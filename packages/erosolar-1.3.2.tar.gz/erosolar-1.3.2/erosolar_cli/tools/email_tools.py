"""
Email Tools for Erosolar CLI

Provides SMTP email sending capabilities with support for Gmail, Outlook,
Yahoo, iCloud, Zoho, and custom SMTP servers.

Principal Investigator: Bo Shang
Framework: erosolar-cli
"""

from __future__ import annotations

import asyncio
import re
import smtplib
import ssl
from base64 import b64decode
from dataclasses import dataclass
from email.mime.base import MIMEBase
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.utils import formataddr
from pathlib import Path
from typing import Any, Dict, List, Optional

from ..core.secret_store import get_secret_value
from ..core.tool_runtime import ToolDefinition
from ..core.types import (
    JSONSchemaArray,
    JSONSchemaBoolean,
    JSONSchemaNumber,
    JSONSchemaObject,
    JSONSchemaString,
)


# ============================================================================
# SMTP Provider Presets
# ============================================================================

SMTP_PRESETS: Dict[str, Dict[str, Any]] = {
    "gmail": {
        "host": "smtp.gmail.com",
        "port": 587,
        "secure": False,  # Uses STARTTLS
    },
    "outlook": {
        "host": "smtp.office365.com",
        "port": 587,
        "secure": False,
    },
    "hotmail": {
        "host": "smtp.office365.com",
        "port": 587,
        "secure": False,
    },
    "yahoo": {
        "host": "smtp.mail.yahoo.com",
        "port": 587,
        "secure": False,
    },
    "icloud": {
        "host": "smtp.mail.me.com",
        "port": 587,
        "secure": False,
    },
    "zoho": {
        "host": "smtp.zoho.com",
        "port": 587,
        "secure": False,
    },
}


# ============================================================================
# Types
# ============================================================================

@dataclass
class EmailConfig:
    """Email configuration."""
    provider: str
    host: str
    port: int
    secure: bool
    user: str
    password: str
    from_name: Optional[str] = None


# ============================================================================
# Configuration
# ============================================================================

def get_email_config() -> Optional[EmailConfig]:
    """
    Get email configuration from secrets/environment.

    Returns:
        EmailConfig or None if not configured
    """
    import os

    # Check secretStore first, then fall back to environment variables
    provider = (
        get_secret_value("SMTP_PROVIDER") or
        os.environ.get("SMTP_PROVIDER", "gmail")
    ).lower()

    user = (
        get_secret_value("SMTP_USER") or
        os.environ.get("SMTP_USER") or
        os.environ.get("EMAIL_USER")
    )

    password = (
        get_secret_value("SMTP_PASSWORD") or
        os.environ.get("SMTP_PASSWORD") or
        os.environ.get("EMAIL_APP_PASSWORD") or
        os.environ.get("SMTP_APP_PASSWORD")
    )

    if not user or not password:
        return None

    # Get preset or custom config
    preset = SMTP_PRESETS.get(provider, {})

    custom_host = get_secret_value("SMTP_HOST") or os.environ.get("SMTP_HOST")
    custom_port = get_secret_value("SMTP_PORT") or os.environ.get("SMTP_PORT")
    from_name = (
        get_secret_value("SMTP_FROM_NAME") or
        os.environ.get("SMTP_FROM_NAME") or
        os.environ.get("EMAIL_FROM_NAME")
    )

    return EmailConfig(
        provider=provider,
        host=custom_host or preset.get("host", "smtp.gmail.com"),
        port=int(custom_port or preset.get("port", 587)),
        secure=os.environ.get("SMTP_SECURE", "").lower() == "true" or preset.get("secure", False),
        user=user,
        password=password,
        from_name=from_name or None,
    )


# ============================================================================
# SMTP Functions
# ============================================================================

def create_smtp_connection(config: EmailConfig) -> smtplib.SMTP:
    """
    Create and verify SMTP connection.

    Args:
        config: Email configuration

    Returns:
        Connected SMTP object

    Raises:
        Exception if connection fails
    """
    import os

    context = ssl.create_default_context()
    reject_unauthorized = os.environ.get("SMTP_REJECT_UNAUTHORIZED", "true").lower() != "false"
    if not reject_unauthorized:
        context.check_hostname = False
        context.verify_mode = ssl.CERT_NONE

    if config.secure:
        # SSL/TLS from the start
        smtp = smtplib.SMTP_SSL(config.host, config.port, context=context)
    else:
        # STARTTLS
        smtp = smtplib.SMTP(config.host, config.port)
        smtp.ehlo()
        smtp.starttls(context=context)
        smtp.ehlo()

    smtp.login(config.user, config.password)
    return smtp


def apply_template(
    template: str,
    data: Dict[str, Any],
) -> str:
    """
    Apply template substitution.

    Args:
        template: Template string with {{variables}}
        data: Data dictionary with values

    Returns:
        Substituted string
    """
    result = template

    # Standard fields
    result = re.sub(r"\{\{email\}\}", data.get("email", ""), result, flags=re.IGNORECASE)
    result = re.sub(r"\{\{name\}\}", data.get("name", ""), result, flags=re.IGNORECASE)
    result = re.sub(r"\{\{company\}\}", data.get("company", ""), result, flags=re.IGNORECASE)

    # First name extraction
    name = data.get("name", "")
    first_name = name.split()[0] if name else ""
    result = re.sub(r"\{\{first_name\}\}", first_name, result, flags=re.IGNORECASE)
    result = re.sub(r"\{\{firstName\}\}", first_name, result, flags=re.IGNORECASE)

    # Custom fields
    custom = data.get("custom", {})
    if isinstance(custom, dict):
        for key, value in custom.items():
            pattern = re.compile(r"\{\{" + re.escape(key) + r"\}\}", re.IGNORECASE)
            result = pattern.sub(str(value) if value else "", result)

    # Clean up unmatched placeholders
    result = re.sub(r"\{\{[^}]+\}\}", "", result)

    return result


# ============================================================================
# Tool Definitions
# ============================================================================

def create_email_tools() -> List[ToolDefinition]:
    """Create email tools."""

    async def send_email_handler(args: Dict[str, Any]) -> str:
        config = get_email_config()

        if not config:
            return """Email not configured. Please set up SMTP credentials:

Required environment variables:
- SMTP_USER or EMAIL_USER: Your email address
- SMTP_PASSWORD or EMAIL_APP_PASSWORD: Your app password

Optional:
- SMTP_PROVIDER: gmail, outlook, yahoo, icloud, zoho (default: gmail)
- SMTP_FROM_NAME: Display name for sent emails

For Gmail, create an app password at: https://myaccount.google.com/apppasswords
For Outlook, create an app password at: https://account.live.com/proofs/AppPassword

Use /secrets to configure these values."""

        to = args.get("to")
        subject = args.get("subject")
        body = args.get("body")
        is_html = args.get("html", False)
        cc = args.get("cc")
        bcc = args.get("bcc")
        reply_to = args.get("reply_to")
        attachments = args.get("attachments", [])

        if not to or not subject or not body:
            return "Error: to, subject, and body are required parameters."

        try:
            # Create message
            if attachments:
                msg = MIMEMultipart()
                if is_html:
                    msg.attach(MIMEText(body, "html"))
                else:
                    msg.attach(MIMEText(body, "plain"))
            else:
                if is_html:
                    msg = MIMEText(body, "html")
                else:
                    msg = MIMEText(body, "plain")

            # Set headers
            from_address = formataddr((config.from_name, config.user)) if config.from_name else config.user
            msg["From"] = from_address
            msg["To"] = to
            msg["Subject"] = subject

            if cc:
                msg["Cc"] = cc
            if reply_to:
                msg["Reply-To"] = reply_to

            # Add attachments
            if attachments and isinstance(attachments, list):
                for att in attachments:
                    if not isinstance(att, dict):
                        continue

                    filename = att.get("filename", "attachment")
                    file_path = att.get("path")
                    content_b64 = att.get("content")

                    part = MIMEBase("application", "octet-stream")

                    if file_path:
                        path = Path(file_path)
                        if path.exists():
                            part.set_payload(path.read_bytes())
                            filename = filename or path.name
                    elif content_b64:
                        part.set_payload(b64decode(content_b64))
                    else:
                        continue

                    from email import encoders
                    encoders.encode_base64(part)
                    part.add_header("Content-Disposition", f"attachment; filename={filename}")
                    msg.attach(part)

            # Build recipient list
            all_recipients = [r.strip() for r in to.split(",")]
            if cc:
                all_recipients.extend([r.strip() for r in cc.split(",")])
            if bcc:
                all_recipients.extend([r.strip() for r in bcc.split(",")])

            # Send email
            smtp = create_smtp_connection(config)
            try:
                smtp.sendmail(config.user, all_recipients, msg.as_string())
            finally:
                smtp.quit()

            attachment_info = f"\nAttachments: {len(attachments)} file(s)" if attachments else ""
            cc_info = f"\nCC: {cc}" if cc else ""
            bcc_info = f"\nBCC: {bcc}" if bcc else ""

            return f"""Email sent successfully!

To: {to}
Subject: {subject}
Provider: {config.provider}{cc_info}{bcc_info}{attachment_info}

Response: Message sent"""

        except smtplib.SMTPAuthenticationError as e:
            return f"""Authentication failed.

Error: {e}

Common fixes:
1. Make sure you're using an APP PASSWORD, not your regular password
2. For Gmail: https://myaccount.google.com/apppasswords
3. For Outlook: https://account.live.com/proofs/AppPassword
4. Ensure 2-Factor Authentication is enabled on your account
5. Check that SMTP_USER matches the email account"""

        except (smtplib.SMTPConnectError, ConnectionRefusedError, OSError) as e:
            return f"""Could not connect to SMTP server.

Error: {e}

Current config:
- Host: {config.host}
- Port: {config.port}
- Provider: {config.provider}

Try setting SMTP_HOST and SMTP_PORT manually if using a custom server."""

        except Exception as e:
            return f"Failed to send email: {e}"

    async def verify_email_config_handler(args: Dict[str, Any]) -> str:
        config = get_email_config()

        if not config:
            return """Email not configured.

Required environment variables:
- SMTP_USER or EMAIL_USER
- SMTP_PASSWORD or EMAIL_APP_PASSWORD

Optional:
- SMTP_PROVIDER: gmail, outlook, yahoo, icloud, zoho
- SMTP_HOST, SMTP_PORT: For custom SMTP servers
- SMTP_FROM_NAME: Display name

Use /secrets to configure these values."""

        try:
            smtp = create_smtp_connection(config)
            smtp.quit()

            return f"""Email configuration verified!

Provider: {config.provider}
Host: {config.host}
Port: {config.port}
User: {config.user}
Secure: {'Yes (SSL/TLS)' if config.secure else 'No (STARTTLS)'}
From Name: {config.from_name or '(not set)'}

SMTP connection successful. You can now use send_email to send emails."""

        except Exception as e:
            return f"""Email configuration verification failed.

Provider: {config.provider}
Host: {config.host}
Port: {config.port}
User: {config.user}

Error: {e}

Common issues:
1. Wrong app password (must use app password, not regular password)
2. 2FA not enabled on email account
3. Wrong SMTP provider selected
4. Network/firewall blocking SMTP ports"""

    async def send_batch_emails_handler(args: Dict[str, Any]) -> str:
        config = get_email_config()

        if not config:
            return "Email not configured. Use /secrets to set SMTP_USER and SMTP_PASSWORD."

        recipients = args.get("recipients", [])
        subject_template = args.get("subject_template")
        body_template = args.get("body_template")
        is_html = args.get("html", False)
        delay_ms = args.get("delay_ms", 1000)

        if not recipients or not subject_template or not body_template:
            return "Error: recipients, subject_template, and body_template are required."

        try:
            smtp = create_smtp_connection(config)
            from_address = formataddr((config.from_name, config.user)) if config.from_name else config.user

            results: List[Dict[str, Any]] = []

            for i, recipient in enumerate(recipients):
                if not isinstance(recipient, dict) or not recipient.get("email"):
                    continue

                # Apply template substitution
                personalized_subject = apply_template(subject_template, recipient)
                personalized_body = apply_template(body_template, recipient)

                try:
                    if is_html:
                        msg = MIMEText(personalized_body, "html")
                    else:
                        msg = MIMEText(personalized_body, "plain")

                    msg["From"] = from_address
                    msg["To"] = recipient["email"]
                    msg["Subject"] = personalized_subject

                    smtp.sendmail(config.user, [recipient["email"]], msg.as_string())
                    results.append({"email": recipient["email"], "success": True})

                except Exception as e:
                    results.append({
                        "email": recipient["email"],
                        "success": False,
                        "error": str(e),
                    })

                # Delay between emails (except for last one)
                if i < len(recipients) - 1 and delay_ms > 0:
                    await asyncio.sleep(delay_ms / 1000)

            smtp.quit()

            successful = sum(1 for r in results if r.get("success"))
            failed = [r for r in results if not r.get("success")]

            summary = f"""Batch Email Results

Total: {len(recipients)}
Sent: {successful}
Failed: {len(failed)}
Provider: {config.provider}
"""

            if failed:
                summary += "\nFailed emails:\n"
                for f in failed:
                    summary += f"- {f['email']}: {f.get('error', 'Unknown error')}\n"

            return summary

        except Exception as e:
            return f"Batch email failed: {e}"

    return [
        ToolDefinition(
            name="send_email",
            description="""Send an email via SMTP. Supports Gmail, Outlook, Yahoo, iCloud, Zoho, and custom SMTP servers.

Configuration (set via /secrets or environment variables):
- SMTP_USER or EMAIL_USER: Your email address
- SMTP_PASSWORD or EMAIL_APP_PASSWORD: Your app password (NOT your regular password)
- SMTP_PROVIDER: gmail, outlook, yahoo, icloud, zoho (default: gmail)
- SMTP_FROM_NAME: Display name for sent emails (optional)

For Gmail:
1. Enable 2-Factor Authentication
2. Go to https://myaccount.google.com/apppasswords
3. Generate an app password for "Mail"
4. Use that app password as SMTP_PASSWORD

For Outlook/Hotmail:
1. Go to https://account.live.com/proofs/AppPassword
2. Generate an app password
3. Use that as SMTP_PASSWORD

Use cases:
- Send notifications, reports, or alerts
- Automated outreach (investors, leads, contacts)
- Send formatted HTML emails with attachments
- Batch email campaigns with personalization""",
            parameters=JSONSchemaObject(
                properties={
                    "to": JSONSchemaString(
                        description="Recipient email address(es). For multiple recipients, use comma-separated values."
                    ),
                    "subject": JSONSchemaString(description="Email subject line"),
                    "body": JSONSchemaString(
                        description="Email body content. Can be plain text or HTML."
                    ),
                    "html": JSONSchemaBoolean(
                        description="Set to true if body contains HTML content (default: false)"
                    ),
                    "cc": JSONSchemaString(
                        description="CC recipient(s), comma-separated (optional)"
                    ),
                    "bcc": JSONSchemaString(
                        description="BCC recipient(s), comma-separated (optional)"
                    ),
                    "reply_to": JSONSchemaString(
                        description="Reply-To address (optional)"
                    ),
                    "attachments": JSONSchemaArray(
                        items=JSONSchemaObject(
                            properties={
                                "filename": JSONSchemaString(description="Filename"),
                                "path": JSONSchemaString(description="File path to attach"),
                                "content": JSONSchemaString(
                                    description="Base64 encoded content (alternative to path)"
                                ),
                            }
                        ),
                        description="Array of attachments (optional)",
                    ),
                },
                required=["to", "subject", "body"],
            ),
            handler=send_email_handler,
        ),
        ToolDefinition(
            name="verify_email_config",
            description="Verify that email/SMTP configuration is correct and can connect to the mail server.",
            parameters=JSONSchemaObject(properties={}),
            handler=verify_email_config_handler,
        ),
        ToolDefinition(
            name="send_batch_emails",
            description="""Send personalized emails to multiple recipients in batch.

Useful for:
- Investor outreach campaigns
- Lead nurturing sequences
- Newsletter distribution
- Bulk notifications with personalization

Supports template variables: {{name}}, {{company}}, {{custom_field}}""",
            parameters=JSONSchemaObject(
                properties={
                    "recipients": JSONSchemaArray(
                        items=JSONSchemaObject(
                            properties={
                                "email": JSONSchemaString(description="Recipient email"),
                                "name": JSONSchemaString(
                                    description="Recipient name for personalization"
                                ),
                                "company": JSONSchemaString(
                                    description="Company name (optional)"
                                ),
                                "custom": JSONSchemaObject(
                                    description="Custom fields for template substitution"
                                ),
                            },
                            required=["email"],
                        ),
                        description="Array of recipients with personalization data",
                    ),
                    "subject_template": JSONSchemaString(
                        description="Subject line template with {{variables}}"
                    ),
                    "body_template": JSONSchemaString(
                        description="Email body template with {{variables}}"
                    ),
                    "html": JSONSchemaBoolean(
                        description="Set to true if body contains HTML (default: false)"
                    ),
                    "delay_ms": JSONSchemaNumber(
                        description="Delay between emails in milliseconds (default: 1000). Helps avoid rate limits."
                    ),
                },
                required=["recipients", "subject_template", "body_template"],
            ),
            handler=send_batch_emails_handler,
        ),
    ]


# ============================================================================
# Exports
# ============================================================================

__all__ = [
    "create_email_tools",
    "EmailConfig",
    "get_email_config",
]
