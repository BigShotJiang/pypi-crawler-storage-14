"""
Automatic Dependency Manager - Auto-install missing tools via package managers.

Detects OS, checks if commands exist, and automatically installs missing dependencies
via Homebrew (macOS), apt (Debian/Ubuntu), yum (RHEL/CentOS), or pacman (Arch).
"""

from __future__ import annotations

import asyncio
import os
import platform
import shutil
from typing import Optional


class DependencyManager:
    """Manages automatic installation of missing command-line tools."""

    def __init__(self):
        self.os_type = platform.system().lower()
        self.package_manager = self._detect_package_manager()

    def _detect_package_manager(self) -> Optional[str]:
        """Detect available package manager based on OS and installed tools."""
        if self.os_type == "darwin":
            # macOS - use Homebrew
            if shutil.which("brew"):
                return "brew"
            return None

        elif self.os_type == "linux":
            # Linux - detect distro package manager
            if shutil.which("apt-get"):
                return "apt"
            elif shutil.which("yum"):
                return "yum"
            elif shutil.which("dnf"):
                return "dnf"
            elif shutil.which("pacman"):
                return "pacman"
            elif shutil.which("zypper"):
                return "zypper"
            return None

        return None

    def command_exists(self, command: str) -> bool:
        """Check if a command is available in PATH."""
        return shutil.which(command) is not None

    async def install_package(self, package_name: str, command_name: Optional[str] = None) -> tuple[bool, str]:
        """
        Automatically install a package using the detected package manager.

        Args:
            package_name: Package name to install (e.g., "nmap")
            command_name: Command name to verify (defaults to package_name)

        Returns:
            Tuple of (success, output_message)
        """
        if not command_name:
            command_name = package_name

        # Check if already installed
        if self.command_exists(command_name):
            return True, f"✓ {command_name} is already installed"

        # No package manager available
        if not self.package_manager:
            return False, f"❌ No package manager detected. Please install {package_name} manually."

        # Build installation command
        install_cmd = self._get_install_command(package_name)
        if not install_cmd:
            return False, f"❌ Unsupported package manager for {package_name}"

        # Execute installation
        try:
            output_lines = [
                f"🔧 Installing {package_name} via {self.package_manager}...",
                f"Command: {install_cmd}",
                "",
            ]

            proc = await asyncio.create_subprocess_shell(
                install_cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )

            stdout, stderr = await asyncio.wait_for(proc.communicate(), timeout=300.0)
            stdout_text = stdout.decode("utf-8", errors="replace")
            stderr_text = stderr.decode("utf-8", errors="replace")

            # Check if installation succeeded
            if proc.returncode == 0 and self.command_exists(command_name):
                output_lines.extend([
                    f"✅ Successfully installed {package_name}",
                    f"✓ Verified: {command_name} is now available",
                    "",
                    "Installation output:",
                    stdout_text[-500:] if len(stdout_text) > 500 else stdout_text,
                ])
                return True, "\n".join(output_lines)

            # Installation failed
            output_lines.extend([
                f"❌ Failed to install {package_name} (exit code: {proc.returncode})",
                "",
                "stdout:",
                stdout_text[-500:] if len(stdout_text) > 500 else stdout_text,
                "",
                "stderr:",
                stderr_text[-500:] if len(stderr_text) > 500 else stderr_text,
                "",
                f"Manual installation: {self._get_manual_install_instructions(package_name)}",
            ])
            return False, "\n".join(output_lines)

        except asyncio.TimeoutError:
            return False, f"❌ Installation of {package_name} timed out after 300 seconds"
        except Exception as e:
            return False, f"❌ Installation failed: {str(e)}"

    def _get_install_command(self, package_name: str) -> Optional[str]:
        """Get the installation command for the current package manager."""
        # Special case: searchsploit is part of exploitdb on Homebrew
        if package_name == "searchsploit" and self.package_manager == "brew":
            return "brew install exploitdb"
        
        # Special case: gcloud CLI installation
        if package_name == "gcloud" and self.package_manager == "brew":
            return "brew install --cask google-cloud-sdk"
        
        # Special case: AWS CLI installation
        if package_name == "aws" and self.package_manager == "brew":
            return "brew install awscli"

        if self.package_manager == "brew":
            return f"brew install {package_name}"

        elif self.package_manager == "apt":
            # Check if running with sudo
            if os.geteuid() == 0:
                return f"apt-get update && apt-get install -y {package_name}"
            else:
                return f"sudo apt-get update && sudo apt-get install -y {package_name}"

        elif self.package_manager in ("yum", "dnf"):
            if os.geteuid() == 0:
                return f"{self.package_manager} install -y {package_name}"
            else:
                return f"sudo {self.package_manager} install -y {package_name}"

        elif self.package_manager == "pacman":
            if os.geteuid() == 0:
                return f"pacman -Sy --noconfirm {package_name}"
            else:
                return f"sudo pacman -Sy --noconfirm {package_name}"

        elif self.package_manager == "zypper":
            if os.geteuid() == 0:
                return f"zypper install -y {package_name}"
            else:
                return f"sudo zypper install -y {package_name}"

        return None

    def _get_manual_install_instructions(self, package_name: str) -> str:
        """Get manual installation instructions for the package."""
        instructions = {
            "nmap": "macOS: brew install nmap | Ubuntu: sudo apt install nmap | Kali: pre-installed",
            "searchsploit": "macOS: brew install exploitdb | git clone https://gitlab.com/exploit-database/exploitdb.git /opt/exploitdb && ln -sf /opt/exploitdb/searchsploit /usr/local/bin/searchsploit",
            "sqlmap": "macOS: brew install sqlmap | Ubuntu: sudo apt install sqlmap | pip: pip install sqlmap",
            "nikto": "macOS: brew install nikto | Ubuntu: sudo apt install nikto",
            "wfuzz": "pip install wfuzz",
            "ffuf": "macOS: brew install ffuf | Go: go install github.com/ffuf/ffuf@latest",
            "gobuster": "macOS: brew install gobuster | Go: go install github.com/OJ/gobuster/v3@latest",
            "hydra": "macOS: brew install hydra | Ubuntu: sudo apt install hydra",
            "john": "macOS: brew install john | Ubuntu: sudo apt install john",
            "hashcat": "macOS: brew install hashcat | Ubuntu: sudo apt install hashcat",
            "gcloud": "macOS: brew install --cask google-cloud-sdk | Linux: curl https://sdk.cloud.google.com | bash",
            "aws": "macOS: brew install awscli | Linux: curl 'https://awscli.amazonaws.com/awscli-exe-linux-x86_64.zip' -o 'awscliv2.zip' && unzip awscliv2.zip && sudo ./aws/install",
        }
        return instructions.get(package_name, f"Visit package documentation for {package_name} installation")

    async def ensure_command(self, command_name: str, package_name: Optional[str] = None) -> tuple[bool, str]:
        """
        Ensure a command is available, installing if necessary.

        Args:
            command_name: Command to check (e.g., "nmap")
            package_name: Package to install if different from command (e.g., "nmap" for "nmap")

        Returns:
            Tuple of (available, message)
        """
        if not package_name:
            package_name = command_name

        # Check if command exists
        if self.command_exists(command_name):
            return True, f"✓ {command_name} is available"

        # Attempt installation
        return await self.install_package(package_name, command_name)


# Global instance
_dependency_manager: Optional[DependencyManager] = None


def get_dependency_manager() -> DependencyManager:
    """Get or create the global dependency manager instance."""
    global _dependency_manager
    if _dependency_manager is None:
        _dependency_manager = DependencyManager()
    return _dependency_manager


async def ensure_command_available(command: str, package: Optional[str] = None) -> tuple[bool, str]:
    """
    Convenience function to ensure a command is available.

    Args:
        command: Command name to check
        package: Package name to install if different from command

    Returns:
        Tuple of (available, message)
    """
    manager = get_dependency_manager()
    return await manager.ensure_command(command, package)


# Package name mappings for common tools
PACKAGE_MAPPINGS = {
    "searchsploit": "exploitdb",  # Note: searchsploit requires special handling
    "sqlmap": "sqlmap",
    "nmap": "nmap",
    "nikto": "nikto",
    "wfuzz": "wfuzz",
    "ffuf": "ffuf",
    "gobuster": "gobuster",
    "hydra": "hydra",
    "john": "john",
    "hashcat": "hashcat",
    "masscan": "masscan",
    "zap": "zaproxy",
    "gcloud": "google-cloud-sdk",
    "aws": "awscli",
}


def get_package_name(command: str) -> str:
    """Get the package name for a command."""
    return PACKAGE_MAPPINGS.get(command, command)
