"""
Browser Automation Tools for Erosolar CLI

Provides browser control capabilities for:
- Opening URLs in Chrome/Safari/Firefox
- Taking screenshots of web pages
- Interactive OAuth flows
- Website testing and verification

Principal Investigator: Bo Shang
Framework: erosolar-cli
"""

from __future__ import annotations

import asyncio
import base64
import os
import platform
import shutil
import tempfile
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from ..core.unified.types import (
    JSONSchemaObject,
    JSONSchemaProperty,
    ToolDefinition,
)


# ============================================================================
# Types
# ============================================================================

@dataclass
class BrowserInfo:
    """Information about available browsers."""
    name: str
    command: str
    available: bool
    path: Optional[str] = None


@dataclass
class ScreenshotResult:
    """Result of a screenshot operation."""
    success: bool
    path: Optional[str] = None
    error: Optional[str] = None
    width: Optional[int] = None
    height: Optional[int] = None


# ============================================================================
# Helper Functions
# ============================================================================

async def run_command(
    command: str,
    timeout: int = 30,
    cwd: Optional[str] = None,
) -> Tuple[str, str, int]:
    """Run a shell command asynchronously."""
    try:
        process = await asyncio.create_subprocess_shell(
            command,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
            cwd=cwd,
            env={**os.environ},
        )

        try:
            stdout, stderr = await asyncio.wait_for(
                process.communicate(),
                timeout=timeout,
            )
            return (
                stdout.decode("utf-8", errors="replace").strip(),
                stderr.decode("utf-8", errors="replace").strip(),
                process.returncode or 0,
            )
        except asyncio.TimeoutError:
            process.kill()
            return ("", "Command timed out", 1)

    except Exception as e:
        return ("", str(e), 1)


def detect_browsers() -> List[BrowserInfo]:
    """Detect available browsers on the system."""
    system = platform.system()
    browsers: List[BrowserInfo] = []

    if system == "Darwin":
        # macOS browsers
        browser_paths = [
            ("Google Chrome", "/Applications/Google Chrome.app"),
            ("Safari", "/Applications/Safari.app"),
            ("Firefox", "/Applications/Firefox.app"),
            ("Microsoft Edge", "/Applications/Microsoft Edge.app"),
            ("Brave Browser", "/Applications/Brave Browser.app"),
            ("Arc", "/Applications/Arc.app"),
        ]
        for name, path in browser_paths:
            browsers.append(BrowserInfo(
                name=name,
                command=f'open -a "{name}"',
                available=Path(path).exists(),
                path=path,
            ))

    elif system == "Linux":
        # Linux browsers
        browser_commands = [
            ("Google Chrome", "google-chrome"),
            ("Chromium", "chromium"),
            ("Firefox", "firefox"),
            ("Microsoft Edge", "microsoft-edge"),
            ("Brave", "brave-browser"),
        ]
        for name, cmd in browser_commands:
            path = shutil.which(cmd)
            browsers.append(BrowserInfo(
                name=name,
                command=cmd,
                available=path is not None,
                path=path,
            ))

    elif system == "Windows":
        # Windows browsers (common paths)
        browser_paths = [
            ("Google Chrome", r"C:\Program Files\Google\Chrome\Application\chrome.exe"),
            ("Microsoft Edge", r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe"),
            ("Firefox", r"C:\Program Files\Mozilla Firefox\firefox.exe"),
        ]
        for name, path in browser_paths:
            browsers.append(BrowserInfo(
                name=name,
                command=f'"{path}"',
                available=Path(path).exists(),
                path=path,
            ))

    return browsers


def get_default_browser() -> Optional[BrowserInfo]:
    """Get the default/preferred browser."""
    browsers = detect_browsers()
    available = [b for b in browsers if b.available]

    # Prefer Chrome for consistency
    for browser in available:
        if "Chrome" in browser.name:
            return browser

    return available[0] if available else None


async def open_url_macos(url: str, browser: Optional[str] = None) -> Tuple[bool, str]:
    """Open URL on macOS."""
    if browser:
        cmd = f'open -a "{browser}" "{url}"'
    else:
        cmd = f'open "{url}"'

    stdout, stderr, exit_code = await run_command(cmd)

    if exit_code == 0:
        return (True, f"Opened {url}" + (f" in {browser}" if browser else ""))
    else:
        return (False, stderr or "Failed to open URL")


async def open_url_linux(url: str, browser: Optional[str] = None) -> Tuple[bool, str]:
    """Open URL on Linux."""
    if browser:
        cmd = f'{browser} "{url}" &'
    else:
        cmd = f'xdg-open "{url}" &'

    stdout, stderr, exit_code = await run_command(cmd)

    if exit_code == 0:
        return (True, f"Opened {url}")
    else:
        return (False, stderr or "Failed to open URL")


async def take_screenshot_macos(
    url: str,
    output_path: Optional[str] = None,
    width: int = 1280,
    height: int = 800,
    delay: int = 2,
) -> ScreenshotResult:
    """Take screenshot using macOS screencapture after opening URL."""
    # First open the URL
    success, msg = await open_url_macos(url, "Google Chrome")
    if not success:
        return ScreenshotResult(success=False, error=msg)

    # Wait for page to load
    await asyncio.sleep(delay)

    # Generate output path if not provided
    if not output_path:
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        output_path = str(Path(tempfile.gettempdir()) / f"screenshot_{timestamp}.png")

    # Use screencapture
    cmd = f'screencapture -x "{output_path}"'
    stdout, stderr, exit_code = await run_command(cmd)

    if exit_code == 0 and Path(output_path).exists():
        return ScreenshotResult(
            success=True,
            path=output_path,
            width=width,
            height=height,
        )
    else:
        return ScreenshotResult(success=False, error=stderr or "Screenshot failed")


async def run_interactive_login(
    login_command: str,
    timeout: int = 180,
) -> Tuple[bool, str]:
    """
    Run an interactive login command using pseudo-TTY.
    This enables browser-based OAuth flows.
    """
    system = platform.system()

    if system == "Darwin":
        wrapped_cmd = f'script -q /dev/null {login_command}'
    elif system == "Linux":
        wrapped_cmd = f'script -q -c "{login_command}" /dev/null'
    else:
        wrapped_cmd = login_command

    stdout, stderr, exit_code = await run_command(wrapped_cmd, timeout=timeout)

    success_indicators = ["success", "logged in", "authenticated", "✓", "✔"]
    output = (stdout + stderr).lower()

    if exit_code == 0 or any(ind in output for ind in success_indicators):
        return (True, stdout or "Login completed")
    else:
        return (False, stderr or stdout or "Login failed")


# ============================================================================
# Tool Definitions
# ============================================================================

def create_browser_tools(working_dir: Optional[str] = None) -> List[ToolDefinition]:
    """Create browser automation tools."""
    if working_dir is None:
        working_dir = os.getcwd()

    async def browser_open_handler(args: Dict[str, Any]) -> str:
        """Open a URL in a browser."""
        url = args.get("url")
        browser = args.get("browser")

        if not url:
            return "Error: url parameter is required"

        # Ensure URL has protocol
        if not url.startswith(("http://", "https://", "file://")):
            url = "https://" + url

        system = platform.system()

        if system == "Darwin":
            success, msg = await open_url_macos(url, browser)
        elif system == "Linux":
            success, msg = await open_url_linux(url, browser)
        else:
            # Fallback for Windows or other systems
            import webbrowser
            try:
                webbrowser.open(url)
                success, msg = True, f"Opened {url}"
            except Exception as e:
                success, msg = False, str(e)

        if success:
            return f"✓ {msg}"
        else:
            return f"Error: {msg}"

    async def browser_list_handler(args: Dict[str, Any]) -> str:
        """List available browsers."""
        browsers = detect_browsers()

        lines = ["Available Browsers:\n"]
        for browser in browsers:
            status = "✓" if browser.available else "✗"
            lines.append(f"{status} {browser.name}")
            if browser.available and browser.path:
                lines.append(f"   Path: {browser.path}")

        default = get_default_browser()
        if default:
            lines.append(f"\nDefault: {default.name}")

        return "\n".join(lines)

    async def browser_screenshot_handler(args: Dict[str, Any]) -> str:
        """Take a screenshot of a URL."""
        url = args.get("url")
        output_path = args.get("output_path")
        width = args.get("width", 1280)
        height = args.get("height", 800)
        delay = args.get("delay", 3)

        if not url:
            return "Error: url parameter is required"

        # Ensure URL has protocol
        if not url.startswith(("http://", "https://", "file://")):
            url = "https://" + url

        system = platform.system()

        if system == "Darwin":
            result = await take_screenshot_macos(url, output_path, width, height, delay)
        else:
            return f"Screenshot not yet supported on {system}. Consider installing Playwright:\n  pip install playwright && playwright install"

        if result.success:
            return f"""✓ Screenshot captured!
Path: {result.path}
URL: {url}

You can view this file or use it for comparison."""
        else:
            return f"Error taking screenshot: {result.error}"

    async def browser_auth_handler(args: Dict[str, Any]) -> str:
        """
        Run interactive browser-based authentication.
        Supports OAuth flows for cloud providers.
        """
        command = args.get("command")
        timeout = args.get("timeout", 180)

        if not command:
            return "Error: command parameter is required"

        # Run the interactive login
        success, output = await run_interactive_login(command, timeout)

        if success:
            return f"""✓ Authentication completed!

{output}

You can now use authenticated features."""
        else:
            return f"""Authentication output:

{output}

If authentication failed, try running the command directly in your terminal:
  {command}"""

    async def browser_test_url_handler(args: Dict[str, Any]) -> str:
        """Test if a URL is accessible and get basic info."""
        url = args.get("url")

        if not url:
            return "Error: url parameter is required"

        # Ensure URL has protocol
        if not url.startswith(("http://", "https://")):
            url = "https://" + url

        import aiohttp

        try:
            timeout = aiohttp.ClientTimeout(total=10)
            async with aiohttp.ClientSession(timeout=timeout) as session:
                async with session.head(
                    url,
                    allow_redirects=True,
                    headers={"User-Agent": "Mozilla/5.0 (compatible; ErosolarBot/1.0)"},
                ) as response:
                    return f"""URL Test Results for {url}

Status: {response.status} {response.reason}
Final URL: {response.url}
Content-Type: {response.headers.get('Content-Type', 'Unknown')}
Server: {response.headers.get('Server', 'Unknown')}

✓ URL is accessible"""

        except aiohttp.ClientError as e:
            return f"""URL Test Results for {url}

Error: {type(e).__name__}: {str(e)}

✗ URL is not accessible"""
        except Exception as e:
            return f"Error testing URL: {e}"

    return [
        ToolDefinition(
            name="browser_open",
            description="""Open a URL in a web browser.

Uses the system's default browser or a specified browser.
Supports macOS (open command), Linux (xdg-open), and Windows.

Use cases:
- Open web pages for manual inspection
- Launch OAuth authentication flows
- Open Firebase/Vercel/etc. dashboards
- Preview deployed websites""",
            execute=browser_open_handler,
            parameters=JSONSchemaObject(
                type="object",
                properties={
                    "url": JSONSchemaProperty(
                        type="string",
                        description="URL to open (https:// prefix added if missing)"
                    ),
                    "browser": JSONSchemaProperty(
                        type="string",
                        description="Specific browser to use (e.g., 'Google Chrome', 'Safari', 'Firefox'). Uses default if not specified."
                    ),
                },
                required=["url"],
            ),
            category="browser",
        ),
        ToolDefinition(
            name="browser_list",
            description="""List available browsers on the system.

Shows which browsers are installed and available for use.
Useful for determining which browser to use for specific tasks.""",
            execute=browser_list_handler,
            parameters=JSONSchemaObject(
                type="object",
                properties={},
            ),
            category="browser",
        ),
        ToolDefinition(
            name="browser_screenshot",
            description="""Take a screenshot of a web page.

Opens the URL in Chrome, waits for it to load, and captures a screenshot.
Currently supports macOS. For cross-platform screenshots, consider using Playwright.

Use cases:
- Visual verification of deployed websites
- Capturing UI state for debugging
- Documentation screenshots""",
            execute=browser_screenshot_handler,
            parameters=JSONSchemaObject(
                type="object",
                properties={
                    "url": JSONSchemaProperty(
                        type="string",
                        description="URL to screenshot"
                    ),
                    "output_path": JSONSchemaProperty(
                        type="string",
                        description="Path to save screenshot (auto-generated if not specified)"
                    ),
                    "width": JSONSchemaProperty(
                        type="integer",
                        description="Viewport width (default: 1280)"
                    ),
                    "height": JSONSchemaProperty(
                        type="integer",
                        description="Viewport height (default: 800)"
                    ),
                    "delay": JSONSchemaProperty(
                        type="integer",
                        description="Seconds to wait for page load (default: 3)"
                    ),
                },
                required=["url"],
            ),
            category="browser",
        ),
        ToolDefinition(
            name="browser_auth",
            description="""Run interactive browser-based authentication.

Executes a CLI login command with pseudo-TTY support, enabling
browser-based OAuth flows to complete successfully.

Supports:
- Firebase: firebase login, firebase login --reauth
- Google Cloud: gcloud auth login
- Azure: az login
- Vercel: vercel login
- Any CLI that opens a browser for OAuth

The command runs with a pseudo-TTY wrapper (script command) to
enable interactive login even in non-interactive environments.""",
            execute=browser_auth_handler,
            parameters=JSONSchemaObject(
                type="object",
                properties={
                    "command": JSONSchemaProperty(
                        type="string",
                        description="The login command to run (e.g., 'firebase login --reauth')"
                    ),
                    "timeout": JSONSchemaProperty(
                        type="integer",
                        description="Timeout in seconds for the auth flow (default: 180)"
                    ),
                },
                required=["command"],
            ),
            category="browser",
        ),
        ToolDefinition(
            name="browser_test_url",
            description="""Test if a URL is accessible and get basic info.

Performs a HEAD request to check URL accessibility without
downloading the full content.

Returns:
- HTTP status code
- Final URL (after redirects)
- Content-Type
- Server info

Use cases:
- Verify deployments are live
- Check URL redirects
- Quick availability checks""",
            execute=browser_test_url_handler,
            parameters=JSONSchemaObject(
                type="object",
                properties={
                    "url": JSONSchemaProperty(
                        type="string",
                        description="URL to test"
                    ),
                },
                required=["url"],
            ),
            category="browser",
        ),
    ]


# ============================================================================
# Exports
# ============================================================================

__all__ = [
    "create_browser_tools",
    "detect_browsers",
    "get_default_browser",
    "run_interactive_login",
    "BrowserInfo",
    "ScreenshotResult",
]
