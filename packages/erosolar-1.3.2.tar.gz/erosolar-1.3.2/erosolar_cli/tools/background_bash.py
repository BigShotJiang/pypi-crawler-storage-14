"""
Background Bash Shell Manager for Erosolar CLI

Manages long-running background bash shells with output buffering.
Provides tools for starting, monitoring, and killing background processes.

Principal Investigator: Bo Shang
Framework: erosolar-cli
"""

from __future__ import annotations

import asyncio
import re
import subprocess
import threading
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

from ..core.tool_runtime import ToolDefinition
from ..core.types import JSONSchemaObject, JSONSchemaString


# ============================================================================
# Background Shell Classes
# ============================================================================

@dataclass
class ShellOutput:
    """Output from a background shell."""
    stdout: str
    stderr: str
    status: str


class BackgroundShell:
    """
    A background bash shell with output buffering.

    Captures stdout/stderr and tracks execution status.
    """

    def __init__(self, shell_id: str, command: str, working_dir: str) -> None:
        self.id = shell_id
        self._command = command
        self._working_dir = working_dir
        self._process: Optional[subprocess.Popen] = None
        self._output_buffer: List[str] = []
        self._error_buffer: List[str] = []
        self._last_read_position = 0
        self._is_running = False
        self._exit_code: Optional[int] = None
        self._lock = threading.Lock()

    def start(self) -> None:
        """Start the background shell."""
        self._process = subprocess.Popen(
            ["bash", "-c", self._command],
            cwd=self._working_dir,
            stdin=subprocess.DEVNULL,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
        )
        self._is_running = True

        # Start reader threads
        threading.Thread(target=self._read_stdout, daemon=True).start()
        threading.Thread(target=self._read_stderr, daemon=True).start()
        threading.Thread(target=self._wait_for_exit, daemon=True).start()

    def _read_stdout(self) -> None:
        """Read stdout in background."""
        if self._process and self._process.stdout:
            for line in self._process.stdout:
                with self._lock:
                    self._output_buffer.append(line)

    def _read_stderr(self) -> None:
        """Read stderr in background."""
        if self._process and self._process.stderr:
            for line in self._process.stderr:
                with self._lock:
                    self._error_buffer.append(line)

    def _wait_for_exit(self) -> None:
        """Wait for process to exit."""
        if self._process:
            self._exit_code = self._process.wait()
            self._is_running = False

    def get_new_output(self, filter_pattern: Optional[str] = None) -> ShellOutput:
        """
        Get new output since last read.

        Args:
            filter_pattern: Optional regex pattern to filter output lines

        Returns:
            ShellOutput with stdout, stderr, and status
        """
        with self._lock:
            all_output = "".join(self._output_buffer)
            new_output = all_output[self._last_read_position:]
            self._last_read_position = len(all_output)

            all_error = "".join(self._error_buffer)

            stdout = new_output
            if filter_pattern:
                try:
                    pattern = re.compile(filter_pattern)
                    lines = new_output.split("\n")
                    filtered = [line for line in lines if pattern.search(line)]
                    stdout = "\n".join(filtered)
                except re.error:
                    pass  # Use unfiltered if regex is invalid

            status = "running" if self._is_running else f"exited with code {self._exit_code}"

            return ShellOutput(
                stdout=stdout,
                stderr=all_error,
                status=status,
            )

    def kill(self) -> None:
        """Kill the background shell."""
        if self._process:
            self._process.terminate()
            try:
                self._process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                self._process.kill()

    def get_status(self) -> str:
        """Get current status."""
        return "running" if self._is_running else f"exited with code {self._exit_code}"


class BackgroundShellManager:
    """
    Manages multiple background shells.

    Thread-safe singleton for shell lifecycle management.
    """

    _instance: Optional["BackgroundShellManager"] = None
    _lock = threading.Lock()

    def __init__(self) -> None:
        self._shells: Dict[str, BackgroundShell] = {}
        self._next_id = 1
        self._manager_lock = threading.Lock()

    @classmethod
    def get_instance(cls) -> "BackgroundShellManager":
        """Get singleton instance."""
        with cls._lock:
            if cls._instance is None:
                cls._instance = BackgroundShellManager()
            return cls._instance

    def create_shell(self, command: str, working_dir: str) -> str:
        """
        Create and start a new background shell.

        Args:
            command: Command to execute
            working_dir: Working directory

        Returns:
            Shell ID
        """
        with self._manager_lock:
            shell_id = f"shell_{self._next_id}"
            self._next_id += 1
            shell = BackgroundShell(shell_id, command, working_dir)
            self._shells[shell_id] = shell
            shell.start()
            return shell_id

    def get_shell(self, shell_id: str) -> Optional[BackgroundShell]:
        """Get a shell by ID."""
        return self._shells.get(shell_id)

    def kill_shell(self, shell_id: str) -> bool:
        """
        Kill a shell by ID.

        Returns:
            True if killed, False if not found
        """
        shell = self._shells.get(shell_id)
        if shell:
            shell.kill()
            del self._shells[shell_id]
            return True
        return False

    def list_shells(self) -> List[str]:
        """List all active shell IDs."""
        return list(self._shells.keys())


# Global manager instance
shell_manager = BackgroundShellManager.get_instance()


# ============================================================================
# Tool Definitions
# ============================================================================

def create_background_bash_tools(working_dir: str) -> List[ToolDefinition]:
    """
    Create background bash management tools.

    Args:
        working_dir: Default working directory for commands

    Returns:
        List of tool definitions
    """

    async def bash_output_handler(args: Dict[str, Any]) -> str:
        bash_id = args.get("bash_id")
        filter_str = args.get("filter")

        if not bash_id or not isinstance(bash_id, str) or not bash_id.strip():
            return "Error: bash_id must be a non-empty string."

        try:
            shell = shell_manager.get_shell(bash_id)
            if not shell:
                available = shell_manager.list_shells()
                available_str = ", ".join(available) if available else "none"
                return f'Error: Shell "{bash_id}" not found.\n\nAvailable shells: {available_str}'

            output = shell.get_new_output(filter_str)

            parts = [
                f"Shell: {bash_id}",
                f"Status: {output.status}",
            ]

            if output.stdout:
                parts.append("\n=== New Output ===")
                parts.append(output.stdout)

            if output.stderr:
                parts.append("\n=== Errors ===")
                parts.append(output.stderr)

            if not output.stdout and not output.stderr:
                parts.append("\n(No new output)")

            return "\n".join(parts)

        except Exception as e:
            return f"Error retrieving shell output: {e}"

    async def kill_shell_handler(args: Dict[str, Any]) -> str:
        shell_id = args.get("shell_id")

        if not shell_id or not isinstance(shell_id, str) or not shell_id.strip():
            return "Error: shell_id must be a non-empty string."

        try:
            success = shell_manager.kill_shell(shell_id)

            if success:
                return f'Shell "{shell_id}" has been terminated.'
            else:
                available = shell_manager.list_shells()
                available_str = ", ".join(available) if available else "none"
                return f'Error: Shell "{shell_id}" not found.\n\nAvailable shells: {available_str}'

        except Exception as e:
            return f"Error killing shell: {e}"

    return [
        ToolDefinition(
            name="BashOutput",
            description="""Retrieves output from a running or completed background bash shell.

- Takes a shell_id parameter identifying the shell
- Always returns only new output since the last check
- Returns stdout and stderr output along with shell status
- Supports optional regex filtering to show only lines matching a pattern
- Use this tool when you need to monitor or check the output of a long-running shell
- Shell IDs can be found using the /tasks command""",
            parameters=JSONSchemaObject(
                properties={
                    "bash_id": JSONSchemaString(
                        description="The ID of the background shell to retrieve output from"
                    ),
                    "filter": JSONSchemaString(
                        description="Optional regular expression to filter the output lines. Only lines matching this regex will be included in the result."
                    ),
                },
                required=["bash_id"],
            ),
            handler=bash_output_handler,
        ),
        ToolDefinition(
            name="KillShell",
            description="""Kills a running background bash shell by its ID.

- Takes a shell_id parameter identifying the shell to kill
- Returns a success or failure status
- Use this tool when you need to terminate a long-running shell
- Shell IDs can be found using the /tasks command""",
            parameters=JSONSchemaObject(
                properties={
                    "shell_id": JSONSchemaString(
                        description="The ID of the background shell to kill"
                    ),
                },
                required=["shell_id"],
            ),
            handler=kill_shell_handler,
        ),
    ]


def start_background_shell(command: str, working_dir: str) -> str:
    """
    Start a background bash command.

    This should be integrated into the main Bash tool with a run_in_background parameter.

    Args:
        command: Command to execute
        working_dir: Working directory

    Returns:
        Shell ID
    """
    return shell_manager.create_shell(command, working_dir)


# ============================================================================
# Exports
# ============================================================================

__all__ = [
    "BackgroundShell",
    "BackgroundShellManager",
    "ShellOutput",
    "create_background_bash_tools",
    "start_background_shell",
    "shell_manager",
]
