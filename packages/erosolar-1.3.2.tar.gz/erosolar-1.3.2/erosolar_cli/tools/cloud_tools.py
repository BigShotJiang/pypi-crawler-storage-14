"""
Cloud Deployment Tools - Unified cloud CLI capabilities with auto-detection and auto-fix

Supports:
- Firebase (Hosting, Functions, Firestore, Storage, Auth)
- Aliyun/Alibaba Cloud (OSS, FC, ACR, etc.)
- AWS (S3, Lambda, CloudFront, etc.)
- GCP (Cloud Run, Storage, Functions)
- Azure (Static Web Apps, Functions, Blob Storage)
- Vercel, Netlify, Cloudflare Pages

Features:
- Automatic CLI detection and installation checking
- Authentication status verification
- Auto-fix for common issues
- AI-driven error resolution

Principal Investigator: Bo Shang
Framework: erosolar-cli
"""

from __future__ import annotations

import asyncio
import json
import os
import subprocess
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from ..core.unified.types import (
    JSONSchemaObject,
    JSONSchemaProperty,
    ToolDefinition,
)


# ============================================================================
# Types
# ============================================================================

@dataclass
class CloudProvider:
    """Cloud provider configuration."""
    id: str
    name: str
    cli_command: str
    version_flag: str
    install_command: str
    install_url: str
    login_command: str
    check_auth_command: str
    config_file: Optional[str] = None
    env_vars: List[str] = field(default_factory=list)


@dataclass
class CLIStatus:
    """Status of a cloud CLI."""
    installed: bool
    version: Optional[str] = None
    authenticated: bool = False
    auth_details: Optional[str] = None
    config_exists: bool = False
    errors: List[str] = field(default_factory=list)
    suggestions: List[str] = field(default_factory=list)


# ============================================================================
# Cloud Provider Configurations
# ============================================================================

CLOUD_PROVIDERS: Dict[str, CloudProvider] = {
    "firebase": CloudProvider(
        id="firebase",
        name="Firebase",
        cli_command="firebase",
        version_flag="--version",
        install_command="npm install -g firebase-tools",
        install_url="https://firebase.google.com/docs/cli",
        login_command="firebase login",
        check_auth_command="firebase projects:list",
        config_file="firebase.json",
        env_vars=["FIREBASE_TOKEN", "GOOGLE_APPLICATION_CREDENTIALS"],
    ),
    "aliyun": CloudProvider(
        id="aliyun",
        name="Alibaba Cloud (Aliyun)",
        cli_command="aliyun",
        version_flag="version",
        install_command="brew install aliyun-cli || curl -O https://aliyuncli.alicdn.com/aliyun-cli-linux-amd64-*.tgz",
        install_url="https://www.alibabacloud.com/help/doc-detail/139508.htm",
        login_command="aliyun configure",
        check_auth_command="aliyun ecs DescribeRegions",
        config_file="~/.aliyun/config.json",
        env_vars=["ALIBABA_CLOUD_ACCESS_KEY_ID", "ALIBABA_CLOUD_ACCESS_KEY_SECRET"],
    ),
    "aws": CloudProvider(
        id="aws",
        name="Amazon Web Services",
        cli_command="aws",
        version_flag="--version",
        install_command="brew install awscli || pip install awscli",
        install_url="https://docs.aws.amazon.com/cli/latest/userguide/getting-started-install.html",
        login_command="aws configure",
        check_auth_command="aws sts get-caller-identity",
        config_file="~/.aws/credentials",
        env_vars=["AWS_ACCESS_KEY_ID", "AWS_SECRET_ACCESS_KEY", "AWS_SESSION_TOKEN"],
    ),
    "gcloud": CloudProvider(
        id="gcloud",
        name="Google Cloud Platform",
        cli_command="gcloud",
        version_flag="--version",
        install_command="brew install --cask google-cloud-sdk",
        install_url="https://cloud.google.com/sdk/docs/install",
        login_command="gcloud auth login",
        check_auth_command="gcloud auth list",
        config_file="~/.config/gcloud/credentials.db",
        env_vars=["GOOGLE_APPLICATION_CREDENTIALS", "CLOUDSDK_CORE_PROJECT"],
    ),
    "azure": CloudProvider(
        id="azure",
        name="Microsoft Azure",
        cli_command="az",
        version_flag="--version",
        install_command="brew install azure-cli || curl -sL https://aka.ms/InstallAzureCLIDeb | sudo bash",
        install_url="https://docs.microsoft.com/en-us/cli/azure/install-azure-cli",
        login_command="az login",
        check_auth_command="az account show",
        config_file="~/.azure/accessTokens.json",
        env_vars=["AZURE_CLIENT_ID", "AZURE_CLIENT_SECRET", "AZURE_TENANT_ID"],
    ),
    "vercel": CloudProvider(
        id="vercel",
        name="Vercel",
        cli_command="vercel",
        version_flag="--version",
        install_command="npm install -g vercel",
        install_url="https://vercel.com/docs/cli",
        login_command="vercel login",
        check_auth_command="vercel whoami",
        env_vars=["VERCEL_TOKEN"],
    ),
    "netlify": CloudProvider(
        id="netlify",
        name="Netlify",
        cli_command="netlify",
        version_flag="--version",
        install_command="npm install -g netlify-cli",
        install_url="https://docs.netlify.com/cli/get-started/",
        login_command="netlify login",
        check_auth_command="netlify status",
        env_vars=["NETLIFY_AUTH_TOKEN"],
    ),
    "cloudflare": CloudProvider(
        id="cloudflare",
        name="Cloudflare",
        cli_command="wrangler",
        version_flag="--version",
        install_command="npm install -g wrangler",
        install_url="https://developers.cloudflare.com/workers/wrangler/install-and-update/",
        login_command="wrangler login",
        check_auth_command="wrangler whoami",
        env_vars=["CLOUDFLARE_API_TOKEN", "CLOUDFLARE_ACCOUNT_ID"],
    ),
    "fly": CloudProvider(
        id="fly",
        name="Fly.io",
        cli_command="flyctl",
        version_flag="version",
        install_command="brew install flyctl || curl -L https://fly.io/install.sh | sh",
        install_url="https://fly.io/docs/hands-on/install-flyctl/",
        login_command="flyctl auth login",
        check_auth_command="flyctl auth whoami",
        env_vars=["FLY_API_TOKEN"],
    ),
    "railway": CloudProvider(
        id="railway",
        name="Railway",
        cli_command="railway",
        version_flag="--version",
        install_command="npm install -g @railway/cli",
        install_url="https://docs.railway.app/develop/cli",
        login_command="railway login",
        check_auth_command="railway whoami",
        env_vars=["RAILWAY_TOKEN"],
    ),
    "supabase": CloudProvider(
        id="supabase",
        name="Supabase",
        cli_command="supabase",
        version_flag="--version",
        install_command="npm install -g supabase",
        install_url="https://supabase.com/docs/guides/cli",
        login_command="supabase login",
        check_auth_command="supabase projects list",
        env_vars=["SUPABASE_ACCESS_TOKEN"],
    ),
}


# ============================================================================
# Helper Functions
# ============================================================================

async def run_command(
    command: str,
    timeout: int = 30,
    cwd: Optional[str] = None,
) -> Tuple[str, str, int]:
    """
    Run a shell command asynchronously.

    Args:
        command: Command to run
        timeout: Timeout in seconds
        cwd: Working directory

    Returns:
        Tuple of (stdout, stderr, exit_code)
    """
    try:
        process = await asyncio.create_subprocess_shell(
            command,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
            cwd=cwd,
            env={**os.environ},
        )

        try:
            stdout, stderr = await asyncio.wait_for(
                process.communicate(),
                timeout=timeout,
            )
            return (
                stdout.decode("utf-8", errors="replace").strip(),
                stderr.decode("utf-8", errors="replace").strip(),
                process.returncode or 0,
            )
        except asyncio.TimeoutError:
            process.kill()
            return ("", "Command timed out", 1)

    except Exception as e:
        return ("", str(e), 1)


async def check_cli_installed(
    provider: CloudProvider,
) -> Tuple[bool, Optional[str], Optional[str]]:
    """
    Check if a CLI is installed.

    Returns:
        Tuple of (installed, version, error)
    """
    command = f"which {provider.cli_command} && {provider.cli_command} {provider.version_flag} 2>&1 | head -5"
    stdout, stderr, exit_code = await run_command(command)

    if exit_code == 0 and stdout:
        # Extract version from output
        import re
        version_match = re.search(r"(\d+\.\d+\.\d+[\w.-]*)", stdout)
        version = version_match.group(1) if version_match else stdout.split("\n")[-1]
        return (True, version, None)

    return (False, None, stderr or "CLI not found in PATH")


async def check_authentication(
    provider: CloudProvider,
) -> Tuple[bool, Optional[str], Optional[str]]:
    """
    Check authentication status.

    Returns:
        Tuple of (authenticated, details, error)
    """
    stdout, stderr, exit_code = await run_command(provider.check_auth_command, timeout=15)

    if exit_code == 0:
        return (True, stdout[:500], None)

    # Check for specific auth errors
    combined = (stdout + stderr).lower()
    auth_keywords = [
        "not logged in", "authentication", "credentials", "login",
        "token", "unauthorized"
    ]

    if any(kw in combined for kw in auth_keywords):
        return (False, None, f"Not authenticated. Run: {provider.login_command}")

    return (False, None, stderr or stdout)


async def check_config_file(provider: CloudProvider, working_dir: str) -> bool:
    """Check if config file exists."""
    if not provider.config_file:
        return True

    # Check project-level config
    project_config = Path(working_dir) / provider.config_file
    if project_config.exists():
        return True

    # Check user-level config (expand ~)
    if provider.config_file.startswith("~"):
        home_config = Path(provider.config_file).expanduser()
        if home_config.exists():
            return True

    return False


async def get_full_cli_status(provider_id: str, working_dir: str) -> CLIStatus:
    """Get full status of a cloud CLI."""
    provider = CLOUD_PROVIDERS.get(provider_id)
    if not provider:
        return CLIStatus(
            installed=False,
            authenticated=False,
            errors=[f"Unknown provider: {provider_id}"],
            suggestions=[f"Available providers: {', '.join(CLOUD_PROVIDERS.keys())}"],
        )

    status = CLIStatus(installed=False, authenticated=False)

    # Check installation
    installed, version, error = await check_cli_installed(provider)
    status.installed = installed
    status.version = version

    if not installed:
        status.errors.append(f"{provider.name} CLI not installed")
        status.suggestions.append(f"Install with: {provider.install_command}")
        status.suggestions.append(f"Documentation: {provider.install_url}")
        return status

    # Check authentication
    authenticated, details, auth_error = await check_authentication(provider)
    status.authenticated = authenticated
    status.auth_details = details

    if not authenticated:
        status.errors.append(auth_error or "Not authenticated")
        status.suggestions.append(f"Authenticate with: {provider.login_command}")
        if provider.env_vars:
            status.suggestions.append(f"Or set environment variables: {', '.join(provider.env_vars)}")

    # Check config file
    status.config_exists = await check_config_file(provider, working_dir)

    if not status.config_exists and provider.config_file:
        status.errors.append(f"Config file not found: {provider.config_file}")
        if "firebase.json" in provider.config_file:
            status.suggestions.append("Initialize project with: firebase init")
        elif "aliyun" in provider.config_file:
            status.suggestions.append("Configure with: aliyun configure")

    return status


async def auto_fix_issues(provider_id: str, working_dir: str) -> List[str]:
    """Attempt to auto-fix common issues."""
    fixes: List[str] = []
    provider = CLOUD_PROVIDERS.get(provider_id)

    if not provider:
        return ["Unknown provider"]

    status = await get_full_cli_status(provider_id, working_dir)

    # Try to install if not present
    if not status.installed:
        fixes.append(f"Attempting to install {provider.name} CLI...")

        # Try npm install first for npm-based CLIs
        if "npm install" in provider.install_command:
            stdout, stderr, exit_code = await run_command(provider.install_command, timeout=120)
            if exit_code == 0:
                fixes.append(f"Successfully installed {provider.name} CLI")
            else:
                fixes.append(f"Failed to install: {stderr}")
                fixes.append(f"Manual install: {provider.install_command}")
        else:
            fixes.append(f"Manual installation required: {provider.install_command}")
            fixes.append(f"Visit: {provider.install_url}")

    # Check for CI environment variables
    if not status.authenticated and provider.env_vars:
        has_env_auth = any(os.environ.get(v) for v in provider.env_vars)
        if has_env_auth:
            fixes.append(f"Environment credentials detected for {provider.name}")
        else:
            fixes.append(f"Authentication required. Run: {provider.login_command}")

            # For headless/CI environments
            if os.environ.get("CI") or not os.isatty(0):
                fixes.append(f"For CI/headless environments, set: {' or '.join(provider.env_vars)}")

    return fixes


def analyze_deployment_error(output: str, provider: CloudProvider) -> str:
    """Analyze deployment error and provide suggestions."""
    suggestions = ["Error Analysis:"]
    lower = output.lower()

    # Authentication issues
    if any(kw in lower for kw in ["auth", "login", "token", "credential"]):
        suggestions.append("• Authentication issue detected")
        suggestions.append(f"  Fix: {provider.login_command}")
        if provider.env_vars:
            suggestions.append(f"  CI: Set {provider.env_vars[0]}")

    # Permission issues
    if any(kw in lower for kw in ["permission", "denied", "forbidden", "access"]):
        suggestions.append("• Permission issue detected")
        suggestions.append("  Check your account permissions/roles")

    # Build issues
    if any(kw in lower for kw in ["build", "compile", "error", "failed"]):
        suggestions.append("• Build/compile error detected")
        suggestions.append("  Run your build command locally first")

    # Network issues
    if any(kw in lower for kw in ["network", "timeout", "econnrefused", "dns"]):
        suggestions.append("• Network connectivity issue")
        suggestions.append("  Check your internet connection")

    # Quota/limits
    if any(kw in lower for kw in ["quota", "limit", "exceeded", "billing"]):
        suggestions.append("• Quota/billing issue detected")
        suggestions.append("  Check your account billing status")

    # Config issues
    if any(kw in lower for kw in ["config", "not found", "missing"]):
        suggestions.append("• Configuration issue detected")
        suggestions.append("  Use cloud_init to create configuration")

    if len(suggestions) == 1:
        suggestions.append("• Unable to determine specific cause")
        suggestions.append("  Try running the command directly for more details")

    return "\n".join(suggestions)


def detect_project_type(directory: str) -> str:
    """Detect the project type from package.json or file structure."""
    package_json_path = Path(directory) / "package.json"

    if package_json_path.exists():
        try:
            with open(package_json_path) as f:
                pkg = json.load(f)
            deps = {**pkg.get("dependencies", {}), **pkg.get("devDependencies", {})}

            if "next" in deps:
                return "nextjs"
            if "@angular/core" in deps:
                return "angular"
            if "vue" in deps:
                return "vue"
            if "react" in deps:
                return "react"
            if "svelte" in deps:
                return "svelte"
            if any(fw in deps for fw in ["express", "fastify", "koa"]):
                return "node"
        except (json.JSONDecodeError, OSError):
            pass

    # Check for static site
    if (Path(directory) / "index.html").exists() or (Path(directory) / "public" / "index.html").exists():
        return "static"

    return "unknown"


def generate_firebase_config(project_type: str) -> str:
    """Generate Firebase configuration."""
    build_dirs = {
        "react": "build",
        "nextjs": "out",
        "angular": "dist",
        "vue": "dist",
        "svelte": "public",
        "static": "public",
        "unknown": "public",
    }

    build_dir = build_dirs.get(project_type, "public")

    config = {
        "hosting": {
            "public": build_dir,
            "ignore": ["firebase.json", "**/.*", "**/node_modules/**"],
            "rewrites": [{"source": "**", "destination": "/index.html"}],
        }
    }

    return f"""Create firebase.json:
```json
{json.dumps(config, indent=2)}
```

Then run: firebase init
Select Hosting and follow the prompts."""


def generate_vercel_config(project_type: str) -> str:
    """Generate Vercel configuration."""
    configs = {
        "nextjs": {},  # Vercel auto-detects Next.js
        "react": {"buildCommand": "npm run build", "outputDirectory": "build"},
        "vue": {"buildCommand": "npm run build", "outputDirectory": "dist"},
        "angular": {"buildCommand": "npm run build", "outputDirectory": "dist"},
        "static": {"buildCommand": None, "outputDirectory": "."},
        "unknown": {},
    }

    config = configs.get(project_type, {})

    return f"""Create vercel.json:
```json
{json.dumps(config, indent=2)}
```

Then run: vercel"""


def generate_netlify_config(project_type: str) -> str:
    """Generate Netlify configuration."""
    configs = {
        "react": {"command": "npm run build", "publish": "build"},
        "nextjs": {"command": "npm run build", "publish": ".next"},
        "vue": {"command": "npm run build", "publish": "dist"},
        "angular": {"command": "npm run build", "publish": "dist"},
        "static": {"command": "", "publish": "."},
        "unknown": {"command": "npm run build", "publish": "public"},
    }

    config = configs.get(project_type, {"command": "npm run build", "publish": "public"})

    return f"""Create netlify.toml:
```toml
[build]
  command = "{config['command']}"
  publish = "{config['publish']}"

[[redirects]]
  from = "/*"
  to = "/index.html"
  status = 200
```

Then run: netlify deploy"""


def generate_cloudflare_config(project_type: str) -> str:
    """Generate Cloudflare configuration."""
    today = datetime.now().strftime("%Y-%m-%d")

    return f"""Create wrangler.toml:
```toml
name = "my-{project_type}-app"
main = "src/index.js"
compatibility_date = "{today}"

[site]
bucket = "./dist"
```

For Pages, run: npx wrangler pages project create"""


# ============================================================================
# Tool Definitions
# ============================================================================

def create_cloud_tools(working_dir: Optional[str] = None) -> List[ToolDefinition]:
    """Create cloud deployment tools."""
    if working_dir is None:
        working_dir = os.getcwd()

    async def cloud_status_handler(args: Dict[str, Any]) -> str:
        providers_to_check = args.get("providers") or list(CLOUD_PROVIDERS.keys())
        results = ["Cloud CLI Status Report\n"]

        for provider_id in providers_to_check:
            provider = CLOUD_PROVIDERS.get(provider_id)
            if not provider:
                results.append(f"Unknown provider: {provider_id}")
                continue

            results.append(f"\n--- {provider.name} ({provider.cli_command}) ---")
            status = await get_full_cli_status(provider_id, working_dir)

            if status.installed:
                results.append(f"Installed: v{status.version}")
            else:
                results.append("Not installed")

            if status.installed:
                if status.authenticated:
                    results.append("Authenticated")
                    if status.auth_details:
                        results.append(f"   {status.auth_details.split(chr(10))[0]}")
                else:
                    results.append("Not authenticated")

                if status.config_exists:
                    results.append("Project config found")
                elif provider.config_file:
                    results.append(f"No project config ({provider.config_file})")

            if status.errors:
                results.append("\nIssues:")
                for err in status.errors:
                    results.append(f"  - {err}")

            if status.suggestions:
                results.append("\nSuggestions:")
                for sug in status.suggestions:
                    results.append(f"  - {sug}")

        return "\n".join(results)

    async def cloud_fix_handler(args: Dict[str, Any]) -> str:
        provider_id = (args.get("provider") or "").lower()

        if provider_id not in CLOUD_PROVIDERS:
            return f"Unknown provider: {provider_id}\n\nAvailable: {', '.join(CLOUD_PROVIDERS.keys())}"

        fixes = await auto_fix_issues(provider_id, working_dir)
        provider = CLOUD_PROVIDERS[provider_id]
        return f"Auto-Fix Results for {provider.name}\n\n" + "\n".join(fixes)

    async def firebase_deploy_handler(args: Dict[str, Any]) -> str:
        target = args.get("target") or "all"
        project = args.get("project")
        dry_run = args.get("dry_run", False)

        # Check status first
        status = await get_full_cli_status("firebase", working_dir)

        if not status.installed:
            return "Firebase CLI not installed.\n\nAuto-fix: Run `npm install -g firebase-tools`\n\nOr use cloud_fix tool with provider=\"firebase\""

        if not status.authenticated:
            return "Firebase not authenticated.\n\nFix options:\n1. Interactive: `firebase login`\n2. CI/Headless: `firebase login:ci` and set FIREBASE_TOKEN\n3. Service account: Set GOOGLE_APPLICATION_CREDENTIALS"

        if not status.config_exists:
            return f"No firebase.json found in {working_dir}.\n\nInitialize with: `firebase init`"

        # Build deploy command
        cmd = "firebase deploy"

        if target != "all":
            cmd += f" --only {target}"

        if project:
            cmd += f" --project {project}"

        if dry_run:
            cmd += " --dry-run"

        cmd += " 2>&1"

        stdout, stderr, exit_code = await run_command(f'cd "{working_dir}" && {cmd}', timeout=300)

        if exit_code == 0:
            return f"Firebase deployment successful!\n\n{stdout}"

        # Analyze error
        output = stdout + stderr
        fix = ""

        if "authentication" in output.lower() or "login" in output.lower():
            fix = "\n\nFix: Run `firebase login --reauth`"
        elif "permission" in output.lower() or "denied" in output.lower():
            fix = "\n\nFix: Check Firebase project permissions at https://console.firebase.google.com"
        elif "quota" in output.lower() or "limit" in output.lower():
            fix = "\n\nFix: Quota exceeded. Check billing at https://console.firebase.google.com/billing"
        elif "build" in output.lower() or "compile" in output.lower():
            fix = "\n\nFix: Build errors detected. Run your build command first (e.g., npm run build)"

        return f"Firebase deployment failed\n\n{output}{fix}"

    async def aliyun_deploy_handler(args: Dict[str, Any]) -> str:
        service = args.get("service")
        action = args.get("action")
        region = args.get("region")
        extra_args = args.get("args", "")

        # Check status
        status = await get_full_cli_status("aliyun", working_dir)

        if not status.installed:
            return "Aliyun CLI not installed.\n\nInstall:\n- macOS: brew install aliyun-cli\n- Linux: curl -O https://aliyuncli.alicdn.com/aliyun-cli-linux-latest-amd64.tgz\n\nDocs: https://www.alibabacloud.com/help/doc-detail/139508.htm"

        if not status.authenticated:
            return "Aliyun not configured.\n\nFix:\n1. Run: aliyun configure\n2. Enter your AccessKey ID and Secret\n3. Get keys at: https://ram.console.aliyun.com/manage/ak\n\nOr set environment variables:\n- ALIBABA_CLOUD_ACCESS_KEY_ID\n- ALIBABA_CLOUD_ACCESS_KEY_SECRET"

        # Build command
        cmd = f"aliyun {service} {action}"

        if region:
            cmd += f" --region {region}"

        if extra_args:
            cmd += f" {extra_args}"

        cmd += " 2>&1"

        stdout, stderr, exit_code = await run_command(cmd, timeout=120)

        if exit_code == 0:
            return f"Aliyun {service} {action} successful!\n\n{stdout}"

        # Error analysis
        output = stdout + stderr
        fix = ""

        if "InvalidAccessKeyId" in output or "SignatureDoesNotMatch" in output:
            fix = "\n\nFix: Invalid credentials. Run `aliyun configure` with correct AccessKey"
        elif "Forbidden" in output:
            fix = "\n\nFix: Permission denied. Check RAM policies at https://ram.console.aliyun.com"

        return f"Aliyun command failed\n\n{output}{fix}"

    async def cloud_deploy_handler(args: Dict[str, Any]) -> str:
        provider_id = (args.get("provider") or "").lower()
        command = args.get("command") or "deploy"
        auto_fix = args.get("auto_fix") != False

        provider = CLOUD_PROVIDERS.get(provider_id)
        if not provider:
            return f"Unknown provider: {provider_id}\n\nAvailable: {', '.join(CLOUD_PROVIDERS.keys())}"

        # Check and potentially fix status
        status = await get_full_cli_status(provider_id, working_dir)

        if not status.installed and auto_fix:
            fixes = await auto_fix_issues(provider_id, working_dir)
            status = await get_full_cli_status(provider_id, working_dir)

            if not status.installed:
                return f"{provider.name} CLI could not be installed.\n\n" + "\n".join(fixes)

        if not status.installed:
            return f"{provider.name} CLI not installed.\n\nInstall: {provider.install_command}\nDocs: {provider.install_url}"

        if not status.authenticated:
            env_info = " or ".join(provider.env_vars) if provider.env_vars else "appropriate credentials"
            return f"{provider.name} not authenticated.\n\nFix: {provider.login_command}\n\nFor CI, set: {env_info}"

        # Execute deployment
        cmd = f"{provider.cli_command} {command} 2>&1"
        stdout, stderr, exit_code = await run_command(f'cd "{working_dir}" && {cmd}', timeout=300)

        if exit_code == 0:
            return f"{provider.name} deployment successful!\n\n{stdout}"

        # Provide error context
        output = stdout + stderr
        error_analysis = analyze_deployment_error(output, provider)

        return f"{provider.name} deployment failed\n\n{output}\n\n{error_analysis}"

    async def cloud_init_handler(args: Dict[str, Any]) -> str:
        provider_id = (args.get("provider") or "").lower()
        project_type = args.get("project_type")

        # Detect project type if not specified
        detected_type = project_type or detect_project_type(working_dir)

        config_generators = {
            "firebase": lambda: generate_firebase_config(detected_type),
            "vercel": lambda: generate_vercel_config(detected_type),
            "netlify": lambda: generate_netlify_config(detected_type),
            "cloudflare": lambda: generate_cloudflare_config(detected_type),
        }

        if provider_id not in config_generators:
            return f"Initialization not supported for: {provider_id}\n\nSupported: firebase, vercel, netlify, cloudflare"

        config = config_generators[provider_id]()
        provider_name = CLOUD_PROVIDERS.get(provider_id, CloudProvider(id=provider_id, name=provider_id, cli_command="", version_flag="", install_command="", install_url="", login_command="", check_auth_command="")).name

        return f"{provider_name} Configuration\n\nProject type: {detected_type}\n\n{config}"

    async def cloud_login_handler(args: Dict[str, Any]) -> str:
        """Handle interactive cloud provider login."""
        provider_id = (args.get("provider") or "").lower()
        reauth = args.get("reauth", False)
        no_localhost = args.get("no_localhost", False)
        ci_mode = args.get("ci_mode", False)

        provider = CLOUD_PROVIDERS.get(provider_id)
        if not provider:
            return f"Unknown provider: {provider_id}\n\nAvailable: {', '.join(CLOUD_PROVIDERS.keys())}"

        # Check if CLI is installed
        installed, version, error = await check_cli_installed(provider)
        if not installed:
            return f"{provider.name} CLI not installed.\n\nInstall with: {provider.install_command}\nDocs: {provider.install_url}"

        # Build login command based on provider and options
        login_commands: Dict[str, Dict[str, str]] = {
            "firebase": {
                "standard": "firebase login",
                "reauth": "firebase login --reauth",
                "no_localhost": "firebase login --no-localhost",
                "ci": "firebase login:ci",
            },
            "gcloud": {
                "standard": "gcloud auth login",
                "reauth": "gcloud auth login --force",
                "no_localhost": "gcloud auth login --no-browser",
                "ci": "gcloud auth activate-service-account --key-file=",
            },
            "aws": {
                "standard": "aws configure",
                "reauth": "aws configure",
                "no_localhost": "aws configure",
                "ci": "aws configure set",
            },
            "azure": {
                "standard": "az login",
                "reauth": "az login",
                "no_localhost": "az login --use-device-code",
                "ci": "az login --service-principal",
            },
            "vercel": {
                "standard": "vercel login",
                "reauth": "vercel login",
                "no_localhost": "vercel login",
                "ci": "vercel login --token",
            },
            "netlify": {
                "standard": "netlify login",
                "reauth": "netlify login",
                "no_localhost": "netlify login",
                "ci": "netlify login --new",
            },
            "cloudflare": {
                "standard": "wrangler login",
                "reauth": "wrangler login",
                "no_localhost": "wrangler login",
                "ci": "wrangler login",
            },
            "aliyun": {
                "standard": "aliyun configure",
                "reauth": "aliyun configure",
                "no_localhost": "aliyun configure",
                "ci": "aliyun configure set",
            },
            "fly": {
                "standard": "flyctl auth login",
                "reauth": "flyctl auth login",
                "no_localhost": "flyctl auth login",
                "ci": "flyctl auth token",
            },
            "railway": {
                "standard": "railway login",
                "reauth": "railway login",
                "no_localhost": "railway login",
                "ci": "railway login --browserless",
            },
            "supabase": {
                "standard": "supabase login",
                "reauth": "supabase login",
                "no_localhost": "supabase login",
                "ci": "supabase login",
            },
        }

        provider_commands = login_commands.get(provider_id, {
            "standard": provider.login_command,
            "reauth": provider.login_command,
            "no_localhost": provider.login_command,
            "ci": provider.login_command,
        })

        # Select the appropriate command
        if ci_mode:
            cmd = provider_commands.get("ci", provider.login_command)
            return f"""CI/Headless Authentication for {provider.name}

For CI/CD environments, you need to set environment variables instead of interactive login.

Command (for generating token): {cmd}

Environment variables to set:
{chr(10).join(f'  - {var}' for var in provider.env_vars)}

For Firebase specifically:
1. Run locally: firebase login:ci
2. Copy the token
3. Set FIREBASE_TOKEN in your CI environment

For service accounts (Firebase/GCP):
1. Create a service account in Google Cloud Console
2. Download the JSON key file
3. Set GOOGLE_APPLICATION_CREDENTIALS=/path/to/key.json"""

        if reauth:
            cmd = provider_commands.get("reauth", provider.login_command)
        elif no_localhost:
            cmd = provider_commands.get("no_localhost", provider.login_command)
        else:
            cmd = provider_commands.get("standard", provider.login_command)

        # For interactive login, we use the 'script' command to provide a pseudo-TTY
        # This allows browser-based OAuth flows to work even in non-interactive environments
        import platform

        # Use 'script' to provide pseudo-TTY for the login command
        # This enables browser-based OAuth even in non-interactive shells
        system = platform.system()

        if system == "Darwin":
            # macOS: script -q /dev/null <command>
            wrapped_cmd = f'script -q /dev/null {cmd}'
        elif system == "Linux":
            # Linux: script -q -c "<command>" /dev/null
            wrapped_cmd = f'script -q -c "{cmd}" /dev/null'
        else:
            # Windows or other: try direct execution
            wrapped_cmd = cmd

        try:
            # Run with longer timeout for OAuth flow (user needs to complete in browser)
            stdout, stderr, exit_code = await run_command(wrapped_cmd, timeout=180)

            if exit_code == 0 or "Success" in stdout or "success" in stdout.lower():
                # Verify authentication succeeded
                authenticated, details, auth_error = await check_authentication(provider)
                if authenticated:
                    return f"""✓ {provider.name} login successful!

{details or 'Authentication verified.'}

You can now use {provider.name} deployment tools."""
                else:
                    # Sometimes the command succeeds but verification fails temporarily
                    return f"""Login command completed.

{stdout}

If authentication issues persist, try running: {cmd}"""
            else:
                # Check if it contains useful output (like a URL)
                combined = stdout + stderr
                if combined.strip():
                    return f"""{provider.name} login output:

{combined}

If login failed, try running manually: {cmd}"""
                else:
                    return f"""{provider.name} login failed (exit code: {exit_code})

Try:
1. {cmd} (run again)
2. {provider_commands.get('no_localhost', cmd)} (if browser issues)
3. Check your network connection
4. Visit: {provider.install_url}"""

        except Exception as e:
            return f"""Error during {provider.name} login: {str(e)}

Please run manually:
  {cmd}

Or for headless environments:
  Set environment variables: {', '.join(provider.env_vars)}"""

    return [
        ToolDefinition(
            name="cloud_status",
            description="""Check the status of cloud CLIs on this system.

Detects and reports on:
- CLI installation status and versions
- Authentication status
- Project configuration
- Required environment variables

Supports: Firebase, Aliyun, AWS, GCP, Azure, Vercel, Netlify, Cloudflare, Fly.io, Railway, Supabase

Use this before attempting any cloud deployment to ensure everything is properly configured.""",
            execute=cloud_status_handler,
            parameters=JSONSchemaObject(
                type="object",
                properties={
                    "providers": JSONSchemaProperty(
                        type="array",
                        items=JSONSchemaProperty(type="string"),
                        description="Specific providers to check (default: all). Options: firebase, aliyun, aws, gcloud, azure, vercel, netlify, cloudflare, fly, railway, supabase",
                    ),
                },
            ),
            category="cloud",
        ),
        ToolDefinition(
            name="cloud_fix",
            description="""Automatically fix cloud CLI issues.

Attempts to:
- Install missing CLIs (via npm/brew where possible)
- Detect environment credentials
- Provide step-by-step fix instructions for issues that can't be auto-fixed

Use this when cloud_status reports issues.""",
            execute=cloud_fix_handler,
            parameters=JSONSchemaObject(
                type="object",
                properties={
                    "provider": JSONSchemaProperty(
                        type="string",
                        description="The cloud provider to fix. Options: firebase, aliyun, aws, gcloud, azure, vercel, netlify, cloudflare, fly, railway, supabase"
                    ),
                },
                required=["provider"],
            ),
            category="cloud",
        ),
        ToolDefinition(
            name="firebase_deploy",
            description="""Deploy to Firebase (Hosting, Functions, Firestore rules, Storage rules).

Automatically:
- Checks Firebase CLI status
- Validates firebase.json configuration
- Handles authentication issues
- Provides detailed deployment logs

Supports:
- firebase deploy --only hosting
- firebase deploy --only functions
- firebase deploy --only firestore
- firebase deploy --only storage
- firebase deploy (all)""",
            execute=firebase_deploy_handler,
            parameters=JSONSchemaObject(
                type="object",
                properties={
                    "target": JSONSchemaProperty(
                        type="string",
                        description='Deployment target: "hosting", "functions", "firestore", "storage", "all" (default: all)'
                    ),
                    "project": JSONSchemaProperty(
                        type="string",
                        description="Firebase project ID (uses default if not specified)"
                    ),
                    "dry_run": JSONSchemaProperty(
                        type="boolean",
                        description="Preview deployment without actually deploying (default: false)"
                    ),
                },
            ),
            category="cloud",
        ),
        ToolDefinition(
            name="aliyun_deploy",
            description="""Deploy to Alibaba Cloud (Aliyun).

Supports:
- OSS (Object Storage Service) - static file hosting
- FC (Function Compute) - serverless functions
- ACR (Container Registry) - Docker images
- ECS (Elastic Compute Service) - VM management

Automatically handles authentication and common issues.""",
            execute=aliyun_deploy_handler,
            parameters=JSONSchemaObject(
                type="object",
                properties={
                    "service": JSONSchemaProperty(
                        type="string",
                        description='Service to deploy: "oss", "fc", "acr", "ecs"'
                    ),
                    "action": JSONSchemaProperty(
                        type="string",
                        description="Action to perform (service-specific)"
                    ),
                    "region": JSONSchemaProperty(
                        type="string",
                        description="Aliyun region (e.g., cn-hangzhou, cn-shanghai)"
                    ),
                    "args": JSONSchemaProperty(
                        type="string",
                        description="Additional CLI arguments"
                    ),
                },
                required=["service", "action"],
            ),
            category="cloud",
        ),
        ToolDefinition(
            name="cloud_deploy",
            description="""Universal cloud deployment command that works across providers.

Automatically:
- Detects project type and configuration
- Selects appropriate deployment target
- Handles provider-specific requirements
- Auto-fixes common issues

Supports deployment to:
- Firebase, Vercel, Netlify for web apps
- AWS Lambda, GCP Functions, Azure Functions for serverless
- Cloudflare Workers/Pages for edge deployments
- Fly.io, Railway for containers""",
            execute=cloud_deploy_handler,
            parameters=JSONSchemaObject(
                type="object",
                properties={
                    "provider": JSONSchemaProperty(
                        type="string",
                        description="Cloud provider: firebase, vercel, netlify, cloudflare, fly, railway, aws, gcloud, azure"
                    ),
                    "command": JSONSchemaProperty(
                        type="string",
                        description='Deployment command (e.g., "deploy", "deploy --prod")'
                    ),
                    "auto_fix": JSONSchemaProperty(
                        type="boolean",
                        description="Automatically attempt to fix issues (default: true)"
                    ),
                },
                required=["provider"],
            ),
            category="cloud",
        ),
        ToolDefinition(
            name="cloud_init",
            description="""Initialize a cloud project configuration.

Creates configuration files and sets up project structure for:
- Firebase (firebase.json, .firebaserc)
- Vercel (vercel.json)
- Netlify (netlify.toml)
- Cloudflare (wrangler.toml)

Auto-detects project type (React, Vue, Angular, Next.js, etc.) and configures appropriately.""",
            execute=cloud_init_handler,
            parameters=JSONSchemaObject(
                type="object",
                properties={
                    "provider": JSONSchemaProperty(
                        type="string",
                        description="Cloud provider to initialize: firebase, vercel, netlify, cloudflare"
                    ),
                    "project_type": JSONSchemaProperty(
                        type="string",
                        description="Project type: react, vue, angular, nextjs, static, node (auto-detected if not specified)"
                    ),
                },
                required=["provider"],
            ),
            category="cloud",
        ),
        ToolDefinition(
            name="cloud_login",
            description="""Interactive login for cloud providers.

Supports browser-based OAuth login for:
- Firebase (firebase login)
- Google Cloud (gcloud auth login)
- AWS (aws configure)
- Azure (az login)
- Vercel (vercel login)
- Netlify (netlify login)
- Cloudflare (wrangler login)
- Aliyun (aliyun configure)
- Fly.io (flyctl auth login)
- Railway (railway login)
- Supabase (supabase login)

Options:
- reauth: Force re-authentication even if already logged in
- no_localhost: Use device code flow (for remote/headless machines with browser access elsewhere)
- ci_mode: Get instructions for CI/CD environment setup

Use this when cloud_status shows authentication issues.""",
            execute=cloud_login_handler,
            parameters=JSONSchemaObject(
                type="object",
                properties={
                    "provider": JSONSchemaProperty(
                        type="string",
                        description="Cloud provider to login: firebase, gcloud, aws, azure, vercel, netlify, cloudflare, aliyun, fly, railway, supabase"
                    ),
                    "reauth": JSONSchemaProperty(
                        type="boolean",
                        description="Force re-authentication (default: false)"
                    ),
                    "no_localhost": JSONSchemaProperty(
                        type="boolean",
                        description="Use device code flow instead of localhost redirect (default: false)"
                    ),
                    "ci_mode": JSONSchemaProperty(
                        type="boolean",
                        description="Show CI/CD setup instructions instead of interactive login (default: false)"
                    ),
                },
                required=["provider"],
            ),
            category="cloud",
        ),
    ]


# ============================================================================
# Exports
# ============================================================================

__all__ = [
    "CloudProvider",
    "CLIStatus",
    "CLOUD_PROVIDERS",
    "create_cloud_tools",
    "get_full_cli_status",
    "auto_fix_issues",
    "check_cli_installed",
    "check_authentication",
]
