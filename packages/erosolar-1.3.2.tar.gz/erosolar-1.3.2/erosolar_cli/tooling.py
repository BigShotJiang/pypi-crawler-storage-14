from __future__ import annotations

import os
import re
import subprocess
from pathlib import Path
from typing import List

from langchain_core.tools import tool

from .core.ai_error_fixer import AIErrorFixer, analyze_and_fix_output


def build_tools(root: Path) -> list:
  safe_root = root.resolve()
  error_fixer = AIErrorFixer(working_dir=str(safe_root), auto_fix_enabled=True)

  @tool
  def read_file(path: str, start: int = 1, end: int = 200) -> str:
    """Read a file within the workspace, returning numbered lines."""
    full = (safe_root / path).resolve()
    if safe_root not in full.parents and full != safe_root:
      return f"error: path outside workspace: {path}"
    if not full.exists() or not full.is_file():
      return f"error: file not found: {path}"
    try:
      lines = full.read_text(encoding="utf-8").splitlines()
    except Exception as error:
      return f"error: failed to read {path}: {error}"
    start_idx = max(start - 1, 0)
    end_idx = min(end, len(lines))
    numbered = [f"{idx + 1}: {line}" for idx, line in enumerate(lines[start_idx:end_idx], start=start_idx)]
    return "\n".join(numbered) if numbered else "error: no content in range"

  @tool
  def read_files(paths: List[str]) -> str:
    """Read multiple files at once for efficiency. Use this instead of multiple read_file calls."""
    if not paths:
      return "error: paths list is empty"
    if len(paths) > 20:
      return f"error: too many files ({len(paths)}). Maximum is 20."

    results = []
    total_lines = 0

    for path in paths:
      full = (safe_root / path).resolve()
      if safe_root not in full.parents and full != safe_root:
        results.append(f"--- {path} ---\nerror: path outside workspace")
        continue
      if not full.exists() or not full.is_file():
        results.append(f"--- {path} ---\nerror: file not found")
        continue
      try:
        content = full.read_text(encoding="utf-8")
        lines = content.count('\n') + 1
        total_lines += lines
        results.append(f"--- {path} ({lines} lines) ---\n{content}")
      except Exception as error:
        results.append(f"--- {path} ---\nerror: {error}")

    header = f"Read {len(paths)} files ({total_lines} total lines)"
    return f"{header}\n\n" + "\n".join(results)

  @tool
  def list_dir(path: str = ".", recursive: bool = False, limit: int = 200) -> str:
    """List files/directories under a path."""
    target = (safe_root / path).resolve()
    if safe_root not in target.parents and target != safe_root:
      return f"error: path outside workspace: {path}"
    if not target.exists():
      return f"error: path not found: {path}"
    entries: List[str] = []
    if recursive:
      for item in target.rglob("*"):
        if len(entries) >= limit:
          break
        rel = item.relative_to(safe_root)
        entries.append(f"{rel}/" if item.is_dir() else str(rel))
    else:
      for item in sorted(target.iterdir()):
        if len(entries) >= limit:
          break
        rel = item.relative_to(safe_root)
        entries.append(f"{rel}/" if item.is_dir() else str(rel))
    return "\n".join(entries)

  @tool
  def search_text(pattern: str, path: str = ".", max_results: int = 50) -> str:
    """Regex search files under a path, returning matched lines."""
    target = (safe_root / path).resolve()
    if safe_root not in target.parents and target != safe_root:
      return f"error: path outside workspace: {path}"
    if not target.exists():
      return f"error: path not found: {path}"
    try:
      regex = re.compile(pattern, flags=re.MULTILINE)
    except re.error as error:
      return f"error: invalid regex: {error}"
    results: List[str] = []
    for file_path in target.rglob("*"):
      if len(results) >= max_results:
        break
      if not file_path.is_file():
        continue
      try:
        content = file_path.read_text(encoding="utf-8")
      except (UnicodeDecodeError, OSError):
        continue
      for match in regex.finditer(content):
        line_no = content.count("\n", 0, match.start()) + 1
        rel = file_path.relative_to(safe_root)
        snippet = content.splitlines()[line_no - 1]
        results.append(f"{rel}:{line_no}: {snippet}")
        if len(results) >= max_results:
          break
    return "\n".join(results) if results else "no matches"

  @tool
  def run_bash(command: str, timeout: int = 60) -> str:
    """Run a bash command inside the workspace. If command fails, provides AI analysis and fix suggestions."""
    try:
      result = subprocess.run(
        ["bash", "-lc", command],
        cwd=safe_root,
        env={**os.environ, "PYTHONUNBUFFERED": "1"},
        text=True,
        capture_output=True,
        timeout=timeout,
      )
    except subprocess.TimeoutExpired:
      return f"Command timed out after {timeout}s"
    except Exception as error:
      return f"error: failed to run command: {error}"

    output_parts = []
    if result.stdout:
      output_parts.append(result.stdout.strip())
    if result.stderr:
      output_parts.append(f"stderr:\n{result.stderr.strip()}")

    output_text = "\n".join(part for part in output_parts if part)

    # If command failed, analyze errors and suggest fixes
    if result.returncode != 0:
      output_parts.append(f"\n═══ FAILED ═══")
      output_parts.append(f"Command failed with exit code {result.returncode}")

      # AI error analysis
      combined_output = output_text
      errors = error_fixer.analyze_output(combined_output, command)

      if errors:
        output_parts.append("")
        output_parts.append("Failed checks:")
        for err in errors[:5]:  # First 5 errors
          output_parts.append(f"  - {err.message[:100]}")
          if err.locations:
            loc = err.locations[0]
            output_parts.append(f"    at {loc.file_path}:{loc.line_number or '?'}")

        # Add fix suggestions
        suggestions = error_fixer.get_fix_suggestions(errors)
        if suggestions and "Suggested fixes" in suggestions:
          output_parts.append("")
          output_parts.append("AI Fix Suggestions:")
          for line in suggestions.split('\n'):
            if line.strip().startswith(('1.', '2.', '3.', '-')):
              output_parts.append(f"  {line.strip()}")

    return "\n".join(part for part in output_parts if part) or "Command executed successfully (no output)"

  @tool
  def run_build(command: str = "") -> str:
    """Run project build with AI error analysis. Auto-detects build system if no command given."""
    import json

    # Auto-detect build command
    if not command:
      package_json = safe_root / "package.json"
      if package_json.exists():
        try:
          data = json.loads(package_json.read_text())
          scripts = data.get("scripts", {})
          if "build" in scripts:
            command = "npm run build"
          elif (safe_root / "tsconfig.json").exists():
            command = "npx tsc"
          else:
            command = "npm run build"
        except Exception:
          command = "npm run build"
      elif (safe_root / "Makefile").exists():
        command = "make"
      elif (safe_root / "Cargo.toml").exists():
        command = "cargo build"
      else:
        return "error: Could not detect build system. Please specify a command."

    return run_bash(command, timeout=120)

  @tool
  def run_tests(command: str = "") -> str:
    """Run project tests with AI error analysis. Auto-detects test framework if no command given."""
    import json

    # Auto-detect test command
    if not command:
      package_json = safe_root / "package.json"
      if package_json.exists():
        try:
          data = json.loads(package_json.read_text())
          scripts = data.get("scripts", {})
          if "test" in scripts:
            command = "npm test"
          else:
            command = "npm test"
        except Exception:
          command = "npm test"
      elif (safe_root / "pytest.ini").exists() or (safe_root / "pyproject.toml").exists():
        command = "pytest"
      elif (safe_root / "Cargo.toml").exists():
        command = "cargo test"
      else:
        return "error: Could not detect test framework. Please specify a command."

    return run_bash(command, timeout=300)

  return [read_file, read_files, list_dir, search_text, run_bash, run_build, run_tests]
