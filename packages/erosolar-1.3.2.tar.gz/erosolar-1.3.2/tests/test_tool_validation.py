"""
Comprehensive tests for tool validation and schema handling.

Tests cover:
- JSON Schema type definitions
- Tool argument validation
- Provider tool schema conversion
- Edge cases and unusual inputs
"""

import json
import pytest

from erosolar_cli.core.types import (
    JSONSchemaArray,
    JSONSchemaBoolean,
    JSONSchemaNumber,
    JSONSchemaObject,
    JSONSchemaString,
    ProviderToolDefinition,
)
from erosolar_cli.core.schema_validator import (
    ToolArgumentValidationError,
    has_argument,
    validate_tool_arguments,
)


class TestJSONSchemaTypes:
    """Test JSON Schema type definitions."""

    def test_string_schema_basic(self):
        """Test basic string schema creation."""
        schema = JSONSchemaString(
            type="string",
            description="A test string",
        )
        dumped = schema.model_dump(by_alias=True, exclude_none=True)

        assert dumped["type"] == "string"
        assert dumped["description"] == "A test string"
        assert "minLength" not in dumped  # Not set, should be excluded

    def test_string_schema_with_min_length(self):
        """Test string schema with minLength constraint."""
        schema = JSONSchemaString(
            type="string",
            description="A non-empty string",
            min_length=1,
        )
        dumped = schema.model_dump(by_alias=True, exclude_none=True)

        assert dumped["minLength"] == 1
        assert "min_length" not in dumped  # Should use alias

    def test_string_schema_with_max_length(self):
        """Test string schema with maxLength constraint."""
        schema = JSONSchemaString(
            type="string",
            max_length=100,
        )
        dumped = schema.model_dump(by_alias=True, exclude_none=True)

        assert dumped["maxLength"] == 100

    def test_string_schema_with_enum(self):
        """Test string schema with enum constraint."""
        schema = JSONSchemaString(
            type="string",
            description="File format",
            enum=["json", "yaml", "toml"],
        )
        dumped = schema.model_dump(by_alias=True, exclude_none=True)

        assert dumped["enum"] == ["json", "yaml", "toml"]

    def test_string_schema_with_pattern(self):
        """Test string schema with regex pattern."""
        schema = JSONSchemaString(
            type="string",
            description="Email address",
            pattern=r"^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$",
        )
        dumped = schema.model_dump(by_alias=True, exclude_none=True)

        assert "pattern" in dumped

    def test_number_schema_basic(self):
        """Test basic number schema."""
        schema = JSONSchemaNumber(
            type="number",
            description="A numeric value",
        )
        dumped = schema.model_dump(by_alias=True, exclude_none=True)

        assert dumped["type"] == "number"

    def test_number_schema_with_bounds(self):
        """Test number schema with min/max bounds."""
        schema = JSONSchemaNumber(
            type="number",
            minimum=0,
            maximum=100,
        )
        dumped = schema.model_dump(by_alias=True, exclude_none=True)

        assert dumped["minimum"] == 0
        assert dumped["maximum"] == 100

    def test_boolean_schema(self):
        """Test boolean schema."""
        schema = JSONSchemaBoolean(
            type="boolean",
            description="A flag",
        )
        dumped = schema.model_dump(by_alias=True, exclude_none=True)

        assert dumped["type"] == "boolean"

    def test_array_schema_basic(self):
        """Test basic array schema."""
        schema = JSONSchemaArray(
            type="array",
            description="A list of items",
        )
        dumped = schema.model_dump(by_alias=True, exclude_none=True)

        assert dumped["type"] == "array"

    def test_array_schema_with_items(self):
        """Test array schema with item type definition."""
        schema = JSONSchemaArray(
            type="array",
            items={"type": "string"},
            min_items=1,
            max_items=10,
        )
        dumped = schema.model_dump(by_alias=True, exclude_none=True)

        assert dumped["items"] == {"type": "string"}
        assert dumped["minItems"] == 1
        assert dumped["maxItems"] == 10

    def test_object_schema_basic(self):
        """Test basic object schema."""
        schema = JSONSchemaObject(
            type="object",
            properties={
                "name": JSONSchemaString(type="string", description="Name"),
            },
            required=["name"],
        )
        dumped = schema.model_dump(by_alias=True, exclude_none=True)

        assert dumped["type"] == "object"
        assert "name" in dumped["properties"]
        assert dumped["required"] == ["name"]
        assert dumped["additionalProperties"] == False

    def test_object_schema_additional_properties_true(self):
        """Test object schema allowing additional properties."""
        schema = JSONSchemaObject(
            type="object",
            properties={},
            additional_properties=True,
        )
        dumped = schema.model_dump(by_alias=True, exclude_none=True)

        assert dumped["additionalProperties"] == True

    def test_object_schema_snake_case_alias(self):
        """Test that snake_case input maps to camelCase output."""
        schema = JSONSchemaObject(
            type="object",
            properties={"foo": {"type": "string"}},
            additional_properties=False,  # snake_case input
        )
        dumped = schema.model_dump(by_alias=True, exclude_none=True)

        assert "additionalProperties" in dumped  # camelCase output
        assert "additional_properties" not in dumped


class TestToolArgumentValidation:
    """Test tool argument validation against schemas."""

    def test_valid_arguments(self):
        """Test validation passes for valid arguments."""
        schema = JSONSchemaObject(
            type="object",
            properties={
                "file_path": JSONSchemaString(type="string", description="Path"),
                "old_string": JSONSchemaString(type="string", description="Text to replace"),
                "new_string": JSONSchemaString(type="string", description="Replacement text"),
            },
            required=["file_path", "old_string", "new_string"],
            additional_properties=False,
        )
        args = {"file_path": "test.txt", "old_string": "", "new_string": "Hello World"}

        # Should not raise
        validate_tool_arguments("Edit", schema, args)

    def test_missing_required_property(self):
        """Test validation fails for missing required property."""
        schema = JSONSchemaObject(
            type="object",
            properties={
                "file_path": JSONSchemaString(type="string"),
                "old_string": JSONSchemaString(type="string"),
                "new_string": JSONSchemaString(type="string"),
            },
            required=["file_path", "old_string", "new_string"],
        )
        args = {"file_path": "test.txt", "old_string": ""}  # Missing new_string

        with pytest.raises(ToolArgumentValidationError) as exc_info:
            validate_tool_arguments("Edit", schema, args)

        assert 'Missing required property "new_string"' in str(exc_info.value)

    def test_empty_arguments(self):
        """Test validation fails for empty arguments when required."""
        schema = JSONSchemaObject(
            type="object",
            properties={
                "file_path": JSONSchemaString(type="string"),
                "old_string": JSONSchemaString(type="string"),
                "new_string": JSONSchemaString(type="string"),
            },
            required=["file_path", "old_string", "new_string"],
        )
        args = {}

        with pytest.raises(ToolArgumentValidationError) as exc_info:
            validate_tool_arguments("Edit", schema, args)

        error_msg = str(exc_info.value)
        assert 'Missing required property "file_path"' in error_msg
        assert 'Missing required property "new_string"' in error_msg

    def test_wrong_type_string(self):
        """Test validation fails for wrong type (expected string)."""
        schema = JSONSchemaObject(
            type="object",
            properties={
                "name": JSONSchemaString(type="string"),
            },
            required=["name"],
        )
        args = {"name": 123}  # Number instead of string

        with pytest.raises(ToolArgumentValidationError) as exc_info:
            validate_tool_arguments("test_tool", schema, args)

        assert 'must be a string' in str(exc_info.value)

    def test_wrong_type_number(self):
        """Test validation fails for wrong type (expected number)."""
        schema = JSONSchemaObject(
            type="object",
            properties={
                "count": JSONSchemaNumber(type="number"),
            },
            required=["count"],
        )
        args = {"count": "not a number"}

        with pytest.raises(ToolArgumentValidationError) as exc_info:
            validate_tool_arguments("test_tool", schema, args)

        assert 'must be a number' in str(exc_info.value)

    def test_wrong_type_boolean(self):
        """Test validation fails for wrong type (expected boolean)."""
        schema = JSONSchemaObject(
            type="object",
            properties={
                "enabled": JSONSchemaBoolean(type="boolean"),
            },
            required=["enabled"],
        )
        args = {"enabled": "yes"}  # String instead of boolean

        with pytest.raises(ToolArgumentValidationError) as exc_info:
            validate_tool_arguments("test_tool", schema, args)

        assert 'must be a boolean' in str(exc_info.value)

    def test_wrong_type_array(self):
        """Test validation fails for wrong type (expected array)."""
        schema = JSONSchemaObject(
            type="object",
            properties={
                "items": JSONSchemaArray(type="array"),
            },
            required=["items"],
        )
        args = {"items": "not an array"}

        with pytest.raises(ToolArgumentValidationError) as exc_info:
            validate_tool_arguments("test_tool", schema, args)

        assert 'must be an array' in str(exc_info.value)

    def test_enum_validation(self):
        """Test validation fails for value not in enum."""
        schema = JSONSchemaObject(
            type="object",
            properties={
                "format": JSONSchemaString(type="string", enum=["json", "yaml"]),
            },
            required=["format"],
        )
        args = {"format": "xml"}

        with pytest.raises(ToolArgumentValidationError) as exc_info:
            validate_tool_arguments("test_tool", schema, args)

        assert 'must be one of' in str(exc_info.value)

    def test_min_length_validation(self):
        """Test validation fails for string shorter than minLength."""
        schema = JSONSchemaObject(
            type="object",
            properties={
                "path": JSONSchemaString(type="string", min_length=1),
            },
            required=["path"],
        )
        args = {"path": ""}  # Empty string

        with pytest.raises(ToolArgumentValidationError) as exc_info:
            validate_tool_arguments("test_tool", schema, args)

        assert 'at least 1 character' in str(exc_info.value)

    def test_additional_properties_rejected(self):
        """Test validation fails for extra properties when not allowed."""
        schema = JSONSchemaObject(
            type="object",
            properties={
                "name": JSONSchemaString(type="string"),
            },
            additional_properties=False,
        )
        args = {"name": "test", "extra": "not allowed"}

        with pytest.raises(ToolArgumentValidationError) as exc_info:
            validate_tool_arguments("test_tool", schema, args)

        assert 'not allowed' in str(exc_info.value)

    def test_additional_properties_allowed(self):
        """Test validation passes for extra properties when allowed."""
        schema = JSONSchemaObject(
            type="object",
            properties={
                "name": JSONSchemaString(type="string"),
            },
            additional_properties=True,
        )
        args = {"name": "test", "extra": "allowed"}

        # Should not raise
        validate_tool_arguments("test_tool", schema, args)

    def test_none_value_for_required(self):
        """Test validation fails when required value is None."""
        schema = JSONSchemaObject(
            type="object",
            properties={
                "path": JSONSchemaString(type="string"),
            },
            required=["path"],
        )
        args = {"path": None}

        with pytest.raises(ToolArgumentValidationError) as exc_info:
            validate_tool_arguments("test_tool", schema, args)

        assert 'Missing required property' in str(exc_info.value)

    def test_optional_property(self):
        """Test validation passes when optional property is missing."""
        schema = JSONSchemaObject(
            type="object",
            properties={
                "path": JSONSchemaString(type="string"),
                "encoding": JSONSchemaString(type="string"),
            },
            required=["path"],  # encoding is optional
        )
        args = {"path": "test.txt"}

        # Should not raise
        validate_tool_arguments("test_tool", schema, args)


class TestHasArgument:
    """Test the has_argument helper function."""

    def test_present_value(self):
        """Test returns True for present value."""
        assert has_argument({"key": "value"}, "key") == True

    def test_absent_key(self):
        """Test returns False for absent key."""
        assert has_argument({"key": "value"}, "other") == False

    def test_none_value(self):
        """Test returns False for None value."""
        assert has_argument({"key": None}, "key") == False

    def test_empty_string(self):
        """Test returns True for empty string (it exists)."""
        assert has_argument({"key": ""}, "key") == True

    def test_zero_value(self):
        """Test returns True for zero value."""
        assert has_argument({"key": 0}, "key") == True

    def test_false_value(self):
        """Test returns True for False value."""
        assert has_argument({"key": False}, "key") == True

    def test_empty_list(self):
        """Test returns True for empty list."""
        assert has_argument({"key": []}, "key") == True


class TestProviderToolDefinition:
    """Test provider tool definition conversion."""

    def test_basic_tool_definition(self):
        """Test basic tool definition conversion."""
        params = JSONSchemaObject(
            type="object",
            properties={
                "path": JSONSchemaString(
                    type="string",
                    description="File path",
                    min_length=1,
                ),
            },
            required=["path"],
            additional_properties=False,
        )

        tool = ProviderToolDefinition(
            name="read_file",
            description="Read a file",
            parameters=params,
        )

        dumped = tool.model_dump(by_alias=True, exclude_none=True)
        params_dumped = tool.parameters.model_dump(by_alias=True, exclude_none=True)

        assert tool.name == "read_file"
        assert "minLength" in params_dumped["properties"]["path"]
        assert params_dumped["additionalProperties"] == False

    def test_edit_tool_schema(self):
        """Test Edit tool schema."""
        params = JSONSchemaObject(
            type="object",
            properties={
                "file_path": JSONSchemaString(
                    type="string",
                    description="The file path to modify or create",
                    min_length=1,
                ),
                "old_string": JSONSchemaString(
                    type="string",
                    description="The exact text to replace",
                ),
                "new_string": JSONSchemaString(
                    type="string",
                    description="The replacement text",
                ),
            },
            required=["file_path", "old_string", "new_string"],
            additional_properties=False,
        )

        dumped = params.model_dump(by_alias=True, exclude_none=True)

        # Verify the schema is correct
        assert dumped["type"] == "object"
        assert dumped["required"] == ["file_path", "old_string", "new_string"]
        assert dumped["additionalProperties"] == False
        assert dumped["properties"]["file_path"]["minLength"] == 1

        # Convert to JSON to verify it's serializable
        json_str = json.dumps(dumped)
        assert '"required": ["file_path", "old_string", "new_string"]' in json_str


class TestEdgeCases:
    """Test edge cases and unusual inputs."""

    def test_unicode_in_arguments(self):
        """Test handling of unicode characters in arguments."""
        schema = JSONSchemaObject(
            type="object",
            properties={
                "content": JSONSchemaString(type="string"),
            },
            required=["content"],
        )
        args = {"content": "Hello 世界 🌍 مرحبا"}

        # Should not raise
        validate_tool_arguments("test_tool", schema, args)

    def test_very_long_string(self):
        """Test handling of very long strings."""
        schema = JSONSchemaObject(
            type="object",
            properties={
                "content": JSONSchemaString(type="string"),
            },
            required=["content"],
        )
        args = {"content": "x" * 1000000}  # 1MB string

        # Should not raise
        validate_tool_arguments("test_tool", schema, args)

    def test_deeply_nested_args(self):
        """Test handling of deeply nested argument structures."""
        schema = JSONSchemaObject(
            type="object",
            properties={
                "data": JSONSchemaArray(type="array"),
            },
            required=["data"],
        )
        # Deeply nested array
        args = {"data": [[[[["nested"]]]]]}

        # Should not raise (array validation is shallow)
        validate_tool_arguments("test_tool", schema, args)

    def test_special_characters_in_property_names(self):
        """Test handling of special characters in property names."""
        schema = JSONSchemaObject(
            type="object",
            properties={
                "file-path": JSONSchemaString(type="string"),
                "content_type": JSONSchemaString(type="string"),
            },
            required=["file-path"],
        )
        args = {"file-path": "test.txt", "content_type": "text/plain"}

        # Should not raise
        validate_tool_arguments("test_tool", schema, args)

    def test_numeric_string_values(self):
        """Test that numeric strings are treated as strings."""
        schema = JSONSchemaObject(
            type="object",
            properties={
                "port": JSONSchemaString(type="string"),
            },
            required=["port"],
        )
        args = {"port": "8080"}  # String, not number

        # Should not raise
        validate_tool_arguments("test_tool", schema, args)

    def test_boolean_string_values(self):
        """Test that boolean strings are treated as strings."""
        schema = JSONSchemaObject(
            type="object",
            properties={
                "flag": JSONSchemaString(type="string"),
            },
            required=["flag"],
        )
        args = {"flag": "true"}  # String "true", not boolean True

        # Should not raise
        validate_tool_arguments("test_tool", schema, args)

    def test_empty_schema(self):
        """Test handling of empty schema."""
        schema = JSONSchemaObject(
            type="object",
            properties={},
            required=[],
        )
        args = {}

        # Should not raise
        validate_tool_arguments("test_tool", schema, args)

    def test_no_schema(self):
        """Test handling when no schema is provided."""
        # Should not raise
        validate_tool_arguments("test_tool", None, {"any": "args"})

    def test_nan_number_rejected(self):
        """Test that NaN is rejected as a number."""
        schema = JSONSchemaObject(
            type="object",
            properties={
                "value": JSONSchemaNumber(type="number"),
            },
            required=["value"],
        )
        args = {"value": float("nan")}

        with pytest.raises(ToolArgumentValidationError) as exc_info:
            validate_tool_arguments("test_tool", schema, args)

        assert 'must be a number' in str(exc_info.value)

    def test_infinity_as_number(self):
        """Test that infinity is accepted as a number."""
        schema = JSONSchemaObject(
            type="object",
            properties={
                "value": JSONSchemaNumber(type="number"),
            },
            required=["value"],
        )
        args = {"value": float("inf")}

        # Should not raise (infinity is a valid float)
        validate_tool_arguments("test_tool", schema, args)


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
