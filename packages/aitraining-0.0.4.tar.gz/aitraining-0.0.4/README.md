<p align="center">
  <img src="docs/images/terminal-wizard.png" alt="AITraining" width="700">
</p>

<p align="center">
  <a href="https://pypi.org/project/aitraining/"><img src="https://img.shields.io/pypi/v/aitraining.svg" alt="PyPI version"></a>
  <a href="https://pypi.org/project/aitraining/"><img src="https://img.shields.io/pypi/pyversions/aitraining.svg" alt="Python versions"></a>
  <a href="https://github.com/monostate/aitraining/blob/main/LICENSE"><img src="https://img.shields.io/badge/License-Apache%202.0-blue.svg" alt="License"></a>
</p>

<p align="center">
  <b>Train state-of-the-art ML models with minimal code</b>
</p>

---

AITraining is an advanced machine learning training platform built on top of [AutoTrain Advanced](https://github.com/huggingface/autotrain-advanced). It provides a streamlined interface for fine-tuning LLMs, vision models, and more.

## Features

- **LLM Fine-tuning**: SFT, DPO, ORPO, PPO, Reward modeling, Knowledge distillation
- **Vision**: Image classification, regression, object detection, VLM training
- **NLP**: Text classification, token classification, sequence-to-sequence, QA
- **Tabular**: Classification and regression on structured data
- **Interactive CLI**: Step-by-step wizard and TUI for configuration
- **Hyperparameter Sweeps**: Automated optimization with Optuna

## Installation

```bash
pip install aitraining
```

Requirements: Python >= 3.10, PyTorch

## Quick Start

### Interactive Wizard

```bash
aitraining wizard
```

### Config File

```bash
aitraining --config config.yaml
```

### Python API

```python
from autotrain.trainers.clm import train
from autotrain.trainers.clm.params import LLMTrainingParams

config = LLMTrainingParams(
    model="meta-llama/Llama-3.2-1B",
    data_path="your-dataset",
    trainer="sft",
    epochs=3,
    batch_size=4,
    lr=2e-5,
    peft=True,
)

train(config)
```

## Supported Tasks

| Task | Trainers | Status |
|------|----------|--------|
| LLM Fine-tuning | SFT, DPO, ORPO, PPO, Reward, Distillation | Stable |
| Text Classification | Single/Multi-label | Stable |
| Token Classification | NER, POS tagging | Stable |
| Sequence-to-Sequence | Translation, Summarization | Stable |
| Image Classification | Single/Multi-label | Stable |
| Object Detection | YOLO, DETR | Stable |
| VLM Training | Vision-Language Models | Beta |
| Tabular | XGBoost, sklearn | Stable |

## Comparison

| Feature | AutoTrain | AITraining | Tinker |
|---------|-----------|------------|--------|
| SFT/DPO/ORPO | Yes | Yes | Yes |
| PPO Training | Basic | Enhanced | Advanced |
| Reward Modeling | Yes | Yes | No |
| Knowledge Distillation | No | Yes | Yes |
| Hyperparameter Sweeps | No | Yes (Optuna) | Manual |
| Interactive CLI | No | Yes | No |
| TUI Interface | No | Yes | No |
| Vision Tasks | Yes | Yes | No |
| Tabular Tasks | Yes | Yes | No |
| Apple Silicon | Limited | Yes | No |
| Quantization (int4/int8) | Yes | Yes | No |

## Configuration Example

```yaml
task: llm-sft
base_model: meta-llama/Llama-3.2-1B
project_name: my-finetune

data:
  path: your-dataset
  train_split: train
  chat_template: tokenizer
  column_mapping:
    text_column: messages

params:
  epochs: 3
  batch_size: 4
  lr: 2e-5
  peft: true
  quantization: int4
  mixed_precision: bf16
```

## Documentation

- [Dataset Formats](docs/dataset_formats.md)
- [Trainer Reference](docs/trainers/README.md)
- [CLI Guide](docs/cli/README.md)
- [Python API](docs/api/PYTHON_API.md)

## License

Apache 2.0 - See [LICENSE](LICENSE) for details.

Based on [AutoTrain Advanced](https://github.com/huggingface/autotrain-advanced) by Hugging Face.

---

<p align="center">
  <a href="https://monostate.ai">Monostate AI</a>
</p>
