"""
Video Image Watermark MCP Server

A MCP server for adding image watermarks and overlays to videos.
"""

__version__ = "0.1.0"

from .main import main

__all__ = ["main"]
