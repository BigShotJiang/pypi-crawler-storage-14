from pathlib import Path

from setuptools import find_packages, setup

root = Path(__file__).parent
with open(root / 'requirements.txt', encoding='utf-8') as f:
    requirements = [line.strip() for line in f if line.strip() and not line.startswith('#')]

with open(root / 'README.md', encoding='utf-8') as f:
    long_description = f.read()

setup(
    name="XGM_devtest",
    version='6.0.2',
    author="baqis",
    author_email="baqis@baqis.ac.cn",
    url="https://gitee.com/",
    license="MIT",
    keywords="quantum lab",
    description="control, measure and visualization",
    long_description=long_description,
    long_description_content_type='text/markdown',
    packages=find_packages(),
    include_package_data=True,
    install_requires=requirements,
    python_requires='>=3.10',
    package_data={
        'systemq': [
            'remote.json',
            'remote_startup.bat',
            'remote/*',
            'startup/*',
            'xgkj/XGM/*.dll',
            'xgkj/XGM/mds24_driver20240601/*',
        ],
    },
    classifiers=[
        'Development Status :: 5 - Production/Stable',
        'Intended Audience :: Developers',
        'Intended Audience :: Science/Research',
        'License :: OSI Approved :: MIT License',
        'Natural Language :: Chinese (Simplified)',
        'Natural Language :: English',
        'Operating System :: Microsoft :: Windows',
        'Operating System :: POSIX :: Linux',
        'Operating System :: MacOS :: MacOS X',
        'Programming Language :: Python :: 3.10',
        'Programming Language :: Python :: 3.11',
        'Topic :: Scientific/Engineering :: Physics',
    ],
    project_urls={
        'Source': 'https://gitee.com',
        'Tracker': 'https://gitee.com',
    },
)

