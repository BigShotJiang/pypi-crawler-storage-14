"""Version information for the torch_concepts package."""
__version__ = '1.0.0a1'
