Distributions
=============

Probability distributions for modeling concepts and targets.

.. toctree::
   :maxdepth: 1

   distributions
