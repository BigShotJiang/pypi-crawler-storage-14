# tests/testalm.py
import numpy as np
import math
import pytest
from scipy.optimize import minimize


from eqc_models.algorithms.alm import(
    ALMAlgorithm,
    ALMConfig,
    ConstraintRegistry,
)


class _PolyShim:
    def __init__(self, coefficients, indices):
        self.coefficients = list(coefficients)
        self.indices = [tuple(ix) for ix in indices]


class InputPolyModel:
    """
    Miniimal input model for ALMAlgorithm.run().
    Only needs: n, upper_bound (optional lower_bound), and polynomial terms.
    The algorithm will internally build a new PolynomialModel for the merged problem.
    """
    def __init__(self, n, terms, lb=None, ub=None):
        self.n = int(n)
        self.polynomial = _PolyShim(coefficients=[w for (_, w) in terms], indices=[inds for (inds, _) in terms])
        self.lower_bound = None if lb is None else np.asarray(lb, float)
        self.upper_bound = None if ub is None else np.asarray(ub, float)


def terms_from_Qc(Q, c):
    """
    Convert Q, c into polynomial monomials compatible with ALMAlgorithm._alm_poly_value.
    We keep only linear/quadratic monomials in tests.
    """
    terms = []
    Qs = 0.5*(Q + Q.T)
    n = Q.shape[0]
    for i in range(n):
        if Qs[i, i] != 0.0:
            terms.append(((i + 1, i + 1), float(Qs[i, i])))
        for j in range(i+1, n):
            q = 2.0 * Qs[i, j]
            if q != 0.0:
                terms.append(((i + 1, j + 1), float(q)))
    for i in range(n):
        if c[i] != 0.0:
            terms.append(((0, i + 1), float(c[i])))
    return terms


def read_terms_from_poly_model(poly_model):
    """
    The inner 'core' solver receives the *internal* PolynomialModel instance built by ALMAlgorithm.
    It usually exposes `.polynomial`.
    """
    if hasattr(poly_model, "polynomial"):
        return poly_model.polynomial.indices, poly_model.polynomial.coefficients
    else:
        raise ValueError("poly_model must expose `.polynomial`")


def reconstruct_Qc_from_terms(terms, n):
    """
    Inverse of terms_from_Qc for (quadratic+linear)-only tests.
    """
    Q = np.zeros((n, n), dtype=float)
    c = np.zeros(n, dtype=float)
    for inds, coeff in zip(terms[0], terms[1]):
        if inds[0] == 0:
            # linear: ((0, i), w) means w * x_i
            c[inds[1] - 1] += coeff
        else:
            # quadratic: ((i, j), w) means w * x_i x_j with i,j >= 1
            i, j = inds
            if i == j:
                Q[i - 1, i - 1] += coeff
            else:
                # w * x_i x_j == (Q_ij + Q_ji) * x_i x_j with sum Q
                # We encode 2 * Q_ij in terms; thus split equally back:
                Q[i - 1, j - 1] += coeff / 2.0
                Q[j - 1, i - 1] += coeff / 2.0
    # Make sure it's symmetric
    Q = 0.5 * (Q + Q.T)
    return Q, c


class LBFGSBSolver:
    """
    A tiny 'core' solver usable with ALMAlgorithm. It rebuilds Q and c from the
    polynomial terms and solves min x^T Q x + c^T x with L-BFGS-B bounds (if
    present on the model).
    """
    @staticmethod
    def solve(poly_model):
        terms = read_terms_from_poly_model(poly_model)

        # Figure out n from bounds if available, else from max_index in terms
        ub = getattr(poly_model, "upper_bound", None)
        lb = getattr(poly_model, "lower_bound", None)
        if ub is not None:
            n = len(ub)
        elif lb is not None:
            n = len(lb)
        else:
            max_idx = 0
            for inds, _ in terms:
                for j in inds:
                    if j > 0:
                        max_idx = max(max_idx, j)
            n = max_idx

        Q, c = reconstruct_Qc_from_terms(terms, n)

        def f(x):
            return float(x @ (Q @ x) + c @ x)

        def g(x):
            return Q @ x + c

        # Build bounds if we have them
        bounds = None
        if lb is not None or ub is not None:
            if lb is None:
                lb = np.full(n, 0)
            if ub is None:
                ub = np.full(n, +np.inf)
            bounds = [(lb[i], ub[i]) for i in range(n)]

        # --- warm start retrieval ---
        x0 = getattr(poly_model, "initial_guess", None)
        if x0 is None:
            x0 = getattr(poly_model, "warm_start", None)
        if x0 is None:
            x0 = getattr(poly_model, "x0", None)
        if x0 is not None:
            x0 = np.asarray(x0, float).reshape(-1)
            if x0.size != n:
                # size mismatch safeguard; ignore invalid warm start
                x0 = None

        # --- default init if no warm start was provided ---
        if x0 is None:
            if lb is not None and ub is not None and np.all(np.isfinite(lb)) and np.all(np.isfinite(ub)):
                x0 = 0.5 * (np.asarray(lb, float) + np.asarray(ub, float))
            else:
                x0 = np.full(n, 1.0 / max(n, 1))  # simple feasible-ish default

        res = minimize(f, x0, jac=g, method="L-BFGS-B", bounds=bounds,
                       options={"maxiter": 2000, "ftol": 1e-12})
        return np.asarray(res.x, float)


def test_continuous_eq_ineq():
    # min 0.5 * ||x||^2 s.t. 1^t x = 1, x >= 0, and x1 + x2 - 0.8 <= 0
    n = 3
    Q = 0.5 * np.eye(n)
    c = np.zeros(n)
    terms = terms_from_Qc(Q, c)
    lb = np.zeros(n)
    ub = np.ones(n) * 10
    model = InputPolyModel(n, terms, lb=lb, ub=ub)

    reg = ConstraintRegistry()

    # equality: sum x = 1
    Aeq = np.ones((1, n))
    beq = np.array([1.0])
    reg.add_equality(
        fun=lambda x, A=Aeq, b=beq: A@x - b,
        jac=lambda x, A=Aeq: A,
        name="sum1"
    )

    # inequality: x1 + x2 <= 0.8   ->   (x1 + x2 - 0.8) <= 0
    Gineq = np.zeros((1, n))
    Gineq[0, 0] = 1.0
    Gineq[0, 1] = 1.0
    hineq = np.array([0.8])
    reg.add_inequality(
        fun=lambda x, G=Gineq, h=hineq: G@x - h,
        jac=lambda x, G=Gineq: G,
        name="cap12"
    )

    cfg = ALMConfig(max_outer=60, tol_h=1e-8, tol_g=1e-8, rho_h=10.0, rho_g=10.0)
    solver = LBFGSBSolver()

    x0 = np.ones(n) / n
    result = ALMAlgorithm.run(model, reg, solver, cfg=cfg, x0=x0, verbose=False)
    x = result["x"]

    # Feasibility checks
    assert np.isclose(np.sum(x), 1.0, atol=1e-5)
    assert x[0] + x[1] <= 0.8001
    assert np.all(x >= -1e-8)


def test_lifted_binary_block_sum_to_one():
    # One lifted binary block s in R^2 (sum-to-one), objective prefers s = [0, 1]
    n = 2
    # base objective: linear tilt c = [0, -1] (minimization pushes s2 up)
    Q = np.zeros((n, n))
    c = np.array([0.0, -1.0])  # favor second component
    terms = terms_from_Qc(Q, c)
    lb = np.zeros(n)
    ub = np.ones(n)
    model = InputPolyModel(n, terms, lb=lb, ub=ub)

    reg = ConstraintRegistry()
    levels = np.array([0.0, 1.0])
    reg.add_block(idx=range(0, 2), levels=levels, sum_to_one=True, one_hot=True)

    cfg = ALMConfig(max_outer=80, tol_h=1e-8, tol_g=1e-8, rho_h=20.0, rho_g=20.0)
    solver = LBFGSBSolver()

    x0 = np.ones(n) / n
    result = ALMAlgorithm.run(model, reg, solver, cfg=cfg, x0=x0, verbose=False)
    s = result["x"]

    assert np.isclose(s.sum(), 1.0, atol=1e-6)
    assert s[1] >= 0.9 and s[0] <= 0.1  # one-hot-ish towards index 1


def test_multi_level_block_and_decode():
    # One 3-level variable with levels [0, 2, 5]; objective favors level 5
    n = 3
    Q = np.zeros((n, n))
    c = np.array([0.0, 0.0, -2.0])
    terms = terms_from_Qc(Q, c)
    lb = np.zeros(n)
    ub = np.ones(n)
    model = InputPolyModel(n, terms, lb=lb, ub=ub)

    reg = ConstraintRegistry()
    levels = np.array([0.0, 2.0, 5.0])
    reg.add_block(idx=range(0, 3), levels=levels, sum_to_one=True, one_hot=True)

    cfg = ALMConfig(max_outer=80, tol_h=1e-8, tol_g=1e-8, rho_h=30.0, rho_g=30.0)
    solver = LBFGSBSolver()

    x0 = np.zeros(n)
    result = ALMAlgorithm.run(model, reg, solver, cfg=cfg, x0=x0, verbose=False)
    s = result["x"]
    decoded = result["decoded"]

    assert np.isclose(np.sum(s), 1.0, atol=1e-6)
    assert int(np.argmax(s)) == 2
    first_block_start = 0
    assert math.isclose(decoded[first_block_start], 5.0, rel_tol=1e-8, abs_tol=1e-8)


def test_block_onehot_and_sum1_pure_eq():
    # ---- define blocks directly (levels = allowed valuess for each discrete var) ----
    blocks = [
        np.array([0.0, 1.0]),  # Block 0: binary (size 2)
        np.array([0.0, 2.0, 5.0])  # Block 1: 3 -level (size 3)
    ]

    # build the flattened dimension and remember slices for each block
    n = sum(len(b) for b in blocks)
    slices = []
    start = 0
    for levels in blocks:
        k = len(levels)
        slices.append(slice(start, start + k))
        start += k

    # ---- objective: simple linear tilt to prefer a specific level in each block ----
    # choose the preferred index in each block (0-based)
    preferred = [1, 2]  # prefer index 1 in block 0; index 2 in block 1 (i.e., value 5.0)
    terms = []
    for (sl, pref) in zip(slices, preferred):
        terms.append(((0, sl.start + pref + 1), -1.0))  # linear term: smaller is better -> pushes that coord up

    lb = np.zeros(n)
    ub = np.ones(n)
    model = InputPolyModel(n, terms, lb=lb, ub=ub)

    # register each block; ALM will auto-install:
    #   - sum-to-one equality: sum(s_block) = 1
    #   - one-hot equality: s_block^T (11^T - I) s_block = 0
    reg = ConstraintRegistry()
    for sl, levels in zip(slices, blocks):
        reg.add_block(idx=range(sl.start, sl.stop), levels=levels, sum_to_one=True, one_hot=True)

    cfg = ALMConfig(max_outer=80, rho_h=50.0, rho_g=100.0, tol_h=1e-6, tol_g=1e-6)
    solver = LBFGSBSolver()

    x0 = np.zeros(n)
    for sl in slices:
        x0[sl] = 1.0 / (sl.stop - sl.start)

    res = ALMAlgorithm.run(model, reg, solver, cfg=cfg, x0=x0, verbose=False)
    x = res["x"]
    # each block sums to 1, and one-hot residual near 0
    for sl in slices:
        s = x[sl]
        assert np.isclose(np.sum(s), 1.0, atol=5e-6)
        M = np.ones((len(s), len(s))) - np.eye(len(s))
        assert abs(float(s @ (M @ s))) <= 9.5e-3


def test_multiplier_hist_traces_include_block_equalities():
    """
    Verifies that:
      1) ALM allocates multipliers for ALL equalities in 'full_eqs' = problem_eqs + block_eqs
         (block_eqs includes both sum-to-one and one-hot when requested).
      2) History traces (lam_eq_max_idx*, lam_eq_min_idx*, mu_ineq_*) exist and
         have lengths equal to the number of iterations taken.
    """
    n = 4
    # Build a simple objective that won't converge in a single step:
    # quadratic with small curvature + a tiny linear tilt
    Q = 0.25 * np.eye(n)
    c = np.array([0.0, 0.0, -0.1, 0.05])
    terms = terms_from_Qc(Q, c)
    lb = np.zeros(n)
    ub = np.ones(n)
    model = InputPolyModel(n, terms, lb=lb, ub=ub)

    # Registry:
    reg = ConstraintRegistry()

    # Problem equality: x0 + x1 = 0.9
    Aeq = np.zeros((1, n)); Aeq[0, 0] = 1.0; Aeq[0, 1] = 1.0
    beq = np.array([0.9])
    reg.add_equality(
        fun=lambda x, A=Aeq, b=beq: A @ x - b,
        jac=lambda x, A=Aeq: A,
        name="prob_sum01"
    )

    # Problem inequality: x2 + x3 <= 0.7
    Gineq = np.zeros((1, n))
    Gineq[0, 2] = 1.0
    Gineq[0, 3] = 1.0
    hineq = np.array([0.7])
    reg.add_inequality(
        fun=lambda x, G=Gineq, h=hineq: G @ x - h,
        jac=lambda x, G=Gineq: G,
        name="cap23"
    )

    # One lifted block over indices [0,1,2] with both sum-to-one and one-hot enabled.
    # This installs TWO block equalities in addition to the single problem equality above.
    reg.add_block(idx=[0, 1, 2], levels=np.array([0.0, 1.0, 2.0]), sum_to_one=True, one_hot=True)

    cfg = ALMConfig(
        max_outer=12,      # leave room for multiple updates
        rho_h=10.0,
        rho_g=10.0,
        tol_h=1e-10,       # tight so we get several iterations before convergence
        tol_g=1e-10,
        adapt=True
    )
    solver = LBFGSBSolver()

    out = ALMAlgorithm.run(model, reg, solver, cfg=cfg, verbose=False)
    hist = out["hist"]

    # Iteration count actually performed
    L = len(hist["eq_inf"])
    assert L >= 1

    # We expect 3 equality groups total:
    #   0: problem equality     (x0 + x1 = 0.9)
    #   1: block sum-to-one     (sum of block [0,1,2] == 1)
    #   2: block one-hot        (s^T(11^T - I)s == 0)
    for k in (0, 1, 2):
        assert f"lam_eq_max_idx{k}" in hist, f"Missing lam_eq_max_idx{k}"
        assert f"lam_eq_min_idx{k}" in hist, f"Missing lam_eq_min_idx{k}"
        assert len(hist[f"lam_eq_max_idx{k}"]) == L
        assert len(hist[f"lam_eq_min_idx{k}"]) == L

    # We expect 1 inequality group total (cap23)
    for k in (0,):
        assert f"mu_ineq_max_idx{k}" in hist, f"Missing mu_ineq_max_idx{k}"
        assert f"mu_ineq_min_idx{k}" in hist, f"Missing mu_ineq_min_idx{k}"
        assert len(hist[f"mu_ineq_max_idx{k}"]) == L
        assert len(hist[f"mu_ineq_min_idx{k}"]) == L

    # Sanity checks that traces are numeric and finite
    for k in (0, 1, 2):
        assert np.all(np.isfinite(hist[f"lam_eq_max_idx{k}"]))
        assert np.all(np.isfinite(hist[f"lam_eq_min_idx{k}"]))
    for k in (0,):
        assert np.all(np.isfinite(hist[f"mu_ineq_max_idx{k}"]))
        assert np.all(np.isfinite(hist[f"mu_ineq_min_idx{k}"]))

