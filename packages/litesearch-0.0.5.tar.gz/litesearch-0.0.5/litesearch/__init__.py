__version__ = "0.0.5"
from .postfix import usearch_fix
usearch_fix()
from .core import *
from .data import *
from .utils import *
