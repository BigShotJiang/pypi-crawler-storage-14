import socket
from termcolor import colored
from concurrent.futures import ProcessPoolExecutor

ports = {
    20: "FTP-Data",
    21: "FTP-Control",
    22: "SSH",
    23: "Telnet",
    25: "SMTP",
    43: "Whois",
    53: "DNS",
    70: "Gopher",
    79: "FINGER",
    80: "HTTP",
    110: "POP3",
    111: "RPC",
    113: "ident",
    115: "SFTP",
    135: "MSRPC",
    139: "NetBIOS-SSN",
    143: "IMAP",
    179: "BGP",
    194: "IRC",
    389: "LDAP",
    443: "HTTPS",
    445: "SMB",
    465: "SMTPS",
    587: "SMTP Submission",
    631: "IPP",
    636: "LDAPS",
    873: "RSYNC",
    993: "IMAPS",
    995: "POP3S",
    1080: "SOCKS",
    1433: "SQL Server",
    1521: "Oracle",
    2082: "CPanel",
    2083: "CPanel",
    2222: "SSH",
    3128: "HTTP Proxy",
    3306: "MySQL",
    3389: "RDP",
    5432: "PostgreSQL",
    5900: "VNC",
    8000: "HTTP Alternate",
    8080: "HTTP Alternate",
    8443: "HTTPS Alternate",
    8888: "HTTP Alternate",
    10000: "Webmin",
    27017: "MongoDB",
}


def is_port_open_threads(host, port):
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        try:
            s.settimeout(1)
            s.connect((host, port))
        except (OSError, socket.timeout):
            try:
                print(
                    f"Closed{colored('|X|','red')}-->{colored(ports.get(port),'light_red')}{colored(f'|{port}|','red')}"
                )
            except:
                print(f"Closed{colored('|X|','red')}-->{colored(f'|{port}|','red')}")
        else:
            print(
                f"Open{colored('|√|','green')}-->{colored(ports.get(port),'light_green')}{colored(f'|{port}|','green')}"
            )


def PoolProcessExecutor(host):
    with ProcessPoolExecutor(max_workers=None) as executor:
        try:
            for port in ports.keys():
                future = executor.submit(is_port_open_threads, host, port)

        except Exception as e:
            print(e)
