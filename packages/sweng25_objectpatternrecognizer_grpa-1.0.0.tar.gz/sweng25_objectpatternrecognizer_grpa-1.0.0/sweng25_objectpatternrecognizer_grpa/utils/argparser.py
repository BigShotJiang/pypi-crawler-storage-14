"""Module providing a class to parse the comand line arguments for the Object Pattern Recognizer.

Classes
-------
ArgParser
    Parse comand line arguments for the SWENG25 Object Pattern Recognizer.
"""

import argparse
import os


class ArgParser:
    """Command-line argument parser for the SWENG25 Object Pattern Recognizer.

    This class provides a structured interface for defining, validating, and parsing
    command-line arguments used to configure the Object Pattern Recognizer.

    The parser supports both image- and camera-based inputs, configurable paths for
    config file and test images, as well as a headless (no-GUI) execution mode.
    """

    def __init__(self) -> None:
        self.parser = argparse.ArgumentParser(
            description="SWENG25 Object Pattern Recognizer Grp A"
        )
        self._add_arguments()

    def _add_arguments(self) -> None:
        """Define and add all supported command-line arguments.

        Arguments
        ---------
        The following command-line arguments are available:
        --config_path : str, optional
            Path to the JSON configuration file.
            Must be a valid .json file.
        --source : {'camera', 'image'}, optional
            Input source type. Determines whether the program processes a live camera
            feed or a static image.
        --image_path : str, optional
            Path to the image file used when --source=image.
            Must be a valid .png, .jpg or .jpeg file.
        --camera_index : int, optional
            Index of the camera device used when --source=camera.
            Typically 0 for the default webcam.
        --headless : flag, optional
            If set, the application runs without GUI.

        Notes
        -----
        The method does not return any value but modifies the internal argparse
        instance by adding argument definitions.
        """
        self.parser.add_argument(
            "--config_path",
            type=lambda f: self._validate_file(f, (".json",)),
            default="./sweng25_objectpatternrecognizer_grpa/config/config.json",
            help="Path to config file (.json)",
        )
        self.parser.add_argument(
            "--source",
            type=str,
            choices=["camera", "image"],
            help="Input source: 'camera' or 'image'",
        )
        self.parser.add_argument(
            "--image_path",
            type=lambda f: self._validate_file(f, (".png", ".jpg", ".jpeg")),
            help="Path to image file if source='image' (.png/.jpg/.jpeg)",
        )
        self.parser.add_argument(
            "--camera_index",
            type=int,
            help="Camera index if source='camera'",
        )
        self.parser.add_argument(
            "--headless",
            action="store_true",
            help="Run without GUI (command line only)",
        )

    def parse(self) -> argparse.Namespace:
        """Parse and return CLI arguments"""
        return self.parser.parse_args()

    @staticmethod
    def _validate_file(file: str, extensions: tuple[str, ...]) -> str:
        if not os.path.exists(file):
            raise argparse.ArgumentTypeError(f"{file} does not exist.")
        if not file.lower().endswith(extensions):
            raise argparse.ArgumentTypeError(f"{file} must be one of {extensions}.")
        return file
