# iTAC REST API lib
[![made-with-python](https://img.shields.io/badge/Made%20with-Python-1f425f.svg)](https://www.python.org/)
[![MIT license](https://img.shields.io/badge/License-MIT-blue.svg)](https://lbesson.mit-license.org/)
[![Ask Me Anything !](https://img.shields.io/badge/Ask%20me-anything-1abc9c.svg)](https://github.com/ANUVAMAON)

RESTful API for iTAC.

*Use iTAC **OnlineHelp** for IMSAPi-Description.*

# How to use
**Fill station or user parameters**

**Station parameters**
```python
STATION_NUMBER = " "
STATION_PASSWORD = " "
```

**User parameters**
```python
USER = " "
PASSWORD = " "
```
**Client**
```python
CLIENT = " "
```
**Registration type**
```python
REG_TYPE = "S"
# S for station
# U for user
```

**System identification**
```python
SYS_ID = "TestApp"
```
# Example
```python
from itac_pylib.client import Client

BASE_URL = "https://api-url/mes/imsapi/rest/actions/"
STATION_NUMBER = "StationNumber"
STATION_PASSWORD = ""
USER = ""
PASSWORD = ""
CLIENT = "01"
REG_TYPE = "S"
SYS_ID = "TestApp"

itac = Client(
    base_url=BASE_URL,
    station_number=STATION_NUMBER,
    station_password=STATION_PASSWORD,
    client=CLIENT,
    reg_type=REG_TYPE,
    sys_id=SYS_ID,
)

test = itac.attribAppendAttributeValues(
    stationNumber="StationNumber",
    objectType=0,
    objectNumber="Test-0001",
    objectDetail="-1",
    bookDate="-1",
    allowOverWrite=0,
    attributeUploadValues=["", "", 0],
)
print("Return value: ", test.return_value)
print("attributeResultValues: ", test.attributeResultValues)
print("ERROR_CODE: ", test.attributeResultValues["ERROR_CODE"])
```

### Output
```bash
Return value:  5
attributeResultValues:  {'ATTRIBUTE_CODE': '', 'ATTRIBUTE_VALUE': '', 'ERROR_CODE': '-904'}
ERROR_CODE:  -904
```
