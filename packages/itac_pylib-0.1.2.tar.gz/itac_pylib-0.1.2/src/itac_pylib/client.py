import urllib3
from urllib3.util.ssl_ import create_urllib3_context
import json
from . import models
import datetime
import os


class Client:
    """
    A class to represent iTAC REST API.

    ***Check IMSApi documentation for Key Value Pairs***.
    """

    def __init__(
        self,
        base_url: str = "",
        station_number: str = "",
        station_password: str = "",
        user: str = "",
        password: str = "",
        client: str = "",
        reg_type: str = "",
        sys_id: str = "",
    ) -> None:
        if base_url == "":
            raise ValueError("BASE_URL cannot be empty!")
        if station_number == "" and user == "":
            raise ValueError("Either STATION_NUMBER or USER must be provided!")
        if client == "":
            raise ValueError("CLIENT cannot be empty!")
        if reg_type == "":
            raise ValueError("REG_TYPE should be specified! U = user, S = station")
        if sys_id == "":
            raise ValueError("SYS_ID cannot be empty!")

        self.base_url = base_url if base_url.endswith("/") else base_url + "/"
        self.headers = {"Content-Type": "application/json"}
        self.station_number = station_number
        self.station_password = station_password
        self.user = user
        self.password = password
        self.client = client
        self.reg_type = reg_type
        self.sys_id = sys_id
        self.session_context = self.session_context_from_file()
        self.last_return_value = None

    def post_request(self, api_call, payload) -> json:
        # create ssl context
        URL = self.base_url + api_call
        ctx = create_urllib3_context()
        ctx.load_default_certs()
        ctx.options |= 0x4  # ssl.OP_LEGACY_SERVER_CONNECT

        with urllib3.PoolManager(ssl_context=ctx) as http:
            req = http.request(
                "POST",
                url=URL,
                headers=self.headers,
                body=json.dumps(payload),
            )
            try:
                if req.status == 200:
                    return req.json()
                else:
                    print(
                        f"********post_request status: {req.status} > Check connection!********"
                    )
            except urllib3.exceptions.MaxRetryError:
                raise Exception(
                    f"Request to {self.base_url} failed after maximum retries."
                )

    def session_context_from_file(self) -> json:
        file_sc = ".sessionContext"
        if os.path.exists(file_sc):
            if os.path.getsize(file_sc) == 0:
                self.regLogin()
                return self.session_context_from_file()

            try:
                with open(file_sc, "r") as f:
                    self._ = json.load(f)
                    self.last_return_value = 0
                    return self._
            except json.JSONDecodeError as e:
                self.regLogin()
                return self.session_context_from_file()
        else:
            open(file_sc, "w").close()  # create sessionContext file if it doesn't exist
            self.regLogin()
            return self.session_context_from_file()

    # region ADVICE (advice notices)
    # region APS (work order planning)
    # region ATTRIB (attribute)
    def attribAppendAttributeValues(
        self,
        stationNumber: str,
        objectType: int,
        objectNumber: str,
        objectDetail: str,
        bookDate: datetime,
        allowOverWrite: int,
        attributeUploadKeys: list = [
            "ATTRIBUTE_CODE",
            "ATTRIBUTE_VALUE",
            "ERROR_CODE",
        ],  # default keys
        attributeUploadValues: list = [],
    ) -> models.attributeResultValues:
        """This function enables the assignment of attributes to a wide range of data
        objects. This allows individual information, such as a customer-specific material
        number and specific manufacturing characteristic, to be assigned to the data objects.
        Multiple, different attribute codes with the corresponding values can be assigned to
        a data object (successively); an attribute code may only be used once per data object,
        however. If an already existing attribute code is again assigned with this function,
        the original value can be overwritten if necessary (parameter allowOverWrite).
        Each attribute assignment is processed as a unique record in an array."""
        api_call = "attribAppendAttributeValues"
        payload = {
            "sessionContext": self.session_context,
            "stationNumber": stationNumber,
            "objectType": objectType,
            "objectNumber": objectNumber,
            "objectDetail": objectDetail,
            "bookDate": bookDate,
            "allowOverWrite": allowOverWrite,
            "attributeUploadKeys": attributeUploadKeys,
            "attributeUploadValues": attributeUploadValues,
        }
        response = self.post_request(api_call, payload)
        return_value = response["result"]["return_value"]
        if response["result"]["attributeResultValues"] is None:
            error_string = self.imsapiGetErrorText(return_value).errorString
            return models.attributeResultValues(
                f"{return_value}: {error_string}",
                attributeUploadKeys,
                [],
            )
        else:
            return models.attributeResultValues(
                return_value,
                attributeUploadKeys,
                response["result"]["attributeResultValues"],
            )

    def attribGetAttributeValues(
        self,
        stationNumber: str,
        objectType: int,
        objectNumber: str,
        objectDetail: str,
        attributeCodeArray: list,
        allMergeLevel: int,
        attributeResultKeys: list = ["ATTRIBUTE_CODE", "ATTRIBUTE_VALUE", "ERROR_CODE"],
    ) -> models.attributeResultValues:
        """This function returns the available attributes for a specified attribute
        category (e.g. for the data object "Serial numbers"). If a call is to be used
        to ascertain data for different attribute categories, the IMSApi function
        »attribGetAttributeValuesForObjectType« must be used."""
        api_call = "attribGetAttributeValues"
        payload = {
            "sessionContext": self.session_context,
            "stationNumber": stationNumber,
            "objectType": objectType,
            "objectNumber": objectNumber,
            "objectDetail": objectDetail,
            "attributeCodeArray": attributeCodeArray,
            "allMergeLevel": allMergeLevel,
            "attributeResultKeys": attributeResultKeys,
        }
        response = self.post_request(api_call, payload)
        return_value = response["result"]["return_value"]
        if response["result"]["attributeResultValues"] is None:
            error_string = self.imsapiGetErrorText(return_value).errorString
            return models.attributeResultValues(
                f"{return_value}: {error_string}",
                attributeResultKeys,
                [],
            )
        else:
            return models.attributeResultValues(
                return_value,
                attributeResultKeys,
                response["result"]["attributeResultValues"],
            )

    # endregion
    # region "BATCH" (bin)
    def batchAssignBatchNumberToWorkOrder(
        self,
        stationNumber: str,
        workOrderNumber: str,
        partNumber: str,
        bomVersion: str,
        bomIndex: str,
        bomVersionErp: str,
        processLayer: int,
        batchNumber: str,
        quantity: int,
        activateWorkOrder: int,
    ) -> models.Result_batchAssignBatchNumberToWorkOrder:
        """This function is used to create a material bin for "bin-based traceability" and assign it to a work order.
        It is also possible for material bins that are already known in the system to be used again; in this case,
        it is important that the bin is empty and not registered at any station (see the function »batchUnregisterBatch«).

        The part number of the unit which is to be manufactured with the work order is automatically assigned to the
        material bin. Here, the work order does not need to be active on the station. To determine the work order the bin
        should be assigned to, and to determine which tests are to be carried out for this, the input values partNumber (part),
        bomVersion (BOM version), bomIndex (BOM version index), bomVersionErp (BOM version in the ERP system)
        and workOrderNumber (work order) may be combined.

        If no work order is passed by means of workOrderNumber, a search for a suitable work order is carried out based on the
        passed product data (partNumber and bomVersion or bomIndex and bomVersionErp). If no work order is found, a new work order
        is created. It is a condition for automatic work order creation that the work plan uses work order type "01".
        """
        api_call = "batchAssignBatchNumberToWorkOrder"
        payload = {
            "sessionContext": self.session_context,
            "stationNumber": stationNumber,
            "workOrderNumber": workOrderNumber,
            "partNumber": partNumber,
            "bomVersion": bomVersion,
            "bomIndex": bomIndex,
            "bomVersionErp": bomVersionErp,
            "processLayer": processLayer,
            "batchNumber": batchNumber,
            "quantity": quantity,
            "activateWorkOrder": activateWorkOrder,
        }
        response = self.post_request(api_call, payload)
        return_value = response["result"]["return_value"]
        return models.Result_batchAssignBatchNumberToWorkOrder(return_value)

    def batchCompleteBatch(
        self,
        stationNumber: str,
        batchCompleteKeyValues: dict,
        batchFailUploadKeys: list,
        batchFailUploadValues: list,
    ) -> models.batchFailResultValues:

        batchCompleteKeyValues = [
            {"key": key, "value": value}
            for key, value in batchCompleteKeyValues.items()
        ]

        api_call = "batchCompleteBatch"
        payload = {
            "sessionContext": self.session_context,
            "stationNumber": stationNumber,
            "batchCompleteKeyValues": batchCompleteKeyValues,
            "batchFailUploadKeys": batchFailUploadKeys,
            "batchFailUploadValues": batchFailUploadValues,
        }
        response = self.post_request(api_call, payload)
        return_value = response["result"]["return_value"]
        return models.batchFailResultValues(
            return_value,
            batchFailUploadKeys,
            response["result"]["batchFailResultValues"],
        )

    # endregion

    # region "CONFIG" (configuration)
    # region "CRP" (continuous replenishment)
    # region "CUSTOM" (customer function)

    def customFunction(self, methodName: str, inArgs: list) -> models.customErrorString:
        """
        This function enables the grouping together of various IMSApi functions into a "customer method"; in this way, complex,
        customer-specific IMSApi workflows can be represented and called centrally via one method. The workflows can also include
        branches and conditions and are implemented using programming methods on the server side.
        """
        api_call = "customFunction"
        payload = {
            "sessionContext": self.session_context,
            "methodName": methodName,
            "inArgs": inArgs,
        }
        response = self.post_request(api_call, payload)
        return models.customErrorString(
            response["result"]["return_value"],
            response["result"]["outArgs"],
            response["result"]["customErrorString"],
        )

    # endregion

    # region "EDA" (external data)
    # region "EQU" (production means)
    # region "EXEC" (ruleset)
    # endregion
    # region "IMSAPI" (metadata)

    def imsapiGetErrorText(self, error_code: int) -> models.errorString:
        """Retrieve error text for a given error code."""
        api_call = "imsapiGetErrorText"
        payload = {"errorCode": error_code}

        response = self.post_request(api_call, payload)
        if response and response["result"]:
            return models.errorString(
                response["result"]["return_value"],
                error_code,
                response["result"]["errorString"],
            )
        else:
            raise Exception("Failed to retrieve error text.")

    # endregion

    # region "LOCK" (lock)
    # region "MDA" (document management)
    # region "MDATA" (master data)
    # region "MDC" (machine data collection)
    # region "ML" (material & logistics)
    # region "MSG" (iTAC.Messaging)
    # region "MSL" (Moisture Sensitivity Level)
    # region "PM" (production management)
    # region REG (registration)
    # TODO: regCheckLicense, regGetRegisteredUser, regRegisterUser, regUnregisterUser

    def regLogin(self) -> json:
        """Authenticate as a machine with user data."""
        api_call = "regLogin"
        payload = {
            "sessionValidationStruct": {
                "stationNumber": self.station_number,
                "stationPassword": self.station_password,
                "user": self.user,
                "password": self.password,
                "client": self.client,
                "registrationType": self.reg_type,
                "systemIdentifier": self.sys_id,
            }
        }

        response = self.post_request(api_call, payload)
        self.last_return_value = response["result"]["return_value"]
        print(self.last_return_value)

        with open(".sessionContext", "w") as f:
            json.dump(response["result"]["sessionContext"], f)

    def regLogout(self) -> json:
        """Deactivate the current session."""
        api_call = "regLogout"
        payload = {"sessionContext": self.session_context}

        response = self.post_request(api_call, payload)
        if response["result"] != None:
            print(f"Logout Response: {response}")
            return response["result"]
        else:
            raise Exception("Logout failed, no result returned.")
        # endregion

    # region "SETUP" (setup)
    # region "SHIP" (packing)
    # region "SMT" (placement data)
    # region "TR" (traceability)

    def trGetStationSetting(
        self, station_number: str = None, stationSettingResultKeys: list = []
    ) -> models.stationSettingResultValues:
        """
        This function queries the product version and the corresponding work order that are currently
        set at a station. If no work order is active, the function is finished with a corresponding error
        message.
        """
        api_call = "trGetStationSetting"
        payload = {
            "sessionContext": self.session_context,
            "stationNumber": station_number,
            "stationSettingResultKeys": stationSettingResultKeys,
        }
        response = self.post_request(api_call, payload)
        return_value = response["result"]["return_value"]
        return models.stationSettingResultValues(
            return_value,
            stationSettingResultKeys,
            response["result"]["stationSettingResultValues"],
        )

    # endregion
