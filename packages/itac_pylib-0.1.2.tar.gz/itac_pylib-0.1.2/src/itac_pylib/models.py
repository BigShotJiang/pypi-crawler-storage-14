from dataclasses import dataclass

__all__ = [
    "attributeResultValues",
    "Result_batchAssignBatchNumberToWorkOrder",
    "batchFailResultValues",
    "customErrorString",
    "errorString",
    "stationSettingResultValues",
]


# region ADVICE (advice notices)
# region APS (work order planning)
# region ATTRIB (attribute)
@dataclass
# attribGetAttributeValues, attribAppendAttributeValues
class attributeResultValues:
    def __init__(
        self,
        return_value: str,
        attributeResultKeys: list,
        attributeResultValues: list,
    ):
        self.return_value = return_value
        self.attributeResultValues = dict(
            zip(attributeResultKeys, attributeResultValues)
        )


# endregion
# region "BATCH" (bin)
@dataclass
# batchAssignBatchNumberToWorkOrder
class Result_batchAssignBatchNumberToWorkOrder:
    def __init__(self, return_value: int):
        self.return_value = return_value


@dataclass
# batchCompleteBatch
class batchFailResultValues:
    def __init__(
        self, return_value: int, batchFailResultKeys: list, batchFailResultValues: list
    ):
        self.return_value = return_value
        self.batchFailResultValues = dict(
            zip(batchFailResultKeys, batchFailResultValues)
        )


# endregion
# region "CONFIG" (configuration)
# region "CRP" (continuous replenishment)
# region "CUSTOM" (customer function)
@dataclass
# customFunction
class customErrorString:
    def __init__(self, return_value: int, outArgs: str, errorString: str):
        self.return_value = return_value
        self.outArgs = outArgs
        self.errorString = errorString


# endregion
# region "EDA" (external data)
# region "EQU" (production means)
# region "EXEC" (ruleset)
# endregion
# region "IMSAPI" (metadata)


@dataclass
# imsapiGetErrorText
class errorString:
    def __init__(self, return_value: int, errorCode: int, erorString: str):
        self.return_value = return_value
        self.errorCode = errorCode
        self.errorString = erorString


# endregion
# region "LOCK" (lock)
# region "MDA" (document management)
# region "MDATA" (master data)
# region "MDC" (machine data collection)
# region "ML" (material & logistics)
# region "MSG" (iTAC.Messaging)
# region "MSL" (Moisture Sensitivity Level)
# region "PM" (production management)
# region REG (registration)
# region "SETUP" (setup)
# region "SHIP" (packing)
# region "SMT" (placement data)
# region "TR" (traceability)


@dataclass
# trGetStationSetting
class stationSettingResultValues:
    def __init__(
        self,
        return_value: str,
        stationSettingResultKeys: list,
        stationSettingResultValues: list,
    ):
        self.return_value = return_value
        self.stationSettingResultValues = dict(
            zip(stationSettingResultKeys, stationSettingResultValues)
        )


# endregion
