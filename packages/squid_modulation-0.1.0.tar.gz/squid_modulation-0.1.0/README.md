もしnotebook上で表示したいなら
```python
from IPython.display import display,HTML
import squid-modulation as sqm

netlist = ModulationPattern("example.jsm")
html = netlist.to_html()
display(HTML(html))
```