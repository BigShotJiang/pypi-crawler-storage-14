import concurrent.futures as cf
import subprocess
import plotly.express as px
import polars as pl
import tempfile as tmp
import pathlib 
import uuid

import numpy as np

def test():
    netlist = ModulationPattern("example.jsm")
    with open("modulation_pattern.html","w") as f:
       f.write(netlist.to_html())

class ModulationPattern:
    input_file: str
    voltage_threshold: float 
    voltage_column: str 
    critical_current_column: str 
    control_current_range: float
    control_current_param_name: str 
    sample_amount: int 
    modulationData: pl.DataFrame
    def __init__(self,input_file:str,
                 voltage_threshold: float = 250e-6,
                 voltage_column: str = "V(1)",
                 critical_current_column: str = "I(IIN)",
                 control_current_range: float = 1300e-6,
                 control_current_param_name: str = "CTRL",
                 sample_amount: int = 200):
        self.input_file = input_file
        self.voltage_threshold = voltage_threshold
        self.voltage_column = voltage_column.upper()
        self.critical_current_column = critical_current_column.upper()
        self.control_current_range = control_current_range
        self.control_current_param_name = control_current_param_name.upper()
        self.sample_amount = sample_amount

    def run_simulation(self,control_current:float):
        stem = uuid.uuid4().hex
        tmp_dir = tmp.TemporaryDirectory()
        tmp_file = pathlib.Path(tmp_dir.name).joinpath(stem + ".jsm")
        flag = False
        with open(tmp_file,"w") as f:
            with open(self.input_file,"r") as original_file:
                for line in original_file:
                    if line.startswith(".PARAM CTRL"):
                        line = f".PARAM CTRL={control_current}\n"
                        f.write(line)
                        flag = True
                    else:
                        f.write(line)
            original_file.close()
        f.close()
        if not flag:
            raise ValueError("No '.PARAM CTRL' found in the input file.")
        output_path = pathlib.Path(tmp_dir.name).joinpath(stem + ".csv")
        command = ["josim-cli", tmp_file.as_posix(), "-o", output_path.as_posix()]
        subprocess.run(command,capture_output=True, text=True)
        return pl.read_csv(output_path)

    def get_critical_current(self,control_current:float):
        df = self.run_simulation(control_current)
        if self.voltage_column not in df.columns:
            raise ValueError(f"Column {self.voltage_column} not found in DataFrame\nAvailable columns: {df.columns}")
        if self.critical_current_column not in df.columns:
            raise ValueError(f"Column {self.critical_current_column} not found in DataFrame\nAvailable columns: {df.columns}")
        df_filtered = df.filter(pl.col(self.voltage_column) > self.voltage_threshold).head(1)
        critical_current = df_filtered.select(pl.col(self.critical_current_column)).to_series().to_list()
        return (control_current,critical_current)

    def get_modulation_pattern(self):
        with cf.ThreadPoolExecutor() as executor:
            futures = []
            for control_current in np.linspace(-1*self.control_current_range,self.control_current_range,self.sample_amount):
                futures.append(executor.submit(self.get_critical_current,control_current))
            results = [future.result() for future in cf.as_completed(futures)]
        control_currents = []
        critical_currents = []
        for result in results:
            control_currents.append(result[0])
            if len(result[1]) == 0:
                critical_currents.append(0.0)
            else:
                critical_currents.append(result[1][0])
        self.modulationData = pl.DataFrame({
            "Ictrl": control_currents,
            "Ic": critical_currents})
        
    def to_html(self):
        if not hasattr(self,"modulationData"):
            self.get_modulation_pattern()
        fig = px.scatter(self.modulationData.to_pandas(),x="Ictrl",y="Ic",title="Modulation Pattern",labels={"Ictrl":"Control Current [A]","Ic":"Critical Current [A]"},template="presentation")
        html = fig.to_html(include_plotlyjs='cdn')
        return html

    def save(self,filename:str):
        fig = px.line(self.modulationData.to_pandas(),x="Ictrl",y="Ic",title="Modulation Pattern",labels={"Ictrl":"Control Current [A]","Ic":"Critical Current [A]"})
        fig.write_image(filename)