from pathlib import Path

ENV_VAR_PREFIX = "BLURRY_"

SETTINGS_FILENAME = "blurry.toml"

CURR_DIR = Path.cwd()
