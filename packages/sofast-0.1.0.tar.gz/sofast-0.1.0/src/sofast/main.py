class SoFast:
    pass
