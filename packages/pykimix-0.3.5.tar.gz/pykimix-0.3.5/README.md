Hello everyone, welcome to the brainrot library, actually not, it is the pykimix library.

This library mixes pygame and kivy together. Yes boy.

Make sure to download it and have fun using it.