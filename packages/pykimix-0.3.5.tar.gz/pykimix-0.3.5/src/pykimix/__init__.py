import pykimix.mix
import pykimix.integration
import pykimix.pygame_surface

def patch_surface(surf):
    return surf

def patch_text(surf):
    import pygame
    return pygame.transform.flip(surf, False, True)

pykimix.pygame_surface._pykimix_patch_surface = patch_surface
pykimix.pygame_surface._pykimix_patch_text = patch_text