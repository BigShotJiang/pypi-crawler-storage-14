import kivy.clock as _kc

def start_loop(widget, update_func, fps=60):
    _kc.Clock.schedule_interval(lambda dt: update_func(dt), 1.0 / fps)