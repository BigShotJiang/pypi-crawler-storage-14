# Pyarmor 9.2.1 (trial), 000000, 2025-12-01T20:56:45.398584
from .pyarmor_runtime import __pyarmor__
