# radix

A radix is the base of a positional number system. It is the number of unique digits, including the digit zero, used to represent numbers. For example, base-10 (decimal) has radix 10. 
