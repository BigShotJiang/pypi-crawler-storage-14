# probability

Probability is a measure that quantifies the likelihood of elements in a [set](mathematics/set) or events, typically expressed as a number between 0 and 1. Probabilities indicate how likely different [objects](mathematics/object) or outcomes are to occur.
