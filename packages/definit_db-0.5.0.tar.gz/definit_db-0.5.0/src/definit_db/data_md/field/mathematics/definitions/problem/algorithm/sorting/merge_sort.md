# merge_sort

MergeSort is a [sorting](mathematics/sorting) [algorithm](mathematics/algorithm) that uses a [divide_and_conquer](mathematics/divide_and_conquer) approach: it divides the input [sequence](mathematics/sequence) into two halves, [recursively](mathematics/recursion) sorts each half, and then merges the two sorted halves into a single sorted [sequence](mathematics/sequence). 
