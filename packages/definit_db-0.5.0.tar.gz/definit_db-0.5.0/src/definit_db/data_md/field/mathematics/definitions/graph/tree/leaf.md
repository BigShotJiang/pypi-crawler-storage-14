# leaf

A [node](mathematics/node) in a tree that does not have any children (descendants).
