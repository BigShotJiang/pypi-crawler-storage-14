# graph_distance

A measure of the shortest [path](mathematics/path) between two [nodes](mathematics/node) in a [graph](mathematics/graph).
