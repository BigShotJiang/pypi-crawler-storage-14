# uniform_distribution

A uniform distribution is a [distribution](mathematics/distribution) in which all elements of a [set](mathematics/set) are assigned equal weight or probability, so each outcome is equally likely.
