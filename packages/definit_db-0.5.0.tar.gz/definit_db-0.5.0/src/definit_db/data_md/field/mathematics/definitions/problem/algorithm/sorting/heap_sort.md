# heap_sort

Heap Sort is a [sorting](mathematics/sorting) [algorithm](mathematics/algorithm) that builds a [heap tree](mathematics/heap_tree) from the elements of a [sequence](mathematics/sequence), and then repeatedly extracts the root (the maximum or minimum) and restores the heap until the entire [sequence](mathematics/sequence) is sorted.
