# relation

A relation (also called relationship) describes a connection or association between elements of a [set(s)](mathematics/set).
