# binary_tree

A [tree](mathematics/tree) in which each node has at most two children, referred to as the left child and the right child. A binary tree is a special case of a [k-ary tree](mathematics/k_ary_tree) where k = 2.
