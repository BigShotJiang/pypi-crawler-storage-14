# base_case

The simplest instance of the [problem](mathematics/problem), which can be [solved](mathematics/solution) directly without further [reduction](mathematics/reduction).
