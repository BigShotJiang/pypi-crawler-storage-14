# optimal_solution

A [solution](mathematics/solution) that is the best among all possible solutions, often in terms of a specific [criterion](mathematics/criterion).
