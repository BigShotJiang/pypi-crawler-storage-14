# graph

Graphs are used to model pairwise [relations](mathematics/relation) between objects. A graph is made up of [nodes](mathematics/node) and [edges](mathematics/edge). Graphs can be directed or undirected, weighted or unweighted, and can represent various types of relationships in different fields.
