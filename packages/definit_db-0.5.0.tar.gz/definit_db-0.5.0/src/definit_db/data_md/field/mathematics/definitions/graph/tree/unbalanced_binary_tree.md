# unbalanced_binary_tree

A [binary tree](mathematics/binary_tree) that does not satisfy the [balanced binary tree](mathematics/balanced_binary_tree) property. In an unbalanced binary tree, the depth of the two [subtrees](mathematics/subtree) of at least one [node](mathematics/node) differs by more than one.
