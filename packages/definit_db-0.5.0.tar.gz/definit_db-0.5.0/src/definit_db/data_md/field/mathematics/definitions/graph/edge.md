# edge

An edge is a directed or undirected connection between two [nodes](mathematics/node). It defines a [relationship](mathematics/relation) or link between them.
