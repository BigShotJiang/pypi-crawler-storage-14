# operation

A mathematical action performed on one or more [objects](mathematics/object) to produce a result.
