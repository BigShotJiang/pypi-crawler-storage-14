# adjacency_list

An adjacency list is a way of representing a [graph](mathematics/graph) as a collection of lists. Each list corresponds to a [node](mathematics/node) in the graph and contains a list of its adjacent nodes.
