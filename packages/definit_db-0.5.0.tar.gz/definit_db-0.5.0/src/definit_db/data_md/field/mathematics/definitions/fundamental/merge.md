# merge

Merge is an [operation](mathematics/operation) that combines two [sequences](mathematics/sequence) into a single sequence by interleaving their elements while preserving the order of each input sequence.
