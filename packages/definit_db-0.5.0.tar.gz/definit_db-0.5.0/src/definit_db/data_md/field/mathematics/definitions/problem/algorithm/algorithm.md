# algorithm

A [finite sequence](mathematics/finite_sequence) of mathematically rigorous [instructions](mathematics/instruction), typically used to solve a [problem](mathematics/problem).
