# bubble_sort

Bubble Sort is a [sorting](mathematics/sorting) [algorithm](mathematics/algorithm) that repeatedly
steps through a [sequence](mathematics/sequence), compares adjacent elements and swaps them if
they are in the wrong order. This process is repeated until the entire [sequence](mathematics/sequence) is sorted. Bubble sort is simple but generally inefficient for large inputs, as it repeatedly passes
over the sequence.
