# cycle

A cycle in a [graph](mathematics/graph) is a non-empty [path](mathematics/path) in which only the first and last [nodes](mathematics/node) are equal.
