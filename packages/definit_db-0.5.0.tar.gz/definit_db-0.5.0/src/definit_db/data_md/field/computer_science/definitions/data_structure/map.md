# map

A [data structure](computer_science/data_structure) that maps keys to values. Each key can map to at most one value. It models the mathematical function abstraction.
