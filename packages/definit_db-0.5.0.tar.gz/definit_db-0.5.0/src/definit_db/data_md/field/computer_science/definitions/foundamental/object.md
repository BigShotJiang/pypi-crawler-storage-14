# object

An object is an instance of a [data structure](computer_science/data_structure).
