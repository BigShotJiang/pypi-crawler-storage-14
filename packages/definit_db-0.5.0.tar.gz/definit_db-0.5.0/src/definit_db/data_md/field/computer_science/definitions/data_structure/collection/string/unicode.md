# unicode

A [character encoding](computer_science/character_encoding) standard that aims to provide a unique number for every character, regardless of the system.
