# vertex_coloring

A specific type of [graph coloring](computer_science/graph_coloring) where the goal is to ensure that no two connected [nodes](mathematics/node) share the same color.
