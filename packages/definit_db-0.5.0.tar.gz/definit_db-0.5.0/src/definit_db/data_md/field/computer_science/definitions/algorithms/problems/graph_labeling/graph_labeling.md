# graph_labeling

A [problem](mathematics/problem) of assigning [labels](mathematics/label), traditionally represented by [integers](computer_science/integer), to [edges](mathematics/edge) and/or [nodes](mathematics/node) of a [graph](mathematics/graph).
