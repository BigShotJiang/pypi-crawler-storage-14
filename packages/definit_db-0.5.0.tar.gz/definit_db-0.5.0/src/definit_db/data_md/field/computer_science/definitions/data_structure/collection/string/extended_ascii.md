# extended_ascii

An extension of the [ASCII](computer_science/ascii) [character encoding](computer_science/character_encoding) standard that uses 8 bits to represent 256 characters, including additional symbols and characters from various languages.
