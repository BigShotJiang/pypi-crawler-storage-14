# substring

A contiguous sequence of characters within a [string](computer_science/string). For instance, 'the best of' is a substring of 'It was the best of times'.
