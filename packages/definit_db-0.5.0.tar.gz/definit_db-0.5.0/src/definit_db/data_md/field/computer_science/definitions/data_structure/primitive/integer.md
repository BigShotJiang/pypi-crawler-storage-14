# integer

A [primitive data type](computer_science/primitive_data_type) that represents whole numbers. Integers can be positive, negative, or zero.
