# data_structure

A data structure is a way of organizing and storing [data](computer_science/data) so it can be accessed and modified efficiently. A data structure contains a value or group of values and the functions or operations that can be applied to the data.
