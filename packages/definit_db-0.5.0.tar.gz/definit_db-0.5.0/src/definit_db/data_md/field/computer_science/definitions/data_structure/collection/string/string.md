# string

A sequence of [decoded characters](computer_science/character_encoding), typically used to represent text. Strings can be of variable length and can contain letters, numbers, symbols, and whitespace.
