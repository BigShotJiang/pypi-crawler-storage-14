# bit

The bit (binary digit) is the smallest unit of data in computing, representing a binary state of either 0 or 1. Bits are the fundamental building blocks of [data](computer_science/data) and can convey basic forms of [information](mathematics/information) by representing true/false or data/off states.
