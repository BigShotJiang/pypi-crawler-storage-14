# boolean

Boolean (sometimes shortened to Bool) is a [primitive data type](computer_science/primitive_data_type) that has one of two possible values usually denoted true and false. Boolean is a [bit field](computer_science/bit_field) that stores a single [bit](computer_science/bit) of [information](mathematics/information).
