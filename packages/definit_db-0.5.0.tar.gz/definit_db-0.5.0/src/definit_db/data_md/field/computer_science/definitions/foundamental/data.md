# data

A collection of discrete or continuous values that convey [information](mathematics/information), describing the quantity, quality, fact, statistics, other basic units of meaning, or simply sequences of symbols that may be further interpreted formally.
