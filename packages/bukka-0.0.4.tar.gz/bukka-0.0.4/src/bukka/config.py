# These are the dependencies created in new bukka projects.
requirements= '''
scikit-learn
polars
pandas
seaborn
numpy
ipykernel
'''

import logging
LOG_LEVEL = logging.DEBUG