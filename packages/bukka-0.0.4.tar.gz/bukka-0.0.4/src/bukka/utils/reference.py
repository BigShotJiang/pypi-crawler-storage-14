requirements= '''
scikit-learn
polars
pandas
seaborn
numpy
ipykernel
'''