from .detection import Detection
from .detection_set import DetectionSet

__all__ = [
    "Detection",
    "DetectionSet",
]
