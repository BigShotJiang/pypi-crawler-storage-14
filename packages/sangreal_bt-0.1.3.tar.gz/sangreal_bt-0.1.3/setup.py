from setuptools import setup, find_packages
import os

# Read README file for long description
def read_readme():
    readme_path = os.path.join(os.path.dirname(__file__), 'README.md')
    if os.path.exists(readme_path):
        with open(readme_path, 'r', encoding='utf-8') as f:
            return f.read()
    return ""

# Read requirements from requirements.txt if exists
def read_requirements():
    requirements_path = os.path.join(os.path.dirname(__file__), 'requirements.txt')
    if os.path.exists(requirements_path):
        with open(requirements_path, 'r', encoding='utf-8') as f:
            return [line.strip() for line in f if line.strip() and not line.startswith('#')]
    return []

setup(
    name='sangreal_bt',
    version='0.1.3',
    description='A high-performance vector backtesting framework for quantitative strategies',
    long_description=read_readme(),
    long_description_content_type='text/markdown',

    # Core dependencies
    install_requires=[
        'attrs>=19.0.0',
        'pandas>=1.0.0',
        'numpy>=1.18.0',
        'addict>=2.2.0',
        'empyrical>=0.5.5',
        'python-dateutil>=2.8.0',
    ],

    # Optional dependencies for enhanced features
    extras_require={
        'dev': [
            'pytest>=6.0.0',
            'pytest-cov>=2.10.0',
            'black>=21.0.0',
            'flake8>=3.8.0',
            'mypy>=0.800',
        ],
        'plotting': [
            'matplotlib>=3.0.0',
            'seaborn>=0.11.0',
        ],
        'performance': [
            'numba>=0.50.0',
            'cython>=0.29.0',
        ],
    },

    # Python version requirement
    python_requires='>=3.6',

    # Package metadata
    author='liubola',
    author_email='lby3523@gmail.com',
    maintainer='liubola',
    maintainer_email='lby3523@gmail.com',
    license='GNU General Public License v3.0',

    # Package discovery
    packages=find_packages(exclude=['tests*', 'docs*', 'examples*']),
    include_package_data=True,
    package_data={
        'sangreal_bt': ['*.py'],
    },

    # URLs
    url='https://github.com/liubola/sangreal-bt',
    project_urls={
        'Bug Reports': 'https://github.com/liubola/sangreal-bt/issues',
        'Source': 'https://github.com/liubola/sangreal-bt',
        'Documentation': 'https://github.com/liubola/sangreal-bt/blob/main/README.md',
    },

    # Classification
    platforms=["all"],
    classifiers=[
        'Development Status :: 4 - Beta',
        'Intended Audience :: Developers',
        'Intended Audience :: Financial and Insurance Industry',
        'Intended Audience :: Science/Research',
        'Topic :: Office/Business :: Financial',
        'Topic :: Scientific/Engineering',
        'Topic :: Software Development :: Libraries :: Python Modules',

        'License :: OSI Approved :: GNU General Public License v3 (GPLv3)',

        'Programming Language :: Python :: 3',
        'Programming Language :: Python :: 3.6',
        'Programming Language :: Python :: 3.7',
        'Programming Language :: Python :: 3.8',
        'Programming Language :: Python :: 3.9',
        'Programming Language :: Python :: 3.10',
        'Programming Language :: Python :: 3.11',

        'Operating System :: OS Independent',
        'Operating System :: POSIX',
        'Operating System :: Microsoft :: Windows',
        'Operating System :: MacOS',

        'Natural Language :: Chinese (Simplified)',
        'Natural Language :: English',
    ],

    # Keywords
    keywords='backtesting, quantitative, finance, vector, trading, strategy, investment',

    # Entry points (if you want to add CLI commands)
    entry_points={
        'console_scripts': [
            # 'sangreal-bt=sangreal_bt.cli:main',  # Uncomment if you add CLI
        ],
    },
)