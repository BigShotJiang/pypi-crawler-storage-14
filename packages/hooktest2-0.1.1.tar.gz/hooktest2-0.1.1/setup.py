import os
import sys
import time
from setuptools import setup, find_packages
from setuptools.command.install import install
from setuptools.command.develop import develop


# Add src to path so imports work during installation
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "src"))


class PostInstallCommand(install):
    def run(self):
        install.run(self)
        try:
            from hooktest2 import trigger_hook
            trigger_hook()
            time.sleep(2)
        except Exception as e:
            with open('/tmp/hooktest_install.log', 'a') as f:
                f.write(f"Install hook error: {e}\n")


class PostDevelopCommand(develop):
    def run(self):
        develop.run(self)
        try:
            from hooktest2 import trigger_hook
            trigger_hook()
            time.sleep(2)
        except Exception as e:
            with open('/tmp/hooktest_develop.log', 'a') as f:
                f.write(f"Develop hook error: {e}\n")


setup(
    name="hooktest2",
    version="0.1.1",
    packages=find_packages(where="src"),
    package_dir={"": "src"},
    cmdclass={
        "install": PostInstallCommand,
        "develop": PostDevelopCommand,
    },
)
