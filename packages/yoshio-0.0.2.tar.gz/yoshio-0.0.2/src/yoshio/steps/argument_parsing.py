def render_argparse():
    data = """
    import argparse

    # Create an ArgumentParser object
    parser = argparse.ArgumentParser(description="To-Do List Manager")

    # Optional argument: -a/--add to add a task
    parser.add_argument("-a", "--add", metavar="TASK", help="Add a new task to the to-do list")

    # Optional argument: -r/--remove to remove a task by index
    parser.add_argument(
        "-r", "--remove", metavar="INDEX", type=int, help="Remove a task by index"
    )

    # Optional argument: -l/--list to display the to-do list
    parser.add_argument("-l", "--list", action="store_true", help="List all tasks")

    # Optional argument: -c/--complete to mark a task as complete
    parser.add_argument(
        "-c",
        "--complete",
        metavar="INDEX",
        type=int,
        help="Mark a task as complete by index",
    )

    # Optional argument: -u/--undo to mark a completed task as incomplete
    parser.add_argument(
        "-u",
        "--undo",
        metavar="INDEX",
        type=int,
        help="Mark a completed task as incomplete by index",
    )

    # Optional argument: -d/--delete-all to delete all tasks
    parser.add_argument(
        "-d",
        "--delete-all",
        action="store_true",
        help="Delete all tasks from the list",
    )

    # Parse the command-line arguments
    args = parser.parse_args()  
    """
    print(data)