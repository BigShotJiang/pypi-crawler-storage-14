VIMRC = """
" General settings
set number            " Show line numbers
set showcmd           " Show (partial) command in the last line of the screen
set cursorline        " Highlight the current line
set wildmenu          " Visual autocomplete for command menu
set lazyredraw        " Redraw only when necessary
set showmatch         " Highlight matching [{()}]

" Indentation
set autoindent        " Auto-indent new lines
set smartindent       " Smart autoindenting on new lines
set expandtab         " Use spaces instead of tabs
set shiftwidth=4      " Number of auto-indent spaces
set tabstop=4         " Number of spaces tabs count for

" Searching
set hlsearch          " Highlight search results
set incsearch         " Show partial matches for a search

" Visual
syntax on             " Enable syntax highlighting
set t_Co=256          " Support 256 colors
colorscheme desert    " Set colorscheme

" Backup files
set backup            " Enable backup files
set backupdir=~/.vim/backup//  " Directory for backup files
set directory=~/.vim/swp//     " Directory for swap files
set undodir=~/.vim/undo//      " Directory for undo files

" Plugins (if you have any)
" Plug 'tpope/vim-sensible'

"""

NVIMRC = """
require('packer').startup(function()
    use 'wbthomason/packer.nvim'
    use 'chriskempson/base16-vim'
	use {
	  'dense-analysis/ale',
	  config = function()
	    vim.g.ale_sign_column_always = 1
	    vim.g.ale_linters_explicit = 1
	    vim.g.ale_fix_on_save = 1
	    vim.g.ale_completion_enabled = 0
	  end
    }
    use {
      "nvim-treesitter/nvim-treesitter",
      run = ":TSUpdate",
      config = function()
        require("nvim-treesitter.configs").setup {
          ensure_installed = "all",
          highlight = { enable = true },
          indent = { enable = true },
        }
      end
    }

end)

-- Basic options
vim.o.clipboard = "unnamedplus"
vim.o.number = true
vim.o.relativenumber = false
vim.o.tabstop = 4
vim.o.shiftwidth = 4
vim.o.expandtab = true
vim.o.smartindent = true
vim.o.hidden = true
vim.o.wrap = false
vim.o.termguicolors = false
vim.o.cursorline = true
vim.o.updatetime = 250
vim.o.signcolumn = "yes"
vim.o.mouse = "a"

vim.g.ale_sign_error = "✘"
vim.g.ale_sign_warning = "⚠"
vim.g.ale_sign_column_always = 1
vim.g.ale_hover_to_floating_preview = 1
vim.g.ale_echo_cursor = 1
vim.g.ale_lint_on_text_changed = "always"
vim.g.ale_lint_on_insert_leave = 1

vim.cmd([[
  highlight ALEError cterm=underline gui=underline
  highlight ALEWarning cterm=underline gui=underline
]])

local theme = vim.env.BASE16_THEME

if theme then
  local target = "base16-" .. theme
  vim.g.base16colorspace = 256

  local ok = pcall(vim.cmd, "colorscheme " .. target)
  if not ok then
    vim.notify("Base16 theme not found: " .. target, vim.log.levels.WARN)
  end
end
"""
