import argparse

from yoshio.config.base import (render_shell, render_vimrc, render_shell,
                                    render_tmux, render_nvim_init, render_tmux,
                                    render_zshrc, render_bashrc)
from yoshio.steps.ssh import authorized_keys
from yoshio.steps.argument_parsing import render_argparse
from yoshio.tools.recommended import display_recs

from typing import Tuple, Any
from argparse import Namespace, ArgumentParser

# Global version variable
__VERSION__ = "1.0"


def parse_args() -> Tuple[Namespace, ArgumentParser]:
    global __VERSION__
    parser = argparse.ArgumentParser(description="Render configurations for different tools.")

    group_tools = parser.add_argument_group('Tools')
    group_tools.add_argument("--vim", nargs='?', const=True, default=None, metavar="OUTFILE", help="Render Vim configuration")
    group_tools.add_argument("--nvim", nargs='?', const=True, default=None, metavar="OUTFILE", help="Render Vim configuration")
    group_tools.add_argument("--zsh", nargs='?', const=True, default=None, metavar="OUTFILE", help="Render Zsh configuration")
    group_tools.add_argument("--bash", nargs='?', const=True, default=None, metavar="OUTFILE", help="Render Bash configuration")
    group_tools.add_argument("--tmux", nargs='?', const=True, default=None, metavar="OUTFILE", help="Render Tmux configuration")
    group_tools.add_argument("--ssh-key", action="store_true", help="Display steps to skip password during SSH.")
    group_tools.add_argument("--argparse", action="store_true", help="Display steps to skip password during SSH.")
    group_tools.add_argument("--recommended", action="store_true", help="List neat tools to download from apt, yum, brew and pip.")


    group_config = parser.add_argument_group('Configuration')
    group_config.add_argument("-f", "--file", default=None, help="File used for output")
    group_config.add_argument("--version", action="version", version=f"%(prog)s {__VERSION__}")

    args = parser.parse_args()
    return args, parser

def main():

    # Parse arguments
    args, parser = parse_args()

    # Toggle which output to generate, or print help
    selection = False
    if args.vim is not None:
        if isinstance(args.vim, str):
            render_vimrc(args.vim)
        else:
            render_vimrc()
        selection = True
    if args.nvim is not None:
        if isinstance(args.nvim, str):
            render_nvim_init(args.nvim)
        else:
            render_nvim_init()
        selection = True
    if args.zsh:
        if isinstance(args.zsh, str):
            render_zshrc(args.zsh)
        else:
            render_zshrc()
        selection = True
    if args.bash:
        if isinstance(args.bash, str):
            render_bashrc(args.bash)
        else:
            render_bashrc()
        selection = True
    if args.tmux:
        if isinstance(args.tmux, str):
            render_tmux(args.tmux)
        else:
            render_tmux()
        selection = True
    if args.ssh_key:
        authorized_keys(args.file)
        selection = True
    if args.recommended:
        display_recs(args.file)
        selection = True
    if args.argparse:
        render_argparse()
        selection = True

    if not selection:
        parser.print_help()

if __name__ == "__main__":
    main()
