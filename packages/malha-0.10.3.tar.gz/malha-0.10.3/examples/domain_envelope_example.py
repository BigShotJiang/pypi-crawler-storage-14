"""
Exemplo: Padrão Domain Envelope na Malha
=========================================

Este exemplo demonstra como usar o novo padrão Domain Envelope
para criar recursos de domínio ricos que são automaticamente
mapeados para a tabela física do registro.
"""

import asyncio
from datetime import datetime
from typing import List, Optional

from pydantic import EmailStr, Field, field_validator
from registro import DomainResource, register

# ============================================================================
# 1. Definir Recursos de Domínio
# ============================================================================


class User(DomainResource):
    """Recurso de domínio para usuários.
    
    Herda de DomainResource, que já inclui:
    - rid: str (Resource ID)
    - version: int (Optimistic Locking)
    - created_at: datetime
    - updated_at: datetime
    - valid_from/valid_to: datetime (Bitemporal)
    """
    
    name: str = Field(..., min_length=1, max_length=100)
    email: EmailStr
    age: Optional[int] = Field(None, ge=0, le=150)
    tags: List[str] = Field(default_factory=list)
    metadata: dict = Field(default_factory=dict)
    
    @field_validator('name')
    @classmethod
    def validate_name(cls, v: str) -> str:
        """Validação customizada de domínio."""
        if not v.strip():
            raise ValueError("Name cannot be empty")
        return v.strip()
    
    def is_adult(self) -> bool:
        """Lógica de negócio no domínio."""
        return self.age is not None and self.age >= 18


class Product(DomainResource):
    """Recurso de domínio para produtos."""
    
    name: str
    price: float = Field(..., gt=0)
    stock: int = Field(default=0, ge=0)
    category: str
    supplier_rid: Optional[str] = None  # Relacionamento
    
    @property
    def is_available(self) -> bool:
        """Propriedade computada."""
        return self.stock > 0
    
    def apply_discount(self, percentage: float) -> float:
        """Método de negócio."""
        if not 0 <= percentage <= 100:
            raise ValueError("Discount must be between 0 and 100")
        return self.price * (1 - percentage / 100)


# ============================================================================
# 2. Registrar Recursos no Global Registry
# ============================================================================

# Isso permite que o outbox processor e synapse encontrem as classes
register("User", User)
register("Product", Product)


# ============================================================================
# 3. Usar com a Malha
# ============================================================================

async def main():
    """Exemplo de uso do padrão Domain Envelope."""
    from malha import UnifiedDataManager, AsyncSQLAlchemyDriver, KuzuActor, DuckDBDriver
    
    # Configurar drivers
    sql_driver = AsyncSQLAlchemyDriver("sqlite+aiosqlite:///./example.db")
    graph_driver = KuzuActor("./graph.db")
    analytics_driver = DuckDBDriver()
    
    # Criar kernel
    kernel = UnifiedDataManager(
        sql_driver=sql_driver,
        graph_driver=graph_driver,
        analytics_driver=analytics_driver,
        enable_monitoring=True,
        node_id="example-node"
    )
    
    # Inicializar schema
    await kernel.boot()
    
    print("=" * 60)
    print("Exemplo: Padrão Domain Envelope")
    print("=" * 60)
    
    # ========================================================================
    # Exemplo 1: Criar Usuário (Objeto de Domínio Rico)
    # ========================================================================
    print("\n[1] Criando usuário com validação de domínio...")
    
    user = User(
        name="Alice Silva",
        email="alice@example.com",
        age=25,
        tags=["developer", "python"],
        metadata={"department": "Engineering", "level": "Senior"}
    )
    
    # Validação acontece automaticamente (Pydantic)
    print(f"✓ Usuário criado: {user.name} ({user.email})")
    print(f"  RID: {user.rid}")
    print(f"  É adulto? {user.is_adult()}")
    
    # Salvar com versionamento bitemporal
    saved_user = await kernel.save_versioned(obj=user)
    print(f"✓ Usuário salvo no banco (versão {saved_user.version})")
    
    # ========================================================================
    # Exemplo 2: Conversão Envelope (Transparente)
    # ========================================================================
    print("\n[2] Conversão Domain → Envelope → Domain...")
    
    # Converter para envelope físico (tabela SQL)
    physical_envelope = user.to_envelope()
    print(f"✓ Envelope físico criado")
    print(f"  Colunas SQL: rid={physical_envelope.rid}, version={physical_envelope.version}")
    print(f"  JSON Bag (meta_tags): {physical_envelope.meta_tags}")
    
    # Hidratar de volta para domínio
    hydrated_user = User.from_envelope(physical_envelope)
    print(f"✓ Objeto de domínio hidratado")
    print(f"  Nome: {hydrated_user.name}")
    print(f"  Tags: {hydrated_user.tags}")
    print(f"  Metadata: {hydrated_user.metadata}")
    
    # ========================================================================
    # Exemplo 3: Repositório (API Transparente)
    # ========================================================================
    print("\n[3] Usando repositório (Domain Envelope transparente)...")
    
    repo = kernel.get_repository(User)
    
    async with await kernel.sql_driver.get_session() as session:
        # Criar via repositório (recebe dict, retorna DomainResource)
        bob = await repo.create(session, {
            "name": "Bob Santos",
            "email": "bob@example.com",
            "age": 30,
            "tags": ["manager"]
        })
        print(f"✓ Bob criado via repositório: {bob.name} (RID: {bob.rid})")
        
        # Buscar (retorna DomainResource hidratado)
        found_user = await repo.get(session, id=bob.id)
        print(f"✓ Usuário encontrado: {found_user.name}")
        
        # Atualizar (trabalha com DomainResource)
        found_user.age = 31
        updated = await repo.update(session, id=bob.id, data={"age": 31})
        print(f"✓ Idade atualizada: {updated.age}")
        
        # Listar (retorna lista de DomainResource)
        users = await repo.list(session, limit=10)
        print(f"✓ Total de usuários: {len(users)}")
        for u in users:
            print(f"  - {u.name} ({u.email})")
        
        await session.commit()
    
    # ========================================================================
    # Exemplo 4: Produto com Lógica de Negócio
    # ========================================================================
    print("\n[4] Produto com lógica de negócio...")
    
    product = Product(
        name="Laptop Dell XPS",
        price=5000.00,
        stock=10,
        category="Electronics"
    )
    
    print(f"✓ Produto criado: {product.name}")
    print(f"  Preço: R$ {product.price:.2f}")
    print(f"  Disponível? {product.is_available}")
    print(f"  Preço com 10% desconto: R$ {product.apply_discount(10):.2f}")
    
    # Salvar
    saved_product = await kernel.save_versioned(obj=product)
    print(f"✓ Produto salvo (RID: {saved_product.rid})")
    
    # ========================================================================
    # Exemplo 5: Interceptor de Domínio
    # ========================================================================
    print("\n[5] Interceptor operando em objetos de domínio...")
    
    from malha import Interceptor
    
    class AuditInterceptor(Interceptor):
        """Interceptor que audita operações em objetos de domínio."""
        
        async def on_write(self, obj: DomainResource, agent=None):
            """Audita antes de salvar."""
            print(f"  [AUDIT] Salvando {obj.__class__.__name__}: {obj.rid}")
            
            # Validação específica de domínio
            if isinstance(obj, User):
                if obj.age and obj.age < 18:
                    print(f"  [AUDIT] ⚠️  Usuário menor de idade: {obj.name}")
            
            elif isinstance(obj, Product):
                if obj.price > 10000:
                    print(f"  [AUDIT] ⚠️  Produto de alto valor: {obj.name}")
        
        async def on_read(self, obj: DomainResource, agent=None):
            """Audita após carregar."""
            return obj
    
    # Registrar interceptor
    kernel.add_interceptor(AuditInterceptor())
    
    # Testar com novo usuário
    young_user = User(name="Charlie", email="charlie@example.com", age=16)
    await kernel.save_versioned(obj=young_user)
    
    # Testar com produto caro
    expensive_product = Product(
        name="MacBook Pro M3",
        price=15000.00,
        stock=5,
        category="Electronics"
    )
    await kernel.save_versioned(obj=expensive_product)
    
    # ========================================================================
    # Exemplo 6: Campos Dinâmicos (Schema-on-Read)
    # ========================================================================
    print("\n[6] Campos dinâmicos (Schema-on-Read)...")
    
    # DomainResource permite campos extras (extra='allow')
    dynamic_user = User(
        name="Diana",
        email="diana@example.com",
        age=28,
        # Campos não definidos no schema vão para meta_tags
        custom_field="valor customizado",
        another_field={"nested": "data"}
    )
    
    print(f"✓ Usuário com campos dinâmicos criado")
    print(f"  custom_field: {dynamic_user.custom_field}")
    print(f"  another_field: {dynamic_user.another_field}")
    
    # Salvar (campos extras vão para meta_tags automaticamente)
    saved_dynamic = await kernel.save_versioned(obj=dynamic_user)
    
    # Recuperar via repositório
    async with await kernel.sql_driver.get_session() as session:
        recovered = await repo.get(session, id=saved_dynamic.id)
        print(f"✓ Campos dinâmicos recuperados:")
        print(f"  custom_field: {recovered.custom_field}")
        print(f"  another_field: {recovered.another_field}")
        await session.commit()
    
    # ========================================================================
    # Resumo
    # ========================================================================
    print("\n" + "=" * 60)
    print("Resumo do Padrão Domain Envelope")
    print("=" * 60)
    print("✓ Objetos de domínio ricos (DomainResource)")
    print("✓ Validação Pydantic automática")
    print("✓ Conversão transparente para SQL (to_envelope)")
    print("✓ Hidratação automática (from_envelope)")
    print("✓ Repositórios com API limpa")
    print("✓ Interceptors operam em objetos de domínio")
    print("✓ Schema-on-Read para campos dinâmicos")
    print("✓ Lógica de negócio no domínio")
    print("=" * 60)
    
    # Cleanup
    await graph_driver.close()


if __name__ == "__main__":
    asyncio.run(main())
