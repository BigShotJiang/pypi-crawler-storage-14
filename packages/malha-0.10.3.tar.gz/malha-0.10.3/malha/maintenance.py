"""
Malha Maintenance - Garbage Collection and Schema Migration
============================================================

The maintenance module provides tools for keeping the Malha system healthy
over time. Append-only systems (like SysOutbox, ActionLog) need periodic
cleanup to prevent disk exhaustion.

Components:
1. Janitor: Cleans up old data (outbox, processes, logs)
2. Migrator: Detects and applies schema changes
3. Compactor: Optimizes storage (checkpoints, vacuums)

Usage:
    ```python
    from malha.maintenance import Janitor, Migrator
    
    # Manual cleanup
    janitor = Janitor(kernel, retention_days=30)
    result = await janitor.run()
    
    # Schema migration check
    migrator = Migrator(kernel)
    drift = await migrator.check_drift(UserModel)
    if drift:
        await migrator.apply_migrations(drift)
    
    # Schedule periodic maintenance (via kinetic or cron)
    await janitor.schedule_daily(hour=3)  # Run at 3 AM
    ```
"""

from __future__ import annotations

import asyncio
import logging
from datetime import datetime, timedelta, UTC
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Type, Any
from enum import Enum

from sqlalchemy import delete, select, text, inspect

if TYPE_CHECKING:
    from .malha import UnifiedDataManager
    from sqlmodel import SQLModel

logger = logging.getLogger("malha.maintenance")


# ==============================================================================
# JANITOR (Garbage Collection)
# ==============================================================================

@dataclass
class CleanupResult:
    """Result of a cleanup operation."""
    outbox_deleted: int = 0
    processes_deleted: int = 0
    action_logs_archived: int = 0
    duration_seconds: float = 0.0
    errors: list[str] = field(default_factory=list)
    
    def __str__(self) -> str:
        return (
            f"CleanupResult(outbox={self.outbox_deleted}, "
            f"processes={self.processes_deleted}, "
            f"logs_archived={self.action_logs_archived}, "
            f"duration={self.duration_seconds:.2f}s)"
        )


class Janitor:
    """Garbage collector for the Malha system.
    
    The Janitor periodically cleans up old data to prevent unbounded growth
    of append-only tables like SysOutbox and SysProcess.
    
    Cleanup policies:
    - SysOutbox: Delete DONE events older than retention_days
    - SysProcess: Delete COMPLETED/FAILED processes older than retention_days
    - ActionLog: Archive to Parquet (cold storage) and delete from SQL
    
    Attributes:
        kernel: The UnifiedDataManager instance
        retention_days: Days to keep data before cleanup (default: 30)
        archive_enabled: Whether to archive logs to Parquet before deletion
    """
    
    def __init__(
        self,
        kernel: "UnifiedDataManager",
        retention_days: int = 30,
        archive_enabled: bool = True,
    ):
        """Initialize the Janitor.
        
        Args:
            kernel: The kernel instance
            retention_days: Days to retain data before cleanup
            archive_enabled: Archive logs to Parquet before deletion
        """
        self.kernel = kernel
        self.retention_days = retention_days
        self.archive_enabled = archive_enabled
        self._scheduled_task: asyncio.Task | None = None

    async def run(self) -> CleanupResult:
        """Execute a full cleanup cycle.
        
        Returns:
            CleanupResult with statistics
        """
        logger.info(f"🧹 Janitor: Starting cleanup (retention={self.retention_days} days)")
        start_time = datetime.now(UTC)
        result = CleanupResult()
        
        cutoff = datetime.now(UTC) - timedelta(days=self.retention_days)
        
        # 1. Clean up processed outbox events
        try:
            result.outbox_deleted = await self._cleanup_outbox(cutoff)
        except Exception as e:
            result.errors.append(f"Outbox cleanup failed: {e}")
            logger.error(f"[Janitor] Outbox cleanup failed: {e}")
        
        # 2. Clean up old processes
        try:
            result.processes_deleted = await self._cleanup_processes(cutoff)
        except Exception as e:
            result.errors.append(f"Process cleanup failed: {e}")
            logger.error(f"[Janitor] Process cleanup failed: {e}")
        
        # 3. Archive and clean action logs (if available)
        try:
            result.action_logs_archived = await self._archive_action_logs(cutoff)
        except Exception as e:
            result.errors.append(f"Log archival failed: {e}")
            logger.error(f"[Janitor] Log archival failed: {e}")
        
        # 4. Database optimization (optional)
        await self._optimize_databases()
        
        result.duration_seconds = (datetime.now(UTC) - start_time).total_seconds()
        
        logger.info(f"✅ Janitor complete: {result}")
        return result

    async def _cleanup_outbox(self, cutoff: datetime) -> int:
        """Delete processed outbox events older than cutoff.
        
        Args:
            cutoff: Delete events created before this timestamp
            
        Returns:
            Number of deleted records
        """
        from .malha import SysOutbox
        
        async with await self.kernel.sql_driver.get_session() as session:
            # Count before delete (for logging)
            count_stmt = select(SysOutbox).where(
                SysOutbox.status == "DONE",
                SysOutbox.created_at < cutoff,
            )
            count_result = await session.execute(count_stmt)
            count = len(count_result.scalars().all())
            
            if count == 0:
                logger.debug("[Janitor] No outbox events to clean")
                return 0
            
            # Delete old DONE events
            stmt = delete(SysOutbox).where(
                SysOutbox.status == "DONE",
                SysOutbox.created_at < cutoff,
            )
            result = await session.execute(stmt)
            await session.commit()
            
            deleted = result.rowcount if hasattr(result, 'rowcount') else count
            logger.info(f"[Janitor] Deleted {deleted} outbox events")
            return deleted

    async def _cleanup_processes(self, cutoff: datetime) -> int:
        """Delete completed/failed processes older than cutoff.
        
        Args:
            cutoff: Delete processes completed before this timestamp
            
        Returns:
            Number of deleted records
        """
        from .malha import SysProcess, ProcessStatus
        
        terminal_statuses = [
            ProcessStatus.COMPLETED.value,
            ProcessStatus.FAILED.value,
            ProcessStatus.COMPENSATED.value,
            ProcessStatus.DEAD_LETTER.value,
        ]
        
        async with await self.kernel.sql_driver.get_session() as session:
            # Delete old terminal processes
            stmt = delete(SysProcess).where(
                SysProcess.status.in_(terminal_statuses),
                SysProcess.completed_at < cutoff,
            )
            result = await session.execute(stmt)
            await session.commit()
            
            deleted = result.rowcount if hasattr(result, 'rowcount') else 0
            if deleted > 0:
                logger.info(f"[Janitor] Deleted {deleted} old processes")
            return deleted

    async def _archive_action_logs(self, cutoff: datetime) -> int:
        """Archive action logs to Parquet and delete from SQL.
        
        This moves data from hot (SQL) to cold (Parquet) storage,
        keeping the SQL database lean while preserving audit history.
        
        Args:
            cutoff: Archive logs created before this timestamp
            
        Returns:
            Number of archived records
        """
        # Check if kernel has stream driver and ActionLog exists
        if not self.archive_enabled:
            return 0
        
        if not hasattr(self.kernel, "stream") or self.kernel.stream is None:
            logger.debug("[Janitor] No stream driver, skipping log archival")
            return 0
        
        # Try to import ActionLog (may not exist in all deployments)
        try:
            from .malha import ActionLog
        except ImportError:
            logger.debug("[Janitor] ActionLog not found, skipping archival")
            return 0
        
        archived = 0
        
        async with await self.kernel.sql_driver.get_session() as session:
            # Fetch logs to archive
            stmt = select(ActionLog).where(ActionLog.created_at < cutoff).limit(10000)
            result = await session.execute(stmt)
            logs = result.scalars().all()
            
            if not logs:
                return 0
            
            # Archive to Parquet via stream driver
            for log in logs:
                try:
                    await self.kernel.stream.write({
                        "id": log.id,
                        "action": log.action,
                        "rid": log.rid,
                        "payload": log.payload,
                        "created_at": log.created_at.isoformat() if log.created_at else None,
                        "archived_at": datetime.now(UTC).isoformat(),
                    })
                    archived += 1
                except Exception as e:
                    logger.warning(f"[Janitor] Failed to archive log {log.id}: {e}")
            
            # Flush to ensure data is persisted
            await self.kernel.stream.flush()
            
            # Delete archived logs
            if archived > 0:
                log_ids = [log.id for log in logs[:archived]]
                delete_stmt = delete(ActionLog).where(ActionLog.id.in_(log_ids))
                await session.execute(delete_stmt)
                await session.commit()
                logger.info(f"[Janitor] Archived {archived} action logs to Parquet")
        
        return archived

    async def _optimize_databases(self) -> None:
        """Run optimization commands on databases.
        
        Delegates to SmartCompactor for intelligent storage optimization.
        """
        compactor = SmartCompactor(self.kernel)
        await compactor.run_maintenance(force=False)


# ==============================================================================
# SMART COMPACTOR (Physical Storage Optimization)
# ==============================================================================

@dataclass
class CompactionResult:
    """Result of a compaction operation."""
    sqlite_vacuumed: bool = False
    sqlite_pages_freed: int = 0
    duckdb_checkpointed: bool = False
    kuzu_checkpointed: bool = False
    duration_seconds: float = 0.0
    errors: list[str] = field(default_factory=list)
    
    def __str__(self) -> str:
        return (
            f"CompactionResult(sqlite={self.sqlite_vacuumed}, "
            f"duckdb={self.duckdb_checkpointed}, "
            f"kuzu={self.kuzu_checkpointed}, "
            f"duration={self.duration_seconds:.2f}s)"
        )


class SmartCompactor:
    """Manages physical storage compaction (Vacuum/Checkpoint) for all storages.
    
    Modern databases like Kùzu, DuckDB, and SQLite use MVCC (Multi-Version 
    Concurrency Control). When you delete or update a record, the database
    does NOT immediately erase the data from disk - it marks the old data
    as "dead" and writes the new version elsewhere.
    
    The Problem:
    - Database files only grow ("Bloat")
    - A database with 1GB of useful data can occupy 10GB on disk
    - Queries slow down (scanning dead pages)
    - Storage costs explode
    
    The Solution:
    SmartCompactor reclaims physical disk space by:
    - SQLite: VACUUM (rewrites entire database file)
    - DuckDB: CHECKPOINT (merges WAL into main file)
    - Kùzu: CHECKPOINT (cleans up old MVCC versions)
    
    Scheduling Recommendations:
    - Kùzu/DuckDB CHECKPOINT: Every 1 hour or after heavy ingestion
    - SQLite VACUUM: Only during maintenance window (3 AM) - blocks database
    
    Example:
        ```python
        from malha.maintenance import SmartCompactor
        
        compactor = SmartCompactor(kernel)
        
        # Smart compaction (only if needed)
        result = await compactor.run_maintenance(force=False)
        
        # Force full compaction (maintenance window)
        result = await compactor.run_maintenance(force=True)
        
        # Individual operations
        await compactor.checkpoint_kuzu()
        await compactor.checkpoint_duckdb()
        await compactor.vacuum_sqlite(force=True)
        ```
    """
    
    # Threshold: VACUUM SQLite if more than this many free pages (~4MB at 4KB/page)
    SQLITE_FREE_PAGES_THRESHOLD = 1000
    
    def __init__(self, kernel: "UnifiedDataManager"):
        """Initialize the SmartCompactor.
        
        Args:
            kernel: The UnifiedDataManager instance
        """
        self.kernel = kernel

    async def run_maintenance(self, force: bool = False) -> CompactionResult:
        """Run full storage optimization across all databases.
        
        Args:
            force: If True, run VACUUM even if not strictly needed.
                  Use during maintenance windows only.
        
        Returns:
            CompactionResult with statistics
        """
        logger.info("🗜️ Compactor: Starting storage optimization...")
        start_time = datetime.now(UTC)
        result = CompactionResult()
        
        # 1. SQLite (Transactional Store)
        # VACUUM rewrites the entire file - expensive but reclaims space
        try:
            vacuumed, pages = await self._optimize_sqlite(force)
            result.sqlite_vacuumed = vacuumed
            result.sqlite_pages_freed = pages
        except Exception as e:
            result.errors.append(f"SQLite: {e}")
            logger.error(f"[Compactor] SQLite optimization failed: {e}")
        
        # 2. DuckDB (Analytics Store)
        # CHECKPOINT merges WAL into main file
        try:
            result.duckdb_checkpointed = await self._optimize_duckdb()
        except Exception as e:
            result.errors.append(f"DuckDB: {e}")
            logger.error(f"[Compactor] DuckDB optimization failed: {e}")
        
        # 3. Kùzu (Graph Store)
        # CHECKPOINT cleans up old MVCC versions
        try:
            result.kuzu_checkpointed = await self._optimize_kuzu()
        except Exception as e:
            result.errors.append(f"Kùzu: {e}")
            logger.error(f"[Compactor] Kùzu optimization failed: {e}")
        
        result.duration_seconds = (datetime.now(UTC) - start_time).total_seconds()
        
        logger.info(f"✅ Compactor complete: {result}")
        return result

    async def _optimize_sqlite(self, force: bool) -> tuple[bool, int]:
        """Optimize SQLite storage by reclaiming free pages.
        
        SQLite stores free space in a 'freelist'. VACUUM rewrites the
        entire database file, eliminating the freelist and shrinking
        the file on disk.
        
        WARNING: VACUUM blocks the database for the duration of the
        operation. Only run during maintenance windows.
        
        Args:
            force: Run VACUUM regardless of freelist size
            
        Returns:
            Tuple of (was_vacuumed, pages_freed)
        """
        async with await self.kernel.sql_driver.get_session() as session:
            bind = session.get_bind()
            
            # Only applies to SQLite
            if "sqlite" not in str(bind.url):
                return False, 0
            
            # Check freelist size (heuristic for bloat)
            try:
                res = await session.execute(text("PRAGMA freelist_count;"))
                free_pages = res.scalar() or 0
            except Exception:
                free_pages = 0
            
            # Decide whether to VACUUM
            should_vacuum = force or free_pages > self.SQLITE_FREE_PAGES_THRESHOLD
            
            if not should_vacuum:
                logger.debug(
                    f"[Compactor] SQLite: {free_pages} free pages "
                    f"(threshold: {self.SQLITE_FREE_PAGES_THRESHOLD}), skipping VACUUM"
                )
                return False, 0
            
            logger.info(
                f"[Compactor] SQLite: VACUUMing ({free_pages} free pages)..."
            )
            
            # VACUUM cannot run inside a transaction in SQLite
            # We need to use raw connection
            await session.execute(text("VACUUM;"))
            await session.commit()
            
            logger.info(f"[Compactor] SQLite: VACUUM complete, freed ~{free_pages} pages")
            return True, free_pages

    async def _optimize_duckdb(self) -> bool:
        """Optimize DuckDB storage by checkpointing WAL.
        
        DuckDB accumulates data in .wal files before merging into the
        main .db file. CHECKPOINT forces this merge, reclaiming space
        and improving read performance.
        
        Returns:
            True if checkpoint was successful
        """
        if not hasattr(self.kernel, "analytics_driver"):
            return False
        
        analytics = self.kernel.analytics_driver
        
        # Check if it's a DuckDB driver with a connection
        if not hasattr(analytics, "conn") or analytics.conn is None:
            return False
        
        try:
            # Force WAL merge into main file
            analytics.conn.execute("CHECKPOINT;")
            logger.debug("[Compactor] DuckDB: CHECKPOINT complete")
            return True
        except Exception as e:
            logger.warning(f"[Compactor] DuckDB: CHECKPOINT failed: {e}")
            return False

    async def _optimize_kuzu(self) -> bool:
        """Optimize Kùzu storage by checkpointing MVCC versions.
        
        Kùzu uses MVCC for concurrency. Old versions accumulate until
        a CHECKPOINT is issued, which cleans up versions that are no
        longer visible to any active transaction.
        
        Returns:
            True if checkpoint was successful
        """
        if not hasattr(self.kernel, "graph_driver"):
            return False
        
        try:
            await self.kernel.graph_driver.execute("CHECKPOINT")
            logger.debug("[Compactor] Kùzu: CHECKPOINT complete")
            return True
        except Exception as e:
            logger.warning(f"[Compactor] Kùzu: CHECKPOINT failed: {e}")
            return False

    # Convenience methods for individual operations
    
    async def checkpoint_kuzu(self) -> bool:
        """Run Kùzu CHECKPOINT only."""
        return await self._optimize_kuzu()
    
    async def checkpoint_duckdb(self) -> bool:
        """Run DuckDB CHECKPOINT only."""
        return await self._optimize_duckdb()
    
    async def vacuum_sqlite(self, force: bool = False) -> tuple[bool, int]:
        """Run SQLite VACUUM only."""
        return await self._optimize_sqlite(force)

    async def schedule_daily(self, hour: int = 3, minute: int = 0) -> asyncio.Task:
        """Schedule the janitor to run daily at a specific time.
        
        Args:
            hour: Hour to run (0-23, default 3 AM)
            minute: Minute to run (0-59, default 0)
            
        Returns:
            The scheduled task
        """
        async def _daily_loop():
            while True:
                now = datetime.now(UTC)
                next_run = now.replace(hour=hour, minute=minute, second=0, microsecond=0)
                if next_run <= now:
                    next_run += timedelta(days=1)
                
                wait_seconds = (next_run - now).total_seconds()
                logger.info(f"[Janitor] Next run scheduled in {wait_seconds/3600:.1f} hours")
                
                await asyncio.sleep(wait_seconds)
                
                try:
                    await self.run()
                except Exception as e:
                    logger.error(f"[Janitor] Scheduled run failed: {e}")
        
        self._scheduled_task = asyncio.create_task(_daily_loop())
        return self._scheduled_task

    def cancel_schedule(self) -> None:
        """Cancel the scheduled daily cleanup."""
        if self._scheduled_task:
            self._scheduled_task.cancel()
            self._scheduled_task = None


# ==============================================================================
# MIGRATOR (Schema Evolution)
# ==============================================================================

class MigrationAction(str, Enum):
    """Type of schema migration action."""
    ADD_COLUMN = "add_column"
    DROP_COLUMN = "drop_column"  # Dangerous, disabled by default
    MODIFY_TYPE = "modify_type"  # Dangerous, disabled by default
    ADD_INDEX = "add_index"
    

@dataclass
class SchemaDrift:
    """Represents a difference between model and database schema."""
    table_name: str
    action: MigrationAction
    column_name: str
    model_type: str | None = None  # Type in Pydantic model
    db_type: str | None = None  # Type in database
    
    def __str__(self) -> str:
        return f"{self.action.value}: {self.table_name}.{self.column_name}"


@dataclass
class MigrationResult:
    """Result of migration operations."""
    drifts_detected: list[SchemaDrift] = field(default_factory=list)
    migrations_applied: list[str] = field(default_factory=list)
    migrations_skipped: list[str] = field(default_factory=list)
    errors: list[str] = field(default_factory=list)
    
    @property
    def has_drift(self) -> bool:
        return len(self.drifts_detected) > 0
    
    def __str__(self) -> str:
        return (
            f"MigrationResult(drifts={len(self.drifts_detected)}, "
            f"applied={len(self.migrations_applied)}, "
            f"skipped={len(self.migrations_skipped)})"
        )


class Migrator:
    """Schema migrator for detecting and applying model changes.
    
    The Migrator compares Pydantic/SQLModel definitions with the actual
    database schema and can apply safe migrations (ADD COLUMN only by default).
    
    For production systems, use the embedded AlembicDriver which provides:
    - Full DDL support (DROP, MODIFY, RENAME)
    - Versioned migration history
    - SQLite batch mode for safe DDL operations
    - Rollback capabilities
    
    Example with AlembicDriver:
        ```python
        from malha.drivers.alembic import AlembicDriver
        
        driver = AlembicDriver(kernel)
        await driver.init()  # First time only
        await driver.auto_migrate("add user preferences")
        ```
    
    Attributes:
        kernel: The UnifiedDataManager instance
        allow_destructive: Allow DROP COLUMN and type changes (dangerous!)
        dry_run: Only detect drift, don't apply changes
        alembic_driver: Optional AlembicDriver for advanced migrations
    """
    
    # Type mapping from Python to SQL
    TYPE_MAP = {
        "str": "TEXT",
        "int": "INTEGER",
        "float": "REAL",
        "bool": "INTEGER",  # SQLite doesn't have BOOLEAN
        "datetime": "TIMESTAMP",
        "date": "DATE",
        "bytes": "BLOB",
        "dict": "TEXT",  # JSON stored as TEXT
        "list": "TEXT",  # JSON stored as TEXT
    }
    
    def __init__(
        self,
        kernel: "UnifiedDataManager",
        allow_destructive: bool = False,
        dry_run: bool = True,
        migrations_path: str = "./migrations",
    ):
        """Initialize the Migrator.
        
        Args:
            kernel: The kernel instance
            allow_destructive: Allow destructive operations (DROP, MODIFY)
            dry_run: Don't apply changes, only detect
            migrations_path: Path to Alembic migrations directory
        """
        self.kernel = kernel
        self.allow_destructive = allow_destructive
        self.dry_run = dry_run
        self.migrations_path = migrations_path
        self._alembic_driver = None
    
    @property
    def alembic(self):
        """Get the AlembicDriver instance (lazy initialization)."""
        if self._alembic_driver is None:
            try:
                from malha.drivers.alembic import AlembicDriver
                self._alembic_driver = AlembicDriver(
                    self.kernel,
                    migrations_path=self.migrations_path,
                )
            except ImportError:
                raise ImportError(
                    "AlembicDriver requires 'alembic' package. "
                    "Install with: pip install alembic>=1.13.0"
                )
        return self._alembic_driver
    
    async def auto_migrate(self, message: str = "auto migration"):
        """Create and apply a migration using AlembicDriver.
        
        This is the recommended method for production migrations.
        It uses Alembic's autogenerate to detect changes and applies them.
        
        Args:
            message: Description of the migration
            
        Returns:
            MigrationResult from AlembicDriver
        """
        return await self.alembic.auto_migrate(message)
    
    async def upgrade(self, revision: str = "head"):
        """Apply pending migrations using AlembicDriver.
        
        Args:
            revision: Target revision (default: "head")
            
        Returns:
            MigrationResult from AlembicDriver
        """
        return await self.alembic.upgrade(revision)
    
    async def downgrade(self, revision: str = "-1"):
        """Rollback migrations using AlembicDriver.
        
        Args:
            revision: Target revision (default: "-1" for one step back)
            
        Returns:
            MigrationResult from AlembicDriver
        """
        return await self.alembic.downgrade(revision)
    
    async def init_alembic(self):
        """Initialize Alembic migrations directory.
        
        Creates the migrations directory with a custom env.py
        that integrates with the kernel's connection pool.
        
        Returns:
            MigrationResult from AlembicDriver
        """
        return await self.alembic.init()

    async def check_drift(self, model_cls: Type["SQLModel"]) -> list[SchemaDrift]:
        """Check for schema drift between model and database.
        
        Args:
            model_cls: The SQLModel class to check
            
        Returns:
            List of SchemaDrift objects describing differences
        """
        drifts: list[SchemaDrift] = []
        table_name = model_cls.__tablename__
        
        # Get database columns
        db_columns = await self._get_db_columns(table_name)
        
        # Get model columns
        model_columns = self._get_model_columns(model_cls)
        
        # Find missing columns (in model but not in DB)
        for col_name, col_type in model_columns.items():
            if col_name not in db_columns:
                drifts.append(SchemaDrift(
                    table_name=table_name,
                    action=MigrationAction.ADD_COLUMN,
                    column_name=col_name,
                    model_type=col_type,
                ))
        
        # Find extra columns (in DB but not in model) - warn only
        for col_name in db_columns:
            if col_name not in model_columns:
                logger.warning(
                    f"[Migrator] Column '{col_name}' exists in DB but not in model {model_cls.__name__}"
                )
        
        if drifts:
            logger.info(f"[Migrator] Found {len(drifts)} schema drifts for {table_name}")
        
        return drifts

    async def apply_migrations(self, drifts: list[SchemaDrift]) -> MigrationResult:
        """Apply schema migrations based on detected drifts.
        
        Args:
            drifts: List of SchemaDrift to apply
            
        Returns:
            MigrationResult with applied/skipped migrations
        """
        result = MigrationResult(drifts_detected=drifts)
        
        if self.dry_run:
            logger.info("[Migrator] Dry run mode - no changes will be applied")
            result.migrations_skipped = [str(d) for d in drifts]
            return result
        
        async with await self.kernel.sql_driver.get_session() as session:
            for drift in drifts:
                try:
                    if drift.action == MigrationAction.ADD_COLUMN:
                        sql_type = self._map_type(drift.model_type)
                        stmt = text(
                            f"ALTER TABLE {drift.table_name} "
                            f"ADD COLUMN {drift.column_name} {sql_type}"
                        )
                        await session.execute(stmt)
                        result.migrations_applied.append(str(drift))
                        logger.info(f"[Migrator] Applied: {drift}")
                        
                    elif drift.action in (MigrationAction.DROP_COLUMN, MigrationAction.MODIFY_TYPE):
                        if self.allow_destructive:
                            # These are complex and database-specific
                            logger.warning(
                                f"[Migrator] Destructive migration {drift} requires manual intervention"
                            )
                            result.migrations_skipped.append(str(drift))
                        else:
                            result.migrations_skipped.append(str(drift))
                            
                except Exception as e:
                    result.errors.append(f"{drift}: {e}")
                    logger.error(f"[Migrator] Failed to apply {drift}: {e}")
            
            await session.commit()
        
        return result

    async def _get_db_columns(self, table_name: str) -> dict[str, str]:
        """Get column names and types from database.
        
        Args:
            table_name: Name of the table
            
        Returns:
            Dict of column_name -> column_type
        """
        columns = {}
        
        async with await self.kernel.sql_driver.get_session() as session:
            bind = session.get_bind()
            
            if "sqlite" in str(bind.url):
                # SQLite specific
                result = await session.execute(text(f"PRAGMA table_info({table_name})"))
                for row in result:
                    columns[row[1]] = row[2]  # name, type
                    
            elif "postgresql" in str(bind.url):
                # PostgreSQL specific
                result = await session.execute(text(f"""
                    SELECT column_name, data_type 
                    FROM information_schema.columns 
                    WHERE table_name = '{table_name}'
                """))
                for row in result:
                    columns[row[0]] = row[1]
                    
            else:
                # Generic fallback using SQLAlchemy inspection
                try:
                    def _inspect():
                        inspector = inspect(bind)
                        for col in inspector.get_columns(table_name):
                            columns[col["name"]] = str(col["type"])
                    
                    loop = asyncio.get_running_loop()
                    await loop.run_in_executor(None, _inspect)
                except Exception as e:
                    logger.warning(f"[Migrator] Could not inspect table {table_name}: {e}")
        
        return columns

    def _get_model_columns(self, model_cls: Type["SQLModel"]) -> dict[str, str]:
        """Get column names and types from Pydantic model.
        
        Args:
            model_cls: The SQLModel class
            
        Returns:
            Dict of column_name -> python_type
        """
        columns = {}
        
        for field_name, field_info in model_cls.model_fields.items():
            # Get the annotation type
            annotation = field_info.annotation
            if annotation is not None:
                # Handle Optional types
                if hasattr(annotation, "__origin__"):
                    if annotation.__origin__ is type(None):
                        continue
                    # Get the first non-None type from Union
                    args = getattr(annotation, "__args__", ())
                    for arg in args:
                        if arg is not type(None):
                            annotation = arg
                            break
                
                type_name = getattr(annotation, "__name__", str(annotation))
                columns[field_name] = type_name
        
        return columns

    def _map_type(self, python_type: str | None) -> str:
        """Map Python type to SQL type.
        
        Args:
            python_type: Python type name
            
        Returns:
            SQL type string
        """
        if python_type is None:
            return "TEXT"
        return self.TYPE_MAP.get(python_type.lower(), "TEXT")


# ==============================================================================
# CONVENIENCE FUNCTIONS
# ==============================================================================

async def run_cleanup(
    kernel: "UnifiedDataManager",
    retention_days: int = 30,
) -> CleanupResult:
    """Run a one-time cleanup.
    
    Args:
        kernel: The kernel instance
        retention_days: Days to retain data
        
    Returns:
        CleanupResult with statistics
    """
    janitor = Janitor(kernel, retention_days=retention_days)
    return await janitor.run()


async def check_schema_drift(
    kernel: "UnifiedDataManager",
    model_cls: Type["SQLModel"],
) -> list[SchemaDrift]:
    """Check for schema drift on a single model.
    
    Args:
        kernel: The kernel instance
        model_cls: The model to check
        
    Returns:
        List of detected drifts
    """
    migrator = Migrator(kernel)
    return await migrator.check_drift(model_cls)
