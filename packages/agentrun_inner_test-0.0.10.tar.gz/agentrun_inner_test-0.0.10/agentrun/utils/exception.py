"""异常定义模块 / Exception Definition Module

此模块定义 AgentRun SDK 的所有异常类型。
This module defines all exception types for AgentRun SDK.
"""

from typing import Optional


class AgentRunError(Exception):
    """AgentRun SDK 基础异常类 / AgentRun SDK Base Exception Class

    所有 AgentRun SDK 异常的基类。
    Base class for all AgentRun SDK exceptions.
    """

    def __init__(
        self,
        message: str,
        **kwargs,
    ):
        """初始化异常 / Initialize exception

        Args:
            message: 错误消息 / Error message
            **kwargs: 详细信息键值对 / Detailed information key-value pairs
        """
        msg = message or ""
        if kwargs is not None:
            msg += self.kwargs_str(**kwargs)

        super().__init__(msg)
        self.message = message
        self.details = kwargs

    @classmethod
    def kwargs_str(cls, **kwargs) -> str:
        """获取详细信息字符串 / Get detailed information string

        Args:
            **kwargs: 详细信息键值对 / Detailed information key-value pairs

        Returns:
            str: JSON 格式的详细信息字符串 / Detailed information string in JSON format
        """
        if not kwargs:
            return ""
        # return ", ".join([f"{key}={value!s}" for key, value in kwargs.items()])
        import json

        return json.dumps(
            kwargs,
            ensure_ascii=False,
            default=lambda x: x.__dict__,
        )

    def details_str(self) -> str:
        return self.kwargs_str(**self.details)

    def __str__(self) -> str:
        return self.message


class HTTPError(AgentRunError):
    """HTTP 异常类 / HTTP Exception Class

    表示 HTTP 请求失败的异常。
    Represents an exception when HTTP request fails.
    """

    def __init__(
        self,
        status_code: int,
        message: str,
        request_id: Optional[str] = None,
        **kwargs,
    ):
        """初始化 HTTP 异常 / Initialize HTTP exception

        Args:
            status_code: HTTP 状态码 / HTTP status code
            message: 错误消息 / Error message
            request_id: 请求 ID,可选 / Request ID, optional
            **kwargs: 额外的详细信息 / Additional detailed information
        """
        self.status_code = status_code
        self.request_id = request_id
        self.details = kwargs
        super().__init__(message, **kwargs)

    def __str__(self) -> str:
        return (
            f"HTTP {self.status_code}: {self.message}. Request ID:"
            f" {self.request_id}. Details: {self.details_str()}"
        )

    def to_resource_error(
        self, resource_type: str, resource_id: Optional[str] = ""
    ):
        if self.status_code == 404 and (
            "does not exist" in self.message or "not found" in self.message
        ):
            return ResourceNotExistError(resource_type, resource_id)
        elif self.status_code == 400 and ("already exists" in self.message):
            return ResourceAlreadyExistError(resource_type, resource_id)
        else:
            return self


class ClientError(HTTPError):
    """客户端异常类"""

    def __init__(
        self,
        status_code: int,
        message: str,
        request_id: Optional[str] = None,
        **kwargs,
    ):
        super().__init__(status_code, message, request_id=request_id, **kwargs)


class ServerError(HTTPError):
    """服务端异常类"""

    def __init__(
        self, status_code: int, message: str, request_id: Optional[str] = None
    ):
        super().__init__(status_code, message, request_id=request_id)


class ResourceNotExistError(AgentRunError):
    """资源不存在异常"""

    def __init__(
        self,
        resource_type: str,
        resource_id: Optional[str] = "",
    ):
        super().__init__(
            f"Resource {resource_type}({resource_id}) does not exist."
        )


class ResourceAlreadyExistError(AgentRunError):
    """资源已存在异常"""

    def __init__(
        self,
        resource_type: str,
        resource_id: Optional[str] = "",
    ):
        super().__init__(
            f"Resource {resource_type}({resource_id}) already exists."
        )


class DeleteResourceError(AgentRunError):
    """删除资源异常"""

    def __init__(
        self,
        message: Optional[str] = None,
    ):
        msg = "Failed to delete resource."
        if message:
            msg += f" Reason: {message}"

        super().__init__(msg)
