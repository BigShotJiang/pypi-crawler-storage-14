# -*- encoding: utf-8 -*-
"""
                  888    888                         .d8888b.       .d8888b.  
                  888    888                        d88P  Y88b     d88P  Y88b 
                  888    888                             .d88P     Y88b. d88P 
 .d8888b 888  888 888888 88888b.   .d88b.  88888b.      8888"       "Y88888"  
d88P"    888  888 888    888 "88b d88""88b 888 "88b      "Y8b.     .d8P""Y8b. 
888      888  888 888    888  888 888  888 888  888 888    888     888    888 
Y88b.    Y88b 888 Y88b.  888  888 Y88..88P 888  888 Y88b  d88P d8b Y88b  d88P 
 "Y8888P  "Y88888  "Y888 888  888  "Y88P"  888  888  "Y8888P"  Y8P  "Y8888P"  
              888                                                             
         Y8b d88P                                                             
          "Y88P"                                                              
"""
from __future__ import print_function
from replenv import *
from replutilities import *
import keyvalue