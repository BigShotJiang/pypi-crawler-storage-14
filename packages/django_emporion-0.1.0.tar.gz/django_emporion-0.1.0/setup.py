# django_emporion_package/setup.py

import os
from setuptools import setup, find_packages


def read_version():
    with open(os.path.join(os.path.dirname(__file__), 'django_emporion', '__init__.py')) as f:
        for line in f:
            if line.startswith('__version__'):
                return line.split('=')[1].strip().strip("'\"")
    raise RuntimeError("Unable to find version string in __init__.py.")


setup(
    name='django-emporion',
    version=read_version(),
    packages=find_packages(exclude=['tests', 'docs']),
    include_package_data=True,
    license='GPL v3',
    description='A modular e-commerce core for Django.',
    install_requires=[
        'asgiref>=3.11.0',
        'Django>=5.2.8',
        'django-fsm>=3.0.1',
        'django-rest-framework>=0.1.0',
        'djangorestframework>=3.16.1',
        'sqlparse>=0.5.4',
        'tzdata>=2025.2'
    ],
)
