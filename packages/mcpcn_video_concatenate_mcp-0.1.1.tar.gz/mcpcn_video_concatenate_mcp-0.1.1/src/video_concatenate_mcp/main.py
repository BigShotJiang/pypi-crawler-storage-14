from mcp.server.fastmcp import FastMCP
import ffmpeg
import os
import logging
import tempfile
import shutil
import subprocess
from logging.handlers import RotatingFileHandler
from pathlib import Path

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    handlers=[logging.StreamHandler()],
)
logger = logging.getLogger(__name__)
logger.setLevel(logging.DEBUG)

package = "video-concatenate-mcp"

log_dir = Path(tempfile.gettempdir()) / package
log_dir.mkdir(exist_ok=True)
log_file = log_dir / "debug.log"

file_handler = RotatingFileHandler(
    str(log_file), maxBytes=5_000_000, backupCount=3, encoding="utf-8"
)
file_handler.setFormatter(
    logging.Formatter("%(asctime)s - %(name)s - %(levelname)s - %(message)s")
)
logger.addHandler(file_handler)
logger.propagate = False

FFMPEG_BINARY = os.environ.get("FFMPEG_BINARY", "ffmpeg")
FFPROBE_BINARY = os.environ.get("FFPROBE_BINARY", "ffprobe")


def _ffmpeg_run(stream_spec, **kwargs):
    if "overwrite_output" not in kwargs:
        kwargs["overwrite_output"] = True
    return ffmpeg.run(stream_spec, cmd=FFMPEG_BINARY, **kwargs)


def _ffprobe_probe(path: str, **kwargs):
    return ffmpeg.probe(path, cmd=FFPROBE_BINARY, **kwargs)


def _prepare_path(input_path: str, output_path: str) -> None:
    if not os.path.exists(input_path):
        raise RuntimeError(f"Error: Input file not found at {input_path}")
    try:
        parent_dir = os.path.dirname(output_path)
        if parent_dir and not os.path.exists(parent_dir):
            os.makedirs(parent_dir, exist_ok=True)
    except Exception as e:
        raise RuntimeError(
            f"Error creating output directory for {output_path}: {str(e)}"
        )
    if os.path.exists(output_path):
        raise RuntimeError(
            f"Error: Output file already exists at {output_path}. Please choose a different path or delete the existing file."
        )


def _get_media_properties(media_path: str) -> dict:
    """获取媒体文件的属性信息"""
    try:
        probe = _ffprobe_probe(media_path)
        video_stream_info = next(
            (s for s in probe["streams"] if s["codec_type"] == "video"), None
        )
        audio_stream_info = next(
            (s for s in probe["streams"] if s["codec_type"] == "audio"), None
        )

        props = {
            "duration": float(probe["format"].get("duration", 0.0)),
            "has_video": video_stream_info is not None,
            "has_audio": audio_stream_info is not None,
            "width": int(video_stream_info["width"])
            if video_stream_info and "width" in video_stream_info
            else 0,
            "height": int(video_stream_info["height"])
            if video_stream_info and "height" in video_stream_info
            else 0,
            "avg_fps": 0,
            "sample_rate": int(audio_stream_info["sample_rate"])
            if audio_stream_info and "sample_rate" in audio_stream_info
            else 44100,
            "channels": int(audio_stream_info["channels"])
            if audio_stream_info and "channels" in audio_stream_info
            else 2,
            "channel_layout": audio_stream_info.get("channel_layout", "stereo")
            if audio_stream_info
            else "stereo",
        }
        if (
            video_stream_info
            and "avg_frame_rate" in video_stream_info
            and video_stream_info["avg_frame_rate"] != "0/0"
        ):
            num, den = map(int, video_stream_info["avg_frame_rate"].split("/"))
            if den > 0:
                props["avg_fps"] = num / den
            else:
                props["avg_fps"] = 30
        else:
            props["avg_fps"] = 30
        return props
    except ffmpeg.Error as e:
        raise RuntimeError(
            f"Error probing file {media_path}: {e.stderr.decode('utf8') if e.stderr else str(e)}"
        )
    except Exception as e:
        raise RuntimeError(f"Unexpected error probing file {media_path}: {str(e)}")


# 支持的转场效果列表
VALID_TRANSITIONS = {
    "dissolve",
    "fade",
    "fadeblack",
    "fadewhite",
    "fadegrays",
    "distance",
    "wipeleft",
    "wiperight",
    "wipeup",
    "wipedown",
    "slideleft",
    "slideright",
    "slideup",
    "slidedown",
    "smoothleft",
    "smoothright",
    "smoothup",
    "smoothdown",
    "circlecrop",
    "rectcrop",
    "circleopen",
    "circleclose",
    "vertopen",
    "vertclose",
    "horzopen",
    "horzclose",
    "diagtl",
    "diagtr",
    "diagbl",
    "diagbr",
    "hlslice",
    "hrslice",
    "vuslice",
    "vdslice",
    "pixelize",
    "radial",
    "hblur",
}

mcp = FastMCP("VideoConcatenateServer")


@mcp.tool()
def concatenate_videos(
    video_paths: list[str],
    output_video_path: str,
    transition_effect: str = None,
    transition_duration: float = None,
) -> str:
    """拼接视频序列，并可选两段间的过渡效果。

    Args:
        video_paths: 输入视频路径列表（至少 1 个）。
        output_video_path: 输出视频文件路径。
        transition_effect: 过渡效果（可选）。支持的效果包括：
            - 淡入淡出类: 'dissolve', 'fade', 'fadeblack', 'fadewhite', 'fadegrays'
            - 擦除类: 'wipeleft', 'wiperight', 'wipeup', 'wipedown'
            - 滑动类: 'slideleft', 'slideright', 'slideup', 'slidedown'
            - 平滑类: 'smoothleft', 'smoothright', 'smoothup', 'smoothdown'
            - 圆形类: 'circlecrop', 'circleopen', 'circleclose'
            - 矩形类: 'rectcrop', 'vertopen', 'vertclose', 'horzopen', 'horzclose'
            - 对角线类: 'diagtl', 'diagtr', 'diagbl', 'diagbr'
            - 切片类: 'hlslice', 'hrslice', 'vuslice', 'vdslice'
            - 其他: 'distance', 'pixelize', 'radial', 'hblur'
        transition_duration: 过渡时长（秒，>0；仅在指定 transition_effect 且有两段视频时有效）。

    Returns:
        成功或失败的状态消息。

    示例:
        # 简单拼接（无转场）
        concatenate_videos(["/path/video1.mp4", "/path/video2.mp4"], "/path/output.mp4")

        # 带淡入淡出转场
        concatenate_videos(
            ["/path/video1.mp4", "/path/video2.mp4"],
            "/path/output.mp4",
            transition_effect="dissolve",
            transition_duration=1.0
        )
    """
    if not video_paths:
        raise RuntimeError("Error: No video paths provided for concatenation.")
    if len(video_paths) < 1:
        raise RuntimeError("Error: At least one video is required.")

    # 验证所有输入文件存在
    for video_path in video_paths:
        if not os.path.exists(video_path):
            raise RuntimeError(f"Error: Input file not found at {video_path}")

    # 验证输出路径
    try:
        parent_dir = os.path.dirname(output_video_path)
        if parent_dir and not os.path.exists(parent_dir):
            os.makedirs(parent_dir, exist_ok=True)
    except Exception as e:
        raise RuntimeError(
            f"Error creating output directory for {output_video_path}: {str(e)}"
        )
    if os.path.exists(output_video_path):
        raise RuntimeError(
            f"Error: Output file already exists at {output_video_path}. Please choose a different path or delete the existing file."
        )

    # 验证转场参数
    if transition_effect and transition_duration is None:
        raise RuntimeError(
            "Error: transition_duration is required when transition_effect is specified."
        )
    if transition_effect and transition_duration <= 0:
        raise RuntimeError("Error: transition_duration must be positive.")
    if transition_effect and transition_effect not in VALID_TRANSITIONS:
        raise RuntimeError(
            f"Error: Invalid transition_effect '{transition_effect}'. Valid options: {', '.join(sorted(VALID_TRANSITIONS))}"
        )

    # 单个视频直接处理
    if len(video_paths) == 1:
        try:
            _ffmpeg_run(
                ffmpeg.input(video_paths[0]).output(
                    output_video_path, vcodec="libx264", acodec="aac"
                ),
                capture_stdout=True,
                capture_stderr=True,
            )
            return f"Single video processed and saved to {output_video_path}"
        except ffmpeg.Error as e:
            raise RuntimeError(
                f"Error processing single video: {e.stderr.decode('utf8') if e.stderr else str(e)}"
            )

    # 两个视频带转场效果
    if transition_effect and len(video_paths) == 2:
        return _concatenate_with_transition(
            video_paths[0], video_paths[1], output_video_path,
            transition_effect, transition_duration
        )

    # 多个视频简单拼接
    return _concatenate_simple(video_paths, output_video_path)


def _concatenate_with_transition(
    video1_path: str,
    video2_path: str,
    output_video_path: str,
    transition_effect: str,
    transition_duration: float,
) -> str:
    """使用 xfade 转场效果拼接两个视频"""
    temp_dir = tempfile.mkdtemp()
    try:
        props1 = _get_media_properties(video1_path)
        props2 = _get_media_properties(video2_path)

        if not props1["has_video"] or not props2["has_video"]:
            raise RuntimeError(
                "Error: xfade transition requires both inputs to be videos."
            )
        if transition_duration >= props1["duration"]:
            raise RuntimeError(
                f"Error: Transition duration ({transition_duration}s) cannot be equal or longer than the first video's duration ({props1['duration']})."
            )

        has_audio = props1["has_audio"] and props2["has_audio"]
        target_w = max(props1["width"], props2["width"], 640)
        target_h = max(props1["height"], props2["height"], 360)
        target_fps = max(props1["avg_fps"], props2["avg_fps"], 30)
        if target_fps <= 0:
            target_fps = 30

        # 标准化第一个视频
        norm_video1_path = os.path.join(temp_dir, "norm_video1.mp4")
        try:
            subprocess.run(
                [
                    FFMPEG_BINARY,
                    "-i", video1_path,
                    "-vf", f"scale={target_w}:{target_h}",
                    "-r", str(target_fps),
                    "-c:v", "libx264",
                    "-pix_fmt", "yuv420p",
                    "-c:a", "aac",
                    "-y", norm_video1_path,
                ],
                check=True,
                capture_output=True,
            )
        except subprocess.CalledProcessError as e:
            raise RuntimeError(
                f"Error normalizing first video: {e.stderr.decode('utf8') if e.stderr else str(e)}"
            )

        # 标准化第二个视频
        norm_video2_path = os.path.join(temp_dir, "norm_video2.mp4")
        try:
            subprocess.run(
                [
                    FFMPEG_BINARY,
                    "-i", video2_path,
                    "-vf", f"scale={target_w}:{target_h}",
                    "-r", str(target_fps),
                    "-c:v", "libx264",
                    "-pix_fmt", "yuv420p",
                    "-c:a", "aac",
                    "-y", norm_video2_path,
                ],
                check=True,
                capture_output=True,
            )
        except subprocess.CalledProcessError as e:
            raise RuntimeError(
                f"Error normalizing second video: {e.stderr.decode('utf8') if e.stderr else str(e)}"
            )

        # 获取标准化后的视频时长
        norm_props1 = _get_media_properties(norm_video1_path)
        norm_video1_duration = norm_props1["duration"]
        if transition_duration >= norm_video1_duration:
            raise RuntimeError(
                f"Error: Transition duration ({transition_duration}s) is too long for the normalized first video ({norm_video1_duration}s)."
            )

        # 计算转场开始时间
        offset = norm_video1_duration - transition_duration

        # 构建 filter_complex
        filter_complex = f"[0:v][1:v]xfade=transition={transition_effect}:duration={transition_duration}:offset={offset}[v]"
        cmd = [
            FFMPEG_BINARY,
            "-i", norm_video1_path,
            "-i", norm_video2_path,
            "-filter_complex",
        ]

        if has_audio:
            filter_complex += f";[0:a][1:a]acrossfade=d={transition_duration}:c1=tri:c2=tri[a]"
            cmd.extend([filter_complex, "-map", "[v]", "-map", "[a]"])
        else:
            cmd.extend([filter_complex, "-map", "[v]"])

        cmd.extend(["-c:v", "libx264", "-c:a", "aac", "-y", output_video_path])

        try:
            subprocess.run(cmd, check=True, capture_output=True)
            return f"Videos concatenated successfully with '{transition_effect}' transition to {output_video_path}"
        except subprocess.CalledProcessError as e:
            raise RuntimeError(
                f"Error during xfade process: {e.stderr.decode('utf8') if e.stderr else str(e)}"
            )
    finally:
        shutil.rmtree(temp_dir)


def _concatenate_simple(video_paths: list[str], output_video_path: str) -> str:
    """简单拼接多个视频（无转场）"""
    temp_dir = tempfile.mkdtemp()
    try:
        # 获取第一个视频的属性作为目标参数
        first_props = _get_media_properties(video_paths[0])
        target_w = first_props["width"] if first_props["width"] > 0 else 1280
        target_h = first_props["height"] if first_props["height"] > 0 else 720
        target_fps = first_props["avg_fps"] if first_props["avg_fps"] > 0 else 30
        if target_fps <= 0:
            target_fps = 30

        # 标准化所有视频
        normalized_paths = []
        for i, video_path in enumerate(video_paths):
            norm_path = os.path.join(temp_dir, f"norm_{i}.mp4")
            try:
                subprocess.run(
                    [
                        FFMPEG_BINARY,
                        "-i", video_path,
                        "-vf", f"scale={target_w}:{target_h}",
                        "-r", str(target_fps),
                        "-c:v", "libx264",
                        "-pix_fmt", "yuv420p",
                        "-c:a", "aac",
                        "-y", norm_path,
                    ],
                    check=True,
                    capture_output=True,
                )
                normalized_paths.append(norm_path)
            except subprocess.CalledProcessError as e:
                raise RuntimeError(
                    f"Error normalizing video {i}: {e.stderr.decode('utf8') if e.stderr else str(e)}"
                )

        # 创建拼接列表文件
        concat_list_path = os.path.join(temp_dir, "concat_list.txt")
        with open(concat_list_path, "w") as f:
            for path in normalized_paths:
                f.write(f"file '{path}'\n")

        # 执行拼接
        try:
            subprocess.run(
                [
                    FFMPEG_BINARY,
                    "-f", "concat",
                    "-safe", "0",
                    "-i", concat_list_path,
                    "-c", "copy",
                    "-y", output_video_path,
                ],
                check=True,
                capture_output=True,
            )
            return f"Videos concatenated successfully to {output_video_path}"
        except subprocess.CalledProcessError as e:
            raise RuntimeError(
                f"Error during concatenation: {e.stderr.decode('utf8') if e.stderr else str(e)}"
            )
    finally:
        shutil.rmtree(temp_dir)


@mcp.tool()
def list_transition_effects() -> str:
    """列出所有支持的转场效果。

    Returns:
        所有可用转场效果的列表和说明。
    """
    effects_info = """
支持的转场效果:

【淡入淡出类】
- dissolve: 溶解过渡（推荐）
- fade: 渐变过渡
- fadeblack: 渐变到黑色
- fadewhite: 渐变到白色
- fadegrays: 灰度渐变

【擦除类】
- wipeleft: 从右向左擦除
- wiperight: 从左向右擦除
- wipeup: 从下向上擦除
- wipedown: 从上向下擦除

【滑动类】
- slideleft: 向左滑动
- slideright: 向右滑动
- slideup: 向上滑动
- slidedown: 向下滑动

【平滑类】
- smoothleft: 平滑向左
- smoothright: 平滑向右
- smoothup: 平滑向上
- smoothdown: 平滑向下

【圆形类】
- circlecrop: 圆形裁剪
- circleopen: 圆形展开
- circleclose: 圆形闭合

【矩形类】
- rectcrop: 矩形裁剪
- vertopen: 垂直展开
- vertclose: 垂直闭合
- horzopen: 水平展开
- horzclose: 水平闭合

【对角线类】
- diagtl: 对角线（左上）
- diagtr: 对角线（右上）
- diagbl: 对角线（左下）
- diagbr: 对角线（右下）

【切片类】
- hlslice: 水平左切片
- hrslice: 水平右切片
- vuslice: 垂直上切片
- vdslice: 垂直下切片

【其他】
- distance: 距离过渡
- pixelize: 像素化过渡
- radial: 径向过渡
- hblur: 水平模糊过渡
"""
    return effects_info


def main():
    """Main entry point for the MCP server."""
    mcp.run()


if __name__ == "__main__":
    main()
