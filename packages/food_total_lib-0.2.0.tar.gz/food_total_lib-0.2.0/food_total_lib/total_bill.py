from collections import Counter

def food_bill(product_queryset, product_ids):
    """
    product_queryset : Django queryset of product objects
    product_ids      : list of product IDs found in the cart

    Returns dict:
    {
        "total": <float>,
        "products": [
            {
                "id": <id>,
                "name": <name>,
                "price": <price>,
                "quantity": <count>
            }
        ]
    }
    """

    total = 0
    products_output = []

    # Count occurrences of each product ID
    id_counts = Counter(product_ids)

    # Loop through queryset and calculate totals
    for product in product_queryset:
        quantity = id_counts.get(str(product.id), 0)
        amount = product.price * quantity
        total += amount

        products_output.append({
            "id": product.id,
            "name": product.name,
            "price": product.price,
            "quantity": quantity,
            "subtotal": amount
        })

    return {
        "total": total,
        "products": products_output
    }

