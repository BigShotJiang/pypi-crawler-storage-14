
from .total_bill import food_bill

__version__ = "0.2.0"
__all__ = ["food_bill"]