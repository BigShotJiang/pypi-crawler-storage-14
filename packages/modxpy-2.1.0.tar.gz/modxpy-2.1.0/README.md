### **🌟 ModXPy — The Python Module Universe at Your Fingertips**



Welcome to ModXPy, the ultimate playground for Python’s modules.  
With ModXPy you can instantly import, explore, and experiment with the entire Python standard library — plus any installed third-party modules — all from one simple interface.



#### UPDATE 2.1.0



New function: modglobals(module)

Show a module's global names (not functions/classes/modules);

optional private names and Markdown export (may import typed module).



Tiny vcompat() polishes.

Tiny rework for one of modorigin()'s internal functions to replace a

deprecated function. Also improved filtering code.

Added testing function. Runs whenever you run the module itself

and not import it.



#### 🚀 Installation and Importing



Install directly from terminal.

Type: "pip install modxpy"



In Python, import as import modx (not modxpy)



#### Functions:



🔹 importall()

Imports about every standard library module at once.



🔹 importrandom(n)

Imports n random modules from the standard library.



🔹 importletter(letter)

Imports all standard library modules whose names start with the given letter.



🔹 importexternal()

Attempts to import every third-party module you currently have installed.



🔹 importscreen()

Imports every module that uses a screen/GUI (like pygame or turtle).



🔹 listimportall()

Returns a list of modules that would be imported by import\_all().



🔹 modsloaded()

Shows how many modules you currently have downloaded on your device.



🔹 imported()

Lists the modules imported since ModX loaded (user + ModX), including dependencies.



🔹 modximported()

Lists the modules that were ONLY imported by ModX, NOT including user imports

and dependencies.



🔹 importletter(letter)

Import every standard library module from the ModX 'modules' list
whose name starts with the given letter (case-insensitive).



🔹 searchmodules(keyword)

Search for modules whose names contain the keyword.



🔹 info(module\_name)

Shows basic info about typed module: file path, built-in status, docstring.



🔹 isimported(module)

Checks if module is currently imported into Python Shell (Not Pythonlib)



🔹 dependencies()

Shows what other modules a specific module depends on without importing it.



🔹 vcompat(module\_name, python\_version)

Checks if a module is compatible with a python version, if a version was given.



🔹 modfunctions(module)

Show how many and what functions a module has without importing it.



🔹 modxhelp()

Shows ModX's built in help dialogue.



🔹 modclasses(module)

Show how many and what classes a module has without importing it.



🔹 modorigin(module)

Shows where a module came from (e.g. built-in, stndlib or pip-installed).



🔹 modbench(n)

Shows how much time and memory a module takes to import
(typed modules DOES get imported)



🔹 revdeps(module)

Shows what modules import typed module without importing it.



🔹 modglobals(module)

Show a module's global names (not functions/classes/modules);

optional private names and Markdown export (may import typed module).



#### 💡 Why Use ModX?



1.) Explore the Python standard library in seconds
2.) Stress-test your environment by bulk importing modules
3.) See hidden dependencies that load behind the scenes
4.) Experiment with random imports for fun or testing
5.) Discover new modules you didn’t know existed



ModXPy turns Python’s module system into a playground —
perfect for learning, testing, or just satisfying your curiosity.
Install it today with pip install modxpy, import it with import modx,
and start discovering how many modules Python already has waiting for you!

