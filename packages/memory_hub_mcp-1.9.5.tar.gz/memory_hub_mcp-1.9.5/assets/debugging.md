 Issue: search_memories ignores metadata_filters

  Reproduction:
  1. Store a memory with app_id: "claude-flow", project_id: "test-swarm-001"
  2. Search with query_text: "integration test", metadata_filters: {"app_id": "claude-flow"} → 0 results
  3. Search with query_text: "integration test" (no filters) → Finds it

  Expected: Filtered search should return the memory since it matches the filter.

  Evidence: The memory exists - get_recent_memories and unfiltered search_memories both find it. Only filtered search fails.

  Likely cause: The metadata_filters parameter might not be applied to the Qdrant query correctly, or there's a field name mismatch.