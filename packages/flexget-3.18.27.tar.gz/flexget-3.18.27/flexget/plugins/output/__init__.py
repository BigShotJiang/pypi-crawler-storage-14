"""Plugins for "output" task phase."""
