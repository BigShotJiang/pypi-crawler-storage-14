"""Standard plugin package."""
