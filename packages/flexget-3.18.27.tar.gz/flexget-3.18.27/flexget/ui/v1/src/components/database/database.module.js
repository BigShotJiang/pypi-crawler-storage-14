/* global angular */
(function () {
  'use strict';

  angular.module('components.database', ['ngMaterial', 'components.toolbar']);
})();
