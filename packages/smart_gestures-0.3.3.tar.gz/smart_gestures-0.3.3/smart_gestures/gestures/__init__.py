"""
SmartGlasses Gesture Recognition Gestures Package

Top-level package that exposes subpackages `lstm_model`.

"""

from . import lstm_model

__all__ = [
    "lstm_model",
]
