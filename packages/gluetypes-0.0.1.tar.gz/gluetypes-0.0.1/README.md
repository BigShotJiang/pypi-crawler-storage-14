# gluetypes

Glue types together.
