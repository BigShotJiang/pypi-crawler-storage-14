<!-- This file is generated. DO NOT EDIT -->

# uv-normalize

This crate is an internal component of [uv](https://crates.io/uv). The Rust API exposed here is
unstable and will have frequent breaking changes.

See uv's
[crate versioning policy](https://docs.astral.sh/uv/reference/policies/versioning/#crate-versioning)
for details on versioning.
