from dataclasses import dataclass
from .core import xor_with_key,score_printable
from .entropy import entropy_delta_score
@dataclass
class GuessResult: key:bytes; plaintext:bytes; score:float
def brute_guess_small_keys(d,max_len=4,limit=32):
    if not d: return None
    mags=[b'MZ',b'PK',b'\x7fELF',b'%PDF']
    best=None; samp=d[:limit]
    for m in mags:
        if len(samp)<len(m): continue
        key=bytes(s^t for s,t in zip(samp[:len(m)],m))
        if not(1<=len(key)<=max_len): continue
        pt=xor_with_key(d,key)
        s=.6*score_printable(pt[:256])+.4*entropy_delta_score(d[:256],pt[:256])
        if not best or s>best.score: best=GuessResult(key,pt,s)
    return best
def sliding_window_key_guess(d,w=256):
    if len(d)<w: w=len(d)
    if not w: return None
    from .single_byte import crack_single_byte_xor
    best=None; step=max(1,w//4)
    for off in range(0,len(d)-w+1,step):
        chunk=d[off:off+w]; r=crack_single_byte_xor(chunk)
        if r.score<0.2: continue
        key=r.key; pt=xor_with_key(d,key)
        s=.5*score_printable(pt[:512])+.5*entropy_delta_score(d[:512],pt[:512])
        if not best or s>best.score: best=GuessResult(key,pt,s)
    return best
