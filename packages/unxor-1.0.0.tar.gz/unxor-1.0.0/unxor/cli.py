import argparse
from .pipeline import UnxorPipeline
def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('input'); ap.add_argument('-o','--output')
    a=ap.parse_args()
    data=open(a.input,'rb').read()
    r=UnxorPipeline().run(data)
    print('[+] Method:',r.source)
    print('[+] Key:',r.key.hex())
    if a.output:
        open(a.output,'wb').write(r.plaintext)
        print('[+] Wrote to',a.output)
