from dataclasses import dataclass
from .single_byte import crack_single_byte_xor
from .repeating_key import crack_repeating_xor
from .guessers import brute_guess_small_keys,sliding_window_key_guess
from .plugins import load_plugins
@dataclass
class Candidate: key:bytes; plaintext:bytes; score:float; source:str
class UnxorPipeline:
    def __init__(self): self.plugins=load_plugins()
    def run(self,d):
        c=[]
        sb=crack_single_byte_xor(d); c.append(Candidate(sb.key,sb.plaintext,sb.score,'single-byte'))
        rk=crack_repeating_xor(d)
        if rk: c.append(Candidate(rk.key,rk.plaintext,rk.score,'repeating-key'))
        sk=brute_guess_small_keys(d)
        if sk: c.append(Candidate(sk.key,sk.plaintext,sk.score,'small-key'))
        sw=sliding_window_key_guess(d)
        if sw: c.append(Candidate(sw.key,sw.plaintext,sw.score,'window'))
        for p in self.plugins:
            try:
                r=p.solve(d)
                if r: c.append(r)
            except: pass
        return max(c,key=lambda x:x.score)
