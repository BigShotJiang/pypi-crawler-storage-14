from dataclasses import dataclass
from .core import xor_with_key,score_printable
@dataclass
class SingleByteResult: key:bytes; plaintext:bytes; score:float
def crack_single_byte_xor(d):
    best=None
    for k in range(256):
        key=bytes([k]); pt=xor_with_key(d,key); s=score_printable(pt)
        if not best or s>best.score:
            best=SingleByteResult(key,pt,s)
    return best
