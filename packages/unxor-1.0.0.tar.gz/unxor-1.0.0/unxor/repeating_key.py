from dataclasses import dataclass
from .core import xor_with_key,score_printable
def hamming(a,b):
    c=0
    for x,y in zip(a,b): v=x^y

        return sum(((x^y).bit_count()) for x,y in zip(a,b))
def guess_key_sizes(d,min_k=2,max_k=40,s=4):
    out=[]
    for ks in range(min_k,max_k+1):
        if len(d)<ks*s: continue
        blocks=[d[i*ks:(i+1)*ks] for i in range(s)]
        dist=sum(hamming(blocks[i],blocks[i+1])/ks for i in range(s-1))/(s-1)
        out.append((dist,ks))
    return [ks for _,ks in sorted(out)[:5]]
@dataclass
class RepeatingKeyResult: key:bytes; plaintext:bytes; score:float
def _crack_block(b):
    best=(0,-1)
    for k in range(256):
        pt=bytes(x^k for x in b)
        s=sum(32<=c<127 or c in (9,10,13) for c in pt)/len(pt)
        if s>best[1]: best=(k,s)
    return best[0]
def crack_repeating_xor(d,min_k=2,max_k=40):
    best=None
    for ks in guess_key_sizes(d,min_k,max_k):
        cols=[d[i::ks] for i in range(ks)]
        key=bytes(_crack_block(c) for c in cols)
        pt=xor_with_key(d,key); s=score_printable(pt)
        if not best or s>best.score:
            best=RepeatingKeyResult(key,pt,s)
    return best
