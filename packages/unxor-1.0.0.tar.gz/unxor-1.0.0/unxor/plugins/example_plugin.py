from ..core import xor_with_key,score_printable
from ..entropy import entropy_delta_score
from ..pipeline import Candidate
def solve(d):
    if not d: return None
    pt=xor_with_key(d,b"\x00")
    s=.7*score_printable(pt[:256])+.3*entropy_delta_score(d[:256],pt[:256])
    if s>0.8: return Candidate(b"\x00",pt,s,"plugin:id-check")
    return None
