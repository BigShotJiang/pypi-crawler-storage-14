def load_plugins():
    try:
        from . import example_plugin
        return [example_plugin]
    except:
        return []
