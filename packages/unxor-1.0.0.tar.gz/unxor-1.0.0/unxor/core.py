PRINTABLE=set(range(32,127))|{9,10,13}
def xor_with_key(d,k):
    return bytes(b^k[i%len(k)] for i,b in enumerate(d))
def score_printable(d):
    return sum(b in PRINTABLE for b in d)/len(d) if d else 0
