import math
def entropy(d):
    f={};
        [f.setdefault(b,0) or f.__setitem__(b,f[b]+1) for b in d]
    tot=len(d)
    return -sum((c/tot)*math.log2(c/tot) for c in f.values() if c)
def entropy_delta_score(o,n):
    return max(0,entropy(o)-entropy(n))
