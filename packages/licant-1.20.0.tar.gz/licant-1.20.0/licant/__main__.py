import licant.licant_libs

licant.licant_libs.licant_libs_utility()