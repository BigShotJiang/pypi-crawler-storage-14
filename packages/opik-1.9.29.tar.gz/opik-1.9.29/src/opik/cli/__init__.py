"""CLI commands for Opik."""

from .main import cli

__all__ = ["cli"]
