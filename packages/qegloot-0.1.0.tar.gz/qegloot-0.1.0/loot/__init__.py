"""
Loot - Repositorio central de ativos de automacao e bibliotecas compartilhadas.

Steal like an artist :)
"""

__version__ = "0.1.0"

from . import parsers

__all__ = ["parsers"]
