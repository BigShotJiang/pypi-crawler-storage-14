To use this module, you need to:

- Edit any partner's form.
- Make sure the partner is not a company.
- Enter firstname, lastnames, secondlast name.

If you directly enter the full name instead of entering the other fields
separately (maybe from other form), this module will try to guess the
best match for your input and split it between firstname, lastname and
second lastname using an inverse function.

If you can, always enter it manually please. Automatic guessing could
fail for you easily in some corner cases.
