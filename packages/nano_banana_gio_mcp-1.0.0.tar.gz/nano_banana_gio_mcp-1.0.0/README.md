# Nano Banana MCP

MCP server pour générer des images avec Gemini.

## Installation
```bash
uvx install nano-banana-mcp
```

## Configuration

Ajoute dans `~/Library/Application Support/Claude/claude_desktop_config.json` :
```json
{
  "mcpServers": {
    "nano-banana": {
      "command": "uvx",
      "args": ["nano-banana-mcp"],
      "env": {
        "GEMINI_API_KEY": "TA_CLE_GEMINI"
      }
    }
  }
}
```

Redémarre Claude Desktop.

## Features

- Génération d'images avec Gemini Flash/Pro
- Support des images de référence (UNIQUEMENT avec lien de chemin OU avec URL, impossible d'upload les images de façon classique dans le LLM pour le moment)
- Ratios personnalisés et résolutions 1K, 2K ou 4K au choix. Calculez vos coûts intelligemment, la 4K c'est bien mais ça coûte une blinde sur un gros volume.
```