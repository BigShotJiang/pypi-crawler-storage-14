# Container Image + Python PKG - pve-cloud-backup

Python package and docker image that form the base for backing up pve cloud k8s namespaces, aswell as git repos, nextcloud files and postgres dumps.
