"""
Linux namespace-based sandbox implementation.

Uses Linux namespaces for isolation without requiring Docker.
Includes strace-based security monitoring for file and network access.
"""

import subprocess
import os
import logging
import threading
import time
import re
import shutil
from typing import Dict, Any, List, Optional, Set

from .base import SandboxBase

logger = logging.getLogger(__name__)

# BUG-L001 FIX: Add try/except for psutil import like Windows/macOS
try:
    import psutil
    PSUTIL_AVAILABLE = True
except ImportError:
    PSUTIL_AVAILABLE = False
    logger.warning("psutil not available - limited stats")

# Check if strace is available
STRACE_AVAILABLE = shutil.which('strace') is not None

# Sensitive file patterns that should trigger security alerts
SENSITIVE_PATHS = [
    '/etc/passwd',
    '/etc/shadow',
    '/etc/sudoers',
    '/etc/ssh/',
    '/.ssh/',
    '/id_rsa',
    '/id_ed25519',
    '/.aws/',
    '/.kube/',
    '/.docker/',
    '/credentials',
    '/secrets',
    '/.env',
    '/token',
    '/api_key',
    '/private_key',
]

# Suspicious network ports
SUSPICIOUS_PORTS = {
    22: 'SSH',
    23: 'Telnet',
    3389: 'RDP',
    4444: 'Metasploit',
    5555: 'Android Debug',
    6666: 'IRC/Backdoor',
    6667: 'IRC',
    31337: 'Back Orifice',
}

# Dangerous syscalls that might indicate malicious behavior
DANGEROUS_SYSCALLS = [
    'ptrace',      # Process tracing/debugging
    'process_vm_readv',  # Read another process memory
    'process_vm_writev', # Write another process memory
    'init_module',  # Load kernel module
    'finit_module', # Load kernel module
    'delete_module', # Unload kernel module
    'reboot',       # System reboot
    'sethostname',  # Change hostname
    'setdomainname', # Change domain name
    'kexec_load',   # Load new kernel
]


class LinuxNamespaceSandbox(SandboxBase):
    """Linux namespace-based sandboxing with security monitoring"""

    def __init__(self, agent_id: str, limits: Dict[str, Any], config: Dict[str, Any]):
        super().__init__(agent_id, limits, config)
        self.monitor_thread = None
        self.strace_thread = None
        self.actions_log = []
        self.security_events = []
        self.file_access_log: List[Dict[str, Any]] = []
        self.network_access_log: List[Dict[str, Any]] = []
        self.syscall_log: List[Dict[str, Any]] = []
        self.strace_process: Optional[subprocess.Popen] = None
        # BUG-L003 FIX: Initialize workspace to prevent AttributeError in cleanup
        self.workspace = None
        # Track unique files and connections for summary
        self.files_read: Set[str] = set()
        self.files_written: Set[str] = set()
        self.network_connections: Set[str] = set()

    def setup(self):
        """Prepare Linux namespace sandbox"""
        logger.info(f"Setting up Linux namespace sandbox for agent {self.agent_id}")

        # Verify we're on Linux
        if not os.path.exists('/proc'):
            raise RuntimeError("Linux /proc filesystem not found")

        # Create temp directory for agent if needed
        self.workspace = f"/tmp/sudodog-{self.agent_id}"
        os.makedirs(self.workspace, exist_ok=True)

        # Log strace availability
        if STRACE_AVAILABLE:
            logger.info("strace available - security monitoring enabled")
        else:
            logger.warning("strace not available - install for enhanced security monitoring")

    def run(self, command: List[str]) -> int:
        """
        Execute command in Linux namespace with security monitoring.

        Uses unshare for namespace isolation and strace for syscall tracking.
        """
        self.setup()
        self._running = True

        # Build unshare command for namespace isolation
        # Isolate: network, mount, IPC, UTS (hostname), PID
        unshare_flags = []

        # Check both config keys for network isolation
        # --no-network flag sets allow_network=False
        if self.config.get('isolate_network', False) or not self.config.get('allow_network', True):
            unshare_flags.append('--net')  # Network namespace

        if self.config.get('isolate_mount', True):
            unshare_flags.append('--mount')  # Mount namespace

        # Build final command
        if unshare_flags and os.geteuid() == 0:  # Only if root
            final_command = ['unshare'] + unshare_flags + ['--'] + command
            logger.info(f"Running with namespace isolation: {' '.join(final_command)}")
        else:
            final_command = command
            logger.warning("Running without namespace isolation (not root or disabled)")

        # Wrap with strace if available and security monitoring enabled
        use_strace = STRACE_AVAILABLE and self.config.get('security_monitoring', True)
        strace_output_file = None

        if use_strace:
            strace_output_file = os.path.join(self.workspace, 'strace.log')
            # Trace file, network, and process syscalls
            strace_cmd = [
                'strace',
                '-f',  # Follow forks
                '-e', 'trace=open,openat,read,write,connect,socket,execve,unlink,rename',
                '-e', 'signal=none',  # Don't trace signals
                '-o', strace_output_file,
                '--'
            ] + final_command
            final_command = strace_cmd
            logger.info("Security monitoring enabled via strace")

        # Set resource limits using cgroups (if available)
        env = os.environ.copy()

        # Start process
        try:
            self.process = subprocess.Popen(
                final_command,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                env=env,
                cwd=self.workspace
            )

            logger.info(f"Started process PID {self.process.pid}")

            # Start monitoring thread
            self.monitor_thread = threading.Thread(
                target=self.monitor_loop,
                daemon=True
            )
            self.monitor_thread.start()

            # Wait for completion
            stdout, stderr = self.process.communicate()

            exit_code = self.process.returncode

            # Parse strace output for security analysis
            if use_strace and strace_output_file and os.path.exists(strace_output_file):
                self._parse_strace_output(strace_output_file)

            # Send final security summary to dashboard
            self._send_final_telemetry(exit_code)

            # Display output to user (not just debug log)
            if stdout:
                print(stdout.decode('utf-8', errors='replace'), end='')
            if stderr:
                import sys
                print(stderr.decode('utf-8', errors='replace'), end='', file=sys.stderr)

            # Display security summary
            self._display_security_summary()

            logger.info(f"Process completed with exit code {exit_code}")

            return exit_code

        except Exception as e:
            logger.error(f"Error running command: {e}")
            raise

        finally:
            self._running = False
            self.cleanup()

    def _parse_strace_output(self, strace_file: str):
        """Parse strace output to extract security-relevant events"""
        try:
            with open(strace_file, 'r', errors='replace') as f:
                for line in f:
                    self._parse_strace_line(line.strip())
        except Exception as e:
            logger.error(f"Error parsing strace output: {e}")

    def _parse_strace_line(self, line: str):
        """Parse a single strace line and extract security events"""
        if not line:
            return

        timestamp = time.time()

        # Parse open/openat syscalls for file access
        # Example: openat(AT_FDCWD, "/etc/passwd", O_RDONLY) = 3
        open_match = re.search(r'open(?:at)?\([^,]*,\s*"([^"]+)"[^)]*([A-Z_|]+)', line)
        if open_match:
            filepath = open_match.group(1)
            flags = open_match.group(2)

            operation = 'read'
            if 'O_WRONLY' in flags or 'O_RDWR' in flags or 'O_CREAT' in flags:
                operation = 'write'
                self.files_written.add(filepath)
            else:
                self.files_read.add(filepath)

            self.file_access_log.append({
                'type': 'file',
                'operation': operation,
                'path': filepath,
                'flags': flags,
                'timestamp': timestamp
            })

            # Check for sensitive file access
            self._check_sensitive_file(filepath, operation)
            return

        # Parse connect syscalls for network access
        # Example: connect(3, {sa_family=AF_INET, sin_port=htons(443), sin_addr=inet_addr("1.2.3.4")}, 16) = 0
        connect_match = re.search(
            r'connect\(\d+,\s*\{[^}]*sin_port=htons\((\d+)\)[^}]*sin_addr=inet_addr\("([^"]+)"\)',
            line
        )
        if connect_match:
            port = int(connect_match.group(1))
            ip = connect_match.group(2)

            connection = f"{ip}:{port}"
            self.network_connections.add(connection)

            self.network_access_log.append({
                'type': 'network',
                'operation': 'connect',
                'ip': ip,
                'port': port,
                'timestamp': timestamp
            })

            # Check for suspicious ports
            self._check_suspicious_port(ip, port)
            return

        # Parse execve for process execution
        # Example: execve("/bin/sh", ["sh", "-c", "..."], ...) = 0
        exec_match = re.search(r'execve\("([^"]+)"', line)
        if exec_match:
            executable = exec_match.group(1)
            self.syscall_log.append({
                'type': 'exec',
                'path': executable,
                'timestamp': timestamp
            })

            # Check for shell spawning (potential escape attempt)
            if any(shell in executable for shell in ['/bin/sh', '/bin/bash', '/bin/zsh', '/bin/fish']):
                self._detect_threat('shell_spawn', {
                    'executable': executable,
                    'description': 'Agent spawned a shell process'
                })
            return

        # Check for dangerous syscalls
        for syscall in DANGEROUS_SYSCALLS:
            if line.startswith(syscall + '(') or f' {syscall}(' in line:
                self._detect_threat('dangerous_syscall', {
                    'syscall': syscall,
                    'line': line[:200],  # Truncate for logging
                    'description': f'Dangerous syscall detected: {syscall}'
                })
                break

    def _check_sensitive_file(self, filepath: str, operation: str):
        """Check if file access involves sensitive files"""
        filepath_lower = filepath.lower()

        for sensitive in SENSITIVE_PATHS:
            if sensitive.lower() in filepath_lower:
                self._detect_threat('sensitive_file_access', {
                    'path': filepath,
                    'operation': operation,
                    'pattern_matched': sensitive,
                    'description': f'Agent accessed sensitive file: {filepath}'
                })
                return

    def _check_suspicious_port(self, ip: str, port: int):
        """Check if network connection is to a suspicious port"""
        if port in SUSPICIOUS_PORTS:
            self._detect_threat('suspicious_port', {
                'ip': ip,
                'port': port,
                'service': SUSPICIOUS_PORTS[port],
                'description': f'Connection to suspicious port: {port} ({SUSPICIOUS_PORTS[port]})'
            })

    def _display_security_summary(self):
        """Display a summary of security-relevant activity"""
        print("\n" + "─" * 50)
        print("🔒 Security Summary")
        print("─" * 50)

        # File access summary
        if self.files_read or self.files_written:
            print(f"\n📁 File Access:")
            if self.files_read:
                # Show up to 10 files, sorted
                files_to_show = sorted(self.files_read)[:10]
                print(f"   Read: {len(self.files_read)} files")
                for f in files_to_show:
                    print(f"      • {f}")
                if len(self.files_read) > 10:
                    print(f"      ... and {len(self.files_read) - 10} more")
            if self.files_written:
                files_to_show = sorted(self.files_written)[:10]
                print(f"   Written: {len(self.files_written)} files")
                for f in files_to_show:
                    print(f"      • {f}")
                if len(self.files_written) > 10:
                    print(f"      ... and {len(self.files_written) - 10} more")

        # Network summary
        if self.network_connections:
            print(f"\n🌐 Network Connections: {len(self.network_connections)}")
            for conn in sorted(self.network_connections)[:10]:
                print(f"   • {conn}")
            if len(self.network_connections) > 10:
                print(f"   ... and {len(self.network_connections) - 10} more")

        # Security alerts
        if self.security_events:
            print(f"\n⚠️  Security Alerts: {len(self.security_events)}")
            for event in self.security_events:
                severity = "🔴" if event['type'] in ['dangerous_syscall', 'sensitive_file_access'] else "🟡"
                print(f"   {severity} [{event['type']}] {event['details'].get('description', '')}")
        else:
            print(f"\n✅ No security alerts")

        print("─" * 50 + "\n")

    def get_stats(self) -> Dict[str, Any]:
        """Get Linux process stats using psutil"""
        # BUG-L002 FIX: Provide meaningful fallback stats instead of empty dict
        if not self.process:
            return {
                "status": "no_process",
                "error": "Process not started"
            }

        if not PSUTIL_AVAILABLE:
            return {
                "status": "limited",
                "pid": self.process.pid,
                "running": self.process.poll() is None,
                "error": "psutil not available - install with: pip install psutil"
            }

        try:
            proc = psutil.Process(self.process.pid)

            # Get comprehensive stats
            stats = {
                "status": "ok",
                "pid": self.process.pid,
                "cpu_percent": proc.cpu_percent(interval=0.1),
                "memory_bytes": proc.memory_info().rss,
                "memory_percent": proc.memory_percent(),
                "num_threads": proc.num_threads(),
                "num_fds": proc.num_fds() if hasattr(proc, 'num_fds') else 0,
            }

            # IO counters (if available)
            try:
                io = proc.io_counters()
                stats["io_counters"] = {
                    "read_bytes": io.read_bytes,
                    "write_bytes": io.write_bytes,
                    "read_count": io.read_count,
                    "write_count": io.write_count
                }
            except (psutil.AccessDenied, AttributeError):
                stats["io_counters"] = {}

            # Network connections
            try:
                connections = proc.connections()
                stats["network_connections"] = len(connections)
            except (psutil.AccessDenied, psutil.NoSuchProcess):
                stats["network_connections"] = 0

            return stats

        except psutil.NoSuchProcess:
            return {
                "status": "exited",
                "pid": self.process.pid,
                "running": False
            }
        except Exception as e:
            logger.error(f"Error getting stats: {e}")
            return {
                "status": "error",
                "pid": self.process.pid,
                "error": str(e)
            }

    def cleanup(self):
        """Clean up Linux namespace sandbox"""
        logger.info("Cleaning up Linux sandbox")

        # Kill strace process if running
        if self.strace_process and self.strace_process.poll() is None:
            try:
                self.strace_process.terminate()
                self.strace_process.wait(timeout=2)
            except:
                pass

        # Kill process if still running
        if self.process and self.process.poll() is None:
            try:
                self.process.terminate()
                self.process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                self.process.kill()
                self.process.wait()

        # Clean up workspace (optional)
        # We keep it for debugging by default
        # import shutil
        # if os.path.exists(self.workspace):
        #     shutil.rmtree(self.workspace)

    def get_platform_name(self) -> str:
        """Return 'linux'"""
        return "linux"

    def get_recent_actions(self) -> List[Dict[str, Any]]:
        """Get recent file and network actions tracked by strace"""
        actions = (
            self.file_access_log[-100:] +  # Last 100 file operations
            self.network_access_log[-50:] +  # Last 50 network operations
            self.syscall_log[-50:]  # Last 50 exec operations
        )
        return sorted(actions, key=lambda x: x.get('timestamp', 0))

    def check_security_patterns(self) -> Dict[str, Any]:
        """Get security analysis results"""
        return {
            "threats_detected": len(self.security_events),
            "security_events": self.security_events.copy(),
            "files_read": len(self.files_read),
            "files_written": len(self.files_written),
            "network_connections": len(self.network_connections),
            "timestamp": time.time()
        }

    def _track_file_access(self, filepath: str, operation: str):
        """Track file access (used by strace parser)"""
        self.actions_log.append({
            "type": "file",
            "operation": operation,
            "path": filepath,
            "timestamp": time.time()
        })

    def _detect_threat(self, threat_type: str, details: Dict[str, Any]):
        """Record a security threat detection"""
        self.security_events.append({
            "type": threat_type,
            "details": details,
            "timestamp": time.time()
        })

    def _send_final_telemetry(self, exit_code: int):
        """Send final security summary to dashboard after strace parsing"""
        from ..core.telemetry import TelemetryService

        telemetry = TelemetryService(self.config)

        try:
            telemetry.send({
                "agent_id": self.agent_id,
                "event_type": "agent_complete",
                "timestamp": time.time(),
                "platform": self.get_platform_name(),
                "exit_code": exit_code,
                "security_summary": {
                    "files_read": len(self.files_read),
                    "files_written": len(self.files_written),
                    "files_read_list": list(self.files_read)[:100],  # Top 100
                    "files_written_list": list(self.files_written)[:100],
                    "network_connections": len(self.network_connections),
                    "network_connections_list": list(self.network_connections)[:50],
                    "security_events": self.security_events,
                    "threats_detected": len(self.security_events),
                },
                "actions_summary": {
                    "total_file_operations": len(self.file_access_log),
                    "total_network_operations": len(self.network_access_log),
                    "total_exec_operations": len(self.syscall_log),
                }
            })
            logger.debug("Final security telemetry sent to dashboard")
        except Exception as e:
            logger.warning(f"Failed to send final telemetry: {e}")
