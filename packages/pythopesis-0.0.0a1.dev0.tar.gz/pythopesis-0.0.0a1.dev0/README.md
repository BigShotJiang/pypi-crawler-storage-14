# Pythopesis

[![License: MIT](https://img.shields.io/badge/License-MIT-green.svg)](LICENSE)
[![Python versions](https://img.shields.io/badge/Python-3.11%20•%203.12%20•%203.13%20•%203.14-blue?logo=python)](https://www.python.org/)
[![Code style: ruff](https://img.shields.io/badge/code%20style-ruff-000000.svg?logo=ruff)](https://github.com/astral-sh/ruff)

A Python CLI & Python Package for managing research project templates and configurations.

> Last updated: December 1, 2025

## 🚀 Getting Started

Install dependencies:

```bash
make install
```

Run tests:

```bash
make test
```

## 📋 Available Tasks

Run `make help` to see all available targets.

## Testing your documentation

Python code blocks in README.md are automatically tested:

```python
import math
print("Hello, World!")
print(1 + 1)
```

Expected output:

```result
Hello, World!
2
```

## 📄 License

This project is licensed under the MIT License - see the LICENSE file for details.

## 🙏 Acknowledgments

Special thanks to [.config-templates](https://github.com/tschm/.config-templates) for providing the configuration templates and tooling setup that power this project.

