#  (C) 2024 GoodData Corporation
from tests.utils.multiple_methods_module.mock_methods import (
    anotherMockMethodsFactory,  # noqa: F401
    mockMethodsFactory,  # noqa: F401
)
