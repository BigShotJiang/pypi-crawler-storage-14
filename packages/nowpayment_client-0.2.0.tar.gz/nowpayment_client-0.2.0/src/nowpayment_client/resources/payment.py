# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import httpx

from ..types import payment_list_params, payment_create_params
from .._types import Body, Query, Headers, NotGiven, not_given
from .._utils import maybe_transform, async_maybe_transform
from .._compat import cached_property
from .._resource import SyncAPIResource, AsyncAPIResource
from .._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from .._base_client import make_request_options
from ..types.payment_list_response import PaymentListResponse
from ..types.payment_create_response import PaymentCreateResponse
from ..types.payment_retrieve_response import PaymentRetrieveResponse
from ..types.payment_update_estimate_response import PaymentUpdateEstimateResponse

__all__ = ["PaymentResource", "AsyncPaymentResource"]


class PaymentResource(SyncAPIResource):
    @cached_property
    def with_raw_response(self) -> PaymentResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/greatpie/nofa-nowpayment-client#accessing-raw-response-data-eg-headers
        """
        return PaymentResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> PaymentResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/greatpie/nofa-nowpayment-client#with_streaming_response
        """
        return PaymentResourceWithStreamingResponse(self)

    def create(
        self,
        *,
        ipn_callback_url: str,
        is_fee_paid_by_user: bool,
        is_fixed_rate: bool,
        order_description: str,
        order_id: str,
        pay_currency: str,
        price_amount: float,
        price_currency: str,
        x_api_key: str,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> PaymentCreateResponse:
        """Creates payment.

        With this method, your customer will be able to complete the
        payment without leaving your website.
        **Data must be sent as a JSON-object payload.**
        Required request fields:

        - price_amount (required) - the fiat equivalent of the price to be paid in
          crypto. If the pay_amount parameter is left empty, our system will
          automatically convert this fiat price into its crypto equivalent. Please note
          that this does not enable fiat payments, only provides a fiat price for yours
          and the customer’s convenience and information. **NOTE: Some of the assets
          (KISHU, NWC, FTT, CHR, XYM, SRK, KLV, SUPER, OM, XCUR, NOW, SHIB, SAND, MATIC,
          CTSI, MANA, FRONT, FTM, DAO, LGCY), have a maximum price amount of \\~~$2000;**
        - price_currency (required) - the fiat currency in which the price_amount is
          specified (usd, eur, etc);
        - pay_amount (optional) - the amount that users have to pay for the order stated
          in crypto. You can either specify it yourself, or we will automatically
          convert the amount you indicated in price_amount;
        - pay_currency (required) - the crypto currency in which the pay_amount is
          specified (btc, eth, etc), or one of available fiat currencies if it's enabled
          for your account (USD, EUR, ILS, GBP, AUD, RON);
           **NOTE: some of the currencies require a Memo, Destination Tag, etc., to complete
          a payment (AVA, EOS, BNBMAINNET, XLM, XRP). This is unique for each payment. This
          ID is received in “payin_extra_id” parameter of the response. Payments made without
          "payin_extra_id" cannot be detected automatically;**
        - ipn_callback_url (optional) - url to receive callbacks, should contain "http"
          or "https", eg. "[https://nowpayments.io"](https://nowpayments.io);
        - order_id (optional) - inner store order ID, e.g. "RGDBP-21314";
        - order_description (optional) - inner store order description, e.g. "Apple
          Macbook Pro 2019 x 1";
        - payout_address (optional) - usually the funds will go to the address you
          specify in your Personal account. In case you want to receive funds on another
          address, you can specify it in this parameter;
        - payout_currency (optional) - currency of your external payout_address,
          required when payout_adress is specified;
        - payout_extra_id(optional) - extra id or memo or tag for external
          payout_address;
        - is_fixed_rate(optional) - boolean, can be **true** or **false**. Required for
          fixed-rate exchanges;
           NOTE: the rate of exchange will be frozen for 20 minutes. If there are no incoming
          payments during this period, the payment status changes to "expired".
        - is_fee_paid_by_user(optional) - boolean, can be **true** or **false**.
          Required for fixed-rate exchanges with all fees paid by users;
           NOTE: the rate of exchange will be frozen for 20 minutes. If there are no incoming
          payments during this period, the payment status changes to "expired";

        Here the list of available statuses of payment:

        - waiting - waiting for the customer to send the payment. The initial status of
          each payment;
        - confirming - the transaction is being processed on the blockchain. Appears
          when NOWPayments detect the funds from the user on the blockchain;
           **Please note:** each currency has its own amount of confirmations requires to
          start the processing.
        - confirmed - the process is confirmed by the blockchain. Customer’s funds have
          accumulated enough confirmations;
        - sending - the funds are being sent to your personal wallet. We are in the
          process of sending the funds to you;
        - partially_paid - it shows that the customer sent the less than the actual
          price. Appears when the funds have arrived in your wallet;
        - finished - the funds have reached your personal address and the payment is
          finished;
        - failed - the payment wasn't completed due to the error of some kind;
        - expired - the user didn't send the funds to the specified address in the 7
          days time window;

        **Please note: when you're creating a fiat2crypto payment you also should
        include additional header to your request - "origin-ip : xxx", where xxx is your
        customer IP address.**

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {"x-api-key": x_api_key, **(extra_headers or {})}
        return self._post(
            "/v1/payment",
            body=maybe_transform(
                {
                    "ipn_callback_url": ipn_callback_url,
                    "is_fee_paid_by_user": is_fee_paid_by_user,
                    "is_fixed_rate": is_fixed_rate,
                    "order_description": order_description,
                    "order_id": order_id,
                    "pay_currency": pay_currency,
                    "price_amount": price_amount,
                    "price_currency": price_currency,
                },
                payment_create_params.PaymentCreateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=PaymentCreateResponse,
        )

    def retrieve(
        self,
        payment_id: str,
        *,
        x_api_key: str,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> PaymentRetrieveResponse:
        """Get the actual information about the payment.

        You need to provide the ID of the
        payment in the request.

        NOTE! You should make the get payment status request with the same API key that
        you used in the create payment request.
        Here is the list of available statuses:

        - waiting - waiting for the customer to send the payment. The initial status of
          each payment;
        - confirming - the transaction is being processed on the blockchain. Appears
          when NOWPayments detect the funds from the user on the blockchain;
        - confirmed - the process is confirmed by the blockchain. Customer’s funds have
          accumulated enough confirmations;
        - sending - the funds are being sent to your personal wallet. We are in the
          process of sending the funds to you;
        - partially_paid - it shows that the customer sent the less than the actual
          price. Appears when the funds have arrived in your wallet;
        - finished - the funds have reached your personal address and the payment is
          finished;
        - failed - the payment wasn't completed due to the error of some kind;
        - refunded - the funds were refunded back to the user;
        - expired - the user didn't send the funds to the specified address in the 7
          days time window;

        Additional info:

        - outcome_amount - this parameter shows the amount that will be (or is already)
          received on your Outcome Wallet once the transaction is settled;
        - outcome_currency - this parameter shows the currency in which the transaction
          will be settled;
        - invoice_id - this parameter shows invoice ID from which the payment was
          created;

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not payment_id:
            raise ValueError(f"Expected a non-empty value for `payment_id` but received {payment_id!r}")
        extra_headers = {"x-api-key": x_api_key, **(extra_headers or {})}
        return self._get(
            f"/v1/payment/{payment_id}",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=PaymentRetrieveResponse,
        )

    def list(
        self,
        *,
        date_from: str,
        date_to: str,
        limit: str,
        order_by: str,
        page: str,
        sort_by: str,
        x_api_key: str,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> PaymentListResponse:
        """Returns the entire list of all transactions created with certain API key.


        The list of optional parameters:

        - limit - number of records in one page. (possible values: from 1 to 500);
        - page - the page number you want to get (possible values: from 0 to **page
          count - 1**);
        - invoiceId - filtering payments by certain invoice ID;
        - sortBy - sort the received list by a paramenter. Set to **created_at** by
          default (possible values: payment_id, payment_status, pay_address,
          price_amount, price_currency, pay_amount, actually_paid, pay_currency,
          order_id, order_description, purchase_id, outcome_amount, outcome_currency);
        - orderBy - display the list in ascending or descending order. Set to **asc** by
          default (possible values: asc, desc);
        - dateFrom - select the displayed period start date (date format: YYYY-MM-DD or
          yy-MM-ddTHH:mm:ss.SSSZ);
        - dateTo - select the displayed period end date (date format: YYYY-MM-DD or
          yy-MM-ddTHH:mm:ss.SSSZ);

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {"x-api-key": x_api_key, **(extra_headers or {})}
        return self._get(
            "/v1/payment/",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "date_from": date_from,
                        "date_to": date_to,
                        "limit": limit,
                        "order_by": order_by,
                        "page": page,
                        "sort_by": sort_by,
                    },
                    payment_list_params.PaymentListParams,
                ),
            ),
            cast_to=PaymentListResponse,
        )

    def update_estimate(
        self,
        id: str,
        *,
        x_api_key: str,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> PaymentUpdateEstimateResponse:
        """
        This endpoint is required to get the current estimate on the payment and update
        the current estimate.
        Please note! Calling this estimate before `expiration_estimate_date` will return
        the current estimate, it won’t be updated.

        `:id` - payment ID, for which you want to get the estimate

        Response:
        `id` - payment ID
        `token_id` - id of api key used to create this payment (please discard this
        parameter)
        `pay_amount` - payment estimate, the exact amount the user will have to send to
        complete the payment
        `expiration_estimate_date` - expiration date of this estimate

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        extra_headers = {"x-api-key": x_api_key, **(extra_headers or {})}
        return self._post(
            f"/v1/payment/{id}/update-merchant-estimate",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=PaymentUpdateEstimateResponse,
        )


class AsyncPaymentResource(AsyncAPIResource):
    @cached_property
    def with_raw_response(self) -> AsyncPaymentResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/greatpie/nofa-nowpayment-client#accessing-raw-response-data-eg-headers
        """
        return AsyncPaymentResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncPaymentResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/greatpie/nofa-nowpayment-client#with_streaming_response
        """
        return AsyncPaymentResourceWithStreamingResponse(self)

    async def create(
        self,
        *,
        ipn_callback_url: str,
        is_fee_paid_by_user: bool,
        is_fixed_rate: bool,
        order_description: str,
        order_id: str,
        pay_currency: str,
        price_amount: float,
        price_currency: str,
        x_api_key: str,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> PaymentCreateResponse:
        """Creates payment.

        With this method, your customer will be able to complete the
        payment without leaving your website.
        **Data must be sent as a JSON-object payload.**
        Required request fields:

        - price_amount (required) - the fiat equivalent of the price to be paid in
          crypto. If the pay_amount parameter is left empty, our system will
          automatically convert this fiat price into its crypto equivalent. Please note
          that this does not enable fiat payments, only provides a fiat price for yours
          and the customer’s convenience and information. **NOTE: Some of the assets
          (KISHU, NWC, FTT, CHR, XYM, SRK, KLV, SUPER, OM, XCUR, NOW, SHIB, SAND, MATIC,
          CTSI, MANA, FRONT, FTM, DAO, LGCY), have a maximum price amount of \\~~$2000;**
        - price_currency (required) - the fiat currency in which the price_amount is
          specified (usd, eur, etc);
        - pay_amount (optional) - the amount that users have to pay for the order stated
          in crypto. You can either specify it yourself, or we will automatically
          convert the amount you indicated in price_amount;
        - pay_currency (required) - the crypto currency in which the pay_amount is
          specified (btc, eth, etc), or one of available fiat currencies if it's enabled
          for your account (USD, EUR, ILS, GBP, AUD, RON);
           **NOTE: some of the currencies require a Memo, Destination Tag, etc., to complete
          a payment (AVA, EOS, BNBMAINNET, XLM, XRP). This is unique for each payment. This
          ID is received in “payin_extra_id” parameter of the response. Payments made without
          "payin_extra_id" cannot be detected automatically;**
        - ipn_callback_url (optional) - url to receive callbacks, should contain "http"
          or "https", eg. "[https://nowpayments.io"](https://nowpayments.io);
        - order_id (optional) - inner store order ID, e.g. "RGDBP-21314";
        - order_description (optional) - inner store order description, e.g. "Apple
          Macbook Pro 2019 x 1";
        - payout_address (optional) - usually the funds will go to the address you
          specify in your Personal account. In case you want to receive funds on another
          address, you can specify it in this parameter;
        - payout_currency (optional) - currency of your external payout_address,
          required when payout_adress is specified;
        - payout_extra_id(optional) - extra id or memo or tag for external
          payout_address;
        - is_fixed_rate(optional) - boolean, can be **true** or **false**. Required for
          fixed-rate exchanges;
           NOTE: the rate of exchange will be frozen for 20 minutes. If there are no incoming
          payments during this period, the payment status changes to "expired".
        - is_fee_paid_by_user(optional) - boolean, can be **true** or **false**.
          Required for fixed-rate exchanges with all fees paid by users;
           NOTE: the rate of exchange will be frozen for 20 minutes. If there are no incoming
          payments during this period, the payment status changes to "expired";

        Here the list of available statuses of payment:

        - waiting - waiting for the customer to send the payment. The initial status of
          each payment;
        - confirming - the transaction is being processed on the blockchain. Appears
          when NOWPayments detect the funds from the user on the blockchain;
           **Please note:** each currency has its own amount of confirmations requires to
          start the processing.
        - confirmed - the process is confirmed by the blockchain. Customer’s funds have
          accumulated enough confirmations;
        - sending - the funds are being sent to your personal wallet. We are in the
          process of sending the funds to you;
        - partially_paid - it shows that the customer sent the less than the actual
          price. Appears when the funds have arrived in your wallet;
        - finished - the funds have reached your personal address and the payment is
          finished;
        - failed - the payment wasn't completed due to the error of some kind;
        - expired - the user didn't send the funds to the specified address in the 7
          days time window;

        **Please note: when you're creating a fiat2crypto payment you also should
        include additional header to your request - "origin-ip : xxx", where xxx is your
        customer IP address.**

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {"x-api-key": x_api_key, **(extra_headers or {})}
        return await self._post(
            "/v1/payment",
            body=await async_maybe_transform(
                {
                    "ipn_callback_url": ipn_callback_url,
                    "is_fee_paid_by_user": is_fee_paid_by_user,
                    "is_fixed_rate": is_fixed_rate,
                    "order_description": order_description,
                    "order_id": order_id,
                    "pay_currency": pay_currency,
                    "price_amount": price_amount,
                    "price_currency": price_currency,
                },
                payment_create_params.PaymentCreateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=PaymentCreateResponse,
        )

    async def retrieve(
        self,
        payment_id: str,
        *,
        x_api_key: str,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> PaymentRetrieveResponse:
        """Get the actual information about the payment.

        You need to provide the ID of the
        payment in the request.

        NOTE! You should make the get payment status request with the same API key that
        you used in the create payment request.
        Here is the list of available statuses:

        - waiting - waiting for the customer to send the payment. The initial status of
          each payment;
        - confirming - the transaction is being processed on the blockchain. Appears
          when NOWPayments detect the funds from the user on the blockchain;
        - confirmed - the process is confirmed by the blockchain. Customer’s funds have
          accumulated enough confirmations;
        - sending - the funds are being sent to your personal wallet. We are in the
          process of sending the funds to you;
        - partially_paid - it shows that the customer sent the less than the actual
          price. Appears when the funds have arrived in your wallet;
        - finished - the funds have reached your personal address and the payment is
          finished;
        - failed - the payment wasn't completed due to the error of some kind;
        - refunded - the funds were refunded back to the user;
        - expired - the user didn't send the funds to the specified address in the 7
          days time window;

        Additional info:

        - outcome_amount - this parameter shows the amount that will be (or is already)
          received on your Outcome Wallet once the transaction is settled;
        - outcome_currency - this parameter shows the currency in which the transaction
          will be settled;
        - invoice_id - this parameter shows invoice ID from which the payment was
          created;

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not payment_id:
            raise ValueError(f"Expected a non-empty value for `payment_id` but received {payment_id!r}")
        extra_headers = {"x-api-key": x_api_key, **(extra_headers or {})}
        return await self._get(
            f"/v1/payment/{payment_id}",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=PaymentRetrieveResponse,
        )

    async def list(
        self,
        *,
        date_from: str,
        date_to: str,
        limit: str,
        order_by: str,
        page: str,
        sort_by: str,
        x_api_key: str,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> PaymentListResponse:
        """Returns the entire list of all transactions created with certain API key.


        The list of optional parameters:

        - limit - number of records in one page. (possible values: from 1 to 500);
        - page - the page number you want to get (possible values: from 0 to **page
          count - 1**);
        - invoiceId - filtering payments by certain invoice ID;
        - sortBy - sort the received list by a paramenter. Set to **created_at** by
          default (possible values: payment_id, payment_status, pay_address,
          price_amount, price_currency, pay_amount, actually_paid, pay_currency,
          order_id, order_description, purchase_id, outcome_amount, outcome_currency);
        - orderBy - display the list in ascending or descending order. Set to **asc** by
          default (possible values: asc, desc);
        - dateFrom - select the displayed period start date (date format: YYYY-MM-DD or
          yy-MM-ddTHH:mm:ss.SSSZ);
        - dateTo - select the displayed period end date (date format: YYYY-MM-DD or
          yy-MM-ddTHH:mm:ss.SSSZ);

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {"x-api-key": x_api_key, **(extra_headers or {})}
        return await self._get(
            "/v1/payment/",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=await async_maybe_transform(
                    {
                        "date_from": date_from,
                        "date_to": date_to,
                        "limit": limit,
                        "order_by": order_by,
                        "page": page,
                        "sort_by": sort_by,
                    },
                    payment_list_params.PaymentListParams,
                ),
            ),
            cast_to=PaymentListResponse,
        )

    async def update_estimate(
        self,
        id: str,
        *,
        x_api_key: str,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> PaymentUpdateEstimateResponse:
        """
        This endpoint is required to get the current estimate on the payment and update
        the current estimate.
        Please note! Calling this estimate before `expiration_estimate_date` will return
        the current estimate, it won’t be updated.

        `:id` - payment ID, for which you want to get the estimate

        Response:
        `id` - payment ID
        `token_id` - id of api key used to create this payment (please discard this
        parameter)
        `pay_amount` - payment estimate, the exact amount the user will have to send to
        complete the payment
        `expiration_estimate_date` - expiration date of this estimate

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        extra_headers = {"x-api-key": x_api_key, **(extra_headers or {})}
        return await self._post(
            f"/v1/payment/{id}/update-merchant-estimate",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=PaymentUpdateEstimateResponse,
        )


class PaymentResourceWithRawResponse:
    def __init__(self, payment: PaymentResource) -> None:
        self._payment = payment

        self.create = to_raw_response_wrapper(
            payment.create,
        )
        self.retrieve = to_raw_response_wrapper(
            payment.retrieve,
        )
        self.list = to_raw_response_wrapper(
            payment.list,
        )
        self.update_estimate = to_raw_response_wrapper(
            payment.update_estimate,
        )


class AsyncPaymentResourceWithRawResponse:
    def __init__(self, payment: AsyncPaymentResource) -> None:
        self._payment = payment

        self.create = async_to_raw_response_wrapper(
            payment.create,
        )
        self.retrieve = async_to_raw_response_wrapper(
            payment.retrieve,
        )
        self.list = async_to_raw_response_wrapper(
            payment.list,
        )
        self.update_estimate = async_to_raw_response_wrapper(
            payment.update_estimate,
        )


class PaymentResourceWithStreamingResponse:
    def __init__(self, payment: PaymentResource) -> None:
        self._payment = payment

        self.create = to_streamed_response_wrapper(
            payment.create,
        )
        self.retrieve = to_streamed_response_wrapper(
            payment.retrieve,
        )
        self.list = to_streamed_response_wrapper(
            payment.list,
        )
        self.update_estimate = to_streamed_response_wrapper(
            payment.update_estimate,
        )


class AsyncPaymentResourceWithStreamingResponse:
    def __init__(self, payment: AsyncPaymentResource) -> None:
        self._payment = payment

        self.create = async_to_streamed_response_wrapper(
            payment.create,
        )
        self.retrieve = async_to_streamed_response_wrapper(
            payment.retrieve,
        )
        self.list = async_to_streamed_response_wrapper(
            payment.list,
        )
        self.update_estimate = async_to_streamed_response_wrapper(
            payment.update_estimate,
        )
