# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import httpx

from .._types import Body, Query, Headers, NotGiven, not_given
from .._compat import cached_property
from .._resource import SyncAPIResource, AsyncAPIResource
from .._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from .._base_client import make_request_options
from ..types.payout_withdrawal_retrieve_min_amount_response import PayoutWithdrawalRetrieveMinAmountResponse

__all__ = ["PayoutWithdrawalResource", "AsyncPayoutWithdrawalResource"]


class PayoutWithdrawalResource(SyncAPIResource):
    @cached_property
    def with_raw_response(self) -> PayoutWithdrawalResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/greatpie/nofa-nowpayment-client#accessing-raw-response-data-eg-headers
        """
        return PayoutWithdrawalResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> PayoutWithdrawalResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/greatpie/nofa-nowpayment-client#with_streaming_response
        """
        return PayoutWithdrawalResourceWithStreamingResponse(self)

    def retrieve_min_amount(
        self,
        coin: str,
        *,
        x_api_key: str,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> PayoutWithdrawalRetrieveMinAmountResponse:
        """
        This endpoint shows you current minimal amount for withdrawals.

        Parameters:

        :coin - ticker of the coin.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not coin:
            raise ValueError(f"Expected a non-empty value for `coin` but received {coin!r}")
        extra_headers = {"x-api-key": x_api_key, **(extra_headers or {})}
        return self._get(
            f"/v1/payout-withdrawal/min-amount/{coin}",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=PayoutWithdrawalRetrieveMinAmountResponse,
        )


class AsyncPayoutWithdrawalResource(AsyncAPIResource):
    @cached_property
    def with_raw_response(self) -> AsyncPayoutWithdrawalResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/greatpie/nofa-nowpayment-client#accessing-raw-response-data-eg-headers
        """
        return AsyncPayoutWithdrawalResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncPayoutWithdrawalResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/greatpie/nofa-nowpayment-client#with_streaming_response
        """
        return AsyncPayoutWithdrawalResourceWithStreamingResponse(self)

    async def retrieve_min_amount(
        self,
        coin: str,
        *,
        x_api_key: str,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> PayoutWithdrawalRetrieveMinAmountResponse:
        """
        This endpoint shows you current minimal amount for withdrawals.

        Parameters:

        :coin - ticker of the coin.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not coin:
            raise ValueError(f"Expected a non-empty value for `coin` but received {coin!r}")
        extra_headers = {"x-api-key": x_api_key, **(extra_headers or {})}
        return await self._get(
            f"/v1/payout-withdrawal/min-amount/{coin}",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=PayoutWithdrawalRetrieveMinAmountResponse,
        )


class PayoutWithdrawalResourceWithRawResponse:
    def __init__(self, payout_withdrawal: PayoutWithdrawalResource) -> None:
        self._payout_withdrawal = payout_withdrawal

        self.retrieve_min_amount = to_raw_response_wrapper(
            payout_withdrawal.retrieve_min_amount,
        )


class AsyncPayoutWithdrawalResourceWithRawResponse:
    def __init__(self, payout_withdrawal: AsyncPayoutWithdrawalResource) -> None:
        self._payout_withdrawal = payout_withdrawal

        self.retrieve_min_amount = async_to_raw_response_wrapper(
            payout_withdrawal.retrieve_min_amount,
        )


class PayoutWithdrawalResourceWithStreamingResponse:
    def __init__(self, payout_withdrawal: PayoutWithdrawalResource) -> None:
        self._payout_withdrawal = payout_withdrawal

        self.retrieve_min_amount = to_streamed_response_wrapper(
            payout_withdrawal.retrieve_min_amount,
        )


class AsyncPayoutWithdrawalResourceWithStreamingResponse:
    def __init__(self, payout_withdrawal: AsyncPayoutWithdrawalResource) -> None:
        self._payout_withdrawal = payout_withdrawal

        self.retrieve_min_amount = async_to_streamed_response_wrapper(
            payout_withdrawal.retrieve_min_amount,
        )
