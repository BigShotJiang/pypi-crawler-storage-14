# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import httpx

from .._types import Body, Query, Headers, NotGiven, not_given
from .._compat import cached_property
from .._resource import SyncAPIResource, AsyncAPIResource
from .._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from .._base_client import make_request_options
from ..types.merchant_list_coins_response import MerchantListCoinsResponse

__all__ = ["MerchantResource", "AsyncMerchantResource"]


class MerchantResource(SyncAPIResource):
    @cached_property
    def with_raw_response(self) -> MerchantResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/greatpie/nofa-nowpayment-client#accessing-raw-response-data-eg-headers
        """
        return MerchantResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> MerchantResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/greatpie/nofa-nowpayment-client#with_streaming_response
        """
        return MerchantResourceWithStreamingResponse(self)

    def list_coins(
        self,
        *,
        x_api_key: str,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> MerchantListCoinsResponse:
        """
        This is a method for obtaining information about the cryptocurrencies available
        for payments. Shows the coins you set as available for payments in the "coins
        settings" tab on your personal account.
        Optional parameters:

        - fixed_rate(optional) - boolean, can be **true** or **false**. Returns
          currencies avaliable for fixed rate exchanges with minimum and maximum amount
          of the exchange.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {"x-api-key": x_api_key, **(extra_headers or {})}
        return self._get(
            "/v1/merchant/coins",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=MerchantListCoinsResponse,
        )


class AsyncMerchantResource(AsyncAPIResource):
    @cached_property
    def with_raw_response(self) -> AsyncMerchantResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/greatpie/nofa-nowpayment-client#accessing-raw-response-data-eg-headers
        """
        return AsyncMerchantResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncMerchantResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/greatpie/nofa-nowpayment-client#with_streaming_response
        """
        return AsyncMerchantResourceWithStreamingResponse(self)

    async def list_coins(
        self,
        *,
        x_api_key: str,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> MerchantListCoinsResponse:
        """
        This is a method for obtaining information about the cryptocurrencies available
        for payments. Shows the coins you set as available for payments in the "coins
        settings" tab on your personal account.
        Optional parameters:

        - fixed_rate(optional) - boolean, can be **true** or **false**. Returns
          currencies avaliable for fixed rate exchanges with minimum and maximum amount
          of the exchange.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {"x-api-key": x_api_key, **(extra_headers or {})}
        return await self._get(
            "/v1/merchant/coins",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=MerchantListCoinsResponse,
        )


class MerchantResourceWithRawResponse:
    def __init__(self, merchant: MerchantResource) -> None:
        self._merchant = merchant

        self.list_coins = to_raw_response_wrapper(
            merchant.list_coins,
        )


class AsyncMerchantResourceWithRawResponse:
    def __init__(self, merchant: AsyncMerchantResource) -> None:
        self._merchant = merchant

        self.list_coins = async_to_raw_response_wrapper(
            merchant.list_coins,
        )


class MerchantResourceWithStreamingResponse:
    def __init__(self, merchant: MerchantResource) -> None:
        self._merchant = merchant

        self.list_coins = to_streamed_response_wrapper(
            merchant.list_coins,
        )


class AsyncMerchantResourceWithStreamingResponse:
    def __init__(self, merchant: AsyncMerchantResource) -> None:
        self._merchant = merchant

        self.list_coins = async_to_streamed_response_wrapper(
            merchant.list_coins,
        )
