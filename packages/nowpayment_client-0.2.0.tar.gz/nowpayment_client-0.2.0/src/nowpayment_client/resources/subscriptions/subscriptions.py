# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import httpx

from .plans import (
    PlansResource,
    AsyncPlansResource,
    PlansResourceWithRawResponse,
    AsyncPlansResourceWithRawResponse,
    PlansResourceWithStreamingResponse,
    AsyncPlansResourceWithStreamingResponse,
)
from ...types import subscription_list_params, subscription_create_params
from ..._types import Body, Omit, Query, Headers, NotGiven, omit, not_given
from ..._utils import maybe_transform, async_maybe_transform
from ..._compat import cached_property
from ..._resource import SyncAPIResource, AsyncAPIResource
from ..._response import (
    BinaryAPIResponse,
    AsyncBinaryAPIResponse,
    StreamedBinaryAPIResponse,
    AsyncStreamedBinaryAPIResponse,
    to_custom_raw_response_wrapper,
    to_custom_streamed_response_wrapper,
    async_to_custom_raw_response_wrapper,
    async_to_custom_streamed_response_wrapper,
)
from ..._base_client import make_request_options

__all__ = ["SubscriptionsResource", "AsyncSubscriptionsResource"]


class SubscriptionsResource(SyncAPIResource):
    @cached_property
    def plans(self) -> PlansResource:
        return PlansResource(self._client)

    @cached_property
    def with_raw_response(self) -> SubscriptionsResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/greatpie/nofa-nowpayment-client#accessing-raw-response-data-eg-headers
        """
        return SubscriptionsResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> SubscriptionsResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/greatpie/nofa-nowpayment-client#with_streaming_response
        """
        return SubscriptionsResourceWithStreamingResponse(self)

    def create(
        self,
        *,
        email: str,
        subscription_plan_id: int,
        x_api_key: str,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> BinaryAPIResponse:
        """This method allows you to send payment links to your customers via email.

        A day
        before the paid period ends, the customer receives a new letter with a new
        payment link.

        `subscription_plan_id` - the ID of the payment plan your customer chooses; such
        params as the duration and amount will be defined by this ID;
        `email` - your customer’s email to which the payment links will be sent;

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {"Accept": "application/octet-stream", **(extra_headers or {})}
        extra_headers = {"x-api-key": x_api_key, **(extra_headers or {})}
        return self._post(
            "/v1/subscriptions",
            body=maybe_transform(
                {
                    "email": email,
                    "subscription_plan_id": subscription_plan_id,
                },
                subscription_create_params.SubscriptionCreateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=BinaryAPIResponse,
        )

    def retrieve(
        self,
        sub_id: str,
        *,
        x_api_key: str,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> BinaryAPIResponse:
        """
        Get information about a particular recurring payment via its ID.

        Here is the list of available statuses:

        - WAITING_PAY - the payment is waiting for user's deposit;
        - PAID - the payment is completed;
        - PARTIALLY_PAID - the payment is completed, but the final amount is less than
          required for payment to be fully paid;
        - EXPIRED - is being assigned to unpaid payment after 7 days of waiting;

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not sub_id:
            raise ValueError(f"Expected a non-empty value for `sub_id` but received {sub_id!r}")
        extra_headers = {"Accept": "application/octet-stream", **(extra_headers or {})}
        extra_headers = {"x-api-key": x_api_key, **(extra_headers or {})}
        return self._get(
            f"/v1/subscriptions/{sub_id}",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=BinaryAPIResponse,
        )

    def list(
        self,
        *,
        x_api_key: str,
        is_active: str | Omit = omit,
        limit: str | Omit = omit,
        offset: str | Omit = omit,
        status: str | Omit = omit,
        subscription_plan_id: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> BinaryAPIResponse:
        """
        The method allows you to view the entire list of recurring payments filtered by
        payment status and/or payment plan id

        Available parameters:

        - limit - the amount of shown items
        - offset - setting the offset
        - is_active - status of the recurring payment
        - status - filter by status of recurring payment
        - subscription_plan_id - filter results by subscription plan id.

        Here is the list of available statuses:

        - WAITING_PAY - the payment is waiting for user's deposit;
        - PAID - the payment is completed;
        - PARTIALLY_PAID - the payment is completed, but the final amount is less than
          required for payment to be fully paid;
        - EXPIRED - is being assigned to unpaid payment after 7 days of waiting;

        Args:
          is_active: true / false

          status: "WAITING_PAY" / "PAID" / "PARTIALLY_PAID" / "EXPIRED"

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {"Accept": "application/octet-stream", **(extra_headers or {})}
        extra_headers = {"x-api-key": x_api_key, **(extra_headers or {})}
        return self._get(
            "/v1/subscriptions",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "is_active": is_active,
                        "limit": limit,
                        "offset": offset,
                        "status": status,
                        "subscription_plan_id": subscription_plan_id,
                    },
                    subscription_list_params.SubscriptionListParams,
                ),
            ),
            cast_to=BinaryAPIResponse,
        )

    def delete(
        self,
        sub_id: str,
        *,
        x_api_key: str,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> BinaryAPIResponse:
        """Completely removes a particular payment from the recurring payment plan.


        You need to specify the payment plan id in the request.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not sub_id:
            raise ValueError(f"Expected a non-empty value for `sub_id` but received {sub_id!r}")
        extra_headers = {"Accept": "application/octet-stream", **(extra_headers or {})}
        extra_headers = {"x-api-key": x_api_key, **(extra_headers or {})}
        return self._delete(
            f"/v1/subscriptions/{sub_id}",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=BinaryAPIResponse,
        )


class AsyncSubscriptionsResource(AsyncAPIResource):
    @cached_property
    def plans(self) -> AsyncPlansResource:
        return AsyncPlansResource(self._client)

    @cached_property
    def with_raw_response(self) -> AsyncSubscriptionsResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/greatpie/nofa-nowpayment-client#accessing-raw-response-data-eg-headers
        """
        return AsyncSubscriptionsResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncSubscriptionsResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/greatpie/nofa-nowpayment-client#with_streaming_response
        """
        return AsyncSubscriptionsResourceWithStreamingResponse(self)

    async def create(
        self,
        *,
        email: str,
        subscription_plan_id: int,
        x_api_key: str,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> AsyncBinaryAPIResponse:
        """This method allows you to send payment links to your customers via email.

        A day
        before the paid period ends, the customer receives a new letter with a new
        payment link.

        `subscription_plan_id` - the ID of the payment plan your customer chooses; such
        params as the duration and amount will be defined by this ID;
        `email` - your customer’s email to which the payment links will be sent;

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {"Accept": "application/octet-stream", **(extra_headers or {})}
        extra_headers = {"x-api-key": x_api_key, **(extra_headers or {})}
        return await self._post(
            "/v1/subscriptions",
            body=await async_maybe_transform(
                {
                    "email": email,
                    "subscription_plan_id": subscription_plan_id,
                },
                subscription_create_params.SubscriptionCreateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=AsyncBinaryAPIResponse,
        )

    async def retrieve(
        self,
        sub_id: str,
        *,
        x_api_key: str,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> AsyncBinaryAPIResponse:
        """
        Get information about a particular recurring payment via its ID.

        Here is the list of available statuses:

        - WAITING_PAY - the payment is waiting for user's deposit;
        - PAID - the payment is completed;
        - PARTIALLY_PAID - the payment is completed, but the final amount is less than
          required for payment to be fully paid;
        - EXPIRED - is being assigned to unpaid payment after 7 days of waiting;

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not sub_id:
            raise ValueError(f"Expected a non-empty value for `sub_id` but received {sub_id!r}")
        extra_headers = {"Accept": "application/octet-stream", **(extra_headers or {})}
        extra_headers = {"x-api-key": x_api_key, **(extra_headers or {})}
        return await self._get(
            f"/v1/subscriptions/{sub_id}",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=AsyncBinaryAPIResponse,
        )

    async def list(
        self,
        *,
        x_api_key: str,
        is_active: str | Omit = omit,
        limit: str | Omit = omit,
        offset: str | Omit = omit,
        status: str | Omit = omit,
        subscription_plan_id: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> AsyncBinaryAPIResponse:
        """
        The method allows you to view the entire list of recurring payments filtered by
        payment status and/or payment plan id

        Available parameters:

        - limit - the amount of shown items
        - offset - setting the offset
        - is_active - status of the recurring payment
        - status - filter by status of recurring payment
        - subscription_plan_id - filter results by subscription plan id.

        Here is the list of available statuses:

        - WAITING_PAY - the payment is waiting for user's deposit;
        - PAID - the payment is completed;
        - PARTIALLY_PAID - the payment is completed, but the final amount is less than
          required for payment to be fully paid;
        - EXPIRED - is being assigned to unpaid payment after 7 days of waiting;

        Args:
          is_active: true / false

          status: "WAITING_PAY" / "PAID" / "PARTIALLY_PAID" / "EXPIRED"

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {"Accept": "application/octet-stream", **(extra_headers or {})}
        extra_headers = {"x-api-key": x_api_key, **(extra_headers or {})}
        return await self._get(
            "/v1/subscriptions",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=await async_maybe_transform(
                    {
                        "is_active": is_active,
                        "limit": limit,
                        "offset": offset,
                        "status": status,
                        "subscription_plan_id": subscription_plan_id,
                    },
                    subscription_list_params.SubscriptionListParams,
                ),
            ),
            cast_to=AsyncBinaryAPIResponse,
        )

    async def delete(
        self,
        sub_id: str,
        *,
        x_api_key: str,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> AsyncBinaryAPIResponse:
        """Completely removes a particular payment from the recurring payment plan.


        You need to specify the payment plan id in the request.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not sub_id:
            raise ValueError(f"Expected a non-empty value for `sub_id` but received {sub_id!r}")
        extra_headers = {"Accept": "application/octet-stream", **(extra_headers or {})}
        extra_headers = {"x-api-key": x_api_key, **(extra_headers or {})}
        return await self._delete(
            f"/v1/subscriptions/{sub_id}",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=AsyncBinaryAPIResponse,
        )


class SubscriptionsResourceWithRawResponse:
    def __init__(self, subscriptions: SubscriptionsResource) -> None:
        self._subscriptions = subscriptions

        self.create = to_custom_raw_response_wrapper(
            subscriptions.create,
            BinaryAPIResponse,
        )
        self.retrieve = to_custom_raw_response_wrapper(
            subscriptions.retrieve,
            BinaryAPIResponse,
        )
        self.list = to_custom_raw_response_wrapper(
            subscriptions.list,
            BinaryAPIResponse,
        )
        self.delete = to_custom_raw_response_wrapper(
            subscriptions.delete,
            BinaryAPIResponse,
        )

    @cached_property
    def plans(self) -> PlansResourceWithRawResponse:
        return PlansResourceWithRawResponse(self._subscriptions.plans)


class AsyncSubscriptionsResourceWithRawResponse:
    def __init__(self, subscriptions: AsyncSubscriptionsResource) -> None:
        self._subscriptions = subscriptions

        self.create = async_to_custom_raw_response_wrapper(
            subscriptions.create,
            AsyncBinaryAPIResponse,
        )
        self.retrieve = async_to_custom_raw_response_wrapper(
            subscriptions.retrieve,
            AsyncBinaryAPIResponse,
        )
        self.list = async_to_custom_raw_response_wrapper(
            subscriptions.list,
            AsyncBinaryAPIResponse,
        )
        self.delete = async_to_custom_raw_response_wrapper(
            subscriptions.delete,
            AsyncBinaryAPIResponse,
        )

    @cached_property
    def plans(self) -> AsyncPlansResourceWithRawResponse:
        return AsyncPlansResourceWithRawResponse(self._subscriptions.plans)


class SubscriptionsResourceWithStreamingResponse:
    def __init__(self, subscriptions: SubscriptionsResource) -> None:
        self._subscriptions = subscriptions

        self.create = to_custom_streamed_response_wrapper(
            subscriptions.create,
            StreamedBinaryAPIResponse,
        )
        self.retrieve = to_custom_streamed_response_wrapper(
            subscriptions.retrieve,
            StreamedBinaryAPIResponse,
        )
        self.list = to_custom_streamed_response_wrapper(
            subscriptions.list,
            StreamedBinaryAPIResponse,
        )
        self.delete = to_custom_streamed_response_wrapper(
            subscriptions.delete,
            StreamedBinaryAPIResponse,
        )

    @cached_property
    def plans(self) -> PlansResourceWithStreamingResponse:
        return PlansResourceWithStreamingResponse(self._subscriptions.plans)


class AsyncSubscriptionsResourceWithStreamingResponse:
    def __init__(self, subscriptions: AsyncSubscriptionsResource) -> None:
        self._subscriptions = subscriptions

        self.create = async_to_custom_streamed_response_wrapper(
            subscriptions.create,
            AsyncStreamedBinaryAPIResponse,
        )
        self.retrieve = async_to_custom_streamed_response_wrapper(
            subscriptions.retrieve,
            AsyncStreamedBinaryAPIResponse,
        )
        self.list = async_to_custom_streamed_response_wrapper(
            subscriptions.list,
            AsyncStreamedBinaryAPIResponse,
        )
        self.delete = async_to_custom_streamed_response_wrapper(
            subscriptions.delete,
            AsyncStreamedBinaryAPIResponse,
        )

    @cached_property
    def plans(self) -> AsyncPlansResourceWithStreamingResponse:
        return AsyncPlansResourceWithStreamingResponse(self._subscriptions.plans)
