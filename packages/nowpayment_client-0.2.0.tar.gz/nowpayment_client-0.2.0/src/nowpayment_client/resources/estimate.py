# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import httpx

from ..types import estimate_calculate_params
from .._types import Body, Query, Headers, NotGiven, not_given
from .._utils import maybe_transform, async_maybe_transform
from .._compat import cached_property
from .._resource import SyncAPIResource, AsyncAPIResource
from .._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from .._base_client import make_request_options
from ..types.estimate_calculate_response import EstimateCalculateResponse

__all__ = ["EstimateResource", "AsyncEstimateResource"]


class EstimateResource(SyncAPIResource):
    @cached_property
    def with_raw_response(self) -> EstimateResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/greatpie/nofa-nowpayment-client#accessing-raw-response-data-eg-headers
        """
        return EstimateResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> EstimateResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/greatpie/nofa-nowpayment-client#with_streaming_response
        """
        return EstimateResourceWithStreamingResponse(self)

    def calculate(
        self,
        *,
        amount: str,
        currency_from: str,
        currency_to: str,
        x_api_key: str,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> EstimateCalculateResponse:
        """
        This is a method for calculating the approximate price in cryptocurrency for a
        given value in Fiat currency. You will need to provide the initial cost in the
        Fiat currency (amount, currency_from) and the necessary cryptocurrency
        (currency_to)
        Currently following fiat currencies are available: USD, EUR, CAD, GBP, AUD, ILS,
        RON.

        Please note that this method allows you to get estimates for crypto pairs as
        well.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {"x-api-key": x_api_key, **(extra_headers or {})}
        return self._get(
            "/v1/estimate",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "amount": amount,
                        "currency_from": currency_from,
                        "currency_to": currency_to,
                    },
                    estimate_calculate_params.EstimateCalculateParams,
                ),
            ),
            cast_to=EstimateCalculateResponse,
        )


class AsyncEstimateResource(AsyncAPIResource):
    @cached_property
    def with_raw_response(self) -> AsyncEstimateResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/greatpie/nofa-nowpayment-client#accessing-raw-response-data-eg-headers
        """
        return AsyncEstimateResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncEstimateResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/greatpie/nofa-nowpayment-client#with_streaming_response
        """
        return AsyncEstimateResourceWithStreamingResponse(self)

    async def calculate(
        self,
        *,
        amount: str,
        currency_from: str,
        currency_to: str,
        x_api_key: str,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> EstimateCalculateResponse:
        """
        This is a method for calculating the approximate price in cryptocurrency for a
        given value in Fiat currency. You will need to provide the initial cost in the
        Fiat currency (amount, currency_from) and the necessary cryptocurrency
        (currency_to)
        Currently following fiat currencies are available: USD, EUR, CAD, GBP, AUD, ILS,
        RON.

        Please note that this method allows you to get estimates for crypto pairs as
        well.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {"x-api-key": x_api_key, **(extra_headers or {})}
        return await self._get(
            "/v1/estimate",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=await async_maybe_transform(
                    {
                        "amount": amount,
                        "currency_from": currency_from,
                        "currency_to": currency_to,
                    },
                    estimate_calculate_params.EstimateCalculateParams,
                ),
            ),
            cast_to=EstimateCalculateResponse,
        )


class EstimateResourceWithRawResponse:
    def __init__(self, estimate: EstimateResource) -> None:
        self._estimate = estimate

        self.calculate = to_raw_response_wrapper(
            estimate.calculate,
        )


class AsyncEstimateResourceWithRawResponse:
    def __init__(self, estimate: AsyncEstimateResource) -> None:
        self._estimate = estimate

        self.calculate = async_to_raw_response_wrapper(
            estimate.calculate,
        )


class EstimateResourceWithStreamingResponse:
    def __init__(self, estimate: EstimateResource) -> None:
        self._estimate = estimate

        self.calculate = to_streamed_response_wrapper(
            estimate.calculate,
        )


class AsyncEstimateResourceWithStreamingResponse:
    def __init__(self, estimate: AsyncEstimateResource) -> None:
        self._estimate = estimate

        self.calculate = async_to_streamed_response_wrapper(
            estimate.calculate,
        )
