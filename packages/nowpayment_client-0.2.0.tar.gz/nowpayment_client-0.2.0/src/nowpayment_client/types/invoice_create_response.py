# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from .._models import BaseModel

__all__ = ["InvoiceCreateResponse"]


class InvoiceCreateResponse(BaseModel):
    id: str

    cancel_url: str

    created_at: str

    invoice_url: str

    ipn_callback_url: str

    order_description: str

    order_id: str

    pay_currency: None = None

    price_amount: str

    price_currency: str

    success_url: str

    updated_at: str
