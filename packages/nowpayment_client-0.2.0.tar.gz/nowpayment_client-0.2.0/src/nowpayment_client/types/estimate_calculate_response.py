# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from .._models import BaseModel

__all__ = ["EstimateCalculateResponse"]


class EstimateCalculateResponse(BaseModel):
    amount_from: float

    currency_from: str

    currency_to: str

    estimated_amount: float
