# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from .._models import BaseModel

__all__ = ["PaymentRetrieveResponse"]


class PaymentRetrieveResponse(BaseModel):
    actually_paid: int

    created_at: str

    order_description: str

    order_id: str

    outcome_amount: float

    outcome_currency: str

    pay_address: str

    pay_amount: float

    pay_currency: str

    payment_id: int

    payment_status: str

    price_amount: int

    price_currency: str

    purchase_id: str

    updated_at: str
