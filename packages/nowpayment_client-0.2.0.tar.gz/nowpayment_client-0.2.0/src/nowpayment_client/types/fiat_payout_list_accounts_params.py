# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import Required, Annotated, TypedDict

from .._utils import PropertyInfo

__all__ = ["FiatPayoutListAccountsParams"]


class FiatPayoutListAccountsParams(TypedDict, total=False):
    id: Required[str]

    currency: Required[str]

    date_from: Required[Annotated[str, PropertyInfo(alias="dateFrom")]]

    date_to: Required[Annotated[str, PropertyInfo(alias="dateTo")]]

    filter: Required[str]

    limit: Required[str]

    order_by: Required[Annotated[str, PropertyInfo(alias="orderBy")]]

    page: Required[str]

    provider: Required[str]

    sort_by: Required[Annotated[str, PropertyInfo(alias="sortBy")]]
