# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from .._models import BaseModel

__all__ = ["PaymentUpdateEstimateResponse"]


class PaymentUpdateEstimateResponse(BaseModel):
    id: str

    expiration_estimate_date: str

    pay_amount: float

    token_id: str
