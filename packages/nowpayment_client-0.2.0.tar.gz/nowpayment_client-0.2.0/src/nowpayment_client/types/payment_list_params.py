# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import Required, Annotated, TypedDict

from .._utils import PropertyInfo

__all__ = ["PaymentListParams"]


class PaymentListParams(TypedDict, total=False):
    date_from: Required[Annotated[str, PropertyInfo(alias="dateFrom")]]

    date_to: Required[Annotated[str, PropertyInfo(alias="dateTo")]]

    limit: Required[str]

    order_by: Required[Annotated[str, PropertyInfo(alias="orderBy")]]

    page: Required[str]

    sort_by: Required[Annotated[str, PropertyInfo(alias="sortBy")]]

    x_api_key: Required[Annotated[str, PropertyInfo(alias="x-api-key")]]
