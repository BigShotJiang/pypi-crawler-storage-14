# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List

from pydantic import Field as FieldInfo

from .._models import BaseModel

__all__ = ["FiatPayoutListFiatCurrenciesResponse", "Result"]


class Result(BaseModel):
    currency_code: str = FieldInfo(alias="currencyCode")

    enabled: bool

    provider: str


class FiatPayoutListFiatCurrenciesResponse(BaseModel):
    result: List[Result]
