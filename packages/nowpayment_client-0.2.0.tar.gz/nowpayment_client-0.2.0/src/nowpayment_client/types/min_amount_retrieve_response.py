# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from .._models import BaseModel

__all__ = ["MinAmountRetrieveResponse"]


class MinAmountRetrieveResponse(BaseModel):
    currency_from: str

    currency_to: str

    fiat_equivalent: float

    min_amount: float
