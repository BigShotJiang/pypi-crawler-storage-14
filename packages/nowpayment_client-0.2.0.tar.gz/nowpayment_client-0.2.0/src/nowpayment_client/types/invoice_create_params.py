# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import Required, Annotated, TypedDict

from .._utils import PropertyInfo

__all__ = ["InvoiceCreateParams"]


class InvoiceCreateParams(TypedDict, total=False):
    cancel_url: Required[str]

    ipn_callback_url: Required[str]

    is_fee_paid_by_user: Required[bool]

    is_fixed_rate: Required[bool]

    order_description: Required[str]

    order_id: Required[str]

    partially_paid_url: Required[str]

    price_amount: Required[int]

    price_currency: Required[str]

    success_url: Required[str]

    x_api_key: Required[Annotated[str, PropertyInfo(alias="x-api-key")]]
