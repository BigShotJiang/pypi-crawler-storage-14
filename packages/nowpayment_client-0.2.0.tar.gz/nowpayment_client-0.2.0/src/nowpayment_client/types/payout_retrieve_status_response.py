# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List, Optional
from typing_extensions import TypeAlias

from .._models import BaseModel

__all__ = ["PayoutRetrieveStatusResponse", "PayoutRetrieveStatusResponseItem"]


class PayoutRetrieveStatusResponseItem(BaseModel):
    id: Optional[str] = None

    address: Optional[str] = None

    amount: Optional[str] = None

    batch_withdrawal_id: Optional[str] = None

    created_at: Optional[str] = None

    currency: Optional[str] = None

    error: None = None

    extra_id: None = None

    hash: None = None

    ipn_callback_url: None = None

    is_request_payouts: Optional[bool] = None

    payout_description: None = None

    requested_at: None = None

    status: Optional[str] = None

    unique_external_id: None = None

    updated_at: None = None


PayoutRetrieveStatusResponse: TypeAlias = List[PayoutRetrieveStatusResponseItem]
