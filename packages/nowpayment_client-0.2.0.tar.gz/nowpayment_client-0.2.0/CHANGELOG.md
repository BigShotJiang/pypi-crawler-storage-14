# Changelog

## 0.2.0 (2025-11-28)

Full Changelog: [v0.1.0...v0.2.0](https://github.com/greatpie/nofa-nowpayment-client/compare/v0.1.0...v0.2.0)

### Features

* **api:** manual updates&fix json schema ([7b2eea4](https://github.com/greatpie/nofa-nowpayment-client/commit/7b2eea4cd538a7403521c0628c9a0f13f3bdec04))

## 0.1.0 (2025-11-28)

Full Changelog: [v0.0.2...v0.1.0](https://github.com/greatpie/nofa-nowpayment-client/compare/v0.0.2...v0.1.0)

### Features

* **api:** manual updates ([16623d9](https://github.com/greatpie/nofa-nowpayment-client/commit/16623d9c1d49110de05413c13e73e0a746ca3022))
* **api:** manual updates ([fe02d56](https://github.com/greatpie/nofa-nowpayment-client/commit/fe02d56cf29f9a02fe20f1b95c0f6351bf81d70a))

## 0.0.2 (2025-11-28)

Full Changelog: [v0.0.1...v0.0.2](https://github.com/greatpie/nofa-nowpayment-client/compare/v0.0.1...v0.0.2)

### Chores

* update SDK settings ([a0e36fc](https://github.com/greatpie/nofa-nowpayment-client/commit/a0e36fc9c1adafbf2657107a5bc7239ce1bb764d))
* update SDK settings ([99c65b5](https://github.com/greatpie/nofa-nowpayment-client/commit/99c65b5abb284066c4287df3e53ea697feec66d7))
