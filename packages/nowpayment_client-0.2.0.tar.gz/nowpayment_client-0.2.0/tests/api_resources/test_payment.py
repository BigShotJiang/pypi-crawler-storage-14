# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import os
from typing import Any, cast

import pytest

from tests.utils import assert_matches_type
from nowpayment_client import NowpaymentClient, AsyncNowpaymentClient
from nowpayment_client.types import (
    PaymentListResponse,
    PaymentCreateResponse,
    PaymentRetrieveResponse,
    PaymentUpdateEstimateResponse,
)

base_url = os.environ.get("TEST_API_BASE_URL", "http://127.0.0.1:4010")


class TestPayment:
    parametrize = pytest.mark.parametrize("client", [False, True], indirect=True, ids=["loose", "strict"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_create(self, client: NowpaymentClient) -> None:
        payment = client.payment.create(
            ipn_callback_url="https://nowpayments.io",
            is_fee_paid_by_user=False,
            is_fixed_rate=True,
            order_description="Apple Macbook Pro 2019 x 1",
            order_id="RGDBP-21314",
            pay_currency="btc",
            price_amount=3999.5,
            price_currency="usd",
            x_api_key="{{your_api_key}}",
        )
        assert_matches_type(PaymentCreateResponse, payment, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_raw_response_create(self, client: NowpaymentClient) -> None:
        response = client.payment.with_raw_response.create(
            ipn_callback_url="https://nowpayments.io",
            is_fee_paid_by_user=False,
            is_fixed_rate=True,
            order_description="Apple Macbook Pro 2019 x 1",
            order_id="RGDBP-21314",
            pay_currency="btc",
            price_amount=3999.5,
            price_currency="usd",
            x_api_key="{{your_api_key}}",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        payment = response.parse()
        assert_matches_type(PaymentCreateResponse, payment, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_streaming_response_create(self, client: NowpaymentClient) -> None:
        with client.payment.with_streaming_response.create(
            ipn_callback_url="https://nowpayments.io",
            is_fee_paid_by_user=False,
            is_fixed_rate=True,
            order_description="Apple Macbook Pro 2019 x 1",
            order_id="RGDBP-21314",
            pay_currency="btc",
            price_amount=3999.5,
            price_currency="usd",
            x_api_key="{{your_api_key}}",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            payment = response.parse()
            assert_matches_type(PaymentCreateResponse, payment, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_retrieve(self, client: NowpaymentClient) -> None:
        payment = client.payment.retrieve(
            payment_id="",
            x_api_key="{{your_api_key}}",
        )
        assert_matches_type(PaymentRetrieveResponse, payment, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_raw_response_retrieve(self, client: NowpaymentClient) -> None:
        response = client.payment.with_raw_response.retrieve(
            payment_id="",
            x_api_key="{{your_api_key}}",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        payment = response.parse()
        assert_matches_type(PaymentRetrieveResponse, payment, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_streaming_response_retrieve(self, client: NowpaymentClient) -> None:
        with client.payment.with_streaming_response.retrieve(
            payment_id="",
            x_api_key="{{your_api_key}}",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            payment = response.parse()
            assert_matches_type(PaymentRetrieveResponse, payment, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_path_params_retrieve(self, client: NowpaymentClient) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `payment_id` but received ''"):
            client.payment.with_raw_response.retrieve(
                payment_id="",
                x_api_key="{{your_api_key}}",
            )

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_list(self, client: NowpaymentClient) -> None:
        payment = client.payment.list(
            date_from="dateFrom",
            date_to="dateTo",
            limit="limit",
            order_by="orderBy",
            page="page",
            sort_by="sortBy",
            x_api_key="{{your_api_key}}",
        )
        assert_matches_type(PaymentListResponse, payment, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_raw_response_list(self, client: NowpaymentClient) -> None:
        response = client.payment.with_raw_response.list(
            date_from="dateFrom",
            date_to="dateTo",
            limit="limit",
            order_by="orderBy",
            page="page",
            sort_by="sortBy",
            x_api_key="{{your_api_key}}",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        payment = response.parse()
        assert_matches_type(PaymentListResponse, payment, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_streaming_response_list(self, client: NowpaymentClient) -> None:
        with client.payment.with_streaming_response.list(
            date_from="dateFrom",
            date_to="dateTo",
            limit="limit",
            order_by="orderBy",
            page="page",
            sort_by="sortBy",
            x_api_key="{{your_api_key}}",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            payment = response.parse()
            assert_matches_type(PaymentListResponse, payment, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_update_estimate(self, client: NowpaymentClient) -> None:
        payment = client.payment.update_estimate(
            id="",
            x_api_key="{{api-key}}",
        )
        assert_matches_type(PaymentUpdateEstimateResponse, payment, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_raw_response_update_estimate(self, client: NowpaymentClient) -> None:
        response = client.payment.with_raw_response.update_estimate(
            id="",
            x_api_key="{{api-key}}",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        payment = response.parse()
        assert_matches_type(PaymentUpdateEstimateResponse, payment, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_streaming_response_update_estimate(self, client: NowpaymentClient) -> None:
        with client.payment.with_streaming_response.update_estimate(
            id="",
            x_api_key="{{api-key}}",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            payment = response.parse()
            assert_matches_type(PaymentUpdateEstimateResponse, payment, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_path_params_update_estimate(self, client: NowpaymentClient) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `id` but received ''"):
            client.payment.with_raw_response.update_estimate(
                id="",
                x_api_key="{{api-key}}",
            )


class TestAsyncPayment:
    parametrize = pytest.mark.parametrize(
        "async_client", [False, True, {"http_client": "aiohttp"}], indirect=True, ids=["loose", "strict", "aiohttp"]
    )

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_create(self, async_client: AsyncNowpaymentClient) -> None:
        payment = await async_client.payment.create(
            ipn_callback_url="https://nowpayments.io",
            is_fee_paid_by_user=False,
            is_fixed_rate=True,
            order_description="Apple Macbook Pro 2019 x 1",
            order_id="RGDBP-21314",
            pay_currency="btc",
            price_amount=3999.5,
            price_currency="usd",
            x_api_key="{{your_api_key}}",
        )
        assert_matches_type(PaymentCreateResponse, payment, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_raw_response_create(self, async_client: AsyncNowpaymentClient) -> None:
        response = await async_client.payment.with_raw_response.create(
            ipn_callback_url="https://nowpayments.io",
            is_fee_paid_by_user=False,
            is_fixed_rate=True,
            order_description="Apple Macbook Pro 2019 x 1",
            order_id="RGDBP-21314",
            pay_currency="btc",
            price_amount=3999.5,
            price_currency="usd",
            x_api_key="{{your_api_key}}",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        payment = await response.parse()
        assert_matches_type(PaymentCreateResponse, payment, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_streaming_response_create(self, async_client: AsyncNowpaymentClient) -> None:
        async with async_client.payment.with_streaming_response.create(
            ipn_callback_url="https://nowpayments.io",
            is_fee_paid_by_user=False,
            is_fixed_rate=True,
            order_description="Apple Macbook Pro 2019 x 1",
            order_id="RGDBP-21314",
            pay_currency="btc",
            price_amount=3999.5,
            price_currency="usd",
            x_api_key="{{your_api_key}}",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            payment = await response.parse()
            assert_matches_type(PaymentCreateResponse, payment, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_retrieve(self, async_client: AsyncNowpaymentClient) -> None:
        payment = await async_client.payment.retrieve(
            payment_id="",
            x_api_key="{{your_api_key}}",
        )
        assert_matches_type(PaymentRetrieveResponse, payment, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_raw_response_retrieve(self, async_client: AsyncNowpaymentClient) -> None:
        response = await async_client.payment.with_raw_response.retrieve(
            payment_id="",
            x_api_key="{{your_api_key}}",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        payment = await response.parse()
        assert_matches_type(PaymentRetrieveResponse, payment, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_streaming_response_retrieve(self, async_client: AsyncNowpaymentClient) -> None:
        async with async_client.payment.with_streaming_response.retrieve(
            payment_id="",
            x_api_key="{{your_api_key}}",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            payment = await response.parse()
            assert_matches_type(PaymentRetrieveResponse, payment, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_path_params_retrieve(self, async_client: AsyncNowpaymentClient) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `payment_id` but received ''"):
            await async_client.payment.with_raw_response.retrieve(
                payment_id="",
                x_api_key="{{your_api_key}}",
            )

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_list(self, async_client: AsyncNowpaymentClient) -> None:
        payment = await async_client.payment.list(
            date_from="dateFrom",
            date_to="dateTo",
            limit="limit",
            order_by="orderBy",
            page="page",
            sort_by="sortBy",
            x_api_key="{{your_api_key}}",
        )
        assert_matches_type(PaymentListResponse, payment, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_raw_response_list(self, async_client: AsyncNowpaymentClient) -> None:
        response = await async_client.payment.with_raw_response.list(
            date_from="dateFrom",
            date_to="dateTo",
            limit="limit",
            order_by="orderBy",
            page="page",
            sort_by="sortBy",
            x_api_key="{{your_api_key}}",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        payment = await response.parse()
        assert_matches_type(PaymentListResponse, payment, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_streaming_response_list(self, async_client: AsyncNowpaymentClient) -> None:
        async with async_client.payment.with_streaming_response.list(
            date_from="dateFrom",
            date_to="dateTo",
            limit="limit",
            order_by="orderBy",
            page="page",
            sort_by="sortBy",
            x_api_key="{{your_api_key}}",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            payment = await response.parse()
            assert_matches_type(PaymentListResponse, payment, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_update_estimate(self, async_client: AsyncNowpaymentClient) -> None:
        payment = await async_client.payment.update_estimate(
            id="",
            x_api_key="{{api-key}}",
        )
        assert_matches_type(PaymentUpdateEstimateResponse, payment, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_raw_response_update_estimate(self, async_client: AsyncNowpaymentClient) -> None:
        response = await async_client.payment.with_raw_response.update_estimate(
            id="",
            x_api_key="{{api-key}}",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        payment = await response.parse()
        assert_matches_type(PaymentUpdateEstimateResponse, payment, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_streaming_response_update_estimate(self, async_client: AsyncNowpaymentClient) -> None:
        async with async_client.payment.with_streaming_response.update_estimate(
            id="",
            x_api_key="{{api-key}}",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            payment = await response.parse()
            assert_matches_type(PaymentUpdateEstimateResponse, payment, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_path_params_update_estimate(self, async_client: AsyncNowpaymentClient) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `id` but received ''"):
            await async_client.payment.with_raw_response.update_estimate(
                id="",
                x_api_key="{{api-key}}",
            )
