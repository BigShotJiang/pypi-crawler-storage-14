# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import os
from typing import Any, cast

import pytest

from tests.utils import assert_matches_type
from nowpayment_client import NowpaymentClient, AsyncNowpaymentClient
from nowpayment_client.types import MerchantListCoinsResponse

base_url = os.environ.get("TEST_API_BASE_URL", "http://127.0.0.1:4010")


class TestMerchant:
    parametrize = pytest.mark.parametrize("client", [False, True], indirect=True, ids=["loose", "strict"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_list_coins(self, client: NowpaymentClient) -> None:
        merchant = client.merchant.list_coins(
            x_api_key="{{your_api_key}}",
        )
        assert_matches_type(MerchantListCoinsResponse, merchant, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_raw_response_list_coins(self, client: NowpaymentClient) -> None:
        response = client.merchant.with_raw_response.list_coins(
            x_api_key="{{your_api_key}}",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        merchant = response.parse()
        assert_matches_type(MerchantListCoinsResponse, merchant, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_streaming_response_list_coins(self, client: NowpaymentClient) -> None:
        with client.merchant.with_streaming_response.list_coins(
            x_api_key="{{your_api_key}}",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            merchant = response.parse()
            assert_matches_type(MerchantListCoinsResponse, merchant, path=["response"])

        assert cast(Any, response.is_closed) is True


class TestAsyncMerchant:
    parametrize = pytest.mark.parametrize(
        "async_client", [False, True, {"http_client": "aiohttp"}], indirect=True, ids=["loose", "strict", "aiohttp"]
    )

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_list_coins(self, async_client: AsyncNowpaymentClient) -> None:
        merchant = await async_client.merchant.list_coins(
            x_api_key="{{your_api_key}}",
        )
        assert_matches_type(MerchantListCoinsResponse, merchant, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_raw_response_list_coins(self, async_client: AsyncNowpaymentClient) -> None:
        response = await async_client.merchant.with_raw_response.list_coins(
            x_api_key="{{your_api_key}}",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        merchant = await response.parse()
        assert_matches_type(MerchantListCoinsResponse, merchant, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_streaming_response_list_coins(self, async_client: AsyncNowpaymentClient) -> None:
        async with async_client.merchant.with_streaming_response.list_coins(
            x_api_key="{{your_api_key}}",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            merchant = await response.parse()
            assert_matches_type(MerchantListCoinsResponse, merchant, path=["response"])

        assert cast(Any, response.is_closed) is True
