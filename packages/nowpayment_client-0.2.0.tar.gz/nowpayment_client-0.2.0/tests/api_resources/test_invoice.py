# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import os
from typing import Any, cast

import pytest

from tests.utils import assert_matches_type
from nowpayment_client import NowpaymentClient, AsyncNowpaymentClient
from nowpayment_client.types import InvoiceCreateResponse

base_url = os.environ.get("TEST_API_BASE_URL", "http://127.0.0.1:4010")


class TestInvoice:
    parametrize = pytest.mark.parametrize("client", [False, True], indirect=True, ids=["loose", "strict"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_create(self, client: NowpaymentClient) -> None:
        invoice = client.invoice.create(
            cancel_url="https://nowpayments.io",
            ipn_callback_url="https://nowpayments.io",
            is_fee_paid_by_user=False,
            is_fixed_rate=True,
            order_description="Apple Macbook Pro 2019 x 1",
            order_id="RGDBP-21314",
            partially_paid_url="https://nowpayments.io",
            price_amount=1000,
            price_currency="usd",
            success_url="https://nowpayments.io",
            x_api_key="{{api-key}}",
        )
        assert_matches_type(InvoiceCreateResponse, invoice, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_raw_response_create(self, client: NowpaymentClient) -> None:
        response = client.invoice.with_raw_response.create(
            cancel_url="https://nowpayments.io",
            ipn_callback_url="https://nowpayments.io",
            is_fee_paid_by_user=False,
            is_fixed_rate=True,
            order_description="Apple Macbook Pro 2019 x 1",
            order_id="RGDBP-21314",
            partially_paid_url="https://nowpayments.io",
            price_amount=1000,
            price_currency="usd",
            success_url="https://nowpayments.io",
            x_api_key="{{api-key}}",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        invoice = response.parse()
        assert_matches_type(InvoiceCreateResponse, invoice, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_streaming_response_create(self, client: NowpaymentClient) -> None:
        with client.invoice.with_streaming_response.create(
            cancel_url="https://nowpayments.io",
            ipn_callback_url="https://nowpayments.io",
            is_fee_paid_by_user=False,
            is_fixed_rate=True,
            order_description="Apple Macbook Pro 2019 x 1",
            order_id="RGDBP-21314",
            partially_paid_url="https://nowpayments.io",
            price_amount=1000,
            price_currency="usd",
            success_url="https://nowpayments.io",
            x_api_key="{{api-key}}",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            invoice = response.parse()
            assert_matches_type(InvoiceCreateResponse, invoice, path=["response"])

        assert cast(Any, response.is_closed) is True


class TestAsyncInvoice:
    parametrize = pytest.mark.parametrize(
        "async_client", [False, True, {"http_client": "aiohttp"}], indirect=True, ids=["loose", "strict", "aiohttp"]
    )

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_create(self, async_client: AsyncNowpaymentClient) -> None:
        invoice = await async_client.invoice.create(
            cancel_url="https://nowpayments.io",
            ipn_callback_url="https://nowpayments.io",
            is_fee_paid_by_user=False,
            is_fixed_rate=True,
            order_description="Apple Macbook Pro 2019 x 1",
            order_id="RGDBP-21314",
            partially_paid_url="https://nowpayments.io",
            price_amount=1000,
            price_currency="usd",
            success_url="https://nowpayments.io",
            x_api_key="{{api-key}}",
        )
        assert_matches_type(InvoiceCreateResponse, invoice, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_raw_response_create(self, async_client: AsyncNowpaymentClient) -> None:
        response = await async_client.invoice.with_raw_response.create(
            cancel_url="https://nowpayments.io",
            ipn_callback_url="https://nowpayments.io",
            is_fee_paid_by_user=False,
            is_fixed_rate=True,
            order_description="Apple Macbook Pro 2019 x 1",
            order_id="RGDBP-21314",
            partially_paid_url="https://nowpayments.io",
            price_amount=1000,
            price_currency="usd",
            success_url="https://nowpayments.io",
            x_api_key="{{api-key}}",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        invoice = await response.parse()
        assert_matches_type(InvoiceCreateResponse, invoice, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_streaming_response_create(self, async_client: AsyncNowpaymentClient) -> None:
        async with async_client.invoice.with_streaming_response.create(
            cancel_url="https://nowpayments.io",
            ipn_callback_url="https://nowpayments.io",
            is_fee_paid_by_user=False,
            is_fixed_rate=True,
            order_description="Apple Macbook Pro 2019 x 1",
            order_id="RGDBP-21314",
            partially_paid_url="https://nowpayments.io",
            price_amount=1000,
            price_currency="usd",
            success_url="https://nowpayments.io",
            x_api_key="{{api-key}}",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            invoice = await response.parse()
            assert_matches_type(InvoiceCreateResponse, invoice, path=["response"])

        assert cast(Any, response.is_closed) is True
