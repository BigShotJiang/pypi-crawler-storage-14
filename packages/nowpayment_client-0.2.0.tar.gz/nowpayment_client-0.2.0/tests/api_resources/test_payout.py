# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import os
from typing import Any, cast

import httpx
import pytest
from respx import MockRouter

from tests.utils import assert_matches_type
from nowpayment_client import NowpaymentClient, AsyncNowpaymentClient
from nowpayment_client.types import (
    PayoutListResponse,
    PayoutCreateResponse,
    PayoutGetFeeEstimateResponse,
    PayoutRetrieveStatusResponse,
)
from nowpayment_client._response import (
    BinaryAPIResponse,
    AsyncBinaryAPIResponse,
    StreamedBinaryAPIResponse,
    AsyncStreamedBinaryAPIResponse,
)

base_url = os.environ.get("TEST_API_BASE_URL", "http://127.0.0.1:4010")


class TestPayout:
    parametrize = pytest.mark.parametrize("client", [False, True], indirect=True, ids=["loose", "strict"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_create(self, client: NowpaymentClient) -> None:
        payout = client.payout.create(
            ipn_callback_url="https://nowpayments.io",
            payout_description="description",
            withdrawals=[
                {
                    "address": "TEmGwPeRTPiLFLVfBxXkSP91yc5GMNQhfS",
                    "amount": 200,
                    "currency": "trx",
                    "ipn_callback_url": "https://nowpayments.io",
                },
                {
                    "address": "0x1EBAeF7Bee7B3a7B2EEfC72e86593Bf15ED37522",
                    "amount": 0.1,
                    "currency": "eth",
                    "ipn_callback_url": "https://nowpayments.io",
                },
            ],
            x_api_key="<your_api_key>",
        )
        assert_matches_type(PayoutCreateResponse, payout, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_raw_response_create(self, client: NowpaymentClient) -> None:
        response = client.payout.with_raw_response.create(
            ipn_callback_url="https://nowpayments.io",
            payout_description="description",
            withdrawals=[
                {
                    "address": "TEmGwPeRTPiLFLVfBxXkSP91yc5GMNQhfS",
                    "amount": 200,
                    "currency": "trx",
                    "ipn_callback_url": "https://nowpayments.io",
                },
                {
                    "address": "0x1EBAeF7Bee7B3a7B2EEfC72e86593Bf15ED37522",
                    "amount": 0.1,
                    "currency": "eth",
                    "ipn_callback_url": "https://nowpayments.io",
                },
            ],
            x_api_key="<your_api_key>",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        payout = response.parse()
        assert_matches_type(PayoutCreateResponse, payout, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_streaming_response_create(self, client: NowpaymentClient) -> None:
        with client.payout.with_streaming_response.create(
            ipn_callback_url="https://nowpayments.io",
            payout_description="description",
            withdrawals=[
                {
                    "address": "TEmGwPeRTPiLFLVfBxXkSP91yc5GMNQhfS",
                    "amount": 200,
                    "currency": "trx",
                    "ipn_callback_url": "https://nowpayments.io",
                },
                {
                    "address": "0x1EBAeF7Bee7B3a7B2EEfC72e86593Bf15ED37522",
                    "amount": 0.1,
                    "currency": "eth",
                    "ipn_callback_url": "https://nowpayments.io",
                },
            ],
            x_api_key="<your_api_key>",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            payout = response.parse()
            assert_matches_type(PayoutCreateResponse, payout, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_list(self, client: NowpaymentClient) -> None:
        payout = client.payout.list(
            x_api_key="{{your_api_key}}",
        )
        assert_matches_type(PayoutListResponse, payout, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_raw_response_list(self, client: NowpaymentClient) -> None:
        response = client.payout.with_raw_response.list(
            x_api_key="{{your_api_key}}",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        payout = response.parse()
        assert_matches_type(PayoutListResponse, payout, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_streaming_response_list(self, client: NowpaymentClient) -> None:
        with client.payout.with_streaming_response.list(
            x_api_key="{{your_api_key}}",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            payout = response.parse()
            assert_matches_type(PayoutListResponse, payout, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_get_fee_estimate(self, client: NowpaymentClient) -> None:
        payout = client.payout.get_fee_estimate(
            amount="amount",
            currency="currency",
            x_api_key="{{api-key}}",
        )
        assert_matches_type(PayoutGetFeeEstimateResponse, payout, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_raw_response_get_fee_estimate(self, client: NowpaymentClient) -> None:
        response = client.payout.with_raw_response.get_fee_estimate(
            amount="amount",
            currency="currency",
            x_api_key="{{api-key}}",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        payout = response.parse()
        assert_matches_type(PayoutGetFeeEstimateResponse, payout, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_streaming_response_get_fee_estimate(self, client: NowpaymentClient) -> None:
        with client.payout.with_streaming_response.get_fee_estimate(
            amount="amount",
            currency="currency",
            x_api_key="{{api-key}}",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            payout = response.parse()
            assert_matches_type(PayoutGetFeeEstimateResponse, payout, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_retrieve_status(self, client: NowpaymentClient) -> None:
        payout = client.payout.retrieve_status(
            payout_id="",
            x_api_key="{{api-key}}",
        )
        assert_matches_type(PayoutRetrieveStatusResponse, payout, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_raw_response_retrieve_status(self, client: NowpaymentClient) -> None:
        response = client.payout.with_raw_response.retrieve_status(
            payout_id="",
            x_api_key="{{api-key}}",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        payout = response.parse()
        assert_matches_type(PayoutRetrieveStatusResponse, payout, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_streaming_response_retrieve_status(self, client: NowpaymentClient) -> None:
        with client.payout.with_streaming_response.retrieve_status(
            payout_id="",
            x_api_key="{{api-key}}",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            payout = response.parse()
            assert_matches_type(PayoutRetrieveStatusResponse, payout, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_path_params_retrieve_status(self, client: NowpaymentClient) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `payout_id` but received ''"):
            client.payout.with_raw_response.retrieve_status(
                payout_id="",
                x_api_key="{{api-key}}",
            )

    @parametrize
    @pytest.mark.respx(base_url=base_url)
    def test_method_validate_address(self, client: NowpaymentClient, respx_mock: MockRouter) -> None:
        respx_mock.post("/v1/payout/validate-address").mock(return_value=httpx.Response(200, json={"foo": "bar"}))
        payout = client.payout.validate_address(
            x_api_key="{{your_api_key}}",
        )
        assert payout.is_closed
        assert payout.json() == {"foo": "bar"}
        assert cast(Any, payout.is_closed) is True
        assert isinstance(payout, BinaryAPIResponse)

    @parametrize
    @pytest.mark.respx(base_url=base_url)
    def test_method_validate_address_with_all_params(self, client: NowpaymentClient, respx_mock: MockRouter) -> None:
        respx_mock.post("/v1/payout/validate-address").mock(return_value=httpx.Response(200, json={"foo": "bar"}))
        payout = client.payout.validate_address(
            x_api_key="{{your_api_key}}",
            body="body",
        )
        assert payout.is_closed
        assert payout.json() == {"foo": "bar"}
        assert cast(Any, payout.is_closed) is True
        assert isinstance(payout, BinaryAPIResponse)

    @parametrize
    @pytest.mark.respx(base_url=base_url)
    def test_raw_response_validate_address(self, client: NowpaymentClient, respx_mock: MockRouter) -> None:
        respx_mock.post("/v1/payout/validate-address").mock(return_value=httpx.Response(200, json={"foo": "bar"}))

        payout = client.payout.with_raw_response.validate_address(
            x_api_key="{{your_api_key}}",
        )

        assert payout.is_closed is True
        assert payout.http_request.headers.get("X-Stainless-Lang") == "python"
        assert payout.json() == {"foo": "bar"}
        assert isinstance(payout, BinaryAPIResponse)

    @parametrize
    @pytest.mark.respx(base_url=base_url)
    def test_streaming_response_validate_address(self, client: NowpaymentClient, respx_mock: MockRouter) -> None:
        respx_mock.post("/v1/payout/validate-address").mock(return_value=httpx.Response(200, json={"foo": "bar"}))
        with client.payout.with_streaming_response.validate_address(
            x_api_key="{{your_api_key}}",
        ) as payout:
            assert not payout.is_closed
            assert payout.http_request.headers.get("X-Stainless-Lang") == "python"

            assert payout.json() == {"foo": "bar"}
            assert cast(Any, payout.is_closed) is True
            assert isinstance(payout, StreamedBinaryAPIResponse)

        assert cast(Any, payout.is_closed) is True

    @parametrize
    @pytest.mark.respx(base_url=base_url)
    def test_method_verify(self, client: NowpaymentClient, respx_mock: MockRouter) -> None:
        respx_mock.post("/v1/payout//verify").mock(return_value=httpx.Response(200, json={"foo": "bar"}))
        payout = client.payout.verify(
            batch_withdrawal_id="",
            verification_code="123456",
            x_api_key="{{your_api_key}}",
        )
        assert payout.is_closed
        assert payout.json() == {"foo": "bar"}
        assert cast(Any, payout.is_closed) is True
        assert isinstance(payout, BinaryAPIResponse)

    @parametrize
    @pytest.mark.respx(base_url=base_url)
    def test_raw_response_verify(self, client: NowpaymentClient, respx_mock: MockRouter) -> None:
        respx_mock.post("/v1/payout//verify").mock(return_value=httpx.Response(200, json={"foo": "bar"}))

        payout = client.payout.with_raw_response.verify(
            batch_withdrawal_id="",
            verification_code="123456",
            x_api_key="{{your_api_key}}",
        )

        assert payout.is_closed is True
        assert payout.http_request.headers.get("X-Stainless-Lang") == "python"
        assert payout.json() == {"foo": "bar"}
        assert isinstance(payout, BinaryAPIResponse)

    @parametrize
    @pytest.mark.respx(base_url=base_url)
    def test_streaming_response_verify(self, client: NowpaymentClient, respx_mock: MockRouter) -> None:
        respx_mock.post("/v1/payout//verify").mock(return_value=httpx.Response(200, json={"foo": "bar"}))
        with client.payout.with_streaming_response.verify(
            batch_withdrawal_id="",
            verification_code="123456",
            x_api_key="{{your_api_key}}",
        ) as payout:
            assert not payout.is_closed
            assert payout.http_request.headers.get("X-Stainless-Lang") == "python"

            assert payout.json() == {"foo": "bar"}
            assert cast(Any, payout.is_closed) is True
            assert isinstance(payout, StreamedBinaryAPIResponse)

        assert cast(Any, payout.is_closed) is True

    @parametrize
    @pytest.mark.respx(base_url=base_url)
    def test_path_params_verify(self, client: NowpaymentClient) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `batch_withdrawal_id` but received ''"):
            client.payout.with_raw_response.verify(
                batch_withdrawal_id="",
                verification_code="123456",
                x_api_key="{{your_api_key}}",
            )


class TestAsyncPayout:
    parametrize = pytest.mark.parametrize(
        "async_client", [False, True, {"http_client": "aiohttp"}], indirect=True, ids=["loose", "strict", "aiohttp"]
    )

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_create(self, async_client: AsyncNowpaymentClient) -> None:
        payout = await async_client.payout.create(
            ipn_callback_url="https://nowpayments.io",
            payout_description="description",
            withdrawals=[
                {
                    "address": "TEmGwPeRTPiLFLVfBxXkSP91yc5GMNQhfS",
                    "amount": 200,
                    "currency": "trx",
                    "ipn_callback_url": "https://nowpayments.io",
                },
                {
                    "address": "0x1EBAeF7Bee7B3a7B2EEfC72e86593Bf15ED37522",
                    "amount": 0.1,
                    "currency": "eth",
                    "ipn_callback_url": "https://nowpayments.io",
                },
            ],
            x_api_key="<your_api_key>",
        )
        assert_matches_type(PayoutCreateResponse, payout, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_raw_response_create(self, async_client: AsyncNowpaymentClient) -> None:
        response = await async_client.payout.with_raw_response.create(
            ipn_callback_url="https://nowpayments.io",
            payout_description="description",
            withdrawals=[
                {
                    "address": "TEmGwPeRTPiLFLVfBxXkSP91yc5GMNQhfS",
                    "amount": 200,
                    "currency": "trx",
                    "ipn_callback_url": "https://nowpayments.io",
                },
                {
                    "address": "0x1EBAeF7Bee7B3a7B2EEfC72e86593Bf15ED37522",
                    "amount": 0.1,
                    "currency": "eth",
                    "ipn_callback_url": "https://nowpayments.io",
                },
            ],
            x_api_key="<your_api_key>",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        payout = await response.parse()
        assert_matches_type(PayoutCreateResponse, payout, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_streaming_response_create(self, async_client: AsyncNowpaymentClient) -> None:
        async with async_client.payout.with_streaming_response.create(
            ipn_callback_url="https://nowpayments.io",
            payout_description="description",
            withdrawals=[
                {
                    "address": "TEmGwPeRTPiLFLVfBxXkSP91yc5GMNQhfS",
                    "amount": 200,
                    "currency": "trx",
                    "ipn_callback_url": "https://nowpayments.io",
                },
                {
                    "address": "0x1EBAeF7Bee7B3a7B2EEfC72e86593Bf15ED37522",
                    "amount": 0.1,
                    "currency": "eth",
                    "ipn_callback_url": "https://nowpayments.io",
                },
            ],
            x_api_key="<your_api_key>",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            payout = await response.parse()
            assert_matches_type(PayoutCreateResponse, payout, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_list(self, async_client: AsyncNowpaymentClient) -> None:
        payout = await async_client.payout.list(
            x_api_key="{{your_api_key}}",
        )
        assert_matches_type(PayoutListResponse, payout, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_raw_response_list(self, async_client: AsyncNowpaymentClient) -> None:
        response = await async_client.payout.with_raw_response.list(
            x_api_key="{{your_api_key}}",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        payout = await response.parse()
        assert_matches_type(PayoutListResponse, payout, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_streaming_response_list(self, async_client: AsyncNowpaymentClient) -> None:
        async with async_client.payout.with_streaming_response.list(
            x_api_key="{{your_api_key}}",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            payout = await response.parse()
            assert_matches_type(PayoutListResponse, payout, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_get_fee_estimate(self, async_client: AsyncNowpaymentClient) -> None:
        payout = await async_client.payout.get_fee_estimate(
            amount="amount",
            currency="currency",
            x_api_key="{{api-key}}",
        )
        assert_matches_type(PayoutGetFeeEstimateResponse, payout, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_raw_response_get_fee_estimate(self, async_client: AsyncNowpaymentClient) -> None:
        response = await async_client.payout.with_raw_response.get_fee_estimate(
            amount="amount",
            currency="currency",
            x_api_key="{{api-key}}",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        payout = await response.parse()
        assert_matches_type(PayoutGetFeeEstimateResponse, payout, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_streaming_response_get_fee_estimate(self, async_client: AsyncNowpaymentClient) -> None:
        async with async_client.payout.with_streaming_response.get_fee_estimate(
            amount="amount",
            currency="currency",
            x_api_key="{{api-key}}",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            payout = await response.parse()
            assert_matches_type(PayoutGetFeeEstimateResponse, payout, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_retrieve_status(self, async_client: AsyncNowpaymentClient) -> None:
        payout = await async_client.payout.retrieve_status(
            payout_id="",
            x_api_key="{{api-key}}",
        )
        assert_matches_type(PayoutRetrieveStatusResponse, payout, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_raw_response_retrieve_status(self, async_client: AsyncNowpaymentClient) -> None:
        response = await async_client.payout.with_raw_response.retrieve_status(
            payout_id="",
            x_api_key="{{api-key}}",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        payout = await response.parse()
        assert_matches_type(PayoutRetrieveStatusResponse, payout, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_streaming_response_retrieve_status(self, async_client: AsyncNowpaymentClient) -> None:
        async with async_client.payout.with_streaming_response.retrieve_status(
            payout_id="",
            x_api_key="{{api-key}}",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            payout = await response.parse()
            assert_matches_type(PayoutRetrieveStatusResponse, payout, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_path_params_retrieve_status(self, async_client: AsyncNowpaymentClient) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `payout_id` but received ''"):
            await async_client.payout.with_raw_response.retrieve_status(
                payout_id="",
                x_api_key="{{api-key}}",
            )

    @parametrize
    @pytest.mark.respx(base_url=base_url)
    async def test_method_validate_address(self, async_client: AsyncNowpaymentClient, respx_mock: MockRouter) -> None:
        respx_mock.post("/v1/payout/validate-address").mock(return_value=httpx.Response(200, json={"foo": "bar"}))
        payout = await async_client.payout.validate_address(
            x_api_key="{{your_api_key}}",
        )
        assert payout.is_closed
        assert await payout.json() == {"foo": "bar"}
        assert cast(Any, payout.is_closed) is True
        assert isinstance(payout, AsyncBinaryAPIResponse)

    @parametrize
    @pytest.mark.respx(base_url=base_url)
    async def test_method_validate_address_with_all_params(
        self, async_client: AsyncNowpaymentClient, respx_mock: MockRouter
    ) -> None:
        respx_mock.post("/v1/payout/validate-address").mock(return_value=httpx.Response(200, json={"foo": "bar"}))
        payout = await async_client.payout.validate_address(
            x_api_key="{{your_api_key}}",
            body="body",
        )
        assert payout.is_closed
        assert await payout.json() == {"foo": "bar"}
        assert cast(Any, payout.is_closed) is True
        assert isinstance(payout, AsyncBinaryAPIResponse)

    @parametrize
    @pytest.mark.respx(base_url=base_url)
    async def test_raw_response_validate_address(
        self, async_client: AsyncNowpaymentClient, respx_mock: MockRouter
    ) -> None:
        respx_mock.post("/v1/payout/validate-address").mock(return_value=httpx.Response(200, json={"foo": "bar"}))

        payout = await async_client.payout.with_raw_response.validate_address(
            x_api_key="{{your_api_key}}",
        )

        assert payout.is_closed is True
        assert payout.http_request.headers.get("X-Stainless-Lang") == "python"
        assert await payout.json() == {"foo": "bar"}
        assert isinstance(payout, AsyncBinaryAPIResponse)

    @parametrize
    @pytest.mark.respx(base_url=base_url)
    async def test_streaming_response_validate_address(
        self, async_client: AsyncNowpaymentClient, respx_mock: MockRouter
    ) -> None:
        respx_mock.post("/v1/payout/validate-address").mock(return_value=httpx.Response(200, json={"foo": "bar"}))
        async with async_client.payout.with_streaming_response.validate_address(
            x_api_key="{{your_api_key}}",
        ) as payout:
            assert not payout.is_closed
            assert payout.http_request.headers.get("X-Stainless-Lang") == "python"

            assert await payout.json() == {"foo": "bar"}
            assert cast(Any, payout.is_closed) is True
            assert isinstance(payout, AsyncStreamedBinaryAPIResponse)

        assert cast(Any, payout.is_closed) is True

    @parametrize
    @pytest.mark.respx(base_url=base_url)
    async def test_method_verify(self, async_client: AsyncNowpaymentClient, respx_mock: MockRouter) -> None:
        respx_mock.post("/v1/payout//verify").mock(return_value=httpx.Response(200, json={"foo": "bar"}))
        payout = await async_client.payout.verify(
            batch_withdrawal_id="",
            verification_code="123456",
            x_api_key="{{your_api_key}}",
        )
        assert payout.is_closed
        assert await payout.json() == {"foo": "bar"}
        assert cast(Any, payout.is_closed) is True
        assert isinstance(payout, AsyncBinaryAPIResponse)

    @parametrize
    @pytest.mark.respx(base_url=base_url)
    async def test_raw_response_verify(self, async_client: AsyncNowpaymentClient, respx_mock: MockRouter) -> None:
        respx_mock.post("/v1/payout//verify").mock(return_value=httpx.Response(200, json={"foo": "bar"}))

        payout = await async_client.payout.with_raw_response.verify(
            batch_withdrawal_id="",
            verification_code="123456",
            x_api_key="{{your_api_key}}",
        )

        assert payout.is_closed is True
        assert payout.http_request.headers.get("X-Stainless-Lang") == "python"
        assert await payout.json() == {"foo": "bar"}
        assert isinstance(payout, AsyncBinaryAPIResponse)

    @parametrize
    @pytest.mark.respx(base_url=base_url)
    async def test_streaming_response_verify(self, async_client: AsyncNowpaymentClient, respx_mock: MockRouter) -> None:
        respx_mock.post("/v1/payout//verify").mock(return_value=httpx.Response(200, json={"foo": "bar"}))
        async with async_client.payout.with_streaming_response.verify(
            batch_withdrawal_id="",
            verification_code="123456",
            x_api_key="{{your_api_key}}",
        ) as payout:
            assert not payout.is_closed
            assert payout.http_request.headers.get("X-Stainless-Lang") == "python"

            assert await payout.json() == {"foo": "bar"}
            assert cast(Any, payout.is_closed) is True
            assert isinstance(payout, AsyncStreamedBinaryAPIResponse)

        assert cast(Any, payout.is_closed) is True

    @parametrize
    @pytest.mark.respx(base_url=base_url)
    async def test_path_params_verify(self, async_client: AsyncNowpaymentClient) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `batch_withdrawal_id` but received ''"):
            await async_client.payout.with_raw_response.verify(
                batch_withdrawal_id="",
                verification_code="123456",
                x_api_key="{{your_api_key}}",
            )
