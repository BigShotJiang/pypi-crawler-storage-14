"""RAMSES RF - a RAMSES-II protocol decoder & analyser (transport layer)."""

__version__ = "0.52.4"
VERSION = __version__
