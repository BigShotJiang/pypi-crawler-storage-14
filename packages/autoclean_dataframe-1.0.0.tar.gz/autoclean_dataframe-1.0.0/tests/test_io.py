"""Tests for I/O functions."""

import pytest
import json
import tempfile
from pathlib import Path

from autoclean_dataframe import (
    DataCleanConfig,
    GeneralCleanConfig,
    ColumnConfig,
    TypeConversionConfig,
    load_config,
    save_config,
    save_report,
    load_config_dict,
    config_to_dict,
    config_to_yaml,
    config_to_json,
    ConfigValidationError,
    ReportExportError,
)
from autoclean_dataframe.report import CleanReport


class TestLoadConfigDict:
    """Tests for loading config from dictionary."""

    def test_load_config_dict_basic(self):
        """Test loading basic config from dict."""
        config_dict = {
            "general": {"remove_duplicates": True},
            "columns": {},
        }
        config = load_config_dict(config_dict)
        assert config.general.remove_duplicates is True

    def test_load_config_dict_with_columns(self):
        """Test loading config with column config from dict."""
        config_dict = {
            "general": {},
            "columns": {
                "age": {
                    "column_name": "age",
                    "type_conversion": {"target_type": "int"},
                }
            },
        }
        config = load_config_dict(config_dict)
        assert "age" in config.columns
        assert config.columns["age"].type_conversion.target_type == "int"

    def test_load_config_dict_invalid(self):
        """Test that invalid dict raises ConfigValidationError."""
        config_dict = {
            "invalid_field": "value",
        }
        with pytest.raises(ConfigValidationError):
            load_config_dict(config_dict)


class TestConfigToDict:
    """Tests for converting config to dictionary."""

    def test_config_to_dict_basic(self):
        """Test converting basic config to dict."""
        config = DataCleanConfig(
            general=GeneralCleanConfig(remove_duplicates=True)
        )
        config_dict = config_to_dict(config)
        assert isinstance(config_dict, dict)
        assert config_dict["general"]["remove_duplicates"] is True

    def test_config_to_dict_with_columns(self):
        """Test converting config with columns to dict."""
        config = DataCleanConfig(
            columns={
                "age": ColumnConfig(
                    column_name="age",
                    type_conversion=TypeConversionConfig(target_type="int"),
                )
            }
        )
        config_dict = config_to_dict(config)
        assert "age" in config_dict["columns"]


class TestConfigToYaml:
    """Tests for converting config to YAML string."""

    def test_config_to_yaml(self):
        """Test converting config to YAML."""
        config = DataCleanConfig(
            general=GeneralCleanConfig(remove_duplicates=True)
        )
        yaml_str = config_to_yaml(config)
        assert isinstance(yaml_str, str)
        assert "remove_duplicates" in yaml_str

    def test_config_to_yaml_readability(self):
        """Test that YAML output is readable."""
        config = DataCleanConfig(
            general=GeneralCleanConfig(remove_duplicates=True)
        )
        yaml_str = config_to_yaml(config)
        # YAML should have newlines for readability
        assert "\n" in yaml_str


class TestConfigToJson:
    """Tests for converting config to JSON string."""

    def test_config_to_json(self):
        """Test converting config to JSON."""
        config = DataCleanConfig(
            general=GeneralCleanConfig(remove_duplicates=True)
        )
        json_str = config_to_json(config)
        assert isinstance(json_str, str)
        # Should be valid JSON
        parsed = json.loads(json_str)
        assert parsed["general"]["remove_duplicates"] is True

    def test_config_to_json_formatting(self):
        """Test that JSON output is formatted."""
        config = DataCleanConfig()
        json_str = config_to_json(config)
        # Should be indented
        assert "  " in json_str or "   " in json_str


class TestSaveAndLoadConfigYaml:
    """Tests for saving/loading YAML config files."""

    def test_save_and_load_yaml_config(self):
        """Test round-trip YAML config save/load."""
        with tempfile.TemporaryDirectory() as tmpdir:
            config_path = Path(tmpdir) / "config.yaml"

            # Create and save config
            original_config = DataCleanConfig(
                general=GeneralCleanConfig(remove_duplicates=True),
                columns={
                    "age": ColumnConfig(
                        column_name="age",
                        type_conversion=TypeConversionConfig(target_type="int"),
                    )
                }
            )
            save_config(original_config, config_path, format="yaml")

            # Load and verify
            loaded_config = load_config(config_path)
            assert loaded_config.general.remove_duplicates is True
            assert "age" in loaded_config.columns

    def test_load_nonexistent_config(self):
        """Test loading non-existent config file."""
        with pytest.raises(FileNotFoundError):
            load_config("/nonexistent/path/config.yaml")

    def test_load_invalid_yaml(self):
        """Test loading invalid YAML file."""
        with tempfile.TemporaryDirectory() as tmpdir:
            config_path = Path(tmpdir) / "bad.yaml"
            # Write invalid YAML
            with open(config_path, "w") as f:
                f.write("{ invalid: yaml: content ]")

            with pytest.raises(ConfigValidationError):
                load_config(config_path)


class TestSaveAndLoadConfigJson:
    """Tests for saving/loading JSON config files."""

    def test_save_and_load_json_config(self):
        """Test round-trip JSON config save/load."""
        with tempfile.TemporaryDirectory() as tmpdir:
            config_path = Path(tmpdir) / "config.json"

            # Create and save config
            original_config = DataCleanConfig(
                general=GeneralCleanConfig(drop_fully_empty_rows=True)
            )
            save_config(original_config, config_path, format="json")

            # Load and verify
            loaded_config = load_config(config_path)
            assert loaded_config.general.drop_fully_empty_rows is True

    def test_load_invalid_json(self):
        """Test loading invalid JSON file."""
        with tempfile.TemporaryDirectory() as tmpdir:
            config_path = Path(tmpdir) / "bad.json"
            # Write invalid JSON
            with open(config_path, "w") as f:
                f.write("{ invalid json ]")

            with pytest.raises(ConfigValidationError):
                load_config(config_path)


class TestSaveConfigErrors:
    """Tests for config save error handling."""

    def test_save_config_invalid_format(self):
        """Test saving config with invalid format."""
        config = DataCleanConfig()
        with tempfile.TemporaryDirectory() as tmpdir:
            config_path = Path(tmpdir) / "config.xyz"

            with pytest.raises(ValueError):
                save_config(config, config_path, format="xyz")

    def test_save_config_invalid_path(self):
        """Test saving config to invalid path."""
        config = DataCleanConfig()
        invalid_path = Path("/invalid/nonexistent/path/config.yaml")

        with pytest.raises(ReportExportError):
            save_config(config, invalid_path)


class TestLoadConfigAuto:
    """Tests for auto-detecting file format."""

    def test_load_config_auto_yaml(self):
        """Test auto-detecting YAML format."""
        with tempfile.TemporaryDirectory() as tmpdir:
            config_path = Path(tmpdir) / "config.yaml"
            config = DataCleanConfig(
                general=GeneralCleanConfig(remove_duplicates=True)
            )
            save_config(config, config_path, format="yaml")

            loaded = load_config(config_path)
            assert loaded.general.remove_duplicates is True

    def test_load_config_auto_yml(self):
        """Test auto-detecting .yml format."""
        with tempfile.TemporaryDirectory() as tmpdir:
            config_path = Path(tmpdir) / "config.yml"
            config = DataCleanConfig()
            save_config(config, config_path, format="yaml")

            loaded = load_config(config_path)
            assert isinstance(loaded, DataCleanConfig)

    def test_load_config_auto_json(self):
        """Test auto-detecting JSON format."""
        with tempfile.TemporaryDirectory() as tmpdir:
            config_path = Path(tmpdir) / "config.json"
            config = DataCleanConfig()
            save_config(config, config_path, format="json")

            loaded = load_config(config_path)
            assert isinstance(loaded, DataCleanConfig)

    def test_load_config_unsupported_format(self):
        """Test loading unsupported file format."""
        with tempfile.TemporaryDirectory() as tmpdir:
            config_path = Path(tmpdir) / "config.txt"
            # Create dummy file
            config_path.write_text("some content")

            with pytest.raises(ValueError):
                load_config(config_path)


class TestSaveReport:
    """Tests for saving cleaning reports."""

    def test_save_report_json(self):
        """Test saving report as JSON."""
        with tempfile.TemporaryDirectory() as tmpdir:
            report_path = Path(tmpdir) / "report.json"
            report = CleanReport(rows_before=100, rows_after=90)

            save_report(report, report_path, format="json")
            assert report_path.exists()

            # Verify content
            with open(report_path) as f:
                data = json.load(f)
            assert data["rows_before"] == 100
            assert data["rows_after"] == 90

    def test_save_report_text(self):
        """Test saving report as text."""
        with tempfile.TemporaryDirectory() as tmpdir:
            report_path = Path(tmpdir) / "report.txt"
            report = CleanReport(rows_before=100, rows_after=90)

            save_report(report, report_path, format="txt")
            assert report_path.exists()

            # Verify content
            content = report_path.read_text()
            assert "DATA CLEANING REPORT" in content
            assert "rows_before" in content or "Rows before" in content

    def test_save_report_invalid_format(self):
        """Test saving report with invalid format."""
        report = CleanReport(rows_before=100, rows_after=90)

        with pytest.raises(ValueError):
            with tempfile.TemporaryDirectory() as tmpdir:
                save_report(
                    report,
                    Path(tmpdir) / "report.xyz",
                    format="xyz"
                )


class TestIntegrationConfigWorkflow:
    """Integration tests for config workflow."""

    def test_complete_workflow(self):
        """Test complete config save/load/modify workflow."""
        with tempfile.TemporaryDirectory() as tmpdir:
            config_path = Path(tmpdir) / "pipeline.yaml"

            # Create and save initial config
            config = DataCleanConfig(
                general=GeneralCleanConfig(remove_duplicates=True),
                columns={
                    "age": ColumnConfig(
                        column_name="age",
                        type_conversion=TypeConversionConfig(target_type="int"),
                    ),
                    "email": ColumnConfig(
                        column_name="email",
                        strip_whitespace=True,
                    ),
                }
            )
            save_config(config, config_path)

            # Load config
            loaded = load_config(config_path)
            assert len(loaded.columns) == 2
            assert loaded.general.remove_duplicates is True

            # Modify and save again
            loaded.general.remove_duplicates = False
            save_config(loaded, config_path)

            # Reload and verify change
            reloaded = load_config(config_path)
            assert reloaded.general.remove_duplicates is False
