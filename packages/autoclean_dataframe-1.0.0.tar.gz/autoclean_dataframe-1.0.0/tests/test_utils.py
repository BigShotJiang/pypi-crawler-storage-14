"""Tests for utility functions."""

import pytest
import pandas as pd
import numpy as np

from autoclean_dataframe import utils
from autoclean_dataframe.types import ColumnType


class TestTypeInference:
    """Tests for type inference functions."""

    def test_infer_numeric_type(self):
        """Test inferring numeric column type."""
        series = pd.Series([1, 2, 3, 4, 5])
        col_type = utils.infer_column_type(series)
        assert col_type == ColumnType.NUMERIC

    def test_infer_datetime_type(self):
        """Test inferring datetime column type."""
        series = pd.Series(pd.date_range("2020-01-01", periods=5))
        col_type = utils.infer_column_type(series)
        assert col_type == ColumnType.DATETIME

    def test_infer_text_type(self):
        """Test inferring text column type."""
        series = pd.Series(["hello", "world", "test"])
        col_type = utils.infer_column_type(series)
        assert col_type == ColumnType.TEXT

    def test_infer_categorical_type(self):
        """Test inferring categorical column type."""
        series = pd.Series(["a", "b", "a", "b", "a"])
        col_type = utils.infer_column_type(series)
        assert col_type == ColumnType.CATEGORICAL

    def test_infer_unknown_type(self):
        """Test inferring unknown type for empty series."""
        series = pd.Series([None, None, None])
        col_type = utils.infer_column_type(series)
        assert col_type == ColumnType.UNKNOWN

    def test_infer_datetime_like_strings(self):
        """Test inferring datetime-like strings as datetime."""
        series = pd.Series(["2020-01-01", "2021-06-15", "2022-12-31"])
        col_type = utils.infer_column_type(series)
        assert col_type == ColumnType.DATETIME


class TestEmailValidation:
    """Tests for email validation and masking."""

    def test_validate_email_valid(self):
        """Test validating valid email addresses."""
        assert utils.validate_email("john@example.com")
        assert utils.validate_email("test.user+tag@domain.co.uk")

    def test_validate_email_invalid(self):
        """Test validating invalid email addresses."""
        assert not utils.validate_email("not-an-email")
        assert not utils.validate_email("missing@.com")
        assert not utils.validate_email("@nodomain.com")

    def test_mask_email(self):
        """Test email masking."""
        masked = utils.mask_email("john@example.com")
        assert masked == "***@***.com"

    def test_mask_email_different_tld(self):
        """Test email masking with different TLD."""
        masked = utils.mask_email("test@domain.org")
        assert masked == "***@***.org"

    def test_mask_email_non_string(self):
        """Test masking non-string values."""
        result = utils.mask_email(123)
        assert result == 123


class TestPhoneValidation:
    """Tests for phone number validation and masking."""

    def test_validate_phone_valid(self):
        """Test validating valid phone numbers."""
        assert utils.validate_phone("555-123-4567")
        assert utils.validate_phone("(555) 123-4567")
        assert utils.validate_phone("+1 555-123-4567")

    def test_validate_phone_invalid(self):
        """Test validating invalid phone numbers."""
        assert not utils.validate_phone("123")
        assert not utils.validate_phone("not-a-phone")

    def test_mask_phone(self):
        """Test phone masking."""
        masked = utils.mask_phone("555-123-4567")
        assert "4567" in masked
        assert masked.count("*") >= 6

    def test_mask_phone_non_string(self):
        """Test masking non-string values."""
        result = utils.mask_phone(555123456)
        assert result == 555123456


class TestTextNormalization:
    """Tests for text normalization functions."""

    def test_normalize_unicode_nfc(self):
        """Test NFC normalization."""
        text = "café"
        normalized = utils.normalize_unicode(text, form="NFC")
        assert isinstance(normalized, str)

    def test_normalize_unicode_nfkc(self):
        """Test NFKC normalization."""
        text = "ﬁle"  # Ligature fi
        normalized = utils.normalize_unicode(text, form="NFKC")
        assert "fi" in normalized or "ﬁ" in normalized

    def test_normalize_unicode_non_string(self):
        """Test normalizing non-string values."""
        result = utils.normalize_unicode(123)
        assert result == 123


class TestBooleanParsing:
    """Tests for boolean value parsing."""

    def test_parse_boolean_true_values(self):
        """Test parsing various true representations."""
        assert utils.parse_boolean(True) is True
        assert utils.parse_boolean("true") is True
        assert utils.parse_boolean("True") is True
        assert utils.parse_boolean("yes") is True
        assert utils.parse_boolean("YES") is True
        assert utils.parse_boolean("y") is True
        assert utils.parse_boolean("1") is True
        assert utils.parse_boolean(1) is True
        assert utils.parse_boolean("on") is True

    def test_parse_boolean_false_values(self):
        """Test parsing various false representations."""
        assert utils.parse_boolean(False) is False
        assert utils.parse_boolean("false") is False
        assert utils.parse_boolean("False") is False
        assert utils.parse_boolean("no") is False
        assert utils.parse_boolean("NO") is False
        assert utils.parse_boolean("n") is False
        assert utils.parse_boolean("0") is False
        assert utils.parse_boolean(0) is False
        assert utils.parse_boolean("off") is False

    def test_parse_boolean_null(self):
        """Test parsing null values."""
        assert utils.parse_boolean(None) is None
        assert utils.parse_boolean(np.nan) is None

    def test_parse_boolean_invalid(self):
        """Test parsing invalid boolean values."""
        assert utils.parse_boolean("maybe") is None
        assert utils.parse_boolean("unknown") is None


class TestOutlierDetection:
    """Tests for outlier detection functions."""

    def test_detect_outliers_iqr(self):
        """Test IQR-based outlier detection."""
        series = pd.Series([1, 2, 3, 4, 5, 100])
        outliers = utils.detect_outliers_iqr(series, multiplier=1.5)
        assert outliers.iloc[-1]  # 100 should be flagged as outlier

    def test_detect_outliers_zscore(self):
        """Test Z-score-based outlier detection."""
        series = pd.Series([1, 2, 3, 4, 5, 100])
        outliers = utils.detect_outliers_zscore(series, threshold=3.0)
        assert outliers.iloc[-1]  # 100 should be flagged as outlier

    def test_detect_outliers_non_numeric(self):
        """Test outlier detection on non-numeric data."""
        series = pd.Series(["a", "b", "c"])
        outliers = utils.detect_outliers_iqr(series)
        assert not outliers.any()

    def test_clip_outliers_iqr(self):
        """Test clipping outliers."""
        series = pd.Series([1, 2, 3, 4, 5, 100])
        clipped = utils.clip_outliers_iqr(series, multiplier=1.5)
        assert clipped.max() < 100  # Max should be clipped


class TestMissingValueImputation:
    """Tests for missing value imputation functions."""

    def test_impute_mean(self):
        """Test mean imputation."""
        series = pd.Series([1.0, 2.0, np.nan, 4.0, 5.0])
        imputed = utils.impute_mean(series)
        assert not imputed.isna().any()
        assert imputed.iloc[2] == 3.0  # Mean of [1, 2, 4, 5]

    def test_impute_median(self):
        """Test median imputation."""
        series = pd.Series([1.0, 2.0, np.nan, 4.0, 5.0])
        imputed = utils.impute_median(series)
        assert not imputed.isna().any()
        assert imputed.iloc[2] == 3.0  # Median of [1, 2, 4, 5]

    def test_impute_mode(self):
        """Test mode imputation."""
        series = pd.Series([1, 2, 2, 3, 3, 3, np.nan])
        imputed = utils.impute_mode(series)
        assert not imputed.isna().any()
        assert imputed.iloc[-1] == 3  # Mode is 3

    def test_impute_mean_non_numeric(self):
        """Test mean imputation on non-numeric data."""
        series = pd.Series(["a", "b", None])
        imputed = utils.impute_mean(series)
        assert imputed.isna().sum() == 1  # No change for non-numeric


class TestMissingPercentage:
    """Tests for missing value percentage calculation."""

    def test_get_missing_percentage(self):
        """Test calculating missing value percentage."""
        series = pd.Series([1, 2, np.nan, 4, np.nan])
        pct = utils.get_missing_percentage(series)
        assert pct == 0.4  # 2/5 are missing

    def test_get_missing_percentage_no_missing(self):
        """Test with no missing values."""
        series = pd.Series([1, 2, 3, 4, 5])
        pct = utils.get_missing_percentage(series)
        assert pct == 0.0

    def test_get_missing_percentage_all_missing(self):
        """Test with all missing values."""
        series = pd.Series([np.nan, np.nan, np.nan])
        pct = utils.get_missing_percentage(series)
        assert pct == 1.0

    def test_get_missing_percentage_empty(self):
        """Test with empty series."""
        series = pd.Series([], dtype=float)
        pct = utils.get_missing_percentage(series)
        assert pct == 0.0


class TestNumericTypeDetection:
    """Tests for numeric type detection."""

    def test_detect_int_type(self):
        """Test detecting integer type."""
        series = pd.Series([1, 2, 3, 4, 5])
        dtype = utils.detect_numeric_type(series)
        assert dtype == "int"

    def test_detect_float_type(self):
        """Test detecting float type."""
        series = pd.Series([1.5, 2.5, 3.5])
        dtype = utils.detect_numeric_type(series)
        assert dtype == "float"

    def test_detect_float_with_whole_numbers(self):
        """Test that series with .0 values is still detected as float."""
        series = pd.Series([1.0, 2.0, 3.0])
        dtype = utils.detect_numeric_type(series)
        assert dtype == "int" or dtype == "float"

    def test_detect_non_numeric(self):
        """Test detecting non-numeric series."""
        series = pd.Series(["a", "b", "c"])
        dtype = utils.detect_numeric_type(series)
        assert dtype == "float"  # Default to float for non-numeric


class TestPatternValidation:
    """Tests for custom pattern validation."""

    def test_validate_pattern_valid(self):
        """Test validating values matching pattern."""
        assert utils.validate_pattern("123-45-6789", r"\d{3}-\d{2}-\d{4}")

    def test_validate_pattern_invalid(self):
        """Test validating values not matching pattern."""
        assert not utils.validate_pattern("123-4-6789", r"\d{3}-\d{2}-\d{4}")

    def test_validate_pattern_non_string(self):
        """Test pattern validation on non-string values."""
        assert not utils.validate_pattern(123, r"\d+")

    def test_validate_pattern_invalid_regex(self):
        """Test pattern validation with invalid regex."""
        assert not utils.validate_pattern("test", r"[invalid(")
