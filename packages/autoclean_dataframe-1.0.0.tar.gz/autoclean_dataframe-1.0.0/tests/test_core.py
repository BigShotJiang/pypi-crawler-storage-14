"""Tests for core cleaning pipeline."""

import pytest
import pandas as pd
import numpy as np

from autoclean_dataframe import (
    clean_dataframe,
    auto_clean,
    DataCleanConfig,
    GeneralCleanConfig,
    ColumnConfig,
    TypeConversionConfig,
    MissingValueConfig,
    OutlierConfig,
    PiiConfig,
    ImputationMethod,
    OutlierMethod,
    OutlierAction,
    PiiType,
)


class TestAutoClean:
    """Tests for auto_clean convenience function."""

    def test_auto_clean_removes_duplicates(self, sample_df):
        """Test that auto_clean removes duplicate rows."""
        df_clean, report = auto_clean(sample_df)
        # Original has 6 rows, 2 are duplicates
        assert len(df_clean) < len(sample_df)
        assert report.duplicate_rows_removed > 0

    def test_auto_clean_returns_report(self, sample_df):
        """Test that auto_clean returns a CleanReport."""
        df_clean, report = auto_clean(sample_df)
        assert report.rows_before == len(sample_df)
        assert report.rows_after == len(df_clean)

    def test_auto_clean_empty_dataframe(self, empty_df):
        """Test auto_clean with empty DataFrame."""
        df_clean, report = auto_clean(empty_df)
        assert len(df_clean) == 0
        assert report.rows_before == 0


class TestGeneralCleaning:
    """Tests for general cleaning operations."""

    def test_drop_fully_empty_rows(self):
        """Test dropping rows where all values are NaN."""
        df = pd.DataFrame({
            "a": [1, np.nan, 3],
            "b": [4, np.nan, 6],
            "c": [7, np.nan, 9],
        })
        config = DataCleanConfig(
            general=GeneralCleanConfig(drop_fully_empty_rows=True)
        )
        df_clean, report = clean_dataframe(df, config)
        assert len(df_clean) == 2
        assert report.rows_removed == 1

    def test_drop_fully_empty_columns(self):
        """Test dropping columns where all values are NaN."""
        df = pd.DataFrame({
            "a": [1, 2, 3],
            "b": [np.nan, np.nan, np.nan],
            "c": [7, 8, 9],
        })
        config = DataCleanConfig(
            general=GeneralCleanConfig(drop_fully_empty_columns=True)
        )
        df_clean, report = clean_dataframe(df, config)
        assert len(df_clean.columns) == 2
        assert "b" not in df_clean.columns
        assert report.empty_columns_removed == 1

    def test_remove_duplicates(self):
        """Test removing duplicate rows."""
        df = pd.DataFrame({
            "id": [1, 2, 1, 2],
            "value": ["a", "b", "a", "b"],
        })
        config = DataCleanConfig(
            general=GeneralCleanConfig(remove_duplicates=True)
        )
        df_clean, report = clean_dataframe(df, config)
        assert len(df_clean) == 2
        assert report.duplicate_rows_removed == 2

    def test_no_modifications_when_not_configured(self, sample_df):
        """Test that no modifications occur when general config is empty."""
        config = DataCleanConfig(general=GeneralCleanConfig())
        df_clean, report = clean_dataframe(sample_df, config)
        # DataFrame should be unchanged except for index
        assert len(df_clean) == len(sample_df)


class TestTextNormalization:
    """Tests for text normalization operations."""

    def test_strip_whitespace(self):
        """Test stripping whitespace from strings."""
        df = pd.DataFrame({
            "text": ["  hello  ", "  world  ", None],
        })
        config = DataCleanConfig(
            columns={
                "text": ColumnConfig(
                    column_name="text",
                    strip_whitespace=True,
                )
            }
        )
        df_clean, report = clean_dataframe(df, config)
        assert df_clean["text"].iloc[0] == "hello"
        assert df_clean["text"].iloc[1] == "world"
        assert pd.isna(df_clean["text"].iloc[2])

    def test_lowercase_conversion(self):
        """Test converting text to lowercase."""
        df = pd.DataFrame({
            "text": ["HELLO", "World", None],
        })
        config = DataCleanConfig(
            columns={
                "text": ColumnConfig(
                    column_name="text",
                    to_lowercase=True,
                )
            }
        )
        df_clean, report = clean_dataframe(df, config)
        assert df_clean["text"].iloc[0] == "hello"
        assert df_clean["text"].iloc[1] == "world"

    def test_uppercase_conversion(self):
        """Test converting text to uppercase."""
        df = pd.DataFrame({
            "text": ["hello", "World"],
        })
        config = DataCleanConfig(
            columns={
                "text": ColumnConfig(
                    column_name="text",
                    to_uppercase=True,
                )
            }
        )
        df_clean, report = clean_dataframe(df, config)
        assert df_clean["text"].iloc[0] == "HELLO"
        assert df_clean["text"].iloc[1] == "WORLD"


class TestTypeConversion:
    """Tests for type conversion operations."""

    def test_convert_to_int(self):
        """Test converting to integer type."""
        df = pd.DataFrame({
            "values": ["1", "2", "3", "invalid"],
        })
        config = DataCleanConfig(
            columns={
                "values": ColumnConfig(
                    column_name="values",
                    type_conversion=TypeConversionConfig(target_type="int"),
                )
            }
        )
        df_clean, report = clean_dataframe(df, config)
        assert pd.api.types.is_integer_dtype(df_clean["values"].dtype) or pd.api.types.is_float_dtype(df_clean["values"].dtype)
        assert df_clean["values"].iloc[0] == 1
        assert pd.isna(df_clean["values"].iloc[3])  # Invalid coerced to NaN

    def test_convert_to_float(self):
        """Test converting to float type."""
        df = pd.DataFrame({
            "values": ["1.5", "2.5", "3.5"],
        })
        config = DataCleanConfig(
            columns={
                "values": ColumnConfig(
                    column_name="values",
                    type_conversion=TypeConversionConfig(target_type="float"),
                )
            }
        )
        df_clean, report = clean_dataframe(df, config)
        assert pd.api.types.is_float_dtype(df_clean["values"].dtype)
        assert df_clean["values"].iloc[0] == 1.5

    def test_convert_to_datetime(self):
        """Test converting to datetime type."""
        df = pd.DataFrame({
            "dates": ["2020-01-15", "2021-06-20", "invalid"],
        })
        config = DataCleanConfig(
            columns={
                "dates": ColumnConfig(
                    column_name="dates",
                    type_conversion=TypeConversionConfig(
                        target_type="datetime",
                        datetime_format="%Y-%m-%d",
                    ),
                )
            }
        )
        df_clean, report = clean_dataframe(df, config)
        assert pd.api.types.is_datetime64_any_dtype(df_clean["dates"].dtype)
        assert pd.isna(df_clean["dates"].iloc[2])

    def test_convert_to_bool(self):
        """Test converting to boolean type."""
        df = pd.DataFrame({
            "flags": ["yes", "no", "true", "false", "1", "0"],
        })
        config = DataCleanConfig(
            columns={
                "flags": ColumnConfig(
                    column_name="flags",
                    type_conversion=TypeConversionConfig(target_type="bool"),
                )
            }
        )
        df_clean, report = clean_dataframe(df, config)
        assert df_clean["flags"].iloc[0] == True
        assert df_clean["flags"].iloc[1] == False


class TestMissingValueHandling:
    """Tests for missing value imputation."""

    def test_impute_with_mean(self):
        """Test imputing missing numeric values with mean."""
        df = pd.DataFrame({
            "values": [1.0, 2.0, np.nan, 4.0, 5.0],
        })
        config = DataCleanConfig(
            columns={
                "values": ColumnConfig(
                    column_name="values",
                    missing_values=MissingValueConfig(
                        strategy=ImputationMethod.MEAN
                    ),
                )
            }
        )
        df_clean, report = clean_dataframe(df, config)
        assert not df_clean["values"].isna().any()
        assert df_clean["values"].iloc[2] == 3.0  # Mean of [1, 2, 4, 5]

    def test_impute_with_median(self):
        """Test imputing missing numeric values with median."""
        df = pd.DataFrame({
            "values": [1.0, 2.0, np.nan, 4.0, 5.0],
        })
        config = DataCleanConfig(
            columns={
                "values": ColumnConfig(
                    column_name="values",
                    missing_values=MissingValueConfig(
                        strategy=ImputationMethod.MEDIAN
                    ),
                )
            }
        )
        df_clean, report = clean_dataframe(df, config)
        assert not df_clean["values"].isna().any()
        assert df_clean["values"].iloc[2] == 3.0  # Median of [1, 2, 4, 5]

    def test_impute_with_constant(self):
        """Test imputing missing values with constant."""
        df = pd.DataFrame({
            "values": [1, 2, None, 4, 5],
        })
        config = DataCleanConfig(
            columns={
                "values": ColumnConfig(
                    column_name="values",
                    missing_values=MissingValueConfig(
                        strategy=ImputationMethod.CONSTANT,
                        constant_value=0,
                    ),
                )
            }
        )
        df_clean, report = clean_dataframe(df, config)
        assert not df_clean["values"].isna().any()
        assert df_clean["values"].iloc[2] == 0


class TestOutlierDetection:
    """Tests for outlier detection and handling."""

    def test_detect_outliers_iqr(self, numeric_df):
        """Test IQR-based outlier detection."""
        config = DataCleanConfig(
            columns={
                "values": ColumnConfig(
                    column_name="values",
                    outliers=OutlierConfig(
                        method=OutlierMethod.IQR,
                        action=OutlierAction.FLAG,
                        iqr_multiplier=1.5,
                    ),
                )
            }
        )
        df_clean, report = clean_dataframe(numeric_df, config)
        # Should flag 100 and 200 as outliers
        assert "values_is_outlier" in df_clean.columns
        assert df_clean["values_is_outlier"].sum() > 0

    def test_detect_outliers_zscore(self):
        """Test Z-score-based outlier detection."""
        df = pd.DataFrame({
            "values": [1, 2, 3, 4, 5, 100],  # 100 is outlier
        })
        config = DataCleanConfig(
            columns={
                "values": ColumnConfig(
                    column_name="values",
                    outliers=OutlierConfig(
                        method=OutlierMethod.ZSCORE,
                        action=OutlierAction.FLAG,
                        zscore_threshold=3.0,
                    ),
                )
            }
        )
        df_clean, report = clean_dataframe(df, config)
        assert "values_is_outlier" in df_clean.columns

    def test_remove_outliers(self, numeric_df):
        """Test removing outliers."""
        config = DataCleanConfig(
            columns={
                "values": ColumnConfig(
                    column_name="values",
                    outliers=OutlierConfig(
                        method=OutlierMethod.IQR,
                        action=OutlierAction.REMOVE,
                    ),
                )
            }
        )
        df_clean, report = clean_dataframe(numeric_df, config)
        assert len(df_clean) < len(numeric_df)

    def test_clip_outliers(self, numeric_df):
        """Test clipping outliers to bounds."""
        config = DataCleanConfig(
            columns={
                "values": ColumnConfig(
                    column_name="values",
                    outliers=OutlierConfig(
                        method=OutlierMethod.IQR,
                        action=OutlierAction.CLIP,
                    ),
                )
            }
        )
        df_clean, report = clean_dataframe(numeric_df, config)
        # DataFrame should have same shape
        assert len(df_clean) == len(numeric_df)
        # Outlier values should be clipped
        assert df_clean["values"].max() < 200


class TestPiiMasking:
    """Tests for PII masking operations."""

    def test_mask_email(self):
        """Test masking email addresses."""
        df = pd.DataFrame({
            "email": ["john@example.com", "jane@test.org", None],
        })
        config = DataCleanConfig(
            columns={
                "email": ColumnConfig(
                    column_name="email",
                    pii=PiiConfig(pii_type=PiiType.EMAIL),
                )
            }
        )
        df_clean, report = clean_dataframe(df, config)
        assert df_clean["email"].iloc[0] == "***@***.com"
        assert df_clean["email"].iloc[1] == "***@***.org"

    def test_mask_phone(self):
        """Test masking phone numbers."""
        df = pd.DataFrame({
            "phone": ["555-123-4567", "666-789-0123"],
        })
        config = DataCleanConfig(
            columns={
                "phone": ColumnConfig(
                    column_name="phone",
                    pii=PiiConfig(pii_type=PiiType.PHONE),
                )
            }
        )
        df_clean, report = clean_dataframe(df, config)
        assert "4567" in df_clean["phone"].iloc[0]
        assert "0123" in df_clean["phone"].iloc[1]


class TestReporting:
    """Tests for cleaning report generation."""

    def test_report_contains_row_counts(self, sample_df):
        """Test that report contains row before/after counts."""
        config = DataCleanConfig(
            general=GeneralCleanConfig(remove_duplicates=True)
        )
        df_clean, report = clean_dataframe(sample_df, config)
        assert report.rows_before == len(sample_df)
        assert report.rows_after == len(df_clean)

    def test_report_contains_column_changes(self, sample_df):
        """Test that report tracks column changes."""
        config = DataCleanConfig(
            columns={
                "name": ColumnConfig(
                    column_name="name",
                    strip_whitespace=True,
                )
            }
        )
        df_clean, report = clean_dataframe(sample_df, config)
        assert "name" in report.column_changes

    def test_report_to_dict(self, sample_df):
        """Test converting report to dictionary."""
        config = DataCleanConfig()
        df_clean, report = clean_dataframe(sample_df, config)
        report_dict = report.to_dict()
        assert "rows_before" in report_dict
        assert "rows_after" in report_dict

    def test_report_to_json(self, sample_df):
        """Test converting report to JSON."""
        config = DataCleanConfig()
        df_clean, report = clean_dataframe(sample_df, config)
        json_str = report.to_json()
        assert isinstance(json_str, str)
        assert "rows_before" in json_str

    def test_report_summary(self, sample_df):
        """Test generating human-readable report summary."""
        config = DataCleanConfig()
        df_clean, report = clean_dataframe(sample_df, config)
        summary = str(report)
        assert "DATA CLEANING REPORT" in summary


class TestMultipleOperations:
    """Tests combining multiple cleaning operations."""

    def test_combined_cleaning(self):
        """Test applying multiple cleaning operations together."""
        df = pd.DataFrame({
            "id": [1, 2, 2],  # Duplicate
            "name": ["  JOHN  ", "  JANE  ", "  JANE  "],  # Whitespace
            "age": ["25", "30", "30"],  # String numbers
        })
        config = DataCleanConfig(
            general=GeneralCleanConfig(remove_duplicates=True),
            columns={
                "name": ColumnConfig(
                    column_name="name",
                    strip_whitespace=True,
                    to_lowercase=True,
                ),
                "age": ColumnConfig(
                    column_name="age",
                    type_conversion=TypeConversionConfig(target_type="int"),
                ),
            }
        )
        df_clean, report = clean_dataframe(df, config)
        assert len(df_clean) == 2  # Duplicates removed
        assert df_clean["name"].iloc[0] == "john"  # Whitespace stripped and lowercased
        assert isinstance(df_clean["age"].iloc[0], (int, np.integer))
