"""Tests for configuration models."""

import pytest
from pydantic import ValidationError

from autoclean_dataframe import (
    DataCleanConfig,
    GeneralCleanConfig,
    ColumnConfig,
    TypeConversionConfig,
    MissingValueConfig,
    OutlierConfig,
    PiiConfig,
    ImputationMethod,
    ConfigValidationError,
)


class TestGeneralCleanConfig:
    """Tests for GeneralCleanConfig model."""

    def test_default_values(self):
        """Test default configuration values."""
        config = GeneralCleanConfig()
        assert config.drop_fully_empty_rows is False
        assert config.drop_fully_empty_columns is False
        assert config.remove_duplicates is False
        assert config.normalize_unicode is False

    def test_custom_values(self):
        """Test setting custom values."""
        config = GeneralCleanConfig(
            drop_fully_empty_rows=True,
            remove_duplicates=True,
        )
        assert config.drop_fully_empty_rows is True
        assert config.remove_duplicates is True


class TestMissingValueConfig:
    """Tests for MissingValueConfig model."""

    def test_default_strategy(self):
        """Test default missing value strategy."""
        config = MissingValueConfig()
        assert config.strategy == ImputationMethod.NONE

    def test_constant_strategy_requires_value(self):
        """Test that CONSTANT strategy requires constant_value."""
        with pytest.raises(ValidationError):
            MissingValueConfig(strategy=ImputationMethod.CONSTANT)

    def test_constant_strategy_with_value(self):
        """Test CONSTANT strategy with value provided."""
        config = MissingValueConfig(
            strategy=ImputationMethod.CONSTANT,
            constant_value=0,
        )
        assert config.strategy == ImputationMethod.CONSTANT
        assert config.constant_value == 0

    def test_threshold_bounds(self):
        """Test threshold parameter bounds."""
        # Valid
        config = MissingValueConfig(threshold=0.5)
        assert config.threshold == 0.5

        # Invalid - too high
        with pytest.raises(ValidationError):
            MissingValueConfig(threshold=1.5)

        # Invalid - negative
        with pytest.raises(ValidationError):
            MissingValueConfig(threshold=-0.1)


class TestTypeConversionConfig:
    """Tests for TypeConversionConfig model."""

    def test_default_values(self):
        """Test default type conversion config."""
        config = TypeConversionConfig()
        assert config.target_type == "none"
        assert config.strict is False
        assert config.infer_type is False

    def test_datetime_format(self):
        """Test datetime format specification."""
        config = TypeConversionConfig(
            target_type="datetime",
            datetime_format="%Y-%m-%d",
        )
        assert config.datetime_format == "%Y-%m-%d"

    def test_valid_target_types(self):
        """Test all valid target types."""
        for target_type in ["int", "float", "str", "bool", "datetime", "category", "none"]:
            config = TypeConversionConfig(target_type=target_type)
            assert config.target_type == target_type


class TestOutlierConfig:
    """Tests for OutlierConfig model."""

    def test_default_values(self):
        """Test default outlier config."""
        config = OutlierConfig()
        assert config.method.value == "none"
        assert config.action.value == "none"

    def test_zscore_threshold(self):
        """Test Z-score threshold validation."""
        config = OutlierConfig(zscore_threshold=2.5)
        assert config.zscore_threshold == 2.5

        # Must be > 0
        with pytest.raises(ValidationError):
            OutlierConfig(zscore_threshold=0)

    def test_iqr_multiplier(self):
        """Test IQR multiplier validation."""
        config = OutlierConfig(iqr_multiplier=2.0)
        assert config.iqr_multiplier == 2.0

        # Must be > 0
        with pytest.raises(ValidationError):
            OutlierConfig(iqr_multiplier=0)


class TestPiiConfig:
    """Tests for PiiConfig model."""

    def test_default_values(self):
        """Test default PII config."""
        config = PiiConfig()
        assert config.pii_type.value == "none"
        assert config.mask_char == "*"

    def test_email_pii_type(self):
        """Test email PII type."""
        config = PiiConfig(pii_type="email")
        assert config.pii_type.value == "email"

    def test_custom_pattern(self):
        """Test custom regex pattern."""
        config = PiiConfig(
            pii_type="custom",
            custom_pattern=r"\d{3}-\d{2}-\d{4}",
        )
        assert config.custom_pattern == r"\d{3}-\d{2}-\d{4}"

    def test_mask_char_length(self):
        """Test mask character validation."""
        config = PiiConfig(mask_char="#")
        assert config.mask_char == "#"

        # Must be single character
        with pytest.raises(ValidationError):
            PiiConfig(mask_char="***")


class TestColumnConfig:
    """Tests for ColumnConfig model."""

    def test_basic_column_config(self):
        """Test basic column configuration."""
        config = ColumnConfig(column_name="age")
        assert config.column_name == "age"
        assert config.strip_whitespace is False

    def test_mutually_exclusive_case_conversion(self):
        """Test that lowercase and uppercase are mutually exclusive."""
        with pytest.raises(ValidationError):
            ColumnConfig(
                column_name="text",
                to_lowercase=True,
                to_uppercase=True,
            )

    def test_column_with_type_conversion(self):
        """Test column config with type conversion."""
        config = ColumnConfig(
            column_name="age",
            type_conversion=TypeConversionConfig(target_type="int"),
        )
        assert config.type_conversion.target_type == "int"

    def test_column_with_missing_values(self):
        """Test column config with missing value strategy."""
        config = ColumnConfig(
            column_name="salary",
            missing_values=MissingValueConfig(
                strategy=ImputationMethod.MEAN
            ),
        )
        assert config.missing_values.strategy == ImputationMethod.MEAN

    def test_allowed_values(self):
        """Test allowed values specification."""
        config = ColumnConfig(
            column_name="status",
            allowed_values=["active", "inactive", "pending"],
        )
        assert "active" in config.allowed_values


class TestDataCleanConfig:
    """Tests for main DataCleanConfig model."""

    def test_empty_config(self):
        """Test minimal config."""
        config = DataCleanConfig()
        assert isinstance(config.general, GeneralCleanConfig)
        assert config.columns == {}

    def test_config_with_columns(self):
        """Test config with column configurations."""
        config = DataCleanConfig(
            columns={
                "age": ColumnConfig(column_name="age"),
                "name": ColumnConfig(column_name="name"),
            }
        )
        assert "age" in config.columns
        assert "name" in config.columns

    def test_config_with_general_settings(self):
        """Test config with general settings."""
        config = DataCleanConfig(
            general=GeneralCleanConfig(remove_duplicates=True),
        )
        assert config.general.remove_duplicates is True

    def test_preserve_index(self):
        """Test preserve_index setting."""
        config = DataCleanConfig(preserve_index=False)
        assert config.preserve_index is False

    def test_verbose_mode(self):
        """Test verbose mode setting."""
        config = DataCleanConfig(verbose=True)
        assert config.verbose is True

    def test_complex_config(self):
        """Test complex configuration with multiple settings."""
        config = DataCleanConfig(
            general=GeneralCleanConfig(
                drop_fully_empty_rows=True,
                remove_duplicates=True,
            ),
            columns={
                "age": ColumnConfig(
                    column_name="age",
                    type_conversion=TypeConversionConfig(target_type="int"),
                    missing_values=MissingValueConfig(
                        strategy=ImputationMethod.MEAN
                    ),
                    outliers=OutlierConfig(method="iqr"),
                ),
                "email": ColumnConfig(
                    column_name="email",
                    pii=PiiConfig(pii_type="email"),
                ),
            },
            verbose=True,
        )
        assert len(config.columns) == 2
        assert config.general.remove_duplicates is True


class TestConfigValidation:
    """Tests for configuration validation."""

    def test_valid_config_from_dict(self):
        """Test creating config from dictionary."""
        config_dict = {
            "general": {"remove_duplicates": True},
            "columns": {
                "age": {
                    "column_name": "age",
                    "type_conversion": {"target_type": "int"},
                }
            },
        }
        config = DataCleanConfig(**config_dict)
        assert config.general.remove_duplicates is True
        assert "age" in config.columns

    def test_invalid_config_from_dict(self):
        """Test that invalid dict raises error."""
        config_dict = {
            "general": {"invalid_field": True},
        }
        with pytest.raises(ValidationError):
            DataCleanConfig(**config_dict)

    def test_config_model_dump(self):
        """Test serializing config to dict."""
        config = DataCleanConfig(
            general=GeneralCleanConfig(remove_duplicates=True),
        )
        dumped = config.model_dump()
        assert "general" in dumped
        assert dumped["general"]["remove_duplicates"] is True

    def test_config_model_dump_json(self):
        """Test serializing config to JSON."""
        config = DataCleanConfig(
            general=GeneralCleanConfig(remove_duplicates=True),
        )
        json_str = config.model_dump_json()
        assert isinstance(json_str, str)
        assert "remove_duplicates" in json_str
