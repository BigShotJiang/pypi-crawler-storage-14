"""Configuration models for data cleaning pipeline."""

from typing import Any, Literal, Optional, Dict, List

from pydantic import BaseModel, Field, field_validator, model_validator, ConfigDict

from .types import (
    ImputationMethod,
    OutlierMethod,
    OutlierAction,
    PiiType,
    CleanerProtocol,
)


# ============================================================================
# MISSING VALUE CONFIGURATION
# ============================================================================


class MissingValueConfig(BaseModel):
    """Configuration for handling missing values."""

    strategy: ImputationMethod = Field(
        default=ImputationMethod.NONE,
        description="Strategy for handling missing values",
    )
    constant_value: Optional[Any] = Field(
        default=None,
        description="Constant value to fill when strategy=CONSTANT",
    )
    threshold: float = Field(
        default=0.5,
        ge=0,
        le=1,
        description="Drop column if missing % exceeds threshold",
    )

    @model_validator(mode="after")
    def validate_strategy_and_constant(self):
        """Ensure CONSTANT strategy has constant_value."""
        if self.strategy == ImputationMethod.CONSTANT and self.constant_value is None:
            raise ValueError("constant_value required when strategy=CONSTANT")
        return self


# ============================================================================
# TYPE CONVERSION CONFIGURATION
# ============================================================================


class TypeConversionConfig(BaseModel):
    """Configuration for type conversion."""

    target_type: Literal[
        "int", "float", "str", "bool", "datetime", "category", "none"
    ] = Field(default="none", description="Target type to convert to")
    datetime_format: Optional[str] = Field(
        default=None,
        description="Format string for datetime parsing (e.g., '%Y-%m-%d')",
    )
    strict: bool = Field(
        default=False,
        description="If True, raise error on conversion failure; if False, coerce to NaN/NaT",
    )
    infer_type: bool = Field(
        default=False,
        description="Auto-detect and convert to appropriate type",
    )


# ============================================================================
# OUTLIER DETECTION & HANDLING CONFIGURATION
# ============================================================================


class OutlierConfig(BaseModel):
    """Configuration for outlier detection and handling."""

    method: OutlierMethod = Field(
        default=OutlierMethod.NONE,
        description="Outlier detection method",
    )
    action: OutlierAction = Field(
        default=OutlierAction.NONE,
        description="Action to take on detected outliers",
    )
    zscore_threshold: float = Field(
        default=3.0,
        gt=0,
        description="Z-score threshold for outlier detection",
    )
    iqr_multiplier: float = Field(
        default=1.5,
        gt=0,
        description="IQR multiplier for outlier bounds (Q1 - k*IQR, Q3 + k*IQR)",
    )


# ============================================================================
# PII MASKING CONFIGURATION
# ============================================================================


class PiiConfig(BaseModel):
    """Configuration for PII masking."""

    pii_type: PiiType = Field(
        default=PiiType.NONE,
        description="Type of PII to detect and mask",
    )
    custom_pattern: Optional[str] = Field(
        default=None,
        description="Custom regex pattern for PII detection",
    )
    mask_char: str = Field(
        default="*",
        min_length=1,
        max_length=1,
        description="Character to use for masking",
    )


# ============================================================================
# COLUMN-LEVEL CONFIGURATION
# ============================================================================


class ColumnConfig(BaseModel):
    """Configuration for individual column cleaning."""

    column_name: str = Field(description="Column name to apply config to")
    strip_whitespace: bool = Field(
        default=False,
        description="Strip leading/trailing whitespace",
    )
    to_lowercase: bool = Field(
        default=False,
        description="Convert text to lowercase",
    )
    to_uppercase: bool = Field(
        default=False,
        description="Convert text to uppercase",
    )
    type_conversion: Optional[TypeConversionConfig] = Field(
        default=None,
        description="Type conversion configuration",
    )
    missing_values: Optional[MissingValueConfig] = Field(
        default=None,
        description="Missing value handling configuration",
    )
    outliers: Optional[OutlierConfig] = Field(
        default=None,
        description="Outlier handling configuration",
    )
    pii: Optional[PiiConfig] = Field(
        default=None,
        description="PII masking configuration",
    )
    allowed_values: Optional[List[Any]] = Field(
        default=None,
        description="List of allowed values; others flagged as invalid",
    )

    @model_validator(mode="after")
    def validate_case_exclusive(self):
        """Ensure both lowercase and uppercase aren't set."""
        if self.to_lowercase and self.to_uppercase:
            raise ValueError("Cannot set both to_lowercase and to_uppercase")
        return self


# ============================================================================
# GLOBAL CONFIGURATION
# ============================================================================


class GeneralCleanConfig(BaseModel):
    """General cleaning configuration applied to all columns."""

    model_config = ConfigDict(extra="forbid")

    drop_fully_empty_rows: bool = Field(
        default=False,
        description="Drop rows where all values are NaN/None",
    )
    drop_fully_empty_columns: bool = Field(
        default=False,
        description="Drop columns where all values are NaN/None",
    )
    remove_duplicates: bool = Field(
        default=False,
        description="Remove duplicate rows (keep first occurrence)",
    )
    normalize_unicode: bool = Field(
        default=False,
        description="Normalize unicode to NFC form",
    )
    infer_dtypes: bool = Field(
        default=False,
        description="Auto-detect and convert column types",
    )


# ============================================================================
# CUSTOM CLEANER DEFINITION
# ============================================================================


class CustomCleanerDef(BaseModel):
    """Definition of a custom cleaner function."""

    name: str = Field(description="Unique name for this cleaner")
    columns: Optional[List[str]] = Field(
        default=None,
        description="Columns to apply cleaner to",
    )
    order: int = Field(
        default=100,
        description="Execution order (lower = earlier)",
    )

    class Config:
        arbitrary_types_allowed = True


# ============================================================================
# MAIN CONFIGURATION
# ============================================================================


class DataCleanConfig(BaseModel):
    """Main configuration for data cleaning pipeline."""

    model_config = ConfigDict(extra="forbid", arbitrary_types_allowed=True)

    general: GeneralCleanConfig = Field(
        default_factory=GeneralCleanConfig,
        description="General cleaning settings",
    )
    columns: Dict[str, ColumnConfig] = Field(
        default_factory=dict,
        description="Per-column cleaning configuration",
    )
    preserve_index: bool = Field(
        default=True,
        description="Preserve DataFrame index through cleaning",
    )
    verbose: bool = Field(
        default=False,
        description="Enable verbose logging during cleaning",
    )

    @field_validator("columns")
    @classmethod
    def validate_columns(cls, v: Dict[str, ColumnConfig]) -> Dict[str, ColumnConfig]:
        """Validate column configurations."""
        if not isinstance(v, dict):
            raise ValueError("columns must be a dictionary")
        return v
