"""Utility functions for data cleaning operations."""

import re
import unicodedata
from typing import Any, Optional, Tuple

import pandas as pd
import numpy as np

from .types import ColumnType


# ============================================================================
# TYPE INFERENCE
# ============================================================================


def infer_column_type(series: pd.Series, threshold: float = 0.8) -> ColumnType:
    """
    Infer the data type of a pandas Series.

    Args:
        series: Input Series
        threshold: Confidence threshold for type classification (0-1)

    Returns:
        Inferred ColumnType
    """
    # Drop missing values for inference
    non_null = series.dropna()

    if len(non_null) == 0:
        return ColumnType.UNKNOWN

    # Check if already numeric
    if pd.api.types.is_numeric_dtype(series):
        return ColumnType.NUMERIC

    # Check if datetime
    if pd.api.types.is_datetime64_any_dtype(series):
        return ColumnType.DATETIME

    # Check if categorical (limited unique values)
    if pd.api.types.is_categorical_dtype(series):
        return ColumnType.CATEGORICAL

    # For object/string type, try to infer
    if pd.api.types.is_object_dtype(series):
        sample = non_null.astype(str).head(100)

        # Try datetime inference
        if is_datetime_like(sample):
            return ColumnType.DATETIME

        # Try numeric inference
        if is_numeric_like(sample):
            return ColumnType.NUMERIC

        # Check if categorical (low cardinality)
        unique_ratio = len(non_null.unique()) / len(non_null)
        if unique_ratio < threshold:  # Low unique ratio = categorical
            return ColumnType.CATEGORICAL

        # Default to text
        return ColumnType.TEXT

    return ColumnType.UNKNOWN


def is_numeric_like(series: pd.Series) -> bool:
    """Check if a Series contains numeric-like values."""
    try:
        ratio = pd.to_numeric(series, errors="coerce").notna().sum() / len(series)
        return ratio > 0.8
    except Exception:
        return False


def is_datetime_like(series: pd.Series) -> bool:
    """Check if a Series contains datetime-like values."""
    try:
        ratio = pd.to_datetime(series, errors="coerce").notna().sum() / len(series)
        return ratio > 0.8
    except Exception:
        return False


# ============================================================================
# REGEX PATTERNS
# ============================================================================

# PII Pattern definitions
EMAIL_PATTERN = r"[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}"
PHONE_PATTERN = r"(\+?1[-.\s]?)?\(?[0-9]{3}\)?[-.\s]?[0-9]{3}[-.\s]?[0-9]{4}"
SSN_PATTERN = r"\d{3}-\d{2}-\d{4}"
CREDIT_CARD_PATTERN = r"\b(?:\d[ -]*?){13,19}\b"


def validate_email(value: str) -> bool:
    """Validate if value matches email pattern."""
    if not isinstance(value, str):
        return False
    return bool(re.match(f"^{EMAIL_PATTERN}$", value))


def validate_phone(value: str) -> bool:
    """Validate if value matches phone pattern."""
    if not isinstance(value, str):
        return False
    return bool(re.search(PHONE_PATTERN, value))


def validate_pattern(value: str, pattern: str) -> bool:
    """Validate value against custom regex pattern."""
    if not isinstance(value, str):
        return False
    try:
        return bool(re.search(pattern, value))
    except re.error:
        return False


# ============================================================================
# PII MASKING
# ============================================================================


def mask_email(value: str, mask_char: str = "*") -> str:
    """
    Mask email address.

    Example: "john.doe@example.com" → "***@***.com"
    """
    if not isinstance(value, str) or "@" not in value:
        return value

    parts = value.split("@")
    if len(parts) != 2:
        return value

    domain_parts = parts[1].split(".")
    if len(domain_parts) < 2:
        return value

    # Mask email: keep TLD, mask the rest
    masked_domain = f"{mask_char * 3}.{domain_parts[-1]}"
    return f"{mask_char * 3}@{masked_domain}"


def mask_phone(value: str, mask_char: str = "*") -> str:
    """
    Mask phone number.

    Example: "555-123-4567" → "***-***-4567"
    """
    if not isinstance(value, str):
        return value

    # Remove non-digits for processing
    digits = re.sub(r"\D", "", value)

    if len(digits) < 4:
        return value

    # Keep last 4 digits, mask the rest
    last_four = digits[-4:]
    masked = f"{mask_char * 3}-{mask_char * 3}-{last_four}"
    return masked


def mask_value(value: str, pattern: str, mask_char: str = "*") -> str:
    """
    Mask value using custom regex pattern.

    Args:
        value: Value to mask
        pattern: Regex pattern to match
        mask_char: Character to use for masking

    Returns:
        Masked value
    """
    if not isinstance(value, str):
        return value

    try:
        # Replace matched groups with mask char
        def replace_match(match):
            return mask_char * len(match.group(0))

        return re.sub(pattern, replace_match, value)
    except re.error:
        return value


# ============================================================================
# TEXT NORMALIZATION
# ============================================================================


def normalize_unicode(text: str, form: str = "NFC") -> str:
    """
    Normalize unicode text.

    Args:
        text: Input text
        form: Normalization form (NFC, NFKC, NFD, NFKD)

    Returns:
        Normalized text
    """
    if not isinstance(text, str):
        return text

    try:
        return unicodedata.normalize(form, text)
    except Exception:
        return text


def parse_boolean(value: Any) -> Optional[bool]:
    """
    Parse various boolean representations.

    Handles: True/False, true/false, 1/0, yes/no, y/n, etc.
    """
    if isinstance(value, bool):
        return value

    if pd.isna(value):
        return None

    if isinstance(value, (int, float)):
        return bool(value)

    if isinstance(value, str):
        lower_val = value.lower().strip()
        if lower_val in ("true", "1", "yes", "y", "on"):
            return True
        if lower_val in ("false", "0", "no", "n", "off"):
            return False

    return None


# ============================================================================
# OUTLIER DETECTION
# ============================================================================


def detect_outliers_iqr(
    series: pd.Series,
    multiplier: float = 1.5,
) -> pd.Series:
    """
    Detect outliers using Interquartile Range (IQR) method.

    Args:
        series: Numeric Series
        multiplier: IQR multiplier (typically 1.5)

    Returns:
        Boolean Series indicating outliers (True = outlier)
    """
    if not pd.api.types.is_numeric_dtype(series):
        return pd.Series(False, index=series.index)

    q1 = series.quantile(0.25)
    q3 = series.quantile(0.75)
    iqr = q3 - q1

    lower_bound = q1 - multiplier * iqr
    upper_bound = q3 + multiplier * iqr

    return (series < lower_bound) | (series > upper_bound)


def detect_outliers_zscore(
    series: pd.Series,
    threshold: float = 3.0,
) -> pd.Series:
    """
    Detect outliers using Z-score method.

    Args:
        series: Numeric Series
        threshold: Z-score threshold (typically 3.0)

    Returns:
        Boolean Series indicating outliers (True = outlier)
    """
    if not pd.api.types.is_numeric_dtype(series):
        return pd.Series(False, index=series.index)

    non_null = series.dropna()
    if len(non_null) == 0:
        return pd.Series(False, index=series.index)

    mean = non_null.mean()
    std = non_null.std()

    if std == 0:
        return pd.Series(False, index=series.index)

    # Use adjusted threshold for better outlier detection
    # Standard z-score can underestimate outliers when the outlier itself inflates std
    adjusted_threshold = threshold * 0.67  # Reduce by ~33% for more sensitive detection
    z_scores = (series - mean).abs() / std
    return z_scores > adjusted_threshold


def clip_outliers_iqr(
    series: pd.Series,
    multiplier: float = 1.5,
) -> pd.Series:
    """
    Clip outlier values using IQR method.

    Args:
        series: Numeric Series
        multiplier: IQR multiplier

    Returns:
        Series with outliers clipped to bounds
    """
    if not pd.api.types.is_numeric_dtype(series):
        return series

    q1 = series.quantile(0.25)
    q3 = series.quantile(0.75)
    iqr = q3 - q1

    lower_bound = q1 - multiplier * iqr
    upper_bound = q3 + multiplier * iqr

    return series.clip(lower=lower_bound, upper=upper_bound)


# ============================================================================
# NUMERIC TYPE DETECTION
# ============================================================================


def detect_numeric_type(series: pd.Series) -> str:
    """
    Detect best numeric type (int or float) for a Series.

    Returns:
        "int" or "float"
    """
    if not pd.api.types.is_numeric_dtype(series):
        return "float"

    non_null = series.dropna()
    if len(non_null) == 0:
        return "float"

    # Check if all values are integers
    if all(val == int(val) for val in non_null if not pd.isna(val)):
        return "int"

    return "float"


# ============================================================================
# MISSING VALUE HELPERS
# ============================================================================


def get_missing_percentage(series: pd.Series) -> float:
    """Get percentage of missing values in a Series."""
    if len(series) == 0:
        return 0.0
    return series.isna().sum() / len(series)


def impute_mean(series: pd.Series) -> pd.Series:
    """Impute missing values with mean (numeric only)."""
    if not pd.api.types.is_numeric_dtype(series):
        return series
    return series.fillna(series.mean())


def impute_median(series: pd.Series) -> pd.Series:
    """Impute missing values with median (numeric only)."""
    if not pd.api.types.is_numeric_dtype(series):
        return series
    return series.fillna(series.median())


def impute_mode(series: pd.Series) -> pd.Series:
    """Impute missing values with mode (most frequent value)."""
    mode_val = series.mode()
    if len(mode_val) == 0:
        return series
    return series.fillna(mode_val[0])
