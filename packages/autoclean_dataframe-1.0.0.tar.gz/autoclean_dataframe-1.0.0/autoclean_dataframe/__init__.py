"""
autoclean-dataframe: Automatic, configurable data cleansing for pandas DataFrames.

A Python library for declarative data cleaning with detailed reporting.
"""

__version__ = "1.0.0"
__author__ = "autoclean-dataframe contributors"

# Configuration models
from .config import (
    DataCleanConfig,
    GeneralCleanConfig,
    ColumnConfig,
    TypeConversionConfig,
    MissingValueConfig,
    OutlierConfig,
    PiiConfig,
    CustomCleanerDef,
)

# Core functions
from .core import (
    CleaningPipeline,
    clean_dataframe,
    auto_clean,
)

# Reporting
from .report import (
    CleanReport,
    ColumnChange,
)

# I/O utilities
from .io import (
    load_config,
    save_config,
    save_report,
    load_config_dict,
    config_to_dict,
    config_to_yaml,
    config_to_json,
    report_to_dict,
)

# Types and enums
from .types import (
    ColumnType,
    ImputationMethod,
    OutlierMethod,
    OutlierAction,
    PiiType,
    AutocleanException,
    ConfigValidationError,
    DataValidationError,
    TypeConversionError,
    OutlierDetectionError,
    ReportExportError,
)

__all__ = [
    # Version
    "__version__",
    # Config models
    "DataCleanConfig",
    "GeneralCleanConfig",
    "ColumnConfig",
    "TypeConversionConfig",
    "MissingValueConfig",
    "OutlierConfig",
    "PiiConfig",
    "CustomCleanerDef",
    # Core functions
    "CleaningPipeline",
    "clean_dataframe",
    "auto_clean",
    # Reporting
    "CleanReport",
    "ColumnChange",
    # I/O
    "load_config",
    "save_config",
    "save_report",
    "load_config_dict",
    "config_to_dict",
    "config_to_yaml",
    "config_to_json",
    "report_to_dict",
    # Types and enums
    "ColumnType",
    "ImputationMethod",
    "OutlierMethod",
    "OutlierAction",
    "PiiType",
    "AutocleanException",
    "ConfigValidationError",
    "DataValidationError",
    "TypeConversionError",
    "OutlierDetectionError",
    "ReportExportError",
]
