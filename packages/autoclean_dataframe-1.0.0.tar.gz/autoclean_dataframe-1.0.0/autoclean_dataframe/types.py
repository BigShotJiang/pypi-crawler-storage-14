"""Custom types, enums, and exceptions for autoclean_dataframe."""

from enum import Enum
from typing import Any, Callable, Protocol, TypeVar

import pandas as pd


T = TypeVar("T")


# ============================================================================
# ENUMS
# ============================================================================


class ColumnType(str, Enum):
    """Inferred or specified column data types."""

    NUMERIC = "numeric"
    CATEGORICAL = "categorical"
    DATETIME = "datetime"
    TEXT = "text"
    UNKNOWN = "unknown"


class ImputationMethod(str, Enum):
    """Missing value imputation strategies."""

    MEAN = "mean"
    MEDIAN = "median"
    MODE = "mode"
    FORWARD_FILL = "forward_fill"
    BACKWARD_FILL = "backward_fill"
    CONSTANT = "constant"
    DROP_ROW = "drop_row"
    NONE = "none"


class OutlierMethod(str, Enum):
    """Outlier detection methods."""

    IQR = "iqr"
    ZSCORE = "zscore"
    NONE = "none"


class OutlierAction(str, Enum):
    """Actions to take on detected outliers."""

    REMOVE = "remove"
    CLIP = "clip"
    FLAG = "flag"
    NONE = "none"


class PiiType(str, Enum):
    """Types of Personally Identifiable Information."""

    EMAIL = "email"
    PHONE = "phone"
    SSN = "ssn"
    CREDIT_CARD = "credit_card"
    CUSTOM = "custom"
    NONE = "none"


# ============================================================================
# CUSTOM EXCEPTIONS
# ============================================================================


class AutocleanException(Exception):
    """Base exception for autoclean_dataframe."""

    pass


class ConfigValidationError(AutocleanException):
    """Raised when configuration validation fails."""

    pass


class DataValidationError(AutocleanException):
    """Raised when input data validation fails."""

    pass


class TypeConversionError(AutocleanException):
    """Raised when type conversion fails."""

    pass


class OutlierDetectionError(AutocleanException):
    """Raised when outlier detection fails."""

    pass


class ReportExportError(AutocleanException):
    """Raised when report serialization fails."""

    pass


# ============================================================================
# PROTOCOLS (duck typing interfaces)
# ============================================================================


class CleanerProtocol(Protocol):
    """Protocol for custom cleaner functions."""

    def __call__(self, df: pd.DataFrame, **kwargs: Any) -> pd.DataFrame:
        """
        Apply cleaning operation to DataFrame.

        Args:
            df: Input DataFrame
            **kwargs: Cleaner-specific configuration

        Returns:
            Cleaned DataFrame
        """
        ...


class ColumnTypeInferrer(Protocol):
    """Protocol for custom type inference."""

    def infer(self, series: pd.Series) -> ColumnType:
        """
        Infer data type of a pandas Series.

        Args:
            series: Input Series

        Returns:
            ColumnType enum value
        """
        ...


# ============================================================================
# TYPE ALIASES
# ============================================================================

ColumnDtype = Any  # Flexible type representation
CleanerFunction = Callable[[pd.DataFrame], pd.DataFrame]
PatternMask = str  # e.g. "***@***.com"
