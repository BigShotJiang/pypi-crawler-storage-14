"""Reporting infrastructure for tracking cleaning operations."""

from dataclasses import dataclass, field
from datetime import datetime
from typing import List, Dict, Any
import json


# ============================================================================
# OPERATION LOGGING
# ============================================================================


@dataclass
class ColumnChange:
    """Summary of changes to a single column."""

    column_name: str
    missing_values_handled: int = 0
    type_conversions: int = 0
    type_conversion_failures: int = 0
    outliers_detected: int = 0
    outliers_removed: int = 0
    outliers_clipped: int = 0
    outliers_flagged: int = 0
    pii_values_masked: int = 0
    whitespace_stripped: int = 0
    case_changed: int = 0
    notes: List[str] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "column_name": self.column_name,
            "missing_values_handled": self.missing_values_handled,
            "type_conversions": self.type_conversions,
            "type_conversion_failures": self.type_conversion_failures,
            "outliers_detected": self.outliers_detected,
            "outliers_removed": self.outliers_removed,
            "outliers_clipped": self.outliers_clipped,
            "outliers_flagged": self.outliers_flagged,
            "pii_values_masked": self.pii_values_masked,
            "whitespace_stripped": self.whitespace_stripped,
            "case_changed": self.case_changed,
            "notes": self.notes,
        }


@dataclass
class CleanReport:
    """Comprehensive report of all cleaning operations."""

    rows_before: int
    rows_after: int
    columns_before: int = 0
    columns_after: int = 0
    timestamp: datetime = field(default_factory=datetime.now)
    column_changes: Dict[str, ColumnChange] = field(default_factory=dict)
    rows_removed: int = 0
    duplicate_rows_removed: int = 0
    empty_columns_removed: int = 0
    warnings: List[str] = field(default_factory=list)
    errors: List[str] = field(default_factory=list)

    def add_column_change(self, change: ColumnChange) -> None:
        """Add or update column change summary."""
        self.column_changes[change.column_name] = change

    def add_warning(self, message: str) -> None:
        """Add warning message."""
        self.warnings.append(message)

    def add_error(self, message: str) -> None:
        """Add error message."""
        self.errors.append(message)

    def get_summary(self) -> str:
        """Get human-readable summary."""
        lines = [
            "=" * 70,
            "DATA CLEANING REPORT",
            "=" * 70,
            f"Timestamp: {self.timestamp.isoformat()}",
            "",
            "OVERVIEW",
            "-" * 70,
            f"Rows before: {self.rows_before:,}",
            f"Rows after:  {self.rows_after:,}",
            f"Rows removed: {self.rows_removed:,}",
            f"Columns before: {self.columns_before}",
            f"Columns after:  {self.columns_after}",
            f"Columns removed: {self.empty_columns_removed}",
            "",
        ]

        if self.duplicate_rows_removed > 0:
            lines.append(f"Duplicate rows removed: {self.duplicate_rows_removed}")
            lines.append("")

        if self.column_changes:
            lines.append("COLUMN CHANGES")
            lines.append("-" * 70)
            for col_name, change in self.column_changes.items():
                if any(
                    [
                        change.missing_values_handled,
                        change.type_conversions,
                        change.outliers_detected,
                        change.pii_values_masked,
                        change.whitespace_stripped,
                        change.case_changed,
                    ]
                ):
                    lines.append(f"\n{col_name}:")
                    if change.missing_values_handled > 0:
                        lines.append(
                            f"  - Missing values handled: {change.missing_values_handled}"
                        )
                    if change.type_conversions > 0:
                        lines.append(f"  - Type conversions: {change.type_conversions}")
                    if change.type_conversion_failures > 0:
                        lines.append(
                            f"  - Type conversion failures: {change.type_conversion_failures}"
                        )
                    if change.outliers_detected > 0:
                        lines.append(
                            f"  - Outliers detected: {change.outliers_detected}"
                        )
                    if change.outliers_removed > 0:
                        lines.append(f"  - Outliers removed: {change.outliers_removed}")
                    if change.outliers_clipped > 0:
                        lines.append(f"  - Outliers clipped: {change.outliers_clipped}")
                    if change.outliers_flagged > 0:
                        lines.append(f"  - Outliers flagged: {change.outliers_flagged}")
                    if change.pii_values_masked > 0:
                        lines.append(f"  - PII values masked: {change.pii_values_masked}")
                    if change.whitespace_stripped > 0:
                        lines.append(
                            f"  - Whitespace stripped: {change.whitespace_stripped}"
                        )
                    if change.case_changed > 0:
                        lines.append(f"  - Case changed: {change.case_changed}")
                    if change.notes:
                        for note in change.notes:
                            lines.append(f"  - {note}")

        if self.warnings:
            lines.append("")
            lines.append("WARNINGS")
            lines.append("-" * 70)
            for warning in self.warnings:
                lines.append(f"  ⚠ {warning}")

        if self.errors:
            lines.append("")
            lines.append("ERRORS")
            lines.append("-" * 70)
            for error in self.errors:
                lines.append(f"  ✗ {error}")

        lines.append("")
        lines.append("=" * 70)

        return "\n".join(lines)

    def to_dict(self) -> Dict[str, Any]:
        """Convert report to dictionary."""
        return {
            "rows_before": self.rows_before,
            "rows_after": self.rows_after,
            "columns_before": self.columns_before,
            "columns_after": self.columns_after,
            "timestamp": self.timestamp.isoformat(),
            "rows_removed": self.rows_removed,
            "duplicate_rows_removed": self.duplicate_rows_removed,
            "empty_columns_removed": self.empty_columns_removed,
            "column_changes": {
                col_name: change.to_dict()
                for col_name, change in self.column_changes.items()
            },
            "warnings": self.warnings,
            "errors": self.errors,
        }

    def to_json(self) -> str:
        """Convert report to JSON string."""
        return json.dumps(self.to_dict(), indent=2)

    def __str__(self) -> str:
        """Return human-readable report."""
        return self.get_summary()
