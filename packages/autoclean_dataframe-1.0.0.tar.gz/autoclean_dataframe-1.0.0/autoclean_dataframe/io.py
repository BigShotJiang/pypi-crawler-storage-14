"""I/O utilities for loading/saving configurations and reports."""

import json
from pathlib import Path
from typing import Dict, Any, Union

import yaml

from .config import DataCleanConfig
from .report import CleanReport
from .types import ConfigValidationError, ReportExportError


def load_config(path: Union[str, Path]) -> DataCleanConfig:
    """
    Load DataCleanConfig from YAML or JSON file.

    Args:
        path: Path to config file (.yaml, .yml, or .json)

    Returns:
        DataCleanConfig instance

    Raises:
        FileNotFoundError: If file doesn't exist
        ConfigValidationError: If config is invalid
        ValueError: If file format is not supported

    Example:
        >>> config = load_config("config.yaml")
        >>> from autoclean_dataframe import clean_dataframe
        >>> df_clean, report = clean_dataframe(df, config)
    """
    path = Path(path)

    if not path.exists():
        raise FileNotFoundError(f"Config file not found: {path}")

    if path.suffix not in (".yaml", ".yml", ".json"):
        raise ValueError(f"Unsupported file format: {path.suffix}")

    try:
        if path.suffix in (".yaml", ".yml"):
            with open(path, "r") as f:
                data = yaml.safe_load(f)
        else:  # .json
            with open(path, "r") as f:
                data = json.load(f)

        # Parse into DataCleanConfig
        config = DataCleanConfig(**data)
        return config

    except yaml.YAMLError as e:
        raise ConfigValidationError(f"Failed to parse YAML: {e}")
    except json.JSONDecodeError as e:
        raise ConfigValidationError(f"Failed to parse JSON: {e}")
    except Exception as e:
        raise ConfigValidationError(f"Failed to load config: {e}")


def save_config(
    config: DataCleanConfig,
    path: Union[str, Path],
    format: str = "yaml",
) -> None:
    """
    Save DataCleanConfig to file.

    Args:
        config: DataCleanConfig to save
        path: Output file path
        format: Output format ("yaml" or "json")

    Raises:
        ValueError: If format is not supported
        ReportExportError: If saving fails

    Example:
        >>> config = DataCleanConfig(...)
        >>> save_config(config, "config.yaml")
    """
    path = Path(path)

    if format not in ("yaml", "json"):
        raise ValueError(f"Unsupported format: {format}")

    try:
        data = config.model_dump()

        if format == "yaml":
            with open(path, "w") as f:
                yaml.dump(data, f, default_flow_style=False, sort_keys=False)
        elif format == "json":
            with open(path, "w") as f:
                json.dump(data, f, indent=2)

    except Exception as e:
        raise ReportExportError(f"Failed to save config: {e}")


def save_report(
    report: CleanReport,
    path: Union[str, Path],
    format: str = "json",
) -> None:
    """
    Save CleanReport to file.

    Args:
        report: CleanReport to save
        path: Output file path
        format: Output format ("json" or "txt")

    Raises:
        ValueError: If format is not supported
        ReportExportError: If saving fails

    Example:
        >>> df_clean, report = clean_dataframe(df, config)
        >>> save_report(report, "report.json")
    """
    path = Path(path)

    if format not in ("json", "txt"):
        raise ValueError(f"Unsupported format: {format}")

    try:
        if format == "json":
            with open(path, "w") as f:
                f.write(report.to_json())
        elif format == "txt":
            with open(path, "w") as f:
                f.write(str(report))

    except Exception as e:
        raise ReportExportError(f"Failed to save report: {e}")


def load_config_dict(data: Dict[str, Any]) -> DataCleanConfig:
    """
    Load DataCleanConfig from dictionary.

    Args:
        data: Dictionary with config data

    Returns:
        DataCleanConfig instance

    Raises:
        ConfigValidationError: If config is invalid

    Example:
        >>> config_dict = {
        ...     "general": {"remove_duplicates": True},
        ...     "columns": {}
        ... }
        >>> config = load_config_dict(config_dict)
    """
    try:
        return DataCleanConfig(**data)
    except Exception as e:
        raise ConfigValidationError(f"Failed to parse config dict: {e}")


def config_to_dict(config: DataCleanConfig) -> Dict[str, Any]:
    """
    Convert DataCleanConfig to dictionary.

    Args:
        config: DataCleanConfig instance

    Returns:
        Dictionary representation
    """
    return config.model_dump()


def config_to_yaml(config: DataCleanConfig) -> str:
    """
    Convert DataCleanConfig to YAML string.

    Args:
        config: DataCleanConfig instance

    Returns:
        YAML string
    """
    data = config.model_dump()
    return yaml.dump(data, default_flow_style=False, sort_keys=False)


def config_to_json(config: DataCleanConfig) -> str:
    """
    Convert DataCleanConfig to JSON string.

    Args:
        config: DataCleanConfig instance

    Returns:
        JSON string
    """
    data = config.model_dump()
    return json.dumps(data, indent=2)


def report_to_dict(report: CleanReport) -> Dict[str, Any]:
    """
    Convert CleanReport to dictionary.

    Args:
        report: CleanReport instance

    Returns:
        Dictionary representation
    """
    return report.to_dict()
