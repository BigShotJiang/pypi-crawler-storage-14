"""Core cleaning pipeline orchestrator."""

import logging
from typing import Tuple, Optional
import pandas as pd

from .config import DataCleanConfig, GeneralCleanConfig, ColumnConfig
from .report import CleanReport, ColumnChange
from .types import (
    ImputationMethod,
    OutlierMethod,
    OutlierAction,
    PiiType,
    DataValidationError,
)
from . import utils


logger = logging.getLogger(__name__)


class CleaningPipeline:
    """Main orchestrator for data cleaning operations."""

    def __init__(self, config: DataCleanConfig):
        """
        Initialize cleaning pipeline.

        Args:
            config: DataCleanConfig specifying cleaning rules

        Raises:
            ValueError: If config is invalid
        """
        self.config = config
        self.logger = logging.getLogger(__name__)

    def clean(self, df: pd.DataFrame) -> Tuple[pd.DataFrame, CleanReport]:
        """
        Apply cleaning pipeline to DataFrame.

        Args:
            df: Input DataFrame to clean

        Returns:
            Tuple of (cleaned_df, report)

        Raises:
            DataValidationError: If input validation fails
        """
        # Validate input
        if df is None:
            raise DataValidationError("Input DataFrame cannot be None")
        if len(df) == 0:
            logger.warning("Input DataFrame is empty")

        # Create report
        report = CleanReport(
            rows_before=len(df),
            columns_before=len(df.columns),
            rows_after=len(df),
            columns_after=len(df.columns),
        )

        # Make a copy to avoid modifying input
        df_clean = df.copy()

        # Apply general cleaning
        df_clean, report = self._apply_general_cleaning(df_clean, report)

        # Apply per-column cleaning
        df_clean, report = self._apply_column_cleaning(df_clean, report)

        # Update final counts
        report.rows_after = len(df_clean)
        report.columns_after = len(df_clean.columns)
        report.rows_removed = report.rows_before - report.rows_after

        if self.config.verbose:
            logger.info(f"Cleaning complete. {report.rows_removed} rows removed.")

        return df_clean, report

    def _apply_general_cleaning(
        self,
        df: pd.DataFrame,
        report: CleanReport,
    ) -> Tuple[pd.DataFrame, CleanReport]:
        """
        Apply general cleaning rules.

        Args:
            df: DataFrame to clean
            report: Report to update

        Returns:
            Tuple of (cleaned_df, report)
        """
        config = self.config.general

        # Remove fully empty rows
        if config.drop_fully_empty_rows:
            rows_before = len(df)
            df = df.dropna(how="all")
            rows_dropped = rows_before - len(df)
            if rows_dropped > 0:
                report.add_warning(f"Dropped {rows_dropped} fully empty rows")
                report.rows_removed += rows_dropped

        # Remove fully empty columns
        if config.drop_fully_empty_columns:
            cols_before = len(df.columns)
            df = df.dropna(axis=1, how="all")
            cols_dropped = cols_before - len(df.columns)
            report.empty_columns_removed = cols_dropped
            if cols_dropped > 0:
                report.add_warning(f"Dropped {cols_dropped} fully empty columns")

        # Remove duplicates
        if config.remove_duplicates:
            rows_before = len(df)
            df = df.drop_duplicates()
            rows_dropped = rows_before - len(df)
            report.duplicate_rows_removed = rows_dropped
            if rows_dropped > 0:
                report.add_warning(f"Removed {rows_dropped} duplicate rows")

        return df, report

    def _apply_column_cleaning(
        self,
        df: pd.DataFrame,
        report: CleanReport,
    ) -> Tuple[pd.DataFrame, CleanReport]:
        """
        Apply per-column cleaning rules.

        Args:
            df: DataFrame to clean
            report: Report to update

        Returns:
            Tuple of (cleaned_df, report)
        """
        for col_name in df.columns:
            # Get column-specific config if exists
            col_config = self.config.columns.get(col_name)

            # Create change tracker
            change = ColumnChange(column_name=col_name)

            if col_config:
                # Apply text normalization
                if col_config.strip_whitespace or col_config.to_lowercase or col_config.to_uppercase:
                    df[col_name], stripped = self._apply_text_normalization(
                        df[col_name],
                        col_config,
                    )
                    change.whitespace_stripped = stripped

                # Apply PII masking
                if col_config.pii:
                    df[col_name], masked = self._apply_pii_masking(
                        df[col_name],
                        col_config.pii,
                    )
                    change.pii_values_masked = masked

                # Apply type conversion
                if col_config.type_conversion:
                    df[col_name], conversions, failures = self._apply_type_conversion(
                        df[col_name],
                        col_config.type_conversion,
                    )
                    change.type_conversions = conversions
                    change.type_conversion_failures = failures
                    if failures > 0:
                        change.notes.append(
                            f"{failures} type conversion failures (coerced to NaN)"
                        )

                # Apply outlier detection/handling
                if col_config.outliers:
                    df, df[col_name], outlier_info = self._apply_outlier_handling(
                        df,
                        col_name,
                        col_config.outliers,
                    )
                    change.outliers_detected = outlier_info["detected"]
                    change.outliers_removed = outlier_info["removed"]
                    change.outliers_clipped = outlier_info["clipped"]
                    change.outliers_flagged = outlier_info["flagged"]

                # Apply missing value imputation
                if col_config.missing_values:
                    df[col_name], imputed = self._apply_missing_value_handling(
                        df[col_name],
                        col_config.missing_values,
                    )
                    change.missing_values_handled = imputed

            report.add_column_change(change)

        return df, report

    def _apply_text_normalization(
        self,
        series: pd.Series,
        col_config: ColumnConfig,
    ) -> Tuple[pd.Series, int]:
        """
        Apply text normalization (strip whitespace, case changes).

        Returns:
            Tuple of (cleaned_series, count_of_changes)
        """
        count = 0

        if not pd.api.types.is_object_dtype(series) and not pd.api.types.is_string_dtype(series):
            return series, count

        original = series.copy()

        if col_config.strip_whitespace:
            series = series.str.strip()

        if col_config.to_lowercase:
            series = series.str.lower()

        if col_config.to_uppercase:
            series = series.str.upper()

        count = (original != series).sum()
        return series, count

    def _apply_pii_masking(
        self,
        series: pd.Series,
        pii_config,
    ) -> Tuple[pd.Series, int]:
        """
        Apply PII masking.

        Returns:
            Tuple of (masked_series, count_masked)
        """
        count = 0
        original = series.copy()

        if pii_config.pii_type == PiiType.EMAIL:
            series = series.apply(
                lambda x: utils.mask_email(x, pii_config.mask_char)
                if isinstance(x, str)
                else x
            )
        elif pii_config.pii_type == PiiType.PHONE:
            series = series.apply(
                lambda x: utils.mask_phone(x, pii_config.mask_char)
                if isinstance(x, str)
                else x
            )
        elif pii_config.pii_type == PiiType.CUSTOM and pii_config.custom_pattern:
            series = series.apply(
                lambda x: utils.mask_value(x, pii_config.custom_pattern, pii_config.mask_char)
                if isinstance(x, str)
                else x
            )

        count = (original != series).sum()
        return series, count

    def _apply_type_conversion(
        self,
        series: pd.Series,
        type_config,
    ) -> Tuple[pd.Series, int, int]:
        """
        Apply type conversion.

        Returns:
            Tuple of (converted_series, conversions_count, failures_count)
        """
        conversions = 0
        failures = 0

        if type_config.target_type == "none" and not type_config.infer_type:
            return series, conversions, failures

        target_type = type_config.target_type

        # Auto-detect type if infer_type is True
        if type_config.infer_type:
            inferred = utils.infer_column_type(series)
            type_map = {
                "numeric": "float",
                "datetime": "datetime",
                "categorical": "category",
                "text": "str",
            }
            target_type = type_map.get(inferred.value, "none")

        if target_type == "none":
            return series, conversions, failures

        original = series.copy()

        try:
            if target_type == "int":
                # Convert to float first, then int (handles NaN)
                series = pd.to_numeric(series, errors="coerce").astype("Int64")
            elif target_type == "float":
                series = pd.to_numeric(series, errors="coerce")
            elif target_type == "str":
                series = series.astype(str)
            elif target_type == "bool":
                series = series.apply(utils.parse_boolean)
            elif target_type == "datetime":
                if type_config.datetime_format:
                    series = pd.to_datetime(
                        series,
                        format=type_config.datetime_format,
                        errors="coerce",
                    )
                else:
                    series = pd.to_datetime(series, errors="coerce")
            elif target_type == "category":
                series = series.astype("category")
        except Exception as e:
            if type_config.strict:
                raise
            logger.warning(f"Type conversion failed: {e}")
            return original, conversions, failures

        # Count changes and failures
        conversions = (original != series).sum()
        failures = series.isna().sum() - original.isna().sum()
        failures = max(0, failures)  # Only count new NaNs

        return series, conversions, failures

    def _apply_outlier_handling(
        self,
        df: pd.DataFrame,
        col_name: str,
        outlier_config,
    ) -> Tuple[pd.DataFrame, pd.Series, dict]:
        """
        Apply outlier detection and handling.

        Returns:
            Tuple of (modified_df, handled_series, info_dict)
        """
        series = df[col_name]
        info = {"detected": 0, "removed": 0, "clipped": 0, "flagged": 0}

        if outlier_config.method == OutlierMethod.NONE:
            return df, series, info

        if not pd.api.types.is_numeric_dtype(series):
            return df, series, info

        # Detect outliers
        if outlier_config.method == OutlierMethod.IQR:
            outlier_mask = utils.detect_outliers_iqr(
                series,
                outlier_config.iqr_multiplier,
            )
        elif outlier_config.method == OutlierMethod.ZSCORE:
            outlier_mask = utils.detect_outliers_zscore(
                series,
                outlier_config.zscore_threshold,
            )
        else:
            return df, series, info

        info["detected"] = outlier_mask.sum()

        # Handle outliers
        if outlier_config.action == OutlierAction.REMOVE:
            series = series[~outlier_mask]
            df = df[~outlier_mask]  # Also remove from main DataFrame
            info["removed"] = info["detected"]
        elif outlier_config.action == OutlierAction.CLIP:
            if outlier_config.method == OutlierMethod.IQR:
                series = utils.clip_outliers_iqr(series, outlier_config.iqr_multiplier)
            info["clipped"] = info["detected"]
        elif outlier_config.action == OutlierAction.FLAG:
            flag_col = f"{col_name}_is_outlier"
            df[flag_col] = outlier_mask
            info["flagged"] = info["detected"]

        return df, series, info

    def _apply_missing_value_handling(
        self,
        series: pd.Series,
        missing_config,
    ) -> Tuple[pd.Series, int]:
        """
        Apply missing value handling.

        Returns:
            Tuple of (imputed_series, count_imputed)
        """
        count = 0
        strategy = missing_config.strategy

        if strategy == ImputationMethod.NONE:
            return series, count

        missing_before = series.isna().sum()

        try:
            if strategy == ImputationMethod.MEAN:
                series = utils.impute_mean(series)
            elif strategy == ImputationMethod.MEDIAN:
                series = utils.impute_median(series)
            elif strategy == ImputationMethod.MODE:
                series = utils.impute_mode(series)
            elif strategy == ImputationMethod.CONSTANT:
                series = series.fillna(missing_config.constant_value)
            elif strategy == ImputationMethod.FORWARD_FILL:
                series = series.fillna(method="ffill")
            elif strategy == ImputationMethod.BACKWARD_FILL:
                series = series.fillna(method="bfill")
            elif strategy == ImputationMethod.DROP_ROW:
                # This is handled at DataFrame level in the caller
                pass

            count = missing_before - series.isna().sum()
        except Exception as e:
            logger.warning(f"Missing value imputation failed: {e}")

        return series, count


def clean_dataframe(
    df: pd.DataFrame,
    config: DataCleanConfig,
) -> Tuple[pd.DataFrame, CleanReport]:
    """
    Apply cleaning pipeline to DataFrame.

    Args:
        df: DataFrame to clean
        config: DataCleanConfig specifying cleaning rules

    Returns:
        Tuple of (cleaned_df, report)

    Example:
        >>> config = DataCleanConfig(
        ...     general=GeneralCleanConfig(remove_duplicates=True),
        ...     columns={
        ...         "age": ColumnConfig(
        ...             column_name="age",
        ...             type_conversion=TypeConversionConfig(target_type="int")
        ...         )
        ...     }
        ... )
        >>> df_clean, report = clean_dataframe(df, config)
        >>> print(report)
    """
    pipeline = CleaningPipeline(config)
    return pipeline.clean(df)


def auto_clean(df: pd.DataFrame, verbose: bool = False) -> Tuple[pd.DataFrame, CleanReport]:
    """
    Apply smart default cleaning to DataFrame.

    This is a convenience function that applies:
    - Removes duplicate rows
    - Drops fully empty rows and columns
    - Auto-detects and converts column types
    - Detects and flags outliers (IQR method)
    - Handles missing values conservatively

    Args:
        df: DataFrame to clean
        verbose: Enable verbose logging

    Returns:
        Tuple of (cleaned_df, report)

    Example:
        >>> df_clean, report = auto_clean(df)
        >>> print(report)
    """
    from .config import (
        GeneralCleanConfig,
        TypeConversionConfig,
        OutlierConfig,
    )

    config = DataCleanConfig(
        general=GeneralCleanConfig(
            drop_fully_empty_rows=True,
            drop_fully_empty_columns=True,
            remove_duplicates=True,
            infer_dtypes=True,
        ),
        verbose=verbose,
    )

    pipeline = CleaningPipeline(config)
    return pipeline.clean(df)
