"""Handsfree speech-to-text daemon for Linux."""
