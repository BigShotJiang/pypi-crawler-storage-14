---
name: Feature request
about: Suggest an idea for this project
title: "[Feature] "
labels: enhancement
assignees: ""
---

**Problem / Use case**

**Proposed solution**

**Configuration surface**
- New env vars / config keys:

**Alternatives considered**

**Additional context**
