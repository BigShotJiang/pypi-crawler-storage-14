from __future__ import annotations

from pathlib import Path

from pybind11.setup_helpers import Pybind11Extension, build_ext
from setuptools import setup

ROOT = Path(__file__).parent

ext_modules = [
    Pybind11Extension(
        "pipeline_backend._backend",
        sources=["src/pipeline_backend/cpp/backend.cpp"],
        cxx_std=17,
    )
]

setup(
    ext_modules=ext_modules,
    cmdclass={"build_ext": build_ext},
)
