# cf-pipeline-backend

Pybind11-based backend implementing the mixed C++/Python pipeline described in `pipeline_backend/spec/PIPELINE_SPEC.md`.

Version 0.0.2 introduces a compiled backend (`pipeline_backend._backend`) that provides:
- C++ registry (cpp + python ops) and `Pipeline::run` loop
- PyCapsule C API (`pipeline_backend.register_op_v1`) for C++ plugins
- Python shims re-exporting the compiled functions (`pipeline_backend/__init__.py`)

This package exposes:

- `__backend_metadata__`
- `register_py_op`, `register_cpp_op`
- `list_ops`, `describe_ops`
- `Pipeline`
- `_register_op_capsule`

Resources bundled for validation/reference:
- Spec: `pipeline_backend/spec/PIPELINE_SPEC.md`
- Schemas: `pipeline_backend/spec/schemas/{pipeline_backend.schema.json,pipeline_plugin.schema.json}`
- Validator helper: `pipeline_backend.validator`

Example (uses cf_basic_signal, OPC UA virtual pH server):
```
pip install -e sand_toys/cf_basic_steps/cf_basic_signal
pip install -e sand_toys/cf-pipeline/cf-pipeline-backend
python sand_toys/cf-pipeline/cf-pipeline-backend/examples/run_opcua_fifo_avg_csv.py
```

Code lives in `src/pipeline_backend/`. This packaging layer enables tag-driven wheel builds and publishing to PyPI/TestPyPI.
