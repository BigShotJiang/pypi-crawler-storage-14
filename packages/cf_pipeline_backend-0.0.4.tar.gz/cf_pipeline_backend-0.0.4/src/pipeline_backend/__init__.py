"""
Python shim that re-exports the compiled pybind11 backend.

The compiled extension lives in pipeline_backend._backend and implements:
 - Data struct
 - Op registry (cpp + python)
 - Pipeline::add_step / Pipeline::run
 - PyCapsule C API for C++ plugins
"""

from __future__ import annotations

try:
    from . import _backend as _impl
except ImportError as exc:  # pragma: no cover - build-time guard
    raise ImportError(
        "pipeline_backend._backend extension is not available. "
        "Build or install the package (with a C++ toolchain) to use the C++ backend."
    ) from exc

Data = _impl.Data
Pipeline = _impl.Pipeline
register_py_op = _impl.register_py_op
register_cpp_op = _impl.register_cpp_op
list_ops = _impl.list_ops
describe_ops = _impl.describe_ops
_register_op_capsule = _impl._register_op_capsule

__backend_metadata__ = {
    "name": "pipeline_backend",
    "version": "0.0.2",
    "api_version": "1",
    "capsule_name": "pipeline_backend.register_op_v1",
    "data_abi_tag": "Data-v1",
    "supports_python_ops": True,
}

__all__ = [
    "Data",
    "Pipeline",
    "register_py_op",
    "register_cpp_op",
    "list_ops",
    "describe_ops",
    "__backend_metadata__",
    "_register_op_capsule",
]
