
pkg_version = "V1.1.5"

print(pkg_version)
from numpy import ndarray

from .example  import *
