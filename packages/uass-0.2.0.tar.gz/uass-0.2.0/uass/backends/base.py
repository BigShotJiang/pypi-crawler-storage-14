"""Base backend interface for state storage."""

from abc import ABC, abstractmethod
from typing import Optional, List, Callable
from ..schemas import UnifiedState


class StateBackend(ABC):
    """Abstract base class for state storage backends."""
    
    @abstractmethod
    def write_state(self, state: UnifiedState) -> bool:
        """
        Write state to storage.
        
        Args:
            state: UnifiedState to write
            
        Returns:
            True if successful, False otherwise
        """
        pass
    
    @abstractmethod
    def read_state(self, session_id: str, agent_id: str) -> Optional[UnifiedState]:
        """
        Read state from storage.
        
        Args:
            session_id: Session identifier
            agent_id: Agent identifier
            
        Returns:
            UnifiedState if found, None otherwise
        """
        pass
    
    @abstractmethod
    def delete_state(self, session_id: str, agent_id: str) -> bool:
        """
        Delete state from storage.
        
        Args:
            session_id: Session identifier
            agent_id: Agent identifier
            
        Returns:
            True if successful, False otherwise
        """
        pass
    
    @abstractmethod
    def list_agents(self, session_id: str) -> List[str]:
        """
        List all agent IDs in a session.
        
        Args:
            session_id: Session identifier
            
        Returns:
            List of agent IDs
        """
        pass
    
    @abstractmethod
    def read_shared_state(self, session_id: str) -> Optional[UnifiedState]:
        """
        Read shared state for a session (state accessible by all agents).
        
        Args:
            session_id: Session identifier
            
        Returns:
            UnifiedState if found, None otherwise
        """
        pass
    
    @abstractmethod
    def write_shared_state(self, session_id: str, state: UnifiedState) -> bool:
        """
        Write shared state for a session.
        
        Args:
            session_id: Session identifier
            state: UnifiedState to write
            
        Returns:
            True if successful, False otherwise
        """
        pass
    
    def subscribe(self, pattern: str, callback: Callable[[UnifiedState], None]) -> None:
        """
        Subscribe to state changes (optional, backend-dependent).
        
        Args:
            pattern: Pattern to match (e.g., "session:*:agent:*")
            callback: Function to call when state changes
        """
        # Default implementation does nothing
        pass

