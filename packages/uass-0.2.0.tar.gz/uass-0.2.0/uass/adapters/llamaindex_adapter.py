"""
LlamaIndex adapter for UASS integration.
"""

from typing import Optional, Dict, Any, List
from ..client import UASSClient
from ..adapters.base import FrameworkAdapter


class LlamaIndexAdapter(FrameworkAdapter):
    """
    Adapter for integrating LlamaIndex with UASS.
    
    Usage:
        from uass import UASSClient, RedisBackend, LlamaIndexAdapter
        
        client = UASSClient(backend=RedisBackend())
        adapter = LlamaIndexAdapter(client)
        
        # Sync LlamaIndex agent state
        adapter.sync_to_uass("session_123", "agent_1", agent, chat_history, memory)
        
        # Read state from another framework
        state = adapter.sync_from_uass("session_123", "agent_1")
    """
    
    def sync_to_uass(
        self,
        session_id: str,
        agent_id: str,
        agent: Any = None,
        chat_history: Optional[List[Any]] = None,
        memory: Optional[Any] = None,
        variables: Optional[Dict[str, Any]] = None,
    ) -> bool:
        """
        Sync LlamaIndex state to UASS.
        
        Args:
            session_id: Session identifier
            agent_id: Agent identifier
            agent: LlamaIndex agent instance (optional)
            chat_history: Chat history/messages (optional)
            memory: Memory object (optional)
            variables: Additional variables (optional)
            
        Returns:
            True if successful, False otherwise
        """
        uass_variables = variables or {}
        context = {}
        uass_messages = []
        actions = []
        
        if agent:
            # Extract agent information
            uass_variables["agent_name"] = getattr(agent, "name", getattr(agent, "agent_name", agent_id))
            if hasattr(agent, "system_prompt"):
                uass_variables["system_prompt"] = getattr(agent, "system_prompt", "")
            if hasattr(agent, "tools"):
                context["tools_count"] = len(getattr(agent, "tools", []))
        
        if memory:
            # Extract memory information
            if hasattr(memory, "chat_history"):
                context["memory_chat_history_count"] = len(getattr(memory, "chat_history", []))
            if hasattr(memory, "get_all"):
                context["memory_entries"] = len(getattr(memory, "get_all", lambda: [])())
        
        if chat_history:
            # Convert LlamaIndex messages to UASS format
            for msg in chat_history:
                if isinstance(msg, dict):
                    uass_messages.append(msg)
                else:
                    # Handle LlamaIndex message objects
                    uass_messages.append({
                        "role": getattr(msg, "role", getattr(msg, "message_type", "unknown")),
                        "content": getattr(msg, "content", getattr(msg, "text", str(msg))),
                        "timestamp": getattr(msg, "timestamp", None),
                    })
        
        framework_state = {}
        if agent:
            framework_state["agent_type"] = type(agent).__name__
        if memory:
            framework_state["memory_type"] = type(memory).__name__
        
        return self.client.write_state(
            session_id=session_id,
            agent_id=agent_id,
            framework="llamaindex",
            variables=uass_variables,
            context=context,
            messages=uass_messages,
            actions=actions,
            framework_state=framework_state,
        )
    
    def sync_from_uass(
        self,
        session_id: str,
        agent_id: str,
    ) -> Optional[Dict[str, Any]]:
        """
        Sync state from UASS to LlamaIndex format.
        
        Args:
            session_id: Session identifier
            agent_id: Agent identifier
            
        Returns:
            Dictionary with LlamaIndex-compatible state, or None if not found
        """
        unified_state = self.client.read_full_state(session_id, agent_id)
        if unified_state is None:
            return None
        
        # Return LlamaIndex-compatible format
        return {
            "messages": unified_state.state.messages,
            "variables": unified_state.state.variables,
            "context": unified_state.state.context,
            "actions": unified_state.state.actions,
            "framework_state": unified_state.state.framework_state,
        }

