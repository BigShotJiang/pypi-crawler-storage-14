"""
UASS - Unified Agent State System
A universal state management system for cross-framework AI agent communication.
"""

from .client import UASSClient
from .schemas import UnifiedState, AgentState, StateMetadata
from .backends import MemoryBackend, StateBackend

# Optional Redis backend
try:
    from .backends import RedisBackend
except ImportError:
    RedisBackend = None

from .adapters import (
    LangGraphAdapter,
    AutoGenAdapter,
    CrewAIAdapter,
    SemanticKernelAdapter,
    HaystackAdapter,
    LlamaIndexAdapter,
)

# Optional automatic management
try:
    from .auto_manager import AutoManager, AutoSyncHook
    __all__ = [
        "UASSClient",
        "UnifiedState",
        "AgentState",
        "StateMetadata",
        "RedisBackend",
        "MemoryBackend",
        "StateBackend",
        "LangGraphAdapter",
        "AutoGenAdapter",
        "CrewAIAdapter",
        "SemanticKernelAdapter",
        "HaystackAdapter",
        "LlamaIndexAdapter",
        "AutoManager",
        "AutoSyncHook",
    ]
except ImportError:
    __all__ = [
        "UASSClient",
        "UnifiedState",
        "AgentState",
        "StateMetadata",
        "RedisBackend",
        "MemoryBackend",
        "StateBackend",
        "LangGraphAdapter",
        "AutoGenAdapter",
        "CrewAIAdapter",
        "SemanticKernelAdapter",
        "HaystackAdapter",
        "LlamaIndexAdapter",
    ]

