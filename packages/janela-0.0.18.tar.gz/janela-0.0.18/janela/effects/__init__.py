"""Effects available in Janela."""

from .mosaic import mosaic

__all__ = ["mosaic"]
