Change Log
==========

1.0.1 (30/11/2025)
--------------------
 Initial Release

Introduced core classes:

Point, Line, Circle

Parabola, Ellipse, Hyperbola

Triangle

Implemented geometric computations:

distances, slopes, intersections

tangents & normals

foci, eccentricities, asymptotes

circle & conic geometry

Added construction helpers:

circle from 3 points

line from slope+point

section formula

foot of perpendicular

Provided plotting support (matplotlib) via plotting.py

Added full README.md, library structure, and package documentation