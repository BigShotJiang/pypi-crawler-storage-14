"""
coordgeo — A Python library for Coordinate Geometry (OOP style).

Public API Exports:
- Point, Line, Circle
- Conic sections: Parabola, Ellipse, Hyperbola
- Section formula & geometric projections
- Visualization helpers (accessible via coordgeo.plotting)
"""

__title__ = "coordgeo"
__version__ = "1.0.1"
__author__ = "Kareem Khan"

# Core geometry objects (Classes)
from .point import Point
from .line import Line
from .circle import Circle

# Section & projections (Functions)
from .section import section_point
from .projection import foot_of_perpendicular, perpendicular_distance, reflect_point

# Conics & Other Shapes
from .parabola import Parabola
from .ellipse import Ellipse
from .hyperbola import Hyperbola
from .triangle import Triangle

# Sub-modules
from . import plotting  # Import the plotting module itself

# Public exports (Includes the module itself)
__all__ = [
    "Point",
    "Line",
    "Circle",
    "section_point",
    "foot_of_perpendicular",
    "perpendicular_distance",
    "reflect_point",
    "Parabola",
    "Ellipse",
    "Hyperbola",
    "Triangle",
    "plotting", # <-- THIS IS THE ADDITION
]