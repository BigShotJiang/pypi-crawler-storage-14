from __future__ import annotations
from .point import Point


def section_point(p1: Point, p2: Point, m: float, n: float, *, internal: bool = True) -> Point:
    """
    Point dividing the segment joining p1(x1, y1) and p2(x2, y2)
    in the ratio m : n.

    - internal=True  -> internal division
    - internal=False -> external division

    Uses section formula from coordinate geometry.
    """
    x1, y1 = p1.x, p1.y
    x2, y2 = p2.x, p2.y

    if internal:
        x = (m * x2 + n * x1) / (m + n)
        y = (m * y2 + n * y1) / (m + n)
    else:
        x = (m * x2 - n * x1) / (m - n)
        y = (m * y2 - n * y1) / (m - n)

    return Point(x, y)
