from setuptools import setup, find_packages

setup(
    name="Alsulf",
    version="2025.11.0a1",
    description="Tools Network Scanning",
    author="ALSULF",
    packages=find_packages(),
    install_requires=[],
    entry_points={
        "console_scripts": [
            "ast=AST.Alsulf:main",
        ],
    },
)
