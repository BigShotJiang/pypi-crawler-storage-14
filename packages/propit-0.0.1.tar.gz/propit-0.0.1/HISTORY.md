# History

## 0.0.1 (2025-11-11)

* First release on PyPI.
