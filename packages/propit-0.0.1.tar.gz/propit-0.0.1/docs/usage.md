# Usage

To use Proteomics Pipeline Toolkit in a project:

```python
import propit
```
