# Proteomics Pipeline Toolkit

![PyPI version](https://img.shields.io/pypi/v/propit.svg)
[![Documentation Status](https://readthedocs.org/projects/propit/badge/?version=latest)](https://propit.readthedocs.io/en/latest/?version=latest)

Glue and Grease for Proteomics Pipelines.

* PyPI package: https://pypi.org/project/propit/
* Free software: MIT License
* Documentation: https://propit.readthedocs.io.

## Credits

This package was created with [Cookiecutter](https://github.com/audreyfeldroy/cookiecutter) and the [audreyfeldroy/cookiecutter-pypackage](https://github.com/audreyfeldroy/cookiecutter-pypackage) project template.
