.. bronx documentation master file, created by
   sphinx-quickstart on Wed Nov  2 14:34:54 2022.

Welcome to bronx's documentation!
=================================

.. automodule:: bronx

Dive in the sub-modules:

.. autosummary::
   :toctree: _autosummary
   :template: autosummary/custom-module.tpl
   :recursive:

   bronx.compat
   bronx.datagrip
   bronx.fancies
   bronx.graphics
   bronx.meteo
   bronx.net
   bronx.patterns
   bronx.stdtypes
   bronx.syntax
   bronx.system

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
