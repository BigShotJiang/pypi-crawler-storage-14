"""
A collection of tools to access all kinds of data (often read from files).
"""

#: No automatic export
__all__ = []
