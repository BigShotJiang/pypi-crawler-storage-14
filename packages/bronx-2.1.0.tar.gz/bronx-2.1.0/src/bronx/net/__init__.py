"""
Classes and functions to deal with network connections.
"""

#: No automatic export
__all__ = []
