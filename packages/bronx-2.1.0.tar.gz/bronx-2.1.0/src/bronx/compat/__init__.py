"""
Some annoying tools that help to make the jump from Python2 to Python3.
"""

#: No automatic export
__all__ = []
