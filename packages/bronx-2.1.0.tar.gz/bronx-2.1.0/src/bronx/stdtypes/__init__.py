"""
Extended types classes.
"""

#: No automatic export
__all__ = []
