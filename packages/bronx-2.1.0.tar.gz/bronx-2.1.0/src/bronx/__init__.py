"""
A collection of basic utilities that are used in the Vortex project
but also in other ones. Consequently, this package is independent
of the Vortex package.

BRONX may mean...

* Boîte Révolutionnaire d'Outils Nonobstant vorteX
* Bunch of Reusable Objects Not in vorteX

"""

#: No automatic export
__all__ = []
