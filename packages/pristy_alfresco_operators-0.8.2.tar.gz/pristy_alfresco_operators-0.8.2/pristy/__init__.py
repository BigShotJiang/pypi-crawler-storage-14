"""
Pristy Alfresco operators for Airflow
"""
