"""Store all the possible HTTP methods.
"""
httpmethods = ["HEAD", "GET", "POST", "PUT", "DELETE", "TRACE", "OPTIONS", "CONNECT", "PATCH"]