"""Common type definitions and imports for fake Kubernetes client"""
