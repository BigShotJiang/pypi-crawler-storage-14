"""Internal modules used by the PracticeJapanese quizzes package."""

__all__ = ["kanji", "vocab", "quiz"]
