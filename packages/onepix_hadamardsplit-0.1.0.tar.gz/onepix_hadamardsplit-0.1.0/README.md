## HadamardSplit  
---  

## Overview  

The *Hadamard Split* method is a classical single-pixel imaging technique that uses **Hadamard patterns** generated from an unstructured matrix as an orthogonal basis, combined with a *splitting* method. These patterns are **binary** (black and white), which means they do not require grayscale projection.  

| Development Status | Technique Specificity | Measurement Output Format | Example Patterns |
|--------------------|-----------------------|----------------------------|------------------|
| Functional and final | Classical SPI, binary patterns | Datacube | <p align="center"> <img src="img/hadamardsplit.png" alt="hub" width="100"/> </p> |

## install 
tested with python 3.9
```bash
pip install onepix_hadamardsplit
```

## 🔗 Source Code  
📁 Access the source code on GitHub:  
👉 [ONE-PIX – HadamardSplit Imaging Method](https://github.com/PhotonicsOpenProjects/ONE-PIX/tree/main/plugins/imaging_methods/HadamardSplit)

## 🧪 Author & Contributor  
🔧 Made by [POP](https://www.photonics-open-projects.com/) 💡
