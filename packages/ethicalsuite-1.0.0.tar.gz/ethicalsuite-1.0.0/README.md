Use the app in an ethical manner and NEVER use it to hurt anyone
The app has -
[1] Port Scanner                         
[2] Service Fingerprinter                
[3] Automatic Exploit Finder (CVE + PoC) 
[0] Exit
All these features are easy to run and the app is fast
    ____________  _______________    __       _____ __  __________________
   / ____/_  __/ / / /  _/ ____/   |  / /      / ___// / / /  _/_  __/ ____/
  / __/   / / / /_/ // // /   / /| | / /       \__ \/ / / // /  / / / __/   
 / /___  / / / __  // // /___/ ___ |/ /___    ___/ / /_/ // /  / / / /___   
/_____/ /_/ /_/ /_/___/\____/_/  |_/_____/   /____/\____/___/ /_/ /_____/   
                                                                            

 Ethical Hacking Toolkit v1.0
 Made by Czax foundation
                             Thanks for Using 
                              -Czax foundation