__all__ = ["UserWebsocket"]


class UserWebsocket:
    """Пользовательский вебсокет Bybit."""

    pass
