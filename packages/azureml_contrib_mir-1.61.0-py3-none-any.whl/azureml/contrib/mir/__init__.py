# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------
"""This package is used for managing MIR webservices created with Azure Machine Learning.
"""

__path__ = __import__('pkgutil').extend_path(__path__, __name__)
