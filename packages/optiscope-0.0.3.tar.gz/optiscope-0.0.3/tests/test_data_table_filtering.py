import unittest

import pandas as pd

from optiscope.dash_app.components.data_table import DataTable


class TestDataTableFiltering(unittest.TestCase):
    def setUp(self):
        # Instantiate DataTable with dummy IDs
        self.dt = DataTable(component_id="test-table")
        self.df = pd.DataFrame(
            {
                "A": [1, 2, 3, 4, 5],
                "B": ["apple", "banana", "cherry", "date", "elderberry"],
                "C": [0.1, 0.2, 0.3, 0.4, 0.5],
            }
        )

    def test_filter_gt(self):
        filtered = self.dt._filter_dataframe(self.df, "{A} gt 3")
        self.assertEqual(len(filtered), 2)
        self.assertTrue(all(filtered["A"] > 3))

    def test_filter_ge(self):
        filtered = self.dt._filter_dataframe(self.df, "{A} ge 3")
        self.assertEqual(len(filtered), 3)
        self.assertTrue(all(filtered["A"] >= 3))

    def test_filter_lt(self):
        filtered = self.dt._filter_dataframe(self.df, "{C} lt 0.3")
        self.assertEqual(len(filtered), 2)
        self.assertTrue(all(filtered["C"] < 0.3))

    def test_filter_le(self):
        filtered = self.dt._filter_dataframe(self.df, "{C} le 0.3")
        self.assertEqual(len(filtered), 3)
        self.assertTrue(all(filtered["C"] <= 0.3))

    def test_filter_eq_numeric(self):
        filtered = self.dt._filter_dataframe(self.df, "{A} eq 3")
        self.assertEqual(len(filtered), 1)
        self.assertEqual(filtered.iloc[0]["A"], 3)

    def test_filter_ne_numeric(self):
        filtered = self.dt._filter_dataframe(self.df, "{A} ne 3")
        self.assertEqual(len(filtered), 4)
        self.assertFalse(3 in filtered["A"].values)

    def test_filter_contains(self):
        filtered = self.dt._filter_dataframe(self.df, "{B} contains 'an'")
        self.assertEqual(len(filtered), 1)  # banana
        self.assertEqual(filtered.iloc[0]["B"], "banana")
        # banana: yes
        pass

    # def test_filter_contains_case_insensitive(self):
    #     filtered = self.dt._filter_dataframe(self.df, "{B} contains 'AN'")
    #     self.assertEqual(len(filtered), 1)  # banana
    #     self.assertEqual(filtered.iloc[0]["B"], "banana")

    def test_multiple_filters(self):
        filtered = self.dt._filter_dataframe(self.df, "{A} gt 2 && {C} lt 0.5")
        # A > 2: 3, 4, 5
        # C < 0.5: 0.1, 0.2, 0.3, 0.4
        # Intersection: 3 (C=0.3), 4 (C=0.4)
        self.assertEqual(len(filtered), 2)
        self.assertTrue(all(filtered["A"].isin([3, 4])))


if __name__ == "__main__":
    unittest.main()
