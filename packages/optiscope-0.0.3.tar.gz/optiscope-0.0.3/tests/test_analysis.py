"""
Unit tests for the analysis module.
"""

import numpy as np
import pandas as pd
import pytest

from optiscope.core.data_model import OptimizationResult
from optiscope.core.data_types import (
    Constraint,
    ConstraintType,
    Objective,
    OptimizationDirection,
)


@pytest.fixture
def sample_result() -> OptimizationResult:
    """Create a sample OptimizationResult for testing."""
    design_vars = pd.DataFrame({"x1": [1, 2, 3, 4], "x2": [4, 3, 2, 1]})
    objectives = pd.DataFrame({"f1": [1, 2, 1, 3], "f2": [3, 1, 2, 1]})
    constraints = pd.DataFrame({"g1": [-1, 1, -2, 0.5], "g2": [0, 0, 0, -1]})

    result = OptimizationResult(
        design_variables=design_vars,
        objectives=objectives,
        inequality_constraints=constraints,
    )

    result.add_variable_metadata(Objective(name="f1", direction=OptimizationDirection.MINIMIZE))
    result.add_variable_metadata(Objective(name="f2", direction=OptimizationDirection.MINIMIZE))
    result.add_variable_metadata(Constraint(name="g1", constraint_type=ConstraintType.INEQUALITY))
    result.add_variable_metadata(Constraint(name="g2", constraint_type=ConstraintType.INEQUALITY))
    return result


def test_find_pareto_front(sample_result):
    """Test the find_pareto_front method."""
    pareto_set = sample_result.find_pareto_front()
    assert pareto_set.name == "pareto_front"
    assert sorted(pareto_set.indices) == [1, 2]


def test_check_feasibility(sample_result):
    """Test the check_feasibility method."""
    feasible_set = sample_result.check_feasibility()
    assert feasible_set.name == "feasible"
    assert sorted(feasible_set.indices) == [0, 2]


def test_rank_with_wsm(sample_result):
    """Test the rank_with_wsm method."""
    weights = {"f1": 0.5, "f2": 0.5}
    scores = sample_result.rank_with_wsm(weights)

    assert isinstance(scores, pd.Series)
    assert len(scores) == 4
    assert np.isclose(scores.iloc[0], 0.5, atol=1e-5)
    assert np.isclose(scores.iloc[1], 0.25, atol=1e-5)
    assert np.isclose(scores.iloc[2], 0.25, atol=1e-5)
    assert np.isclose(scores.iloc[3], 0.5, atol=1e-5)


def test_find_pareto_front_from_set(sample_result):
    """Test finding Pareto front from a subset."""
    # In the subset [0, 1, 3], solution 3 is dominated by solution 1.
    # The pareto front of the subset should be [0, 1].
    sample_result.create_set("subset", indices=[0, 1, 3])
    pareto_set = sample_result.find_pareto_front(from_set="subset")
    assert sorted(pareto_set.indices) == [0, 1]
