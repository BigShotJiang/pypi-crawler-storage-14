import numpy as np
import pytest

from optiscope.analysis.pareto import (
    identify_pareto_front,
    is_pareto_efficient,
    is_pareto_efficient_auto,
    is_pareto_efficient_dumb,
    is_pareto_efficient_simple,
)
from optiscope.core.data_types import OptimizationDirection


# Test data fixtures
@pytest.fixture
def simple_min_data():
    # Point 0: (1, 1) - Pareto optimal
    # Point 1: (2, 2) - Dominated by 0
    # Point 2: (1, 2) - Dominated by 0
    # Point 3: (0.5, 3) - Pareto optimal
    return np.array([[1.0, 1.0], [2.0, 2.0], [1.0, 2.0], [0.5, 3.0]])


@pytest.fixture
def simple_max_data():
    # Point 0: (2, 2) - Pareto optimal
    # Point 1: (1, 1) - Dominated by 0
    # Point 2: (2, 1) - Dominated by 0
    # Point 3: (3, 0.5) - Pareto optimal
    return np.array([[2.0, 2.0], [1.0, 1.0], [2.0, 1.0], [3.0, 0.5]])


@pytest.fixture
def mixed_data():
    # Obj 1: Min, Obj 2: Max
    # Point 0: (1, 2) - Pareto optimal (low cost, high value)
    # Point 1: (2, 1) - Dominated by 0 (higher cost, lower value)
    # Point 2: (0.5, 1) - Pareto optimal (lowest cost, low value)
    # Point 3: (2, 3) - Pareto optimal (high cost, highest value)
    return np.array([[1.0, 2.0], [2.0, 1.0], [0.5, 1.0], [2.0, 3.0]])


@pytest.fixture
def duplicate_data():
    # Point 0: (1, 1) - Pareto optimal
    # Point 1: (1, 1) - Pareto optimal (duplicate)
    # Point 2: (2, 2) - Dominated by 0 and 1
    return np.array([[1.0, 1.0], [1.0, 1.0], [2.0, 2.0]])


def test_is_pareto_efficient_dumb_min(simple_min_data):
    # Default is minimize
    mask = is_pareto_efficient_dumb(simple_min_data)
    expected = np.array([True, False, False, True])
    np.testing.assert_array_equal(mask, expected)


def test_is_pareto_efficient_dumb_max(simple_max_data):
    directions = [OptimizationDirection.MAXIMIZE, OptimizationDirection.MAXIMIZE]
    mask = is_pareto_efficient_dumb(simple_max_data, directions)
    expected = np.array([True, False, False, True])
    np.testing.assert_array_equal(mask, expected)


def test_is_pareto_efficient_simple_min(simple_min_data):
    mask = is_pareto_efficient_simple(simple_min_data)
    expected = np.array([True, False, False, True])
    np.testing.assert_array_equal(mask, expected)


def test_is_pareto_efficient_simple_max(simple_max_data):
    directions = [OptimizationDirection.MAXIMIZE, OptimizationDirection.MAXIMIZE]
    mask = is_pareto_efficient_simple(simple_max_data, directions)
    expected = np.array([True, False, False, True])
    np.testing.assert_array_equal(mask, expected)


def test_is_pareto_efficient_min(simple_min_data):
    mask = is_pareto_efficient(simple_min_data, return_mask=True)
    expected = np.array([True, False, False, True])
    np.testing.assert_array_equal(mask, expected)

    indices = is_pareto_efficient(simple_min_data, return_mask=False)
    # Note: The order of indices might vary depending on implementation details,
    # but for this simple case and implementation it should be sorted or stable.
    # The current implementation returns sorted indices of efficient points.
    expected_indices = np.array([0, 3])
    np.testing.assert_array_equal(np.sort(indices), expected_indices)


def test_is_pareto_efficient_max(simple_max_data):
    directions = [OptimizationDirection.MAXIMIZE, OptimizationDirection.MAXIMIZE]
    mask = is_pareto_efficient(simple_max_data, directions, return_mask=True)
    expected = np.array([True, False, False, True])
    np.testing.assert_array_equal(mask, expected)


def test_is_pareto_efficient_mixed(mixed_data):
    directions = [OptimizationDirection.MINIMIZE, OptimizationDirection.MAXIMIZE]
    mask = is_pareto_efficient(mixed_data, directions, return_mask=True)
    expected = np.array([True, False, True, True])
    np.testing.assert_array_equal(mask, expected)


def test_is_pareto_efficient_auto_min(simple_min_data):
    mask = is_pareto_efficient_auto(simple_min_data)
    expected = np.array([True, False, False, True])
    np.testing.assert_array_equal(mask, expected)


def test_identify_pareto_front_basic(simple_min_data):
    mask = identify_pareto_front(simple_min_data)
    expected = np.array([True, False, False, True])
    np.testing.assert_array_equal(mask, expected)


def test_identify_pareto_front_with_mask(simple_min_data):
    # Mask out the first point (which was Pareto optimal)
    # Remaining points: (2, 2), (1, 2), (0.5, 3)
    # (1, 2) dominates (2, 2)
    # (0.5, 3) is Pareto optimal
    # (1, 2) is Pareto optimal among the subset
    input_mask = np.array([False, True, True, True])

    result_mask = identify_pareto_front(simple_min_data, mask=input_mask)

    # Point 0 is False because it was masked out
    # Point 1 is False because it is dominated by Point 2
    # Point 2 is True because it is not dominated by any other CANDIDATE
    # Point 3 is True
    expected = np.array([False, False, True, True])
    np.testing.assert_array_equal(result_mask, expected)


def test_duplicates(duplicate_data):
    # Duplicates will not both be considered Pareto efficient if they are non-dominated
    mask = is_pareto_efficient(duplicate_data, return_mask=True)
    expected = np.array([True, False, False])
    np.testing.assert_array_equal(mask, expected)


def test_single_point():
    data = np.array([[1.0, 1.0]])
    mask = is_pareto_efficient(data, return_mask=True)
    expected = np.array([True])
    np.testing.assert_array_equal(mask, expected)


def test_empty_input():
    data = np.empty((0, 2))
    mask = is_pareto_efficient(data, return_mask=True)
    expected = np.array([], dtype=bool)
    np.testing.assert_array_equal(mask, expected)


def test_identify_pareto_front_validation():
    with pytest.raises(ValueError, match="objectives must be a 2D array"):
        identify_pareto_front(np.array([1, 2, 3]))

    with pytest.raises(ValueError, match="Mismatch between number of objectives"):
        identify_pareto_front(np.array([[1, 2]]), directions=[OptimizationDirection.MINIMIZE])


def test_is_pareto_efficient_dumb_mixed(mixed_data):
    directions = [OptimizationDirection.MINIMIZE, OptimizationDirection.MAXIMIZE]
    mask = is_pareto_efficient_dumb(mixed_data, directions)
    expected = np.array([True, False, True, True])
    np.testing.assert_array_equal(mask, expected)


def test_is_pareto_efficient_simple_mixed(mixed_data):
    directions = [OptimizationDirection.MINIMIZE, OptimizationDirection.MAXIMIZE]
    mask = is_pareto_efficient_simple(mixed_data, directions)
    expected = np.array([True, False, True, True])
    np.testing.assert_array_equal(mask, expected)
