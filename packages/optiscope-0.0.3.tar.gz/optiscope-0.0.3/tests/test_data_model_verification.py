import numpy as np
import pandas as pd
import polars as pl

from optiscope.core.data_model import OptimizationResult, ProblemMetadata
from optiscope.core.data_types import (
    Constraint,
    ConstraintType,
    CustomDataType,
    DataTypeCategory,
    DesignVariable,
    Objective,
    Observable,
)


def test_optimization_result_init():
    print("Testing OptimizationResult initialization...")
    # Test empty init
    res = OptimizationResult()
    assert isinstance(res.metadata, ProblemMetadata)
    assert res.metadata.name == "Unnamed Problem"
    assert res.n_points == 0
    print("Empty init successful.")

    # Test with Pandas DataFrame
    df_pd = pd.DataFrame({"x": [1, 2, 3], "y": [4, 5, 6]})
    res_pd = OptimizationResult(design_variables=df_pd)
    assert res_pd.n_points == 3
    assert isinstance(res_pd._design_variables, pl.DataFrame)
    assert res_pd.design_variables.equals(df_pd)
    print("Pandas init successful.")

    # Test with Polars DataFrame
    df_pl = pl.DataFrame({"obj1": [10.0, 20.0]})
    res_pl = OptimizationResult(objectives=df_pl)
    assert res_pl.n_points == 2
    assert isinstance(res_pl._objectives, pl.DataFrame)
    assert res_pl.objectives.equals(df_pl.to_pandas())
    print("Polars init successful.")


def test_add_column():
    print("\nTesting add_column...")
    res = OptimizationResult()

    # Add design variable
    x_data = [1.0, 2.0, 3.0]
    res.add_column("x", x_data, DataTypeCategory.DESIGN_VARIABLE)

    assert res.n_points == 3
    assert "x" in res.design_variables.columns
    meta = res.get_variable_metadata("x")
    assert isinstance(meta, DesignVariable)
    assert meta.name == "x"
    assert meta.category == DataTypeCategory.DESIGN_VARIABLE
    print("Added design variable.")

    # Add objective
    obj_data = [10.0, 5.0, 2.0]
    res.add_column("f1", obj_data, DataTypeCategory.OBJECTIVE)
    assert "f1" in res.objectives.columns
    meta = res.get_variable_metadata("f1")
    assert isinstance(meta, Objective)
    print("Added objective.")

    # Add constraint
    const_data = [0.0, -1.0, 0.5]
    res.add_column("g1", const_data, DataTypeCategory.CONSTRAINT)
    # Default constraint type is INEQUALITY
    assert "g1" in res.inequality_constraints.columns
    meta = res.get_variable_metadata("g1")
    assert isinstance(meta, Constraint)
    print("Added constraint.")

    # Add observable
    obs_data = [100, 200, 300]
    res.add_column("obs1", obs_data, DataTypeCategory.OBSERVABLE)
    assert "obs1" in res.observables.columns
    meta = res.get_variable_metadata("obs1")
    assert isinstance(meta, Observable)
    print("Added observable.")

    # Add custom data
    custom_data = ["a", "b", "c"]
    # Must provide custom metadata for CUSTOM category if we want to specify custom_type,
    # but add_column handles default metadata creation.
    # Let's see if default works.
    res.add_column("custom1", custom_data, DataTypeCategory.CUSTOM)
    meta = res.get_variable_metadata("custom1")
    assert isinstance(meta, CustomDataType)
    assert meta.custom_type == "generic"
    # Check if data is stored in _custom_data
    assert "generic" in res._custom_data
    assert "custom1" in res._custom_data["generic"].columns
    print("Added custom data.")


def test_add_column_explicit_metadata():
    print("\nTesting add_column with explicit metadata...")
    res = OptimizationResult()
    n_points = 3

    # Design variable with bounds
    x_data = np.zeros(n_points)
    meta_x = DesignVariable(name="x", lower_bound=0, upper_bound=10)
    res.add_column("x", x_data, DataTypeCategory.DESIGN_VARIABLE, metadata=meta_x)

    stored_meta = res.get_variable_metadata("x")
    assert stored_meta.lower_bound == 0
    assert stored_meta.upper_bound == 10
    print("Explicit DesignVariable metadata successful.")

    # Equality constraint
    h_data = np.zeros(n_points)
    meta_h = Constraint(name="h1", constraint_type=ConstraintType.EQUALITY)
    res.add_column("h1", h_data, DataTypeCategory.CONSTRAINT, metadata=meta_h)

    assert "h1" in res.equality_constraints.columns
    assert "h1" not in res.inequality_constraints.columns
    print("Explicit Equality Constraint successful.")


def test_serialization():
    print("\nTesting serialization (to_dict/from_dict)...")
    res = OptimizationResult(problem_metadata=ProblemMetadata(name="Test Problem"))
    res.add_column("x", [1, 2], DataTypeCategory.DESIGN_VARIABLE)
    res.add_column("f", [10, 20], DataTypeCategory.OBJECTIVE)

    data_dict = res.to_dict()

    # Verify dictionary structure
    assert data_dict["problem_metadata"]["name"] == "Test Problem"
    assert "x" in str(data_dict["design_variables"])  # JSON string inside

    # Reconstruct
    res_new = OptimizationResult.from_dict(data_dict)

    assert res_new.metadata.name == "Test Problem"
    assert res_new.n_points == 2
    assert "x" in res_new.design_variables.columns
    assert "f" in res_new.objectives.columns

    # Verify Polars storage in reconstructed object
    assert isinstance(res_new._design_variables, pl.DataFrame)

    print("Serialization successful.")
