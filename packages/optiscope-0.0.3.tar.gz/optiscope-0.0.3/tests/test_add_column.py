import numpy as np
import pandas as pd

from optiscope.core.data_model import OptimizationResult
from optiscope.core.data_types import (
    Constraint,
    ConstraintType,
    CustomDataType,
    DataTypeCategory,
    Objective,
    Observable,
    OptimizationDirection,
)


def test_add_column():
    print("Starting test_add_column...")
    # 1. Initialize OptimizationResult with some data
    n_points = 5
    design_variables = pd.DataFrame(
        {"x1": np.random.rand(n_points), "x2": np.random.rand(n_points)}
    )
    objectives = pd.DataFrame({"f1": np.random.rand(n_points)})

    opt_result = OptimizationResult(design_variables=design_variables, objectives=objectives)

    print(f"Initial n_points: {opt_result.n_points}")
    assert opt_result.n_points == n_points

    # 2. Add a column with default metadata (Observable)
    print("\n--- Testing add observable (default metadata) ---")
    new_observable_data = np.random.rand(n_points)
    opt_result.add_column("obs1", new_observable_data)

    print("Checking if 'obs1' is in observables...")
    assert "obs1" in opt_result.observables.columns
    assert len(opt_result.observables) == n_points
    meta = opt_result.get_variable_metadata("obs1")
    assert meta.category == DataTypeCategory.OBSERVABLE
    print("Success: 'obs1' added as observable.")

    # 3. Add a column with specific metadata (Objective)
    print("\n--- Testing add objective ---")
    new_objective_data = np.random.rand(n_points)
    obj_metadata = Objective(name="f2", direction=OptimizationDirection.MAXIMIZE)
    opt_result.add_column(
        "f2", new_objective_data, category=DataTypeCategory.OBJECTIVE, metadata=obj_metadata
    )

    print("Checking if 'f2' is in objectives...")
    assert "f2" in opt_result.objectives.columns
    meta = opt_result.get_variable_metadata("f2")
    assert meta.category == DataTypeCategory.OBJECTIVE
    assert meta.direction == OptimizationDirection.MAXIMIZE
    print("Success: 'f2' added as objective.")

    # 4. Add a column for a Constraint (Inequality)
    print("\n--- Testing add inequality constraint ---")
    new_constraint_data = np.random.rand(n_points)
    const_metadata = Constraint(name="g1", constraint_type=ConstraintType.INEQUALITY)
    opt_result.add_column(
        "g1", new_constraint_data, category=DataTypeCategory.CONSTRAINT, metadata=const_metadata
    )

    print("Checking if 'g1' is in inequality constraints...")
    assert "g1" in opt_result.inequality_constraints.columns
    meta = opt_result.get_variable_metadata("g1")
    assert meta.category == DataTypeCategory.CONSTRAINT
    assert meta.constraint_type == ConstraintType.INEQUALITY
    print("Success: 'g1' added as inequality constraint.")

    # 5. Add a column for a Constraint (Equality)
    print("\n--- Testing add equality constraint ---")
    new_eq_constraint_data = np.random.rand(n_points)
    eq_const_metadata = Constraint(name="h1", constraint_type=ConstraintType.EQUALITY)
    opt_result.add_column(
        "h1",
        new_eq_constraint_data,
        category=DataTypeCategory.CONSTRAINT,
        metadata=eq_const_metadata,
    )

    print("Checking if 'h1' is in equality constraints...")
    assert "h1" in opt_result.equality_constraints.columns
    meta = opt_result.get_variable_metadata("h1")
    assert meta.constraint_type == ConstraintType.EQUALITY
    print("Success: 'h1' added as equality constraint.")

    # 6. Add a column for Custom data
    print("\n--- Testing add custom data ---")
    new_custom_data = np.random.rand(n_points)
    custom_metadata = CustomDataType(name="custom1", custom_type="metrics")
    opt_result.add_column(
        "custom1", new_custom_data, category=DataTypeCategory.CUSTOM, metadata=custom_metadata
    )

    print("Checking if 'custom1' is in custom data 'metrics'...")
    assert "metrics" in opt_result._custom_data
    assert "custom1" in opt_result._custom_data["metrics"].columns
    print("Success: 'custom1' added to custom data.")

    # 7. Error handling: Length mismatch
    print("\n--- Testing error: Length mismatch ---")
    try:
        opt_result.add_column("fail", np.random.rand(n_points + 1))
        print("Error: Should have raised ValueError for length mismatch")
        assert False, "Did not raise ValueError for length mismatch"
    except ValueError as e:
        print(f"Success: Caught expected error: {e}")

    # 8. Error handling: Metadata mismatch (Category)
    print("\n--- Testing error: Category mismatch ---")
    try:
        wrong_metadata = Objective(name="wrong")  # Category is OBJECTIVE
        opt_result.add_column(
            "wrong",
            np.random.rand(n_points),
            category=DataTypeCategory.OBSERVABLE,
            metadata=wrong_metadata,
        )
        print("Error: Should have raised ValueError for category mismatch")
        assert False, "Did not raise ValueError for category mismatch"
    except ValueError as e:
        print(f"Success: Caught expected error: {e}")

    # 9. Error handling: Metadata mismatch (Name)
    print("\n--- Testing error: Name mismatch ---")
    try:
        wrong_metadata = Observable(name="wrong_name")
        opt_result.add_column(
            "right_name",
            np.random.rand(n_points),
            category=DataTypeCategory.OBSERVABLE,
            metadata=wrong_metadata,
        )
        print("Error: Should have raised ValueError for name mismatch")
        assert False, "Did not raise ValueError for name mismatch"
    except ValueError as e:
        print(f"Success: Caught expected error: {e}")

    print("\nAll tests passed!")
