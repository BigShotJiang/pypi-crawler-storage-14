import os
import shutil
import unittest
from unittest.mock import patch

import numpy as np
import pandas as pd

from optiscope import load_results, save_results
from optiscope.analysis import (
    adaptive_smart_pareto_filter,
    compare_weight_scenarios,
    detect_knee_points,
    identify_pareto_front,
    smart_pareto_filter,
    topsis,
    topsis_from_result,
)
from optiscope.core.result_set import ResultSet
from optiscope.io.csv_handler import CSVHandler
from optiscope.io.json_handler import JSONHandler
from optiscope.plotting import (
    plot_correlation_heatmap,
    plot_parallel_coordinates,
    plot_pareto_front_2d,
    plot_pareto_front_3d,
    plot_scatter_matrix,
)
from optiscope.plotting.time_series import (
    plot_optimization_history,
    plot_time_series,
    plot_time_series_resampled,
)


class TestDocsExamples(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        # Create dummy data for tests
        cls.csv_filename = "optimization_results.csv"
        cls.json_filename = "optimization_results.json"
        cls.data_csv_filename = "data.csv"
        cls.data_json_filename = "data.json"

        # Generate data
        n_points = 100
        # Use default prefixes defined in optiscope.io.base.TabularFormatHandler
        # default_design_var_prefix = "x:"
        # default_objective_prefix = "f:"
        data = {
            "f:objective_0": np.random.uniform(100, 500, n_points),
            "f:objective_1": np.random.uniform(10, 50, n_points),
            "f:objective_2": np.random.uniform(0.5, 0.95, n_points),
            "x:design_var_0": np.random.uniform(1, 10, n_points),
            "x:design_var_1": np.random.uniform(1, 10, n_points),
            "x:design_var_2": np.random.uniform(1, 10, n_points),
        }
        df = pd.DataFrame(data)

        # Save as CSV
        df.to_csv(cls.csv_filename, index=False)
        df.to_csv(cls.data_csv_filename, index=False)

        # Save as JSON (using Optiscope's save_results to ensure correct format)
        # First load it as a result to save it properly
        result = load_results(cls.csv_filename)
        save_results(result, cls.json_filename)
        save_results(result, cls.data_json_filename)

    @classmethod
    def tearDownClass(cls):
        # Clean up files
        files_to_remove = [
            cls.csv_filename,
            cls.json_filename,
            cls.data_csv_filename,
            cls.data_json_filename,
            "pareto_front.html",
            "analysis_results.html",
            "my_results.json",
            "parallel_coordinates.html",
            "my_plot.html",
            "my_plot.png",
            "analyzed_results.csv",
            "results_with_sets.csv",
        ]
        for f in files_to_remove:
            if os.path.exists(f):
                os.remove(f)

        if os.path.exists("results"):
            shutil.rmtree("results")

    @patch("plotly.graph_objects.Figure.show")
    @patch("plotly.graph_objects.Figure.write_html")
    @patch("plotly.graph_objects.Figure.write_image")
    def test_quickstart_example(self, mock_write_image, mock_write_html, mock_show):
        # Test code from quickstart.md

        # Step 1: Load Data
        result = load_results(self.csv_filename)

        # Step 2: Visualize
        fig = plot_pareto_front_2d(
            result,
            obj_x="objective_0",
            obj_y="objective_1",
            show_dominated=True,
            show_ideal_nadir=True,
        )
        fig.show()

        # Step 3: Analyze
        pareto_indices = smart_pareto_filter(
            result.objectives[["objective_0", "objective_1"]], epsilon=0.15
        )
        result.create_set("pareto", pareto_indices, "smart_filter")

        pareto_objectives = result.objectives[["objective_0", "objective_1"]].iloc[pareto_indices]
        knee_indices = detect_knee_points(pareto_objectives, method="angle", n_knees=3)
        knee_original = pareto_indices[knee_indices]
        result.create_set("knees", knee_original, "knee_detection")

        # Step 4: Make Decisions
        topsis_from_result(
            result,
            weights={"objective_0": 0.5, "objective_1": 0.3, "objective_2": 0.2},
            subset_name="pareto",
        )

        # Complete Example
        # 1. Load data
        result = load_results(self.csv_filename)

        # 2. Filter to representative points
        pareto_indices = smart_pareto_filter(
            result.objectives[["objective_0", "objective_1"]], epsilon=0.15
        )
        result.create_set("pareto", pareto_indices, "smart_filter")

        # 3. Find knee points
        pareto_obj = result.objectives[["objective_0", "objective_1"]].iloc[pareto_indices]
        knee_indices = detect_knee_points(pareto_obj, method="angle", n_knees=3)
        result.create_set("knees", pareto_indices[knee_indices], "knee_detection")

        # 4. Visualize everything
        fig = plot_pareto_front_2d(
            result,
            obj_x="objective_0",
            obj_y="objective_1",
            pareto_set="pareto",
            additional_sets=["knees"],
            show_dominated=True,
            show_ideal_nadir=True,
        )
        fig.write_html("analysis_results.html")

        # 5. Rank with TOPSIS
        topsis_from_result(
            result,
            weights={"objective_0": 0.5, "objective_1": 0.3, "objective_2": 0.2},
            subset_name="pareto",
        )

    @patch("plotly.graph_objects.Figure.show")
    def test_library_usage_loading(self, mock_show):
        # Test loading examples from library_usage.md

        # Load from CSV
        csv_handler = CSVHandler()
        result = csv_handler.read(self.csv_filename)

        # Load from JSON
        json_handler = JSONHandler()
        result = json_handler.read(self.json_filename)

        # Quick Example from library_usage.md (fixing the load_result typo)
        result = load_results(self.csv_filename)

        pareto_mask = identify_pareto_front(
            objectives=result.objectives, directions=result.optimization_directions
        )

        topsis(
            objectives=result.objectives[pareto_mask],
            weights=[0.4, 0.3, 0.3],
            directions=result.optimization_directions,
        )

        fig = plot_parallel_coordinates(result)
        fig.show()

    def test_library_usage_result_sets(self):
        # Test Result Sets examples
        result = load_results(self.csv_filename)

        custom_set = ResultSet(
            name="high_efficiency",
            indices=[0, 5, 10, 15],
            created_by="manual_selection",
            description="Solutions with efficiency > 0.8",
        )

        result.add_set(custom_set)

    def test_library_usage_analysis(self):
        # Test Analysis Tools examples
        result = load_results(self.csv_filename)

        # Pareto Front Identification
        pareto_mask = identify_pareto_front(
            objectives=result.objectives, directions=result.optimization_directions
        )

        pareto_set = ResultSet(
            name="pareto_front",
            indices=np.where(pareto_mask)[0].tolist(),
            created_by="pareto_analysis",
            description="Non-dominated solutions",
        )
        result.add_set(pareto_set)

        # Smart Pareto Filter
        pareto_indices = np.where(pareto_mask)[0]
        pareto_objectives = result.objectives.iloc[pareto_indices]

        filtered_indices = smart_pareto_filter(
            objectives=pareto_objectives, epsilon=0.05, normalize=True
        )

        filtered_indices_adaptive = adaptive_smart_pareto_filter(
            objectives=pareto_objectives,
            target_reduction=0.5,
            min_points=10,
            max_points=50,
            normalize=True,
        )

        filtered_pareto_set = ResultSet(
            name="filtered_pareto",
            indices=pareto_indices[filtered_indices_adaptive].tolist(),
            created_by="smart_pareto_filter",
            description=f"Representative subset of Pareto front ({len(filtered_indices_adaptive)} points)",
        )
        result.add_set(filtered_pareto_set)

        # TOPSIS
        topsis(
            objectives=result.objectives,
            weights=[0.4, 0.3, 0.3],
            directions=result.optimization_directions,
            normalize_method="vector",
        )

        topsis(
            objectives=result.objectives,
            weights=[0.4, 0.3, 0.3],
            directions=result.optimization_directions,
            return_details=True,
        )

        scenarios = {
            "Cost-focused": np.array([0.6, 0.2, 0.2]),
            "Performance-focused": np.array([0.2, 0.6, 0.2]),
            "Balanced": np.array([0.33, 0.33, 0.34]),
        }

        compare_weight_scenarios(
            objectives=result.objectives,
            weight_scenarios=scenarios,
            directions=result.optimization_directions,
        )

        # Combining Analysis Tools
        # (This part repeats some of the above but follows the example flow)
        pareto_mask = identify_pareto_front(
            objectives=result.objectives, directions=result.optimization_directions
        )
        pareto_indices = np.where(pareto_mask)[0]

        filtered_indices = adaptive_smart_pareto_filter(
            objectives=result.objectives.iloc[pareto_indices],
            target_reduction=0.3,
            min_points=10,
            normalize=True,
        )
        final_indices = pareto_indices[filtered_indices]

        topsis(
            objectives=result.objectives.iloc[final_indices],
            weights=[0.4, 0.3, 0.3],
            directions=result.optimization_directions,
        )

    @patch("plotly.graph_objects.Figure.show")
    @patch("plotly.graph_objects.Figure.write_html")
    @patch("plotly.graph_objects.Figure.write_image")
    def test_library_usage_visualization(self, mock_write_image, mock_write_html, mock_show):
        # Test Visualization examples
        result = load_results(self.csv_filename)

        # Parallel Coordinates
        fig = plot_parallel_coordinates(result)
        fig.show()

        fig = plot_parallel_coordinates(
            result,
            include_design_vars=True,
            include_objectives=True,
            include_constraints=False,
            color_by="objective_0",
            highlight_feasible=True,
            title="Optimization Results - Parallel Coordinates",
        )
        fig.show()

        # Scatter Plot Matrix
        fig = plot_scatter_matrix(result)
        fig.show()

        fig = plot_scatter_matrix(
            result,
            variables=["design_var_0", "design_var_1", "objective_0", "objective_1"],
            color_by="objective_0",
            show_distributions=True,
            title="Scatter Matrix - Key Variables",
        )
        fig.show()

        # Correlation Heatmap
        fig = plot_correlation_heatmap(
            result,
            include_objectives=True,
            include_design_vars=True,
            method="pearson",
            title="Variable Correlations",
        )
        fig.show()

        # Pareto Front Visualization
        # Need to create result sets first as they are used in the example
        pareto_mask = identify_pareto_front(
            objectives=result.objectives, directions=result.optimization_directions
        )
        pareto_set = ResultSet(
            name="pareto_front",
            indices=np.where(pareto_mask)[0].tolist(),
            created_by="pareto_analysis",
            description="Non-dominated solutions",
        )
        result.add_set(pareto_set)

        fig_2d = plot_pareto_front_2d(
            result,
            obj_x=0,
            obj_y=1,
            pareto_set="pareto_front",
            show_dominated=True,
            show_ideal_nadir=True,
            title="Pareto Front - 2D View",
        )
        fig_2d.show()

        fig_3d = plot_pareto_front_3d(
            result,
            obj_x=0,
            obj_y=1,
            obj_z=2,
            pareto_set="pareto_front",
            show_surface=True,
            title="Pareto Front - 3D View",
        )
        fig_3d.show()

        # Optimization History Plots
        figs = plot_optimization_history(
            result,
            variables=None,
            objectives=None,
            constraints=None,
            show_markers=True,
            show_feasibility=True,
        )
        for category, fig in figs.items():
            fig.show()

        fig_objectives = plot_time_series(
            result,
            columns=["objective_0", "objective_1"],
            data_attr="objectives",
            title="Objective Evolution",
            show_markers=True,
            single_plot=True,
        )
        fig_objectives.show()

        fig_variables = plot_time_series(
            result,
            columns=["design_var_0", "design_var_1", "design_var_2"],
            data_attr="design_vars",
            title="Design Variable Evolution",
            show_markers=False,
            single_plot=False,
        )
        fig_variables.show()

        # Resampled
        fig_resampled = plot_time_series_resampled(
            result,
            columns=["objective_0", "objective_1", "objective_2"],
            data_attr="objectives",
            title="Objective Evolution (Resampled)",
            show_markers=False,
            single_plot=False,
            max_n_samples=1000,
        )
        fig_resampled.show()

    @patch("plotly.graph_objects.Figure.show")
    @patch("plotly.graph_objects.Figure.write_html")
    @patch("plotly.graph_objects.Figure.write_image")
    def test_complete_workflow(self, mock_write_image, mock_write_html, mock_show):
        # Test Complete Example Workflow
        handler = CSVHandler()
        result = handler.read(self.csv_filename)

        pareto_mask = identify_pareto_front(
            objectives=result.objectives, directions=result.optimization_directions
        )
        pareto_indices = np.where(pareto_mask)[0]

        filtered_indices = adaptive_smart_pareto_filter(
            objectives=result.objectives.iloc[pareto_indices],
            target_reduction=0.3,
            min_points=10,
            normalize=True,
        )
        final_indices = pareto_indices[filtered_indices]

        weights = [0.4, 0.3, 0.3]
        scores = topsis(
            objectives=result.objectives.iloc[final_indices],
            weights=weights,
            directions=result.optimization_directions,
        )
        best_idx = final_indices[np.argmax(scores)]

        result.add_set(
            ResultSet(
                name="pareto_front",
                indices=pareto_indices.tolist(),
                created_by="analysis",
                description="All Pareto-optimal solutions",
            )
        )

        result.add_set(
            ResultSet(
                name="filtered_pareto",
                indices=final_indices.tolist(),
                created_by="smart_pareto_filter",
                description="Representative Pareto subset",
            )
        )

        result.add_set(
            ResultSet(
                name="best_solution",
                indices=[best_idx],
                created_by="topsis",
                description=f"Best solution (TOPSIS score: {scores.max():.3f})",
            )
        )

        fig_parallel = plot_parallel_coordinates(
            result,
            result_sets=["pareto_front", "filtered_pareto", "best_solution"],
            color_by="Set",
            title="Optimization Analysis Results",
        )
        fig_parallel.show()

        fig_pareto = plot_pareto_front_2d(
            result,
            obj_x=0,
            obj_y=1,
            pareto_set="pareto_front",
            additional_sets=["filtered_pareto", "best_solution"],
            title="Pareto Front Analysis",
        )
        fig_pareto.show()

        fig_splom = plot_scatter_matrix(
            result,
            variables=[f"objective_{i}" for i in range(len(result.objectives.columns))],
            result_sets=["filtered_pareto", "best_solution"],
            color_by="Set",
            title="Objective Space Analysis",
        )
        fig_splom.show()

        handler.write(result, "analyzed_results.csv")


if __name__ == "__main__":
    unittest.main()
