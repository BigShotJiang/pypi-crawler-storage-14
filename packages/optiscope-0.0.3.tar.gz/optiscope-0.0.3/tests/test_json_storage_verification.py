"""
Verification script for JSON storage in DatabaseStorage.

This script tests the full cycle of saving and loading OptimizationResult objects
to/from a SQLite database using the JSON storage format. It specifically verifies
that datetime objects and nested Pydantic models are handled correctly during
serialization and deserialization.
"""

import os
import shutil
import tempfile
from datetime import datetime, timedelta

import pandas as pd

from optiscope.core.data_model import OptimizationResult, ProblemMetadata
from optiscope.storage.database import DatabaseStorage


def test_json_storage_verification():
    """Verify JSON storage implementation."""
    print("Starting JSON storage verification...")

    # Create a temporary directory for the database
    temp_dir = tempfile.mkdtemp()
    db_path = os.path.join(temp_dir, "test_storage.db")
    connection_string = f"sqlite:///{db_path}"

    print(f"Using temporary database: {connection_string}")

    try:
        # 1. Initialize storage
        storage = DatabaseStorage(connection_string, dump_as_json=False)

        # 2. Create test data
        print("Creating test OptimizationResult...")

        # Create problem metadata with datetime
        run_date = datetime.now()
        metadata = ProblemMetadata(
            name="Test Problem",
            description="A test problem for verification",
            n_design_variables=2,
            n_objectives=2,
            run_date=run_date,
            metadata={"custom_key": "custom_value"},
        )

        # Create some data
        data = pd.DataFrame(
            {
                "x1": [1.0, 2.0, 3.0],
                "x2": [4.0, 5.0, 6.0],
                "obj1": [10.0, 20.0, 30.0],
                "obj2": [100.0, 200.0, 300.0],
            }
        )

        # Create result object
        result = OptimizationResult(
            problem_metadata=metadata,
            design_variables=data[["x1", "x2"]],
            objectives=data[["obj1", "obj2"]],
        )

        # Add a result set
        print("Adding a ResultSet...")
        set_indices = [0, 2]
        set_created_at = datetime.now() - timedelta(hours=1)

        result_set = result.create_set(
            name="Test Set",
            indices=set_indices,
            created_by="verification_script",
            description="A test set",
        )
        # Manually set created_at to test serialization of specific time
        result_set.created_at = set_created_at

        # Add an operation with timestamp
        op_time = datetime.now()
        result_set.add_operation(
            operation="manual_creation",
            parameters={"indices": set_indices},
            description="Manually created for test",
        )
        # Hack to set the timestamp of the last operation
        result_set.operations[-1].timestamp = op_time

        # 3. Save to database
        print("Saving result to database...")
        key = "test_run_001"
        storage.save_result(key, result)

        # 4. Load from database
        print("Loading result from database...")
        loaded_result = storage.load_result(key)

        # 5. Verify data integrity
        print("Verifying loaded data...")

        # Check metadata
        assert loaded_result.problem_metadata.name == metadata.name
        # Note: Pydantic's isoformat might lose microsecond precision or format slightly differently depending on configuration
        # We compare isoformat strings or accept slight differences if needed.
        # Here we expect Pydantic to handle ISO format roundtrip correctly.
        print(f"Original run_date: {metadata.run_date}")
        print(f"Loaded run_date:   {loaded_result.problem_metadata.run_date}")
        assert loaded_result.problem_metadata.run_date == metadata.run_date

        # Check dataframes
        # Convert to pandas for easy comparison
        # check_dtype=False is required because JSON roundtrip might change int-like floats to ints
        pd.testing.assert_frame_equal(
            loaded_result.design_variables,
            result.design_variables,
            # check_dtype=False
        )

        pd.testing.assert_frame_equal(
            loaded_result.objectives,
            result.objectives,
            # check_dtype=False
        )

        # Check result sets
        loaded_set = loaded_result.get_set("Test Set")
        assert loaded_set.name == "Test Set"
        assert loaded_set.indices == set_indices
        assert loaded_set.created_by == "verification_script"

        print(f"Original set created_at: {set_created_at}")
        print(f"Loaded set created_at:   {loaded_set.created_at}")
        assert loaded_set.created_at == set_created_at

        # Check operations
        assert len(loaded_set.operations) == 1
        loaded_op = loaded_set.operations[0]
        assert loaded_op.operation == "manual_creation"

        print(f"Original op timestamp: {op_time}")
        print(f"Loaded op timestamp:   {loaded_op.timestamp}")
        assert loaded_op.timestamp == op_time

        print("\nSUCCESS: All verification checks passed!")

    except Exception as e:
        print(f"\nFAILURE: Verification failed with error: {e}")
        import traceback

        traceback.print_exc()
        raise e

    finally:
        # Cleanup
        if hasattr(storage, "close"):
            storage.close()
        shutil.rmtree(temp_dir)
        print("Cleanup complete.")
