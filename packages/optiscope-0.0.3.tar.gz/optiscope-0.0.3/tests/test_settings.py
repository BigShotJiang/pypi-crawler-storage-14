"""Test script for settings system."""

import sys
from pathlib import Path

# Add project root to path
sys.path.insert(0, str(Path(__file__).parent))

from optiscope.dash_app.core.settings_manager import SettingsManager
from optiscope.dash_app.core.settings_schema import SETTINGS_SCHEMA, get_default_settings


def test_default_settings():
    """Test getting default settings."""
    print("Testing default settings...")
    settings = get_default_settings()
    print(f"✓ Default settings loaded: {settings.model_dump()}")
    print(f"✓ Version: {settings.version}")
    print(f"✓ Theme: {settings.theme}")
    print()


def test_settings_schema():
    """Test settings schema."""
    print("Testing settings schema...")
    print(f"✓ Total settings: {len(SETTINGS_SCHEMA)}")
    for setting in SETTINGS_SCHEMA:
        print(f"  - {setting.key} ({setting.type.value}): {setting.label}")
    print()


def test_settings_manager_local():
    """Test settings manager in local mode."""
    print("Testing settings manager (local mode)...")
    manager = SettingsManager(app_mode="local")

    # Test get setting
    theme = manager.get_setting("theme")
    print(f"✓ Current theme: {theme}")

    # Test update setting
    manager.update_setting("theme", "dark")
    print(f"✓ Updated theme to: {manager.get_setting('theme')}")

    # Test save
    manager.save_settings()
    print("✓ Settings saved to file")

    # Test export
    json_str = manager.export_settings()
    print(f"✓ Exported settings (length: {len(json_str)} chars)")

    # Test import
    success, message = manager.import_settings(json_str)
    print(f"✓ Import result: {success} - {message}")

    # Reset to defaults
    manager.reset_to_defaults()
    print(f"✓ Reset to defaults, theme is now: {manager.get_setting('theme')}")
    print()


def test_settings_manager_deployed():
    """Test settings manager in deployed mode."""
    print("Testing settings manager (deployed mode)...")
    manager = SettingsManager(app_mode="deployed")

    # Test loading from dict
    test_settings = {
        "version": "0.0.2",
        "theme": "dark",
        "language": "en",
        "auto_save": False,
        "page_size": 100,
        "show_tooltips": False,
        "plot_animation": False,
        "decimal_places": 5,
    }

    manager.load_settings(test_settings)
    print("✓ Loaded settings from dict")
    print(f"✓ Theme: {manager.get_setting('theme')}")
    print(f"✓ Page size: {manager.get_setting('page_size')}")

    # Test save (returns dict in deployed mode)
    manager.save_settings()
    print("✓ Saved settings (deployed mode returns dict)")
    print()


if __name__ == "__main__":
    print("=" * 60)
    print("Settings System Test")
    print("=" * 60)
    print()

    try:
        test_default_settings()
        test_settings_schema()
        test_settings_manager_local()
        test_settings_manager_deployed()

        print("=" * 60)
        print("✓ All tests passed!")
        print("=" * 60)

    except Exception as e:
        print(f"\n✗ Test failed with error: {e}")
        import traceback

        traceback.print_exc()
        sys.exit(1)
