<div align="center">
  <img src="docs/assets/logo.svg" alt="Optiscope Logo" width="150">
</div>

<p align="center">
  A Python library and modular Dash application for visualizing and analyzing single- and multi-objective optimization results with multi-criteria decision making (MCDA) support.
</p>

<p align="center">
  <a href="https://github.com/simaosr/optiscope/actions/workflows/ci.yml">
    <img src="https://github.com/simaosr/optiscope/actions/workflows/ci.yml/badge.svg" alt="CI Status">
  </a>
  <a href="https://codecov.io/gh/simaosr/optiscope">
    <img src="https://codecov.io/gh/simaosr/optiscope/branch/main/graph/badge.svg" alt="Coverage">
  </a>
  <a href="https://www.python.org/downloads/">
    <img src="https://img.shields.io/badge/python-3.9%20|%203.10%20|%203.11%20|%203.12-blue" alt="Python Versions">
  </a>
  <a href="LICENSE">
    <img src="https://img.shields.io/badge/license-MIT-green.svg" alt="License">
  </a>
  <a href="https://optiscope.readthedocs.io">
    <img src="https://img.shields.io/badge/docs-latest-blue.svg" alt="Documentation">
  </a>
</p>

> [!IMPORTANT]  
> Optiscope is in a beta phase, so expect breaking changes and that some features may not work as expected. All suggestions and contributions are welcome!

## Why Optiscope?

Modern optimization workflows often generate vast amounts of data that can be challenging to explore and understand. Optiscope tries to provides a unified and extensible platform to:

- **Visualize** complex, high-dimensional optimization data through interactive plots.
- **Analyze** results to uncover trade-offs, identify Pareto fronts, and detect patterns.
- **Compare** different optimization runs or subsets of data.
- **Decide** on the best solutions using integrated multi-criteria decision analysis (MCDA) tools.

Whether you're an engineer, researcher, or data scientist, Optiscope helps you turn optimization results into actionable insights.

## Features

**Solver-Agnostic**: Import results from multiple file formats.

**Rich Data Model**: Support for design variables, objectives, constraints, and more.

**Result Sets**: Create and manage named subsets of data for focused analysis.

**Flexible Storage**: Multiple storage backends (memory, filesystem, database).

**Extensible**: Easy to add new data types, analysis modules and file format handlers.

**Modern UI**: A modular Dash application built with dash-mantine-components.

## Installation

```bash
pip install .
```

For a development installation, which includes tools for testing and documentation, run:

```bash
pip install -e .[dev]
```

## Quick Start

### Standalone Library Usage

```python
from optiscope import load_results

# Load results from a file (format is auto-detected)
result = load_results("path/to/your/optimization_output.csv")

# Access your data
print(f"Loaded {result.n_points} solutions")
print(f"Objectives: {result.objectives.columns.tolist()}")

# Create a subset of your results
pareto_indices = [0, 5, 12, 23, 45]  # Replace with your Pareto detection logic
pareto_set = result.create_set("pareto_front", pareto_indices)

# Get data for the new set
pareto_data = result.get_set_data("pareto_front")
```

### Running the Dash App

```bash
python -m optiscope.app
```

Then, open your browser to `http://0.0.0.0:8050`.

## Contributing

Contributions are welcome! Please see our [Contributing Guide](CONTRIBUTING.md) for more details on how to get started.

## License

This project is licensed under the MIT License. See the [LICENSE](LICENSE) file for details.
