import argparse
import multiprocessing
import os
import platform
import signal
import threading
import time
from multiprocessing import Condition, Process

import setproctitle
import webview

from optiscope.dash_app.app import run_server  # <<< UPDATE THIS IMPORT


def join_process_and_terminate(process: multiprocessing.process.BaseProcess):
    """
    Whenever the given process exits, send SIGTERM to self.
    This function is synchronous; for async usage see the other two.
    """
    process.join()
    # sys.exit() raises, killing only the current thread
    # os._exit() is private, and also doesn't allow the thread to gracefully exit
    os.kill(os.getpid(), signal.SIGTERM)


def terminate_when_process_dies(process: multiprocessing.process.BaseProcess):
    """
    Whenever the given process exits, send SIGTERM to self.
    This function is asynchronous.
    """
    threading.Thread(target=join_process_and_terminate, args=(process,)).start()


def terminate_when_parent_process_dies():
    """
    Whenever the parent process exits, send SIGTERM to self.
    This function is asynchronous.
    """
    terminate_when_process_dies(multiprocessing.parent_process())


def start_dash(host: str, port: int, debug: bool, app_mode: str, server_is_started: Condition):
    # Set the process title.
    setproctitle.setproctitle("optiscope-dash")
    # When the parent dies, follow along.
    terminate_when_parent_process_dies()

    with server_is_started:
        server_is_started.notify()

    # debug cannot be True right now with nuitka: https://github.com/Nuitka/Nuitka/issues/2953
    run_server(debug=debug, host=host, port=port, app_mode=app_mode)


def run_desktop_mode(host, port, debug, app_mode):
    """Run Dash in main thread and open PyWebView window once ready."""

    # Set memory flags
    system = platform.system()
    if system == "Windows":
        os.environ["WEBVIEW2_ADDITIONAL_BROWSER_ARGUMENTS"] = "--js-flags=--max-old-space-size=8192"
    elif system == "Linux":
        os.environ["QTWEBENGINE_CHROMIUM_FLAGS"] = (
            "--js-flags=--max-old-space-size=8192 --disable-dev-shm-usage"
        )

    server_is_started = Condition()

    # Set the process title.
    setproctitle.setproctitle("optiscope-webview")

    # Spawn the dash process.
    p = Process(target=start_dash, args=(host, port, debug, app_mode, server_is_started))
    p.start()
    # If the dash process dies, follow along.
    terminate_when_process_dies(p)

    # Wait until dash process is ready.
    with server_is_started:
        server_is_started.wait()
    # FIXME this should not be needed, if server_is_started was triggered after app runs.
    #  idk if that is possible.
    time.sleep(0.2)

    # Create the webview.
    webview.settings["ALLOW_DOWNLOADS"] = True
    webview.create_window("Optiscope", f"http://{host}:{port}", maximized=True, confirm_close=True)
    webview.start(debug=debug)

    # Reached when window is closed.
    p.terminate()
    exit(0)


def main():
    parser = argparse.ArgumentParser(description="Run the Dash app (local or desktop mode).")
    parser.add_argument("--debug", action="store_true", help="Run the app in debug mode")
    parser.add_argument("--host", type=str, default="127.0.0.1", help="Host")
    parser.add_argument("--port", type=int, default=8050, help="Port")
    parser.add_argument(
        "--mode",
        type=str,
        default="local",
        choices=["local", "desktop", "deployed"],
        help="Application mode",
    )
    args = parser.parse_args()

    if args.mode == "desktop":
        run_desktop_mode(args.host, args.port, args.debug, app_mode=args.mode)
    else:
        # Old simple way
        run_server(debug=args.debug, host=args.host, port=args.port, app_mode=args.mode)


if __name__ == "__main__":
    main()
