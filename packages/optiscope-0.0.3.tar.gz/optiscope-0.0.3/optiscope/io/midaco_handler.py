"""
MIDACO file format handler.

MIDACO is a solver for mixed-integer optimization. It outputs results in
two file formats:
- SOLUTION.TXT: Complete history of solutions evaluated
- PARETO.TXT: Pareto front approximation (for multi-objective problems)

File Format:
- Header lines start with #
- First data line: O (objectives), M (constraints), N (design vars), [PSIZE]
- Following lines: F(1:O) G(1:M) X(1:N) values space-separated
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd

from optiscope.core.data_model import OptimizationResult, ProblemMetadata
from optiscope.core.data_types import Constraint, DesignVariable, Objective
from optiscope.io.base import FormatReadError, FormatWriteError, TabularFormatHandler


class MIDACoHandler(TabularFormatHandler):
    """
    Handler for MIDACO solution files.

    Supports both SOLUTION.TXT (history) and PARETO.TXT (Pareto front) formats.
    """

    format_name = "MIDACO"
    file_extensions = [".txt"]
    priority = 15  # Check after JSON but before generic text

    @classmethod
    def can_handle(cls, filepath: Path) -> bool:
        """Check if file is a MIDACO format."""
        if filepath.suffix.lower() != ".txt":
            return False

        # Check for MIDACO-specific markers
        try:
            with open(filepath) as f:
                content = f.read(500)  # Read first 500 chars

                # Look for MIDACO-specific header patterns
                if any(
                    marker in content
                    for marker in [
                        "SOLUTION HISTORY",
                        "pareto front approximation",
                        "MIDACO solution",
                    ]
                ):
                    return True

                # Check for O M N pattern
                lines = content.split("\n")
                for line in lines:
                    if line.strip() and not line.strip().startswith("#"):
                        # Should be O M N [PSIZE] line
                        parts = line.split()
                        if len(parts) >= 3:
                            try:
                                # Try to parse as integers
                                int(parts[0]), int(parts[1]), int(parts[2])
                                return True
                            except ValueError:
                                pass
                        break
        except Exception:
            return False

        return False

    def read(self, filepath: Path, parse_pareto: bool = True, **kwargs: Any) -> OptimizationResult:
        """
        Read MIDACO solution file.

        Args:
            filepath: Path to MIDACO file (SOLUTION.TXT or PARETO.TXT)
            parse_pareto: If True and this is PARETO.TXT, automatically create
                         'pareto' and 'midaco_best' result sets
            **kwargs: Additional arguments (unused)

        Returns:
            OptimizationResult object
        """
        try:
            with open(filepath) as f:
                lines = f.readlines()

            # Parse header to determine file type and dimensions
            file_type, n_obj, n_const, n_vars, psize = self._parse_header(lines)

            # Extract data lines (non-comment, non-empty)
            data_lines = []
            for line in lines:
                stripped = line.strip()
                if stripped and not stripped.startswith("#"):
                    # Skip dimension line (O M N [PSIZE])
                    parts = stripped.split()
                    if len(parts) == n_obj + n_const + n_vars:
                        try:
                            values = [float(x) for x in parts]
                            data_lines.append(values)
                        except ValueError:
                            continue

            if not data_lines:
                raise FormatReadError("No valid data lines found in MIDACO file")

            # Convert to numpy array
            data = np.array(data_lines)
            n_points = len(data)

            # Split into objectives, constraints, design variables
            idx = 0

            # Objectives F(1:O)
            objectives_data = data[:, idx : idx + n_obj]
            idx += n_obj

            # Constraints G(1:M)
            if n_const > 0:
                constraints_data = data[:, idx : idx + n_const]
                idx += n_const
            else:
                constraints_data = None

            # Design variables X(1:N)
            design_vars_data = data[:, idx : idx + n_vars]

            # Create DataFrames with proper column names
            obj_names = [f"f{i + 1}" for i in range(n_obj)]
            var_names = [f"x{i + 1}" for i in range(n_vars)]

            objectives_df = pd.DataFrame(objectives_data, columns=obj_names)
            design_vars_df = pd.DataFrame(design_vars_data, columns=var_names)

            # MIDACO constraints are inequality (g(x) <= 0)
            if constraints_data is not None:
                const_names = [f"g{i + 1}" for i in range(n_const)]
                constraints_df = pd.DataFrame(constraints_data, columns=const_names)
            else:
                constraints_df = pd.DataFrame()

            # Create problem metadata
            problem_metadata = ProblemMetadata(
                name=f"MIDACO {file_type}",
                description=f"Loaded from {filepath.name}",
                solver="MIDACO",
                n_design_variables=n_vars,
                n_objectives=n_obj,
                n_inequality_constraints=n_const,
                n_equality_constraints=0,
                n_evaluations=n_points,
                metadata={"file_type": file_type, "source_file": filepath.name, "psize": psize},
            )  # type: ignore

            # Create result
            result = OptimizationResult(
                problem_metadata=problem_metadata,
                design_variables=design_vars_df,
                objectives=objectives_df,
                inequality_constraints=constraints_df,
                equality_constraints=pd.DataFrame(),
            )

            # Add variable metadata
            for i, name in enumerate(obj_names):
                result.add_variable_metadata(
                    Objective(name=name, description=f"Objective {i + 1} from MIDACO")  # type: ignore
                )

            for i, name in enumerate(var_names):
                result.add_variable_metadata(
                    DesignVariable(name=name, description=f"Design variable {i + 1} from MIDACO")  # type: ignore
                )

            for i, name in enumerate(const_names) if constraints_data is not None else []:
                result.add_variable_metadata(
                    Constraint(name=name, description=f"Inequality constraint {i + 1} (g <= 0)")  # type: ignore
                )

            # For PARETO.TXT files, create result sets
            if parse_pareto and file_type == "PARETO":
                # First solution is the MIDACO solution (best found)
                result.create_set(
                    name="midaco_best",
                    indices=[0],
                    created_by="midaco_import",
                    description="Best solution found by MIDACO",
                    color="#FF6B6B",
                )

                # All other solutions are the Pareto front approximation
                if n_points > 1:
                    result.create_set(
                        name="pareto_front",
                        indices=list(range(1, n_points)),
                        created_by="midaco_import",
                        description="Pareto front approximation from MIDACO",
                        color="#4ECDC4",
                    )

            return result

        except Exception as e:
            raise FormatReadError(f"Failed to read MIDACO file: {str(e)}") from e

    def _parse_header(self, lines: list[str]) -> tuple[str, int, int, int, int | None]:
        """
        Parse MIDACO file header.

        Returns:
            Tuple of (file_type, n_objectives, n_constraints, n_vars, psize)
        """
        # Determine file type from header
        file_type = "SOLUTION"  # Default
        for line in lines:
            if "pareto front approximation" in line.lower():
                file_type = "PARETO"
                break
            elif "SOLUTION HISTORY" in line:
                file_type = "SOLUTION"
                break

        # Find dimension line (O M N [PSIZE])
        for line in lines:
            stripped = line.strip()
            if stripped and not stripped.startswith("#"):
                parts = stripped.split()
                try:
                    n_obj = int(parts[0])
                    n_const = int(parts[1])
                    n_vars = int(parts[2])
                    psize = int(parts[3]) if len(parts) > 3 else None

                    return file_type, n_obj, n_const, n_vars, psize
                except (ValueError, IndexError):
                    continue

        raise FormatReadError("Could not find dimension line (O M N) in MIDACO file")

    def write(
        self,
        result: OptimizationResult,
        filepath: Path,
        file_type: str = "SOLUTION",
        include_pareto_set: str | None = None,
        **kwargs: Any,
    ) -> None:
        """
        Write optimization results to MIDACO format.

        Args:
            result: OptimizationResult to write
            filepath: Output file path
            file_type: "SOLUTION" for history or "PARETO" for Pareto front
            include_pareto_set: Name of result set to write as Pareto front
                               (only used if file_type="PARETO")
            **kwargs: Additional arguments (unused)
        """
        try:
            n_obj = len(result.objectives.columns)
            n_const = len(result.inequality_constraints.columns)
            n_vars = len(result.design_variables.columns)
            n_points = result.n_points

            with open(filepath, "w") as f:
                # Write header
                if file_type == "SOLUTION":
                    f.write("###################################################\n")
                    f.write("### This file contains the history of solutions ###\n")
                    f.write("###################################################\n")
                    f.write("### SOLUTION FORMAT:  F(1:O)  G(1:M)  X(1:N)    ###\n")
                    f.write("###################################################\n")
                else:  # PARETO
                    f.write("#########################################################\n")
                    f.write("### This file contains the pareto front approximation ###\n")
                    f.write("#########################################################\n")
                    f.write("### Solution format:     F(1:O)    G(1:M)    X(1:N)   ###\n")
                    f.write("#########################################################\n")

                f.write("#                              \n")
                if file_type == "SOLUTION":
                    f.write("#        O         M         N \n")
                else:
                    f.write("#        O         M         N     PSIZE\n")
                f.write("#                              \n")

                # Write dimensions
                if file_type == "SOLUTION":
                    f.write(f"{n_obj:10d}{n_const:10d}{n_vars:10d}\n")
                else:
                    psize = (
                        n_points
                        if include_pareto_set is None
                        else len(result.get_set(include_pareto_set).indices)
                    )
                    f.write(f"{n_obj:10d}{n_const:10d}{n_vars:10d}{psize:10d}\n")

                f.write("#                       \n")

                # Write data
                if file_type == "SOLUTION":
                    f.write("#        SOLUTION HISTORY (in chronological order)\n")
                    f.write("#                       \n")
                    indices = range(n_points)
                else:  # PARETO
                    if include_pareto_set and include_pareto_set in result.sets:
                        f.write("#                       \n")
                        f.write("#        MIDACO solution\n")
                        f.write("#                       \n")

                        # Write best solution (first point of set)
                        pareto_set = result.get_set(include_pareto_set)
                        best_idx = pareto_set.indices[0]
                        self._write_solution_line(f, result, best_idx)

                        f.write("#                       \n")
                        f.write("#        All non-dominated solutions found by MIDACO\n")
                        f.write("#                       \n")

                        # Write rest of Pareto front
                        indices = pareto_set.indices[1:] if len(pareto_set.indices) > 1 else []
                    else:
                        f.write("#        All solutions\n")
                        f.write("#                       \n")
                        indices = range(n_points)

                # Write solution lines
                for idx in indices:
                    self._write_solution_line(f, result, idx)

        except Exception as e:
            raise FormatWriteError(f"Failed to write MIDACO file: {str(e)}") from e

    def _write_solution_line(self, f, result: OptimizationResult, idx: int) -> None:
        """Write a single solution line in MIDACO format."""
        # Objectives
        for col in result.objectives.columns:
            f.write(f"{result.objectives[col].iloc[idx]:18.7f}")

        # Constraints
        for col in result.inequality_constraints.columns:
            f.write(f"{result.inequality_constraints[col].iloc[idx]:18.7f}")

        # Design variables
        for col in result.design_variables.columns:
            f.write(f"{result.design_variables[col].iloc[idx]:18.7f}")

        f.write("\n")


def read_midaco_pair(
    solution_file: Path, pareto_file: Path
) -> tuple[OptimizationResult, OptimizationResult]:
    """
    Read both SOLUTION.TXT and PARETO.TXT files from MIDACO.

    Convenience function to load both files at once.

    Args:
        solution_file: Path to SOLUTION.TXT
        pareto_file: Path to PARETO.TXT

    Returns:
        Tuple of (solution_history, pareto_front) OptimizationResult objects
    """
    handler = MIDACoHandler()

    solution_result = handler.read(solution_file, parse_pareto=False)
    pareto_result = handler.read(pareto_file, parse_pareto=True)

    return solution_result, pareto_result


def detect_midaco_files(directory: Path) -> dict[str, Path]:
    """
    Detect MIDACO files in a directory.

    Args:
        directory: Directory to search

    Returns:
        Dictionary mapping file types to paths:
        {'SOLUTION': path, 'PARETO': path}
    """
    directory = Path(directory)
    found_files = {}

    # Common MIDACO filenames
    solution_names = ["SOLUTION.TXT", "solution.txt", "SOLUTION.OUT", "solution.out"]
    pareto_names = ["PARETO.TXT", "pareto.txt", "PARETO.OUT", "pareto.out"]

    for name in solution_names:
        filepath = directory / name
        if filepath.exists():
            found_files["SOLUTION"] = filepath
            break

    for name in pareto_names:
        filepath = directory / name
        if filepath.exists():
            found_files["PARETO"] = filepath
            break

    # If not found by common names, search all .txt files
    if "SOLUTION" not in found_files or "PARETO" not in found_files:
        handler = MIDACoHandler()
        for txt_file in directory.glob("*.txt"):
            if handler.can_handle(txt_file):
                with open(txt_file) as f:
                    content = f.read(500)
                    if "pareto front approximation" in content.lower():
                        found_files["PARETO"] = txt_file
                    elif "SOLUTION HISTORY" in content:
                        found_files["SOLUTION"] = txt_file

    return found_files
