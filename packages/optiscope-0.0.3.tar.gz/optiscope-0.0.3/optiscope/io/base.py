"""
Base classes for file format handlers.

This module defines the abstract interface that all file format handlers
must implement, enabling a plug-and-play architecture for supporting
different optimization result file formats.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from pathlib import Path
from typing import Any

import pandas as pd

from optiscope.core.data_model import OptimizationResult, ProblemMetadata


class BaseFormatHandler(ABC):
    """
    Abstract base class for optimization result file format handlers.

    Each format handler must implement methods to:
    - Detect if a file is in their format
    - Read optimization results from files
    - Write optimization results to files
    """

    # Handler metadata
    format_name: str = "Unknown"
    file_extensions: list[str] = []
    priority: int = 10  # Lower priority = checked first

    @classmethod
    @abstractmethod
    def can_handle(cls, filepath: Path) -> bool:
        """
        Check if this handler can read the given file.

        Args:
            filepath: Path to file to check

        Returns:
            True if this handler can read the file
        """
        pass

    @abstractmethod
    def read(self, filepath: Path, **kwargs: Any) -> OptimizationResult:
        """
        Read optimization results from file.

        Args:
            filepath: Path to file to read
            **kwargs: Format-specific options

        Returns:
            OptimizationResult object
        """
        pass

    @abstractmethod
    def write(self, result: OptimizationResult, filepath: Path, **kwargs: Any) -> None:
        """
        Write optimization results to file.

        Args:
            result: OptimizationResult to write
            filepath: Path to output file
            **kwargs: Format-specific options
        """
        pass

    def validate_result(self, result: OptimizationResult) -> None:
        """
        Validate that the result can be written by this handler.

        Args:
            result: OptimizationResult to validate

        Raises:
            ValueError: If result cannot be written
        """
        if result.n_points == 0:
            raise ValueError("Cannot write empty result")

    @staticmethod
    def _infer_data_types(df: pd.DataFrame, prefix: str = "") -> dict[str, Any]:
        """
        Helper to infer basic metadata from DataFrame columns.

        Args:
            df: DataFrame to analyze
            prefix: Prefix for column names

        Returns:
            Dictionary of inferred metadata
        """
        metadata = {}
        for col in df.columns:
            col_name = col.replace(prefix, "") if prefix else col
            metadata[col_name] = {
                "name": col_name,
                "dtype": str(df[col].dtype),
                "min": float(df[col].min()) if pd.api.types.is_numeric_dtype(df[col]) else None,
                "max": float(df[col].max()) if pd.api.types.is_numeric_dtype(df[col]) else None,
                "has_nan": bool(df[col].isna().any()),
            }
        return metadata


class StructuredFormatHandler(BaseFormatHandler):
    """
    Base class for handlers of structured formats with explicit metadata.

    Structured formats (like JSON, YAML, HDF5) can store metadata alongside data,
    making round-trip reading/writing lossless.
    """

    supports_metadata: bool = True
    supports_sets: bool = True

    @abstractmethod
    def read_metadata(self, filepath: Path) -> dict[str, Any]:
        """
        Read just the metadata from file without loading all data.

        Args:
            filepath: Path to file

        Returns:
            Dictionary of metadata
        """
        pass


class TabularFormatHandler(BaseFormatHandler):
    """
    Base class for handlers of tabular formats (CSV, Excel, etc.).

    Tabular formats typically store only data without metadata,
    requiring inference or separate metadata files.
    """

    supports_metadata: bool = False
    supports_sets: bool = False

    # Column naming conventions
    default_design_var_prefix: str = "x:"
    default_objective_prefix: str = "f:"
    default_equality_constraint_prefix: str = "h:"
    default_inequality_constraint_prefix: str = "g:"
    default_observable_prefix: str = "obs:"

    def infer_column_categories(
        self,
        columns: list[str],
        design_var_prefix: str | None = None,
        objective_prefix: str | None = None,
        equality_constraint_prefix: str | None = None,
        inequality_constraint_prefix: str | None = None,
        observable_prefix: str | None = None,
    ) -> tuple[dict[str, list[str]], dict[str, str]]:
        """
        Infer which columns belong to which category based on naming.

        Args:
            columns: List of column names
            design_var_prefix: Prefix for design variables
            objective_prefix: Prefix for objectives
            equality_constraint_prefix: Prefix for constraints
            inequality_constraint_prefix: Prefix for constraints
            observable_prefix: Prefix for observables

        Returns:
            A tuple containing:
            - Dictionary mapping categories to stripped column names
            - Dictionary mapping original column names to stripped column names
        """
        design_var_prefix = design_var_prefix or self.default_design_var_prefix
        objective_prefix = objective_prefix or self.default_objective_prefix
        equality_constraint_prefix = (
            equality_constraint_prefix or self.default_equality_constraint_prefix
        )
        inequality_constraint_prefix = (
            inequality_constraint_prefix or self.default_inequality_constraint_prefix
        )
        observable_prefix = observable_prefix or self.default_observable_prefix

        categorized = {
            "design_variables": [],
            "objectives": [],
            "equality_constraints": [],
            "inequality_constraints": [],
            "observables": [],
            "unknown": [],
        }
        rename_map = {}

        for col in columns:
            col_lower = col.lower()
            if col_lower.startswith(design_var_prefix.lower()):
                new_name = col[len(design_var_prefix) :]
                categorized["design_variables"].append(new_name)
                rename_map[col] = new_name
            elif col_lower.startswith(objective_prefix.lower()):
                new_name = col[len(objective_prefix) :]
                categorized["objectives"].append(new_name)
                rename_map[col] = new_name
            elif col_lower.startswith(equality_constraint_prefix.lower()):
                new_name = col[len(equality_constraint_prefix) :]
                categorized["equality_constraints"].append(new_name)
                rename_map[col] = new_name
            elif col_lower.startswith(inequality_constraint_prefix.lower()):
                new_name = col[len(inequality_constraint_prefix) :]
                categorized["inequality_constraints"].append(new_name)
                rename_map[col] = new_name
            elif col_lower.startswith(observable_prefix.lower()):
                new_name = col[len(observable_prefix) :]
                categorized["observables"].append(new_name)
                rename_map[col] = new_name
            else:
                categorized["unknown"].append(col)
                rename_map[col] = col

        return categorized, rename_map

    def create_default_metadata(
        self, n_points: int, categorized_columns: dict[str, list[str]]
    ) -> ProblemMetadata:
        """
        Create default problem metadata when none is available.

        Args:
            n_points: Number of data points
            categorized_columns: Categorized column names

        Returns:
            ProblemMetadata with inferred values
        """
        return ProblemMetadata(
            name="Imported Data",
            description="Data imported from a tabular file.",
            solver="Unknown",
            solver_version=None,
            n_design_variables=len(categorized_columns.get("design_variables", [])),
            n_objectives=len(categorized_columns.get("objectives", [])),
            n_equality_constraints=len(categorized_columns.get("equality_constraints", [])),
            n_inequality_constraints=len(categorized_columns.get("inequality_constraints", [])),
            computation_time=None,
            n_evaluations=None,
            metadata={
                "n_points": n_points,
                "inferred": True,
                "unknown_columns": categorized_columns.get("unknown", []),
            },
        )


class FormatDetectionError(Exception):
    """Exception raised when file format cannot be detected."""

    pass


class FormatReadError(Exception):
    """Exception raised when file cannot be read."""

    pass


class FormatWriteError(Exception):
    """Exception raised when file cannot be written."""

    pass
