"""
JSON file format handler for optimization results.

Supports reading and writing optimization results in JSON format with
full metadata preservation and support for result sets.
"""

from __future__ import annotations

import json
from datetime import datetime
from pathlib import Path
from typing import Any

import pandas as pd

from optiscope.core.data_model import OptimizationResult, ProblemMetadata
from optiscope.core.data_types import (
    Constraint,
    CustomDataType,
    DataTypeCategory,
    DesignVariable,
    Objective,
    Observable,
)
from optiscope.core.result_set import ResultSet
from optiscope.io.base import FormatReadError, FormatWriteError, StructuredFormatHandler


class JSONHandler(StructuredFormatHandler):
    """
    Handler for JSON files containing optimization results.

    JSON format preserves all metadata, variable information, and result sets.
    This is the recommended format for complete data preservation.
    """

    format_name = "JSON"
    file_extensions = [".json"]
    priority = 5  # High priority (checked early)

    @classmethod
    def can_handle(cls, filepath: Path) -> bool:
        """Check if file is a valid JSON optimization result."""
        if filepath.suffix.lower() != ".json":
            return False

        try:
            with open(filepath) as f:
                data = json.load(f)

            # Check for required structure
            return isinstance(data, dict) and (
                "problem_metadata" in data
                or "design_variables" in data
                or "objectives" in data
                or "inequality_constraints" in data
                or "equality_constraints" in data
            )
        except Exception:
            return False

    def read(self, filepath: Path, **kwargs: Any) -> OptimizationResult:
        """
        Read optimization results from JSON file.

        Args:
            filepath: Path to JSON file
            **kwargs: Unused (for interface compatibility)

        Returns:
            OptimizationResult object
        """
        try:
            with open(filepath) as f:
                data = json.load(f)

            # Parse problem metadata
            problem_metadata = None
            if "problem_metadata" in data:
                meta_dict = data["problem_metadata"]
                # Convert ISO datetime strings
                if "run_date" in meta_dict and isinstance(meta_dict["run_date"], str):
                    meta_dict["run_date"] = datetime.fromisoformat(meta_dict["run_date"])
                problem_metadata = ProblemMetadata(**meta_dict)

            # Parse data sections
            design_vars = self._parse_dataframe(data.get("design_variables", {}))
            objectives = self._parse_dataframe(data.get("objectives", {}))
            inequality_constraints = self._parse_dataframe(data.get("inequality_constraints", {}))
            equality_constraints = self._parse_dataframe(data.get("equality_constraints", {}))
            observables = self._parse_dataframe(data.get("observables", {}))

            # Parse custom data
            custom_data = {}
            if "custom_data" in data:
                for name, df_data in data["custom_data"].items():
                    custom_data[name] = self._parse_dataframe(df_data)

            # Create result
            result = OptimizationResult(
                problem_metadata=problem_metadata,
                design_variables=design_vars,
                objectives=objectives,
                inequality_constraints=inequality_constraints,
                equality_constraints=equality_constraints,
                observables=observables,
                custom_data=custom_data,
            )

            # Parse variable metadata
            if "variable_metadata" in data:
                for var_name, meta_dict in data["variable_metadata"].items():
                    meta = self._parse_variable_metadata(meta_dict)
                    result.add_variable_metadata(meta)

            # Parse result sets
            if "sets" in data:
                for set_name, set_dict in data["sets"].items():
                    result_set = ResultSet.from_dict(set_dict)
                    result._set_manager.add_set(result_set)

            return result

        except json.JSONDecodeError as e:
            raise FormatReadError(f"Invalid JSON: {str(e)}") from e
        except Exception as e:
            raise FormatReadError(f"Failed to read JSON: {str(e)}") from e

    def write(
        self, result: OptimizationResult, filepath: Path, indent: int = 2, **kwargs: Any
    ) -> None:
        """
        Write optimization results to JSON file.

        Args:
            result: OptimizationResult to write
            filepath: Output JSON path
            indent: JSON indentation level
            **kwargs: Unused (for interface compatibility)
        """
        try:
            data = {
                "format_version": "1.0",
                "problem_metadata": result.problem_metadata.model_dump(mode="json"),
            }

            # Add data sections
            if not result.design_variables.empty:
                data["design_variables"] = self._dataframe_to_dict(result.design_variables)

            if not result.objectives.empty:
                data["objectives"] = self._dataframe_to_dict(result.objectives)

            if not result.inequality_constraints.empty:
                data["inequality_constraints"] = self._dataframe_to_dict(
                    result.inequality_constraints
                )

            if not result.equality_constraints.empty:
                data["equality_constraints"] = self._dataframe_to_dict(result.equality_constraints)

            if not result.observables.empty:
                data["observables"] = self._dataframe_to_dict(result.observables)

            # Add custom data
            if result._custom_data:
                data["custom_data"] = {
                    name: self._dataframe_to_dict(df) for name, df in result._custom_data.items()
                }

            # Add variable metadata
            if result._variable_metadata:
                data["variable_metadata"] = {
                    name: meta.model_dump(mode="json")
                    for name, meta in result._variable_metadata.items()
                }

            # Add result sets
            if result.sets:
                data["sets"] = {name: s.to_dict() for name, s in result.sets.items()}

            # Write JSON
            with open(filepath, "w") as f:
                json.dump(data, f, indent=indent, default=str)

        except Exception as e:
            raise FormatWriteError(f"Failed to write JSON: {str(e)}") from e

    def read_metadata(self, filepath: Path) -> dict[str, Any]:
        """
        Read just metadata from JSON file.

        Args:
            filepath: Path to JSON file

        Returns:
            Dictionary containing metadata
        """
        with open(filepath) as f:
            data = json.load(f)

        metadata = {
            "problem_metadata": data.get("problem_metadata", {}),
            "n_points": 0,
            "variables": list(data.get("variable_metadata", {}).keys()),
            "sets": list(data.get("sets", {}).keys()),
        }

        # Count points from any available data
        for key in [
            "design_variables",
            "objectives",
            "inequality_constraints",
            "equality_constraints",
            "observables",
        ]:
            if key in data and "data" in data[key]:
                metadata["n_points"] = len(data[key]["data"])
                break

        return metadata

    @staticmethod
    def _parse_dataframe(data: dict[str, Any]) -> pd.DataFrame:
        """Parse DataFrame from dictionary format."""
        if not data:
            return pd.DataFrame()

        # Support multiple formats
        if "data" in data and "columns" in data:
            # Column-oriented format
            return pd.DataFrame(data["data"], columns=data["columns"])
        elif "records" in data:
            # Record-oriented format
            return pd.DataFrame.from_records(data["records"])
        else:
            # Direct dictionary format
            return pd.DataFrame(data)

    @staticmethod
    def _dataframe_to_dict(df: pd.DataFrame) -> dict[str, Any]:
        """Convert DataFrame to dictionary format."""
        return {
            "columns": df.columns.tolist(),
            "data": df.values.tolist(),
            "dtypes": {col: str(dtype) for col, dtype in df.dtypes.items()},
        }

    @staticmethod
    def _parse_variable_metadata(meta_dict: dict[str, Any]):
        """Parse variable metadata from dictionary."""
        category = meta_dict.get("category", DataTypeCategory.CUSTOM)

        if category == DataTypeCategory.DESIGN_VARIABLE:
            return DesignVariable(**meta_dict)
        elif category == DataTypeCategory.OBJECTIVE:
            return Objective(**meta_dict)
        elif category == DataTypeCategory.CONSTRAINT:
            return Constraint(**meta_dict)
        elif category == DataTypeCategory.OBSERVABLE:
            return Observable(**meta_dict)
        else:
            return CustomDataType(**meta_dict)
