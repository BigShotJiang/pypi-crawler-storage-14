"""
CSV file format handler for optimization results.

Supports reading and writing optimization results in CSV format with
configurable column naming conventions and optional metadata sidecar files.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import pandas as pd

from optiscope.core.data_model import OptimizationResult, ProblemMetadata
from optiscope.core.data_types import (
    Constraint,
    ConstraintType,
    DesignVariable,
    Objective,
    Observable,
)
from optiscope.io.base import FormatReadError, FormatWriteError, TabularFormatHandler


class CSVHandler(TabularFormatHandler):
    """
    Handler for CSV files containing optimization results.

    CSV files can be read with automatic column categorization based on naming
    conventions. Metadata can be stored in a separate JSON sidecar file.
    """

    format_name = "CSV"
    file_extensions = [".csv"]
    priority = 20  # Lower priority than structured formats

    @classmethod
    def can_handle(cls, filepath: Path) -> bool:
        """Check if file is a CSV."""
        if filepath.suffix.lower() != ".csv":
            return False

        try:
            # Try to read first few lines
            pd.read_csv(filepath, nrows=5)
            return True
        except Exception:
            return False

    def read(
        self,
        filepath: Path,
        design_var_prefix: str | None = None,
        objective_prefix: str | None = None,
        inequality_constraint_prefix: str | None = None,
        equality_constraint_prefix: str | None = None,
        observable_prefix: str | None = None,
        metadata_file: Path | None = None,
        **kwargs: Any,
    ) -> OptimizationResult:
        """
        Read optimization results from CSV file.

        Args:
            filepath: Path to CSV file
            design_var_prefix: Prefix for design variable columns
            objective_prefix: Prefix for objective columns
            inequality_constraint_prefix: Prefix for inequality constraint columns (g(x) <= 0)
            equality_constraint_prefix: Prefix for equality constraint columns (h(x) = 0)
            observable_prefix: Prefix for observable columns
            metadata_file: Optional path to metadata JSON file
            **kwargs: Additional arguments passed to pd.read_csv

        Returns:
            OptimizationResult object
        """
        try:
            # Read CSV
            df = pd.read_csv(filepath, **kwargs)

            if df.empty:
                raise FormatReadError("CSV file is empty")

            # Categorize columns
            categorized, rename_map = self.infer_column_categories(
                df.columns.tolist(),
                design_var_prefix,
                objective_prefix,
                inequality_constraint_prefix,
                equality_constraint_prefix,
                observable_prefix,
            )

            # Rename columns to strip prefixes
            df.rename(columns=rename_map, inplace=True)

            # Extract data by category
            design_vars = (
                df[categorized["design_variables"]]
                if categorized["design_variables"]
                else pd.DataFrame()
            )
            objectives = (
                df[categorized["objectives"]] if categorized["objectives"] else pd.DataFrame()
            )
            inequality_constraints = (
                df[categorized["inequality_constraints"]]
                if categorized["inequality_constraints"]
                else pd.DataFrame()
            )
            equality_constraints = (
                df[categorized["equality_constraints"]]
                if categorized["equality_constraints"]
                else pd.DataFrame()
            )
            observables = (
                df[categorized["observables"]] if categorized["observables"] else pd.DataFrame()
            )

            # Handle unknown columns as observables
            unknown_df = df[categorized["unknown"]] if categorized["unknown"] else pd.DataFrame()
            if not unknown_df.empty:
                observables = pd.concat([observables, unknown_df], axis=1)

            # Load or create metadata
            if metadata_file and metadata_file.exists():
                problem_metadata = self._load_metadata_file(metadata_file)
            else:
                # Check for sidecar metadata file
                sidecar_path = Path(filepath).with_suffix(".meta.json")
                if sidecar_path.exists():
                    problem_metadata = self._load_metadata_file(sidecar_path)
                else:
                    problem_metadata = self.create_default_metadata(len(df), categorized)

            # Create result
            result = OptimizationResult(
                problem_metadata=problem_metadata,
                design_variables=design_vars,
                objectives=objectives,
                inequality_constraints=inequality_constraints,
                equality_constraints=equality_constraints,
                observables=observables,
            )

            # Add basic metadata for variables
            self._add_inferred_metadata(result, categorized)

            return result

        except pd.errors.EmptyDataError:
            raise FormatReadError("CSV file is empty or malformed")
        except Exception as e:
            raise FormatReadError(f"Failed to read CSV: {str(e)}") from e

    def write(
        self,
        result: OptimizationResult,
        filepath: Path,
        include_metadata: bool = True,
        **kwargs: Any,
    ) -> None:
        """
        Write optimization results to CSV file.

        Args:
            result: OptimizationResult to write
            filepath: Output CSV path
            include_metadata: Whether to write metadata sidecar file
            **kwargs: Additional arguments passed to pd.to_csv
        """
        try:
            # Combine all data
            data_frames = []

            if not result.design_variables.empty:
                data_frames.append(result.design_variables)
            if not result.objectives.empty:
                data_frames.append(result.objectives)
            if not result.inequality_constraints.empty:
                data_frames.append(result.inequality_constraints)
            if not result.equality_constraints.empty:
                data_frames.append(result.equality_constraints)
            if not result.observables.empty:
                data_frames.append(result.observables)

            if not data_frames:
                raise FormatWriteError("No data to write")

            df = pd.concat(data_frames, axis=1)

            # Write CSV
            df.to_csv(filepath, index=False, **kwargs)

            # Write metadata sidecar if requested
            if include_metadata:
                metadata_path = Path(filepath).with_suffix(".meta.json")
                self._write_metadata_file(result, metadata_path)

        except Exception as e:
            raise FormatWriteError(f"Failed to write CSV: {str(e)}") from e

    def _load_metadata_file(self, filepath: Path) -> ProblemMetadata:
        """Load metadata from JSON file."""
        with open(filepath) as f:
            data = json.load(f)
        return ProblemMetadata(**data)

    def _write_metadata_file(self, result: OptimizationResult, filepath: Path) -> None:
        """Write metadata to JSON file."""
        metadata_dict = result.problem_metadata.model_dump(mode="json")

        # Add variable metadata
        metadata_dict["variables"] = {}
        for name, meta in result._variable_metadata.items():
            metadata_dict["variables"][name] = meta.model_dump(mode="json")

        # Add set information
        metadata_dict["sets"] = {name: s.to_dict() for name, s in result.sets.items()}

        with open(filepath, "w") as f:
            json.dump(metadata_dict, f, indent=2)

    def _add_inferred_metadata(
        self, result: OptimizationResult, categorized: dict[str, list[str]]
    ) -> None:
        """Add inferred metadata for variables."""
        # Add design variable metadata
        for col in categorized["design_variables"]:
            if not result.design_variables[col].empty:
                result.add_variable_metadata(
                    DesignVariable(
                        name=col,
                        description=f"Inferred design variable: {col}",
                        units=None,
                        lower_bound=float(result.design_variables[col].min()),
                        upper_bound=float(result.design_variables[col].max()),
                        possible_values=None,
                        initial_value=None,
                    )
                )

        # Add objective metadata
        for col in categorized["objectives"]:
            if not result.objectives[col].empty:
                result.add_variable_metadata(
                    Objective(
                        name=col,
                        description=f"Inferred objective: {col}",
                        units=None,
                        lower_bound=None,
                        upper_bound=None,
                        ideal_value=float(result.objectives[col].min()),
                        nadir_value=float(result.objectives[col].max()),
                    )
                )

        # Add inequality constraint metadata
        for col in categorized["inequality_constraints"]:
            if not result.inequality_constraints[col].empty:
                result.add_variable_metadata(
                    Constraint(
                        name=col,
                        description=f"Inferred inequality constraint: {col}",
                        units=None,
                        lower_bound=None,
                        upper_bound=None,
                        constraint_type=ConstraintType.INEQUALITY,
                    )
                )

        # Add equality constraint metadata
        for col in categorized["equality_constraints"]:
            if not result.equality_constraints[col].empty:
                result.add_variable_metadata(
                    Constraint(
                        name=col,
                        description=f"Inferred equality constraint: {col}",
                        units=None,
                        lower_bound=None,
                        upper_bound=None,
                        constraint_type=ConstraintType.EQUALITY,
                    )
                )

        # Add observable metadata
        for col in categorized["observables"]:
            if not result.observables[col].empty:
                result.add_variable_metadata(
                    Observable(
                        name=col,
                        description=f"Inferred observable: {col}",
                        units=None,
                        lower_bound=None,
                        upper_bound=None,
                        computation_source="inferred",
                    )
                )
