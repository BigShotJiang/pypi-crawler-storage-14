"""
File format handlers for importing and exporting optimization results.

This package provides a pluggable architecture for reading and writing
optimization results in various file formats. The format registry
automatically detects and selects the appropriate handler.
"""

from .base import (
    BaseFormatHandler,
    FormatDetectionError,
    FormatReadError,
    FormatWriteError,
    StructuredFormatHandler,
    TabularFormatHandler,
)
from .csv_handler import CSVHandler
from .json_handler import JSONHandler
from .midaco_handler import MIDACoHandler, detect_midaco_files, read_midaco_pair
from .registry import (
    FormatRegistry,
    get_global_registry,
    load_results,
    save_results,
)

__all__ = [
    # Base classes
    "BaseFormatHandler",
    "StructuredFormatHandler",
    "TabularFormatHandler",
    # Exceptions
    "FormatDetectionError",
    "FormatReadError",
    "FormatWriteError",
    # Registry
    "FormatRegistry",
    "get_global_registry",
    # Convenience functions
    "load_results",
    "save_results",
    # Built-in handlers
    "CSVHandler",
    "JSONHandler",
    "MIDACoHandler",
    # MIDACO specific
    "detect_midaco_files",
    "read_midaco_pair",
]
