"""
Optimization Visualization Library

A comprehensive library for visualizing and analyzing single- and multi-objective
optimization results with multi-criteria decision making support.

Main components:
- Core data structures for optimization results
- File format handlers for various input formats
- Plotting utilities for visualization
- Analysis tools (Pareto fronts, metrics, MCDA)
- Storage abstraction layer
- Modular Dash application for interactive visualization
"""

__version__ = "0.0.3"

# Import main classes for convenience
from optiscope.core import (
    Constraint,
    DataTypeCategory,
    DesignVariable,
    Objective,
    Observable,
    OptimizationResult,
    ProblemMetadata,
    ResultSet,
)
from optiscope.io import (
    FormatRegistry,
    load_results,
    save_results,
)

__all__ = [
    # Version
    "__version__",
    # Core classes
    "OptimizationResult",
    "ProblemMetadata",
    "ResultSet",
    "DesignVariable",
    "Objective",
    "Constraint",
    "Observable",
    "DataTypeCategory",
    # IO functions
    "load_results",
    "save_results",
    "FormatRegistry",
]
