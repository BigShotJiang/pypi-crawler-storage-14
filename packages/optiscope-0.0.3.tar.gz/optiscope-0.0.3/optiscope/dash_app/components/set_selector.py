from typing import Optional

import dash
import dash_mantine_components as dmc
from dash import Input, Output, State

from optiscope.dash_app.components.base import BaseComponent
from optiscope.dash_app.core.compatibility import create_virtual_storage_manager
from optiscope.dash_app.core.id_factory import IDFactory


class SetSelector(BaseComponent):
    """
    A reusable SetSelector component for selecting optimization result sets.
    """

    def __init__(
        self,
        component_id: str,
        result_selector_id: str,
        multi: bool = True,
        label: str = "Select Sets:",
        description: Optional[str] = None,
        references_store: str = "storage-references",
        **select_args,
    ):
        """
        Initialize the SetSelector component.

        Args:
            component_id: Unique identifier for this component instance.
            result_selector_id: ID of the component providing the selected result value(s).
            multi: If True, allows multiple set selections.
            label: Label for the MultiSelect/Select component.
            description: Description for the MultiSelect/Select component.
            **select_args: Additional arguments to pass directly to dmc.MultiSelect or dmc.Select.
        """
        super().__init__(component_id)
        self.result_selector_id = result_selector_id
        self._result_selector_ids = IDFactory(result_selector_id)
        self.multi = multi
        self.label = label
        self.description = description
        self.references_store = references_store
        self.select_args = {
            "placeholder": "Select one or more sets...",
            "searchable": True,
            "clearable": True,
            **select_args,
        }

    def layout(self, **kwargs) -> dmc.MultiSelect | dmc.Select:
        """
        Return the Dash layout for this component.

        Returns:
            Dash MultiSelect or Select component.
        """
        if self.multi:
            return dmc.MultiSelect(
                id=self.ids("selector"),
                label=self.label,
                description=self.description,
                data=[],
                value=[],
                persistence=True,
                persistence_type="session",
                **self.select_args,
                **kwargs,
            )
        else:
            return dmc.Select(
                id=self.ids("selector"),
                label=self.label,
                description=self.description,
                data=[],
                value=None,
                persistence=True,
                persistence_type="session",
                **self.select_args,
                **kwargs,
            )

    def register_callbacks(self, app: dash.Dash | None = None) -> None:
        """
        Register all callbacks for this component.

        Args:
            app: The Dash application instance.
        """
        if app is None:
            app = dash.get_app()

        @app.callback(
            Output(self.ids("selector"), "data"),
            Output(self.ids("selector"), "value"),
            Input(self._result_selector_ids("selector"), "value"),
            State(self.references_store, "data"),
            State(self.ids("selector"), "value"),
            prevent_initial_call=True,
        )
        def update_sets_selector(selected_result_keys, stored_refs, current_value):
            """Update available sets based on selected results."""
            if not stored_refs or not selected_result_keys:
                return [], [] if self.multi else None

            # Ensure selected_result_keys is a list for consistent processing
            if not isinstance(selected_result_keys, list):
                selected_result_keys = [selected_result_keys]

            storage_manager = create_virtual_storage_manager(stored_refs)

            # Collect all unique sets across selected results
            all_sets = {}
            for result_key in selected_result_keys:
                try:
                    result = storage_manager.load_result(result_key)
                    sets = result.list_sets()
                    for set_name in sets:
                        if set_name not in all_sets:
                            all_sets[set_name] = []
                        all_sets[set_name].append(result_key)
                except Exception:
                    continue

            # Create options showing which results contain each set
            options = []
            for set_name, result_keys in all_sets.items():
                if len(result_keys) == len(selected_result_keys):
                    label = f"{set_name} (all results)"
                else:
                    label = f"{set_name} ({', '.join(result_keys)})"
                options.append({"label": label, "value": set_name})

            # Keep current selection if still valid
            if current_value:
                if self.multi:
                    valid_value = [v for v in current_value if v in all_sets.keys()]
                else:
                    valid_value = current_value if current_value in all_sets.keys() else None
            else:
                valid_value = [] if self.multi else None

            return options, valid_value

    def get_value_id(self) -> str:
        """Return the ID of the component's value property."""
        return self.ids("selector")
