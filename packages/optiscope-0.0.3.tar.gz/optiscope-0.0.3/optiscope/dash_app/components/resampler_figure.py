import dash
from dash import Input, Output, State, dcc, no_update

from optiscope.dash_app.core.id_factory import IDFactory
from optiscope.plotting.time_series import RESAMPLER_AVAILABLE


class ResamplerFigure:
    """A component that wraps a dcc.Graph and a dcc.Store for resampling."""

    def __init__(self, component_id: str):
        """
        Initialize the ResamplerFigure.

        Args:
            component_id: Unique identifier for this component instance.
        """
        self.component_id = component_id
        self.ids = IDFactory(component_id)

    def layout(self):
        """
        Create the layout for the ResamplerFigure.

        Returns:
            A list containing the dcc.Graph and dcc.Store components.
        """
        return [
            dcc.Graph(
                id=self.get_figure_id(),
                config={"displayModeBar": True, "displaylogo": False},
            ),
            dcc.Store(id=self.get_store_id()),
        ]

    def register_callbacks(self, app: dash.Dash) -> None:
        """
        Register the resampling callback for the figure.

        Args:
            app: The Dash app instance.
        """
        if not RESAMPLER_AVAILABLE:
            return

        @app.callback(
            Output(self.get_figure_id(), "figure", allow_duplicate=True),
            Input(self.get_figure_id(), "relayoutData"),
            State(self.get_store_id(), "data"),
            prevent_initial_call=True,
            memoize=True,
        )
        def update_resampler(relayoutdata, fig):
            """Update the figure based on relayout data from the stored figure."""
            if fig is None:
                return no_update
            return fig.construct_update_data_patch(relayoutdata)

    def get_figure_id(self) -> str:
        """Get the component ID for the dcc.Graph component."""
        return self.ids("graph")

    def get_store_id(self) -> str:
        """Get the component ID for the dcc.Store component."""
        return self.ids("store")
