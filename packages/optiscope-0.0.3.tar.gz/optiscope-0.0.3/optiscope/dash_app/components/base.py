"""Base class for reusable Dash components with automatic callback management."""

from abc import ABC, abstractmethod
from typing import Any

import dash

from optiscope.dash_app.core.id_factory import IDFactory


class BaseComponent(ABC):
    """
    Base class for creating reusable Dash components.

    This class provides a framework for creating components that:
    - Manage their own IDs and avoid conflicts
    - Register their own callbacks automatically
    - Can be easily instantiated and reused across pages

    Attributes:
        component_id: Unique identifier for this component instance
        ids: IDFactory instance for generating component-specific IDs
    """

    def __init__(self, component_id: str, id_factory: IDFactory | None = None):
        """
        Initialize the base component.

        Args:
            component_id: Unique identifier for this component instance.
                         Used to namespace all IDs to avoid conflicts.
        """
        self.component_id = component_id
        if id_factory is None:
            self.ids = IDFactory(component_id)
        else:
            self.ids = id_factory

    def __post_init__(self):
        self.register_callbacks()

    @abstractmethod
    def layout(self, **kwargs) -> Any:
        """
        Return the Dash layout for this component.

        Returns:
            Dash component or layout
        """
        pass

    @abstractmethod
    def register_callbacks(self, app: dash.Dash | None = None) -> None:
        """
        Register all callbacks for this component.

        This method should define all callbacks that the component needs.
        It will be called automatically when the component is initialized.

        Args:
            app: The Dash application instance
        """
        pass

    def get_id(self, element_name: str) -> str:
        """
        Get a namespaced ID for a component element.

        Args:
            element_name: Name of the element within this component

        Returns:
            Namespaced ID string
        """
        return self.ids(element_name)
