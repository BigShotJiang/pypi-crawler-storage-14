from __future__ import annotations

import logging
from typing import Any

import dash
import dash_ag_grid as dag
import dash_mantine_components as dmc
from dash import callback, html, no_update
from dash.dependencies import Input, Output

from optiscope.dash_app.components.base import BaseComponent
from optiscope.dash_app.core.compatibility import create_virtual_storage_manager
from optiscope.dash_app.core.id_factory import IDFactory


class AgGridTable(BaseComponent):
    """
    A reusable AgGrid component for displaying optimization results.
    Replaces the DataTable component with dash-ag-grid.
    """

    def __init__(
        self,
        component_id: str,
        storage_id: str = "global-results-store",
        result_selector_id: str | None = None,
        set_selector_id: str | None = None,
        selected_sets_to_display_id: str | None = None,
        specific_ids_selector_id: str | None = None,
        output_selected_rows_id: str | None = None,
        output_filtered_data_id: str | None = None,
        color_scheme_id: str = "theme-store",
        logger: logging.Logger | None = None,
        **grid_args,
    ):
        """
        Initialize the AgGridTable component.

        Args:
            component_id: Unique identifier for this component instance.
            storage_id: ID of the main data storage component.
            result_selector_id: ID of the component providing the selected result value.
            set_selector_id: ID of the component providing the selected set value.
            selected_sets_to_display_id: ID of the component providing which sets to display as columns.
            specific_ids_selector_id: ID of the component providing specific IDs to highlight/filter.
            output_selected_rows_id: Optional ID for a dcc.Store to output selected row data.
            output_filtered_data_id: Optional ID for a dcc.Store to output filtered table data.
            color_scheme_id: ID of the store containing theme info (light/dark).
            **grid_args: Additional arguments to pass directly to dag.AgGrid.
        """
        super().__init__(component_id)
        self.storage_id = storage_id
        self.result_selector_id = result_selector_id
        self._result_selector_ids = IDFactory(result_selector_id) if result_selector_id else None
        self.set_selector_id = set_selector_id
        self.selected_sets_to_display_id = selected_sets_to_display_id
        self.specific_ids_selector_id = specific_ids_selector_id
        self.output_selected_rows_id = output_selected_rows_id
        self.output_filtered_data_id = output_filtered_data_id
        self.color_scheme_id = color_scheme_id

        self.grid_args = {
            "style": {"height": "600px", "width": "100%"},
            "dashGridOptions": {
                "pagination": True,
                "paginationPageSize": 20,
                "rowSelection": "multiple",
                "suppressRowClickSelection": False,
                "animateRows": True,
            },
            "defaultColDef": {
                "sortable": True,
                "filter": True,
                "resizable": True,
                "floatingFilter": True,
            },
            **grid_args,
        }

        self.logger = logger if logger else logging.getLogger(__name__)

    def layout(self, **kwargs) -> html.Div:
        """
        Return the Dash layout for this component.
        """
        return html.Div(
            [
                # Control Panel (Accordion)
                dmc.Accordion(
                    children=[
                        dmc.AccordionItem(
                            [
                                dmc.AccordionControl("Display Options"),
                                dmc.AccordionPanel(
                                    [
                                        dmc.Switch(
                                            label="Colorize Constraints",
                                            id=self.ids("colorize-constraints-switch"),
                                            checked=False,
                                        )
                                    ]
                                ),
                            ],
                            value="display-options",
                        ),
                        dmc.AccordionItem(
                            [
                                dmc.AccordionControl("Advanced Filtering (Pandas Query)"),
                                dmc.AccordionPanel(
                                    [
                                        dmc.Text(
                                            "Enter a Pandas query string to filter the data before it reaches the grid.",
                                            size="sm",
                                            mb="xs",
                                        ),
                                        dmc.TextInput(
                                            id=self.ids("filter-query-input"),
                                            placeholder="e.g. `Cost` < 100 and `Efficiency` > 0.5",
                                            style={"width": "100%"},
                                            mb="sm",
                                        ),
                                    ]
                                ),
                            ],
                            value="advanced-filtering",
                        ),
                    ],
                    mb="md",
                ),
                # Ag Grid Component
                dag.AgGrid(
                    id=self.ids("data-table"),
                    rowData=[],
                    columnDefs=[],
                    # Apply default themes, will be updated by callback
                    className="ag-theme-alpine",
                    **self.grid_args,
                    **kwargs,
                ),
            ]
        )

    def register_callbacks(self, app: dash.Dash | None = None) -> None:
        """
        Register all callbacks for this component.
        """
        if app is None:
            app = dash.get_app()

        # 1. Theme Update Callback
        @callback(
            Output(self.ids("data-table"), "className"),
            Input(self.color_scheme_id, "data"),
        )
        def update_theme(theme_data):
            is_dark = theme_data and "dark" in theme_data
            return "ag-theme-alpine-dark" if is_dark else "ag-theme-alpine"

        # 2. Main Data & Columns Callback
        main_inputs = [
            Input(self.storage_id, "data"),
            Input(self.ids("filter-query-input"), "value"),
            Input(self.ids("colorize-constraints-switch"), "checked"),
        ]

        # Add inputs for selectors if they exist
        if self._result_selector_ids:
            main_inputs.append(Input(self._result_selector_ids("selector"), "value"))
        if self.set_selector_id:
            main_inputs.append(Input(self.set_selector_id, "value"))
        if self.selected_sets_to_display_id:
            main_inputs.append(Input(self.selected_sets_to_display_id, "value"))
        if self.specific_ids_selector_id:
            main_inputs.append(Input(self.specific_ids_selector_id, "data"))

        @callback(
            Output(self.ids("data-table"), "rowData"),
            Output(self.ids("data-table"), "columnDefs"),
            main_inputs,
            prevent_initial_call=True,
        )
        def update_table_data(stored_data, filter_query, colorize_constraints, *args):
            # Unpack optional args
            arg_idx = 0

            selected_result = None
            if self._result_selector_ids:
                selected_result = args[arg_idx]
                arg_idx += 1

            selected_set = None
            if self.set_selector_id:
                selected_set = args[arg_idx]
                arg_idx += 1

            selected_sets_to_display = None
            if self.selected_sets_to_display_id:
                selected_sets_to_display = args[arg_idx]
                arg_idx += 1

            specific_ids = None
            if self.specific_ids_selector_id:
                specific_ids = args[arg_idx]
                arg_idx += 1

            # Data Loading Logic
            if not stored_data:
                return no_update, no_update

            if self._result_selector_ids and not selected_result:
                return [], []

            storage_manager = create_virtual_storage_manager(stored_data)
            result = storage_manager.load_result(selected_result) if selected_result else None

            if not result:
                return [], []

            # Get Data
            df = result.get_all_data()

            # Add 'id' column from index if not present
            if "id" not in df.columns:
                df["id"] = df.index.tolist()

            # 1. Filter by Set
            if selected_set:
                set_data = result.get_set(selected_set)
                df = df.loc[df.index.isin(set_data.indices)]

            # 2. Filter by Specific IDs
            if specific_ids:
                df = df[df["id"].isin(specific_ids)]

            # 3. Add Set columns
            all_sets = result.list_sets()
            sets_to_show = [s for s in (selected_sets_to_display or all_sets) if s in all_sets]

            for set_name in sets_to_show:
                current_set = result.get_set(set_name)
                # Convert boolean to string for better grid filtering, or keep as bool
                df[set_name] = df["id"].isin(current_set.indices)

            # 4. Advanced Pandas Filtering
            if filter_query:
                try:
                    df = df.query(filter_query)
                except Exception as e:
                    self.logger.warning(f"Invalid pandas query: {e}")
                    # We could output an error notification here if we added an Output for it

            # Prepare Columns
            column_defs = [{"field": "id", "headerName": "ID", "width": 80, "pinned": "left"}]

            categories = {
                "Variables": result.design_variables.columns,
                "Objectives": result.objectives.columns,
                "Inequality": result.inequality_constraints.columns,
                "Equality": result.equality_constraints.columns,
                "Observables": result.observables.columns,
            }

            # Helper to build style conditions
            def get_constraint_style(col_type):
                if not colorize_constraints:
                    return None

                # Inequality: > 0 is violation (red), <= 0 is satisfaction (green)
                if col_type == "Inequality":
                    return {
                        "styleConditions": [
                            {
                                "condition": "params.value > 0",
                                "style": {"backgroundColor": "rgba(255, 0, 0, 0.2)"},
                            },
                            {
                                "condition": "params.value <= 0",
                                "style": {"backgroundColor": "rgba(0, 255, 0, 0.2)"},
                            },
                        ]
                    }

                # Equality: != 0 (with tolerance) violation, near 0 satisfaction
                if col_type == "Equality":
                    tol = 1e-6
                    return {
                        "styleConditions": [
                            {
                                "condition": f"params.value > {tol} || params.value < -{tol}",
                                "style": {"backgroundColor": "rgba(255, 0, 0, 0.2)"},
                            },
                            {
                                "condition": f"params.value >= -{tol} && params.value <= {tol}",
                                "style": {"backgroundColor": "rgba(0, 255, 0, 0.2)"},
                            },
                        ]
                    }
                return None

            for cat, cols in categories.items():
                for col in cols:
                    col_def: dict[str, Any] = {
                        "field": col,
                        "headerName": col,
                        # Grouping in header using 'headerGroupComponent' is complex in AgGrid
                        # simpler approach: just use field name or maybe pre-pend category
                        # For now, flat columns. Could use column groups in future.
                    }

                    # Apply coloring if enabled
                    style_cond = get_constraint_style(cat)
                    if style_cond:
                        col_def["cellStyle"] = style_cond

                    # Format numbers
                    if df[col].dtype.kind in "fc":  # float or complex
                        col_def["valueFormatter"] = {"function": "d3.format(',.4f')(params.value)"}

                    column_defs.append(col_def)

            # Add Set Columns
            for s in sets_to_show:
                column_defs.append(
                    {"field": s, "headerName": f"Set: {s}", "cellDataType": "boolean"}
                )

            return df.to_dict("records"), column_defs

        # 3. Selected Rows Output
        if self.output_selected_rows_id:

            @callback(
                Output(self.output_selected_rows_id, "data", allow_duplicate=True),
                Input(self.ids("data-table"), "selectedRows"),
                prevent_initial_call=True,
            )
            def update_selected_output(selected_rows):
                return selected_rows or []

        # 4. Filtered Data Output
        if self.output_filtered_data_id:

            @callback(
                Output(self.output_filtered_data_id, "data", allow_duplicate=True),
                Input(self.ids("data-table"), "virtualRowData"),
                prevent_initial_call=True,
            )
            def update_filtered_output(virtual_row_data):
                return virtual_row_data or []
