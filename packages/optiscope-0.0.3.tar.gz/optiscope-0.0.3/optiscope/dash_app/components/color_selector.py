"""Component for selecting which column to use for coloring data points."""

from typing import Optional

import dash_mantine_components as dmc
from dash import Input, Output, State, callback

import optiscope.dash_app.core.glossary as glo
from optiscope.dash_app.core import storage_helpers
from optiscope.dash_app.core.id_factory import IDFactory


class ColorSelector:
    """Component for selecting a column to color data points by."""

    def __init__(
        self,
        component_id: str,
        label: str = "Color By:",
        description: Optional[str] = None,
        include_result_option: bool = True,
    ):
        """
        Initialize the color selector.

        Args:
            component_id: Unique identifier for this selector instance
            label: Label for the selector
            description: Optional description text
            include_result_option: Whether to include "Result" as a color option for multi-result scenarios
        """
        self.component_id = component_id
        self.label = label
        self.description = description
        self.include_result_option = include_result_option
        self.ids = IDFactory(component_id)

    def layout(self) -> dmc.Stack:
        """Create the layout for the color selector."""
        return dmc.Stack(
            [
                dmc.Text(self.label, fw="bold", size="sm"),
                dmc.Select(
                    id=self.ids("selector"),
                    placeholder="Select a column to color by...",
                    data=[],
                    value=None,
                    searchable=True,
                    clearable=True,
                    description=self.description,  # or "Choose a column to use for coloring data points",
                    renderOption={"function": "renderOptionSelect"},
                    persistence=True,
                    persistence_type="session",
                ),
            ],
            gap="xs",
        )

    def register_callbacks(self, app, result_selector_id: str) -> None:
        """
        Register callbacks to populate the selector with available columns.

        Args:
            app: Dash app instance
            result_selector_id: Component ID of the result selector to watch for changes
        """

        @callback(
            Output(self.ids("selector"), "data"),
            Output(self.ids("selector"), "value"),
            Input(glo.REF_STORE_STR, "data"),
            Input(result_selector_id, "value"),
            State(self.ids("selector"), "value"),
        )
        def update_color_selector_options(stored_data, selected_result_keys, current_value):
            """Update available color options based on selected results."""
            if not stored_data:
                return [], None

            if not selected_result_keys:
                return [], None

            # Ensure selected_result_keys is a list
            if not isinstance(selected_result_keys, list):
                selected_result_keys = [selected_result_keys]

            # Collect all unique columns across selected results, properly categorized
            all_variables = set()
            all_objectives = set()
            all_constraints = set()
            all_observables = set()

            for result_key in selected_result_keys:
                try:
                    result = storage_helpers.get_result_by_combined_key(result_key)
                    if result:
                        all_variables.update(result.design_variables.columns)
                        all_objectives.update(result.objectives.columns)
                        all_constraints.update(result.inequality_constraints.columns)
                        all_constraints.update(result.equality_constraints.columns)
                        all_observables.update(result.observables.columns)
                except Exception:
                    continue

            # Create options without groups (DMC Select doesn't support groups in the same way)
            options = []

            # Add "Result" option if multiple results and enabled
            if self.include_result_option and len(selected_result_keys) > 1:
                options.append({"label": "🎨 Result (comparison)", "value": "_result"})

            # Add all columns with visual separators in labels
            if all_variables:
                for col in sorted(all_variables):
                    options.append({"label": f"{col}", "value": col, "type": "var"})
            if all_objectives:
                for col in sorted(all_objectives):
                    options.append({"label": f"{col}", "value": col, "type": "obj"})
            if all_constraints:
                for col in sorted(all_constraints):
                    options.append({"label": f"{col}", "value": col, "type": "con"})
            if all_observables:
                for col in sorted(all_observables):
                    options.append({"label": f"{col}", "value": col, "type": "obs"})

            # Determine value
            if current_value and current_value in [opt["value"] for opt in options]:
                value = current_value
            elif self.include_result_option and len(selected_result_keys) > 1:
                value = "_result"  # Default to result comparison for multiple results
            elif options:
                obj_options = [opt for opt in options if opt["label"].startswith("🎯")]
                value = obj_options[0]["value"] if obj_options else options[0]["value"]
            else:
                value = None

            return options, value

    def get_value_id(self):
        """Get the component ID for accessing the selected value."""
        return self.ids("selector")


def create_color_selector(
    component_id: str,
    label: str = "Color By:",
    description: Optional[str] = None,
    include_result_option: bool = True,
) -> ColorSelector:
    """
    Factory function to create a ColorSelector component.

    Args:
        component_id: Unique identifier for this selector instance
        label: Label for the selector
        description: Optional description text
        include_result_option: Whether to include "Result" as a color option

    Returns:
        ColorSelector instance
    """
    return ColorSelector(
        component_id=component_id,
        label=label,
        description=description,
        include_result_option=include_result_option,
    )
