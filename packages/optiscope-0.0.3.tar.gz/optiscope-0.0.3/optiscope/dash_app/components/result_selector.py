"""Component for selecting which optimization results to visualize."""

from typing import Optional

import dash_mantine_components as dmc
from dash import Input, Output, State, callback

from optiscope.dash_app.core import storage_helpers
from optiscope.dash_app.core.id_factory import IDFactory


class ResultSelector:
    """Component for selecting one or more optimization results."""

    def __init__(
        self,
        component_id: str,
        multi: bool = True,
        label: str = "Select Results:",
        description: Optional[str] = None,
        references_store: str = "storage-references",
        persistence: bool = True,
        main_selector_id: str | None = None,
    ):
        """
        Initialize the result selector.

        Args:
            component_id: Unique identifier for this selector instance
            multi: Whether to allow multiple result selection
            label: Label for the selector
            description: Optional description text
            persistence: Whether to persist the selected value
        """
        self.component_id = component_id
        self.multi = multi
        self.label = label
        self.description = description
        self.ids = IDFactory(component_id)
        self.references_store = references_store
        self.persistence = persistence
        self.main_selector_id = main_selector_id

    def layout(self, show_label: bool = True) -> dmc.Stack:
        """Create the layout for the result selector."""
        persistence_props = (
            {"persistence": True, "persistence_type": "session"} if self.persistence else {}
        )

        return dmc.Stack(
            [
                dmc.Text(self.label, fw="bold", size="sm") if show_label else "",
                dmc.MultiSelect(
                    id=self.ids("selector"),
                    placeholder="Select optimization results...",
                    data=[],
                    value=[],
                    searchable=True,
                    clearable=True,
                    description=self.description,
                    **persistence_props,
                )
                if self.multi
                else dmc.Select(
                    id=self.ids("selector"),
                    placeholder="Select an optimization result...",
                    data=[],
                    value=None,
                    searchable=True,
                    clearable=True,
                    description=self.description,
                    **persistence_props,
                ),
            ],
            gap="xs",
        )

    def register_callbacks(self, app) -> None:
        """Register callbacks to populate the selector with available results."""

        state = [
            State(self.ids("selector"), "value"),
        ]

        if self.main_selector_id is not None:
            state.append(State(self.main_selector_id, "value"))

        @callback(
            Output(self.ids("selector"), "data"),
            Output(self.ids("selector"), "value"),
            Input(self.references_store, "data"),
            Input("selected-results-store", "data"),
            *state,
        )
        def update_selector_options(
            storage_refs, selected_results, current_value, main_selection=None
        ):
            """Update available options and default selection."""
            if not storage_refs:
                return [], [] if self.multi else None

            combined_results = storage_helpers.get_combined_result_list(storage_refs)

            # Group items by source_id
            grouped_data = {}
            for item in combined_results:
                source_id = item["source_label"]
                if source_id not in grouped_data:
                    grouped_data[source_id] = []

                grouped_data[source_id].append(
                    {
                        "label": item["display_label"],
                        "value": storage_helpers.create_combined_key(
                            item["source_id"], item["result_key"]
                        ),
                    }
                )

            # Create grouped options for dmc.MultiSelect
            options = [
                {"group": source_id, "items": items} for source_id, items in grouped_data.items()
            ]

            # Flatten items to check for current_value
            all_values = [item["value"] for group in options for item in group["items"]]

            # Determine selected value
            if main_selection is not None:
                value = main_selection
            elif current_value and current_value in all_values:
                value = current_value
            elif all_values:
                value = all_values[0]
            else:
                value = None

            if self.multi:
                value = [value]

            return options, value

    def get_value_id(self) -> str:
        """Get the component ID for accessing the selected value."""
        return self.ids("selector")


def create_result_selector(
    component_id: str,
    multi: bool = True,
    label: str = "Select Results:",
    description: Optional[str] = None,
    persistence: bool = False,
) -> ResultSelector:
    """
    Factory function to create a ResultSelector component.

    Args:
        component_id: Unique identifier for this selector instance
        multi: Whether to allow multiple result selection
        label: Label for the selector
        description: Optional description text
        persistence: Whether to persist the selected value

    Returns:
        ResultSelector instance
    """
    return ResultSelector(
        component_id=component_id,
        multi=multi,
        label=label,
        description=description,
        persistence=persistence,
    )
