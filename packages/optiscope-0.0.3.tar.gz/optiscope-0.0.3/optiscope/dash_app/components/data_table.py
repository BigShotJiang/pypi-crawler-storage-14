from __future__ import annotations

import json
import logging
import math
import re

import dash
import dash_mantine_components as dmc
import pandas as pd
from dash import html
from dash_extensions.enrich import Input, Output, State, callback, dash_table, no_update

from optiscope.dash_app.components.base import BaseComponent
from optiscope.dash_app.core.compatibility import create_virtual_storage_manager
from optiscope.dash_app.core.id_factory import IDFactory


class DataTable(BaseComponent):
    """
    A reusable DataTable component for displaying optimization results.

    This component allows for flexible data display, including:
    - Loading data from a specified storage and result.
    - Filtering data by a selected set.
    - Highlighting specific rows based on provided IDs.
    - Passing DataTable arguments for customization.
    - Outputting selected rows and filtered data.
    """

    def __init__(
        self,
        component_id: str,
        storage_id: str = "global-results-store",
        result_selector_id: str | None = None,
        set_selector_id: str | None = None,
        selected_sets_to_display_id: str | None = None,
        specific_ids_selector_id: str | None = None,
        output_selected_rows_id: str | None = None,
        output_filtered_data_id: str | None = None,
        color_scheme_id: str = "theme-store",  # Default to "theme-store"
        logger: logging.Logger | None = None,
        **datatable_args,
    ):
        """
        Initialize the DataTable component.

        Args:
            component_id: Unique identifier for this component instance.
            storage_id: ID of the main data storage component (e.g., "global-results-store").
            result_selector_id: ID of the component providing the selected result value.
                                If None, fetches all results.
            set_selector_id: ID of the component providing the selected set value.
                             If None, no set filtering is applied.
            selected_sets_to_display_id: ID of the component providing which sets to display as columns.
                                         If None, no set columns are shown.
            specific_ids_selector_id: ID of the component providing specific IDs to highlight/filter.
                                      If provided, only rows with these IDs will be shown if a set is also selected.
            output_selected_rows_id: Optional ID for a dcc.Store or similar to output selected row data.
            output_filtered_data_id: Optional ID for a dcc.Store or similar to output filtered table data.
            **datatable_args: Additional arguments to pass directly to dash_table.DataTable.
        """
        super().__init__(component_id)
        self.storage_id = storage_id
        self.result_selector_id = result_selector_id
        self._result_selector_ids = (
            IDFactory(result_selector_id) if result_selector_id else None
        )  # Create IDFactory for result selector
        self.set_selector_id = set_selector_id
        self.selected_sets_to_display_id = selected_sets_to_display_id
        self.specific_ids_selector_id = specific_ids_selector_id
        self.output_selected_rows_id = output_selected_rows_id
        self.output_filtered_data_id = output_filtered_data_id
        self.color_scheme_id = color_scheme_id
        self.datatable_args = {
            "page_size": 20,
            "sort_action": "custom",
            "page_action": "custom",
            "filter_action": "custom",  # Enable server-side filtering
            "sort_mode": "multi",
            "style_table": {"overflowX": "auto"},
            "row_selectable": "multi",
            "merge_duplicate_headers": True,
            "hidden_columns": [],
            **datatable_args,
        }

        self.logger = logger if logger else logging.getLogger(__name__)

    def layout(self, **kwargs) -> html.Div:
        """
        Return the Dash layout for this component.

        Args:
            **kwargs: Additional arguments to pass to the DataTable.

        Returns:
            Dash Div component containing the DataTable and advanced filter controls.
        """
        return html.Div(
            [
                dash_table.DataTable(
                    id=self.ids("data-table"),
                    data=[],
                    columns=[],
                    **self.datatable_args,
                    **kwargs,
                ),
                dmc.Accordion(
                    children=[
                        dmc.AccordionItem(
                            [
                                dmc.AccordionControl("Display Options"),
                                dmc.AccordionPanel(
                                    [
                                        dmc.Switch(
                                            label="Colorize Constraints",
                                            id=self.ids("colorize-constraints-switch"),
                                            checked=False,
                                        )
                                    ]
                                ),
                            ],
                            value="display-options",
                        ),
                        dmc.AccordionItem(
                            [
                                dmc.AccordionControl("Advanced Filtering"),
                                dmc.AccordionPanel(
                                    [
                                        dmc.RadioGroup(
                                            [
                                                dmc.Radio(label="Read filter_query", value="read"),
                                                dmc.Radio(
                                                    label="Write to filter_query", value="write"
                                                ),
                                            ],
                                            value="read",
                                            id=self.ids("filter-query-read-write"),
                                            mb="sm",
                                        ),
                                        dmc.TextInput(
                                            id=self.ids("filter-query-input"),
                                            placeholder="Enter filter query (e.g. {column} gt 5)",
                                            style={"width": "100%"},
                                            mb="sm",
                                        ),
                                        html.Div(id=self.ids("filter-query-output")),
                                        html.Div(
                                            id=self.ids("datatable-query-structure"),
                                            style={"whiteSpace": "pre"},
                                        ),
                                    ]
                                ),
                            ],
                            value="advanced-filtering",
                        ),
                    ],
                    mb="md",
                ),
            ]
        )

    @staticmethod
    def _sort_dataframe(df: pd.DataFrame, sort_by: list[dict[str, str]]) -> pd.DataFrame:
        """
        Sort the DataFrame based on the sort_by list.

        Args:
            df: The DataFrame to sort.
            sort_by: List of dictionaries containing column ID and direction.

        Returns:
            The sorted DataFrame.
        """
        if not sort_by:
            return df

        return df.sort_values(
            [col["column_id"] for col in sort_by],
            ascending=[col["direction"] == "asc" for col in sort_by],
        )

    @staticmethod
    def table_type(df_column):
        # Note - this only works with Pandas >= 1.0.0
        if isinstance(df_column.dtype, pd.DatetimeTZDtype):
            return ("datetime",)
        elif (
            isinstance(df_column.dtype, pd.StringDtype)
            or isinstance(df_column.dtype, pd.BooleanDtype)
            or isinstance(df_column.dtype, pd.CategoricalDtype)
            or isinstance(df_column.dtype, pd.PeriodDtype)
        ):
            return "text"
        elif (
            isinstance(df_column.dtype, pd.SparseDtype)
            or isinstance(df_column.dtype, pd.IntervalDtype)
            or isinstance(df_column.dtype, pd.Int8Dtype)
            or isinstance(df_column.dtype, pd.Int16Dtype)
            or isinstance(df_column.dtype, pd.Int32Dtype)
            or isinstance(df_column.dtype, pd.Int64Dtype)
        ):
            return "numeric"
        else:
            return "any"

    @staticmethod
    def _filter_dataframe(df: pd.DataFrame, filter_query: str | dict) -> pd.DataFrame:
        def to_string(filter):
            operator_type = filter.get("type")
            operator_subtype = filter.get("subType")

            if operator_type == "relational-operator":
                if operator_subtype == "=":
                    return "=="
                else:
                    return operator_subtype
            elif operator_type == "logical-operator":
                if operator_subtype == "&&":
                    return "&"
                else:
                    return "|"
            elif (
                operator_type == "expression"
                and operator_subtype == "value"
                and type(filter.get("value")) is str
            ):
                return '"{}"'.format(filter.get("value"))
            else:
                return filter.get("value")

        def construct_filter(derived_query_structure, df, complex_operator=None):
            # there is no query; return an empty filter string and the
            # original dataframe
            if derived_query_structure is None:
                return ("", df)

            # the operator typed in by the user; can be both word-based or
            # symbol-based
            operator_type = derived_query_structure.get("type")

            # the symbol-based representation of the operator
            operator_subtype = derived_query_structure.get("subType")

            # the LHS and RHS of the query, which are both queries themselves
            left = derived_query_structure.get("left", None)
            right = derived_query_structure.get("right", None)

            # the base case
            if left is None and right is None:
                return (to_string(derived_query_structure), df)

            # recursively apply the filter on the LHS of the query to the
            # dataframe to generate a new dataframe
            (left_query, left_df) = construct_filter(left, df)

            # apply the filter on the RHS of the query to this new dataframe
            (right_query, right_df) = construct_filter(right, left_df)

            # 'datestartswith' and 'contains' can't be used within a pandas
            # filter string, so we have to do this filtering ourselves
            if complex_operator is not None:
                right_query = right.get("value")
                # perform the filtering to generate a new dataframe
                if complex_operator == "datestartswith":
                    return (
                        "",
                        right_df[right_df[left_query].astype(str).str.startswith(right_query)],
                    )
                elif complex_operator == "contains":
                    return (
                        "",
                        right_df[right_df[left_query].astype(str).str.contains(right_query)],
                    )

            if operator_type == "relational-operator" and operator_subtype in [
                "contains",
                "datestartswith",
            ]:
                return construct_filter(
                    derived_query_structure, df, complex_operator=operator_subtype
                )

            # construct the query string; return it and the filtered dataframe
            return (
                "{} {} {}".format(
                    left_query,
                    to_string(derived_query_structure)
                    if left_query != "" and right_query != ""
                    else "",
                    right_query,
                ).strip(),
                right_df,
            )

        # Handle string queries directly (from manual input)
        if isinstance(filter_query, str):
            try:
                # Basic support for manual queries like "{col} gt 5"
                # This is a simplified parser/converter to pandas query syntax
                # Ideally, we should use a proper parser or rely on Dash's structure if possible
                # But when writing manually, we get a string.
                # Let's try to use pandas query directly if it looks like one,
                # or do some basic replacements to make it pandas-compatible.

                # Dash syntax: {col} operator value
                # Pandas syntax: `col` operator value

                # Replace {col} with `col`
                pd_query = re.sub(r"{([^}]+)}", r"`\1`", filter_query)

                # Replace operators
                replacements = {
                    " eq ": " == ",
                    " ne ": " != ",
                    " gt ": " > ",
                    " lt ": " < ",
                    " ge ": " >= ",
                    " le ": " <= ",
                    " && ": " & ",
                    " || ": " | ",
                    " contains ": " contains ",  # Pandas query doesn't support contains directly like this usually
                }
                for dash_op, pd_op in replacements.items():
                    pd_query = pd_query.replace(dash_op, pd_op)

                if " contains " in filter_query:
                    # Fallback to manual filtering for 'contains'
                    match = re.match(r"`([^`]+)` contains '([^']+)'", pd_query)
                    if match:
                        col_name = match.group(1)
                        substring = match.group(2)
                        return df[df[col_name].astype(str).str.contains(substring)]
                    else:
                        return df  # Invalid format; return unfiltered

                return df.query(pd_query)
            except Exception as e:
                print(f"Error filtering with query '{filter_query}': {e}")
                return df

        pd_query_string = ""
        df_filtered = df
        (pd_query_string, df_filtered) = construct_filter(filter_query, df)

        if pd_query_string != "":
            df_filtered = df_filtered.query(pd_query_string)

        return df_filtered

    def register_callbacks(self, app: dash.Dash | None = None) -> None:
        """
        Register all callbacks for this component.

        Args:
            app: The Dash application instance.
        """
        if app is None:
            app = dash.get_app()

        outputs = [
            Output(self.ids("data-table"), "data"),
            Output(self.ids("data-table"), "columns"),
            Output(self.ids("data-table"), "page_count"),
        ]
        # Append optional outputs first
        if self.output_selected_rows_id:
            outputs.append(Output(self.output_selected_rows_id, "data", allow_duplicate=True))
        if self.output_filtered_data_id:
            outputs.append(Output(self.output_filtered_data_id, "data", allow_duplicate=True))

        # Then append all style outputs
        outputs.extend(
            [
                Output(self.ids("data-table"), "style_data"),
                Output(self.ids("data-table"), "style_header"),
                Output(self.ids("data-table"), "style_table"),
                Output(self.ids("data-table"), "style_filter"),
                Output(self.ids("data-table"), "style_data_conditional"),
                Output(self.ids("data-table"), "style_header_conditional"),
                Output(self.ids("data-table"), "style_cell_conditional"),
            ]
        )

        inputs = [
            Input(self.storage_id, "data"),
            Input(self.ids("data-table"), "page_current"),
            Input(self.ids("data-table"), "page_size"),
            Input(self.ids("data-table"), "sort_by"),
            Input(
                self.ids("data-table"), "filter_query"
            ),  # Use filter_query directly for both manual and UI filtering
        ]
        if self._result_selector_ids:  # Use the internal IDFactory
            inputs.append(
                Input(self._result_selector_ids("selector"), "value")
            )  # Correctly reference the ResultSelector's value ID
        if self.set_selector_id:
            inputs.append(Input(self.set_selector_id, "value"))
        if self.selected_sets_to_display_id:
            inputs.append(Input(self.selected_sets_to_display_id, "value"))
        if self.specific_ids_selector_id:
            inputs.append(
                Input(self.specific_ids_selector_id, "data")
            )  # Assuming dcc.Store for specific IDs

        # Add input for color scheme
        inputs.append(Input(self.color_scheme_id, "data"))

        # Add input for colorize constraints switch
        inputs.append(Input(self.ids("colorize-constraints-switch"), "checked"))

        @callback(
            outputs,
            inputs,
            prevent_initial_call=True,
        )
        def update_data_table(
            stored_data,
            page_current,
            page_size,
            sort_by,
            filter_query,
            arg5=None,
            arg6=None,
            arg7=None,
            arg8=None,
            arg9=None,
            arg10=None,
        ):
            # Map args based on what's enabled
            arg_offset = 5

            selected_result = None
            if self._result_selector_ids:
                selected_result = locals()[f"arg{arg_offset}"]
                arg_offset += 1

            selected_set = None
            if self.set_selector_id:
                selected_set = locals()[f"arg{arg_offset}"]
                arg_offset += 1

            selected_sets_to_display = None
            if self.selected_sets_to_display_id:
                selected_sets_to_display = locals()[f"arg{arg_offset}"]
                arg_offset += 1

            specific_ids = None
            if self.specific_ids_selector_id:
                specific_ids = locals()[f"arg{arg_offset}"]
                arg_offset += 1

            color_scheme_data = locals()[f"arg{arg_offset}"]
            arg_offset += 1

            colorize_constraints = locals()[f"arg{arg_offset}"]

            is_dark_mode = "dark" in (color_scheme_data or {})

            if not stored_data:
                self.logger.debug("No stored data")
                return [no_update] * len(outputs)

            if self._result_selector_ids and not selected_result:
                self.logger.debug("No selected result")
                return [no_update] * len(outputs)

            storage_manager = create_virtual_storage_manager(stored_data)
            result = storage_manager.load_result(selected_result) if selected_result else None
            if not result:
                self.logger.debug("No result")
                return [no_update] * len(outputs)

            df = result.get_all_data()

            # Store original index for set membership checking
            original_indices = df.index.tolist()
            df["id"] = original_indices  # Add 'id' column for row selection

            # Apply set filtering
            if selected_set:
                set_data = result.get_set(selected_set)
                df = df.iloc[set_data.indices]

            # Apply specific IDs filtering/highlighting
            if specific_ids:
                df = df[df["id"].isin(specific_ids)]

            # Add set membership columns only for selected sets
            all_sets = result.list_sets()

            # Determine which sets to display as columns
            sets_to_show = []
            if selected_sets_to_display:
                sets_to_show = [s for s in selected_sets_to_display if s in all_sets]
            else:
                sets_to_show = all_sets

            # Add set membership columns only for sets to show
            for set_name in sets_to_show:
                current_set = result.get_set(set_name)
                df[f"{set_name}"] = df["id"].apply(lambda x: str(x in current_set.indices))

            # Apply server-side filtering
            # print("FILTERING WITH", filter_query)
            if filter_query:
                df = self._filter_dataframe(df, filter_query)

            # Sorting
            if sort_by:
                df = self._sort_dataframe(df, sort_by)

            # Pagination
            page_current = page_current or 0
            page_size = page_size or 20
            paginated_df = df.iloc[page_current * page_size : (page_current + 1) * page_size]
            page_count = math.ceil(len(df) / page_size)

            categories = {
                "Variables": result.design_variables.columns,
                "Objectives": result.objectives.columns,
                "Inequality Constraints": result.inequality_constraints.columns,
                "Equality Constraints": result.equality_constraints.columns,
                "Observables": result.observables.columns,
            }

            columns = [
                {
                    "name": [category, col],
                    "id": col,
                    "hideable": True,
                }
                for category, cols in categories.items()
                for col in cols
            ]

            # Add set columns to the columns definition only for sets to show
            set_columns = [
                {
                    "name": ["Sets", f"{s}"],
                    "id": f"{s}",
                    "type": "text",
                    "hideable": True,
                }
                for s in sets_to_show
            ]
            columns.extend(set_columns)

            # Add an 'id' column for internal use by DataTable, if not already present
            if "id" not in [col["id"] for col in columns]:
                columns.insert(0, {"name": ["", "id"], "id": "id", "type": "numeric"})

            data = paginated_df.to_dict("records")

            # Define theme-dependent styles
            if is_dark_mode:
                background_color = dmc.DEFAULT_THEME["colors"]["dark"][7]
                text_color = dmc.DEFAULT_THEME["colors"]["gray"][3]
                header_background_color = dmc.DEFAULT_THEME["colors"]["dark"][6]
                border_color = dmc.DEFAULT_THEME["colors"]["dark"][4]
                selected_row_background_color = dmc.DEFAULT_THEME["colors"]["indigo"][9]
                filter_background_color = dmc.DEFAULT_THEME["colors"]["dark"][6]
                accent_color = dmc.DEFAULT_THEME["colors"]["indigo"][5]
            else:
                background_color = "#ffffff"
                text_color = dmc.DEFAULT_THEME["colors"]["gray"][7]
                header_background_color = dmc.DEFAULT_THEME["colors"]["gray"][0]
                border_color = dmc.DEFAULT_THEME["colors"]["gray"][3]
                selected_row_background_color = dmc.DEFAULT_THEME["colors"]["blue"][0]
                filter_background_color = dmc.DEFAULT_THEME["colors"]["gray"][0]
                accent_color = dmc.DEFAULT_THEME["colors"]["blue"][5]

            style_data = {
                "backgroundColor": background_color,
                "color": text_color,
                "border": f"1px solid {border_color}",
                "fontFamily": "Inter, sans-serif",
                "fontSize": "14px",
            }
            style_header = {
                "backgroundColor": header_background_color,
                "color": text_color,
                "fontWeight": "600",
                "border": f"1px solid {border_color}",
                "fontFamily": "Inter, sans-serif",
                "fontSize": "14px",
                "padding": "10px",
            }
            style_table = {
                "overflowX": "auto",
                "minWidth": "100%",
                "border": f"1px solid {border_color}",
                "borderRadius": "8px",
            }
            style_filter = {
                "backgroundColor": filter_background_color,
                "color": text_color,
                "border": f"1px solid {border_color}",
                "padding": "5px",
                "fontFamily": "Inter, sans-serif",
            }
            style_data_conditional = [
                {
                    "if": {"row_index": "odd"},
                    "backgroundColor": background_color,  # Keep it clean, maybe slight variation if needed but flat is modern
                },
                {
                    "if": {"state": "selected"},
                    "backgroundColor": selected_row_background_color,
                    "border": f"1px solid {accent_color}",
                },
            ]

            if colorize_constraints:
                # Define colors for constraints
                # Using standard red/green for violation/satisfaction
                # Adjust opacity/shade for better readability if needed
                violation_color = "rgba(255, 0, 0, 0.2)"
                satisfaction_color = "rgba(0, 255, 0, 0.2)"

                # Inequality constraints: > 0 is violation, <= 0 is satisfaction
                for col in result.inequality_constraints.columns:
                    style_data_conditional.extend(
                        [
                            {
                                "if": {"filter_query": f"{{{col}}} > 0", "column_id": col},
                                "backgroundColor": violation_color,
                            },
                            {
                                "if": {"filter_query": f"{{{col}}} <= 0", "column_id": col},
                                "backgroundColor": satisfaction_color,
                            },
                        ]
                    )

                # Equality constraints: != 0 (with tolerance) is violation, == 0 is satisfaction
                tolerance = 1e-6
                for col in result.equality_constraints.columns:
                    style_data_conditional.extend(
                        [
                            {
                                "if": {
                                    "filter_query": f"{{{col}}} > {tolerance} || {{{col}}} < -{tolerance}",
                                    "column_id": col,
                                },
                                "backgroundColor": violation_color,
                            },
                            {
                                "if": {
                                    "filter_query": f"{{{col}}} >= -{tolerance} && {{{col}}} <= {tolerance}",
                                    "column_id": col,
                                },
                                "backgroundColor": satisfaction_color,
                            },
                        ]
                    )
            style_header_conditional = []  # Removed odd/even header styling for cleaner look

            style_cell_conditional = [{"if": {"column_id": "id"}, "width": "60px"}]

            # Construct return_values in the exact order of outputs
            return_values = [data, columns, page_count]
            if self.output_selected_rows_id:
                return_values.append(no_update)
            if self.output_filtered_data_id:
                return_values.append(data)

            # Append all style outputs after the data and columns, and optional outputs
            return_values.append(style_data)
            return_values.append(style_header)
            return_values.append(style_table)
            return_values.append(style_filter)
            return_values.append(style_data_conditional)
            return_values.append(style_header_conditional)
            return_values.append(style_cell_conditional)

            return return_values

        # Callback to output selected rows
        if self.output_selected_rows_id:

            @app.callback(
                Output(self.output_selected_rows_id, "data"),
                Input(self.ids("data-table"), "selected_rows"),
                State(self.ids("data-table"), "data"),
                prevent_initial_call=True,
            )
            def update_selected_rows_store(selected_rows_indices, table_data):
                if selected_rows_indices is None:
                    return []

                # Extract the actual data for the selected rows
                selected_data = [table_data[i] for i in selected_rows_indices]
                return selected_data

        # Callback to output filtered data (e.g., from column filtering)
        if self.output_filtered_data_id:

            @app.callback(
                Output(self.output_filtered_data_id, "data", allow_duplicate=True),
                Input(self.ids("data-table"), "derived_viewport_data"),
                prevent_initial_call=True,
            )
            def update_filtered_data_store(derived_viewport_data):
                return derived_viewport_data

        # New callbacks for advanced filtering controls

        @app.callback(
            Output(self.ids("filter-query-input"), "disabled"),
            Output(self.ids("filter-query-output"), "style"),
            Input(self.ids("filter-query-read-write"), "value"),
        )
        def query_input_output(val):
            if val == "read":
                return True, {"display": "block"}
            else:
                return False, {"display": "none"}

        @app.callback(
            Output(self.ids("data-table"), "filter_query"),
            Input(self.ids("filter-query-input"), "value"),
            prevent_initial_call=True,
        )
        def write_query(query):
            if query is None:
                return no_update
            return query

        @app.callback(
            Output(self.ids("filter-query-output"), "children"),
            Input(self.ids("data-table"), "filter_query"),
        )
        def read_query(query):
            if query is None:
                return "No filter query"
            return dmc.Code(f'filter_query = "{query}"')

        @app.callback(
            Output(self.ids("datatable-query-structure"), "children"),
            Input(self.ids("data-table"), "derived_filter_query_structure"),
        )
        def display_query(query):
            if query is None:
                return ""
            return dmc.Accordion(
                children=[
                    dmc.AccordionItem(
                        [
                            dmc.AccordionControl("Derived filter query structure"),
                            dmc.AccordionPanel(
                                dmc.Code(
                                    json.dumps(query, indent=4),
                                    block=True,
                                    style={"whiteSpace": "pre-wrap"},
                                )
                            ),
                        ],
                        value="structure",
                    )
                ]
            )
