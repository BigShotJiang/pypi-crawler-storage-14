"""Reusable column selector component with automatic callback management."""

from __future__ import annotations

from typing import Literal

import dash
import dash_mantine_components as dmc
from dash import Input, Output, callback
from dash_iconify import DashIconify

import optiscope.dash_app.core.glossary as glo
from optiscope.dash_app.components.base import BaseComponent
from optiscope.dash_app.core import storage_helpers
from optiscope.dash_app.core.compatibility import create_virtual_storage_manager
from optiscope.dash_app.utils.helpers import get_column_info


class ColumnSelector(BaseComponent):
    """
    Reusable component for selecting columns from optimization results.

    This component provides a MultiSelect dropdown that automatically populates
    with available columns based on the data in the global data store or selected results.

    Attributes:
        column_types: List of column types to include (e.g., ["variables", "objectives"])
        label: Label text to display above the selector
        placeholder: Placeholder text for the selector
        icon: Icon to display in the selector (optional)
        default_count: Number of columns to select by default (default: 3)
        searchable: Whether the selector is searchable (default: True)
        clearable: Whether the selector is clearable (default: True)
    """

    def __init__(
        self,
        component_id: str,
        column_types: list[
            Literal[
                "variables",
                "objectives",
                "inequality_constraints",
                "equality_constraints",
                "observables",
                "sets",
            ]
        ],
        label: str,
        placeholder: str = "Select columns",
        icon: str | None = None,
        default_count: int = 3,
        searchable: bool = True,
        clearable: bool = True,
        result_selector_id: str | None = None,
    ):
        """
        Initialize the column selector component.

        Args:
            component_id: Unique identifier for this component instance
            column_types: List of column types to include
            label: Label text to display above the selector
            placeholder: Placeholder text for the selector
            icon: Icon name to display in the selector (optional)
            default_count: Number of columns to select by default
            searchable: Whether the selector is searchable
            clearable: Whether the selector is clearable
        """
        super().__init__(component_id)
        self.column_types = column_types
        self.label = label
        self.placeholder = placeholder
        self.icon = icon
        self.default_count = default_count
        self.searchable = searchable
        self.clearable = clearable
        self.result_selector_id = result_selector_id

    def layout(self, **kwargs) -> dmc.Stack:
        """
        Return the Dash layout for this component.

        Returns:
            Dash component containing the selector
        """
        # Build the selector with optional icon
        selector_props = {
            "id": self.ids("selector"),
            "placeholder": self.placeholder,
            "data": [],
            "value": [],
            "searchable": self.searchable,
            "clearable": self.clearable,
            "renderOption": {"function": "renderOptionSelect"},
            "persistence": True,
            "persistence_type": "session",
        }

        if self.icon:
            selector_props["leftSection"] = dmc.ThemeIcon(
                DashIconify(icon=self.icon),
                variant="light",
            )

        return dmc.Stack(
            [
                dmc.Text(self.label, fw="bold", mb=5),
                dmc.MultiSelect(**selector_props),
            ],
            gap=0,
        )

    def register_callbacks(self, app: dash.Dash | None = None) -> None:
        """
        Register the callback for updating selector options.

        This callback watches the global data store and updates the available
        options and default selections when data changes.

        Args:
            app: The Dash application instance
        """

        inputs = [Input(glo.REF_STORE_STR, "data")]

        if self.result_selector_id is not None:
            inputs.append(Input(self.result_selector_id, "value"))

        @callback(
            Output(self.ids("selector"), "data"), Output(self.ids("selector"), "value"), *inputs
        )
        def update_selector_options(stored_data, selected_results_keys=None):
            """Update selector options based on global data store."""
            if not stored_data:
                return [], []

            if selected_results_keys:
                # Ensure selected_result_keys is a list for consistent processing
                if not isinstance(selected_results_keys, list):
                    selected_result_keys = [selected_results_keys]

                storage_manager = create_virtual_storage_manager(stored_data)

                result = storage_manager.load_result(selected_result_keys[0])
            else:
                all_results = storage_helpers.get_all_results_from_sources(stored_data)

                result_keys = [k for k in all_results]
                if not result_keys:
                    return [], []

                # Get first source, first result
                first_source = list(all_results.keys())[0]
                first_result = all_results[first_source][0]

                result = storage_helpers.load_result_from_source(first_source, first_result)

            # Get column info for specified column types
            column_info = get_column_info(result, self.column_types)

            # Select first N by default (or all if less than N)
            default_values = [col["value"] for col in column_info[: self.default_count]]

            return column_info, default_values

    def get_value_id(self) -> str:
        """
        Get the ID for the selector's value (for use in other callbacks).

        Returns:
            ID string for the selector component
        """
        return self.ids("selector")


class ColumnSelectorGroup:
    """
    Helper class to create and manage multiple related column selectors.

    This class simplifies creating multiple selectors that need to be used together
    (e.g., for variables, objectives, constraints, and observables on the same page).
    """

    def __init__(self, page_id: str):
        """
        Initialize the column selector group.

        Args:
            page_id: Unique identifier for the page using this group
        """
        self.page_id = page_id
        self.selectors: dict[str, ColumnSelector] = {}

    def add_selector(
        self,
        selector_id: str,
        column_types: list[
            Literal[
                "variables",
                "objectives",
                "inequality_constraints",
                "equality_constraints",
                "observables",
                "sets",
            ]
        ],
        label: str,
        placeholder: str = "Select columns",
        icon: str | None = None,
        default_count: int = 3,
        **kwargs,
    ) -> ColumnSelector:
        """
        Add a new column selector to the group.

        Args:
            selector_id: Identifier for this specific selector
            column_types: List of column types to include
            label: Label text to display above the selector
            placeholder: Placeholder text for the selector
            icon: Icon name to display in the selector (optional)
            default_count: Number of columns to select by default

        Returns:
            The created ColumnSelector instance
        """
        component_id = f"{self.page_id}-{selector_id}"
        selector = ColumnSelector(
            component_id=component_id,
            column_types=column_types,
            label=label,
            placeholder=placeholder,
            icon=icon,
            default_count=default_count,
            **kwargs,
        )
        self.selectors[selector_id] = selector
        return selector

    def register_all_callbacks(self, app: dash.Dash) -> None:
        """
        Register callbacks for all selectors in the group.

        Args:
            app: The Dash application instance
        """
        for selector in self.selectors.values():
            selector.register_callbacks(app)

    def get_selector(self, selector_id: str) -> ColumnSelector:
        """
        Get a selector by its ID.

        Args:
            selector_id: The ID of the selector to retrieve

        Returns:
            The ColumnSelector instance
        """
        return self.selectors[selector_id]

    def get_all_value_ids(self) -> dict[str, str]:
        """
        Get all selector value IDs for use in callbacks.

        Returns:
            Dictionary mapping selector IDs to their value IDs
        """
        return {sid: selector.get_value_id() for sid, selector in self.selectors.items()}
