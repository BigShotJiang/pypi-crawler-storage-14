"""Detailed layout components for building page sections."""

from __future__ import annotations

from typing import Any, Literal

import dash_mantine_components as dmc
from dash_iconify import DashIconify

from optiscope import __version__


def create_page_header(
    title: str,
    description: str | None = None,
    icon: str | None = None,
    actions: list[Any] | None = None,
    divider: bool = True,
    **kwargs,
) -> dmc.Stack:
    """
    Create a standardized page header with title, description, and action buttons.

    Args:
        title: Page title text
        description: Optional description text below title
        icon: Optional icon name to display before title
        actions: Optional list of action components (buttons, etc.)
        divider: Whether to add a divider below the header
        **kwargs: Additional kwargs for the Stack container

    Returns:
        A dmc.Stack component with the header content

    Example:
        >>> header = create_page_header(
        ...     title="Data Visualization",
        ...     description="Explore your optimization results",
        ...     icon="mdi:chart-line",
        ...     actions=[dmc.Button("Export", leftSection=DashIconify(icon="mdi:download"))]
        ... )
    """
    header_components = []

    # Title row with optional icon and actions
    title_row = []

    if icon:
        title_row.append(DashIconify(icon=icon, width=32, style={"marginRight": "10px"}))

    title_row.append(dmc.Title(title, order=1, style={"flex": 1}))

    if actions:
        title_row.append(dmc.Group(actions, gap="sm"))

    header_components.append(dmc.Group(title_row, align="center"))

    # Description
    if description:
        header_components.append(dmc.Text(description, size="lg", c="gray"))

    # Divider
    if divider:
        header_components.append(dmc.Divider(mt="md"))

    return dmc.Stack(header_components, gap="sm", **kwargs)


def create_section_card(
    title: str,
    content: Any,
    icon: str | None = None,
    collapsible: bool = False,
    default_opened: bool = True,
    actions: list[Any] | None = None,
    **card_kwargs,
) -> dmc.Card:
    """
    Create a card with a title header and content section.

    Args:
        title: Section title
        content: Content to display (can be a list or single component)
        icon: Optional icon for the title
        collapsible: Whether the content can be collapsed
        default_opened: Initial state if collapsible (default: True)
        actions: Optional action buttons in the header
        **card_kwargs: Additional kwargs for dmc.Card

    Returns:
        A dmc.Card with title and content

    Example:
        >>> card = create_section_card(
        ...     title="Results",
        ...     content=dmc.Text("Your content here"),
        ...     icon="mdi:chart-box",
        ...     collapsible=True
        ... )
    """
    # Ensure content is a list
    if not isinstance(content, list):
        content = [content]

    # Build header
    header_items = []
    if icon:
        header_items.append(DashIconify(icon=icon, width=20, style={"marginRight": "8px"}))
    header_items.append(dmc.Title(title, order=4, style={"flex": 1}))
    if actions:
        header_items.append(dmc.Group(actions, gap="xs"))

    header = dmc.Group(header_items, align="center", mb="md")

    # Build card content
    if collapsible:
        card_content = [
            header,
            dmc.Collapse(content, opened=default_opened),
        ]
    else:
        card_content = [header, *content]

    return dmc.Card(
        card_content,
        withBorder=True,
        shadow="sm",
        p="md",
        **card_kwargs,
    )


def create_metric_cards(
    metrics: list[dict[str, Any]],
    columns: int = 4,
    **grid_kwargs,
) -> dmc.Grid:
    """
    Create a grid of metric/stat cards.

    Args:
        metrics: List of dictionaries, each with:
            - 'label': Metric name
            - 'value': Metric value (string or number)
            - 'icon': Optional icon name
            - 'color': Optional color (default: "blue")
            - 'description': Optional description text
        columns: Number of columns in the grid (default: 4)
        **grid_kwargs: Additional kwargs for dmc.Grid

    Returns:
        A dmc.Grid with metric cards

    Example:
        >>> metrics = [
        ...     {"label": "Total Points", "value": "1,234", "icon": "mdi:dots-grid"},
        ...     {"label": "Pareto Solutions", "value": "42", "icon": "mdi:star", "color": "green"}
        ... ]
        >>> grid = create_metric_cards(metrics, columns=3)
    """
    span = 12 // columns

    metric_cards = []
    for metric in metrics:
        icon = metric.get("icon")
        color = metric.get("color", "blue")
        description = metric.get("description")

        card_content = []

        # Icon and label row
        if icon:
            card_content.append(
                dmc.Group(
                    [
                        DashIconify(icon=icon, width=24, color=color),
                        dmc.Text(metric["label"], size="sm", c="gray"),
                    ],
                    gap="xs",
                )
            )
        else:
            card_content.append(dmc.Text(metric["label"], size="sm", c="gray"))

        # Value
        card_content.append(
            dmc.Text(
                str(metric["value"]),
                size="xl",
                fw="bold",
                c=color,
            )
        )

        # Description
        if description:
            card_content.append(dmc.Text(description, size="xs", c="gray"))

        metric_cards.append(
            dmc.GridCol(
                dmc.Card(
                    dmc.Stack(card_content, gap="xs"),
                    withBorder=True,
                    p="md",
                ),
                span=span,
            )
        )

    return dmc.Grid(metric_cards, **grid_kwargs)


def create_empty_state(
    message: str = "No data available",
    icon: str = "mdi:database-off-outline",
    action: Any | None = None,
    **stack_kwargs,
) -> dmc.Stack:
    """
    Create a standardized empty state display.

    Args:
        message: Message to display
        icon: Icon to show (default: database off icon)
        action: Optional action component (e.g., upload button)
        **stack_kwargs: Additional kwargs for the Stack container

    Returns:
        A centered empty state component

    Example:
        >>> empty = create_empty_state(
        ...     message="No results loaded yet",
        ...     action=dmc.Button("Upload Data", leftSection=DashIconify(icon="mdi:upload"))
        ... )
    """
    components = [
        DashIconify(icon=icon, width=64, color="gray"),
        dmc.Text(message, size="lg", c="gray", ta="center"),
    ]

    if action:
        components.append(action)

    return dmc.Stack(
        components,
        align="center",
        gap="md",
        py="xl",
        **stack_kwargs,
    )


def create_control_panel(
    controls: list[dict[str, Any]],
    title: str | None = None,
    columns: int = 1,
    **card_kwargs,
) -> dmc.Card:
    """
    Create a panel of labeled controls/inputs.

    Args:
        controls: List of dictionaries, each with:
            - 'label': Control label
            - 'component': The control component
            - 'description': Optional help text
        title: Optional panel title
        columns: Number of columns for controls (default: 1)
        **card_kwargs: Additional kwargs for dmc.Card

    Returns:
        A dmc.Card with organized controls

    Example:
        >>> controls = [
        ...     {
        ...         "label": "X Axis",
        ...         "component": dmc.Select(data=["var1", "var2"]),
        ...         "description": "Select variable for X axis"
        ...     }
        ... ]
        >>> panel = create_control_panel(controls, title="Plot Controls")
    """
    content = []

    if title:
        content.append(dmc.Title(title, order=5, mb="md"))

    # Create control items
    control_items = []
    for control in controls:
        items = [
            dmc.Text(control["label"], size="sm", fw="bold", mb=4),
            control["component"],
        ]

        if "description" in control:
            items.append(dmc.Text(control["description"], size="xs", c="gray", mt=4))

        control_items.append(dmc.GridCol(dmc.Stack(items, gap="xs"), span=12 // columns))

    content.append(dmc.Grid(control_items, gutter="md"))

    return dmc.Card(
        dmc.Stack(content, gap="sm"),
        withBorder=True,
        p="md",
        **card_kwargs,
    )


def create_accordion_sections(
    sections: list[dict[str, Any]],
    multiple: bool = False,
    default_value: str | list[str] | None = None,
    **accordion_kwargs,
) -> dmc.Accordion:
    """
    Create an accordion with multiple collapsible sections.

    Args:
        sections: List of dictionaries, each with:
            - 'value': Unique identifier
            - 'title': Section title
            - 'content': Section content
            - 'icon': Optional icon
        multiple: Allow multiple sections open at once
        default_value: Initially opened section(s)
        **accordion_kwargs: Additional kwargs for dmc.Accordion

    Returns:
        A dmc.Accordion component

    Example:
        >>> sections = [
        ...     {
        ...         "value": "filters",
        ...         "title": "Filters",
        ...         "icon": "mdi:filter",
        ...         "content": dmc.Text("Filter controls")
        ...     }
        ... ]
        >>> accordion = create_accordion_sections(sections, multiple=True)
    """
    items = []
    for section in sections:
        control = dmc.AccordionControl(
            section["title"],
            icon=DashIconify(icon=section["icon"], width=20) if "icon" in section else None,
        )
        panel = dmc.AccordionPanel(section["content"])
        items.append(dmc.AccordionItem([control, panel], value=section["value"]))

    return dmc.Accordion(
        items,
        multiple=multiple,
        value=default_value,
        **accordion_kwargs,
    )


def create_tabbed_section(
    tabs: list[dict[str, Any]],
    tab_position: Literal["flex-start", "center", "flex-end", "space-between"] = "flex-start",
    default_tab: str | None = None,
    variant: Literal["default", "outline", "pills"] = "default",
    orientation: Literal["horizontal", "vertical"] = "horizontal",
    **tabs_kwargs,
) -> dmc.Tabs:
    """
    Create a tabbed section with customizable tabs.

    Args:
        tabs: List of dictionaries, each with:
            - 'value': Unique identifier for the tab
            - 'label': Display label for the tab
            - 'icon': Optional icon name for the tab
            - 'content': Content to display when tab is active
        tab_position: Alignment of tab labels (default: "left")
        default_tab: Value of the tab to show by default (defaults to first tab)
        variant: Visual style of tabs ("default", "outline", or "pills")
        orientation: Tab orientation ("horizontal" or "vertical")
        **tabs_kwargs: Additional keyword arguments to pass to dmc.Tabs

    Returns:
        A dmc.Tabs component with the specified configuration

    Example:
        >>> tabs = [
        ...     {
        ...         "value": "tab1",
        ...         "label": "First Tab",
        ...         "icon": "mdi:chart-line",
        ...         "content": dmc.Text("Content for tab 1")
        ...     },
        ...     {
        ...         "value": "tab2",
        ...         "label": "Second Tab",
        ...         "content": dmc.Text("Content for tab 2")
        ...     }
        ... ]
        >>> section = create_tabbed_section(tabs, variant="pills")
    """
    if not tabs:
        raise ValueError("At least one tab must be provided")

    # Set default tab to first tab if not specified
    if default_tab is None:
        default_tab = tabs[0]["value"]

    # Create tab list items
    tab_list_items = []
    for tab_config in tabs:
        tab_label = tab_config["label"]

        # Add icon if provided
        if "icon" in tab_config and tab_config["icon"]:
            left_section = DashIconify(icon=tab_config["icon"], width=20)
            tab_list_items.append(
                dmc.TabsTab(tab_label, value=tab_config["value"], leftSection=left_section)
            )
        else:
            tab_list_items.append(dmc.TabsTab(tab_label, value=tab_config["value"]))

    # Create tab panels
    tab_panels = []
    for tab_config in tabs:
        tab_panels.append(dmc.TabsPanel(tab_config["content"], value=tab_config["value"]))

    return dmc.Tabs(
        [
            dmc.TabsList(tab_list_items, justify=tab_position),
            *tab_panels,
        ],
        value=default_tab,
        variant=variant,
        orientation=orientation,
        **tabs_kwargs,
    )


def get_nav_content(page_registry, stored_data: dict | None = None):
    # Define your category display names and order
    category_names = {
        "visualization": "Visualization",
        "analysitcs": "Analytics",
        "data": "Data Management",
        "settings": "Settings",
        "debug": "Debug",
        # Add more categories as needed
    }

    category_order = {
        "visualization": 2,
        "analysitcs": 3,
        "data": 1,
        "settings": 4,
        "debug": 5,
        # Add order for categories as needed
    }

    category_icons = {
        "visualization": "mdi:chart-multiple",
        "data": "mdi:cable-data",
        "debug": "mdi:bug-outline",
    }

    # Define categories that should always be at the bottom
    bottom_categories = ["settings", "debug"]

    # --- SEPARATION LOGIC ---
    from collections import defaultdict

    top_pages_by_category = defaultdict(list)
    bottom_pages_by_category = defaultdict(list)

    for page in page_registry.values():
        if page.get("hidden_from_nav"):
            continue

        category = page.get("category", "")
        if page.get("order", float("inf")) is None:
            page["order"] = float("inf")

        if category in bottom_categories or page.get("show_at_bottom"):
            bottom_pages_by_category[category].append(page)
        else:
            top_pages_by_category[category].append(page)

    # --- BUILDER FUNCTION ---
    def build_nav_links(pages_by_cat, expand_categories: bool = False):
        # Sort pages within each category
        for category in pages_by_cat:
            pages_by_cat[category].sort(key=lambda p: p.get("order", float("inf")))

        # Create a list of tuples (order, is_category, data)
        items = []
        if "" in pages_by_cat:  # Handle pages without a category first
            for page in pages_by_cat[""]:
                order = page.get("order", float("inf"))
                items.append((order, False, page))

        for category, pages in pages_by_cat.items():
            if category == "":
                continue
            order = category_order.get(category, float("inf"))
            items.append((order, True, (category, pages)))

        items.sort(key=lambda x: x[0])

        # Build the final list of dmc components
        components = []
        for order, is_category, data in items:
            if is_category:
                category, pages = data
                category_label = category_names.get(category, category.title())

                # Check if all pages in category are disabled
                page_nav_links = []
                all_disabled = True

                for page in pages:
                    # Check page availability
                    page_module = page.get("_page_module_instance")
                    is_available = True

                    if page_module and hasattr(page_module, "is_available"):
                        try:
                            is_available, _ = page_module.is_available(stored_data=stored_data)
                        except Exception:
                            # If is_available fails, assume page is available
                            is_available = True

                    if is_available:
                        all_disabled = False

                    page_nav_links.append(
                        dmc.NavLink(
                            label=page["name"],
                            href=page["path"],
                            leftSection=DashIconify(icon=page["icon"], width=20),
                            disabled=not is_available,
                        )
                    )

                components.append(
                    dmc.NavLink(
                        label=category_label,
                        childrenOffset=14,
                        opened=expand_categories,
                        disabled=all_disabled,
                        children=page_nav_links,
                        leftSection=DashIconify(icon=category_icons.get(category), width=20)
                        if category in category_icons
                        else None,
                    )
                )
            else:  # is a page
                page = data

                # Check page availability
                page_module = page.get("_page_module_instance")
                is_available = True

                if page_module and hasattr(page_module, "is_available"):
                    try:
                        is_available, _ = page_module.is_available(stored_data=stored_data)
                    except Exception:
                        # If is_available fails, assume page is available
                        is_available = True

                components.append(
                    dmc.NavLink(
                        label=page["name"],
                        href=page["path"],
                        leftSection=DashIconify(icon=page["icon"], width=18),
                        disabled=not is_available,
                        styles={
                            "root": {
                                "borderRadius": "8px",
                                "marginBottom": "4px",
                                "&:hover": {
                                    "backgroundColor": "var(--mantine-color-blue-0)",
                                    "transform": "translateX(2px)",
                                    "transition": "all 0.2s ease",
                                },
                            },
                            "label": {
                                "fontSize": "14px",
                                "fontWeight": 500,
                            },
                        },
                    )
                )
        return components

    # --- FINAL ASSEMBLY ---
    nav_children = build_nav_links(top_pages_by_category, expand_categories=True)
    bottom_nav = build_nav_links(bottom_pages_by_category, expand_categories=False)

    bottom_nav.extend(
        [dmc.Divider(mb="xs", mt="sm"), dmc.Text(f"Optiscope v{__version__}", size="xs", c="gray")]
    )  # Separator before version info

    return dmc.Stack(
        [dmc.ScrollArea(children=nav_children), dmc.ScrollArea(children=bottom_nav)],
        justify="space-between",
        h="100%",
    )


def create_navigation_component(page_registry):
    return dmc.AppShellNavbar(
        id="app-nav-bar",
        children=get_nav_content(page_registry),
        p="xs",
    )


def in_paper(content, **kwargs):
    options = {
        "radius": "sm",
        "p": "lg",
        "shadow": "sm",
        "withBorder": False,
    } | kwargs

    return dmc.Paper(content, **options)
