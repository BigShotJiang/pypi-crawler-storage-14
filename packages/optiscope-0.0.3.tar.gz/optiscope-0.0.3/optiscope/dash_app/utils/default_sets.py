"""Utility functions for creating default sets for optimization results."""

import logging

from optiscope.analysis.smart_pareto import smart_pareto_filter
from optiscope.core.data_types import DataTypeCategory
from optiscope.dash_app.core import storage_helpers

logger = logging.getLogger(__name__)


def create_default_sets(source_id: str, result_key: str) -> None:
    """Creates feasible, non-feasible, pareto_front, and optimal sets for a given result.

    Args:
        source_id: The ID of the data source containing the result
        result_key: The key identifying the specific result within the source
    """
    try:
        optimization_result = storage_helpers.load_result_from_source(source_id, result_key)
        storage = storage_helpers.get_source_storage(source_id)

        if optimization_result is None or storage is None:
            return

        # Feasible set
        feasible_set = optimization_result.check_feasibility(set_name="feasible")
        storage.save_set(result_key, "feasible", feasible_set)

        # Non-feasible set (all points not in feasible)
        all_indices = set(range(optimization_result.n_points))
        feasible_indices = set(feasible_set.indices)
        non_feasible_indices = list(all_indices - feasible_indices)
        if non_feasible_indices:
            non_feasible = optimization_result.create_set(
                name="non-feasible",
                indices=non_feasible_indices,
                created_by="default-sets-creator",
                description="Solutions that violate constraints.",
            )
            storage.save_set(result_key, "non-feasible", non_feasible)

        # Pareto front set
        try:
            pareto_set = optimization_result.get_set("pareto_front")
        except:  # noqa: E722
            optimization_result.find_pareto_front(set_name="pareto_front")
            pareto_set = optimization_result.get_set("pareto_front")
            # Optimal set (for now, same as pareto_front, can be refined later)
            storage.save_set(result_key, "pareto", pareto_set)

        if pareto_set.indices:
            optimal_set = optimization_result.create_set(
                name="optimal",
                indices=pareto_set.indices,
                created_by="default-sets-creator",
                description="Solutions identified as optimal (e.g., Pareto front).",
            )
            storage.save_set(result_key, "optimal", optimal_set)

            # Smart Pareto
            pareto_indices = smart_pareto_filter(
                optimization_result.get_set_data("pareto_front", DataTypeCategory.OBJECTIVE),
                epsilon=0.15,
            )

            smart_set = optimization_result.create_set(
                name="smart_pareto", indices=pareto_indices, created_by="smart_filter"
            )
            storage.save_set(result_key, "smart_pareto", smart_set)
        else:
            logger.debug("Not creating smart pareto - no pareto front indices found")

    except Exception as set_creation_error:
        logger.warning(f"Could not create default sets for result: {set_creation_error}")
