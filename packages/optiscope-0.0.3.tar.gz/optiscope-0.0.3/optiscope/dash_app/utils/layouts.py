"""Layout helper utilities for creating common page layouts."""

from __future__ import annotations

from typing import Any, Literal

import dash_mantine_components as dmc
from dash_iconify import DashIconify


def create_grid_layout(
    items: list[Any],
    columns: int = 4,
    rows: int | None = None,
    equal_height: bool = True,
    **grid_kwargs,
) -> dmc.Grid:
    """
    Create a flexible grid layout with any number of columns and rows.

    Args:
        items: List of components to place in grid cells
        columns: Number of columns (default: 4 for 4x4 grid)
        rows: Optional number of rows (auto-calculated if None)
        equal_height: Whether all items should have equal height
        **grid_kwargs: Additional kwargs for dmc.Grid

    Returns:
        A dmc.Grid with the specified layout

    Example:
        >>> # Create a 4x4 grid
        >>> items = [dmc.Card(f"Card {i}") for i in range(16)]
        >>> grid = create_grid_layout(items, columns=4)
        >>>
        >>> # Create a 3x3 grid
        >>> items = [dmc.Card(f"Card {i}") for i in range(9)]
        >>> grid = create_grid_layout(items, columns=3)
    """
    span = 12 // columns

    grid_items = []
    for item in items:
        # Ensure item is wrapped properly
        if not isinstance(item, list):
            item = [item]

        grid_items.append(
            dmc.GridCol(
                item,
                span=span,
                style={"height": "100%"} if equal_height else None,
            )
        )

    return dmc.Grid(grid_items, **grid_kwargs)


def create_two_column_layout(
    left_content: Any,
    right_content: Any,
    left_span: int = 6,
    right_span: int = 6,
    fluid: bool = True,
    **container_kwargs,
) -> dmc.Container:
    """
    Create a two-column grid layout.

    Args:
        left_content: Content for the left column (can be a list or single component)
        right_content: Content for the right column (can be a list or single component)
        left_span: Number of columns for the left side (1-12, default: 6)
        right_span: Number of columns for the right side (1-12, default: 6)
        fluid: Whether container should be fluid (default: True)
        **container_kwargs: Additional keyword arguments to pass to dmc.Container

    Returns:
        A dmc.Container with a two-column grid layout

    Example:
        >>> left = [dmc.Title("Left"), dmc.Text("Content on left")]
        >>> right = [dmc.Title("Right"), dmc.Text("Content on right")]
        >>> layout = create_two_column_layout(left, right, left_span=4, right_span=8)
    """
    # Ensure content is wrapped in a list
    if not isinstance(left_content, list):
        left_content = [left_content]
    if not isinstance(right_content, list):
        right_content = [right_content]

    return dmc.Container(
        [
            dmc.Grid(
                [
                    dmc.GridCol(left_content, span=left_span),
                    dmc.GridCol(right_content, span=right_span),
                ]
            )
        ],
        fluid=fluid,
        **container_kwargs,
    )


def create_tabbed_layout(
    tabs: list[dict[str, Any]],
    tab_position: Literal["left", "right"] = "left",
    default_tab: str | None = None,
    variant: Literal["default", "outline", "pills"] = "default",
    orientation: Literal["horizontal", "vertical"] = "horizontal",
    **tabs_kwargs,
) -> dmc.Tabs:
    """
    Create a tabbed layout with customizable tabs.

    Args:
        tabs: List of dictionaries, each with:
            - 'value': Unique identifier for the tab
            - 'label': Display label for the tab
            - 'icon': Optional icon name for the tab
            - 'content': Content to display when tab is active
        tab_position: Alignment of tab labels ("left" or "right", default: "left")
        default_tab: Value of the tab to show by default (defaults to first tab)
        variant: Visual style of tabs ("default", "outline", or "pills")
        orientation: Tab orientation ("horizontal" or "vertical")
        **tabs_kwargs: Additional keyword arguments to pass to dmc.Tabs

    Returns:
        A dmc.Tabs component with the specified configuration

    Example:
        >>> tabs = [
        ...     {
        ...         "value": "tab1",
        ...         "label": "First Tab",
        ...         "icon": "mdi:home",
        ...         "content": dmc.Text("Content for tab 1")
        ...     },
        ...     {
        ...         "value": "tab2",
        ...         "label": "Second Tab",
        ...         "content": dmc.Text("Content for tab 2")
        ...     }
        ... ]
        >>> layout = create_tabbed_layout(tabs, tab_position="right", variant="pills")
    """
    if not tabs:
        raise ValueError("At least one tab must be provided")

    # Set default tab to first tab if not specified
    if default_tab is None:
        default_tab = tabs[0]["value"]

    # Create tab list items
    tab_list_items = []
    for tab_config in tabs:
        tab_label = tab_config["label"]

        # Add icon if provided
        if "icon" in tab_config and tab_config["icon"]:
            left_section = DashIconify(icon=tab_config["icon"], width=20)
            tab_list_items.append(
                dmc.TabsTab(tab_label, value=tab_config["value"], leftSection=left_section)
            )
        else:
            tab_list_items.append(dmc.TabsTab(tab_label, value=tab_config["value"]))

    # Create tab panels
    tab_panels = []
    for tab_config in tabs:
        tab_panels.append(dmc.TabsPanel(tab_config["content"], value=tab_config["value"]))

    # Determine justify based on position
    justify = "flex-end" if tab_position == "right" else "flex-start"

    return dmc.Tabs(
        [
            dmc.TabsList(tab_list_items, justify=justify),
            *tab_panels,
        ],
        value=default_tab,
        variant=variant,
        orientation=orientation,
        **tabs_kwargs,
    )


def create_sidebar_layout(
    sidebar_content: Any,
    main_content: Any,
    sidebar_width: int = 300,
    sidebar_position: Literal["left", "right"] = "left",
    sticky_sidebar: bool = False,
    **container_kwargs,
) -> dmc.Container:
    """
    Create a layout with a sidebar and main content area.

    Args:
        sidebar_content: Content for the sidebar
        main_content: Content for the main area
        sidebar_width: Width of sidebar in pixels (default: 300)
        sidebar_position: Position of sidebar ("left" or "right", default: "left")
        sticky_sidebar: Whether sidebar should stick on scroll
        **container_kwargs: Additional kwargs for the Container

    Returns:
        A dmc.Container with sidebar layout

    Example:
        >>> layout = create_sidebar_layout(
        ...     sidebar_content=[dmc.Text("Filters"), dmc.Select(data=[...])],
        ...     main_content=dcc.Graph(...),
        ...     sidebar_width=250,
        ...     sticky_sidebar=True
        ... )
    """
    if not isinstance(sidebar_content, list):
        sidebar_content = [sidebar_content]
    if not isinstance(main_content, list):
        main_content = [main_content]

    sidebar_style = {"width": f"{sidebar_width}px"}
    if sticky_sidebar:
        sidebar_style["position"] = "sticky"
        sidebar_style["top"] = "20px"

    main_style = {"flex": 1}

    sidebar_component = dmc.Box(sidebar_content, style=sidebar_style)
    main_component = dmc.Box(main_content, style=main_style)

    if sidebar_position == "left":
        layout = [sidebar_component, main_component]
    else:
        layout = [main_component, sidebar_component]

    return dmc.Container(
        dmc.Group(layout, align="flex-start", gap="md"),
        fluid=True,
        **container_kwargs,
    )
