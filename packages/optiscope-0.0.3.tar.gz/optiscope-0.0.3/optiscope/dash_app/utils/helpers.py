"""Helper utilities for Dash app components."""

from __future__ import annotations

from typing import Literal

from dash_iconify import DashIconify

from optiscope.core.data_model import OptimizationResult


def get_column_info(
    result: OptimizationResult,
    column_types: list[
        Literal[
            "variables",
            "objectives",
            "inequality_constraints",
            "equality_constraints",
            "observables",
            "sets",
        ]
    ],
) -> list[dict[str, str]]:
    """
    Get column information with icons for dropdown selectors.

    Args:
        result: OptimizationResult object
        column_types: List of column types to include

    Returns:
        List of dictionaries with 'label', 'value', and 'icon' keys
    """
    icon_map = {
        "variables": "tabler:box-align-bottom",  # Input box with arrow
        "objectives": "tabler:target",  # Target icon
        "inequality_constraints": "tabler:math-lower",  # Less than or equal
        "equality_constraints": "tabler:math-equal-lower",  # Equal sign
        "observables": "tabler:eye",  # Eye/observable icon
        "sets": "tabler:layers",  # Layers icon
    }

    type_map = {
        "variables": "var",
        "objectives": "obj",
        "inequality_constraints": "con",
        "equality_constraints": "con",
        "observables": "obs",
        "sets": "set",
    }

    column_info = []

    for col_type in column_types:
        if col_type == "variables":
            columns = result.design_variables.columns.tolist()
        elif col_type == "objectives":
            columns = result.objectives.columns.tolist()
        elif col_type == "inequality_constraints":
            columns = result.inequality_constraints.columns.tolist()
        elif col_type == "equality_constraints":
            columns = result.equality_constraints.columns.tolist()
        elif col_type == "observables":
            columns = result.observables.columns.tolist()
        elif col_type == "sets":
            columns = result._set_manager.list_sets()
        else:
            continue

        icon = icon_map[col_type]
        type_code = type_map[col_type]

        for col in columns:
            column_info.append({"label": col, "value": col, "icon": icon, "type": type_code})

    return column_info


def get_icon(icon: str, *args, **kwargs):
    return DashIconify(icon=icon, *args, **kwargs)


def get_graph_id(id: str) -> dict[str, str]:
    return {"type": "graph", "index": id}
