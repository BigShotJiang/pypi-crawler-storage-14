"""Knee point detection page for visualizing best compromise solutions."""

import dash
import dash_mantine_components as dmc
import plotly.express as px
from dash import Input, Output, State, callback, dcc

import optiscope.analysis.knee_detection as kd_mod
import optiscope.dash_app.core.glossary as glo
from optiscope.dash_app.components.result_selector import ResultSelector
from optiscope.dash_app.core.compatibility import create_virtual_storage_manager
from optiscope.dash_app.core.id_factory import IDFactory
from optiscope.dash_app.core.theme_config import LIGHT_THEME
from optiscope.dash_app.pages._base import PageModule
from optiscope.dash_app.utils.helpers import get_graph_id
from optiscope.dash_app.utils.layout_components import create_accordion_sections
from optiscope.dash_app.utils.layouts import create_sidebar_layout


class KneeDetectionPage(PageModule):
    name = "Knee Detection"
    path = "/knee-detection"
    icon = "mdi:chart-bell-curve-cumulative"
    description = "Identify knee points on Pareto fronts for best compromise solutions."
    category = "analysis"
    show_in_home = True

    def __init__(self):
        super().__init__()
        self.result_selector = ResultSelector(
            component_id="knee-page",
            multi=False,
            label="Select Result:",
            description="Choose an optimization result to analyze",
            main_selector_id="main-result-selector",
        )
        self.ids = IDFactory("knee-page")

    def register_callbacks(self, app: dash.Dash | None = None) -> None:
        if app is None:
            return
        ids = IDFactory("knee-page")
        self.result_selector.register_callbacks(app)

        @callback(
            Output(get_graph_id(ids("knee-plot")), "figure"),
            Output(ids("method-dropdown"), "value"),
            Input(self.result_selector.get_value_id(), "value"),
            Input(ids("method-dropdown"), "value"),
            State("theme-store", "data"),
            State(glo.REF_STORE_STR, "data"),
        )
        def update_knee_plot(selected_result, method, theme, stored_data):
            if not stored_data or not selected_result:
                empty_fig = px.scatter(title="No data available")
                return empty_fig, "angle"
            # Load result
            storage_manager = create_virtual_storage_manager(stored_data)
            result = storage_manager.load_result(selected_result)
            # Detect knee points
            knee_indices = kd_mod.detect_knee_points(
                result.objectives, method=method, n_knees=3, normalize=True
            )
            # Plot objectives with knee points highlighted (use first two objectives)
            if result.objectives.shape[1] < 2:
                empty_fig = px.scatter(title="Need at least 2 objectives for knee plot")
                return empty_fig, method
            x_name, y_name = result.objectives.columns[:2]
            fig = px.scatter(
                result.objectives,
                x=x_name,
                y=y_name,
                title=f"Knee Detection ({method.capitalize()} method)",
                template=theme if theme else LIGHT_THEME,
            )
            # Highlight knee points
            if len(knee_indices) > 0:
                knee_df = result.objectives.iloc[knee_indices]
                fig.add_scatter(
                    x=knee_df[x_name],
                    y=knee_df[y_name],
                    mode="markers",
                    marker=dict(color="red", size=12, symbol="star"),
                    name="Knee Points",
                )
            return fig, method

    def layout(self, **kwargs):
        ids = IDFactory("knee-page")
        return dmc.Container(
            children=[
                dmc.Title("Knee Detection", order=2),
                dmc.Text("Identify knee points on Pareto fronts for best compromise solutions."),
                dmc.Space(h=10),
                create_accordion_sections(
                    [
                        {
                            "title": "Filters",
                            "icon": "mdi:filter-menu-outline",
                            "value": "knee-filters",
                            "content": dmc.Stack(
                                [
                                    self.result_selector.layout(),
                                ]
                            ),
                        }
                    ]
                ),
                dmc.Space(h=10),
                create_sidebar_layout(
                    sidebar_content=dmc.Select(
                        label="Method",
                        data=[
                            {"value": "angle", "label": "Angle"},
                            {"value": "distance", "label": "Distance"},
                            {"value": "tradeoff", "label": "Tradeoff"},
                            {"value": "curvature", "label": "Curvature"},
                        ],
                        value="angle",
                        id=ids("method-dropdown"),
                    ),
                    main_content=dcc.Graph(
                        id=get_graph_id(ids("knee-plot")),
                        config={"displayModeBar": True, "displaylogo": False},
                    ),
                    sidebar_position="right",
                ),
            ],
            fluid=True,
        )


page_module = KneeDetectionPage()
