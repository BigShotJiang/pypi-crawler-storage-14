import dash
import dash_mantine_components as dmc

# from dash import Input, Output, State, callback, html
from dash_extensions.enrich import Input, Output, State, html

from optiscope.dash_app.components.ag_grid_table import AgGridTable
from optiscope.dash_app.components.result_selector import ResultSelector
from optiscope.dash_app.core.compatibility import create_virtual_storage_manager
from optiscope.dash_app.core.id_factory import IDFactory
from optiscope.dash_app.pages._base import PageModule
from optiscope.dash_app.utils.layout_components import create_accordion_sections


class DataViewerPage(PageModule):
    name = "Data Inspector"
    path = "/data_inspector"
    icon = "mdi:table-eye"
    description = "View and explore your optimization data."
    category = "data"
    show_in_home = True

    def __init__(self):
        super().__init__()
        self.ids = IDFactory("data-inspector-page")
        self.result_selector = ResultSelector(
            component_id="data-inspector-result-selector",
            multi=False,
            label="Select Result:",
            description="Choose an optimization result to view and explore",
            main_selector_id="main-result-selector",
        )
        self.data_table = AgGridTable(
            component_id="data-inspector-data-table",
            storage_id="storage-references",
            result_selector_id=self.result_selector.component_id,
            # set_selector_id=self.ids("sets-container"),
            # selected_sets_to_display_id=self.set_selector.get_value_id(),
            output_selected_rows_id=self.ids("data-table-selected-rows-store"),
            output_filtered_data_id=self.ids("data-table-filtered-data-store"),
        )

    def register_callbacks(self, app: dash.Dash | None = None) -> None:
        ids = IDFactory("data-inspector-page")

        # Register result selector callbacks
        self.result_selector.register_callbacks(app)
        # self.set_selector.register_callbacks(app)  # Register set selector callbacks
        self.data_table.register_callbacks(app)

        @app.callback(
            Output(ids("sets-container"), "children"),
            Input(self.result_selector.get_value_id(), "value"),
            State("storage-references", "data"),
            Input(
                "storage-references", "data"
            ),  # Trigger update when data store changes (e.g., set saved/removed)
        )
        def update_sets_container(selected_result, stored_data, _):
            """Update sets container when a result is selected or data store changes."""
            if not stored_data or not selected_result:
                return []

            # storage_manager = StorageManager.from_dict(stored_data)
            storage_manager = create_virtual_storage_manager(stored_data)
            result = storage_manager.load_result(selected_result)
            sets = result.list_sets()
            sets_container = [dmc.Chip(s, value=s) for s in sets]
            return sets_container

    def layout(self, **kwargs):
        return dmc.Container(
            children=[
                dmc.Title("Data Viewer", order=2),
                dmc.Text(
                    "View and explore your optimization results and create sets from selected data points."
                ),
                dmc.Space(h=10),
                # Result selector section
                create_accordion_sections(
                    [
                        {
                            "title": "Filters",
                            "icon": "mdi:filter-menu-outline",
                            "value": "data-inspector-filters",
                            "content": dmc.Stack(
                                [
                                    self.result_selector.layout(),
                                    # dmc.Space(h=5),
                                    # self.set_selector.layout(),  # Add SetSelector to layout
                                ]
                            ),
                        }
                    ]
                ),
                # Data table section
                dmc.Paper(
                    children=[
                        dmc.Group(
                            [
                                dmc.Title("Result Data", order=3),
                            ],
                            justify="space-between",
                        ),
                        dmc.Text(
                            "Select rows to create sets from specific data points.",
                            size="sm",
                            c="gray",
                            mt="xs",
                        ),
                        dmc.Space(h=10),
                        self.data_table.layout(),  # Use the new DataTable component
                        html.Div(
                            id=self.ids("data-table-selected-rows-store"), style={"display": "none"}
                        ),  # Hidden store for selected rows
                        html.Div(
                            id=self.ids("data-table-filtered-data-store"), style={"display": "none"}
                        ),  # Hidden store for filtered data
                    ],
                    p="md",
                    shadow="sm",
                    withBorder=True,
                ),
            ],
            fluid=True,
        )


page_module = DataViewerPage()
