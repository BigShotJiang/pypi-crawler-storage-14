"""Optimization History page for visualizing time series of optimization variables."""

import dash
import dash_mantine_components as dmc
import plotly.graph_objects as go
from dash import Input, Output, State, dcc
from dash_extensions.enrich import Serverside

import optiscope.dash_app.core.glossary as glo
from optiscope.dash_app.components.column_selector import ColumnSelectorGroup
from optiscope.dash_app.components.resampler_figure import ResamplerFigure
from optiscope.dash_app.components.result_selector import ResultSelector
from optiscope.dash_app.core import storage_helpers
from optiscope.dash_app.core.id_factory import IDFactory
from optiscope.dash_app.core.theme_config import LIGHT_THEME
from optiscope.dash_app.pages._base import PageModule
from optiscope.dash_app.utils.helpers import get_graph_id
from optiscope.dash_app.utils.layout_components import create_accordion_sections, in_paper
from optiscope.plotting.time_series import (
    RESAMPLER_AVAILABLE,
    plot_constraints_time_series,
    plot_time_series,
    plot_time_series_resampled,
)


class OptimizationHistoryPage(PageModule):
    name = "Optimization History"
    path = "/optimization-history"
    icon = "mdi:chart-line"
    description = "View time series of optimization variables, objectives, and constraints."
    category = "visualization"
    show_in_home = True

    def __init__(self):
        """Initialize the page with column selectors."""
        super().__init__()

        # Create result selector
        self.result_selector = ResultSelector(
            component_id="optimization-history-page",
            multi=False,
            label="Select Results to Compare:",
            description="Choose one or more optimization results to visualize together",
            main_selector_id="main-result-selector",
        )

        # Create column selector group
        self.selector_group = ColumnSelectorGroup("optimization-history-page")

        # Add selectors for each category
        self.selector_group.add_selector(
            selector_id="variables",
            column_types=["variables"],
            label="Select Variables:",
            placeholder="Select variables to display",
            icon="mdi:input",
            default_count=3,
        )

        self.selector_group.add_selector(
            selector_id="objectives",
            column_types=["objectives"],
            label="Select Objectives:",
            placeholder="Select objectives to display",
            icon="mdi:target",
            default_count=3,
        )

        self.selector_group.add_selector(
            selector_id="constraints",
            column_types=["inequality_constraints", "equality_constraints"],
            label="Select Constraints:",
            placeholder="Select constraints to display",
            icon="mdi:border-style",
            default_count=3,
        )

        self.selector_group.add_selector(
            selector_id="observables",
            column_types=["observables"],
            label="Select Observables:",
            placeholder="Select observables to display",
            icon="mdi:eye",
            default_count=3,
        )

        # Create ResamplerFigure components
        self.variables_figure = ResamplerFigure("optimization-history-page-variables")
        self.objectives_figure = ResamplerFigure("optimization-history-page-objectives")

    def register_callbacks(self, app: dash.Dash | None = None) -> None:
        if app is None:
            return

        ids = IDFactory("optimization-history-page")

        # Register selector callbacks
        self.result_selector.register_callbacks(app)
        self.selector_group.register_all_callbacks(app)
        self.variables_figure.register_callbacks(app)
        self.objectives_figure.register_callbacks(app)

        # Get selector value IDs
        value_ids = self.selector_group.get_all_value_ids()

        @app.callback(
            Output(self.variables_figure.get_figure_id(), "figure"),
            Output(self.variables_figure.get_store_id(), "data"),
            Output(self.objectives_figure.get_figure_id(), "figure"),
            Output(self.objectives_figure.get_store_id(), "data"),
            Output(get_graph_id(ids("constraints-plot")), "figure"),
            Output(get_graph_id(ids("observables-plot")), "figure"),
            Input(value_ids["variables"], "value"),
            Input(value_ids["objectives"], "value"),
            Input(value_ids["constraints"], "value"),
            Input(value_ids["observables"], "value"),
            Input(self.result_selector.get_value_id(), "value"),
            State("theme-store", "data"),
            State(glo.REF_STORE_STR, "data"),
        )
        def update_plots(
            selected_variables,
            selected_objectives,
            selected_constraints,
            selected_observables,
            selected_result_keys,
            theme,
            stored_data,
        ):
            empty_fig = go.Figure()
            empty_fig.add_annotation(
                text="No data available",
                xref="paper",
                yref="paper",
                x=0.5,
                y=0.5,
                showarrow=False,
            )

            if not stored_data or not selected_result_keys:
                return empty_fig, None, empty_fig, None, empty_fig, empty_fig

            # Ensure selected_result_keys is a list
            if not isinstance(selected_result_keys, list):
                selected_result_keys = [selected_result_keys]

            if not selected_result_keys:
                empty_fig = go.Figure()
                empty_fig.add_annotation(
                    text="No results found",
                    xref="paper",
                    yref="paper",
                    x=0.5,
                    y=0.5,
                    showarrow=False,
                )
                return empty_fig, None, empty_fig, None, empty_fig, empty_fig

            result = storage_helpers.get_result_by_combined_key(selected_result_keys[0])
            if result is None:
                return empty_fig, None, empty_fig, None, empty_fig, empty_fig

            # Apply theme template
            template = theme if theme else LIGHT_THEME

            # Determine if we should use resampler based on data size
            n_iterations = len(result.design_variables)
            use_resampler = RESAMPLER_AVAILABLE and n_iterations > 5000

            # Create time series plots for each category
            if use_resampler:
                # Use resampled versions for large datasets
                variables_fig = plot_time_series_resampled(
                    result,
                    selected_variables,
                    "design_variables",
                    "Design Variables",
                    single_plot=True,
                )
                objectives_fig = plot_time_series_resampled(
                    result, selected_objectives, "objectives", "Objectives"
                )
                constraints_fig = plot_time_series_resampled(
                    result, selected_constraints, "constraints", "Constraints"
                )

                observables_fig = plot_time_series_resampled(
                    result, selected_observables, "observables", "Observables"
                )
            else:
                # Use regular plots for smaller datasets
                variables_fig = plot_time_series(
                    result,
                    selected_variables,
                    "design_variables",
                    "Design Variables",
                    single_plot=False,
                )
                objectives_fig = plot_time_series(
                    result, selected_objectives, "objectives", "Objectives"
                )
                constraints_fig = plot_constraints_time_series(
                    result, selected_constraints, "Constraints", show_feasibility=True
                )

                observables_fig = plot_time_series(
                    result, selected_observables, "observables", "Observables"
                )

            variables_fig.update_layout(template=template)
            objectives_fig.update_layout(template=template)
            constraints_fig.update_layout(template=template)
            observables_fig.update_layout(template=template)

            # Store resampler figures on server side if using resampler
            if use_resampler:
                return (
                    variables_fig,
                    Serverside(variables_fig),
                    objectives_fig,
                    Serverside(objectives_fig),
                    constraints_fig,
                    observables_fig,
                )
            else:
                return (variables_fig, None, objectives_fig, None, constraints_fig, observables_fig)

    def layout(self, **kwargs):
        ids = IDFactory("optimization-history-page")

        # Get selectors from the group
        variables_selector = self.selector_group.get_selector("variables")
        objectives_selector = self.selector_group.get_selector("objectives")
        constraints_selector = self.selector_group.get_selector("constraints")
        observables_selector = self.selector_group.get_selector("observables")

        return dmc.Container(
            children=[
                dmc.Title("Optimization History", order=2),
                dmc.Text(
                    "View time series evolution of variables, objectives, constraints, and observables throughout the optimization process."
                ),
                dmc.Space(h=10),
                create_accordion_sections(
                    [
                        {
                            "title": "Filters",
                            "icon": "mdi:filter-menu-outline",
                            "value": "optimization-history-filters",
                            "content": dmc.Stack(
                                [  # Result selector
                                    self.result_selector.layout(),
                                    # Selectors Grid
                                    dmc.Grid(
                                        [
                                            dmc.GridCol(
                                                variables_selector.layout(),
                                                span=6,
                                            ),
                                            dmc.GridCol(
                                                objectives_selector.layout(),
                                                span=6,
                                            ),
                                            dmc.GridCol(
                                                constraints_selector.layout(),
                                                span=6,
                                            ),
                                            dmc.GridCol(
                                                observables_selector.layout(),
                                                span=6,
                                            ),
                                        ]
                                    ),
                                ]
                            ),
                        }
                    ]
                ),
                dmc.Space(h=20),
                # Time Series Plots
                dmc.Stack(
                    [
                        in_paper(self.variables_figure.layout()),
                        in_paper(self.objectives_figure.layout()),
                        in_paper(
                            dcc.Graph(
                                id=get_graph_id(ids("constraints-plot")),
                                config={"displayModeBar": True, "displaylogo": False},
                            )
                        ),
                        in_paper(
                            dcc.Graph(
                                id=get_graph_id(ids("observables-plot")),
                                config={"displayModeBar": True, "displaylogo": False},
                            )
                        ),
                    ],
                    gap="md",
                ),
            ],
            fluid=True,
        )


page_module = OptimizationHistoryPage()
