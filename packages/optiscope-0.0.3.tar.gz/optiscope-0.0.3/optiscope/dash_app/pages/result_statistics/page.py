import dash_mantine_components as dmc
from dash import Input, Output, State, callback, html
from dash_iconify import DashIconify

from optiscope.dash_app.components.result_selector import create_result_selector
from optiscope.dash_app.core.id_factory import IDFactory
from optiscope.dash_app.core.storage_helpers import get_result_by_combined_key
from optiscope.dash_app.pages._base import PageModule


class ResultStatisticsPage(PageModule):
    """Page for viewing statistics of optimization results."""

    name = "Result Statistics"
    path = "/result-statistics"
    icon = "carbon:chart-radar"
    description = "View detailed statistics and metadata for optimization results."
    category = "visualization"

    def __init__(self):
        self.ids = IDFactory("result-statistics")
        self.result_selector = create_result_selector(
            component_id=self.ids("result-selector"),
            multi=False,
            label="Select Result to Analyze",
            description="Choose an optimization result to view its statistics.",
            persistence=True,
        )

    def layout(self, **kwargs):
        return dmc.Stack(
            [
                dmc.Group(
                    [
                        DashIconify(icon=self.icon, width=30),
                        dmc.Title(self.name, order=2),
                    ],
                    gap="sm",
                ),
                dmc.Text(
                    self.description,
                    size="sm",
                    style={"color": "var(--mantine-color-dimmed)"},
                ),
                dmc.Divider(),
                self.result_selector.layout(),
                dmc.Space(h="md"),
                html.Div(id=self.ids("stats-container")),
            ],
            gap="md",
            p="md",
        )

    def register_callbacks(self, app):
        self.result_selector.register_callbacks(app)

        @callback(
            Output(self.ids("stats-container"), "children"),
            Input(self.result_selector.get_value_id(), "value"),
            State("storage-references", "data"),
        )
        def update_statistics(selected_result_key, storage_refs):
            if not selected_result_key or not storage_refs:
                return dmc.Alert(
                    "Please select a result to view statistics.",
                    title="No Selection",
                    color="blue",
                    icon=DashIconify(icon="carbon:information"),
                )

            try:
                # Get result using helper function
                result = get_result_by_combined_key(selected_result_key)

                print(result)

                # # Load result using virtual storage manager
                # storage = create_virtual_storage_manager(storage_refs)
                # result = storage.load_result(selected_result_key)
                metadata = result.metadata

                # Prepare stats data
                stats_data = [
                    {
                        "label": "Problem Name",
                        "value": metadata.name,
                        "icon": "carbon:notebook",
                        "color": "blue",
                    },
                    {
                        "label": "Solver",
                        "value": f"{metadata.solver} {metadata.solver_version or ''}".strip()
                        or "Unknown",
                        "icon": "carbon:calculator",
                        "color": "cyan",
                    },
                    {
                        "label": "Total Points",
                        "value": str(result.n_points),
                        "icon": "carbon:scatter-plot",
                        "color": "teal",
                    },
                    {
                        "label": "Design Variables",
                        "value": str(metadata.n_design_variables),
                        "icon": "carbon:variable",
                        "color": "grape",
                    },
                    {
                        "label": "Objectives",
                        "value": str(metadata.n_objectives),
                        "icon": "carbon:bullseye",
                        "color": "orange",
                    },
                    {
                        "label": "Constraints",
                        "value": str(
                            metadata.n_inequality_constraints + metadata.n_equality_constraints
                        ),
                        "icon": "carbon:warning-alt",
                        "color": "red",
                    },
                    {
                        "label": "Result Sets",
                        "value": str(len(result.list_sets())),
                        "icon": "carbon:category",
                        "color": "violet",
                    },
                    {
                        "label": "Run Date",
                        "value": metadata.run_date.strftime("%Y-%m-%d %H:%M")
                        if metadata.run_date
                        else "Unknown",
                        "icon": "carbon:calendar",
                        "color": "gray",
                    },
                ]

                # Create cards
                cards = []
                for stat in stats_data:
                    card = dmc.Paper(
                        p="md",
                        radius="md",
                        withBorder=True,
                        children=[
                            dmc.Group(
                                [
                                    dmc.ThemeIcon(
                                        DashIconify(icon=stat["icon"], width=20),
                                        size="lg",
                                        radius="md",
                                        variant="light",
                                        color=stat["color"],
                                    ),
                                    dmc.Text(
                                        stat["label"],
                                        size="sm",
                                        style={
                                            "color": "var(--mantine-color-dimmed)",
                                            "fontWeight": 500,
                                        },
                                    ),
                                ],
                                mb="md",
                            ),
                            dmc.Text(stat["value"], size="xl", style={"fontWeight": 700}),
                        ],
                    )
                    cards.append(card)

                summary_grid = dmc.SimpleGrid(
                    cols={"base": 1, "sm": 2, "md": 4},
                    spacing="md",
                    verticalSpacing="md",
                    children=cards,
                )

                # Helper function to generate statistics table
                def generate_stats_table(df, title):
                    if df is None or len(df) == 0:
                        return None

                    # Select numeric columns
                    numeric_df = df.select_dtypes(include=["number"])

                    if len(numeric_df) == 0 or len(numeric_df.columns) == 0:
                        return None

                    stats = numeric_df.describe().T
                    # describe() gives count, mean, std, min, 25%, 50%, 75%, max

                    header = dmc.TableThead(
                        dmc.TableTr(
                            [
                                dmc.TableTh("Variable"),
                                dmc.TableTh("Min"),
                                dmc.TableTh("Max"),
                                dmc.TableTh("Average"),
                                dmc.TableTh("Median"),
                                dmc.TableTh("Std Dev"),
                            ]
                        )
                    )

                    rows = []
                    for index, row in stats.iterrows():
                        rows.append(
                            dmc.TableTr(
                                [
                                    dmc.TableTd(index, style={"fontWeight": 500}),
                                    dmc.TableTd(f"{row['min']:.4f}"),
                                    dmc.TableTd(f"{row['max']:.4f}"),
                                    dmc.TableTd(f"{row['mean']:.4f}"),
                                    dmc.TableTd(f"{row['50%']:.4f}"),
                                    dmc.TableTd(f"{row['std']:.4f}"),
                                ]
                            )
                        )

                    return dmc.Paper(
                        withBorder=True,
                        radius="md",
                        p="md",
                        children=[
                            dmc.Title(title, order=4, mb="sm"),
                            dmc.TableScrollContainer(
                                minWidth=500,
                                children=[
                                    dmc.Table(
                                        [header, dmc.TableTbody(rows)],
                                        striped=True,
                                        highlightOnHover=True,
                                        withTableBorder=True,
                                        withColumnBorders=True,
                                    )
                                ],
                            ),
                        ],
                    )

                # Generate tables for each category
                detailed_stats = [
                    generate_stats_table(result.design_variables, "Design Variables"),
                    generate_stats_table(result.objectives, "Objectives"),
                    generate_stats_table(result.inequality_constraints, "Inequality Constraints"),
                    generate_stats_table(result.equality_constraints, "Equality Constraints"),
                    generate_stats_table(result.observables, "Observables"),
                ]

                # Filter out None values (empty tables)
                detailed_stats = [item for item in detailed_stats if item is not None]

                return dmc.Stack(
                    [
                        summary_grid,
                        dmc.Divider(label="Detailed Statistics", labelPosition="center"),
                        *detailed_stats,
                    ],
                    gap="xl",
                )

            except Exception as e:
                return dmc.Alert(
                    f"Error loading result: {str(e)}",
                    title="Error",
                    color="red",
                    icon=DashIconify(icon="carbon:error"),
                )


page_module = ResultStatisticsPage()
