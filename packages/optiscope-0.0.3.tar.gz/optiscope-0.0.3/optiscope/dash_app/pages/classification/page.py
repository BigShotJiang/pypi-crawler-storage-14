"""Solution Classification page."""

import dash
import dash_mantine_components as dmc
import plotly.express as px
from dash import Input, Output, State, callback, dcc, html, no_update

import optiscope.dash_app.core.glossary as glo
from optiscope.analysis.classification import classify_result
from optiscope.core.data_types import DataTypeCategory
from optiscope.dash_app.components.result_selector import ResultSelector
from optiscope.dash_app.core.compatibility import create_virtual_storage_manager
from optiscope.dash_app.core.id_factory import IDFactory
from optiscope.dash_app.core.storage_registry import get_storage_registry
from optiscope.dash_app.core.theme_config import LIGHT_THEME
from optiscope.dash_app.pages._base import PageModule
from optiscope.dash_app.utils.helpers import get_graph_id
from optiscope.dash_app.utils.layout_components import create_accordion_sections
from optiscope.dash_app.utils.layouts import create_sidebar_layout


class ClassificationPage(PageModule):
    name = "Solution Classification"
    path = "/classification"
    icon = "mdi:tag-multiple-outline"
    description = "Classify solutions based on their performance profile (e.g., PRUF)."
    category = "analysis"
    show_in_home = True

    def __init__(self):
        super().__init__()
        self.result_selector = ResultSelector(
            component_id="classification-page",
            multi=False,
            label="Select Result:",
            description="Choose an optimization result to analyze",
            main_selector_id="main-result-selector",
        )
        self.ids = IDFactory("classification-page")

    def register_callbacks(self, app: dash.Dash | None = None) -> None:
        if app is None:
            return
        ids = IDFactory("classification-page")
        self.result_selector.register_callbacks(app)

        @callback(
            Output(get_graph_id(ids("class-plot")), "figure"),
            Output(get_graph_id(ids("class-bar-plot")), "figure"),
            Input(self.result_selector.get_value_id(), "value"),
            Input(ids("method-dropdown"), "value"),
            State("theme-store", "data"),
            State(glo.REF_STORE_STR, "data"),
        )
        def update_classification_plot(selected_result, method, theme, stored_data):
            if not stored_data or not selected_result:
                return px.scatter(title="No data available"), px.bar(title="No data available")

            # Load result
            storage_manager = create_virtual_storage_manager(stored_data)
            result = storage_manager.load_result(selected_result)

            if result.objectives.empty:
                return px.scatter(title="No objectives found"), px.bar(title="No objectives found")

            # Classify
            classification = classify_result(result, method=method, add_to_result=False)

            # Create DataFrame for plotting
            df = result.objectives.copy()
            df["Classification"] = classification

            # Scatter Plot (first 2 objectives)
            if df.shape[1] >= 2:  # 2 objs
                x_name = df.columns[0]
                y_name = df.columns[1]

                # Define color map for PRUF categories if applicable
                color_discrete_map = None
                category_orders = None

                if "pruf" in method:
                    # PRUF categories order
                    pruf_order = [
                        "Highly Desirable",
                        "Desirable",
                        "Tolerable",
                        "Undesirable",
                        "Highly Undesirable",
                    ]
                    category_orders = {"Classification": pruf_order}

                    # Custom colors for PRUF
                    color_discrete_map = {
                        "Highly Desirable": "#00cc96",  # Green
                        "Desirable": "#636efa",  # Blue
                        "Tolerable": "#ab63fa",  # Purple
                        "Undesirable": "#ffa15a",  # Orange
                        "Highly Undesirable": "#ef553b",  # Red
                    }

                fig_scatter = px.scatter(
                    df,
                    x=x_name,
                    y=y_name,
                    color="Classification",
                    title=f"Classification: {method.replace('_', ' ').title()}",
                    template=theme if theme else LIGHT_THEME,
                    category_orders=category_orders,
                    color_discrete_map=color_discrete_map,
                )
            else:
                fig_scatter = px.scatter(title="Need at least 2 objectives for scatter plot")

            # Bar Plot (Distribution)
            counts = df["Classification"].value_counts().reset_index()
            counts.columns = ["Category", "Count"]

            fig_bar = px.bar(
                counts,
                x="Category",
                y="Count",
                color="Category",
                title="Solution Distribution",
                template=theme if theme else LIGHT_THEME,
                category_orders=category_orders,
                color_discrete_map=color_discrete_map,
            )

            return fig_scatter, fig_bar

        @callback(
            Output(ids("save-notification"), "children"),
            Input(ids("save-btn"), "n_clicks"),
            State(self.result_selector.get_value_id(), "value"),
            State(ids("method-dropdown"), "value"),
            State(ids("col-name-input"), "value"),
            State(glo.REF_STORE_STR, "data"),
            prevent_initial_call=True,
        )
        def save_classification(n_clicks, selected_result, method, col_name, stored_data):
            if not n_clicks or not selected_result:
                return no_update, no_update

            try:
                # Parse key to find source
                if "::" in selected_result:
                    source_id, result_key = selected_result.split("::", 1)
                else:
                    # Fallback or error
                    return dmc.Alert("Invalid result key format", color="red")

                registry = get_storage_registry()
                storage = registry.get(source_id)

                if not storage:
                    return dmc.Alert("Storage source not found", color="red")

                # Load, modify, save
                result = storage.load_result(result_key)

                # Default column name if empty
                if not col_name:
                    col_name = f"class_{method}"

                # Perform classification and add to result
                classification = classify_result(
                    result,
                    method=method,
                    add_to_result=False,
                    new_column_name=col_name,
                )

                # Check if column exists
                # We can't easily check without loading, but add_column might fail
                # Let's try to add
                try:
                    result.add_column(col_name, classification, DataTypeCategory.OBSERVABLE)
                    storage.save_result(result_key, result)
                    return dmc.Alert(
                        f"Successfully saved column '{col_name}'",
                        color="green",
                        withCloseButton=True,
                    )
                except Exception as e:
                    return dmc.Alert(
                        f"Error saving column: {str(e)}", color="red", withCloseButton=True
                    )

                return (
                    dmc.Alert(
                        f"Successfully saved classification to column '{col_name}' in result '{selected_result}'.",
                        color="green",
                        duration=3000,
                    ),
                )

            except Exception as e:
                return (
                    dmc.Alert(
                        f"Failed to save classification: {str(e)}",
                        color="red",
                        duration=5000,
                    ),
                )

    def layout(self, **kwargs):
        ids = IDFactory("classification-page")
        return dmc.Container(
            children=[
                dmc.Title("Solution Classification", order=2),
                dmc.Text("Classify solutions based on their performance profile."),
                dmc.Text(
                    "Includes PRUF method (Physical Programming) categories: Highly Desirable to Highly Undesirable.",
                    size="sm",
                    c="dimmed",
                ),
                dmc.Space(h=10),
                create_accordion_sections(
                    [
                        {
                            "title": "Filters",
                            "icon": "mdi:filter-menu-outline",
                            "value": "class-filters",
                            "content": dmc.Stack(
                                [
                                    self.result_selector.layout(),
                                ]
                            ),
                        }
                    ]
                ),
                dmc.Space(h=10),
                create_sidebar_layout(
                    sidebar_content=dmc.Stack(
                        [
                            dmc.Select(
                                label="Classification Method",
                                data=[
                                    {
                                        "value": "best_obj",
                                        "label": "Best Objective (Identify Strength)",
                                    },
                                    {
                                        "value": "worst_obj",
                                        "label": "Worst Objective (Identify Weakness)",
                                    },
                                    {
                                        "value": "pruf_worst",
                                        "label": "PRUF Categories (Pessimistic)",
                                    },
                                    {
                                        "value": "pruf_best",
                                        "label": "PRUF Categories (Optimistic)",
                                    },
                                ],
                                value="pruf_worst",
                                id=ids("method-dropdown"),
                            ),
                            dmc.TextInput(
                                label="Save as Column Name",
                                placeholder="e.g., pruf_class",
                                id=ids("col-name-input"),
                            ),
                            dmc.Button(
                                "Save Classification to Result",
                                id=ids("save-btn"),
                                color="blue",
                                fullWidth=True,
                            ),
                            html.Div(id=ids("save-notification")),
                        ]
                    ),
                    main_content=dmc.Stack(
                        [
                            dcc.Graph(
                                id=get_graph_id(ids("class-plot")),
                                config={"displayModeBar": True, "displaylogo": False},
                            ),
                            dcc.Graph(
                                id=get_graph_id(ids("class-bar-plot")),
                                config={"displayModeBar": True, "displaylogo": False},
                            ),
                        ]
                    ),
                    sidebar_position="right",
                ),
            ],
            fluid=True,
        )


page_module = ClassificationPage()
