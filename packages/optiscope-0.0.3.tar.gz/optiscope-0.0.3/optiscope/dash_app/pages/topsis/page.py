"""TOPSIS analysis page for visualizing multi-criteria ranking."""

import dash
import dash_mantine_components as dmc
import plotly.express as px
from dash import ALL, Input, Output, State, callback, dcc, html, no_update

import optiscope.dash_app.core.glossary as glo
from optiscope.analysis import topsis
from optiscope.core.data_types import DataTypeCategory
from optiscope.dash_app.components.result_selector import ResultSelector
from optiscope.dash_app.core.compatibility import create_virtual_storage_manager
from optiscope.dash_app.core.id_factory import IDFactory
from optiscope.dash_app.core.storage_registry import get_storage_registry
from optiscope.dash_app.core.theme_config import LIGHT_THEME
from optiscope.dash_app.pages._base import PageModule
from optiscope.dash_app.utils.helpers import get_graph_id, get_icon
from optiscope.dash_app.utils.layouts import create_two_column_layout


class TopsisPage(PageModule):
    name = "TOPSIS Analysis"
    path = "/topsis"
    icon = "mdi:chart-bell-curve"
    description = "Rank solutions using TOPSIS multi-criteria decision making."
    category = "analysis"
    show_in_home = True

    def __init__(self):
        super().__init__()
        # Result selector (single result)
        self.result_selector = ResultSelector(
            component_id="topsis-page",
            multi=False,
            label="Select Result:",
            description="Choose an optimization result to rank",
            main_selector_id="main-result-selector",
        )
        self.ids = IDFactory("topsis-page")

    def register_callbacks(self, app: dash.Dash | None = None) -> None:
        if app is None:
            return
        ids = IDFactory("topsis-page")
        self.result_selector.register_callbacks(app)

        # Callback to generate weight inputs based on selected result
        @callback(
            Output(ids("weights-container"), "children"),
            Input(self.result_selector.get_value_id(), "value"),
            State(glo.REF_STORE_STR, "data"),
        )
        def update_weight_inputs(selected_result, stored_data):
            if not stored_data or not selected_result:
                return []

            try:
                storage_manager = create_virtual_storage_manager(stored_data)
                result = storage_manager.load_result(selected_result)
                obj_names = result.objectives.columns.tolist()
                default_weights = [1.0 / len(obj_names)] * len(obj_names)

                weight_inputs = []
                for name, w in zip(obj_names, default_weights):
                    weight_inputs.append(
                        dmc.NumberInput(
                            label=f"Weight for {name}",
                            value=w,
                            min=0,
                            step=0.01,
                            id={"type": ids("weight-input"), "index": name},
                            mb="xs",
                        )
                    )
                return weight_inputs
            except Exception:
                return []

        # Callback to enable/disable 3D scatter button
        @callback(
            Output(ids("btn-show-scatter-3d"), "disabled"),
            Input(self.result_selector.get_value_id(), "value"),
            State(glo.REF_STORE_STR, "data"),
        )
        def update_3d_button_state(selected_result, stored_data):
            if not stored_data or not selected_result:
                return True

            try:
                storage_manager = create_virtual_storage_manager(stored_data)
                result = storage_manager.load_result(selected_result)
                return len(result.objectives.columns) < 3
            except Exception:
                return True

        # Callback to calculate scores and update graph
        @callback(
            Output(get_graph_id(ids("scores-plot")), "figure"),
            Output(ids("topsis-scores-store"), "data"),
            Input(self.result_selector.get_value_id(), "value"),
            Input({"type": ids("weight-input"), "index": ALL}, "value"),
            Input(ids("view-mode-store"), "data"),
            State("theme-store", "data"),
            State(glo.REF_STORE_STR, "data"),
        )
        def update_graph(selected_result, weight_values, view_mode, theme, stored_data):
            if not stored_data or not selected_result:
                return px.bar(title="No data available"), None

            try:
                storage_manager = create_virtual_storage_manager(stored_data)
                result = storage_manager.load_result(selected_result)
                obj_names = result.objectives.columns.tolist()

                # Handle weights
                if not weight_values or len(weight_values) != len(obj_names):
                    # Default equal weights if inputs not ready
                    weights = [1.0 / len(obj_names)] * len(obj_names)
                else:
                    # Filter out None values if any
                    weights = [w if w is not None else 0.0 for w in weight_values]

                # Compute TOPSIS scores
                scores = topsis(
                    result.objectives,
                    weights=weights,
                    directions=result.optimization_directions,
                    return_details=False,
                )

                template = theme if theme else LIGHT_THEME

                if view_mode == "scatter":
                    # Use dataframe directly for plotting
                    df = result.get_all_data()
                    df["TOPSIS Score"] = scores

                    # Find 2 objectives for scatter plot (default to first two)
                    x_axis = obj_names[0]
                    y_axis = obj_names[1] if len(obj_names) > 1 else obj_names[0]

                    fig = px.scatter(
                        df,
                        x=x_axis,
                        y=y_axis,
                        color="TOPSIS Score",
                        title="TOPSIS Score Distribution",
                        template=template,
                        hover_data=obj_names + ["TOPSIS Score"],
                        color_continuous_scale="Viridis",
                    )
                    return fig, scores

                elif view_mode == "scatter-3d":
                    # Use dataframe directly for plotting
                    df = result.get_all_data()
                    df["TOPSIS Score"] = scores

                    # Find 3 objectives for scatter plot
                    if len(obj_names) < 3:
                        return px.scatter(title="Need at least 3 objectives for 3D plot"), scores

                    x_axis = obj_names[0]
                    y_axis = obj_names[1]
                    z_axis = obj_names[2]

                    fig = px.scatter_3d(
                        df,
                        x=x_axis,
                        y=y_axis,
                        z=z_axis,
                        color="TOPSIS Score",
                        title="TOPSIS Score Distribution (3D)",
                        template=template,
                        hover_data=obj_names + ["TOPSIS Score"],
                        color_continuous_scale="Viridis",
                    )
                    return fig, scores

                else:
                    # Bar chart
                    fig = px.bar(
                        x=result.objectives.index,
                        y=scores,
                        labels={"x": "Solution Index", "y": "TOPSIS Score"},
                        title="TOPSIS Scores",
                        template=template,
                    )
                    return fig, scores

            except Exception as e:
                return px.scatter(title=f"Error: {str(e)}"), None

        # Callback to toggle view mode
        @callback(
            Output(ids("view-mode-store"), "data"),
            Input(ids("btn-show-scatter"), "n_clicks"),
            Input(ids("btn-show-bar"), "n_clicks"),
            Input(ids("btn-show-scatter-3d"), "n_clicks"),
            State(ids("view-mode-store"), "data"),
            prevent_initial_call=True,
        )
        def toggle_view(n_scatter, n_bar, n_scatter_3d, current_mode):
            ctx = dash.callback_context
            if not ctx.triggered:
                return current_mode

            button_id = ctx.triggered[0]["prop_id"].split(".")[0]
            if "btn-show-scatter-3d" in button_id:
                return "scatter-3d"
            elif "btn-show-scatter" in button_id:
                return "scatter"
            elif "btn-show-bar" in button_id:
                return "bar"
            return current_mode

        # Callback to save score column
        @callback(
            Output(ids("save-notification"), "children"),
            Input(ids("btn-save-column"), "n_clicks"),
            State(self.result_selector.get_value_id(), "value"),
            State(ids("topsis-scores-store"), "data"),
            State(ids("new-column-name"), "value"),
            State(glo.REF_STORE_STR, "data"),
            prevent_initial_call=True,
        )
        def save_column(n_clicks, selected_result, scores, col_name, stored_data):
            if not n_clicks or not selected_result or not scores or not col_name:
                return no_update

            try:
                # Parse key to find source
                if "::" in selected_result:
                    source_id, result_key = selected_result.split("::", 1)
                else:
                    # Fallback or error
                    return dmc.Alert("Invalid result key format", color="red")

                registry = get_storage_registry()
                storage = registry.get(source_id)

                if not storage:
                    return dmc.Alert("Storage source not found", color="red")

                # Load, modify, save
                result = storage.load_result(result_key)

                # Check if column exists
                # We can't easily check without loading, but add_column might fail
                # Let's try to add
                try:
                    result.add_column(col_name, scores, DataTypeCategory.OBSERVABLE)
                    storage.save_result(result_key, result)
                    return dmc.Alert(
                        f"Successfully saved column '{col_name}'",
                        color="green",
                        withCloseButton=True,
                    )
                except Exception as e:
                    return dmc.Alert(
                        f"Error saving column: {str(e)}", color="red", withCloseButton=True
                    )

            except Exception as e:
                return dmc.Alert(f"Error: {str(e)}", color="red", withCloseButton=True)

    def layout(self, **kwargs):
        ids = IDFactory("topsis-page")

        # Sidebar content
        sidebar_content = dmc.Stack(
            [
                dmc.Title("Controls", order=4),
                self.result_selector.layout(),
                dmc.Divider(),
                dmc.Text("Weights", size="sm", fw=500),
                html.Div(id=ids("weights-container")),
                dmc.Divider(),
                dmc.Text("Visualization", size="sm", fw=500),
                dmc.Group(
                    [
                        dmc.Button(
                            "Bar Chart",
                            id=ids("btn-show-bar"),
                            variant="outline",
                            size="xs",
                            leftSection=dmc.ThemeIcon(
                                size="xs",
                                radius="xl",
                                color="blue",
                                variant="light",
                                children=get_icon(icon="mdi:chart-bar"),
                            ),
                        ),
                        dmc.Button(
                            "Scatter Plot",
                            id=ids("btn-show-scatter"),
                            variant="outline",
                            size="xs",
                            leftSection=dmc.ThemeIcon(
                                size="xs",
                                radius="xl",
                                color="blue",
                                variant="light",
                                children=get_icon(icon="mdi:scatter-plot"),
                            ),
                        ),
                    ],
                    grow=True,
                ),
                dmc.Button(
                    "3D Scatter",
                    id=ids("btn-show-scatter-3d"),
                    variant="outline",
                    size="xs",
                    fullWidth=True,
                    leftSection=dmc.ThemeIcon(
                        size="xs",
                        radius="xl",
                        color="blue",
                        variant="light",
                        children=get_icon(icon="mdi:axis-z-arrow"),
                    ),
                    disabled=True,  # Enabled by callback if enough objectives
                ),
                dmc.Divider(),
                dmc.Text("Save Results", size="sm", fw=500),
                dmc.TextInput(
                    id=ids("new-column-name"),
                    label="Column Name",
                    value="topsis_score",
                    placeholder="Enter column name",
                ),
                dmc.Button(
                    "Save Score Column",
                    id=ids("btn-save-column"),
                    leftSection=get_icon(icon="mdi:content-save"),
                    color="green",
                    fullWidth=True,
                ),
                html.Div(id=ids("save-notification")),
            ],
            gap="md",
        )

        # Main content
        main_content = dmc.Stack(
            [
                dmc.Title("TOPSIS Analysis", order=2),
                dmc.Text("Rank solutions using TOPSIS multi-criteria decision making."),
                dcc.Graph(
                    id=get_graph_id(ids("scores-plot")),
                    config={"displayModeBar": True, "displaylogo": False},
                    style={"height": "70vh"},
                ),
                # Stores
                dcc.Store(id=ids("topsis-scores-store")),
                dcc.Store(id=ids("view-mode-store"), data="bar"),
            ],
            gap="lg",
        )

        return create_two_column_layout(
            right_content=sidebar_content,
            left_content=main_content,
            left_span=9,
            right_span=3,
        )


page_module = TopsisPage()
