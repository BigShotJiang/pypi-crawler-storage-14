from __future__ import annotations

from typing import Any

import dash
import dash_mantine_components as dmc
from dash import Input, Output, callback, dcc
from dash.exceptions import PreventUpdate
from dash_iconify import DashIconify

import optiscope.dash_app.core.glossary as glo
from optiscope.dash_app.core.id_factory import IDFactory
from optiscope.dash_app.core.storage_helpers import validate_source_store
from optiscope.dash_app.pages._base import PageModule
from optiscope.dash_app.utils.layout_components import create_page_header
from optiscope.dash_app.utils.layouts import create_two_column_layout


class HomePage(PageModule):
    name = "Welcome"
    path = "/"
    icon = "mdi:home"
    description = "Welcome to Optiscope."
    hidden_from_nav: bool = True

    def is_available(self, app=None, stored_data=None) -> tuple[bool, str]:
        """Home page is always available"""
        return True, ""

    def layout(self, **kwargs):
        ids = IDFactory("home-page")
        return dmc.Container(id=ids("main-container"), fluid=True)

    def register_callbacks(self, app: dash.Dash):
        ids = IDFactory("home-page")

        @callback(
            Output(ids("main-container"), "children"),
            Input(glo.REF_STORE_STR, "data"),
            Input("url", "pathname"),
        )
        def update_layout(stored_data, pathname):
            if pathname != self.path:
                raise PreventUpdate

            if stored_data:
                try:
                    results_exist = validate_source_store(stored_data)
                except Exception:
                    results_exist = False
            else:
                results_exist = False

            # Left content
            left_content = [
                dmc.Stack(
                    [
                        create_page_header(
                            title="Welcome to Optiscope",
                            description="Your open-source platform for visualizing and analyzing optimization data.",
                            icon="mdi:magnify-expand",
                            divider=False,
                        ),
                        dmc.Space(h=20),
                        dmc.Title("Quick Start", order=3, mb="md"),
                        dmc.Timeline(
                            active=1 if results_exist else 0,
                            bulletSize=24,
                            lineWidth=2,
                            children=[
                                dmc.TimelineItem(
                                    title="Load Data",
                                    children=[
                                        dmc.Text(
                                            "Import your optimization results from CSV, JSON, or other formats in the Data Manager.",
                                            c="dimmed",
                                            size="sm",
                                        ),
                                    ],
                                    bullet=DashIconify(icon="mdi:database-import", width=14),
                                ),
                                dmc.TimelineItem(
                                    title="Analyze",
                                    children=[
                                        dmc.Text(
                                            "Filter solutions, find knee points, and perform multi-criteria decision making (TOPSIS).",
                                            c="dimmed",
                                            size="sm",
                                        ),
                                    ],
                                    bullet=DashIconify(icon="mdi:chart-line", width=14),
                                ),
                                dmc.TimelineItem(
                                    title="Visualize",
                                    children=[
                                        dmc.Text(
                                            "Explore trade-offs with interactive scatter plots, parallel coordinates, and more.",
                                            c="dimmed",
                                            size="sm",
                                        ),
                                    ],
                                    bullet=DashIconify(icon="mdi:eye", width=14),
                                ),
                            ],
                        ),
                        dmc.Title("Key Features", order=3, mt="xl", mb="sm"),
                        dmc.List(
                            [
                                dmc.ListItem(
                                    "Interactive visualizations for high-dimensional data."
                                ),
                                dmc.ListItem("Pareto front identification and analysis."),
                                dmc.ListItem("Flexible data import and management."),
                            ],
                            spacing="sm",
                            size="sm",
                            icon=dmc.ThemeIcon(
                                DashIconify(icon="mdi:check", width=16),
                                radius="xl",
                                color="teal",
                                size=24,
                            ),
                        ),
                    ],
                    align="center",
                    justify="space-between",
                    gap="sm",
                )
            ]

            # Right content (cards)
            pages_by_category = {}
            for page in dash.page_registry.values():
                if page["path"] == "/" or not page.get("show_in_home"):
                    continue
                category = page.get("category", "Other")
                if category not in pages_by_category:
                    pages_by_category[category] = []
                pages_by_category[category].append(page)

            page_cards_layout = []
            for category in ["data", "analysis", "visualization", "Other"]:
                page_cards = []
                if category not in pages_by_category:
                    continue
                for page in pages_by_category[category]:
                    is_dm_page = page["path"] == "/data_manager"
                    is_clickable = results_exist or is_dm_page

                    card_style = {"cursor": "pointer" if is_clickable else "not-allowed"}
                    if not is_clickable:
                        card_style["opacity"] = 0.5

                    card_content = dmc.Group(
                        [
                            DashIconify(icon=page.get("icon", "mdi:page"), width=30),
                            dmc.Stack(
                                [
                                    dmc.Text(page["name"], fw="bold"),
                                    dmc.Text(page["description"], size="sm", c="gray"),
                                ],
                                gap=0,
                            ),
                        ],
                        gap="lg",
                        align="flex-start",
                    )

                    card = dmc.Card(
                        children=[card_content],
                        withBorder=True,
                        shadow="sm",
                        radius="md",
                        style=card_style,
                    )

                    if is_clickable:
                        page_cards.append(
                            dcc.Link(card, href=page["path"], style={"textDecoration": "none"})
                        )
                    else:
                        page_cards.append(card)

                if category == "analysis":
                    pass
                elif category == "data":
                    pass

                category_section = dmc.Stack(
                    [
                        dmc.SimpleGrid(cols=2, children=page_cards, mt="sm"),
                    ],
                    gap="sm",
                    mt="xl",
                )
                page_cards_layout.append(category_section)

            right_content_children: list[Any] = [dmc.Title("Available Pages", order=2)]
            if not results_exist:
                right_content_children.append(
                    dmc.Alert(
                        "No results loaded. Please go to the Data Manager to upload data.",
                        title="Attention",
                        color="orange",
                        icon=DashIconify(icon="mdi:alert"),
                        mt="md",
                    )
                )
            right_content_children.extend(page_cards_layout)
            right_content = dmc.Stack(right_content_children)

            return create_two_column_layout(left_content, right_content, left_span=6, right_span=6)


page_module = HomePage()
