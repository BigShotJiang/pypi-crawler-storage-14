import dash_mantine_components as dmc
import numpy as np
import plotly.express as px
from dash import Input, Output, State, callback, dcc, html, no_update
from dash_iconify import DashIconify

from optiscope.analysis.pareto import identify_pareto_front
from optiscope.analysis.smart_pareto import adaptive_smart_pareto_filter, smart_pareto_filter
from optiscope.core.data_types import Objective, OptimizationDirection
from optiscope.dash_app.components.result_selector import ResultSelector
from optiscope.dash_app.components.set_selector import SetSelector
from optiscope.dash_app.core import storage_helpers
from optiscope.dash_app.core.compatibility import create_virtual_storage_manager
from optiscope.dash_app.core.id_factory import IDFactory
from optiscope.dash_app.pages._base import PageModule


class DominancePage(PageModule):
    name = "Dominance Analysis"
    path = "/dominance"
    icon = "mdi:chart-bubble"
    description = "Identify Pareto optimal solutions using standard or smart filtering methods."
    category = "analysis"
    show_in_home = True
    requires_data = True

    def __init__(self):
        self.id_factory = IDFactory("dominance")
        self.storage_manager = create_virtual_storage_manager()
        # Initialize ResultSelector with multi=False for single result selection
        self.result_selector = ResultSelector(
            self.id_factory("result-selector"),
            multi=False,
            label="Select Result:",
            persistence=True,
        )
        self.set_selector = SetSelector(
            self.id_factory("set-selector"),
            self.id_factory("result-selector"),
            multi=False,
            label="Select Pareto Set (Optional):",
            description="Select an existing set to use as the Pareto front. If empty, it will be calculated.",
        )

    def register_callbacks(self, app):
        self.result_selector.register_callbacks(app)
        self.set_selector.register_callbacks(app)

        # Toggle smart pareto controls visibility
        @callback(
            Output(self.id_factory("smart-pareto-controls"), "style"),
            Input(self.id_factory("smart-pareto-checkbox"), "checked"),
        )
        def toggle_smart_pareto_visibility(checked):
            return {"display": "block"} if checked else {"display": "none"}

        # Toggle between fixed and adaptive controls
        @callback(
            Output(self.id_factory("fixed-controls"), "style"),
            Output(self.id_factory("adaptive-controls"), "style"),
            Input(self.id_factory("smart-pareto-method"), "value"),
        )
        def toggle_method_controls(method):
            if method == "adaptive":
                return {"display": "none"}, {"display": "block"}
            return {"display": "block"}, {"display": "none"}

        # Update graph
        @callback(
            Output(self.id_factory("graph"), "figure"),
            Output(self.id_factory("selected-indices-store"), "data"),
            Output(self.id_factory("notification-area"), "children", allow_duplicate=True),
            Output(self.id_factory("selection-info"), "children"),
            Input(self.id_factory("compute-btn"), "n_clicks"),
            State(self.result_selector.get_value_id(), "value"),
            State(self.set_selector.get_value_id(), "value"),
            State(self.id_factory("smart-pareto-checkbox"), "checked"),
            State(self.id_factory("smart-pareto-method"), "value"),
            State(self.id_factory("epsilon-input"), "value"),
            State(self.id_factory("target-reduction"), "value"),
            State(self.id_factory("min-points"), "value"),
            State(self.id_factory("max-points"), "value"),
            prevent_initial_call=True,
        )
        def update_graph(
            n_clicks,
            result_id,
            set_id,
            smart_pareto_enabled,
            method,
            epsilon,
            target_reduction,
            min_points,
            max_points,
        ):
            if not n_clicks or not result_id:
                return no_update, no_update, no_update, ""

            try:
                result = self.storage_manager.load_result(result_id)
                objectives_df = result.objectives

                if objectives_df.empty:
                    return (
                        no_update,
                        no_update,
                        dmc.Alert(
                            "Result has no objectives defined.",
                            color="red",
                            title="Error",
                            withCloseButton=True,
                        ),
                        "",
                    )

                # Get directions for Pareto calculation
                directions = []
                objective_names = objectives_df.columns.tolist()

                for name in objective_names:
                    meta = result.get_variable_metadata(name)
                    if isinstance(meta, Objective):
                        directions.append(meta.direction)
                    else:
                        # Default to minimization if unknown
                        directions.append(OptimizationDirection.MINIMIZE)

                objectives_np = objectives_df.to_numpy()

                # Initialize DataFrame for plotting with "Dominated" status
                df = objectives_df.copy()
                df["Status"] = "Dominated"

                # Determine Pareto indices (either from set or calculation)
                if set_id:
                    # Use selected set as Pareto front
                    try:
                        selected_set = result.get_set(set_id)
                        pareto_indices = np.array(selected_set.indices)
                        # Ensure indices are valid for current result (in case set is stale or from diff result logic)
                        # Assuming set stores indices valid for this result.
                        valid_indices = pareto_indices[pareto_indices < len(df)]
                        if len(valid_indices) < len(pareto_indices):
                            # Warn or handle mismatch? For now just use valid ones.
                            pareto_indices = valid_indices
                    except Exception:
                        return (
                            no_update,
                            no_update,
                            dmc.Alert(
                                f"Error loading set '{set_id}'.",
                                color="red",
                                title="Error",
                                withCloseButton=True,
                            ),
                            "",
                        )
                else:
                    # 1. Calculate Pareto Front from scratch
                    pareto_mask = identify_pareto_front(objectives_np, directions)
                    pareto_indices = np.where(pareto_mask)[0]

                # Mark Pareto points
                df.loc[df.index[pareto_indices], "Status"] = "Pareto Optimal"
                selected_indices = pareto_indices.tolist()
                selection_info = f"Selected {len(selected_indices)} Pareto Optimal points."

                # 2. Apply Smart Pareto Filter if enabled (ONLY on Pareto set)
                if smart_pareto_enabled:
                    if len(pareto_indices) > 0:
                        # Extract objectives for Pareto points only
                        pareto_objectives = objectives_np[pareto_indices]

                        # Normalize directions for Smart Pareto (minimization)
                        pareto_objectives_smart = pareto_objectives.copy()
                        for i, direction in enumerate(directions):
                            if direction == OptimizationDirection.MAXIMIZE:
                                pareto_objectives_smart[:, i] *= -1

                        # Select filter method
                        if method == "adaptive":
                            smart_local_indices = adaptive_smart_pareto_filter(
                                pareto_objectives_smart,
                                target_reduction=float(target_reduction)
                                if target_reduction is not None
                                else 0.5,
                                min_points=int(min_points) if min_points is not None else 5,
                                max_points=int(max_points) if max_points is not None else None,
                            )
                        else:
                            # Fixed Epsilon
                            eps_val = float(epsilon) if epsilon is not None else None
                            smart_local_indices = smart_pareto_filter(
                                pareto_objectives_smart, epsilon=eps_val
                            )

                        # Map back to global indices
                        smart_global_indices = pareto_indices[smart_local_indices]

                        # Update Status
                        # Points in Pareto front that are NOT selected by Smart Pareto remain "Pareto Optimal"
                        # Points selected by Smart Pareto become "Smart Pareto"
                        df.loc[df.index[smart_global_indices], "Status"] = "Smart Pareto"

                        # For saving/selection, we prioritize Smart Pareto points when enabled
                        selected_indices = smart_global_indices.tolist()
                        selection_info = f"Selected {len(selected_indices)} Smart Pareto points (filtered from {len(pareto_indices)} Pareto points)."
                    else:
                        selection_info = "No Pareto points found to filter."

                # Determine plot type based on dimensions
                n_obj = len(objective_names)

                color_map = {
                    "Dominated": "lightgray",
                    "Pareto Optimal": "#228be6",  # Blue
                    "Smart Pareto": "#fa5252",  # Red
                }

                if n_obj == 2:
                    fig = px.scatter(
                        df,
                        x=objective_names[0],
                        y=objective_names[1],
                        color="Status",
                        color_discrete_map=color_map,
                        title=f"Dominance Analysis ({len(selected_indices)} points selected)",
                        hover_data=objective_names,
                    )
                elif n_obj >= 3:
                    fig = px.scatter_3d(
                        df,
                        x=objective_names[0],
                        y=objective_names[1],
                        z=objective_names[2],
                        color="Status",
                        color_discrete_map=color_map,
                        title=f"Dominance Analysis ({len(selected_indices)} points selected)",
                        hover_data=objective_names,
                    )
                else:
                    # 1D case or empty
                    fig = px.scatter(
                        df,
                        x=df.index,
                        y=objective_names[0] if n_obj > 0 else None,
                        color="Status",
                        color_discrete_map=color_map,
                        title="1D Objective Analysis",
                    )

                fig.update_traces(marker=dict(size=8))
                fig.update_layout(margin=dict(l=0, r=0, t=40, b=0))

                return fig, selected_indices, None, selection_info

            except Exception as e:
                return (
                    no_update,
                    no_update,
                    dmc.Alert(
                        f"Error analyzing results: {str(e)}",
                        color="red",
                        title="Error",
                        withCloseButton=True,
                    ),
                    "",
                )

        # Save set callback
        @callback(
            Output(self.id_factory("notification-area"), "children", allow_duplicate=True),
            Input(self.id_factory("save-btn"), "n_clicks"),
            State(self.result_selector.get_value_id(), "value"),
            State(self.id_factory("set-name"), "value"),
            State(self.id_factory("selected-indices-store"), "data"),
            prevent_initial_call=True,
        )
        def save_set(n_clicks, result_id, set_name, indices):
            if not n_clicks or not result_id or not indices:
                return no_update

            if not set_name:
                return dmc.Alert(
                    "Please enter a name for the set.",
                    color="yellow",
                    title="Warning",
                    withCloseButton=True,
                )

            try:
                result = self.storage_manager.load_result(result_id)

                # Create set and get the object
                new_set = result.create_set(
                    name=set_name,
                    indices=indices,
                    created_by="analysis.dominance",
                    description="Generated via Dominance Analysis page",
                )

                # Save to the specific backend
                parsed_key = storage_helpers.parse_combined_key(result_id)
                if not parsed_key:
                    return dmc.Alert(
                        "Invalid result ID format.",
                        color="red",
                        title="Error",
                        withCloseButton=True,
                    )

                source_id, key = parsed_key
                storage_backend = self.storage_manager.registry.get(source_id)

                if storage_backend:
                    # Use efficient atomic save for the set
                    storage_backend.save_set(key, set_name, new_set)

                    return dmc.Alert(
                        f"Set '{set_name}' created successfully with {len(indices)} points!",
                        color="green",
                        title="Success",
                        withCloseButton=True,
                    )
                else:
                    return dmc.Alert(
                        f"Could not find storage backend for source: {source_id}",
                        color="red",
                        title="Error",
                        withCloseButton=True,
                    )

            except Exception as e:
                return dmc.Alert(
                    f"Error saving set: {str(e)}",
                    color="red",
                    title="Error",
                    withCloseButton=True,
                )

    def layout(self):
        return dmc.Grid(
            [
                dmc.GridCol(
                    [
                        dmc.Stack(
                            [
                                dmc.Title("Dominance Analysis", order=2),
                                dmc.Text(
                                    "Identify Pareto optimal solutions using standard or smart filtering methods.",
                                    size="sm",
                                ),
                                self.result_selector.layout(),
                                self.set_selector.layout(),
                                dmc.Divider(label="Analysis Method"),
                                dmc.Checkbox(
                                    id=self.id_factory("smart-pareto-checkbox"),
                                    label="Enable Smart Pareto Filter",
                                    checked=False,
                                    mb="sm",
                                ),
                                html.Div(
                                    id=self.id_factory("smart-pareto-controls"),
                                    style={"display": "none"},
                                    children=[
                                        dmc.Select(
                                            id=self.id_factory("smart-pareto-method"),
                                            label="Filter Method",
                                            data=[
                                                {
                                                    "value": "fixed",
                                                    "label": "Fixed Distance (Epsilon)",
                                                },
                                                {
                                                    "value": "adaptive",
                                                    "label": "Adaptive Reduction",
                                                },
                                            ],
                                            value="fixed",
                                            mb="md",
                                            allowDeselect=False,
                                        ),
                                        html.Div(
                                            id=self.id_factory("fixed-controls"),
                                            children=[
                                                dmc.NumberInput(
                                                    id=self.id_factory("epsilon-input"),
                                                    label="Epsilon",
                                                    description="Minimum normalized distance. Empty for auto.",
                                                    min=0,
                                                    max=1,
                                                    step=0.01,
                                                    # precision=4,
                                                )
                                            ],
                                        ),
                                        html.Div(
                                            id=self.id_factory("adaptive-controls"),
                                            style={"display": "none"},
                                            children=[
                                                dmc.NumberInput(
                                                    id=self.id_factory("target-reduction"),
                                                    label="Target Reduction",
                                                    description="Fraction of points to keep (0.0 - 1.0)",
                                                    value=0.5,
                                                    min=0.0,
                                                    max=1.0,
                                                    step=0.05,
                                                    mb="sm",
                                                    # precision=2,
                                                ),
                                                dmc.Group(
                                                    [
                                                        dmc.NumberInput(
                                                            id=self.id_factory("min-points"),
                                                            label="Min Points",
                                                            value=5,
                                                            min=1,
                                                            step=1,
                                                        ),
                                                        dmc.NumberInput(
                                                            id=self.id_factory("max-points"),
                                                            label="Max Points",
                                                            placeholder="Unlimited",
                                                            min=1,
                                                            step=1,
                                                        ),
                                                    ],
                                                    grow=True,
                                                ),
                                            ],
                                        ),
                                    ],
                                ),
                                dmc.Button(
                                    "Compute Analysis",
                                    id=self.id_factory("compute-btn"),
                                    leftSection=DashIconify(icon="fluent:play-24-regular"),
                                    fullWidth=True,
                                    mt="md",
                                    mb="md",
                                ),
                                dmc.Divider(label="Save Selection"),
                                dmc.Text(
                                    id=self.id_factory("selection-info"),
                                    size="sm",
                                    c="dimmed",
                                    mb="xs",
                                ),
                                dmc.TextInput(
                                    id=self.id_factory("set-name"),
                                    label="Set Name",
                                    placeholder="e.g., pareto_front",
                                ),
                                dmc.Button(
                                    "Save Set",
                                    id=self.id_factory("save-btn"),
                                    leftSection=DashIconify(icon="fluent:save-24-regular"),
                                    fullWidth=True,
                                ),
                                html.Div(id=self.id_factory("notification-area")),
                            ],
                            gap="md",
                        )
                    ],
                    span=3,
                ),
                dmc.GridCol(
                    [
                        dmc.Paper(
                            dcc.Graph(id=self.id_factory("graph"), style={"height": "80vh"}),
                            withBorder=True,
                            shadow="sm",
                            p="md",
                            radius="md",
                        ),
                        dcc.Store(id=self.id_factory("selected-indices-store")),
                    ],
                    span=9,
                ),
            ],
            gutter="xl",
        )


page_module = DominancePage()
