"""Parallel Coordinates Plot page for visualizing multi-dimensional data."""

import dash
import dash_mantine_components as dmc
import plotly.graph_objects as go
from dash import Input, Output, State, callback, dcc

import optiscope.dash_app.core.glossary as glo
from optiscope.dash_app.components.color_selector import ColorSelector
from optiscope.dash_app.components.column_selector import ColumnSelectorGroup
from optiscope.dash_app.components.result_selector import ResultSelector
from optiscope.dash_app.core.compatibility import create_virtual_storage_manager
from optiscope.dash_app.core.id_factory import IDFactory
from optiscope.dash_app.core.theme_config import LIGHT_THEME
from optiscope.dash_app.pages._base import PageModule
from optiscope.dash_app.utils.helpers import get_graph_id
from optiscope.dash_app.utils.layout_components import create_accordion_sections
from optiscope.plotting.parallel_coordinates import (
    plot_parallel_coordinates,
)


class ParallelCoordinatesPage(PageModule):
    name = "Parallel Coordinates"
    path = "/parallel-coordinates"
    icon = "mdi:math-norm"
    description = "Visualize multi-dimensional data with parallel coordinates plots."
    category = "visualization"
    show_in_home = True

    def __init__(self):
        """Initialize the page with selectors."""
        super().__init__()

        # Create result selector
        self.result_selector = ResultSelector(
            component_id="parallel-plot-page",
            multi=False,
            label="Select Result:",
            description="Choose an optimization result to visualize",
            main_selector_id="main-result-selector",
        )

        # Switch for vertical orientation
        self.vertical_switch = dmc.Switch(
            id="parallel-plot-vertical-switch",
            label="Vertical Orientation",
            checked=False,
            mb="md",
        )

        # Create column selector group
        self.selector_group = ColumnSelectorGroup("parallel-plot-page")

        # Add selector for all columns (variables, objectives, constraints, observables)
        self.selector_group.add_selector(
            selector_id="columns",
            column_types=[
                "variables",
                "objectives",
                "inequality_constraints",
                "equality_constraints",
                "observables",
                "sets",
            ],
            label="Select Columns to Display:",
            # placeholder="Choose columns for parallel plot axes",
            icon="tabler:columns",
            default_count=5,
            result_selector_id=self.result_selector.get_value_id(),
        )

        # Create color selector
        self.color_selector = ColorSelector(
            component_id="parallel-plot-page-color",
            label="Color By:",
            # description="Select a column to color the parallel coordinates by",
            include_result_option=True,
        )

    def register_callbacks(self, app: dash.Dash | None = None) -> None:
        if app is None:
            return

        ids = IDFactory("parallel-plot-page")

        # Register selector callbacks
        self.result_selector.register_callbacks(app)
        self.selector_group.register_all_callbacks(app)
        self.color_selector.register_callbacks(app, self.result_selector.get_value_id())

        # Get selector value IDs
        value_ids = self.selector_group.get_all_value_ids()

        @callback(
            Output(get_graph_id(ids("parallel-plot")), "figure"),
            Output(get_graph_id(ids("parallel-plot")), "className"),
            Input(value_ids["columns"], "value"),
            Input(self.result_selector.get_value_id(), "value"),
            Input(self.color_selector.get_value_id(), "value"),
            Input("parallel-plot-vertical-switch", "checked"),
            State("theme-store", "data"),
            State(glo.REF_STORE_STR, "data"),
        )
        def update_parallel_plot(
            selected_columns,
            selected_result_keys,
            color_by,
            vertical_mode,
            theme,
            stored_data,
        ):
            """Update the parallel coordinates plot."""
            if not stored_data:
                fig = go.Figure()
                fig.add_annotation(
                    text="No data available.",
                    xref="paper",
                    yref="paper",
                    x=0.5,
                    y=0.5,
                    showarrow=False,
                )
                return fig, ""

            storage_manager = create_virtual_storage_manager(stored_data)

            if not selected_result_keys:
                fig = go.Figure()
                fig.add_annotation(
                    text="No results selected.",
                    xref="paper",
                    yref="paper",
                    x=0.5,
                    y=0.5,
                    showarrow=False,
                )
                return fig, ""

            if not isinstance(selected_result_keys, list):
                selected_result_keys = [selected_result_keys]

            results = [storage_manager.load_result(key) for key in selected_result_keys]
            template = theme if theme else LIGHT_THEME

            # Collect sets from all results to include as dimensions
            list_of_sets = []
            for result in results:
                list_of_sets.extend(result._set_manager.list_sets())

            list_of_sets = list(set(list_of_sets))

            selected_sets = [col for col in selected_columns if col in list_of_sets]
            selected_columns = [col for col in selected_columns if col not in list_of_sets]

            fig = plot_parallel_coordinates(
                results=results,
                selected_columns=selected_columns,
                color_by=color_by,
                theme=template,
                include_sets_as_dimensions=False if len(selected_sets) == 0 else selected_sets,
                vertical=vertical_mode,
                width=1500,
            )

            class_name = "vertical-parcoords" if vertical_mode else ""
            return fig, class_name

    def layout(self, **kwargs):
        ids = IDFactory("parallel-plot-page")

        # Get selectors from the group
        columns_selector = self.selector_group.get_selector("columns")

        return dmc.Container(
            children=[
                dmc.Title("Parallel Coordinates Plot", order=2),
                dmc.Text("Visualize multi-dimensional optimization data along parallel axes. "),
                dmc.Space(h=20),
                # Settings Grid
                create_accordion_sections(
                    [
                        {
                            "title": "Filters",
                            "icon": "mdi:filter-menu-outline",
                            "value": "data-viewer-filters",
                            "content": dmc.Stack(
                                [
                                    dmc.Grid(
                                        [
                                            dmc.GridCol(
                                                dmc.Card(
                                                    children=[self.result_selector.layout()],
                                                    withBorder=True,
                                                    shadow="sm",
                                                    p="md",
                                                    mb="md",
                                                ),
                                                span=5,
                                            ),
                                            dmc.GridCol(
                                                dmc.Card(
                                                    children=[columns_selector.layout()],
                                                    withBorder=True,
                                                    shadow="sm",
                                                    p="md",
                                                    mb="md",
                                                ),
                                                span=4,
                                            ),
                                            dmc.GridCol(
                                                dmc.Card(
                                                    children=[
                                                        self.color_selector.layout(),
                                                        dmc.Space(h="md"),
                                                        self.vertical_switch,
                                                    ],
                                                    withBorder=True,
                                                    shadow="sm",
                                                    p="md",
                                                ),
                                                span=3,
                                            ),
                                        ],
                                        mb="md",
                                    ),
                                ]
                            ),
                        }
                    ]
                ),
                # Parallel coordinates plot
                dmc.Card(
                    children=[
                        dcc.Graph(
                            id=get_graph_id(ids("parallel-plot")),
                            config={
                                "displayModeBar": True,
                                "displaylogo": False,
                                "modeBarButtonsToRemove": ["lasso2d", "select2d"],
                            },
                        ),
                    ],
                    withBorder=True,
                    shadow="sm",
                    p="md",
                ),
            ],
            fluid=True,
        )


page_module = ParallelCoordinatesPage()
