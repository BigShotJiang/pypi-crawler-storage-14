import logging

import dash
import dash_mantine_components as dmc
from dash import ALL, Input, Output, State, callback, ctx, dcc, html, no_update

from optiscope.dash_app.components.result_selector import ResultSelector
from optiscope.dash_app.core import storage_helpers
from optiscope.dash_app.core.compatibility import create_virtual_storage_manager
from optiscope.dash_app.core.id_factory import IDFactory
from optiscope.dash_app.pages._base import PageModule

logger = logging.getLogger(__name__)


class SetsManagerPage(PageModule):
    name = "Sets Manager"
    path = "/sets_manager"
    icon = "mdi:format-list-group"
    description = "Add, edit, or delete sets for each result/source."
    category = "data"
    show_in_home = True

    def __init__(self):
        super().__init__()
        self.ids = IDFactory("sets-manager-page")
        self.result_selector = ResultSelector(
            component_id="sets-manager-result-selector",
            multi=False,
            label="Select Result:",
            description="Choose an optimization result to manage its sets.",
        )

    def _create_default_sets(self, source_id, result_key):
        """Creates feasible, non-feasible, pareto_front, and optimal sets for a given result."""
        from optiscope.dash_app.utils.default_sets import create_default_sets

        create_default_sets(source_id, result_key)

    def register_callbacks(self, app: dash.Dash | None = None) -> None:
        """Register page-specific callbacks."""
        self.result_selector.register_callbacks(app)

        @callback(
            Output(self.ids("sets-table-container"), "children"),
            Input(self.result_selector.get_value_id(), "value"),
            State("storage-references", "data"),
            Input("storage-references", "data"),
        )
        def update_sets_table(selected_result, stored_data, _):
            if not stored_data or not selected_result:
                return dmc.Text("Select a result to see its sets.", c="gray")

            storage_manager = create_virtual_storage_manager(stored_data)
            result = storage_manager.load_result(selected_result)
            set_names = result.list_sets()

            if not set_names:
                return dmc.Text("No sets found for this result.", c="gray")

            header = dmc.TableThead(
                dmc.TableTr(
                    [
                        dmc.TableTh(""),
                        dmc.TableTh("Name"),
                        dmc.TableTh("Description"),
                        dmc.TableTh("Size"),
                    ]
                )
            )

            rows = []
            for name in set_names:
                set_obj = result.get_set(name)
                rows.append(
                    dmc.TableTr(
                        [
                            dmc.TableTd(
                                dmc.Checkbox(id={"type": self.ids("set-checkbox"), "index": name})
                            ),
                            dmc.TableTd(set_obj.name),
                            dmc.TableTd(getattr(set_obj, "description", "")),
                            dmc.TableTd(len(set_obj.indices)),
                        ]
                    )
                )
            body = dmc.TableTbody(rows)

            return dmc.Table([header, body])

        @callback(
            Output(self.ids("selected-sets-store"), "data"),
            Input({"type": self.ids("set-checkbox"), "index": ALL}, "checked"),
            State({"type": self.ids("set-checkbox"), "index": ALL}, "id"),
        )
        def update_selected_sets(checked_values, ids):
            selected = [id["index"] for id, checked in zip(ids, checked_values) if checked]
            return selected

        @callback(
            Output(self.ids("set-modal"), "opened"),
            Output(self.ids("set-modal-title"), "children"),
            Output(self.ids("set-name-input"), "value"),
            Output(self.ids("set-description-input"), "value"),
            Output(self.ids("set-indices-input-wrapper"), "style"),
            Input(self.ids("add-set-btn"), "n_clicks"),
            Input(self.ids("edit-set-btn"), "n_clicks"),
            State(self.ids("selected-sets-store"), "data"),
            State(self.result_selector.get_value_id(), "value"),
            State("storage-references", "data"),
            prevent_initial_call=True,
        )
        def open_set_modal(add_clicks, edit_clicks, selected_sets, selected_result, stored_data):
            if not ctx.triggered_id or not selected_result:
                return no_update

            button_id = ctx.triggered_id

            if button_id == self.ids("add-set-btn"):
                return True, "Add New Set", "", "", {"display": "block"}

            if button_id == self.ids("edit-set-btn"):
                if not selected_sets or len(selected_sets) != 1:
                    # TODO: Add notification
                    return no_update

                storage_manager = create_virtual_storage_manager(stored_data)
                result = storage_manager.load_result(selected_result)
                set_to_edit = result.get_set(selected_sets[0])

                return (
                    True,
                    f"Edit Set: {set_to_edit.name}",
                    set_to_edit.name,
                    getattr(set_to_edit, "description", ""),
                    {"display": "none"},
                )

            return no_update

        @callback(
            Output(self.ids("set-modal"), "opened", allow_duplicate=True),
            Input(self.ids("save-set-btn"), "n_clicks"),
            State(self.ids("set-modal-title"), "children"),
            State(self.ids("set-name-input"), "value"),
            State(self.ids("set-description-input"), "value"),
            State(self.ids("set-indices-input"), "value"),
            State(self.result_selector.get_value_id(), "value"),
            State("storage-references", "data"),
            prevent_initial_call=True,
        )
        def save_set(
            n_clicks, modal_title, name, description, indices_str, selected_result, stored_data
        ):
            if not n_clicks or not name or not selected_result:
                return no_update

            result = storage_helpers.get_result_by_combined_key(selected_result, stored_data)
            source_id, result_key = selected_result.split("::", 1)
            storage = storage_helpers.get_source_storage(source_id)

            if not result:
                return stored_data, False

            if "Edit Set" in modal_title:
                original_name = modal_title.split(": ")[1]
                set_to_edit = result.get_set(original_name)
                set_to_edit.name = name
                set_to_edit.description = description
                if original_name != name:
                    storage.delete_set(result_key, original_name)
                    storage.save_set(result_key, name, set_to_edit)
            else:  # Add new set
                try:
                    indices = [int(i.strip()) for i in indices_str.split(",") if i.strip()]
                    set = result.create_set(
                        name=name,
                        indices=indices,
                        description=description,
                        created_by="sets-manager",
                    )
                    storage.save_set(result_key, name, set)
                except (ValueError, AttributeError):
                    # TODO: Add notification for invalid indices
                    return no_update

            return False

        @callback(
            Output(self.ids("delete-confirm-modal"), "opened"),
            Input(self.ids("delete-set-btn"), "n_clicks"),
            Input(self.ids("cancel-delete-btn"), "n_clicks"),
            State(self.ids("delete-confirm-modal"), "opened"),
            prevent_initial_call=True,
        )
        def toggle_delete_modal(delete_clicks, cancel_clicks, opened):
            if not ctx.triggered_id:
                return no_update
            return not opened

        @callback(
            Output(self.ids("delete-confirm-modal"), "opened", allow_duplicate=True),
            Input(self.ids("confirm-delete-btn"), "n_clicks"),
            State(self.ids("selected-sets-store"), "data"),
            State(self.result_selector.get_value_id(), "value"),
            State("storage-references", "data"),
            prevent_initial_call=True,
        )
        def delete_set(n_clicks, selected_sets, selected_result, stored_data):
            if not n_clicks or not selected_sets or not selected_result:
                return no_update, no_update

            source_id, result_key = selected_result.split("::", 1)
            storage = storage_helpers.get_source_storage(source_id)

            for set_name in selected_sets:
                storage.delete_set(result_key, set_name)

            return False

        @callback(
            Input(self.ids("add-default-btn"), "n_clicks"),
            State(self.result_selector.get_value_id(), "value"),
            prevent_initial_call=True,
        )
        def create_default_sets(n_clicks, selected_result):
            if not n_clicks or not selected_result:
                return

            source_id, result_key = selected_result.split("::", 1)
            self._create_default_sets(source_id, result_key)

    def layout(self, **kwargs):
        return dmc.Container(
            children=[
                dcc.Store(id=self.ids("selected-sets-store")),
                dmc.Title("Sets Manager", order=2),
                dmc.Text("Add, edit, or delete sets for each result/source."),
                dmc.Space(h=20),
                self.result_selector.layout(),
                dmc.Space(h=20),
                dmc.Paper(
                    [
                        dmc.Group(
                            [
                                dmc.Title("Sets", order=3),
                                dmc.Group(
                                    [
                                        dmc.Button(
                                            "Create Default Sets", id=self.ids("add-default-btn")
                                        ),
                                        dmc.Button("Add New Set", id=self.ids("add-set-btn")),
                                        dmc.Button(
                                            "Edit Set",
                                            id=self.ids("edit-set-btn"),
                                            variant="outline",
                                        ),
                                        dmc.Button(
                                            "Delete Set", id=self.ids("delete-set-btn"), color="red"
                                        ),
                                    ]
                                ),
                            ],
                            justify="space-between",
                        ),
                        dmc.Space(h="md"),
                        html.Div(id=self.ids("sets-table-container")),
                    ],
                    withBorder=True,
                    p="md",
                    mt="md",
                ),
                dmc.Modal(
                    id=self.ids("set-modal"),
                    title=dmc.Title(id=self.ids("set-modal-title"), order=3),
                    children=[
                        dmc.TextInput(
                            label="Set Name",
                            id=self.ids("set-name-input"),
                            required=True,
                        ),
                        dmc.Textarea(
                            label="Description",
                            id=self.ids("set-description-input"),
                            mt="md",
                        ),
                        html.Div(
                            [
                                dmc.Textarea(
                                    label="Indices (comma-separated)",
                                    id=self.ids("set-indices-input"),
                                    placeholder="e.g., 1, 2, 5, 10",
                                    mt="md",
                                )
                            ],
                            id=self.ids("set-indices-input-wrapper"),
                        ),
                        dmc.Group(
                            [
                                dmc.Button("Save", id=self.ids("save-set-btn"), mt="md"),
                            ],
                            justify="flex-end",
                        ),
                    ],
                ),
                dmc.Modal(
                    id=self.ids("delete-confirm-modal"),
                    title="Confirm Deletion",
                    children=[
                        dmc.Text(
                            "Are you sure you want to delete the selected sets? This action cannot be undone."
                        ),
                        dmc.Group(
                            [
                                dmc.Button(
                                    "Cancel", id=self.ids("cancel-delete-btn"), variant="default"
                                ),
                                dmc.Button(
                                    "Delete", id=self.ids("confirm-delete-btn"), color="red"
                                ),
                            ],
                            justify="flex-end",
                            mt="md",
                        ),
                    ],
                ),
            ],
            fluid=True,
        )


page_module = SetsManagerPage()
