"""Scatterplot Matrix page for visualizing variable and objective relationships."""

import dash
import dash_mantine_components as dmc
import plotly.express as px
from dash import Input, Output, State, callback, dcc

import optiscope.dash_app.core.glossary as glo
from optiscope.dash_app.components.column_selector import ColumnSelectorGroup
from optiscope.dash_app.components.result_selector import ResultSelector
from optiscope.dash_app.core.compatibility import create_virtual_storage_manager
from optiscope.dash_app.core.id_factory import IDFactory
from optiscope.dash_app.core.theme_config import LIGHT_THEME
from optiscope.dash_app.pages._base import PageModule
from optiscope.dash_app.utils.helpers import get_graph_id
from optiscope.dash_app.utils.layouts import create_two_column_layout
from optiscope.plotting.scatter_matrix import plot_scatter_matrix


class ScatterplotMatrixPage(PageModule):
    name = "Scatterplot Matrix"
    path = "/scatterplot-matrix"
    icon = "mdi:scatter-plot"
    description = "View scatterplot matrices of variables and objectives."
    category = "visualization"
    show_in_home = True

    def __init__(self):
        """Initialize the page with column selectors."""
        super().__init__()

        # Create result selector
        self.result_selector = ResultSelector(
            component_id="scatterplot-matrix-page",
            multi=False,
            label="Select Result:",
            description="Choose an optimization result to visualize",
            main_selector_id="main-result-selector",
        )

        # Create column selector group
        self.selector_group = ColumnSelectorGroup("scatterplot-matrix-page")

        # Add selectors for variables and objectives
        self.selector_group.add_selector(
            selector_id="variables",
            column_types=["variables"],
            label="Select Variables:",
            placeholder="Select variables to display",
            icon="tabler:box-align-bottom",
            default_count=3,
        )

        self.selector_group.add_selector(
            selector_id="objectives",
            column_types=["objectives"],
            label="Select Objectives:",
            placeholder="Select objectives to display",
            icon="tabler:target",
            default_count=3,
        )

        self.selector_group.add_selector(
            selector_id="observables",
            column_types=["observables"],
            label="Select Observables:",
            placeholder="Select observables to display",
            icon=glo.ICON_OBSERVABLES,
            default_count=3,
        )

    def register_callbacks(self, app: dash.Dash | None = None) -> None:
        if app is None:
            return

        ids = IDFactory("scatterplot-matrix-page")

        # Register selector callbacks
        self.result_selector.register_callbacks(app)
        self.selector_group.register_all_callbacks(app)

        # Get selector value IDs
        value_ids = self.selector_group.get_all_value_ids()

        @callback(
            Output(get_graph_id(ids("scatter-matrix-plot")), "figure"),
            Input(value_ids["variables"], "value"),
            Input(value_ids["objectives"], "value"),
            Input(value_ids["observables"], "value"),
            Input(self.result_selector.get_value_id(), "value"),
            State("theme-store", "data"),
            State(glo.REF_STORE_STR, "data"),
        )
        def update_plots(
            selected_variables,
            selected_objectives,
            selected_observables,
            selected_result_key,
            theme,
            stored_data,
        ):
            if not stored_data or not selected_result_key:
                empty_fig = px.scatter(title="No data available")
                return empty_fig

            # Handle potential list input for result key
            if isinstance(selected_result_key, list):
                if not selected_result_key:
                    empty_fig = px.scatter(title="No data available")
                    return empty_fig
                result_key = selected_result_key[0]
            else:
                result_key = selected_result_key

            # Apply theme template
            template = theme if theme else LIGHT_THEME

            storage_manager = create_virtual_storage_manager(stored_data)

            try:
                result = storage_manager.load_result(result_key)
            except Exception:
                empty_fig = px.scatter(title="Error loading result")
                return empty_fig

            # Helper to create plot
            def create_splom(variables, title):
                if not variables:
                    return px.scatter(title=f"Select variables for {title}")
                if len(variables) < 2:
                    return px.scatter(title=f"Select at least 2 variables for {title}")

                try:
                    fig = plot_scatter_matrix(
                        result,
                        variables=variables,
                        include_objectives=False,
                        include_design_vars=False,
                        title=title,
                        width=None,
                    )
                    fig.update_layout(template=template)
                    return fig
                except Exception as e:
                    return px.scatter(title=f"Error creating {title}: {str(e)}")

            # Create variables scatterplot matrix
            scatterplot_fig = create_splom(
                selected_variables + selected_objectives + selected_observables, ""
            )

            return scatterplot_fig

    def layout(self, **kwargs):
        ids = IDFactory("scatterplot-matrix-page")

        # Sidebar content
        sidebar_content = dmc.Stack(
            [
                dmc.Title("Controls", order=4),
                self.result_selector.layout(),
                dmc.Divider(),
                *[s.layout() for s in self.selector_group.selectors.values()],
            ],
            gap="md",
        )

        # Main content
        main_content = dmc.Stack(
            [
                dmc.Title("Scatterplot Matrix", order=2),
                dmc.Text(
                    "Visualize relationships between variables and objectives using scatterplot matrices."
                ),
                dcc.Graph(
                    id=get_graph_id(ids("scatter-matrix-plot")),
                    config={"displayModeBar": True, "displaylogo": False},
                ),
            ],
            gap="lg",
        )

        return create_two_column_layout(
            right_content=sidebar_content,
            left_content=main_content,
            left_span=9,
            right_span=3,
        )


page_module = ScatterplotMatrixPage()
