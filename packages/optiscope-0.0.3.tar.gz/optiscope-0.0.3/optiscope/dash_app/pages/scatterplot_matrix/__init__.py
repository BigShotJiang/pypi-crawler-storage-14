"""Scatterplot Matrix page module."""

from .page import page_module

__all__ = ["page_module"]
