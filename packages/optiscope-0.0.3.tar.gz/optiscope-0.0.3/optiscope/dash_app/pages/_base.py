from __future__ import annotations

from abc import ABC, abstractmethod

from dash import Dash
from dash.development.base_component import Component

from optiscope.dash_app.core.storage_helpers import validate_source_store


class PageModule(ABC):
    """Base class for all pages"""

    # Required attributes
    name: str  # Display name
    path: str  # URL path (e.g., "/pareto-explorer")
    icon: str  # Icon name
    description: str  # Short description

    # Optional attributes
    requires_data: bool = True  # Whether page needs uploaded data
    category: str = ""  # Defaults to main
    show_in_home: bool = False
    show_at_bottom: bool = False
    hidden_from_nav: bool = False

    @abstractmethod
    def layout(self, **kwargs) -> Component:
        """Return the page layout"""
        pass

    def register_callbacks(self, app: Dash | None = None) -> None:
        """Register page-specific callbacks"""
        pass

    def get_storage_keys(self) -> list[str]:
        """Define page-specific storage keys"""
        return []

    def get_documentation(self) -> str:
        """Return page documentation (markdown)"""
        return ""

    def is_available(self, app=None, stored_data=None) -> tuple[bool, str]:
        """Check if valid data is loaded"""
        if self.requires_data:
            if not stored_data:
                return False, "No data loaded"

            try:
                if not validate_source_store(stored_data):
                    return False, "Invalid data"
            except Exception as e:
                return False, f"Data validation failed: {str(e)}"

            if len(stored_data.get("sources", {})) == 0:
                return False, "No data sources available"

        return True, ""
