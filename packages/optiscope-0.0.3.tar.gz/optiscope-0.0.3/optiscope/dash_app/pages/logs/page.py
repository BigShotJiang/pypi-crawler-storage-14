from dash import Input, Output, callback, dcc, html

from optiscope.dash_app.core.logging import _log_handler
from optiscope.dash_app.pages._base import PageModule


class LogsPage(PageModule):
    name = "Logs"
    path = "/logs"
    icon = "mdi:file-document-outline"
    description = "View and filter logs from the application."
    category = "debug"
    requires_data = False

    def __init__(self):
        super().__init__()
        # Sample log data, now an instance attribute
        self.log_data = _log_handler.logs

    def layout(self, **kwargs):
        """Returns the layout of the page."""
        return html.Div(
            [
                html.H1("Log Viewer"),
                dcc.Dropdown(
                    id="log-name-filter",
                    options=[
                        {"label": name, "value": name}
                        for name in set(log["name"] for log in self.log_data)
                    ],
                    placeholder="Select a log name",
                    multi=True,
                ),
                html.Div(id="log-table"),
            ]
        )

    def register_callbacks(self, app):
        """Registers the callbacks for the page."""

        @callback(Output("log-table", "children"), Input("log-name-filter", "value"))
        def update_log_table(selected_names):
            if not selected_names:
                filtered_logs = self.log_data
            else:
                filtered_logs = [log for log in self.log_data if log["name"] in selected_names]

            # CSS styling for the table
            table_style = {"borderCollapse": "collapse", "width": "100%", "marginTop": "20px"}

            th_style = {
                "border": "1px solid #ddd",
                "padding": "8px",
                "textAlign": "left",
                "backgroundColor": "#f2f2f2",
            }

            td_style = {"border": "1px solid #ddd", "padding": "8px", "textAlign": "left"}

            return html.Table(
                style=table_style,
                children=[
                    html.Thead(
                        html.Tr(
                            [
                                html.Th(col, style=th_style)
                                for col in ["Timestamp", "Name", "Level", "Message"]
                            ]
                        )
                    ),
                    html.Tbody(
                        [
                            html.Tr(
                                [
                                    html.Td(log["timestamp"], style=td_style),
                                    html.Td(log["name"], style=td_style),
                                    html.Td(log["level"], style=td_style),
                                    html.Td(log["message"], style=td_style),
                                ]
                            )
                            for log in filtered_logs
                        ]
                    ),
                ],
            )


# Instantiate the page
page_module = LogsPage()
