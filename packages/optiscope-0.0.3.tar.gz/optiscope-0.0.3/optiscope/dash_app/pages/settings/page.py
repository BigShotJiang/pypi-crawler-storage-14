import base64
import json

import dash
import dash_mantine_components as dmc
from dash import Input, Output, State, callback, dcc, html, no_update
from dash_iconify import DashIconify

from optiscope.dash_app.core.id_factory import IDFactory
from optiscope.dash_app.core.settings_manager import SettingsManager
from optiscope.dash_app.core.settings_schema import (
    SETTINGS_SCHEMA,
    get_default_settings,
    get_optiscope_version,
)
from optiscope.dash_app.core.settings_ui import create_settings_preview, create_settings_ui
from optiscope.dash_app.pages._base import PageModule
from optiscope.dash_app.utils.layouts import create_two_column_layout


class SettingsPage(PageModule):
    name = "Settings"
    path = "/settings"
    icon = "mdi:cog-outline"
    description = "Configure application settings."
    show_at_bottom = True
    requires_data = False

    def register_callbacks(self, app: dash.Dash) -> None:
        ids = IDFactory("settings-page")

        @callback(
            Output("user-settings-store", "data", allow_duplicate=True),
            Output(ids("notification-container"), "children"),
            Input(ids("save-settings-btn"), "n_clicks"),
            State("user-settings-store", "data"),
            State("session-id", "data"),
            *[
                State(
                    ids(f"setting-{setting.key}"),
                    "value" if setting.type.value != "switch" else "checked",
                )
                for setting in SETTINGS_SCHEMA
            ],
            prevent_initial_call=True,
        )
        def save_settings(n_clicks, current_settings, session_id, *setting_values):
            """Save all settings."""
            if not n_clicks:
                return no_update, no_update

            # Get app mode from config
            from optiscope.dash_app.core import config

            app_mode = getattr(config, "APP_MODE", "local")

            # Create settings manager
            manager = SettingsManager(app_mode=app_mode)

            # Update settings with current values
            updates = {
                setting.key: value for setting, value in zip(SETTINGS_SCHEMA, setting_values)
            }
            manager.update_settings(updates)

            # Save settings
            settings_dict = manager.save_settings()

            notification = dmc.Notification(
                id=ids("save-notification"),
                title="Settings Saved",
                message="Your settings have been saved successfully.",
                color="green",
                icon=DashIconify(icon="mdi:check-circle"),
                action="show",
            )

            return settings_dict, notification

        @callback(
            Output(ids("settings-preview"), "children"),
            Input("user-settings-store", "data"),
        )
        def update_preview(settings_data):
            """Update the settings preview when settings change."""
            if not settings_data:
                settings_data = get_default_settings().model_dump()

            return create_settings_preview(settings_data)

        @callback(
            Output(ids("download-settings"), "data"),
            Input(ids("export-btn"), "n_clicks"),
            State("user-settings-store", "data"),
            prevent_initial_call=True,
        )
        def export_settings(n_clicks, settings_data):
            """Export settings to JSON file."""
            if not n_clicks:
                return no_update

            if not settings_data:
                settings_data = get_default_settings().model_dump()

            json_string = json.dumps(settings_data, indent=2)

            return dict(
                content=json_string,
                filename="optiscope_settings.json",
            )

        @callback(
            Output("user-settings-store", "data", allow_duplicate=True),
            Output(ids("notification-container"), "children", allow_duplicate=True),
            Input(ids("upload-settings"), "contents"),
            State(ids("upload-settings"), "filename"),
            State("session-id", "data"),
            prevent_initial_call=True,
        )
        def import_settings(contents, filename, session_id):
            """Import settings from uploaded JSON file."""
            if not contents:
                return no_update, no_update

            # Get app mode from config
            from optiscope.dash_app.core import config

            app_mode = getattr(config, "APP_MODE", "local")

            try:
                # Decode the uploaded file
                content_type, content_string = contents.split(",")
                decoded = base64.b64decode(content_string).decode("utf-8")

                # Create settings manager and import
                manager = SettingsManager(app_mode=app_mode)
                success, message = manager.import_settings(decoded)

                if success:
                    settings_dict = manager.save_settings()
                    notification = dmc.Notification(
                        id=ids("import-notification"),
                        title="Settings Imported",
                        message=message,
                        color="green" if "successfully" in message.lower() else "yellow",
                        icon=DashIconify(icon="mdi:check-circle"),
                        action="show",
                    )
                    return settings_dict, notification
                else:
                    notification = dmc.Notification(
                        id=ids("import-error"),
                        title="Import Failed",
                        message=message,
                        color="red",
                        icon=DashIconify(icon="mdi:alert-circle"),
                        action="show",
                    )
                    return no_update, notification

            except Exception as e:
                notification = dmc.Notification(
                    id=ids("import-error"),
                    title="Import Failed",
                    message=f"Failed to read file: {str(e)}",
                    color="red",
                    icon=DashIconify(icon="mdi:alert-circle"),
                    action="show",
                )
                return no_update, notification

        @callback(
            Output("user-settings-store", "data", allow_duplicate=True),
            Output(ids("notification-container"), "children", allow_duplicate=True),
            Input(ids("reset-btn"), "n_clicks"),
            State("session-id", "data"),
            prevent_initial_call=True,
        )
        def reset_settings(n_clicks, session_id):
            """Reset settings to defaults."""
            if not n_clicks:
                return no_update, no_update

            # Get app mode from config
            from optiscope.dash_app.core import config

            app_mode = getattr(config, "APP_MODE", "local")

            # Create settings manager and reset
            manager = SettingsManager(app_mode=app_mode)
            manager.reset_to_defaults()
            settings_dict = manager.save_settings()

            notification = dmc.Notification(
                id=ids("reset-notification"),
                title="Settings Reset",
                message="All settings have been reset to their default values.",
                color="blue",
                icon=DashIconify(icon="mdi:refresh"),
                action="show",
            )

            return settings_dict, notification

    def layout(self, **kwargs):
        ids = IDFactory("settings-page")

        # Get current settings from store or use defaults
        current_settings = kwargs.get("user-settings-store", {})
        if not current_settings:
            current_settings = get_default_settings().model_dump()

        # Left column: Settings controls
        left_content = [
            dmc.Title("Application Settings", order=2),
            dmc.Text(
                "Configure your OptiScope preferences. Changes are saved per session in deployed mode, "
                "or globally in local mode.",
                size="sm",
                c="dimmed",
                mb="md",
            ),
            dmc.Space(h=20),
            dmc.Accordion(
                children=create_settings_ui(current_settings, ids),
                value=["general", "display", "data"],  # Expand all by default
                multiple=True,
                variant="separated",
            ),
            dmc.Space(h=30),
            dmc.Button(
                "Save Settings",
                id=ids("save-settings-btn"),
                leftSection=DashIconify(icon="mdi:content-save"),
                color="blue",
                fullWidth=True,
            ),
        ]

        # Right column: Preview and import/export
        right_content = [
            dmc.Alert(
                title="Work in Progress",
                children="Settings are still a work in progress, and some features may not work as expected.",
                color="red",
            ),
            # dmc.Title("Current Settings", order=2),
            # dmc.Space(h=20),
            # dmc.Card(
            #     id=ids("settings-preview"),
            #     children=create_settings_preview(current_settings),
            #     withBorder=True,
            #     shadow="sm",
            #     p="md",
            #     mb="xl",
            # ),
            dmc.Title("Import / Export", order=3),
            dmc.Space(h=20),
            dmc.Stack(
                [
                    dmc.Text(
                        "Export your settings to a JSON file or import settings from a file.",
                        size="sm",
                        c="dimmed",
                    ),
                    dmc.Button(
                        "Export Settings",
                        id=ids("export-btn"),
                        leftSection=DashIconify(icon="mdi:download"),
                        variant="light",
                        fullWidth=True,
                    ),
                    dcc.Download(id=ids("download-settings")),
                    dmc.Divider(label="OR", labelPosition="center"),
                    dcc.Upload(
                        id=ids("upload-settings"),
                        children=dmc.Button(
                            "Import Settings",
                            leftSection=DashIconify(icon="mdi:upload"),
                            variant="light",
                            fullWidth=True,
                        ),
                    ),
                    dmc.Divider(),
                    dmc.Button(
                        "Reset to Defaults",
                        id=ids("reset-btn"),
                        leftSection=DashIconify(icon="mdi:refresh"),
                        color="red",
                        variant="subtle",
                        fullWidth=True,
                    ),
                ],
                gap="md",
            ),
            dmc.Space(h=30),
            dmc.Card(
                [
                    dmc.Text("Version Information", fw=600, size="sm"),
                    dmc.Space(h=10),
                    dmc.Text(
                        f"OptiScope Version: {get_optiscope_version()}",
                        size="sm",
                        c="dimmed",
                    ),
                    dmc.Text(
                        f"Settings Version: {current_settings.get('version', 'Unknown')}",
                        size="sm",
                        c="dimmed",
                    ),
                ],
                withBorder=True,
                p="md",
            ),
        ]

        return html.Div(
            [
                html.Div(id=ids("notification-container")),
                create_two_column_layout(left_content, right_content),
            ]
        )


page_module = SettingsPage()
