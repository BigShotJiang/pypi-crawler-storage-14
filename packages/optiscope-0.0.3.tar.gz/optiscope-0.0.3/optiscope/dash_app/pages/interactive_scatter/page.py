import dash
import dash_mantine_components as dmc
import numpy as np
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from dash import Input, Output, State, callback, dcc
from dash_extensions.logging import DivLogHandler

import optiscope.dash_app.core.glossary as glo
from optiscope.core.data_types import DataTypeCategory
from optiscope.dash_app.components.result_selector import ResultSelector
from optiscope.dash_app.components.set_selector import SetSelector
from optiscope.dash_app.core.compatibility import create_virtual_storage_manager
from optiscope.dash_app.core.id_factory import IDFactory
from optiscope.dash_app.core.storage_helpers import get_result_by_combined_key
from optiscope.dash_app.core.theme_config import LIGHT_THEME
from optiscope.dash_app.pages._base import PageModule
from optiscope.dash_app.utils.layout_components import create_tabbed_section
from optiscope.plotting.interactive_scatter import create_interactive_scatter

log_handler = DivLogHandler()
logger = log_handler.setup_logger(__name__)


class InteractiveScatterPage(PageModule):
    name = "Interactive Scatter"
    path = "/interactive_scatter"
    icon = "fluent:chart-multiple-24-regular"
    description = "An interactive scatter plot to explore relationships between variables."
    category = "visualization"
    show_in_home = True

    def __init__(self):
        """Initialize the page."""
        super().__init__()
        self.ids = IDFactory("interactive-scatter")

        # Create result selector
        self.result_selector = ResultSelector(
            component_id="interactive-scatter",
            multi=False,
            label="Select Results to Compare:",
            description="Choose one or more optimization results to visualize together",
            main_selector_id="main-result-selector",
        )

        self.set_selector = SetSelector(
            component_id="interactive-scatter-set-selector",
            result_selector_id="interactive-scatter",
            multi=True,
            label="Filter by Set",
        )

    @staticmethod
    def _in_paper(content, **kwargs):
        options = {
            "radius": "sm",
            "p": "lg",
            "shadow": "sm",
            "withBorder": False,
        } | kwargs

        return dmc.Paper(content, **options)

    def layout(self):
        return dmc.Container(
            [
                dmc.Grid(
                    [
                        dmc.GridCol(self.result_selector.layout(), span=12),
                        dmc.GridCol(
                            dmc.Select(
                                id=self.ids("x-axis"),
                                label="X-Axis",
                                renderOption={"function": "renderOptionSelect"},
                                persistence=True,
                                persistence_type="session",
                            ),
                            span=2,
                        ),
                        dmc.GridCol(
                            dmc.Select(
                                id=self.ids("y-axis"),
                                label="Y-Axis",
                                renderOption={"function": "renderOptionSelect"},
                                persistence=True,
                                persistence_type="session",
                            ),
                            span=2,
                        ),
                        dmc.GridCol(
                            dmc.Select(
                                id=self.ids("color-by"),
                                label="Color By",
                                renderOption={"function": "renderOptionSelect"},
                                persistence=True,
                                persistence_type="session",
                            ),
                            span=2,
                        ),
                        dmc.GridCol(
                            dmc.Select(
                                id=self.ids("marker-by"),
                                label="Marker By",
                                renderOption={"function": "renderOptionSelect"},
                                persistence=True,
                                persistence_type="session",
                            ),
                            span=2,
                        ),
                        dmc.GridCol(self.set_selector.layout(), span=4),
                    ]
                ),
                dmc.Grid(
                    [
                        dmc.GridCol(
                            self._in_paper(dcc.Graph(id=self.ids("scatter-plot"))),
                            span=6,
                        ),
                        dmc.GridCol(
                            create_tabbed_section(
                                tabs=[
                                    {
                                        "value": self.ids("tab-plot-vars"),
                                        "label": "Design variables",
                                        "content": self._in_paper(
                                            dcc.Graph(id=self.ids("bar-plot-vars"))
                                        ),
                                    },
                                    {
                                        "value": self.ids("tab-plot-obj"),
                                        "label": "Objectives",
                                        "content": self._in_paper(
                                            dcc.Graph(id=self.ids("bar-plot-obj"))
                                        ),
                                    },
                                    {
                                        "value": self.ids("tab-plot-obs"),
                                        "label": "Observables",
                                        "content": self._in_paper(
                                            dcc.Graph(id=self.ids("bar-plot-obs"))
                                        ),
                                    },
                                ]
                            ),
                            span=6,
                        ),
                    ],
                ),
            ],
            fluid=True,
        )

    def register_callbacks(self, app: dash.Dash | None = None) -> None:
        self.result_selector.register_callbacks(app)
        self.set_selector.register_callbacks(app)

        @callback(
            Output(self.ids("x-axis"), "data"),
            Output(self.ids("y-axis"), "data"),
            Output(self.ids("color-by"), "data"),
            Output(self.ids("marker-by"), "data"),
            Input(self.result_selector.get_value_id(), "value"),
            State(glo.REF_STORE_STR, "data"),
            State("session-id", "data"),
        )
        def update_dropdowns(selected_results, ref_store, session_id):
            if not selected_results:
                logger.debug("No results selected; clearing dropdown options.")
                return [], [], [], []
            # Collect all columns with their types
            all_vars_info = {}

            if isinstance(selected_results, str):
                selected_results = [selected_results]

            for result_id in selected_results:
                result_set = get_result_by_combined_key(result_id, ref_store)

                # Helper to add columns with type
                def add_cols(cols, type_code):
                    for col in cols:
                        if col not in all_vars_info:
                            all_vars_info[col] = {"label": col, "value": col, "type": type_code}

                add_cols(result_set.design_variables.columns, "var")
                add_cols(result_set.objectives.columns, "obj")
                add_cols(result_set.inequality_constraints.columns, "con")
                add_cols(result_set.equality_constraints.columns, "con")
                add_cols(result_set.observables.columns, "obs")

            # Sort by label
            sorted_vars = sorted(all_vars_info.values(), key=lambda x: x["label"])

            # Create options for color/marker (include Set)
            color_marker_options = [{"label": "Set", "value": "Set", "type": "var"}] + sorted_vars

            return sorted_vars, sorted_vars, color_marker_options, color_marker_options

        @callback(
            Output(self.ids("scatter-plot"), "figure"),
            Input(self.result_selector.get_value_id(), "value"),
            Input(self.ids("x-axis"), "value"),
            Input(self.ids("y-axis"), "value"),
            Input(self.ids("color-by"), "value"),
            Input(self.ids("marker-by"), "value"),
            Input(self.set_selector.get_value_id(), "value"),
            State(glo.REF_STORE_STR, "data"),
            State("theme-store", "data"),
        )
        def update_scatter_plot(
            selected_results,
            x_axis,
            y_axis,
            color_by,
            marker_by,
            set_filter,
            ref_store,
            theme,
        ):
            empty_fig = go.Figure()
            empty_fig.add_annotation(
                text="No data available",
                xref="paper",
                yref="paper",
                x=0.5,
                y=0.5,
                showarrow=False,
            )

            if isinstance(selected_results, str):
                selected_results = [selected_results]

            if not selected_results or not x_axis or not y_axis:
                return empty_fig

            storage_manager = create_virtual_storage_manager(ref_store)
            results = []
            for result_id in selected_results:
                try:
                    results.append(storage_manager.load_result(result_id))
                except Exception:
                    pass

            if not results:
                return empty_fig

            template = theme if theme else LIGHT_THEME

            fig = create_interactive_scatter(
                results=results,
                x_axis=x_axis,
                y_axis=y_axis,
                selected_sets=set_filter,
                color_by=color_by,
                marker_by=marker_by,
                template=template,
                height=600,
            )

            fig.update_layout(clickmode="event+select", annotations=[])
            return fig

        @callback(
            Output(self.ids("bar-plot-vars"), "figure"),
            Output(self.ids("bar-plot-obj"), "figure"),
            Output(self.ids("bar-plot-obs"), "figure"),
            Input(self.ids("scatter-plot"), "selectedData"),
            Input(self.result_selector.get_value_id(), "value"),
            Input(self.set_selector.get_value_id(), "value"),
            State(glo.REF_STORE_STR, "data"),
            State("theme-store", "data"),
        )
        def update_bar_plots(
            selected_data: dict, selected_results, set_filter: list, ref_store: dict, theme
        ):
            empty_fig = go.Figure()
            empty_fig.add_annotation(
                text="No data selected",
                xref="paper",
                yref="paper",
                x=0.5,
                y=0.5,
                showarrow=False,
            )
            if theme:
                empty_fig.update_layout(template=theme)

            if not selected_results:
                return empty_fig, empty_fig, empty_fig

            if isinstance(selected_results, str):
                selected_results = [selected_results]

            storage_manager = create_virtual_storage_manager(ref_store)
            points_by_set = {}

            if set_filter:
                for result_id in selected_results:
                    result_set = storage_manager.load_result(result_id)
                    if result_set.problem_metadata.name in set_filter:
                        df = result_set.get_all_data()
                        points_by_set[result_set.problem_metadata.name] = df.index.tolist()
            elif selected_data and selected_data.get("points"):
                for point in selected_data["points"]:
                    result_name = point["customdata"][0]
                    original_index = point["customdata"][1]
                    if result_name not in points_by_set:
                        points_by_set[result_name] = []
                    points_by_set[result_name].append(original_index)
            else:
                return empty_fig, empty_fig, empty_fig

            all_selected_dfs = []
            all_design_vars = set()
            all_obj_vars = set()
            all_obs_vars = set()

            is_multi_result = len(points_by_set) > 1

            for result_id in selected_results:
                result_set = storage_manager.load_result(result_id)
                if result_set.problem_metadata.name in points_by_set:
                    df = result_set.get_all_data()
                    point_indices = points_by_set[result_set.problem_metadata.name]
                    selected_df_for_set = df.iloc[point_indices].copy()

                    name = result_set.problem_metadata.name
                    selected_df_for_set["result_name"] = name
                    selected_df_for_set["original_index"] = selected_df_for_set.index.astype(str)

                    if is_multi_result:
                        selected_df_for_set["point_index"] = (
                            f"{name} - " + selected_df_for_set.index.astype(str)
                        )
                    else:
                        selected_df_for_set["point_index"] = selected_df_for_set.index.astype(str)

                    all_selected_dfs.append(selected_df_for_set)

                    all_design_vars.update(
                        result_set.get_variables_by_category(DataTypeCategory.DESIGN_VARIABLE)
                    )
                    all_obj_vars.update(
                        result_set.get_variables_by_category(DataTypeCategory.OBJECTIVE)
                    )
                    all_obs_vars.update(
                        result_set.get_variables_by_category(DataTypeCategory.OBSERVABLE)
                    )

            if not all_selected_dfs:
                return empty_fig, empty_fig, empty_fig

            selected_df = pd.concat(all_selected_dfs)

            design_vars = sorted(list(all_design_vars))
            obj_vars = sorted(list(all_obj_vars))
            obs_vars = sorted(list(all_obs_vars))

            template = theme if theme else LIGHT_THEME

            def make_bar_plot(
                selected_df,
                features,
                title,
                lollipop_threshold=200,
                lollipop_style="vertical",  # "connected" or "vertical"
                lollipop_spacing=0.3,  # controls side-by-side spacing for vertical lollipops
            ):
                # Melt into long format
                df = selected_df[["point_index", "result_name", "original_index", *features]].melt(
                    id_vars=["point_index", "result_name", "original_index"],
                    var_name="Variable",
                    value_name="Value",
                )
                df["Variable"] = df["Variable"].astype(str).str.strip()
                df["point_index"] = df["point_index"].astype(str)
                df = df.sort_values(by=["Variable", "point_index"])

                n_vars = df["Variable"].nunique()
                n_points = df["point_index"].nunique()
                total_bars = n_vars * n_points

                meta_map = selected_df.set_index("point_index")[
                    ["result_name", "original_index"]
                ].to_dict("index")

                # --- Use normal bar plot when manageable ---
                if total_bars <= lollipop_threshold:
                    fig = px.bar(
                        df,
                        x="Variable",
                        y="Value",
                        color="point_index",
                        title=title,
                    )
                    fig.update_layout(
                        barmode="group", margin=dict(l=10, r=10, t=40, b=10), template=template
                    )
                    fig.update_xaxes(
                        categoryorder="array",
                        categoryarray=df["Variable"].unique(),
                    )

                    if is_multi_result:

                        def update_trace(trace):
                            if trace.name in meta_map:
                                r_name = meta_map[trace.name]["result_name"]
                                o_idx = meta_map[trace.name]["original_index"]
                                trace.update(
                                    legendgroup=r_name,
                                    legendgrouptitle_text=r_name,
                                    name=str(o_idx),
                                )

                        fig.for_each_trace(update_trace)

                    return fig

                # --- Otherwise use lollipop plot ---
                colors = px.colors.qualitative.Plotly
                color_map = {
                    pid: colors[i % len(colors)] for i, pid in enumerate(df["point_index"].unique())
                }

                fig = go.Figure()

                if lollipop_style == "connected":
                    # Each point_index is a connected trend line
                    for pid, group in df.groupby("point_index"):
                        name = str(pid)
                        legendgroup = None
                        legendgrouptitle_text = None

                        if is_multi_result and pid in meta_map:
                            r_name = meta_map[pid]["result_name"]
                            o_idx = meta_map[pid]["original_index"]
                            name = str(o_idx)
                            legendgroup = r_name
                            legendgrouptitle_text = r_name

                        fig.add_trace(
                            go.Scatter(
                                x=group["Variable"],
                                y=group["Value"],
                                mode="lines+markers",
                                name=name,
                                legendgroup=legendgroup,
                                legendgrouptitle_text=legendgrouptitle_text,
                                line=dict(color=color_map[pid], width=2),
                                marker=dict(size=8),
                            )
                        )

                elif lollipop_style == "vertical":
                    # Grouped vertical lollipops: side-by-side sticks for each variable
                    vars_unique = list(df["Variable"].unique())
                    x_positions = np.arange(len(vars_unique))
                    pid_list = list(df["point_index"].unique())
                    n_pids = len(pid_list)
                    offsets = np.linspace(
                        -lollipop_spacing, lollipop_spacing, n_pids
                    )  # horizontal offsets

                    for i, pid in enumerate(pid_list):
                        group = df[df["point_index"] == pid]

                        name = str(pid)
                        legendgroup = None
                        legendgrouptitle_text = None

                        if is_multi_result and pid in meta_map:
                            r_name = meta_map[pid]["result_name"]
                            o_idx = meta_map[pid]["original_index"]
                            name = str(o_idx)
                            legendgroup = r_name
                            legendgrouptitle_text = r_name

                        for j, var in enumerate(vars_unique):
                            val = group.loc[group["Variable"] == var, "Value"]
                            if val.empty:
                                continue
                            x_shifted = x_positions[j] + offsets[i]
                            fig.add_trace(
                                go.Scatter(
                                    x=[x_shifted, x_shifted],
                                    y=[0, val.values[0]],
                                    mode="lines+markers",
                                    line=dict(color=color_map[pid], width=2),
                                    marker=dict(size=8, color=color_map[pid]),
                                    name=name,
                                    legendgroup=legendgroup,
                                    legendgrouptitle_text=legendgrouptitle_text,
                                    showlegend=(j == 0),  # one legend entry per point
                                )
                            )

                    # Replace numeric x positions with category labels
                    fig.update_xaxes(
                        tickvals=x_positions,
                        ticktext=vars_unique,
                    )

                fig.update_layout(
                    title=title + f" (lollipop view - {lollipop_style})",
                    xaxis_title="Variable",
                    yaxis_title="Value",
                    showlegend=True,
                    xaxis=dict(categoryorder="array", categoryarray=df["Variable"].unique()),
                    height=200,
                    margin=dict(l=10, r=10, t=40, b=10),
                    template=template,
                )

                return fig

            vars_fig, obj_fig, obs_fig = go.Figure(), go.Figure(), go.Figure()

            if design_vars:
                vars_fig = make_bar_plot(selected_df, design_vars, "Design Variables")
            if obj_vars:
                obj_fig = make_bar_plot(selected_df, obj_vars, "Objectives")
            if obs_vars:
                obs_fig = make_bar_plot(selected_df, obs_vars, "Observables")

            return vars_fig, obj_fig, obs_fig

        @callback(
            Output(self.ids("scatter-plot"), "figure", allow_duplicate=True),
            Input(self.ids("scatter-plot"), "selectedData"),
            State(self.ids("scatter-plot"), "figure"),
            prevent_initial_call=True,
        )
        def update_annotations(selected_data, fig):  # noqa: N803
            if not selected_data or not selected_data.get("points"):
                if "layout" not in fig:
                    fig["layout"] = {}

                fig["layout"]["annotations"] = []
                return fig

            annotations = []

            for point in selected_data["points"]:
                point_index = point["pointIndex"]
                x_coord = point["x"]
                y_coord = point["y"]

                annotations.append(
                    {
                        "x": x_coord,
                        "y": y_coord,
                        "text": f"Index: {point_index}",
                        "showarrow": True,
                        "arrowhead": 1,
                        "ax": 20,
                        "ay": -30,
                    }
                )

            if "layout" not in fig:
                fig["layout"] = {}

            fig["layout"]["annotations"] = annotations

            return fig


page_module = InteractiveScatterPage()
