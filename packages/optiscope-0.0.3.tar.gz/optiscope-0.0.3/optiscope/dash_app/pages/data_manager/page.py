from __future__ import annotations

import base64
import datetime
import os
import tempfile

# from tkinter import Tk, filedialog
from typing import Any

import dash
import dash_mantine_components as dmc
from dash import State, callback, dcc, no_update
from dash_iconify import DashIconify

import optiscope.dash_app.core.glossary as glo
from optiscope.dash_app.core import (
    DataSourceManager,
    get_session_manager,
    get_storage_registry,
)
from optiscope.dash_app.core.id_factory import IDFactory
from optiscope.dash_app.core.storage_registry import StorageRegistry
from optiscope.dash_app.pages._base import PageModule
from optiscope.dash_app.utils.layouts import create_two_column_layout
from optiscope.io.registry import get_global_registry
from optiscope.storage.database import DatabaseStorage
from optiscope.storage.manager import StorageManager

try:
    from optiscope.storage.database import DatabaseStorage

    DATABASE_AVAILABLE = True
except ImportError:
    DATABASE_AVAILABLE = False

from dash_extensions.enrich import Input, Output, html
from dash_extensions.logging import DivLogHandler, NotificationsLogHandler

notif_handler = NotificationsLogHandler(
    notifications_provider=dmc.NotificationProvider(autoClose=True, position="top-right")
)
notiffer = notif_handler.setup_logger(__name__ + ".notif")

log_handler = DivLogHandler()
logger = log_handler.setup_logger(__name__)

MAX_MEMORY_SIZE = 100 * 1024 * 1024  # 100 MB


class DataManagerPage(PageModule):
    name = "Data Manager"
    path = "/data_manager"
    icon = "mdi:database-import-outline"
    description = "Manage and view your optimization data."
    category = "data"
    show_in_home = True

    def is_available(self, app=None, stored_data=None) -> tuple[bool, str]:
        """Data Manager is always available"""
        return True, ""

    @staticmethod
    def _create_results_list(
        storage_registry: StorageRegistry,
        storage_refs: dict[str, Any],
        selected_results: list[str],
    ) -> html.Div:
        """Create a list of loaded data sources with delete buttons and selection checkboxes."""
        if not storage_refs:
            return html.Div([dmc.Text("No data sources loaded yet.", c="gray")])

        result_items = []
        # Sort for consistent display order
        sorted_items = sorted(storage_refs.items(), key=lambda x: x[1].get("label", "").lower())

        for source_id, ref in sorted_items:
            storage = storage_registry.get(source_id)

            status = glo.VALID_STR
            if not storage:
                status = glo.INVALID_STR

            storage_type = ref.get("type", "N/A")
            storage_location = ref.get("storage_location", ref.get("path", "N/A"))
            label = ref.get("label", f"Source {source_id}")

            # Results Listing
            results_content = []
            if storage:
                try:
                    result_keys = storage.list_results()
                    if result_keys:
                        list_items = []
                        for res_key in result_keys:
                            list_items.append(
                                dmc.Group(
                                    [
                                        dmc.Text(res_key, size="sm"),
                                        dmc.Group(
                                            [
                                                dmc.Tooltip(
                                                    label="Add Default Sets",
                                                    children=dmc.ActionIcon(
                                                        DashIconify(
                                                            icon="mdi:folder-multiple-plus",
                                                            width=16,
                                                        ),
                                                        id={
                                                            "type": "add-default-sets-btn",
                                                            "source": source_id,
                                                            "key": res_key,
                                                        },
                                                        size="sm",
                                                        variant="subtle",
                                                        color="green",
                                                    ),
                                                ),
                                                dmc.Popover(
                                                    [
                                                        dmc.PopoverTarget(
                                                            dmc.ActionIcon(
                                                                DashIconify(
                                                                    icon="mdi:pencil", width=16
                                                                ),
                                                                size="sm",
                                                                variant="subtle",
                                                                color="blue",
                                                            )
                                                        ),
                                                        dmc.PopoverDropdown(
                                                            [
                                                                dmc.Group(
                                                                    [
                                                                        dmc.TextInput(
                                                                            id={
                                                                                "type": "rename-result-input",
                                                                                "source": source_id,
                                                                                "key": res_key,
                                                                            },
                                                                            value=res_key,
                                                                            size="xs",
                                                                            style={
                                                                                "width": "180px"
                                                                            },
                                                                        ),
                                                                        dmc.ActionIcon(
                                                                            DashIconify(
                                                                                icon="mdi:check",
                                                                                width=16,
                                                                            ),
                                                                            id={
                                                                                "type": "confirm-rename-result-btn",
                                                                                "source": source_id,
                                                                                "key": res_key,
                                                                            },
                                                                            color="green",
                                                                            variant="filled",
                                                                            size="sm",
                                                                        ),
                                                                    ]
                                                                )
                                                            ]
                                                        ),
                                                    ],
                                                    position="left",
                                                    withArrow=True,
                                                    shadow="md",
                                                    trapFocus=True,
                                                ),
                                            ]
                                        ),
                                    ],
                                    justify="space-between",
                                    py=4,
                                    style={"borderBottom": "1px solid #eee"},
                                )
                            )
                        results_content = [
                            dmc.Text("Results:", size="sm", fw=500, mt="sm"),
                            dmc.Stack(list_items, gap=0),
                        ]
                    else:
                        results_content = [
                            dmc.Text(
                                "No results found in this source.",
                                size="sm",
                                c="dimmed",
                                mt="sm",
                            )
                        ]
                except Exception as e:
                    results_content = [
                        dmc.Text(f"Error listing results: {e}", size="sm", c="red", mt="sm")
                    ]
            else:
                results_content = [
                    dmc.Text("Storage backend not available.", size="sm", c="red", mt="sm")
                ]

            # Source Card
            result_items.append(
                dmc.Card(
                    children=[
                        dmc.Group(
                            [
                                dmc.Group(
                                    [
                                        dmc.Checkbox(
                                            id={
                                                "type": "select-result-checkbox",
                                                "index": source_id,
                                            },
                                            checked=source_id in selected_results,
                                            size="md",
                                        ),
                                        dmc.Stack(
                                            [
                                                dmc.Group(
                                                    [
                                                        dmc.Text(label, fw="bold", size="lg"),
                                                        # Source Rename Popover
                                                        dmc.Popover(
                                                            [
                                                                dmc.PopoverTarget(
                                                                    dmc.ActionIcon(
                                                                        DashIconify(
                                                                            icon="mdi:pencil",
                                                                            width=18,
                                                                        ),
                                                                        variant="subtle",
                                                                        color="gray",
                                                                        size="sm",
                                                                    )
                                                                ),
                                                                dmc.PopoverDropdown(
                                                                    [
                                                                        dmc.Group(
                                                                            [
                                                                                dmc.TextInput(
                                                                                    id={
                                                                                        "type": "rename-source-input",
                                                                                        "index": source_id,
                                                                                    },
                                                                                    value=label,
                                                                                    size="xs",
                                                                                ),
                                                                                dmc.ActionIcon(
                                                                                    DashIconify(
                                                                                        icon="mdi:check",
                                                                                        width=16,
                                                                                    ),
                                                                                    id={
                                                                                        "type": "confirm-rename-source-btn",
                                                                                        "index": source_id,
                                                                                    },
                                                                                    color="green",
                                                                                    variant="filled",
                                                                                    size="sm",
                                                                                ),
                                                                            ]
                                                                        )
                                                                    ]
                                                                ),
                                                            ],
                                                            position="bottom",
                                                            withArrow=True,
                                                            shadow="md",
                                                            trapFocus=True,
                                                        ),
                                                    ],
                                                    gap="xs",
                                                ),
                                                dmc.Text(
                                                    f"Type: {storage_type} | Location: {storage_location}",
                                                    size="xs",
                                                    c="dimmed",
                                                ),
                                            ],
                                            gap=0,
                                        ),
                                    ],
                                    gap="sm",
                                ),
                                dmc.ActionIcon(
                                    DashIconify(icon="mdi:trash-can", width=20),
                                    id={"type": "delete-result-btn", "index": source_id},
                                    color="red",
                                    variant="light",
                                    size="lg",
                                ),
                            ],
                            justify="space-between",
                            align="flex-start",
                            mb="sm",
                        ),
                        html.Div(results_content),
                    ],
                    withBorder=True,
                    shadow="sm",
                    p="md",
                    mb="sm",
                    variant="outline",
                    style={
                        "borderColor": (
                            "var(--mantine-color-red-6)"
                            if status == glo.INVALID_STR
                            else "var(--mantine-color-gray-4)"
                        )
                    },
                )
            )

        return html.Div(result_items)

    @staticmethod
    def _create_storage_info_card(storage_manager) -> dmc.Card:
        """Creates a card displaying general storage information."""
        info = storage_manager.get_storage_info()
        info_items = []

        def format_backend_info(
            name: str, backend_info: dict
        ) -> list[Any]:  # Changed return type hint to list[Any]
            items = [dmc.Text(f"{name.capitalize()} Storage:", fw="bold", size="sm", mb=5)]
            items.append(
                dmc.Text(f"  Type: {backend_info.get('type', 'N/A').capitalize()}", size="xs")
            )
            if "path" in backend_info:
                items.append(dmc.Text(f"  Path: {backend_info['path']}", size="xs"))
            if "connection_string" in backend_info:
                items.append(
                    dmc.Text(f"  Connection: {backend_info['connection_string']}", size="xs")
                )
            if "size_mb" in backend_info:
                items.append(dmc.Text(f"  Size: {backend_info['size_mb']:.2f} MB", size="xs"))
            if "n_results" in backend_info:
                items.append(dmc.Text(f"  Results: {backend_info['n_results']}", size="xs"))
            return items

        if "primary" in info:
            info_items.extend(format_backend_info("primary", info["primary"]))
            info_items.append(dmc.Space(h=10))

        if "secondary" in info:
            info_items.extend(format_backend_info("secondary", info["secondary"]))
            info_items.append(dmc.Space(h=10))

        if "cache" in info:
            info_items.extend(format_backend_info("cache", info["cache"]))
            info_items.append(dmc.Space(h=10))

        return dmc.Card(
            children=[
                dmc.Title("Storage Overview", order=3),
                dmc.Text("General information about the configured storage backends."),
                dmc.Space(h=10),
                *info_items,
            ],
            withBorder=True,
            p="md",
            mb="md",
        )

    # Required methods
    def register_callbacks(self, app: dash.Dash | None = None) -> None:
        """Register page-specific callbacks"""
        ids_upload = IDFactory("data-manager-page")

        @callback(
            Output("output", "children"),
            Input("load-button", "n_clicks"),
            State("file-path-input", "value"),
            prevent_initial_call=True,
        )
        def load_file(n_clicks, file_path):
            if not file_path or not os.path.exists(file_path):
                return dmc.Alert("Invalid file path", color="red")

            # Work directly with the file path in backend
            # Example: read file size
            size = os.path.getsize(file_path)
            return dmc.Alert(f"File loaded: {file_path} ({size} bytes)", color="green")

        @callback(
            Output("storage-references", "data"),
            Output(ids_upload("output-data-upload"), "children"),
            Output(ids_upload("results-list"), "children", allow_duplicate=True),
            Input(ids_upload("upload-data"), "contents"),
            State(ids_upload("upload-data"), "filename"),
            State(ids_upload("upload-data"), "last_modified"),
            State("session-id", "data"),
            State("storage-references", "data"),
            State("selected-results-store", "data"),
            prevent_initial_call=True,
        )
        def upload_data(
            all_contents,
            all_filenames,
            last_modified,
            session_id,
            current_refs,
            selected_results,
        ):
            if all_contents is None:
                return no_update, no_update, no_update

            try:
                for contents, filename in zip(all_contents, all_filenames):
                    content_type, content_string = contents.split(",")
                    decoded = base64.b64decode(content_string)

                    # Get managers for the current session
                    session_mgr = get_session_manager(session_id)
                    storage_registry = get_storage_registry()
                    ds_mgr = DataSourceManager(session_mgr, storage_registry)

                    # Determine the source type
                    source_type = None
                    path = None
                    if filename.endswith((".db", ".sqlite")):
                        source_type = "sqlite"
                        # For sqlite, save to a temp file and pass the path
                        fd, path = tempfile.mkstemp(suffix=filename)
                        with os.fdopen(fd, "wb") as temp_file:
                            temp_file.write(decoded)
                        decoded = None  # Don't pass raw data for sqlite
                    elif filename.endswith(".duckdb"):
                        source_type = "duckdb"
                        # For duckdb, save to a temp file and pass the path
                        fd, path = tempfile.mkstemp(suffix=filename)
                        with os.fdopen(fd, "wb") as temp_file:
                            temp_file.write(decoded)
                        decoded = None  # Don't pass raw data for duckdb
                    else:
                        # Fallback to format registry for other files
                        format_registry = get_global_registry()
                        # Save the uploaded file to a temporary path to allow detection
                        fd, path = tempfile.mkstemp(suffix=filename)
                        with os.fdopen(fd, "wb") as temp_file:
                            temp_file.write(decoded)

                        try:
                            handler = format_registry.get_handler_for_file(path)
                            source_type = handler.format_name
                            decoded = decoded  # The handler will read from the path
                        except Exception as e:
                            logger.warning(f"Could not determine handler for {filename}: {e}")
                            source_type = None

                    if not source_type:
                        if path and os.path.exists(path):
                            os.unlink(path)
                        return (
                            no_update,
                            dmc.Alert(f"Unsupported file type: {filename}", color="red"),
                            no_update,
                        )

                    # Build source config
                    source_config = {
                        "type": source_type,
                        "label": os.path.splitext(filename)[0],
                        "data": decoded,
                        "path": path,
                    }
                    # Add data source
                    new_ref = ds_mgr.add_data_source(source_config)

                    # Update browser store with the new reference
                    current_refs = current_refs or {"sources": {}}
                    current_refs["sources"][new_ref["source_id"]] = new_ref

                    # Update UI (simplified for now)
                    success_message = dmc.Alert(
                        f"Successfully added {filename} as a new data source.",
                        color="green",
                    )
                    results_list = self._create_results_list(
                        storage_registry, current_refs["sources"], selected_results or []
                    )

                return current_refs, success_message, results_list

            except Exception as e:
                logger.error(f"Error during file upload: {e}", exc_info=True)
                error_message = dmc.Alert(
                    title="Upload Failed",
                    color="red",
                    children=[html.Pre(str(e))],
                )
                return no_update, error_message, no_update

        @callback(
            Output("storage-references", "data", allow_duplicate=True),
            Output(ids_upload("mount-db-output"), "children"),
            Output(ids_upload("results-list"), "children", allow_duplicate=True),
            Input(ids_upload("mount-db-btn"), "n_clicks"),
            State(ids_upload("db-path-input"), "value"),
            State(ids_upload("db-label-input"), "value"),
            State("session-id", "data"),
            State("storage-references", "data"),
            prevent_initial_call=True,
        )
        def mount_database(n_clicks, db_path, label, session_id, current_refs):
            if not n_clicks or not db_path:
                return no_update, no_update, no_update

            try:
                # Get managers
                session_mgr = get_session_manager(session_id)
                storage_registry = get_storage_registry()
                ds_mgr = DataSourceManager(session_mgr, storage_registry)

                # Build source config
                source_config = {
                    "type": "sqlite",
                    "path": db_path,
                    "label": label or os.path.basename(db_path),
                }

                # Mount the database
                new_ref = ds_mgr.add_data_source(source_config)

                # Update browser store
                current_refs = current_refs or {"sources": {}}
                if "sources" not in current_refs:
                    current_refs["sources"] = {}
                current_refs["sources"][new_ref["source_id"]] = new_ref

                # Success message
                success_msg = dmc.Alert(
                    f"Successfully mounted database: {label}",
                    color="green",
                )

                # Update results list
                results_list = DataManagerPage._create_results_list(
                    storage_registry,
                    current_refs["sources"],
                    [],  # selected_results
                )

                return current_refs, success_msg, results_list

            except Exception as e:
                logger.error(f"Error mounting database: {e}", exc_info=True)
                error_msg = dmc.Alert(
                    title="Mount Failed",
                    color="red",
                    children=[html.Pre(str(e))],
                )
                return no_update, error_msg, no_update

        @callback(
            Output("storage-references", "data", allow_duplicate=True),
            Output(ids_upload("output-data-upload"), "children", allow_duplicate=True),
            Output(ids_upload("results-list"), "children", allow_duplicate=True),
            Input(ids_upload("connect-db-btn"), "n_clicks"),
            State(ids_upload("db-path-input"), "value"),
            State("session-id", "data"),
            State("storage-references", "data"),
            State("selected-results-store", "data"),
            prevent_initial_call=True,
        )
        def connect_to_db(n_clicks, db_path, session_id, current_refs, selected_results):
            if not n_clicks or not db_path:
                return no_update, no_update, no_update

            try:
                session_mgr = get_session_manager(session_id)
                storage_registry = get_storage_registry()
                ds_mgr = DataSourceManager(session_mgr, storage_registry)

                is_url = db_path.startswith("sqlite://") or "://" in db_path
                label = os.path.basename(db_path).split(".")[0] if not is_url else "Database URL"

                source_config = {"type": "sqlite", "path": db_path, "label": label}

                new_ref = ds_mgr.add_data_source(source_config)
                current_refs = current_refs or {"sources": {}}
                current_refs["sources"][new_ref["source_id"]] = new_ref

                success_message = dmc.Alert(
                    f"Successfully connected to database at {db_path}.", color="green"
                )
                results_list = self._create_results_list(
                    storage_registry, current_refs["sources"], selected_results or []
                )

                return current_refs, success_message, results_list

            except Exception as e:
                logger.error(f"Error connecting to database: {e}", exc_info=True)
                error_message = dmc.Alert(
                    title="Database Connection Failed",
                    color="red",
                    children=[html.Pre(str(e))],
                )
                return no_update, error_message, no_update

        @callback(
            Output(ids_upload("output-data-upload"), "children", allow_duplicate=True),
            Input(ids_upload("upload-data"), "filename"),
            prevent_initial_call=True,
        )
        def diagnostic_upload_trigger(filename):
            if filename:
                logger.info(f"DIAGNOSTIC: dcc.Upload filename changed to: {filename}")
            return no_update

        @callback(
            Output("storage-references", "data", allow_duplicate=True),
            Output("selected-results-store", "data", allow_duplicate=True),
            Output(ids_upload("results-list"), "children", allow_duplicate=True),
            Input({"type": "delete-result-btn", "index": dash.ALL}, "n_clicks"),
            State("session-id", "data"),
            State("storage-references", "data"),
            State("selected-results-store", "data"),
            prevent_initial_call=True,
        )
        def delete_source(n_clicks_list, session_id, current_refs, selected_results):
            if not any(n_clicks_list):
                return no_update, no_update, no_update

            ctx = dash.callback_context
            if not ctx.triggered:
                return no_update, no_update, no_update

            import json

            button_id = json.loads(ctx.triggered[0]["prop_id"].split(".")[0])
            source_id = button_id["index"]

            # Get managers
            session_mgr = get_session_manager(session_id)
            storage_registry = get_storage_registry()
            ds_mgr = DataSourceManager(session_mgr, storage_registry)

            # Remove data source
            ds_mgr.remove_data_source(source_id)

            # Update browser store
            if current_refs and "sources" in current_refs and source_id in current_refs["sources"]:
                del current_refs["sources"][source_id]

            # Remove from selected results
            if selected_results and source_id in selected_results:
                selected_results.remove(source_id)

            # Update UI
            results_list = DataManagerPage._create_results_list(
                storage_registry, current_refs["sources"], selected_results or []
            )

            return current_refs, selected_results, results_list

        @callback(
            Output(ids_upload("results-list"), "children"),
            Input("storage-references", "data"),
            Input("selected-results-store", "data"),
            Input("url", "pathname"),
            prevent_initial_call=False,
        )
        def update_results_list(storage_refs, selected_results, pathname):
            """Update the results list whenever data or selection changes, or when navigating to the page."""
            logger.debug(f"Update results list callback triggered for pathname: {pathname}")
            if not storage_refs or not storage_refs.get("sources"):
                logger.debug("No storage references, returning 'No results loaded yet' message.")
                return html.Div([dmc.Text("No data sources loaded yet.", c="gray")])

            storage_registry = get_storage_registry()
            logger.debug("Storage registry retrieved for updating results list.")
            return DataManagerPage._create_results_list(
                storage_registry, storage_refs["sources"], selected_results or []
            )

        @callback(
            Output(ids_upload("export-download"), "data"),
            Input(ids_upload("export-sqlite-btn"), "n_clicks"),
            Input(ids_upload("export-duckdb-btn"), "n_clicks"),
            State("selected-results-store", "data"),
            prevent_initial_call=True,
        )
        def export_selected(n_sqlite, n_duckdb, selected_results):
            if not (n_sqlite or n_duckdb):
                return no_update

            ctx = dash.callback_context
            triggered_id = ctx.triggered_id

            if triggered_id == ids_upload("export-sqlite-btn"):
                db_type = "sqlite"
                suffix = ".db"
                connection_prefix = "sqlite:///"
            elif triggered_id == ids_upload("export-duckdb-btn"):
                db_type = "duckdb"
                suffix = ".duckdb"
                connection_prefix = "duckdb:///"  # Assuming this works for duckdb
            else:
                return no_update

            if not selected_results:
                notiffer.warning("No results selected for export.")
                return no_update

            if not DATABASE_AVAILABLE:
                notiffer.error(f"Database backend not available for {db_type} export.")
                return no_update

            try:
                storage_registry = get_storage_registry()

                temp_db_path = tempfile.mktemp(suffix=suffix)
                db_connection = f"{connection_prefix}{temp_db_path}"

                db_storage = DatabaseStorage(connection_string=db_connection)

                exported_count = 0
                exported_results_keys = set()

                for source_id in selected_results:
                    storage = storage_registry.get(source_id)
                    if storage:
                        for result_key in storage.list_results():
                            if result_key not in exported_results_keys:
                                result = storage.load_result(result_key)
                                db_storage.save_result(result_key, result)
                                exported_results_keys.add(result_key)
                                exported_count += 1

                db_storage.close()

                if exported_count == 0:
                    notiffer.warning("No results found in selected sources to export.")
                    if os.path.exists(temp_db_path):
                        os.unlink(temp_db_path)
                    return no_update

                with open(temp_db_path, "rb") as f:
                    db_content = f.read()

                os.unlink(temp_db_path)

                timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
                filename = f"optiscope_selected_results_{timestamp}{suffix}"
                notiffer.info(f"Exported {exported_count} results to {filename}.")

                return dict(
                    content=base64.b64encode(db_content).decode(),
                    filename=filename,
                    base64=True,
                )

            except Exception as e:
                logger.error(f"Error during {db_type} export: {e}", exc_info=True)
                notiffer.error(f"{db_type.capitalize()} export failed: {e}")
                return no_update

        @callback(
            Output("selected-results-store", "data", allow_duplicate=True),
            Input({"type": "select-result-checkbox", "index": dash.ALL}, "checked"),
            State("selected-results-store", "data"),
            State({"type": "select-result-checkbox", "index": dash.ALL}, "id"),
            prevent_initial_call=True,
        )
        def update_selected_results(checked_list, selected_results, ids_list):
            logger.debug("Update selected results callback triggered.")
            if not dash.callback_context.triggered:
                logger.debug("No callback context triggered, returning no_update.")
                return no_update

            triggered_id_info = dash.callback_context.triggered[0]
            triggered_prop_id = triggered_id_info["prop_id"]
            triggered_value = triggered_id_info["value"]

            # Extract the index (result_key) from the triggered ID
            import json

            triggered_id_dict = json.loads(triggered_prop_id.split(".")[0])
            result_key = triggered_id_dict["index"]

            if selected_results is None:
                selected_results = []

            if triggered_value:  # Checkbox is checked
                if result_key not in selected_results:
                    selected_results.append(result_key)
                    logger.debug(f"Result '{result_key}' added to selected_results.")
            else:  # Checkbox is unchecked
                if result_key in selected_results:
                    selected_results.remove(result_key)
                    logger.debug(f"Result '{result_key}' removed from selected_results.")

            return selected_results

        @callback(
            Output("selected-results-store", "data", allow_duplicate=True),
            Input(ids_upload("select-all-btn"), "n_clicks"),
            State(glo.REF_STORE_STR, "data"),
            prevent_initial_call=True,
        )
        def select_all_results(n_clicks, stored_refs):
            logger.debug("Select All button clicked.")
            if not n_clicks or not stored_refs:
                return no_update

            all_keys = [k for k in stored_refs["sources"].keys()]
            logger.debug(f"All results selected: {all_keys}")
            return all_keys

        @callback(
            Output("selected-results-store", "data", allow_duplicate=True),
            Input(ids_upload("deselect-all-btn"), "n_clicks"),
            prevent_initial_call=True,
        )
        def deselect_all_results(n_clicks):
            logger.debug("Deselect All button clicked.")
            if not n_clicks:
                return no_update
            logger.debug("All results deselected.")
            return []

        @callback(
            Output(glo.REF_STORE_STR, "data", allow_duplicate=True),
            Output("selected-results-store", "data", allow_duplicate=True),
            # Output(ids_upload("results-list"), "children", allow_duplicate=True),
            Input(ids_upload("clear-all-results-btn"), "n_clicks"),
            State("session-id", "data"),
            State("selected-results-store", "data"),
            State(glo.REF_STORE_STR, "data"),
            prevent_initial_call=True,
        )
        def delete_selected_sources(n_clicks, session_id, selected_sources, stored_data):
            logger.debug("Clear Selected Results button clicked.")
            if not n_clicks or not stored_data:
                return no_update, no_update

            # Get managers
            session_mgr = get_session_manager(session_id)
            storage_registry = get_storage_registry()
            ds_mgr = DataSourceManager(session_mgr, storage_registry)

            # Load storage manager and delete result
            for source_key in selected_sources:
                ds_mgr.remove_data_source(source_key)
                logger.debug(f"Source '{source_key}' deleted from storage manager.")

                # Update browser store
                if (
                    stored_data
                    and "sources" in stored_data
                    and source_key in stored_data["sources"]
                ):
                    del stored_data["sources"][source_key]

            logger.info("All selected sources cleared from storage.")

            notiffer.info("All selected results cleared.")
            return stored_data, []

        @callback(
            Output("storage-references", "data", allow_duplicate=True),
            Input({"type": "confirm-rename-source-btn", "index": dash.ALL}, "n_clicks"),
            State({"type": "rename-source-input", "index": dash.ALL}, "value"),
            State({"type": "rename-source-input", "index": dash.ALL}, "id"),
            State("storage-references", "data"),
            prevent_initial_call=True,
        )
        def rename_source(n_clicks_list, new_values, input_ids, current_refs):
            ctx = dash.callback_context
            if not ctx.triggered:
                return no_update

            # Check if any button was actually clicked
            if not any(n_clicks_list):
                return no_update

            triggered_prop_id = ctx.triggered[0]["prop_id"]
            import json

            # Parse triggered ID: {"index": "source_id", "type": "..."}.n_clicks
            triggered_id = json.loads(triggered_prop_id.split(".")[0])
            source_id = triggered_id["index"]

            # Find the new name matching this source_id
            new_label = None
            for i, iid in enumerate(input_ids):
                if iid["index"] == source_id:
                    new_label = new_values[i]
                    break

            if new_label and current_refs and "sources" in current_refs:
                if source_id in current_refs["sources"]:
                    old_label = current_refs["sources"][source_id].get("label", "")
                    if new_label != old_label:
                        current_refs["sources"][source_id]["label"] = new_label
                        notiffer.info(f"Source renamed to '{new_label}'")
                        return current_refs

            return no_update

        @callback(
            Output("storage-references", "data", allow_duplicate=True),
            Input(
                {
                    "type": "confirm-rename-result-btn",
                    "source": dash.ALL,
                    "key": dash.ALL,
                },
                "n_clicks",
            ),
            State(
                {"type": "rename-result-input", "source": dash.ALL, "key": dash.ALL},
                "value",
            ),
            State(
                {"type": "rename-result-input", "source": dash.ALL, "key": dash.ALL},
                "id",
            ),
            State("storage-references", "data"),
            prevent_initial_call=True,
        )
        def rename_result(n_clicks_list, new_values, input_ids, current_refs):
            ctx = dash.callback_context
            if not ctx.triggered:
                return no_update

            if not any(n_clicks_list):
                return no_update

            triggered_prop_id = ctx.triggered[0]["prop_id"]
            import json

            triggered_id = json.loads(triggered_prop_id.split(".")[0])
            source_id = triggered_id["source"]
            old_key = triggered_id["key"]

            # Find the new name
            new_key = None
            for i, iid in enumerate(input_ids):
                if iid["source"] == source_id and iid["key"] == old_key:
                    new_key = new_values[i]
                    break

            if not new_key or new_key == old_key:
                return no_update

            try:
                storage_registry = get_storage_registry()
                storage = storage_registry.get(source_id)
                if storage:
                    storage.rename_result(old_key, new_key)
                    notiffer.info(f"Result renamed: {old_key} -> {new_key}")
                    # Return current_refs to trigger the list update
                    # We create a shallow copy to ensure Dash detects the change if needed,
                    # though often just returning the same object works if we rely on the signal
                    # but modifying it slightly ensures a trigger.
                    # Here we don't modify refs content, but returning it triggers outputs.
                    return dict(current_refs)
            except Exception as e:
                logger.error(f"Error renaming result: {e}", exc_info=True)
                notiffer.error(f"Failed to rename result: {e}")

            return no_update

        @callback(
            Output(ids_upload("results-list"), "children", allow_duplicate=True),
            Input(
                {
                    "type": "add-default-sets-btn",
                    "source": dash.ALL,
                    "key": dash.ALL,
                },
                "n_clicks",
            ),
            State(
                {
                    "type": "add-default-sets-btn",
                    "source": dash.ALL,
                    "key": dash.ALL,
                },
                "id",
            ),
            State("storage-references", "data"),
            State("selected-results-store", "data"),
            prevent_initial_call=True,
        )
        def add_default_sets_to_result(n_clicks_list, button_ids, current_refs, selected_results):
            """Add default sets to a result when the button is clicked."""
            ctx = dash.callback_context
            if not ctx.triggered:
                return no_update

            if not any(n_clicks_list):
                return no_update

            triggered_prop_id = ctx.triggered[0]["prop_id"]
            import json

            triggered_id = json.loads(triggered_prop_id.split(".")[0])
            source_id = triggered_id["source"]
            result_key = triggered_id["key"]

            try:
                from optiscope.dash_app.utils.default_sets import create_default_sets

                create_default_sets(source_id, result_key)
                notiffer.info(f"Default sets created for '{result_key}'")

                # Return updated results list
                storage_registry = get_storage_registry()
                return DataManagerPage._create_results_list(
                    storage_registry, current_refs["sources"], selected_results or []
                )
            except Exception as e:
                logger.error(f"Error creating default sets: {e}", exc_info=True)
                notiffer.error(f"Failed to create default sets: {e}")
                return no_update

        @callback(
            Output(ids_upload("storage-info-output"), "children"),
            Input("global-results-store", "data"),
            prevent_initial_call=False,
        )
        def update_storage_info_card(stored_data):
            """Update the storage information card when global data changes."""
            if not stored_data:
                return html.Div([dmc.Text("No storage information available.", c="gray")])

            storage_manager = StorageManager.from_dict(stored_data)
            return DataManagerPage._create_storage_info_card(storage_manager)

    def layout(self, **kwargs):
        ids = IDFactory("data-manager-page")

        # Get supported formats from the registry
        registry = get_global_registry()
        supported_formats_info = registry.list_formats()

        format_children = []
        for fmt in supported_formats_info:
            extensions_str = ", ".join(fmt["extensions"])
            format_children.append(
                html.Div(f"• {fmt['name']} files ({extensions_str}) - Single optimization result")
            )

        if DATABASE_AVAILABLE:
            format_children.append(
                html.Div("• SQLite databases (.db, .sqlite) - Mounts the database")
            )

        # Left column content
        left_content = [
            dmc.Title("Add Data Sources", order=2),
            dmc.Text("Upload files or mount databases to visualize your optimization results."),
            dmc.Space(h=20),
            dmc.Alert(
                title="Supported Formats",
                color="blue",
                children=format_children,
            ),
            dcc.Upload(
                id=ids("upload-data"),
                children=html.Div(["Drag and Drop or ", html.A("Select Files")]),
                style={
                    "width": "100%",
                    "height": "60px",
                    "lineHeight": "60px",
                    "borderWidth": "1px",
                    "borderStyle": "dashed",
                    "borderRadius": "5px",
                    "textAlign": "center",
                    "margin": "10px",
                },
                multiple=True,
            ),
            html.Div(id=ids("output-data-upload")),
            dmc.Space(h=20),
            dmc.Divider(label="Or Mount External Database", labelPosition="center"),
            dmc.Space(h=10),
            dmc.TextInput(
                id=ids("db-path-input"),
                label="SQLite Database Path",
                placeholder="/path/to/results.db",
                style={"width": "100%"},
            ),
            dmc.TextInput(
                id=ids("db-label-input"),
                label="Display Name",
                placeholder="My Experiment Results",
                style={"width": "100%"},
            ),
            dmc.Button(
                "Mount Database",
                id=ids("mount-db-btn"),
                leftSection=DashIconify(icon="mdi:database-plus", width=20),
                color="blue",
                fullWidth=True,
            ),
            html.Div(id=ids("mount-db-output")),
            dmc.Space(h=20),
            *notif_handler.embed(),
            html.Div(id=ids("storage-info-output")),
        ]

        # Right column content
        right_content = [
            dmc.Title("Loaded Data Sources", order=2),
            dmc.Text("View, select, and manage your loaded data sources."),
            dmc.Space(h=20),
            dmc.Group(
                [
                    dmc.Button(
                        "Select All",
                        id=ids("select-all-btn"),
                        leftSection=DashIconify(icon="mdi:select-all", width=20),
                        variant="outline",
                        color="blue",
                    ),
                    dmc.Button(
                        "Deselect All",
                        id=ids("deselect-all-btn"),
                        leftSection=DashIconify(icon="mdi:select-off", width=20),
                        variant="outline",
                        color="gray",
                    ),
                    dmc.Button(
                        "Delete Selected",
                        id=ids("clear-all-results-btn"),
                        leftSection=DashIconify(icon="mdi:trash-can-outline", width=20),
                        color="red",
                        variant="outline",
                    ),
                    dmc.Menu(
                        [
                            dmc.MenuTarget(
                                dmc.Button(
                                    "Export Selected",
                                    leftSection=DashIconify(icon="mdi:database-export", width=20),
                                    variant="outline",
                                    color="green",
                                )
                            ),
                            dmc.MenuDropdown(
                                [
                                    dmc.MenuItem(
                                        "to SQLite",
                                        id=ids("export-sqlite-btn"),
                                        leftSection=DashIconify(icon="mdi:database-export-outline"),
                                    ),
                                    dmc.MenuItem(
                                        "to DuckDB",
                                        id=ids("export-duckdb-btn"),
                                        leftSection=DashIconify(icon="mdi:database-export-outline"),
                                    ),
                                ]
                            ),
                        ],
                    ),
                ],
                mb="md",
            ),
            dmc.ScrollArea(html.Div(id=ids("results-list")), h=500),
            dcc.Download(id=ids("export-download")),
        ]

        return create_two_column_layout(left_content, right_content)


# def select_file():
#     """Open file dialog and return selected file path"""
#     root = Tk()
#     root.withdraw()  # Hide the main window
#     root.wm_attributes("-topmost", 1)  # Bring dialog to front
#     file_path = filedialog.askopenfilename()
#     root.destroy()
#     return file_path


page_module = DataManagerPage()
