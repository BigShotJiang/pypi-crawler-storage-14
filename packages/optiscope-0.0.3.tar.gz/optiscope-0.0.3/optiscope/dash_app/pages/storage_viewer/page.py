import dash
import dash_json_grid as djg
import dash_mantine_components as dmc
from dash import Input, Output, callback

import optiscope.dash_app.core.glossary as glo
from optiscope.dash_app.core.id_factory import IDFactory
from optiscope.dash_app.pages._base import PageModule


class StorageViewerPage(PageModule):
    name = "Storage Viewer"
    path = "/storage_viewer"
    icon = "mdi:database-eye-outline"
    description = "View storage."
    category = "debug"
    requires_data = False

    def __init__(self):
        super().__init__()
        self.ids = IDFactory("storage-viewer-page")

    def register_callbacks(self, app: dash.Dash | None = None) -> None:
        @callback(Output(self.ids("store-results"), "data"), Input(glo.REF_STORE_STR, "data"))
        def read_storage(stored_refs):
            return stored_refs

    def layout(self, **kwargs):
        return dmc.Container(
            children=[
                dmc.Title("Storage Viewer", order=2),
                dmc.Text("View storages."),
                dmc.Space(h=10),
                djg.DashJsonGrid(
                    data={},
                    id=self.ids("store-results"),
                    theme="defaultLight",
                ),
            ],
            fluid=True,
        )


page_module = StorageViewerPage()
