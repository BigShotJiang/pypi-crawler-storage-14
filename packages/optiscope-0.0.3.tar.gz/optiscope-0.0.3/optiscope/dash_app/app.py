import dash
import dash_mantine_components as dmc
from dash import Input, Output, State, clientside_callback, dcc, page_container
from dash_extensions.enrich import DashProxy, ServersideOutputTransform
from dash_iconify import DashIconify
from dash_mantine_components import Group, Image
from flask import session

from optiscope.dash_app.components.result_selector import create_result_selector
from optiscope.dash_app.core import config
from optiscope.dash_app.core.callbacks import register_callbacks  # Import register_callbacks
from optiscope.dash_app.core.glossary import REF_STORE_STR
from optiscope.dash_app.core.page_registry import discover_pages
from optiscope.dash_app.core.session_manager import generate_session_id
from optiscope.dash_app.core.settings_manager import SettingsManager
from optiscope.dash_app.core.theme_config import LIGHT_THEME
from optiscope.dash_app.utils.layout_components import create_navigation_component, get_nav_content
from optiscope.plotting.theme import apply_theme


class DashApp:
    def __init__(self, app_mode="local"):
        self.app_mode = app_mode
        self.app = DashProxy(
            __name__,
            use_pages=True,
            suppress_callback_exceptions=True,
            transforms=[ServersideOutputTransform()],
        )
        self.app._favicon = "/assets/favicon.ico"
        self.app.server.secret_key = "super-secret-key-2"
        self.result_selector = create_result_selector(
            "main-result", multi=False, persistence=True, label="Default Result:"
        )
        discover_pages("optiscope.dash_app.pages", self.app, fetch_modules=True)
        self.app.layout = self._create_main_layout()
        self._register_callbacks()

        apply_theme()

    def _create_main_layout(self):
        children = [
            dcc.Location(id="url", refresh=False),
            dcc.Store("storage-references", storage_type="session"),
            dcc.Store("global-results-store", storage_type="session"),
            dcc.Store("selected-results-store", storage_type="session"),
            dcc.Store(id="theme-store", data=LIGHT_THEME),
            dcc.Store(id="user-settings-store", storage_type="session"),
        ]

        if self.app_mode == "deployed":
            children.append(dcc.Store(id="session-id", storage_type="session"))
        else:
            children.append(dcc.Store(id="session-id", storage_type="memory"))

        theme_toggle = dmc.Switch(
            offLabel=DashIconify(
                icon="radix-icons:sun", width=15, color=dmc.DEFAULT_THEME["colors"]["yellow"][8]
            ),
            onLabel=DashIconify(
                icon="radix-icons:moon", width=15, color=dmc.DEFAULT_THEME["colors"]["yellow"][6]
            ),
            id="color-scheme-switch",
            persistence=True,
            color="gray",
        )

        app_shell = dmc.AppShell(
            id="app-shell",
            children=[
                dmc.AppShellHeader(
                    children=[
                        Group(
                            h="100%",
                            px="xl",
                            justify="space-between",
                            style={
                                # "borderBottom": "1px solid var(--mantine-color-gray-3)",
                                "backdropFilter": "blur(10px)",
                                "backgroundColor": "var(--mantine-color-body)",
                            },
                            children=[
                                Group(
                                    gap="md",
                                    children=[
                                        dmc.Burger(
                                            id="burger-mobile",
                                            opened=False,
                                            size="sm",
                                            hiddenFrom="sm",
                                        ),
                                        dmc.Burger(
                                            id="burger-desktop",
                                            opened=True,
                                            size="sm",
                                            visibleFrom="sm",
                                        ),
                                    ],
                                ),
                                dmc.Group(
                                    [
                                        Image(src="/assets/logo.svg", h=60, w="auto"),
                                    ],
                                    gap="sm",
                                ),
                                Group(
                                    gap="sm",
                                    children=[
                                        self.result_selector.layout(show_label=False),
                                        theme_toggle,
                                    ],
                                ),
                            ],
                        )
                    ],
                ),
                create_navigation_component(dash.page_registry),
                dmc.AppShellMain(
                    [
                        page_container,
                    ]
                ),
            ],
            header={"height": 60},
            navbar={
                "width": 250,
                "breakpoint": "sm",
                "collapsed": {"mobile": True, "desktop": False},
            },
            padding="xl",
        )
        children.append(app_shell)

        return dmc.MantineProvider(
            theme={
                "primaryColor": "cyan",
                "defaultRadius": "xs",
                "fontFamily": "'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif",
                "headings": {
                    "fontFamily": "'Inter', sans-serif",
                    "fontWeight": "600",
                },
                "components": {
                    "Title": {
                        "styles": {
                            "root": {
                                "letterSpacing": "-0.02em",
                            }
                        }
                    },
                    "Card": {"defaultProps": {"shadow": "xs"}},
                },
            },
            children=dmc.Container(
                children, fluid=True, style={"padding": "0px", "maxWidth": "100%"}
            ),
        )

    def _register_callbacks(self):
        @self.app.callback(
            Output("app-shell", "navbar"),
            Output("burger-mobile", "opened"),
            Output("burger-desktop", "opened"),
            Input("burger-mobile", "opened"),
            Input("burger-desktop", "opened"),
            State("app-shell", "navbar"),
            prevent_initial_call=True,
        )
        def toggle_navbar(mobile_opened, desktop_opened, navbar):
            trigger_id = dash.ctx.triggered_id
            is_open = mobile_opened if trigger_id == "burger-mobile" else desktop_opened

            navbar["collapsed"] = {"mobile": not is_open, "desktop": not is_open}
            return navbar, is_open, is_open

        if self.app_mode == "deployed":

            @self.app.callback(
                Output("session-id", "data"),
                Input("url", "pathname"),
                State("session-id", "data"),
            )
            def ensure_session_id_deployed(_, session_id):
                if session_id is None:
                    return generate_session_id()
                return session_id
        else:

            @self.app.callback(
                Output("session-id", "data"),
                Input("url", "pathname"),
            )
            def ensure_session_id_local(_):
                if "session_id" not in session:
                    session["session_id"] = generate_session_id()
                return session["session_id"]

        clientside_callback(
            """
            (switchOn) => {
               document.documentElement.setAttribute('data-mantine-color-scheme', switchOn ? 'dark' : 'light');
               return window.dash_clientside.no_update
            }
            """,
            Output("color-scheme-switch", "id"),
            Input("color-scheme-switch", "checked"),
        )

        # Initialize user settings
        @self.app.callback(
            Output("user-settings-store", "data"),
            Output("color-scheme-switch", "checked"),
            Input("url", "pathname"),
            State("user-settings-store", "data"),
        )
        def initialize_settings(pathname, current_settings):
            """Initialize settings on app load."""
            if current_settings:
                # Settings already loaded
                theme = current_settings.get("theme", "light")
                return dash.no_update, theme == "dark"

            # Load settings
            settings_manager = SettingsManager(app_mode=self.app_mode)
            settings_dict = settings_manager.get_all_settings()

            # Set initial theme
            theme = settings_dict.get("theme", "light")
            return settings_dict, theme == "dark"

        # Sync theme changes to settings
        @self.app.callback(
            Output("user-settings-store", "data", allow_duplicate=True),
            Input("color-scheme-switch", "checked"),
            State("user-settings-store", "data"),
            prevent_initial_call=True,
        )
        def sync_theme_to_settings(is_dark, current_settings):
            """Update settings when theme toggle changes."""
            if current_settings is None:
                return dash.no_update

            settings_manager = SettingsManager(app_mode=self.app_mode)
            settings_manager.load_settings(current_settings)
            settings_manager.update_setting("theme", "dark" if is_dark else "light")
            return settings_manager.save_settings()

        self.result_selector.register_callbacks(self.app)

        @self.app.callback(
            Output("app-nav-bar", "children"),
            Input(REF_STORE_STR, "data"),
        )
        def update_nav_links(stored_data):
            return get_nav_content(dash.page_registry, stored_data=stored_data)

        register_callbacks(self.app)

    def run(self, **kwargs):
        self.app.run(**kwargs)


def run_server(debug=False, host="127.0.0.1", port=8050, app_mode="local"):
    """Run the Dash server."""
    config.APP_MODE = app_mode
    dash_app = DashApp(app_mode=app_mode)
    dash_app.run(host=host, port=port, debug=debug, use_reloader=debug)


if __name__ == "__main__":
    run_server(debug=True, port=8050)
