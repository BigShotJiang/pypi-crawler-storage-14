"""Configuration for the Dash application."""

# Application mode: 'local' or 'deployed'
# This is set by the run_server function in app.py
APP_MODE = "local"
