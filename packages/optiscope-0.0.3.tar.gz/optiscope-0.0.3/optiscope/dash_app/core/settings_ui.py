"""UI generator for settings based on schema.

This module provides functions to dynamically generate Dash Mantine Components
for settings based on the settings schema.
"""

from __future__ import annotations

from typing import Any

import dash_mantine_components as dmc
from dash import html

from optiscope.dash_app.core.id_factory import IDFactory
from optiscope.dash_app.core.settings_schema import (
    SettingDefinition,
    SettingType,
    get_settings_by_category,
)


def create_setting_control(setting: SettingDefinition, value: Any, ids: IDFactory) -> Any:
    """Create a Dash Mantine Component for a setting.

    Args:
        setting: Setting definition
        value: Current value of the setting
        ids: ID factory for generating component IDs

    Returns:
        Dash Mantine Component
    """
    component_id = ids(f"setting-{setting.key}")

    if setting.type == SettingType.SELECT:
        return dmc.Select(
            id=component_id,
            label=setting.label,
            description=setting.description,
            data=setting.options or [],
            value=value,
            disabled=setting.disabled,
            clearable=False,
        )

    elif setting.type == SettingType.SWITCH:
        return dmc.Switch(
            id=component_id,
            label=setting.label,
            description=setting.description,
            checked=value,
            disabled=setting.disabled,
        )

    elif setting.type == SettingType.NUMBER:
        return dmc.NumberInput(
            id=component_id,
            label=setting.label,
            description=setting.description,
            value=value,
            min=setting.min_value,
            max=setting.max_value,
            step=setting.step or 1,
            disabled=setting.disabled,
        )

    elif setting.type == SettingType.TEXT:
        return dmc.TextInput(
            id=component_id,
            label=setting.label,
            description=setting.description,
            value=value,
            disabled=setting.disabled,
        )

    elif setting.type == SettingType.COLOR:
        return dmc.ColorInput(
            id=component_id,
            label=setting.label,
            description=setting.description,
            value=value,
            disabled=setting.disabled,
        )

    else:
        return html.Div(f"Unsupported setting type: {setting.type}")


def create_settings_ui(current_settings: dict[str, Any], ids: IDFactory) -> list:
    """Create the complete settings UI from schema.

    Args:
        current_settings: Dictionary of current setting values
        ids: ID factory for generating component IDs

    Returns:
        List of Dash components organized by category
    """
    settings_by_category = get_settings_by_category()
    components = []

    for category, settings in settings_by_category.items():
        # Create accordion item for each category
        category_controls = []

        for setting in settings:
            value = current_settings.get(setting.key, setting.default)
            control = create_setting_control(setting, value, ids)

            # Add disabled reason if applicable
            if setting.disabled and setting.disabled_reason:
                category_controls.append(
                    html.Div(
                        [
                            control,
                            dmc.Text(
                                setting.disabled_reason,
                                size="xs",
                                c="dimmed",
                                mt=4,
                            ),
                        ]
                    )
                )
            else:
                category_controls.append(control)

            category_controls.append(dmc.Space(h=20))

        # Create accordion item
        components.append(
            dmc.AccordionItem(
                value=category.lower(),
                children=[
                    dmc.AccordionControl(category),
                    dmc.AccordionPanel(category_controls),
                ],
            )
        )

    return components


def create_settings_preview(current_settings: dict[str, Any]) -> list:
    """Create a preview card showing current settings.

    Args:
        current_settings: Dictionary of current setting values

    Returns:
        List of components for the preview
    """
    settings_by_category = get_settings_by_category()
    preview_items = []

    for category, settings in settings_by_category.items():
        preview_items.append(dmc.Text(category, fw=600, size="sm", mt="md"))

        for setting in settings:
            value = current_settings.get(setting.key, setting.default)

            # Format value for display
            if isinstance(value, bool):
                display_value = "Enabled" if value else "Disabled"
            elif setting.type == SettingType.SELECT and setting.options:
                # Find label for the value
                option = next((opt for opt in setting.options if opt["value"] == value), None)
                display_value = option["label"] if option else str(value)
            else:
                display_value = str(value)

            preview_items.append(
                dmc.Group(
                    [
                        dmc.Text(f"{setting.label}:", size="sm", c="dimmed"),
                        dmc.Text(display_value, size="sm"),
                    ],
                    justify="space-between",
                )
            )

    return preview_items
