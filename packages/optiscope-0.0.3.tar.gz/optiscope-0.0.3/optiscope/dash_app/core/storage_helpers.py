"""
Helper functions for working with storage registry and data sources.

These utilities provide convenient access to stored data and help
bridge between the new multi-source system and existing components.
"""

from __future__ import annotations

import logging
from typing import Any

from optiscope.core.data_model import OptimizationResult
from optiscope.dash_app.core import config
from optiscope.dash_app.core.data_source_manager import DataSourceManager
from optiscope.dash_app.core.session_manager import get_session_manager
from optiscope.dash_app.core.storage_registry import get_storage_registry
from optiscope.storage.base import StorageBackend
from optiscope.storage.memory import MemoryStorage

logger = logging.getLogger(__name__)


def get_source_storage(source_id: str) -> StorageBackend | None:
    """
    Get storage backend for a specific source.

    Args:
        source_id: The unique identifier for the data source

    Returns:
        StorageBackend instance or None if not found
    """
    registry = get_storage_registry()
    return registry.get(source_id)


def load_result_from_source(source_id: str, result_key: str) -> OptimizationResult | None:
    """
    Load a specific result from a data source.

    Args:
        source_id: The unique identifier for the data source
        result_key: The key of the result to load

    Returns:
        OptimizationResult or None if not found
    """
    storage = get_source_storage(source_id)
    if not storage:
        logger.warning(f"Storage not found for source_id: {source_id}")
        return None

    try:
        return storage.load_result(result_key)
    except KeyError:
        logger.warning(f"Result '{result_key}' not found in source '{source_id}'")
        return None
    except Exception as e:
        logger.error(
            f"Error loading result '{result_key}' from source '{source_id}': {e}", exc_info=True
        )
        return None


def list_results_from_source(source_id: str) -> list[str]:
    """
    List all results in a data source.

    Args:
        source_id: The unique identifier for the data source

    Returns:
        List of result keys
    """
    storage = get_source_storage(source_id)
    if not storage:
        logger.warning(f"Storage not found for source_id: {source_id}")
        return []

    try:
        return storage.list_results()
    except Exception as e:
        logger.error(f"Error listing results from source '{source_id}': {e}", exc_info=True)
        return []


def get_all_results_from_sources(
    storage_refs: dict[str, Any] | None = None,
) -> dict[str, list[str]]:
    """
    Get all results from all registered sources.

    Args:
        storage_refs: Optional storage references dict from dcc.Store
                     If None, uses all registered sources

    Returns:
        Dictionary mapping source_id to list of result keys
    """
    registry = get_storage_registry()

    if storage_refs and "sources" in storage_refs:
        source_ids = list(storage_refs["sources"].keys())
    else:
        source_ids = list(registry.get_all().keys())

    all_results = {}
    for source_id in source_ids:
        all_results[source_id] = list_results_from_source(source_id)

    return all_results


def load_all_results(
    storage_refs: dict[str, Any] | None = None,
) -> dict[str, dict[str, OptimizationResult]]:
    """
    Load all results from all sources.

    WARNING: This can be memory-intensive for large datasets.
    Use with caution or implement pagination.

    Args:
        storage_refs: Optional storage references dict from dcc.Store

    Returns:
        Nested dictionary: {source_id: {result_key: OptimizationResult}}
    """
    all_results = get_all_results_from_sources(storage_refs)

    loaded_results = {}
    for source_id, result_keys in all_results.items():
        loaded_results[source_id] = {}
        for result_key in result_keys:
            result = load_result_from_source(source_id, result_key)
            if result:
                loaded_results[source_id][result_key] = result

    return loaded_results


def get_combined_result_list(storage_refs: dict[str, Any] | None = None) -> list[dict[str, str]]:
    """
    Get a combined list of all results with source information.

    Useful for populating dropdowns and selectors.

    Args:
        storage_refs: Optional storage references dict from dcc.Store

    Returns:
        List of dicts with keys: 'source_id', 'result_key', 'display_label', 'source_label'
    """
    all_results = get_all_results_from_sources(storage_refs)

    combined = []
    for source_id, result_keys in all_results.items():
        # Get source label from storage_refs if available
        source_label = source_id
        if storage_refs and "sources" in storage_refs:
            source_info = storage_refs["sources"].get(source_id, {})
            source_label = source_info.get("label", source_id)

        for result_key in result_keys:
            combined.append(
                {
                    "source_id": source_id,
                    "result_key": result_key,
                    "display_label": f"{source_label} - {result_key}",
                    "source_label": source_label,
                }
            )

    return combined


def get_result_by_combined_key(
    combined_key: str, storage_refs: dict[str, Any] | None = None
) -> OptimizationResult | None:
    """
    Load a result using a combined source_id::result_key format.

    Args:
        combined_key: Key in format "source_id::result_key"
        storage_refs: Optional storage references dict

    Returns:
        OptimizationResult or None if not found
    """
    if "::" not in combined_key:
        logger.warning(f"Invalid combined key format: {combined_key}")
        return None

    parts = combined_key.split("::", 1)
    if len(parts) != 2:
        logger.warning(f"Invalid combined key format: {combined_key}")
        return None

    source_id, result_key = parts
    return load_result_from_source(source_id, result_key)


def create_combined_key(source_id: str, result_key: str) -> str:
    """
    Create a combined key in the format source_id::result_key.

    Args:
        source_id: The source identifier
        result_key: The result key

    Returns:
        Combined key string
    """
    return f"{source_id}::{result_key}"


def parse_combined_key(combined_key: str) -> tuple[str, str] | None:
    """
    Parse a combined key into source_id and result_key.

    Args:
        combined_key: Key in format "source_id::result_key"

    Returns:
        Tuple of (source_id, result_key) or None if invalid
    """
    if "::" not in combined_key:
        return None

    parts = combined_key.split("::", 1)
    if len(parts) != 2:
        return None

    return parts[0], parts[1]


def get_source_metadata(
    source_id: str, storage_refs: dict[str, Any] | None = None
) -> dict[str, Any]:
    """
    Get metadata for a data source.

    Args:
        source_id: The source identifier
        storage_refs: Optional storage references dict from dcc.Store

    Returns:
        Metadata dictionary
    """
    metadata = {
        "source_id": source_id,
        "label": source_id,
        "type": "unknown",
        "mode": "unknown",
        "num_results": 0,
    }

    # Get metadata from storage_refs if available
    if storage_refs and "sources" in storage_refs:
        source_info = storage_refs["sources"].get(source_id, {})
        metadata.update(source_info)

    # Get live count from storage
    results = list_results_from_source(source_id)
    metadata["num_results"] = len(results)

    return metadata


def validate_source_store(store_data: dict) -> bool:
    if "sources" not in store_data:
        return False

    is_valid = True
    for key, val in store_data["sources"].items():
        if not validate_source_exists(key):
            is_valid = False

    return is_valid


def validate_source_exists(source_id: str) -> bool:
    """
    Check if a data source exists in the registry.

    Args:
        source_id: The source identifier

    Returns:
        True if source exists, False otherwise
    """
    storage = get_source_storage(source_id)
    return storage is not None


def validate_result_exists(source_id: str, result_key: str) -> bool:
    """
    Check if a result exists in a specific source.

    Args:
        source_id: The source identifier
        result_key: The result key

    Returns:
        True if result exists, False otherwise
    """
    storage = get_source_storage(source_id)
    if not storage:
        return False

    try:
        return storage.exists_result(result_key)
    except Exception:
        return False


def delete_source(session_id: str, source_id: str) -> None:
    "Delete source from registry"
    # Get managers
    storage_registry = get_storage_registry()

    if config.APP_MODE == "deployed":
        # In deployed mode, we use a MemoryStorage, so we don't need a session manager
        storage = storage_registry.get(source_id)
        if isinstance(storage, MemoryStorage):
            storage_registry.unregister(source_id)
        else:
            logger.warning(f"Attempted to delete non-memory backend in deployed mode: {source_id}")
    else:
        session_mgr = get_session_manager(session_id)
        ds_mgr = DataSourceManager(session_mgr, storage_registry)
        ds_mgr.remove_data_source(source_id)
