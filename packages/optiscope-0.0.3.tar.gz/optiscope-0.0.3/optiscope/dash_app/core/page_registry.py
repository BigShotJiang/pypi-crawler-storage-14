import importlib
import importlib.metadata
import importlib.resources
import logging
import os

import dash


def _register_page_from_module(module, module_name, app):
    """Helper to register a page from a module."""
    if hasattr(module, "page_module"):
        pm = module.page_module

        # Dynamically get all attributes from the page module instance,
        # excluding methods and private attributes that shouldn't be passed.
        exclude_attrs = {
            "register_callbacks",
            "get_storage_keys",
            "get_documentation",
            "is_available",
        }
        page_kwargs = {
            attr: getattr(pm, attr)
            for attr in dir(pm)
            if not attr.startswith("_") and attr not in exclude_attrs
        }

        dash.register_page(module_name, **page_kwargs)

        # Store the page module instance for later use (e.g., calling is_available())
        dash.page_registry[module_name]["_page_module_instance"] = pm

        if app:
            pm.register_callbacks(app)

        logging.info(f"Successfully registered page: {pm.name}")
    else:
        logging.warning(f"Module {module_name} does not have a 'page_module' attribute.")


def discover_pages(
    pages_dir, app=None, fetch_modules: bool = False, entry_point_group: str = "optiscope.pages"
):
    """Automatically import and register all pages"""
    discover_local_pages(pages_dir, app)

    if fetch_modules:
        discover_installed_package_pages(app, entry_point_group=entry_point_group)


def discover_local_pages(pages_dir, app=None):
    """Discover pages in the local dash_app/pages directory"""
    try:
        # Use importlib.resources to get the path to the pages directory
        with importlib.resources.path(pages_dir, "") as pages_path:
            for item in os.listdir(pages_path):
                path = os.path.join(pages_path, item)
                if os.path.isdir(path) and not item.startswith("_") and not item.startswith("."):
                    try:
                        module_path = f"{pages_dir}.{item}.page"
                        module = importlib.import_module(module_path)
                        _register_page_from_module(module, module_path, app)
                    except ImportError as e:
                        logging.error(f"Could not import page module {module_path}: {e}")
    except ImportError as e:
        logging.error(f"Could not find pages directory {pages_dir}: {e}")


def discover_installed_package_pages(app=None, entry_point_group="optiscope.pages"):
    """Discover pages from installed Python packages that declare them"""
    logging.info(f"Discovering pages for entry point group: {entry_point_group}")
    for dist in importlib.metadata.distributions():
        # Check entry points
        for ep in dist.entry_points:
            if ep.group == entry_point_group:
                logging.info(f"Found entry point: {ep.name} in {dist.metadata['Name']}")
                try:
                    module = ep.load()
                    if module.__name__ in dash.page_registry:
                        logging.info(f"Page {module.__name__} already registered. Skipping.")
                        continue
                    _register_page_from_module(module, module.__name__, app)
                except Exception as e:
                    logging.error(
                        f"Failed to load or register page from entry point {ep.name}: {e}"
                    )
