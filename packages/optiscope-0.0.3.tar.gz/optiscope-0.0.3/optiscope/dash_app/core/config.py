APP_MODE = "local"  # Default mode
