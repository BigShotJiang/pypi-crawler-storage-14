from dash import Dash
from dash_extensions.enrich import Input, Output, callback

from optiscope.dash_app.core.theme_config import DARK_THEME, LIGHT_THEME


def register_callbacks(app: Dash):
    @callback(
        Output("theme-store", "data"),
        Input("color-scheme-switch", "checked"),
        prevent_initial_call=False,
    )
    def update_theme_store(switch_on):
        """Update theme store when switch changes."""
        if switch_on is None:
            return LIGHT_THEME
        return DARK_THEME if switch_on else LIGHT_THEME

    # @callback(
    #     Output({"type": "graph", "index": ALL}, "figure"),
    #     Input("color-scheme-switch", "checked"),
    #     State({"type": "graph", "index": ALL}, "id"),
    # )
    # def update_all_graph_themes(switch_on, ids):
    #     """Update all graph templates when theme changes."""
    #     # Get template object (not just string name)
    #     template = pio.templates[DARK_THEME] if switch_on else pio.templates[LIGHT_THEME]

    #     # Create Patch for each graph
    #     patched_figures = []
    #     for i in ids:
    #         patched_fig = Patch()
    #         patched_fig["layout"]["template"] = template
    #         patched_figures.append(patched_fig)

    #     return patched_figures
