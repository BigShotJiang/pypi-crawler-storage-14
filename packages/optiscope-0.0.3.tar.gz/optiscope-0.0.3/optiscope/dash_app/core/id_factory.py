class IDFactory:
    """
    Generates unique, namespaced IDs for Dash components within a page module.

    This prevents ID collisions when multiple pages or components use the same
    internal ID names.
    """

    def __init__(self, page_id: str, separator: str = "-"):
        """
        Initialize the IDFactory for a specific page.

        Args:
            page_id: A unique identifier for the page (e.g., "data-manager-page", "pareto-explorer").
        """
        if not isinstance(page_id, str) or not page_id:
            raise ValueError("page_id must be a non-empty string.")
        self._page_id = page_id
        self._separator = separator

    def __call__(self, component_id: str) -> str:
        """
        Generate a namespaced ID for a component.

        Args:
            component_id: The base ID for the component (e.g., "refresh-button").

        Returns:
            A unique, namespaced ID (e.g., "data-manager-page-refresh-button").
        """
        if not isinstance(component_id, str) or not component_id:
            raise ValueError("component_id must be a non-empty string.")
        return f"{self._page_id}{self._separator}{component_id}"

    def store(self, store_id: str) -> str:
        """
        Generate a namespaced ID for a dcc.Store component.

        Args:
            store_id: The base ID for the store (e.g., "data-storage").

        Returns:
            A unique, namespaced ID for the store (e.g., "data-manager-page-store-data-storage").
        """
        return self(f"store-{store_id}")

    def graph(self, graph_id: str) -> str:
        """
        Generate a namespaced ID for a dcc.Graph component.

        Args:
            graph_id: The base ID for the graph (e.g., "main-plot").

        Returns:
            A unique, namespaced ID for the graph (e.g., "data-manager-page-graph-main-plot").
        """
        return self(f"graph-{graph_id}")

    def graph_dict(self, graph_id: str) -> dict:
        """
        Generate a namespaced ID for a dcc.Graph component in the form of dictionary.

        Args:
            graph_id: The base ID for the graph (e.g., "main-plot").

        Returns:
            A unique, namespaced ID for the graph (e.g., "data-manager-page-graph-main-plot").
        """
        return {"type": "graph", "index": self(f"graph-{graph_id}")}
