"""
Session database storage backend for imported data sources.

This module provides a storage backend that wraps DatabaseStorage
but filters results by source_id, enabling multiple imported data
sources to coexist in a single session database.
"""

from __future__ import annotations

import logging
from typing import Any

from optiscope.core.data_model import OptimizationResult
from optiscope.core.result_set import ResultSet
from optiscope.storage.database import DatabaseStorage

logger = logging.getLogger(__name__)


class SessionDBStorage(DatabaseStorage):
    """
    Storage backend for imported data in session database.

    This class extends DatabaseStorage to add source_id filtering,
    allowing multiple data sources to be stored in a single session
    database while maintaining isolation between them.
    """

    def __init__(self, connection_string: str, source_id: str, **kwargs):
        """
        Initialize session database storage.

        Args:
            connection_string: Database connection string for session DB
            source_id: Unique identifier for this data source
            **kwargs: Additional configuration passed to DatabaseStorage
        """
        super().__init__(connection_string=connection_string, **kwargs)
        self.source_id = source_id

        logger.debug(
            f"Initialized SessionDBStorage for source '{source_id}' "
            f"with connection: {connection_string}"
        )

    def _prefix_key(self, key: str) -> str:
        """
        Add source_id prefix to a key if it's not already prefixed.

        Args:
            key: Original key

        Returns:
            Prefixed key in format: source_id::key
        """
        if self._is_own_key(key):
            return key
        # Use :: as separator to avoid conflicts with typical key formats
        return f"{self.source_id}::{key}"

    def _unprefix_key(self, prefixed_key: str) -> str:
        """
        Remove source_id prefix from a key.

        Args:
            prefixed_key: Key with source_id prefix

        Returns:
            Original key without prefix
        """
        prefix = f"{self.source_id}::"
        if prefixed_key.startswith(prefix):
            return prefixed_key[len(prefix) :]
        return prefixed_key

    def _is_own_key(self, key: str) -> bool:
        """
        Check if a key belongs to this source.

        Args:
            key: Key to check

        Returns:
            True if key belongs to this source
        """
        return key.startswith(f"{self.source_id}::")

    # Override methods to add source_id filtering

    def save_result(
        self,
        key: str,
        result: OptimizationResult,
        metadata: dict[str, Any] | None = None,
    ) -> None:
        """
        Save result with source_id prefix.

        Args:
            key: Result key (will be prefixed with source_id)
            result: OptimizationResult to save
            metadata: Optional metadata
        """
        prefixed_key = self._prefix_key(key)
        super().save_result(prefixed_key, result, metadata)
        logger.debug(f"Saved result with key '{key}' as '{prefixed_key}'")

    def load_result(self, key: str) -> OptimizationResult:
        """
        Load result by key.

        Args:
            key: Result key (without source_id prefix)

        Returns:
            OptimizationResult object
        """
        prefixed_key = self._prefix_key(key)
        logger.debug(f"Loading result with key '{key}' as '{prefixed_key}'")
        return super().load_result(prefixed_key)

    def delete_result(self, key: str) -> None:
        """
        Delete result by key.

        Args:
            key: Result key (without source_id prefix)
        """
        prefixed_key = self._prefix_key(key)
        logger.debug(f"Deleting result with key '{key}' as '{prefixed_key}'")
        super().delete_result(prefixed_key)

    def exists_result(self, key: str) -> bool:
        """
        Check if result exists.

        Args:
            key: Result key (without source_id prefix)

        Returns:
            True if result exists
        """
        prefixed_key = self._prefix_key(key)
        return super().exists_result(prefixed_key)

    def list_results(self, prefix: str | None = None) -> list[str]:
        """
        List results belonging to this source.

        Args:
            prefix: Optional additional prefix filter (applied after source_id)

        Returns:
            List of result keys (without source_id prefix)
        """
        # Prefix for this source
        source_prefix = f"{self.source_id}::"

        # Get all results from the database for this source
        source_results = super().list_results(prefix=source_prefix)

        # Remove source_id prefix from results
        unprefixed_results = [self._unprefix_key(key) for key in source_results]

        # Apply additional prefix filter if provided
        if prefix:
            unprefixed_results = [key for key in unprefixed_results if key.startswith(prefix)]

        logger.debug(f"Listed {len(unprefixed_results)} results for source '{self.source_id}'")
        return unprefixed_results

    def save_set(
        self,
        result_key: str,
        set_name: str,
        result_set: ResultSet,
    ) -> None:
        """
        Save result set.

        Args:
            result_key: Key of parent result (without source_id prefix)
            set_name: Name of the result set
            result_set: ResultSet to save
        """
        prefixed_key = self._prefix_key(result_key)
        super().save_set(prefixed_key, set_name, result_set)

    def load_set(self, result_key: str, set_name: str) -> ResultSet:
        """
        Load result set.

        Args:
            result_key: Key of parent result (without source_id prefix)
            set_name: Name of the result set

        Returns:
            ResultSet object
        """
        prefixed_key = self._prefix_key(result_key)
        return super().load_set(prefixed_key, set_name)

    def delete_set(self, result_key: str, set_name: str) -> None:
        """
        Delete result set.

        Args:
            result_key: Key of parent result (without source_id prefix)
            set_name: Name of the result set
        """
        prefixed_key = self._prefix_key(result_key)
        super().delete_set(prefixed_key, set_name)

    def list_sets(self, result_key: str) -> list[str]:
        """
        List result sets for a result.

        Args:
            result_key: Key of parent result (without source_id prefix)

        Returns:
            List of set names
        """
        prefixed_key = self._prefix_key(result_key)
        return super().list_sets(prefixed_key)

    def get_result_metadata(self, key: str) -> dict[str, Any]:
        """
        Get result metadata.

        Args:
            key: Result key (without source_id prefix)

        Returns:
            Metadata dictionary
        """
        prefixed_key = self._prefix_key(key)
        return super().get_result_metadata(prefixed_key)

    def update_result_metadata(self, key: str, metadata: dict[str, Any]) -> None:
        """
        Update result metadata.

        Args:
            key: Result key (without source_id prefix)
            metadata: Metadata to update
        """
        prefixed_key = self._prefix_key(key)
        super().update_result_metadata(prefixed_key, metadata)

    def clear(self, prefix: str | None = None) -> int:
        """
        Clear results belonging to this source.

        Args:
            prefix: Optional additional prefix filter

        Returns:
            Number of results deleted
        """
        # Get all keys for this source
        keys_to_delete = self.list_results(prefix=prefix)

        # Delete each one
        for key in keys_to_delete:
            self.delete_result(key)

        logger.info(f"Cleared {len(keys_to_delete)} results for source '{self.source_id}'")
        return len(keys_to_delete)

    def get_storage_info(self) -> dict[str, Any]:
        """
        Get storage information for this source.

        Returns:
            Dictionary with storage information including source_id
        """
        info = super().get_storage_info()
        info["source_id"] = self.source_id
        info["n_results"] = len(self.list_results())
        return info

    def to_dict(self) -> dict[str, Any]:
        """
        Serialize storage backend to dictionary.

        Returns:
            Dictionary representation (not typically used for session storage)
        """
        data = super().to_dict()
        data["source_id"] = self.source_id
        data["storage_class"] = "SessionDBStorage"
        return data

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> SessionDBStorage:
        """
        Deserialize storage backend from dictionary.

        Args:
            data: Dictionary representation

        Returns:
            SessionDBStorage instance
        """
        connection_string = data.get("connection_string")
        source_id = data.get("source_id")

        if not connection_string or not source_id:
            raise ValueError("SessionDBStorage requires both connection_string and source_id")

        return cls(
            connection_string=connection_string,
            source_id=source_id,
        )
