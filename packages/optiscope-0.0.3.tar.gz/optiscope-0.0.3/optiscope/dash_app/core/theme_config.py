"""Theme configuration for the Dash application.

Centralized configuration for Plotly figure themes.
Modify the LIGHT_THEME and DARK_THEME values to change the theme templates
used throughout the application.
"""

import dash_mantine_components as dmc
import plotly.io as pio

dmc.add_figure_templates()

# Create a custom light theme
optiscope_light = pio.templates["mantine_light"]
optiscope_light.layout.margin = dict(t=40, b=40, l=40, r=40)
optiscope_light.layout.title.font.family = "Open Sans, bold"
optiscope_light.layout.title.font.variant = "small-caps"


# Create a custom dark theme
optiscope_dark = pio.templates["mantine_dark"]
optiscope_dark.layout.margin = dict(t=40, b=40, l=40, r=40)
optiscope_dark.layout.title.font.family = "Open Sans, bold"
optiscope_dark.layout.title.font.variant = "small-caps"

# Register the new custom templates
pio.templates["optiscope_light"] = optiscope_light
pio.templates["optiscope_dark"] = optiscope_dark


# Plotly theme templates to use for light and dark modes
# Available built-in templates: plotly, plotly_white, plotly_dark, ggplot2, seaborn, simple_white, none
# Dash Mantine Components provides: mantine_light, mantine_dark
LIGHT_THEME = "optiscope_light"
DARK_THEME = "optiscope_dark"

pio.templates.default = "optiscope_light"


def get_theme_template(is_dark_mode: bool) -> str:
    """Get the appropriate theme template based on the mode.

    Args:
        is_dark_mode: Whether dark mode is enabled

    Returns:
        The theme template string
    """
    return DARK_THEME if is_dark_mode else LIGHT_THEME
