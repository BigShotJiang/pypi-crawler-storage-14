INVALID_STR: str = "INVALID"
VALID_STR: str = "VALID"

REF_STORE_STR: str = "storage-references"
RESULTS_STORE_STR: str = "global-results-store"

ICON_OBSERVABLES: str = "mdi:eye-outline"
