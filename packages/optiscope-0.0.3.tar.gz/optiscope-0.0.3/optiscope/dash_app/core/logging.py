import logging


class LogHandler(logging.Handler):
    def __init__(self):
        super().__init__()
        self.logs = []
        self.formatter = logging.Formatter(
            "%(asctime)s - %(levelname)s - %(message)s", datefmt="%Y-%m-%d %H:%M:%S"
        )

    def emit(self, record):
        log_entry = {
            "timestamp": self.formatter.formatTime(record, self.formatter.datefmt),  # type: ignore
            "name": record.name,
            "level": record.levelname,
            "message": record.getMessage(),
        }
        self.logs.append(log_entry)


# Configure logging with a custom timestamp format
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",  # Custom timestamp format
)

# Set pages logger to DEBUG
logging.getLogger("dash_app.pages").setLevel(logging.DEBUG)

# Add the custom handler to the pages logger
_log_handler = LogHandler()
logging.getLogger("dash_app.pages").addHandler(_log_handler)

# Add the custom handler to the main app logger
logging.getLogger("__main__").addHandler(_log_handler)

# Add the custom handler to the optiscope logger
logging.getLogger("optiscope").addHandler(_log_handler)
