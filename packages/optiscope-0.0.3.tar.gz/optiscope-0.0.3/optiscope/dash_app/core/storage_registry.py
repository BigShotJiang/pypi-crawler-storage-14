"""
A server-side registry for managing storage backend instances.
"""

from __future__ import annotations

import importlib.metadata
import logging

from optiscope.storage.base import StorageBackend

logger = logging.getLogger(__name__)


class StorageRegistry:
    """Server-side registry of storage backends."""

    def __init__(self):
        """Initializes the StorageRegistry."""
        self._storages: dict[str, StorageBackend] = {}

    def register(self, source_id: str, storage_backend: StorageBackend) -> None:
        """
        Register a storage backend.
        Args:
            source_id: The unique identifier for the data source.
            storage_backend: The storage backend instance.
        """
        self._storages[source_id] = storage_backend

    def get(self, source_id: str) -> StorageBackend | None:
        """
        Retrieve a storage backend.
        Args:
            source_id: The unique identifier for the data source.
        Returns:
            The storage backend instance, or None if not found.
        """
        return self._storages.get(source_id)

    def unregister(self, source_id: str) -> None:
        """
        Remove and cleanup a storage backend.
        Args:
            source_id: The unique identifier for the data source.
        """
        if source_id in self._storages:
            storage = self._storages[source_id]
            storage.close()
            del self._storages[source_id]

    def get_all(self) -> dict[str, StorageBackend]:
        """Retrieve all registered storage backends."""
        return self._storages

    def unregister_all(self) -> None:
        """Remove and cleanup all storage backends."""
        for source_id in list(self._storages.keys()):
            self.unregister(source_id)


# Global instance of the storage registry.
# This simple approach works for single-worker server setups.
# For multi-worker setups, this would need to be replaced with a
# more robust solution (e.g., Redis-based).
_storage_registry: StorageRegistry | None = None


def discover_storages(registry: StorageRegistry, entry_point_group: str = "optiscope.storage"):
    """Discover storages from installed Python packages that declare them."""
    for dist in importlib.metadata.distributions():
        for ep in dist.entry_points:
            if ep.group == entry_point_group:
                try:
                    module = ep.load()
                    if hasattr(module, "register_storages"):
                        module.register_storages(registry)
                        logger.info(f"Ran storage registration from entry point '{ep.name}'.")
                except Exception as e:
                    logger.warning(f"Failed to load storages from entry point '{ep.name}': {e}")


def get_storage_registry() -> StorageRegistry:
    """Factory function to get the global StorageRegistry instance."""
    global _storage_registry
    if _storage_registry is None:
        _storage_registry = StorageRegistry()
        # Discover and register storages from entry points
        discover_storages(_storage_registry)
    return _storage_registry
