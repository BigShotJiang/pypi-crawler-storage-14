"""
Manages per-user session data and resources.
"""

from __future__ import annotations

import atexit
import logging
import shutil
from pathlib import Path
from uuid import uuid4

logger = logging.getLogger(__name__)


class SessionManager:
    """Manages per-user session database and resources."""

    def __init__(
        self,
        session_id: str,
        base_session_path: Path = Path("./sessions"),
        db_backend: str = "duckdb",
    ):
        """
        Initialize a new session manager.
        Args:
            session_id: The unique identifier for the session.
            base_session_path: The base path where session data is stored.
        """

        self.db_backend = db_backend

        if db_backend == "sqlite":
            db_extension = "db"
        elif db_backend == "duckdb":
            db_extension = "duckdb"
        else:
            raise ValueError("db_backend is not valid.")

        self.session_id = session_id
        self.session_path = base_session_path / self.session_id
        self.session_db_path = self.session_path / f"data.{db_extension}"
        self._init_session_dir()

    def _init_session_dir(self):
        """Create the session directory if it doesn't exist."""
        logger.info(f"Creating session directory: {self.session_path}")
        self.session_path.mkdir(parents=True, exist_ok=True)

    def get_db_connection_string(self) -> str:
        """Return the DB connection string for the session database."""
        if self.db_backend == "sqlite":
            return f"sqlite:///{self.session_db_path.resolve()}"
        else:
            return f"duckdb:///{self.session_db_path.resolve()}"

    def cleanup(self):
        """Remove the session directory and all its contents."""
        logger.info(f"Cleaning up session directory {self.session_path}.")
        if self.session_path.exists():
            shutil.rmtree(self.session_path)


class GlobalSessionManager:
    """A global manager to create, retrieve, and cleanup user sessions."""

    def __init__(self):
        self._sessions: dict[str, SessionManager] = {}
        atexit.register(self.cleanup_all)

    def get_session(self, session_id: str) -> SessionManager:
        """Get a session by ID, creating one if it doesn't exist."""
        if session_id not in self._sessions:
            self._sessions[session_id] = SessionManager(session_id)
        return self._sessions[session_id]

    def cleanup_session(self, session_id: str):
        """Cleanup a specific session."""
        if session_id in self._sessions:
            logger.debug(f"Cleaning up session ({session_id})")
            self._sessions[session_id].cleanup()
            del self._sessions[session_id]

    def cleanup_all(self):
        """Cleanup all active sessions."""
        for session_id in list(self._sessions.keys()):
            self.cleanup_session(session_id)


# Global instance of the session manager
_global_session_manager = GlobalSessionManager()


def get_session_manager(session_id: str) -> SessionManager:
    """
    Factory function to get the SessionManager for a given session ID.
    Args:
        session_id: The session ID, typically from Flask session.
    Returns:
        The SessionManager instance for the given session.
    """
    logger.debug(f"Getting session manager for {session_id}.")

    return _global_session_manager.get_session(session_id)


def generate_session_id() -> str:
    """Generate a new unique session ID."""
    logger.debug("Generating new session ID.")
    return str(uuid4())
