"""
Compatibility layer for transitioning from global-results-store to storage-references.

This module provides utilities to create a virtual StorageManager that reads
from the new multi-source registry system, allowing existing components to
work without modification.
"""

from __future__ import annotations

from typing import Any

from optiscope.core.data_model import OptimizationResult
from optiscope.dash_app.core.storage_registry import get_storage_registry
from optiscope.storage.memory import MemoryStorage


class VirtualStorageManager:
    """
    A virtual StorageManager that aggregates all sources from the registry.

    This allows existing code expecting a single StorageManager to work
    with the new multi-source system.
    """

    def __init__(self, storage_refs: dict[str, Any] | None = None):
        """
        Initialize virtual storage manager.

        Args:
            storage_refs: Storage references from dcc.Store
        """
        self.storage_refs = storage_refs or {"sources": {}}
        self.registry = get_storage_registry()

        # Create a memory storage as "primary" for compatibility
        self.primary = MemoryStorage()

    def load_result(self, key: str) -> OptimizationResult:
        """
        Load a result by combined key (source_id::result_key).

        For backwards compatibility, also tries each source if no :: found.
        """
        if "::" in key:
            # New format: source_id::result_key
            source_id, result_key = key.split("::", 1)
            storage = self.registry.get(source_id)
            if storage:
                return storage.load_result(result_key)
            raise KeyError(f"Source not found: {source_id}")
        else:
            # Old format: try each source
            for source_id in self.storage_refs.get("sources", {}).keys():
                storage = self.registry.get(source_id)
                if storage and storage.exists_result(key):
                    return storage.load_result(key)
            raise KeyError(f"Result not found: {key}")

    def list_results(self, prefix: str | None = None) -> list[str]:
        """
        List all results from all sources using combined keys.
        """
        all_results = []
        for source_id in self.storage_refs.get("sources", {}).keys():
            storage = self.registry.get(source_id)
            if storage:
                for result_key in storage.list_results(prefix):
                    all_results.append(f"{source_id}::{result_key}")
        return all_results

    def exists_result(self, key: str) -> bool:
        """Check if a result exists."""
        try:
            self.load_result(key)
            return True
        except KeyError:
            return False

    def to_dict(self) -> dict[str, Any]:
        """
        Serialize to dict format.

        Note: This doesn't serialize actual data, just references.
        """
        return {
            "storage_refs": self.storage_refs,
            "type": "virtual",
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> VirtualStorageManager:
        """Deserialize from dict."""
        return cls(storage_refs=data.get("storage_refs"))


def create_virtual_storage_manager(
    storage_refs: dict[str, Any] | None = None,
) -> VirtualStorageManager:
    """
    Factory function to create a virtual storage manager.

    Args:
        storage_refs: Storage references from dcc.Store

    Returns:
        VirtualStorageManager instance
    """
    return VirtualStorageManager(storage_refs)
