"""Settings schema definition for OptiScope.

This module defines the schema for application settings using Pydantic models.
The schema is used to:
1. Define available settings with their types, defaults, and constraints
2. Validate user settings
3. Generate the settings UI dynamically
4. Handle version compatibility
"""

from __future__ import annotations

from enum import Enum
from typing import Any

from pydantic import BaseModel, Field


class SettingType(str, Enum):
    """Types of settings supported by the UI."""

    SELECT = "select"
    SWITCH = "switch"
    NUMBER = "number"
    TEXT = "text"
    COLOR = "color"


class SettingDefinition(BaseModel):
    """Definition of a single setting."""

    key: str = Field(..., description="Unique identifier for the setting")
    label: str = Field(..., description="Human-readable label")
    type: SettingType = Field(..., description="Type of setting control")
    default: Any = Field(..., description="Default value")
    description: str = Field(..., description="Description of what this setting does")
    category: str = Field(..., description="Category for grouping settings")
    options: list[dict[str, Any]] | None = Field(
        None, description="Options for select-type settings"
    )
    min_value: float | None = Field(None, description="Minimum value for number settings")
    max_value: float | None = Field(None, description="Maximum value for number settings")
    step: float | None = Field(None, description="Step size for number settings")
    disabled: bool = Field(False, description="Whether the setting is currently disabled")
    disabled_reason: str | None = Field(None, description="Reason why the setting is disabled")


class UserSettings(BaseModel):
    """User settings with validation."""

    version: str = Field(..., description="OptiScope version these settings were created with")
    theme: str = Field("light", description="UI theme")
    language: str = Field("en", description="Interface language")
    auto_save: bool = Field(True, description="Auto-save data changes")
    page_size: int = Field(50, ge=10, le=1000, description="Default table page size")
    show_tooltips: bool = Field(True, description="Show tooltips")
    plot_animation: bool = Field(True, description="Enable plot animations")
    decimal_places: int = Field(3, ge=0, le=10, description="Decimal precision for display")

    class Config:
        """Pydantic configuration."""

        extra = "allow"  # Allow extra fields for forward compatibility


# Get version from pyproject.toml
def get_optiscope_version() -> str:
    """Get the current OptiScope version."""
    from optiscope import __version__

    return __version__


# Define the complete settings schema
SETTINGS_SCHEMA: list[SettingDefinition] = [
    # General Settings
    SettingDefinition(
        key="theme",
        label="Theme",
        type=SettingType.SELECT,
        default="light",
        description="Choose between light and dark theme",
        category="General",
        options=[
            {"value": "light", "label": "Light"},
            {"value": "dark", "label": "Dark"},
        ],
    ),
    SettingDefinition(
        key="language",
        label="Language",
        type=SettingType.SELECT,
        default="en",
        description="Interface language (not yet functional)",
        category="General",
        options=[
            {"value": "en", "label": "English"},
            {"value": "es", "label": "Spanish"},
            {"value": "fr", "label": "French"},
            {"value": "pt", "label": "Portuguese"},
        ],
        disabled=True,
        disabled_reason="Language support coming in a future release",
    ),
    # Display Settings
    SettingDefinition(
        key="show_tooltips",
        label="Show Tooltips",
        type=SettingType.SWITCH,
        default=True,
        description="Display helpful tooltips when hovering over elements",
        category="Display",
    ),
    SettingDefinition(
        key="plot_animation",
        label="Plot Animations",
        type=SettingType.SWITCH,
        default=True,
        description="Enable smooth animations when updating plots",
        category="Display",
    ),
    SettingDefinition(
        key="decimal_places",
        label="Decimal Places",
        type=SettingType.NUMBER,
        default=3,
        description="Number of decimal places to display for numeric values",
        category="Display",
        min_value=0,
        max_value=10,
        step=1,
    ),
    # Data Settings
    SettingDefinition(
        key="auto_save",
        label="Auto-Save",
        type=SettingType.SWITCH,
        default=True,
        description="Automatically save data changes",
        category="Data",
    ),
    SettingDefinition(
        key="page_size",
        label="Table Page Size",
        type=SettingType.NUMBER,
        default=50,
        description="Default number of rows per page in tables",
        category="Data",
        min_value=10,
        max_value=1000,
        step=10,
    ),
]


def get_default_settings() -> UserSettings:
    """Get default settings based on the schema."""
    defaults = {setting.key: setting.default for setting in SETTINGS_SCHEMA}
    defaults["version"] = get_optiscope_version()
    return UserSettings(**defaults)


def get_settings_by_category() -> dict[str, list[SettingDefinition]]:
    """Group settings by category."""
    categories: dict[str, list[SettingDefinition]] = {}
    for setting in SETTINGS_SCHEMA:
        if setting.category not in categories:
            categories[setting.category] = []
        categories[setting.category].append(setting)
    return categories
