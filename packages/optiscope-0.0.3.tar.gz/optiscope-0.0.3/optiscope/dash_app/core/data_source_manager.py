"""
High-level manager for adding and removing data sources.
"""

from __future__ import annotations

import logging
import uuid
from pathlib import Path
from typing import Any, Literal

from optiscope.dash_app.core import config
from optiscope.dash_app.core.session_db_storage import SessionDBStorage
from optiscope.dash_app.core.session_manager import SessionManager
from optiscope.dash_app.core.storage_registry import StorageRegistry
from optiscope.io.registry import get_global_registry
from optiscope.storage.database import DatabaseStorage
from optiscope.storage.memory import MemoryStorage

logger = logging.getLogger(__name__)

# Define default thresholds for deciding whether to import or mount a data source.
DEFAULT_IMPORT_THRESHOLDS = {
    "csv": {"max_size_mb": 100, "action": "import_to_db"},
    "filesystem": {
        "max_files": 1000,
        "max_size_mb": 500,
        "action": "import_to_db",
    },
    "sqlite": {"action": "mount"},
}


class DataSourceManager:
    """High-level manager for adding/removing data sources."""

    def __init__(
        self,
        session_manager: SessionManager,
        storage_registry: StorageRegistry,
        thresholds: dict[str, Any] | None = None,
    ):
        """
        Initializes the DataSourceManager.
        Args:
            session_manager: The session manager instance.
            storage_registry: The storage registry instance.
            thresholds: Optional dictionary of import thresholds.
        """

        self.session_manager = session_manager
        self.registry = storage_registry
        self.thresholds = thresholds or DEFAULT_IMPORT_THRESHOLDS

    def add_data_source(self, source_config: dict[str, Any]) -> dict[str, Any]:
        """
        Add a new data source based on configuration.
        Args:
            source_config: A dictionary containing the source configuration.
        Returns:
            A dictionary with the reference object for dcc.Store.
        """

        source_id = str(uuid.uuid4())
        source_type = source_config.get("type").lower()  # type: ignore
        path = source_config.get("path")
        label = source_config.get("label", "Untitled Source")

        if source_type in ["sqlite", "duckdb"] and path:
            return self._mount_database(source_id, path, label, db_type=source_type)

        if "data" in source_config:
            registry = get_global_registry()
            for file_format in registry.list_formats():
                if source_type == file_format["name"].lower():
                    # Assuming the first extension is representative
                    extension = file_format["extensions"][0]
                    return self._import_to_session_db(
                        source_id, source_config["data"], label, extension
                    )

        raise ValueError(f"Unsupported data source type: {source_type}")

    def remove_data_source(self, source_id: str) -> None:
        """
        Remove a data source and clean up its resources.
        Args:
            source_id: The unique identifier for the data source.
        """
        logger.info(f"Removing source {source_id}")
        self.registry.unregister(source_id)

    def _mount_database(
        self,
        source_id: str,
        db_path_str: str,
        label: str,
        db_type: Literal["sqlite", "duckdb"] = "sqlite",
    ) -> dict[str, Any]:
        """
        Mount an external SQLite database.
        Args:
            source_id: The unique identifier for the data source.
            db_path_str: The path to the SQLite database file.
            label: The display name for the data source.
            db_type: The type of database to mount.
        Returns:
            A dictionary with the reference object for dcc.Store.
        """
        db_path = Path(db_path_str)
        if not db_path.exists():
            raise FileNotFoundError(f"Database not found at {db_path}")

        # Use read-only mode for safety
        if db_type == "sqlite":
            connection_string = f"sqlite:///{db_path.resolve()}?mode=ro"
        elif db_type == "duckdb":
            connection_string = f"duckdb:///{db_path.resolve()}?access_mode=read_only"
        else:
            raise ValueError(f"Unsupported database type: {db_type}")

        storage = DatabaseStorage(connection_string=connection_string)
        self.registry.register(source_id, storage)
        num_results = len(storage.list_results())
        last_modified = db_path.stat().st_mtime

        return {
            "source_id": source_id,
            "type": db_type,
            "path": str(db_path),
            "label": label,
            "mode": "mounted",
            "storage_location": "external",
            "metadata": {
                "num_results": num_results,
                "last_modified": last_modified,
            },
        }

    def _import_to_session_db(
        self, source_id: str, data: bytes, label: str, original_type: str
    ) -> dict[str, Any]:
        """
        Import data into the session database.
        Args:
            source_id: The unique identifier for the data source.
            data: The data to import, as bytes.
            label: The display name for the data source.
            original_type: The original type of the data source (e.g., 'csv').
        Returns:
            A dictionary with the reference object for dcc.Store.
        """
        if config.APP_MODE == "deployed":
            storage = MemoryStorage()
            storage_location = "memory"
            connection_string = None
        else:
            session_db_conn_str = self.session_manager.get_db_connection_string()
            storage = SessionDBStorage(connection_string=session_db_conn_str, source_id=source_id)
            storage_location = "session_db"
            connection_string = session_db_conn_str

        # Use the file format registry to parse the data
        registry = get_global_registry()

        try:
            # Import the data from bytes
            import os
            import tempfile

            with tempfile.NamedTemporaryFile(
                mode="wb", suffix=f".{original_type}", delete=False
            ) as tmp_file:
                tmp_file.write(data)
                tmp_path = tmp_file.name

            try:
                handler = registry.get_handler_for_file(Path(tmp_path))
                optimization_result = handler.read(Path(tmp_path))
                result_key = label
                storage.save_result(result_key, optimization_result)
                logger.info(
                    f"Successfully imported {original_type} data as source '{source_id}' "
                    f"with key '{result_key}'"
                )
                num_results = 1
            except Exception as e:
                logger.error(f"Failed to read optimization result {label}: {e}")
                num_results = 0
            finally:
                if os.path.exists(tmp_path):
                    os.unlink(tmp_path)

        except Exception as e:
            logger.error(f"Failed to import data: {e}", exc_info=True)
            raise

        self.registry.register(source_id, storage)

        return {
            "source_id": source_id,
            "type": "database" if config.APP_MODE == "local" else "memory",
            "label": label,
            "mode": "imported",
            "storage_location": storage_location,
            "connection_string": connection_string,
            "original_type": original_type,
            "metadata": {"num_results": num_results},
        }

    def _should_import_to_db(self, source_config: dict[str, Any]) -> bool:
        """
        Decide whether to import or mount a source based on size and complexity.
        Args:
            source_config: The configuration of the data source.
        Returns:
            True to import, False to mount.
        """
        source_type = source_config["type"]
        threshold = self.thresholds.get(source_type, {})

        if threshold.get("action") == "mount":
            return False
        if threshold.get("action") == "import_to_db":
            # Add size checks here based on source_config
            return True
        return False
