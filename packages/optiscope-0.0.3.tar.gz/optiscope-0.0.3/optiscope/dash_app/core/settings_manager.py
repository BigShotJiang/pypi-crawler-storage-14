"""Settings manager for OptiScope.

This module provides the SettingsManager class for loading, saving, and managing
application settings. It handles both local mode (file-based persistence) and
deployed mode (session-based storage).
"""

from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import Any

from pydantic import ValidationError

from optiscope.dash_app.core.settings_schema import (
    UserSettings,
    get_default_settings,
    get_optiscope_version,
)

logger = logging.getLogger(__name__)


class SettingsManager:
    """Manages application settings with mode-aware storage.

    In local mode, settings are persisted to ~/.optiscope/settings.json.
    In deployed mode, settings are stored in session storage (dcc.Store).
    """

    def __init__(self, app_mode: str = "local"):
        """Initialize the settings manager.

        Args:
            app_mode: Either 'local' or 'deployed'
        """
        self.app_mode = app_mode
        self.settings: UserSettings = get_default_settings()

        # Local mode uses file-based storage
        if app_mode == "local":
            self.settings_dir = Path.home() / ".optiscope"
            self.settings_file = self.settings_dir / "settings.json"
            self._ensure_settings_dir()
            self.load_settings()

    def _ensure_settings_dir(self) -> None:
        """Ensure the settings directory exists (local mode only)."""
        if self.app_mode == "local":
            self.settings_dir.mkdir(parents=True, exist_ok=True)
            logger.debug(f"Settings directory: {self.settings_dir}")

    def load_settings(self, settings_dict: dict[str, Any] | None = None) -> UserSettings:
        """Load settings from file (local mode) or dict (deployed mode).

        Args:
            settings_dict: Settings dictionary (for deployed mode or import)

        Returns:
            Loaded UserSettings object
        """
        if settings_dict is not None:
            # Load from provided dictionary (deployed mode or import)
            try:
                self.settings = UserSettings(**settings_dict)
                self._check_version_compatibility()
                logger.info("Settings loaded from dictionary")
            except ValidationError as e:
                logger.warning(f"Invalid settings provided: {e}. Using defaults.")
                self.settings = get_default_settings()
        elif self.app_mode == "local" and self.settings_file.exists():
            # Load from file (local mode)
            try:
                with open(self.settings_file) as f:
                    data = json.load(f)
                self.settings = UserSettings(**data)
                self._check_version_compatibility()
                logger.info(f"Settings loaded from {self.settings_file}")
            except (json.JSONDecodeError, ValidationError) as e:
                logger.warning(f"Failed to load settings: {e}. Using defaults.")
                self.settings = get_default_settings()
        else:
            # Use defaults
            self.settings = get_default_settings()
            logger.info("Using default settings")

        return self.settings

    def save_settings(self) -> dict[str, Any]:
        """Save settings to file (local mode) or return dict (deployed mode).

        Returns:
            Settings as dictionary (for use with dcc.Store in deployed mode)
        """
        settings_dict = self.settings.model_dump()

        if self.app_mode == "local":
            # Save to file
            try:
                with open(self.settings_file, "w") as f:
                    json.dump(settings_dict, f, indent=2)
                logger.info(f"Settings saved to {self.settings_file}")
            except Exception as e:
                logger.error(f"Failed to save settings: {e}")

        return settings_dict

    def get_setting(self, key: str) -> Any:
        """Get a specific setting value.

        Args:
            key: Setting key

        Returns:
            Setting value
        """
        return getattr(self.settings, key, None)

    def update_setting(self, key: str, value: Any) -> None:
        """Update a specific setting value.

        Args:
            key: Setting key
            value: New value
        """
        if hasattr(self.settings, key):
            setattr(self.settings, key, value)
            logger.debug(f"Updated setting {key} = {value}")
        else:
            logger.warning(f"Attempted to update unknown setting: {key}")

    def update_settings(self, updates: dict[str, Any]) -> None:
        """Update multiple settings at once.

        Args:
            updates: Dictionary of setting key-value pairs
        """
        for key, value in updates.items():
            self.update_setting(key, value)

    def export_settings(self) -> str:
        """Export settings as JSON string.

        Returns:
            JSON string of current settings
        """
        return json.dumps(self.settings.model_dump(), indent=2)

    def import_settings(self, json_string: str) -> tuple[bool, str]:
        """Import settings from JSON string.

        Args:
            json_string: JSON string containing settings

        Returns:
            Tuple of (success, message)
        """
        try:
            data = json.loads(json_string)
            # Validate settings
            imported_settings = UserSettings(**data)

            # Check version compatibility
            version_warning = self._check_version_compatibility(imported_settings.version)

            # Apply settings
            self.settings = imported_settings

            if version_warning:
                return True, f"Settings imported successfully. {version_warning}"
            else:
                return True, "Settings imported successfully."

        except json.JSONDecodeError as e:
            return False, f"Invalid JSON format: {e}"
        except ValidationError as e:
            return False, f"Invalid settings format: {e}"
        except Exception as e:
            return False, f"Failed to import settings: {e}"

    def _check_version_compatibility(self, settings_version: str | None = None) -> str | None:
        """Check if settings version is compatible with current app version.

        Args:
            settings_version: Version to check (defaults to current settings version)

        Returns:
            Warning message if there's a version mismatch, None otherwise
        """
        if settings_version is None:
            settings_version = self.settings.version

        current_version = get_optiscope_version()

        if settings_version != current_version:
            logger.warning(f"Settings version mismatch: {settings_version} vs {current_version}")
            # Update to current version
            self.settings.version = current_version
            return (
                f"Settings were created with version {settings_version}, "
                f"but you're running version {current_version}. "
                f"Settings have been migrated automatically."
            )

        return None

    def reset_to_defaults(self) -> None:
        """Reset all settings to their default values."""
        self.settings = get_default_settings()
        logger.info("Settings reset to defaults")

    def get_all_settings(self) -> dict[str, Any]:
        """Get all settings as a dictionary.

        Returns:
            Dictionary of all settings
        """
        return self.settings.model_dump()
