from __future__ import annotations

from typing import TYPE_CHECKING

import pandas as pd
import plotly.express as px
import plotly.graph_objects as go

if TYPE_CHECKING:
    from optiscope.core.data_model import OptimizationResult


def create_interactive_scatter(
    results: list[OptimizationResult] | OptimizationResult,
    x_axis: str,
    y_axis: str,
    selected_sets: list[str] | None = None,
    color_by: str | None = None,
    marker_by: str | None = None,
    template: str | None = None,
    height: int = 600,
) -> go.Figure:
    """
    Create an interactive scatter plot with plotly.graph_objects.

    Args:
        results: One or more OptimizationResult instances.
        x_axis: Column name for x-axis.
        y_axis: Column name for y-axis.
        selected_sets: List of set names to filter by. If None or empty, shows all data.
        color_by: Column name to color by. Can be "Set".
        marker_by: Column name to determine marker symbol.
        template: Plotly template name.
        height: Height of the figure.
    """
    if not isinstance(results, list):
        results = [results]

    dfs = []
    for res in results:
        df = res.get_all_data().copy()
        if df.empty:
            continue

        df["Result"] = res.problem_metadata.name
        df["original_index"] = df.index

        # Calculate sets for each point
        # We map index -> list of set names
        index_to_sets = {}
        # Initialize for all indices
        for idx in df.index:
            index_to_sets[idx] = []

        # res.sets is a dict[str, ResultSet]
        for s in res.sets.values():
            for idx in s.indices:
                if idx in index_to_sets:
                    index_to_sets[idx].append(s.name)

        # Create SetList column
        df["SetList"] = df.index.map(index_to_sets)

        # Create AllSets string for tooltip
        df["AllSets"] = df["SetList"].apply(lambda x: ", ".join(x) if x else "No sets")

        # Filter if selected_sets is provided
        if selected_sets:
            # Keep if intersection is not empty
            selected_sets_set = set(selected_sets)
            mask = df["SetList"].apply(lambda x: not selected_sets_set.isdisjoint(x))
            df = df[mask]

        if not df.empty:
            dfs.append(df)

    fig = go.Figure()

    if not dfs:
        fig.add_annotation(
            text="No data available",
            xref="paper",
            yref="paper",
            x=0.5,
            y=0.5,
            showarrow=False,
        )
        fig.update_layout(height=height, template=template)
        return fig

    combined_df = pd.concat(dfs, ignore_index=True)

    if x_axis not in combined_df.columns or y_axis not in combined_df.columns:
        fig.add_annotation(
            text=f"Columns {x_axis} or {y_axis} not found",
            xref="paper",
            yref="paper",
            x=0.5,
            y=0.5,
            showarrow=False,
        )
        fig.update_layout(height=height, template=template)
        return fig

    # Handle "Set" coloring
    if color_by == "Set":
        # Explode the dataframe so points appear for each set they belong to
        plot_df = combined_df.explode("SetList")
        plot_df.rename(columns={"SetList": "Set"}, inplace=True)

        if selected_sets:
            plot_df = plot_df[plot_df["Set"].isin(selected_sets)]

        # Handle points with no sets or filtered out sets
        plot_df["Set"] = plot_df["Set"].fillna("Uncategorized")

        # Create color map from results
        color_map = {}
        for res in results:
            for s in res.sets.values():
                if s.color:
                    color_map[s.name] = s.color

        fig = px.scatter(
            plot_df,
            x=x_axis,
            y=y_axis,
            color="Set",
            symbol=marker_by,
            hover_data=["Result", "original_index", "AllSets"],
            color_discrete_map=color_map if color_map else None,
            template=template,
        )
    else:
        fig = px.scatter(
            combined_df,
            x=x_axis,
            y=y_axis,
            color=color_by,
            symbol=marker_by,
            hover_data=["Result", "original_index", "AllSets"],
            template=template,
        )

    fig.update_layout(
        xaxis_title=x_axis,
        yaxis_title=y_axis,
        clickmode="event+select",
        height=height,
        legend_title_text=color_by if color_by != "Set" else "Set",
    )

    fig.update_traces(
        hovertemplate=(
            f"<b>{x_axis}</b>: %{{x}}<br>"
            f"<b>{y_axis}</b>: %{{y}}<br>"
            f"<b>Result</b>: %{{customdata[0]}}<br>"
            f"<b>Index</b>: %{{customdata[1]}}<br>"
            f"<b>Sets</b>: %{{customdata[2]}}<extra></extra>"
        )
    )

    return fig
