"""
Scatter Plot Matrix (SPLOM) for optimization visualization.

Provides interactive scatter matrix showing all pairwise relationships
between variables with:
- Brushing and linking across all subplots
- Distribution plots on diagonal
- Feasibility highlighting
- Result set coloring
- Correlation analysis
"""

from __future__ import annotations

import numpy as np
import pandas as pd
import plotly.colors as pc
import plotly.graph_objects as go
from plotly.subplots import make_subplots

from ..core.data_model import OptimizationResult


def plot_scatter_matrix(
    result: OptimizationResult,
    variables: list[str] | None = None,
    include_objectives: bool = True,
    include_design_vars: bool = True,
    max_vars: int = 8,
    color_by: str | None = None,
    result_sets: list[str] | None = None,
    highlight_feasible: bool = False,
    show_distributions: bool = True,
    show_correlations: bool = True,
    constraint_tolerance: float = 1e-6,
    marker_size: int = 4,
    width: int = 1000,
    height: int = 1000,
    title: str | None = None,
) -> go.Figure:
    """
    Create an interactive scatter plot matrix (SPLOM).

    Args:
        result: OptimizationResult object
        variables: Specific variable names to include (if None, auto-select)
        include_objectives: Include objectives in matrix
        include_design_vars: Include design variables in matrix
        max_vars: Maximum number of variables to include
        color_by: Variable name to color points by
        result_sets: List of result set names for coloring
        highlight_feasible: Color by feasibility
        show_distributions: Show histograms/KDE on diagonal
        show_correlations: Show correlation values in upper triangle
        constraint_tolerance: Tolerance for feasibility check
        marker_size: Size of markers
        width: Figure width in pixels
        height: Figure height in pixels
        title: Plot title

    Returns:
        Plotly Figure with interactive scatter matrix
    """
    # Select variables to include
    var_names, var_data = _select_variables(
        result, variables, include_objectives, include_design_vars, max_vars
    )

    if len(var_names) < 2:
        raise ValueError("Need at least 2 variables for scatter matrix")

    n_vars = len(var_names)

    # Prepare color data
    color_data, color_label, colorscale, colorbar_params = _prepare_color_data(
        result, color_by, result_sets, highlight_feasible, constraint_tolerance
    )

    # Create subplots
    fig = make_subplots(
        rows=n_vars,
        cols=n_vars,
        horizontal_spacing=0.02,
        vertical_spacing=0.02,
        # subplot_titles=var_names if n_vars <= 6 else None,
    )

    # Calculate correlations if requested
    correlations = None
    if show_correlations:
        correlations = pd.DataFrame(var_data, columns=var_names).corr()

    # Check size of data to plot to avoid performance issues
    max_points = 5000
    if var_data.shape[0] > max_points:
        # use scattergl for large datasets
        scatter_function = go.Scattergl
    else:
        scatter_function = go.Scatter

    # Add scatter plots and distributions
    for i in range(n_vars):
        for j in range(n_vars):
            row, col = i + 1, j + 1

            if i == j and show_distributions:
                # Diagonal: distribution plot
                _add_distribution_plot(
                    fig, var_data[:, i], var_names[i], color_data, colorscale, row, col
                )
            elif i < j and show_correlations:
                # Upper triangle: correlation values
                corr_val = correlations.iloc[i, j] if correlations is not None else 0.0
                _add_correlation_subplot(fig, corr_val, row, col)
            else:
                # Lower triangle and (if no correlation) upper: scatter plots
                if not (i < j and show_correlations):
                    # Prepare marker dict
                    marker_dict = dict(
                        size=marker_size,
                        color=color_data,
                        colorscale=colorscale,
                        showscale=(i == 0 and j == n_vars - 1),
                        opacity=0.6,
                    )

                    # Add colorbar config if this is the plot showing the scale
                    if i == 0 and j == n_vars - 1:
                        cbar = dict(title=color_label, x=1.02, len=0.3, y=0.85)
                        if colorbar_params:
                            cbar.update(colorbar_params)
                        marker_dict["colorbar"] = cbar

                    fig.add_trace(
                        scatter_function(
                            x=var_data[:, j],
                            y=var_data[:, i],
                            mode="markers",
                            marker=marker_dict,
                            showlegend=False,
                            hovertemplate=(
                                f"<b>{var_names[j]}</b>: %{{x:.4f}}<br>"
                                f"<b>{var_names[i]}</b>: %{{y:.4f}}<br>"
                                "<extra></extra>"
                            ),
                        ),
                        row=row,
                        col=col,
                    )

            # Update axes
            fig.update_xaxes(
                title_text=var_names[j] if i == n_vars - 1 else "",
                showticklabels=(i == n_vars - 1),
                showgrid=True,
                gridcolor="lightgray",
                row=row,
                col=col,
            )
            fig.update_yaxes(
                title_text=var_names[i] if j == 0 else "",
                showticklabels=(j == 0),
                showgrid=True,
                gridcolor="lightgray",
                row=row,
                col=col,
            )

    # Update layout
    title_text = title or f"Scatter Matrix: {result.problem_metadata.name}"

    fig.update_layout(
        title=dict(text=title_text, x=0.5, xanchor="center"),
        width=width,
        height=height,
        hovermode="closest",
        showlegend=False,
        plot_bgcolor="white",
    )

    return fig


def _select_variables(
    result: OptimizationResult,
    variables: list[str] | None,
    include_objectives: bool,
    include_design_vars: bool,
    max_vars: int,
) -> tuple[list[str], np.ndarray]:
    """Select variables to include in scatter matrix."""
    if variables:
        # Use specified variables
        var_names = []
        var_data_list = []

        for var in variables:
            if not result.objectives.empty and var in result.objectives.columns:
                var_names.append(var)
                var_data_list.append(result.objectives[var].values)
            elif not result.design_variables.empty and var in result.design_variables.columns:
                var_names.append(var)
                var_data_list.append(result.design_variables[var].values)
            elif not result.observables.empty and var in result.observables.columns:
                var_names.append(var)
                var_data_list.append(result.observables[var].values)

        var_data = np.column_stack(var_data_list) if var_data_list else np.array([])
    else:
        # Auto-select variables
        var_names = []
        var_data_list = []

        # Add objectives first (prioritize)
        if include_objectives and not result.objectives.empty:
            for col in result.objectives.columns[:max_vars]:
                var_names.append(col)
                var_data_list.append(result.objectives[col].values)

        # Add design variables
        if include_design_vars and not result.design_variables.empty:
            remaining = max_vars - len(var_names)
            for col in result.design_variables.columns[:remaining]:
                var_names.append(col)
                var_data_list.append(result.design_variables[col].values)

        var_data = np.column_stack(var_data_list) if var_data_list else np.array([])

    return var_names, var_data


def _prepare_color_data(
    result: OptimizationResult,
    color_by: str | None,
    result_sets: list[str] | None,
    highlight_feasible: bool,
    constraint_tolerance: float,
) -> tuple[np.ndarray | str | None, str, str | list, dict | None]:
    """Prepare color data for scatter matrix."""
    n_points = result.n_points
    colorbar_params = None

    if result_sets and len(result_sets) > 0:
        # Color by result sets
        color_data = np.zeros(n_points)
        for i, set_name in enumerate(result_sets, start=1):
            if set_name in result.sets:
                result_set = result.get_set(set_name)
                color_data[result_set.indices] = i
        color_label = "Set"
        colorscale = "Viridis"
    elif highlight_feasible:
        # Color by feasibility
        feasible = np.ones(n_points, dtype=bool)

        if not result.inequality_constraints.empty:
            ineq_violations = (result.inequality_constraints.values > constraint_tolerance).any(
                axis=1
            )
            feasible &= ~ineq_violations

        if not result.equality_constraints.empty:
            eq_violations = (np.abs(result.equality_constraints.values) > constraint_tolerance).any(
                axis=1
            )
            feasible &= ~eq_violations

        color_data = feasible.astype(float)
        color_label = "Feasible"
        colorscale = [[0, "#EF553B"], [1, "#00CC96"]]  # Red to Green
        colorbar_params = dict(tickvals=[0, 1], ticktext=["Infeasible", "Feasible"])
    elif color_by:
        # Color by specific variable
        raw_data = None
        if not result.objectives.empty and color_by in result.objectives.columns:
            raw_data = result.objectives[color_by].values
        elif not result.design_variables.empty and color_by in result.design_variables.columns:
            raw_data = result.design_variables[color_by].values
        elif not result.observables.empty and color_by in result.observables.columns:
            raw_data = result.observables[color_by].values

        if raw_data is not None:
            # Check if categorical
            if pd.api.types.is_string_dtype(raw_data) or pd.api.types.is_object_dtype(raw_data):
                # Map categorical to integer
                unique_vals = np.unique(raw_data)
                val_map = {val: i for i, val in enumerate(unique_vals)}

                # Create discrete colorscale
                # import plotly.colors as pc

                # Use a qualitative palette (e.g., Plotly)
                palette = pc.qualitative.Plotly
                # Repeat palette if not enough colors
                while len(palette) < len(unique_vals):
                    palette += palette

                n_cats = len(unique_vals)
                colorscale_discrete = []
                for i in range(n_cats):
                    colorscale_discrete.append([i / n_cats, palette[i]])
                    colorscale_discrete.append([(i + 1) / n_cats, palette[i]])

                colorscale = colorscale_discrete

                # Map data to centers of the bins
                color_data = np.array([val_map[val] for val in raw_data]) + 0.5

                colorbar_params = dict(
                    tickvals=[i + 0.5 for i in range(n_cats)],
                    ticktext=list(unique_vals),
                    tickmode="array",
                    cmin=0,
                    cmax=n_cats,
                )

            else:
                color_data = raw_data
                colorscale = "Viridis"
        else:
            color_data = np.arange(n_points)
            colorscale = "Viridis"

        color_label = color_by
    else:
        # Default: color by index
        color_data = None  # np.arange(n_points)
        color_label = "Index"
        colorscale = "Viridis"

    return color_data, color_label, colorscale, colorbar_params


def _add_distribution_plot(
    fig: go.Figure,
    data: np.ndarray,
    var_name: str,
    color_data: np.ndarray,
    colorscale: str | list,
    row: int,
    col: int,
) -> None:
    """Add distribution plot (histogram) to diagonal."""
    # Create histogram
    fig.add_trace(
        go.Histogram(
            x=data,
            marker=dict(color="#636EFA", opacity=0.7, line=dict(color="white", width=1)),
            showlegend=False,
            hovertemplate="<b>Range</b>: %{x}<br><b>Count</b>: %{y}<extra></extra>",
        ),
        row=row,
        col=col,
    )


def _add_correlation_subplot(fig: go.Figure, corr_val: float, row: int, col: int) -> None:
    """Add correlation bubble subplot to upper triangle."""
    # Determine color based on correlation strength
    if abs(corr_val) > 0.7:
        color = "#EF553B" if corr_val > 0 else "#636EFA"
    elif abs(corr_val) > 0.4:
        color = "#FFA15A" if corr_val > 0 else "#19D3F3"
    else:
        color = "lightgray"

    # Size proportional to correlation strength
    # Min size 10, max size 40
    size = 10 + 30 * abs(corr_val)

    fig.add_trace(
        go.Scatter(
            x=[0.5],
            y=[0.5],
            mode="markers+text",
            marker=dict(size=size, color=color, line=dict(width=1, color="white")),
            text=[f"{corr_val:.2f}"],
            textfont=dict(size=12, color="black" if abs(corr_val) < 0.5 else "white"),
            hoverinfo="text",
            hovertext=f"Correlation: {corr_val:.3f}",
            showlegend=False,
        ),
        row=row,
        col=col,
    )

    # Hide axes for correlation cells
    fig.update_xaxes(showticklabels=False, showgrid=False, range=[0, 1], row=row, col=col)
    fig.update_yaxes(showticklabels=False, showgrid=False, range=[0, 1], row=row, col=col)


def plot_correlation_heatmap(
    result: OptimizationResult,
    variables: list[str] | None = None,
    include_objectives: bool = True,
    include_design_vars: bool = True,
    include_observables: bool = False,
    method: str = "pearson",
    width: int = 800,
    height: int = 700,
    title: str | None = None,
) -> go.Figure:
    """
    Create correlation heatmap for optimization variables.

    Args:
        result: OptimizationResult object
        variables: Specific variables to include
        include_objectives: Include objectives
        include_design_vars: Include design variables
        include_observables: Include observables
        method: Correlation method ('pearson', 'spearman', 'kendall')
        width: Figure width
        height: Figure height
        title: Plot title

    Returns:
        Plotly Figure with correlation heatmap
    """
    # Collect data
    data_dict = {}

    if variables:
        for var in variables:
            if not result.objectives.empty and var in result.objectives.columns:
                data_dict[var] = result.objectives[var].values
            elif not result.design_variables.empty and var in result.design_variables.columns:
                data_dict[var] = result.design_variables[var].values
            elif not result.observables.empty and var in result.observables.columns:
                data_dict[var] = result.observables[var].values
    else:
        if include_objectives and not result.objectives.empty:
            for col in result.objectives.columns:
                data_dict[col] = result.objectives[col].values

        if include_design_vars and not result.design_variables.empty:
            for col in result.design_variables.columns:
                data_dict[col] = result.design_variables[col].values

        if include_observables and not result.observables.empty:
            for col in result.observables.columns:
                data_dict[col] = result.observables[col].values

    if not data_dict:
        raise ValueError("No variables selected for correlation analysis")

    # Create DataFrame and calculate correlation
    df = pd.DataFrame(data_dict)

    if method == "pearson":
        corr_matrix = df.corr(method="pearson")
    elif method == "spearman":
        corr_matrix = df.corr(method="spearman")
    elif method == "kendall":
        corr_matrix = df.corr(method="kendall")
    else:
        raise ValueError(f"Unknown correlation method: {method}")

    # Create heatmap
    fig = go.Figure(
        data=go.Heatmap(
            z=corr_matrix.values,
            x=corr_matrix.columns,
            y=corr_matrix.index,
            colorscale="RdBu",
            zmid=0,
            zmin=-1,
            zmax=1,
            text=np.around(corr_matrix.values, decimals=2),
            texttemplate="%{text}",
            textfont={"size": 10},
            colorbar=dict(title="Correlation"),
            hovertemplate="<b>%{x}</b> vs <b>%{y}</b><br>Correlation: %{z:.3f}<extra></extra>",
        )
    )

    # Update layout
    title_text = (
        title or f"Correlation Matrix ({method.capitalize()}): {result.problem_metadata.name}"
    )

    fig.update_layout(
        title=title_text,
        xaxis=dict(side="bottom", tickangle=-45),
        yaxis=dict(side="left"),
        width=width,
        height=height,
        template="plotly_white",
    )

    return fig
