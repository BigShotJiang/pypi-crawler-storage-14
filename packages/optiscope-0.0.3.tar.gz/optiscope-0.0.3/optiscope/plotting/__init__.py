"""
Plotting utilities for optimization visualization.

This package provides advanced, reusable plotting functions that go beyond
simple Plotly wrappers. All functions return Plotly Figure objects that can
be used in standalone scripts or integrated into Dash applications.

Features:
- Interactive Pareto front viewers (2D and 3D)
- Advanced parallel coordinates with feasibility highlighting
- Scatter plot matrices (SPLOM) with brushing and linking
- Correlation analysis and heatmaps
- Multi-result comparisons
- Customizable styling and interactivity
"""

from .parallel_coordinates import (
    plot_parallel_coordinates,
)
from .pareto_viewer import (
    plot_pareto_front_2d,
    plot_pareto_front_3d,
)
from .scatter_matrix import (
    plot_correlation_heatmap,
    plot_scatter_matrix,
)
from .theme import apply_theme
from .utils import create_combined_legend

__all__ = [
    # Pareto front visualization
    "plot_pareto_front_2d",
    "plot_pareto_front_3d",
    # Parallel coordinates
    "plot_parallel_coordinates",
    # Scatter matrix
    "plot_scatter_matrix",
    "plot_correlation_heatmap",
    # Utils
    "create_combined_legend",
    # Theme
    "apply_theme",
]
