from __future__ import annotations

import numpy as np
import pandas as pd
import plotly.graph_objects as go

from optiscope.core.data_model import OptimizationResult
from optiscope.core.data_types import OptimizationDirection


def plot_parallel_coordinates(
    results: OptimizationResult | list[OptimizationResult] | dict[str, OptimizationResult],
    selected_columns: list[str] | None = None,
    include_design_vars: bool = True,
    include_objectives: bool = True,
    include_constraints: bool = False,
    include_observables: bool = False,
    include_sets_as_dimensions: bool | list[str] = False,
    result_sets: list[str] | None = None,
    highlight_feasible: bool = False,
    constraint_tolerance: float = 1e-6,
    colorscale: str = "Viridis",
    color_by: str | None = None,
    width: int = 1200,
    height: int = 700,
    title: str | None = None,
    theme: str | None = "plotly_white",
    vertical: bool = False,
) -> go.Figure:
    """
    Create a parallel coordinates plot from optimization results.

    This unified function handles three use cases:
    1. Single result with auto-selected columns (original plot_parallel_coordinates)
    2. Multiple results with manual column selection (original plot_parallel_coordinates_from_results)
    3. Multiple results comparison with common columns (original plot_parallel_coordinates_comparison)

    Args:
        results: Single OptimizationResult, list of results, or dict mapping names to results
        selected_columns: Specific columns to plot (overrides include_* flags if provided)
        include_design_vars: Include design variables as axes
        include_objectives: Include objectives as axes
        include_constraints: Include constraints as axes
        include_observables: Include observables as axes
        include_sets_as_dimensions: Include specific sets (or all if True) as boolean axes
        result_sets: list of result set names to highlight with different colors
        highlight_feasible: Color feasible vs infeasible solutions differently
        constraint_tolerance: Tolerance for constraint violations
        colorscale: Plotly colorscale name
        color_by: Column name or "_result" to color lines by
        width: Figure width
        height: Figure height
        title: Plot title
        theme: Plotly theme to apply
        vertical: If True, rotate plot to vertical orientation

    Returns:
        Plotly Figure object
    """
    # Normalize inputs to list of (name, result) tuples
    if isinstance(results, OptimizationResult):
        results_list = [(results.problem_metadata.name, results)]
        is_comparison = False
    elif isinstance(results, dict):
        results_list = list(results.items())
        is_comparison = True
    elif isinstance(results, list):
        results_list = [(r.problem_metadata.name, r) for r in results]
        is_comparison = False
    else:
        raise ValueError("results must be OptimizationResult, list, or dict")

    if not results_list:
        return _create_error_figure("No results provided.")

    # Build dimensions based on mode
    if selected_columns:
        # Mode: Manual column selection (from_results style)
        dimensions, combined_df, result_keys = _build_dimensions_from_columns(
            results_list, selected_columns, include_sets_as_dimensions
        )
        if dimensions is None:
            return combined_df  # Actually an error figure in this case
    elif is_comparison:
        # Mode: Comparison with common columns
        dimensions, data_per_result = _build_comparison_dimensions(
            results_list, include_design_vars, include_objectives
        )
        if dimensions is None:
            return _create_error_figure("No common columns found across results")
        combined_df = None
    else:
        # Mode: Single result with auto-selected columns
        dimensions, data_dict = _build_dimensions_from_flags(
            results_list[0][1],
            include_design_vars,
            include_objectives,
            include_constraints,
            include_observables,
            include_sets_as_dimensions,
        )
        if not dimensions:
            return _create_error_figure("No data selected for parallel coordinates plot")
        combined_df = None

    # Create figure
    if is_comparison:
        fig = _create_comparison_traces(results_list, dimensions, data_per_result, vertical)
    else:
        # Determine coloring
        if selected_columns and combined_df is not None:
            line_dict = _get_color_dict_from_combined(
                combined_df, color_by, results_list, colorscale, vertical
            )
        else:
            result = results_list[0][1]
            line_dict = _get_color_dict_single(
                result,
                result_sets,
                highlight_feasible,
                constraint_tolerance,
                color_by,
                data_dict,
                colorscale,
                vertical,
            )

        # Add labelangle for vertical orientation
        parcoords_kwargs = {"line": line_dict, "dimensions": dimensions}
        if vertical:
            parcoords_kwargs["labelangle"] = -90

        fig = go.Figure(data=go.Parcoords(**parcoords_kwargs))

    # Set title
    if title:
        title_text = title
    elif is_comparison:
        title_text = "Parallel Coordinates Comparison"
    elif selected_columns:
        result_names = [name for name, _ in results_list]
        if len(result_names) > 1:
            title_text = f"Parallel Coordinates Plot (Results: {', '.join(result_names)})"
        else:
            title_text = "Parallel Coordinates Plot"
    else:
        title_text = f"Parallel Coordinates: {results_list[0][0]}"

    # Adjust margins for vertical orientation
    if vertical:
        margin_dict = dict(l=150, r=150, t=80, b=150)
    else:
        margin_dict = dict(l=100, r=100 if is_comparison else 50, t=80, b=50)

    # Update layout
    fig.update_layout(
        title=title_text,
        width=width,
        height=height,
        font=dict(size=11),
        margin=margin_dict,
        template=theme,
        showlegend=is_comparison,
    )

    return fig


def _create_error_figure(message: str) -> go.Figure:
    """Create a figure displaying an error message."""
    fig = go.Figure()
    fig.add_annotation(
        text=message,
        xref="paper",
        yref="paper",
        x=0.5,
        y=0.5,
        showarrow=False,
    )
    return fig


def _build_dimensions_from_columns(
    results_list: list[tuple[str, OptimizationResult]],
    selected_columns: list[str],
    include_sets_as_dimensions: bool | list[str] = False,
) -> tuple[list[dict] | None, pd.DataFrame | go.Figure, list[str]]:
    """Build dimensions from manually selected columns across multiple results."""
    # Check if we have enough columns initially only if not including sets
    if len(selected_columns) < 2 and not include_sets_as_dimensions:
        return None, _create_error_figure("Please select at least 2 columns."), []

    all_data = []
    result_keys = []

    for idx, (name, result) in enumerate(results_list):
        result_keys.append(name)
        df = result.get_all_data()
        available_columns = [col for col in selected_columns if col in df.columns]

        # If we are strictly relying on selected columns and none are found, skip
        # But if we are including sets, we might still want to process this result
        if not available_columns and not include_sets_as_dimensions:
            continue

        # Start with available columns or empty if none found (but sets might be added)
        if available_columns:
            df = df[available_columns].copy()
        else:
            # Create empty dataframe with correct index length if we are only adding sets
            df = pd.DataFrame(index=range(result.n_points))

        # Add sets as columns
        if include_sets_as_dimensions:
            sets_to_include = []
            if isinstance(include_sets_as_dimensions, bool):
                if include_sets_as_dimensions:
                    sets_to_include = result.list_sets()
            else:
                sets_to_include = include_sets_as_dimensions

            for set_name in sets_to_include:
                # Only add if set exists in this result
                if set_name in result.sets:
                    result_set = result.get_set(set_name)
                    values = np.zeros(result.n_points, dtype=int)
                    values[result_set.indices] = 1
                    df[set_name] = values
                # If set doesn't exist, we don't add it here.
                # pd.concat will create NaN columns for missing sets in other results.

        # If after checking columns and sets we still have no data columns (excluding metadata), skip
        if df.empty and not include_sets_as_dimensions:
            continue

        df["_result"] = name
        df["_color_idx"] = idx
        all_data.append(df)

    if not all_data:
        return None, _create_error_figure("No data available for the selected columns."), []

    combined_df = pd.concat(all_data, ignore_index=True)

    # Post-process set columns to ensure they are boolean/categorical
    # Identify all potential set columns
    all_set_names = set()
    if include_sets_as_dimensions:
        if isinstance(include_sets_as_dimensions, list):
            all_set_names.update(include_sets_as_dimensions)
        else:
            # If bool=True, we need to collect all sets found across results
            for _, result in results_list:
                all_set_names.update(result.list_sets())

    # Ensure set columns are boolean (filling NaNs with False/0)
    for col in all_set_names:
        if col in combined_df.columns:
            combined_df[col] = combined_df[col].fillna(0).astype(bool)

    plot_columns = [col for col in combined_df.columns if not col.startswith("_")]

    dimensions = []
    for col in plot_columns:
        dim = {"label": col}
        if combined_df[col].dtype == "object" or combined_df[col].dtype == "bool":
            if combined_df[col].dtype == "bool":
                unique_vals = [False, True]
                cat_values = combined_df[col].astype(int)
                tickvals = [0, 1]
                ticktext = [str(v) for v in unique_vals]
            else:
                unique_vals = combined_df[col].unique()
                cat_map = {val: i for i, val in enumerate(unique_vals)}
                cat_values = combined_df[col].map(cat_map)
                tickvals = list(range(len(unique_vals)))
                ticktext = [str(v) for v in unique_vals]
            dim.update({"values": cat_values, "tickvals": tickvals, "ticktext": ticktext})
        else:
            dim["values"] = combined_df[col]
        dimensions.append(dim)

    if len(dimensions) < 2:
        return None, _create_error_figure("Not enough dimensions to plot (need at least 2)."), []

    return dimensions, combined_df, result_keys


def _build_dimensions_from_flags(
    result: OptimizationResult,
    include_design_vars: bool,
    include_objectives: bool,
    include_constraints: bool,
    include_observables: bool,
    include_sets_as_dimensions: bool | list[str] = False,
) -> tuple[list[dict], dict[str, np.ndarray]]:
    """Build dimensions based on include flags for a single result."""
    from ..core.data_model import Objective as ObjectiveClass

    dimensions = []
    data_dict = {}

    # Add design variables
    if include_design_vars and not result.design_variables.empty:
        for col in result.design_variables.columns:
            meta = result.get_variable_metadata(col)
            label = col
            if meta and meta.units:
                label = f"{col} ({meta.units})"

            dimensions.append(
                {
                    "label": label,
                    "values": result.design_variables[col].to_numpy(),
                    "range": [
                        meta.lower_bound
                        if meta and meta.lower_bound is not None
                        else result.design_variables[col].min(),
                        meta.upper_bound
                        if meta and meta.upper_bound is not None
                        else result.design_variables[col].max(),
                    ],
                }
            )
            data_dict[col] = result.design_variables[col].to_numpy()

    # Add objectives
    if include_objectives and not result.objectives.empty:
        for col in result.objectives.columns:
            meta = result.get_variable_metadata(col)
            label = col

            if meta and isinstance(meta, ObjectiveClass):
                direction = "↓" if meta.direction == OptimizationDirection.MINIMIZE else "↑"
                label = f"{col} {direction}"
                if meta.units:
                    label = f"{col} {direction} ({meta.units})"

            dimensions.append({"label": label, "values": result.objectives[col].to_numpy()})
            data_dict[col] = result.objectives[col].to_numpy()

    # Add constraints
    if include_constraints:
        if not result.inequality_constraints.empty:
            for col in result.inequality_constraints.columns:
                meta = result.get_variable_metadata(col)
                label = f"{col} (≤0)"
                if meta and meta.units:
                    label = f"{col} (≤0) ({meta.units})"

                dimensions.append(
                    {
                        "label": label,
                        "values": result.inequality_constraints[col].to_numpy(),
                    }
                )
                data_dict[col] = result.inequality_constraints[col].to_numpy()

        if not result.equality_constraints.empty:
            for col in result.equality_constraints.columns:
                meta = result.get_variable_metadata(col)
                label = f"{col} (=0)"
                if meta and meta.units:
                    label = f"{col} (=0) ({meta.units})"

                dimensions.append(
                    {
                        "label": label,
                        "values": result.equality_constraints[col].to_numpy(),
                    }
                )
                data_dict[col] = result.equality_constraints[col].to_numpy()

    # Add observables
    if include_observables and not result.observables.empty:
        for col in result.observables.columns:
            meta = result.get_variable_metadata(col)
            label = col
            if meta and meta.units:
                label = f"{col} ({meta.units})"

            dimensions.append({"label": label, "values": result.observables[col].to_numpy()})
            data_dict[col] = result.observables[col].to_numpy()

    # Add sets as dimensions
    if include_sets_as_dimensions:
        sets_to_include = []
        if isinstance(include_sets_as_dimensions, bool):
            if include_sets_as_dimensions:
                sets_to_include = result.list_sets()
                print(f"SETS TO INCLUDE: {sets_to_include}")
        else:
            sets_to_include = include_sets_as_dimensions

        for set_name in sets_to_include:
            if set_name in result.sets:
                result_set = result.get_set(set_name)
                # Create boolean array (0/1)
                values = np.zeros(result.n_points, dtype=int)
                values[result_set.indices] = 1

                dimensions.append(
                    {
                        "label": set_name,
                        "values": values,
                        "tickvals": [0, 1],
                        "ticktext": ["False", "True"],
                    }
                )
                data_dict[set_name] = values

    return dimensions, data_dict


def _build_comparison_dimensions(
    results_list: list[tuple[str, OptimizationResult]],
    include_design_vars: bool,
    include_objectives: bool,
) -> tuple[list[dict] | None, dict[str, dict[str, np.ndarray]]]:
    """Build dimensions for comparison mode with common columns."""
    # Find common columns
    common_cols = None
    for name, result in results_list:
        result_cols = set()

        if include_design_vars and not result.design_variables.empty:
            for col in result.design_variables.columns:
                result_cols.add((col, "design_var"))

        if include_objectives and not result.objectives.empty:
            for col in result.objectives.columns:
                result_cols.add((col, "objective"))

        if common_cols is None:
            common_cols = result_cols
        else:
            common_cols &= result_cols

    if not common_cols:
        return None, {}

    common_cols = sorted(list(common_cols))

    # Build dimensions with ranges across all results
    dimensions = []
    data_per_result = {}

    for col, category in common_cols:
        all_values = []
        for name, result in results_list:
            if category == "design_var":
                values = result.design_variables[col].to_numpy()
            else:  # objective
                values = result.objectives[col].to_numpy()
            all_values.extend(values)

            if name not in data_per_result:
                data_per_result[name] = {}
            data_per_result[name][col] = values

        dimensions.append(
            {
                "label": col,
                "range": [min(all_values), max(all_values)],
            }
        )

    return dimensions, data_per_result


def _create_comparison_traces(
    results_list: list[tuple[str, OptimizationResult]],
    dimensions: list[dict],
    data_per_result: dict[str, dict[str, np.ndarray]],
    vertical: bool = False,
) -> go.Figure:
    """Create figure with separate traces for each result."""
    colors = [
        "#636EFA",
        "#EF553B",
        "#00CC96",
        "#AB63FA",
        "#FFA15A",
        "#19D3F3",
        "#FF6692",
        "#B6E880",
        "#FF97FF",
        "#FECB52",
    ]

    fig = go.Figure()

    for idx, (name, result) in enumerate(results_list):
        trace_dimensions = [
            {"label": dim["label"], "values": data_per_result[name][dim["label"]]}
            for dim in dimensions
        ]

        color_idx = idx % len(colors)

        parcoords_kwargs = {
            "line": dict(color=colors[color_idx]),
            "dimensions": trace_dimensions,
            "name": name,
        }

        if vertical:
            parcoords_kwargs["labelangle"] = -90

        trace = go.Parcoords(**parcoords_kwargs)
        fig.add_trace(trace)

    return fig


def _get_color_dict_from_combined(
    combined_df: pd.DataFrame,
    color_by: str | None,
    results_list: list[tuple[str, OptimizationResult]],
    colorscale: str,
    vertical: bool = False,
) -> dict:
    """Get line coloring dict for combined dataframe mode."""
    if color_by == "_result":
        result_keys = [name for name, _ in results_list]
        colorscale_list = [
            [0.0, "#1f77b4"],
            [0.25, "#ff7f0e"],
            [0.5, "#2ca02c"],
            [0.75, "#d62728"],
            [1.0, "#9467bd"],
        ]
        colorbar_dict = dict(
            title="Result",
            tickvals=list(range(len(results_list))),
            ticktext=result_keys,
        )
        return dict(
            color=combined_df["_color_idx"],
            colorscale=colorscale_list,
            showscale=True,
            cmin=0,
            cmax=len(results_list) - 1,
            colorbar=colorbar_dict,
        )
    elif color_by and color_by in combined_df.columns:
        return dict(
            color=combined_df[color_by],
            colorscale=colorscale,
            showscale=True,
            colorbar=dict(title=color_by),
        )
    else:
        return dict(color="steelblue")


def _get_color_dict_single(
    result: OptimizationResult,
    result_sets: list[str] | None,
    highlight_feasible: bool,
    constraint_tolerance: float,
    color_by: str | None,
    data_dict: dict[str, np.ndarray],
    colorscale: str,
    vertical: bool = False,
) -> dict:
    """Get line coloring dict for single result mode."""
    if result_sets and len(result_sets) > 0:
        color_values, colorbar = _get_set_colors(result, result_sets)
    elif highlight_feasible:
        color_values, colorbar = _get_feasibility_colors(result, constraint_tolerance)
    elif color_by and color_by in data_dict:
        color_values = data_dict[color_by]
        colorbar = {"title": color_by}
    elif not result.objectives.empty:
        first_obj = result.objectives.columns[0]
        color_values = result.objectives[first_obj].to_numpy()
        colorbar = {"title": first_obj}
    else:
        color_values = np.zeros(result.n_points)
        colorbar = None

    return dict(
        color=color_values,
        colorscale=colorscale,
        showscale=colorbar is not None,
        colorbar=colorbar,
    )


def _get_feasibility_colors(
    result: OptimizationResult,
    tolerance: float = 1e-6,
) -> tuple[np.ndarray, dict]:
    """Calculate feasibility-based colors."""
    n_points = result.n_points
    feasible = np.ones(n_points, dtype=bool)

    if not result.inequality_constraints.empty:
        ineq_violations = (result.inequality_constraints.to_numpy() > tolerance).any(axis=1)
        feasible &= ~ineq_violations

    if not result.equality_constraints.empty:
        eq_violations = (np.abs(result.equality_constraints.to_numpy()) > tolerance).any(axis=1)
        feasible &= ~eq_violations

    color_values = feasible.astype(float)
    colorbar = {
        "title": "Feasibility",
        "tickmode": "array",
        "tickvals": [0.25, 0.75],
        "ticktext": ["Infeasible", "Feasible"],
    }

    return color_values, colorbar


def _get_set_colors(
    result: OptimizationResult,
    set_names: list[str],
) -> tuple[np.ndarray, dict]:
    """Calculate colors based on result set membership."""
    n_points = result.n_points
    color_values = np.zeros(n_points)

    for i, set_name in enumerate(set_names, start=1):
        if set_name in result.sets:
            result_set = result.get_set(set_name)
            color_values[result_set.indices] = i

    colorbar = {
        "title": "Set",
        "tickmode": "array",
        "tickvals": list(range(len(set_names) + 1)),
        "ticktext": ["None"] + set_names,
    }

    return color_values, colorbar
