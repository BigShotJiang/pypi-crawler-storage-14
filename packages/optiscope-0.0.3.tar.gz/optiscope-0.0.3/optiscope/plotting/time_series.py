"""Time series plotting functions for optimization history."""

from __future__ import annotations

import numpy as np
import plotly.graph_objects as go
from plotly.subplots import make_subplots

from optiscope.core.data_model import OptimizationResult
from optiscope.core.data_types import Constraint, ConstraintType

try:
    from plotly_resampler import FigureResampler
    from plotly_resampler.aggregation import MinMaxLTTB

    RESAMPLER_AVAILABLE = True
except ImportError:
    RESAMPLER_AVAILABLE = False
    FigureResampler = None
    MinMaxLTTB = None


def plot_time_series(
    result: OptimizationResult,
    columns: list[str],
    data_attr: str,
    title: str = "Time Series",
    show_markers: bool = True,
    line_width: int = 2,
    marker_size: int = 4,
    show_feasibility: bool = True,
    single_plot: bool = False,
) -> go.Figure:
    """
    Create a time series plot for selected columns from an OptimizationResult.

    Each selected column is displayed in its own subplot, with iterations on the x-axis
    and the column values on the y-axis.

    Args:
        result: OptimizationResult object containing the data
        columns: List of column names to plot
        data_attr: Attribute name on result object (e.g., 'design_variables', 'objectives')
        title: Overall plot title
        show_markers: Whether to show markers on the line plot
        line_width: Width of the lines
        marker_size: Size of the markers
        single_plot: If True, all columns are plotted in a single subplot with a legend.
                     Otherwise, a subplot is created for each column.
    Returns:
        Plotly figure object with subplots for each column

    Example:
        >>> from optiscope.plotting.time_series import plot_time_series
        >>> fig = plot_time_series(
        ...     result,
        ...     columns=['x1', 'x2'],
        ...     data_attr='design_variables',
        ...     title='Design Variables Evolution'
        ... )
        >>> fig.show()
    """
    if not columns or len(columns) == 0:
        fig = go.Figure()
        fig.add_annotation(
            text=f"No columns selected for {title}",
            xref="paper",
            yref="paper",
            x=0.5,
            y=0.5,
            showarrow=False,
            font=dict(size=14),
        )
        fig.update_layout(
            title=title,
            height=400,
            margin=dict(l=10, r=10, t=40, b=10),
        )
        return fig

    # Get the data frame
    df = getattr(result, data_attr, None)
    if df is None or df.empty:
        fig = go.Figure()
        fig.add_annotation(
            text=f"No data available for {data_attr}",
            xref="paper",
            yref="paper",
            x=0.5,
            y=0.5,
            showarrow=False,
            font=dict(size=14),
        )
        fig.update_layout(
            title=title,
            height=400,
            margin=dict(l=10, r=10, t=40, b=10),
        )
        return fig

    # Filter to only columns that exist
    valid_columns = [col for col in columns if col in df.columns]
    if not valid_columns:
        fig = go.Figure()
        fig.add_annotation(
            text=f"Selected columns not found in {data_attr}",
            xref="paper",
            yref="paper",
            x=0.5,
            y=0.5,
            showarrow=False,
            font=dict(size=14),
        )
        fig.update_layout(
            title=title,
            height=400,
            margin=dict(l=10, r=10, t=40, b=10),
        )
        return fig

    # Create subplots
    num_plots = 1 if single_plot else len(valid_columns)
    subplot_titles = None if single_plot else [f"{col}" for col in valid_columns]

    fig = make_subplots(
        rows=num_plots,
        cols=1,
        subplot_titles=subplot_titles,
        vertical_spacing=0.08,
    )

    # Add traces for each selected column
    mode = "lines+markers" if show_markers else "lines"
    for i, col in enumerate(valid_columns, start=1):
        fig.add_trace(
            go.Scatter(
                x=np.arange(len(df)),
                y=df[col],
                mode=mode,
                name=col,
                line=dict(width=line_width),
                marker=dict(size=marker_size) if show_markers else None,
                showlegend=single_plot,  # Show legend only if all in one plot
            ),
            row=1 if single_plot else i,
            col=1,
        )

        # Update y-axis label for this subplot
        if not single_plot:
            fig.update_yaxes(title_text=col, row=i, col=1)
        elif i == 1:  # For single plot, set a generic y-axis title once
            fig.update_yaxes(title_text="Value", row=1, col=1)

    # Update x-axis label for bottom subplot
    fig.update_xaxes(title_text="Iteration", row=num_plots, col=1)

    # Update overall layout
    fig.update_layout(
        title_text=title,
        height=max(400, 250 * num_plots),
        showlegend=single_plot,  # Show legend for the overall plot if single_plot is True
        margin=dict(l=10, r=10, t=60, b=10),
    )

    # Add grid lines
    fig.update_xaxes(showgrid=True, gridwidth=1, gridcolor="lightgray")
    fig.update_yaxes(showgrid=True, gridwidth=1, gridcolor="lightgray")

    return fig


def plot_constraints_time_series(
    result: OptimizationResult,
    columns: list[str],
    title: str = "Constraints",
    show_markers: bool = True,
    line_width: int = 2,
    marker_size: int = 4,
    show_feasibility: bool = True,
) -> go.Figure:
    """
    Create a time series plot for constraints (handles both inequality and equality).

    This function specifically handles constraints by checking both inequality_constraints
    and equality_constraints dataframes. It can also optionally show feasible regions.

    Args:
        result: OptimizationResult object containing the data
        columns: List of constraint column names to plot
        title: Overall plot title
        show_markers: Whether to show markers on the line plot
        line_width: Width of the lines
        marker_size: Size of the markers
        show_feasibility: If True, feasible regions will be shaded.

    Returns:
        Plotly figure object with subplots for each constraint

    Example:
        >>> from optiscope.plotting.time_series import plot_constraints_time_series
        >>> fig = plot_constraints_time_series(
        ...     result,
        ...     columns=['c1', 'c2'],
        ...     title='Constraint Evolution',
        ...     show_feasibility=True
        ... )
        >>> fig.show()
    """
    if not columns or len(columns) == 0:
        fig = go.Figure()
        fig.add_annotation(
            text="No constraints selected",
            xref="paper",
            yref="paper",
            x=0.5,
            y=0.5,
            showarrow=False,
            font=dict(size=14),
        )
        fig.update_layout(
            title=title,
            height=400,
            margin=dict(l=10, r=10, t=40, b=10),
        )
        return fig

    # Get constraint dataframes
    ineq_df = result.inequality_constraints
    eq_df = result.equality_constraints

    # Check if we have any constraint data
    available_columns = []
    for col in columns:
        if col in ineq_df.columns or col in eq_df.columns:
            available_columns.append(col)

    if not available_columns:
        fig = go.Figure()
        fig.add_annotation(
            text="No constraint data available for selected columns",
            xref="paper",
            yref="paper",
            x=0.5,
            y=0.5,
            showarrow=False,
            font=dict(size=14),
        )
        fig.update_layout(
            title=title,
            height=400,
            margin=dict(l=10, r=10, t=40, b=10),
        )
        return fig

    # Create subplots - one for each selected column
    num_plots = len(available_columns)
    fig = make_subplots(
        rows=num_plots,
        cols=1,
        subplot_titles=[f"{col}" for col in available_columns],
        vertical_spacing=0.08,
    )

    # Add traces for each selected column
    mode = "lines+markers" if show_markers else "lines"
    for i, col in enumerate(available_columns, start=1):
        # Check which dataframe contains this column
        if col in ineq_df.columns:
            data = ineq_df[col]
        elif col in eq_df.columns:
            data = eq_df[col]
        else:
            continue

        fig.add_trace(
            go.Scatter(
                x=np.arange(len(data)),
                y=data,
                mode=mode,
                name=col,
                line=dict(width=line_width),
                marker=dict(size=marker_size) if show_markers else None,
                showlegend=False,
            ),
            row=i,
            col=1,
        )

        # Add feasibility lines if requested
        if show_feasibility:
            constraint_meta = result.get_variable_metadata(col)
            if isinstance(constraint_meta, Constraint):
                line_style = dict(color="red", width=1, dash="dash")

                if constraint_meta.constraint_type == ConstraintType.EQUALITY:
                    # Equality constraint: value = reference_value +/- tolerance
                    # Draw lines at reference_value - tolerance and reference_value + tolerance
                    fig.add_hline(
                        y=constraint_meta.reference_value - constraint_meta.tolerance,
                        line=line_style,
                        annotation_text="Lower Feasible Bound",
                        annotation_position="bottom right",
                        row=i,
                        col=1,
                    )
                    fig.add_hline(
                        y=constraint_meta.reference_value + constraint_meta.tolerance,
                        line=line_style,
                        annotation_text="Upper Feasible Bound",
                        annotation_position="top right",
                        row=i,
                        col=1,
                    )
                elif constraint_meta.constraint_type == ConstraintType.INEQUALITY:
                    # Inequality constraint: value <= reference_value + tolerance
                    # Draw line at reference_value + tolerance (upper limit of feasible region)
                    fig.add_hline(
                        y=constraint_meta.reference_value + constraint_meta.tolerance,
                        line=line_style,
                        annotation_text="Upper Feasible Bound",
                        annotation_position="top right",
                        row=i,
                        col=1,
                    )
                elif constraint_meta.constraint_type == ConstraintType.BOUND:
                    # Bound constraint: lower_bound <= value <= upper_bound
                    # Draw lines at lower_bound and upper_bound, considering tolerance
                    if constraint_meta.lower_bound is not None:
                        fig.add_hline(
                            y=constraint_meta.lower_bound - constraint_meta.tolerance,
                            line=line_style,
                            annotation_text="Lower Bound",
                            annotation_position="bottom right",
                            row=i,
                            col=1,
                        )
                    if constraint_meta.upper_bound is not None:
                        fig.add_hline(
                            y=constraint_meta.upper_bound + constraint_meta.tolerance,
                            line=line_style,
                            annotation_text="Upper Bound",
                            annotation_position="top right",
                            row=i,
                            col=1,
                        )

        # Update y-axis label for this subplot
        fig.update_yaxes(title_text=col, row=i, col=1)

    # Update x-axis label for bottom subplot
    fig.update_xaxes(title_text="Iteration", row=num_plots, col=1)

    # Update overall layout
    fig.update_layout(
        title_text=title,
        height=max(400, 250 * num_plots),
        showlegend=False,
        margin=dict(l=10, r=10, t=60, b=10),
    )

    # Add grid lines
    fig.update_xaxes(showgrid=True, gridwidth=1, gridcolor="lightgray")
    fig.update_yaxes(showgrid=True, gridwidth=1, gridcolor="lightgray")

    return fig


def plot_time_series_resampled(
    result: OptimizationResult,
    columns: list[str],
    data_attr: str,
    title: str = "Time Series",
    show_markers: bool = False,
    line_width: int = 2,
    marker_size: int = 4,
    show_feasibility: bool = True,
    single_plot: bool = False,
    max_n_samples: int = 1000,
) -> go.Figure | FigureResampler:
    """
    Create a resampled time series plot for large datasets.

    This function uses plotly-resampler to efficiently handle large time series data
    by dynamically downsampling based on the zoom level. This is particularly useful
    for optimization histories with many iterations.

    Args:
        result: OptimizationResult object containing the data
        columns: List of column names to plot
        data_attr: Attribute name on result object (e.g., 'design_variables', 'objectives')
        title: Overall plot title
        show_markers: Whether to show markers on the line plot (default False for performance)
        line_width: Width of the lines
        marker_size: Size of the markers
        show_feasibility: Whether to show feasibility markers
        single_plot: If True, all columns are plotted in a single subplot with a legend
        max_n_samples: Maximum number of samples to display at any zoom level (default: 1000)

    Returns:
        FigureResampler object if plotly-resampler is available, otherwise regular Figure

    Example:
        >>> from optiscope.plotting.time_series import plot_time_series_resampled
        >>> fig = plot_time_series_resampled(
        ...     result,
        ...     columns=['x1', 'x2'],
        ...     data_attr='design_variables',
        ...     title='Design Variables Evolution'
        ... )
        >>> fig.show_dash(mode='inline')  # For Dash apps
    """
    if not RESAMPLER_AVAILABLE:
        # Fallback to regular plotting if resampler not available
        return plot_time_series(
            result,
            columns,
            data_attr,
            title,
            show_markers,
            line_width,
            marker_size,
            show_feasibility,
            single_plot,
        )

    if not columns or len(columns) == 0:
        fig = go.Figure()
        fig.add_annotation(
            text=f"No columns selected for {title}",
            xref="paper",
            yref="paper",
            x=0.5,
            y=0.5,
            showarrow=False,
            font=dict(size=14),
        )
        fig.update_layout(
            title=title,
            height=400,
            margin=dict(l=10, r=10, t=40, b=10),
        )
        return fig

    # Get the data frame
    df = getattr(result, data_attr, None)
    if df is None or df.empty:
        fig = go.Figure()
        fig.add_annotation(
            text=f"No data available for {data_attr}",
            xref="paper",
            yref="paper",
            x=0.5,
            y=0.5,
            showarrow=False,
            font=dict(size=14),
        )
        fig.update_layout(
            title=title,
            height=400,
            margin=dict(l=10, r=10, t=40, b=10),
        )
        return fig

    # Filter to only columns that exist
    valid_columns = [col for col in columns if col in df.columns]
    if not valid_columns:
        fig = go.Figure()
        fig.add_annotation(
            text=f"Selected columns not found in {data_attr}",
            xref="paper",
            yref="paper",
            x=0.5,
            y=0.5,
            showarrow=False,
            font=dict(size=14),
        )
        fig.update_layout(
            title=title,
            height=400,
            margin=dict(l=10, r=10, t=40, b=10),
        )
        return fig

    # Create subplots
    num_plots = 1 if single_plot else len(valid_columns)
    subplot_titles = None if single_plot else [f"{col}" for col in valid_columns]

    base_fig = make_subplots(
        rows=num_plots,
        cols=1,
        subplot_titles=subplot_titles,
        vertical_spacing=0.08,
    )

    # Wrap with FigureResampler
    fig = FigureResampler(
        base_fig,
        default_downsampler=MinMaxLTTB(parallel=True),
        default_n_shown_samples=max_n_samples,
    )

    # Add traces for each selected column using hf_x and hf_y for resampling
    mode = "lines+markers" if show_markers else "lines"
    x_data = np.arange(len(df))

    for i, col in enumerate(valid_columns, start=1):
        fig.add_trace(
            go.Scattergl(
                mode=mode,
                name=col,
                line=dict(width=line_width),
                marker=dict(size=marker_size) if show_markers else None,
                showlegend=single_plot,
            ),
            hf_x=x_data,
            hf_y=df[col].values,
            row=1 if single_plot else i,
            col=1,
        )

        # Update y-axis label for this subplot
        if not single_plot:
            fig.update_yaxes(title_text=col, row=i, col=1)
        elif i == 1:
            fig.update_yaxes(title_text="Value", row=1, col=1)

    # Update x-axis label for bottom subplot
    fig.update_xaxes(title_text="Iteration", row=num_plots, col=1)

    # Update overall layout
    fig.update_layout(
        title_text=title,
        height=max(400, 250 * num_plots),
        showlegend=single_plot,
        margin=dict(l=10, r=10, t=60, b=10),
    )

    # Add grid lines
    fig.update_xaxes(showgrid=True, gridwidth=1, gridcolor="lightgray")
    fig.update_yaxes(showgrid=True, gridwidth=1, gridcolor="lightgray")

    return fig


def plot_optimization_history(
    result: OptimizationResult,
    variables: list[str] | None = None,
    objectives: list[str] | None = None,
    constraints: list[str] | None = None,
    observables: list[str] | None = None,
    **kwargs,
) -> dict[str, go.Figure]:
    """
    Create time series plots for all categories of optimization data.

    This is a convenience function that creates separate plots for variables,
    objectives, constraints, and observables.

    Args:
        result: OptimizationResult object containing the data
        variables: List of variable names to plot (None = all)
        objectives: List of objective names to plot (None = all)
        constraints: List of constraint names to plot (None = all)
        observables: List of observable names to plot (None = all)
        **kwargs: Additional keyword arguments passed to plotting functions

    Returns:
        Dictionary with keys 'variables', 'objectives', 'constraints', 'observables',
        each containing a Plotly figure

    Example:
        >>> from optiscope.plotting.time_series import plot_optimization_history
        >>> figs = plot_optimization_history(result)
        >>> figs['variables'].show()
        >>> figs['objectives'].show()
    """
    # Use all columns if not specified
    if variables is None:
        variables = result.design_variables.columns.tolist()
    if objectives is None:
        objectives = result.objectives.columns.tolist()
    if constraints is None:
        constraints = (
            result.inequality_constraints.columns.tolist()
            + result.equality_constraints.columns.tolist()
        )
    if observables is None:
        observables = result.observables.columns.tolist()

    figures = {
        "variables": plot_time_series(
            result, variables, "design_variables", "Design Variables", **kwargs
        ),
        "objectives": plot_time_series(result, objectives, "objectives", "Objectives", **kwargs),
        "constraints": plot_constraints_time_series(result, constraints, "Constraints", **kwargs),
        "observables": plot_time_series(
            result, observables, "observables", "Observables", **kwargs
        ),
    }

    return figures
