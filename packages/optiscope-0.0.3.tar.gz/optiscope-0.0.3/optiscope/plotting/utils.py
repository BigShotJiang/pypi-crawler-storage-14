from __future__ import annotations

from typing import Any

import plotly.graph_objects as go


def create_combined_legend(figures: list[go.Figure]) -> go.Figure:
    """
    Create a figure containing only the combined legend from multiple Plotly figures.

    Traces with the same name are merged unless they have different colors.

    Parameters:
    -----------
    figures : List[go.Figure]
        List of Plotly figures to extract legends from

    Returns:
    --------
    go.Figure
        A figure containing only the legend entries (invisible traces)
    """

    # Dictionary to store unique traces: key = (name, color), value = trace properties
    unique_traces: dict[tuple[str, str], dict[str, Any]] = {}

    for fig in figures:
        for trace in fig.data:
            # Skip traces without names or with showlegend=False
            if not hasattr(trace, "name") or not trace.name:
                continue
            if hasattr(trace, "showlegend") and not trace.showlegend:
                continue

            # Extract color from trace (handle different trace types)
            color = None
            if hasattr(trace, "line") and trace.line and hasattr(trace.line, "color"):
                color = trace.line.color
            elif hasattr(trace, "marker") and trace.marker and hasattr(trace.marker, "color"):
                color = trace.marker.color
                # Handle case where color is an array (take first color)
                if isinstance(color, (list, tuple)):
                    color = color[0] if len(color) > 0 else None
            elif hasattr(trace, "fillcolor"):
                color = trace.fillcolor

            # Convert color to string for consistent comparison
            color_str = str(color) if color is not None else "default"

            # Create unique key
            key = (trace.name, color_str)

            # Store trace info if not already present
            if key not in unique_traces:
                # Convert Plotly objects to dicts using .to_plotly_json()
                line_dict = None
                if hasattr(trace, "line") and trace.line:
                    line_dict = (
                        trace.line.to_plotly_json()
                        if hasattr(trace.line, "to_plotly_json")
                        else None
                    )

                marker_dict = None
                if hasattr(trace, "marker") and trace.marker:
                    marker_dict = (
                        trace.marker.to_plotly_json()
                        if hasattr(trace.marker, "to_plotly_json")
                        else None
                    )

                unique_traces[key] = {
                    "name": trace.name,
                    "color": color,
                    "mode": getattr(trace, "mode", None),
                    "type": trace.type,
                    "line": line_dict,
                    "marker": marker_dict,
                    "legendgroup": getattr(trace, "legendgroup", None),
                }

    # Create new figure with invisible traces for legend
    legend_fig = go.Figure()

    for (name, color_str), trace_info in unique_traces.items():
        # Create a minimal invisible trace that will show in legend
        if trace_info["type"] == "scatter":
            # Use scatter trace with a single invisible point
            trace_kwargs = {
                "x": [None],
                "y": [None],
                "name": name,
                "mode": trace_info["mode"] if trace_info["mode"] else "lines",
                "showlegend": True,
            }

            # Add line styling if present
            if trace_info["line"]:
                trace_kwargs["line"] = trace_info["line"]

            # Add marker styling if present
            if trace_info["marker"] and "lines" not in str(trace_info["mode"]):
                trace_kwargs["marker"] = trace_info["marker"]

            legend_fig.add_trace(go.Scatter(**trace_kwargs))

        elif trace_info["type"] == "bar":
            # Use bar trace with invisible bar
            trace_kwargs = {
                "x": [None],
                "y": [None],
                "name": name,
                "showlegend": True,
            }
            if trace_info["marker"]:
                trace_kwargs["marker"] = trace_info["marker"]

            legend_fig.add_trace(go.Bar(**trace_kwargs))

        else:
            # Generic approach for other trace types
            trace_kwargs = {
                "x": [None],
                "y": [None],
                "name": name,
                "showlegend": True,
            }
            if trace_info["marker"]:
                trace_kwargs["marker"] = trace_info["marker"]
            if trace_info["line"]:
                trace_kwargs["line"] = trace_info["line"]

            legend_fig.add_trace(go.Scatter(**trace_kwargs))

    # Update layout to hide axes and show only legend
    legend_fig.update_layout(
        xaxis=dict(visible=False),
        yaxis=dict(visible=False),
        plot_bgcolor="rgba(0,0,0,0)",
        paper_bgcolor="rgba(0,0,0,0)",
        margin=dict(l=0, r=0, t=0, b=0),
        showlegend=True,
        legend=dict(orientation="h", yanchor="top", y=1, xanchor="left", x=0),
        height=100,
    )

    return legend_fig


# Example usage
if __name__ == "__main__":
    # Create sample figures with various traces
    fig1 = go.Figure()
    fig1.add_trace(go.Scatter(x=[1, 2, 3], y=[1, 2, 3], name="Series A", line=dict(color="red")))
    fig1.add_trace(go.Scatter(x=[1, 2, 3], y=[2, 3, 4], name="Series B", line=dict(color="blue")))

    fig2 = go.Figure()
    fig2.add_trace(
        go.Scatter(x=[1, 2, 3], y=[3, 2, 1], name="Series A", line=dict(color="red"))
    )  # Same name and color - will merge
    fig2.add_trace(go.Scatter(x=[1, 2, 3], y=[4, 3, 2], name="Series C", line=dict(color="green")))
    fig2.add_trace(
        go.Scatter(x=[1, 2, 3], y=[5, 4, 3], name="Series A", line=dict(color="orange"))
    )  # Same name, different color - won't merge

    # Create combined legend figure
    legend_fig = create_combined_legend([fig1, fig2])
    legend_fig.show()
