"""
Database storage backend for optimization results.

Scalable storage backend using SQLAlchemy for database operations.
Supports PostgreSQL, SQLite, MySQL, and other SQLAlchemy-compatible databases.
"""

from __future__ import annotations

import json
import pickle
from datetime import datetime
from typing import Any

from sqlalchemy import Sequence

try:
    from sqlalchemy import (
        Column,
        DateTime,
        Integer,
        LargeBinary,
        String,
        Text,
        create_engine,
        text,
    )
    from sqlalchemy.orm import sessionmaker

    SQLALCHEMY_AVAILABLE = True
except ImportError:
    SQLALCHEMY_AVAILABLE = False

from optiscope.core.data_model import OptimizationResult
from optiscope.core.result_set import ResultSet
from optiscope.storage.base import (
    StorageBackend,
    StorageConnectionError,
    StorageError,
    StorageOperationError,
    StorageType,
)

if SQLALCHEMY_AVAILABLE:

    def _create_set_record_classes(connection_string: str, dump_as_json: bool = True):
        """
        Create SetRecord class with appropriate ID column for the database backend.

        Args:
            connection_string: SQLAlchemy connection string

        Returns:
            SetRecord class configured for the specific database backend
        """
        from sqlalchemy.ext.declarative import declarative_base

        Base = declarative_base()  # noqa: N806

        # Determine if using DuckDB
        is_duckdb = "duckdb" in connection_string.lower()

        class ResultRecord(Base):
            """Database record for optimization results."""

            __tablename__ = "optimization_results"

            key = Column(String(255), primary_key=True)
            if dump_as_json:
                data = Column(Text, nullable=False)  # JSON serialized OptimizationResult
            else:
                data = Column(LargeBinary, nullable=False)  # Pickle serialized OptimizationResult
            created_at = Column(DateTime, nullable=False)
            modified_at = Column(DateTime, nullable=False)
            n_points = Column(Integer)
            n_sets = Column(Integer)
            size_bytes = Column(Integer)
            metadata_json = Column(Text)  # JSON string for custom metadata

        class SetRecord(Base):
            """Database record for result sets."""

            __tablename__ = "result_sets"

            if is_duckdb:
                # DuckDB requires Sequence for autoincrement
                user_id_seq = Sequence("user_id_seq")
                id = Column(
                    Integer, user_id_seq, primary_key=True, server_default=user_id_seq.next_value()
                )
            else:
                # SQLite and others use standard autoincrement
                id = Column(Integer, primary_key=True, autoincrement=True)

            result_key = Column(String(255), nullable=False, index=True)
            set_name = Column(String(255), nullable=False)
            data = Column(Text, nullable=False)  # JSON serialized ResultSet
            created_at = Column(DateTime, nullable=False)
            modified_at = Column(DateTime, nullable=False)

        return ResultRecord, SetRecord


class DatabaseStorage(StorageBackend):
    """
    Database storage backend using SQLAlchemy.

    Stores results in a relational database with efficient querying
    and metadata indexing. Suitable for large-scale applications
    and multi-user scenarios.

    For multi-source session databases, use SessionDBStorage instead,
    which adds automatic source_id prefixing for data isolation.
    """

    storage_type = StorageType.DATABASE

    def __init__(
        self,
        connection_string: str,
        echo: bool = False,
        pool_size: int = 5,
        max_overflow: int = 10,
        dump_as_json: bool = False,
        **config: Any,
    ) -> None:
        """
        Initialize database storage.

        Args:
            connection_string: SQLAlchemy connection string
                Examples:
                - SQLite: "sqlite:///path/to/database.db"
                - PostgreSQL: "postgresql://user:pass@localhost/dbname"
                - MySQL: "mysql://user:pass@localhost/dbname"
                - DuckDB: "duckdb:///database.duckdb"
            echo: Enable SQL query logging
            pool_size: Connection pool size
            max_overflow: Maximum overflow connections
            **config: Additional SQLAlchemy engine configuration
        """
        if not SQLALCHEMY_AVAILABLE:
            raise StorageError(
                "SQLAlchemy is not installed. Install with: pip install optiscope[database]"
            )

        self.connection_string = connection_string
        self.echo = echo
        self.pool_size = pool_size
        self.max_overflow = max_overflow
        self.dump_as_json = dump_as_json
        # Create backend-specific ResultRecord and SetRecord classes
        self.ResultRecord, self.SetRecord = _create_set_record_classes(
            connection_string, dump_as_json
        )

        super().__init__(**config)

    def _initialize(self) -> None:
        """Initialize database connection and tables."""
        try:
            # Create engine
            self.engine = create_engine(
                self.connection_string,
                echo=self.echo,
                pool_size=self.pool_size,
                max_overflow=self.max_overflow,
                **self.config,
            )

            # Create tables (use the instance's SetRecord class)
            self.ResultRecord.metadata.create_all(self.engine)
            self.SetRecord.__table__.create(self.engine, checkfirst=True)

            # Create session factory
            self.SessionLocal = sessionmaker(bind=self.engine)

        except Exception as e:
            raise StorageConnectionError(f"Failed to initialize database: {str(e)}") from e

    def _serialize_result(self, result: OptimizationResult) -> str | bytes:
        """Serialize result to bytes or JSON string."""
        if not self.dump_as_json:
            return pickle.dumps(result, protocol=pickle.HIGHEST_PROTOCOL)
        return json.dumps(result.to_dict())

    def _deserialize_result(self, data: str | bytes) -> OptimizationResult:
        """Deserialize result from JSON string."""
        if not self.dump_as_json and isinstance(data, bytes):
            return pickle.loads(data)
        return OptimizationResult.from_dict(json.loads(data))

    def save_result(
        self, key: str, result: OptimizationResult, metadata: dict[str, Any] | None = None
    ) -> None:
        """Save result to database."""
        session = self.SessionLocal()

        try:
            # Serialize result
            data = self._serialize_result(result)
            if isinstance(data, str) and self.dump_as_json:
                size_bytes = len(data.encode("utf-8"))
            else:
                size_bytes = len(data)

            # Check if record exists
            existing: Any = session.query(self.ResultRecord).filter_by(key=key).first()

            now = datetime.now()

            if existing:
                # Update existing record
                existing.data = data
                existing.modified_at = now
                existing.n_points = result.n_points
                existing.n_sets = len(result.list_sets())
                existing.size_bytes = size_bytes

                # Update custom metadata
                if metadata:
                    existing_meta = json.loads(existing.metadata_json or "{}")
                    existing_meta.update(metadata)
                    existing.metadata_json = json.dumps(existing_meta)
            else:
                # Create new record
                record: Any = self.ResultRecord(
                    key=key,
                    data=data,
                    created_at=now,
                    modified_at=now,
                    n_points=result.n_points,
                    n_sets=len(result.list_sets()),
                    size_bytes=size_bytes,
                    metadata_json=json.dumps(metadata or {}),
                )
                session.add(record)

            session.commit()

            # Save result sets
            for set_name, result_set in result.sets.items():
                self.save_set(key, set_name, result_set)

        except Exception as e:
            session.rollback()
            raise StorageOperationError(f"Failed to save result '{key}': {str(e)}") from e
        finally:
            session.close()

    def load_result(self, key: str) -> OptimizationResult:
        """Load result from database."""
        session = self.SessionLocal()

        try:
            record: Any = session.query(self.ResultRecord).filter_by(key=key).first()

            if not record:
                raise KeyError(f"Result '{key}' not found in storage")

            # Deserialize result
            result = self._deserialize_result(record.data)

            # Load result sets
            set_records: list[Any] = session.query(self.SetRecord).filter_by(result_key=key).all()
            for set_record in set_records:
                try:
                    set_data = json.loads(set_record.data)
                    result_set = ResultSet.from_dict(set_data)
                    result._set_manager.add_set(result_set)
                except Exception as e:
                    print(f"Warning: Failed to load set '{set_record.set_name}': {e}")

            return result

        except KeyError:
            raise
        except Exception as e:
            raise StorageOperationError(f"Failed to load result '{key}': {str(e)}") from e
        finally:
            session.close()

    def delete_result(self, key: str) -> None:
        """Delete result from database."""
        session = self.SessionLocal()

        try:
            record: Any = session.query(self.ResultRecord).filter_by(key=key).first()

            if not record:
                raise KeyError(f"Result '{key}' not found in storage")

            # Delete result sets first
            session.query(self.SetRecord).filter_by(result_key=key).delete()

            # Delete result
            session.delete(record)
            session.commit()

        except KeyError:
            raise
        except Exception as e:
            session.rollback()
            raise StorageOperationError(f"Failed to delete result '{key}': {str(e)}") from e
        finally:
            session.close()

    def rename_result(self, old_key: str, new_key: str) -> None:
        """
        Rename a result.

        Args:
            old_key: Current result key
            new_key: New result key
        """
        session = self.SessionLocal()

        try:
            # Check if new key exists
            if session.query(self.ResultRecord).filter_by(key=new_key).count() > 0:
                raise StorageError(f"Result '{new_key}' already exists")

            # Get existing record
            record: Any = session.query(self.ResultRecord).filter_by(key=old_key).first()

            if not record:
                raise KeyError(f"Result '{old_key}' not found in storage")

            # Update key
            record.key = new_key
            record.modified_at = datetime.now()

            # Update serialized data
            result = self._deserialize_result(record.data)
            result.rename(new_key)
            record.data = self._serialize_result(result)

            # Update size_bytes if needed
            if isinstance(record.data, str) and self.dump_as_json:
                record.size_bytes = len(record.data.encode("utf-8"))
            else:
                record.size_bytes = len(record.data)

            # Update SetRecords associated with this result
            session.query(self.SetRecord).filter_by(result_key=old_key).update(
                {"result_key": new_key}
            )

            session.commit()

        except (KeyError, StorageError):
            session.rollback()
            raise
        except Exception as e:
            session.rollback()
            raise StorageOperationError(
                f"Failed to rename result '{old_key}' to '{new_key}': {str(e)}"
            ) from e
        finally:
            session.close()

    def exists_result(self, key: str) -> bool:
        """Check if result exists."""
        session = self.SessionLocal()
        try:
            count = session.query(self.ResultRecord).filter_by(key=key).count()
            return count > 0
        finally:
            session.close()

    def list_results(self, prefix: str | None = None) -> list[str]:
        """List all result keys."""
        session = self.SessionLocal()

        try:
            query = session.query(self.ResultRecord.key)

            if prefix:
                query = query.filter(self.ResultRecord.key.like(f"{prefix}%"))

            keys = [row[0] for row in query.all()]
            return sorted(keys)
        finally:
            session.close()

    def save_set(self, result_key: str, set_name: str, result_set: ResultSet) -> None:
        """Save result set to database."""
        session = self.SessionLocal()

        try:
            # Check if result exists
            if not self.exists_result(result_key):
                raise KeyError(f"Result '{result_key}' not found in storage")

            # Check if set record exists
            existing: Any = (
                session.query(self.SetRecord)
                .filter_by(result_key=result_key, set_name=set_name)
                .first()
            )

            now = datetime.now()
            set_data = json.dumps(result_set.to_dict(), default=str)

            if existing:
                # Update existing record
                existing.data = set_data
                existing.modified_at = now
            else:
                # Create new record
                record: Any = self.SetRecord(
                    result_key=result_key,
                    set_name=set_name,
                    data=set_data,
                    created_at=now,
                    modified_at=now,
                )
                session.add(record)

            session.commit()

            # Update result metadata
            result_record: Any = session.query(self.ResultRecord).filter_by(key=result_key).first()
            if result_record:
                result_record.modified_at = now
                result_record.n_sets = (
                    session.query(self.SetRecord).filter_by(result_key=result_key).count()
                )
                session.commit()

        except KeyError:
            raise
        except Exception as e:
            session.rollback()
            raise StorageOperationError(f"Failed to save set '{set_name}': {str(e)}") from e
        finally:
            session.close()

    def load_set(self, result_key: str, set_name: str) -> ResultSet:
        """Load result set from database."""
        session = self.SessionLocal()

        try:
            record: Any = (
                session.query(self.SetRecord)
                .filter_by(result_key=result_key, set_name=set_name)
                .first()
            )

            if not record:
                raise KeyError(f"Set '{set_name}' not found for result '{result_key}'")

            set_data = json.loads(record.data)
            return ResultSet.from_dict(set_data)

        except KeyError:
            raise
        except Exception as e:
            raise StorageOperationError(f"Failed to load set '{set_name}': {str(e)}") from e
        finally:
            session.close()

    def delete_set(self, result_key: str, set_name: str) -> None:
        """Delete result set from database."""
        session = self.SessionLocal()

        try:
            record: Any = (
                session.query(self.SetRecord)
                .filter_by(result_key=result_key, set_name=set_name)
                .first()
            )

            if not record:
                raise KeyError(f"Set '{set_name}' not found for result '{result_key}'")

            session.delete(record)
            session.commit()

            # Update result metadata
            result_record: Any = session.query(self.ResultRecord).filter_by(key=result_key).first()
            if result_record:
                result_record.modified_at = datetime.now()
                result_record.n_sets = (
                    session.query(self.SetRecord).filter_by(result_key=result_key).count()
                )
                session.commit()

        except KeyError:
            raise
        except Exception as e:
            session.rollback()
            raise StorageOperationError(f"Failed to delete set '{set_name}': {str(e)}") from e
        finally:
            session.close()

    def list_sets(self, result_key: str) -> list[str]:
        """List all sets for a result."""
        session = self.SessionLocal()

        try:
            if not self.exists_result(result_key):
                raise KeyError(f"Result '{result_key}' not found in storage")

            records = session.query(self.SetRecord.set_name).filter_by(result_key=result_key).all()

            return sorted([row[0] for row in records])
        finally:
            session.close()

    def get_result_metadata(self, key: str) -> dict[str, Any]:
        """Get result metadata."""
        session = self.SessionLocal()

        try:
            record: Any = session.query(self.ResultRecord).filter_by(key=key).first()

            if not record:
                raise KeyError(f"Result '{key}' not found in storage")

            custom_meta = json.loads(record.metadata_json or "{}")

            return {
                "key": record.key,
                "created_at": record.created_at,
                "modified_at": record.modified_at,
                "n_points": record.n_points,
                "n_sets": record.n_sets,
                "size_bytes": record.size_bytes,
                "custom": custom_meta,
            }
        finally:
            session.close()

    def update_result_metadata(self, key: str, metadata: dict[str, Any]) -> None:
        """Update result metadata."""
        session = self.SessionLocal()

        try:
            record: Any = session.query(self.ResultRecord).filter_by(key=key).first()

            if not record:
                raise KeyError(f"Result '{key}' not found in storage")

            # Update custom metadata
            existing_meta = json.loads(record.metadata_json or "{}")
            existing_meta.update(metadata)
            record.metadata_json = json.dumps(existing_meta)
            record.modified_at = datetime.now()

            session.commit()

        except KeyError:
            raise
        except Exception as e:
            session.rollback()
            raise StorageOperationError(f"Failed to update metadata for '{key}': {str(e)}") from e
        finally:
            session.close()

    def clear(self, prefix: str | None = None) -> int:
        """Clear stored results."""
        session = self.SessionLocal()

        try:
            query = session.query(self.ResultRecord)

            if prefix:
                query = query.filter(self.ResultRecord.key.like(f"{prefix}%"))

            # Get keys to delete sets
            results: list[Any] = query.all()
            keys = [row.key for row in results]

            # Delete sets first
            for key in keys:
                session.query(self.SetRecord).filter_by(result_key=key).delete()

            # Delete results
            count = query.delete()
            session.commit()

            return count

        except Exception as e:
            session.rollback()
            raise StorageOperationError(f"Failed to clear storage: {str(e)}") from e
        finally:
            session.close()

    def get_storage_info(self) -> dict[str, Any]:
        """Get storage information."""
        session = self.SessionLocal()

        try:
            n_results = session.query(self.ResultRecord).count()
            n_sets = session.query(self.SetRecord).count()

            # Get total size
            total_size = session.query(self.ResultRecord.size_bytes).all()
            total_mb = sum(s[0] for s in total_size if s[0]) / (1024 * 1024)

            return {
                "storage_type": "database",
                "connection_string": self.connection_string.split("@")[-1],  # Hide credentials
                "n_results": n_results,
                "n_total_sets": n_sets,
                "total_size_mb": total_mb,
            }
        finally:
            session.close()

    def close(self) -> None:
        """Close database connections."""
        if hasattr(self, "engine"):
            self.engine.dispose()

    def vacuum(self) -> None:
        """
        Optimize database (SQLite only).

        For SQLite databases, runs VACUUM to reclaim space.
        For other databases, this is a no-op.
        """
        if "sqlite" in self.connection_string.lower():
            session = self.SessionLocal()
            try:
                session.execute(text("VACUUM"))
                session.commit()
            finally:
                session.close()

    def to_dict(self) -> dict[str, Any]:
        """
        Serialize database storage to dictionary.

        Note: This only stores connection information, not the actual data.
        The data persists in the database itself.
        """
        return {
            "storage_type": "database",
            "connection_string": self.connection_string,
            "echo": self.echo,
            "pool_size": self.pool_size,
            "max_overflow": self.max_overflow,
            "config": self.config,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> DatabaseStorage:
        """
        Deserialize database storage from dictionary.

        Reconnects to the database using the stored connection information.
        """
        return cls(
            connection_string=data["connection_string"],
            echo=data.get("echo", False),
            pool_size=data.get("pool_size", 5),
            max_overflow=data.get("max_overflow", 10),
            **data.get("config", {}),
        )
