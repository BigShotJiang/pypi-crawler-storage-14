"""
File system storage backend for optimization results.

Persistent storage backend that saves results to the file system.
Supports different serialization formats and directory structures.
"""

from __future__ import annotations

import json
import shutil
from datetime import datetime
from pathlib import Path
from typing import Any

from optiscope.core import OptimizationResult, ResultSet
from optiscope.io import load_results, save_results
from optiscope.storage import (
    StorageBackend,
    StorageError,
    StorageOperationError,
    StorageType,
)


class FileSystemStorage(StorageBackend):
    """
    File system storage backend.

    Stores results as files in a directory structure. Each result is
    saved with its metadata and sets in a dedicated subdirectory.
    """

    storage_type = StorageType.FILESYSTEM

    def __init__(
        self,
        base_path: str | Path,
        format: str = "json",
        create_if_missing: bool = True,
        **config: Any,
    ) -> None:
        """
        Initialize file system storage.

        Args:
            base_path: Base directory for storage
            format: File format for results ("json", "csv", etc.)
            create_if_missing: Create base directory if it doesn't exist
            **config: Additional configuration
        """
        self.base_path = Path(base_path)
        self.format = format
        self.create_if_missing = create_if_missing
        super().__init__(**config)

    def _initialize(self) -> None:
        """Initialize storage directory."""
        if self.create_if_missing:
            self.base_path.mkdir(parents=True, exist_ok=True)
        elif not self.base_path.exists():
            raise StorageError(f"Storage path does not exist: {self.base_path}")

        if not self.base_path.is_dir():
            raise StorageError(f"Storage path is not a directory: {self.base_path}")

    def _get_result_path(self, key: str) -> Path:
        """Get directory path for a result."""
        # Sanitize key for filesystem
        safe_key = key.replace("/", "_").replace("\\", "_")
        return self.base_path / safe_key

    def _get_result_file(self, key: str) -> Path:
        """Get file path for result data."""
        result_path = self._get_result_path(key)
        return result_path / f"result.{self.format}"

    def _get_metadata_file(self, key: str) -> Path:
        """Get file path for metadata."""
        result_path = self._get_result_path(key)
        return result_path / "metadata.json"

    def _get_sets_dir(self, key: str) -> Path:
        """Get directory path for result sets."""
        result_path = self._get_result_path(key)
        return result_path / "sets"

    def _get_set_file(self, result_key: str, set_name: str) -> Path:
        """Get file path for a result set."""
        sets_dir = self._get_sets_dir(result_key)
        safe_name = set_name.replace("/", "_").replace("\\", "_")
        return sets_dir / f"{safe_name}.json"

    def _save_metadata(self, key: str, metadata: dict[str, Any]) -> None:
        """Save metadata to file."""
        metadata_file = self._get_metadata_file(key)
        metadata_file.parent.mkdir(parents=True, exist_ok=True)

        with open(metadata_file, "w") as f:
            json.dump(metadata, f, indent=2, default=str)

    def _load_metadata(self, key: str) -> dict[str, Any]:
        """Load metadata from file."""
        metadata_file = self._get_metadata_file(key)

        if not metadata_file.exists():
            raise StorageError(f"Metadata file not found for '{key}'")

        with open(metadata_file) as f:
            return json.load(f)

    def save_result(
        self, key: str, result: OptimizationResult, metadata: dict[str, Any] | None = None
    ) -> None:
        """Save result to file system."""
        result_path = self._get_result_path(key)
        result_file = self._get_result_file(key)

        try:
            # Create directory
            result_path.mkdir(parents=True, exist_ok=True)

            # Save result data
            save_results(result, result_file, format_hint=self.format)

            # Create/update metadata
            now = datetime.now()
            meta = self._load_metadata(key) if self._get_metadata_file(key).exists() else {}

            if "created_at" not in meta:
                meta["created_at"] = now.isoformat()

            meta.update(
                {
                    "key": key,
                    "modified_at": now.isoformat(),
                    "n_points": result.n_points,
                    "n_sets": len(result.list_sets()),
                    "format": self.format,
                    "custom": metadata or {},
                }
            )

            self._save_metadata(key, meta)

            # Save result sets
            sets_dir = self._get_sets_dir(key)
            sets_dir.mkdir(exist_ok=True)

            for set_name, result_set in result.sets.items():
                self.save_set(key, set_name, result_set)

        except Exception as e:
            # Clean up on failure
            if result_path.exists():
                shutil.rmtree(result_path, ignore_errors=True)
            raise StorageOperationError(f"Failed to save result '{key}': {str(e)}") from e

    def load_result(self, key: str) -> OptimizationResult:
        """Load result from file system."""
        result_file = self._get_result_file(key)

        if not result_file.exists():
            raise KeyError(f"Result '{key}' not found in storage")

        try:
            result = load_results(result_file, format_hint=self.format)

            # Load result sets
            sets_dir = self._get_sets_dir(key)
            if sets_dir.exists():
                for set_file in sets_dir.glob("*.json"):
                    set_name = set_file.stem
                    try:
                        result_set = self.load_set(key, set_name)
                        result._set_manager.add_set(result_set)
                    except Exception as e:
                        # Log but don't fail on individual set load errors
                        print(f"Warning: Failed to load set '{set_name}': {e}")

            return result

        except Exception as e:
            raise StorageOperationError(f"Failed to load result '{key}': {str(e)}") from e

    def delete_result(self, key: str) -> None:
        """Delete result from file system."""
        result_path = self._get_result_path(key)

        if not result_path.exists():
            raise KeyError(f"Result '{key}' not found in storage")

        try:
            shutil.rmtree(result_path)
        except Exception as e:
            raise StorageOperationError(f"Failed to delete result '{key}': {str(e)}") from e

    def rename_result(self, old_key: str, new_key: str) -> None:
        """Rename a result."""
        old_path = self._get_result_path(old_key)
        new_path = self._get_result_path(new_key)

        if not old_path.exists():
            raise KeyError(f"Result '{old_key}' not found in storage")

        if new_path.exists():
            raise StorageOperationError(f"Result '{new_key}' already exists")

        try:
            # Rename directory
            shutil.move(str(old_path), str(new_path))

            # Update metadata if it exists
            try:
                meta = self._load_metadata(new_key)
                meta["key"] = new_key
                meta["modified_at"] = datetime.now().isoformat()
                self._save_metadata(new_key, meta)
            except Exception as e:
                # If metadata update fails, we might want to warn but the rename happened
                print(f"Warning: Failed to update metadata for renamed result '{new_key}': {e}")

        except Exception as e:
            raise StorageOperationError(
                f"Failed to rename result '{old_key}' to '{new_key}': {str(e)}"
            ) from e

    def exists_result(self, key: str) -> bool:
        """Check if result exists."""
        return self._get_result_file(key).exists()

    def list_results(self, prefix: str | None = None) -> list[str]:
        """List all result keys."""
        if not self.base_path.exists():
            return []

        keys = []
        for item in self.base_path.iterdir():
            if item.is_dir():
                result_file = item / f"result.{self.format}"
                if result_file.exists():
                    key = item.name
                    if prefix is None or key.startswith(prefix):
                        keys.append(key)

        return sorted(keys)

    def save_set(self, result_key: str, set_name: str, result_set: ResultSet) -> None:
        """Save result set to file system."""
        if not self.exists_result(result_key):
            raise KeyError(f"Result '{result_key}' not found in storage")

        set_file = self._get_set_file(result_key, set_name)
        set_file.parent.mkdir(parents=True, exist_ok=True)

        try:
            with open(set_file, "w") as f:
                json.dump(result_set.to_dict(), f, indent=2, default=str)

            # Update metadata
            meta = self._load_metadata(result_key)
            meta["modified_at"] = datetime.now().isoformat()
            sets_dir = self._get_sets_dir(result_key)
            meta["n_sets"] = len(list(sets_dir.glob("*.json"))) if sets_dir.exists() else 0
            self._save_metadata(result_key, meta)

        except Exception as e:
            raise StorageOperationError(f"Failed to save set '{set_name}': {str(e)}") from e

    def load_set(self, result_key: str, set_name: str) -> ResultSet:
        """Load result set from file system."""
        set_file = self._get_set_file(result_key, set_name)

        if not set_file.exists():
            raise KeyError(f"Set '{set_name}' not found for result '{result_key}'")

        try:
            with open(set_file) as f:
                data = json.load(f)
            return ResultSet.from_dict(data)
        except Exception as e:
            raise StorageOperationError(f"Failed to load set '{set_name}': {str(e)}") from e

    def delete_set(self, result_key: str, set_name: str) -> None:
        """Delete result set from file system."""
        set_file = self._get_set_file(result_key, set_name)

        if not set_file.exists():
            raise KeyError(f"Set '{set_name}' not found for result '{result_key}'")

        try:
            set_file.unlink()

            # Update metadata
            meta = self._load_metadata(result_key)
            meta["modified_at"] = datetime.now().isoformat()
            sets_dir = self._get_sets_dir(result_key)
            meta["n_sets"] = len(list(sets_dir.glob("*.json"))) if sets_dir.exists() else 0
            self._save_metadata(result_key, meta)

        except Exception as e:
            raise StorageOperationError(f"Failed to delete set '{set_name}': {str(e)}") from e

    def list_sets(self, result_key: str) -> list[str]:
        """List all sets for a result."""
        if not self.exists_result(result_key):
            raise KeyError(f"Result '{result_key}' not found in storage")

        sets_dir = self._get_sets_dir(result_key)
        if not sets_dir.exists():
            return []

        return sorted([f.stem for f in sets_dir.glob("*.json")])

    def get_result_metadata(self, key: str) -> dict[str, Any]:
        """Get result metadata."""
        if not self.exists_result(key):
            raise KeyError(f"Result '{key}' not found in storage")

        return self._load_metadata(key)

    def update_result_metadata(self, key: str, metadata: dict[str, Any]) -> None:
        """Update result metadata."""
        if not self.exists_result(key):
            raise KeyError(f"Result '{key}' not found in storage")

        meta = self._load_metadata(key)

        if "custom" not in meta:
            meta["custom"] = {}

        meta["custom"].update(metadata)
        meta["modified_at"] = datetime.now().isoformat()

        self._save_metadata(key, meta)

    def clear(self, prefix: str | None = None) -> int:
        """Clear stored results."""
        keys = self.list_results(prefix)

        for key in keys:
            self.delete_result(key)

        return len(keys)

    def get_storage_info(self) -> dict[str, Any]:
        """Get storage information."""
        # Calculate total size
        total_size = 0
        n_files = 0

        if self.base_path.exists():
            for item in self.base_path.rglob("*"):
                if item.is_file():
                    total_size += item.stat().st_size
                    n_files += 1

        size_mb = total_size / (1024 * 1024)

        return {
            "storage_type": "filesystem",
            "base_path": str(self.base_path.absolute()),
            "format": self.format,
            "n_results": len(self.list_results()),
            "total_size_mb": size_mb,
            "n_files": n_files,
            "exists": self.base_path.exists(),
        }

    def compact(self) -> dict[str, Any]:
        """
        Compact storage by removing orphaned files.

        Returns:
            Dictionary with compaction statistics
        """
        removed_files = 0
        freed_bytes = 0

        if not self.base_path.exists():
            return {"removed_files": 0, "freed_mb": 0.0}

        # Find directories without result files
        for item in self.base_path.iterdir():
            if item.is_dir():
                result_file = item / f"result.{self.format}"
                if not result_file.exists():
                    # Orphaned directory
                    size = sum(f.stat().st_size for f in item.rglob("*") if f.is_file())
                    shutil.rmtree(item)
                    removed_files += 1
                    freed_bytes += size

        return {"removed_files": removed_files, "freed_mb": freed_bytes / (1024 * 1024)}

    def to_dict(self) -> dict[str, Any]:
        """Serialize the filesystem storage to a dictionary."""
        return {
            "storage_type": self.storage_type.value,
            "base_path": str(self.base_path),
            "format": self.format,
            "config": self.config,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> FileSystemStorage:
        """Deserialize filesystem storage from a dictionary."""
        return cls(
            base_path=data["base_path"],
            format=data.get("format", "json"),
            **data.get("config", {}),
        )
