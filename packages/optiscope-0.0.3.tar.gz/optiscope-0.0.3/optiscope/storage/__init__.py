"""
Storage abstraction layer for optimization results.

This package provides a pluggable storage architecture supporting
multiple backends (memory, filesystem, database) with a consistent API.

Backends:
- MemoryStorage: Fast in-memory storage (session-based)
- FileSystemStorage: Persistent file-based storage
- DatabaseStorage: Scalable database storage (requires SQLAlchemy)

The StorageManager coordinates multiple backends and provides caching,
replication, and migration capabilities.
"""

from .base import (
    StorageBackend,
    StorageCapacityError,
    StorageConnectionError,
    StorageError,
    StorageMetadata,
    StorageOperationError,
    StorageType,
)
from .file_system import FileSystemStorage
from .manager import (
    StorageManager,
    create_database_storage,
    create_filesystem_storage,
    create_memory_storage,
    create_storage_manager,
)
from .memory import MemoryStorage

# Try to import database storage
try:
    from .database import SQLALCHEMY_AVAILABLE, DatabaseStorage

    _database_available = SQLALCHEMY_AVAILABLE
except ImportError:
    DatabaseStorage = None
    _database_available = False


__all__ = [
    # Base classes
    "StorageBackend",
    "StorageType",
    # Exceptions
    "StorageError",
    "StorageConnectionError",
    "StorageOperationError",
    "StorageCapacityError",
    "StorageMetadata",
    # Backends
    "MemoryStorage",
    "FileSystemStorage",
    "DatabaseStorage",
    # Manager
    "StorageManager",
    # Factory functions
    "create_memory_storage",
    "create_filesystem_storage",
    "create_database_storage",
    "create_storage_manager",
]


def is_database_available() -> bool:
    """Check if database storage backend is available."""
    return _database_available
