"""
Base storage abstraction for optimization results.

This module defines the abstract interface for storage backends,
enabling different storage strategies (memory, filesystem, database)
with a consistent API.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from datetime import datetime
from enum import Enum
from typing import Any

from optiscope.core.data_model import OptimizationResult
from optiscope.core.result_set import ResultSet


class StorageType(str, Enum):
    """Types of storage backends."""

    MEMORY = "memory"
    FILESYSTEM = "filesystem"
    DATABASE = "database"


class StorageBackend(ABC):
    """
    Abstract base class for storage backends.

    Storage backends handle persistence of OptimizationResult objects
    and their associated result sets. Each backend can implement its
    own strategy for data storage and retrieval.
    """

    storage_type: StorageType

    def __init__(self, **config: Any) -> None:
        """
        Initialize storage backend.

        Args:
            **config: Backend-specific configuration
        """
        self.config = config
        self._initialize()

    @abstractmethod
    def _initialize(self) -> None:
        """Initialize the storage backend (create connections, etc.)."""
        pass

    # Result management
    @abstractmethod
    def save_result(
        self, key: str, result: OptimizationResult, metadata: dict[str, Any] | None = None
    ) -> None:
        """
        Save an optimization result.

        Args:
            key: Unique identifier for the result
            result: OptimizationResult to save
            metadata: Optional additional metadata

        Raises:
            StorageError: If save operation fails
        """
        pass

    @abstractmethod
    def load_result(self, key: str) -> OptimizationResult:
        """
        Load an optimization result.

        Args:
            key: Unique identifier for the result

        Returns:
            OptimizationResult object

        Raises:
            KeyError: If key not found
            StorageError: If load operation fails
        """
        pass

    @abstractmethod
    def delete_result(self, key: str) -> None:
        """
        Delete an optimization result.

        Args:
            key: Unique identifier for the result

        Raises:
            KeyError: If key not found
            StorageError: If delete operation fails
        """
        pass

    @abstractmethod
    def exists_result(self, key: str) -> bool:
        """
        Check if a result exists.

        Args:
            key: Unique identifier for the result

        Returns:
            True if result exists
        """
        pass

    @abstractmethod
    def list_results(self, prefix: str | None = None) -> list[str]:
        """
        List all stored result keys.

        Args:
            prefix: Optional prefix filter

        Returns:
            List of result keys
        """
        pass

    @abstractmethod
    def rename_result(self, old_key: str, new_key: str) -> None:
        """
        Rename a result.

        Args:
            old_key: The current key of the result
            new_key: The new key for the result

        Raises:
            KeyError: If old_key not found
            ValueError: If new_key already exists
            StorageError: If rename operation fails
        """
        pass

    # Result set management
    @abstractmethod
    def save_set(self, result_key: str, set_name: str, result_set: ResultSet) -> None:
        """
        Save a result set for a specific result.

        Args:
            result_key: Key of the parent result
            set_name: Name of the result set
            result_set: ResultSet to save

        Raises:
            KeyError: If result_key not found
            StorageError: If save operation fails
        """
        pass

    @abstractmethod
    def load_set(self, result_key: str, set_name: str) -> ResultSet:
        """
        Load a result set.

        Args:
            result_key: Key of the parent result
            set_name: Name of the result set

        Returns:
            ResultSet object

        Raises:
            KeyError: If result_key or set_name not found
            StorageError: If load operation fails
        """
        pass

    @abstractmethod
    def delete_set(self, result_key: str, set_name: str) -> None:
        """
        Delete a result set.

        Args:
            result_key: Key of the parent result
            set_name: Name of the result set

        Raises:
            KeyError: If result_key or set_name not found
            StorageError: If delete operation fails
        """
        pass

    @abstractmethod
    def list_sets(self, result_key: str) -> list[str]:
        """
        List all result sets for a given result.

        Args:
            result_key: Key of the parent result

        Returns:
            List of set names

        Raises:
            KeyError: If result_key not found
        """
        pass

    # Metadata management
    @abstractmethod
    def get_result_metadata(self, key: str) -> dict[str, Any]:
        """
        Get metadata for a result without loading the full data.

        Args:
            key: Unique identifier for the result

        Returns:
            Dictionary of metadata

        Raises:
            KeyError: If key not found
        """
        pass

    @abstractmethod
    def update_result_metadata(self, key: str, metadata: dict[str, Any]) -> None:
        """
        Update metadata for a result.

        Args:
            key: Unique identifier for the result
            metadata: Metadata to update/add

        Raises:
            KeyError: If key not found
        """
        pass

    # Storage management
    @abstractmethod
    def clear(self, prefix: str | None = None) -> int:
        """
        Clear stored results.

        Args:
            prefix: Optional prefix filter (if None, clear all)

        Returns:
            Number of results deleted
        """
        pass

    @abstractmethod
    def get_storage_info(self) -> dict[str, Any]:
        """
        Get information about storage usage.

        Returns:
            Dictionary with storage information
        """
        pass

    @abstractmethod
    def to_dict(self) -> dict[str, Any]:
        """
        Serialize the storage backend's state to a dictionary.

        For memory-based storage, this might involve serializing all contained data.
        For file-based or database storage, this might involve storing references
        (e.g., file paths or connection strings) so the state can be reconstructed.
        """
        pass

    @classmethod
    @abstractmethod
    def from_dict(cls, data: dict[str, Any]) -> StorageBackend:
        """
        Deserialize a storage backend from a dictionary representation.

        This class method should reconstruct the storage backend from the serialized
        state produced by `to_dict`.
        """
        pass

    def close(self) -> None:
        """Close storage backend (cleanup connections, etc.)."""
        pass

    def __enter__(self) -> StorageBackend:
        """Context manager entry."""
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        """Context manager exit."""
        self.close()


class StorageError(Exception):
    """Base exception for storage-related errors."""

    pass


class StorageConnectionError(StorageError):
    """Exception raised when storage connection fails."""

    pass


class StorageOperationError(StorageError):
    """Exception raised when storage operation fails."""

    pass


class StorageCapacityError(StorageError):
    """Exception raised when storage capacity is exceeded."""

    pass


# Helper class for storage metadata
class StorageMetadata:
    """Metadata about a stored result."""

    def __init__(
        self,
        key: str,
        created_at: datetime,
        modified_at: datetime,
        size_bytes: int | None = None,
        n_points: int | None = None,
        n_sets: int | None = None,
        custom_metadata: dict[str, Any] | None = None,
    ) -> None:
        """
        Initialize storage metadata.

        Args:
            key: Result key
            created_at: Creation timestamp
            modified_at: Last modification timestamp
            size_bytes: Size in bytes
            n_points: Number of data points
            n_sets: Number of result sets
            custom_metadata: Additional custom metadata
        """
        self.key = key
        self.created_at = created_at
        self.modified_at = modified_at
        self.size_bytes = size_bytes
        self.n_points = n_points
        self.n_sets = n_sets
        self.custom_metadata = custom_metadata or {}

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "key": self.key,
            "created_at": self.created_at.isoformat(),
            "modified_at": self.modified_at.isoformat(),
            "size_bytes": self.size_bytes,
            "n_points": self.n_points,
            "n_sets": self.n_sets,
            "custom_metadata": self.custom_metadata,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> StorageMetadata:
        """Create from dictionary."""
        return cls(
            key=data["key"],
            created_at=datetime.fromisoformat(data["created_at"]),
            modified_at=datetime.fromisoformat(data["modified_at"]),
            size_bytes=data.get("size_bytes"),
            n_points=data.get("n_points"),
            n_sets=data.get("n_sets"),
            custom_metadata=data.get("custom_metadata"),
        )
