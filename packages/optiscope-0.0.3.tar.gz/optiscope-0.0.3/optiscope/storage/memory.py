"""
In-memory storage backend for optimization results.

Fast storage backend that keeps all data in memory. Useful for
interactive sessions and when persistence is not required.
"""

from __future__ import annotations

import sys
from copy import deepcopy
from datetime import datetime
from typing import Any

from optiscope.core.data_model import OptimizationResult
from optiscope.core.result_set import ResultSet
from optiscope.storage.base import StorageBackend, StorageOperationError, StorageType


class MemoryStorage(StorageBackend):
    """
    In-memory storage backend.

    Stores all results in memory using Python dictionaries. This is the
    fastest storage option but data is lost when the process ends.
    Supports optional memory limits and automatic eviction.
    """

    storage_type = StorageType.MEMORY

    def __init__(
        self, max_memory_mb: float | None = None, eviction_policy: str = "lru", **config: Any
    ) -> None:
        """
        Initialize memory storage.

        Args:
            max_memory_mb: Maximum memory usage in MB (None = unlimited)
            eviction_policy: Eviction policy when limit reached ("lru", "fifo")
            **config: Additional configuration
        """
        self.max_memory_mb = max_memory_mb
        self.eviction_policy = eviction_policy
        super().__init__(**config)

    def _initialize(self) -> None:
        """Initialize storage structures."""
        self._results: dict[str, OptimizationResult] = {}
        self._sets: dict[str, dict[str, ResultSet]] = {}  # result_key -> {set_name: set}
        self._metadata: dict[str, dict[str, Any]] = {}
        self._access_order: list[str] = []  # For LRU eviction
        self._creation_order: list[str] = []  # For FIFO eviction

    def _update_access(self, key: str) -> None:
        """Update access tracking for eviction policies."""
        if key in self._access_order:
            self._access_order.remove(key)
        self._access_order.append(key)

    def _check_memory_limit(self, new_key: str | None = None) -> None:
        """
        Check if memory limit is exceeded and evict if necessary.

        Args:
            new_key: Key being added (to exclude from eviction)
        """
        if self.max_memory_mb is None:
            return

        # Estimate memory usage (approximate)
        current_mb = sys.getsizeof(self._results) / (1024 * 1024)

        while current_mb > self.max_memory_mb and len(self._results) > 1:
            # Evict based on policy
            if self.eviction_policy == "lru":
                # Evict least recently used
                evict_key = self._access_order[0]
            else:  # fifo
                # Evict oldest
                evict_key = self._creation_order[0]

            # Don't evict the key we're trying to add
            if evict_key == new_key:
                if len(self._access_order) > 1:
                    evict_key = self._access_order[1]
                else:
                    break

            # Perform eviction
            self.delete_result(evict_key)
            current_mb = sys.getsizeof(self._results) / (1024 * 1024)

    def save_result(
        self, key: str, result: OptimizationResult, metadata: dict[str, Any] | None = None
    ) -> None:
        """Save result to memory."""
        # Check memory limit before saving
        self._check_memory_limit(key)

        # Deep copy to avoid external modifications
        self._results[key] = deepcopy(result)

        # Track creation
        if key not in self._creation_order:
            self._creation_order.append(key)

        # Initialize metadata
        now = datetime.now()
        self._metadata[key] = {
            "created_at": now,
            "modified_at": now,
            "n_points": result.n_points,
            "n_sets": len(result.list_sets()),
            "custom": metadata or {},
        }

        # Update access
        self._update_access(key)

        # Check memory after save
        self._check_memory_limit()

    def load_result(self, key: str) -> OptimizationResult:
        """Load result from memory."""
        if key not in self._results:
            raise KeyError(f"Result '{key}' not found in storage")

        self._update_access(key)
        # Return a deep copy to avoid external modifications
        return deepcopy(self._results[key])

    def delete_result(self, key: str) -> None:
        """Delete result from memory."""
        if key not in self._results:
            raise KeyError(f"Result '{key}' not found in storage")

        del self._results[key]

        # Clean up sets
        if key in self._sets:
            del self._sets[key]

        # Clean up metadata
        if key in self._metadata:
            del self._metadata[key]

        # Clean up tracking
        if key in self._access_order:
            self._access_order.remove(key)
        if key in self._creation_order:
            self._creation_order.remove(key)

    def rename_result(self, old_key: str, new_key: str) -> None:
        """Rename a result."""
        if old_key not in self._results:
            raise KeyError(f"Result '{old_key}' not found in storage")

        if new_key in self._results:
            raise StorageOperationError(f"Result '{new_key}' already exists")

        # Move result
        self._results[new_key] = self._results.pop(old_key)

        # Move sets
        if old_key in self._sets:
            self._sets[new_key] = self._sets.pop(old_key)

        # Move metadata
        if old_key in self._metadata:
            self._metadata[new_key] = self._metadata.pop(old_key)
            self._metadata[new_key]["modified_at"] = datetime.now()

        # Update tracking
        if old_key in self._access_order:
            idx = self._access_order.index(old_key)
            self._access_order[idx] = new_key

        if old_key in self._creation_order:
            idx = self._creation_order.index(old_key)
            self._creation_order[idx] = new_key

    def exists_result(self, key: str) -> bool:
        """Check if result exists in memory."""
        return key in self._results

    def list_results(self, prefix: str | None = None) -> list[str]:
        """List all result keys."""
        keys = list(self._results.keys())
        if prefix:
            keys = [k for k in keys if k.startswith(prefix)]
        return sorted(keys)

    def save_set(self, result_key: str, set_name: str, result_set: ResultSet) -> None:
        """Save result set."""
        if result_key not in self._results:
            raise KeyError(f"Result '{result_key}' not found in storage")

        if result_key not in self._sets:
            self._sets[result_key] = {}

        # Deep copy the set
        self._sets[result_key][set_name] = deepcopy(result_set)

        # Update metadata
        if result_key in self._metadata:
            self._metadata[result_key]["modified_at"] = datetime.now()
            self._metadata[result_key]["n_sets"] = len(self._sets[result_key])

        self._update_access(result_key)

    def load_set(self, result_key: str, set_name: str) -> ResultSet:
        """Load result set."""
        if result_key not in self._results:
            raise KeyError(f"Result '{result_key}' not found in storage")

        if result_key not in self._sets or set_name not in self._sets[result_key]:
            raise KeyError(f"Set '{set_name}' not found for result '{result_key}'")

        self._update_access(result_key)
        return deepcopy(self._sets[result_key][set_name])

    def delete_set(self, result_key: str, set_name: str) -> None:
        """Delete result set."""
        if result_key not in self._results:
            raise KeyError(f"Result '{result_key}' not found in storage")

        if result_key not in self._sets or set_name not in self._sets[result_key]:
            raise KeyError(f"Set '{set_name}' not found for result '{result_key}'")

        del self._sets[result_key][set_name]

        # Update metadata
        if result_key in self._metadata:
            self._metadata[result_key]["modified_at"] = datetime.now()
            self._metadata[result_key]["n_sets"] = len(self._sets[result_key])

    def list_sets(self, result_key: str) -> list[str]:
        """List all sets for a result."""
        if result_key not in self._results:
            raise KeyError(f"Result '{result_key}' not found in storage")

        if result_key not in self._sets:
            return []

        return sorted(self._sets[result_key].keys())

    def get_result_metadata(self, key: str) -> dict[str, Any]:
        """Get result metadata."""
        if key not in self._results:
            raise KeyError(f"Result '{key}' not found in storage")

        meta = self._metadata.get(key, {})
        return {
            "key": key,
            "created_at": meta.get("created_at"),
            "modified_at": meta.get("modified_at"),
            "n_points": meta.get("n_points"),
            "n_sets": meta.get("n_sets"),
            "custom": meta.get("custom", {}),
        }

    def update_result_metadata(self, key: str, metadata: dict[str, Any]) -> None:
        """Update result metadata."""
        if key not in self._results:
            raise KeyError(f"Result '{key}' not found in storage")

        if key not in self._metadata:
            self._metadata[key] = {}

        # Update custom metadata
        if "custom" not in self._metadata[key]:
            self._metadata[key]["custom"] = {}

        self._metadata[key]["custom"].update(metadata)
        self._metadata[key]["modified_at"] = datetime.now()

    def clear(self, prefix: str | None = None) -> int:
        """Clear stored results."""
        if prefix is None:
            count = len(self._results)
            self._results.clear()
            self._sets.clear()
            self._metadata.clear()
            self._access_order.clear()
            self._creation_order.clear()
            return count
        else:
            keys_to_delete = [k for k in self._results.keys() if k.startswith(prefix)]
            for key in keys_to_delete:
                self.delete_result(key)
            return len(keys_to_delete)

    def get_storage_info(self) -> dict[str, Any]:
        """Get storage information."""
        # Estimate memory usage
        total_size = sys.getsizeof(self._results)
        for result in self._results.values():
            total_size += sys.getsizeof(result)

        size_mb = total_size / (1024 * 1024)

        return {
            "storage_type": "memory",
            "n_results": len(self._results),
            "n_total_sets": sum(len(sets) for sets in self._sets.values()),
            "size_mb": size_mb,
            "max_memory_mb": self.max_memory_mb,
            "eviction_policy": self.eviction_policy,
            "usage_percent": (size_mb / self.max_memory_mb * 100) if self.max_memory_mb else None,
        }

    def get_result_reference(self, key: str) -> OptimizationResult:
        """
        Get direct reference to result (no copy).

        WARNING: This bypasses the copy protection and allows direct
        modification of stored data. Use with caution.

        Args:
            key: Result key

        Returns:
            Direct reference to stored OptimizationResult
        """
        if key not in self._results:
            raise KeyError(f"Result '{key}' not found in storage")

        self._update_access(key)
        return self._results[key]

    def to_dict(self) -> dict[str, Any]:
        """Serialize the memory storage to a dictionary."""
        return {
            "storage_type": self.storage_type.value,
            "results": {key: result.to_dict() for key, result in self._results.items()},
            "config": self.config,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> MemoryStorage:
        """Deserialize memory storage from a dictionary."""
        storage = cls(**data.get("config", {}))
        results = {
            key: OptimizationResult.from_dict(res_data)
            for key, res_data in data.get("results", {}).items()
        }
        storage._results = results
        # Re-initialize other attributes based on loaded results if necessary
        storage._access_order = list(results.keys())
        storage._creation_order = list(results.keys())
        return storage
