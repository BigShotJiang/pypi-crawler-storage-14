"""
Core data structures and models for optimization visualization.

This package contains the fundamental data structures used throughout
the library: data types, optimization results, and result sets.
"""

from .data_model import (
    OptimizationResult,
    ProblemMetadata,
)
from .data_types import (
    AnyVariableMetadata,
    Constraint,
    ConstraintType,
    CustomDataType,
    DataTypeCategory,
    DesignVariable,
    Objective,
    Observable,
    OptimizationDirection,
    VariableMetadata,
)
from .result_set import (
    ResultSet,
    SetManager,
    SetOperation,
)

__all__ = [
    # Data types
    "DataTypeCategory",
    "OptimizationDirection",
    "ConstraintType",
    "VariableMetadata",
    "DesignVariable",
    "Objective",
    "Constraint",
    "Observable",
    "CustomDataType",
    "AnyVariableMetadata",
    # Result sets
    "SetOperation",
    "ResultSet",
    "SetManager",
    # Data model
    "ProblemMetadata",
    "OptimizationResult",
]
