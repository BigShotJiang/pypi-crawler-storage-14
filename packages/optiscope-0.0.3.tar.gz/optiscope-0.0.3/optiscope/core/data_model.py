"""
Core data model for optimization results.

This module defines the main OptimizationResult class that holds all
optimization data and metadata in a structured, extensible format.
"""

from __future__ import annotations

from datetime import datetime
from io import StringIO
from typing import Any

import narwhals as nw
import numpy as np
import pandas as pd
import polars as pl
from pydantic import BaseModel, Field

from optiscope.core.data_types import (
    AnyVariableMetadata,
    Constraint,
    ConstraintType,
    CustomDataType,
    DataTypeCategory,
    DesignVariable,
    Objective,
    Observable,
    OptimizationDirection,
)
from optiscope.core.result_set import ResultSet, SetManager


class ProblemMetadata(BaseModel):
    """Metadata about the optimization problem."""

    name: str = Field(..., description="Problem name")
    description: str | None = Field(None, description="Problem description")
    solver: str | None = Field(None, description="Solver used")
    solver_version: str | None = Field(None, description="Solver version")
    solver_settings: dict[str, Any] = Field(
        default_factory=dict, description="Solver settings/parameters"
    )

    # Problem dimensions
    n_design_variables: int = Field(0, description="Number of design variables")
    n_objectives: int = Field(0, description="Number of objectives")
    n_inequality_constraints: int = Field(0, description="Number of inequality constraints")
    n_equality_constraints: int = Field(0, description="Number of equality constraints")

    # Run information
    run_date: datetime = Field(default_factory=datetime.now)
    computation_time: float | None = Field(None, description="Total time in seconds")
    n_evaluations: int | None = Field(None, description="Number of function evaluations")

    # Custom metadata
    metadata: dict[str, Any] = Field(default_factory=dict, description="Additional custom metadata")

    class Config:
        json_encoders = {datetime: lambda v: v.isoformat()}


class OptimizationResult:
    """
    Main container for optimization results.

    This class holds all data from an optimization run including design variables,
    objectives, constraints, observables, and any custom data.
    """

    def __init__(
        self,
        problem_metadata: ProblemMetadata | None = None,
        design_variables: Any = None,
        objectives: Any = None,
        inequality_constraints: Any = None,
        equality_constraints: Any = None,
        observables: Any = None,
        custom_data: dict[str, Any] | None = None,
    ) -> None:
        """
        Initialize optimization result.

        Narwhals is used here to accept Pandas, Polars, or generic iterables
        and normalize them to the internal Polars storage format.
        """
        self.problem_metadata = problem_metadata or ProblemMetadata(name="Unnamed Problem")  # type: ignore

        # Data storage - internal storage uses Polars
        # We use a helper method that leverages Narwhals for conversion
        self._design_variables = self._normalize_to_frame(design_variables)
        self._objectives = self._normalize_to_frame(objectives)
        self._inequality_constraints = self._normalize_to_frame(inequality_constraints)
        self._equality_constraints = self._normalize_to_frame(equality_constraints)
        self._observables = self._normalize_to_frame(observables)

        self._custom_data: dict[str, pl.DataFrame] = {}
        if custom_data:
            for k, v in custom_data.items():
                self._custom_data[k] = self._normalize_to_frame(v)

        # Variable metadata storage
        self._variable_metadata: dict[str, AnyVariableMetadata] = {}

        # Set management
        self._set_manager = SetManager()

        # Validate consistency
        self._validate_data()

    def _normalize_to_frame(self, data: Any) -> pl.DataFrame:
        """
        Convert input data to Polars DataFrame using Narwhals.
        """
        if data is None:
            return pl.DataFrame()

        # If it's already a Polars DataFrame, return it directly
        if isinstance(data, pl.DataFrame):
            return data

        # Handle dicts/lists directly with Polars
        if isinstance(data, (dict, list)):
            return pl.DataFrame(data)

        try:
            # Use Narwhals to convert Pandas/PyArrow/etc to Polars
            return nw.from_native(data).to_polars()
        except Exception:
            # Last resort fallback
            try:
                return pl.DataFrame(data)
            except Exception:
                # If conversion fails entirely, return empty (or raise specific error)
                print(f"Warning: Could not convert data of type {type(data)} to Polars.")
                return pl.DataFrame()

    def to_dict(self) -> dict[str, Any]:
        """Serialize the OptimizationResult to a dictionary."""

        def serialize_df(df: pl.DataFrame) -> str | None:
            if df.is_empty():
                return None
            # Narwhals doesn't handle JSON serialization formats, so we stick to
            # Polars -> Pandas -> JSON for compatibility with the existing schema
            return df.to_pandas().to_json(orient="split", date_format="iso")

        return {
            "problem_metadata": self.problem_metadata.model_dump(mode="json"),
            "design_variables": serialize_df(self._design_variables),
            "objectives": serialize_df(self._objectives),
            "inequality_constraints": serialize_df(self._inequality_constraints),
            "equality_constraints": serialize_df(self._equality_constraints),
            "observables": serialize_df(self._observables),
            "custom_data": {name: serialize_df(df) for name, df in self._custom_data.items()},
            "variable_metadata": {
                name: meta.model_dump(mode="json") for name, meta in self._variable_metadata.items()
            },
            "set_manager": self._set_manager.to_dict(),
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> OptimizationResult:
        """Deserialize an OptimizationResult from a dictionary."""

        def deserialize_df(json_str: str | None) -> pd.DataFrame:
            if json_str is None:
                return pd.DataFrame()
            df = pd.read_json(StringIO(json_str), orient="split")
            # Ensure date columns are parsed correctly if any
            for col in df.columns:
                if pd.api.types.is_object_dtype(df[col]):
                    try:
                        df[col] = pd.to_datetime(df[col], errors="raise")
                    except (ValueError, TypeError):
                        pass
            return df

        metadata_cls_map: dict[DataTypeCategory, type[AnyVariableMetadata]] = {
            DataTypeCategory.DESIGN_VARIABLE: DesignVariable,
            DataTypeCategory.OBJECTIVE: Objective,
            DataTypeCategory.CONSTRAINT: Constraint,
            DataTypeCategory.OBSERVABLE: Observable,
        }

        variable_metadata = {}
        for name, meta_data in data.get("variable_metadata", {}).items():
            category = DataTypeCategory(meta_data.get("category"))
            cls_ = metadata_cls_map.get(category)
            if cls_:
                variable_metadata[name] = cls_(**meta_data)

        result = cls(
            problem_metadata=ProblemMetadata(**data["problem_metadata"]),
            design_variables=deserialize_df(data.get("design_variables")),
            objectives=deserialize_df(data.get("objectives")),
            inequality_constraints=deserialize_df(data.get("inequality_constraints")),
            equality_constraints=deserialize_df(data.get("equality_constraints")),
            observables=deserialize_df(data.get("observables")),
            custom_data={
                name: deserialize_df(df_json)
                for name, df_json in data.get("custom_data", {}).items()
            },
        )

        result._variable_metadata = variable_metadata

        if "set_manager" in data:
            result._set_manager.from_dict(data["set_manager"])

        return result

    def _validate_data(self) -> None:
        """Validate that all data has consistent number of rows."""
        sizes = []

        # Helper to check size of internal polars frames
        for df in [
            self._design_variables,
            self._objectives,
            self._inequality_constraints,
            self._equality_constraints,
            self._observables,
        ]:
            if not df.is_empty():
                sizes.append(df.height)

        for df in self._custom_data.values():
            if not df.is_empty():
                sizes.append(df.height)

        if sizes and len(set(sizes)) > 1:
            raise ValueError(f"All data must have same number of rows. Found: {set(sizes)}")

    @property
    def metadata(self) -> ProblemMetadata:
        return self.problem_metadata

    @property
    def optimization_directions(self) -> list[OptimizationDirection]:
        directions = []
        for col in self._objectives.columns:
            meta = self.get_variable_metadata(col)
            if isinstance(meta, Objective):
                directions.append(meta.direction)
            else:
                raise ValueError(f"Metadata for objective '{col}' is missing or invalid.")
        return directions

    @property
    def n_points(self) -> int:
        if not self._design_variables.is_empty():
            return self._design_variables.height
        # Fallback checks for other frames
        for df in [
            self._objectives,
            self._inequality_constraints,
            self._equality_constraints,
            self._observables,
        ]:
            if not df.is_empty():
                return df.height
        if self._custom_data:
            return next(iter(self._custom_data.values())).height
        return 0

    # Property accessors for data (Pandas compatibility)
    @property
    def design_variables(self) -> pd.DataFrame:
        return self._design_variables.to_pandas()

    @property
    def objectives(self) -> pd.DataFrame:
        return self._objectives.to_pandas()

    @property
    def inequality_constraints(self) -> pd.DataFrame:
        return self._inequality_constraints.to_pandas()

    @property
    def equality_constraints(self) -> pd.DataFrame:
        return self._equality_constraints.to_pandas()

    @property
    def observables(self) -> pd.DataFrame:
        return self._observables.to_pandas()

    # Polars accessors (Internal / Advanced usage)
    @property
    def design_variables_pl(self) -> pl.DataFrame:
        return self._design_variables

    @property
    def objectives_pl(self) -> pl.DataFrame:
        return self._objectives

    @property
    def inequality_constraints_pl(self) -> pl.DataFrame:
        return self._inequality_constraints

    @property
    def equality_constraints_pl(self) -> pl.DataFrame:
        return self._equality_constraints

    @property
    def observables_pl(self) -> pl.DataFrame:
        return self._observables

    def get_custom_data(self, name: str) -> pd.DataFrame:
        if name not in self._custom_data:
            raise KeyError(f"Custom data '{name}' not found")
        return self._custom_data[name].to_pandas()

    def get_custom_data_pl(self, name: str) -> pl.DataFrame:
        if name not in self._custom_data:
            raise KeyError(f"Custom data '{name}' not found")
        return self._custom_data[name]

    def add_custom_data(self, name: str, data: Any) -> None:
        data_pl = self._normalize_to_frame(data)
        if not data_pl.is_empty() and data_pl.height != self.n_points:
            raise ValueError(f"Custom data must have {self.n_points} rows, got {data_pl.height}")
        self._custom_data[name] = data_pl

    def rename(self, new_name: str) -> None:
        """Rename the optimization problem."""
        self.problem_metadata.name = new_name

    def add_column(
        self,
        name: str,
        data: Any,
        category: DataTypeCategory = DataTypeCategory.OBSERVABLE,
        metadata: AnyVariableMetadata | None = None,
    ) -> None:
        """
        Add a new column of data to the optimization result.
        Uses Narwhals to handle input formats (list, np.array, pd.Series, pl.Series) identically.
        """
        # 1. Normalize input to Polars Series using Narwhals
        if isinstance(data, (list, np.ndarray)):
            series = pl.Series(name, data)
        else:
            # nw.from_native(..., series_only=True) handles pd.Series, pl.Series, etc.
            series = nw.from_native(data, series_only=True).to_polars().rename(name)

        current_n_points = self.n_points
        if current_n_points > 0 and series.len() != current_n_points:
            raise ValueError(
                f"Data length {series.len()} does not match result length {current_n_points}"
            )

        # 2. Create default metadata if not provided
        if metadata is None:
            if category == DataTypeCategory.DESIGN_VARIABLE:
                metadata = DesignVariable(name=name)
            elif category == DataTypeCategory.OBJECTIVE:
                metadata = Objective(name=name)
            elif category == DataTypeCategory.CONSTRAINT:
                metadata = Constraint(name=name)
            elif category == DataTypeCategory.OBSERVABLE:
                metadata = Observable(name=name)
            elif category == DataTypeCategory.CUSTOM:
                metadata = CustomDataType(name=name, custom_type="generic")
            else:
                raise ValueError(f"Unknown category: {category}")

        # Validate metadata matches category and name
        if metadata.category != category:
            raise ValueError(
                f"Metadata category {metadata.category} does not match provided category {category}"
            )

        if metadata.name != name:
            raise ValueError(f"Metadata name {metadata.name} does not match provided name {name}")

        # 3. Add to appropriate DataFrame
        # Note: We use direct polars assignment here because internal storage is concrete Polars
        if category == DataTypeCategory.DESIGN_VARIABLE:
            self._design_variables = self._design_variables.with_columns(series)
        elif category == DataTypeCategory.OBJECTIVE:
            self._objectives = self._objectives.with_columns(series)
        elif category == DataTypeCategory.CONSTRAINT:
            if isinstance(metadata, Constraint):
                if metadata.constraint_type == ConstraintType.EQUALITY:
                    self._equality_constraints = self._equality_constraints.with_columns(series)
                else:
                    self._inequality_constraints = self._inequality_constraints.with_columns(series)
            else:
                raise ValueError("Metadata must be instance of Constraint for CONSTRAINT category")
        elif category == DataTypeCategory.OBSERVABLE:
            self._observables = self._observables.with_columns(series)
        elif category == DataTypeCategory.CUSTOM:
            if isinstance(metadata, CustomDataType):
                table_name = metadata.custom_type
                if table_name not in self._custom_data:
                    self._custom_data[table_name] = pl.DataFrame()
                self._custom_data[table_name] = self._custom_data[table_name].with_columns(series)
            else:
                raise ValueError("Metadata must be instance of CustomDataType for CUSTOM category")

        self.add_variable_metadata(metadata)

    # Metadata management
    def add_variable_metadata(self, metadata: AnyVariableMetadata) -> None:
        self._variable_metadata[metadata.name] = metadata

    def get_variable_metadata(self, name: str) -> AnyVariableMetadata | None:
        return self._variable_metadata.get(name)

    def get_variables_by_category(self, category: DataTypeCategory) -> list[str]:
        return [name for name, meta in self._variable_metadata.items() if meta.category == category]

    # Set management
    def create_set(
        self,
        name: str,
        indices: list[int] | np.ndarray,
        created_by: str = "user",
        description: str | None = None,
        color: str | None = None,
    ) -> ResultSet:
        if isinstance(indices, np.ndarray):
            indices = indices.tolist()

        indices = [int(i) for i in indices]
        if any(i < 0 or i >= self.n_points for i in indices):
            raise ValueError(f"Indices must be in range [0, {self.n_points})")

        result_set = ResultSet(
            name=name, indices=indices, created_by=created_by, description=description, color=color
        )  # type: ignore

        self._set_manager.add_set(result_set)
        return result_set

    def add_set(self, result_set: ResultSet) -> None:
        self._set_manager.add_set(result_set)

    def get_set(self, name: str) -> ResultSet:
        return self._set_manager.get_set(name)

    def remove_set(self, name: str) -> None:
        self._set_manager.remove_set(name)

    def list_sets(self) -> list[str]:
        return self._set_manager.list_sets()

    @property
    def sets(self) -> dict[str, ResultSet]:
        return self._set_manager.sets

    # Data extraction for sets
    def get_set_data(self, set_name: str, category: DataTypeCategory | None = None) -> pd.DataFrame:
        """
        Get data for a specific set as Pandas DataFrame.
        """
        result_set = self.get_set(set_name)
        indices = result_set.indices

        # We collect frames in native Polars first
        data_frames = []

        if category is None or category == DataTypeCategory.DESIGN_VARIABLE:
            if not self._design_variables.is_empty():
                data_frames.append(self._design_variables[indices])

        if category is None or category == DataTypeCategory.OBJECTIVE:
            if not self._objectives.is_empty():
                data_frames.append(self._objectives[indices])

        if category is None or category == DataTypeCategory.CONSTRAINT:
            if not self._inequality_constraints.is_empty():
                data_frames.append(self._inequality_constraints[indices])
            if not self._equality_constraints.is_empty():
                data_frames.append(self._equality_constraints[indices])

        if category is None or category == DataTypeCategory.OBSERVABLE:
            if not self._observables.is_empty():
                data_frames.append(self._observables[indices])

        if not data_frames:
            return pd.DataFrame()

        # Use Narwhals to concatenate regardless of what backend we might use in future
        # Convert all to Narwhals DataFrame -> Concat -> Convert to Pandas
        nw_frames = [nw.from_native(df) for df in data_frames]
        return nw.concat(nw_frames, how="horizontal").to_pandas()

    # Analysis methods
    def find_pareto_front(
        self,
        set_name: str = "pareto_front",
        from_set: str | None = None,
    ) -> ResultSet:
        from optiscope.analysis.pareto import identify_pareto_front

        if self._objectives.is_empty():
            raise ValueError("Cannot find Pareto front without objectives.")

        objective_names = self.get_variables_by_category(DataTypeCategory.OBJECTIVE)
        directions = []
        for name in objective_names:
            meta = self.get_variable_metadata(name)
            if isinstance(meta, Objective):
                directions.append(meta.direction)

        mask = None
        if from_set:
            source_set = self.get_set(from_set)
            mask = np.zeros(self.n_points, dtype=bool)
            mask[source_set.indices] = True

        # Efficient export to numpy
        objectives_np = self._objectives.to_numpy()

        pareto_mask = identify_pareto_front(objectives_np, directions, mask=mask)
        pareto_indices = np.where(pareto_mask)[0].tolist()

        return self.create_set(
            name=set_name,
            indices=pareto_indices,
            created_by="analysis.pareto",
            description="Pareto optimal solutions.",
        )

    def check_feasibility(
        self,
        set_name: str = "feasible",
        from_set: str | None = None,
    ) -> ResultSet:
        from optiscope.analysis.feasibility import check_feasibility as check_feasibility_func

        mask = None
        if from_set:
            source_set = self.get_set(from_set)
            mask = np.zeros(self.n_points, dtype=bool)
            mask[source_set.indices] = True

        feasible_mask = check_feasibility_func(self, mask=mask)
        feasible_indices = np.where(feasible_mask)[0].tolist()

        return self.create_set(
            name=set_name,
            indices=feasible_indices,
            created_by="analysis.feasibility",
            description="Feasible solutions.",
        )

    def rank_with_wsm(
        self,
        weights: dict[str, float],
    ) -> pd.Series:
        from optiscope.analysis.mcda import weighted_sum_method

        if self._objectives.is_empty():
            raise ValueError("Cannot rank without objectives.")

        objective_names = list(weights.keys())
        weight_values = np.array(list(weights.values()))

        directions = []
        for name in objective_names:
            meta = self.get_variable_metadata(name)
            if not isinstance(meta, Objective):
                raise ValueError(f"'{name}' is not a valid objective.")
            directions.append(meta.direction)

        # Narwhals used to select columns before exporting
        data_subset = nw.from_native(self._objectives).select(objective_names).to_pandas()

        scores = weighted_sum_method(data_subset, directions, weight_values)

        return pd.Series(scores, index=data_subset.index, name="wsm_score")

    # Utility methods
    def get_all_data(self) -> pd.DataFrame:
        """Get all data as a single Pandas DataFrame."""
        data_frames = []

        # Collect all potential frames
        candidates = [
            self._design_variables,
            self._objectives,
            self._inequality_constraints,
            self._equality_constraints,
            self._observables,
        ]

        # Add custom data values
        candidates.extend(self._custom_data.values())

        for df in candidates:
            # FIX: Use len() which works for both Polars and Pandas.
            # Polars .is_empty() crashes on Pandas; Pandas .empty crashes on Polars (if used as method).
            if len(df) > 0:
                data_frames.append(df)

        if not data_frames:
            return pd.DataFrame()

        # Narwhals horizontal concatenation
        # This part handles mixed Pandas/Polars inputs correctly
        nw_frames = [nw.from_native(df) for df in data_frames]
        return nw.concat(nw_frames, how="horizontal").to_pandas()

    def summary(self) -> dict[str, Any]:
        return {
            "problem_name": self.problem_metadata.name,
            "solver": self.problem_metadata.solver,
            "n_points": self.n_points,
            "n_design_variables": len(self._design_variables.columns),
            "n_objectives": len(self._objectives.columns),
            "n_inequality_constraints": len(self._inequality_constraints.columns),
            "n_equality_constraints": len(self._equality_constraints.columns),
            "n_observables": len(self._observables.columns),
            "n_custom_data": len(self._custom_data),
            "n_sets": len(self.list_sets()),
            "run_date": self.problem_metadata.run_date.isoformat(),
        }

    def __repr__(self) -> str:
        summary = self.summary()
        return (
            f"OptimizationResult(problem='{summary['problem_name']}', "
            f"n_points={summary['n_points']}, "
            f"n_objectives={summary['n_objectives']}, "
            f"n_design_vars={summary['n_design_variables']})"
        )
