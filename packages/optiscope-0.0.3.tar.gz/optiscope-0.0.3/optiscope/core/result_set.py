"""
Result set management for creating and managing subsets of optimization data.

Result sets allow users to create named subsets of optimization results
for focused analysis, comparison, and decision making.
"""

from __future__ import annotations

from datetime import datetime
from typing import Any

import numpy as np
from pydantic import BaseModel, Field


class SetOperation(BaseModel):
    """Record of an operation that created or modified a set."""

    operation: str = Field(..., description="Type of operation (filter, union, etc.)")
    timestamp: datetime = Field(default_factory=datetime.now)
    parameters: dict[str, Any] = Field(
        default_factory=dict, description="Parameters used in the operation"
    )
    description: str | None = Field(None, description="Human-readable description")


class ResultSet(BaseModel):
    """
    A named subset of optimization results.

    Result sets reference indices in the parent OptimizationResult and can be
    created through filtering, manual selection, or algorithmic identification
    (e.g., Pareto front detection).
    """

    name: str = Field(..., description="Unique name for this set")
    indices: list[int] = Field(..., description="Indices into parent result data")
    created_by: str = Field(..., description="Module/page that created this set")
    created_at: datetime = Field(default_factory=datetime.now)
    description: str | None = Field(None, description="Description of this set")

    # Set properties
    color: str | None = Field(None, description="Display color for plots")
    is_locked: bool = Field(default=False, description="Prevent modifications")

    # Metadata and history
    metadata: dict[str, Any] = Field(default_factory=dict, description="Additional metadata")
    operations: list[SetOperation] = Field(
        default_factory=list, description="History of operations"
    )
    parent_set: str | None = Field(None, description="Name of parent set if derived from another")

    class Config:
        json_encoders = {datetime: lambda v: v.isoformat()}

    def __len__(self) -> int:
        """Return number of points in set."""
        return len(self.indices)

    def add_operation(
        self, operation: str, parameters: dict[str, Any], description: str | None = None
    ) -> None:
        """
        Record an operation in the set's history.

        Args:
            operation: Type of operation
            parameters: Operation parameters
            description: Optional description
        """
        self.operations.append(
            SetOperation(operation=operation, parameters=parameters, description=description)
        )

    def union(self, other: ResultSet, name: str) -> ResultSet:
        """
        Create a new set as the union of this set and another.

        Args:
            other: Another ResultSet
            name: Name for the new set

        Returns:
            New ResultSet containing union of indices
        """
        union_indices = sorted(set(self.indices) | set(other.indices))
        new_set = ResultSet(
            name=name,
            indices=union_indices,
            created_by=f"{self.created_by}+{other.created_by}",
            description=f"Union of '{self.name}' and '{other.name}'",
            color=None,
            parent_set=None,
        )
        new_set.add_operation(
            "union",
            {"sets": [self.name, other.name]},
            f"Union of {len(self)} and {len(other)} points",
        )
        return new_set

    def intersection(self, other: ResultSet, name: str) -> ResultSet:
        """
        Create a new set as the intersection of this set and another.

        Args:
            other: Another ResultSet
            name: Name for the new set

        Returns:
            New ResultSet containing intersection of indices
        """
        intersect_indices = sorted(set(self.indices) & set(other.indices))
        new_set = ResultSet(
            name=name,
            indices=intersect_indices,
            created_by=f"{self.created_by}+{other.created_by}",
            description=f"Intersection of '{self.name}' and '{other.name}'",
            color=None,
            parent_set=None,
        )
        new_set.add_operation(
            "intersection",
            {"sets": [self.name, other.name]},
            f"Intersection of {len(self)} and {len(other)} points",
        )
        return new_set

    def difference(self, other: ResultSet, name: str) -> ResultSet:
        """
        Create a new set as the difference (this - other).

        Args:
            other: Another ResultSet
            name: Name for the new set

        Returns:
            New ResultSet containing difference of indices
        """
        diff_indices = sorted(set(self.indices) - set(other.indices))
        new_set = ResultSet(
            name=name,
            indices=diff_indices,
            created_by=self.created_by,
            description=f"Difference '{self.name}' - '{other.name}'",
            color=None,
            parent_set=None,
        )
        new_set.add_operation(
            "difference",
            {"sets": [self.name, other.name]},
            f"Removed {len(other)} points from {len(self)} points",
        )
        return new_set

    def filter_by_mask(
        self, mask: np.ndarray, name: str, description: str | None = None
    ) -> ResultSet:
        """
        Create a new set by filtering current set with a boolean mask.

        Args:
            mask: Boolean mask array (length must match this set)
            name: Name for new set
            description: Optional description

        Returns:
            New filtered ResultSet
        """
        if len(mask) != len(self.indices):
            raise ValueError(f"Mask length {len(mask)} must match set size {len(self.indices)}")

        filtered_indices = [idx for idx, keep in zip(self.indices, mask) if keep]
        new_set = ResultSet(
            name=name,
            indices=filtered_indices,
            created_by=self.created_by,
            parent_set=self.name,
            description=description or f"Filtered from '{self.name}'",
            color=None,
        )
        new_set.add_operation(
            "filter",
            {"parent": self.name, "kept": len(filtered_indices), "total": len(self)},
            f"Filtered to {len(filtered_indices)} points",
        )
        return new_set

    def to_dict(self) -> dict[str, Any]:
        """Export set as dictionary."""
        return {
            "name": self.name,
            "indices": self.indices,
            "created_by": self.created_by,
            "created_at": self.created_at.isoformat(),
            "description": self.description,
            "color": self.color,
            "is_locked": self.is_locked,
            "metadata": self.metadata,
            "operations": [op.model_dump(mode="json") for op in self.operations],
            "parent_set": self.parent_set,
            "size": len(self),
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> ResultSet:
        """Create ResultSet from dictionary."""
        # Convert operations
        if "operations" in data:
            data["operations"] = [
                SetOperation(**op) if isinstance(op, dict) else op for op in data["operations"]
            ]

        # Remove computed fields
        data.pop("size", None)

        # Convert datetime strings
        if isinstance(data.get("created_at"), str):
            data["created_at"] = datetime.fromisoformat(data["created_at"])

        return cls(**data)


class SetManager:
    """
    Manager for handling multiple result sets.

    Provides utilities for creating, managing, and performing operations
    on collections of result sets.
    """

    def __init__(self) -> None:
        self.sets: dict[str, ResultSet] = {}

    def add_set(self, result_set: ResultSet) -> None:
        """Add a result set to the manager."""
        if result_set.name in self.sets:
            raise ValueError(f"Set '{result_set.name}' already exists")
        self.sets[result_set.name] = result_set

    def get_set(self, name: str) -> ResultSet:
        """Get a result set by name."""
        if name not in self.sets:
            raise KeyError(f"Set '{name}' not found")
        return self.sets[name]

    def remove_set(self, name: str) -> None:
        """Remove a result set."""
        if name not in self.sets:
            raise KeyError(f"Set '{name}' not found")

        result_set = self.sets[name]
        if result_set.is_locked:
            raise ValueError(f"Cannot remove locked set '{name}'")

        del self.sets[name]

    def list_sets(self) -> list[str]:
        """List all set names."""
        return list(self.sets.keys())

    def get_all_sets(self) -> list[ResultSet]:
        """Get all sets."""
        return list(self.sets.values())

    def get_sets_by_creator(self, created_by: str) -> list[ResultSet]:
        """Get all sets created by a specific module."""
        return [s for s in self.sets.values() if s.created_by == created_by]

    def clear(self) -> None:
        """Remove all unlocked sets."""
        self.sets = {name: s for name, s in self.sets.items() if s.is_locked}

    def to_dict(self) -> dict[str, Any]:
        """Export all sets as dictionary."""
        return {name: s.to_dict() for name, s in self.sets.items()}

    def from_dict(self, data: dict[str, Any]) -> None:
        """Load sets from dictionary."""
        self.sets = {name: ResultSet.from_dict(set_data) for name, set_data in data.items()}
