"""
Core data types for optimization results.

This module defines the fundamental data types used to represent different
aspects of optimization problems: design variables, objectives, constraints,
observables, and extensible custom data types.
"""

from __future__ import annotations

from enum import Enum
from typing import Any

from pydantic import BaseModel, Field, field_validator


class DataTypeCategory(str, Enum):
    """Categories of data in optimization results."""

    DESIGN_VARIABLE = "design_variable"
    OBJECTIVE = "objective"
    CONSTRAINT = "constraint"
    OBSERVABLE = "observable"
    CUSTOM = "custom"


class OptimizationDirection(str, Enum):
    """Direction of optimization for objectives."""

    MINIMIZE = "minimize"
    MAXIMIZE = "maximize"


class ConstraintType(str, Enum):
    """Types of constraints."""

    INEQUALITY = "inequality"  # g(x) <= 0
    EQUALITY = "equality"  # h(x) = 0
    BOUND = "bound"  # lower <= x <= upper


class VariableMetadata(BaseModel):
    """Base metadata for any variable/parameter in optimization."""

    name: str = Field(..., description="Variable name")
    description: str | None = Field(None, description="Human-readable description")
    units: str | None = Field(None, description="Physical units")
    category: DataTypeCategory = Field(..., description="Data type category")

    # Optional bounds/limits
    lower_bound: float | None = Field(None, description="Lower bound")
    upper_bound: float | None = Field(None, description="Upper bound")

    # Additional metadata
    metadata: dict[str, Any] = Field(default_factory=dict, description="Extra metadata")

    @field_validator("name")
    @classmethod
    def validate_name(cls, v: str) -> str:
        """Ensure name is valid identifier."""
        if not v or not v.strip():
            raise ValueError("Name cannot be empty")
        return v.strip()

    class Config:
        use_enum_values = True


class DesignVariable(VariableMetadata):
    """Metadata for a design variable (decision variable)."""

    category: DataTypeCategory = Field(default=DataTypeCategory.DESIGN_VARIABLE, frozen=True)

    # Design variable specific
    is_discrete: bool = Field(default=False, description="Whether variable is discrete")
    possible_values: list[float] | None = Field(
        None, description="List of possible values for discrete variables"
    )
    initial_value: float | None = Field(None, description="Initial/default value")


class Objective(VariableMetadata):
    """Metadata for an objective function."""

    category: DataTypeCategory = Field(default=DataTypeCategory.OBJECTIVE, frozen=True)

    # Objective specific
    direction: OptimizationDirection = Field(
        default=OptimizationDirection.MINIMIZE, description="Direction of optimization"
    )
    ideal_value: float | None = Field(None, description="Ideal/utopia value")
    nadir_value: float | None = Field(None, description="Nadir/worst value")

    def normalize_value(self, value: float) -> float:
        """
        Normalize objective value to [0, 1] range if ideal and nadir are known.

        Args:
            value: Raw objective value

        Returns:
            Normalized value (0=ideal, 1=nadir)
        """
        if self.ideal_value is None or self.nadir_value is None:
            return value

        if abs(self.nadir_value - self.ideal_value) < 1e-10:
            return 0.0

        return (value - self.ideal_value) / (self.nadir_value - self.ideal_value)


class Constraint(VariableMetadata):
    """Metadata for a constraint."""

    category: DataTypeCategory = Field(default=DataTypeCategory.CONSTRAINT, frozen=True)

    # Constraint specific
    constraint_type: ConstraintType = Field(
        default=ConstraintType.INEQUALITY, description="Type of constraint"
    )
    tolerance: float = Field(default=1e-6, description="Constraint violation tolerance")
    reference_value: float = Field(
        default=0.0, description="Reference value (RHS for inequality/equality)"
    )

    def is_violated(self, value: float) -> bool:
        """
        Check if constraint is violated.

        Args:
            value: Constraint function value

        Returns:
            True if constraint is violated
        """
        if self.constraint_type == ConstraintType.EQUALITY:
            return abs(value - self.reference_value) > self.tolerance
        elif self.constraint_type == ConstraintType.INEQUALITY:
            # g(x) <= reference_value
            return value > self.reference_value + self.tolerance
        elif self.constraint_type == ConstraintType.BOUND:
            if self.lower_bound is not None and value < self.lower_bound - self.tolerance:
                return True
            if self.upper_bound is not None and value > self.upper_bound + self.tolerance:
                return True
        return False


class Observable(VariableMetadata):
    """
    Metadata for an observable (computed quantity that's not an objective or constraint).

    Observables are additional quantities computed during optimization that
    may be useful for analysis but don't directly affect the optimization.
    """

    category: DataTypeCategory = Field(default=DataTypeCategory.OBSERVABLE, frozen=True)

    # Observable specific
    computation_source: str | None = Field(
        None, description="Source/formula for computing this observable"
    )


class CustomDataType(VariableMetadata):
    """
    Metadata for custom/user-defined data types.

    This allows users to add arbitrary data types beyond the standard categories.
    """

    category: DataTypeCategory = Field(default=DataTypeCategory.CUSTOM, frozen=True)

    custom_type: str = Field(..., description="Custom type identifier")
    # schema: Optional[dict[str, Any]] = Field(
    #     None, description="Optional JSON schema for validation"
    # )


# Type alias for any variable metadata
AnyVariableMetadata = DesignVariable | Objective | Constraint | Observable | CustomDataType
