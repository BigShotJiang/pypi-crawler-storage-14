"""
Pareto front identification for multi-objective optimization results.

This module provides algorithms to identify the Pareto optimal set from a collection
of solutions.

The Pareto front identification algorithms are based on the implementations from:
# Source - https://stackoverflow.com/a/40239615
# Posted by Peter, modified by community. See post 'Timeline' for change history
# Retrieved 2025-11-07, License - CC BY-SA 4.0
#
# Additional implementations and optimizations from:
# https://github.com/QUVA-Lab/artemis/blob/peter/artemis/general/pareto_efficiency.py
"""

from __future__ import annotations

import numpy as np

from optiscope.core.data_types import OptimizationDirection


def is_pareto_efficient_dumb(
    objectives: np.ndarray, directions: list[OptimizationDirection] | None = None
) -> np.ndarray:
    """
    Find the pareto-efficient points. This is a slow implementation, but easy to
    understand.

    Args:
        objectives: An (n_points, n_objectives) array.
        directions: A list of optimization directions for each objective.
                    If None, all objectives are assumed to be minimization.

    Returns:
        A (n_points, ) boolean array, indicating whether each point is Pareto efficient.
    """
    costs = np.copy(objectives)
    if directions:
        for i, direction in enumerate(directions):
            if direction == OptimizationDirection.MAXIMIZE:
                costs[:, i] *= -1

    is_efficient = np.ones(costs.shape[0], dtype=bool)
    for i, c in enumerate(costs):
        is_efficient[i] = np.all(np.any(costs[:i] > c, axis=1)) and np.all(
            np.any(costs[i + 1 :] > c, axis=1)
        )
    return is_efficient


def is_pareto_efficient_simple(
    objectives: np.ndarray, directions: list[OptimizationDirection] | None = None
) -> np.ndarray:
    """
    Find the pareto-efficient points. Fairly fast for many datapoints, less so for many
    costs.

    Args:
        objectives: An (n_points, n_objectives) array.
        directions: A list of optimization directions for each objective.
                    If None, all objectives are assumed to be minimization.

    Returns:
        A (n_points, ) boolean array, indicating whether each point is Pareto efficient.
    """
    costs = np.copy(objectives)
    if directions:
        for i, direction in enumerate(directions):
            if direction == OptimizationDirection.MAXIMIZE:
                costs[:, i] *= -1

    is_efficient = np.ones(costs.shape[0], dtype=bool)
    for i, c in enumerate(costs):
        if is_efficient[i]:
            is_efficient[is_efficient] = np.any(
                costs[is_efficient] < c, axis=1
            )  # Keep any point with a lower cost
            is_efficient[i] = True  # And keep self
    return is_efficient


def is_pareto_efficient(
    objectives: np.ndarray,
    directions: list[OptimizationDirection] | None = None,
    return_mask: bool = True,
) -> np.ndarray | list[int]:
    """
    Find the pareto-efficient points. Faster than is_pareto_efficient_simple, but less
    readable.

    Args:
        objectives: An (n_points, n_objectives) array.
        directions: A list of optimization directions for each objective.
                    If None, all objectives are assumed to be minimization.
        return_mask: True to return a boolean mask of shape (n_points, ).

    Returns:
        - If `return_mask` is True: An (n_points, ) boolean array.
        - If `return_mask` is False: A (n_efficient_points, ) integer array of indices.
    """
    costs = np.copy(objectives)
    if directions:
        for i, direction in enumerate(directions):
            if direction == OptimizationDirection.MAXIMIZE:
                costs[:, i] *= -1

    is_efficient_indices = np.arange(costs.shape[0])
    n_points = costs.shape[0]
    next_point_index = 0  # Next index in the is_efficient array to search for

    while next_point_index < len(costs):
        nondominated_point_mask = np.any(costs < costs[next_point_index], axis=1)
        nondominated_point_mask[next_point_index] = True
        is_efficient_indices = is_efficient_indices[
            nondominated_point_mask
        ]  # Remove dominated points
        costs = costs[nondominated_point_mask]
        next_point_index = np.sum(nondominated_point_mask[:next_point_index]) + 1

    if return_mask:
        is_efficient_mask = np.zeros(n_points, dtype=bool)
        is_efficient_mask[is_efficient_indices] = True
        return is_efficient_mask
    else:
        return is_efficient_indices


def is_pareto_efficient_auto(
    objectives: np.ndarray, directions: list[OptimizationDirection] | None = None
) -> np.ndarray:
    """
    Automatically selects an efficient Pareto front algorithm based on data shape.

    - For a high number of objectives, a simple direct comparison is faster.
    - For a large number of solutions, a more complex algorithm with reordering is
      more efficient.

    Args:
        objectives: An (n_points, n_objectives) array.
        directions: A list of optimization directions for each objective.
                    If None, all objectives are assumed to be minimization.

    Returns:
        A (n_points, ) boolean array, indicating whether each point is Pareto efficient.
    """
    n_points, n_costs = objectives.shape

    if directions is None:
        directions = [OptimizationDirection.MINIMIZE] * n_costs

    if n_costs > 10 and n_points < 10000:
        return is_pareto_efficient_dumb(objectives, directions)

    # Reorder to gain a ~2x speedup on larger datasets
    costs = np.copy(objectives)
    for i, direction in enumerate(directions):  # type: ignore
        if direction == OptimizationDirection.MAXIMIZE:
            costs[:, i] *= -1

    ixs = np.argsort(((costs - costs.mean(axis=0)) / (costs.std(axis=0) + 1e-7)).sum(axis=1))
    reordered_costs = costs[ixs]
    # Pass empty directions list because costs are already adjusted
    is_efficient_mask = is_pareto_efficient(reordered_costs, directions=None, return_mask=True)

    # Un-reorder the mask to match the original order
    final_mask = np.zeros_like(is_efficient_mask)
    final_mask[ixs] = is_efficient_mask
    return final_mask


def identify_pareto_front(
    objectives: np.ndarray,
    directions: list[OptimizationDirection] | None = None,
    mask: np.ndarray | None = None,
) -> np.ndarray:
    """
    Identifies the Pareto optimal front from a set of objective values.

    Args:
        objectives: A 2D array of objective values (n_solutions, n_objectives).
        directions: A list of optimization directions for each objective.
                    If None, all objectives are assumed to be minimization.
        mask: A boolean array indicating which solutions to consider.
              If None, all solutions are considered.

    Returns:
        A boolean array where True indicates a solution is on the Pareto front.
    """
    if objectives.ndim != 2:
        raise ValueError("objectives must be a 2D array")

    if directions is None:
        directions = [OptimizationDirection.MINIMIZE] * objectives.shape[1]

    if objectives.shape[1] != len(directions):  # type: ignore
        raise ValueError("Mismatch between number of objectives and directions")

    n_solutions = objectives.shape[0]
    if mask is None:
        is_candidate = np.ones(n_solutions, dtype=bool)
    else:
        is_candidate = mask.copy()

    # Filter objectives to only consider candidates
    candidate_objectives = objectives[is_candidate]

    if candidate_objectives.shape[0] == 0:
        return np.zeros(n_solutions, dtype=bool)

    # Identify Pareto front on the candidates
    pareto_mask_candidates = is_pareto_efficient_auto(candidate_objectives, directions)

    # Map the Pareto mask back to the original array size
    is_pareto = np.zeros(n_solutions, dtype=bool)
    candidate_indices = np.where(is_candidate)[0]
    pareto_indices = candidate_indices[pareto_mask_candidates]
    is_pareto[pareto_indices] = True

    return is_pareto
