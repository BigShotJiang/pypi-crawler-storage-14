"""
Knee point detection for Pareto fronts.

Implements multiple methods for identifying "knee" points - solutions
that represent the best compromise between competing objectives.
"""

from __future__ import annotations

import numpy as np
import pandas as pd
from scipy.spatial.distance import cdist


def detect_knee_points(
    objectives: np.ndarray | pd.DataFrame,
    method: str = "angle",
    n_knees: int = 1,
    normalize: bool = True,
) -> np.ndarray:
    """
    Detect knee points on Pareto front.

    A knee point represents the best compromise - maximum trade-off benefit
    per unit sacrifice. These are often the most preferred solutions.

    Args:
        objectives: Array or DataFrame of objective values (assumed minimization)
        method: Detection method ('angle', 'distance', 'tradeoff', 'curvature')
        n_knees: Number of knee points to detect
        normalize: Whether to normalize objectives to [0,1]

    Returns:
        Array of indices of knee points, sorted by knee quality (best first)
    """
    # Convert to numpy array
    if isinstance(objectives, pd.DataFrame):
        obj_array = objectives.values
    else:
        obj_array = np.asarray(objectives)

    if obj_array.shape[1] != 2:
        raise ValueError("Knee detection currently only supports 2D objectives")

    n_points = len(obj_array)

    if n_points == 0:
        return np.array([], dtype=int)

    if n_points <= 2:
        return np.arange(n_points)

    # Normalize if requested
    if normalize:
        obj_min = obj_array.min(axis=0)
        obj_max = obj_array.max(axis=0)
        obj_range = obj_max - obj_min
        obj_range[obj_range < 1e-10] = 1.0
        obj_normalized = (obj_array - obj_min) / obj_range
    else:
        obj_normalized = obj_array.copy()

    # Sort by first objective for ordered Pareto front
    sort_idx = np.argsort(obj_normalized[:, 0])
    obj_sorted = obj_normalized[sort_idx]

    # Apply selected method
    if method == "angle":
        knee_scores = _angle_based_knee_detection(obj_sorted)
    elif method == "distance":
        knee_scores = _distance_based_knee_detection(obj_sorted)
    elif method == "tradeoff":
        knee_scores = _tradeoff_based_knee_detection(obj_sorted)
    elif method == "curvature":
        knee_scores = _curvature_based_knee_detection(obj_sorted)
    else:
        raise ValueError(f"Unknown method: {method}")

    # Get top n_knees
    top_knee_indices = np.argsort(knee_scores)[::-1][:n_knees]

    # Convert back to original indices
    original_indices = sort_idx[top_knee_indices]

    return original_indices


def _angle_based_knee_detection(objectives: np.ndarray) -> np.ndarray:
    """
    Detect knees based on angle between consecutive line segments.

    Large angles indicate sharp turns (knees).
    """
    n_points = len(objectives)
    angles = np.zeros(n_points)

    for i in range(1, n_points - 1):
        # Vectors from point i to neighbors
        v1 = objectives[i] - objectives[i - 1]
        v2 = objectives[i + 1] - objectives[i]

        # Normalize vectors
        v1_norm = v1 / (np.linalg.norm(v1) + 1e-10)
        v2_norm = v2 / (np.linalg.norm(v2) + 1e-10)

        # Calculate angle (using dot product)
        cos_angle = np.clip(np.dot(v1_norm, v2_norm), -1.0, 1.0)
        angle = np.arccos(cos_angle)

        # Larger angle = more knee-like
        angles[i] = angle

    return angles


def _distance_based_knee_detection(objectives: np.ndarray) -> np.ndarray:
    """
    Detect knees based on distance from line connecting extremes.

    Points farthest from the ideal line are potential knees.
    """
    n_points = len(objectives)

    if n_points < 3:
        return np.zeros(n_points)

    # Line from first to last point
    p1 = objectives[0]
    p2 = objectives[-1]

    # Calculate perpendicular distance for each point
    distances = np.zeros(n_points)

    line_vec = p2 - p1
    line_length = np.linalg.norm(line_vec)

    if line_length < 1e-10:
        return distances

    for i in range(n_points):
        point_vec = objectives[i] - p1
        # Project onto line
        projection = np.dot(point_vec, line_vec) / line_length**2
        projection = np.clip(projection, 0, 1)
        closest_point = p1 + projection * line_vec
        # Distance to line
        distances[i] = np.linalg.norm(objectives[i] - closest_point)

    return distances


def _tradeoff_based_knee_detection(objectives: np.ndarray) -> np.ndarray:
    """
    Detect knees based on trade-off rate changes.

    Knee points have maximum change in the trade-off ratio df2/df1.
    """
    n_points = len(objectives)
    tradeoff_changes = np.zeros(n_points)

    for i in range(1, n_points - 1):
        # Trade-off before point i
        df1_before = objectives[i, 0] - objectives[i - 1, 0]
        df2_before = objectives[i, 1] - objectives[i - 1, 1]
        tradeoff_before = abs(df2_before / (df1_before + 1e-10))

        # Trade-off after point i
        df1_after = objectives[i + 1, 0] - objectives[i, 0]
        df2_after = objectives[i + 1, 1] - objectives[i, 1]
        tradeoff_after = abs(df2_after / (df1_after + 1e-10))

        # Change in trade-off rate
        tradeoff_changes[i] = abs(tradeoff_after - tradeoff_before)

    return tradeoff_changes


def _curvature_based_knee_detection(objectives: np.ndarray) -> np.ndarray:
    """
    Detect knees based on curvature of the Pareto front.

    High curvature indicates knee regions.
    """
    n_points = len(objectives)

    if n_points < 5:
        # Need enough points for curvature estimation
        return _angle_based_knee_detection(objectives)

    curvatures = np.zeros(n_points)

    # Use finite differences to estimate curvature
    for i in range(2, n_points - 2):
        # Use 5-point stencil for better estimation
        points = objectives[i - 2 : i + 3]

        # Fit local polynomial and estimate curvature
        # Simplified: use angle method on local neighborhood
        local_angles = _angle_based_knee_detection(points)
        curvatures[i] = local_angles[2]  # Middle point

    return curvatures


def find_knee_region(
    objectives: np.ndarray | pd.DataFrame,
    width: float = 0.1,
    method: str = "angle",
    normalize: bool = True,
) -> tuple[np.ndarray, float, float]:
    """
    Find knee region instead of single point.

    Returns a region around the knee point where solutions are similar.

    Args:
        objectives: Objective values
        width: Width of knee region (as fraction of normalized space)
        method: Knee detection method
        normalize: Normalize objectives

    Returns:
        Tuple of (indices in knee region, region_start, region_end)
    """
    # Find primary knee point
    knee_idx = detect_knee_points(objectives, method=method, n_knees=1, normalize=normalize)[0]

    # Convert to numpy
    if isinstance(objectives, pd.DataFrame):
        obj_array = objectives.values
    else:
        obj_array = np.asarray(objectives)

    # Normalize
    if normalize:
        obj_min = obj_array.min(axis=0)
        obj_max = obj_array.max(axis=0)
        obj_range = obj_max - obj_min
        obj_range[obj_range < 1e-10] = 1.0
        obj_normalized = (obj_array - obj_min) / obj_range
    else:
        obj_normalized = obj_array

    # Find points within width of knee point
    knee_point = obj_normalized[knee_idx]
    distances = np.linalg.norm(obj_normalized - knee_point, axis=1)

    region_indices = np.where(distances <= width)[0]

    # Calculate region bounds in normalized space
    if len(region_indices) > 0:
        region_points = obj_normalized[region_indices]
        region_start = region_points[:, 0].min()
        region_end = region_points[:, 0].max()
    else:
        region_start = region_end = knee_point[0]

    return region_indices, region_start, region_end


def rank_by_knee_distance(
    objectives: np.ndarray | pd.DataFrame, knee_indices: np.ndarray, normalize: bool = True
) -> np.ndarray:
    """
    Rank all solutions by distance to nearest knee point.

    Args:
        objectives: Objective values
        knee_indices: Indices of knee points
        normalize: Normalize objectives

    Returns:
        Array of ranks (0 = on knee, higher = farther from knee)
    """
    if isinstance(objectives, pd.DataFrame):
        obj_array = objectives.values
    else:
        obj_array = np.asarray(objectives)

    # Normalize
    if normalize:
        obj_min = obj_array.min(axis=0)
        obj_max = obj_array.max(axis=0)
        obj_range = obj_max - obj_min
        obj_range[obj_range < 1e-10] = 1.0
        obj_normalized = (obj_array - obj_min) / obj_range
    else:
        obj_normalized = obj_array

    # Calculate distance to nearest knee
    knee_points = obj_normalized[knee_indices]
    distances = cdist(obj_normalized, knee_points)
    min_distances = distances.min(axis=1)

    # Rank by distance
    ranks = np.argsort(min_distances)

    return ranks


def calculate_knee_quality_metrics(
    objectives: np.ndarray | pd.DataFrame, knee_indices: np.ndarray, normalize: bool = True
) -> dict:
    """
    Calculate quality metrics for detected knee points.

    Args:
        objectives: Objective values
        knee_indices: Detected knee point indices
        normalize: Normalize objectives

    Returns:
        Dictionary with quality metrics
    """
    if isinstance(objectives, pd.DataFrame):
        obj_array = objectives.values
    else:
        obj_array = np.asarray(objectives)

    if normalize:
        obj_min = obj_array.min(axis=0)
        obj_max = obj_array.max(axis=0)
        obj_range = obj_max - obj_min
        obj_range[obj_range < 1e-10] = 1.0
        obj_normalized = (obj_array - obj_min) / obj_range
    else:
        obj_normalized = obj_array

    knee_points = obj_normalized[knee_indices]

    # Distance from ideal point (origin in normalized space)
    ideal_point = np.zeros(obj_array.shape[1])
    distances_to_ideal = np.linalg.norm(knee_points - ideal_point, axis=1)

    # Distance from nadir point
    nadir_point = np.ones(obj_array.shape[1])
    distances_to_nadir = np.linalg.norm(knee_points - nadir_point, axis=1)

    # Balance score (how centered between ideal and nadir)
    balance_scores = 1 - abs(distances_to_ideal - distances_to_nadir)

    # Spread of knee points
    if len(knee_indices) > 1:
        knee_distances = cdist(knee_points, knee_points)
        np.fill_diagonal(knee_distances, np.inf)
        min_separation = knee_distances.min()
        max_separation = knee_distances.max()
    else:
        min_separation = max_separation = 0.0

    return {
        "n_knees": len(knee_indices),
        "avg_distance_to_ideal": float(distances_to_ideal.mean()),
        "avg_distance_to_nadir": float(distances_to_nadir.mean()),
        "avg_balance_score": float(balance_scores.mean()),
        "min_knee_separation": float(min_separation),
        "max_knee_separation": float(max_separation),
        "knee_indices": knee_indices.tolist(),
    }
