"""
Analysis tools for optimization results.

This package provides algorithms and utilities for analyzing optimization results:
- Pareto front identification
- Smart Pareto filtering for representative subset selection
- Knee point detection for identifying best compromise solutions
- TOPSIS for multi-criteria decision making
- Quality metrics (hypervolume, IGD, etc.)
"""

from .feasibility import check_feasibility
from .knee_detection import (
    calculate_knee_quality_metrics,
    detect_knee_points,
    find_knee_region,
    rank_by_knee_distance,
)
from .pareto import identify_pareto_front
from .smart_pareto import (
    adaptive_smart_pareto_filter,
    calculate_coverage_metric,
    smart_pareto_filter,
    visualize_filter_effect,
)
from .topsis import (
    compare_weight_scenarios,
    interactive_topsis,
    sensitivity_analysis_topsis,
    topsis,
    topsis_from_result,
)

__all__ = [
    # Pareto Front
    "identify_pareto_front",
    # Smart Pareto Filter
    "smart_pareto_filter",
    "adaptive_smart_pareto_filter",
    "visualize_filter_effect",
    "calculate_coverage_metric",
    # Knee Detection
    "detect_knee_points",
    "find_knee_region",
    "rank_by_knee_distance",
    "calculate_knee_quality_metrics",
    # TOPSIS
    "topsis",
    "topsis_from_result",
    "interactive_topsis",
    "sensitivity_analysis_topsis",
    "compare_weight_scenarios",
    # Feasibility
    "check_feasibility",
]
