"""
Feasibility analysis for optimization results.

This module provides functions to check constraint violations and identify
feasible solutions.
"""

from __future__ import annotations

import typing

import numpy as np
import pandas as pd

from optiscope.core.data_types import Constraint

if typing.TYPE_CHECKING:
    from optiscope.core.data_model import OptimizationResult


def check_feasibility(
    result: OptimizationResult,
    mask: np.ndarray | None = None,
) -> np.ndarray:
    """
    Checks the feasibility of each solution based on its constraints.

    Args:
        result: An OptimizationResult object containing the data.
        mask: A boolean array indicating which solutions to consider.
              If None, all solutions are considered.

    Returns:
        A boolean array where True indicates a solution is feasible.
    """
    n_solutions = result.n_points
    if mask is None:
        is_feasible = np.ones(n_solutions, dtype=bool)
    else:
        is_feasible = mask.copy()

    # Combine inequality and equality constraints
    all_constraints = pd.concat(
        [result.inequality_constraints, result.equality_constraints], axis=1
    )

    if all_constraints.empty:
        return is_feasible

    for col_name in all_constraints.columns:
        constraint_meta = result.get_variable_metadata(col_name)
        if not isinstance(constraint_meta, Constraint):
            continue

        values = all_constraints[col_name].values

        for i in range(n_solutions):
            if is_feasible[i]:  # Only check if still considered feasible
                if constraint_meta.is_violated(values[i]):
                    is_feasible[i] = False

    return is_feasible
