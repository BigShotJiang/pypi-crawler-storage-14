"""
Multi-Criteria Decision Analysis (MCDA) methods.

This module provides various MCDA techniques to rank and select solutions from a
set of alternatives based on multiple criteria (objectives).
"""

from __future__ import annotations

import numpy as np
import pandas as pd

from optiscope.core.data_types import OptimizationDirection


def _normalize_objectives(
    objectives: pd.DataFrame, directions: list[OptimizationDirection]
) -> np.ndarray:
    """Normalize objectives to a [0, 1] scale."""
    norm_matrix = np.zeros_like(objectives, dtype=float)
    for i, col in enumerate(objectives.columns):
        vals = objectives[col].to_numpy()
        min_val, max_val = np.min(vals), np.max(vals)

        if max_val == min_val:
            norm_matrix[:, i] = 0.5  # Or 0, or 1, depending on preference
            continue

        if directions[i] == OptimizationDirection.MINIMIZE:
            # Lower is better: 0 for min, 1 for max
            norm_matrix[:, i] = (vals - min_val) / (max_val - min_val)
        else:  # MAXIMIZE
            # Higher is better: 1 for min, 0 for max
            norm_matrix[:, i] = (max_val - vals) / (max_val - min_val)
    return norm_matrix


def weighted_sum_method(
    objectives: pd.DataFrame,
    directions: list[OptimizationDirection],
    weights: np.ndarray,
) -> np.ndarray:
    """
    Ranks solutions using the Weighted Sum Model (WSM).

    Args:
        objectives: DataFrame of objective values (n_solutions, n_objectives).
        directions: A list of optimization directions for each objective.
        weights: An array of weights for each objective.

    Returns:
        An array of scores for each solution. Lower scores are better.
    """
    if objectives.shape[1] != len(weights):
        raise ValueError("Mismatch between number of objectives and weights")
    if not np.isclose(np.sum(weights), 1.0):
        raise ValueError("Weights must sum to 1.0")

    normalized_objectives = _normalize_objectives(objectives, directions)
    scores = np.sum(normalized_objectives * weights, axis=1)
    return scores
