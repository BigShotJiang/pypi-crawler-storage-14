"""
Preference-based Solution Classification.

This module implements classification methods to categorize solutions based on their
performance on individual objectives, including methods derived from Physical Programming (PRUF).

References:
    Chiu, W. Y., Yen, G. G., & Juan, T. K. (2016).
    Minimum Manhattan distance approach to multiple criteria decision making in multiobjective optimization problems.
    IEEE Transactions on Evolutionary Computation, 20(6), 972-985.

    Messac, A. (1996). Physical programming: Effective optimization for computational design.
    AIAA journal, 34(1), 149-158.
"""

from __future__ import annotations

from typing import Literal

import numpy as np
import pandas as pd

from ..core.data_model import OptimizationResult
from ..core.data_types import OptimizationDirection


def classify_solutions(
    objectives: np.ndarray | pd.DataFrame,
    directions: np.ndarray | list[str] | list[OptimizationDirection] | None = None,
    method: Literal["best", "worst"] = "best",
    return_names: bool = False,
) -> np.ndarray:
    """
    Classify solutions by their best or worst performant objective.

    This classification helps identify which objective a solution favors (best)
    or sacrifices (worst). It is often used in Hyper-Radial Visualization to
    group solutions into "cones" of dominance.

    Args:
        objectives: Array or DataFrame of objective values (n_solutions, n_objectives)
        directions: Optimization direction for each objective ('min' or 'max')
                   If None, assumes all minimization.
        method: Classification method ('best' or 'worst').
                'best': Classify by the objective with the most optimal value (after normalization).
                'worst': Classify by the objective with the least optimal value.
        return_names: If True and input is DataFrame, return column names instead of indices.

    Returns:
        Array of objective indices (or names) corresponding to the classification.
    """
    # Convert to numpy array
    if isinstance(objectives, pd.DataFrame):
        obj_array = objectives.values
        obj_names = objectives.columns.tolist()
    else:
        obj_array = np.asarray(objectives)
        obj_names = [f"f{i + 1}" for i in range(obj_array.shape[1])]

    n_solutions, n_objectives = obj_array.shape

    # Set default directions (all minimization)
    if directions is None:
        directions = np.array(["min"] * n_objectives)
    else:
        directions = np.asarray(directions)
        if len(directions) != n_objectives:
            raise ValueError("Number of directions must match objectives")

    # Normalize objectives to [0, 1] where 0 is ideal and 1 is anti-ideal

    # We want to map everything to a minimization problem where smaller is better
    # But for normalization to [0, 1], we need min and max of the dataset

    # Let's normalize each column to [0, 1] respecting direction
    normalized_matrix = np.zeros_like(obj_array)

    for i in range(n_objectives):
        col = obj_array[:, i]
        min_val = np.min(col)
        max_val = np.max(col)
        rng = max_val - min_val
        if rng < 1e-10:
            rng = 1.0

        direction = directions[i]
        if direction in ["max", "maximize", OptimizationDirection.MAXIMIZE]:
            # For maximization: (val - min) / (max - min) -> 1 is best, 0 is worst
            # But we want 0 to be ideal for "best" logic consistency with minimization?
            # Actually, let's define "performance score" where 1 is best, 0 is worst.
            normalized_matrix[:, i] = (col - min_val) / rng
        else:
            # For minimization: (max - val) / (max - min) -> 1 is best (min value), 0 is worst (max value)
            # Or standard min-max: (val - min) / rng -> 0 is best, 1 is worst.

            # Let's standardize on: 0 is Ideal (Best), 1 is Anti-Ideal (Worst)
            normalized_matrix[:, i] = (col - min_val) / rng

    # Now:
    # If direction was MIN: 0 is min (best), 1 is max (worst)
    # If direction was MAX: 0 is min (worst), 1 is max (best) -> We need to invert this

    for i, direction in enumerate(directions):
        if direction in ["max", "maximize", OptimizationDirection.MAXIMIZE]:
            # Invert so 0 becomes best (max value) and 1 becomes worst (min value)
            normalized_matrix[:, i] = 1.0 - normalized_matrix[:, i]

    # Now normalized_matrix contains "distance from ideal" (0 is ideal, 1 is anti-ideal)

    if method == "best":
        # We want the objective with the SMALLEST normalized value (closest to ideal)
        indices = np.argmin(normalized_matrix, axis=1)
    elif method == "worst":
        # We want the objective with the LARGEST normalized value (closest to anti-ideal)
        indices = np.argmax(normalized_matrix, axis=1)
    else:
        raise ValueError(f"Unknown method: {method}")

    if return_names:
        return np.array([obj_names[i] for i in indices])

    return indices


def classify_physical_programming(
    objectives: np.ndarray | pd.DataFrame,
    directions: np.ndarray | list[str] | list[OptimizationDirection] | None = None,
    method: Literal["best", "worst"] = "worst",
    categories: list[str] | None = None,
) -> np.ndarray:
    """
    Classify solutions using Physical Programming (PRUF) categories.

    Based on:
    Messac, A. (1996). Physical programming: Effective optimization for computational design.
    AIAA journal, 34(1), 149-158.

    And:
    Hyper-Radial Visualization for Multi-objective Decision-making Support Under Uncertainty
    Using Preference Ranges: The PRUF Method.

    Categories (default 5 equal ranges):
    1. Highly Desirable (0-20%)
    2. Desirable (20-40%)
    3. Tolerable (40-60%)
    4. Undesirable (60-80%)
    5. Highly Undesirable (80-100%)

    Args:
        objectives: Objective values
        directions: Optimization directions
        method: 'worst' (classify by worst performing objective) or 'best' (classify by best).
        categories: List of category names (must be 5).

    Returns:
        Array of category names for each solution.
    """
    if categories is None:
        categories = [
            "Highly Desirable",
            "Desirable",
            "Tolerable",
            "Undesirable",
            "Highly Undesirable",
        ]

    # Convert to numpy array
    if isinstance(objectives, pd.DataFrame):
        obj_array = objectives.values
    else:
        obj_array = np.asarray(objectives)

    n_solutions, n_objectives = obj_array.shape

    # Set default directions (all minimization)
    if directions is None:
        directions = np.array(["min"] * n_objectives)
    else:
        directions = np.asarray(directions)

    # Normalize objectives to [0, 1] where 0 is ideal and 1 is anti-ideal
    normalized_matrix = np.zeros_like(obj_array)

    for i in range(n_objectives):
        col = obj_array[:, i]
        min_val = np.min(col)
        max_val = np.max(col)
        rng = max_val - min_val
        if rng < 1e-10:
            rng = 1.0

        direction = directions[i]
        if direction in ["max", "maximize", OptimizationDirection.MAXIMIZE]:
            # Maximize: (val - min) / rng -> 1 is best. Invert to 0 is best.
            normalized_matrix[:, i] = 1.0 - ((col - min_val) / rng)
        else:
            # Minimize: (val - min) / rng -> 0 is best.
            normalized_matrix[:, i] = (col - min_val) / rng

    # Assign categories to each objective value
    # 0.0 - 0.2: Cat 0
    # 0.2 - 0.4: Cat 1
    # ...
    # 0.8 - 1.0: Cat 4

    # Multiply by 5 and floor to get index 0-4
    # Clip to 4 to handle 1.0 exactly
    category_indices = np.floor(normalized_matrix * 5).astype(int)
    category_indices = np.clip(category_indices, 0, 4)

    if method == "worst":
        # The solution classification is determined by the WORST category of any of its objectives.
        # Worst category has higher index (4 is Highly Undesirable).
        solution_cat_indices = np.max(category_indices, axis=1)
    elif method == "best":
        # The solution classification is determined by the BEST category of any of its objectives.
        # Best category has lower index (0 is Highly Desirable).
        solution_cat_indices = np.min(category_indices, axis=1)
    else:
        raise ValueError(f"Unknown method: {method}")

    return np.array([categories[i] for i in solution_cat_indices])


def classify_result(
    result: OptimizationResult,
    subset_name: str | None = None,
    method: Literal["best_obj", "worst_obj", "pruf_best", "pruf_worst"] = "best_obj",
    add_to_result: bool = False,
    new_column_name: str | None = None,
) -> np.ndarray:
    """
    Classify solutions in an OptimizationResult.

    Args:
        result: OptimizationResult object
        subset_name: Name of result set to analyze (if None, use all points)
        method: Classification method:
                - 'best_obj': Classify by the name of the best performing objective.
                - 'worst_obj': Classify by the name of the worst performing objective.
                - 'pruf_best': Classify by Physical Programming categories (optimistic).
                - 'pruf_worst': Classify by Physical Programming categories (pessimistic).
        add_to_result: If True, add the classification as a new column (variable) to the result.
        new_column_name: Name of the new column if add_to_result is True.

    Returns:
        Array of classification labels.
    """
    if result.objectives.empty:
        raise ValueError("No objectives found in result")

    # Get objectives data
    if subset_name and subset_name in result.sets:
        result_set = result.get_set(subset_name)
        objectives_data = result.objectives.iloc[result_set.indices]
    else:
        objectives_data = result.objectives

    obj_names = objectives_data.columns.tolist()

    # Extract directions from metadata
    directions = []
    for obj_name in obj_names:
        meta = result.get_variable_metadata(obj_name)
        if meta and hasattr(meta, "direction"):
            directions.append(meta.direction)
        else:
            directions.append("min")  # Default to minimization

    # Apply classification
    if method == "best_obj":
        classification = classify_solutions(
            objectives_data, directions=directions, method="best", return_names=True
        )
    elif method == "worst_obj":
        classification = classify_solutions(
            objectives_data, directions=directions, method="worst", return_names=True
        )
    elif method == "pruf_best":
        classification = classify_physical_programming(
            objectives_data, directions=directions, method="best"
        )
    elif method == "pruf_worst":
        classification = classify_physical_programming(
            objectives_data, directions=directions, method="worst"
        )
    else:
        raise ValueError(f"Unknown method: {method}")

    if add_to_result:
        if new_column_name is None:
            new_column_name = f"class_{method}"

        full_classification = np.full(result.n_points, None, dtype=object)

        if subset_name and subset_name in result.sets:
            full_classification[result_set.indices] = classification
        else:
            full_classification = classification

        # Add to result variables
        if new_column_name is None:
            new_column_name = f"class_{method}"

        result.add_column(new_column_name, full_classification)  # defaults to observable

    return classification
