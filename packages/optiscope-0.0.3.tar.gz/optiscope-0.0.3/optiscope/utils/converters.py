"""
Converters for transforming optimization results from various libraries into OptimizationResult.

This module provides helper functions to convert results from popular optimization
libraries (scipy, pymoo, etc.) into optiscope's OptimizationResult format with
appropriate metadata.
"""

from __future__ import annotations

from datetime import datetime
from typing import Any

import numpy as np

from optiscope.core.data_model import OptimizationResult, ProblemMetadata
from optiscope.core.data_types import (
    Constraint,
    ConstraintType,
    DataTypeCategory,
    DesignVariable,
    Objective,
    Observable,
    OptimizationDirection,
)


def from_scipy_minimize(
    result: Any,
    problem_name: str = "SciPy Optimization",
    variable_names: list[str] | None = None,
    objective_name: str = "objective",
    bounds: list[tuple[float, float]] | None = None,
    constraints_info: list[dict[str, Any]] | None = None,
    include_jacobian: bool = True,
    include_hessian: bool = False,
    description: str | None = None,
    **metadata_kwargs: Any,
) -> OptimizationResult:
    """Convert scipy.optimize.minimize result to OptimizationResult.

    Args:
        result: The result object from scipy.optimize.minimize
        problem_name: Name for the optimization problem
        variable_names: Names for design variables. If None, uses x1, x2, ...
        objective_name: Name for the objective function
        bounds: Variable bounds for metadata
        constraints_info: List of constraint information dicts with keys:
            - 'name': constraint name
            - 'type': 'eq' or 'ineq'
            - 'value': constraint value at solution (if available)
        include_jacobian: Include Jacobian as observable if available
        include_hessian: Include Hessian information as observable if available
        description: Problem description
        **metadata_kwargs: Additional metadata to include in ProblemMetadata

    Returns:
        Converted optimization result

    Examples:
        >>> from scipy.optimize import minimize
        >>> result = minimize(lambda x: (x[0]-1)**2 + (x[1]-2)**2, [0, 0])
        >>> opt_result = from_scipy_minimize(
        ...     result,
        ...     problem_name="Simple Quadratic",
        ...     variable_names=["x", "y"]
        ... )
    """
    # Extract solution
    x_opt = np.atleast_1d(result.x)
    n_vars = len(x_opt)

    # Generate variable names if not provided
    if variable_names is None:
        variable_names = [f"x{i + 1}" for i in range(n_vars)]
    elif len(variable_names) != n_vars:
        raise ValueError(
            f"Number of variable names ({len(variable_names)}) "
            f"does not match number of variables ({n_vars})"
        )

    # Create problem metadata
    metadata = ProblemMetadata(
        name=problem_name,
        description=description
        or f"Optimization using {result.get('message', 'scipy.optimize.minimize')}",
        solver="scipy.optimize.minimize",
        solver_version=None,  # scipy doesn't provide version in result
        solver_settings=metadata_kwargs.get("solver_settings", {}),
        n_design_variables=n_vars,
        n_objectives=1,  # minimize always has single objective
        n_inequality_constraints=0,
        n_equality_constraints=0,
        run_date=datetime.now(),
        computation_time=None,  # scipy doesn't track this in result
        n_evaluations=result.get("nfev"),
        metadata={
            "success": result.get("success", False),
            "status": result.get("status"),
            "message": result.get("message", ""),
            "nit": result.get("nit"),
            "njev": result.get("njev"),
            "nhev": result.get("nhev"),
            "maxcv": result.get("maxcv"),
            **metadata_kwargs,
        },
    )

    # Create design variables DataFrame (single row with optimal solution)
    design_vars_data = {name: [value] for name, value in zip(variable_names, x_opt)}

    # Create objectives DataFrame
    objectives_data = {objective_name: [result.fun]}

    # Initialize OptimizationResult
    opt_result = OptimizationResult(
        problem_metadata=metadata,
        design_variables=design_vars_data,
        objectives=objectives_data,
    )

    # Add variable metadata for design variables
    for i, name in enumerate(variable_names):
        lower = bounds[i][0] if bounds and i < len(bounds) else None
        upper = bounds[i][1] if bounds and i < len(bounds) else None
        opt_result.add_variable_metadata(
            DesignVariable(
                name=name,
                description=f"Design variable {i + 1}",
                lower_bound=lower,
                upper_bound=upper,
            )
        )

    # Add objective metadata
    opt_result.add_variable_metadata(
        Objective(
            name=objective_name,
            description="Objective function value",
            direction=OptimizationDirection.MINIMIZE,
        )
    )

    # Add Jacobian as observable if available and requested
    if include_jacobian and hasattr(result, "jac") and result.jac is not None:
        jac = np.atleast_1d(result.jac)
        for i, name in enumerate(variable_names):
            grad_name = f"grad_{name}"
            opt_result.add_column(
                name=grad_name,
                data=[jac[i]],
                metadata=Observable(
                    name=grad_name,
                    description=f"Gradient w.r.t. {name}",
                ),
            )

    # Add Hessian information if available and requested
    if include_hessian and hasattr(result, "hess") and result.hess is not None:
        # Store Hessian as flattened observable or custom data
        hess = np.atleast_2d(result.hess)
        hess_flat = hess.flatten()
        opt_result.add_column(
            name="hessian_flat",
            data=[hess_flat.tolist()],
            metadata=Observable(
                name="hessian_flat",
                description="Flattened Hessian matrix",
            ),
        )

    # Add constraints if provided
    if constraints_info:
        for constraint_info in constraints_info:
            c_name = constraint_info.get("name", "constraint")
            c_type = constraint_info.get("type", "ineq")
            c_value = constraint_info.get("value", 0.0)

            constraint_type = (
                ConstraintType.EQUALITY if c_type == "eq" else ConstraintType.INEQUALITY
            )

            opt_result.add_column(
                name=c_name,
                data=[c_value],
                category=DataTypeCategory.CONSTRAINT,
                metadata=Constraint(
                    name=c_name,
                    description=constraint_info.get("description", f"{c_type} constraint"),
                    constraint_type=constraint_type,
                ),
            )

            # Update metadata counts
            if constraint_type == ConstraintType.EQUALITY:
                opt_result.problem_metadata.n_equality_constraints += 1
            else:
                opt_result.problem_metadata.n_inequality_constraints += 1

    return opt_result


def from_scipy_differential_evolution(
    result: Any,
    problem_name: str = "SciPy Differential Evolution",
    variable_names: list[str] | None = None,
    objective_name: str = "objective",
    bounds: list[tuple[float, float]] | None = None,
    description: str | None = None,
    **metadata_kwargs: Any,
) -> OptimizationResult:
    """Convert scipy.optimize.differential_evolution result to OptimizationResult.

    This is a wrapper around from_scipy_minimize since differential_evolution
    returns the same OptimizeResult format.

    Args:
        result: The result object from scipy.optimize.differential_evolution
        problem_name: Name for the optimization problem
        variable_names: Names for design variables
        objective_name: Name for the objective function
        bounds: Variable bounds for metadata
        description: Problem description
        **metadata_kwargs: Additional metadata

    Returns:
        Converted optimization result
    """
    opt_result = from_scipy_minimize(
        result=result,
        problem_name=problem_name,
        variable_names=variable_names,
        objective_name=objective_name,
        bounds=bounds,
        constraints_info=None,
        include_jacobian=False,  # DE doesn't use gradients
        include_hessian=False,
        description=description or "Differential Evolution optimization",
        **metadata_kwargs,
    )

    # Update solver name
    opt_result.problem_metadata.solver = "scipy.optimize.differential_evolution"

    return opt_result


def from_scipy_least_squares(
    result: Any,
    problem_name: str = "SciPy Least Squares",
    variable_names: list[str] | None = None,
    residual_names: list[str] | None = None,
    bounds: list[tuple[float, float]] | None = None,
    description: str | None = None,
    **metadata_kwargs: Any,
) -> OptimizationResult:
    """Convert scipy.optimize.least_squares result to OptimizationResult.

    Args:
        result: The result object from scipy.optimize.least_squares
        problem_name: Name for the optimization problem
        variable_names: Names for design variables
        residual_names: Names for residuals (observables)
        bounds: Variable bounds for metadata
        description: Problem description
        **metadata_kwargs: Additional metadata

    Returns:
        Converted optimization result
    """
    # Extract solution
    x_opt = np.atleast_1d(result.x)
    n_vars = len(x_opt)

    # Generate variable names if not provided
    if variable_names is None:
        variable_names = [f"x{i + 1}" for i in range(n_vars)]

    # Create base result using minimize converter
    opt_result = from_scipy_minimize(
        result=result,
        problem_name=problem_name,
        variable_names=variable_names,
        objective_name="cost",
        bounds=bounds,
        description=description or "Least squares optimization",
        include_jacobian=True,
        **metadata_kwargs,
    )

    # Update solver name
    opt_result.problem_metadata.solver = "scipy.optimize.least_squares"

    # Add residuals as observables if available
    if hasattr(result, "fun") and result.fun is not None:
        residuals = np.atleast_1d(result.fun)
        n_residuals = len(residuals)

        if residual_names is None:
            residual_names = [f"residual_{i + 1}" for i in range(n_residuals)]

        for i, (res_name, res_value) in enumerate(zip(residual_names, residuals)):
            opt_result.add_column(
                name=res_name,
                data=[res_value],
                metadata=Observable(
                    name=res_name,
                    description=f"Residual {i + 1}",
                ),
            )

    # Add optimality metric if available
    if hasattr(result, "optimality") and result.optimality is not None:
        opt_result.add_column(
            name="optimality",
            data=[result.optimality],
            metadata=Observable(
                name="optimality",
                description="First-order optimality measure",
            ),
        )

    return opt_result


def from_optimization_history(
    x_history: np.ndarray,
    f_history: np.ndarray,
    problem_name: str = "Optimization History",
    variable_names: list[str] | None = None,
    objective_names: list[str] | None = None,
    g_history: np.ndarray | None = None,
    constraint_names: list[str] | None = None,
    constraint_types: list[str] | None = None,
    solver_name: str = "Unknown",
    description: str | None = None,
    **metadata_kwargs: Any,
) -> OptimizationResult:
    """Convert optimization history arrays to OptimizationResult.

    This is a generic converter for when you have arrays of optimization history
    (e.g., from custom optimizers or logging).

    Args:
        x_history: Design variables history, shape (n_iterations, n_variables)
        f_history: Objectives history, shape (n_iterations, n_objectives)
        problem_name: Name for the optimization problem
        variable_names: Names for design variables
        objective_names: Names for objectives
        g_history: Constraints history, shape (n_iterations, n_constraints)
        constraint_names: Names for constraints
        constraint_types: Types for constraints ('eq' or 'ineq')
        solver_name: Name of the solver used
        description: Problem description
        **metadata_kwargs: Additional metadata

    Returns:
        Converted optimization result
    """
    # Ensure arrays are 2D
    x_history = np.atleast_2d(x_history)
    f_history = np.atleast_2d(f_history)

    n_iterations, n_vars = x_history.shape
    n_objectives = f_history.shape[1] if f_history.ndim > 1 else 1

    # Generate names if not provided
    if variable_names is None:
        variable_names = [f"x{i + 1}" for i in range(n_vars)]
    if objective_names is None:
        objective_names = [f"f{i + 1}" for i in range(n_objectives)]

    # Create metadata
    metadata = ProblemMetadata(
        name=problem_name,
        description=description or f"Optimization history with {n_iterations} iterations",
        solver=solver_name,
        n_design_variables=n_vars,
        n_objectives=n_objectives,
        n_inequality_constraints=0,
        n_equality_constraints=0,
        run_date=datetime.now(),
        n_evaluations=n_iterations,
        metadata=metadata_kwargs,
    )

    # Create data dictionaries
    design_vars_data = {name: x_history[:, i] for i, name in enumerate(variable_names)}
    objectives_data = {name: f_history[:, i] for i, name in enumerate(objective_names)}

    # Initialize result
    opt_result = OptimizationResult(
        problem_metadata=metadata,
        design_variables=design_vars_data,
        objectives=objectives_data,
    )

    # Add variable metadata
    for name in variable_names:
        opt_result.add_variable_metadata(DesignVariable(name=name))

    for name in objective_names:
        opt_result.add_variable_metadata(
            Objective(name=name, direction=OptimizationDirection.MINIMIZE)
        )

    # Add constraints if provided
    if g_history is not None:
        g_history = np.atleast_2d(g_history)
        n_constraints = g_history.shape[1]

        if constraint_names is None:
            constraint_names = [f"g{i + 1}" for i in range(n_constraints)]

        if constraint_types is None:
            constraint_types = ["ineq"] * n_constraints

        for i, (name, c_type) in enumerate(zip(constraint_names, constraint_types)):
            constraint_type = (
                ConstraintType.EQUALITY if c_type == "eq" else ConstraintType.INEQUALITY
            )

            opt_result.add_column(
                name=name,
                data=g_history[:, i],
                category=DataTypeCategory.CONSTRAINT,
                metadata=Constraint(name=name, constraint_type=constraint_type),
            )

            if constraint_type == ConstraintType.EQUALITY:
                opt_result.problem_metadata.n_equality_constraints += 1
            else:
                opt_result.problem_metadata.n_inequality_constraints += 1

    # Add iteration number as observable
    opt_result.add_column(
        name="iteration",
        data=np.arange(n_iterations),
        metadata=Observable(name="iteration", description="Iteration number"),
    )

    return opt_result


def from_custom_optimizer(
    x_opt: np.ndarray | list,
    f_opt: float | np.ndarray | list,
    problem_name: str = "Custom Optimization",
    variable_names: list[str] | None = None,
    objective_names: list[str] | None = None,
    solver_name: str = "Custom",
    n_evaluations: int | None = None,
    computation_time: float | None = None,
    success: bool = True,
    message: str = "",
    **metadata_kwargs: Any,
) -> OptimizationResult:
    """Create OptimizationResult from custom optimizer output.

    This is a simple converter for when you just have the optimal solution
    and objective value(s).

    Args:
        x_opt: Optimal design variables
        f_opt: Optimal objective value(s)
        problem_name: Name for the optimization problem
        variable_names: Names for design variables
        objective_names: Names for objectives
        solver_name: Name of the solver used
        n_evaluations: Number of function evaluations
        computation_time: Computation time in seconds
        success: Whether optimization was successful
        message: Status message
        **metadata_kwargs: Additional metadata

    Returns:
        Converted optimization result
    """
    # Convert to arrays
    x_opt = np.atleast_1d(x_opt)
    f_opt = np.atleast_1d(f_opt)

    n_vars = len(x_opt)
    n_objectives = len(f_opt)

    # Generate names
    if variable_names is None:
        variable_names = [f"x{i + 1}" for i in range(n_vars)]
    if objective_names is None:
        objective_names = [f"f{i + 1}" for i in range(n_objectives)]

    # Create metadata
    metadata = ProblemMetadata(
        name=problem_name,
        solver=solver_name,
        n_design_variables=n_vars,
        n_objectives=n_objectives,
        run_date=datetime.now(),
        n_evaluations=n_evaluations,
        computation_time=computation_time,
        metadata={"success": success, "message": message, **metadata_kwargs},
    )

    # Create data (single point)
    design_vars_data = {name: [value] for name, value in zip(variable_names, x_opt)}
    objectives_data = {name: [value] for name, value in zip(objective_names, f_opt)}

    # Initialize result
    opt_result = OptimizationResult(
        problem_metadata=metadata,
        design_variables=design_vars_data,
        objectives=objectives_data,
    )

    # Add metadata
    for name in variable_names:
        opt_result.add_variable_metadata(DesignVariable(name=name))

    for name in objective_names:
        opt_result.add_variable_metadata(
            Objective(name=name, direction=OptimizationDirection.MINIMIZE)
        )

    return opt_result
