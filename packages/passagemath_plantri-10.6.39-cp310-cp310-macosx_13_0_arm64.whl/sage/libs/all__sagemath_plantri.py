# sage_setup: distribution = sagemath-plantri
