=====
Usage
=====

To use risclog.batou in a project::

    import risclog.batou
