__version__ = "0.1.4"

from MeowCore.main import MeowCore

__all__ = [
    "MeowCore"
]
