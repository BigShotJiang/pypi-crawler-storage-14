from setuptools import setup, find_packages

setup(
    name="insta_checker_speed",               # اسم مكتبتك
    version="1.0.0",                # الإصدار
    packages=find_packages(),       # يبحث تلقائيًا عن مجلد المكتبة
    install_requires=[
        "requests",
        "threading; python_version>='3.0'"
    ],
    description="Instagram speed",
    author="ITSH",
    python_requires=">=3.7",
)
