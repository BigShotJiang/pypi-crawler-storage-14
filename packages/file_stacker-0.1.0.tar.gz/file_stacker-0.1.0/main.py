import typer
from pathlib import Path
from datetime import datetime
from typing import Dict, List, Tuple
from collections import defaultdict
import shutil

app = typer.Typer()

import logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def group_files_by_date(
    path: Path, tolerance: int, extensions: set[str]
) -> Tuple[Dict[datetime, List[Path]], Dict[datetime, datetime]]:
    """
    Group files by their creation time with a given tolerance.
    
    Files with the specified extensions are grouped together if their creation times
    are within the tolerance window. Groups are created sequentially: if a file's
    creation time exceeds the tolerance from the current group's end time, a new
    group is started.
    
    Args:
        path: Directory path to scan for files
        tolerance: Time difference in seconds to consider files as part of the same group
        extensions: Set of file extensions (without dots) to include, e.g., {"jpg", "cr3"}
        
    Returns:
        A tuple containing:
        - groups: Dictionary mapping start times to lists of file paths in that group
        - start_end_times: Dictionary mapping group start times to their end times
    """
    # Get all files with specified extensions and their creation times
    files_with_creation_time = []
    for file_path in path.glob("*.*"):
        if file_path.is_file():
            if file_path.suffix.lower().lstrip(".") not in extensions:
                logger.debug(f"Skipping file {file_path} because it is not a {extensions} file")
                continue
            creation_time = datetime.fromtimestamp(file_path.stat().st_birthtime)
            files_with_creation_time.append((creation_time, file_path))

    if not files_with_creation_time:
        return {}, {}

    files_with_creation_time.sort(key=lambda x: x[0])

    start_end_times = {}
    groups = defaultdict(list)

    start_time = files_with_creation_time[0][0]

    start_end_times[start_time] = start_time

    for creation_time, file_path in files_with_creation_time:
        reference_time = start_end_times[start_time]
        if (creation_time - reference_time).total_seconds() > tolerance:
            logger.debug(f"Starting new group at {creation_time}")
            start_time = creation_time

        start_end_times[start_time] = creation_time
        groups[start_time].append(file_path)

    return groups, start_end_times

@app.command()
def stack(
    path: Path = typer.Argument(default=".", help="Path to the directory to stack"),
    tolerance: int = typer.Option(default=10, help="Tolerance for time difference in seconds"),
    extensions: list[str] = typer.Option(default=["jpg", "cr3"], help="File extensions to group by"),
):
    """
    Stack files by grouping them based on creation time and copying them into organized folders.
    
    Files with the specified extensions are grouped by creation time within the specified
    tolerance window. Each group is copied into a new folder named with the start and end
    times of that group. Folder names follow the format: YYYY_MM_DD_HH_MM_SS-YYYY_MM_DD_HH_MM_SS
    
    By default, processes JPG and CR3 files, but can be configured to handle any file extensions.
    """
    if not path.exists():
        logger.error(f"Error: Path {path} does not exist")
        raise typer.Exit(1)
    
    if not path.is_dir():
        logger.error(f"Error: {path} is not a directory")
        raise typer.Exit(1)
    
    logger.info(f"Stacking files in {path.resolve()} with tolerance {tolerance} seconds...")
    
    groups, start_end_times = group_files_by_date(path, tolerance, set(extensions))
    
    for start_time, end_time in start_end_times.items():
        folder_name = f"{start_time.strftime('%Y_%m_%d_%H_%M_%S')}-{end_time.strftime('%Y_%m_%d_%H_%M_%S')}"
        folder_path = path / folder_name
        folder_path.mkdir(parents=True, exist_ok=True)
        for file_path in groups[start_time]:
            shutil.copy(file_path, folder_path / file_path.name)
        


def main():
    """File Stacker CLI - A command-line tool built with Typer."""
    app()


if __name__ == "__main__":
    main()
