# 📘 **README.md (End-User Version — Clean & Professional)**

# C2REGbase

C2REGbase provides a simple and structured workflow for running linear regression using six clear steps.  
It is designed for analysts who want a clean, consistent, and reproducible regression process without the complexity of full statistical frameworks.

The library performs:
1. **Variable inspection**  
2. **Type adjustments**  
3. **Missing-value summary and listwise deletion**  
4. **Ordinary Least Squares (OLS) regression**  
5. **Export of parameter estimates in a dataset-friendly format**  
6. **Diagnostics including standard errors, t-values, p-values, and confidence intervals**

---

## 🔧 Installation

Install from PyPI:


pip install C2REGbase


---

## 🚀 Quick Example

```python
from C2REGbase import (
    inspect_variables,
    adjust_variable_types,
    summarize_missing_listwise,
    fit_ols,
    export_outest,
    compute_diagnostics
)
import pandas as pd
import numpy as np

# Sample dataset
df = pd.DataFrame({
    "bweight": np.random.normal(3000, 600, size=200),
    "matage": np.random.randint(18, 40, size=200),
    "ht": np.random.choice(["yes", "no"], size=200),
    "sex": np.random.choice(["male", "female"], size=200)
})

# Step 1: Inspect structure
inspect_variables(df)

# Step 2: Adjust variable types
df = adjust_variable_types(df, {"ht": "category", "sex": "category"})

# Step 3: Missing-value summary & listwise deletion
df_clean, mv_summary = summarize_missing_listwise(
    df, ["bweight", "matage", "ht", "sex"]
)

# Step 4: Fit OLS model
results, stats = fit_ols(
    df_clean,
    dependent="bweight",
    independents=["matage", "ht", "sex"]
)

# Step 5: Export parameter estimates (OUTEST-style)
outest_df = export_outest(results, dependent="bweight")

# Step 6: Compute diagnostics (stderr, t, p-value, CI)
diag_df = compute_diagnostics(results, alpha=0.05)
```

---

## 📘 Notes

* C2REGbase does **not** perform automatic transformations (e.g., log, squared, interaction terms).
  Users should create any derived variables manually in their DataFrame before fitting.
* Categorical variables are automatically dummy-encoded during regression.
* The output includes:

  * ANOVA
  * RMSE
  * R² and Adjusted R²
  * Coefficient table
  * OUTEST-like export
  * Diagnostic table with confidence intervals

---

## 📄 License

C2REGbase is open-source under the MIT License.


---
