import cv2
import numpy as np
from pyblurry._base import BaseAnalysis
from typing import Optional


DEFAULT_LAPLACIAN_THRESHOLD = 19.0
"""Best default for the laplacian threshold analyzed via iterating over a range of thresholds."""

class LaplacianSimpleAnalysis(BaseAnalysis):
    """Class to perform the simplest laplacian analysis (very fast) to determine if an image is blurred."""
    ALGORITHM_NAME = "laplacian-simple"
    CONFIDENCE_FACTOR = 1.0

    def __init__(self, image_filepath: Optional[str] = None,
                 laplacian_threshold: float = DEFAULT_LAPLACIAN_THRESHOLD):
        """ Initializes a new instance of the :class:`LaplacianSimpleAnalysis` class.

        :param image_filepath: Path to the image file to load as a grayscale image.
                               (To load in full color use the :py:func:`load_image` method).
        :param laplacian_threshold: The threshold for the laplacian variance. If the variance is lower than the
                                    threshold, then the image is considered blurry.
        """
        super().__init__(image_filepath=image_filepath)

        self.laplacian_threshold: float = laplacian_threshold
        """The threshold for the laplacian variance. If the variance is lower than the threshold, then the image is 
        considered blurry."""

    def _perform_analysis(self, image: Optional[np.typing.NDArray] = None) -> dict:
        """ Performs the real analysis of the image to determine if it is blurry.

        :param image: An image to perform the analysis on, or if None the image in :py:attr:`image` is used.
        :return: A dictionary with the result of the analysis.
        """
        img = image if image is not None else self.image
        laplacian_variance = cv2.Laplacian(img, cv2.CV_64F).var()
        return {
            "is_blurry": bool(laplacian_variance < self.laplacian_threshold),
            "laplacian_variance": laplacian_variance,
            "laplacian_threshold": self.laplacian_threshold
        }
