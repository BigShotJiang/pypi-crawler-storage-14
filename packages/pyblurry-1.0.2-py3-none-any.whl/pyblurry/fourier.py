import numpy as np
from pyblurry._base import BaseAnalysis
from typing import Optional


DEFAULT_FFT_CENTER_RADIUS_SIZE = 20
"""Best default for the image center radius size analyzed via iterating over a range of radii."""
DEFAULT_FFT_MEAN_THRESHOLD = 10.0
"""Best default for the fast-Fourier transform mean threshold analyzed via iterating over a range of thresholds."""

class FastFourierTransformAnalysis(BaseAnalysis):
    """Class to perform a Fast Fourier Transform (FFT) analysis to determine if an image is blurred."""
    ALGORITHM_NAME = "fast-fourier-transform"
    CONFIDENCE_FACTOR = 0.9333333333333333

    def __init__(self, image_filepath: Optional[str] = None,
                 fft_mean_threshold: float = DEFAULT_FFT_MEAN_THRESHOLD,
                 fft_center_radius_size: int = DEFAULT_FFT_CENTER_RADIUS_SIZE):
        """ Initializes a new instance of the :class:`FastFourierTransformAnalysis` class.

        :param image_filepath: Path to the image file to load as a grayscale image.
                               (To load in full color use the :py:func:`load_image` method).
        :param fft_mean_threshold: The threshold for the Fourier mean measurement. If the mean value is lower than the
                                   threshold, then the image is considered blurry.
        :param fft_center_radius_size: The size of the center radius of the Fast Fourier transform.
        """
        super().__init__(image_filepath=image_filepath)

        self.fft_center_radius_size: float = fft_center_radius_size
        """The size of the center radius of the Fast Fourier transform."""

        self.fft_mean_threshold: float = fft_mean_threshold
        """The threshold for the Fourier mean measurement. If the mean value is lower than the threshold, then the 
        image is considered blurry."""

    def _perform_analysis(self, image: Optional[np.typing.NDArray] = None) -> dict:
        """ Performs the real analysis of the image to determine if it is blurry.

        :param image: An image to perform the analysis on, or if None the image in :py:attr:`image` is used.
        :return: A dictionary with the result of the analysis.
        """
        img = image if image is not None else self.image

        # Normalize image and compute FFT
        fft = np.fft.fft2(img)
        fft_shift = np.fft.fftshift(fft)

        # zero-out the center of the FFT shift (i.e., remove low
        # frequencies), apply the inverse shift such that the DC
        # component once again becomes the top-left, and then apply
        # the inverse FFT
        h, w = img.shape
        (c_x, c_y) = (int(w / 2.0), int(h / 2.0))
        fft_shift[
            c_y - self.fft_center_radius_size : c_y + self.fft_center_radius_size,
            c_x - self.fft_center_radius_size : c_x + self.fft_center_radius_size
        ] = 0
        fft_shift = np.fft.ifftshift(fft_shift)
        recon = np.fft.ifft2(fft_shift)

        # compute the magnitude spectrum of the reconstructed image,
        # then compute the mean (average) of the magnitude values
        # The literal 20 here is needed as is as it is a fixed value in the formula.
        magnitude = 20 * np.log(np.abs(recon))
        fft_mean = np.mean(magnitude)

        return {
            "is_blurry": bool(fft_mean < self.fft_mean_threshold),
            "fft_mean": float(fft_mean),
            "fft_mean_threshold": self.fft_mean_threshold
        }
