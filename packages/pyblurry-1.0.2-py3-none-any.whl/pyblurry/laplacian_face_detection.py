import cv2
import numpy as np
from pyblurry.laplacian_simple import LaplacianSimpleAnalysis
from typing import Optional, Tuple


DEFAULT_FACE_DETECTION_SCALE_FACTOR = 1.1
"""Best default for the face detection scale factor analyzed via iterating over a range of values."""
DEFAULT_FACE_DETECTION_MIN_NEIGHBORS = 6
"""Best default for the face detection minimum number of neighbors analyzed via iterating over a range of values."""
DEFAULT_FACE_DETECTION_MIN_SIZE = (30, 30)
"""Best default for the face detection minimum size (as a width and height pixels tuple) analyzed via iterating over 
a range of values."""
DEFAULT_LAPLACIAN_THRESHOLD = 20.0
"""Best default for the laplacian threshold analyzed via iterating over a range of thresholds."""

class LaplacianDetectingFaces(LaplacianSimpleAnalysis):
    """Class to perform a Laplacian analysis doing basic face recognition, to determine if an image with people in it
    is blurred."""
    ALGORITHM_NAME = "laplacian-face-detection"
    CONFIDENCE_FACTOR = 0.9916666666666667

    def __init__(self, image_filepath: Optional[str] = None,
                 laplacian_threshold: float = DEFAULT_LAPLACIAN_THRESHOLD,
                 face_detection_scale_factor: float = DEFAULT_FACE_DETECTION_SCALE_FACTOR,
                 face_detection_min_neighbors: int = DEFAULT_FACE_DETECTION_MIN_NEIGHBORS,
                 face_detection_min_size: Tuple[int, int] = DEFAULT_FACE_DETECTION_MIN_SIZE):
        """ Initializes a new instance of the :class:`LaplacianDetectingFaces` class.

        :param image_filepath: Path to the image file to load as a grayscale image.
                               (To load in full color use the :py:func:`load_image` method).
        :param laplacian_threshold: The threshold for the laplacian variance. If the variance is lower than the
                                    threshold, then the image is considered blurry.
        :param face_detection_scale_factor: The factor to resize the image to increase the change of detecting faces.
        :param face_detection_min_neighbors: The minimum number of neighbors each candidate rectangle should have to
                                             retain it.
        :param face_detection_min_size: Minimum possible object size as a tuple of width and height in pixels. Faces
                                        smaller than that are ignored.
        """
        super().__init__(image_filepath=image_filepath,
                         laplacian_threshold=laplacian_threshold)

        self.face_detection_min_neighbors: int = face_detection_min_neighbors
        """The minimum number of neighbors each candidate rectangle should have to retain it."""

        self.face_detection_min_size: Tuple[int, int] = face_detection_min_size
        """Minimum possible object size as a tuple of width and height in pixels. Faces smaller than that are 
        ignored."""

        self.face_detection_scale_factor: float = face_detection_scale_factor
        """The factor to resize the image to increase the change of detecting faces."""

    def _perform_analysis(self, image: Optional[np.typing.NDArray] = None) -> dict:
        """ Performs the real analysis of the image to determine if it is blurry.

        :param image: An image to perform the analysis on, or if None the image in :py:attr:`image` is used.
        :return: A dictionary with the result of the analysis.
        """
        img = image if image is not None else self.image

        # Load the pre-trained Haar cascade for face detection
        face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + "haarcascade_frontalface_default.xml")

        # Detect faces in the image
        faces = face_cascade.detectMultiScale(
            img,
            scaleFactor=self.face_detection_scale_factor,
            minNeighbors=self.face_detection_min_neighbors,
            minSize=self.face_detection_min_size
        )

        # If no faces are found, fall back to a full-image check
        if len(faces) == 0:
            laplacian_variance = cv2.Laplacian(img, cv2.CV_64F).var()
            return {
                "is_blurry": bool(laplacian_variance < self.laplacian_threshold),
                "faces_detected": False,
                "laplacian_variance": laplacian_variance,
                "laplacian_threshold": self.laplacian_threshold
            }

        # Iterate over detected faces and check for blurriness
        sum_of_laplacian_variances: float = 0
        for (x, y, w, h) in faces:
            # Extract the face region of interest (ROI)
            face_roi = img[y:y + h, x:x + w]

            # Calculate the Laplacian variance on the face region
            face_laplacian_variance = cv2.Laplacian(face_roi, cv2.CV_64F).var()
            sum_of_laplacian_variances += face_laplacian_variance
        average_laplacian_variance = sum_of_laplacian_variances / len(faces)

        # If the average of the variances for all faces are below the threshold consider the image overall as blurry
        return{
            "is_blurry": bool(average_laplacian_variance < self.laplacian_threshold),
            "faces_detected": True,
            "laplacian_variance": average_laplacian_variance,
            "laplacian_threshold": self.laplacian_threshold
        }
