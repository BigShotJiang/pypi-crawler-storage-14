from abc import ABC, abstractmethod
from numpy.typing import NDArray
from pyblurry.utils import load_image, resize_image, CannotResizeImageError
from time import perf_counter
from typing import Optional


class BaseAnalysis(ABC):
    ALGORITHM_NAME: str = "NOT SET"
    """The name of the method used to perform the analysis."""

    CONFIDENCE_FACTOR: float = 1.0
    """The confidence factor of this analysis method (the closer to 1.0 the better)."""

    """Base class for all analysis classes."""
    def __init__(self, image_filepath: Optional[str] = None):
        """ Initializes a new instance of the :class:`BaseAnalysis` class.

        :param image_filepath: Path to the image file to load as a grayscale image.
                               (To load in full color use the :py:func:`load_image` method).
        """
        self.image: Optional[NDArray] = None
        """The image being analyzed as a numpy array."""

        if image_filepath:
            self.image = load_image(image_filepath=image_filepath,
                                    grayscale=True,
                                    except_if_animated=True)

    def analyze(self, resize: bool = True) -> dict:
        """ Analyzes the image to determine if it is blurry.

        :param resize: Indicates whether the image is resized before the analysis for more consistent and fast results.
        :return: A dictionary with the result of the analysis.
        """
        if self.image is None:
            raise Exception('Image must be set or loaded from file.')
        img, resized = (self.image, False)
        if resize:
            try:
                img, resized = resize_image(image=self.image)
            except CannotResizeImageError:
                pass
        analysis = {
            "method": self.ALGORITHM_NAME,
            "confidence": self.CONFIDENCE_FACTOR,
            "is_blurry": None,
            "resized": resized,
            "elapsed_time": None,
        }
        start_time = perf_counter()
        perf_analysis = self._perform_analysis(image=img)
        # noinspection PyTypeChecker
        analysis["elapsed_time"] = perf_counter() - start_time
        analysis.update(perf_analysis)
        return analysis

    @abstractmethod
    def _perform_analysis(self, image: Optional[NDArray] = None) -> dict:
        """ Performs the real analysis of the image to determine if it is blurry.

        :param image: An image to perform the analysis on, or if None the image in :py:attr:`image` is used.
        :return: A dictionary with the result of the analysis.
        """
        pass
