import cv2
import filetype
import numpy as np
import os
import sys
from pathlib import Path
from PIL import Image, ImageFile
from typing import Callable, Tuple


DEFAULT_RESIZE_WIDTH = 512

class AnimatedImageError(Exception):
    """Raised when an error occurs during image loading if the image is detected to be animated."""
    pass

class CannotResizeImageError(Exception):
    """Raised if an error occurs when trying to resize an image."""
    pass

class CorruptImageError(Exception):
    """Raised when an error occurs during image loading if the image is detected as corrupt."""
    pass

class NotImageError(Exception):
    """Raised if the image is detected to not be a known image type."""
    pass

def corrupt_image(source_image_filepath: str,
                  target_image_filepath: str,
                  at_percentage: int = 85):
    """ Intentionally produces a corrupt image by truncating the file at the given percentage.

    :param source_image_filepath: The source filepath to the image to corrupt.
    :param target_image_filepath: The filepath where the corrupt image will be saved.
    :param at_percentage: The percentage of the source image where the image will be truncated.
    :raises FileNotFoundError: If the source file does not exist.
    :raises ValueError: If any of the filepaths is not supplied, or if the target file is the same as the source file
                        or if the percentage is less than 10 or greater than 99.
    """
    if not source_image_filepath:
        raise ValueError("The source image file path was not supplied.")
    if not target_image_filepath:
        raise ValueError("The target image file path was not supplied.")
    if Path(source_image_filepath).resolve(strict=False) ==  Path(target_image_filepath).resolve(strict=False):
        raise ValueError(f"The source image file path and target image file path are identical.")
    if not os.path.isfile(source_image_filepath):
        raise FileNotFoundError(source_image_filepath)
    if at_percentage < 10 or at_percentage > 99:
        raise ValueError(f"The given percentage {at_percentage} is out of range. Must be between 10 and 99.")
    try:
        with open(source_image_filepath, 'rb') as f_in:
            original_data = f_in.read()
        total_bytes = len(original_data)
        bytes_to_copy = int(total_bytes * (at_percentage / 100.0))
        incomplete_data = original_data[:bytes_to_copy]
    except Exception:
        print(f"Error loading source file: {source_image_filepath}")
        raise
    try:
        if os.path.isfile(target_image_filepath):
            print(f"File {target_image_filepath} already exists. It will be overwritten.")
        with open(target_image_filepath, 'wb') as f_out:
            f_out.write(incomplete_data)
        print(f"Incomplete image saved to: {target_image_filepath} (copied {bytes_to_copy} of {total_bytes} bytes)")
    except IOError:
        print(f"Error saving incomplete image as target: {target_image_filepath}")
        raise

def format_seconds_to_m_s_ms(total_seconds: float) -> str:
    """ Formats a float representing total seconds into a string of
    minutes, seconds, and milliseconds.

    :param total_seconds: Total seconds represented as a float.
    :return: Formatted string representing total seconds represented as a float.
    """
    # Extract minutes and remaining seconds
    minutes, remaining_seconds = divmod(total_seconds, 60)

    # Extract whole seconds and milliseconds from remaining_seconds
    seconds = int(remaining_seconds)
    milliseconds = int((remaining_seconds - seconds) * 1000)

    # Format the output string
    return f"{int(minutes):02d}:{seconds:02d}.{milliseconds:03d}"

def is_dir_empty(dirpath: str) -> bool:
    """ Checks if a directory is empty or just contains a single system file.

    :param dirpath: The directory to check.
    :return: True if the directory is empty, False otherwise.
    :raises NotADirectoryError: If the directory does not exist.
    :raises ValueError: If the filepath is not supplied.
    """
    if not dirpath:
        raise ValueError("The directory path was not supplied.")
    if not os.path.isdir(dirpath):
        raise NotADirectoryError(dirpath)
    system_files = (
        ".DS_Store",  # macOS
        "Thumbs.db",  # Windows
    )
    contents = os.listdir(dirpath)
    return len(contents) == 0 or (len(contents) == 1 and contents[0] in system_files)

def is_file_image(filepath: str) -> bool:
    """ Checks if a file is an image file.

    :param filepath: Path to the file to check.
    :return: True if the file is an image file, False otherwise.
    :raises FileNotFoundError: If the file does not exist.
    :raises ValueError: If the filepath is not supplied.
    """
    if not filepath:
        raise ValueError("The file path was not supplied.")
    if not os.path.isfile(filepath):
        raise FileNotFoundError(filepath)
    return filetype.is_image(filepath)

def is_image_animated(image_path: str) -> bool:
    """ Checks if a file is an animated image file.

    :param image_path: Path to the file to check.
    :return: True if the image is animated, False otherwise.
    :raises FileNotFoundError: If the file does not exist.
    :raises ValueError: If the filepath is not supplied.
    """
    if not image_path:
        raise ValueError("The image file path was not supplied.")
    with Image.open(image_path) as img:
        return getattr(img, "is_animated", False)

def load_image(image_filepath: str,
               grayscale: bool = False,
               except_if_animated: bool = False,
               except_if_corrupt: bool = False,
               remove_corrupt_data_from_end: bool = True) -> np.typing.NDArray:
    """ Loads an image from a filepath.

    :param image_filepath: The filepath to the image to load.
    :param grayscale: Flag indicating if the image is loaded as grayscale.
    :param except_if_animated: Flag indicating if an exception is raised if the image is detected as being animated.
    :param except_if_corrupt: Flag indicating if an exception is raised if the image is detected as being corrupt.
    :param remove_corrupt_data_from_end: Flag indicating whether data at the end of the array coming from corrupt JPEG
                                         files is automatically detected and removed.
    :return: The loaded image.
    :raises FileNotFoundError: If the image file does not exist.
    :raises ValueError: If the image filepath is not supplied.
    :raises NotImageError: If the file is not a known image file type.
    :raises AnimatedImageError: If the image is an animated image file and except_if_animated is True.
    :raises CorruptImageError: If the image is corrupt/incomplete and except_if_corrupt is True.
    """
    if not image_filepath:
        raise ValueError("The image file path was not supplied.")
    if not os.path.isfile(image_filepath):
        raise FileNotFoundError(image_filepath)
    if not is_file_image(filepath=image_filepath):
        raise NotImageError(f"{image_filepath} is not an image file.")

    is_corrupt = False

    # Try to determine if the image is corrupt
    try:
        with Image.open(image_filepath) as img:
            # Try to verify the image to determine if the image is corrupt (for PNG files)
            img.verify()
        with Image.open(image_filepath) as img:
            # Try to load the image to observe an exception if the image is corrupt (for JPEG files)
            _ = img.getdata()[0]
    except Exception as e:
        if except_if_corrupt:
            raise CorruptImageError(f"{image_filepath} is a corrupt or incomplete image.") from e
        is_corrupt = True

    try:
        if is_corrupt:
            # Attempt to load as much image data as possible even if it is incomplete
            ImageFile.LOAD_TRUNCATED_IMAGES = True
        with Image.open(image_filepath) as img:
            # Convert the image to a numpy array in order to return it
            if except_if_animated and getattr(img, "is_animated", False):
                raise AnimatedImageError(f"{image_filepath} is an animated image.")
            if grayscale:
                pil_image_grayscale = img.convert('L')
                img_as_numpy_array = np.array(pil_image_grayscale)
            else:
                pil_image = img.convert('RGB')
                numpy_image_rgb = np.array(pil_image)
                img_as_numpy_array = numpy_image_rgb[:, :, ::-1].copy()
            if is_corrupt and remove_corrupt_data_from_end:
                img_as_numpy_array, removed_rows = remove_corrupt_data_rows_from_end(image=img_as_numpy_array)
            return img_as_numpy_array
    finally:
        if is_corrupt:
            # Revert the flag
            ImageFile.LOAD_TRUNCATED_IMAGES = False

def remove_corrupt_data_rows_from_end(image: np.typing.NDArray) -> Tuple[np.typing.NDArray, int]:
    """ Removes corrupt data rows from the end of the image that has a premature end.

    :param image: The image to remove corrupt data rows from.
    :return: A tuple of the new image and the number of rows removed from the image.
    """
    if image.size == 0:
        # An empty array, very unlikely
        return image, 0

    # Start from the second to last row and compare with the last row
    # Iterate backwards to find the first row that is not identical to the last
    last_row = image[-1]

    index_to_keep = image.shape[0]
    for i in range(image.shape[0] - 2, -1, -1):
        if not np.array_equal(image[i], last_row):
            break
        index_to_keep -= 1
    else:
        # If all rows are identical to the last row (very unlikely)
        return image, 0
    return image[0 : index_to_keep], image.shape[0] - index_to_keep

def resize_image(image: np.typing.NDArray,
                 resize_width: int = DEFAULT_RESIZE_WIDTH) -> Tuple[np.typing.NDArray, bool]:
    """ Resizes an image to min_width width pixels.

    :param image: An image to resize.
    :param resize_width: The width to resize the image to if it is greater.
    :return: A tuple of the resized image and a flag indicating if it was resized.
    :raises ValueError: If the image is not supplied.
    """
    if image is None:
        raise ValueError('Image is required.')
    height = image.shape[0]
    width = image.shape[1]
    if width > resize_width:
        scale = resize_width / width
        new_size = (resize_width, int(height * scale))
        try:
            return cv2.resize(image, new_size, interpolation=cv2.INTER_AREA), True
        except Exception as e:
            raise CannotResizeImageError(f"Failed to resize image to {resize_width}x{resize_width} pixels.") from e
    return image, False

def suppress_output(func: Callable) -> Callable:
    """ Decorator used to suppress temporarily any output to stderr and stdout for the function being decorated.
    The suppression only happens if the callable is called with a kwarg called "suppress_output" with a True value.

    :return: A callable wrapper that decorates another callable.
    """
    def wrapper(*args, **kwargs):
        if not kwargs.pop("suppress_output", False):
            return func(*args, **kwargs)
        with open(os.devnull, 'w') as devnull:
            original_stdout = sys.stdout
            original_stderr = sys.stderr
            sys.stdout = devnull
            sys.stderr = devnull
            result = func(*args, **kwargs)
            sys.stdout = original_stdout
            sys.stderr = original_stderr
        return result
    return wrapper

def time_format_to_seconds(time_format: str) -> float:
    """ Converts a string representing mm:ss.ms into its float equivalent representation.

    :param time_format: The time format to convert.
    :return: The converted float representation.
    """
    mins_and_secs_str = time_format.split(':')
    mins = int(mins_and_secs_str[0])
    secs = float(mins_and_secs_str[1])

    return (mins * 60) + secs
