import numpy as np
from blur_detector import detectBlur
from pyblurry._base import BaseAnalysis
from typing import Optional


DEFAULT_PERCEPTUAL_THRESHOLD = 0.395
"""Best default for the perceptual algorithm threshold analyzed via iterating over a range of thresholds."""

class PerceptualRobustAnalysis(BaseAnalysis):
    """Class to perform a perceptual (more robust but slowest) analysis to determine if an image is blurred."""
    ALGORITHM_NAME = "perceptual-robust"
    CONFIDENCE_FACTOR = 0.9583333333333333

    def __init__(self, image_filepath: Optional[str] = None,
                 perceptual_threshold: float = DEFAULT_PERCEPTUAL_THRESHOLD):
        """ Initializes a new instance of the :class:`PerceptualRobustAnalysis` class.

        :param image_filepath: Path to the image file to load as a grayscale image.
                               (To load in full color use the :py:func:`load_image` method).
        :param perceptual_threshold: The threshold for the perceptual analysis. If the value is greater than the
                                     threshold, then the image is considered blurry.
        """
        super().__init__(image_filepath=image_filepath)

        self.perceptual_threshold: float = perceptual_threshold
        """The threshold for the perceptual analysis. If the value is greater than the threshold, then the image is 
        considered blurry."""

    def _perform_analysis(self, image: Optional[np.typing.NDArray] = None) -> dict:
        """ Performs the real analysis of the image to determine if it is blurry.

        :param image: An image to perform the analysis on, or if None the image in :py:attr:`image` is used.
        :return: A dictionary with the result of the analysis.
        """
        img = image if image is not None else self.image

        # Detect blur using the perceptual method
        blur_map = detectBlur(img, show_progress=False)

        # Calculate the average blur value across the entire image.
        perceptual_mean = blur_map.mean()

        return {
            "is_blurry": bool(perceptual_mean > self.perceptual_threshold),
            "perceptual_mean": perceptual_mean,
            "perceptual_threshold": self.perceptual_threshold
        }
