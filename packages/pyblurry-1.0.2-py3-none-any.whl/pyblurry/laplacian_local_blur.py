import cv2
import numpy as np
from pyblurry.laplacian_simple import LaplacianSimpleAnalysis
from typing import Optional


DEFAULT_LAPLACIAN_THRESHOLD = 70.0
"""Best default for the laplacian threshold analyzed via iterating over a range of thresholds."""
DEFAULT_ROI_THRESHOLD = 15.0
"""Best default for the ROI edge detection threshold analyzed via iterating over a range of thresholds."""
DEFAULT_ROI_WEIGHT = 0.81666
"""Best default for the ROI edge weight analyzed via iterating over a range of values."""

class LaplacianDetectingLocalizedBlur(LaplacianSimpleAnalysis):
    """Class to perform a Laplacian analysis of a region of interest using basic edge detection, to determine if an
    image is blurred."""
    ALGORITHM_NAME = "laplacian-local-blur"
    CONFIDENCE_FACTOR = 0.9916666666666667

    def __init__(self, image_filepath: Optional[str] = None,
                 laplacian_threshold: float = DEFAULT_LAPLACIAN_THRESHOLD,
                 roi_threshold: float = DEFAULT_ROI_THRESHOLD,
                 roi_weight: float = DEFAULT_ROI_WEIGHT):
        """ Initializes a new instance of the :class:`LaplacianDetectingLocalizedBlur` class.

        :param image_filepath: Path to the image file to load as a grayscale image.
                               (To load in full color use the :py:func:`load_image` method).
        :param laplacian_threshold: The threshold for the laplacian variance. If the variance is lower than the
                                    threshold, then the image is considered blurry.
        :param roi_threshold: The threshold for the ROI edge detection.
        :param roi_weight: The weight for the ROI edge detection.
        """
        super().__init__(image_filepath=image_filepath,
                         laplacian_threshold=laplacian_threshold)

        self.roi_threshold: float = roi_threshold
        """The threshold for the roi edge detection."""

        self.roi_weight: float = roi_weight
        """The weight for the roi edge detection."""

    def _perform_analysis(self, image: Optional[np.typing.NDArray] = None) -> dict:
        """ Performs the real analysis of the image to determine if it is blurry.

        :param image: An image to perform the analysis on, or if None the image in :py:attr:`image` is used.
        :return: A dictionary with the result of the analysis.
        """
        img = image if image is not None else self.image
        global_laplacian_variance = cv2.Laplacian(img, cv2.CV_64F).var()

        # Attempt to determine automatically good heuristic values for the Canny thresholds based on the image's
        # pixel intensities
        sigma = 0.33
        pixel_intensities_median = np.median(img)
        canny_lower_threshold = int(max(0, (1.0 - sigma) * pixel_intensities_median))
        canny_upper_threshold = int(min(255, (1.0 + sigma) * pixel_intensities_median))

        # Attempt to find a Region of Interest (ROI) for foreground objects
        # This is a simplified approach; for robust object detection, consider using
        # pre-trained models (e.g., YOLO, SSD) or more advanced segmentation techniques.
        # Here, we use a simple edge detection and contour finding for demonstration.
        edges = cv2.Canny(img, canny_lower_threshold, canny_upper_threshold)
        contours, _ = cv2.findContours(edges, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

        roi_fm_list = []
        img_area_factor = img.shape[0] * img.shape[1] * 0.8
        for contour in contours:
            x, y, w, h = cv2.boundingRect(contour)
            # Filter out very small or very large contours that might not be relevant objects
            if w > self.roi_threshold and h > self.roi_threshold and w * h < img_area_factor:
                roi = img[y : y + h, x : x + w]
                if roi.size > 0:
                    roi_fm_list.append(cv2.Laplacian(roi, cv2.CV_64F).var())

        # Combine global and local blur measures
        if roi_fm_list:
            avg_roi_fm = np.mean(roi_fm_list)
            # Weighted average to prioritize ROI sharpness
            local_laplacian_variance = (
                    (self.roi_weight * avg_roi_fm) + ((1 - self.roi_weight) * global_laplacian_variance)
            )
        else:
            # If no significant ROIs found, rely on global measure
            local_laplacian_variance = global_laplacian_variance

        return {
            "is_blurry": bool(local_laplacian_variance < self.laplacian_threshold),
            "local_laplacian_variance": local_laplacian_variance,
            "global_laplacian_variance": global_laplacian_variance,
            "laplacian_threshold": self.laplacian_threshold
        }
