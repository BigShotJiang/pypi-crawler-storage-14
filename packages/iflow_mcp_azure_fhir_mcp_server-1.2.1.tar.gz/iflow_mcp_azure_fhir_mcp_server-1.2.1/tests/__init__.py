# Tests package for Azure FHIR MCP Server
