"""Beancount Model Context Protocol Server."""

__version__ = "0.1.1"
