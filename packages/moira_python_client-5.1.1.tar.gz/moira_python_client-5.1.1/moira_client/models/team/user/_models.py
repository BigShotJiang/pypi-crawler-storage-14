from typing import List


class TeamMembers:
    def __init__(self, usernames: List[str]) -> None:
        self.usernames = usernames
