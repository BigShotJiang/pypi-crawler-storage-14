import pytest
import json
from pathlib import Path
from unittest.mock import MagicMock
from auto_pytest_generator.response_refresher import ResponseRefresher, ResultCategory

# -----------------------------------------------------------------------------
# Fixtures: 准备测试数据
# -----------------------------------------------------------------------------

@pytest.fixture
def sample_test_file(tmp_path):
    """创建一个临时的 pytest 文件，包含典型的自动生成用例结构"""
    content = """
import requests
import pytest

def test_get_example():
    url = "http://httpbin.org/get"
    headers = {"User-Agent": "test-agent"}
    params = {"q": "python"}
    response = requests.request("GET", url, headers=headers, params=params)
    assert response.status_code == 200
    assert response.json() == {"origin": "127.0.0.1", "url": "http://httpbin.org/get"}

def test_post_example():
    url = "http://httpbin.org/post"
    json_data = {"key": "value"}
    # 测试 requests.post 简写形式
    response = requests.post(url, json=json_data)
    assert response.status_code == 201
    assert response.json() == {"data": "created"}
"""
    p = tmp_path / "test_sample_input.py"
    p.write_text(content, encoding="utf-8")
    return p

# -----------------------------------------------------------------------------
# Tests
# -----------------------------------------------------------------------------

def test_load_tests_from_file(sample_test_file):
    """
    测试 load_tests_from_file 方法。
    目标：验证是否能正确解析 AST 并提取 url, method, headers, body, original_status 等信息。
    """
    
    # --- [DEBUG START] 调试专用：读取本地文件覆盖 fixture (调试完请注释掉) ---
    debug_path = Path(r"D:\dev\smoke-test-recorder\generated_tests\test_prod_api_order_order_list.py")  # 修改为你的实际文件路径
    if debug_path.exists():
        print(f"\n[DEBUG] 正在使用本地文件覆盖测试输入: {debug_path}")
        print(f'读取到文件内容为:\n{debug_path.read_text(encoding="utf-8")}\n')
        sample_test_file = debug_path
    # --- [DEBUG END] -----------------------------------------------------

    print(f"\n\n[Test] load_tests_from_file: 读取文件 {sample_test_file}")
    
    refresher = ResponseRefresher()
    tests = refresher.load_tests_from_file(sample_test_file)
    
    print(f"[*] 解析到 {len(tests)} 个测试用例:")
    for i, t in enumerate(tests, 1):
        print(f"  {i}. Name: {t.get('name')}")
        print(f"     Method: {t.get('method')}")
        print(f"     URL: {t.get('url')}")
        print(f"     Headers: {t.get('headers')}")
        print(f"     Params: {t.get('params')}")
        print(f"     JSON: {t.get('json')}")
        print(f"     Original Status: {t.get('original_status')}")
        print(f"     Original Body: {t.get('original_body')}")
        print("-" * 40)

    # 简单断言验证
    assert len(tests) == 2
    assert tests[0]["name"] == "test_get_example"
    assert tests[0]["method"] == "GET"
    assert tests[0]["params"] == {"q": "python"}
    
    assert tests[1]["name"] == "test_post_example"
    assert tests[1]["method"] == "POST"
    assert tests[1]["json"] == {"key": "value"}


def test_run_request_for_test():
    """
    测试 run_request_for_test 方法。
    目标：验证是否正确调用了 session.request，并传递了正确的参数。
    """
    print("\n\n[Test] run_request_for_test: 模拟发送请求")
    
    # Mock session
    mock_session = MagicMock()
    mock_response = MagicMock()
    mock_response.status_code = 200
    mock_response.text = "ok"
    mock_session.request.return_value = mock_response
    
    refresher = ResponseRefresher(session=mock_session)
    
    test_def = {
        "method": "PUT",
        "url": "http://api.example.com/update",
        "headers": {"Authorization": "Bearer token"},
        "json": {"field": "new_value"}
    }
    
    response = refresher.run_request_for_test(test_def)
    
    # 验证调用参数
    call_args = mock_session.request.call_args
    print(f"[*] Session.request 调用参数: {call_args}")
    
    assert call_args[1]["method"] == "PUT"
    assert call_args[1]["url"] == "http://api.example.com/update"
    assert call_args[1]["json"] == {"field": "new_value"}
    assert response.status_code == 200
    print("[*] 请求参数验证通过")


def test_compare_response():
    """
    测试 compare_response 方法。
    目标：验证不同响应结果下的分类逻辑 (UNCHANGED, DATA_CHANGED, Failed)。
    """
    print("\n\n[Test] compare_response: 验证结果分类逻辑")
    refresher = ResponseRefresher()
    
    # 场景 1: 完全一致
    test_def_1 = {"original_body": {"a": 1}}
    resp_1 = MagicMock()
    resp_1.status_code = 200
    resp_1.json.return_value = {"a": 1}
    cat_1 = refresher.compare_response(test_def_1, resp_1)
    print(f"  Case 1 (Body一致): {cat_1} (预期: UNCHANGED)")
    assert cat_1 == ResultCategory.UNCHANGED

    # 场景 2: 数据变化
    test_def_2 = {"original_body": {"a": 1}}
    resp_2 = MagicMock()
    resp_2.status_code = 200
    resp_2.json.return_value = {"a": 2}
    cat_2 = refresher.compare_response(test_def_2, resp_2)
    print(f"  Case 2 (Body变化): {cat_2} (预期: DATA_CHANGED)")
    assert cat_2 == ResultCategory.DATA_CHANGED

    # 场景 3: 状态码非 200
    test_def_3 = {"original_body": {"a": 1}}
    resp_3 = MagicMock()
    resp_3.status_code = 500
    cat_3 = refresher.compare_response(test_def_3, resp_3)
    print(f"  Case 3 (Status 500): {cat_3} (预期: Failed)")
    assert cat_3 == ResultCategory.Failed

    # 场景 4: 原用例无 Body 断言 (视为 UNCHANGED)
    test_def_4 = {"original_body": None}
    resp_4 = MagicMock()
    resp_4.status_code = 200
    resp_4.json.return_value = {"any": "thing"}
    cat_4 = refresher.compare_response(test_def_4, resp_4)
    print(f"  Case 4 (原无断言): {cat_4} (预期: UNCHANGED)")
    assert cat_4 == ResultCategory.UNCHANGED


def test_write_refreshed_file(tmp_path):
    """
    测试 write_refreshed_file 方法。
    目标：验证生成的 Python 代码文件内容是否符合预期。
    """
    print("\n\n[Test] write_refreshed_file: 生成新文件")
    target_file = tmp_path / "refreshed_output.py"
    refresher = ResponseRefresher()
    
    tests = [
        {
            "name": "test_refreshed_success",
            "url": "http://api.com/success",
            "method": "GET",
            "headers": {"Accept": "application/json", "Authorization": "Bearer old"},
            "new_status": 200,
            "new_body": {"status": "ok", "id": 123},
            "category": ResultCategory.UNCHANGED
        },
        {
            "name": "test_refreshed_fail",
            "url": "http://api.com/fail",
            "method": "POST",
            "data": "raw_string_data",
            "new_status": 400,
            "new_body": {"error": "bad request"},
            "category": ResultCategory.Failed
        },
        {
            "name": "test_unexpected_error",
            "url": "http://api.com/error",
            "method": "GET",
            "error": "Connection refused",
            "category": ResultCategory.UNEXPECTED
        }
    ]
    
    refresher.write_refreshed_file("dummy_origin", target_file, tests, [])
    
    content = target_file.read_text(encoding="utf-8")
    print(f"[*] 文件写入路径: {target_file}")
    print("[*] 文件内容预览:\n")
    print(content)
    
    # 验证引入了 config
    assert "from generated_tests.config import BASE_URLS, AUTH_TOKENS" in content
    
    # 验证 test_refreshed_success
    assert "def test_refreshed_success():" in content
    # 验证 URL 拼接逻辑 (使用 .get)
    assert 'BASE = BASE_URLS.get("host_api_com", "http://api.com")' in content
    assert 'url = BASE + "/success"' in content
    # 验证 Headers 逻辑
    assert 'auth = AUTH_TOKENS.get("host_api_com", auth_from_capture)' in content
    assert "assert response.status_code == 200" in content
    assert '"status": "ok"' in content
    
    # 验证 test_refreshed_fail
    assert "def test_refreshed_fail():" in content
    assert "assert response.status_code == 400" in content
    # 验证 data 参数
    assert "data='raw_string_data'" in content
    
    # 验证 test_unexpected_error
    assert "def test_unexpected_error():" in content
    assert 'pytest.fail("Connection refused")' in content


def test_process_file_integration(sample_test_file, tmp_path):
    """
    测试 process_file 全流程。
    目标：模拟从读取 -> 请求 -> 比较 -> 写入的完整过程。
    """
    print("\n\n[Test] process_file: 完整流程集成测试")
    target_file = tmp_path / "final_result.py"
    
    # Mock session behavior
    mock_session = MagicMock()
    def side_effect(*args, **kwargs):
        resp = MagicMock()
        url = kwargs.get('url', '')
        if "httpbin.org/get" in url:
            # 模拟数据变化
            resp.status_code = 200
            resp.json.return_value = {"origin": "192.168.1.1", "url": "http://httpbin.org/get"}
            resp.text = json.dumps(resp.json.return_value)
        elif "httpbin.org/post" in url:
            # 模拟一致
            resp.status_code = 201
            resp.json.return_value = {"data": "created"}
            resp.text = json.dumps(resp.json.return_value)
        return resp
    
    mock_session.request.side_effect = side_effect
    
    refresher = ResponseRefresher(session=mock_session)
    stats = refresher.process_file(sample_test_file, target_file)
    
    print(f"[*] 统计结果: {stats}")
    
    assert stats["total"] == 2
    assert stats["data_changed"] == 1  # get 接口 IP 变了
    assert stats["unchanged"] == 1     # post 接口没变
    
    print("[*] 生成文件内容:")
    print(target_file.read_text(encoding="utf-8"))