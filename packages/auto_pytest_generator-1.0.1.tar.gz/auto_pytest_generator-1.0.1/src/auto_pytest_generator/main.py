import asyncio
import re
import click
from typing import Sequence
from mitmproxy.tools.dump import DumpMaster
from mitmproxy.options import Options
from urllib.parse import urlparse
from .dispatcher_addon import DispatcherAddon
from .pytest_generator import PytestGenerator
from .response_refresher import ResponseRefresher, ResultCategory
from pathlib import Path

async def start_recorder(
        port: int, url_prefixes: Sequence[str], response_mode: str = "json"
):
    """
    启动 mitmproxy 并只对指定的 URL 前缀进行录制。

    参数:
    - port: 本地监听端口
    - url_prefixes: 可重复的 --url-prefix 参数（例如:
        --url-prefix http://1.2.3.4:8000/api --url-prefix http://5.6.7.8:9000/v1）
      mitmproxy 会被配置为只允许这些 host，另外在 通过DispatcherAddon 基于完整前缀(包含 path)
      进行精确过滤，确保只有匹配前缀的请求会被传给生成器。
    """
    # 1. 解析每个前缀的 host（netloc），并收集用于 mitmproxy Options.allow_hosts 的值
    hosts = []
    normalized_prefixes = []
    for p in url_prefixes:
        try:
            parsed = urlparse(p)
            host = parsed.netloc
            if not host:
                raise ValueError
            hosts.append(host)
            # 保留原始前缀，用于在运行时基于完整 URL 做精确匹配
            normalized_prefixes.append(p)
        except Exception:
            click.secho(
                f"Error: Invalid --url-prefix '{p}'. 请提供完整 URL，如 'http://example.com/api'.",
                fg="red",
            )
            return

    # 去重 hosts
    hosts = list(dict.fromkeys(hosts))

    # 2. 配置 mitmproxy 的 allow_hosts，mitmproxy 接受正则表达式列表。
    #    这里我们对 host 进行转义，确保点等字符被正确处理。
    allow_hosts_regex = [re.escape(h) for h in hosts]

    opts = Options(
        listen_host="127.0.0.1",
        listen_port=port,
        # allow_hosts 是一个正则列表，mitmproxy 只会允许匹配这些 host 的流量进入。
        allow_hosts=allow_hosts_regex,
    )

    # 3. 创建 DumpMaster 并加载 addon。我们不直接把 generator_addon 暴露给 master，
    #    而是通过一个中间 FilterAddon 只把匹配任一前缀的请求/响应转发给生成器，
    #    同时也可以在这里扩展静态资源过滤（如果需要）。
    master = DumpMaster(opts, with_termlog=True)

    # 原 generator（保留原始接口，传入第一个前缀作为默认描述）
    # 如果 addon.PytestGenerator 支持多个前缀可以在此调整传参。
    # 为每个 url_prefix 创建一个独立的 PytestGenerator 实例，
    # 并为每个实例注册一个只转发该前缀流量的 FilterAddon。
    # 这样可以确保多个 --url-prefix 的流量都会被各自的 generator 处理并生成用例。
    generators = []
    for p in normalized_prefixes:
        try:
            gen = PytestGenerator(url_prefix=p, response_mode=response_mode)
        except TypeError:
            # 兼容：如果旧版 addon 不接受 response_mode，则退回
            try:
                gen = PytestGenerator(p)
            except Exception:
                raise
        generators.append((p, gen))



    # 只注册一个分发器实例，内部包含所有 (prefix, generator) 对
    master.addons.add(DispatcherAddon(generators))

    click.echo(f"[*] Proxy started on 127.0.0.1:{port}")
    click.echo(f"[*] Recording traffic for prefixes: {', '.join(normalized_prefixes)}")

    click.echo(f"[*] Extracted hosts (unescaped): {', '.join(hosts)}")
    click.echo(
        "[*] Only requests to the above hosts whose full URL starts with one of the provided prefixes will be recorded as pytest cases."
    )
    click.echo(
        "[*] Visit http://mitm.it in your browser to verify the proxy certificate/connection."
    )

    click.echo("[*] Press Ctrl+C to stop.")

    try:
        await master.run()
    except KeyboardInterrupt:
        master.shutdown()


async def start_refresh_testcase(
    origin_dir: str = "generated_tests",
    target_dir: str = "refreshed_tests",
):
    """
    刷新用例：读取 origin_dir 下的测试文件，按文件级别交给 ResponseRefresher 处理，
    并把输出文件写入到 target_dir 保持原有目录结构。

    注意：具体的请求执行/断言比对/文件写入逻辑由 ResponseRefresher 提供（在 response_refresher.py 中定义接口）。
    这里负责文件遍历、目标路径创建以及并发调度（借助 asyncio.to_thread 调用阻塞实现）。
    """

    origin = Path(origin_dir)
    target = Path(target_dir)

    if not origin.exists() or not origin.is_dir():
        click.secho(f"Error: origin_dir '{origin}' 不存在或不是目录。", fg="red")
        return

    # 收集 pytest 识别的测试文件：test_*.py 和 *_test.py
    patterns = ["**/test_*.py", "**/*_test.py"]
    files = []
    for pat in patterns:
        files.extend([p for p in origin.glob(pat) if p.is_file()])

    # 去重（同一路径可能两次匹配）
    files = sorted(set(files))

    if not files:
        click.echo(f"[*] 没有在 '{origin}' 中发现测试文件。")
        return

    refresher = ResponseRefresher()
    # 与 response_refresher.py 中的 ResultCategory 保持一致：
    # - UNCHANGED: 与原用例一致
    # - DATA_CHANGED: code == 200 但数据变化
    # - Failed: 请求成功且有响应但 status_code != 200
    # - UNEXPECTED: 请求/解析等异常
    summary = {
        ResultCategory.UNCHANGED: 0,
        ResultCategory.DATA_CHANGED: 0,
        ResultCategory.Failed: 0,
        ResultCategory.UNEXPECTED: 0,
        "files": 0,
        "tests_total": 0,
    }

    click.echo(f"[*] Found {len(files)} test file(s) under '{origin}', refreshing into '{target}'...")

    for f in files:
        rel = f.relative_to(origin)
        out_path = target / rel
        out_path.parent.mkdir(parents=True, exist_ok=True)

        click.echo(f"[*] Processing: {rel}")

        try:
            # process_file 是阻塞函数（会执行 requests），在线程池中运行以避免阻塞事件循环
            result = await asyncio.to_thread(refresher.process_file, f, out_path)
        except Exception as e:
            # 将无法处理的文件算作 UNEXPECTED（例如解析失败、IO、超时等）
            click.secho(f"    ! Failed to process {rel}: {e}", fg="red")
            summary["files"] += 1
            # 无法得知 tests_total 时不增加 tests_total，记为一个文件级的 UNEXPECTED 事件
            summary[ResultCategory.UNEXPECTED] += 1
            continue

        # result 假定为 dict 包含 counts，例如:
        # {"total": N, "unchanged": a, "data_changed": b, "failed": c, "unexpected": d}
        summary["files"] += 1
        summary["tests_total"] += result.get("total", 0)
        summary[ResultCategory.UNCHANGED] += result.get("unchanged", 0)
        summary[ResultCategory.DATA_CHANGED] += result.get("data_changed", 0)
        summary[ResultCategory.Failed] += result.get("failed", 0)
        summary[ResultCategory.UNEXPECTED] += result.get("unexpected", 0)

        click.echo(
            f"    -> tests: {result.get('total',0)}, unchanged: {result.get('unchanged',0)}, "
            f"data_changed: {result.get('data_changed',0)}, failed(status!=200): {result.get('failed',0)}, "
            f"unexpected: {result.get('unexpected',0)}"
        )

    # 总结
    click.echo("\n[*] Refresh summary:")
    click.echo(f"    files processed: {summary['files']}")
    click.echo(f"    tests checked: {summary['tests_total']}")
    click.echo(f"    unchanged: {summary[ResultCategory.UNCHANGED]}")
    click.echo(f"    data changed: {summary[ResultCategory.DATA_CHANGED]}")
    click.echo(f"    failed (status != 200): {summary[ResultCategory.Failed]}")
    click.echo(f"    unexpected errors: {summary[ResultCategory.UNEXPECTED]}")
    click.echo(f"[*] Refreshed tests written to: {target}")
# 使用子命令组织 CLI： apg recorder ... 或 apg response-refresh ...
@click.version_option(version="1.0.1", prog_name="apg")
@click.group()
def cli():
    """auto-pytest-generator: subcommands: recorder | response-refresh"""
    pass

@cli.command("recorder")
@click.option("--port", default=5000, help="Proxy listen port", type=int)
@click.option(
    "--url-prefix",
    required=True,
    multiple=True,
    help="URL prefix of the target API. Can be provided multiple times.",
)
@click.option(
    "--response-mode",
    type=click.Choice(["json", "text"]),
    default="json",
    help="如何生成 response 断言（json/text）。",
)
def cmd_recorder(port, url_prefix, response_mode):
    try:
        asyncio.run(start_recorder(port, url_prefix, response_mode))
    except (KeyboardInterrupt, RuntimeError):
        pass
    click.echo("\n[*] Proxy server shut down.")
    click.echo("[*] Test cases have been generated in the 'generated_tests' directory.")

@cli.command("response-refresh")
@click.option("--origin-dir", "origin_dir", default="tests", help="被刷新的测试用例目录")
@click.option("---target-dir", "target_dir", default="refreshed_tests", help="刷新后生成的测试用例目录")
def cmd_response_refresh(origin_dir, target_dir):
    try:
        asyncio.run(
            start_refresh_testcase(
                origin_dir=origin_dir,
                target_dir=target_dir,
            )
        )
    except (KeyboardInterrupt, RuntimeError):
        pass

if __name__ == "__main__":
    cli()
