from typing import Sequence, Tuple
import re
from . import pytest_generator

class DispatcherAddon:
    """
    单一分发器：
    - 跳过静态资源（按扩展名）
    - 将符合各个前缀的 flow 分发给对应的 generator 实例
    这样只需向 mitmproxy 注册一个 addon 实例，避免重复注册同名 addon 导致的错误。
    """
    # 静态资源扩展名正则（按需增减）
    STATIC_EXT_PATTERN = (
        r"\.(css|js|jpg|jpeg|png|gif|svg|woff2?|ttf|map|ico|json|xml|eot|otf)(?:[?#]|$)"
    )
    static_re = re.compile(STATIC_EXT_PATTERN, re.IGNORECASE)

    def __init__(
            self, prefix_generator_pairs: Sequence[Tuple[str, "pytest_generator.PytestGenerator"]]
    ):
        # prefix_generator_pairs: list of (prefix, generator)
        self.pairs = [(str(p), g) for p, g in prefix_generator_pairs]

    def _is_static(self, flow):
        url = getattr(flow.request, "url", "") or getattr(
            flow.request, "pretty_url", ""
        )
        return bool(self.static_re.search(url))

    def _matching_generators(self, flow):
        url = getattr(flow.request, "url", "") or getattr(
            flow.request, "pretty_url", ""
        )
        matches = []
        for prefix, gen in self.pairs:
            if url.startswith(prefix):
                matches.append(gen)
        return matches

    def request(self, flow):
        if self._is_static(flow):
            return
        matches = self._matching_generators(flow)
        if not matches:
            return
        for gen in matches:
            if hasattr(gen, "request"):
                try:
                    gen.request(flow)
                except Exception:
                    # 不让单个 generator 异常影响分发逻辑
                    pass

    def response(self, flow):
        if self._is_static(flow):
            return
        matches = self._matching_generators(flow)
        if not matches:
            return
        for gen in matches:
            if hasattr(gen, "response"):
                try:
                    gen.response(flow)
                except Exception:
                    pass
