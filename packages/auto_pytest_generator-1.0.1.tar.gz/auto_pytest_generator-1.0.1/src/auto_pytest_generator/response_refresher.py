from enum import Enum
from pathlib import Path
from typing import Any, Dict, List, Optional, Union
import ast
import requests
import re
import shutil
import pytest  # <--- 新增导入
from unittest.mock import MagicMock
from urllib.parse import urlparse
from pprint import pformat
from jinja2 import Environment, FileSystemLoader

class ResultCategory(Enum):
    UNCHANGED = "unchanged"
    DATA_CHANGED = "data_changed"
    Failed = "failed"
    UNEXPECTED = "unexpected"

    @property
    def label(self):
        return {
            ResultCategory.UNCHANGED: "与原用例一致",
            ResultCategory.DATA_CHANGED: "code == 200但数据变化",
            ResultCategory.Failed: "code != 200",
            ResultCategory.UNEXPECTED: "其他错误",
        }[self]


class ResponseRefresher:
    def __init__(self, session=None, timeout: int = 10):
        self.session = session if session else requests.Session()
        self.timeout = timeout
        # 初始化 Jinja2 环境
        template_dir = Path(__file__).parent / "templates"
        self.jinja_env = Environment(loader=FileSystemLoader(template_dir))

    def process_file(self, origin_path: Union[str, Path], target_path: Union[str, Path]) -> Dict[str, Any]:
        """
        高层处理流程（同步）：
        1. load_tests_from_file: 解析 origin_path 得到内部的测试用例描述
        2. 对每个测试用例调用 run_request_for_test 获取实际 response
        3. compare_response 决定分类（ResultCategory）
        4. write_refreshed_file: 根据比较结果和原始内容生成 target_path 输出文件
        5. 返回统计信息
        """
        origin_path = Path(origin_path)
        target_path = Path(target_path)

        # 确保目标目录存在
        if not target_path.parent.exists():
            target_path.parent.mkdir(parents=True, exist_ok=True)

        # 确保目标目录包含 __init__.py 以支持相对导入 (from .config import ...)
        init_file = target_path.parent / "__init__.py"
        if not init_file.exists():
            init_file.touch()

        # 0. 尝试拷贝 config.py (如果源目录有，且目标目录没有)
        src_config = origin_path.parent / "config.py"
        dst_config = target_path.parent / "config.py"
        if src_config.exists() and not dst_config.exists():
            try:
                shutil.copy2(src_config, dst_config)
            except Exception:
                pass

        # 1. 解析
        try:
            tests = self.load_tests_from_file(origin_path)
        except Exception as e:
            # 如果文件解析都失败了，直接抛出，由上层捕获记为文件级 UNEXPECTED
            raise RuntimeError(f"Failed to parse test file {origin_path}: {e}")

        results: List[ResultCategory] = []

        # 2. 执行与比对
        for test_def in tests:
            try:
                response = self.run_request_for_test(test_def)
                # 记录实际响应结果到 test_def，方便后续写入
                try:
                    json_body = response.json()
                except ValueError:
                    json_body = None
                
                test_def["new_status"] = response.status_code
                test_def["new_body"] = json_body
                test_def["new_text"] = response.text

                category = self.compare_response(test_def, response)
            except Exception as e:
                category = ResultCategory.UNEXPECTED
                test_def["error"] = str(e)
            
            results.append(category)
            test_def["category"] = category

        # 3. 写入
        # 修复：第4个参数 failed_tests 期望是 dict 列表，之前错误传入了 results (Enum列表)
        # 当前逻辑下 tests 包含了所有用例（含出错的），所以 failed_tests 传空即可
        self.write_refreshed_file(origin_path, target_path, tests, [])

        # 4. 统计
        stats = {
            "file": str(origin_path),
            "total": len(tests),
            "unchanged": sum(1 for r in results if r == ResultCategory.UNCHANGED),
            "data_changed": sum(1 for r in results if r == ResultCategory.DATA_CHANGED),
            "failed": sum(1 for r in results if r == ResultCategory.Failed),
            "unexpected": sum(1 for r in results if r == ResultCategory.UNEXPECTED),
        }
        return stats

    def load_tests_from_file(self, path: Union[str, Path]) -> List[Dict[str, Any]]:
        """
        解析 pytest 文件，提取每个测试用例所需的信息。
        通过 AST 修改 + exec 执行的方式，处理 config 依赖和动态 URL。
        """
        path = Path(path)
        with open(path, "r", encoding="utf-8") as f:
            source = f.read()
        
        tree = ast.parse(source)
        tests = []

        # 1. 准备上下文：尝试加载同级目录下的 config.py
        config_context = {"BASE_URLS": {}, "AUTH_TOKENS": {}}
        config_path = path.parent / "config.py"
        if config_path.exists():
            try:
                with open(config_path, "r", encoding="utf-8") as f:
                    # 执行 config.py 获取变量
                    exec(f.read(), {}, config_context)
            except Exception:
                pass 
        
        # 2. 预处理 AST：移除相对导入 (from .config import ...)，防止 exec 报错
        new_body = []
        for node in tree.body:
            if isinstance(node, ast.ImportFrom) and node.module == 'config' and node.level == 1:
                continue # 跳过相对导入
            new_body.append(node)
        tree.body = new_body

        # 3. 准备全局执行环境
        global_context = {}
        # 注入 config 变量
        global_context.update(config_context)
        # 注入常用库，防止 NameError
        global_context["pytest"] = pytest
        global_context["requests"] = requests

        # 4. 执行模块级代码 (获取 imports, constants, helper functions)
        try:
            code = compile(tree, filename=str(path), mode="exec")
            exec(code, global_context)
        except Exception as e:
            print(f"Warning: Failed to exec module level code for {path.name}: {e}")
            # 继续尝试，因为可能只是部分代码执行失败
        
        # 5. 遍历并提取测试函数
        for node in tree.body:
            if isinstance(node, ast.FunctionDef) and node.name.startswith("test_"):
                # 从 global_context 中获取已定义的函数对象
                func_obj = global_context.get(node.name)
                if func_obj:
                    test_info = self._extract_test_info_by_execution(func_obj, node.name)
                    if test_info:
                        # 补充原始 AST 中的 docstring 或其他静态信息
                        test_info["docstring"] = ast.get_docstring(node)
                        # 尝试从 AST 提取 expected_response
                        test_info["original_body"] = self._extract_expected_response_from_ast(node)
                        tests.append(test_info)
        
        return tests

    def _extract_expected_response_from_ast(self, func_node: ast.FunctionDef) -> Any:
        """
        从 AST 中提取 expected_response 变量的值。
        """
        for stmt in func_node.body:
            if isinstance(stmt, ast.Assign):
                # 检查赋值目标是否是 expected_response
                for target in stmt.targets:
                    if isinstance(target, ast.Name) and target.id == "expected_response":
                        # 尝试解析赋值的值
                        try:
                            return ast.literal_eval(stmt.value)
                        except Exception:
                            pass
        return None

    def _extract_test_info_by_execution(self, func_obj, func_name) -> Optional[Dict[str, Any]]:
        """
        通过 Mock requests 并实际执行函数来提取参数。
        """
        captured = {}

        # 定义 Mock 的 requests.request
        def mock_request(method, url, **kwargs):
            captured["method"] = method
            captured["url"] = url
            captured["headers"] = kwargs.get("headers", {})
            captured["json"] = kwargs.get("json")
            captured["data"] = kwargs.get("data")
            # 返回一个 Mock 响应，防止后续代码报错（如 assert response.status_code）
            mock_resp = MagicMock()
            mock_resp.status_code = 200
            mock_resp.json.return_value = {}
            mock_resp.text = ""
            return mock_resp

        # 替换全局 requests
        original_request = requests.request
        requests.request = mock_request
        
        # 同时也需要 Mock requests.get, requests.post 等
        original_get = requests.get
        original_post = requests.post
        requests.get = lambda url, **kwargs: mock_request("GET", url, **kwargs)
        requests.post = lambda url, **kwargs: mock_request("POST", url, **kwargs)

        try:
            # 执行测试函数
            # 注意：如果函数内有 pytest.fail，会抛出 Failed 异常，需要捕获
            try:
                func_obj()
            except Exception:
                pass # 我们只关心执行过程中是否调用了 request
            
            if not captured:
                return None

            # 提取原始期望结果 (从源码或 docstring 很难提取，这里主要提取请求参数)
            # 对于 Refresher 来说，original_status 和 original_body 
            # 最好是从 docstring 或之前的运行记录提取，但现在模板里没有存这些。
            # 暂时设为 None，Refresher 主要关注本次运行结果。
            
            return {
                "name": func_name,
                "url": captured.get("url"),
                "method": captured.get("method"),
                "headers": captured.get("headers"),
                "json": captured.get("json"),
                "data": captured.get("data"),
                "original_status": "Unknown", # 无法从代码简单反推
                "original_body": None
            }

        finally:
            # 恢复环境
            requests.request = original_request
            requests.get = original_get
            requests.post = original_post

    def run_request_for_test(self, test_def: Dict[str, Any]) -> requests.Response:
        """
        根据中间表示发起 HTTP 请求并返回 requests.Response。
        """
        method = test_def.get("method", "GET")
        url = test_def.get("url")
        headers = test_def.get("headers")
        params = test_def.get("params")
        json_data = test_def.get("json")
        data = test_def.get("data")

        return self.session.request(
            method=method,
            url=url,
            headers=headers,
            params=params,
            json=json_data,
            data=data,
            timeout=self.timeout
        )

    def compare_response(self, test_def: Dict[str, Any], response: requests.Response) -> ResultCategory:
        """
        对比 response 与原始测试用例中的断言。
        """
        # 1. 检查状态码
        if response.status_code != 200:
            return ResultCategory.Failed
        
        # 2. 检查数据 (仅当 status == 200)
        # 如果原用例没有 body 断言，则视为 UNCHANGED (或者无法判断)
        if test_def.get("original_body") is None:
            return ResultCategory.UNCHANGED

        try:
            current_json = response.json()
            # 简单的全量比对，实际场景可能需要忽略某些字段
            if current_json == test_def["original_body"]:
                return ResultCategory.UNCHANGED
            else:
                return ResultCategory.DATA_CHANGED
        except ValueError:
            # 响应不是 JSON，但原断言是 JSON -> 视为数据变化
            return ResultCategory.DATA_CHANGED

    def _safe_key_from_netloc(self, netloc: str) -> str:
        """生成合法的 config key，与 PytestGenerator 保持一致"""
        key = re.sub(r'[^0-9a-zA-Z]', '_', netloc)
        return f"host_{key}"

    def write_refreshed_file(self, original_file_name: str, target_file: Path, tests: list, failed_tests: list):
        """
        使用 pytest_template.jinja2 模板生成刷新后的测试文件。
        """
        tests_context = []
        
        # 处理正常执行的测试（包括执行失败但捕获了结果的）
        for t in tests:
            url = t.get("url", "")
            parsed = urlparse(url)
            base_netloc = parsed.netloc
            base_key = self._safe_key_from_netloc(base_netloc)
            
            path_query = parsed.path or ""
            if parsed.query:
                path_query += "?" + parsed.query
            
            # Headers 处理
            headers = t.get("headers", {})
            
            # Payload 处理
            payload_arg = ""
            if t.get("json"):
                payload_arg = f"json={t.get('json')}"
            elif t.get("data"):
                payload_arg = f"data={repr(t.get('data'))}"
            
            # Response Body 处理
            new_body = t.get("new_body")
            is_json = False
            response_data_py = ""
            response_data_text = ""
            
            if isinstance(new_body, (dict, list)):
                is_json = True
                response_data_py = pformat(new_body, width=120, sort_dicts=False)
            else:
                response_data_text = str(new_body) if new_body is not None else ""

            docstring = (
                f"Refreshed test case.\n    "
                f"Original Status: {t.get('original_status')}\n    "
                f"New Status: {t.get('new_status')}\n    "
                f"Category: {t.get('category')}"
            )

            tests_context.append({
                "test_func_name": t.get("name"),
                "docstring": docstring,
                "error": t.get("error"),
                "base_key": base_key,
                "base_netloc": base_netloc,
                "path_query": path_query,
                "headers": headers,
                "method": t.get("method", "GET").lower(),
                "payload_arg": payload_arg,
                "response_status": t.get("new_status"),
                "is_json_response": is_json,
                "response_data_py": response_data_py,
                "response_data_text": response_data_text,
            })

        # 处理完全无法执行的测试（如解析错误等）
        for ft in failed_tests:
            tests_context.append({
                "test_func_name": ft.get("name", "unknown_test"),
                "docstring": "Execution failed during refresh",
                "error": ft.get("error", "Unknown error"),
                # 提供默认值防止模板报错（虽然有 if error 判断）
                "base_key": "", "base_netloc": "", "path_query": "", "headers": {},
                "method": "", "payload_arg": "", "response_status": 0,
                "is_json_response": False, "response_data_py": "", "response_data_text": ""
            })

        template = self.jinja_env.get_template("pytest_template.jinja2")
        # 传入 tests 列表，适配模板的循环结构
        rendered_code = template.render(tests=tests_context)
        
        target_file.write_text(rendered_code, encoding="utf-8")





