"""
移动端视觉识别模块
"""

from .vision_locator import MobileVisionLocator

__all__ = [
    'MobileVisionLocator',
]

