from abc import ABC, abstractmethod
from collections.abc import Collection, Sequence
from dataclasses import dataclass
from inspect import signature
from typing import Self
from uuid import UUID, uuid4

from dacite import from_dict

from schubladendenken.core.types import JSONType


class Label:
    def __init__(self, name: str, values: dict[int, str], uuid: UUID | None = None):
        self._check_value_integrity(values.values())
        self._name: str = name.strip()
        self._values: dict[int, str] = values
        self._uuid: UUID | None = uuid or uuid4()

    @property
    def uuid(self) -> UUID:
        return self._uuid

    @property
    def name(self) -> str:
        return self._name

    @name.setter
    def name(self, value: str) -> None:
        self._name = value.strip()

    @property
    def values(self) -> dict[int, str]:
        return self._values.copy()

    def rename_value(self, value: str, new: str) -> None:
        self._values = {index: new if name == value else name for index, name in self._values.items()}
        self._check_value_integrity(self._values.values())

    @classmethod
    def _check_value_integrity(cls, values: Collection[str]) -> None:
        if len(set(values)) != len(values):
            raise ValueError("Duplicate values found in label values")

    def __eq__(self, other: object) -> bool:
        return isinstance(other, Label) and self.uuid == other.uuid


@dataclass(frozen=True)
class LabelRepositoryConfig:
    pass


class LabelRepository[C: LabelRepositoryConfig](ABC):
    def __init__(self, config: C):
        self._config = config

    @abstractmethod
    def load(self, uuid: UUID) -> Label:
        """

        Args:
            uuid:

        Returns:

        """

    @abstractmethod
    def store(self, label: Label) -> None:
        """

        Args:
            label:

        Returns:

        """

    @abstractmethod
    def list(self, offset: int = 0, amount: int = 30) -> Sequence[Label]:
        """

        Args:
            offset:
            amount:

        Returns:

        """

    @classmethod
    def from_config(cls, config: C) -> Self:
        return cls(config)

    @classmethod
    def from_dict(cls, config: dict[str, JSONType]) -> Self:
        config_type: type[LabelRepositoryConfig] = signature(cls.__init__).parameters["config"].annotation
        return cls.from_config(from_dict(config_type, config))