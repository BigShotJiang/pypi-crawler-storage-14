from abc import ABC, abstractmethod
from collections import defaultdict
from collections.abc import Sequence, Iterable
from dataclasses import dataclass
from functools import partial
from inspect import signature
from random import choice
from typing import Self
from uuid import UUID, uuid4

from dacite import from_dict
from toolz import valmap

from schubladendenken.core.label import Label, LabelRepository
from schubladendenken.core.types import JSONType


class Subject[L](ABC):
    def __init__(self, location: L, uuid: UUID | None = None):
        self._location: L = location
        self._uuid: UUID = uuid or uuid4()
        self._labels: dict[UUID, dict[str, int]] = defaultdict(partial(defaultdict, int))

    def set_label(self, label: Label, value: str, weight: int = 1) -> None:
        if value not in label.values.values():
            raise ValueError(f"Value {value} not in label {label.name}")
        self._labels[label.uuid][value] += max(1, weight)

    @classmethod
    def create_from(cls, location: str, uuid: UUID | None = None) -> Self:
        return cls(cls._parse_location(location), uuid)

    @property
    def votes(self) -> int:
        return sum(votes for labels in self._labels.values() for votes in labels.values())

    @property
    def uuid(self) -> UUID:
        return self._uuid

    @property
    def labels(self) -> dict[UUID, set[str]]:
        return {uuid: set(set_labels) for uuid, set_labels in self._labels.items()}

    @property
    def label_counts(self) -> dict[UUID, dict[str, int]]:
        return valmap(dict, self._labels)

    @property
    @abstractmethod
    def content(self) -> bytes:
        """

        Returns:

        """

    @property
    @abstractmethod
    def mime_type(self) -> str:
        """

        Returns:

        """

    @property
    @abstractmethod
    def __dto__(self) -> dict[str, JSONType]:
        """

        Returns:

        """

    @classmethod
    @abstractmethod
    def from_dto(cls, dto: dict[str, JSONType], label_repo: LabelRepository) -> Self:
        """

        Args:
            dto:
            label_repo:

        Returns:

        """

    @classmethod
    @abstractmethod
    def _parse_location(cls, location: str) -> L:
        """

        Args:
            location:

        Returns:

        """

    @classmethod
    def _subclasses(cls) -> Iterable[type[Self]]:
        yield cls
        yield from cls.__subclasses__()

    @classmethod
    def get_type_by_name(cls, name: str) -> type[Self]:
        for subclass in cls._subclasses():
            if subclass.__name__ == name:
                return subclass
        raise LookupError(f"No subclass found for name {name}")





@dataclass(frozen=True)
class SubjectRepositoryConfig:
    pass


class SubjectRepository[C: SubjectRepositoryConfig](ABC):
    def __init__(self, config: C, label_repo: LabelRepository):
        self._config: C = config
        self._label_repo: LabelRepository = label_repo

    @abstractmethod
    def load(self, uuid: UUID) -> Subject:
        """

        Args:
            uuid:

        Returns:

        """


    @abstractmethod
    def store(self, subject: Subject) -> None:
        """

        Args:
            subject:

        Returns:

        """

    @abstractmethod
    def list(self, offset: int = 0, amount: int = 30) -> Sequence[UUID]:
        """

        Args:
            offset:
            amount:

        Returns:

        """

    def random(self) -> Subject:
        return self.load(choice(self.list()))

    @classmethod
    def from_config(cls, config: C, label_repo: LabelRepository) -> Self:
        return cls(config, label_repo)

    @classmethod
    def from_dict(cls, config: dict[str, JSONType], label_repo: LabelRepository) -> Self:
        config_type: type[SubjectRepositoryConfig] = signature(cls.__init__).parameters["config"].annotation
        return cls.from_config(from_dict(config_type, config), label_repo)