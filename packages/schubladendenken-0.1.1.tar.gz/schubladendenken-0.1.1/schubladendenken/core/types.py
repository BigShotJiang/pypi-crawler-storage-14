type PrimitiveType = int | float | str | None | bool
type JSONType = PrimitiveType | list[JSONType] | dict[str, JSONType]