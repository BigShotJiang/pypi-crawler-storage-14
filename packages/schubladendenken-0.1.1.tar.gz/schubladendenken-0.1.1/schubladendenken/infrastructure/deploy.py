from fastapi import FastAPI

from schubladendenken.adapter.rest.api import RestAPIBuilder
from schubladendenken.adapter.rest.client import APIClient
from schubladendenken.external_server.subject.contained import ContainedSubject
from schubladendenken.infrastructure.configuration import ConfigFileParser, ConfigurationParser


def build_rest_api(
    config: ConfigurationParser
) -> FastAPI:
    label_repo = config.label_repo()
    subject_repo = config.subject_repo()
    return RestAPIBuilder(label_repo, subject_repo, ContainedSubject, APIClient(root=config.root_path)).build()


app: FastAPI = build_rest_api(ConfigFileParser())