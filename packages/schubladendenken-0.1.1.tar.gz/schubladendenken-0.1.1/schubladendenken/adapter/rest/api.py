import uuid
from random import choice
from uuid import UUID

from fastapi import FastAPI, UploadFile, File, Form
from fastapi_offline import FastAPIOffline
from pydantic import BaseModel
from starlette.responses import Response, RedirectResponse

from schubladendenken.adapter.rest.client import APIClient
from schubladendenken.core.label import LabelRepository, Label
from schubladendenken.core.subject import SubjectRepository, Subject
from schubladendenken.external_server.subject.contained import ContainedSubject


class LabelItem(BaseModel):
    uuid: UUID
    name: str
    values: dict[int, str]

    @classmethod
    def from_domain(cls, label: Label):
        return cls(uuid=label.uuid, name=label.name, values=label.values)


class NewLabelRequest(BaseModel):
    name: str
    values: set[str]

class NewSubjectRequest(BaseModel):
    location: str
    uuid: UUID | None = None

class LabelRequestItem(BaseModel):
    label: UUID
    value: str

class LabelPage(BaseModel):
    labels: list[LabelItem]
    offset: int

class ResultItem(BaseModel):
    uuid: UUID
    labels: dict[UUID, dict[str, int]]

class ResultPage(BaseModel):
    offset: int
    results: list[ResultItem]

class SubjectPage(BaseModel):
    offset: int
    uuids: list[UUID]


class RestAPIBuilder:
    def __init__(
            self,
            label_repository: LabelRepository,
            subject_repository: SubjectRepository,
            subject_type: type[Subject] = ContainedSubject,
            client: APIClient | None = APIClient()
    ):
        self._app: FastAPI = FastAPIOffline()
        self._label_repository: LabelRepository = label_repository
        self._subject_repository: SubjectRepository = subject_repository
        self._subject_type: type[Subject] = subject_type
        self._client: APIClient = client

    def build(self) -> FastAPI:
        self._build_label_routes()
        self._build_subject_routes()
        self._build_result_routes()
        if self._client:
            self._build_client_routes()
        return self._app

    def _build_label_routes(self) -> None:
        @self._app.get("/labels")
        def _get_labels_endpoint(offset: int = 0, amount: int = 100) -> LabelPage:
            return LabelPage(
                labels=list(map(LabelItem.from_domain, self._label_repository.list(offset, amount))),
                offset=offset
            )

        @self._app.get("/labels/{uuid}")
        def _get_label_endpoint(uuid: UUID) -> LabelItem:
            return LabelItem.from_domain(self._label_repository.load(uuid))

        @self._app.post("/labels")
        def _create_label_endpoint(item: NewLabelRequest) -> Response:
            label = Label(item.name, dict(enumerate(sorted(item.values))))
            self._label_repository.store(label)
            return Response(status_code=201, headers={"Location": f"/labels/{label.uuid}"})

    def _build_subject_routes(self) -> None:
        @self._app.get("/subjects/{uuid}")
        def _get_subject_endpoint(uuid: UUID) -> Response:
            subject = self._subject_repository.load(uuid)
            return Response(content=subject.content, media_type=subject.mime_type)

        @self._app.get("/subjects")
        def _list_subjects_endpoint(offset: int = 0, amount: int = 100) -> SubjectPage:
            return SubjectPage(
                offset=offset,
                uuids=list(self._subject_repository.list(offset, amount))
            )


        @self._app.put("/subjects/{uuid}")
        def _label_subject_endpoint(uuid: UUID, item: LabelRequestItem) -> Response:
            subject = self._subject_repository.load(uuid)
            subject.set_label(self._label_repository.load(item.label), item.value)
            self._subject_repository.store(subject)
            return Response(status_code=204)

        @self._app.post("/subjects/{uuid}/{label}")
        def _label_subject_explicit_endpoint(uuid: UUID, label: UUID, decision: str = Form(...)) -> Response:
            subject = self._subject_repository.load(uuid)
            subject.set_label(self._label_repository.load(label), decision)
            self._subject_repository.store(subject)
            return RedirectResponse(f"/client/{label}", status_code=303)

        @self._app.post("/subjects")
        def _create_subject_endpoint(item: NewSubjectRequest) -> Response:
            subject: Subject = self._subject_type.create_from(item.location, item.uuid)
            self._subject_repository.store(subject)
            return Response(status_code=201, headers={"Location": f"/subjects/{subject.uuid}"})

        if issubclass(self._subject_type, ContainedSubject):
            @self._app.post("/subjects/upload")
            async def _upload_endpoint(file: UploadFile = File(...)) -> Response:
                contents: bytes = await file.read()

                subject: Subject = self._subject_type(contents, file.content_type)
                self._subject_repository.store(subject)
                return Response(status_code=201, headers={"Location": f"/subjects/{subject.uuid}"})


    def _build_result_routes(self) -> None:
        @self._app.get("/results")
        def _list_subjects_endpoint(offset: int = 0, amount: int = 100) -> ResultPage:
            return ResultPage(
                offset=offset,
                results=[
                    ResultItem(uuid=uuid, labels=self._subject_repository.load(uuid).label_counts)
                    for uuid in self._subject_repository.list(offset, amount)
                ]
            )

    def _build_client_routes(self) -> None:
        @self._app.get("/client/{uuid}")
        def _serve_client(uuid: UUID) -> Response:
            labels: Label = self._label_repository.load(uuid)
            subject: Subject = self._subject_repository.random()
            return Response(content=self._client.serve(subject, labels), media_type="text/html")