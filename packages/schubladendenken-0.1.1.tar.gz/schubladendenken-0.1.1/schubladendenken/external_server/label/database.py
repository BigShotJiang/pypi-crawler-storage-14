from dataclasses import dataclass
from typing import Sequence, Self
from uuid import UUID

from sqlalchemy import create_engine, Engine, JSON
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, sessionmaker
from toolz import keymap

from schubladendenken.core.label import LabelRepository, LabelRepositoryConfig, Label



class _Base(DeclarativeBase):
    pass


class _Label(_Base):
    __tablename__ = "labels"

    uuid: Mapped[UUID] = mapped_column(primary_key=True)
    name: Mapped[str] = mapped_column()
    values: Mapped[dict[int, str]] = mapped_column(JSON, default={})

    def to_domain(self) -> Label:
        return Label(self.name, keymap(int, self.values), self.uuid)

    @classmethod
    def from_domain(cls, label: Label) -> Self:
        return cls(uuid=label.uuid, name=label.name, values=label.values)


@dataclass(frozen=True)
class DatabaseLabelRepositoryConfig(LabelRepositoryConfig):
    uri: str


class DatabaseLabelRepository(LabelRepository[DatabaseLabelRepositoryConfig]):
    def __init__(self, config: DatabaseLabelRepositoryConfig):
        super().__init__(config)
        self._engine: Engine = create_engine(config.uri)
        self._create_session: sessionmaker = sessionmaker(bind=self._engine)
        _Base.metadata.create_all(self._engine, checkfirst=True)


    def load(self, uuid: UUID) -> Label:
        with self._create_session() as session:
            return session.query(_Label).filter(_Label.uuid == uuid).one().to_domain()

    def store(self, label: Label) -> None:
        with self._create_session() as session:
            session.merge(_Label.from_domain(label))
            session.commit()

    def list(self, offset: int = 0, amount: int = 30) -> Sequence[Label]:
        with self._create_session() as session:
            return [
                label.to_domain()
                for label in session.query(_Label).order_by(_Label.uuid).offset(offset).limit(amount).all()
            ]



