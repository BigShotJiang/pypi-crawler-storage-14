from base64 import b85encode, b85decode, b64decode
from typing import Self
from uuid import UUID

from magic import Magic

from schubladendenken.core.label import LabelRepository, Label
from schubladendenken.core.subject import Subject
from schubladendenken.core.types import JSONType


class ContainedSubject(Subject[bytes]):
    def __init__(self, content: bytes, mime_type: str, uuid: UUID | None = None):
        super().__init__(content, uuid)
        self._mime_type: str = mime_type

    @classmethod
    def create_from(cls, location: str, uuid: UUID | None = None) -> Self:
        content: bytes = cls._parse_location(location)
        mime: str = Magic(mime=True).from_buffer(content)
        return cls(content, mime, uuid)

    @property
    def content(self) -> bytes:
        return self._location

    @property
    def __dto__(self) -> dict[str, JSONType]:
        return {
            "mime_type": self._mime_type,
            "content": b85encode(self.content).decode(),
            "uuid": self.uuid.hex,
            "labels": {label.hex: value for label, value in self._labels.items()}
        }

    @property
    def mime_type(self) -> str:
        return self._mime_type

    def _restore_labels(self, labels: dict[str, dict[str, int]], label_repo: LabelRepository) -> None:
        for uuid_hex, counts in labels.items():
            uuid: UUID = UUID(uuid_hex)
            for value, count in counts.items():
                try:
                    label: Label = label_repo.load(uuid)
                    self.set_label(label, value, count)
                except (FileNotFoundError, ValueError):
                    pass

    @classmethod
    def from_dto(cls, dto: dict[str, JSONType], label_repo: LabelRepository) -> Self:
        match dto:
            case {"mime_type": str(mime_type), "content": str(content), "uuid": str(uuid), "labels": {**labels}}:
                subject: ContainedSubject = cls(b85decode(content), mime_type, UUID(uuid))
                subject._restore_labels(labels, label_repo)
                return subject

    @classmethod
    def _parse_location(cls, location: str) -> bytes:
        return b64decode(location)