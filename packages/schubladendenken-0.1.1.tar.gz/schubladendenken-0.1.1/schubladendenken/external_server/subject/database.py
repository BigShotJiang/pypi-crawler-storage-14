from dataclasses import dataclass
from random import choice
from typing import Sequence
from uuid import UUID

from sqlalchemy import create_engine, JSON
from sqlalchemy.orm import sessionmaker, DeclarativeBase, Mapped
from sqlalchemy.testing.schema import mapped_column

from schubladendenken.core.label import LabelRepository
from schubladendenken.core.subject import SubjectRepository, SubjectRepositoryConfig, Subject
from schubladendenken.core.types import JSONType


class _Base(DeclarativeBase):
    pass


class _Subject(_Base):
    __tablename__ = "subjects"
    uuid: Mapped[UUID] = mapped_column(primary_key=True)
    type: Mapped[str] = mapped_column()
    dto: Mapped[dict[str, JSONType]] = mapped_column(JSON)
    votes: Mapped[int] = mapped_column(default=0)

@dataclass(frozen=True)
class DatabaseSubjectRepositoryConfig(SubjectRepositoryConfig):
    uri: str

class DatabaseSubjectRepository(SubjectRepository[DatabaseSubjectRepositoryConfig]):
    def __init__(self, config: DatabaseSubjectRepositoryConfig, label_repo: LabelRepository):
        super().__init__(config, label_repo)

        self._engine = create_engine(config.uri)
        self._create_session = sessionmaker(bind=self._engine)
        _Base.metadata.create_all(self._engine, checkfirst=True)

    def load(self, uuid: UUID) -> Subject:
        with self._create_session() as session:
            subject: _Subject = session.query(_Subject).filter(_Subject.uuid == uuid).one()
            return Subject.get_type_by_name(subject.type).from_dto(subject.dto, self._label_repo)

    def store(self, subject: Subject) -> None:
        with self._create_session() as session:
            session.merge(
                _Subject(uuid=subject.uuid, type=subject.__class__.__name__, dto=subject.__dto__, votes=subject.votes)
            )
            session.commit()

    def list(self, offset: int = 0, amount: int = 30) -> Sequence[UUID]:
        with self._create_session() as session:
            return tuple(
                subject.uuid for subject in session.query(_Subject).order_by(_Subject.uuid).offset(offset).limit(amount)
            )

    def random(self) -> Subject:
        with self._create_session() as session:
            subject: _Subject = choice(session.query(_Subject).order_by(_Subject.votes.asc()).limit(10).all())
            return Subject.get_type_by_name(subject.type).from_dto(subject.dto, self._label_repo)
