# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

__title__ = "release_flow_with_sample_api"
__version__ = "2.0.0"  # x-release-please-version
