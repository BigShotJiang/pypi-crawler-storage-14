"""ARX X5 SDK utility functions."""

from pathlib import Path

from .types import ArmType

_PACKAGE_DIR = Path(__file__).parent


def get_urdf_path(urdf_name: str = "x5_2025.urdf") -> str:
    """
    Get path to a URDF file included in the package.

    Args:
        urdf_name: URDF filename (e.g., "x5_2025.urdf")

    Returns:
        Absolute path to the URDF file

    Raises:
        FileNotFoundError: If URDF file doesn't exist
    """
    urdf_path = _PACKAGE_DIR / "urdf" / urdf_name
    if not urdf_path.exists():
        raise FileNotFoundError(f"URDF not found: {urdf_path}")
    return str(urdf_path)


def get_urdf_path_by_type(arm_type: ArmType) -> str:
    """
    Get URDF path for a given arm type.

    Args:
        arm_type: ArmType enum value

    Returns:
        Absolute path to the URDF file

    Raises:
        ValueError: If arm_type is invalid
    """
    urdf_map = {
        ArmType.FOLLOWER: "x5.urdf",
        ArmType.LEADER: "x5_master.urdf",
        ArmType.X5_2025: "x5_2025.urdf",
        ArmType.X5_2025_LOWER_MASS_LINK6: "x5_2025_lower_mass_link6.urdf",
    }

    if arm_type not in urdf_map:
        raise ValueError(
            f"Invalid arm_type: {arm_type}. "
            f"Must be one of: {', '.join(t.name for t in ArmType)}"
        )

    return get_urdf_path(urdf_map[arm_type])
