"""ARX X5 SDK high-level interface."""

from ._loader import load_extension
from .types import ArmType
from .utils import get_urdf_path_by_type

# Load C++ extension
_ext = load_extension()
C_ArxInterface = _ext.C_ArxInterface


class ArxInterface(C_ArxInterface):
    """
    High-level ARX interface with automatic URDF selection.

    Example:
        >>> arm = ArxInterface("can0", ArmType.X5_2025)
        >>> arm = ArxInterface("can1", arm_type=ArmType.LEADER)
    """

    def __init__(self, can_port: str, arm_type: ArmType = ArmType.X5_2025):
        """
        Initialize ARX interface.

        Args:
            can_port: CAN interface name (e.g., "can0")
            arm_type: Arm type enum (default: ArmType.X5_2025)
        """
        urdf_path = get_urdf_path_by_type(arm_type)
        super().__init__(urdf_path, can_port, int(arm_type))
        # Set ARX-recommended gains for consistent behavior across arms
        # (prevents model transfer issues due to varying actuator defaults)
        self.set_default_position_control_gains()

    def set_default_position_control_gains(self):
        """
        Set default PID-like control gains for position following speed.
        """
        self.set_position_control_gains(p=500.0, d=2000.0, i=10.0)

    def set_position_control_gains(self, p: float, d: float, i: float):
        """
        Set PID-like control gains for position following speed.

        Higher proportional (p) and derivative (d) gains result in faster position following,
        but may cause instability if set too high.

        Args:
            p: Proportional gain
            d: Derivative gain (recommended: d = 4*p)
            i: Integral gain (recommended constant 10.0)

        Example:
            >>> arm.set_position_control_gains(p=50, d=200)  # Slower, smoother motion
            >>> arm.set_position_control_gains(p=500, d=2000)  # Faster motion
        """
        self.arx_x(p, d, i)
