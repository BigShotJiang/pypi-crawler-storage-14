"""ARX X5 SDK type definitions."""

from enum import IntEnum


class ArmType(IntEnum):
    """
    ARX arm type identifiers.

    These values are passed to the C++ interface as the third argument:
    C_ArxInterface(urdf_path, can_port, arm_type_int)

    The integer values correspond to:
    - 0 (FOLLOWER): Regular follower arm configuration
    - 1 (LEADER): Leader/master arm configuration
    - 2 (X5_2025): X5 2025 model configuration
    """

    FOLLOWER = 0
    LEADER = 1
    X5_2025 = 2
    # Alias for X5_2025 - uses same C++ config but different URDF
    X5_2025_LOWER_MASS_LINK6 = 2


class ArmStatus(IntEnum):
    """ARX X5 arm status modes."""

    DISABLED = 0
    MOVE_HOME = 1
    PROTECT_MODE = 2
    GRAVITY_COMPENSATION = 3
    END_CONTROL = 4
    POSITION_CONTROL = 5
