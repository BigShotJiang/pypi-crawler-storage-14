import pytest
from pyvat_with_checksums.core import check_vat

VALID_VATS = [
    "SE000000002601",
    "SE000000003401",
    "SE000000004201",
    "SE000000006701",
    "SE000000007501",
    "SE000000008301",
    "SE000000010901",
    "SE000000011701",
    "SE000000012501",
    "SE000000014101",
    "SE000000015801",
    "SE000000016601",
    "SE000000018201",
    "SE000000019001",
    "SE000000020801",
    "SE502069927701",
    "SE202100281701",
    "SE202100287401",
    "SE202100293201",
    "SE202100297301",
    "SE202100305401",
    "SE202100306201",
    "SE202100309601",
    "SE202100321101",
    "SE202100509101",
    "SE262000119401",
    "SE390806051401",
    "SE502052817901",
    "SE502067960001",
    "SE516403812601",
    "SE516405444601",
    "SE556035133901",
    "SE556101935601",
    "SE556126249301",
    "SE556188840401",
    "SE556263276901",
    "SE556366804401",
    "SE556399449901",
    "SE556464687401",
    "SE556500060001",
    "SE556555952201",
    "SE556576895801",
    "SE556654042201",
    "SE556785615701",
]

INVALID_VATS = [
    "SE556188840301",
    "SE000000002301",
    "SE000000003301",
    "SE000000004301",
    "SE000000006301",
]


@pytest.mark.parametrize("vat", VALID_VATS)
def test_sweden_valid(vat):
    result = check_vat(vat)
    assert result.is_valid, f"Expected {vat} to be valid for Sweden"
    assert result.country.name == "Sweden"


@pytest.mark.parametrize("vat", INVALID_VATS)
def test_sweden_invalid(vat):
    result = check_vat(vat)
    # Some invalid VATs might match the format but fail the check digit,
    # or fail the format entirely.
    # But result.is_valid should definitely be False.
    assert not result.is_valid, f"Expected {vat} to be invalid for Sweden"
