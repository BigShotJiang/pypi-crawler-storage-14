import pytest
from pyvat_with_checksums.core import check_vat

VALID_VATS = [
    "HU10672101",
    "HU10724318",
    "HU10747759",
    "HU10766172",
    "HU10875153",
    "HU10891748",
    "HU11125248",
    "HU11162973",
    "HU11342261",
    "HU11377304",
    "HU11457695",
    "HU11683582",
    "HU11879318",
    "HU12082348",
    "HU12194339",
    "HU12476365",
    "HU12509403",
    "HU12618398",
    "HU12723650",
    "HU12783166",
    "HU12804825",
    "HU12840937",
    "HU13122605",
    "HU13245658",
    "HU13277279",
    "HU13460370",
    "HU13532774",
    "HU13597986",
    "HU13846077",
    "HU13949235",
    "HU14860955",
    "HU14915969",
    "HU15308744",
    "HU15329499",
    "HU15490012",
    "HU15598323",
    "HU17781279",
    "HU18173967",
    "HU18764325",
    "HU19002464",
    "HU19023229",
    "HU22919456",
    "HU23001363",
    "HU23157653",
    "HU23058176",
    "HU23143409",
    "HU23157653",
    "HU23474178",
    "HU63731758",
    "HU65730980",
]

INVALID_VATS = ["HU65730981", "HU65731980"]


@pytest.mark.parametrize("vat", VALID_VATS)
def test_hungary_valid(vat):
    result = check_vat(vat)
    assert result.is_valid, f"Expected {vat} to be valid for Hungary"
    assert result.country.name == "Hungary"


@pytest.mark.parametrize("vat", INVALID_VATS)
def test_hungary_invalid(vat):
    result = check_vat(vat)
    # Some invalid VATs might match the format but fail the check digit,
    # or fail the format entirely.
    # But result.is_valid should definitely be False.
    assert not result.is_valid, f"Expected {vat} to be invalid for Hungary"
