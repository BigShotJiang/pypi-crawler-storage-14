import pytest
from pyvat_with_checksums.core import check_vat

VALID_VATS = [
    "45.723.174/0001-10",
    "41142260000189",
    "10.984.785/0001-38",
    "17.469.701/0066-12",
    "15.530.875/0001-72",
    "00.028.666/0001-58",
    "02.248.426/0001-94",
    "24492886000104",
    "61797924000317",
    "59.748.988/0001-14",
    "33.000.167/0143-23",
    "62.858.352/0001-30",
    "54.821.137/0001-36",
    "08.356.731/0001-86",
    "00.429.640/0001-11",
    "20.722.213/0001-34",
    "05.454.389/0001-69",
    "82.027.129/0001-58",
    "02.061.065/0001-72",
    "09.039.988/0002-58",
    "58.426.628/0001-33",
    "27.851.302/0001-20",
    "15.675.599/0001-30",
    "71.256.283/0001-85",
    "59.104.901/0001-76",
    "03.560.974/0001-18",
    "51.294.643/0001-26",
    "13.586.957/0001-03",
    "03.525.717/0001-45",
    "14.510.243/0001-84",
    "03.795.071/0001-16",
    "03.773.700/0003-79",
    "16.965.029/0001-48",
    "71.336.218/0001-60",
    "42.596.973/0001-85",
    "07.316.087/0001-50",
    "10.322.118/0002-70",
    "63.911.895/0001-36",
    "29.503.802/0007-91",
    "12.543.653/0001-04",
    "78.380.987/0001-04",
    "19.899.556/0001-90",
    "72.820.822/0027-69",
    "72.820.822/0001-20",
    "07.287.034/0001-58",
    "46.761.730/0001-06",
    "17.218.689/0001-28",
    "00.913.443/0001-73",
]

INVALID_VATS = ["411407182"]


@pytest.mark.parametrize("vat", VALID_VATS)
def test_brazil_valid(vat):
    result = check_vat(vat)
    assert result.is_valid, f"Expected {vat} to be valid for Brazil"
    assert result.country.name == "Brazil"


@pytest.mark.parametrize("vat", INVALID_VATS)
def test_brazil_invalid(vat):
    result = check_vat(vat)
    # Some invalid VATs might match the format but fail the check digit,
    # or fail the format entirely.
    # But result.is_valid should definitely be False.
    assert not result.is_valid, f"Expected {vat} to be invalid for Brazil"
