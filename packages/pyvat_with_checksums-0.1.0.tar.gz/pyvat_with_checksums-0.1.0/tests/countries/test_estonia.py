import pytest
from pyvat_with_checksums.core import check_vat

VALID_VATS = [
    "EE100007796",
    "EE100014404",
    "EE100037342",
    "EE100050879",
    "EE100050989",
    "EE100054752",
    "EE100067066",
    "EE100183238",
    "EE100196403",
    "EE100207415",
    "EE100210457",
    "EE100229859",
    "EE100235791",
    "EE100338245",
    "EE100396999",
    "EE100402498",
    "EE100434084",
    "EE100461536",
    "EE100619906",
    "EE100645682",
    "EE100660230",
    "EE100672736",
    "EE100691542",
    "EE100692266",
    "EE100069349",
    "EE100715473",
    "EE100721878",
    "EE100818723",
    "EE100900754",
    "EE100945641",
    "EE101007643",
    "EE101039763",
    "EE101193861",
    "EE101246514",
    "EE101246938",
    "EE101259750",
    "EE101261706",
    "EE101274434",
    "EE101282772",
    "EE101321015",
    "EE101331966",
    "EE101344209",
    "EE101367804",
    "EE101378466",
    "EE101482239",
    "EE101560290",
    "EE101589064",
]

INVALID_VATS = ["EE000207418", "EE110207418"]


@pytest.mark.parametrize("vat", VALID_VATS)
def test_estonia_valid(vat):
    result = check_vat(vat)
    assert result.is_valid, f"Expected {vat} to be valid for Estonia"
    assert result.country.name == "Estonia"


@pytest.mark.parametrize("vat", INVALID_VATS)
def test_estonia_invalid(vat):
    result = check_vat(vat)
    # Some invalid VATs might match the format but fail the check digit,
    # or fail the format entirely.
    # But result.is_valid should definitely be False.
    assert not result.is_valid, f"Expected {vat} to be invalid for Estonia"
