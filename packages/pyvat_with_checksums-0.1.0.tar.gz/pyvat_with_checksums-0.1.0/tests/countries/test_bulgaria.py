import pytest
from pyvat_with_checksums.core import check_vat

VALID_VATS = [
    "BG0000100153",
    "BG0000100159",
    "BG000670680",
    "BG0041010002",
    "BG0432270001",
    "BG040683212",
    "BG101004508",
    "BG103041626",
    "BG103704427",
    "BG103873594",
    "BG103873594",
    "BG104049218",
    "BG111004501",
    "BG123115379",
    "BG117546706",
    "BG121393209",
    "BG121745404",
    "BG121846702",
    "BG1234567893",
    "BG127595406",
    "BG130389149",
    "BG130500368",
    "BG130544891",
    "BG131071587",
    "BG131134023",
    "BG131142625",
    "BG131202360",
    "BG131272009",
    "BG131394206",
    "BG131406904",
    "BG131570565",
    "BG160084694",
    "BG160135231",
    "BG175074752",
    "BG175163651",
    "BG175281594",
    "BG175352176",
    "BG175379202",
    "BG200174309",
    "BG200313292",
    "BG200717477",
    "BG200893288",
    "BG200950556",
    "BG200964147",
    "BG201071853",
    "BG201219134",
    "BG201543613",
    "BG201809971",
    "BG202376409",
    "BG825312229",
    "BG831144533",
    "BG837107196",
    "BG9902280002",
]

INVALID_VATS = [
    "BG101004509",
    "BG101004507",
    "BG111004500",
    "BG111004502",
    "BG9902280001",
    "BG9902280004",
    "BG0433170001",
    "BG0433170002",
    "BG0433170003",
    "BG0433170004",
    "BG0433170005",
    "BG0433170006",
    "BG0433170007",
    "BG0433170009",
    "BG0413270001",
    "BG0413270002",
    "BG0413270003",
    "BG0413270004",
    "BG0413270005",
    "BG0413270008",
    "BG0413270009",
    "BG0413270000",
    "BG1234567894",
    "BG4234567890",
    "BG4234567892",
    "BG4234567893",
    "BG4234567894",
    "BG4234567895",
    "BG4234567897",
    "BG4234567898",
]


@pytest.mark.parametrize("vat", VALID_VATS)
def test_bulgaria_valid(vat):
    result = check_vat(vat)
    assert result.is_valid, f"Expected {vat} to be valid for Bulgaria"
    assert result.country.name == "Bulgaria"


@pytest.mark.parametrize("vat", INVALID_VATS)
def test_bulgaria_invalid(vat):
    result = check_vat(vat)
    # Some invalid VATs might match the format but fail the check digit,
    # or fail the format entirely.
    # But result.is_valid should definitely be False.
    assert not result.is_valid, f"Expected {vat} to be invalid for Bulgaria"
