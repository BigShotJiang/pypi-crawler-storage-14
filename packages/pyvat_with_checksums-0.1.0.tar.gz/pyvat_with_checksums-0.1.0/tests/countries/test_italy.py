import pytest
from pyvat_with_checksums.core import check_vat

VALID_VATS = [
    "IT00000010215",
    "IT00079760328",
    "IT00140390501",
    "IT00144659992",
    "IT00224320234",
    "IT00383590486",
    "IT00453840357",
    "IT00488410010",
    "IT00502591209",
    "IT00697300150",
    "IT00754150100",
    "IT00820340966",
    "IT00902170018",
    "IT01021630668",
    "IT01044120358",
    "IT01114601006",
    "IT01219560800",
    "IT01390230462",
    "IT01654960473",
    "IT02118311006",
    "IT02121151001",
    "IT02458160245",
    "IT07234250962",
    "IT03084300171",
    "IT05067600154",
    "IT06363391001",
    "IT06515871009",
    "IT06631330963",
    "IT06895721006",
    "IT07129470014",
    "IT08146570018",
    "IT08792831003",
    "IT10000100015",
    "IT10000200013",
    "IT10000300011",
    "IT10000500016",
    "IT10000600014",
    "IT10000700012",
    "IT10000900018",
    "IT10001000016",
    "IT10001100014",
    "IT10001300010",
    "IT10001400018",
    "IT10001500015",
    "IT10001700011",
    "IT10001708881",
    "IT10001701209",
    "IT10001701217",
    "IT10001709996",
    "IT10001800019",
    "IT10001900017",
    "IT11005760159",
    "IT12066470159",
    "IT12286350157",
    "IT12683790153",
    "IT13378520152",
    "IT05142860484",
    "IT01709820995",
]

INVALID_VATS = [
    "IT00000010210",
    "IT10000100010",
    "IT10000200010",
    "IT0000300010",
    "IT10001900010",
    "IT10000500010",
    "IT10000600010",
    "IT10001708882",
    "IT10001701202",
    "IT10001701216",
    "IT10001709997",
]


@pytest.mark.parametrize("vat", VALID_VATS)
def test_italy_valid(vat):
    result = check_vat(vat)
    assert result.is_valid, f"Expected {vat} to be valid for Italy"
    assert result.country.name == "Italy"


@pytest.mark.parametrize("vat", INVALID_VATS)
def test_italy_invalid(vat):
    result = check_vat(vat)
    # Some invalid VATs might match the format but fail the check digit,
    # or fail the format entirely.
    # But result.is_valid should definitely be False.
    assert not result.is_valid, f"Expected {vat} to be invalid for Italy"
