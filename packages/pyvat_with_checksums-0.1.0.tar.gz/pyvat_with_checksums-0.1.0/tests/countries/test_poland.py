import pytest
from pyvat_with_checksums.core import check_vat

VALID_VATS = [
    "PL1132191233",
    "PL1181092318",
    "PL5210088067",
    "PL5221008534",
    "PL5222349705",
    "PL5222762925",
    "PL5222897588",
    "PL5240303547",
    "PL5242718991",
    "PL5252248481",
    "PL5260006841",
    "PL5260033950",
    "PL5260204995",
    "PL5260250274",
    "PL5260300724",
    "PL5262493733",
    "PL5262816171",
    "PL5262823001",
    "PL5262823001",
    "PL5270023255",
    "PL5270009261",
    "PL5270204212",
    "PL5272525794",
    "PL5272527149",
    "PL5272548269",
    "PL5841896486",
    "PL5851408413",
    "PL5860017014",
    "PL6570006959",
    "PL6571225764",
    "PL6751330882",
    "PL6762017752",
    "PL6912393587",
    "PL6922253959",
    "PL7010009325",
    "PL7122913627",
    "PL7712761851",
    "PL7780001070",
    "PL7792048522",
    "PL8392919362",
    "PL9371000329",
    "PL9512293636",
    "PL9562180153",
    "PL9691068493",
]

INVALID_VATS = ["PL7122913628", "PL7122913427"]


@pytest.mark.parametrize("vat", VALID_VATS)
def test_poland_valid(vat):
    result = check_vat(vat)
    assert result.is_valid, f"Expected {vat} to be valid for Poland"
    assert result.country.name == "Poland"


@pytest.mark.parametrize("vat", INVALID_VATS)
def test_poland_invalid(vat):
    result = check_vat(vat)
    # Some invalid VATs might match the format but fail the check digit,
    # or fail the format entirely.
    # But result.is_valid should definitely be False.
    assert not result.is_valid, f"Expected {vat} to be invalid for Poland"
