import pytest
from pyvat_with_checksums.core import check_vat

VALID_VATS = [
    "LT100000009017",
    "LT100000031710",
    "LT100001410314",
    "LT100001647810",
    "LT100002247911",
    "LT100002640213",
    "LT100002992518",
    "LT100003099412",
    "LT100003222911",
    "LT100003776115",
    "LT100003806615",
    "LT100004463513",
    "LT100005808219",
    "LT100005772517",
    "LT100005847815",
    "LT100006555419",
    "LT100006615910",
    "LT100006688411",
    "LT100006852615",
    "LT100007390914",
    "LT100008061513",
    "LT100119219",
    "LT104019515",
    "LT108940716",
    "LT115521113",
    "LT105672113",
    "LT115184219",
    "LT119515314",
    "LT119513417",
    "LT119505811",
    "LT119502413",
    "LT119508113",
    "LT119517219",
    "LT120212314",
    "LT120296515",
    "LT205052113",
    "LT205458414",
    "LT208640716",
    "LT210811811",
    "LT213179412",
    "LT238708219",
    "LT239056314",
    "LT243857314",
    "LT245702113",
    "LT246655314",
    "LT254096515",
    "LT258223515",
    "LT290061371314",
    "LT321389515",
    "LT330214917",
    "LT331842113",
    "LT351634917",
    "LT408382716",
    "LT458248716",
    "LT530091413",
    "LT852320917",
    "LT907560811",
]

INVALID_VATS = ["LT123456789", "LT1234567890", "LT530091413111", "LT0123"]


@pytest.mark.parametrize("vat", VALID_VATS)
def test_lithuania_valid(vat):
    result = check_vat(vat)
    assert result.is_valid, f"Expected {vat} to be valid for Lithuania"
    assert result.country.name == "Lithuania"


@pytest.mark.parametrize("vat", INVALID_VATS)
def test_lithuania_invalid(vat):
    result = check_vat(vat)
    # Some invalid VATs might match the format but fail the check digit,
    # or fail the format entirely.
    # But result.is_valid should definitely be False.
    assert not result.is_valid, f"Expected {vat} to be invalid for Lithuania"
