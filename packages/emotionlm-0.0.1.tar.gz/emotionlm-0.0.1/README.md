# EmotionLM
A library for integrating episodic memory within AI applications.

