import logging
from datetime import datetime, timezone
from collections import namedtuple

FakeLevel = namedtuple("FakeLevel", ["name", "no"])


class FakeFile:
    def __init__(self, path: str):
        self.path = path


class FakeMessage:
    def __init__(self, record: dict):
        self.record = record


def make_message(**overrides) -> FakeMessage:
    record = {
        "level": FakeLevel("ERROR", 40),
        "message": "boom",
        "time": datetime(2025, 11, 6, 18, 15, 26, 129000, tzinfo=timezone.utc),
        "function": "do_stuff",
        "line": 42,
        "file": FakeFile("/app/main.py"),
        "exception": None,
    }
    record.update(overrides)
    return FakeMessage(record)


def make_fake_logrecord(**overrides) -> logging.LogRecord:
    defaults = {
        "name": "test.logger",
        "level": logging.ERROR,
        "pathname": "/app/main.py",
        "lineno": 42,
        "msg": "boom",
        "args": (),
        "exc_info": None,
        "func": "do_stuff",
        "sinfo": None,
    }

    defaults.update(overrides)

    defaults.update(overrides)

    exc_info = defaults.get("exc_info")
    exception = defaults.get("exception")

    if exc_info is None and exception is not None:
        if isinstance(exception, BaseException):
            exc_info = (type(exception), exception, exception.__traceback__)

        elif (
            hasattr(exception, "type")
            and hasattr(exception, "value")
            and hasattr(exception, "traceback")
        ):
            exc_info = (exception.type, exception.value, exception.traceback)

        defaults["exc_info"] = exc_info

    record = logging.LogRecord(
        name=defaults["name"],
        level=defaults["level"],
        pathname=defaults["pathname"],
        lineno=defaults["lineno"],
        msg=defaults["msg"],
        args=defaults["args"],
        exc_info=defaults["exc_info"],
        func=defaults["func"],
        sinfo=defaults["sinfo"],
    )

    for k, v in overrides.items():
        if not hasattr(record, k):
            setattr(record, k, v)

    if "created" in overrides:
        record.created = overrides["created"]
        record.msecs = (record.created - int(record.created)) * 1000

    return record
