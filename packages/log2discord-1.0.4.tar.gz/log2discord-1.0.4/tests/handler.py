import logging
import sys
from datetime import datetime

import pytest

from log2discord.constants import (
    DEFAULT_EMBED_COLORS,
    DEFAULT_EMBED_TITLES,
)
from log2discord import DiscordLoggingHandler

from .conftest import make_fake_logrecord


def test_get_embed_title_uses_custom_and_falls_back_to_defaults():
    sink = DiscordLoggingHandler(
        webhook_url="https://hook",
        project_name="my-service",
        embed_titles={logging.ERROR: "{project_name} ERROR!"},
    )

    title_error = sink.discord_requests_manager._get_embed_title(logging.ERROR)
    assert title_error == "my-service ERROR!"

    title_info = sink.discord_requests_manager._get_embed_title(logging.INFO)
    assert title_info == DEFAULT_EMBED_TITLES[logging.INFO].format(
        project_name="my-service"
    )


def test_get_embed_color_uses_custom_and_falls_back_to_defaults():
    sink = DiscordLoggingHandler(
        webhook_url="https://hook",
        project_name="my-service",
        embed_colors={"ERROR": "16711680"},
    )

    assert sink.discord_requests_manager._get_embed_color(logging.ERROR) == "16711680"
    assert (
        sink.discord_requests_manager._get_embed_color(logging.INFO)
        == DEFAULT_EMBED_COLORS[logging.INFO]
    )


def test_get_embed_fields_uses_custom_field_names():
    sink = DiscordLoggingHandler(
        webhook_url="https://hook",
        project_name="my-service",
        discord_field_names={
            "level": "Severity",
            "function": "Func",
            "line": "Ln",
            "file": "Path",
        },
    )

    fields = sink.discord_requests_manager._get_embed_fields(
        "WARNING", "load_stuff", 99, "/srv/app/loader.py"
    )

    assert fields[0] == {"name": "Severity", "value": "WARNING", "inline": True}
    assert fields[1]["name"] == "Func"
    assert fields[1]["value"] == "load_stuff"
    assert fields[2]["name"] == "Ln"
    assert fields[2]["value"] == 99
    assert fields[3]["name"] == "Path"
    assert fields[3]["value"] == "/srv/app/loader.py"


def test_format_message_without_exception():
    sink = DiscordLoggingHandler("https://hook", "svc")
    msg = make_fake_logrecord(msg="hello world")
    sink.discord_requests_manager._build_request_payload(
        20, "hello world", "function", 20, "/srv/app/loader.py", datetime.now()
    )
    out = sink._format_record(msg)
    assert out == "hello world"


def test_format_message_truncates_when_too_long():
    sink = DiscordLoggingHandler("https://hook", "svc")
    sink.discord_max_chars = 10

    msg = make_fake_logrecord(msg="0123456789ABCDEFGHIJ0123456789ABCDEFGHIJ")
    out = sink._format_record(msg)
    # formato: "…" + últimos N chars
    assert out.startswith("…")
    # longitud total == discord_max_chars
    assert len(out) == 10


def test_format_message_with_exception_uses_traceback():
    sink = DiscordLoggingHandler("https://hook", "svc")

    try:
        1 / 0
    except ZeroDivisionError as e:
        tb = sys.exc_info()[2]
        fake_exc = type(
            "FakeException",
            (),
            {"traceback": tb, "type": type(e), "value": e},
        )

    msg = make_fake_logrecord(exception=fake_exc)
    out = sink._format_record(msg)
    print(out)
    assert "ZeroDivisionError" in out
    assert "1 / 0" in out


@pytest.mark.freeze_time("2025-11-06T18:15:26.129+00:00")
def test_build_discord_payload_basic():
    sink = DiscordLoggingHandler("https://hook", "my-service")
    msg = make_fake_logrecord(
        level=logging.ERROR,
        msg="boom!",
        func="function",
        lineno=5,
        pathname="/srv/file.py",
    )

    payload = sink.discord_requests_manager._build_request_payload(
        logging.ERROR, "boom!", "function", 5, "file.py", datetime.now()
    )
    assert "embeds" in payload
    assert len(payload["embeds"]) == 1

    embed = payload["embeds"][0]
    assert embed["description"] == "boom!"
    assert embed["title"] == sink.discord_requests_manager._get_embed_title(
        logging.ERROR
    )
    assert embed["color"] == sink.discord_requests_manager._get_embed_color(
        logging.ERROR
    )
    assert embed["timestamp"] == "2025-11-06T18:15:26.129Z"
    assert embed["fields"] == sink.discord_requests_manager._get_embed_fields(
        msg.levelno, msg.funcName, msg.lineno, msg.filename
    )


def test_ping_users():
    sink = DiscordLoggingHandler(
        "https://hook", "my-service", mentioned_users=["999", "666"]
    )

    payload = sink.discord_requests_manager._build_request_payload(
        logging.ERROR, "boom!", "function", 5, "file.py", datetime.now()
    )

    assert "content" in payload
    assert "allowed_mentions" in payload
    assert "users" in payload["allowed_mentions"]
    assert (
        "999" in payload["allowed_mentions"]["users"]
        and "666" in payload["allowed_mentions"]["users"]
    )
    assert "<@999>" in payload["content"] and "<@666>" in payload["content"]


def test_ping_roles():
    sink = DiscordLoggingHandler(
        "https://hook", "my-service", mentioned_roles=["999", "666"]
    )

    payload = sink.discord_requests_manager._build_request_payload(
        logging.ERROR, "boom!", "function", 5, "file.py", datetime.now()
    )

    assert "content" in payload
    assert "allowed_mentions" in payload
    assert "roles" in payload["allowed_mentions"]
    assert (
        "999" in payload["allowed_mentions"]["roles"]
        and "666" in payload["allowed_mentions"]["roles"]
    )
    assert "<@&999>" in payload["content"] and "<@&666>" in payload["content"]


def test_ping_users_and_roles():
    sink = DiscordLoggingHandler(
        "https://hook",
        "my-service",
        mentioned_users=["111", "777"],
        mentioned_roles=["999", "666"],
    )

    payload = sink.discord_requests_manager._build_request_payload(
        logging.ERROR, "boom!", "function", 5, "file.py", datetime.now()
    )

    assert "content" in payload
    assert "allowed_mentions" in payload
    assert "roles" in payload["allowed_mentions"]
    assert "users" not in payload["allowed_mentions"]
    assert "parse" in payload["allowed_mentions"]
    assert "users" in payload["allowed_mentions"]["parse"]
    assert (
        "999" in payload["allowed_mentions"]["roles"]
        and "666" in payload["allowed_mentions"]["roles"]
    )
    assert "<@&999>" in payload["content"] and "<@&666>" in payload["content"]
    assert "<@111>" in payload["content"] and "<@777>" in payload["content"]
