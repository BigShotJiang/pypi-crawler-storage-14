from typing import TypedDict, Dict, Literal

allowed_mentions_parse = Literal["everyone", "users", "roles"]


class BaseEmbedColors(TypedDict, total=False):
    """Strings must be colors in decimal notation, for Discord to use them"""

    TRACE: str
    DEBUG: str
    INFO: str
    SUCCESS: str
    WARNING: str
    ERROR: str
    CRITICAL: str


class BaseEmbedTitles(TypedDict, total=False):
    """You can use {project_name} interpolation to insert the project name in the string"""

    TRACE: str
    DEBUG: str
    INFO: str
    SUCCESS: str
    WARNING: str
    ERROR: str
    CRITICAL: str


class DiscordFieldNames(TypedDict, total=True):
    level: str
    function: str
    line: str
    file: str


class DiscordPayloadEmbedField(TypedDict):
    name: str
    value: str
    inline: bool


class DiscordPayloadEmbed(TypedDict):
    title: str
    color: str | int
    description: str
    fields: list[DiscordPayloadEmbedField]
    timestamp: str


class DiscordAllowedMentions(TypedDict, total=False):
    parse: list[allowed_mentions_parse]
    users: list[str]
    roles: list[str]


class DiscordPayload(TypedDict):
    content: str
    embeds: list[DiscordPayloadEmbed]
    allowed_mentions: DiscordAllowedMentions


EmbedColors = BaseEmbedColors | Dict[str, str]
EmbedTitles = BaseEmbedTitles | Dict[str, str]
