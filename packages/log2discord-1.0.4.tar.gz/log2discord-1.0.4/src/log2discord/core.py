import logging
from datetime import datetime, timezone
import traceback

import requests

from .constants import (
    DEFAULT_EMBED_COLORS,
    DEFAULT_EMBED_TITLES,
    DEFAULT_DISCORD_FIELD_NAMES,
    TRACEBACK_MAX_FRAMES,
    DISCORD_MAX_CHARS,
)
from .schemas import (
    DiscordPayloadEmbedField,
    DiscordPayload,
    EmbedColors,
    EmbedTitles,
    DiscordFieldNames,
    DiscordAllowedMentions,
)


class DiscordRequestsManager:
    def __init__(
        self,
        webhook_url: str,
        project_name: str,
        embed_colors: EmbedColors = None,
        embed_titles: EmbedTitles = None,
        discord_field_names: DiscordFieldNames = None,
        mentioned_users: list[str] = None,
        mentioned_roles: list[str] = None,
    ):
        if embed_colors is None:
            embed_colors = DEFAULT_EMBED_COLORS
        if embed_titles is None:
            embed_titles = DEFAULT_EMBED_TITLES
        if mentioned_users is None:
            mentioned_users = []
        if mentioned_roles is None:
            mentioned_roles = []

        if discord_field_names is None:
            discord_field_names = DEFAULT_DISCORD_FIELD_NAMES

        self.webhook_url = webhook_url
        self.traceback_max_frames = TRACEBACK_MAX_FRAMES
        self.discord_max_chars = DISCORD_MAX_CHARS
        self.project_name = project_name
        self.embed_colors = embed_colors
        self.embed_titles = embed_titles
        self.mentioned_users = mentioned_users
        self.mentioned_roles = mentioned_roles
        self.discord_field_names = discord_field_names

    def _build_request_payload(
        self,
        level: str,
        description: str,
        function: str,
        line: str | int,
        file: str,
        dt: datetime,
    ) -> DiscordPayload:
        return {
            "content": self._build_content(),
            "embeds": [
                {
                    "title": self._get_embed_title(level),
                    "color": self._get_embed_color(level),
                    "description": description,
                    "fields": self._get_embed_fields(level, function, line, file),
                    "timestamp": self._format_timestamp(dt),
                }
            ],
            "allowed_mentions": self._build_allowed_mentions(),
        }

    def _get_embed_title(self, level) -> str:
        string = self.embed_titles.get(
            level, DEFAULT_EMBED_TITLES.get(level, DEFAULT_EMBED_TITLES[logging.INFO])
        )
        return string.format(project_name=self.project_name)

    def _get_embed_color(self, level) -> str:
        return self.embed_colors.get(
            level, DEFAULT_EMBED_COLORS.get(level, DEFAULT_EMBED_COLORS[logging.INFO])
        )

    @staticmethod
    def _format_timestamp(dt: datetime) -> str:
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
            dt_utc = dt.astimezone(timezone.utc)
            return dt_utc.strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "Z"

    def _get_embed_fields(
        self, level, function, line, file
    ) -> list[DiscordPayloadEmbedField]:
        print(self.discord_field_names)
        return [
            {
                "name": self.discord_field_names.get(
                    "level", DEFAULT_DISCORD_FIELD_NAMES["level"]
                ),
                "value": level,
                "inline": True,
            },
            {
                "name": self.discord_field_names.get(
                    "function", DEFAULT_DISCORD_FIELD_NAMES["function"]
                ),
                "value": function,
                "inline": True,
            },
            {
                "name": self.discord_field_names.get(
                    "line", DEFAULT_DISCORD_FIELD_NAMES["line"]
                ),
                "value": line,
                "inline": True,
            },
            {
                "name": self.discord_field_names.get(
                    "file", DEFAULT_DISCORD_FIELD_NAMES["file"]
                ),
                "value": file,
            },
        ]

    def send_to_discord(
        self,
        level: str,
        description: str,
        function: str,
        line: str | int,
        file: str,
        dt: datetime,
    ):
        try:
            requests.post(
                self.webhook_url,
                json=self._build_request_payload(
                    level, description, function, line, file, dt
                ),
            )
        except Exception:
            print("Error sending to Discord", traceback.format_exc())

    def _build_content(self) -> str:
        out = ""

        for user in self.mentioned_users:
            out += f"<@{user}> "
        for role in self.mentioned_roles:
            out += f"<@&{role}>"

        return out

    def _build_allowed_mentions(self) -> DiscordAllowedMentions:
        if len(self.mentioned_roles) > 0 and len(self.mentioned_users) > 0:
            return {"parse": ["users"], "roles": self.mentioned_roles}

        if len(self.mentioned_users) > 0:
            return {"users": self.mentioned_users}

        if len(self.mentioned_roles) > 0:
            return {"roles": self.mentioned_roles}
