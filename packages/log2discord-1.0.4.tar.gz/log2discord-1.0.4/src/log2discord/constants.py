import logging

from .schemas import EmbedColors, EmbedTitles, DiscordFieldNames

TRACEBACK_MAX_FRAMES: int = 5
DISCORD_MAX_CHARS: int = 2000


DEFAULT_EMBED_COLORS: EmbedColors = {
    # TRACE, loguru only
    5: "13421772",  # cccccc
    logging.DEBUG: "13421772",  # cccccc
    logging.INFO: "39423",  # 0099ff
    # SUCCESS, loguru only
    25: "65433",  # 00ff99
    logging.WARNING: "16737792",  # ff6600
    logging.ERROR: "16711680",  # ff0000
    logging.CRITICAL: "16711680",  # ff0000
}

DEFAULT_EMBED_TITLES: EmbedTitles = {
    # TRACE, loguru only
    5: "Trace: {project_name}",
    logging.DEBUG: "Debug: {project_name}",
    logging.INFO: "Info: {project_name}",
    # SUCCESS, loguru only
    25: "Success: {project_name}",
    logging.WARNING: "Warning: {project_name}",
    logging.ERROR: "Error: {project_name}",
    logging.CRITICAL: "Critical error: {project_name}",
}

DEFAULT_DISCORD_FIELD_NAMES: DiscordFieldNames = {
    "level": "Level",
    "function": "Function",
    "line": "Line",
    "file": "File",
}
