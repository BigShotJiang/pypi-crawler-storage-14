import re
import traceback
from datetime import datetime
from logging import Handler, LogRecord
from types import TracebackType

from .constants import TRACEBACK_MAX_FRAMES, DISCORD_MAX_CHARS
from .core import DiscordRequestsManager
from .schemas import EmbedColors, EmbedTitles, DiscordFieldNames

MD_ESCAPE_RE = re.compile(r"([_*`])")


class DiscordLoggingHandler(Handler):
    def __init__(
        self,
        webhook_url: str,
        project_name: str,
        embed_colors: EmbedColors = None,
        embed_titles: EmbedTitles = None,
        mentioned_users: list[str] = None,
        mentioned_roles: list[str] = None,
        discord_field_names: DiscordFieldNames = None,
    ):
        super().__init__()
        self.traceback_max_frames = TRACEBACK_MAX_FRAMES
        self.discord_max_chars = DISCORD_MAX_CHARS
        self.discord_requests_manager = DiscordRequestsManager(
            webhook_url,
            project_name,
            embed_colors,
            embed_titles,
            discord_field_names,
            mentioned_users,
            mentioned_roles,
        )

    @staticmethod
    def _escape_md(s: str) -> str:
        return MD_ESCAPE_RE.sub(r"\\\1", s)

    def _format_traceback(self, tb, exception) -> str:
        """
        From an exception,
        Returns a string (formatted in Markdown) with the last frames of the traceback
        """
        frames = traceback.extract_tb(tb)
        frames = frames[-self.traceback_max_frames :]

        lines = []
        for f in frames:
            lines.append(f"- `{f.filename}:{f.lineno}` · `{f.name}()`")
            if f.line:
                lines.append(f"    → `{self._escape_md(f.line.strip())}`")
        lines.append(
            f"\n**{type(exception).__name__}**: {self._escape_md(str(exception))}"
        )
        return "\n".join(lines)

    def _process_exception(
        self, exc_instance: Exception, tb: TracebackType | None
    ) -> str:
        if tb:
            return self._format_traceback(tb, exc_instance)
        return str(exc_instance)

    def _format_record(self, record: LogRecord):
        msg = self.format(record)
        out = ""

        if record.exc_info:
            exc_type, exc_instance, tb = record.exc_info
            msg = self._process_exception(exc_instance, tb)

        if len(msg) > self.discord_max_chars:
            remaining = self.discord_max_chars - len(out) - 1
            out = "…" + msg[-remaining:]
        else:
            out = msg

        return out

    def emit(self, record: LogRecord) -> None:
        try:
            msg = self.format(record)

            if record.exc_info:
                exc_type, exc_instance, tb = record.exc_info
                msg = self._process_exception(exc_instance, tb)

            level = record.levelname
            self.discord_requests_manager.send_to_discord(
                level,
                msg,
                record.funcName,
                record.lineno,
                record.pathname,
                datetime.now(),
            )
        except Exception:
            self.handleError(record)
