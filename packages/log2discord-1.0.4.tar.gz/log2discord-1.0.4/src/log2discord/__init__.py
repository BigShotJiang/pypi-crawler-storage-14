from .std_logging import DiscordLoggingHandler

__all__ = ["DiscordLoggingHandler"]

__version__ = "1.0.4"
