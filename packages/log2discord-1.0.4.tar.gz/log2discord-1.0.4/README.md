# log2discord

[![PyPI](https://img.shields.io/pypi/v/loguru-discord-sink.svg)](https://pypi.org/project/loguru-discord-sink/)
![Python Versions](https://img.shields.io/pypi/pyversions/loguru-discord-sink.svg)
![License](https://img.shields.io/pypi/l/loguru-discord-sink.svg)
[![Ruff](https://img.shields.io/badge/lint-ruff-6E9F18.svg)](https://astral.sh/ruff)

A logging handler that outputs log messages to a Discord webhook.

## Installation
```shell
pip install log2discord
```

## Quick setup
### Loguru
```python
from loguru import logger
from log2discord import DiscordLoggingHandler

discord_webhook = "https://discord.com/api/webhooks/XXXX/XXXXX"
project_name = "my-service"

discord_sink = DiscordLoggingHandler(discord_webhook, project_name)
logger.add(discord_sink, level="ERROR")

logger.info("This will not be sent.")
logger.error("Something failed!")  # -> sent to Discord
```

> [!WARNING]
>
> This sink has **no default filtering**.
> If you don't specify a level or set up a filter when calling `logger.add()`, **Loguru will send all log messages to Discord.**
> This includes `DEBUG`, `INFO`, etc, which *will* saturate your webhook.


## Sink parameters

```python
DiscordLoggingHandler(
    webhook_url: str,
    project_name: str,
    embed_colors: EmbedColors | None = None,
    embed_titles: EmbedTitles | None = None,
    mentioned_users: list[str] | None = None,
    mentioned_roles: list[str] | None = None,
    discord_field_names: DiscordFieldNames | None = None
)
```

- `webhook_url: str`

Discord webhook URL where messages will  be forwarded to.
- `project_name: str`
Project name that will be used in the Discord default notification header.

- `embed_colors: EmbedColors | None`
Dictionary mapping to add custom colors to each Loguru log level.

```python
colors = {
    "ERROR": "16711680",    # red
    "SUCCESS": "65280",     # green
}
```
> [!NOTE]
>
> Colors must be in [decimal notation](https://www.spycolor.com/), as required by the Discord API.

- `embed_titles: EmbedTitles | None`

Custom embed titles for each log level. `project_name` can be interpolated into these strings.

```python
titles = {
    "ERROR": "❌ {project_name} encountered an error",
    "SUCCESS": "✅ {project_name} finished successfully",
}
```

- `mentioned_users: list[str]`
List of [User IDs](https://support.discord.com/hc/en-us/articles/206346498-Where-can-I-find-my-User-Server-Message-ID#h_01HRSTXPS5H5D7JBY2QKKPVKNA) that will be mentioned in each message.

- `mentioned_roles: list[str]`
List of Role IDs that will be mentioned in each message.

- `discord_field_names: DiscordFieldNames | None`

Titles for the fields shown inside the Discord embed

```python
field_names = {
    "level": "Severity",
    "function": "Func",
    "line": "Ln",
    "file": "Path",
}

```
