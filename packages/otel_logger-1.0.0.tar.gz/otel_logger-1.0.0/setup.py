
from setuptools import setup, find_packages

setup(
    name="otel-logger",
    version="1.0.0",
    description="Structured JSON logging for OpenTelemetry and New Relic",
    author="Your Name",
    packages=find_packages(),
    python_requires=">=3.7",
)
