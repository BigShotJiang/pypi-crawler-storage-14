# python-uniform-logging - Custom Logging Package

A Python logging package for structured logs and audit logging to DB.

## Features
- Structured JSON-like logs
- Audit logs stored in DB (SQLite for dev, MS SQL for staging/prod)
- Environment-based configuration
- Docker support

## Installation
```bash
pip install -r requirements.txt
```

## Usage

```
from custom_logging.config import setup_logging
from custom_logging.logger import get_logger

setup_logging()
logger = get_logger("my_app")

logger.info("Normal log")
logger.info("Audit log entry", extra={"type": "audit"})
```