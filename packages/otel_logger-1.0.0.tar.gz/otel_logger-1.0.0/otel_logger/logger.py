
import logging
from .formatter import JsonLogFormatter

def get_otel_logger(log_file, service_name, level=logging.INFO):
    """
    Create a logger with:
    - log_file: path from app
    - service_name: param from app
    - level: param from app
    """
    otel_logger = logging.getLogger("otel_logger")
    otel_logger.setLevel(level)

    if not otel_logger.hasHandlers():
        handler = logging.FileHandler(log_file)
        formatter = JsonLogFormatter()
        handler.setFormatter(formatter)
        otel_logger.addHandler(handler)
        otel_logger.propagate = False

    # Inject service_name into log records dynamically
    def add_service_name(record):
        record.service_name = service_name
        return True

    otel_logger.addFilter(add_service_name)
    return otel_logger
