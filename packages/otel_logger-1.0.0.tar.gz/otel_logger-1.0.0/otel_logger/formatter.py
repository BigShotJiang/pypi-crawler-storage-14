
import logging
import json
from datetime import datetime, timezone

class JsonLogFormatter(logging.Formatter):
    def __init__(self, team="sse", sink="newrelic", vsn="v1.0.0"):
        super().__init__()
        self.team = team
        self.sink = sink
        self.vsn = vsn

    def format(self, record):
        log_record = {
            "timestamp": datetime.now(timezone.utc).isoformat(),  # via logging package
            "level": record.levelname,                            # param from app
            "message": record.getMessage(),                      # param from app
            "service.name": getattr(record, "service_name", "unknown"),  # param from app
            "team": self.team,                                   # via logging package
            "sink": self.sink,                                   # via logging package
            "vsn": self.vsn,                                     # via logging package
        }
        if record.exc_info:
            log_record["error"] = self.formatException(record.exc_info)
        if hasattr(record, "extra_fields"):
            log_record.update(getattr(record, "extra_fields", {}))
        return json.dumps(log_record)
