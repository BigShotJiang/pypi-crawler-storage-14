v5_sql = 'ALTER TABLE properties ADD COLUMN property_group_id INTEGER;'
