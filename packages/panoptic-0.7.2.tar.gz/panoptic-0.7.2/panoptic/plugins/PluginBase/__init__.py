from .plugin_base import PluginBase

plugin_class = PluginBase
