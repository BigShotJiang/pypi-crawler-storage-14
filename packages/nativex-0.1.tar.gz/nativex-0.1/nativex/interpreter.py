import os
import importlib.util
import tkinter as tk
from tkinter import scrolledtext

variables = {}
loaded_apis = {}
syntax_handlers = {}
EXT_DIR = "extensions"
SYN_DIR = os.path.join(os.path.dirname(__file__), "syntaxes")

# ------------------ Load Syntax Modules ------------------
def load_syntax_modules():
    global syntax_handlers
    syntax_handlers = {}
    if not os.path.isdir(SYN_DIR):
        os.makedirs(SYN_DIR)

    for file in os.listdir(SYN_DIR):
        if not file.endswith(".py"):
            continue
        path = os.path.join(SYN_DIR, file)
        name = file[:-3]
        spec = importlib.util.spec_from_file_location(name, path)
        module = importlib.util.module_from_spec(spec)
        try:
            spec.loader.exec_module(module)
            if hasattr(module, "handle"):
                syntax_handlers[name] = module
        except Exception as e:
            print(f"[Syntax Error] {file}: {e}")

load_syntax_modules()

# ------------------ Evaluate Expression ------------------
def eval_expr(expr):
    try:
        expr = expr.replace('&&', ' and ').replace('||', ' or ')
        return eval(expr, {}, variables)
    except:
        return expr

# ------------------ Extensions ------------------
def load_extension_py(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module

def load_extension(name):
    global loaded_apis
    local_path = os.path.join(os.path.dirname(__file__), "extensions", f"{name}.py")
    if not os.path.isfile(local_path):
        return False
    module = load_extension_py(local_path, name)
    loaded_apis[name] = module
    return True

def run_api(ext_name, func, *args):
    if ext_name not in loaded_apis:
        return "Extension not loaded"
    module = loaded_apis[ext_name]
    if not hasattr(module, func):
        return "No such function"
    return getattr(module, func)(*args)

# ------------------ Run Code ------------------
def run_code(code, output_widget=None):
    global variables
    variables = {}
    if output_widget is None:
        root = tk.Tk()
        root.withdraw()
        output_widget = scrolledtext.ScrolledText(root)
    g = {"root": tk._default_root, "app_window": None}

    for line in code.splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue

        if line.startswith("import "):
            load_extension(line.split()[1])
            continue

        if " = api " in line:
            var, expr = line.split(" = api ", 1)
            var = var.strip()
            parts = expr.split()
            ext = parts[0]
            func = parts[1]
            args = []
            for a in parts[2:]:
                try:
                    args.append(int(a))
                except:
                    try:
                        args.append(float(a))
                    except:
                        args.append(a)
            variables[var] = run_api(ext, func, *args)
            continue

        if "=" in line:
            var, expr = line.split("=", 1)
            variables[var.strip()] = eval_expr(expr.strip())
            continue

        handled = False
        for mod in syntax_handlers.values():
            if mod.handle(line, variables, output_widget, g):
                handled = True
                break
        if not handled:
            output_widget.insert("end", f"Unknown command: {line}\n")

    return variables

def run_file(path, output_widget=None):
    with open(path, "r", encoding="utf-8") as f:
        run_code(f.read(), output_widget)
