from setuptools import setup, find_packages

setup(
    name="NativeX",
    version="0.1",
    packages=find_packages(),
    include_package_data=True,
    install_requires=[],
    python_requires='>=3.8',
    author="Dark",
    description="NativeX - modular scripting language for Python",
    url="",
)
