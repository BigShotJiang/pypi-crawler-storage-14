# test/test_shittify.py

import unittest
import os
from src.transformer import shittify_code, obfuscate_code_with_ast

class TestShittify(unittest.TestCase):
    
    def test_shittify_code_alias(self):
        """Test that shittify_code is an alias for obfuscate_code_with_ast"""
        self.assertEqual(shittify_code, obfuscate_code_with_ast)
    
    def test_basic_function(self):
        """Test that basic function code works after shittification"""
        original_code = """
def example_function(x, y):
    return x + y

a = 5
b = 10
z = example_function(a, b)
print(z)
"""
        shittified_code = shittify_code(original_code)
        self.assertNotEqual(original_code, shittified_code)
        # The shittified code should be executable
        try:
            exec(shittified_code)
        except Exception as e:
            self.fail(f"Shittified code failed to execute: {e}")
    
    def test_with_imports(self):
        """Test that code with imports works after shittification"""
        original_code = """
import math
def calculate_area(radius):
    return math.pi * radius ** 2

result = calculate_area(5)
print(result)
"""
        # Try multiple times due to randomness in obfuscation
        for attempt in range(5):
            try:
                shittified_code = shittify_code(original_code)
                self.assertNotEqual(original_code, shittified_code)
                self.assertIn("import math", shittified_code)
                # The shittified code should be executable
                # Use a clean namespace to avoid any contamination
                namespace = {}
                exec(shittified_code, namespace)
                return  # Success
            except Exception as e:
                if attempt == 4:  # Last attempt
                    # Print first 20 lines for debugging
                    lines = shittified_code.split('\n')[:20]
                    error_msg = f"Shittified code with imports failed to execute after 5 attempts: {e}\n"
                    error_msg += "First 20 lines of generated code:\n"
                    for i, line in enumerate(lines, 1):
                        error_msg += f"{i:2}: {line}\n"
                    self.fail(error_msg)
                continue  # Try again
    
    def test_with_classes(self):
        """Test that code with classes works after shittification"""
        original_code = """
class Calculator:
    def __init__(self):
        self.value = 0
    
    def add(self, x):
        self.value += x
        return self.value

calc = Calculator()
result = calc.add(5)
print(result)
"""
        shittified_code = shittify_code(original_code)
        self.assertNotEqual(original_code, shittified_code)
        # The shittified code should be executable
        try:
            exec(shittified_code)
        except Exception as e:
            self.fail(f"Shittified code with classes failed to execute: {e}")
    
    def test_with_conditionals(self):
        """Test that code with conditionals works after shittification"""
        original_code = """
x = 10
if x > 5:
    print("Greater than 5")
else:
    print("Less than or equal to 5")
"""
        shittified_code = shittify_code(original_code)
        self.assertNotEqual(original_code, shittified_code)
        # The shittified code should be executable
        try:
            exec(shittified_code)
        except Exception as e:
            self.fail(f"Shittified code with conditionals failed to execute: {e}")
    
    def test_with_loops(self):
        """Test that code with loops works after shittification"""
        original_code = """
for i in range(5):
    print(i)

nums = [1, 2, 3]
for num in nums:
    print(num * 2)
"""
        shittified_code = shittify_code(original_code)
        self.assertNotEqual(original_code, shittified_code)
        # The shittified code should be executable
        try:
            exec(shittified_code)
        except Exception as e:
            self.fail(f"Shittified code with loops failed to execute: {e}")
    
    def test_string_operations(self):
        """Test that string operations work after shittification"""
        original_code = """
text = "Hello"
world = "World"
result = text + " " + world
print(result)
"""
        shittified_code = shittify_code(original_code)
        self.assertNotEqual(original_code, shittified_code)
        # The shittified code should be executable
        try:
            exec(shittified_code)
        except Exception as e:
            self.fail(f"Shittified code with string operations failed to execute: {e}")
    
    def test_syntax_validity(self):
        """Test that shittified code is syntactically valid"""
        original_code = """
def test(x, y):
    return x + y

result = test(1, 2)
"""
        shittified_code = shittify_code(original_code)
        # Should be parseable
        import ast
        try:
            ast.parse(shittified_code)
        except SyntaxError as e:
            self.fail(f"Shittified code has syntax errors: {e}")

if __name__ == '__main__':
    unittest.main()
