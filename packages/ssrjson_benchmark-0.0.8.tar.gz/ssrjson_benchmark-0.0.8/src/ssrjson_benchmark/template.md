# ssrJSON benchmark Report

REV:            `{REV}`
Python:         `{PYTHON}`
Orjson:         `{ORJSON_VER}`
MsgSpec:        `{MSGSPEC_VER}`
Ujson:          `{UJSON_VER}`
Generated time: {TIME}
OS:             {OS}
SIMD flag:      {SIMD_FLAGS}
Chipset:        {CHIPSET}
Memory:         {MEM}
Process(GB):    {PROCESS_MEM}
PerBin(MB):     {PER_BIN_MEM}
