# AEA Test Autonomy


Plugin containing test tools for open-autonomy packages.

## Installation and usage

Simply include `open-aea-test-autonomy` as a dependency of your packages.