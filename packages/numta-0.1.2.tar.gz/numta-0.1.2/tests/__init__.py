"""Test suite for numta"""
