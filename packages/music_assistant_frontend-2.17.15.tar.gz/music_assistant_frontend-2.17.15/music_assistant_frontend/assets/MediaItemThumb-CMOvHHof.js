import{_ as a,ct as s}from"./index-BjdGY0D1.js";const _=a(s,[["__scopeId","data-v-565bc716"]]);export{_ as M};
