# Installing whatnext

`whatnext` is a python package:

```bash
pip install whatnext
```
