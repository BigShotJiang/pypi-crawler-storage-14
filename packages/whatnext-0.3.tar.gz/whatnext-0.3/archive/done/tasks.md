# Some old stuff

- [X] Do the first thing
- [X] Do the second thing
- [x] do the last thing all lowercase
