# Sample task file

These tasks are just for the sake of the tests.

- [ ] Do something for the sake of it
