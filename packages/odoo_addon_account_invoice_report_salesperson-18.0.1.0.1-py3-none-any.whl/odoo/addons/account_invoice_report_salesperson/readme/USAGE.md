To print Invoice reports:

#. Go to *Accounting > Customers > Invoices* and pick or create one with Salesperson.  
#. Print it.
