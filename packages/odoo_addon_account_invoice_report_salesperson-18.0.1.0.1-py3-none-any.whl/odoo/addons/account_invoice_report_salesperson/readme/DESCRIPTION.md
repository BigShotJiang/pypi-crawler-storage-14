This module displays salesperson info (name, phone OR mobile) in:

- Invoices report.
- Invoices without Payment report.
