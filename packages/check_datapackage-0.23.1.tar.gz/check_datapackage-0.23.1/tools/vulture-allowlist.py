# ruff: noqa
# mypy: ignore-errors
version  # unused variable (src/check_datapackage/config.py:44)
_check_not_required  # unused method (src/check_datapackage/extensions.py:59)
_check_field_name_in_jsonpath  # unused method (src/check_datapackage/extensions.py:117)
cls  # unused variable (src/check_datapackage/extensions.py:61)
