"""flacfetch - Search and download high-quality audio from multiple sources."""

__version__ = "0.3.3"
__author__ = "Andrew Beveridge"
__email__ = "andrew@beveridge.uk"

