Installation
************

Requirements
=============

- Python 3.7 or newer
- GoodData.CN or GoodData Cloud

Installation
============

Run the following command to install the ``gooddata-pandas`` package on your system:

.. code-block:: shell

    pip install gooddata-pandas
