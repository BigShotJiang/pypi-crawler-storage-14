API
===

.. autosummary::
   :toctree: _autosummary
   :template: module-template.rst
   :recursive:

   gooddata_pandas
