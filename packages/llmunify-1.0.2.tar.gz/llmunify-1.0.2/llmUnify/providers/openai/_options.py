# Based on the documentation at https://platform.openai.com/docs/api-reference/chat/create

from typing import Any, Literal, Optional, Union

from pydantic import BaseModel

from ..._options import LlmOptions


class OpenAIMessage(BaseModel):
    role: Literal["system", "user", "assistant", "tool", "function"]
    content: Optional[Union[str, list[dict[str, Any]]]] = None
    name: Optional[str] = None
    tool_calls: Optional[list[dict[str, Any]]] = None
    tool_call_id: Optional[str] = None
    function_call: Optional[dict[str, Any]] = None


class OpenAIFunctionParameters(BaseModel):
    type: str = "object"
    properties: Optional[dict[str, Any]] = None
    required: Optional[list[str]] = None
    additionalProperties: Optional[bool] = None


class OpenAIFunction(BaseModel):
    name: str
    description: Optional[str] = None
    parameters: Optional[OpenAIFunctionParameters] = None
    strict: Optional[bool] = None


class OpenAITool(BaseModel):
    type: Literal["function"]
    function: OpenAIFunction


class OpenAIToolChoice(BaseModel):
    type: Literal["function"]
    function: dict[str, str]


class OpenAIResponseFormat(BaseModel):
    type: Literal["text", "json_object", "json_schema"]
    json_schema: Optional[dict[str, Any]] = None


class OpenAIStreamOptions(BaseModel):
    include_usage: Optional[bool] = None


class OpenAIOptions(BaseModel):
    messages: list[OpenAIMessage]
    frequency_penalty: Optional[float] = None
    logit_bias: Optional[dict[str, int]] = None
    logprobs: Optional[bool] = None
    top_logprobs: Optional[int] = None
    max_tokens: Optional[int] = None
    max_completion_tokens: Optional[int] = None
    n: Optional[int] = None
    presence_penalty: Optional[float] = None
    response_format: Optional[OpenAIResponseFormat] = None
    seed: Optional[int] = None
    stop: Optional[Union[str, list[str]]] = None
    temperature: Optional[float] = None
    top_p: Optional[float] = None
    tools: Optional[list[OpenAITool]] = None
    tool_choice: Optional[Union[Literal["none", "auto", "required"], OpenAIToolChoice]] = None
    parallel_tool_calls: Optional[bool] = None
    user: Optional[str] = None
    stream_options: Optional[OpenAIStreamOptions] = None

    @classmethod
    def from_generic(cls, generic_options: LlmOptions) -> "OpenAIOptions":
        """Creates an OpenAIOptions instance from a generic LlmOptions."""

        mapping_obj = {
            "messages": [{"role": "user", "content": generic_options.prompt}],
            **(generic_options.openai.model_dump(exclude_none=True) if generic_options.openai else {}),
            "max_tokens": generic_options.max_tokens,
            "temperature": generic_options.temperature,
            "top_p": generic_options.top_p,
            "stop": generic_options.stop_sequences,
        }

        return cls(**mapping_obj)
