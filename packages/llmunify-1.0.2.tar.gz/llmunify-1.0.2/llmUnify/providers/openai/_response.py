# Based on the documentation at https://platform.openai.com/docs/api-reference/chat/object

from typing import Any, Literal, Optional

from pydantic import BaseModel

from ..._response import LlmResponse


class OpenAIFunctionCall(BaseModel):
    name: str
    arguments: str


class OpenAIToolCall(BaseModel):
    id: str
    type: Literal["function"]
    function: OpenAIFunctionCall


class OpenAIMessage(BaseModel):
    role: Literal["system", "user", "assistant", "tool"]
    content: Optional[str] = None
    tool_calls: Optional[list[OpenAIToolCall]] = None
    function_call: Optional[OpenAIFunctionCall] = None


class OpenAILogprobContent(BaseModel):
    token: str
    logprob: float
    bytes: Optional[list[int]] = None
    top_logprobs: Optional[list[dict[str, Any]]] = None


class OpenAILogprobs(BaseModel):
    content: Optional[list[OpenAILogprobContent]] = None
    refusal: Optional[list[OpenAILogprobContent]] = None


class OpenAIChoice(BaseModel):
    index: int
    message: OpenAIMessage
    logprobs: Optional[OpenAILogprobs] = None
    finish_reason: Optional[Literal["stop", "length", "tool_calls", "content_filter", "function_call"]] = None


class OpenAIUsage(BaseModel):
    prompt_tokens: int
    completion_tokens: int
    total_tokens: int
    prompt_tokens_details: Optional[dict[str, Any]] = None
    completion_tokens_details: Optional[dict[str, Any]] = None


class OpenAIResponse(BaseModel):
    id: str
    object: str
    created: int
    model: str
    choices: list[OpenAIChoice]
    usage: Optional[OpenAIUsage] = None
    system_fingerprint: Optional[str] = None
    service_tier: Optional[str] = None

    def to_generic(self) -> LlmResponse:
        """Converts an OpenAIResponse into a generic LlmResponse instance."""
        return LlmResponse(
            generated_text=(
                self.choices[0].message.content if self.choices and self.choices[0].message.content else None
            ),
            model=self.model,
            generated_token_count=self.usage.completion_tokens if self.usage else None,
            input_token_count=self.usage.prompt_tokens if self.usage else None,
            openai=self,
        )
