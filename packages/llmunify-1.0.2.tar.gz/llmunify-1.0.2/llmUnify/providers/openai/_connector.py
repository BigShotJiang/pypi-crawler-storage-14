# Based on the documentation at https://platform.openai.com/docs/api-reference/chat/create

from typing import Iterator, Optional

from openai import OpenAI

from ..._abstract_connector import LlmConnector
from ..._options import LlmOptions
from ..._response import LlmResponse
from ...utils._get_env import get_env, get_required_env
from ._options import OpenAIOptions
from ._response import OpenAIResponse

OPENAI_API_KEY = "LLM_UNIFY_OPENAI_API_KEY"
OPENAI_BASE_URL = "LLM_UNIFY_OPENAI_BASE_URL"
OPENAI_ORGANIZATION = "LLM_UNIFY_OPENAI_ORGANIZATION"


class OpenaiConnector(LlmConnector):
    def __init__(
        self,
        api_key: Optional[str] = None,
        base_url: Optional[str] = None,
        organization: Optional[str] = None,
    ):
        self.api_key = api_key or get_env(OPENAI_API_KEY) or "dummy_api_key"
        self.base_url = base_url or get_required_env(OPENAI_BASE_URL)
        self.organization = organization or get_env(OPENAI_ORGANIZATION)

        # Initialize OpenAI client
        client_kwargs = {"api_key": self.api_key}
        if self.base_url:
            client_kwargs["base_url"] = self.base_url
        if self.organization:
            client_kwargs["organization"] = self.organization

        self.client = OpenAI(**client_kwargs) # type: ignore

    def _generate(self, model_name: str, options: LlmOptions) -> LlmResponse:
        openai_options = OpenAIOptions.from_generic(options)

        response = self.client.chat.completions.create(
            model=model_name,
            **openai_options.model_dump(exclude_none=True),
        )

        # Convert OpenAI response to dict for Pydantic
        response_dict = response.model_dump()
        return OpenAIResponse(**response_dict).to_generic()

    def _generate_stream(self, model_name: str, options: LlmOptions) -> Iterator[LlmResponse]:
        openai_options = OpenAIOptions.from_generic(options)

        stream = self.client.chat.completions.create(
            model=model_name,
            stream=True,
            **openai_options.model_dump(exclude_none=True),
        )

        accumulated_content = ""
        last_response = None

        for chunk in stream:
            chunk_dict = chunk.model_dump()

            # Accumulate content from delta
            if chunk_dict["choices"] and chunk_dict["choices"][0].get("delta", {}).get("content"):
                content = chunk_dict["choices"][0]["delta"]["content"]
                accumulated_content += content

                # Build a complete response structure for each chunk
                complete_response = {
                    "id": chunk_dict["id"],
                    "object": chunk_dict["object"],
                    "created": chunk_dict["created"],
                    "model": chunk_dict["model"],
                    "choices": [
                        {
                            "index": 0,
                            "message": {"role": "assistant", "content": accumulated_content},
                            "finish_reason": chunk_dict["choices"][0].get("finish_reason"),
                        }
                    ],
                    "usage": chunk_dict.get("usage"),
                }

                last_response = OpenAIResponse(**complete_response).to_generic()
                yield last_response

        if last_response:
            yield last_response
