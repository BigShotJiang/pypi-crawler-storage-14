from enum import Enum
from typing import List, Optional
from pydantic import BaseModel, Field

class BackUrlDto(BaseModel):
    back_url_cancel: str | None = Field(None, alias="backUrlCancel")
    back_url_ko: str = Field(..., alias="backUrlKO")
    back_url_notify: str | None = Field(None, alias="backUrlNotify")
    back_url_ok: str = Field(..., alias="backUrlOK")

class CausaAggStatoEnum(str, Enum):
    ALTRO = "ALTRO"
    ATTIVAZIONE = "ATTIVAZIONE"
    ATTIVAZIONE_RIAPERTURA_TERMINI = "ATTIVAZIONE_RIAPERTURA_TERMINI"
    DISATTIVAZIONE = "DISATTIVAZIONE"
    ELIMINAZIONE = "ELIMINAZIONE"
    ELIMINAZIONE_DA_CRUSCOTTO = "ELIMINAZIONE_DA_CRUSCOTTO"
    ELIMINAZIONE_DEBITO = "ELIMINAZIONE_DEBITO"
    IMPORTO_ATTUALIZZATO = "IMPORTO_ATTUALIZZATO"
    MODIFICA_CAUSALE = "MODIFICA_CAUSALE"
    MODIFICA_CONTRIBUENTE = "MODIFICA_CONTRIBUENTE"
    MODIFICA_DATE_SCADENZA = "MODIFICA_DATE_SCADENZA"
    MODIFICA_DETTAGLI_IMPORTO = "MODIFICA_DETTAGLI_IMPORTO"
    MODIFICA_IMPORTO = "MODIFICA_IMPORTO"
    MODIFICA_SPESE_NOTIFICA = "MODIFICA_SPESE_NOTIFICA"
    PAGAMENTO_ESTERNO = "PAGAMENTO_ESTERNO"
    RIATTIVAZIONE_DAFLUSSO_REND = "RIATTIVAZIONE_DAFLUSSO_REND"
    SOSTITUZIONE = "SOSTITUZIONE"
    
class EsitoRichiestaPagamentoEnum(str, Enum):
    CONCLUSO_ESEGUITO = "CONCLUSO_ESEGUITO"
    CONCLUSO_ESEGUITO_PARZIALMENTE = "CONCLUSO_ESEGUITO_PARZIALMENTE"
    CONCLUSO_NON_ESEGUITO = "CONCLUSO_NON_ESEGUITO"
    CONCLUSO_NON_ESEGUITO_DECORRENZA = "CONCLUSO_NON_ESEGUITO_DECORRENZA"
    CONCLUSO_NON_ESEGUITO_DECORRENZA_PARZIALE = "CONCLUSO_NON_ESEGUITO_DECORRENZA_PARZIALE"
    NON_CONCLUSO = "NON_CONCLUSO"
    RIFIUTATA = "RIFIUTATA"


class StatoTecnicoPagamentoEnum(str, Enum):
    COMPLETATO = "COMPLETATO"
    CONTABILIZZATO = "CONTABILIZZATO"
    INVIATO = "INVIATO"
    NOTIFICATO = "NOTIFICATO"
    RIFIUTATO = "RIFIUTATO"


class TipoVersamentoEnum(str, Enum):
    AD = "AD"
    BBT = "BBT"
    BP = "BP"
    CP = "CP"
    INDETERMINATO = "INDETERMINATO"
    OBEP = "OBEP"
    PO = "PO"


class EsitoNotificaEnum(str, Enum):
    CON_SCARTI = "CON_SCARTI"
    ERROR = "Error"
    OK = "OK"


class NumeroAvviso(BaseModel):
    numero_avviso: str = Field(..., alias="numeroAvviso")

class Esito(BaseModel):
    codice: str | None = None
    descrizione: str | None = None

class TipoIdentificativoUnivoco(str, Enum):
    F = "F"  # Persona fisica
    G = "G"  # Persona giuridica
    
class ContribuenteDebitoDto(BaseModel):
    codice_identificativo_univoco: str = Field(..., alias="codiceIdentificativoUnivoco")
    tipo_identificativo_univoco: TipoIdentificativoUnivoco = Field(
        ..., alias="tipoIdentificativoUnivoco"
    )
    
class EsitoEnum(str, Enum):
    CON_SCARTI = "CON_SCARTI"
    ERROR = "Error"
    OK = "OK"

class EsitoDto(BaseModel):
    esito: EsitoEnum | None = None
    messaggio: str | None = None
    
class ContestoDovuto(str, Enum):
    MONOBENEFICIARIO = "MONOBENEFICIARIO"
    MULTIBENEFICIARIO = "MULTIBENEFICIARIO"
    
class ChiaveDebitoDto(BaseModel):
    cod_ente_creditore: str = Field(..., alias="codEnteCreditore")
    codice_tipo_debito: str = Field(..., alias="codiceTipoDebito")
    i_deb: str = Field(..., alias="iDeb")
    i_pos: str = Field(..., alias="iPos")
    

class ContribuenteDto(BaseModel):
    cap: str | None = None
    civico: str | None = None

    codice_identificativo_univoco: str = Field(
        ..., alias="codiceIdentificativoUnivoco"
    )

    cognome: str | None = None
    email: str | None = None
    indirizzo: str | None = None
    localita: str | None = None
    nazione: str | None = None
    nome: str | None = None
    provincia: str | None = None

    ragione_sociale: str | None = Field(
        None, alias="ragioneSociale"
    )

    tipo_identificativo_univoco: TipoIdentificativoUnivoco = Field(
        ..., alias="tipoIdentificativoUnivoco"
    )

class TestataDovutoDto(BaseModel):
    dati_contribuente: ContribuenteDto | None = Field(None, alias="datiContribuente")

    dettaglio_posizione: str = Field(
        ...,
        alias="dettaglioPosizione",
    )

    id_pos: str = Field(
        ...,
        alias="idPos",
    )
    
    
class NumeroAvvisoDto(BaseModel):
    flag_attiva_debito: bool | None = Field(None, alias="flagAttivaDebito")
    numero_avviso: str = Field(..., alias="numeroAvviso")
    versione_numero_avviso: int | None = Field(None, alias="versioneNumeroAvviso")
    
    
class TestataDovutoDto(BaseModel):
    dati_contribuente: ContribuenteDto | None = Field(None, alias="datiContribuente")

    dettaglio_posizione: str = Field(
        ...,
        alias="dettaglioPosizione",
    )

    id_pos: str = Field(
        ...,
        alias="idPos",
    )

    
class DatoAccertamentoDto(BaseModel):
    anno_accertamento: str = Field(..., alias="annoAccertamento")
    codice_accertamento: str = Field(..., alias="codiceAccertamento")
    descrizione_accertamento: str = Field(..., alias="descrizioneAccertamento")
    importo_accertamento: float = Field(..., alias="importoAccertamento")
    
class ParametroDebitoDto(BaseModel):
    codice: str | None = None
    valore: str | None = None
    
class MarcaDaBolloDto(BaseModel):
    hash_documento: str = Field(..., alias="hashDocumento")
    provincia_residenza_soggetto_pagatore: str = Field(..., alias="provinciaResidenzaSoggettoPagatore")
    tipologia: str | None = None

class SpeseNotificaEnum(str, Enum):
    ATTUALIZZAZIONE_DELAYED = "ATTUALIZZAZIONE_DELAYED"
    ATTUALIZZAZIONE_OFF = "ATTUALIZZAZIONE_OFF"
    ATTUALIZZAZIONE_ON = "ATTUALIZZAZIONE_ON"

class DettaglioDovutoDto(BaseModel):
    causale_debito: str = Field(..., alias="causaleDebito")
    codice_ipa_creditore: str = Field(..., alias="codiceIpaCreditore")
    codice_lotto: str | None = Field(None, alias="codiceLotto")
    codice_tipo_debito: str = Field(..., alias="codiceTipoDebito")

    data_attualizzazione: Optional[str] = Field(None, alias="dataAttualizzazione")
    data_fine_validita: Optional[str] = Field(None, alias="dataFineValidita")
    data_inizio_validita: str = Field(..., alias="dataInizioValidita")
    data_limite_pagabilita: Optional[str] = Field(None, alias="dataLimitePagabilita")

    dati_accertamento: Optional[List[DatoAccertamentoDto]] = Field(None, alias="datiAccertamento")

    gruppo: str = Field(..., alias="gruppo")
    id_deb: str = Field(..., alias="idDeb")
    importo_debito: float = Field(..., alias="importoDebito")

    importo_pa_fee: Optional[float] = Field(None, alias="importoPaFee")
    importo_spese_notifica: Optional[float] = Field(None, alias="importoSpeseNotifica")

    marca_da_bollo: Optional[MarcaDaBolloDto] = Field(None, alias="marcaDaBollo")

    ordinamento: int = Field(..., alias="ordinamento")

    parametri_debito: Optional[List[ParametroDebitoDto]] = Field(None, alias="parametriDebito")

    spese_notifica_da_attualizzare: Optional[SpeseNotificaEnum] = Field(
        None, alias="speseNotificaDaAttualizzare"
    )

    spese_notifica_voce_contabile: Optional[str] = Field(
        None, alias="speseNotificaVoceContabile"
    )
    
    
class InviaDovutoDto(BaseModel):
    contesto_dovuto: ContestoDovuto = Field(..., alias="contestoDovuto")
    dettaglio_dovuto: List[DettaglioDovutoDto] = Field(..., alias="dettaglioDovuto")
    numero_avviso: NumeroAvvisoDto | None = Field(None, alias="numeroAvviso")
    testata_dovuto: TestataDovutoDto = Field(..., alias="testataDovuto")

class ModificaDovutoDto(BaseModel):
    contesto_dovuto: ContestoDovuto = Field(..., alias="contestoDovuto")
    dettaglio_dovuto: List[DettaglioDovutoDto] = Field(..., alias="dettaglioDovuto")
    numero_avviso: NumeroAvvisoDto = Field(..., alias="numeroAvviso")
    testata_dovuto: TestataDovutoDto = Field(..., alias="testataDovuto")
    
    
class RicercaDovutiRequest(BaseModel):
    cod_ipa_richiedente: str = Field(..., alias="codIpaRichiedente")
    codice_servizio: str | None = Field(None, alias="codiceServizio")
    codice_fiscale: str | None = Field(None, alias="codiceFiscale")
    iuv: str | None = None


class DovutoItem(BaseModel):
    iuv: str | None = None
    numero_avviso: str | None = Field(None, alias="numeroAvviso")
    importo: float | None = None
    descrizione: str | None = None
    stato: str | None = None


class RicercaDovutiResponse(BaseModel):
    esito: str | None = None
    items: list[DovutoItem] | None = Field(None, alias="listaDovuti")
    
class DettaglioDovutoRequest(BaseModel):
    cod_ipa_richiedente: str = Field(..., alias="codIpaRichiedente")
    iuv: str = Field(...)


class VoceDovuto(BaseModel):
    tipo: str | None = None
    importo: float | None = None
    descrizione: str | None = None


class DettaglioDovutoResponse(BaseModel):
    esito: str | None = None
    iuv: str | None = None
    voci: list[VoceDovuto] | None = Field(None, alias="vociDovuto")
    totale: float | None = Field(None, alias="totaleImporto")
    descrizione: str | None = None
    
    
class EsitoDovutoRequest(BaseModel):
    cod_ipa_richiedente: str = Field(..., alias="codIpaRichiedente")
    iuv: str = Field(...)
    stato: str | None = None


class EsitoDovutoResponse(BaseModel):
    esito: str | None = None
    iuv: str | None = None
    stato: str | None = None
    descrizione: str | None = None
    
    
class RichiestaInviaDovutiRestDto(BaseModel):
    codice_ipa: str = Field(..., alias="codiceIPA")
    codice_servizio: str = Field(..., alias="codiceServizio")
    dovuti: List[InviaDovutoDto] = Field(...)
    transactional: bool | None = False
    
class RichiestaInviaDovutoRestDto(BaseModel):
    codice_ipa: str = Field(..., alias="codiceIPA")
    codice_servizio: str = Field(..., alias="codiceServizio")
    dovuto: InviaDovutoDto = Field(..., alias="dovuto")
    
    
class OperazioneModifica(str, Enum):
    ALL = "ALL"
    MODIFICA_ANNO_COMPETENZA = "MODIFICA_ANNO_COMPETENZA"
    MODIFICA_CAUSALE_DEBITO = "MODIFICA_CAUSALE_DEBITO"
    MODIFICA_CONTRIBUENTE_DEBITO = "MODIFICA_CONTRIBUENTE_DEBITO"
    MODIFICA_DETTAGLI_IMPORTO_DEBITO = "MODIFICA_DETTAGLI_IMPORTO_DEBITO"
    MODIFICA_IMPORTO_DEBITO = "MODIFICA_IMPORTO_DEBITO"
    MODIFICA_SCADENZA_DEBITO = "MODIFICA_SCADENZA_DEBITO"


class RichiestaModificaDovutiDto(BaseModel):
    codice_ipa: str = Field(..., alias="codiceIPA")
    codice_servizio: str = Field(..., alias="codiceServizio")
    dovuto_dto: ModificaDovutoDto = Field(..., alias="dovutoDto")
    operazione: OperazioneModifica = Field(..., alias="operazione")
    
class AvvisoPagamentoResultDto(BaseModel):
    chiave_debito_dto: Optional[ChiaveDebitoDto] = Field(
        None, alias="chiaveDebitoDto"
    )
    esito: Optional[EsitoDto] = None
    numero_avviso_dto: Optional[NumeroAvvisoDto] = Field(
        None, alias="numeroAvvisoDto"
    )
    
class RispostaInviaDovutoDto(BaseModel):
    avviso_pagamento_result_dto: Optional[AvvisoPagamentoResultDto] = Field(
        None, alias="avvisoPagamentoResultDto"
    )
    cod_ipa_richiedente: str = Field(..., alias="codIpaRichiedente")
    codice_servizio: str = Field(..., alias="codiceServizio")



class DettaglioImportoDto0(BaseModel):
    anno: Optional[str] = None
    capitolo_bilancio: Optional[str] = None
    descrizione: Optional[str] = None
    importo: Optional[float] = None
    
class DatiDebitoreDto(BaseModel):
    cap: str | None = None
    civico: str | None = None
    codice_identificativo_univoco: str | None = Field(None, alias="codiceIdentificativoUnivoco")
    cognome: str | None = None
    email: str | None = None
    identificativo_univoco_debitore: str | None = Field(None, alias="identificativoUnivocoDebitore")
    indirizzo: str | None = None
    localita: str | None = None
    nazione: str | None = None
    nome: str | None = None
    provincia: str | None = None
    ragione_sociale: str | None = Field(None, alias="ragioneSociale")
    tipo_identificativo_univoco: str | None = Field(None, alias="tipoIdentificativoUnivoco")

class DatiVersanteDto(BaseModel):
    cap: str | None = None
    civico: str | None = None
    codice_identificativo_univoco: str | None = Field(None, alias="codiceIdentificativoUnivoco")
    cognome: str | None = None
    email: str | None = None
    identificativo_univoco_versante: str | None = Field(None, alias="identificativoUnivocoVersante")
    indirizzo: str | None = None
    localita: str | None = None
    nazione: str | None = None
    nome: str | None = None
    provincia: str | None = None
    ragione_sociale: str | None = Field(None, alias="ragioneSociale")
    tipo_identificativo_univoco: str | None = Field(None, alias="tipoIdentificativoUnivoco")

class DettaglioImportoDto(BaseModel):
    codice: Optional[str] = None
    importo: Optional[float] = None
    tipo: Optional[str] = None

class AnagraficaDebitore(BaseModel):
    codice_fiscale: str | None = Field(None, alias="codiceFiscale")
    ragione_sociale: str | None = Field(None, alias="ragioneSociale")


class ImportoAvviso(BaseModel):
    importo: float | None = None
    descrizione: str | None = None



class DebitoDto(BaseModel):
    causa_agg_stato: Optional[CausaAggStatoEnum] = Field(None, alias="causaAggStato")
    causale_debito: str = Field(..., alias="causaleDebito")
    cod_ipa_creditore: str = Field(..., alias="codIpaCreditore")
    cod_ipa_richiedente: str = Field(..., alias="codIpaRichiedente")
    codice_lotto: str = Field(..., alias="codiceLotto")
    codice_servizio: str = Field(..., alias="codiceServizio")
    codice_tipo_debito: str = Field(..., alias="codiceTipoDebito")
    contribuente_dto: ContribuenteDto = Field(..., alias="contribuenteDto")

    data_attualizzazione: Optional[str] = Field(None, alias="dataAttualizzazione")
    data_fine_validita: Optional[str] = Field(None, alias="dataFineValidita")
    data_inizio_validita: str = Field(..., alias="dataInizioValidita")
    data_limite_pagabilita: Optional[str] = Field(None, alias="dataLimitePagabilita")

    dati_accertamento: Optional[List[DatoAccertamentoDto]] = Field(
        None, alias="datiAccertamento"
    )

    dettaglio_posizione: str = Field(..., alias="dettaglioPosizione")

    gruppo: str = Field(..., alias="gruppo")

    id_debito: Optional[int] = Field(None, alias="idDebito")
    id_debito_bo: str = Field(..., alias="idDebitoBO")
    id_posizione_bo: str = Field(..., alias="idPosizioneBO")

    importo_debito: float = Field(..., alias="importoDebito")
    importo_pa_fee: Optional[float] = Field(None, alias="importoPaFee")
    importo_spese_notifica: Optional[float] = Field(None, alias="importoSpeseNotifica")

    marca_da_bollo: Optional[MarcaDaBolloDto] = Field(None, alias="marcaDaBollo")

    ordinamento: int = Field(..., alias="ordinamento")

    parametri_debito: Optional[List[ParametroDebitoDto]] = Field(None, alias="parametriDebito")

    spese_notifica_da_attualizzare: Optional[SpeseNotificaEnum] = Field(
        None, alias="speseNotificaDaAttualizzare"
    )

    spese_notifica_voce_contabile: Optional[str] = Field(
        None, alias="speseNotificaVoceContabile"
    )


class AvvisoPagamentoDto(BaseModel):
    debito_dto: Optional[DebitoDto] = Field(None, alias="debitoDto")
    debito_secondario_dto: Optional[DebitoDto] = Field(None, alias="debitoSecondarioDto")
    numero_avviso_dto: Optional[NumeroAvvisoDto] = Field(None, alias="numeroAvvisoDto")

class RichiestaInfoAvvisoPagamentoPerNumeroAvvisoDto(BaseModel):
    cod_ipa_richiedente: str = Field(..., alias="codIpaRichiedente")
    codice_ipa_creditore: str | None = Field(None, alias="codiceIpaCreditore")
    codice_servizio: str = Field(..., alias="codiceServizio")
    numero_avviso: str = Field(..., alias="numeroAvviso")
    
class EsitoVersamentoSingoloEnum(str, Enum):
    CONCLUSO_ESEGUITO = "CONCLUSO_ESEGUITO"
    CONCLUSO_ESEGUITO_PARZIALMENTE = "CONCLUSO_ESEGUITO_PARZIALMENTE"
    CONCLUSO_NON_ESEGUITO = "CONCLUSO_NON_ESEGUITO"
    CONCLUSO_NON_ESEGUITO_DECORRENZA = "CONCLUSO_NON_ESEGUITO_DECORRENZA"
    CONCLUSO_NON_ESEGUITO_DECORRENZA_PARZIALE = "CONCLUSO_NON_ESEGUITO_DECORRENZA_PARZIALE"
    NON_CONCLUSO = "NON_CONCLUSO"
    RIFIUTATA = "RIFIUTATA"


class InfoSingoloPagamentoDto(BaseModel):
    chiave_debito: Optional[ChiaveDebitoDto] = Field(None, alias="chiaveDebito")
    dettagli_importo: Optional[List[DettaglioImportoDto]] = Field(None, alias="dettagliImporto")
    esito_versamento_singolo: Optional[EsitoVersamentoSingoloEnum] = Field(
        None, alias="esitoVersamentoSingolo"
    )
    importo_singolo_pagato: Optional[float] = Field(None, alias="importoSingoloPagato")
    importo_singolo_richiesta: Optional[float] = Field(None, alias="importoSingoloRichiesta")
    progressivo_versamento_singolo: Optional[int] = Field(
        None, alias="progressivoVersamentoSingolo"
    )
    testo_allegato: Optional[str] = Field(None, alias="testoAllegato")
    tipo_allegato: Optional[str] = Field(None, alias="tipoAllegato")
    
class RichiestaModificaImportoDto(BaseModel):
    attualizzazione_spese_notifica: Optional[SpeseNotificaEnum] = Field(
        None, alias="attualizzazioneSpeseNotifica"
    )
    causa_agg_stato: CausaAggStatoEnum = Field(..., alias="causaAggStato")

    cod_ipa_richiedente: str = Field(..., alias="codIpaRichiedente")
    codice_servizio: str = Field(..., alias="codiceServizio")

    data_attualizzazione: Optional[str] = Field(
        None, alias="dataAttualizzazione"
    )

    dati_accertamento: Optional[List[DatoAccertamentoDto]] = Field(
        None, alias="datiAccertamento"
    )

    importo: float = Field(..., alias="importo")
    importo_pa_fee: Optional[float] = Field(None, alias="importoPaFee")
    importo_spese_notifica: Optional[float] = Field(
        None, alias="importoSpeseNotifica"
    )

    numero_avviso_dto: NumeroAvvisoDto = Field(..., alias="numeroAvvisoDto")

    spese_notifica_voce_contabile: Optional[str] = Field(
        None, alias="speseNotificaVoceContabile"
    )


class RispostaModificaImportoDto(BaseModel):
    cod_ipa_richiedente: str = Field(..., alias="codIpaRichiedente")
    codice_servizio: str = Field(..., alias="codiceServizio")
    numero_avviso_dto: NumeroAvvisoDto | None = Field(
        None, alias="numeroAvvisoDto"
    )
    
class RichiestaPagaDebitiDto(BaseModel):
    back_url_dto: Optional[BackUrlDto] = Field(None, alias="backUrlDto")
    cod_ipa_richiedente: str = Field(..., alias="codIpaRichiedente")
    codice_servizio: str = Field(..., alias="codiceServizio")

    debiti: List[DebitoDto] = Field(..., alias="debiti")

    id_richiesta_pagamento: str = Field(..., alias="idRichiestaPagamento")

    multibeneficiario: Optional[bool] = Field(None, alias="multibeneficiario")

    versante: ContribuenteDto = Field(..., alias="versante")
    
class RispostaPagaDebitiDto(BaseModel):
    cod_ipa_richiedente: str = Field(..., alias="codIpaRichiedente")
    codice_servizio: str = Field(..., alias="codiceServizio")

    esito_dto: Optional[EsitoDto] = Field(None, alias="esitoDto")

    ident_transazione: str = Field(..., alias="identTransazione")
    url: str = Field(..., alias="url")
    
class InfoMultibeneficiarioDto(BaseModel):
    chiavi_debito: Optional[ChiaveDebitoDto] = Field(None, alias="chiaviDebito")
    codice_ipa: Optional[str] = Field(None, alias="codiceIpa")
    importo: Optional[float] = None
    
class MultibeneficiarioDto(BaseModel):
    importo_totale: Optional[float] = Field(None, alias="importoTotale")
    info_multibeneficiario: Optional[List[InfoMultibeneficiarioDto]] = Field(
        None, alias="infoMultibeneficiario"
    )
    multibeneficiario: Optional[bool] = None
    
    

class InfoPagamentoTelematicoResponseDto(BaseModel):
    codice_contesto_pagamento: Optional[str] = Field(None, alias="codiceContestoPagamento")
    data_accredito: Optional[str] = Field(None, alias="dataAccredito")
    data_pagamento: Optional[str] = Field(None, alias="dataPagamento")
    dati_debitore: Optional[DatiDebitoreDto] = Field(None, alias="datiDebitore")
    dati_versante: Optional[DatiVersanteDto] = Field(None, alias="datiVersante")

    esito_richiesta_pagamento: Optional[EsitoRichiestaPagamentoEnum] = Field(
        None, alias="esitoRichiestaPagamento"
    )

    flusso_ricevuta: Optional[str] = Field(None, alias="flussoRicevuta")
    ident_transazione: Optional[str] = Field(None, alias="identTransazione")
    identificativo_dominio: Optional[str] = Field(None, alias="identificativoDominio")
    identificativo_univoco_versamento: str = Field(
        ..., alias="identificativoUnivocoVersamento"
    )
    importo_totale_pagato: Optional[float] = Field(None, alias="importoTotalePagato")
    importo_totale_richiesta: Optional[float] = Field(None, alias="importoTotaleRichiesta")

    info_versamento_singolo: Optional[List[InfoSingoloPagamentoDto]] = Field(
        None, alias="infoVersamentoSingolo"
    )

    numero_avviso: Optional[str] = Field(None, alias="numeroAvviso")

    numero_versamenti_singoli: int = Field(
        ..., alias="numeroVersamentiSingoli"
    )

    stato_tecnico_pagamento: Optional[StatoTecnicoPagamentoEnum] = Field(
        None, alias="statoTecnicoPagamento"
    )

    testo_originale_ricevuta: Optional[str] = Field(None, alias="testoOriginaleRicevuta")

    tipo_versamento: Optional[TipoVersamentoEnum] = Field(
        None, alias="tipoVersamento"
    )
    
class RispostaInfoPagamentoPerIuvDto(BaseModel):
    avviso_pagamento_dto: Optional[AvvisoPagamentoDto] = Field(
        None, alias="avvisoPagamentoDto"
    )
    cod_ipa_richiedente: str = Field(..., alias="codIpaRichiedente")
    codice_servizio: str = Field(..., alias="codiceServizio")
    data_valuta: Optional[str] = Field(None, alias="dataValuta")
    info_pagamento_telematico: Optional[List[InfoPagamentoTelematicoResponseDto]] = Field(
        None, alias="infoPagamentoTelematico"
    )

class RispostaInfoAvvisoPagamentoPerNumeroAvvisoDto(BaseModel):
    avviso_pagamento_dto: Optional[AvvisoPagamentoDto] = Field(
        None, alias="avvisoPagamentoDto"
    )
    cod_ipa_richiedente: str = Field(..., alias="codIpaRichiedente")
    codice_servizio: str = Field(..., alias="codiceServizio")

    multibeneficiario_dto: Optional[MultibeneficiarioDto] = Field(
        None, alias="multibeneficiarioDto"
    )
    
class RichiestaInfoPagamentoDebitoDto(BaseModel):
    chiave_debito_dto: ChiaveDebitoDto = Field(..., alias="chiaveDebitoDto")
    cod_ipa_richiedente: str = Field(..., alias="codIpaRichiedente")
    codice_servizio: str = Field(..., alias="codiceServizio")

class RispostaInfoPagamentoDebitoDto(BaseModel):
    chiave_debito_dto: Optional[ChiaveDebitoDto] = Field(
        None, alias="chiaveDebitoDto"
    )
    cod_ipa_richiedente: str = Field(..., alias="codIpaRichiedente")
    codice_servizio: str = Field(..., alias="codiceServizio")

    data_valuta: Optional[str] = Field(None, alias="dataValuta")

    info_pagamento_telematico: Optional[
        List[InfoPagamentoTelematicoResponseDto]
    ] = Field(None, alias="infoPagamentoTelematico")

    multibeneficiario_dto: Optional[MultibeneficiarioDto] = Field(
        None, alias="multibeneficiarioDto"
    )
    
class RichiestaNotificaPagamentoDto(BaseModel):
    base64_ricevuta: str = Field(..., alias="base64Ricevuta")
    dettaglio_importo_dto_list: Optional[List[DettaglioImportoDto0]] = Field(
        None, alias="dettaglioImportoDtoList"
    )
    identificativo_dominio_ente_creditore: str = Field(
        ..., alias="identificativoDominioEnteCreditore"
    )
    
class RichiestaNotificaPagamentoV2Dto(BaseModel):
    base64_ricevuta: str = Field(..., alias="base64Ricevuta")
    dati_accertamento: Optional[List[DatoAccertamentoDto]] = Field(
        None, alias="datiAccertamento"
    )
    identificativo_dominio_ente_creditore: str = Field(
        ..., alias="identificativoDominioEnteCreditore"
    )
    
class RispostaNotificaPagamentoDto(BaseModel):
    error_messages: Optional[List[str]] = Field(None, alias="errorMessages")
    esito: Optional[EsitoNotificaEnum] = None
    identificativo_univoco_versamento: Optional[str] = Field(
        None, alias="identificativoUnivocoVersamento"
    )
    warning_messages: Optional[List[str]] = Field(None, alias="warningMessages")
    
    
class InfoPerNumeroAvvisoRequest(BaseModel):
    cod_ipa_richiedente: str = Field(..., alias="codIpaRichiedente")
    codice_servizio: str = Field(..., alias="codiceServizio")
    numero_avviso_dto: NumeroAvviso = Field(..., alias="numeroAvvisoDto")
    
class InfoPerNumeroAvvisoResponse(BaseModel):
    esito: Esito | None = None
    numero_avviso: str | None = Field(None, alias="numeroAvviso")
    anagrafica_debitore: AnagraficaDebitore | None = Field(None, alias="anagraficaDebitore")
    importo_dto: ImportoAvviso | None = Field(None, alias="importoDto")
    message: str | None = None
    
class VoceImporto(BaseModel):
    tipo: str | None = None
    importo: float | None = None
    descrizione: str | None = None

    
class DettaglioAvvisoRequest(BaseModel):
    cod_ipa_richiedente: str = Field(..., alias="codIpaRichiedente")
    numero_avviso_dto: NumeroAvviso = Field(..., alias="numeroAvvisoDto")


class DettaglioAvvisoResponse(BaseModel):
    esito: Esito | None = None
    numero_avviso: str | None = Field(None, alias="numeroAvviso")
    voci_importo: list[VoceImporto] | None = Field(None, alias="vociImporto")
    totale_importo: float | None = Field(None, alias="totaleImporto")
    
class EsitoPagamentoRequest(BaseModel):
    cod_ipa_richiedente: str = Field(..., alias="codIpaRichiedente")
    numero_avviso_dto: NumeroAvviso = Field(..., alias="numeroAvvisoDto")
    iuv: str | None = None
    stato: str | None = None


class EsitoPagamentoResponse(BaseModel):
    esito: Esito | None = None
    iuv: str | None = None
    stato: str | None = None
    descrizione: str | None = None
    
    
class JppaLoginRequest(BaseModel):
    id_messaggio: str = Field(..., alias="idMessaggio")
    identificativo_ente: str = Field(..., alias="identificativoEnte")
    username: str = Field(..., alias="username")
    password: str = Field(..., alias="password")
    
class JppaLoginResponse(BaseModel):
    descrizione_errore: str | None = Field(None, alias="descrizioneErrore")
    esito: str | None = None
    token: str | None = None
    
class MaggioliApiError(Exception):
    pass