from datetime import datetime, timedelta
import uuid
import httpx
import jwt
from typing import Optional
from pagopa_schema.schemas import IConfigPagoPa

from .schemas import (
    DettaglioAvvisoRequest,
    DettaglioAvvisoResponse,
    EsitoPagamentoRequest,
    EsitoPagamentoResponse,
    InfoPerNumeroAvvisoRequest,
    InfoPerNumeroAvvisoResponse,
    InviaDovutoDto,
    JppaLoginRequest,
    JppaLoginResponse,
    ModificaDovutoDto,
    OperazioneModifica,
    RicercaDovutiRequest,
    RicercaDovutiResponse,
    DettaglioDovutoRequest,
    DettaglioDovutoResponse,
    EsitoDovutoRequest,
    EsitoDovutoResponse,
    RichiestaInviaDovutiRestDto,
    RichiestaInviaDovutoRestDto,
    RichiestaModificaDovutiDto,
    RispostaInviaDovutoDto,
    RichiestaInfoAvvisoPagamentoPerNumeroAvvisoDto, 
    RichiestaInfoPagamentoDebitoDto, 
    RichiestaModificaImportoDto, 
    RichiestaNotificaPagamentoDto, 
    RichiestaNotificaPagamentoV2Dto, 
    RichiestaPagaDebitiDto, 
    RispostaInfoAvvisoPagamentoPerNumeroAvvisoDto, 
    RispostaInfoPagamentoDebitoDto, 
    RispostaModificaImportoDto, 
    RispostaNotificaPagamentoDto, 
    RispostaPagaDebitiDto
)

class PagoPaClient:
    
    _config:IConfigPagoPa
    _token: str

    def __init__(self, config:IConfigPagoPa):
        self._config = config
        self._token = None
        self._client = httpx.AsyncClient()
        
    async def _ensure_token(self):
        tk = None
        try:
            tk = jwt.decode(self._token, options={"verify_signature": False})
        except :
            pass
        
        if not tk:
            await self._login()
            
    async def _login(self):
        
        req = JppaLoginRequest(
            idMessaggio=str(uuid.uuid4()),
            identificativoEnte=self._config.codiceIpa,
            username=self._config.wsUser,
            password=self._config.wsPassword,
        )
        
        data = await self._post(
            "/login",
            req.model_dump(by_alias=True),
            auth=False,  # niente token durante il login
        )

        res = JppaLoginResponse.model_validate(data)
        if not res.token:
            raise Exception(f"Login fallita: {res.descrizione_errore}")

        print (res.token)
        self._token = res.token


    def _headers(self) -> dict:
        h = {"Content-Type": "application/json"}
        if self._token:
            h["Authorization"] = f"Bearer {self._token}"
        return h
    
    async def _request(self, method, path, json=None, auth=True):
        url = f"{self._config.wsUrl}{path}"

        # 1) se l'endpoint richiede auth e abbiamo un token → prova la request
        headers = {}
        if auth and self._token:
            headers["Authorization"] = f"Bearer {self._token}"

        resp = await self._client.request(method, url, json=json, headers=headers)

        # 2) se ottieni 401 e hai provato solo "una" volta → rifai login e ritenta
        if resp.status_code == 401 and auth:
            # rifai login
            await self._login()

            # aggiorna header
            headers = {"Authorization": f"Bearer {self._token}"}

            # secondo e ultimo tentativo
            resp = await self._client.request(method, url, json=json, headers=headers)

            # 3) se ancora 401 → ERRORE
            if resp.status_code == 401:
                raise Exception("Autenticazione Maggioli fallita anche dopo il login.")

        resp.raise_for_status()
        return resp.json() if resp.content else None

    
    async def _post(self, path: str, json=None, auth=True):
        return await self._request("POST", path, json=json, auth=auth)

    async def _patch(self, path: str, json=None, auth=True):
        return await self._request("PATCH", path, json=json, auth=auth)

    async def aclose(self):
        await self._client.aclose()
        
 
 
 
 
    # ------------------------------
    # AvvisiPagamento: infoPerNumeroAvviso
    # ------------------------------
    async def info_per_numero_avviso(
        self,
        cod_ipa: str,
        codice_servizio: str,
        numero_avviso: str,
    ):
        req = InfoPerNumeroAvvisoRequest(
            cod_ipa_richiedente=cod_ipa,
            codice_servizio=codice_servizio,
            numero_avviso_dto={"numeroAvviso": numero_avviso},
        )

        data = await self._post(
            "/avvisiPagamento/v2/infoPerNumeroAvviso",
            req.model_dump(by_alias=True),
        )

        return InfoPerNumeroAvvisoResponse.model_validate(data)
    
    
    
    
    
    

    async def paga_debiti(
        self,
        richiesta: RichiestaPagaDebitiDto,
    ) -> RispostaPagaDebitiDto:
        """
        POST /debiti/v1/paga
        Crea un carrello di debiti, avvia una transazione
        e restituisce identTransazione + URL pagamento.
        """
        data = await self._post(
            "/debiti/v1/paga",
            richiesta.model_dump(by_alias=True),
        )

        return RispostaPagaDebitiDto.model_validate(data)



    
    
    async def info_per_iuv(
        self,
        numero_avviso: str,
        cod_ipa: str="c_e463",
        codice_servizio: str="GISWEB",
    ):
        payload  = {
            "codIpaRichiedente": cod_ipa,
            "codiceIpaCreditore": cod_ipa,
            "codiceServizio": codice_servizio,
            "iuv": numero_avviso
        }
        data = await self._post("/pagamenti/v2/infoPerIuv", payload)
        return data
    
    

    # ------------------------------
    # AvvisiPagamento: dettaglio
    # ------------------------------

    async def dettaglio_avviso(
        self,
        cod_ipa: str,
        numero_avviso: str,
    ) -> DettaglioAvvisoResponse:
        req = DettaglioAvvisoRequest(
            cod_ipa_richiedente=cod_ipa,
            numero_avviso_dto={"numeroAvviso": numero_avviso},
        )

        data = await self._post(
            "/avvisiPagamento/v2/dettaglio",
            req.model_dump(by_alias=True),
        )

        return DettaglioAvvisoResponse.model_validate(data)

    # ------------------------------
    # AvvisiPagamento: esitoPagamento
    # ------------------------------

    async def esito_pagamento(
        self,
        cod_ipa: str,
        numero_avviso: str,
        iuv: Optional[str] = None,
        stato: Optional[str] = None,
    ) -> EsitoPagamentoResponse:
        req = EsitoPagamentoRequest(
            cod_ipa_richiedente=cod_ipa,
            numero_avviso_dto={"numeroAvviso": numero_avviso},
            iuv=iuv,
            stato=stato,
        )

        data = await self._post(
            "/avvisiPagamento/v2/esitoPagamento",
            req.model_dump(by_alias=True),
        )

        return EsitoPagamentoResponse.model_validate(data)


    async def ricerca_dovuti(
        self,
        cod_ipa: str,
        codice_servizio: str | None = None,
        codice_fiscale: str | None = None,
        iuv: str | None = None,
    ) -> RicercaDovutiResponse:

        req = RicercaDovutiRequest(
            cod_ipa_richiedente=cod_ipa,
            codice_servizio=codice_servizio,
            codice_fiscale=codice_fiscale,
            iuv=iuv,
        )

        data = await self._post(
            "/dovuti/v2/ricerca",
            req.model_dump(by_alias=True),
        )
        return RicercaDovutiResponse.model_validate(data)


    async def dettaglio_dovuto(
        self,
        cod_ipa: str,
        iuv: str,
    ) -> DettaglioDovutoResponse:

        req = DettaglioDovutoRequest(
            cod_ipa_richiedente=cod_ipa,
            iuv=iuv,
        )

        data = await self._post(
            "/dovuti/v2/dettaglio",
            req.model_dump(by_alias=True),
        )
        return DettaglioDovutoResponse.model_validate(data)


    async def esito_dovuto(
        self,
        cod_ipa: str,
        iuv: str,
        stato: str | None = None,
    ) -> EsitoDovutoResponse:

        req = EsitoDovutoRequest(
            cod_ipa_richiedente=cod_ipa,
            iuv=iuv,
            stato=stato,
        )

        data = await self._post(
            "/dovuti/v2/esito",
            req.model_dump(by_alias=True),
        )
        return EsitoDovutoResponse.model_validate(data)
    
    async def invia_dovuti(
        self,
        codice_ipa: str,
        codice_servizio: str,
        dovuti: list[InviaDovutoDto],
        transactional: bool = False,
    ):
        req = RichiestaInviaDovutiRestDto(
            codice_ipa=codice_ipa,
            codice_servizio=codice_servizio,
            dovuti=dovuti,
            transactional=transactional,
        )

        data = await self._post(
            "/dovuti/v2/invia",
            req.model_dump(by_alias=True),
        )
        return data  # Swagger spesso non definisce un vero response DTO

    async def invia_dovuto(
        self,
        codice_ipa: str,
        codice_servizio: str,
        dovuto: InviaDovutoDto,
    ) -> RispostaInviaDovutoDto:

        req = RichiestaInviaDovutoRestDto(
            codice_ipa=codice_ipa,
            codice_servizio=codice_servizio,
            dovuto=dovuto,
        )

        data = await self._post(
            "/dovuti/v1/inviaDovuto",
            req.model_dump(by_alias=True),
        )

        return RispostaInviaDovutoDto.model_validate(data)

    async def modifica_dovuto(
        self,
        codice_ipa: str,
        codice_servizio: str,
        dovuto: ModificaDovutoDto,
        operazione: OperazioneModifica,
    ):
        req = RichiestaModificaDovutiDto(
            codice_ipa=codice_ipa,
            codice_servizio=codice_servizio,
            dovuto_dto=dovuto,
            operazione=operazione,
        )

        data = await self._post(
            "/dovuti/v2/modifica",
            req.model_dump(by_alias=True),
        )
        return data
    
    
    async def modifica_importo_avviso(
        self,
        richiesta: RichiestaModificaImportoDto,
    ) -> RispostaModificaImportoDto:
        """
        Wrapper per PATCH /avvisiPagamento/v1/modificaImporto
        Permette la modifica dell'importo di un avviso (attivo).
        """
        data = await self._patch(
            "/avvisiPagamento/v1/modificaImporto",
            richiesta.model_dump(by_alias=True),
        )

        return RispostaModificaImportoDto.model_validate(data)
    
    
    async def info_pagamento_per_debito(
        self,
        richiesta: RichiestaInfoPagamentoDebitoDto,
    ) -> RispostaInfoPagamentoDebitoDto:
        """
        POST /pagamenti/v1/infoPerDebito
        Restituisce il dettaglio del pagamento partendo dalle chiavi del debito.
        """
        data = await self._post(
            "/pagamenti/v1/infoPerDebito",
            richiesta.model_dump(by_alias=True),
        )

        return RispostaInfoPagamentoDebitoDto.model_validate(data)
    
    
    async def info_per_numero_avviso_v2(
        self,
        richiesta: RichiestaInfoAvvisoPagamentoPerNumeroAvvisoDto,
    ) -> RispostaInfoAvvisoPagamentoPerNumeroAvvisoDto:
        """
        POST /avvisiPagamento/v2/infoPerNumeroAvviso
        Restituisce dettagli del debito tramite numero avviso.
        """
        data = await self._post(
            "/avvisiPagamento/v2/infoPerNumeroAvviso",
            richiesta.model_dump(by_alias=True),
        )

        return RispostaInfoAvvisoPagamentoPerNumeroAvvisoDto.model_validate(data)
    
    async def notifica_pagamento(
        self,
        richiesta: RichiestaNotificaPagamentoDto,
    ) -> RispostaNotificaPagamentoDto:
        """
        POST /notifiche/v1/pagamenti
        Import di ricevute telematiche.
        """
        data = await self._post(
            "/notifiche/v1/pagamenti",
            richiesta.model_dump(by_alias=True),
        )

        return RispostaNotificaPagamentoDto.model_validate(data)
    
    async def notifica_pagamento_v2(
        self,
        richiesta: RichiestaNotificaPagamentoV2Dto,
    ) -> RispostaNotificaPagamentoDto:
        """
        POST /notifiche/v2/pagamenti
        Import ricevute telematiche (versione estesa V2).
        """
        data = await self._post(
            "/notifiche/v2/pagamenti",
            richiesta.model_dump(by_alias=True),
        )

        return RispostaNotificaPagamentoDto.model_validate(data)