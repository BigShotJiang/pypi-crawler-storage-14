# jpparest-client

Client Python per il servizio SOAP SIB.jpparest.