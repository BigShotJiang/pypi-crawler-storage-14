# The version is updated automatically with bumpversion
# Do not update manually
__version__ = "4.1.1"