import contextlib
import io
import logging
import time
from pathlib import Path
from collections.abc import AsyncGenerator, Generator, Mapping

from lxml.etree import ElementBase, fromstring, Element
from lxml.html import HTMLParser
from rich.console import Console
from rich.live import Live
from rich.markdown import Markdown as RichMarkdown
from rich.text import Text
from typing_extensions import Any, Self

from mbcore.execute import run_async

logger = logging.getLogger(__name__)


def html(html_str: str, ensure_head_body: bool = True, **kw) -> ElementBase:
    parser = HTMLParser()
    value: ElementBase = fromstring(html_str, parser, **kw)
    if value is None:
        raise ValueError("Invalid HTML")
    if ensure_head_body and value.find('head') is None:
        value.insert(0, Element('head'))
    if ensure_head_body and value.find('body') is None:
        value.append(Element('body'))
    return value


# --- Improved agetlines from newer version ---

async def agetlines(data: Mapping[str, Any] | list[Any] | str | None = None, depth: int = 0) -> AsyncGenerator[str, None]:
    """Generate Markdown from JSON with headers based on depth."""
    indent = "  " * depth

    if isinstance(data, dict):
        header_depth = 3 if depth > 0 else 1

        if "name" in data:
            if depth == 0:
                yield "\n"
            title = f"\n{indent}{'#' * header_depth} {data['name']}"
            if "brief" in data and data["brief"]:
                title += f" - {data['brief']}"
            else:
                title += "\n"
            yield title

        # Simplified and corrected member processing
        if "members" in data and isinstance(data["members"], dict) and "brief" in data and data["brief"]:
            for member_name, member_info in data["members"].items():
                brief = member_info.get('brief', '')
                yield f"{indent}- **{member_name}**{f' - {brief}' if brief else ''}\n"

        if "doc" in data and data["doc"]:
            doc_lines = str(data["doc"]).split("\n")
            for line in doc_lines:
                if line.strip():
                    if line.startswith('@param'):
                        yield f"{indent}> **{line.strip()}**"
                    else:
                        yield f"{indent}> {line.strip()}"
            yield '\n'

        if "return_type" in data and data["return_type"]:
            yield f"{indent}**Returns:** `{data['return_type']}`\n"

        for key, value in data.items():
            # Skip keys that are already handled or duplicates
            if key in ["name", "brief", "doc", "return_type", "members", "project_urls"]:
                continue

            # For package info, just show key-value pairs as bullet points
            if isinstance(value, str) and value:
                # Handle description specially - it's often multi-line markdown/RST
                if key == "description":
                    # Clean up RST/markdown badges and directives that don't render well
                    import re
                    clean_desc = value
                    # Remove markdown image badges [![alt](url)](link)
                    clean_desc = re.sub(r'\[!\[.*?\]\(.*?\)\]\(.*?\)', '', clean_desc)
                    # Remove standalone markdown images ![alt](url)
                    clean_desc = re.sub(r'!\[.*?\]\(.*?\)', '', clean_desc)
                    # Remove HTML comments <!-- ... -->
                    clean_desc = re.sub(r'<!--.*?-->', '', clean_desc, flags=re.DOTALL)
                    # Remove RST image directives (badges, etc)
                    clean_desc = re.sub(r'\.\. image::.*?(?=\n\S|\n\n|\Z)', '', clean_desc, flags=re.DOTALL)
                    # Remove RST target directives
                    clean_desc = re.sub(r':target:.*', '', clean_desc)
                    # Remove banner lines like [====== name ======]
                    clean_desc = re.sub(r'\[=+.*?=+\]', '', clean_desc)
                    # Downgrade markdown headers so they don't compete with package headers
                    # # Header -> #### Header (h1 -> h4)
                    # ## Header -> ##### Header (h2 -> h5)
                    clean_desc = re.sub(r'^(#{1,3}) ', r'###\1 ', clean_desc, flags=re.MULTILINE)
                    # Remove excessive blank lines
                    clean_desc = re.sub(r'\n{3,}', '\n\n', clean_desc)
                    clean_desc = clean_desc.strip()

                    if clean_desc:
                        yield f"\n{indent}**Description:**\n"
                        for line in clean_desc.splitlines():
                            yield f"{indent}> {line}\n"
                        yield "\n"
                # Make URLs clickable
                elif key == "github_url" or "://" in value:
                    yield f"{indent}- **{key}**: [{value}]({value})\n"
                else:
                    yield f"{indent}- **{key}**: {value}\n"
            elif isinstance(value, dict) and key == "urls":
                yield f"{indent}- **{key}**:\n"
                for url_key, url_value in value.items():
                    if url_value and "://" in str(url_value):
                        yield f"{indent}  - **{url_key}**: [{url_value}]({url_value})\n"
                    elif url_value:
                        yield f"{indent}  - **{url_key}**: {url_value}\n"
            elif isinstance(value, dict) and key == "earliest_release":
                yield f"{indent}- **{key}**:\n"
                for sub_key, sub_value in value.items():
                    if sub_value:
                        yield f"{indent}  - **{sub_key}**: {sub_value}\n"
            elif isinstance(value, dict) and value:
                yield f"{indent}- **{key}**:\n"
                for sub_key, sub_value in value.items():
                    if sub_value:
                        yield f"{indent}  - **{sub_key}**: {sub_value}\n"
            elif isinstance(value, list) and value:
                # Handle matches specially - extract text field
                yield f"{indent}- **{key}**:\n"
                for item in value:
                    if isinstance(item, dict) and "text" in item:
                        yield f"{indent}  - {item['text']}\n"
                    else:
                        yield f"{indent}  - {item}\n"

    elif isinstance(data, list):
        for item in data:
            async for line in agetlines(item, depth):
                yield line
    elif isinstance(data, str):
        for line in data.splitlines(keepends=True):
            yield line


def getlines(data: Mapping[str, Any] | list[Any] | str | None = None, depth: int = 0) -> Generator[str, None, None]:
    """Sync wrapper for agetlines."""
    async def run_agetlines():
        lines = []
        async for line in agetlines(data, depth):
            lines.append(line)
        return lines
    return (line for line in run_async(run_agetlines()))


# --- Old sync MarkdownStream class ---

class MarkdownStream:
    """Sync streaming renderer using Rich Live display."""
    live: Live | None
    when = 0
    min_delay = 0.020
    live_window = 3  # Reduced to show output sooner

    def __init__(self, mdargs=None):
        self.printed = []
        self.mdargs = mdargs or {}
        self.live = Live(Text(""), refresh_per_second=30)
        self.live.start()

    def __del__(self):
        if self.live:
            with contextlib.suppress(Exception):
                self.live.stop()

    def update(self, text, final=False) -> None:
        now = time.time()
        should_render = final or now - self.when >= self.min_delay
        if not should_render:
            return
        self.when = now

        string_io = io.StringIO()
        console = Console(file=string_io, force_terminal=True)
        markdown = RichMarkdown(text, **self.mdargs)
        console.print(markdown)
        output = string_io.getvalue()

        lines = output.splitlines(keepends=True)
        num_lines = len(lines)

        if not final:
            num_lines -= self.live_window

        if (final or num_lines > 0) and self.live:
            num_printed = len(self.printed)
            show = num_lines - num_printed

            if show > 0:
                show_lines = lines[num_printed:num_lines]
                show_text = "".join(show_lines)
                show_text = Text.from_ansi(show_text)
                self.live.console.print(show_text)
                self.printed = lines[:num_lines]

        if final and self.live:
            self.live.update(Text(""))
            self.live.stop()
            self.live = None
        elif self.live:
            rest = lines[max(0, num_lines):]
            rest_text = "".join(rest)
            rest_text = Text.from_ansi(rest_text)
            self.live.update(rest_text)


# --- Markdown class with sync streaming + async wrapper ---

class Markdown:
    """Stream formatted JSON-like text to the terminal with live updates."""

    def __init__(self,
                 data=None,
                 mdargs=None,
                 style="default",
                 min_delay=0.05,
                 live_window=6,
                 line_delay=0.02,
                 **kwargs):
        self.data = data or {}
        self.mdargs = mdargs or {}
        self.style = style
        self.console = Console(style=self.style)
        self.min_delay = min_delay
        self.live_window = live_window
        self.line_delay = line_delay
        # For async streaming
        self._stream: MarkdownStream | None = None
        self._accumulated_text = ""

    def rich(self, show: bool = False, data=None, mdargs=None) -> RichMarkdown:
        """Render the markdown content using the Rich library."""
        mdargs = mdargs or self.mdargs
        data = data or self.data
        content = "".join(getlines(data))
        md = RichMarkdown(content, **mdargs)
        if show:
            self.console.print(md)
        return md

    def save(self, outfile: str, data=None) -> Self:
        """Save the markdown content to a file."""
        data = data or self.data
        content = "".join(getlines(data))
        if outfile and content:
            Path(outfile).write_text(content)
        return self

    def stream(self, speed_factor=40000, outfile: str | None = None) -> None:
        """Stream the markdown content dynamically based on its length."""
        content = "".join(getlines(self.data))
        if outfile:
            Path(outfile).write_text(content)

        content_length = len(content)
        if content_length == 0:
            return

        speed = max(0.01, min(0.1, speed_factor / content_length))
        speed /= 2
        refresh_speed = 1 / 20

        pm = MarkdownStream(mdargs=self.mdargs)

        for i in range(6, len(content)):
            pm.update(content[:i], final=False)
            time.sleep(speed * refresh_speed)

        pm.update(content, final=True)

    # --- Async API for mb search ---

    async def astream(self) -> Self:
        """Start async streaming mode. Returns self for chaining."""
        self._stream = MarkdownStream(mdargs=self.mdargs)
        self._accumulated_text = ""
        return self

    async def aput(self, item: dict | list | str) -> None:
        """Add an item to the stream, rendering line by line."""
        import asyncio
        if not self._stream:
            raise RuntimeError("Stream not started. Call astream() first.")

        # Stream line by line for smooth scrolling
        async for line in agetlines(item):
            self._accumulated_text += line
            self._stream.update(self._accumulated_text, final=False)
            await asyncio.sleep(self.line_delay)

    async def wait(self) -> None:
        """Finalize the stream."""
        if self._stream:
            self._stream.update(self._accumulated_text, final=True)
            self._stream = None

    async def aclose(self) -> None:
        """Close the stream."""
        await self.wait()

    @classmethod
    def from_json(cls, json_data, **kwargs) -> Self:
        return cls(data=json_data, **kwargs)


def recursive_read(path: str) -> dict[str, Any]:
    """Recursively read a file or directory returning a mapping of path -> content."""
    path_obj = Path(path)
    if path_obj.is_dir():
        result: dict[str, Any] = {}
        for file in path_obj.rglob("*"):
            if file.is_file():
                result[str(file)] = file.read_text()
        return result
    else:
        return {str(path_obj): path_obj.read_text()}
