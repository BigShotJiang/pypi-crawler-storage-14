import re
from pathlib import Path

import requests
from bs4 import BeautifulSoup

from mrender.md import Markdown
from lxml.etree import Element

def html_to_markdown_with_depth(html_or_element, depth: int = 0, max_depth: int = None) -> str:
    """Convert HTML string or element to Markdown.
    
    Args:
        html_or_element: Either an HTML string or an Element object
        depth: Current depth for indentation
        max_depth: Maximum depth (for compatibility, not used in current implementation)
    """
    if isinstance(html_or_element, str):
        # Parse HTML string using BeautifulSoup
        soup = BeautifulSoup(html_or_element, 'html.parser')
        return _element_to_markdown(soup, depth)
    else:
        # Assume it's an Element object
        return _element_to_markdown(html_or_element, depth)

def _element_to_markdown(element, depth: int = 0) -> str:
    """Recursively convert HTML element and its children to Markdown."""
    markdown_lines = []
    indent = ' ' * depth
    
    if hasattr(element, 'name') and element.name is not None:
        # Handle headers
        if element.name in ['h1', 'h2', 'h3', 'h4', 'h5', 'h6']:
            level = int(element.name[1])  # Get header level
            text = element.get_text(strip=True) if hasattr(element, 'get_text') else str(element)
            markdown_lines.append(f"{indent}{'#' * level} {text}\n")
        
        # Handle paragraphs
        elif element.name == 'p':
            text = element.get_text(strip=True) if hasattr(element, 'get_text') else str(element)
            markdown_lines.append(f"{indent}{text}\n")
        
        # Handle unordered lists
        elif element.name == 'ul':
            for li in element.find_all('li', recursive=False):
                markdown_lines.append(f"{indent}- {_element_to_markdown(li, depth + 2).strip()}\n")

        # Handle ordered lists
        elif element.name == 'ol':
            for i, li in enumerate(element.find_all('li', recursive=False), start=1):
                markdown_lines.append(f"{indent}{i}. {_element_to_markdown(li, depth + 2).strip()}\n")

        # Handle other tags (e.g., blockquotes, code blocks)
        elif element.name == 'blockquote':
            text = element.get_text(strip=True) if hasattr(element, 'get_text') else str(element)
            markdown_lines.append(f"{indent}> {text}\n")

        elif element.name == 'code':
            text = element.get_text(strip=True) if hasattr(element, 'get_text') else str(element)
            markdown_lines.append(f"{indent}```\n{text}\n```\n")

        # Handle other nested tags recursively
        else:
            for child in element.children if hasattr(element, 'children') else []:
                if hasattr(child, 'name') or isinstance(child, str):
                    result = _element_to_markdown(child, depth)
                    if result.strip():
                        markdown_lines.append(result)

    # If element has no tag name, treat it as text
    elif isinstance(element, str) and element.strip():
        markdown_lines.append(f"{indent}{element.strip()}\n")

    return ''.join(markdown_lines)

def display_markdown_hierarchically(markdown_text, max_depth):
    md = Markdown(markdown_text)
    md.stream(max_depth)


def cli(path, max_depth):
    if Path(path).exists():
        html = Path(path).read_text()
    elif requests.get(path).status_code == 200:
        html = requests.get(path, timeout=10).text

    markdown_output = html_to_markdown_with_depth(html, max_depth)



    display_markdown_hierarchically(markdown_output, max_depth)

if __name__ == "__main__":
    import sys
    if len(sys.argv) < 3:
        print("Usage: python web2md.py <path> <max_depth>")
        sys.exit(1)
    
    cli(sys.argv[1], int(sys.argv[2]))
    # # Sample HTML content
    # html_content = """
    # <html>
    #     <head><title>Sample Page</title></head>
    #     <body>
    #         <h1>Heading 1</h1>
    #         <p>This is a <strong>sample</strong> paragraph with <a href="https://example.com">a link</a>.</p>
    #         <div>
    #             <h2>Subheading</h2>
    #             <ul>
    #                 <li>First item</li>
    #                 <li>Second item</li>
    #             </ul>
    #         </div>
    #         <footer>
    #             <p>Footer content</p>
    #         </footer>
    #     </body>
    # </html>
    # """

    # max_depth = 3
    # markdown_output = html_to_markdown_with_depth(html_content, max_depth)

    # print("Markdown Output:")
    # print(markdown_output)

    # display_markdown_hierarchically(markdown_output, max_depth)import re

def extract_links(markdown_content):
    """Extract links from markdown content."""
    link_pattern = r'\[([^\]]+)\]\(([^\)]+)\)'
    links = re.findall(link_pattern, markdown_content)
    return [{"text": text, "url": url} for text, url in links]
