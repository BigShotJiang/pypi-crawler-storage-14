import asyncio
from collections.abc import AsyncGenerator
from typing import Any, Optional

from rich.console import Console

class MarkdownStreamer:
    """
    An asynchronous streamer that prints new lines to the console, creating
    a standard, scrollable log.

    This class uses an asyncio.Queue to buffer incoming lines and prints them
    using `console.print()`, preserving the terminal's scrollback history.

    Usage:
        console = Console()
        streamer = AsyncScrollingStreamer(console)
        # The try...finally is still best practice for graceful shutdown
        try:
            await streamer.start()
            await streamer.put("This is the first line.")
            await streamer.put("This is the second, and the first will scroll up.")
        finally:
            await streamer.stop()
    """
    def __init__(
        self,
        console: Optional[Console] = None,
    ):
        self.console = console or Console()
        self._queue: asyncio.Queue[str] = asyncio.Queue()
        self._print_task: Optional[asyncio.Task] = None
        self._started = False

    async def _print_loop(self) -> None:
        """The background task that consumes from the queue and prints to the console."""
        while True:
            try:
                # Wait for a line to appear in the queue
                line = await self._queue.get()
                self.console.print(line)
                self._queue.task_done()
            except asyncio.CancelledError:
                # The task was cancelled, so we exit the loop.
                break

    async def start(self) -> None:
        """Starts the background printing task."""
        if self._started:
            return

        self._print_task = asyncio.create_task(self._print_loop())
        self._started = True
        self.console.log("Scrolling streamer started.")

    async def put(self, line: str) -> None:
        """Puts a new line into the queue to be printed."""
        if not self._started:
            raise RuntimeError("Streamer has not been started. Please call .start() first.")
        await self._queue.put(line)

    async def stop(self) -> None:
        """Stops the background printing task gracefully."""
        if not self._started or not self._print_task:
            return

        # 1. Wait for all items in the queue to be printed.
        await self._queue.join()

        # 2. Cancel the background task.
        self._print_task.cancel()
        try:
            # Wait for the task to acknowledge the cancellation.
            await self._print_task
        except asyncio.CancelledError:
            pass # This is expected.

        self._started = False
        self.console.log("Scrolling streamer stopped.")

    # You can still add the __aenter__ and __aexit__ methods for convenience
    async def __aenter__(self) -> "MarkdownStreamer":
        await self.start()
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb) -> None:
        await self.stop()

class Markdown:
    def __init__(self, data: dict[str, Any] | list[Any] | str | None = None):
        self.data = data

    def __str__(self) -> str:
        from .md import getlines
        return "\n".join(getlines(self.data))
    
    def stream(self,*args, **kwargs) -> MarkdownStreamer:
        from mbcore.execute import run_async
        self.streamer = MarkdownStreamer()
        future = asyncio.Future()
        asyncio.create_task(self.streamer.put(self.data))
        future.set_result(self.streamer)
        return future
    
    
    def astream(self) -> MarkdownStreamer:
        return self.streamer

# --- Example Usage ---

async def main():
    console = Console()
    console.print("[bold]Demonstrating a SCROLLABLE async streamer.[/bold]")
    async with MarkdownStreamer(console) as streamer:
        await streamer.put("[green]Worker 1 starting...[/green]")
        await asyncio.sleep(0.5)
        await streamer.put("Worker 1: Processing step A.")
        await asyncio.sleep(0.5)
        await streamer.put("[blue]Worker 2 starting...[/blue]")
        await asyncio.sleep(0.5)
        await streamer.put("Worker 1: Processing step B.")
        await streamer.put("Worker 2: Fetching data.")
        await asyncio.sleep(0.5)
        await streamer.put("[bold green]Worker 1 finished.[/bold green]")
        await asyncio.sleep(0.5)
        await streamer.put("[bold blue]Worker 2 finished.[/bold blue]")

    console.print("\n[bold]Program finished. You can scroll up to see the full log.[/bold]")

if __name__ == "__main__":
    asyncio.run(main())