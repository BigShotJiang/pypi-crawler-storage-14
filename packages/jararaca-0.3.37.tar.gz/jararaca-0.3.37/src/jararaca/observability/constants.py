# SPDX-FileCopyrightText: 2025 Lucas S
#
# SPDX-License-Identifier: GPL-3.0-or-later

TRACEPARENT_KEY = "traceparent"

__all__ = ["TRACEPARENT_KEY"]
