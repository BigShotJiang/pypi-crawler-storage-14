"""Agents module for naive_knowledge_base."""

from .dependency_graph import generate_dependency_graph

__all__ = [
    "generate_dependency_graph",
]
