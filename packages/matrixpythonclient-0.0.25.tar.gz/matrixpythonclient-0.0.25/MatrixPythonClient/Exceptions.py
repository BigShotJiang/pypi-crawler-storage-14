

class UserAlreadyJoinedRoomException(Exception):
    pass
