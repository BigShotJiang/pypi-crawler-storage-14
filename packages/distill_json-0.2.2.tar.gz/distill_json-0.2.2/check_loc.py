import distill
import os
print(f"Distill location: {os.path.dirname(distill.__file__)}")
