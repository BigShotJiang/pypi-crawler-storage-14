This module was developed because in some cases, you want to filter Stock Move Lines by Scheduled Date.

It will be useful for you if you plan Waves from Stock Move Lines and you use Scheduled date to organize your pickings and Waves.
