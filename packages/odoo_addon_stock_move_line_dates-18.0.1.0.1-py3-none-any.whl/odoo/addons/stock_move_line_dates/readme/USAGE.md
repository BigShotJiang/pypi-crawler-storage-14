To use this module, you need to:

1. Go to Inventory > Overview
1. Select any Picking Type and click on 3 dot icon
1. Select Prepare Wave on the popup menu
1. Add Scheduled Date and Deadline columns
1. Filter by Scheduled Date or preselect Today / Tomorrow
1. Group by Scheduled Date or Deadline
