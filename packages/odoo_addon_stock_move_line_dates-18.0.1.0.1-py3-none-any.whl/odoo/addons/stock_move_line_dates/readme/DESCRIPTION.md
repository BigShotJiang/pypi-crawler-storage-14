This module extends the functionality of Stock Move Lines to support filter and grouping by Scheduled Date and Date Deadline and to allow you to plan Waves based on your Picking Schedule.
