For use this module you need:
1. Go to Inventory > Configuration > Settings
1. Activate Batch, Wave & Cluster Transfers