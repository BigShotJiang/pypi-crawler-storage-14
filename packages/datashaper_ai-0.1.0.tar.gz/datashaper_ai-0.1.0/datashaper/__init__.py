"""
DataShaper - Local-first deterministic data cleaning engine.
"""

__version__ = "0.1.0"

from datashaper.engine.crashguard_engine import CrashGuardEngine

__all__ = ["CrashGuardEngine"]
