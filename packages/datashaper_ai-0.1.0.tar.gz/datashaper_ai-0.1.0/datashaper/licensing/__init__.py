"""
DataShaper licensing system.
"""

from datashaper.licensing.validator import LicenseValidator

__all__ = ["LicenseValidator"]
