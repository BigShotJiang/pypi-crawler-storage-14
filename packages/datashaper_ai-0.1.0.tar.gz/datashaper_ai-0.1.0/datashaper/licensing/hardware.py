"""
Hardware fingerprinting for license binding.
"""
import hashlib
import platform
import uuid
from typing import Optional


class HardwareFingerprint:
    """Generate and verify hardware fingerprints."""
    
    @staticmethod
    def get_machine_id() -> str:
        """
        Generate a unique hardware fingerprint for this machine.
        
        Uses combination of:
        - MAC address (most stable)
        - Hostname
        - Platform info
        
        Returns:
            SHA256 hash of hardware identifiers
        """
        # Get MAC address (most reliable identifier)
        mac = uuid.getnode()
        mac_str = ':'.join(('%012X' % mac)[i:i+2] for i in range(0, 12, 2))
        
        # Get hostname
        hostname = platform.node()
        
        # Get platform info
        system = platform.system()
        machine = platform.machine()
        
        # Combine into fingerprint
        fingerprint_data = f"{mac_str}|{hostname}|{system}|{machine}"
        
        # Hash to create stable ID
        fingerprint = hashlib.sha256(fingerprint_data.encode()).hexdigest()
        
        return fingerprint[:32]  # First 32 chars
    
    @staticmethod
    def verify_machine_id(stored_id: str) -> bool:
        """
        Verify if the stored machine ID matches current hardware.
        
        Args:
            stored_id: Previously stored machine ID
            
        Returns:
            True if IDs match
        """
        current_id = HardwareFingerprint.get_machine_id()
        return current_id == stored_id
