"""
DataShaper engines - Polars (primary) and DuckDB (fallback).
"""

from datashaper.engine.crashguard_engine import CrashGuardEngine
from datashaper.engine.polars_engine import PolarsEngine
from datashaper.engine.duckdb_engine import DuckDBEngine

__all__ = ["CrashGuardEngine", "PolarsEngine", "DuckDBEngine"]
