import pytest
from backend.app.engines.polars_engine import PolarsEngine
import polars as pl

def test_polars_engine_initialization():
    """Test that PolarsEngine initializes correctly."""
    engine = PolarsEngine()
    assert engine is not None

def test_polars_deduplication():
    """Test basic deduplication logic."""
    data = {"col1": [1, 1, 2], "col2": ["a", "a", "b"]}
    df = pl.DataFrame(data)
    
    assert df.height == 3
    deduped = df.unique()
    assert deduped.height == 2
