"""
Test configuration and fixtures.
"""

import pytest
from pathlib import Path
import tempfile
import pandas as pd
from uuid import uuid4

from app.core.config import Settings
from app.storage.metadata_store import MetadataStore
from app.storage.file_storage import FileStorage


@pytest.fixture(scope="session")
def test_settings():
    """Create test settings."""
    with tempfile.TemporaryDirectory() as tmpdir:
        settings = Settings(
            debug=True,
            environment="test",
            duckdb_path=f"{tmpdir}/test.duckdb",
            upload_dir=f"{tmpdir}/uploads",
            processed_dir=f"{tmpdir}/processed",
            export_dir=f"{tmpdir}/exports",
            log_dir=f"{tmpdir}/logs",
        )
        settings.create_directories()
        yield settings


@pytest.fixture
def sample_dataframe():
    """Create sample DataFrame for testing."""
    return pd.DataFrame({
        "customer_id": [1, 2, 3, 4, 5, 1],  # Includes duplicate
        "name": ["John", "Jane", "Bob", "Alice", "Charlie", "John"],
        "age": [25, 30, None, 28, 35, 25],  # Includes null
        "email": ["john@test.com", "jane@test.com", "bob@test.com", 
                  "alice@test.com", "charlie@test.com", "john@test.com"],
        "purchase_amount": [100.0, 200.0, 150.0, None, 300.0, 100.0],
    })


@pytest.fixture
def sample_csv_file(tmp_path, sample_dataframe):
    """Create sample CSV file."""
    csv_path = tmp_path / "sample.csv"
    sample_dataframe.to_csv(csv_path, index=False)
    return csv_path


@pytest.fixture
def metadata_store(test_settings):
    """Create metadata store for testing."""
    store = MetadataStore(db_path=test_settings.duckdb_path)
    yield store
    # Cleanup handled by temporary directory


@pytest.fixture
def file_storage(test_settings):
    """Create file storage for testing."""
    return FileStorage(
        upload_dir=test_settings.upload_dir,
        processed_dir=test_settings.processed_dir,
        export_dir=test_settings.export_dir,
    )
