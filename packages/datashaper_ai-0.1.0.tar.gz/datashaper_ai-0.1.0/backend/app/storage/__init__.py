"""Storage layer for file and metadata management."""
