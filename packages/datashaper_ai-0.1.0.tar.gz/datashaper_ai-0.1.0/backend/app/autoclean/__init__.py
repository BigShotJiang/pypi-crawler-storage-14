"""AutoClean package - Rule-based batch data cleaning."""
