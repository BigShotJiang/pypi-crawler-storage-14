"""Domain models package."""
