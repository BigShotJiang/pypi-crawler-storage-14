"""Domain models and entities."""
