"""
Upload endpoint for file handling.
"""

from fastapi import APIRouter, UploadFile, File, HTTPException
from typing import List
import os
import shutil
import uuid

router = APIRouter()

# Temporary upload directory
UPLOAD_DIR = os.path.join(os.getcwd(), "uploads")
os.makedirs(UPLOAD_DIR, exist_ok=True)


@router.post("/upload")
async def upload_files(files: List[UploadFile] = File(...)):
    """
    Upload CSV files and return their server paths.
    """
    saved_paths = []
    
    for file in files:
        # Generate unique filename
        file_id = str(uuid.uuid4())[:8]
        filename = f"{file_id}_{file.filename}"
        file_path = os.path.join(UPLOAD_DIR, filename)
        
        # Save file
        with open(file_path, "wb") as buffer:
            shutil.copyfileobj(file.file, buffer)
        
        saved_paths.append(file_path)
    
    return {"files": saved_paths}
