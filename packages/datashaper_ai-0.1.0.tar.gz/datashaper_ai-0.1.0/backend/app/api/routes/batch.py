"""
Batch processing router (stub).
"""

from fastapi import APIRouter

router = APIRouter()

@router.post("/batch/upload")
async def upload_batch():
    """Upload batch files."""
    return {"status": "not_implemented"}

@router.get("/batch/status/{batch_id}")
async def get_batch_status(batch_id: str):
    """Get batch processing status."""
    return {"batch_id": batch_id, "status": "processing"}
