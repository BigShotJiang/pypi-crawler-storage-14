from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import Optional

router = APIRouter()

class UpdateInfo(BaseModel):
    version: str
    min_supported_version: str
    download_url: str
    release_notes: str
    force_update: bool = False

# In a real scenario, this would come from a database or config file
# For now, we hardcode the latest version info
LATEST_RELEASE = {
    "version": "3.0.1",  # Bumped version for testing
    "min_supported_version": "2.0.0",
    "download_url": "https://github.com/datashaper/core/releases/latest/download/DataShaperAI-Windows.zip",
    "release_notes": "Critical bug fixes and performance improvements.",
    "force_update": False
}

@router.get("/latest", response_model=UpdateInfo)
async def get_latest_version():
    """
    Get the latest available version of the application.
    Used by the desktop app to check for updates.
    """
    return LATEST_RELEASE
