"""
Pydantic Models - Request and Response schemas.
"""

from pydantic import BaseModel, Field
from typing import List, Dict, Optional, Any
from datetime import datetime


# Request Models

class CleanRequest(BaseModel):
    """Request to clean data."""
    files: List[str] = Field(..., description="List of file paths to clean")
    conservative: bool = Field(default=True, description="Use conservative mode")
    workers: int = Field(default=4, ge=1, le=16, description="Number of parallel workers")
    merge: bool = Field(default=True, description="Merge files into single dataset")
    flag_only: bool = Field(default=False, description="Flag issues only, don't fix")


class SchemaReconcileRequest(BaseModel):
    """Request to reconcile schemas."""
    files: Dict[str, str] = Field(..., description="Dict of filename -> file_path")
    fuzzy_threshold: float = Field(default=0.85, ge=0.0, le=1.0)


class SchemaDiffRequest(BaseModel):
    """Request to diff two schemas."""
    schema1: Dict[str, Any]
    schema2: Dict[str, Any]


class ReportRequest(BaseModel):
    """Request to generate report."""
    result_id: str = Field(..., description="Result ID from clean operation")
    format: str = Field(default="html", pattern="^(html|json)$")
    tier: str = Field(default="free", pattern="^(free|pro)$")


class LicenseValidateRequest(BaseModel):
    """Request to validate license."""
    license_key: str = Field(..., min_length=10)


class LicenseActivateRequest(BaseModel):
    """Request to activate license."""
    license_key: str = Field(..., min_length=10)
    email: str = Field(..., pattern=r"^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$")


# Response Models

class IssueResponse(BaseModel):
    """Detected issue."""
    issue_type: str
    severity: str
    description: str
    affected_items: List[str]
    fix_available: bool


class CleanResponse(BaseModel):
    """Response from clean operation."""
    result_id: str
    files_processed: int
    issues_found: int
    fixes_applied: int
    quality_score: float
    processing_time_seconds: float
    issues: List[IssueResponse]


class SchemaColumnResponse(BaseModel):
    """Schema column info."""
    name: str
    dtype: str
    nullable: bool
    constraints: Optional[Dict[str, Any]] = None
    lineage: Optional[List[str]] = None


class SchemaResponse(BaseModel):
    """Schema response."""
    name: str
    version: str
    columns: Dict[str, SchemaColumnResponse]
    created_at: str
    metadata: Dict[str, Any] = {}


class SchemaDriftResponse(BaseModel):
    """Schema drift response."""
    missing_columns: Dict[str, List[str]]
    extra_columns: Dict[str, List[str]]
    type_drifts: Dict[str, Dict[str, str]]
    drift_score: float


class SchemaReconcileResponse(BaseModel):
    """Schema reconciliation response."""
    unified_schema: SchemaResponse
    drift: SchemaDriftResponse
    confidence_score: float


class SchemaDiffResponse(BaseModel):
    """Schema diff response."""
    columns_added: List[str]
    columns_removed: List[str]
    type_changes: Dict[str, Dict[str, str]]
    constraint_changes: Dict[str, Any]
    version_change: tuple


class ReportResponse(BaseModel):
    """Report generation response."""
    report_url: Optional[str] = None
    report_data: Optional[Dict[str, Any]] = None
    format: str


class LicenseResponse(BaseModel):
    """License validation response."""
    valid: bool
    tier: str
    email: Optional[str] = None
    expires_at: Optional[str] = None
    features: Dict[str, bool] = {}


class ErrorResponse(BaseModel):
    """Error response."""
    error: str
    detail: Optional[str] = None
    code: Optional[str] = None
