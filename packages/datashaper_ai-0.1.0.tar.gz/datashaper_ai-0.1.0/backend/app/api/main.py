"""
FastAPI Application - Main entry point.

REST API for DataShaper AI with:
- Data cleaning endpoints
- Schema reconciliation
- Batch processing
- License validation
- Reporting
"""

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from contextlib import asynccontextmanager
import structlog

from app.api.routes import cleaning, schema, reporting, batch, licensing, payments, updates, auth, upload
from app.core.logging_config import setup_logging


@asynccontextmanager
async def lifespan(app: FastAPI):
    setup_logging()
    logger = structlog.get_logger()
    logger.info("Starting up DataShaper AI API")
    yield
    logger.info("Shutting down DataShaper AI API")

app = FastAPI(
    title="DataShaper AI API",
    version="3.0.0",
    lifespan=lifespan
)

# Include routers
app.include_router(upload.router, prefix="/api/v1/upload", tags=["upload"])
app.include_router(cleaning.router, prefix="/api/v1/cleaning", tags=["cleaning"])
app.include_router(schema.router, prefix="/api/v1/schema", tags=["schema"])
app.include_router(reporting.router, prefix="/api/v1/reporting", tags=["reporting"])
app.include_router(batch.router, prefix="/api/v1/batch", tags=["batch"])
app.include_router(licensing.router, prefix="/api/v1/licensing", tags=["licensing"])
app.include_router(payments.router, prefix="/api/v1/payments", tags=["payments"])
app.include_router(updates.router, prefix="/api/v1/updates", tags=["updates"])
app.include_router(auth.router, prefix="/api/v1/auth", tags=["auth"])

@app.get("/health")
async def health_check():
    """Health check endpoint."""
    return {"status": "healthy"}


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(
        "app.api.main:app",
        host="0.0.0.0",
        port=8000,
        reload=True,
        log_level="info"
    )
