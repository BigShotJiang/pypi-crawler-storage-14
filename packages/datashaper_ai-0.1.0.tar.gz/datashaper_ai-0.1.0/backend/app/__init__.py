"""
DataShaper AI - Core Application Package

A production-ready data automation and transformation platform with autonomous multi-agent workflow.
"""

__version__ = "0.1.0"
__author__ = "DataShaper AI Team"
