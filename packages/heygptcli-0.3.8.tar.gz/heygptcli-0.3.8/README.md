# heygpt cli/ui

[https://github.com/Rishang/heygpt](https://github.com/Rishang/heygpt)