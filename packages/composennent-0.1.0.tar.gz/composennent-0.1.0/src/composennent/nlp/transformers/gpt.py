"""GPT (Generative Pre-trained Transformer) implementation."""

import torch
import torch.nn as nn
from typing import Optional
from composennent.basic.decoder import Decoder
from composennent.attention import causal_mask


class GPT(nn.Module):
    """GPT: Decoder-only Transformer for autoregressive language modeling.

    Implements a GPT-style architecture with stacked decoder layers,
    token embeddings, learned positional embeddings, and weight tying
    between the input embeddings and output projection.

    Args:
        vocab_size: Size of the vocabulary.
        latent_dim: Dimension of the model (embedding size).
        num_heads: Number of attention heads per layer.
        num_layers: Number of decoder layers.
        max_seq_len: Maximum sequence length. Defaults to 512.
        drop_out: Dropout probability. Defaults to 0.1.
        mlp_ratio: MLP expansion ratio for decoder layers. Defaults to 4.

    Example:
        >>> model = GPT(
        ...     vocab_size=50257,
        ...     latent_dim=768,
        ...     num_heads=12,
        ...     num_layers=12,
        ... )
        >>> logits = model(input_ids)  # (batch, seq_len, vocab_size)

    Note:
        Uses weight tying between token embeddings and language model head
        for improved parameter efficiency.
    """

    def __init__(
        self,
        vocab_size: int,
        latent_dim: int,
        num_heads: int,
        num_layers: int,
        max_seq_len: int = 512,
        drop_out: float = 0.1,
        mlp_ratio: int = 4,
    ) -> None:
        super().__init__()
        self.latent_dim = latent_dim

        self.token_embedding = nn.Embedding(vocab_size, latent_dim)
        self.position_embedding = nn.Embedding(max_seq_len, latent_dim)
        self.dropout = nn.Dropout(drop_out)

        self.layers = nn.ModuleList([
            Decoder(latent_dim, num_heads, drop_out, mlp_ratio)
            for _ in range(num_layers)
        ])

        self.ln_f = nn.LayerNorm(latent_dim)
        self.lm_head = nn.Linear(latent_dim, vocab_size, bias=False)

        self.lm_head.weight = self.token_embedding.weight

    def forward(
        self,
        input_ids: torch.Tensor,
        key_padding_mask: Optional[torch.Tensor] = None,
    ) -> torch.Tensor:
        """Forward pass for language modeling.

        Args:
            input_ids: Token indices of shape (batch, seq_len).
            key_padding_mask: Optional mask for padded positions.
                Shape (batch, seq_len), True indicates padding.

        Returns:
            Logits over vocabulary of shape (batch, seq_len, vocab_size).
        """
        batch_size, seq_len = input_ids.shape
        positions = torch.arange(seq_len, device=input_ids.device).unsqueeze(0)

        x = self.token_embedding(input_ids) + self.position_embedding(positions)
        x = self.dropout(x)

        # Generate causal mask once for all layers
        mask = causal_mask(seq_len, x.device)

        for layer in self.layers:
            x = layer(x, memory=None, tgt_mask=mask, tgt_key_padding_mask=key_padding_mask)

        x = self.ln_f(x)
        logits = self.lm_head(x)

        return logits