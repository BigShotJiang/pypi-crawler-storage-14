"""Operation widget package."""

from .registry import get_registered_operations

__all__ = ["get_registered_operations"]
