"""Processing operations package."""

from ..ui.widgets.operations.registry import get_registered_operations

__all__ = ["get_registered_operations"]
