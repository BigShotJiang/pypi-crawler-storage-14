"""Base class for exceptions in the terminaltexteffects package."""


class TerminalTextEffectsError(Exception):
    """Base class for exceptions in the terminaltexteffects package."""
