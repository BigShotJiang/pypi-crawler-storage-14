# BoundResourceKind


## Enum

* `ORGANIZATION` (value: `'organization'`)

* `WORKSPACE` (value: `'workspace'`)

* `PROJECT` (value: `'project'`)

* `DATA_PLANE` (value: `'data_plane'`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


