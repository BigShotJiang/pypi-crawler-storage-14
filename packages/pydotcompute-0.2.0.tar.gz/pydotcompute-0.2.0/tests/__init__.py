"""
PyDotCompute test suite.
"""
