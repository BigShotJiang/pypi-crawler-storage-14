/** 
    THIS IS AHJO SQL SCRIPT TEMPLATE 
    ================================
    USE THIS TEMPLATE AS AN EXAMPLE
    WHEN CREATING YOUR OWN SCRIPTS.

    NAMING CONVENTION:
    <schema>.<object name>.sql
*/

-- First, truncate table

/**
TRUNCATE TABLE schema.tableNAme


-- Second, perform data insert


INSERT INTO schema.tableNAme (col1, col2) VALUES (1, 'test')
*/