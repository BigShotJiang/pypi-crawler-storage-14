/*
    THIS IS AHJO SQL SCRIPT TEMPLATE (MSSQL)
    ================================
    USE THIS TEMPLATE AS AN EXAMPLE
    WHEN CREATING YOUR OWN SCRIPTS.
*/
/*

-- Examples of creating database users

CREATE USER [AHJO_USER] FOR LOGIN AHJO_LOGIN WITH DEFAULT_SCHEMA=[dbo]

IF DATABASE_PRINCIPAL_ID('$(example_user_name)') IS NULL
    CREATE USER [$(example_user_name)]
    FROM EXTERNAL PROVIDER

GO

*/