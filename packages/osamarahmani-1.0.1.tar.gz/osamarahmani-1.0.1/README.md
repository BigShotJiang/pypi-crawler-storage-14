# osamarahmani

Simple package providing public profile information for Osama Rahmani.

## Usage

```python
import osamarahmani

print(osamarahmani.name)
print(osamarahmani.role)
print(osamarahmani.profile)
