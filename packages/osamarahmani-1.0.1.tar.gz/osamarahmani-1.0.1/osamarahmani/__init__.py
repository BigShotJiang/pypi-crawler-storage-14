name = "Osama Rahmani"
gmail = ["osamrahmani.tech@gmail.com", "armanmallik168@gmail.com"]
phone = "7631406611"
website = "https://osamrahmani.tech"
role = "Full-Stack Developer"

profile = {
    "name": name,
    "gmail": gmail,
    "phone": phone,
    "website": website,
    "role": role
}
