# Icon files go here
# - idle.png
# - recording.png  
# - processing.png
#
# If no icons are present, system theme icons or 
# standard Qt icons will be used as fallback.
