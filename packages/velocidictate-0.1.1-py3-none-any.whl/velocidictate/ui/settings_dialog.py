"""
Settings dialog for VelociDictate.
Tabbed interface for configuration.
"""
import os
import webbrowser
from PyQt6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QTabWidget, QWidget,
    QLabel, QLineEdit, QComboBox, QCheckBox, QPushButton,
    QFormLayout, QFileDialog, QGroupBox, QKeySequenceEdit, QDoubleSpinBox,
    QTextEdit, QMessageBox, QListWidget, QListWidgetItem
)
from PyQt6.QtGui import QKeySequence
from PyQt6.QtCore import Qt, QThread, pyqtSignal
from velocidictate.ui.config import Config
from velocidictate.refinement.claude import (
    get_vocabularies_dir,
    list_available_vocabularies,
    download_vocabularies
)


class DownloadThread(QThread):
    """Background thread for downloading vocabularies."""
    progress = pyqtSignal(str)
    finished = pyqtSignal(bool, str)

    def run(self):
        success, message = download_vocabularies(progress_callback=self.progress.emit)
        self.finished.emit(success, message)


class SettingsDialog(QDialog):
    """Settings dialog with tabbed interface."""

    def __init__(self, config: Config, parent=None):
        super().__init__(parent)
        self.config = config
        self.setWindowTitle("VelociDictate Settings")
        self.setMinimumWidth(550)
        self.setMinimumHeight(500)
        self._setup_ui()
        self._load_settings()

    def _setup_ui(self):
        """Setup the dialog UI."""
        layout = QVBoxLayout(self)
        self.tabs = QTabWidget()
        layout.addWidget(self.tabs)

        # Create tabs
        self.tabs.addTab(self._create_api_tab(), "API Keys")
        self.tabs.addTab(self._create_whisper_tab(), "Whisper")
        self.tabs.addTab(self._create_wake_word_tab(), "Wake Word")
        self.tabs.addTab(self._create_output_tab(), "Output")
        self.tabs.addTab(self._create_vocabulary_tab(), "Vocabulary")
        self.tabs.addTab(self._create_hotkey_tab(), "Hotkeys")

        # Buttons
        button_layout = QHBoxLayout()
        button_layout.addStretch()
        btn_cancel = QPushButton("Cancel")
        btn_cancel.clicked.connect(self.reject)
        button_layout.addWidget(btn_cancel)
        btn_save = QPushButton("Save")
        btn_save.clicked.connect(self._save_settings)
        btn_save.setDefault(True)
        button_layout.addWidget(btn_save)
        layout.addLayout(button_layout)

    def _create_api_tab(self) -> QWidget:
        """Create API keys tab."""
        widget = QWidget()
        layout = QVBoxLayout(widget)

        # Claude API
        claude_group = QGroupBox("Anthropic Claude")
        claude_layout = QFormLayout(claude_group)
        self.edit_claude_key = QLineEdit()
        self.edit_claude_key.setEchoMode(QLineEdit.EchoMode.Password)
        self.edit_claude_key.setPlaceholderText("sk-ant-...")
        claude_layout.addRow("API Key:", self.edit_claude_key)
        layout.addWidget(claude_group)

        # OpenAI API (optional)
        openai_group = QGroupBox("OpenAI (Optional - for Whisper API fallback)")
        openai_layout = QFormLayout(openai_group)
        self.edit_openai_key = QLineEdit()
        self.edit_openai_key.setEchoMode(QLineEdit.EchoMode.Password)
        self.edit_openai_key.setPlaceholderText("sk-...")
        openai_layout.addRow("API Key:", self.edit_openai_key)
        layout.addWidget(openai_group)

        note = QLabel("Note: API keys can also be set via environment variables\n"
                      "(ANTHROPIC_API_KEY, OPENAI_API_KEY)")
        note.setStyleSheet("color: gray; font-size: 11px;")
        layout.addWidget(note)
        layout.addStretch()
        return widget

    def _create_whisper_tab(self) -> QWidget:
        """Create Whisper settings tab."""
        widget = QWidget()
        layout = QVBoxLayout(widget)
        form = QFormLayout()

        self.combo_whisper_mode = QComboBox()
        self.combo_whisper_mode.addItems(["local", "api"])
        form.addRow("Mode:", self.combo_whisper_mode)

        self.combo_whisper_model = QComboBox()
        self.combo_whisper_model.addItems(["tiny", "base", "small", "medium", "large-v3"])
        form.addRow("Model:", self.combo_whisper_model)

        self.combo_device = QComboBox()
        self.combo_device.addItems(["cpu", "cuda", "auto"])
        form.addRow("Device:", self.combo_device)

        layout.addLayout(form)

        info_group = QGroupBox("Model Information")
        info_layout = QVBoxLayout(info_group)
        model_info = QLabel(
            "tiny: ~75MB, fastest, lower accuracy\n"
            "base: ~140MB, fast, fair accuracy\n"
            "small: ~460MB, fast, good accuracy (recommended)\n"
            "medium: ~1.5GB, moderate speed, high accuracy\n"
            "large-v3: ~3GB, slower, highest accuracy"
        )
        model_info.setStyleSheet("font-size: 11px;")
        info_layout.addWidget(model_info)
        layout.addWidget(info_group)
        layout.addStretch()
        return widget

    def _create_wake_word_tab(self) -> QWidget:
        """Create Wake Word / Hands-Free settings tab."""
        widget = QWidget()
        layout = QVBoxLayout(widget)

        # Main settings
        settings_group = QGroupBox("Hands-Free Dictation")
        settings_layout = QFormLayout(settings_group)

        self.edit_start_phrase = QLineEdit()
        self.edit_start_phrase.setPlaceholderText("start now")
        settings_layout.addRow("Start Phrase:", self.edit_start_phrase)

        self.edit_end_phrase = QLineEdit()
        self.edit_end_phrase.setPlaceholderText("stop now")
        settings_layout.addRow("End Phrase:", self.edit_end_phrase)

        self.spin_chunk_duration = QDoubleSpinBox()
        self.spin_chunk_duration.setRange(1.0, 5.0)
        self.spin_chunk_duration.setSingleStep(0.5)
        self.spin_chunk_duration.setSuffix(" seconds")
        self.spin_chunk_duration.setToolTip("How often to check for wake words (smaller = more responsive, more CPU)")
        settings_layout.addRow("Detection Window:", self.spin_chunk_duration)

        self.spin_sensitivity = QDoubleSpinBox()
        self.spin_sensitivity.setRange(0.5, 1.0)
        self.spin_sensitivity.setSingleStep(0.1)
        self.spin_sensitivity.setToolTip("Lower = stricter matching, Higher = more lenient")
        settings_layout.addRow("Sensitivity:", self.spin_sensitivity)

        layout.addWidget(settings_group)

        # Info
        info_group = QGroupBox("How It Works")
        info_layout = QVBoxLayout(info_group)
        info_text = QLabel(
            "Hands-free mode uses the tiny Whisper model to continuously\n"
            "listen for your wake words.\n\n"
            "1. Say your start phrase to begin recording\n"
            "2. Speak your dictation\n"
            "3. Say your end phrase to stop and process\n\n"
            "The wake phrases are stripped from the final output.\n\n"
            "Enable hands-free mode from the system tray menu."
        )
        info_text.setStyleSheet("font-size: 11px;")
        info_layout.addWidget(info_text)
        layout.addWidget(info_group)

        # Suggested phrases
        suggestions_group = QGroupBox("Suggested Phrases")
        suggestions_layout = QVBoxLayout(suggestions_group)
        suggestions_text = QLabel(
            "Good start phrases: 'begin phrase', 'start dictation', 'hey veloci'\n"
            "Good end phrases: 'end phrase', 'stop dictation', 'that's all'\n\n"
            "Choose phrases that are unlikely to appear in normal speech\n"
            "and easy to pronounce clearly."
        )
        suggestions_text.setStyleSheet("font-size: 11px; color: gray;")
        suggestions_layout.addWidget(suggestions_text)
        layout.addWidget(suggestions_group)

        layout.addStretch()
        return widget

    def _create_output_tab(self) -> QWidget:
        """Create output settings tab."""
        widget = QWidget()
        layout = QVBoxLayout(widget)

        # Auto-paste option (most important for hands-free)
        self.check_auto_paste = QCheckBox("Auto-paste after transcription")
        self.check_auto_paste.setToolTip("Automatically paste transcription into the active window")
        layout.addWidget(self.check_auto_paste)

        self.check_notifications = QCheckBox("Show notifications")
        layout.addWidget(self.check_notifications)

        # Description
        desc_group = QGroupBox("Auto-Paste Mode")
        desc_layout = QVBoxLayout(desc_group)
        desc = QLabel(
            "When enabled, transcriptions are automatically pasted\n"
            "into whatever window/text field is currently focused.\n\n"
            "Perfect for hands-free dictation:\n"
            "1. Focus on any text field (email, chat, IDE, etc.)\n"
            "2. Say 'start now' to begin dictating\n"
            "3. Say 'stop now' to transcribe and paste\n"
            "4. Repeat for multiple paragraphs!\n\n"
            "Requires: pyautogui or pynput package"
        )
        desc.setStyleSheet("font-size: 11px;")
        desc_layout.addWidget(desc)
        layout.addWidget(desc_group)
        layout.addStretch()
        return widget

    def _create_vocabulary_tab(self) -> QWidget:
        """Create vocabulary settings tab with vocabulary manager."""
        widget = QWidget()
        layout = QVBoxLayout(widget)

        # === DOMAIN SELECTION ===
        domain_group = QGroupBox("Domain Preset")
        domain_layout = QVBoxLayout(domain_group)

        domain_form = QFormLayout()
        self.combo_domain = QComboBox()
        self.combo_domain.addItems([
            "networking",
            "development",
            "it-general",
            "project-management",
            "creative-writing",
            "general"
        ])
        self.combo_domain.currentTextChanged.connect(self._on_domain_changed)
        domain_form.addRow("Domain:", self.combo_domain)
        domain_layout.addLayout(domain_form)

        # Domain description (updates dynamically)
        self.lbl_domain_desc = QLabel()
        self.lbl_domain_desc.setWordWrap(True)
        self.lbl_domain_desc.setStyleSheet("color: gray; font-size: 11px; padding: 5px;")
        domain_layout.addWidget(self.lbl_domain_desc)

        layout.addWidget(domain_group)

        # === INSTALLED VOCABULARIES ===
        installed_group = QGroupBox("Installed Vocabulary Packs")
        installed_layout = QVBoxLayout(installed_group)

        self.list_vocabularies = QListWidget()
        self.list_vocabularies.setMaximumHeight(80)
        self.list_vocabularies.setStyleSheet("font-size: 11px;")
        installed_layout.addWidget(self.list_vocabularies)

        # Refresh and download buttons
        btn_layout = QHBoxLayout()

        self.btn_refresh_vocabs = QPushButton("↻ Refresh")
        self.btn_refresh_vocabs.clicked.connect(self._refresh_vocabulary_list)
        btn_layout.addWidget(self.btn_refresh_vocabs)

        self.btn_download_vocabs = QPushButton("📥 Download Vocabulary Packs")
        self.btn_download_vocabs.clicked.connect(self._download_vocabularies)
        self.btn_download_vocabs.setStyleSheet("font-weight: bold;")
        btn_layout.addWidget(self.btn_download_vocabs)

        btn_layout.addStretch()
        installed_layout.addLayout(btn_layout)

        self.lbl_download_status = QLabel("")
        self.lbl_download_status.setStyleSheet("font-size: 11px; color: gray;")
        installed_layout.addWidget(self.lbl_download_status)

        layout.addWidget(installed_group)

        # === CUSTOM VOCABULARY FILE ===
        vocab_group = QGroupBox("Additional Custom Vocabulary")
        vocab_layout = QVBoxLayout(vocab_group)

        file_layout = QHBoxLayout()
        self.edit_vocab_file = QLineEdit()
        self.edit_vocab_file.setPlaceholderText("Path to additional vocabulary file...")
        self.edit_vocab_file.textChanged.connect(self._on_vocab_file_changed)
        file_layout.addWidget(self.edit_vocab_file)

        btn_browse = QPushButton("Browse...")
        btn_browse.clicked.connect(self._browse_vocab_file)
        file_layout.addWidget(btn_browse)

        btn_preview = QPushButton("Preview")
        btn_preview.clicked.connect(self._preview_vocab_file)
        file_layout.addWidget(btn_preview)

        vocab_layout.addLayout(file_layout)

        # Vocabulary file stats
        self.lbl_vocab_stats = QLabel("No custom vocabulary loaded")
        self.lbl_vocab_stats.setStyleSheet("color: gray; font-size: 11px;")
        vocab_layout.addWidget(self.lbl_vocab_stats)

        layout.addWidget(vocab_group)

        # === VOCABULARY PREVIEW ===
        preview_group = QGroupBox("Vocabulary Preview")
        preview_layout = QVBoxLayout(preview_group)

        self.txt_vocab_preview = QTextEdit()
        self.txt_vocab_preview.setReadOnly(True)
        self.txt_vocab_preview.setMaximumHeight(80)
        self.txt_vocab_preview.setStyleSheet("font-family: monospace; font-size: 10px;")
        self.txt_vocab_preview.setPlaceholderText("Select a vocabulary file and click Preview to see contents...")
        preview_layout.addWidget(self.txt_vocab_preview)

        layout.addWidget(preview_group)

        # === HOW IT WORKS (compact) ===
        help_group = QGroupBox("Vocabulary File Format")
        help_layout = QVBoxLayout(help_group)

        help_text = QLabel(
            "Each line: <b>CorrectTerm, misheard1, misheard2, ...</b><br>"
            "Examples: <code>OSPF, oh SPF, OSP F</code> · <code>Kubernetes, K 8 S, kube</code>"
        )
        help_text.setTextFormat(Qt.TextFormat.RichText)
        help_text.setStyleSheet("font-size: 10px;")
        help_layout.addWidget(help_text)

        layout.addWidget(help_group)

        # Initialize
        self._on_domain_changed(self.combo_domain.currentText())
        self._refresh_vocabulary_list()

        return widget

    def _refresh_vocabulary_list(self):
        """Refresh the list of installed vocabularies."""
        self.list_vocabularies.clear()

        vocabs = list_available_vocabularies()

        if not vocabs:
            item = QListWidgetItem("No vocabulary packs installed. Click 'Download' to get started.")
            item.setForeground(Qt.GlobalColor.gray)
            self.list_vocabularies.addItem(item)
        else:
            for v in vocabs:
                item = QListWidgetItem(f"✓ {v['name']} ({v['term_count']} terms)")
                item.setData(Qt.ItemDataRole.UserRole, v['path'])
                self.list_vocabularies.addItem(item)

    def _download_vocabularies(self):
        """Download vocabulary packs from GitHub."""
        self.btn_download_vocabs.setEnabled(False)
        self.btn_download_vocabs.setText("Downloading...")
        self.lbl_download_status.setText("Starting download...")
        self.lbl_download_status.setStyleSheet("font-size: 11px; color: blue;")

        self.download_thread = DownloadThread()
        self.download_thread.progress.connect(self._on_download_progress)
        self.download_thread.finished.connect(self._on_download_finished)
        self.download_thread.start()

    def _on_download_progress(self, message: str):
        """Handle download progress updates."""
        self.lbl_download_status.setText(message)

    def _on_download_finished(self, success: bool, message: str):
        """Handle download completion."""
        self.btn_download_vocabs.setEnabled(True)
        self.btn_download_vocabs.setText("📥 Download Vocabulary Packs")

        if success:
            self.lbl_download_status.setText(message)
            self.lbl_download_status.setStyleSheet("font-size: 11px; color: green;")
            self._refresh_vocabulary_list()
        else:
            self.lbl_download_status.setText(message)
            self.lbl_download_status.setStyleSheet("font-size: 11px; color: red;")
            QMessageBox.warning(self, "Download Failed", message)

    def _on_domain_changed(self, domain: str):
        """Update domain description when selection changes."""
        descriptions = {
            "networking": (
                "Routing protocols (BGP, OSPF, EIGRP), switching (VLANs, STP), "
                "firewalls, wireless, QoS, and vendor terminology (Cisco, Juniper, Arista)."
            ),
            "development": (
                "Programming languages, frameworks (React, Django), databases, "
                "cloud platforms (AWS, GCP, Azure), containers, and CI/CD."
            ),
            "it-general": (
                "Operating systems, Active Directory, helpdesk terminology, "
                "hardware, virtualization (VMware, Hyper-V), and troubleshooting."
            ),
            "project-management": (
                "Agile/Scrum (sprint, backlog), SAFe, Kanban, stakeholder terms, "
                "meeting terminology, and PM tools (Jira, Confluence)."
            ),
            "creative-writing": (
                "Latin phrases (in medias res, carpe diem), Shakespeare references, "
                "literary terms, classical allusions, and publishing terminology."
            ),
            "general": (
                "Basic technical correction without domain-specific optimization. "
                "Use when working across multiple domains."
            ),
        }
        self.lbl_domain_desc.setText(descriptions.get(domain, ""))

    def _on_vocab_file_changed(self, path: str):
        """Update stats when vocabulary file path changes."""
        if not path or not os.path.exists(path):
            self.lbl_vocab_stats.setText("No custom vocabulary loaded")
            self.lbl_vocab_stats.setStyleSheet("color: gray; font-size: 11px;")
            return

        try:
            with open(path, 'r', encoding='utf-8') as f:
                lines = f.readlines()

            # Count non-comment, non-empty lines
            term_lines = [l for l in lines if l.strip() and not l.strip().startswith('#')]
            total_terms = len(term_lines)

            # Count unique primary terms (first item before comma)
            primary_terms = set()
            for line in term_lines:
                if ',' in line:
                    primary_terms.add(line.split(',')[0].strip().lower())
                else:
                    primary_terms.add(line.strip().lower())

            self.lbl_vocab_stats.setText(
                f"✓ Loaded: {total_terms} entries, {len(primary_terms)} unique terms"
            )
            self.lbl_vocab_stats.setStyleSheet("color: green; font-size: 11px;")
        except Exception as e:
            self.lbl_vocab_stats.setText(f"⚠ Error reading file: {str(e)[:50]}")
            self.lbl_vocab_stats.setStyleSheet("color: red; font-size: 11px;")

    def _preview_vocab_file(self):
        """Show preview of vocabulary file contents."""
        path = self.edit_vocab_file.text()

        if not path:
            self.txt_vocab_preview.setPlainText(
                "No vocabulary file selected.\n\n"
                "Browse to select a .txt vocabulary file."
            )
            return

        if not os.path.exists(path):
            self.txt_vocab_preview.setPlainText(f"File not found:\n{path}")
            return

        try:
            with open(path, 'r', encoding='utf-8') as f:
                lines = f.readlines()

            # Show first 15 non-comment lines
            preview_lines = []
            count = 0
            for line in lines:
                if line.strip() and not line.strip().startswith('#'):
                    preview_lines.append(line.rstrip())
                    count += 1
                    if count >= 15:
                        break

            total_terms = len([l for l in lines if l.strip() and not l.strip().startswith('#')])

            preview_text = '\n'.join(preview_lines)
            if total_terms > 15:
                preview_text += f"\n\n... and {total_terms - 15} more entries"

            self.txt_vocab_preview.setPlainText(preview_text)

        except Exception as e:
            self.txt_vocab_preview.setPlainText(f"Error reading file:\n{str(e)}")

    def _browse_vocab_file(self):
        """Open file browser for vocabulary file."""
        path, _ = QFileDialog.getOpenFileName(
            self, "Select Vocabulary File", "",
            "Text Files (*.txt);;All Files (*)"
        )
        if path:
            self.edit_vocab_file.setText(path)

    def _create_hotkey_tab(self) -> QWidget:
        """Create hotkey settings tab."""
        widget = QWidget()
        layout = QVBoxLayout(widget)
        form = QFormLayout()

        self.edit_hotkey = QKeySequenceEdit()
        form.addRow("Record Hotkey:", self.edit_hotkey)
        layout.addLayout(form)

        note = QLabel(
            "Click the hotkey field and press your desired key combination.\n"
            "This hotkey will start/stop recording from anywhere.\n\n"
            "You can also click the tray icon to toggle recording,\n"
            "or use hands-free mode with voice commands."
        )
        note.setStyleSheet("color: gray;")
        layout.addWidget(note)
        layout.addStretch()
        return widget

    def _load_settings(self):
        """Load current settings into UI."""
        # API
        self.edit_claude_key.setText(self.config.get("api", "claude_key", ""))
        self.edit_openai_key.setText(self.config.get("api", "openai_key", ""))

        # Whisper
        self.combo_whisper_mode.setCurrentText(self.config.get("whisper", "mode", "local"))
        self.combo_whisper_model.setCurrentText(self.config.get("whisper", "model", "small"))
        self.combo_device.setCurrentText(self.config.get("whisper", "device", "cpu"))

        # Wake Word
        self.edit_start_phrase.setText(self.config.get("wake_word", "start_phrase", "start now"))
        self.edit_end_phrase.setText(self.config.get("wake_word", "end_phrase", "stop now"))
        self.spin_chunk_duration.setValue(self.config.get("wake_word", "chunk_duration", 2.0))
        self.spin_sensitivity.setValue(self.config.get("wake_word", "sensitivity", 0.7))

        # Output
        self.check_auto_paste.setChecked(self.config.get("output", "auto_paste", False))
        self.check_notifications.setChecked(self.config.get("output", "notification", True))

        # Vocabulary
        domain = self.config.get("vocabulary", "domain", "networking")
        index = self.combo_domain.findText(domain)
        if index >= 0:
            self.combo_domain.setCurrentIndex(index)
        self.edit_vocab_file.setText(self.config.get("vocabulary", "custom_file", ""))

        # Hotkey
        hotkey = self.config.get("hotkey", "record", "ctrl+shift+r")
        self.edit_hotkey.setKeySequence(QKeySequence(hotkey))

    def _save_settings(self):
        """Save settings and close dialog."""
        # API
        self.config.set("api", "claude_key", self.edit_claude_key.text())
        self.config.set("api", "openai_key", self.edit_openai_key.text())

        # Whisper
        self.config.set("whisper", "mode", self.combo_whisper_mode.currentText())
        self.config.set("whisper", "model", self.combo_whisper_model.currentText())
        self.config.set("whisper", "device", self.combo_device.currentText())

        # Wake Word
        self.config.set("wake_word", "start_phrase", self.edit_start_phrase.text() or "start now")
        self.config.set("wake_word", "end_phrase", self.edit_end_phrase.text() or "stop now")
        self.config.set("wake_word", "chunk_duration", self.spin_chunk_duration.value())
        self.config.set("wake_word", "sensitivity", self.spin_sensitivity.value())

        # Output
        self.config.set("output", "auto_paste", self.check_auto_paste.isChecked())
        self.config.set("output", "notification", self.check_notifications.isChecked())

        # Vocabulary
        self.config.set("vocabulary", "domain", self.combo_domain.currentText())
        self.config.set("vocabulary", "custom_file", self.edit_vocab_file.text())

        # Hotkey
        hotkey = self.edit_hotkey.keySequence().toString()
        self.config.set("hotkey", "record", hotkey)

        self.config.save()
        self.accept()