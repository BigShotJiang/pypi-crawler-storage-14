"""
Help dialog for VelociDictate.
Provides usage instructions and settings documentation.
"""
from PyQt6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QTabWidget, QWidget,
    QLabel, QPushButton, QScrollArea, QFrame
)
from PyQt6.QtCore import Qt
from PyQt6.QtGui import QFont


class HelpDialog(QDialog):
    """Help dialog with tabbed documentation."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("VelociDictate Help")
        self.setMinimumWidth(600)
        self.setMinimumHeight(500)
        self._setup_ui()

    def _setup_ui(self):
        """Setup the dialog UI."""
        layout = QVBoxLayout(self)

        # Title
        title = QLabel("VelociDictate")
        title_font = QFont()
        title_font.setPointSize(16)
        title_font.setBold(True)
        title.setFont(title_font)
        title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(title)

        subtitle = QLabel("AI-Powered Hands-Free Technical Dictation")
        subtitle.setAlignment(Qt.AlignmentFlag.AlignCenter)
        subtitle.setStyleSheet("color: gray; margin-bottom: 10px;")
        layout.addWidget(subtitle)

        # Tabs
        self.tabs = QTabWidget()
        layout.addWidget(self.tabs)

        self.tabs.addTab(self._create_quickstart_tab(), "Quick Start")
        self.tabs.addTab(self._create_dictation_tab(), "Dictation Commands")
        self.tabs.addTab(self._create_handsfree_tab(), "Hands-Free Mode")
        self.tabs.addTab(self._create_settings_tab(), "Settings Guide")
        self.tabs.addTab(self._create_troubleshooting_tab(), "Troubleshooting")
        self.tabs.addTab(self._create_about_tab(), "About")

        # Close button
        button_layout = QHBoxLayout()
        button_layout.addStretch()
        btn_close = QPushButton("Close")
        btn_close.clicked.connect(self.accept)
        button_layout.addWidget(btn_close)
        layout.addLayout(button_layout)

    def _create_scroll_area(self, content: QLabel) -> QScrollArea:
        """Wrap content in a scroll area."""
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.Shape.NoFrame)

        container = QWidget()
        container_layout = QVBoxLayout(container)
        container_layout.addWidget(content)
        container_layout.addStretch()

        scroll.setWidget(container)
        return scroll

    def _create_quickstart_tab(self) -> QWidget:
        """Create Quick Start tab."""
        content = QLabel("""
<h3>Getting Started</h3>

<p><b>1. Basic Recording (Click Mode)</b></p>
<ul>
<li>Click the tray icon to start recording</li>
<li>Speak your text</li>
<li>Click again to stop and transcribe</li>
<li>Text is copied to clipboard (or auto-pasted if enabled)</li>
</ul>

<p><b>2. Hotkey Recording</b></p>
<ul>
<li>Press <code>Ctrl+Shift+R</code> (default) from any application</li>
<li>Speak your text</li>
<li>Press the hotkey again to stop</li>
</ul>

<p><b>3. Hands-Free Mode (Recommended)</b></p>
<ul>
<li>Right-click tray → "Enable Hands-Free Mode"</li>
<li>Say <b>"start now"</b> to begin recording</li>
<li>Speak your text naturally</li>
<li>Say <b>"stop now"</b> to transcribe</li>
<li>Text is automatically pasted (if auto-paste enabled)</li>
</ul>

<h3>Tray Icon Colors</h3>
<ul>
<li><span style="color: green;">●</span> <b>Green</b> - Ready/Idle</li>
<li><span style="color: orange;">●</span> <b>Orange</b> - Listening for wake word</li>
<li><span style="color: red;">●</span> <b>Red</b> - Recording</li>
<li><span style="color: orange;">●</span> <b>Orange (spinning)</b> - Processing</li>
</ul>

<h3>Requirements</h3>
<ul>
<li>Anthropic API key (for Claude refinement)</li>
<li>Microphone</li>
<li>For auto-paste on Linux: <code>xdotool</code></li>
</ul>
""")
        content.setWordWrap(True)
        content.setTextFormat(Qt.TextFormat.RichText)
        content.setAlignment(Qt.AlignmentFlag.AlignTop)
        return self._create_scroll_area(content)

    def _create_dictation_tab(self) -> QWidget:
        """Create Dictation Commands tab."""
        content = QLabel("""
<h3>Voice Punctuation Commands</h3>

<p>Speak these words to insert punctuation:</p>

<table border="0" cellpadding="5">
<tr><td><b>Say:</b></td><td><b>Result:</b></td></tr>
<tr><td>"period"</td><td>.</td></tr>
<tr><td>"comma"</td><td>,</td></tr>
<tr><td>"question mark"</td><td>?</td></tr>
<tr><td>"exclamation point"</td><td>!</td></tr>
<tr><td>"colon"</td><td>:</td></tr>
<tr><td>"semicolon"</td><td>;</td></tr>
<tr><td>"new paragraph"</td><td>(blank line)</td></tr>
<tr><td>"new line"</td><td>(line break)</td></tr>
<tr><td>"open paren"</td><td>(</td></tr>
<tr><td>"close paren"</td><td>)</td></tr>
<tr><td>"dash"</td><td>-</td></tr>
<tr><td>"quote" / "open quote"</td><td>"</td></tr>
<tr><td>"end quote" / "close quote"</td><td>"</td></tr>
</table>

<h3>Example Dictation</h3>

<p><b>You say:</b></p>
<p><i>"Configure the BGP neighbor at 10.0.0.1 period New paragraph 
The OSPF process should be enabled on VLAN 100 comma with area 0 period"</i></p>

<p><b>Result:</b></p>
<p>Configure the BGP neighbor at 10.0.0.1.</p>
<p>The OSPF process should be enabled on VLAN 100, with area 0.</p>

<h3>Technical Term Corrections</h3>

<p>Claude automatically corrects common speech-to-text errors:</p>
<ul>
<li>"oh SPF" → OSPF</li>
<li>"B G P" → BGP</li>
<li>"V LAN" → VLAN</li>
<li>"ten dot zero dot zero dot one" → 10.0.0.1</li>
<li>"slash twenty four" → /24</li>
<li>"eight oh two dot one Q" → 802.1Q</li>
</ul>
""")
        content.setWordWrap(True)
        content.setTextFormat(Qt.TextFormat.RichText)
        content.setAlignment(Qt.AlignmentFlag.AlignTop)
        return self._create_scroll_area(content)

    def _create_handsfree_tab(self) -> QWidget:
        """Create Hands-Free Mode tab."""
        content = QLabel("""
<h3>Hands-Free Mode</h3>

<p>True voice-activated dictation - no clicking or keyboard required!</p>

<h3>How It Works</h3>
<ol>
<li><b>Enable:</b> Right-click tray → "Enable Hands-Free Mode"</li>
<li><b>Start:</b> Say your start phrase (default: "start now")</li>
<li><b>Dictate:</b> Speak naturally, use voice commands for punctuation</li>
<li><b>Stop:</b> Say your end phrase (default: "stop now")</li>
<li><b>Result:</b> Text is transcribed, refined, and pasted</li>
</ol>

<h3>Best Practices</h3>
<ul>
<li><b>Enable auto-paste</b> in Settings → Output for seamless operation</li>
<li><b>Focus your target</b> (email, chat, document) before saying "start now"</li>
<li><b>Speak clearly</b> for the wake phrases - normal speech is fine for content</li>
<li><b>Pause briefly</b> after "start now" before beginning your content</li>
</ul>

<h3>Choosing Wake Phrases</h3>

<p>Good wake phrases are:</p>
<ul>
<li>Unlikely to appear in normal speech</li>
<li>Easy to pronounce clearly</li>
<li>Distinct from each other</li>
</ul>

<p><b>Recommended pairs:</b></p>
<ul>
<li>"start now" / "stop now" (default)</li>
<li>"begin dictation" / "end dictation"</li>
<li>"hey veloci" / "thanks veloci"</li>
<li>"dictate this" / "that's all"</li>
</ul>

<h3>Performance Notes</h3>
<ul>
<li>Uses the tiny Whisper model for wake word detection (~10-20% CPU)</li>
<li>Uses small/medium model for actual transcription (more accurate)</li>
<li>Disable hands-free mode when not dictating to save CPU</li>
</ul>
""")
        content.setWordWrap(True)
        content.setTextFormat(Qt.TextFormat.RichText)
        content.setAlignment(Qt.AlignmentFlag.AlignTop)
        return self._create_scroll_area(content)

    def _create_settings_tab(self) -> QWidget:
        """Create Settings Guide tab."""
        content = QLabel("""
<h3>Settings Reference</h3>

<h4>API Keys Tab</h4>
<ul>
<li><b>Claude API Key:</b> Required for intelligent transcription refinement. 
Get one at <code>console.anthropic.com</code></li>
<li><b>OpenAI Key:</b> Optional fallback for Whisper API (not typically needed)</li>
</ul>

<h4>Whisper Tab</h4>
<ul>
<li><b>Mode:</b> "local" (recommended) runs on your machine; "api" uses OpenAI</li>
<li><b>Model:</b> Larger = more accurate but slower
  <ul>
  <li>tiny: Fast, lower accuracy (used for wake word detection)</li>
  <li>small: Good balance (recommended for transcription)</li>
  <li>medium: Higher accuracy, slower</li>
  <li>large-v3: Best accuracy, requires good hardware</li>
  </ul>
</li>
<li><b>Device:</b> "cpu" for compatibility; "cuda" for NVIDIA GPU acceleration</li>
</ul>

<h4>Wake Word Tab</h4>
<ul>
<li><b>Start/End Phrases:</b> What you say to start/stop recording</li>
<li><b>Detection Window:</b> How often to check (smaller = faster response, more CPU)</li>
<li><b>Sensitivity:</b> Lower = stricter matching; higher = more lenient</li>
</ul>

<h4>Output Tab</h4>
<ul>
<li><b>Auto-paste:</b> Automatically paste transcription into focused window</li>
<li><b>Notifications:</b> Show system notifications for status updates</li>
</ul>

<h4>Vocabulary Tab</h4>
<ul>
<li><b>Domain:</b> Optimizes corrections for your field
  <ul>
  <li>networking: BGP, OSPF, VLAN, Cisco terms</li>
  <li>development: Python, APIs, Docker, cloud terms</li>
  <li>general: Common technical terminology</li>
  </ul>
</li>
<li><b>Custom Vocabulary:</b> Text file with additional terms (one per line)</li>
</ul>

<h4>Hotkeys Tab</h4>
<ul>
<li><b>Record Hotkey:</b> Global shortcut to toggle recording (default: Ctrl+Shift+R)</li>
</ul>
""")
        content.setWordWrap(True)
        content.setTextFormat(Qt.TextFormat.RichText)
        content.setAlignment(Qt.AlignmentFlag.AlignTop)
        return self._create_scroll_area(content)

    def _create_troubleshooting_tab(self) -> QWidget:
        """Create Troubleshooting tab."""
        content = QLabel("""
<h3>Common Issues</h3>

<h4>No audio captured</h4>
<ul>
<li>Check microphone permissions</li>
<li>Run <code>python main.py --list-devices</code> to see available devices</li>
<li>Check PulseAudio/PipeWire: <code>pactl list sources short</code></li>
</ul>

<h4>Wake word not detected</h4>
<ul>
<li>Speak clearly and at normal volume</li>
<li>Reduce background noise</li>
<li>Try increasing sensitivity in Settings → Wake Word</li>
<li>Try different wake phrases</li>
</ul>

<h4>Auto-paste not working (Linux)</h4>
<ul>
<li>Install xdotool: <code>sudo apt install xdotool</code></li>
<li>On Wayland, xdotool may not work - try X11 or install <code>wtype</code></li>
<li>Ensure the target window accepts Ctrl+V</li>
</ul>

<h4>Claude refinement not working</h4>
<ul>
<li>Verify API key is set correctly</li>
<li>Check API quota at console.anthropic.com</li>
<li>Raw transcription still works without Claude</li>
</ul>

<h4>High CPU usage</h4>
<ul>
<li>Normal in hands-free mode (tiny model runs continuously)</li>
<li>Disable hands-free mode when not dictating</li>
<li>Consider using a smaller detection window</li>
</ul>

<h4>Slow transcription</h4>
<ul>
<li>Try a smaller Whisper model (small instead of medium)</li>
<li>If you have NVIDIA GPU, set device to "cuda"</li>
<li>First transcription is slower (model loading)</li>
</ul>

<h3>Debug Mode</h3>
<p>Run with <code>--debug</code> flag for detailed logging:</p>
<pre>python tray.py --debug</pre>

<h3>Getting Help</h3>
<p>Report issues or get help at the project repository.</p>
""")
        content.setWordWrap(True)
        content.setTextFormat(Qt.TextFormat.RichText)
        content.setAlignment(Qt.AlignmentFlag.AlignTop)
        return self._create_scroll_area(content)

    def _create_about_tab(self) -> QWidget:
        """Create About tab."""
        content = QLabel("""
<h3>VelociDictate</h3>
<p><b>Version:</b> 1.0.0</p>
<p><b>Author:</b> Scott Peterman</p>

<h3>Description</h3>
<p>VelociDictate is a cross-platform speech-to-text application optimized 
for technical terminology. It combines OpenAI's Whisper for audio transcription 
with Anthropic's Claude for intelligent correction of technical terms, 
acronyms, and protocol names.</p>

<h3>Key Features</h3>
<ul>
<li>🎤 Hands-free operation with voice-activated start/stop</li>
<li>🔧 Technical accuracy for networking and development terms</li>
<li>📋 Auto-paste mode for seamless dictation workflow</li>
<li>🖥️ System tray app that runs quietly in background</li>
<li>⚡ Local Whisper processing for privacy and speed</li>
</ul>

<h3>Technology Stack</h3>
<ul>
<li><b>Speech Recognition:</b> OpenAI Whisper (faster-whisper)</li>
<li><b>AI Refinement:</b> Anthropic Claude</li>
<li><b>GUI Framework:</b> PyQt6</li>
<li><b>Audio:</b> sounddevice, numpy</li>
</ul>

<h3>License</h3>
<p>GPLv3 License</p>

<h3>Acknowledgments</h3>
<ul>
<li>OpenAI for the Whisper model</li>
<li>Anthropic for the Claude API</li>
<li>The faster-whisper team for the optimized implementation</li>
</ul>
""")
        content.setWordWrap(True)
        content.setTextFormat(Qt.TextFormat.RichText)
        content.setAlignment(Qt.AlignmentFlag.AlignTop)
        return self._create_scroll_area(content)