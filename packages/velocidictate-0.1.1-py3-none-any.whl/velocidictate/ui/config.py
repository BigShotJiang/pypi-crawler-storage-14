"""
Configuration management for VelociDictate.
Handles loading/saving TOML config files.
"""
import os
import sys
from pathlib import Path
from typing import Any

try:
    import tomllib
except ImportError:
    import tomli as tomllib

import tomli_w


def get_config_dir() -> Path:
    """Get platform-appropriate config directory."""
    if sys.platform == "win32":
        base = Path(os.environ.get("APPDATA", Path.home()))
    elif sys.platform == "darwin":
        base = Path.home() / "Library" / "Application Support"
    else:
        base = Path(os.environ.get("XDG_CONFIG_HOME", Path.home() / ".config"))

    config_dir = base / "velocidictate"
    config_dir.mkdir(parents=True, exist_ok=True)
    return config_dir


DEFAULT_CONFIG = {
    "api": {
        "claude_key": "",
        "openai_key": ""
    },
    "whisper": {
        "mode": "local",
        "model": "small",
        "device": "cpu"
    },
    "audio": {
        "sample_rate": 16000,
        "silence_threshold": 0.01,
        "max_duration": 120
    },
    "hotkey": {
        "record": "ctrl+shift+r"
    },
    "output": {
        "mode": "clipboard",
        "auto_paste": False,
        "notification": True
    },
    "vocabulary": {
        "domain": "networking",
        "custom_file": ""
    },
    "wake_word": {
        "enabled": False,
        "start_phrase": "start now",
        "end_phrase": "stop now",
        "chunk_duration": 2.0,
        "sensitivity": 0.7
    }
}


class Config:
    """Configuration manager for VelociDictate."""

    def __init__(self, config_path: Path = None):
        self.config_dir = get_config_dir()
        self.config_path = config_path or (self.config_dir / "config.toml")
        self._data = self._load()

    def _load(self) -> dict:
        """Load config from file or create default."""
        if self.config_path.exists():
            try:
                with open(self.config_path, "rb") as f:
                    data = tomllib.load(f)
                return self._merge_defaults(data)
            except Exception as e:
                print(f"Error loading config: {e}")
                return DEFAULT_CONFIG.copy()
        else:
            self.save(DEFAULT_CONFIG)
            return DEFAULT_CONFIG.copy()

    def _merge_defaults(self, data: dict) -> dict:
        """Merge loaded data with defaults to fill missing keys."""
        result = {}
        for section, values in DEFAULT_CONFIG.items():
            if section in data and isinstance(values, dict):
                result[section] = {**values, **data[section]}
            elif section in data:
                result[section] = data[section]
            else:
                result[section] = values.copy() if isinstance(values, dict) else values
        # Also preserve any extra sections from user config
        for section in data:
            if section not in result:
                result[section] = data[section]
        return result

    def save(self, data: dict = None) -> None:
        """Save config to file."""
        if data is not None:
            self._data = data
        with open(self.config_path, "wb") as f:
            tomli_w.dump(self._data, f)

    def get(self, section: str, key: str, default: Any = None) -> Any:
        """Get a config value."""
        try:
            return self._data[section][key]
        except KeyError:
            return default

    def set(self, section: str, key: str, value: Any) -> None:
        """Set a config value."""
        if section not in self._data:
            self._data[section] = {}
        self._data[section][key] = value

    def get_section(self, section: str) -> dict:
        """Get an entire config section."""
        return self._data.get(section, {})

    @property
    def data(self) -> dict:
        """Get full config data."""
        return self._data