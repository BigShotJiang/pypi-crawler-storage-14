"""
VelociDictate - System Tray Application
PyQt6-based GUI for the dictation tool.
Now with hands-free wake word support.
"""
import sys
import os
import traceback
from pathlib import Path
from PyQt6.QtWidgets import (
    QApplication, QSystemTrayIcon, QMenu, QMessageBox
)
from PyQt6.QtGui import QIcon, QAction
from PyQt6.QtCore import QThread, pyqtSignal, QObject

from velocidictate.audio import AudioRecorder
from velocidictate.audio.wake_word import WakeWordListener, WakeWordConfig
from velocidictate.transcription import LocalWhisper
from velocidictate.refinement import ClaudeRefiner
from velocidictate.output import copy_to_clipboard, copy_and_paste
from velocidictate.ui.settings_dialog import SettingsDialog
from velocidictate.ui.help_dialog import HelpDialog
from velocidictate.ui.config import Config

# Global hotkey support
try:
    from pynput import keyboard
    PYNPUT_AVAILABLE = True
except ImportError:
    PYNPUT_AVAILABLE = False
    print("pynput not installed - global hotkeys disabled")

# Global debug flag - set via --debug command line argument
DEBUG_MODE = False


def debug_print(msg: str):
    """Print debug message with prefix (only if DEBUG_MODE is enabled)."""
    if DEBUG_MODE:
        print(f"[DEBUG] {msg}")


class HotkeySignals(QObject):
    """Qt signals for hotkey events (thread-safe)."""
    triggered = pyqtSignal()


class HotkeyListener:
    """Global hotkey listener using pynput."""

    def __init__(self, hotkey_str: str, callback):
        """
        Initialize hotkey listener.

        Args:
            hotkey_str: Hotkey in Qt format like "Ctrl+Shift+R"
            callback: Function to call when hotkey pressed
        """
        self.signals = HotkeySignals()
        self.signals.triggered.connect(callback)
        self.listener = None
        self.hotkey_str = hotkey_str

        if not PYNPUT_AVAILABLE:
            return

        # Convert Qt format to pynput format
        pynput_hotkey = self._convert_hotkey(hotkey_str)
        if pynput_hotkey:
            try:
                self.listener = keyboard.GlobalHotKeys({
                    pynput_hotkey: self._on_hotkey
                })
                self.listener.start()
                print(f"[Hotkey] Registered: {hotkey_str} -> {pynput_hotkey}")
            except Exception as e:
                print(f"[Hotkey] Failed to register: {e}")

    def _convert_hotkey(self, qt_hotkey: str) -> str:
        """Convert Qt hotkey format to pynput format."""
        if not qt_hotkey:
            return None

        parts = qt_hotkey.lower().split('+')
        pynput_parts = []

        for part in parts:
            part = part.strip()
            if part in ('ctrl', 'control'):
                pynput_parts.append('<ctrl>')
            elif part in ('shift',):
                pynput_parts.append('<shift>')
            elif part in ('alt',):
                pynput_parts.append('<alt>')
            elif part in ('meta', 'win', 'cmd', 'super'):
                pynput_parts.append('<cmd>')
            elif len(part) == 1:
                pynput_parts.append(part)
            else:
                pynput_parts.append(f'<{part}>')

        return '+'.join(pynput_parts) if pynput_parts else None

    def _on_hotkey(self):
        """Called from pynput thread - emit Qt signal for thread safety."""
        self.signals.triggered.emit()

    def stop(self):
        """Stop the hotkey listener."""
        if self.listener:
            self.listener.stop()
            self.listener = None


class TranscriptionWorker(QThread):
    """Background worker for audio processing."""
    finished = pyqtSignal(str, str)  # raw, refined
    error = pyqtSignal(str)
    status = pyqtSignal(str)

    def __init__(self, audio_data, whisper: LocalWhisper, refiner: ClaudeRefiner = None):
        super().__init__()
        self.audio_data = audio_data
        self.whisper = whisper
        self.refiner = refiner
        debug_print(f"TranscriptionWorker.__init__: refiner is None = {refiner is None}")

    def run(self):
        """Main worker thread - transcribe and refine audio."""
        debug_print("TranscriptionWorker.run() STARTED")
        try:
            # Transcribe with Whisper
            debug_print("Calling Whisper transcribe...")
            self.status.emit("Transcribing...")
            raw_transcript = self.whisper.transcribe(self.audio_data)
            debug_print(f"Whisper returned: {repr(raw_transcript)}")

            if not raw_transcript.strip():
                debug_print("No speech detected - emitting error")
                self.error.emit("No speech detected")
                return

            # Refine with Claude if available
            refined_transcript = raw_transcript
            debug_print(f"self.refiner is None: {self.refiner is None}")

            if self.refiner:
                debug_print("Refiner exists - calling Claude...")
                self.status.emit("Refining...")
                try:
                    debug_print(f"About to call self.refiner.refine()")
                    refined_transcript = self.refiner.refine(raw_transcript)
                    debug_print(f"Claude returned: {repr(refined_transcript)}")
                except Exception as e:
                    debug_print(f"Claude EXCEPTION: {e}")
                    traceback.print_exc()
                    self.status.emit(f"Claude error, using raw: {e}")
            else:
                debug_print("No refiner - using raw transcript")

            debug_print(f"Emitting finished signal")
            debug_print(f"  raw: {repr(raw_transcript)}")
            debug_print(f"  refined: {repr(refined_transcript)}")
            self.finished.emit(raw_transcript, refined_transcript)

        except Exception as e:
            debug_print(f"TranscriptionWorker EXCEPTION: {e}")
            traceback.print_exc()
            self.error.emit(str(e))

        debug_print("TranscriptionWorker.run() ENDED")


class WakeWordSignals(QObject):
    """Qt signals for wake word listener callbacks."""
    recording_started = pyqtSignal()
    recording_complete = pyqtSignal(object)  # numpy array
    state_changed = pyqtSignal(str)


class VelociDictateTray(QSystemTrayIcon):
    """System tray application for VelociDictate."""

    def __init__(self):
        super().__init__()
        debug_print("VelociDictateTray.__init__ starting")

        # Load configuration
        self.config = Config()

        # State
        self.is_recording = False
        self.hands_free_mode = False
        self.recorder = AudioRecorder()
        self.whisper = None
        self.whisper_tiny = None
        self.refiner = None
        self.worker = None
        self.wake_word_listener = None
        self.wake_word_signals = WakeWordSignals()
        self.hotkey_listener = None

        # Setup UI
        self._setup_icons()
        self._setup_menu()
        self._setup_connections()

        # Initialize components
        self._init_components()

        # Setup global hotkey
        self._setup_hotkey()

        self.setIcon(self.icon_idle)
        self.setToolTip("VelociDictate - Ready")
        self.show()
        debug_print("VelociDictateTray.__init__ complete")

    def _setup_icons(self):
        """Load or create status icons."""
        icon_dir = Path(__file__).parent / "icons"

        if (icon_dir / "idle.png").exists():
            self.icon_idle = QIcon(str(icon_dir / "idle.png"))
            self.icon_recording = QIcon(str(icon_dir / "recording.png"))
            self.icon_processing = QIcon(str(icon_dir / "processing.png"))
            self.icon_listening = QIcon(str(icon_dir / "processing.png"))
        else:
            self.icon_idle = QIcon.fromTheme("audio-input-microphone")
            self.icon_recording = QIcon.fromTheme("media-record")
            self.icon_processing = QIcon.fromTheme("system-run")
            self.icon_listening = QIcon.fromTheme("audio-input-microphone")

            if self.icon_idle.isNull():
                self.icon_idle = QApplication.style().standardIcon(
                    QApplication.style().StandardPixmap.SP_MediaVolume
                )
                self.icon_recording = QApplication.style().standardIcon(
                    QApplication.style().StandardPixmap.SP_MediaPlay
                )
                self.icon_processing = QApplication.style().standardIcon(
                    QApplication.style().StandardPixmap.SP_BrowserReload
                )
                self.icon_listening = self.icon_processing

    def _setup_menu(self):
        """Create the context menu."""
        self.menu = QMenu()

        self.action_record = QAction("Start Recording", self.menu)
        self.action_record.triggered.connect(self.toggle_recording)
        self.menu.addAction(self.action_record)

        self.menu.addSeparator()

        self.action_hands_free = QAction("Enable Hands-Free Mode", self.menu)
        self.action_hands_free.setCheckable(True)
        self.action_hands_free.triggered.connect(self.toggle_hands_free_mode)
        self.menu.addAction(self.action_hands_free)

        self.menu.addSeparator()

        action_settings = QAction("Settings...", self.menu)
        action_settings.triggered.connect(self.show_settings)
        self.menu.addAction(action_settings)

        action_help = QAction("Help...", self.menu)
        action_help.triggered.connect(self.show_help)
        self.menu.addAction(action_help)

        self.menu.addSeparator()

        action_quit = QAction("Quit", self.menu)
        action_quit.triggered.connect(self.quit_app)
        self.menu.addAction(action_quit)

        self.setContextMenu(self.menu)

    def _setup_connections(self):
        """Setup signal connections."""
        self.activated.connect(self._on_activated)
        self.wake_word_signals.recording_started.connect(self._on_wake_word_recording_start)
        self.wake_word_signals.recording_complete.connect(self._on_wake_word_recording_complete)
        self.wake_word_signals.state_changed.connect(self._on_wake_word_state_change)

    def _setup_hotkey(self):
        """Setup global hotkey for recording toggle."""
        if not PYNPUT_AVAILABLE:
            return

        hotkey = self.config.get("hotkey", "record", "ctrl+shift+r")
        if hotkey:
            self.hotkey_listener = HotkeyListener(hotkey, self._on_hotkey_pressed)

    def _on_hotkey_pressed(self):
        """Handle global hotkey press."""
        debug_print("Hotkey pressed!")
        if self.hands_free_mode and self.wake_word_listener:
            if self.wake_word_listener.state == WakeWordListener.STATE_RECORDING:
                audio = self.wake_word_listener.force_stop_recording()
                if audio is not None:
                    self._process_audio(audio)
        else:
            self.toggle_recording()

    def _init_components(self):
        """Initialize Whisper and Claude components."""
        debug_print("_init_components starting")

        # Initialize main Whisper model
        try:
            model = self.config.get("whisper", "model", "small")
            debug_print(f"Loading Whisper model: {model}")
            self.whisper = LocalWhisper(model_size=model, device="cpu", verbose=False)
            self.showMessage(
                "VelociDictate",
                f"Whisper {model} model ready",
                QSystemTrayIcon.MessageIcon.Information,
                2000
            )
            debug_print("Whisper loaded successfully")
        except Exception as e:
            debug_print(f"Whisper init FAILED: {e}")
            traceback.print_exc()
            self.showMessage(
                "VelociDictate",
                f"Whisper init failed: {e}",
                QSystemTrayIcon.MessageIcon.Warning,
                3000
            )

        # Initialize Claude if API key available
        api_key = self.config.get("api", "claude_key", "")
        if not api_key:
            api_key = os.environ.get("ANTHROPIC_API_KEY", "")

        debug_print(f"API key available: {bool(api_key)}")
        debug_print(f"API key length: {len(api_key) if api_key else 0}")

        if api_key:
            try:
                domain = self.config.get("vocabulary", "domain", "networking")
                debug_print(f"Initializing ClaudeRefiner with domain: {domain}")
                self.refiner = ClaudeRefiner(api_key=api_key, domain=domain, debug=DEBUG_MODE)
                debug_print(f"ClaudeRefiner initialized: {self.refiner}")
                debug_print(f"ClaudeRefiner model: {self.refiner.model}")
            except Exception as e:
                debug_print(f"Claude init FAILED: {e}")
                traceback.print_exc()
                self.showMessage(
                    "VelociDictate",
                    f"Claude init failed: {e}",
                    QSystemTrayIcon.MessageIcon.Warning,
                    3000
                )
        else:
            debug_print("No API key - Claude refinement disabled")

        debug_print(f"_init_components complete. self.refiner = {self.refiner}")

    def _init_wake_word_listener(self):
        """Initialize the wake word listener (lazy initialization)."""
        if self.wake_word_listener is not None:
            return True

        if self.whisper_tiny is None:
            try:
                self.showMessage(
                    "VelociDictate",
                    "Loading tiny model for wake word detection...",
                    QSystemTrayIcon.MessageIcon.Information,
                    2000
                )
                self.whisper_tiny = LocalWhisper(model_size="tiny", device="cpu", verbose=False)
                self.whisper_tiny._ensure_loaded()
            except Exception as e:
                self.showMessage(
                    "VelociDictate",
                    f"Failed to load tiny model: {e}",
                    QSystemTrayIcon.MessageIcon.Critical,
                    3000
                )
                return False

        start_phrase = self.config.get("wake_word", "start_phrase", "start now")
        end_phrase = self.config.get("wake_word", "end_phrase", "stop now")

        config = WakeWordConfig(
            start_phrase=start_phrase,
            end_phrase=end_phrase,
            chunk_duration=2.0,
            overlap=0.5
        )

        self.wake_word_listener = WakeWordListener(
            whisper_tiny=self.whisper_tiny,
            config=config,
            on_recording_start=lambda: self.wake_word_signals.recording_started.emit(),
            on_recording_complete=lambda audio: self.wake_word_signals.recording_complete.emit(audio),
            on_state_change=lambda state: self.wake_word_signals.state_changed.emit(state)
        )

        return True

    def _on_activated(self, reason):
        """Handle tray icon activation (click)."""
        if reason == QSystemTrayIcon.ActivationReason.Trigger:
            if self.hands_free_mode and self.wake_word_listener:
                if self.wake_word_listener.state == WakeWordListener.STATE_RECORDING:
                    audio = self.wake_word_listener.force_stop_recording()
                    if audio is not None:
                        self._process_audio(audio)
            else:
                self.toggle_recording()
        elif reason == QSystemTrayIcon.ActivationReason.DoubleClick:
            self.show_settings()

    def toggle_hands_free_mode(self):
        """Toggle hands-free (wake word) mode."""
        if self.hands_free_mode:
            self._disable_hands_free_mode()
        else:
            self._enable_hands_free_mode()

    def _enable_hands_free_mode(self):
        """Enable hands-free wake word mode."""
        if self.is_recording:
            self.stop_recording()

        if not self._init_wake_word_listener():
            self.action_hands_free.setChecked(False)
            return

        self.hands_free_mode = True
        self.action_hands_free.setText("Disable Hands-Free Mode")
        self.action_hands_free.setChecked(True)
        self.action_record.setEnabled(False)

        self.wake_word_listener.start_listening()

        start_phrase = self.config.get("wake_word", "start_phrase", "begin phrase")
        self.showMessage(
            "VelociDictate",
            f"Hands-free mode enabled\nSay '{start_phrase}' to start recording",
            QSystemTrayIcon.MessageIcon.Information,
            3000
        )

    def _disable_hands_free_mode(self):
        """Disable hands-free wake word mode."""
        if self.wake_word_listener:
            self.wake_word_listener.stop_listening()

        self.hands_free_mode = False
        self.action_hands_free.setText("Enable Hands-Free Mode")
        self.action_hands_free.setChecked(False)
        self.action_record.setEnabled(True)

        self.setIcon(self.icon_idle)
        self.setToolTip("VelociDictate - Ready")

        self.showMessage(
            "VelociDictate",
            "Hands-free mode disabled",
            QSystemTrayIcon.MessageIcon.Information,
            2000
        )

    def _on_wake_word_recording_start(self):
        """Called when wake word triggers recording start."""
        self.setIcon(self.icon_recording)
        end_phrase = self.config.get("wake_word", "end_phrase", "end phrase")
        self.setToolTip(f"VelociDictate - Recording (say '{end_phrase}' to stop)")

        self.showMessage(
            "VelociDictate",
            f"Recording started\nSay '{end_phrase}' when done",
            QSystemTrayIcon.MessageIcon.Information,
            2000
        )

    def _on_wake_word_recording_complete(self, audio):
        """Called when wake word detects end phrase."""
        self._process_audio(audio)

    def _on_wake_word_state_change(self, state):
        """Called when wake word listener state changes."""
        if state == WakeWordListener.STATE_LISTENING:
            self.setIcon(self.icon_listening)
            start_phrase = self.config.get("wake_word", "start_phrase", "begin phrase")
            self.setToolTip(f"VelociDictate - Listening for '{start_phrase}'")
        elif state == WakeWordListener.STATE_RECORDING:
            self.setIcon(self.icon_recording)
            self.setToolTip("VelociDictate - Recording...")
        elif state == WakeWordListener.STATE_IDLE:
            self.setIcon(self.icon_idle)
            self.setToolTip("VelociDictate - Ready")

    def toggle_recording(self):
        """Start or stop recording (manual mode)."""
        debug_print(f"toggle_recording called. is_recording={self.is_recording}")
        if self.is_recording:
            self.stop_recording()
        else:
            self.start_recording()

    def start_recording(self):
        """Start audio recording (manual mode)."""
        debug_print("start_recording called")
        if self.whisper is None:
            debug_print("Whisper is None - cannot record")
            self.showMessage(
                "VelociDictate",
                "Whisper not initialized",
                QSystemTrayIcon.MessageIcon.Warning,
                2000
            )
            return

        self.is_recording = True
        self.recorder.start_recording()

        self.setIcon(self.icon_recording)
        self.setToolTip("VelociDictate - Recording...")
        self.action_record.setText("Stop Recording")

        self.showMessage(
            "VelociDictate",
            "Recording started - click to stop",
            QSystemTrayIcon.MessageIcon.Information,
            1500
        )
        debug_print("Recording started")

    def stop_recording(self):
        """Stop recording and process audio (manual mode)."""
        debug_print("stop_recording called")
        self.is_recording = False
        audio_data = self.recorder.stop_recording()

        self.action_record.setText("Start Recording")

        debug_print(f"Audio data length: {len(audio_data)}")
        if len(audio_data) == 0:
            debug_print("No audio captured")
            self.showMessage(
                "VelociDictate",
                "No audio captured",
                QSystemTrayIcon.MessageIcon.Warning,
                2000
            )
            self._reset_to_idle()
            return

        self._process_audio(audio_data)

    def _process_audio(self, audio_data):
        """Process recorded audio through Whisper and Claude."""
        debug_print(f"_process_audio called with {len(audio_data)} samples")
        debug_print(f"self.refiner at process time: {self.refiner}")

        self.setIcon(self.icon_processing)
        self.setToolTip("VelociDictate - Processing...")
        self.action_record.setEnabled(False)

        # Process in background thread
        debug_print("Creating TranscriptionWorker...")
        self.worker = TranscriptionWorker(audio_data, self.whisper, self.refiner)
        self.worker.finished.connect(self._on_transcription_complete)
        self.worker.error.connect(self._on_transcription_error)
        self.worker.status.connect(self._on_status_update)
        debug_print("Starting worker thread...")
        self.worker.start()
        debug_print("Worker thread started")

    def _on_transcription_complete(self, raw: str, refined: str):
        """Handle completed transcription."""
        debug_print("_on_transcription_complete called")
        debug_print(f"  raw (repr): {repr(raw)}")
        debug_print(f"  refined (repr): {repr(refined)}")
        debug_print(f"  raw == refined: {raw == refined}")

        # Strip wake word phrases from output if in hands-free mode
        if self.hands_free_mode:
            start_phrase = self.config.get("wake_word", "start_phrase", "start now")
            end_phrase = self.config.get("wake_word", "end_phrase", "stop now")
            import re
            refined = re.sub(re.escape(start_phrase), '', refined, flags=re.IGNORECASE).strip()
            refined = re.sub(re.escape(end_phrase), '', refined, flags=re.IGNORECASE).strip()
            raw = re.sub(re.escape(start_phrase), '', raw, flags=re.IGNORECASE).strip()
            raw = re.sub(re.escape(end_phrase), '', raw, flags=re.IGNORECASE).strip()

        # Check if auto-paste is enabled
        auto_paste = self.config.get("output", "auto_paste", False)
        debug_print(f"auto_paste: {auto_paste}")

        if auto_paste:
            debug_print("Calling copy_and_paste...")
            copy_and_paste(refined)
        else:
            debug_print("Calling copy_to_clipboard...")
            copy_to_clipboard(refined)

        # Show preview in notification
        if self.config.get("output", "notification", True):
            preview = refined[:100] + "..." if len(refined) > 100 else refined
            action = "Pasted" if auto_paste else "Copied"
            self.showMessage(
                "VelociDictate",
                f"{action}: {preview}",
                QSystemTrayIcon.MessageIcon.Information,
                2000
            )

        self._reset_to_idle()

    def _on_transcription_error(self, error: str):
        """Handle transcription error."""
        debug_print(f"_on_transcription_error: {error}")
        self.showMessage(
            "VelociDictate",
            f"Error: {error}",
            QSystemTrayIcon.MessageIcon.Critical,
            3000
        )
        self._reset_to_idle()

    def _on_status_update(self, status: str):
        """Handle status updates from worker."""
        debug_print(f"Status update: {status}")
        self.setToolTip(f"VelociDictate - {status}")

    def _reset_to_idle(self):
        """Reset to idle state."""
        debug_print("_reset_to_idle called")
        self.action_record.setEnabled(not self.hands_free_mode)

        if self.hands_free_mode:
            self.setIcon(self.icon_listening)
            start_phrase = self.config.get("wake_word", "start_phrase", "begin phrase")
            self.setToolTip(f"VelociDictate - Listening for '{start_phrase}'")
        else:
            self.setIcon(self.icon_idle)
            self.setToolTip("VelociDictate - Ready")

    def show_settings(self):
        """Show settings dialog."""
        dialog = SettingsDialog(self.config)
        if dialog.exec():
            was_hands_free = self.hands_free_mode
            if was_hands_free:
                self._disable_hands_free_mode()

            self.wake_word_listener = None
            self._init_components()

            if self.hotkey_listener:
                self.hotkey_listener.stop()
            self._setup_hotkey()

            if was_hands_free:
                self._enable_hands_free_mode()

    def show_help(self):
        """Show help dialog."""
        dialog = HelpDialog()
        dialog.exec()

    def quit_app(self):
        """Quit the application."""
        debug_print("quit_app called")
        if self.is_recording:
            self.recorder.stop_recording()
        if self.wake_word_listener:
            self.wake_word_listener.stop_listening()
        if self.hotkey_listener:
            self.hotkey_listener.stop()
        QApplication.quit()


def main():
    global DEBUG_MODE

    # Parse command line arguments
    import argparse
    parser = argparse.ArgumentParser(description="VelociDictate - AI-Powered Hands-Free Technical Dictation")
    parser.add_argument("--debug", action="store_true", help="Enable debug output")
    args = parser.parse_args()

    DEBUG_MODE = args.debug

    if DEBUG_MODE:
        print("[DEBUG] Debug mode enabled")

    debug_print("main() starting")
    app = QApplication(sys.argv)
    app.setQuitOnLastWindowClosed(False)
    app.setApplicationName("VelociDictate")

    if not QSystemTrayIcon.isSystemTrayAvailable():
        QMessageBox.critical(
            None,
            "VelociDictate",
            "System tray not available on this system."
        )
        sys.exit(1)

    tray = VelociDictateTray()
    debug_print("Entering Qt event loop")
    sys.exit(app.exec())


if __name__ == "__main__":
    main()