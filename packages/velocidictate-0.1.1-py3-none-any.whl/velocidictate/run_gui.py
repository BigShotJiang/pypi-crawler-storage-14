#!/usr/bin/env python3
"""
VelociDictate GUI - System Tray Application
Run this script to start the graphical interface.
"""
import sys

# Suppress pkg_resources deprecation warning from ctranslate2
import warnings

warnings.filterwarnings("ignore", category=UserWarning, module="ctranslate2")
warnings.filterwarnings("ignore", category=DeprecationWarning, module="pkg_resources")

from PyQt6.QtWidgets import QApplication, QMessageBox, QSystemTrayIcon

from velocidictate.ui import VelociDictateTray


def main():
    app = QApplication(sys.argv)
    app.setQuitOnLastWindowClosed(False)
    app.setApplicationName("VelociDictate")

    # Check for system tray support
    if not QSystemTrayIcon.isSystemTrayAvailable():
        QMessageBox.critical(
            None,
            "VelociDictate",
            "System tray not available on this system."
        )
        sys.exit(1)

    tray = VelociDictateTray()
    sys.exit(app.exec())


if __name__ == "__main__":
    main()