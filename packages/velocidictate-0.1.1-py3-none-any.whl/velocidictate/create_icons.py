#!/usr/bin/env python3
"""
Generate simple tray icons for VelociDictate.
Creates colored circle icons for idle, recording, and processing states.
"""
from pathlib import Path

# Simple 16x16 ICO/PNG using PyQt6
from PyQt6.QtWidgets import QApplication
from PyQt6.QtGui import QPixmap, QPainter, QColor, QBrush
from PyQt6.QtCore import Qt
import sys


def create_icon(color: str, filename: str, size: int = 64):
    """Create a simple colored circle icon."""
    pixmap = QPixmap(size, size)
    pixmap.fill(Qt.GlobalColor.transparent)

    painter = QPainter(pixmap)
    painter.setRenderHint(QPainter.RenderHint.Antialiasing)

    # Draw filled circle
    painter.setBrush(QBrush(QColor(color)))
    painter.setPen(Qt.PenStyle.NoPen)
    margin = size // 8
    painter.drawEllipse(margin, margin, size - 2 * margin, size - 2 * margin)

    painter.end()

    return pixmap


def main():
    app = QApplication(sys.argv)

    icon_dir = Path(__file__).parent / "ui" / "icons"
    icon_dir.mkdir(parents=True, exist_ok=True)

    # Create icons
    icons = {
        "idle.png": "#4CAF50",  # Green
        "recording.png": "#F44336",  # Red
        "processing.png": "#FF9800"  # Orange
    }

    for filename, color in icons.items():
        pixmap = create_icon(color, filename)
        path = icon_dir / filename
        pixmap.save(str(path))
        print(f"Created: {path}")

    print("\nIcons created successfully!")


if __name__ == "__main__":
    main()