"""
VelociDictate - AI-Powered Technical Dictation Tool

A speech-to-text tool optimized for technical terminology,
using Whisper for transcription and Claude for refinement.
"""
__version__ = "0.1.0"
__author__ = "Scott Peterman"
