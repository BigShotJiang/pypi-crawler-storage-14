"""
Local Whisper transcription using faster-whisper.
"""
import numpy as np
from typing import Optional
from faster_whisper import WhisperModel


class LocalWhisper:
    """Local Whisper inference using faster-whisper (CTranslate2)."""
    
    VALID_MODELS = ["tiny", "base", "small", "medium", "large-v3"]
    
    def __init__(
        self,
        model_size: str = "small",
        device: str = "auto",
        compute_type: str = "auto",
        verbose: bool = False
    ):
        """
        Initialize Whisper model.

        Args:
            model_size: One of tiny, base, small, medium, large-v3
            device: "auto", "cuda", or "cpu"
            compute_type: "auto", "float16", "int8", etc.
            verbose: Print debug messages (model loading, language detection)
        """
        if model_size not in self.VALID_MODELS:
            raise ValueError(f"Invalid model: {model_size}. Choose from {self.VALID_MODELS}")

        self.model_size = model_size
        self.device = device
        self.compute_type = compute_type
        self.verbose = verbose
        self._model: Optional[WhisperModel] = None

    def _ensure_loaded(self) -> None:
        """Load model if not already loaded."""
        if self._model is None:
            if self.verbose:
                print(f"Loading Whisper {self.model_size} model...")

            # Determine device
            if self.device == "auto":
                device = "cuda"  # faster-whisper will fall back to CPU if needed
            else:
                device = self.device

            # Determine compute type
            if self.compute_type == "auto":
                compute_type = "float16" if device == "cuda" else "int8"
            else:
                compute_type = self.compute_type

            self._model = WhisperModel(
                self.model_size,
                device=device,
                compute_type=compute_type
            )
            if self.verbose:
                print(f"Model loaded on {device} with {compute_type}")

    def transcribe(self, audio: np.ndarray | str) -> str:
        """
        Transcribe audio to text.

        Args:
            audio: Numpy array (float32, 16kHz) or path to audio file

        Returns:
            Transcribed text
        """
        self._ensure_loaded()

        # faster-whisper expects float32 audio or file path
        segments, info = self._model.transcribe(
            audio,
            language="en",
            beam_size=5,
            vad_filter=True,  # Filter out silence
            vad_parameters=dict(
                min_silence_duration_ms=500
            )
        )

        # Collect all segments
        text_parts = []
        for segment in segments:
            text_parts.append(segment.text.strip())

        transcript = " ".join(text_parts)

        if self.verbose:
            print(f"Whisper detected language: {info.language} (probability: {info.language_probability:.2f})")

        return transcript

    def is_available(self) -> bool:
        """Check if model is loaded and ready."""
        return self._model is not None

    def unload(self) -> None:
        """Unload model to free memory."""
        self._model = None
        if self.verbose:
            print("Model unloaded")


if __name__ == "__main__":
    # Quick test with a file
    import sys

    whisper = LocalWhisper(model_size="small", verbose=True)

    if len(sys.argv) > 1:
        audio_file = sys.argv[1]
        print(f"Transcribing {audio_file}...")
        text = whisper.transcribe(audio_file)
        print(f"\nTranscript:\n{text}")
    else:
        print("Usage: python whisper_local.py <audio_file.wav>")