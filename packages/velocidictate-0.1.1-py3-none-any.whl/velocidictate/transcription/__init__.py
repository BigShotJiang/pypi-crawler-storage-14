from .whisper_local import LocalWhisper

__all__ = ["LocalWhisper"]
