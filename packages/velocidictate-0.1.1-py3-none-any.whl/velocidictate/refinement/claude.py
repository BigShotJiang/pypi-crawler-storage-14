"""
Claude API integration for technical terminology correction.
"""
import os
import re
import zipfile
import urllib.request
from pathlib import Path
from typing import Optional


# Dictation commands that apply to all domains
DICTATION_COMMANDS = """

CRITICAL - VOICE COMMAND CONVERSION:
This is a voice-dictated transcript. The speaker used SPOKEN voice commands for punctuation.
You MUST convert these spoken words into actual punctuation marks.

IMPORTANT: The speech-to-text may have ALREADY added punctuation around the command word.
For example, you might see ", comma," or "test, period." - remove the spoken word AND any duplicate punctuation.

CONVERSIONS (remove the word, keep only one punctuation mark):
- "period" → .
- "comma" → ,
- "question mark" → ?
- "exclamation point" or "exclamation mark" → !
- "colon" → :
- "semicolon" → ;
- "new paragraph" → (start a new paragraph - double line break)
- "new line" → (single line break)
- "open paren" or "open parenthesis" → (
- "close paren" or "close parenthesis" → )
- "dash" or "hyphen" → -
- "quote" or "open quote" → "
- "end quote" or "close quote" → "

EXAMPLE TRANSFORMATIONS:
- "test, comma, more" → "test, more"
- "done, period. Next" → "done. Next"  
- "okay, period." → "okay."
- "Hello comma how are you question mark" → "Hello, how are you?"
- "First point, period, new paragraph, Second" → "First point.\\n\\nSecond"

The final output must read as natural written text with NO spoken command words remaining.
"""


DOMAIN_PROMPTS = {
    "networking": """You are a technical transcription assistant specializing in network engineering.

Your FIRST priority is converting voice dictation commands to punctuation (see rules below).
Your SECOND priority is correcting technical terminology.

Technical corrections to make:
- Network protocol names: "oh SPF" → "OSPF", "B G P" → "BGP", "I S I S" → "IS-IS"
- IP addresses: "ten dot zero dot zero dot one" → "10.0.0.1"
- CIDR notation: "slash twenty four" → "/24"
- Network terms: "V LAN" → "VLAN", "A C L" → "ACL", "S N M P" → "SNMP"
- Standards: "eight oh two dot one Q" → "802.1Q"
- Vendors: Cisco, Juniper, Arista, Fortinet, Palo Alto
""" + DICTATION_COMMANDS + """

Return ONLY the corrected transcript. No explanations, no markdown, no quotes around the result.""",

    "development": """You are a technical transcription assistant specializing in software development.

Your FIRST priority is converting voice dictation commands to punctuation (see rules below).
Your SECOND priority is correcting technical terminology.

Technical corrections to make:
- Languages: "python" → "Python", "java script" → "JavaScript", "type script" → "TypeScript"
- Terms: "A P I" → "API", "jason" → "JSON", "sequel" → "SQL"
- Tools: "docker" → "Docker", "kubernetes" → "Kubernetes", "get hub" → "GitHub"
- Databases: "postgres" → "PostgreSQL", "my sequel" → "MySQL", "redis" → "Redis"
- Cloud: "A W S" → "AWS", "G C P" → "GCP", "azure" → "Azure"
""" + DICTATION_COMMANDS + """

Return ONLY the corrected transcript. No explanations, no markdown, no quotes around the result.""",

    "it-general": """You are a technical transcription assistant specializing in IT support and system administration.

Your FIRST priority is converting voice dictation commands to punctuation (see rules below).
Your SECOND priority is correcting technical terminology.

Technical corrections to make:
- Operating systems: "windows" → "Windows", "linux" → "Linux", "mac OS" → "macOS"
- Microsoft terms: "active directory" → "Active Directory", "A D" → "AD", "G P O" → "GPO"
- Virtualization: "V M ware" → "VMware", "hyper V" → "Hyper-V", "V M" → "VM"
- Hardware: "C P U" → "CPU", "R A M" → "RAM", "S S D" → "SSD", "N I C" → "NIC"
- Protocols: "R D P" → "RDP", "S S H" → "SSH", "S M B" → "SMB", "N F S" → "NFS"
- Support terms: "S L A" → "SLA", "I T I L" → "ITIL", "ticket", "incident", "escalation"
""" + DICTATION_COMMANDS + """

Return ONLY the corrected transcript. No explanations, no markdown, no quotes around the result.""",

    "project-management": """You are a transcription assistant specializing in project management and Agile terminology.

Your FIRST priority is converting voice dictation commands to punctuation (see rules below).
Your SECOND priority is correcting project management terminology.

Technical corrections to make:
- Agile terms: "scrum" → "Scrum", "kanban" → "Kanban", "stand up" → "standup"
- Roles: "scrum master" → "Scrum Master", "P O" → "Product Owner", "P M" → "PM"
- Ceremonies: "retro" → "retrospective", "sprint review", "backlog grooming"
- Metrics: "K P I" → "KPI", "O K R" → "OKR", "S L A" → "SLA", "velocity"
- Tools: "jira" → "Jira", "confluence" → "Confluence", "trello" → "Trello"
- Documents: "B R D" → "BRD", "P R D" → "PRD", "S O W" → "SOW", "R F P" → "RFP"
- SAFe terms: "S A F E" → "SAFe", "P I planning" → "PI Planning", "A R T" → "ART"
""" + DICTATION_COMMANDS + """

Return ONLY the corrected transcript. No explanations, no markdown, no quotes around the result.""",

    "creative-writing": """You are a transcription assistant specializing in creative writing and literary terminology.

Your FIRST priority is converting voice dictation commands to punctuation (see rules below).
Your SECOND priority is correcting literary terms, Latin phrases, and proper nouns.

Technical corrections to make:
- Latin phrases: "in medias res" (not "in media res"), "deus ex machina", "carpe diem"
- Literary terms: "protagonist", "antagonist", "denouement" (day-new-MAHN)
- Shakespeare plays: "Hamlet", "Macbeth", "Othello", "King Lear", "The Tempest"
- Shakespeare characters: "Ophelia", "Iago", "Mercutio", "Prospero", "Falstaff"
- Classical references: "Odysseus", "Achilles", "Prometheus", "Sisyphus", "Orpheus"
- Poetic terms: "iambic pentameter", "sonnet", "quatrain", "couplet", "stanza"
- Narrative terms: "foreshadowing", "allegory", "metaphor", "personification"

Preserve the author's voice and style. Do not over-correct creative language choices.
""" + DICTATION_COMMANDS + """

Return ONLY the corrected transcript. No explanations, no markdown, no quotes around the result.""",

    "general": """You are a transcription assistant that converts voice-dictated text into proper written form.

Your FIRST priority is converting voice dictation commands to punctuation (see rules below).
Your SECOND priority is correcting any obvious speech-to-text errors.

Focus on:
- Converting all spoken punctuation commands to actual punctuation
- Fixing obvious transcription errors
- Proper capitalization
- Natural sentence flow
""" + DICTATION_COMMANDS + """

Return ONLY the corrected transcript. No explanations, no markdown, no quotes around the result."""
}


# Vocabulary folder management
VOCABULARIES_URL = "https://github.com/scottpeterman/velocidictate/raw/main/vocabularies.zip"


def get_vocabularies_dir() -> Path:
    """Get the vocabularies directory path."""
    if os.name == 'nt':  # Windows
        config_dir = Path(os.environ.get('APPDATA', '')) / 'velocidictate'
    else:  # Linux/macOS
        config_dir = Path.home() / '.config' / 'velocidictate'

    return config_dir / 'vocabularies'


def ensure_vocabularies_dir() -> Path:
    """Ensure the vocabularies directory exists."""
    vocab_dir = get_vocabularies_dir()
    vocab_dir.mkdir(parents=True, exist_ok=True)
    return vocab_dir


def list_available_vocabularies() -> list[dict]:
    """
    List all available vocabulary files in the vocabularies directory.

    Returns:
        List of dicts with 'name', 'path', and 'term_count' keys.
    """
    vocab_dir = get_vocabularies_dir()
    vocabularies = []

    if not vocab_dir.exists():
        return vocabularies

    for file_path in vocab_dir.glob('*.txt'):
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                lines = f.readlines()

            # Count non-comment, non-empty lines
            term_count = len([l for l in lines if l.strip() and not l.strip().startswith('#')])

            vocabularies.append({
                'name': file_path.stem,  # filename without extension
                'path': str(file_path),
                'term_count': term_count
            })
        except Exception:
            # Skip files we can't read
            continue

    return sorted(vocabularies, key=lambda x: x['name'])


def download_vocabularies(progress_callback=None) -> tuple[bool, str]:
    """
    Download and extract vocabularies.zip from GitHub.

    Args:
        progress_callback: Optional callable(status_message) for progress updates.

    Returns:
        Tuple of (success: bool, message: str)
    """
    vocab_dir = ensure_vocabularies_dir()
    zip_path = vocab_dir / 'vocabularies.zip'

    try:
        if progress_callback:
            progress_callback("Downloading vocabulary packs...")

        # Download the zip file
        urllib.request.urlretrieve(VOCABULARIES_URL, zip_path)

        if progress_callback:
            progress_callback("Extracting vocabulary files...")

        # Extract the zip file
        with zipfile.ZipFile(zip_path, 'r') as zip_ref:
            zip_ref.extractall(vocab_dir)

        # Clean up the zip file
        zip_path.unlink()

        # Count what we got
        vocab_files = list(vocab_dir.glob('*.txt'))

        if progress_callback:
            progress_callback(f"Done! {len(vocab_files)} vocabulary packs installed.")

        return True, f"Successfully installed {len(vocab_files)} vocabulary packs"

    except urllib.error.URLError as e:
        return False, f"Download failed: {e.reason}"
    except zipfile.BadZipFile:
        return False, "Downloaded file is not a valid zip archive"
    except Exception as e:
        return False, f"Error: {str(e)}"
    finally:
        # Clean up zip file if it exists
        if zip_path.exists():
            try:
                zip_path.unlink()
            except Exception:
                pass


class ClaudeRefiner:
    """Uses Claude to refine transcripts for technical accuracy."""

    def __init__(
        self,
        api_key: Optional[str] = None,
        domain: str = "networking",
        model: str = "claude-sonnet-4-20250514",
        debug: bool = False
    ):
        # Import here to avoid circular imports
        from anthropic import Anthropic

        self.debug = debug
        self.api_key = api_key or os.environ.get("ANTHROPIC_API_KEY")
        if self.api_key:
            self.api_key = self.api_key.strip()  # Remove any trailing newlines/whitespace
        if not self.api_key:
            raise ValueError("API key required. Set ANTHROPIC_API_KEY or pass api_key.")

        self.client = Anthropic(api_key=self.api_key)
        self.model = model
        self.domain = domain
        self._custom_vocabulary: list[str] = []

        if self.debug:
            print(f"[DEBUG] ClaudeRefiner initialized: model={model}, domain={domain}")

    def set_domain(self, domain: str) -> None:
        """Switch domain preset."""
        if domain not in DOMAIN_PROMPTS:
            raise ValueError(f"Invalid domain: {domain}. Choose from {list(DOMAIN_PROMPTS.keys())}")
        self.domain = domain

    def load_vocabulary(self, path: str) -> None:
        """Load custom vocabulary from file (one term per line or CSV format)."""
        with open(path, 'r', encoding='utf-8') as f:
            self._custom_vocabulary = [
                line.strip() for line in f
                if line.strip() and not line.strip().startswith('#')
            ]
        if self.debug:
            print(f"[DEBUG] Loaded {len(self._custom_vocabulary)} custom vocabulary entries")

    def load_vocabulary_from_dir(self, name: str) -> bool:
        """
        Load a vocabulary file by name from the vocabularies directory.

        Args:
            name: Vocabulary name (without .txt extension)

        Returns:
            True if loaded successfully, False otherwise.
        """
        vocab_dir = get_vocabularies_dir()
        vocab_path = vocab_dir / f"{name}.txt"

        if vocab_path.exists():
            self.load_vocabulary(str(vocab_path))
            return True
        return False

    def add_vocabulary(self, terms: list[str]) -> None:
        """Add custom vocabulary terms."""
        self._custom_vocabulary.extend(terms)

    def clear_vocabulary(self) -> None:
        """Clear all custom vocabulary terms."""
        self._custom_vocabulary = []

    def _build_system_prompt(self) -> str:
        """Construct system prompt with domain and custom vocabulary."""
        base_prompt = DOMAIN_PROMPTS.get(self.domain, DOMAIN_PROMPTS["general"])

        if self._custom_vocabulary:
            vocab_section = "\n\nAdditional vocabulary to recognize (format: correct term, common misrecognitions):\n"
            vocab_section += "\n".join(self._custom_vocabulary[:200])  # Limit to avoid token overflow
            if len(self._custom_vocabulary) > 200:
                vocab_section += f"\n... and {len(self._custom_vocabulary) - 200} more terms"
            return base_prompt + vocab_section

        return base_prompt

    def refine(self, raw_transcript: str) -> str:
        """Send transcript to Claude for correction."""
        if not raw_transcript.strip():
            return ""

        system_prompt = self._build_system_prompt()

        if self.debug:
            print(f"[DEBUG] Calling Claude API...")
            print(f"[DEBUG] System prompt length: {len(system_prompt)} chars")

        message = self.client.messages.create(
            model=self.model,
            max_tokens=2048,
            system=system_prompt,
            messages=[{"role": "user", "content": raw_transcript}]
        )

        refined = message.content[0].text

        if self.debug:
            print(f"[DEBUG] Claude API returned (repr): {repr(refined)}")
            print(f"[DEBUG] Newline count: {refined.count(chr(10))}")

        # NOTE: We do NOT run post-processing on Claude's output.
        # Claude handles dictation commands correctly, and post-processing
        # can break legitimate text that contains words like "new paragraph".
        # Post-processing is only for fallback when Claude is unavailable.

        return refined

    def refine_without_claude(self, raw_transcript: str) -> str:
        """
        Fallback refinement using only regex post-processing.
        Use this when Claude API is unavailable.
        """
        if not raw_transcript.strip():
            return ""
        return self._apply_dictation_commands(raw_transcript)

    def _apply_dictation_commands(self, text: str) -> str:
        """
        Fallback post-processing for dictation commands.

        Handles cases where Whisper outputs patterns like:
        - ", comma," (punctuation + word + punctuation)
        - "test, period." (word + punctuation + command + punctuation)
        - "comma" (just the word)
        """

        # === NEW PARAGRAPH ===
        # Handle various forms: "new paragraph", ", new paragraph.", etc.
        # Use a marker first, then convert at the end to avoid regex conflicts
        text = re.sub(
            r'[,.]?\s*[Nn]ew [Pp]aragraph[,.]?\s*',
            '{{PARA}}',
            text
        )

        # === NEW LINE ===
        text = re.sub(
            r'[,.]?\s*[Nn]ew [Ll]ine[,.]?\s*',
            '{{NEWLINE}}',
            text
        )

        # === PERIOD ===
        # Handles: "period", ", period", "period.", ", period.", etc.
        # The key insight: remove the word and any adjacent duplicate punctuation,
        # but ensure we end up with exactly one period.
        text = re.sub(
            r'[,\s]*[Pp]eriod[.\s]*',
            '. ',
            text
        )

        # === COMMA ===
        # Handles: "comma", ", comma", "comma,", ", comma,", etc.
        text = re.sub(
            r'[,\s]*[Cc]omma[,\s]*',
            ', ',
            text
        )

        # === QUESTION MARK ===
        text = re.sub(
            r'[,.\s]*[Qq]uestion [Mm]ark[?\s]*',
            '? ',
            text
        )

        # === EXCLAMATION ===
        text = re.sub(
            r'[,.\s]*[Ee]xclamation ([Pp]oint|[Mm]ark)[!\s]*',
            '! ',
            text
        )

        # === COLON ===
        text = re.sub(
            r'[,.\s]*[Cc]olon[:\s]*',
            ': ',
            text
        )

        # === SEMICOLON ===
        text = re.sub(
            r'[,.\s]*[Ss]emicolon[;\s]*',
            '; ',
            text
        )

        # === PARENTHESES ===
        text = re.sub(
            r'[,.\s]*[Oo]pen [Pp]aren(thesis)?[(\s]*',
            ' (',
            text
        )
        text = re.sub(
            r'[)\s]*[Cc]lose [Pp]aren(thesis)?[,.\s]*',
            ') ',
            text
        )

        # === DASH / HYPHEN ===
        text = re.sub(
            r'\s*[Dd]ash\s*',
            '-',
            text
        )
        text = re.sub(
            r'\s*[Hh]yphen\s*',
            '-',
            text
        )

        # === QUOTES ===
        text = re.sub(
            r'[,.\s]*([Oo]pen )?[Qq]uote["\s]*',
            ' "',
            text
        )
        text = re.sub(
            r'["]*\s*([Ee]nd |[Cc]lose )?[Qq]uote[,.\s]*',
            '" ',
            text
        )

        # === CLEANUP ===
        # Fix double punctuation
        text = re.sub(r'\.\.+', '.', text)
        text = re.sub(r',,+', ',', text)
        text = re.sub(r'\?\?+', '?', text)
        text = re.sub(r'!!+', '!', text)

        # Fix comma-period combinations
        text = re.sub(r',\s*\.', '.', text)
        text = re.sub(r'\.\s*,', '.', text)

        # Fix spacing around punctuation
        text = re.sub(r'\s+([.,?!;:])', r'\1', text)  # No space before punctuation
        text = re.sub(r'([.,?!;:])\s*([.,?!;:])', r'\1', text)  # No double punctuation

        # Fix multiple spaces
        text = re.sub(r' +', ' ', text)

        # Fix space at start of lines
        text = re.sub(r'\n +', '\n', text)
        text = re.sub(r' +\n', '\n', text)

        # Fix multiple newlines (more than 2)
        text = re.sub(r'\n{3,}', '\n\n', text)

        # Convert paragraph/line markers to actual newlines
        text = re.sub(r'\s*\{\{PARA\}\}\s*', '\n\n', text)
        text = re.sub(r'\s*\{\{NEWLINE\}\}\s*', '\n', text)

        # If Claude already converted "new paragraph" to a single \n, upgrade to \n\n
        # Pattern: period/question/exclamation followed by single newline (not already double)
        text = re.sub(r'([.?!])\n(?!\n)', r'\1\n\n', text)

        # Capitalize after sentence-ending punctuation
        def capitalize_after_punct(match):
            return match.group(1) + ' ' + match.group(2).upper()

        text = re.sub(r'([.?!])\s+([a-z])', capitalize_after_punct, text)

        # Capitalize start of text
        if text and text[0].islower():
            text = text[0].upper() + text[1:]

        # Capitalize after paragraph breaks
        def capitalize_after_newline(match):
            return match.group(1) + match.group(2).upper()

        text = re.sub(r'(\n\n)([a-z])', capitalize_after_newline, text)

        return text.strip()


def test_dictation_commands():
    """Test the post-processing without hitting the API."""
    refiner = ClaudeRefiner.__new__(ClaudeRefiner)  # Create without __init__

    test_cases = [
        # Input -> Expected output
        (
            "This is going to be a test, comma, more complete than any of the others, period.",
            "This is going to be a test, more complete than any of the others."
        ),
        (
            "I want to test this, comma, produce a document, period. New paragraph. Next section.",
            "I want to test this, produce a document.\n\nNext section."
        ),
        (
            "Do you think it can question mark",
            "Do you think it can?"
        ),
        (
            "First item, comma, second item, comma, third item, period.",
            "First item, second item, third item."
        ),
        (
            "Hello, period, new paragraph, This is new, period.",
            "Hello.\n\nThis is new."
        ),
    ]

    print("Testing _apply_dictation_commands post-processing:\n")
    print("=" * 70)

    all_passed = True
    for raw, expected in test_cases:
        result = refiner._apply_dictation_commands(raw)
        passed = result.strip() == expected.strip()
        status = "✓ PASS" if passed else "✗ FAIL"

        print(f"\nInput:    {raw}")
        print(f"Expected: {expected}")
        print(f"Got:      {result}")
        print(f"Status:   {status}")

        if not passed:
            all_passed = False

    print("\n" + "=" * 70)
    print(f"Overall: {'All tests passed!' if all_passed else 'Some tests failed.'}")
    return all_passed


if __name__ == "__main__":
    import sys
    import argparse

    parser = argparse.ArgumentParser(description="Claude API integration for technical terminology correction")
    parser.add_argument("--test-local", action="store_true", help="Test post-processing regex without API calls")
    parser.add_argument("--debug", action="store_true", help="Enable debug output")
    parser.add_argument("--domain", choices=list(DOMAIN_PROMPTS.keys()), default="general",
                        help="Domain for terminology correction")
    parser.add_argument("--list-vocabs", action="store_true", help="List available vocabulary files")
    parser.add_argument("--download-vocabs", action="store_true", help="Download vocabulary packs from GitHub")
    args = parser.parse_args()

    if args.list_vocabs:
        vocabs = list_available_vocabularies()
        if vocabs:
            print("Available vocabulary files:")
            for v in vocabs:
                print(f"  - {v['name']}: {v['term_count']} terms")
        else:
            print("No vocabulary files found.")
            print(f"Directory: {get_vocabularies_dir()}")
            print("Use --download-vocabs to download vocabulary packs.")
        sys.exit(0)

    if args.download_vocabs:
        print(f"Downloading vocabularies to: {get_vocabularies_dir()}")
        success, message = download_vocabularies(progress_callback=print)
        print(message)
        sys.exit(0 if success else 1)

    if args.test_local:
        # Test just the post-processing regex
        test_dictation_commands()
    else:
        # Full API test
        refiner = ClaudeRefiner(domain=args.domain, debug=args.debug)

        test_inputs = [
            "This is going to be a test, comma, more complete than any of the others, period. I want to be able to test if we can use this for real dictation, comma, produce a natural language document that you can use in email, period. New paragraph. I'm interested to see if Claude can do that, period. Do you think it can? Thank you.",
            "The oh SPF process is not forming adjacencies on V LAN one hundred",
            "Check the B G P neighbor at ten dot zero dot zero dot one slash twenty four",
        ]

        print("Testing Claude refinement with dictation commands...\n")
        print("-" * 60)

        for raw in test_inputs:
            print(f"Raw:\n{raw}\n")
            refined = refiner.refine(raw)
            print(f"Refined:\n{refined}")
            print("-" * 60)