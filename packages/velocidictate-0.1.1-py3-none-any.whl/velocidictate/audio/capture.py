"""
Audio capture module using sounddevice.
"""
import io
import wave
import numpy as np
import sounddevice as sd
from typing import Optional


class AudioRecorder:
    """Records audio from the default microphone."""
    
    def __init__(
        self,
        sample_rate: int = 16000,
        channels: int = 1,
        dtype: str = "float32"
    ):
        self.sample_rate = sample_rate
        self.channels = channels
        self.dtype = dtype
        self._buffer: list[np.ndarray] = []
        self._is_recording = False
        self._stream: Optional[sd.InputStream] = None
    
    def _audio_callback(self, indata: np.ndarray, frames: int, time_info, status):
        """Called by sounddevice for each audio chunk."""
        if status:
            print(f"Audio status: {status}")
        self._buffer.append(indata.copy())
    
    def start_recording(self) -> None:
        """Begin capturing audio."""
        self._buffer = []
        self._is_recording = True
        self._stream = sd.InputStream(
            samplerate=self.sample_rate,
            channels=self.channels,
            dtype=self.dtype,
            callback=self._audio_callback
        )
        self._stream.start()
        print("Recording started... Press Enter to stop.")
    
    def stop_recording(self) -> np.ndarray:
        """Stop capture and return audio as numpy array."""
        if self._stream:
            self._stream.stop()
            self._stream.close()
            self._stream = None
        self._is_recording = False
        
        if not self._buffer:
            return np.array([], dtype=self.dtype)
        
        audio = np.concatenate(self._buffer, axis=0)
        if audio.ndim > 1:
            audio = audio.flatten()
        duration = len(audio) / self.sample_rate
        print(f"Recording stopped. Duration: {duration:.1f}s")
        return audio
    
    def get_audio_bytes(self, audio: np.ndarray) -> bytes:
        """Convert numpy array to WAV bytes for API submission."""
        # Convert float32 [-1, 1] to int16 for WAV
        audio_int16 = (audio * 32767).astype(np.int16)
        
        buffer = io.BytesIO()
        with wave.open(buffer, 'wb') as wf:
            wf.setnchannels(self.channels)
            wf.setsampwidth(2)  # 16-bit
            wf.setframerate(self.sample_rate)
            wf.writeframes(audio_int16.tobytes())
        
        buffer.seek(0)
        return buffer.read()
    
    def save_wav(self, audio: np.ndarray, path: str) -> None:
        """Save audio to WAV file."""
        wav_bytes = self.get_audio_bytes(audio)
        with open(path, 'wb') as f:
            f.write(wav_bytes)
        print(f"Saved to {path}")
    
    @property
    def is_recording(self) -> bool:
        return self._is_recording
    
    @staticmethod
    def list_devices() -> None:
        """Print available audio devices."""
        print(sd.query_devices())


if __name__ == "__main__":
    # Quick test
    recorder = AudioRecorder()
    recorder.list_devices()
    print("\nPress Enter to start recording...")
    input()
    recorder.start_recording()
    input()  # Wait for Enter to stop
    audio = recorder.stop_recording()
    if len(audio) > 0:
        recorder.save_wav(audio, "test_recording.wav")
