"""
Wake word listener for hands-free dictation.
Uses tiny Whisper model for lightweight continuous listening.
"""
import threading
import queue
import time
import numpy as np
import sounddevice as sd
from typing import Optional, Callable
from dataclasses import dataclass


@dataclass
class WakeWordConfig:
    """Configuration for wake word detection."""
    start_phrase: str = "start now"
    end_phrase: str = "stop now"
    chunk_duration: float = 2.5  # seconds per chunk (longer = more context)
    overlap: float = 0.5  # seconds of overlap between chunks
    sample_rate: int = 16000
    # Audio level threshold - RMS below this is considered silence
    # Typical speech is 0.02-0.2, silence is < 0.005
    silence_threshold: float = 0.008
    # Minimum audio level to even attempt transcription
    min_speech_level: float = 0.01
    # Verbose output for debugging
    verbose: bool = False


class WakeWordListener:
    """
    Continuously listens for wake phrases using tiny Whisper model.

    States:
    - IDLE: Not listening
    - LISTENING: Listening for start phrase
    - RECORDING: Recording until end phrase detected
    """

    STATE_IDLE = "idle"
    STATE_LISTENING = "listening"
    STATE_RECORDING = "recording"

    def __init__(
        self,
        whisper_tiny,  # LocalWhisper instance with tiny model
        config: WakeWordConfig = None,
        on_recording_start: Callable = None,
        on_recording_complete: Callable[[np.ndarray], None] = None,
        on_state_change: Callable[[str], None] = None,
    ):
        """
        Initialize wake word listener.

        Args:
            whisper_tiny: LocalWhisper instance (should use tiny model for speed)
            config: WakeWordConfig with phrases and settings
            on_recording_start: Callback when recording starts
            on_recording_complete: Callback with recorded audio when complete
            on_state_change: Callback when state changes
        """
        self.whisper = whisper_tiny
        self.config = config or WakeWordConfig()
        self.on_recording_start = on_recording_start
        self.on_recording_complete = on_recording_complete
        self.on_state_change = on_state_change

        self._state = self.STATE_IDLE
        self._stream: Optional[sd.InputStream] = None
        self._audio_queue: queue.Queue = queue.Queue()
        self._recording_buffer: list[np.ndarray] = []
        self._listen_thread: Optional[threading.Thread] = None
        self._process_thread: Optional[threading.Thread] = None
        self._stop_event = threading.Event()

        # Chunk settings
        self._chunk_samples = int(self.config.chunk_duration * self.config.sample_rate)
        self._overlap_samples = int(self.config.overlap * self.config.sample_rate)

        # Normalize phrases for matching
        self._start_phrase_normalized = self._normalize_phrase(self.config.start_phrase)
        self._end_phrase_normalized = self._normalize_phrase(self.config.end_phrase)

        if self.config.verbose:
            print(f"[WakeWord] Start phrase: '{self.config.start_phrase}' -> {self._start_phrase_normalized}")
            print(f"[WakeWord] End phrase: '{self.config.end_phrase}' -> {self._end_phrase_normalized}")

    @staticmethod
    def _normalize_phrase(phrase: str) -> list[str]:
        """Normalize a phrase into lowercase words for matching."""
        import re
        # Remove punctuation (commas, periods, etc.) and split into words
        # This handles "Okay, start" -> ["okay", "start"]
        # And "o.k. start" -> ["o", "k", "start"] (will be handled by _words_match)
        phrase_clean = re.sub(r'[^\w\s]', ' ', phrase.lower())
        words = phrase_clean.split()

        # Merge standalone 'o' and 'k' into 'ok' (handles "o.k." -> "ok")
        merged = []
        i = 0
        while i < len(words):
            if i < len(words) - 1 and words[i] == 'o' and words[i+1] == 'k':
                merged.append('ok')
                i += 2
            else:
                merged.append(words[i])
                i += 1

        return merged

    @staticmethod
    def _get_audio_level(audio: np.ndarray) -> float:
        """Calculate RMS audio level."""
        if len(audio) == 0:
            return 0.0
        return float(np.sqrt(np.mean(audio ** 2)))

    @property
    def state(self) -> str:
        return self._state

    def _set_state(self, new_state: str) -> None:
        """Update state and notify callback."""
        old_state = self._state
        self._state = new_state
        if self.on_state_change and old_state != new_state:
            self.on_state_change(new_state)

    def _audio_callback(self, indata: np.ndarray, frames: int, time_info, status):
        """Called by sounddevice for each audio chunk."""
        if status:
            print(f"Wake word audio status: {status}")

        # Always add to queue for processing
        self._audio_queue.put(indata.copy())

        # If recording, also save to recording buffer
        if self._state == self.STATE_RECORDING:
            self._recording_buffer.append(indata.copy())

    def _contains_phrase(self, text: str, phrase_words: list[str]) -> bool:
        """
        Check if text contains the phrase using strict word matching.

        Args:
            text: Transcribed text to search in
            phrase_words: Pre-normalized list of words to find

        Returns:
            True if all phrase words appear consecutively in text
        """
        if not phrase_words:
            return False

        # Normalize the transcribed text
        text_words = self._normalize_phrase(text)

        if len(text_words) < len(phrase_words):
            return False

        # Look for exact consecutive word sequence
        for i in range(len(text_words) - len(phrase_words) + 1):
            match = True
            for j, phrase_word in enumerate(phrase_words):
                text_word = text_words[i + j]
                # Require exact match or very close match
                if not self._words_match(text_word, phrase_word):
                    match = False
                    break
            if match:
                return True

        return False

    @staticmethod
    def _words_match(word1: str, word2: str) -> bool:
        """
        Check if two words match (exact or very close).

        Allows for minor variations like:
        - begin/begins/beginning (same root)
        - phrase/phrases
        - ok/okay/o.k. (common variations)
        - start/starts/started
        - stop/stops/stopped
        """
        if word1 == word2:
            return True

        # Normalize common variations
        word1_norm = word1.lower().strip()
        word2_norm = word2.lower().strip()

        # Handle ok/okay/o.k. specifically
        ok_variants = {'ok', 'okay', 'o', 'k'}  # 'o' and 'k' for "o.k." split
        if word1_norm in ok_variants and word2_norm in ok_variants:
            return True

        # Both normalize to same thing
        if word1_norm == word2_norm:
            return True

        # Check if one is a prefix of the other (handles plurals, verb forms)
        # e.g., start/starts/started, stop/stops/stopped
        # But require at least 3 chars to avoid false positives
        min_len = min(len(word1_norm), len(word2_norm))
        if min_len >= 3:
            # One word starts with the other
            if word1_norm.startswith(word2_norm) or word2_norm.startswith(word1_norm):
                return True

        return False

    def _is_whisper_hallucination(self, text: str) -> bool:
        """
        Check if the text is likely a Whisper hallucination.

        Whisper tends to output certain phrases when given silence/noise.
        We only filter the most obvious/common hallucinations to avoid
        filtering real speech.
        """
        text_lower = text.lower().strip()

        # Only filter the most common/obvious hallucination patterns
        hallucination_phrases = [
            "thank you for watching",
            "thanks for watching",
            "subscribe",
            "like and subscribe",
            "please subscribe",
            "[music]",
            "(music)",
            "[applause]",
            "(applause)",
        ]

        for phrase in hallucination_phrases:
            if phrase in text_lower:
                return True

        # Check for very short text (1-2 chars is likely noise)
        if len(text_lower) <= 2:
            return True

        # Check for just ellipsis
        if text_lower in ('...', '..', '.'):
            return True

        return False

    def _process_audio_loop(self):
        """Background thread: process audio chunks for wake word detection."""
        chunk_buffer = []

        while not self._stop_event.is_set():
            try:
                # Get audio from queue with timeout
                audio_chunk = self._audio_queue.get(timeout=0.1)

                # Flatten immediately to ensure consistent 1D arrays
                if audio_chunk.ndim > 1:
                    audio_chunk = audio_chunk.flatten()

                chunk_buffer.append(audio_chunk)

                # Calculate total samples in buffer
                total_samples = sum(len(c) for c in chunk_buffer)

                # Process when we have enough audio
                if total_samples >= self._chunk_samples:
                    # Concatenate (all chunks are now 1D)
                    audio = np.concatenate(chunk_buffer, axis=0)

                    # Take chunk_samples worth
                    process_audio = audio[:self._chunk_samples]

                    # Keep overlap for next iteration
                    keep_samples = max(0, total_samples - self._chunk_samples + self._overlap_samples)
                    if keep_samples > 0:
                        chunk_buffer = [audio[-keep_samples:]]
                    else:
                        chunk_buffer = []

                    # Check audio level before transcribing
                    audio_level = self._get_audio_level(process_audio)

                    if audio_level < self.config.silence_threshold:
                        # Too quiet - skip transcription entirely
                        continue

                    if audio_level < self.config.min_speech_level:
                        # Probably just noise, skip
                        if self.config.verbose:
                            print(f"[WakeWord] Audio level {audio_level:.4f} below speech threshold, skipping")
                        continue

                    # Transcribe
                    try:
                        text = self.whisper.transcribe(process_audio)

                        # Filter out likely hallucinations
                        if text.strip() and not self._is_whisper_hallucination(text):
                            self._handle_transcription(text, process_audio)
                        elif text.strip() and self.config.verbose:
                            print(f"[WakeWord] Filtered hallucination: '{text}'")

                    except Exception as e:
                        print(f"Wake word transcription error: {e}")

            except queue.Empty:
                continue
            except Exception as e:
                print(f"Wake word processing error: {e}")

    def _handle_transcription(self, text: str, audio: np.ndarray):
        """Handle transcribed text based on current state."""
        text = text.strip()
        if not text:
            return

        if self.config.verbose:
            print(f"[WakeWord] Heard: '{text}' (state: {self._state})")

        if self._state == self.STATE_LISTENING:
            # Look for start phrase
            if self._contains_phrase(text, self._start_phrase_normalized):
                print(f"[WakeWord] >>> Start phrase detected! <<<")
                self._recording_buffer = []
                self._set_state(self.STATE_RECORDING)
                if self.on_recording_start:
                    self.on_recording_start()

        elif self._state == self.STATE_RECORDING:
            # Look for end phrase
            if self._contains_phrase(text, self._end_phrase_normalized):
                print(f"[WakeWord] >>> End phrase detected! <<<")
                self._complete_recording()

    def _complete_recording(self):
        """Finalize recording and call completion callback."""
        if not self._recording_buffer:
            self._set_state(self.STATE_LISTENING)
            return

        # Concatenate all recorded audio
        audio = np.concatenate(self._recording_buffer, axis=0)
        if audio.ndim > 1:
            audio = audio.flatten()

        # Strip the end phrase audio (approximately last chunk)
        # This removes "end phrase" from the recording
        strip_samples = int(self.config.chunk_duration * self.config.sample_rate)
        if len(audio) > strip_samples * 2:
            audio = audio[:-strip_samples]

        # Clear buffer and return to listening
        self._recording_buffer = []
        self._set_state(self.STATE_LISTENING)

        # Deliver the recording
        if self.on_recording_complete:
            self.on_recording_complete(audio)

    def start_listening(self) -> None:
        """Start listening for wake word."""
        if self._state != self.STATE_IDLE:
            return

        self._stop_event.clear()
        self._audio_queue = queue.Queue()
        self._recording_buffer = []

        # Start audio stream
        self._stream = sd.InputStream(
            samplerate=self.config.sample_rate,
            channels=1,
            dtype="float32",
            callback=self._audio_callback,
            blocksize=int(self.config.sample_rate * 0.1)  # 100ms blocks
        )
        self._stream.start()

        # Start processing thread
        self._process_thread = threading.Thread(target=self._process_audio_loop, daemon=True)
        self._process_thread.start()

        self._set_state(self.STATE_LISTENING)
        print(f"[WakeWord] Listening for '{self.config.start_phrase}'...")

    def stop_listening(self) -> None:
        """Stop listening entirely."""
        self._stop_event.set()

        if self._stream:
            self._stream.stop()
            self._stream.close()
            self._stream = None

        if self._process_thread:
            self._process_thread.join(timeout=2.0)
            self._process_thread = None

        self._recording_buffer = []
        self._set_state(self.STATE_IDLE)

    def cancel_recording(self) -> None:
        """Cancel current recording and return to listening."""
        if self._state == self.STATE_RECORDING:
            self._recording_buffer = []
            self._set_state(self.STATE_LISTENING)

    def force_stop_recording(self) -> Optional[np.ndarray]:
        """
        Force stop recording and return audio (for manual override).
        Returns the recorded audio without waiting for end phrase.
        """
        if self._state != self.STATE_RECORDING:
            return None

        if not self._recording_buffer:
            self._set_state(self.STATE_LISTENING)
            return None

        audio = np.concatenate(self._recording_buffer, axis=0)
        if audio.ndim > 1:
            audio = audio.flatten()

        self._recording_buffer = []
        self._set_state(self.STATE_LISTENING)

        return audio

    @staticmethod
    def calibrate(duration: float = 3.0, sample_rate: int = 16000) -> dict:
        """
        Calibrate audio levels by measuring ambient noise.

        Records for `duration` seconds and returns statistics about
        the audio levels detected. Use this to set appropriate
        silence_threshold and min_speech_level values.

        Args:
            duration: How long to record (seconds)
            sample_rate: Audio sample rate

        Returns:
            dict with 'min', 'max', 'mean', 'recommended_silence',
            'recommended_speech' levels
        """
        print(f"\n[Calibration] Recording {duration}s of ambient noise...")
        print("[Calibration] Please remain quiet...")

        audio_chunks = []

        def callback(indata, frames, time_info, status):
            audio_chunks.append(indata.copy())

        stream = sd.InputStream(
            samplerate=sample_rate,
            channels=1,
            dtype="float32",
            callback=callback,
            blocksize=int(sample_rate * 0.1)
        )

        import time
        stream.start()
        time.sleep(duration)
        stream.stop()
        stream.close()

        if not audio_chunks:
            print("[Calibration] No audio captured!")
            return {}

        # Concatenate and analyze
        audio = np.concatenate(audio_chunks, axis=0)
        if audio.ndim > 1:
            audio = audio.flatten()

        # Calculate RMS for overlapping windows
        window_size = int(sample_rate * 0.5)  # 500ms windows
        step_size = int(sample_rate * 0.1)    # 100ms steps

        levels = []
        for i in range(0, len(audio) - window_size, step_size):
            window = audio[i:i + window_size]
            rms = float(np.sqrt(np.mean(window ** 2)))
            levels.append(rms)

        if not levels:
            levels = [float(np.sqrt(np.mean(audio ** 2)))]

        min_level = min(levels)
        max_level = max(levels)
        mean_level = sum(levels) / len(levels)
        std_level = float(np.std(levels))

        # Recommended thresholds:
        # silence_threshold should be above the max ambient noise
        # min_speech_level should be well above that
        recommended_silence = max_level * 1.5
        recommended_speech = max_level * 2.5

        results = {
            'min': min_level,
            'max': max_level,
            'mean': mean_level,
            'std': std_level,
            'recommended_silence': recommended_silence,
            'recommended_speech': recommended_speech,
        }

        print(f"\n[Calibration] Results:")
        print(f"  Ambient noise range: {min_level:.4f} - {max_level:.4f}")
        print(f"  Ambient noise mean:  {mean_level:.4f} (std: {std_level:.4f})")
        print(f"\n[Calibration] Recommended settings:")
        print(f"  silence_threshold: {recommended_silence:.4f}")
        print(f"  min_speech_level:  {recommended_speech:.4f}")

        return results


# Convenience function for testing
def test_wake_word():
    """Test the wake word listener from command line."""
    import argparse

    parser = argparse.ArgumentParser(description="Test wake word listener")
    parser.add_argument("--calibrate", action="store_true", help="Run calibration first")
    parser.add_argument("--silence", type=float, default=0.008, help="Silence threshold")
    parser.add_argument("--speech", type=float, default=0.01, help="Min speech level")
    args = parser.parse_args()

    silence_threshold = args.silence
    min_speech_level = args.speech

    # Run calibration if requested
    if args.calibrate:
        results = WakeWordListener.calibrate(duration=3.0)
        if results:
            silence_threshold = results['recommended_silence']
            min_speech_level = results['recommended_speech']
            print(f"\nUsing calibrated values:")
            print(f"  silence_threshold: {silence_threshold:.4f}")
            print(f"  min_speech_level:  {min_speech_level:.4f}")
        print("\nNow loading Whisper model...")

    from velocidictate.transcription import LocalWhisper

    print("Loading tiny Whisper model for wake word detection...")
    whisper = LocalWhisper(model_size="tiny", device="cpu")

    # Force load the model
    whisper._ensure_loaded()

    config = WakeWordConfig(
        start_phrase="start now",
        end_phrase="stop now",
        chunk_duration=2.5,
        overlap=0.5,
        silence_threshold=silence_threshold,
        min_speech_level=min_speech_level
    )

    results = []

    def on_start():
        print("\n" + "=" * 50)
        print("RECORDING STARTED - Speak now!")
        print("Say 'end phrase' when done")
        print("=" * 50 + "\n")

    def on_complete(audio):
        print("\n" + "=" * 50)
        print(f"RECORDING COMPLETE - {len(audio) / 16000:.1f} seconds")
        print("=" * 50 + "\n")
        results.append(audio)

    def on_state(state):
        print(f"[State changed to: {state}]")

    listener = WakeWordListener(
        whisper_tiny=whisper,
        config=config,
        on_recording_start=on_start,
        on_recording_complete=on_complete,
        on_state_change=on_state
    )

    print("\n" + "=" * 60)
    print("Wake Word Listener Test")
    print("=" * 60)
    print(f"Start phrase: '{config.start_phrase}'")
    print(f"End phrase: '{config.end_phrase}'")
    print(f"Silence threshold: {config.silence_threshold:.4f}")
    print(f"Min speech level: {config.min_speech_level:.4f}")
    print("\nSay 'begin phrase' to start recording")
    print("Say 'end phrase' to stop recording")
    print("Press Ctrl+C to quit")
    print("=" * 60 + "\n")

    listener.start_listening()

    try:
        while True:
            time.sleep(0.5)
            if results:
                # Transcribe the result with a better model
                print("\nTranscribing captured audio...")
                main_whisper = LocalWhisper(model_size="small", device="cpu")
                text = main_whisper.transcribe(results[-1])
                print(f"\nFinal transcription:\n{text}\n")
                results.clear()
    except KeyboardInterrupt:
        print("\nShutting down...")
    finally:
        listener.stop_listening()


if __name__ == "__main__":
    test_wake_word()