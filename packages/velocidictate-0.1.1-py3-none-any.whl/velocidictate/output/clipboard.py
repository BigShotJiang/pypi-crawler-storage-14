"""
Output module for clipboard operations and auto-paste.
"""
import sys
import time
import pyperclip


def copy_to_clipboard(text: str) -> None:
    """Copy text to system clipboard."""
    pyperclip.copy(text)
    print(f"Copied to clipboard ({len(text)} chars)")


def get_clipboard() -> str:
    """Get current clipboard contents."""
    return pyperclip.paste()


def paste_from_clipboard() -> bool:
    """
    Simulate Ctrl+V (or Cmd+V on Mac) to paste clipboard contents.

    Returns:
        True if paste was attempted, False if dependencies missing
    """
    # Small delay to ensure the app is ready to receive input
    time.sleep(0.15)

    # Try xdotool first on Linux (most reliable, no X11 issues)
    if sys.platform.startswith('linux'):
        try:
            import subprocess
            result = subprocess.run(
                ['xdotool', 'key', '--clearmodifiers', 'ctrl+v'],
                check=True,
                capture_output=True
            )
            return True
        except FileNotFoundError:
            print("xdotool not found. Install with: sudo apt install xdotool")
        except subprocess.CalledProcessError as e:
            print(f"xdotool error: {e}")

    # Try pyautogui
    try:
        import pyautogui
        # Disable fail-safe for headless/tray apps
        pyautogui.FAILSAFE = False

        if sys.platform == "darwin":
            # macOS: Cmd+V
            pyautogui.hotkey('command', 'v')
        else:
            # Windows/Linux: Ctrl+V
            pyautogui.hotkey('ctrl', 'v')

        return True

    except ImportError:
        print("pyautogui not installed")
    except Exception as e:
        print(f"pyautogui error: {e}")

    # Try pynput as fallback
    try:
        from pynput.keyboard import Controller, Key

        keyboard = Controller()

        if sys.platform == "darwin":
            # macOS: Cmd+V
            with keyboard.pressed(Key.cmd):
                keyboard.press('v')
                keyboard.release('v')
        else:
            # Windows/Linux: Ctrl+V
            with keyboard.pressed(Key.ctrl):
                keyboard.press('v')
                keyboard.release('v')

        return True

    except ImportError:
        print("pynput not installed")
    except Exception as e:
        print(f"pynput error: {e}")

    print("Warning: No paste method available.")
    print("  Linux: Install xdotool (sudo apt install xdotool)")
    print("  Or: pip install pyautogui (requires python3-tk python3-dev)")
    return False


def copy_and_paste(text: str) -> bool:
    """
    Copy text to clipboard and immediately paste it.

    Args:
        text: Text to copy and paste

    Returns:
        True if paste was successful
    """
    copy_to_clipboard(text)
    success = paste_from_clipboard()
    if success:
        print("Pasted!")
    return success


if __name__ == "__main__":
    # Quick test
    test_text = "Hello from VelociDictate!"
    print(f"Testing copy and paste with: '{test_text}'")
    print("Focus on a text field within 3 seconds...")
    time.sleep(3)
    success = copy_and_paste(test_text)
    print(f"Paste successful: {success}")