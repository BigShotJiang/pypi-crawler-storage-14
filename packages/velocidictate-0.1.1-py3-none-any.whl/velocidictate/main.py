#!/usr/bin/env python3
"""
VelociDictate - AI-Powered Technical Dictation
Phase 1: CLI Prototype

Usage:
    python main.py                    # Interactive mode
    python main.py --test-whisper     # Test Whisper only
    python main.py --test-claude      # Test Claude only
    python main.py --list-devices     # List audio devices
"""
import argparse
import os

from velocidictate.audio import AudioRecorder
from velocidictate.transcription import LocalWhisper
from velocidictate.refinement import ClaudeRefiner
from velocidictate.output import copy_to_clipboard


def check_api_key() -> bool:
    """Check if Claude API key is configured."""
    if os.environ.get("ANTHROPIC_API_KEY"):
        return True
    print("WARNING: ANTHROPIC_API_KEY not set. Claude refinement will fail.")
    print("Set it with: export ANTHROPIC_API_KEY='your-key-here'")
    return False


def run_dictation(
    whisper_model: str = "small",
    domain: str = "networking",
    skip_refinement: bool = False,
    vocabulary_file: str = None
) -> None:
    """
    Main dictation loop.
    
    Press Enter to start recording, Enter again to stop.
    Transcribes with Whisper, refines with Claude, copies to clipboard.
    """
    print("\n" + "=" * 60)
    print("VelociDictate - Technical Dictation Tool")
    print("=" * 60)
    
    # Initialize components
    print(f"\nInitializing Whisper ({whisper_model} model)...")
    whisper = LocalWhisper(model_size=whisper_model)
    
    refiner = None
    if not skip_refinement and check_api_key():
        print(f"Initializing Claude refiner ({domain} domain)...")
        refiner = ClaudeRefiner(domain=domain)
        if vocabulary_file and os.path.exists(vocabulary_file):
            refiner.load_vocabulary(vocabulary_file)
    
    recorder = AudioRecorder()
    
    print("\n" + "-" * 60)
    print("Ready! Press Enter to start recording, Enter again to stop.")
    print("Type 'quit' or 'q' to exit.")
    print("-" * 60)
    
    while True:
        user_input = input("\n> ").strip().lower()
        
        if user_input in ('quit', 'q', 'exit'):
            print("Goodbye!")
            break
        
        # Start recording
        recorder.start_recording()
        input()  # Wait for Enter to stop
        audio = recorder.stop_recording()
        
        if len(audio) == 0:
            print("No audio captured.")
            continue
        
        # Transcribe with Whisper
        print("\nTranscribing with Whisper...")
        raw_transcript = whisper.transcribe(audio)
        print(f"\nRaw transcript:\n  {raw_transcript}")
        
        if not raw_transcript.strip():
            print("No speech detected.")
            continue
        
        # Refine with Claude
        final_text = raw_transcript
        if refiner:
            print("\nRefining with Claude...")
            final_text = refiner.refine(raw_transcript)
            print(f"\nRefined transcript:\n  {final_text}")
        
        # Copy to clipboard
        copy_to_clipboard(final_text)
        print("\n✓ Ready to paste (Ctrl+V)")


def test_whisper(model: str = "small") -> None:
    """Test Whisper transcription with a recording."""
    print(f"Testing Whisper ({model} model)...")
    
    recorder = AudioRecorder()
    whisper = LocalWhisper(model_size=model)
    
    print("\nPress Enter to start recording...")
    input()
    recorder.start_recording()
    print("Recording... Press Enter to stop.")
    input()
    audio = recorder.stop_recording()
    
    if len(audio) > 0:
        print("\nTranscribing...")
        text = whisper.transcribe(audio)
        print(f"\nTranscript:\n{text}")
    else:
        print("No audio captured.")


def test_claude() -> None:
    """Test Claude refinement with sample inputs."""
    if not check_api_key():
        return
    
    refiner = ClaudeRefiner(domain="networking")
    
    test_inputs = [
        "The oh SPF process is not forming adjacencies on V LAN one hundred",
        "Check the B G P neighbor at ten dot zero dot zero dot one slash twenty four",
        "We need to configure S N M P on the Cisco switches",
        "The I S I S routing protocol uses area zero",
        "Configure a V R F called management on the Arista switch"
    ]
    
    print("Testing Claude refinement...\n")
    print("-" * 60)
    
    for raw in test_inputs:
        print(f"Raw:     {raw}")
        refined = refiner.refine(raw)
        print(f"Refined: {refined}")
        print("-" * 60)


def list_audio_devices() -> None:
    """List available audio input devices."""
    AudioRecorder.list_devices()


def main():
    parser = argparse.ArgumentParser(
        description="VelociDictate - AI-Powered Technical Dictation"
    )
    parser.add_argument(
        "--model", "-m",
        default="small",
        choices=["tiny", "base", "small", "medium", "large-v3"],
        help="Whisper model size (default: small)"
    )
    parser.add_argument(
        "--domain", "-d",
        default="networking",
        choices=["networking", "development", "general"],
        help="Technical domain for Claude refinement (default: networking)"
    )
    parser.add_argument(
        "--vocabulary", "-v",
        help="Path to custom vocabulary file"
    )
    parser.add_argument(
        "--no-refine",
        action="store_true",
        help="Skip Claude refinement (Whisper only)"
    )
    parser.add_argument(
        "--test-whisper",
        action="store_true",
        help="Test Whisper transcription only"
    )
    parser.add_argument(
        "--test-claude",
        action="store_true",
        help="Test Claude refinement only"
    )
    parser.add_argument(
        "--list-devices",
        action="store_true",
        help="List available audio devices"
    )
    
    args = parser.parse_args()
    
    if args.list_devices:
        list_audio_devices()
    elif args.test_whisper:
        test_whisper(args.model)
    elif args.test_claude:
        test_claude()
    else:
        run_dictation(
            whisper_model=args.model,
            domain=args.domain,
            skip_refinement=args.no_refine,
            vocabulary_file=args.vocabulary
        )


if __name__ == "__main__":
    main()
