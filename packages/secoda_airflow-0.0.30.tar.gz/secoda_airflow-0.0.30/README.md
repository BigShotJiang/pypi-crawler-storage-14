# Start

```bash
docker-composer up
```

Navigate to http://localhost:8080/

# Configuration

You need to add the snowflake connection to Airflow.

Go to: http://localhost:8080/connection/add

- Connection Id: snowflake
- Connection Type: Snowflake
- Make sure you add the credentials too!

# Secoda

Add the Airflow integration to Secoda using these settings:

- Connection Type: API
- API Host: http://localhost:8080/
- User: admin
- Password: admin
