#!/usr/bin/env python
# -*- coding:utf-8 -*-
# Author: qicongsheng
from mecho import client
from mecho import server


def server_start():
    server.start()


def client_start():
    client.start()


if __name__ == "__main__":
    server_start()
