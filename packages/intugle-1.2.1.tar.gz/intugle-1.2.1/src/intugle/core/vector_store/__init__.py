from intugle.core.vector_store.qdrant import AsyncQdrantService, VDocument

VectorStoreService = AsyncQdrantService
VDocument = VDocument