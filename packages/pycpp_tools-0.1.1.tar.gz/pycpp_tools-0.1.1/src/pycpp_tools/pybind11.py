import subprocess
import os
import sys


def pybind11_init(project_name="demo"):
    print("pybind11 initialization...")
    if os.path.exists("CMakeLists.txt"):
        print("init failed cause cmake file already exists")
        return
    if os.path.isdir("src"):
        print("init failed cause src directory already exists")
        return
    with open("CMakeLists.txt", "w") as f:
        f.write("cmake_minimum_required(VERSION 3.30)\n")
        f.write(f"\nset(project_name {project_name})\n")
        f.write("project(${project_name})\n")
        f.write("\nset(CMAKE_CXX_STANDARD 23)\n")
        f.write("set(CMAKE_CXX_STANDARD_REQUIRED ON)\n")
        py_dir = os.path.dirname(os.path.realpath(sys.executable))
        py_dir = py_dir.replace("\\", "/")
        f.write(f"\nset(py_dir {py_dir})\n")
        f.write("list(APPEND CMAKE_PREFIX_PATH ${py_dir})\n")
        f.write(
            "list(APPEND CMAKE_PREFIX_PATH ${py_dir}/Lib/site-packages/pybind11/share/cmake/pybind11)\n"
        )
        f.write("find_package(Python3 COMPONENTS Interpreter Development REQUIRED)\n")
        f.write("find_package(pybind11 REQUIRED)\n")
        f.write('\nfile(GLOB src_files "src/*.cpp")\n')
        f.write("\npybind11_add_module(${project_name} ${src_files})\n")
        f.write(
            "target_include_directories(${project_name} PRIVATE ${pybind11_INCLUDE_DIRS} src)\n"
        )

    os.makedirs("src")

    with open("src/pywrapper.cpp", "w") as f:
        f.write("#include <pybind11/pybind11.h>\n")
        f.write(f"\n\nPYBIND11_MODULE({project_name}, m) {{\n")
        f.write(f'    m.doc() = "{project_name} module";\n')
        f.write("}\n")

    with open(f"test.py", "w") as f:
        f.write("import sys\n")
        f.write('sys.path.extend(["build","build/Debug","build/Release"])\n')
        f.write(f"import {project_name}\n")
        f.write(f"\nprint({project_name}.__doc__)\n")

    os.makedirs(".vscode")
    with open(".vscode/launch.json", "w") as f:
        s = r"""
{
    // Use IntelliSense to learn about possible attributes.
    // Hover to view descriptions of existing attributes.
    // For more information, visit: https://go.microsoft.com/fwlink/?linkid=830387
    "version": "0.2.0",
    "configurations": [

        {
            "name": "pybind11: test",
            "type": "debugpy",
            "request": "launch",
            "program": "test.py",
            "console": "integratedTerminal",
            "preLaunchTask": "CMake: build"
        }
    ]
}"""

        f.write(s)
        print("pybind11 init finished!")
