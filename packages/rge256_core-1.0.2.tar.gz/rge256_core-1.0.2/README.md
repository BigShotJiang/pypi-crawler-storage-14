# RGE256 Core – Python Implementation of the RGE-256 PRNG

Version 1.0.2
Author: Steven Reid
License: Apache 2.0
Project: https://github.com/RRG314/RGE-256-app
Preprint: https://zenodo.org/records/17713219

## Security Notice
Not cryptographically secure. Use only for testing, research, simulation.

## Installation
```
pip install rge256_core
```

## Basic Usage
```python
from rge256_core import RGE256
rng = RGE256(seed=123)
rng.rand_uint32()
rng.random()
rng.randint(0,10)
rng.random_array(5)
rng.random_bytes(8)
```
