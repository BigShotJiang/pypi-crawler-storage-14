# TanMesh

**TanMesh** is a Tor-routed, P2P, end-to-end encrypted messenger core written in Python.

It provides:

- Long-term X25519 static identities (`node_id = SHA256(static_pub)`).
- Ephemeral X25519 keys per connection.
- HKDF-based root and chain keys.
- AES-GCM per-message encryption with padding and associated data (message counter).
- Optional embedded Tor instance that exposes your node as a v3 onion service.
- A minimal CLI chat interface for power users.

> ⚠️ **Security disclaimer**
>
> This is a research / hacker-grade tool. While the design uses strong primitives,
> it has not undergone formal security audits. Do **not** assume it is unbreakable.
> Use at your own risk.

## Installation

```bash
pip install tanmesh

