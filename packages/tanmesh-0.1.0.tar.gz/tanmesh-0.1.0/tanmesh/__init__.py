"""
tanmesh: Tor-routed P2P end-to-end encrypted messenger core.

This package exposes the TanMeshNode and related helpers so you can embed
TANmesh into other Python applications, or use the `tanmesh` CLI for
standalone operation.
"""

from .core import (
    TanMeshNode,
    PeerConnection,
    start_tor_if_needed,
    stop_tor,
    open_connection_via_tor,
    load_or_create_identity,
    APP_DIR,
    IDENTITY_FILE,
    CONTACTS_FILE,
)

__all__ = [
    "TanMeshNode",
    "PeerConnection",
    "start_tor_if_needed",
    "stop_tor",
    "open_connection_via_tor",
    "load_or_create_identity",
    "APP_DIR",
    "IDENTITY_FILE",
    "CONTACTS_FILE",
]

