#!/usr/bin/env python3
import argparse
import asyncio
import base64
import errno
import json
import os
import signal
import sys
import socket
import subprocess
import time
import shutil
from dataclasses import dataclass, field
from datetime import datetime, timezone
from hashlib import sha256
from pathlib import Path
from typing import Dict, Optional, Tuple

from cryptography.hazmat.primitives.asymmetric import x25519
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.kdf.hkdf import HKDF
from cryptography.hazmat.primitives.ciphers.aead import AESGCM

# ----------------- paths & globals -----------------

APP_DIR = Path.home() / ".tanmesh"
IDENTITY_FILE = APP_DIR / "identity.json"
CONTACTS_FILE = APP_DIR / "contacts.json"

# These are initialised lazily when Tor is started
TOR_DIR: Optional[Path] = None
TOR_HS_DIR: Optional[Path] = None

# Tor SOCKS host; port can be auto-chosen
TOR_SOCKS_HOST = os.environ.get("TANMESH_TOR_SOCKS_HOST", "127.0.0.1")
_env_port = os.environ.get("TANMESH_TOR_SOCKS_PORT")
TOR_SOCKS_PORT: Optional[int] = int(_env_port) if _env_port else None

TOR_PROCESS: Optional[subprocess.Popen] = None
ONION_HOSTNAME: Optional[str] = None


# ----------------- helpers -----------------

def b64e(b: bytes) -> str:
    return base64.b64encode(b).decode("ascii")


def b64d(s: str) -> bytes:
    return base64.b64decode(s.encode("ascii"))


def save_json(path: Path, data: dict):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, sort_keys=True)


def load_json(path: Path, default=None):
    if not path.exists():
        return default
    with path.open("r", encoding="utf-8") as f:
        return json.load(f)


def load_or_create_identity(name: Optional[str]):
    """
    Long-term static identity:
      - static X25519 keypair
      - node_id = SHA256(static_pub)

    On load, we *re-derive* static_public and node_id from static_private
    to prevent tampering with identity.json.
    """
    APP_DIR.mkdir(parents=True, exist_ok=True)
    ident = load_json(IDENTITY_FILE, None)

    static_priv = None
    priv_bytes: Optional[bytes] = None

    if ident is not None:
        try:
            priv_bytes = b64d(ident["static_private"])
            static_priv = x25519.X25519PrivateKey.from_private_bytes(priv_bytes)
        except Exception:
            print(
                "[!] Identity file is corrupted or invalid; generating a new identity.",
                file=sys.stderr,
            )
            ident = None

    if ident is None:
        static_priv = x25519.X25519PrivateKey.generate()
        priv_bytes = static_priv.private_bytes(
            encoding=serialization.Encoding.Raw,
            format=serialization.PrivateFormat.Raw,
            encryption_algorithm=serialization.NoEncryption(),
        )
        ident_name = name or "anon"
    else:
        ident_name = name or ident.get("name") or "anon"

    static_pub = static_priv.public_key()
    pub_bytes = static_pub.public_bytes(
        encoding=serialization.Encoding.Raw,
        format=serialization.PublicFormat.Raw,
    )
    node_id = sha256(pub_bytes).hexdigest()

    ident = {
        "name": ident_name,
        "node_id": node_id,
        "static_private": b64e(priv_bytes),
        "static_public": b64e(pub_bytes),
    }
    save_json(IDENTITY_FILE, ident)
    return ident


def hkdf(ikm: bytes, length: int, info: bytes, salt: Optional[bytes] = None) -> bytes:
    h = HKDF(
        algorithm=hashes.SHA256(),
        length=length,
        salt=salt,
        info=info,
    )
    return h.derive(ikm)


def derive_session_state(
    local_node_id: str,
    remote_node_id: str,
    static_priv: x25519.X25519PrivateKey,
    eph_priv: x25519.X25519PrivateKey,
    remote_static_pub: x25519.X25519PublicKey,
    remote_eph_pub: x25519.X25519PublicKey,
    salt: Optional[bytes] = None,
) -> Tuple[bytes, bytes, bytes]:
    """
    Symmetric session state derivation.

    Both sides compute the *same set* of DH values, sort them as raw bytes,
    and concatenate into IKM so order doesn't depend on initiator/responder.

    Returns (root_key, send_chain_key, recv_chain_key).
    """
    dh_ss = static_priv.exchange(remote_static_pub)
    dh_se = static_priv.exchange(remote_eph_pub)
    dh_es = eph_priv.exchange(remote_static_pub)
    dh_ee = eph_priv.exchange(remote_eph_pub)

    parts = sorted([dh_ss, dh_se, dh_es, dh_ee])
    ikm = b"".join(parts)

    root_key = hkdf(ikm, 32, b"tanmesh/root", salt=salt)

    ck_material = hkdf(root_key, 64, b"tanmesh/chains")
    ck_ab = ck_material[:32]
    ck_ba = ck_material[32:]
    a, b = sorted([local_node_id, remote_node_id])
    if local_node_id == a:
        send_ck = ck_ab
        recv_ck = ck_ba
    else:
        send_ck = ck_ba
        recv_ck = ck_ab
    return root_key, send_ck, recv_ck


def next_chain_key(chain_key: bytes) -> Tuple[bytes, bytes]:
    """Given current chain key, derive (new_chain_key, msg_key)."""
    out = hkdf(chain_key, 64, b"tanmesh/msg")
    new_ck = out[:32]
    msg_key = out[32:]
    return new_ck, msg_key


# ----------------- Tor management -----------------


def _pick_free_port() -> int:
    s = socket.socket()
    s.bind((TOR_SOCKS_HOST, 0))
    port = s.getsockname()[1]
    s.close()
    return port


def refresh_onion_hostname() -> Optional[str]:
    """Try to read the onion hostname from the hidden service dir."""
    global ONION_HOSTNAME, TOR_HS_DIR
    if ONION_HOSTNAME:
        return ONION_HOSTNAME
    if TOR_HS_DIR is None:
        return None
    hostname_path = TOR_HS_DIR / "hostname"
    if hostname_path.exists():
        try:
            ONION_HOSTNAME = hostname_path.read_text(encoding="utf-8").strip()
        except Exception:
            pass
    return ONION_HOSTNAME


def start_tor_if_needed(app_port: int, node_id: Optional[str] = None):
    """
    Start a private Tor instance in the background with:
      - its own DataDirectory under ~/.tanmesh/tor-<node_id_prefix>
      - SOCKSPort on localhost (random or env override)
      - a v3 hidden service exposing app_port on 127.0.0.1:app_port
    """
    global TOR_PROCESS, TOR_SOCKS_PORT, ONION_HOSTNAME, TOR_DIR, TOR_HS_DIR

    if TOR_PROCESS is not None:
        return  # already running

    if shutil.which("tor") is None:
        print(
            "[!] 'tor' executable not found in PATH. "
            "Install Tor or set TANMESH_TOR_SOCKS_PORT to use an external Tor.",
            file=sys.stderr,
        )
        return

    # Per-identity Tor directory
    suffix = (node_id or f"port{app_port}")[:16]
    TOR_DIR = APP_DIR / f"tor-{suffix}"
    TOR_HS_DIR = TOR_DIR / "hidden_service"

    TOR_DIR.mkdir(parents=True, exist_ok=True)
    TOR_HS_DIR.mkdir(parents=True, exist_ok=True)

    # Tor is picky about permissions: must be 0700 or it will exit.
    os.chmod(TOR_DIR, 0o700)
    os.chmod(TOR_HS_DIR, 0o700)

    if TOR_SOCKS_PORT is None:
        TOR_SOCKS_PORT = _pick_free_port()

    torrc_path = TOR_DIR / "torrc"
    with torrc_path.open("w", encoding="utf-8") as f:
        f.write(f'DataDirectory "{str(TOR_DIR)}"\n')
        f.write(f'SOCKSPort {TOR_SOCKS_HOST}:{TOR_SOCKS_PORT}\n')
        f.write(f'HiddenServiceDir "{str(TOR_HS_DIR)}"\n')
        f.write("HiddenServiceVersion 3\n")
        f.write(f"HiddenServicePort {app_port} 127.0.0.1:{app_port}\n")

    log_path = TOR_DIR / "tor.log"
    log_file = open(log_path, "ab", buffering=0)

    print(f"[i] Starting embedded Tor (SOCKS {TOR_SOCKS_HOST}:{TOR_SOCKS_PORT})...")
    print("[i] Waiting for Tor to bootstrap and create the hidden service...")
    TOR_PROCESS = subprocess.Popen(
        ["tor", "-f", str(torrc_path)],
        stdout=log_file,
        stderr=log_file,
    )

    # Wait for SOCKS port to be ready
    deadline = time.time() + 60.0
    last_msg_time = 0.0
    while time.time() < deadline:
        if TOR_PROCESS.poll() is not None:
            print(
                f"[!] Tor exited unexpectedly. See log: {log_path}",
                file=sys.stderr,
            )
            TOR_PROCESS = None
            return
        try:
            with socket.create_connection((TOR_SOCKS_HOST, TOR_SOCKS_PORT), timeout=1.0):
                print(f"[i] Tor SOCKS is up at {TOR_SOCKS_HOST}:{TOR_SOCKS_PORT}")
                break
        except OSError:
            now = time.time()
            if now - last_msg_time > 5.0:
                print("[i] Tor bootstrapping... (waiting for SOCKS port)")
                last_msg_time = now
            time.sleep(0.5)
    else:
        print("[!] Timed out waiting for Tor SOCKS port.", file=sys.stderr)
        return

    # Try to read the hidden service hostname
    hostname_path = TOR_HS_DIR / "hostname"
    deadline = time.time() + 60.0
    last_msg_time = 0.0
    while time.time() < deadline:
        if TOR_PROCESS.poll() is not None:
            print(
                f"[!] Tor exited unexpectedly while creating hidden service. See log: {log_path}",
                file=sys.stderr,
            )
            TOR_PROCESS = None
            return
        if hostname_path.exists():
            try:
                ONION_HOSTNAME = hostname_path.read_text(encoding="utf-8").strip()
                print(f"[i] Tor hidden service is ready: {ONION_HOSTNAME}")
            except Exception:
                pass
            break
        now = time.time()
        if now - last_msg_time > 5.0:
            print("[i] Tor bootstrapping... (waiting for hidden service hostname)")
            last_msg_time = now
        time.sleep(1.0)


def stop_tor():
    """Terminate the embedded Tor process if running."""
    global TOR_PROCESS
    if TOR_PROCESS is None:
        return
    print("[i] Stopping embedded Tor...")
    try:
        TOR_PROCESS.terminate()
        TOR_PROCESS.wait(timeout=5.0)
    except Exception:
        try:
            TOR_PROCESS.kill()
        except Exception:
            pass
    TOR_PROCESS = None


# ----------------- Tor SOCKS connector -----------------


async def open_connection_via_tor(
    host: str,
    port: int,
    socks_host: str,
    socks_port: int,
) -> Tuple[asyncio.StreamReader, asyncio.StreamWriter]:
    """
    Minimal SOCKS5 client to talk to Tor's SOCKS port.
    """
    try:
        reader, writer = await asyncio.open_connection(socks_host, socks_port)
    except OSError as e:
        raise RuntimeError(
            f"Could not connect to Tor SOCKS at {socks_host}:{socks_port}: {e}"
        ) from e

    # SOCKS5 greeting: version=5, nmethods=1, method=0 (no auth)
    writer.write(b"\x05\x01\x00")
    await writer.drain()
    resp = await reader.readexactly(2)
    if resp[0] != 5 or resp[1] != 0:
        writer.close()
        try:
            await writer.wait_closed()
        except Exception:
            pass
        raise RuntimeError("SOCKS5 server does not accept no-auth")

    # Build CONNECT request
    host_bytes = host.encode("idna")
    if len(host_bytes) > 255:
        writer.close()
        try:
            await writer.wait_closed()
        except Exception:
            pass
        raise ValueError("Hostname too long for SOCKS5")

    # ver=5, cmd=1 (CONNECT), rsv=0, atyp=3 (domain), len(host), host, port
    req = (
        b"\x05\x01\x00\x03"
        + bytes([len(host_bytes)])
        + host_bytes
        + port.to_bytes(2, "big")
    )
    writer.write(req)
    await writer.drain()

    # Response: ver, rep, rsv, atyp, bnd.addr, bnd.port
    header = await reader.readexactly(4)
    ver, rep, rsv, atyp = header
    if ver != 5 or rep != 0:
        reasons = {
            1: "general SOCKS server failure",
            2: "connection not allowed by ruleset",
            3: "network unreachable",
            4: "host unreachable",
            5: "connection refused by destination",
            6: "TTL expired",
            7: "command not supported",
            8: "address type not supported",
        }
        reason = reasons.get(rep, "unknown error")
        writer.close()
        try:
            await writer.wait_closed()
        except Exception:
            pass
        raise RuntimeError(f"SOCKS5 CONNECT failed (rep={rep}: {reason})")

    # Consume bound address (we don't care about it)
    if atyp == 1:  # IPv4
        await reader.readexactly(4 + 2)
    elif atyp == 3:  # domain
        ln = await reader.readexactly(1)
        dom_len = ln[0]
        await reader.readexactly(dom_len + 2)
    elif atyp == 4:  # IPv6
        await reader.readexactly(16 + 2)
    else:
        writer.close()
        try:
            await writer.wait_closed()
        except Exception:
            pass
        raise RuntimeError("Unknown ATYP in SOCKS5 response")

    return reader, writer


# ----------------- contact book -----------------


def load_contacts():
    return load_json(CONTACTS_FILE, {})


def save_contacts(contacts):
    save_json(CONTACTS_FILE, contacts)


def add_contact_entry(alias: str, node_id: str, address: str, port: int):
    contacts = load_contacts()
    contacts[alias] = {
        "node_id": node_id,
        "address": address,
        "port": port,
    }
    save_contacts(contacts)


def find_contact(alias_or_node_id: str):
    contacts = load_contacts()
    if alias_or_node_id in contacts:
        return contacts[alias_or_node_id]
    for alias, data in contacts.items():
        if data.get("node_id") == alias_or_node_id:
            return data
    return None

def list_contacts():
    contacts = load_contacts()
    if not contacts:
        print("[i] No saved contacts yet. Use /add-contact to add one.")
        return
    print("Saved contacts:")
    for alias, c in contacts.items():
        nid = c.get("node_id", "")[:8]
        addr = c.get("address", "?")
        port = c.get("port", "?")
        print(f"  {alias:12s} {nid}  {addr}:{port}")


def delete_contact(alias: str):
    contacts = load_contacts()
    if alias not in contacts:
        print(f"[!] No contact with alias '{alias}'")
        return
    contacts.pop(alias)
    save_contacts(contacts)
    print(f"[i] Deleted contact '{alias}'")


# ----------------- peer / session logic -----------------


@dataclass
class PeerConnection:
    reader: asyncio.StreamReader
    writer: asyncio.StreamWriter
    local_name: str
    local_node_id: str
    static_priv: x25519.X25519PrivateKey
    static_pub: x25519.X25519PublicKey

    # handshake / identity
    local_eph_priv: x25519.X25519PrivateKey = field(init=False)
    local_eph_pub: x25519.X25519PublicKey = field(init=False)
    remote_name: Optional[str] = None
    remote_node_id: Optional[str] = None
    remote_static_pub: Optional[x25519.X25519PublicKey] = None
    remote_eph_pub: Optional[x25519.X25519PublicKey] = None
    handshake_sent: bool = False
    handshake_received: bool = False

    # session crypto
    root_key: Optional[bytes] = None
    send_chain_key: Optional[bytes] = None
    recv_chain_key: Optional[bytes] = None
    send_counter: int = 0
    recv_counter: int = 0
    established: bool = False
    pending_rekey: bool = False

    # misc
    index: int = 0
    expected_remote_node_id: Optional[str] = None
    expected_alias: Optional[str] = None

    def __post_init__(self):
        self.local_eph_priv = x25519.X25519PrivateKey.generate()
        self.local_eph_pub = self.local_eph_priv.public_key()

    def peer_label(self) -> str:
        nid = self.remote_node_id[:8] if self.remote_node_id else "????????"
        nm = self.remote_name or "?"
        return f"{nm} ({nid})"

    async def send_json(self, obj: dict):
        line = json.dumps(obj).encode("utf-8") + b"\n"
        self.writer.write(line)
        await self.writer.drain()

    # ----- handshake -----

    async def send_handshake(self):
        if self.handshake_sent:
            return
        static_pub_bytes = self.static_pub.public_bytes(
            encoding=serialization.Encoding.Raw,
            format=serialization.PublicFormat.Raw,
        )
        eph_pub_bytes = self.local_eph_pub.public_bytes(
            encoding=serialization.Encoding.Raw,
            format=serialization.PublicFormat.Raw,
        )
        msg = {
            "type": "handshake",
            "version": 1,
            "node_id": self.local_node_id,
            "name": self.local_name,
            "static": b64e(static_pub_bytes),
            "ephemeral": b64e(eph_pub_bytes),
        }
        await self.send_json(msg)
        self.handshake_sent = True

    async def handle_handshake(self, msg: dict):
        try:
            static_bytes = b64d(msg["static"])
            eph_bytes = b64d(msg["ephemeral"])
            claimed_node_id = msg["node_id"]
        except KeyError as e:
            print(
                f"[!] Incomplete handshake from peer {self.index}: missing {e}",
                file=sys.stderr,
            )
            raise RuntimeError("Invalid handshake") from e

        computed_node_id = sha256(static_bytes).hexdigest()
        if computed_node_id != claimed_node_id:
            print(
                f"[!] Identity binding failure for peer {self.index}: "
                f"claimed node_id {claimed_node_id} but static_pub hashes to {computed_node_id}",
                file=sys.stderr,
            )
            raise RuntimeError("Remote identity binding failed")

        if (
            self.expected_remote_node_id is not None
            and claimed_node_id != self.expected_remote_node_id
        ):
            label = f"alias '{self.expected_alias}'" if self.expected_alias else "saved contact"
            print(
                f"[!] Remote identity mismatch for peer {self.index}: "
                f"handshake node_id {claimed_node_id} does not match {label} node_id "
                f"{self.expected_remote_node_id}. Possible MITM or wrong contact – closing.",
                file=sys.stderr,
            )
            raise RuntimeError("Remote identity does not match expected contact")

        self.remote_name = msg.get("name") or "?"
        self.remote_node_id = claimed_node_id
        self.remote_static_pub = x25519.X25519PublicKey.from_public_bytes(static_bytes)
        self.remote_eph_pub = x25519.X25519PublicKey.from_public_bytes(eph_bytes)
        self.handshake_received = True

        if not self.handshake_sent:
            await self.send_handshake()

        self.maybe_establish()

    # ----- key derivation -----

    def _derive_new_session_keys(self, salt: Optional[bytes]):
        if (
            self.remote_node_id is None
            or self.remote_static_pub is None
            or self.remote_eph_pub is None
        ):
            print(
                f"[!] Cannot derive session keys, missing remote info for peer {self.index}",
                file=sys.stderr,
            )
            return
        root_key, send_ck, recv_ck = derive_session_state(
            self.local_node_id,
            self.remote_node_id,
            self.static_priv,
            self.local_eph_priv,
            self.remote_static_pub,
            self.remote_eph_pub,
            salt=salt,
        )
        self.root_key = root_key
        self.send_chain_key = send_ck
        self.recv_chain_key = recv_ck
        self.send_counter = 0
        self.recv_counter = 0

    def maybe_establish(self):
        if self.established:
            return
        if not (self.handshake_sent and self.handshake_received):
            return
        assert self.remote_node_id is not None
        assert self.remote_static_pub is not None
        assert self.remote_eph_pub is not None

        self._derive_new_session_keys(salt=None)
        if self.root_key is None:
            return
        self.established = True
        print(f"[+] Secure session established with peer {self.index}: {self.peer_label()}")

    # ----- PFS rekey -----

    async def initiate_rekey(self):
        if not self.established:
            print(
                f"[!] Cannot rekey, session not established with peer {self.index}",
                file=sys.stderr,
            )
            return
        if self.pending_rekey:
            print(
                f"[i] Rekey already in progress with peer {self.index}",
                file=sys.stderr,
            )
            return
        self.local_eph_priv = x25519.X25519PrivateKey.generate()
        self.local_eph_pub = self.local_eph_priv.public_key()
        eph_pub_bytes = self.local_eph_pub.public_bytes(
            encoding=serialization.Encoding.Raw,
            format=serialization.PublicFormat.Raw,
        )
        msg = {
            "type": "rekey",
            "ephemeral": b64e(eph_pub_bytes),
        }
        self.pending_rekey = True
        await self.send_json(msg)
        print(f"[i] Sent rekey request to peer {self.index}: {self.peer_label()}")

    async def handle_rekey(self, msg: dict):
        if not self.established:
            print(
                f"[!] Got rekey from non-established peer {self.index}",
                file=sys.stderr,
            )
            return
        self.remote_eph_pub = x25519.X25519PublicKey.from_public_bytes(
            b64d(msg["ephemeral"])
        )
        self.local_eph_priv = x25519.X25519PrivateKey.generate()
        self.local_eph_pub = self.local_eph_priv.public_key()
        if self.root_key is None:
            print(
                f"[!] No root key for rekey with peer {self.index}",
                file=sys.stderr,
            )
            return
        self._derive_new_session_keys(salt=self.root_key)
        eph_pub_bytes = self.local_eph_pub.public_bytes(
            encoding=serialization.Encoding.Raw,
            format=serialization.PublicFormat.Raw,
        )
        ack = {
            "type": "rekey-ack",
            "ephemeral": b64e(eph_pub_bytes),
        }
        await self.send_json(ack)
        self.pending_rekey = False
        print(
            f"[i] Session rekeyed (responded) with peer {self.index}: {self.peer_label()}",
        )

    async def handle_rekey_ack(self, msg: dict):
        if not self.established:
            print(
                f"[!] Got rekey-ack from non-established peer {self.index}",
                file=sys.stderr,
            )
            return
        self.remote_eph_pub = x25519.X25519PublicKey.from_public_bytes(
            b64d(msg["ephemeral"])
        )
        if self.root_key is None:
            print(
                f"[!] No root key for rekey-ack with peer {self.index}",
                file=sys.stderr,
            )
            return
        self._derive_new_session_keys(salt=self.root_key)
        self.pending_rekey = False
        print(
            f"[i] Session rekeyed (initiator) with peer {self.index}: {self.peer_label()}",
        )

    # ----- chat frames -----

    async def send_chat(self, text: str):
        if not self.established:
            print(
                f"[!] Session not yet established with peer {self.index}",
                file=sys.stderr,
            )
            return
        assert self.send_chain_key is not None
        self.send_chain_key, msg_key = next_chain_key(self.send_chain_key)
        nonce = os.urandom(12)
        payload = {
            "type": "chat",
            "text": text,
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }
        payload_bytes = json.dumps(payload).encode("utf-8")
        prefix = len(payload_bytes).to_bytes(4, "big")
        plaintext = prefix + payload_bytes
        pad_to = ((len(plaintext) + 255) // 256) * 256
        if pad_to > len(plaintext):
            plaintext = plaintext + os.urandom(pad_to - len(plaintext))
        aad = f"{self.send_counter}".encode("ascii")
        aesgcm = AESGCM(msg_key)
        ct = aesgcm.encrypt(nonce, plaintext, aad)
        frame = {
            "type": "ciphertext",
            "counter": self.send_counter,
            "nonce": b64e(nonce),
            "ciphertext": b64e(ct),
        }
        self.send_counter += 1
        await self.send_json(frame)

    async def handle_ciphertext(self, msg: dict):
        if not self.established:
            print(
                f"[!] Got ciphertext before session established from peer {self.index}",
                file=sys.stderr,
            )
            return
        assert self.recv_chain_key is not None
        ctr = msg["counter"]
        if ctr != self.recv_counter:
            print(
                f"[!] Dropping out-of-order message from peer {self.index}: "
                f"got {ctr}, expected {self.recv_counter}",
                file=sys.stderr,
            )
            return
        nonce = b64d(msg["nonce"])
        ct = b64d(msg["ciphertext"])
        self.recv_chain_key, msg_key = next_chain_key(self.recv_chain_key)
        aad = f"{self.recv_counter}".encode("ascii")
        aesgcm = AESGCM(msg_key)
        try:
            plaintext = aesgcm.decrypt(nonce, ct, aad)
        except Exception as e:
            print(
                f"[!] Decryption failed from peer {self.index}: {e}",
                file=sys.stderr,
            )
            return
        self.recv_counter += 1
        try:
            if len(plaintext) < 4:
                raise ValueError("plaintext too short")
            plen = int.from_bytes(plaintext[:4], "big")
            payload_bytes = plaintext[4:4 + plen]
            payload = json.loads(payload_bytes.decode("utf-8"))
        except Exception:
            print(
                f"[!] Could not parse message payload from peer {self.index}",
                file=sys.stderr,
            )
            return
        if payload.get("type") == "chat":
            ts = payload.get("timestamp", "?")
            txt = payload.get("text", "")
            print(f"[{ts}] <peer {self.index} {self.peer_label()}> {txt}")
        else:
            print(f"[peer {self.index}] Received unknown payload: {payload}")

    async def run(self):
        try:
            await self.send_handshake()
            while True:
                line = await self.reader.readline()
                if not line:
                    print(f"[i] Peer {self.index} disconnected: {self.peer_label()}")
                    break
                try:
                    msg = json.loads(line.decode("utf-8"))
                except json.JSONDecodeError:
                    print(
                        f"[!] Invalid JSON from peer {self.index}",
                        file=sys.stderr,
                    )
                    continue
                mtype = msg.get("type")
                try:
                    if mtype == "handshake":
                        await self.handle_handshake(msg)
                    elif mtype == "ciphertext":
                        await self.handle_ciphertext(msg)
                    elif mtype == "rekey":
                        await self.handle_rekey(msg)
                    elif mtype == "rekey-ack":
                        await self.handle_rekey_ack(msg)
                    else:
                        print(
                            f"[!] Unknown message type from peer {self.index}: {mtype}",
                            file=sys.stderr,
                        )
                except RuntimeError as e:
                    print(
                        f"[i] Closing connection to peer {self.index} due to error: {e}",
                        file=sys.stderr,
                    )
                    break
        finally:
            self.writer.close()
            try:
                await self.writer.wait_closed()
            except Exception:
                pass


# ----------------- node / CLI -----------------


class TanMeshNode:
    def __init__(self, name: Optional[str], port: int):
        ident = load_or_create_identity(name)
        self.name = ident["name"]
        self.node_id = ident["node_id"]
        self.static_priv = x25519.X25519PrivateKey.from_private_bytes(
            b64d(ident["static_private"])
        )
        self.static_pub = self.static_priv.public_key()
        self.port = port
        self.peers: Dict[int, PeerConnection] = {}
        self._next_index = 0
        self.server = None

    async def _watch_onion_hostname(self):
        """
        Background watcher: if Tor is running and the onion hostname appears later,
        print it immediately for the user.
        """
        global ONION_HOSTNAME, TOR_HS_DIR
        if TOR_HS_DIR is None:
            return
        hostname_path = TOR_HS_DIR / "hostname"
        for _ in range(120):
            if hostname_path.exists():
                try:
                    ONION_HOSTNAME = hostname_path.read_text(encoding="utf-8").strip()
                    if ONION_HOSTNAME:
                        print(f"[i] Tor hidden service is ready: {ONION_HOSTNAME}")
                except Exception:
                    pass
                return
            await asyncio.sleep(1.0)

    async def start(self):
        loop = asyncio.get_running_loop()
        self.server = await asyncio.start_server(
            self._handle_incoming, "127.0.0.1", self.port
        )
        addr = ", ".join(str(sock.getsockname()) for sock in self.server.sockets)

        refresh_onion_hostname()

        print("======================================================")
        print(" TanMesh secure P2P messenger (Tor + PFS demo)")
        print("======================================================")
        print(f" Name        : {self.name}")
        print(f" Node ID     : {self.node_id}")
        print(f" Local bind  : {addr}")

        if ONION_HOSTNAME:
            print(f" Onion addr  : {ONION_HOSTNAME}")
            print("   → Share this .onion + your Node ID with friends.")
        elif TOR_PROCESS is not None:
            print(" Onion addr  : (bootstrapping Tor hidden service... will print when ready)")
            loop.create_task(self._watch_onion_hostname())
        else:
            print(" Onion addr  : (Tor not running; using direct /connect only)")

        print()
        self._print_help()
        loop.create_task(self._user_input_loop())

        async with self.server:
            await self.server.serve_forever()

    def _print_help(self):
        print(" Commands:")
        print("   /peers                              - list connected peers")
        print("   /contacts                           - list saved contacts")
        print("   /connect host port                  - direct connect (IP/DNS)  [NOT anonymous]")
        print("   /connect-id <alias|node_id>         - connect to a saved contact (uses .onion if set)")
        print("   /add-contact alias id addr [port]   - save contact (addr usually .onion, default port 9999)")
        print("   /del-contact alias                  - delete a saved contact")
        print("   /msg <peer_index> message           - send message to peer")
        print("   /msgall message                     - broadcast message to all peers")
        print("   /rekey <peer_index>                 - rekey session with peer")
        print("   /whoami                             - show your identity and onion (if any)")
        print("   /help                               - show this help")
        print("   /quit                               - exit")
        print("------------------------------------------------------")

    async def _handle_incoming(
        self, reader: asyncio.StreamReader, writer: asyncio.StreamWriter
    ):
        idx = self._next_index
        self._next_index += 1
        conn = PeerConnection(
            reader=reader,
            writer=writer,
            local_name=self.name,
            local_node_id=self.node_id,
            static_priv=self.static_priv,
            static_pub=self.static_pub,
            index=idx,
        )
        self.peers[idx] = conn
        print(f"[i] Incoming connection -> peer {idx}")
        await conn.run()
        self.peers.pop(idx, None)

    async def connect_raw(
        self,
        host: str,
        port: int,
        expected_remote_node_id: Optional[str] = None,
        alias: Optional[str] = None,
    ):
        global TOR_SOCKS_PORT
        try:
            if host.endswith(".onion"):
                if TOR_SOCKS_PORT is None:
                    print(
                        "[!] Tor SOCKS is not available; cannot connect to .onion.",
                        file=sys.stderr,
                    )
                    return
                print(
                    f"[i] Connecting to {host}:{port} via Tor SOCKS at "
                    f"{TOR_SOCKS_HOST}:{TOR_SOCKS_PORT}"
                )
                reader, writer = await open_connection_via_tor(
                    host, port, TOR_SOCKS_HOST, TOR_SOCKS_PORT
                )
            else:
                print(
                    f"[i] Direct TCP connect to {host}:{port} (IP visible)",
                )
                reader, writer = await asyncio.open_connection(host, port)
        except Exception as e:
            print(f"[!] Could not connect to {host}:{port}: {e}", file=sys.stderr)
            return
        idx = self._next_index
        self._next_index += 1
        conn = PeerConnection(
            reader=reader,
            writer=writer,
            local_name=self.name,
            local_node_id=self.node_id,
            static_priv=self.static_priv,
            static_pub=self.static_pub,
            index=idx,
            expected_remote_node_id=expected_remote_node_id,
            expected_alias=alias,
        )
        self.peers[idx] = conn
        print(f"[i] Outgoing connection -> peer {idx} at {host}:{port}")
        asyncio.create_task(conn.run())

    async def connect_by_id(self, alias_or_node_id: str):
        entry = find_contact(alias_or_node_id)
        if not entry:
            print(
                f"[!] No contact found for '{alias_or_node_id}'. Use /add-contact first.",
                file=sys.stderr,
            )
            return
        addr = entry.get("address")
        port = entry.get("port")
        expected_id = entry.get("node_id")
        if addr is None or port is None:
            print(
                f"[!] Contact entry for '{alias_or_node_id}' missing address/port.",
                file=sys.stderr,
            )
            return
        await self.connect_raw(
            addr,
            int(port),
            expected_remote_node_id=expected_id,
            alias=alias_or_node_id,
        )

    def _print_whoami(self):
        print("------------------------------------------------------")
        print(f" Name        : {self.name}")
        print(f" Node ID     : {self.node_id}")
        print(f" Listen port : {self.port}")
        if ONION_HOSTNAME:
            print(f" Onion addr  : {ONION_HOSTNAME}")
        else:
            print(" Onion addr  : (none / Tor not running)")
        print("------------------------------------------------------")

    async def _user_input_loop(self):
        loop = asyncio.get_running_loop()
        while True:
            line = await loop.run_in_executor(None, sys.stdin.readline)
            if not line:
                continue
            line = line.strip()
            if not line:
                continue
            if line.startswith("/"):
                parts = line.split()
                cmd = parts[0]
                if cmd == "/peers":
                    if not self.peers:
                        print("[i] No peers connected.")
                    else:
                        print("Connected peers:")
                        for idx, conn in self.peers.items():
                            print(f"  [{idx}] {conn.peer_label()}")
                elif cmd == "/contacts":
                    list_contacts()
                elif cmd == "/connect" and len(parts) == 3:
                    ...
                elif cmd == "/connect-id" and len(parts) == 2:
                    await self.connect_by_id(parts[1])
                elif cmd == "/add-contact" and len(parts) >= 4:
                    alias = parts[1]
                    node_id = parts[2]
                    addr = parts[3]
                    if len(parts) >= 5:
                        try:
                            port = int(parts[4])
                        except ValueError:
                            print("[!] Invalid port in /add-contact.")
                            continue
                    else:
                        port = 9999
                    add_contact_entry(alias, node_id, addr, port)
                    print(f"[i] Saved contact '{alias}' for node {node_id} at {addr}:{port}")
                elif cmd == "/del-contact" and len(parts) == 2:
                    delete_contact(parts[1])
                elif cmd == "/msg" and len(parts) >= 3:
                    try:
                        idx = int(parts[1])
                    except ValueError:
                        print("[!] Usage: /msg <peer_index> message")
                        continue
                    if idx not in self.peers:
                        print(f"[!] No such peer index {idx}")
                        continue
                    msg = " ".join(parts[2:])
                    await self.peers[idx].send_chat(msg)
                elif cmd == "/msgall" and len(parts) >= 2:
                    msg = " ".join(parts[1:])
                    if not self.peers:
                        print("[i] No peers to broadcast to.")
                        continue
                    for idx, peer in list(self.peers.items()):
                        await peer.send_chat(msg)
                elif cmd == "/rekey" and len(parts) == 2:
                    try:
                        idx = int(parts[1])
                    except ValueError:
                        print("[!] Usage: /rekey <peer_index>")
                        continue
                    if idx not in self.peers:
                        print(f"[!] No such peer index {idx}")
                        continue
                    await self.peers[idx].initiate_rekey()
                elif cmd == "/whoami":
                    self._print_whoami()
                elif cmd == "/help":
                    self._print_help()
                elif cmd == "/quit":
                    print("[i] Exiting...")
                    for conn in list(self.peers.values()):
                        conn.writer.close()
                    stop_tor()
                    os._exit(0)
                else:
                    print("[i] Unknown command. Use /help for a list of commands.")
            else:
                print(
                    "[i] Use commands like /peers, /connect, /connect-id, /add-contact, /msg, /msgall, /rekey, /whoami, /quit"
                )


# ----------------- process / entrypoint -----------------


async def shutdown(loop: asyncio.AbstractEventLoop, sig):
    print(f"[i] Caught signal {sig.name}: shutting down...")
    tasks = [t for t in asyncio.all_tasks(loop) if t is not asyncio.current_task(loop)]
    for t in tasks:
        t.cancel()
    await asyncio.gather(*tasks, return_exceptions=True)
    stop_tor()
    loop.stop()


def main():
    parser = argparse.ArgumentParser(
        description="TanMesh – Tor-routed P2P end-to-end encrypted messenger (demo)"
    )
    parser.add_argument("--name", help="display name", default=None)
    parser.add_argument(
        "--port",
        type=int,
        default=9999,
        help="port to listen on locally (Tor hidden service will map to this)",
    )
    parser.add_argument(
        "--no-embedded-tor",
        action="store_true",
        help="do not start embedded Tor; expect an external Tor SOCKS at TANMESH_TOR_SOCKS_HOST/PORT",
    )
    args = parser.parse_args()

    node = TanMeshNode(args.name, args.port)

    # Start embedded Tor (if requested and available)
    if not args.no_embedded_tor and TOR_SOCKS_PORT is None:
        start_tor_if_needed(args.port, node.node_id)
    else:
        if args.no_embedded_tor:
            print(
                f"[i] Using external Tor SOCKS at {TOR_SOCKS_HOST}:{TOR_SOCKS_PORT} (no embedded Tor)."
            )

    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)

    for sig in (signal.SIGINT, signal.SIGTERM):
        try:
            loop.add_signal_handler(
                sig, lambda s=sig: asyncio.ensure_future(shutdown(loop, s))
            )
        except (NotImplementedError, AttributeError):
            pass

    try:
        loop.run_until_complete(node.start())
    finally:
        stop_tor()
        loop.close()


if __name__ == "__main__":
    main()
