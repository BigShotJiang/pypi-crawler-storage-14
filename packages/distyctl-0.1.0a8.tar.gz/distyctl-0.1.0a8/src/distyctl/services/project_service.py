from pathlib import Path
from typing import Optional
from distyctl.libs.framework_installer import FrameworkInstaller
from distyctl.libs.github_client import GithubClient
from distyctl.services.lock_service import LockService
from distyctl.types import VersionLiteral


class ProjectService:
    """ """

    def __init__(self, target_path: Path):
        self.lock_service = LockService(target_path)
        self.github_client = GithubClient()
        self.framework_installer = FrameworkInstaller(target_path)
        self.target_path = target_path

    def intialize_new_game(self, initial_version: Optional[VersionLiteral] = None):
        version: str
        if initial_version is None:
            if self.lock_service.is_locked():
                version = self.lock_service.get_locked_version()

            else:
                version = self.github_client.get_latest_release_version()
        else:
            version = initial_version

        framework_asset = self.github_client.get_framework_asset_by_version(version)

        self.framework_installer.install(framework_asset)
        self.lock_service.lock_version(version)
        # TODO: add .disty-craft to .gitignore
        # TODO: setup tooling

    def is_initialized(self):
        raise NotImplementedError()
