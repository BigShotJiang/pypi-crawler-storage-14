from typing import Optional


class BrokenFrameworkVersion(Exception):
    """Raised when the requested framework version is broken or unusable."""

    def __init__(
        self,
        version: str,
        reason: Optional[str] = None,
        issue_url: Optional[str] = None,
    ):
        self.version = version
        self.reason = reason
        self.issue_url = issue_url
        msg = f"Framework version '{version}' is broken."
        if reason:
            msg += f" Reason: {reason}"
        if issue_url:
            msg += f" See: {issue_url}"
        super().__init__(msg)


class LockFileFormatError(Exception):
    """Raised when the lock file is malformed or unreadable."""

    pass
