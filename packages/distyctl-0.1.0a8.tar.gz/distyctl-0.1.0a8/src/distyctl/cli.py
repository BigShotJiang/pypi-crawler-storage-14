import typer
from distyctl.commands import cmd_init, cmd_dev, cmd_render

app = typer.Typer()

# register subcommands
app.add_typer(cmd_init.app)
app.add_typer(cmd_dev.app)
app.add_typer(cmd_render.app)

if __name__ == "__main__":
    app()
