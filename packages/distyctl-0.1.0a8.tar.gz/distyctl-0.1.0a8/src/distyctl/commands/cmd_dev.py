import typer

app = typer.Typer(help="Start the development server")


@app.command(help="Start development mode with hot reload")
def dev():
    """
    Start the development server.

    This command will run the game with automatic reload when source
    files change.
    """
    # typer.echo(f"Running dev server on port {port}, debug={debug}")
    raise NotImplementedError()
