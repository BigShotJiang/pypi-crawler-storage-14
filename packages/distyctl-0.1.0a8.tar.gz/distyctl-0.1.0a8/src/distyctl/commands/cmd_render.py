from typing import Annotated, Literal
import typer


app = typer.Typer(help="Prepare the game for deployment")

ModeLiteral = Literal["platform", "standalone"]


@app.command(
    help="Prepares either a standalone deployable game or a game ready to deploy to the Distyopoly platform."
)
def render(mode: Annotated[ModeLiteral, typer.Argument()] = "standalone"):
    """ """
    # typer.echo(f"Running dev server on port {port}, debug={debug}")
    raise NotImplementedError()
