from pathlib import Path
from typing import Annotated, Optional
import typer

from distyctl.services.project_service import ProjectService
from distyctl.types import VersionLiteral

app = typer.Typer(help="Initialize the project environment and files")


@app.command(help="Start development mode with hot reload")
def init(
    target_path: Annotated[
        Path,
        typer.Argument(
            show_default=False,
            default_factory=Path.cwd,
            exists=True,
            file_okay=False,
            dir_okay=True,
            resolve_path=True,
            writable=True,
        ),
    ],
    version: Annotated[Optional[VersionLiteral], typer.Option()] = None,
):
    """ """
    ProjectService(target_path).intialize_new_game(version)
