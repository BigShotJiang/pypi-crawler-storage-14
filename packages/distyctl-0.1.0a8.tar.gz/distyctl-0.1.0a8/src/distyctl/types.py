from typing import TypeAlias


VersionLiteral: TypeAlias = str # what if new release was not added to the supported list?
# VersionLiteral = Literal["v0.0.1-alpha.5"]
