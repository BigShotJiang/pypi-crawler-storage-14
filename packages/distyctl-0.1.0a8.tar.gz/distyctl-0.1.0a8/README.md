[![Checked with pyright](https://microsoft.github.io/pyright/img/pyright_badge.svg)](https://microsoft.github.io/pyright/)

# Distyctl

Utility program for Distyopoly game developers.

## Usage:

**Creating a new project:**
```bash
distyctl init [target_path] [--version VERSION]
```

This command makes the framework available.

---

Planned features:

```
distyctl dev

distyctl render standalone/platform
```


## Contributing

```bash
# Bumps the version and creates  
cz bump

# push the created tag
git push origin [TAGNAME]
```