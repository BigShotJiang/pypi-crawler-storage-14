"""
Cointegration Regression with I(1) and I(2) Variables
======================================================

This module implements OLS cointegration regression as described in
Section 3 of Haldrup (1994).

The general regression model is:
    y_t = β̂'₀c_t + β̂'₁x_{1t} + β̂'₂x_{2t} + û_t

where:
- c_t: Deterministic components (constant, trend, etc.)
- x_{1t}: I(1) regressors
- x_{2t}: I(2) regressors

Reference
---------
Haldrup, N. (1994). The asymptotics of single-equation cointegration 
regressions with I(1) and I(2) variables. Journal of Econometrics, 
63(1), 153-181.

Notes
-----
From Theorem 1 (p. 160): The integration order d of the conditional model
determines the behavior of OLS estimates:
- d = 0 (full cointegration): β̂₂ is O_p(n^{-2})-consistent, β̂₁ is O_p(n^{-1})-consistent
- d = 1 (partial cointegration): β̂₂ is O_p(n^{-1})-consistent, β̂₁ is nondegenerate
- d = 2 (no cointegration): Spurious regression, F-test diverges O_p(n)
"""

from dataclasses import dataclass, field
from typing import Optional, Tuple, Union, List, Dict
import numpy as np
from numpy.typing import ArrayLike
from scipy import stats

from haldrup.cointegration_tests import adf_test, HaldrupCointegrationResult
from haldrup.diagnostics import durbin_watson, r_squared


@dataclass
class CointegrationRegressionResult:
    """
    Result container for cointegration regression.
    
    Attributes
    ----------
    coefficients : np.ndarray
        Estimated coefficients (deterministic, I(1), I(2) in order).
    std_errors : np.ndarray
        Standard errors of coefficients.
    t_statistics : np.ndarray
        t-statistics for coefficients.
    residuals : np.ndarray
        Regression residuals û_t.
    fitted_values : np.ndarray
        Fitted values ŷ_t.
    r_squared : float
        Coefficient of determination R².
    adj_r_squared : float
        Adjusted R².
    durbin_watson : float
        Durbin-Watson statistic.
    sigma : float
        Standard error of regression.
    n : int
        Number of observations.
    k : int
        Number of regressors.
    m1 : int
        Number of I(1) regressors.
    m2 : int
        Number of I(2) regressors.
    deterministic : str
        Deterministic specification.
    variable_names : List[str]
        Names of variables.
    cointegration_test : HaldrupCointegrationResult or None
        Results of cointegration test on residuals.
    """
    coefficients: np.ndarray
    std_errors: np.ndarray
    t_statistics: np.ndarray
    residuals: np.ndarray = field(repr=False)
    fitted_values: np.ndarray = field(repr=False)
    r_squared: float
    adj_r_squared: float
    durbin_watson: float
    sigma: float
    n: int
    k: int
    m1: int
    m2: int
    deterministic: str
    variable_names: List[str] = field(default_factory=list)
    cointegration_test: Optional[HaldrupCointegrationResult] = None
    
    def summary(self) -> str:
        """Generate publication-ready regression summary."""
        lines = []
        lines.append("=" * 78)
        lines.append("Cointegration Regression Results (Haldrup 1994)")
        lines.append("=" * 78)
        lines.append(f"Dependent Variable: y")
        lines.append(f"Method: Ordinary Least Squares")
        lines.append(f"Sample Size: {self.n}")
        lines.append(f"Number of I(1) regressors (m₁): {self.m1}")
        lines.append(f"Number of I(2) regressors (m₂): {self.m2}")
        lines.append(f"Deterministic: {self.deterministic}")
        lines.append("-" * 78)
        lines.append(f"R²: {self.r_squared:.6f}")
        lines.append(f"Adjusted R²: {self.adj_r_squared:.6f}")
        lines.append(f"S.E. of regression: {self.sigma:.6f}")
        lines.append(f"Durbin-Watson: {self.durbin_watson:.6f}")
        lines.append("-" * 78)
        lines.append("")
        lines.append(f"{'Variable':<15} {'Coefficient':>12} {'Std.Err':>12} {'t-Stat':>12}")
        lines.append("-" * 78)
        
        for i, name in enumerate(self.variable_names):
            lines.append(
                f"{name:<15} {self.coefficients[i]:>12.6f} "
                f"{self.std_errors[i]:>12.6f} {self.t_statistics[i]:>12.4f}"
            )
        
        lines.append("=" * 78)
        
        if self.cointegration_test is not None:
            lines.append("")
            lines.append("Cointegration Test (ADF on residuals):")
            lines.append(f"  Test statistic: {self.cointegration_test.test_statistic:.4f}")
            lines.append(f"  5% critical value: {self.cointegration_test.critical_values[0.05]:.4f}")
            lines.append(f"  Conclusion: {self.cointegration_test.conclusion}")
            lines.append("")
            lines.append("Note: For I(2) cointegration, critical values from Haldrup (1994)")
            lines.append("      Table 1 are used, which account for both m₁ and m₂.")
        
        return "\n".join(lines)
    
    def __repr__(self) -> str:
        return (
            f"CointegrationRegressionResult(n={self.n}, m1={self.m1}, m2={self.m2}, "
            f"R²={self.r_squared:.4f}, DW={self.durbin_watson:.4f})"
        )


def cointegration_regression(
    y: ArrayLike,
    x1: Optional[ArrayLike] = None,
    x2: Optional[ArrayLike] = None,
    deterministic: str = "c",
    variable_names: Optional[List[str]] = None,
    test_cointegration: bool = True,
    adf_lags: Optional[int] = None
) -> CointegrationRegressionResult:
    """
    Estimate cointegration regression with I(1) and I(2) variables.
    
    Fits the model:
        y_t = β̂'₀c_t + β̂'₁x_{1t} + β̂'₂x_{2t} + û_t
    
    by ordinary least squares, following Haldrup (1994, eq. 11).
    
    Parameters
    ----------
    y : array_like
        Dependent variable (typically I(2)).
    x1 : array_like, optional
        I(1) regressors. Shape (n,) for single regressor or (n, m1) for multiple.
    x2 : array_like, optional
        I(2) regressors. Shape (n,) for single regressor or (n, m2) for multiple.
    deterministic : str, default "c"
        Deterministic specification:
        - "n": No deterministic components
        - "c": Constant only
        - "ct": Constant and linear trend
        - "ctt": Constant, linear trend, and quadratic trend
    variable_names : list of str, optional
        Names for variables. If None, default names are generated.
    test_cointegration : bool, default True
        Whether to perform ADF cointegration test on residuals.
    adf_lags : int, optional
        Lags for ADF test. If None, selected automatically.
        
    Returns
    -------
    CointegrationRegressionResult
        Object containing regression results and diagnostics.
        
    Notes
    -----
    From Theorem 1 (Haldrup 1994, p. 160):
    
    The orders of the coefficient estimates depend on d, the integration
    order of the conditional model:
    - β̂₁ (I(1) coefficients): O_p(n^{d-1})
    - β̂₂ (I(2) coefficients): O_p(n^{d-2})
    
    Hence for full cointegration (d=0):
    - β̂₁ is O_p(n^{-1})-consistent
    - β̂₂ is O_p(n^{-2})-consistent (superconsistent)
    
    For partial cointegration (d=1):
    - β̂₁ is nondegenerate (not consistent)
    - β̂₂ is O_p(n^{-1})-consistent (superconsistent)
    
    The Durbin-Watson statistic tends to zero at rate O_p(n^{-1}) for
    both d=1 and d=2 (eq. stated after Theorem 1, p. 161).
    
    Examples
    --------
    >>> import numpy as np
    >>> from haldrup import cointegration_regression
    >>> n = 100
    >>> # Generate I(2) process
    >>> x2 = np.cumsum(np.cumsum(np.random.randn(n)))
    >>> # Generate cointegrated y (with I(0) error)
    >>> y = 2.0 * x2 + np.random.randn(n)
    >>> result = cointegration_regression(y, x2=x2, deterministic="c")
    >>> print(result.summary())
    
    References
    ----------
    Haldrup, N. (1994). Section 3, pp. 158-164.
    """
    y = np.asarray(y).flatten()
    n = len(y)
    
    # Process regressors
    X_list = []
    names = []
    
    # Deterministic components
    if deterministic.lower() in ["c", "ct", "ctt"]:
        X_list.append(np.ones(n))
        names.append("Constant")
    if deterministic.lower() in ["ct", "ctt"]:
        X_list.append(np.arange(1, n + 1))
        names.append("Trend")
    if deterministic.lower() == "ctt":
        X_list.append(np.arange(1, n + 1) ** 2)
        names.append("Trend²")
    
    n_det = len(X_list)
    
    # I(1) regressors
    m1 = 0
    if x1 is not None:
        x1 = np.asarray(x1)
        if x1.ndim == 1:
            x1 = x1.reshape(-1, 1)
        m1 = x1.shape[1]
        for i in range(m1):
            X_list.append(x1[:, i])
            if variable_names and len(variable_names) > n_det + i:
                names.append(variable_names[n_det + i])
            else:
                names.append(f"x1_{i+1}")
    
    # I(2) regressors
    m2 = 0
    if x2 is not None:
        x2 = np.asarray(x2)
        if x2.ndim == 1:
            x2 = x2.reshape(-1, 1)
        m2 = x2.shape[1]
        for i in range(m2):
            X_list.append(x2[:, i])
            if variable_names and len(variable_names) > n_det + m1 + i:
                names.append(variable_names[n_det + m1 + i])
            else:
                names.append(f"x2_{i+1}")
    
    if len(X_list) == 0:
        raise ValueError("No regressors specified. Provide x1 and/or x2.")
    
    # Construct design matrix
    X = np.column_stack(X_list)
    k = X.shape[1]
    
    # OLS estimation: β̂ = (X'X)^{-1}X'y
    try:
        XtX_inv = np.linalg.inv(X.T @ X)
    except np.linalg.LinAlgError:
        XtX_inv = np.linalg.pinv(X.T @ X)
    
    beta_hat = XtX_inv @ X.T @ y
    
    # Fitted values and residuals
    y_hat = X @ beta_hat
    residuals = y - y_hat
    
    # Residual variance and standard errors
    ssr = np.sum(residuals ** 2)
    sigma_sq = ssr / (n - k)
    sigma = np.sqrt(sigma_sq)
    
    var_beta = sigma_sq * XtX_inv
    se_beta = np.sqrt(np.diag(var_beta))
    
    # t-statistics
    t_stats = beta_hat / se_beta
    
    # R² and adjusted R²
    y_mean = np.mean(y)
    sst = np.sum((y - y_mean) ** 2)
    r2 = 1 - ssr / sst if sst > 0 else 0.0
    adj_r2 = 1 - (1 - r2) * (n - 1) / (n - k) if n > k else r2
    
    # Durbin-Watson statistic
    dw = durbin_watson(residuals)
    
    # Cointegration test
    coint_result = None
    if test_cointegration and m2 > 0:
        det_spec = "intercept" if "c" in deterministic.lower() else "none"
        coint_result = adf_test(
            residuals, 
            m1=m1, 
            m2=m2,
            lags=adf_lags,
            deterministic=det_spec
        )
    
    # Update variable names if provided
    if variable_names:
        names = variable_names[:k]
    
    return CointegrationRegressionResult(
        coefficients=beta_hat,
        std_errors=se_beta,
        t_statistics=t_stats,
        residuals=residuals,
        fitted_values=y_hat,
        r_squared=r2,
        adj_r_squared=adj_r2,
        durbin_watson=dw,
        sigma=sigma,
        n=n,
        k=k,
        m1=m1,
        m2=m2,
        deterministic=deterministic,
        variable_names=names,
        cointegration_test=coint_result
    )


def polynomial_cointegration_regression(
    y: ArrayLike,
    x1: Optional[ArrayLike] = None,
    x2: Optional[ArrayLike] = None,
    include_dx2: bool = True,
    include_dy: bool = False,
    deterministic: str = "c",
    variable_names: Optional[List[str]] = None,
    test_cointegration: bool = True,
    adf_lags: Optional[int] = None
) -> CointegrationRegressionResult:
    """
    Polynomial cointegration regression with I(1) and I(2) variables.
    
    Extends the standard cointegration regression to include first differences
    of I(2) variables, allowing for polynomial cointegration as described
    in Haldrup (1994, Section 3).
    
    The model is:
        y_t = β̂'₀c_t + β̂'₁x_{1t} + β̂'₂x_{2t} + γ'Δx_{2t} + û_t
    
    where Δx_{2t} are the first differences of the I(2) regressors.
    
    Parameters
    ----------
    y : array_like
        Dependent variable (typically I(2)).
    x1 : array_like, optional
        I(1) regressors.
    x2 : array_like, optional
        I(2) regressors.
    include_dx2 : bool, default True
        Whether to include first differences of I(2) regressors.
    include_dy : bool, default False
        Whether to include first difference of y.
        Note: Creates singularity issues if Δy is effectively driven by Δx_{2t}.
    deterministic : str, default "c"
        Deterministic specification.
    variable_names : list of str, optional
        Names for variables.
    test_cointegration : bool, default True
        Whether to perform cointegration test.
    adf_lags : int, optional
        Lags for ADF test.
        
    Returns
    -------
    CointegrationRegressionResult
        Regression results.
        
    Notes
    -----
    From Haldrup (1994, p. 162):
    
    "For the practitioner the above example illustrates the importance of
    considering first differences in cointegration regressions when variables
    are I(2), i.e., such that cointegrating vectors essentially become
    polynomials in the lag operator."
    
    When first differences are included in a 'dynamic' regression, the orders
    of β̂₁ and β̂₂ become O_p(n^{-2}) and O_p(n^{-1}), respectively, compared
    to O_p(n^{-1}) and O_p(1) in the 'static' regression excluding them.
    
    References
    ----------
    Haldrup, N. (1994). p. 162 and Section 4.
    Yoo, B.S. (1986). Multi-cointegrated time series and generalized error 
        correction models. Discussion paper, UC San Diego.
    """
    y = np.asarray(y).flatten()
    n = len(y)
    
    # Process x2 and compute differences
    dx2 = None
    if x2 is not None and include_dx2:
        x2_arr = np.asarray(x2)
        if x2_arr.ndim == 1:
            x2_arr = x2_arr.reshape(-1, 1)
        dx2 = np.diff(x2_arr, axis=0)
        # Pad with zero at beginning
        dx2 = np.vstack([np.zeros((1, dx2.shape[1])), dx2])
    
    # Process dy
    dy = None
    if include_dy:
        dy = np.diff(y)
        dy = np.concatenate([[0], dy])
    
    # Combine I(1) regressors with differences
    x1_combined = None
    if x1 is not None:
        x1_combined = np.asarray(x1)
        if x1_combined.ndim == 1:
            x1_combined = x1_combined.reshape(-1, 1)
    
    if dx2 is not None:
        if x1_combined is not None:
            x1_combined = np.column_stack([x1_combined, dx2])
        else:
            x1_combined = dx2
    
    if dy is not None:
        if x1_combined is not None:
            x1_combined = np.column_stack([x1_combined, dy.reshape(-1, 1)])
        else:
            x1_combined = dy.reshape(-1, 1)
    
    # Update m1 count
    m1_orig = 0 if x1 is None else (1 if np.asarray(x1).ndim == 1 else np.asarray(x1).shape[1])
    m1_dx2 = dx2.shape[1] if dx2 is not None else 0
    m1_dy = 1 if dy is not None else 0
    m1_total = m1_orig + m1_dx2 + m1_dy
    
    # Generate variable names
    if variable_names is None:
        variable_names = []
        # Deterministic names will be added by cointegration_regression
        # Names for x1
        for i in range(m1_orig):
            variable_names.append(f"x1_{i+1}")
        # Names for dx2
        m2_count = x2.shape[1] if x2 is not None and np.asarray(x2).ndim > 1 else (1 if x2 is not None else 0)
        for i in range(m1_dx2):
            variable_names.append(f"Δx2_{i+1}")
        # Name for dy
        if dy is not None:
            variable_names.append("Δy")
        # Names for x2
        for i in range(m2_count):
            variable_names.append(f"x2_{i+1}")
    
    return cointegration_regression(
        y=y,
        x1=x1_combined,
        x2=x2,
        deterministic=deterministic,
        variable_names=None,  # Let function generate names
        test_cointegration=test_cointegration,
        adf_lags=adf_lags
    )


def dynamic_ols(
    y: ArrayLike,
    x1: Optional[ArrayLike] = None,
    x2: Optional[ArrayLike] = None,
    leads: int = 0,
    lags: int = 0,
    deterministic: str = "c"
) -> CointegrationRegressionResult:
    """
    Dynamic OLS (DOLS) estimation for cointegration.
    
    Augments the cointegration regression with leads and lags of the
    first differences of the regressors to correct for endogeneity.
    
    Parameters
    ----------
    y : array_like
        Dependent variable.
    x1 : array_like, optional
        I(1) regressors.
    x2 : array_like, optional
        I(2) regressors.
    leads : int, default 0
        Number of leads of differenced regressors.
    lags : int, default 0
        Number of lags of differenced regressors.
    deterministic : str, default "c"
        Deterministic specification.
        
    Returns
    -------
    CointegrationRegressionResult
        DOLS regression results.
        
    Notes
    -----
    DOLS was proposed by Stock and Watson (1993) and Saikkonen (1991).
    It provides efficient estimates under more general conditions than OLS.
    
    References
    ----------
    Stock, J.H. and Watson, M.W. (1993). A simple estimator of cointegrating
        vectors in higher order integrated systems. Econometrica, 61(4), 783-820.
    """
    y = np.asarray(y).flatten()
    n = len(y)
    
    # Collect all regressors
    all_x = []
    if x1 is not None:
        x1 = np.asarray(x1)
        if x1.ndim == 1:
            x1 = x1.reshape(-1, 1)
        all_x.append(x1)
    
    if x2 is not None:
        x2 = np.asarray(x2)
        if x2.ndim == 1:
            x2 = x2.reshape(-1, 1)
        all_x.append(x2)
    
    if len(all_x) == 0:
        raise ValueError("Provide at least one regressor (x1 or x2)")
    
    X = np.hstack(all_x)
    k_orig = X.shape[1]
    
    # Compute differences
    dX = np.diff(X, axis=0)
    
    # Construct leads and lags
    trim = leads + lags
    if trim >= n - 1:
        raise ValueError(f"Too many leads ({leads}) and lags ({lags}) for sample size {n}")
    
    # Effective sample
    y_eff = y[lags:n-leads] if leads > 0 else y[lags:]
    X_eff = X[lags:n-leads, :] if leads > 0 else X[lags:, :]
    
    n_eff = len(y_eff)
    
    # Add leads and lags of differences
    diff_regressors = []
    for l in range(-lags, leads + 1):
        if l == 0:
            continue
        if l < 0:
            # Lag
            idx_start = -l
            idx_end = n - 1 - leads
        else:
            # Lead
            idx_start = lags
            idx_end = n - 1 - leads + l - leads
        
        # Adjust indices
        start = max(0, lags - l) if l < 0 else lags
        end = min(n - 1, n - 1 - leads - l) if l > 0 else n - 1 - leads
        
        if l < 0:
            diff_slice = dX[(-l):(-l + n_eff), :]
        else:
            diff_slice = dX[(lags + l - 1):(lags + l - 1 + n_eff), :]
        
        if diff_slice.shape[0] == n_eff:
            diff_regressors.append(diff_slice)
    
    # Combine regressors
    if diff_regressors:
        X_dols = np.hstack([X_eff] + diff_regressors)
    else:
        X_dols = X_eff
    
    # Add deterministic components
    if "c" in deterministic.lower():
        X_dols = np.column_stack([np.ones(n_eff), X_dols])
    if "t" in deterministic.lower():
        X_dols = np.column_stack([X_dols, np.arange(1, n_eff + 1)])
    
    # Estimate
    try:
        beta = np.linalg.lstsq(X_dols, y_eff, rcond=None)[0]
    except np.linalg.LinAlgError:
        beta = np.linalg.pinv(X_dols) @ y_eff
    
    # Compute standard errors
    y_hat = X_dols @ beta
    resid = y_eff - y_hat
    sigma_sq = np.sum(resid ** 2) / (n_eff - X_dols.shape[1])
    
    try:
        var_beta = sigma_sq * np.linalg.inv(X_dols.T @ X_dols)
    except np.linalg.LinAlgError:
        var_beta = sigma_sq * np.linalg.pinv(X_dols.T @ X_dols)
    
    se_beta = np.sqrt(np.diag(var_beta))
    t_stats = beta / se_beta
    
    # R² and DW
    sst = np.sum((y_eff - np.mean(y_eff)) ** 2)
    r2 = 1 - np.sum(resid ** 2) / sst if sst > 0 else 0.0
    adj_r2 = 1 - (1 - r2) * (n_eff - 1) / (n_eff - X_dols.shape[1])
    dw = durbin_watson(resid)
    
    # Variable names
    names = []
    if "c" in deterministic.lower():
        names.append("Constant")
    names.extend([f"x_{i+1}" for i in range(k_orig)])
    for l in range(-lags, leads + 1):
        if l == 0:
            continue
        for i in range(k_orig):
            names.append(f"Δx_{i+1}(t{l:+d})")
    if "t" in deterministic.lower():
        names.append("Trend")
    
    m1 = x1.shape[1] if x1 is not None else 0
    m2 = x2.shape[1] if x2 is not None else 0
    
    return CointegrationRegressionResult(
        coefficients=beta,
        std_errors=se_beta,
        t_statistics=t_stats,
        residuals=resid,
        fitted_values=y_hat,
        r_squared=r2,
        adj_r_squared=adj_r2,
        durbin_watson=dw,
        sigma=np.sqrt(sigma_sq),
        n=n_eff,
        k=X_dols.shape[1],
        m1=m1,
        m2=m2,
        deterministic=deterministic,
        variable_names=names[:X_dols.shape[1]],
        cointegration_test=None
    )
