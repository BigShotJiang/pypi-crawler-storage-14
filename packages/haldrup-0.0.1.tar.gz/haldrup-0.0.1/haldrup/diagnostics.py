"""
Diagnostic Statistics for Cointegration Regressions
====================================================

This module provides diagnostic statistics for cointegration regressions,
with particular focus on the behavior of these statistics when variables
are I(1) or I(2).

Key results from Theorem 1 (Haldrup 1994, pp. 160-161):
- DW → 0 of order O_p(n^{-1}) for d = 1, 2
- R² → 1 of order O_p(n^{-3}), O_p(n^{-2}) for d = 0, 1
- R² has a nondegenerate limiting distribution for d = 2

Reference
---------
Haldrup, N. (1994). The asymptotics of single-equation cointegration 
regressions with I(1) and I(2) variables. Journal of Econometrics, 
63(1), 153-181. Theorem 1, pp. 159-161.

Phillips, P.C.B. (1986). Understanding spurious regressions in econometrics.
Journal of Econometrics, 33(3), 311-340.
"""

from dataclasses import dataclass
from typing import Optional, Tuple
import numpy as np
from numpy.typing import ArrayLike


@dataclass
class SpuriousDiagnostics:
    """
    Container for spurious regression diagnostics.
    
    Attributes
    ----------
    r_squared : float
        Coefficient of determination R².
    durbin_watson : float
        Durbin-Watson statistic.
    f_statistic : float
        F-statistic for overall significance.
    n : int
        Sample size.
    likely_spurious : bool
        Whether regression appears spurious (low DW, high R²).
    interpretation : str
        Human-readable interpretation.
    """
    r_squared: float
    durbin_watson: float
    f_statistic: float
    n: int
    likely_spurious: bool
    interpretation: str
    
    def summary(self) -> str:
        """Generate diagnostic summary."""
        lines = []
        lines.append("=" * 60)
        lines.append("Spurious Regression Diagnostics (Haldrup 1994)")
        lines.append("=" * 60)
        lines.append(f"R²:              {self.r_squared:.6f}")
        lines.append(f"Durbin-Watson:   {self.durbin_watson:.6f}")
        lines.append(f"F-statistic:     {self.f_statistic:.4f}")
        lines.append(f"Sample size:     {self.n}")
        lines.append("-" * 60)
        
        if self.likely_spurious:
            lines.append("WARNING: Regression appears spurious!")
            lines.append("")
            lines.append("From Theorem 1 (Haldrup 1994):")
            lines.append("- DW → 0 at rate O_p(n^{-1}) when d = 1 or 2")
            lines.append("- F-stat diverges at rate O_p(n)")
            lines.append("- For d = 2, R² has nondegenerate distribution")
        else:
            lines.append("No clear evidence of spurious regression.")
        
        lines.append("-" * 60)
        lines.append(f"Interpretation: {self.interpretation}")
        lines.append("=" * 60)
        
        return "\n".join(lines)


def durbin_watson(residuals: ArrayLike) -> float:
    """
    Compute the Durbin-Watson statistic.
    
    DW = Σ(û_t - û_{t-1})² / Σû_t²
    
    Parameters
    ----------
    residuals : array_like
        Regression residuals.
        
    Returns
    -------
    float
        Durbin-Watson statistic (0 to 4).
        
    Notes
    -----
    From Theorem 1 (Haldrup 1994, p. 160):
    
    DW → 0 of order O_p(n^{-1}) for d = 1, 2
    
    This result may seem surprising: when focusing on the DW statistic
    for single time series (not calculated as cointegration residuals),
    then DW = O_p(n^{-d}) for d = 1, 2. The reason why results differ for
    regression residuals is that the regression coefficients associated
    with I(1) variables will spuriously tend to infinity of order O_p(n)
    when the conditional model is I(2).
    
    A very low DW statistic (close to 0) combined with a high R² is
    a classic sign of a spurious regression (Granger and Newbold, 1974).
    
    Examples
    --------
    >>> import numpy as np
    >>> from haldrup import durbin_watson
    >>> residuals = np.random.randn(100).cumsum()  # I(1) residuals
    >>> dw = durbin_watson(residuals)
    >>> print(f"DW = {dw:.4f}")  # Will be close to 0
    
    References
    ----------
    Durbin, J. and Watson, G.S. (1950). Testing for serial correlation in
        least squares regression I. Biometrika, 37(3-4), 409-428.
    """
    residuals = np.asarray(residuals).flatten()
    diff_resid = np.diff(residuals)
    
    numerator = np.sum(diff_resid ** 2)
    denominator = np.sum(residuals ** 2)
    
    if denominator == 0:
        return np.nan
    
    return numerator / denominator


def r_squared(
    y: ArrayLike, 
    y_fitted: ArrayLike,
    adjusted: bool = False,
    k: int = 1
) -> float:
    """
    Compute coefficient of determination R².
    
    R² = 1 - Σû_t² / Σ(y_t - ȳ)²
    
    Parameters
    ----------
    y : array_like
        Actual values.
    y_fitted : array_like
        Fitted values.
    adjusted : bool, default False
        Whether to compute adjusted R².
    k : int, default 1
        Number of regressors (for adjusted R²).
        
    Returns
    -------
    float
        R² or adjusted R².
        
    Notes
    -----
    From Theorem 1 (Haldrup 1994, p. 160):
    
    By assuming that y_t is not dominated by higher-order deterministic trends:
    - R² → 1 of order O_p(n^{-3}), O_p(n^{-2}) for d = 0, d = 1, respectively
    - R² has a nondegenerate limiting distribution for d = 2
    
    The coefficient of multiple correlation tends to one not only when the
    conditional model is stationary but also when it is I(1). This is because
    when d = 1, then y_t, x_{2t} ∼ CI(2, 1) and hence, by definition, the
    residual variation is of a lower order in probability than the original
    I(2) variables.
    
    When there is no cointegration among the series (d = 2), R² will have
    a nondegenerate limiting distribution.
    
    Examples
    --------
    >>> import numpy as np
    >>> from haldrup import r_squared
    >>> y = np.random.randn(100).cumsum().cumsum()  # I(2)
    >>> y_fitted = y + np.random.randn(100) * 0.1  # Fitted with small error
    >>> r2 = r_squared(y, y_fitted)
    >>> print(f"R² = {r2:.6f}")
    """
    y = np.asarray(y).flatten()
    y_fitted = np.asarray(y_fitted).flatten()
    
    residuals = y - y_fitted
    y_mean = np.mean(y)
    
    ssr = np.sum(residuals ** 2)
    sst = np.sum((y - y_mean) ** 2)
    
    if sst == 0:
        return 1.0 if ssr == 0 else 0.0
    
    r2 = 1 - ssr / sst
    
    if adjusted:
        n = len(y)
        r2 = 1 - (1 - r2) * (n - 1) / (n - k - 1)
    
    return r2


def f_statistic(
    y: ArrayLike,
    y_fitted: ArrayLike,
    k: int,
    restricted_ssr: Optional[float] = None
) -> Tuple[float, float]:
    """
    Compute F-statistic for overall significance.
    
    Parameters
    ----------
    y : array_like
        Actual values.
    y_fitted : array_like
        Fitted values.
    k : int
        Number of regressors (excluding constant).
    restricted_ssr : float, optional
        Sum of squared residuals under restricted model.
        If None, computed from y as Σ(y_t - ȳ)².
        
    Returns
    -------
    Tuple[float, float]
        F-statistic and p-value.
        
    Notes
    -----
    From Theorem 1 (Haldrup 1994, p. 159):
    
    F(β̂) → ∞ of order O_p(n) for d = 1, 2
    
    The F test of any hypothesis will always tend to infinity by the order
    O_p(n), although the hypothesis is actually true. One would expect
    spurious divergence to become faster when y_t conditional upon x_t is
    integrated of order two, but the result follows from the fact that the
    order of the estimated error variance n^{-1}Σû_t² increases from O_p(n)
    to O_p(n³) when we go from d = 1 to d = 2, while the order of the
    'squared' coefficient estimates increases by an equivalent magnitude.
    """
    from scipy import stats
    
    y = np.asarray(y).flatten()
    y_fitted = np.asarray(y_fitted).flatten()
    n = len(y)
    
    residuals = y - y_fitted
    ssr_unrestricted = np.sum(residuals ** 2)
    
    if restricted_ssr is None:
        y_mean = np.mean(y)
        restricted_ssr = np.sum((y - y_mean) ** 2)
    
    # F = ((SSR_r - SSR_u) / k) / (SSR_u / (n - k - 1))
    numerator = (restricted_ssr - ssr_unrestricted) / k
    denominator = ssr_unrestricted / (n - k - 1)
    
    if denominator == 0:
        return np.inf, 0.0
    
    f_stat = numerator / denominator
    p_value = 1 - stats.f.cdf(f_stat, k, n - k - 1)
    
    return f_stat, p_value


def spurious_regression_diagnostics(
    y: ArrayLike,
    y_fitted: ArrayLike,
    k: int,
    dw_threshold: float = 0.5,
    r2_threshold: float = 0.8
) -> SpuriousDiagnostics:
    """
    Comprehensive diagnostics for detecting spurious regressions.
    
    Parameters
    ----------
    y : array_like
        Actual values.
    y_fitted : array_like
        Fitted values.
    k : int
        Number of regressors.
    dw_threshold : float, default 0.5
        DW values below this suggest spurious regression.
    r2_threshold : float, default 0.8
        R² values above this (combined with low DW) suggest spurious regression.
        
    Returns
    -------
    SpuriousDiagnostics
        Diagnostic results with interpretation.
        
    Notes
    -----
    Granger and Newbold (1974) first illustrated how regressions involving
    statistically independent random walks would lead to inappropriate
    inference that regression coefficients were significant. Their Monte Carlo
    study indicated that this type of spurious regression was accompanied by:
    - High degree of first-order autocorrelation (low DW)
    - Relatively good fit (high R²)
    
    Phillips (1986) gave an analytical explanation by proving that for
    noncointegrated I(1) variables:
    - F → ∞ at rate O_p(n)
    - DW → 0 at rate O_p(n^{-1})
    - R² has nondegenerate limiting distribution
    
    Haldrup (1994) extended these results to I(2) variables (Theorem 1).
    
    Examples
    --------
    >>> import numpy as np
    >>> from haldrup import spurious_regression_diagnostics
    >>> # Generate independent random walks
    >>> y = np.random.randn(100).cumsum()
    >>> x = np.random.randn(100).cumsum()
    >>> # Spurious regression
    >>> from numpy.linalg import lstsq
    >>> X = np.column_stack([np.ones(100), x])
    >>> beta = lstsq(X, y, rcond=None)[0]
    >>> y_fitted = X @ beta
    >>> diag = spurious_regression_diagnostics(y, y_fitted, k=1)
    >>> print(diag.summary())
    
    References
    ----------
    Granger, C.W.J. and Newbold, P. (1974). Spurious regressions in econometrics.
        Journal of Econometrics, 2(2), 111-120.
    Phillips, P.C.B. (1986). Understanding spurious regressions in econometrics.
        Journal of Econometrics, 33(3), 311-340.
    """
    y = np.asarray(y).flatten()
    y_fitted = np.asarray(y_fitted).flatten()
    n = len(y)
    
    residuals = y - y_fitted
    
    dw = durbin_watson(residuals)
    r2 = r_squared(y, y_fitted)
    f_stat, _ = f_statistic(y, y_fitted, k)
    
    # Determine if likely spurious
    likely_spurious = (dw < dw_threshold) and (r2 > r2_threshold)
    
    # Generate interpretation
    if likely_spurious:
        interpretation = (
            f"Low DW ({dw:.4f}) combined with high R² ({r2:.4f}) suggests "
            "a spurious regression. The residuals appear highly autocorrelated. "
            "Consider testing for cointegration using Haldrup (1994) critical values."
        )
    elif dw < dw_threshold:
        interpretation = (
            f"Low DW ({dw:.4f}) indicates strong positive autocorrelation in residuals. "
            "This could indicate omitted dynamics, misspecification, or spurious regression."
        )
    elif r2 > r2_threshold and f_stat > 100:
        interpretation = (
            f"Very high R² ({r2:.4f}) and F-statistic ({f_stat:.2f}) might indicate "
            "spurious regression if variables are integrated. Check DW and test for cointegration."
        )
    else:
        interpretation = "No clear evidence of spurious regression based on DW and R²."
    
    return SpuriousDiagnostics(
        r_squared=r2,
        durbin_watson=dw,
        f_statistic=f_stat,
        n=n,
        likely_spurious=likely_spurious,
        interpretation=interpretation
    )


def order_of_magnitude_test(
    statistic_values: ArrayLike,
    sample_sizes: ArrayLike,
    expected_rate: float
) -> Tuple[float, float, str]:
    """
    Test whether a statistic's rate of convergence matches theory.
    
    For Haldrup (1994) results:
    - DW: expected_rate = -1 (O_p(n^{-1}))
    - R² - 1: expected_rate = -2 or -3 for d=1, d=0
    - F: expected_rate = 1 (O_p(n))
    
    Parameters
    ----------
    statistic_values : array_like
        Values of the statistic at different sample sizes.
    sample_sizes : array_like
        Corresponding sample sizes.
    expected_rate : float
        Expected rate of convergence (power of n).
        
    Returns
    -------
    Tuple[float, float, str]
        Estimated rate, expected rate, interpretation.
        
    Notes
    -----
    Fits log(statistic) = a + rate * log(n) + error
    and compares estimated rate to expected rate.
    """
    statistic_values = np.asarray(statistic_values).flatten()
    sample_sizes = np.asarray(sample_sizes).flatten()
    
    # Remove zeros or negatives
    valid = (statistic_values > 0) & (sample_sizes > 0)
    stat = statistic_values[valid]
    n = sample_sizes[valid]
    
    if len(stat) < 2:
        return np.nan, expected_rate, "Insufficient data"
    
    # Log-log regression
    log_n = np.log(n)
    log_stat = np.log(stat)
    
    X = np.column_stack([np.ones(len(log_n)), log_n])
    beta = np.linalg.lstsq(X, log_stat, rcond=None)[0]
    estimated_rate = beta[1]
    
    # Interpretation
    diff = abs(estimated_rate - expected_rate)
    if diff < 0.3:
        interp = f"Estimated rate ({estimated_rate:.2f}) consistent with theory ({expected_rate:.2f})"
    else:
        interp = f"Estimated rate ({estimated_rate:.2f}) differs from theory ({expected_rate:.2f})"
    
    return estimated_rate, expected_rate, interp
