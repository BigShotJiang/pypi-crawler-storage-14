"""
Test suite for the Haldrup library.
"""
