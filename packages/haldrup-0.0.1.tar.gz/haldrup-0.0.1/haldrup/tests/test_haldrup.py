"""
Tests for the Haldrup Library
=============================

Comprehensive test suite for verifying the implementation against
the theoretical results in Haldrup (1994).

To run tests:
    pytest tests/test_haldrup.py -v
"""

import numpy as np
import pytest
from numpy.testing import assert_allclose, assert_array_less

# Import all modules
from haldrup.critical_values import (
    get_critical_value,
    get_critical_values_table,
    CRITICAL_VALUES_INTERCEPT,
    asymptotic_critical_value,
)
from haldrup.cointegration_tests import (
    adf_test,
    phillips_z_test,
    cointegration_test,
)
from haldrup.regression import (
    cointegration_regression,
    polynomial_cointegration_regression,
)
from haldrup.diagnostics import (
    durbin_watson,
    r_squared,
    spurious_regression_diagnostics,
)
from haldrup.simulation import (
    generate_i1_process,
    generate_i2_process,
    simulate_critical_values,
)
from haldrup.unit_root import (
    adf_unit_root_test,
    hasza_fuller_test,
    double_unit_root_test,
    determine_integration_order,
)


class TestCriticalValues:
    """Tests for critical values from Table 1."""
    
    def test_table1_exact_values(self):
        """Verify exact values from Table 1 (Haldrup 1994, p. 168)."""
        # m2=1, m1=0, n=100, alpha=0.05 -> -3.42
        cv = get_critical_value(m1=0, m2=1, n=100, alpha=0.05)
        assert cv.critical_value == -3.42
        assert not cv.interpolated
        
        # m2=1, m1=1, n=50, alpha=0.01 -> -4.65
        cv = get_critical_value(m1=1, m2=1, n=50, alpha=0.01)
        assert cv.critical_value == -4.65
        
        # m2=2, m1=2, n=250, alpha=0.10 -> -4.19
        cv = get_critical_value(m1=2, m2=2, n=250, alpha=0.10)
        assert cv.critical_value == -4.19
    
    def test_interpolation(self):
        """Test interpolation for non-standard sample sizes."""
        cv = get_critical_value(m1=1, m2=1, n=75, alpha=0.05)
        assert cv.interpolated
        # Should be between n=50 and n=100 values
        # n=50: -3.93, n=100: -3.89
        assert -3.93 <= cv.critical_value <= -3.89
    
    def test_asymptotic_convergence(self):
        """Verify that CVs converge as n increases (Haldrup 1994, p. 168)."""
        # For large n, CVs are quite similar for given m1 + m2
        cv_250 = get_critical_value(m1=1, m2=1, n=250, alpha=0.05)
        cv_500 = get_critical_value(m1=1, m2=1, n=500, alpha=0.05)
        assert abs(cv_250.critical_value - cv_500.critical_value) < 0.05
    
    def test_critical_value_ordering(self):
        """CVs should become more negative as m1 + m2 increases."""
        cv_m1_0 = get_critical_value(m1=0, m2=1, n=100, alpha=0.05)
        cv_m1_1 = get_critical_value(m1=1, m2=1, n=100, alpha=0.05)
        cv_m1_2 = get_critical_value(m1=2, m2=1, n=100, alpha=0.05)
        
        assert cv_m1_0.critical_value > cv_m1_1.critical_value
        assert cv_m1_1.critical_value > cv_m1_2.critical_value
    
    def test_invalid_inputs(self):
        """Test error handling for invalid inputs."""
        with pytest.raises(ValueError):
            get_critical_value(m1=10, m2=1, n=100)  # m1 out of range
        with pytest.raises(ValueError):
            get_critical_value(m1=0, m2=5, n=100)  # m2 out of range


class TestProcessGeneration:
    """Tests for I(1) and I(2) process generation."""
    
    def test_i1_process_properties(self):
        """Test that generated I(1) process has correct properties."""
        np.random.seed(42)
        x = generate_i1_process(n=1000)
        
        # Check dimensions
        assert len(x) == 1000
        
        # First difference should be approximately white noise
        dx = np.diff(x)
        # Mean should be near zero
        assert abs(np.mean(dx)) < 0.1
        # Autocorrelation of differences should be small
        acf_1 = np.corrcoef(dx[:-1], dx[1:])[0, 1]
        assert abs(acf_1) < 0.1
    
    def test_i2_process_properties(self):
        """Test that generated I(2) process has correct properties."""
        np.random.seed(42)
        x = generate_i2_process(n=1000)
        
        # Check dimensions
        assert len(x) == 1000
        
        # First difference should still be I(1)
        dx = np.diff(x)
        # Second difference should be approximately white noise
        d2x = np.diff(dx)
        assert abs(np.mean(d2x)) < 0.1
    
    def test_reproducibility(self):
        """Test that seed produces reproducible results."""
        x1 = generate_i1_process(n=100, seed=42)
        x2 = generate_i1_process(n=100, seed=42)
        assert_allclose(x1, x2)


class TestCointegrationRegression:
    """Tests for cointegration regression."""
    
    def test_basic_regression(self):
        """Test basic cointegration regression."""
        np.random.seed(42)
        n = 100
        
        # Generate cointegrated system
        x2 = generate_i2_process(n)
        y = 2.0 * x2 + np.random.randn(n) * 0.5  # I(2) + I(0) error
        
        result = cointegration_regression(y, x2=x2.reshape(-1, 1))
        
        # Coefficient should be close to 2.0 (superconsistent)
        assert abs(result.coefficients[-1] - 2.0) < 0.5
        
        # R² should be high
        assert result.r_squared > 0.95
    
    def test_spurious_regression(self):
        """Test detection of spurious regression (Theorem 1)."""
        np.random.seed(42)
        n = 200
        
        # Generate independent random walks (no cointegration)
        y = generate_i1_process(n)
        x = generate_i1_process(n)
        
        result = cointegration_regression(y, x1=x.reshape(-1, 1))
        
        # DW should be low (Theorem 1: DW → 0 at rate O_p(n^{-1}))
        assert result.durbin_watson < 0.5
        
        # R² might be high despite no true relationship
        # This is the spurious regression phenomenon
    
    def test_result_summary(self):
        """Test that summary generates properly."""
        np.random.seed(42)
        n = 50
        x2 = generate_i2_process(n)
        y = x2 + np.random.randn(n)
        
        result = cointegration_regression(y, x2=x2.reshape(-1, 1))
        summary = result.summary()
        
        assert "Cointegration Regression" in summary
        assert "R²" in summary
        assert "Durbin-Watson" in summary


class TestADFCointegrationTest:
    """Tests for ADF cointegration test (Theorem 4)."""
    
    def test_reject_under_cointegration(self):
        """Test that cointegration is detected when present."""
        np.random.seed(42)
        n = 200
        
        # Create cointegrated system
        x2 = generate_i2_process(n)
        y = x2 + np.random.randn(n) * 0.5  # I(0) error
        
        # Compute cointegration residuals
        result = cointegration_regression(y, x2=x2.reshape(-1, 1), test_cointegration=True)
        
        # Should reject no cointegration at 5% level
        assert result.cointegration_test is not None
        # Note: May not always reject due to sample size
    
    def test_no_reject_under_no_cointegration(self):
        """Test that spurious regression is not flagged as cointegration."""
        np.random.seed(42)
        n = 100
        
        # Independent I(2) processes (no cointegration)
        y = generate_i2_process(n)
        x2 = generate_i2_process(n)  # Independent
        
        result = cointegration_regression(y, x2=x2.reshape(-1, 1), test_cointegration=True)
        
        # Should not reject no cointegration
        if result.cointegration_test is not None:
            # The test statistic should be above critical value (not reject)
            # This is a probabilistic statement
            pass
    
    def test_direct_adf_test(self):
        """Test direct use of adf_test function."""
        np.random.seed(42)
        residuals = np.random.randn(100).cumsum()  # I(1) residuals
        
        result = adf_test(residuals, m1=0, m2=1)
        
        assert hasattr(result, 'test_statistic')
        assert hasattr(result, 'critical_values')
        assert 0.05 in result.critical_values


class TestDiagnostics:
    """Tests for diagnostic statistics."""
    
    def test_durbin_watson_range(self):
        """DW should be between 0 and 4."""
        residuals = np.random.randn(100)
        dw = durbin_watson(residuals)
        assert 0 <= dw <= 4
    
    def test_durbin_watson_random(self):
        """DW should be near 2 for white noise."""
        np.random.seed(42)
        residuals = np.random.randn(1000)
        dw = durbin_watson(residuals)
        assert 1.8 < dw < 2.2
    
    def test_durbin_watson_autocorrelated(self):
        """DW should be low for positively autocorrelated residuals."""
        np.random.seed(42)
        residuals = generate_i1_process(100)
        dw = durbin_watson(residuals)
        assert dw < 0.5
    
    def test_r_squared_perfect(self):
        """R² should be 1 for perfect fit."""
        y = np.array([1, 2, 3, 4, 5])
        y_fitted = y.copy()
        assert r_squared(y, y_fitted) == 1.0
    
    def test_r_squared_range(self):
        """R² should be between 0 and 1 for typical data."""
        np.random.seed(42)
        y = np.random.randn(100)
        y_fitted = y + np.random.randn(100) * 0.5
        r2 = r_squared(y, y_fitted)
        assert 0 <= r2 <= 1


class TestUnitRootTests:
    """Tests for unit root testing functions."""
    
    def test_adf_on_stationary(self):
        """ADF should reject unit root for stationary data."""
        np.random.seed(42)
        y = np.random.randn(500)  # Stationary
        
        result = adf_unit_root_test(y, deterministic="c")
        
        # Should reject null of unit root
        assert result.reject_5pct
    
    def test_adf_on_random_walk(self):
        """ADF should not reject unit root for random walk."""
        np.random.seed(42)
        y = generate_i1_process(500)
        
        result = adf_unit_root_test(y, deterministic="c")
        
        # Should not reject null (usually)
        # This is probabilistic, so we just check it runs
        assert hasattr(result, 'test_statistic')
    
    def test_integration_order_detection(self):
        """Test integration order determination."""
        np.random.seed(42)
        
        # Test I(0)
        y0 = np.random.randn(500)
        order0 = determine_integration_order(y0)
        assert order0 == 0
        
        # Test I(1)
        y1 = generate_i1_process(500)
        order1 = determine_integration_order(y1)
        # May not always be exactly 1 due to test size


class TestSimulation:
    """Tests for Monte Carlo simulation."""
    
    @pytest.mark.slow
    def test_simulation_basic(self):
        """Test basic simulation runs."""
        result = simulate_critical_values(
            m1=0, m2=1, n=50,
            replications=100,  # Small for speed
            seed=42
        )
        
        assert result.m1 == 0
        assert result.m2 == 1
        assert result.n == 50
        assert len(result.empirical_distribution) == 100
    
    @pytest.mark.slow
    def test_simulation_critical_values(self):
        """Test that simulated CVs are in reasonable range."""
        result = simulate_critical_values(
            m1=1, m2=1, n=100,
            replications=500,
            seed=42
        )
        
        # 5% CV should be negative (left tail)
        assert result.critical_values[0.05] < 0
        
        # Should be in ballpark of Table 1 values
        table_cv = get_critical_value(m1=1, m2=1, n=100, alpha=0.05)
        diff = abs(result.critical_values[0.05] - table_cv.critical_value)
        # Allow larger difference due to small number of replications
        assert diff < 1.0


class TestTheorem1Properties:
    """
    Tests verifying Theorem 1 properties from Haldrup (1994, pp. 159-161).
    """
    
    def test_dw_convergence_rate(self):
        """
        Test that DW → 0 at rate O_p(n^{-1}) for d = 1, 2.
        (Haldrup 1994, p. 160)
        """
        np.random.seed(42)
        dw_values = []
        sample_sizes = [50, 100, 200, 400]
        
        for n in sample_sizes:
            # Spurious regression (no cointegration, d=2)
            y = generate_i2_process(n)
            x2 = generate_i2_process(n)
            
            result = cointegration_regression(y, x2=x2.reshape(-1, 1))
            dw_values.append(result.durbin_watson)
        
        # DW should decrease as n increases
        # Due to randomness, check general trend
        dw_values = np.array(dw_values)
        # Later values should generally be smaller
        assert np.mean(dw_values[:2]) > np.mean(dw_values[2:]) * 0.5
    
    def test_r2_behavior(self):
        """
        Test R² behavior under different integration orders.
        (Haldrup 1994, p. 160)
        """
        np.random.seed(42)
        n = 200
        
        # d = 0 (full cointegration): R² → 1
        x2 = generate_i2_process(n)
        y = 2.0 * x2 + np.random.randn(n)  # I(0) error
        result = cointegration_regression(y, x2=x2.reshape(-1, 1))
        assert result.r_squared > 0.9
        
        # d = 2 (no cointegration): R² has nondegenerate distribution
        y_indep = generate_i2_process(n)
        x2_indep = generate_i2_process(n)
        result_indep = cointegration_regression(y_indep, x2=x2_indep.reshape(-1, 1))
        # R² can still be high in spurious regression
        assert result_indep.r_squared > 0


class TestPolynomialCointegration:
    """Tests for polynomial cointegration regression."""
    
    def test_with_first_differences(self):
        """Test regression including first differences of I(2) variables."""
        np.random.seed(42)
        n = 100
        
        x2 = generate_i2_process(n)
        y = x2 + np.random.randn(n)
        
        # Should run without error
        result = polynomial_cointegration_regression(
            y, x2=x2.reshape(-1, 1),
            include_dx2=True,
            deterministic="c"
        )
        
        assert result.n == n


# Slow tests that can be skipped in CI
class TestSlowIntegration:
    """Slow integration tests."""
    
    @pytest.mark.slow
    def test_replicate_table1_subset(self):
        """Replicate a subset of Table 1 values."""
        # This is a computationally intensive test
        result = simulate_critical_values(
            m1=0, m2=1, n=100,
            replications=2000,
            seed=42
        )
        
        # Compare with Table 1
        table_cv = get_critical_value(m1=0, m2=1, n=100, alpha=0.05)
        
        # Should be within 0.3 with 2000 replications
        diff = abs(result.critical_values[0.05] - table_cv.critical_value)
        assert diff < 0.3


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
