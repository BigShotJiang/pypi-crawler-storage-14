"""
Haldrup: Cointegration Analysis with I(1) and I(2) Variables
============================================================

A Python implementation of the econometric methods from:

Haldrup, N. (1994). "The asymptotics of single-equation cointegration 
regressions with I(1) and I(2) variables." Journal of Econometrics, 
63(1), 153-181.

This package provides:
- Residual-based cointegration tests for systems with I(1) and I(2) variables
- Critical values for the ADF test (Table 1 from Haldrup 1994)
- Monte Carlo simulation for critical value computation
- OLS cointegration regression with diagnostic statistics
- Integration order detection and unit root testing

Author: Dr Merwan Roudane
Email: merwanroudane920@gmail.com
GitHub: https://github.com/merwanroudane/haldrup

References
----------
Haldrup, N. (1994). The asymptotics of single-equation cointegration 
    regressions with I(1) and I(2) variables. Journal of Econometrics, 
    63(1), 153-181.

Phillips, P.C.B. and Ouliaris, S. (1990). Asymptotic properties of 
    residual based tests for cointegration. Econometrica, 58(1), 165-193.

Engle, R.F. and Granger, C.W.J. (1987). Co-integration and error correction: 
    Representation, estimation and testing. Econometrica, 55(2), 251-276.
"""

__version__ = "0.0.1"
__author__ = "Dr Merwan Roudane"
__email__ = "merwanroudane920@gmail.com"

from haldrup.critical_values import (
    get_critical_value,
    get_critical_values_table,
    CriticalValueTable,
    CRITICAL_VALUES_INTERCEPT,
)

from haldrup.cointegration_tests import (
    adf_test,
    phillips_z_test,
    cointegration_test,
    HaldrupCointegrationResult,
)

from haldrup.regression import (
    cointegration_regression,
    polynomial_cointegration_regression,
    CointegrationRegressionResult,
)

from haldrup.diagnostics import (
    durbin_watson,
    r_squared,
    spurious_regression_diagnostics,
)

from haldrup.simulation import (
    simulate_critical_values,
    generate_i1_process,
    generate_i2_process,
    compare_with_table1,
    SimulationResult,
)

from haldrup.unit_root import (
    adf_unit_root_test,
    hasza_fuller_test,
    double_unit_root_test,
    determine_integration_order,
    UnitRootTestResult,
)

__all__ = [
    # Version info
    "__version__",
    "__author__",
    "__email__",
    # Critical values
    "get_critical_value",
    "get_critical_values_table",
    "CriticalValueTable",
    "CRITICAL_VALUES_INTERCEPT",
    # Cointegration tests
    "adf_test",
    "phillips_z_test",
    "cointegration_test",
    "HaldrupCointegrationResult",
    # Regression
    "cointegration_regression",
    "polynomial_cointegration_regression",
    "CointegrationRegressionResult",
    # Diagnostics
    "durbin_watson",
    "r_squared",
    "spurious_regression_diagnostics",
    # Simulation
    "simulate_critical_values",
    "generate_i1_process",
    "generate_i2_process",
    "compare_with_table1",
    "SimulationResult",
    # Unit root tests
    "adf_unit_root_test",
    "hasza_fuller_test",
    "double_unit_root_test",
    "determine_integration_order",
    "UnitRootTestResult",
]
