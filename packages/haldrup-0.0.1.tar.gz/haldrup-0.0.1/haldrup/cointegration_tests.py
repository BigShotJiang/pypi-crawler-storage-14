"""
Cointegration Tests for Systems with I(1) and I(2) Variables
=============================================================

This module implements residual-based tests for cointegration following
Haldrup (1994), specifically designed for systems containing both I(1)
and I(2) variables.

The main test is the Augmented Dickey-Fuller (ADF) test applied to
cointegration regression residuals (Theorem 4, Haldrup 1994).

Reference
---------
Haldrup, N. (1994). The asymptotics of single-equation cointegration 
regressions with I(1) and I(2) variables. Journal of Econometrics, 
63(1), 153-181.

Phillips, P.C.B. (1987). Time series regression with a unit root.
Econometrica, 55(2), 277-302.

Notes
-----
From Theorem 4 (Haldrup 1994, p. 167):
Let y_t be generated according to the model with d = 1 and conduct
the cointegration regression. Then for n → ∞ and with p = O_p(n^{1/3}),
the ADF test following from the auxiliary regression gives:

ADF → (∫₀¹ W²)^{-1/2} (∫₀¹ W dW)

where W(r) = W₀ - (∫₀¹ W₀ W_*')(∫₀¹ W_* W_*')^{-1} W_*

The distribution is free of nuisance parameters but depends on both
the number of I(1) and I(2) variables in the system.
"""

from dataclasses import dataclass, field
from typing import Optional, Tuple, Union, List
import numpy as np
from numpy.typing import ArrayLike
from scipy import stats

from haldrup.critical_values import get_critical_value, CriticalValueTable


@dataclass
class HaldrupCointegrationResult:
    """
    Result container for Haldrup cointegration tests.
    
    Attributes
    ----------
    test_statistic : float
        The ADF or Phillips Z test statistic.
    pvalue : float or None
        Approximate p-value (if available).
    critical_values : dict
        Critical values at standard significance levels.
    m1 : int
        Number of I(1) regressors.
    m2 : int
        Number of I(2) regressors.
    n : int
        Sample size.
    lags : int
        Number of lags used in ADF regression (for ADF test).
    method : str
        Test method ('ADF' or 'Phillips-Z').
    deterministic : str
        Deterministic specification.
    reject_5pct : bool
        Whether to reject null at 5% level.
    reject_1pct : bool
        Whether to reject null at 1% level.
    residuals : np.ndarray
        Cointegration regression residuals used in the test.
    regression_t_stat : float
        The t-statistic from the ADF regression (α̂ - 1).
    conclusion : str
        Human-readable conclusion.
    """
    test_statistic: float
    pvalue: Optional[float]
    critical_values: dict
    m1: int
    m2: int
    n: int
    lags: int
    method: str
    deterministic: str
    reject_5pct: bool
    reject_1pct: bool
    residuals: np.ndarray = field(repr=False)
    regression_t_stat: Optional[float] = None
    conclusion: str = ""
    
    def __post_init__(self):
        if not self.conclusion:
            if self.reject_1pct:
                self.conclusion = "Reject H₀ of no cointegration at 1% level"
            elif self.reject_5pct:
                self.conclusion = "Reject H₀ of no cointegration at 5% level"
            else:
                self.conclusion = "Cannot reject H₀ of no cointegration at 5% level"
    
    def summary(self) -> str:
        """Generate publication-ready summary."""
        lines = []
        lines.append("=" * 70)
        lines.append(f"Haldrup Cointegration Test Results ({self.method})")
        lines.append("=" * 70)
        lines.append(f"H₀: No cointegration (residuals are I(1))")
        lines.append(f"H₁: Cointegration exists (residuals are I(0))")
        lines.append("-" * 70)
        lines.append(f"Test Statistic: {self.test_statistic:.4f}")
        lines.append(f"Sample Size (n): {self.n}")
        lines.append(f"Number of I(1) regressors (m₁): {self.m1}")
        lines.append(f"Number of I(2) regressors (m₂): {self.m2}")
        if self.method == "ADF":
            lines.append(f"Lags used: {self.lags}")
        lines.append(f"Deterministic: {self.deterministic}")
        lines.append("-" * 70)
        lines.append("Critical Values:")
        for alpha, cv in sorted(self.critical_values.items()):
            reject = "***" if self.test_statistic < cv else ""
            lines.append(f"  {int(alpha*100):>2}%: {cv:>8.4f}  {reject}")
        lines.append("-" * 70)
        lines.append(f"Conclusion: {self.conclusion}")
        lines.append("=" * 70)
        return "\n".join(lines)
    
    def __repr__(self) -> str:
        return (
            f"HaldrupCointegrationResult(stat={self.test_statistic:.4f}, "
            f"m1={self.m1}, m2={self.m2}, n={self.n}, "
            f"reject_5pct={self.reject_5pct})"
        )


def _compute_adf_regression(
    residuals: np.ndarray,
    lags: int = 0,
    trend: str = "n"
) -> Tuple[float, float, np.ndarray]:
    """
    Compute the ADF test regression.
    
    Regression: Δû_t = (α̂ - 1)û_{t-1} + Σφⱼ Δû_{t-j} + error
    
    Parameters
    ----------
    residuals : np.ndarray
        Cointegration regression residuals
    lags : int
        Number of lagged differences to include
    trend : str
        Trend specification for ADF ('n', 'c', 'ct')
        Note: For cointegration residuals, typically 'n' (no constant)
        
    Returns
    -------
    Tuple[float, float, np.ndarray]
        (alpha_hat - 1), t-statistic, regression residuals
    """
    n = len(residuals)
    y = np.diff(residuals)
    x_lag = residuals[:-1]
    
    # Construct lagged differences
    if lags > 0:
        X = np.column_stack([
            x_lag[lags:],
            *[y[lags-i:-i] if i > 0 else y[lags:] for i in range(1, lags + 1)]
        ])
        y_reg = y[lags:]
    else:
        X = x_lag.reshape(-1, 1)
        y_reg = y
    
    # Add deterministic components
    nobs = len(y_reg)
    if trend == 'c':
        X = np.column_stack([np.ones(nobs), X])
    elif trend == 'ct':
        X = np.column_stack([np.ones(nobs), np.arange(1, nobs + 1), X])
    
    # OLS estimation
    try:
        beta = np.linalg.lstsq(X, y_reg, rcond=None)[0]
    except np.linalg.LinAlgError:
        # Handle singular matrix
        beta = np.linalg.pinv(X) @ y_reg
    
    # Get the coefficient on lagged level
    if trend == 'n':
        alpha_minus_1 = beta[0]
        idx = 0
    elif trend == 'c':
        alpha_minus_1 = beta[1]
        idx = 1
    else:  # 'ct'
        alpha_minus_1 = beta[2]
        idx = 2
    
    # Compute standard error and t-statistic
    resid = y_reg - X @ beta
    s2 = np.sum(resid**2) / (nobs - len(beta))
    
    # Variance-covariance matrix
    try:
        var_beta = s2 * np.linalg.inv(X.T @ X)
    except np.linalg.LinAlgError:
        var_beta = s2 * np.linalg.pinv(X.T @ X)
    
    se = np.sqrt(var_beta[idx, idx])
    t_stat = alpha_minus_1 / se
    
    return alpha_minus_1, t_stat, resid


def _select_lag_aic(
    residuals: np.ndarray,
    max_lags: int,
    trend: str = "n"
) -> int:
    """
    Select optimal lag length using AIC.
    
    Parameters
    ----------
    residuals : np.ndarray
        Cointegration regression residuals
    max_lags : int
        Maximum lags to consider
    trend : str
        Trend specification
        
    Returns
    -------
    int
        Optimal lag length
    """
    n = len(residuals) - 1
    aic_values = []
    
    for p in range(max_lags + 1):
        _, _, resid = _compute_adf_regression(residuals, lags=p, trend=trend)
        nobs = len(resid)
        ssr = np.sum(resid**2)
        k = p + 1 + (1 if trend == 'c' else 0) + (2 if trend == 'ct' else 0)
        aic = nobs * np.log(ssr / nobs) + 2 * k
        aic_values.append(aic)
    
    return int(np.argmin(aic_values))


def _select_lag_schwarz(
    residuals: np.ndarray,
    max_lags: int,
    trend: str = "n"
) -> int:
    """
    Select optimal lag length using Schwarz Information Criterion (BIC).
    
    Parameters
    ----------
    residuals : np.ndarray
        Cointegration regression residuals
    max_lags : int
        Maximum lags to consider
    trend : str
        Trend specification
        
    Returns
    -------
    int
        Optimal lag length
    """
    n = len(residuals) - 1
    bic_values = []
    
    for p in range(max_lags + 1):
        _, _, resid = _compute_adf_regression(residuals, lags=p, trend=trend)
        nobs = len(resid)
        ssr = np.sum(resid**2)
        k = p + 1 + (1 if trend == 'c' else 0) + (2 if trend == 'ct' else 0)
        bic = nobs * np.log(ssr / nobs) + k * np.log(nobs)
        bic_values.append(bic)
    
    return int(np.argmin(bic_values))


def adf_test(
    residuals: np.ndarray,
    m1: int,
    m2: int,
    lags: Optional[int] = None,
    max_lags: Optional[int] = None,
    lag_method: str = "aic",
    deterministic: str = "intercept"
) -> HaldrupCointegrationResult:
    """
    Augmented Dickey-Fuller test for I(2) cointegration.
    
    Implements Theorem 4 from Haldrup (1994). Under the null hypothesis,
    the cointegration residuals are I(1), meaning there is no cointegration
    among the I(2) variables at the I(0) level.
    
    The test regression is:
        Δû_t = (α̂ - 1)û_{t-1} + Σⱼ φⱼ Δû_{t-j} + η_t
    
    where û_t are the residuals from the cointegration regression.
    
    Parameters
    ----------
    residuals : array_like
        Residuals from the cointegration regression.
    m1 : int
        Number of I(1) regressors in the cointegration regression.
    m2 : int
        Number of I(2) regressors in the cointegration regression.
    lags : int, optional
        Number of lagged differences in the ADF regression.
        If None, determined by lag_method.
    max_lags : int, optional
        Maximum lags to consider for automatic selection.
        Default is int(12 * (n/100)^{1/4}) following Schwert (1989).
    lag_method : str, default "aic"
        Method for automatic lag selection: "aic" or "bic".
    deterministic : str, default "intercept"
        Deterministic specification in the original cointegration regression.
        
    Returns
    -------
    HaldrupCointegrationResult
        Object containing test results and diagnostics.
        
    Notes
    -----
    From Haldrup (1994, p. 167): The ADF test statistic converges to:
    
    ADF → (∫₀¹ W²)^{-1/2} (∫₀¹ W dW)
    
    where W(r) is a conditional Brownian motion. The distribution is
    free of nuisance parameters but depends on m₁, m₂, and deterministics.
    
    The recommended lag truncation is p = O_p(n^{1/3}) as noted in Theorem 4.
    
    Examples
    --------
    >>> import numpy as np
    >>> from haldrup import adf_test
    >>> # Suppose we have cointegration residuals from a regression
    >>> # with 1 I(1) and 1 I(2) regressor
    >>> residuals = np.random.randn(100).cumsum()  # I(1) process
    >>> result = adf_test(residuals, m1=1, m2=1)
    >>> print(result.summary())
    
    References
    ----------
    Haldrup, N. (1994). Theorem 4, p. 167.
    Said, S.E. and Dickey, D.A. (1984). Testing for unit roots in 
        autoregressive-moving average models of unknown order. 
        Biometrika, 71(3), 599-607.
    """
    residuals = np.asarray(residuals).flatten()
    n = len(residuals)
    
    # Determine lag length
    if lags is None:
        if max_lags is None:
            # Schwert (1989) rule: int(12 * (n/100)^{1/4})
            max_lags = int(12 * (n / 100) ** 0.25)
        
        if lag_method.lower() == "aic":
            lags = _select_lag_aic(residuals, max_lags, trend="n")
        elif lag_method.lower() in ["bic", "schwarz"]:
            lags = _select_lag_schwarz(residuals, max_lags, trend="n")
        else:
            raise ValueError(f"Unknown lag_method: {lag_method}")
    
    # Compute ADF statistic
    # Note: For cointegration residuals, we don't include a constant
    # in the ADF regression (the constant is in the original regression)
    alpha_minus_1, t_stat, adf_resid = _compute_adf_regression(
        residuals, lags=lags, trend="n"
    )
    
    # Get critical values
    cvs = {}
    for alpha in [0.01, 0.025, 0.05, 0.10]:
        cv_table = get_critical_value(m1, m2, n, alpha, deterministic)
        cvs[alpha] = cv_table.critical_value
    
    # Determine rejection
    reject_5pct = t_stat < cvs[0.05]
    reject_1pct = t_stat < cvs[0.01]
    
    return HaldrupCointegrationResult(
        test_statistic=t_stat,
        pvalue=None,  # No closed-form p-value
        critical_values=cvs,
        m1=m1,
        m2=m2,
        n=n,
        lags=lags,
        method="ADF",
        deterministic=deterministic,
        reject_5pct=reject_5pct,
        reject_1pct=reject_1pct,
        residuals=residuals,
        regression_t_stat=t_stat
    )


def _compute_long_run_variance(
    residuals: np.ndarray,
    truncation: int
) -> float:
    """
    Compute long-run variance using Newey-West type estimator.
    
    Parameters
    ----------
    residuals : np.ndarray
        Residuals
    truncation : int
        Truncation lag (bandwidth)
        
    Returns
    -------
    float
        Long-run variance estimate
    """
    n = len(residuals)
    
    # Autocovariances
    gamma = np.zeros(truncation + 1)
    for j in range(truncation + 1):
        gamma[j] = np.mean(residuals[j:] * residuals[:n-j]) if j > 0 else np.var(residuals)
    
    # Bartlett kernel weights
    omega_sq = gamma[0]
    for j in range(1, truncation + 1):
        w_j = 1 - j / (truncation + 1)  # Bartlett kernel
        omega_sq += 2 * w_j * gamma[j]
    
    return max(omega_sq, 1e-10)  # Ensure positive


def phillips_z_test(
    residuals: np.ndarray,
    m1: int,
    m2: int,
    truncation: Optional[int] = None,
    deterministic: str = "intercept"
) -> HaldrupCointegrationResult:
    """
    Phillips Z_α test for cointegration with I(1) and I(2) variables.
    
    Implements the semiparametric Phillips (1987) test adapted for
    cointegration testing following Phillips and Ouliaris (1990).
    
    Parameters
    ----------
    residuals : array_like
        Residuals from the cointegration regression.
    m1 : int
        Number of I(1) regressors.
    m2 : int
        Number of I(2) regressors.
    truncation : int, optional
        Truncation lag for long-run variance estimation.
        Default is int(4 * (n/100)^{1/4}).
    deterministic : str, default "intercept"
        Deterministic specification.
        
    Returns
    -------
    HaldrupCointegrationResult
        Object containing test results.
        
    Notes
    -----
    The Phillips Z_α test is a semiparametric alternative to the ADF test
    that corrects for serial correlation nonparametrically using a
    Newey-West type long-run variance estimator.
    
    References
    ----------
    Phillips, P.C.B. (1987). Time series regression with a unit root.
        Econometrica, 55(2), 277-302.
    Phillips, P.C.B. and Ouliaris, S. (1990). Asymptotic properties of 
        residual based tests for cointegration. Econometrica, 58(1), 165-193.
    """
    residuals = np.asarray(residuals).flatten()
    n = len(residuals)
    
    if truncation is None:
        truncation = int(4 * (n / 100) ** 0.25)
    
    # AR(1) regression: u_t = alpha * u_{t-1} + e_t
    u_lag = residuals[:-1]
    u_t = residuals[1:]
    
    alpha_hat = np.sum(u_lag * u_t) / np.sum(u_lag ** 2)
    e_hat = u_t - alpha_hat * u_lag
    
    # Long-run variance
    omega_sq = _compute_long_run_variance(e_hat, truncation)
    sigma_sq = np.var(e_hat, ddof=1)
    
    # Phillips Z_alpha statistic
    sum_u_sq = np.sum(u_lag ** 2)
    z_alpha = n * (alpha_hat - 1) - (n**2 / (2 * sum_u_sq)) * (omega_sq - sigma_sq)
    
    # Phillips Z_t statistic (t-ratio version)
    se_alpha = np.sqrt(sigma_sq / sum_u_sq)
    t_alpha = (alpha_hat - 1) / se_alpha
    z_t = t_alpha * np.sqrt(sigma_sq / omega_sq) - \
          0.5 * (omega_sq - sigma_sq) / (omega_sq * np.sqrt(omega_sq / sum_u_sq))
    
    # Get critical values (use same as ADF)
    cvs = {}
    for alpha in [0.01, 0.025, 0.05, 0.10]:
        cv_table = get_critical_value(m1, m2, n, alpha, deterministic)
        cvs[alpha] = cv_table.critical_value
    
    # Use Z_t for comparison with ADF critical values
    reject_5pct = z_t < cvs[0.05]
    reject_1pct = z_t < cvs[0.01]
    
    return HaldrupCointegrationResult(
        test_statistic=z_t,
        pvalue=None,
        critical_values=cvs,
        m1=m1,
        m2=m2,
        n=n,
        lags=truncation,  # Truncation lag
        method="Phillips-Z",
        deterministic=deterministic,
        reject_5pct=reject_5pct,
        reject_1pct=reject_1pct,
        residuals=residuals
    )


def cointegration_test(
    residuals: np.ndarray,
    m1: int,
    m2: int,
    method: str = "adf",
    **kwargs
) -> HaldrupCointegrationResult:
    """
    Unified interface for cointegration testing.
    
    Parameters
    ----------
    residuals : array_like
        Cointegration regression residuals.
    m1 : int
        Number of I(1) regressors.
    m2 : int
        Number of I(2) regressors.
    method : str, default "adf"
        Test method: "adf" or "phillips".
    **kwargs
        Additional arguments passed to the specific test function.
        
    Returns
    -------
    HaldrupCointegrationResult
        Test results.
        
    Examples
    --------
    >>> from haldrup import cointegration_test
    >>> import numpy as np
    >>> residuals = np.random.randn(100).cumsum()
    >>> result = cointegration_test(residuals, m1=1, m2=1, method="adf")
    >>> print(result.conclusion)
    """
    method = method.lower()
    
    if method in ["adf", "dickey-fuller", "df"]:
        return adf_test(residuals, m1, m2, **kwargs)
    elif method in ["phillips", "phillips-z", "z", "za"]:
        return phillips_z_test(residuals, m1, m2, **kwargs)
    else:
        raise ValueError(f"Unknown method: {method}. Use 'adf' or 'phillips'.")
