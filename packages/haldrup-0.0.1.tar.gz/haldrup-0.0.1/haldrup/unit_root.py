"""
Unit Root Tests for I(1) and I(2) Processes
============================================

This module provides unit root tests for determining the integration order
of time series, including tests for double unit roots (I(2)).

Reference
---------
Haldrup, N. (1994). The asymptotics of single-equation cointegration 
regressions with I(1) and I(2) variables. Journal of Econometrics, 
63(1), 153-181.

Additional References
---------------------
Dickey, D.A. and Fuller, W.A. (1979). Distribution of the estimators for
    autoregressive time series with a unit root. JASA, 74(366), 427-431.
    
Hasza, D.P. and Fuller, W.A. (1979). Estimation of autoregressive processes
    with unit roots. Annals of Statistics, 7(5), 1106-1120.
    
Dickey, D.A. and Pantula, S.G. (1987). Determining the order of differencing
    in autoregressive processes. JBES, 5(4), 455-461.
"""

from dataclasses import dataclass
from typing import Optional, Tuple, Dict
import numpy as np
from numpy.typing import ArrayLike
from scipy import stats


# Dickey-Fuller critical values (Fuller 1976, Table 8.5.2)
# For τ_μ (constant included)
ADF_CRITICAL_VALUES_CONST = {
    25:  {0.01: -3.75, 0.05: -3.00, 0.10: -2.63},
    50:  {0.01: -3.58, 0.05: -2.93, 0.10: -2.60},
    100: {0.01: -3.51, 0.05: -2.89, 0.10: -2.58},
    250: {0.01: -3.46, 0.05: -2.88, 0.10: -2.57},
    500: {0.01: -3.44, 0.05: -2.87, 0.10: -2.57},
}

# For τ_τ (constant and trend)
ADF_CRITICAL_VALUES_TREND = {
    25:  {0.01: -4.38, 0.05: -3.60, 0.10: -3.24},
    50:  {0.01: -4.15, 0.05: -3.50, 0.10: -3.18},
    100: {0.01: -4.04, 0.05: -3.45, 0.10: -3.15},
    250: {0.01: -3.99, 0.05: -3.43, 0.10: -3.13},
    500: {0.01: -3.98, 0.05: -3.42, 0.10: -3.13},
}

# For τ (no deterministic components)
ADF_CRITICAL_VALUES_NONE = {
    25:  {0.01: -2.66, 0.05: -1.95, 0.10: -1.60},
    50:  {0.01: -2.62, 0.05: -1.95, 0.10: -1.61},
    100: {0.01: -2.60, 0.05: -1.95, 0.10: -1.61},
    250: {0.01: -2.58, 0.05: -1.95, 0.10: -1.62},
    500: {0.01: -2.58, 0.05: -1.95, 0.10: -1.62},
}


# =============================================================================
# Hasza-Fuller (1979) Critical Values for Double Unit Root Tests
# Source: Hasza, D.P. and Fuller, W.A. (1979). "Estimation for Autoregressive
#         Processes with Unit Roots." Annals of Statistics, 7(5), 1106-1120.
#         Table 4.1, page 1116.
#
# These are F-type statistics for testing joint hypotheses about unit roots.
# The values are upper-tail percentiles (reject H0 if statistic > critical value).
# =============================================================================

# Φ₁(2): No deterministic components
# Tests H₁: (α₁, β₁) = (1, 1) in Model 5.1: Y_t = α₁Y_{t-1} + β₁ΔY_{t-1} + e_t
# Percentiles: {0.90: ..., 0.95: ..., 0.975: ..., 0.99: ...}
HASZA_FULLER_PHI1_2 = {
    25:  {0.10: 2.89, 0.05: 3.78, 0.025: 4.66, 0.01: 6.01},
    50:  {0.10: 2.82, 0.05: 3.60, 0.025: 4.41, 0.01: 5.52},
    100: {0.10: 2.78, 0.05: 3.53, 0.025: 4.29, 0.01: 5.31},
    250: {0.10: 2.76, 0.05: 3.49, 0.025: 4.22, 0.01: 5.20},
    500: {0.10: 2.76, 0.05: 3.48, 0.025: 4.20, 0.01: 5.17},
    'inf': {0.10: 2.75, 0.05: 3.47, 0.025: 4.18, 0.01: 5.14},
}

# Φ₂(2): Constant included (2 restrictions)
# Tests H₂: (α₂, β₂) = (1, 1) in Model 5.2: Y_t = μ₂ + α₂Y_{t-1} + β₂ΔY_{t-1} + e_t
HASZA_FULLER_PHI2_2 = {
    25:  {0.10: 5.78, 0.05: 7.17, 0.025: 8.61, 0.01: 10.55},
    50:  {0.10: 5.47, 0.05: 6.61, 0.025: 7.76, 0.01: 9.22},
    100: {0.10: 5.33, 0.05: 6.36, 0.025: 7.38, 0.01: 8.65},
    250: {0.10: 5.25, 0.05: 6.23, 0.025: 7.18, 0.01: 8.36},
    500: {0.10: 5.22, 0.05: 6.19, 0.025: 7.13, 0.01: 8.28},
    'inf': {0.10: 5.21, 0.05: 6.16, 0.025: 7.08, 0.01: 8.22},
}

# Φ₂(3): Constant included (3 restrictions)
# Tests H₃: (μ₂, α₂, β₂) = (0, 1, 1)
HASZA_FULLER_PHI2_3 = {
    25:  {0.10: 4.28, 0.05: 5.22, 0.025: 6.23, 0.01: 7.59},
    50:  {0.10: 3.99, 0.05: 4.76, 0.025: 5.55, 0.01: 6.56},
    100: {0.10: 3.86, 0.05: 4.55, 0.025: 5.24, 0.01: 6.11},
    250: {0.10: 3.79, 0.05: 4.44, 0.025: 5.08, 0.01: 5.88},
    500: {0.10: 3.76, 0.05: 4.41, 0.025: 5.03, 0.01: 5.81},
    'inf': {0.10: 3.75, 0.05: 4.39, 0.025: 5.00, 0.01: 5.76},
}

# Φ₃(2): Constant and trend included (2 restrictions)
# Tests H₄: (α₃, β₃) = (1, 1) in Model 5.3: Y_t = μ₃ + θ₃t + α₃Y_{t-1} + β₃ΔY_{t-1} + e_t
HASZA_FULLER_PHI3_2 = {
    25:  {0.10: 9.54, 0.05: 11.41, 0.025: 13.34, 0.01: 15.88},
    50:  {0.10: 8.75, 0.05: 10.17, 0.025: 11.61, 0.01: 13.43},
    100: {0.10: 8.36, 0.05: 9.58, 0.025: 10.80, 0.01: 12.31},
    250: {0.10: 8.13, 0.05: 9.25, 0.025: 10.34, 0.01: 11.70},
    500: {0.10: 8.05, 0.05: 9.15, 0.025: 10.20, 0.01: 11.52},
    'inf': {0.10: 7.98, 0.05: 9.05, 0.025: 10.08, 0.01: 11.37},
}

# Φ₃(4): Constant and trend included (4 restrictions)
# Tests H₅: (μ₃, θ₃, α₃, β₃) = (0, 0, 1, 1)
HASZA_FULLER_PHI3_4 = {
    25:  {0.10: 5.63, 0.05: 6.66, 0.025: 7.74, 0.01: 9.25},
    50:  {0.10: 5.00, 0.05: 5.77, 0.025: 6.51, 0.01: 7.49},
    100: {0.10: 4.71, 0.05: 5.36, 0.025: 5.96, 0.01: 6.74},
    250: {0.10: 4.55, 0.05: 5.14, 0.025: 5.68, 0.01: 6.38},
    500: {0.10: 4.50, 0.05: 5.07, 0.025: 5.60, 0.01: 6.28},
    'inf': {0.10: 4.45, 0.05: 5.01, 0.025: 5.54, 0.01: 6.21},
}


def _get_hasza_fuller_critical_values(
    n: int,
    deterministic: str,
    num_restrictions: int = 2
) -> Dict[float, float]:
    """
    Get Hasza-Fuller critical values with interpolation.
    
    Parameters
    ----------
    n : int
        Sample size.
    deterministic : str
        Deterministic specification: "n" (none), "c" (constant), "ct" (constant+trend).
    num_restrictions : int
        Number of restrictions being tested (2, 3, or 4).
        
    Returns
    -------
    dict
        Critical values at standard significance levels.
        
    Notes
    -----
    Source: Hasza & Fuller (1979), Table 4.1, p. 1116.
    """
    # Select the appropriate table
    if deterministic == "n":
        cv_table = HASZA_FULLER_PHI1_2
    elif deterministic == "c":
        if num_restrictions == 2:
            cv_table = HASZA_FULLER_PHI2_2
        else:  # 3 restrictions
            cv_table = HASZA_FULLER_PHI2_3
    else:  # "ct" or "ctt"
        if num_restrictions == 2:
            cv_table = HASZA_FULLER_PHI3_2
        else:  # 4 restrictions
            cv_table = HASZA_FULLER_PHI3_4
    
    # Available sample sizes (excluding 'inf')
    available_n = sorted([k for k in cv_table.keys() if k != 'inf'])
    
    if n in cv_table:
        return cv_table[n]
    
    # Interpolate
    result = {}
    for alpha in [0.01, 0.025, 0.05, 0.10]:
        values = [cv_table[ns][alpha] for ns in available_n]
        
        if n <= min(available_n):
            result[alpha] = values[0]
        elif n >= max(available_n):
            # Use asymptotic value for very large n
            result[alpha] = cv_table['inf'][alpha]
        else:
            # Linear interpolation on log(n)
            log_n = np.log(available_n)
            log_n_target = np.log(n)
            result[alpha] = float(np.interp(log_n_target, log_n, values))
    
    return result


@dataclass
class UnitRootTestResult:
    """
    Container for unit root test results.
    
    Attributes
    ----------
    test_statistic : float
        Test statistic value.
    pvalue : float or None
        P-value (if available).
    critical_values : dict
        Critical values at standard levels.
    n : int
        Sample size.
    lags : int
        Lags used in test.
    method : str
        Test method name.
    deterministic : str
        Deterministic specification.
    null_hypothesis : str
        Description of null hypothesis.
    reject_5pct : bool
        Whether to reject at 5% level.
    conclusion : str
        Human-readable conclusion.
    """
    test_statistic: float
    pvalue: Optional[float]
    critical_values: dict
    n: int
    lags: int
    method: str
    deterministic: str
    null_hypothesis: str
    reject_5pct: bool
    conclusion: str
    
    def summary(self) -> str:
        """Generate test summary."""
        lines = []
        lines.append("=" * 60)
        lines.append(f"Unit Root Test Results ({self.method})")
        lines.append("=" * 60)
        lines.append(f"H₀: {self.null_hypothesis}")
        lines.append("-" * 60)
        lines.append(f"Test Statistic: {self.test_statistic:.4f}")
        if self.pvalue is not None:
            lines.append(f"P-value: {self.pvalue:.4f}")
        lines.append(f"Sample Size: {self.n}")
        lines.append(f"Lags: {self.lags}")
        lines.append(f"Deterministic: {self.deterministic}")
        lines.append("-" * 60)
        lines.append("Critical Values:")
        for alpha, cv in sorted(self.critical_values.items()):
            pct = int(alpha * 100)
            reject = "***" if self.test_statistic < cv else ""
            lines.append(f"  {pct:>2}%: {cv:>8.4f}  {reject}")
        lines.append("-" * 60)
        lines.append(f"Conclusion: {self.conclusion}")
        lines.append("=" * 60)
        return "\n".join(lines)


def _get_adf_critical_values(
    n: int,
    deterministic: str
) -> Dict[float, float]:
    """Get ADF critical values with interpolation."""
    if deterministic == "c":
        cv_table = ADF_CRITICAL_VALUES_CONST
    elif deterministic == "ct":
        cv_table = ADF_CRITICAL_VALUES_TREND
    else:
        cv_table = ADF_CRITICAL_VALUES_NONE
    
    # Find bracketing sample sizes
    available_n = sorted(cv_table.keys())
    
    if n in cv_table:
        return cv_table[n]
    
    # Interpolate
    result = {}
    for alpha in [0.01, 0.05, 0.10]:
        values = [cv_table[ns][alpha] for ns in available_n]
        
        if n <= min(available_n):
            result[alpha] = values[0]
        elif n >= max(available_n):
            result[alpha] = values[-1]
        else:
            # Linear interpolation on log(n)
            log_n = np.log(available_n)
            log_n_target = np.log(n)
            result[alpha] = float(np.interp(log_n_target, log_n, values))
    
    return result


def adf_unit_root_test(
    y: ArrayLike,
    lags: Optional[int] = None,
    max_lags: Optional[int] = None,
    lag_method: str = "aic",
    deterministic: str = "c"
) -> UnitRootTestResult:
    """
    Augmented Dickey-Fuller test for a unit root.
    
    Tests H₀: y_t has a unit root (is I(1))
    vs H₁: y_t is stationary (is I(0))
    
    Parameters
    ----------
    y : array_like
        Time series to test.
    lags : int, optional
        Number of lagged differences. If None, selected automatically.
    max_lags : int, optional
        Maximum lags for automatic selection.
    lag_method : str, default "aic"
        Method for lag selection ("aic" or "bic").
    deterministic : str, default "c"
        Deterministic specification:
        - "n": No deterministic
        - "c": Constant only
        - "ct": Constant and trend
        
    Returns
    -------
    UnitRootTestResult
        Test results.
        
    Notes
    -----
    From Haldrup (1994, p. 170), for testing the integration order:
    "By testing the integration order of the single time series we find
    that m_t and p_t may well be described as I(2) processes, whilst the
    remaining series, including real money (m - p)_t and velocity (m - p - y)_t,
    are I(1)."
    
    References
    ----------
    Dickey, D.A. and Fuller, W.A. (1979).
    """
    y = np.asarray(y).flatten()
    n = len(y)
    
    # Lag selection
    if lags is None:
        if max_lags is None:
            max_lags = int(12 * (n / 100) ** 0.25)
        lags = _select_lag_aic_adf(y, max_lags, deterministic, lag_method)
    
    # Compute ADF regression
    dy = np.diff(y)
    y_lag = y[:-1]
    
    # Build regressor matrix
    X_list = []
    
    if deterministic in ["c", "ct"]:
        X_list.append(np.ones(n - 1 - lags))
    if deterministic == "ct":
        X_list.append(np.arange(1, n - lags))
    
    X_list.append(y_lag[lags:])
    
    # Add lagged differences
    for j in range(1, lags + 1):
        X_list.append(dy[lags - j:-j] if j < lags else dy[:n - 1 - lags])
    
    y_reg = dy[lags:]
    X = np.column_stack(X_list) if len(X_list) > 1 else X_list[0].reshape(-1, 1)
    
    nobs = len(y_reg)
    
    # OLS
    try:
        beta = np.linalg.lstsq(X, y_reg, rcond=None)[0]
    except np.linalg.LinAlgError:
        beta = np.linalg.pinv(X) @ y_reg
    
    # Get coefficient on y_{t-1}
    if deterministic == "n":
        rho_idx = 0
    elif deterministic == "c":
        rho_idx = 1
    else:  # "ct"
        rho_idx = 2
    
    rho_minus_1 = beta[rho_idx]
    
    # Standard error
    resid = y_reg - X @ beta
    s2 = np.sum(resid**2) / (nobs - len(beta))
    
    try:
        var_beta = s2 * np.linalg.inv(X.T @ X)
    except np.linalg.LinAlgError:
        var_beta = s2 * np.linalg.pinv(X.T @ X)
    
    se = np.sqrt(var_beta[rho_idx, rho_idx])
    t_stat = rho_minus_1 / se
    
    # Critical values
    cvs = _get_adf_critical_values(n, deterministic)
    
    reject_5pct = t_stat < cvs[0.05]
    
    if reject_5pct:
        conclusion = "Reject H₀: Series appears stationary (I(0))"
    else:
        conclusion = "Cannot reject H₀: Series may have a unit root (I(1) or higher)"
    
    return UnitRootTestResult(
        test_statistic=t_stat,
        pvalue=None,
        critical_values=cvs,
        n=n,
        lags=lags,
        method="ADF",
        deterministic=deterministic,
        null_hypothesis="Series has a unit root (I(1))",
        reject_5pct=reject_5pct,
        conclusion=conclusion
    )


def _select_lag_aic_adf(
    y: np.ndarray,
    max_lags: int,
    deterministic: str,
    method: str = "aic"
) -> int:
    """Select optimal lag using AIC or BIC."""
    n = len(y)
    ic_values = []
    
    for p in range(max_lags + 1):
        # Compute regression
        dy = np.diff(y)
        y_lag = y[:-1]
        
        X_list = []
        if deterministic in ["c", "ct"]:
            X_list.append(np.ones(n - 1 - p))
        if deterministic == "ct":
            X_list.append(np.arange(1, n - p))
        
        X_list.append(y_lag[p:])
        
        for j in range(1, p + 1):
            if j < p:
                X_list.append(dy[p - j:-j])
            else:
                X_list.append(dy[:n - 1 - p])
        
        y_reg = dy[p:]
        X = np.column_stack(X_list) if len(X_list) > 1 else X_list[0].reshape(-1, 1)
        
        nobs = len(y_reg)
        k = X.shape[1]
        
        try:
            beta = np.linalg.lstsq(X, y_reg, rcond=None)[0]
        except:
            ic_values.append(np.inf)
            continue
        
        resid = y_reg - X @ beta
        ssr = np.sum(resid**2)
        
        if method.lower() == "aic":
            ic = nobs * np.log(ssr / nobs) + 2 * k
        else:  # bic
            ic = nobs * np.log(ssr / nobs) + k * np.log(nobs)
        
        ic_values.append(ic)
    
    return int(np.argmin(ic_values))


def hasza_fuller_test(
    y: ArrayLike,
    lags: int = 0,
    deterministic: str = "ct",
    num_restrictions: int = 2
) -> UnitRootTestResult:
    """
    Hasza-Fuller test for double unit root (I(2)).
    
    Tests H₀: y_t is I(2) (two unit roots)
    vs H₁: y_t is I(1) or I(0)
    
    The test regression is based on the model:
    Δ²y_t = π₁y_{t-2} + π₂Δy_{t-1} + deterministics + Σφ_jΔ²y_{t-j} + ε_t
    
    Under H₀ (I(2)): π₁ = 0 and π₂ = 0 (i.e., α = β = 1 in original notation)
    
    This function computes the Φ (F-type) statistic from Hasza & Fuller (1979).
    
    Parameters
    ----------
    y : array_like
        Time series to test.
    lags : int, default 0
        Number of additional lags of Δ²y.
    deterministic : str, default "ct"
        Deterministic specification:
        - "n": No deterministic terms (Φ₁(2))
        - "c": Constant only (Φ₂(2) or Φ₂(3))
        - "ct": Constant and trend (Φ₃(2) or Φ₃(4))
    num_restrictions : int, default 2
        Number of restrictions being tested:
        - 2: Test only (α, β) = (1, 1)
        - 3: Test (μ, α, β) = (0, 1, 1) for "c" model
        - 4: Test (μ, θ, α, β) = (0, 0, 1, 1) for "ct" model
        
    Returns
    -------
    UnitRootTestResult
        Test results including F-statistic and critical values.
        
    Notes
    -----
    From Haldrup (1994, p. 154):
    "Univariate models for I(2) processes and their testing for double unit
    roots have been analyzed in a number of papers by, e.g., Hasza and Fuller
    (1979), Dickey and Pantula (1987), Pantula (1989) and Haldrup (1994)."
    
    Critical values are from Hasza & Fuller (1979), Table 4.1, p. 1116.
    These are upper-tail critical values: reject H₀ if F > critical value.
    
    References
    ----------
    Hasza, D.P. and Fuller, W.A. (1979). Estimation of autoregressive 
        processes with unit roots. Annals of Statistics, 7(5), 1106-1120.
    """
    y = np.asarray(y).flatten()
    n = len(y)
    
    # Compute differences
    dy = np.diff(y)           # First difference
    d2y = np.diff(dy)         # Second difference
    
    # Build regression
    # Δ²y_t = π₁y_{t-2} + π₂Δy_{t-1} + c + trend + Σφ_jΔ²y_{t-j} + ε_t
    
    trim = 2 + lags
    nobs = n - trim
    
    X_list = []
    
    # Deterministics
    n_det = 0
    if deterministic in ["c", "ct", "ctt"]:
        X_list.append(np.ones(nobs))
        n_det += 1
    if deterministic in ["ct", "ctt"]:
        X_list.append(np.arange(1, nobs + 1))
        n_det += 1
    if deterministic == "ctt":
        X_list.append(np.arange(1, nobs + 1) ** 2)
        n_det += 1
    
    # y_{t-2} (coefficient α-1 = π₁)
    X_list.append(y[:(n - trim)])
    # Δy_{t-1} (coefficient β-1 = π₂)
    X_list.append(dy[:(n - trim)])
    
    # Lagged second differences
    for j in range(1, lags + 1):
        X_list.append(d2y[lags - j:n - 2 - j])
    
    y_reg = d2y[lags:]
    X = np.column_stack(X_list)
    
    # Full model OLS
    try:
        beta = np.linalg.lstsq(X, y_reg, rcond=None)[0]
    except np.linalg.LinAlgError:
        beta = np.linalg.pinv(X) @ y_reg
    
    # Residuals from full model
    resid_full = y_reg - X @ beta
    ssr_full = np.sum(resid_full**2)
    
    # Restricted model (under H₀: π₁ = π₂ = 0)
    # Remove the level and first difference terms
    if num_restrictions == 2:
        # Test only (π₁, π₂) = (0, 0)
        if n_det > 0:
            X_r = X[:, :n_det]  # Keep only deterministics
            # Add lagged second differences if any
            if lags > 0:
                X_r = np.hstack([X_r, X[:, (n_det + 2):]])
        else:
            if lags > 0:
                X_r = X[:, 2:]  # Remove first two regressors (level and first diff)
            else:
                # No regressors - just use mean
                X_r = np.ones((nobs, 1))
        
        try:
            beta_r = np.linalg.lstsq(X_r, y_reg, rcond=None)[0]
            resid_r = y_reg - X_r @ beta_r
        except:
            resid_r = y_reg - np.mean(y_reg)
        
        ssr_r = np.sum(resid_r**2)
        q = 2  # Number of restrictions
        
    elif num_restrictions == 3 and deterministic == "c":
        # Test (μ, π₁, π₂) = (0, 0, 0)
        if lags > 0:
            X_r = X[:, 3:]  # Remove constant, level, and first diff
            try:
                beta_r = np.linalg.lstsq(X_r, y_reg, rcond=None)[0]
                resid_r = y_reg - X_r @ beta_r
            except:
                resid_r = y_reg
        else:
            resid_r = y_reg
        
        ssr_r = np.sum(resid_r**2)
        q = 3
        
    elif num_restrictions == 4 and deterministic in ["ct", "ctt"]:
        # Test (μ, θ, π₁, π₂) = (0, 0, 0, 0)
        if lags > 0:
            X_r = X[:, 4:]  # Remove constant, trend, level, and first diff
            try:
                beta_r = np.linalg.lstsq(X_r, y_reg, rcond=None)[0]
                resid_r = y_reg - X_r @ beta_r
            except:
                resid_r = y_reg
        else:
            resid_r = y_reg
        
        ssr_r = np.sum(resid_r**2)
        q = 4
    else:
        # Default to 2 restrictions
        q = 2
        ssr_r = np.sum(y_reg**2)
    
    # F-statistic
    k = X.shape[1]  # Number of parameters in full model
    df_full = nobs - k
    
    if df_full > 0 and ssr_full > 0:
        F_stat = ((ssr_r - ssr_full) / q) / (ssr_full / df_full)
    else:
        F_stat = np.nan
    
    # Get critical values from Hasza-Fuller Table 4.1
    cvs = _get_hasza_fuller_critical_values(n, deterministic, num_restrictions)
    
    # Reject H₀ if F > critical value (upper-tail test)
    reject_5pct = F_stat > cvs[0.05]
    
    if reject_5pct:
        conclusion = "Reject H₀: Series is likely I(1) or I(0), not I(2)"
    else:
        conclusion = "Cannot reject H₀: Series may be I(2)"
    
    # Determine test name
    if deterministic == "n":
        test_name = "Φ₁(2)"
    elif deterministic == "c":
        test_name = f"Φ₂({num_restrictions})"
    else:
        test_name = f"Φ₃({num_restrictions})"
    
    return UnitRootTestResult(
        test_statistic=F_stat,
        pvalue=None,
        critical_values=cvs,
        n=n,
        lags=lags,
        method=f"Hasza-Fuller {test_name}",
        deterministic=deterministic,
        null_hypothesis="Series is I(2) (double unit root)",
        reject_5pct=reject_5pct,
        conclusion=conclusion
    )


def double_unit_root_test(
    y: ArrayLike,
    lags: Optional[int] = None,
    deterministic: str = "ct"
) -> Tuple[UnitRootTestResult, UnitRootTestResult]:
    """
    Sequential testing procedure for double unit roots.
    
    Implements the Dickey-Pantula (1987) approach: first test for the
    second unit root, then conditionally test for the first.
    
    Parameters
    ----------
    y : array_like
        Time series to test.
    lags : int, optional
        Number of lags.
    deterministic : str, default "ct"
        Deterministic specification.
        
    Returns
    -------
    Tuple[UnitRootTestResult, UnitRootTestResult]
        (test for second unit root, test for first unit root)
        
    Notes
    -----
    From Dickey and Pantula (1987, p. 458):
    "Reject the hypothesis H₃ of three unit roots and go to step 2 if 
    t*₃,ₙ(3) < τₙ,α, where τₙ,α was given by Fuller (1976)."
    
    The sequential t* procedure uses standard Fuller (1976) Table 8.5.2 
    critical values (τ_μ for constant, τ_τ for constant+trend). This is
    the key insight: Dickey-Pantula does NOT require separate critical 
    values - it uses the standard ADF critical values.
    
    The sequential procedure:
    1. Test H₀: Δy has unit root (y is I(2)) vs H₁: Δy is stationary (y is I(1))
    2. If reject in step 1, test H₀: y has unit root (I(1)) vs H₁: y is I(0)
    
    From Haldrup (1994, p. 170):
    "For the m_t and the p_t series, the Hasza and Fuller (1979) test and
    the semiparametric test in Haldrup (1994) were conducted with quadratic
    trends included in the auxiliary regression, but also their differences
    were tested to contain an additional unit root."
    
    References
    ----------
    Dickey, D.A. and Pantula, S.G. (1987). Determining the order of 
        differencing in autoregressive processes. JBES, 5(4), 455-461.
    Fuller, W.A. (1976). Introduction to Statistical Time Series.
        Wiley, New York. Table 8.5.2.
    """
    y = np.asarray(y).flatten()
    n = len(y)
    
    if lags is None:
        lags = int(12 * (n / 100) ** 0.25)
    
    # First test: Is Δy ~ I(1)? (i.e., is y ~ I(2)?)
    dy = np.diff(y)
    test_second = adf_unit_root_test(dy, lags=lags, deterministic=deterministic)
    test_second.null_hypothesis = "Δy has a unit root (y is I(2))"
    
    if not test_second.reject_5pct:
        # Cannot reject that Δy is I(1), so y appears to be I(2)
        test_second.conclusion = "Cannot reject: Series appears to be I(2)"
        # No need to test further
        test_first = UnitRootTestResult(
            test_statistic=np.nan,
            pvalue=None,
            critical_values={},
            n=n,
            lags=lags,
            method="ADF",
            deterministic=deterministic,
            null_hypothesis="Series has a unit root",
            reject_5pct=False,
            conclusion="Not applicable (series appears I(2))"
        )
    else:
        # Δy appears stationary or has no unit root
        test_second.conclusion = "Reject: Δy appears stationary, so y is at most I(1)"
        # Test if y is I(1) or I(0)
        test_first = adf_unit_root_test(y, lags=lags, deterministic=deterministic)
    
    return test_second, test_first


def determine_integration_order(
    y: ArrayLike,
    max_order: int = 2,
    significance: float = 0.05,
    deterministic: str = "ct"
) -> int:
    """
    Determine the integration order of a time series.
    
    Uses sequential testing from highest to lowest order.
    
    Parameters
    ----------
    y : array_like
        Time series to test.
    max_order : int, default 2
        Maximum integration order to consider.
    significance : float, default 0.05
        Significance level for tests.
    deterministic : str, default "ct"
        Deterministic specification.
        
    Returns
    -------
    int
        Estimated integration order (0, 1, or 2).
        
    Notes
    -----
    From the introduction of Haldrup (1994, pp. 153-154):
    
    "Many observed time series, particularly nominal time series like prices,
    wages, and money balances, but also time series for other stock variables,
    seem to be smoother than what is normally observed for series integrated
    of order one. Obvious candidates for time series with this kind of behaviour
    are double unit root processes, i.e., processes that require double
    differencing in order to become stationary."
    
    This function helps identify such I(2) processes.
    """
    y = np.asarray(y).flatten()
    
    if max_order >= 2:
        # Test for I(2)
        test_second, test_first = double_unit_root_test(y, deterministic=deterministic)
        
        if not test_second.reject_5pct:
            return 2
        
        if not test_first.reject_5pct:
            return 1
        
        return 0
    elif max_order == 1:
        test = adf_unit_root_test(y, deterministic=deterministic)
        return 0 if test.reject_5pct else 1
    else:
        return 0
