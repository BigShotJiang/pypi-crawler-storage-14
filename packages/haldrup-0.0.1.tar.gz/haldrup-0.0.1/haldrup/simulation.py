"""
Monte Carlo Simulation for I(2) Cointegration Critical Values
==============================================================

This module implements Monte Carlo simulation for computing critical values
of the residual-based Dickey-Fuller test with I(1) and I(2) variables,
following the methodology in Haldrup (1994, Section 4).

Data Generating Process (from p. 169):
    Δx_{1t} = ε_{1t},     (I(1) variables)
    Δ²x_{2t} = ε_{2t},    (I(2) variables)
    y_t = x_{2t} + u_t    with Δu_t = v_t

where ε_{1t}, ε_{2t}, and v_t are standard normal with Ω = I.

Reference
---------
Haldrup, N. (1994). The asymptotics of single-equation cointegration 
regressions with I(1) and I(2) variables. Journal of Econometrics, 
63(1), 153-181. Section 4, pp. 165-169.
"""

from dataclasses import dataclass, field
from typing import Optional, Tuple, List, Dict
import numpy as np
from numpy.typing import ArrayLike
from concurrent.futures import ProcessPoolExecutor
import warnings


@dataclass
class SimulationResult:
    """
    Container for Monte Carlo simulation results.
    
    Attributes
    ----------
    m1 : int
        Number of I(1) regressors.
    m2 : int
        Number of I(2) regressors.
    n : int
        Sample size.
    replications : int
        Number of Monte Carlo replications.
    critical_values : dict
        Critical values at standard significance levels.
    empirical_distribution : np.ndarray
        Sorted test statistics from simulation.
    mean : float
        Mean of simulated test statistics.
    std : float
        Standard deviation of simulated test statistics.
    deterministic : str
        Deterministic specification.
    """
    m1: int
    m2: int
    n: int
    replications: int
    critical_values: Dict[float, float]
    empirical_distribution: np.ndarray = field(repr=False)
    mean: float
    std: float
    deterministic: str
    
    def summary(self) -> str:
        """Generate summary of simulation results."""
        lines = []
        lines.append("=" * 60)
        lines.append("Monte Carlo Simulation Results")
        lines.append("=" * 60)
        lines.append(f"m₁ (I(1) regressors): {self.m1}")
        lines.append(f"m₂ (I(2) regressors): {self.m2}")
        lines.append(f"Sample size (n): {self.n}")
        lines.append(f"Replications: {self.replications}")
        lines.append(f"Deterministic: {self.deterministic}")
        lines.append("-" * 60)
        lines.append("Critical Values:")
        for alpha in sorted(self.critical_values.keys()):
            pct = int(alpha * 100) if alpha * 100 == int(alpha * 100) else alpha * 100
            lines.append(f"  {pct:>4}%: {self.critical_values[alpha]:.4f}")
        lines.append("-" * 60)
        lines.append(f"Distribution Summary:")
        lines.append(f"  Mean: {self.mean:.4f}")
        lines.append(f"  Std Dev: {self.std:.4f}")
        lines.append("=" * 60)
        return "\n".join(lines)
    
    def get_percentile(self, p: float) -> float:
        """Get percentile of empirical distribution."""
        idx = int(p * len(self.empirical_distribution))
        return self.empirical_distribution[max(0, min(idx, len(self.empirical_distribution) - 1))]


def generate_i1_process(n: int, sigma: float = 1.0, seed: Optional[int] = None) -> np.ndarray:
    """
    Generate an I(1) process (random walk).
    
    x_t = x_{t-1} + ε_t, where ε_t ~ N(0, σ²)
    
    Parameters
    ----------
    n : int
        Sample size.
    sigma : float, default 1.0
        Standard deviation of innovations.
    seed : int, optional
        Random seed for reproducibility.
        
    Returns
    -------
    np.ndarray
        I(1) process of length n.
        
    Notes
    -----
    From Haldrup (1994, eq. 3):
    x_{1t} = γ'₁c_t + x°_{1t}, Δx°_{1t} = ε_{1t}
    
    The stochastic component x°_{1t} is I(1) with innovations ε_{1t}.
    
    Examples
    --------
    >>> from haldrup import generate_i1_process
    >>> x = generate_i1_process(n=100, seed=42)
    >>> print(f"x is I(1): {x.shape}")
    """
    if seed is not None:
        np.random.seed(seed)
    
    epsilon = sigma * np.random.randn(n)
    x = np.cumsum(epsilon)
    
    return x


def generate_i2_process(n: int, sigma: float = 1.0, seed: Optional[int] = None) -> np.ndarray:
    """
    Generate an I(2) process (double random walk).
    
    x_t = x_{t-1} + w_{t-1}, w_t = w_{t-1} + ε_t
    
    Parameters
    ----------
    n : int
        Sample size.
    sigma : float, default 1.0
        Standard deviation of innovations.
    seed : int, optional
        Random seed for reproducibility.
        
    Returns
    -------
    np.ndarray
        I(2) process of length n.
        
    Notes
    -----
    From Haldrup (1994, eq. 4):
    x_{2t} = γ'₂c_t + x°_{2t}, Δ²x°_{2t} = ε_{2t}
    
    The I(2) process can be written as a repeated random walk:
    x°_{2t} = Σ_{k=1}^t Σ_{j=1}^k ε_{2j}
    
    The limiting process (Haldrup 1994, p. 157) is:
    n^{-3/2} x_{2,[nr]} → ∫₀^r B₂(s)ds ≡ B̄₂(r)
    
    where B̄ indicates an integrated Brownian motion.
    
    Examples
    --------
    >>> from haldrup import generate_i2_process
    >>> x = generate_i2_process(n=100, seed=42)
    >>> print(f"x is I(2): {x.shape}")
    """
    if seed is not None:
        np.random.seed(seed)
    
    epsilon = sigma * np.random.randn(n)
    
    # Double cumsum: first creates I(1), second creates I(2)
    w = np.cumsum(epsilon)  # I(1)
    x = np.cumsum(w)        # I(2)
    
    return x


def _single_replication(
    n: int,
    m1: int,
    m2: int,
    include_intercept: bool = True,
    seed: Optional[int] = None
) -> float:
    """
    Perform a single Monte Carlo replication.
    
    DGP from Haldrup (1994, p. 169):
    - Δx_{1t} = ε_{1t}
    - Δ²x_{2t} = ε_{2t}  
    - y_t = x_{2t} + u_t with Δu_t = v_t
    
    Parameters
    ----------
    n : int
        Sample size.
    m1 : int
        Number of I(1) regressors.
    m2 : int
        Number of I(2) regressors.
    include_intercept : bool
        Whether to include intercept in regression.
    seed : int, optional
        Random seed.
        
    Returns
    -------
    float
        ADF test statistic from this replication.
    """
    if seed is not None:
        np.random.seed(seed)
    
    # Generate I(1) regressors
    x1 = None
    if m1 > 0:
        x1 = np.column_stack([
            generate_i1_process(n) for _ in range(m1)
        ])
    
    # Generate I(2) regressors
    x2 = np.column_stack([
        generate_i2_process(n) for _ in range(m2)
    ])
    
    # Generate y: y_t = x_{2,t} + u_t where Δu_t = v_t (u_t is I(1))
    # Sum of I(2) regressors plus I(1) error
    y = np.sum(x2, axis=1) + generate_i1_process(n)
    
    # Construct regression matrix
    X_list = []
    if include_intercept:
        X_list.append(np.ones((n, 1)))
    if x1 is not None:
        if x1.ndim == 1:
            X_list.append(x1.reshape(-1, 1))
        else:
            X_list.append(x1)
    if x2.ndim == 1:
        X_list.append(x2.reshape(-1, 1))
    else:
        X_list.append(x2)
    
    X = np.hstack(X_list) if len(X_list) > 1 else X_list[0]
    
    # OLS estimation
    try:
        beta = np.linalg.lstsq(X, y, rcond=None)[0]
    except np.linalg.LinAlgError:
        beta = np.linalg.pinv(X) @ y
    
    # Residuals
    residuals = y - X @ beta
    
    # ADF test on residuals (no constant in ADF regression)
    adf_stat = _compute_adf_statistic(residuals)
    
    return adf_stat


def _compute_adf_statistic(residuals: np.ndarray, lags: int = 0) -> float:
    """
    Compute ADF t-statistic from residuals.
    
    Parameters
    ----------
    residuals : np.ndarray
        Cointegration regression residuals.
    lags : int
        Number of lagged differences (p in Theorem 4).
        
    Returns
    -------
    float
        ADF t-statistic.
    """
    n = len(residuals)
    y = np.diff(residuals)
    x_lag = residuals[:-1]
    
    if lags > 0:
        # Include lagged differences
        X = np.column_stack([
            x_lag[lags:],
            *[y[lags-i:-i] if i > 0 else y[lags:] for i in range(1, lags + 1)]
        ])
        y_reg = y[lags:]
    else:
        X = x_lag.reshape(-1, 1)
        y_reg = y
    
    nobs = len(y_reg)
    
    # OLS
    try:
        beta = np.linalg.lstsq(X, y_reg, rcond=None)[0]
    except np.linalg.LinAlgError:
        beta = np.linalg.pinv(X) @ y_reg
    
    alpha_minus_1 = beta[0]
    
    # Standard error
    resid = y_reg - X @ beta
    s2 = np.sum(resid**2) / (nobs - len(beta))
    
    try:
        var_beta = s2 * np.linalg.inv(X.T @ X)
    except np.linalg.LinAlgError:
        var_beta = s2 * np.linalg.pinv(X.T @ X)
    
    se = np.sqrt(var_beta[0, 0])
    t_stat = alpha_minus_1 / se
    
    return t_stat


def simulate_critical_values(
    m1: int,
    m2: int,
    n: int,
    replications: int = 10000,
    include_intercept: bool = True,
    adf_lags: int = 0,
    seed: Optional[int] = None,
    n_jobs: int = 1
) -> SimulationResult:
    """
    Monte Carlo simulation for critical values.
    
    Implements the simulation methodology from Haldrup (1994, pp. 168-169).
    
    Parameters
    ----------
    m1 : int
        Number of I(1) regressors.
    m2 : int
        Number of I(2) regressors.
    n : int
        Sample size.
    replications : int, default 10000
        Number of Monte Carlo replications.
    include_intercept : bool, default True
        Whether to include intercept in cointegration regression.
    adf_lags : int, default 0
        Lags in ADF regression (p in Theorem 4).
    seed : int, optional
        Random seed for reproducibility.
    n_jobs : int, default 1
        Number of parallel jobs (1 = sequential).
        
    Returns
    -------
    SimulationResult
        Object containing critical values and empirical distribution.
        
    Notes
    -----
    From Haldrup (1994, p. 169):
    
    "The data-generating process is:
    Δx_{1t} = ε_{1t}, Δ²x_{2t} = ε_{2t},
    y_t = x_{2t} + u_t with Δu_t = v_t,
    
    where x_{1t}, x_{2t}, and y_t are of dimensions m₁, m₂, and 1,
    respectively. The innovation processes are generated according to
    a standard normal distribution with covariance matrix Ω = I."
    
    The cointegration regression is:
    y_t = β̂₀ + β̂'₁x_{1t} + β̂'₂x_{2t} + û_t
    
    The Dickey-Fuller t-statistic is computed from û_t.
    
    Examples
    --------
    >>> from haldrup import simulate_critical_values
    >>> result = simulate_critical_values(m1=1, m2=1, n=100, replications=1000)
    >>> print(result.summary())
    
    >>> # Compare with Table 1 values
    >>> from haldrup import get_critical_value
    >>> table_cv = get_critical_value(m1=1, m2=1, n=100, alpha=0.05)
    >>> print(f"Table 1: {table_cv.critical_value:.4f}")
    >>> print(f"Simulated: {result.critical_values[0.05]:.4f}")
    
    References
    ----------
    Haldrup, N. (1994). Section 4 and Table 1.
    """
    if seed is not None:
        np.random.seed(seed)
    
    if m2 < 1:
        raise ValueError("m2 must be at least 1 for I(2) cointegration")
    
    # Generate seeds for reproducibility
    seeds = np.random.randint(0, 2**31, size=replications)
    
    # Run simulations
    if n_jobs == 1:
        # Sequential
        test_stats = np.array([
            _single_replication(n, m1, m2, include_intercept, seed=int(s))
            for s in seeds
        ])
    else:
        # Parallel
        with ProcessPoolExecutor(max_workers=n_jobs) as executor:
            futures = [
                executor.submit(_single_replication, n, m1, m2, include_intercept, int(s))
                for s in seeds
            ]
            test_stats = np.array([f.result() for f in futures])
    
    # Remove any NaN values
    test_stats = test_stats[~np.isnan(test_stats)]
    
    # Sort for percentile computation
    sorted_stats = np.sort(test_stats)
    
    # Compute critical values at standard levels
    critical_values = {}
    for alpha in [0.01, 0.025, 0.05, 0.10]:
        idx = int(alpha * len(sorted_stats))
        critical_values[alpha] = sorted_stats[idx]
    
    deterministic = "intercept" if include_intercept else "none"
    
    return SimulationResult(
        m1=m1,
        m2=m2,
        n=n,
        replications=len(test_stats),
        critical_values=critical_values,
        empirical_distribution=sorted_stats,
        mean=np.mean(test_stats),
        std=np.std(test_stats),
        deterministic=deterministic
    )


def simulate_table1(
    sample_sizes: List[int] = [25, 50, 100, 250, 500],
    m1_values: List[int] = [0, 1, 2, 3, 4],
    m2_values: List[int] = [1, 2],
    replications: int = 10000,
    seed: Optional[int] = None
) -> Dict[Tuple[int, int, int], SimulationResult]:
    """
    Replicate Table 1 from Haldrup (1994).
    
    Parameters
    ----------
    sample_sizes : list of int
        Sample sizes to simulate.
    m1_values : list of int
        Values of m₁ (I(1) regressors).
    m2_values : list of int
        Values of m₂ (I(2) regressors).
    replications : int
        Monte Carlo replications.
    seed : int, optional
        Random seed.
        
    Returns
    -------
    dict
        Dictionary mapping (m1, m2, n) to SimulationResult.
        
    Examples
    --------
    >>> from haldrup import simulate_table1
    >>> results = simulate_table1(sample_sizes=[100], m1_values=[1], 
    ...                           m2_values=[1], replications=1000)
    >>> key = (1, 1, 100)
    >>> print(f"m1=1, m2=1, n=100: 5% CV = {results[key].critical_values[0.05]:.4f}")
    """
    if seed is not None:
        np.random.seed(seed)
    
    results = {}
    total = len(sample_sizes) * len(m1_values) * len(m2_values)
    count = 0
    
    for m2 in m2_values:
        for m1 in m1_values:
            for n in sample_sizes:
                count += 1
                print(f"Simulating m1={m1}, m2={m2}, n={n} ({count}/{total})...")
                
                result = simulate_critical_values(
                    m1=m1, m2=m2, n=n,
                    replications=replications,
                    include_intercept=True
                )
                results[(m1, m2, n)] = result
    
    return results


def format_table1_results(
    results: Dict[Tuple[int, int, int], SimulationResult],
    m2: int = 1
) -> str:
    """
    Format simulation results as Table 1 from Haldrup (1994).
    
    Parameters
    ----------
    results : dict
        Results from simulate_table1.
    m2 : int
        Number of I(2) regressors to display.
        
    Returns
    -------
    str
        Formatted table string.
    """
    lines = []
    lines.append("=" * 75)
    lines.append(f"Simulated Critical Values (m₂ = {m2})")
    lines.append("=" * 75)
    lines.append("")
    lines.append("Probability of a Smaller Value")
    lines.append("-" * 75)
    lines.append(f"{'m₁':>4} {'n':>6} {'0.01':>10} {'0.025':>10} {'0.05':>10} {'0.10':>10}")
    lines.append("-" * 75)
    
    # Get unique m1 values and sample sizes
    m1_values = sorted(set(k[0] for k in results.keys() if k[1] == m2))
    sample_sizes = sorted(set(k[2] for k in results.keys() if k[1] == m2))
    
    for m1 in m1_values:
        for i, n in enumerate(sample_sizes):
            key = (m1, m2, n)
            if key not in results:
                continue
            
            cv = results[key].critical_values
            
            if i == 0:
                m1_str = str(m1)
            else:
                m1_str = ""
            
            lines.append(
                f"{m1_str:>4} {n:>6} {cv[0.01]:>10.2f} {cv[0.025]:>10.2f} "
                f"{cv[0.05]:>10.2f} {cv[0.10]:>10.2f}"
            )
        lines.append("")
    
    lines.append("=" * 75)
    
    return "\n".join(lines)


def compare_with_table1(
    simulated: SimulationResult,
    tolerance: float = 0.15
) -> str:
    """
    Compare simulated critical values with Table 1 from Haldrup (1994).
    
    Parameters
    ----------
    simulated : SimulationResult
        Simulated results.
    tolerance : float
        Acceptable absolute difference.
        
    Returns
    -------
    str
        Comparison summary.
    """
    from haldrup.critical_values import get_critical_value
    
    lines = []
    lines.append("Comparison with Haldrup (1994) Table 1")
    lines.append("-" * 50)
    lines.append(f"{'Alpha':>8} {'Table 1':>10} {'Simulated':>10} {'Diff':>8}")
    lines.append("-" * 50)
    
    all_close = True
    for alpha in [0.01, 0.025, 0.05, 0.10]:
        cv_table = get_critical_value(
            simulated.m1, simulated.m2, simulated.n, alpha
        ).critical_value
        cv_sim = simulated.critical_values[alpha]
        diff = cv_sim - cv_table
        
        status = "OK" if abs(diff) < tolerance else "CHECK"
        if abs(diff) >= tolerance:
            all_close = False
        
        pct = int(alpha * 100) if alpha * 100 == int(alpha * 100) else alpha * 100
        lines.append(f"{pct:>7}% {cv_table:>10.4f} {cv_sim:>10.4f} {diff:>+8.4f} {status}")
    
    lines.append("-" * 50)
    if all_close:
        lines.append("All critical values within tolerance ✓")
    else:
        lines.append(f"Some values differ by more than {tolerance}")
    
    return "\n".join(lines)
