# vedicsutragif

vedicsutragif is a Python library that provides fast and intuitive implementations of **Vedic Mathematics Sutras**, along with animated step-by-step GIF visualizations. It is designed for learning, teaching, and integrating Vedic Math techniques into Python applications.

---

## Features

- **Vedic Math Sutra Implementations**
  - Ekadhikena Purvena
  - Nikhilam Sutra
  - Urdhva Tiryak Sutra
  - Vedic Squaring and more

- **GIF Generation**
  - Each sutra method includes a GIF generator  
  - Visual step-by-step explanation  
  - Adjustable speed using `fps`

- **Clean Documentation**
  - Every method has a detailed docstring  
  - Input/Output explained  
  - GIF parameters explained

- **Optional PDF/Image Export**

---

## Installation

```bash
pip install vedicsutragif
```

---

## Contributing

Contributions are welcome! Feel free to submit issues or pull requests for new features or bug fixes.

---
