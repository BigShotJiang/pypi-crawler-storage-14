import logging

LOGGER_NAME = "pico_ioc"
LOGGER = logging.getLogger(LOGGER_NAME)

PICO_INFRA = "_pico_infra"
PICO_NAME = "_pico_name"
PICO_KEY = "_pico_key"
PICO_META = "_pico_meta"

