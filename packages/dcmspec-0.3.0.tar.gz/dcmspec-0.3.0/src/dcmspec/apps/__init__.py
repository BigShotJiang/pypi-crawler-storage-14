"""Application interfaces for dcmspec."""
