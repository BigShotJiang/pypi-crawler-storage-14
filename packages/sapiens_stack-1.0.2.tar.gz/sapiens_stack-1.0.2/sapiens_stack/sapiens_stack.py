# Module to execute the "stackOverflowPages" function directly in Google Colab.
# --------------------------> A SAPIENS TECHNOLOGY®️ PRODUCTION) <--------------------------
class SapiensStack:
	def __init__(self, show_errors=True, display_error_point=False):
		try:
			self.__show_errors = bool(show_errors) if type(show_errors) in (bool, int, float) else True
			self.__display_error_point = bool(display_error_point) if type(display_error_point) in (bool, int, float) else False
			from traceback import print_exc
			self.__print_exc = print_exc
			try:
				from warnings import filterwarnings
				from logging import getLogger, ERROR
				from bs4 import MarkupResemblesLocatorWarning
				filterwarnings('ignore')
				filterwarnings('ignore', category=UserWarning, module='torch.distributed')
				getLogger('torch.distributed.elastic.multiprocessing.redirects').setLevel(ERROR)
				filterwarnings('ignore', category=MarkupResemblesLocatorWarning)
			except: pass
		except Exception as error:
			try:
				if self.__show_errors:
					error_message = 'ERROR in SapiensStack.__init__: '+str(error)
					print(error_message)
					try: self.__print_exc() if self.__display_error_point else None
					except: pass
			except: pass
	def __replace_excessive_newlines(self, text=''):
	    try:
	        text = str(text).strip()
	        from re import sub
	        text = sub('[ \\t]*\\n[ \\t]*\\n[ \\t]*', '\n\n', text)
	        return sub('\n{3,}', '\n\n', text).strip()
	    except Exception as error:
	        if self.__show_errors:
	            error_message = 'ERROR in SapiensStack.__replace_excessive_newlines: '+str(error)
	            print(error_message)
	            try: self.__print_exc() if self.__display_error_point else None
	            except: pass
	        return ''
	def __create_text_file(self, content='', file_path='', add_content=False):
		try:
			text_file_created = False
			add_content = bool(add_content) if type(add_content) in (bool, int, float) else False
			content, file_path = str(content).strip() if not add_content else str(content), str(file_path).strip()
			state = 'a' if add_content else 'w'
			from os.path import exists
			if exists(file_path) and state == 'a' and self.__read_text_file(file_path=file_path): content = f'\n{content}'
			def _ensure_directory_for_file(file_path=''):
				from os.path import dirname, exists
				from os import makedirs
				directory_path = dirname(file_path)
				if directory_path and not exists(directory_path): makedirs(directory_path)
				return file_path
			from re import sub
			content = sub(r'[\u00a0\u2000-\u200f\u202f\u205f\u3000\u000b\u2060]', ' ', content)
			with open(_ensure_directory_for_file(file_path=file_path), state, encoding='utf-8', errors='replace') as file_handle: file_handle.write(content)
			text_file_created = exists(file_path)
			return text_file_created
		except Exception as error:
			if self.__show_errors:
				error_message = 'ERROR in SapiensStack.__create_text_file: '+str(error)
				print(error_message)
				try: self.__print_exc() if self.__display_error_point else None
				except: pass
			return False
	def __read_text_file(self, file_path=''):
		try:
			content = ''
			file_path = str(file_path).strip()
			from os.path import exists
			if not exists(file_path): return content
			try:
				with open(file_path, 'r', errors='replace') as file_handle: content = str(file_handle.read()).strip()
			except:
				for encoding in ('utf-8', 'latin-1', 'windows-1252'):
					try:
						with open(file_path, 'r', encoding=encoding, errors='ignore') as file_handle: content = str(file_handle.read()).strip()
						if content: break
					except: pass
			return content
		except Exception as error:
			if self.__show_errors:
				error_message = 'ERROR in SapiensStack.__read_text_file: '+str(error)
				print(error_message)
				try: self.__print_exc() if self.__display_error_point else None
				except: pass
			return ''
	def stackOverflowPages(self, dataset_path='', max_pages=1, end_tag='<|end|>', language=None, progress=True):
		try:
			page_content = ''
			dataset_path, end_tag = str(dataset_path).strip(), rf'{end_tag}'
			max_pages = max(1, int(max_pages)) if type(max_pages) in (bool, int, float) else 1
			language = str(language).strip() if language else 'en'
			if '-' in language: language = language.split('-')[0].strip()
			progress = bool(progress) if type(progress) in (bool, int, float) else True
			from bs4 import BeautifulSoup
			from html import unescape
			from base64 import b64decode
			from stackapi import StackAPI
			from random import randint
			from tqdm import tqdm
			from os.path import exists
			def _detect_language(tag={}):
				classes = tag.get('class', []) if tag else []
				for css_class in classes:
					if css_class.startswith('language-'): return css_class.replace('language-', '')
					if css_class.startswith('lang-'): return css_class.replace('lang-', '')
				return ''
			def _html_to_markdown(html_content=''):
				soup = BeautifulSoup(html_content, 'html.parser')
				for pre in soup.find_all('pre'):
					code_tag = pre.find('code')
					language = _detect_language(code_tag)
					code_text = pre.get_text()
					pre.replace_with(f'\n```{language}\n{code_text.rstrip()}\n```\n')
				for inline in soup.find_all('code'):
					if inline.parent.name != 'pre': inline.replace_with(f'`{inline.get_text()}`')
				text = unescape(soup.get_text())
				return '\n'.join(line.rstrip() for line in text.splitlines()).strip()
			def _decode(code=''): return b64decode(code.encode('utf-8')).decode('utf-8')
			stack_site = StackAPI('stackoverflow') if language == 'en' else StackAPI(f'{language}.stackoverflow')
			keys = (_decode(code='cmxfZ1hKVXVHUExuYkVjUWlTdnZWb0hCdTRwNA=='), _decode(code='cmxfSEFmdzNRNWNGcWNGd2U0NkcxM1RzMnJpeA=='))
			key_code = keys[randint(0, 1)]
			stack_site.key = key_code
			try: questions_data = stack_site.fetch('questions', sort='creation', page_size=max_pages, filter='withbody')
			except:
				if key_code == keys[0]: stack_site.key = keys[1]
				elif key_code == keys[1]: stack_site.key = keys[0]
				questions_data = stack_site.fetch('questions', sort='creation', page_size=max_pages, filter='withbody')
			with tqdm(questions_data['items'], desc='Processing pages', disable=not progress) as progress_bar:
				for question in progress_bar:
					if not question.get('is_answered'): continue
					html_to_markdown = _html_to_markdown(question.get('body', ''))
					page_content += f'{html_to_markdown}\n\n{end_tag}  \n\n'
					answers = stack_site.fetch('questions/{ids}/answers', ids=[question['question_id']], filter='withbody')
					for count, answer in enumerate(answers['items'], start=1):
						html_to_markdown = _html_to_markdown(answer.get('body', ''))
						page_content += f'{html_to_markdown}\n\n{end_tag}  \n\n'
					page_content = self.__replace_excessive_newlines(text=page_content)
					page_content = f'{page_content}\n\n{end_tag}  \n\n' if not page_content.strip().endswith(end_tag) else page_content	
					if dataset_path: page_content = '' if self.__create_text_file(content=page_content, file_path=dataset_path, add_content=True) else page_content
			return exists(dataset_path) if dataset_path else page_content
		except Exception as error:
			if self.__show_errors:
				error_message = 'ERROR in SapiensStack.stackOverflowPages: '+str(error)
				print(error_message)
				try: self.__print_exc() if self.__display_error_point else None
				except: pass
			return ''
# Module to execute the "stackOverflowPages" function directly in Google Colab.
# --------------------------> A SAPIENS TECHNOLOGY®️ PRODUCTION) <--------------------------
