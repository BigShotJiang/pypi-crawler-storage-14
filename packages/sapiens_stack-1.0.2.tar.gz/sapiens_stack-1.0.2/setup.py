# Module to execute the "stackOverflowPages" function directly in Google Colab.
# --------------------------> A SAPIENS TECHNOLOGY®️ PRODUCTION) <--------------------------
from setuptools import setup, find_packages
package_name = 'sapiens_stack'
version = '1.0.2'
setup(
    name=package_name,
    version=version,
    author='SAPIENS TECHNOLOGY',
    packages=find_packages(),
    include_package_data=True,
    install_requires=['tqdm', 'beautifulsoup4', 'StackAPI'],
    url='https://github.com/sapiens-technology/sapiens_stack',
    license='Proprietary Software'
)
# Module to execute the "stackOverflowPages" function directly in Google Colab.
# --------------------------> A SAPIENS TECHNOLOGY®️ PRODUCTION) <--------------------------
