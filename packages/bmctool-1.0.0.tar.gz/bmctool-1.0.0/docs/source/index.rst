.. BMCTool documentation

Welcome to BMCTool's documentation!
===================================

.. toctree::
   :maxdepth: 1

   user_guide
   contributor_guide
   api




Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
