protokolo.initialise module
===========================

.. automodule:: protokolo.initialise
   :members:
   :show-inheritance:
   :undoc-members:
