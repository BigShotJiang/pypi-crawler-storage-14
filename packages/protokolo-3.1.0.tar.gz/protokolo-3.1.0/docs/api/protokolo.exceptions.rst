protokolo.exceptions module
===========================

.. automodule:: protokolo.exceptions
   :members:
   :show-inheritance:
   :undoc-members:
