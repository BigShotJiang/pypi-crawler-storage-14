# -*- coding: utf-8 -*-
import os
import json

from tencentcloud.common.common_client import CommonClient
from tencentcloud.common import credential
from tencentcloud.common.exception.tencent_cloud_sdk_exception import TencentCloudSDKException
from tencentcloud.common.profile.client_profile import ClientProfile
from tencentcloud.common.profile.http_profile import HttpProfile

def req_create_migration_rag(secret_id: str, secret_key: str, ora_code: str, suffix: str, vendor: str):
    try:
        cred = credential.Credential(secret_id=secret_id, secret_key=secret_key)
        httpProfile = HttpProfile()
        httpProfile.endpoint = "trtccopilot.tencentcloudapi.com"
        clientProfile = ClientProfile()
        clientProfile.httpProfile = httpProfile

        params_json = {"Suffix": suffix, "Code": ora_code, "Vendor": vendor}
        params = json.dumps(params_json)

        common_client = CommonClient("trtccopilot", "2023-07-25", cred, "ap-guangzhou", profile=clientProfile)
        resp = common_client.call_json("CreateMigrationRag", json.loads(params))
        response = resp.get("Response", None)

        if response is not None:
            rag = response.get("RagText", None)
            if rag is not None:
                return rag
            else:
                error = response.get("Error", None)
                reqId = response.get("RequestId", None)
                errInfo = "Request failed."
                if error is not None:
                    errInfo += f" Error: {error}"
                if reqId is not None:
                    errInfo += f" RequestId: {reqId}"
                print(f"+> [Warn] CreateMigrationRag return error: {errInfo}")
                return errInfo
        else:
            return "response is None"
            
    except TencentCloudSDKException as err:
        print(f"+> [Warn] req CreateMigrationRag fail with: {err}")
        return f"request fail with err: {str(err)}"