import os

def get_env():
    secret_id = os.getenv("SECRET_ID")
    secret_key = os.getenv("SECRET_KEY")
    server_port = os.getenv("SERVER_PORT")

    return secret_id, secret_key, server_port