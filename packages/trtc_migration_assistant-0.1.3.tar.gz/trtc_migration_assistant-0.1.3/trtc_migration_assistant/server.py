import sys
from mcp.server.fastmcp import FastMCP
import env
import req

def main():
    secret_id, secret_key, server_port = env.get_env()
    if secret_id is None or secret_key is None:
        print("+> [Error] secret_id or secret_key is null")
        sys.exit(-1)
    
    mcp = FastMCP(name="trtc-migration-assistant", json_response=True)

    @mcp.tool()
    def get_migration_doc(ora_code: str, suffix: str, vendor: str) -> str:
        """ Provide the latest API document, guidance and parameter specifications for migration from Agora or Zego to TRTC

        Args:
            ora_code: User code that integrates Agora or Zego
            suffix: Identify the programming language of the user_input_code and pass the corresponding file extension suffix. For example, the suffix for Objective-C is m, for Swift it's swift, for Java it's java, for Kotlin it's kt, and for Dart it's dart. If the language cannot be identified, prompt the user to provide the file extension suffix
            vendor: Which vendor? If specified by the user, pass Agora or Zego. If not specified, pass Undecided
        
        Returns:   
            str: migration guidence and re api document
        """
        # if vendor != "Agora" and vendor != "Zego":
        #     return f"vendor: {vendor} not support yet"
        
        resp = req.req_create_migration_rag(secret_id=secret_id, secret_key=secret_key, ora_code=ora_code, suffix=suffix, vendor=vendor)
        return resp
    
    mcp.add_tool(get_migration_doc)

    mcp.settings.host = "0.0.0.0"
    run_port = 6675
    try:
        run_port = int(server_port)
    except ValueError:
        print(f"+> [Error] can't convert server_port: {server_port} to int, use default port")
    mcp.settings.port = run_port
    mcp.run(transport="streamable-http")
    # mcp.run(transport="sse")
    
if __name__ == "__main__":
    main()
