"""
Bangla OCR - The Best Bangla/Bengali Text Recognition Package

This module provides the BanglaOCR class for recognizing Bangla text from images.
Designed to work flawlessly on:
- Google Colab (all versions)
- Kaggle Notebooks (CPU, GPU, TPU)
- Local environments (Windows, Linux, macOS, Apple Silicon)
- Docker containers
- Cloud platforms (AWS, GCP, Azure)

Features:
- Zero dependency conflicts
- Smart fallbacks for all operations
- Works with or without OpenCV
- Supports CUDA, MPS (Apple Silicon), and CPU
- Accepts file paths, numpy arrays, PIL Images, URLs, and bytes

Author: Bangla OCR Team
Version: 1.0.0
License: MIT
"""

from __future__ import annotations

import io
import os
import pickle
import warnings
import urllib.request
import shutil
from pathlib import Path
from typing import List, Optional, Union

import numpy as np
import torch
import torchvision.transforms as T
from PIL import Image, ImageFilter

# Type alias for image inputs
ImageInput = Union[str, Path, np.ndarray, Image.Image, bytes]

# Smart OpenCV import with graceful fallback (no warning - PIL works fine)
_CV2_AVAILABLE = False
try:
    import cv2
    _CV2_AVAILABLE = True
except ImportError:
    pass  # Will use PIL fallback silently

from .model import BanglaOCR as BanglaOCRModel
from .services import Tokenizer


def _download_file(url: str, dest_path: Path):
    """Download file with simple progress indicator."""
    print(f"Downloading {dest_path.name} from {url}...")
    try:
        with urllib.request.urlopen(url) as response:
            total_size = int(response.info().get('Content-Length', 0))
            block_size = 8192
            
            dest_path.parent.mkdir(parents=True, exist_ok=True)
            
            with open(dest_path, 'wb') as f:
                downloaded = 0
                while True:
                    buffer = response.read(block_size)
                    if not buffer:
                        break
                    f.write(buffer)
                    downloaded += len(buffer)
                    if total_size > 0:
                        percent = downloaded * 100 / total_size
                        print(f"\rProgress: {percent:.1f}%", end='')
            print("\nDownload complete.")
    except Exception as e:
        if dest_path.exists():
            dest_path.unlink()
        raise RuntimeError(
            f"Failed to download {dest_path.name}.\n"
            f"Error: {e}\n"
            f"Please manually download from: {url}\n"
            f"And place it at: {dest_path}"
        )


def _ensure_numpy(img: np.ndarray) -> np.ndarray:
    """Ensure array is contiguous and correct dtype."""
    if not img.flags['C_CONTIGUOUS']:
        img = np.ascontiguousarray(img)
    return img.astype(np.uint8)


def _rgb_to_gray(img: np.ndarray) -> np.ndarray:
    """Convert RGB/RGBA to grayscale using luminosity method."""
    if len(img.shape) == 2:
        return img
    if img.shape[2] == 4:  # RGBA
        img = img[:, :, :3]
    # Luminosity method: 0.299*R + 0.587*G + 0.114*B
    return np.dot(img[..., :3], [0.299, 0.587, 0.114]).astype(np.uint8)


def _gaussian_blur_pil(img: np.ndarray, radius: int = 2) -> np.ndarray:
    """Apply Gaussian blur using PIL."""
    pil_img = Image.fromarray(img)
    blurred = pil_img.filter(ImageFilter.GaussianBlur(radius=radius))
    return np.array(blurred)


def _adaptive_threshold_pil(img: np.ndarray, block_size: int = 21) -> np.ndarray:
    """
    Apply adaptive thresholding using pure numpy/PIL.
    This is a high-quality fallback when OpenCV is not available.
    """
    # Apply blur first
    blurred = _gaussian_blur_pil(img, radius=2)
    
    # Calculate local mean using PIL's SMOOTH filter
    pil_img = Image.fromarray(blurred)
    for _ in range(3):
        pil_img = pil_img.filter(ImageFilter.SMOOTH)
    local_mean = np.array(pil_img).astype(np.float32)
    
    # Apply threshold: pixel > local_mean - C
    C = 10  # Constant subtracted from mean
    binary = ((blurred.astype(np.float32) > (local_mean - C)) * 255).astype(np.uint8)
    
    return binary


def _resize_pil(img: np.ndarray, size: tuple) -> np.ndarray:
    """Resize image using PIL with high-quality resampling."""
    pil_img = Image.fromarray(img)
    try:
        resized = pil_img.resize(size, Image.Resampling.LANCZOS)
    except AttributeError:
        # Fallback for older PIL versions (< 9.1.0)
        resized = pil_img.resize(size, Image.LANCZOS)
    return np.array(resized)


class BanglaOCR:
    """
    Bangla OCR - The Best Bangla/Bengali Text Recognition.
    
    Recognizes Bangla handwritten and printed text from images using
    a Transformer-based architecture with ResNet-18 backbone.
    
    Works perfectly on:
    - Google Colab (all versions, all runtimes)
    - Kaggle Notebooks (CPU, GPU, TPU)
    - Local environments (Windows, Linux, macOS, Apple Silicon)
    - Docker containers
    - Cloud platforms (AWS, GCP, Azure)
    
    Args:
        model_path: Path to the trained model checkpoint (.pth file)
        tokenizer_path: Path to the tokenizer pickle file (.pk file)
        device: Device for inference ('cuda', 'cpu', 'mps', or None for auto)
        d_model: Hidden dimension (auto-detected from filename if not provided)
        nheads: Number of attention heads (auto-detected if not provided)
        num_decoder_layers: Number of decoder layers (auto-detected if not provided)
    
    Example:
        >>> from bangla_ocr import BanglaOCR
        >>> 
        >>> # Initialize with model and tokenizer
        >>> ocr = BanglaOCR('model.pth', 'tokenizer.pk')
        >>> 
        >>> # Predict from file path
        >>> text = ocr.predict('bangla_image.jpg')
        >>> print(text)
        >>> 
        >>> # Predict from PIL Image
        >>> from PIL import Image
        >>> img = Image.open('image.png')
        >>> text = ocr.predict(img)
        >>> 
        >>> # Predict from numpy array
        >>> import numpy as np
        >>> arr = np.array(Image.open('image.jpg'))
        >>> text = ocr.predict(arr)
        >>> 
        >>> # Batch prediction
        >>> texts = ocr.predict_batch(['img1.jpg', 'img2.jpg', 'img3.jpg'])
        >>> 
        >>> # Predict from URL
        >>> text = ocr.predict('https://example.com/bangla.jpg')
    """
    
    def __init__(
        self, 
        model_path: Optional[Union[str, Path]] = None, 
        tokenizer_path: Optional[Union[str, Path]] = None, 
        device: Optional[str] = None,
        d_model: Optional[int] = None,
        nheads: Optional[int] = None,
        num_decoder_layers: Optional[int] = None,
        force_download: bool = False
    ):
        # Default filenames and URLs
        default_model = 'bangla_ocr_model.pth'
        default_tokenizer = 'bangla_ocr_tokenizer.pk'
        base_url = "https://github.com/ayan-cs/bangla-ocr-transformer/releases/download/v1.0.0"
        
        # Storage directory: ~/.bangla_ocr
        storage_dir = Path.home() / '.bangla_ocr'
        storage_dir.mkdir(parents=True, exist_ok=True)
        
        # Resolve model path
        if model_path is None:
            model_path = storage_dir / default_model
            if not model_path.exists() or force_download:
                print(f"Model not found at {model_path}. Downloading...")
                _download_file(f"{base_url}/{default_model}", model_path)
        else:
            # User provided a path, check if it exists
            model_path = Path(model_path)
            if not model_path.exists():
                print(f"Warning: Provided model path '{model_path}' does not exist.")
                print("Falling back to automatic download...")
                model_path = storage_dir / default_model
                if not model_path.exists() or force_download:
                    print(f"Model not found at {model_path}. Downloading...")
                    _download_file(f"{base_url}/{default_model}", model_path)
        
        # Resolve tokenizer path
        if tokenizer_path is None:
            tokenizer_path = storage_dir / default_tokenizer
            if not tokenizer_path.exists() or force_download:
                print(f"Tokenizer not found at {tokenizer_path}. Downloading...")
                _download_file(f"{base_url}/{default_tokenizer}", tokenizer_path)
        else:
            # User provided a path, check if it exists
            tokenizer_path = Path(tokenizer_path)
            if not tokenizer_path.exists():
                print(f"Warning: Provided tokenizer path '{tokenizer_path}' does not exist.")
                print("Falling back to automatic download...")
                tokenizer_path = storage_dir / default_tokenizer
                if not tokenizer_path.exists() or force_download:
                    print(f"Tokenizer not found at {tokenizer_path}. Downloading...")
                    _download_file(f"{base_url}/{default_tokenizer}", tokenizer_path)

        # Convert to Path objects for better handling
        model_path = Path(model_path)
        tokenizer_path = Path(tokenizer_path)
        
        # Auto-detect best available device
        self.device = self._get_best_device(device)
        
        # Load tokenizer first
        self._load_tokenizer(tokenizer_path)
        
        # Get model parameters from args or filename
        self.model_params = self._get_model_params(
            model_path, d_model, nheads, num_decoder_layers
        )
        
        # Load model
        self._load_model(model_path)
        
        # Image transform pipeline
        self.transform = T.Compose([T.ToTensor()])
        
        # Processing settings
        self.target_size = (360, 640)  # (width, height)

    def recognize(self, image: ImageInput) -> str:
        """Alias for predict() method."""
        return self.predict(image)
    
    def _get_best_device(self, device: Optional[str]) -> str:
        """Auto-detect the best available device."""
        if device is not None:
            return device
        
        # Check CUDA (NVIDIA GPU)
        if torch.cuda.is_available():
            return 'cuda'
        
        # Check MPS (Apple Silicon M1/M2/M3)
        try:
            if hasattr(torch.backends, 'mps') and torch.backends.mps.is_available():
                # Verify MPS actually works
                try:
                    _ = torch.zeros(1).to('mps')
                    return 'mps'
                except Exception:
                    pass
        except Exception:
            pass
        
        return 'cpu'
    
    def _load_tokenizer(self, tokenizer_path: Path) -> None:
        """Load the tokenizer from pickle file."""
        if not tokenizer_path.exists():
            raise FileNotFoundError(
                f"Tokenizer not found at: {tokenizer_path}\n"
                "Please provide a valid tokenizer.pk file."
            )
        
        try:
            with open(tokenizer_path, 'rb') as f:
                self.tokenizer = pickle.load(f)
        except Exception as e:
            raise RuntimeError(f"Failed to load tokenizer: {e}")
    
    def _get_model_params(
        self, 
        model_path: Path,
        d_model: Optional[int],
        nheads: Optional[int],
        num_decoder_layers: Optional[int]
    ) -> dict:
        """Get model parameters from args or parse from filename."""
        if all(x is not None for x in [d_model, nheads, num_decoder_layers]):
            return {
                'd_model': d_model,
                'nheads': nheads,
                'num_decoder_layers': num_decoder_layers
            }
        
        # Try to parse from filename: BanglaOCR_epochs_d_model_nheads_layers.pth
        try:
            parts = model_path.stem.split('_')
            if len(parts) >= 5:
                return {
                    'd_model': int(parts[2]),
                    'nheads': int(parts[3]),
                    'num_decoder_layers': int(parts[4])
                }
        except (ValueError, IndexError):
            pass
        
        # Default parameters
        return {
            'd_model': 256,
            'nheads': 4,
            'num_decoder_layers': 4
        }
    
    def _load_model(self, model_path: Path) -> None:
        """Load the model checkpoint."""
        if not model_path.exists():
            raise FileNotFoundError(
                f"Model not found at: {model_path}\n"
                "Please provide a valid .pth model file."
            )
        
        # Initialize model architecture
        self.model = BanglaOCRModel(
            vocab_len=self.tokenizer.vocab_size,
            max_text_length=self.tokenizer.maxlen,
            hidden_dim=self.model_params['d_model'],
            nheads=self.model_params['nheads'],
            num_decoder_layers=self.model_params['num_decoder_layers']
        )
        
        # Load state dict with compatibility handling for all PyTorch versions
        try:
            # PyTorch 2.0+ with weights_only for security
            state_dict = torch.load(
                model_path, 
                map_location=self.device, 
                weights_only=True
            )
        except TypeError:
            # Older PyTorch versions
            state_dict = torch.load(model_path, map_location=self.device)
        except Exception:
            # Handle pickle issues
            state_dict = torch.load(
                model_path, 
                map_location=self.device,
                pickle_module=pickle
            )
        
        self.model.load_state_dict(state_dict)
        self.model = self.model.to(self.device)
        self.model.eval()

    def _load_image(self, img_input: ImageInput) -> np.ndarray:
        """
        Load image from various sources and convert to grayscale numpy array.
        
        Supports:
        - File path (str or Path)
        - PIL Image
        - Numpy array
        - Bytes (raw image data)
        - URL (http/https)
        
        Args:
            img_input: Image in any supported format
            
        Returns:
            Grayscale image as numpy array
        """
        # Handle bytes (raw image data)
        if isinstance(img_input, bytes):
            pil_img = Image.open(io.BytesIO(img_input))
            return np.array(pil_img.convert('L'))
        
        # Handle Path objects
        if isinstance(img_input, Path):
            img_input = str(img_input)
        
        # Handle string (file path or URL)
        if isinstance(img_input, str):
            # Check if it's a URL
            if img_input.startswith(('http://', 'https://')):
                try:
                    import urllib.request
                    with urllib.request.urlopen(img_input, timeout=30) as response:
                        img_data = response.read()
                    pil_img = Image.open(io.BytesIO(img_data))
                    return np.array(pil_img.convert('L'))
                except Exception as e:
                    raise ValueError(f"Failed to load image from URL: {e}")
            
            # It's a file path
            if not os.path.exists(img_input):
                raise FileNotFoundError(f"Image not found: {img_input}")
            
            pil_img = Image.open(img_input)
            return np.array(pil_img.convert('L'))
        
        # Handle PIL Image
        if isinstance(img_input, Image.Image):
            return np.array(img_input.convert('L'))
        
        # Handle numpy array
        if isinstance(img_input, np.ndarray):
            img = _ensure_numpy(img_input)
            return _rgb_to_gray(img)
        
        raise TypeError(
            f"Unsupported image type: {type(img_input)}\n"
            "Supported: str, Path, PIL.Image, numpy.ndarray, bytes, URL"
        )

    def _binarize_image(self, img: np.ndarray) -> np.ndarray:
        """Apply adaptive thresholding for binarization (better text recognition)."""
        if _CV2_AVAILABLE:
            # OpenCV method (slightly better quality)
            blurred = cv2.GaussianBlur(img, (5, 5), 0)
            binary = cv2.adaptiveThreshold(
                blurred, 255, 
                cv2.ADAPTIVE_THRESH_GAUSSIAN_C, 
                cv2.THRESH_BINARY, 21, 10
            )
            return binary
        else:
            # PIL-based fallback (high quality, no OpenCV needed)
            return _adaptive_threshold_pil(img)

    def _resize_image(self, img: np.ndarray, target_size: tuple = None) -> np.ndarray:
        """Resize image maintaining aspect ratio with padding."""
        if target_size is None:
            target_size = self.target_size
            
        h, w = img.shape[:2]
        target_w, target_h = target_size
        
        # Calculate new dimensions maintaining 16:9 aspect ratio
        new_height = int(np.ceil((w * 16) / 9))
        if h > new_height:
            new_width = int(np.ceil((h * 9) / 16))
            new_img = np.full((h, new_width), 255, dtype=np.uint8)
            new_img[:, :w] = img
        else:
            new_img = np.full((new_height, w), 255, dtype=np.uint8)
            new_img[:h, :] = img
        
        # Resize using OpenCV or PIL
        if _CV2_AVAILABLE:
            return cv2.resize(new_img, target_size, interpolation=cv2.INTER_LANCZOS4)
        else:
            return _resize_pil(new_img, target_size)

    def preprocess(self, img_input: ImageInput) -> np.ndarray:
        """
        Preprocess image for OCR recognition.
        
        Pipeline:
        1. Load image and convert to grayscale
        2. Apply adaptive binarization for better text contrast
        3. Resize with aspect ratio preservation and padding
        4. Convert to 3-channel for ResNet backbone
        
        Args:
            img_input: Image (path, PIL, numpy, bytes, or URL)
            
        Returns:
            Preprocessed image as (H, W, 3) numpy array
        """
        # Load and convert to grayscale
        image = self._load_image(img_input)
        
        # Binarize for better text/background separation
        image = self._binarize_image(image)
        
        # Resize with padding
        image = self._resize_image(image)
        
        # Convert to 3-channel (required by ResNet backbone)
        image = np.repeat(image[..., np.newaxis], 3, axis=-1)
        
        return _ensure_numpy(image)

    def _get_memory(self, imgs: torch.Tensor) -> torch.Tensor:
        """Compute encoder memory from image features."""
        x = self.model.conv(self.model.get_feature(imgs))
        bs, _, H, W = x.shape
        pos = torch.cat([
            self.model.col_embed[:W].unsqueeze(0).repeat(H, 1, 1),
            self.model.row_embed[:H].unsqueeze(1).repeat(1, W, 1),
        ], dim=-1).flatten(0, 1).unsqueeze(1)
        return pos + 0.1 * x.flatten(2).permute(2, 0, 1)

    @torch.inference_mode()
    def predict(self, image: ImageInput) -> str:
        """
        Recognize Bangla text from an image.
        
        Args:
            image: Input image in any supported format:
                   - File path (str or Path)
                   - PIL Image
                   - Numpy array
                   - Bytes (raw image data)
                   - URL (http:// or https://)
            
        Returns:
            Recognized Bangla text as string
            
        Example:
            >>> ocr = BanglaOCR('model.pth', 'tokenizer.pk')
            >>> 
            >>> # From file path
            >>> text = ocr.predict('bangla_text.jpg')
            >>> 
            >>> # From PIL Image
            >>> from PIL import Image
            >>> text = ocr.predict(Image.open('image.png'))
            >>> 
            >>> # From URL
            >>> text = ocr.predict('https://example.com/bangla.jpg')
        """
        # Preprocess image
        img = self.preprocess(image)
        
        # Transform and add batch dimension
        img = self.transform(img)
        imgs = img.unsqueeze(0).to(self.device)
        
        # Compute encoder memory
        memory = self._get_memory(imgs.float())
        
        # Autoregressive decoding
        sos_idx = self.tokenizer.chars.index('SOS')
        eos_idx = self.tokenizer.chars.index('EOS')
        out_indexes = [sos_idx]
        
        for _ in range(self.tokenizer.maxlen):
            mask = self.model.generate_square_subsequent_mask(
                len(out_indexes)
            ).to(self.device)
            
            trg_tensor = torch.LongTensor(out_indexes).unsqueeze(1).to(self.device)
            
            output = self.model.vocab(
                self.model.tf_decoder(
                    self.model.query_pos(self.model.decoder(trg_tensor)), 
                    memory, 
                    tgt_mask=mask
                )
            )
            
            out_token = output.argmax(2)[-1].item()
            
            if out_token == eos_idx:
                break
            
            out_indexes.append(out_token)
        
        # Decode (skip SOS token)
        return self.tokenizer.decode(out_indexes[1:])
    
    def predict_batch(
        self, 
        images: List[ImageInput],
        show_progress: bool = False
    ) -> List[str]:
        """
        Recognize Bangla text from multiple images.
        
        Args:
            images: List of images in any supported format
            show_progress: Show progress indicator (default: False)
            
        Returns:
            List of recognized texts
            
        Example:
            >>> texts = ocr.predict_batch(['img1.jpg', 'img2.jpg', 'img3.jpg'])
            >>> for i, text in enumerate(texts):
            ...     print(f"Image {i+1}: {text}")
        """
        results = []
        total = len(images)
        
        for i, img in enumerate(images):
            if show_progress:
                print(f"\rProcessing: {i+1}/{total}", end='', flush=True)
            
            try:
                text = self.predict(img)
                results.append(text)
            except Exception as e:
                warnings.warn(f"Failed to process image {i}: {e}")
                results.append("")
        
        if show_progress:
            print()  # New line after progress
        
        return results
    
    def __repr__(self) -> str:
        return (
            f"BanglaOCR(\n"
            f"  device='{self.device}',\n"
            f"  d_model={self.model_params['d_model']},\n"
            f"  nheads={self.model_params['nheads']},\n"
            f"  num_decoder_layers={self.model_params['num_decoder_layers']},\n"
            f"  vocab_size={self.tokenizer.vocab_size},\n"
            f"  max_length={self.tokenizer.maxlen}\n"
            f")"
        )
    
    def __str__(self) -> str:
        return f"BanglaOCR(device='{self.device}')"
    
    @property
    def info(self) -> dict:
        """
        Get model and environment information.
        
        Returns:
            Dictionary with version, device, model params, and environment info
        """
        return {
            'version': '1.0.0',
            'device': self.device,
            'd_model': self.model_params['d_model'],
            'nheads': self.model_params['nheads'],
            'num_decoder_layers': self.model_params['num_decoder_layers'],
            'vocab_size': self.tokenizer.vocab_size,
            'max_text_length': self.tokenizer.maxlen,
            'opencv_available': _CV2_AVAILABLE,
            'cuda_available': torch.cuda.is_available(),
            'mps_available': hasattr(torch.backends, 'mps') and torch.backends.mps.is_available() if hasattr(torch, 'backends') else False,
        }
