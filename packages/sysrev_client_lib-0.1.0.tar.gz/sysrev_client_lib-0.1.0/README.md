# Sysrev Client Library

Python client library for the [Sysrev](https://sysrev.com) API.

## Installation

```bash
pip install sysrev_client_lib
```

## Requirements

- Python 3.11 or higher

## Usage

```python
from sysrev_client import Client

# Initialize the client
client = Client(base_url="https://api.sysrev.com")

# Use the client to interact with the Sysrev API
# (Add specific usage examples based on your API)
```

## Features

- Python client for the Sysrev API
- Type-safe API interactions
- Built with modern Python (3.11+)

## Development

This library is part of the [sysrev-client](https://github.com/sysrev/sysrev-client) monorepo, built using the Polylith architecture.

## License

MIT License - see [LICENSE](https://github.com/sysrev/sysrev-client/blob/master/LICENSE) for details.

## Links

- [GitHub Repository](https://github.com/sysrev/sysrev-client)
- [Issue Tracker](https://github.com/sysrev/sysrev-client/issues)
- [Sysrev](https://sysrev.com)
