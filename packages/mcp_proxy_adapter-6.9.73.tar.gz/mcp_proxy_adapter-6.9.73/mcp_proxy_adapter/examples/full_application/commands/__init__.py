"""
Commands package for full application example.
"""
# Note: Old commands (EchoCommand, ListCommand, HelpCommand) are not imported
# to avoid import errors. They use BaseCommand which doesn't exist.
# Use built-in commands from the framework instead.

__all__ = []