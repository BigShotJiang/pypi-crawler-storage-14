import math
from scipy.stats import norm

def z_test_one_mean(xbar, mu0, sigma, n, alpha=0.05):
    """
    Perform a Z-test for one mean.

    Parameters:
    - xbar: sample mean
    - mu0: population mean under H0
    - sigma: population standard deviation
    - n: sample size
    - alpha: significance level (default 0.05)

    Returns:
    - z: Z-statistic
    - p_value: two-sided p-value
    """
    z = (xbar - mu0) / (sigma / math.sqrt(n))
    p_value = 2 * (1 - norm.cdf(abs(z)))
    z_crit = norm.ppf(1 - alpha / 2)

    print("\n--- Z-Test for One Mean ---")
    print(f"Z-statistic = {z:.3f}")
    print(f"p-value = {p_value:.4f}")
    print(f"Critical Region: |Z| > {z_crit:.3f}")

    if abs(z) > z_crit:
        print("Decision: Reject H₀ → Significant difference exists.")
        print("Type I Error (α):", alpha)
    else:
        print("Decision: Fail to reject H₀ → No significant difference.")
        print("Type II Error (β): Not calculated (depends on true mean).")

    return z, p_value


def z_test_two_proportions(n1, x1, n2, x2, alpha=0.05):
    """
    Perform a Z-test for the difference of two proportions.

    Parameters:
    - n1: sample size for group 1
    - x1: number of successes in group 1
    - n2: sample size for group 2
    - x2: number of successes in group 2
    - alpha: significance level (default 0.05)

    Returns:
    - z: Z-statistic
    - p_value: two-sided p-value
    """
    p1 = x1 / n1
    p2 = x2 / n2
    p_pool = (x1 + x2) / (n1 + n2)

    z = (p1 - p2) / math.sqrt(p_pool * (1 - p_pool) * (1 / n1 + 1 / n2))
    p_value = 2 * (1 - norm.cdf(abs(z)))
    z_crit = norm.ppf(1 - alpha / 2)

    print("\n--- Z-Test for Difference of Two Proportions ---")
    print(f"Z-statistic = {z:.3f}")
    print(f"p-value = {p_value:.4f}")
    print(f"Critical Region: |Z| > {z_crit:.3f}")

    if abs(z) > z_crit:
        print("Decision: Reject H₀ → Proportions differ significantly.")
        print("Type I Error (α):", alpha)
    else:
        print("Decision: Fail to reject H₀ → No significant difference.")
        print("Type II Error (β): Not calculated (depends on true p1, p2).")

    return z, p_value

def ci_one_mean_t(n, xbar, sd, confidence=0.95):
    """
    Confidence Interval for ONE Normal Mean (t-based).
    Use when population SD is unknown (real-world data).
    """
    import math
    from scipy import stats

    alpha = 1 - confidence
    t_crit = stats.t.ppf(1 - alpha/2, df=n-1)

    margin = t_crit * (sd / math.sqrt(n))
    lower = xbar - margin
    upper = xbar + margin

    print(f"\nT-based {int(confidence*100)}% CI for mean = ({lower:.3f}, {upper:.3f})")
    return lower, upper

def ci_one_mean_z(n, xbar, sigma, confidence=0.95):
    """
    Confidence Interval for ONE Mean (z-based).
    Use when population SD (sigma) is known.
    """
    import math
    from scipy.stats import norm

    alpha = 1 - confidence
    z_crit = norm.ppf(1 - alpha/2)

    margin = z_crit * (sigma / math.sqrt(n))
    lower = xbar - margin
    upper = xbar + margin

    print(f"\nZ-based {int(confidence*100)}% CI for mean = ({lower:.3f}, {upper:.3f})")
    return lower, upper

def ci_two_means_independent_t(n1, mean1, sd1, n2, mean2, sd2, confidence=0.95):
    """
    Confidence Interval for the Difference of Two Independent Means (Welch's t-CI).
    Use when population SDs are unknown and variances may differ.
    """
    import math
    from scipy import stats

    alpha = 1 - confidence

    # Standard error
    se = math.sqrt((sd1**2 / n1) + (sd2**2 / n2))

    # Welch degrees of freedom
    df = (se**4) / (
        (sd1**4 / (n1**2 * (n1 - 1))) +
        (sd2**4 / (n2**2 * (n2 - 1)))
    )

    t_crit = stats.t.ppf(1 - alpha/2, df=df)

    diff = mean1 - mean2
    margin = t_crit * se
    lower = diff - margin
    upper = diff + margin

    print(f"\nT-based {int(confidence*100)}% CI for difference (x1 - x2) = ({lower:.3f}, {upper:.3f})")
    return lower, upper

def ci_two_means_independent_z(n1, mean1, sigma1, n2, mean2, sigma2, confidence=0.95):
    """
    Z-based CI for difference of two means.
    Use when population standard deviations are known.
    """
    import math
    from scipy.stats import norm

    alpha = 1 - confidence
    z_crit = norm.ppf(1 - alpha/2)

    se = math.sqrt((sigma1**2 / n1) + (sigma2**2 / n2))

    diff = mean1 - mean2
    margin = z_crit * se
    lower = diff - margin
    upper = diff + margin

    print(f"\nZ-based {int(confidence*100)}% CI for difference (x1 - x2) = ({lower:.3f}, {upper:.3f})")
    return lower, upper
