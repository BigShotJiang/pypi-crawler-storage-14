from gooddata_api_client.paths.api_v1_actions_workspaces_workspace_id_execution_afm_execute_result_result_id.get import ApiForget


class ApiV1ActionsWorkspacesWorkspaceIdExecutionAfmExecuteResultResultId(
    ApiForget,
):
    pass
