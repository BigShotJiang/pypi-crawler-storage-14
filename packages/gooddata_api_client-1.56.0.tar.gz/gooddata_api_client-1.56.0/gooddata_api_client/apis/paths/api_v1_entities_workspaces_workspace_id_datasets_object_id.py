from gooddata_api_client.paths.api_v1_entities_workspaces_workspace_id_datasets_object_id.get import ApiForget


class ApiV1EntitiesWorkspacesWorkspaceIdDatasetsObjectId(
    ApiForget,
):
    pass
