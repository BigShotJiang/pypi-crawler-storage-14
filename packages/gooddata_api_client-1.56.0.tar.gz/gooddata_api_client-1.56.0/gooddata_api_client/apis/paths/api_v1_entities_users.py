from gooddata_api_client.paths.api_v1_entities_users.get import ApiForget
from gooddata_api_client.paths.api_v1_entities_users.post import ApiForpost


class ApiV1EntitiesUsers(
    ApiForget,
    ApiForpost,
):
    pass
