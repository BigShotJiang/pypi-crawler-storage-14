from gooddata_api_client.paths.api_v1_actions_workspaces_workspace_id_check_entity_overrides.post import ApiForpost


class ApiV1ActionsWorkspacesWorkspaceIdCheckEntityOverrides(
    ApiForpost,
):
    pass
