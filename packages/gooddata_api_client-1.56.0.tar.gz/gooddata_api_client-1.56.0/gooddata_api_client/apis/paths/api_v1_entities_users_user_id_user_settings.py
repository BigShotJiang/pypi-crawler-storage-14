from gooddata_api_client.paths.api_v1_entities_users_user_id_user_settings.get import ApiForget
from gooddata_api_client.paths.api_v1_entities_users_user_id_user_settings.post import ApiForpost


class ApiV1EntitiesUsersUserIdUserSettings(
    ApiForget,
    ApiForpost,
):
    pass
