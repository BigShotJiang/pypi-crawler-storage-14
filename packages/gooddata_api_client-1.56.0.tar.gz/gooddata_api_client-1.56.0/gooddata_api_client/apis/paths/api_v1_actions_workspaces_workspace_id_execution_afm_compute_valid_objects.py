from gooddata_api_client.paths.api_v1_actions_workspaces_workspace_id_execution_afm_compute_valid_objects.post import ApiForpost


class ApiV1ActionsWorkspacesWorkspaceIdExecutionAfmComputeValidObjects(
    ApiForpost,
):
    pass
