from gooddata_api_client.paths.api_v1_entities_workspaces_workspace_id_attributes.get import ApiForget


class ApiV1EntitiesWorkspacesWorkspaceIdAttributes(
    ApiForget,
):
    pass
