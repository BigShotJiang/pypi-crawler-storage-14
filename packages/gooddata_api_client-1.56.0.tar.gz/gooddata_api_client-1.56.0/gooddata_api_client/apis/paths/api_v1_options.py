from gooddata_api_client.paths.api_v1_options.get import ApiForget


class ApiV1Options(
    ApiForget,
):
    pass
