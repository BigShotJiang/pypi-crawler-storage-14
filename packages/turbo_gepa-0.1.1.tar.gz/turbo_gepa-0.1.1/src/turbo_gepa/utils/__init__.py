"""Shared utilities for TurboGEPA."""

