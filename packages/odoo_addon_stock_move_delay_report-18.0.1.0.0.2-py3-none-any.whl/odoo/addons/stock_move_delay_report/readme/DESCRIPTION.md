This module adds a report to check the delay from incoming and outgoing
moves grouped by Responsible Partner.
