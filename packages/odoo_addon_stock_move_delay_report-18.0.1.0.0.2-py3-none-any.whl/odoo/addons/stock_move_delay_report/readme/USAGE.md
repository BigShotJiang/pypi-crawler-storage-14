Go to Inventory -\> Reporting -\> Delay Analysis.

Here there are 3 views:

Graph View: Shows the mean delay days of the stock moves for each
partner with incoming or outgoing moves.

Pivot View: Shows the mean delay days of the stock moves for each
partner with incoming or outgoing moves. Also shows the % of moves done
on time.

Tree View: Shows all the done moves grouped by the partner responsible
(in charge) of the picking.
