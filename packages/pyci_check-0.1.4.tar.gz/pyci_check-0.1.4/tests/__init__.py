"""Tests for pyci-check."""
