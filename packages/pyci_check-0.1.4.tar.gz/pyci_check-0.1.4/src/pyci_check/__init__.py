"""快速的 Python 語法與 import 檢查工具."""

__version__ = "0.1.4"
