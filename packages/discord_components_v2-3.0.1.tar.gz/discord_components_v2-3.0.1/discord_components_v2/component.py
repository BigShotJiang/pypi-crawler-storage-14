from typing import Optional, Union, List, Iterable, Any
from discord import PartialEmoji, Emoji, InvalidArgument
from uuid import uuid1
from enum import IntEnum

__all__ = (
    "Component",
    "ComponentType",
    "Container",
    "LayoutDirection",
    "Separator",
    "SeparatorSpacing",
    "MediaGallery",
    "ContentContainer",
    "HeadingLevel",
    "TextComponent",
    "HeadingComponent",
    "MediaItem",
    "ButtonStyle",
    "Button",
    "Select",
    "SelectOption",
    "TextInput",
    "TextInputStyle",
    "Modal",
    "ActionRow",
    "_get_component_type",
)


def _get_partial_emoji(emoji: Union[Emoji, PartialEmoji, str]) -> PartialEmoji:
    if isinstance(emoji, Emoji):
        return PartialEmoji(name=emoji.name, animated=emoji.animated, id=emoji.id)
    elif isinstance(emoji, PartialEmoji):
        return emoji
    elif isinstance(emoji, str):
        return PartialEmoji(name=emoji)


class ComponentType(IntEnum):
    action_row = 1
    button = 2
    string_select = 3
    text_input = 4
    user_select = 5
    role_select = 6
    mentionable_select = 7
    channel_select = 8
    container = 9
    separator = 10
    text = 11
    media_gallery = 12
    content_container = 13
    heading = 14
    file_upload = 15


class LayoutDirection(IntEnum):
    horizontal = 1
    vertical = 2


class SeparatorSpacing(IntEnum):
    small = 1
    large = 2


class HeadingLevel(IntEnum):
    heading_1 = 1
    heading_2 = 2
    heading_3 = 3


class Component:
    def to_dict(self) -> dict:
        raise NotImplementedError

    @classmethod
    def from_json(cls, data: dict):
        raise NotImplementedError


class Container(Component):
    __slots__ = ("_components", "_direction")

    def __init__(
        self,
        *components: List[Component],
        direction: int = LayoutDirection.vertical
    ):
        self._components = list(components) if components else []
        self._direction = direction

    def to_dict(self) -> dict:
        return {
            "type": ComponentType.container,
            "components": [c.to_dict() for c in self.components],
            "direction": self.direction
        }

    @property
    def components(self) -> List[Component]:
        return self._components

    @property
    def direction(self) -> int:
        return self._direction

    @components.setter
    def components(self, value: List[Component]):
        self._components = value

    @direction.setter
    def direction(self, value: int):
        self._direction = value

    def add_component(self, component: Component):
        self._components.append(component)
        return self

    @classmethod
    def from_json(cls, data: dict):
        components = []
        for comp_data in data.get("components", []):
            comp_type = _get_component_type(comp_data.get("type"))
            if comp_type:
                components.append(comp_type.from_json(comp_data))
        return cls(*components, direction=data.get("direction", LayoutDirection.vertical))


class Separator(Component):
    __slots__ = ("_spacing", "_divider")

    def __init__(self, spacing: int = SeparatorSpacing.small, divider: bool = False):
        self._spacing = spacing
        self._divider = divider

    def to_dict(self) -> dict:
        return {
            "type": ComponentType.separator,
            "spacing": self.spacing,
            "divider": self.divider
        }

    @property
    def spacing(self) -> int:
        return self._spacing

    @property
    def divider(self) -> bool:
        return self._divider

    @spacing.setter
    def spacing(self, value: int):
        self._spacing = value

    @divider.setter
    def divider(self, value: bool):
        self._divider = value

    @classmethod
    def from_json(cls, data: dict):
        return cls(
            spacing=data.get("spacing", SeparatorSpacing.small),
            divider=data.get("divider", False)
        )


class TextComponent(Component):
    __slots__ = ("_text", "_alignment")

    def __init__(self, text: str, alignment: str = "left"):
        self._text = text
        self._alignment = alignment

    def to_dict(self) -> dict:
        return {
            "type": ComponentType.text,
            "text": self.text,
            "alignment": self.alignment
        }

    @property
    def text(self) -> str:
        return self._text

    @property
    def alignment(self) -> str:
        return self._alignment

    @text.setter
    def text(self, value: str):
        self._text = value

    @alignment.setter
    def alignment(self, value: str):
        self._alignment = value

    @classmethod
    def from_json(cls, data: dict):
        return cls(
            text=data.get("text", ""),
            alignment=data.get("alignment", "left")
        )


class HeadingComponent(Component):
    __slots__ = ("_text", "_level")

    def __init__(self, text: str, level: int = HeadingLevel.heading_1):
        self._text = text
        self._level = level

    def to_dict(self) -> dict:
        return {
            "type": ComponentType.heading,
            "text": self.text,
            "level": self.level
        }

    @property
    def text(self) -> str:
        return self._text

    @property
    def level(self) -> int:
        return self._level

    @text.setter
    def text(self, value: str):
        self._text = value

    @level.setter
    def level(self, value: int):
        self._level = value

    @classmethod
    def from_json(cls, data: dict):
        return cls(
            text=data.get("text", ""),
            level=data.get("level", HeadingLevel.heading_1)
        )


class MediaItem:
    __slots__ = ("_url", "_description", "_spoiler")

    def __init__(self, url: str, description: str = None, spoiler: bool = False):
        self._url = url
        self._description = description
        self._spoiler = spoiler

    def to_dict(self) -> dict:
        data = {"url": self.url}
        if self.description:
            data["description"] = self.description
        if self.spoiler:
            data["spoiler"] = self.spoiler
        return data

    @property
    def url(self) -> str:
        return self._url

    @property
    def description(self) -> Optional[str]:
        return self._description

    @property
    def spoiler(self) -> bool:
        return self._spoiler


class MediaGallery(Component):
    __slots__ = ("_items",)

    def __init__(self, *items: MediaItem):
        self._items = list(items) if items else []

    def to_dict(self) -> dict:
        return {
            "type": ComponentType.media_gallery,
            "items": [item.to_dict() for item in self.items]
        }

    @property
    def items(self) -> List[MediaItem]:
        return self._items

    def add_item(self, item: MediaItem):
        self._items.append(item)
        return self

    @classmethod
    def from_json(cls, data: dict):
        items = [MediaItem(**item) for item in data.get("items", [])]
        return cls(*items)


class ContentContainer(Component):
    __slots__ = ("_title", "_icon", "_components")

    def __init__(
        self,
        *components: Component,
        title: str = None,
        icon: str = None
    ):
        self._components = list(components) if components else []
        self._title = title
        self._icon = icon

    def to_dict(self) -> dict:
        data = {
            "type": ComponentType.content_container,
            "components": [c.to_dict() for c in self.components]
        }
        if self.title:
            data["title"] = self.title
        if self.icon:
            data["icon"] = self.icon
        return data

    @property
    def components(self) -> List[Component]:
        return self._components

    @property
    def title(self) -> Optional[str]:
        return self._title

    @property
    def icon(self) -> Optional[str]:
        return self._icon

    def add_component(self, component: Component):
        self._components.append(component)
        return self

    @classmethod
    def from_json(cls, data: dict):
        components = []
        for comp_data in data.get("components", []):
            comp_type = _get_component_type(comp_data.get("type"))
            if comp_type:
                components.append(comp_type.from_json(comp_data))
        return cls(
            *components,
            title=data.get("title"),
            icon=data.get("icon")
        )


class SelectOption(Component):
    __slots__ = ("_label", "_value", "_emoji", "_description", "_default")

    def __init__(
        self,
        *,
        label: str,
        value: str,
        emoji: Union[Emoji, PartialEmoji, str] = None,
        description: str = None,
        default: bool = False,
    ):
        self._label = label
        self._value = value
        self._description = description
        self._default = default

        if emoji is not None:
            self.emoji = _get_partial_emoji(emoji)
        else:
            self._emoji = None

    def to_dict(self) -> dict:
        data = {
            "label": self.label,
            "value": self.value,
            "description": self.description,
            "default": self.default,
        }
        if self.emoji is not None:
            data["emoji"] = self.emoji.to_dict()
        return data

    @property
    def label(self) -> str:
        return self._label

    @property
    def value(self) -> str:
        return self._value

    @property
    def emoji(self) -> Optional[PartialEmoji]:
        return self._emoji

    @property
    def description(self) -> str:
        return self._description

    @property
    def default(self) -> bool:
        return self._default

    @label.setter
    def label(self, value: str):
        if not len(value):
            raise InvalidArgument("Label must not be empty.")
        self._label = value

    @value.setter
    def value(self, value: str):
        self._value = value

    @emoji.setter
    def emoji(self, emoji: Union[Emoji, PartialEmoji, str]):
        self._emoji = _get_partial_emoji(emoji)

    @description.setter
    def description(self, value: str):
        self._description = value

    @default.setter
    def default(self, value: bool):
        self._default = value

    def set_label(self, value: str):
        self.label = value
        return self

    def set_value(self, value: str):
        self.value = value
        return self

    def set_emoji(self, emoji: Union[Emoji, PartialEmoji, str]):
        self.emoji = emoji
        return self

    def set_description(self, value: str):
        self.description = value
        return self

    def set_default(self, value: bool):
        self.default = value
        return self

    @classmethod
    def from_json(cls, data: dict):
        emoji = data.get("emoji")
        return cls(
            label=data.get("label"),
            value=data.get("value"),
            emoji=PartialEmoji(
                name=emoji["name"],
                animated=emoji.get("animated", False),
                id=emoji.get("id"),
            )
            if emoji
            else None,
            description=data.get("description"),
            default=data.get("default", False),
        )


class Select(Component):
    __slots__ = (
        "_id",
        "_options",
        "_placeholder",
        "_min_values",
        "_max_values",
        "_disabled",
        "_type",
    )

    def __init__(
        self,
        *,
        options: List[SelectOption] = None,
        id: str = None,
        custom_id: str = None,
        placeholder: str = None,
        min_values: int = 1,
        max_values: int = 1,
        disabled: bool = False,
        select_type: int = ComponentType.string_select,
    ):
        if options and ((not len(options)) or (len(options) > 25)):
            raise InvalidArgument("Options length should be between 1 and 25.")

        self._id = id or custom_id or str(uuid1())
        self._options = options or []
        self._placeholder = placeholder
        self._min_values = min_values
        self._max_values = max_values
        self._disabled = disabled
        self._type = select_type

    def to_dict(self) -> dict:
        data = {
            "type": self._type,
            "custom_id": self.id,
            "placeholder": self.placeholder,
            "min_values": self.min_values,
            "max_values": self.max_values,
            "disabled": self.disabled,
        }
        if self.options:
            data["options"] = list(map(lambda option: option.to_dict(), self.options))
        return data

    @property
    def id(self) -> str:
        return self._id

    @property
    def custom_id(self) -> str:
        return self._id

    @property
    def options(self) -> List[SelectOption]:
        return self._options

    @property
    def placeholder(self) -> str:
        return self._placeholder

    @property
    def min_values(self) -> int:
        return self._min_values

    @property
    def max_values(self) -> int:
        return self._max_values

    @property
    def disabled(self) -> bool:
        return self._disabled

    @id.setter
    def id(self, value: str):
        self._id = value

    @custom_id.setter
    def custom_id(self, value: str):
        self._id = value

    @options.setter
    def options(self, value: List[SelectOption]):
        if value and ((not len(value)) or (len(value) > 25)):
            raise InvalidArgument("Options length should be between 1 and 25.")
        self._options = value

    @placeholder.setter
    def placeholder(self, value: str):
        self._placeholder = value

    @min_values.setter
    def min_values(self, value: int):
        self._min_values = value

    @max_values.setter
    def max_values(self, value: int):
        self._max_values = value

    @disabled.setter
    def disabled(self, value: bool):
        self._disabled = value

    def set_id(self, value: str):
        self.id = value
        return self

    def set_custom_id(self, value: str):
        self.custom_id = value
        return self

    def set_options(self, value: List[SelectOption]):
        self.options = value
        return self

    def set_placeholder(self, value: str):
        self.placeholder = value
        return self

    def set_min_values(self, value: int):
        self.min_values = value
        return self

    def set_max_values(self, value: int):
        self.max_values = value
        return self

    def set_disabled(self, value: bool):
        self.disabled = value
        return self

    @classmethod
    def from_json(cls, data: dict):
        return cls(
            id=data.get("custom_id"),
            options=list(map(lambda x: SelectOption.from_json(x), data.get("options", []))),
            placeholder=data.get("placeholder"),
            min_values=data.get("min_values"),
            max_values=data.get("max_values"),
            disabled=data.get("disabled", False),
            select_type=data.get("type", ComponentType.string_select),
        )


class ButtonStyle(IntEnum):
    primary = 1
    blue = 1
    secondary = 2
    gray = 2
    grey = 2
    success = 3
    green = 3
    danger = 4
    red = 4
    link = 5
    URL = 5


class Button(Component):
    __slots__ = ("_style", "_label", "_id", "_url", "_disabled", "_emoji")

    def __init__(
        self,
        *,
        label: str = None,
        style: int = ButtonStyle.secondary,
        id: str = None,
        custom_id: str = None,
        url: str = None,
        disabled: bool = False,
        emoji: Union[Emoji, PartialEmoji, str] = None,
    ):
        self._style = style
        self._label = label
        self._url = url
        self._disabled = disabled

        if emoji is not None:
            self._emoji = _get_partial_emoji(emoji)
        else:
            self._emoji = None

        if not self.style == ButtonStyle.link:
            self._id = id or custom_id or str(uuid1())
        else:
            self._id = None

    def to_dict(self) -> dict:
        data = {
            "type": ComponentType.button,
            "style": self.style,
            "label": self.label,
            "custom_id": self.id,
            "url": self.url if self.style == ButtonStyle.link else None,
            "disabled": self.disabled,
        }
        if self.emoji:
            data["emoji"] = self.emoji.to_dict()
        return data

    @property
    def style(self) -> int:
        return self._style

    @property
    def label(self) -> str:
        return self._label

    @property
    def id(self) -> str:
        return self._id

    @property
    def custom_id(self) -> str:
        return self._id

    @property
    def url(self) -> Optional[str]:
        return self._url

    @property
    def disabled(self) -> bool:
        return self._disabled

    @property
    def emoji(self) -> PartialEmoji:
        return self._emoji

    @style.setter
    def style(self, value: int):
        if value == ButtonStyle.link and self.id:
            raise InvalidArgument("Both ID and URL are set.")
        if not (1 <= value <= ButtonStyle.link):
            raise InvalidArgument(f"Style must be between 1, {ButtonStyle.link}.")
        self._style = value

    @label.setter
    def label(self, value: str):
        if not value and not self.emoji:
            raise InvalidArgument("Label should not be empty.")
        self._label = value

    @url.setter
    def url(self, value: str):
        if value and self.style != ButtonStyle.link:
            raise InvalidArgument("Button style is not link. You shouldn't provide URL.")
        self._url = value

    @id.setter
    def id(self, value: str):
        if self.style == ButtonStyle.link:
            raise InvalidArgument("Button style is set to link. You shouldn't provide ID.")
        self._id = value

    @custom_id.setter
    def custom_id(self, value: str):
        if self.style == ButtonStyle.link:
            raise InvalidArgument("Button style is set to link. You shouldn't provide ID.")
        self._id = value

    @disabled.setter
    def disabled(self, value: bool):
        self._disabled = value

    @emoji.setter
    def emoji(self, emoji: Union[Emoji, PartialEmoji, str]):
        self._emoji = _get_partial_emoji(emoji)

    def set_style(self, value: int):
        self.style = value
        return self

    def set_label(self, value: str):
        self.label = value
        return self

    def set_url(self, value: str):
        self.url = value
        return self

    def set_id(self, value: str):
        self.id = value
        return self

    def set_custom_id(self, value: str):
        self.custom_id = value
        return self

    def set_disabled(self, value: bool):
        self.disabled = value
        return self

    def set_emoji(self, emoji: Union[Emoji, PartialEmoji, str]):
        self.emoji = emoji
        return self

    @classmethod
    def from_json(cls, data: dict):
        emoji = data.get("emoji")
        return cls(
            style=data.get("style"),
            label=data.get("label"),
            id=data.get("custom_id"),
            url=data.get("url"),
            disabled=data.get("disabled", False),
            emoji=PartialEmoji(
                name=emoji["name"],
                animated=emoji.get("animated", False),
                id=emoji.get("id"),
            )
            if emoji
            else None,
        )


class TextInputStyle(IntEnum):
    short = 1
    paragraph = 2


class TextInput(Component):
    __slots__ = (
        "_id",
        "_label",
        "_style",
        "_placeholder",
        "_value",
        "_required",
        "_min_length",
        "_max_length",
    )

    def __init__(
        self,
        *,
        label: str,
        custom_id: str = None,
        style: int = TextInputStyle.short,
        placeholder: str = None,
        value: str = None,
        required: bool = True,
        min_length: int = None,
        max_length: int = None,
    ):
        self._label = label
        self._id = custom_id or str(uuid1())
        self._style = style
        self._placeholder = placeholder
        self._value = value
        self._required = required
        self._min_length = min_length
        self._max_length = max_length

    def to_dict(self) -> dict:
        data = {
            "type": ComponentType.text_input,
            "custom_id": self.custom_id,
            "label": self.label,
            "style": self.style,
            "required": self.required,
        }
        if self.placeholder:
            data["placeholder"] = self.placeholder
        if self.value:
            data["value"] = self.value
        if self.min_length is not None:
            data["min_length"] = self.min_length
        if self.max_length is not None:
            data["max_length"] = self.max_length
        return data

    @property
    def custom_id(self) -> str:
        return self._id

    @property
    def label(self) -> str:
        return self._label

    @property
    def style(self) -> int:
        return self._style

    @property
    def placeholder(self) -> Optional[str]:
        return self._placeholder

    @property
    def value(self) -> Optional[str]:
        return self._value

    @property
    def required(self) -> bool:
        return self._required

    @property
    def min_length(self) -> Optional[int]:
        return self._min_length

    @property
    def max_length(self) -> Optional[int]:
        return self._max_length

    @custom_id.setter
    def custom_id(self, value: str):
        self._id = value

    @label.setter
    def label(self, value: str):
        self._label = value

    @style.setter
    def style(self, value: int):
        self._style = value

    @placeholder.setter
    def placeholder(self, value: str):
        self._placeholder = value

    @value.setter
    def value(self, value: str):
        self._value = value

    @required.setter
    def required(self, value: bool):
        self._required = value

    @min_length.setter
    def min_length(self, value: int):
        self._min_length = value

    @max_length.setter
    def max_length(self, value: int):
        self._max_length = value

    def set_custom_id(self, value: str):
        self.custom_id = value
        return self

    def set_label(self, value: str):
        self.label = value
        return self

    def set_style(self, value: int):
        self.style = value
        return self

    def set_placeholder(self, value: str):
        self.placeholder = value
        return self

    def set_value(self, value: str):
        self.value = value
        return self

    def set_required(self, value: bool):
        self.required = value
        return self

    def set_min_length(self, value: int):
        self.min_length = value
        return self

    def set_max_length(self, value: int):
        self.max_length = value
        return self

    @classmethod
    def from_json(cls, data: dict):
        return cls(
            label=data.get("label"),
            custom_id=data.get("custom_id"),
            style=data.get("style", TextInputStyle.short),
            placeholder=data.get("placeholder"),
            value=data.get("value"),
            required=data.get("required", True),
            min_length=data.get("min_length"),
            max_length=data.get("max_length"),
        )


class Modal:
    __slots__ = ("_title", "_custom_id", "_components")

    def __init__(
        self,
        *,
        title: str,
        custom_id: str = None,
        components: List[Union["ActionRow", TextInput, List[TextInput]]] = None,
    ):
        self._title = title
        self._custom_id = custom_id or str(uuid1())
        self._components = components or []

    def to_dict(self) -> dict:
        from .utils import _get_components_json
        
        return {
            "title": self.title,
            "custom_id": self.custom_id,
            "components": _get_components_json(self.components),
        }

    @property
    def title(self) -> str:
        return self._title

    @property
    def custom_id(self) -> str:
        return self._custom_id

    @property
    def components(self) -> List:
        return self._components

    @title.setter
    def title(self, value: str):
        self._title = value

    @custom_id.setter
    def custom_id(self, value: str):
        self._custom_id = value

    @components.setter
    def components(self, value: List):
        self._components = value

    def set_title(self, value: str):
        self.title = value
        return self

    def set_custom_id(self, value: str):
        self.custom_id = value
        return self

    def set_components(self, value: List):
        self.components = value
        return self

    def add_component(self, component):
        self.components.append(component)
        return self


class ActionRow(Component):
    __slots__ = ("_components",)

    def __init__(self, *args: List[Component]):
        self._components = list(args) if args is not None else []

    def disable_components(self):
        def disable(component: Component):
            if hasattr(component, 'disabled'):
                component.disabled = True
            return component

        self._components = list(map(disable, self._components))
        return self

    def __list__(self) -> List[Component]:
        return self.components

    def __len__(self) -> int:
        return len(self.components)

    def __iter__(self) -> Iterable[Component]:
        return iter(self.components)

    def __getitem__(self, index: int) -> Component:
        return self.components[index]

    def __setitem__(self, index: int, value: Component):
        self._components[index] = value

    def __delitem__(self, index: int):
        del self._components[index]

    def to_dict(self) -> dict:
        data = {
            "type": ComponentType.action_row,
            "components": [component.to_dict() for component in self.components],
        }
        return data

    def append(self, component: Component):
        self.components.append(component)

    @property
    def components(self) -> List[Component]:
        return self._components

    @components.setter
    def components(self, value: List[Component]):
        self._components = value

    def set_components(self, value: List[Component]):
        self.components = value
        return self

    def add_component(self, value: Component):
        self.components.append(value)
        return self

    @classmethod
    def from_json(cls, data: dict):
        components = []
        for component in data.get("components", []):
            comp_type = _get_component_type(component.get("type"))
            if comp_type:
                components.append(comp_type.from_json(component))
        return cls(*components)


def _get_component_type(type: int):
    return {
        ComponentType.action_row: ActionRow,
        ComponentType.button: Button,
        ComponentType.string_select: Select,
        ComponentType.text_input: TextInput,
        ComponentType.user_select: Select,
        ComponentType.role_select: Select,
        ComponentType.mentionable_select: Select,
        ComponentType.channel_select: Select,
        ComponentType.container: Container,
        ComponentType.separator: Separator,
        ComponentType.text: TextComponent,
        ComponentType.media_gallery: MediaGallery,
        ComponentType.content_container: ContentContainer,
        ComponentType.heading: HeadingComponent,
    }.get(type)
