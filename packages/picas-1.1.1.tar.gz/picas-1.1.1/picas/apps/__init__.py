# Make this a package so that entry_points target `picas.apps.picas:main` is importable.
