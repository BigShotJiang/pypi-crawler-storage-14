VM_NAME = 'ibm-watsonx-orchestrate'
OS_MAC = 'Darwin'
DEFAULT_CPUS = 8 # cores
DEFAULT_MEMORY = 16 # cores
DEFAULT_DISK_SPACE = 100 # gb
CPU_ARCH_X86 = 'amd64'
CPU_ARCH_ARM = 'arm64'