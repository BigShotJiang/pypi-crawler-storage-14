"""
AgenticWerx MCP Client - Simple rule retrieval client

This module implements a simple MCP server that connects to your
AgenticWerx MCP server to retrieve rules.

Available Tools:
- get_rules: Get AgenticWerx marketplace rule packages
- get_custom_rules: Get user-uploaded custom rules (Pro/Pro Plus)
- get_team_rules: Get team-shared custom rules (Pro Plus teams)
- analyze_code: Analyze code with selected rules
- list_external_mcp_servers: Discover available external MCP servers (from Lambda)
- get_external_mcp_server: Get connection details for external servers (from Lambda)
- connect_external_server: Connect to external MCP servers (supports serverId or manual)
- list_external_connections: List connected external servers
- disconnect_external_server: Disconnect from external server
- call_external_tool: Call a tool on a connected external server
"""

import json
import logging
import os
from typing import Any

from mcp.server import Server
from mcp.server.models import InitializationOptions
from mcp.types import Resource, TextContent, Tool

from .api import AgenticWerxAPI, AgenticWerxAPIError
from .mcp_connection_manager import MCPConnectionManager

logger = logging.getLogger(__name__)


class AgenticWerxMCPClient:
    """
    Simple AgenticWerx MCP Client for rule retrieval.

    This client connects to your AgenticWerx MCP server and provides
    a simple interface to get rules through the MCP protocol.
    """

    def __init__(self, api_key: str, debug: bool = False):
        """
        Initialize the MCP client.

        Args:
            api_key: AgenticWerx API key
            debug: Enable debug logging
        """
        self.api_key = api_key
        self.debug = debug

        # Initialize the API client
        self.api = AgenticWerxAPI(api_key)

        # Initialize the MCP server
        self.server = Server("agenticwerx")

        # Initialize connection manager for external MCP servers with persistence
        connection_options = {
            "autoReconnect": True,  # Automatically restore connections on startup
        }
        # Only set custom persistence path if environment variable is set
        persistence_path = os.getenv("MCP_CONNECTIONS_FILE")
        if persistence_path:
            connection_options["persistencePath"] = persistence_path
        
        self.connection_manager = MCPConnectionManager(connection_options)

        # Configure logging
        if debug:
            logging.getLogger().setLevel(logging.DEBUG)

        logger.info("Initializing AgenticWerx MCP Client")

        # Set up MCP handlers
        self._setup_handlers()

    def _setup_handlers(self) -> None:
        """Set up MCP server handlers."""

        @self.server.list_resources()
        async def list_resources() -> list[Resource]:
            """List available rule resources."""
            logger.debug("Listing available rule resources")

            try:
                # Test if we can get rules from the Lambda MCP server
                await self.api.get_rules()

                # Create a single resource for all rules
                resource = Resource(
                    uri="agenticwerx://rules",
                    name="AgenticWerx Rules",
                    description="All available AgenticWerx rules from Lambda MCP server",
                    mimeType="application/json",
                )

                logger.info("Listed rule resources from Lambda MCP server")
                return [resource]

            except AgenticWerxAPIError as e:
                logger.error(f"API error listing resources: {e}")
                return []
            except Exception as e:
                logger.error(f"Unexpected error listing resources: {e}")
                return []

        @self.server.read_resource()
        async def read_resource(uri: str) -> str:
            """Read rule resource."""
            logger.debug(f"Reading resource: {uri}")

            if uri != "agenticwerx://rules":
                raise ValueError(f"Unknown resource URI: {uri}")

            try:
                rules_data = await self.api.get_rules()
                logger.debug("Successfully read rules resource from Lambda MCP server")
                return json.dumps(rules_data, indent=2)

            except AgenticWerxAPIError as e:
                logger.error(f"API error reading resource: {e}")
                raise
            except Exception as e:
                logger.error(f"Unexpected error reading resource: {e}")
                raise ValueError(f"Failed to read resource: {str(e)}") from e

        @self.server.list_tools()
        async def list_tools() -> list[Tool]:
            """List available tools."""
            logger.debug("Listing available tools")

            # Provide get_rules, get_custom_rules, get_team_rules, and analyze_code tools
            tools = [
                Tool(
                    name="get_rules",
                    description=(
                        "Get available rules for subscribed packages.\n\n"
                        "📋 Response Modes:\n"
                        "  • Summary (default): Just id, title, category, severity\n"
                        "  • Detailed (detailed=true): Includes instructions, rationale, tags, references\n"
                        "  • With Content (includeContent=true): Full markdown/JSON content\n"
                        "  • With Patterns (includePatterns=true + detailed=true): Regex patterns\n\n"
                        "💡 Tip: Start with summary mode, then use detailed=true or includeContent=true "
                        "when you need more information about specific rules."
                    ),
                    inputSchema={
                        "type": "object",
                        "properties": {
                            "packageId": {
                                "type": "string",
                                "description": "Specific package ID (optional)",
                            },
                            "language": {
                                "type": "string",
                                "description": "Filter by programming language (e.g., typescript, python, go)",
                            },
                            "framework": {
                                "type": "string",
                                "description": "Filter by framework (e.g., react, nextjs, express)",
                            },
                            "category": {
                                "type": "string",
                                "description": "Filter by category (e.g., security, api-design, testing)",
                            },
                            "severity": {
                                "type": "string",
                                "description": "Filter by severity (critical, high, medium, low)",
                            },
                            "appliesTo": {
                                "type": "string",
                                "description": "Filter by applies to (e.g., frontend, backend, api, all)",
                            },
                            "search": {
                                "type": "string",
                                "description": "Search in rule titles and descriptions",
                            },
                            "ruleIds": {
                                "type": "array",
                                "items": {"type": "string"},
                                "description": "Get specific rules by ID",
                            },
                            "detailed": {
                                "type": "boolean",
                                "description": "⭐ Get full rule details (instructions, rationale, tags). Default: false",
                            },
                            "includeContent": {
                                "type": "boolean",
                                "description": "⭐ Get complete rule content (markdown/JSON). Warning: Large responses. Default: false",
                            },
                            "includePatterns": {
                                "type": "boolean",
                                "description": "⭐ Include regex patterns (requires detailed=true). Default: false",
                            },
                            "limit": {
                                "type": "number",
                                "description": "Maximum rules to return (1-200). Default: 50",
                            },
                            "offset": {
                                "type": "number",
                                "description": "Skip N rules for pagination. Default: 0",
                            },
                        },
                        "additionalProperties": False,
                    },
                ),
                Tool(
                    name="get_custom_rules",
                    description=(
                        "Get user-uploaded custom rules (Pro/Pro Plus only).\n\n"
                        "Custom rules are rules you've uploaded to your AgenticWerx account. "
                        "These are private to your account and can be used alongside marketplace rules.\n\n"
                        "📋 Response Modes:\n"
                        "  • Summary (default): Just id, title, category, severity\n"
                        "  • Detailed (detailed=true): Includes instructions, rationale, tags, references\n"
                        "  • With Content (includeContent=true): Full markdown/JSON content\n"
                        "  • With Patterns (includePatterns=true + detailed=true): Regex patterns\n\n"
                        "💡 Tip: Same filtering options as get_rules."
                    ),
                    inputSchema={
                        "type": "object",
                        "properties": {
                            "language": {
                                "type": "string",
                                "description": "Filter by programming language (e.g., typescript, python, go)",
                            },
                            "framework": {
                                "type": "string",
                                "description": "Filter by framework (e.g., react, nextjs, express)",
                            },
                            "category": {
                                "type": "string",
                                "description": "Filter by category (e.g., security, api-design, testing)",
                            },
                            "severity": {
                                "type": "string",
                                "description": "Filter by severity (critical, high, medium, low)",
                            },
                            "appliesTo": {
                                "type": "string",
                                "description": "Filter by applies to (e.g., frontend, backend, api, all)",
                            },
                            "search": {
                                "type": "string",
                                "description": "Search in rule titles and descriptions",
                            },
                            "ruleIds": {
                                "type": "array",
                                "items": {"type": "string"},
                                "description": "Get specific rules by ID",
                            },
                            "detailed": {
                                "type": "boolean",
                                "description": "⭐ Get full rule details (instructions, rationale, tags). Default: false",
                            },
                            "includeContent": {
                                "type": "boolean",
                                "description": "⭐ Get complete rule content (markdown/JSON). Warning: Large responses. Default: false",
                            },
                            "includePatterns": {
                                "type": "boolean",
                                "description": "⭐ Include regex patterns (requires detailed=true). Default: false",
                            },
                            "limit": {
                                "type": "number",
                                "description": "Maximum rules to return (1-200). Default: 50",
                            },
                            "offset": {
                                "type": "number",
                                "description": "Skip N rules for pagination. Default: 0",
                            },
                        },
                        "additionalProperties": False,
                    },
                ),
                Tool(
                    name="get_team_rules",
                    description=(
                        "Get team-shared custom rules (Pro Plus teams only).\n\n"
                        "Team rules are custom rules shared across your Pro Plus team. "
                        "These are visible to all team members and can be used alongside marketplace and custom rules.\n\n"
                        "📋 Response Modes:\n"
                        "  • Summary (default): Just id, title, category, severity\n"
                        "  • Detailed (detailed=true): Includes instructions, rationale, tags, references\n"
                        "  • With Content (includeContent=true): Full markdown/JSON content\n"
                        "  • With Patterns (includePatterns=true + detailed=true): Regex patterns\n\n"
                        "💡 Tip: Same filtering options as get_rules."
                    ),
                    inputSchema={
                        "type": "object",
                        "properties": {
                            "language": {
                                "type": "string",
                                "description": "Filter by programming language (e.g., typescript, python, go)",
                            },
                            "framework": {
                                "type": "string",
                                "description": "Filter by framework (e.g., react, nextjs, express)",
                            },
                            "category": {
                                "type": "string",
                                "description": "Filter by category (e.g., security, api-design, testing)",
                            },
                            "severity": {
                                "type": "string",
                                "description": "Filter by severity (critical, high, medium, low)",
                            },
                            "appliesTo": {
                                "type": "string",
                                "description": "Filter by applies to (e.g., frontend, backend, api, all)",
                            },
                            "search": {
                                "type": "string",
                                "description": "Search in rule titles and descriptions",
                            },
                            "ruleIds": {
                                "type": "array",
                                "items": {"type": "string"},
                                "description": "Get specific rules by ID",
                            },
                            "detailed": {
                                "type": "boolean",
                                "description": "⭐ Get full rule details (instructions, rationale, tags). Default: false",
                            },
                            "includeContent": {
                                "type": "boolean",
                                "description": "⭐ Get complete rule content (markdown/JSON). Warning: Large responses. Default: false",
                            },
                            "includePatterns": {
                                "type": "boolean",
                                "description": "⭐ Include regex patterns (requires detailed=true). Default: false",
                            },
                            "limit": {
                                "type": "number",
                                "description": "Maximum rules to return (1-200). Default: 50",
                            },
                            "offset": {
                                "type": "number",
                                "description": "Skip N rules for pagination. Default: 0",
                            },
                        },
                        "additionalProperties": False,
                    },
                ),
                Tool(
                    name="analyze_code",
                    description="Analyze code using AgenticWerx rules. Provide code snippet, optional language, and optional package IDs.",
                    inputSchema={
                        "type": "object",
                        "properties": {
                            "code": {
                                "type": "string",
                                "description": "Code to analyze",
                            },
                            "language": {
                                "type": "string",
                                "description": "Programming language (optional, will be auto-detected)",
                            },
                            "packageIds": {
                                "type": "array",
                                "items": {"type": "string"},
                                "description": "List of package IDs to use for analysis (optional)",
                            },
                        },
                        "required": ["code"],
                        "additionalProperties": False,
                    },
                ),
                # External MCP server discovery tools (from Lambda)
                Tool(
                    name="list_external_mcp_servers",
                    description=(
                        "Discover available external MCP servers from the AgenticWerx registry.\n\n"
                        "Returns a list of pre-configured external MCP servers that you can connect to, "
                        "including GitHub, AWS Documentation, PostgreSQL, and more.\n\n"
                        "Use this to discover what servers are available before connecting."
                    ),
                    inputSchema={
                        "type": "object",
                        "properties": {},
                        "additionalProperties": False,
                    },
                ),
                Tool(
                    name="get_external_mcp_server",
                    description=(
                        "Get detailed connection information for a specific external MCP server.\n\n"
                        "Returns the command, arguments, and environment variables needed to connect "
                        "to the specified server. Use this information with connect_external_server."
                    ),
                    inputSchema={
                        "type": "object",
                        "properties": {
                            "serverId": {
                                "type": "string",
                                "description": "Server ID from the registry (e.g., 'github', 'aws-documentation')",
                            }
                        },
                        "required": ["serverId"],
                        "additionalProperties": False,
                    },
                ),
                # External MCP server management tools
                Tool(
                    name="connect_external_server",
                    description=(
                        "Connect to an external MCP server (AWS Documentation, GitHub, PostgreSQL, etc.). "
                        "Connections are automatically saved and restored on restart.\n\n"
                        "You can either:\n"
                        "1. Use list_external_mcp_servers and get_external_mcp_server to discover servers, then connect by serverId\n"
                        "2. Manually specify the command, args, and env\n\n"
                        "Example servers:\n"
                        "  • github: GitHub repository access\n"
                        "  • aws-documentation: AWS documentation search\n"
                        "  • postgres: PostgreSQL database access\n\n"
                        "Note: You'll need appropriate credentials in environment variables."
                    ),
                    inputSchema={
                        "type": "object",
                        "properties": {
                            "serverId": {
                                "type": "string",
                                "description": "Server ID from registry (e.g., 'github'). Use list_external_mcp_servers to discover. If provided, command/args are fetched automatically.",
                            },
                            "name": {
                                "type": "string",
                                "description": "Server name (optional if serverId is provided, otherwise required)",
                            },
                            "command": {
                                "type": "string",
                                "description": "Command to run (e.g., 'npx', 'uvx'). Required if serverId not provided.",
                            },
                            "args": {
                                "type": "array",
                                "items": {"type": "string"},
                                "description": "Command arguments. Required if serverId not provided.",
                            },
                            "env": {
                                "type": "object",
                                "description": "Environment variables required by the server",
                                "additionalProperties": {"type": "string"},
                            },
                        },
                        "additionalProperties": False,
                    },
                ),
                Tool(
                    name="list_external_connections",
                    description="List all currently connected external MCP servers and their available tools",
                    inputSchema={
                        "type": "object",
                        "properties": {},
                        "additionalProperties": False,
                    },
                ),
                Tool(
                    name="disconnect_external_server",
                    description="Disconnect from an external MCP server and remove from saved connections",
                    inputSchema={
                        "type": "object",
                        "properties": {
                            "serverName": {
                                "type": "string",
                                "description": "Name of the server to disconnect",
                            }
                        },
                        "required": ["serverName"],
                        "additionalProperties": False,
                    },
                ),
                Tool(
                    name="call_external_tool",
                    description=(
                        "Call a tool on a connected external MCP server. "
                        "This is the universal way to use any external server tool."
                    ),
                    inputSchema={
                        "type": "object",
                        "properties": {
                            "serverName": {
                                "type": "string",
                                "description": "Name of the connected server (e.g., 'github')",
                            },
                            "toolName": {
                                "type": "string",
                                "description": "Name of the tool to call (e.g., 'search_repositories')",
                            },
                            "arguments": {
                                "type": "object",
                                "description": "Arguments to pass to the tool",
                                "additionalProperties": True,
                            },
                        },
                        "required": ["serverName", "toolName"],
                        "additionalProperties": False,
                    },
                ),
            ]

            # Add tools from connected external servers (with prefix)
            connections = self.connection_manager.list_connections()
            for conn in connections:
                connection = self.connection_manager.get_connection(conn["name"])
                if connection and connection.tools:
                    for tool in connection.tools:
                        tools.append(
                            Tool(
                                name=f"{conn['name']}__{tool['name']}",
                                description=f"[{conn['name']}] {tool.get('description', '')}",
                                inputSchema=tool.get("inputSchema", {"type": "object"}),
                            )
                        )

            logger.info(f"Listed {len(tools)} available tools")
            return tools

        @self.server.call_tool()
        async def call_tool(name: str, arguments: dict[str, Any]) -> list[TextContent]:
            """Execute a tool."""
            logger.debug(f"Executing tool: {name}")

            try:
                if name == "get_rules":
                    # Handle get_rules tool with enhanced parameters
                    detailed = arguments.get("detailed", False)
                    include_content = arguments.get("includeContent", False)
                    include_patterns = arguments.get("includePatterns", False)

                    # Build params dict with all parameters
                    params = {
                        "packageId": arguments.get("packageId"),
                        "language": arguments.get("language"),
                        "framework": arguments.get("framework"),
                        "category": arguments.get("category"),
                        "severity": arguments.get("severity"),
                        "appliesTo": arguments.get("appliesTo"),
                        "search": arguments.get("search"),
                        "ruleIds": arguments.get("ruleIds"),
                        "limit": arguments.get("limit", 50),
                        "offset": arguments.get("offset", 0),
                        "detailed": detailed,
                        "includePatterns": include_patterns,
                        "includeContent": include_content,
                    }

                    # Remove None values
                    params = {k: v for k, v in params.items() if v is not None}

                    # Call the API with all parameters
                    result = await self.api.call_tool("get_rules", params)

                    # Parse the response - Lambda returns content array
                    content = result.get("content", [])

                    # Extract message and rules data from content array
                    message_text = ""
                    rules_data = None

                    for item in content:
                        if item.get("type") == "text":
                            text = item.get("text", "")
                            # Try to parse as JSON (second content item)
                            try:
                                parsed = json.loads(text)
                                if "rules" in parsed and "summary" in parsed:
                                    rules_data = parsed
                            except json.JSONDecodeError:
                                # First content item - the message from Lambda
                                message_text = text

                    # If no rules data found, return just the message
                    if not rules_data:
                        return [
                            TextContent(
                                type="text",
                                text=message_text or "No rules found",
                            )
                        ]

                    # Extract summary for hints
                    summary = rules_data.get("summary", {})
                    has_more = summary.get("hasMore", False)
                    offset = summary.get("offset", 0)
                    limit = summary.get("limit", 50)

                    # Build response with contextual hints
                    response_parts = [message_text]

                    # Add contextual hints based on current mode
                    if not detailed and not include_content:
                        response_parts.append(
                            "\n\n💡 Tip: You're viewing summary mode (minimal info). "
                            "To get more details, use:\n"
                            "  • detailed=true - Get full rule details (instructions, rationale, tags)\n"
                            "  • includeContent=true - Get complete rule content (markdown/JSON)\n"
                            "  • includePatterns=true - Get regex patterns (requires detailed=true)"
                        )
                    elif detailed and not include_content:
                        response_parts.append(
                            "\n\n💡 Tip: Use includeContent=true to get the full rule content (markdown/JSON)"
                        )

                    # Add pagination hint if there are more results
                    if has_more:
                        next_offset = offset + limit
                        response_parts.append(
                            f"\n\n📄 More results available. Use offset={next_offset} to get the next page."
                        )

                    # Build final response
                    response_text = "".join(response_parts)

                    logger.debug("Successfully retrieved rules")
                    return [
                        TextContent(type="text", text=response_text),
                        TextContent(
                            type="text", text=json.dumps(rules_data, indent=2)
                        ),
                    ]

                elif name == "get_custom_rules":
                    # Handle get_custom_rules tool (similar to get_rules)
                    detailed = arguments.get("detailed", False)
                    include_content = arguments.get("includeContent", False)
                    include_patterns = arguments.get("includePatterns", False)

                    # Build params dict with all parameters
                    params = {
                        "language": arguments.get("language"),
                        "framework": arguments.get("framework"),
                        "category": arguments.get("category"),
                        "severity": arguments.get("severity"),
                        "appliesTo": arguments.get("appliesTo"),
                        "search": arguments.get("search"),
                        "ruleIds": arguments.get("ruleIds"),
                        "limit": arguments.get("limit", 50),
                        "offset": arguments.get("offset", 0),
                        "detailed": detailed,
                        "includePatterns": include_patterns,
                        "includeContent": include_content,
                    }

                    # Remove None values
                    params = {k: v for k, v in params.items() if v is not None}

                    # Call the API with all parameters
                    result = await self.api.call_tool("get_custom_rules", params)

                    # Parse the response - Lambda returns content array
                    content = result.get("content", [])

                    # Extract message and rules data from content array
                    message_text = ""
                    rules_data = None

                    for item in content:
                        if item.get("type") == "text":
                            text = item.get("text", "")
                            # Try to parse as JSON (second content item)
                            try:
                                parsed = json.loads(text)
                                if "rules" in parsed and "summary" in parsed:
                                    rules_data = parsed
                            except json.JSONDecodeError:
                                # First content item - the message from Lambda
                                message_text = text

                    # If no rules data found, return just the message
                    if not rules_data:
                        return [
                            TextContent(
                                type="text",
                                text=message_text or "No custom rules found",
                            )
                        ]

                    # Extract summary for hints
                    summary = rules_data.get("summary", {})
                    has_more = summary.get("hasMore", False)
                    offset = summary.get("offset", 0)
                    limit = summary.get("limit", 50)

                    # Build response with contextual hints
                    response_parts = [message_text]

                    # Add contextual hints based on current mode
                    if not detailed and not include_content:
                        response_parts.append(
                            "\n\n💡 Tip: You're viewing summary mode (minimal info). "
                            "To get more details, use:\n"
                            "  • detailed=true - Get full rule details (instructions, rationale, tags)\n"
                            "  • includeContent=true - Get complete rule content (markdown/JSON)\n"
                            "  • includePatterns=true - Get regex patterns (requires detailed=true)"
                        )
                    elif detailed and not include_content:
                        response_parts.append(
                            "\n\n💡 Tip: Use includeContent=true to get the full rule content (markdown/JSON)"
                        )

                    # Add pagination hint if there are more results
                    if has_more:
                        next_offset = offset + limit
                        response_parts.append(
                            f"\n\n📄 More results available. Use offset={next_offset} to get the next page."
                        )

                    # Build final response
                    response_text = "".join(response_parts)

                    logger.debug("Successfully retrieved custom rules")
                    return [
                        TextContent(type="text", text=response_text),
                        TextContent(
                            type="text", text=json.dumps(rules_data, indent=2)
                        ),
                    ]

                elif name == "get_team_rules":
                    # Handle get_team_rules tool (similar to get_rules)
                    detailed = arguments.get("detailed", False)
                    include_content = arguments.get("includeContent", False)
                    include_patterns = arguments.get("includePatterns", False)

                    # Build params dict with all parameters
                    params = {
                        "language": arguments.get("language"),
                        "framework": arguments.get("framework"),
                        "category": arguments.get("category"),
                        "severity": arguments.get("severity"),
                        "appliesTo": arguments.get("appliesTo"),
                        "search": arguments.get("search"),
                        "ruleIds": arguments.get("ruleIds"),
                        "limit": arguments.get("limit", 50),
                        "offset": arguments.get("offset", 0),
                        "detailed": detailed,
                        "includePatterns": include_patterns,
                        "includeContent": include_content,
                    }

                    # Remove None values
                    params = {k: v for k, v in params.items() if v is not None}

                    # Call the API with all parameters
                    result = await self.api.call_tool("get_team_rules", params)

                    # Parse the response - Lambda returns content array
                    content = result.get("content", [])

                    # Extract message and rules data from content array
                    message_text = ""
                    rules_data = None

                    for item in content:
                        if item.get("type") == "text":
                            text = item.get("text", "")
                            # Try to parse as JSON (second content item)
                            try:
                                parsed = json.loads(text)
                                if "rules" in parsed and "summary" in parsed:
                                    rules_data = parsed
                            except json.JSONDecodeError:
                                # First content item - the message from Lambda
                                message_text = text

                    # If no rules data found, return just the message
                    if not rules_data:
                        return [
                            TextContent(
                                type="text",
                                text=message_text or "No team rules found",
                            )
                        ]

                    # Extract summary for hints
                    summary = rules_data.get("summary", {})
                    has_more = summary.get("hasMore", False)
                    offset = summary.get("offset", 0)
                    limit = summary.get("limit", 50)

                    # Build response with contextual hints
                    response_parts = [message_text]

                    # Add contextual hints based on current mode
                    if not detailed and not include_content:
                        response_parts.append(
                            "\n\n💡 Tip: You're viewing summary mode (minimal info). "
                            "To get more details, use:\n"
                            "  • detailed=true - Get full rule details (instructions, rationale, tags)\n"
                            "  • includeContent=true - Get complete rule content (markdown/JSON)\n"
                            "  • includePatterns=true - Get regex patterns (requires detailed=true)"
                        )
                    elif detailed and not include_content:
                        response_parts.append(
                            "\n\n💡 Tip: Use includeContent=true to get the full rule content (markdown/JSON)"
                        )

                    # Add pagination hint if there are more results
                    if has_more:
                        next_offset = offset + limit
                        response_parts.append(
                            f"\n\n📄 More results available. Use offset={next_offset} to get the next page."
                        )

                    # Build final response
                    response_text = "".join(response_parts)

                    logger.debug("Successfully retrieved team rules")
                    return [
                        TextContent(type="text", text=response_text),
                        TextContent(
                            type="text", text=json.dumps(rules_data, indent=2)
                        ),
                    ]

                elif name == "analyze_code":
                    # Handle analyze_code tool
                    code = arguments.get("code")
                    if not code:
                        error_msg = "Missing required parameter: code"
                        logger.warning(error_msg)
                        return [
                            TextContent(
                                type="text",
                                text=json.dumps({"error": error_msg}, indent=2),
                            )
                        ]

                    language = arguments.get("language")
                    package_ids = arguments.get("packageIds") or arguments.get(
                        "package_ids"
                    )

                    result = await self.api.analyze_code(code, language, package_ids)

                    response = {
                        "tool": "analyze_code",
                        "language": language,
                        "packageIds": package_ids,
                        "analysis": result,
                    }

                    logger.debug("Successfully analyzed code")
                    return [
                        TextContent(type="text", text=json.dumps(response, indent=2))
                    ]

                elif name == "list_external_mcp_servers":
                    # Handle list_external_mcp_servers tool - forward to Lambda
                    logger.info("Listing external MCP servers from Lambda registry")

                    try:
                        result = await self.api.call_tool("list_external_mcp_servers", {})

                        # Return the Lambda response directly
                        if isinstance(result, dict) and "content" in result:
                            content = result["content"]
                            return [
                                TextContent(
                                    type=item.get("type", "text"),
                                    text=item.get("text", ""),
                                )
                                for item in content
                            ]
                        else:
                            return [
                                TextContent(
                                    type="text", text=json.dumps(result, indent=2)
                                )
                            ]

                    except Exception as e:
                        error_msg = f"Failed to list external MCP servers: {str(e)}"
                        logger.error(error_msg)
                        return [
                            TextContent(
                                type="text",
                                text=json.dumps({"error": error_msg}, indent=2),
                            )
                        ]

                elif name == "get_external_mcp_server":
                    # Handle get_external_mcp_server tool - forward to Lambda
                    server_id = arguments.get("serverId")

                    if not server_id:
                        error_msg = "Missing required parameter: serverId"
                        logger.warning(error_msg)
                        return [
                            TextContent(
                                type="text",
                                text=json.dumps({"error": error_msg}, indent=2),
                            )
                        ]

                    logger.info(f"Getting external MCP server details: {server_id}")

                    try:
                        result = await self.api.call_tool(
                            "get_external_mcp_server", {"serverId": server_id}
                        )

                        # Return the Lambda response directly
                        if isinstance(result, dict) and "content" in result:
                            content = result["content"]
                            return [
                                TextContent(
                                    type=item.get("type", "text"),
                                    text=item.get("text", ""),
                                )
                                for item in content
                            ]
                        else:
                            return [
                                TextContent(
                                    type="text", text=json.dumps(result, indent=2)
                                )
                            ]

                    except Exception as e:
                        error_msg = f"Failed to get external MCP server: {str(e)}"
                        logger.error(error_msg)
                        return [
                            TextContent(
                                type="text",
                                text=json.dumps({"error": error_msg}, indent=2),
                            )
                        ]

                elif name == "connect_external_server":
                    # Handle connect_external_server tool
                    # Support two modes:
                    # 1. serverId (fetch config from Lambda)
                    # 2. Manual (name, command, args)

                    server_id = arguments.get("serverId")
                    server_name = arguments.get("name")
                    command = arguments.get("command")
                    args_list = arguments.get("args", [])
                    env_vars = arguments.get("env", {})

                    # Mode 1: serverId provided - fetch from Lambda
                    if server_id:
                        logger.info(
                            f"Connecting to external server via serverId: {server_id}"
                        )

                        try:
                            # Get server details from Lambda
                            server_details = await self.api.call_tool(
                                "get_external_mcp_server", {"serverId": server_id}
                            )

                            # Parse the server details from the text response
                            server_text = server_details["content"][0]["text"]

                            # Extract command and args from the response
                            import re

                            command_match = re.search(
                                r"\*\*Command:\*\* `([^`]+)`", server_text
                            )
                            args_match = re.search(
                                r"\*\*Arguments:\*\* (\[.*?\])", server_text
                            )

                            if not command_match or not args_match:
                                raise Exception("Could not parse server configuration")

                            command = command_match.group(1)
                            args_list = json.loads(args_match.group(1))

                            # Use serverId as the name if not provided
                            server_name = server_name or server_id

                            logger.info(
                                f"Fetched server config: {command} {' '.join(args_list)}"
                            )

                        except Exception as e:
                            error_msg = f"Failed to fetch server config for {server_id}: {str(e)}"
                            logger.error(error_msg)
                            return [
                                TextContent(
                                    type="text",
                                    text=json.dumps({"error": error_msg}, indent=2),
                                )
                            ]

                    # Mode 2: Manual connection
                    else:
                        if not server_name or not command or not args_list:
                            error_msg = "Missing required parameters: either serverId OR (name, command, args)"
                            logger.warning(error_msg)
                            return [
                                TextContent(
                                    type="text",
                                    text=json.dumps({"error": error_msg}, indent=2),
                                )
                            ]

                        logger.info(f"Connecting to external server manually: {server_name}")

                    # Connect to the external server
                    try:
                        result = await self.connection_manager.connect(
                            {
                                "name": server_name,
                                "command": command,
                                "args": args_list,
                                "env": env_vars,
                            }
                        )

                        response_text = (
                            f"✅ **Successfully Connected to {result['serverName']}**\n\n"
                            f"**Server Info:**\n"
                            f"- Name: {result['serverInfo']['name']}\n"
                            f"- Version: {result['serverInfo']['version']}\n\n"
                            f"**Available Tools ({len(result['tools'])}):**\n"
                        )

                        for tool in result["tools"]:
                            response_text += f"- `{tool['name']}`: {tool.get('description', 'No description')}\n"

                        response_text += (
                            f"\n**Usage:** Tools are now available with prefix `{result['serverName']}__`\n"
                            f"Example: `{result['serverName']}__{result['tools'][0]['name'] if result['tools'] else 'tool_name'}`\n\n"
                            f"**Note:** This connection will be automatically restored on restart."
                        )

                        logger.info(
                            f"Successfully connected to {server_name} with {len(result['tools'])} tools"
                        )

                        return [TextContent(type="text", text=response_text)]

                    except Exception as e:
                        error_msg = f"Failed to connect to {server_name}: {str(e)}"
                        logger.error(error_msg)
                        
                        # Enhanced error response with environment variable hints
                        error_response = {
                            "error": error_msg,
                            "server": server_name,
                        }
                        
                        # If we have a serverId, try to fetch required env vars from registry
                        if server_id:
                            try:
                                # Get server details from Lambda to extract required env vars
                                server_details = await self.api.call_tool(
                                    "get_external_mcp_server", {"serverId": server_id}
                                )
                                
                                # Parse the server details to extract env var names
                                server_text = server_details["content"][0]["text"]
                                
                                # Extract environment variables section
                                env_section_match = re.search(
                                    r"\*\*Environment Variables:\*\*(.*?)(?:\n\n|\Z)",
                                    server_text,
                                    re.DOTALL
                                )
                                
                                if env_section_match:
                                    env_section = env_section_match.group(1)
                                    # Extract variable names (format: - `VAR_NAME`: description)
                                    env_vars_found = re.findall(r"`([A-Z_]+)`", env_section)
                                    
                                    if env_vars_found:
                                        error_response["likely_cause"] = "Missing required environment variables"
                                        error_response["required_env_vars"] = env_vars_found
                                        error_response["help"] = f"Run get_external_mcp_server('{server_id}') for complete configuration details and examples."
                                
                            except Exception as fetch_error:
                                logger.debug(f"Could not fetch env var details: {fetch_error}")
                        
                        # Check for common timeout/connection errors
                        error_str = str(e).lower()
                        if "timeout" in error_str or "timed out" in error_str:
                            error_response["likely_cause"] = error_response.get(
                                "likely_cause", 
                                "Connection timeout - server may be unreachable or missing required configuration"
                            )
                        elif "connection" in error_str or "connect" in error_str:
                            error_response["likely_cause"] = error_response.get(
                                "likely_cause",
                                "Connection failed - check that the server command is installed and configured correctly"
                            )
                        
                        return [
                            TextContent(
                                type="text",
                                text=json.dumps(error_response, indent=2),
                            )
                        ]

                elif name == "list_external_connections":
                    # Handle list_external_connections tool
                    connections = self.connection_manager.list_connections()

                    response_text = "# Connected External MCP Servers\n\n"

                    if not connections:
                        response_text += "No external servers connected.\n\n"
                        response_text += "**To connect:** Use `connect_external_server` tool\n"
                    else:
                        response_text += f"**Total Connections:** {len(connections)}\n\n"
                        for conn in connections:
                            response_text += f"## {conn['name']}\n"
                            response_text += f"- **Status:** {'✅ Connected' if conn['isConnected'] else '❌ Disconnected'}\n"
                            response_text += f"- **Server:** {conn['serverInfo']['name']} v{conn['serverInfo']['version']}\n"
                            response_text += f"- **Tools:** {len(conn['tools'])} available\n"
                            response_text += f"  - {', '.join(conn['tools'])}\n\n"

                    logger.debug(f"Listed {len(connections)} external connections")
                    return [TextContent(type="text", text=response_text)]

                elif name == "disconnect_external_server":
                    # Handle disconnect_external_server tool
                    server_name = arguments.get("serverName")

                    if not server_name:
                        error_msg = "Missing required parameter: serverName"
                        logger.warning(error_msg)
                        return [
                            TextContent(
                                type="text",
                                text=json.dumps({"error": error_msg}, indent=2),
                            )
                        ]

                    logger.info(f"Disconnecting from external server: {server_name}")

                    result = await self.connection_manager.disconnect(server_name)

                    if result["success"]:
                        response_text = f"✅ Disconnected from {server_name}"
                        logger.info(f"Successfully disconnected from {server_name}")
                    else:
                        response_text = f"❌ {result.get('error', 'Unknown error')}"
                        logger.warning(f"Failed to disconnect from {server_name}")

                    return [TextContent(type="text", text=response_text)]

                elif name == "call_external_tool":
                    # Handle call_external_tool tool
                    server_name = arguments.get("serverName")
                    tool_name = arguments.get("toolName")
                    tool_args = arguments.get("arguments", {})

                    if not server_name or not tool_name:
                        error_msg = "Missing required parameters: serverName, toolName"
                        logger.warning(error_msg)
                        return [
                            TextContent(
                                type="text",
                                text=json.dumps({"error": error_msg}, indent=2),
                            )
                        ]

                    logger.info(
                        f"Calling external tool: {server_name}.{tool_name}"
                    )

                    try:
                        result = await self.connection_manager.call_tool(
                            server_name, tool_name, tool_args
                        )

                        logger.debug(
                            f"External tool call completed: {server_name}.{tool_name}"
                        )

                        # Return the result from the external server
                        # The result should already be in MCP format
                        if isinstance(result, dict) and "content" in result:
                            # Extract content array
                            content = result["content"]
                            return [
                                TextContent(
                                    type=item.get("type", "text"),
                                    text=item.get("text", ""),
                                )
                                for item in content
                            ]
                        else:
                            # Fallback: wrap in JSON
                            return [
                                TextContent(
                                    type="text", text=json.dumps(result, indent=2)
                                )
                            ]

                    except Exception as e:
                        error_msg = f"Failed to call {server_name}.{tool_name}: {str(e)}"
                        logger.error(error_msg)
                        return [
                            TextContent(
                                type="text",
                                text=json.dumps({"error": error_msg}, indent=2),
                            )
                        ]

                # Check if this is a call to an external server tool (with prefix)
                elif "__" in name:
                    server_name, tool_name = name.split("__", 1)

                    logger.info(
                        f"Routing to external server: {server_name}.{tool_name}"
                    )

                    try:
                        result = await self.connection_manager.call_tool(
                            server_name, tool_name, arguments
                        )

                        logger.debug(
                            f"External tool call completed: {server_name}.{tool_name}"
                        )

                        # Return the result from the external server
                        if isinstance(result, dict) and "content" in result:
                            content = result["content"]
                            return [
                                TextContent(
                                    type=item.get("type", "text"),
                                    text=item.get("text", ""),
                                )
                                for item in content
                            ]
                        else:
                            return [
                                TextContent(
                                    type="text", text=json.dumps(result, indent=2)
                                )
                            ]

                    except Exception as e:
                        error_msg = f"Failed to call {server_name}.{tool_name}: {str(e)}"
                        logger.error(error_msg)
                        return [
                            TextContent(
                                type="text",
                                text=json.dumps({"error": error_msg}, indent=2),
                            )
                        ]

                else:
                    # Unsupported tool
                    error_msg = f"Tool '{name}' is not supported. Available tools: get_rules, get_custom_rules, get_team_rules, analyze_code, connect_external_server, list_external_connections, disconnect_external_server, call_external_tool"
                    logger.warning(f"Unsupported tool requested: {name}")
                    return [
                        TextContent(
                            type="text", text=json.dumps({"error": error_msg}, indent=2)
                        )
                    ]

            except AgenticWerxAPIError as e:
                error_msg = f"AgenticWerx API Error: {str(e)}"
                logger.error(f"API error in tool {name}: {e}")
                return [
                    TextContent(
                        type="text", text=json.dumps({"error": error_msg}, indent=2)
                    )
                ]

            except Exception as e:
                error_msg = f"Tool execution error: {str(e)}"
                logger.error(f"Unexpected error in tool {name}: {e}")
                return [
                    TextContent(
                        type="text", text=json.dumps({"error": error_msg}, indent=2)
                    )
                ]

    async def test_connection(self) -> bool:
        """Test connection to the Lambda MCP server."""
        return await self.api.test_connection()

    async def run(self) -> None:
        """Run the MCP server."""
        logger.info("Starting AgenticWerx MCP Client")

        # Initialize connection manager and restore saved connections
        try:
            await self.connection_manager.initialize()
            logger.info(
                f"Connection manager initialized (persistence: {self.connection_manager.get_persistence_path()})"
            )
        except Exception as e:
            logger.error(f"Failed to initialize connection manager: {e}")

        # Test connection to Lambda MCP server on startup
        logger.info("Testing connection to Lambda MCP server...")
        connection_ok = await self.test_connection()
        if not connection_ok:
            logger.error("Failed to connect to Lambda MCP server")
            # Continue anyway - the client might still work for some operations
        else:
            logger.info("Successfully connected to Lambda MCP server")

        try:
            from mcp.server.stdio import stdio_server

            async with stdio_server() as (read_stream, write_stream):
                logger.info("MCP Client started, waiting for connections...")

                from mcp.types import (
                    ResourcesCapability,
                    ServerCapabilities,
                    ToolsCapability,
                )

                init_options = InitializationOptions(
                    server_name="agenticwerx",
                    server_version="1.0.0",
                    capabilities=ServerCapabilities(
                        resources=ResourcesCapability(
                            subscribe=False, listChanged=False
                        ),
                        tools=ToolsCapability(listChanged=False),
                    ),
                )

                await self.server.run(read_stream, write_stream, init_options)

        except Exception as e:
            logger.error(f"Error running MCP server: {e}")
            raise
        finally:
            # Disconnect all external servers
            await self.connection_manager.disconnect_all()
            await self.api.close()
            logger.info("AgenticWerx MCP Client stopped")

    async def __aenter__(self):
        """Async context manager entry."""
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Async context manager exit."""
        await self.api.close()
