"""
AgenticWerx MCP Client

A Model Context Protocol (MCP) client for AgenticWerx rule packages.
Provides universal code analysis across all IDEs and programming languages.
"""

__version__ = "1.2.2"
__author__ = "AgenticWerx"
__email__ = "support@agenticwerx.com"

from .api import AgenticWerxAPI
from .client import AgenticWerxMCPClient
from .mcp_connection_manager import MCPConnectionManager, MCPServerConnection

__all__ = [
    "AgenticWerxMCPClient",
    "AgenticWerxAPI",
    "MCPConnectionManager",
    "MCPServerConnection",
]
