from pydantic_settings import BaseSettings


class ScoldAppSettings(BaseSettings):
    pass
