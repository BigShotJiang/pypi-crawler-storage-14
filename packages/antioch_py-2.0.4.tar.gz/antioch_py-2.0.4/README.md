# Antioch Python

Python client library for the Antioch middleware platform.

## Installation

Authenticate your local environment with GCP via the Google Cloud CLI:

```bash
gcloud auth login                                       # Login to Google Cloud
gcloud config set project proof-of-concept-staging-9072 # Set the correct project
gcloud auth application-default login                   # Create app credentials
```

This project uses [uv](https://github.com/astral-sh/uv), a fast Python package and project manager. Install it and set up authentication:

```bash
# Install uv
curl -LsSf https://astral.sh/uv/install.sh | sh

# Install keyring authentication globally for uv
uv tool install keyring --with keyrings.google-artifactregistry-auth

# Install all default groups in one step
uv sync
```

Install the pre-commit hooks to auto-run `uv sync` and `ruff format` on Git commit:

```bash
uv run pre-commit install
```
