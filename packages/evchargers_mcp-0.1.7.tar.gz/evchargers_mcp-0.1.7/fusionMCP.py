import asyncio
from fastmcp import FastMCP, Context
import aiohttp
import os
import json
from dotenv import load_dotenv
import ssl
import re
import logging
import tempfile
from pathlib import Path
from scriptsWebScrapping.extract_warnings import extract_warnings
from scriptsWebScrapping.extract_sessions import extract_sessions
from scriptsWebScrapping.extract_syslog import extract_syslog

mcp = FastMCP("EV Charger MCP Server")

# Cargar el archivo .env
load_dotenv()

# Configurar logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

def get_ssl_context():
    """
    Crea y configura el contexto SSL basado en las variables de entorno.
    
    Variables de entorno:
    - VERIFY_SSL: "true" o "false" para habilitar/deshabilitar verificación SSL
    - SSL_CERT_PATH: Ruta al archivo de certificado de confianza (opcional)
    
    Returns:
        ssl.SSLContext configurado según las variables de entorno
    """
    verify_ssl = os.getenv("VERIFY_SSL", "false").lower() == "true"
    ssl_cert_path = os.getenv("SSL_CERT_PATH")
    
    ssl_context = ssl.create_default_context()
    
    if not verify_ssl:
        # Deshabilitar verificación SSL
        ssl_context.check_hostname = False
        ssl_context.verify_mode = ssl.CERT_NONE
        logger.info("SSL verification deshabilitado")
    else:
        # Habilitar verificación SSL
        ssl_context.check_hostname = True
        ssl_context.verify_mode = ssl.CERT_REQUIRED
        
        if ssl_cert_path:
            if not Path(ssl_cert_path).exists():
                logger.error(f"Archivo de certificado no encontrado: {ssl_cert_path}")
                raise FileNotFoundError(f"Certificado SSL no encontrado: {ssl_cert_path}")
            
            ssl_context.load_verify_locations(ssl_cert_path)
            logger.info(f"Certificado SSL cargado desde: {ssl_cert_path}")
        else:
            logger.info("Usando certificados del sistema para verificación SSL")
    
    return ssl_context

class ChargerSession:
    """Maneja la sesión autenticada con el cargador"""
    def __init__(self, host: str, username: str, password: str):
        self.host = host
        self.username = username
        self.password = password
        self.cookies = None
        self.stok = None
        self.device_id = os.getenv("DEVICE_ID")
        self.ssl_context = get_ssl_context()
    
    async def authenticate(self):
        """Autentica y obtiene las cookies de sesión"""
        url = f"https://{self.host}/cgi-bin/webmanager/operator"
        payload = {
            "luci_username": self.username,
            "luci_password": self.password
        }
        
        try:
            async with aiohttp.ClientSession() as session:
                async with session.post(url, data=payload, ssl=self.ssl_context, allow_redirects=False, timeout=aiohttp.ClientTimeout(total=30)) as response:
                    self.cookies = response.cookies
                    
                    # Extraer stok del header Location
                    location = response.headers.get("Location", "")
                    if location:
                        # Buscar patrón stok=xxxxx en la URL
                        match = re.search(r"stok=([a-f0-9]+)", location)
                        if match:
                            self.stok = match.group(1)
                            logger.info(f"Token STOK obtenido: {self.stok}")
                            return response.status in [200, 302]
                    
                    logger.warning(f"No se encontró STOK en la respuesta")
                    return False
        except Exception as e:
            logger.error(f"Error durante autenticación: {str(e)}")
            return False

@mcp.tool
async def obtener_warnings(ctx: Context, days: int = None, start_date: str = None, end_date: str = None):
    """
    Obtiene y procesa los warnings del cargador EV.
    
    Descarga el HTML, lo convierte a CSV y devuelve los datos procesados.
    
    Args:
        days: Últimos N días a incluir (ej: 7, 30) (opcional)
        start_date: Fecha de inicio (formato: YYYY-MM-DD) (opcional)
        end_date: Fecha de fin (formato: YYYY-MM-DD) (opcional)
    
    Returns:
        dict con status, count, filtered_count y lista de warnings
    """
    try:
        host = os.getenv("CHARGER_HOST")
        username = os.getenv("CHARGER_USERNAME")
        password = os.getenv("CHARGER_PASSWORD")
        
        logger.info("Iniciando obtener_warnings")
        
        if not host or not username or not password:
            error_msg = "Las variables CHARGER_HOST, CHARGER_USERNAME o CHARGER_PASSWORD no están definidas."
            logger.error(error_msg)
            await ctx.error(error_msg)
            return
        
        session = ChargerSession(host, username, password)
        authenticated = await session.authenticate()
        
        if not authenticated or not session.stok:
            error_msg = "Falló la autenticación con el cargador o no se obtuvo stok"
            logger.error(error_msg)
            await ctx.error(error_msg)
            return
        
        device_id = os.getenv("DEVICE_ID", "6W0A19240050")
        url = f"https://{host}/cgi-bin/webmanager/;stok={session.stok}/{username}/charging/{device_id}/warnings"
        
        logger.info(f"Descargando warnings desde {url}")
        
        # Descargar HTML
        async with aiohttp.ClientSession(cookies=session.cookies) as client:
            async with client.get(url, ssl=session.ssl_context, timeout=aiohttp.ClientTimeout(total=30)) as response:
                if response.status != 200:
                    error_msg = f"Error al descargar warnings: status {response.status}"
                    logger.error(error_msg)
                    await ctx.error(error_msg)
                    return
                
                html_content = await response.text()
                logger.info(f"HTML descargado exitosamente ({len(html_content)} bytes)")
        
        # Guardar HTML en archivo temporal
        with tempfile.NamedTemporaryFile(mode='w', suffix='.html', delete=False, encoding='utf-8') as tmp:
            tmp.write(html_content)
            temp_html_path = tmp.name
        
        try:
            # Procesar HTML con extract_warnings
            logger.info("Procesando HTML con extract_warnings")
            result = extract_warnings(
                input_file=temp_html_path,
                days=days,
                start_date=start_date,
                end_date=end_date,
                return_data=True
            )
            
            logger.info(f"Warnings procesados: {result['count']} registros extraídos")
            
            return {
                "status": 200,
                "count": result["count"],
                "filtered_count": result["filtered_count"],
                "data": result["data"]
            }
        
        finally:
            # Limpiar archivo temporal
            Path(temp_html_path).unlink(missing_ok=True)
    
    except Exception as e:
        logger.error(f"Error en obtener_warnings: {str(e)}")
        await ctx.error(f"Error: {str(e)}")

@mcp.tool
async def obtener_sessions(ctx: Context, days: int = None, start_date: str = None, end_date: str = None):
    """
    Obtiene y procesa las sesiones del cargador EV.
    
    Descarga el HTML, lo convierte a CSV y devuelve los datos procesados.
    
    Args:
        days: Últimos N días a incluir (ej: 7, 30) (opcional)
        start_date: Fecha de inicio (formato: YYYY-MM-DD) (opcional)
        end_date: Fecha de fin (formato: YYYY-MM-DD) (opcional)
    
    Returns:
        dict con status, count, filtered_count y lista de sesiones
    """
    try:
        host = os.getenv("CHARGER_HOST")
        username = os.getenv("CHARGER_USERNAME")
        password = os.getenv("CHARGER_PASSWORD")
        
        logger.info("Iniciando obtener_sessions")
        
        if not host or not username or not password:
            error_msg = "Las variables CHARGER_HOST, CHARGER_USERNAME o CHARGER_PASSWORD no están definidas."
            logger.error(error_msg)
            await ctx.error(error_msg)
            return
        
        session = ChargerSession(host, username, password)
        authenticated = await session.authenticate()
        
        if not authenticated or not session.stok:
            error_msg = "Falló la autenticación con el cargador o no se obtuvo stok"
            logger.error(error_msg)
            await ctx.error(error_msg)
            return
        
        device_id = os.getenv("DEVICE_ID", "6W0A19240050")
        url = f"https://{host}/cgi-bin/webmanager/;stok={session.stok}/{username}/charging/{device_id}/sessions"
        
        logger.info(f"Descargando sessions desde {url}")
        
        # Descargar HTML
        async with aiohttp.ClientSession(cookies=session.cookies) as client:
            async with client.get(url, ssl=session.ssl_context, timeout=aiohttp.ClientTimeout(total=30)) as response:
                if response.status != 200:
                    error_msg = f"Error al descargar sessions: status {response.status}"
                    logger.error(error_msg)
                    await ctx.error(error_msg)
                    return
                
                html_content = await response.text()
                logger.info(f"HTML descargado exitosamente ({len(html_content)} bytes)")
        
        # Guardar HTML en archivo temporal
        with tempfile.NamedTemporaryFile(mode='w', suffix='.html', delete=False, encoding='utf-8') as tmp:
            tmp.write(html_content)
            temp_html_path = tmp.name
        
        try:
            # Procesar HTML con extract_sessions
            logger.info("Procesando HTML con extract_sessions")
            result = extract_sessions(
                input_file=temp_html_path,
                days=days,
                start_date=start_date,
                end_date=end_date,
                return_data=True
            )
            
            logger.info(f"Sessions procesadas: {result['count']} registros extraídos")
            
            return {
                "status": 200,
                "count": result["count"],
                "filtered_count": result["filtered_count"],
                "data": result["data"]
            }
        
        finally:
            # Limpiar archivo temporal
            Path(temp_html_path).unlink(missing_ok=True)
    
    except Exception as e:
        logger.error(f"Error en obtener_sessions: {str(e)}")
        await ctx.error(f"Error: {str(e)}")

@mcp.tool
async def obtener_logs(ctx: Context, days: int = None, start_date: str = None, end_date: str = None):
    """
    Obtiene y procesa los logs del sistema (syslog) del cargador EV.
    
    Descarga el HTML, lo extrae del textarea y devuelve los datos procesados.
    
    Args:
        days: Últimos N días a incluir (ej: 7, 30) (opcional)
        start_date: Fecha de inicio (formato: YYYY-MM-DD) (opcional)
        end_date: Fecha de fin (formato: YYYY-MM-DD) (opcional)
    
    Returns:
        dict con status, count, filtered_count y lista de logs
    """
    try:
        host = os.getenv("CHARGER_HOST")
        username = os.getenv("CHARGER_USERNAME")
        password = os.getenv("CHARGER_PASSWORD")
        
        logger.info("Iniciando obtener_logs")
        
        if not host or not username or not password:
            error_msg = "Las variables CHARGER_HOST, CHARGER_USERNAME o CHARGER_PASSWORD no están definidas."
            logger.error(error_msg)
            await ctx.error(error_msg)
            return
        
        session = ChargerSession(host, username, password)
        authenticated = await session.authenticate()
        
        if not authenticated or not session.stok:
            error_msg = "Falló la autenticación con el cargador o no se obtuvo stok"
            logger.error(error_msg)
            await ctx.error(error_msg)
            return
        
        device_id = os.getenv("DEVICE_ID", "6W0A19240050")
        url = f"https://{host}/cgi-bin/webmanager/;stok={session.stok}/{username}/system/syslog/{device_id}"
        
        logger.info(f"Descargando logs desde {url}")
        
        # Descargar HTML
        async with aiohttp.ClientSession(cookies=session.cookies) as client:
            async with client.get(url, ssl=session.ssl_context, timeout=aiohttp.ClientTimeout(total=30)) as response:
                if response.status != 200:
                    error_msg = f"Error al descargar logs: status {response.status}"
                    logger.error(error_msg)
                    await ctx.error(error_msg)
                    return
                
                html_content = await response.text()
                logger.info(f"HTML descargado exitosamente ({len(html_content)} bytes)")
        
        # Guardar HTML en archivo temporal
        with tempfile.NamedTemporaryFile(mode='w', suffix='.html', delete=False, encoding='utf-8') as tmp:
            tmp.write(html_content)
            temp_html_path = tmp.name
        
        try:
            # Procesar HTML con extract_syslog
            logger.info("Procesando HTML con extract_syslog")
            result = extract_syslog(
                input_file=temp_html_path,
                days=days,
                start_date=start_date,
                end_date=end_date,
                return_data=True
            )
            
            logger.info(f"Logs procesados: {result['count']} líneas extraídas")
            
            return {
                "status": 200,
                "count": result["count"],
                "filtered_count": result["filtered_count"],
                "data": result["data"]
            }
        
        finally:
            # Limpiar archivo temporal
            Path(temp_html_path).unlink(missing_ok=True)
    
    except Exception as e:
        logger.error(f"Error en obtener_logs: {str(e)}")
        await ctx.error(f"Error: {str(e)}")

def main():
    logger.info("Iniciando EV Charger MCP Server")
    try:
        mcp.run()
    except Exception as e:
        logger.error(f"Error fatal en MCP Server: {str(e)}")
        raise

if __name__ == "__main__":
    main()