"""
Command-Line Interface

CLI for OMOP cohort management via OHDSI WebAPI.

Author: Ankur Lohachab
Department of Advanced Computing Sciences, Maastricht University
"""

import argparse
import json
import sys
from typing import Optional
from smart_omop.client import OMOPClient
from smart_omop.cohort import CohortBuilder, Gender
from smart_omop.fetcher import (
    fetch_cohort_data,
    create_and_generate_cohort,
    poll_generation_status
)


def cmd_create_cohort(args):
    """Create cohort definition."""
    # Build cohort
    builder = CohortBuilder(args.name, args.description or "")

    if args.concept_ids:
        concept_ids = [int(cid) for cid in args.concept_ids.split(',')]
        builder.with_condition("Primary Condition", concept_ids)

    if args.age_gte is not None or args.age_lte is not None:
        builder.with_age_range(args.age_gte, args.age_lte)

    if args.gender:
        gender_map = {
            'male': Gender.MALE,
            'female': Gender.FEMALE
        }
        builder.with_gender(gender_map[args.gender.lower()])

    cohort_def = builder.build()

    # Create via WebAPI
    with OMOPClient(args.base_url) as client:
        created = client.create_cohort(cohort_def.to_dict())

        print(f"✓ Cohort created successfully")
        print(f"  ID: {created['id']}")
        print(f"  Name: {created['name']}")

        if args.output:
            with open(args.output, 'w') as f:
                json.dump(created, f, indent=2)
            print(f"  Saved to: {args.output}")

        return created['id']


def cmd_generate(args):
    """Generate cohort on data source."""
    with OMOPClient(args.base_url) as client:
        result = client.generate_cohort(args.cohort_id, args.source_key)

        print(f"✓ Cohort generation started")
        print(f"  Cohort ID: {args.cohort_id}")
        print(f"  Source: {args.source_key}")

        if args.output:
            with open(args.output, 'w') as f:
                json.dump(result, f, indent=2)


def cmd_heracles(args):
    """Run Heracles characterization."""
    with OMOPClient(args.base_url) as client:
        result = client.run_heracles(args.cohort_id, args.source_key)

        print(f"✓ Heracles characterization started")
        print(f"  Cohort ID: {args.cohort_id}")
        print(f"  Source: {args.source_key}")

        if args.poll:
            print("  Polling for completion...")
            status = poll_generation_status(
                args.base_url,
                args.cohort_id,
                args.source_key,
                max_wait=args.timeout or 300
            )
            print(f"  Status: {status.get('status', 'UNKNOWN')}")


def cmd_results(args):
    """Fetch cohort results."""
    data = fetch_cohort_data(
        args.base_url,
        args.cohort_id,
        args.source_key,
        include_results=True
    )

    print(f"✓ Cohort data retrieved")
    print(f"  Cohort: {data['definition'].get('name', 'Unknown')}")

    if data.get('results'):
        print(f"  Results available: Yes")

        # Output format
        if args.output_format == 'json':
            output_data = data
        elif args.output_format == 'md':
            # Convert to markdown
            output_data = format_results_markdown(data)
        else:
            output_data = data

        if args.output:
            if args.output_format == 'md':
                with open(args.output, 'w') as f:
                    f.write(output_data)
            else:
                with open(args.output, 'w') as f:
                    json.dump(output_data, f, indent=2)
            print(f"  Saved to: {args.output}")
        else:
            if args.output_format == 'json':
                print(json.dumps(output_data, indent=2))
            else:
                print(output_data)
    else:
        print(f"  Results available: No")
        if data.get('results_error'):
            print(f"  Error: {data['results_error']}")


def format_results_markdown(data: dict) -> str:
    """Format results as markdown."""
    lines = [
        f"# Cohort Results: {data['definition'].get('name', 'Unknown')}",
        "",
        f"**Cohort ID**: {data['cohort_id']}",
        f"**Source**: {data['source_key']}",
        ""
    ]

    if data.get('results'):
        results = data['results']
        lines.extend([
            "## Summary",
            "",
            f"- **Person Count**: {results.get('person_count', 'N/A')}",
            ""
        ])

    return "\n".join(lines)


def main():
    """Main CLI entry point."""
    parser = argparse.ArgumentParser(
        prog='smart-omop',
        description='OMOP CDM cohort management via OHDSI WebAPI'
    )

    parser.add_argument(
        '--base-url',
        required=True,
        help='WebAPI base URL (e.g., http://host:8080/WebAPI)'
    )

    subparsers = parser.add_subparsers(dest='command', help='Command to execute')

    # create-cohort
    create_parser = subparsers.add_parser('create-cohort', help='Create cohort definition')
    create_parser.add_argument('--name', required=True, help='Cohort name')
    create_parser.add_argument('--concept-ids', help='Comma-separated concept IDs')
    create_parser.add_argument('--description', help='Cohort description')
    create_parser.add_argument('--age-gte', type=int, help='Minimum age')
    create_parser.add_argument('--age-lte', type=int, help='Maximum age')
    create_parser.add_argument('--gender', choices=['male', 'female'], help='Gender filter')
    create_parser.add_argument('--output', help='Output file path')

    # generate
    gen_parser = subparsers.add_parser('generate', help='Generate cohort')
    gen_parser.add_argument('--cohort-id', type=int, required=True, help='Cohort ID')
    gen_parser.add_argument('--source-key', required=True, help='Source database key')
    gen_parser.add_argument('--output', help='Output file path')

    # heracles
    her_parser = subparsers.add_parser('heracles', help='Run Heracles characterization')
    her_parser.add_argument('--cohort-id', type=int, required=True, help='Cohort ID')
    her_parser.add_argument('--source-key', required=True, help='Source database key')
    her_parser.add_argument('--poll', action='store_true', help='Poll until complete')
    her_parser.add_argument('--timeout', type=int, help='Poll timeout in seconds')

    # results
    res_parser = subparsers.add_parser('results', help='Fetch cohort results')
    res_parser.add_argument('--cohort-id', type=int, required=True, help='Cohort ID')
    res_parser.add_argument('--source-key', required=True, help='Source database key')
    res_parser.add_argument('--output', help='Output file path')
    res_parser.add_argument('--output-format', choices=['json', 'md'], default='json', help='Output format')

    args = parser.parse_args()

    if not args.command:
        parser.print_help()
        sys.exit(1)

    # Execute command
    try:
        if args.command == 'create-cohort':
            cmd_create_cohort(args)
        elif args.command == 'generate':
            cmd_generate(args)
        elif args.command == 'heracles':
            cmd_heracles(args)
        elif args.command == 'results':
            cmd_results(args)
    except Exception as e:
        print(f"✗ Error: {e}", file=sys.stderr)
        sys.exit(1)


if __name__ == '__main__':
    main()
