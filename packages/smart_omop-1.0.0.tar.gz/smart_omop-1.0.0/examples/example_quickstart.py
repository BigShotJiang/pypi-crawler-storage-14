"""
Quick Start Example

Demonstrates basic OMOPClient operations:
- Listing data sources
- Fetching cohort definitions
- Generating cohorts
- Retrieving results

Author: Ankur Lohachab
Department of Advanced Computing Sciences, Maastricht University
"""

from smart_omop import OMOPClient

# Replace with your WebAPI URL
BASE_URL = "http://your-webapi:8080/WebAPI"

def main():
    with OMOPClient(BASE_URL) as client:
        # List data sources
        sources = client.get_sources()
        print(f"Available sources: {len(sources)}")
        for source in sources:
            print(f"  - {source['sourceKey']}: {source['sourceName']}")

        # Fetch cohort definition
        cohort = client.get_cohort(cohort_id=1)
        print(f"\nCohort: {cohort['name']}")

        # Generate cohort
        client.generate_cohort(cohort_id=1, source_key="MY_CDM")
        print(f"Cohort generation started")

        # Get results
        results = client.get_cohort_results(cohort_id=1, source_key="MY_CDM")
        print(f"Persons: {results['personCount']}, Status: {results['status']}")


if __name__ == "__main__":
    main()
