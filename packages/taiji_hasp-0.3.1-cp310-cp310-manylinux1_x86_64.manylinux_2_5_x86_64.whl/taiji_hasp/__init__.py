"""
Taiji HASP license protection wrapper
"""

__version__ = "0.3.1"

from .taiji_hasp import TaiJiHasp

