# SPDX-License-Identifier: LGPL-2.1-or-later

""" PCR prediction """

import hashlib

from cvmutils.pe import PEImage
from cvmutils.sb import SecureBoot
from cvmutils.guid import GUID_GLOBAL_VARIABLE, GUID_SECURITY_DATABASE, GUID_SHIM_LOCK

def extend_pcr(pcr, digest, verbose, log_prefix):
    """ Extend PCR value (TPM emulation) """
    if verbose:
        print(log_prefix, ''.join(f'{x:02x}' for x in digest))
    return hashlib.sha256(pcr + digest).digest()

def event_hash(guid, name, value):
    """ Event hash (TPM emulation) """
    d = guid.bytes_le
    d += len(name).to_bytes(8, 'little')
    d += len(value).to_bytes(8, 'little')
    d += name.encode('utf-16-le')
    d += value
    return hashlib.sha256(d).digest()

# pylint: disable=too-many-locals, too-many-branches, too-many-statements

class PCR:
    """ PCR4/PCR7 prediction for a given environment """

    def predict_pcr4(self, args, esp):
        """ Predict PCR4 """
        verbose = args.verbose

        # Calculate the expected PCR4 value
        pcr4 = bytearray.fromhex('0000000000000000000000000000000000000000000000000000000000000000')
        if verbose:
            print("PCR4 prediction started: 0000000000000000000000000000000000000000000000000000000000000000")
        # EV_EFI_ACTION
        pcr4 = extend_pcr(pcr4, hashlib.sha256(bytearray(b"Calling EFI Application from Boot Option")).digest(),
                          verbose, "PCR4: extending 'Calling EFI Application from Boot Option', hash")
        # EV_SEPARATOR
        pcr4 = extend_pcr(pcr4, hashlib.sha256(bytearray.fromhex("00000000")).digest(),
                          verbose, "PCR4: extending '00000000' SEPARATOR, hash")
        # shim
        pcr4 = extend_pcr(pcr4, esp.shim.get_authenticode_hash(), verbose, "PCR4: extending shim's hash")

        # Second stage bootloader if needed (e.g. sd-boot)
        if esp.bootloader is not None:
            pcr4 = extend_pcr(pcr4, esp.bootloader.get_authenticode_hash(), verbose, "PCR4: extending bootloader's hash")

        # UKI
        pcr4 = extend_pcr(pcr4, esp.uki.get_authenticode_hash(), verbose, "PCR4: extending UKI's hash")

        # UKI addons
        for addon in esp.uki_addons:
            pcr4 = extend_pcr(pcr4, addon.get_authenticode_hash(), verbose, f"PCR4: extending UKI's addon {addon.path.split('/')[-1]} hash")

        # With SecureBoot disabled, measure ".linux" section too
        if args.nosecureboot:
            linux = PEImage(data=esp.uki.get_section_data(".linux"))
            pcr4 = extend_pcr(pcr4, linux.get_authenticode_hash(), verbose, "PCR4: extending Linux's hash")

        return '0x' + ''.join(f'{x:02x}' for x in pcr4).upper()

    def predict_pcr7(self, args, esp):
        """ Predict PCR7 """

        verbose = args.verbose
        sb = SecureBoot()

        pcr7 = bytearray.fromhex('0000000000000000000000000000000000000000000000000000000000000000')
        if verbose:
            print("PCR7 prediction started: 0000000000000000000000000000000000000000000000000000000000000000")

        if args.efivars_profile:
            sb.load_uefi_from_efivars(args.efivars_profile, args.efivars_profile_no_attrs)
        elif args.uefi_profile:
            sb.load_uefi_from_uefi_profile(args.uefi_profile)
        elif args.az_disk_profile:
            sb.load_uefi_from_azdisk_profile(args.az_disk_profile)
        else:
            raise RuntimeError("Efivars, UEFI, or Azure disk profile is required for PCR7 prediction")

        sb.load_shim(esp.shim)

        # SecureBoot state
        if args.nosecureboot:
            expected_sb = '00'
        else:
            expected_sb = '01'

        pcr7 = extend_pcr(pcr7, event_hash(GUID_GLOBAL_VARIABLE, "SecureBoot", bytes.fromhex(expected_sb)),
                          verbose, f"PCR7: extending 'SecureBoot: {expected_sb}', hash")

        # PK, KEK, db, dbx
        pcr7 = extend_pcr(pcr7, event_hash(GUID_GLOBAL_VARIABLE, "PK", sb.uefi['PK']),
                          verbose, "PCR7: extending 'PK' variable, hash")
        pcr7 = extend_pcr(pcr7, event_hash(GUID_GLOBAL_VARIABLE, "KEK", sb.uefi['KEK']),
                          verbose, "PCR7: extending 'KEK' variable, hash")
        pcr7 = extend_pcr(pcr7, event_hash(GUID_SECURITY_DATABASE, "db", sb.uefi['db']),
                          verbose, "PCR7: extending 'db' variable, hash")
        pcr7 = extend_pcr(pcr7, event_hash(GUID_SECURITY_DATABASE, "dbx", sb.uefi['dbx']),
                          verbose, "PCR7: extending 'dbx' variable, hash")

        # EV_SEPARATOR
        pcr7 = extend_pcr(pcr7, hashlib.sha256(bytearray.fromhex("00000000")).digest(),
                          verbose, "PCR7: extending '00000000' SEPARATOR, hash")

        # In case several boot components are signed by the same certificate, it is only measured once
        certs_used = []

        if not args.nosecureboot:
            # Certificate which signed shim
            shim_cert_in_db = sb.find_shim_cert_in_sb_db()
            if shim_cert_in_db:
                pcr7 = extend_pcr(pcr7, event_hash(GUID_SECURITY_DATABASE, "db", shim_cert_in_db),
                                  verbose, "PCR7: shim's signator found in db, extending the matching cert, hash")
                certs_used.append(event_hash(GUID_SECURITY_DATABASE, "db", shim_cert_in_db))
            else:
                raise RuntimeError("SecureBoot certificate which signed Shim can't be found in db!")

        sbat_latest = sb.shim_get_sbat_latest()
        if sbat_latest and not args.nosecureboot:
            pcr7 = extend_pcr(pcr7, event_hash(GUID_SHIM_LOCK, "SbatLevel", sbat_latest),
                          verbose, "PCR7: extending '.sbatlevel' from shim's binary, hash")
        else:
            # Shim with SecureBoot disabled and older shim versions always
            # measure SBAT_VAR_ORIGINAL (sbat,1,2021030218), fingers crossed
            # it never changes.
            pcr7 = extend_pcr(pcr7, event_hash(GUID_SHIM_LOCK, "SbatLevel", bytearray(b'sbat,1,2021030218\n')),
                              verbose, "PCR7: extending '.sbatlevel' 'sbat,1,2021030218', hash")

        if sb.shim_measures_moklisttrusted_to_pcr7():
            # MokListTrusted
            pcr7 = extend_pcr(pcr7, event_hash(GUID_SHIM_LOCK, "MokListTrusted", bytes.fromhex('01')),
                              verbose, "PCR7: extending 'MokListTrusted: 01', hash")

        # Shim either boots UKI directly or through second state bootloader
        binaries = []
        if not args.nosecureboot:
            if esp.bootloader:
                binaries.append((esp.bootloader, "bootloader"))
            binaries.append((esp.uki, "UKI"))
            for addon in esp.uki_addons:
                binaries.append((addon, f"{addon.path.split('/')[1]} addon"))

        for binary, binary_name in binaries:
            found = False
            # Shim measures signators of all valid signatures into PCR7, mimic the behavior.
            for pkcs7 in binary.certchains:
                # Is the certificate which signed the binary in 'db'?
                bin_cert_in_db = sb.find_cert_in_sb_db(pkcs7)
                if bin_cert_in_db:
                    found = True
                    ehash = event_hash(GUID_SECURITY_DATABASE, "db", bin_cert_in_db)
                    if ehash not in certs_used:
                        pcr7 = extend_pcr(pcr7, ehash, verbose,
                                          f"PCR7: {binary_name}'s signator found in db, extending the matching cert, hash")
                        certs_used.append(ehash)
                    elif verbose:
                        print(f"PCR7: {binary_name}'s signator found in db but the hash is already used, skipping")
                    continue

                # Is the certificate which signed the binary is shim's 'vendor_db'?
                vendor_db_cert = sb.find_cert_in_shim_vendor_db(pkcs7)
                if vendor_db_cert:
                    found = True
                    ehash = event_hash(GUID_SECURITY_DATABASE, "vendor_db", vendor_db_cert)
                    if ehash not in certs_used:
                        pcr7 = extend_pcr(pcr7, ehash, verbose,
                                          f"PCR7: {binary_name}'s signator found in 'vendor_db', extending the matching cert, hash")
                        certs_used.append(ehash)
                    elif verbose:
                        print(f"PCR7: {binary_name}'s signator found in 'vendor_db' but the hash is already used, skipping")
                    continue

                # Is the certificate which signed the binary is shim's 'vendor_cert'?
                vendor_cert = sb.find_cert_in_shim_vendor_cert(pkcs7)
                if vendor_cert:
                    found = True
                    # shim 15.7+ extends MokListRT and uses it before checking .vendor_cert,
                    # which in practice means that MokListRT entry always gets logged.
                    # See: https://github.com/rhboot/shim/issues/714
                    ehash = event_hash(GUID_SHIM_LOCK, "MokListRT", GUID_SHIM_LOCK.bytes_le + vendor_cert)
                    if ehash not in certs_used:
                        pcr7 = extend_pcr(pcr7, ehash, verbose,
                                          f"PCR7: {binary_name}'s signator found in 'vendor_cert', extending the matching cert, hash")
                        certs_used.append(ehash)
                    elif verbose:
                        print(f"PCR7: {binary_name}'s signator found in 'vendor_cert' but the hash is already used, skipping")
                    continue

            if not found:
                # Certificate was not found
                raise RuntimeError(f"SecureBoot certificate which signed {binary_name} can't be found in db/shim!")

        return '0x' + ''.join(f'{x:02x}' for x in pcr7).upper()
