# SPDX-License-Identifier: LGPL-2.1-or-later

""" EFI System partition representation """

import glob
import os
import re
from cvmutils.pe import PEImage

# pylint: disable=too-many-branches, too-many-statements, too-few-public-methods

class ESP:
    """ EFI System partition """

    def __init__(self, path):
        self.shim = None
        self.bootloader = None
        self.uki = None
        self.uki_addons = []

        shimname = 'shim'
        bootloaderpath = None
        if os.path.exists(f"{path}/EFI/redhat"):
            vendor='redhat'
        elif os.path.exists(f"{path}/EFI/fedora"):
            vendor='fedora'
        elif os.path.exists(f"{path}/EFI/azurelinux"):
            vendor='azurelinux'
        elif os.path.exists(f"{path}/EFI/rocky"):
            vendor='rocky'
        else:
            print("No EFI vendor dir, assuming legacy Mariner 2 layout")
            vendor='BOOT'
            shimname='boot'

        # Check is shim exists
        shimpath = f"{path}/EFI/{vendor}/{shimname}x64.efi"
        if not os.path.exists(shimpath):
            raise RuntimeError(f"/EFI/{vendor}/{shimname}x64.efi can't be found!")

        # Try getting UKI path from shim fallback
        ukipath = None
        if os.path.exists(f"{path}/EFI/{vendor}/BOOTX64.CSV"):
            # BOOTX64.CSV may contain several entries, take the last one as it will be the first in boot order
            with open(f"{path}/EFI/{vendor}/BOOTX64.CSV", encoding='utf-16-le') as f:
                ukipath = f.readlines()[-1]
            ukipath = ukipath.split(',')[2].split(' ')[0]
            if ukipath.lower().endswith(".efi"):
                ukipath = re.sub("\\\\", "/", ukipath)
                if not os.path.exists(f"{path}/{ukipath}"):
                    print(f"UKI {ukipath} from shim fallback doesn't exist!")
                    ukipath = None
                else:
                    print(f"Using UKI {ukipath} from shim fallback for PCR prediction")
                    ukipath = f"{path}/{ukipath}"
            else:
                print("BOOTX64.CSV does not set UKI to boot")
                ukipath = None

        # If UKI is not set in BOOTX64.CSV, shim will attempt to load grubx64.efi
        if ukipath is None:
            bootloaderpath = f"{path}/EFI/{vendor}/grubx64.efi"
            if not os.path.exists(bootloaderpath):
                raise RuntimeError("No UKI set in BOOTX64.CSV and grubx64.efi is missing!")
            print(f"Using 2nd stage bootloader /EFI/{vendor}/grubx64.efi")

            ukis = sorted(glob.glob(f"{path}/EFI/Linux/*.efi"))
            if ukis != []:
                ukipath = ukis[-1]
                print(f"Warning! Using the latest UKI {ukipath[len(path):]} for PCR prediction")
        if ukipath is None:
            raise RuntimeError("No UKI found for PCR prediction!")

        self.shim = PEImage(path = shimpath)
        if bootloaderpath:
            self.bootloader = PEImage(path = bootloaderpath)
        self.uki = PEImage(path = ukipath)

        for addonpath in [path + "/loader/addons/", ukipath + ".extra.d/"]:
            if os.path.exists(addonpath):
                for addon in sorted(glob.glob(addonpath + "*.addon.efi")):
                    addon_bin = PEImage(path = addon)
                    self.uki_addons.append(addon_bin)
