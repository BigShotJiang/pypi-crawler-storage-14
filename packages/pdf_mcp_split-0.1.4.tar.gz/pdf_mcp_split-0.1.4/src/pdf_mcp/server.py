"""PDF MCP Server using FastMCP."""

from __future__ import annotations

import logging
from typing import Optional

from fastmcp import FastMCP

from .pdf_tools import split_pdf

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

mcp = FastMCP("PDF 拆分")


@mcp.tool()
def split_pdf_file(
    input_path: str,
    output_dir: str,
    split_mode: str = "ranges",
    ranges: Optional[list[str]] = None,
    prefix: Optional[str] = None,
) -> str:
    """拆分PDF文件为多个独立的PDF文件。支持两种拆分模式。

    拆分模式说明：
    1. pages模式（每页一个文件）：
       - 默认拆分所有页，每页生成一个独立PDF文件
       - 如果指定ranges参数，则只拆分指定范围内的页面，每页仍然生成独立文件
       - 示例：ranges=["1-5"] → 生成5个文件（第1页.pdf, 第2页.pdf, ..., 第5页.pdf）
       - 示例：ranges=["1-3", "7-10"] → 生成7个文件（第1、2、3、7、8、9、10页各一个）

    2. ranges模式（按范围合并）：
       - 必须指定ranges参数
       - 每个范围表达式生成一个PDF文件，包含该范围内的所有页面
       - 示例：ranges=["1-5"] → 生成1个文件（包含第1-5页）
       - 示例：ranges=["1-3", "7-10"] → 生成2个文件（一个包含第1-3页，另一个包含第7-10页）

    Args:
        input_path: 输入PDF文件路径
        output_dir: 输出目录路径
        split_mode: 拆分模式，可选值：
            - "pages": 每页一个文件模式
            - "ranges": 按范围合并模式（默认）
        ranges: 页面范围列表，格式示例：
            - ["1-5"]: 第1页到第5页
            - ["1", "3", "5"]: 第1、3、5页
            - ["1-3", "7-10"]: 第1-3页和第7-10页
            - None: 仅在pages模式下，表示拆分所有页
        prefix: 输出文件名前缀，默认使用输入文件名

    Returns:
        拆分结果的详细信息，包括生成的文件列表、总页数等

    示例：
        # 拆分所有页，每页一个文件
        split_pdf_file("document.pdf", "./output", split_mode="pages")

        # 只拆分第1-5页，每页一个文件（生成5个PDF）
        split_pdf_file("document.pdf", "./output", split_mode="pages", ranges=["1-5"])

        # 拆分成2个文件：一个包含第1-5页，另一个包含第10-15页
        split_pdf_file("document.pdf", "./output", split_mode="ranges", ranges=["1-5", "10-15"])
    """
    
    try:
        result = split_pdf(input_path, output_dir, split_mode, ranges, prefix)
        items_info = "\n".join([
            f"  - {item.name}: {item.pages} pages, {item.formatted_size}"
            for item in result.items
        ])
        return (
            f"✅ PDF split succeeded\n"
            f"Output directory: {result.output_dir}\n"
            f"Generated files: {len(result.items)}\n"
            f"Original total pages: {result.total_pages}\n"
            f"Split files:\n{items_info}"
        )
    
    except Exception as e:
        logger.error(f"Failed to split PDF: {e}")
        raise


def main():
    """启动MCP服务器。"""
    mcp.run()


if __name__ == "__main__":
    main()
