from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Optional, Sequence



from .utils import ensure_directory, get_file_stats, parse_page_range, resolve_output_dir
import pikepdf


@dataclass
class SplitItem:
    path: Path
    name: str
    pages: int
    formatted_size: str


@dataclass
class SplitResult:
    output_dir: Path
    items: list[SplitItem]
    total_pages: int
    input_stats: get_file_stats.__annotations__.get("return")  # type: ignore


def _to_path(path_like: str) -> Path:
    return Path(path_like).expanduser().resolve()


def split_pdf(
    input_path: str,
    output_dir: str,
    split_mode: str = "ranges",
    ranges: Optional[Sequence[str]] = None,
    prefix: Optional[str] = None,
) -> SplitResult:
    source_path = _to_path(input_path)
    if not source_path.exists():
        raise FileNotFoundError(f"File not found: {source_path}")
    if source_path.suffix.lower() != ".pdf":
        raise ValueError("Input file must be a PDF")

    resolved_output_dir = resolve_output_dir(source_path, output_dir)
    ensure_directory(resolved_output_dir)

    with pikepdf.Pdf.open(source_path) as pdf:
        total_pages = len(pdf.pages)
        if total_pages == 0:
            raise ValueError("Input PDF is empty")

        base_name = prefix or source_path.stem
        items: list[SplitItem] = []

        if split_mode == "pages":
            if ranges:
                page_numbers_to_split: list[int] = []
                for range_expression in ranges:
                    page_numbers = parse_page_range(range_expression, total_pages)
                    page_numbers_to_split.extend(page_numbers)
                page_numbers_to_split = sorted(set(page_numbers_to_split))
            else:
                page_numbers_to_split = list(range(1, total_pages + 1))

            for page_number in page_numbers_to_split:
                page = pdf.pages[page_number - 1]
                output_path = resolved_output_dir / f"{base_name}_page_{page_number:03d}.pdf"
                new_pdf = pikepdf.Pdf.new()
                new_pdf.pages.append(page)
                new_pdf.save(output_path)
                new_pdf.close()
                stats = get_file_stats(output_path)
                items.append(
                    SplitItem(
                        path=output_path,
                        name=output_path.name,
                        pages=1,
                        formatted_size=stats.formatted_size,
                    )
                )
        elif split_mode == "ranges" and ranges:
            for range_expression in ranges:
                page_numbers = parse_page_range(range_expression, total_pages)
                if not page_numbers:
                    continue

                new_pdf = pikepdf.Pdf.new()
                for page_number in page_numbers:
                    new_pdf.pages.append(pdf.pages[page_number - 1])

                start = min(page_numbers)
                end = max(page_numbers)
                file_name = (
                    f"{base_name}_page_{start:03d}.pdf" if start == end
                    else f"{base_name}_pages_{start:03d}-{end:03d}.pdf"
                )

                output_path = resolved_output_dir / file_name
                new_pdf.save(output_path)
                new_pdf.close()
                stats = get_file_stats(output_path)
                items.append(
                    SplitItem(
                        path=output_path,
                        name=file_name,
                        pages=len(page_numbers),
                        formatted_size=stats.formatted_size,
                    )
                )
        else:
            raise ValueError("Ranges mode requires the 'ranges' parameter")

    if not items:
        raise ValueError("No split result generated")

    return SplitResult(
        output_dir=resolved_output_dir,
        items=items,
        total_pages=total_pages,
        input_stats=get_file_stats(source_path),
    )
