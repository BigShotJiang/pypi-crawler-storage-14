# PDF 拆分 MCP 服务

仅提供一个工具：`split_pdf_file`，用于按页面或页面范围拆分 PDF。

## 运行

```bash
uv run pdf-mcp-server
```

或：

```bash
$env:PYTHONPATH="src"; python -c "import pdf_mcp.server; pdf_mcp.server.main()"
```

## 工具：split_pdf_file

- `input_path` (str) 输入 PDF 文件路径
- `output_dir` (str) 输出目录路径
- `split_mode` (str) 拆分模式：`pages` 或 `ranges`
- `ranges` (list[str], 可选) 页面范围，如 `"1-3"`, `"5"`, `"7-10"`
- `prefix` (str, 可选) 输出文件名前缀

示例：

- 每页一个文件：`split_mode="pages"`
- 指定范围每页一个文件：`split_mode="pages"`, `ranges=["1-3", "7-9"]`
- 按范围生成多个文件：`split_mode="ranges"`, `ranges=["1-5", "10-15"]`

## 依赖

- `fastmcp`
- `pikepdf`

## License

MIT
