# LinkBay-Settings

**Version**: 0.1.0  
**License**: Proprietary  
**Python**: 3.8+

Sistema di gestione configurazioni per l'ecosistema LinkBay: gerarchico, multi-tenant, protocol-based e totalmente agnostico rispetto allo storage. Coordina default di piattaforma, override per tenant, preferenze utente, feature flag e limiti di piano con validazione type-safe e auditing centralizzato.

## Principali capacita

- Gerarchia platform -> tenant -> user con risoluzione deterministica e fallback sicuri.
- API async tramite `SettingsManager` con cache opzionale e audit trail.
- Validazione type-safe per 9 data type (string, int, float, bool, enum, email, url, color, json) e regole custom.
- Feature flag e quote per tenant tramite `FeatureFlagService`, integrabili con LinkBay-Subscriptions.
- Branding centralizzato via `BrandingService`, pronto per LinkBay-Templates e LinkBay-Billing.
- Import/export, clone e history con integrazione verso `LinkBay-Audit` e `LinkBay-Roles` per governance.
- Router FastAPI opzionale per esposizione REST self-service.

## Indice

- [Requisiti](#requisiti)
- [Architettura e componenti](#architettura-e-componenti)
- [Modello gerarchico](#modello-gerarchico)
- [Data type e validazione](#data-type-e-validazione)
- [Quick start](#quick-start)
- [Feature flag e limiti](#feature-flag-e-limiti)
- [Branding e integrazione template](#branding-e-integrazione-template)
- [Caching e performance](#caching-e-performance)
- [Governance e sicurezza](#governance-e-sicurezza)
- [Migrazione, import/export](#migrazione-importexport)
- [FAQ](#faq)
- [Troubleshooting](#troubleshooting)
- [Supporto e licenza](#supporto-e-licenza)

## Requisiti

| Requisito | Dettagli |
| --- | --- |
| Python | 3.8 o superiore |
| Dipendenze core | `pydantic>=2.0.0` |
| Extra opzionali | `linkbay-settings[fastapi]` abilita il router REST |
| Storage suggeriti | PostgreSQL (JSONB), MongoDB, DynamoDB, Redis per cache |
| Ecosistema | Usa `LinkBay-Roles`, `LinkBay-Audit`, `LinkBay-Subscriptions`, `LinkBay-Templates` |

## Architettura e componenti

La libreria e completamente protocol-based, quindi scegli storage, cache e audit secondo la tua infrastruttura:

- `SettingsStorage`: gestisce CRUD e platform default. Implementalo con DB relazionale, NoSQL o config store esistente.
- `SettingsCacheProvider`: cache opzionale (Redis, Memcached) per ridurre latenza nelle risoluzioni.
- `SettingsAuditProvider`: ponte verso LinkBay-Audit o altro sistema per versioning, history e revert.
- `ValidationService`: orchestratore dei validator built-in, garantisce type safety per ogni change.
- `SettingsManager`: servizio core (CRUD, resolve, history, import/export, clone) con invalidazione cache.
- `FeatureFlagService`: helper per feature gating e quote basate su tenant o piano.
- `BrandingService`: API semplificate per colori, logo, tipografia e naming di tenant.

Schema di flusso tipico:

```
request -> SettingsManager.resolve_setting -> cache (hit?) -> storage -> audit/cache invalidation -> response
```

## Modello gerarchico

LinkBay-Settings risolve ogni chiave seguendo questa precedenza:

1. **User scope** (`user_id` presente)
2. **Tenant scope** (override per tenant)
3. **Platform default** (valore globale)

Se nessun livello fornisce un valore, viene sollevata `SettingNotFoundError`. Piani subscription o tier possono essere modellati come tenant template da clonare (`clone_settings`) o tramite chiavi `limit.` e `feature.`. Utenti di uno stesso tenant vedono i valori effettivi ma possono avere preferenze personali se abilitate.

### Esempio di risoluzione

| Scope | Chiave | Valore |
| --- | --- | --- |
| Platform | `branding.primary_color` | `#0040ff` |
| Tenant `tenant_abc` | `branding.primary_color` | `#111111` |
| User `user_42` | (nessun override) | - |

`resolve_setting("branding.primary_color", tenant_id="tenant_abc", user_id="user_42")` restituisce `#111111` con `precedence_chain = ["tenant", "platform"]`.

## Data type e validazione

I nove data type supportati (Enum `SettingDataType`) sono:

| Data type | Validatore | Regole disponibili |
| --- | --- | --- |
| `string` | `StringValidator` | `min_length`, `max_length`, `pattern` |
| `integer` | `IntValidator` | `min`, `max` |
| `float` | `FloatValidator` | `min`, `max` |
| `boolean` | `BoolValidator` | — |
| `json` | `JSONValidator` | accetta dict/list o string JSON |
| `enum` | `EnumValidator` | `allowed_values` |
| `email` | `EmailValidator` | pattern RFC semplice |
| `url` | `URLValidator` | http/https con porta opzionale |
| `color` | `ColorValidator` | formato `#RRGGBB`

`ValidationService` espone `validate()` e `get_last_error()` per investigare fallimenti. Puoi registrare validator custom estendendo il service.

## Quick start

### 1. Implementa uno storage (esempio in-memory per test)

```python
from typing import Dict, Any, Optional, List
from linkbay_settings import SettingsStorage

class InMemoryStorage(SettingsStorage):
	def __init__(self):
		self.platform_defaults: Dict[str, Dict[str, Any]] = {
			"branding.primary_color": {"value": "#0040ff"},
			"feature.enable_ai": {"value": False},
			"limit.max_products": {"value": 1000},
		}
		self.tenants: Dict[str, Dict[str, Dict[str, Any]]] = {}

	async def get_setting(self, key: str, tenant_id: str, user_id: Optional[str] = None, scope: str = "tenant") -> Optional[Dict[str, Any]]:
		bucket = self.tenants.setdefault(tenant_id, {"tenant": {}, "user": {}})
		if scope == "user" and user_id:
			return bucket["user"].get(user_id, {}).get(key)
		return bucket[scope].get(key)

	async def set_setting(self, setting_data: Dict[str, Any]) -> Dict[str, Any]:
		bucket = self.tenants.setdefault(setting_data["tenant_id"], {"tenant": {}, "user": {}})
		scope = setting_data.get("scope", "tenant")
		if scope == "user" and setting_data.get("user_id"):
			user_bucket = bucket["user"].setdefault(setting_data["user_id"], {})
			user_bucket[setting_data["key"]] = setting_data
		else:
			bucket[scope][setting_data["key"]] = setting_data
		return setting_data

	async def delete_setting(self, key: str, tenant_id: str, user_id: Optional[str] = None, scope: str = "tenant") -> bool:
		bucket = self.tenants.setdefault(tenant_id, {"tenant": {}, "user": {}})
		if scope == "user" and user_id:
			return bucket["user"].get(user_id, {}).pop(key, None) is not None
		return bucket[scope].pop(key, None) is not None

	async def list_settings(self, tenant_id: str, scope: str = "tenant", category: Optional[str] = None, user_id: Optional[str] = None) -> List[Dict[str, Any]]:
		bucket = self.tenants.setdefault(tenant_id, {"tenant": {}, "user": {}})
		if scope == "user" and user_id:
			return list(bucket["user"].get(user_id, {}).values())
		return list(bucket[scope].values())

	async def get_platform_default(self, key: str) -> Optional[Dict[str, Any]]:
		return self.platform_defaults.get(key)
```

### 2. Istanziamento servizi

```python
from linkbay_settings import SettingsManager, FeatureFlagService, BrandingService
from linkbay_settings.services.validation_service import ValidationService

storage = InMemoryStorage()
validation_service = ValidationService()
settings_manager = SettingsManager(storage=storage, validation_service=validation_service)
feature_flags = FeatureFlagService(storage=storage)
branding = BrandingService(storage=storage)
```

### 3. Creazione e risoluzione

```python
from linkbay_settings import SettingCreate, SettingScope, SettingDataType, SettingCategory

create_payload = SettingCreate(
	key="branding.primary_color",
	value="#111111",
	scope=SettingScope.TENANT,
	data_type=SettingDataType.COLOR,
	category=SettingCategory.BRANDING,
	description="Primary branding color",
)

await settings_manager.set_setting(
	key=create_payload.key,
	value=create_payload.value,
	tenant_id="tenant_abc",
	user_id=None,
	setting_create=create_payload,
	updated_by="user_admin",
)

resolved = await settings_manager.resolve_setting(
	key="branding.primary_color",
	tenant_id="tenant_abc",
	user_id="user_42",
)
print(resolved["value"], resolved["precedence_chain"])
```

Output esempio: `#111111`, `['tenant', 'platform']`.

## Feature flag e limiti

```python
await feature_flags.enable_feature("advanced_reports", tenant_id="tenant_abc", updated_by="ops")

if await feature_flags.is_feature_enabled("advanced_reports", tenant_id="tenant_abc"):
	# abilita percorsi LinkBay-Analytics avanzati
	...

limit_ok = await feature_flags.check_limit(
	limit_key="max_products",
	tenant_id="tenant_abc",
	current_usage=512,
)
if not limit_ok:
	raise HTTPException(status_code=402, detail="Upgrade piano richiesto")
```

Coordina questi flag con `LinkBay-Subscriptions` impostando default per piano e clonando set di impostazioni quando un tenant cambia tier.

## Branding e integrazione template

```python
branding_cfg = await branding.get_branding("tenant_abc")
context = {
	"primary_color": branding_cfg.primary_color,
	"company_name": branding_cfg.company_name,
}
rendered = await templates.render_email("welcome", tenant_id="tenant_abc", context=context)
```

`BrandingService.update_branding()` scrive direttamente le chiavi `branding.*` usando i validator corretti (color, url). Collega questo flusso a LinkBay-Templates per email e PDF, e a LinkBay-Billing per personalizzare documenti fiscali.

## Caching e performance

- Usa `SettingsCacheProvider` per memorizzare il risultato di `resolve_setting` con TTL (predefinito `DEFAULT_CACHE_TTL = 300`).
- Il manager invalida automaticamente chiavi `setting:{tenant}:{user}:{key}` su update/delete/import/clone.
- Strategie consigliate: cache per tenant in Redis con prefix dedicato e invalidazione per pattern (`invalidate_pattern`).
- In workload ad alto throughput, considera warmup post-deploy caricando le chiavi piu usate.

## Governance e sicurezza

- **Access control**: proteggi le route di gestione con LinkBay-Roles (`settings:*`, `branding:*`, `feature:*`).
- **Audit**: collega `SettingsAuditProvider` a LinkBay-Audit per loggare chi ha cambiato cosa e revertire tramite `revert_setting`.
- **Sensibilita**: marca chiavi con `is_sensitive=True` e conserva i valori cifrati a livello storage. Non esportare campi sensibili senza mascheramento.
- **Processo di change**: integra notifiche via LinkBay-Notifications per eventi critici (es. modifica `limit.max_users`).

## Migrazione, import/export

- `export_settings` genera snapshot JSON del tenant, utile per backup e rollout complessi.
- `import_settings(overwrite_existing=False)` carica file di seed; utile per bootstrap di nuovi tenant o per ripristini.
- `clone_settings(source_tenant_id, target_tenant_id)` replica asset da tenant template (es. piani Bronze/Silver/Gold).
- Per migrazioni schema, abbina `SettingsManager.list_settings` con script personalizzati per trasformare le chiavi.

## FAQ

**Posso aggiungere nuovi data type?**  
Si, estendi `ValidationService` registrando un validator custom e un nuovo valore in `SettingDataType`.

**Come gestisco rollout graduale di una feature?**  
Usa `FeatureFlagService` per abilitare la feature a subset di tenant; per user-level toggles, salva preferenze in scope `user` o appoggiati a LinkBay-Experiments.

**Il modello supporta piani gerarchici?**  
Si: mantieni tenant template o chiavi `plan.*` per differenziare i default, poi clona o applica import al cambio piano.

## Troubleshooting

- **ValidationError**: verifica `setting_create.data_type` e il contenuto di `validation_schema`; usa `ValidationService.get_last_error()` per il dettaglio.
- **Cache stale**: assicurati che il provider implementi `delete` o `invalidate_pattern`; `SettingsManager` li invoca dopo update/delete/import.
- **Setting mancante**: prepopola `SettingsStorage.get_platform_default` con i default minimi oppure gestisci fallback applicativo.
- **History vuota**: collega un `SettingsAuditProvider`; molte funzionalita (revert, diff) richiedono audit attivo.

## Supporto e licenza

- Supporto: quagliara.alessio@gmail.com  
- Repository: https://github.com/AlessioQuagliara/LinkBay-Py  
- Issue tracker: cartella `LinkBay-Settings`
- Licenza: Proprietary (c) 2025 Alessio Quagliara

> LinkBay-Settings non sostituisce policy interne di sicurezza o change management: valida sempre le configurazioni critiche in ambienti di staging prima del deploy.
