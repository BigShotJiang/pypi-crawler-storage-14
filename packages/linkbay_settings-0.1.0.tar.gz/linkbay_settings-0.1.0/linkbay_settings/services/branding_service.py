"""Branding configuration service."""

from typing import Optional

from ..protocols import SettingsStorage
from ..schemas import BrandingConfig
from ..constants import BRANDING_PREFIX


class BrandingService:
    """
    Service for managing tenant branding configuration.
    
    Provides simplified access to branding settings.
    """
    
    def __init__(self, storage: SettingsStorage):
        self.storage = storage
    
    async def get_branding(
        self,
        tenant_id: str,
    ) -> BrandingConfig:
        """Get complete branding configuration for tenant."""
        # Get all branding settings
        settings = await self.storage.list_settings(
            tenant_id=tenant_id,
            scope="tenant",
            category="branding",
        )
        
        # Map to BrandingConfig
        branding_data = {}
        for setting in settings:
            key = setting["key"].replace(BRANDING_PREFIX, "")
            branding_data[key] = setting["value"]
        
        # Set defaults for missing values
        if "company_name" not in branding_data:
            branding_data["company_name"] = f"Tenant {tenant_id}"
        
        return BrandingConfig(**branding_data)
    
    async def update_branding(
        self,
        tenant_id: str,
        branding_config: BrandingConfig,
        updated_by: str,
    ) -> BrandingConfig:
        """Update branding configuration."""
        from datetime import datetime
        from ..constants import SettingScope, SettingDataType, SettingCategory
        
        # Update each branding setting
        for field, value in branding_config.model_dump(exclude_unset=True).items():
            if value is None:
                continue
            
            key = f"{BRANDING_PREFIX}{field}"
            
            # Determine data type
            data_type = SettingDataType.STRING
            if field.endswith("_color"):
                data_type = SettingDataType.COLOR
            elif field.endswith("_url"):
                data_type = SettingDataType.URL
            
            setting_data = {
                "key": key,
                "value": value,
                "tenant_id": tenant_id,
                "user_id": None,
                "scope": SettingScope.TENANT.value,
                "data_type": data_type.value,
                "category": SettingCategory.BRANDING.value,
                "description": f"Branding: {field}",
                "updated_at": datetime.utcnow(),
                "updated_by": updated_by,
            }
            
            await self.storage.set_setting(setting_data)
        
        return branding_config
