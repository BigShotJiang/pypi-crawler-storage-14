"""Feature flag management service."""

from typing import List, Optional

from ..protocols import SettingsStorage
from ..schemas import FeatureFlag
from ..constants import FEATURE_PREFIX, SettingScope, SettingDataType, SettingCategory
from datetime import datetime


class FeatureFlagService:
    """
    Service for managing feature flags.
    
    Integrates with subscription plans for feature gating.
    """
    
    def __init__(self, storage: SettingsStorage):
        self.storage = storage
    
    async def is_feature_enabled(
        self,
        feature_key: str,
        tenant_id: str,
    ) -> bool:
        """Check if feature is enabled for tenant."""
        key = f"{FEATURE_PREFIX}{feature_key}"
        
        setting = await self.storage.get_setting(
            key=key,
            tenant_id=tenant_id,
            scope=SettingScope.TENANT.value,
        )
        
        if not setting:
            # Check platform default
            platform_setting = await self.storage.get_platform_default(key=key)
            if platform_setting:
                return platform_setting["value"]
            return False
        
        return setting["value"]
    
    async def enable_feature(
        self,
        feature_key: str,
        tenant_id: str,
        updated_by: str,
        requires_plan: Optional[str] = None,
    ) -> FeatureFlag:
        """Enable feature for tenant."""
        key = f"{FEATURE_PREFIX}{feature_key}"
        
        setting_data = {
            "key": key,
            "value": True,
            "tenant_id": tenant_id,
            "user_id": None,
            "scope": SettingScope.TENANT.value,
            "data_type": SettingDataType.BOOLEAN.value,
            "category": SettingCategory.FEATURES.value,
            "description": f"Feature flag: {feature_key}",
            "updated_at": datetime.utcnow(),
            "updated_by": updated_by,
        }
        
        await self.storage.set_setting(setting_data)
        
        return FeatureFlag(
            key=feature_key,
            enabled=True,
            requires_plan=requires_plan,
        )
    
    async def disable_feature(
        self,
        feature_key: str,
        tenant_id: str,
        updated_by: str,
    ) -> FeatureFlag:
        """Disable feature for tenant."""
        key = f"{FEATURE_PREFIX}{feature_key}"
        
        setting_data = {
            "key": key,
            "value": False,
            "tenant_id": tenant_id,
            "user_id": None,
            "scope": SettingScope.TENANT.value,
            "data_type": SettingDataType.BOOLEAN.value,
            "category": SettingCategory.FEATURES.value,
            "description": f"Feature flag: {feature_key}",
            "updated_at": datetime.utcnow(),
            "updated_by": updated_by,
        }
        
        await self.storage.set_setting(setting_data)
        
        return FeatureFlag(
            key=feature_key,
            enabled=False,
        )
    
    async def list_features(
        self,
        tenant_id: str,
    ) -> List[FeatureFlag]:
        """List all feature flags for tenant."""
        settings = await self.storage.list_settings(
            tenant_id=tenant_id,
            scope=SettingScope.TENANT.value,
            category=SettingCategory.FEATURES.value,
        )
        
        features = []
        for setting in settings:
            feature_key = setting["key"].replace(FEATURE_PREFIX, "")
            features.append(
                FeatureFlag(
                    key=feature_key,
                    enabled=setting["value"],
                    description=setting.get("description"),
                )
            )
        
        return features
    
    async def check_limit(
        self,
        limit_key: str,
        tenant_id: str,
        current_usage: int,
    ) -> bool:
        """
        Check if tenant is within limit.
        
        Returns True if usage is below limit, False if exceeded.
        """
        from ..constants import LIMIT_PREFIX
        
        key = f"{LIMIT_PREFIX}{limit_key}"
        
        setting = await self.storage.get_setting(
            key=key,
            tenant_id=tenant_id,
            scope=SettingScope.TENANT.value,
        )
        
        if not setting:
            # Check platform default
            platform_setting = await self.storage.get_platform_default(key=key)
            if not platform_setting:
                return True  # No limit set
            limit_value = platform_setting["value"]
        else:
            limit_value = setting["value"]
        
        return current_usage < limit_value
    
    async def get_limit(
        self,
        limit_key: str,
        tenant_id: str,
    ) -> Optional[int]:
        """Get limit value for tenant."""
        from ..constants import LIMIT_PREFIX
        
        key = f"{LIMIT_PREFIX}{limit_key}"
        
        setting = await self.storage.get_setting(
            key=key,
            tenant_id=tenant_id,
            scope=SettingScope.TENANT.value,
        )
        
        if not setting:
            # Check platform default
            platform_setting = await self.storage.get_platform_default(key=key)
            if platform_setting:
                return platform_setting["value"]
            return None
        
        return setting["value"]
