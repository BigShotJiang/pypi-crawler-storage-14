"""Core settings manager service."""

from typing import Optional, Dict, Any, List
from datetime import datetime

from ..protocols import (
    SettingsStorage,
    SettingsAuditProvider,
    SettingsCacheProvider,
)
from ..schemas import (
    SettingDTO,
    SettingCreate,
    SettingUpdate,
    SettingFilter,
    SettingHistory,
    SettingsExport,
)
from ..constants import SettingScope, DEFAULT_CACHE_TTL
from ..exceptions import SettingNotFoundError, ValidationError
from .validation_service import ValidationService


class SettingsManager:
    """
    Core settings management service.
    
    Handles hierarchical resolution, CRUD operations, caching.
    """
    
    def __init__(
        self,
        storage: SettingsStorage,
        validation_service: ValidationService,
        audit_provider: Optional[SettingsAuditProvider] = None,
        cache_provider: Optional[SettingsCacheProvider] = None,
    ):
        self.storage = storage
        self.validation_service = validation_service
        self.audit_provider = audit_provider
        self.cache_provider = cache_provider
    
    async def get_setting(
        self,
        key: str,
        tenant_id: str,
        user_id: Optional[str] = None,
    ) -> SettingDTO:
        """Get setting by key (no hierarchy resolution)."""
        scope = SettingScope.USER if user_id else SettingScope.TENANT
        
        setting_data = await self.storage.get_setting(
            key=key,
            tenant_id=tenant_id,
            user_id=user_id,
            scope=scope.value,
        )
        
        if not setting_data:
            raise SettingNotFoundError(key=key, tenant_id=tenant_id, user_id=user_id)
        
        return SettingDTO(**setting_data)
    
    async def resolve_setting(
        self,
        key: str,
        tenant_id: str,
        user_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        Resolve setting with hierarchy: user → tenant → platform.
        
        Returns effective value with precedence chain.
        """
        cache_key = f"setting:{tenant_id}:{user_id or 'tenant'}:{key}"
        
        # Check cache
        if self.cache_provider:
            cached = await self.cache_provider.get(cache_key)
            if cached:
                return cached
        
        precedence_chain = []
        effective_value = None
        
        # 1. Try user setting
        if user_id:
            user_setting = await self.storage.get_setting(
                key=key,
                tenant_id=tenant_id,
                user_id=user_id,
                scope=SettingScope.USER.value,
            )
            if user_setting:
                effective_value = user_setting["value"]
                precedence_chain.append("user")
        
        # 2. Try tenant setting
        if effective_value is None:
            tenant_setting = await self.storage.get_setting(
                key=key,
                tenant_id=tenant_id,
                scope=SettingScope.TENANT.value,
            )
            if tenant_setting:
                effective_value = tenant_setting["value"]
                precedence_chain.append("tenant")
        
        # 3. Try platform default
        if effective_value is None:
            platform_setting = await self.storage.get_platform_default(key=key)
            if platform_setting:
                effective_value = platform_setting["value"]
                precedence_chain.append("platform")
        
        if effective_value is None:
            raise SettingNotFoundError(key=key, tenant_id=tenant_id, user_id=user_id)
        
        result = {
            "key": key,
            "value": effective_value,
            "precedence_chain": precedence_chain,
        }
        
        # Cache result
        if self.cache_provider:
            await self.cache_provider.set(
                cache_key=cache_key,
                value=result,
                ttl=DEFAULT_CACHE_TTL,
            )
        
        return result
    
    async def set_setting(
        self,
        key: str,
        value: Any,
        tenant_id: str,
        user_id: Optional[str],
        setting_create: SettingCreate,
        updated_by: str,
    ) -> SettingDTO:
        """Create or update setting."""
        # Validate value
        is_valid = self.validation_service.validate(
            value=value,
            data_type=setting_create.data_type,
            validation_rules=setting_create.validation_schema,
        )
        
        if not is_valid:
            error_msg = self.validation_service.get_last_error()
            raise ValidationError(key=key, value=value, reason=error_msg)
        
        # Get old value for audit
        old_value = None
        try:
            old_setting = await self.get_setting(key, tenant_id, user_id)
            old_value = old_setting.value
        except SettingNotFoundError:
            pass
        
        # Save setting
        scope = SettingScope.USER if user_id else SettingScope.TENANT
        setting_data = {
            "key": key,
            "value": value,
            "tenant_id": tenant_id,
            "user_id": user_id,
            "scope": scope.value,
            "data_type": setting_create.data_type.value,
            "default_value": setting_create.default_value,
            "validation_schema": setting_create.validation_schema,
            "category": setting_create.category.value,
            "description": setting_create.description,
            "is_sensitive": setting_create.is_sensitive,
            "updated_at": datetime.utcnow(),
            "updated_by": updated_by,
        }
        
        saved_setting = await self.storage.set_setting(setting_data)
        
        # Audit log
        if self.audit_provider:
            await self.audit_provider.log_change(
                key=key,
                tenant_id=tenant_id,
                user_id=updated_by,
                old_value=old_value,
                new_value=value,
                scope=scope.value,
            )
        
        # Invalidate cache
        if self.cache_provider:
            await self._invalidate_setting_cache(key, tenant_id, user_id)
        
        return SettingDTO(**saved_setting)
    
    async def delete_setting(
        self,
        key: str,
        tenant_id: str,
        user_id: Optional[str] = None,
    ) -> bool:
        """Delete setting."""
        scope = SettingScope.USER if user_id else SettingScope.TENANT
        
        deleted = await self.storage.delete_setting(
            key=key,
            tenant_id=tenant_id,
            user_id=user_id,
            scope=scope.value,
        )
        
        if deleted and self.cache_provider:
            await self._invalidate_setting_cache(key, tenant_id, user_id)
        
        return deleted
    
    async def list_settings(
        self,
        tenant_id: str,
        filters: SettingFilter,
        user_id: Optional[str] = None,
    ) -> List[SettingDTO]:
        """List settings with filters."""
        scope = filters.scope.value if filters.scope else SettingScope.TENANT.value
        
        settings_data = await self.storage.list_settings(
            tenant_id=tenant_id,
            scope=scope,
            category=filters.category.value if filters.category else None,
            user_id=user_id,
        )
        
        settings = [SettingDTO(**s) for s in settings_data]
        
        # Apply additional filters
        if filters.data_type:
            settings = [s for s in settings if s.data_type == filters.data_type]
        
        if filters.search_query:
            query_lower = filters.search_query.lower()
            settings = [
                s for s in settings
                if query_lower in s.key.lower()
                or (s.description and query_lower in s.description.lower())
            ]
        
        return settings
    
    async def get_setting_history(
        self,
        key: str,
        tenant_id: str,
        limit: int = 100,
    ) -> List[SettingHistory]:
        """Get change history for setting."""
        if not self.audit_provider:
            return []
        
        history_data = await self.audit_provider.get_history(
            key=key,
            tenant_id=tenant_id,
            limit=limit,
        )
        
        return [SettingHistory(**h) for h in history_data]
    
    async def revert_setting(
        self,
        key: str,
        tenant_id: str,
        version: int,
        updated_by: str,
    ) -> SettingDTO:
        """Revert setting to specific version."""
        if not self.audit_provider:
            raise ValueError("Audit provider required for revert")
        
        version_data = await self.audit_provider.get_version(
            key=key,
            tenant_id=tenant_id,
            version=version,
        )
        
        if not version_data:
            raise SettingNotFoundError(key=key, tenant_id=tenant_id)
        
        # Restore old value
        setting_data = {
            "key": key,
            "value": version_data["value"],
            "tenant_id": tenant_id,
            "scope": version_data["scope"],
            "data_type": version_data["data_type"],
            "updated_at": datetime.utcnow(),
            "updated_by": updated_by,
        }
        
        saved_setting = await self.storage.set_setting(setting_data)
        
        # Invalidate cache
        if self.cache_provider:
            await self._invalidate_setting_cache(key, tenant_id, None)
        
        return SettingDTO(**saved_setting)
    
    async def export_settings(
        self,
        tenant_id: str,
    ) -> SettingsExport:
        """Export all tenant settings."""
        settings_data = await self.storage.list_settings(
            tenant_id=tenant_id,
            scope=SettingScope.TENANT.value,
        )
        
        settings = [SettingDTO(**s) for s in settings_data]
        
        return SettingsExport(
            tenant_id=tenant_id,
            exported_at=datetime.utcnow(),
            settings=settings,
        )
    
    async def import_settings(
        self,
        tenant_id: str,
        settings: List[SettingCreate],
        updated_by: str,
        overwrite_existing: bool = False,
    ) -> int:
        """Import settings from export."""
        imported_count = 0
        
        for setting in settings:
            # Check if exists
            try:
                existing = await self.get_setting(
                    key=setting.key,
                    tenant_id=tenant_id,
                )
                if not overwrite_existing:
                    continue
            except SettingNotFoundError:
                pass
            
            await self.set_setting(
                key=setting.key,
                value=setting.value,
                tenant_id=tenant_id,
                user_id=None,
                setting_create=setting,
                updated_by=updated_by,
            )
            imported_count += 1
        
        return imported_count
    
    async def clone_settings(
        self,
        source_tenant_id: str,
        target_tenant_id: str,
        updated_by: str,
        overwrite_existing: bool = False,
    ) -> int:
        """Clone settings from template tenant."""
        source_settings = await self.storage.list_settings(
            tenant_id=source_tenant_id,
            scope=SettingScope.TENANT.value,
        )
        
        settings_create = [
            SettingCreate(
                key=s["key"],
                value=s["value"],
                scope=SettingScope.TENANT,
                data_type=s["data_type"],
                default_value=s.get("default_value"),
                validation_schema=s.get("validation_schema"),
                category=s["category"],
                description=s.get("description"),
                is_sensitive=s.get("is_sensitive", False),
            )
            for s in source_settings
        ]
        
        return await self.import_settings(
            tenant_id=target_tenant_id,
            settings=settings_create,
            updated_by=updated_by,
            overwrite_existing=overwrite_existing,
        )
    
    async def _invalidate_setting_cache(
        self,
        key: str,
        tenant_id: str,
        user_id: Optional[str],
    ) -> None:
        """Invalidate cache for setting."""
        if not self.cache_provider:
            return
        
        # Invalidate all cache keys for this setting
        pattern = f"setting:{tenant_id}:*:{key}"
        await self.cache_provider.invalidate_pattern(pattern)
