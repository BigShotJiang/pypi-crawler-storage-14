"""Validation service for settings."""

from typing import Any, Dict, Optional

from ..constants import SettingDataType
from ..validators import (
    StringValidator,
    IntValidator,
    FloatValidator,
    BoolValidator,
    EnumValidator,
    EmailValidator,
    URLValidator,
    ColorValidator,
    JSONValidator,
)


class ValidationService:
    """
    Service for validating setting values.
    
    Routes to appropriate validator based on data type.
    """
    
    def __init__(self):
        self.validators = {
            SettingDataType.STRING: StringValidator(),
            SettingDataType.INTEGER: IntValidator(),
            SettingDataType.FLOAT: FloatValidator(),
            SettingDataType.BOOLEAN: BoolValidator(),
            SettingDataType.ENUM: EnumValidator(),
            SettingDataType.EMAIL: EmailValidator(),
            SettingDataType.URL: URLValidator(),
            SettingDataType.COLOR: ColorValidator(),
            SettingDataType.JSON: JSONValidator(),
        }
        self.last_error = ""
    
    def validate(
        self,
        value: Any,
        data_type: SettingDataType,
        validation_rules: Optional[Dict[str, Any]] = None,
    ) -> bool:
        """Validate value against data type and rules."""
        validator = self.validators.get(data_type)
        
        if not validator:
            self.last_error = f"No validator for data type: {data_type}"
            return False
        
        is_valid = validator.validate(value, validation_rules)
        
        if not is_valid:
            self.last_error = validator.get_error_message()
        
        return is_valid
    
    def get_last_error(self) -> str:
        """Get last validation error message."""
        return self.last_error
