"""Pydantic schemas for settings."""

from typing import Optional, Dict, Any, List
from datetime import datetime
from pydantic import BaseModel, Field, EmailStr, HttpUrl

from .constants import SettingScope, SettingDataType, SettingCategory


class SettingDTO(BaseModel):
    """Complete setting metadata."""
    key: str
    value: Any
    tenant_id: str
    user_id: Optional[str] = None
    scope: SettingScope
    data_type: SettingDataType
    default_value: Optional[Any] = None
    validation_schema: Optional[Dict[str, Any]] = None
    category: SettingCategory
    description: Optional[str] = None
    is_sensitive: bool = False
    updated_at: datetime
    updated_by: str


class SettingCreate(BaseModel):
    """Request to create/update setting."""
    key: str
    value: Any
    scope: SettingScope
    data_type: SettingDataType
    default_value: Optional[Any] = None
    validation_schema: Optional[Dict[str, Any]] = None
    category: SettingCategory = SettingCategory.GENERAL
    description: Optional[str] = None
    is_sensitive: bool = False


class SettingUpdate(BaseModel):
    """Request to update setting."""
    value: Any
    description: Optional[str] = None


class SettingFilter(BaseModel):
    """Filters for listing settings."""
    scope: Optional[SettingScope] = None
    category: Optional[SettingCategory] = None
    data_type: Optional[SettingDataType] = None
    search_query: Optional[str] = None


class SettingResponse(BaseModel):
    """Response with single setting."""
    setting: SettingDTO
    effective_value: Any
    precedence_chain: List[str]  # ["user", "tenant", "platform"]


class SettingListResponse(BaseModel):
    """Paginated list of settings."""
    settings: List[SettingDTO]
    total: int


class SettingHistory(BaseModel):
    """Setting change history entry."""
    key: str
    tenant_id: str
    user_id: str
    old_value: Any
    new_value: Any
    scope: SettingScope
    changed_at: datetime
    changed_by: str
    version: int


class CategoryDTO(BaseModel):
    """Setting category metadata."""
    name: SettingCategory
    label: str
    description: str
    icon: Optional[str] = None
    settings_count: int = 0


class BrandingConfig(BaseModel):
    """Tenant branding configuration."""
    logo_url: Optional[str] = None
    primary_color: str = "#0066CC"
    secondary_color: str = "#6C757D"
    font_family: str = "Inter, sans-serif"
    custom_css: Optional[str] = None
    favicon_url: Optional[str] = None
    email_header_logo: Optional[str] = None
    company_name: str
    domain_name: Optional[str] = None


class EmailConfig(BaseModel):
    """Email configuration."""
    smtp_host: str
    smtp_port: int = 587
    smtp_user: str
    smtp_password: str
    smtp_use_tls: bool = True
    from_email: EmailStr
    from_name: str
    reply_to: Optional[EmailStr] = None


class FeatureFlag(BaseModel):
    """Feature flag configuration."""
    key: str
    enabled: bool
    description: Optional[str] = None
    requires_plan: Optional[str] = None  # "pro", "enterprise"


class LimitConfig(BaseModel):
    """Limit configuration."""
    key: str
    limit_value: int
    current_usage: Optional[int] = None
    description: Optional[str] = None


class SettingsExport(BaseModel):
    """Settings export format."""
    tenant_id: str
    exported_at: datetime
    settings: List[SettingDTO]
    metadata: Dict[str, Any] = Field(default_factory=dict)


class SettingsImportRequest(BaseModel):
    """Settings import request."""
    settings: List[SettingCreate]
    overwrite_existing: bool = False


class CloneSettingsRequest(BaseModel):
    """Clone settings from template."""
    source_tenant_id: str
    overwrite_existing: bool = False
