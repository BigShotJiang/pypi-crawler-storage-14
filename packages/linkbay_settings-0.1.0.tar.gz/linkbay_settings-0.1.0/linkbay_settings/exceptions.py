"""Custom exceptions for settings management."""


class SettingsError(Exception):
    """Base exception for settings errors."""
    pass


class SettingNotFoundError(SettingsError):
    """Setting not found."""
    
    def __init__(self, key: str, tenant_id: str, user_id: str = None):
        self.key = key
        self.tenant_id = tenant_id
        self.user_id = user_id
        scope = f"user {user_id}" if user_id else f"tenant {tenant_id}"
        super().__init__(f"Setting '{key}' not found for {scope}")


class ValidationError(SettingsError):
    """Setting validation failed."""
    
    def __init__(self, key: str, value: any, reason: str):
        self.key = key
        self.value = value
        self.reason = reason
        super().__init__(f"Validation failed for '{key}': {reason}")


class InvalidScopeError(SettingsError):
    """Invalid setting scope."""
    
    def __init__(self, scope: str):
        self.scope = scope
        super().__init__(f"Invalid scope: {scope}")
