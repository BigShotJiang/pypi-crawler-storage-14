"""LinkBay-Settings: Protocol-based configuration management for multi-tenant SaaS."""

from .constants import (
    SettingScope,
    SettingDataType,
    SettingCategory,
)

from .exceptions import (
    SettingsError,
    SettingNotFoundError,
    ValidationError,
    InvalidScopeError,
)

from .protocols import (
    SettingsStorage,
    SettingValidator,
    SettingsAuditProvider,
    SettingsCacheProvider,
)

from .schemas import (
    SettingDTO,
    SettingCreate,
    SettingUpdate,
    SettingFilter,
    SettingResponse,
    SettingListResponse,
    SettingHistory,
    CategoryDTO,
    BrandingConfig,
    EmailConfig,
    FeatureFlag,
    LimitConfig,
    SettingsExport,
)

from .services import (
    SettingsManager,
    BrandingService,
    FeatureFlagService,
    ValidationService,
)

from .validators import (
    StringValidator,
    IntValidator,
    BoolValidator,
    EnumValidator,
    EmailValidator,
    URLValidator,
    ColorValidator,
    JSONValidator,
)

from .router import create_settings_router

__all__ = [
    # Constants
    "SettingScope",
    "SettingDataType",
    "SettingCategory",
    # Exceptions
    "SettingsError",
    "SettingNotFoundError",
    "ValidationError",
    "InvalidScopeError",
    # Protocols
    "SettingsStorage",
    "SettingValidator",
    "SettingsAuditProvider",
    "SettingsCacheProvider",
    # Schemas
    "SettingDTO",
    "SettingCreate",
    "SettingUpdate",
    "SettingFilter",
    "SettingResponse",
    "SettingListResponse",
    "SettingHistory",
    "CategoryDTO",
    "BrandingConfig",
    "EmailConfig",
    "FeatureFlag",
    "LimitConfig",
    "SettingsExport",
    # Services
    "SettingsManager",
    "BrandingService",
    "FeatureFlagService",
    "ValidationService",
    # Validators
    "StringValidator",
    "IntValidator",
    "BoolValidator",
    "EnumValidator",
    "EmailValidator",
    "URLValidator",
    "ColorValidator",
    "JSONValidator",
    # Router
    "create_settings_router",
]

__version__ = "0.1.0"
