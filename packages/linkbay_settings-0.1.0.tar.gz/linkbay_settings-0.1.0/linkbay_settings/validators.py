"""Built-in validators for settings."""

import re
import json
from typing import Any, Dict, Optional, List
from .exceptions import ValidationError


class BaseValidator:
    """Base validator class."""
    
    def __init__(self):
        self.error_message = ""
    
    def validate(self, value: Any, rules: Optional[Dict[str, Any]] = None) -> bool:
        """Validate value. Override in subclasses."""
        raise NotImplementedError
    
    def get_error_message(self) -> str:
        return self.error_message


class StringValidator(BaseValidator):
    """Validates string values."""
    
    def validate(self, value: Any, rules: Optional[Dict[str, Any]] = None) -> bool:
        if not isinstance(value, str):
            self.error_message = f"Value must be a string, got {type(value).__name__}"
            return False
        
        if rules:
            min_length = rules.get("min_length")
            max_length = rules.get("max_length")
            pattern = rules.get("pattern")
            
            if min_length and len(value) < min_length:
                self.error_message = f"String length must be at least {min_length}"
                return False
            
            if max_length and len(value) > max_length:
                self.error_message = f"String length must not exceed {max_length}"
                return False
            
            if pattern and not re.match(pattern, value):
                self.error_message = f"String does not match required pattern"
                return False
        
        return True


class IntValidator(BaseValidator):
    """Validates integer values."""
    
    def validate(self, value: Any, rules: Optional[Dict[str, Any]] = None) -> bool:
        if not isinstance(value, int) or isinstance(value, bool):
            self.error_message = f"Value must be an integer, got {type(value).__name__}"
            return False
        
        if rules:
            min_value = rules.get("min")
            max_value = rules.get("max")
            
            if min_value is not None and value < min_value:
                self.error_message = f"Value must be at least {min_value}"
                return False
            
            if max_value is not None and value > max_value:
                self.error_message = f"Value must not exceed {max_value}"
                return False
        
        return True


class FloatValidator(BaseValidator):
    """Validates float values."""
    
    def validate(self, value: Any, rules: Optional[Dict[str, Any]] = None) -> bool:
        if not isinstance(value, (int, float)) or isinstance(value, bool):
            self.error_message = f"Value must be a number, got {type(value).__name__}"
            return False
        
        if rules:
            min_value = rules.get("min")
            max_value = rules.get("max")
            
            if min_value is not None and value < min_value:
                self.error_message = f"Value must be at least {min_value}"
                return False
            
            if max_value is not None and value > max_value:
                self.error_message = f"Value must not exceed {max_value}"
                return False
        
        return True


class BoolValidator(BaseValidator):
    """Validates boolean values."""
    
    def validate(self, value: Any, rules: Optional[Dict[str, Any]] = None) -> bool:
        if not isinstance(value, bool):
            self.error_message = f"Value must be a boolean, got {type(value).__name__}"
            return False
        return True


class EnumValidator(BaseValidator):
    """Validates enum values."""
    
    def validate(self, value: Any, rules: Optional[Dict[str, Any]] = None) -> bool:
        if not rules or "allowed_values" not in rules:
            self.error_message = "Enum validation requires 'allowed_values' in rules"
            return False
        
        allowed_values = rules["allowed_values"]
        if value not in allowed_values:
            self.error_message = f"Value must be one of {allowed_values}"
            return False
        
        return True


class EmailValidator(BaseValidator):
    """Validates email addresses."""
    
    EMAIL_PATTERN = re.compile(r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$')
    
    def validate(self, value: Any, rules: Optional[Dict[str, Any]] = None) -> bool:
        if not isinstance(value, str):
            self.error_message = "Email must be a string"
            return False
        
        if not self.EMAIL_PATTERN.match(value):
            self.error_message = "Invalid email format"
            return False
        
        return True


class URLValidator(BaseValidator):
    """Validates URLs."""
    
    URL_PATTERN = re.compile(
        r'^https?://'
        r'(?:(?:[A-Z0-9](?:[A-Z0-9-]{0,61}[A-Z0-9])?\.)+[A-Z]{2,6}\.?|'
        r'localhost|'
        r'\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})'
        r'(?::\d+)?'
        r'(?:/?|[/?]\S+)$', re.IGNORECASE
    )
    
    def validate(self, value: Any, rules: Optional[Dict[str, Any]] = None) -> bool:
        if not isinstance(value, str):
            self.error_message = "URL must be a string"
            return False
        
        if not self.URL_PATTERN.match(value):
            self.error_message = "Invalid URL format"
            return False
        
        return True


class ColorValidator(BaseValidator):
    """Validates hex color codes."""
    
    COLOR_PATTERN = re.compile(r'^#[0-9A-Fa-f]{6}$')
    
    def validate(self, value: Any, rules: Optional[Dict[str, Any]] = None) -> bool:
        if not isinstance(value, str):
            self.error_message = "Color must be a string"
            return False
        
        if not self.COLOR_PATTERN.match(value):
            self.error_message = "Invalid hex color format (must be #RRGGBB)"
            return False
        
        return True


class JSONValidator(BaseValidator):
    """Validates JSON values."""
    
    def validate(self, value: Any, rules: Optional[Dict[str, Any]] = None) -> bool:
        # If value is already dict/list, it's valid JSON
        if isinstance(value, (dict, list)):
            return True
        
        # If string, try to parse as JSON
        if isinstance(value, str):
            try:
                json.loads(value)
                return True
            except json.JSONDecodeError as e:
                self.error_message = f"Invalid JSON: {str(e)}"
                return False
        
        self.error_message = f"Value must be JSON (dict, list, or JSON string), got {type(value).__name__}"
        return False
