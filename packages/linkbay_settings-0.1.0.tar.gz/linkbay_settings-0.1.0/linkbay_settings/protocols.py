"""Protocol definitions for settings management."""

from typing import Protocol, Dict, Any, List, Optional
from datetime import datetime


class SettingsStorage(Protocol):
    """
    Protocol for settings persistence.
    
    User implements with their database (PostgreSQL, MongoDB, etc.).
    """
    
    async def get_setting(
        self,
        key: str,
        tenant_id: str,
        user_id: Optional[str] = None,
        scope: str = "tenant",
    ) -> Optional[Dict[str, Any]]:
        """Get setting by key and scope."""
        ...
    
    async def set_setting(
        self,
        setting_data: Dict[str, Any],
    ) -> Dict[str, Any]:
        """Create or update setting."""
        ...
    
    async def delete_setting(
        self,
        key: str,
        tenant_id: str,
        user_id: Optional[str] = None,
        scope: str = "tenant",
    ) -> bool:
        """Delete setting."""
        ...
    
    async def list_settings(
        self,
        tenant_id: str,
        scope: str = "tenant",
        category: Optional[str] = None,
        user_id: Optional[str] = None,
    ) -> List[Dict[str, Any]]:
        """List settings by scope and optional filters."""
        ...
    
    async def get_platform_default(
        self,
        key: str,
    ) -> Optional[Dict[str, Any]]:
        """Get platform-wide default setting."""
        ...


class SettingValidator(Protocol):
    """
    Protocol for setting validation.
    
    Validates setting values against rules/schema.
    """
    
    def validate(
        self,
        value: Any,
        data_type: str,
        validation_rules: Optional[Dict[str, Any]] = None,
    ) -> bool:
        """Validate value against data type and rules."""
        ...
    
    def get_error_message(self) -> str:
        """Get validation error message."""
        ...


class SettingsAuditProvider(Protocol):
    """
    Protocol for settings audit logging.
    
    Tracks who changed what, when.
    """
    
    async def log_change(
        self,
        key: str,
        tenant_id: str,
        user_id: str,
        old_value: Any,
        new_value: Any,
        scope: str,
    ) -> Dict[str, Any]:
        """Log setting change."""
        ...
    
    async def get_history(
        self,
        key: str,
        tenant_id: str,
        limit: int = 100,
    ) -> List[Dict[str, Any]]:
        """Get change history for setting."""
        ...
    
    async def get_version(
        self,
        key: str,
        tenant_id: str,
        version: int,
    ) -> Optional[Dict[str, Any]]:
        """Get specific version of setting."""
        ...


class SettingsCacheProvider(Protocol):
    """
    Protocol for settings caching.
    
    Caches resolved settings for performance.
    """
    
    async def get(
        self,
        cache_key: str,
    ) -> Optional[Any]:
        """Get cached value."""
        ...
    
    async def set(
        self,
        cache_key: str,
        value: Any,
        ttl: int,
    ) -> bool:
        """Set cached value with TTL."""
        ...
    
    async def delete(
        self,
        cache_key: str,
    ) -> bool:
        """Delete cached value."""
        ...
    
    async def invalidate_pattern(
        self,
        pattern: str,
    ) -> int:
        """Invalidate all keys matching pattern."""
        ...
