"""FastAPI router for settings management."""

from typing import Optional, List
from fastapi import APIRouter, Depends, HTTPException, status

from .protocols import (
    SettingsStorage,
    SettingsAuditProvider,
    SettingsCacheProvider,
)
from .schemas import (
    SettingDTO,
    SettingCreate,
    SettingUpdate,
    SettingFilter,
    SettingResponse,
    SettingListResponse,
    SettingHistory,
    CategoryDTO,
    BrandingConfig,
    EmailConfig,
    FeatureFlag,
    LimitConfig,
    SettingsExport,
    SettingsImportRequest,
    CloneSettingsRequest,
)
from .services import (
    SettingsManager,
    BrandingService,
    FeatureFlagService,
    ValidationService,
)
from .constants import SettingScope, SettingCategory
from .exceptions import SettingNotFoundError, ValidationError


def create_settings_router(
    storage: SettingsStorage,
    validation_service: ValidationService,
    audit_provider: Optional[SettingsAuditProvider] = None,
    cache_provider: Optional[SettingsCacheProvider] = None,
    prefix: str = "/settings",
) -> APIRouter:
    """
    Create FastAPI router for settings management.
    
    Args:
        storage: Settings storage implementation
        validation_service: Validation service
        audit_provider: Optional audit provider
        cache_provider: Optional cache provider
        prefix: Router prefix
    
    Returns:
        Configured APIRouter
    """
    router = APIRouter(prefix=prefix, tags=["settings"])
    
    # Initialize services
    settings_manager = SettingsManager(
        storage=storage,
        validation_service=validation_service,
        audit_provider=audit_provider,
        cache_provider=cache_provider,
    )
    branding_service = BrandingService(storage=storage)
    feature_flag_service = FeatureFlagService(storage=storage)
    
    # TENANT SETTINGS ENDPOINTS
    
    @router.get("/{tenant_id}/settings/{key}", response_model=SettingResponse)
    async def get_setting(
        tenant_id: str,
        key: str,
        user_id: Optional[str] = None,
    ):
        """Get setting with hierarchical resolution."""
        try:
            resolved = await settings_manager.resolve_setting(
                key=key,
                tenant_id=tenant_id,
                user_id=user_id,
            )
            
            # Get full setting metadata
            setting = await settings_manager.get_setting(
                key=key,
                tenant_id=tenant_id,
                user_id=user_id,
            )
            
            return SettingResponse(
                setting=setting,
                effective_value=resolved["value"],
                precedence_chain=resolved["precedence_chain"],
            )
        except SettingNotFoundError as e:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=str(e),
            )
    
    @router.post("/{tenant_id}/settings", response_model=SettingDTO)
    async def create_setting(
        tenant_id: str,
        setting: SettingCreate,
        user_id: Optional[str] = None,
        updated_by: str = "system",
    ):
        """Create or update setting."""
        try:
            return await settings_manager.set_setting(
                key=setting.key,
                value=setting.value,
                tenant_id=tenant_id,
                user_id=user_id,
                setting_create=setting,
                updated_by=updated_by,
            )
        except ValidationError as e:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=str(e),
            )
    
    @router.put("/{tenant_id}/settings/{key}", response_model=SettingDTO)
    async def update_setting(
        tenant_id: str,
        key: str,
        update: SettingUpdate,
        user_id: Optional[str] = None,
        updated_by: str = "system",
    ):
        """Update setting value."""
        try:
            # Get existing setting
            existing = await settings_manager.get_setting(
                key=key,
                tenant_id=tenant_id,
                user_id=user_id,
            )
            
            # Create update
            setting_create = SettingCreate(
                key=key,
                value=update.value,
                scope=existing.scope,
                data_type=existing.data_type,
                default_value=existing.default_value,
                validation_schema=existing.validation_schema,
                category=existing.category,
                description=update.description or existing.description,
                is_sensitive=existing.is_sensitive,
            )
            
            return await settings_manager.set_setting(
                key=key,
                value=update.value,
                tenant_id=tenant_id,
                user_id=user_id,
                setting_create=setting_create,
                updated_by=updated_by,
            )
        except SettingNotFoundError as e:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=str(e),
            )
        except ValidationError as e:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=str(e),
            )
    
    @router.delete("/{tenant_id}/settings/{key}", status_code=status.HTTP_204_NO_CONTENT)
    async def delete_setting(
        tenant_id: str,
        key: str,
        user_id: Optional[str] = None,
    ):
        """Delete setting."""
        deleted = await settings_manager.delete_setting(
            key=key,
            tenant_id=tenant_id,
            user_id=user_id,
        )
        
        if not deleted:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Setting '{key}' not found",
            )
    
    @router.get("/{tenant_id}/settings", response_model=SettingListResponse)
    async def list_settings(
        tenant_id: str,
        scope: Optional[SettingScope] = None,
        category: Optional[SettingCategory] = None,
        data_type: Optional[str] = None,
        search_query: Optional[str] = None,
        user_id: Optional[str] = None,
    ):
        """List settings with filters."""
        filters = SettingFilter(
            scope=scope,
            category=category,
            data_type=data_type,
            search_query=search_query,
        )
        
        settings = await settings_manager.list_settings(
            tenant_id=tenant_id,
            filters=filters,
            user_id=user_id,
        )
        
        return SettingListResponse(
            settings=settings,
            total=len(settings),
        )
    
    # BRANDING ENDPOINTS
    
    @router.get("/{tenant_id}/branding", response_model=BrandingConfig)
    async def get_branding(tenant_id: str):
        """Get tenant branding configuration."""
        return await branding_service.get_branding(tenant_id=tenant_id)
    
    @router.put("/{tenant_id}/branding", response_model=BrandingConfig)
    async def update_branding(
        tenant_id: str,
        branding: BrandingConfig,
        updated_by: str = "system",
    ):
        """Update tenant branding."""
        return await branding_service.update_branding(
            tenant_id=tenant_id,
            branding_config=branding,
            updated_by=updated_by,
        )
    
    # FEATURE FLAGS ENDPOINTS
    
    @router.get("/{tenant_id}/features/{feature_key}", response_model=dict)
    async def check_feature(tenant_id: str, feature_key: str):
        """Check if feature is enabled."""
        enabled = await feature_flag_service.is_feature_enabled(
            feature_key=feature_key,
            tenant_id=tenant_id,
        )
        return {"feature_key": feature_key, "enabled": enabled}
    
    @router.post("/{tenant_id}/features/{feature_key}/enable", response_model=FeatureFlag)
    async def enable_feature(
        tenant_id: str,
        feature_key: str,
        updated_by: str = "system",
        requires_plan: Optional[str] = None,
    ):
        """Enable feature for tenant."""
        return await feature_flag_service.enable_feature(
            feature_key=feature_key,
            tenant_id=tenant_id,
            updated_by=updated_by,
            requires_plan=requires_plan,
        )
    
    @router.post("/{tenant_id}/features/{feature_key}/disable", response_model=FeatureFlag)
    async def disable_feature(
        tenant_id: str,
        feature_key: str,
        updated_by: str = "system",
    ):
        """Disable feature for tenant."""
        return await feature_flag_service.disable_feature(
            feature_key=feature_key,
            tenant_id=tenant_id,
            updated_by=updated_by,
        )
    
    @router.get("/{tenant_id}/features", response_model=List[FeatureFlag])
    async def list_features(tenant_id: str):
        """List all feature flags."""
        return await feature_flag_service.list_features(tenant_id=tenant_id)
    
    # LIMITS ENDPOINTS
    
    @router.get("/{tenant_id}/limits/{limit_key}", response_model=LimitConfig)
    async def get_limit(
        tenant_id: str,
        limit_key: str,
        current_usage: Optional[int] = None,
    ):
        """Get limit configuration."""
        limit_value = await feature_flag_service.get_limit(
            limit_key=limit_key,
            tenant_id=tenant_id,
        )
        
        if limit_value is None:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Limit '{limit_key}' not found",
            )
        
        return LimitConfig(
            key=limit_key,
            limit_value=limit_value,
            current_usage=current_usage,
        )
    
    @router.post("/{tenant_id}/limits/{limit_key}/check", response_model=dict)
    async def check_limit(
        tenant_id: str,
        limit_key: str,
        current_usage: int,
    ):
        """Check if within limit."""
        within_limit = await feature_flag_service.check_limit(
            limit_key=limit_key,
            tenant_id=tenant_id,
            current_usage=current_usage,
        )
        
        return {
            "limit_key": limit_key,
            "current_usage": current_usage,
            "within_limit": within_limit,
        }
    
    # AUDIT & HISTORY ENDPOINTS
    
    @router.get("/{tenant_id}/settings/{key}/history", response_model=List[SettingHistory])
    async def get_setting_history(
        tenant_id: str,
        key: str,
        limit: int = 100,
    ):
        """Get setting change history."""
        return await settings_manager.get_setting_history(
            key=key,
            tenant_id=tenant_id,
            limit=limit,
        )
    
    @router.post("/{tenant_id}/settings/{key}/revert", response_model=SettingDTO)
    async def revert_setting(
        tenant_id: str,
        key: str,
        version: int,
        updated_by: str = "system",
    ):
        """Revert setting to specific version."""
        try:
            return await settings_manager.revert_setting(
                key=key,
                tenant_id=tenant_id,
                version=version,
                updated_by=updated_by,
            )
        except SettingNotFoundError as e:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=str(e),
            )
    
    # EXPORT/IMPORT ENDPOINTS
    
    @router.get("/{tenant_id}/export", response_model=SettingsExport)
    async def export_settings(tenant_id: str):
        """Export all tenant settings."""
        return await settings_manager.export_settings(tenant_id=tenant_id)
    
    @router.post("/{tenant_id}/import", response_model=dict)
    async def import_settings(
        tenant_id: str,
        import_request: SettingsImportRequest,
        updated_by: str = "system",
    ):
        """Import settings."""
        count = await settings_manager.import_settings(
            tenant_id=tenant_id,
            settings=import_request.settings,
            updated_by=updated_by,
            overwrite_existing=import_request.overwrite_existing,
        )
        
        return {"imported_count": count}
    
    @router.post("/{tenant_id}/clone", response_model=dict)
    async def clone_settings(
        tenant_id: str,
        clone_request: CloneSettingsRequest,
        updated_by: str = "system",
    ):
        """Clone settings from template tenant."""
        count = await settings_manager.clone_settings(
            source_tenant_id=clone_request.source_tenant_id,
            target_tenant_id=tenant_id,
            updated_by=updated_by,
            overwrite_existing=clone_request.overwrite_existing,
        )
        
        return {"cloned_count": count}
    
    return router
