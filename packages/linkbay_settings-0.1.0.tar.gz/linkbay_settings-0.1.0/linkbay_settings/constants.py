"""Constants for settings management."""

from enum import Enum


class SettingScope(str, Enum):
    """Setting scope hierarchy."""
    PLATFORM = "platform"  # Platform-wide defaults
    TENANT = "tenant"      # Tenant overrides
    USER = "user"          # User preferences


class SettingDataType(str, Enum):
    """Setting data types."""
    STRING = "string"
    INTEGER = "integer"
    FLOAT = "float"
    BOOLEAN = "boolean"
    JSON = "json"
    ENUM = "enum"
    EMAIL = "email"
    URL = "url"
    COLOR = "color"


class SettingCategory(str, Enum):
    """Setting categories for organization."""
    GENERAL = "general"
    BRANDING = "branding"
    EMAIL = "email"
    NOTIFICATIONS = "notifications"
    PAYMENT = "payment"
    FEATURES = "features"
    LIMITS = "limits"
    INTEGRATIONS = "integrations"
    SECURITY = "security"
    LOCALIZATION = "localization"


# Default cache TTL (seconds)
DEFAULT_CACHE_TTL = 300  # 5 minutes

# Setting key prefixes
BRANDING_PREFIX = "branding."
EMAIL_PREFIX = "email."
FEATURE_PREFIX = "feature."
LIMIT_PREFIX = "limit."
NOTIFICATION_PREFIX = "notification."

# Common setting keys
COMMON_SETTINGS = {
    # Branding
    "branding.logo_url": {"type": SettingDataType.URL, "category": SettingCategory.BRANDING},
    "branding.primary_color": {"type": SettingDataType.COLOR, "category": SettingCategory.BRANDING},
    "branding.secondary_color": {"type": SettingDataType.COLOR, "category": SettingCategory.BRANDING},
    "branding.font_family": {"type": SettingDataType.STRING, "category": SettingCategory.BRANDING},
    "branding.favicon_url": {"type": SettingDataType.URL, "category": SettingCategory.BRANDING},
    "branding.company_name": {"type": SettingDataType.STRING, "category": SettingCategory.BRANDING},
    
    # Email
    "email.smtp_host": {"type": SettingDataType.STRING, "category": SettingCategory.EMAIL},
    "email.smtp_port": {"type": SettingDataType.INTEGER, "category": SettingCategory.EMAIL},
    "email.smtp_user": {"type": SettingDataType.STRING, "category": SettingCategory.EMAIL},
    "email.from_email": {"type": SettingDataType.EMAIL, "category": SettingCategory.EMAIL},
    "email.from_name": {"type": SettingDataType.STRING, "category": SettingCategory.EMAIL},
    
    # Features
    "feature.enable_ai": {"type": SettingDataType.BOOLEAN, "category": SettingCategory.FEATURES},
    "feature.enable_multi_currency": {"type": SettingDataType.BOOLEAN, "category": SettingCategory.FEATURES},
    "feature.enable_api_access": {"type": SettingDataType.BOOLEAN, "category": SettingCategory.FEATURES},
    
    # Limits
    "limit.max_products": {"type": SettingDataType.INTEGER, "category": SettingCategory.LIMITS},
    "limit.max_users": {"type": SettingDataType.INTEGER, "category": SettingCategory.LIMITS},
    "limit.max_storage_gb": {"type": SettingDataType.INTEGER, "category": SettingCategory.LIMITS},
}
