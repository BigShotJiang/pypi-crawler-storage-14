"""FastBlocks style adapters."""
