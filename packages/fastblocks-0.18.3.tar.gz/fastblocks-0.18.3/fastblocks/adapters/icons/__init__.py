"""FastBlocks icon adapters."""
