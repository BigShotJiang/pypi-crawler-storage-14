"""FastBlocks auth adapters."""
