from acb.config import AdapterBase, Settings


class RoutesBaseSettings(Settings): ...


class RoutesBase(AdapterBase): ...
