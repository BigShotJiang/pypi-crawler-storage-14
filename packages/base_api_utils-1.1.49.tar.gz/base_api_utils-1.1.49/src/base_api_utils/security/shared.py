import re

from django.contrib.admindocs.views import simplify_regex

_PATH_PARAMETER_COMPONENT_RE = re.compile(
    r'<(?:(?P<converter>[^>:]+):)?(?P<parameter>\w+)>'
)

def get_path(request) -> str:
    path = simplify_regex(request.resolver_match.route)
    # Strip Django 2.0 convertors as they are incompatible with uritemplate format
    path = re.sub(_PATH_PARAMETER_COMPONENT_RE, r'{\g<parameter>}', path)
    return path.replace('{pk}', '{id}')

client_secret_basic_auth_method = 'client_secret_basic'

application_type_service = 'SERVICE'

def get_user_role(token_info):
    """
    Determines the user's role based on their groups.

    Args:
    token_info (dict): Dictionary with authz information including 'user_groups'

    Returns:
    str: 'super-admin', 'admin', or 'user'
    """
    user_groups = token_info.get('user_groups', [])
    group_slugs = {group['slug'] for group in user_groups}

    if 'super-admins' in group_slugs:
        return 'super-admin'
    elif 'administrators' in group_slugs:
        return 'admin'
    else:
        return 'user'

def is_admin(token_info):
    """
    Checks if the user has administrator privileges (admin or super-admin).

    Args:
    token_info (dict): Dictionary with authz information

    Returns:
    bool: True if admin or super-admin, False otherwise
    """
    role = get_user_role(token_info)
    return role in ('admin', 'super-admin')