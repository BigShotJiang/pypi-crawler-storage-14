
# weather_capability_v7.py
from __future__ import annotations
import os, re, json, requests
from typing import Dict, Any, List, Optional, AsyncGenerator, Tuple
from tvi.solphit.base.logging import SolphitLogger

# Optional LLM (ingialla)
try:
    from tvi.solphit.ingialla.ask import Generator
    _HAS_LLM = True
except Exception:
    _HAS_LLM = False

log = SolphitLogger.get_logger("discera.capabilities.weather")

# ---------- External HTTP helpers ----------
def _http_json(url: str, *, timeout: float = 20.0) -> Dict[str, Any]:
    r = requests.get(url, timeout=timeout)
    r.raise_for_status()
    return r.json() or {}

# ---------- Ollama fallback ----------
def _ollama_base_url() -> str:
    return os.getenv("OLLAMA_BASE_URL", "http://localhost:11434").rstrip("/")

def _ollama_generate(*, prompt: str, model: str = "llama3.2:3b") -> str:
    url = f"{_ollama_base_url()}/api/generate"
    body = {"model": model, "prompt": prompt, "stream": False}
    r = requests.post(url, json=body, timeout=60)
    r.raise_for_status()
    data = r.json() or {}
    text = str(data.get("response", "")).strip()
    if not text:
        msg = data.get("message") or data.get("error") or ""
        raise RuntimeError(f"Ollama /api/generate returned empty response. {msg}")
    return text

# ---------- Weather code dictionary (WMO) ----------
# Source: WMO codes (simplified most-common values)
WMO = {
    0: "Clear sky",
    1: "Mainly clear", 2: "Partly cloudy", 3: "Overcast",
    45: "Fog", 48: "Depositing rime fog",
    51: "Light drizzle", 53: "Moderate drizzle", 55: "Dense drizzle",
    56: "Light freezing drizzle", 57: "Dense freezing drizzle",
    61: "Slight rain", 63: "Moderate rain", 65: "Heavy rain",
    66: "Light freezing rain", 67: "Heavy freezing rain",
    71: "Slight snow", 73: "Moderate snow", 75: "Heavy snow",
    77: "Snow grains",
    80: "Slight rain showers", 81: "Moderate rain showers", 82: "Violent rain showers",
    85: "Slight snow showers", 86: "Heavy snow showers",
    95: "Thunderstorm", 96: "Thunderstorm with slight hail", 99: "Thunderstorm with heavy hail",
}

def _wmo_label(code: Optional[int]) -> str:
    try:
        return WMO.get(int(code), f"Weather code {code}")
    except Exception:
        return "Unknown"

# ---------- Query extraction ----------
def _extract_query_with_llm(q: str, *, provider: str, model: str) -> Dict[str, Any]:
    """
    Ask LLM to turn free text into structured weather query:
    { location: str, days: int, start: 'YYYY-MM-DD'|null, units: 'metric'|'imperial' }
    """
    system = (
        "You extract weather query parameters from the user's text. "
        "Return strict JSON with keys: location (string), days (int), start (string or null), units ('metric'|'imperial'). "
        "If not specified, infer sensible defaults: location from text, days=3, start=null, units='metric'. "
        "Do not include any extra keys; return only a single JSON object."
    )
    prompt = f"{system}\n\nUSER:\n{q}"
    if _HAS_LLM:
        try:
            gen = Generator(provider=provider, model=model, verbose=False)
            txt = gen.generate(prompt, contexts=[], history=[]) or ""
            obj = json.loads(_extract_json_block(txt))
            return _normalize_query_obj(obj)
        except Exception as e:
            log.warning(f"[weather] LLM extract failed; falling back to regex: {e}")
    else:
        try:
            txt = _ollama_generate(prompt=prompt, model=model)
            obj = json.loads(_extract_json_block(txt))
            return _normalize_query_obj(obj)
        except Exception as e:
            log.warning(f"[weather] Ollama extract failed; falling back to regex: {e}")
    return _extract_query_with_regex(q)

def _extract_json_block(text: str) -> str:
    """
    Find the first {...} JSON object in text; if none, return text (may throw in json.loads).
    """
    m = re.search(r"\{[\s\S]*\}", text)
    return m.group(0) if m else text

def _extract_query_with_regex(q: str) -> Dict[str, Any]:
    q = (q or "").strip()
    # Location: text after 'in ' or 'for ' until punctuation or end
    loc = None
    m = re.search(r"\b(?:in|for)\s+([A-Za-z0-9\-\.\,\s]+)", q)
    if m:
        loc = m.group(1).strip().rstrip(".")
    # Days: 'next N days' or 'N-day'
    days = None
    m = re.search(r"next\s+(\d{1,2})\s+days", q, flags=re.I)
    if m:
        days = int(m.group(1))
    m = m or re.search(r"(\d{1,2})\s*-\s*day", q, flags=re.I)
    if not m and not days:
        m = re.search(r"(\d{1,2})\s*day(s)?", q, flags=re.I)
        if m:
            days = int(m.group(1))
    # Units: celsius/metric or fahrenheit/imperial
    units = "metric"
    if re.search(r"\b(fahrenheit|imperial|°f)\b", q, flags=re.I):
        units = "imperial"

    # Defaults
    location = loc or "New York"
    d = max(1, min(int(days or 3), 14))  # allow up to 14 for future-proof; API limits will clamp
    return {"location": location, "days": d, "start": None, "units": units}

def _normalize_query_obj(obj: Dict[str, Any]) -> Dict[str, Any]:
    location = str(obj.get("location") or "").strip() or "New York"
    days = int(obj.get("days") or 3)
    days = max(1, min(days, 14))
    start = obj.get("start")
    if isinstance(start, str):
        start = start.strip() or None
    units = str(obj.get("units") or "metric").strip().lower()
    units = "imperial" if units.startswith("imp") or "f" in units else "metric"
    return {"location": location, "days": days, "start": start, "units": units}

# ---------- Formatting ----------
def _fmt_units(units: str) -> Tuple[str, str]:
    # temperature unit, precip unit
    if units == "imperial":
        return ("°F", "in")
    return ("°C", "mm")

def _mm_to_in(mm: float) -> float:
    return round(mm / 25.4, 2)

def _fmt_day_line(date: str, tmin_c: float, tmax_c: float, precip_mm: float, code: int, *, units: str) -> str:
    label = _wmo_label(code)
    t_unit, p_unit = _fmt_units(units)
    if units == "imperial":
        # Open-Meteo returns Celsius; convert to Fahrenheit: F = C*9/5 + 32
        tmin = round(tmin_c * 9 / 5 + 32, 1)
        tmax = round(tmax_c * 9 / 5 + 32, 1)
        precip = _mm_to_in(precip_mm)
    else:
        tmin, tmax, precip = round(tmin_c, 1), round(tmax_c, 1), round(precip_mm, 1)
    return f"- **{date}**: {label}; low **{tmin}{t_unit}**, high **{tmax}{t_unit}**; precip **{precip}{p_unit}**."

def _chunk_text(s: str, max_len: int = 96) -> List[str]:
    out: List[str] = []
    buf = (s or "").strip()
    while buf:
        out.append(buf[:max_len])
        buf = buf[max_len:]
    return out

# ---------- Capability ----------
class WeatherCapability:
    name = "weather"

    @staticmethod
    def descriptor() -> Dict[str, Any]:
        return {
            "name": "weather",
            "description": (
                "Answers weather questions with up-to-date multi‑day forecasts for any location; "
                "supports human‑friendly summaries and unit selection."
            ),
            "intents": ["weather_forecast", "current_weather", "weather_trend"],
            "examples": [
                "What's the weather in Ferndale, MI for the next 3 days?",
                "Temperature and rain outlook for Amsterdam this week (in Fahrenheit).",
                "Is it likely to snow in Denver tomorrow?"
            ],
            "tags": ["weather", "forecast", "trend", "current", "location", "temperature", "precipitation"],
            "excludes": ["climate", "historical", "koppen"],
        }

    @staticmethod
    def assets() -> Dict[str, List[str]]:
        # Optional minimal CSS to improve readability (safe)
        css = r"""
.discera .weather-summary { margin-top: 6px; }
.discera .weather-summary .lead { color: #9ca3af; }
"""
        return {"css": [css], "js": []}

    def run_once(self, args: Any, **kwargs) -> Dict[str, Any]:
        q: str = (getattr(args, "question", None) or (args.get("question") if isinstance(args, dict) else "") or "").strip()
        hints: Dict[str, Any] = kwargs.get("hints") or {}

        provider = hints.get("provider") or "ollama"
        model = hints.get("model") or os.getenv("WEATHER_EXTRACT_MODEL", "llama3.2:3b")

        # 1) Extract structured query
        params = _extract_query_with_llm(q, provider=provider, model=model)
        location, days, start, units = params["location"], params["days"], params["start"], params["units"]

        # 2) Geocode
        try:
            geo = _http_json(f"https://geocoding-api.open-meteo.com/v1/search?name={requests.utils.quote(location)}&count=1")
        except Exception as ex:
            answer = f"Sorry, I couldn't reach the geocoding service ({ex})."
            return {"answer": answer, "contexts": [], "meta": {"capability": self.name, "location": location}}

        if not geo.get("results"):
            answer = f"Sorry, I couldn't find the location **{location}**."
            return {"answer": answer, "contexts": ["https://open-meteo.com/en/docs"], "meta": {"capability": self.name, "location": location}}

        lat = float(geo["results"][0]["latitude"])
        lon = float(geo["results"][0]["longitude"])
        resolved_name = geo["results"][0].get("name") or location
        admin = geo["results"][0].get("admin1") or ""
        country = geo["results"][0].get("country") or ""

        # 3) Forecast (daily)
        base_url = ("https://api.open-meteo.com/v1/forecast"
                    f"?latitude={lat}&longitude={lon}"
                    "&daily=temperature_2m_max,temperature_2m_min,precipitation_sum,weathercode"
                    f"&forecast_days={days}&timezone=auto")
        if start:
            base_url += f"&start_date={start}"
        try:
            weather = _http_json(base_url)
        except Exception as ex:
            answer = f"Sorry, I couldn't reach the forecast service ({ex})."
            return {"answer": answer, "contexts": [base_url, "https://open-meteo.com/en/docs"], "meta": {"capability": self.name, "location": location}}

        daily = weather.get("daily", {})
        dates: List[str] = daily.get("time", []) or []
        tmax: List[float] = daily.get("temperature_2m_max", []) or []
        tmin: List[float] = daily.get("temperature_2m_min", []) or []
        precip: List[float] = daily.get("precipitation_sum", []) or []
        codes: List[int] = daily.get("weathercode", []) or []

        if not dates:
            answer = f"I couldn't find forecast data for **{resolved_name}**."
            return {"answer": answer, "contexts": [base_url, "https://open-meteo.com/en/docs"], "meta": {"capability": self.name, "location": resolved_name}}

        # 4) Build human‑friendly summary
        header_loc = f"{resolved_name}" + (f", {admin}" if admin else "") + (f", {country}" if country else "")
        t_unit, p_unit = _fmt_units(units)
        lines = [f"**{header_loc}** · Next **{min(days, len(dates))}** day(s) · Units **{t_unit}/{p_unit}**"]
        for i in range(min(days, len(dates))):
            lines.append(_fmt_day_line(dates[i], tmin[i], tmax[i], precip[i], codes[i], units=units))

        answer = "\n".join(lines)

        meta = {
            "capability": self.name,
            "location": header_loc,
            "query": {"location": location, "days": days, "start": start, "units": units},
            "lat": lat, "lon": lon,
            "forecast_days": min(days, len(dates)),
        }
        contexts = [base_url, "https://open-meteo.com/en/docs"]

        return {"answer": answer, "contexts": contexts, "meta": meta}

    async def run_stream(self, args: Any, **kwargs) -> AsyncGenerator[dict, None]:
        result = self.run_once(args, **kwargs)
        text = result.get("answer", "")
        yield {"event": "generation_started", "data": {"capability": self.name}}
        for chunk in _chunk_text(text, max_len=96):
            yield {"event": "token", "data": chunk}
        # contexts (optional streaming; keep brief)
        if (result.get("contexts") or []):
            yield {"event": "context", "data": {"items": result["contexts"]}}
        yield {"event": "generation_done", "data": {}}
        yield {"event": "done", "data": {}}

def register(registry):  # entry-point plugin function
    registry.register(WeatherCapability())
