"""
pyg_lib - A Python package library
"""

__version__ = "0.1.0"
__author__ = "Your Name"
__email__ = "your.email@example.com"

def hello():
    """A simple hello function."""
    return "Hello from pyg_lib!"

