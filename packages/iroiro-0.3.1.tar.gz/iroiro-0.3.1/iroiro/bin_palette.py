from . import bin

def main():
    bin.rainbow.main()
