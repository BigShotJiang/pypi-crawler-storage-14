# Allow importing the ModelAdmin mixin directly from the root app.
from changeform_actions.admin import ChangeFormActionsMixin
