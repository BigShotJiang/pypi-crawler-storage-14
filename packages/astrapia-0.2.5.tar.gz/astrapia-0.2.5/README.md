# Astrapia
[![Test & Build](https://github.com/Tensor46/astrapia/actions/workflows/python-package.yml/badge.svg?branch=main)](https://github.com/Tensor46/astrapia/actions/workflows/python-package.yml)

ML Inference Library with CoreML and ONNXRunTime backends.

## Examples
### MediaPipe
MediaPipe face detector (short & long) and face mesh landmark models in both CoreML and ONNXRunTime are added.