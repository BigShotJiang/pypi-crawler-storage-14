__all__ = ["detector", "mesh"]

from astrapia.examples.mediapipe import detector, mesh
