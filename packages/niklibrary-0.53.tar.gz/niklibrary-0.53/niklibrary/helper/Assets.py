from nikassets.helper.Assets import Assets as AssetsSuper


class Assets(AssetsSuper):
    pass