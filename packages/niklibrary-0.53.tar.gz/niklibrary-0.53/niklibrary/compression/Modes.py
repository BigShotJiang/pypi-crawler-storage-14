class Modes:
    TAR_XZ = ".tar.xz"
    ZIP = ".zip"
    DEFAULT = ZIP
