import pykimix.mix
import pykimix.integration
import pykimix.pygame_surface
import pykimix.bridge

# UI / Input
from .joystick import Joystick
from .button import Button

# Expose main classes/functions
Bridge = pykimix.bridge.Bridge
BridgeConfig = pykimix.bridge.BridgeConfig
PygameWidget = pykimix.pygame_surface.PygameWidget
PygameSurface = pykimix.pygame_surface.PygameSurface
start_loop = pykimix.integration.start_loop
create_surface = pykimix.mix.create_surface
fill_surface = pykimix.mix.fill_surface

# Everything in pykimix namespace
__all__ = [
    "Bridge",
    "BridgeConfig",
    "PygameWidget",
    "PygameSurface",
    "start_loop",
    "create_surface",
    "fill_surface",
    "Joystick",
    "Button"
]