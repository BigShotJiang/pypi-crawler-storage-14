import pygame

def create_surface(width, height):
    return pygame.Surface((width, height))

def fill_surface(surface, color=(0,0,0)):
    surface.fill(color)