from kivy.uix.widget import Widget
from kivy.graphics import Color, Ellipse
from kivy.core.window import Window

class Button(Widget):
    def __init__(self, label="BTN", size=120, pos=(0, 0), **kwargs):
        super().__init__(**kwargs)
        self.label = label
        self.size = (size, size)
        self.pos = pos
        self.pressed = False
        self.draw()

    def draw(self):
        self.canvas.clear()
        with self.canvas:
            Color(0.2, 0.2, 0.2, 0.7)  # shadow base
            Ellipse(size=self.size, pos=self.pos)
            Color(0.9, 0.1, 0.1, 0.8)  # red styled button
            Ellipse(size=(self.size[0]-20, self.size[1]-20),
                    pos=(self.pos[0]+10, self.pos[1]+10))

    def on_touch_down(self, touch):
        if self.collide_point(*touch.pos):
            self.pressed = True
            return True
        return False

    def on_touch_up(self, touch):
        if self.pressed:
            self.pressed = False
            return True
        return False