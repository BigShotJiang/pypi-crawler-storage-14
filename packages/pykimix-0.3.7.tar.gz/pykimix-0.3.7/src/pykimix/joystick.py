from kivy.uix.widget import Widget
from kivy.graphics import Color, Ellipse, Ellipse
from kivy.core.window import Window
from kivy.clock import Clock
from math import sqrt

class Joystick(Widget):
    def __init__(self, size=150, pos=(50, 50), knob_size=60, **kwargs):
        super().__init__(**kwargs)
        self.size = (size, size)
        self.pos = pos
        self.knob_size = knob_size
        self.knob_pos = (self.center_x, self.center_y)
        self.x = 0   # joystick X value (-1 to 1)
        self.y = 0   # joystick Y value (-1 to 1)
        self._touch = None

        self.draw()
        Clock.schedule_interval(lambda dt: self.draw(), 1/60)

    def draw(self):
        self.canvas.clear()
        cx, cy = self.center
        with self.canvas:
            # Outer circle (base)
            Color(0.3, 0.3, 0.3, 0.6)
            Ellipse(size=self.size, pos=self.pos)
            # Inner knob (glowing)
            Color(1, 0.3, 0.3, 0.8)
            knob_x = self.knob_pos[0] - self.knob_size / 2
            knob_y = self.knob_pos[1] - self.knob_size / 2
            Ellipse(size=(self.knob_size, self.knob_size), pos=(knob_x, knob_y))

    def on_touch_down(self, touch):
        if self.collide_point(*touch.pos):
            self._touch = touch
            self.update_knob(touch.pos)
            return True
        return False

    def on_touch_move(self, touch):
        if touch is self._touch:
            self.update_knob(touch.pos)
            return True
        return False

    def on_touch_up(self, touch):
        if touch is self._touch:
            self._touch = None
            # Return knob to center
            self.knob_pos = (self.center_x, self.center_y)
            self.x = 0
            self.y = 0
            return True
        return False

    def update_knob(self, pos):
        cx, cy = self.center
        dx = pos[0] - cx
        dy = pos[1] - cy
        radius = self.width / 2

        # Limit knob to circle radius
        dist = sqrt(dx*dx + dy*dy)
        if dist > radius:
            scale = radius / dist
            dx *= scale
            dy *= scale

        self.knob_pos = (cx + dx, cy + dy)
        self.x = dx / radius
        self.y = dy / radius