# soccernetpro/datasets/builder.py
from .classification_dataset import ClassificationDataset
# from .spotting_dataset import SpottingDataset

def build_dataset(config, annotation_file, processor, split="train"):
    """Return a dataset instance based on model type"""
    task = config.TASK.lower()
    if "classification" in task:
        return ClassificationDataset(config, annotation_file, processor, split=split)
    else:
        raise ValueError(f"No dataset")
