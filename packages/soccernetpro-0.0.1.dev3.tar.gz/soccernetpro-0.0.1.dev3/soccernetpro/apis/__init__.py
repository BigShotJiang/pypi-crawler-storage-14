# soccernetpro/apis/__init__.py

# Import task APIs
from .classification import ClassificationAPI

# Factory functions for user-facing calls
def classification(config=None):
    return ClassificationAPI(config=config)#,pretrained_model=pretrained_model)


# Expose only these
__all__ = [
    "classification",
]
