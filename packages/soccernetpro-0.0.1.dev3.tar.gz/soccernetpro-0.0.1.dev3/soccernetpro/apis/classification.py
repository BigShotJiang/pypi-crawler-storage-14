# soccernetpro/apis/classification.py

import os

HOME = os.path.expanduser("~")
BASE_DIR = os.path.dirname(os.path.abspath(__file__))


def expand(path):
    return os.path.abspath(os.path.expanduser(path))


class ClassificationAPI:
    def __init__(self, config=None):
        from ..core.utils.config import load_config
        from ..core.trainer import Trainer

        if config is None:
            raise ValueError("config path is required")

        config_path = expand(config)
        self.config = load_config(config_path)
        self.trainer = Trainer(self.config)

    def train(self, train_set=None, valid_set=None, pretrained=None):
        from ..datasets.builder import build_dataset
        from ..models.builder import build_model

        # Load pretrained or build model
        if pretrained:
            pretrained = expand(pretrained)
            self.model, self.processor, _ = self.trainer.load(pretrained)
        else:
            self.model, self.processor = build_model(self.config, self.trainer.device)

        train_set = expand(train_set or self.config.DATA.annotations.train)
        valid_set = expand(valid_set or self.config.DATA.annotations.valid)

        # datasets
        train_data = build_dataset(self.config, train_set, self.processor, split="train")
        print(f"Train Dataset length: {len(train_data)}")
        frames= train_data[0]
        print(f"Frames shape: {frames['pixel_values'].shape}")  # 
        print(f"Label: {frames['labels']}")
        
        valid_data = build_dataset(self.config, valid_set, self.processor, split="valid") if valid_set else None
        print(f"Valid Dataset length: {len(valid_data)}")
        frames = valid_data[0]
        print(f"Frames shape: {frames['pixel_values'].shape}")  # 
        print(f"Label: {frames['labels']}")
        self.trainer.train_model(self.model, train_data, valid_data)

        save_path = os.path.join(BASE_DIR, self.config.TRAIN.save_dir, "final_model")
        self.trainer.save(model=self.model, path=save_path, processor=self.processor)


    def infer(self, test_set=None, pretrained=None, output_inference=None):
        from ..datasets.builder import build_dataset
        from ..models.builder import build_model
        
        if pretrained:
            pretrained = expand(pretrained)
            self.model, self.processor, _ = self.trainer.load(pretrained)

        test_set = expand(test_set or self.config.DATA.annotations.valid)
        test_data = build_dataset(self.config, test_set, self.processor, split="test")
        print(f"Test Dataset length: {len(test_data)}")
        frames = test_data[0]
        print(f"Frames shape: {frames['pixel_values'].shape}")  # 
        print(f"Label: {frames['labels']}")

        # # Run inference
        preds, metrics = self.trainer.infer(test_data)
        print(metrics)
        # # Save inference if requested
        # if output_inference:
        #     self.trainer.save_inference(outputs, output_inference)

        return preds, metrics
