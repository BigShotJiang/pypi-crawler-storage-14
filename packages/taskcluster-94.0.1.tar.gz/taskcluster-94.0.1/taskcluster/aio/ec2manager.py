# stub to support existing import paths
from ..generated.aio.ec2manager import *  # NOQA
