facet
-----

.. automodule:: lsmtool.facet
    :members:
    :undoc-members:
    :show-inheritance:
