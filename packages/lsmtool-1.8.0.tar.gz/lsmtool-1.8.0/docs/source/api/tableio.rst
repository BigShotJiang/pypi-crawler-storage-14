

tableio
-------

.. automodule:: lsmtool.tableio
    :members:
    :undoc-members:
    :show-inheritance:
