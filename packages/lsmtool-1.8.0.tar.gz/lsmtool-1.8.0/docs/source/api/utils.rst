utils
-----

.. automodule:: lsmtool.utils
    :members:
    :undoc-members:
    :show-inheritance:
