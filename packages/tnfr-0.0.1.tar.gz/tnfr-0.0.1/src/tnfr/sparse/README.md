# TNFR Sparse — Canonical Module Hub (Single Source of Truth)

English-only hub for sparse data structures and ops.

- Computational hub: `src/tnfr/mathematics/README.md`

## Scope
- CSR/CSC utilities, neighbor accumulation, and performance helpers
