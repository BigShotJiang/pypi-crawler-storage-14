# TNFR Services — Canonical Module Hub (Single Source of Truth)

English-only hub for service abstractions and integrations.

## Scope
- Long-running processes, orchestration, adapters
