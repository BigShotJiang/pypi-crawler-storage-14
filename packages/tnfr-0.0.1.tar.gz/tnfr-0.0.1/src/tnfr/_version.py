"""Version information for TNFR package."""

__version__ = "9.5.1"