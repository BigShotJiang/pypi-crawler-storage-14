import sys

if sys.version_info < (3, 11):
    # pylint: disable-next=deprecated-class
    from importlib.abc import Traversable
else:
    from importlib.resources.abc import Traversable


class Woodpecker:
    family = "woodpecker"


class W001(Woodpecker):
    "Woodpecker workflows found"

    url = "https://woodpecker-ci.org/docs/usage/workflows"

    @staticmethod
    def check(root: Traversable) -> bool:
        return any(
            [
                (root / ".woodpecker.yaml").is_file(),
                (root / ".woodpecker").is_dir(),
            ]
        )


def repo_review_checks() -> dict[str, Woodpecker]:
    return {p.__name__: p() for p in Woodpecker.__subclasses__()}
