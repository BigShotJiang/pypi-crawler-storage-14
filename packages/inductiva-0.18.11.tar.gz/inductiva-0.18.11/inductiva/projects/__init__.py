#pylint: disable=missing-module-docstring
from inductiva.projects.project import (Project, get_projects)
