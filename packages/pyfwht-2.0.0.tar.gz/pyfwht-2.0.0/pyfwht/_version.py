"""Version information for pyfwht package."""

__version__ = "2.0.0"
