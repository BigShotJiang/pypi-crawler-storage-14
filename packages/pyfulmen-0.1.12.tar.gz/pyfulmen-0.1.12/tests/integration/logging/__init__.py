"""Integration tests for pyfulmen logging module."""
