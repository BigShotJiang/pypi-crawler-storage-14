"""Integration tests for pyfulmen."""
