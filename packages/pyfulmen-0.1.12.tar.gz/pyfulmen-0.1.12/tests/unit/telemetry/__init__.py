"""Tests for telemetry module."""
