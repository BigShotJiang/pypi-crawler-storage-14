import{_ as a,cu as s}from"./index-Dj6UKNsX.js";const c=a(s,[["__scopeId","data-v-565bc716"]]);export{c as M};
