def foo(lst: list[int]) -> list[int]:
    """MUST FAIL — missing validate_Numeric_List."""
    return lst
