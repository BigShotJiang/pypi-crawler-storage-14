from nvector._examples import GETTING_STARTED_FUNCTIONAL

__doc__ = GETTING_STARTED_FUNCTIONAL  # @ReservedAssignment


if __name__ == "__main__":
    from nvector._common import test_docstrings

    test_docstrings(__file__)
