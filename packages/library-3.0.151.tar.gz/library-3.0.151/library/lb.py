if __name__ == "__main__":
    import library.__main__

    library.__main__.library()
