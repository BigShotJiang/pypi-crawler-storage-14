This module provides a generic tool to have the possibility to see a
list of records associated to a given selection of records. This is
basically the UI version of `recordset.mapped('field1.field2')`.

For example, if you use the sale module, you can configure an action to
see all the products that have been sold for a given selection of sale
orders.
