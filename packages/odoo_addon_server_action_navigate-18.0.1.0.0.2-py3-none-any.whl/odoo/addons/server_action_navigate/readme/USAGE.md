- Go to a tree view, for a model for which you have defined a navigation
  action.
- click on 'Action' Button

![Users List](../static/description/res_users_tree.png)

- then click on the name of the configured Action and see the results

![Partner Category List](../static/description/res_partner_category_tree.png)
