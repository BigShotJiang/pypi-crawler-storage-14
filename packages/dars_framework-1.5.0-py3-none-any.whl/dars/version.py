__version__ = "1.5.0"
__release_url__ = "https://github.com/ZtaMDev/Dars-Framework/releases/tag/1.5.0"
