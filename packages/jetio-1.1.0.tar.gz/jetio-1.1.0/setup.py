from setuptools import setup, find_packages

# This file is now just a shim to support editable installs and older tools.
# All package metadata is now defined in setup.cfg.
setup()

if __name__ == "__main__":
    setup()