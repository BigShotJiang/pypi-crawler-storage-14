raise ImportError("Artificially failining import as if no lxml is available")
