__version__ = "0.0.20251126.224505"

from .client import MultisportClient as MultisportClient
