"""
Bar Chart Module

This module provides functions to create clean, publication-ready bar charts.
All charts follow The Economist's visual style guidelines featuring:
- Y-axis gridlines only (no x-axis gridlines)
- Labels positioned at the top of the y-axis
- Minimal spines (only bottom axis visible)
- Left-aligned titles and subtitles
- Optional reference lines for benchmarks
- High-resolution export capabilities

Functions:
    apply_style: Apply standard styling to matplotlib axes
    add_reference_lines: Add horizontal dashed lines for benchmarks
    bar_chart: Create a complete bar chart
    format_y_axis: Configure y-axis tick labels with custom formatting
"""

import matplotlib.pyplot as plt
import numpy as np
from typing import Optional, List, Tuple, Callable, Union


def apply_style(
    ax: plt.Axes,
    remove_spines: List[str] = ['top', 'right', 'left']
) -> None:
    """
    Apply standard styling to a matplotlib axes object.
    
    Args:
        ax: Matplotlib axes object to style
        remove_spines: List of spine names to remove. Default: ['top', 'right', 'left']
    """
    ax.spines[remove_spines].set_visible(False)
    ax.grid(which="major", axis='y', color='#758D99', alpha=0.6, zorder=1)
    ax.xaxis.set_tick_params(labelsize=11)
    ax.yaxis.set_tick_params(
        pad=5,
        labeltop=True,
        labelbottom=False,
        bottom=False,
        labelsize=11
    )


def format_y_axis(
    ax: plt.Axes,
    format_func: Optional[Callable[[float], str]] = None,
    decimal_places: int = 2
) -> None:
    """
    Format y-axis tick labels with left alignment and custom formatting.
    
    Args:
        ax: Matplotlib axes object
        format_func: Optional custom formatting function. If None, uses decimal places.
        decimal_places: Number of decimal places for default formatting
    """
    y_ticks = ax.get_yticks()
    
    if format_func is None:
        format_func = lambda y: f'{y:.{decimal_places}f}'
    
    ax.set_yticklabels(
        [format_func(y) for y in y_ticks],
        ha='left',
        verticalalignment='bottom'
    )


def add_reference_lines(
    ax: plt.Axes,
    positions: List[float],
    color: str = '#758D99',
    linewidth: float = 1,
    linestyle: str = '--',
    alpha: float = 0.6
) -> None:
    """
    Add horizontal dashed lines to mark reference values on the chart.
    
    Args:
        ax: Matplotlib axes object
        positions: List of y-coordinates where reference lines should appear
        color: Color of the reference lines. Default: '#758D99' (gray-blue)
        linewidth: Width of reference lines. Default: 1
        linestyle: Line style. Default: '--' (dashed)
        alpha: Transparency of lines. Default: 0.6
    """
    for y_pos in positions:
        ax.axhline(
            y=y_pos,
            color=color,
            linewidth=linewidth,
            linestyle=linestyle,
            alpha=alpha,
            zorder=1
        )


def bar_chart(
    x,
    y,
    title: str,
    subtitle: str,
    source: str,
    color: str = '#006BA2',
    figsize: Tuple[float, float] = (8, 4),
    bar_width: float = 0.8,
    y_format_func: Optional[Callable[[float], str]] = None,
    y_decimal_places: int = 2,
    y_margin: float = 0.05,
    reference_lines: Optional[List[float]] = None,
    horizontal: bool = False,
    output_path: Optional[str] = None,
    dpi: int = 300,
    show_plot: bool = True
) -> Tuple[plt.Figure, plt.Axes]:
    """
    Create a complete bar chart.
    
    Args:
        x: List data for x-axis (categories or positions)
        y: List data for y-axis (bar heights)
        title: Main chart title
        subtitle: Subtitle providing additional context
        source: Data source citation
        color: Bar color. Default: '#006BA2' (blue)
        figsize: Figure size as (width, height). Default: (8, 4)
        bar_width: Width of bars. Default: 0.8
        y_format_func: Optional custom function to format y-axis labels
        y_decimal_places: Decimal places for y-axis labels. Default: 2
        y_margin: Margin around y-data as fraction. Default: 0.05 (5%)
        reference_lines: Optional list of y-coordinates for reference lines
        horizontal: If True, creates horizontal bars. Default: False
        output_path: Optional path to save the figure. If None, figure is not saved.
        dpi: Resolution for saved figure. Default: 300
        show_plot: Whether to display the plot. Default: True
    
    Returns:
        Tuple of (figure, axes) objects for further customization
    
    Example:
        >>> import pandas as pd
        >>> df = pd.read_csv('data.csv')
        >>> fig, ax = bar_chart(
        ...     x=df['category'],
        ...     y=df['value'],
        ...     title="Sales by Category",
        ...     subtitle="Annual totals, 2020",
        ...     source="Company data",
        ...     reference_lines=[50],  # Add line at 50
        ...     output_path="bar_chart.png"
        ... )
    """
    # Setup plot
    fig, ax = plt.subplots(figsize=figsize)
    apply_style(ax)
    
    # Create bars
    if horizontal:
        ax.barh(x, y, height=bar_width, color=color, zorder=2)
        # Adjust styling for horizontal bars
        ax.grid(which="major", axis='x', color='#758D99', alpha=0.6, zorder=1)
        ax.grid(which="major", axis='y', visible=False)
        y_min = np.min(y) * (1 - y_margin) if np.min(y) >= 0 else np.min(y) * (1 + y_margin)
        y_max = np.max(y) * (1 + y_margin) if np.max(y) >= 0 else np.max(y) * (1 - y_margin)
        ax.set_xlim(y_min, y_max)
    else:
        ax.bar(x, y, width=bar_width, color=color, zorder=2)
        y_min = np.min(y) * (1 - y_margin) if np.min(y) >= 0 else np.min(y) * (1 + y_margin)
        y_max = np.max(y) * (1 + y_margin) if np.max(y) >= 0 else np.max(y) * (1 - y_margin)
        ax.set_ylim(y_min, y_max)
    
    # Format y-axis
    format_y_axis(ax, format_func=y_format_func, decimal_places=y_decimal_places)
    
    # Add reference lines if provided
    if reference_lines:
        add_reference_lines(ax, reference_lines)
    
    # Title and subtitle
    ax.text(
        x=0.0, y=1.15,
        s=title,
        transform=ax.transAxes,
        ha='left',
        fontsize=13,
        weight='bold',
        alpha=0.8
    )
    ax.text(
        x=0.0, y=1.08,
        s=subtitle,
        transform=ax.transAxes,
        ha='left',
        fontsize=11,
        alpha=0.8
    )
    
    # Source text
    ax.text(
        x=0.0, y=-0.15,
        s=source,
        transform=ax.transAxes,
        ha='left',
        fontsize=9,
        alpha=0.7
    )
    
    plt.tight_layout()
    
    # Export plot
    if output_path:
        plt.savefig(
            output_path,
            dpi=dpi,
            bbox_inches="tight",
            facecolor='white'
        )
    
    # Show plot if requested
    if show_plot:
        plt.show()
    
    return fig, ax
