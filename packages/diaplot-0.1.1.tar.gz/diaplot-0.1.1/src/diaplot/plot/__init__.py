"""
Diaplot Plot Module

Publication-ready charts with Economist-inspired styling.
"""

from .line import line_chart, apply_style as apply_line_style, add_event_markers, format_y_axis
from .bar import bar_chart, apply_style as apply_bar_style, add_reference_lines
from .scatter import scatter_chart, apply_style as apply_scatter_style, add_trend_line
from .parliament import parliament_chart
from .palettes import (
    get_palette,
    get_color,
    create_gradient,
    categorical_colors,
    diverging_gradient,
    sequential_gradient
)

__all__ = [
    # Line charts
    'line_chart',
    'apply_line_style',
    'add_event_markers',
    'format_y_axis',
    # Bar charts
    'bar_chart',
    'apply_bar_style',
    'add_reference_lines',
    # Scatter charts
    'scatter_chart',
    'apply_scatter_style',
    'add_trend_line',
    # Parliament charts
    'parliament_chart',
    # Color palettes
    'get_palette',
    'get_color',
    'create_gradient',
    'categorical_colors',
    'diverging_gradient',
    'sequential_gradient',
]
