"""
Parliament Chart Module

This module provides functions to create parliament/legislature seat diagrams
in The Economist style. Seats are arranged in semicircular rows with parties
displayed in contiguous blocks.

Functions:
    calculate_seat_positions: Calculate (x, y) coordinates for semicircular arrangement
    allocate_seats_to_parties: Assign positions to political parties
    parliament_chart: Create a complete parliament diagram
"""

import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import numpy as np
from typing import Dict, Optional, Tuple, List


def _calculate_row_distribution(total_seats: int, n_rows: Optional[int] = None) -> np.ndarray:
    """
    Calculate how many seats should be in each row, weighted by circumference.
    
    Args:
        total_seats: Total number of seats to distribute
        n_rows: Number of rows. If None, calculated automatically.
    
    Returns:
        Array of seat counts per row (inner to outer)
    """
    if n_rows is None:
        # Heuristic: roughly sqrt(total_seats / 2), bounded
        n_rows = max(3, min(int(np.sqrt(total_seats / 2)), 15))
    
    # Seats proportional to radius (row number)
    # Row i has radius r_0 + i * dr, circumference ∝ radius
    row_weights = np.arange(1, n_rows + 1, dtype=float)
    row_seats = (row_weights / row_weights.sum() * total_seats)
    
    # Round to integers, ensuring exact total
    row_seats = np.round(row_seats).astype(int)
    
    # Adjust for rounding errors
    diff = total_seats - row_seats.sum()
    if diff > 0:
        # Add seats to outer rows (better visual balance)
        for i in range(diff):
            row_seats[-(i % n_rows) - 1] += 1
    elif diff < 0:
        # Remove seats from outer rows
        for i in range(-diff):
            idx = -(i % n_rows) - 1
            if row_seats[idx] > 1:
                row_seats[idx] -= 1
    
    return row_seats


def calculate_seat_positions(
    total_seats: int,
    n_rows: Optional[int] = None,
    angular_span: float = np.pi,
    row_spacing: float = 0.6,
    start_radius: float = 1.0
) -> np.ndarray:
    """
    Calculate (x, y) coordinates for seats arranged in semicircular rows.
    
    Args:
        total_seats: Total number of seats
        n_rows: Number of rows. If None, calculated automatically.
        angular_span: Angular span in radians. Default: π (semicircle)
        row_spacing: Distance between rows. Default: 0.6
        start_radius: Radius of innermost row. Default: 1.0
    
    Returns:
        Array of shape (total_seats, 2) containing (x, y) coordinates.
        Ordered from left to right, front to back.
    """
    row_seats = _calculate_row_distribution(total_seats, n_rows)
    positions = []
    
    for row_idx, n_seats_in_row in enumerate(row_seats):
        radius = start_radius + row_idx * row_spacing
        
        # Evenly distribute seats across angular span
        # Start and end with small margin from edges
        if n_seats_in_row == 1:
            angles = np.array([angular_span / 2])
        else:
            # Small margin (5%) on each side
            margin = angular_span * 0.05
            angles = np.linspace(
                margin,
                angular_span - margin,
                n_seats_in_row
            )
        
        # Convert polar to Cartesian
        x = radius * np.cos(angles)
        y = radius * np.sin(angles)
        
        positions.extend(zip(x, y))
    
    return np.array(positions)


def allocate_seats_to_parties(
    positions: np.ndarray,
    seats: Dict[str, int]
) -> Dict[str, np.ndarray]:
    """
    Assign seat positions to political parties in contiguous blocks.
    
    Args:
        positions: Array of (x, y) coordinates from calculate_seat_positions
        seats: Dictionary mapping party names to seat counts
    
    Returns:
        Dictionary mapping party names to their assigned position arrays
    """
    # Sort positions by angle (left to right)
    angles = np.arctan2(positions[:, 1], positions[:, 0])
    sorted_indices = np.argsort(angles)
    sorted_positions = positions[sorted_indices]
    
    # Allocate positions sequentially
    party_positions = {}
    current_idx = 0
    
    for party, count in seats.items():
        party_positions[party] = sorted_positions[current_idx:current_idx + count]
        current_idx += count
    
    return party_positions


def _get_auto_marker_size(total_seats: int) -> float:
    """
    Calculate appropriate marker size based on total seats using a formula.
    
    Args:
        total_seats: Total number of seats
    
    Returns:
        Marker size in points²
    """
    marker_size = 250 * np.exp(-total_seats / 400) + 25
    return max(30, min(marker_size, 180))


def _get_auto_figsize(total_seats: int) -> Tuple[float, float]:
    """
    Calculate appropriate figure size based on total seats.
    
    Args:
        total_seats: Total number of seats
    
    Returns:
        Tuple of (width, height)
    """
    if total_seats < 200:
        return (10, 5)
    else:
        return (12, 6)


def _get_default_colors(n_parties: int) -> List[str]:
    """
    Get default color palette for parties.
    
    Args:
        n_parties: Number of parties
    
    Returns:
        List of color hex codes
    """
    # Economist-inspired colors: blues, reds, greens, oranges, purples
    base_colors = [
        '#006BA2',  # Economist blue
        '#DB0A05',  # Economist red
        '#3EBF94',  # Teal/green
        '#E8B500',  # Gold
        '#9E67AB',  # Purple
        '#C8B273',  # Tan
        '#EC6A5C',  # Coral
        '#4E7B8C',  # Steel blue
    ]
    
    # Cycle through if more parties than colors
    colors = []
    for i in range(n_parties):
        colors.append(base_colors[i % len(base_colors)])
    
    return colors


def parliament_chart(
    seats: Dict[str, int],
    colors: Optional[Dict[str, str]] = None,
    n_rows: Optional[int] = None,
    title: Optional[str] = None,
    subtitle: Optional[str] = None,
    figsize: Optional[Tuple[float, float]] = None,
    marker_size: Optional[float] = None,
    show_legend: bool = True,
    show_counts: bool = True,
    show_percentages: bool = False,
    output_path: Optional[str] = None,
    dpi: int = 300,
    show_plot: bool = True
) -> Tuple[plt.Figure, plt.Axes]:
    """
    Create a parliament/legislature seat diagram.
    
    Args:
        seats: Dictionary mapping party names to seat counts
            Example: {'Party A': 150, 'Party B': 100, 'Party C': 50}
        colors: Optional dictionary mapping party names to colors
            If None, default colors are assigned
        n_rows: Number of semicircular rows. If None, calculated automatically
        title: Optional main title
        subtitle: Optional subtitle
        figsize: Figure size as (width, height). If None, auto-calculated
        marker_size: Size of seat markers in points². If None, auto-calculated
        show_legend: Whether to show party legend. Default: True
        show_counts: Whether to show seat counts in legend. Default: True
        show_percentages: Whether to show percentages in legend. Default: False
        output_path: Optional path to save figure
        dpi: Resolution for saved figure. Default: 300
        show_plot: Whether to display the plot. Default: True
    
    Returns:
        Tuple of (figure, axes) objects for further customization
    
    Raises:
        ValueError: If seats dictionary is empty or contains invalid values
    
    Example:
        >>> fig, ax = parliament_chart(
        ...     seats={'Conservative': 365, 'Labour': 202, 'SNP': 48},
        ...     colors={'Conservative': '#0087DC', 'Labour': '#E4003B', 'SNP': '#FDF38E'},
        ...     title='UK House of Commons, 2019',
        ...     subtitle='650 seats total'
        ... )
    """
    # Validation
    if not seats:
        raise ValueError("seats dictionary cannot be empty")
    
    if any(count <= 0 for count in seats.values()):
        raise ValueError("All seat counts must be positive integers")
    
    total_seats = sum(seats.values())
    
    if total_seats > 10000:
        raise ValueError("Total seats exceeds reasonable limit (10000)")
    
    # Color assignment
    if colors is None:
        default_colors = _get_default_colors(len(seats))
        colors = dict(zip(seats.keys(), default_colors))
    else:
        # Check that all parties have colors
        missing = set(seats.keys()) - set(colors.keys())
        if missing:
            raise ValueError(f"Colors missing for parties: {missing}")
    
    # Auto-calculate size parameters
    if figsize is None:
        figsize = _get_auto_figsize(total_seats)
    
    if marker_size is None:
        marker_size = _get_auto_marker_size(total_seats)
    
    # Calculate positions
    positions = calculate_seat_positions(total_seats, n_rows)
    party_positions = allocate_seats_to_parties(positions, seats)
    
    # Create figure
    fig, ax = plt.subplots(figsize=figsize)
    
    # Plot each party
    for party, party_pos in party_positions.items():
        ax.scatter(
            party_pos[:, 0],
            party_pos[:, 1],
            s=marker_size,
            color=colors[party],
            zorder=2,
            edgecolors='none'
        )
    
    # Styling
    ax.set_aspect('equal')
    ax.axis('off')
    
    # Set axis limits with moderate padding for labels
    all_x = positions[:, 0]
    all_y = positions[:, 1]
    x_range = all_x.max() - all_x.min()
    y_range = all_y.max() - all_y.min()
    
    # Moderate padding for labels
    ax.set_xlim(all_x.min() - 0.2 * x_range, all_x.max() + 0.2 * x_range)
    ax.set_ylim(all_y.min() - 0.1 * y_range, all_y.max() + 0.35 * y_range)
    
    # Title and subtitle (left-aligned, close to graph)
    if title:
        ax.text(
            x=0.0, y=1.08,
            s=title,
            transform=ax.transAxes,
            ha='left',
            va='bottom',
            fontsize=16,
            weight='bold',
            alpha=0.8
        )
    
    if subtitle:
        subtitle_y = 1.02 if title else 1.04
        ax.text(
            x=0.0, y=subtitle_y,
            s=subtitle,
            transform=ax.transAxes,
            ha='left',
            va='bottom',
            fontsize=13,
            alpha=0.8
        )
    
    # Add inline party labels with smart collision avoidance
    label_data = []
    
    # Calculate initial positions for all labels
    for party, party_pos in party_positions.items():
        count = seats[party]
        
        party_angles = np.arctan2(party_pos[:, 1], party_pos[:, 0])
        party_radii = np.sqrt(party_pos[:, 0]**2 + party_pos[:, 1]**2)
        
        median_angle = np.median(party_angles)
        max_radius = party_radii.max()
        
        # Base offset - keep labels close but clear of bubbles
        label_offset = 0.8
        label_radius = max_radius + label_offset
        label_x = label_radius * np.cos(median_angle)
        label_y = label_radius * np.sin(median_angle)
        
        label_data.append({
            'party': party,
            'count': count,
            'x': label_x,
            'y': label_y,
            'angle': median_angle,
            'original_x': label_x,
            'original_y': label_y
        })
    
    # Sort by angle for sequential collision checking
    label_data.sort(key=lambda d: d['angle'])
    
    # Collision avoidance: push labels downward to maintain left-to-right order
    for i, label in enumerate(label_data):
        max_iterations = 25
        iteration = 0
        
        while iteration < max_iterations:
            collision = False
            
            # Check against all previous labels
            for j in range(i):
                prev = label_data[j]
                dx = label['x'] - prev['x']
                dy = label['y'] - prev['y']
                dist = np.sqrt(dx**2 + dy**2)
                
                # More aggressive thresholds to prevent overlap
                if label['count'] < 20 or prev['count'] < 20:
                    threshold = 0.9  # Very small parties
                elif label['count'] < 50 or prev['count'] < 50:
                    threshold = 0.75  # Small-medium parties
                else:
                    threshold = 0.6  # Larger parties
                
                # If too close, push downward only
                if dist < threshold:
                    collision = True
                    push_amount = 0.35 if label['count'] < 30 else 0.28
                    
                    # Always push downward to spread labels vertically below
                    label['y'] -= push_amount
                    
                    break
            
            if not collision:
                break
            iteration += 1
    
    # Render all labels
    for label in label_data:
        angle = label['angle']
        
        # Determine alignment
        if angle < np.pi / 3:
            ha = 'left'
        elif angle > 2 * np.pi / 3:
            ha = 'right'
        else:
            ha = 'center'
        
        # Font sizing
        count = label['count']
        fontsize = 8 if count < 20 else 9 if count < 50 else 10
        
        # Render party name
        ax.text(
            label['x'], label['y'],
            label['party'],
            ha=ha,
            va='bottom',
            fontsize=fontsize,
            alpha=0.8,
            color='black'
        )
        
        # Render colored seat count
        ax.text(
            label['x'], label['y'] - 0.16,
            f"({count})",
            ha=ha,
            va='top',
            fontsize=max(7, fontsize - 1),
            color=colors[label['party']],
            alpha=0.95,
            weight='bold'
        )
    
    plt.tight_layout()
    
    # Export plot
    if output_path:
        plt.savefig(
            output_path,
            dpi=dpi,
            bbox_inches="tight",
            facecolor='white'
        )
    
    # Show plot if requested
    if show_plot:
        plt.show()
    
    return fig, ax
