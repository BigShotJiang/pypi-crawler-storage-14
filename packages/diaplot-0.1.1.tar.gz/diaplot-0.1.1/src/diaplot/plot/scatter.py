"""
Scatter Plot Module

This module provides functions to create clean, publication-ready scatter plots.
All charts follow The Economist's visual style guidelines featuring:
- Y-axis gridlines only (no x-axis gridlines)
- Labels positioned at the top of the y-axis
- Minimal spines (only bottom axis visible)
- Left-aligned titles and subtitles
- Optional trend lines and reference lines
- High-resolution export capabilities

Functions:
    apply_style: Apply standard styling to matplotlib axes
    add_reference_lines: Add horizontal or vertical reference lines
    add_trend_line: Add a linear trend line to the scatter plot
    scatter_chart: Create a complete scatter plot
    format_y_axis: Configure y-axis tick labels with custom formatting
"""

import matplotlib.pyplot as plt
import numpy as np
from typing import Optional, List, Tuple, Callable, Dict


def apply_style(
    ax: plt.Axes,
    remove_spines: List[str] = ['top', 'right', 'left']
) -> None:
    """
    Apply standard styling to a matplotlib axes object.
    
    Args:
        ax: Matplotlib axes object to style
        remove_spines: List of spine names to remove. Default: ['top', 'right', 'left']
    """
    for spine in remove_spines:
        ax.spines[spine].set_visible(False)
    ax.grid(which="major", axis='y', color='#758D99', alpha=0.6, zorder=1)
    ax.xaxis.set_tick_params(labelsize=11)
    ax.yaxis.set_tick_params(
        pad=5,
        labeltop=True,
        labelbottom=False,
        bottom=False,
        labelsize=11
    )


def format_y_axis(
    ax: plt.Axes,
    format_func: Optional[Callable[[float], str]] = None,
    decimal_places: int = 2
) -> None:
    """
    Format y-axis tick labels with left alignment and custom formatting.
    
    Args:
        ax: Matplotlib axes object
        format_func: Optional custom formatting function. If None, uses decimal places.
        decimal_places: Number of decimal places for default formatting
    """
    y_ticks = ax.get_yticks()
    
    if format_func is None:
        format_func = lambda y: f'{y:.{decimal_places}f}'
    
    ax.set_yticklabels(
        [format_func(y) for y in y_ticks],
        ha='left',
        verticalalignment='bottom'
    )


def add_reference_lines(
    ax: plt.Axes,
    horizontal: Optional[List[float]] = None,
    vertical: Optional[List[float]] = None,
    color: str = '#758D99',
    linewidth: float = 1,
    linestyle: str = '--',
    alpha: float = 0.6
) -> None:
    """
    Add horizontal or vertical reference lines to the chart.
    
    Args:
        ax: Matplotlib axes object
        horizontal: Optional list of y-coordinates for horizontal lines
        vertical: Optional list of x-coordinates for vertical lines
        color: Color of the reference lines. Default: '#758D99' (gray-blue)
        linewidth: Width of reference lines. Default: 1
        linestyle: Line style. Default: '--' (dashed)
        alpha: Transparency of lines. Default: 0.6
    """
    if horizontal:
        for y_pos in horizontal:
            ax.axhline(
                y=y_pos,
                color=color,
                linewidth=linewidth,
                linestyle=linestyle,
                alpha=alpha,
                zorder=1
            )
    
    if vertical:
        for x_pos in vertical:
            ax.axvline(
                x=x_pos,
                color=color,
                linewidth=linewidth,
                linestyle=linestyle,
                alpha=alpha,
                zorder=1
            )


def add_trend_line(
    ax: plt.Axes,
    x,
    y,
    color: str = '#E3120B',
    linewidth: float = 2,
    linestyle: str = '-',
    alpha: float = 0.8
) -> Tuple[float, float]:
    """
    Add a linear trend line to the scatter plot.
    
    Args:
        ax: Matplotlib axes object
        x: X-axis data
        y: Y-axis data
        color: Color of the trend line. Default: '#E3120B' (Economist red)
        linewidth: Width of the trend line. Default: 2
        linestyle: Line style. Default: '-' (solid)
        alpha: Transparency of line. Default: 0.8
    
    Returns:
        Tuple of (slope, intercept) for the trend line
    """
    # Calculate linear regression
    x_array = np.array(x)
    y_array = np.array(y)
    
    # Remove any NaN values
    mask = ~np.isnan(x_array) & ~np.isnan(y_array)
    x_clean = x_array[mask]
    y_clean = y_array[mask]
    
    # Calculate slope and intercept
    coefficients = np.polyfit(x_clean, y_clean, 1)
    slope, intercept = coefficients
    
    # Generate trend line
    x_trend = np.linspace(x_clean.min(), x_clean.max(), 100)
    y_trend = slope * x_trend + intercept
    
    # Plot trend line
    ax.plot(
        x_trend,
        y_trend,
        color=color,
        linewidth=linewidth,
        linestyle=linestyle,
        alpha=alpha,
        zorder=3
    )
    
    return slope, intercept


def scatter_chart(
    x,
    y,
    title: str,
    subtitle: str,
    source: str,
    color: str = '#006BA2',
    figsize: Tuple[float, float] = (8, 6),
    marker_size: float = 50,
    marker_alpha: float = 0.7,
    marker_style: str = 'o',
    weights: Optional[list] = None,
    size_range: Tuple[float, float] = (20, 500),
    y_format_func: Optional[Callable[[float], str]] = None,
    y_decimal_places: int = 2,
    x_format_func: Optional[Callable[[float], str]] = None,
    x_decimal_places: int = 2,
    y_margin: float = 0.05,
    x_margin: float = 0.05,
    reference_lines: Optional[Dict[str, List[float]]] = None,
    show_trend_line: bool = False,
    trend_line_color: str = '#E3120B',
    labels: Optional[List[str]] = None,
    label_fontsize: int = 9,
    output_path: Optional[str] = None,
    dpi: int = 300,
    show_plot: bool = True
) -> Tuple[plt.Figure, plt.Axes]:
    """
    Create a complete scatter plot.
    
    Args:
        x: List or array of x-axis data
        y: List or array of y-axis data
        title: Main chart title
        subtitle: Subtitle providing additional context
        source: Data source citation
        color: Marker color. Default: '#006BA2' (Economist blue)
        figsize: Figure size as (width, height). Default: (8, 6)
        marker_size: Size of scatter markers. Default: 50 (ignored if weights provided)
        marker_alpha: Transparency of markers. Default: 0.7
        marker_style: Marker style. Default: 'o' (circle)
        weights: Optional list/array of weights for each point to create weighted scatter plot.
            If provided, marker sizes will be scaled based on these weights. Default: None
        size_range: Tuple of (min_size, max_size) for weighted markers. Default: (20, 500)
        y_format_func: Optional custom function to format y-axis labels
        y_decimal_places: Decimal places for y-axis labels. Default: 2
        x_format_func: Optional custom function to format x-axis labels
        x_decimal_places: Decimal places for x-axis labels. Default: 2
        y_margin: Margin around y-data as fraction. Default: 0.05 (5%)
        x_margin: Margin around x-data as fraction. Default: 0.05 (5%)
        reference_lines: Optional dict with 'horizontal' and/or 'vertical' keys containing lists of positions
        show_trend_line: Whether to show a linear trend line. Default: False
        trend_line_color: Color of trend line. Default: '#E3120B' (red)
        labels: Optional list of labels for each point
        label_fontsize: Font size for point labels. Default: 9
        output_path: Optional path to save the figure. If None, figure is not saved.
        dpi: Resolution for saved figure. Default: 300
        show_plot: Whether to display the plot. Default: True
    
    Returns:
        Tuple of (figure, axes) objects for further customization
    
    Example:
        >>> import pandas as pd
        >>> df = pd.read_csv('data.csv')
        >>> fig, ax = scatter_chart(
        ...     x=df['gdp_per_capita'],
        ...     y=df['life_expectancy'],
        ...     title="Life Expectancy vs GDP",
        ...     subtitle="Data from 2020",
        ...     source="World Bank data",
        ...     show_trend_line=True,
        ...     labels=df['country'],
        ...     output_path="scatter.png"
        ... )
        
        >>> # Weighted scatter plot
        >>> fig, ax = scatter_chart(
        ...     x=df['gdp_per_capita'],
        ...     y=df['life_expectancy'],
        ...     weights=df['population'],  # Bubble size represents population
        ...     title="Life Expectancy vs GDP (sized by population)",
        ...     subtitle="Bubble size represents population",
        ...     source="World Bank data"
        ... )
    """
    # Setup plot
    fig, ax = plt.subplots(figsize=figsize)
    apply_style(ax)
    
    # Calculate marker sizes based on weights if provided
    if weights is not None:
        weights_array = np.array(weights)
        min_weight = weights_array.min()
        max_weight = weights_array.max()
        
        # Normalize weights to size_range
        if max_weight > min_weight:
            normalized_weights = (weights_array - min_weight) / (max_weight - min_weight)
            sizes = size_range[0] + normalized_weights * (size_range[1] - size_range[0])
        else:
            # All weights are the same
            sizes = np.full(len(weights), (size_range[0] + size_range[1]) / 2)
    else:
        sizes = marker_size
    
    # Create scatter plot
    ax.scatter(
        x, y,
        s=sizes,
        color=color,
        alpha=marker_alpha,
        marker=marker_style,
        zorder=2,
        edgecolors='none'
    )
    
    # Add labels if provided
    if labels is not None:
        for i, label in enumerate(labels):
            ax.annotate(
                label,
                (x[i], y[i]),
                xytext=(5, 5),
                textcoords='offset points',
                fontsize=label_fontsize,
                alpha=0.8
            )
    
    # Setup axes
    y_min = np.min(y) * (1 - y_margin) if np.min(y) >= 0 else np.min(y) * (1 + y_margin)
    y_max = np.max(y) * (1 + y_margin) if np.max(y) >= 0 else np.max(y) * (1 - y_margin)
    ax.set_ylim(y_min, y_max)
    
    x_min = np.min(x) * (1 - x_margin) if np.min(x) >= 0 else np.min(x) * (1 + x_margin)
    x_max = np.max(x) * (1 + x_margin) if np.max(x) >= 0 else np.max(x) * (1 - x_margin)
    ax.set_xlim(x_min, x_max)
    
    # Format axes
    format_y_axis(ax, format_func=y_format_func, decimal_places=y_decimal_places)
    
    if x_format_func:
        x_ticks = ax.get_xticks()
        ax.set_xticklabels([x_format_func(x_val) for x_val in x_ticks])
    
    # Add trend line if requested
    if show_trend_line:
        add_trend_line(
            ax, x, y,
            color=trend_line_color,
            linewidth=2
        )
    
    # Add reference lines if provided
    if reference_lines:
        add_reference_lines(
            ax,
            horizontal=reference_lines.get('horizontal'),
            vertical=reference_lines.get('vertical')
        )
    
    # Title and subtitle
    ax.text(
        x=0.0, y=1.15,
        s=title,
        transform=ax.transAxes,
        ha='left',
        fontsize=13,
        weight='bold',
        alpha=0.8
    )
    ax.text(
        x=0.0, y=1.08,
        s=subtitle,
        transform=ax.transAxes,
        ha='left',
        fontsize=11,
        alpha=0.8
    )
    
    # Source text
    ax.text(
        x=0.0, y=-0.15,
        s=source,
        transform=ax.transAxes,
        ha='left',
        fontsize=9,
        alpha=0.7
    )
    
    plt.tight_layout()
    
    # Export plot
    if output_path:
        plt.savefig(
            output_path,
            dpi=dpi,
            bbox_inches="tight",
            facecolor='white'
        )
    
    # Show plot if requested
    if show_plot:
        plt.show()
    
    return fig, ax
