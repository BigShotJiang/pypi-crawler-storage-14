### Requirements ##
- fastmcp
- numpy
- opencv-python
- Pillow