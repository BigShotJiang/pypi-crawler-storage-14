import "../../../../../assets/svelte/svelte_internal_flags_legacy.js";
import * as bt from "../../../../../assets/svelte/svelte_internal_client.js";
var Xt = {
  /***/
  976: (
    /***/
    ((ct, st, V) => {
      V.d(st, {
        AnnotationLayer: () => (
          /* binding */
          ut
        ),
        FreeTextAnnotationElement: () => (
          /* binding */
          z
        ),
        InkAnnotationElement: () => (
          /* binding */
          tt
        ),
        StampAnnotationElement: () => (
          /* binding */
          dt
        )
      });
      var w = V(292), B = V(419), _ = V(792);
      function U(et) {
        return Math.floor(Math.max(0, Math.min(1, et)) * 255).toString(16).padStart(2, "0");
      }
      function P(et) {
        return Math.max(0, Math.min(255, 255 * et));
      }
      class T {
        static CMYK_G([m, h, e, r]) {
          return ["G", 1 - Math.min(1, 0.3 * m + 0.59 * e + 0.11 * h + r)];
        }
        static G_CMYK([m]) {
          return ["CMYK", 0, 0, 0, 1 - m];
        }
        static G_RGB([m]) {
          return ["RGB", m, m, m];
        }
        static G_rgb([m]) {
          return m = P(m), [m, m, m];
        }
        static G_HTML([m]) {
          const h = U(m);
          return `#${h}${h}${h}`;
        }
        static RGB_G([m, h, e]) {
          return ["G", 0.3 * m + 0.59 * h + 0.11 * e];
        }
        static RGB_rgb(m) {
          return m.map(P);
        }
        static RGB_HTML(m) {
          return `#${m.map(U).join("")}`;
        }
        static T_HTML() {
          return "#00000000";
        }
        static T_rgb() {
          return [null];
        }
        static CMYK_RGB([m, h, e, r]) {
          return ["RGB", 1 - Math.min(1, m + r), 1 - Math.min(1, e + r), 1 - Math.min(1, h + r)];
        }
        static CMYK_rgb([m, h, e, r]) {
          return [P(1 - Math.min(1, m + r)), P(1 - Math.min(1, e + r)), P(1 - Math.min(1, h + r))];
        }
        static CMYK_HTML(m) {
          const h = this.CMYK_RGB(m).slice(1);
          return this.RGB_HTML(h);
        }
        static RGB_CMYK([m, h, e]) {
          const r = 1 - m, p = 1 - h, o = 1 - e, a = Math.min(r, p, o);
          return ["CMYK", r, p, o, a];
        }
      }
      var E = V(284);
      const v = 1e3, n = 9, c = /* @__PURE__ */ new WeakSet();
      function l(et) {
        return {
          width: et[2] - et[0],
          height: et[3] - et[1]
        };
      }
      class b {
        static create(m) {
          switch (m.data.annotationType) {
            case w.AnnotationType.LINK:
              return new g(m);
            case w.AnnotationType.TEXT:
              return new t(m);
            case w.AnnotationType.WIDGET:
              switch (m.data.fieldType) {
                case "Tx":
                  return new d(m);
                case "Btn":
                  return m.data.radioButton ? new S(m) : m.data.checkBox ? new y(m) : new L(m);
                case "Ch":
                  return new M(m);
                case "Sig":
                  return new f(m);
              }
              return new i(m);
            case w.AnnotationType.POPUP:
              return new N(m);
            case w.AnnotationType.FREETEXT:
              return new z(m);
            case w.AnnotationType.LINE:
              return new q(m);
            case w.AnnotationType.SQUARE:
              return new nt(m);
            case w.AnnotationType.CIRCLE:
              return new j(m);
            case w.AnnotationType.POLYLINE:
              return new O(m);
            case w.AnnotationType.CARET:
              return new Y(m);
            case w.AnnotationType.INK:
              return new tt(m);
            case w.AnnotationType.POLYGON:
              return new G(m);
            case w.AnnotationType.HIGHLIGHT:
              return new Z(m);
            case w.AnnotationType.UNDERLINE:
              return new at(m);
            case w.AnnotationType.SQUIGGLY:
              return new lt(m);
            case w.AnnotationType.STRIKEOUT:
              return new pt(m);
            case w.AnnotationType.STAMP:
              return new dt(m);
            case w.AnnotationType.FILEATTACHMENT:
              return new ot(m);
            default:
              return new s(m);
          }
        }
      }
      class s {
        #t = null;
        #e = !1;
        constructor(m, {
          isRenderable: h = !1,
          ignoreBorder: e = !1,
          createQuadrilaterals: r = !1
        } = {}) {
          this.isRenderable = h, this.data = m.data, this.layer = m.layer, this.linkService = m.linkService, this.downloadManager = m.downloadManager, this.imageResourcesPath = m.imageResourcesPath, this.renderForms = m.renderForms, this.svgFactory = m.svgFactory, this.annotationStorage = m.annotationStorage, this.enableScripting = m.enableScripting, this.hasJSActions = m.hasJSActions, this._fieldObjects = m.fieldObjects, this.parent = m.parent, h && (this.container = this._createContainer(e)), r && this._createQuadrilaterals();
        }
        static _hasPopupData({
          titleObj: m,
          contentsObj: h,
          richText: e
        }) {
          return !!(m?.str || h?.str || e?.str);
        }
        get hasPopupData() {
          return s._hasPopupData(this.data);
        }
        updateEdited(m) {
          if (!this.container)
            return;
          this.#t ||= {
            rect: this.data.rect.slice(0)
          };
          const {
            rect: h
          } = m;
          h && this.#s(h);
        }
        resetEdited() {
          this.#t && (this.#s(this.#t.rect), this.#t = null);
        }
        #s(m) {
          const {
            container: {
              style: h
            },
            data: {
              rect: e,
              rotation: r
            },
            parent: {
              viewport: {
                rawDims: {
                  pageWidth: p,
                  pageHeight: o,
                  pageX: a,
                  pageY: u
                }
              }
            }
          } = this;
          e?.splice(0, 4, ...m);
          const {
            width: A,
            height: x
          } = l(m);
          h.left = `${100 * (m[0] - a) / p}%`, h.top = `${100 * (o - m[3] + u) / o}%`, r === 0 ? (h.width = `${100 * A / p}%`, h.height = `${100 * x / o}%`) : this.setRotation(r);
        }
        _createContainer(m) {
          const {
            data: h,
            parent: {
              page: e,
              viewport: r
            }
          } = this, p = document.createElement("section");
          p.setAttribute("data-annotation-id", h.id), this instanceof i || (p.tabIndex = v);
          const {
            style: o
          } = p;
          if (o.zIndex = this.parent.zIndex++, h.popupRef && p.setAttribute("aria-haspopup", "dialog"), h.alternativeText && (p.title = h.alternativeText), h.noRotate && p.classList.add("norotate"), !h.rect || this instanceof N) {
            const {
              rotation: F
            } = h;
            return !h.hasOwnCanvas && F !== 0 && this.setRotation(F, p), p;
          }
          const {
            width: a,
            height: u
          } = l(h.rect);
          if (!m && h.borderStyle.width > 0) {
            o.borderWidth = `${h.borderStyle.width}px`;
            const F = h.borderStyle.horizontalCornerRadius, C = h.borderStyle.verticalCornerRadius;
            if (F > 0 || C > 0) {
              const K = `calc(${F}px * var(--scale-factor)) / calc(${C}px * var(--scale-factor))`;
              o.borderRadius = K;
            } else if (this instanceof S) {
              const K = `calc(${a}px * var(--scale-factor)) / calc(${u}px * var(--scale-factor))`;
              o.borderRadius = K;
            }
            switch (h.borderStyle.style) {
              case w.AnnotationBorderStyleType.SOLID:
                o.borderStyle = "solid";
                break;
              case w.AnnotationBorderStyleType.DASHED:
                o.borderStyle = "dashed";
                break;
              case w.AnnotationBorderStyleType.BEVELED:
                (0, w.warn)("Unimplemented border style: beveled");
                break;
              case w.AnnotationBorderStyleType.INSET:
                (0, w.warn)("Unimplemented border style: inset");
                break;
              case w.AnnotationBorderStyleType.UNDERLINE:
                o.borderBottomStyle = "solid";
                break;
            }
            const $ = h.borderColor || null;
            $ ? (this.#e = !0, o.borderColor = w.Util.makeHexColor($[0] | 0, $[1] | 0, $[2] | 0)) : o.borderWidth = 0;
          }
          const A = w.Util.normalizeRect([h.rect[0], e.view[3] - h.rect[1] + e.view[1], h.rect[2], e.view[3] - h.rect[3] + e.view[1]]), {
            pageWidth: x,
            pageHeight: k,
            pageX: R,
            pageY: D
          } = r.rawDims;
          o.left = `${100 * (A[0] - R) / x}%`, o.top = `${100 * (A[1] - D) / k}%`;
          const {
            rotation: I
          } = h;
          return h.hasOwnCanvas || I === 0 ? (o.width = `${100 * a / x}%`, o.height = `${100 * u / k}%`) : this.setRotation(I, p), p;
        }
        setRotation(m, h = this.container) {
          if (!this.data.rect)
            return;
          const {
            pageWidth: e,
            pageHeight: r
          } = this.parent.viewport.rawDims, {
            width: p,
            height: o
          } = l(this.data.rect);
          let a, u;
          m % 180 === 0 ? (a = 100 * p / e, u = 100 * o / r) : (a = 100 * o / e, u = 100 * p / r), h.style.width = `${a}%`, h.style.height = `${u}%`, h.setAttribute("data-main-rotation", (360 - m) % 360);
        }
        get _commonActions() {
          const m = (h, e, r) => {
            const p = r.detail[h], o = p[0], a = p.slice(1);
            r.target.style[e] = T[`${o}_HTML`](a), this.annotationStorage.setValue(this.data.id, {
              [e]: T[`${o}_rgb`](a)
            });
          };
          return (0, w.shadow)(this, "_commonActions", {
            display: (h) => {
              const {
                display: e
              } = h.detail, r = e % 2 === 1;
              this.container.style.visibility = r ? "hidden" : "visible", this.annotationStorage.setValue(this.data.id, {
                noView: r,
                noPrint: e === 1 || e === 2
              });
            },
            print: (h) => {
              this.annotationStorage.setValue(this.data.id, {
                noPrint: !h.detail.print
              });
            },
            hidden: (h) => {
              const {
                hidden: e
              } = h.detail;
              this.container.style.visibility = e ? "hidden" : "visible", this.annotationStorage.setValue(this.data.id, {
                noPrint: e,
                noView: e
              });
            },
            focus: (h) => {
              setTimeout(() => h.target.focus({
                preventScroll: !1
              }), 0);
            },
            userName: (h) => {
              h.target.title = h.detail.userName;
            },
            readonly: (h) => {
              h.target.disabled = h.detail.readonly;
            },
            required: (h) => {
              this._setRequired(h.target, h.detail.required);
            },
            bgColor: (h) => {
              m("bgColor", "backgroundColor", h);
            },
            fillColor: (h) => {
              m("fillColor", "backgroundColor", h);
            },
            fgColor: (h) => {
              m("fgColor", "color", h);
            },
            textColor: (h) => {
              m("textColor", "color", h);
            },
            borderColor: (h) => {
              m("borderColor", "borderColor", h);
            },
            strokeColor: (h) => {
              m("strokeColor", "borderColor", h);
            },
            rotation: (h) => {
              const e = h.detail.rotation;
              this.setRotation(e), this.annotationStorage.setValue(this.data.id, {
                rotation: e
              });
            }
          });
        }
        _dispatchEventFromSandbox(m, h) {
          const e = this._commonActions;
          for (const r of Object.keys(h.detail))
            (m[r] || e[r])?.(h);
        }
        _setDefaultPropertiesFromJS(m) {
          if (!this.enableScripting)
            return;
          const h = this.annotationStorage.getRawValue(this.data.id);
          if (!h)
            return;
          const e = this._commonActions;
          for (const [r, p] of Object.entries(h)) {
            const o = e[r];
            if (o) {
              const a = {
                detail: {
                  [r]: p
                },
                target: m
              };
              o(a), delete h[r];
            }
          }
        }
        _createQuadrilaterals() {
          if (!this.container)
            return;
          const {
            quadPoints: m
          } = this.data;
          if (!m)
            return;
          const [h, e, r, p] = this.data.rect;
          if (m.length === 1) {
            const [, {
              x: F,
              y: C
            }, {
              x: $,
              y: K
            }] = m[0];
            if (r === F && p === C && h === $ && e === K)
              return;
          }
          const {
            style: o
          } = this.container;
          let a;
          if (this.#e) {
            const {
              borderColor: F,
              borderWidth: C
            } = o;
            o.borderWidth = 0, a = ["url('data:image/svg+xml;utf8,", '<svg xmlns="http://www.w3.org/2000/svg"', ' preserveAspectRatio="none" viewBox="0 0 1 1">', `<g fill="transparent" stroke="${F}" stroke-width="${C}">`], this.container.classList.add("hasBorder");
          }
          const u = r - h, A = p - e, {
            svgFactory: x
          } = this, k = x.createElement("svg");
          k.classList.add("quadrilateralsContainer"), k.setAttribute("width", 0), k.setAttribute("height", 0);
          const R = x.createElement("defs");
          k.append(R);
          const D = x.createElement("clipPath"), I = `clippath_${this.data.id}`;
          D.setAttribute("id", I), D.setAttribute("clipPathUnits", "objectBoundingBox"), R.append(D);
          for (const [, {
            x: F,
            y: C
          }, {
            x: $,
            y: K
          }] of m) {
            const X = x.createElement("rect"), W = ($ - h) / u, rt = (p - C) / A, J = (F - $) / u, Q = (C - K) / A;
            X.setAttribute("x", W), X.setAttribute("y", rt), X.setAttribute("width", J), X.setAttribute("height", Q), D.append(X), a?.push(`<rect vector-effect="non-scaling-stroke" x="${W}" y="${rt}" width="${J}" height="${Q}"/>`);
          }
          this.#e && (a.push("</g></svg>')"), o.backgroundImage = a.join("")), this.container.append(k), this.container.style.clipPath = `url(#${I})`;
        }
        _createPopup() {
          const {
            container: m,
            data: h
          } = this;
          m.setAttribute("aria-haspopup", "dialog");
          const e = new N({
            data: {
              color: h.color,
              titleObj: h.titleObj,
              modificationDate: h.modificationDate,
              contentsObj: h.contentsObj,
              richText: h.richText,
              parentRect: h.rect,
              borderStyle: 0,
              id: `popup_${h.id}`,
              rotation: h.rotation
            },
            parent: this.parent,
            elements: [this]
          });
          this.parent.div.append(e.render());
        }
        render() {
          (0, w.unreachable)("Abstract method `AnnotationElement.render` called");
        }
        _getElementsByName(m, h = null) {
          const e = [];
          if (this._fieldObjects) {
            const r = this._fieldObjects[m];
            if (r)
              for (const {
                page: p,
                id: o,
                exportValues: a
              } of r) {
                if (p === -1 || o === h)
                  continue;
                const u = typeof a == "string" ? a : null, A = document.querySelector(`[data-element-id="${o}"]`);
                if (A && !c.has(A)) {
                  (0, w.warn)(`_getElementsByName - element not allowed: ${o}`);
                  continue;
                }
                e.push({
                  id: o,
                  exportValue: u,
                  domElement: A
                });
              }
            return e;
          }
          for (const r of document.getElementsByName(m)) {
            const {
              exportValue: p
            } = r, o = r.getAttribute("data-element-id");
            o !== h && c.has(r) && e.push({
              id: o,
              exportValue: p,
              domElement: r
            });
          }
          return e;
        }
        show() {
          this.container && (this.container.hidden = !1), this.popup?.maybeShow();
        }
        hide() {
          this.container && (this.container.hidden = !0), this.popup?.forceHide();
        }
        getElementsToTriggerPopup() {
          return this.container;
        }
        addHighlightArea() {
          const m = this.getElementsToTriggerPopup();
          if (Array.isArray(m))
            for (const h of m)
              h.classList.add("highlightArea");
          else
            m.classList.add("highlightArea");
        }
        get _isEditable() {
          return !1;
        }
        _editOnDoubleClick() {
          if (!this._isEditable)
            return;
          const {
            annotationEditorType: m,
            data: {
              id: h
            }
          } = this;
          this.container.addEventListener("dblclick", () => {
            this.linkService.eventBus?.dispatch("switchannotationeditormode", {
              source: this,
              mode: m,
              editId: h
            });
          });
        }
      }
      class g extends s {
        constructor(m, h = null) {
          super(m, {
            isRenderable: !0,
            ignoreBorder: !!h?.ignoreBorder,
            createQuadrilaterals: !0
          }), this.isTooltipOnly = m.data.isTooltipOnly;
        }
        render() {
          const {
            data: m,
            linkService: h
          } = this, e = document.createElement("a");
          e.setAttribute("data-element-id", m.id);
          let r = !1;
          return m.url ? (h.addLinkAttributes(e, m.url, m.newWindow), r = !0) : m.action ? (this._bindNamedAction(e, m.action), r = !0) : m.attachment ? (this.#e(e, m.attachment, m.attachmentDest), r = !0) : m.setOCGState ? (this.#s(e, m.setOCGState), r = !0) : m.dest ? (this._bindLink(e, m.dest), r = !0) : (m.actions && (m.actions.Action || m.actions["Mouse Up"] || m.actions["Mouse Down"]) && this.enableScripting && this.hasJSActions && (this._bindJSAction(e, m), r = !0), m.resetForm ? (this._bindResetFormAction(e, m.resetForm), r = !0) : this.isTooltipOnly && !r && (this._bindLink(e, ""), r = !0)), this.container.classList.add("linkAnnotation"), r && this.container.append(e), this.container;
        }
        #t() {
          this.container.setAttribute("data-internal-link", "");
        }
        _bindLink(m, h) {
          m.href = this.linkService.getDestinationHash(h), m.onclick = () => (h && this.linkService.goToDestination(h), !1), (h || h === "") && this.#t();
        }
        _bindNamedAction(m, h) {
          m.href = this.linkService.getAnchorUrl(""), m.onclick = () => (this.linkService.executeNamedAction(h), !1), this.#t();
        }
        #e(m, h, e = null) {
          m.href = this.linkService.getAnchorUrl(""), m.onclick = () => (this.downloadManager?.openOrDownloadData(h.content, h.filename, e), !1), this.#t();
        }
        #s(m, h) {
          m.href = this.linkService.getAnchorUrl(""), m.onclick = () => (this.linkService.executeSetOCGState(h), !1), this.#t();
        }
        _bindJSAction(m, h) {
          m.href = this.linkService.getAnchorUrl("");
          const e = /* @__PURE__ */ new Map([["Action", "onclick"], ["Mouse Up", "onmouseup"], ["Mouse Down", "onmousedown"]]);
          for (const r of Object.keys(h.actions)) {
            const p = e.get(r);
            p && (m[p] = () => (this.linkService.eventBus?.dispatch("dispatcheventinsandbox", {
              source: this,
              detail: {
                id: h.id,
                name: r
              }
            }), !1));
          }
          m.onclick || (m.onclick = () => !1), this.#t();
        }
        _bindResetFormAction(m, h) {
          const e = m.onclick;
          if (e || (m.href = this.linkService.getAnchorUrl("")), this.#t(), !this._fieldObjects) {
            (0, w.warn)('_bindResetFormAction - "resetForm" action not supported, ensure that the `fieldObjects` parameter is provided.'), e || (m.onclick = () => !1);
            return;
          }
          m.onclick = () => {
            e?.();
            const {
              fields: r,
              refs: p,
              include: o
            } = h, a = [];
            if (r.length !== 0 || p.length !== 0) {
              const x = new Set(p);
              for (const k of r) {
                const R = this._fieldObjects[k] || [];
                for (const {
                  id: D
                } of R)
                  x.add(D);
              }
              for (const k of Object.values(this._fieldObjects))
                for (const R of k)
                  x.has(R.id) === o && a.push(R);
            } else
              for (const x of Object.values(this._fieldObjects))
                a.push(...x);
            const u = this.annotationStorage, A = [];
            for (const x of a) {
              const {
                id: k
              } = x;
              switch (A.push(k), x.type) {
                case "text": {
                  const D = x.defaultValue || "";
                  u.setValue(k, {
                    value: D
                  });
                  break;
                }
                case "checkbox":
                case "radiobutton": {
                  const D = x.defaultValue === x.exportValues;
                  u.setValue(k, {
                    value: D
                  });
                  break;
                }
                case "combobox":
                case "listbox": {
                  const D = x.defaultValue || "";
                  u.setValue(k, {
                    value: D
                  });
                  break;
                }
                default:
                  continue;
              }
              const R = document.querySelector(`[data-element-id="${k}"]`);
              if (R) {
                if (!c.has(R)) {
                  (0, w.warn)(`_bindResetFormAction - element not allowed: ${k}`);
                  continue;
                }
              } else continue;
              R.dispatchEvent(new Event("resetform"));
            }
            return this.enableScripting && this.linkService.eventBus?.dispatch("dispatcheventinsandbox", {
              source: this,
              detail: {
                id: "app",
                ids: A,
                name: "ResetForm"
              }
            }), !1;
          };
        }
      }
      class t extends s {
        constructor(m) {
          super(m, {
            isRenderable: !0
          });
        }
        render() {
          this.container.classList.add("textAnnotation");
          const m = document.createElement("img");
          return m.src = this.imageResourcesPath + "annotation-" + this.data.name.toLowerCase() + ".svg", m.setAttribute("data-l10n-id", "pdfjs-text-annotation-type"), m.setAttribute("data-l10n-args", JSON.stringify({
            type: this.data.name
          })), !this.data.popupRef && this.hasPopupData && this._createPopup(), this.container.append(m), this.container;
        }
      }
      class i extends s {
        render() {
          return this.container;
        }
        showElementAndHideCanvas(m) {
          this.data.hasOwnCanvas && (m.previousSibling?.nodeName === "CANVAS" && (m.previousSibling.hidden = !0), m.hidden = !1);
        }
        _getKeyModifier(m) {
          return w.FeatureTest.platform.isMac ? m.metaKey : m.ctrlKey;
        }
        _setEventListener(m, h, e, r, p) {
          e.includes("mouse") ? m.addEventListener(e, (o) => {
            this.linkService.eventBus?.dispatch("dispatcheventinsandbox", {
              source: this,
              detail: {
                id: this.data.id,
                name: r,
                value: p(o),
                shift: o.shiftKey,
                modifier: this._getKeyModifier(o)
              }
            });
          }) : m.addEventListener(e, (o) => {
            if (e === "blur") {
              if (!h.focused || !o.relatedTarget)
                return;
              h.focused = !1;
            } else if (e === "focus") {
              if (h.focused)
                return;
              h.focused = !0;
            }
            p && this.linkService.eventBus?.dispatch("dispatcheventinsandbox", {
              source: this,
              detail: {
                id: this.data.id,
                name: r,
                value: p(o)
              }
            });
          });
        }
        _setEventListeners(m, h, e, r) {
          for (const [p, o] of e)
            (o === "Action" || this.data.actions?.[o]) && ((o === "Focus" || o === "Blur") && (h ||= {
              focused: !1
            }), this._setEventListener(m, h, p, o, r), o === "Focus" && !this.data.actions?.Blur ? this._setEventListener(m, h, "blur", "Blur", null) : o === "Blur" && !this.data.actions?.Focus && this._setEventListener(m, h, "focus", "Focus", null));
        }
        _setBackgroundColor(m) {
          const h = this.data.backgroundColor || null;
          m.style.backgroundColor = h === null ? "transparent" : w.Util.makeHexColor(h[0], h[1], h[2]);
        }
        _setTextStyle(m) {
          const h = ["left", "center", "right"], {
            fontColor: e
          } = this.data.defaultAppearanceData, r = this.data.defaultAppearanceData.fontSize || n, p = m.style;
          let o;
          const a = 2, u = (A) => Math.round(10 * A) / 10;
          if (this.data.multiLine) {
            const A = Math.abs(this.data.rect[3] - this.data.rect[1] - a), x = Math.round(A / (w.LINE_FACTOR * r)) || 1, k = A / x;
            o = Math.min(r, u(k / w.LINE_FACTOR));
          } else {
            const A = Math.abs(this.data.rect[3] - this.data.rect[1] - a);
            o = Math.min(r, u(A / w.LINE_FACTOR));
          }
          p.fontSize = `calc(${o}px * var(--scale-factor))`, p.color = w.Util.makeHexColor(e[0], e[1], e[2]), this.data.textAlignment !== null && (p.textAlign = h[this.data.textAlignment]);
        }
        _setRequired(m, h) {
          h ? m.setAttribute("required", !0) : m.removeAttribute("required"), m.setAttribute("aria-required", h);
        }
      }
      class d extends i {
        constructor(m) {
          const h = m.renderForms || m.data.hasOwnCanvas || !m.data.hasAppearance && !!m.data.fieldValue;
          super(m, {
            isRenderable: h
          });
        }
        setPropertyOnSiblings(m, h, e, r) {
          const p = this.annotationStorage;
          for (const o of this._getElementsByName(m.name, m.id))
            o.domElement && (o.domElement[h] = e), p.setValue(o.id, {
              [r]: e
            });
        }
        render() {
          const m = this.annotationStorage, h = this.data.id;
          this.container.classList.add("textWidgetAnnotation");
          let e = null;
          if (this.renderForms) {
            const r = m.getValue(h, {
              value: this.data.fieldValue
            });
            let p = r.value || "";
            const o = m.getValue(h, {
              charLimit: this.data.maxLen
            }).charLimit;
            o && p.length > o && (p = p.slice(0, o));
            let a = r.formattedValue || this.data.textContent?.join(`
`) || null;
            a && this.data.comb && (a = a.replaceAll(/\s+/g, ""));
            const u = {
              userValue: p,
              formattedValue: a,
              lastCommittedValue: null,
              commitKey: 1,
              focused: !1
            };
            this.data.multiLine ? (e = document.createElement("textarea"), e.textContent = a ?? p, this.data.doNotScroll && (e.style.overflowY = "hidden")) : (e = document.createElement("input"), e.type = "text", e.setAttribute("value", a ?? p), this.data.doNotScroll && (e.style.overflowX = "hidden")), this.data.hasOwnCanvas && (e.hidden = !0), c.add(e), e.setAttribute("data-element-id", h), e.disabled = this.data.readOnly, e.name = this.data.fieldName, e.tabIndex = v, this._setRequired(e, this.data.required), o && (e.maxLength = o), e.addEventListener("input", (x) => {
              m.setValue(h, {
                value: x.target.value
              }), this.setPropertyOnSiblings(e, "value", x.target.value, "value"), u.formattedValue = null;
            }), e.addEventListener("resetform", (x) => {
              const k = this.data.defaultFieldValue ?? "";
              e.value = u.userValue = k, u.formattedValue = null;
            });
            let A = (x) => {
              const {
                formattedValue: k
              } = u;
              k != null && (x.target.value = k), x.target.scrollLeft = 0;
            };
            if (this.enableScripting && this.hasJSActions) {
              e.addEventListener("focus", (k) => {
                if (u.focused)
                  return;
                const {
                  target: R
                } = k;
                u.userValue && (R.value = u.userValue), u.lastCommittedValue = R.value, u.commitKey = 1, this.data.actions?.Focus || (u.focused = !0);
              }), e.addEventListener("updatefromsandbox", (k) => {
                this.showElementAndHideCanvas(k.target);
                const R = {
                  value(D) {
                    u.userValue = D.detail.value ?? "", m.setValue(h, {
                      value: u.userValue.toString()
                    }), D.target.value = u.userValue;
                  },
                  formattedValue(D) {
                    const {
                      formattedValue: I
                    } = D.detail;
                    u.formattedValue = I, I != null && D.target !== document.activeElement && (D.target.value = I), m.setValue(h, {
                      formattedValue: I
                    });
                  },
                  selRange(D) {
                    D.target.setSelectionRange(...D.detail.selRange);
                  },
                  charLimit: (D) => {
                    const {
                      charLimit: I
                    } = D.detail, {
                      target: F
                    } = D;
                    if (I === 0) {
                      F.removeAttribute("maxLength");
                      return;
                    }
                    F.setAttribute("maxLength", I);
                    let C = u.userValue;
                    !C || C.length <= I || (C = C.slice(0, I), F.value = u.userValue = C, m.setValue(h, {
                      value: C
                    }), this.linkService.eventBus?.dispatch("dispatcheventinsandbox", {
                      source: this,
                      detail: {
                        id: h,
                        name: "Keystroke",
                        value: C,
                        willCommit: !0,
                        commitKey: 1,
                        selStart: F.selectionStart,
                        selEnd: F.selectionEnd
                      }
                    }));
                  }
                };
                this._dispatchEventFromSandbox(R, k);
              }), e.addEventListener("keydown", (k) => {
                u.commitKey = 1;
                let R = -1;
                if (k.key === "Escape" ? R = 0 : k.key === "Enter" && !this.data.multiLine ? R = 2 : k.key === "Tab" && (u.commitKey = 3), R === -1)
                  return;
                const {
                  value: D
                } = k.target;
                u.lastCommittedValue !== D && (u.lastCommittedValue = D, u.userValue = D, this.linkService.eventBus?.dispatch("dispatcheventinsandbox", {
                  source: this,
                  detail: {
                    id: h,
                    name: "Keystroke",
                    value: D,
                    willCommit: !0,
                    commitKey: R,
                    selStart: k.target.selectionStart,
                    selEnd: k.target.selectionEnd
                  }
                }));
              });
              const x = A;
              A = null, e.addEventListener("blur", (k) => {
                if (!u.focused || !k.relatedTarget)
                  return;
                this.data.actions?.Blur || (u.focused = !1);
                const {
                  value: R
                } = k.target;
                u.userValue = R, u.lastCommittedValue !== R && this.linkService.eventBus?.dispatch("dispatcheventinsandbox", {
                  source: this,
                  detail: {
                    id: h,
                    name: "Keystroke",
                    value: R,
                    willCommit: !0,
                    commitKey: u.commitKey,
                    selStart: k.target.selectionStart,
                    selEnd: k.target.selectionEnd
                  }
                }), x(k);
              }), this.data.actions?.Keystroke && e.addEventListener("beforeinput", (k) => {
                u.lastCommittedValue = null;
                const {
                  data: R,
                  target: D
                } = k, {
                  value: I,
                  selectionStart: F,
                  selectionEnd: C
                } = D;
                let $ = F, K = C;
                switch (k.inputType) {
                  case "deleteWordBackward": {
                    const X = I.substring(0, F).match(/\w*[^\w]*$/);
                    X && ($ -= X[0].length);
                    break;
                  }
                  case "deleteWordForward": {
                    const X = I.substring(F).match(/^[^\w]*\w*/);
                    X && (K += X[0].length);
                    break;
                  }
                  case "deleteContentBackward":
                    F === C && ($ -= 1);
                    break;
                  case "deleteContentForward":
                    F === C && (K += 1);
                    break;
                }
                k.preventDefault(), this.linkService.eventBus?.dispatch("dispatcheventinsandbox", {
                  source: this,
                  detail: {
                    id: h,
                    name: "Keystroke",
                    value: I,
                    change: R || "",
                    willCommit: !1,
                    selStart: $,
                    selEnd: K
                  }
                });
              }), this._setEventListeners(e, u, [["focus", "Focus"], ["blur", "Blur"], ["mousedown", "Mouse Down"], ["mouseenter", "Mouse Enter"], ["mouseleave", "Mouse Exit"], ["mouseup", "Mouse Up"]], (k) => k.target.value);
            }
            if (A && e.addEventListener("blur", A), this.data.comb) {
              const k = (this.data.rect[2] - this.data.rect[0]) / o;
              e.classList.add("comb"), e.style.letterSpacing = `calc(${k}px * var(--scale-factor) - 1ch)`;
            }
          } else
            e = document.createElement("div"), e.textContent = this.data.fieldValue, e.style.verticalAlign = "middle", e.style.display = "table-cell", this.data.hasOwnCanvas && (e.hidden = !0);
          return this._setTextStyle(e), this._setBackgroundColor(e), this._setDefaultPropertiesFromJS(e), this.container.append(e), this.container;
        }
      }
      class f extends i {
        constructor(m) {
          super(m, {
            isRenderable: !!m.data.hasOwnCanvas
          });
        }
      }
      class y extends i {
        constructor(m) {
          super(m, {
            isRenderable: m.renderForms
          });
        }
        render() {
          const m = this.annotationStorage, h = this.data, e = h.id;
          let r = m.getValue(e, {
            value: h.exportValue === h.fieldValue
          }).value;
          typeof r == "string" && (r = r !== "Off", m.setValue(e, {
            value: r
          })), this.container.classList.add("buttonWidgetAnnotation", "checkBox");
          const p = document.createElement("input");
          return c.add(p), p.setAttribute("data-element-id", e), p.disabled = h.readOnly, this._setRequired(p, this.data.required), p.type = "checkbox", p.name = h.fieldName, r && p.setAttribute("checked", !0), p.setAttribute("exportValue", h.exportValue), p.tabIndex = v, p.addEventListener("change", (o) => {
            const {
              name: a,
              checked: u
            } = o.target;
            for (const A of this._getElementsByName(a, e)) {
              const x = u && A.exportValue === h.exportValue;
              A.domElement && (A.domElement.checked = x), m.setValue(A.id, {
                value: x
              });
            }
            m.setValue(e, {
              value: u
            });
          }), p.addEventListener("resetform", (o) => {
            const a = h.defaultFieldValue || "Off";
            o.target.checked = a === h.exportValue;
          }), this.enableScripting && this.hasJSActions && (p.addEventListener("updatefromsandbox", (o) => {
            const a = {
              value(u) {
                u.target.checked = u.detail.value !== "Off", m.setValue(e, {
                  value: u.target.checked
                });
              }
            };
            this._dispatchEventFromSandbox(a, o);
          }), this._setEventListeners(p, null, [["change", "Validate"], ["change", "Action"], ["focus", "Focus"], ["blur", "Blur"], ["mousedown", "Mouse Down"], ["mouseenter", "Mouse Enter"], ["mouseleave", "Mouse Exit"], ["mouseup", "Mouse Up"]], (o) => o.target.checked)), this._setBackgroundColor(p), this._setDefaultPropertiesFromJS(p), this.container.append(p), this.container;
        }
      }
      class S extends i {
        constructor(m) {
          super(m, {
            isRenderable: m.renderForms
          });
        }
        render() {
          this.container.classList.add("buttonWidgetAnnotation", "radioButton");
          const m = this.annotationStorage, h = this.data, e = h.id;
          let r = m.getValue(e, {
            value: h.fieldValue === h.buttonValue
          }).value;
          if (typeof r == "string" && (r = r !== h.buttonValue, m.setValue(e, {
            value: r
          })), r)
            for (const o of this._getElementsByName(h.fieldName, e))
              m.setValue(o.id, {
                value: !1
              });
          const p = document.createElement("input");
          if (c.add(p), p.setAttribute("data-element-id", e), p.disabled = h.readOnly, this._setRequired(p, this.data.required), p.type = "radio", p.name = h.fieldName, r && p.setAttribute("checked", !0), p.tabIndex = v, p.addEventListener("change", (o) => {
            const {
              name: a,
              checked: u
            } = o.target;
            for (const A of this._getElementsByName(a, e))
              m.setValue(A.id, {
                value: !1
              });
            m.setValue(e, {
              value: u
            });
          }), p.addEventListener("resetform", (o) => {
            const a = h.defaultFieldValue;
            o.target.checked = a != null && a === h.buttonValue;
          }), this.enableScripting && this.hasJSActions) {
            const o = h.buttonValue;
            p.addEventListener("updatefromsandbox", (a) => {
              const u = {
                value: (A) => {
                  const x = o === A.detail.value;
                  for (const k of this._getElementsByName(A.target.name)) {
                    const R = x && k.id === e;
                    k.domElement && (k.domElement.checked = R), m.setValue(k.id, {
                      value: R
                    });
                  }
                }
              };
              this._dispatchEventFromSandbox(u, a);
            }), this._setEventListeners(p, null, [["change", "Validate"], ["change", "Action"], ["focus", "Focus"], ["blur", "Blur"], ["mousedown", "Mouse Down"], ["mouseenter", "Mouse Enter"], ["mouseleave", "Mouse Exit"], ["mouseup", "Mouse Up"]], (a) => a.target.checked);
          }
          return this._setBackgroundColor(p), this._setDefaultPropertiesFromJS(p), this.container.append(p), this.container;
        }
      }
      class L extends g {
        constructor(m) {
          super(m, {
            ignoreBorder: m.data.hasAppearance
          });
        }
        render() {
          const m = super.render();
          m.classList.add("buttonWidgetAnnotation", "pushButton");
          const h = m.lastChild;
          return this.enableScripting && this.hasJSActions && h && (this._setDefaultPropertiesFromJS(h), h.addEventListener("updatefromsandbox", (e) => {
            this._dispatchEventFromSandbox({}, e);
          })), m;
        }
      }
      class M extends i {
        constructor(m) {
          super(m, {
            isRenderable: m.renderForms
          });
        }
        render() {
          this.container.classList.add("choiceWidgetAnnotation");
          const m = this.annotationStorage, h = this.data.id, e = m.getValue(h, {
            value: this.data.fieldValue
          }), r = document.createElement("select");
          c.add(r), r.setAttribute("data-element-id", h), r.disabled = this.data.readOnly, this._setRequired(r, this.data.required), r.name = this.data.fieldName, r.tabIndex = v;
          let p = this.data.combo && this.data.options.length > 0;
          this.data.combo || (r.size = this.data.options.length, this.data.multiSelect && (r.multiple = !0)), r.addEventListener("resetform", (x) => {
            const k = this.data.defaultFieldValue;
            for (const R of r.options)
              R.selected = R.value === k;
          });
          for (const x of this.data.options) {
            const k = document.createElement("option");
            k.textContent = x.displayValue, k.value = x.exportValue, e.value.includes(x.exportValue) && (k.setAttribute("selected", !0), p = !1), r.append(k);
          }
          let o = null;
          if (p) {
            const x = document.createElement("option");
            x.value = " ", x.setAttribute("hidden", !0), x.setAttribute("selected", !0), r.prepend(x), o = () => {
              x.remove(), r.removeEventListener("input", o), o = null;
            }, r.addEventListener("input", o);
          }
          const a = (x) => {
            const k = x ? "value" : "textContent", {
              options: R,
              multiple: D
            } = r;
            return D ? Array.prototype.filter.call(R, (I) => I.selected).map((I) => I[k]) : R.selectedIndex === -1 ? null : R[R.selectedIndex][k];
          };
          let u = a(!1);
          const A = (x) => {
            const k = x.target.options;
            return Array.prototype.map.call(k, (R) => ({
              displayValue: R.textContent,
              exportValue: R.value
            }));
          };
          return this.enableScripting && this.hasJSActions ? (r.addEventListener("updatefromsandbox", (x) => {
            const k = {
              value(R) {
                o?.();
                const D = R.detail.value, I = new Set(Array.isArray(D) ? D : [D]);
                for (const F of r.options)
                  F.selected = I.has(F.value);
                m.setValue(h, {
                  value: a(!0)
                }), u = a(!1);
              },
              multipleSelection(R) {
                r.multiple = !0;
              },
              remove(R) {
                const D = r.options, I = R.detail.remove;
                D[I].selected = !1, r.remove(I), D.length > 0 && Array.prototype.findIndex.call(D, (C) => C.selected) === -1 && (D[0].selected = !0), m.setValue(h, {
                  value: a(!0),
                  items: A(R)
                }), u = a(!1);
              },
              clear(R) {
                for (; r.length !== 0; )
                  r.remove(0);
                m.setValue(h, {
                  value: null,
                  items: []
                }), u = a(!1);
              },
              insert(R) {
                const {
                  index: D,
                  displayValue: I,
                  exportValue: F
                } = R.detail.insert, C = r.children[D], $ = document.createElement("option");
                $.textContent = I, $.value = F, C ? C.before($) : r.append($), m.setValue(h, {
                  value: a(!0),
                  items: A(R)
                }), u = a(!1);
              },
              items(R) {
                const {
                  items: D
                } = R.detail;
                for (; r.length !== 0; )
                  r.remove(0);
                for (const I of D) {
                  const {
                    displayValue: F,
                    exportValue: C
                  } = I, $ = document.createElement("option");
                  $.textContent = F, $.value = C, r.append($);
                }
                r.options.length > 0 && (r.options[0].selected = !0), m.setValue(h, {
                  value: a(!0),
                  items: A(R)
                }), u = a(!1);
              },
              indices(R) {
                const D = new Set(R.detail.indices);
                for (const I of R.target.options)
                  I.selected = D.has(I.index);
                m.setValue(h, {
                  value: a(!0)
                }), u = a(!1);
              },
              editable(R) {
                R.target.disabled = !R.detail.editable;
              }
            };
            this._dispatchEventFromSandbox(k, x);
          }), r.addEventListener("input", (x) => {
            const k = a(!0), R = a(!1);
            m.setValue(h, {
              value: k
            }), x.preventDefault(), this.linkService.eventBus?.dispatch("dispatcheventinsandbox", {
              source: this,
              detail: {
                id: h,
                name: "Keystroke",
                value: u,
                change: R,
                changeEx: k,
                willCommit: !1,
                commitKey: 1,
                keyDown: !1
              }
            });
          }), this._setEventListeners(r, null, [["focus", "Focus"], ["blur", "Blur"], ["mousedown", "Mouse Down"], ["mouseenter", "Mouse Enter"], ["mouseleave", "Mouse Exit"], ["mouseup", "Mouse Up"], ["input", "Action"], ["input", "Validate"]], (x) => x.target.value)) : r.addEventListener("input", function(x) {
            m.setValue(h, {
              value: a(!0)
            });
          }), this.data.combo && this._setTextStyle(r), this._setBackgroundColor(r), this._setDefaultPropertiesFromJS(r), this.container.append(r), this.container;
        }
      }
      class N extends s {
        constructor(m) {
          const {
            data: h,
            elements: e
          } = m;
          super(m, {
            isRenderable: s._hasPopupData(h)
          }), this.elements = e;
        }
        render() {
          this.container.classList.add("popupAnnotation");
          const m = new H({
            container: this.container,
            color: this.data.color,
            titleObj: this.data.titleObj,
            modificationDate: this.data.modificationDate,
            contentsObj: this.data.contentsObj,
            richText: this.data.richText,
            rect: this.data.rect,
            parentRect: this.data.parentRect || null,
            parent: this.parent,
            elements: this.elements,
            open: this.data.open
          }), h = [];
          for (const e of this.elements)
            e.popup = m, h.push(e.data.id), e.addHighlightArea();
          return this.container.setAttribute("aria-controls", h.map((e) => `${w.AnnotationPrefix}${e}`).join(",")), this.container;
        }
      }
      class H {
        #t = this.#m.bind(this);
        #e = this.#C.bind(this);
        #s = this.#w.bind(this);
        #n = this.#v.bind(this);
        #r = null;
        #i = null;
        #a = null;
        #l = null;
        #h = null;
        #d = null;
        #u = null;
        #c = !1;
        #o = null;
        #p = null;
        #g = null;
        #f = null;
        #A = !1;
        constructor({
          container: m,
          color: h,
          elements: e,
          titleObj: r,
          modificationDate: p,
          contentsObj: o,
          richText: a,
          parent: u,
          rect: A,
          parentRect: x,
          open: k
        }) {
          this.#i = m, this.#f = r, this.#a = o, this.#g = a, this.#d = u, this.#r = h, this.#p = A, this.#u = x, this.#h = e, this.#l = B.PDFDateString.toDateObject(p), this.trigger = e.flatMap((R) => R.getElementsToTriggerPopup());
          for (const R of this.trigger)
            R.addEventListener("click", this.#n), R.addEventListener("mouseenter", this.#s), R.addEventListener("mouseleave", this.#e), R.classList.add("popupTriggerArea");
          for (const R of e)
            R.container?.addEventListener("keydown", this.#t);
          this.#i.hidden = !0, k && this.#v();
        }
        render() {
          if (this.#o)
            return;
          const {
            page: {
              view: m
            },
            viewport: {
              rawDims: {
                pageWidth: h,
                pageHeight: e,
                pageX: r,
                pageY: p
              }
            }
          } = this.#d, o = this.#o = document.createElement("div");
          if (o.className = "popup", this.#r) {
            const X = o.style.outlineColor = w.Util.makeHexColor(...this.#r);
            CSS.supports("background-color", "color-mix(in srgb, red 30%, white)") ? o.style.backgroundColor = `color-mix(in srgb, ${X} 30%, white)` : o.style.backgroundColor = w.Util.makeHexColor(...this.#r.map((rt) => Math.floor(0.7 * (255 - rt) + rt)));
          }
          const a = document.createElement("span");
          a.className = "header";
          const u = document.createElement("h1");
          if (a.append(u), {
            dir: u.dir,
            str: u.textContent
          } = this.#f, o.append(a), this.#l) {
            const X = document.createElement("span");
            X.classList.add("popupDate"), X.setAttribute("data-l10n-id", "pdfjs-annotation-date-string"), X.setAttribute("data-l10n-args", JSON.stringify({
              date: this.#l.toLocaleDateString(),
              time: this.#l.toLocaleTimeString()
            })), a.append(X);
          }
          const A = this.#a, x = this.#g;
          if (x?.str && (!A?.str || A.str === x.str))
            E.XfaLayer.render({
              xfaHtml: x.html,
              intent: "richText",
              div: o
            }), o.lastChild.classList.add("richText", "popupContent");
          else {
            const X = this._formatContents(A);
            o.append(X);
          }
          let k = !!this.#u, R = k ? this.#u : this.#p;
          for (const X of this.#h)
            if (!R || w.Util.intersect(X.data.rect, R) !== null) {
              R = X.data.rect, k = !0;
              break;
            }
          const D = w.Util.normalizeRect([R[0], m[3] - R[1] + m[1], R[2], m[3] - R[3] + m[1]]), F = k ? R[2] - R[0] + 5 : 0, C = D[0] + F, $ = D[1], {
            style: K
          } = this.#i;
          K.left = `${100 * (C - r) / h}%`, K.top = `${100 * ($ - p) / e}%`, this.#i.append(o);
        }
        _formatContents({
          str: m,
          dir: h
        }) {
          const e = document.createElement("p");
          e.classList.add("popupContent"), e.dir = h;
          const r = m.split(/(?:\r\n?|\n)/);
          for (let p = 0, o = r.length; p < o; ++p) {
            const a = r[p];
            e.append(document.createTextNode(a)), p < o - 1 && e.append(document.createElement("br"));
          }
          return e;
        }
        #m(m) {
          m.altKey || m.shiftKey || m.ctrlKey || m.metaKey || (m.key === "Enter" || m.key === "Escape" && this.#c) && this.#v();
        }
        #v() {
          this.#c = !this.#c, this.#c ? (this.#w(), this.#i.addEventListener("click", this.#n), this.#i.addEventListener("keydown", this.#t)) : (this.#C(), this.#i.removeEventListener("click", this.#n), this.#i.removeEventListener("keydown", this.#t));
        }
        #w() {
          this.#o || this.render(), this.isVisible ? this.#c && this.#i.classList.add("focused") : (this.#i.hidden = !1, this.#i.style.zIndex = parseInt(this.#i.style.zIndex) + 1e3);
        }
        #C() {
          this.#i.classList.remove("focused"), !(this.#c || !this.isVisible) && (this.#i.hidden = !0, this.#i.style.zIndex = parseInt(this.#i.style.zIndex) - 1e3);
        }
        forceHide() {
          this.#A = this.isVisible, this.#A && (this.#i.hidden = !0);
        }
        maybeShow() {
          this.#A && (this.#A = !1, this.#i.hidden = !1);
        }
        get isVisible() {
          return this.#i.hidden === !1;
        }
      }
      class z extends s {
        constructor(m) {
          super(m, {
            isRenderable: !0,
            ignoreBorder: !0
          }), this.textContent = m.data.textContent, this.textPosition = m.data.textPosition, this.annotationEditorType = w.AnnotationEditorType.FREETEXT;
        }
        render() {
          if (this.container.classList.add("freeTextAnnotation"), this.textContent) {
            const m = document.createElement("div");
            m.classList.add("annotationTextContent"), m.setAttribute("role", "comment");
            for (const h of this.textContent) {
              const e = document.createElement("span");
              e.textContent = h, m.append(e);
            }
            this.container.append(m);
          }
          return !this.data.popupRef && this.hasPopupData && this._createPopup(), this._editOnDoubleClick(), this.container;
        }
        get _isEditable() {
          return this.data.hasOwnCanvas;
        }
      }
      class q extends s {
        #t = null;
        constructor(m) {
          super(m, {
            isRenderable: !0,
            ignoreBorder: !0
          });
        }
        render() {
          this.container.classList.add("lineAnnotation");
          const m = this.data, {
            width: h,
            height: e
          } = l(m.rect), r = this.svgFactory.create(h, e, !0), p = this.#t = this.svgFactory.createElement("svg:line");
          return p.setAttribute("x1", m.rect[2] - m.lineCoordinates[0]), p.setAttribute("y1", m.rect[3] - m.lineCoordinates[1]), p.setAttribute("x2", m.rect[2] - m.lineCoordinates[2]), p.setAttribute("y2", m.rect[3] - m.lineCoordinates[3]), p.setAttribute("stroke-width", m.borderStyle.width || 1), p.setAttribute("stroke", "transparent"), p.setAttribute("fill", "transparent"), r.append(p), this.container.append(r), !m.popupRef && this.hasPopupData && this._createPopup(), this.container;
        }
        getElementsToTriggerPopup() {
          return this.#t;
        }
        addHighlightArea() {
          this.container.classList.add("highlightArea");
        }
      }
      class nt extends s {
        #t = null;
        constructor(m) {
          super(m, {
            isRenderable: !0,
            ignoreBorder: !0
          });
        }
        render() {
          this.container.classList.add("squareAnnotation");
          const m = this.data, {
            width: h,
            height: e
          } = l(m.rect), r = this.svgFactory.create(h, e, !0), p = m.borderStyle.width, o = this.#t = this.svgFactory.createElement("svg:rect");
          return o.setAttribute("x", p / 2), o.setAttribute("y", p / 2), o.setAttribute("width", h - p), o.setAttribute("height", e - p), o.setAttribute("stroke-width", p || 1), o.setAttribute("stroke", "transparent"), o.setAttribute("fill", "transparent"), r.append(o), this.container.append(r), !m.popupRef && this.hasPopupData && this._createPopup(), this.container;
        }
        getElementsToTriggerPopup() {
          return this.#t;
        }
        addHighlightArea() {
          this.container.classList.add("highlightArea");
        }
      }
      class j extends s {
        #t = null;
        constructor(m) {
          super(m, {
            isRenderable: !0,
            ignoreBorder: !0
          });
        }
        render() {
          this.container.classList.add("circleAnnotation");
          const m = this.data, {
            width: h,
            height: e
          } = l(m.rect), r = this.svgFactory.create(h, e, !0), p = m.borderStyle.width, o = this.#t = this.svgFactory.createElement("svg:ellipse");
          return o.setAttribute("cx", h / 2), o.setAttribute("cy", e / 2), o.setAttribute("rx", h / 2 - p / 2), o.setAttribute("ry", e / 2 - p / 2), o.setAttribute("stroke-width", p || 1), o.setAttribute("stroke", "transparent"), o.setAttribute("fill", "transparent"), r.append(o), this.container.append(r), !m.popupRef && this.hasPopupData && this._createPopup(), this.container;
        }
        getElementsToTriggerPopup() {
          return this.#t;
        }
        addHighlightArea() {
          this.container.classList.add("highlightArea");
        }
      }
      class O extends s {
        #t = null;
        constructor(m) {
          super(m, {
            isRenderable: !0,
            ignoreBorder: !0
          }), this.containerClassName = "polylineAnnotation", this.svgElementName = "svg:polyline";
        }
        render() {
          this.container.classList.add(this.containerClassName);
          const m = this.data, {
            width: h,
            height: e
          } = l(m.rect), r = this.svgFactory.create(h, e, !0);
          let p = [];
          for (const a of m.vertices) {
            const u = a.x - m.rect[0], A = m.rect[3] - a.y;
            p.push(u + "," + A);
          }
          p = p.join(" ");
          const o = this.#t = this.svgFactory.createElement(this.svgElementName);
          return o.setAttribute("points", p), o.setAttribute("stroke-width", m.borderStyle.width || 1), o.setAttribute("stroke", "transparent"), o.setAttribute("fill", "transparent"), r.append(o), this.container.append(r), !m.popupRef && this.hasPopupData && this._createPopup(), this.container;
        }
        getElementsToTriggerPopup() {
          return this.#t;
        }
        addHighlightArea() {
          this.container.classList.add("highlightArea");
        }
      }
      class G extends O {
        constructor(m) {
          super(m), this.containerClassName = "polygonAnnotation", this.svgElementName = "svg:polygon";
        }
      }
      class Y extends s {
        constructor(m) {
          super(m, {
            isRenderable: !0,
            ignoreBorder: !0
          });
        }
        render() {
          return this.container.classList.add("caretAnnotation"), !this.data.popupRef && this.hasPopupData && this._createPopup(), this.container;
        }
      }
      class tt extends s {
        #t = [];
        constructor(m) {
          super(m, {
            isRenderable: !0,
            ignoreBorder: !0
          }), this.containerClassName = "inkAnnotation", this.svgElementName = "svg:polyline", this.annotationEditorType = w.AnnotationEditorType.INK;
        }
        render() {
          this.container.classList.add(this.containerClassName);
          const m = this.data, {
            width: h,
            height: e
          } = l(m.rect), r = this.svgFactory.create(h, e, !0);
          for (const p of m.inkLists) {
            let o = [];
            for (const u of p) {
              const A = u.x - m.rect[0], x = m.rect[3] - u.y;
              o.push(`${A},${x}`);
            }
            o = o.join(" ");
            const a = this.svgFactory.createElement(this.svgElementName);
            this.#t.push(a), a.setAttribute("points", o), a.setAttribute("stroke-width", m.borderStyle.width || 1), a.setAttribute("stroke", "transparent"), a.setAttribute("fill", "transparent"), !m.popupRef && this.hasPopupData && this._createPopup(), r.append(a);
          }
          return this.container.append(r), this.container;
        }
        getElementsToTriggerPopup() {
          return this.#t;
        }
        addHighlightArea() {
          this.container.classList.add("highlightArea");
        }
      }
      class Z extends s {
        constructor(m) {
          super(m, {
            isRenderable: !0,
            ignoreBorder: !0,
            createQuadrilaterals: !0
          });
        }
        render() {
          return !this.data.popupRef && this.hasPopupData && this._createPopup(), this.container.classList.add("highlightAnnotation"), this.container;
        }
      }
      class at extends s {
        constructor(m) {
          super(m, {
            isRenderable: !0,
            ignoreBorder: !0,
            createQuadrilaterals: !0
          });
        }
        render() {
          return !this.data.popupRef && this.hasPopupData && this._createPopup(), this.container.classList.add("underlineAnnotation"), this.container;
        }
      }
      class lt extends s {
        constructor(m) {
          super(m, {
            isRenderable: !0,
            ignoreBorder: !0,
            createQuadrilaterals: !0
          });
        }
        render() {
          return !this.data.popupRef && this.hasPopupData && this._createPopup(), this.container.classList.add("squigglyAnnotation"), this.container;
        }
      }
      class pt extends s {
        constructor(m) {
          super(m, {
            isRenderable: !0,
            ignoreBorder: !0,
            createQuadrilaterals: !0
          });
        }
        render() {
          return !this.data.popupRef && this.hasPopupData && this._createPopup(), this.container.classList.add("strikeoutAnnotation"), this.container;
        }
      }
      class dt extends s {
        constructor(m) {
          super(m, {
            isRenderable: !0,
            ignoreBorder: !0
          });
        }
        render() {
          return this.container.classList.add("stampAnnotation"), !this.data.popupRef && this.hasPopupData && this._createPopup(), this.container;
        }
      }
      class ot extends s {
        #t = null;
        constructor(m) {
          super(m, {
            isRenderable: !0
          });
          const {
            filename: h,
            content: e
          } = this.data.file;
          this.filename = (0, B.getFilenameFromUrl)(h, !0), this.content = e, this.linkService.eventBus?.dispatch("fileattachmentannotation", {
            source: this,
            filename: h,
            content: e
          });
        }
        render() {
          this.container.classList.add("fileAttachmentAnnotation");
          const {
            container: m,
            data: h
          } = this;
          let e;
          h.hasAppearance || h.fillAlpha === 0 ? e = document.createElement("div") : (e = document.createElement("img"), e.src = `${this.imageResourcesPath}annotation-${/paperclip/i.test(h.name) ? "paperclip" : "pushpin"}.svg`, h.fillAlpha && h.fillAlpha < 1 && (e.style = `filter: opacity(${Math.round(h.fillAlpha * 100)}%);`)), e.addEventListener("dblclick", this.#e.bind(this)), this.#t = e;
          const {
            isMac: r
          } = w.FeatureTest.platform;
          return m.addEventListener("keydown", (p) => {
            p.key === "Enter" && (r ? p.metaKey : p.ctrlKey) && this.#e();
          }), !h.popupRef && this.hasPopupData ? this._createPopup() : e.classList.add("popupTriggerArea"), m.append(e), m;
        }
        getElementsToTriggerPopup() {
          return this.#t;
        }
        addHighlightArea() {
          this.container.classList.add("highlightArea");
        }
        #e() {
          this.downloadManager?.openOrDownloadData(this.content, this.filename);
        }
      }
      class ut {
        #t = null;
        #e = null;
        #s = /* @__PURE__ */ new Map();
        constructor({
          div: m,
          accessibilityManager: h,
          annotationCanvasMap: e,
          annotationEditorUIManager: r,
          page: p,
          viewport: o
        }) {
          this.div = m, this.#t = h, this.#e = e, this.page = p, this.viewport = o, this.zIndex = 0, this._annotationEditorUIManager = r;
        }
        #n(m, h) {
          const e = m.firstChild || m;
          e.id = `${w.AnnotationPrefix}${h}`, this.div.append(m), this.#t?.moveElementInDOM(this.div, m, e, !1);
        }
        async render(m) {
          const {
            annotations: h
          } = m, e = this.div;
          (0, B.setLayerDimensions)(e, this.viewport);
          const r = /* @__PURE__ */ new Map(), p = {
            data: null,
            layer: e,
            linkService: m.linkService,
            downloadManager: m.downloadManager,
            imageResourcesPath: m.imageResourcesPath || "",
            renderForms: m.renderForms !== !1,
            svgFactory: new B.DOMSVGFactory(),
            annotationStorage: m.annotationStorage || new _.AnnotationStorage(),
            enableScripting: m.enableScripting === !0,
            hasJSActions: m.hasJSActions,
            fieldObjects: m.fieldObjects,
            parent: this,
            elements: null
          };
          for (const o of h) {
            if (o.noHTML)
              continue;
            const a = o.annotationType === w.AnnotationType.POPUP;
            if (a) {
              const x = r.get(o.id);
              if (!x)
                continue;
              p.elements = x;
            } else {
              const {
                width: x,
                height: k
              } = l(o.rect);
              if (x <= 0 || k <= 0)
                continue;
            }
            p.data = o;
            const u = b.create(p);
            if (!u.isRenderable)
              continue;
            if (!a && o.popupRef) {
              const x = r.get(o.popupRef);
              x ? x.push(u) : r.set(o.popupRef, [u]);
            }
            const A = u.render();
            o.hidden && (A.style.visibility = "hidden"), this.#n(A, o.id), u.annotationEditorType > 0 && (this.#s.set(u.data.id, u), this._annotationEditorUIManager?.renderAnnotationElement(u));
          }
          this.#r();
        }
        update({
          viewport: m
        }) {
          const h = this.div;
          this.viewport = m, (0, B.setLayerDimensions)(h, {
            rotation: m.rotation
          }), this.#r(), h.hidden = !1;
        }
        #r() {
          if (!this.#e)
            return;
          const m = this.div;
          for (const [h, e] of this.#e) {
            const r = m.querySelector(`[data-annotation-id="${h}"]`);
            if (!r)
              continue;
            e.className = "annotationContent";
            const {
              firstChild: p
            } = r;
            p ? p.nodeName === "CANVAS" ? p.replaceWith(e) : p.classList.contains("annotationContent") ? p.after(e) : p.before(e) : r.append(e);
          }
          this.#e.clear();
        }
        getEditableAnnotations() {
          return Array.from(this.#s.values());
        }
        getEditableAnnotation(m) {
          return this.#s.get(m);
        }
      }
    })
  ),
  /***/
  792: (
    /***/
    ((ct, st, V) => {
      V.d(st, {
        /* harmony export */
        AnnotationStorage: () => (
          /* binding */
          P
        ),
        /* harmony export */
        PrintAnnotationStorage: () => (
          /* binding */
          T
        ),
        /* harmony export */
        SerializableEmpty: () => (
          /* binding */
          U
        )
        /* harmony export */
      });
      var w = V(292), B = V(310), _ = V(651);
      const U = Object.freeze({
        map: null,
        hash: "",
        transfer: void 0
      });
      class P {
        #t = !1;
        #e = /* @__PURE__ */ new Map();
        constructor() {
          this.onSetModified = null, this.onResetModified = null, this.onAnnotationEditor = null;
        }
        getValue(v, n) {
          const c = this.#e.get(v);
          return c === void 0 ? n : Object.assign(n, c);
        }
        getRawValue(v) {
          return this.#e.get(v);
        }
        remove(v) {
          if (this.#e.delete(v), this.#e.size === 0 && this.resetModified(), typeof this.onAnnotationEditor == "function") {
            for (const n of this.#e.values())
              if (n instanceof B.AnnotationEditor)
                return;
            this.onAnnotationEditor(null);
          }
        }
        setValue(v, n) {
          const c = this.#e.get(v);
          let l = !1;
          if (c !== void 0)
            for (const [b, s] of Object.entries(n))
              c[b] !== s && (l = !0, c[b] = s);
          else
            l = !0, this.#e.set(v, n);
          l && this.#s(), n instanceof B.AnnotationEditor && typeof this.onAnnotationEditor == "function" && this.onAnnotationEditor(n.constructor._type);
        }
        has(v) {
          return this.#e.has(v);
        }
        getAll() {
          return this.#e.size > 0 ? (0, w.objectFromMap)(this.#e) : null;
        }
        setAll(v) {
          for (const [n, c] of Object.entries(v))
            this.setValue(n, c);
        }
        get size() {
          return this.#e.size;
        }
        #s() {
          this.#t || (this.#t = !0, typeof this.onSetModified == "function" && this.onSetModified());
        }
        resetModified() {
          this.#t && (this.#t = !1, typeof this.onResetModified == "function" && this.onResetModified());
        }
        get print() {
          return new T(this);
        }
        get serializable() {
          if (this.#e.size === 0)
            return U;
          const v = /* @__PURE__ */ new Map(), n = new _.MurmurHash3_64(), c = [], l = /* @__PURE__ */ Object.create(null);
          let b = !1;
          for (const [s, g] of this.#e) {
            const t = g instanceof B.AnnotationEditor ? g.serialize(!1, l) : g;
            t && (v.set(s, t), n.update(`${s}:${JSON.stringify(t)}`), b ||= !!t.bitmap);
          }
          if (b)
            for (const s of v.values())
              s.bitmap && c.push(s.bitmap);
          return v.size > 0 ? {
            map: v,
            hash: n.hexdigest(),
            transfer: c
          } : U;
        }
        get editorStats() {
          let v = null;
          const n = /* @__PURE__ */ new Map();
          for (const c of this.#e.values()) {
            if (!(c instanceof B.AnnotationEditor))
              continue;
            const l = c.telemetryFinalData;
            if (!l)
              continue;
            const {
              type: b
            } = l;
            n.has(b) || n.set(b, Object.getPrototypeOf(c).constructor), v ||= /* @__PURE__ */ Object.create(null);
            const s = v[b] ||= /* @__PURE__ */ new Map();
            for (const [g, t] of Object.entries(l)) {
              if (g === "type")
                continue;
              let i = s.get(g);
              i || (i = /* @__PURE__ */ new Map(), s.set(g, i));
              const d = i.get(t) ?? 0;
              i.set(t, d + 1);
            }
          }
          for (const [c, l] of n)
            v[c] = l.computeTelemetryFinalData(v[c]);
          return v;
        }
      }
      class T extends P {
        #t;
        constructor(v) {
          super();
          const {
            map: n,
            hash: c,
            transfer: l
          } = v.serializable, b = structuredClone(n, l ? {
            transfer: l
          } : null);
          this.#t = {
            map: b,
            hash: c,
            transfer: l
          };
        }
        get print() {
          (0, w.unreachable)("Should not call PrintAnnotationStorage.print");
        }
        get serializable() {
          return this.#t;
        }
      }
    })
  ),
  /***/
  831: (
    /***/
    ((ct, st, V) => {
      V.a(ct, async (w, B) => {
        try {
          let nt = function(o) {
            if (typeof o == "string" || o instanceof URL ? o = {
              url: o
            } : (o instanceof ArrayBuffer || ArrayBuffer.isView(o)) && (o = {
              data: o
            }), typeof o != "object")
              throw new Error("Invalid parameter in getDocument, need parameter object.");
            if (!o.url && !o.data && !o.range)
              throw new Error("Invalid parameter object: need either .data, .range or .url");
            const a = new tt(), {
              docId: u
            } = a, A = o.url ? O(o.url) : null, x = o.data ? G(o.data) : null, k = o.httpHeaders || null, R = o.withCredentials === !0, D = o.password ?? null, I = o.range instanceof Z ? o.range : null, F = Number.isInteger(o.rangeChunkSize) && o.rangeChunkSize > 0 ? o.rangeChunkSize : S;
            let C = o.worker instanceof ot ? o.worker : null;
            const $ = o.verbosity, K = typeof o.docBaseUrl == "string" && !(0, P.isDataScheme)(o.docBaseUrl) ? o.docBaseUrl : null, X = typeof o.cMapUrl == "string" ? o.cMapUrl : null, W = o.cMapPacked !== !1, rt = o.CMapReaderFactory || H, J = typeof o.standardFontDataUrl == "string" ? o.standardFontDataUrl : null, Q = o.StandardFontDataFactory || q, it = o.stopAtErrors !== !0, ht = Number.isInteger(o.maxImageSize) && o.maxImageSize > -1 ? o.maxImageSize : -1, gt = o.isEvalSupported !== !1, At = typeof o.isOffscreenCanvasSupported == "boolean" ? o.isOffscreenCanvasSupported : !_.isNodeJS, vt = Number.isInteger(o.canvasMaxAreaInBytes) ? o.canvasMaxAreaInBytes : -1, mt = typeof o.disableFontFace == "boolean" ? o.disableFontFace : _.isNodeJS, kt = o.fontExtraProperties === !0, xt = o.enableXfa === !0, Ct = o.ownerDocument || globalThis.document, yt = o.disableRange === !0, Et = o.disableStream === !0, Rt = o.disableAutoFetch === !0, Lt = o.pdfBug === !0, _t = I ? I.length : o.length ?? NaN, Ht = typeof o.useSystemFonts == "boolean" ? o.useSystemFonts : !_.isNodeJS && !mt, Mt = typeof o.useWorkerFetch == "boolean" ? o.useWorkerFetch : rt === P.DOMCMapReaderFactory && Q === P.DOMStandardFontDataFactory && X && J && (0, P.isValidFetchUrl)(X, document.baseURI) && (0, P.isValidFetchUrl)(J, document.baseURI), Tt = o.canvasFactory || new N({
              ownerDocument: Ct
            }), St = o.filterFactory || new z({
              docId: u,
              ownerDocument: Ct
            }), Bt = null;
            (0, _.setVerbosityLevel)($);
            const Dt = {
              canvasFactory: Tt,
              filterFactory: St
            };
            if (Mt || (Dt.cMapReaderFactory = new rt({
              baseUrl: X,
              isCompressed: W
            }), Dt.standardFontDataFactory = new Q({
              baseUrl: J
            })), !C) {
              const Nt = {
                verbosity: $,
                port: c.GlobalWorkerOptions.workerPort
              };
              C = Nt.port ? ot.fromPort(Nt) : new ot(Nt), a._worker = C;
            }
            const It = {
              docId: u,
              apiVersion: "4.2.67",
              data: x,
              password: D,
              disableAutoFetch: Rt,
              rangeChunkSize: F,
              length: _t,
              docBaseUrl: K,
              enableXfa: xt,
              evaluatorOptions: {
                maxImageSize: ht,
                disableFontFace: mt,
                ignoreErrors: it,
                isEvalSupported: gt,
                isOffscreenCanvasSupported: At,
                canvasMaxAreaInBytes: vt,
                fontExtraProperties: kt,
                useSystemFonts: Ht,
                cMapUrl: Mt ? X : null,
                standardFontDataUrl: Mt ? J : null
              }
            }, wt = {
              ignoreErrors: it,
              disableFontFace: mt,
              fontExtraProperties: kt,
              enableXfa: xt,
              ownerDocument: Ct,
              disableAutoFetch: Rt,
              pdfBug: Lt,
              styleElement: Bt
            };
            return C.promise.then(function() {
              if (a.destroyed)
                throw new Error("Loading aborted");
              const Nt = j(C, It), $t = new Promise(function(zt) {
                let Ot;
                I ? Ot = new g.PDFDataTransportStream(I, {
                  disableRange: yt,
                  disableStream: Et
                }) : x || (Ot = ((Ft) => _.isNodeJS ? function() {
                  return typeof fetch < "u" && typeof Response < "u" && "body" in Response.prototype;
                }() && (0, P.isValidFetchUrl)(Ft.url) ? new t.PDFFetchStream(Ft) : new d.PDFNodeStream(Ft) : (0, P.isValidFetchUrl)(Ft.url) ? new t.PDFFetchStream(Ft) : new i.PDFNetworkStream(Ft))({
                  url: A,
                  length: _t,
                  httpHeaders: k,
                  withCredentials: R,
                  rangeChunkSize: F,
                  disableRange: yt,
                  disableStream: Et
                })), zt(Ot);
              });
              return Promise.all([Nt, $t]).then(function([zt, Ot]) {
                if (a.destroyed)
                  throw new Error("Loading aborted");
                const Gt = new l.MessageHandler(u, zt, C.port), Ft = new ut(Gt, a, Ot, wt, Dt);
                a._transport = Ft, Gt.send("Ready", null);
              });
            }).catch(a._capability.reject), a;
          }, O = function(o) {
            if (o instanceof URL)
              return o.href;
            try {
              return new URL(o, window.location).href;
            } catch {
              if (_.isNodeJS && typeof o == "string")
                return o;
            }
            throw new Error("Invalid PDF url data: either string or URL-object is expected in the url property.");
          }, G = function(o) {
            if (_.isNodeJS && typeof Buffer < "u" && o instanceof Buffer)
              throw new Error("Please provide binary data as `Uint8Array`, rather than `Buffer`.");
            if (o instanceof Uint8Array && o.byteLength === o.buffer.byteLength)
              return o;
            if (typeof o == "string")
              return (0, _.stringToBytes)(o);
            if (o instanceof ArrayBuffer || ArrayBuffer.isView(o) || typeof o == "object" && !isNaN(o?.length))
              return new Uint8Array(o);
            throw new Error("Invalid PDF binary data: either TypedArray, string, or array-like object is expected in the data property.");
          }, Y = function(o) {
            return typeof o == "object" && Number.isInteger(o?.num) && o.num >= 0 && Number.isInteger(o?.gen) && o.gen >= 0;
          };
          V.d(st, {
            /* harmony export */
            PDFDataRangeTransport: () => (
              /* binding */
              Z
            ),
            /* harmony export */
            PDFWorker: () => (
              /* binding */
              ot
            ),
            /* harmony export */
            build: () => (
              /* binding */
              p
            ),
            /* harmony export */
            getDocument: () => (
              /* binding */
              nt
            ),
            /* harmony export */
            version: () => (
              /* binding */
              r
            )
            /* harmony export */
          });
          var _ = V(292), U = V(792), P = V(419), T = V(10), E = V(573), v = V(923), n = V(814), c = V(164), l = V(178), b = V(62), s = V(626), g = V(585), t = V(94), i = V(457), d = V(786), f = V(50), y = w([E, d]);
          [E, d] = y.then ? (await y)() : y;
          const S = 65536, L = 100, M = 5e3, N = _.isNodeJS ? E.NodeCanvasFactory : P.DOMCanvasFactory, H = _.isNodeJS ? E.NodeCMapReaderFactory : P.DOMCMapReaderFactory, z = _.isNodeJS ? E.NodeFilterFactory : P.DOMFilterFactory, q = _.isNodeJS ? E.NodeStandardFontDataFactory : P.DOMStandardFontDataFactory;
          async function j(o, a) {
            if (o.destroyed)
              throw new Error("Worker was destroyed");
            const u = await o.messageHandler.sendWithPromise("GetDocRequest", a, a.data ? [a.data.buffer] : null);
            if (o.destroyed)
              throw new Error("Worker was destroyed");
            return u;
          }
          class tt {
            static #t = 0;
            constructor() {
              this._capability = Promise.withResolvers(), this._transport = null, this._worker = null, this.docId = `d${tt.#t++}`, this.destroyed = !1, this.onPassword = null, this.onProgress = null;
            }
            get promise() {
              return this._capability.promise;
            }
            async destroy() {
              this.destroyed = !0;
              try {
                this._worker?.port && (this._worker._pendingDestroy = !0), await this._transport?.destroy();
              } catch (a) {
                throw this._worker?.port && delete this._worker._pendingDestroy, a;
              }
              this._transport = null, this._worker && (this._worker.destroy(), this._worker = null);
            }
          }
          class Z {
            constructor(a, u, A = !1, x = null) {
              this.length = a, this.initialData = u, this.progressiveDone = A, this.contentDispositionFilename = x, this._rangeListeners = [], this._progressListeners = [], this._progressiveReadListeners = [], this._progressiveDoneListeners = [], this._readyCapability = Promise.withResolvers();
            }
            addRangeListener(a) {
              this._rangeListeners.push(a);
            }
            addProgressListener(a) {
              this._progressListeners.push(a);
            }
            addProgressiveReadListener(a) {
              this._progressiveReadListeners.push(a);
            }
            addProgressiveDoneListener(a) {
              this._progressiveDoneListeners.push(a);
            }
            onDataRange(a, u) {
              for (const A of this._rangeListeners)
                A(a, u);
            }
            onDataProgress(a, u) {
              this._readyCapability.promise.then(() => {
                for (const A of this._progressListeners)
                  A(a, u);
              });
            }
            onDataProgressiveRead(a) {
              this._readyCapability.promise.then(() => {
                for (const u of this._progressiveReadListeners)
                  u(a);
              });
            }
            onDataProgressiveDone() {
              this._readyCapability.promise.then(() => {
                for (const a of this._progressiveDoneListeners)
                  a();
              });
            }
            transportReady() {
              this._readyCapability.resolve();
            }
            requestDataRange(a, u) {
              (0, _.unreachable)("Abstract method PDFDataRangeTransport.requestDataRange");
            }
            abort() {
            }
          }
          class at {
            constructor(a, u) {
              this._pdfInfo = a, this._transport = u;
            }
            get annotationStorage() {
              return this._transport.annotationStorage;
            }
            get filterFactory() {
              return this._transport.filterFactory;
            }
            get numPages() {
              return this._pdfInfo.numPages;
            }
            get fingerprints() {
              return this._pdfInfo.fingerprints;
            }
            get isPureXfa() {
              return (0, _.shadow)(this, "isPureXfa", !!this._transport._htmlForXfa);
            }
            get allXfaHtml() {
              return this._transport._htmlForXfa;
            }
            getPage(a) {
              return this._transport.getPage(a);
            }
            getPageIndex(a) {
              return this._transport.getPageIndex(a);
            }
            getDestinations() {
              return this._transport.getDestinations();
            }
            getDestination(a) {
              return this._transport.getDestination(a);
            }
            getPageLabels() {
              return this._transport.getPageLabels();
            }
            getPageLayout() {
              return this._transport.getPageLayout();
            }
            getPageMode() {
              return this._transport.getPageMode();
            }
            getViewerPreferences() {
              return this._transport.getViewerPreferences();
            }
            getOpenAction() {
              return this._transport.getOpenAction();
            }
            getAttachments() {
              return this._transport.getAttachments();
            }
            getJSActions() {
              return this._transport.getDocJSActions();
            }
            getOutline() {
              return this._transport.getOutline();
            }
            getOptionalContentConfig({
              intent: a = "display"
            } = {}) {
              const {
                renderingIntent: u
              } = this._transport.getRenderingIntent(a);
              return this._transport.getOptionalContentConfig(u);
            }
            getPermissions() {
              return this._transport.getPermissions();
            }
            getMetadata() {
              return this._transport.getMetadata();
            }
            getMarkInfo() {
              return this._transport.getMarkInfo();
            }
            getData() {
              return this._transport.getData();
            }
            saveDocument() {
              return this._transport.saveDocument();
            }
            getDownloadInfo() {
              return this._transport.downloadInfoCapability.promise;
            }
            cleanup(a = !1) {
              return this._transport.startCleanup(a || this.isPureXfa);
            }
            destroy() {
              return this.loadingTask.destroy();
            }
            cachedPageNumber(a) {
              return this._transport.cachedPageNumber(a);
            }
            get loadingParams() {
              return this._transport.loadingParams;
            }
            get loadingTask() {
              return this._transport.loadingTask;
            }
            getFieldObjects() {
              return this._transport.getFieldObjects();
            }
            hasJSActions() {
              return this._transport.hasJSActions();
            }
            getCalculationOrderIds() {
              return this._transport.getCalculationOrderIds();
            }
          }
          class lt {
            #t = null;
            #e = !1;
            constructor(a, u, A, x = !1) {
              this._pageIndex = a, this._pageInfo = u, this._transport = A, this._stats = x ? new P.StatTimer() : null, this._pdfBug = x, this.commonObjs = A.commonObjs, this.objs = new m(), this._maybeCleanupAfterRender = !1, this._intentStates = /* @__PURE__ */ new Map(), this.destroyed = !1;
            }
            get pageNumber() {
              return this._pageIndex + 1;
            }
            get rotate() {
              return this._pageInfo.rotate;
            }
            get ref() {
              return this._pageInfo.ref;
            }
            get userUnit() {
              return this._pageInfo.userUnit;
            }
            get view() {
              return this._pageInfo.view;
            }
            getViewport({
              scale: a,
              rotation: u = this.rotate,
              offsetX: A = 0,
              offsetY: x = 0,
              dontFlip: k = !1
            } = {}) {
              return new P.PageViewport({
                viewBox: this.view,
                scale: a,
                rotation: u,
                offsetX: A,
                offsetY: x,
                dontFlip: k
              });
            }
            getAnnotations({
              intent: a = "display"
            } = {}) {
              const {
                renderingIntent: u
              } = this._transport.getRenderingIntent(a);
              return this._transport.getAnnotations(this._pageIndex, u);
            }
            getJSActions() {
              return this._transport.getPageJSActions(this._pageIndex);
            }
            get filterFactory() {
              return this._transport.filterFactory;
            }
            get isPureXfa() {
              return (0, _.shadow)(this, "isPureXfa", !!this._transport._htmlForXfa);
            }
            async getXfa() {
              return this._transport._htmlForXfa?.children[this._pageIndex] || null;
            }
            render({
              canvasContext: a,
              viewport: u,
              intent: A = "display",
              annotationMode: x = _.AnnotationMode.ENABLE,
              transform: k = null,
              background: R = null,
              optionalContentConfigPromise: D = null,
              annotationCanvasMap: I = null,
              pageColors: F = null,
              printAnnotationStorage: C = null
            }) {
              this._stats?.time("Overall");
              const $ = this._transport.getRenderingIntent(A, x, C), {
                renderingIntent: K,
                cacheKey: X
              } = $;
              this.#e = !1, this.#n(), D ||= this._transport.getOptionalContentConfig(K);
              let W = this._intentStates.get(X);
              W || (W = /* @__PURE__ */ Object.create(null), this._intentStates.set(X, W)), W.streamReaderCancelTimeout && (clearTimeout(W.streamReaderCancelTimeout), W.streamReaderCancelTimeout = null);
              const rt = !!(K & _.RenderingIntentFlag.PRINT);
              W.displayReadyCapability || (W.displayReadyCapability = Promise.withResolvers(), W.operatorList = {
                fnArray: [],
                argsArray: [],
                lastChunk: !1,
                separateAnnots: null
              }, this._stats?.time("Page Request"), this._pumpOperatorList($));
              const J = (ht) => {
                W.renderTasks.delete(Q), (this._maybeCleanupAfterRender || rt) && (this.#e = !0), this.#s(!rt), ht ? (Q.capability.reject(ht), this._abortOperatorList({
                  intentState: W,
                  reason: ht instanceof Error ? ht : new Error(ht)
                })) : Q.capability.resolve(), this._stats?.timeEnd("Rendering"), this._stats?.timeEnd("Overall");
              }, Q = new e({
                callback: J,
                params: {
                  canvasContext: a,
                  viewport: u,
                  transform: k,
                  background: R
                },
                objs: this.objs,
                commonObjs: this.commonObjs,
                annotationCanvasMap: I,
                operatorList: W.operatorList,
                pageIndex: this._pageIndex,
                canvasFactory: this._transport.canvasFactory,
                filterFactory: this._transport.filterFactory,
                useRequestAnimationFrame: !rt,
                pdfBug: this._pdfBug,
                pageColors: F
              });
              (W.renderTasks ||= /* @__PURE__ */ new Set()).add(Q);
              const it = Q.task;
              return Promise.all([W.displayReadyCapability.promise, D]).then(([ht, gt]) => {
                if (this.destroyed) {
                  J();
                  return;
                }
                if (this._stats?.time("Rendering"), !(gt.renderingIntent & K))
                  throw new Error("Must use the same `intent`-argument when calling the `PDFPageProxy.render` and `PDFDocumentProxy.getOptionalContentConfig` methods.");
                Q.initializeGraphics({
                  transparency: ht,
                  optionalContentConfig: gt
                }), Q.operatorListChanged();
              }).catch(J), it;
            }
            getOperatorList({
              intent: a = "display",
              annotationMode: u = _.AnnotationMode.ENABLE,
              printAnnotationStorage: A = null
            } = {}) {
              function x() {
                R.operatorList.lastChunk && (R.opListReadCapability.resolve(R.operatorList), R.renderTasks.delete(D));
              }
              const k = this._transport.getRenderingIntent(a, u, A, !0);
              let R = this._intentStates.get(k.cacheKey);
              R || (R = /* @__PURE__ */ Object.create(null), this._intentStates.set(k.cacheKey, R));
              let D;
              return R.opListReadCapability || (D = /* @__PURE__ */ Object.create(null), D.operatorListChanged = x, R.opListReadCapability = Promise.withResolvers(), (R.renderTasks ||= /* @__PURE__ */ new Set()).add(D), R.operatorList = {
                fnArray: [],
                argsArray: [],
                lastChunk: !1,
                separateAnnots: null
              }, this._stats?.time("Page Request"), this._pumpOperatorList(k)), R.opListReadCapability.promise;
            }
            streamTextContent({
              includeMarkedContent: a = !1,
              disableNormalization: u = !1
            } = {}) {
              return this._transport.messageHandler.sendWithStream("GetTextContent", {
                pageIndex: this._pageIndex,
                includeMarkedContent: a === !0,
                disableNormalization: u === !0
              }, {
                highWaterMark: 100,
                size(x) {
                  return x.items.length;
                }
              });
            }
            getTextContent(a = {}) {
              if (this._transport._htmlForXfa)
                return this.getXfa().then((A) => f.XfaText.textContent(A));
              const u = this.streamTextContent(a);
              return new Promise(function(A, x) {
                function k() {
                  R.read().then(function({
                    value: I,
                    done: F
                  }) {
                    if (F) {
                      A(D);
                      return;
                    }
                    Object.assign(D.styles, I.styles), D.items.push(...I.items), k();
                  }, x);
                }
                const R = u.getReader(), D = {
                  items: [],
                  styles: /* @__PURE__ */ Object.create(null)
                };
                k();
              });
            }
            getStructTree() {
              return this._transport.getStructTree(this._pageIndex);
            }
            _destroy() {
              this.destroyed = !0;
              const a = [];
              for (const u of this._intentStates.values())
                if (this._abortOperatorList({
                  intentState: u,
                  reason: new Error("Page was destroyed."),
                  force: !0
                }), !u.opListReadCapability)
                  for (const A of u.renderTasks)
                    a.push(A.completed), A.cancel();
              return this.objs.clear(), this.#e = !1, this.#n(), Promise.all(a);
            }
            cleanup(a = !1) {
              this.#e = !0;
              const u = this.#s(!1);
              return a && u && (this._stats &&= new P.StatTimer()), u;
            }
            #s(a = !1) {
              if (this.#n(), !this.#e || this.destroyed)
                return !1;
              if (a)
                return this.#t = setTimeout(() => {
                  this.#t = null, this.#s(!1);
                }, M), !1;
              for (const {
                renderTasks: u,
                operatorList: A
              } of this._intentStates.values())
                if (u.size > 0 || !A.lastChunk)
                  return !1;
              return this._intentStates.clear(), this.objs.clear(), this.#e = !1, !0;
            }
            #n() {
              this.#t && (clearTimeout(this.#t), this.#t = null);
            }
            _startRenderPage(a, u) {
              const A = this._intentStates.get(u);
              A && (this._stats?.timeEnd("Page Request"), A.displayReadyCapability?.resolve(a));
            }
            _renderPageChunk(a, u) {
              for (let A = 0, x = a.length; A < x; A++)
                u.operatorList.fnArray.push(a.fnArray[A]), u.operatorList.argsArray.push(a.argsArray[A]);
              u.operatorList.lastChunk = a.lastChunk, u.operatorList.separateAnnots = a.separateAnnots;
              for (const A of u.renderTasks)
                A.operatorListChanged();
              a.lastChunk && this.#s(!0);
            }
            _pumpOperatorList({
              renderingIntent: a,
              cacheKey: u,
              annotationStorageSerializable: A
            }) {
              const {
                map: x,
                transfer: k
              } = A, D = this._transport.messageHandler.sendWithStream("GetOperatorList", {
                pageIndex: this._pageIndex,
                intent: a,
                cacheKey: u,
                annotationStorage: x
              }, k).getReader(), I = this._intentStates.get(u);
              I.streamReader = D;
              const F = () => {
                D.read().then(({
                  value: C,
                  done: $
                }) => {
                  if ($) {
                    I.streamReader = null;
                    return;
                  }
                  this._transport.destroyed || (this._renderPageChunk(C, I), F());
                }, (C) => {
                  if (I.streamReader = null, !this._transport.destroyed) {
                    if (I.operatorList) {
                      I.operatorList.lastChunk = !0;
                      for (const $ of I.renderTasks)
                        $.operatorListChanged();
                      this.#s(!0);
                    }
                    if (I.displayReadyCapability)
                      I.displayReadyCapability.reject(C);
                    else if (I.opListReadCapability)
                      I.opListReadCapability.reject(C);
                    else
                      throw C;
                  }
                });
              };
              F();
            }
            _abortOperatorList({
              intentState: a,
              reason: u,
              force: A = !1
            }) {
              if (a.streamReader) {
                if (a.streamReaderCancelTimeout && (clearTimeout(a.streamReaderCancelTimeout), a.streamReaderCancelTimeout = null), !A) {
                  if (a.renderTasks.size > 0)
                    return;
                  if (u instanceof P.RenderingCancelledException) {
                    let x = L;
                    u.extraDelay > 0 && u.extraDelay < 1e3 && (x += u.extraDelay), a.streamReaderCancelTimeout = setTimeout(() => {
                      a.streamReaderCancelTimeout = null, this._abortOperatorList({
                        intentState: a,
                        reason: u,
                        force: !0
                      });
                    }, x);
                    return;
                  }
                }
                if (a.streamReader.cancel(new _.AbortException(u.message)).catch(() => {
                }), a.streamReader = null, !this._transport.destroyed) {
                  for (const [x, k] of this._intentStates)
                    if (k === a) {
                      this._intentStates.delete(x);
                      break;
                    }
                  this.cleanup();
                }
              }
            }
            get stats() {
              return this._stats;
            }
          }
          class pt {
            #t = /* @__PURE__ */ new Set();
            #e = Promise.resolve();
            postMessage(a, u) {
              const A = {
                data: structuredClone(a, u ? {
                  transfer: u
                } : null)
              };
              this.#e.then(() => {
                for (const x of this.#t)
                  x.call(this, A);
              });
            }
            addEventListener(a, u) {
              this.#t.add(u);
            }
            removeEventListener(a, u) {
              this.#t.delete(u);
            }
            terminate() {
              this.#t.clear();
            }
          }
          const dt = {
            isWorkerDisabled: !1,
            fakeWorkerId: 0
          };
          _.isNodeJS && (dt.isWorkerDisabled = !0, c.GlobalWorkerOptions.workerSrc ||= "./pdf.worker.mjs"), dt.isSameOrigin = function(o, a) {
            let u;
            try {
              if (u = new URL(o), !u.origin || u.origin === "null")
                return !1;
            } catch {
              return !1;
            }
            const A = new URL(a, u);
            return u.origin === A.origin;
          }, dt.createCDNWrapper = function(o) {
            const a = `await import("${o}");`;
            return URL.createObjectURL(new Blob([a], {
              type: "text/javascript"
            }));
          };
          class ot {
            static #t;
            constructor({
              name: a = null,
              port: u = null,
              verbosity: A = (0, _.getVerbosityLevel)()
            } = {}) {
              if (this.name = a, this.destroyed = !1, this.verbosity = A, this._readyCapability = Promise.withResolvers(), this._port = null, this._webWorker = null, this._messageHandler = null, u) {
                if (ot.#t?.has(u))
                  throw new Error("Cannot use more than one PDFWorker per port.");
                (ot.#t ||= /* @__PURE__ */ new WeakMap()).set(u, this), this._initializeFromPort(u);
                return;
              }
              this._initialize();
            }
            get promise() {
              return this._readyCapability.promise;
            }
            get port() {
              return this._port;
            }
            get messageHandler() {
              return this._messageHandler;
            }
            _initializeFromPort(a) {
              this._port = a, this._messageHandler = new l.MessageHandler("main", "worker", a), this._messageHandler.on("ready", function() {
              }), this._readyCapability.resolve(), this._messageHandler.send("configure", {
                verbosity: this.verbosity
              });
            }
            _initialize() {
              if (!dt.isWorkerDisabled && !ot.#e) {
                let {
                  workerSrc: a
                } = ot;
                try {
                  dt.isSameOrigin(window.location.href, a) || (a = dt.createCDNWrapper(new URL(a, window.location).href));
                  const u = new Worker(a, {
                    type: "module"
                  }), A = new l.MessageHandler("main", "worker", u), x = () => {
                    u.removeEventListener("error", k), A.destroy(), u.terminate(), this.destroyed ? this._readyCapability.reject(new Error("Worker was destroyed")) : this._setupFakeWorker();
                  }, k = () => {
                    this._webWorker || x();
                  };
                  u.addEventListener("error", k), A.on("test", (D) => {
                    if (u.removeEventListener("error", k), this.destroyed) {
                      x();
                      return;
                    }
                    D ? (this._messageHandler = A, this._port = u, this._webWorker = u, this._readyCapability.resolve(), A.send("configure", {
                      verbosity: this.verbosity
                    })) : (this._setupFakeWorker(), A.destroy(), u.terminate());
                  }), A.on("ready", (D) => {
                    if (u.removeEventListener("error", k), this.destroyed) {
                      x();
                      return;
                    }
                    try {
                      R();
                    } catch {
                      this._setupFakeWorker();
                    }
                  });
                  const R = () => {
                    const D = new Uint8Array();
                    A.send("test", D, [D.buffer]);
                  };
                  R();
                  return;
                } catch {
                  (0, _.info)("The worker has been disabled.");
                }
              }
              this._setupFakeWorker();
            }
            _setupFakeWorker() {
              dt.isWorkerDisabled || ((0, _.warn)("Setting up fake worker."), dt.isWorkerDisabled = !0), ot._setupFakeWorkerGlobal.then((a) => {
                if (this.destroyed) {
                  this._readyCapability.reject(new Error("Worker was destroyed"));
                  return;
                }
                const u = new pt();
                this._port = u;
                const A = `fake${dt.fakeWorkerId++}`, x = new l.MessageHandler(A + "_worker", A, u);
                a.setup(x, u);
                const k = new l.MessageHandler(A, A + "_worker", u);
                this._messageHandler = k, this._readyCapability.resolve(), k.send("configure", {
                  verbosity: this.verbosity
                });
              }).catch((a) => {
                this._readyCapability.reject(new Error(`Setting up fake worker failed: "${a.message}".`));
              });
            }
            destroy() {
              this.destroyed = !0, this._webWorker && (this._webWorker.terminate(), this._webWorker = null), ot.#t?.delete(this._port), this._port = null, this._messageHandler && (this._messageHandler.destroy(), this._messageHandler = null);
            }
            static fromPort(a) {
              if (!a?.port)
                throw new Error("PDFWorker.fromPort - invalid method signature.");
              const u = this.#t?.get(a.port);
              if (u) {
                if (u._pendingDestroy)
                  throw new Error("PDFWorker.fromPort - the worker is being destroyed.\nPlease remember to await `PDFDocumentLoadingTask.destroy()`-calls.");
                return u;
              }
              return new ot(a);
            }
            static get workerSrc() {
              if (c.GlobalWorkerOptions.workerSrc)
                return c.GlobalWorkerOptions.workerSrc;
              throw new Error('No "GlobalWorkerOptions.workerSrc" specified.');
            }
            static get #e() {
              try {
                return globalThis.pdfjsWorker?.WorkerMessageHandler || null;
              } catch {
                return null;
              }
            }
            static get _setupFakeWorkerGlobal() {
              const a = async () => this.#e ? this.#e : (await import(
                /*webpackIgnore: true*/
                this.workerSrc
              )).WorkerMessageHandler;
              return (0, _.shadow)(this, "_setupFakeWorkerGlobal", a());
            }
          }
          class ut {
            #t = /* @__PURE__ */ new Map();
            #e = /* @__PURE__ */ new Map();
            #s = /* @__PURE__ */ new Map();
            #n = /* @__PURE__ */ new Map();
            #r = null;
            constructor(a, u, A, x, k) {
              this.messageHandler = a, this.loadingTask = u, this.commonObjs = new m(), this.fontLoader = new T.FontLoader({
                ownerDocument: x.ownerDocument,
                styleElement: x.styleElement
              }), this._params = x, this.canvasFactory = k.canvasFactory, this.filterFactory = k.filterFactory, this.cMapReaderFactory = k.cMapReaderFactory, this.standardFontDataFactory = k.standardFontDataFactory, this.destroyed = !1, this.destroyCapability = null, this._networkStream = A, this._fullReader = null, this._lastProgress = null, this.downloadInfoCapability = Promise.withResolvers(), this.setupMessageHandler();
            }
            #i(a, u = null) {
              const A = this.#t.get(a);
              if (A)
                return A;
              const x = this.messageHandler.sendWithPromise(a, u);
              return this.#t.set(a, x), x;
            }
            get annotationStorage() {
              return (0, _.shadow)(this, "annotationStorage", new U.AnnotationStorage());
            }
            getRenderingIntent(a, u = _.AnnotationMode.ENABLE, A = null, x = !1) {
              let k = _.RenderingIntentFlag.DISPLAY, R = U.SerializableEmpty;
              switch (a) {
                case "any":
                  k = _.RenderingIntentFlag.ANY;
                  break;
                case "display":
                  break;
                case "print":
                  k = _.RenderingIntentFlag.PRINT;
                  break;
                default:
                  (0, _.warn)(`getRenderingIntent - invalid intent: ${a}`);
              }
              switch (u) {
                case _.AnnotationMode.DISABLE:
                  k += _.RenderingIntentFlag.ANNOTATIONS_DISABLE;
                  break;
                case _.AnnotationMode.ENABLE:
                  break;
                case _.AnnotationMode.ENABLE_FORMS:
                  k += _.RenderingIntentFlag.ANNOTATIONS_FORMS;
                  break;
                case _.AnnotationMode.ENABLE_STORAGE:
                  k += _.RenderingIntentFlag.ANNOTATIONS_STORAGE, R = (k & _.RenderingIntentFlag.PRINT && A instanceof U.PrintAnnotationStorage ? A : this.annotationStorage).serializable;
                  break;
                default:
                  (0, _.warn)(`getRenderingIntent - invalid annotationMode: ${u}`);
              }
              return x && (k += _.RenderingIntentFlag.OPLIST), {
                renderingIntent: k,
                cacheKey: `${k}_${R.hash}`,
                annotationStorageSerializable: R
              };
            }
            destroy() {
              if (this.destroyCapability)
                return this.destroyCapability.promise;
              this.destroyed = !0, this.destroyCapability = Promise.withResolvers(), this.#r?.reject(new Error("Worker was destroyed during onPassword callback"));
              const a = [];
              for (const A of this.#e.values())
                a.push(A._destroy());
              this.#e.clear(), this.#s.clear(), this.#n.clear(), this.hasOwnProperty("annotationStorage") && this.annotationStorage.resetModified();
              const u = this.messageHandler.sendWithPromise("Terminate", null);
              return a.push(u), Promise.all(a).then(() => {
                this.commonObjs.clear(), this.fontLoader.clear(), this.#t.clear(), this.filterFactory.destroy(), (0, n.cleanupTextLayer)(), this._networkStream?.cancelAllRequests(new _.AbortException("Worker was terminated.")), this.messageHandler && (this.messageHandler.destroy(), this.messageHandler = null), this.destroyCapability.resolve();
              }, this.destroyCapability.reject), this.destroyCapability.promise;
            }
            setupMessageHandler() {
              const {
                messageHandler: a,
                loadingTask: u
              } = this;
              a.on("GetReader", (A, x) => {
                (0, _.assert)(this._networkStream, "GetReader - no `IPDFStream` instance available."), this._fullReader = this._networkStream.getFullReader(), this._fullReader.onProgress = (k) => {
                  this._lastProgress = {
                    loaded: k.loaded,
                    total: k.total
                  };
                }, x.onPull = () => {
                  this._fullReader.read().then(function({
                    value: k,
                    done: R
                  }) {
                    if (R) {
                      x.close();
                      return;
                    }
                    (0, _.assert)(k instanceof ArrayBuffer, "GetReader - expected an ArrayBuffer."), x.enqueue(new Uint8Array(k), 1, [k]);
                  }).catch((k) => {
                    x.error(k);
                  });
                }, x.onCancel = (k) => {
                  this._fullReader.cancel(k), x.ready.catch((R) => {
                    if (!this.destroyed)
                      throw R;
                  });
                };
              }), a.on("ReaderHeadersReady", (A) => {
                const x = Promise.withResolvers(), k = this._fullReader;
                return k.headersReady.then(() => {
                  (!k.isStreamingSupported || !k.isRangeSupported) && (this._lastProgress && u.onProgress?.(this._lastProgress), k.onProgress = (R) => {
                    u.onProgress?.({
                      loaded: R.loaded,
                      total: R.total
                    });
                  }), x.resolve({
                    isStreamingSupported: k.isStreamingSupported,
                    isRangeSupported: k.isRangeSupported,
                    contentLength: k.contentLength
                  });
                }, x.reject), x.promise;
              }), a.on("GetRangeReader", (A, x) => {
                (0, _.assert)(this._networkStream, "GetRangeReader - no `IPDFStream` instance available.");
                const k = this._networkStream.getRangeReader(A.begin, A.end);
                if (!k) {
                  x.close();
                  return;
                }
                x.onPull = () => {
                  k.read().then(function({
                    value: R,
                    done: D
                  }) {
                    if (D) {
                      x.close();
                      return;
                    }
                    (0, _.assert)(R instanceof ArrayBuffer, "GetRangeReader - expected an ArrayBuffer."), x.enqueue(new Uint8Array(R), 1, [R]);
                  }).catch((R) => {
                    x.error(R);
                  });
                }, x.onCancel = (R) => {
                  k.cancel(R), x.ready.catch((D) => {
                    if (!this.destroyed)
                      throw D;
                  });
                };
              }), a.on("GetDoc", ({
                pdfInfo: A
              }) => {
                this._numPages = A.numPages, this._htmlForXfa = A.htmlForXfa, delete A.htmlForXfa, u._capability.resolve(new at(A, this));
              }), a.on("DocException", function(A) {
                let x;
                switch (A.name) {
                  case "PasswordException":
                    x = new _.PasswordException(A.message, A.code);
                    break;
                  case "InvalidPDFException":
                    x = new _.InvalidPDFException(A.message);
                    break;
                  case "MissingPDFException":
                    x = new _.MissingPDFException(A.message);
                    break;
                  case "UnexpectedResponseException":
                    x = new _.UnexpectedResponseException(A.message, A.status);
                    break;
                  case "UnknownErrorException":
                    x = new _.UnknownErrorException(A.message, A.details);
                    break;
                  default:
                    (0, _.unreachable)("DocException - expected a valid Error.");
                }
                u._capability.reject(x);
              }), a.on("PasswordRequest", (A) => {
                if (this.#r = Promise.withResolvers(), u.onPassword) {
                  const x = (k) => {
                    k instanceof Error ? this.#r.reject(k) : this.#r.resolve({
                      password: k
                    });
                  };
                  try {
                    u.onPassword(x, A.code);
                  } catch (k) {
                    this.#r.reject(k);
                  }
                } else
                  this.#r.reject(new _.PasswordException(A.message, A.code));
                return this.#r.promise;
              }), a.on("DataLoaded", (A) => {
                u.onProgress?.({
                  loaded: A.length,
                  total: A.length
                }), this.downloadInfoCapability.resolve(A);
              }), a.on("StartRenderPage", (A) => {
                if (this.destroyed)
                  return;
                this.#e.get(A.pageIndex)._startRenderPage(A.transparency, A.cacheKey);
              }), a.on("commonobj", ([A, x, k]) => {
                if (this.destroyed || this.commonObjs.has(A))
                  return null;
                switch (x) {
                  case "Font":
                    const R = this._params;
                    if ("error" in k) {
                      const C = k.error;
                      (0, _.warn)(`Error during font loading: ${C}`), this.commonObjs.resolve(A, C);
                      break;
                    }
                    const D = R.pdfBug && globalThis.FontInspector?.enabled ? (C, $) => globalThis.FontInspector.fontAdded(C, $) : null, I = new T.FontFaceObject(k, {
                      disableFontFace: R.disableFontFace,
                      ignoreErrors: R.ignoreErrors,
                      inspectFont: D
                    });
                    this.fontLoader.bind(I).catch(() => a.sendWithPromise("FontFallback", {
                      id: A
                    })).finally(() => {
                      !R.fontExtraProperties && I.data && (I.data = null), this.commonObjs.resolve(A, I);
                    });
                    break;
                  case "CopyLocalImage":
                    const {
                      imageRef: F
                    } = k;
                    (0, _.assert)(F, "The imageRef must be defined.");
                    for (const C of this.#e.values())
                      for (const [, $] of C.objs)
                        if ($.ref === F)
                          return $.dataLen ? (this.commonObjs.resolve(A, structuredClone($)), $.dataLen) : null;
                    break;
                  case "FontPath":
                  case "Image":
                  case "Pattern":
                    this.commonObjs.resolve(A, k);
                    break;
                  default:
                    throw new Error(`Got unknown common object type ${x}`);
                }
                return null;
              }), a.on("obj", ([A, x, k, R]) => {
                if (this.destroyed)
                  return;
                const D = this.#e.get(x);
                if (!D.objs.has(A)) {
                  if (D._intentStates.size === 0) {
                    R?.bitmap?.close();
                    return;
                  }
                  switch (k) {
                    case "Image":
                      D.objs.resolve(A, R), R?.dataLen > _.MAX_IMAGE_SIZE_TO_CACHE && (D._maybeCleanupAfterRender = !0);
                      break;
                    case "Pattern":
                      D.objs.resolve(A, R);
                      break;
                    default:
                      throw new Error(`Got unknown object type ${k}`);
                  }
                }
              }), a.on("DocProgress", (A) => {
                this.destroyed || u.onProgress?.({
                  loaded: A.loaded,
                  total: A.total
                });
              }), a.on("FetchBuiltInCMap", (A) => this.destroyed ? Promise.reject(new Error("Worker was destroyed.")) : this.cMapReaderFactory ? this.cMapReaderFactory.fetch(A) : Promise.reject(new Error("CMapReaderFactory not initialized, see the `useWorkerFetch` parameter."))), a.on("FetchStandardFontData", (A) => this.destroyed ? Promise.reject(new Error("Worker was destroyed.")) : this.standardFontDataFactory ? this.standardFontDataFactory.fetch(A) : Promise.reject(new Error("StandardFontDataFactory not initialized, see the `useWorkerFetch` parameter.")));
            }
            getData() {
              return this.messageHandler.sendWithPromise("GetData", null);
            }
            saveDocument() {
              this.annotationStorage.size <= 0 && (0, _.warn)("saveDocument called while `annotationStorage` is empty, please use the getData-method instead.");
              const {
                map: a,
                transfer: u
              } = this.annotationStorage.serializable;
              return this.messageHandler.sendWithPromise("SaveDocument", {
                isPureXfa: !!this._htmlForXfa,
                numPages: this._numPages,
                annotationStorage: a,
                filename: this._fullReader?.filename ?? null
              }, u).finally(() => {
                this.annotationStorage.resetModified();
              });
            }
            getPage(a) {
              if (!Number.isInteger(a) || a <= 0 || a > this._numPages)
                return Promise.reject(new Error("Invalid page request."));
              const u = a - 1, A = this.#s.get(u);
              if (A)
                return A;
              const x = this.messageHandler.sendWithPromise("GetPage", {
                pageIndex: u
              }).then((k) => {
                if (this.destroyed)
                  throw new Error("Transport destroyed");
                k.refStr && this.#n.set(k.refStr, a);
                const R = new lt(u, k, this, this._params.pdfBug);
                return this.#e.set(u, R), R;
              });
              return this.#s.set(u, x), x;
            }
            getPageIndex(a) {
              return Y(a) ? this.messageHandler.sendWithPromise("GetPageIndex", {
                num: a.num,
                gen: a.gen
              }) : Promise.reject(new Error("Invalid pageIndex request."));
            }
            getAnnotations(a, u) {
              return this.messageHandler.sendWithPromise("GetAnnotations", {
                pageIndex: a,
                intent: u
              });
            }
            getFieldObjects() {
              return this.#i("GetFieldObjects");
            }
            hasJSActions() {
              return this.#i("HasJSActions");
            }
            getCalculationOrderIds() {
              return this.messageHandler.sendWithPromise("GetCalculationOrderIds", null);
            }
            getDestinations() {
              return this.messageHandler.sendWithPromise("GetDestinations", null);
            }
            getDestination(a) {
              return typeof a != "string" ? Promise.reject(new Error("Invalid destination request.")) : this.messageHandler.sendWithPromise("GetDestination", {
                id: a
              });
            }
            getPageLabels() {
              return this.messageHandler.sendWithPromise("GetPageLabels", null);
            }
            getPageLayout() {
              return this.messageHandler.sendWithPromise("GetPageLayout", null);
            }
            getPageMode() {
              return this.messageHandler.sendWithPromise("GetPageMode", null);
            }
            getViewerPreferences() {
              return this.messageHandler.sendWithPromise("GetViewerPreferences", null);
            }
            getOpenAction() {
              return this.messageHandler.sendWithPromise("GetOpenAction", null);
            }
            getAttachments() {
              return this.messageHandler.sendWithPromise("GetAttachments", null);
            }
            getDocJSActions() {
              return this.#i("GetDocJSActions");
            }
            getPageJSActions(a) {
              return this.messageHandler.sendWithPromise("GetPageJSActions", {
                pageIndex: a
              });
            }
            getStructTree(a) {
              return this.messageHandler.sendWithPromise("GetStructTree", {
                pageIndex: a
              });
            }
            getOutline() {
              return this.messageHandler.sendWithPromise("GetOutline", null);
            }
            getOptionalContentConfig(a) {
              return this.#i("GetOptionalContentConfig").then((u) => new s.OptionalContentConfig(u, a));
            }
            getPermissions() {
              return this.messageHandler.sendWithPromise("GetPermissions", null);
            }
            getMetadata() {
              const a = "GetMetadata", u = this.#t.get(a);
              if (u)
                return u;
              const A = this.messageHandler.sendWithPromise(a, null).then((x) => ({
                info: x[0],
                metadata: x[1] ? new b.Metadata(x[1]) : null,
                contentDispositionFilename: this._fullReader?.filename ?? null,
                contentLength: this._fullReader?.contentLength ?? null
              }));
              return this.#t.set(a, A), A;
            }
            getMarkInfo() {
              return this.messageHandler.sendWithPromise("GetMarkInfo", null);
            }
            async startCleanup(a = !1) {
              if (!this.destroyed) {
                await this.messageHandler.sendWithPromise("Cleanup", null);
                for (const u of this.#e.values())
                  if (!u.cleanup())
                    throw new Error(`startCleanup: Page ${u.pageNumber} is currently rendering.`);
                this.commonObjs.clear(), a || this.fontLoader.clear(), this.#t.clear(), this.filterFactory.destroy(!0), (0, n.cleanupTextLayer)();
              }
            }
            cachedPageNumber(a) {
              if (!Y(a))
                return null;
              const u = a.gen === 0 ? `${a.num}R` : `${a.num}R${a.gen}`;
              return this.#n.get(u) ?? null;
            }
            get loadingParams() {
              const {
                disableAutoFetch: a,
                enableXfa: u
              } = this._params;
              return (0, _.shadow)(this, "loadingParams", {
                disableAutoFetch: a,
                enableXfa: u
              });
            }
          }
          const et = Symbol("INITIAL_DATA");
          class m {
            #t = /* @__PURE__ */ Object.create(null);
            #e(a) {
              return this.#t[a] ||= {
                ...Promise.withResolvers(),
                data: et
              };
            }
            get(a, u = null) {
              if (u) {
                const x = this.#e(a);
                return x.promise.then(() => u(x.data)), null;
              }
              const A = this.#t[a];
              if (!A || A.data === et)
                throw new Error(`Requesting object that isn't resolved yet ${a}.`);
              return A.data;
            }
            has(a) {
              const u = this.#t[a];
              return !!u && u.data !== et;
            }
            resolve(a, u = null) {
              const A = this.#e(a);
              A.data = u, A.resolve();
            }
            clear() {
              for (const a in this.#t) {
                const {
                  data: u
                } = this.#t[a];
                u?.bitmap?.close();
              }
              this.#t = /* @__PURE__ */ Object.create(null);
            }
            *[Symbol.iterator]() {
              for (const a in this.#t) {
                const {
                  data: u
                } = this.#t[a];
                u !== et && (yield [a, u]);
              }
            }
          }
          class h {
            #t = null;
            constructor(a) {
              this.#t = a, this.onContinue = null;
            }
            get promise() {
              return this.#t.capability.promise;
            }
            cancel(a = 0) {
              this.#t.cancel(null, a);
            }
            get separateAnnots() {
              const {
                separateAnnots: a
              } = this.#t.operatorList;
              if (!a)
                return !1;
              const {
                annotationCanvasMap: u
              } = this.#t;
              return a.form || a.canvas && u?.size > 0;
            }
          }
          class e {
            static #t = /* @__PURE__ */ new WeakSet();
            constructor({
              callback: a,
              params: u,
              objs: A,
              commonObjs: x,
              annotationCanvasMap: k,
              operatorList: R,
              pageIndex: D,
              canvasFactory: I,
              filterFactory: F,
              useRequestAnimationFrame: C = !1,
              pdfBug: $ = !1,
              pageColors: K = null
            }) {
              this.callback = a, this.params = u, this.objs = A, this.commonObjs = x, this.annotationCanvasMap = k, this.operatorListIdx = null, this.operatorList = R, this._pageIndex = D, this.canvasFactory = I, this.filterFactory = F, this._pdfBug = $, this.pageColors = K, this.running = !1, this.graphicsReadyCallback = null, this.graphicsReady = !1, this._useRequestAnimationFrame = C === !0 && typeof window < "u", this.cancelled = !1, this.capability = Promise.withResolvers(), this.task = new h(this), this._cancelBound = this.cancel.bind(this), this._continueBound = this._continue.bind(this), this._scheduleNextBound = this._scheduleNext.bind(this), this._nextBound = this._next.bind(this), this._canvas = u.canvasContext.canvas;
            }
            get completed() {
              return this.capability.promise.catch(function() {
              });
            }
            initializeGraphics({
              transparency: a = !1,
              optionalContentConfig: u
            }) {
              if (this.cancelled)
                return;
              if (this._canvas) {
                if (e.#t.has(this._canvas))
                  throw new Error("Cannot use the same canvas during multiple render() operations. Use different canvas or ensure previous operations were cancelled or completed.");
                e.#t.add(this._canvas);
              }
              this._pdfBug && globalThis.StepperManager?.enabled && (this.stepper = globalThis.StepperManager.create(this._pageIndex), this.stepper.init(this.operatorList), this.stepper.nextBreakPoint = this.stepper.getNextBreakPoint());
              const {
                canvasContext: A,
                viewport: x,
                transform: k,
                background: R
              } = this.params;
              this.gfx = new v.CanvasGraphics(A, this.commonObjs, this.objs, this.canvasFactory, this.filterFactory, {
                optionalContentConfig: u
              }, this.annotationCanvasMap, this.pageColors), this.gfx.beginDrawing({
                transform: k,
                viewport: x,
                transparency: a,
                background: R
              }), this.operatorListIdx = 0, this.graphicsReady = !0, this.graphicsReadyCallback?.();
            }
            cancel(a = null, u = 0) {
              this.running = !1, this.cancelled = !0, this.gfx?.endDrawing(), e.#t.delete(this._canvas), this.callback(a || new P.RenderingCancelledException(`Rendering cancelled, page ${this._pageIndex + 1}`, u));
            }
            operatorListChanged() {
              if (!this.graphicsReady) {
                this.graphicsReadyCallback ||= this._continueBound;
                return;
              }
              this.stepper?.updateOperatorList(this.operatorList), !this.running && this._continue();
            }
            _continue() {
              this.running = !0, !this.cancelled && (this.task.onContinue ? this.task.onContinue(this._scheduleNextBound) : this._scheduleNext());
            }
            _scheduleNext() {
              this._useRequestAnimationFrame ? window.requestAnimationFrame(() => {
                this._nextBound().catch(this._cancelBound);
              }) : Promise.resolve().then(this._nextBound).catch(this._cancelBound);
            }
            async _next() {
              this.cancelled || (this.operatorListIdx = this.gfx.executeOperatorList(this.operatorList, this.operatorListIdx, this._continueBound, this.stepper), this.operatorListIdx === this.operatorList.argsArray.length && (this.running = !1, this.operatorList.lastChunk && (this.gfx.endDrawing(), e.#t.delete(this._canvas), this.callback())));
            }
          }
          const r = "4.2.67", p = "49b388101";
          B();
        } catch (S) {
          B(S);
        }
      });
    })
  ),
  /***/
  583: (
    /***/
    ((ct, st, V) => {
      V.d(st, {
        /* harmony export */
        BaseCMapReaderFactory: () => (
          /* binding */
          U
        ),
        /* harmony export */
        BaseCanvasFactory: () => (
          /* binding */
          _
        ),
        /* harmony export */
        BaseFilterFactory: () => (
          /* binding */
          B
        ),
        /* harmony export */
        BaseSVGFactory: () => (
          /* binding */
          T
        ),
        /* harmony export */
        BaseStandardFontDataFactory: () => (
          /* binding */
          P
        )
        /* harmony export */
      });
      var w = V(292);
      class B {
        constructor() {
          this.constructor === B && (0, w.unreachable)("Cannot initialize BaseFilterFactory.");
        }
        addFilter(v) {
          return "none";
        }
        addHCMFilter(v, n) {
          return "none";
        }
        addHighlightHCMFilter(v, n, c, l, b) {
          return "none";
        }
        destroy(v = !1) {
        }
      }
      class _ {
        constructor() {
          this.constructor === _ && (0, w.unreachable)("Cannot initialize BaseCanvasFactory.");
        }
        create(v, n) {
          if (v <= 0 || n <= 0)
            throw new Error("Invalid canvas size");
          const c = this._createCanvas(v, n);
          return {
            canvas: c,
            context: c.getContext("2d")
          };
        }
        reset(v, n, c) {
          if (!v.canvas)
            throw new Error("Canvas is not specified");
          if (n <= 0 || c <= 0)
            throw new Error("Invalid canvas size");
          v.canvas.width = n, v.canvas.height = c;
        }
        destroy(v) {
          if (!v.canvas)
            throw new Error("Canvas is not specified");
          v.canvas.width = 0, v.canvas.height = 0, v.canvas = null, v.context = null;
        }
        _createCanvas(v, n) {
          (0, w.unreachable)("Abstract method `_createCanvas` called.");
        }
      }
      class U {
        constructor({
          baseUrl: v = null,
          isCompressed: n = !0
        }) {
          this.constructor === U && (0, w.unreachable)("Cannot initialize BaseCMapReaderFactory."), this.baseUrl = v, this.isCompressed = n;
        }
        async fetch({
          name: v
        }) {
          if (!this.baseUrl)
            throw new Error('The CMap "baseUrl" parameter must be specified, ensure that the "cMapUrl" and "cMapPacked" API parameters are provided.');
          if (!v)
            throw new Error("CMap name must be specified.");
          const n = this.baseUrl + v + (this.isCompressed ? ".bcmap" : ""), c = this.isCompressed ? w.CMapCompressionType.BINARY : w.CMapCompressionType.NONE;
          return this._fetchData(n, c).catch((l) => {
            throw new Error(`Unable to load ${this.isCompressed ? "binary " : ""}CMap at: ${n}`);
          });
        }
        _fetchData(v, n) {
          (0, w.unreachable)("Abstract method `_fetchData` called.");
        }
      }
      class P {
        constructor({
          baseUrl: v = null
        }) {
          this.constructor === P && (0, w.unreachable)("Cannot initialize BaseStandardFontDataFactory."), this.baseUrl = v;
        }
        async fetch({
          filename: v
        }) {
          if (!this.baseUrl)
            throw new Error('The standard font "baseUrl" parameter must be specified, ensure that the "standardFontDataUrl" API parameter is provided.');
          if (!v)
            throw new Error("Font filename must be specified.");
          const n = `${this.baseUrl}${v}`;
          return this._fetchData(n).catch((c) => {
            throw new Error(`Unable to load font data at: ${n}`);
          });
        }
        _fetchData(v) {
          (0, w.unreachable)("Abstract method `_fetchData` called.");
        }
      }
      class T {
        constructor() {
          this.constructor === T && (0, w.unreachable)("Cannot initialize BaseSVGFactory.");
        }
        create(v, n, c = !1) {
          if (v <= 0 || n <= 0)
            throw new Error("Invalid SVG dimensions");
          const l = this._createSVG("svg:svg");
          return l.setAttribute("version", "1.1"), c || (l.setAttribute("width", `${v}px`), l.setAttribute("height", `${n}px`)), l.setAttribute("preserveAspectRatio", "none"), l.setAttribute("viewBox", `0 0 ${v} ${n}`), l;
        }
        createElement(v) {
          if (typeof v != "string")
            throw new Error("Invalid SVG element type");
          return this._createSVG(v);
        }
        _createSVG(v) {
          (0, w.unreachable)("Abstract method `_createSVG` called.");
        }
      }
    })
  ),
  /***/
  923: (
    /***/
    ((ct, st, V) => {
      V.d(st, {
        CanvasGraphics: () => (
          /* binding */
          m
        )
      });
      var w = V(292), B = V(419);
      const _ = {
        FILL: "Fill",
        STROKE: "Stroke",
        SHADING: "Shading"
      };
      function U(h, e) {
        if (!e)
          return;
        const r = e[2] - e[0], p = e[3] - e[1], o = new Path2D();
        o.rect(e[0], e[1], r, p), h.clip(o);
      }
      class P {
        constructor() {
          this.constructor === P && (0, w.unreachable)("Cannot initialize BaseShadingPattern.");
        }
        getPattern() {
          (0, w.unreachable)("Abstract method `getPattern` called.");
        }
      }
      class T extends P {
        constructor(e) {
          super(), this._type = e[1], this._bbox = e[2], this._colorStops = e[3], this._p0 = e[4], this._p1 = e[5], this._r0 = e[6], this._r1 = e[7], this.matrix = null;
        }
        _createGradient(e) {
          let r;
          this._type === "axial" ? r = e.createLinearGradient(this._p0[0], this._p0[1], this._p1[0], this._p1[1]) : this._type === "radial" && (r = e.createRadialGradient(this._p0[0], this._p0[1], this._r0, this._p1[0], this._p1[1], this._r1));
          for (const p of this._colorStops)
            r.addColorStop(p[0], p[1]);
          return r;
        }
        getPattern(e, r, p, o) {
          let a;
          if (o === _.STROKE || o === _.FILL) {
            const u = r.current.getClippedPathBoundingBox(o, (0, B.getCurrentTransform)(e)) || [0, 0, 0, 0], A = Math.ceil(u[2] - u[0]) || 1, x = Math.ceil(u[3] - u[1]) || 1, k = r.cachedCanvases.getCanvas("pattern", A, x, !0), R = k.context;
            R.clearRect(0, 0, R.canvas.width, R.canvas.height), R.beginPath(), R.rect(0, 0, R.canvas.width, R.canvas.height), R.translate(-u[0], -u[1]), p = w.Util.transform(p, [1, 0, 0, 1, u[0], u[1]]), R.transform(...r.baseTransform), this.matrix && R.transform(...this.matrix), U(R, this._bbox), R.fillStyle = this._createGradient(R), R.fill(), a = e.createPattern(k.canvas, "no-repeat");
            const D = new DOMMatrix(p);
            a.setTransform(D);
          } else
            U(e, this._bbox), a = this._createGradient(e);
          return a;
        }
      }
      function E(h, e, r, p, o, a, u, A) {
        const x = e.coords, k = e.colors, R = h.data, D = h.width * 4;
        let I;
        x[r + 1] > x[p + 1] && (I = r, r = p, p = I, I = a, a = u, u = I), x[p + 1] > x[o + 1] && (I = p, p = o, o = I, I = u, u = A, A = I), x[r + 1] > x[p + 1] && (I = r, r = p, p = I, I = a, a = u, u = I);
        const F = (x[r] + e.offsetX) * e.scaleX, C = (x[r + 1] + e.offsetY) * e.scaleY, $ = (x[p] + e.offsetX) * e.scaleX, K = (x[p + 1] + e.offsetY) * e.scaleY, X = (x[o] + e.offsetX) * e.scaleX, W = (x[o + 1] + e.offsetY) * e.scaleY;
        if (C >= W)
          return;
        const rt = k[a], J = k[a + 1], Q = k[a + 2], it = k[u], ht = k[u + 1], gt = k[u + 2], At = k[A], vt = k[A + 1], mt = k[A + 2], kt = Math.round(C), xt = Math.round(W);
        let Ct, yt, Et, Rt, Lt, _t, Ht, Mt;
        for (let Tt = kt; Tt <= xt; Tt++) {
          if (Tt < K) {
            const wt = Tt < C ? 0 : (C - Tt) / (C - K);
            Ct = F - (F - $) * wt, yt = rt - (rt - it) * wt, Et = J - (J - ht) * wt, Rt = Q - (Q - gt) * wt;
          } else {
            let wt;
            Tt > W ? wt = 1 : K === W ? wt = 0 : wt = (K - Tt) / (K - W), Ct = $ - ($ - X) * wt, yt = it - (it - At) * wt, Et = ht - (ht - vt) * wt, Rt = gt - (gt - mt) * wt;
          }
          let St;
          Tt < C ? St = 0 : Tt > W ? St = 1 : St = (C - Tt) / (C - W), Lt = F - (F - X) * St, _t = rt - (rt - At) * St, Ht = J - (J - vt) * St, Mt = Q - (Q - mt) * St;
          const Bt = Math.round(Math.min(Ct, Lt)), Dt = Math.round(Math.max(Ct, Lt));
          let It = D * Tt + Bt * 4;
          for (let wt = Bt; wt <= Dt; wt++)
            St = (Ct - wt) / (Ct - Lt), St < 0 ? St = 0 : St > 1 && (St = 1), R[It++] = yt - (yt - _t) * St | 0, R[It++] = Et - (Et - Ht) * St | 0, R[It++] = Rt - (Rt - Mt) * St | 0, R[It++] = 255;
        }
      }
      function v(h, e, r) {
        const p = e.coords, o = e.colors;
        let a, u;
        switch (e.type) {
          case "lattice":
            const A = e.verticesPerRow, x = Math.floor(p.length / A) - 1, k = A - 1;
            for (a = 0; a < x; a++) {
              let R = a * A;
              for (let D = 0; D < k; D++, R++)
                E(h, r, p[R], p[R + 1], p[R + A], o[R], o[R + 1], o[R + A]), E(h, r, p[R + A + 1], p[R + 1], p[R + A], o[R + A + 1], o[R + 1], o[R + A]);
            }
            break;
          case "triangles":
            for (a = 0, u = p.length; a < u; a += 3)
              E(h, r, p[a], p[a + 1], p[a + 2], o[a], o[a + 1], o[a + 2]);
            break;
          default:
            throw new Error("illegal figure");
        }
      }
      class n extends P {
        constructor(e) {
          super(), this._coords = e[2], this._colors = e[3], this._figures = e[4], this._bounds = e[5], this._bbox = e[7], this._background = e[8], this.matrix = null;
        }
        _createMeshCanvas(e, r, p) {
          const A = Math.floor(this._bounds[0]), x = Math.floor(this._bounds[1]), k = Math.ceil(this._bounds[2]) - A, R = Math.ceil(this._bounds[3]) - x, D = Math.min(Math.ceil(Math.abs(k * e[0] * 1.1)), 3e3), I = Math.min(Math.ceil(Math.abs(R * e[1] * 1.1)), 3e3), F = k / D, C = R / I, $ = {
            coords: this._coords,
            colors: this._colors,
            offsetX: -A,
            offsetY: -x,
            scaleX: 1 / F,
            scaleY: 1 / C
          }, K = D + 4, X = I + 4, W = p.getCanvas("mesh", K, X, !1), rt = W.context, J = rt.createImageData(D, I);
          if (r) {
            const it = J.data;
            for (let ht = 0, gt = it.length; ht < gt; ht += 4)
              it[ht] = r[0], it[ht + 1] = r[1], it[ht + 2] = r[2], it[ht + 3] = 255;
          }
          for (const it of this._figures)
            v(J, it, $);
          return rt.putImageData(J, 2, 2), {
            canvas: W.canvas,
            offsetX: A - 2 * F,
            offsetY: x - 2 * C,
            scaleX: F,
            scaleY: C
          };
        }
        getPattern(e, r, p, o) {
          U(e, this._bbox);
          let a;
          if (o === _.SHADING)
            a = w.Util.singularValueDecompose2dScale((0, B.getCurrentTransform)(e));
          else if (a = w.Util.singularValueDecompose2dScale(r.baseTransform), this.matrix) {
            const A = w.Util.singularValueDecompose2dScale(this.matrix);
            a = [a[0] * A[0], a[1] * A[1]];
          }
          const u = this._createMeshCanvas(a, o === _.SHADING ? null : this._background, r.cachedCanvases);
          return o !== _.SHADING && (e.setTransform(...r.baseTransform), this.matrix && e.transform(...this.matrix)), e.translate(u.offsetX, u.offsetY), e.scale(u.scaleX, u.scaleY), e.createPattern(u.canvas, "no-repeat");
        }
      }
      class c extends P {
        getPattern() {
          return "hotpink";
        }
      }
      function l(h) {
        switch (h[0]) {
          case "RadialAxial":
            return new T(h);
          case "Mesh":
            return new n(h);
          case "Dummy":
            return new c();
        }
        throw new Error(`Unknown IR type: ${h[0]}`);
      }
      const b = {
        COLORED: 1,
        UNCOLORED: 2
      };
      class s {
        static MAX_PATTERN_SIZE = 3e3;
        constructor(e, r, p, o, a) {
          this.operatorList = e[2], this.matrix = e[3] || [1, 0, 0, 1, 0, 0], this.bbox = e[4], this.xstep = e[5], this.ystep = e[6], this.paintType = e[7], this.tilingType = e[8], this.color = r, this.ctx = p, this.canvasGraphicsFactory = o, this.baseTransform = a;
        }
        createPatternCanvas(e) {
          const r = this.operatorList, p = this.bbox, o = this.xstep, a = this.ystep, u = this.paintType, A = this.tilingType, x = this.color, k = this.canvasGraphicsFactory;
          (0, w.info)("TilingType: " + A);
          const R = p[0], D = p[1], I = p[2], F = p[3], C = w.Util.singularValueDecompose2dScale(this.matrix), $ = w.Util.singularValueDecompose2dScale(this.baseTransform), K = [C[0] * $[0], C[1] * $[1]], X = this.getSizeAndScale(o, this.ctx.canvas.width, K[0]), W = this.getSizeAndScale(a, this.ctx.canvas.height, K[1]), rt = e.cachedCanvases.getCanvas("pattern", X.size, W.size, !0), J = rt.context, Q = k.createCanvasGraphics(J);
          Q.groupLevel = e.groupLevel, this.setFillAndStrokeStyleToContext(Q, u, x);
          let it = R, ht = D, gt = I, At = F;
          return R < 0 && (it = 0, gt += Math.abs(R)), D < 0 && (ht = 0, At += Math.abs(D)), J.translate(-(X.scale * it), -(W.scale * ht)), Q.transform(X.scale, 0, 0, W.scale, 0, 0), J.save(), this.clipBbox(Q, it, ht, gt, At), Q.baseTransform = (0, B.getCurrentTransform)(Q.ctx), Q.executeOperatorList(r), Q.endDrawing(), {
            canvas: rt.canvas,
            scaleX: X.scale,
            scaleY: W.scale,
            offsetX: it,
            offsetY: ht
          };
        }
        getSizeAndScale(e, r, p) {
          e = Math.abs(e);
          const o = Math.max(s.MAX_PATTERN_SIZE, r);
          let a = Math.ceil(e * p);
          return a >= o ? a = o : p = a / e, {
            scale: p,
            size: a
          };
        }
        clipBbox(e, r, p, o, a) {
          const u = o - r, A = a - p;
          e.ctx.rect(r, p, u, A), e.current.updateRectMinMax((0, B.getCurrentTransform)(e.ctx), [r, p, o, a]), e.clip(), e.endPath();
        }
        setFillAndStrokeStyleToContext(e, r, p) {
          const o = e.ctx, a = e.current;
          switch (r) {
            case b.COLORED:
              const u = this.ctx;
              o.fillStyle = u.fillStyle, o.strokeStyle = u.strokeStyle, a.fillColor = u.fillStyle, a.strokeColor = u.strokeStyle;
              break;
            case b.UNCOLORED:
              const A = w.Util.makeHexColor(p[0], p[1], p[2]);
              o.fillStyle = A, o.strokeStyle = A, a.fillColor = A, a.strokeColor = A;
              break;
            default:
              throw new w.FormatError(`Unsupported paint type: ${r}`);
          }
        }
        getPattern(e, r, p, o) {
          let a = p;
          o !== _.SHADING && (a = w.Util.transform(a, r.baseTransform), this.matrix && (a = w.Util.transform(a, this.matrix)));
          const u = this.createPatternCanvas(r);
          let A = new DOMMatrix(a);
          A = A.translate(u.offsetX, u.offsetY), A = A.scale(1 / u.scaleX, 1 / u.scaleY);
          const x = e.createPattern(u.canvas, "repeat");
          return x.setTransform(A), x;
        }
      }
      function g({
        src: h,
        srcPos: e = 0,
        dest: r,
        width: p,
        height: o,
        nonBlackColor: a = 4294967295,
        inverseDecode: u = !1
      }) {
        const A = w.FeatureTest.isLittleEndian ? 4278190080 : 255, [x, k] = u ? [a, A] : [A, a], R = p >> 3, D = p & 7, I = h.length;
        r = new Uint32Array(r.buffer);
        let F = 0;
        for (let C = 0; C < o; C++) {
          for (const K = e + R; e < K; e++) {
            const X = e < I ? h[e] : 255;
            r[F++] = X & 128 ? k : x, r[F++] = X & 64 ? k : x, r[F++] = X & 32 ? k : x, r[F++] = X & 16 ? k : x, r[F++] = X & 8 ? k : x, r[F++] = X & 4 ? k : x, r[F++] = X & 2 ? k : x, r[F++] = X & 1 ? k : x;
          }
          if (D === 0)
            continue;
          const $ = e < I ? h[e++] : 255;
          for (let K = 0; K < D; K++)
            r[F++] = $ & 1 << 7 - K ? k : x;
        }
        return {
          srcPos: e,
          destPos: F
        };
      }
      const t = 16, i = 100, d = 4096, f = 15, y = 10, S = 1e3, L = 16;
      function M(h, e) {
        if (h._removeMirroring)
          throw new Error("Context is already forwarding operations.");
        h.__originalSave = h.save, h.__originalRestore = h.restore, h.__originalRotate = h.rotate, h.__originalScale = h.scale, h.__originalTranslate = h.translate, h.__originalTransform = h.transform, h.__originalSetTransform = h.setTransform, h.__originalResetTransform = h.resetTransform, h.__originalClip = h.clip, h.__originalMoveTo = h.moveTo, h.__originalLineTo = h.lineTo, h.__originalBezierCurveTo = h.bezierCurveTo, h.__originalRect = h.rect, h.__originalClosePath = h.closePath, h.__originalBeginPath = h.beginPath, h._removeMirroring = () => {
          h.save = h.__originalSave, h.restore = h.__originalRestore, h.rotate = h.__originalRotate, h.scale = h.__originalScale, h.translate = h.__originalTranslate, h.transform = h.__originalTransform, h.setTransform = h.__originalSetTransform, h.resetTransform = h.__originalResetTransform, h.clip = h.__originalClip, h.moveTo = h.__originalMoveTo, h.lineTo = h.__originalLineTo, h.bezierCurveTo = h.__originalBezierCurveTo, h.rect = h.__originalRect, h.closePath = h.__originalClosePath, h.beginPath = h.__originalBeginPath, delete h._removeMirroring;
        }, h.save = function() {
          e.save(), this.__originalSave();
        }, h.restore = function() {
          e.restore(), this.__originalRestore();
        }, h.translate = function(p, o) {
          e.translate(p, o), this.__originalTranslate(p, o);
        }, h.scale = function(p, o) {
          e.scale(p, o), this.__originalScale(p, o);
        }, h.transform = function(p, o, a, u, A, x) {
          e.transform(p, o, a, u, A, x), this.__originalTransform(p, o, a, u, A, x);
        }, h.setTransform = function(p, o, a, u, A, x) {
          e.setTransform(p, o, a, u, A, x), this.__originalSetTransform(p, o, a, u, A, x);
        }, h.resetTransform = function() {
          e.resetTransform(), this.__originalResetTransform();
        }, h.rotate = function(p) {
          e.rotate(p), this.__originalRotate(p);
        }, h.clip = function(p) {
          e.clip(p), this.__originalClip(p);
        }, h.moveTo = function(r, p) {
          e.moveTo(r, p), this.__originalMoveTo(r, p);
        }, h.lineTo = function(r, p) {
          e.lineTo(r, p), this.__originalLineTo(r, p);
        }, h.bezierCurveTo = function(r, p, o, a, u, A) {
          e.bezierCurveTo(r, p, o, a, u, A), this.__originalBezierCurveTo(r, p, o, a, u, A);
        }, h.rect = function(r, p, o, a) {
          e.rect(r, p, o, a), this.__originalRect(r, p, o, a);
        }, h.closePath = function() {
          e.closePath(), this.__originalClosePath();
        }, h.beginPath = function() {
          e.beginPath(), this.__originalBeginPath();
        };
      }
      class N {
        constructor(e) {
          this.canvasFactory = e, this.cache = /* @__PURE__ */ Object.create(null);
        }
        getCanvas(e, r, p) {
          let o;
          return this.cache[e] !== void 0 ? (o = this.cache[e], this.canvasFactory.reset(o, r, p)) : (o = this.canvasFactory.create(r, p), this.cache[e] = o), o;
        }
        delete(e) {
          delete this.cache[e];
        }
        clear() {
          for (const e in this.cache) {
            const r = this.cache[e];
            this.canvasFactory.destroy(r), delete this.cache[e];
          }
        }
      }
      function H(h, e, r, p, o, a, u, A, x, k) {
        const [R, D, I, F, C, $] = (0, B.getCurrentTransform)(h);
        if (D === 0 && I === 0) {
          const W = u * R + C, rt = Math.round(W), J = A * F + $, Q = Math.round(J), it = (u + x) * R + C, ht = Math.abs(Math.round(it) - rt) || 1, gt = (A + k) * F + $, At = Math.abs(Math.round(gt) - Q) || 1;
          return h.setTransform(Math.sign(R), 0, 0, Math.sign(F), rt, Q), h.drawImage(e, r, p, o, a, 0, 0, ht, At), h.setTransform(R, D, I, F, C, $), [ht, At];
        }
        if (R === 0 && F === 0) {
          const W = A * I + C, rt = Math.round(W), J = u * D + $, Q = Math.round(J), it = (A + k) * I + C, ht = Math.abs(Math.round(it) - rt) || 1, gt = (u + x) * D + $, At = Math.abs(Math.round(gt) - Q) || 1;
          return h.setTransform(0, Math.sign(D), Math.sign(I), 0, rt, Q), h.drawImage(e, r, p, o, a, 0, 0, At, ht), h.setTransform(R, D, I, F, C, $), [At, ht];
        }
        h.drawImage(e, r, p, o, a, u, A, x, k);
        const K = Math.hypot(R, D), X = Math.hypot(I, F);
        return [K * x, X * k];
      }
      function z(h) {
        const {
          width: e,
          height: r
        } = h;
        if (e > S || r > S)
          return null;
        const p = 1e3, o = new Uint8Array([0, 2, 4, 0, 1, 0, 5, 4, 8, 10, 0, 8, 0, 2, 1, 0]), a = e + 1;
        let u = new Uint8Array(a * (r + 1)), A, x, k;
        const R = e + 7 & -8;
        let D = new Uint8Array(R * r), I = 0;
        for (const X of h.data) {
          let W = 128;
          for (; W > 0; )
            D[I++] = X & W ? 0 : 255, W >>= 1;
        }
        let F = 0;
        for (I = 0, D[I] !== 0 && (u[0] = 1, ++F), x = 1; x < e; x++)
          D[I] !== D[I + 1] && (u[x] = D[I] ? 2 : 1, ++F), I++;
        for (D[I] !== 0 && (u[x] = 2, ++F), A = 1; A < r; A++) {
          I = A * R, k = A * a, D[I - R] !== D[I] && (u[k] = D[I] ? 1 : 8, ++F);
          let X = (D[I] ? 4 : 0) + (D[I - R] ? 8 : 0);
          for (x = 1; x < e; x++)
            X = (X >> 2) + (D[I + 1] ? 4 : 0) + (D[I - R + 1] ? 8 : 0), o[X] && (u[k + x] = o[X], ++F), I++;
          if (D[I - R] !== D[I] && (u[k + x] = D[I] ? 2 : 4, ++F), F > p)
            return null;
        }
        for (I = R * (r - 1), k = A * a, D[I] !== 0 && (u[k] = 8, ++F), x = 1; x < e; x++)
          D[I] !== D[I + 1] && (u[k + x] = D[I] ? 4 : 8, ++F), I++;
        if (D[I] !== 0 && (u[k + x] = 4, ++F), F > p)
          return null;
        const C = new Int32Array([0, a, -1, 0, -a, 0, 0, 0, 1]), $ = new Path2D();
        for (A = 0; F && A <= r; A++) {
          let X = A * a;
          const W = X + e;
          for (; X < W && !u[X]; )
            X++;
          if (X === W)
            continue;
          $.moveTo(X % a, A);
          const rt = X;
          let J = u[X];
          do {
            const Q = C[J];
            do
              X += Q;
            while (!u[X]);
            const it = u[X];
            it !== 5 && it !== 10 ? (J = it, u[X] = 0) : (J = it & 51 * J >> 4, u[X] &= J >> 2 | J << 2), $.lineTo(X % a, X / a | 0), u[X] || --F;
          } while (rt !== X);
          --A;
        }
        return D = null, u = null, function(X) {
          X.save(), X.scale(1 / e, -1 / r), X.translate(0, -r), X.fill($), X.beginPath(), X.restore();
        };
      }
      class q {
        constructor(e, r) {
          this.alphaIsShape = !1, this.fontSize = 0, this.fontSizeScale = 1, this.textMatrix = w.IDENTITY_MATRIX, this.textMatrixScale = 1, this.fontMatrix = w.FONT_IDENTITY_MATRIX, this.leading = 0, this.x = 0, this.y = 0, this.lineX = 0, this.lineY = 0, this.charSpacing = 0, this.wordSpacing = 0, this.textHScale = 1, this.textRenderingMode = w.TextRenderingMode.FILL, this.textRise = 0, this.fillColor = "#000000", this.strokeColor = "#000000", this.patternFill = !1, this.fillAlpha = 1, this.strokeAlpha = 1, this.lineWidth = 1, this.activeSMask = null, this.transferMaps = "none", this.startNewPathAndClipBox([0, 0, e, r]);
        }
        clone() {
          const e = Object.create(this);
          return e.clipBox = this.clipBox.slice(), e;
        }
        setCurrentPoint(e, r) {
          this.x = e, this.y = r;
        }
        updatePathMinMax(e, r, p) {
          [r, p] = w.Util.applyTransform([r, p], e), this.minX = Math.min(this.minX, r), this.minY = Math.min(this.minY, p), this.maxX = Math.max(this.maxX, r), this.maxY = Math.max(this.maxY, p);
        }
        updateRectMinMax(e, r) {
          const p = w.Util.applyTransform(r, e), o = w.Util.applyTransform(r.slice(2), e), a = w.Util.applyTransform([r[0], r[3]], e), u = w.Util.applyTransform([r[2], r[1]], e);
          this.minX = Math.min(this.minX, p[0], o[0], a[0], u[0]), this.minY = Math.min(this.minY, p[1], o[1], a[1], u[1]), this.maxX = Math.max(this.maxX, p[0], o[0], a[0], u[0]), this.maxY = Math.max(this.maxY, p[1], o[1], a[1], u[1]);
        }
        updateScalingPathMinMax(e, r) {
          w.Util.scaleMinMax(e, r), this.minX = Math.min(this.minX, r[0]), this.minY = Math.min(this.minY, r[1]), this.maxX = Math.max(this.maxX, r[2]), this.maxY = Math.max(this.maxY, r[3]);
        }
        updateCurvePathMinMax(e, r, p, o, a, u, A, x, k, R) {
          const D = w.Util.bezierBoundingBox(r, p, o, a, u, A, x, k, R);
          R || this.updateRectMinMax(e, D);
        }
        getPathBoundingBox(e = _.FILL, r = null) {
          const p = [this.minX, this.minY, this.maxX, this.maxY];
          if (e === _.STROKE) {
            r || (0, w.unreachable)("Stroke bounding box must include transform.");
            const o = w.Util.singularValueDecompose2dScale(r), a = o[0] * this.lineWidth / 2, u = o[1] * this.lineWidth / 2;
            p[0] -= a, p[1] -= u, p[2] += a, p[3] += u;
          }
          return p;
        }
        updateClipFromPath() {
          const e = w.Util.intersect(this.clipBox, this.getPathBoundingBox());
          this.startNewPathAndClipBox(e || [0, 0, 0, 0]);
        }
        isEmptyClip() {
          return this.minX === 1 / 0;
        }
        startNewPathAndClipBox(e) {
          this.clipBox = e, this.minX = 1 / 0, this.minY = 1 / 0, this.maxX = 0, this.maxY = 0;
        }
        getClippedPathBoundingBox(e = _.FILL, r = null) {
          return w.Util.intersect(this.clipBox, this.getPathBoundingBox(e, r));
        }
      }
      function nt(h, e) {
        if (typeof ImageData < "u" && e instanceof ImageData) {
          h.putImageData(e, 0, 0);
          return;
        }
        const r = e.height, p = e.width, o = r % L, a = (r - o) / L, u = o === 0 ? a : a + 1, A = h.createImageData(p, L);
        let x = 0, k;
        const R = e.data, D = A.data;
        let I, F, C, $;
        if (e.kind === w.ImageKind.GRAYSCALE_1BPP) {
          const K = R.byteLength, X = new Uint32Array(D.buffer, 0, D.byteLength >> 2), W = X.length, rt = p + 7 >> 3, J = 4294967295, Q = w.FeatureTest.isLittleEndian ? 4278190080 : 255;
          for (I = 0; I < u; I++) {
            for (C = I < a ? L : o, k = 0, F = 0; F < C; F++) {
              const it = K - x;
              let ht = 0;
              const gt = it > rt ? p : it * 8 - 7, At = gt & -8;
              let vt = 0, mt = 0;
              for (; ht < At; ht += 8)
                mt = R[x++], X[k++] = mt & 128 ? J : Q, X[k++] = mt & 64 ? J : Q, X[k++] = mt & 32 ? J : Q, X[k++] = mt & 16 ? J : Q, X[k++] = mt & 8 ? J : Q, X[k++] = mt & 4 ? J : Q, X[k++] = mt & 2 ? J : Q, X[k++] = mt & 1 ? J : Q;
              for (; ht < gt; ht++)
                vt === 0 && (mt = R[x++], vt = 128), X[k++] = mt & vt ? J : Q, vt >>= 1;
            }
            for (; k < W; )
              X[k++] = 0;
            h.putImageData(A, 0, I * L);
          }
        } else if (e.kind === w.ImageKind.RGBA_32BPP) {
          for (F = 0, $ = p * L * 4, I = 0; I < a; I++)
            D.set(R.subarray(x, x + $)), x += $, h.putImageData(A, 0, F), F += L;
          I < u && ($ = p * o * 4, D.set(R.subarray(x, x + $)), h.putImageData(A, 0, F));
        } else if (e.kind === w.ImageKind.RGB_24BPP)
          for (C = L, $ = p * C, I = 0; I < u; I++) {
            for (I >= a && (C = o, $ = p * C), k = 0, F = $; F--; )
              D[k++] = R[x++], D[k++] = R[x++], D[k++] = R[x++], D[k++] = 255;
            h.putImageData(A, 0, I * L);
          }
        else
          throw new Error(`bad image kind: ${e.kind}`);
      }
      function j(h, e) {
        if (e.bitmap) {
          h.drawImage(e.bitmap, 0, 0);
          return;
        }
        const r = e.height, p = e.width, o = r % L, a = (r - o) / L, u = o === 0 ? a : a + 1, A = h.createImageData(p, L);
        let x = 0;
        const k = e.data, R = A.data;
        for (let D = 0; D < u; D++) {
          const I = D < a ? L : o;
          ({
            srcPos: x
          } = g({
            src: k,
            srcPos: x,
            dest: R,
            width: p,
            height: I,
            nonBlackColor: 0
          })), h.putImageData(A, 0, D * L);
        }
      }
      function O(h, e) {
        const r = ["strokeStyle", "fillStyle", "fillRule", "globalAlpha", "lineWidth", "lineCap", "lineJoin", "miterLimit", "globalCompositeOperation", "font", "filter"];
        for (const p of r)
          h[p] !== void 0 && (e[p] = h[p]);
        h.setLineDash !== void 0 && (e.setLineDash(h.getLineDash()), e.lineDashOffset = h.lineDashOffset);
      }
      function G(h) {
        if (h.strokeStyle = h.fillStyle = "#000000", h.fillRule = "nonzero", h.globalAlpha = 1, h.lineWidth = 1, h.lineCap = "butt", h.lineJoin = "miter", h.miterLimit = 10, h.globalCompositeOperation = "source-over", h.font = "10px sans-serif", h.setLineDash !== void 0 && (h.setLineDash([]), h.lineDashOffset = 0), !w.isNodeJS) {
          const {
            filter: e
          } = h;
          e !== "none" && e !== "" && (h.filter = "none");
        }
      }
      function Y(h, e, r, p) {
        const o = h.length;
        for (let a = 3; a < o; a += 4) {
          const u = h[a];
          if (u === 0)
            h[a - 3] = e, h[a - 2] = r, h[a - 1] = p;
          else if (u < 255) {
            const A = 255 - u;
            h[a - 3] = h[a - 3] * u + e * A >> 8, h[a - 2] = h[a - 2] * u + r * A >> 8, h[a - 1] = h[a - 1] * u + p * A >> 8;
          }
        }
      }
      function tt(h, e, r) {
        const p = h.length, o = 1 / 255;
        for (let a = 3; a < p; a += 4) {
          const u = r ? r[h[a]] : h[a];
          e[a] = e[a] * u * o | 0;
        }
      }
      function Z(h, e, r) {
        const p = h.length;
        for (let o = 3; o < p; o += 4) {
          const a = h[o - 3] * 77 + h[o - 2] * 152 + h[o - 1] * 28;
          e[o] = r ? e[o] * r[a >> 8] >> 8 : e[o] * a >> 16;
        }
      }
      function at(h, e, r, p, o, a, u, A, x, k, R) {
        const D = !!a, I = D ? a[0] : 0, F = D ? a[1] : 0, C = D ? a[2] : 0, $ = o === "Luminosity" ? Z : tt, X = Math.min(p, Math.ceil(1048576 / r));
        for (let W = 0; W < p; W += X) {
          const rt = Math.min(X, p - W), J = h.getImageData(A - k, W + (x - R), r, rt), Q = e.getImageData(A, W + x, r, rt);
          D && Y(J.data, I, F, C), $(J.data, Q.data, u), e.putImageData(Q, A, W + x);
        }
      }
      function lt(h, e, r, p) {
        const o = p[0], a = p[1], u = p[2] - o, A = p[3] - a;
        u === 0 || A === 0 || (at(e.context, r, u, A, e.subtype, e.backdrop, e.transferMap, o, a, e.offsetX, e.offsetY), h.save(), h.globalAlpha = 1, h.globalCompositeOperation = "source-over", h.setTransform(1, 0, 0, 1, 0, 0), h.drawImage(r.canvas, 0, 0), h.restore());
      }
      function pt(h, e) {
        if (e)
          return !0;
        const r = w.Util.singularValueDecompose2dScale(h);
        r[0] = Math.fround(r[0]), r[1] = Math.fround(r[1]);
        const p = Math.fround((globalThis.devicePixelRatio || 1) * B.PixelsPerInch.PDF_TO_CSS_UNITS);
        return r[0] <= p && r[1] <= p;
      }
      const dt = ["butt", "round", "square"], ot = ["miter", "round", "bevel"], ut = {}, et = {};
      class m {
        constructor(e, r, p, o, a, {
          optionalContentConfig: u,
          markedContentStack: A = null
        }, x, k) {
          this.ctx = e, this.current = new q(this.ctx.canvas.width, this.ctx.canvas.height), this.stateStack = [], this.pendingClip = null, this.pendingEOFill = !1, this.res = null, this.xobjs = null, this.commonObjs = r, this.objs = p, this.canvasFactory = o, this.filterFactory = a, this.groupStack = [], this.processingType3 = null, this.baseTransform = null, this.baseTransformStack = [], this.groupLevel = 0, this.smaskStack = [], this.smaskCounter = 0, this.tempSMask = null, this.suspendedCtx = null, this.contentVisible = !0, this.markedContentStack = A || [], this.optionalContentConfig = u, this.cachedCanvases = new N(this.canvasFactory), this.cachedPatterns = /* @__PURE__ */ new Map(), this.annotationCanvasMap = x, this.viewportScale = 1, this.outputScaleX = 1, this.outputScaleY = 1, this.pageColors = k, this._cachedScaleForStroking = [-1, 0], this._cachedGetSinglePixelWidth = null, this._cachedBitmapsMap = /* @__PURE__ */ new Map();
        }
        getObject(e, r = null) {
          return typeof e == "string" ? e.startsWith("g_") ? this.commonObjs.get(e) : this.objs.get(e) : r;
        }
        beginDrawing({
          transform: e,
          viewport: r,
          transparency: p = !1,
          background: o = null
        }) {
          const a = this.ctx.canvas.width, u = this.ctx.canvas.height, A = this.ctx.fillStyle;
          if (this.ctx.fillStyle = o || "#ffffff", this.ctx.fillRect(0, 0, a, u), this.ctx.fillStyle = A, p) {
            const x = this.cachedCanvases.getCanvas("transparent", a, u);
            this.compositeCtx = this.ctx, this.transparentCanvas = x.canvas, this.ctx = x.context, this.ctx.save(), this.ctx.transform(...(0, B.getCurrentTransform)(this.compositeCtx));
          }
          this.ctx.save(), G(this.ctx), e && (this.ctx.transform(...e), this.outputScaleX = e[0], this.outputScaleY = e[0]), this.ctx.transform(...r.transform), this.viewportScale = r.scale, this.baseTransform = (0, B.getCurrentTransform)(this.ctx);
        }
        executeOperatorList(e, r, p, o) {
          const a = e.argsArray, u = e.fnArray;
          let A = r || 0;
          const x = a.length;
          if (x === A)
            return A;
          const k = x - A > y && typeof p == "function", R = k ? Date.now() + f : 0;
          let D = 0;
          const I = this.commonObjs, F = this.objs;
          let C;
          for (; ; ) {
            if (o !== void 0 && A === o.nextBreakPoint)
              return o.breakIt(A, p), A;
            if (C = u[A], C !== w.OPS.dependency)
              this[C].apply(this, a[A]);
            else
              for (const $ of a[A]) {
                const K = $.startsWith("g_") ? I : F;
                if (!K.has($))
                  return K.get($, p), A;
              }
            if (A++, A === x)
              return A;
            if (k && ++D > y) {
              if (Date.now() > R)
                return p(), A;
              D = 0;
            }
          }
        }
        #t() {
          for (; this.stateStack.length || this.inSMaskMode; )
            this.restore();
          this.ctx.restore(), this.transparentCanvas && (this.ctx = this.compositeCtx, this.ctx.save(), this.ctx.setTransform(1, 0, 0, 1, 0, 0), this.ctx.drawImage(this.transparentCanvas, 0, 0), this.ctx.restore(), this.transparentCanvas = null);
        }
        endDrawing() {
          this.#t(), this.cachedCanvases.clear(), this.cachedPatterns.clear();
          for (const e of this._cachedBitmapsMap.values()) {
            for (const r of e.values())
              typeof HTMLCanvasElement < "u" && r instanceof HTMLCanvasElement && (r.width = r.height = 0);
            e.clear();
          }
          this._cachedBitmapsMap.clear(), this.#e();
        }
        #e() {
          if (this.pageColors) {
            const e = this.filterFactory.addHCMFilter(this.pageColors.foreground, this.pageColors.background);
            if (e !== "none") {
              const r = this.ctx.filter;
              this.ctx.filter = e, this.ctx.drawImage(this.ctx.canvas, 0, 0), this.ctx.filter = r;
            }
          }
        }
        _scaleImage(e, r) {
          const p = e.width, o = e.height;
          let a = Math.max(Math.hypot(r[0], r[1]), 1), u = Math.max(Math.hypot(r[2], r[3]), 1), A = p, x = o, k = "prescale1", R, D;
          for (; a > 2 && A > 1 || u > 2 && x > 1; ) {
            let I = A, F = x;
            a > 2 && A > 1 && (I = A >= 16384 ? Math.floor(A / 2) - 1 || 1 : Math.ceil(A / 2), a /= A / I), u > 2 && x > 1 && (F = x >= 16384 ? Math.floor(x / 2) - 1 || 1 : Math.ceil(x) / 2, u /= x / F), R = this.cachedCanvases.getCanvas(k, I, F), D = R.context, D.clearRect(0, 0, I, F), D.drawImage(e, 0, 0, A, x, 0, 0, I, F), e = R.canvas, A = I, x = F, k = k === "prescale1" ? "prescale2" : "prescale1";
          }
          return {
            img: e,
            paintWidth: A,
            paintHeight: x
          };
        }
        _createMaskCanvas(e) {
          const r = this.ctx, {
            width: p,
            height: o
          } = e, a = this.current.fillColor, u = this.current.patternFill, A = (0, B.getCurrentTransform)(r);
          let x, k, R, D;
          if ((e.bitmap || e.data) && e.count > 1) {
            const gt = e.bitmap || e.data.buffer;
            k = JSON.stringify(u ? A : [A.slice(0, 4), a]), x = this._cachedBitmapsMap.get(gt), x || (x = /* @__PURE__ */ new Map(), this._cachedBitmapsMap.set(gt, x));
            const At = x.get(k);
            if (At && !u) {
              const vt = Math.round(Math.min(A[0], A[2]) + A[4]), mt = Math.round(Math.min(A[1], A[3]) + A[5]);
              return {
                canvas: At,
                offsetX: vt,
                offsetY: mt
              };
            }
            R = At;
          }
          R || (D = this.cachedCanvases.getCanvas("maskCanvas", p, o), j(D.context, e));
          let I = w.Util.transform(A, [1 / p, 0, 0, -1 / o, 0, 0]);
          I = w.Util.transform(I, [1, 0, 0, 1, 0, -o]);
          const [F, C, $, K] = w.Util.getAxialAlignedBoundingBox([0, 0, p, o], I), X = Math.round($ - F) || 1, W = Math.round(K - C) || 1, rt = this.cachedCanvases.getCanvas("fillCanvas", X, W), J = rt.context, Q = F, it = C;
          J.translate(-Q, -it), J.transform(...I), R || (R = this._scaleImage(D.canvas, (0, B.getCurrentTransformInverse)(J)), R = R.img, x && u && x.set(k, R)), J.imageSmoothingEnabled = pt((0, B.getCurrentTransform)(J), e.interpolate), H(J, R, 0, 0, R.width, R.height, 0, 0, p, o), J.globalCompositeOperation = "source-in";
          const ht = w.Util.transform((0, B.getCurrentTransformInverse)(J), [1, 0, 0, 1, -Q, -it]);
          return J.fillStyle = u ? a.getPattern(r, this, ht, _.FILL) : a, J.fillRect(0, 0, p, o), x && !u && (this.cachedCanvases.delete("fillCanvas"), x.set(k, rt.canvas)), {
            canvas: rt.canvas,
            offsetX: Math.round(Q),
            offsetY: Math.round(it)
          };
        }
        setLineWidth(e) {
          e !== this.current.lineWidth && (this._cachedScaleForStroking[0] = -1), this.current.lineWidth = e, this.ctx.lineWidth = e;
        }
        setLineCap(e) {
          this.ctx.lineCap = dt[e];
        }
        setLineJoin(e) {
          this.ctx.lineJoin = ot[e];
        }
        setMiterLimit(e) {
          this.ctx.miterLimit = e;
        }
        setDash(e, r) {
          const p = this.ctx;
          p.setLineDash !== void 0 && (p.setLineDash(e), p.lineDashOffset = r);
        }
        setRenderingIntent(e) {
        }
        setFlatness(e) {
        }
        setGState(e) {
          for (const [r, p] of e)
            switch (r) {
              case "LW":
                this.setLineWidth(p);
                break;
              case "LC":
                this.setLineCap(p);
                break;
              case "LJ":
                this.setLineJoin(p);
                break;
              case "ML":
                this.setMiterLimit(p);
                break;
              case "D":
                this.setDash(p[0], p[1]);
                break;
              case "RI":
                this.setRenderingIntent(p);
                break;
              case "FL":
                this.setFlatness(p);
                break;
              case "Font":
                this.setFont(p[0], p[1]);
                break;
              case "CA":
                this.current.strokeAlpha = p;
                break;
              case "ca":
                this.current.fillAlpha = p, this.ctx.globalAlpha = p;
                break;
              case "BM":
                this.ctx.globalCompositeOperation = p;
                break;
              case "SMask":
                this.current.activeSMask = p ? this.tempSMask : null, this.tempSMask = null, this.checkSMaskState();
                break;
              case "TR":
                this.ctx.filter = this.current.transferMaps = this.filterFactory.addFilter(p);
                break;
            }
        }
        get inSMaskMode() {
          return !!this.suspendedCtx;
        }
        checkSMaskState() {
          const e = this.inSMaskMode;
          this.current.activeSMask && !e ? this.beginSMaskMode() : !this.current.activeSMask && e && this.endSMaskMode();
        }
        beginSMaskMode() {
          if (this.inSMaskMode)
            throw new Error("beginSMaskMode called while already in smask mode");
          const e = this.ctx.canvas.width, r = this.ctx.canvas.height, p = "smaskGroupAt" + this.groupLevel, o = this.cachedCanvases.getCanvas(p, e, r);
          this.suspendedCtx = this.ctx, this.ctx = o.context;
          const a = this.ctx;
          a.setTransform(...(0, B.getCurrentTransform)(this.suspendedCtx)), O(this.suspendedCtx, a), M(a, this.suspendedCtx), this.setGState([["BM", "source-over"], ["ca", 1], ["CA", 1]]);
        }
        endSMaskMode() {
          if (!this.inSMaskMode)
            throw new Error("endSMaskMode called while not in smask mode");
          this.ctx._removeMirroring(), O(this.ctx, this.suspendedCtx), this.ctx = this.suspendedCtx, this.suspendedCtx = null;
        }
        compose(e) {
          if (!this.current.activeSMask)
            return;
          e ? (e[0] = Math.floor(e[0]), e[1] = Math.floor(e[1]), e[2] = Math.ceil(e[2]), e[3] = Math.ceil(e[3])) : e = [0, 0, this.ctx.canvas.width, this.ctx.canvas.height];
          const r = this.current.activeSMask, p = this.suspendedCtx;
          lt(p, r, this.ctx, e), this.ctx.save(), this.ctx.setTransform(1, 0, 0, 1, 0, 0), this.ctx.clearRect(0, 0, this.ctx.canvas.width, this.ctx.canvas.height), this.ctx.restore();
        }
        save() {
          this.inSMaskMode ? (O(this.ctx, this.suspendedCtx), this.suspendedCtx.save()) : this.ctx.save();
          const e = this.current;
          this.stateStack.push(e), this.current = e.clone();
        }
        restore() {
          this.stateStack.length === 0 && this.inSMaskMode && this.endSMaskMode(), this.stateStack.length !== 0 && (this.current = this.stateStack.pop(), this.inSMaskMode ? (this.suspendedCtx.restore(), O(this.suspendedCtx, this.ctx)) : this.ctx.restore(), this.checkSMaskState(), this.pendingClip = null, this._cachedScaleForStroking[0] = -1, this._cachedGetSinglePixelWidth = null);
        }
        transform(e, r, p, o, a, u) {
          this.ctx.transform(e, r, p, o, a, u), this._cachedScaleForStroking[0] = -1, this._cachedGetSinglePixelWidth = null;
        }
        constructPath(e, r, p) {
          const o = this.ctx, a = this.current;
          let u = a.x, A = a.y, x, k;
          const R = (0, B.getCurrentTransform)(o), D = R[0] === 0 && R[3] === 0 || R[1] === 0 && R[2] === 0, I = D ? p.slice(0) : null;
          for (let F = 0, C = 0, $ = e.length; F < $; F++)
            switch (e[F] | 0) {
              case w.OPS.rectangle:
                u = r[C++], A = r[C++];
                const K = r[C++], X = r[C++], W = u + K, rt = A + X;
                o.moveTo(u, A), K === 0 || X === 0 ? o.lineTo(W, rt) : (o.lineTo(W, A), o.lineTo(W, rt), o.lineTo(u, rt)), D || a.updateRectMinMax(R, [u, A, W, rt]), o.closePath();
                break;
              case w.OPS.moveTo:
                u = r[C++], A = r[C++], o.moveTo(u, A), D || a.updatePathMinMax(R, u, A);
                break;
              case w.OPS.lineTo:
                u = r[C++], A = r[C++], o.lineTo(u, A), D || a.updatePathMinMax(R, u, A);
                break;
              case w.OPS.curveTo:
                x = u, k = A, u = r[C + 4], A = r[C + 5], o.bezierCurveTo(r[C], r[C + 1], r[C + 2], r[C + 3], u, A), a.updateCurvePathMinMax(R, x, k, r[C], r[C + 1], r[C + 2], r[C + 3], u, A, I), C += 6;
                break;
              case w.OPS.curveTo2:
                x = u, k = A, o.bezierCurveTo(u, A, r[C], r[C + 1], r[C + 2], r[C + 3]), a.updateCurvePathMinMax(R, x, k, u, A, r[C], r[C + 1], r[C + 2], r[C + 3], I), u = r[C + 2], A = r[C + 3], C += 4;
                break;
              case w.OPS.curveTo3:
                x = u, k = A, u = r[C + 2], A = r[C + 3], o.bezierCurveTo(r[C], r[C + 1], u, A, u, A), a.updateCurvePathMinMax(R, x, k, r[C], r[C + 1], u, A, u, A, I), C += 4;
                break;
              case w.OPS.closePath:
                o.closePath();
                break;
            }
          D && a.updateScalingPathMinMax(R, I), a.setCurrentPoint(u, A);
        }
        closePath() {
          this.ctx.closePath();
        }
        stroke(e = !0) {
          const r = this.ctx, p = this.current.strokeColor;
          r.globalAlpha = this.current.strokeAlpha, this.contentVisible && (typeof p == "object" && p?.getPattern ? (r.save(), r.strokeStyle = p.getPattern(r, this, (0, B.getCurrentTransformInverse)(r), _.STROKE), this.rescaleAndStroke(!1), r.restore()) : this.rescaleAndStroke(!0)), e && this.consumePath(this.current.getClippedPathBoundingBox()), r.globalAlpha = this.current.fillAlpha;
        }
        closeStroke() {
          this.closePath(), this.stroke();
        }
        fill(e = !0) {
          const r = this.ctx, p = this.current.fillColor, o = this.current.patternFill;
          let a = !1;
          o && (r.save(), r.fillStyle = p.getPattern(r, this, (0, B.getCurrentTransformInverse)(r), _.FILL), a = !0);
          const u = this.current.getClippedPathBoundingBox();
          this.contentVisible && u !== null && (this.pendingEOFill ? (r.fill("evenodd"), this.pendingEOFill = !1) : r.fill()), a && r.restore(), e && this.consumePath(u);
        }
        eoFill() {
          this.pendingEOFill = !0, this.fill();
        }
        fillStroke() {
          this.fill(!1), this.stroke(!1), this.consumePath();
        }
        eoFillStroke() {
          this.pendingEOFill = !0, this.fillStroke();
        }
        closeFillStroke() {
          this.closePath(), this.fillStroke();
        }
        closeEOFillStroke() {
          this.pendingEOFill = !0, this.closePath(), this.fillStroke();
        }
        endPath() {
          this.consumePath();
        }
        clip() {
          this.pendingClip = ut;
        }
        eoClip() {
          this.pendingClip = et;
        }
        beginText() {
          this.current.textMatrix = w.IDENTITY_MATRIX, this.current.textMatrixScale = 1, this.current.x = this.current.lineX = 0, this.current.y = this.current.lineY = 0;
        }
        endText() {
          const e = this.pendingTextPaths, r = this.ctx;
          if (e === void 0) {
            r.beginPath();
            return;
          }
          r.save(), r.beginPath();
          for (const p of e)
            r.setTransform(...p.transform), r.translate(p.x, p.y), p.addToPath(r, p.fontSize);
          r.restore(), r.clip(), r.beginPath(), delete this.pendingTextPaths;
        }
        setCharSpacing(e) {
          this.current.charSpacing = e;
        }
        setWordSpacing(e) {
          this.current.wordSpacing = e;
        }
        setHScale(e) {
          this.current.textHScale = e / 100;
        }
        setLeading(e) {
          this.current.leading = -e;
        }
        setFont(e, r) {
          const p = this.commonObjs.get(e), o = this.current;
          if (!p)
            throw new Error(`Can't find font for ${e}`);
          if (o.fontMatrix = p.fontMatrix || w.FONT_IDENTITY_MATRIX, (o.fontMatrix[0] === 0 || o.fontMatrix[3] === 0) && (0, w.warn)("Invalid font matrix for font " + e), r < 0 ? (r = -r, o.fontDirection = -1) : o.fontDirection = 1, this.current.font = p, this.current.fontSize = r, p.isType3Font)
            return;
          const a = p.loadedName || "sans-serif", u = p.systemFontInfo?.css || `"${a}", ${p.fallbackName}`;
          let A = "normal";
          p.black ? A = "900" : p.bold && (A = "bold");
          const x = p.italic ? "italic" : "normal";
          let k = r;
          r < t ? k = t : r > i && (k = i), this.current.fontSizeScale = r / k, this.ctx.font = `${x} ${A} ${k}px ${u}`;
        }
        setTextRenderingMode(e) {
          this.current.textRenderingMode = e;
        }
        setTextRise(e) {
          this.current.textRise = e;
        }
        moveText(e, r) {
          this.current.x = this.current.lineX += e, this.current.y = this.current.lineY += r;
        }
        setLeadingMoveText(e, r) {
          this.setLeading(-r), this.moveText(e, r);
        }
        setTextMatrix(e, r, p, o, a, u) {
          this.current.textMatrix = [e, r, p, o, a, u], this.current.textMatrixScale = Math.hypot(e, r), this.current.x = this.current.lineX = 0, this.current.y = this.current.lineY = 0;
        }
        nextLine() {
          this.moveText(0, this.current.leading);
        }
        paintChar(e, r, p, o) {
          const a = this.ctx, u = this.current, A = u.font, x = u.textRenderingMode, k = u.fontSize / u.fontSizeScale, R = x & w.TextRenderingMode.FILL_STROKE_MASK, D = !!(x & w.TextRenderingMode.ADD_TO_PATH_FLAG), I = u.patternFill && !A.missingFile;
          let F;
          (A.disableFontFace || D || I) && (F = A.getPathGenerator(this.commonObjs, e)), A.disableFontFace || I ? (a.save(), a.translate(r, p), a.beginPath(), F(a, k), o && a.setTransform(...o), (R === w.TextRenderingMode.FILL || R === w.TextRenderingMode.FILL_STROKE) && a.fill(), (R === w.TextRenderingMode.STROKE || R === w.TextRenderingMode.FILL_STROKE) && a.stroke(), a.restore()) : ((R === w.TextRenderingMode.FILL || R === w.TextRenderingMode.FILL_STROKE) && a.fillText(e, r, p), (R === w.TextRenderingMode.STROKE || R === w.TextRenderingMode.FILL_STROKE) && a.strokeText(e, r, p)), D && (this.pendingTextPaths ||= []).push({
            transform: (0, B.getCurrentTransform)(a),
            x: r,
            y: p,
            fontSize: k,
            addToPath: F
          });
        }
        get isFontSubpixelAAEnabled() {
          const {
            context: e
          } = this.cachedCanvases.getCanvas("isFontSubpixelAAEnabled", 10, 10);
          e.scale(1.5, 1), e.fillText("I", 0, 10);
          const r = e.getImageData(0, 0, 10, 10).data;
          let p = !1;
          for (let o = 3; o < r.length; o += 4)
            if (r[o] > 0 && r[o] < 255) {
              p = !0;
              break;
            }
          return (0, w.shadow)(this, "isFontSubpixelAAEnabled", p);
        }
        showText(e) {
          const r = this.current, p = r.font;
          if (p.isType3Font)
            return this.showType3Text(e);
          const o = r.fontSize;
          if (o === 0)
            return;
          const a = this.ctx, u = r.fontSizeScale, A = r.charSpacing, x = r.wordSpacing, k = r.fontDirection, R = r.textHScale * k, D = e.length, I = p.vertical, F = I ? 1 : -1, C = p.defaultVMetrics, $ = o * r.fontMatrix[0], K = r.textRenderingMode === w.TextRenderingMode.FILL && !p.disableFontFace && !r.patternFill;
          a.save(), a.transform(...r.textMatrix), a.translate(r.x, r.y + r.textRise), k > 0 ? a.scale(R, -1) : a.scale(R, 1);
          let X;
          if (r.patternFill) {
            a.save();
            const it = r.fillColor.getPattern(a, this, (0, B.getCurrentTransformInverse)(a), _.FILL);
            X = (0, B.getCurrentTransform)(a), a.restore(), a.fillStyle = it;
          }
          let W = r.lineWidth;
          const rt = r.textMatrixScale;
          if (rt === 0 || W === 0) {
            const it = r.textRenderingMode & w.TextRenderingMode.FILL_STROKE_MASK;
            (it === w.TextRenderingMode.STROKE || it === w.TextRenderingMode.FILL_STROKE) && (W = this.getSinglePixelWidth());
          } else
            W /= rt;
          if (u !== 1 && (a.scale(u, u), W /= u), a.lineWidth = W, p.isInvalidPDFjsFont) {
            const it = [];
            let ht = 0;
            for (const gt of e)
              it.push(gt.unicode), ht += gt.width;
            a.fillText(it.join(""), 0, 0), r.x += ht * $ * R, a.restore(), this.compose();
            return;
          }
          let J = 0, Q;
          for (Q = 0; Q < D; ++Q) {
            const it = e[Q];
            if (typeof it == "number") {
              J += F * it * o / 1e3;
              continue;
            }
            let ht = !1;
            const gt = (it.isSpace ? x : 0) + A, At = it.fontChar, vt = it.accent;
            let mt, kt, xt = it.width;
            if (I) {
              const yt = it.vmetric || C, Et = -(it.vmetric ? yt[1] : xt * 0.5) * $, Rt = yt[2] * $;
              xt = yt ? -yt[0] : xt, mt = Et / u, kt = (J + Rt) / u;
            } else
              mt = J / u, kt = 0;
            if (p.remeasure && xt > 0) {
              const yt = a.measureText(At).width * 1e3 / o * u;
              if (xt < yt && this.isFontSubpixelAAEnabled) {
                const Et = xt / yt;
                ht = !0, a.save(), a.scale(Et, 1), mt /= Et;
              } else xt !== yt && (mt += (xt - yt) / 2e3 * o / u);
            }
            if (this.contentVisible && (it.isInFont || p.missingFile)) {
              if (K && !vt)
                a.fillText(At, mt, kt);
              else if (this.paintChar(At, mt, kt, X), vt) {
                const yt = mt + o * vt.offset.x / u, Et = kt - o * vt.offset.y / u;
                this.paintChar(vt.fontChar, yt, Et, X);
              }
            }
            const Ct = I ? xt * $ - gt * k : xt * $ + gt * k;
            J += Ct, ht && a.restore();
          }
          I ? r.y -= J : r.x += J * R, a.restore(), this.compose();
        }
        showType3Text(e) {
          const r = this.ctx, p = this.current, o = p.font, a = p.fontSize, u = p.fontDirection, A = o.vertical ? 1 : -1, x = p.charSpacing, k = p.wordSpacing, R = p.textHScale * u, D = p.fontMatrix || w.FONT_IDENTITY_MATRIX, I = e.length, F = p.textRenderingMode === w.TextRenderingMode.INVISIBLE;
          let C, $, K, X;
          if (!(F || a === 0)) {
            for (this._cachedScaleForStroking[0] = -1, this._cachedGetSinglePixelWidth = null, r.save(), r.transform(...p.textMatrix), r.translate(p.x, p.y), r.scale(R, u), C = 0; C < I; ++C) {
              if ($ = e[C], typeof $ == "number") {
                X = A * $ * a / 1e3, this.ctx.translate(X, 0), p.x += X * R;
                continue;
              }
              const W = ($.isSpace ? k : 0) + x, rt = o.charProcOperatorList[$.operatorListId];
              if (!rt) {
                (0, w.warn)(`Type3 character "${$.operatorListId}" is not available.`);
                continue;
              }
              this.contentVisible && (this.processingType3 = $, this.save(), r.scale(a, a), r.transform(...D), this.executeOperatorList(rt), this.restore()), K = w.Util.applyTransform([$.width, 0], D)[0] * a + W, r.translate(K, 0), p.x += K * R;
            }
            r.restore(), this.processingType3 = null;
          }
        }
        setCharWidth(e, r) {
        }
        setCharWidthAndBounds(e, r, p, o, a, u) {
          this.ctx.rect(p, o, a - p, u - o), this.ctx.clip(), this.endPath();
        }
        getColorN_Pattern(e) {
          let r;
          if (e[0] === "TilingPattern") {
            const p = e[1], o = this.baseTransform || (0, B.getCurrentTransform)(this.ctx), a = {
              createCanvasGraphics: (u) => new m(u, this.commonObjs, this.objs, this.canvasFactory, this.filterFactory, {
                optionalContentConfig: this.optionalContentConfig,
                markedContentStack: this.markedContentStack
              })
            };
            r = new s(e, p, this.ctx, a, o);
          } else
            r = this._getPattern(e[1], e[2]);
          return r;
        }
        setStrokeColorN() {
          this.current.strokeColor = this.getColorN_Pattern(arguments);
        }
        setFillColorN() {
          this.current.fillColor = this.getColorN_Pattern(arguments), this.current.patternFill = !0;
        }
        setStrokeRGBColor(e, r, p) {
          const o = w.Util.makeHexColor(e, r, p);
          this.ctx.strokeStyle = o, this.current.strokeColor = o;
        }
        setFillRGBColor(e, r, p) {
          const o = w.Util.makeHexColor(e, r, p);
          this.ctx.fillStyle = o, this.current.fillColor = o, this.current.patternFill = !1;
        }
        _getPattern(e, r = null) {
          let p;
          return this.cachedPatterns.has(e) ? p = this.cachedPatterns.get(e) : (p = l(this.getObject(e)), this.cachedPatterns.set(e, p)), r && (p.matrix = r), p;
        }
        shadingFill(e) {
          if (!this.contentVisible)
            return;
          const r = this.ctx;
          this.save();
          const p = this._getPattern(e);
          r.fillStyle = p.getPattern(r, this, (0, B.getCurrentTransformInverse)(r), _.SHADING);
          const o = (0, B.getCurrentTransformInverse)(r);
          if (o) {
            const {
              width: a,
              height: u
            } = r.canvas, [A, x, k, R] = w.Util.getAxialAlignedBoundingBox([0, 0, a, u], o);
            this.ctx.fillRect(A, x, k - A, R - x);
          } else
            this.ctx.fillRect(-1e10, -1e10, 2e10, 2e10);
          this.compose(this.current.getClippedPathBoundingBox()), this.restore();
        }
        beginInlineImage() {
          (0, w.unreachable)("Should not call beginInlineImage");
        }
        beginImageData() {
          (0, w.unreachable)("Should not call beginImageData");
        }
        paintFormXObjectBegin(e, r) {
          if (this.contentVisible && (this.save(), this.baseTransformStack.push(this.baseTransform), Array.isArray(e) && e.length === 6 && this.transform(...e), this.baseTransform = (0, B.getCurrentTransform)(this.ctx), r)) {
            const p = r[2] - r[0], o = r[3] - r[1];
            this.ctx.rect(r[0], r[1], p, o), this.current.updateRectMinMax((0, B.getCurrentTransform)(this.ctx), r), this.clip(), this.endPath();
          }
        }
        paintFormXObjectEnd() {
          this.contentVisible && (this.restore(), this.baseTransform = this.baseTransformStack.pop());
        }
        beginGroup(e) {
          if (!this.contentVisible)
            return;
          this.save(), this.inSMaskMode && (this.endSMaskMode(), this.current.activeSMask = null);
          const r = this.ctx;
          e.isolated || (0, w.info)("TODO: Support non-isolated groups."), e.knockout && (0, w.warn)("Knockout groups not supported.");
          const p = (0, B.getCurrentTransform)(r);
          if (e.matrix && r.transform(...e.matrix), !e.bbox)
            throw new Error("Bounding box is required.");
          let o = w.Util.getAxialAlignedBoundingBox(e.bbox, (0, B.getCurrentTransform)(r));
          const a = [0, 0, r.canvas.width, r.canvas.height];
          o = w.Util.intersect(o, a) || [0, 0, 0, 0];
          const u = Math.floor(o[0]), A = Math.floor(o[1]);
          let x = Math.max(Math.ceil(o[2]) - u, 1), k = Math.max(Math.ceil(o[3]) - A, 1), R = 1, D = 1;
          x > d && (R = x / d, x = d), k > d && (D = k / d, k = d), this.current.startNewPathAndClipBox([0, 0, x, k]);
          let I = "groupAt" + this.groupLevel;
          e.smask && (I += "_smask_" + this.smaskCounter++ % 2);
          const F = this.cachedCanvases.getCanvas(I, x, k), C = F.context;
          C.scale(1 / R, 1 / D), C.translate(-u, -A), C.transform(...p), e.smask ? this.smaskStack.push({
            canvas: F.canvas,
            context: C,
            offsetX: u,
            offsetY: A,
            scaleX: R,
            scaleY: D,
            subtype: e.smask.subtype,
            backdrop: e.smask.backdrop,
            transferMap: e.smask.transferMap || null,
            startTransformInverse: null
          }) : (r.setTransform(1, 0, 0, 1, 0, 0), r.translate(u, A), r.scale(R, D), r.save()), O(r, C), this.ctx = C, this.setGState([["BM", "source-over"], ["ca", 1], ["CA", 1]]), this.groupStack.push(r), this.groupLevel++;
        }
        endGroup(e) {
          if (!this.contentVisible)
            return;
          this.groupLevel--;
          const r = this.ctx, p = this.groupStack.pop();
          if (this.ctx = p, this.ctx.imageSmoothingEnabled = !1, e.smask)
            this.tempSMask = this.smaskStack.pop(), this.restore();
          else {
            this.ctx.restore();
            const o = (0, B.getCurrentTransform)(this.ctx);
            this.restore(), this.ctx.save(), this.ctx.setTransform(...o);
            const a = w.Util.getAxialAlignedBoundingBox([0, 0, r.canvas.width, r.canvas.height], o);
            this.ctx.drawImage(r.canvas, 0, 0), this.ctx.restore(), this.compose(a);
          }
        }
        beginAnnotation(e, r, p, o, a) {
          if (this.#t(), G(this.ctx), this.ctx.save(), this.save(), this.baseTransform && this.ctx.setTransform(...this.baseTransform), Array.isArray(r) && r.length === 4) {
            const u = r[2] - r[0], A = r[3] - r[1];
            if (a && this.annotationCanvasMap) {
              p = p.slice(), p[4] -= r[0], p[5] -= r[1], r = r.slice(), r[0] = r[1] = 0, r[2] = u, r[3] = A;
              const [x, k] = w.Util.singularValueDecompose2dScale((0, B.getCurrentTransform)(this.ctx)), {
                viewportScale: R
              } = this, D = Math.ceil(u * this.outputScaleX * R), I = Math.ceil(A * this.outputScaleY * R);
              this.annotationCanvas = this.canvasFactory.create(D, I);
              const {
                canvas: F,
                context: C
              } = this.annotationCanvas;
              this.annotationCanvasMap.set(e, F), this.annotationCanvas.savedCtx = this.ctx, this.ctx = C, this.ctx.save(), this.ctx.setTransform(x, 0, 0, -k, 0, A * k), G(this.ctx);
            } else
              G(this.ctx), this.ctx.rect(r[0], r[1], u, A), this.ctx.clip(), this.endPath();
          }
          this.current = new q(this.ctx.canvas.width, this.ctx.canvas.height), this.transform(...p), this.transform(...o);
        }
        endAnnotation() {
          this.annotationCanvas && (this.ctx.restore(), this.#e(), this.ctx = this.annotationCanvas.savedCtx, delete this.annotationCanvas.savedCtx, delete this.annotationCanvas);
        }
        paintImageMaskXObject(e) {
          if (!this.contentVisible)
            return;
          const r = e.count;
          e = this.getObject(e.data, e), e.count = r;
          const p = this.ctx, o = this.processingType3;
          if (o && (o.compiled === void 0 && (o.compiled = z(e)), o.compiled)) {
            o.compiled(p);
            return;
          }
          const a = this._createMaskCanvas(e), u = a.canvas;
          p.save(), p.setTransform(1, 0, 0, 1, 0, 0), p.drawImage(u, a.offsetX, a.offsetY), p.restore(), this.compose();
        }
        paintImageMaskXObjectRepeat(e, r, p = 0, o = 0, a, u) {
          if (!this.contentVisible)
            return;
          e = this.getObject(e.data, e);
          const A = this.ctx;
          A.save();
          const x = (0, B.getCurrentTransform)(A);
          A.transform(r, p, o, a, 0, 0);
          const k = this._createMaskCanvas(e);
          A.setTransform(1, 0, 0, 1, k.offsetX - x[4], k.offsetY - x[5]);
          for (let R = 0, D = u.length; R < D; R += 2) {
            const I = w.Util.transform(x, [r, p, o, a, u[R], u[R + 1]]), [F, C] = w.Util.applyTransform([0, 0], I);
            A.drawImage(k.canvas, F, C);
          }
          A.restore(), this.compose();
        }
        paintImageMaskXObjectGroup(e) {
          if (!this.contentVisible)
            return;
          const r = this.ctx, p = this.current.fillColor, o = this.current.patternFill;
          for (const a of e) {
            const {
              data: u,
              width: A,
              height: x,
              transform: k
            } = a, R = this.cachedCanvases.getCanvas("maskCanvas", A, x), D = R.context;
            D.save();
            const I = this.getObject(u, a);
            j(D, I), D.globalCompositeOperation = "source-in", D.fillStyle = o ? p.getPattern(D, this, (0, B.getCurrentTransformInverse)(r), _.FILL) : p, D.fillRect(0, 0, A, x), D.restore(), r.save(), r.transform(...k), r.scale(1, -1), H(r, R.canvas, 0, 0, A, x, 0, -1, 1, 1), r.restore();
          }
          this.compose();
        }
        paintImageXObject(e) {
          if (!this.contentVisible)
            return;
          const r = this.getObject(e);
          if (!r) {
            (0, w.warn)("Dependent image isn't ready yet");
            return;
          }
          this.paintInlineImageXObject(r);
        }
        paintImageXObjectRepeat(e, r, p, o) {
          if (!this.contentVisible)
            return;
          const a = this.getObject(e);
          if (!a) {
            (0, w.warn)("Dependent image isn't ready yet");
            return;
          }
          const u = a.width, A = a.height, x = [];
          for (let k = 0, R = o.length; k < R; k += 2)
            x.push({
              transform: [r, 0, 0, p, o[k], o[k + 1]],
              x: 0,
              y: 0,
              w: u,
              h: A
            });
          this.paintInlineImageXObjectGroup(a, x);
        }
        applyTransferMapsToCanvas(e) {
          return this.current.transferMaps !== "none" && (e.filter = this.current.transferMaps, e.drawImage(e.canvas, 0, 0), e.filter = "none"), e.canvas;
        }
        applyTransferMapsToBitmap(e) {
          if (this.current.transferMaps === "none")
            return e.bitmap;
          const {
            bitmap: r,
            width: p,
            height: o
          } = e, a = this.cachedCanvases.getCanvas("inlineImage", p, o), u = a.context;
          return u.filter = this.current.transferMaps, u.drawImage(r, 0, 0), u.filter = "none", a.canvas;
        }
        paintInlineImageXObject(e) {
          if (!this.contentVisible)
            return;
          const r = e.width, p = e.height, o = this.ctx;
          if (this.save(), !w.isNodeJS) {
            const {
              filter: A
            } = o;
            A !== "none" && A !== "" && (o.filter = "none");
          }
          o.scale(1 / r, -1 / p);
          let a;
          if (e.bitmap)
            a = this.applyTransferMapsToBitmap(e);
          else if (typeof HTMLElement == "function" && e instanceof HTMLElement || !e.data)
            a = e;
          else {
            const x = this.cachedCanvases.getCanvas("inlineImage", r, p).context;
            nt(x, e), a = this.applyTransferMapsToCanvas(x);
          }
          const u = this._scaleImage(a, (0, B.getCurrentTransformInverse)(o));
          o.imageSmoothingEnabled = pt((0, B.getCurrentTransform)(o), e.interpolate), H(o, u.img, 0, 0, u.paintWidth, u.paintHeight, 0, -p, r, p), this.compose(), this.restore();
        }
        paintInlineImageXObjectGroup(e, r) {
          if (!this.contentVisible)
            return;
          const p = this.ctx;
          let o;
          if (e.bitmap)
            o = e.bitmap;
          else {
            const a = e.width, u = e.height, x = this.cachedCanvases.getCanvas("inlineImage", a, u).context;
            nt(x, e), o = this.applyTransferMapsToCanvas(x);
          }
          for (const a of r)
            p.save(), p.transform(...a.transform), p.scale(1, -1), H(p, o, a.x, a.y, a.w, a.h, 0, -1, 1, 1), p.restore();
          this.compose();
        }
        paintSolidColorImageMask() {
          this.contentVisible && (this.ctx.fillRect(0, 0, 1, 1), this.compose());
        }
        markPoint(e) {
        }
        markPointProps(e, r) {
        }
        beginMarkedContent(e) {
          this.markedContentStack.push({
            visible: !0
          });
        }
        beginMarkedContentProps(e, r) {
          e === "OC" ? this.markedContentStack.push({
            visible: this.optionalContentConfig.isVisible(r)
          }) : this.markedContentStack.push({
            visible: !0
          }), this.contentVisible = this.isContentVisible();
        }
        endMarkedContent() {
          this.markedContentStack.pop(), this.contentVisible = this.isContentVisible();
        }
        beginCompat() {
        }
        endCompat() {
        }
        consumePath(e) {
          const r = this.current.isEmptyClip();
          this.pendingClip && this.current.updateClipFromPath(), this.pendingClip || this.compose(e);
          const p = this.ctx;
          this.pendingClip && (r || (this.pendingClip === et ? p.clip("evenodd") : p.clip()), this.pendingClip = null), this.current.startNewPathAndClipBox(this.current.clipBox), p.beginPath();
        }
        getSinglePixelWidth() {
          if (!this._cachedGetSinglePixelWidth) {
            const e = (0, B.getCurrentTransform)(this.ctx);
            if (e[1] === 0 && e[2] === 0)
              this._cachedGetSinglePixelWidth = 1 / Math.min(Math.abs(e[0]), Math.abs(e[3]));
            else {
              const r = Math.abs(e[0] * e[3] - e[2] * e[1]), p = Math.hypot(e[0], e[2]), o = Math.hypot(e[1], e[3]);
              this._cachedGetSinglePixelWidth = Math.max(p, o) / r;
            }
          }
          return this._cachedGetSinglePixelWidth;
        }
        getScaleForStroking() {
          if (this._cachedScaleForStroking[0] === -1) {
            const {
              lineWidth: e
            } = this.current, {
              a: r,
              b: p,
              c: o,
              d: a
            } = this.ctx.getTransform();
            let u, A;
            if (p === 0 && o === 0) {
              const x = Math.abs(r), k = Math.abs(a);
              if (x === k)
                if (e === 0)
                  u = A = 1 / x;
                else {
                  const R = x * e;
                  u = A = R < 1 ? 1 / R : 1;
                }
              else if (e === 0)
                u = 1 / x, A = 1 / k;
              else {
                const R = x * e, D = k * e;
                u = R < 1 ? 1 / R : 1, A = D < 1 ? 1 / D : 1;
              }
            } else {
              const x = Math.abs(r * a - p * o), k = Math.hypot(r, p), R = Math.hypot(o, a);
              if (e === 0)
                u = R / x, A = k / x;
              else {
                const D = e * x;
                u = R > D ? R / D : 1, A = k > D ? k / D : 1;
              }
            }
            this._cachedScaleForStroking[0] = u, this._cachedScaleForStroking[1] = A;
          }
          return this._cachedScaleForStroking;
        }
        rescaleAndStroke(e) {
          const {
            ctx: r
          } = this, {
            lineWidth: p
          } = this.current, [o, a] = this.getScaleForStroking();
          if (r.lineWidth = p || 1, o === 1 && a === 1) {
            r.stroke();
            return;
          }
          const u = r.getLineDash();
          if (e && r.save(), r.scale(o, a), u.length > 0) {
            const A = Math.max(o, a);
            r.setLineDash(u.map((x) => x / A)), r.lineDashOffset /= A;
          }
          r.stroke(), e && r.restore();
        }
        isContentVisible() {
          for (let e = this.markedContentStack.length - 1; e >= 0; e--)
            if (!this.markedContentStack[e].visible)
              return !1;
          return !0;
        }
      }
      for (const h in w.OPS)
        m.prototype[h] !== void 0 && (m.prototype[w.OPS[h]] = m.prototype[h]);
    })
  ),
  /***/
  419: (
    /***/
    ((ct, st, V) => {
      V.d(st, {
        /* harmony export */
        DOMCMapReaderFactory: () => (
          /* binding */
          v
        ),
        /* harmony export */
        DOMCanvasFactory: () => (
          /* binding */
          T
        ),
        /* harmony export */
        DOMFilterFactory: () => (
          /* binding */
          P
        ),
        /* harmony export */
        DOMSVGFactory: () => (
          /* binding */
          c
        ),
        /* harmony export */
        DOMStandardFontDataFactory: () => (
          /* binding */
          n
        ),
        /* harmony export */
        PDFDateString: () => (
          /* binding */
          L
        ),
        /* harmony export */
        PageViewport: () => (
          /* binding */
          l
        ),
        /* harmony export */
        PixelsPerInch: () => (
          /* binding */
          U
        ),
        /* harmony export */
        RenderingCancelledException: () => (
          /* binding */
          b
        ),
        /* harmony export */
        StatTimer: () => (
          /* binding */
          d
        ),
        /* harmony export */
        fetchData: () => (
          /* binding */
          E
        ),
        /* harmony export */
        getColorValues: () => (
          /* binding */
          H
        ),
        /* harmony export */
        getCurrentTransform: () => (
          /* binding */
          z
        ),
        /* harmony export */
        getCurrentTransformInverse: () => (
          /* binding */
          q
        ),
        /* harmony export */
        getFilenameFromUrl: () => (
          /* binding */
          t
        ),
        /* harmony export */
        getPdfFilenameFromUrl: () => (
          /* binding */
          i
        ),
        /* harmony export */
        getRGB: () => (
          /* binding */
          N
        ),
        /* harmony export */
        getXfaPageViewport: () => (
          /* binding */
          M
        ),
        /* harmony export */
        isDataScheme: () => (
          /* binding */
          s
        ),
        /* harmony export */
        isPdfFile: () => (
          /* binding */
          g
        ),
        /* harmony export */
        isValidFetchUrl: () => (
          /* binding */
          f
        ),
        /* harmony export */
        noContextMenu: () => (
          /* binding */
          y
        ),
        /* harmony export */
        setLayerDimensions: () => (
          /* binding */
          nt
        )
        /* harmony export */
      });
      var w = V(583), B = V(292);
      const _ = "http://www.w3.org/2000/svg";
      class U {
        static CSS = 96;
        static PDF = 72;
        static PDF_TO_CSS_UNITS = this.CSS / this.PDF;
      }
      class P extends w.BaseFilterFactory {
        #t;
        #e;
        #s;
        #n;
        #r;
        #i = 0;
        constructor({
          docId: O,
          ownerDocument: G = globalThis.document
        } = {}) {
          super(), this.#s = O, this.#n = G;
        }
        get #a() {
          return this.#t ||= /* @__PURE__ */ new Map();
        }
        get #l() {
          return this.#r ||= /* @__PURE__ */ new Map();
        }
        get #h() {
          if (!this.#e) {
            const O = this.#n.createElement("div"), {
              style: G
            } = O;
            G.visibility = "hidden", G.contain = "strict", G.width = G.height = 0, G.position = "absolute", G.top = G.left = 0, G.zIndex = -1;
            const Y = this.#n.createElementNS(_, "svg");
            Y.setAttribute("width", 0), Y.setAttribute("height", 0), this.#e = this.#n.createElementNS(_, "defs"), O.append(Y), Y.append(this.#e), this.#n.body.append(O);
          }
          return this.#e;
        }
        addFilter(O) {
          if (!O)
            return "none";
          let G = this.#a.get(O);
          if (G)
            return G;
          let Y, tt, Z, at;
          if (O.length === 1) {
            const ot = O[0], ut = new Array(256);
            for (let et = 0; et < 256; et++)
              ut[et] = ot[et] / 255;
            at = Y = tt = Z = ut.join(",");
          } else {
            const [ot, ut, et] = O, m = new Array(256), h = new Array(256), e = new Array(256);
            for (let r = 0; r < 256; r++)
              m[r] = ot[r] / 255, h[r] = ut[r] / 255, e[r] = et[r] / 255;
            Y = m.join(","), tt = h.join(","), Z = e.join(","), at = `${Y}${tt}${Z}`;
          }
          if (G = this.#a.get(at), G)
            return this.#a.set(O, G), G;
          const lt = `g_${this.#s}_transfer_map_${this.#i++}`, pt = `url(#${lt})`;
          this.#a.set(O, pt), this.#a.set(at, pt);
          const dt = this.#u(lt);
          return this.#o(Y, tt, Z, dt), pt;
        }
        addHCMFilter(O, G) {
          const Y = `${O}-${G}`, tt = "base";
          let Z = this.#l.get(tt);
          if (Z?.key === Y || (Z ? (Z.filter?.remove(), Z.key = Y, Z.url = "none", Z.filter = null) : (Z = {
            key: Y,
            url: "none",
            filter: null
          }, this.#l.set(tt, Z)), !O || !G))
            return Z.url;
          const at = this.#p(O);
          O = B.Util.makeHexColor(...at);
          const lt = this.#p(G);
          if (G = B.Util.makeHexColor(...lt), this.#h.style.color = "", O === "#000000" && G === "#ffffff" || O === G)
            return Z.url;
          const pt = new Array(256);
          for (let m = 0; m <= 255; m++) {
            const h = m / 255;
            pt[m] = h <= 0.03928 ? h / 12.92 : ((h + 0.055) / 1.055) ** 2.4;
          }
          const dt = pt.join(","), ot = `g_${this.#s}_hcm_filter`, ut = Z.filter = this.#u(ot);
          this.#o(dt, dt, dt, ut), this.#d(ut);
          const et = (m, h) => {
            const e = at[m] / 255, r = lt[m] / 255, p = new Array(h + 1);
            for (let o = 0; o <= h; o++)
              p[o] = e + o / h * (r - e);
            return p.join(",");
          };
          return this.#o(et(0, 5), et(1, 5), et(2, 5), ut), Z.url = `url(#${ot})`, Z.url;
        }
        addHighlightHCMFilter(O, G, Y, tt, Z) {
          const at = `${G}-${Y}-${tt}-${Z}`;
          let lt = this.#l.get(O);
          if (lt?.key === at || (lt ? (lt.filter?.remove(), lt.key = at, lt.url = "none", lt.filter = null) : (lt = {
            key: at,
            url: "none",
            filter: null
          }, this.#l.set(O, lt)), !G || !Y))
            return lt.url;
          const [pt, dt] = [G, Y].map(this.#p.bind(this));
          let ot = Math.round(0.2126 * pt[0] + 0.7152 * pt[1] + 0.0722 * pt[2]), ut = Math.round(0.2126 * dt[0] + 0.7152 * dt[1] + 0.0722 * dt[2]), [et, m] = [tt, Z].map(this.#p.bind(this));
          ut < ot && ([ot, ut, et, m] = [ut, ot, m, et]), this.#h.style.color = "";
          const h = (p, o, a) => {
            const u = new Array(256), A = (ut - ot) / a, x = p / 255, k = (o - p) / (255 * a);
            let R = 0;
            for (let D = 0; D <= a; D++) {
              const I = Math.round(ot + D * A), F = x + D * k;
              for (let C = R; C <= I; C++)
                u[C] = F;
              R = I + 1;
            }
            for (let D = R; D < 256; D++)
              u[D] = u[R - 1];
            return u.join(",");
          }, e = `g_${this.#s}_hcm_${O}_filter`, r = lt.filter = this.#u(e);
          return this.#d(r), this.#o(h(et[0], m[0], 5), h(et[1], m[1], 5), h(et[2], m[2], 5), r), lt.url = `url(#${e})`, lt.url;
        }
        destroy(O = !1) {
          O && this.#l.size !== 0 || (this.#e && (this.#e.parentNode.parentNode.remove(), this.#e = null), this.#t && (this.#t.clear(), this.#t = null), this.#i = 0);
        }
        #d(O) {
          const G = this.#n.createElementNS(_, "feColorMatrix");
          G.setAttribute("type", "matrix"), G.setAttribute("values", "0.2126 0.7152 0.0722 0 0 0.2126 0.7152 0.0722 0 0 0.2126 0.7152 0.0722 0 0 0 0 0 1 0"), O.append(G);
        }
        #u(O) {
          const G = this.#n.createElementNS(_, "filter");
          return G.setAttribute("color-interpolation-filters", "sRGB"), G.setAttribute("id", O), this.#h.append(G), G;
        }
        #c(O, G, Y) {
          const tt = this.#n.createElementNS(_, G);
          tt.setAttribute("type", "discrete"), tt.setAttribute("tableValues", Y), O.append(tt);
        }
        #o(O, G, Y, tt) {
          const Z = this.#n.createElementNS(_, "feComponentTransfer");
          tt.append(Z), this.#c(Z, "feFuncR", O), this.#c(Z, "feFuncG", G), this.#c(Z, "feFuncB", Y);
        }
        #p(O) {
          return this.#h.style.color = O, N(getComputedStyle(this.#h).getPropertyValue("color"));
        }
      }
      class T extends w.BaseCanvasFactory {
        constructor({
          ownerDocument: O = globalThis.document
        } = {}) {
          super(), this._document = O;
        }
        _createCanvas(O, G) {
          const Y = this._document.createElement("canvas");
          return Y.width = O, Y.height = G, Y;
        }
      }
      async function E(j, O = "text") {
        if (f(j, document.baseURI)) {
          const G = await fetch(j);
          if (!G.ok)
            throw new Error(G.statusText);
          switch (O) {
            case "arraybuffer":
              return G.arrayBuffer();
            case "blob":
              return G.blob();
            case "json":
              return G.json();
          }
          return G.text();
        }
        return new Promise((G, Y) => {
          const tt = new XMLHttpRequest();
          tt.open("GET", j, !0), tt.responseType = O, tt.onreadystatechange = () => {
            if (tt.readyState === XMLHttpRequest.DONE) {
              if (tt.status === 200 || tt.status === 0) {
                switch (O) {
                  case "arraybuffer":
                  case "blob":
                  case "json":
                    G(tt.response);
                    return;
                }
                G(tt.responseText);
                return;
              }
              Y(new Error(tt.statusText));
            }
          }, tt.send(null);
        });
      }
      class v extends w.BaseCMapReaderFactory {
        _fetchData(O, G) {
          return E(O, this.isCompressed ? "arraybuffer" : "text").then((Y) => ({
            cMapData: Y instanceof ArrayBuffer ? new Uint8Array(Y) : (0, B.stringToBytes)(Y),
            compressionType: G
          }));
        }
      }
      class n extends w.BaseStandardFontDataFactory {
        _fetchData(O) {
          return E(O, "arraybuffer").then((G) => new Uint8Array(G));
        }
      }
      class c extends w.BaseSVGFactory {
        _createSVG(O) {
          return document.createElementNS(_, O);
        }
      }
      class l {
        constructor({
          viewBox: O,
          scale: G,
          rotation: Y,
          offsetX: tt = 0,
          offsetY: Z = 0,
          dontFlip: at = !1
        }) {
          this.viewBox = O, this.scale = G, this.rotation = Y, this.offsetX = tt, this.offsetY = Z;
          const lt = (O[2] + O[0]) / 2, pt = (O[3] + O[1]) / 2;
          let dt, ot, ut, et;
          switch (Y %= 360, Y < 0 && (Y += 360), Y) {
            case 180:
              dt = -1, ot = 0, ut = 0, et = 1;
              break;
            case 90:
              dt = 0, ot = 1, ut = 1, et = 0;
              break;
            case 270:
              dt = 0, ot = -1, ut = -1, et = 0;
              break;
            case 0:
              dt = 1, ot = 0, ut = 0, et = -1;
              break;
            default:
              throw new Error("PageViewport: Invalid rotation, must be a multiple of 90 degrees.");
          }
          at && (ut = -ut, et = -et);
          let m, h, e, r;
          dt === 0 ? (m = Math.abs(pt - O[1]) * G + tt, h = Math.abs(lt - O[0]) * G + Z, e = (O[3] - O[1]) * G, r = (O[2] - O[0]) * G) : (m = Math.abs(lt - O[0]) * G + tt, h = Math.abs(pt - O[1]) * G + Z, e = (O[2] - O[0]) * G, r = (O[3] - O[1]) * G), this.transform = [dt * G, ot * G, ut * G, et * G, m - dt * G * lt - ut * G * pt, h - ot * G * lt - et * G * pt], this.width = e, this.height = r;
        }
        get rawDims() {
          const {
            viewBox: O
          } = this;
          return (0, B.shadow)(this, "rawDims", {
            pageWidth: O[2] - O[0],
            pageHeight: O[3] - O[1],
            pageX: O[0],
            pageY: O[1]
          });
        }
        clone({
          scale: O = this.scale,
          rotation: G = this.rotation,
          offsetX: Y = this.offsetX,
          offsetY: tt = this.offsetY,
          dontFlip: Z = !1
        } = {}) {
          return new l({
            viewBox: this.viewBox.slice(),
            scale: O,
            rotation: G,
            offsetX: Y,
            offsetY: tt,
            dontFlip: Z
          });
        }
        convertToViewportPoint(O, G) {
          return B.Util.applyTransform([O, G], this.transform);
        }
        convertToViewportRectangle(O) {
          const G = B.Util.applyTransform([O[0], O[1]], this.transform), Y = B.Util.applyTransform([O[2], O[3]], this.transform);
          return [G[0], G[1], Y[0], Y[1]];
        }
        convertToPdfPoint(O, G) {
          return B.Util.applyInverseTransform([O, G], this.transform);
        }
      }
      class b extends B.BaseException {
        constructor(O, G = 0) {
          super(O, "RenderingCancelledException"), this.extraDelay = G;
        }
      }
      function s(j) {
        const O = j.length;
        let G = 0;
        for (; G < O && j[G].trim() === ""; )
          G++;
        return j.substring(G, G + 5).toLowerCase() === "data:";
      }
      function g(j) {
        return typeof j == "string" && /\.pdf$/i.test(j);
      }
      function t(j, O = !1) {
        return O || ([j] = j.split(/[#?]/, 1)), j.substring(j.lastIndexOf("/") + 1);
      }
      function i(j, O = "document.pdf") {
        if (typeof j != "string")
          return O;
        if (s(j))
          return (0, B.warn)('getPdfFilenameFromUrl: ignore "data:"-URL for performance reasons.'), O;
        const G = /^(?:(?:[^:]+:)?\/\/[^/]+)?([^?#]*)(\?[^#]*)?(#.*)?$/, Y = /[^/?#=]+\.pdf\b(?!.*\.pdf\b)/i, tt = G.exec(j);
        let Z = Y.exec(tt[1]) || Y.exec(tt[2]) || Y.exec(tt[3]);
        if (Z && (Z = Z[0], Z.includes("%")))
          try {
            Z = Y.exec(decodeURIComponent(Z))[0];
          } catch {
          }
        return Z || O;
      }
      class d {
        started = /* @__PURE__ */ Object.create(null);
        times = [];
        time(O) {
          O in this.started && (0, B.warn)(`Timer is already running for ${O}`), this.started[O] = Date.now();
        }
        timeEnd(O) {
          O in this.started || (0, B.warn)(`Timer has not been started for ${O}`), this.times.push({
            name: O,
            start: this.started[O],
            end: Date.now()
          }), delete this.started[O];
        }
        toString() {
          const O = [];
          let G = 0;
          for (const {
            name: Y
          } of this.times)
            G = Math.max(Y.length, G);
          for (const {
            name: Y,
            start: tt,
            end: Z
          } of this.times)
            O.push(`${Y.padEnd(G)} ${Z - tt}ms
`);
          return O.join("");
        }
      }
      function f(j, O) {
        try {
          const {
            protocol: G
          } = O ? new URL(j, O) : new URL(j);
          return G === "http:" || G === "https:";
        } catch {
          return !1;
        }
      }
      function y(j) {
        j.preventDefault();
      }
      let S;
      class L {
        static toDateObject(O) {
          if (!O || typeof O != "string")
            return null;
          S ||= new RegExp("^D:(\\d{4})(\\d{2})?(\\d{2})?(\\d{2})?(\\d{2})?(\\d{2})?([Z|+|-])?(\\d{2})?'?(\\d{2})?'?");
          const G = S.exec(O);
          if (!G)
            return null;
          const Y = parseInt(G[1], 10);
          let tt = parseInt(G[2], 10);
          tt = tt >= 1 && tt <= 12 ? tt - 1 : 0;
          let Z = parseInt(G[3], 10);
          Z = Z >= 1 && Z <= 31 ? Z : 1;
          let at = parseInt(G[4], 10);
          at = at >= 0 && at <= 23 ? at : 0;
          let lt = parseInt(G[5], 10);
          lt = lt >= 0 && lt <= 59 ? lt : 0;
          let pt = parseInt(G[6], 10);
          pt = pt >= 0 && pt <= 59 ? pt : 0;
          const dt = G[7] || "Z";
          let ot = parseInt(G[8], 10);
          ot = ot >= 0 && ot <= 23 ? ot : 0;
          let ut = parseInt(G[9], 10) || 0;
          return ut = ut >= 0 && ut <= 59 ? ut : 0, dt === "-" ? (at += ot, lt += ut) : dt === "+" && (at -= ot, lt -= ut), new Date(Date.UTC(Y, tt, Z, at, lt, pt));
        }
      }
      function M(j, {
        scale: O = 1,
        rotation: G = 0
      }) {
        const {
          width: Y,
          height: tt
        } = j.attributes.style, Z = [0, 0, parseInt(Y), parseInt(tt)];
        return new l({
          viewBox: Z,
          scale: O,
          rotation: G
        });
      }
      function N(j) {
        if (j.startsWith("#")) {
          const O = parseInt(j.slice(1), 16);
          return [(O & 16711680) >> 16, (O & 65280) >> 8, O & 255];
        }
        return j.startsWith("rgb(") ? j.slice(4, -1).split(",").map((O) => parseInt(O)) : j.startsWith("rgba(") ? j.slice(5, -1).split(",").map((O) => parseInt(O)).slice(0, 3) : ((0, B.warn)(`Not a valid color format: "${j}"`), [0, 0, 0]);
      }
      function H(j) {
        const O = document.createElement("span");
        O.style.visibility = "hidden", document.body.append(O);
        for (const G of j.keys()) {
          O.style.color = G;
          const Y = window.getComputedStyle(O).color;
          j.set(G, N(Y));
        }
        O.remove();
      }
      function z(j) {
        const {
          a: O,
          b: G,
          c: Y,
          d: tt,
          e: Z,
          f: at
        } = j.getTransform();
        return [O, G, Y, tt, Z, at];
      }
      function q(j) {
        const {
          a: O,
          b: G,
          c: Y,
          d: tt,
          e: Z,
          f: at
        } = j.getTransform().invertSelf();
        return [O, G, Y, tt, Z, at];
      }
      function nt(j, O, G = !1, Y = !0) {
        if (O instanceof l) {
          const {
            pageWidth: tt,
            pageHeight: Z
          } = O.rawDims, {
            style: at
          } = j, lt = B.FeatureTest.isCSSRoundSupported, pt = `var(--scale-factor) * ${tt}px`, dt = `var(--scale-factor) * ${Z}px`, ot = lt ? `round(${pt}, 1px)` : `calc(${pt})`, ut = lt ? `round(${dt}, 1px)` : `calc(${dt})`;
          !G || O.rotation % 180 === 0 ? (at.width = ot, at.height = ut) : (at.width = ut, at.height = ot);
        }
        Y && j.setAttribute("data-main-rotation", O.rotation);
      }
    })
  ),
  /***/
  47: (
    /***/
    ((ct, st, V) => {
      V.d(st, {
        /* harmony export */
        DrawLayer: () => (
          /* binding */
          _
        )
        /* harmony export */
      });
      var w = V(419), B = V(292);
      class _ {
        #t = null;
        #e = 0;
        #s = /* @__PURE__ */ new Map();
        #n = /* @__PURE__ */ new Map();
        constructor({
          pageIndex: P
        }) {
          this.pageIndex = P;
        }
        setParent(P) {
          if (!this.#t) {
            this.#t = P;
            return;
          }
          if (this.#t !== P) {
            if (this.#s.size > 0)
              for (const T of this.#s.values())
                T.remove(), P.append(T);
            this.#t = P;
          }
        }
        static get _svgFactory() {
          return (0, B.shadow)(this, "_svgFactory", new w.DOMSVGFactory());
        }
        static #r(P, {
          x: T = 0,
          y: E = 0,
          width: v = 1,
          height: n = 1
        } = {}) {
          const {
            style: c
          } = P;
          c.top = `${100 * E}%`, c.left = `${100 * T}%`, c.width = `${100 * v}%`, c.height = `${100 * n}%`;
        }
        #i(P) {
          const T = _._svgFactory.create(1, 1, !0);
          return this.#t.append(T), T.setAttribute("aria-hidden", !0), _.#r(T, P), T;
        }
        #a(P, T) {
          const E = _._svgFactory.createElement("clipPath");
          P.append(E);
          const v = `clip_${T}`;
          E.setAttribute("id", v), E.setAttribute("clipPathUnits", "objectBoundingBox");
          const n = _._svgFactory.createElement("use");
          return E.append(n), n.setAttribute("href", `#${T}`), n.classList.add("clip"), v;
        }
        highlight(P, T, E, v = !1) {
          const n = this.#e++, c = this.#i(P.box);
          c.classList.add("highlight"), P.free && c.classList.add("free");
          const l = _._svgFactory.createElement("defs");
          c.append(l);
          const b = _._svgFactory.createElement("path");
          l.append(b);
          const s = `path_p${this.pageIndex}_${n}`;
          b.setAttribute("id", s), b.setAttribute("d", P.toSVGPath()), v && this.#n.set(n, b);
          const g = this.#a(l, s), t = _._svgFactory.createElement("use");
          return c.append(t), c.setAttribute("fill", T), c.setAttribute("fill-opacity", E), t.setAttribute("href", `#${s}`), this.#s.set(n, c), {
            id: n,
            clipPathId: `url(#${g})`
          };
        }
        highlightOutline(P) {
          const T = this.#e++, E = this.#i(P.box);
          E.classList.add("highlightOutline");
          const v = _._svgFactory.createElement("defs");
          E.append(v);
          const n = _._svgFactory.createElement("path");
          v.append(n);
          const c = `path_p${this.pageIndex}_${T}`;
          n.setAttribute("id", c), n.setAttribute("d", P.toSVGPath()), n.setAttribute("vector-effect", "non-scaling-stroke");
          let l;
          if (P.free) {
            E.classList.add("free");
            const g = _._svgFactory.createElement("mask");
            v.append(g), l = `mask_p${this.pageIndex}_${T}`, g.setAttribute("id", l), g.setAttribute("maskUnits", "objectBoundingBox");
            const t = _._svgFactory.createElement("rect");
            g.append(t), t.setAttribute("width", "1"), t.setAttribute("height", "1"), t.setAttribute("fill", "white");
            const i = _._svgFactory.createElement("use");
            g.append(i), i.setAttribute("href", `#${c}`), i.setAttribute("stroke", "none"), i.setAttribute("fill", "black"), i.setAttribute("fill-rule", "nonzero"), i.classList.add("mask");
          }
          const b = _._svgFactory.createElement("use");
          E.append(b), b.setAttribute("href", `#${c}`), l && b.setAttribute("mask", `url(#${l})`);
          const s = b.cloneNode();
          return E.append(s), b.classList.add("mainOutline"), s.classList.add("secondaryOutline"), this.#s.set(T, E), T;
        }
        finalizeLine(P, T) {
          const E = this.#n.get(P);
          this.#n.delete(P), this.updateBox(P, T.box), E.setAttribute("d", T.toSVGPath());
        }
        updateLine(P, T) {
          this.#s.get(P).firstChild.firstChild.setAttribute("d", T.toSVGPath());
        }
        removeFreeHighlight(P) {
          this.remove(P), this.#n.delete(P);
        }
        updatePath(P, T) {
          this.#n.get(P).setAttribute("d", T.toSVGPath());
        }
        updateBox(P, T) {
          _.#r(this.#s.get(P), T);
        }
        show(P, T) {
          this.#s.get(P).classList.toggle("hidden", !T);
        }
        rotate(P, T) {
          this.#s.get(P).setAttribute("data-main-rotation", T);
        }
        changeColor(P, T) {
          this.#s.get(P).setAttribute("fill", T);
        }
        changeOpacity(P, T) {
          this.#s.get(P).setAttribute("fill-opacity", T);
        }
        addClass(P, T) {
          this.#s.get(P).classList.add(T);
        }
        removeClass(P, T) {
          this.#s.get(P).classList.remove(T);
        }
        remove(P) {
          this.#t !== null && (this.#s.get(P).remove(), this.#s.delete(P));
        }
        destroy() {
          this.#t = null;
          for (const P of this.#s.values())
            P.remove();
          this.#s.clear();
        }
      }
    })
  ),
  /***/
  731: (
    /***/
    ((ct, st, V) => {
      V.d(st, {
        AnnotationEditorLayer: () => (
          /* binding */
          s
        )
      });
      var w = V(292), B = V(310), _ = V(830), U = V(976);
      const P = /\r\n?|\n/g;
      class T extends B.AnnotationEditor {
        #t = this.editorDivBlur.bind(this);
        #e = this.editorDivFocus.bind(this);
        #s = this.editorDivInput.bind(this);
        #n = this.editorDivKeydown.bind(this);
        #r = this.editorDivPaste.bind(this);
        #i;
        #a = "";
        #l = `${this.id}-editor`;
        #h;
        #d = null;
        static _freeTextDefaultContent = "";
        static _internalPadding = 0;
        static _defaultColor = null;
        static _defaultFontSize = 10;
        static get _keyboardManager() {
          const t = T.prototype, i = (y) => y.isEmpty(), d = _.AnnotationEditorUIManager.TRANSLATE_SMALL, f = _.AnnotationEditorUIManager.TRANSLATE_BIG;
          return (0, w.shadow)(this, "_keyboardManager", new _.KeyboardManager([[["ctrl+s", "mac+meta+s", "ctrl+p", "mac+meta+p"], t.commitOrRemove, {
            bubbles: !0
          }], [["ctrl+Enter", "mac+meta+Enter", "Escape", "mac+Escape"], t.commitOrRemove], [["ArrowLeft", "mac+ArrowLeft"], t._translateEmpty, {
            args: [-d, 0],
            checker: i
          }], [["ctrl+ArrowLeft", "mac+shift+ArrowLeft"], t._translateEmpty, {
            args: [-f, 0],
            checker: i
          }], [["ArrowRight", "mac+ArrowRight"], t._translateEmpty, {
            args: [d, 0],
            checker: i
          }], [["ctrl+ArrowRight", "mac+shift+ArrowRight"], t._translateEmpty, {
            args: [f, 0],
            checker: i
          }], [["ArrowUp", "mac+ArrowUp"], t._translateEmpty, {
            args: [0, -d],
            checker: i
          }], [["ctrl+ArrowUp", "mac+shift+ArrowUp"], t._translateEmpty, {
            args: [0, -f],
            checker: i
          }], [["ArrowDown", "mac+ArrowDown"], t._translateEmpty, {
            args: [0, d],
            checker: i
          }], [["ctrl+ArrowDown", "mac+shift+ArrowDown"], t._translateEmpty, {
            args: [0, f],
            checker: i
          }]]));
        }
        static _type = "freetext";
        static _editorType = w.AnnotationEditorType.FREETEXT;
        constructor(t) {
          super({
            ...t,
            name: "freeTextEditor"
          }), this.#i = t.color || T._defaultColor || B.AnnotationEditor._defaultLineColor, this.#h = t.fontSize || T._defaultFontSize;
        }
        static initialize(t, i) {
          B.AnnotationEditor.initialize(t, i, {
            strings: ["pdfjs-free-text-default-content"]
          });
          const d = getComputedStyle(document.documentElement);
          this._internalPadding = parseFloat(d.getPropertyValue("--freetext-padding"));
        }
        static updateDefaultParams(t, i) {
          switch (t) {
            case w.AnnotationEditorParamsType.FREETEXT_SIZE:
              T._defaultFontSize = i;
              break;
            case w.AnnotationEditorParamsType.FREETEXT_COLOR:
              T._defaultColor = i;
              break;
          }
        }
        updateParams(t, i) {
          switch (t) {
            case w.AnnotationEditorParamsType.FREETEXT_SIZE:
              this.#u(i);
              break;
            case w.AnnotationEditorParamsType.FREETEXT_COLOR:
              this.#c(i);
              break;
          }
        }
        static get defaultPropertiesToUpdate() {
          return [[w.AnnotationEditorParamsType.FREETEXT_SIZE, T._defaultFontSize], [w.AnnotationEditorParamsType.FREETEXT_COLOR, T._defaultColor || B.AnnotationEditor._defaultLineColor]];
        }
        get propertiesToUpdate() {
          return [[w.AnnotationEditorParamsType.FREETEXT_SIZE, this.#h], [w.AnnotationEditorParamsType.FREETEXT_COLOR, this.#i]];
        }
        #u(t) {
          const i = (f) => {
            this.editorDiv.style.fontSize = `calc(${f}px * var(--scale-factor))`, this.translate(0, -(f - this.#h) * this.parentScale), this.#h = f, this.#p();
          }, d = this.#h;
          this.addCommands({
            cmd: i.bind(this, t),
            undo: i.bind(this, d),
            post: this._uiManager.updateUI.bind(this._uiManager, this),
            mustExec: !0,
            type: w.AnnotationEditorParamsType.FREETEXT_SIZE,
            overwriteIfSameType: !0,
            keepUndo: !0
          });
        }
        #c(t) {
          const i = (f) => {
            this.#i = this.editorDiv.style.color = f;
          }, d = this.#i;
          this.addCommands({
            cmd: i.bind(this, t),
            undo: i.bind(this, d),
            post: this._uiManager.updateUI.bind(this._uiManager, this),
            mustExec: !0,
            type: w.AnnotationEditorParamsType.FREETEXT_COLOR,
            overwriteIfSameType: !0,
            keepUndo: !0
          });
        }
        _translateEmpty(t, i) {
          this._uiManager.translateSelectedEditors(t, i, !0);
        }
        getInitialTranslation() {
          const t = this.parentScale;
          return [-T._internalPadding * t, -(T._internalPadding + this.#h) * t];
        }
        rebuild() {
          this.parent && (super.rebuild(), this.div !== null && (this.isAttachedToDOM || this.parent.add(this)));
        }
        enableEditMode() {
          this.isInEditMode() || (this.parent.setEditingState(!1), this.parent.updateToolbar(w.AnnotationEditorType.FREETEXT), super.enableEditMode(), this.overlayDiv.classList.remove("enabled"), this.editorDiv.contentEditable = !0, this._isDraggable = !1, this.div.removeAttribute("aria-activedescendant"), this.editorDiv.addEventListener("keydown", this.#n), this.editorDiv.addEventListener("focus", this.#e), this.editorDiv.addEventListener("blur", this.#t), this.editorDiv.addEventListener("input", this.#s), this.editorDiv.addEventListener("paste", this.#r));
        }
        disableEditMode() {
          this.isInEditMode() && (this.parent.setEditingState(!0), super.disableEditMode(), this.overlayDiv.classList.add("enabled"), this.editorDiv.contentEditable = !1, this.div.setAttribute("aria-activedescendant", this.#l), this._isDraggable = !0, this.editorDiv.removeEventListener("keydown", this.#n), this.editorDiv.removeEventListener("focus", this.#e), this.editorDiv.removeEventListener("blur", this.#t), this.editorDiv.removeEventListener("input", this.#s), this.editorDiv.removeEventListener("paste", this.#r), this.div.focus({
            preventScroll: !0
          }), this.isEditing = !1, this.parent.div.classList.add("freetextEditing"));
        }
        focusin(t) {
          this._focusEventsAllowed && (super.focusin(t), t.target !== this.editorDiv && this.editorDiv.focus());
        }
        onceAdded() {
          this.width || (this.enableEditMode(), this.editorDiv.focus(), this._initialOptions?.isCentered && this.center(), this._initialOptions = null);
        }
        isEmpty() {
          return !this.editorDiv || this.editorDiv.innerText.trim() === "";
        }
        remove() {
          this.isEditing = !1, this.parent && (this.parent.setEditingState(!0), this.parent.div.classList.add("freetextEditing")), super.remove();
        }
        #o() {
          const t = [];
          this.editorDiv.normalize();
          for (const i of this.editorDiv.childNodes)
            t.push(T.#g(i));
          return t.join(`
`);
        }
        #p() {
          const [t, i] = this.parentDimensions;
          let d;
          if (this.isAttachedToDOM)
            d = this.div.getBoundingClientRect();
          else {
            const {
              currentLayer: f,
              div: y
            } = this, S = y.style.display, L = y.classList.contains("hidden");
            y.classList.remove("hidden"), y.style.display = "hidden", f.div.append(this.div), d = y.getBoundingClientRect(), y.remove(), y.style.display = S, y.classList.toggle("hidden", L);
          }
          this.rotation % 180 === this.parentRotation % 180 ? (this.width = d.width / t, this.height = d.height / i) : (this.width = d.height / t, this.height = d.width / i), this.fixAndSetPosition();
        }
        commit() {
          if (!this.isInEditMode())
            return;
          super.commit(), this.disableEditMode();
          const t = this.#a, i = this.#a = this.#o().trimEnd();
          if (t === i)
            return;
          const d = (f) => {
            if (this.#a = f, !f) {
              this.remove();
              return;
            }
            this.#f(), this._uiManager.rebuild(this), this.#p();
          };
          this.addCommands({
            cmd: () => {
              d(i);
            },
            undo: () => {
              d(t);
            },
            mustExec: !1
          }), this.#p();
        }
        shouldGetKeyboardEvents() {
          return this.isInEditMode();
        }
        enterInEditMode() {
          this.enableEditMode(), this.editorDiv.focus();
        }
        dblclick(t) {
          this.enterInEditMode();
        }
        keydown(t) {
          t.target === this.div && t.key === "Enter" && (this.enterInEditMode(), t.preventDefault());
        }
        editorDivKeydown(t) {
          T._keyboardManager.exec(this, t);
        }
        editorDivFocus(t) {
          this.isEditing = !0;
        }
        editorDivBlur(t) {
          this.isEditing = !1;
        }
        editorDivInput(t) {
          this.parent.div.classList.toggle("freetextEditing", this.isEmpty());
        }
        disableEditing() {
          this.editorDiv.setAttribute("role", "comment"), this.editorDiv.removeAttribute("aria-multiline");
        }
        enableEditing() {
          this.editorDiv.setAttribute("role", "textbox"), this.editorDiv.setAttribute("aria-multiline", !0);
        }
        render() {
          if (this.div)
            return this.div;
          let t, i;
          this.width && (t = this.x, i = this.y), super.render(), this.editorDiv = document.createElement("div"), this.editorDiv.className = "internal", this.editorDiv.setAttribute("id", this.#l), this.editorDiv.setAttribute("data-l10n-id", "pdfjs-free-text"), this.enableEditing(), B.AnnotationEditor._l10nPromise.get("pdfjs-free-text-default-content").then((f) => this.editorDiv?.setAttribute("default-content", f)), this.editorDiv.contentEditable = !0;
          const {
            style: d
          } = this.editorDiv;
          if (d.fontSize = `calc(${this.#h}px * var(--scale-factor))`, d.color = this.#i, this.div.append(this.editorDiv), this.overlayDiv = document.createElement("div"), this.overlayDiv.classList.add("overlay", "enabled"), this.div.append(this.overlayDiv), (0, _.bindEvents)(this, this.div, ["dblclick", "keydown"]), this.width) {
            const [f, y] = this.parentDimensions;
            if (this.annotationElementId) {
              const {
                position: S
              } = this.#d;
              let [L, M] = this.getInitialTranslation();
              [L, M] = this.pageTranslationToScreen(L, M);
              const [N, H] = this.pageDimensions, [z, q] = this.pageTranslation;
              let nt, j;
              switch (this.rotation) {
                case 0:
                  nt = t + (S[0] - z) / N, j = i + this.height - (S[1] - q) / H;
                  break;
                case 90:
                  nt = t + (S[0] - z) / N, j = i - (S[1] - q) / H, [L, M] = [M, -L];
                  break;
                case 180:
                  nt = t - this.width + (S[0] - z) / N, j = i - (S[1] - q) / H, [L, M] = [-L, -M];
                  break;
                case 270:
                  nt = t + (S[0] - z - this.height * H) / N, j = i + (S[1] - q - this.width * N) / H, [L, M] = [-M, L];
                  break;
              }
              this.setAt(nt * f, j * y, L, M);
            } else
              this.setAt(t * f, i * y, this.width * f, this.height * y);
            this.#f(), this._isDraggable = !0, this.editorDiv.contentEditable = !1;
          } else
            this._isDraggable = !1, this.editorDiv.contentEditable = !0;
          return this.div;
        }
        static #g(t) {
          return (t.nodeType === Node.TEXT_NODE ? t.nodeValue : t.innerText).replaceAll(P, "");
        }
        editorDivPaste(t) {
          const i = t.clipboardData || window.clipboardData, {
            types: d
          } = i;
          if (d.length === 1 && d[0] === "text/plain")
            return;
          t.preventDefault();
          const f = T.#m(i.getData("text") || "").replaceAll(P, `
`);
          if (!f)
            return;
          const y = window.getSelection();
          if (!y.rangeCount)
            return;
          this.editorDiv.normalize(), y.deleteFromDocument();
          const S = y.getRangeAt(0);
          if (!f.includes(`
`)) {
            S.insertNode(document.createTextNode(f)), this.editorDiv.normalize(), y.collapseToStart();
            return;
          }
          const {
            startContainer: L,
            startOffset: M
          } = S, N = [], H = [];
          if (L.nodeType === Node.TEXT_NODE) {
            const nt = L.parentElement;
            if (H.push(L.nodeValue.slice(M).replaceAll(P, "")), nt !== this.editorDiv) {
              let j = N;
              for (const O of this.editorDiv.childNodes) {
                if (O === nt) {
                  j = H;
                  continue;
                }
                j.push(T.#g(O));
              }
            }
            N.push(L.nodeValue.slice(0, M).replaceAll(P, ""));
          } else if (L === this.editorDiv) {
            let nt = N, j = 0;
            for (const O of this.editorDiv.childNodes)
              j++ === M && (nt = H), nt.push(T.#g(O));
          }
          this.#a = `${N.join(`
`)}${f}${H.join(`
`)}`, this.#f();
          const z = new Range();
          let q = N.reduce((nt, j) => nt + j.length, 0);
          for (const {
            firstChild: nt
          } of this.editorDiv.childNodes)
            if (nt.nodeType === Node.TEXT_NODE) {
              const j = nt.nodeValue.length;
              if (q <= j) {
                z.setStart(nt, q), z.setEnd(nt, q);
                break;
              }
              q -= j;
            }
          y.removeAllRanges(), y.addRange(z);
        }
        #f() {
          if (this.editorDiv.replaceChildren(), !!this.#a)
            for (const t of this.#a.split(`
`)) {
              const i = document.createElement("div");
              i.append(t ? document.createTextNode(t) : document.createElement("br")), this.editorDiv.append(i);
            }
        }
        #A() {
          return this.#a.replaceAll(" ", " ");
        }
        static #m(t) {
          return t.replaceAll(" ", " ");
        }
        get contentDiv() {
          return this.editorDiv;
        }
        static deserialize(t, i, d) {
          let f = null;
          if (t instanceof U.FreeTextAnnotationElement) {
            const {
              data: {
                defaultAppearanceData: {
                  fontSize: S,
                  fontColor: L
                },
                rect: M,
                rotation: N,
                id: H
              },
              textContent: z,
              textPosition: q,
              parent: {
                page: {
                  pageNumber: nt
                }
              }
            } = t;
            if (!z || z.length === 0)
              return null;
            f = t = {
              annotationType: w.AnnotationEditorType.FREETEXT,
              color: Array.from(L),
              fontSize: S,
              value: z.join(`
`),
              position: q,
              pageIndex: nt - 1,
              rect: M.slice(0),
              rotation: N,
              id: H,
              deleted: !1
            };
          }
          const y = super.deserialize(t, i, d);
          return y.#h = t.fontSize, y.#i = w.Util.makeHexColor(...t.color), y.#a = T.#m(t.value), y.annotationElementId = t.id || null, y.#d = f, y;
        }
        serialize(t = !1) {
          if (this.isEmpty())
            return null;
          if (this.deleted)
            return {
              pageIndex: this.pageIndex,
              id: this.annotationElementId,
              deleted: !0
            };
          const i = T._internalPadding * this.parentScale, d = this.getRect(i, i), f = B.AnnotationEditor._colorManager.convert(this.isAttachedToDOM ? getComputedStyle(this.editorDiv).color : this.#i), y = {
            annotationType: w.AnnotationEditorType.FREETEXT,
            color: f,
            fontSize: this.#h,
            value: this.#A(),
            pageIndex: this.pageIndex,
            rect: d,
            rotation: this.rotation,
            structTreeParentId: this._structTreeParentId
          };
          return t ? y : this.annotationElementId && !this.#v(y) ? null : (y.id = this.annotationElementId, y);
        }
        #v(t) {
          const {
            value: i,
            fontSize: d,
            color: f,
            pageIndex: y
          } = this.#d;
          return this._hasBeenMoved || t.value !== i || t.fontSize !== d || t.color.some((S, L) => S !== f[L]) || t.pageIndex !== y;
        }
        renderAnnotationElement(t) {
          const i = super.renderAnnotationElement(t);
          if (this.deleted)
            return i;
          const {
            style: d
          } = i;
          d.fontSize = `calc(${this.#h}px * var(--scale-factor))`, d.color = this.#i, i.replaceChildren();
          for (const y of this.#a.split(`
`)) {
            const S = document.createElement("div");
            S.append(y ? document.createTextNode(y) : document.createElement("br")), i.append(S);
          }
          const f = T._internalPadding * this.parentScale;
          return t.updateEdited({
            rect: this.getRect(f, f)
          }), i;
        }
        resetAnnotationElement(t) {
          super.resetAnnotationElement(t), t.resetEdited();
        }
      }
      var E = V(61), v = V(259), n = V(419);
      class c extends B.AnnotationEditor {
        #t = null;
        #e = 0;
        #s;
        #n = null;
        #r = null;
        #i = null;
        #a = null;
        #l = 0;
        #h = null;
        #d = null;
        #u = null;
        #c = !1;
        #o = this.#x.bind(this);
        #p = null;
        #g;
        #f = null;
        #A = "";
        #m;
        #v = "";
        static _defaultColor = null;
        static _defaultOpacity = 1;
        static _defaultThickness = 12;
        static _l10nPromise;
        static _type = "highlight";
        static _editorType = w.AnnotationEditorType.HIGHLIGHT;
        static _freeHighlightId = -1;
        static _freeHighlight = null;
        static _freeHighlightClipId = "";
        static get _keyboardManager() {
          const t = c.prototype;
          return (0, w.shadow)(this, "_keyboardManager", new _.KeyboardManager([[["ArrowLeft", "mac+ArrowLeft"], t._moveCaret, {
            args: [0]
          }], [["ArrowRight", "mac+ArrowRight"], t._moveCaret, {
            args: [1]
          }], [["ArrowUp", "mac+ArrowUp"], t._moveCaret, {
            args: [2]
          }], [["ArrowDown", "mac+ArrowDown"], t._moveCaret, {
            args: [3]
          }]]));
        }
        constructor(t) {
          super({
            ...t,
            name: "highlightEditor"
          }), this.color = t.color || c._defaultColor, this.#m = t.thickness || c._defaultThickness, this.#g = t.opacity || c._defaultOpacity, this.#s = t.boxes || null, this.#v = t.methodOfCreation || "", this.#A = t.text || "", this._isDraggable = !1, t.highlightId > -1 ? (this.#c = !0, this.#C(t), this.#b()) : (this.#t = t.anchorNode, this.#e = t.anchorOffset, this.#a = t.focusNode, this.#l = t.focusOffset, this.#w(), this.#b(), this.rotate(this.rotation));
        }
        get telemetryInitialData() {
          return {
            action: "added",
            type: this.#c ? "free_highlight" : "highlight",
            color: this._uiManager.highlightColorNames.get(this.color),
            thickness: this.#m,
            methodOfCreation: this.#v
          };
        }
        get telemetryFinalData() {
          return {
            type: "highlight",
            color: this._uiManager.highlightColorNames.get(this.color)
          };
        }
        static computeTelemetryFinalData(t) {
          return {
            numberOfColors: t.get("color").size
          };
        }
        #w() {
          const t = new E.Outliner(this.#s, 1e-3);
          this.#d = t.getOutlines(), {
            x: this.x,
            y: this.y,
            width: this.width,
            height: this.height
          } = this.#d.box;
          const i = new E.Outliner(this.#s, 25e-4, 1e-3, this._uiManager.direction === "ltr");
          this.#i = i.getOutlines();
          const {
            lastPoint: d
          } = this.#i.box;
          this.#p = [(d[0] - this.x) / this.width, (d[1] - this.y) / this.height];
        }
        #C({
          highlightOutlines: t,
          highlightId: i,
          clipPathId: d
        }) {
          this.#d = t;
          const f = 1.5;
          if (this.#i = t.getNewOutline(this.#m / 2 + f, 25e-4), i >= 0)
            this.#u = i, this.#n = d, this.parent.drawLayer.finalizeLine(i, t), this.#f = this.parent.drawLayer.highlightOutline(this.#i);
          else if (this.parent) {
            const H = this.parent.viewport.rotation;
            this.parent.drawLayer.updateLine(this.#u, t), this.parent.drawLayer.updateBox(this.#u, c.#S(this.#d.box, (H - this.rotation + 360) % 360)), this.parent.drawLayer.updateLine(this.#f, this.#i), this.parent.drawLayer.updateBox(this.#f, c.#S(this.#i.box, H));
          }
          const {
            x: y,
            y: S,
            width: L,
            height: M
          } = t.box;
          switch (this.rotation) {
            case 0:
              this.x = y, this.y = S, this.width = L, this.height = M;
              break;
            case 90: {
              const [H, z] = this.parentDimensions;
              this.x = S, this.y = 1 - y, this.width = L * z / H, this.height = M * H / z;
              break;
            }
            case 180:
              this.x = 1 - y, this.y = 1 - S, this.width = L, this.height = M;
              break;
            case 270: {
              const [H, z] = this.parentDimensions;
              this.x = 1 - S, this.y = y, this.width = L * z / H, this.height = M * H / z;
              break;
            }
          }
          const {
            lastPoint: N
          } = this.#i.box;
          this.#p = [(N[0] - y) / L, (N[1] - S) / M];
        }
        static initialize(t, i) {
          B.AnnotationEditor.initialize(t, i), c._defaultColor ||= i.highlightColors?.values().next().value || "#fff066";
        }
        static updateDefaultParams(t, i) {
          switch (t) {
            case w.AnnotationEditorParamsType.HIGHLIGHT_DEFAULT_COLOR:
              c._defaultColor = i;
              break;
            case w.AnnotationEditorParamsType.HIGHLIGHT_THICKNESS:
              c._defaultThickness = i;
              break;
          }
        }
        translateInPage(t, i) {
        }
        get toolbarPosition() {
          return this.#p;
        }
        updateParams(t, i) {
          switch (t) {
            case w.AnnotationEditorParamsType.HIGHLIGHT_COLOR:
              this.#k(i);
              break;
            case w.AnnotationEditorParamsType.HIGHLIGHT_THICKNESS:
              this.#I(i);
              break;
          }
        }
        static get defaultPropertiesToUpdate() {
          return [[w.AnnotationEditorParamsType.HIGHLIGHT_DEFAULT_COLOR, c._defaultColor], [w.AnnotationEditorParamsType.HIGHLIGHT_THICKNESS, c._defaultThickness]];
        }
        get propertiesToUpdate() {
          return [[w.AnnotationEditorParamsType.HIGHLIGHT_COLOR, this.color || c._defaultColor], [w.AnnotationEditorParamsType.HIGHLIGHT_THICKNESS, this.#m || c._defaultThickness], [w.AnnotationEditorParamsType.HIGHLIGHT_FREE, this.#c]];
        }
        #k(t) {
          const i = (f) => {
            this.color = f, this.parent?.drawLayer.changeColor(this.#u, f), this.#r?.updateColor(f);
          }, d = this.color;
          this.addCommands({
            cmd: i.bind(this, t),
            undo: i.bind(this, d),
            post: this._uiManager.updateUI.bind(this._uiManager, this),
            mustExec: !0,
            type: w.AnnotationEditorParamsType.HIGHLIGHT_COLOR,
            overwriteIfSameType: !0,
            keepUndo: !0
          }), this._reportTelemetry({
            action: "color_changed",
            color: this._uiManager.highlightColorNames.get(t)
          }, !0);
        }
        #I(t) {
          const i = this.#m, d = (f) => {
            this.#m = f, this.#L(f);
          };
          this.addCommands({
            cmd: d.bind(this, t),
            undo: d.bind(this, i),
            post: this._uiManager.updateUI.bind(this._uiManager, this),
            mustExec: !0,
            type: w.AnnotationEditorParamsType.INK_THICKNESS,
            overwriteIfSameType: !0,
            keepUndo: !0
          }), this._reportTelemetry({
            action: "thickness_changed",
            thickness: t
          }, !0);
        }
        async addEditToolbar() {
          const t = await super.addEditToolbar();
          return t ? (this._uiManager.highlightColors && (this.#r = new v.ColorPicker({
            editor: this
          }), t.addColorPicker(this.#r)), t) : null;
        }
        disableEditing() {
          super.disableEditing(), this.div.classList.toggle("disabled", !0);
        }
        enableEditing() {
          super.enableEditing(), this.div.classList.toggle("disabled", !1);
        }
        fixAndSetPosition() {
          return super.fixAndSetPosition(this.#T());
        }
        getBaseTranslation() {
          return [0, 0];
        }
        getRect(t, i) {
          return super.getRect(t, i, this.#T());
        }
        onceAdded() {
          this.parent.addUndoableEditor(this), this.div.focus();
        }
        remove() {
          this.#y(), this._reportTelemetry({
            action: "deleted"
          }), super.remove();
        }
        rebuild() {
          this.parent && (super.rebuild(), this.div !== null && (this.#b(), this.isAttachedToDOM || this.parent.add(this)));
        }
        setParent(t) {
          let i = !1;
          this.parent && !t ? this.#y() : t && (this.#b(t), i = !this.parent && this.div?.classList.contains("selectedEditor")), super.setParent(t), this.show(this._isVisible), i && this.select();
        }
        #L(t) {
          if (!this.#c)
            return;
          this.#C({
            highlightOutlines: this.#d.getNewOutline(t / 2)
          }), this.fixAndSetPosition();
          const [i, d] = this.parentDimensions;
          this.setDims(this.width * i, this.height * d);
        }
        #y() {
          this.#u === null || !this.parent || (this.parent.drawLayer.remove(this.#u), this.#u = null, this.parent.drawLayer.remove(this.#f), this.#f = null);
        }
        #b(t = this.parent) {
          this.#u === null && ({
            id: this.#u,
            clipPathId: this.#n
          } = t.drawLayer.highlight(this.#d, this.color, this.#g), this.#f = t.drawLayer.highlightOutline(this.#i), this.#h && (this.#h.style.clipPath = this.#n));
        }
        static #S({
          x: t,
          y: i,
          width: d,
          height: f
        }, y) {
          switch (y) {
            case 90:
              return {
                x: 1 - i - f,
                y: t,
                width: f,
                height: d
              };
            case 180:
              return {
                x: 1 - t - d,
                y: 1 - i - f,
                width: d,
                height: f
              };
            case 270:
              return {
                x: i,
                y: 1 - t - d,
                width: f,
                height: d
              };
          }
          return {
            x: t,
            y: i,
            width: d,
            height: f
          };
        }
        rotate(t) {
          const {
            drawLayer: i
          } = this.parent;
          let d;
          this.#c ? (t = (t - this.rotation + 360) % 360, d = c.#S(this.#d.box, t)) : d = c.#S(this, t), i.rotate(this.#u, t), i.rotate(this.#f, t), i.updateBox(this.#u, d), i.updateBox(this.#f, c.#S(this.#i.box, t));
        }
        render() {
          if (this.div)
            return this.div;
          const t = super.render();
          this.#A && (t.setAttribute("aria-label", this.#A), t.setAttribute("role", "mark")), this.#c ? t.classList.add("free") : this.div.addEventListener("keydown", this.#o);
          const i = this.#h = document.createElement("div");
          t.append(i), i.setAttribute("aria-hidden", "true"), i.className = "internal", i.style.clipPath = this.#n;
          const [d, f] = this.parentDimensions;
          return this.setDims(this.width * d, this.height * f), (0, _.bindEvents)(this, this.#h, ["pointerover", "pointerleave"]), this.enableEditing(), t;
        }
        pointerover() {
          this.parent.drawLayer.addClass(this.#f, "hovered");
        }
        pointerleave() {
          this.parent.drawLayer.removeClass(this.#f, "hovered");
        }
        #x(t) {
          c._keyboardManager.exec(this, t);
        }
        _moveCaret(t) {
          switch (this.parent.unselect(this), t) {
            case 0:
            case 2:
              this.#R(!0);
              break;
            case 1:
            case 3:
              this.#R(!1);
              break;
          }
        }
        #R(t) {
          if (!this.#t)
            return;
          const i = window.getSelection();
          t ? i.setPosition(this.#t, this.#e) : i.setPosition(this.#a, this.#l);
        }
        select() {
          super.select(), this.#f && (this.parent?.drawLayer.removeClass(this.#f, "hovered"), this.parent?.drawLayer.addClass(this.#f, "selected"));
        }
        unselect() {
          super.unselect(), this.#f && (this.parent?.drawLayer.removeClass(this.#f, "selected"), this.#c || this.#R(!1));
        }
        get _mustFixPosition() {
          return !this.#c;
        }
        show(t = this._isVisible) {
          super.show(t), this.parent && (this.parent.drawLayer.show(this.#u, t), this.parent.drawLayer.show(this.#f, t));
        }
        #T() {
          return this.#c ? this.rotation : 0;
        }
        #M() {
          if (this.#c)
            return null;
          const [t, i] = this.pageDimensions, d = this.#s, f = new Array(d.length * 8);
          let y = 0;
          for (const {
            x: S,
            y: L,
            width: M,
            height: N
          } of d) {
            const H = S * t, z = (1 - L - N) * i;
            f[y] = f[y + 4] = H, f[y + 1] = f[y + 3] = z, f[y + 2] = f[y + 6] = H + M * t, f[y + 5] = f[y + 7] = z + N * i, y += 8;
          }
          return f;
        }
        #F(t) {
          return this.#d.serialize(t, this.#T());
        }
        static startHighlighting(t, i, {
          target: d,
          x: f,
          y
        }) {
          const {
            x: S,
            y: L,
            width: M,
            height: N
          } = d.getBoundingClientRect(), H = (j) => {
            this.#_(t, j);
          }, z = {
            capture: !0,
            passive: !1
          }, q = (j) => {
            j.preventDefault(), j.stopPropagation();
          }, nt = (j) => {
            d.removeEventListener("pointermove", H), window.removeEventListener("blur", nt), window.removeEventListener("pointerup", nt), window.removeEventListener("pointerdown", q, z), window.removeEventListener("contextmenu", n.noContextMenu), this.#P(t, j);
          };
          window.addEventListener("blur", nt), window.addEventListener("pointerup", nt), window.addEventListener("pointerdown", q, z), window.addEventListener("contextmenu", n.noContextMenu), d.addEventListener("pointermove", H), this._freeHighlight = new E.FreeOutliner({
            x: f,
            y
          }, [S, L, M, N], t.scale, this._defaultThickness / 2, i, 1e-3), {
            id: this._freeHighlightId,
            clipPathId: this._freeHighlightClipId
          } = t.drawLayer.highlight(this._freeHighlight, this._defaultColor, this._defaultOpacity, !0);
        }
        static #_(t, i) {
          this._freeHighlight.add(i) && t.drawLayer.updatePath(this._freeHighlightId, this._freeHighlight);
        }
        static #P(t, i) {
          this._freeHighlight.isEmpty() ? t.drawLayer.removeFreeHighlight(this._freeHighlightId) : t.createAndAddNewEditor(i, !1, {
            highlightId: this._freeHighlightId,
            highlightOutlines: this._freeHighlight.getOutlines(),
            clipPathId: this._freeHighlightClipId,
            methodOfCreation: "main_toolbar"
          }), this._freeHighlightId = -1, this._freeHighlight = null, this._freeHighlightClipId = "";
        }
        static deserialize(t, i, d) {
          const f = super.deserialize(t, i, d), {
            rect: [y, S, L, M],
            color: N,
            quadPoints: H
          } = t;
          f.color = w.Util.makeHexColor(...N), f.#g = t.opacity;
          const [z, q] = f.pageDimensions;
          f.width = (L - y) / z, f.height = (M - S) / q;
          const nt = f.#s = [];
          for (let j = 0; j < H.length; j += 8)
            nt.push({
              x: (H[4] - L) / z,
              y: (M - (1 - H[j + 5])) / q,
              width: (H[j + 2] - H[j]) / z,
              height: (H[j + 5] - H[j + 1]) / q
            });
          return f.#w(), f;
        }
        serialize(t = !1) {
          if (this.isEmpty() || t)
            return null;
          const i = this.getRect(0, 0), d = B.AnnotationEditor._colorManager.convert(this.color);
          return {
            annotationType: w.AnnotationEditorType.HIGHLIGHT,
            color: d,
            opacity: this.#g,
            thickness: this.#m,
            quadPoints: this.#M(),
            outlines: this.#F(i),
            pageIndex: this.pageIndex,
            rect: i,
            rotation: this.#T(),
            structTreeParentId: this._structTreeParentId
          };
        }
        static canCreateNewEmptyEditor() {
          return !1;
        }
      }
      class l extends B.AnnotationEditor {
        #t = 0;
        #e = 0;
        #s = this.canvasPointermove.bind(this);
        #n = this.canvasPointerleave.bind(this);
        #r = this.canvasPointerup.bind(this);
        #i = this.canvasPointerdown.bind(this);
        #a = null;
        #l = new Path2D();
        #h = !1;
        #d = !1;
        #u = !1;
        #c = null;
        #o = 0;
        #p = 0;
        #g = null;
        static _defaultColor = null;
        static _defaultOpacity = 1;
        static _defaultThickness = 1;
        static _type = "ink";
        static _editorType = w.AnnotationEditorType.INK;
        constructor(t) {
          super({
            ...t,
            name: "inkEditor"
          }), this.color = t.color || null, this.thickness = t.thickness || null, this.opacity = t.opacity || null, this.paths = [], this.bezierPath2D = [], this.allRawPaths = [], this.currentPath = [], this.scaleFactor = 1, this.translationX = this.translationY = 0, this.x = 0, this.y = 0, this._willKeepAspectRatio = !0;
        }
        static initialize(t, i) {
          B.AnnotationEditor.initialize(t, i);
        }
        static updateDefaultParams(t, i) {
          switch (t) {
            case w.AnnotationEditorParamsType.INK_THICKNESS:
              l._defaultThickness = i;
              break;
            case w.AnnotationEditorParamsType.INK_COLOR:
              l._defaultColor = i;
              break;
            case w.AnnotationEditorParamsType.INK_OPACITY:
              l._defaultOpacity = i / 100;
              break;
          }
        }
        updateParams(t, i) {
          switch (t) {
            case w.AnnotationEditorParamsType.INK_THICKNESS:
              this.#f(i);
              break;
            case w.AnnotationEditorParamsType.INK_COLOR:
              this.#A(i);
              break;
            case w.AnnotationEditorParamsType.INK_OPACITY:
              this.#m(i);
              break;
          }
        }
        static get defaultPropertiesToUpdate() {
          return [[w.AnnotationEditorParamsType.INK_THICKNESS, l._defaultThickness], [w.AnnotationEditorParamsType.INK_COLOR, l._defaultColor || B.AnnotationEditor._defaultLineColor], [w.AnnotationEditorParamsType.INK_OPACITY, Math.round(l._defaultOpacity * 100)]];
        }
        get propertiesToUpdate() {
          return [[w.AnnotationEditorParamsType.INK_THICKNESS, this.thickness || l._defaultThickness], [w.AnnotationEditorParamsType.INK_COLOR, this.color || l._defaultColor || B.AnnotationEditor._defaultLineColor], [w.AnnotationEditorParamsType.INK_OPACITY, Math.round(100 * (this.opacity ?? l._defaultOpacity))]];
        }
        #f(t) {
          const i = (f) => {
            this.thickness = f, this.#N();
          }, d = this.thickness;
          this.addCommands({
            cmd: i.bind(this, t),
            undo: i.bind(this, d),
            post: this._uiManager.updateUI.bind(this._uiManager, this),
            mustExec: !0,
            type: w.AnnotationEditorParamsType.INK_THICKNESS,
            overwriteIfSameType: !0,
            keepUndo: !0
          });
        }
        #A(t) {
          const i = (f) => {
            this.color = f, this.#x();
          }, d = this.color;
          this.addCommands({
            cmd: i.bind(this, t),
            undo: i.bind(this, d),
            post: this._uiManager.updateUI.bind(this._uiManager, this),
            mustExec: !0,
            type: w.AnnotationEditorParamsType.INK_COLOR,
            overwriteIfSameType: !0,
            keepUndo: !0
          });
        }
        #m(t) {
          const i = (f) => {
            this.opacity = f, this.#x();
          };
          t /= 100;
          const d = this.opacity;
          this.addCommands({
            cmd: i.bind(this, t),
            undo: i.bind(this, d),
            post: this._uiManager.updateUI.bind(this._uiManager, this),
            mustExec: !0,
            type: w.AnnotationEditorParamsType.INK_OPACITY,
            overwriteIfSameType: !0,
            keepUndo: !0
          });
        }
        rebuild() {
          this.parent && (super.rebuild(), this.div !== null && (this.canvas || (this.#T(), this.#M()), this.isAttachedToDOM || (this.parent.add(this), this.#F()), this.#N()));
        }
        remove() {
          this.canvas !== null && (this.isEmpty() || this.commit(), this.canvas.width = this.canvas.height = 0, this.canvas.remove(), this.canvas = null, this.#a && (clearTimeout(this.#a), this.#a = null), this.#c.disconnect(), this.#c = null, super.remove());
        }
        setParent(t) {
          !this.parent && t ? this._uiManager.removeShouldRescale(this) : this.parent && t === null && this._uiManager.addShouldRescale(this), super.setParent(t);
        }
        onScaleChanging() {
          const [t, i] = this.parentDimensions, d = this.width * t, f = this.height * i;
          this.setDimensions(d, f);
        }
        enableEditMode() {
          this.#h || this.canvas === null || (super.enableEditMode(), this._isDraggable = !1, this.canvas.addEventListener("pointerdown", this.#i));
        }
        disableEditMode() {
          !this.isInEditMode() || this.canvas === null || (super.disableEditMode(), this._isDraggable = !this.isEmpty(), this.div.classList.remove("editing"), this.canvas.removeEventListener("pointerdown", this.#i));
        }
        onceAdded() {
          this._isDraggable = !this.isEmpty();
        }
        isEmpty() {
          return this.paths.length === 0 || this.paths.length === 1 && this.paths[0].length === 0;
        }
        #v() {
          const {
            parentRotation: t,
            parentDimensions: [i, d]
          } = this;
          switch (t) {
            case 90:
              return [0, d, d, i];
            case 180:
              return [i, d, i, d];
            case 270:
              return [i, 0, d, i];
            default:
              return [0, 0, i, d];
          }
        }
        #w() {
          const {
            ctx: t,
            color: i,
            opacity: d,
            thickness: f,
            parentScale: y,
            scaleFactor: S
          } = this;
          t.lineWidth = f * y / S, t.lineCap = "round", t.lineJoin = "round", t.miterLimit = 10, t.strokeStyle = `${i}${(0, _.opacityToHex)(d)}`;
        }
        #C(t, i) {
          this.canvas.addEventListener("contextmenu", n.noContextMenu), this.canvas.addEventListener("pointerleave", this.#n), this.canvas.addEventListener("pointermove", this.#s), this.canvas.addEventListener("pointerup", this.#r), this.canvas.removeEventListener("pointerdown", this.#i), this.isEditing = !0, this.#u || (this.#u = !0, this.#F(), this.thickness ||= l._defaultThickness, this.color ||= l._defaultColor || B.AnnotationEditor._defaultLineColor, this.opacity ??= l._defaultOpacity), this.currentPath.push([t, i]), this.#d = !1, this.#w(), this.#g = () => {
            this.#y(), this.#g && window.requestAnimationFrame(this.#g);
          }, window.requestAnimationFrame(this.#g);
        }
        #k(t, i) {
          const [d, f] = this.currentPath.at(-1);
          if (this.currentPath.length > 1 && t === d && i === f)
            return;
          const y = this.currentPath;
          let S = this.#l;
          if (y.push([t, i]), this.#d = !0, y.length <= 2) {
            S.moveTo(...y[0]), S.lineTo(t, i);
            return;
          }
          y.length === 3 && (this.#l = S = new Path2D(), S.moveTo(...y[0])), this.#b(S, ...y.at(-3), ...y.at(-2), t, i);
        }
        #I() {
          if (this.currentPath.length === 0)
            return;
          const t = this.currentPath.at(-1);
          this.#l.lineTo(...t);
        }
        #L(t, i) {
          this.#g = null, t = Math.min(Math.max(t, 0), this.canvas.width), i = Math.min(Math.max(i, 0), this.canvas.height), this.#k(t, i), this.#I();
          let d;
          if (this.currentPath.length !== 1)
            d = this.#S();
          else {
            const M = [t, i];
            d = [[M, M.slice(), M.slice(), M]];
          }
          const f = this.#l, y = this.currentPath;
          this.currentPath = [], this.#l = new Path2D();
          const S = () => {
            this.allRawPaths.push(y), this.paths.push(d), this.bezierPath2D.push(f), this._uiManager.rebuild(this);
          }, L = () => {
            this.allRawPaths.pop(), this.paths.pop(), this.bezierPath2D.pop(), this.paths.length === 0 ? this.remove() : (this.canvas || (this.#T(), this.#M()), this.#N());
          };
          this.addCommands({
            cmd: S,
            undo: L,
            mustExec: !0
          });
        }
        #y() {
          if (!this.#d)
            return;
          this.#d = !1;
          const t = Math.ceil(this.thickness * this.parentScale), i = this.currentPath.slice(-3), d = i.map((S) => S[0]), f = i.map((S) => S[1]);
          Math.min(...d) - t, Math.max(...d) + t, Math.min(...f) - t, Math.max(...f) + t;
          const {
            ctx: y
          } = this;
          y.save(), y.clearRect(0, 0, this.canvas.width, this.canvas.height);
          for (const S of this.bezierPath2D)
            y.stroke(S);
          y.stroke(this.#l), y.restore();
        }
        #b(t, i, d, f, y, S, L) {
          const M = (i + f) / 2, N = (d + y) / 2, H = (f + S) / 2, z = (y + L) / 2;
          t.bezierCurveTo(M + 2 * (f - M) / 3, N + 2 * (y - N) / 3, H + 2 * (f - H) / 3, z + 2 * (y - z) / 3, H, z);
        }
        #S() {
          const t = this.currentPath;
          if (t.length <= 2)
            return [[t[0], t[0], t.at(-1), t.at(-1)]];
          const i = [];
          let d, [f, y] = t[0];
          for (d = 1; d < t.length - 2; d++) {
            const [q, nt] = t[d], [j, O] = t[d + 1], G = (q + j) / 2, Y = (nt + O) / 2, tt = [f + 2 * (q - f) / 3, y + 2 * (nt - y) / 3], Z = [G + 2 * (q - G) / 3, Y + 2 * (nt - Y) / 3];
            i.push([[f, y], tt, Z, [G, Y]]), [f, y] = [G, Y];
          }
          const [S, L] = t[d], [M, N] = t[d + 1], H = [f + 2 * (S - f) / 3, y + 2 * (L - y) / 3], z = [M + 2 * (S - M) / 3, N + 2 * (L - N) / 3];
          return i.push([[f, y], H, z, [M, N]]), i;
        }
        #x() {
          if (this.isEmpty()) {
            this.#P();
            return;
          }
          this.#w();
          const {
            canvas: t,
            ctx: i
          } = this;
          i.setTransform(1, 0, 0, 1, 0, 0), i.clearRect(0, 0, t.width, t.height), this.#P();
          for (const d of this.bezierPath2D)
            i.stroke(d);
        }
        commit() {
          this.#h || (super.commit(), this.isEditing = !1, this.disableEditMode(), this.setInForeground(), this.#h = !0, this.div.classList.add("disabled"), this.#N(!0), this.select(), this.parent.addInkEditorIfNeeded(!0), this.moveInDOM(), this.div.focus({
            preventScroll: !0
          }));
        }
        focusin(t) {
          this._focusEventsAllowed && (super.focusin(t), this.enableEditMode());
        }
        canvasPointerdown(t) {
          t.button !== 0 || !this.isInEditMode() || this.#h || (this.setInForeground(), t.preventDefault(), this.div.contains(document.activeElement) || this.div.focus({
            preventScroll: !0
          }), this.#C(t.offsetX, t.offsetY));
        }
        canvasPointermove(t) {
          t.preventDefault(), this.#k(t.offsetX, t.offsetY);
        }
        canvasPointerup(t) {
          t.preventDefault(), this.#R(t);
        }
        canvasPointerleave(t) {
          this.#R(t);
        }
        #R(t) {
          this.canvas.removeEventListener("pointerleave", this.#n), this.canvas.removeEventListener("pointermove", this.#s), this.canvas.removeEventListener("pointerup", this.#r), this.canvas.addEventListener("pointerdown", this.#i), this.#a && clearTimeout(this.#a), this.#a = setTimeout(() => {
            this.#a = null, this.canvas.removeEventListener("contextmenu", n.noContextMenu);
          }, 10), this.#L(t.offsetX, t.offsetY), this.addToAnnotationStorage(), this.setInBackground();
        }
        #T() {
          this.canvas = document.createElement("canvas"), this.canvas.width = this.canvas.height = 0, this.canvas.className = "inkEditorCanvas", this.canvas.setAttribute("data-l10n-id", "pdfjs-ink-canvas"), this.div.append(this.canvas), this.ctx = this.canvas.getContext("2d");
        }
        #M() {
          this.#c = new ResizeObserver((t) => {
            const i = t[0].contentRect;
            i.width && i.height && this.setDimensions(i.width, i.height);
          }), this.#c.observe(this.div);
        }
        get isResizable() {
          return !this.isEmpty() && this.#h;
        }
        render() {
          if (this.div)
            return this.div;
          let t, i;
          this.width && (t = this.x, i = this.y), super.render(), this.div.setAttribute("data-l10n-id", "pdfjs-ink");
          const [d, f, y, S] = this.#v();
          if (this.setAt(d, f, 0, 0), this.setDims(y, S), this.#T(), this.width) {
            const [L, M] = this.parentDimensions;
            this.setAspectRatio(this.width * L, this.height * M), this.setAt(t * L, i * M, this.width * L, this.height * M), this.#u = !0, this.#F(), this.setDims(this.width * L, this.height * M), this.#x(), this.div.classList.add("disabled");
          } else
            this.div.classList.add("editing"), this.enableEditMode();
          return this.#M(), this.div;
        }
        #F() {
          if (!this.#u)
            return;
          const [t, i] = this.parentDimensions;
          this.canvas.width = Math.ceil(this.width * t), this.canvas.height = Math.ceil(this.height * i), this.#P();
        }
        setDimensions(t, i) {
          const d = Math.round(t), f = Math.round(i);
          if (this.#o === d && this.#p === f)
            return;
          this.#o = d, this.#p = f, this.canvas.style.visibility = "hidden";
          const [y, S] = this.parentDimensions;
          this.width = t / y, this.height = i / S, this.fixAndSetPosition(), this.#h && this.#_(t, i), this.#F(), this.#x(), this.canvas.style.visibility = "visible", this.fixDims();
        }
        #_(t, i) {
          const d = this.#B(), f = (t - d) / this.#e, y = (i - d) / this.#t;
          this.scaleFactor = Math.min(f, y);
        }
        #P() {
          const t = this.#B() / 2;
          this.ctx.setTransform(this.scaleFactor, 0, 0, this.scaleFactor, this.translationX * this.scaleFactor + t, this.translationY * this.scaleFactor + t);
        }
        static #D(t) {
          const i = new Path2D();
          for (let d = 0, f = t.length; d < f; d++) {
            const [y, S, L, M] = t[d];
            d === 0 && i.moveTo(...y), i.bezierCurveTo(S[0], S[1], L[0], L[1], M[0], M[1]);
          }
          return i;
        }
        static #G(t, i, d) {
          const [f, y, S, L] = i;
          switch (d) {
            case 0:
              for (let M = 0, N = t.length; M < N; M += 2)
                t[M] += f, t[M + 1] = L - t[M + 1];
              break;
            case 90:
              for (let M = 0, N = t.length; M < N; M += 2) {
                const H = t[M];
                t[M] = t[M + 1] + f, t[M + 1] = H + y;
              }
              break;
            case 180:
              for (let M = 0, N = t.length; M < N; M += 2)
                t[M] = S - t[M], t[M + 1] += y;
              break;
            case 270:
              for (let M = 0, N = t.length; M < N; M += 2) {
                const H = t[M];
                t[M] = S - t[M + 1], t[M + 1] = L - H;
              }
              break;
            default:
              throw new Error("Invalid rotation");
          }
          return t;
        }
        static #$(t, i, d) {
          const [f, y, S, L] = i;
          switch (d) {
            case 0:
              for (let M = 0, N = t.length; M < N; M += 2)
                t[M] -= f, t[M + 1] = L - t[M + 1];
              break;
            case 90:
              for (let M = 0, N = t.length; M < N; M += 2) {
                const H = t[M];
                t[M] = t[M + 1] - y, t[M + 1] = H - f;
              }
              break;
            case 180:
              for (let M = 0, N = t.length; M < N; M += 2)
                t[M] = S - t[M], t[M + 1] -= y;
              break;
            case 270:
              for (let M = 0, N = t.length; M < N; M += 2) {
                const H = t[M];
                t[M] = L - t[M + 1], t[M + 1] = S - H;
              }
              break;
            default:
              throw new Error("Invalid rotation");
          }
          return t;
        }
        #X(t, i, d, f) {
          const y = [], S = this.thickness / 2, L = t * i + S, M = t * d + S;
          for (const N of this.paths) {
            const H = [], z = [];
            for (let q = 0, nt = N.length; q < nt; q++) {
              const [j, O, G, Y] = N[q];
              if (j[0] === Y[0] && j[1] === Y[1] && nt === 1) {
                const et = t * j[0] + L, m = t * j[1] + M;
                H.push(et, m), z.push(et, m);
                break;
              }
              const tt = t * j[0] + L, Z = t * j[1] + M, at = t * O[0] + L, lt = t * O[1] + M, pt = t * G[0] + L, dt = t * G[1] + M, ot = t * Y[0] + L, ut = t * Y[1] + M;
              q === 0 && (H.push(tt, Z), z.push(tt, Z)), H.push(at, lt, pt, dt, ot, ut), z.push(at, lt), q === nt - 1 && z.push(ot, ut);
            }
            y.push({
              bezier: l.#G(H, f, this.rotation),
              points: l.#G(z, f, this.rotation)
            });
          }
          return y;
        }
        #U() {
          let t = 1 / 0, i = -1 / 0, d = 1 / 0, f = -1 / 0;
          for (const y of this.paths)
            for (const [S, L, M, N] of y) {
              const H = w.Util.bezierBoundingBox(...S, ...L, ...M, ...N);
              t = Math.min(t, H[0]), d = Math.min(d, H[1]), i = Math.max(i, H[2]), f = Math.max(f, H[3]);
            }
          return [t, d, i, f];
        }
        #B() {
          return this.#h ? Math.ceil(this.thickness * this.parentScale) : 0;
        }
        #N(t = !1) {
          if (this.isEmpty())
            return;
          if (!this.#h) {
            this.#x();
            return;
          }
          const i = this.#U(), d = this.#B();
          this.#e = Math.max(B.AnnotationEditor.MIN_SIZE, i[2] - i[0]), this.#t = Math.max(B.AnnotationEditor.MIN_SIZE, i[3] - i[1]);
          const f = Math.ceil(d + this.#e * this.scaleFactor), y = Math.ceil(d + this.#t * this.scaleFactor), [S, L] = this.parentDimensions;
          this.width = f / S, this.height = y / L, this.setAspectRatio(f, y);
          const M = this.translationX, N = this.translationY;
          this.translationX = -i[0], this.translationY = -i[1], this.#F(), this.#x(), this.#o = f, this.#p = y, this.setDims(f, y);
          const H = t ? d / this.scaleFactor / 2 : 0;
          this.translate(M - this.translationX - H, N - this.translationY - H);
        }
        static deserialize(t, i, d) {
          if (t instanceof U.InkAnnotationElement)
            return null;
          const f = super.deserialize(t, i, d);
          f.thickness = t.thickness, f.color = w.Util.makeHexColor(...t.color), f.opacity = t.opacity;
          const [y, S] = f.pageDimensions, L = f.width * y, M = f.height * S, N = f.parentScale, H = t.thickness / 2;
          f.#h = !0, f.#o = Math.round(L), f.#p = Math.round(M);
          const {
            paths: z,
            rect: q,
            rotation: nt
          } = t;
          for (let {
            bezier: O
          } of z) {
            O = l.#$(O, q, nt);
            const G = [];
            f.paths.push(G);
            let Y = N * (O[0] - H), tt = N * (O[1] - H);
            for (let at = 2, lt = O.length; at < lt; at += 6) {
              const pt = N * (O[at] - H), dt = N * (O[at + 1] - H), ot = N * (O[at + 2] - H), ut = N * (O[at + 3] - H), et = N * (O[at + 4] - H), m = N * (O[at + 5] - H);
              G.push([[Y, tt], [pt, dt], [ot, ut], [et, m]]), Y = et, tt = m;
            }
            const Z = this.#D(G);
            f.bezierPath2D.push(Z);
          }
          const j = f.#U();
          return f.#e = Math.max(B.AnnotationEditor.MIN_SIZE, j[2] - j[0]), f.#t = Math.max(B.AnnotationEditor.MIN_SIZE, j[3] - j[1]), f.#_(L, M), f;
        }
        serialize() {
          if (this.isEmpty())
            return null;
          const t = this.getRect(0, 0), i = B.AnnotationEditor._colorManager.convert(this.ctx.strokeStyle);
          return {
            annotationType: w.AnnotationEditorType.INK,
            color: i,
            thickness: this.thickness,
            opacity: this.opacity,
            paths: this.#X(this.scaleFactor / this.parentScale, this.translationX, this.translationY, t),
            pageIndex: this.pageIndex,
            rect: t,
            rotation: this.rotation,
            structTreeParentId: this._structTreeParentId
          };
        }
      }
      class b extends B.AnnotationEditor {
        #t = null;
        #e = null;
        #s = null;
        #n = null;
        #r = null;
        #i = "";
        #a = null;
        #l = null;
        #h = null;
        #d = !1;
        #u = !1;
        static _type = "stamp";
        static _editorType = w.AnnotationEditorType.STAMP;
        constructor(t) {
          super({
            ...t,
            name: "stampEditor"
          }), this.#n = t.bitmapUrl, this.#r = t.bitmapFile;
        }
        static initialize(t, i) {
          B.AnnotationEditor.initialize(t, i);
        }
        static get supportedTypes() {
          const t = ["apng", "avif", "bmp", "gif", "jpeg", "png", "svg+xml", "webp", "x-icon"];
          return (0, w.shadow)(this, "supportedTypes", t.map((i) => `image/${i}`));
        }
        static get supportedTypesStr() {
          return (0, w.shadow)(this, "supportedTypesStr", this.supportedTypes.join(","));
        }
        static isHandlingMimeForPasting(t) {
          return this.supportedTypes.includes(t);
        }
        static paste(t, i) {
          i.pasteEditor(w.AnnotationEditorType.STAMP, {
            bitmapFile: t.getAsFile()
          });
        }
        #c(t, i = !1) {
          if (!t) {
            this.remove();
            return;
          }
          this.#t = t.bitmap, i || (this.#e = t.id, this.#d = t.isSvg), t.file && (this.#i = t.file.name), this.#g();
        }
        #o() {
          this.#s = null, this._uiManager.enableWaiting(!1), this.#a && this.div.focus();
        }
        #p() {
          if (this.#e) {
            this._uiManager.enableWaiting(!0), this._uiManager.imageManager.getFromId(this.#e).then((i) => this.#c(i, !0)).finally(() => this.#o());
            return;
          }
          if (this.#n) {
            const i = this.#n;
            this.#n = null, this._uiManager.enableWaiting(!0), this.#s = this._uiManager.imageManager.getFromUrl(i).then((d) => this.#c(d)).finally(() => this.#o());
            return;
          }
          if (this.#r) {
            const i = this.#r;
            this.#r = null, this._uiManager.enableWaiting(!0), this.#s = this._uiManager.imageManager.getFromFile(i).then((d) => this.#c(d)).finally(() => this.#o());
            return;
          }
          const t = document.createElement("input");
          t.type = "file", t.accept = b.supportedTypesStr, this.#s = new Promise((i) => {
            t.addEventListener("change", async () => {
              if (!t.files || t.files.length === 0)
                this.remove();
              else {
                this._uiManager.enableWaiting(!0);
                const d = await this._uiManager.imageManager.getFromFile(t.files[0]);
                this.#c(d);
              }
              i();
            }), t.addEventListener("cancel", () => {
              this.remove(), i();
            });
          }).finally(() => this.#o()), t.click();
        }
        remove() {
          this.#e && (this.#t = null, this._uiManager.imageManager.deleteId(this.#e), this.#a?.remove(), this.#a = null, this.#l?.disconnect(), this.#l = null, this.#h && (clearTimeout(this.#h), this.#h = null)), super.remove();
        }
        rebuild() {
          if (!this.parent) {
            this.#e && this.#p();
            return;
          }
          super.rebuild(), this.div !== null && (this.#e && this.#a === null && this.#p(), this.isAttachedToDOM || this.parent.add(this));
        }
        onceAdded() {
          this._isDraggable = !0, this.div.focus();
        }
        isEmpty() {
          return !(this.#s || this.#t || this.#n || this.#r || this.#e);
        }
        get isResizable() {
          return !0;
        }
        render() {
          if (this.div)
            return this.div;
          let t, i;
          if (this.width && (t = this.x, i = this.y), super.render(), this.div.hidden = !0, this.addAltTextButton(), this.#t ? this.#g() : this.#p(), this.width) {
            const [d, f] = this.parentDimensions;
            this.setAt(t * d, i * f, this.width * d, this.height * f);
          }
          return this.div;
        }
        #g() {
          const {
            div: t
          } = this;
          let {
            width: i,
            height: d
          } = this.#t;
          const [f, y] = this.pageDimensions, S = 0.75;
          if (this.width)
            i = this.width * f, d = this.height * y;
          else if (i > S * f || d > S * y) {
            const H = Math.min(S * f / i, S * y / d);
            i *= H, d *= H;
          }
          const [L, M] = this.parentDimensions;
          this.setDims(i * L / f, d * M / y), this._uiManager.enableWaiting(!1);
          const N = this.#a = document.createElement("canvas");
          t.append(N), t.hidden = !1, this.#m(i, d), this.#w(), this.#u || (this.parent.addUndoableEditor(this), this.#u = !0), this._reportTelemetry({
            action: "inserted_image"
          }), this.#i && N.setAttribute("aria-label", this.#i);
        }
        #f(t, i) {
          const [d, f] = this.parentDimensions;
          this.width = t / d, this.height = i / f, this.setDims(t, i), this._initialOptions?.isCentered ? this.center() : this.fixAndSetPosition(), this._initialOptions = null, this.#h !== null && clearTimeout(this.#h);
          const y = 200;
          this.#h = setTimeout(() => {
            this.#h = null, this.#m(t, i);
          }, y);
        }
        #A(t, i) {
          const {
            width: d,
            height: f
          } = this.#t;
          let y = d, S = f, L = this.#t;
          for (; y > 2 * t || S > 2 * i; ) {
            const M = y, N = S;
            y > 2 * t && (y = y >= 16384 ? Math.floor(y / 2) - 1 : Math.ceil(y / 2)), S > 2 * i && (S = S >= 16384 ? Math.floor(S / 2) - 1 : Math.ceil(S / 2));
            const H = new OffscreenCanvas(y, S);
            H.getContext("2d").drawImage(L, 0, 0, M, N, 0, 0, y, S), L = H.transferToImageBitmap();
          }
          return L;
        }
        #m(t, i) {
          t = Math.ceil(t), i = Math.ceil(i);
          const d = this.#a;
          if (!d || d.width === t && d.height === i)
            return;
          d.width = t, d.height = i;
          const f = this.#d ? this.#t : this.#A(t, i);
          if (this._uiManager.hasMLManager && !this.hasAltText()) {
            const S = new OffscreenCanvas(t, i);
            S.getContext("2d").drawImage(f, 0, 0, f.width, f.height, 0, 0, t, i), S.convertToBlob().then((M) => {
              const N = new FileReader();
              N.onload = () => {
                const H = N.result;
                this._uiManager.mlGuess({
                  service: "image-to-text",
                  request: {
                    imageData: H
                  }
                }).then((z) => {
                  const q = z?.output || "";
                  this.parent && q && !this.hasAltText() && (this.altTextData = {
                    altText: q,
                    decorative: !1
                  });
                });
              }, N.readAsDataURL(M);
            });
          }
          const y = d.getContext("2d");
          y.filter = this._uiManager.hcmFilter, y.drawImage(f, 0, 0, f.width, f.height, 0, 0, t, i);
        }
        getImageForAltText() {
          return this.#a;
        }
        #v(t) {
          if (t) {
            if (this.#d) {
              const f = this._uiManager.imageManager.getSvgUrl(this.#e);
              if (f)
                return f;
            }
            const i = document.createElement("canvas");
            return {
              width: i.width,
              height: i.height
            } = this.#t, i.getContext("2d").drawImage(this.#t, 0, 0), i.toDataURL();
          }
          if (this.#d) {
            const [i, d] = this.pageDimensions, f = Math.round(this.width * i * n.PixelsPerInch.PDF_TO_CSS_UNITS), y = Math.round(this.height * d * n.PixelsPerInch.PDF_TO_CSS_UNITS), S = new OffscreenCanvas(f, y);
            return S.getContext("2d").drawImage(this.#t, 0, 0, this.#t.width, this.#t.height, 0, 0, f, y), S.transferToImageBitmap();
          }
          return structuredClone(this.#t);
        }
        #w() {
          this.#l = new ResizeObserver((t) => {
            const i = t[0].contentRect;
            i.width && i.height && this.#f(i.width, i.height);
          }), this.#l.observe(this.div);
        }
        static deserialize(t, i, d) {
          if (t instanceof U.StampAnnotationElement)
            return null;
          const f = super.deserialize(t, i, d), {
            rect: y,
            bitmapUrl: S,
            bitmapId: L,
            isSvg: M,
            accessibilityData: N
          } = t;
          L && d.imageManager.isValidId(L) ? f.#e = L : f.#n = S, f.#d = M;
          const [H, z] = f.pageDimensions;
          return f.width = (y[2] - y[0]) / H, f.height = (y[3] - y[1]) / z, N && (f.altTextData = N), f;
        }
        serialize(t = !1, i = null) {
          if (this.isEmpty())
            return null;
          const d = {
            annotationType: w.AnnotationEditorType.STAMP,
            bitmapId: this.#e,
            pageIndex: this.pageIndex,
            rect: this.getRect(0, 0),
            rotation: this.rotation,
            isSvg: this.#d,
            structTreeParentId: this._structTreeParentId
          };
          if (t)
            return d.bitmapUrl = this.#v(!0), d.accessibilityData = this.altTextData, d;
          const {
            decorative: f,
            altText: y
          } = this.altTextData;
          if (!f && y && (d.accessibilityData = {
            type: "Figure",
            alt: y
          }), i === null)
            return d;
          i.stamps ||= /* @__PURE__ */ new Map();
          const S = this.#d ? (d.rect[2] - d.rect[0]) * (d.rect[3] - d.rect[1]) : null;
          if (!i.stamps.has(this.#e))
            i.stamps.set(this.#e, {
              area: S,
              serialized: d
            }), d.bitmap = this.#v(!1);
          else if (this.#d) {
            const L = i.stamps.get(this.#e);
            S > L.area && (L.area = S, L.serialized.bitmap.close(), L.serialized.bitmap = this.#v(!1));
          }
          return d;
        }
      }
      class s {
        #t;
        #e = !1;
        #s = null;
        #n = null;
        #r = null;
        #i = null;
        #a = null;
        #l = /* @__PURE__ */ new Map();
        #h = !1;
        #d = !1;
        #u = !1;
        #c = null;
        #o;
        static _initialized = !1;
        static #p = new Map([T, l, b, c].map((t) => [t._editorType, t]));
        constructor({
          uiManager: t,
          pageIndex: i,
          div: d,
          accessibilityManager: f,
          annotationLayer: y,
          drawLayer: S,
          textLayer: L,
          viewport: M,
          l10n: N
        }) {
          const H = [...s.#p.values()];
          if (!s._initialized) {
            s._initialized = !0;
            for (const z of H)
              z.initialize(N, t);
          }
          t.registerEditorTypes(H), this.#o = t, this.pageIndex = i, this.div = d, this.#t = f, this.#s = y, this.viewport = M, this.#c = L, this.drawLayer = S, this.#o.addLayer(this);
        }
        get isEmpty() {
          return this.#l.size === 0;
        }
        get isInvisible() {
          return this.isEmpty && this.#o.getMode() === w.AnnotationEditorType.NONE;
        }
        updateToolbar(t) {
          this.#o.updateToolbar(t);
        }
        updateMode(t = this.#o.getMode()) {
          switch (this.#v(), t) {
            case w.AnnotationEditorType.NONE:
              this.disableTextSelection(), this.togglePointerEvents(!1), this.toggleAnnotationLayerPointerEvents(!0), this.disableClick();
              return;
            case w.AnnotationEditorType.INK:
              this.addInkEditorIfNeeded(!1), this.disableTextSelection(), this.togglePointerEvents(!0), this.disableClick();
              break;
            case w.AnnotationEditorType.HIGHLIGHT:
              this.enableTextSelection(), this.togglePointerEvents(!1), this.disableClick();
              break;
            default:
              this.disableTextSelection(), this.togglePointerEvents(!0), this.enableClick();
          }
          this.toggleAnnotationLayerPointerEvents(!1);
          const {
            classList: i
          } = this.div;
          for (const d of s.#p.values())
            i.toggle(`${d._type}Editing`, t === d._editorType);
          this.div.hidden = !1;
        }
        hasTextLayer(t) {
          return t === this.#c?.div;
        }
        addInkEditorIfNeeded(t) {
          if (this.#o.getMode() !== w.AnnotationEditorType.INK)
            return;
          if (!t) {
            for (const d of this.#l.values())
              if (d.isEmpty()) {
                d.setInBackground();
                return;
              }
          }
          this.createAndAddNewEditor({
            offsetX: 0,
            offsetY: 0
          }, !1).setInBackground();
        }
        setEditingState(t) {
          this.#o.setEditingState(t);
        }
        addCommands(t) {
          this.#o.addCommands(t);
        }
        togglePointerEvents(t = !1) {
          this.div.classList.toggle("disabled", !t);
        }
        toggleAnnotationLayerPointerEvents(t = !1) {
          this.#s?.div.classList.toggle("disabled", !t);
        }
        enable() {
          this.div.tabIndex = 0, this.togglePointerEvents(!0);
          const t = /* @__PURE__ */ new Set();
          for (const d of this.#l.values())
            d.enableEditing(), d.show(!0), d.annotationElementId && (this.#o.removeChangedExistingAnnotation(d), t.add(d.annotationElementId));
          if (!this.#s)
            return;
          const i = this.#s.getEditableAnnotations();
          for (const d of i) {
            if (d.hide(), this.#o.isDeletedAnnotationElement(d.data.id) || t.has(d.data.id))
              continue;
            const f = this.deserialize(d);
            f && (this.addOrRebuild(f), f.enableEditing());
          }
        }
        disable() {
          this.#u = !0, this.div.tabIndex = -1, this.togglePointerEvents(!1);
          const t = /* @__PURE__ */ new Map(), i = /* @__PURE__ */ new Map();
          for (const f of this.#l.values())
            if (f.disableEditing(), !!f.annotationElementId) {
              if (f.serialize() !== null) {
                t.set(f.annotationElementId, f);
                continue;
              } else
                i.set(f.annotationElementId, f);
              this.getEditableAnnotation(f.annotationElementId)?.show(), f.remove();
            }
          if (this.#s) {
            const f = this.#s.getEditableAnnotations();
            for (const y of f) {
              const {
                id: S
              } = y.data;
              if (this.#o.isDeletedAnnotationElement(S))
                continue;
              let L = i.get(S);
              if (L) {
                L.resetAnnotationElement(y), L.show(!1), y.show();
                continue;
              }
              L = t.get(S), L && (this.#o.addChangedExistingAnnotation(L), L.renderAnnotationElement(y), L.show(!1)), y.show();
            }
          }
          this.#v(), this.isEmpty && (this.div.hidden = !0);
          const {
            classList: d
          } = this.div;
          for (const f of s.#p.values())
            d.remove(`${f._type}Editing`);
          this.disableTextSelection(), this.toggleAnnotationLayerPointerEvents(!0), this.#u = !1;
        }
        getEditableAnnotation(t) {
          return this.#s?.getEditableAnnotation(t) || null;
        }
        setActiveEditor(t) {
          this.#o.getActive() !== t && this.#o.setActiveEditor(t);
        }
        enableTextSelection() {
          this.div.tabIndex = -1, this.#c?.div && !this.#i && (this.#i = this.#g.bind(this), this.#c.div.addEventListener("pointerdown", this.#i), this.#c.div.classList.add("highlighting"));
        }
        disableTextSelection() {
          this.div.tabIndex = 0, this.#c?.div && this.#i && (this.#c.div.removeEventListener("pointerdown", this.#i), this.#i = null, this.#c.div.classList.remove("highlighting"));
        }
        #g(t) {
          if (this.#o.unselectAll(), t.target === this.#c.div) {
            const {
              isMac: i
            } = w.FeatureTest.platform;
            if (t.button !== 0 || t.ctrlKey && i)
              return;
            this.#o.showAllEditors("highlight", !0, !0), this.#c.div.classList.add("free"), c.startHighlighting(this, this.#o.direction === "ltr", t), this.#c.div.addEventListener("pointerup", () => {
              this.#c.div.classList.remove("free");
            }, {
              once: !0
            }), t.preventDefault();
          }
        }
        enableClick() {
          this.#r || (this.#r = this.pointerdown.bind(this), this.#n = this.pointerup.bind(this), this.div.addEventListener("pointerdown", this.#r), this.div.addEventListener("pointerup", this.#n));
        }
        disableClick() {
          this.#r && (this.div.removeEventListener("pointerdown", this.#r), this.div.removeEventListener("pointerup", this.#n), this.#r = null, this.#n = null);
        }
        attach(t) {
          this.#l.set(t.id, t);
          const {
            annotationElementId: i
          } = t;
          i && this.#o.isDeletedAnnotationElement(i) && this.#o.removeDeletedAnnotationElement(t);
        }
        detach(t) {
          this.#l.delete(t.id), this.#t?.removePointerInTextLayer(t.contentDiv), !this.#u && t.annotationElementId && this.#o.addDeletedAnnotationElement(t);
        }
        remove(t) {
          this.detach(t), this.#o.removeEditor(t), t.div.remove(), t.isAttachedToDOM = !1, this.#d || this.addInkEditorIfNeeded(!1);
        }
        changeParent(t) {
          t.parent !== this && (t.parent && t.annotationElementId && (this.#o.addDeletedAnnotationElement(t.annotationElementId), B.AnnotationEditor.deleteAnnotationElement(t), t.annotationElementId = null), this.attach(t), t.parent?.detach(t), t.setParent(this), t.div && t.isAttachedToDOM && (t.div.remove(), this.div.append(t.div)));
        }
        add(t) {
          if (!(t.parent === this && t.isAttachedToDOM)) {
            if (this.changeParent(t), this.#o.addEditor(t), this.attach(t), !t.isAttachedToDOM) {
              const i = t.render();
              this.div.append(i), t.isAttachedToDOM = !0;
            }
            t.fixAndSetPosition(), t.onceAdded(), this.#o.addToAnnotationStorage(t), t._reportTelemetry(t.telemetryInitialData);
          }
        }
        moveEditorInDOM(t) {
          if (!t.isAttachedToDOM)
            return;
          const {
            activeElement: i
          } = document;
          t.div.contains(i) && !this.#a && (t._focusEventsAllowed = !1, this.#a = setTimeout(() => {
            this.#a = null, t.div.contains(document.activeElement) ? t._focusEventsAllowed = !0 : (t.div.addEventListener("focusin", () => {
              t._focusEventsAllowed = !0;
            }, {
              once: !0
            }), i.focus());
          }, 0)), t._structTreeParentId = this.#t?.moveElementInDOM(this.div, t.div, t.contentDiv, !0);
        }
        addOrRebuild(t) {
          t.needsToBeRebuilt() ? (t.parent ||= this, t.rebuild(), t.show()) : this.add(t);
        }
        addUndoableEditor(t) {
          const i = () => t._uiManager.rebuild(t), d = () => {
            t.remove();
          };
          this.addCommands({
            cmd: i,
            undo: d,
            mustExec: !1
          });
        }
        getNextId() {
          return this.#o.getId();
        }
        get #f() {
          return s.#p.get(this.#o.getMode());
        }
        #A(t) {
          const i = this.#f;
          return i ? new i.prototype.constructor(t) : null;
        }
        canCreateNewEmptyEditor() {
          return this.#f?.canCreateNewEmptyEditor();
        }
        pasteEditor(t, i) {
          this.#o.updateToolbar(t), this.#o.updateMode(t);
          const {
            offsetX: d,
            offsetY: f
          } = this.#m(), y = this.getNextId(), S = this.#A({
            parent: this,
            id: y,
            x: d,
            y: f,
            uiManager: this.#o,
            isCentered: !0,
            ...i
          });
          S && this.add(S);
        }
        deserialize(t) {
          return s.#p.get(t.annotationType ?? t.annotationEditorType)?.deserialize(t, this, this.#o) || null;
        }
        createAndAddNewEditor(t, i, d = {}) {
          const f = this.getNextId(), y = this.#A({
            parent: this,
            id: f,
            x: t.offsetX,
            y: t.offsetY,
            uiManager: this.#o,
            isCentered: i,
            ...d
          });
          return y && this.add(y), y;
        }
        #m() {
          const {
            x: t,
            y: i,
            width: d,
            height: f
          } = this.div.getBoundingClientRect(), y = Math.max(0, t), S = Math.max(0, i), L = Math.min(window.innerWidth, t + d), M = Math.min(window.innerHeight, i + f), N = (y + L) / 2 - t, H = (S + M) / 2 - i, [z, q] = this.viewport.rotation % 180 === 0 ? [N, H] : [H, N];
          return {
            offsetX: z,
            offsetY: q
          };
        }
        addNewEditor() {
          this.createAndAddNewEditor(this.#m(), !0);
        }
        setSelected(t) {
          this.#o.setSelected(t);
        }
        toggleSelected(t) {
          this.#o.toggleSelected(t);
        }
        isSelected(t) {
          return this.#o.isSelected(t);
        }
        unselect(t) {
          this.#o.unselect(t);
        }
        pointerup(t) {
          const {
            isMac: i
          } = w.FeatureTest.platform;
          if (!(t.button !== 0 || t.ctrlKey && i) && t.target === this.div && this.#h) {
            if (this.#h = !1, !this.#e) {
              this.#e = !0;
              return;
            }
            if (this.#o.getMode() === w.AnnotationEditorType.STAMP) {
              this.#o.unselectAll();
              return;
            }
            this.createAndAddNewEditor(t, !1);
          }
        }
        pointerdown(t) {
          if (this.#o.getMode() === w.AnnotationEditorType.HIGHLIGHT && this.enableTextSelection(), this.#h) {
            this.#h = !1;
            return;
          }
          const {
            isMac: i
          } = w.FeatureTest.platform;
          if (t.button !== 0 || t.ctrlKey && i || t.target !== this.div)
            return;
          this.#h = !0;
          const d = this.#o.getActive();
          this.#e = !d || d.isEmpty();
        }
        findNewParent(t, i, d) {
          const f = this.#o.findParent(i, d);
          return f === null || f === this ? !1 : (f.changeParent(t), !0);
        }
        destroy() {
          this.#o.getActive()?.parent === this && (this.#o.commitOrRemove(), this.#o.setActiveEditor(null)), this.#a && (clearTimeout(this.#a), this.#a = null);
          for (const t of this.#l.values())
            this.#t?.removePointerInTextLayer(t.contentDiv), t.setParent(null), t.isAttachedToDOM = !1, t.div.remove();
          this.div = null, this.#l.clear(), this.#o.removeLayer(this);
        }
        #v() {
          this.#d = !0;
          for (const t of this.#l.values())
            t.isEmpty() && t.remove();
          this.#d = !1;
        }
        render({
          viewport: t
        }) {
          this.viewport = t, (0, n.setLayerDimensions)(this.div, t);
          for (const i of this.#o.getEditors(this.pageIndex))
            this.add(i), i.rebuild();
          this.updateMode();
        }
        update({
          viewport: t
        }) {
          this.#o.commitOrRemove(), this.#v();
          const i = this.viewport.rotation, d = t.rotation;
          if (this.viewport = t, (0, n.setLayerDimensions)(this.div, {
            rotation: d
          }), i !== d)
            for (const f of this.#l.values())
              f.rotate(d);
          this.addInkEditorIfNeeded(!1);
        }
        get pageDimensions() {
          const {
            pageWidth: t,
            pageHeight: i
          } = this.viewport.rawDims;
          return [t, i];
        }
        get scale() {
          return this.#o.viewParameters.realScale;
        }
      }
    })
  ),
  /***/
  259: (
    /***/
    ((ct, st, V) => {
      V.d(st, {
        /* harmony export */
        ColorPicker: () => (
          /* binding */
          U
        )
        /* harmony export */
      });
      var w = V(292), B = V(830), _ = V(419);
      class U {
        #t = this.#g.bind(this);
        #e = this.#A.bind(this);
        #s = null;
        #n = null;
        #r;
        #i = null;
        #a = !1;
        #l = !1;
        #h = null;
        #d;
        #u = null;
        #c;
        static get _keyboardManager() {
          return (0, w.shadow)(this, "_keyboardManager", new B.KeyboardManager([[["Escape", "mac+Escape"], U.prototype._hideDropdownFromKeyboard], [[" ", "mac+ "], U.prototype._colorSelectFromKeyboard], [["ArrowDown", "ArrowRight", "mac+ArrowDown", "mac+ArrowRight"], U.prototype._moveToNext], [["ArrowUp", "ArrowLeft", "mac+ArrowUp", "mac+ArrowLeft"], U.prototype._moveToPrevious], [["Home", "mac+Home"], U.prototype._moveToBeginning], [["End", "mac+End"], U.prototype._moveToEnd]]));
        }
        constructor({
          editor: T = null,
          uiManager: E = null
        }) {
          T ? (this.#l = !1, this.#c = w.AnnotationEditorParamsType.HIGHLIGHT_COLOR, this.#h = T) : (this.#l = !0, this.#c = w.AnnotationEditorParamsType.HIGHLIGHT_DEFAULT_COLOR), this.#u = T?._uiManager || E, this.#d = this.#u._eventBus, this.#r = T?.color || this.#u?.highlightColors.values().next().value || "#FFFF98";
        }
        renderButton() {
          const T = this.#s = document.createElement("button");
          T.className = "colorPicker", T.tabIndex = "0", T.setAttribute("data-l10n-id", "pdfjs-editor-colorpicker-button"), T.setAttribute("aria-haspopup", !0), T.addEventListener("click", this.#f.bind(this)), T.addEventListener("keydown", this.#t);
          const E = this.#n = document.createElement("span");
          return E.className = "swatch", E.setAttribute("aria-hidden", !0), E.style.backgroundColor = this.#r, T.append(E), T;
        }
        renderMainDropdown() {
          const T = this.#i = this.#o();
          return T.setAttribute("aria-orientation", "horizontal"), T.setAttribute("aria-labelledby", "highlightColorPickerLabel"), T;
        }
        #o() {
          const T = document.createElement("div");
          T.addEventListener("contextmenu", _.noContextMenu), T.className = "dropdown", T.role = "listbox", T.setAttribute("aria-multiselectable", !1), T.setAttribute("aria-orientation", "vertical"), T.setAttribute("data-l10n-id", "pdfjs-editor-colorpicker-dropdown");
          for (const [E, v] of this.#u.highlightColors) {
            const n = document.createElement("button");
            n.tabIndex = "0", n.role = "option", n.setAttribute("data-color", v), n.title = E, n.setAttribute("data-l10n-id", `pdfjs-editor-colorpicker-${E}`);
            const c = document.createElement("span");
            n.append(c), c.className = "swatch", c.style.backgroundColor = v, n.setAttribute("aria-selected", v === this.#r), n.addEventListener("click", this.#p.bind(this, v)), T.append(n);
          }
          return T.addEventListener("keydown", this.#t), T;
        }
        #p(T, E) {
          E.stopPropagation(), this.#d.dispatch("switchannotationeditorparams", {
            source: this,
            type: this.#c,
            value: T
          });
        }
        _colorSelectFromKeyboard(T) {
          if (T.target === this.#s) {
            this.#f(T);
            return;
          }
          const E = T.target.getAttribute("data-color");
          E && this.#p(E, T);
        }
        _moveToNext(T) {
          if (!this.#m) {
            this.#f(T);
            return;
          }
          if (T.target === this.#s) {
            this.#i.firstChild?.focus();
            return;
          }
          T.target.nextSibling?.focus();
        }
        _moveToPrevious(T) {
          if (T.target === this.#i?.firstChild || T.target === this.#s) {
            this.#m && this._hideDropdownFromKeyboard();
            return;
          }
          this.#m || this.#f(T), T.target.previousSibling?.focus();
        }
        _moveToBeginning(T) {
          if (!this.#m) {
            this.#f(T);
            return;
          }
          this.#i.firstChild?.focus();
        }
        _moveToEnd(T) {
          if (!this.#m) {
            this.#f(T);
            return;
          }
          this.#i.lastChild?.focus();
        }
        #g(T) {
          U._keyboardManager.exec(this, T);
        }
        #f(T) {
          if (this.#m) {
            this.hideDropdown();
            return;
          }
          if (this.#a = T.detail === 0, window.addEventListener("pointerdown", this.#e), this.#i) {
            this.#i.classList.remove("hidden");
            return;
          }
          const E = this.#i = this.#o();
          this.#s.append(E);
        }
        #A(T) {
          this.#i?.contains(T.target) || this.hideDropdown();
        }
        hideDropdown() {
          this.#i?.classList.add("hidden"), window.removeEventListener("pointerdown", this.#e);
        }
        get #m() {
          return this.#i && !this.#i.classList.contains("hidden");
        }
        _hideDropdownFromKeyboard() {
          if (!this.#l) {
            if (!this.#m) {
              this.#h?.unselect();
              return;
            }
            this.hideDropdown(), this.#s.focus({
              preventScroll: !0,
              focusVisible: this.#a
            });
          }
        }
        updateColor(T) {
          if (this.#n && (this.#n.style.backgroundColor = T), !this.#i)
            return;
          const E = this.#u.highlightColors.values();
          for (const v of this.#i.children)
            v.setAttribute("aria-selected", E.next().value === T);
        }
        destroy() {
          this.#s?.remove(), this.#s = null, this.#n = null, this.#i?.remove(), this.#i = null;
        }
      }
    })
  ),
  /***/
  310: (
    /***/
    ((ct, st, V) => {
      V.d(st, {
        AnnotationEditor: () => (
          /* binding */
          T
        )
      });
      var w = V(830), B = V(292), _ = V(419);
      class U {
        #t = "";
        #e = !1;
        #s = null;
        #n = null;
        #r = null;
        #i = !1;
        #a = null;
        static _l10nPromise = null;
        constructor(n) {
          this.#a = n;
        }
        static initialize(n) {
          U._l10nPromise ||= n;
        }
        async render() {
          const n = this.#s = document.createElement("button");
          n.className = "altText";
          const c = await U._l10nPromise.get("pdfjs-editor-alt-text-button-label");
          n.textContent = c, n.setAttribute("aria-label", c), n.tabIndex = "0", n.addEventListener("contextmenu", _.noContextMenu), n.addEventListener("pointerdown", (b) => b.stopPropagation());
          const l = (b) => {
            b.preventDefault(), this.#a._uiManager.editAltText(this.#a);
          };
          return n.addEventListener("click", l, {
            capture: !0
          }), n.addEventListener("keydown", (b) => {
            b.target === n && b.key === "Enter" && (this.#i = !0, l(b));
          }), await this.#l(), n;
        }
        finish() {
          this.#s && (this.#s.focus({
            focusVisible: this.#i
          }), this.#i = !1);
        }
        isEmpty() {
          return !this.#t && !this.#e;
        }
        get data() {
          return {
            altText: this.#t,
            decorative: this.#e
          };
        }
        set data({
          altText: n,
          decorative: c
        }) {
          this.#t === n && this.#e === c || (this.#t = n, this.#e = c, this.#l());
        }
        toggle(n = !1) {
          this.#s && (!n && this.#r && (clearTimeout(this.#r), this.#r = null), this.#s.disabled = !n);
        }
        destroy() {
          this.#s?.remove(), this.#s = null, this.#n = null;
        }
        async #l() {
          const n = this.#s;
          if (!n)
            return;
          if (!this.#t && !this.#e) {
            n.classList.remove("done"), this.#n?.remove();
            return;
          }
          n.classList.add("done"), U._l10nPromise.get("pdfjs-editor-alt-text-edit-button-label").then((b) => {
            n.setAttribute("aria-label", b);
          });
          let c = this.#n;
          if (!c) {
            this.#n = c = document.createElement("span"), c.className = "tooltip", c.setAttribute("role", "tooltip");
            const b = c.id = `alt-text-tooltip-${this.#a.id}`;
            n.setAttribute("aria-describedby", b);
            const s = 100;
            n.addEventListener("mouseenter", () => {
              this.#r = setTimeout(() => {
                this.#r = null, this.#n.classList.add("show"), this.#a._reportTelemetry({
                  action: "alt_text_tooltip"
                });
              }, s);
            }), n.addEventListener("mouseleave", () => {
              this.#r && (clearTimeout(this.#r), this.#r = null), this.#n?.classList.remove("show");
            });
          }
          c.innerText = this.#e ? await U._l10nPromise.get("pdfjs-editor-alt-text-decorative-tooltip") : this.#t, c.parentNode || n.append(c), this.#a.getImageForAltText()?.setAttribute("aria-describedby", c.id);
        }
      }
      var P = V(362);
      class T {
        #t = null;
        #e = null;
        #s = !1;
        #n = !1;
        #r = null;
        #i = null;
        #a = this.focusin.bind(this);
        #l = this.focusout.bind(this);
        #h = null;
        #d = "";
        #u = !1;
        #c = null;
        #o = !1;
        #p = !1;
        #g = !1;
        #f = null;
        #A = 0;
        #m = 0;
        #v = null;
        _initialOptions = /* @__PURE__ */ Object.create(null);
        _isVisible = !0;
        _uiManager = null;
        _focusEventsAllowed = !0;
        _l10nPromise = null;
        #w = !1;
        #C = T._zIndex++;
        static _borderLineWidth = -1;
        static _colorManager = new w.ColorManager();
        static _zIndex = 1;
        static _telemetryTimeout = 1e3;
        static get _resizerKeyboardManager() {
          const n = T.prototype._resizeWithKeyboard, c = w.AnnotationEditorUIManager.TRANSLATE_SMALL, l = w.AnnotationEditorUIManager.TRANSLATE_BIG;
          return (0, B.shadow)(this, "_resizerKeyboardManager", new w.KeyboardManager([[["ArrowLeft", "mac+ArrowLeft"], n, {
            args: [-c, 0]
          }], [["ctrl+ArrowLeft", "mac+shift+ArrowLeft"], n, {
            args: [-l, 0]
          }], [["ArrowRight", "mac+ArrowRight"], n, {
            args: [c, 0]
          }], [["ctrl+ArrowRight", "mac+shift+ArrowRight"], n, {
            args: [l, 0]
          }], [["ArrowUp", "mac+ArrowUp"], n, {
            args: [0, -c]
          }], [["ctrl+ArrowUp", "mac+shift+ArrowUp"], n, {
            args: [0, -l]
          }], [["ArrowDown", "mac+ArrowDown"], n, {
            args: [0, c]
          }], [["ctrl+ArrowDown", "mac+shift+ArrowDown"], n, {
            args: [0, l]
          }], [["Escape", "mac+Escape"], T.prototype._stopResizingWithKeyboard]]));
        }
        constructor(n) {
          this.constructor === T && (0, B.unreachable)("Cannot initialize AnnotationEditor."), this.parent = n.parent, this.id = n.id, this.width = this.height = null, this.pageIndex = n.parent.pageIndex, this.name = n.name, this.div = null, this._uiManager = n.uiManager, this.annotationElementId = null, this._willKeepAspectRatio = !1, this._initialOptions.isCentered = n.isCentered, this._structTreeParentId = null;
          const {
            rotation: c,
            rawDims: {
              pageWidth: l,
              pageHeight: b,
              pageX: s,
              pageY: g
            }
          } = this.parent.viewport;
          this.rotation = c, this.pageRotation = (360 + c - this._uiManager.viewParameters.rotation) % 360, this.pageDimensions = [l, b], this.pageTranslation = [s, g];
          const [t, i] = this.parentDimensions;
          this.x = n.x / t, this.y = n.y / i, this.isAttachedToDOM = !1, this.deleted = !1;
        }
        get editorType() {
          return Object.getPrototypeOf(this).constructor._type;
        }
        static get _defaultLineColor() {
          return (0, B.shadow)(this, "_defaultLineColor", this._colorManager.getHexCode("CanvasText"));
        }
        static deleteAnnotationElement(n) {
          const c = new E({
            id: n.parent.getNextId(),
            parent: n.parent,
            uiManager: n._uiManager
          });
          c.annotationElementId = n.annotationElementId, c.deleted = !0, c._uiManager.addToAnnotationStorage(c);
        }
        static initialize(n, c, l) {
          if (T._l10nPromise ||= new Map(["pdfjs-editor-alt-text-button-label", "pdfjs-editor-alt-text-edit-button-label", "pdfjs-editor-alt-text-decorative-tooltip", "pdfjs-editor-resizer-label-topLeft", "pdfjs-editor-resizer-label-topMiddle", "pdfjs-editor-resizer-label-topRight", "pdfjs-editor-resizer-label-middleRight", "pdfjs-editor-resizer-label-bottomRight", "pdfjs-editor-resizer-label-bottomMiddle", "pdfjs-editor-resizer-label-bottomLeft", "pdfjs-editor-resizer-label-middleLeft"].map((s) => [s, n.get(s.replaceAll(/([A-Z])/g, (g) => `-${g.toLowerCase()}`))])), l?.strings)
            for (const s of l.strings)
              T._l10nPromise.set(s, n.get(s));
          if (T._borderLineWidth !== -1)
            return;
          const b = getComputedStyle(document.documentElement);
          T._borderLineWidth = parseFloat(b.getPropertyValue("--outline-width")) || 0;
        }
        static updateDefaultParams(n, c) {
        }
        static get defaultPropertiesToUpdate() {
          return [];
        }
        static isHandlingMimeForPasting(n) {
          return !1;
        }
        static paste(n, c) {
          (0, B.unreachable)("Not implemented");
        }
        get propertiesToUpdate() {
          return [];
        }
        get _isDraggable() {
          return this.#w;
        }
        set _isDraggable(n) {
          this.#w = n, this.div?.classList.toggle("draggable", n);
        }
        get isEnterHandled() {
          return !0;
        }
        center() {
          const [n, c] = this.pageDimensions;
          switch (this.parentRotation) {
            case 90:
              this.x -= this.height * c / (n * 2), this.y += this.width * n / (c * 2);
              break;
            case 180:
              this.x += this.width / 2, this.y += this.height / 2;
              break;
            case 270:
              this.x += this.height * c / (n * 2), this.y -= this.width * n / (c * 2);
              break;
            default:
              this.x -= this.width / 2, this.y -= this.height / 2;
              break;
          }
          this.fixAndSetPosition();
        }
        addCommands(n) {
          this._uiManager.addCommands(n);
        }
        get currentLayer() {
          return this._uiManager.currentLayer;
        }
        setInBackground() {
          this.div.style.zIndex = 0;
        }
        setInForeground() {
          this.div.style.zIndex = this.#C;
        }
        setParent(n) {
          n !== null ? (this.pageIndex = n.pageIndex, this.pageDimensions = n.pageDimensions) : this.#D(), this.parent = n;
        }
        focusin(n) {
          this._focusEventsAllowed && (this.#u ? this.#u = !1 : this.parent.setSelected(this));
        }
        focusout(n) {
          !this._focusEventsAllowed || !this.isAttachedToDOM || n.relatedTarget?.closest(`#${this.id}`) || (n.preventDefault(), this.parent?.isMultipleSelection || this.commitOrRemove());
        }
        commitOrRemove() {
          this.isEmpty() ? this.remove() : this.commit();
        }
        commit() {
          this.addToAnnotationStorage();
        }
        addToAnnotationStorage() {
          this._uiManager.addToAnnotationStorage(this);
        }
        setAt(n, c, l, b) {
          const [s, g] = this.parentDimensions;
          [l, b] = this.screenToPageTranslation(l, b), this.x = (n + l) / s, this.y = (c + b) / g, this.fixAndSetPosition();
        }
        #k([n, c], l, b) {
          [l, b] = this.screenToPageTranslation(l, b), this.x += l / n, this.y += b / c, this.fixAndSetPosition();
        }
        translate(n, c) {
          this.#k(this.parentDimensions, n, c);
        }
        translateInPage(n, c) {
          this.#c ||= [this.x, this.y], this.#k(this.pageDimensions, n, c), this.div.scrollIntoView({
            block: "nearest"
          });
        }
        drag(n, c) {
          this.#c ||= [this.x, this.y];
          const [l, b] = this.parentDimensions;
          if (this.x += n / l, this.y += c / b, this.parent && (this.x < 0 || this.x > 1 || this.y < 0 || this.y > 1)) {
            const {
              x: d,
              y: f
            } = this.div.getBoundingClientRect();
            this.parent.findNewParent(this, d, f) && (this.x -= Math.floor(this.x), this.y -= Math.floor(this.y));
          }
          let {
            x: s,
            y: g
          } = this;
          const [t, i] = this.getBaseTranslation();
          s += t, g += i, this.div.style.left = `${(100 * s).toFixed(2)}%`, this.div.style.top = `${(100 * g).toFixed(2)}%`, this.div.scrollIntoView({
            block: "nearest"
          });
        }
        get _hasBeenMoved() {
          return !!this.#c && (this.#c[0] !== this.x || this.#c[1] !== this.y);
        }
        getBaseTranslation() {
          const [n, c] = this.parentDimensions, {
            _borderLineWidth: l
          } = T, b = l / n, s = l / c;
          switch (this.rotation) {
            case 90:
              return [-b, s];
            case 180:
              return [b, s];
            case 270:
              return [b, -s];
            default:
              return [-b, -s];
          }
        }
        get _mustFixPosition() {
          return !0;
        }
        fixAndSetPosition(n = this.rotation) {
          const [c, l] = this.pageDimensions;
          let {
            x: b,
            y: s,
            width: g,
            height: t
          } = this;
          if (g *= c, t *= l, b *= c, s *= l, this._mustFixPosition)
            switch (n) {
              case 0:
                b = Math.max(0, Math.min(c - g, b)), s = Math.max(0, Math.min(l - t, s));
                break;
              case 90:
                b = Math.max(0, Math.min(c - t, b)), s = Math.min(l, Math.max(g, s));
                break;
              case 180:
                b = Math.min(c, Math.max(g, b)), s = Math.min(l, Math.max(t, s));
                break;
              case 270:
                b = Math.min(c, Math.max(t, b)), s = Math.max(0, Math.min(l - g, s));
                break;
            }
          this.x = b /= c, this.y = s /= l;
          const [i, d] = this.getBaseTranslation();
          b += i, s += d;
          const {
            style: f
          } = this.div;
          f.left = `${(100 * b).toFixed(2)}%`, f.top = `${(100 * s).toFixed(2)}%`, this.moveInDOM();
        }
        static #I(n, c, l) {
          switch (l) {
            case 90:
              return [c, -n];
            case 180:
              return [-n, -c];
            case 270:
              return [-c, n];
            default:
              return [n, c];
          }
        }
        screenToPageTranslation(n, c) {
          return T.#I(n, c, this.parentRotation);
        }
        pageTranslationToScreen(n, c) {
          return T.#I(n, c, 360 - this.parentRotation);
        }
        #L(n) {
          switch (n) {
            case 90: {
              const [c, l] = this.pageDimensions;
              return [0, -c / l, l / c, 0];
            }
            case 180:
              return [-1, 0, 0, -1];
            case 270: {
              const [c, l] = this.pageDimensions;
              return [0, c / l, -l / c, 0];
            }
            default:
              return [1, 0, 0, 1];
          }
        }
        get parentScale() {
          return this._uiManager.viewParameters.realScale;
        }
        get parentRotation() {
          return (this._uiManager.viewParameters.rotation + this.pageRotation) % 360;
        }
        get parentDimensions() {
          const {
            parentScale: n,
            pageDimensions: [c, l]
          } = this, b = c * n, s = l * n;
          return B.FeatureTest.isCSSRoundSupported ? [Math.round(b), Math.round(s)] : [b, s];
        }
        setDims(n, c) {
          const [l, b] = this.parentDimensions;
          this.div.style.width = `${(100 * n / l).toFixed(2)}%`, this.#n || (this.div.style.height = `${(100 * c / b).toFixed(2)}%`);
        }
        fixDims() {
          const {
            style: n
          } = this.div, {
            height: c,
            width: l
          } = n, b = l.endsWith("%"), s = !this.#n && c.endsWith("%");
          if (b && s)
            return;
          const [g, t] = this.parentDimensions;
          b || (n.width = `${(100 * parseFloat(l) / g).toFixed(2)}%`), !this.#n && !s && (n.height = `${(100 * parseFloat(c) / t).toFixed(2)}%`);
        }
        getInitialTranslation() {
          return [0, 0];
        }
        #y() {
          if (this.#r)
            return;
          this.#r = document.createElement("div"), this.#r.classList.add("resizers");
          const n = this._willKeepAspectRatio ? ["topLeft", "topRight", "bottomRight", "bottomLeft"] : ["topLeft", "topMiddle", "topRight", "middleRight", "bottomRight", "bottomMiddle", "bottomLeft", "middleLeft"];
          for (const c of n) {
            const l = document.createElement("div");
            this.#r.append(l), l.classList.add("resizer", c), l.setAttribute("data-resizer-name", c), l.addEventListener("pointerdown", this.#b.bind(this, c)), l.addEventListener("contextmenu", _.noContextMenu), l.tabIndex = -1;
          }
          this.div.prepend(this.#r);
        }
        #b(n, c) {
          c.preventDefault();
          const {
            isMac: l
          } = B.FeatureTest.platform;
          if (c.button !== 0 || c.ctrlKey && l)
            return;
          this.#e?.toggle(!1);
          const b = this.#x.bind(this, n), s = this._isDraggable;
          this._isDraggable = !1;
          const g = {
            passive: !0,
            capture: !0
          };
          this.parent.togglePointerEvents(!1), window.addEventListener("pointermove", b, g), window.addEventListener("contextmenu", _.noContextMenu);
          const t = this.x, i = this.y, d = this.width, f = this.height, y = this.parent.div.style.cursor, S = this.div.style.cursor;
          this.div.style.cursor = this.parent.div.style.cursor = window.getComputedStyle(c.target).cursor;
          const L = () => {
            this.parent.togglePointerEvents(!0), this.#e?.toggle(!0), this._isDraggable = s, window.removeEventListener("pointerup", L), window.removeEventListener("blur", L), window.removeEventListener("pointermove", b, g), window.removeEventListener("contextmenu", _.noContextMenu), this.parent.div.style.cursor = y, this.div.style.cursor = S, this.#S(t, i, d, f);
          };
          window.addEventListener("pointerup", L), window.addEventListener("blur", L);
        }
        #S(n, c, l, b) {
          const s = this.x, g = this.y, t = this.width, i = this.height;
          s === n && g === c && t === l && i === b || this.addCommands({
            cmd: () => {
              this.width = t, this.height = i, this.x = s, this.y = g;
              const [d, f] = this.parentDimensions;
              this.setDims(d * t, f * i), this.fixAndSetPosition();
            },
            undo: () => {
              this.width = l, this.height = b, this.x = n, this.y = c;
              const [d, f] = this.parentDimensions;
              this.setDims(d * l, f * b), this.fixAndSetPosition();
            },
            mustExec: !0
          });
        }
        #x(n, c) {
          const [l, b] = this.parentDimensions, s = this.x, g = this.y, t = this.width, i = this.height, d = T.MIN_SIZE / l, f = T.MIN_SIZE / b, y = (m) => Math.round(m * 1e4) / 1e4, S = this.#L(this.rotation), L = (m, h) => [S[0] * m + S[2] * h, S[1] * m + S[3] * h], M = this.#L(360 - this.rotation), N = (m, h) => [M[0] * m + M[2] * h, M[1] * m + M[3] * h];
          let H, z, q = !1, nt = !1;
          switch (n) {
            case "topLeft":
              q = !0, H = (m, h) => [0, 0], z = (m, h) => [m, h];
              break;
            case "topMiddle":
              H = (m, h) => [m / 2, 0], z = (m, h) => [m / 2, h];
              break;
            case "topRight":
              q = !0, H = (m, h) => [m, 0], z = (m, h) => [0, h];
              break;
            case "middleRight":
              nt = !0, H = (m, h) => [m, h / 2], z = (m, h) => [0, h / 2];
              break;
            case "bottomRight":
              q = !0, H = (m, h) => [m, h], z = (m, h) => [0, 0];
              break;
            case "bottomMiddle":
              H = (m, h) => [m / 2, h], z = (m, h) => [m / 2, 0];
              break;
            case "bottomLeft":
              q = !0, H = (m, h) => [0, h], z = (m, h) => [m, 0];
              break;
            case "middleLeft":
              nt = !0, H = (m, h) => [0, h / 2], z = (m, h) => [m, h / 2];
              break;
          }
          const j = H(t, i), O = z(t, i);
          let G = L(...O);
          const Y = y(s + G[0]), tt = y(g + G[1]);
          let Z = 1, at = 1, [lt, pt] = this.screenToPageTranslation(c.movementX, c.movementY);
          if ([lt, pt] = N(lt / l, pt / b), q) {
            const m = Math.hypot(t, i);
            Z = at = Math.max(Math.min(Math.hypot(O[0] - j[0] - lt, O[1] - j[1] - pt) / m, 1 / t, 1 / i), d / t, f / i);
          } else nt ? Z = Math.max(d, Math.min(1, Math.abs(O[0] - j[0] - lt))) / t : at = Math.max(f, Math.min(1, Math.abs(O[1] - j[1] - pt))) / i;
          const dt = y(t * Z), ot = y(i * at);
          G = L(...z(dt, ot));
          const ut = Y - G[0], et = tt - G[1];
          this.width = dt, this.height = ot, this.x = ut, this.y = et, this.setDims(l * dt, b * ot), this.fixAndSetPosition();
        }
        altTextFinish() {
          this.#e?.finish();
        }
        async addEditToolbar() {
          return this.#h || this.#p ? this.#h : (this.#h = new P.EditorToolbar(this), this.div.append(this.#h.render()), this.#e && this.#h.addAltTextButton(await this.#e.render()), this.#h);
        }
        removeEditToolbar() {
          this.#h && (this.#h.remove(), this.#h = null, this.#e?.destroy());
        }
        getClientDimensions() {
          return this.div.getBoundingClientRect();
        }
        async addAltTextButton() {
          this.#e || (U.initialize(T._l10nPromise), this.#e = new U(this), await this.addEditToolbar());
        }
        get altTextData() {
          return this.#e?.data;
        }
        set altTextData(n) {
          this.#e && (this.#e.data = n);
        }
        hasAltText() {
          return !this.#e?.isEmpty();
        }
        render() {
          this.div = document.createElement("div"), this.div.setAttribute("data-editor-rotation", (360 - this.rotation) % 360), this.div.className = this.name, this.div.setAttribute("id", this.id), this.div.tabIndex = this.#s ? -1 : 0, this._isVisible || this.div.classList.add("hidden"), this.setInForeground(), this.div.addEventListener("focusin", this.#a), this.div.addEventListener("focusout", this.#l);
          const [n, c] = this.parentDimensions;
          this.parentRotation % 180 !== 0 && (this.div.style.maxWidth = `${(100 * c / n).toFixed(2)}%`, this.div.style.maxHeight = `${(100 * n / c).toFixed(2)}%`);
          const [l, b] = this.getInitialTranslation();
          return this.translate(l, b), (0, w.bindEvents)(this, this.div, ["pointerdown"]), this.div;
        }
        pointerdown(n) {
          const {
            isMac: c
          } = B.FeatureTest.platform;
          if (n.button !== 0 || n.ctrlKey && c) {
            n.preventDefault();
            return;
          }
          if (this.#u = !0, this._isDraggable) {
            this.#T(n);
            return;
          }
          this.#R(n);
        }
        #R(n) {
          const {
            isMac: c
          } = B.FeatureTest.platform;
          n.ctrlKey && !c || n.shiftKey || n.metaKey && c ? this.parent.toggleSelected(this) : this.parent.setSelected(this);
        }
        #T(n) {
          const c = this._uiManager.isSelected(this);
          this._uiManager.setUpDragSession();
          let l, b;
          c && (this.div.classList.add("moving"), l = {
            passive: !0,
            capture: !0
          }, this.#A = n.clientX, this.#m = n.clientY, b = (g) => {
            const {
              clientX: t,
              clientY: i
            } = g, [d, f] = this.screenToPageTranslation(t - this.#A, i - this.#m);
            this.#A = t, this.#m = i, this._uiManager.dragSelectedEditors(d, f);
          }, window.addEventListener("pointermove", b, l));
          const s = () => {
            window.removeEventListener("pointerup", s), window.removeEventListener("blur", s), c && (this.div.classList.remove("moving"), window.removeEventListener("pointermove", b, l)), this.#u = !1, this._uiManager.endDragSession() || this.#R(n);
          };
          window.addEventListener("pointerup", s), window.addEventListener("blur", s);
        }
        moveInDOM() {
          this.#f && clearTimeout(this.#f), this.#f = setTimeout(() => {
            this.#f = null, this.parent?.moveEditorInDOM(this);
          }, 0);
        }
        _setParentAndPosition(n, c, l) {
          n.changeParent(this), this.x = c, this.y = l, this.fixAndSetPosition();
        }
        getRect(n, c, l = this.rotation) {
          const b = this.parentScale, [s, g] = this.pageDimensions, [t, i] = this.pageTranslation, d = n / b, f = c / b, y = this.x * s, S = this.y * g, L = this.width * s, M = this.height * g;
          switch (l) {
            case 0:
              return [y + d + t, g - S - f - M + i, y + d + L + t, g - S - f + i];
            case 90:
              return [y + f + t, g - S + d + i, y + f + M + t, g - S + d + L + i];
            case 180:
              return [y - d - L + t, g - S + f + i, y - d + t, g - S + f + M + i];
            case 270:
              return [y - f - M + t, g - S - d - L + i, y - f + t, g - S - d + i];
            default:
              throw new Error("Invalid rotation");
          }
        }
        getRectInCurrentCoords(n, c) {
          const [l, b, s, g] = n, t = s - l, i = g - b;
          switch (this.rotation) {
            case 0:
              return [l, c - g, t, i];
            case 90:
              return [l, c - b, i, t];
            case 180:
              return [s, c - b, t, i];
            case 270:
              return [s, c - g, i, t];
            default:
              throw new Error("Invalid rotation");
          }
        }
        onceAdded() {
        }
        isEmpty() {
          return !1;
        }
        enableEditMode() {
          this.#p = !0;
        }
        disableEditMode() {
          this.#p = !1;
        }
        isInEditMode() {
          return this.#p;
        }
        shouldGetKeyboardEvents() {
          return this.#g;
        }
        needsToBeRebuilt() {
          return this.div && !this.isAttachedToDOM;
        }
        rebuild() {
          this.div?.addEventListener("focusin", this.#a), this.div?.addEventListener("focusout", this.#l);
        }
        rotate(n) {
        }
        serialize(n = !1, c = null) {
          (0, B.unreachable)("An editor must be serializable");
        }
        static deserialize(n, c, l) {
          const b = new this.prototype.constructor({
            parent: c,
            id: c.getNextId(),
            uiManager: l
          });
          b.rotation = n.rotation;
          const [s, g] = b.pageDimensions, [t, i, d, f] = b.getRectInCurrentCoords(n.rect, g);
          return b.x = t / s, b.y = i / g, b.width = d / s, b.height = f / g, b;
        }
        get hasBeenModified() {
          return !!this.annotationElementId && (this.deleted || this.serialize() !== null);
        }
        remove() {
          if (this.div.removeEventListener("focusin", this.#a), this.div.removeEventListener("focusout", this.#l), this.isEmpty() || this.commit(), this.parent ? this.parent.remove(this) : this._uiManager.removeEditor(this), this.#f && (clearTimeout(this.#f), this.#f = null), this.#D(), this.removeEditToolbar(), this.#v) {
            for (const n of this.#v.values())
              clearTimeout(n);
            this.#v = null;
          }
          this.parent = null;
        }
        get isResizable() {
          return !1;
        }
        makeResizable() {
          this.isResizable && (this.#y(), this.#r.classList.remove("hidden"), (0, w.bindEvents)(this, this.div, ["keydown"]));
        }
        get toolbarPosition() {
          return null;
        }
        keydown(n) {
          if (!this.isResizable || n.target !== this.div || n.key !== "Enter")
            return;
          this._uiManager.setSelected(this), this.#i = {
            savedX: this.x,
            savedY: this.y,
            savedWidth: this.width,
            savedHeight: this.height
          };
          const c = this.#r.children;
          if (!this.#t) {
            this.#t = Array.from(c);
            const g = this.#M.bind(this), t = this.#F.bind(this);
            for (const i of this.#t) {
              const d = i.getAttribute("data-resizer-name");
              i.setAttribute("role", "spinbutton"), i.addEventListener("keydown", g), i.addEventListener("blur", t), i.addEventListener("focus", this.#_.bind(this, d)), T._l10nPromise.get(`pdfjs-editor-resizer-label-${d}`).then((f) => i.setAttribute("aria-label", f));
            }
          }
          const l = this.#t[0];
          let b = 0;
          for (const g of c) {
            if (g === l)
              break;
            b++;
          }
          const s = (360 - this.rotation + this.parentRotation) % 360 / 90 * (this.#t.length / 4);
          if (s !== b) {
            if (s < b)
              for (let t = 0; t < b - s; t++)
                this.#r.append(this.#r.firstChild);
            else if (s > b)
              for (let t = 0; t < s - b; t++)
                this.#r.firstChild.before(this.#r.lastChild);
            let g = 0;
            for (const t of c) {
              const d = this.#t[g++].getAttribute("data-resizer-name");
              T._l10nPromise.get(`pdfjs-editor-resizer-label-${d}`).then((f) => t.setAttribute("aria-label", f));
            }
          }
          this.#P(0), this.#g = !0, this.#r.firstChild.focus({
            focusVisible: !0
          }), n.preventDefault(), n.stopImmediatePropagation();
        }
        #M(n) {
          T._resizerKeyboardManager.exec(this, n);
        }
        #F(n) {
          this.#g && n.relatedTarget?.parentNode !== this.#r && this.#D();
        }
        #_(n) {
          this.#d = this.#g ? n : "";
        }
        #P(n) {
          if (this.#t)
            for (const c of this.#t)
              c.tabIndex = n;
        }
        _resizeWithKeyboard(n, c) {
          this.#g && this.#x(this.#d, {
            movementX: n,
            movementY: c
          });
        }
        #D() {
          if (this.#g = !1, this.#P(-1), this.#i) {
            const {
              savedX: n,
              savedY: c,
              savedWidth: l,
              savedHeight: b
            } = this.#i;
            this.#S(n, c, l, b), this.#i = null;
          }
        }
        _stopResizingWithKeyboard() {
          this.#D(), this.div.focus();
        }
        select() {
          if (this.makeResizable(), this.div?.classList.add("selectedEditor"), !this.#h) {
            this.addEditToolbar().then(() => {
              this.div?.classList.contains("selectedEditor") && this.#h?.show();
            });
            return;
          }
          this.#h?.show();
        }
        unselect() {
          this.#r?.classList.add("hidden"), this.div?.classList.remove("selectedEditor"), this.div?.contains(document.activeElement) && this._uiManager.currentLayer.div.focus({
            preventScroll: !0
          }), this.#h?.hide();
        }
        updateParams(n, c) {
        }
        disableEditing() {
        }
        enableEditing() {
        }
        enterInEditMode() {
        }
        getImageForAltText() {
          return null;
        }
        get contentDiv() {
          return this.div;
        }
        get isEditing() {
          return this.#o;
        }
        set isEditing(n) {
          this.#o = n, this.parent && (n ? (this.parent.setSelected(this), this.parent.setActiveEditor(this)) : this.parent.setActiveEditor(null));
        }
        setAspectRatio(n, c) {
          this.#n = !0;
          const l = n / c, {
            style: b
          } = this.div;
          b.aspectRatio = l, b.height = "auto";
        }
        static get MIN_SIZE() {
          return 16;
        }
        static canCreateNewEmptyEditor() {
          return !0;
        }
        get telemetryInitialData() {
          return {
            action: "added"
          };
        }
        get telemetryFinalData() {
          return null;
        }
        _reportTelemetry(n, c = !1) {
          if (c) {
            this.#v ||= /* @__PURE__ */ new Map();
            const {
              action: l
            } = n;
            let b = this.#v.get(l);
            b && clearTimeout(b), b = setTimeout(() => {
              this._reportTelemetry(n), this.#v.delete(l), this.#v.size === 0 && (this.#v = null);
            }, T._telemetryTimeout), this.#v.set(l, b);
            return;
          }
          n.type ||= this.editorType, this._uiManager._eventBus.dispatch("reporttelemetry", {
            source: this,
            details: {
              type: "editing",
              data: n
            }
          });
        }
        show(n = this._isVisible) {
          this.div.classList.toggle("hidden", !n), this._isVisible = n;
        }
        enable() {
          this.div && (this.div.tabIndex = 0), this.#s = !1;
        }
        disable() {
          this.div && (this.div.tabIndex = -1), this.#s = !0;
        }
        renderAnnotationElement(n) {
          let c = n.container.querySelector(".annotationContent");
          if (!c)
            c = document.createElement("div"), c.classList.add("annotationContent", this.editorType), n.container.prepend(c);
          else if (c.nodeName === "CANVAS") {
            const l = c;
            c = document.createElement("div"), c.classList.add("annotationContent", this.editorType), l.before(c);
          }
          return c;
        }
        resetAnnotationElement(n) {
          const {
            firstChild: c
          } = n.container;
          c.nodeName === "DIV" && c.classList.contains("annotationContent") && c.remove();
        }
      }
      class E extends T {
        constructor(n) {
          super(n), this.annotationElementId = n.annotationElementId, this.deleted = !0;
        }
        serialize() {
          return {
            id: this.annotationElementId,
            deleted: !0,
            pageIndex: this.pageIndex
          };
        }
      }
    })
  ),
  /***/
  61: (
    /***/
    ((ct, st, V) => {
      V.d(st, {
        /* harmony export */
        FreeOutliner: () => (
          /* binding */
          P
        ),
        /* harmony export */
        Outliner: () => (
          /* binding */
          B
        )
        /* harmony export */
      });
      var w = V(292);
      class B {
        #t;
        #e = [];
        #s = [];
        constructor(v, n = 0, c = 0, l = !0) {
          let b = 1 / 0, s = -1 / 0, g = 1 / 0, t = -1 / 0;
          const i = 10 ** -4;
          for (const {
            x: N,
            y: H,
            width: z,
            height: q
          } of v) {
            const nt = Math.floor((N - n) / i) * i, j = Math.ceil((N + z + n) / i) * i, O = Math.floor((H - n) / i) * i, G = Math.ceil((H + q + n) / i) * i, Y = [nt, O, G, !0], tt = [j, O, G, !1];
            this.#e.push(Y, tt), b = Math.min(b, nt), s = Math.max(s, j), g = Math.min(g, O), t = Math.max(t, G);
          }
          const d = s - b + 2 * c, f = t - g + 2 * c, y = b - c, S = g - c, L = this.#e.at(l ? -1 : -2), M = [L[0], L[2]];
          for (const N of this.#e) {
            const [H, z, q] = N;
            N[0] = (H - y) / d, N[1] = (z - S) / f, N[2] = (q - S) / f;
          }
          this.#t = {
            x: y,
            y: S,
            width: d,
            height: f,
            lastPoint: M
          };
        }
        getOutlines() {
          this.#e.sort((n, c) => n[0] - c[0] || n[1] - c[1] || n[2] - c[2]);
          const v = [];
          for (const n of this.#e)
            n[3] ? (v.push(...this.#l(n)), this.#i(n)) : (this.#a(n), v.push(...this.#l(n)));
          return this.#n(v);
        }
        #n(v) {
          const n = [], c = /* @__PURE__ */ new Set();
          for (const s of v) {
            const [g, t, i] = s;
            n.push([g, t, s], [g, i, s]);
          }
          n.sort((s, g) => s[1] - g[1] || s[0] - g[0]);
          for (let s = 0, g = n.length; s < g; s += 2) {
            const t = n[s][2], i = n[s + 1][2];
            t.push(i), i.push(t), c.add(t), c.add(i);
          }
          const l = [];
          let b;
          for (; c.size > 0; ) {
            const s = c.values().next().value;
            let [g, t, i, d, f] = s;
            c.delete(s);
            let y = g, S = t;
            for (b = [g, i], l.push(b); ; ) {
              let L;
              if (c.has(d))
                L = d;
              else if (c.has(f))
                L = f;
              else
                break;
              c.delete(L), [g, t, i, d, f] = L, y !== g && (b.push(y, S, g, S === t ? t : i), y = g), S = S === t ? i : t;
            }
            b.push(y, S);
          }
          return new U(l, this.#t);
        }
        #r(v) {
          const n = this.#s;
          let c = 0, l = n.length - 1;
          for (; c <= l; ) {
            const b = c + l >> 1, s = n[b][0];
            if (s === v)
              return b;
            s < v ? c = b + 1 : l = b - 1;
          }
          return l + 1;
        }
        #i([, v, n]) {
          const c = this.#r(v);
          this.#s.splice(c, 0, [v, n]);
        }
        #a([, v, n]) {
          const c = this.#r(v);
          for (let l = c; l < this.#s.length; l++) {
            const [b, s] = this.#s[l];
            if (b !== v)
              break;
            if (b === v && s === n) {
              this.#s.splice(l, 1);
              return;
            }
          }
          for (let l = c - 1; l >= 0; l--) {
            const [b, s] = this.#s[l];
            if (b !== v)
              break;
            if (b === v && s === n) {
              this.#s.splice(l, 1);
              return;
            }
          }
        }
        #l(v) {
          const [n, c, l] = v, b = [[n, c, l]], s = this.#r(l);
          for (let g = 0; g < s; g++) {
            const [t, i] = this.#s[g];
            for (let d = 0, f = b.length; d < f; d++) {
              const [, y, S] = b[d];
              if (!(i <= y || S <= t)) {
                if (y >= t) {
                  if (S > i)
                    b[d][1] = i;
                  else {
                    if (f === 1)
                      return [];
                    b.splice(d, 1), d--, f--;
                  }
                  continue;
                }
                b[d][2] = t, S > i && b.push([n, i, S]);
              }
            }
          }
          return b;
        }
      }
      class _ {
        toSVGPath() {
          throw new Error("Abstract method `toSVGPath` must be implemented.");
        }
        get box() {
          throw new Error("Abstract getter `box` must be implemented.");
        }
        serialize(v, n) {
          throw new Error("Abstract method `serialize` must be implemented.");
        }
        get free() {
          return this instanceof T;
        }
      }
      class U extends _ {
        #t;
        #e;
        constructor(v, n) {
          super(), this.#e = v, this.#t = n;
        }
        toSVGPath() {
          const v = [];
          for (const n of this.#e) {
            let [c, l] = n;
            v.push(`M${c} ${l}`);
            for (let b = 2; b < n.length; b += 2) {
              const s = n[b], g = n[b + 1];
              s === c ? (v.push(`V${g}`), l = g) : g === l && (v.push(`H${s}`), c = s);
            }
            v.push("Z");
          }
          return v.join(" ");
        }
        serialize([v, n, c, l], b) {
          const s = [], g = c - v, t = l - n;
          for (const i of this.#e) {
            const d = new Array(i.length);
            for (let f = 0; f < i.length; f += 2)
              d[f] = v + i[f] * g, d[f + 1] = l - i[f + 1] * t;
            s.push(d);
          }
          return s;
        }
        get box() {
          return this.#t;
        }
      }
      class P {
        #t;
        #e = [];
        #s;
        #n;
        #r = [];
        #i = new Float64Array(18);
        #a;
        #l;
        #h;
        #d;
        #u;
        #c;
        #o = [];
        static #p = 8;
        static #g = 2;
        static #f = P.#p + P.#g;
        constructor({
          x: v,
          y: n
        }, c, l, b, s, g = 0) {
          this.#t = c, this.#c = b * l, this.#n = s, this.#i.set([NaN, NaN, NaN, NaN, v, n], 6), this.#s = g, this.#d = P.#p * l, this.#h = P.#f * l, this.#u = l, this.#o.push(v, n);
        }
        get free() {
          return !0;
        }
        isEmpty() {
          return isNaN(this.#i[8]);
        }
        #A() {
          const v = this.#i.subarray(4, 6), n = this.#i.subarray(16, 18), [c, l, b, s] = this.#t;
          return [(this.#a + (v[0] - n[0]) / 2 - c) / b, (this.#l + (v[1] - n[1]) / 2 - l) / s, (this.#a + (n[0] - v[0]) / 2 - c) / b, (this.#l + (n[1] - v[1]) / 2 - l) / s];
        }
        add({
          x: v,
          y: n
        }) {
          this.#a = v, this.#l = n;
          const [c, l, b, s] = this.#t;
          let [g, t, i, d] = this.#i.subarray(8, 12);
          const f = v - i, y = n - d, S = Math.hypot(f, y);
          if (S < this.#h)
            return !1;
          const L = S - this.#d, M = L / S, N = M * f, H = M * y;
          let z = g, q = t;
          g = i, t = d, i += N, d += H, this.#o?.push(v, n);
          const nt = -H / L, j = N / L, O = nt * this.#c, G = j * this.#c;
          return this.#i.set(this.#i.subarray(2, 8), 0), this.#i.set([i + O, d + G], 4), this.#i.set(this.#i.subarray(14, 18), 12), this.#i.set([i - O, d - G], 16), isNaN(this.#i[6]) ? (this.#r.length === 0 && (this.#i.set([g + O, t + G], 2), this.#r.push(NaN, NaN, NaN, NaN, (g + O - c) / b, (t + G - l) / s), this.#i.set([g - O, t - G], 14), this.#e.push(NaN, NaN, NaN, NaN, (g - O - c) / b, (t - G - l) / s)), this.#i.set([z, q, g, t, i, d], 6), !this.isEmpty()) : (this.#i.set([z, q, g, t, i, d], 6), Math.abs(Math.atan2(q - t, z - g) - Math.atan2(H, N)) < Math.PI / 2 ? ([g, t, i, d] = this.#i.subarray(2, 6), this.#r.push(NaN, NaN, NaN, NaN, ((g + i) / 2 - c) / b, ((t + d) / 2 - l) / s), [g, t, z, q] = this.#i.subarray(14, 18), this.#e.push(NaN, NaN, NaN, NaN, ((z + g) / 2 - c) / b, ((q + t) / 2 - l) / s), !0) : ([z, q, g, t, i, d] = this.#i.subarray(0, 6), this.#r.push(((z + 5 * g) / 6 - c) / b, ((q + 5 * t) / 6 - l) / s, ((5 * g + i) / 6 - c) / b, ((5 * t + d) / 6 - l) / s, ((g + i) / 2 - c) / b, ((t + d) / 2 - l) / s), [i, d, g, t, z, q] = this.#i.subarray(12, 18), this.#e.push(((z + 5 * g) / 6 - c) / b, ((q + 5 * t) / 6 - l) / s, ((5 * g + i) / 6 - c) / b, ((5 * t + d) / 6 - l) / s, ((g + i) / 2 - c) / b, ((t + d) / 2 - l) / s), !0));
        }
        toSVGPath() {
          if (this.isEmpty())
            return "";
          const v = this.#r, n = this.#e, c = this.#i.subarray(4, 6), l = this.#i.subarray(16, 18), [b, s, g, t] = this.#t, [i, d, f, y] = this.#A();
          if (isNaN(this.#i[6]) && !this.isEmpty())
            return `M${(this.#i[2] - b) / g} ${(this.#i[3] - s) / t} L${(this.#i[4] - b) / g} ${(this.#i[5] - s) / t} L${i} ${d} L${f} ${y} L${(this.#i[16] - b) / g} ${(this.#i[17] - s) / t} L${(this.#i[14] - b) / g} ${(this.#i[15] - s) / t} Z`;
          const S = [];
          S.push(`M${v[4]} ${v[5]}`);
          for (let L = 6; L < v.length; L += 6)
            isNaN(v[L]) ? S.push(`L${v[L + 4]} ${v[L + 5]}`) : S.push(`C${v[L]} ${v[L + 1]} ${v[L + 2]} ${v[L + 3]} ${v[L + 4]} ${v[L + 5]}`);
          S.push(`L${(c[0] - b) / g} ${(c[1] - s) / t} L${i} ${d} L${f} ${y} L${(l[0] - b) / g} ${(l[1] - s) / t}`);
          for (let L = n.length - 6; L >= 6; L -= 6)
            isNaN(n[L]) ? S.push(`L${n[L + 4]} ${n[L + 5]}`) : S.push(`C${n[L]} ${n[L + 1]} ${n[L + 2]} ${n[L + 3]} ${n[L + 4]} ${n[L + 5]}`);
          return S.push(`L${n[4]} ${n[5]} Z`), S.join(" ");
        }
        getOutlines() {
          const v = this.#r, n = this.#e, c = this.#i, l = c.subarray(4, 6), b = c.subarray(16, 18), [s, g, t, i] = this.#t, d = new Float64Array((this.#o?.length ?? 0) + 2);
          for (let H = 0, z = d.length - 2; H < z; H += 2)
            d[H] = (this.#o[H] - s) / t, d[H + 1] = (this.#o[H + 1] - g) / i;
          d[d.length - 2] = (this.#a - s) / t, d[d.length - 1] = (this.#l - g) / i;
          const [f, y, S, L] = this.#A();
          if (isNaN(c[6]) && !this.isEmpty()) {
            const H = new Float64Array(36);
            return H.set([NaN, NaN, NaN, NaN, (c[2] - s) / t, (c[3] - g) / i, NaN, NaN, NaN, NaN, (c[4] - s) / t, (c[5] - g) / i, NaN, NaN, NaN, NaN, f, y, NaN, NaN, NaN, NaN, S, L, NaN, NaN, NaN, NaN, (c[16] - s) / t, (c[17] - g) / i, NaN, NaN, NaN, NaN, (c[14] - s) / t, (c[15] - g) / i], 0), new T(H, d, this.#t, this.#u, this.#s, this.#n);
          }
          const M = new Float64Array(this.#r.length + 24 + this.#e.length);
          let N = v.length;
          for (let H = 0; H < N; H += 2) {
            if (isNaN(v[H])) {
              M[H] = M[H + 1] = NaN;
              continue;
            }
            M[H] = v[H], M[H + 1] = v[H + 1];
          }
          M.set([NaN, NaN, NaN, NaN, (l[0] - s) / t, (l[1] - g) / i, NaN, NaN, NaN, NaN, f, y, NaN, NaN, NaN, NaN, S, L, NaN, NaN, NaN, NaN, (b[0] - s) / t, (b[1] - g) / i], N), N += 24;
          for (let H = n.length - 6; H >= 6; H -= 6)
            for (let z = 0; z < 6; z += 2) {
              if (isNaN(n[H + z])) {
                M[N] = M[N + 1] = NaN, N += 2;
                continue;
              }
              M[N] = n[H + z], M[N + 1] = n[H + z + 1], N += 2;
            }
          return M.set([NaN, NaN, NaN, NaN, n[4], n[5]], N), new T(M, d, this.#t, this.#u, this.#s, this.#n);
        }
      }
      class T extends _ {
        #t;
        #e = null;
        #s;
        #n;
        #r;
        #i;
        #a;
        constructor(v, n, c, l, b, s) {
          super(), this.#a = v, this.#r = n, this.#t = c, this.#i = l, this.#s = b, this.#n = s, this.#d(s);
          const {
            x: g,
            y: t,
            width: i,
            height: d
          } = this.#e;
          for (let f = 0, y = v.length; f < y; f += 2)
            v[f] = (v[f] - g) / i, v[f + 1] = (v[f + 1] - t) / d;
          for (let f = 0, y = n.length; f < y; f += 2)
            n[f] = (n[f] - g) / i, n[f + 1] = (n[f + 1] - t) / d;
        }
        toSVGPath() {
          const v = [`M${this.#a[4]} ${this.#a[5]}`];
          for (let n = 6, c = this.#a.length; n < c; n += 6) {
            if (isNaN(this.#a[n])) {
              v.push(`L${this.#a[n + 4]} ${this.#a[n + 5]}`);
              continue;
            }
            v.push(`C${this.#a[n]} ${this.#a[n + 1]} ${this.#a[n + 2]} ${this.#a[n + 3]} ${this.#a[n + 4]} ${this.#a[n + 5]}`);
          }
          return v.push("Z"), v.join(" ");
        }
        serialize([v, n, c, l], b) {
          const s = c - v, g = l - n;
          let t, i;
          switch (b) {
            case 0:
              t = this.#l(this.#a, v, l, s, -g), i = this.#l(this.#r, v, l, s, -g);
              break;
            case 90:
              t = this.#h(this.#a, v, n, s, g), i = this.#h(this.#r, v, n, s, g);
              break;
            case 180:
              t = this.#l(this.#a, c, n, -s, g), i = this.#l(this.#r, c, n, -s, g);
              break;
            case 270:
              t = this.#h(this.#a, c, l, -s, -g), i = this.#h(this.#r, c, l, -s, -g);
              break;
          }
          return {
            outline: Array.from(t),
            points: [Array.from(i)]
          };
        }
        #l(v, n, c, l, b) {
          const s = new Float64Array(v.length);
          for (let g = 0, t = v.length; g < t; g += 2)
            s[g] = n + v[g] * l, s[g + 1] = c + v[g + 1] * b;
          return s;
        }
        #h(v, n, c, l, b) {
          const s = new Float64Array(v.length);
          for (let g = 0, t = v.length; g < t; g += 2)
            s[g] = n + v[g + 1] * l, s[g + 1] = c + v[g] * b;
          return s;
        }
        #d(v) {
          const n = this.#a;
          let c = n[4], l = n[5], b = c, s = l, g = c, t = l, i = c, d = l;
          const f = v ? Math.max : Math.min;
          for (let N = 6, H = n.length; N < H; N += 6) {
            if (isNaN(n[N]))
              b = Math.min(b, n[N + 4]), s = Math.min(s, n[N + 5]), g = Math.max(g, n[N + 4]), t = Math.max(t, n[N + 5]), d < n[N + 5] ? (i = n[N + 4], d = n[N + 5]) : d === n[N + 5] && (i = f(i, n[N + 4]));
            else {
              const z = w.Util.bezierBoundingBox(c, l, ...n.slice(N, N + 6));
              b = Math.min(b, z[0]), s = Math.min(s, z[1]), g = Math.max(g, z[2]), t = Math.max(t, z[3]), d < z[3] ? (i = z[2], d = z[3]) : d === z[3] && (i = f(i, z[2]));
            }
            c = n[N + 4], l = n[N + 5];
          }
          const y = b - this.#s, S = s - this.#s, L = g - b + 2 * this.#s, M = t - s + 2 * this.#s;
          this.#e = {
            x: y,
            y: S,
            width: L,
            height: M,
            lastPoint: [i, d]
          };
        }
        get box() {
          return this.#e;
        }
        getNewOutline(v, n) {
          const {
            x: c,
            y: l,
            width: b,
            height: s
          } = this.#e, [g, t, i, d] = this.#t, f = b * i, y = s * d, S = c * i + g, L = l * d + t, M = new P({
            x: this.#r[0] * f + S,
            y: this.#r[1] * y + L
          }, this.#t, this.#i, v, this.#n, n ?? this.#s);
          for (let N = 2; N < this.#r.length; N += 2)
            M.add({
              x: this.#r[N] * f + S,
              y: this.#r[N + 1] * y + L
            });
          return M.getOutlines();
        }
      }
    })
  ),
  /***/
  362: (
    /***/
    ((ct, st, V) => {
      V.d(st, {
        /* harmony export */
        EditorToolbar: () => (
          /* binding */
          B
        ),
        /* harmony export */
        HighlightToolbar: () => (
          /* binding */
          _
        )
        /* harmony export */
      });
      var w = V(419);
      class B {
        #t = null;
        #e = null;
        #s;
        #n = null;
        constructor(P) {
          this.#s = P;
        }
        render() {
          const P = this.#t = document.createElement("div");
          P.className = "editToolbar", P.setAttribute("role", "toolbar"), P.addEventListener("contextmenu", w.noContextMenu), P.addEventListener("pointerdown", B.#r);
          const T = this.#n = document.createElement("div");
          T.className = "buttons", P.append(T);
          const E = this.#s.toolbarPosition;
          if (E) {
            const {
              style: v
            } = P, n = this.#s._uiManager.direction === "ltr" ? 1 - E[0] : E[0];
            v.insetInlineEnd = `${100 * n}%`, v.top = `calc(${100 * E[1]}% + var(--editor-toolbar-vert-offset))`;
          }
          return this.#h(), P;
        }
        static #r(P) {
          P.stopPropagation();
        }
        #i(P) {
          this.#s._focusEventsAllowed = !1, P.preventDefault(), P.stopPropagation();
        }
        #a(P) {
          this.#s._focusEventsAllowed = !0, P.preventDefault(), P.stopPropagation();
        }
        #l(P) {
          P.addEventListener("focusin", this.#i.bind(this), {
            capture: !0
          }), P.addEventListener("focusout", this.#a.bind(this), {
            capture: !0
          }), P.addEventListener("contextmenu", w.noContextMenu);
        }
        hide() {
          this.#t.classList.add("hidden"), this.#e?.hideDropdown();
        }
        show() {
          this.#t.classList.remove("hidden");
        }
        #h() {
          const P = document.createElement("button");
          P.className = "delete", P.tabIndex = 0, P.setAttribute("data-l10n-id", `pdfjs-editor-remove-${this.#s.editorType}-button`), this.#l(P), P.addEventListener("click", (T) => {
            this.#s._uiManager.delete();
          }), this.#n.append(P);
        }
        get #d() {
          const P = document.createElement("div");
          return P.className = "divider", P;
        }
        addAltTextButton(P) {
          this.#l(P), this.#n.prepend(P, this.#d);
        }
        addColorPicker(P) {
          this.#e = P;
          const T = P.renderButton();
          this.#l(T), this.#n.prepend(T, this.#d);
        }
        remove() {
          this.#t.remove(), this.#e?.destroy(), this.#e = null;
        }
      }
      class _ {
        #t = null;
        #e = null;
        #s;
        constructor(P) {
          this.#s = P;
        }
        #n() {
          const P = this.#e = document.createElement("div");
          P.className = "editToolbar", P.setAttribute("role", "toolbar"), P.addEventListener("contextmenu", w.noContextMenu);
          const T = this.#t = document.createElement("div");
          return T.className = "buttons", P.append(T), this.#i(), P;
        }
        #r(P, T) {
          let E = 0, v = 0;
          for (const n of P) {
            const c = n.y + n.height;
            if (c < E)
              continue;
            const l = n.x + (T ? n.width : 0);
            if (c > E) {
              v = l, E = c;
              continue;
            }
            T ? l > v && (v = l) : l < v && (v = l);
          }
          return [T ? 1 - v : v, E];
        }
        show(P, T, E) {
          const [v, n] = this.#r(T, E), {
            style: c
          } = this.#e ||= this.#n();
          P.append(this.#e), c.insetInlineEnd = `${100 * v}%`, c.top = `calc(${100 * n}% + var(--editor-toolbar-vert-offset))`;
        }
        hide() {
          this.#e.remove();
        }
        #i() {
          const P = document.createElement("button");
          P.className = "highlightButton", P.tabIndex = 0, P.setAttribute("data-l10n-id", "pdfjs-highlight-floating-button1");
          const T = document.createElement("span");
          P.append(T), T.className = "visuallyHidden", T.setAttribute("data-l10n-id", "pdfjs-highlight-floating-button-label"), P.addEventListener("contextmenu", w.noContextMenu), P.addEventListener("click", () => {
            this.#s.highlightSelection("floating_button");
          }), this.#t.append(P);
        }
      }
    })
  ),
  /***/
  830: (
    /***/
    ((ct, st, V) => {
      V.d(st, {
        /* harmony export */
        AnnotationEditorUIManager: () => (
          /* binding */
          l
        ),
        /* harmony export */
        ColorManager: () => (
          /* binding */
          c
        ),
        /* harmony export */
        KeyboardManager: () => (
          /* binding */
          n
        ),
        /* harmony export */
        bindEvents: () => (
          /* binding */
          U
        ),
        /* harmony export */
        opacityToHex: () => (
          /* binding */
          P
        )
        /* harmony export */
      });
      var w = V(292), B = V(419), _ = V(362);
      function U(b, s, g) {
        for (const t of g)
          s.addEventListener(t, b[t].bind(b));
      }
      function P(b) {
        return Math.round(Math.min(255, Math.max(1, 255 * b))).toString(16).padStart(2, "0");
      }
      class T {
        #t = 0;
        constructor() {
        }
        get id() {
          return `${w.AnnotationEditorPrefix}${this.#t++}`;
        }
      }
      class E {
        #t = (0, w.getUuid)();
        #e = 0;
        #s = null;
        static get _isSVGFittingCanvas() {
          const s = 'data:image/svg+xml;charset=UTF-8,<svg viewBox="0 0 1 1" width="1" height="1" xmlns="http://www.w3.org/2000/svg"><rect width="1" height="1" style="fill:red;"/></svg>', t = new OffscreenCanvas(1, 3).getContext("2d"), i = new Image();
          i.src = s;
          const d = i.decode().then(() => (t.drawImage(i, 0, 0, 1, 1, 0, 0, 1, 3), new Uint32Array(t.getImageData(0, 0, 1, 1).data.buffer)[0] === 0));
          return (0, w.shadow)(this, "_isSVGFittingCanvas", d);
        }
        async #n(s, g) {
          this.#s ||= /* @__PURE__ */ new Map();
          let t = this.#s.get(s);
          if (t === null)
            return null;
          if (t?.bitmap)
            return t.refCounter += 1, t;
          try {
            t ||= {
              bitmap: null,
              id: `image_${this.#t}_${this.#e++}`,
              refCounter: 0,
              isSvg: !1
            };
            let i;
            if (typeof g == "string" ? (t.url = g, i = await (0, B.fetchData)(g, "blob")) : i = t.file = g, i.type === "image/svg+xml") {
              const d = E._isSVGFittingCanvas, f = new FileReader(), y = new Image(), S = new Promise((L, M) => {
                y.onload = () => {
                  t.bitmap = y, t.isSvg = !0, L();
                }, f.onload = async () => {
                  const N = t.svgUrl = f.result;
                  y.src = await d ? `${N}#svgView(preserveAspectRatio(none))` : N;
                }, y.onerror = f.onerror = M;
              });
              f.readAsDataURL(i), await S;
            } else
              t.bitmap = await createImageBitmap(i);
            t.refCounter = 1;
          } catch (i) {
            console.error(i), t = null;
          }
          return this.#s.set(s, t), t && this.#s.set(t.id, t), t;
        }
        async getFromFile(s) {
          const {
            lastModified: g,
            name: t,
            size: i,
            type: d
          } = s;
          return this.#n(`${g}_${t}_${i}_${d}`, s);
        }
        async getFromUrl(s) {
          return this.#n(s, s);
        }
        async getFromId(s) {
          this.#s ||= /* @__PURE__ */ new Map();
          const g = this.#s.get(s);
          return g ? g.bitmap ? (g.refCounter += 1, g) : g.file ? this.getFromFile(g.file) : this.getFromUrl(g.url) : null;
        }
        getSvgUrl(s) {
          const g = this.#s.get(s);
          return g?.isSvg ? g.svgUrl : null;
        }
        deleteId(s) {
          this.#s ||= /* @__PURE__ */ new Map();
          const g = this.#s.get(s);
          g && (g.refCounter -= 1, g.refCounter === 0 && (g.bitmap = null));
        }
        isValidId(s) {
          return s.startsWith(`image_${this.#t}_`);
        }
      }
      class v {
        #t = [];
        #e = !1;
        #s;
        #n = -1;
        constructor(s = 128) {
          this.#s = s;
        }
        add({
          cmd: s,
          undo: g,
          post: t,
          mustExec: i,
          type: d = NaN,
          overwriteIfSameType: f = !1,
          keepUndo: y = !1
        }) {
          if (i && s(), this.#e)
            return;
          const S = {
            cmd: s,
            undo: g,
            post: t,
            type: d
          };
          if (this.#n === -1) {
            this.#t.length > 0 && (this.#t.length = 0), this.#n = 0, this.#t.push(S);
            return;
          }
          if (f && this.#t[this.#n].type === d) {
            y && (S.undo = this.#t[this.#n].undo), this.#t[this.#n] = S;
            return;
          }
          const L = this.#n + 1;
          L === this.#s ? this.#t.splice(0, 1) : (this.#n = L, L < this.#t.length && this.#t.splice(L)), this.#t.push(S);
        }
        undo() {
          if (this.#n === -1)
            return;
          this.#e = !0;
          const {
            undo: s,
            post: g
          } = this.#t[this.#n];
          s(), g?.(), this.#e = !1, this.#n -= 1;
        }
        redo() {
          if (this.#n < this.#t.length - 1) {
            this.#n += 1, this.#e = !0;
            const {
              cmd: s,
              post: g
            } = this.#t[this.#n];
            s(), g?.(), this.#e = !1;
          }
        }
        hasSomethingToUndo() {
          return this.#n !== -1;
        }
        hasSomethingToRedo() {
          return this.#n < this.#t.length - 1;
        }
        destroy() {
          this.#t = null;
        }
      }
      class n {
        constructor(s) {
          this.buffer = [], this.callbacks = /* @__PURE__ */ new Map(), this.allKeys = /* @__PURE__ */ new Set();
          const {
            isMac: g
          } = w.FeatureTest.platform;
          for (const [t, i, d = {}] of s)
            for (const f of t) {
              const y = f.startsWith("mac+");
              g && y ? (this.callbacks.set(f.slice(4), {
                callback: i,
                options: d
              }), this.allKeys.add(f.split("+").at(-1))) : !g && !y && (this.callbacks.set(f, {
                callback: i,
                options: d
              }), this.allKeys.add(f.split("+").at(-1)));
            }
        }
        #t(s) {
          s.altKey && this.buffer.push("alt"), s.ctrlKey && this.buffer.push("ctrl"), s.metaKey && this.buffer.push("meta"), s.shiftKey && this.buffer.push("shift"), this.buffer.push(s.key);
          const g = this.buffer.join("+");
          return this.buffer.length = 0, g;
        }
        exec(s, g) {
          if (!this.allKeys.has(g.key))
            return;
          const t = this.callbacks.get(this.#t(g));
          if (!t)
            return;
          const {
            callback: i,
            options: {
              bubbles: d = !1,
              args: f = [],
              checker: y = null
            }
          } = t;
          y && !y(s, g) || (i.bind(s, ...f, g)(), d || (g.stopPropagation(), g.preventDefault()));
        }
      }
      class c {
        static _colorsMapping = /* @__PURE__ */ new Map([["CanvasText", [0, 0, 0]], ["Canvas", [255, 255, 255]]]);
        get _colors() {
          const s = /* @__PURE__ */ new Map([["CanvasText", null], ["Canvas", null]]);
          return (0, B.getColorValues)(s), (0, w.shadow)(this, "_colors", s);
        }
        convert(s) {
          const g = (0, B.getRGB)(s);
          if (!window.matchMedia("(forced-colors: active)").matches)
            return g;
          for (const [t, i] of this._colors)
            if (i.every((d, f) => d === g[f]))
              return c._colorsMapping.get(t);
          return g;
        }
        getHexCode(s) {
          const g = this._colors.get(s);
          return g ? w.Util.makeHexColor(...g) : s;
        }
      }
      class l {
        #t = null;
        #e = /* @__PURE__ */ new Map();
        #s = /* @__PURE__ */ new Map();
        #n = null;
        #r = null;
        #i = null;
        #a = new v();
        #l = 0;
        #h = /* @__PURE__ */ new Set();
        #d = null;
        #u = null;
        #c = /* @__PURE__ */ new Set();
        #o = !1;
        #p = null;
        #g = null;
        #f = null;
        #A = !1;
        #m = null;
        #v = new T();
        #w = !1;
        #C = !1;
        #k = null;
        #I = null;
        #L = null;
        #y = w.AnnotationEditorType.NONE;
        #b = /* @__PURE__ */ new Set();
        #S = null;
        #x = null;
        #R = null;
        #T = this.blur.bind(this);
        #M = this.focus.bind(this);
        #F = this.copy.bind(this);
        #_ = this.cut.bind(this);
        #P = this.paste.bind(this);
        #D = this.keydown.bind(this);
        #G = this.keyup.bind(this);
        #$ = this.onEditingAction.bind(this);
        #X = this.onPageChanging.bind(this);
        #U = this.onScaleChanging.bind(this);
        #B = this.#rt.bind(this);
        #N = this.onRotationChanging.bind(this);
        #q = {
          isEditing: !1,
          isEmpty: !0,
          hasSomethingToUndo: !1,
          hasSomethingToRedo: !1,
          hasSelectedEditor: !1,
          hasSelectedText: !1
        };
        #V = [0, 0];
        #O = null;
        #z = null;
        #K = null;
        static TRANSLATE_SMALL = 1;
        static TRANSLATE_BIG = 10;
        static get _keyboardManager() {
          const s = l.prototype, g = (f) => f.#z.contains(document.activeElement) && document.activeElement.tagName !== "BUTTON" && f.hasSomethingToControl(), t = (f, {
            target: y
          }) => {
            if (y instanceof HTMLInputElement) {
              const {
                type: S
              } = y;
              return S !== "text" && S !== "number";
            }
            return !0;
          }, i = this.TRANSLATE_SMALL, d = this.TRANSLATE_BIG;
          return (0, w.shadow)(this, "_keyboardManager", new n([[["ctrl+a", "mac+meta+a"], s.selectAll, {
            checker: t
          }], [["ctrl+z", "mac+meta+z"], s.undo, {
            checker: t
          }], [["ctrl+y", "ctrl+shift+z", "mac+meta+shift+z", "ctrl+shift+Z", "mac+meta+shift+Z"], s.redo, {
            checker: t
          }], [["Backspace", "alt+Backspace", "ctrl+Backspace", "shift+Backspace", "mac+Backspace", "mac+alt+Backspace", "mac+ctrl+Backspace", "Delete", "ctrl+Delete", "shift+Delete", "mac+Delete"], s.delete, {
            checker: t
          }], [["Enter", "mac+Enter"], s.addNewEditorFromKeyboard, {
            checker: (f, {
              target: y
            }) => !(y instanceof HTMLButtonElement) && f.#z.contains(y) && !f.isEnterHandled
          }], [[" ", "mac+ "], s.addNewEditorFromKeyboard, {
            checker: (f, {
              target: y
            }) => !(y instanceof HTMLButtonElement) && f.#z.contains(document.activeElement)
          }], [["Escape", "mac+Escape"], s.unselectAll], [["ArrowLeft", "mac+ArrowLeft"], s.translateSelectedEditors, {
            args: [-i, 0],
            checker: g
          }], [["ctrl+ArrowLeft", "mac+shift+ArrowLeft"], s.translateSelectedEditors, {
            args: [-d, 0],
            checker: g
          }], [["ArrowRight", "mac+ArrowRight"], s.translateSelectedEditors, {
            args: [i, 0],
            checker: g
          }], [["ctrl+ArrowRight", "mac+shift+ArrowRight"], s.translateSelectedEditors, {
            args: [d, 0],
            checker: g
          }], [["ArrowUp", "mac+ArrowUp"], s.translateSelectedEditors, {
            args: [0, -i],
            checker: g
          }], [["ctrl+ArrowUp", "mac+shift+ArrowUp"], s.translateSelectedEditors, {
            args: [0, -d],
            checker: g
          }], [["ArrowDown", "mac+ArrowDown"], s.translateSelectedEditors, {
            args: [0, i],
            checker: g
          }], [["ctrl+ArrowDown", "mac+shift+ArrowDown"], s.translateSelectedEditors, {
            args: [0, d],
            checker: g
          }]]));
        }
        constructor(s, g, t, i, d, f, y, S, L) {
          this.#z = s, this.#K = g, this.#n = t, this._eventBus = i, this._eventBus._on("editingaction", this.#$), this._eventBus._on("pagechanging", this.#X), this._eventBus._on("scalechanging", this.#U), this._eventBus._on("rotationchanging", this.#N), this.#at(), this.#J(), this.#r = d.annotationStorage, this.#p = d.filterFactory, this.#x = f, this.#f = y || null, this.#o = S, this.#L = L || null, this.viewParameters = {
            realScale: B.PixelsPerInch.PDF_TO_CSS_UNITS,
            rotation: 0
          }, this.isShiftKeyDown = !1;
        }
        destroy() {
          this.#Z(), this.#Q(), this._eventBus._off("editingaction", this.#$), this._eventBus._off("pagechanging", this.#X), this._eventBus._off("scalechanging", this.#U), this._eventBus._off("rotationchanging", this.#N);
          for (const s of this.#s.values())
            s.destroy();
          this.#s.clear(), this.#e.clear(), this.#c.clear(), this.#t = null, this.#b.clear(), this.#a.destroy(), this.#n?.destroy(), this.#m?.hide(), this.#m = null, this.#g && (clearTimeout(this.#g), this.#g = null), this.#O && (clearTimeout(this.#O), this.#O = null), this.#ot();
        }
        async mlGuess(s) {
          return this.#L?.guess(s) || null;
        }
        get hasMLManager() {
          return !!this.#L;
        }
        get hcmFilter() {
          return (0, w.shadow)(this, "hcmFilter", this.#x ? this.#p.addHCMFilter(this.#x.foreground, this.#x.background) : "none");
        }
        get direction() {
          return (0, w.shadow)(this, "direction", getComputedStyle(this.#z).direction);
        }
        get highlightColors() {
          return (0, w.shadow)(this, "highlightColors", this.#f ? new Map(this.#f.split(",").map((s) => s.split("=").map((g) => g.trim()))) : null);
        }
        get highlightColorNames() {
          return (0, w.shadow)(this, "highlightColorNames", this.highlightColors ? new Map(Array.from(this.highlightColors, (s) => s.reverse())) : null);
        }
        setMainHighlightColorPicker(s) {
          this.#I = s;
        }
        editAltText(s) {
          this.#n?.editAltText(this, s);
        }
        onPageChanging({
          pageNumber: s
        }) {
          this.#l = s - 1;
        }
        focusMainContainer() {
          this.#z.focus();
        }
        findParent(s, g) {
          for (const t of this.#s.values()) {
            const {
              x: i,
              y: d,
              width: f,
              height: y
            } = t.div.getBoundingClientRect();
            if (s >= i && s <= i + f && g >= d && g <= d + y)
              return t;
          }
          return null;
        }
        disableUserSelect(s = !1) {
          this.#K.classList.toggle("noUserSelect", s);
        }
        addShouldRescale(s) {
          this.#c.add(s);
        }
        removeShouldRescale(s) {
          this.#c.delete(s);
        }
        onScaleChanging({
          scale: s
        }) {
          this.commitOrRemove(), this.viewParameters.realScale = s * B.PixelsPerInch.PDF_TO_CSS_UNITS;
          for (const g of this.#c)
            g.onScaleChanging();
        }
        onRotationChanging({
          pagesRotation: s
        }) {
          this.commitOrRemove(), this.viewParameters.rotation = s;
        }
        #Y({
          anchorNode: s
        }) {
          return s.nodeType === Node.TEXT_NODE ? s.parentElement : s;
        }
        highlightSelection(s = "") {
          const g = document.getSelection();
          if (!g || g.isCollapsed)
            return;
          const {
            anchorNode: t,
            anchorOffset: i,
            focusNode: d,
            focusOffset: f
          } = g, y = g.toString(), L = this.#Y(g).closest(".textLayer"), M = this.getSelectionBoxes(L);
          if (M) {
            g.empty(), this.#y === w.AnnotationEditorType.NONE && (this._eventBus.dispatch("showannotationeditorui", {
              source: this,
              mode: w.AnnotationEditorType.HIGHLIGHT
            }), this.showAllEditors("highlight", !0, !0));
            for (const N of this.#s.values())
              if (N.hasTextLayer(L)) {
                N.createAndAddNewEditor({
                  x: 0,
                  y: 0
                }, !1, {
                  methodOfCreation: s,
                  boxes: M,
                  anchorNode: t,
                  anchorOffset: i,
                  focusNode: d,
                  focusOffset: f,
                  text: y
                });
                break;
              }
          }
        }
        #nt() {
          const s = document.getSelection();
          if (!s || s.isCollapsed)
            return;
          const t = this.#Y(s).closest(".textLayer"), i = this.getSelectionBoxes(t);
          i && (this.#m ||= new _.HighlightToolbar(this), this.#m.show(t, i, this.direction === "ltr"));
        }
        addToAnnotationStorage(s) {
          !s.isEmpty() && this.#r && !this.#r.has(s.id) && this.#r.setValue(s.id, s);
        }
        #rt() {
          const s = document.getSelection();
          if (!s || s.isCollapsed) {
            this.#S && (this.#m?.hide(), this.#S = null, this.#E({
              hasSelectedText: !1
            }));
            return;
          }
          const {
            anchorNode: g
          } = s;
          if (g === this.#S)
            return;
          if (!this.#Y(s).closest(".textLayer")) {
            this.#S && (this.#m?.hide(), this.#S = null, this.#E({
              hasSelectedText: !1
            }));
            return;
          }
          if (this.#m?.hide(), this.#S = g, this.#E({
            hasSelectedText: !0
          }), !(this.#y !== w.AnnotationEditorType.HIGHLIGHT && this.#y !== w.AnnotationEditorType.NONE) && (this.#y === w.AnnotationEditorType.HIGHLIGHT && this.showAllEditors("highlight", !0, !0), this.#A = this.isShiftKeyDown, !this.isShiftKeyDown)) {
            const d = (f) => {
              f.type === "pointerup" && f.button !== 0 || (window.removeEventListener("pointerup", d), window.removeEventListener("blur", d), f.type === "pointerup" && this.#W("main_toolbar"));
            };
            window.addEventListener("pointerup", d), window.addEventListener("blur", d);
          }
        }
        #W(s = "") {
          this.#y === w.AnnotationEditorType.HIGHLIGHT ? this.highlightSelection(s) : this.#o && this.#nt();
        }
        #at() {
          document.addEventListener("selectionchange", this.#B);
        }
        #ot() {
          document.removeEventListener("selectionchange", this.#B);
        }
        #ht() {
          window.addEventListener("focus", this.#M), window.addEventListener("blur", this.#T);
        }
        #Q() {
          window.removeEventListener("focus", this.#M), window.removeEventListener("blur", this.#T);
        }
        blur() {
          if (this.isShiftKeyDown = !1, this.#A && (this.#A = !1, this.#W("main_toolbar")), !this.hasSelection)
            return;
          const {
            activeElement: s
          } = document;
          for (const g of this.#b)
            if (g.div.contains(s)) {
              this.#k = [g, s], g._focusEventsAllowed = !1;
              break;
            }
        }
        focus() {
          if (!this.#k)
            return;
          const [s, g] = this.#k;
          this.#k = null, g.addEventListener("focusin", () => {
            s._focusEventsAllowed = !0;
          }, {
            once: !0
          }), g.focus();
        }
        #J() {
          window.addEventListener("keydown", this.#D), window.addEventListener("keyup", this.#G);
        }
        #Z() {
          window.removeEventListener("keydown", this.#D), window.removeEventListener("keyup", this.#G);
        }
        #tt() {
          document.addEventListener("copy", this.#F), document.addEventListener("cut", this.#_), document.addEventListener("paste", this.#P);
        }
        #et() {
          document.removeEventListener("copy", this.#F), document.removeEventListener("cut", this.#_), document.removeEventListener("paste", this.#P);
        }
        addEditListeners() {
          this.#J(), this.#tt();
        }
        removeEditListeners() {
          this.#Z(), this.#et();
        }
        copy(s) {
          if (s.preventDefault(), this.#t?.commitOrRemove(), !this.hasSelection)
            return;
          const g = [];
          for (const t of this.#b) {
            const i = t.serialize(!0);
            i && g.push(i);
          }
          g.length !== 0 && s.clipboardData.setData("application/pdfjs", JSON.stringify(g));
        }
        cut(s) {
          this.copy(s), this.delete();
        }
        paste(s) {
          s.preventDefault();
          const {
            clipboardData: g
          } = s;
          for (const d of g.items)
            for (const f of this.#u)
              if (f.isHandlingMimeForPasting(d.type)) {
                f.paste(d, this.currentLayer);
                return;
              }
          let t = g.getData("application/pdfjs");
          if (!t)
            return;
          try {
            t = JSON.parse(t);
          } catch (d) {
            (0, w.warn)(`paste: "${d.message}".`);
            return;
          }
          if (!Array.isArray(t))
            return;
          this.unselectAll();
          const i = this.currentLayer;
          try {
            const d = [];
            for (const S of t) {
              const L = i.deserialize(S);
              if (!L)
                return;
              d.push(L);
            }
            const f = () => {
              for (const S of d)
                this.#st(S);
              this.#it(d);
            }, y = () => {
              for (const S of d)
                S.remove();
            };
            this.addCommands({
              cmd: f,
              undo: y,
              mustExec: !0
            });
          } catch (d) {
            (0, w.warn)(`paste: "${d.message}".`);
          }
        }
        keydown(s) {
          !this.isShiftKeyDown && s.key === "Shift" && (this.isShiftKeyDown = !0), this.#y !== w.AnnotationEditorType.NONE && !this.isEditorHandlingKeyboard && l._keyboardManager.exec(this, s);
        }
        keyup(s) {
          this.isShiftKeyDown && s.key === "Shift" && (this.isShiftKeyDown = !1, this.#A && (this.#A = !1, this.#W("main_toolbar")));
        }
        onEditingAction({
          name: s
        }) {
          switch (s) {
            case "undo":
            case "redo":
            case "delete":
            case "selectAll":
              this[s]();
              break;
            case "highlightSelection":
              this.highlightSelection("context_menu");
              break;
          }
        }
        #E(s) {
          Object.entries(s).some(([t, i]) => this.#q[t] !== i) && (this._eventBus.dispatch("annotationeditorstateschanged", {
            source: this,
            details: Object.assign(this.#q, s)
          }), this.#y === w.AnnotationEditorType.HIGHLIGHT && s.hasSelectedEditor === !1 && this.#H([[w.AnnotationEditorParamsType.HIGHLIGHT_FREE, !0]]));
        }
        #H(s) {
          this._eventBus.dispatch("annotationeditorparamschanged", {
            source: this,
            details: s
          });
        }
        setEditingState(s) {
          s ? (this.#ht(), this.#tt(), this.#E({
            isEditing: this.#y !== w.AnnotationEditorType.NONE,
            isEmpty: this.#j(),
            hasSomethingToUndo: this.#a.hasSomethingToUndo(),
            hasSomethingToRedo: this.#a.hasSomethingToRedo(),
            hasSelectedEditor: !1
          })) : (this.#Q(), this.#et(), this.#E({
            isEditing: !1
          }), this.disableUserSelect(!1));
        }
        registerEditorTypes(s) {
          if (!this.#u) {
            this.#u = s;
            for (const g of this.#u)
              this.#H(g.defaultPropertiesToUpdate);
          }
        }
        getId() {
          return this.#v.id;
        }
        get currentLayer() {
          return this.#s.get(this.#l);
        }
        getLayer(s) {
          return this.#s.get(s);
        }
        get currentPageIndex() {
          return this.#l;
        }
        addLayer(s) {
          this.#s.set(s.pageIndex, s), this.#w ? s.enable() : s.disable();
        }
        removeLayer(s) {
          this.#s.delete(s.pageIndex);
        }
        updateMode(s, g = null, t = !1) {
          if (this.#y !== s) {
            if (this.#y = s, s === w.AnnotationEditorType.NONE) {
              this.setEditingState(!1), this.#ct();
              return;
            }
            this.setEditingState(!0), this.#lt(), this.unselectAll();
            for (const i of this.#s.values())
              i.updateMode(s);
            if (!g && t) {
              this.addNewEditorFromKeyboard();
              return;
            }
            if (g) {
              for (const i of this.#e.values())
                if (i.annotationElementId === g) {
                  this.setSelected(i), i.enterInEditMode();
                  break;
                }
            }
          }
        }
        addNewEditorFromKeyboard() {
          this.currentLayer.canCreateNewEmptyEditor() && this.currentLayer.addNewEditor();
        }
        updateToolbar(s) {
          s !== this.#y && this._eventBus.dispatch("switchannotationeditormode", {
            source: this,
            mode: s
          });
        }
        updateParams(s, g) {
          if (this.#u) {
            switch (s) {
              case w.AnnotationEditorParamsType.CREATE:
                this.currentLayer.addNewEditor();
                return;
              case w.AnnotationEditorParamsType.HIGHLIGHT_DEFAULT_COLOR:
                this.#I?.updateColor(g);
                break;
              case w.AnnotationEditorParamsType.HIGHLIGHT_SHOW_ALL:
                this._eventBus.dispatch("reporttelemetry", {
                  source: this,
                  details: {
                    type: "editing",
                    data: {
                      type: "highlight",
                      action: "toggle_visibility"
                    }
                  }
                }), (this.#R ||= /* @__PURE__ */ new Map()).set(s, g), this.showAllEditors("highlight", g);
                break;
            }
            for (const t of this.#b)
              t.updateParams(s, g);
            for (const t of this.#u)
              t.updateDefaultParams(s, g);
          }
        }
        showAllEditors(s, g, t = !1) {
          for (const d of this.#e.values())
            d.editorType === s && d.show(g);
          (this.#R?.get(w.AnnotationEditorParamsType.HIGHLIGHT_SHOW_ALL) ?? !0) !== g && this.#H([[w.AnnotationEditorParamsType.HIGHLIGHT_SHOW_ALL, g]]);
        }
        enableWaiting(s = !1) {
          if (this.#C !== s) {
            this.#C = s;
            for (const g of this.#s.values())
              s ? g.disableClick() : g.enableClick(), g.div.classList.toggle("waiting", s);
          }
        }
        #lt() {
          if (!this.#w) {
            this.#w = !0;
            for (const s of this.#s.values())
              s.enable();
            for (const s of this.#e.values())
              s.enable();
          }
        }
        #ct() {
          if (this.unselectAll(), this.#w) {
            this.#w = !1;
            for (const s of this.#s.values())
              s.disable();
            for (const s of this.#e.values())
              s.disable();
          }
        }
        getEditors(s) {
          const g = [];
          for (const t of this.#e.values())
            t.pageIndex === s && g.push(t);
          return g;
        }
        getEditor(s) {
          return this.#e.get(s);
        }
        addEditor(s) {
          this.#e.set(s.id, s);
        }
        removeEditor(s) {
          s.div.contains(document.activeElement) && (this.#g && clearTimeout(this.#g), this.#g = setTimeout(() => {
            this.focusMainContainer(), this.#g = null;
          }, 0)), this.#e.delete(s.id), this.unselect(s), (!s.annotationElementId || !this.#h.has(s.annotationElementId)) && this.#r?.remove(s.id);
        }
        addDeletedAnnotationElement(s) {
          this.#h.add(s.annotationElementId), this.addChangedExistingAnnotation(s), s.deleted = !0;
        }
        isDeletedAnnotationElement(s) {
          return this.#h.has(s);
        }
        removeDeletedAnnotationElement(s) {
          this.#h.delete(s.annotationElementId), this.removeChangedExistingAnnotation(s), s.deleted = !1;
        }
        #st(s) {
          const g = this.#s.get(s.pageIndex);
          g ? g.addOrRebuild(s) : (this.addEditor(s), this.addToAnnotationStorage(s));
        }
        setActiveEditor(s) {
          this.#t !== s && (this.#t = s, s && this.#H(s.propertiesToUpdate));
        }
        get #dt() {
          let s = null;
          for (s of this.#b)
            ;
          return s;
        }
        updateUI(s) {
          this.#dt === s && this.#H(s.propertiesToUpdate);
        }
        toggleSelected(s) {
          if (this.#b.has(s)) {
            this.#b.delete(s), s.unselect(), this.#E({
              hasSelectedEditor: this.hasSelection
            });
            return;
          }
          this.#b.add(s), s.select(), this.#H(s.propertiesToUpdate), this.#E({
            hasSelectedEditor: !0
          });
        }
        setSelected(s) {
          for (const g of this.#b)
            g !== s && g.unselect();
          this.#b.clear(), this.#b.add(s), s.select(), this.#H(s.propertiesToUpdate), this.#E({
            hasSelectedEditor: !0
          });
        }
        isSelected(s) {
          return this.#b.has(s);
        }
        get firstSelectedEditor() {
          return this.#b.values().next().value;
        }
        unselect(s) {
          s.unselect(), this.#b.delete(s), this.#E({
            hasSelectedEditor: this.hasSelection
          });
        }
        get hasSelection() {
          return this.#b.size !== 0;
        }
        get isEnterHandled() {
          return this.#b.size === 1 && this.firstSelectedEditor.isEnterHandled;
        }
        undo() {
          this.#a.undo(), this.#E({
            hasSomethingToUndo: this.#a.hasSomethingToUndo(),
            hasSomethingToRedo: !0,
            isEmpty: this.#j()
          });
        }
        redo() {
          this.#a.redo(), this.#E({
            hasSomethingToUndo: !0,
            hasSomethingToRedo: this.#a.hasSomethingToRedo(),
            isEmpty: this.#j()
          });
        }
        addCommands(s) {
          this.#a.add(s), this.#E({
            hasSomethingToUndo: !0,
            hasSomethingToRedo: !1,
            isEmpty: this.#j()
          });
        }
        #j() {
          if (this.#e.size === 0)
            return !0;
          if (this.#e.size === 1)
            for (const s of this.#e.values())
              return s.isEmpty();
          return !1;
        }
        delete() {
          if (this.commitOrRemove(), !this.hasSelection)
            return;
          const s = [...this.#b], g = () => {
            for (const i of s)
              i.remove();
          }, t = () => {
            for (const i of s)
              this.#st(i);
          };
          this.addCommands({
            cmd: g,
            undo: t,
            mustExec: !0
          });
        }
        commitOrRemove() {
          this.#t?.commitOrRemove();
        }
        hasSomethingToControl() {
          return this.#t || this.hasSelection;
        }
        #it(s) {
          for (const g of this.#b)
            g.unselect();
          this.#b.clear();
          for (const g of s)
            g.isEmpty() || (this.#b.add(g), g.select());
          this.#E({
            hasSelectedEditor: this.hasSelection
          });
        }
        selectAll() {
          for (const s of this.#b)
            s.commit();
          this.#it(this.#e.values());
        }
        unselectAll() {
          if (!(this.#t && (this.#t.commitOrRemove(), this.#y !== w.AnnotationEditorType.NONE)) && this.hasSelection) {
            for (const s of this.#b)
              s.unselect();
            this.#b.clear(), this.#E({
              hasSelectedEditor: !1
            });
          }
        }
        translateSelectedEditors(s, g, t = !1) {
          if (t || this.commitOrRemove(), !this.hasSelection)
            return;
          this.#V[0] += s, this.#V[1] += g;
          const [i, d] = this.#V, f = [...this.#b], y = 1e3;
          this.#O && clearTimeout(this.#O), this.#O = setTimeout(() => {
            this.#O = null, this.#V[0] = this.#V[1] = 0, this.addCommands({
              cmd: () => {
                for (const S of f)
                  this.#e.has(S.id) && S.translateInPage(i, d);
              },
              undo: () => {
                for (const S of f)
                  this.#e.has(S.id) && S.translateInPage(-i, -d);
              },
              mustExec: !1
            });
          }, y);
          for (const S of f)
            S.translateInPage(s, g);
        }
        setUpDragSession() {
          if (this.hasSelection) {
            this.disableUserSelect(!0), this.#d = /* @__PURE__ */ new Map();
            for (const s of this.#b)
              this.#d.set(s, {
                savedX: s.x,
                savedY: s.y,
                savedPageIndex: s.pageIndex,
                newX: 0,
                newY: 0,
                newPageIndex: -1
              });
          }
        }
        endDragSession() {
          if (!this.#d)
            return !1;
          this.disableUserSelect(!1);
          const s = this.#d;
          this.#d = null;
          let g = !1;
          for (const [{
            x: i,
            y: d,
            pageIndex: f
          }, y] of s)
            y.newX = i, y.newY = d, y.newPageIndex = f, g ||= i !== y.savedX || d !== y.savedY || f !== y.savedPageIndex;
          if (!g)
            return !1;
          const t = (i, d, f, y) => {
            if (this.#e.has(i.id)) {
              const S = this.#s.get(y);
              S ? i._setParentAndPosition(S, d, f) : (i.pageIndex = y, i.x = d, i.y = f);
            }
          };
          return this.addCommands({
            cmd: () => {
              for (const [i, {
                newX: d,
                newY: f,
                newPageIndex: y
              }] of s)
                t(i, d, f, y);
            },
            undo: () => {
              for (const [i, {
                savedX: d,
                savedY: f,
                savedPageIndex: y
              }] of s)
                t(i, d, f, y);
            },
            mustExec: !0
          }), !0;
        }
        dragSelectedEditors(s, g) {
          if (this.#d)
            for (const t of this.#d.keys())
              t.drag(s, g);
        }
        rebuild(s) {
          if (s.parent === null) {
            const g = this.getLayer(s.pageIndex);
            g ? (g.changeParent(s), g.addOrRebuild(s)) : (this.addEditor(s), this.addToAnnotationStorage(s), s.rebuild());
          } else
            s.parent.addOrRebuild(s);
        }
        get isEditorHandlingKeyboard() {
          return this.getActive()?.shouldGetKeyboardEvents() || this.#b.size === 1 && this.firstSelectedEditor.shouldGetKeyboardEvents();
        }
        isActive(s) {
          return this.#t === s;
        }
        getActive() {
          return this.#t;
        }
        getMode() {
          return this.#y;
        }
        get imageManager() {
          return (0, w.shadow)(this, "imageManager", new E());
        }
        getSelectionBoxes(s) {
          if (!s)
            return null;
          const g = document.getSelection();
          for (let L = 0, M = g.rangeCount; L < M; L++)
            if (!s.contains(g.getRangeAt(L).commonAncestorContainer))
              return null;
          const {
            x: t,
            y: i,
            width: d,
            height: f
          } = s.getBoundingClientRect();
          let y;
          switch (s.getAttribute("data-main-rotation")) {
            case "90":
              y = (L, M, N, H) => ({
                x: (M - i) / f,
                y: 1 - (L + N - t) / d,
                width: H / f,
                height: N / d
              });
              break;
            case "180":
              y = (L, M, N, H) => ({
                x: 1 - (L + N - t) / d,
                y: 1 - (M + H - i) / f,
                width: N / d,
                height: H / f
              });
              break;
            case "270":
              y = (L, M, N, H) => ({
                x: 1 - (M + H - i) / f,
                y: (L - t) / d,
                width: H / f,
                height: N / d
              });
              break;
            default:
              y = (L, M, N, H) => ({
                x: (L - t) / d,
                y: (M - i) / f,
                width: N / d,
                height: H / f
              });
              break;
          }
          const S = [];
          for (let L = 0, M = g.rangeCount; L < M; L++) {
            const N = g.getRangeAt(L);
            if (!N.collapsed)
              for (const {
                x: H,
                y: z,
                width: q,
                height: nt
              } of N.getClientRects())
                q === 0 || nt === 0 || S.push(y(H, z, q, nt));
          }
          return S.length === 0 ? null : S;
        }
        addChangedExistingAnnotation({
          annotationElementId: s,
          id: g
        }) {
          (this.#i ||= /* @__PURE__ */ new Map()).set(s, g);
        }
        removeChangedExistingAnnotation({
          annotationElementId: s
        }) {
          this.#i?.delete(s);
        }
        renderAnnotationElement(s) {
          const g = this.#i?.get(s.data.id);
          if (!g)
            return;
          const t = this.#r.getRawValue(g);
          t && (this.#y === w.AnnotationEditorType.NONE && !t.hasBeenModified || t.renderAnnotationElement(s));
        }
      }
    })
  ),
  /***/
  94: (
    /***/
    ((ct, st, V) => {
      V.d(st, {
        /* harmony export */
        PDFFetchStream: () => (
          /* binding */
          T
        )
        /* harmony export */
      });
      var w = V(292), B = V(490);
      function _(n, c, l) {
        return {
          method: "GET",
          headers: n,
          signal: l.signal,
          mode: "cors",
          credentials: c ? "include" : "same-origin",
          redirect: "follow"
        };
      }
      function U(n) {
        const c = new Headers();
        for (const l in n) {
          const b = n[l];
          b !== void 0 && c.append(l, b);
        }
        return c;
      }
      function P(n) {
        return n instanceof Uint8Array ? n.buffer : n instanceof ArrayBuffer ? n : ((0, w.warn)(`getArrayBuffer - unexpected data format: ${n}`), new Uint8Array(n).buffer);
      }
      class T {
        constructor(c) {
          this.source = c, this.isHttp = /^https?:/i.test(c.url), this.httpHeaders = this.isHttp && c.httpHeaders || {}, this._fullRequestReader = null, this._rangeRequestReaders = [];
        }
        get _progressiveDataLength() {
          return this._fullRequestReader?._loaded ?? 0;
        }
        getFullReader() {
          return (0, w.assert)(!this._fullRequestReader, "PDFFetchStream.getFullReader can only be called once."), this._fullRequestReader = new E(this), this._fullRequestReader;
        }
        getRangeReader(c, l) {
          if (l <= this._progressiveDataLength)
            return null;
          const b = new v(this, c, l);
          return this._rangeRequestReaders.push(b), b;
        }
        cancelAllRequests(c) {
          this._fullRequestReader?.cancel(c);
          for (const l of this._rangeRequestReaders.slice(0))
            l.cancel(c);
        }
      }
      class E {
        constructor(c) {
          this._stream = c, this._reader = null, this._loaded = 0, this._filename = null;
          const l = c.source;
          this._withCredentials = l.withCredentials || !1, this._contentLength = l.length, this._headersCapability = Promise.withResolvers(), this._disableRange = l.disableRange || !1, this._rangeChunkSize = l.rangeChunkSize, !this._rangeChunkSize && !this._disableRange && (this._disableRange = !0), this._abortController = new AbortController(), this._isStreamingSupported = !l.disableStream, this._isRangeSupported = !l.disableRange, this._headers = U(this._stream.httpHeaders);
          const b = l.url;
          fetch(b, _(this._headers, this._withCredentials, this._abortController)).then((s) => {
            if (!(0, B.validateResponseStatus)(s.status))
              throw (0, B.createResponseStatusError)(s.status, b);
            this._reader = s.body.getReader(), this._headersCapability.resolve();
            const g = (d) => s.headers.get(d), {
              allowRangeRequests: t,
              suggestedLength: i
            } = (0, B.validateRangeRequestCapabilities)({
              getResponseHeader: g,
              isHttp: this._stream.isHttp,
              rangeChunkSize: this._rangeChunkSize,
              disableRange: this._disableRange
            });
            this._isRangeSupported = t, this._contentLength = i || this._contentLength, this._filename = (0, B.extractFilenameFromHeader)(g), !this._isStreamingSupported && this._isRangeSupported && this.cancel(new w.AbortException("Streaming is disabled."));
          }).catch(this._headersCapability.reject), this.onProgress = null;
        }
        get headersReady() {
          return this._headersCapability.promise;
        }
        get filename() {
          return this._filename;
        }
        get contentLength() {
          return this._contentLength;
        }
        get isRangeSupported() {
          return this._isRangeSupported;
        }
        get isStreamingSupported() {
          return this._isStreamingSupported;
        }
        async read() {
          await this._headersCapability.promise;
          const {
            value: c,
            done: l
          } = await this._reader.read();
          return l ? {
            value: c,
            done: l
          } : (this._loaded += c.byteLength, this.onProgress?.({
            loaded: this._loaded,
            total: this._contentLength
          }), {
            value: P(c),
            done: !1
          });
        }
        cancel(c) {
          this._reader?.cancel(c), this._abortController.abort();
        }
      }
      class v {
        constructor(c, l, b) {
          this._stream = c, this._reader = null, this._loaded = 0;
          const s = c.source;
          this._withCredentials = s.withCredentials || !1, this._readCapability = Promise.withResolvers(), this._isStreamingSupported = !s.disableStream, this._abortController = new AbortController(), this._headers = U(this._stream.httpHeaders), this._headers.append("Range", `bytes=${l}-${b - 1}`);
          const g = s.url;
          fetch(g, _(this._headers, this._withCredentials, this._abortController)).then((t) => {
            if (!(0, B.validateResponseStatus)(t.status))
              throw (0, B.createResponseStatusError)(t.status, g);
            this._readCapability.resolve(), this._reader = t.body.getReader();
          }).catch(this._readCapability.reject), this.onProgress = null;
        }
        get isStreamingSupported() {
          return this._isStreamingSupported;
        }
        async read() {
          await this._readCapability.promise;
          const {
            value: c,
            done: l
          } = await this._reader.read();
          return l ? {
            value: c,
            done: l
          } : (this._loaded += c.byteLength, this.onProgress?.({
            loaded: this._loaded
          }), {
            value: P(c),
            done: !1
          });
        }
        cancel(c) {
          this._reader?.cancel(c), this._abortController.abort();
        }
      }
    })
  ),
  /***/
  10: (
    /***/
    ((ct, st, V) => {
      V.d(st, {
        /* harmony export */
        FontFaceObject: () => (
          /* binding */
          _
        ),
        /* harmony export */
        FontLoader: () => (
          /* binding */
          B
        )
        /* harmony export */
      });
      var w = V(292);
      class B {
        #t = /* @__PURE__ */ new Set();
        constructor({
          ownerDocument: P = globalThis.document,
          styleElement: T = null
        }) {
          this._document = P, this.nativeFontFaces = /* @__PURE__ */ new Set(), this.styleElement = null, this.loadingRequests = [], this.loadTestFontId = 0;
        }
        addNativeFontFace(P) {
          this.nativeFontFaces.add(P), this._document.fonts.add(P);
        }
        removeNativeFontFace(P) {
          this.nativeFontFaces.delete(P), this._document.fonts.delete(P);
        }
        insertRule(P) {
          this.styleElement || (this.styleElement = this._document.createElement("style"), this._document.documentElement.getElementsByTagName("head")[0].append(this.styleElement));
          const T = this.styleElement.sheet;
          T.insertRule(P, T.cssRules.length);
        }
        clear() {
          for (const P of this.nativeFontFaces)
            this._document.fonts.delete(P);
          this.nativeFontFaces.clear(), this.#t.clear(), this.styleElement && (this.styleElement.remove(), this.styleElement = null);
        }
        async loadSystemFont({
          systemFontInfo: P,
          _inspectFont: T
        }) {
          if (!(!P || this.#t.has(P.loadedName))) {
            if ((0, w.assert)(!this.disableFontFace, "loadSystemFont shouldn't be called when `disableFontFace` is set."), this.isFontLoadingAPISupported) {
              const {
                loadedName: E,
                src: v,
                style: n
              } = P, c = new FontFace(E, v, n);
              this.addNativeFontFace(c);
              try {
                await c.load(), this.#t.add(E), T?.(P);
              } catch {
                (0, w.warn)(`Cannot load system font: ${P.baseFontName}, installing it could help to improve PDF rendering.`), this.removeNativeFontFace(c);
              }
              return;
            }
            (0, w.unreachable)("Not implemented: loadSystemFont without the Font Loading API.");
          }
        }
        async bind(P) {
          if (P.attached || P.missingFile && !P.systemFontInfo)
            return;
          if (P.attached = !0, P.systemFontInfo) {
            await this.loadSystemFont(P);
            return;
          }
          if (this.isFontLoadingAPISupported) {
            const E = P.createNativeFontFace();
            if (E) {
              this.addNativeFontFace(E);
              try {
                await E.loaded;
              } catch (v) {
                throw (0, w.warn)(`Failed to load font '${E.family}': '${v}'.`), P.disableFontFace = !0, v;
              }
            }
            return;
          }
          const T = P.createFontFaceRule();
          if (T) {
            if (this.insertRule(T), this.isSyncFontLoadingSupported)
              return;
            await new Promise((E) => {
              const v = this._queueLoadingCallback(E);
              this._prepareFontLoadEvent(P, v);
            });
          }
        }
        get isFontLoadingAPISupported() {
          const P = !!this._document?.fonts;
          return (0, w.shadow)(this, "isFontLoadingAPISupported", P);
        }
        get isSyncFontLoadingSupported() {
          let P = !1;
          return (w.isNodeJS || typeof navigator < "u" && typeof navigator?.userAgent == "string" && /Mozilla\/5.0.*?rv:\d+.*? Gecko/.test(navigator.userAgent)) && (P = !0), (0, w.shadow)(this, "isSyncFontLoadingSupported", P);
        }
        _queueLoadingCallback(P) {
          function T() {
            for ((0, w.assert)(!v.done, "completeRequest() cannot be called twice."), v.done = !0; E.length > 0 && E[0].done; ) {
              const n = E.shift();
              setTimeout(n.callback, 0);
            }
          }
          const {
            loadingRequests: E
          } = this, v = {
            done: !1,
            complete: T,
            callback: P
          };
          return E.push(v), v;
        }
        get _loadTestFont() {
          const P = atob("T1RUTwALAIAAAwAwQ0ZGIDHtZg4AAAOYAAAAgUZGVE1lkzZwAAAEHAAAABxHREVGABQAFQAABDgAAAAeT1MvMlYNYwkAAAEgAAAAYGNtYXABDQLUAAACNAAAAUJoZWFk/xVFDQAAALwAAAA2aGhlYQdkA+oAAAD0AAAAJGhtdHgD6AAAAAAEWAAAAAZtYXhwAAJQAAAAARgAAAAGbmFtZVjmdH4AAAGAAAAAsXBvc3T/hgAzAAADeAAAACAAAQAAAAEAALZRFsRfDzz1AAsD6AAAAADOBOTLAAAAAM4KHDwAAAAAA+gDIQAAAAgAAgAAAAAAAAABAAADIQAAAFoD6AAAAAAD6AABAAAAAAAAAAAAAAAAAAAAAQAAUAAAAgAAAAQD6AH0AAUAAAKKArwAAACMAooCvAAAAeAAMQECAAACAAYJAAAAAAAAAAAAAQAAAAAAAAAAAAAAAFBmRWQAwAAuAC4DIP84AFoDIQAAAAAAAQAAAAAAAAAAACAAIAABAAAADgCuAAEAAAAAAAAAAQAAAAEAAAAAAAEAAQAAAAEAAAAAAAIAAQAAAAEAAAAAAAMAAQAAAAEAAAAAAAQAAQAAAAEAAAAAAAUAAQAAAAEAAAAAAAYAAQAAAAMAAQQJAAAAAgABAAMAAQQJAAEAAgABAAMAAQQJAAIAAgABAAMAAQQJAAMAAgABAAMAAQQJAAQAAgABAAMAAQQJAAUAAgABAAMAAQQJAAYAAgABWABYAAAAAAAAAwAAAAMAAAAcAAEAAAAAADwAAwABAAAAHAAEACAAAAAEAAQAAQAAAC7//wAAAC7////TAAEAAAAAAAABBgAAAQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAMAAAAAAAD/gwAyAAAAAQAAAAAAAAAAAAAAAAAAAAABAAQEAAEBAQJYAAEBASH4DwD4GwHEAvgcA/gXBIwMAYuL+nz5tQXkD5j3CBLnEQACAQEBIVhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYAAABAQAADwACAQEEE/t3Dov6fAH6fAT+fPp8+nwHDosMCvm1Cvm1DAz6fBQAAAAAAAABAAAAAMmJbzEAAAAAzgTjFQAAAADOBOQpAAEAAAAAAAAADAAUAAQAAAABAAAAAgABAAAAAAAAAAAD6AAAAAAAAA==");
          return (0, w.shadow)(this, "_loadTestFont", P);
        }
        _prepareFontLoadEvent(P, T) {
          function E(H, z) {
            return H.charCodeAt(z) << 24 | H.charCodeAt(z + 1) << 16 | H.charCodeAt(z + 2) << 8 | H.charCodeAt(z + 3) & 255;
          }
          function v(H, z, q, nt) {
            const j = H.substring(0, z), O = H.substring(z + q);
            return j + nt + O;
          }
          let n, c;
          const l = this._document.createElement("canvas");
          l.width = 1, l.height = 1;
          const b = l.getContext("2d");
          let s = 0;
          function g(H, z) {
            if (++s > 30) {
              (0, w.warn)("Load test font never loaded."), z();
              return;
            }
            if (b.font = "30px " + H, b.fillText(".", 0, 20), b.getImageData(0, 0, 1, 1).data[3] > 0) {
              z();
              return;
            }
            setTimeout(g.bind(null, H, z));
          }
          const t = `lt${Date.now()}${this.loadTestFontId++}`;
          let i = this._loadTestFont;
          i = v(i, 976, t.length, t);
          const f = 16, y = 1482184792;
          let S = E(i, f);
          for (n = 0, c = t.length - 3; n < c; n += 4)
            S = S - y + E(t, n) | 0;
          n < t.length && (S = S - y + E(t + "XXX", n) | 0), i = v(i, f, 4, (0, w.string32)(S));
          const L = `url(data:font/opentype;base64,${btoa(i)});`, M = `@font-face {font-family:"${t}";src:${L}}`;
          this.insertRule(M);
          const N = this._document.createElement("div");
          N.style.visibility = "hidden", N.style.width = N.style.height = "10px", N.style.position = "absolute", N.style.top = N.style.left = "0px";
          for (const H of [P.loadedName, t]) {
            const z = this._document.createElement("span");
            z.textContent = "Hi", z.style.fontFamily = H, N.append(z);
          }
          this._document.body.append(N), g(t, () => {
            N.remove(), T.complete();
          });
        }
      }
      class _ {
        constructor(P, {
          disableFontFace: T = !1,
          ignoreErrors: E = !1,
          inspectFont: v = null
        }) {
          this.compiledGlyphs = /* @__PURE__ */ Object.create(null);
          for (const n in P)
            this[n] = P[n];
          this.disableFontFace = T === !0, this.ignoreErrors = E === !0, this._inspectFont = v;
        }
        createNativeFontFace() {
          if (!this.data || this.disableFontFace)
            return null;
          let P;
          if (!this.cssFontInfo)
            P = new FontFace(this.loadedName, this.data, {});
          else {
            const T = {
              weight: this.cssFontInfo.fontWeight
            };
            this.cssFontInfo.italicAngle && (T.style = `oblique ${this.cssFontInfo.italicAngle}deg`), P = new FontFace(this.cssFontInfo.fontFamily, this.data, T);
          }
          return this._inspectFont?.(this), P;
        }
        createFontFaceRule() {
          if (!this.data || this.disableFontFace)
            return null;
          const P = (0, w.bytesToString)(this.data), T = `url(data:${this.mimetype};base64,${btoa(P)});`;
          let E;
          if (!this.cssFontInfo)
            E = `@font-face {font-family:"${this.loadedName}";src:${T}}`;
          else {
            let v = `font-weight: ${this.cssFontInfo.fontWeight};`;
            this.cssFontInfo.italicAngle && (v += `font-style: oblique ${this.cssFontInfo.italicAngle}deg;`), E = `@font-face {font-family:"${this.cssFontInfo.fontFamily}";${v}src:${T}}`;
          }
          return this._inspectFont?.(this, T), E;
        }
        getPathGenerator(P, T) {
          if (this.compiledGlyphs[T] !== void 0)
            return this.compiledGlyphs[T];
          let E;
          try {
            E = P.get(this.loadedName + "_path_" + T);
          } catch (n) {
            if (!this.ignoreErrors)
              throw n;
            (0, w.warn)(`getPathGenerator - ignoring character: "${n}".`);
          }
          if (!Array.isArray(E) || E.length === 0)
            return this.compiledGlyphs[T] = function(n, c) {
            };
          const v = [];
          for (let n = 0, c = E.length; n < c; )
            switch (E[n++]) {
              case w.FontRenderOps.BEZIER_CURVE_TO:
                {
                  const [l, b, s, g, t, i] = E.slice(n, n + 6);
                  v.push((d) => d.bezierCurveTo(l, b, s, g, t, i)), n += 6;
                }
                break;
              case w.FontRenderOps.MOVE_TO:
                {
                  const [l, b] = E.slice(n, n + 2);
                  v.push((s) => s.moveTo(l, b)), n += 2;
                }
                break;
              case w.FontRenderOps.LINE_TO:
                {
                  const [l, b] = E.slice(n, n + 2);
                  v.push((s) => s.lineTo(l, b)), n += 2;
                }
                break;
              case w.FontRenderOps.QUADRATIC_CURVE_TO:
                {
                  const [l, b, s, g] = E.slice(n, n + 4);
                  v.push((t) => t.quadraticCurveTo(l, b, s, g)), n += 4;
                }
                break;
              case w.FontRenderOps.RESTORE:
                v.push((l) => l.restore());
                break;
              case w.FontRenderOps.SAVE:
                v.push((l) => l.save());
                break;
              case w.FontRenderOps.SCALE:
                (0, w.assert)(v.length === 2, "Scale command is only valid at the third position.");
                break;
              case w.FontRenderOps.TRANSFORM:
                {
                  const [l, b, s, g, t, i] = E.slice(n, n + 6);
                  v.push((d) => d.transform(l, b, s, g, t, i)), n += 6;
                }
                break;
              case w.FontRenderOps.TRANSLATE:
                {
                  const [l, b] = E.slice(n, n + 2);
                  v.push((s) => s.translate(l, b)), n += 2;
                }
                break;
            }
          return this.compiledGlyphs[T] = function(c, l) {
            v[0](c), v[1](c), c.scale(l, -l);
            for (let b = 2, s = v.length; b < s; b++)
              v[b](c);
          };
        }
      }
    })
  ),
  /***/
  62: (
    /***/
    ((ct, st, V) => {
      V.d(st, {
        /* harmony export */
        Metadata: () => (
          /* binding */
          B
        )
        /* harmony export */
      });
      var w = V(292);
      class B {
        #t;
        #e;
        constructor({
          parsedData: U,
          rawData: P
        }) {
          this.#t = U, this.#e = P;
        }
        getRaw() {
          return this.#e;
        }
        get(U) {
          return this.#t.get(U) ?? null;
        }
        getAll() {
          return (0, w.objectFromMap)(this.#t);
        }
        has(U) {
          return this.#t.has(U);
        }
      }
    })
  ),
  /***/
  457: (
    /***/
    ((ct, st, V) => {
      V.d(st, {
        /* harmony export */
        PDFNetworkStream: () => (
          /* binding */
          E
        )
        /* harmony export */
      });
      var w = V(292), B = V(490);
      const _ = 200, U = 206;
      function P(c) {
        const l = c.response;
        return typeof l != "string" ? l : (0, w.stringToBytes)(l).buffer;
      }
      class T {
        constructor(l, b = {}) {
          this.url = l, this.isHttp = /^https?:/i.test(l), this.httpHeaders = this.isHttp && b.httpHeaders || /* @__PURE__ */ Object.create(null), this.withCredentials = b.withCredentials || !1, this.currXhrId = 0, this.pendingRequests = /* @__PURE__ */ Object.create(null);
        }
        requestRange(l, b, s) {
          const g = {
            begin: l,
            end: b
          };
          for (const t in s)
            g[t] = s[t];
          return this.request(g);
        }
        requestFull(l) {
          return this.request(l);
        }
        request(l) {
          const b = new XMLHttpRequest(), s = this.currXhrId++, g = this.pendingRequests[s] = {
            xhr: b
          };
          b.open("GET", this.url), b.withCredentials = this.withCredentials;
          for (const t in this.httpHeaders) {
            const i = this.httpHeaders[t];
            i !== void 0 && b.setRequestHeader(t, i);
          }
          return this.isHttp && "begin" in l && "end" in l ? (b.setRequestHeader("Range", `bytes=${l.begin}-${l.end - 1}`), g.expectedStatus = U) : g.expectedStatus = _, b.responseType = "arraybuffer", l.onError && (b.onerror = function(t) {
            l.onError(b.status);
          }), b.onreadystatechange = this.onStateChange.bind(this, s), b.onprogress = this.onProgress.bind(this, s), g.onHeadersReceived = l.onHeadersReceived, g.onDone = l.onDone, g.onError = l.onError, g.onProgress = l.onProgress, b.send(null), s;
        }
        onProgress(l, b) {
          const s = this.pendingRequests[l];
          s && s.onProgress?.(b);
        }
        onStateChange(l, b) {
          const s = this.pendingRequests[l];
          if (!s)
            return;
          const g = s.xhr;
          if (g.readyState >= 2 && s.onHeadersReceived && (s.onHeadersReceived(), delete s.onHeadersReceived), g.readyState !== 4 || !(l in this.pendingRequests))
            return;
          if (delete this.pendingRequests[l], g.status === 0 && this.isHttp) {
            s.onError?.(g.status);
            return;
          }
          const t = g.status || _;
          if (!(t === _ && s.expectedStatus === U) && t !== s.expectedStatus) {
            s.onError?.(g.status);
            return;
          }
          const d = P(g);
          if (t === U) {
            const f = g.getResponseHeader("Content-Range"), y = /bytes (\d+)-(\d+)\/(\d+)/.exec(f);
            s.onDone({
              begin: parseInt(y[1], 10),
              chunk: d
            });
          } else d ? s.onDone({
            begin: 0,
            chunk: d
          }) : s.onError?.(g.status);
        }
        getRequestXhr(l) {
          return this.pendingRequests[l].xhr;
        }
        isPendingRequest(l) {
          return l in this.pendingRequests;
        }
        abortRequest(l) {
          const b = this.pendingRequests[l].xhr;
          delete this.pendingRequests[l], b.abort();
        }
      }
      class E {
        constructor(l) {
          this._source = l, this._manager = new T(l.url, {
            httpHeaders: l.httpHeaders,
            withCredentials: l.withCredentials
          }), this._rangeChunkSize = l.rangeChunkSize, this._fullRequestReader = null, this._rangeRequestReaders = [];
        }
        _onRangeRequestReaderClosed(l) {
          const b = this._rangeRequestReaders.indexOf(l);
          b >= 0 && this._rangeRequestReaders.splice(b, 1);
        }
        getFullReader() {
          return (0, w.assert)(!this._fullRequestReader, "PDFNetworkStream.getFullReader can only be called once."), this._fullRequestReader = new v(this._manager, this._source), this._fullRequestReader;
        }
        getRangeReader(l, b) {
          const s = new n(this._manager, l, b);
          return s.onClosed = this._onRangeRequestReaderClosed.bind(this), this._rangeRequestReaders.push(s), s;
        }
        cancelAllRequests(l) {
          this._fullRequestReader?.cancel(l);
          for (const b of this._rangeRequestReaders.slice(0))
            b.cancel(l);
        }
      }
      class v {
        constructor(l, b) {
          this._manager = l;
          const s = {
            onHeadersReceived: this._onHeadersReceived.bind(this),
            onDone: this._onDone.bind(this),
            onError: this._onError.bind(this),
            onProgress: this._onProgress.bind(this)
          };
          this._url = b.url, this._fullRequestId = l.requestFull(s), this._headersReceivedCapability = Promise.withResolvers(), this._disableRange = b.disableRange || !1, this._contentLength = b.length, this._rangeChunkSize = b.rangeChunkSize, !this._rangeChunkSize && !this._disableRange && (this._disableRange = !0), this._isStreamingSupported = !1, this._isRangeSupported = !1, this._cachedChunks = [], this._requests = [], this._done = !1, this._storedError = void 0, this._filename = null, this.onProgress = null;
        }
        _onHeadersReceived() {
          const l = this._fullRequestId, b = this._manager.getRequestXhr(l), s = (i) => b.getResponseHeader(i), {
            allowRangeRequests: g,
            suggestedLength: t
          } = (0, B.validateRangeRequestCapabilities)({
            getResponseHeader: s,
            isHttp: this._manager.isHttp,
            rangeChunkSize: this._rangeChunkSize,
            disableRange: this._disableRange
          });
          g && (this._isRangeSupported = !0), this._contentLength = t || this._contentLength, this._filename = (0, B.extractFilenameFromHeader)(s), this._isRangeSupported && this._manager.abortRequest(l), this._headersReceivedCapability.resolve();
        }
        _onDone(l) {
          if (l && (this._requests.length > 0 ? this._requests.shift().resolve({
            value: l.chunk,
            done: !1
          }) : this._cachedChunks.push(l.chunk)), this._done = !0, !(this._cachedChunks.length > 0)) {
            for (const b of this._requests)
              b.resolve({
                value: void 0,
                done: !0
              });
            this._requests.length = 0;
          }
        }
        _onError(l) {
          this._storedError = (0, B.createResponseStatusError)(l, this._url), this._headersReceivedCapability.reject(this._storedError);
          for (const b of this._requests)
            b.reject(this._storedError);
          this._requests.length = 0, this._cachedChunks.length = 0;
        }
        _onProgress(l) {
          this.onProgress?.({
            loaded: l.loaded,
            total: l.lengthComputable ? l.total : this._contentLength
          });
        }
        get filename() {
          return this._filename;
        }
        get isRangeSupported() {
          return this._isRangeSupported;
        }
        get isStreamingSupported() {
          return this._isStreamingSupported;
        }
        get contentLength() {
          return this._contentLength;
        }
        get headersReady() {
          return this._headersReceivedCapability.promise;
        }
        async read() {
          if (this._storedError)
            throw this._storedError;
          if (this._cachedChunks.length > 0)
            return {
              value: this._cachedChunks.shift(),
              done: !1
            };
          if (this._done)
            return {
              value: void 0,
              done: !0
            };
          const l = Promise.withResolvers();
          return this._requests.push(l), l.promise;
        }
        cancel(l) {
          this._done = !0, this._headersReceivedCapability.reject(l);
          for (const b of this._requests)
            b.resolve({
              value: void 0,
              done: !0
            });
          this._requests.length = 0, this._manager.isPendingRequest(this._fullRequestId) && this._manager.abortRequest(this._fullRequestId), this._fullRequestReader = null;
        }
      }
      class n {
        constructor(l, b, s) {
          this._manager = l;
          const g = {
            onDone: this._onDone.bind(this),
            onError: this._onError.bind(this),
            onProgress: this._onProgress.bind(this)
          };
          this._url = l.url, this._requestId = l.requestRange(b, s, g), this._requests = [], this._queuedChunk = null, this._done = !1, this._storedError = void 0, this.onProgress = null, this.onClosed = null;
        }
        _close() {
          this.onClosed?.(this);
        }
        _onDone(l) {
          const b = l.chunk;
          this._requests.length > 0 ? this._requests.shift().resolve({
            value: b,
            done: !1
          }) : this._queuedChunk = b, this._done = !0;
          for (const s of this._requests)
            s.resolve({
              value: void 0,
              done: !0
            });
          this._requests.length = 0, this._close();
        }
        _onError(l) {
          this._storedError = (0, B.createResponseStatusError)(l, this._url);
          for (const b of this._requests)
            b.reject(this._storedError);
          this._requests.length = 0, this._queuedChunk = null;
        }
        _onProgress(l) {
          this.isStreamingSupported || this.onProgress?.({
            loaded: l.loaded
          });
        }
        get isStreamingSupported() {
          return !1;
        }
        async read() {
          if (this._storedError)
            throw this._storedError;
          if (this._queuedChunk !== null) {
            const b = this._queuedChunk;
            return this._queuedChunk = null, {
              value: b,
              done: !1
            };
          }
          if (this._done)
            return {
              value: void 0,
              done: !0
            };
          const l = Promise.withResolvers();
          return this._requests.push(l), l.promise;
        }
        cancel(l) {
          this._done = !0;
          for (const b of this._requests)
            b.resolve({
              value: void 0,
              done: !0
            });
          this._requests.length = 0, this._manager.isPendingRequest(this._requestId) && this._manager.abortRequest(this._requestId), this._close();
        }
      }
    })
  ),
  /***/
  490: (
    /***/
    ((ct, st, V) => {
      V.d(st, {
        createResponseStatusError: () => (
          /* binding */
          T
        ),
        extractFilenameFromHeader: () => (
          /* binding */
          P
        ),
        validateRangeRequestCapabilities: () => (
          /* binding */
          U
        ),
        validateResponseStatus: () => (
          /* binding */
          E
        )
      });
      var w = V(292);
      function B(v) {
        let n = !0, c = l("filename\\*", "i").exec(v);
        if (c) {
          c = c[1];
          let f = t(c);
          return f = unescape(f), f = i(f), f = d(f), s(f);
        }
        if (c = g(v), c) {
          const f = d(c);
          return s(f);
        }
        if (c = l("filename", "i").exec(v), c) {
          c = c[1];
          let f = t(c);
          return f = d(f), s(f);
        }
        function l(f, y) {
          return new RegExp("(?:^|;)\\s*" + f + '\\s*=\\s*([^";\\s][^;\\s]*|"(?:[^"\\\\]|\\\\"?)+"?)', y);
        }
        function b(f, y) {
          if (f) {
            if (!/^[\x00-\xFF]+$/.test(y))
              return y;
            try {
              const S = new TextDecoder(f, {
                fatal: !0
              }), L = (0, w.stringToBytes)(y);
              y = S.decode(L), n = !1;
            } catch {
            }
          }
          return y;
        }
        function s(f) {
          return n && /[\x80-\xff]/.test(f) && (f = b("utf-8", f), n && (f = b("iso-8859-1", f))), f;
        }
        function g(f) {
          const y = [];
          let S;
          const L = l("filename\\*((?!0\\d)\\d+)(\\*?)", "ig");
          for (; (S = L.exec(f)) !== null; ) {
            let [, N, H, z] = S;
            if (N = parseInt(N, 10), N in y) {
              if (N === 0)
                break;
              continue;
            }
            y[N] = [H, z];
          }
          const M = [];
          for (let N = 0; N < y.length && N in y; ++N) {
            let [H, z] = y[N];
            z = t(z), H && (z = unescape(z), N === 0 && (z = i(z))), M.push(z);
          }
          return M.join("");
        }
        function t(f) {
          if (f.startsWith('"')) {
            const y = f.slice(1).split('\\"');
            for (let S = 0; S < y.length; ++S) {
              const L = y[S].indexOf('"');
              L !== -1 && (y[S] = y[S].slice(0, L), y.length = S + 1), y[S] = y[S].replaceAll(/\\(.)/g, "$1");
            }
            f = y.join('"');
          }
          return f;
        }
        function i(f) {
          const y = f.indexOf("'");
          if (y === -1)
            return f;
          const S = f.slice(0, y), M = f.slice(y + 1).replace(/^[^']*'/, "");
          return b(S, M);
        }
        function d(f) {
          return !f.startsWith("=?") || /[\x00-\x19\x80-\xff]/.test(f) ? f : f.replaceAll(/=\?([\w-]*)\?([QqBb])\?((?:[^?]|\?(?!=))*)\?=/g, function(y, S, L, M) {
            if (L === "q" || L === "Q")
              return M = M.replaceAll("_", " "), M = M.replaceAll(/=([0-9a-fA-F]{2})/g, function(N, H) {
                return String.fromCharCode(parseInt(H, 16));
              }), b(S, M);
            try {
              M = atob(M);
            } catch {
            }
            return b(S, M);
          });
        }
        return "";
      }
      var _ = V(419);
      function U({
        getResponseHeader: v,
        isHttp: n,
        rangeChunkSize: c,
        disableRange: l
      }) {
        const b = {
          allowRangeRequests: !1,
          suggestedLength: void 0
        }, s = parseInt(v("Content-Length"), 10);
        return !Number.isInteger(s) || (b.suggestedLength = s, s <= 2 * c) || l || !n || v("Accept-Ranges") !== "bytes" || (v("Content-Encoding") || "identity") !== "identity" || (b.allowRangeRequests = !0), b;
      }
      function P(v) {
        const n = v("Content-Disposition");
        if (n) {
          let c = B(n);
          if (c.includes("%"))
            try {
              c = decodeURIComponent(c);
            } catch {
            }
          if ((0, _.isPdfFile)(c))
            return c;
        }
        return null;
      }
      function T(v, n) {
        return v === 404 || v === 0 && n.startsWith("file:") ? new w.MissingPDFException('Missing PDF "' + n + '".') : new w.UnexpectedResponseException(`Unexpected server response (${v}) while retrieving PDF "${n}".`, v);
      }
      function E(v) {
        return v === 200 || v === 206;
      }
    })
  ),
  /***/
  786: (
    /***/
    ((ct, st, V) => {
      V.a(ct, async (w, B) => {
        try {
          let c = function(y) {
            const S = v.parse(y);
            return S.protocol === "file:" || S.host ? S : /^[a-z]:[/\\]/i.test(y) ? v.parse(`file:///${y}`) : (S.host || (S.protocol = "file:"), S);
          }, g = function(y, S) {
            return {
              protocol: y.protocol,
              auth: y.auth,
              host: y.hostname,
              port: y.port,
              path: y.path,
              method: "GET",
              headers: S
            };
          };
          V.d(st, {
            /* harmony export */
            PDFNodeStream: () => (
              /* binding */
              l
            )
            /* harmony export */
          });
          var _ = V(292), U = V(490);
          let P, T, E, v;
          _.isNodeJS && (P = await import(
            /*webpackIgnore: true*/
            "./__vite-browser-external-DYxpcVy9.js"
          ), T = await import(
            /*webpackIgnore: true*/
            "./__vite-browser-external-DYxpcVy9.js"
          ), E = await import(
            /*webpackIgnore: true*/
            "./__vite-browser-external-DYxpcVy9.js"
          ), v = await import(
            /*webpackIgnore: true*/
            "./__vite-browser-external-DYxpcVy9.js"
          ));
          const n = /^file:\/\/\/[a-zA-Z]:\//;
          class l {
            constructor(S) {
              this.source = S, this.url = c(S.url), this.isHttp = this.url.protocol === "http:" || this.url.protocol === "https:", this.isFsUrl = this.url.protocol === "file:", this.httpHeaders = this.isHttp && S.httpHeaders || {}, this._fullRequestReader = null, this._rangeRequestReaders = [];
            }
            get _progressiveDataLength() {
              return this._fullRequestReader?._loaded ?? 0;
            }
            getFullReader() {
              return (0, _.assert)(!this._fullRequestReader, "PDFNodeStream.getFullReader can only be called once."), this._fullRequestReader = this.isFsUrl ? new d(this) : new t(this), this._fullRequestReader;
            }
            getRangeReader(S, L) {
              if (L <= this._progressiveDataLength)
                return null;
              const M = this.isFsUrl ? new f(this, S, L) : new i(this, S, L);
              return this._rangeRequestReaders.push(M), M;
            }
            cancelAllRequests(S) {
              this._fullRequestReader?.cancel(S);
              for (const L of this._rangeRequestReaders.slice(0))
                L.cancel(S);
            }
          }
          class b {
            constructor(S) {
              this._url = S.url, this._done = !1, this._storedError = null, this.onProgress = null;
              const L = S.source;
              this._contentLength = L.length, this._loaded = 0, this._filename = null, this._disableRange = L.disableRange || !1, this._rangeChunkSize = L.rangeChunkSize, !this._rangeChunkSize && !this._disableRange && (this._disableRange = !0), this._isStreamingSupported = !L.disableStream, this._isRangeSupported = !L.disableRange, this._readableStream = null, this._readCapability = Promise.withResolvers(), this._headersCapability = Promise.withResolvers();
            }
            get headersReady() {
              return this._headersCapability.promise;
            }
            get filename() {
              return this._filename;
            }
            get contentLength() {
              return this._contentLength;
            }
            get isRangeSupported() {
              return this._isRangeSupported;
            }
            get isStreamingSupported() {
              return this._isStreamingSupported;
            }
            async read() {
              if (await this._readCapability.promise, this._done)
                return {
                  value: void 0,
                  done: !0
                };
              if (this._storedError)
                throw this._storedError;
              const S = this._readableStream.read();
              return S === null ? (this._readCapability = Promise.withResolvers(), this.read()) : (this._loaded += S.length, this.onProgress?.({
                loaded: this._loaded,
                total: this._contentLength
              }), {
                value: new Uint8Array(S).buffer,
                done: !1
              });
            }
            cancel(S) {
              if (!this._readableStream) {
                this._error(S);
                return;
              }
              this._readableStream.destroy(S);
            }
            _error(S) {
              this._storedError = S, this._readCapability.resolve();
            }
            _setReadableStream(S) {
              this._readableStream = S, S.on("readable", () => {
                this._readCapability.resolve();
              }), S.on("end", () => {
                S.destroy(), this._done = !0, this._readCapability.resolve();
              }), S.on("error", (L) => {
                this._error(L);
              }), !this._isStreamingSupported && this._isRangeSupported && this._error(new _.AbortException("streaming is disabled")), this._storedError && this._readableStream.destroy(this._storedError);
            }
          }
          class s {
            constructor(S) {
              this._url = S.url, this._done = !1, this._storedError = null, this.onProgress = null, this._loaded = 0, this._readableStream = null, this._readCapability = Promise.withResolvers();
              const L = S.source;
              this._isStreamingSupported = !L.disableStream;
            }
            get isStreamingSupported() {
              return this._isStreamingSupported;
            }
            async read() {
              if (await this._readCapability.promise, this._done)
                return {
                  value: void 0,
                  done: !0
                };
              if (this._storedError)
                throw this._storedError;
              const S = this._readableStream.read();
              return S === null ? (this._readCapability = Promise.withResolvers(), this.read()) : (this._loaded += S.length, this.onProgress?.({
                loaded: this._loaded
              }), {
                value: new Uint8Array(S).buffer,
                done: !1
              });
            }
            cancel(S) {
              if (!this._readableStream) {
                this._error(S);
                return;
              }
              this._readableStream.destroy(S);
            }
            _error(S) {
              this._storedError = S, this._readCapability.resolve();
            }
            _setReadableStream(S) {
              this._readableStream = S, S.on("readable", () => {
                this._readCapability.resolve();
              }), S.on("end", () => {
                S.destroy(), this._done = !0, this._readCapability.resolve();
              }), S.on("error", (L) => {
                this._error(L);
              }), this._storedError && this._readableStream.destroy(this._storedError);
            }
          }
          class t extends b {
            constructor(S) {
              super(S);
              const L = (M) => {
                if (M.statusCode === 404) {
                  const q = new _.MissingPDFException(`Missing PDF "${this._url}".`);
                  this._storedError = q, this._headersCapability.reject(q);
                  return;
                }
                this._headersCapability.resolve(), this._setReadableStream(M);
                const N = (q) => this._readableStream.headers[q.toLowerCase()], {
                  allowRangeRequests: H,
                  suggestedLength: z
                } = (0, U.validateRangeRequestCapabilities)({
                  getResponseHeader: N,
                  isHttp: S.isHttp,
                  rangeChunkSize: this._rangeChunkSize,
                  disableRange: this._disableRange
                });
                this._isRangeSupported = H, this._contentLength = z || this._contentLength, this._filename = (0, U.extractFilenameFromHeader)(N);
              };
              this._request = null, this._url.protocol === "http:" ? this._request = T.request(g(this._url, S.httpHeaders), L) : this._request = E.request(g(this._url, S.httpHeaders), L), this._request.on("error", (M) => {
                this._storedError = M, this._headersCapability.reject(M);
              }), this._request.end();
            }
          }
          class i extends s {
            constructor(S, L, M) {
              super(S), this._httpHeaders = {};
              for (const H in S.httpHeaders) {
                const z = S.httpHeaders[H];
                z !== void 0 && (this._httpHeaders[H] = z);
              }
              this._httpHeaders.Range = `bytes=${L}-${M - 1}`;
              const N = (H) => {
                if (H.statusCode === 404) {
                  const z = new _.MissingPDFException(`Missing PDF "${this._url}".`);
                  this._storedError = z;
                  return;
                }
                this._setReadableStream(H);
              };
              this._request = null, this._url.protocol === "http:" ? this._request = T.request(g(this._url, this._httpHeaders), N) : this._request = E.request(g(this._url, this._httpHeaders), N), this._request.on("error", (H) => {
                this._storedError = H;
              }), this._request.end();
            }
          }
          class d extends b {
            constructor(S) {
              super(S);
              let L = decodeURIComponent(this._url.path);
              n.test(this._url.href) && (L = L.replace(/^\//, "")), P.promises.lstat(L).then((M) => {
                this._contentLength = M.size, this._setReadableStream(P.createReadStream(L)), this._headersCapability.resolve();
              }, (M) => {
                M.code === "ENOENT" && (M = new _.MissingPDFException(`Missing PDF "${L}".`)), this._storedError = M, this._headersCapability.reject(M);
              });
            }
          }
          class f extends s {
            constructor(S, L, M) {
              super(S);
              let N = decodeURIComponent(this._url.path);
              n.test(this._url.href) && (N = N.replace(/^\//, "")), this._setReadableStream(P.createReadStream(N, {
                start: L,
                end: M - 1
              }));
            }
          }
          B();
        } catch (P) {
          B(P);
        }
      }, 1);
    })
  ),
  /***/
  573: (
    /***/
    ((ct, st, V) => {
      V.a(ct, async (w, B) => {
        try {
          V.d(st, {
            /* harmony export */
            NodeCMapReaderFactory: () => (
              /* binding */
              l
            ),
            /* harmony export */
            NodeCanvasFactory: () => (
              /* binding */
              c
            ),
            /* harmony export */
            NodeFilterFactory: () => (
              /* binding */
              n
            ),
            /* harmony export */
            NodeStandardFontDataFactory: () => (
              /* binding */
              b
            )
            /* harmony export */
          });
          var _ = V(583), U = V(292);
          let P, T, E;
          if (U.isNodeJS) {
            P = await import(
              /*webpackIgnore: true*/
              "./__vite-browser-external-DYxpcVy9.js"
            );
            try {
              T = await import(
                /*webpackIgnore: true*/
                "./__vite-browser-external-DYxpcVy9.js"
              );
            } catch {
            }
            try {
              E = await import(
                /*webpackIgnore: true*/
                "./index-Dwr47WtL.js"
              );
            } catch {
            }
          }
          const v = function(s) {
            return P.promises.readFile(s).then((g) => new Uint8Array(g));
          };
          class n extends _.BaseFilterFactory {
          }
          class c extends _.BaseCanvasFactory {
            _createCanvas(g, t) {
              return T.createCanvas(g, t);
            }
          }
          class l extends _.BaseCMapReaderFactory {
            _fetchData(g, t) {
              return v(g).then((i) => ({
                cMapData: i,
                compressionType: t
              }));
            }
          }
          class b extends _.BaseStandardFontDataFactory {
            _fetchData(g) {
              return v(g);
            }
          }
          B();
        } catch (P) {
          B(P);
        }
      }, 1);
    })
  ),
  /***/
  626: (
    /***/
    ((ct, st, V) => {
      V.d(st, {
        /* harmony export */
        OptionalContentConfig: () => (
          /* binding */
          P
        )
        /* harmony export */
      });
      var w = V(292), B = V(651);
      const _ = Symbol("INTERNAL");
      class U {
        #t = !1;
        #e = !1;
        #s = !1;
        #n = !0;
        constructor(E, {
          name: v,
          intent: n,
          usage: c
        }) {
          this.#t = !!(E & w.RenderingIntentFlag.DISPLAY), this.#e = !!(E & w.RenderingIntentFlag.PRINT), this.name = v, this.intent = n, this.usage = c;
        }
        get visible() {
          if (this.#s)
            return this.#n;
          if (!this.#n)
            return !1;
          const {
            print: E,
            view: v
          } = this.usage;
          return this.#t ? v?.viewState !== "OFF" : this.#e ? E?.printState !== "OFF" : !0;
        }
        _setVisible(E, v, n = !1) {
          E !== _ && (0, w.unreachable)("Internal method `_setVisible` called."), this.#s = n, this.#n = v;
        }
      }
      class P {
        #t = null;
        #e = /* @__PURE__ */ new Map();
        #s = null;
        #n = null;
        constructor(E, v = w.RenderingIntentFlag.DISPLAY) {
          if (this.renderingIntent = v, this.name = null, this.creator = null, E !== null) {
            this.name = E.name, this.creator = E.creator, this.#n = E.order;
            for (const n of E.groups)
              this.#e.set(n.id, new U(v, n));
            if (E.baseState === "OFF")
              for (const n of this.#e.values())
                n._setVisible(_, !1);
            for (const n of E.on)
              this.#e.get(n)._setVisible(_, !0);
            for (const n of E.off)
              this.#e.get(n)._setVisible(_, !1);
            this.#s = this.getHash();
          }
        }
        #r(E) {
          const v = E.length;
          if (v < 2)
            return !0;
          const n = E[0];
          for (let c = 1; c < v; c++) {
            const l = E[c];
            let b;
            if (Array.isArray(l))
              b = this.#r(l);
            else if (this.#e.has(l))
              b = this.#e.get(l).visible;
            else
              return (0, w.warn)(`Optional content group not found: ${l}`), !0;
            switch (n) {
              case "And":
                if (!b)
                  return !1;
                break;
              case "Or":
                if (b)
                  return !0;
                break;
              case "Not":
                return !b;
              default:
                return !0;
            }
          }
          return n === "And";
        }
        isVisible(E) {
          if (this.#e.size === 0)
            return !0;
          if (!E)
            return (0, w.info)("Optional content group not defined."), !0;
          if (E.type === "OCG")
            return this.#e.has(E.id) ? this.#e.get(E.id).visible : ((0, w.warn)(`Optional content group not found: ${E.id}`), !0);
          if (E.type === "OCMD") {
            if (E.expression)
              return this.#r(E.expression);
            if (!E.policy || E.policy === "AnyOn") {
              for (const v of E.ids) {
                if (!this.#e.has(v))
                  return (0, w.warn)(`Optional content group not found: ${v}`), !0;
                if (this.#e.get(v).visible)
                  return !0;
              }
              return !1;
            } else if (E.policy === "AllOn") {
              for (const v of E.ids) {
                if (!this.#e.has(v))
                  return (0, w.warn)(`Optional content group not found: ${v}`), !0;
                if (!this.#e.get(v).visible)
                  return !1;
              }
              return !0;
            } else if (E.policy === "AnyOff") {
              for (const v of E.ids) {
                if (!this.#e.has(v))
                  return (0, w.warn)(`Optional content group not found: ${v}`), !0;
                if (!this.#e.get(v).visible)
                  return !0;
              }
              return !1;
            } else if (E.policy === "AllOff") {
              for (const v of E.ids) {
                if (!this.#e.has(v))
                  return (0, w.warn)(`Optional content group not found: ${v}`), !0;
                if (this.#e.get(v).visible)
                  return !1;
              }
              return !0;
            }
            return (0, w.warn)(`Unknown optional content policy ${E.policy}.`), !0;
          }
          return (0, w.warn)(`Unknown group type ${E.type}.`), !0;
        }
        setVisibility(E, v = !0) {
          const n = this.#e.get(E);
          if (!n) {
            (0, w.warn)(`Optional content group not found: ${E}`);
            return;
          }
          n._setVisible(_, !!v, !0), this.#t = null;
        }
        setOCGState({
          state: E,
          preserveRB: v
        }) {
          let n;
          for (const c of E) {
            switch (c) {
              case "ON":
              case "OFF":
              case "Toggle":
                n = c;
                continue;
            }
            const l = this.#e.get(c);
            if (l)
              switch (n) {
                case "ON":
                  l._setVisible(_, !0);
                  break;
                case "OFF":
                  l._setVisible(_, !1);
                  break;
                case "Toggle":
                  l._setVisible(_, !l.visible);
                  break;
              }
          }
          this.#t = null;
        }
        get hasInitialVisibility() {
          return this.#s === null || this.getHash() === this.#s;
        }
        getOrder() {
          return this.#e.size ? this.#n ? this.#n.slice() : [...this.#e.keys()] : null;
        }
        getGroups() {
          return this.#e.size > 0 ? (0, w.objectFromMap)(this.#e) : null;
        }
        getGroup(E) {
          return this.#e.get(E) || null;
        }
        getHash() {
          if (this.#t !== null)
            return this.#t;
          const E = new B.MurmurHash3_64();
          for (const [v, n] of this.#e)
            E.update(`${v}:${n.visible}`);
          return this.#t = E.hexdigest();
        }
      }
    })
  ),
  /***/
  814: (
    /***/
    ((ct, st, V) => {
      V.d(st, {
        /* harmony export */
        cleanupTextLayer: () => (
          /* binding */
          n
        ),
        /* harmony export */
        renderTextLayer: () => (
          /* binding */
          t
        ),
        /* harmony export */
        updateTextLayer: () => (
          /* binding */
          i
        )
        /* harmony export */
      });
      var w = V(292), B = V(419);
      const _ = 1e5, U = 30, P = 0.8, T = /* @__PURE__ */ new Map();
      let E = null;
      function v() {
        if (!E) {
          const d = document.createElement("canvas");
          d.className = "hiddenCanvasElement", document.body.append(d), E = d.getContext("2d", {
            alpha: !1
          });
        }
        return E;
      }
      function n() {
        E?.canvas.remove(), E = null;
      }
      function c(d) {
        const f = T.get(d);
        if (f)
          return f;
        const y = v(), S = y.font;
        y.canvas.width = y.canvas.height = U, y.font = `${U}px ${d}`;
        const L = y.measureText("");
        let M = L.fontBoundingBoxAscent, N = Math.abs(L.fontBoundingBoxDescent);
        if (M) {
          const z = M / (M + N);
          return T.set(d, z), y.canvas.width = y.canvas.height = 0, y.font = S, z;
        }
        y.strokeStyle = "red", y.clearRect(0, 0, U, U), y.strokeText("g", 0, 0);
        let H = y.getImageData(0, 0, U, U).data;
        N = 0;
        for (let z = H.length - 1 - 3; z >= 0; z -= 4)
          if (H[z] > 0) {
            N = Math.ceil(z / 4 / U);
            break;
          }
        y.clearRect(0, 0, U, U), y.strokeText("A", 0, U), H = y.getImageData(0, 0, U, U).data, M = 0;
        for (let z = 0, q = H.length; z < q; z += 4)
          if (H[z] > 0) {
            M = U - Math.floor(z / 4 / U);
            break;
          }
        if (y.canvas.width = y.canvas.height = 0, y.font = S, M) {
          const z = M / (M + N);
          return T.set(d, z), z;
        }
        return T.set(d, P), P;
      }
      function l(d, f, y) {
        const S = document.createElement("span"), L = {
          angle: 0,
          canvasWidth: 0,
          hasText: f.str !== "",
          hasEOL: f.hasEOL,
          fontSize: 0
        };
        d._textDivs.push(S);
        const M = w.Util.transform(d._transform, f.transform);
        let N = Math.atan2(M[1], M[0]);
        const H = y[f.fontName];
        H.vertical && (N += Math.PI / 2);
        const z = d._fontInspectorEnabled && H.fontSubstitution || H.fontFamily, q = Math.hypot(M[2], M[3]), nt = q * c(z);
        let j, O;
        N === 0 ? (j = M[4], O = M[5] - nt) : (j = M[4] + nt * Math.sin(N), O = M[5] - nt * Math.cos(N));
        const G = "calc(var(--scale-factor)*", Y = S.style;
        d._container === d._rootContainer ? (Y.left = `${(100 * j / d._pageWidth).toFixed(2)}%`, Y.top = `${(100 * O / d._pageHeight).toFixed(2)}%`) : (Y.left = `${G}${j.toFixed(2)}px)`, Y.top = `${G}${O.toFixed(2)}px)`), Y.fontSize = `${G}${q.toFixed(2)}px)`, Y.fontFamily = z, L.fontSize = q, S.setAttribute("role", "presentation"), S.textContent = f.str, S.dir = f.dir, d._fontInspectorEnabled && (S.dataset.fontName = H.fontSubstitutionLoadedName || f.fontName), N !== 0 && (L.angle = N * (180 / Math.PI));
        let tt = !1;
        if (f.str.length > 1)
          tt = !0;
        else if (f.str !== " " && f.transform[0] !== f.transform[3]) {
          const Z = Math.abs(f.transform[0]), at = Math.abs(f.transform[3]);
          Z !== at && Math.max(Z, at) / Math.min(Z, at) > 1.5 && (tt = !0);
        }
        tt && (L.canvasWidth = H.vertical ? f.height : f.width), d._textDivProperties.set(S, L), d._isReadableStream && d._layoutText(S);
      }
      function b(d) {
        const {
          div: f,
          scale: y,
          properties: S,
          ctx: L,
          prevFontSize: M,
          prevFontFamily: N
        } = d, {
          style: H
        } = f;
        let z = "";
        if (S.canvasWidth !== 0 && S.hasText) {
          const {
            fontFamily: q
          } = H, {
            canvasWidth: nt,
            fontSize: j
          } = S;
          (M !== j || N !== q) && (L.font = `${j * y}px ${q}`, d.prevFontSize = j, d.prevFontFamily = q);
          const {
            width: O
          } = L.measureText(f.textContent);
          O > 0 && (z = `scaleX(${nt * y / O})`);
        }
        S.angle !== 0 && (z = `rotate(${S.angle}deg) ${z}`), z.length > 0 && (H.transform = z);
      }
      function s(d) {
        if (d._canceled)
          return;
        const f = d._textDivs, y = d._capability;
        if (f.length > _) {
          y.resolve();
          return;
        }
        if (!d._isReadableStream)
          for (const L of f)
            d._layoutText(L);
        y.resolve();
      }
      class g {
        constructor({
          textContentSource: f,
          container: y,
          viewport: S,
          textDivs: L,
          textDivProperties: M,
          textContentItemsStr: N
        }) {
          this._textContentSource = f, this._isReadableStream = f instanceof ReadableStream, this._container = this._rootContainer = y, this._textDivs = L || [], this._textContentItemsStr = N || [], this._fontInspectorEnabled = !!globalThis.FontInspector?.enabled, this._reader = null, this._textDivProperties = M || /* @__PURE__ */ new WeakMap(), this._canceled = !1, this._capability = Promise.withResolvers(), this._layoutTextParams = {
            prevFontSize: null,
            prevFontFamily: null,
            div: null,
            scale: S.scale * (globalThis.devicePixelRatio || 1),
            properties: null,
            ctx: v()
          };
          const {
            pageWidth: H,
            pageHeight: z,
            pageX: q,
            pageY: nt
          } = S.rawDims;
          this._transform = [1, 0, 0, -1, -q, nt + z], this._pageWidth = H, this._pageHeight = z, (0, B.setLayerDimensions)(y, S), this._capability.promise.finally(() => {
            this._layoutTextParams = null;
          }).catch(() => {
          });
        }
        get promise() {
          return this._capability.promise;
        }
        cancel() {
          this._canceled = !0, this._reader && (this._reader.cancel(new w.AbortException("TextLayer task cancelled.")).catch(() => {
          }), this._reader = null), this._capability.reject(new w.AbortException("TextLayer task cancelled."));
        }
        _processItems(f, y) {
          for (const S of f) {
            if (S.str === void 0) {
              if (S.type === "beginMarkedContentProps" || S.type === "beginMarkedContent") {
                const L = this._container;
                this._container = document.createElement("span"), this._container.classList.add("markedContent"), S.id !== null && this._container.setAttribute("id", `${S.id}`), L.append(this._container);
              } else S.type === "endMarkedContent" && (this._container = this._container.parentNode);
              continue;
            }
            this._textContentItemsStr.push(S.str), l(this, S, y);
          }
        }
        _layoutText(f) {
          const y = this._layoutTextParams.properties = this._textDivProperties.get(f);
          if (this._layoutTextParams.div = f, b(this._layoutTextParams), y.hasText && this._container.append(f), y.hasEOL) {
            const S = document.createElement("br");
            S.setAttribute("role", "presentation"), this._container.append(S);
          }
        }
        _render() {
          const {
            promise: f,
            resolve: y,
            reject: S
          } = Promise.withResolvers();
          let L = /* @__PURE__ */ Object.create(null);
          if (this._isReadableStream) {
            const M = () => {
              this._reader.read().then(({
                value: N,
                done: H
              }) => {
                if (H) {
                  y();
                  return;
                }
                Object.assign(L, N.styles), this._processItems(N.items, L), M();
              }, S);
            };
            this._reader = this._textContentSource.getReader(), M();
          } else if (this._textContentSource) {
            const {
              items: M,
              styles: N
            } = this._textContentSource;
            this._processItems(M, N), y();
          } else
            throw new Error('No "textContentSource" parameter specified.');
          f.then(() => {
            L = null, s(this);
          }, this._capability.reject);
        }
      }
      function t(d) {
        const f = new g(d);
        return f._render(), f;
      }
      function i({
        container: d,
        viewport: f,
        textDivs: y,
        textDivProperties: S,
        mustRotate: L = !0,
        mustRescale: M = !0
      }) {
        if (L && (0, B.setLayerDimensions)(d, {
          rotation: f.rotation
        }), M) {
          const N = v(), z = {
            prevFontSize: null,
            prevFontFamily: null,
            div: null,
            scale: f.scale * (globalThis.devicePixelRatio || 1),
            properties: null,
            ctx: N
          };
          for (const q of y)
            z.properties = S.get(q), z.div = q, b(z);
        }
      }
    })
  ),
  /***/
  585: (
    /***/
    ((ct, st, V) => {
      V.d(st, {
        /* harmony export */
        PDFDataTransportStream: () => (
          /* binding */
          _
        )
        /* harmony export */
      });
      var w = V(292), B = V(419);
      class _ {
        constructor(E, {
          disableRange: v = !1,
          disableStream: n = !1
        }) {
          (0, w.assert)(E, 'PDFDataTransportStream - missing required "pdfDataRangeTransport" argument.');
          const {
            length: c,
            initialData: l,
            progressiveDone: b,
            contentDispositionFilename: s
          } = E;
          if (this._queuedChunks = [], this._progressiveDone = b, this._contentDispositionFilename = s, l?.length > 0) {
            const g = l instanceof Uint8Array && l.byteLength === l.buffer.byteLength ? l.buffer : new Uint8Array(l).buffer;
            this._queuedChunks.push(g);
          }
          this._pdfDataRangeTransport = E, this._isStreamingSupported = !n, this._isRangeSupported = !v, this._contentLength = c, this._fullRequestReader = null, this._rangeReaders = [], E.addRangeListener((g, t) => {
            this._onReceiveData({
              begin: g,
              chunk: t
            });
          }), E.addProgressListener((g, t) => {
            this._onProgress({
              loaded: g,
              total: t
            });
          }), E.addProgressiveReadListener((g) => {
            this._onReceiveData({
              chunk: g
            });
          }), E.addProgressiveDoneListener(() => {
            this._onProgressiveDone();
          }), E.transportReady();
        }
        _onReceiveData({
          begin: E,
          chunk: v
        }) {
          const n = v instanceof Uint8Array && v.byteLength === v.buffer.byteLength ? v.buffer : new Uint8Array(v).buffer;
          if (E === void 0)
            this._fullRequestReader ? this._fullRequestReader._enqueue(n) : this._queuedChunks.push(n);
          else {
            const c = this._rangeReaders.some(function(l) {
              return l._begin !== E ? !1 : (l._enqueue(n), !0);
            });
            (0, w.assert)(c, "_onReceiveData - no `PDFDataTransportStreamRangeReader` instance found.");
          }
        }
        get _progressiveDataLength() {
          return this._fullRequestReader?._loaded ?? 0;
        }
        _onProgress(E) {
          E.total === void 0 ? this._rangeReaders[0]?.onProgress?.({
            loaded: E.loaded
          }) : this._fullRequestReader?.onProgress?.({
            loaded: E.loaded,
            total: E.total
          });
        }
        _onProgressiveDone() {
          this._fullRequestReader?.progressiveDone(), this._progressiveDone = !0;
        }
        _removeRangeReader(E) {
          const v = this._rangeReaders.indexOf(E);
          v >= 0 && this._rangeReaders.splice(v, 1);
        }
        getFullReader() {
          (0, w.assert)(!this._fullRequestReader, "PDFDataTransportStream.getFullReader can only be called once.");
          const E = this._queuedChunks;
          return this._queuedChunks = null, new U(this, E, this._progressiveDone, this._contentDispositionFilename);
        }
        getRangeReader(E, v) {
          if (v <= this._progressiveDataLength)
            return null;
          const n = new P(this, E, v);
          return this._pdfDataRangeTransport.requestDataRange(E, v), this._rangeReaders.push(n), n;
        }
        cancelAllRequests(E) {
          this._fullRequestReader?.cancel(E);
          for (const v of this._rangeReaders.slice(0))
            v.cancel(E);
          this._pdfDataRangeTransport.abort();
        }
      }
      class U {
        constructor(E, v, n = !1, c = null) {
          this._stream = E, this._done = n || !1, this._filename = (0, B.isPdfFile)(c) ? c : null, this._queuedChunks = v || [], this._loaded = 0;
          for (const l of this._queuedChunks)
            this._loaded += l.byteLength;
          this._requests = [], this._headersReady = Promise.resolve(), E._fullRequestReader = this, this.onProgress = null;
        }
        _enqueue(E) {
          this._done || (this._requests.length > 0 ? this._requests.shift().resolve({
            value: E,
            done: !1
          }) : this._queuedChunks.push(E), this._loaded += E.byteLength);
        }
        get headersReady() {
          return this._headersReady;
        }
        get filename() {
          return this._filename;
        }
        get isRangeSupported() {
          return this._stream._isRangeSupported;
        }
        get isStreamingSupported() {
          return this._stream._isStreamingSupported;
        }
        get contentLength() {
          return this._stream._contentLength;
        }
        async read() {
          if (this._queuedChunks.length > 0)
            return {
              value: this._queuedChunks.shift(),
              done: !1
            };
          if (this._done)
            return {
              value: void 0,
              done: !0
            };
          const E = Promise.withResolvers();
          return this._requests.push(E), E.promise;
        }
        cancel(E) {
          this._done = !0;
          for (const v of this._requests)
            v.resolve({
              value: void 0,
              done: !0
            });
          this._requests.length = 0;
        }
        progressiveDone() {
          this._done || (this._done = !0);
        }
      }
      class P {
        constructor(E, v, n) {
          this._stream = E, this._begin = v, this._end = n, this._queuedChunk = null, this._requests = [], this._done = !1, this.onProgress = null;
        }
        _enqueue(E) {
          if (!this._done) {
            if (this._requests.length === 0)
              this._queuedChunk = E;
            else {
              this._requests.shift().resolve({
                value: E,
                done: !1
              });
              for (const n of this._requests)
                n.resolve({
                  value: void 0,
                  done: !0
                });
              this._requests.length = 0;
            }
            this._done = !0, this._stream._removeRangeReader(this);
          }
        }
        get isStreamingSupported() {
          return !1;
        }
        async read() {
          if (this._queuedChunk) {
            const v = this._queuedChunk;
            return this._queuedChunk = null, {
              value: v,
              done: !1
            };
          }
          if (this._done)
            return {
              value: void 0,
              done: !0
            };
          const E = Promise.withResolvers();
          return this._requests.push(E), E.promise;
        }
        cancel(E) {
          this._done = !0;
          for (const v of this._requests)
            v.resolve({
              value: void 0,
              done: !0
            });
          this._requests.length = 0, this._stream._removeRangeReader(this);
        }
      }
    })
  ),
  /***/
  164: (
    /***/
    ((ct, st, V) => {
      V.d(st, {
        /* harmony export */
        GlobalWorkerOptions: () => (
          /* binding */
          w
        )
        /* harmony export */
      });
      class w {
        static #t = null;
        static #e = "";
        static get workerPort() {
          return this.#t;
        }
        static set workerPort(_) {
          if (!(typeof Worker < "u" && _ instanceof Worker) && _ !== null)
            throw new Error("Invalid `workerPort` type.");
          this.#t = _;
        }
        static get workerSrc() {
          return this.#e;
        }
        static set workerSrc(_) {
          if (typeof _ != "string")
            throw new Error("Invalid `workerSrc` type.");
          this.#e = _;
        }
      }
    })
  ),
  /***/
  284: (
    /***/
    ((ct, st, V) => {
      V.d(st, {
        /* harmony export */
        XfaLayer: () => (
          /* binding */
          B
        )
        /* harmony export */
      });
      var w = V(50);
      class B {
        static setupStorage(U, P, T, E, v) {
          const n = E.getValue(P, {
            value: null
          });
          switch (T.name) {
            case "textarea":
              if (n.value !== null && (U.textContent = n.value), v === "print")
                break;
              U.addEventListener("input", (c) => {
                E.setValue(P, {
                  value: c.target.value
                });
              });
              break;
            case "input":
              if (T.attributes.type === "radio" || T.attributes.type === "checkbox") {
                if (n.value === T.attributes.xfaOn ? U.setAttribute("checked", !0) : n.value === T.attributes.xfaOff && U.removeAttribute("checked"), v === "print")
                  break;
                U.addEventListener("change", (c) => {
                  E.setValue(P, {
                    value: c.target.checked ? c.target.getAttribute("xfaOn") : c.target.getAttribute("xfaOff")
                  });
                });
              } else {
                if (n.value !== null && U.setAttribute("value", n.value), v === "print")
                  break;
                U.addEventListener("input", (c) => {
                  E.setValue(P, {
                    value: c.target.value
                  });
                });
              }
              break;
            case "select":
              if (n.value !== null) {
                U.setAttribute("value", n.value);
                for (const c of T.children)
                  c.attributes.value === n.value ? c.attributes.selected = !0 : c.attributes.hasOwnProperty("selected") && delete c.attributes.selected;
              }
              U.addEventListener("input", (c) => {
                const l = c.target.options, b = l.selectedIndex === -1 ? "" : l[l.selectedIndex].value;
                E.setValue(P, {
                  value: b
                });
              });
              break;
          }
        }
        static setAttributes({
          html: U,
          element: P,
          storage: T = null,
          intent: E,
          linkService: v
        }) {
          const {
            attributes: n
          } = P, c = U instanceof HTMLAnchorElement;
          n.type === "radio" && (n.name = `${n.name}-${E}`);
          for (const [l, b] of Object.entries(n))
            if (b != null)
              switch (l) {
                case "class":
                  b.length && U.setAttribute(l, b.join(" "));
                  break;
                case "dataId":
                  break;
                case "id":
                  U.setAttribute("data-element-id", b);
                  break;
                case "style":
                  Object.assign(U.style, b);
                  break;
                case "textContent":
                  U.textContent = b;
                  break;
                default:
                  (!c || l !== "href" && l !== "newWindow") && U.setAttribute(l, b);
              }
          c && v.addLinkAttributes(U, n.href, n.newWindow), T && n.dataId && this.setupStorage(U, n.dataId, P, T);
        }
        static render(U) {
          const P = U.annotationStorage, T = U.linkService, E = U.xfaHtml, v = U.intent || "display", n = document.createElement(E.name);
          E.attributes && this.setAttributes({
            html: n,
            element: E,
            intent: v,
            linkService: T
          });
          const c = v !== "richText", l = U.div;
          if (l.append(n), U.viewport) {
            const g = `matrix(${U.viewport.transform.join(",")})`;
            l.style.transform = g;
          }
          c && l.setAttribute("class", "xfaLayer xfaFont");
          const b = [];
          if (E.children.length === 0) {
            if (E.value) {
              const g = document.createTextNode(E.value);
              n.append(g), c && w.XfaText.shouldBuildText(E.name) && b.push(g);
            }
            return {
              textDivs: b
            };
          }
          const s = [[E, -1, n]];
          for (; s.length > 0; ) {
            const [g, t, i] = s.at(-1);
            if (t + 1 === g.children.length) {
              s.pop();
              continue;
            }
            const d = g.children[++s.at(-1)[1]];
            if (d === null)
              continue;
            const {
              name: f
            } = d;
            if (f === "#text") {
              const S = document.createTextNode(d.value);
              b.push(S), i.append(S);
              continue;
            }
            const y = d?.attributes?.xmlns ? document.createElementNS(d.attributes.xmlns, f) : document.createElement(f);
            if (i.append(y), d.attributes && this.setAttributes({
              html: y,
              element: d,
              storage: P,
              intent: v,
              linkService: T
            }), d.children?.length > 0)
              s.push([d, -1, y]);
            else if (d.value) {
              const S = document.createTextNode(d.value);
              c && w.XfaText.shouldBuildText(f) && b.push(S), y.append(S);
            }
          }
          for (const g of l.querySelectorAll(".xfaNonInteractive input, .xfaNonInteractive textarea"))
            g.setAttribute("readOnly", !0);
          return {
            textDivs: b
          };
        }
        static update(U) {
          const P = `matrix(${U.viewport.transform.join(",")})`;
          U.div.style.transform = P, U.div.hidden = !1;
        }
      }
    })
  ),
  /***/
  50: (
    /***/
    ((ct, st, V) => {
      V.d(st, {
        /* harmony export */
        XfaText: () => (
          /* binding */
          w
        )
        /* harmony export */
      });
      class w {
        static textContent(_) {
          const U = [], P = {
            items: U,
            styles: /* @__PURE__ */ Object.create(null)
          };
          function T(E) {
            if (!E)
              return;
            let v = null;
            const n = E.name;
            if (n === "#text")
              v = E.value;
            else if (w.shouldBuildText(n))
              E?.attributes?.textContent ? v = E.attributes.textContent : E.value && (v = E.value);
            else return;
            if (v !== null && U.push({
              str: v
            }), !!E.children)
              for (const c of E.children)
                T(c);
          }
          return T(_), P;
        }
        static shouldBuildText(_) {
          return !(_ === "textarea" || _ === "input" || _ === "option" || _ === "select");
        }
      }
    })
  ),
  /***/
  228: (
    /***/
    ((ct, st, V) => {
      V.a(ct, async (w, B) => {
        try {
          V.d(st, {
            /* harmony export */
            AbortException: () => (
              /* reexport safe */
              _.AbortException
            ),
            /* harmony export */
            AnnotationEditorLayer: () => (
              /* reexport safe */
              E.AnnotationEditorLayer
            ),
            /* harmony export */
            AnnotationEditorParamsType: () => (
              /* reexport safe */
              _.AnnotationEditorParamsType
            ),
            /* harmony export */
            AnnotationEditorType: () => (
              /* reexport safe */
              _.AnnotationEditorType
            ),
            /* harmony export */
            AnnotationEditorUIManager: () => (
              /* reexport safe */
              v.AnnotationEditorUIManager
            ),
            /* harmony export */
            AnnotationLayer: () => (
              /* reexport safe */
              n.AnnotationLayer
            ),
            /* harmony export */
            AnnotationMode: () => (
              /* reexport safe */
              _.AnnotationMode
            ),
            /* harmony export */
            CMapCompressionType: () => (
              /* reexport safe */
              _.CMapCompressionType
            ),
            /* harmony export */
            ColorPicker: () => (
              /* reexport safe */
              c.ColorPicker
            ),
            /* harmony export */
            DOMSVGFactory: () => (
              /* reexport safe */
              P.DOMSVGFactory
            ),
            /* harmony export */
            DrawLayer: () => (
              /* reexport safe */
              l.DrawLayer
            ),
            /* harmony export */
            FeatureTest: () => (
              /* reexport safe */
              _.FeatureTest
            ),
            /* harmony export */
            GlobalWorkerOptions: () => (
              /* reexport safe */
              b.GlobalWorkerOptions
            ),
            /* harmony export */
            ImageKind: () => (
              /* reexport safe */
              _.ImageKind
            ),
            /* harmony export */
            InvalidPDFException: () => (
              /* reexport safe */
              _.InvalidPDFException
            ),
            /* harmony export */
            MissingPDFException: () => (
              /* reexport safe */
              _.MissingPDFException
            ),
            /* harmony export */
            OPS: () => (
              /* reexport safe */
              _.OPS
            ),
            /* harmony export */
            Outliner: () => (
              /* reexport safe */
              s.Outliner
            ),
            /* harmony export */
            PDFDataRangeTransport: () => (
              /* reexport safe */
              U.PDFDataRangeTransport
            ),
            /* harmony export */
            PDFDateString: () => (
              /* reexport safe */
              P.PDFDateString
            ),
            /* harmony export */
            PDFWorker: () => (
              /* reexport safe */
              U.PDFWorker
            ),
            /* harmony export */
            PasswordResponses: () => (
              /* reexport safe */
              _.PasswordResponses
            ),
            /* harmony export */
            PermissionFlag: () => (
              /* reexport safe */
              _.PermissionFlag
            ),
            /* harmony export */
            PixelsPerInch: () => (
              /* reexport safe */
              P.PixelsPerInch
            ),
            /* harmony export */
            RenderingCancelledException: () => (
              /* reexport safe */
              P.RenderingCancelledException
            ),
            /* harmony export */
            UnexpectedResponseException: () => (
              /* reexport safe */
              _.UnexpectedResponseException
            ),
            /* harmony export */
            Util: () => (
              /* reexport safe */
              _.Util
            ),
            /* harmony export */
            VerbosityLevel: () => (
              /* reexport safe */
              _.VerbosityLevel
            ),
            /* harmony export */
            XfaLayer: () => (
              /* reexport safe */
              g.XfaLayer
            ),
            /* harmony export */
            build: () => (
              /* reexport safe */
              U.build
            ),
            /* harmony export */
            createValidAbsoluteUrl: () => (
              /* reexport safe */
              _.createValidAbsoluteUrl
            ),
            /* harmony export */
            fetchData: () => (
              /* reexport safe */
              P.fetchData
            ),
            /* harmony export */
            getDocument: () => (
              /* reexport safe */
              U.getDocument
            ),
            /* harmony export */
            getFilenameFromUrl: () => (
              /* reexport safe */
              P.getFilenameFromUrl
            ),
            /* harmony export */
            getPdfFilenameFromUrl: () => (
              /* reexport safe */
              P.getPdfFilenameFromUrl
            ),
            /* harmony export */
            getXfaPageViewport: () => (
              /* reexport safe */
              P.getXfaPageViewport
            ),
            /* harmony export */
            isDataScheme: () => (
              /* reexport safe */
              P.isDataScheme
            ),
            /* harmony export */
            isPdfFile: () => (
              /* reexport safe */
              P.isPdfFile
            ),
            /* harmony export */
            noContextMenu: () => (
              /* reexport safe */
              P.noContextMenu
            ),
            /* harmony export */
            normalizeUnicode: () => (
              /* reexport safe */
              _.normalizeUnicode
            ),
            /* harmony export */
            renderTextLayer: () => (
              /* reexport safe */
              T.renderTextLayer
            ),
            /* harmony export */
            setLayerDimensions: () => (
              /* reexport safe */
              P.setLayerDimensions
            ),
            /* harmony export */
            shadow: () => (
              /* reexport safe */
              _.shadow
            ),
            /* harmony export */
            updateTextLayer: () => (
              /* reexport safe */
              T.updateTextLayer
            ),
            /* harmony export */
            version: () => (
              /* reexport safe */
              U.version
            )
            /* harmony export */
          });
          var _ = V(292), U = V(831), P = V(419), T = V(814), E = V(731), v = V(830), n = V(976), c = V(259), l = V(47), b = V(164), s = V(61), g = V(284), t = w([U]);
          U = (t.then ? (await t)() : t)[0];
          const i = "4.2.67", d = "49b388101";
          B();
        } catch (i) {
          B(i);
        }
      });
    })
  ),
  /***/
  178: (
    /***/
    ((ct, st, V) => {
      V.d(st, {
        /* harmony export */
        MessageHandler: () => (
          /* binding */
          P
        )
        /* harmony export */
      });
      var w = V(292);
      const B = {
        DATA: 1,
        ERROR: 2
      }, _ = {
        CANCEL: 1,
        CANCEL_COMPLETE: 2,
        CLOSE: 3,
        ENQUEUE: 4,
        ERROR: 5,
        PULL: 6,
        PULL_COMPLETE: 7,
        START_COMPLETE: 8
      };
      function U(T) {
        switch (T instanceof Error || typeof T == "object" && T !== null || (0, w.unreachable)('wrapReason: Expected "reason" to be a (possibly cloned) Error.'), T.name) {
          case "AbortException":
            return new w.AbortException(T.message);
          case "MissingPDFException":
            return new w.MissingPDFException(T.message);
          case "PasswordException":
            return new w.PasswordException(T.message, T.code);
          case "UnexpectedResponseException":
            return new w.UnexpectedResponseException(T.message, T.status);
          case "UnknownErrorException":
            return new w.UnknownErrorException(T.message, T.details);
          default:
            return new w.UnknownErrorException(T.message, T.toString());
        }
      }
      class P {
        constructor(E, v, n) {
          this.sourceName = E, this.targetName = v, this.comObj = n, this.callbackId = 1, this.streamId = 1, this.streamSinks = /* @__PURE__ */ Object.create(null), this.streamControllers = /* @__PURE__ */ Object.create(null), this.callbackCapabilities = /* @__PURE__ */ Object.create(null), this.actionHandler = /* @__PURE__ */ Object.create(null), this._onComObjOnMessage = (c) => {
            const l = c.data;
            if (l.targetName !== this.sourceName)
              return;
            if (l.stream) {
              this.#e(l);
              return;
            }
            if (l.callback) {
              const s = l.callbackId, g = this.callbackCapabilities[s];
              if (!g)
                throw new Error(`Cannot resolve callback ${s}`);
              if (delete this.callbackCapabilities[s], l.callback === B.DATA)
                g.resolve(l.data);
              else if (l.callback === B.ERROR)
                g.reject(U(l.reason));
              else
                throw new Error("Unexpected callback case");
              return;
            }
            const b = this.actionHandler[l.action];
            if (!b)
              throw new Error(`Unknown action from worker: ${l.action}`);
            if (l.callbackId) {
              const s = this.sourceName, g = l.sourceName;
              new Promise(function(t) {
                t(b(l.data));
              }).then(function(t) {
                n.postMessage({
                  sourceName: s,
                  targetName: g,
                  callback: B.DATA,
                  callbackId: l.callbackId,
                  data: t
                });
              }, function(t) {
                n.postMessage({
                  sourceName: s,
                  targetName: g,
                  callback: B.ERROR,
                  callbackId: l.callbackId,
                  reason: U(t)
                });
              });
              return;
            }
            if (l.streamId) {
              this.#t(l);
              return;
            }
            b(l.data);
          }, n.addEventListener("message", this._onComObjOnMessage);
        }
        on(E, v) {
          const n = this.actionHandler;
          if (n[E])
            throw new Error(`There is already an actionName called "${E}"`);
          n[E] = v;
        }
        send(E, v, n) {
          this.comObj.postMessage({
            sourceName: this.sourceName,
            targetName: this.targetName,
            action: E,
            data: v
          }, n);
        }
        sendWithPromise(E, v, n) {
          const c = this.callbackId++, l = Promise.withResolvers();
          this.callbackCapabilities[c] = l;
          try {
            this.comObj.postMessage({
              sourceName: this.sourceName,
              targetName: this.targetName,
              action: E,
              callbackId: c,
              data: v
            }, n);
          } catch (b) {
            l.reject(b);
          }
          return l.promise;
        }
        sendWithStream(E, v, n, c) {
          const l = this.streamId++, b = this.sourceName, s = this.targetName, g = this.comObj;
          return new ReadableStream({
            start: (t) => {
              const i = Promise.withResolvers();
              return this.streamControllers[l] = {
                controller: t,
                startCall: i,
                pullCall: null,
                cancelCall: null,
                isClosed: !1
              }, g.postMessage({
                sourceName: b,
                targetName: s,
                action: E,
                streamId: l,
                data: v,
                desiredSize: t.desiredSize
              }, c), i.promise;
            },
            pull: (t) => {
              const i = Promise.withResolvers();
              return this.streamControllers[l].pullCall = i, g.postMessage({
                sourceName: b,
                targetName: s,
                stream: _.PULL,
                streamId: l,
                desiredSize: t.desiredSize
              }), i.promise;
            },
            cancel: (t) => {
              (0, w.assert)(t instanceof Error, "cancel must have a valid reason");
              const i = Promise.withResolvers();
              return this.streamControllers[l].cancelCall = i, this.streamControllers[l].isClosed = !0, g.postMessage({
                sourceName: b,
                targetName: s,
                stream: _.CANCEL,
                streamId: l,
                reason: U(t)
              }), i.promise;
            }
          }, n);
        }
        #t(E) {
          const v = E.streamId, n = this.sourceName, c = E.sourceName, l = this.comObj, b = this, s = this.actionHandler[E.action], g = {
            enqueue(t, i = 1, d) {
              if (this.isCancelled)
                return;
              const f = this.desiredSize;
              this.desiredSize -= i, f > 0 && this.desiredSize <= 0 && (this.sinkCapability = Promise.withResolvers(), this.ready = this.sinkCapability.promise), l.postMessage({
                sourceName: n,
                targetName: c,
                stream: _.ENQUEUE,
                streamId: v,
                chunk: t
              }, d);
            },
            close() {
              this.isCancelled || (this.isCancelled = !0, l.postMessage({
                sourceName: n,
                targetName: c,
                stream: _.CLOSE,
                streamId: v
              }), delete b.streamSinks[v]);
            },
            error(t) {
              (0, w.assert)(t instanceof Error, "error must have a valid reason"), !this.isCancelled && (this.isCancelled = !0, l.postMessage({
                sourceName: n,
                targetName: c,
                stream: _.ERROR,
                streamId: v,
                reason: U(t)
              }));
            },
            sinkCapability: Promise.withResolvers(),
            onPull: null,
            onCancel: null,
            isCancelled: !1,
            desiredSize: E.desiredSize,
            ready: null
          };
          g.sinkCapability.resolve(), g.ready = g.sinkCapability.promise, this.streamSinks[v] = g, new Promise(function(t) {
            t(s(E.data, g));
          }).then(function() {
            l.postMessage({
              sourceName: n,
              targetName: c,
              stream: _.START_COMPLETE,
              streamId: v,
              success: !0
            });
          }, function(t) {
            l.postMessage({
              sourceName: n,
              targetName: c,
              stream: _.START_COMPLETE,
              streamId: v,
              reason: U(t)
            });
          });
        }
        #e(E) {
          const v = E.streamId, n = this.sourceName, c = E.sourceName, l = this.comObj, b = this.streamControllers[v], s = this.streamSinks[v];
          switch (E.stream) {
            case _.START_COMPLETE:
              E.success ? b.startCall.resolve() : b.startCall.reject(U(E.reason));
              break;
            case _.PULL_COMPLETE:
              E.success ? b.pullCall.resolve() : b.pullCall.reject(U(E.reason));
              break;
            case _.PULL:
              if (!s) {
                l.postMessage({
                  sourceName: n,
                  targetName: c,
                  stream: _.PULL_COMPLETE,
                  streamId: v,
                  success: !0
                });
                break;
              }
              s.desiredSize <= 0 && E.desiredSize > 0 && s.sinkCapability.resolve(), s.desiredSize = E.desiredSize, new Promise(function(g) {
                g(s.onPull?.());
              }).then(function() {
                l.postMessage({
                  sourceName: n,
                  targetName: c,
                  stream: _.PULL_COMPLETE,
                  streamId: v,
                  success: !0
                });
              }, function(g) {
                l.postMessage({
                  sourceName: n,
                  targetName: c,
                  stream: _.PULL_COMPLETE,
                  streamId: v,
                  reason: U(g)
                });
              });
              break;
            case _.ENQUEUE:
              if ((0, w.assert)(b, "enqueue should have stream controller"), b.isClosed)
                break;
              b.controller.enqueue(E.chunk);
              break;
            case _.CLOSE:
              if ((0, w.assert)(b, "close should have stream controller"), b.isClosed)
                break;
              b.isClosed = !0, b.controller.close(), this.#s(b, v);
              break;
            case _.ERROR:
              (0, w.assert)(b, "error should have stream controller"), b.controller.error(U(E.reason)), this.#s(b, v);
              break;
            case _.CANCEL_COMPLETE:
              E.success ? b.cancelCall.resolve() : b.cancelCall.reject(U(E.reason)), this.#s(b, v);
              break;
            case _.CANCEL:
              if (!s)
                break;
              new Promise(function(g) {
                g(s.onCancel?.(U(E.reason)));
              }).then(function() {
                l.postMessage({
                  sourceName: n,
                  targetName: c,
                  stream: _.CANCEL_COMPLETE,
                  streamId: v,
                  success: !0
                });
              }, function(g) {
                l.postMessage({
                  sourceName: n,
                  targetName: c,
                  stream: _.CANCEL_COMPLETE,
                  streamId: v,
                  reason: U(g)
                });
              }), s.sinkCapability.reject(U(E.reason)), s.isCancelled = !0, delete this.streamSinks[v];
              break;
            default:
              throw new Error("Unexpected stream case");
          }
        }
        async #s(E, v) {
          await Promise.allSettled([E.startCall?.promise, E.pullCall?.promise, E.cancelCall?.promise]), delete this.streamControllers[v];
        }
        destroy() {
          this.comObj.removeEventListener("message", this._onComObjOnMessage);
        }
      }
    })
  ),
  /***/
  651: (
    /***/
    ((ct, st, V) => {
      V.d(st, {
        /* harmony export */
        MurmurHash3_64: () => (
          /* binding */
          U
        )
        /* harmony export */
      });
      const w = 3285377520, B = 4294901760, _ = 65535;
      class U {
        constructor(T) {
          this.h1 = T ? T & 4294967295 : w, this.h2 = T ? T & 4294967295 : w;
        }
        update(T) {
          let E, v;
          if (typeof T == "string") {
            E = new Uint8Array(T.length * 2), v = 0;
            for (let S = 0, L = T.length; S < L; S++) {
              const M = T.charCodeAt(S);
              M <= 255 ? E[v++] = M : (E[v++] = M >>> 8, E[v++] = M & 255);
            }
          } else if (ArrayBuffer.isView(T))
            E = T.slice(), v = E.byteLength;
          else
            throw new Error("Invalid data format, must be a string or TypedArray.");
          const n = v >> 2, c = v - n * 4, l = new Uint32Array(E.buffer, 0, n);
          let b = 0, s = 0, g = this.h1, t = this.h2;
          const i = 3432918353, d = 461845907, f = i & _, y = d & _;
          for (let S = 0; S < n; S++)
            S & 1 ? (b = l[S], b = b * i & B | b * f & _, b = b << 15 | b >>> 17, b = b * d & B | b * y & _, g ^= b, g = g << 13 | g >>> 19, g = g * 5 + 3864292196) : (s = l[S], s = s * i & B | s * f & _, s = s << 15 | s >>> 17, s = s * d & B | s * y & _, t ^= s, t = t << 13 | t >>> 19, t = t * 5 + 3864292196);
          switch (b = 0, c) {
            case 3:
              b ^= E[n * 4 + 2] << 16;
            case 2:
              b ^= E[n * 4 + 1] << 8;
            case 1:
              b ^= E[n * 4], b = b * i & B | b * f & _, b = b << 15 | b >>> 17, b = b * d & B | b * y & _, n & 1 ? g ^= b : t ^= b;
          }
          this.h1 = g, this.h2 = t;
        }
        hexdigest() {
          let T = this.h1, E = this.h2;
          return T ^= E >>> 1, T = T * 3981806797 & B | T * 36045 & _, E = E * 4283543511 & B | ((E << 16 | T >>> 16) * 2950163797 & B) >>> 16, T ^= E >>> 1, T = T * 444984403 & B | T * 60499 & _, E = E * 3301882366 & B | ((E << 16 | T >>> 16) * 3120437893 & B) >>> 16, T ^= E >>> 1, (T >>> 0).toString(16).padStart(8, "0") + (E >>> 0).toString(16).padStart(8, "0");
        }
      }
    })
  ),
  /***/
  292: (
    /***/
    ((ct, st, V) => {
      V.d(st, {
        /* harmony export */
        AbortException: () => (
          /* binding */
          dt
        ),
        /* harmony export */
        AnnotationBorderStyleType: () => (
          /* binding */
          t
        ),
        /* harmony export */
        AnnotationEditorParamsType: () => (
          /* binding */
          c
        ),
        /* harmony export */
        AnnotationEditorPrefix: () => (
          /* binding */
          v
        ),
        /* harmony export */
        AnnotationEditorType: () => (
          /* binding */
          n
        ),
        /* harmony export */
        AnnotationMode: () => (
          /* binding */
          E
        ),
        /* harmony export */
        AnnotationPrefix: () => (
          /* binding */
          R
        ),
        /* harmony export */
        AnnotationType: () => (
          /* binding */
          g
        ),
        /* harmony export */
        BaseException: () => (
          /* binding */
          G
        ),
        /* harmony export */
        CMapCompressionType: () => (
          /* binding */
          d
        ),
        /* harmony export */
        FONT_IDENTITY_MATRIX: () => (
          /* binding */
          _
        ),
        /* harmony export */
        FeatureTest: () => (
          /* binding */
          r
        ),
        /* harmony export */
        FontRenderOps: () => (
          /* binding */
          D
        ),
        /* harmony export */
        FormatError: () => (
          /* binding */
          pt
        ),
        /* harmony export */
        IDENTITY_MATRIX: () => (
          /* binding */
          B
        ),
        /* harmony export */
        ImageKind: () => (
          /* binding */
          s
        ),
        /* harmony export */
        InvalidPDFException: () => (
          /* binding */
          Z
        ),
        /* harmony export */
        LINE_FACTOR: () => (
          /* binding */
          P
        ),
        /* harmony export */
        MAX_IMAGE_SIZE_TO_CACHE: () => (
          /* binding */
          U
        ),
        /* harmony export */
        MissingPDFException: () => (
          /* binding */
          at
        ),
        /* harmony export */
        OPS: () => (
          /* binding */
          f
        ),
        /* harmony export */
        PasswordException: () => (
          /* binding */
          Y
        ),
        /* harmony export */
        PasswordResponses: () => (
          /* binding */
          y
        ),
        /* harmony export */
        PermissionFlag: () => (
          /* binding */
          l
        ),
        /* harmony export */
        RenderingIntentFlag: () => (
          /* binding */
          T
        ),
        /* harmony export */
        TextRenderingMode: () => (
          /* binding */
          b
        ),
        /* harmony export */
        UnexpectedResponseException: () => (
          /* binding */
          lt
        ),
        /* harmony export */
        UnknownErrorException: () => (
          /* binding */
          tt
        ),
        /* harmony export */
        Util: () => (
          /* binding */
          o
        ),
        /* harmony export */
        VerbosityLevel: () => (
          /* binding */
          i
        ),
        /* harmony export */
        assert: () => (
          /* binding */
          q
        ),
        /* harmony export */
        bytesToString: () => (
          /* binding */
          ot
        ),
        /* harmony export */
        createValidAbsoluteUrl: () => (
          /* binding */
          j
        ),
        /* harmony export */
        getUuid: () => (
          /* binding */
          k
        ),
        /* harmony export */
        getVerbosityLevel: () => (
          /* binding */
          M
        ),
        /* harmony export */
        info: () => (
          /* binding */
          N
        ),
        /* harmony export */
        isNodeJS: () => (
          /* binding */
          w
        ),
        /* harmony export */
        normalizeUnicode: () => (
          /* binding */
          x
        ),
        /* harmony export */
        objectFromMap: () => (
          /* binding */
          m
        ),
        /* harmony export */
        setVerbosityLevel: () => (
          /* binding */
          L
        ),
        /* harmony export */
        shadow: () => (
          /* binding */
          O
        ),
        /* harmony export */
        string32: () => (
          /* binding */
          et
        ),
        /* harmony export */
        stringToBytes: () => (
          /* binding */
          ut
        ),
        /* harmony export */
        unreachable: () => (
          /* binding */
          z
        ),
        /* harmony export */
        warn: () => (
          /* binding */
          H
        )
        /* harmony export */
      });
      const w = typeof process == "object" && process + "" == "[object process]" && !process.versions.nw && !(process.versions.electron && process.type && process.type !== "browser"), B = [1, 0, 0, 1, 0, 0], _ = [1e-3, 0, 0, 1e-3, 0, 0], U = 1e7, P = 1.35, T = {
        ANY: 1,
        DISPLAY: 2,
        PRINT: 4,
        SAVE: 8,
        ANNOTATIONS_FORMS: 16,
        ANNOTATIONS_STORAGE: 32,
        ANNOTATIONS_DISABLE: 64,
        OPLIST: 256
      }, E = {
        DISABLE: 0,
        ENABLE: 1,
        ENABLE_FORMS: 2,
        ENABLE_STORAGE: 3
      }, v = "pdfjs_internal_editor_", n = {
        DISABLE: -1,
        NONE: 0,
        FREETEXT: 3,
        HIGHLIGHT: 9,
        STAMP: 13,
        INK: 15
      }, c = {
        RESIZE: 1,
        CREATE: 2,
        FREETEXT_SIZE: 11,
        FREETEXT_COLOR: 12,
        FREETEXT_OPACITY: 13,
        INK_COLOR: 21,
        INK_THICKNESS: 22,
        INK_OPACITY: 23,
        HIGHLIGHT_COLOR: 31,
        HIGHLIGHT_DEFAULT_COLOR: 32,
        HIGHLIGHT_THICKNESS: 33,
        HIGHLIGHT_FREE: 34,
        HIGHLIGHT_SHOW_ALL: 35
      }, l = {
        PRINT: 4,
        MODIFY_CONTENTS: 8,
        COPY: 16,
        MODIFY_ANNOTATIONS: 32,
        FILL_INTERACTIVE_FORMS: 256,
        COPY_FOR_ACCESSIBILITY: 512,
        ASSEMBLE: 1024,
        PRINT_HIGH_QUALITY: 2048
      }, b = {
        FILL: 0,
        STROKE: 1,
        FILL_STROKE: 2,
        INVISIBLE: 3,
        FILL_ADD_TO_PATH: 4,
        STROKE_ADD_TO_PATH: 5,
        FILL_STROKE_ADD_TO_PATH: 6,
        ADD_TO_PATH: 7,
        FILL_STROKE_MASK: 3,
        ADD_TO_PATH_FLAG: 4
      }, s = {
        GRAYSCALE_1BPP: 1,
        RGB_24BPP: 2,
        RGBA_32BPP: 3
      }, g = {
        TEXT: 1,
        LINK: 2,
        FREETEXT: 3,
        LINE: 4,
        SQUARE: 5,
        CIRCLE: 6,
        POLYGON: 7,
        POLYLINE: 8,
        HIGHLIGHT: 9,
        UNDERLINE: 10,
        SQUIGGLY: 11,
        STRIKEOUT: 12,
        STAMP: 13,
        CARET: 14,
        INK: 15,
        POPUP: 16,
        FILEATTACHMENT: 17,
        SOUND: 18,
        MOVIE: 19,
        WIDGET: 20,
        SCREEN: 21,
        PRINTERMARK: 22,
        TRAPNET: 23,
        WATERMARK: 24,
        THREED: 25,
        REDACT: 26
      }, t = {
        SOLID: 1,
        DASHED: 2,
        BEVELED: 3,
        INSET: 4,
        UNDERLINE: 5
      }, i = {
        ERRORS: 0,
        WARNINGS: 1,
        INFOS: 5
      }, d = {
        NONE: 0,
        BINARY: 1
      }, f = {
        dependency: 1,
        setLineWidth: 2,
        setLineCap: 3,
        setLineJoin: 4,
        setMiterLimit: 5,
        setDash: 6,
        setRenderingIntent: 7,
        setFlatness: 8,
        setGState: 9,
        save: 10,
        restore: 11,
        transform: 12,
        moveTo: 13,
        lineTo: 14,
        curveTo: 15,
        curveTo2: 16,
        curveTo3: 17,
        closePath: 18,
        rectangle: 19,
        stroke: 20,
        closeStroke: 21,
        fill: 22,
        eoFill: 23,
        fillStroke: 24,
        eoFillStroke: 25,
        closeFillStroke: 26,
        closeEOFillStroke: 27,
        endPath: 28,
        clip: 29,
        eoClip: 30,
        beginText: 31,
        endText: 32,
        setCharSpacing: 33,
        setWordSpacing: 34,
        setHScale: 35,
        setLeading: 36,
        setFont: 37,
        setTextRenderingMode: 38,
        setTextRise: 39,
        moveText: 40,
        setLeadingMoveText: 41,
        setTextMatrix: 42,
        nextLine: 43,
        showText: 44,
        showSpacedText: 45,
        nextLineShowText: 46,
        nextLineSetSpacingShowText: 47,
        setCharWidth: 48,
        setCharWidthAndBounds: 49,
        setStrokeColorSpace: 50,
        setFillColorSpace: 51,
        setStrokeColor: 52,
        setStrokeColorN: 53,
        setFillColor: 54,
        setFillColorN: 55,
        setStrokeGray: 56,
        setFillGray: 57,
        setStrokeRGBColor: 58,
        setFillRGBColor: 59,
        setStrokeCMYKColor: 60,
        setFillCMYKColor: 61,
        shadingFill: 62,
        beginInlineImage: 63,
        beginImageData: 64,
        endInlineImage: 65,
        paintXObject: 66,
        markPoint: 67,
        markPointProps: 68,
        beginMarkedContent: 69,
        beginMarkedContentProps: 70,
        endMarkedContent: 71,
        beginCompat: 72,
        endCompat: 73,
        paintFormXObjectBegin: 74,
        paintFormXObjectEnd: 75,
        beginGroup: 76,
        endGroup: 77,
        beginAnnotation: 80,
        endAnnotation: 81,
        paintImageMaskXObject: 83,
        paintImageMaskXObjectGroup: 84,
        paintImageXObject: 85,
        paintInlineImageXObject: 86,
        paintInlineImageXObjectGroup: 87,
        paintImageXObjectRepeat: 88,
        paintImageMaskXObjectRepeat: 89,
        paintSolidColorImageMask: 90,
        constructPath: 91
      }, y = {
        NEED_PASSWORD: 1,
        INCORRECT_PASSWORD: 2
      };
      let S = i.WARNINGS;
      function L(I) {
        Number.isInteger(I) && (S = I);
      }
      function M() {
        return S;
      }
      function N(I) {
        S >= i.INFOS && console.log(`Info: ${I}`);
      }
      function H(I) {
        S >= i.WARNINGS && console.log(`Warning: ${I}`);
      }
      function z(I) {
        throw new Error(I);
      }
      function q(I, F) {
        I || z(F);
      }
      function nt(I) {
        switch (I?.protocol) {
          case "http:":
          case "https:":
          case "ftp:":
          case "mailto:":
          case "tel:":
            return !0;
          default:
            return !1;
        }
      }
      function j(I, F = null, C = null) {
        if (!I)
          return null;
        try {
          if (C && typeof I == "string" && (C.addDefaultProtocol && I.startsWith("www.") && I.match(/\./g)?.length >= 2 && (I = `http://${I}`), C.tryConvertEncoding))
            try {
              I = a(I);
            } catch {
            }
          const $ = F ? new URL(I, F) : new URL(I);
          if (nt($))
            return $;
        } catch {
        }
        return null;
      }
      function O(I, F, C, $ = !1) {
        return Object.defineProperty(I, F, {
          value: C,
          enumerable: !$,
          configurable: !0,
          writable: !1
        }), C;
      }
      const G = (function() {
        function F(C, $) {
          this.constructor === F && z("Cannot initialize BaseException."), this.message = C, this.name = $;
        }
        return F.prototype = new Error(), F.constructor = F, F;
      })();
      class Y extends G {
        constructor(F, C) {
          super(F, "PasswordException"), this.code = C;
        }
      }
      class tt extends G {
        constructor(F, C) {
          super(F, "UnknownErrorException"), this.details = C;
        }
      }
      class Z extends G {
        constructor(F) {
          super(F, "InvalidPDFException");
        }
      }
      class at extends G {
        constructor(F) {
          super(F, "MissingPDFException");
        }
      }
      class lt extends G {
        constructor(F, C) {
          super(F, "UnexpectedResponseException"), this.status = C;
        }
      }
      class pt extends G {
        constructor(F) {
          super(F, "FormatError");
        }
      }
      class dt extends G {
        constructor(F) {
          super(F, "AbortException");
        }
      }
      function ot(I) {
        (typeof I != "object" || I?.length === void 0) && z("Invalid argument for bytesToString");
        const F = I.length, C = 8192;
        if (F < C)
          return String.fromCharCode.apply(null, I);
        const $ = [];
        for (let K = 0; K < F; K += C) {
          const X = Math.min(K + C, F), W = I.subarray(K, X);
          $.push(String.fromCharCode.apply(null, W));
        }
        return $.join("");
      }
      function ut(I) {
        typeof I != "string" && z("Invalid argument for stringToBytes");
        const F = I.length, C = new Uint8Array(F);
        for (let $ = 0; $ < F; ++$)
          C[$] = I.charCodeAt($) & 255;
        return C;
      }
      function et(I) {
        return String.fromCharCode(I >> 24 & 255, I >> 16 & 255, I >> 8 & 255, I & 255);
      }
      function m(I) {
        const F = /* @__PURE__ */ Object.create(null);
        for (const [C, $] of I)
          F[C] = $;
        return F;
      }
      function h() {
        const I = new Uint8Array(4);
        return I[0] = 1, new Uint32Array(I.buffer, 0, 1)[0] === 1;
      }
      function e() {
        try {
          return new Function(""), !0;
        } catch {
          return !1;
        }
      }
      class r {
        static get isLittleEndian() {
          return O(this, "isLittleEndian", h());
        }
        static get isEvalSupported() {
          return O(this, "isEvalSupported", e());
        }
        static get isOffscreenCanvasSupported() {
          return O(this, "isOffscreenCanvasSupported", typeof OffscreenCanvas < "u");
        }
        static get platform() {
          return typeof navigator < "u" && typeof navigator?.platform == "string" ? O(this, "platform", {
            isMac: navigator.platform.includes("Mac")
          }) : O(this, "platform", {
            isMac: !1
          });
        }
        static get isCSSRoundSupported() {
          return O(this, "isCSSRoundSupported", globalThis.CSS?.supports?.("width: round(1.5px, 1px)"));
        }
      }
      const p = Array.from(Array(256).keys(), (I) => I.toString(16).padStart(2, "0"));
      class o {
        static makeHexColor(F, C, $) {
          return `#${p[F]}${p[C]}${p[$]}`;
        }
        static scaleMinMax(F, C) {
          let $;
          F[0] ? (F[0] < 0 && ($ = C[0], C[0] = C[2], C[2] = $), C[0] *= F[0], C[2] *= F[0], F[3] < 0 && ($ = C[1], C[1] = C[3], C[3] = $), C[1] *= F[3], C[3] *= F[3]) : ($ = C[0], C[0] = C[1], C[1] = $, $ = C[2], C[2] = C[3], C[3] = $, F[1] < 0 && ($ = C[1], C[1] = C[3], C[3] = $), C[1] *= F[1], C[3] *= F[1], F[2] < 0 && ($ = C[0], C[0] = C[2], C[2] = $), C[0] *= F[2], C[2] *= F[2]), C[0] += F[4], C[1] += F[5], C[2] += F[4], C[3] += F[5];
        }
        static transform(F, C) {
          return [F[0] * C[0] + F[2] * C[1], F[1] * C[0] + F[3] * C[1], F[0] * C[2] + F[2] * C[3], F[1] * C[2] + F[3] * C[3], F[0] * C[4] + F[2] * C[5] + F[4], F[1] * C[4] + F[3] * C[5] + F[5]];
        }
        static applyTransform(F, C) {
          const $ = F[0] * C[0] + F[1] * C[2] + C[4], K = F[0] * C[1] + F[1] * C[3] + C[5];
          return [$, K];
        }
        static applyInverseTransform(F, C) {
          const $ = C[0] * C[3] - C[1] * C[2], K = (F[0] * C[3] - F[1] * C[2] + C[2] * C[5] - C[4] * C[3]) / $, X = (-F[0] * C[1] + F[1] * C[0] + C[4] * C[1] - C[5] * C[0]) / $;
          return [K, X];
        }
        static getAxialAlignedBoundingBox(F, C) {
          const $ = this.applyTransform(F, C), K = this.applyTransform(F.slice(2, 4), C), X = this.applyTransform([F[0], F[3]], C), W = this.applyTransform([F[2], F[1]], C);
          return [Math.min($[0], K[0], X[0], W[0]), Math.min($[1], K[1], X[1], W[1]), Math.max($[0], K[0], X[0], W[0]), Math.max($[1], K[1], X[1], W[1])];
        }
        static inverseTransform(F) {
          const C = F[0] * F[3] - F[1] * F[2];
          return [F[3] / C, -F[1] / C, -F[2] / C, F[0] / C, (F[2] * F[5] - F[4] * F[3]) / C, (F[4] * F[1] - F[5] * F[0]) / C];
        }
        static singularValueDecompose2dScale(F) {
          const C = [F[0], F[2], F[1], F[3]], $ = F[0] * C[0] + F[1] * C[2], K = F[0] * C[1] + F[1] * C[3], X = F[2] * C[0] + F[3] * C[2], W = F[2] * C[1] + F[3] * C[3], rt = ($ + W) / 2, J = Math.sqrt(($ + W) ** 2 - 4 * ($ * W - X * K)) / 2, Q = rt + J || 1, it = rt - J || 1;
          return [Math.sqrt(Q), Math.sqrt(it)];
        }
        static normalizeRect(F) {
          const C = F.slice(0);
          return F[0] > F[2] && (C[0] = F[2], C[2] = F[0]), F[1] > F[3] && (C[1] = F[3], C[3] = F[1]), C;
        }
        static intersect(F, C) {
          const $ = Math.max(Math.min(F[0], F[2]), Math.min(C[0], C[2])), K = Math.min(Math.max(F[0], F[2]), Math.max(C[0], C[2]));
          if ($ > K)
            return null;
          const X = Math.max(Math.min(F[1], F[3]), Math.min(C[1], C[3])), W = Math.min(Math.max(F[1], F[3]), Math.max(C[1], C[3]));
          return X > W ? null : [$, X, K, W];
        }
        static #t(F, C, $, K, X, W, rt, J, Q, it) {
          if (Q <= 0 || Q >= 1)
            return;
          const ht = 1 - Q, gt = Q * Q, At = gt * Q, vt = ht * (ht * (ht * F + 3 * Q * C) + 3 * gt * $) + At * K, mt = ht * (ht * (ht * X + 3 * Q * W) + 3 * gt * rt) + At * J;
          it[0] = Math.min(it[0], vt), it[1] = Math.min(it[1], mt), it[2] = Math.max(it[2], vt), it[3] = Math.max(it[3], mt);
        }
        static #e(F, C, $, K, X, W, rt, J, Q, it, ht, gt) {
          if (Math.abs(Q) < 1e-12) {
            Math.abs(it) >= 1e-12 && this.#t(F, C, $, K, X, W, rt, J, -ht / it, gt);
            return;
          }
          const At = it ** 2 - 4 * ht * Q;
          if (At < 0)
            return;
          const vt = Math.sqrt(At), mt = 2 * Q;
          this.#t(F, C, $, K, X, W, rt, J, (-it + vt) / mt, gt), this.#t(F, C, $, K, X, W, rt, J, (-it - vt) / mt, gt);
        }
        static bezierBoundingBox(F, C, $, K, X, W, rt, J, Q) {
          return Q ? (Q[0] = Math.min(Q[0], F, rt), Q[1] = Math.min(Q[1], C, J), Q[2] = Math.max(Q[2], F, rt), Q[3] = Math.max(Q[3], C, J)) : Q = [Math.min(F, rt), Math.min(C, J), Math.max(F, rt), Math.max(C, J)], this.#e(F, $, X, rt, C, K, W, J, 3 * (-F + 3 * ($ - X) + rt), 6 * (F - 2 * $ + X), 3 * ($ - F), Q), this.#e(F, $, X, rt, C, K, W, J, 3 * (-C + 3 * (K - W) + J), 6 * (C - 2 * K + W), 3 * (K - C), Q), Q;
        }
      }
      function a(I) {
        return decodeURIComponent(escape(I));
      }
      let u = null, A = null;
      function x(I) {
        return u || (u = /([\u00a0\u00b5\u037e\u0eb3\u2000-\u200a\u202f\u2126\ufb00-\ufb04\ufb06\ufb20-\ufb36\ufb38-\ufb3c\ufb3e\ufb40-\ufb41\ufb43-\ufb44\ufb46-\ufba1\ufba4-\ufba9\ufbae-\ufbb1\ufbd3-\ufbdc\ufbde-\ufbe7\ufbea-\ufbf8\ufbfc-\ufbfd\ufc00-\ufc5d\ufc64-\ufcf1\ufcf5-\ufd3d\ufd88\ufdf4\ufdfa-\ufdfb\ufe71\ufe77\ufe79\ufe7b\ufe7d]+)|(\ufb05+)/gu, A = /* @__PURE__ */ new Map([["ﬅ", "ſt"]])), I.replaceAll(u, (F, C, $) => C ? C.normalize("NFKC") : A.get($));
      }
      function k() {
        if (typeof crypto < "u" && typeof crypto?.randomUUID == "function")
          return crypto.randomUUID();
        const I = new Uint8Array(32);
        if (typeof crypto < "u" && typeof crypto?.getRandomValues == "function")
          crypto.getRandomValues(I);
        else
          for (let F = 0; F < 32; F++)
            I[F] = Math.floor(Math.random() * 255);
        return ot(I);
      }
      const R = "pdfjs_internal_id_", D = {
        BEZIER_CURVE_TO: 0,
        MOVE_TO: 1,
        LINE_TO: 2,
        QUADRATIC_CURVE_TO: 3,
        RESTORE: 4,
        SAVE: 5,
        SCALE: 6,
        TRANSFORM: 7,
        TRANSLATE: 8
      };
    })
  )
  /******/
}, Vt = {};
function Pt(ct) {
  var st = Vt[ct];
  if (st !== void 0)
    return st.exports;
  var V = Vt[ct] = {
    /******/
    // no module.id needed
    /******/
    // no module.loaded needed
    /******/
    exports: {}
    /******/
  };
  return Xt[ct](V, V.exports, Pt), V.exports;
}
(() => {
  var ct = typeof Symbol == "function" ? Symbol("webpack queues") : "__webpack_queues__", st = typeof Symbol == "function" ? Symbol("webpack exports") : "__webpack_exports__", V = typeof Symbol == "function" ? Symbol("webpack error") : "__webpack_error__", w = (_) => {
    _ && _.d < 1 && (_.d = 1, _.forEach((U) => U.r--), _.forEach((U) => U.r-- ? U.r++ : U()));
  }, B = (_) => _.map((U) => {
    if (U !== null && typeof U == "object") {
      if (U[ct]) return U;
      if (U.then) {
        var P = [];
        P.d = 0, U.then((v) => {
          T[st] = v, w(P);
        }, (v) => {
          T[V] = v, w(P);
        });
        var T = {};
        return T[ct] = (v) => v(P), T;
      }
    }
    var E = {};
    return E[ct] = (v) => {
    }, E[st] = U, E;
  });
  Pt.a = (_, U, P) => {
    var T;
    P && ((T = []).d = -1);
    var E = /* @__PURE__ */ new Set(), v = _.exports, n, c, l, b = new Promise((s, g) => {
      l = g, c = s;
    });
    b[st] = v, b[ct] = (s) => (T && s(T), E.forEach(s), b.catch((g) => {
    })), _.exports = b, U((s) => {
      n = B(s);
      var g, t = () => n.map((d) => {
        if (d[V]) throw d[V];
        return d[st];
      }), i = new Promise((d) => {
        g = () => d(t), g.r = 0;
        var f = (y) => y !== T && !E.has(y) && (E.add(y), y && !y.d && (g.r++, y.push(g)));
        n.map((y) => y[ct](f));
      });
      return g.r ? i : t();
    }, (s) => (s ? l(b[V] = s) : c(v), w(T))), T && T.d < 0 && (T.d = 0);
  };
})();
Pt.d = (ct, st) => {
  for (var V in st)
    Pt.o(st, V) && !Pt.o(ct, V) && Object.defineProperty(ct, V, { enumerable: !0, get: st[V] });
};
Pt.o = (ct, st) => Object.prototype.hasOwnProperty.call(ct, st);
var ft = Pt(228);
ft = globalThis.pdfjsLib = await (globalThis.pdfjsLibPromise = ft);
var jt = ft.AbortException, Yt = ft.AnnotationEditorLayer, Wt = ft.AnnotationEditorParamsType, qt = ft.AnnotationEditorType, Kt = ft.AnnotationEditorUIManager, Qt = ft.AnnotationLayer, Jt = ft.AnnotationMode, Zt = ft.CMapCompressionType, te = ft.ColorPicker, ee = ft.DOMSVGFactory, se = ft.DrawLayer, ie = ft.FeatureTest, ne = ft.GlobalWorkerOptions, re = ft.ImageKind, ae = ft.InvalidPDFException, oe = ft.MissingPDFException, he = ft.OPS, le = ft.Outliner, ce = ft.PDFDataRangeTransport, de = ft.PDFDateString, ue = ft.PDFWorker, fe = ft.PasswordResponses, pe = ft.PermissionFlag, ge = ft.PixelsPerInch, me = ft.RenderingCancelledException, be = ft.UnexpectedResponseException, Ae = ft.Util, ve = ft.VerbosityLevel, ye = ft.XfaLayer, we = ft.build, Se = ft.createValidAbsoluteUrl, xe = ft.fetchData, Ee = ft.getDocument, Te = ft.getFilenameFromUrl, Ce = ft.getPdfFilenameFromUrl, ke = ft.getXfaPageViewport, Re = ft.isDataScheme, Fe = ft.isPdfFile, Pe = ft.noContextMenu, Le = ft.normalizeUnicode, Me = ft.renderTextLayer, Ie = ft.setLayerDimensions, _e = ft.shadow, De = ft.updateTextLayer, Ne = ft.version;
const Oe = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  AbortException: jt,
  AnnotationEditorLayer: Yt,
  AnnotationEditorParamsType: Wt,
  AnnotationEditorType: qt,
  AnnotationEditorUIManager: Kt,
  AnnotationLayer: Qt,
  AnnotationMode: Jt,
  CMapCompressionType: Zt,
  ColorPicker: te,
  DOMSVGFactory: ee,
  DrawLayer: se,
  FeatureTest: ie,
  GlobalWorkerOptions: ne,
  ImageKind: re,
  InvalidPDFException: ae,
  MissingPDFException: oe,
  OPS: he,
  Outliner: le,
  PDFDataRangeTransport: ce,
  PDFDateString: de,
  PDFWorker: ue,
  PasswordResponses: fe,
  PermissionFlag: pe,
  PixelsPerInch: ge,
  RenderingCancelledException: me,
  UnexpectedResponseException: be,
  Util: Ae,
  VerbosityLevel: ve,
  XfaLayer: ye,
  build: we,
  createValidAbsoluteUrl: Se,
  fetchData: xe,
  getDocument: Ee,
  getFilenameFromUrl: Te,
  getPdfFilenameFromUrl: Ce,
  getXfaPageViewport: ke,
  isDataScheme: Re,
  isPdfFile: Fe,
  noContextMenu: Pe,
  normalizeUnicode: Le,
  renderTextLayer: Me,
  setLayerDimensions: Ie,
  shadow: _e,
  updateTextLayer: De,
  version: Ne
}, Symbol.toStringTag, { value: "Module" }));
var Ut = bt.reactive_import(() => Oe), He = bt.from_html('<div style="justify-content: center; align-items: center; display: flex; flex-direction: column;"><canvas></canvas></div>');
function Ge(ct, st) {
  bt.push(st, !1);
  const V = bt.mutable_source();
  var w = this && this.__awaiter || function(b, s, g, t) {
    function i(d) {
      return d instanceof g ? d : new g(function(f) {
        f(d);
      });
    }
    return new (g || (g = Promise))(function(d, f) {
      function y(M) {
        try {
          L(t.next(M));
        } catch (N) {
          f(N);
        }
      }
      function S(M) {
        try {
          L(t.throw(M));
        } catch (N) {
          f(N);
        }
      }
      function L(M) {
        M.done ? d(M.value) : i(M.value).then(y, S);
      }
      L((t = t.apply(b, s || [])).next());
    });
  };
  let B = bt.prop(st, "value", 8);
  bt.prop(st, "samples_dir", 8);
  let _ = bt.prop(st, "type", 8), U = bt.prop(st, "selected", 8, !1);
  Ut(Ut().GlobalWorkerOptions.workerSrc = "https://cdn.jsdelivr.net/gh/freddyaboulton/gradio-pdf@main/pdf.worker.min.mjs");
  let P, T = bt.mutable_source();
  function E(b) {
    return w(this, void 0, void 0, function* () {
      P = yield Ut().getDocument(b).promise, v();
    });
  }
  function v() {
    P.getPage(1).then((b) => {
      const s = bt.get(T).getContext("2d");
      s.clearRect(0, 0, bt.get(T).width, bt.get(T).height);
      const g = b.getViewport({ scale: 0.2 }), t = { canvasContext: s, viewport: g };
      bt.mutate(T, bt.get(T).width = g.width), bt.mutate(T, bt.get(T).height = g.height), b.render(t);
    });
  }
  bt.legacy_pre_effect(() => bt.deep_read_state(B()), () => {
    bt.set(V, B().url);
  }), bt.legacy_pre_effect(() => bt.get(V), () => {
    E(bt.get(V));
  }), bt.legacy_pre_effect_reset(), bt.init();
  var n = He();
  let c;
  var l = bt.child(n);
  bt.bind_this(l, (b) => bt.set(T, b), () => bt.get(T)), bt.reset(n), bt.template_effect(() => c = bt.set_class(n, 1, "svelte-s3apn9", null, c, {
    table: _() === "table",
    gallery: _() === "gallery",
    selected: U()
  })), bt.append(ct, n), bt.pop();
}
export {
  Ge as default
};
