"""Prompt Unifier CLI - AI prompt template management tool."""

__version__ = "2.1.0"
