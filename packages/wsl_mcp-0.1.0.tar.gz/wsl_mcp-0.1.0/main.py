def main():
    print("Hello from wsl-mcp!")


if __name__ == "__main__":
    main()
