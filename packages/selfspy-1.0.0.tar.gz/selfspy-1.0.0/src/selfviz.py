#!/usr/bin/env python3
"""
Standalone enhanced statistics viewer for Selfspy
"""

if __name__ == "__main__":
    from enhanced_stats import app

    app()
