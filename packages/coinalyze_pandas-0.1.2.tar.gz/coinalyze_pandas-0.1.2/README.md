# Coinalyze-Pandas

`coinalyze-pandas` is a thin, pandas-friendly wrapper around the [Coinalyze](https://coinalyze.net/) API.
---

## Installation

```bash
pip install coinalyze-pandas
# or with Poetry
poetry add coinalyze-pandas
