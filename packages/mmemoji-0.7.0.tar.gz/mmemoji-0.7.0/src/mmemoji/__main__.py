from mmemoji.cli import cli

cli()
