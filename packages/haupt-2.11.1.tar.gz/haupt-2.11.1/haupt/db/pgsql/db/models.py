from haupt.db.models import *  # noqa
