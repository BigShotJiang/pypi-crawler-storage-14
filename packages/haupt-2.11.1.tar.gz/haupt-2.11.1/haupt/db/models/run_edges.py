from haupt.db.abstracts.run_edges import BaseRunEdge


class RunEdge(BaseRunEdge):
    pass
