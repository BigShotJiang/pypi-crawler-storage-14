class PolyCommonException(Exception):
    pass


class AccessNotAuthorized(Exception):
    pass


class AccessNotFound(Exception):
    pass
