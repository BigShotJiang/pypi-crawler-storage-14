class OptionException(AttributeError):
    pass
