class Check:
    @classmethod
    def run(cls):
        raise NotImplementedError
