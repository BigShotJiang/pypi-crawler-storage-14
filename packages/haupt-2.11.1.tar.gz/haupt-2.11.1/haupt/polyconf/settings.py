import os

os.environ["CONFIG_PREFIX"] = "haupt"

from haupt.polyconf.config_manager import PLATFORM_CONFIG  # noqa
from haupt.polyconf.config_settings import *  # noqa
