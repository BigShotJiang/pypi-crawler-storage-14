Glue auto installable module between 'Sale Margin Delivered' and 'Sale
Margin Security' modules.

It restrict usage of fields introduced by margin delivered module to a
group of users, defined in the margin security modules.
