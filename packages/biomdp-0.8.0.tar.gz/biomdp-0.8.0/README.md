# biomdp package

This package contains a set of functions useful for analyzing time series records, particularly biomechanical data. 

The name is a compound of:

biom(echanics) d(ata) p(rocessing)
