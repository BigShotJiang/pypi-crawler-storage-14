### Classes stack

*Connection*

*AgentCommunicator*

*Service*

*HubApp*


