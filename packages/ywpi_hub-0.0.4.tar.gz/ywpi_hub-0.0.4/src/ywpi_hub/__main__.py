from ywpi_hub.main import runserver


if __name__ == '__main__':
    runserver()
