Sometimes it can be really helpful to have an overview of the planned repair orders. This can be especially useful when you need to allocate a free slot to schedule a new repair order.
