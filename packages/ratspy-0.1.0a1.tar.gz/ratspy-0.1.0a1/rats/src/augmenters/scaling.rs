use super::base::Augmenter;
use tracing::{info_span};
/// Augmenter that scales a time series with a random scalar within the range specified 
/// by `min_factor` (inclusive) and `max_factor` (inclusive)
pub struct Scaling {
    pub name: String,
    pub min_factor: f64,
    pub max_factor: f64,
    p: f64,
}

impl Scaling {
    pub fn new(min: f64, max: f64) -> Self {
        Scaling {
            name: "Scaling".to_string(),
            min_factor: min,
            max_factor: max,
            p: 1.0,
        }
    }
}

impl Augmenter for Scaling {
    fn augment_one(&self, x: &[f64]) -> Vec<f64> {
        let span = info_span!("", step = "augment_one");
        let _enter = span.enter();

        let scalar = rand::random_range(self.min_factor..=self.max_factor);
        x.iter().map(|val| *val * scalar).collect()
    }

    fn get_probability(&self) -> f64 {
        self.p
    }

    fn set_probability(&mut self, probability: f64) {
        self.p = probability;
    }

    fn get_name(&self) ->String {
        self.name.clone()
    }
}
