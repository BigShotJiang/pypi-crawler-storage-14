# Arcane ga4 README

This package helps us to interact with Google Analytics V4 API:

    + [Analytics Data API](https://developers.google.com/analytics/devguides/reporting/data/v1)
    + [Google Analytics Admin API](https://developers.google.com/analytics/devguides/config/admin/v1)


## Release history
To see changes, please see CHANGELOG.md
