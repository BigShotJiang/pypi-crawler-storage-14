#!/usr/bin/env python3
"""
SafeKeyLab LangChain Middleware
Callback handler that adds SafeKeyLab protection to any LangChain application

Usage:
    from langchain.llms import OpenAI
    from safekeylab.integrations import SafeKeyLabCallback

    llm = OpenAI(callbacks=[SafeKeyLabCallback()])

    # All LLM calls are now protected
    response = llm("Tell me about...")
"""

import re
import time
import logging
from typing import Any, Dict, List, Optional, Union
from dataclasses import dataclass, field

logger = logging.getLogger(__name__)


class SafeKeyLabBlockedError(Exception):
    """Raised when SafeKeyLab blocks a request"""

    def __init__(self, message: str, details: Dict[str, Any] = None):
        super().__init__(message)
        self.details = details or {}


@dataclass
class CallbackConfig:
    """Configuration for SafeKeyLab callback"""
    # Input validation
    validate_input: bool = True
    on_threat: str = 'block'  # 'block', 'sanitize', 'log'

    # Output validation
    check_output: bool = True
    redact_output_pii: bool = True

    # PII handling
    allowed_pii_types: List[str] = field(default_factory=list)

    # Chain/Agent validation
    validate_tool_calls: bool = True
    allowed_tools: List[str] = field(default_factory=lambda: ['*'])
    blocked_tools: List[str] = field(default_factory=list)

    # Logging
    log_requests: bool = True
    log_responses: bool = False


# Try to import LangChain - gracefully handle if not installed
try:
    from langchain.callbacks.base import BaseCallbackHandler
    from langchain.schema import LLMResult, AgentAction, AgentFinish
    LANGCHAIN_AVAILABLE = True
except ImportError:
    LANGCHAIN_AVAILABLE = False

    # Create placeholder classes
    class BaseCallbackHandler:
        pass

    class LLMResult:
        pass

    class AgentAction:
        pass

    class AgentFinish:
        pass


class SafeKeyLabCallback(BaseCallbackHandler):
    """
    LangChain callback that adds SafeKeyLab protection.

    Validates inputs before LLM calls and checks outputs for PII.

    Usage:
        from langchain.llms import OpenAI
        from safekeylab.integrations import SafeKeyLabCallback

        # Basic usage
        llm = OpenAI(callbacks=[SafeKeyLabCallback()])

        # With configuration
        callback = SafeKeyLabCallback(
            on_threat='sanitize',
            redact_output_pii=True,
            allowed_tools=['search', 'calculator']
        )
        llm = OpenAI(callbacks=[callback])
    """

    def __init__(
        self,
        config: CallbackConfig = None,
        **kwargs
    ):
        if not LANGCHAIN_AVAILABLE:
            logger.warning("LangChain not installed. Callback will be limited.")

        self.config = config or CallbackConfig(**kwargs)
        self._init_patterns()
        self._request_count = 0
        self._blocked_count = 0
        self._pii_detection_count = 0

    def _init_patterns(self):
        """Initialize detection patterns"""
        self._pii_patterns = {
            'SSN': r'\b\d{3}-?\d{2}-?\d{4}\b',
            'EMAIL': r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b',
            'PHONE': r'\b\d{3}[-.]?\d{3}[-.]?\d{4}\b',
            'CREDIT_CARD': r'\b\d{4}[-\s]?\d{4}[-\s]?\d{4}[-\s]?\d{4}\b',
        }

        self._injection_patterns = [
            r'ignore\s+(all\s+)?previous\s+instructions?',
            r'system\s*:\s*',
            r'<\|system\|>',
            r'\[INST\]',
            r'you\s+are\s+now\s+',
            r'pretend\s+(you\s+are|to\s+be)',
            r'forget\s+(all\s+)?previous',
        ]

    # ===== LLM Callbacks =====

    def on_llm_start(
        self,
        serialized: Dict[str, Any],
        prompts: List[str],
        **kwargs
    ):
        """Called when LLM starts - validate inputs"""
        self._request_count += 1

        if not self.config.validate_input:
            return

        for i, prompt in enumerate(prompts):
            check = self._validate_input(prompt)

            if not check['safe']:
                self._blocked_count += 1

                if self.config.on_threat == 'block':
                    raise SafeKeyLabBlockedError(
                        f"Prompt {i} blocked: {check['threat_type']}",
                        details=check
                    )
                elif self.config.on_threat == 'sanitize':
                    prompts[i] = check.get('sanitized', prompt)
                # 'log' mode: just log
                logger.warning(f"SafeKeyLab: Threat detected in prompt {i}: {check['threat_type']}")

        if self.config.log_requests:
            logger.info(f"SafeKeyLab: LLM start - {len(prompts)} prompts")

    def on_llm_end(self, response: 'LLMResult', **kwargs):
        """Called when LLM finishes - check outputs"""
        if not self.config.check_output:
            return

        try:
            for generation in response.generations:
                for gen in generation:
                    pii_check = self._detect_pii(gen.text)

                    if pii_check['found']:
                        self._pii_detection_count += 1

                        if self.config.redact_output_pii:
                            gen.text = pii_check['redacted']
                            logger.info(f"SafeKeyLab: PII redacted from output: {pii_check['types']}")

        except (AttributeError, IndexError) as e:
            logger.debug(f"Could not check LLM output: {e}")

    def on_llm_error(self, error: Exception, **kwargs):
        """Called when LLM errors"""
        logger.error(f"SafeKeyLab: LLM error - {error}")

    # ===== Chat Model Callbacks =====

    def on_chat_model_start(
        self,
        serialized: Dict[str, Any],
        messages: List[List[Any]],
        **kwargs
    ):
        """Called when chat model starts - validate inputs"""
        self._request_count += 1

        if not self.config.validate_input:
            return

        for message_list in messages:
            for msg in message_list:
                # Get content from message
                content = getattr(msg, 'content', str(msg))

                if isinstance(content, str):
                    check = self._validate_input(content)

                    if not check['safe']:
                        self._blocked_count += 1

                        if self.config.on_threat == 'block':
                            raise SafeKeyLabBlockedError(
                                f"Message blocked: {check['threat_type']}",
                                details=check
                            )
                        # Can't easily sanitize in-place for chat messages
                        logger.warning(f"SafeKeyLab: Threat detected: {check['threat_type']}")

    # ===== Chain Callbacks =====

    def on_chain_start(
        self,
        serialized: Dict[str, Any],
        inputs: Dict[str, Any],
        **kwargs
    ):
        """Called when chain starts"""
        if self.config.log_requests:
            chain_type = serialized.get('name', 'Unknown')
            logger.info(f"SafeKeyLab: Chain start - {chain_type}")

    def on_chain_end(self, outputs: Dict[str, Any], **kwargs):
        """Called when chain ends - check outputs"""
        if not self.config.check_output:
            return

        for key, value in outputs.items():
            if isinstance(value, str):
                pii_check = self._detect_pii(value)

                if pii_check['found']:
                    self._pii_detection_count += 1

                    if self.config.redact_output_pii:
                        outputs[key] = pii_check['redacted']

    def on_chain_error(self, error: Exception, **kwargs):
        """Called when chain errors"""
        logger.error(f"SafeKeyLab: Chain error - {error}")

    # ===== Agent Callbacks =====

    def on_agent_action(self, action: 'AgentAction', **kwargs):
        """Called when agent takes an action - validate tool use"""
        if not self.config.validate_tool_calls:
            return

        tool = action.tool

        # Check if tool is blocked
        if tool in self.config.blocked_tools:
            raise SafeKeyLabBlockedError(
                f"Tool '{tool}' is blocked by policy",
                details={'tool': tool}
            )

        # Check if tool is allowed
        if '*' not in self.config.allowed_tools:
            if tool not in self.config.allowed_tools:
                raise SafeKeyLabBlockedError(
                    f"Tool '{tool}' not in allowed list",
                    details={'tool': tool, 'allowed': self.config.allowed_tools}
                )

        # Validate tool input for injections
        tool_input = str(action.tool_input)
        check = self._validate_input(tool_input)

        if not check['safe']:
            if self.config.on_threat == 'block':
                raise SafeKeyLabBlockedError(
                    f"Tool input blocked: {check['threat_type']}",
                    details=check
                )

        logger.info(f"SafeKeyLab: Agent action - tool={tool}")

    def on_agent_finish(self, finish: 'AgentFinish', **kwargs):
        """Called when agent finishes"""
        if not self.config.check_output:
            return

        output = finish.return_values.get('output', '')
        if isinstance(output, str):
            pii_check = self._detect_pii(output)

            if pii_check['found'] and self.config.redact_output_pii:
                finish.return_values['output'] = pii_check['redacted']

    # ===== Tool Callbacks =====

    def on_tool_start(
        self,
        serialized: Dict[str, Any],
        input_str: str,
        **kwargs
    ):
        """Called when tool starts"""
        if self.config.log_requests:
            tool_name = serialized.get('name', 'Unknown')
            logger.info(f"SafeKeyLab: Tool start - {tool_name}")

    def on_tool_end(self, output: str, **kwargs):
        """Called when tool ends - check output"""
        if not self.config.check_output:
            return

        if isinstance(output, str):
            pii_check = self._detect_pii(output)

            if pii_check['found']:
                self._pii_detection_count += 1
                logger.info(f"SafeKeyLab: PII detected in tool output: {pii_check['types']}")

    def on_tool_error(self, error: Exception, **kwargs):
        """Called when tool errors"""
        logger.error(f"SafeKeyLab: Tool error - {error}")

    # ===== Helper Methods =====

    def _validate_input(self, content: str) -> Dict[str, Any]:
        """Validate input for threats"""
        for pattern in self._injection_patterns:
            if re.search(pattern, content, re.IGNORECASE):
                return {
                    'safe': False,
                    'threat_type': 'prompt_injection',
                    'pattern': pattern,
                    'sanitized': self._sanitize_input(content)
                }

        return {'safe': True}

    def _sanitize_input(self, content: str) -> str:
        """Sanitize malicious input"""
        sanitized = content
        for pattern in self._injection_patterns:
            sanitized = re.sub(pattern, '[BLOCKED]', sanitized, flags=re.IGNORECASE)
        return sanitized

    def _detect_pii(self, content: str) -> Dict[str, Any]:
        """Detect PII in content"""
        found_types = []
        redacted = content

        for pii_type, pattern in self._pii_patterns.items():
            if pii_type in self.config.allowed_pii_types:
                continue

            matches = re.findall(pattern, content, re.IGNORECASE)
            if matches:
                found_types.append(pii_type)
                redacted = re.sub(pattern, f'[{pii_type}_REDACTED]', redacted, flags=re.IGNORECASE)

        return {
            'found': len(found_types) > 0,
            'types': found_types,
            'redacted': redacted
        }

    def get_statistics(self) -> Dict[str, Any]:
        """Get callback statistics"""
        return {
            'total_requests': self._request_count,
            'blocked_requests': self._blocked_count,
            'pii_detections': self._pii_detection_count,
            'block_rate': self._blocked_count / self._request_count if self._request_count > 0 else 0
        }


# Convenience function for creating configured callback
def create_safekeylab_callback(
    on_threat: str = 'block',
    redact_output_pii: bool = True,
    allowed_tools: List[str] = None,
    **kwargs
) -> SafeKeyLabCallback:
    """
    Create a configured SafeKeyLab callback.

    Args:
        on_threat: What to do when threat detected ('block', 'sanitize', 'log')
        redact_output_pii: Whether to redact PII from outputs
        allowed_tools: List of allowed tools (for agents)
        **kwargs: Additional config options

    Returns:
        Configured SafeKeyLabCallback instance
    """
    config = CallbackConfig(
        on_threat=on_threat,
        redact_output_pii=redact_output_pii,
        allowed_tools=allowed_tools or ['*'],
        **kwargs
    )
    return SafeKeyLabCallback(config=config)
