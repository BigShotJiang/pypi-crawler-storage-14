#!/usr/bin/env python3
"""
SafeKeyLab OpenAI Wrapper
Drop-in replacement for OpenAI client with SafeKeyLab protection

Usage:
    import openai
    import safekeylab

    client = openai.OpenAI()
    secure_client = safekeylab.wrap(client)

    # Now all calls are protected
    response = secure_client.chat.completions.create(
        model="gpt-4",
        messages=[{"role": "user", "content": user_input}]
    )
"""

import re
import os
import time
import logging
from typing import Any, Dict, List, Optional
from dataclasses import dataclass, field

logger = logging.getLogger(__name__)


@dataclass
class WrapperConfig:
    """Configuration for the OpenAI wrapper"""
    # Input validation
    validate_input: bool = True
    on_threat: str = 'block'  # 'block', 'sanitize', 'log'

    # Output validation
    check_output: bool = True
    redact_output_pii: bool = True

    # PII handling
    allowed_pii_types: List[str] = field(default_factory=list)

    # Logging
    log_requests: bool = True
    log_responses: bool = False  # Don't log responses by default (privacy)

    # Rate limiting
    max_requests_per_minute: int = 60


class SafeKeyLabBlockedError(Exception):
    """Raised when SafeKeyLab blocks a request"""

    def __init__(self, message: str, details: Dict[str, Any] = None):
        super().__init__(message)
        self.details = details or {}


class SecureChatCompletions:
    """Secure wrapper for chat completions"""

    def __init__(self, chat, config: WrapperConfig):
        self._chat = chat
        self._config = config
        self.completions = self  # OpenAI compatibility

        # PII patterns for detection
        self._pii_patterns = {
            'SSN': r'\b\d{3}-?\d{2}-?\d{4}\b',
            'EMAIL': r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b',
            'PHONE': r'\b\d{3}[-.]?\d{3}[-.]?\d{4}\b',
            'CREDIT_CARD': r'\b\d{4}[-\s]?\d{4}[-\s]?\d{4}[-\s]?\d{4}\b',
        }

        # Injection patterns
        self._injection_patterns = [
            r'ignore\s+(all\s+)?previous\s+instructions?',
            r'system\s*:\s*',
            r'<\|system\|>',
            r'you\s+are\s+now\s+',
            r'pretend\s+(you\s+are|to\s+be)',
            r'forget\s+(all\s+)?previous',
            r'disregard\s+(all\s+)?previous',
        ]

    def create(
        self,
        messages: List[Dict[str, str]],
        **kwargs
    ) -> Any:
        """Create chat completion with security checks"""
        start_time = time.time()

        # 1. Validate all user messages
        if self._config.validate_input:
            for i, msg in enumerate(messages):
                if msg.get('role') == 'user':
                    content = msg.get('content', '')
                    if isinstance(content, str):
                        check = self._validate_input(content)

                        if not check['safe']:
                            if self._config.on_threat == 'block':
                                raise SafeKeyLabBlockedError(
                                    f"Input blocked: {check['threat_type']}",
                                    details=check
                                )
                            elif self._config.on_threat == 'sanitize':
                                messages[i]['content'] = check.get('sanitized', content)
                            # 'log' mode: just log and continue

        # 2. Log request if enabled
        if self._config.log_requests:
            logger.info(f"SafeKeyLab: OpenAI request - model={kwargs.get('model', 'unknown')}")

        # 3. Make the API call
        response = self._chat.completions.create(messages=messages, **kwargs)

        # 4. Check response for PII
        if self._config.check_output:
            try:
                content = response.choices[0].message.content
                if content:
                    pii_check = self._detect_pii(content)

                    if pii_check['found'] and self._config.redact_output_pii:
                        # Create modified response content
                        response.choices[0].message.content = pii_check['redacted']
                        # Add metadata
                        if not hasattr(response, '_safekeylab'):
                            response._safekeylab = {}
                        response._safekeylab['redacted'] = True
                        response._safekeylab['pii_types'] = pii_check['types']
            except (AttributeError, IndexError):
                pass

        # 5. Log completion time
        elapsed = (time.time() - start_time) * 1000
        logger.debug(f"SafeKeyLab: Request completed in {elapsed:.2f}ms")

        return response

    async def acreate(self, messages: List[Dict[str, str]], **kwargs) -> Any:
        """Async version of create"""
        # Same logic but async
        if self._config.validate_input:
            for i, msg in enumerate(messages):
                if msg.get('role') == 'user':
                    content = msg.get('content', '')
                    if isinstance(content, str):
                        check = self._validate_input(content)
                        if not check['safe']:
                            if self._config.on_threat == 'block':
                                raise SafeKeyLabBlockedError(
                                    f"Input blocked: {check['threat_type']}",
                                    details=check
                                )
                            elif self._config.on_threat == 'sanitize':
                                messages[i]['content'] = check.get('sanitized', content)

        # Make async API call
        response = await self._chat.completions.acreate(messages=messages, **kwargs)

        # Check output
        if self._config.check_output:
            try:
                content = response.choices[0].message.content
                if content:
                    pii_check = self._detect_pii(content)
                    if pii_check['found'] and self._config.redact_output_pii:
                        response.choices[0].message.content = pii_check['redacted']
            except (AttributeError, IndexError):
                pass

        return response

    def _validate_input(self, content: str) -> Dict[str, Any]:
        """Validate input for threats"""
        # Check for injection patterns
        for pattern in self._injection_patterns:
            if re.search(pattern, content, re.IGNORECASE):
                return {
                    'safe': False,
                    'threat_type': 'prompt_injection',
                    'pattern': pattern,
                    'sanitized': self._sanitize_input(content)
                }

        return {'safe': True}

    def _sanitize_input(self, content: str) -> str:
        """Sanitize malicious input"""
        sanitized = content

        # Neutralize injection patterns
        for pattern in self._injection_patterns:
            sanitized = re.sub(
                pattern,
                '[BLOCKED]',
                sanitized,
                flags=re.IGNORECASE
            )

        return sanitized

    def _detect_pii(self, content: str) -> Dict[str, Any]:
        """Detect PII in content"""
        found_types = []
        redacted = content

        for pii_type, pattern in self._pii_patterns.items():
            if pii_type in self._config.allowed_pii_types:
                continue

            matches = re.findall(pattern, content, re.IGNORECASE)
            if matches:
                found_types.append(pii_type)
                redacted = re.sub(
                    pattern,
                    f'[{pii_type}_REDACTED]',
                    redacted,
                    flags=re.IGNORECASE
                )

        return {
            'found': len(found_types) > 0,
            'types': found_types,
            'redacted': redacted
        }


class SecureOpenAI:
    """Drop-in replacement for OpenAI client with SafeKeyLab protection"""

    def __init__(
        self,
        openai_client: Any,
        config: WrapperConfig = None
    ):
        self._client = openai_client
        self._config = config or WrapperConfig()

        # Wrap the chat completions
        self.chat = type('Chat', (), {
            'completions': SecureChatCompletions(
                self._client.chat,
                self._config
            )
        })()

        # Pass through other attributes
        self.models = self._client.models
        self.embeddings = self._client.embeddings
        self.files = getattr(self._client, 'files', None)
        self.images = getattr(self._client, 'images', None)
        self.audio = getattr(self._client, 'audio', None)

    def __getattr__(self, name):
        """Pass through any other attributes to the underlying client"""
        return getattr(self._client, name)


def wrap_openai(
    openai_client: Any,
    **config_kwargs
) -> SecureOpenAI:
    """
    Wrap an OpenAI client with SafeKeyLab protection.

    Usage:
        import openai
        from safekeylab import wrap_openai

        client = openai.OpenAI()
        secure_client = wrap_openai(client)

        # Now all calls are protected
        response = secure_client.chat.completions.create(
            model="gpt-4",
            messages=[{"role": "user", "content": user_input}]
        )

    Args:
        openai_client: The OpenAI client instance
        **config_kwargs: Configuration options
            - validate_input: bool (default True) - Validate inputs for threats
            - on_threat: str (default 'block') - 'block', 'sanitize', or 'log'
            - check_output: bool (default True) - Check outputs for PII
            - redact_output_pii: bool (default True) - Redact PII from outputs

    Returns:
        SecureOpenAI instance
    """
    config = WrapperConfig(**config_kwargs)
    return SecureOpenAI(openai_client, config)


# Convenience function for quick wrapping
def wrap(client: Any, **kwargs) -> Any:
    """
    Universal wrap function - detects client type and wraps appropriately.

    Usage:
        import safekeylab

        # Works with OpenAI
        openai_client = safekeylab.wrap(openai.OpenAI())

        # Works with Anthropic
        anthropic_client = safekeylab.wrap(anthropic.Anthropic())
    """
    client_type = type(client).__name__

    if 'OpenAI' in client_type:
        return wrap_openai(client, **kwargs)
    elif 'Anthropic' in client_type:
        from .anthropic_wrapper import wrap_anthropic
        return wrap_anthropic(client, **kwargs)
    else:
        logger.warning(f"Unknown client type: {client_type}. Returning unwrapped.")
        return client
