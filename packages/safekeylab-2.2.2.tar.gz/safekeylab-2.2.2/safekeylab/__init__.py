"""
SafeKeyLab SDK - Enterprise PII Detection, Data Protection, and LLM Security

Features:
- PII Detection & Redaction
- LLM Guard (prompt injection, jailbreak detection)
- One-line SDK wrappers (OpenAI, Anthropic, LangChain)
- Agent Security
- RAG Security
"""

__version__ = "2.2.2"
__author__ = "SafeKey Lab Inc."

from .client import SafeKeyLab
from .client_v2 import (
    SafeKeyLabClient,
    RateLimitException,
    QuotaExceededException,
    FeatureNotAvailableException,
    create_client
)
from .scanner import PIIScanner
from .protector import DataProtector
from .exceptions import SafeKeyLabException, APIError, ValidationError
from .llm_guard import LLMGuardClient, ThreatDetector, ComplianceManager

# One-line SDK wrappers
from .openai_wrapper import wrap_openai, SecureOpenAI, WrapperConfig
from .anthropic_wrapper import wrap_anthropic, SecureAnthropic
from .langchain_middleware import SafeKeyLabCallback, get_safekeylab_callback

__all__ = [
    # Core client
    "SafeKeyLab",
    # New v2 client with subscription support
    "SafeKeyLabClient",
    "create_client",
    "RateLimitException",
    "QuotaExceededException",
    "FeatureNotAvailableException",
    # PII detection
    "PIIScanner",
    "DataProtector",
    # Exceptions
    "SafeKeyLabException",
    "APIError",
    "ValidationError",
    # LLM Guard features
    "LLMGuardClient",
    "ThreatDetector",
    "ComplianceManager",
    # One-line SDK wrappers (NEW in 2.3.0)
    "wrap_openai",
    "wrap_anthropic",
    "SecureOpenAI",
    "SecureAnthropic",
    "WrapperConfig",
    "SafeKeyLabCallback",
    "get_safekeylab_callback",
]


# Convenience function for wrapping any supported client
def wrap(client, **config_kwargs):
    """
    Wrap any supported LLM client with SafeKeyLab protection.

    Supported clients:
    - OpenAI (openai.OpenAI)
    - Anthropic (anthropic.Anthropic)

    Usage:
        import openai
        import safekeylab

        client = openai.OpenAI()
        secure_client = safekeylab.wrap(client)

        # All calls are now protected
        response = secure_client.chat.completions.create(...)
    """
    client_type = type(client).__name__
    module = type(client).__module__

    if 'openai' in module.lower() or client_type == 'OpenAI':
        return wrap_openai(client, **config_kwargs)
    elif 'anthropic' in module.lower() or client_type == 'Anthropic':
        return wrap_anthropic(client, **config_kwargs)
    else:
        raise ValueError(
            f"Unsupported client type: {client_type}. "
            "Supported: OpenAI, Anthropic. "
            "For LangChain, use SafeKeyLabCallback instead."
        )
