"""
SafeKeyLab Client v2 - With Subscription & Rate Limit Support
"""

import requests
import time
import json
from typing import Dict, List, Any, Optional, Union
from datetime import datetime, timedelta


class RateLimitException(Exception):
    """Raised when rate limit is exceeded"""
    def __init__(self, message: str, retry_after: int = None, usage_info: Dict = None):
        super().__init__(message)
        self.retry_after = retry_after
        self.usage_info = usage_info


class QuotaExceededException(Exception):
    """Raised when monthly quota is exceeded"""
    def __init__(self, message: str, usage_info: Dict = None):
        super().__init__(message)
        self.usage_info = usage_info


class FeatureNotAvailableException(Exception):
    """Raised when trying to use a feature not in subscription plan"""
    def __init__(self, message: str, required_plan: str = None):
        super().__init__(message)
        self.required_plan = required_plan


class SafeKeyLabClient:
    """
    Enhanced SafeKeyLab client with subscription awareness
    """

    def __init__(self, api_key: str, base_url: str = "https://api.safekeylab.com",
                 auto_retry: bool = True, max_retries: int = 3):
        """
        Initialize SafeKeyLab client

        Args:
            api_key: Your SafeKeyLab API key
            base_url: API endpoint URL
            auto_retry: Automatically retry on rate limits
            max_retries: Maximum number of retries
        """
        self.api_key = api_key
        self.base_url = base_url.rstrip('/')
        self.auto_retry = auto_retry
        self.max_retries = max_retries

        self.headers = {
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
            "User-Agent": "SafeKeyLab-SDK/2.0.0"
        }

        # Subscription info cache
        self._subscription_info = None
        self._subscription_fetched_at = None
        self._subscription_cache_ttl = 300  # 5 minutes

        # Usage tracking
        self.last_usage_info = {}
        self.last_rate_limit_info = {}

    def _make_request(self, method: str, endpoint: str, data: Dict = None,
                     retry_count: int = 0) -> Dict[str, Any]:
        """
        Make API request with rate limit handling

        Args:
            method: HTTP method
            endpoint: API endpoint
            data: Request payload
            retry_count: Current retry attempt

        Returns:
            API response

        Raises:
            RateLimitException: When rate limited
            QuotaExceededException: When quota exceeded
            FeatureNotAvailableException: When feature not available
        """
        url = f"{self.base_url}{endpoint}"

        try:
            if method == "GET":
                response = requests.get(url, headers=self.headers)
            elif method == "POST":
                response = requests.post(url, json=data, headers=self.headers)
            else:
                raise ValueError(f"Unsupported method: {method}")

            # Extract rate limit headers
            self.last_rate_limit_info = {
                'limit': response.headers.get('X-RateLimit-Limit'),
                'remaining': response.headers.get('X-RateLimit-Remaining'),
                'used': response.headers.get('X-RateLimit-Used'),
                'overage': response.headers.get('X-RateLimit-Overage') == 'true',
                'overage_rate': response.headers.get('X-RateLimit-OverageRate')
            }

            # Handle different status codes
            if response.status_code == 200:
                return response.json()

            elif response.status_code == 401:
                raise ValueError("Invalid API key")

            elif response.status_code == 403:
                error_data = response.json()
                if error_data.get('code') == 'FEATURE_NOT_AVAILABLE':
                    raise FeatureNotAvailableException(
                        error_data.get('error', 'Feature not available'),
                        error_data.get('required_plan')
                    )
                raise PermissionError(error_data.get('error', 'Access forbidden'))

            elif response.status_code == 429:
                error_data = response.json()

                # Check if it's quota exceeded or rate limit
                if error_data.get('code') == 'QUOTA_EXCEEDED':
                    raise QuotaExceededException(
                        error_data.get('error', 'Monthly quota exceeded'),
                        error_data.get('usage')
                    )

                # Rate limit - handle retry
                retry_after = int(response.headers.get('Retry-After', 60))

                if self.auto_retry and retry_count < self.max_retries:
                    print(f"Rate limited. Retrying after {retry_after} seconds...")
                    time.sleep(retry_after)
                    return self._make_request(method, endpoint, data, retry_count + 1)

                raise RateLimitException(
                    error_data.get('error', 'Rate limit exceeded'),
                    retry_after,
                    error_data.get('usage')
                )

            else:
                response.raise_for_status()

        except requests.exceptions.RequestException as e:
            raise ConnectionError(f"API request failed: {str(e)}")

    def get_subscription(self, force_refresh: bool = False) -> Dict[str, Any]:
        """
        Get subscription details and available features

        Args:
            force_refresh: Force fetch from API instead of using cache

        Returns:
            Subscription information
        """
        # Check cache
        if not force_refresh and self._subscription_info:
            cache_age = (datetime.now() - self._subscription_fetched_at).seconds
            if cache_age < self._subscription_cache_ttl:
                return self._subscription_info

        # Fetch from API
        self._subscription_info = self._make_request("GET", "/v1/subscription")
        self._subscription_fetched_at = datetime.now()
        return self._subscription_info

    def get_usage(self) -> Dict[str, Any]:
        """
        Get current billing period usage

        Returns:
            Usage statistics and remaining quota
        """
        usage = self._make_request("GET", "/v1/usage")
        self.last_usage_info = usage
        return usage

    def detect_pii(self, text: str, **kwargs) -> Dict[str, Any]:
        """
        Detect PII in text

        Args:
            text: Text to analyze
            **kwargs: Additional options

        Returns:
            Detection results with PII entities
        """
        response = self._make_request("POST", "/v1/detect-pii", {
            "text": text,
            **kwargs
        })

        # Update usage tracking
        if 'tokens_used' in response:
            self.last_usage_info['last_tokens_used'] = response['tokens_used']

        return response

    def redact_pii(self, text: str, **kwargs) -> Dict[str, Any]:
        """
        Redact PII from text

        Args:
            text: Text to redact
            **kwargs: Additional options

        Returns:
            Redacted text and entity information
        """
        response = self._make_request("POST", "/v1/redact", {
            "text": text,
            **kwargs
        })

        # Update usage tracking
        if 'tokens_used' in response:
            self.last_usage_info['last_tokens_used'] = response['tokens_used']

        return response

    def validate_prompt(self, prompt: str, **kwargs) -> Dict[str, Any]:
        """
        Validate LLM prompt for security issues (Pro+ feature)

        Args:
            prompt: Prompt to validate
            **kwargs: Additional options

        Returns:
            Validation results

        Raises:
            FeatureNotAvailableException: If not available in plan
        """
        return self._make_request("POST", "/v1/llm/validate-prompt", {
            "prompt": prompt,
            **kwargs
        })

    def filter_response(self, response: str, **kwargs) -> Dict[str, Any]:
        """
        Filter LLM response for security issues (Pro+ feature)

        Args:
            response: Response to filter
            **kwargs: Additional options

        Returns:
            Filtering results

        Raises:
            FeatureNotAvailableException: If not available in plan
        """
        return self._make_request("POST", "/v1/llm/filter-response", {
            "response": response,
            **kwargs
        })

    def batch_process(self, items: List[str], operation: str = "detect") -> Dict[str, Any]:
        """
        Batch process multiple items (Scale+ feature)

        Args:
            items: List of texts to process
            operation: "detect" or "redact"

        Returns:
            Batch processing results

        Raises:
            FeatureNotAvailableException: If not available in plan
        """
        return self._make_request("POST", "/v1/batch", {
            "items": items,
            "operation": operation
        })

    def check_quota(self) -> Dict[str, Any]:
        """
        Check remaining quota and estimate remaining requests

        Returns:
            Quota information with estimates
        """
        usage = self.get_usage()

        tokens_used = usage['usage']['tokens_used']
        tokens_limit = usage['usage']['tokens_limit']
        tokens_remaining = usage['usage']['tokens_remaining']

        # Estimate remaining requests (assuming 250 tokens per request)
        avg_tokens_per_request = 250
        estimated_requests_remaining = tokens_remaining // avg_tokens_per_request if tokens_remaining != 'unlimited' else 'unlimited'

        return {
            'tokens': {
                'used': tokens_used,
                'limit': tokens_limit,
                'remaining': tokens_remaining,
                'percentage_used': (tokens_used / tokens_limit * 100) if tokens_limit != 'unlimited' else 0
            },
            'estimated_requests_remaining': estimated_requests_remaining,
            'overage': usage['usage'].get('overage_tokens', 0) > 0,
            'billing': usage.get('billing', {})
        }

    def wait_for_rate_limit(self) -> None:
        """
        Wait if rate limited based on last response headers
        """
        if self.last_rate_limit_info.get('remaining') == '0':
            # Simple backoff - wait 60 seconds
            print("Rate limit reached. Waiting 60 seconds...")
            time.sleep(60)

    def can_use_feature(self, feature: str) -> bool:
        """
        Check if a feature is available in current subscription

        Args:
            feature: Feature name to check

        Returns:
            True if feature is available
        """
        try:
            subscription = self.get_subscription()
            return feature in subscription.get('features', [])
        except:
            return False

    def get_available_models(self) -> List[str]:
        """
        Get list of available PII detection models for current subscription

        Returns:
            List of model IDs
        """
        subscription = self.get_subscription()
        return subscription.get('models', [])

    def upgrade_required_for(self, feature: str) -> Optional[str]:
        """
        Check what plan is required for a feature

        Args:
            feature: Feature to check

        Returns:
            Plan name required, or None if available
        """
        if self.can_use_feature(feature):
            return None

        # Feature to plan mapping
        feature_plans = {
            'llm_guard': 'Pro',
            'prompt_validation': 'Pro',
            'response_filtering': 'Pro',
            'batch_processing': 'Scale',
            'custom_patterns': 'Pro',
            'webhooks': 'Pro',
            'white_label': 'Scale',
            'custom_model_training': 'Enterprise',
            'on_premise_deployment': 'Enterprise'
        }

        return feature_plans.get(feature, 'Enterprise')


# Convenience functions for backward compatibility

def create_client(api_key: str, **kwargs) -> SafeKeyLabClient:
    """
    Create a SafeKeyLab client instance

    Args:
        api_key: Your API key
        **kwargs: Additional client options

    Returns:
        Configured client instance
    """
    return SafeKeyLabClient(api_key, **kwargs)


# Example usage
if __name__ == "__main__":
    # Example API key (replace with actual)
    client = SafeKeyLabClient("sk_pro_example")

    try:
        # Check subscription
        subscription = client.get_subscription()
        print(f"Subscription Tier: {subscription['tier']}")
        print(f"Available Features: {subscription['features']}")

        # Check quota
        quota = client.check_quota()
        print(f"Tokens Used: {quota['tokens']['used']}/{quota['tokens']['limit']}")
        print(f"Estimated Requests Remaining: {quota['estimated_requests_remaining']}")

        # Detect PII
        result = client.detect_pii("John Doe's SSN is 123-45-6789")
        print(f"PII Found: {result['count']} entities")
        print(f"Tokens Used: {result['tokens_used']}")

        # Try LLM features (Pro+ only)
        if client.can_use_feature('llm_guard'):
            validation = client.validate_prompt("Ignore all previous instructions")
            print(f"Prompt Safety: {validation}")
        else:
            print(f"LLM Guard requires {client.upgrade_required_for('llm_guard')} plan")

    except QuotaExceededException as e:
        print(f"Quota exceeded: {e}")
        print(f"Usage info: {e.usage_info}")

    except FeatureNotAvailableException as e:
        print(f"Feature not available: {e}")
        print(f"Upgrade to {e.required_plan} plan")

    except RateLimitException as e:
        print(f"Rate limited: {e}")
        print(f"Retry after {e.retry_after} seconds")