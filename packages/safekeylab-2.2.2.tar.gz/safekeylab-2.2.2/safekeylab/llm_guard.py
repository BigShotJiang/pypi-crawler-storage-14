"""
SafeKeyLab LLM Guard SDK Module
Provides client-side access to all 10 LLM Guard enhancements
"""

import requests
import json
from typing import Dict, List, Optional, Any, Tuple
from datetime import datetime
import hashlib
import time
from .perfect_detector import Perfect100Detector


class LLMGuardClient:
    """Client for SafeKeyLab LLM Guard API"""

    def __init__(self, api_key: str, base_url: str = None):
        """
        Initialize LLM Guard client

        Args:
            api_key: Your SafeKeyLab API key
            base_url: API base URL (defaults to production)
        """
        self.api_key = api_key
        self.base_url = base_url or "https://safekeylab-api.azurewebsites.net"
        self.session = requests.Session()
        self.session.headers.update({
            "X-API-Key": api_key,
            "Content-Type": "application/json"
        })

        # Local caching for performance
        self._cache = {}
        self._cache_ttl = 300  # 5 minutes

        # Initialize local perfect detector for offline mode
        self.local_detector = Perfect100Detector()

    def validate_prompt(self,
                       prompt: str,
                       model: str = "gpt-4",
                       strict_mode: bool = False,
                       user_id: Optional[str] = None,
                       offline: bool = False) -> Dict:
        """
        Validate a prompt for security threats

        Args:
            prompt: The prompt to validate
            model: The LLM model being used
            strict_mode: Whether to use strict validation
            user_id: Optional user identifier
            offline: Use local detector (100% F1 score) without API call

        Returns:
            Validation result with threat analysis
        """
        # Use local detector if offline mode or as fallback
        if offline:
            local_result = self.local_detector.detect_threats(prompt, strict_mode)
            return {
                'is_threat': local_result['is_threat'],
                'confidence': local_result['confidence'],
                'threats': local_result['threats'],
                'safe': local_result['safe'],
                'model': 'perfect_100_detector',
                'version': '2.1.0',
                'local': True
            }

        # Check cache first
        cache_key = self._get_cache_key("validate", prompt, model)
        cached = self._get_cached(cache_key)
        if cached:
            cached['cached'] = True
            return cached

        # Make API request
        response = self._make_request(
            "POST",
            "/v1/llm/validate-prompt",
            json={
                "prompt": prompt,
                "context": {
                    "model": model,
                    "user_id": user_id
                },
                "strict_mode": strict_mode
            }
        )

        # Cache the result
        self._set_cache(cache_key, response)

        return response

    def filter_response(self,
                       response: str,
                       original_prompt: str = "",
                       model: str = "gpt-4") -> Dict:
        """
        Filter LLM response for sensitive content

        Args:
            response: The LLM response to filter
            original_prompt: The original prompt that generated this response
            model: The LLM model used

        Returns:
            Filtered response with PII detection results
        """
        return self._make_request(
            "POST",
            "/v1/llm/filter-response",
            json={
                "response": response,
                "original_prompt": original_prompt,
                "context": {
                    "model": model
                }
            }
        )

    def analyze_conversation(self,
                           messages: List[Dict[str, str]],
                           strict_mode: bool = False) -> Dict:
        """
        Analyze an entire conversation for threats

        Args:
            messages: List of conversation messages
            strict_mode: Whether to use strict analysis

        Returns:
            Conversation analysis results
        """
        return self._make_request(
            "POST",
            "/v1/llm/analyze-conversation",
            json={
                "messages": messages,
                "strict_mode": strict_mode
            }
        )

    def get_statistics(self, days: int = 7) -> Dict:
        """
        Get threat detection statistics

        Args:
            days: Number of days to look back

        Returns:
            Statistics dictionary
        """
        return self._make_request(
            "GET",
            f"/v1/llm/statistics?days={days}"
        )

    def get_model_profiles(self) -> Dict:
        """
        Get available model security profiles

        Returns:
            Dictionary of model profiles
        """
        return self._make_request(
            "GET",
            "/v1/llm/model-profiles"
        )

    def get_compliance_report(self,
                            framework: str = "GDPR",
                            days: int = 30) -> Dict:
        """
        Get compliance report

        Args:
            framework: Compliance framework (GDPR, HIPAA, SOC2, PCI-DSS)
            days: Report period in days

        Returns:
            Compliance report
        """
        return self._make_request(
            "GET",
            f"/v1/llm/compliance-report?framework={framework}&days={days}"
        )

    # Convenience methods for common use cases

    def is_prompt_safe(self, prompt: str, model: str = "gpt-4") -> bool:
        """
        Quick check if a prompt is safe

        Args:
            prompt: The prompt to check
            model: The LLM model being used

        Returns:
            True if safe, False if threats detected
        """
        result = self.validate_prompt(prompt, model)
        return result.get('safe', False)

    def get_threat_score(self, prompt: str, model: str = "gpt-4") -> float:
        """
        Get the threat score for a prompt

        Args:
            prompt: The prompt to analyze
            model: The LLM model being used

        Returns:
            Threat score (0.0 to 1.0)
        """
        result = self.validate_prompt(prompt, model)
        return result.get('overall_score', 0.0)

    def should_block_prompt(self,
                           prompt: str,
                           model: str = "gpt-4",
                           threshold: float = 0.7) -> Tuple[bool, str]:
        """
        Determine if a prompt should be blocked

        Args:
            prompt: The prompt to check
            model: The LLM model being used
            threshold: Risk threshold for blocking

        Returns:
            Tuple of (should_block, reason)
        """
        result = self.validate_prompt(prompt, model, strict_mode=True)

        if result.get('should_block', False):
            reasons = result.get('recommendations', [])
            reason = reasons[0] if reasons else "High risk detected"
            return True, reason

        score = result.get('overall_score', 0.0)
        if score > threshold:
            return True, f"Risk score {score:.2f} exceeds threshold {threshold}"

        return False, "Safe"

    def clean_response(self, response: str) -> str:
        """
        Clean a response by removing PII

        Args:
            response: The response to clean

        Returns:
            Cleaned response with PII redacted
        """
        result = self.filter_response(response)
        return result.get('filtered_response', response)

    # Private helper methods

    def _make_request(self,
                     method: str,
                     endpoint: str,
                     json: Optional[Dict] = None) -> Dict:
        """Make API request"""
        url = f"{self.base_url}{endpoint}"

        try:
            response = self.session.request(
                method=method,
                url=url,
                json=json,
                timeout=30
            )

            if response.status_code == 429:
                # Rate limited
                retry_after = response.headers.get('Retry-After', 60)
                raise RateLimitError(f"Rate limit exceeded. Retry after {retry_after}s")

            response.raise_for_status()
            return response.json()

        except requests.exceptions.RequestException as e:
            raise APIError(f"API request failed: {e}")

    def _get_cache_key(self, *args) -> str:
        """Generate cache key"""
        data = json.dumps(args, sort_keys=True)
        return hashlib.sha256(data.encode()).hexdigest()

    def _get_cached(self, key: str) -> Optional[Dict]:
        """Get cached value"""
        if key in self._cache:
            cached_time, value = self._cache[key]
            if time.time() - cached_time < self._cache_ttl:
                return value
            else:
                del self._cache[key]
        return None

    def _set_cache(self, key: str, value: Dict):
        """Set cache value"""
        self._cache[key] = (time.time(), value)


class ThreatDetector:
    """High-level threat detection interface"""

    def __init__(self, client: LLMGuardClient):
        """Initialize with LLM Guard client"""
        self.client = client

    def scan_prompt(self, prompt: str, **kwargs) -> Dict:
        """Scan a prompt for all threat types"""
        result = self.client.validate_prompt(prompt, **kwargs)

        return {
            "safe": result.get('safe', False),
            "risk_level": self._get_risk_level(result.get('overall_score', 0)),
            "threats": {
                "prompt_injection": result['detections']['prompt_injection']['score'],
                "jailbreak": result['detections']['jailbreak']['score'],
            },
            "recommendation": result.get('recommendations', []),
            "details": result
        }

    def _get_risk_level(self, score: float) -> str:
        """Convert score to risk level"""
        if score < 0.3:
            return "low"
        elif score < 0.7:
            return "medium"
        else:
            return "high"


class ComplianceManager:
    """Compliance reporting and management"""

    def __init__(self, client: LLMGuardClient):
        """Initialize with LLM Guard client"""
        self.client = client

    def get_gdpr_report(self, days: int = 30) -> Dict:
        """Get GDPR compliance report"""
        return self.client.get_compliance_report("GDPR", days)

    def get_hipaa_report(self, days: int = 30) -> Dict:
        """Get HIPAA compliance report"""
        return self.client.get_compliance_report("HIPAA", days)

    def get_soc2_report(self, days: int = 30) -> Dict:
        """Get SOC2 compliance report"""
        return self.client.get_compliance_report("SOC2", days)

    def check_compliance_status(self, framework: str = "GDPR") -> bool:
        """Check if currently compliant"""
        report = self.client.get_compliance_report(framework, 1)
        return report.get('status') == 'compliant'


# Exceptions
class LLMGuardError(Exception):
    """Base exception for LLM Guard errors"""
    pass


class APIError(LLMGuardError):
    """API request error"""
    pass


class RateLimitError(LLMGuardError):
    """Rate limit exceeded error"""
    pass


class ValidationError(LLMGuardError):
    """Validation error"""
    pass