#!/usr/bin/env python3
"""
SafeKeyLab Anthropic Wrapper
Drop-in replacement for Anthropic client with SafeKeyLab protection

Usage:
    import anthropic
    from safekeylab import wrap_anthropic

    client = anthropic.Anthropic()
    secure_client = wrap_anthropic(client)

    # Now all calls are protected
    response = secure_client.messages.create(
        model="claude-3-opus-20240229",
        max_tokens=1024,
        messages=[{"role": "user", "content": user_input}]
    )
"""

import re
import time
import logging
from typing import Any, Dict, List, Optional
from dataclasses import dataclass, field

logger = logging.getLogger(__name__)


@dataclass
class AnthropicWrapperConfig:
    """Configuration for the Anthropic wrapper"""
    # Input validation
    validate_input: bool = True
    on_threat: str = 'block'  # 'block', 'sanitize', 'log'

    # Output validation
    check_output: bool = True
    redact_output_pii: bool = True

    # PII handling
    allowed_pii_types: List[str] = field(default_factory=list)

    # Logging
    log_requests: bool = True


class SafeKeyLabBlockedError(Exception):
    """Raised when SafeKeyLab blocks a request"""

    def __init__(self, message: str, details: Dict[str, Any] = None):
        super().__init__(message)
        self.details = details or {}


class SecureMessages:
    """Secure wrapper for Anthropic messages"""

    def __init__(self, messages_client, config: AnthropicWrapperConfig):
        self._messages = messages_client
        self._config = config

        # PII patterns
        self._pii_patterns = {
            'SSN': r'\b\d{3}-?\d{2}-?\d{4}\b',
            'EMAIL': r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b',
            'PHONE': r'\b\d{3}[-.]?\d{3}[-.]?\d{4}\b',
            'CREDIT_CARD': r'\b\d{4}[-\s]?\d{4}[-\s]?\d{4}[-\s]?\d{4}\b',
        }

        # Injection patterns
        self._injection_patterns = [
            r'ignore\s+(all\s+)?previous\s+instructions?',
            r'system\s*:\s*',
            r'<\|system\|>',
            r'\[INST\]',
            r'you\s+are\s+now\s+',
            r'pretend\s+(you\s+are|to\s+be)',
            r'forget\s+(all\s+)?previous',
        ]

    def create(
        self,
        model: str,
        messages: List[Dict[str, Any]],
        max_tokens: int,
        **kwargs
    ) -> Any:
        """Create message with security checks"""
        start_time = time.time()

        # 1. Validate user messages
        if self._config.validate_input:
            for i, msg in enumerate(messages):
                if msg.get('role') == 'user':
                    content = msg.get('content', '')

                    # Handle string content
                    if isinstance(content, str):
                        check = self._validate_input(content)
                        if not check['safe']:
                            self._handle_threat(check, messages, i)

                    # Handle list content (multimodal)
                    elif isinstance(content, list):
                        for j, block in enumerate(content):
                            if block.get('type') == 'text':
                                text = block.get('text', '')
                                check = self._validate_input(text)
                                if not check['safe']:
                                    if self._config.on_threat == 'block':
                                        raise SafeKeyLabBlockedError(
                                            f"Input blocked: {check['threat_type']}",
                                            details=check
                                        )
                                    elif self._config.on_threat == 'sanitize':
                                        messages[i]['content'][j]['text'] = check.get('sanitized', text)

        # 2. Log request
        if self._config.log_requests:
            logger.info(f"SafeKeyLab: Anthropic request - model={model}")

        # 3. Make API call
        response = self._messages.create(
            model=model,
            messages=messages,
            max_tokens=max_tokens,
            **kwargs
        )

        # 4. Check output for PII
        if self._config.check_output:
            try:
                # Anthropic response has content blocks
                for i, block in enumerate(response.content):
                    if block.type == 'text':
                        pii_check = self._detect_pii(block.text)

                        if pii_check['found'] and self._config.redact_output_pii:
                            # Modify the text block
                            response.content[i].text = pii_check['redacted']

                            # Add metadata
                            if not hasattr(response, '_safekeylab'):
                                response._safekeylab = {}
                            response._safekeylab['redacted'] = True
                            response._safekeylab['pii_types'] = pii_check['types']

            except (AttributeError, IndexError) as e:
                logger.debug(f"Could not check output: {e}")

        # 5. Log completion
        elapsed = (time.time() - start_time) * 1000
        logger.debug(f"SafeKeyLab: Request completed in {elapsed:.2f}ms")

        return response

    async def acreate(
        self,
        model: str,
        messages: List[Dict[str, Any]],
        max_tokens: int,
        **kwargs
    ) -> Any:
        """Async version of create"""
        # Validate inputs
        if self._config.validate_input:
            for i, msg in enumerate(messages):
                if msg.get('role') == 'user':
                    content = msg.get('content', '')
                    if isinstance(content, str):
                        check = self._validate_input(content)
                        if not check['safe']:
                            self._handle_threat(check, messages, i)

        # Make async API call
        response = await self._messages.acreate(
            model=model,
            messages=messages,
            max_tokens=max_tokens,
            **kwargs
        )

        # Check output
        if self._config.check_output:
            try:
                for i, block in enumerate(response.content):
                    if block.type == 'text':
                        pii_check = self._detect_pii(block.text)
                        if pii_check['found'] and self._config.redact_output_pii:
                            response.content[i].text = pii_check['redacted']
            except (AttributeError, IndexError):
                pass

        return response

    def stream(
        self,
        model: str,
        messages: List[Dict[str, Any]],
        max_tokens: int,
        **kwargs
    ):
        """Stream with security checks on input"""
        # Validate inputs before streaming
        if self._config.validate_input:
            for i, msg in enumerate(messages):
                if msg.get('role') == 'user':
                    content = msg.get('content', '')
                    if isinstance(content, str):
                        check = self._validate_input(content)
                        if not check['safe']:
                            self._handle_threat(check, messages, i)

        # Return the stream
        # Note: Output PII checking on streams requires buffering
        return self._messages.stream(
            model=model,
            messages=messages,
            max_tokens=max_tokens,
            **kwargs
        )

    def _handle_threat(self, check: Dict, messages: List, index: int):
        """Handle detected threat based on config"""
        if self._config.on_threat == 'block':
            raise SafeKeyLabBlockedError(
                f"Input blocked: {check['threat_type']}",
                details=check
            )
        elif self._config.on_threat == 'sanitize':
            content = messages[index].get('content', '')
            if isinstance(content, str):
                messages[index]['content'] = check.get('sanitized', content)

    def _validate_input(self, content: str) -> Dict[str, Any]:
        """Validate input for threats"""
        for pattern in self._injection_patterns:
            if re.search(pattern, content, re.IGNORECASE):
                return {
                    'safe': False,
                    'threat_type': 'prompt_injection',
                    'pattern': pattern,
                    'sanitized': self._sanitize_input(content)
                }

        return {'safe': True}

    def _sanitize_input(self, content: str) -> str:
        """Sanitize malicious input"""
        sanitized = content
        for pattern in self._injection_patterns:
            sanitized = re.sub(pattern, '[BLOCKED]', sanitized, flags=re.IGNORECASE)
        return sanitized

    def _detect_pii(self, content: str) -> Dict[str, Any]:
        """Detect PII in content"""
        found_types = []
        redacted = content

        for pii_type, pattern in self._pii_patterns.items():
            if pii_type in self._config.allowed_pii_types:
                continue

            matches = re.findall(pattern, content, re.IGNORECASE)
            if matches:
                found_types.append(pii_type)
                redacted = re.sub(pattern, f'[{pii_type}_REDACTED]', redacted, flags=re.IGNORECASE)

        return {
            'found': len(found_types) > 0,
            'types': found_types,
            'redacted': redacted
        }


class SecureAnthropic:
    """Drop-in replacement for Anthropic client with SafeKeyLab protection"""

    def __init__(
        self,
        anthropic_client: Any,
        config: AnthropicWrapperConfig = None
    ):
        self._client = anthropic_client
        self._config = config or AnthropicWrapperConfig()

        # Wrap messages
        self.messages = SecureMessages(
            self._client.messages,
            self._config
        )

        # Pass through other attributes
        self.completions = getattr(self._client, 'completions', None)

    def __getattr__(self, name):
        """Pass through any other attributes to the underlying client"""
        return getattr(self._client, name)


def wrap_anthropic(
    anthropic_client: Any,
    **config_kwargs
) -> SecureAnthropic:
    """
    Wrap an Anthropic client with SafeKeyLab protection.

    Usage:
        import anthropic
        from safekeylab import wrap_anthropic

        client = anthropic.Anthropic()
        secure_client = wrap_anthropic(client)

        # Now all calls are protected
        response = secure_client.messages.create(
            model="claude-3-opus-20240229",
            max_tokens=1024,
            messages=[{"role": "user", "content": user_input}]
        )

    Args:
        anthropic_client: The Anthropic client instance
        **config_kwargs: Configuration options
            - validate_input: bool (default True) - Validate inputs for threats
            - on_threat: str (default 'block') - 'block', 'sanitize', or 'log'
            - check_output: bool (default True) - Check outputs for PII
            - redact_output_pii: bool (default True) - Redact PII from outputs

    Returns:
        SecureAnthropic instance
    """
    config = AnthropicWrapperConfig(**config_kwargs)
    return SecureAnthropic(anthropic_client, config)
