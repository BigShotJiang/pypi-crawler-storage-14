from typing import Any, Literal
from uuid import UUID, uuid4

from pydantic import Field

from .enums import CommandType, OrderType, Side, StrategyType
from .models import CustomBaseModel


class CommandBase(CustomBaseModel):
    id: UUID = Field(default_factory=uuid4)
    version: int = 1
    details: dict[str, Any] | None = None


class NewOrderCommandBase(CommandBase):
    type: Literal[CommandType.NEW_ORDER] = CommandType.NEW_ORDER
    strategy_type: StrategyType
    instrument_id: UUID


class SingleOrderMeta(CustomBaseModel):
    order_id: UUID
    user_id: UUID
    order_type: OrderType
    side: Side
    quantity: int
    limit_price: float | None = Field(None, gt=0.0)
    stop_price: float | None = Field(None, gt=0.0)

    def model_post_init(self, context):
        if self.limit_price is None and self.order_type == OrderType.LIMIT:
            raise ValueError("Limit price must be specified")
        if self.stop_price is None and self.order_type == OrderType.STOP:
            raise ValueError("Stop price must be specified")
        return self


class NewSingleOrderCommand(NewOrderCommandBase, SingleOrderMeta):
    pass


class NewOCOOrderCommand(NewOrderCommandBase):
    legs: list[SingleOrderMeta] = Field(max_length=2)


class NewOTOOrderCommand(NewOrderCommandBase):
    parent: dict
    child: dict


class NewOTOCOOrderCommand(NewOrderCommandBase):
    parent: dict
    oco_legs: list[SingleOrderMeta] = Field(min_length=2, max_length=2)


class CancelOrderCommand(CommandBase):
    type: Literal[CommandType.CANCEL_ORDER] = CommandType.CANCEL_ORDER
    order_id: UUID
    instrument_id: UUID


class ModifyOrderCommand(CommandBase):
    type: Literal[CommandType.MODIFY_ORDER] = CommandType.MODIFY_ORDER
    order_id: str
    symbol: str
    limit_price: float | None = Field(None, gt=0.0)
    stop_price: float | None = Field(None, gt=0.0)


class NewInstrumentCommand(CommandBase):
    type: Literal[CommandType.NEW_INSTRUMENT] = CommandType.NEW_INSTRUMENT
    instrument_id: UUID
