"""
Apple Search Ads Python Client

A Python client library for Apple Search Ads API v5.
"""

from .client import AppleSearchAdsClient

__version__ = "0.1.0"
__author__ = "Your Name"
__email__ = "your.email@example.com"

__all__ = ["AppleSearchAdsClient"]
