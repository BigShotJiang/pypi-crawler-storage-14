"""Test cases based on gNMI Subscribe ONCE requests."""

import time

from oc_config_validate import schema, testbase


class SubsOnceTestCase(testbase.TestCase):
    """Subscribes ONCE and checks the response elements.

    The arguments are optional, only checked when defined.

    Args:
        xpaths: List of gNMI paths to subscribe to.
        notifications_count: Number of expected Notifications.
        max_delay_secs: Maximum delay of the replies, measured with the
          timestamp value(s).
    """
    notifications_count = None
    max_delay_secs = None
    xpaths = None

    def subscribeOnce(self):
        """"""
        for xpath in self.xpaths:
            self.assertXpath(xpath)
        self.now = int(time.time())
        self.responses = self.gNMISubsOnce(self.xpaths)
        self.assertTrue(bool(self.responses),
                        "No gNMI Subscribe response")

        for n in self.responses:
            for u in n.update:
                got_path = schema.pathToString(u.path)
                self.assertTrue(
                    schema.isPathInRequestedPaths(got_path, self.xpaths),
                    f"Unexpected update path {got_path} for subscription to {self.xpaths}")

        if self.max_delay_secs:
            for n in self.responses:
                timestamp_diff = (n.timestamp // 1000000000) - self.now
                self.assertTrue(
                    (self.max_delay_secs * -
                     1) < timestamp_diff < self.max_delay_secs,
                    f"Timestamp diff too long: {timestamp_diff} secs")

        if self.notifications_count:
            notifications = len(self.responses)
            self.assertEqual(
                notifications, self.notifications_count,
                f"Expected {self.notifications_count} notifications, "
                f"got {notifications}")


class CountUpdatesCheckType(SubsOnceTestCase):
    """Subscribes ONCE and checks the returned updates and their value types.

    Args:
        xpaths: List of gNMI paths to subscribe to. Can contain wildcards.
        updates_count: Number of expected Update messages.
        values_type: Python type of the values of the Updates.

    """
    values_type = None
    updates_count = None

    def testSubscribeOnce(self):
        """"""
        self.assertArgs(["xpaths", "values_type", "updates_count"])

        self.subscribeOnce()

        updates = 0
        for n in self.responses:
            updates += len(n.update)
            for u in n.update:
                self.assertTrue(
                    u.val.HasField(self.values_type),
                    f"Value of Update {schema.pathToString(u.path)} "
                    f"is not of type {self.values_type}: {u.val}")

        self.assertEqual(
            updates, self.updates_count,
            f"Expected {self.updates_count} Updates, got: {updates}")


class CountUpdatePaths(SubsOnceTestCase):
    """Subscribes ONCE and checks the returned update paths.

    This tests that a Subscription reports all Update paths.

    Args:
        xpaths: List of gNMI paths to subscribe to. Can contain wildcards.
        update_paths_count: Number of expected disctinct Update paths.
    """
    update_paths_count = None

    def testSubscribeOnce(self):
        """"""
        self.assertArgs(["xpaths", "update_paths_count"])
        self.subscribeOnce()

        self.update_paths = set()

        for n in self.responses:
            for u in n.update:
                self.update_paths.add(schema.pathToString(u.path))

        self.assertEqual(
            len(self.update_paths), self.update_paths_count,
            f"Expected {self.update_paths_count} Update paths, "
            f"got: {self.update_paths}")


class CheckLeafsFromModel(SubsOnceTestCase):
    """Subscribes ONCE and checks the updates againts the OC model.

    All arguments are read from the Test YAML description.

    Args:
        xpaths: List of gNMI paths to subscribe to. The paths can contain
          wildcards only in the keys.
        model: Python binding class to check the JSON reply against.
        check_missing_model_paths: If True, missing OC Model leaf paths in the
                                   Updates replies are checked.
    """
    model = None
    check_missing_model_paths = False

    def testSubscribeOnce(self):
        """"""
        self.assertArgs(["xpaths", "model"])

        want_paths = []
        for xpath in self.xpaths:
            self.assertModelXpath(self.model, xpath)
            want_paths.extend(schema.ocLeafsPaths(self.model, xpath))

        self.subscribeOnce()

        got_updates = []
        for n in self.responses:
            got_updates.extend(n.update)

        got_paths = set()
        for u in got_updates:
            got_path = schema.pathToString(u.path)
            got_paths.add(got_path)
            self.assertTrue(
                schema.isPathInRequestedPaths(got_path, want_paths),
                f"Update path {got_path} NOT in OC Model {self.model}")

        if self.check_missing_model_paths:
            for want_path in want_paths:
                self.assertIn(
                    want_path, list(got_paths),
                    f"Missing update path for OC model {self.model}")


class CheckLeafsFromList(SubsOnceTestCase):
    """Subscribes ONCE and checks the updates againts a list of expected paths.

    All arguments are read from the Test YAML description.

    Args:
        xpaths: List of gNMI paths to subscribe to.
        update_paths: List of gNMI paths that the Subscription response must have.
    """
    update_paths = None

    def testSubscribeOnce(self):
        """"""
        self.assertArgs(["xpaths", "update_paths"])

        self.subscribeOnce()

        got_updates = []
        for n in self.responses:
            got_updates.extend(n.update)

        got_paths = set()
        for u in got_updates:
            got_path = schema.pathToString(u.path)
            got_paths.add(got_path)

        for want_path in self.update_paths:
            self.assertIn(
                want_path, list(got_paths),
                "Missing update path")
