#!/usr/bin/env python
"""
Test REM queries from rem-exp-01.md against the cluster database.

Run with:
    POSTGRES__CONNECTION_STRING="postgresql://rem:rem@localhost:5433/rem" uv run python test_rem_queries.py
"""

import asyncio
import os
from pprint import pprint

# Set connection string before importing rem modules
os.environ["POSTGRES__CONNECTION_STRING"] = "postgresql://remuser:wOUr49zYvkELlYMUUk2IQ3O78ysAdqN@localhost:5433/remdb?sslmode=disable"

from rem.services.postgres import PostgresService
from rem.services.rem.query import REMQueryService


async def run_tests():
    """Run REM query tests."""
    print("=" * 60)
    print("REM Query Tests from rem-exp-01.md")
    print("=" * 60)

    # Connect to database
    pg = PostgresService()
    await pg.connect()
    rem = REMQueryService(pg)

    try:
        # =================================================================
        # FIX DATA ISSUES
        # =================================================================
        print("\n" + "=" * 60)
        print("Fixing data issues...")
        print("=" * 60)

        # 1. Fix graph_edges: replace UUIDs with names
        uuid_to_name = {
            'bb55c781-f880-594a-82e5-5191f0b64be8': 'Sarah Chen',
            '3c4bfc2a-33b2-566f-85f1-62be50fe58d6': 'Mike Johnson',
            '679e6ccd-08ff-5cee-b0fc-7e9135fb8595': 'Alex Kim',
            '4f056f0b-0043-5441-b23b-cb250641c232': 'Q4 2024 Team Retrospective',
            'ce0d7bd1-bcd5-57da-9fbe-c7d5f5b36020': 'API Design Document v1',
        }

        for uuid_val, name in uuid_to_name.items():
            update_sql = f"""
                UPDATE resources
                SET graph_edges = (
                    SELECT jsonb_agg(
                        CASE
                            WHEN edge->>'dst' = '{uuid_val}'
                            THEN jsonb_set(edge, '{{dst}}', '"{name}"')
                            ELSE edge
                        END
                    )
                    FROM jsonb_array_elements(graph_edges) AS edge
                )
                WHERE graph_edges::text LIKE '%{uuid_val}%'
            """
            await pg.execute(update_sql)

        print("  - Fixed UUID references in graph_edges")

        # 2. Fix user_id scoping: set to NULL for sample data (make public)
        # Resources with graph_edges should be public for TRAVERSE to work
        await pg.execute("""
            UPDATE resources
            SET user_id = NULL
            WHERE name IN (
                'API Design Document v2',
                'Q4 2024 Retrospective Notes',
                'Frontend Component Refactor',
                'Meeting Notes',
                'Project Plan'
            )
        """)
        print("  - Set user_id=NULL for sample resources (public data)")

        # Also update users to have NULL user_id for consistency
        await pg.execute("""
            UPDATE users
            SET user_id = NULL
            WHERE name IN ('Sarah Chen', 'Mike Johnson', 'Alex Kim')
        """)
        print("  - Set user_id=NULL for sample users (public data)")

        # =================================================================
        # REBUILD KV_STORE (UNLOGGED table cleared on pod restart)
        # =================================================================
        print("\n" + "=" * 60)
        print("Rebuilding KV_STORE cache...")
        print("=" * 60)

        result = await rem.execute("SELECT * FROM rebuild_kv_store()")
        print(f"Rebuilt {result.count} tables:")
        for r in result.results:
            print(f"  - {r['table_name']}: {r['rows_inserted']} rows")

        # Verify kv_store is now populated
        result = await rem.execute("SELECT COUNT(*) as count FROM kv_store")
        print(f"\nTotal entries in kv_store: {result.results[0]['count']}")

        # =================================================================
        # BATCH 1: LOOKUP Queries
        # =================================================================
        print("\n" + "=" * 60)
        print("BATCH 1: LOOKUP Queries")
        print("=" * 60)

        # 1.1 Lookup a specific SSRI medication
        print("\n--- 1.1 LOOKUP 'Sertraline' ---")
        result = await rem.execute('LOOKUP "Sertraline"')
        print(f"Count: {result.count}")
        for r in result.results[:3]:
            print(f"  - {r.get('entity_key', r.get('name', 'N/A'))}: {r.get('entity_type', 'N/A')}")

        # 1.2 Lookup a care stage
        print("\n--- 1.2 LOOKUP 'Active Treatment' ---")
        result = await rem.execute('LOOKUP "Active Treatment"')
        print(f"Count: {result.count}")
        for r in result.results[:3]:
            print(f"  - {r.get('entity_key', r.get('name', 'N/A'))}: {r.get('entity_type', 'N/A')}")

        # 1.3 Lookup a care role
        print("\n--- 1.3 LOOKUP 'Psychiatrist' ---")
        result = await rem.execute('LOOKUP "Psychiatrist"')
        print(f"Count: {result.count}")
        for r in result.results[:3]:
            print(f"  - {r.get('entity_key', r.get('name', 'N/A'))}: {r.get('entity_type', 'N/A')}")

        # 1.5 Lookup a user (with user_id scope)
        print("\n--- 1.5 LOOKUP 'Sarah Chen' (user_id=default) ---")
        result = await rem.execute('LOOKUP "Sarah Chen"', user_id='default')
        print(f"Count: {result.count}")
        for r in result.results[:3]:
            print(f"  - {r.get('entity_key', r.get('name', 'N/A'))}: {r.get('entity_type', 'N/A')}")
            email = r.get('email', 'N/A')
            print(f"    Email: {email}")

        # =================================================================
        # BATCH 2: SEARCH Queries (Semantic Vector Search)
        # =================================================================
        print("\n" + "=" * 60)
        print("BATCH 2: SEARCH Queries (Semantic Vector Search)")
        print("=" * 60)

        # 2.1 Search for anxiety treatment options
        print("\n--- 2.1 SEARCH 'anxiety treatment medications' ---")
        result = await rem.execute('SEARCH "anxiety treatment medications" FROM resources LIMIT 10')
        print(f"Count: {result.count}")
        for r in result.results[:5]:
            sim = r.get('similarity', 'N/A')
            name = r.get('name', r.get('entity_key', 'N/A'))
            print(f"  - {name} (similarity: {sim:.3f})" if isinstance(sim, float) else f"  - {name}")

        # 2.2 Search for depression medication
        print("\n--- 2.2 SEARCH 'selective serotonin medications for depression' ---")
        result = await rem.execute('SEARCH "selective serotonin medications for depression" FROM resources LIMIT 10')
        print(f"Count: {result.count}")
        for r in result.results[:5]:
            sim = r.get('similarity', 'N/A')
            name = r.get('name', r.get('entity_key', 'N/A'))
            print(f"  - {name} (similarity: {sim:.3f})" if isinstance(sim, float) else f"  - {name}")

        # 2.6 Search for care coordination roles
        print("\n--- 2.6 SEARCH 'patient care coordination case management' ---")
        result = await rem.execute('SEARCH "patient care coordination case management" FROM resources LIMIT 10')
        print(f"Count: {result.count}")
        for r in result.results[:5]:
            sim = r.get('similarity', 'N/A')
            name = r.get('name', r.get('entity_key', 'N/A'))
            print(f"  - {name} (similarity: {sim:.3f})" if isinstance(sim, float) else f"  - {name}")

        # =================================================================
        # BATCH 3: SQL Queries
        # =================================================================
        print("\n" + "=" * 60)
        print("BATCH 3: SQL Queries")
        print("=" * 60)

        # 3.1 List all drugs with boxed warnings sorted by adverse reports
        print("\n--- 3.1 Drugs with boxed warnings sorted by adverse reports ---")
        result = await rem.execute("""
            SELECT name,
                   metadata->>'drug_class' as drug_class,
                   metadata->>'total_adverse_reports' as adverse_reports
            FROM resources
            WHERE (metadata->>'has_boxed_warning')::boolean = true
            ORDER BY (metadata->>'total_adverse_reports')::int DESC NULLS LAST
            LIMIT 10
        """)
        print(f"Count: {result.count}")
        for r in result.results[:5]:
            print(f"  - {r['name']}: {r.get('drug_class', 'N/A')} ({r.get('adverse_reports', 'N/A')} reports)")

        # 3.3 Count resources by drug class
        print("\n--- 3.3 Count resources by drug class ---")
        result = await rem.execute("""
            SELECT metadata->>'drug_class' as drug_class, COUNT(*) as count
            FROM resources
            WHERE metadata->>'drug_class' IS NOT NULL
            GROUP BY metadata->>'drug_class'
            ORDER BY count DESC
            LIMIT 10
        """)
        print(f"Count: {result.count}")
        for r in result.results[:5]:
            print(f"  - {r['drug_class']}: {r['count']}")

        # 3.4 SSRI medications ranked by adverse event counts
        print("\n--- 3.4 SSRI medications ranked by adverse event counts ---")
        result = await rem.execute("""
            SELECT name,
                   metadata->>'rxcui' as rxcui,
                   metadata->>'total_adverse_reports' as total_reports,
                   metadata->'top_adverse_events'->0->>'term' as top_adverse_event
            FROM resources
            WHERE category = 'drug.psychotropic.ssri'
            ORDER BY (metadata->>'total_adverse_reports')::int DESC NULLS LAST
        """)
        print(f"Count: {result.count}")
        for r in result.results:
            print(f"  - {r['name']}: {r.get('total_reports', 'N/A')} reports (top: {r.get('top_adverse_event', 'N/A')})")

        # 3.6 List all care stages
        print("\n--- 3.6 List all care stages ---")
        result = await rem.execute("""
            SELECT name, substring(content, 1, 100) as content_preview
            FROM resources
            WHERE category = 'care.stage'
            ORDER BY name
        """)
        print(f"Count: {result.count}")
        for r in result.results:
            print(f"  - {r['name']}")

        # =================================================================
        # BATCH 4: FUZZY Queries
        # =================================================================
        print("\n" + "=" * 60)
        print("BATCH 4: FUZZY Queries")
        print("=" * 60)

        # Fuzzy lookup with typo
        print("\n--- FUZZY 'Sertralene' (typo) ---")
        result = await rem.execute('FUZZY "Sertralene" THRESHOLD 0.3')
        print(f"Count: {result.count}")
        for r in result.results[:5]:
            sim = r.get('similarity', 'N/A')
            key = r.get('entity_key', 'N/A')
            print(f"  - {key} (similarity: {sim:.3f})" if isinstance(sim, float) else f"  - {key}")

        # Fuzzy lookup partial match
        print("\n--- FUZZY 'Quetiap' (partial) ---")
        result = await rem.execute('FUZZY "Quetiap" THRESHOLD 0.3')
        print(f"Count: {result.count}")
        for r in result.results[:5]:
            sim = r.get('similarity', 'N/A')
            key = r.get('entity_key', 'N/A')
            print(f"  - {key} (similarity: {sim:.3f})" if isinstance(sim, float) else f"  - {key}")

        # =================================================================
        # BATCH 5: TRAVERSE Queries
        # =================================================================
        print("\n" + "=" * 60)
        print("BATCH 5: TRAVERSE Queries")
        print("=" * 60)

        # First find resources with graph edges
        print("\n--- Finding resources with graph edges ---")
        result = await rem.execute("""
            SELECT name, jsonb_array_length(graph_edges) as edge_count
            FROM resources
            WHERE jsonb_array_length(graph_edges) > 0
            LIMIT 10
        """)
        print(f"Count: {result.count}")
        for r in result.results:
            print(f"  - {r['name']}: {r['edge_count']} edges")

        # List all relationship types
        print("\n--- Relationship types in the graph ---")
        result = await rem.execute("""
            SELECT DISTINCT edge->>'rel_type' as relationship
            FROM resources r,
                 jsonb_array_elements(r.graph_edges) as edge
            WHERE jsonb_array_length(r.graph_edges) > 0
        """)
        print(f"Count: {result.count}")
        for r in result.results:
            print(f"  - {r['relationship']}")

        # Traverse from a document with edges (no user_id = public data)
        print("\n--- TRAVERSE from 'API Design Document v2' (public data) ---")
        result = await rem.execute('TRAVERSE "API Design Document v2" OUTBOUND DEPTH 1')
        print(f"Count: {result.count}")
        for r in result.results[:5]:
            depth = r.get('depth', 0)
            name = r.get('name', r.get('entity_key', 'N/A'))
            rel = r.get('rel_type', r.get('edge_type', 'root'))
            print(f"  [{depth}] {name} (via {rel})")

        # Debug: Check kv_store for API Design Document with user_id
        print("\n--- DEBUG: kv_store lookup for 'API Design Document v2' (with user_id) ---")
        result = await rem.execute("SELECT entity_key, entity_type, entity_id, user_id, tenant_id FROM kv_store WHERE entity_key LIKE '%API Design%' LIMIT 5")
        print(f"Count: {result.count}")
        for r in result.results:
            print(f"  - {r['entity_key']}: {r['entity_type']} (user_id={r.get('user_id')}, tenant_id={r.get('tenant_id')})")

        # Debug: Manually test rem_traverse SQL with NULL user_id (public data)
        print("\n--- DEBUG: Direct rem_traverse call (user_id=NULL for public) ---")
        result = await rem.execute("""
            SELECT depth, entity_key, entity_type, rel_type
            FROM rem_traverse('API Design Document v2', NULL, NULL, 1, NULL, FALSE)
        """)
        print(f"Count: {result.count}")
        for r in result.results[:5]:
            print(f"  [{r.get('depth')}] {r.get('entity_key')}: {r.get('entity_type')} (via {r.get('rel_type')})")

        # Debug: Check users in kv_store
        print("\n--- DEBUG: Users in kv_store (with user_id) ---")
        result = await rem.execute("SELECT entity_key, entity_type, user_id, tenant_id FROM kv_store WHERE entity_type = 'users' LIMIT 10")
        print(f"Count: {result.count}")
        for r in result.results:
            print(f"  - {r['entity_key']} (user_id={r.get('user_id')}, tenant_id={r.get('tenant_id')})")

        # Debug: Check graph_edges format
        print("\n--- DEBUG: graph_edges format in API Design Document v2 ---")
        result = await rem.execute("SELECT name, graph_edges FROM resources WHERE name = 'API Design Document v2' LIMIT 1")
        if result.results:
            import json
            edges = result.results[0].get('graph_edges', [])
            print(f"  Edges: {json.dumps(edges, indent=2)}")

        # Debug: Check kv_store.graph_edges
        print("\n--- DEBUG: kv_store.graph_edges for API Design Document v2 ---")
        result = await rem.execute("SELECT entity_key, graph_edges FROM kv_store WHERE entity_key = 'API Design Document v2' LIMIT 1")
        if result.results:
            import json
            edges = result.results[0].get('graph_edges', [])
            print(f"  Edges: {json.dumps(edges, indent=2)}")

        # =================================================================
        # DEBUG: Check kv_store population
        # =================================================================
        print("\n" + "=" * 60)
        print("DEBUG: KV Store Status")
        print("=" * 60)

        result = await rem.execute("SELECT COUNT(*) as count FROM kv_store")
        print(f"Total entries in kv_store: {result.results[0]['count']}")

        result = await rem.execute("SELECT entity_key, entity_type FROM kv_store LIMIT 10")
        print(f"Sample entries:")
        for r in result.results:
            print(f"  - {r['entity_key']}: {r['entity_type']}")

        # Check if Sertraline exists in resources
        print("\n--- Does 'Sertraline' exist in resources? ---")
        result = await rem.execute("SELECT name, category FROM resources WHERE name = 'Sertraline' LIMIT 5")
        print(f"Count: {result.count}")
        for r in result.results:
            print(f"  - {r['name']}: {r['category']}")

        print("\n" + "=" * 60)
        print("Tests Complete!")
        print("=" * 60)

    finally:
        await pg.disconnect()


if __name__ == "__main__":
    asyncio.run(run_tests())
