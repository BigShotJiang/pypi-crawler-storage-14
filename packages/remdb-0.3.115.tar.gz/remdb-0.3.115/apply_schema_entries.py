#!/usr/bin/env python
"""
Apply schema table entries from generated SQL to the cluster.
"""

import asyncio
import os
import re

os.environ["POSTGRES__CONNECTION_STRING"] = "postgresql://remuser:wOUr49zYvkELlYMUUk2IQ3O78ysAdqN@localhost:5433/remdb?sslmode=disable"

from rem.services.postgres import PostgresService


async def main():
    # Read the generated SQL file
    sql_file = "src/rem/sql/migrations/002_install_models.sql"
    with open(sql_file) as f:
        content = f.read()

    # Extract schema entries section
    match = re.search(r'-- SCHEMA TABLE ENTRIES.*?-- RECORD MIGRATION', content, re.DOTALL)
    if not match:
        print("Could not find SCHEMA TABLE ENTRIES section")
        return

    schema_section = match.group(0)

    # Extract individual INSERT statements
    insert_pattern = r'(INSERT INTO schemas.*?ON CONFLICT \(id\) DO UPDATE SET.*?updated_at = CURRENT_TIMESTAMP;)'
    inserts = re.findall(insert_pattern, schema_section, re.DOTALL)

    print(f"Found {len(inserts)} schema entries to apply")

    # Connect and apply
    pg = PostgresService()
    await pg.connect()

    try:
        for i, insert_sql in enumerate(inserts):
            # Extract name for logging
            name_match = re.search(r"'([^']+)',\s*--.*?or just the name", insert_sql)
            if not name_match:
                name_match = re.search(r"'system',\s*'([^']+)'", insert_sql)
            name = name_match.group(1) if name_match else f"entry {i+1}"

            try:
                await pg.execute(insert_sql)
                print(f"  ✓ Applied schema: {name}")
            except Exception as e:
                print(f"  ✗ Failed {name}: {e}")

        print(f"\n✓ Applied {len(inserts)} schema entries")

        # Verify
        result = await pg.execute("SELECT name, category FROM schemas WHERE category = 'entity' ORDER BY name")
        print(f"\nEntity schemas in database:")
        for row in result:
            print(f"  - {row['name']}")

    finally:
        await pg.disconnect()


if __name__ == "__main__":
    asyncio.run(main())
