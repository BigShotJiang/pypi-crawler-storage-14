[build-system]
requires = ["setuptools>=45", "wheel", "setuptools_scm[toml]>=6.2"]
build-backend = "setuptools.build_meta"

[project]
name = "DEFAULT"
dynamic = ["version"]
description = "Add a short description here"
readme = "README.md"
authors = [
    {name = "Your Name", email = "your.email@example.com"}
]
classifiers = [
    "Development Status :: 3 - Alpha",
    "Intended Audience :: Developers",
    "License :: OSI Approved :: MIT License",
    "Operating System :: OS Independent",
    "Programming Language :: Python :: 3",
    "Programming Language :: Python :: 3.8",
    "Programming Language :: Python :: 3.9",
    "Programming Language :: Python :: 3.10",
    "Programming Language :: Python :: 3.11",
    "Programming Language :: Python :: 3.12",
]
dependencies = [
    # Add your project dependencies here, e.g.:
    # "requests>=2.25.0",
    # "click>=8.0.0",
]

[project.optional-dependencies]
dev = [
    "pytest>=6.0",
    "pytest-cov",
    "black",
    "flake8",
    "mypy",
]
docs = [
    "sphinx",
    "sphinx-rtd-theme",
]

[project.urls]
Homepage = "https://github.com/yourusername/DEFAULT"
Repository = "https://github.com/yourusername/DEFAULT"
"Bug Tracker" = "https://github.com/yourusername/DEFAULT/issues"

[project.scripts]
# Add command-line scripts here, e.g.:
# mycommand = "DEFAULT.cli:main"

[tool.setuptools_scm]

[tool.setuptools.packages.find]
where = ["src"]  # if using src layout, otherwise omit this line