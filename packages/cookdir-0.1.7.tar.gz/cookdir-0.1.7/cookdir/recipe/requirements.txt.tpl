# Add your project dependencies here
# Example:
# requests>=2.25.0
# click>=8.0.0
# numpy>=1.20.0
# pandas>=1.3.0