"""
Subpackage for Discrimination
"""
