from datetime import datetime

__version__ = "4.4.2"
__current_year__ = datetime.now().year
