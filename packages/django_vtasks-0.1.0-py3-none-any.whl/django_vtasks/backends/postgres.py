import logging
from datetime import timedelta
from typing import Any

from asgiref.sync import sync_to_async
from django.db import DatabaseError, transaction
from django.tasks.base import Task, TaskResult, TaskResultStatus
from django.utils import timezone

from ..postgres.models import QueuedTask, TaskStatus, VTaskMetadata
from ..serialization import deserialize, serialize
from .base import VTasksBaseBackend

logger = logging.getLogger(__name__)


class PostgresTaskBackend(VTasksBaseBackend):
    def __init__(self, alias: str, params: dict[str, Any] | None) -> None:
        super().__init__(alias, params)

    async def aenqueue(self, task: "Task", args: tuple, kwargs: dict) -> "TaskResult":
        queue_name: str = getattr(task, "queue_name", "default")

        data = {
            "func": task.func.__module__ + "." + task.func.__name__,
            "args": args,
            "kwargs": kwargs,
            "queue": queue_name,
        }
        payload = serialize(data)

        queued_task = await QueuedTask.objects.acreate(
            queue=queue_name,
            data=payload,
            status=TaskStatus.QUEUED,
        )

        return TaskResult(
            task=task,
            id=str(queued_task.id),
            status=TaskResultStatus.READY,
            enqueued_at=None,
            started_at=None,
            last_attempted_at=None,
            finished_at=None,
            args=args,
            kwargs=kwargs,
            backend=self.alias,
            errors=[],
            worker_ids=[],
        )

    async def get_queue_depth(self, queue: str) -> int:
        return await QueuedTask.objects.filter(
            queue=queue, status=TaskStatus.QUEUED
        ).acount()

    def _fetch_task_sync(self, queues: list[str]) -> dict | None:
        logger.debug("Fetching task from queues %s", queues)
        with transaction.atomic():
            queued_task = (
                QueuedTask.objects.select_for_update(skip_locked=True)
                .filter(queue__in=queues, status=TaskStatus.QUEUED)
                .order_by("created_at")
                .first()
            )
            if queued_task:
                queued_task.status = TaskStatus.PROCESSING
                queued_task.worker_id = self.worker_id
                queued_task.save(update_fields=["status", "worker_id"])

                unpacked = deserialize(queued_task.data)
                unpacked["_raw"] = queued_task.data
                unpacked["id"] = str(queued_task.id)
                unpacked["queue"] = queued_task.queue
                return unpacked
        return None

    async def _fetch_task(self, queues: list[str]) -> dict | None:
        return await sync_to_async(self._fetch_task_sync)(queues)

    def _ack_task_sync(self, task_id: str):
        QueuedTask.objects.filter(id=task_id).delete()

    async def _ack_task(self, task_data: dict) -> None:
        await sync_to_async(self._ack_task_sync)(task_data["id"])

    @sync_to_async
    def _ack_batch_sync(self, tasks: list[dict]):
        task_ids = [task["id"] for task in tasks]
        QueuedTask.objects.filter(id__in=task_ids).delete()

    async def _ack_batch(self, tasks: list[dict]):
        await self._ack_batch_sync(tasks)

    def _fail_task_sync(self, task_id: str):
        with transaction.atomic():
            QueuedTask.objects.filter(id=task_id).update(status=TaskStatus.FAILED)

            failed_count = QueuedTask.objects.filter(status=TaskStatus.FAILED).count()
            if failed_count > self.dlq_cap:
                ids_to_delete = (
                    QueuedTask.objects.filter(status=TaskStatus.FAILED)
                    .order_by("created_at")
                    .values_list("id", flat=True)[: failed_count - self.dlq_cap]
                )
                QueuedTask.objects.filter(id__in=list(ids_to_delete)).delete()

    async def _fail_task(self, task_data: dict, exception: Exception) -> None:
        task_id = task_data.get("id", "unknown")
        logger.error("Task %s failed", task_id, exc_info=True)
        await sync_to_async(self._fail_task_sync)(task_data["id"])

    def _rescue_tasks_sync(self):
        stuck_tasks = QueuedTask.objects.filter(
            status=TaskStatus.PROCESSING, worker_id=self.worker_id
        ).update(status=TaskStatus.QUEUED, worker_id=None)
        if stuck_tasks:
            logger.warning(
                "Rescued %d tasks previously processed by %s",
                stuck_tasks,
                self.worker_id,
            )

    async def _rescue_tasks(self) -> None:
        await sync_to_async(self._rescue_tasks_sync)()

    def enqueue(
        self, task: "Task", args: tuple, kwargs: dict, **options
    ) -> "TaskResult":
        queue_name = options.get("queue_name") or kwargs.pop(
            "queue_name", getattr(task, "queue_name", "default")
        )

        payload = serialize(
            {
                "func": task.name,
                "args": args,
                "kwargs": kwargs,
            }
        )

        queued_task = QueuedTask.objects.create(queue=queue_name, data=payload)

        return TaskResult(
            task=task,
            id=str(queued_task.id),
            status=TaskResultStatus.READY,
            enqueued_at=queued_task.created_at,
            started_at=None,
            last_attempted_at=None,
            finished_at=None,
            args=args,
            kwargs=kwargs,
            backend=self.alias,
            errors=[],
            worker_ids=[],
        )

    @sync_to_async
    @transaction.atomic
    def acquire_lock(self, key: str, ttl: int) -> bool:
        now = timezone.now()
        try:
            lock = VTaskMetadata.objects.select_for_update(nowait=True).get(key=key)
            if lock.expires_at < now or lock.value == self.worker_id:
                lock.expires_at = now + timedelta(seconds=ttl)
                lock.value = self.worker_id
                lock.save()
                return True
            return False
        except VTaskMetadata.DoesNotExist:
            VTaskMetadata.objects.create(
                key=key, value=self.worker_id, expires_at=now + timedelta(seconds=ttl)
            )
            return True
        except DatabaseError:
            return False

    @sync_to_async
    def get_metadata(self, key: str) -> Any:
        try:
            metadata = VTaskMetadata.objects.get(key=key)
            return metadata.value
        except VTaskMetadata.DoesNotExist:
            return None

    @sync_to_async
    def set_metadata(self, key: str, value: Any) -> None:
        VTaskMetadata.objects.update_or_create(key=key, defaults={"value": str(value)})

    @sync_to_async
    @transaction.atomic
    def fetch_batch_sync(self, queue: str, count: int, timeout: float) -> list[dict]:
        logger.debug("Fetching batch of %d tasks from queue %s", count, queue)
        tasks_to_process = list(
            QueuedTask.objects.select_for_update(skip_locked=True)
            .filter(queue=queue, status=TaskStatus.QUEUED)
            .order_by("created_at")[:count]
        )
        if not tasks_to_process:
            return []

        task_ids = [task.id for task in tasks_to_process]
        QueuedTask.objects.filter(id__in=task_ids).update(
            status=TaskStatus.PROCESSING, worker_id=self.worker_id
        )

        tasks = []
        for task in tasks_to_process:
            task_data = deserialize(task.data)
            task_data["_raw"] = task.data
            task_data["id"] = str(task.id)
            task_data["queue"] = task.queue
            tasks.append(task_data)
        return tasks

    async def fetch_batch(self, queue: str, count: int, timeout: float) -> list[dict]:
        # The timeout is not used in the Postgres backend, as it does not block.
        return await self.fetch_batch_sync(queue, count, timeout)
