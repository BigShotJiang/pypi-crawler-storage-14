import socket
import uuid
from typing import Any

from django.tasks.backends.base import BaseTaskBackend

from .. import conf


class VTasksBaseBackend(BaseTaskBackend):
    supports_async_task = True

    def __init__(self, alias: str, params: dict[str, Any] | None) -> None:
        super().__init__(alias, params)
        self.options = params or {}
        self.worker_id = f"{socket.gethostname()}-{uuid.uuid4().hex[:6]}"
        self.compress_threshold = self.options.get(
            "COMPRESS_THRESHOLD", conf.VTASKS_COMPRESS_THRESHOLD
        )
        self.dlq_cap = self.options.get("DLQ_CAP", conf.VTASKS_DLQ_CAP)

    async def _fetch_task(self, queues: list[str]) -> dict | None:
        raise NotImplementedError

    async def _ack_task(self, task_data: dict) -> None:
        raise NotImplementedError

    async def _fail_task(self, task_data: dict, exception: Exception) -> None:
        raise NotImplementedError

    async def acquire_lock(self, key: str, ttl: int) -> bool:
        raise NotImplementedError

    async def get_metadata(self, key: str) -> Any:
        raise NotImplementedError

    async def set_metadata(self, key: str, value: Any) -> None:
        raise NotImplementedError

    async def get_queue_depth(self, queue: str) -> int:
        raise NotImplementedError

    async def fetch_batch(self, queue: str, count: int, timeout: float) -> list[dict]:
        raise NotImplementedError

    async def _ack_batch(self, tasks: list[dict]) -> None:
        raise NotImplementedError


__all__ = ["VTasksBaseBackend"]
