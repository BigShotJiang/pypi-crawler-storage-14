import logging
import time
import traceback
from typing import TYPE_CHECKING, Any

from django.core.exceptions import ImproperlyConfigured
from django.db import transaction
from django.tasks.base import Task, TaskResult, TaskResultStatus
from django.utils.crypto import get_random_string
from valkey.asyncio import Valkey

from .. import conf
from ..serialization import deserialize, serialize
from .base import VTasksBaseBackend

if TYPE_CHECKING:
    from valkey import ConnectionPool as SyncConnectionPool
    from valkey import Valkey as SyncValkey

logger = logging.getLogger(__name__)


class ValkeyTaskBackend(VTasksBaseBackend):
    def __init__(self, alias: str, params: dict[str, Any] | None) -> None:
        super().__init__(alias, params)
        if "OPTIONS" in self.options:
            self.options = self.options["OPTIONS"]
        self.prefix = conf.VTASKS_VALKEY_PREFIX
        self._client: "Valkey" | None = None
        self._sync_client: "SyncValkey" | None = None
        self._sync_pool: "SyncConnectionPool" | None = None

        if "CONNECTION_POOL" in self.options:
            self.pool = self.options["CONNECTION_POOL"]
        else:
            self.pool = None

    def _get_key(self, key: str) -> str:
        return f"{self.prefix}{key}"

    @property
    def client(self) -> "Valkey":
        if self._client is None:
            if self.pool:
                self._client = Valkey(connection_pool=self.pool)
            else:
                url = self.options.get("BROKER_URL")
                if not url:
                    raise ImproperlyConfigured(
                        "BROKER_URL is not configured for Valkey backend"
                    )
                self._client = Valkey.from_url(url)
        return self._client

    @property
    def sync_client(self) -> "SyncValkey":
        if self._sync_client is None:
            url = self.options.get("BROKER_URL")
            if not url:
                raise ImproperlyConfigured(
                    "BROKER_URL is required for synchronous enqueue, "
                    "even when using CONNECTION_POOL"
                )
            # Lazy load when needed
            from valkey import ConnectionPool as SyncConnectionPool
            from valkey import Valkey as SyncValkey

            self._sync_pool = SyncConnectionPool.from_url(url)
            self._sync_client = SyncValkey(connection_pool=self._sync_pool)
        return self._sync_client

    async def _fetch_task(self, queues: list[str]) -> dict | None:
        queue = queues[0]
        source = self._get_key(f"q:{queue}")
        dest = self._get_key(f"processing:{self.worker_id}")
        logger.debug("Fetching task from %s to %s", source, dest)
        data = await self.client.blmove(
            source,
            dest,
            2,  # Timeout
            src="RIGHT",
            dest="LEFT",
        )
        if data:
            unpacked = deserialize(data)
            unpacked["_raw"] = data
            return unpacked
        return None

    async def _ack_batch(self, tasks: list[dict]) -> None:
        """For Valkey, tasks are popped from the queue, so they are already acked."""
        pass

    async def _ack_task(self, task_data: dict) -> None:
        await self.client.lrem(
            self._get_key(f"processing:{self.worker_id}"), 1, task_data["_raw"]
        )

    async def _fail_task(self, task_data: dict, exception: Exception) -> None:
        task_id = task_data.get("id", "unknown")
        logger.warning("Task %s failed. Moving to DLQ.", task_id, exc_info=True)

        failed_data = task_data.copy()
        failed_data.pop("_raw", None)
        failed_data["error_msg"] = str(exception)
        failed_data["error_traceback"] = traceback.format_exc()
        failed_data["failed_at"] = time.time()
        new_payload = serialize(failed_data)

        async with self.client.pipeline(transaction=True) as pipe:
            pipe.lpush(self._get_key("q:failed"), new_payload)
            pipe.ltrim(self._get_key("q:failed"), 0, self.dlq_cap - 1)
            pipe.lrem(
                self._get_key(f"processing:{self.worker_id}"), 1, task_data["_raw"]
            )
            await pipe.execute()

    async def _rescue_tasks(self) -> None:
        while True:
            raw = await self.client.rpop(self._get_key(f"processing:{self.worker_id}"))
            if raw is None:
                break
            unpacked = deserialize(raw)
            queue = unpacked.get("queue", "default")
            await self.client.lpush(self._get_key(f"q:{queue}"), raw)
            logger.warning("Rescued task %s", unpacked["id"])

    async def aenqueue(self, task: "Task", args: tuple, kwargs: dict) -> "TaskResult":
        task_id = get_random_string(32)
        queue_name: str = getattr(task, "queue_name", "default")

        data = {
            "id": task_id,
            "func": task.func.__module__ + "." + task.func.__name__,
            "args": args,
            "kwargs": kwargs,
            "queue": queue_name,
            "ts": time.time(),
            "retries": 0,
        }
        payload = serialize(data)

        await self.client.lpush(self._get_key(f"q:{queue_name}"), payload)

        return TaskResult(
            task=task,
            id=task_id,
            status=TaskResultStatus.READY,
            enqueued_at=None,
            started_at=None,
            last_attempted_at=None,
            finished_at=None,
            args=args,
            kwargs=kwargs,
            backend=self.alias,
            errors=[],
            worker_ids=[],
        )

    async def get_queue_depth(self, queue: str) -> int:
        return await self.client.llen(self._get_key(f"q:{queue}"))

    async def acquire_lock(self, key: str, ttl: int) -> bool:
        full_key = self._get_key(f"scheduler:{key}")
        # Attempt to acquire the lock atomically.
        if await self.client.set(full_key, self.worker_id, ex=ttl, nx=True):
            # We got the lock
            return True

        # We didn't get the lock. Check if we are the current holder.
        current_holder = await self.client.get(full_key)
        if current_holder is not None and current_holder.decode() == self.worker_id:
            # We already hold the lock, so refresh the TTL.
            await self.client.set(full_key, self.worker_id, ex=ttl)
            return True

        # Lock is held by someone else.
        return False

    async def fetch_batch(self, queue: str, count: int, timeout: float) -> list[dict]:
        """
        Fetches a batch of tasks from the specified queue.
        This is an "unsafe" batch operation as it does not move the tasks
        to a processing queue. If the worker crashes, the tasks are lost.
        """
        key_name = self._get_key(f"q:{queue}")
        logger.debug("Fetching batch of %d tasks from %s", count, key_name)
        result = await self.client.blmpop(
            timeout, 1, key_name, direction="RIGHT", count=count
        )
        if not result:
            return []
        _, items = result  # Now safe to unpac

        tasks = []
        for item in items:
            task_data = deserialize(item)
            task_data["_raw"] = item
            tasks.append(task_data)
        return tasks

    async def get_metadata(self, key: str) -> Any:
        return await self.client.get(self._get_key(f"scheduler:{key}"))

    async def set_metadata(self, key: str, value: Any) -> None:
        await self.client.set(self._get_key(f"scheduler:{key}"), value)

    def enqueue(
        self, task: "Task", args: tuple, kwargs: dict, **options
    ) -> "TaskResult":
        task_id = get_random_string(32)
        queue_name: str = options.get("queue_name") or kwargs.pop(
            "queue_name", getattr(task, "queue_name", "default")
        )

        data = {
            "id": task_id,
            "func": task.name,
            "args": args,
            "kwargs": kwargs,
            "queue": queue_name,
            "ts": time.time(),
            "retries": 0,
        }
        payload = serialize(data)

        def _push():
            self.sync_client.lpush(self._get_key(f"q:{queue_name}"), payload)

        transaction.on_commit(_push)

        return TaskResult(
            task=task,
            id=task_id,
            status=TaskResultStatus.READY,
            enqueued_at=None,
            started_at=None,
            last_attempted_at=None,
            finished_at=None,
            args=args,
            kwargs=kwargs,
            backend=self.alias,
            errors=[],
            worker_ids=[],
        )
