from django.apps import AppConfig


class PostgresConfig(AppConfig):
    name = "django_vtasks.postgres"
    label = "django_vtasks_postgres"
