from django.conf import settings

VTASKS_QUEUES = getattr(settings, "VTASKS_QUEUES", ["default"])
VTASKS_CONCURRENCY = getattr(settings, "VTASKS_CONCURRENCY", 50)
VTASKS_BATCH_QUEUES = getattr(settings, "VTASKS_BATCH_QUEUES", {})
VTASKS_RUN_SCHEDULER = getattr(settings, "VTASKS_RUN_SCHEDULER", True)
VTASKS_SCHEDULE = getattr(settings, "VTASKS_SCHEDULE", {})
VTASKS_COMPRESS_THRESHOLD = getattr(settings, "VTASKS_COMPRESS_THRESHOLD", 1024)
VTASKS_DLQ_CAP = getattr(settings, "VTASKS_DLQ_CAP", 1000)

VTASKS_VALKEY_PREFIX = getattr(settings, "VTASKS_VALKEY_PREFIX", "vt")
if VTASKS_VALKEY_PREFIX and not VTASKS_VALKEY_PREFIX.endswith(":"):
    VTASKS_VALKEY_PREFIX += ":"
