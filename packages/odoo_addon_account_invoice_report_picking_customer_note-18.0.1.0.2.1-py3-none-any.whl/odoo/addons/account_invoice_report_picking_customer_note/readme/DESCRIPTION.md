This module prints the **Picking Customer Comments** (provided by the
`sale_stock_picking_note` module) from the **Delivery Address** contact
on the invoice report. Because this module extends
`sale_stock_picking_note`, please refer to [that module's
README](https://github.com/OCA/sale-workflow/blob/16.0/sale_stock_picking_note/README.rst)
to understand the underlying fields and flow.
