# Fossil-free ecoinvent

<img src="logo.png" alt="Fossil-free ecoinvent logo" width="300">

**Fossil-free ecoinvent** provides a tool to generate partly or fully defossilized versions of ecoinvent databases based on user-defined parameters.  
It is intended for researchers and practitioners working with Life Cycle Assessment (LCA) who require parameterized, defossilized background inventories.

---

## Example Notebook

A full workflow demonstrating how to use the package is available here:

[Example Notebook: Example.ipynb](notebook/Example.ipynb)

---

## Installation

You can install **Fossil-free ecoinvent** either from [PyPI](https://pypi.org/) (recommended for most users) or from source (recommended for development).

### 1. Install from PyPI (recommended)

Simply install using `pip`:

```bash
pip install fossilfree-ecoinvent
