"""External integrations."""

from .openspec import openspec_group

__all__ = [
    "openspec_group",
]
