# Jacobi PhoXi Camera Driver

For instructions regrading installation, getting started, and for general documentation we refer to [docs.jacobirobotics.com](https://docs.jacobirobotics.com).