from __future__ import annotations

from mcp_agent_mail.slack_integration import format_mcp_message_for_slack, mirror_message_to_slack


def test_mirror_message_to_slack_posts_when_enabled(monkeypatch):
    captured = {}

    def fake_post(url, payload):
        captured["url"] = url
        captured["payload"] = payload
        return "ok"

    monkeypatch.setenv("SLACK_MCP_MAIL_WEBHOOK_URL", "https://hooks.slack.com/services/test")
    monkeypatch.setenv("SLACK_MIRROR_ENABLED", "1")
    monkeypatch.setenv("SLACK_WEBHOOK_URL", "")
    monkeypatch.setenv("SLACK_LIVE_TEST", "0")

    monkeypatch.setattr("mcp_agent_mail.slack_integration._post_webhook", fake_post)

    frontmatter = {"project": "proj", "subject": "subj", "thread_id": "tid"}
    body = "hello body"
    resp = mirror_message_to_slack(frontmatter, body)

    assert resp == "ok"
    assert captured["url"] == "https://hooks.slack.com/services/test"
    assert "proj" in captured["payload"]["text"]
    assert "subj" in captured["payload"]["text"]
    assert "tid" in captured["payload"]["text"]
    assert "hello body" in captured["payload"]["text"]


def test_mirror_message_to_slack_skips_when_disabled(monkeypatch):
    monkeypatch.delenv("SLACK_MCP_MAIL_WEBHOOK_URL", raising=False)
    monkeypatch.delenv("SLACK_WEBHOOK_URL", raising=False)
    monkeypatch.setenv("SLACK_MIRROR_ENABLED", "0")

    frontmatter = {"project": "proj", "subject": "subj"}
    body = "hello body"
    resp = mirror_message_to_slack(frontmatter, body)

    assert resp is None


def test_format_mcp_message_for_slack_includes_full_agent_details():
    recipients = [f"Agent {i}" for i in range(1, 8)]

    text, blocks = format_mcp_message_for_slack(
        subject="Demo Subject",
        body_md="Body content",
        sender_name="Primary Sender",
        recipients=recipients,
        message_id="1234567890abcdef",
        importance="high",
    )

    assert "Primary Sender" in text
    assert "Agent 7" in text  # no truncation in fallback text

    assert blocks is not None
    fields = {field["text"] for field in blocks[1]["fields"]}

    sender_field = next(text for text in fields if text.startswith("*From:*"))
    recipient_field = next(text for text in fields if text.startswith("*To:*"))

    assert "*Primary Sender*" in sender_field
    # Should include all recipients in the block list
    assert all(name in recipient_field for name in recipients)
    assert recipient_field.count("•") == len(recipients)
