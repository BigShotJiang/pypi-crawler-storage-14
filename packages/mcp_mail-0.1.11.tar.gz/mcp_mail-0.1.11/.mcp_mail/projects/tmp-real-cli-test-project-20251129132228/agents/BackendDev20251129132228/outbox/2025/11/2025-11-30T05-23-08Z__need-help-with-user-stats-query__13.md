---json
{
  "ack_required": false,
  "attachments": [],
  "bcc": [],
  "cc": [
    "global-inbox-tmp-real-cli-test-project-20251129132228"
  ],
  "created": "2025-11-30T05:23:08.007037+00:00",
  "from": "BackendDev20251129132228",
  "id": 13,
  "importance": "normal",
  "project": "/tmp/real_cli_test_project_20251129132228",
  "project_slug": "tmp-real-cli-test-project-20251129132228",
  "subject": "Need help with user stats query",
  "thread_id": null,
  "to": [
    "DatabaseAdmin20251129132228"
  ]
}
---

Hi DatabaseAdmin20251129132228! FrontendDev20251129132228 needs dashboard stats. Can you help optimize this query: SELECT * FROM user_activity WHERE date > NOW() - INTERVAL '7 days'?
