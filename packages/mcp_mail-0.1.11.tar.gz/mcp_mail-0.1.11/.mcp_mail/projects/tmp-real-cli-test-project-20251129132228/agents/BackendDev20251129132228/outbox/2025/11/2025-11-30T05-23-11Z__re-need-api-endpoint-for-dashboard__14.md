---json
{
  "ack_required": false,
  "attachments": [],
  "bcc": [],
  "cc": [
    "global-inbox-tmp-real-cli-test-project-20251129132228"
  ],
  "created": "2025-11-30T05:23:11.999492+00:00",
  "from": "BackendDev20251129132228",
  "id": 14,
  "importance": "normal",
  "project": "/tmp/real_cli_test_project_20251129132228",
  "project_slug": "tmp-real-cli-test-project-20251129132228",
  "subject": "Re: Need API endpoint for dashboard",
  "thread_id": null,
  "to": [
    "FrontendDev20251129132228"
  ]
}
---

Working on it! Asked DatabaseAdmin20251129132228 for help with the query. Will have it ready soon.
