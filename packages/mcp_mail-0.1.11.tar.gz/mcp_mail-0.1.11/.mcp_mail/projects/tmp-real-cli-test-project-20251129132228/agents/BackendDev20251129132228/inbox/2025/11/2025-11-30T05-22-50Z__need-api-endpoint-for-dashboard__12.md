---json
{
  "ack_required": false,
  "attachments": [],
  "bcc": [],
  "cc": [
    "global-inbox-tmp-real-cli-test-project-20251129132228"
  ],
  "created": "2025-11-30T05:22:50.980939+00:00",
  "from": "FrontendDev20251129132228",
  "id": 12,
  "importance": "high",
  "project": "/tmp/real_cli_test_project_20251129132228",
  "project_slug": "tmp-real-cli-test-project-20251129132228",
  "subject": "Need API endpoint for dashboard",
  "thread_id": null,
  "to": [
    "BackendDev20251129132228"
  ]
}
---

Hi BackendDev20251129132228! Can you create GET /api/dashboard/stats endpoint? I need it for the React dashboard component.
