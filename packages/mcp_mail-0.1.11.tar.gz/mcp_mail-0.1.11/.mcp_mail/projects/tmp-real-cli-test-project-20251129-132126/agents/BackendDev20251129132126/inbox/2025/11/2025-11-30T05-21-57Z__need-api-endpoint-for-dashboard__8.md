---json
{
  "ack_required": false,
  "attachments": [],
  "bcc": [],
  "cc": [
    "global-inbox-tmp-real-cli-test-project-20251129-132126"
  ],
  "created": "2025-11-30T05:21:57.897056+00:00",
  "from": "FrontendDev20251129132126",
  "id": 8,
  "importance": "high",
  "project": "/tmp/real_cli_test_project_20251129_132126",
  "project_slug": "tmp-real-cli-test-project-20251129-132126",
  "subject": "Need API endpoint for dashboard",
  "thread_id": null,
  "to": [
    "BackendDev20251129132126"
  ]
}
---

Hi BackendDev-20251129_132126! Can you create GET /api/dashboard/stats endpoint? I need it for the React dashboard component.
