---json
{
  "ack_required": false,
  "attachments": [],
  "bcc": [],
  "cc": [
    "global-inbox-tmp-real-cli-test-project-20251129-132126"
  ],
  "created": "2025-11-30T05:22:31.925664+00:00",
  "from": "BackendDev20251129132126",
  "id": 11,
  "importance": "high",
  "project": "/tmp/real_cli_test_project_20251129_132126",
  "project_slug": "tmp-real-cli-test-project-20251129-132126",
  "subject": "Re: Need API endpoint for dashboard",
  "thread_id": "8",
  "to": [
    "FrontendDev20251129132126"
  ]
}
---

Working on it! Asked DatabaseAdmin-20251129_132126 for help with the query. Will have it ready soon.
