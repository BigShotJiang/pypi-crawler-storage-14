---json
{
  "ack_required": false,
  "attachments": [],
  "bcc": [],
  "cc": [
    "global-inbox-tmp-real-cli-test-project-20251129-132126"
  ],
  "created": "2025-11-30T05:22:25.391317+00:00",
  "from": "DatabaseAdmin20251129132126",
  "id": 10,
  "importance": "high",
  "project": "/tmp/real_cli_test_project_20251129_132126",
  "project_slug": "tmp-real-cli-test-project-20251129-132126",
  "subject": "Re: Need help with user stats query",
  "thread_id": null,
  "to": [
    "BackendDev20251129132126"
  ]
}
---

Here's the optimized query:
```sql
CREATE INDEX IF NOT EXISTS idx_user_activity_date ON user_activity(date);
SELECT user_id, COUNT(*) as activity_count FROM user_activity WHERE date > NOW() - INTERVAL '7 days' GROUP BY user_id;
```
This will be much faster!
