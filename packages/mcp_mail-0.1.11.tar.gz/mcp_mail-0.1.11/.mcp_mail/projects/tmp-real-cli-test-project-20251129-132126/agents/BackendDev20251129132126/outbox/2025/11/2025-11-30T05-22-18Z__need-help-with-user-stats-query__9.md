---json
{
  "ack_required": false,
  "attachments": [],
  "bcc": [],
  "cc": [
    "global-inbox-tmp-real-cli-test-project-20251129-132126"
  ],
  "created": "2025-11-30T05:22:18.243699+00:00",
  "from": "BackendDev20251129132126",
  "id": 9,
  "importance": "normal",
  "project": "/tmp/real_cli_test_project_20251129_132126",
  "project_slug": "tmp-real-cli-test-project-20251129-132126",
  "subject": "Need help with user stats query",
  "thread_id": null,
  "to": [
    "DatabaseAdmin20251129132126"
  ]
}
---

Hi DatabaseAdmin-20251129_132126! FrontendDev-20251129_132126 needs dashboard stats. Can you help optimize this query: SELECT * FROM user_activity WHERE date > NOW() - INTERVAL '7 days'?
