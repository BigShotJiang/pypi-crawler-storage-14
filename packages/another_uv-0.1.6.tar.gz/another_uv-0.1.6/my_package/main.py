from fastmcp import FastMCP

mcp = FastMCP("Demo 🚀")

@mcp.tool
def add(a: int, b: int) -> int:
    """Add two numbers"""
    return a + b

def main():
    mcp.run()  # Uses STDIO transport by default

if __name__ == "__main__":
    main()