from langchain_core.messages import (HumanMessage, SystemMessage)

from src.constructor.tool_aware import create_tool_aware_agent
from src.constructor.constructor_model import ConstructorModel

from src.tool_providers.file_system_tools_provider import FileSystemToolsProvider
from src.tool_providers.code_analysis_tools_provider import CodeAnalysisToolsProvider
from src.tool_providers.venv_tools_provider import VenvToolsProvider
from src.tool_providers.github_stats_tools_provider import GitHubStatsToolsProvider

from src.core.llm_service import call_llm
from src.core.task_manager import get_github_links, basic_analysis

from langchain.agents import create_agent
from langchain_core.tools import tool

from langchain_google_genai import ChatGoogleGenerativeAI

# project_dir = 'cloned_repos/evalset'

# fs_tools_provider = FileSystemToolsProvider(project_dir)
# code_analysis_tools_provider = CodeAnalysisToolsProvider(project_dir)
# venv_tools_provider = VenvToolsProvider(project_dir)

# all_tools = fs_tools_provider.get_tool_list() + \
#     code_analysis_tools_provider.get_tool_list() + \
#     venv_tools_provider.get_tool_list()

# model = ConstructorModel()
# agent = create_tool_aware_agent(
#     model=model,
#     tools=all_tools
# )
# result = agent.invoke(
#     agent.setup_state(
#         messages=[
#             SystemMessage("You are an experienced Python developer. Use the tools at your disposal carefully. Always stick to the correct formatting when using tool calls."),
#             HumanMessage("Understand the project and generate a working script that demonstrates its main functionality. Use the tools to validate and refine your script as much as possible. On your final response, output just the final version of the script and nothing else.")
#         ],
#     )
# )

# for m in result['messages']:
#     m.pretty_print()

# print(basic_analysis(get_github_links("https://arxiv.org/pdf/1907.10902")[0]))

# st = GitHubStatsToolsProvider("https://github.com/pfnet/optuna/")
# print(st.get_basic_info())
# @tool
# def get_name() -> str:
#     """Returns the name of the agent."""
#     return "Brook"

# model = ChatGoogleGenerativeAI(model="gemini-2.5-pro", api_key="AIzaSyDp2selEGYoJZ8CCHG7BgVzuc5sHaqI0I8")
# agent = create_agent(model=model, tools=[get_name], system_prompt="Use the tool to answer the user's questions.")

# response = agent.invoke({"messages": [("user", "greet me by my name")]})

# print(response)

print(basic_analysis("https://github.com/hyperopt/hyperopt"))