from src.ui.app import PaperProbeApp

def paperprobe() -> None:
    PaperProbeApp().run()