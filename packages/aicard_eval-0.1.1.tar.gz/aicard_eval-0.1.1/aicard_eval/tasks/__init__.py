from .base import Task
from . import multimodal
from . import vision
from . import nlp


