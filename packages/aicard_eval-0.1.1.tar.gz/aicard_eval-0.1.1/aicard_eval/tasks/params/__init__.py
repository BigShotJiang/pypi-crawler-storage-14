from  .classification import main as classification
from .unknown import main as unknown
from .object_detection import main as object_detection
