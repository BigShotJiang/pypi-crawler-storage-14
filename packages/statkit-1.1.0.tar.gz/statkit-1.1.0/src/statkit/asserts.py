"""Assert functions based on, and for, statistical tests."""

from textwrap import dedent

from numpy import (
    arange,
    array,
    array2string,
    cumsum,
    log,
    floor,
    hstack,
    mean,
    ones_like,
)
import numpy as np
from scipy.stats import linregress


def _str(x, precision=2) -> str:
    """Turn into number of array thereof into a string."""
    if isinstance(x, float):
        return f"{x:.{precision}f}"
    return array2string(x, precision=precision)


def _linregress(X, Y):
    """A vectorized version of `linregress`."""
    if isinstance(Y, float) or Y.ndim == 1:
        result = linregress(X, Y)
        return (
            result.slope,
            result.intercept,
            result.rvalue,
            result.pvalue,
            result.stderr,
            result.intercept_stderr,
        )

    slope = []
    intercept = []
    rvalue = []
    pvalue = []
    stderr = []
    intercept_stderr = []
    for y_i in Y.reshape(len(Y), -1).transpose():
        result_i = linregress(X, y_i)
        slope.append(result_i.slope)
        intercept.append(result_i.intercept)
        rvalue.append(result_i.rvalue)
        pvalue.append(result_i.pvalue)
        stderr.append(result_i.stderr)
        intercept_stderr.append(result_i.intercept_stderr)

    # All but the leading batch axis.
    suffix_shape = Y.shape[1:]
    slope = array(slope).reshape(suffix_shape)
    intercept = array(intercept).reshape(suffix_shape)
    rvalue = array(rvalue).reshape(suffix_shape)
    pvalue = array(pvalue).reshape(suffix_shape)
    stderr = array(stderr).reshape(suffix_shape)
    intercept_stderr = array(intercept_stderr).reshape(suffix_shape)
    return slope, intercept, rvalue, pvalue, stderr, intercept_stderr


def assert_converges_to(true_estimate, samples, verbose=False):
    r"""Assert with 95% probability if sample average converges to `true_estimate`.

    **Theory**

    Let $\mu$ denote the true mean and \( \hat{\mu}_M = M^{-1}\sum_{i=1}^M x^{(i)} \) be the (emperical) Monte Carlo mean based on $M$ samples.
    $$
    \text{MSE} = \langle(\hat{\mu}_M - \mu)^2\rangle =
    \langle(\hat{\mu}_M - \langle \hat{\mu}_M \rangle )^2\rangle + \langle(\langle \hat{\mu}_M \rangle - \mu)^2\rangle \\
    = \text{var}[\hat{\mu}_M] + (\langle \hat{\mu}_M \rangle - \mu)^2
    $$
    When sample size $M\rightarrow \infty$; $\text{var}[\hat{\mu}_M] \rightarrow 0$ with a rate of $1/M$.
    If $\langle \hat{\mu}_M \rangle = \mu$ (i.e., an unbiased estimate), then $\text{MSE} \rightarrow 0$;
    otherwise, it remains constant. Uses linear regression to test if the variance
    indeed goes down with a rate of $1/M$ by fitting the coefficients $w$ and $b$ to
    the function $\ln \langle(\hat{\mu}_M - \mu)^2\rangle = w\log(M) + b$, and checking if
    $w = -1$ with 95% probability.

    Example:
        Generate normal samples with mean \( \mu=0.5 \), then test if the sample average
        converges to a (deliberately incorrect) value. An AssertionError will be raised.

        ```
        import numpy as np
        from statkit.asserts import assert_converges_to

        true_mean = 0.5
        draws = np.random.normal(loc=true_mean, size=10_000)
        assert_converges_to(true_estimate=0.3, samples=draws)
        ```

    Args:
        true_estimate: The true mean $\mu$ of the samples.
        samples: The samples $x=[x^{(1)},\dots, x^{(M)}]^\intercal$ to test.
        verbose: Whether to print the regression message.

    Raises:
        AssertionError: If the sample average does not converge to the true mean with a
        confidence of 95% probability.
        AssertionError: If the sample size is too small to reliably estimate convergence.
    """
    M_samples = len(samples)

    # Split training data in non-overlapping chunks.
    # How: use geometric series: sum (1/2)^n = 1
    minimum_sample_size = 8
    num_points = floor(log(M_samples / minimum_sample_size) / log(2))
    sample_proportion = 0.5 ** (arange(1, num_points + 1))
    sample_sizes = (sample_proportion * M_samples).astype(int)
    slice_indices = cumsum(hstack((0, sample_sizes)))
    datasets = [
        samples[start:stop]
        for start, stop in zip(slice_indices[:-1], slice_indices[1:])
    ]

    mse = [((mean(d, axis=0) - true_estimate) ** 2) for d in datasets]

    slope, _, _, _, stderr, _ = _linregress(log(sample_sizes), log(mse))

    expected_slope = -1.0
    slope_lower = slope - 1.96 * stderr
    slope_upper = slope + 1.96 * stderr

    regression_message = (
        "Slope between ln MSE and ln N:\n"
        f"Expected: {_str(-ones_like(slope))}\n"
        f"Actual: {_str(slope)} (95% confidence interval: {_str(slope_lower)} to {_str(slope_upper)})"
    )

    if verbose:
        print(regression_message)
    if not np.all((slope_lower < expected_slope) & (expected_slope < slope_upper)):
        raise AssertionError(
            dedent(
                f"""Samples do not converge to true estimate μ={_str(true_estimate)}.
            The mean squared error (MSE) between Monte Carlo estimate from `samples` and
            μ does not go down with sample size as 1/M. With a confidence of 95% probability,
            your samples are biased.
            {regression_message}"""
            )
        )
    elif np.any(slope_upper > 0.0):
        raise AssertionError(
            "Sample size too small to reliably estimate convergence. Increase the number of samples."
        )
