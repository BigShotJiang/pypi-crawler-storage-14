from unittest import TestCase

import numpy as np
from numpy import e, euler_gamma, pi

from statkit.asserts import assert_converges_to


class TestAssertConvergesTo(TestCase):
    """Test assert_converges_to with various array shapes and means."""

    def setUp(self):
        """Set up random number generator for reproducible tests."""
        self.rng = np.random.default_rng(42)
        # Use a large number of samples for reliable convergence testing
        self.n_samples = 20_000

    def test_scalar_correct_mean_pi(self):
        """Test scalar samples with correct mean (pi)."""
        mean = pi
        std = 2.5
        samples = self.rng.normal(loc=mean, scale=std, size=self.n_samples)
        # Should not raise an AssertionError
        assert_converges_to(mean, samples)

    def test_scalar_incorrect_mean(self):
        """Test scalar samples with incorrect mean should raise AssertionError."""
        true_mean = pi
        wrong_mean = pi + 1.0  # Deliberately wrong
        std = 2.0
        samples = self.rng.normal(loc=true_mean, scale=std, size=self.n_samples)
        # Should raise an AssertionError
        with self.assertRaises(AssertionError):
            assert_converges_to(wrong_mean, samples)

    def test_vector_correct_mean(self):
        """Test vector samples with correct mean."""
        mean = np.array([pi, euler_gamma, e])
        std = np.array([1.5, 2.0, 0.8])
        samples = self.rng.normal(loc=mean, scale=std, size=(self.n_samples, 3))
        # Should not raise an AssertionError
        assert_converges_to(mean, samples)

    def test_vector_incorrect_mean(self):
        """Test vector samples with incorrect mean should raise AssertionError."""
        true_mean = np.array([pi, euler_gamma, e])
        wrong_mean = np.array([pi + 0.5, euler_gamma, e])  # First element wrong
        std = np.array([1.5, 2.0, 0.8])
        samples = self.rng.normal(loc=true_mean, scale=std, size=(self.n_samples, 3))
        # Should raise an AssertionError
        with self.assertRaises(AssertionError):
            assert_converges_to(wrong_mean, samples)

    def test_matrix_correct_mean(self):
        """Test matrix samples with correct mean."""
        mean = np.array([[pi, euler_gamma], [e, 2.71828]])
        std = np.array([[1.2, 1.8], [0.9, 1.5]])
        samples = self.rng.normal(loc=mean, scale=std, size=(self.n_samples, 2, 2))
        # Should not raise an AssertionError
        assert_converges_to(mean, samples)

    def test_matrix_incorrect_mean(self):
        """Test matrix samples with incorrect mean should raise AssertionError."""
        true_mean = np.array([[pi, euler_gamma], [e, 2.71828]])
        wrong_mean = np.array(
            [[pi, euler_gamma + 1.0], [e, 2.71828]]
        )  # One element wrong
        std = np.array([[1.2, 1.8], [0.9, 1.5]])
        samples = self.rng.normal(loc=true_mean, scale=std, size=(self.n_samples, 2, 2))
        # Should raise an AssertionError
        with self.assertRaises(AssertionError):
            assert_converges_to(wrong_mean, samples)
