from langchain_core.tools import tool
import os
 
@tool
def get_current_directory() -> str:
    """
    Returns the absolute path of the current working directory.

    Returns:
        str: A string containing the path of the current directory.
    """
    return os.getcwd()

# @tool
# def move_to_directory(dir_name: str) -> str:
#     """
#     Changes the current working directory to the specified path.

#     Args:
#         dir_name (str): The path of the directory to move to. 
#                         This can be a relative (e.g., '../new_folder') 
#                         or absolute path.

#     Returns:
#         str: A string confirming the directory change or reporting an error.
#     """
#     try:
#         os.chdir(dir_name)
#         return f"Changed current directory to '{dir_name}'"
#     except Exception as e:
#         return f"Error changing directory to '{dir_name}': {str(e)}"

@tool
def create_directory(dir_name: str) -> str:
    """
    Creates a new directory at the specified path. 
    This tool can create nested directories (e.g., 'folder1/folder2').

    Args:
        dir_name (str): The path (including the name) of the directory to create.

    Returns:
        str: A string confirming the directory was created or reporting an error.
    """
    try:
        os.makedirs(dir_name, exist_ok=True)
        return f"Directory '{dir_name}' created successfully."
    except Exception as e:
        return f"Error creating directory '{dir_name}': {str(e)}"

@tool
def delete_directory(dir_name: str) -> str:
    """
    Deletes an *empty* directory at the specified path. 
    The tool will fail if the directory is not empty.

    Args:
        dir_name (str): The path of the empty directory to delete.

    Returns:
        str: A string confirming the directory was deleted or reporting an error.
    """
    try:
        os.rmdir(dir_name)
        return f"Directory '{dir_name}' deleted successfully."
    except Exception as e:
        return f"Error deleting directory '{dir_name}': {str(e)}"

@tool
def create_file(file_name: str) -> str:
    """
    Creates a new, empty file at the specified path. 
    If the file already exists, it will be overwritten and emptied.

    Args:
        file_name (str): The path and name of the file to create (e.g., 'folder/new_file.txt').

    Returns:
        str: A string confirming the file was created or reporting an error.
    """
    try:
        with open(file_name, 'w') as file:
            file.write("")  # Create an empty file
        return f"File '{file_name}' created successfully."
    except Exception as e:
        return f"Error creating file '{file_name}': {str(e)}"

@tool
def delete_file(file_name: str) -> str:
    """
Deletes a file at the specified path.

    Args:
        file_name (str): The path and name of the file to delete.

    Returns:
        str: A string confirming the file was deleted or reporting an error.
    """
    try:
        os.remove(file_name)
        return f"File '{file_name}' deleted successfully."
    except Exception as e:
        return f"Error deleting file '{file_name}': {str(e)}"

@tool
def list_files(dir_path: str) -> str:
    """
    Lists all files and directories in a *specified directory*.

    Args:
        dir_path (str): The relative or absolute path of the directory to list (e.g., '.', 'src', '/app/utils').

    Returns:
        str: A single string where each file or directory name is 
             separated by a newline character.
             Returns an error message if the path is invalid or not a directory.
             Returns a specific message if the directory is empty.
    """
    try:
        files = os.listdir(dir_path)
        if not files:
            return f"Directory '{dir_path}' is empty."
        return "\n".join(files)
    except FileNotFoundError:
        return f"Error: Directory not found at path '{dir_path}'."
    except NotADirectoryError:
        return f"Error: The path '{dir_path}' is a file, not a directory."
    except Exception as e:
        return f"Error listing files in '{dir_path}': {str(e)}"

@tool
def read_file(file_path: str) -> str:
    """
    Reads the entire content of a text file and returns it as a single string.

    Args:
        file_path (str): The path and name of the file to read.

    Returns:
        str: A string containing the full content of the file, or an error message.
    """
    try:
        with open(file_path, 'r') as file:
            content = file.read()
        return content
    except Exception as e:
        return f"Error reading file '{file_path}': {str(e)}"

@tool
def write_to_file(file_path: str, content: str) -> str:
    """
    Writes the given text content to a specified file. 
    **Warning: This will overwrite any existing content in the file.**

    Args:
        file_path (str): The path of the file to write to.
        content (str): The text content to write into the file.

    Returns:
        str: A string confirming the content was written or reporting an error.
    """
    try:
        with open(file_path, 'w') as file:
            file.write(content)
        return f"Content written to file '{file_path}' successfully."
    except Exception as e:
        return f"Error writing to file '{file_path}': {str(e)}"
    
    

# List of all available tools
tools = [
    get_current_directory,
    create_directory,
    delete_directory,
    create_file,
    delete_file,
    list_files,
    read_file,
    write_to_file
]