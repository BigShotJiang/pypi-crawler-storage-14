import os
from langchain_groq import ChatGroq
from langchain_core.prompts import ChatPromptTemplate, MessagesPlaceholder
from src.components.tools import tools
from src.components.prompts import software_engineer_prompt
from langchain_openai import AzureChatOpenAI, AzureOpenAIEmbeddings



# Use it just like any other Ollama model
# # Initialize the LLM
# llm = ChatGoogleGenerativeAI(model="gemini-2.0-flash-lite", temperature=0.2)
# Embeddings
embeddings = AzureOpenAIEmbeddings(
    azure_deployment=os.getenv("AZURE_OPENAI_EMBEDDING_DEPLOYMENT_NAME"),
    openai_api_version=os.getenv("AZURE_OPENAI_EMBEDDING_VERSION"),
    azure_endpoint=os.getenv("AZURE_OPENAI_ENDPOINT"),
    api_key=os.getenv("AZURE_OPENAI_API_KEY"),
)

# Azure GPT Chat Model
llm = AzureChatOpenAI(
    azure_deployment=os.getenv("LARGE_AZURE_OPENAI_DEPLOYMENT_NAME"),
    openai_api_version=os.getenv("LARGE_AZURE_OPENAI_API_VERSION"),
    azure_endpoint=os.getenv("AZURE_OPENAI_ENDPOINT"),
    api_key=os.getenv("AZURE_OPENAI_API_KEY"),
    temperature=1,
    max_retries=2,
    request_timeout=15
)
# llm = ChatGroq(model="openai/gpt-oss-120b", temperature=0.2)
# llm_2 = ChatOpenAI(
#     model="kwaipilot/kat-coder-pro:free",
#     api_key=os.environ.get("OPENROUTER_API_KEY"),
#     base_url="https://openrouter.ai/api/v1",
    
#     # (Optional) You can also set other parameters
#     temperature=0.2,
#     max_tokens=1024
# )
# try:
#     client = Client(
#         host="https://ollama.com",
#         headers={'Authorization': os.getenv("OLLAMA_API_KEY")}
#     ) 

#     def to_ollama_messages(messages):
#         # Handle both ChatPromptTemplate and list of messages
#         if hasattr(messages, "format_prompt"):
#             prompt_messages = messages.format_prompt().to_messages()
#         elif hasattr(messages, "to_messages"):
#             prompt_messages = messages.to_messages()
#         else:
#             prompt_messages = messages

#         formatted = []
#         for msg in prompt_messages:
#             if isinstance(msg, BaseMessage):  # LangChain message object
#                 role, content = msg.type, msg.content
#             else:
#                 raise TypeError(f"Unsupported message type: {type(msg)}")

#             # Map LangChain roles -> Ollama roles
#             if role == "human":
#                 role = "user"
#             elif role == "ai":
#                 role = "assistant"
#             elif role == "system":
#                 role = "system"

#             formatted.append({"role": role, "content": content})
#         return formatted

#     def message_formatting(messages):
#         ollama_msgs = to_ollama_messages(messages)
#         out = client.chat("gpt-oss:120b", messages=ollama_msgs)
#         return out["message"]["content"]

#     Engineer_agent = RunnableLambda(message_formatting)
# except Exception as e:
#     print(f"Warning: Ollama initialization failed: {e}. Falling back to Azure OpenAI.")
#     Engineer_agent = None  # Fallback to Azure OpenAI


agent_with_tools = llm.bind_tools(tools)

# Create the prompt template
prompt = ChatPromptTemplate.from_messages([
    ("system", software_engineer_prompt),
    MessagesPlaceholder(variable_name="messages")
])

software_engineer_agent = prompt | agent_with_tools