import os
import sys

# --- CRITICAL FIX FOR PACKAGING ---
current_package_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, current_package_dir)

# --- IMPORTS ---
import shutil
import subprocess
import asyncio
import hashlib
import random
import webbrowser
import threading
import uvicorn
import importlib
import json
from typing import List, Dict, Optional

from fastapi import FastAPI, HTTPException, WebSocket, WebSocketDisconnect
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from pydantic import BaseModel
from langchain_core.messages import HumanMessage
from dotenv import load_dotenv

# --- Configuration ---
WORK_DIR = os.getcwd()
env_path = os.path.join(WORK_DIR, ".env")

print(f"📂 Loading environment from: {env_path}")
if os.path.exists(env_path):
    load_dotenv(env_path)
else:
    print("⚠️  WARNING: No .env file found. Agent may crash if API keys are missing.")

# --- Import Agent ---
graph_app = None
try:
    from src.engineering_graph import app as graph_app
    print("✅ Agent Logic Imported Successfully")
except Exception as e:
    print(f"\n❌ Error importing agent logic: {e}\n")

app = FastAPI()

# --- Paths ---
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
STATIC_DIR = os.path.join(BASE_DIR, "static")

# --- Mount Assets ---
if os.path.exists(STATIC_DIR):
    assets_path = os.path.join(STATIC_DIR, "assets")
    if os.path.exists(assets_path):
        app.mount("/assets", StaticFiles(directory=assets_path), name="assets")

# --- CORS ---
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"], 
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# --- Data Models ---
class FileUpdate(BaseModel):
    path: str
    content: str

class FileCreate(BaseModel):
    path: str
    type: str

class FileDelete(BaseModel):
    path: str

class CommandRequest(BaseModel):
    command: str

# --- WebSocket Manager ---
class ConnectionManager:
    def __init__(self):
        self.active_connections: List[WebSocket] = []
        # Track running tasks to allow cancellation (Stop button)
        self.active_tasks: Dict[WebSocket, asyncio.Task] = {}

    async def connect(self, websocket: WebSocket):
        await websocket.accept()
        self.active_connections.append(websocket)

    def disconnect(self, websocket: WebSocket):
        if websocket in self.active_connections:
            self.active_connections.remove(websocket)
        if websocket in self.active_tasks:
            self.active_tasks[websocket].cancel()
            del self.active_tasks[websocket]

    async def broadcast(self, message: dict):
        json_msg = json.dumps(message)
        for connection in list(self.active_connections):
            try:
                await connection.send_text(json_msg)
            except Exception:
                pass

manager = ConnectionManager()

# --- Helper Functions ---
def get_dir_hash(path: str) -> str:
    """
    Calculates directory hash.
    """
    hash_str = ""
    if not os.path.exists(path):
        return ""
    
    try:
        for root, dirs, files in os.walk(path):
            dirs.sort()
            files.sort()
            
            for d in dirs:
                hash_str += d
            for file in files:
                file_path = os.path.join(root, file)
                try:
                    stats = os.stat(file_path)
                    hash_str += f"{file}{stats.st_mtime}"
                except FileNotFoundError:
                    pass
    except Exception:
        pass
    return hashlib.md5(hash_str.encode()).hexdigest()

def build_file_tree(path: str):
    name = os.path.basename(path)
    node = {
        "id": os.path.abspath(path),
        "name": name,
        "type": "folder" if os.path.isdir(path) else "file",
        "isOpen": False,
    }
    if os.path.isdir(path):
        try:
            raw_children = os.listdir(path)
            
            children = [build_file_tree(os.path.join(path, x)) for x in raw_children]
            children.sort(key=lambda x: (x["type"] == "file", x["name"]))
            node["children"] = children
        except PermissionError:
            node["children"] = []
    return node

# --- Background File Watcher ---
async def watch_files():
    if not os.path.exists(WORK_DIR):
        return
    
    print(f"👀 Watching files in: {WORK_DIR}")
    loop = asyncio.get_event_loop()
    
    # Initial hash
    last_hash = await loop.run_in_executor(None, get_dir_hash, WORK_DIR)
    
    while True:
        await asyncio.sleep(1)
        # 3. PERFORMANCE FIX: Run hash in thread to avoid blocking WebSocket
        current_hash = await loop.run_in_executor(None, get_dir_hash, WORK_DIR)
        
        if current_hash != last_hash:
            # print("[File Watcher] Change detected")
            last_hash = current_hash
            await manager.broadcast({"type": "system_event", "event": "file_change"})

@app.on_event("startup")
async def startup_event():
    if not os.path.exists(WORK_DIR):
        os.makedirs(WORK_DIR)
        with open(os.path.join(WORK_DIR, "hello.py"), "w") as f:
            f.write("print('Hello from the Agent!')")
    asyncio.create_task(watch_files())


# --- Async Agent Logic ---
async def run_agent_process(websocket: WebSocket, message: str, mode: str):
    global graph_app
    try:
        if graph_app is None:
            await websocket.send_json({"type": "agent_chunk", "text": "🔄 Loading Agent..."})
            if os.path.exists(env_path):
                load_dotenv(env_path, override=True)
            try:
                import src.engineering_graph
                importlib.reload(src.engineering_graph)
                graph_app = src.engineering_graph.app
                print("✅ Agent loaded!")
            except Exception as e:
                await websocket.send_json({"type": "agent_error", "text": f"API Key Error: {e}"})
                return

        inputs = {"messages": [HumanMessage(content=message)], "mode": mode}
        loop = asyncio.get_event_loop()
        
        # Run graph in thread to allow cancellation
        response = await loop.run_in_executor(
            None, 
            lambda: graph_app.invoke(inputs, config={"recursion_limit": 500})
        )
        
        response_text = response["messages"][-1].content
        await websocket.send_json({"type": "agent_response", "text": response_text})

    except asyncio.CancelledError:
        print("Agent task cancelled.")
        await websocket.send_json({"type": "agent_error", "text": "Stopped by user."})
    except Exception as e:
        await websocket.send_json({"type": "agent_error", "text": f"Error: {str(e)}"})
    finally:
        if websocket in manager.active_tasks:
            del manager.active_tasks[websocket]

# --- WebSocket Endpoint ---
@app.websocket("/ws")
async def websocket_endpoint(websocket: WebSocket):
    await manager.connect(websocket)
    try:
        while True:
            data = await websocket.receive_json()
            command_type = data.get("type")

            if command_type == "chat":
                if websocket in manager.active_tasks:
                    manager.active_tasks[websocket].cancel()
                
                task = asyncio.create_task(
                    run_agent_process(websocket, data.get("message"), data.get("mode"))
                )
                manager.active_tasks[websocket] = task

            elif command_type == "stop":
                if websocket in manager.active_tasks:
                    manager.active_tasks[websocket].cancel()

    except WebSocketDisconnect:
        manager.disconnect(websocket)

# --- HTTP Endpoints ---
@app.get("/files")
def get_files():
    if not os.path.exists(WORK_DIR): return {"error": "Directory not found"}
    tree = build_file_tree(WORK_DIR)
    return [tree]

@app.get("/files/content")
def get_file_content(path: str):
    try:
        if not os.path.exists(path):
            raise HTTPException(status_code=404, detail="File not found")
            
        # 1. Try UTF-8 (Standard)
        try:
            with open(path, "r", encoding="utf-8") as f:
                content = f.read()
        except UnicodeDecodeError:
            # 2. Fallback to Latin-1 (Windows default for non-unicode)
            # This prevents the 500 Error crash
            try:
                with open(path, "r", encoding="latin-1") as f:
                    content = f.read()
            except Exception:
                # 3. If binary or truly unreadable
                return {"content": "<< Binary or Unreadable File >>"}

        return {"content": content}
    except Exception as e:
        print(f"Error reading {path}: {e}")
        raise HTTPException(status_code=500, detail=str(e))
    

@app.post("/files/save")
def save_file(update: FileUpdate):
    try:
        with open(update.path, "w", encoding="utf-8") as f: f.write(update.content)
        return {"status": "success"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/files/create")
def create_item(item: FileCreate):
    try:
        full_path = item.path if os.path.isabs(item.path) else os.path.join(WORK_DIR, item.path)
        if item.type == "folder": os.makedirs(full_path, exist_ok=True)
        else:
            os.makedirs(os.path.dirname(full_path), exist_ok=True)
            with open(full_path, "w") as f: f.write("")
        return {"status": "success"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/files/delete")
def delete_item(item: FileDelete):
    try:
        full_path = item.path
        if os.path.isdir(full_path): shutil.rmtree(full_path)
        else: os.remove(full_path)
        return {"status": "success"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/terminal/execute")
def execute_command(req: CommandRequest):
    try:
        result = subprocess.run(req.command, shell=True, cwd=WORK_DIR, capture_output=True, text=True)
        return {"stdout": result.stdout, "stderr": result.stderr}
    except Exception as e:
        return {"error": str(e)}

# --- UI Serving ---
@app.get("/")
async def serve_root():
    index_path = os.path.join(STATIC_DIR, "index.html")
    if os.path.exists(index_path): return FileResponse(index_path)
    return {"error": "index.html not found in 'static' folder"}

@app.get("/{catchall:path}")
async def serve_react_app(catchall: str):
    file_path = os.path.join(STATIC_DIR, catchall)
    if os.path.exists(file_path) and os.path.isfile(file_path): return FileResponse(file_path)
    index_path = os.path.join(STATIC_DIR, "index.html")
    if os.path.exists(index_path): return FileResponse(index_path)
    return {"error": "Frontend files not found."}

def start():
    port = 8000
    host = "127.0.0.1"
    url = f"http://{host}:{port}"
    print(f"🚀 Agentic Engineer starting at {url}")
    threading.Timer(1.5, lambda: webbrowser.open(url)).start()
    uvicorn.run(app, host=host, port=port, log_level="info")

if __name__ == "__main__":
    start()