# Changelog

## 0.2.1
- Add error messages for missing nodes, and beautify logging format

## 0.2.0
- support emit to or fetch from specifc node(s) by string name(s)

## 0.1.2
- the first stable version, fix the bug that Context.fetch may raise asyncio.QueueEmpty exception in previous releases
