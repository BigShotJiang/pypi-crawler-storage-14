"""
Exception classes and translator for backtrader integration.

This module defines the exception hierarchy for DatahubStore and provides
translation from trading_data_client exceptions to backtrader-compatible errors.

Design: .kiro/specs/backtrader-store-integration/design.md (ExceptionTranslator component)
Requirements: 5.2, 10.6
"""

from typing import Optional, Dict, Any
import trading_data_client.exceptions as client_exc


# ============================================================================
# Exception Hierarchy
# ============================================================================

class DatahubStoreError(Exception):
    """
    Base exception for all DatahubStore errors.
    
    All exceptions raised by DatahubStore inherit from this class.
    This provides a single exception type for users to catch all store-related errors.
    """
    
    def __init__(self, message: str, details: Optional[Dict[str, Any]] = None):
        """
        Initialize exception.
        
        Args:
            message: Error message
            details: Optional dictionary with additional error details
        """
        self.message = message
        self.details = details or {}
        super().__init__(self.message)


class ConfigurationError(DatahubStoreError):
    """
    Raised when store or data feed configuration is invalid.
    
    Examples:
    - Invalid server URL
    - Invalid timeout/retry settings
    - Invalid timeframe
    - Missing required parameters
    
    Strategy: Fail fast during initialization with clear validation errors.
    """
    pass


class ConnectionError(DatahubStoreError):
    """
    Raised when connection to Trading Data Server fails.
    
    Examples:
    - Server unreachable
    - Network timeout
    - DNS resolution failure
    
    Strategy: Retry with exponential backoff, translate to backtrader-compatible errors.
    This error is typically retryable.
    """
    
    def __init__(self, message: str, url: Optional[str] = None):
        """
        Initialize connection error.
        
        Args:
            message: Error message
            url: URL that failed to connect
        """
        super().__init__(message, {"url": url})
        self.url = url


class ServerError(DatahubStoreError):
    """
    Raised when Trading Data Server returns an error.
    
    Examples:
    - 4xx client errors (bad request, not found)
    - 5xx server errors (internal error, service unavailable)
    
    Strategy: Translate to meaningful exceptions, retry only for 5xx errors.
    """
    
    def __init__(self, status_code: int, message: str, response: Optional[Dict[str, Any]] = None):
        """
        Initialize server error.
        
        Args:
            status_code: HTTP status code
            message: Error message
            response: Server response body
        """
        super().__init__(
            f"Server error {status_code}: {message}",
            {"status_code": status_code, "response": response}
        )
        self.status_code = status_code
        self.response = response


class DataError(DatahubStoreError):
    """
    Raised when data validation or processing fails.
    
    Examples:
    - Invalid bar data (missing fields, invalid values)
    - Out-of-order timestamps
    - Empty result sets
    
    Strategy: Log warnings, skip invalid bars, continue processing.
    """
    
    def __init__(self, message: str, data: Optional[Any] = None):
        """
        Initialize data error.
        
        Args:
            message: Error message
            data: Invalid data that caused the error
        """
        super().__init__(message, {"data": data})
        self.data = data


# ============================================================================
# Exception Translator
# ============================================================================

class ExceptionTranslator:
    """
    Translate trading_data_client exceptions to backtrader-compatible errors.
    
    This utility class provides methods to:
    1. Translate exceptions from trading_data_client to DatahubStore exceptions
    2. Determine if exceptions are retryable
    3. Format error messages for backtrader users
    
    Design: .kiro/specs/backtrader-store-integration/design.md (ExceptionTranslator)
    Requirements: 5.2, 10.6
    """
    
    @staticmethod
    def translate(exc: Exception) -> Exception:
        """
        Translate exception to backtrader-compatible error.
        
        Converts trading_data_client exceptions to DatahubStore exceptions
        with meaningful error messages for backtrader users.
        
        Args:
            exc: Exception from trading_data_client or other source
            
        Returns:
            Translated DatahubStore exception
            
        Example:
            >>> try:
            ...     client.get_historical_bars(...)
            ... except Exception as e:
            ...     raise ExceptionTranslator.translate(e)
        """
        # Handle trading_data_client exceptions
        if isinstance(exc, client_exc.ConnectionError):
            return ConnectionError(
                message=ExceptionTranslator.format_error_message(exc),
                url=exc.url
            )
        
        elif isinstance(exc, client_exc.ClientError):
            # 4xx errors are non-retryable client errors
            return ServerError(
                status_code=exc.status_code,
                message=ExceptionTranslator.format_error_message(exc),
                response=exc.response
            )
        
        elif isinstance(exc, client_exc.ServerError):
            # 5xx errors are retryable server errors
            return ServerError(
                status_code=exc.status_code,
                message=ExceptionTranslator.format_error_message(exc),
                response=exc.response
            )
        
        elif isinstance(exc, client_exc.ValidationError):
            return DataError(
                message=ExceptionTranslator.format_error_message(exc),
                data={"field": exc.field}
            )
        
        elif isinstance(exc, client_exc.TradingDataClientError):
            # Generic client error
            return DatahubStoreError(
                message=ExceptionTranslator.format_error_message(exc),
                details=exc.details
            )
        
        # Handle standard Python exceptions
        elif isinstance(exc, ValueError):
            return ConfigurationError(
                message=f"Invalid configuration: {str(exc)}"
            )
        
        elif isinstance(exc, TypeError):
            return ConfigurationError(
                message=f"Invalid type in configuration: {str(exc)}"
            )
        
        # For unknown exceptions, wrap in base DatahubStoreError
        else:
            return DatahubStoreError(
                message=f"Unexpected error: {type(exc).__name__}: {str(exc)}"
            )
    
    @staticmethod
    def is_retryable(exc: Exception) -> bool:
        """
        Determine if exception is retryable.
        
        Retryable errors are typically transient and may succeed on retry:
        - Network timeouts
        - 5xx server errors
        - Temporary connection failures
        
        Non-retryable errors will not succeed without fixing the request:
        - 4xx client errors (bad request)
        - Invalid configuration
        - Authentication failures
        
        Args:
            exc: Exception to check
            
        Returns:
            True if exception is retryable, False otherwise
            
        Example:
            >>> if ExceptionTranslator.is_retryable(exc):
            ...     retry_with_backoff()
            ... else:
            ...     raise exc
        """
        # ConnectionError is retryable (network issues)
        if isinstance(exc, (ConnectionError, client_exc.ConnectionError)):
            return True
        
        # ServerError with 5xx status code is retryable
        if isinstance(exc, (ServerError, client_exc.ServerError)):
            if hasattr(exc, 'status_code'):
                # 5xx errors are retryable, 4xx are not
                return 500 <= exc.status_code < 600
            return True  # Assume retryable if no status code
        
        # ClientError (4xx) is not retryable
        if isinstance(exc, client_exc.ClientError):
            return False
        
        # Configuration errors are not retryable
        if isinstance(exc, (ConfigurationError, ValueError, TypeError)):
            return False
        
        # Data errors are not retryable
        if isinstance(exc, (DataError, client_exc.ValidationError)):
            return False
        
        # Unknown errors: assume not retryable to be safe
        return False
    
    @staticmethod
    def format_error_message(exc: Exception) -> str:
        """
        Format error message for backtrader users.
        
        Creates clear, actionable error messages that help users understand
        what went wrong and how to fix it.
        
        Args:
            exc: Exception to format
            
        Returns:
            Formatted error message
            
        Example:
            >>> msg = ExceptionTranslator.format_error_message(exc)
            >>> print(msg)
            "Failed to connect to Trading Data Server at http://localhost:8000. 
             Please check that the server is running and the URL is correct."
        """
        # Handle trading_data_client exceptions
        if isinstance(exc, client_exc.ConnectionError):
            url = exc.url or "unknown URL"
            return (
                f"Failed to connect to Trading Data Server at {url}. "
                f"Please check that the server is running and the URL is correct. "
                f"Original error: {exc.message}"
            )
        
        elif isinstance(exc, client_exc.ClientError):
            return (
                f"Bad request to Trading Data Server (HTTP {exc.status_code}). "
                f"Please check your request parameters (symbol, date range, timeframe). "
                f"Original error: {exc.message}"
            )
        
        elif isinstance(exc, client_exc.ServerError):
            return (
                f"Trading Data Server error (HTTP {exc.status_code}). "
                f"The server may be temporarily unavailable. "
                f"Original error: {exc.message}"
            )
        
        elif isinstance(exc, client_exc.ValidationError):
            return (
                f"Data validation failed for field '{exc.field}'. "
                f"Original error: {exc.message}"
            )
        
        elif isinstance(exc, client_exc.TradingDataClientError):
            return f"Trading Data Client error: {exc.message}"
        
        # Handle DatahubStore exceptions (already formatted)
        elif isinstance(exc, DatahubStoreError):
            return exc.message
        
        # Handle standard Python exceptions
        elif isinstance(exc, ValueError):
            return f"Invalid value: {str(exc)}"
        
        elif isinstance(exc, TypeError):
            return f"Invalid type: {str(exc)}"
        
        # Unknown exception
        else:
            return f"{type(exc).__name__}: {str(exc)}"
