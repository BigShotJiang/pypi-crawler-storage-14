"""
Backtrader Integration for Trading Data Client

This module provides backtrader Store and Data Feed implementations
that connect to the Trading Data Server for backtesting.

Design Reference:
- Design: .kiro/specs/backtrader-store-integration/design.md
- Requirements: .kiro/specs/backtrader-store-integration/requirements.md
- Architecture: .kiro/specs/backtrader-store-integration/ARCHITECTURE_CLARIFICATION.md
"""

# Components will be imported here as they are implemented
from .store import DatahubStore
from .datafeed import DatahubData
from .converter import DataConverter
from .exceptions import (
    DatahubStoreError,
    ConfigurationError,
    ConnectionError,
    ServerError,
    DataError,
    ExceptionTranslator,
)

__all__ = [
    # Store and Data Feed
    "DatahubStore",
    "DatahubData",
    # Utilities
    "DataConverter",
    "ExceptionTranslator",
    # Exceptions
    "DatahubStoreError",
    "ConfigurationError",
    "ConnectionError",
    "ServerError",
    "DataError",
]
