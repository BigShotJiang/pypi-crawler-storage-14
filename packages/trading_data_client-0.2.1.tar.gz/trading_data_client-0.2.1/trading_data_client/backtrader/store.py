"""
Backtrader Store implementation for Trading Data Server.

Design: .kiro/specs/backtrader-store-integration/design.md (DatahubStore component)
Requirements: 1.1, 1.2, 1.4, 1.5, 10.1, 12.1
"""

import logging
from typing import Optional

import backtrader as bt

from ..client import TradingDataClient
from .exceptions import ConfigurationError

logger = logging.getLogger(__name__)


class DatahubStore(bt.Store):
    """
    Backtrader Store for Trading Data Server.
    
    Provides connection management, data feed factory, and broker access.
    Uses backtrader's built-in MetaSingleton to ensure connection reuse across data feeds.
    
    Design Pattern: Adapter Pattern - adapts Trading Data Server API to backtrader interface
    
    Attributes:
        params: Store parameters (server_url, timeout, max_retries, cash, commission)
        _client: TradingDataClient instance (shared across feeds)
        _started: Whether store has been started
    
    Example:
        >>> store = DatahubStore(server_url='http://localhost:8000')
        >>> data = store.getdata(symbol='AAPL', fromdate=start, todate=end)
        >>> cerebro.adddata(data)
        >>> broker = store.getbroker()
        >>> cerebro.setbroker(broker)
    """
    
    params = (
        ('server_url', 'http://localhost:8000'),
        ('timeout', 30),
        ('max_retries', 3),
        ('cash', 10000.0),
        ('commission', 0.0),
    )
    
    def __init__(self):
        """
        Initialize store and create TradingDataClient.
        
        Validates configuration parameters and creates the underlying
        TradingDataClient instance that will be shared across all data feeds.
        
        Raises:
            ConfigurationError: If parameters are invalid
        """
        super(DatahubStore, self).__init__()
        
        # Validate parameters
        self._validate_params()
        
        # Create TradingDataClient instance
        try:
            self._client: Optional[TradingDataClient] = TradingDataClient(
                server_url=self.p.server_url,
                timeout=self.p.timeout,
                max_retries=self.p.max_retries
            )
            logger.info(
                f"DatahubStore initialized: server={self.p.server_url}, "
                f"timeout={self.p.timeout}s, max_retries={self.p.max_retries}"
            )
        except ValueError as e:
            raise ConfigurationError(f"Invalid configuration: {e}")
        
        self._started = False
    
    def _validate_params(self) -> None:
        """
        Validate store parameters.
        
        Raises:
            ConfigurationError: If any parameter is invalid
        """
        # Validate server_url
        if not self.p.server_url:
            raise ConfigurationError("server_url cannot be empty")
        
        if not isinstance(self.p.server_url, str):
            raise ConfigurationError("server_url must be a string")
        
        # Validate timeout
        if not isinstance(self.p.timeout, (int, float)):
            raise ConfigurationError("timeout must be a number")
        
        if self.p.timeout < 1 or self.p.timeout > 300:
            raise ConfigurationError("timeout must be between 1 and 300 seconds")
        
        # Validate max_retries
        if not isinstance(self.p.max_retries, int):
            raise ConfigurationError("max_retries must be an integer")
        
        if self.p.max_retries < 0 or self.p.max_retries > 10:
            raise ConfigurationError("max_retries must be between 0 and 10")
        
        # Validate cash
        if not isinstance(self.p.cash, (int, float)):
            raise ConfigurationError("cash must be a number")
        
        if self.p.cash < 0:
            raise ConfigurationError("cash must be non-negative")
        
        # Validate commission
        if not isinstance(self.p.commission, (int, float)):
            raise ConfigurationError("commission must be a number")
        
        if self.p.commission < 0:
            raise ConfigurationError("commission must be non-negative")
    
    def start(self) -> None:
        """
        Called by backtrader when starting.
        
        Marks the store as started. The TradingDataClient is already
        initialized in __init__, so no additional setup is needed.
        """
        if not self._started:
            self._started = True
            logger.info("DatahubStore started")
    
    def stop(self) -> None:
        """
        Called by backtrader when stopping. Cleanup resources.
        
        Closes the TradingDataClient connection and releases resources.
        Idempotent - safe to call multiple times.
        """
        if self._client is not None:
            logger.info("Stopping DatahubStore")
            try:
                self._client.close()
                logger.info("DatahubStore stopped successfully")
            except Exception as e:
                logger.error(f"Error stopping DatahubStore: {e}")
            finally:
                self._client = None
        
        self._started = False
    
    def get_client(self) -> TradingDataClient:
        """
        Get the underlying TradingDataClient instance.
        
        Returns:
            TradingDataClient instance
            
        Raises:
            RuntimeError: If client is not initialized
        """
        if self._client is None:
            raise RuntimeError("TradingDataClient not initialized")
        return self._client
    
    def getbroker(self) -> bt.brokers.BackBroker:
        """
        Factory method to get broker.
        
        Returns backtrader's default BackBroker configured with
        the store's cash and commission settings.
        
        This follows the standard store pattern where broker configuration
        is set at store initialization time.
        
        Returns:
            BackBroker: Backtrader's default simulation broker with store's settings
            
        Example:
            >>> store = DatahubStore(cash=100000, commission=0.001)
            >>> broker = store.getbroker()
            >>> cerebro.setbroker(broker)
        """
        broker = bt.brokers.BackBroker()
        broker.setcash(self.p.cash)
        broker.setcommission(commission=self.p.commission)
        logger.info(
            f"Created BackBroker: cash={self.p.cash}, commission={self.p.commission}"
        )
        return broker
    
    def getdata(self, **kwargs):
        """
        Factory method to create DatahubData feed.
        
        Creates a new DatahubData instance associated with this store.
        The feed will share the store's TradingDataClient connection.
        
        Args:
            **kwargs: Parameters for DatahubData (symbol, fromdate, todate, etc.)
                Required:
                - symbol: str - Ticker symbol
                - fromdate: datetime - Start date
                - todate: datetime - End date
                Optional:
                - timeframe: bt.TimeFrame constant (default: Days)
                - compression: int (default: 1)
            
        Returns:
            DatahubData instance configured with kwargs
            
        Raises:
            ConfigurationError: If kwargs are invalid
            
        Example:
            >>> store = DatahubStore(server_url='http://localhost:8000')
            >>> data = store.getdata(
            ...     symbol='AAPL',
            ...     fromdate=datetime(2023, 1, 1),
            ...     todate=datetime(2023, 12, 31),
            ...     timeframe=bt.TimeFrame.Days
            ... )
            >>> cerebro.adddata(data)
        """
        from .datafeed import DatahubData
        
        # Create data feed with kwargs
        data = DatahubData(**kwargs)
        
        # Associate feed with this store
        data._store = self
        
        logger.info(
            f"Created DatahubData feed: symbol={kwargs.get('symbol')}, "
            f"timeframe={kwargs.get('timeframe', 'Days')}"
        )
        
        return data
