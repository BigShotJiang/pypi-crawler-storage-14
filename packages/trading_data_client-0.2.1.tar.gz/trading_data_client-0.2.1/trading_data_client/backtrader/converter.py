"""
Data format converter for backtrader integration.

Design: .kiro/specs/backtrader-store-integration/design.md (DataConverter component)
Data Models: .kiro/specs/backtrader-store-integration/data-models.md
Interface: .kiro/specs/backtrader-store-integration/interfaces.md (DataConverter)

This module provides utilities for converting between Trading Data Server format
and backtrader format, including timestamp conversion, OHLCV field mapping, and
timeframe translation.
"""

from datetime import datetime, timezone
from typing import Dict
from dateutil import parser
import backtrader as bt

from trading_data_client.models import Bar


class DataConverter:
    """
    Utility for converting between server and backtrader formats.
    
    All methods are static, pure functions with no side effects.
    Thread-safe and deterministic.
    
    Requirements: 11.1, 11.2, 11.3, 11.5
    """
    
    # Timeframe mapping: (backtrader TimeFrame, compression) -> server string
    TIMEFRAME_MAP = {
        (bt.TimeFrame.Minutes, 1): '1m',
        (bt.TimeFrame.Minutes, 5): '5m',
        (bt.TimeFrame.Minutes, 15): '15m',
        (bt.TimeFrame.Minutes, 30): '30m',
        (bt.TimeFrame.Minutes, 60): '1h',
        (bt.TimeFrame.Minutes, 240): '4h',
        (bt.TimeFrame.Days, 1): '1d',
        (bt.TimeFrame.Weeks, 1): '1w',
        (bt.TimeFrame.Months, 1): '1mo',
    }
    
    @staticmethod
    def iso8601_to_datetime(timestamp: str) -> datetime:
        """
        Convert ISO 8601 timestamp to timezone-aware datetime.
        
        Requirement 11.1: Timestamp conversion from server format to backtrader format.
        
        Args:
            timestamp: ISO 8601 timestamp string (e.g., '2024-01-15T14:30:00Z')
        
        Returns:
            Timezone-aware datetime object in UTC
        
        Raises:
            ValueError: If timestamp is invalid format
        
        Example:
            >>> DataConverter.iso8601_to_datetime('2024-01-15T14:30:00Z')
            datetime(2024, 1, 15, 14, 30, 0, tzinfo=timezone.utc)
        """
        try:
            dt = parser.isoparse(timestamp)
            # If no timezone info, assume UTC
            if dt.tzinfo is None:
                dt = dt.replace(tzinfo=timezone.utc)
            # Convert to UTC if in different timezone
            elif dt.tzinfo != timezone.utc:
                dt = dt.astimezone(timezone.utc)
            return dt
        except (ValueError, TypeError) as e:
            raise ValueError(f"Invalid ISO 8601 timestamp '{timestamp}': {e}")
    
    @staticmethod
    def timeframe_to_server_string(timeframe: int, compression: int) -> str:
        """
        Convert backtrader timeframe to server string.
        
        Requirement 11.5: Timeframe translation between systems.
        
        Args:
            timeframe: Backtrader TimeFrame constant (e.g., bt.TimeFrame.Minutes)
            compression: Compression factor (e.g., 5 for 5-minute bars)
        
        Returns:
            Server timeframe string (e.g., '5m', '1h', '1d')
        
        Raises:
            ValueError: If timeframe/compression combination is unsupported
        
        Example:
            >>> DataConverter.timeframe_to_server_string(bt.TimeFrame.Minutes, 5)
            '5m'
            >>> DataConverter.timeframe_to_server_string(bt.TimeFrame.Days, 1)
            '1d'
        """
        key = (timeframe, compression)
        if key not in DataConverter.TIMEFRAME_MAP:
            raise ValueError(
                f"Unsupported timeframe combination: timeframe={timeframe}, "
                f"compression={compression}. Supported combinations: "
                f"{list(DataConverter.TIMEFRAME_MAP.keys())}"
            )
        return DataConverter.TIMEFRAME_MAP[key]
    
    @staticmethod
    def server_to_backtrader_bar(bar: Bar) -> Dict:
        """
        Convert server Bar to backtrader bar dict.
        
        Requirements:
        - 11.1: Timestamp conversion
        - 11.2: OHLCV field mapping
        - 11.3: Volume conversion (int to float)
        
        Args:
            bar: Bar object from trading_data_client
        
        Returns:
            Dict with backtrader format containing:
            - datetime: timezone-aware datetime object
            - open, high, low, close: float prices
            - volume: float volume
            - openinterest: float (always 0.0 for stocks/crypto)
        
        Raises:
            ValueError: If bar conversion fails
        
        Example:
            >>> bar = Bar(symbol='AAPL', timestamp=datetime(2024, 1, 15, 14, 30, 0, tzinfo=timezone.utc),
            ...           open=150.0, high=152.0, low=149.0, close=151.0, volume=1000000, timeframe='1d')
            >>> result = DataConverter.server_to_backtrader_bar(bar)
            >>> result['datetime']
            datetime(2024, 1, 15, 14, 30, 0, tzinfo=timezone.utc)
            >>> result['open']
            150.0
        """
        try:
            # Convert timestamp to datetime if it's a string
            if isinstance(bar.timestamp, str):
                dt = DataConverter.iso8601_to_datetime(bar.timestamp)
            else:
                dt = bar.timestamp
                # Ensure timezone-aware
                if dt.tzinfo is None:
                    dt = dt.replace(tzinfo=timezone.utc)
            
            return {
                'datetime': dt,
                'open': float(bar.open),
                'high': float(bar.high),
                'low': float(bar.low),
                'close': float(bar.close),
                'volume': float(bar.volume),  # Convert int to float for backtrader
                'openinterest': 0.0  # Always 0 for stocks/crypto
            }
        except (AttributeError, ValueError, TypeError) as e:
            raise ValueError(f"Failed to convert bar to backtrader format: {e}")
    
    @staticmethod
    def validate_bar(bar: Dict) -> bool:
        """
        Validate bar has required fields and valid values.
        
        Requirement 11.2: Data validation for converted bars.
        
        Args:
            bar: Bar dict to validate
        
        Returns:
            True if valid, False otherwise (does not raise exceptions)
        
        Validation Rules:
        - Has all required fields: datetime, open, high, low, close, volume
        - All prices are positive
        - high >= low
        - high >= open, close
        - low <= open, close
        - volume >= 0
        - datetime is datetime object
        
        Example:
            >>> bar = {'datetime': datetime.now(timezone.utc), 'open': 100.0, 'high': 105.0,
            ...        'low': 99.0, 'close': 102.0, 'volume': 1000.0, 'openinterest': 0.0}
            >>> DataConverter.validate_bar(bar)
            True
        """
        try:
            # Check required fields
            required_fields = ['datetime', 'open', 'high', 'low', 'close', 'volume']
            for field in required_fields:
                if field not in bar:
                    return False
            
            # Check datetime type
            if not isinstance(bar['datetime'], datetime):
                return False
            
            # Check positive prices
            if bar['open'] <= 0 or bar['high'] <= 0 or bar['low'] <= 0 or bar['close'] <= 0:
                return False
            
            # Check high/low constraints
            if bar['high'] < bar['low']:
                return False
            
            if bar['high'] < bar['open'] or bar['high'] < bar['close']:
                return False
            
            if bar['low'] > bar['open'] or bar['low'] > bar['close']:
                return False
            
            # Check non-negative volume
            if bar['volume'] < 0:
                return False
            
            return True
            
        except (KeyError, TypeError, AttributeError):
            return False
