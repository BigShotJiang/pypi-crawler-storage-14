#!/usr/bin/env python3
"""
Example: Multi-Symbol Backtest with Backtrader

This example demonstrates a pairs trading strategy using multiple symbols
with the DatahubStore integration.

Requirements:
- Trading Data Server running on http://localhost:8000
- backtrader installed: pip install backtrader
"""

import backtrader as bt
from trading_data_client.backtrader import DatahubStore
from datetime import datetime


class PairsTradingStrategy(bt.Strategy):
    """
    Pairs Trading Strategy.
    
    Trades the spread between two correlated assets (AAPL and MSFT).
    Goes long/short when spread deviates from mean, closes when it reverts.
    """
    
    params = (
        ('period', 20),        # Period for moving average
        ('entry_z', 2.0),      # Z-score threshold for entry
        ('exit_z', 0.5),       # Z-score threshold for exit
    )
    
    def __init__(self):
        # data0 is AAPL, data1 is MSFT
        self.asset1 = self.datas[0]
        self.asset2 = self.datas[1]
        
        # Calculate spread
        self.spread = self.asset1.close - self.asset2.close
        
        # Calculate spread statistics
        self.spread_sma = bt.indicators.SMA(
            self.spread,
            period=self.p.period
        )
        self.spread_std = bt.indicators.StdDev(
            self.spread,
            period=self.p.period
        )
        
        # Track positions
        self.in_position = False
    
    def log(self, txt, dt=None):
        """Logging function"""
        dt = dt or self.datas[0].datetime.date(0)
        print(f'{dt.isoformat()} {txt}')
    
    def notify_order(self, order):
        """Notification of order status"""
        if order.status in [order.Completed]:
            if order.isbuy():
                self.log(
                    f'BUY {order.data._name}: Price={order.executed.price:.2f}'
                )
            elif order.issell():
                self.log(
                    f'SELL {order.data._name}: Price={order.executed.price:.2f}'
                )
    
    def notify_trade(self, trade):
        """Notification of trade status"""
        if trade.isclosed:
            self.log(
                f'TRADE CLOSED {trade.data._name}: '
                f'PnL={trade.pnl:.2f}, PnL Net={trade.pnlcomm:.2f}'
            )
    
    def next(self):
        """Strategy logic executed for each bar"""
        # Calculate z-score
        if self.spread_std[0] == 0:
            return
        
        z_score = (self.spread[0] - self.spread_sma[0]) / self.spread_std[0]
        
        # Log current state
        self.log(
            f'Spread={self.spread[0]:.2f}, '
            f'SMA={self.spread_sma[0]:.2f}, '
            f'Z-Score={z_score:.2f}'
        )
        
        # Check if we're in a position
        pos1 = self.getposition(self.asset1)
        pos2 = self.getposition(self.asset2)
        
        if not pos1.size and not pos2.size:
            # Not in position - check for entry signals
            
            if z_score > self.p.entry_z:
                # Spread too high - short asset1, long asset2
                self.log(f'ENTRY: Short {self.asset1._name}, Long {self.asset2._name}')
                self.sell(data=self.asset1)
                self.buy(data=self.asset2)
                self.in_position = True
            
            elif z_score < -self.p.entry_z:
                # Spread too low - long asset1, short asset2
                self.log(f'ENTRY: Long {self.asset1._name}, Short {self.asset2._name}')
                self.buy(data=self.asset1)
                self.sell(data=self.asset2)
                self.in_position = True
        
        else:
            # In position - check for exit signal
            
            if abs(z_score) < self.p.exit_z:
                # Spread reverted - close positions
                self.log('EXIT: Closing positions')
                self.close(data=self.asset1)
                self.close(data=self.asset2)
                self.in_position = False


def run_backtest():
    """Run the backtest"""
    
    # Create Cerebro engine
    cerebro = bt.Cerebro()
    
    # Create store
    print("Connecting to Trading Data Server...")
    store = DatahubStore(
        server_url='http://localhost:8000',
        timeout=30,
        max_retries=3
    )
    
    # Create data feeds for multiple symbols
    symbols = ['AAPL', 'MSFT']
    
    for symbol in symbols:
        print(f"Creating data feed for {symbol}...")
        data = store.getdata(
            symbol=symbol,
            fromdate=datetime(2023, 1, 1),
            todate=datetime(2023, 12, 31),
            timeframe=bt.TimeFrame.Days
        )
        cerebro.adddata(data, name=symbol)
    
    # Add strategy
    cerebro.addstrategy(PairsTradingStrategy)
    
    # Set broker
    broker = store.getbroker()
    cerebro.setbroker(broker)
    
    # Set initial cash
    cerebro.broker.setcash(100000.0)
    
    # Set commission
    cerebro.broker.setcommission(commission=0.001)  # 0.1%
    
    # Add analyzers
    cerebro.addanalyzer(bt.analyzers.SharpeRatio, _name='sharpe')
    cerebro.addanalyzer(bt.analyzers.Returns, _name='returns')
    cerebro.addanalyzer(bt.analyzers.DrawDown, _name='drawdown')
    cerebro.addanalyzer(bt.analyzers.TradeAnalyzer, _name='trades')
    
    # Print starting conditions
    print('\n' + '='*60)
    print('Starting Portfolio Value: ${:.2f}'.format(cerebro.broker.getvalue()))
    print('='*60 + '\n')
    
    # Run backtest
    results = cerebro.run()
    
    # Print ending conditions
    print('\n' + '='*60)
    print('Final Portfolio Value: ${:.2f}'.format(cerebro.broker.getvalue()))
    print('='*60 + '\n')
    
    # Print analysis
    strat = results[0]
    
    print('Performance Metrics:')
    print('-' * 60)
    
    # Sharpe Ratio
    sharpe = strat.analyzers.sharpe.get_analysis()
    sharpe_ratio = sharpe.get('sharperatio', 0)
    if sharpe_ratio:
        print(f'Sharpe Ratio: {sharpe_ratio:.2f}')
    else:
        print('Sharpe Ratio: N/A')
    
    # Returns
    returns = strat.analyzers.returns.get_analysis()
    print(f'Total Return: {returns["rtot"]:.2%}')
    print(f'Average Return: {returns["ravg"]:.2%}')
    
    # Drawdown
    drawdown = strat.analyzers.drawdown.get_analysis()
    print(f'Max Drawdown: {drawdown["max"]["drawdown"]:.2%}')
    print(f'Max Drawdown Period: {drawdown["max"]["len"]} days')
    
    # Trades
    trades = strat.analyzers.trades.get_analysis()
    print(f'\nTotal Trades: {trades.total.closed}')
    print(f'Winning Trades: {trades.won.total}')
    print(f'Losing Trades: {trades.lost.total}')
    if trades.total.closed > 0:
        win_rate = trades.won.total / trades.total.closed * 100
        print(f'Win Rate: {win_rate:.1f}%')
    
    print('='*60 + '\n')
    
    # Plot results
    print("Generating plot...")
    cerebro.plot(style='candlestick')


if __name__ == '__main__':
    run_backtest()
