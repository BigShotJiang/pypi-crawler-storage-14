#!/usr/bin/env python3
"""
Example: Multi-Timeframe Backtest with Backtrader

This example demonstrates a multi-timeframe strategy that uses
daily data for trend and hourly data for entry timing.

Requirements:
- Trading Data Server running on http://localhost:8000
- backtrader installed: pip install backtrader
"""

import backtrader as bt
from trading_data_client.backtrader import DatahubStore
from datetime import datetime


class MultiTimeframeStrategy(bt.Strategy):
    """
    Multi-Timeframe Strategy.
    
    Uses daily SMA for trend direction and hourly RSI for entry timing.
    Only takes trades in direction of daily trend.
    """
    
    params = (
        ('daily_sma_period', 50),
        ('hourly_rsi_period', 14),
        ('rsi_low', 30),
        ('rsi_high', 70),
    )
    
    def __init__(self):
        # data0 is daily, data1 is hourly
        self.daily_data = self.datas[0]
        self.hourly_data = self.datas[1]
        
        # Daily trend indicator
        self.daily_sma = bt.indicators.SMA(
            self.daily_data.close,
            period=self.p.daily_sma_period
        )
        
        # Hourly timing indicator
        self.hourly_rsi = bt.indicators.RSI(
            self.hourly_data.close,
            period=self.p.hourly_rsi_period
        )
    
    def log(self, txt, dt=None):
        """Logging function"""
        dt = dt or self.datas[0].datetime.date(0)
        print(f'{dt.isoformat()} {txt}')
    
    def notify_order(self, order):
        """Notification of order status"""
        if order.status in [order.Completed]:
            if order.isbuy():
                self.log(
                    f'BUY EXECUTED, Price: {order.executed.price:.2f}, '
                    f'Cost: {order.executed.value:.2f}'
                )
            elif order.issell():
                self.log(
                    f'SELL EXECUTED, Price: {order.executed.price:.2f}, '
                    f'Cost: {order.executed.value:.2f}'
                )
    
    def notify_trade(self, trade):
        """Notification of trade status"""
        if trade.isclosed:
            self.log(f'TRADE PROFIT: {trade.pnlcomm:.2f}')
    
    def next(self):
        """Strategy logic executed for each bar"""
        # Get current values
        daily_close = self.daily_data.close[0]
        daily_sma = self.daily_sma[0]
        hourly_rsi = self.hourly_rsi[0]
        
        # Log current state
        self.log(
            f'Daily Close={daily_close:.2f}, '
            f'Daily SMA={daily_sma:.2f}, '
            f'Hourly RSI={hourly_rsi:.2f}'
        )
        
        # Determine trend
        uptrend = daily_close > daily_sma
        downtrend = daily_close < daily_sma
        
        # Check if we have a position
        if not self.position:
            # Not in market - look for entry
            
            if uptrend and hourly_rsi < self.p.rsi_low:
                # Uptrend + oversold on hourly = buy
                self.log(f'BUY SIGNAL: Uptrend + RSI oversold ({hourly_rsi:.2f})')
                self.buy(data=self.hourly_data)
            
            elif downtrend and hourly_rsi > self.p.rsi_high:
                # Downtrend + overbought on hourly = sell
                self.log(f'SELL SIGNAL: Downtrend + RSI overbought ({hourly_rsi:.2f})')
                self.sell(data=self.hourly_data)
        
        else:
            # In market - look for exit
            
            if self.position.size > 0:
                # Long position
                if hourly_rsi > self.p.rsi_high or not uptrend:
                    self.log(f'EXIT LONG: RSI={hourly_rsi:.2f}, Uptrend={uptrend}')
                    self.close(data=self.hourly_data)
            
            elif self.position.size < 0:
                # Short position
                if hourly_rsi < self.p.rsi_low or not downtrend:
                    self.log(f'EXIT SHORT: RSI={hourly_rsi:.2f}, Downtrend={downtrend}')
                    self.close(data=self.hourly_data)


def run_backtest():
    """Run the backtest"""
    
    # Create Cerebro engine
    cerebro = bt.Cerebro()
    
    # Create store
    print("Connecting to Trading Data Server...")
    store = DatahubStore(
        server_url='http://localhost:8000',
        timeout=30,
        max_retries=3
    )
    
    # Create daily data feed
    print("Creating daily data feed for AAPL...")
    data_daily = store.getdata(
        symbol='AAPL',
        fromdate=datetime(2023, 1, 1),
        todate=datetime(2023, 12, 31),
        timeframe=bt.TimeFrame.Days
    )
    cerebro.adddata(data_daily, name='AAPL-Daily')
    
    # Create hourly data feed
    print("Creating hourly data feed for AAPL...")
    data_hourly = store.getdata(
        symbol='AAPL',
        fromdate=datetime(2023, 1, 1),
        todate=datetime(2023, 12, 31),
        timeframe=bt.TimeFrame.Minutes,
        compression=60  # 60 minutes = 1 hour
    )
    cerebro.adddata(data_hourly, name='AAPL-Hourly')
    
    # Add strategy
    cerebro.addstrategy(MultiTimeframeStrategy)
    
    # Set broker
    broker = store.getbroker()
    cerebro.setbroker(broker)
    
    # Set initial cash
    cerebro.broker.setcash(100000.0)
    
    # Set commission
    cerebro.broker.setcommission(commission=0.001)  # 0.1%
    
    # Add analyzers
    cerebro.addanalyzer(bt.analyzers.SharpeRatio, _name='sharpe')
    cerebro.addanalyzer(bt.analyzers.Returns, _name='returns')
    cerebro.addanalyzer(bt.analyzers.DrawDown, _name='drawdown')
    cerebro.addanalyzer(bt.analyzers.TradeAnalyzer, _name='trades')
    
    # Print starting conditions
    print('\n' + '='*60)
    print('Starting Portfolio Value: ${:.2f}'.format(cerebro.broker.getvalue()))
    print('='*60 + '\n')
    
    # Run backtest
    results = cerebro.run()
    
    # Print ending conditions
    print('\n' + '='*60)
    print('Final Portfolio Value: ${:.2f}'.format(cerebro.broker.getvalue()))
    print('='*60 + '\n')
    
    # Print analysis
    strat = results[0]
    
    print('Performance Metrics:')
    print('-' * 60)
    
    # Sharpe Ratio
    sharpe = strat.analyzers.sharpe.get_analysis()
    sharpe_ratio = sharpe.get('sharperatio', 0)
    if sharpe_ratio:
        print(f'Sharpe Ratio: {sharpe_ratio:.2f}')
    else:
        print('Sharpe Ratio: N/A')
    
    # Returns
    returns = strat.analyzers.returns.get_analysis()
    print(f'Total Return: {returns["rtot"]:.2%}')
    print(f'Average Return: {returns["ravg"]:.2%}')
    
    # Drawdown
    drawdown = strat.analyzers.drawdown.get_analysis()
    print(f'Max Drawdown: {drawdown["max"]["drawdown"]:.2%}')
    print(f'Max Drawdown Period: {drawdown["max"]["len"]} bars')
    
    # Trades
    trades = strat.analyzers.trades.get_analysis()
    print(f'\nTotal Trades: {trades.total.closed}')
    print(f'Winning Trades: {trades.won.total}')
    print(f'Losing Trades: {trades.lost.total}')
    if trades.total.closed > 0:
        win_rate = trades.won.total / trades.total.closed * 100
        print(f'Win Rate: {win_rate:.1f}%')
    
    print('='*60 + '\n')
    
    # Plot results
    print("Generating plot...")
    cerebro.plot(style='candlestick')


if __name__ == '__main__':
    run_backtest()
