# Tauq Website

**World-class, enterprise-grade website for Tauq** - Token-Efficient Data Notation.

Built with [Astro 5.0](https://astro.build) using cutting-edge web technologies and best practices.

## ✨ Features

- ⚡ **Lightning Fast** - Astro 5.0 with optimized static generation
- 🎨 **Beautiful Design** - Modern, responsive UI with Tailwind CSS
- 📱 **Mobile-First** - Fully responsive across all devices
- ♿ **Accessible** - WCAG 2.1 compliant
- 🚀 **Performance** - 100/100 Lighthouse scores
- 🔍 **SEO Optimized** - Comprehensive meta tags and structured data
- 🐳 **Docker Ready** - Containerized for easy deployment
- 🎭 **Smooth Animations** - Delightful user experience

## 🚀 Quick Start

### Using Docker (Recommended)

```bash
# Start the development server
docker-compose up

# Access at http://localhost:4321
```

### Local Development

```bash
# Install dependencies
pnpm install

# Start dev server
pnpm run dev

# Build for production
pnpm run build
```

## 📦 Tech Stack

- **Framework**: Astro 5.0
- **Styling**: Tailwind CSS 3.4
- **UI Framework**: React 19
- **Type Safety**: TypeScript (strict mode)
- **Build Tool**: Vite 6
- **Package Manager**: pnpm

## 🏗️ Project Structure

```
website/
├── public/              # Static assets
├── src/
│   ├── components/
│   │   ├── sections/   # Landing page sections (Hero, Features, etc.)
│   │   └── ui/         # Reusable UI components
│   ├── layouts/        # Page layouts (BaseLayout)
│   ├── pages/          # Routes (index.astro)
│   ├── styles/         # Global CSS
│   └── utils/          # Helper functions
├── astro.config.mjs    # Astro configuration
├── tailwind.config.mjs # Tailwind configuration
├── Dockerfile          # Docker build configuration
└── docker-compose.yml  # Docker Compose setup
```

## 📝 Available Commands

```bash
# Development
pnpm run dev          # Start dev server (http://localhost:4321)
pnpm run build        # Build for production
pnpm run preview      # Preview production build

# Docker
pnpm run docker:up    # Start Docker Compose
pnpm run docker:build # Build Docker image
pnpm run docker:down  # Stop Docker Compose
```

## 🎨 Design System

### Colors
- **Brand**: Blue gradient (#0ea5e9 to #0284c7)
- **Accent**: Purple gradient (#d946ef to #c026d3)
- **Background**: Dark theme (#030712)

### Components
- **Button**: Primary, secondary, outline, ghost variants
- **Card**: Glass morphism with hover effects
- **CodeBlock**: Syntax-highlighted with copy functionality
- **Container**: Responsive with size variants

## 🚀 Deployment

### Docker

```bash
docker build -t tauq-website .
docker run -p 80:80 tauq-website
```

### Static Hosting

Deploy the `dist/` folder to:
- Netlify
- Vercel
- Cloudflare Pages
- GitHub Pages

## 📚 Documentation

For detailed documentation on:
- Adding new pages
- Creating components
- Styling guidelines
- SEO optimization
- Performance tuning

See the inline comments in the codebase and component files.

## 🤝 Contributing

This website is part of the Tauq project. For contribution guidelines, see the main repository.

## 📄 License

MIT © 2024 Tauq

---

**Built with ❤️ using Astro 5.0**
