from enum import Enum


class MethodMode(Enum):
    SCALAR = "scalar"
    POLYNOMIAL_FIT = "polynomial fit"
