from enum import Enum


class DatasetScope(Enum):
    LOCAL = "local"
    GLOBAL = "global"
