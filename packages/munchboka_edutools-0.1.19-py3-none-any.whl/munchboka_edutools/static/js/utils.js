// Placeholder JS to verify asset registration
window.munchbokaEdutools = window.munchbokaEdutools || {};
console.debug("munchboka-edutools: utils.js loaded");
