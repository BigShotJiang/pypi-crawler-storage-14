# ARSC
To calculate ARSC values from amino acid fasta files.
