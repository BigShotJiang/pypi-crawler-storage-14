# Cambrian Non-Commercial License Agreement

This project is licensed under the EvolutionaryScale Cambrian Non-Commercial License Agreement.
See: https://www.evolutionaryscale.ai/policies/cambrian-non-commercial-license-agreement
