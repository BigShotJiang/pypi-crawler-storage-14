---
post_title: "W2T Body Kinematics Pipeline (Design Phase)"
author1: "Project Team"
post_slug: "readme-w2t-bkin"
microsoft_alias: "na"
featured_image: "/assets/og.png"
categories: ["pipeline", "docs"]
tags: ["overview", "design", "nwb"]
ai_note: "Draft produced with AI assistance and reviewed by maintainers."
summary: "Overview, goals, architecture, development workflow, and roadmap for the modular W2T body kinematics pipeline."
post_date: "2025-11-08"
---
