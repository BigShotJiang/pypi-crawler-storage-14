"""Entry point for the ZK Documentation MCP Server."""

from .server import main

if __name__ == "__main__":
    main()
