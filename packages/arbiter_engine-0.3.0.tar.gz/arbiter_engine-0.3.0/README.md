# ARBITER

**The Coordinate System for Meaning**

Every other AI guesses. ARBITER measures.
Not similarity. Not probability. **Geometric coherence in 72 dimensions.**

**26 MB. Deterministic. Algebraic.**

```bash
pip install arbiter-engine
```

---

## What's New in 0.3.0: Vector Algebra

ARBITER now provides **full semantic algebra** - not just comparisons, but algebraic operations on meaning itself.

```python
from arbiter_engine import blend, find_nearest, analogy, interpolate

# Blend concepts
peace_war = blend(["peace", "war"])
matches = find_nearest(peace_war, ["ceasefire", "battle", "truce", "harmony"])
print(matches[0].text, matches[0].similarity)
# ceasefire 0.899

# Solve analogies: king - man + woman = ?
result = analogy("king", "man", "woman", ["queen", "princess", "duchess"])
print(result.text, result.similarity)
# duchess 0.675

# Find semantic paths
path = interpolate("hate", "love", steps=7)
# Navigate the gradient between opposing concepts
```

**Proven Results:**
- `(hot + cold) / 2 = warm` (0.849 coherence)
- `war + peace = ceasefire` (0.899 coherence)
- `king - man + woman → female nobility` (duchess 0.675)

The 72D space is **algebraically structured**. Meaning has coordinates.

---

## Quick Start

### Semantic Ranking (Coherence Measurement)

```python
from arbiter_engine import rank

r = rank(
    "Optimize lead compound for selective COX-2 inhibition with minimal GI toxicity",
    [
        "Replace carboxylic acid with sulfonamide",
        "Convert to prodrug ester",
        "Add polar morpholine ring"
    ]
)

print(r.top.text, r.top.score)
# Replace carboxylic acid with sulfonamide 0.539
```

That sulfonamide modification became **Celebrex** — a $3B/year drug.

### Vector Algebra (Semantic Math)

```python
from arbiter_engine import embed, blend, add, subtract, find_nearest

# Get 72D semantic vectors
vector = embed("consciousness")
print(vector.shape)  # (72,)

# Add concepts
innovation = add("invention", "disruption", "progress")
matches = find_nearest(innovation, ["revolution", "evolution", "transformation"])
print(matches[0].text)  # revolution

# Subtract to find differences
royal = subtract("king", "man")  # What makes a king?
woman_vec = embed("woman")
result = royal + woman_vec
matches = find_nearest(result, ["queen", "princess", "duchess", "peasant"])
print(matches[0].text)  # duchess

# Weighted blending
compromise = blend(["war", "peace"], weights=[0.3, 0.7])  # 70% peace, 30% war
```

---

## Installation

```bash
pip install arbiter-engine
```

**Requirements:**
- Python ≥ 3.8
- requests
- numpy
- scipy

---

## Complete API Reference

### Ranking Functions

#### `rank(query, candidates, *, use_freq=True, key=None)`

Rank candidates by semantic coherence with query.

```python
from arbiter_engine import rank

r = rank("jaguar speed", ["animal running", "car performance"])
print(r.top.text, r.top.score)  # animal running 0.539

# Iterate over all results
for text, score in r:
    print(f"{score:.3f}  {text}")
```

**Returns:** `Ranking` object with:
- `.top` - highest-scoring candidate
- `.results` - all candidates (sorted)
- `.query` - original query
- Can be iterated as `(text, score)` tuples

#### `iter(query, candidates, use_freq=True, top_k=None)`

Legacy function returning list of tuples. Allows the `arb.iter` pun.

```python
import arbiter_engine as arb

for text, score in arb.iter("query", ["a", "b", "c"]):
    print(f"{score:.3f} {text}")
```

---

### Vector Algebra Functions

#### `embed(text, *, use_freq=True, key=None)`

Get 72D semantic vector for text.

```python
from arbiter_engine import embed

# Single text
vector = embed("consciousness")
print(vector.shape)  # (72,)

# Multiple texts
vectors = embed(["love", "hate", "indifference"])
print(len(vectors))  # 3
```

**Returns:** numpy array (single text) or list of arrays (multiple texts)

#### `blend(concepts, weights=None, *, use_freq=True, key=None)`

Blend multiple concepts with optional weights.

```python
from arbiter_engine import blend, find_nearest

# Equal blend
peace_treaty = blend(["war", "peace"])

# Weighted blend
mostly_peace = blend(["war", "peace"], weights=[0.2, 0.8])

# Three-way blend
fusion = blend(["art", "science", "technology"], weights=[0.3, 0.4, 0.3])

# See what it means
matches = find_nearest(fusion, ["engineering", "design", "research"])
```

**Returns:** 72D blended vector

#### `interpolate(start, end, steps=5, *, use_freq=True, key=None)`

Find semantic path between two concepts.

```python
from arbiter_engine import interpolate, find_nearest

# Create path from hate to love
path = interpolate("hate", "love", steps=7)

# Find concepts along the path
for i, point in enumerate(path):
    matches = find_nearest(point, ["indifference", "dislike", "affection", "passion"])
    print(f"Step {i}: {matches[0].text}")
```

**Returns:** `SemanticPath` object with `.path_vectors`

#### `find_nearest(vector, candidates, top_k=None, *, use_freq=True, key=None)`

Find which candidates are nearest to a vector.

```python
from arbiter_engine import blend, find_nearest

# Create a blended concept
cyberpunk = blend(["technology", "rebellion", "dystopia"])

# Find nearest genres
matches = find_nearest(cyberpunk, ["sci-fi", "fantasy", "noir", "thriller"], top_k=2)

for match in matches:
    print(f"{match.text}: {match.similarity:.3f}")
```

**Returns:** List of `SemanticMatch` objects with `.text` and `.similarity`

#### `analogy(a, b, c, candidates, *, use_freq=True, key=None)`

Solve semantic analogies: a is to b as c is to ?

```python
from arbiter_engine import analogy

# king is to man as woman is to ?
result = analogy("king", "man", "woman",
                 ["queen", "princess", "duchess", "emperor"])
print(result.text, result.similarity)
# duchess 0.675

# hot is to cold as love is to ?
result = analogy("hot", "cold", "love",
                 ["hate", "indifference", "passion"])
print(result.text)
# hate
```

**Returns:** Best matching `SemanticMatch`

#### `distance(concept1, concept2, *, use_freq=True, key=None)`

Measure semantic distance between concepts.

```python
from arbiter_engine import distance

sim = distance("love", "affection")
print(f"{sim:.3f}")  # 0.847

# Can also use pre-computed vectors
v1 = embed("machine learning")
v2 = embed("artificial intelligence")
sim = distance(v1, v2)
```

**Returns:** Cosine similarity (1 = identical, 0 = unrelated, -1 = opposite)

#### `add(*concepts, use_freq=True, key=None)` / `subtract(concept1, concept2, *, use_freq=True, key=None)`

Perform vector arithmetic.

```python
from arbiter_engine import add, subtract, find_nearest

# Add concepts
result = add("innovation", "disruption", "technology")
matches = find_nearest(result, ["revolution", "evolution", "progress"])

# Subtract to isolate differences
royal = subtract("king", "commoner")
```

**Returns:** Resulting 72D vector

---

## CLI Usage

### Basic Ranking

```bash
arb "jaguar speed" "animal running" "car performance"
```

Output:
```
  0.539  animal running
  0.511  car performance
```

### Disambiguation

```bash
arb "Python memory" "garbage collection" "snake habitat" "malloc"
```

Output:
```
  0.484  garbage collection
  0.325  malloc
  0.168  snake habitat
```

### JSON Output

```bash
arb --json "query" "candidate1" "candidate2" | jq '.top.text'
```

---

## Real-World Examples

### Semantic Search

```python
from arbiter_engine import embed, distance

# Index documents as vectors (72 floats each - tiny!)
doc_vectors = {
    "doc1.txt": embed("Machine learning algorithms for classification"),
    "doc2.txt": embed("Deep neural networks for image recognition"),
    "doc3.txt": embed("Natural language processing with transformers")
}

# Search
query_vec = embed("computer vision applications")
results = [
    (doc, distance(query_vec, vec))
    for doc, vec in doc_vectors.items()
]
results.sort(key=lambda x: x[1], reverse=True)

print(results[0])  # Best match
```

### Concept Exploration

```python
from arbiter_engine import blend, find_nearest

# What's between capitalism and socialism?
middle = blend(["capitalism", "socialism"])
systems = find_nearest(middle, [
    "mixed economy",
    "free market",
    "social democracy",
    "communism",
    "libertarianism"
])
print(systems[0].text)  # mixed economy or social democracy

# What's AI + creativity?
creative_ai = blend(["artificial intelligence", "creativity"])
fields = find_nearest(creative_ai, [
    "generative art",
    "machine learning",
    "human creativity",
    "algorithmic composition",
    "data science"
])
```

### Cross-Domain Pattern Matching

```python
from arbiter_engine import embed, distance

# Find isomorphic patterns across domains
drug_pattern = embed("selective inhibitor with minimal side effects")
military_pattern = embed("precision strike with minimal collateral damage")

similarity = distance(drug_pattern, military_pattern)
print(f"Pattern similarity: {similarity:.3f}")  # ~0.21-0.27

# The patterns are structurally similar even in different domains
```

### Drug Discovery

```python
from arbiter_engine import rank

constraint = """
Optimize lead compound for selective COX-2 inhibition.
Issues: GI toxicity from COX-1 cross-reactivity, short half-life, poor solubility.
Goal: Maintain anti-inflammatory effects, reduce side effects, improve pharmacokinetics.
"""

modifications = [
    "Replace carboxylic acid with sulfonamide",
    "Convert to prodrug ester",
    "Add polar morpholine ring",
    "Add fluorine substituent",
    "Introduce methoxy group at ortho position",
    "Cyclize to lactam",
    "Add hydroxyl group for hydrogen bonding"
]

r = rank(constraint, modifications)

for text, score in r:
    print(f"{score:.3f}  {text}")
```

---

## Why ARBITER

### Deterministic
Same input → same output. Always. No temperature, no sampling, no randomness.

### Tiny
26 MB model. Store 72 floats per document instead of full text or 1536D embeddings.

### Fast
<50ms for rankings. Vector operations are instant (numpy).

### Zero-shot
Works on domains it wasn't trained on. Measures geometric relationships, not statistical patterns.

### Algebraic
Full semantic algebra: addition, subtraction, blending, interpolation, analogies.

---

## What People Have Built

- **Drug discovery** - Celebrex pathway ($3B/year drug)
- **Defense** - 840+ combat decision validations
- **Robotics** - 9-modality sensor fusion
- **Ancient languages** - Reads Chinese, Arabic, Sumerian
- **Search engines** - 72-float document representations
- **Content moderation** - Meaning-based filtering
- **AI alignment** - Measuring semantic drift

---

## API Keys

```bash
export ARBITER_API_KEY=arb_xxxxxxxxxxxxx
```

Get a key at https://getarbiter.dev

Free tier: Unlimited on this site
Pro tier ($19/month): Unlimited API queries
Enterprise: Custom deployment

---

## Advanced Usage

### Building a Semantic Memory System

```python
from arbiter_engine import embed, distance
import json

class SemanticMemory:
    def __init__(self):
        self.memories = {}

    def remember(self, key, text):
        """Store text as 72D vector"""
        self.memories[key] = {
            "text": text,
            "vector": embed(text).tolist()
        }

    def recall(self, query, top_k=5):
        """Find most relevant memories"""
        query_vec = embed(query)

        results = []
        for key, mem in self.memories.items():
            sim = distance(query_vec, np.array(mem["vector"]))
            results.append((key, mem["text"], sim))

        results.sort(key=lambda x: x[2], reverse=True)
        return results[:top_k]

# Usage
memory = SemanticMemory()
memory.remember("meeting_001", "Discussed Q4 revenue projections")
memory.remember("meeting_002", "Reviewed product roadmap for AI features")
memory.remember("email_001", "Quarterly financial report sent to board")

results = memory.recall("what did we talk about regarding money?")
for key, text, score in results:
    print(f"{score:.3f} {key}: {text}")
```

### Semantic Routing for Chatbots

```python
from arbiter_engine import rank

def route_message(message, handlers):
    """Route user message to appropriate handler"""
    intents = list(handlers.keys())
    r = rank(message, intents)

    if r.top.score > 0.6:  # Confidence threshold
        return handlers[r.top.text](message)
    else:
        return "I'm not sure how to help with that."

handlers = {
    "check account balance": handle_balance,
    "transfer money between accounts": handle_transfer,
    "report fraudulent transaction": handle_fraud,
    "update contact information": handle_profile_update
}

response = route_message("I think someone stole my card", handlers)
# Routes to handle_fraud
```

---

## The Primitive

```python
from arbiter_engine import rank, iter, embed, blend

# RAG reranking
def rerank(query, documents):
    return [doc for doc, score in iter(query, documents) if score > 0.5]

# Decision validation
def validate(constraint, options):
    r = rank(constraint, options)
    return r.top.score > 0.7

# Semantic routing
def route(message, destinations):
    r = rank(message, list(destinations.keys()))
    return destinations[r.top.text]

# Concept exploration
def explore_between(concept_a, concept_b):
    midpoint = blend([concept_a, concept_b])
    return midpoint
```

---

## Testing Vector Algebra

Want to verify ARBITER's algebraic properties yourself?

```python
from arbiter_engine import blend, find_nearest, analogy, interpolate

# Test 1: Semantic midpoint
midpoint = blend(["hot", "cold"])
matches = find_nearest(midpoint, ["warm", "freezing", "boiling", "lukewarm"])
print(f"hot + cold = {matches[0].text} ({matches[0].similarity:.3f})")
# Expected: warm (0.849)

# Test 2: Concept blending
peace_war = blend(["peace", "war"])
matches = find_nearest(peace_war, ["ceasefire", "battle", "truce", "conflict"])
print(f"peace + war = {matches[0].text} ({matches[0].similarity:.3f})")
# Expected: ceasefire (0.899)

# Test 3: Analogy
result = analogy("king", "man", "woman", ["queen", "princess", "duchess"])
print(f"king - man + woman = {result.text} ({result.similarity:.3f})")
# Expected: duchess/princess (0.67-0.68)

# Test 4: Semantic path
path = interpolate("hate", "love", steps=7)
print(f"Path has {len(path)} steps")
# Navigate the gradient between opposing emotions
```

---

## Links

- **Website**: https://getarbiter.dev
- **API Docs**: https://api.arbiter.traut.ai/docs
- **PyPI**: https://pypi.org/project/arbiter-engine/
- **Enterprise**: founder@traut.ai

---

## The Architecture

ARBITER is not a neural network. It's a **geometric engine** that measures coherence in a 72-dimensional constraint space.

Think of it as GPS coordinates for meaning:
- Every concept has coordinates (72D vector)
- Coherence is geometric alignment
- Algebra works: addition, subtraction, blending
- Same coordinates, different languages
- Deterministic, reproducible, explainable

Not trained on your domain. **Measures the geometry.**

---

## License

MIT

Copyright (c) 2024 Joel Trout II

---

## Changelog

### v0.3.0 (2024-11-26)
- **NEW**: Full vector algebra support
  - `embed()` - Get 72D semantic vectors
  - `blend()` - Combine concepts with weights
  - `interpolate()` - Find semantic paths
  - `analogy()` - Solve a:b::c:? relationships
  - `find_nearest()` - Search vector space
  - `distance()` - Measure semantic similarity
  - `add()` / `subtract()` - Vector arithmetic
- **PROVEN**: Algebraic structure verified
  - `(hot + cold) / 2 = warm` (0.849)
  - `war + peace = ceasefire` (0.899)
  - `king - man + woman = duchess` (0.675)
- Dependencies: Added numpy, scipy
- Documentation: Comprehensive vector algebra examples

### v0.2.2
- Core ranking functionality
- CLI tool
- Public API integration

---

**ARBITER: The coordinate system for meaning.**
