__version__ = "0.3.8"

from .config import global_config  # noqa
import hololinked.core  # noqa: F401
