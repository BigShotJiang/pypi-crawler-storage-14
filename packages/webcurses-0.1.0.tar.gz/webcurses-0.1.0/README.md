# webcurses

A drop-in replacement for the Python `curses` library that renders to a web browser.

## Usage

```python
import webcurses
from webcurses import wrapper

def main(stdscr):
    stdscr.clear()
    stdscr.addstr(0, 0, "Hello, Webcurses!")
    stdscr.refresh()
    stdscr.getch()

wrapper(main)
```

## Running

By default, `webcurses` starts a web server on port 8080.

1. Run your script:
   ```bash
   python your_script.py
   ```
2. Open your browser to [http://localhost:8080](http://localhost:8080).

### Configuration

To change the port, set the `WEBCURSES_PORT` environment variable:

```bash
export WEBCURSES_PORT=9090
python your_script.py
```

Then navigate to [http://localhost:9090](http://localhost:9090).
