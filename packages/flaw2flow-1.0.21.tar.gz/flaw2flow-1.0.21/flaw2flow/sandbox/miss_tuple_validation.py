def foo(t: tuple) -> tuple:
    """MUST FAIL — missing validation."""
    return t
