from __future__ import annotations

import logging

generalLogger = logging.getLogger("vdata")
