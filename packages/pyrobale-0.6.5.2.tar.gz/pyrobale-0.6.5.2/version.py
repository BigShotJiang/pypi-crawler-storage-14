stable = True
version = "0.6.5.2"
