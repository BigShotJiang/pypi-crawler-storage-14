"""Main entry point for the lazy-log package."""

from lazy_log.cli import main

if __name__ == "__main__":
    raise SystemExit(main())
