"""Background notifier that surfaces spaced reminders via system notifications."""

from __future__ import annotations

import os
import random
import shutil
import subprocess
import threading
import time
from dataclasses import dataclass
from typing import Any, Dict, Iterable, List, Optional, Sequence

from source.core.utils import (
    get_notification_settings,
    lowest_score_items,
    resolve_data_path,
)
from source.module.kanji import KanjiRow, load_kanji
from source.module.vocab import VocabRow, load_vocab

NotificationSettings = Dict[str, Any]

_NOTIFICATION_THREAD: Optional[threading.Thread] = None
_STOP_EVENT = threading.Event()


@dataclass
class NotificationPayload:
    """Bundle describing what will be sent to the OS notifier."""

    title: str
    body: str


class NotificationBackend:
    """Lightweight interface for pluggable notification senders."""

    name = "console"

    def available(self) -> bool:  # pragma: no cover - simple boolean helper
        return True

    def send(self, payload: NotificationPayload, settings: NotificationSettings) -> bool:  # pragma: no cover - implemented by subclasses
        raise NotImplementedError


class TermuxNotificationBackend(NotificationBackend):
    """Dispatch notifications via ``termux-notification`` when available."""

    name = "termux"

    def __init__(self) -> None:
        self._binary = shutil.which("termux-notification")

    def available(self) -> bool:
        return bool(self._binary)

    def send(self, payload: NotificationPayload, settings: NotificationSettings) -> bool:
        if not self._binary:
            return False
        cmd: List[str] = [
            self._binary,
            "--title",
            payload.title,
            "--content",
            payload.body,
            "--priority",
            "high",
            "--id",
            "practicejapanese-reminder",
        ]
        if settings.get("termux_sound"):
            cmd.append("--sound")
        vibrate = str(settings.get("termux_vibrate_pattern") or "").strip()
        if vibrate:
            cmd.extend(["--vibrate", vibrate])
        extra_args = settings.get("termux_extra_args")
        if isinstance(extra_args, Iterable) and not isinstance(extra_args, (str, bytes)):
            cmd.extend(str(arg) for arg in extra_args if arg)
        try:
            subprocess.run(
                cmd,
                check=True,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
            return True
        except (subprocess.SubprocessError, OSError):
            return False


class NotifySendBackend(NotificationBackend):
    """Dispatch notifications via ``notify-send`` on Linux desktops."""

    name = "notify-send"

    def __init__(self) -> None:
        self._binary = shutil.which("notify-send")

    def available(self) -> bool:
        return bool(self._binary)

    def send(self, payload: NotificationPayload, settings: NotificationSettings) -> bool:
        if not self._binary:
            return False
        urgency = str(settings.get("notify_send_urgency") or "normal")
        cmd = [
            self._binary,
            f"--urgency={urgency}",
            "--expire-time=15000",
            payload.title,
            payload.body,
        ]
        try:
            subprocess.run(
                cmd,
                check=True,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
            return True
        except (subprocess.SubprocessError, OSError):
            return False


class ConsoleBackend(NotificationBackend):
    """Fallback backend that simply prints to the console."""

    name = "console"

    def send(self, payload: NotificationPayload, settings: NotificationSettings) -> bool:
        timestamp = time.strftime("%H:%M:%S")
        sanitized_body = payload.body.replace(os.linesep, " | ")
        print(f"[Reminder {timestamp}] {payload.title}: {sanitized_body}")
        return True


def start_notification_scheduler() -> None:
    """Start the notification worker thread if enabled in config."""

    settings = get_notification_settings()
    if not settings.get("enabled", False):
        return
    if not settings.get("include_vocab", True) and not settings.get("include_kanji", True):
        return

    global _NOTIFICATION_THREAD
    if _NOTIFICATION_THREAD and _NOTIFICATION_THREAD.is_alive():
        return

    _STOP_EVENT.clear()
    _NOTIFICATION_THREAD = threading.Thread(
        target=_notification_loop,
        args=(settings,),
        daemon=True,
        name="PjNotificationScheduler",
    )
    _NOTIFICATION_THREAD.start()


def stop_notification_scheduler() -> None:
    """Signal the background worker to exit (best-effort)."""

    _STOP_EVENT.set()


def _notification_loop(settings: NotificationSettings) -> None:
    backend = _select_backend(settings)
    if backend is None:
        return

    delay = max(30, int(settings.get("initial_delay_seconds", 600)))
    increment = max(10, int(settings.get("delay_increment_seconds", 300)))
    max_delay = max(delay, int(settings.get("max_delay_seconds", delay)))

    include_vocab = bool(settings.get("include_vocab", True))
    include_kanji = bool(settings.get("include_kanji", True))

    while not _STOP_EVENT.wait(delay):
        payload = _build_payload(include_vocab, include_kanji, settings)
        if payload and backend.send(payload, settings):
            delay = min(max_delay, delay + increment)
            continue
        # Either payload generation failed or backend rejected it; retry sooner.
        delay = min(max_delay, max(30, delay // 2))


def _select_backend(settings: NotificationSettings) -> Optional[NotificationBackend]:
    """Return the first available backend respecting user preferences."""

    backends: List[NotificationBackend] = [TermuxNotificationBackend(), NotifySendBackend()]
    if settings.get("allow_console_fallback", True):
        backends.append(ConsoleBackend())
    for backend in backends:
        if backend.available():
            return backend
    return None


def _build_payload(
    include_vocab: bool,
    include_kanji: bool,
    settings: NotificationSettings,
) -> Optional[NotificationPayload]:
    sections: List[str] = []
    if include_vocab:
        vocab_section = _format_vocab_entry()
        if vocab_section:
            sections.append(f"Vocab: {vocab_section}")
    if include_kanji:
        kanji_section = _format_kanji_entry()
        if kanji_section:
            sections.append(f"Kanji: {kanji_section}")

    if not sections:
        return None

    body = os.linesep.join(sections)
    max_chars = max(60, int(settings.get("max_message_chars", 220)))
    if len(body) > max_chars:
        body = body[: max(1, max_chars - 3)].rstrip() + "..."
    title = str(settings.get("title") or "PracticeJapanese Reminder")
    return NotificationPayload(title=title, body=body)


def _format_vocab_entry() -> Optional[str]:
    vocab_path = str(resolve_data_path("Vocab.csv"))
    try:
        vocab_rows: List[VocabRow] = load_vocab(vocab_path)
    except OSError:
        return None
    entry = _choose_entry(vocab_path, vocab_rows, score_col=3)
    if not entry:
        return None
    kanji, reading, meaning, *_ = entry
    reading_block = f" [{reading}]" if reading else ""
    meaning_text = meaning or "(no meaning)"
    return f"{kanji}{reading_block} - {meaning_text}"


def _format_kanji_entry() -> Optional[str]:
    kanji_path = str(resolve_data_path("Kanji.csv"))
    try:
        kanji_rows: List[KanjiRow] = load_kanji(kanji_path)
    except OSError:
        return None
    entry = _choose_entry(kanji_path, kanji_rows, score_col=3)
    if not entry:
        return None
    kanji, readings, meaning, *_ = entry
    readings_block = f" [{readings}]" if readings else ""
    meaning_text = meaning or "(no meaning)"
    return f"{kanji}{readings_block} - {meaning_text}"


def _choose_entry(
    csv_path: str,
    rows: Sequence[Sequence[Any]],
    score_col: int,
) -> Optional[Sequence[Any]]:
    prioritized = lowest_score_items(csv_path, rows, score_col=score_col)
    pool = prioritized or list(rows)
    if not pool:
        return None
    return random.choice(pool)


__all__ = ["start_notification_scheduler", "stop_notification_scheduler"]
