import pyrage
from echobox.tool import file

def encrypt_file_with_ssh_public_key(plaintext_file_path: str, output_path: str, recipients: list[str]):
    recipients = [pyrage.ssh.Recipient.from_str(recipient) for recipient in recipients]
    encrypt_file(plaintext_file_path=plaintext_file_path, output_path=output_path, recipients=recipients)

def decrypt_file_with_ssh_private_key(ciphertext_file_path: str, output_path: str, identity_path: str):
    identities = [pyrage.ssh.Identity.from_buffer(file.file_get_contents(identity_path).encode())]
    decrypt_file(ciphertext_file_path=ciphertext_file_path, output_path=output_path, identities=identities)

def encrypt_file(plaintext_file_path: str, output_path: str, recipients: list):
    pyrage.encrypt_file(plaintext_file_path, output_path, recipients)

def decrypt_file(ciphertext_file_path: str, output_path: str, identities: list):
    pyrage.decrypt_file(ciphertext_file_path, output_path, identities)
