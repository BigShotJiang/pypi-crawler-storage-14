"""FIBO model components."""
