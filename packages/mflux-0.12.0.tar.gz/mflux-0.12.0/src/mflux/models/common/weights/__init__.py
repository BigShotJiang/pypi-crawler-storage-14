"""Common weight mapping utilities."""

from mflux.models.common.weights.model_saver import ModelSaver

__all__ = ["ModelSaver"]
