from .nnscope.nnscope_api.curve.curve_type import CurveType  # noqa: F401
from .scope.scope import QubitScopeClient
from .nnscope.nnscope import QubitNNScopeClient
from .scope.task import TaskName
from .nnscope.task import NNTaskName