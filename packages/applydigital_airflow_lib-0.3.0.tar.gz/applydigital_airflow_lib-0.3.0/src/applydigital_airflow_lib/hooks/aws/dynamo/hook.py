from airflow import AirflowException
from airflow.providers.amazon.aws.hooks.dynamodb import DynamoDBHook


class DynamoDBHookV2(DynamoDBHook):
    def __init__(
            self, *args, connection_id: str, **kwargs
    ) -> None:
        kwargs["aws_conn_id"] = connection_id
        super().__init__(*args, **kwargs)

    def execute_query(self, **kwargs):
        """Get raw query data from dynamoDB"""
        try:
            return self.get_conn().meta.client.query(
                **kwargs
            )
        except Exception as general_error:
            raise AirflowException(f"Failed to get data from dynamodb, error: {str(general_error)}")

    def write_batch(self, **kwargs) -> bool:
        """Write batch items to DynamoDB table with provisioned throughout capacity."""
        try:
            return self.get_conn().meta.client.batch_write_item(
                **kwargs
            )
        except Exception as general_error:
            raise AirflowException(f"Failed to insert items in dynamodb, error: {str(general_error)}")
