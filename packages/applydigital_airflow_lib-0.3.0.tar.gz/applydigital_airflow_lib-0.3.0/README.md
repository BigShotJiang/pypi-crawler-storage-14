## ApplyDigital Airflow Lib

### Description

This package aims to serve as a scaffold to share functionality in a scalable and decoupled way between different projects that use Airflow.

### How to contribute

If you need to add a new module, just create it inside `applydigital_airflow_lib` folder and add its requirements in setup.cfg.

There are many thing to improve listed in the repository's issues section. You're very welcome to issue a Pull Request to improve this package!
