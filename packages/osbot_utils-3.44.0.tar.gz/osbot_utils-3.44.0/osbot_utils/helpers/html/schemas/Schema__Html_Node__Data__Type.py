from enum import Enum

class Schema__Html_Node__Data__Type(str, Enum):
    TEXT : str = 'text'
