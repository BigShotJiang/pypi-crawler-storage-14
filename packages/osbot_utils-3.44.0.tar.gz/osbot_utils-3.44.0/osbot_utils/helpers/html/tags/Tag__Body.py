from osbot_utils.helpers.html.tags.Tag__Base import Tag__Base


class Tag__Body(Tag__Base):
    tag_name = 'body'
