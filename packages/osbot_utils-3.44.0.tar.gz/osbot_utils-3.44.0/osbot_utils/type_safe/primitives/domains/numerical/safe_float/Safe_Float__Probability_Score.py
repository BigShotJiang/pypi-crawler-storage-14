from osbot_utils.type_safe.primitives.core.Safe_Float import Safe_Float

class Safe_Float__Probability_Score(Safe_Float):
    min_value = 0.0
    max_value = 1.0