from enum import Enum

class Enum__Safe_Str__Regex_Mode(Enum):
    REPLACE : str = 'replace'
    MATCH   : str = 'match'