import calendar
import re
from datetime import date, datetime, time, timedelta
from typing import Iterable


def weekdays_in_month(
    year: int, month: int, weekdays: Iterable[int] = (0, 1, 2, 3, 4)
) -> int:
    """Return the number of working days in a given year and month.

    By default, weekdays are Monday (0) through Friday (4) using Python's
    weekday numbering (Monday=0, Sunday=6).

    Args:
            year: The calendar year (e.g. 2025).
            month: The calendar month (1-12).
            weekdays: Iterable of weekday numbers (0..6) considered working days.

    Returns:
            The number of days in the month that fall on any of the given weekdays.

    Raises:
            ValueError: If `month` is not in 1..12 or `year` is not a positive integer.
    """
    if not isinstance(year, int) or year <= 0:
        raise ValueError("year must be a positive integer")

    if not isinstance(month, int) or not (1 <= month <= 12):
        raise ValueError("month must be an integer in 1..12")

    _, ndays = calendar.monthrange(year, month)
    count = 0
    # iterate days and count if weekday in working_weekdays
    for day in range(1, ndays + 1):
        if date(year, month, day).weekday() in weekdays:
            count += 1
    return count


def weekdays_in_month_iso(
    year_month: str, weekdays: Iterable[int] = (0, 1, 2, 3, 4)
) -> int:
    """Return the number of working days in a given year-month string (YYYY-MM).

    By default, weekdays are Monday (0) through Friday (4) using Python's
    weekday numbering (Monday=0, Sunday=6).

    Args:
            year_month: The year-month string in ISO format (e.g. "2025-11").
            weekdays: Iterable of weekday numbers (0..6) considered working days.

    Returns:
            The number of days in the month that fall on any of the given weekdays.

    Raises:
            ValueError: If `year_month` is not in valid format or month is not in 1..12.
    """
    try:
        year_str, month_str = year_month.split("-")
        year = int(year_str)
        month = int(month_str)
    except Exception:
        raise ValueError("year_month must be in 'YYYY-MM' format")

    return weekdays_in_month(year, month, weekdays)


def iso2gr(iso_date_str: str) -> str:
    """
    Convert an ISO 8601 date string (YYYY-MM-DD) to a Gregorian date tuple (year, month, day).

    Parameters:
    iso_date_str (str): Date string in ISO 8601 format.

    Returns:
    tuple: A tuple containing (year, month, day) as integers.
    """
    year, month, day = iso_date_str.split("-")
    return f"{day}/{month}/{year}"


def gr2iso(gr_date: str) -> str:
    """
    Convert a Gregorian date string (DD/MM/YYYY) to an ISO 8601 date string (YYYY-MM-DD).

    Parameters:
    gr_date_str (str): Date string in Gregorian format.

    Returns:
    str: Date string in ISO 8601 format.
    """
    day, month, year = gr_date.split("/")
    return f"{year}-{month}-{day}"


def date2gr(date_obj: datetime.date) -> str:
    """
    Convert a date object to a Gregorian date string (DD/MM/YYYY).

    Parameters:
    date_obj (date): A date object.

    Returns:
    str: Date string in Gregorian format.
    """
    return date_obj.strftime("%d/%m/%Y")


def gr2date(gr_date: str) -> datetime.date:
    """
    Convert a Gregorian date string (DD/MM/YYYY) to a date object.

    Parameters:
    gr_date_str (str): Date string in Gregorian format.

    Returns:
    date: A date object.
    """

    return datetime.strptime(gr_date, "%d/%m/%Y").date()


def iso2yearmonth(isodate: str) -> str:
    """2023-01-15 => 2023-01"""
    return isodate[:7]


def is_greek_date(grdate: str) -> bool:
    return re.match(r"\d{2}\/\d{2}\/\d{4}", grdate, re.I) is not None


def delta_hours(date_from: datetime, date_to: datetime) -> float:
    """Returns hours between two datetime objects"""
    delta = abs(date_to - date_from)
    return round(delta.seconds / 3600, 1)


def round_half(hours: float) -> float:
    """Hours rounded to nearest half hour"""
    return round(hours * 2) / 2


def timerange_duration(timerange: str) -> float:
    """Calculate duration in hours from a time range string formatted as HH:MM-HH:MM"""
    try:
        tfrom_str, tto_str = timerange.split("-")
        tfrom = datetime.strptime(tfrom_str, "%H:%M")
        tto = datetime.strptime(tto_str, "%H:%M")
        if tto < tfrom:
            tto += timedelta(days=1)
        return delta_hours(tfrom, tto)
    except Exception:
        return 0.0
        # raise ValueError("Invalid time range format. Expected HH:MM-HH:MM ")


def date_timerange2timedates(date_timerange: str) -> tuple[datetime, datetime]:
    """Convert a date and time range string formatted as YYYY-MM-DD HH:MM-HH:MM to two datetime objects"""
    try:
        isodate_str, time_range_str = date_timerange.split(" ")
        dtfrom_str, dtto_str = time_range_str.split("-")
        date_from = date.fromisoformat(isodate_str)
        date_to = date.fromisoformat(isodate_str)
        time_from = time.fromisoformat(dtfrom_str)
        time_to = time.fromisoformat(dtto_str)
        if time_from > time_to:
            date_to += timedelta(days=1)
        date_from = datetime.combine(date_from, time_from)
        date_to = datetime.combine(date_to, time_to)
        return date_from, date_to
    except Exception:
        raise ValueError(
            "Invalid date time range format. Expected YYYY-MM-DD HH:MM-HH:MM "
        )


def date_timerange_duration(date_timerange: str) -> float:
    """Calculate duration in hours from a date and time range string formatted as YYYY-MM-DD HH:MM-HH:MM"""
    try:
        date_from, date_to = date_timerange2timedates(date_timerange)
        return delta_hours(date_from, date_to)
    except Exception:
        return 0.0
        # raise ValueError("Invalid date time range format. Expected YYYY-MM-DD HH:MM-HH:MM " )


def timeranges_overlap(range1: str, range2: str) -> bool:
    """Check if two time ranges overlap. Ranges are in format HH:MM-HH:MM"""
    t1_from_str, t1_to_str = range1.split("-")
    t2_from_str, t2_to_str = range2.split("-")
    t1_from = datetime.strptime(t1_from_str, "%H:%M")
    t1_to = datetime.strptime(t1_to_str, "%H:%M")
    t2_from = datetime.strptime(t2_from_str, "%H:%M")
    t2_to = datetime.strptime(t2_to_str, "%H:%M")

    if t1_to <= t1_from:
        t1_to += timedelta(days=1)
    if t2_to <= t2_from:
        t2_to += timedelta(days=1)

    latest_start = max(t1_from, t2_from)
    earliest_end = min(t1_to, t2_to)

    return latest_start < earliest_end


def date_timeranges_overlap(range1: str, range2: str) -> bool:
    """Check if two date time ranges overlap. Ranges are in format YYYY-MM-DD HH:MM-HH:MM"""
    dtime1_from, dtime1_to = date_timerange2timedates(range1)
    dtime2_from, dtime2_to = date_timerange2timedates(range2)
    latest_start = max(dtime1_from, dtime2_from)
    earliest_end = min(dtime1_to, dtime2_to)
    return latest_start < earliest_end
