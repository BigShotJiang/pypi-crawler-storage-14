"""PinViz MCP Server - Natural language to GPIO wiring diagrams."""

__version__ = "0.1.0"
