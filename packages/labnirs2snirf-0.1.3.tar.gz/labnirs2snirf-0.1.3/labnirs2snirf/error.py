"""
Custom exception classes for the labnirs2snirf package.
"""


class Labnirs2SnirfError(Exception):
    """Base class for exceptions in this module."""
