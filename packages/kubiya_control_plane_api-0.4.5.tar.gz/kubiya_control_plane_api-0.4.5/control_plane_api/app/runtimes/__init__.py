"""
Shared runtime validation and configuration.

This module is shared between the API and worker to ensure consistent
validation logic across both components.
"""
