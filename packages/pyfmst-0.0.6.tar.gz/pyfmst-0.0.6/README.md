## pyFMST

Python wrapper around the FMST fortran code, initially published by Nick Rawlinson.

