"""
REM Agents - Specialized agents for REM operations.

All agents are defined as YAML schemas in src/rem/schemas/agents/.
Use create_agent_from_schema_file() to instantiate agents.
"""

__all__ = []
