# ggd-optimizer
Generic Gradient Descent
