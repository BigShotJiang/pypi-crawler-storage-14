
#pip install tensorflow keras numpy pandas matplotlib seaborn scikit-learn pycm pillow opencv-python pickle5 graphviz pydot

#=======================================================
#DL.py
#=======================================================

#transfer learning

from tensorflow.keras.preprocessing.image import ImageDataGenerator
from tensorflow.keras.models import load_model

test_gen = ImageDataGenerator(rescale=1./255)
test_data = test_gen.flow_from_directory(
    "dataset/test",
    target_size=(224, 224),
    batch_size=128,
    class_mode="categorical",
    shuffle=False
)

model1 = load_model("densenet121_oct_full.hdf5")

loss, accuracy = model1.evaluate(test_data)
print(f"✅ Test Accuracy: {accuracy:.4f}")
print(f"✅ Test Loss: {loss:.4f}")




#classification features

from tensorflow.keras.preprocessing.image import ImageDataGenerator
from tensorflow.keras.models import load_model
from tensorflow.keras.optimizers import Adam

model = load_model("densenet121_feature_extract_classifier.hdf5")

val_gen = ImageDataGenerator(rescale=1./255)
val_data = val_gen.flow_from_directory(
    "dataset/validation",   
    target_size=(224, 224),
    batch_size=64,
    class_mode="categorical",
    shuffle=False
)

model.compile(
    optimizer=Adam(),
    loss="categorical_crossentropy",
    metrics=["accuracy"]
)

loss, acc = model.evaluate(val_data, verbose=1)
print(f"✅ Validation Accuracy: {acc:.4f}")
print(f"✅ Validation Loss: {loss:.4f}")

features = model.predict(val_data, verbose=1)
labels = val_data.classes      
num_classes = val_data.num_classes
labels_onehot = np.eye(num_classes)[labels]  

print("Features shape:", features.shape)
print("Labels shape:", labels_onehot.shape)





# Image Captioning model
import tensorflow as tf
from tensorflow.keras.models import load_model

model_3 = load_model("datasetsmall/model_3.hdf5")
model_3.summary()

from pickle import dump, load

with open('datasetsmall/tokenizer.pkl', 'rb') as handle:
    tokenizer = load(handle)

max_len = 52 

from tensorflow.keras.applications.densenet import DenseNet121, preprocess_input
from tensorflow.keras.preprocessing.image import load_img, img_to_array
from tensorflow.keras.preprocessing.sequence import pad_sequences
from numpy import argmax
import numpy as np

# Load CNN for feature extraction
base_model = DenseNet121(weights='imagenet', include_top=False, pooling='avg')

def extract_features(image_path):
    image = load_img(image_path, target_size=(224, 224))
    image = img_to_array(image)
    image = np.expand_dims(image, axis=0)
    image = preprocess_input(image)
    feature = base_model.predict(image)
    return feature

def word_for_id(integer, tokenizer):
    for word, index in tokenizer.word_index.items():
        if index == integer:
            return word
    return None

def generate_caption(model, tokenizer, photo, max_length):
    in_text = 'startseq'
    for i in range(max_length):
        sequence = tokenizer.texts_to_sequences([in_text])[0]
        sequence = pad_sequences([sequence], maxlen=max_length, padding="post")
        yhat = model.predict([photo, sequence], verbose=0)
        yhat = argmax(yhat)
        word = word_for_id(yhat, tokenizer)
        if word is None:
            break
        in_text += ' ' + word
        if word == 'endseq':
            break
    return in_text.replace('startseq ', '').replace(' endseq', '')

image_path = 'datasetsmall/test/Skin-damaged soybeans/367.bmp'
photo = extract_features(image_path)
caption = generate_caption(model_3, tokenizer, photo, max_len)
print("Caption:", caption)


#=======================================================
#Confusion Matrix
#=======================================================

import seaborn as sns
import pandas as pd
from pycm import ConfusionMatrix
import matplotlib.pyplot as plt

confusion_matrix = {
    "Red Disease": {"Red Disease": 92, "Aeromoniasis": 0, "Gill Disease": 3, "Saprolegniasis": 2, "Healthy Fish": 0, "Parasitic Disease": 0, "White Tail Disease": 3},
    "Aeromoniasis": {"Red Disease": 0, "Aeromoniasis": 94, "Gill Disease": 3, "Saprolegniasis": 0, "Healthy Fish": 3, "Parasitic Disease": 0, "White Tail Disease": 0},
    "Gill Disease": {"Red Disease": 2, "Aeromoniasis": 0, "Gill Disease": 95, "Saprolegniasis": 0, "Healthy Fish": 0, "Parasitic Disease": 1, "White Tail Disease": 2},
    "Saprolegniasis": {"Red Disease": 5, "Aeromoniasis": 1, "Gill Disease": 0, "Saprolegniasis": 90, "Healthy Fish": 1, "Parasitic Disease": 3, "White Tail Disease": 0},
    "Healthy Fish": {"Red Disease": 1, "Aeromoniasis": 0, "Gill Disease": 0, "Saprolegniasis": 0, "Healthy Fish": 99, "Parasitic Disease": 0, "White Tail Disease": 0},
    "Parasitic Disease": {"Red Disease": 0, "Aeromoniasis": 3, "Gill Disease": 7, "Saprolegniasis": 1, "Healthy Fish": 4, "Parasitic Disease": 83, "White Tail Disease": 2},
    "White Tail Disease": {"Red Disease": 4, "Aeromoniasis": 0, "Gill Disease": 3, "Saprolegniasis": 2, "Healthy Fish": 5, "Parasitic Disease": 1, "White Tail Disease": 85}
}

# Create confusion matrix object
cm2 = ConfusionMatrix(matrix=confusion_matrix)

# Display matrix
print(cm2)

df = pd.DataFrame(confusion_matrix).T  # Transpose for correct orientation
plt.figure(figsize=(25, 25))
sns.heatmap(df, annot=True, fmt="d", cmap="YlGnBu")
plt.title("Confusion Matrix for MobileNetV2 based Classifier Model")
plt.ylabel("Predicted Disease")
plt.xlabel("Actual Disease")
plt.show()

# Display overall accuracy, class-wise precision, recall, and F1-score using cm2
print("Overall Accuracy:", cm2.Overall_ACC)
print("\nClass-wise Precision:")
for cls in cm2.classes:
    print(f"{cls}: {cm2.PPV[cls]:.3f}")

print("\nClass-wise Recall:")
for cls in cm2.classes:
    print(f"{cls}: {cm2.TPR[cls]:.3f}")

print("\nClass-wise F1-Score:")
for cls in cm2.classes:
    print(f"{cls}: {cm2.F1[cls]:.3f}")

#=======================================================
#Exercise 2
#=======================================================


from keras.applications.vgg16 import VGG16
from matplotlib import pyplot
from tensorflow.keras.utils import plot_model
# load the model
model = VGG16()
plot_model(model, to_file='model_plot1.png', show_shapes=True, show_layer_names=True)
# summarize filter shapes
print(model.layers)
for layer in model.layers:
	# check for convolutional layer
	if 'conv' not in layer.name:
		continue
	# get filter weights
	filters, biases = layer.get_weights()
	print(layer.name, filters.shape)
      
from keras.applications.vgg16 import VGG16
from matplotlib import pyplot
from tensorflow.keras.utils import plot_model

# load the model
model = VGG16()
plot_model(model, to_file='model_plot2.png', show_shapes=True, show_layer_names=True)
# retrieve weights from the second hidden layer
filters, biases = model.layers[1].get_weights()
# normalize filter values to 0-1 so we can visualize them
f_min, f_max = filters.min(), filters.max()
filters = (filters - f_min) / (f_max - f_min)
# plot first few filters
n_filters, ix = 6, 1
for i in range(n_filters):
	# get the filter
	f = filters[:, :, :, i]
	# plot each channel separately
	for j in range(3):
		# specify subplot and turn of axis
		ax = pyplot.subplot(n_filters, 3, ix)
		ax.set_xticks([])
		ax.set_yticks([])
		# plot filter channel in grayscale
		pyplot.imshow(f[:, :, j], cmap='gray')
		ix += 1
# show the figure
pyplot.show()

from keras.applications.vgg16 import VGG16
from keras.applications.vgg16 import preprocess_input
from keras.preprocessing.image import load_img
from keras.preprocessing.image import img_to_array
from keras.models import Model
from matplotlib import pyplot
from numpy import expand_dims
from tensorflow.keras.utils import plot_model
# load the model
model = VGG16()
# redefine model to output right after the first hidden layer
model = Model(inputs=model.inputs, outputs=model.layers[1].output)
plot_model(model, to_file='model_plot3.png', show_shapes=True, show_layer_names=True)
model.summary()

# load the image with the required shape
img = load_img('bird.jpg', target_size=(224, 224))
# convert the image to an array
img = img_to_array(img)
# expand dimensions so that it represents a single 'sample'
img = expand_dims(img, axis=0)
# prepare the image (e.g. scale pixel values for the vgg)
img = preprocess_input(img)
# get feature map for first hidden layer
feature_maps = model.predict(img)
# plot all 64 maps in an 8x8 squares
square = 8
ix = 1
for _ in range(square):
	for _ in range(square):
		# specify subplot and turn of axis
		ax = pyplot.subplot(square, square, ix)
		ax.set_xticks([])
		ax.set_yticks([])
		# plot filter channel in grayscale
		pyplot.imshow(feature_maps[0, :, :, ix-1], cmap='gray')
		ix += 1
# show the figure
pyplot.show()

from keras.applications.vgg16 import VGG16
from keras.applications.vgg16 import preprocess_input
from keras.preprocessing.image import load_img
from keras.preprocessing.image import img_to_array
from keras.models import Model
from matplotlib import pyplot
from numpy import expand_dims
from tensorflow.keras.utils import plot_model
# load the model
model = VGG16()
plot_model(model, to_file='model_plot4.png', show_shapes=True, show_layer_names=True)
# redefine model to output right after the first hidden layer
ixs = [2, 5, 9, 13, 17]
outputs = [model.layers[i].output for i in ixs]
model = Model(inputs=model.inputs, outputs=outputs)
# load the image with the required shape
img = load_img('bird.jpg', target_size=(224, 224))
# convert the image to an array
img = img_to_array(img)
# expand dimensions so that it represents a single 'sample'
img = expand_dims(img, axis=0)
# prepare the image (e.g. scale pixel values for the vgg)
img = preprocess_input(img)
# get feature map for first hidden layer
feature_maps = model.predict(img)
# plot the output from each block
square = 8
for fmap in feature_maps:
	# plot all 64 maps in an 8x8 squares
	ix = 1
	for _ in range(square):
		for _ in range(square):
			# specify subplot and turn of axis
			ax = pyplot.subplot(square, square, ix)
			ax.set_xticks([])
			ax.set_yticks([])
			# plot filter channel in grayscale
			pyplot.imshow(fmap[0, :, :, ix-1], cmap='gray')
			ix += 1
	# show the figure
	pyplot.show()
	
from keras.models import Sequential
from keras.layers import Dense
from tensorflow.keras.utils import plot_model
model = Sequential()
model.add(Dense(2, input_dim=1, activation='relu'))
model.add(Dense(1, activation='sigmoid'))
plot_model(model, to_file='model_plot5.png', show_shapes=True, show_layer_names=True)


#=======================================================
#Exercise 3
#=======================================================
#Ex-3: Different Types of Data Augmentation Techniques

#Horizontal shift
from numpy import expand_dims
from keras.preprocessing.image import load_img
from keras.preprocessing.image import img_to_array
from tensorflow.keras.preprocessing.image import ImageDataGenerator
from matplotlib import pyplot

mg = load_img('bird.jpg')
# convert to numpy array
data = img_to_array(img)
# expand dimension to one sample
samples = expand_dims(data, 0)
# create image data augmentation generator
datagen = ImageDataGenerator(width_shift_range=[-200,200])
# prepare iterator
it = datagen.flow(samples, batch_size=1)
# generate samples and plot
# generate samples and plot
for i in range(9):
    pyplot.subplot(330 + 1 + i)
    batch = next(it)
    image = batch[0].astype('uint8')
    pyplot.imshow(image)
pyplot.show()


#Vertical Shift

# load the image
img = load_img('bird.jpg')
# convert to numpy array
data = img_to_array(img)
# expand dimension to one sample
samples = expand_dims(data, 0)
# create image data augmentation generator
datagen = ImageDataGenerator(height_shift_range=0.5)
# prepare iterator
it = datagen.flow(samples, batch_size=1)
# generate samples and plot
for i in range(9):
	# define subplot
	pyplot.subplot(330 + 1 + i)
	# generate batch of images
	batch = next(it)
	# convert to unsigned integers for viewing
	image = batch[0].astype('uint8')
	# plot raw pixel data
	pyplot.imshow(image)
# show the figure
pyplot.show()


#Horizontal flip
img = load_img('bird.jpg')
# convert to numpy array
data = img_to_array(img)
# expand dimension to one sample
samples = expand_dims(data, 0)
# create image data augmentation generator
datagen = ImageDataGenerator(horizontal_flip=True)
# prepare iterator
it = datagen.flow(samples, batch_size=1)
# generate samples and plot
for i in range(9):
	# define subplot
	pyplot.subplot(330 + 1 + i)
	# generate batch of images
	batch = next(it)
	# convert to unsigned integers for viewing
	image = batch[0].astype('uint8')
	# plot raw pixel data
	pyplot.imshow(image)
# show the figure
pyplot.show()


#Rotation

# load the image
img = load_img('bird.jpg')
# convert to numpy array
data = img_to_array(img)
# expand dimension to one sample
samples = expand_dims(data, 0)
# create image data augmentation generator
datagen = ImageDataGenerator(rotation_range=90)
# prepare iterator
it = datagen.flow(samples, batch_size=1)
# generate samples and plot
for i in range(9):
	# define subplot
	pyplot.subplot(330 + 1 + i)
	# generate batch of images
	batch = next(it)
	# convert to unsigned integers for viewing
	image = batch[0].astype('uint8')
	# plot raw pixel data
	pyplot.imshow(image)
# show the figure
pyplot.show()


#Brightness

# load the image
img = load_img('bird.jpg')
# convert to numpy array
data = img_to_array(img)
# expand dimension to one sample
samples = expand_dims(data, 0)
# create image data augmentation generator
datagen = ImageDataGenerator(brightness_range=[0.2,1.0])
# prepare iterator
it = datagen.flow(samples, batch_size=1)
# generate samples and plot
for i in range(9):
	# define subplot
	pyplot.subplot(330 + 1 + i)
	# generate batch of images
	batch = next(it)
	# convert to unsigned integers for viewing
	image = batch[0].astype('uint8')
	# plot raw pixel data
	pyplot.imshow(image)
# show the figure
pyplot.show()

#Zooming

# load the image
img = load_img('bird.jpg')
# convert to numpy array
data = img_to_array(img)
# expand dimension to one sample
samples = expand_dims(data, 0)
# create image data augmentation generator
datagen = ImageDataGenerator(zoom_range=[0.5,1.0])
# prepare iterator
it = datagen.flow(samples, batch_size=1)
# generate samples and plot
for i in range(9):
	# define subplot
	pyplot.subplot(330 + 1 + i)
	# generate batch of images
	batch = next(it)
	# convert to unsigned integers for viewing
	image = batch[0].astype('uint8')
	# plot raw pixel data
	pyplot.imshow(image)
# show the figure
pyplot.show()

#=======================================================
#Exercise 4
#=======================================================
#Image classification using pre-trained Convolutional Neural Network (CNN)

from google.colab import files  # skip this line if using Kaggle
uploaded = files.upload()       # choose e.g. "mug.jpg"

from keras.preprocessing.image import load_img, img_to_array
from keras.applications.vgg16 import preprocess_input, decode_predictions, VGG16

# load the model
model = VGG16()

# load an image from file
image = load_img('vase.jpg', target_size=(224, 224))  # replace with your uploaded filename

# convert the image pixels to a numpy array
image = img_to_array(image)

# reshape data for the model
image = image.reshape((1, image.shape[0], image.shape[1], image.shape[2]))

# prepare the image for the VGG model
image = preprocess_input(image)

# predict the probability across all output classes
yhat = model.predict(image)

# convert the probabilities to class labels
label = decode_predictions(yhat)

# retrieve the most likely result
label = label[0][0]
print('%s (%.2f%%)' % (label[1], label[2]*100))

from tensorflow.keras.applications import ResNet50, InceptionV3, Xception, VGG16, VGG19, imagenet_utils
from tensorflow.keras.applications.inception_v3 import preprocess_input
from tensorflow.keras.preprocessing.image import img_to_array, load_img
import numpy as np
import matplotlib.pyplot as plt
import cv2

# Choose model here instead of argparse
model_name = "vgg16"   # change to "resnet", "inception", "xception", "vgg19"

MODELS = {
    "vgg16": VGG16,
    "vgg19": VGG19,
    "inception": InceptionV3,
    "xception": Xception,
    "resnet": ResNet50
}

if model_name not in MODELS.keys():
    raise ValueError("Invalid model name")

inputShape = (224, 224)
preprocess = imagenet_utils.preprocess_input
if model_name in ("inception", "xception"):
    inputShape = (299, 299)
    preprocess = preprocess_input

print("[INFO] loading {}...".format(model_name))
Network = MODELS[model_name]
model = Network(weights="imagenet")

image_path = "vase.jpg"  # replace with uploaded image

print("[INFO] loading and pre-processing image...")
image = load_img(image_path, target_size=inputShape)
image = img_to_array(image)
image = np.expand_dims(image, axis=0)
image = preprocess(image)

print("[INFO] classifying image with '{}'...".format(model_name))
preds = model.predict(image)
P = imagenet_utils.decode_predictions(preds)

# Print top-5 predictions
for (i, (imagenetID, label, prob)) in enumerate(P[0]):
    print("{}. {}: {:.2f}%".format(i + 1, label, prob * 100))

# Display image with top prediction
orig = cv2.imread(image_path)
orig = cv2.cvtColor(orig, cv2.COLOR_BGR2RGB)
(imagenetID, label, prob) = P[0][0]
cv2.putText(orig, "Label: {}, {:.2f}%".format(label, prob * 100),
            (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (255, 0, 0), 2)

plt.imshow(orig)
plt.axis("off")
plt.show()



#=======================================================
#Exercise 5
#=======================================================

import tensorflow as tf
from tensorflow.keras.preprocessing.image import ImageDataGenerator
from tensorflow.keras.applications.inception_v3 import InceptionV3
from tensorflow.keras.layers import Dense, GlobalAveragePooling2D
from tensorflow.keras.models import Model
from tensorflow.keras import optimizers

import matplotlib.pyplot as plt


train_datagen = ImageDataGenerator(rescale=1./255)
test_datagen  = ImageDataGenerator(rescale=1./255)
train_dir     = './OCT2017/train/'
test_dir      = './OCT2017/test/'
train_generator = train_datagen.flow_from_directory(train_dir, target_size=(299, 299),                                                     batch_size=128, class_mode='categorical')
test_generator = test_datagen.flow_from_directory(test_dir, target_size=(299, 299),                                                     batch_size=128, class_mode='categorical')

base_model = InceptionV3(weights='imagenet', include_top=False)
x = base_model.output
x = GlobalAveragePooling2D()(x)
x = Dense(64, activation='relu')(x)
predictions = Dense(4, activation='softmax')(x)

model = Model(inputs=base_model.input, outputs=predictions)

for layer in base_model.layers:
    layer.trainable = False

adam = optimizers.Adam(learning_rate=0.001)

model.compile(optimizer=adam, loss='categorical_crossentropy', metrics=['accuracy'])

# Callbacks can be added here if needed
history = model.fit(
    train_generator,
    verbose=1,
    steps_per_epoch=len(train_generator),
    epochs=10,
    validation_data=test_generator,
    validation_steps=len(test_generator)
)


#saving
model.save('model.03-0.94.hdf5')

def plot_history(history):
    acc = history.history['accuracy']
    val_acc = history.history['val_accuracy']
    loss = history.history['loss']
    val_loss = history.history['val_loss']

    epochs = range(1, len(acc) + 1)

    plt.figure()
    plt.title('Training and validation accuracy')
    plt.plot(epochs, acc, 'bo', label='Training acc')
    plt.plot(epochs, val_acc, 'r-', label='Validation acc')
    plt.legend()
    plt.show()

    plt.figure()
    plt.title('Training and validation loss')
    plt.plot(epochs, loss, 'bo', label='Training loss')
    plt.plot(epochs, val_loss, 'r-', label='Validation loss')
    plt.legend()
    plt.show()
    return acc, val_acc, loss, val_loss

acc, val_acc, loss, val_loss = plot_history(history)

import os
import numpy as np
from tensorflow.keras.preprocessing.image import ImageDataGenerator, load_img, img_to_array
from tensorflow.keras.models import load_model
# from keras import backend as K
from io import BytesIO
from PIL import Image
import cv2
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
import requests



model = load_model('model.03-0.94.hdf5')

eval_datagen = ImageDataGenerator(rescale=1./255)
eval_dir = './OCT2017/val'
eval_generator = eval_datagen.flow_from_directory(eval_dir, target_size=(299, 299),                                                     batch_size=32, class_mode='categorical')

loss = model.evaluate(eval_generator, steps=10)
for index, name in enumerate(model.metrics_names):
    print(name, loss[index])  

classes = ['CNV', 'DME', 'DRUSEN', 'NORMAL']

import tensorflow as tf
import numpy as np
import cv2
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
from tensorflow.keras.preprocessing.image import load_img, img_to_array

def preprocess_input(x):
    x = img_to_array(x) / 255.
    return np.expand_dims(x, axis=0)

def grad_CAM(image_path, model, last_conv_layer_name='conv2d_94'):
    img = load_img(image_path, target_size=(299, 299))
    x = preprocess_input(img)

    # Create a model that maps the input image to the activations
    # of the last conv layer as well as the output predictions
    grad_model = tf.keras.models.Model(
        [model.inputs],
        [model.get_layer(last_conv_layer_name).output, model.output]
    )

    with tf.GradientTape() as tape:
        conv_outputs, predictions = grad_model(x)
        pred_index = tf.argmax(predictions[0])
        class_channel = predictions[:, pred_index]

    # Compute the gradient of the top predicted class for the input image
    grads = tape.gradient(class_channel, conv_outputs)

    # Pool the gradients over all the axes leaving out the channel dimension
    pooled_grads = tf.reduce_mean(grads, axis=(0, 1, 2))

    conv_outputs = conv_outputs[0]
    heatmap = conv_outputs @ pooled_grads[..., tf.newaxis]
    heatmap = tf.squeeze(heatmap)

    # Normalize the heatmap between 0 and 1
    heatmap = tf.maximum(heatmap, 0) / tf.math.reduce_max(heatmap)
    heatmap = heatmap.numpy()

    # Load original image
    img = cv2.imread(image_path)
    heatmap = cv2.resize(heatmap, (img.shape[1], img.shape[0]))
    heatmap = np.uint8(255 * heatmap)
    heatmap = cv2.applyColorMap(heatmap, cv2.COLORMAP_JET)

    superimposed_img = heatmap * 0.5 + img
    superimposed_img = np.clip(superimposed_img, 0, 255).astype(np.uint8)

    plt.figure(figsize=(12, 8))
    plt.imshow(cv2.cvtColor(superimposed_img, cv2.COLOR_BGR2RGB))
    plt.axis('off')
    plt.show()

for i, layer in enumerate(model.layers):
    print(i, layer.name, layer.__class__.__name__)

print(predict_from_image_path(r"C:\Users\Admin\Documents\Fyp-Srini\OCT2017\val\DME\DME-9655949-1.jpeg"))
last_conv_layer_name = 'conv2d_375'  # replace with your actual last conv layer name

grad_CAM(r"C:\Users\Admin\Documents\Fyp-Srini\OCT2017\val\DME\DME-9655949-1.jpeg", model, last_conv_layer_name)

for i, c in enumerate(classes):
    folder = './simple/test/' 
    print(c)
    count = 1
    for file in os.listdir(folder):
        if file.endswith('.jpeg') == True:
            image_path = folder + file
            p, class_name = predict_from_image_path(image_path)
            if p == i:
                print(file, p, class_name)
            else:
                print(file, p, class_name, '**INCORRECT PREDICTION**')
                grad_CAM(image_path,model, last_conv_layer_name)
        count = count +1
        if count == 100:
            continue    



#=======================================================
#Exercise 6
#=======================================================

#Ex-6
import tensorflow as tf
from tensorflow.keras.models import load_model
from tensorflow.keras.applications.your_model import your_model, preprocess_input
from tensorflow.keras.preprocessing.image import ImageDataGenerator
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.metrics import confusion_matrix, classification_report

model_path = r"your_model"     
test_dir = r"dataset-1\val"

model = load_model(model_path)
print("Model loaded successfully")

# Load your_pretrained_cnn_model base (used for feature extraction)
pretrained_cnn_base = your_model(weights='imagenet', include_top=False, input_shape=(224,224,3))
print("your_pretrained_cnn_model Base model loaded for feature extraction!")

class_names = [
    'a',
    'b'
]

datagen = ImageDataGenerator(preprocessing_function=preprocess_input)
test_gen = datagen.flow_from_directory(
    test_dir,
    target_size=(224, 224),
    batch_size=1,
    class_mode='binary',
    shuffle=False
)

features = pretrained_cnn_base.predict(test_gen, verbose=1)     
print("Feature extraction completed!")

predictions = model.predict(features, verbose=1)
predicted_classes = (predictions>0.5).astype(int).flatten()
true_classes = test_gen.classes

# Confusion Matrix
cm = confusion_matrix(true_classes, predicted_classes)
plt.figure(figsize=(10, 8))
sns.heatmap(cm, annot=True, fmt='d', cmap='Blues',
            xticklabels=class_names, yticklabels=class_names)   
plt.title("Confusion Matrix - Feature Extraction Model")        
plt.xlabel("Predicted Label")
plt.ylabel("True Label")
plt.show()

# Classification Report
print("Classification Report:")
print(classification_report(true_classes, predicted_classes, target_names=class_names))


#=======================================================
#Exercise 7
#=======================================================

#Ex-7
import tensorflow as tf
from tensorflow.keras.models import load_model
from tensorflow.keras.preprocessing.image import load_img, img_to_array
from tensorflow.keras.applications.densenet import DenseNet201, preprocess_input
from tensorflow.keras.preprocessing.sequence import pad_sequences
import numpy as np
from pickle import load

# ------------------------------
# Load trained captioning model and tokenizer
# ------------------------------
model = load_model("model_captions_Ex7.hdf5")
model.summary()

with open('tokenizer_Ex7.pkl', 'rb') as handle:
    tokenizer = load(handle)

# ------------------------------
# Load DenseNet201 for feature extraction
# ------------------------------
base_model = DenseNet201(weights='imagenet', include_top=False, pooling='avg')

def extract_features(image_path):
    """Extract DenseNet201 features for a given image."""
    image = load_img(image_path, target_size=(224, 224))
    image = img_to_array(image)
    image = np.expand_dims(image, axis=0)
    image = preprocess_input(image)
    feature = base_model.predict(image, verbose=0)
    return feature

# ------------------------------
# Caption generation helpers
# ------------------------------
max_length = 10  # same as training

def word_for_id(integer, tokenizer):
    """Map an integer to a word using the tokenizer."""
    for word, index in tokenizer.word_index.items():
        if index == integer:
            return word
    return None

def generate_caption(model, tokenizer, photo, max_length):
    """Generate a caption for an image feature."""
    in_text = 'startseq'
    for _ in range(max_length):
        sequence = tokenizer.texts_to_sequences([in_text])[0]
        sequence = pad_sequences([sequence], maxlen=max_length, padding='post')

        yhat = model.predict([photo, sequence], verbose=0)
        yhat = np.argmax(yhat)

        word = word_for_id(yhat, tokenizer)
        if word is None:
            break
        in_text += ' ' + word
        if word == 'endseq':
            break

    caption = in_text.replace('startseq ', '').replace(' endseq', '')
    return caption

# ------------------------------
# Predict caption for a new image
# ------------------------------
image_path = "your path"  # Replace with your image path
photo_feature = extract_features(image_path)
caption = generate_caption(model, tokenizer, photo_feature, max_length)
print("Generated Caption:", caption)

#Ex-7 DA
# ==============================
# Evaluate on 50 Images per Class
# ==============================

from tensorflow.keras.models import load_model
from tensorflow.keras.applications.vgg16 import VGG16, preprocess_input
from tensorflow.keras.preprocessing.image import ImageDataGenerator
from sklearn.metrics import confusion_matrix, classification_report
import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np
import os, random, shutil

# 1️⃣ Load the saved classifier (trained on VGG16 features)
model = load_model("vgg16_soyaclassifier_final.h5")

# 2️⃣ Create VGG16 base model for feature extraction
base_model = VGG16(weights='imagenet', include_top=False, input_shape=(224,224,3))

# 3️⃣ Create validation data generator (temporary folder for sample images)
val_datagen = ImageDataGenerator(preprocessing_function=preprocess_input)
dataset_dir = "/content/soyadatasets/datasets/soyadatasets"
sample_dir = "/content/sample_val"

# Clear previous sample folder if exists
if os.path.exists(sample_dir):
    shutil.rmtree(sample_dir)
os.makedirs(sample_dir, exist_ok=True)

# 4️⃣ Randomly copy 50 images per class to sample folder
for class_name in os.listdir(dataset_dir):
    class_path = os.path.join(dataset_dir, class_name)
    if os.path.isdir(class_path):
        images = random.sample(os.listdir(class_path), min(50, len(os.listdir(class_path))))
        os.makedirs(os.path.join(sample_dir, class_name), exist_ok=True)
        for img in images:
            shutil.copy(os.path.join(class_path, img),
                        os.path.join(sample_dir, class_name, img))

# 5️⃣ Load the sample generator
val_generator = val_datagen.flow_from_directory(
    sample_dir,
    target_size=(224,224),
    batch_size=32,
    class_mode='categorical',
    shuffle=False
)

# 6️⃣ Extract VGG16 features from sample validation images
val_features = base_model.predict(val_generator, verbose=1)

# 7️⃣ Predict using the trained classifier
preds = model.predict(val_features, verbose=1)

# 8️⃣ True and predicted labels
y_true = val_generator.classes
y_pred = np.argmax(preds, axis=1)
class_names = list(val_generator.class_indices.keys())

# 9️⃣ Confusion Matrix
cm = confusion_matrix(y_true, y_pred)
plt.figure(figsize=(8,6))
sns.heatmap(cm, annot=True, fmt='d', xticklabels=class_names, yticklabels=class_names, cmap="Blues")
plt.xlabel("Predicted")
plt.ylabel("Actual")
plt.title("Confusion Matrix (50 Images per Class)")
plt.show()

# 🔟 Classification Report
print("Classification Report:\n")
print(classification_report(y_true, y_pred, target_names=class_names))



