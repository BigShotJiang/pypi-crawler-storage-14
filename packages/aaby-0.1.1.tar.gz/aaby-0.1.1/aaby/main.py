from .scripts.AABY import main as _main

def main():
    _main()