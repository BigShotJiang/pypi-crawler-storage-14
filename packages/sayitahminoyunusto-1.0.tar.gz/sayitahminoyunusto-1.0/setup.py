from setuptools import setup, find_packages

setup(
    name="sayitahminoyunusto",       # Paketinin adı
    version="1.0",             # Versiyon
    packages=find_packages(),  # Klasör içindeki tüm package’leri bul
    install_requires=[],       # Başka paketlere bağımlılık yok
    description="Sayı Tahmin Oyunu!",
    author="YusufStudio18",
    author_email="yusufstudio913@gmail.com",
)