# supplytrack-co2-analytics

CO₂ analytics library for calculating and analyzing shipment emissions.

## Installation
