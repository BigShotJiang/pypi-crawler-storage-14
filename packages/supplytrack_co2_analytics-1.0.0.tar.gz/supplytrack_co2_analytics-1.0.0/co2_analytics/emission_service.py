"""
CO₂ Emission Service Layer
Handles data operations for emission management
"""

from decimal import Decimal
from .emission_calculator import EmissionCalculator
from .validators import ValidationError


class EmissionService:
    """
    Service for managing emission data
    
    This is a template service. In your Django application, override
    these methods to integrate with your database.
    """
    
    @staticmethod
    def calculate_and_record_emission(order):
        """
        Calculate and record emission data for an order
        
        Args:
            order: Order object
            
        Returns:
            dict: Emission data
        """
        try:
            # Calculate emission
            emission_data = EmissionCalculator.calculate_order_emission(order)
            
            # ✅ Return data ready for database storage
            return {
                'shipment_id': getattr(order, 'order_id', None),
                'supplier': getattr(order, 'supplier', None),
                'origin': getattr(order, 'from_location', 'Warehouse'),
                'destination': getattr(order, 'destination_location', 'Destination'),
                'distance_km': Decimal(str(emission_data['distance_km'])),
                'transport_mode': emission_data['transport_mode'],
                'weight_kg': Decimal(str(emission_data['weight_tons'])) * Decimal('1000'),
                'total_co2_kg': Decimal(str(emission_data['total_co2_kg'])),
                'emission_factor': emission_data['emission_factor'],
                'breakdown': emission_data['breakdown'],
                'notes': f"Order {getattr(order, 'order_id', 'Unknown')} - {emission_data['transport_mode'].upper()} shipment",
            }
            
        except ValidationError as e:
            raise
        except Exception as e:
            raise Exception(f"Error recording emission: {str(e)}")
    
    @staticmethod
    def get_supplier_emissions(supplier_data=None):
        """
        Get aggregated emission data for a supplier
        
        Args:
            supplier_data: List of emission records or aggregated data
            
        Returns:
            dict: {
                'total_co2_kg': float,
                'total_shipments': int,
                'avg_co2_per_shipment': float,
                'by_transport_mode': dict,
            }
        """
        if not supplier_data:
            supplier_data = []
        
        if isinstance(supplier_data, dict):
            # Already aggregated
            return supplier_data
        
        # Aggregate from list
        total_co2_kg = Decimal('0')
        total_shipments = len(supplier_data) if supplier_data else 0
        by_mode = {}
        
        for record in supplier_data:
            co2 = record.get('total_co2_kg', 0) if isinstance(record, dict) else getattr(record, 'total_co2_kg', 0)
            total_co2_kg += Decimal(str(co2))
            
            mode = record.get('transport_mode', 'unknown') if isinstance(record, dict) else getattr(record, 'transport_mode', 'unknown')
            by_mode[mode] = by_mode.get(mode, Decimal('0')) + Decimal(str(co2))
        
        avg_co2 = total_co2_kg / total_shipments if total_shipments > 0 else Decimal('0')
        
        return {
            'total_co2_kg': round(float(total_co2_kg), 2),
            'total_shipments': total_shipments,
            'avg_co2_per_shipment': round(float(avg_co2), 2),
            'by_transport_mode': {k: round(float(v), 2) for k, v in by_mode.items()},
        }
