"""
Input Validation for CO₂ Calculations
"""

from .constants import (
    EMISSION_FACTORS,
    MIN_WEIGHT_TONS,
    MAX_WEIGHT_TONS,
    MIN_DISTANCE_KM,
    MAX_DISTANCE_KM,
)


class ValidationError(Exception):
    """Custom validation error"""
    pass


class EmissionValidator:
    """Validate all inputs before calculation"""
    
    @staticmethod
    def validate_transport_mode(transport_mode):
        """Validate transport mode is supported"""
        if not transport_mode:
            raise ValidationError("❌ Transport mode is required")
        
        mode = str(transport_mode).lower()
        
        if mode not in EMISSION_FACTORS:
            valid_modes = ', '.join(EMISSION_FACTORS.keys())
            raise ValidationError(
                f"❌ Invalid transport mode: {mode}. Valid modes: {valid_modes}"
            )
        
        return mode
    
    @staticmethod
    def validate_weight(weight_tons):
        """Validate weight is within acceptable range"""
        if weight_tons is None:
            raise ValidationError("❌ Weight is required")
        
        try:
            weight = float(weight_tons)
        except (ValueError, TypeError):
            raise ValidationError(f"❌ Weight must be a number, got {type(weight_tons)}")
        
        if weight < MIN_WEIGHT_TONS or weight > MAX_WEIGHT_TONS:
            raise ValidationError(
                f"❌ Weight must be between {MIN_WEIGHT_TONS} and {MAX_WEIGHT_TONS} tons, got {weight}"
            )
        
        return weight
    
    @staticmethod
    def validate_distance(distance_km):
        """Validate distance is within acceptable range"""
        if distance_km is None:
            raise ValidationError("❌ Distance is required")
        
        try:
            distance = float(distance_km)
        except (ValueError, TypeError):
            raise ValidationError(f"❌ Distance must be a number, got {type(distance_km)}")
        
        if distance < MIN_DISTANCE_KM or distance > MAX_DISTANCE_KM:
            raise ValidationError(
                f"❌ Distance must be between {MIN_DISTANCE_KM} and {MAX_DISTANCE_KM} km, got {distance}"
            )
        
        return distance
    
    @staticmethod
    def validate_order_emission_data(order):
        """Validate all required fields for emission calculation"""
        errors = []
        
        # Check required attributes
        if not hasattr(order, 'from_location') or not order.from_location:
            errors.append("from_location (origin)")
        if not hasattr(order, 'destination_location') or not order.destination_location:
            errors.append("destination_location")
        if not hasattr(order, 'transport_mode') or not order.transport_mode:
            errors.append("transport_mode")
        if not hasattr(order, 'distance_km') or not order.distance_km:
            errors.append("distance_km")
        if not hasattr(order, 'weight_tons') or order.weight_tons is None:
            errors.append("weight_tons")
        
        if errors:
            missing = ", ".join(errors)
            raise ValidationError(f"❌ Missing data: {missing}")
        
        return True
