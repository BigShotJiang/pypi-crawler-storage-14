"""
Analytics Service Module
Advanced analytics and reporting for CO2 emissions
"""

from datetime import datetime, timedelta, date
from decimal import Decimal
from collections import defaultdict


class AnalyticsService:
    """
    Advanced analytics for CO2 emissions
    
    Provides trend analysis, distribution analysis, and forecasting.
    """
    
    @staticmethod
    def get_monthly_trend(emissions_data=None, months=6):
        """
        Get monthly emission trend
        
        Args:
            emissions_data: List of emission records with 'shipment_date' and 'total_co2_kg'
            months: Number of months to retrieve
            
        Returns:
            List of monthly trends
        """
        if emissions_data is None:
            emissions_data = []
        
        # Group by month
        monthly_data = defaultdict(lambda: Decimal('0'))
        
        for record in emissions_data:
            if isinstance(record, dict):
                shipment_date = record.get('shipment_date')
                co2 = record.get('total_co2_kg', 0)
            else:
                shipment_date = getattr(record, 'shipment_date', None)
                co2 = getattr(record, 'total_co2_kg', 0)
            
            if shipment_date:
                # Convert to date if datetime
                if hasattr(shipment_date, 'date'):
                    shipment_date = shipment_date.date()
                
                month_key = shipment_date.strftime('%Y-%m')
                monthly_data[month_key] += Decimal(str(co2))
        
        # Generate months
        result = []
        current = datetime.now().replace(day=1)
        
        for _ in range(months):
            month_key = current.strftime('%Y-%m')
            result.append({
                'month': current.strftime('%b %Y'),
                'year_month': month_key,
                'total_co2_kg': float(monthly_data.get(month_key, Decimal('0')))
            })
            
            # Move to previous month
            if current.month == 1:
                current = current.replace(year=current.year - 1, month=12)
            else:
                current = current.replace(month=current.month - 1)
        
        return list(reversed(result))
    
    @staticmethod
    def get_transport_mode_distribution(emissions_data=None):
        """
        Get emissions distribution by transport mode
        
        Returns:
            List of transport modes with percentages
        """
        if emissions_data is None:
            emissions_data = []
        
        # Aggregate by transport mode
        mode_totals = defaultdict(lambda: Decimal('0'))
        
        for record in emissions_data:
            if isinstance(record, dict):
                mode = record.get('transport_mode', 'unknown')
                co2 = record.get('total_co2_kg', 0)
            else:
                mode = getattr(record, 'transport_mode', 'unknown')
                co2 = getattr(record, 'total_co2_kg', 0)
            
            mode_totals[mode] += Decimal(str(co2))
        
        total = sum(mode_totals.values())
        
        # Calculate percentages
        distribution = []
        for mode, co2_kg in mode_totals.items():
            percentage = (co2_kg / total * 100) if total > 0 else 0
            distribution.append({
                'mode': str(mode),
                'co2_kg': float(co2_kg),
                'percentage': round(float(percentage), 2)
            })
        
        return sorted(distribution, key=lambda x: x['co2_kg'], reverse=True)
    
    @staticmethod
    def get_dashboard_stats(emissions_data=None):
        """
        Get comprehensive dashboard statistics
        
        Returns:
            Dict with key metrics
        """
        if emissions_data is None:
            emissions_data = []
        
        # Ensure list
        if not isinstance(emissions_data, list):
            try:
                emissions_data = list(emissions_data)
            except:
                emissions_data = []
        
        total_emissions = Decimal('0')
        month_emissions = Decimal('0')
        year_emissions = Decimal('0')
        
        today = date.today()
        month_start = today.replace(day=1)
        year_start = today.replace(month=1, day=1)
        
        for record in emissions_data:
            if isinstance(record, dict):
                shipment_date = record.get('shipment_date', today)
                co2 = Decimal(str(record.get('total_co2_kg', 0)))
            else:
                shipment_date = getattr(record, 'shipment_date', today)
                co2 = Decimal(str(getattr(record, 'total_co2_kg', 0)))
            
            # Convert to date if datetime
            if hasattr(shipment_date, 'date'):
                shipment_date = shipment_date.date()
            
            total_emissions += co2
            
            if shipment_date >= month_start:
                month_emissions += co2
            
            if shipment_date >= year_start:
                year_emissions += co2
        
        total_shipments = len(emissions_data)
        avg_per_shipment = (total_emissions / total_shipments) if total_shipments > 0 else Decimal('0')
        
        return {
            'total_emissions_kg': round(float(total_emissions), 2),
            'month_emissions_kg': round(float(month_emissions), 2),
            'year_emissions_kg': round(float(year_emissions), 2),
            'avg_per_shipment_kg': round(float(avg_per_shipment), 2),
            'total_shipments': total_shipments
        }
    
    @staticmethod
    def get_emissions_forecast(emissions_data=None, days=30):
        """Forecast CO₂ emissions for future days"""
        if emissions_data is None:
            emissions_data = []
        
        # Calculate average daily emissions
        if emissions_data:
            total_co2 = sum(
                Decimal(str(
                    r.get('total_co2_kg', 0) if isinstance(r, dict) 
                    else getattr(r, 'total_co2_kg', 0)
                ))
                for r in emissions_data
            )
            avg_daily = total_co2 / len(emissions_data)
        else:
            avg_daily = Decimal('0')
        
        # Generate forecast
        forecast = []
        for i in range(days):
            future_date = datetime.now() + timedelta(days=i)
            forecast.append({
                'date': future_date.strftime('%Y-%m-%d'),
                'predicted_co2_kg': float(avg_daily)
            })
        
        return forecast
    
    @staticmethod
    def calculate_reduction_target(current_monthly_co2, reduction_percent=10):
        """Calculate CO2 reduction targets"""
        current = Decimal(str(current_monthly_co2))
        reduction_decimal = Decimal(str(reduction_percent)) / Decimal('100')
        co2_to_reduce = current * reduction_decimal
        target_monthly = current - co2_to_reduce
        
        return {
            'current_monthly_co2': round(float(current), 2),
            'target_reduction_percent': reduction_percent,
            'target_monthly_co2': round(float(target_monthly), 2),
            'co2_to_reduce': round(float(co2_to_reduce), 2)
        }
