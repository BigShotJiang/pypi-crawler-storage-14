"""
CO2 Analytics Library
===============================

A comprehensive Python library for calculating, tracking, and analyzing 
CO2 emissions from shipments in supply chain management systems.

Features:
  - 📊 Accurate CO2 emission calculations
  - 📈 Advanced analytics and reporting
  - 🚚 Support for multiple transport modes
  - ♻️ Sustainability tracking

Version: 1.0.0
Author: SupplyTrack Development Team
License: MIT
"""

__version__ = "1.0.0"
__author__ = "SupplyTrack Development Team"
__author_email__ = "dev@supplytrack.com"
__license__ = "MIT"

from .constants import EMISSION_FACTORS, ENVIRONMENTAL_CONVERSIONS
from .validators import EmissionValidator, ValidationError
from .emission_calculator import EmissionCalculator
from .emission_service import EmissionService
from .analytics_service import AnalyticsService

__all__ = [
    'EmissionCalculator',
    'EmissionService',
    'AnalyticsService',
    'EmissionValidator',
    'ValidationError',
    'EMISSION_FACTORS',
    'ENVIRONMENTAL_CONVERSIONS',
    '__version__',
    '__author__',
]
