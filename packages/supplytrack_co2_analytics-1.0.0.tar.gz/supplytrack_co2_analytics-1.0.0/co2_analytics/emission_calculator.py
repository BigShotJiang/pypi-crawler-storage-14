"""
Core CO₂ Emission Calculations
Pure calculation logic - no database operations
"""

from decimal import Decimal
from .constants import EMISSION_FACTORS, ENVIRONMENTAL_CONVERSIONS
from .validators import EmissionValidator, ValidationError


class EmissionCalculator:
    """
    Calculate CO₂ emissions based on shipment details
    
    Formula: CO2 (kg) = Weight (tons) × Distance (km) × Emission Factor (g/ton/km) / 1000
    
    Example:
        >>> class Order:
        ...     from_location = "NYC"
        ...     destination_location = "LAX"
        ...     distance_km = 4500
        ...     weight_tons = 20
        ...     transport_mode = "truck"
        >>> result = EmissionCalculator.calculate_order_emission(Order())
        >>> print(f"CO2: {result['total_co2_kg']} kg")
    """
    
    @staticmethod
    def calculate_order_emission(order):
        """
        Calculate total CO₂ emissions for an order
        
        Args:
            order: Object with attributes:
                - from_location (str)
                - destination_location (str)
                - distance_km (float)
                - weight_tons (float)
                - transport_mode (str)
        
        Returns:
            dict: {
                'total_co2_kg': float,
                'weight_tons': float,
                'distance_km': float,
                'transport_mode': str,
                'emission_factor': float,
                'breakdown': dict,
            }
        """
        try:
            # ✅ Validate all inputs
            EmissionValidator.validate_order_emission_data(order)
            
            weight = EmissionValidator.validate_weight(order.weight_tons)
            distance = EmissionValidator.validate_distance(order.distance_km)
            transport_mode = EmissionValidator.validate_transport_mode(order.transport_mode)
            
        except ValidationError as e:
            raise
        
        # ✅ Get emission factor for transport mode
        emission_factor = EMISSION_FACTORS[transport_mode]['factor']
        
        # ✅ Calculate total CO₂
        # Formula: (Weight × Distance × Factor) / 1000
        total_co2_kg = (
            Decimal(str(weight)) * 
            Decimal(str(distance)) * 
            Decimal(str(emission_factor)) / 
            Decimal('1000')
        )
        total_co2_kg = float(total_co2_kg)
        
        # ✅ Calculate environmental impact conversions
        breakdown = EmissionCalculator._calculate_breakdown(total_co2_kg)
        
        return {
            'total_co2_kg': round(total_co2_kg, 2),
            'weight_tons': weight,
            'distance_km': distance,
            'transport_mode': transport_mode,
            'emission_factor': emission_factor,
            'breakdown': breakdown,
        }
    
    @staticmethod
    def _calculate_breakdown(total_co2_kg):
        """Calculate environmental impact conversions"""
        return {
            'equivalent_km_driven': round(
                total_co2_kg / ENVIRONMENTAL_CONVERSIONS['km_driven'], 2
            ),
            'equivalent_kwh': round(
                total_co2_kg / ENVIRONMENTAL_CONVERSIONS['kwh_energy'], 2
            ),
            'trees_to_offset': round(
                total_co2_kg / ENVIRONMENTAL_CONVERSIONS['trees_offset'], 2
            ),
        }
    
    @staticmethod
    def calculate_batch_emissions(orders):
        """
        Calculate CO₂ for multiple orders
        
        Args:
            orders: List of order objects
            
        Returns:
            dict: {
                'results': list of calculation results,
                'total_co2_kg': float,
                'count': int,
            }
        """
        results = []
        total_co2 = 0
        
        for order in orders:
            try:
                result = EmissionCalculator.calculate_order_emission(order)
                results.append(result)
                total_co2 += result['total_co2_kg']
            except ValidationError:
                continue
        
        return {
            'results': results,
            'total_co2_kg': round(total_co2, 2),
            'count': len(results),
        }
    
    @staticmethod
    def compare_transport_modes(weight_tons, distance_km):
        """
        Compare CO2 emissions across all transport modes
        
        Returns:
            dict: Transport mode to CO2 kg mapping
        """
        weight = Decimal(str(weight_tons))
        distance = Decimal(str(distance_km))
        
        comparison = {}
        for mode, data in EMISSION_FACTORS.items():
            factor = Decimal(str(data['factor']))
            co2 = weight * distance * factor / Decimal('1000')
            comparison[mode] = round(float(co2), 2)
        
        return comparison
    
    @staticmethod
    def get_emission_factors():
        """Get all available emission factors with details"""
        return {
            mode: {
                'factor': data['factor'],
                'name': data['name'],
                'description': data['description'],
            }
            for mode, data in EMISSION_FACTORS.items()
        }
