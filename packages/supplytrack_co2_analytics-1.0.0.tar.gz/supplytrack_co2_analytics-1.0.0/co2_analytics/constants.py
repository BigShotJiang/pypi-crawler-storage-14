"""
CO₂ Emission Constants and Factors
All values in grams of CO₂ per ton per kilometer

Source: IPCC, EPA, and industry standards
"""

# ============================================
# TRANSPORT MODE EMISSION FACTORS
# ============================================

EMISSION_FACTORS = {
    'truck': {
        'factor': 61.0,  # g CO2/ton/km
        'name': 'Truck (Heavy)',
        'description': 'Diesel truck over 7.5 tons',
    },
    'ship': {
        'factor': 10.0,  # g CO2/ton/km
        'name': 'Ship (Container)',
        'description': 'Container ship average',
    },
    'plane': {
        'factor': 255.0,  # g CO2/ton/km
        'name': 'Plane (Cargo)',
        'description': 'Air cargo freight',
    },
    'rail': {
        'factor': 18.0,  # g CO2/ton/km
        'name': 'Rail',
        'description': 'Diesel or electric train',
    },
}

# ============================================
# DEFAULT VALUES
# ============================================

DEFAULT_TRANSPORT_MODE = 'truck'
MIN_WEIGHT_TONS = 0.001  # 1 kg minimum
MAX_WEIGHT_TONS = 1000   # 1000 tons maximum
MIN_DISTANCE_KM = 1
MAX_DISTANCE_KM = 50000

# ============================================
# ENVIRONMENTAL IMPACT CONVERSIONS
# ============================================
# Used for user-friendly reporting

ENVIRONMENTAL_CONVERSIONS = {
    'km_driven': 0.000224,  # kg CO2 per km driven (avg car)
    'kwh_energy': 0.41,     # kg CO2 per kWh (grid average)
    'trees_offset': 25.0,   # kg CO2 per tree per year
}

# ============================================
# STATUS TRACKING
# ============================================

VALID_STATUSES = ['pending', 'approved', 'shipped', 'delivered', 'rejected']
EMISSION_TRIGGER_STATUSES = ['approved', 'shipped', 'delivered']
