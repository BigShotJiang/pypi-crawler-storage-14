from ..core._image_pipeline import ImagePipeline


class PrefabPipeline(ImagePipeline):
    """
    Pipeline class for prefabricated image pipelines from the phenotypic team.

    """
    pass
