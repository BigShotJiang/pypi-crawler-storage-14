import{_ as a,cu as s}from"./index-DhxwW1_d.js";const c=a(s,[["__scopeId","data-v-565bc716"]]);export{c as M};
