# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import TypedDict

__all__ = ["ComputerCaptureScreenshotParams"]


class ComputerCaptureScreenshotParams(TypedDict, total=False):
    base64: bool

    tab_id: str
