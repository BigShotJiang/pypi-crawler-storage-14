"""
FastAPI demo application for RAGdoll.

Run with:
    uvicorn demo_app.main:app --reload
"""
