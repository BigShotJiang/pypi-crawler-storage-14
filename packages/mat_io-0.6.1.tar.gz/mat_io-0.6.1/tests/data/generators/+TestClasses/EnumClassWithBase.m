classdef EnumClassWithBase < uint32
   enumeration
      enum1 (1)
      emum2 (2)
   end
end
