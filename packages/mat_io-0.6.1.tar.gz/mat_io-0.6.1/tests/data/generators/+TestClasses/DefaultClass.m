classdef DefaultClass
    properties
        a = "Default String";
        b = 10;
    end
end
