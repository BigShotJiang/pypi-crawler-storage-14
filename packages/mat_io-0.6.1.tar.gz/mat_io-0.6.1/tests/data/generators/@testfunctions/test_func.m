function y = test_func(x)
    y = x.^2 + 1;
end
