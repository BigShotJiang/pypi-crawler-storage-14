import csv
from typing import List, Dict

def write_gap_csv(rows: List[Dict[str, str]], path: str) -> None:
    if not rows:
        # still write header for empty result
        fieldnames = [
            "missing_topic",
            "winner_page",
            "supporter_page",
            "recommended_change",
            "suggested_anchor",
            "relevance_score",
        ]
        with open(path, "w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=fieldnames)
            writer.writeheader()
        return

    fieldnames = list(rows[0].keys())
    with open(path, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for row in rows:
            writer.writerow(row)
