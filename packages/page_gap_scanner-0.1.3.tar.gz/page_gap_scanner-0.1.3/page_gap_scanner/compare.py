from typing import List, Dict
from .fetch import fetch_html
from .extract import extract_page_info
from .export import write_gap_csv

def decide_winner(
    url1: str,
    url2: str,
    score1: int,
    score2: int,
) -> (str, str):
    """Choose winner/supporter based on score.

    Higher score wins; ties default to url1 as winner.
    """
    if score2 > score1:
        return url2, url1
    return url1, url2

def build_anchor(topic: str) -> str:
    """Return a simple, human-ish suggested anchor for a topic."""
    # Mix of formats
    base = topic.strip().lower()
    if len(base.split()) <= 3:
        return f"learn more about {base}"
    return f"full guide on {base}"

def build_recommendation(topic: str, winner: str, supporter: str) -> str:
    return (
        f"Add a short section or sentence about '{topic}' on {supporter} "
        f"and link contextually to {winner}."
    )

def compare_pages(url1: str, url2: str) -> List[Dict[str, str]]:
    """Core logic: fetch two URLs, decide winner/supporter, compute topic gaps.

    Returns a list of dict rows for CSV.
    """
    html1 = fetch_html(url1)
    html2 = fetch_html(url2)

    title1, wc1, hc1, topics1 = extract_page_info(html1)
    title2, wc2, hc2, topics2 = extract_page_info(html2)

    score1 = wc1 + 5 * hc1
    score2 = wc2 + 5 * hc2

    winner, supporter = decide_winner(url1, url2, score1, score2)
    winner_topics = topics1 if winner == url1 else topics2
    supporter_topics = topics2 if winner == url1 else topics1

    missing_topics = sorted(list(winner_topics - supporter_topics))

    rows: List[Dict[str, str]] = []
    for topic in missing_topics:
        anchor = build_anchor(topic)
        rec = build_recommendation(topic, winner, supporter)
        row = {
            "missing_topic": topic,
            "winner_page": winner,
            "supporter_page": supporter,
            "recommended_change": rec,
            "suggested_anchor": anchor,
            "relevance_score": "80",  # simple constant for now
        }
        rows.append(row)

    return rows, winner, supporter, len(missing_topics), (title1, wc1, hc1, score1), (title2, wc2, hc2, score2)

def compare_and_export(url1: str, url2: str, output: str) -> None:
    rows, winner, supporter, count, info1, info2 = compare_pages(url1, url2)
    write_gap_csv(rows, output)
    print()
    print("Scanning:")
    print(f"  URL 1: {url1}")
    print(f"    title: {info1[0]}")
    print(f"    words: {info1[1]}, headings (h1–h3): {info1[2]}, score: {info1[3]}")
    print(f"  URL 2: {url2}")
    print(f"    title: {info2[0]}")
    print(f"    words: {info2[1]}, headings (h1–h3): {info2[2]}, score: {info2[3]}")
    print()
    print(f"Winner selected:   {winner}")
    print(f"Supporter selected:{supporter}")
    print(f"Missing topics on supporter: {count}")
    print(f"CSV written to: {output}")
