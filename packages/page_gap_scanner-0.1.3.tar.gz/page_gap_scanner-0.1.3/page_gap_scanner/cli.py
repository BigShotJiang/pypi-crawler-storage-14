import typer
from .compare import compare_and_export

app = typer.Typer(help="Compare two URLs and generate a topic & internal-link gap CSV report.")

@app.command()
def scan(
    url1: str = typer.Argument(..., help="First URL to compare."),
    url2: str = typer.Argument(..., help="Second URL to compare."),
    output: str = typer.Option("gaps.csv", "--output", "-o", help="Output CSV filepath."),
):
    """Compare two URLs and write a topic gap report to CSV."""
    compare_and_export(url1, url2, output)

def main():
    app()

if __name__ == "__main__":
    main()
