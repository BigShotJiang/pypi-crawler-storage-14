"""page-gap-scanner: compare two URLs and generate a topic & internal-link gap report."""

__version__ = "0.1.0"
