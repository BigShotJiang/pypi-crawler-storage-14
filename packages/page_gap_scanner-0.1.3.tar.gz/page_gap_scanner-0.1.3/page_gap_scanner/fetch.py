import requests
from typing import Optional

DEFAULT_HEADERS = {
    "User-Agent": "page-gap-scanner/0.1.0 (+https://pypi.org/project/page-gap-scanner/)"
}

def fetch_html(url: str, timeout: int = 15) -> str:
    """Fetch HTML content for a given URL.

    Raises requests.HTTPError on bad status codes.
    """
    resp = requests.get(url, headers=DEFAULT_HEADERS, timeout=timeout)
    resp.raise_for_status()
    return resp.text
