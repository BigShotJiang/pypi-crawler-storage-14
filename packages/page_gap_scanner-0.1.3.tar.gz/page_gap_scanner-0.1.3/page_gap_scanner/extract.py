from bs4 import BeautifulSoup
from typing import List, Set, Tuple

STOPWORDS = {
    "the","a","an","and","or","for","of","to","in","on","at","by","with","from","is","are",
    "this","that","these","those","it","its","as","be","can","you","your","we","our","us",
    "if","when","how","what","why","which","into","about","more","most","less","least"
}

def clean_token(token: str) -> str:
    token = token.strip().lower()
    if not token:
        return ""
    # remove basic punctuation
    bad_chars = ',.;:!?()[]{}"\'`'
    for ch in bad_chars:
        token = token.replace(ch, " ")
    token = " ".join(token.split())
    return token

def split_into_candidates(text: str) -> List[str]:
    # naive phrase splitter: split by comma and period first
    parts = []
    for chunk in text.split(","):
        for sub in chunk.split("."):
            cleaned = clean_token(sub)
            if cleaned:
                parts.append(cleaned)
    return parts

def extract_page_info(html: str) -> Tuple[str, int, int, Set[str]]:
    """Return (title, word_count, heading_count, topics).

    topics is a set of short phrases derived from headings and visible text.
    """
    soup = BeautifulSoup(html, "html.parser")

    title_tag = soup.find("title")
    title = title_tag.get_text(strip=True) if title_tag else ""

    headings = []
    for tag_name in ["h1", "h2", "h3"]:
        for h in soup.find_all(tag_name):
            headings.append(h.get_text(separator=" ", strip=True))

    # basic visible text: body text stripped
    body = soup.body.get_text(separator=" ", strip=True) if soup.body else soup.get_text(separator=" ", strip=True)
    words = [w for w in body.split() if w.strip()]
    word_count = len(words)

    heading_count = len(headings)

    # topic candidates from title + headings + some body text
    seed_text = " ".join([title] + headings[:20])  # first 20 headings if many
    candidates = split_into_candidates(seed_text)

    topics: Set[str] = set()
    for cand in candidates:
        tokens = [t for t in cand.split() if t not in STOPWORDS and len(t) > 2]
        if not tokens:
            continue
        phrase = " ".join(tokens)
        if len(phrase) < 4:
            continue
        topics.add(phrase)

    return title, word_count, heading_count, topics
