from enum import Enum


class DocXHeaderFooterTypeEnum(str, Enum):
    first = ("First",)
    even = ("Even",)
    odd = ("Odd",)
