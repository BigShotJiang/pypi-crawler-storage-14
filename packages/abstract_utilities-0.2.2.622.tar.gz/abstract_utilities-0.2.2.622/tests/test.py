from imports import *
get_all_imports()
file_path = "/home/flerb/Pictures/gts/gts2/73w"
sysroot="/home/flerb/Downloads"

###get_dot_fro_line(line,dirname=None,file_path=None,get_info=False)

file_path="/home/flerb/Documents/pythonTools/modules/src/modules/abstract_paths/src/abstract_paths/finderTab"
result = findContent(file_path,strings='gg',exclude_exts='pyc')

