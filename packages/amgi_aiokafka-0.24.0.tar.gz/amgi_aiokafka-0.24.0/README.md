# amgi-aiokafka

:construction: This package is currently under development :construction:

AMGI will be here very soon

## Installation

```
pip install amgi-aiokafka==0.24.0
```

## Contact

For questions or suggestions, please contact [jack.burridge@mail.com](mailto:jack.burridge@mail.com).

## License

Copyright 2025 AMGI
