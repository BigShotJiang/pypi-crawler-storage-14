import json
import sys
from pathlib import Path
from types import SimpleNamespace

# Ensure repository root is importable
ROOT = Path(__file__).resolve().parents[3]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import pytest

import automation.orchestrated_pr_runner as runner


def test_sanitize_workspace_name_includes_pr_number():
    assert runner.sanitize_workspace_name("feature/my-branch", 42) == "pr-42-feature-my-branch"
    assert runner.sanitize_workspace_name("!!!", 7) == "pr-7"


def test_query_recent_prs_invalid_json(monkeypatch):
    monkeypatch.setattr(
        runner,
        "run_cmd",
        lambda *_, **__: SimpleNamespace(returncode=0, stdout="not json", stderr=""),
    )
    with pytest.raises(RuntimeError):
        runner.query_recent_prs(24)


def test_query_recent_prs_skips_incomplete_data(monkeypatch):
    response = {
        "data": {
            "search": {
                "nodes": [
                    {
                        "__typename": "PullRequest",
                        "number": None,
                        "repository": {"name": "repo", "nameWithOwner": "org/repo"},
                        "headRefName": "branch",
                        "headRefOid": "abc",
                        "updatedAt": "2024-01-01T00:00:00Z",
                    }
                ],
                "pageInfo": {"hasNextPage": False, "endCursor": None},
            }
        }
    }
    monkeypatch.setattr(
        runner,
        "run_cmd",
        lambda *_, **__: SimpleNamespace(returncode=0, stdout=json.dumps(response), stderr=""),
    )
    assert runner.query_recent_prs(24) == []


def test_prepare_workspace_dir_cleans_worktree(monkeypatch, tmp_path):
    runner.WORKSPACE_ROOT_BASE = tmp_path
    target = tmp_path / "repo" / "ws"
    target.mkdir(parents=True)
    git_dir = tmp_path / "base" / ".git" / "worktrees" / "ws"
    git_dir.mkdir(parents=True)
    git_file = target / ".git"
    git_file.write_text(f"gitdir: {git_dir}")

    calls = []

    def fake_run_cmd(cmd, cwd=None, check=True, timeout=None):
        calls.append({"cmd": cmd, "cwd": cwd, "check": check, "timeout": timeout})
        return SimpleNamespace(returncode=0, stdout="", stderr="")

    monkeypatch.setattr(runner, "run_cmd", fake_run_cmd)

    result = runner.prepare_workspace_dir("repo", "ws")

    assert result == target
    assert any("worktree" in " ".join(call["cmd"]) for call in calls)
    assert not target.exists()


def test_dispatch_agent_for_pr_validates_fields(tmp_path, monkeypatch):
    runner.WORKSPACE_ROOT_BASE = tmp_path

    class FakeDispatcher:
        def analyze_task_and_create_agents(self, _description):
            return []

        def create_dynamic_agent(self, _spec):
            return True

    assert runner.dispatch_agent_for_pr(FakeDispatcher(), {"repo_full": None}) is False


def test_dispatch_agent_for_pr_injects_workspace(monkeypatch, tmp_path):
    runner.WORKSPACE_ROOT_BASE = tmp_path

    created_specs = []

    class FakeDispatcher:
        def analyze_task_and_create_agents(self, _description):
            return [{"id": "agent"}]

        def create_dynamic_agent(self, spec):
            created_specs.append(spec)
            return True

    pr = {"repo_full": "org/repo", "repo": "repo", "number": 5, "branch": "feature/x"}
    assert runner.dispatch_agent_for_pr(FakeDispatcher(), pr)
    assert created_specs
    workspace_config = created_specs[0].get("workspace_config")
    assert workspace_config
    assert "pr-5" in workspace_config["workspace_name"]

