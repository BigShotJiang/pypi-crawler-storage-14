"""Tests for synchromcp."""
