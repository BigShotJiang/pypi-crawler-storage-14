from django.apps import AppConfig


class DensConfig(AppConfig):
    name = "dens"
    label = "dens"
    verbose_name = "dens"
