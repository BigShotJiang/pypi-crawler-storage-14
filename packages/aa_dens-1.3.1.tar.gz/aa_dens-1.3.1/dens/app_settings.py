"""App settings."""

from app_utils.app_settings import clean_setting

DENS_ADMIN_NOTIFICATIONS_ENABLED = clean_setting(
    "DENS_ADMIN_NOTIFICATIONS_ENABLED", True
)

DENS_FORWARD_TIMER_TO_TIMERBOARD = clean_setting(
    "DENS_FORWARD_TIMER_TO_TIMERBOARD", True
)
