"""Security and sandbox management."""
