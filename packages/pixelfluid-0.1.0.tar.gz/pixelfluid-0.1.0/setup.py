# ============================
# setup.py for pip installation
# ============================
from setuptools import setup, find_packages

setup(
    name="pixelfluid",
    version="0.1.0",
    description="PixelFluid: SPH fluid simulation, humanoids (R6/R15), and rendering.",
    author="Chayce22315",
    packages=find_packages(),
    py_modules=["pixelfluid"],
    python_requires=">=3.8",
    install_requires=[
        "numpy>=1.22",
    ],
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
)