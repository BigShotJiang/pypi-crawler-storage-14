from setuptools import setup, find_packages

setup(
    name="marstar",
    version="0.1.0",
    packages=find_packages(),
    install_requires=[],
    python_requires=">=3.7",
    description="A package which can let you to play the Tic-Tac-Toe game with powerful AI play!",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    author="Marcy",
)

