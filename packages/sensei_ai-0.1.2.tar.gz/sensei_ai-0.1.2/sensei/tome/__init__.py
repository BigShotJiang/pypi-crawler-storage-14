"""Tome: Documentation repository from llms.txt sources."""

from sensei.tome.crawler import ingest_domain

__all__ = ["ingest_domain"]
