import os

from dotenv import load_dotenv

load_dotenv()

CONNEXITY_URL = "https://connexity-gateway-owzhcfagkq-uc.a.run.app/process/sdk"
CONNEXITY_METRICS_URL = "https://connexity-gateway-owzhcfagkq-uc.a.run.app/process/sdk/llm_latency"
