import json
import uuid
from typing import Optional, Literal, Dict, Any


class ErrorMessage:
    def __init__(
        self,
        content: str,
        source: Literal["transport", "frame_filter", "observer", "frame_processor", "frame_serializer", "switcher", "llm_service", "tts_service", "stt_service", "tool_call", "unknown"],
        message_id: Optional[str] = None,
        error_frame_id: Optional[int] = None,
        seconds_from_start: Optional[float] = None,
        code: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
    ):
        # Use message_id for deduplication if available, otherwise error_frame_id, otherwise seconds_from_start
        if message_id:
            dedup_key = message_id
        elif error_frame_id is not None:
            dedup_key = str(error_frame_id)
        elif seconds_from_start is not None:
            dedup_key = str(seconds_from_start)
        else:
            # Fallback: generate a random UUID
            dedup_key = str(uuid.uuid4())
        
        # generating uuid based on dedup_key to avoid registering duplicates
        self.id = uuid.uuid5(uuid.NAMESPACE_OID, dedup_key)
        self.message_id = message_id
        self.content = content
        self.source = source
        self.seconds_from_start = seconds_from_start
        self.code = code
        self.metadata = metadata or {}

    def to_dict(self) -> dict:
        return {
            "id": str(self.id),
            "content": self.content,
            "source": self.source,
            "seconds_from_start": self.seconds_from_start,
            "code": self.code,
            "metadata": self.metadata,
            "message_id": self.message_id,
        }
