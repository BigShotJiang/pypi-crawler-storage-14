import logging
import asyncio
from abc import abstractmethod
from dataclasses import dataclass
from typing import Literal, Optional, List, Dict, Any

from pipecat.transports.base_output import BaseOutputTransport

from connexity.calls.messages.error_message import ErrorMessage
from connexity.client import ConnexityClient
from connexity.pipecat.tool_observer import ToolObserverRegistry, ToolExecutionContext
from twilio.rest import Client
from pipecat.frames.frames import (
    BotStartedSpeakingFrame,
    BotStoppedSpeakingFrame,
    UserStartedSpeakingFrame,
    UserStoppedSpeakingFrame,
    TTSTextFrame,
    TranscriptionFrame,
    CancelFrame,
    FunctionCallInProgressFrame,
    FunctionCallResultFrame,
    LLMFullResponseStartFrame,
    TTSStartedFrame, EndFrame,
)
from pipecat.observers.base_observer import BaseObserver, FramePushed
from pipecat.audio.vad.vad_analyzer import VADParams
from pipecat.frames.frames import ErrorFrame

from pipecat.processors.frame_processor import FrameDirection
from pipecat.services.llm_service import LLMService
from pipecat.services.tts_service import TTSService
from pipecat.services.stt_service import STTService
from connexity.calls.base_call import BaseCall
from connexity.metrics.utils.twilio_module import TwilioCallManager
from connexity.metrics.utils.detect_interruption_loops import detect_interruption_loops
from connexity.calls.messages.user_message import UserMessage
from connexity.calls.messages.assistant_message import AssistantMessage
from connexity.calls.messages.tool_call_message import ToolCallMessage
from connexity.calls.messages.tool_result_message import ToolResultMessage
from connexity.metrics.utils.validate_json import validate_json
from connexity.utils.snapshot_error_frame import snapshot_error_frame, _extract_schema_from_entry, _schema_to_json

logger = logging.getLogger(__name__)

Role = Literal["user", "assistant", "tool_call"]


@dataclass
class Latency:
    tts: Optional[float] = None  # milliseconds
    llm: Optional[float] = None  # milliseconds
    stt: Optional[float] = None  # milliseconds
    vad: Optional[float] = None  # milliseconds

    def get_metrics(self):
        return {"tts": self.tts,
                "llm": self.llm,
                "stt": self.stt,
                "vad": self.vad}


@dataclass
class MessageData:
    role: Role
    start: Optional[float] = None  # seconds from call start
    end: Optional[float] = None    # seconds from call start
    content: str = ""
    latency: Optional[Latency] = None

    def has_valid_window(self) -> bool:
        return (
            self.start is not None
            and self.end is not None
            and self.content.strip() != ""
            and self.start < self.end
        )

    def reset(self) -> None:
        self.start = None
        self.end = None
        self.content = ""
        if self.latency:
            self.latency = Latency()  # reset subfields

    def get_metrics(self):
        return {"role": self.role,
                "start": self.start,
                "end": self.end,
                "content": self.content,
                "latency": self.latency}


@dataclass
class ToolCallData:
    role: Role = "tool_call"
    start: Optional[float] = None
    end: Optional[float] = None
    tool_call_id: Optional[str] = None
    function_name: Optional[str] = None
    arguments: Optional[str] = None
    content: str = ""


@dataclass
class InterruptionAttempt:
    start: float
    stt_words: int = 0
    first_transcript_at: Optional[float] = None
    saw_cancel: bool = False
    user_stop: Optional[float] = None
    bot_stop: Optional[float] = None


class InterfaceConnexityObserver(BaseObserver):

    MIN_SEPARATION = 0.5

    def __init__(self):
        super().__init__()
        self.call: BaseCall | None = None
        self.user_data = MessageData(role="user")
        self.assistant_data = MessageData(role="assistant", latency=Latency())
        self.tool_calls = ToolCallData()

        self.messages: List[Dict[str, Any]] = []

        # additional data for connexity
        self.sid = None
        self.twilio_client: Client | None = None
        self.final = False

        self.stt_start = None
        self.tts_start = None
        self.llm_start = None
        self.vad_stop_secs = None
        self.vad_start_secs = None

        # interruption tracking
        self._bot_speaking: bool = False
        self._current_user_is_interruption: bool = False
        self._active_interrupt: Optional["InterruptionAttempt"] = None
        self.INTERRUPT_MIN_WORDS = 3
        self.INTERRUPT_MIN_OVERLAP_SECS = 1.0
        self.INTERRUPT_EXPECT_CANCEL_WITHIN_SECS = 3.0

        # overlaps tracking for interruption loops detection
        self._overlap_active: bool = False
        self._overlap_start_ts: Optional[float] = None
        self._overlap_user_words: int = 0
        self._overlap_bot_words: int = 0
        self._overlap_interrupter: Optional[str] = None
        self._overlap_first_transcript_at: Optional[float] = None
        self._overlaps_summary: list[dict] = []

        # user VAD de-duplication and state
        self._user_speaking: bool = False
        self._last_user_start_ts: Optional[float] = None
        self._last_user_stop_ts: Optional[float] = None
        self.USER_EVENT_DEDUP_SECS = 0.1

        # error tasks tracking
        self._pending_error_tasks: list[asyncio.Task] = []

        # initialization state tracking
        self._initialized: bool = False
        self._initialization_failed: bool = False

        # tool execution observability
        self._tool_observer_registry = ToolObserverRegistry.get_instance()
        
        # verbose logging flag
        self._verbose: bool = False
        
        # latency peak detection
        self.latency_threshold_ms: float = 4000.0
        
        # message ID tracking for error association
        self._last_assistant_message_id: Optional[str] = None
        self._last_user_message_id: Optional[str] = None
        self._last_tool_call_message_id: Optional[str] = None
        self._tool_call_id_to_message_id: Dict[str, str] = {}  # Map tool_call_id to message_id

    @abstractmethod
    async def initialize(
        self,
        sid: str,
        agent_id: str,
        api_key: str,
        call_type: Literal["inbound", "outbound", "web"],
        vad_params: VADParams,
        env: Literal["development", "production"],
        vad_analyzer: str,
        phone_call_provider: str = None,
        user_phone_number: str = None,
        agent_phone_number: str = None,
        twilio_client: Client = None,
        daily_api_key: str = None,
        verbose: bool = False,
        latency_threshold_ms: Optional[float] = 4000.0
    ):
        self._verbose = verbose
        self.sid = sid
        self.twilio_client = TwilioCallManager(twilio_client)
        self.vad_stop_secs = vad_params.stop_secs
        self.vad_start_secs = vad_params.start_secs
        self.latency_threshold_ms = latency_threshold_ms

        connexity_client = ConnexityClient(api_key=api_key)
        self.call = await connexity_client.register_call(
            sid=sid,
            agent_id=agent_id,
            user_phone_number=user_phone_number,
            agent_phone_number=agent_phone_number,
            created_at=None,
            voice_engine="pipecat",
            call_type=call_type,
            phone_call_provider=phone_call_provider,
            stream=False,
            env=env,
            vad_analyzer=vad_analyzer
        )

    @staticmethod
    def _ns_to_s(ns: int) -> float:
        return ns / 1_000_000_000

    @staticmethod
    def _is_downstream_output(src: Any, direction: FrameDirection) -> bool:
        return isinstance(src, BaseOutputTransport) and direction == FrameDirection.DOWNSTREAM

    @staticmethod
    def _apply_min_separation(prev_time: Optional[float], current_time: float, min_sep: float) -> float:
        if prev_time is None or (current_time - prev_time) > min_sep:
            return current_time
        return prev_time

    def _log(self, message: str, category: str = "general", level: str = "debug", **kv: Any) -> None:
        parts = ["[Connexity SDK]", f"[{level.upper()}]", f"[{category.upper()}]", message]

        if kv:
            kv_str = " | ".join(f"{k}={v}" for k, v in kv.items())
            parts.append(kv_str)
        
        formatted_msg = " ".join(parts)

        if level == "debug":
            logger.debug(formatted_msg)
        elif level == "info":
            logger.info(formatted_msg)
        elif level == "warning":
            logger.warning(formatted_msg)
        elif level == "error":
            logger.error(formatted_msg)
        
        if self._verbose:
            print(formatted_msg, flush=True)

    @staticmethod
    def _debug(msg: str, **kv: Any) -> None:
        """Backward compatible static debug method."""
        if kv:
            msg = f"{msg} | " + " ".join(f"{k}={v}" for k, v in kv.items())
        logger.debug(f"Connexity SDK: {msg}")

    # --- event handlers ------------------------------------------------------

    @staticmethod
    def _trace_upstream(node, max_hops: int = 20) -> list:
        chain = []
        seen = set()
        cur = node
        for _ in range(max_hops):
            if cur is None or id(cur) in seen:
                break
            seen.add(id(cur))
            chain.append(cur)
            cur = getattr(cur, "_prev", None)
        return chain

    @staticmethod
    def _find_by_class_name(nodes: list, needle: str):
        result = []
        for n in nodes:
            if needle in n.__class__.__name__:
                result.append(n)
        return result

    @staticmethod
    def _get_switcher_active_service(switcher) -> object | None:
        strategy = getattr(switcher, "strategy", None)
        return getattr(strategy, "active_service", None) if strategy else None

    @staticmethod
    def _guess_provider(obj) -> str | None:
        hay = f"{obj.__class__.__module__}.{obj.__class__.__name__}".lower()

        tokens = [
            # LLM
            ("azure", "azure"),
            ("anthropic", "anthropic"),
            ("mistral", "mistral"),
            ("deepseek", "deepseek"),
            ("fireworks", "fireworks"),
            ("perplexity", "perplexity"),
            ("openrouter", "openrouter"),
            ("openpipe", "openpipe"),
            ("together", "together"),
            ("grok", "grok"),
            ("groq", "groq"),
            ("ollama", "ollama"),
            ("cerebras", "cerebras"),
            ("qwen", "qwen"),
            ("sambanova", "sambanova"),
            ("nim", "nvidia"),
            ("aws", "aws"),
            ("google", "google"),
            ("gemini", "google"),
            ("vertex", "google"),
            ("openai", "openai"),
            # STT
            ("assemblyai", "assemblyai"),
            ("deepgram", "deepgram"),
            ("speechmatics", "speechmatics"),
            ("soniox", "soniox"),
            ("gladia", "gladia"),
            ("ultravox", "ultravox"),
            ("whisper", "openai"),
            ("elevenlabs", "elevenlabs"),
            ("cartesia", "cartesia"),
            ("riva", "nvidia"),
            # TTS
            ("playht", "playht"),
            ("piper", "coqui"),
            ("xtts", "coqui"),
            ("hume", "hume"),
            ("lmnt", "lmnt"),
            ("neuphonic", "neuphonic"),
            ("minimax", "minimax"),
            ("rime", "rime"),
            # Other service families (safe to map to their own name)
            ("inworld", "inworld"),
            ("heygen", "heygen"),
            ("simli", "simli"),
            ("tavus", "tavus"),
            ("fal", "fal"),
            ("fish", "fish"),
            # generic fallbacks
            ("polly", "aws"),
            ("bedrock", "aws"),
            ("nvidia", "nvidia"),
        ]

        for token, provider in tokens:
            if token in hay:
                return provider
        return None

    @staticmethod
    def _extract_model_voice(service) -> tuple[str | None, str | None]:
        model = getattr(service, "model_name", None) or getattr(service, "_model_name", None)
        voice = getattr(service, "_voice_id", None) or getattr(service, "voice_id", None) or getattr(service, "voice",
                                                                                                     None)
        settings = getattr(service, "_settings", None)
        if isinstance(settings, dict):
            model = model or settings.get("model")
            voice = voice or settings.get("voice") or settings.get("voice_id")
        # Try adapter (LLM)
        get_ad = getattr(service, "get_llm_adapter", None)
        if callable(get_ad):
            try:
                ad = get_ad()
                model = model or getattr(ad, "model", None) or getattr(ad, "model_name", None)
            except Exception:
                pass
        return model, voice

    async def _update_service_timeline(
        self,
        frame: Any,
        src: Any,
        direction: FrameDirection,
        t: float,
    ) -> None:
        upstream_nodes = self._trace_upstream(src)

        families: list[tuple[Literal["stt", "llm", "tts"], type, bool, bool]] = [
            (
                "stt",
                STTService,
                isinstance(frame, TranscriptionFrame),
                False,
            ),
            (
                "llm",
                LLMService,
                isinstance(frame, LLMFullResponseStartFrame)
                and self._is_downstream_output(src, direction),
                False,
            ),
            (
                "tts",
                TTSService,
                isinstance(frame, TTSStartedFrame)
                and self._is_downstream_output(src, direction),
                True,
            ),
        ]

        for family, service_cls, should_process, include_voice in families:
            if not should_process:
                continue

            provider: Optional[str] = None
            model: Optional[str] = None
            voice: Optional[str] = None

            switchers = self._find_by_class_name(upstream_nodes, "ServiceSwitcher")
            for sw in switchers:
                active = self._get_switcher_active_service(sw)
                if active and isinstance(active, service_cls):
                    provider = self._guess_provider(active)
                    m, v = self._extract_model_voice(active)
                    model = m
                    if include_voice:
                        voice = v
                    break

            if provider is None and model is None:
                nodes = self._find_by_class_name(upstream_nodes, service_cls.__name__)
                node = nodes[0] if nodes else None
                if node:
                    provider = self._guess_provider(node)
                    m, v = self._extract_model_voice(node)
                    model = m
                    if include_voice:
                        voice = v

            if (
                provider is not None
                or model is not None
                or (include_voice and voice is not None)
            ):
                if family == "tts":
                    await self.call.update_service_timeline(
                        "tts",
                        provider=provider,
                        model=model,
                        voice=voice,
                        at_seconds=t,
                    )
                else:
                    await self.call.update_service_timeline(
                        family,
                        provider=provider,
                        model=model,
                        at_seconds=t,
                    )

    def _handle_latency_markers(self, frame: Any, src: Any, direction: FrameDirection, t: float) -> None:
        # User finished speaking -> STT starts
        if isinstance(frame, UserStoppedSpeakingFrame):
            self.stt_start = t

        # LLM full response begins (first token) => close STT latency
        if isinstance(frame, LLMFullResponseStartFrame) and self._is_downstream_output(src, direction):
            if self.stt_start is not None and self.assistant_data.latency.stt is None:
                self.llm_start = t
                stt_ms = (t - self.stt_start) * 1000
                self.assistant_data.latency.stt = stt_ms
                self.stt_start = None
                self._log("STT latency metric", category="metrics", level="debug", ms=stt_ms)

        # TTS start => close LLM latency
        if isinstance(frame, TTSStartedFrame) and self._is_downstream_output(src,
                                                                             direction) and self.tts_start is None:
            if self.llm_start is not None:
                llm_ms = (t - self.llm_start) * 1000
                self.assistant_data.latency.llm = llm_ms
                self._log("LLM latency metric", category="metrics", level="debug", ms=llm_ms)
            self.tts_start = t

        # Bot audio actually starts => close TTS prepare latency
        if isinstance(frame, BotStartedSpeakingFrame) and self._is_downstream_output(src,
                                                                                     direction) and self.tts_start:
            tts_ms = (t - self.tts_start) * 1000
            self.assistant_data.latency.tts = tts_ms
            self.tts_start = None
            self._log("TTS latency metric", category="metrics", level="debug", ms=tts_ms)

        # Cancellation seen (counts as successful interruption if attempt is active)
        if isinstance(frame, CancelFrame) and self._is_downstream_output(src, direction):
            if self._active_interrupt and self._bot_speaking:
                self._active_interrupt.saw_cancel = True
                self._log("Cancel frame during interruption attempt", category="interruption", level="debug", t=t)

    def _handle_bot_window(self, frame: Any, src: Any, direction: FrameDirection, t: float) -> None:
        if not self._is_downstream_output(src, direction):
            return

        if isinstance(frame, BotStartedSpeakingFrame):
            self._bot_speaking = True
            # start overlap if user is already speaking
            if self._user_speaking and not self._overlap_active:
                self._start_overlap(t, interrupter="bot")
            self.assistant_data.start = self._apply_min_separation(
                self.assistant_data.start, t, self.MIN_SEPARATION
            )
            self._log("Bot started speaking", category="audio", level="debug", t=t)

        elif isinstance(frame, BotStoppedSpeakingFrame):
            self.assistant_data.end = self._apply_min_separation(
                self.assistant_data.end, t, self.MIN_SEPARATION
            )
            self._log("Bot stopped speaking", category="audio", level="debug", t=t)
            if self._active_interrupt:
                self._finalize_interrupt_attempt(t, "bot_stopped")
            # end overlap when bot stops
            if self._overlap_active:
                self._end_overlap(t)
            self._bot_speaking = False

    def _handle_user_window(self, frame: Any, src: Any, direction: FrameDirection, t: float) -> None:
        if isinstance(frame, UserStartedSpeakingFrame):
            if self._user_speaking:
                if self._last_user_start_ts is not None and (t - self._last_user_start_ts) < self.USER_EVENT_DEDUP_SECS:
                    return
                return

            self._user_speaking = True
            self._last_user_start_ts = t
            # include VAD pre-roll to approximate true start
            vad_start = t
            true_start = vad_start - (self.vad_start_secs or 0.0)
            self.user_data.start = true_start
            if self._bot_speaking:
                self._current_user_is_interruption = True
                self._start_interrupt_attempt(true_start)
                # also track general overlap (regardless of direction)
                if not self._overlap_active:
                    self._start_overlap(true_start, interrupter="user")
            else:
                self._current_user_is_interruption = False
            self._log("User started speaking", category="audio", level="debug", t=t, true_start=true_start, is_interruption=self._current_user_is_interruption)

        elif isinstance(frame, UserStoppedSpeakingFrame):
            if not self._user_speaking:
                if self._last_user_stop_ts is not None and (t - self._last_user_stop_ts) < self.USER_EVENT_DEDUP_SECS:
                    return
                return

            self._user_speaking = False
            self._last_user_stop_ts = t

            self.user_data.end = t
            self._log("User stopped speaking", category="audio", level="debug", t=t)
            if self._active_interrupt:
                self._finalize_interrupt_attempt(t, "user_stopped")
            # end overlap when user stops
            if self._overlap_active:
                self._end_overlap(t)

    async def _handle_tool_call_start(self, frame: Any, src: Any, direction: FrameDirection, t: float) -> None:
        if not (isinstance(frame, FunctionCallInProgressFrame) and self._is_downstream_output(src, direction)):
            return

        self.tool_calls.start = self._apply_min_separation(self.tool_calls.start, t, self.MIN_SEPARATION)
        self.tool_calls.tool_call_id = frame.tool_call_id
        self.tool_calls.function_name = frame.function_name
        self.tool_calls.arguments = frame.arguments

        tool_call_msg = ToolCallMessage(
            arguments=frame.arguments,
            tool_call_id=frame.tool_call_id,
            content="",
            name=frame.function_name,
            seconds_from_start=t,
        )
        await self.call.register_message(tool_call_msg)
        self._last_tool_call_message_id = tool_call_msg.id
        self._tool_call_id_to_message_id[frame.tool_call_id] = tool_call_msg.id
        self._log("Function call started", category="tool", level="info",
                  tool_call_id=frame.tool_call_id, function=frame.function_name, args=str(frame.arguments))

    async def _handle_tool_call_end(self, frame: Any, src: Any, direction: FrameDirection, t: float) -> None:
        if not (isinstance(frame, FunctionCallResultFrame) and self._is_downstream_output(src, direction)):
            return

        self.tool_calls.end = self._apply_min_separation(self.tool_calls.end, t, self.MIN_SEPARATION)
        self.tool_calls.content = frame.result

        if frame.result is None:
            is_json = False
            json_data = None
        else:
            is_json, json_data = validate_json(frame.result)
        
        execution_ctx: Optional[ToolExecutionContext] = await self._tool_observer_registry.get_execution(
            frame.tool_call_id
        )
        
        # Log tool execution data
        self._log("Tool execution data retrieved", category="tool", level="info", tool_call_id=frame.tool_call_id)
        
        if execution_ctx:
            self._log("Execution context found", category="tool", level="info",
                     tool_name=execution_ctx.tool_name,
                     duration_ms=execution_ctx.duration_ms,
                     success=execution_ctx.success,
                     arguments=execution_ctx.arguments,
                     start_time=execution_ctx.start_time,
                     end_time=execution_ctx.end_time)
            
            if execution_ctx.result is not None:
                result_preview = str(execution_ctx.result)
                if len(result_preview) > 200:
                    result_preview = result_preview[:200] + "..."
                self._log("Tool execution result", category="tool", level="info", result=result_preview)
            
            if execution_ctx.error:
                error_msg = f"{type(execution_ctx.error).__name__}: {execution_ctx.error}"
                self._log("Tool execution error", category="tool", level="error",
                         error=error_msg,
                         tool_name=execution_ctx.tool_name,
                         tool_call_id=execution_ctx.tool_call_id)
                if execution_ctx.error_traceback:
                    traceback_preview = execution_ctx.error_traceback[:500] + "..." if len(execution_ctx.error_traceback) > 500 else execution_ctx.error_traceback
                    self._log("Tool execution traceback", category="tool", level="error", traceback=traceback_preview)
        else:
            self._log("No execution context found in registry", category="tool", level="warning",
                     tool_call_id=frame.tool_call_id,
                     note="Tool may not have @observe_tool() decorator")
        
        self._log("Pipecat result", category="tool", level="info",
                 result=json_data if is_json else frame.result,
                 result_type="JSON" if is_json else "string")
        
        # Build metadata if available
        metadata = None
        if execution_ctx:
            metadata = {
                "tool_name": execution_ctx.tool_name,
                "duration_ms": execution_ctx.duration_ms,
                "success": execution_ctx.success,
                "arguments": execution_ctx.arguments,
            }
            
            # If execution failed, register as error
            if not execution_ctx.success and execution_ctx.error:
                tool_call_message_id = self._tool_call_id_to_message_id.get(execution_ctx.tool_call_id)
                err = ErrorMessage(
                    content=f"Tool execution error: {execution_ctx.error}",
                    source="tool_call",
                    message_id=tool_call_message_id,
                    seconds_from_start=execution_ctx.start_time or t,
                    code="tool_execution_error",
                    metadata={
                        "tool_name": execution_ctx.tool_name,
                        "tool_call_id": execution_ctx.tool_call_id,
                        "arguments": execution_ctx.arguments,
                        "duration_ms": execution_ctx.duration_ms,
                        "error_type": type(execution_ctx.error).__name__ if execution_ctx.error else None,
                        "error_message": str(execution_ctx.error) if execution_ctx.error else None,
                        "error_traceback": execution_ctx.error_traceback,
                        "timeout_triggered": execution_ctx.timeout_triggered,
                        "timeout_seconds": execution_ctx.timeout_seconds if execution_ctx.timeout_triggered else None,
                    }
                )
                await self.call.register_error(err)
            
            self._log("Tool execution metrics", category="tool", level="info",
                     tool=execution_ctx.tool_name,
                     duration_ms=execution_ctx.duration_ms,
                     success=execution_ctx.success)
            
            # Clean up after processing
            await self._tool_observer_registry.clear_execution(frame.tool_call_id)
        
        # Register the tool result message with metadata
        await self.call.register_message(
            ToolResultMessage(
                content="",
                tool_call_id=frame.tool_call_id,
                result_type="JSON" if is_json else "string",
                result=json_data if is_json else frame.result,
                seconds_from_start=t,
                metadata=metadata,
            )
        )
        self._log("Function call ended", category="tool", level="info",
                  tool_call_id=frame.tool_call_id, function=getattr(frame, "function_name", None))

    def _start_interrupt_attempt(self, t: float) -> None:
        if self._active_interrupt is None:
            self._active_interrupt = InterruptionAttempt(start=t)
            self._log("Interruption attempt started", category="interruption", level="debug", t=t)

    def _finalize_interrupt_attempt(self, t: float, reason: str) -> None:
        attempt = self._active_interrupt
        if not attempt:
            return

        if reason == "user_stopped" and attempt.user_stop is None:
            attempt.user_stop = t
        if reason == "bot_stopped" and attempt.bot_stop is None:
            attempt.bot_stop = t

        stop_t = attempt.user_stop or attempt.bot_stop or t
        overlap_secs = max(0.0, stop_t - attempt.start)

        meaningful_attempt = (attempt.stt_words >= self.INTERRUPT_MIN_WORDS) or \
                             (overlap_secs >= self.INTERRUPT_MIN_OVERLAP_SECS)

        time_since_start = stop_t - attempt.start
        no_cancel_within_threshold = (not attempt.saw_cancel) and \
                                     (time_since_start >= self.INTERRUPT_EXPECT_CANCEL_WITHIN_SECS)

        unsuccessful = meaningful_attempt and no_cancel_within_threshold

        if unsuccessful:
            root_cause = "unknown"
            if attempt.stt_words == 0 and overlap_secs >= self.INTERRUPT_MIN_OVERLAP_SECS:
                root_cause = "no_transcripts_during_overlap"

            err = ErrorMessage(
                content="Unsuccessful user interruption (agent continued speaking)",
                source="observer",
                message_id=self._last_user_message_id,
                seconds_from_start=attempt.start,
                code="unsuccessful_interruption",
                metadata={
                    "attempt": {
                        "start": attempt.start,
                        "user_stop": attempt.user_stop,
                        "bot_stop": attempt.bot_stop,
                        "overlap_secs": overlap_secs,
                        "stt_words": attempt.stt_words,
                        "first_transcript_at": attempt.first_transcript_at,
                        "saw_cancel": attempt.saw_cancel,
                    },
                    "thresholds": {
                        "min_words": self.INTERRUPT_MIN_WORDS,
                        "min_overlap_secs": self.INTERRUPT_MIN_OVERLAP_SECS,
                        "expect_cancel_within_secs": self.INTERRUPT_EXPECT_CANCEL_WITHIN_SECS,
                        "vad_start_secs": self.vad_start_secs,
                        "vad_stop_secs": self.vad_stop_secs,
                    },
                    "root_cause_heuristic": root_cause,
                },
            )
            self._log("Unsuccessful interruption detected", category="interruption", level="warning",
                     overlap_secs=overlap_secs, words=attempt.stt_words)
            try:
                task = asyncio.create_task(self.call.register_error(err))
                self._pending_error_tasks.append(task)
            except Exception:
                pass

        self._active_interrupt = None

    def _accumulate_content(self, frame: Any, src: Any, direction: FrameDirection, t: float) -> None:
        # STT text (guard against non-STT sources)
        if isinstance(frame, TranscriptionFrame) and getattr(src, "name", "").find("STTService") != -1:
            self.user_data.content += frame.text
            if self._bot_speaking:
                if self._active_interrupt is None:
                    self._start_interrupt_attempt(t)
                words = [w for w in frame.text.strip().split() if w]
                if words and self._active_interrupt:
                    self._active_interrupt.stt_words += len(words)
                    if self._active_interrupt.first_transcript_at is None:
                        self._active_interrupt.first_transcript_at = t
                # count user words said during overlap
                if self._overlap_active and words:
                    self._overlap_user_words += len(words)
                    if self._overlap_interrupter == "user" and self._overlap_first_transcript_at is None:
                        self._overlap_first_transcript_at = t

        # TTS text (bot message accumulation)
        if isinstance(frame, TTSTextFrame) and self._is_downstream_output(src, direction):
            self.assistant_data.content += frame.text + " "
            # count bot words contributing to an overlap window
            if self._overlap_active:
                bot_words = [w for w in (frame.text or "").strip().split() if w]
                if bot_words:
                    self._overlap_bot_words += len(bot_words)

    async def _maybe_flush_user(self) -> None:
        if not self.user_data.has_valid_window():
            return

        self.messages.append(self.user_data.get_metrics())
        user_msg = UserMessage(
            content=self.user_data.content,
            seconds_from_start=self.user_data.start,
            is_interruption=self._current_user_is_interruption,
        )
        await self.call.register_message(user_msg)
        self._last_user_message_id = user_msg.id
        self._log("User data collected", category="message", level="debug", 
                  content_len=len(self.user_data.content or ""),
                  is_interruption=self._current_user_is_interruption)
        self.user_data.reset()
        self._current_user_is_interruption = False

    async def _maybe_flush_assistant(self) -> None:
        if not self.assistant_data.has_valid_window():
            return

        # VAD-based latency to first audio from end of last user utterance
        # Find the last user message that ended BEFORE this assistant response started
        latency_ms: Optional[float] = None
        triggering_user_msg = None
        
        for msg in reversed(self.messages):
            if msg.get("role") == "user" and msg.get("end") is not None:
                # Check if this user message ended before the assistant started speaking
                if msg["end"] <= self.assistant_data.start:
                    triggering_user_msg = msg
                    break
        
        if triggering_user_msg:
            last_user_end_vad = triggering_user_msg["end"]
            real_end = last_user_end_vad - (self.vad_stop_secs or 0.0)
            latency_ms = (self.assistant_data.start - real_end) * 1000
            self.assistant_data.latency.vad = (self.vad_stop_secs or 0.0) * 1000

        assistant_msg = AssistantMessage(
            content=self.assistant_data.content,
            time_to_first_audio=latency_ms,
            seconds_from_start=self.assistant_data.start,
            latency=self.assistant_data.latency.get_metrics(),
        )
        self.messages.append(self.assistant_data.get_metrics())
        await self.call.register_message(assistant_msg)
        self._last_assistant_message_id = assistant_msg.id

        # Check for latency peak error
        if latency_ms is not None and self.latency_threshold_ms is not None and latency_ms > self.latency_threshold_ms:
            err = ErrorMessage(
                content=f"Latency peak detected: {latency_ms:.2f}ms exceeds threshold of {self.latency_threshold_ms}ms",
                source="observer",
                message_id=assistant_msg.id,
                seconds_from_start=self.assistant_data.start,
                code="latency_peak",
                metadata={
                    "latency_ms": latency_ms,
                    "threshold_ms": self.latency_threshold_ms,
                    "assistant_start": self.assistant_data.start,
                    "triggering_user_end": triggering_user_msg.get("end") if triggering_user_msg else None,
                    "latency_breakdown": self.assistant_data.latency.get_metrics(),
                },
            )
            self._log("Latency peak detected", category="latency", level="warning",
                     latency_ms=latency_ms, threshold_ms=self.latency_threshold_ms)
            try:
                task = asyncio.create_task(self.call.register_error(err))
                self._pending_error_tasks.append(task)
            except Exception:
                pass

        self._log("Bot data collected", category="message", level="debug",
                  content_len=len(self.assistant_data.content or ""), 
                  t_start=self.assistant_data.start,
                  time_to_first_audio=latency_ms)
        self.assistant_data.reset()

    async def _extract_tool_schemas(self, frame: Any, src: Any, direction: FrameDirection) -> None:
        if not (isinstance(frame, LLMFullResponseStartFrame) and self._is_downstream_output(src, direction)):
            return
        
        upstream_nodes = self._trace_upstream(src)
        
        llm_service = None
        for node in upstream_nodes:
            if "switcher" in node.__class__.__name__.lower():
                try:
                    strategy = getattr(node, "strategy", None)
                    if strategy:
                        active_service = getattr(strategy, "active_service", None)
                        if isinstance(active_service, LLMService):
                            llm_service = active_service
                            break
                except Exception:
                    continue
            elif isinstance(node, LLMService):
                llm_service = node
                break
        
        if not llm_service:
            return
        
        functions_dict = getattr(llm_service, "_functions", None)
        if not isinstance(functions_dict, dict):
            return
        
        tool_schemas = []
        for func_name, registry_item in functions_dict.items():
            try:
                schema_obj = _extract_schema_from_entry(registry_item)
                if not schema_obj:
                    continue
                
                schema_json = _schema_to_json(schema_obj)
                if not isinstance(schema_json, dict):
                    continue
                
                # Keep only underscore-prefixed properties and remove underscores
                cleaned_schema = {}
                for key, value in schema_json.items():
                    if key.startswith("_"):
                        cleaned_key = key[1:]
                        cleaned_schema[cleaned_key] = value
                
                if "name" not in cleaned_schema:
                    cleaned_schema["name"] = func_name
                
                if cleaned_schema:
                    tool_schemas.append(cleaned_schema)
            except Exception:
                continue
        
        if tool_schemas:
            self._log(f"Extracted {len(tool_schemas)} tool schemas", category="tool", level="info", count=len(tool_schemas))
            await self.call.register_tool_schemas(tool_schemas)

    async def _extract_system_prompts(self, frame: Any, src: Any, direction: FrameDirection) -> None:
        if not (isinstance(frame, LLMFullResponseStartFrame) and self._is_downstream_output(src, direction)):
            return

        upstream_nodes = self._trace_upstream(src)

        for node in upstream_nodes:
            if "contextaggregator" in node.__class__.__name__.lower():
                self._log("Context aggregator found", category="system", level="debug", node_class=node.__class__.__name__)
                messages_attr = getattr(node, "messages", None)
                if isinstance(messages_attr, list):
                    for msg in messages_attr:
                        if isinstance(msg, dict) and msg.get("role") == "system":
                            content = msg.get("content", "")
                            if content and isinstance(content, str):
                                self._log("System prompt extracted", category="system", level="info",
                                         content_len=len(content),
                                         preview=content[:50] + "..." if len(content) > 50 else content)
                                await self.call.register_system_prompts(content)

    def _start_overlap(self, start_t: float, interrupter: str) -> None:
        self._overlap_active = True
        self._overlap_start_ts = start_t
        self._overlap_user_words = 0
        self._overlap_bot_words = 0
        self._overlap_interrupter = interrupter
        self._overlap_first_transcript_at = None

    def _end_overlap(self, end_t: float) -> None:
        if self._overlap_active and self._overlap_start_ts is not None:
            interrupter = self._overlap_interrupter
            interrupter_words = (
                self._overlap_user_words if interrupter == "user" else self._overlap_bot_words
            ) if interrupter in ("user", "bot") else 0

            start_t = self._overlap_start_ts
            overlap_record = {
                "start": start_t,
                "first_transcript_at": self._overlap_first_transcript_at,
                "interrupter": interrupter,
                "interrupter_words": interrupter_words,
                "end": end_t,
            }
            try:
                self._overlaps_summary.append(overlap_record)
            except Exception as e:
                self._log("Overlap record failed", category="interruption", level="error", error=str(e))
        self._overlap_active = False
        self._overlap_start_ts = None
        self._overlap_user_words = 0
        self._overlap_bot_words = 0
        self._overlap_interrupter = None
        self._overlap_first_transcript_at = None

        # --- main entry ----------------------------------------------------------

    async def on_push_frame(self, data: FramePushed) -> None:
        if self._initialization_failed or not self._initialized:
            return

        try:
            await self._on_push_frame_impl(data)
        except Exception as e:
            self._log(f"Internal error (frame will be skipped): {type(e).__name__}: {e}",
                     category="error", level="error", error_type=type(e).__name__, error=str(e))
            logger.error(f"Connexity SDK: Internal error (frame will be skipped): {type(e).__name__}: {e}", exc_info=True)

    async def _on_push_frame_impl(self, data: FramePushed) -> None:
        src = data.source
        frame = data.frame
        direction = data.direction
        t = self._ns_to_s(data.timestamp)

        # 0) update service timelines (STT/LLM/TTS)
        await self._update_service_timeline(frame, src, direction, t)

        # 1) latency anchors / metrics
        self._handle_latency_markers(frame, src, direction, t)

        # 2) speaking windows
        self._handle_bot_window(frame, src, direction, t)
        self._handle_user_window(frame, src, direction, t)

        # 3) tool-call lifecycle
        await self._handle_tool_call_start(frame, src, direction, t)
        await self._handle_tool_call_end(frame, src, direction, t)

        # 4) accumulate text content
        self._accumulate_content(frame, src, direction, t)

        # 5) flush messages if windows are valid
        await self._maybe_flush_user()
        await self._maybe_flush_assistant()

        # 6) Record errors from error frames
        if isinstance(frame, ErrorFrame):
            current_error = snapshot_error_frame(frame, self._ns_to_s(data.timestamp))
            self._log("Snapshot of error frame", category="error", level="debug", error_data=current_error.__dict__)
            await self.call.register_error(current_error)

        # 7) Extract system prompts and tool schemas from LLM-related frames
        await self._extract_system_prompts(frame, src, direction)
        await self._extract_tool_schemas(frame, src, direction)

        # 8) handle cancellation (ensure finalization runs exactly once)
        if (isinstance(frame, CancelFrame) or isinstance(frame, EndFrame)) and not self.final:
            if self._active_interrupt:
                self._finalize_interrupt_attempt(t, "call_ending")
            if self._overlap_active:
                self._end_overlap(t)
            loops: list[dict] = []
            try:
                loops = detect_interruption_loops(overlaps=self._overlaps_summary)
            except Exception as exc:
                self._log("Interruption loop detection failed", category="interruption", level="error", error=str(exc))

            for loop in loops:
                try:
                    loop_start = loop.get("start") or 0
                    loop_err = ErrorMessage(
                        content="Interruption loop (series of interruptions occurring at short intervals)",
                        source="observer",
                        seconds_from_start=loop_start,
                        code="interruption_loop",
                        metadata=loop,
                    )
                    task = asyncio.create_task(self.call.register_error(loop_err))
                    self._pending_error_tasks.append(task)
                except Exception as exc:
                    self._log("Interruption loop error registration failed", category="interruption", level="error", error=str(exc))
            self.final = True
            if self._pending_error_tasks:
                await asyncio.gather(*self._pending_error_tasks, return_exceptions=True)
            await self.post_process_data()

    @abstractmethod
    async def post_process_data(self):
        ...
