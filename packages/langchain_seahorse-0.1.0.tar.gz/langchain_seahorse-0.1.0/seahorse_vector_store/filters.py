"""Metadata filter conversion logic for Seahorse VectorStore SDK.

⚠️ 중요: Seahorse의 metadata 컬럼은 String(LargeUtf8) 타입이며 JSONB 연산자를 지원하지 않습니다.
따라서 LIKE 패턴을 사용하여 JSON 문자열 매칭을 수행합니다.
현재는 equal 연산만 지원됩니다.
"""

from typing import Any, Dict


def convert_filter_to_sql(filter_dict: Dict[str, Any]) -> str:
    """LangChain 필터를 SQL WHERE 절로 변환.

    ⚠️ 중요: metadata 컬럼은 String 타입이며 JSONB 연산자 미지원
    - LIKE 패턴을 사용하여 JSON 문자열 매칭
    - 현재는 equal 연산만 지원
    - Flat한 JSON만 지원 (중첩 불가)

    Args:
        filter_dict: LangChain 스타일 필터

    Returns:
        SQL WHERE 절 문자열

    Raises:
        ValueError: 지원하지 않는 연산자나 값 타입일 경우

    Examples:
        >>> convert_filter_to_sql({"source": "doc.pdf"})
        'metadata LIKE \\\'%"source": "doc.pdf"%\\\''

        >>> convert_filter_to_sql({"page": 10})
        'metadata LIKE \\\'%"page": 10%\\\''

        >>> convert_filter_to_sql({"source": "doc.pdf", "page": 1})
        'metadata LIKE \\\'%"source": "doc.pdf"%\\\' AND metadata LIKE \\\'%"page": 1%\\\''
    """
    conditions = []

    for key, value in filter_dict.items():
        if isinstance(value, dict):
            # 연산자 포함
            condition = _convert_operator(key, value)
        else:
            # 단순 동등 비교
            condition = _convert_equality(key, value)

        conditions.append(condition)

    return " AND ".join(conditions)


def _convert_equality(key: str, value: Any) -> str:
    """단순 동등 비교를 SQL LIKE 패턴으로 변환.

    Args:
        key: 메타데이터 키
        value: 메타데이터 값

    Returns:
        SQL LIKE 조건 문자열

    Raises:
        ValueError: 지원하지 않는 값 타입일 경우
    """
    # metadata는 String 타입이므로 LIKE 패턴 사용
    # JSON 저장 시 json.dumps의 공백 처리를 고려해야 함
    if isinstance(value, bool):
        # bool은 true/false (소문자, JSON 표준)
        # ⚠️ bool은 isinstance(value, int)보다 먼저 체크해야 함 (bool은 int의 서브클래스)
        bool_str = "true" if value else "false"
        # 공백 유무에 관계없이 매칭되도록 % 사용
        return f"metadata LIKE '%\"{key}\":%{bool_str}%'"
    elif isinstance(value, str):
        # JSON 형식으로 LIKE 패턴 생성
        # "key": "value" 또는 "key":"value" 모두 매칭되도록
        # SQL에서 작은따옴표만 이스케이프
        escaped_value = value.replace("'", "''")  # SQL 작은따옴표 이스케이프
        # 공백이 있을 수도 없을 수도 있으므로 %로 처리
        return f'metadata LIKE \'%"{key}":%"{escaped_value}"%\''
    elif isinstance(value, (int, float)):
        # 숫자는 따옴표 없이
        # 공백 유무에 관계없이
        return f"metadata LIKE '%\"{key}\":%{value}%'"
    elif value is None:
        # null은 JSON에서 null (소문자)
        return f"metadata LIKE '%\"{key}\":%null%'"
    else:
        raise ValueError(f"Unsupported value type: {type(value)}")


def _convert_operator(key: str, op_dict: Dict[str, Any]) -> str:
    """연산자를 SQL 조건으로 변환.

    ⚠️ 현재는 equal 연산($eq)만 지원 (LIKE 패턴)
    다른 연산자($gt, $lt 등)는 metadata가 String이므로 정확한 비교 불가능

    Args:
        key: 메타데이터 키
        op_dict: 연산자와 값을 포함하는 딕셔너리

    Returns:
        SQL 조건 문자열

    Raises:
        ValueError: 지원하지 않는 연산자일 경우
    """
    if not op_dict:
        raise ValueError(f"Empty operator dict for key '{key}'")

    op, value = list(op_dict.items())[0]

    if op == "$eq":
        return _convert_equality(key, value)
    else:
        # 다른 연산자는 현재 미지원
        raise ValueError(
            f"Operator '{op}' is not supported. "
            f"metadata column is String type and only equality check ($eq) is supported."
        )
