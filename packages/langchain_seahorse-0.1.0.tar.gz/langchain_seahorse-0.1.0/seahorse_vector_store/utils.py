"""Utility functions for Seahorse VectorStore SDK."""

import hashlib
from typing import Any, Dict, Iterator, List, Tuple

# 배치 크기 설정 (확인 완료)
DEFAULT_BATCH_SIZE = 1024  # API 기본값과 동일
SMALL_BATCH_SIZE = 100  # 작은 배치용
MAX_JSON_SIZE = 20 * 1024 * 1024  # 20MB (JSON 페이로드 제한)


def generate_pk(content: str, chunk_id: int = 0) -> str:
    """Primary Key 생성.

    Seahorse API Gateway의 Primary Key 생성 규칙을 따릅니다:
    - Document ID: SHA-512 해시
    - 구분자: ASCII 30 문자 (\\x1E)
    - Chunk ID: 0부터 시작하는 정수

    Args:
        content: 문서 내용
        chunk_id: 청크 ID (기본: 0)

    Returns:
        생성된 Primary Key (형식: "{doc_id}\\x1e{chunk_id}")

    Examples:
        >>> pk = generate_pk("Hello, world!", 0)
        >>> print(pk)
        'abc123...xyz\\x1e0'
    """
    # Document ID: SHA-512 해시
    doc_id = hashlib.sha512(content.encode()).hexdigest()

    # 포맷: {doc_id}\x1e{chunk_id}
    return f"{doc_id}\x1e{chunk_id}"


def batch_texts(
    texts: List[str],
    metadatas: List[Dict[str, Any]],
    batch_size: int = DEFAULT_BATCH_SIZE,
) -> Iterator[Tuple[List[str], List[Dict[str, Any]]]]:
    """텍스트와 메타데이터를 배치로 나누기.

    Args:
        texts: 분할할 텍스트 목록
        metadatas: 메타데이터 목록
        batch_size: 배치당 항목 수 (기본: 1024)

    Yields:
        (텍스트 배치, 메타데이터 배치) 튜플

    Examples:
        >>> texts = ["text1", "text2", "text3"]
        >>> metadatas = [{"id": 1}, {"id": 2}, {"id": 3}]
        >>> for text_batch, meta_batch in batch_texts(texts, metadatas, batch_size=2):
        ...     print(len(text_batch))
        2
        1
    """
    for i in range(0, len(texts), batch_size):
        yield (
            texts[i : i + batch_size],
            metadatas[i : i + batch_size],
        )


def estimate_json_size(data: Any) -> int:
    """JSON 데이터의 대략적인 크기를 바이트 단위로 추정.

    Args:
        data: 크기를 추정할 데이터

    Returns:
        추정된 크기 (bytes)
    """
    import json

    return len(json.dumps(data, ensure_ascii=False).encode("utf-8"))
