"""Seahorse VectorStore implementation for LangChain."""

import json
from typing import Any, Dict, Iterable, List, Optional, Tuple

from langchain_core.documents import Document
from langchain_core.embeddings import Embeddings
from langchain_core.vectorstores import VectorStore

from .client import SeahorseClient
from .filters import convert_filter_to_sql
from .utils import DEFAULT_BATCH_SIZE, batch_texts, generate_pk


class SeahorseVectorStore(VectorStore):
    """Seahorse API Gateway VectorStore implementation.

    이 클래스는 LangChain의 VectorStore 인터페이스를 구현하여
    Seahorse API Gateway를 벡터 저장소로 사용할 수 있게 합니다.

    Args:
        api_key: Seahorse API key
        base_url: Seahorse API base URL (테이블별 고유 URL)
        embedding: LangChain Embeddings instance (외부 임베딩 사용 시 필수)
        use_builtin_embedding: Seahorse 내장 임베딩 사용 여부 (기본: True)
        index_name: 벡터 컬럼명 (기본: "embedding")
        **kwargs: 추가 인자

    Note:
        Seahorse의 Inference API(/v1/inference/*)는 base_url로 호출할 수 없습니다.
        따라서 use_builtin_embedding=True 일 때는 /v1/data/embedding을 사용하고,
        외부 임베딩을 사용하려면 embedding 파라미터를 제공해야 합니다.

    Attributes:
        _client: SeahorseClient instance
        _embedding: Embeddings instance (외부 임베딩 사용 시)
        _use_builtin_embedding: 내장 임베딩 사용 여부
        _index_name: 벡터 컬럼명

    Examples:
        >>> from seahorse_vector_store import SeahorseVectorStore
        >>>
        >>> # Seahorse 내장 임베딩 사용
        >>> vectorstore = SeahorseVectorStore(
        ...     api_key="your-api-key",
        ...     base_url="https://455fe13765664952bed80e7c22dd3436.api.seahorse.dnotitia.ai"
        ... )
        >>>
        >>> # 텍스트 추가
        >>> ids = vectorstore.add_texts(
        ...     texts=["Hello, world!", "LangChain is awesome!"],
        ...     metadatas=[{"source": "doc1.txt"}, {"source": "doc2.txt"}]
        ... )
        >>>
        >>> # 검색
        >>> docs = vectorstore.similarity_search("greeting", k=2)
        >>>
        >>> # 외부 임베딩 사용
        >>> from langchain_openai import OpenAIEmbeddings
        >>> vectorstore = SeahorseVectorStore(
        ...     api_key="your-api-key",
        ...     base_url="https://455fe13765664952bed80e7c22dd3436.api.seahorse.dnotitia.ai",
        ...     embedding=OpenAIEmbeddings(),
        ...     use_builtin_embedding=False
        ... )
    """

    def __init__(
        self,
        api_key: str,
        base_url: str,
        embedding: Optional[Embeddings] = None,
        use_builtin_embedding: bool = True,
        index_name: str = "embedding",
        **kwargs: Any,
    ) -> None:
        """Initialize SeahorseVectorStore.

        Args:
            api_key: Seahorse API key
            base_url: Seahorse API base URL (테이블별 고유 URL)
            embedding: LangChain Embeddings instance (optional)
            use_builtin_embedding: Seahorse 내장 임베딩 사용 여부
            index_name: 벡터 컬럼명 (기본: "embedding")
            **kwargs: 추가 인자

        Raises:
            ValueError: use_builtin_embedding과 embedding 설정이 충돌할 경우
        """
        self._api_key = api_key
        self._base_url = base_url
        self._index_name = index_name
        self._use_builtin_embedding = use_builtin_embedding

        # SeahorseClient 초기화
        self._client = SeahorseClient(base_url=base_url, api_key=api_key)

        # Embedding 설정
        if use_builtin_embedding:
            if embedding is not None:
                raise ValueError(
                    "Cannot specify both use_builtin_embedding=True and embedding"
                )
            self._embedding = None
        else:
            if embedding is None:
                raise ValueError(
                    "Must provide embedding when use_builtin_embedding=False"
                )
            self._embedding = embedding

    @property
    def embeddings(self) -> Optional[Embeddings]:
        """Get the embeddings instance.

        Returns:
            Embeddings instance if external embedding is used, None otherwise
        """
        return self._embedding

    def add_texts(
        self,
        texts: Iterable[str],
        metadatas: Optional[List[Dict[str, Any]]] = None,
        **kwargs: Any,
    ) -> List[str]:
        """텍스트를 벡터 저장소에 추가.

        Args:
            texts: 추가할 텍스트 목록
            metadatas: 각 텍스트의 메타데이터 (optional)
            **kwargs: 추가 인자

        Returns:
            생성된 document ID 목록

        Raises:
            ValueError: texts와 metadatas의 길이가 다를 경우
            SeahorseAPIError: API 호출 실패

        Examples:
            >>> ids = vectorstore.add_texts(
            ...     texts=["text1", "text2"],
            ...     metadatas=[{"source": "doc1"}, {"source": "doc2"}]
            ... )
        """
        texts_list = list(texts)

        if metadatas is None:
            metadatas = [{} for _ in texts_list]
        elif len(metadatas) != len(texts_list):
            raise ValueError("metadatas must have same length as texts")

        if self._use_builtin_embedding:
            # Seahorse 내장 임베딩 사용
            return self._add_texts_with_builtin_embedding(texts_list, metadatas)
        else:
            # 외부 임베딩 사용
            return self._add_texts_with_external_embedding(texts_list, metadatas)

    def similarity_search(
        self,
        query: str,
        k: int = 4,
        filter: Optional[Dict[str, Any]] = None,
        **kwargs: Any,
    ) -> List[Document]:
        """자연어 쿼리로 유사 문서 검색.

        Args:
            query: 검색 쿼리 (자연어)
            k: 반환할 문서 수 (기본: 4)
            filter: 메타데이터 필터 (optional)
            **kwargs: 추가 인자 (ef_search 등)

        Returns:
            유사한 Document 목록

        Raises:
            SeahorseAPIError: API 호출 실패

        Examples:
            >>> docs = vectorstore.similarity_search("machine learning", k=5)
            >>> docs = vectorstore.similarity_search(
            ...     "AI research",
            ...     k=3,
            ...     filter={"source": "arxiv.pdf"}
            ... )
        """
        docs_and_scores = self.similarity_search_with_score(
            query, k=k, filter=filter, **kwargs
        )
        return [doc for doc, _ in docs_and_scores]

    def similarity_search_with_score(
        self,
        query: str,
        k: int = 4,
        filter: Optional[Dict[str, Any]] = None,
        **kwargs: Any,
    ) -> List[Tuple[Document, float]]:
        """유사도 점수와 함께 문서 검색.

        Args:
            query: 검색 쿼리
            k: 반환할 문서 수
            filter: 메타데이터 필터
            **kwargs: 추가 인자 (ef_search 등)

        Returns:
            (Document, score) 튜플 목록
            score는 distance 값 (작을수록 더 유사)

        Raises:
            SeahorseAPIError: API 호출 실패

        Examples:
            >>> docs_and_scores = vectorstore.similarity_search_with_score(
            ...     "neural networks",
            ...     k=5,
            ...     ef_search=100
            ... )
            >>> for doc, score in docs_and_scores:
            ...     print(f"Score: {score}, Content: {doc.page_content[:50]}")
        """
        # 필터를 SQL WHERE 절로 변환
        filter_sql = convert_filter_to_sql(filter) if filter else None

        # ef_search 파라미터 추출 (기본값: k * 2, 최대 500)
        ef_search = kwargs.get("ef_search", min(k * 2, 500))

        # projection 설정 (id, text, metadata, distance 필요)
        projection = "id, text, metadata, distance"

        # Semantic search API 호출 (filter 지원!)
        results = self._client.semantic_search(
            query=query,
            top_k=k,
            index_name=self._index_name,
            ef_search=ef_search,
            projection=projection,
            filter_sql=filter_sql,
        )

        # 결과를 Document로 변환
        documents = []
        for item in results:
            # metadata 파싱
            try:
                metadata = json.loads(item["metadata"])
            except (json.JSONDecodeError, KeyError):
                metadata = {}

            doc = Document(
                page_content=item["text"],
                metadata=metadata,
            )
            score = item["distance"]
            documents.append((doc, score))

        return documents

    def similarity_search_by_vector(
        self,
        embedding: List[float],
        k: int = 4,
        filter: Optional[Dict[str, Any]] = None,
        **kwargs: Any,
    ) -> List[Document]:
        """벡터로 직접 검색.

        Args:
            embedding: 검색할 벡터
            k: 반환할 문서 수
            filter: 메타데이터 필터
            **kwargs: 추가 인자 (ef_search 등)

        Returns:
            유사한 Document 목록

        Raises:
            SeahorseAPIError: API 호출 실패

        Examples:
            >>> vector = [0.1, 0.2, ..., 0.n]  # 1024차원
            >>> docs = vectorstore.similarity_search_by_vector(vector, k=5)
        """
        docs_and_scores = self.similarity_search_by_vector_with_score(
            embedding, k=k, filter=filter, **kwargs
        )
        return [doc for doc, _ in docs_and_scores]

    def similarity_search_by_vector_with_score(
        self,
        embedding: List[float],
        k: int = 4,
        filter: Optional[Dict[str, Any]] = None,
        **kwargs: Any,
    ) -> List[Tuple[Document, float]]:
        """벡터로 직접 검색 (점수 포함).

        Args:
            embedding: 검색할 벡터
            k: 반환할 문서 수
            filter: 메타데이터 필터
            **kwargs: 추가 인자

        Returns:
            (Document, score) 튜플 목록

        Raises:
            SeahorseAPIError: API 호출 실패
        """
        # 필터를 SQL WHERE 절로 변환
        filter_sql = convert_filter_to_sql(filter) if filter else None

        # ef_search 파라미터 추출
        ef_search = kwargs.get("ef_search", min(k * 2, 500))

        # projection 설정
        projection = "id, text, metadata, distance"

        # Vector search API 호출
        results_list = self._client.vector_search(
            index_name=self._index_name,
            query_vectors=[embedding],
            top_k=k,
            ef_search=ef_search,
            projection=projection,
            filter_sql=filter_sql,
        )

        # 첫 번째 resultset 사용 (단일 벡터 검색)
        results = results_list[0] if results_list else []

        # 결과를 Document로 변환
        documents = []
        for item in results:
            # metadata 파싱
            try:
                metadata = json.loads(item["metadata"])
            except (json.JSONDecodeError, KeyError):
                metadata = {}

            doc = Document(
                page_content=item["text"],
                metadata=metadata,
            )
            score = item["distance"]
            documents.append((doc, score))

        return documents

    def delete(
        self,
        ids: Optional[List[str]] = None,
        **kwargs: Any,
    ) -> Optional[bool]:
        """문서 삭제.

        Args:
            ids: 삭제할 document ID 목록
            **kwargs: 추가 인자

        Returns:
            성공 여부 (True: 삭제됨, False: 삭제 안됨, None: ID 없음)

        Raises:
            SeahorseAPIError: API 호출 실패

        Examples:
            >>> success = vectorstore.delete(ids=["doc1_id", "doc2_id"])
        """
        if not ids:
            return None

        # SQL IN 절 생성
        ids_quoted = [f"'{id}'" for id in ids]
        delete_condition = f"id IN ({', '.join(ids_quoted)})"

        # Delete API 호출
        result = self._client.delete_data(delete_condition=delete_condition)

        return result["deleted_row_count"] > 0

    def max_marginal_relevance_search(
        self,
        query: str,
        k: int = 4,
        fetch_k: int = 20,
        lambda_mult: float = 0.5,
        filter: Optional[Dict[str, Any]] = None,
        **kwargs: Any,
    ) -> List[Document]:
        """Maximal Marginal Relevance (MMR) 검색.

        ⚠️ 현재 Seahorse API는 MMR 검색을 지원하지 않습니다.

        Args:
            query: 검색 쿼리
            k: 반환할 문서 수
            fetch_k: 후보 문서 수
            lambda_mult: Diversity 파라미터 (0~1)
            filter: 메타데이터 필터
            **kwargs: 추가 인자

        Returns:
            Document 목록

        Raises:
            NotImplementedError: MMR 검색은 현재 지원되지 않습니다
        """
        raise NotImplementedError(
            "Seahorse API does not support MMR (Maximal Marginal Relevance) search. "
            "Use similarity_search() or similarity_search_by_vector() instead."
        )

    # 비동기 메서드
    async def aadd_texts(
        self,
        texts: Iterable[str],
        metadatas: Optional[List[Dict[str, Any]]] = None,
        **kwargs: Any,
    ) -> List[str]:
        """비동기로 텍스트를 벡터 저장소에 추가.

        Args:
            texts: 추가할 텍스트 목록
            metadatas: 각 텍스트의 메타데이터 (optional)
            **kwargs: 추가 인자

        Returns:
            생성된 document ID 목록

        Raises:
            ValueError: texts와 metadatas의 길이가 다를 경우
            SeahorseAPIError: API 호출 실패

        Examples:
            >>> ids = await vectorstore.aadd_texts(
            ...     texts=["text1", "text2"],
            ...     metadatas=[{"source": "doc1"}, {"source": "doc2"}]
            ... )
        """
        texts_list = list(texts)

        if metadatas is None:
            metadatas = [{} for _ in texts_list]
        elif len(metadatas) != len(texts_list):
            raise ValueError("metadatas must have same length as texts")

        if self._use_builtin_embedding:
            # Seahorse 내장 임베딩 사용
            return await self._aadd_texts_with_builtin_embedding(texts_list, metadatas)
        else:
            # 외부 임베딩 사용
            return await self._aadd_texts_with_external_embedding(texts_list, metadatas)

    async def asimilarity_search(
        self,
        query: str,
        k: int = 4,
        filter: Optional[Dict[str, Any]] = None,
        **kwargs: Any,
    ) -> List[Document]:
        """비동기로 자연어 쿼리로 유사 문서 검색.

        Args:
            query: 검색 쿼리 (자연어)
            k: 반환할 문서 수 (기본: 4)
            filter: 메타데이터 필터 (optional)
            **kwargs: 추가 인자 (ef_search 등)

        Returns:
            유사한 Document 목록

        Raises:
            SeahorseAPIError: API 호출 실패

        Examples:
            >>> docs = await vectorstore.asimilarity_search("machine learning", k=5)
        """
        docs_and_scores = await self.asimilarity_search_with_score(
            query, k=k, filter=filter, **kwargs
        )
        return [doc for doc, _ in docs_and_scores]

    async def asimilarity_search_with_score(
        self,
        query: str,
        k: int = 4,
        filter: Optional[Dict[str, Any]] = None,
        **kwargs: Any,
    ) -> List[Tuple[Document, float]]:
        """비동기로 유사도 점수와 함께 문서 검색.

        Args:
            query: 검색 쿼리
            k: 반환할 문서 수
            filter: 메타데이터 필터
            **kwargs: 추가 인자 (ef_search 등)

        Returns:
            (Document, score) 튜플 목록

        Raises:
            SeahorseAPIError: API 호출 실패
        """
        # 필터를 SQL WHERE 절로 변환
        filter_sql = convert_filter_to_sql(filter) if filter else None

        # ef_search 파라미터 추출
        ef_search = kwargs.get("ef_search", min(k * 2, 500))

        # projection 설정
        projection = "id, text, metadata, distance"

        # Semantic search API 호출 (filter 지원!)
        results = await self._client.asemantic_search(
            query=query,
            top_k=k,
            index_name=self._index_name,
            ef_search=ef_search,
            projection=projection,
            filter_sql=filter_sql,
        )

        # 결과를 Document로 변환
        documents = []
        for item in results:
            # metadata 파싱
            try:
                metadata = json.loads(item["metadata"])
            except (json.JSONDecodeError, KeyError):
                metadata = {}

            doc = Document(
                page_content=item["text"],
                metadata=metadata,
            )
            score = item["distance"]
            documents.append((doc, score))

        return documents

    async def asimilarity_search_by_vector(
        self,
        embedding: List[float],
        k: int = 4,
        filter: Optional[Dict[str, Any]] = None,
        **kwargs: Any,
    ) -> List[Document]:
        """비동기로 벡터로 직접 검색.

        Args:
            embedding: 검색할 벡터
            k: 반환할 문서 수
            filter: 메타데이터 필터
            **kwargs: 추가 인자

        Returns:
            유사한 Document 목록

        Raises:
            SeahorseAPIError: API 호출 실패
        """
        docs_and_scores = await self.asimilarity_search_by_vector_with_score(
            embedding, k=k, filter=filter, **kwargs
        )
        return [doc for doc, _ in docs_and_scores]

    async def asimilarity_search_by_vector_with_score(
        self,
        embedding: List[float],
        k: int = 4,
        filter: Optional[Dict[str, Any]] = None,
        **kwargs: Any,
    ) -> List[Tuple[Document, float]]:
        """비동기로 벡터로 직접 검색 (점수 포함).

        Args:
            embedding: 검색할 벡터
            k: 반환할 문서 수
            filter: 메타데이터 필터
            **kwargs: 추가 인자

        Returns:
            (Document, score) 튜플 목록

        Raises:
            SeahorseAPIError: API 호출 실패
        """
        # 필터를 SQL WHERE 절로 변환
        filter_sql = convert_filter_to_sql(filter) if filter else None

        # ef_search 파라미터 추출
        ef_search = kwargs.get("ef_search", min(k * 2, 500))

        # projection 설정
        projection = "id, text, metadata, distance"

        # Vector search API 호출
        results_list = await self._client.avector_search(
            index_name=self._index_name,
            query_vectors=[embedding],
            top_k=k,
            ef_search=ef_search,
            projection=projection,
            filter_sql=filter_sql,
        )

        # 첫 번째 resultset 사용
        results = results_list[0] if results_list else []

        # 결과를 Document로 변환
        documents = []
        for item in results:
            # metadata 파싱
            try:
                metadata = json.loads(item["metadata"])
            except (json.JSONDecodeError, KeyError):
                metadata = {}

            doc = Document(
                page_content=item["text"],
                metadata=metadata,
            )
            score = item["distance"]
            documents.append((doc, score))

        return documents

    async def adelete(
        self,
        ids: Optional[List[str]] = None,
        **kwargs: Any,
    ) -> Optional[bool]:
        """비동기로 문서 삭제.

        Args:
            ids: 삭제할 document ID 목록
            **kwargs: 추가 인자

        Returns:
            성공 여부

        Raises:
            SeahorseAPIError: API 호출 실패
        """
        if not ids:
            return None

        # SQL IN 절 생성
        ids_quoted = [f"'{id}'" for id in ids]
        delete_condition = f"id IN ({', '.join(ids_quoted)})"

        # Delete API 호출
        result = await self._client.adelete_data(delete_condition=delete_condition)

        return result["deleted_row_count"] > 0

    @classmethod
    def from_texts(
        cls,
        texts: List[str],
        embedding: Optional[Embeddings] = None,
        metadatas: Optional[List[Dict[str, Any]]] = None,
        **kwargs: Any,
    ) -> "SeahorseVectorStore":
        """텍스트 목록으로부터 VectorStore 생성.

        Args:
            texts: 텍스트 목록
            embedding: Embeddings instance (optional)
            metadatas: 메타데이터 목록 (optional)
            **kwargs: SeahorseVectorStore 초기화 인자 (api_key, base_url 등)

        Returns:
            SeahorseVectorStore instance

        Raises:
            ValueError: 필수 인자 누락 (api_key, base_url)

        Examples:
            >>> vectorstore = SeahorseVectorStore.from_texts(
            ...     texts=["Hello", "World"],
            ...     metadatas=[{"source": "doc1"}, {"source": "doc2"}],
            ...     api_key="your-api-key",
            ...     base_url="https://455fe13765664952bed80e7c22dd3436.api.seahorse.dnotitia.ai"
            ... )
        """
        # embedding 인자를 kwargs에 추가
        if embedding is not None:
            kwargs["embedding"] = embedding
            kwargs["use_builtin_embedding"] = False

        # VectorStore 생성
        vectorstore = cls(**kwargs)

        # 텍스트 추가
        vectorstore.add_texts(texts, metadatas=metadatas)

        return vectorstore

    def _add_texts_with_builtin_embedding(
        self,
        texts: List[str],
        metadatas: List[Dict[str, Any]],
    ) -> List[str]:
        """Seahorse 내장 임베딩으로 텍스트 추가.

        Args:
            texts: 텍스트 목록
            metadatas: 메타데이터 목록

        Returns:
            생성된 document ID 목록
        """
        doc_ids = []

        # 배치 처리
        for text_batch, metadata_batch in batch_texts(
            texts, metadatas, batch_size=DEFAULT_BATCH_SIZE
        ):
            # Primary Key 생성 및 데이터 준비
            data = []
            batch_ids = []

            for text, metadata in zip(text_batch, metadata_batch):
                doc_id = generate_pk(text, chunk_id=0)
                batch_ids.append(doc_id)

                data.append(
                    {
                        "id": doc_id,
                        "text": text,
                        "metadata": json.dumps(metadata, ensure_ascii=False),
                    }
                )

            # API 호출
            self._client.insert_with_embedding(
                data=data,
                embedding_source="text",
                embedding_target=self._index_name,
            )

            doc_ids.extend(batch_ids)

        return doc_ids

    async def _aadd_texts_with_builtin_embedding(
        self,
        texts: List[str],
        metadatas: List[Dict[str, Any]],
    ) -> List[str]:
        """비동기로 Seahorse 내장 임베딩으로 텍스트 추가.

        Args:
            texts: 텍스트 목록
            metadatas: 메타데이터 목록

        Returns:
            생성된 document ID 목록
        """
        doc_ids = []

        # 배치 처리
        for text_batch, metadata_batch in batch_texts(
            texts, metadatas, batch_size=DEFAULT_BATCH_SIZE
        ):
            # Primary Key 생성 및 데이터 준비
            data = []
            batch_ids = []

            for text, metadata in zip(text_batch, metadata_batch):
                doc_id = generate_pk(text, chunk_id=0)
                batch_ids.append(doc_id)

                data.append(
                    {
                        "id": doc_id,
                        "text": text,
                        "metadata": json.dumps(metadata, ensure_ascii=False),
                    }
                )

            # API 호출 (비동기)
            await self._client.ainsert_with_embedding(
                data=data,
                embedding_source="text",
                embedding_target=self._index_name,
            )

            doc_ids.extend(batch_ids)

        return doc_ids

    def _add_texts_with_external_embedding(
        self,
        texts: List[str],
        metadatas: List[Dict[str, Any]],
    ) -> List[str]:
        """외부 임베딩으로 텍스트 추가.

        Args:
            texts: 텍스트 목록
            metadatas: 메타데이터 목록

        Returns:
            생성된 document ID 목록
        """
        if self._embedding is None:
            raise ValueError("Embedding instance is None")

        # 임베딩 생성
        embeddings = self._embedding.embed_documents(texts)

        doc_ids = []

        # 배치 처리
        for text_batch, metadata_batch in batch_texts(
            texts, metadatas, batch_size=DEFAULT_BATCH_SIZE
        ):
            # 해당 배치의 임베딩 추출
            start_idx = texts.index(text_batch[0])
            end_idx = start_idx + len(text_batch)
            embedding_batch = embeddings[start_idx:end_idx]

            # Primary Key 생성 및 JSONL 데이터 준비
            jsonl_lines = []
            batch_ids = []

            for text, metadata, embedding in zip(
                text_batch, metadata_batch, embedding_batch
            ):
                doc_id = generate_pk(text, chunk_id=0)
                batch_ids.append(doc_id)

                line = {
                    "id": doc_id,
                    "text": text,
                    "metadata": json.dumps(metadata, ensure_ascii=False),
                    self._index_name: embedding,
                }
                jsonl_lines.append(json.dumps(line, ensure_ascii=False))

            # JSONL 형식으로 삽입
            jsonl_data = "\n".join(jsonl_lines)
            self._client.insert_jsonl(jsonl_data)

            doc_ids.extend(batch_ids)

        return doc_ids

    async def _aadd_texts_with_external_embedding(
        self,
        texts: List[str],
        metadatas: List[Dict[str, Any]],
    ) -> List[str]:
        """비동기로 외부 임베딩으로 텍스트 추가.

        Args:
            texts: 텍스트 목록
            metadatas: 메타데이터 목록

        Returns:
            생성된 document ID 목록
        """
        if self._embedding is None:
            raise ValueError("Embedding instance is None")

        # 임베딩 생성 (동기 - 대부분의 LangChain Embeddings는 동기)
        # TODO: 추후 aembed_documents가 지원되는 경우 사용
        embeddings = self._embedding.embed_documents(texts)

        doc_ids = []

        # 배치 처리
        for text_batch, metadata_batch in batch_texts(
            texts, metadatas, batch_size=DEFAULT_BATCH_SIZE
        ):
            # 해당 배치의 임베딩 추출
            start_idx = texts.index(text_batch[0])
            end_idx = start_idx + len(text_batch)
            embedding_batch = embeddings[start_idx:end_idx]

            # Primary Key 생성 및 JSONL 데이터 준비
            jsonl_lines = []
            batch_ids = []

            for text, metadata, embedding in zip(
                text_batch, metadata_batch, embedding_batch
            ):
                doc_id = generate_pk(text, chunk_id=0)
                batch_ids.append(doc_id)

                line = {
                    "id": doc_id,
                    "text": text,
                    "metadata": json.dumps(metadata, ensure_ascii=False),
                    self._index_name: embedding,
                }
                jsonl_lines.append(json.dumps(line, ensure_ascii=False))

            # JSONL 형식으로 삽입 (비동기)
            jsonl_data = "\n".join(jsonl_lines)
            await self._client.ainsert_jsonl(jsonl_data)

            doc_ids.extend(batch_ids)

        return doc_ids
