"""Custom exceptions for Seahorse VectorStore SDK."""

from typing import Optional


class SeahorseException(Exception):
    """Base exception for Seahorse SDK."""

    pass


class SeahorseAPIError(SeahorseException):
    """API 호출 실패 예외.

    Args:
        status_code: HTTP 상태 코드
        error_code: Seahorse 에러 코드 (optional)
        error_message: 에러 메시지

    Attributes:
        status_code: HTTP 상태 코드
        error_code: Seahorse 에러 코드
        error_message: 에러 메시지
    """

    def __init__(
        self,
        status_code: int,
        error_code: Optional[int] = None,
        error_message: str = "Unknown error",
    ) -> None:
        """Initialize SeahorseAPIError.

        Args:
            status_code: HTTP 상태 코드
            error_code: Seahorse 에러 코드 (optional)
            error_message: 에러 메시지
        """
        self.status_code = status_code
        self.error_code = error_code
        self.error_message = error_message

        if error_code:
            message = f"[{status_code}] {error_message} (code: {error_code})"
        else:
            message = f"[{status_code}] {error_message}"

        super().__init__(message)


class SeahorseAuthenticationError(SeahorseAPIError):
    """인증 실패 예외 (401, 403).

    API Key가 유효하지 않거나 권한이 없을 때 발생합니다.
    """

    pass


class SeahorseRateLimitError(SeahorseAPIError):
    """Rate limit 초과 예외 (429).

    API 호출 제한을 초과했을 때 발생합니다.
    """

    pass


class SeahorseValidationError(SeahorseException):
    """입력 검증 실패 예외.

    잘못된 파라미터나 데이터 형식으로 인해 발생합니다.
    """

    pass


class SeahorseDimensionMismatchError(SeahorseValidationError):
    """벡터 차원 불일치 예외.

    임베딩 벡터의 차원이 테이블 스키마와 일치하지 않을 때 발생합니다.

    Args:
        expected: 예상되는 벡터 차원
        actual: 실제 벡터 차원

    Attributes:
        expected: 예상되는 벡터 차원
        actual: 실제 벡터 차원
    """

    def __init__(self, expected: int, actual: int) -> None:
        """Initialize SeahorseDimensionMismatchError.

        Args:
            expected: 예상되는 벡터 차원
            actual: 실제 벡터 차원
        """
        self.expected = expected
        self.actual = actual
        super().__init__(
            f"Vector dimension mismatch: expected {expected}, got {actual}"
        )
