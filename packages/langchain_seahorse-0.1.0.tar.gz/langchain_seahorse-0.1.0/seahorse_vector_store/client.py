"""Low-level Seahorse API client."""

import time
from typing import Any, Dict, List, Optional

import httpx

from .exceptions import (
    SeahorseAPIError,
    SeahorseAuthenticationError,
    SeahorseRateLimitError,
)


class SeahorseClient:
    """Low-level Seahorse API client.

    CoralResponse 언래핑, 에러 처리, 재시도 로직 등을 담당합니다.

    Args:
        base_url: Seahorse API base URL (테이블별 고유 URL)
        api_key: Seahorse API key
        timeout: Request timeout (초 단위, 기본: 30.0)
        max_retries: 최대 재시도 횟수 (기본: 3)

    Attributes:
        _base_url: API base URL
        _api_key: API key
        _timeout: Request timeout
        _max_retries: Maximum retry attempts
        _session: httpx.Client instance
        _async_session: httpx.AsyncClient instance

    Examples:
        >>> client = SeahorseClient(
        ...     base_url="https://455fe13765664952bed80e7c22dd3436.api.seahorse.dnotitia.ai",
        ...     api_key="your-api-key"
        ... )
        >>> result = client.insert_with_embedding(
        ...     data=[{"id": "doc1", "text": "Hello"}],
        ...     embedding_source="text",
        ...     embedding_target="embedding"
        ... )
    """

    def __init__(
        self,
        base_url: str,
        api_key: str,
        timeout: float = 30.0,
        max_retries: int = 3,
    ) -> None:
        """Initialize Seahorse API client.

        Args:
            base_url: API base URL
            api_key: API key
            timeout: Request timeout (초 단위)
            max_retries: 최대 재시도 횟수
        """
        self._base_url = base_url.rstrip("/")
        self._api_key = api_key
        self._timeout = timeout
        self._max_retries = max_retries

        # HTTP 클라이언트 설정
        headers = {
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
        }

        self._session = httpx.Client(
            headers=headers,
            timeout=timeout,
            follow_redirects=True,
        )

        self._async_session = httpx.AsyncClient(
            headers=headers,
            timeout=timeout,
            follow_redirects=True,
        )

    def __del__(self) -> None:
        """Clean up resources."""
        if hasattr(self, "_session"):
            self._session.close()
        if hasattr(self, "_async_session"):
            # AsyncClient는 비동기로 닫아야 하지만 __del__에서는 불가능
            # 사용자가 명시적으로 close() 호출하도록 권장
            pass

    def close(self) -> None:
        """동기 세션 종료."""
        self._session.close()

    async def aclose(self) -> None:
        """비동기 세션 종료."""
        await self._async_session.aclose()

    async def ainsert_with_embedding(
        self,
        data: List[Dict[str, Any]],
        embedding_source: str = "text",
        embedding_target: str = "embedding",
    ) -> Dict[str, Any]:
        """데이터 삽입 (비동기, Seahorse 내장 임베딩 사용).

        POST /v1/data/embedding

        Args:
            data: 삽입할 데이터 목록 (각 항목은 id, text, metadata 포함)
            embedding_source: 임베딩 소스 컬럼명 (기본: "text")
            embedding_target: 임베딩 타겟 컬럼명 (기본: "embedding")

        Returns:
            삽입 결과 (inserted_row_count, inserted_record_batches, elapsed_time)

        Raises:
            SeahorseAPIError: API 호출 실패
        """
        payload = {
            "data": data,
            "embedding_source": embedding_source,
            "embedding_target": embedding_target,
        }

        response = await self._arequest("POST", "/v1/data/embedding", json=payload)
        return self._unwrap_coral_response(response)

    def insert_with_embedding(
        self,
        data: List[Dict[str, Any]],
        embedding_source: str = "text",
        embedding_target: str = "embedding",
    ) -> Dict[str, Any]:
        """데이터 삽입 (Seahorse 내장 임베딩 사용).

        POST /v1/data/embedding

        Args:
            data: 삽입할 데이터 목록 (각 항목은 id, text, metadata 포함)
            embedding_source: 임베딩 소스 컬럼명 (기본: "text")
            embedding_target: 임베딩 타겟 컬럼명 (기본: "embedding")

        Returns:
            삽입 결과 (inserted_row_count, inserted_record_batches, elapsed_time)

        Raises:
            SeahorseAPIError: API 호출 실패
        """
        payload = {
            "data": data,
            "embedding_source": embedding_source,
            "embedding_target": embedding_target,
        }

        response = self._request("POST", "/v1/data/embedding", json=payload)
        return self._unwrap_coral_response(response)

    async def asemantic_search(
        self,
        query: str,
        top_k: int,
        index_name: str,
        ef_search: Optional[int] = None,
        projection: Optional[str] = None,
        filter_sql: Optional[str] = None,
    ) -> List[Dict[str, Any]]:
        """시맨틱 검색 (비동기, 자연어 쿼리).

        POST /v1/data/semantic-search

        Args:
            query: 검색 쿼리 (자연어)
            top_k: 반환할 결과 수
            index_name: 벡터 인덱스 컬럼명 (기본: "embedding")
            ef_search: HNSW ef_search 파라미터 (optional)
            projection: 반환할 컬럼 (optional, 기본: 모든 컬럼)
            filter_sql: SQL WHERE 절 (optional)

        Returns:
            검색 결과 리스트 (각 항목은 text, metadata, distance 포함)

        Raises:
            SeahorseAPIError: API 호출 실패
        """
        payload: Dict[str, Any] = {
            "query": query,
            "top_k": top_k,
            "index_name": index_name,
        }

        if ef_search is not None:
            payload["ef_search"] = ef_search
        if projection is not None:
            payload["projection"] = projection
        if filter_sql is not None:
            payload["filter"] = filter_sql

        response = await self._arequest(
            "POST", "/v1/data/semantic-search", json=payload
        )
        result = self._unwrap_coral_response(response)

        # 첫 번째 resultset의 data 반환
        return result["data"][0]

    def semantic_search(
        self,
        query: str,
        top_k: int,
        index_name: str,
        ef_search: Optional[int] = None,
        projection: Optional[str] = None,
        filter_sql: Optional[str] = None,
    ) -> List[Dict[str, Any]]:
        """시맨틱 검색 (자연어 쿼리).

        POST /v1/data/semantic-search

        Args:
            query: 검색 쿼리 (자연어)
            top_k: 반환할 결과 수
            index_name: 벡터 인덱스 컬럼명 (기본: "embedding")
            ef_search: HNSW ef_search 파라미터 (optional)
            projection: 반환할 컬럼 (optional, 기본: 모든 컬럼)
            filter_sql: SQL WHERE 절 (optional)

        Returns:
            검색 결과 리스트 (각 항목은 text, metadata, distance 포함)

        Raises:
            SeahorseAPIError: API 호출 실패
        """
        payload: Dict[str, Any] = {
            "query": query,
            "top_k": top_k,
            "index_name": index_name,
        }

        if ef_search is not None:
            payload["ef_search"] = ef_search
        if projection is not None:
            payload["projection"] = projection
        if filter_sql is not None:
            payload["filter"] = filter_sql

        response = self._request("POST", "/v1/data/semantic-search", json=payload)
        result = self._unwrap_coral_response(response)

        # 첫 번째 resultset의 data 반환
        return result["data"][0]

    async def avector_search(
        self,
        index_name: str,
        query_vectors: List[List[float]],
        top_k: int,
        ef_search: Optional[int] = None,
        projection: Optional[str] = None,
        filter_sql: Optional[str] = None,
    ) -> List[List[Dict[str, Any]]]:
        """벡터 검색 (비동기, 벡터로 직접 검색).

        POST /v1/data/indexes/{index_name}/vector-search

        Args:
            index_name: 벡터 인덱스 컬럼명
            query_vectors: 검색할 벡터 리스트 (여러 벡터 동시 검색 가능)
            top_k: 반환할 결과 수
            ef_search: HNSW ef_search 파라미터 (optional)
            projection: 반환할 컬럼 (optional)
            filter_sql: SQL WHERE 절 (optional)

        Returns:
            검색 결과 리스트 (각 벡터당 하나의 resultset)

        Raises:
            SeahorseAPIError: API 호출 실패
        """
        payload: Dict[str, Any] = {
            "query_vectors": {"dense": query_vectors},
            "top_k": top_k,
        }

        if ef_search is not None:
            payload["ef_search"] = ef_search
        if projection is not None:
            payload["projection"] = projection
        if filter_sql is not None:
            payload["filter"] = filter_sql

        path = f"/v1/data/indexes/{index_name}/vector-search"
        response = await self._arequest("POST", path, json=payload)
        result = self._unwrap_coral_response(response)

        return result["data"]

    def vector_search(
        self,
        index_name: str,
        query_vectors: List[List[float]],
        top_k: int,
        ef_search: Optional[int] = None,
        projection: Optional[str] = None,
        filter_sql: Optional[str] = None,
    ) -> List[List[Dict[str, Any]]]:
        """벡터 검색 (벡터로 직접 검색).

        POST /v1/data/indexes/{index_name}/vector-search

        Args:
            index_name: 벡터 인덱스 컬럼명
            query_vectors: 검색할 벡터 리스트 (여러 벡터 동시 검색 가능)
            top_k: 반환할 결과 수
            ef_search: HNSW ef_search 파라미터 (optional)
            projection: 반환할 컬럼 (optional)
            filter_sql: SQL WHERE 절 (optional)

        Returns:
            검색 결과 리스트 (각 벡터당 하나의 resultset)

        Raises:
            SeahorseAPIError: API 호출 실패
        """
        payload: Dict[str, Any] = {
            "query_vectors": {"dense": query_vectors},
            "top_k": top_k,
        }

        if ef_search is not None:
            payload["ef_search"] = ef_search
        if projection is not None:
            payload["projection"] = projection
        if filter_sql is not None:
            payload["filter"] = filter_sql

        path = f"/v1/data/indexes/{index_name}/vector-search"
        response = self._request("POST", path, json=payload)
        result = self._unwrap_coral_response(response)

        return result["data"]

    async def adelete_data(
        self,
        delete_condition: str,
    ) -> Dict[str, Any]:
        """데이터 삭제 (비동기).

        POST /v1/data/delete

        Args:
            delete_condition: SQL WHERE 절 (삭제 조건)

        Returns:
            삭제 결과 (deleted_row_count)

        Raises:
            SeahorseAPIError: API 호출 실패

        Warning:
            delete_condition을 제공하지 않으면 전체 데이터가 삭제됩니다!
        """
        payload = {"delete_condition": delete_condition}

        response = await self._arequest("POST", "/v1/data/delete", json=payload)
        return self._unwrap_coral_response(response)

    def delete_data(
        self,
        delete_condition: str,
    ) -> Dict[str, Any]:
        """데이터 삭제.

        POST /v1/data/delete

        Args:
            delete_condition: SQL WHERE 절 (삭제 조건)

        Returns:
            삭제 결과 (deleted_row_count)

        Raises:
            SeahorseAPIError: API 호출 실패

        Warning:
            delete_condition을 제공하지 않으면 전체 데이터가 삭제됩니다!
        """
        payload = {"delete_condition": delete_condition}

        response = self._request("POST", "/v1/data/delete", json=payload)
        return self._unwrap_coral_response(response)

    def get_table_schema(self) -> Dict[str, Any]:
        """테이블 스키마 조회.

        GET /v1/data/schema

        Returns:
            테이블 스키마 정보 (table_name, schema)

        Raises:
            SeahorseAPIError: API 호출 실패
        """
        response = self._request("GET", "/v1/data/schema")
        return self._unwrap_coral_response(response)

    async def ainsert_jsonl(
        self,
        jsonl_data: str,
        batch_insert_size: int = 1024,
    ) -> Dict[str, Any]:
        """JSONL 형식으로 데이터 삽입 (비동기, 외부 임베딩 사용 시).

        POST /v1/data

        Args:
            jsonl_data: JSONL 형식 데이터 (각 줄은 JSON 객체)
            batch_insert_size: 배치 삽입 크기 (기본: 1024)

        Returns:
            삽입 결과

        Raises:
            SeahorseAPIError: API 호출 실패
        """
        headers = {"Content-Type": "text/plain"}
        params = {"batch_insert_size": batch_insert_size}

        response = await self._arequest(
            "POST",
            "/v1/data",
            data=jsonl_data,
            headers=headers,
            params=params,
        )
        return self._unwrap_coral_response(response)

    def insert_jsonl(
        self,
        jsonl_data: str,
        batch_insert_size: int = 1024,
    ) -> Dict[str, Any]:
        """JSONL 형식으로 데이터 삽입 (외부 임베딩 사용 시).

        POST /v1/data

        Args:
            jsonl_data: JSONL 형식 데이터 (각 줄은 JSON 객체)
            batch_insert_size: 배치 삽입 크기 (기본: 1024)

        Returns:
            삽입 결과

        Raises:
            SeahorseAPIError: API 호출 실패
        """
        headers = {"Content-Type": "text/plain"}
        params = {"batch_insert_size": batch_insert_size}

        response = self._request(
            "POST",
            "/v1/data",
            data=jsonl_data,
            headers=headers,
            params=params,
        )
        return self._unwrap_coral_response(response)

    async def _arequest(
        self,
        method: str,
        path: str,
        **kwargs: Any,
    ) -> httpx.Response:
        """비동기 HTTP 요청 (재시도 로직 포함).

        Args:
            method: HTTP 메서드 (GET, POST 등)
            path: API 경로
            **kwargs: httpx.request에 전달할 추가 인자

        Returns:
            HTTP 응답

        Raises:
            SeahorseAPIError: API 호출 실패
            SeahorseAuthenticationError: 인증 실패
            SeahorseRateLimitError: Rate limit 초과
        """
        import asyncio

        url = f"{self._base_url}{path}"

        last_exception: Optional[Exception] = None
        for attempt in range(self._max_retries):
            try:
                response = await self._async_session.request(method, url, **kwargs)

                # 재시도 가능한 에러인지 확인
                if response.status_code in [408, 429, 500, 502, 503, 504]:
                    if attempt < self._max_retries - 1:
                        # 지수 백오프
                        delay = 2**attempt
                        await asyncio.sleep(delay)
                        continue

                # 인증 에러 처리
                if response.status_code in [401, 403]:
                    raise SeahorseAuthenticationError(
                        status_code=response.status_code,
                        error_message=f"Authentication failed: {response.text}",
                    )

                # Rate limit 에러 처리
                if response.status_code == 429:
                    raise SeahorseRateLimitError(
                        status_code=429,
                        error_message="Rate limit exceeded",
                    )

                response.raise_for_status()
                return response

            except httpx.HTTPStatusError as e:
                if e.response.status_code not in [408, 429, 500, 502, 503, 504]:
                    # 재시도 불가능한 에러
                    raise SeahorseAPIError(
                        status_code=e.response.status_code,
                        error_message=str(e),
                    )
                last_exception = e
            except httpx.RequestError as e:
                last_exception = e

        # 모든 재시도 실패
        if last_exception:
            raise SeahorseAPIError(
                status_code=500,
                error_message=f"Request failed after {self._max_retries} retries: {last_exception}",
            )

        # 이 코드는 실행되지 않아야 함
        raise SeahorseAPIError(
            status_code=500,
            error_message="Unexpected error in request handling",
        )

    def _request(
        self,
        method: str,
        path: str,
        **kwargs: Any,
    ) -> httpx.Response:
        """HTTP 요청 (재시도 로직 포함).

        Args:
            method: HTTP 메서드 (GET, POST 등)
            path: API 경로
            **kwargs: httpx.request에 전달할 추가 인자

        Returns:
            HTTP 응답

        Raises:
            SeahorseAPIError: API 호출 실패
            SeahorseAuthenticationError: 인증 실패
            SeahorseRateLimitError: Rate limit 초과
        """
        url = f"{self._base_url}{path}"

        last_exception: Optional[Exception] = None
        for attempt in range(self._max_retries):
            try:
                response = self._session.request(method, url, **kwargs)

                # 재시도 가능한 에러인지 확인
                if response.status_code in [408, 429, 500, 502, 503, 504]:
                    if attempt < self._max_retries - 1:
                        # 지수 백오프
                        delay = 2**attempt
                        time.sleep(delay)
                        continue

                # 인증 에러 처리
                if response.status_code in [401, 403]:
                    raise SeahorseAuthenticationError(
                        status_code=response.status_code,
                        error_message=f"Authentication failed: {response.text}",
                    )

                # Rate limit 에러 처리
                if response.status_code == 429:
                    raise SeahorseRateLimitError(
                        status_code=429,
                        error_message="Rate limit exceeded",
                    )

                response.raise_for_status()
                return response

            except httpx.HTTPStatusError as e:
                if e.response.status_code not in [408, 429, 500, 502, 503, 504]:
                    # 재시도 불가능한 에러
                    raise SeahorseAPIError(
                        status_code=e.response.status_code,
                        error_message=str(e),
                    )
                last_exception = e
            except httpx.RequestError as e:
                last_exception = e

        # 모든 재시도 실패
        if last_exception:
            raise SeahorseAPIError(
                status_code=500,
                error_message=f"Request failed after {self._max_retries} retries: {last_exception}",
            )

        # 이 코드는 실행되지 않아야 함
        raise SeahorseAPIError(
            status_code=500,
            error_message="Unexpected error in request handling",
        )

    def _unwrap_coral_response(self, response: httpx.Response) -> Any:
        """CoralResponse 언래핑.

        Args:
            response: HTTP 응답

        Returns:
            CoralResponse의 data 필드

        Raises:
            SeahorseAPIError: API 에러 응답
        """
        data = response.json()

        if not data.get("success"):
            # 에러 응답
            exception = data.get("exception", {})
            error_code = exception.get("error_code")
            error_message = exception.get("error_message", "Unknown error")

            status_code = data.get("code", response.status_code)

            # 인증 에러
            if status_code in [401, 403]:
                raise SeahorseAuthenticationError(
                    status_code=status_code,
                    error_code=error_code,
                    error_message=error_message,
                )

            # Rate limit 에러
            if status_code == 429:
                raise SeahorseRateLimitError(
                    status_code=status_code,
                    error_code=error_code,
                    error_message=error_message,
                )

            # 일반 API 에러
            raise SeahorseAPIError(
                status_code=status_code,
                error_code=error_code,
                error_message=error_message,
            )

        return data.get("data")
