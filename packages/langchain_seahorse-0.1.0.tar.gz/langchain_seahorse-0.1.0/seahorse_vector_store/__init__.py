"""Seahorse Vector Store - LangChain VectorStore integration for Seahorse API Gateway."""

from .exceptions import (
    SeahorseAPIError,
    SeahorseAuthenticationError,
    SeahorseDimensionMismatchError,
    SeahorseException,
    SeahorseRateLimitError,
    SeahorseValidationError,
)
from .vectorstores import SeahorseVectorStore

__version__ = "0.1.0"

__all__ = [
    "SeahorseVectorStore",
    "SeahorseException",
    "SeahorseAPIError",
    "SeahorseAuthenticationError",
    "SeahorseRateLimitError",
    "SeahorseValidationError",
    "SeahorseDimensionMismatchError",
]
