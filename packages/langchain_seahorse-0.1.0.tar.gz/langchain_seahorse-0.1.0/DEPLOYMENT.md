# Seahorse VectorStore - 배포 가이드

## 🚀 PyPI 배포

### 사전 준비

1. **PyPI 계정 생성**
   - https://pypi.org/account/register/
   - API Token 생성

2. **GitHub Repository 설정**
   - Secrets 설정: `PYPI_API_TOKEN`
   - Repository > Settings > Secrets and variables > Actions

### 배포 방법

#### Option 1: GitHub Release (권장)

```bash
# 1. 버전 태그 생성
git tag v0.1.0
git push origin v0.1.0

# 2. GitHub에서 Release 생성
# → GitHub Actions가 자동으로 PyPI에 배포
```

#### Option 2: 수동 배포

```bash
# 1. 패키지 빌드
uv build

# 2. 빌드 확인
ls dist/
# langchain_seahorse-0.1.0-py3-none-any.whl
# langchain_seahorse-0.1.0.tar.gz

# 3. 테스트 PyPI에 먼저 배포 (선택)
uv publish --index-url https://test.pypi.org/legacy/

# 4. 실제 PyPI에 배포
uv publish
```

### 배포 후 확인

```bash
# 1. 설치 테스트
pip install langchain-seahorse

# 2. Import 테스트
python -c "from seahorse_vector_store import SeahorseVectorStore; print('✅ OK')"

# 3. 버전 확인
pip show langchain-seahorse
```

---

## 🔄 버전 관리

### Semantic Versioning

- **MAJOR** (1.0.0): Breaking changes
- **MINOR** (0.1.0): New features (backward compatible)
- **PATCH** (0.1.1): Bug fixes

### 버전 업데이트 절차

```bash
# 1. pyproject.toml 버전 수정
version = "0.2.0"

# 2. CHANGELOG.md 업데이트
## [0.2.0] - 2025-MM-DD
### Added
- New feature

# 3. Git commit
git add pyproject.toml CHANGELOG.md
git commit -m "chore: bump version to 0.2.0"

# 4. Tag 생성 및 푸시
git tag v0.2.0
git push origin main --tags

# 5. GitHub Release 생성 (자동 배포)
```

---

## 📋 배포 체크리스트

### 배포 전
- [x] 모든 테스트 통과
- [x] 문서 업데이트
- [x] CHANGELOG.md 작성
- [x] 버전 번호 업데이트
- [x] LICENSE 파일 존재
- [x] README.md 완성

### 배포 시
- [ ] GitHub Release 생성
- [ ] Release notes 작성
- [ ] PyPI 배포 확인

### 배포 후
- [ ] 설치 테스트
- [ ] 버전 확인
- [ ] 문서 사이트 업데이트
- [ ] 공지 (GitHub, 블로그 등)

---

## 🏷️ Release 생성

### GitHub Release Template

**Title:** `v0.1.0 - Initial Release`

**Description:**
```markdown
# Seahorse VectorStore v0.1.0

## 🎉 Initial Release

LangChain VectorStore integration for Seahorse API Gateway.

### ✨ Features

- Full LangChain VectorStore interface implementation
- Synchronous and asynchronous APIs
- Built-in and external embeddings support
- Metadata filtering with LIKE pattern
- Batch processing (1024 docs/batch)
- Comprehensive error handling

### 📦 Installation

```bash
pip install langchain-seahorse
```

### 📚 Documentation

- [README](./README.md)
- [API Reference](./docs/API_REFERENCE.md)
- [Tutorial](./docs/TUTORIAL.md)

### 🧪 Testing

- 47 unit tests passing
- 76% code coverage
- Python 3.8-3.12 support

### 🙏 Acknowledgments

Built with ❤️ by the Seahorse Team
```

---

## 🔐 보안

### API Key 보호

```bash
# .env 파일이 Git에 커밋되지 않도록 확인
cat .gitignore | grep ".env"
# .env 가 있어야 함

# 실수로 커밋한 경우
git filter-branch --force --index-filter \
  "git rm --cached --ignore-unmatch .env" \
  --prune-empty --tag-name-filter cat -- --all
```

### PyPI Token 보호

- GitHub Secrets에만 저장
- 로컬에 저장하지 않기
- 정기적으로 rotate

---

**작성일:** 2025-11-21
**버전:** 0.1.0
