# Seahorse VectorStore 튜토리얼

## 목차
1. [시작하기](#시작하기)
2. [기본 사용법](#기본-사용법)
3. [메타데이터 필터링](#메타데이터-필터링)
4. [비동기 사용](#비동기-사용)
5. [외부 임베딩 사용](#외부-임베딩-사용)
6. [RAG 파이프라인 구축](#rag-파이프라인-구축)
7. [성능 최적화](#성능-최적화)
8. [트러블슈팅](#트러블슈팅)

---

## 시작하기

### 설치

```bash
pip install langchain-seahorse
```

### API 인증 정보 설정

`.env` 파일을 생성하고 Seahorse credentials를 추가하세요:

```bash
# .env
SEAHORSE_API_KEY=your-api-key-here
SEAHORSE_BASE_URL=https://your-table-uuid.api.seahorse.dnotitia.ai
```

**API Key 발급 방법:**
1. [Seahorse Console](https://console.seahorse.dnotitia.ai) 접속
2. Management > API Keys 메뉴로 이동
3. "Create API Key" 버튼 클릭
4. READ/WRITE 권한 부여

**테이블 생성:**
1. Console에서 "Create Table" 클릭
2. 기본 스키마 선택 (id, text, metadata, embedding)
3. 벡터 차원: 1024 (Seahorse 기본값)
4. HNSW 인덱스 설정 확인
5. 생성 후 Base URL 확인

---

## 기본 사용법

### 1. VectorStore 초기화

```python
import os
from seahorse_vector_store import SeahorseVectorStore

# .env 파일에서 자동으로 로드되거나, 직접 지정
vectorstore = SeahorseVectorStore(
    api_key=os.environ["SEAHORSE_API_KEY"],
    base_url=os.environ["SEAHORSE_BASE_URL"],
)
```

### 2. 문서 추가

```python
# 단순 텍스트 추가
ids = vectorstore.add_texts([
    "Python is a versatile programming language.",
    "JavaScript is essential for web development.",
])

print(f"Added {len(ids)} documents")
print(f"Document IDs: {ids}")
```

### 3. 메타데이터와 함께 추가

```python
texts = [
    "Machine learning enables computers to learn from data.",
    "Deep learning is a subset of machine learning.",
]

metadatas = [
    {"source": "ml_intro.pdf", "page": 1, "author": "John Doe"},
    {"source": "dl_guide.pdf", "page": 5, "author": "Jane Smith"},
]

ids = vectorstore.add_texts(texts, metadatas=metadatas)
```

### 4. 유사도 검색

```python
# 기본 검색 (상위 4개 결과)
docs = vectorstore.similarity_search("What is machine learning?")

for doc in docs:
    print(f"Content: {doc.page_content}")
    print(f"Metadata: {doc.metadata}\n")
```

### 5. 점수와 함께 검색

```python
# 유사도 점수 포함
docs_and_scores = vectorstore.similarity_search_with_score(
    query="deep learning",
    k=5
)

for doc, score in docs_and_scores:
    print(f"Score: {score:.4f}")
    print(f"Content: {doc.page_content}")
    print(f"Metadata: {doc.metadata}\n")
```

**점수 해석:**
- `score`는 distance 값입니다
- **작을수록 더 유사**합니다 (0에 가까울수록 유사)
- 일반적으로 0.0 ~ 2.0 범위

### 6. 문서 삭제

```python
# ID로 삭제
success = vectorstore.delete(ids=["doc_id_1", "doc_id_2"])
print(f"Deletion successful: {success}")
```

---

## 메타데이터 필터링

Seahorse의 metadata는 String 타입이므로 LIKE 패턴을 사용합니다.

### 단일 조건 필터

```python
# source가 "doc.pdf"인 문서만 검색
docs = vectorstore.similarity_search(
    query="machine learning",
    k=10,
    filter={"source": "doc.pdf"}
)
```

### 여러 조건 필터 (AND)

```python
# source가 "doc.pdf"이고 page가 1인 문서
docs = vectorstore.similarity_search(
    query="introduction",
    k=5,
    filter={
        "source": "doc.pdf",
        "page": 1
    }
)
```

### 다양한 데이터 타입

```python
# String
filter = {"author": "John Doe"}

# Integer
filter = {"page": 10}

# Float
filter = {"score": 0.95}

# Boolean
filter = {"is_published": True}

# Null
filter = {"optional_field": None}
```

### 주의사항

⚠️ **지원하지 않는 필터:**
```python
# ❌ 비교 연산자 (미지원)
filter = {"page": {"$gt": 10}}  # ValueError

# ❌ IN 연산자 (미지원)
filter = {"category": {"$in": ["tech", "science"]}}  # ValueError

# ❌ 중첩 객체 (미지원)
filter = {"user.name": "John"}  # 작동하지 않음
```

✅ **권장 방법:**
```python
# Flat한 metadata 사용
metadata = {
    "user_name": "John",  # 중첩 대신 flat하게
    "category": "tech",
    "page": 1
}
```

---

## 비동기 사용

대용량 데이터 처리나 동시성이 필요한 경우 async 메서드를 사용하세요.

### 기본 비동기 사용

```python
import asyncio
from seahorse_vector_store import SeahorseVectorStore

async def main():
    vectorstore = SeahorseVectorStore(
        api_key="your-api-key",
        base_url="https://your-table.api.seahorse.dnotitia.ai",
    )
    
    # 비동기 추가
    ids = await vectorstore.aadd_texts([
        "Async text 1",
        "Async text 2",
    ])
    
    # 비동기 검색
    docs = await vectorstore.asimilarity_search("async", k=5)
    
    # 비동기 삭제
    await vectorstore.adelete(ids=ids)

asyncio.run(main())
```

### 병렬 처리

```python
async def process_multiple_queries():
    vectorstore = SeahorseVectorStore(...)
    
    # 여러 쿼리를 병렬로 처리
    queries = ["query1", "query2", "query3"]
    
    # asyncio.gather로 병렬 실행
    results = await asyncio.gather(*[
        vectorstore.asimilarity_search(q, k=5)
        for q in queries
    ])
    
    for query, docs in zip(queries, results):
        print(f"Query: {query}")
        print(f"Results: {len(docs)} documents\n")
```

**성능 향상:**
- 3개 쿼리를 순차 실행: ~3초
- 3개 쿼리를 병렬 실행: ~1초 (3배 빠름)

---

## 외부 임베딩 사용

Seahorse 내장 임베딩 외에 OpenAI, Cohere 등을 사용할 수 있습니다.

### OpenAI Embeddings

```python
from seahorse_vector_store import SeahorseVectorStore
from langchain_openai import OpenAIEmbeddings

vectorstore = SeahorseVectorStore(
    api_key="seahorse-api-key",
    base_url="https://table-uuid.api.seahorse.dnotitia.ai",
    embedding=OpenAIEmbeddings(
        api_key="openai-api-key",
        model="text-embedding-3-small"  # 1536 dimensions
    ),
    use_builtin_embedding=False,
)

# 사용 방법은 동일
ids = vectorstore.add_texts(["text1", "text2"])
```

### Cohere Embeddings

```python
from langchain_cohere import CohereEmbeddings

vectorstore = SeahorseVectorStore(
    api_key="seahorse-api-key",
    base_url="https://table-uuid.api.seahorse.dnotitia.ai",
    embedding=CohereEmbeddings(
        cohere_api_key="cohere-api-key",
        model="embed-english-v3.0"
    ),
    use_builtin_embedding=False,
)
```

### ⚠️ 벡터 차원 호환성

**중요:** 외부 임베딩 모델의 차원이 Seahorse 테이블의 벡터 차원과 일치해야 합니다!

```python
# 테이블 스키마 확인
# GET /v1/data/schema
# embedding 컬럼의 FixedSizeList 크기 확인 (예: 1024)

# ✅ 호환되는 경우
Seahorse 테이블: 1024 차원
임베딩 모델: 1024 차원
→ 작동함

# ❌ 호환되지 않는 경우
Seahorse 테이블: 1024 차원
OpenAI ada-002: 1536 차원
→ SeahorseDimensionMismatchError 발생
```

---

## RAG 파이프라인 구축

### 전체 RAG 파이프라인

```python
from seahorse_vector_store import SeahorseVectorStore
from langchain.chains import RetrievalQA
from langchain_openai import ChatOpenAI

# 1. VectorStore 초기화
vectorstore = SeahorseVectorStore(
    api_key="your-api-key",
    base_url="https://your-table.api.seahorse.dnotitia.ai",
)

# 2. 지식 베이스 구축
knowledge_base = [
    "Seahorse is a high-performance vector database.",
    "It supports HNSW indexing for fast search.",
    "Seahorse integrates with LangChain.",
]

vectorstore.add_texts(
    texts=knowledge_base,
    metadatas=[{"source": "docs", "id": i} for i in range(len(knowledge_base))]
)

# 3. Retriever 생성
retriever = vectorstore.as_retriever(
    search_type="similarity",
    search_kwargs={"k": 3}
)

# 4. QA Chain 구성
qa_chain = RetrievalQA.from_chain_type(
    llm=ChatOpenAI(model="gpt-4"),
    retriever=retriever,
    return_source_documents=True,
)

# 5. 질의응답
result = qa_chain({"query": "What is Seahorse?"})
print(f"Answer: {result['result']}")
print(f"\nSources:")
for doc in result['source_documents']:
    print(f"- {doc.page_content}")
```

### Retriever 커스터마이징

```python
# Retriever 설정
retriever = vectorstore.as_retriever(
    search_type="similarity",
    search_kwargs={
        "k": 5,
        "filter": {"category": "technical"},
        "ef_search": 100,  # 더 정확한 검색
    }
)

# 사용
docs = retriever.get_relevant_documents("query")
```

---

## 성능 최적화

### 1. 배치 크기 조정

Seahorse는 자동으로 1024개씩 배치 처리합니다:

```python
# 10,000개 문서 추가
large_texts = ["document"] * 10000

# 자동으로 ~10개 배치로 나눠서 처리
ids = vectorstore.add_texts(large_texts)
```

**권장 배치 크기:**
- Small: < 100개 - 단일 요청
- Medium: 100-1000개 - 자동 배치
- Large: > 1000개 - 자동 배치 (1024개씩)

### 2. ef_search 튜닝

HNSW 검색 정확도와 속도 조절:

```python
# 빠른 검색 (정확도 낮음)
docs = vectorstore.similarity_search(
    "query",
    k=10,
    ef_search=50
)

# 정확한 검색 (속도 느림)
docs = vectorstore.similarity_search(
    "query",
    k=10,
    ef_search=200
)
```

**권장값:**
- Fast search: ef_search = 50-100
- Balanced: ef_search = k * 2 (기본값)
- Accurate: ef_search = 100-200
- Maximum: ef_search = 500

### 3. 비동기로 성능 향상

```python
import asyncio

async def process_in_parallel():
    # 여러 작업을 동시에 실행
    results = await asyncio.gather(
        vectorstore.aadd_texts(batch1),
        vectorstore.aadd_texts(batch2),
        vectorstore.aadd_texts(batch3),
    )
    return results

# 순차 실행: 30초
# 병렬 실행: 10초 (3배 빠름)
```

### 4. 메타데이터 최적화

```python
# ❌ 나쁜 예: 복잡한 중첩 구조
metadata = {
    "document": {
        "info": {
            "source": "doc.pdf"  # 필터링 불가
        }
    }
}

# ✅ 좋은 예: Flat한 구조
metadata = {
    "source": "doc.pdf",
    "page": 1,
    "author": "John",
    "category": "tech"
}
```

---

## 메타데이터 필터링

### 실전 예제: 다중 문서 관리

```python
# 여러 소스에서 문서 추가
documents = [
    # Technical documentation
    {"text": "API endpoint documentation", "metadata": {"type": "api", "version": "1.0"}},
    {"text": "System architecture overview", "metadata": {"type": "architecture", "version": "1.0"}},
    
    # User guides
    {"text": "Getting started guide", "metadata": {"type": "guide", "level": "beginner"}},
    {"text": "Advanced configuration", "metadata": {"type": "guide", "level": "advanced"}},
]

texts = [doc["text"] for doc in documents]
metadatas = [doc["metadata"] for doc in documents]

vectorstore.add_texts(texts, metadatas=metadatas)

# API 문서만 검색
api_docs = vectorstore.similarity_search(
    "endpoints",
    k=10,
    filter={"type": "api"}
)

# 초급 가이드만 검색
beginner_docs = vectorstore.similarity_search(
    "how to start",
    k=5,
    filter={"type": "guide", "level": "beginner"}
)
```

---

## 비동기 사용

### FastAPI와 통합

```python
from fastapi import FastAPI
from seahorse_vector_store import SeahorseVectorStore

app = FastAPI()

# VectorStore는 앱 시작 시 한 번만 초기화
vectorstore = SeahorseVectorStore(
    api_key=os.environ["SEAHORSE_API_KEY"],
    base_url=os.environ["SEAHORSE_BASE_URL"],
)

@app.post("/search")
async def search_documents(query: str, k: int = 5):
    """비동기 검색 엔드포인트."""
    docs = await vectorstore.asimilarity_search(query, k=k)
    
    return {
        "query": query,
        "results": [
            {
                "content": doc.page_content,
                "metadata": doc.metadata
            }
            for doc in docs
        ]
    }

@app.post("/add")
async def add_documents(texts: list[str], metadatas: list[dict] = None):
    """비동기 문서 추가 엔드포인트."""
    ids = await vectorstore.aadd_texts(texts, metadatas)
    return {"ids": ids, "count": len(ids)}
```

### 대량 데이터 처리

```python
async def process_large_dataset(texts: list[str]):
    """대용량 데이터를 효율적으로 처리."""
    
    # 청크로 나누기 (10,000개씩)
    chunk_size = 10000
    
    for i in range(0, len(texts), chunk_size):
        chunk = texts[i:i + chunk_size]
        
        # 비동기로 추가 (내부적으로 1024개씩 배치 처리)
        ids = await vectorstore.aadd_texts(chunk)
        print(f"Processed {len(ids)} documents (total: {i + len(ids)})")
    
    print(f"✅ Total {len(texts)} documents processed")
```

---

## 외부 임베딩 사용

### HuggingFace Embeddings

```python
from langchain_huggingface import HuggingFaceEmbeddings

# Local model 사용
embeddings = HuggingFaceEmbeddings(
    model_name="sentence-transformers/all-MiniLM-L6-v2",
    model_kwargs={'device': 'cpu'}
)

vectorstore = SeahorseVectorStore(
    api_key="seahorse-api-key",
    base_url="https://table-uuid.api.seahorse.dnotitia.ai",
    embedding=embeddings,
    use_builtin_embedding=False,
)
```

### 커스텀 Embeddings

```python
from langchain_core.embeddings import Embeddings
from typing import List

class CustomEmbeddings(Embeddings):
    """커스텀 임베딩 모델."""
    
    def embed_documents(self, texts: List[str]) -> List[List[float]]:
        # 커스텀 로직
        return [[0.1] * 1024 for _ in texts]
    
    def embed_query(self, text: str) -> List[float]:
        # 커스텀 로직
        return [0.1] * 1024

# 사용
vectorstore = SeahorseVectorStore(
    api_key="seahorse-api-key",
    base_url="https://table-uuid.api.seahorse.dnotitia.ai",
    embedding=CustomEmbeddings(),
    use_builtin_embedding=False,
)
```

---

## RAG 파이프라인 구축

### 1. 간단한 RAG

```python
from langchain.chains import RetrievalQA
from langchain_openai import ChatOpenAI
from seahorse_vector_store import SeahorseVectorStore

# VectorStore 초기화
vectorstore = SeahorseVectorStore(...)

# 문서 추가
vectorstore.add_texts(your_documents)

# RAG Chain 생성
qa = RetrievalQA.from_chain_type(
    llm=ChatOpenAI(model="gpt-4"),
    retriever=vectorstore.as_retriever(search_kwargs={"k": 3}),
)

# 질의
answer = qa.run("What is machine learning?")
```

### 2. 고급 RAG with 메타데이터 필터

```python
# 특정 카테고리에서만 검색
retriever = vectorstore.as_retriever(
    search_kwargs={
        "k": 5,
        "filter": {"category": "technical_docs"}
    }
)

qa = RetrievalQA.from_chain_type(
    llm=ChatOpenAI(),
    retriever=retriever,
)
```

### 3. ConversationalRetrievalChain

```python
from langchain.chains import ConversationalRetrievalChain
from langchain.memory import ConversationBufferMemory

memory = ConversationBufferMemory(
    memory_key="chat_history",
    return_messages=True
)

conversation_chain = ConversationalRetrievalChain.from_llm(
    llm=ChatOpenAI(),
    retriever=vectorstore.as_retriever(),
    memory=memory,
)

# 대화형 QA
response = conversation_chain({"question": "What is Seahorse?"})
print(response['answer'])

# 후속 질문
response = conversation_chain({"question": "How does it work?"})
print(response['answer'])
```

---

## 성능 최적화

### 벤치마크 결과

**테스트 환경:**
- 100개 문서 삽입: ~3초 (33 docs/sec)
- 1000개 문서 삽입: ~30초 (33 docs/sec)
- 단일 검색: ~0.5초
- 10개 병렬 검색 (async): ~1초

### 최적화 팁

#### 1. 대량 삽입 최적화

```python
# ❌ 나쁜 예: 하나씩 추가
for text in large_texts:
    vectorstore.add_texts([text])  # 매번 API 호출

# ✅ 좋은 예: 한 번에 추가
vectorstore.add_texts(large_texts)  # 자동 배치 처리
```

#### 2. 검색 최적화

```python
# 불필요하게 많은 결과 가져오지 않기
docs = vectorstore.similarity_search("query", k=5)  # 충분

# ef_search 조정
docs = vectorstore.similarity_search(
    "query",
    k=5,
    ef_search=50  # 빠르게
)
```

#### 3. 메모리 효율성

```python
# Generator 사용 (큰 데이터셋)
def text_generator():
    with open("large_file.txt") as f:
        for line in f:
            yield line.strip()

# 배치로 처리
batch_size = 1000
batch = []
for text in text_generator():
    batch.append(text)
    if len(batch) >= batch_size:
        vectorstore.add_texts(batch)
        batch = []

# 나머지 처리
if batch:
    vectorstore.add_texts(batch)
```

---

## 트러블슈팅

### 일반적인 문제

#### 1. 인증 에러

```python
# Error: SeahorseAuthenticationError: [401] Unauthorized

# 해결:
# 1. API Key가 올바른지 확인
# 2. API Key 권한 확인 (READ/WRITE)
# 3. Base URL이 올바른지 확인
```

#### 2. 벡터 차원 불일치

```python
# Error: SeahorseDimensionMismatchError: expected 1024, got 1536

# 해결:
# 1. 테이블 스키마 확인: GET /v1/data/schema
# 2. 임베딩 모델의 차원 확인
# 3. 일치하는 모델 사용 또는 테이블 재생성
```

#### 3. 메타데이터 필터링 안됨

```python
# 문제: filter가 작동하지 않음

# 확인사항:
# 1. metadata가 JSON 문자열로 저장되었는지 확인
# 2. 필터 키가 정확한지 확인
# 3. 값의 타입이 맞는지 확인 (문자열은 따옴표 포함)

# Debugging
docs_and_scores = vectorstore.similarity_search_with_score(
    "query",
    k=100,  # 많이 가져와서 확인
    filter={"source": "doc.pdf"}
)

# metadata 확인
for doc, score in docs_and_scores:
    print(doc.metadata)
```

#### 4. Rate Limit 에러

```python
# Error: SeahorseRateLimitError: [429] Rate limit exceeded

# 해결:
# 1. 요청 속도 줄이기
# 2. 배치 크기 조정
# 3. 재시도 로직은 자동으로 처리됨 (3회)

# 수동 재시도
import time
for attempt in range(5):
    try:
        result = vectorstore.add_texts(texts)
        break
    except SeahorseRateLimitError:
        time.sleep(2 ** attempt)  # Exponential backoff
```

#### 5. 타임아웃

```python
# 대용량 데이터 처리 시 타임아웃

# 해결: Client 타임아웃 증가
from seahorse_vector_store.client import SeahorseClient

client = SeahorseClient(
    base_url="your-url",
    api_key="your-key",
    timeout=120.0  # 2분으로 증가
)

# 또는 작은 배치로 나눠서 처리
```

### 디버깅 팁

```python
import logging

# 로깅 활성화
logging.basicConfig(level=logging.DEBUG)

# httpx 로깅 (HTTP 요청 확인)
logging.getLogger("httpx").setLevel(logging.DEBUG)

# 요청/응답 확인
vectorstore.add_texts(["test"])
```

---

## 모범 사례

### 1. 에러 처리

```python
from seahorse_vector_store import (
    SeahorseVectorStore,
    SeahorseAPIError,
    SeahorseAuthenticationError,
)

try:
    vectorstore = SeahorseVectorStore(...)
    docs = vectorstore.similarity_search("query")
    
except SeahorseAuthenticationError as e:
    print(f"Authentication failed: {e.error_message}")
    # 재인증 또는 에러 로깅
    
except SeahorseAPIError as e:
    print(f"API error {e.status_code}: {e.error_message}")
    # 재시도 또는 fallback
    
except Exception as e:
    print(f"Unexpected error: {e}")
    # 에러 로깅 및 처리
```

### 2. 리소스 관리

```python
# Context manager 패턴
class ManagedVectorStore:
    def __enter__(self):
        self.vectorstore = SeahorseVectorStore(...)
        return self.vectorstore
    
    def __exit__(self, *args):
        # Cleanup
        self.vectorstore._client.close()

# 사용
with ManagedVectorStore() as vectorstore:
    docs = vectorstore.similarity_search("query")
# 자동으로 리소스 정리
```

### 3. 환경 분리

```python
import os

# 환경별 설정
ENV = os.getenv("ENVIRONMENT", "development")

if ENV == "production":
    base_url = os.environ["SEAHORSE_PROD_URL"]
    api_key = os.environ["SEAHORSE_PROD_KEY"]
else:
    base_url = os.environ["SEAHORSE_DEV_URL"]
    api_key = os.environ["SEAHORSE_DEV_KEY"]

vectorstore = SeahorseVectorStore(
    api_key=api_key,
    base_url=base_url,
)
```

---

## 다음 단계

- [API Reference](./API_REFERENCE.md) - 전체 API 문서
- [Examples](../examples/) - 실행 가능한 예제 코드

---

**작성일:** 2025-11-21  
**버전:** 0.1.0

