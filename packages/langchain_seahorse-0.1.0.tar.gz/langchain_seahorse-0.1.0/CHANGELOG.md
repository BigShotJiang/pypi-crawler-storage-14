# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.1.0] - 2025-11-27

Initial release of LangChain Seahorse VectorStore SDK.

### Features

#### Core Functionality
- **LangChain VectorStore integration**: Full compatibility with LangChain's VectorStore interface
- **Document management**: Add, search, and delete documents with vector embeddings
- **Semantic search**: Natural language query-based similarity search
- **Vector search**: Direct vector-based similarity search with score
- **Metadata filtering**: Filter search results using SQL WHERE clause syntax
- **Batch processing**: Automatic batching for large-scale document insertion (1024 docs/batch)

#### Embedding Support
- **Built-in embeddings**: Use Seahorse's native embedding API
- **External embeddings**: Compatible with any LangChain Embeddings (OpenAI, Cohere, HuggingFace, Ollama, etc.)

#### Async Support
- Full async/await support for all core operations
- Async methods: `aadd_texts`, `asimilarity_search`, `asimilarity_search_with_score`, `asimilarity_search_by_vector`, `asimilarity_search_by_vector_with_score`, `adelete`

#### Developer Experience
- **Type-safe**: 100% type hints coverage for better IDE support
- **Well-documented**: Google-style docstrings for all public APIs
- **Easy configuration**: Environment variable support via `.env` files (python-dotenv integration)
- **Error handling**: Automatic retry logic with exponential backoff (3 retries)
- **Examples included**: 5 ready-to-run example scripts

### Technical Specifications
- **Python support**: 3.8.1 - 3.12
- **Dependencies**: langchain-core, httpx, pydantic, python-dotenv
- **Code quality**: PEP 8 compliant, Black formatted, Ruff linted
- **Test coverage**: 76% (66 tests: 47 unit + 12 integration + 7 benchmark)
- **CI/CD**: Automated testing and PyPI deployment via GitHub Actions

### Known Limitations
- **MMR search not supported**: `max_marginal_relevance_search` raises `NotImplementedError` due to Seahorse API limitation
- **Metadata type**: Metadata stored as string (JSON serialized), only equality filtering supported
- **Hybrid search**: Not available in current Seahorse API version
