"""Performance benchmarks for Seahorse VectorStore.

Run with: pytest tests/benchmarks/ -v --benchmark-only
"""

import os
import time

import pytest

from seahorse_vector_store import SeahorseVectorStore


@pytest.fixture
def benchmark_vectorstore() -> SeahorseVectorStore:
    """Create vectorstore for benchmarking."""
    api_key = os.environ.get("SEAHORSE_API_KEY")
    base_url = os.environ.get("SEAHORSE_BASE_URL")

    if not api_key or not base_url:
        pytest.skip("SEAHORSE_API_KEY and SEAHORSE_BASE_URL required for benchmarks")

    return SeahorseVectorStore(
        api_key=api_key,
        base_url=base_url,
    )


@pytest.fixture
def small_dataset() -> tuple:
    """Small dataset for benchmarking (100 docs)."""
    texts = [
        f"This is test document number {i} about machine learning." for i in range(100)
    ]
    metadatas = [{"doc_id": i, "category": "test"} for i in range(100)]
    return texts, metadatas


@pytest.fixture
def medium_dataset() -> tuple:
    """Medium dataset for benchmarking (1000 docs)."""
    texts = [
        f"Document {i}: Deep learning and neural networks are powerful tools."
        for i in range(1000)
    ]
    metadatas = [{"doc_id": i, "category": "benchmark"} for i in range(1000)]
    return texts, metadatas


@pytest.mark.benchmark
class TestInsertPerformance:
    """Benchmark insert operations."""

    def test_insert_small_batch(
        self,
        benchmark_vectorstore: SeahorseVectorStore,
        small_dataset: tuple,
    ) -> None:
        """Benchmark inserting 100 documents."""
        texts, metadatas = small_dataset

        start_time = time.time()
        ids = benchmark_vectorstore.add_texts(texts, metadatas)
        elapsed = time.time() - start_time

        # Cleanup
        benchmark_vectorstore.delete(ids=ids)

        print(f"\n📊 Insert 100 docs: {elapsed:.2f}s ({100/elapsed:.1f} docs/sec)")
        assert len(ids) == 100
        assert elapsed < 60  # Should complete within 60 seconds

    def test_insert_medium_batch(
        self,
        benchmark_vectorstore: SeahorseVectorStore,
        medium_dataset: tuple,
    ) -> None:
        """Benchmark inserting 1000 documents."""
        texts, metadatas = medium_dataset

        start_time = time.time()
        ids = benchmark_vectorstore.add_texts(texts, metadatas)
        elapsed = time.time() - start_time

        # Cleanup
        benchmark_vectorstore.delete(ids=ids)

        print(f"\n📊 Insert 1000 docs: {elapsed:.2f}s ({1000/elapsed:.1f} docs/sec)")
        assert len(ids) == 1000
        assert elapsed < 300  # Should complete within 5 minutes


@pytest.mark.benchmark
@pytest.mark.asyncio
class TestAsyncInsertPerformance:
    """Benchmark async insert operations."""

    async def test_async_insert_small_batch(
        self,
        benchmark_vectorstore: SeahorseVectorStore,
        small_dataset: tuple,
    ) -> None:
        """Benchmark async inserting 100 documents."""
        texts, metadatas = small_dataset

        start_time = time.time()
        ids = await benchmark_vectorstore.aadd_texts(texts, metadatas)
        elapsed = time.time() - start_time

        # Cleanup
        await benchmark_vectorstore.adelete(ids=ids)

        print(
            f"\n📊 Async insert 100 docs: {elapsed:.2f}s ({100/elapsed:.1f} docs/sec)"
        )
        assert len(ids) == 100
        assert elapsed < 60


@pytest.mark.benchmark
class TestSearchPerformance:
    """Benchmark search operations."""

    @pytest.fixture(autouse=True)
    def setup_search_data(
        self,
        benchmark_vectorstore: SeahorseVectorStore,
        small_dataset: tuple,
    ) -> None:
        """Setup test data for search benchmarks."""
        texts, metadatas = small_dataset
        self.ids = benchmark_vectorstore.add_texts(texts, metadatas)
        self.vectorstore = benchmark_vectorstore

        yield

        # Cleanup
        self.vectorstore.delete(ids=self.ids)

    def test_search_performance(self) -> None:
        """Benchmark similarity search."""
        queries = [
            "machine learning algorithms",
            "deep neural networks",
            "natural language processing",
        ]

        start_time = time.time()
        for query in queries:
            docs = self.vectorstore.similarity_search(query, k=10)
            assert len(docs) <= 10
        elapsed = time.time() - start_time

        print(
            f"\n📊 {len(queries)} searches: {elapsed:.2f}s ({len(queries)/elapsed:.1f} queries/sec)"
        )
        assert elapsed < 10  # Should complete within 10 seconds

    def test_search_with_filter_performance(self) -> None:
        """Benchmark search with metadata filter."""
        start_time = time.time()
        _ = self.vectorstore.similarity_search(
            "test document", k=20, filter={"category": "test"}
        )
        elapsed = time.time() - start_time

        print(f"\n📊 Filtered search: {elapsed:.2f}s")
        assert elapsed < 5


@pytest.mark.benchmark
@pytest.mark.asyncio
class TestAsyncSearchPerformance:
    """Benchmark async search operations."""

    async def test_async_search_performance(
        self,
        benchmark_vectorstore: SeahorseVectorStore,
        small_dataset: tuple,
    ) -> None:
        """Benchmark async similarity search."""
        # Setup
        texts, metadatas = small_dataset
        ids = await benchmark_vectorstore.aadd_texts(texts, metadatas)

        # Benchmark
        queries = [
            "machine learning",
            "deep learning",
            "neural networks",
        ]

        start_time = time.time()
        for query in queries:
            docs = await benchmark_vectorstore.asimilarity_search(query, k=10)
            assert len(docs) <= 10
        elapsed = time.time() - start_time

        print(
            f"\n📊 Async {len(queries)} searches: {elapsed:.2f}s ({len(queries)/elapsed:.1f} queries/sec)"
        )
        assert elapsed < 10

        # Cleanup
        await benchmark_vectorstore.adelete(ids=ids)
