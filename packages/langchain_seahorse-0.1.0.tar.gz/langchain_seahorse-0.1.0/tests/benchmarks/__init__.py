"""Performance benchmarks for Seahorse VectorStore."""
