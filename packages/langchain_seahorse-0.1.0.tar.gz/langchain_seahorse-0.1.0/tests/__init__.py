"""Tests for Seahorse Vector Store."""
