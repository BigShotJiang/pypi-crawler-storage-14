"""Unit tests for SeahorseVectorStore."""

from unittest.mock import MagicMock, Mock, patch

import pytest

from seahorse_vector_store.vectorstores import SeahorseVectorStore


class TestSeahorseVectorStore:
    """Tests for SeahorseVectorStore class."""

    @patch("seahorse_vector_store.vectorstores.SeahorseClient")
    def test_init_builtin_embedding(
        self,
        mock_client_class: Mock,
        mock_api_key: str,
        mock_base_url: str,
    ) -> None:
        """Test initialization with builtin embedding."""
        vectorstore = SeahorseVectorStore(
            api_key=mock_api_key,
            base_url=mock_base_url,
            use_builtin_embedding=True,
        )

        assert vectorstore._use_builtin_embedding is True
        assert vectorstore._embedding is None
        assert vectorstore._index_name == "embedding"

    @patch("seahorse_vector_store.vectorstores.SeahorseClient")
    def test_init_external_embedding(
        self,
        mock_client_class: Mock,
        mock_api_key: str,
        mock_base_url: str,
    ) -> None:
        """Test initialization with external embedding."""
        mock_embedding = Mock()

        vectorstore = SeahorseVectorStore(
            api_key=mock_api_key,
            base_url=mock_base_url,
            embedding=mock_embedding,
            use_builtin_embedding=False,
        )

        assert vectorstore._use_builtin_embedding is False
        assert vectorstore._embedding is mock_embedding

    @patch("seahorse_vector_store.vectorstores.SeahorseClient")
    def test_init_conflict_error(
        self,
        mock_client_class: Mock,
        mock_api_key: str,
        mock_base_url: str,
    ) -> None:
        """Test initialization error when both builtin and external embedding specified."""
        mock_embedding = Mock()

        with pytest.raises(ValueError, match="Cannot specify both"):
            SeahorseVectorStore(
                api_key=mock_api_key,
                base_url=mock_base_url,
                embedding=mock_embedding,
                use_builtin_embedding=True,
            )

    @patch("seahorse_vector_store.vectorstores.SeahorseClient")
    def test_init_missing_embedding(
        self,
        mock_client_class: Mock,
        mock_api_key: str,
        mock_base_url: str,
    ) -> None:
        """Test initialization error when external embedding not provided."""
        with pytest.raises(ValueError, match="Must provide embedding"):
            SeahorseVectorStore(
                api_key=mock_api_key,
                base_url=mock_base_url,
                use_builtin_embedding=False,
            )

    @patch("seahorse_vector_store.vectorstores.SeahorseClient")
    def test_add_texts_builtin(
        self,
        mock_client_class: Mock,
        mock_api_key: str,
        mock_base_url: str,
        sample_texts: list,
        sample_metadatas: list,
    ) -> None:
        """Test add_texts with builtin embedding."""
        # Setup mock client
        mock_client = MagicMock()
        mock_client.insert_with_embedding.return_value = {
            "inserted_row_count": 3,
        }
        mock_client_class.return_value = mock_client

        # Create vectorstore
        vectorstore = SeahorseVectorStore(
            api_key=mock_api_key,
            base_url=mock_base_url,
            use_builtin_embedding=True,
        )
        vectorstore._client = mock_client

        # Add texts
        ids = vectorstore.add_texts(sample_texts, sample_metadatas)

        # Verify
        assert len(ids) == len(sample_texts)
        mock_client.insert_with_embedding.assert_called_once()

    @patch("seahorse_vector_store.vectorstores.SeahorseClient")
    def test_add_texts_external(
        self,
        mock_client_class: Mock,
        mock_api_key: str,
        mock_base_url: str,
        sample_texts: list,
        sample_metadatas: list,
        sample_embedding: list,
    ) -> None:
        """Test add_texts with external embedding."""
        # Setup mock client
        mock_client = MagicMock()
        mock_client.insert_jsonl.return_value = {
            "inserted_row_count": 3,
        }
        mock_client_class.return_value = mock_client

        # Setup mock embedding
        mock_embedding = Mock()
        mock_embedding.embed_documents.return_value = [
            sample_embedding,
            sample_embedding,
            sample_embedding,
        ]

        # Create vectorstore
        vectorstore = SeahorseVectorStore(
            api_key=mock_api_key,
            base_url=mock_base_url,
            embedding=mock_embedding,
            use_builtin_embedding=False,
        )
        vectorstore._client = mock_client

        # Add texts
        ids = vectorstore.add_texts(sample_texts, sample_metadatas)

        # Verify
        assert len(ids) == len(sample_texts)
        mock_embedding.embed_documents.assert_called_once_with(sample_texts)
        mock_client.insert_jsonl.assert_called_once()

    @patch("seahorse_vector_store.vectorstores.SeahorseClient")
    def test_similarity_search(
        self,
        mock_client_class: Mock,
        mock_api_key: str,
        mock_base_url: str,
        mock_search_results: list,
    ) -> None:
        """Test similarity_search method."""
        # Setup mock client
        mock_client = MagicMock()
        mock_client.semantic_search.return_value = mock_search_results
        mock_client_class.return_value = mock_client

        # Create vectorstore
        vectorstore = SeahorseVectorStore(
            api_key=mock_api_key,
            base_url=mock_base_url,
        )
        vectorstore._client = mock_client

        # Search
        docs = vectorstore.similarity_search("machine learning", k=2)

        # Verify
        assert len(docs) == 2
        assert docs[0].page_content == "Machine learning is fun"
        assert docs[0].metadata["source"] == "doc1.pdf"
        mock_client.semantic_search.assert_called_once()

    @patch("seahorse_vector_store.vectorstores.SeahorseClient")
    def test_similarity_search_with_filter(
        self,
        mock_client_class: Mock,
        mock_api_key: str,
        mock_base_url: str,
        mock_search_results: list,
    ) -> None:
        """Test similarity_search with metadata filter."""
        # Setup mock client
        mock_client = MagicMock()
        mock_client.semantic_search.return_value = mock_search_results
        mock_client_class.return_value = mock_client

        # Create vectorstore
        vectorstore = SeahorseVectorStore(
            api_key=mock_api_key,
            base_url=mock_base_url,
        )
        vectorstore._client = mock_client

        # Search with filter
        filter_dict = {"source": "doc1.pdf"}
        docs = vectorstore.similarity_search("test", k=2, filter=filter_dict)

        # Verify
        assert len(docs) == 2

        # Check that filter was converted to SQL and passed to API
        call_args = mock_client.semantic_search.call_args
        assert call_args.kwargs["filter_sql"] is not None
        assert "metadata LIKE" in call_args.kwargs["filter_sql"]
        # Check that we requested k results (not k*10)
        assert call_args.kwargs["top_k"] == 2

    @patch("seahorse_vector_store.vectorstores.SeahorseClient")
    def test_delete(
        self,
        mock_client_class: Mock,
        mock_api_key: str,
        mock_base_url: str,
    ) -> None:
        """Test delete method."""
        # Setup mock client
        mock_client = MagicMock()
        mock_client.delete_data.return_value = {"deleted_row_count": 2}
        mock_client_class.return_value = mock_client

        # Create vectorstore
        vectorstore = SeahorseVectorStore(
            api_key=mock_api_key,
            base_url=mock_base_url,
        )
        vectorstore._client = mock_client

        # Delete
        result = vectorstore.delete(ids=["id1", "id2"])

        # Verify
        assert result is True
        mock_client.delete_data.assert_called_once()

    @patch("seahorse_vector_store.vectorstores.SeahorseClient")
    def test_from_texts(
        self,
        mock_client_class: Mock,
        mock_api_key: str,
        mock_base_url: str,
        sample_texts: list,
        sample_metadatas: list,
    ) -> None:
        """Test from_texts class method."""
        # Setup mock client
        mock_client = MagicMock()
        mock_client.insert_with_embedding.return_value = {
            "inserted_row_count": 3,
        }
        mock_client_class.return_value = mock_client

        # Create vectorstore from texts
        vectorstore = SeahorseVectorStore.from_texts(
            texts=sample_texts,
            metadatas=sample_metadatas,
            api_key=mock_api_key,
            base_url=mock_base_url,
        )

        # Verify
        assert isinstance(vectorstore, SeahorseVectorStore)
        mock_client.insert_with_embedding.assert_called_once()
