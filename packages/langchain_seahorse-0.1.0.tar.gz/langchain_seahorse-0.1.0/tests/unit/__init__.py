"""Unit tests for Seahorse Vector Store."""
