"""Unit tests for filters module."""

import pytest

from seahorse_vector_store.filters import convert_filter_to_sql


class TestConvertFilterToSQL:
    """Tests for convert_filter_to_sql function."""

    def test_convert_filter_string_value(self) -> None:
        """Test filter conversion with string value."""
        filter_dict = {"source": "doc.pdf"}
        sql = convert_filter_to_sql(filter_dict)

        assert "metadata LIKE" in sql
        assert '"source"' in sql
        assert '"doc.pdf"' in sql

    def test_convert_filter_int_value(self) -> None:
        """Test filter conversion with integer value."""
        filter_dict = {"page": 10}
        sql = convert_filter_to_sql(filter_dict)

        assert "metadata LIKE" in sql
        assert '"page"' in sql
        assert "10" in sql
        # Integer should not have quotes
        assert '"10"' not in sql

    def test_convert_filter_float_value(self) -> None:
        """Test filter conversion with float value."""
        filter_dict = {"score": 0.95}
        sql = convert_filter_to_sql(filter_dict)

        assert "metadata LIKE" in sql
        assert '"score"' in sql
        assert "0.95" in sql

    def test_convert_filter_bool_value(self) -> None:
        """Test filter conversion with boolean value."""
        filter_dict = {"is_active": True}
        sql = convert_filter_to_sql(filter_dict)

        assert "metadata LIKE" in sql
        assert '"is_active"' in sql
        assert "true" in sql  # JSON uses lowercase

    def test_convert_filter_null_value(self) -> None:
        """Test filter conversion with null value."""
        filter_dict = {"optional_field": None}
        sql = convert_filter_to_sql(filter_dict)

        assert "metadata LIKE" in sql
        assert '"optional_field"' in sql
        assert "null" in sql

    def test_convert_filter_multiple_conditions(self) -> None:
        """Test filter conversion with multiple conditions."""
        filter_dict = {"source": "doc.pdf", "page": 5}
        sql = convert_filter_to_sql(filter_dict)

        assert "AND" in sql
        assert '"source"' in sql
        assert '"page"' in sql

    def test_convert_filter_eq_operator(self) -> None:
        """Test filter conversion with explicit $eq operator."""
        filter_dict = {"source": {"$eq": "doc.pdf"}}
        sql = convert_filter_to_sql(filter_dict)

        assert "metadata LIKE" in sql
        assert '"source"' in sql
        assert '"doc.pdf"' in sql

    def test_convert_filter_unsupported_operator(self) -> None:
        """Test filter conversion with unsupported operator."""
        filter_dict = {"page": {"$gt": 10}}

        with pytest.raises(ValueError, match="not supported"):
            convert_filter_to_sql(filter_dict)

    def test_convert_filter_escape_quotes(self) -> None:
        """Test filter conversion with quotes in value."""
        filter_dict = {"title": "Book's Guide"}  # Single quote in value
        sql = convert_filter_to_sql(filter_dict)

        # Single quotes should be escaped for SQL
        assert "''" in sql  # SQL escapes ' as ''

    def test_convert_filter_unsupported_type(self) -> None:
        """Test filter conversion with unsupported value type."""
        filter_dict = {"data": [1, 2, 3]}  # list is not supported

        with pytest.raises(ValueError, match="Unsupported value type"):
            convert_filter_to_sql(filter_dict)
