"""Unit tests for utils module."""

from seahorse_vector_store.utils import (
    DEFAULT_BATCH_SIZE,
    batch_texts,
    estimate_json_size,
    generate_pk,
)


class TestGeneratePK:
    """Tests for generate_pk function."""

    def test_generate_pk_basic(self) -> None:
        """Test basic PK generation."""
        pk = generate_pk("Hello, world!", chunk_id=0)

        # PK should contain separator \x1e
        assert "\x1e" in pk

        # PK should end with chunk_id
        assert pk.endswith("\x1e0")

        # PK should be deterministic
        pk2 = generate_pk("Hello, world!", chunk_id=0)
        assert pk == pk2

    def test_generate_pk_different_content(self) -> None:
        """Test PK generation with different content."""
        pk1 = generate_pk("content1", chunk_id=0)
        pk2 = generate_pk("content2", chunk_id=0)

        # Different content should produce different PKs
        assert pk1 != pk2

    def test_generate_pk_different_chunk_id(self) -> None:
        """Test PK generation with different chunk IDs."""
        pk1 = generate_pk("same content", chunk_id=0)
        pk2 = generate_pk("same content", chunk_id=1)

        # Same content but different chunk_id should differ only in suffix
        assert pk1.split("\x1e")[0] == pk2.split("\x1e")[0]
        assert pk1 != pk2


class TestBatchTexts:
    """Tests for batch_texts function."""

    def test_batch_texts_basic(self) -> None:
        """Test basic batching."""
        texts = ["text1", "text2", "text3"]
        metadatas = [{"id": 1}, {"id": 2}, {"id": 3}]

        batches = list(batch_texts(texts, metadatas, batch_size=2))

        assert len(batches) == 2
        assert len(batches[0][0]) == 2
        assert len(batches[1][0]) == 1

    def test_batch_texts_exact_size(self) -> None:
        """Test batching with exact size."""
        texts = ["text1", "text2"]
        metadatas = [{"id": 1}, {"id": 2}]

        batches = list(batch_texts(texts, metadatas, batch_size=2))

        assert len(batches) == 1
        assert len(batches[0][0]) == 2

    def test_batch_texts_default_size(self) -> None:
        """Test batching with default size."""
        texts = ["text"] * 2000
        metadatas = [{"id": i} for i in range(2000)]

        batches = list(batch_texts(texts, metadatas))

        # Default batch size is 1024
        assert len(batches) == 2
        assert len(batches[0][0]) == DEFAULT_BATCH_SIZE


class TestEstimateJsonSize:
    """Tests for estimate_json_size function."""

    def test_estimate_json_size_simple(self) -> None:
        """Test JSON size estimation for simple data."""
        data = {"key": "value"}
        size = estimate_json_size(data)

        assert size > 0
        assert isinstance(size, int)

    def test_estimate_json_size_large(self) -> None:
        """Test JSON size estimation for large data."""
        data = {"key": "value" * 1000}
        size = estimate_json_size(data)

        # Should be approximately 5000+ bytes
        assert size > 5000
