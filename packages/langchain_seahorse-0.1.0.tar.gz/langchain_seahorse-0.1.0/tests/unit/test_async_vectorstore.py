"""Unit tests for SeahorseVectorStore async methods."""

from unittest.mock import MagicMock, Mock, patch

import pytest

from seahorse_vector_store.vectorstores import SeahorseVectorStore


class TestSeahorseVectorStoreAsync:
    """Tests for SeahorseVectorStore async methods."""

    @pytest.mark.asyncio
    @patch("seahorse_vector_store.vectorstores.SeahorseClient")
    async def test_aadd_texts_builtin(
        self,
        mock_client_class: Mock,
        mock_api_key: str,
        mock_base_url: str,
        sample_texts: list,
        sample_metadatas: list,
    ) -> None:
        """Test async add_texts with builtin embedding."""
        # Setup mock client
        mock_client = MagicMock()

        async def mock_insert(*args, **kwargs):
            return {"inserted_row_count": 3}

        mock_client.ainsert_with_embedding = mock_insert
        mock_client_class.return_value = mock_client

        # Create vectorstore
        vectorstore = SeahorseVectorStore(
            api_key=mock_api_key,
            base_url=mock_base_url,
            use_builtin_embedding=True,
        )
        vectorstore._client = mock_client

        # Add texts
        ids = await vectorstore.aadd_texts(sample_texts, sample_metadatas)

        # Verify
        assert len(ids) == len(sample_texts)
        assert all(isinstance(id, str) for id in ids)

    @pytest.mark.asyncio
    @patch("seahorse_vector_store.vectorstores.SeahorseClient")
    async def test_aadd_texts_external(
        self,
        mock_client_class: Mock,
        mock_api_key: str,
        mock_base_url: str,
        sample_texts: list,
        sample_metadatas: list,
        sample_embedding: list,
    ) -> None:
        """Test async add_texts with external embedding."""
        # Setup mock client
        mock_client = MagicMock()

        async def mock_insert_jsonl(*args, **kwargs):
            return {"inserted_row_count": 3}

        mock_client.ainsert_jsonl = mock_insert_jsonl
        mock_client_class.return_value = mock_client

        # Setup mock embedding
        mock_embedding = Mock()
        mock_embedding.embed_documents.return_value = [
            sample_embedding,
            sample_embedding,
            sample_embedding,
        ]

        # Create vectorstore
        vectorstore = SeahorseVectorStore(
            api_key=mock_api_key,
            base_url=mock_base_url,
            embedding=mock_embedding,
            use_builtin_embedding=False,
        )
        vectorstore._client = mock_client

        # Add texts
        ids = await vectorstore.aadd_texts(sample_texts, sample_metadatas)

        # Verify
        assert len(ids) == len(sample_texts)
        mock_embedding.embed_documents.assert_called_once_with(sample_texts)

    @pytest.mark.asyncio
    @patch("seahorse_vector_store.vectorstores.SeahorseClient")
    async def test_asimilarity_search(
        self,
        mock_client_class: Mock,
        mock_api_key: str,
        mock_base_url: str,
        mock_search_results: list,
    ) -> None:
        """Test async similarity_search method."""
        # Setup mock client
        mock_client = MagicMock()

        async def mock_search(*args, **kwargs):
            return mock_search_results

        mock_client.asemantic_search = mock_search
        mock_client_class.return_value = mock_client

        # Create vectorstore
        vectorstore = SeahorseVectorStore(
            api_key=mock_api_key,
            base_url=mock_base_url,
        )
        vectorstore._client = mock_client

        # Search
        docs = await vectorstore.asimilarity_search("machine learning", k=2)

        # Verify
        assert len(docs) == 2
        assert docs[0].page_content == "Machine learning is fun"
        assert docs[0].metadata["source"] == "doc1.pdf"

    @pytest.mark.asyncio
    @patch("seahorse_vector_store.vectorstores.SeahorseClient")
    async def test_asimilarity_search_with_score(
        self,
        mock_client_class: Mock,
        mock_api_key: str,
        mock_base_url: str,
        mock_search_results: list,
    ) -> None:
        """Test async similarity_search_with_score method."""
        # Setup mock client
        mock_client = MagicMock()

        async def mock_search(*args, **kwargs):
            return mock_search_results

        mock_client.asemantic_search = mock_search
        mock_client_class.return_value = mock_client

        # Create vectorstore
        vectorstore = SeahorseVectorStore(
            api_key=mock_api_key,
            base_url=mock_base_url,
        )
        vectorstore._client = mock_client

        # Search with score
        docs_and_scores = await vectorstore.asimilarity_search_with_score(
            "test query", k=2
        )

        # Verify
        assert len(docs_and_scores) == 2
        doc, score = docs_and_scores[0]
        assert hasattr(doc, "page_content")
        assert isinstance(score, float)
        assert score == 0.15

    @pytest.mark.asyncio
    @patch("seahorse_vector_store.vectorstores.SeahorseClient")
    async def test_asimilarity_search_by_vector(
        self,
        mock_client_class: Mock,
        mock_api_key: str,
        mock_base_url: str,
        mock_search_results: list,
        sample_embedding: list,
    ) -> None:
        """Test async similarity_search_by_vector method."""
        # Setup mock client
        mock_client = MagicMock()

        async def mock_vector_search(*args, **kwargs):
            return [mock_search_results]

        mock_client.avector_search = mock_vector_search
        mock_client_class.return_value = mock_client

        # Create vectorstore
        vectorstore = SeahorseVectorStore(
            api_key=mock_api_key,
            base_url=mock_base_url,
        )
        vectorstore._client = mock_client

        # Search by vector
        docs = await vectorstore.asimilarity_search_by_vector(sample_embedding, k=2)

        # Verify
        assert len(docs) == 2
        assert all(hasattr(doc, "page_content") for doc in docs)

    @pytest.mark.asyncio
    @patch("seahorse_vector_store.vectorstores.SeahorseClient")
    async def test_adelete(
        self,
        mock_client_class: Mock,
        mock_api_key: str,
        mock_base_url: str,
    ) -> None:
        """Test async delete method."""
        # Setup mock client
        mock_client = MagicMock()

        async def mock_delete(*args, **kwargs):
            return {"deleted_row_count": 2}

        mock_client.adelete_data = mock_delete
        mock_client_class.return_value = mock_client

        # Create vectorstore
        vectorstore = SeahorseVectorStore(
            api_key=mock_api_key,
            base_url=mock_base_url,
        )
        vectorstore._client = mock_client

        # Delete
        result = await vectorstore.adelete(ids=["id1", "id2"])

        # Verify
        assert result is True

    @pytest.mark.asyncio
    @patch("seahorse_vector_store.vectorstores.SeahorseClient")
    async def test_adelete_empty_list(
        self,
        mock_client_class: Mock,
        mock_api_key: str,
        mock_base_url: str,
    ) -> None:
        """Test async delete with empty ID list."""
        mock_client = MagicMock()
        mock_client_class.return_value = mock_client

        # Create vectorstore
        vectorstore = SeahorseVectorStore(
            api_key=mock_api_key,
            base_url=mock_base_url,
        )
        vectorstore._client = mock_client

        # Delete with empty list
        result = await vectorstore.adelete(ids=[])

        # Should return None
        assert result is None
