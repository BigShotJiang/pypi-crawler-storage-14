"""Pytest configuration and fixtures."""

import pytest


@pytest.fixture
def mock_api_key() -> str:
    """Mock API key for testing."""
    return "test-api-key-12345"


@pytest.fixture
def mock_base_url() -> str:
    """Mock base URL for testing."""
    return "https://test-table-uuid.api.seahorse.dnotitia.ai"


@pytest.fixture
def sample_texts() -> list:
    """Sample texts for testing."""
    return [
        "Machine learning is a subset of artificial intelligence.",
        "Deep learning uses neural networks with multiple layers.",
        "Natural language processing enables computers to understand human language.",
    ]


@pytest.fixture
def sample_metadatas() -> list:
    """Sample metadatas for testing."""
    return [
        {"source": "doc1.pdf", "page": 1},
        {"source": "doc2.pdf", "page": 5},
        {"source": "doc3.pdf", "page": 10},
    ]


@pytest.fixture
def sample_embedding() -> list:
    """Sample embedding vector (1024 dimensions)."""
    return [0.1] * 1024


@pytest.fixture
def mock_coral_response_success() -> dict:
    """Mock successful CoralResponse."""
    return {
        "success": True,
        "code": 200,
        "data": {
            "inserted_row_count": 3,
            "inserted_record_batches": 1,
            "elapsed_time": 0.5,
        },
        "exception": None,
    }


@pytest.fixture
def mock_coral_response_error() -> dict:
    """Mock error CoralResponse."""
    return {
        "success": False,
        "code": 400,
        "data": None,
        "exception": {
            "error_code": 400001,
            "error_message": "Bad Request: Invalid parameter",
        },
    }


@pytest.fixture
def mock_search_results() -> list:
    """Mock search results."""
    return [
        {
            "id": "doc1_hash\x1e0",
            "text": "Machine learning is fun",
            "metadata": '{"source": "doc1.pdf", "page": 1}',
            "distance": 0.15,
        },
        {
            "id": "doc2_hash\x1e0",
            "text": "Deep learning is powerful",
            "metadata": '{"source": "doc2.pdf", "page": 2}',
            "distance": 0.25,
        },
    ]
