"""Integration tests for VectorStore as Retriever."""

import pytest

from seahorse_vector_store import SeahorseVectorStore


@pytest.mark.integration
class TestRetriever:
    """Integration tests for using VectorStore as Retriever."""

    def test_as_retriever_basic(
        self,
        api_key: str,
        base_url: str,
    ) -> None:
        """Test basic retriever functionality."""
        vectorstore = SeahorseVectorStore(
            api_key=api_key,
            base_url=base_url,
        )

        # Add test documents
        texts = [
            "The quick brown fox jumps over the lazy dog.",
            "Python is a popular programming language.",
            "Machine learning enables computers to learn from data.",
            "LangChain is a framework for developing LLM applications.",
        ]

        metadatas = [
            {"category": "animals", "id": 1},
            {"category": "programming", "id": 2},
            {"category": "ai", "id": 3},
            {"category": "frameworks", "id": 4},
        ]

        ids = vectorstore.add_texts(texts=texts, metadatas=metadatas)

        # Convert to retriever
        print("\n🔧 Creating retriever...")
        retriever = vectorstore.as_retriever(
            search_type="similarity", search_kwargs={"k": 2}
        )

        # Test retrieval
        print("\n🔍 Testing retriever.invoke()...")
        docs = retriever.invoke("programming languages")

        assert len(docs) <= 2
        assert all(hasattr(doc, "page_content") for doc in docs)
        assert all(hasattr(doc, "metadata") for doc in docs)

        print(f"✅ Retriever returned {len(docs)} documents")
        for i, doc in enumerate(docs, 1):
            print(f"  {i}. {doc.page_content[:60]}...")
            print(f"     Category: {doc.metadata.get('category', 'N/A')}")

        # Test batch invoke (LangChain standard)
        print("\n🔍 Testing retriever.batch()...")
        queries = ["programming", "machine learning"]
        batch_results = retriever.batch(queries)

        assert len(batch_results) == 2
        print(f"✅ batch() returned results for {len(batch_results)} queries")

        # Cleanup
        vectorstore.delete(ids=ids)

    def test_retriever_with_filter(
        self,
        api_key: str,
        base_url: str,
    ) -> None:
        """Test retriever with metadata filter."""
        vectorstore = SeahorseVectorStore(
            api_key=api_key,
            base_url=base_url,
        )

        # Add documents
        texts = [
            "Python tutorial for beginners",
            "Advanced Python programming",
            "JavaScript fundamentals",
            "React framework overview",
        ]

        metadatas = [
            {"language": "python", "level": "beginner"},
            {"language": "python", "level": "advanced"},
            {"language": "javascript", "level": "beginner"},
            {"language": "javascript", "level": "intermediate"},
        ]

        ids = vectorstore.add_texts(texts=texts, metadatas=metadatas)

        # Create retriever with filter
        print("\n🔧 Creating retriever with filter (language=python)...")
        retriever = vectorstore.as_retriever(
            search_kwargs={"k": 5, "filter": {"language": "python"}}
        )

        # Retrieve
        docs = retriever.invoke("programming tutorial")

        # Check filter effectiveness
        python_count = sum(
            1 for doc in docs if doc.metadata.get("language") == "python"
        )
        print(f"\n📊 Filter results: {python_count}/{len(docs)} are Python documents")

        for i, doc in enumerate(docs, 1):
            print(f"  {i}. {doc.page_content}")
            lang = doc.metadata.get("language", "N/A")
            level = doc.metadata.get("level", "N/A")
            print(f"     Language: {lang}, Level: {level}")

        # Verify at least some filtering occurred
        assert len(docs) > 0
        print(f"✅ Retriever with filter returned {len(docs)} documents")

        # Cleanup
        vectorstore.delete(ids=ids)

    def test_retriever_with_custom_search_kwargs(
        self,
        api_key: str,
        base_url: str,
    ) -> None:
        """Test retriever with custom search kwargs (ef_search)."""
        vectorstore = SeahorseVectorStore(
            api_key=api_key,
            base_url=base_url,
        )

        # Add documents
        texts = [
            f"Document number {i} about AI and machine learning." for i in range(10)
        ]
        metadatas = [{"doc_num": i} for i in range(10)]

        ids = vectorstore.add_texts(texts=texts, metadatas=metadatas)

        # Create retriever with custom ef_search
        print("\n🔧 Creating retriever with ef_search=100...")
        retriever = vectorstore.as_retriever(
            search_kwargs={
                "k": 5,
                "ef_search": 100,  # Higher accuracy
            }
        )

        # Retrieve
        docs = retriever.invoke("artificial intelligence and ML")

        assert len(docs) <= 5
        print(f"✅ Retriever with ef_search=100 returned {len(docs)} documents")

        # Cleanup
        vectorstore.delete(ids=ids)

    @pytest.mark.asyncio
    async def test_retriever_async_compatibility(
        self,
        api_key: str,
        base_url: str,
    ) -> None:
        """Test that retriever works with async vectorstore methods."""
        vectorstore = SeahorseVectorStore(
            api_key=api_key,
            base_url=base_url,
        )

        # Add documents asynchronously
        texts = ["Async document 1", "Async document 2", "Async document 3"]
        metadatas = [{"async": True, "id": i} for i in range(3)]

        ids = await vectorstore.aadd_texts(texts=texts, metadatas=metadatas)

        # Create retriever (sync interface)
        retriever = vectorstore.as_retriever(search_kwargs={"k": 2})

        # Use retriever (sync)
        docs = retriever.invoke("async")

        assert len(docs) <= 2
        print(f"\n✅ Retriever works after async add: {len(docs)} documents")

        # Cleanup
        await vectorstore.adelete(ids=ids)
