"""Integration tests for add_texts functionality."""

import pytest

from seahorse_vector_store import SeahorseVectorStore


@pytest.mark.integration
class TestAddTexts:
    """Integration tests for adding texts to Seahorse."""

    def test_add_texts_builtin_embedding(
        self,
        api_key: str,
        base_url: str,
        integration_texts: list,
        integration_metadatas: list,
    ) -> None:
        """Test adding texts with builtin embedding."""
        vectorstore = SeahorseVectorStore(
            api_key=api_key,
            base_url=base_url,
            use_builtin_embedding=True,
        )

        # Add texts
        ids = vectorstore.add_texts(
            texts=integration_texts,
            metadatas=integration_metadatas,
        )

        # Verify
        assert len(ids) == len(integration_texts)
        assert all(isinstance(id, str) for id in ids)
        assert all("\x1e" in id for id in ids)  # Should contain separator

        # Cleanup - delete added texts
        vectorstore.delete(ids=ids)

    def test_add_texts_no_metadata(
        self,
        api_key: str,
        base_url: str,
    ) -> None:
        """Test adding texts without metadata."""
        vectorstore = SeahorseVectorStore(
            api_key=api_key,
            base_url=base_url,
        )

        texts = ["Test text without metadata"]

        # Add texts
        ids = vectorstore.add_texts(texts=texts)

        # Verify
        assert len(ids) == 1

        # Cleanup
        vectorstore.delete(ids=ids)

    def test_from_texts(
        self,
        api_key: str,
        base_url: str,
        integration_texts: list,
        integration_metadatas: list,
    ) -> None:
        """Test creating vectorstore from texts."""
        vectorstore = SeahorseVectorStore.from_texts(
            texts=integration_texts,
            metadatas=integration_metadatas,
            api_key=api_key,
            base_url=base_url,
        )

        # Verify
        assert isinstance(vectorstore, SeahorseVectorStore)

        # Note: Cleanup is difficult here without IDs
        # Recommend using a separate test table that can be cleared
