"""Integration tests for search functionality."""

import pytest

from seahorse_vector_store import SeahorseVectorStore


@pytest.mark.integration
class TestSearch:
    """Integration tests for searching in Seahorse."""

    @pytest.fixture(autouse=True)
    def setup_test_data(
        self,
        api_key: str,
        base_url: str,
        integration_texts: list,
        integration_metadatas: list,
    ) -> None:
        """Setup test data before each test."""
        self.vectorstore = SeahorseVectorStore(
            api_key=api_key,
            base_url=base_url,
        )

        # Add test texts
        self.ids = self.vectorstore.add_texts(
            texts=integration_texts,
            metadatas=integration_metadatas,
        )

        yield

        # Cleanup after test
        self.vectorstore.delete(ids=self.ids)

    def test_similarity_search_basic(self) -> None:
        """Test basic similarity search."""
        docs = self.vectorstore.similarity_search(
            query="programming language",
            k=2,
        )

        # Verify
        assert len(docs) <= 2
        assert all(hasattr(doc, "page_content") for doc in docs)
        assert all(hasattr(doc, "metadata") for doc in docs)

    def test_similarity_search_with_score(self) -> None:
        """Test similarity search with scores."""
        docs_and_scores = self.vectorstore.similarity_search_with_score(
            query="animal",
            k=3,
        )

        # Verify
        assert len(docs_and_scores) <= 3
        for doc, score in docs_and_scores:
            assert hasattr(doc, "page_content")
            assert isinstance(score, float)
            assert score >= 0  # Distance should be non-negative

    def test_similarity_search_with_filter(self) -> None:
        """Test similarity search with metadata filter."""
        docs = self.vectorstore.similarity_search(
            query="test",
            k=5,
            filter={"source": "integration_test"},
        )

        # Verify - all results should match the filter
        assert len(docs) >= 0
        for doc in docs:
            assert (
                doc.metadata.get("source") == "integration_test"
            ), f"Expected source='integration_test', got '{doc.metadata.get('source')}'"

    def test_similarity_search_by_vector(
        self,
        api_key: str,
        base_url: str,
    ) -> None:
        """Test similarity search by vector.

        Note: This test requires external embeddings since Seahorse Inference API
        is not accessible via table base URL.
        """
        try:
            import os

            from langchain_openai import OpenAIEmbeddings

            openai_key = os.environ.get("OPENAI_API_KEY")
            if not openai_key:
                import pytest

                pytest.skip("OPENAI_API_KEY not set - skipping vector search test")

            # Get embedding for query using external embeddings
            embeddings = OpenAIEmbeddings(api_key=openai_key)
            query_vector = embeddings.embed_query("Python programming")

            # Search by vector
            docs = self.vectorstore.similarity_search_by_vector(
                embedding=query_vector,
                k=2,
            )

            # Verify
            assert len(docs) <= 2
            assert all(hasattr(doc, "page_content") for doc in docs)

        except ImportError:
            import pytest

            pytest.skip("langchain-openai not installed - skipping vector search test")

    def test_similarity_search_with_ef_search(self) -> None:
        """Test similarity search with custom ef_search parameter."""
        docs = self.vectorstore.similarity_search(
            query="artificial intelligence",
            k=2,
            ef_search=100,
        )

        # Verify
        assert len(docs) <= 2
