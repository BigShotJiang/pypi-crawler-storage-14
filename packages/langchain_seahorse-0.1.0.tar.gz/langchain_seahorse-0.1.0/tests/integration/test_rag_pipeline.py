"""Integration tests for RAG pipeline.

Tests complete RAG pipeline using Ollama LLM.
Reference: https://milvus.io/docs/ko/integrate_with_langchain.md#Build-RAG-chain-with-Milvus-Vector-Store

Requires:
- Ollama server running on localhost:11434
- qwen3:8b model installed
- qwen3-embedding:8b model installed (for embedding test)
"""

import pytest

from seahorse_vector_store import SeahorseVectorStore


@pytest.fixture
def ollama_llm_available() -> bool:
    """Check if Ollama LLM is available."""
    try:
        import httpx
        from langchain_ollama import ChatOllama  # noqa: F401

        # Check if Ollama server is running
        try:
            response = httpx.get("http://localhost:11434/api/tags", timeout=2.0)
            if response.status_code != 200:
                return False

            # Check if qwen3:8b model is available
            models = response.json().get("models", [])
            has_qwen3 = any("qwen3:8b" in model.get("name", "") for model in models)
            return has_qwen3
        except Exception:
            return False
    except ImportError:
        return False


@pytest.mark.integration
class TestRAGPipeline:
    """Integration tests for RAG pipeline with Ollama."""

    def test_rag_pipeline_with_ollama(
        self,
        api_key: str,
        base_url: str,
        ollama_llm_available: bool,
    ) -> None:
        """Test complete RAG pipeline with Ollama LLM.

        Reference: https://milvus.io/docs/ko/integrate_with_langchain.md
        """
        if not ollama_llm_available:
            pytest.skip("Ollama qwen3:8b not available on localhost:11434")

        try:
            from langchain.chains import RetrievalQA
            from langchain_ollama import ChatOllama
        except ImportError:
            pytest.skip(
                "Required packages not installed. "
                "Install with: pip install langchain-ollama langchain"
            )

        # Initialize VectorStore
        print("\n🔧 Setting up RAG pipeline with Seahorse VectorStore...")
        vectorstore = SeahorseVectorStore(
            api_key=api_key,
            base_url=base_url,
            use_builtin_embedding=True,
        )

        # Knowledge base (similar to Milvus tutorial)
        knowledge_base = [
            "Seahorse is a high-performance vector database API gateway.",
            "Seahorse supports HNSW indexing for fast similarity search.",
            "Seahorse integrates seamlessly with LangChain framework.",
            "Vector embeddings enable semantic search in Seahorse.",
            "Seahorse provides both built-in and external embedding support.",
        ]

        metadatas = [
            {"source": "seahorse_docs", "topic": "overview"},
            {"source": "seahorse_docs", "topic": "indexing"},
            {"source": "seahorse_docs", "topic": "integration"},
            {"source": "seahorse_docs", "topic": "embeddings"},
            {"source": "seahorse_docs", "topic": "features"},
        ]

        # Add knowledge base
        print("\n📚 Building knowledge base...")
        ids = vectorstore.add_texts(texts=knowledge_base, metadatas=metadatas)
        print(f"✅ Added {len(ids)} documents to knowledge base")

        # Create retriever
        print("\n🔍 Creating retriever...")
        retriever = vectorstore.as_retriever(
            search_type="similarity", search_kwargs={"k": 3}
        )

        # Initialize Ollama LLM
        print("\n🤖 Initializing Ollama LLM (qwen3:8b)...")
        llm = ChatOllama(
            model="qwen3:8b",
            base_url="http://localhost:11434",
            temperature=0,
        )

        # Create QA chain
        print("\n⛓️ Building RetrievalQA chain...")
        qa_chain = RetrievalQA.from_chain_type(
            llm=llm,
            retriever=retriever,
            return_source_documents=True,
        )

        # Test RAG query
        print("\n❓ Testing RAG query...")
        query = "What is Seahorse?"
        result = qa_chain.invoke({"query": query})

        # Verify result structure
        assert "result" in result
        assert "source_documents" in result

        answer = result["result"]
        source_docs = result["source_documents"]

        print(f"\n📄 Query: {query}")
        print(f"🤖 Answer: {answer[:200]}...")
        print(f"\n📚 Source documents: {len(source_docs)}")
        for i, doc in enumerate(source_docs, 1):
            print(f"  {i}. {doc.page_content[:60]}...")
            print(f"     Topic: {doc.metadata['topic']}")

        # Verify answer is not empty
        assert len(answer) > 0
        assert len(source_docs) > 0
        assert len(source_docs) <= 3

        print("\n✅ RAG pipeline working correctly!")

        # Cleanup
        vectorstore.delete(ids=ids)
        print(f"🧹 Cleanup: deleted {len(ids)} documents")

    def test_rag_with_metadata_filter(
        self,
        api_key: str,
        base_url: str,
        ollama_llm_available: bool,
    ) -> None:
        """Test RAG pipeline with metadata filtering."""
        if not ollama_llm_available:
            pytest.skip("Ollama not available")

        try:
            from langchain.chains import RetrievalQA
            from langchain_ollama import ChatOllama
        except ImportError:
            pytest.skip("Required packages not installed")

        vectorstore = SeahorseVectorStore(
            api_key=api_key,
            base_url=base_url,
        )

        # Add documents from different sources
        texts = [
            "Technical documentation for Seahorse API.",
            "User guide for beginners.",
            "Advanced configuration options.",
            "Troubleshooting common issues.",
        ]

        metadatas = [
            {"doc_type": "technical", "audience": "developers"},
            {"doc_type": "guide", "audience": "beginners"},
            {"doc_type": "technical", "audience": "advanced"},
            {"doc_type": "support", "audience": "all"},
        ]

        ids = vectorstore.add_texts(texts=texts, metadatas=metadatas)

        # Create retriever with filter (only technical docs)
        print("\n🔍 Creating filtered retriever (doc_type=technical)...")
        retriever = vectorstore.as_retriever(
            search_kwargs={"k": 5, "filter": {"doc_type": "technical"}}
        )

        # Initialize LLM
        llm = ChatOllama(
            model="qwen3:8b",
            base_url="http://localhost:11434",
            temperature=0,
        )

        # Create QA chain
        qa_chain = RetrievalQA.from_chain_type(
            llm=llm,
            retriever=retriever,
            return_source_documents=True,
        )

        # Query
        result = qa_chain.invoke({"query": "Tell me about the API"})

        # Verify all source documents are technical
        source_docs = result["source_documents"]
        for doc in source_docs:
            assert doc.metadata["doc_type"] == "technical"

        print(f"\n✅ All {len(source_docs)} source documents are 'technical' type")
        print(f"🤖 Answer: {result['result'][:150]}...")

        # Cleanup
        vectorstore.delete(ids=ids)

    @pytest.mark.asyncio
    async def test_retriever_compatibility_with_async(
        self,
        api_key: str,
        base_url: str,
    ) -> None:
        """Test that retriever is compatible with async vectorstore operations."""
        vectorstore = SeahorseVectorStore(
            api_key=api_key,
            base_url=base_url,
        )

        # Add documents asynchronously
        texts = [
            "Async document about machine learning",
            "Async document about deep learning",
            "Async document about neural networks",
        ]
        metadatas = [{"async": True, "id": i} for i in range(3)]

        ids = await vectorstore.aadd_texts(texts=texts, metadatas=metadatas)

        # Create retriever (sync interface)
        retriever = vectorstore.as_retriever(search_kwargs={"k": 2})

        # Use retriever (sync) after async add
        docs = retriever.invoke("machine learning")

        assert len(docs) <= 2
        print(f"\n✅ Retriever works with async-added documents: {len(docs)} results")

        # Cleanup asynchronously
        await vectorstore.adelete(ids=ids)

    def test_retriever_search_type_similarity(
        self,
        api_key: str,
        base_url: str,
    ) -> None:
        """Test retriever with similarity search type."""
        vectorstore = SeahorseVectorStore(
            api_key=api_key,
            base_url=base_url,
        )

        texts = ["Document A", "Document B", "Document C"]
        ids = vectorstore.add_texts(texts=texts)

        # Test different search types
        print("\n🔍 Testing search_type='similarity'...")
        retriever_sim = vectorstore.as_retriever(
            search_type="similarity", search_kwargs={"k": 2}
        )

        docs = retriever_sim.invoke("document")
        assert len(docs) <= 2
        print(f"✅ Similarity retriever: {len(docs)} documents")

        # Cleanup
        vectorstore.delete(ids=ids)

    def test_retriever_with_score_threshold(
        self,
        api_key: str,
        base_url: str,
    ) -> None:
        """Test retriever with similarity_score_threshold search type."""
        vectorstore = SeahorseVectorStore(
            api_key=api_key,
            base_url=base_url,
        )

        texts = [
            "Exact match document for testing",
            "Similar document about testing",
            "Completely unrelated content",
        ]

        ids = vectorstore.add_texts(texts=texts)

        # Create retriever with score threshold
        # Note: Seahorse uses distance (lower is better), not similarity score
        print("\n🔍 Testing with search parameters...")
        retriever = vectorstore.as_retriever(
            search_kwargs={
                "k": 3,
                "ef_search": 100,  # Higher accuracy
            }
        )

        docs = retriever.invoke("testing documents")
        assert len(docs) <= 3
        print(f"✅ Retrieved {len(docs)} documents with custom search params")

        # Cleanup
        vectorstore.delete(ids=ids)
