"""Pytest configuration for integration tests."""

import os
from pathlib import Path

import pytest

try:
    from dotenv import load_dotenv

    # Load .env file from project root
    env_path = Path(__file__).parent.parent.parent / ".env"
    if env_path.exists():
        load_dotenv(env_path)
except ImportError:
    # python-dotenv not installed, skip loading .env file
    pass


def pytest_configure(config: pytest.Config) -> None:
    """Configure pytest for integration tests."""
    config.addinivalue_line(
        "markers",
        "integration: marks tests as integration tests (deselect with '-m \"not integration\"')",
    )


@pytest.fixture
def api_key() -> str:
    """Get API key from .env file or environment variable.

    Priority:
        1. Environment variable SEAHORSE_API_KEY
        2. .env file in project root

    Raises:
        pytest.skip: If API key is not set
    """
    key = os.environ.get("SEAHORSE_API_KEY")
    if not key:
        pytest.skip("SEAHORSE_API_KEY not set in .env file or environment variables")
    return key


@pytest.fixture
def base_url() -> str:
    """Get base URL from .env file or environment variable.

    Priority:
        1. Environment variable SEAHORSE_BASE_URL
        2. .env file in project root

    Raises:
        pytest.skip: If base URL is not set
    """
    url = os.environ.get("SEAHORSE_BASE_URL")
    if not url:
        pytest.skip("SEAHORSE_BASE_URL not set in .env file or environment variables")
    return url


@pytest.fixture
def integration_texts() -> list:
    """Sample texts for integration testing."""
    return [
        "The quick brown fox jumps over the lazy dog.",
        "Python is a high-level programming language.",
        "Machine learning is a subset of artificial intelligence.",
    ]


@pytest.fixture
def integration_metadatas() -> list:
    """Sample metadatas for integration testing."""
    return [
        {"source": "integration_test", "test_id": "1"},
        {"source": "integration_test", "test_id": "2"},
        {"source": "integration_test", "test_id": "3"},
    ]
