"""Integration tests for LangChain compatibility.

Tests using the same samples as LangChain Milvus documentation to ensure compatibility.
Reference: https://docs.langchain.com/oss/python/integrations/vectorstores/milvus
"""

import pytest
from langchain_core.documents import Document

from seahorse_vector_store import SeahorseVectorStore


@pytest.mark.integration
class TestLangChainCompatibility:
    """Test compatibility with LangChain standard patterns."""

    def test_milvus_document_samples(
        self,
        api_key: str,
        base_url: str,
    ) -> None:
        """Test using exact same document samples as Milvus documentation.

        Reference: https://docs.langchain.com/oss/python/integrations/vectorstores/milvus#add-items-to-vector-store
        """
        vectorstore = SeahorseVectorStore(
            api_key=api_key,
            base_url=base_url,
        )

        # Use exact same documents as Milvus documentation
        document_1 = Document(
            page_content="I had chocolate chip pancakes and scrambled eggs for breakfast this morning.",
            metadata={"source": "tweet"},
        )

        document_2 = Document(
            page_content="The weather forecast for tomorrow is cloudy and overcast, with a high of 62 degrees.",
            metadata={"source": "news"},
        )

        document_3 = Document(
            page_content="Building an exciting new project with LangChain - come check it out!",
            metadata={"source": "tweet"},
        )

        document_4 = Document(
            page_content="Robbers broke into the city bank and stole $1 million in cash.",
            metadata={"source": "news"},
        )

        document_5 = Document(
            page_content="Wow! That was an amazing movie. I can't wait to see it again.",
            metadata={"source": "tweet"},
        )

        document_6 = Document(
            page_content="Is the new iPhone worth the price? Read this review to find out.",
            metadata={"source": "website"},
        )

        document_7 = Document(
            page_content="The top 10 soccer players in the world right now.",
            metadata={"source": "website"},
        )

        document_8 = Document(
            page_content="LangGraph is the best framework for building stateful, agentic applications!",
            metadata={"source": "tweet"},
        )

        document_9 = Document(
            page_content="The stock market is down 500 points today due to fears of a recession.",
            metadata={"source": "news"},
        )

        document_10 = Document(
            page_content="I have a bad feeling I am going to get deleted :(",
            metadata={"source": "tweet"},
        )

        documents = [
            document_1,
            document_2,
            document_3,
            document_4,
            document_5,
            document_6,
            document_7,
            document_8,
            document_9,
            document_10,
        ]

        # Add documents
        texts = [doc.page_content for doc in documents]
        metadatas = [doc.metadata for doc in documents]

        ids = vectorstore.add_texts(texts=texts, metadatas=metadatas)

        assert len(ids) == 10
        print(f"\n✅ Added {len(ids)} documents")

        # Test similarity search (from Milvus docs)
        # Reference: https://docs.langchain.com/oss/python/integrations/vectorstores/milvus#query-vector-store
        results = vectorstore.similarity_search(
            "What did the author do growing up?", k=3
        )

        assert len(results) <= 3
        assert all(hasattr(doc, "page_content") for doc in results)
        assert all(hasattr(doc, "metadata") for doc in results)
        print(f"\n🔍 Search results: {len(results)} documents found")
        for i, doc in enumerate(results, 1):
            print(f"{i}. {doc.page_content[:60]}... (source: {doc.metadata['source']})")

        # Test similarity search with filter (same as Milvus docs)
        print("\n🔍 Testing filtered search (source=news)...")
        filtered_results = vectorstore.similarity_search(
            "What is the weather like tomorrow?", k=3, filter={"source": "news"}
        )

        print(f"   Found {len(filtered_results)} results:")
        for i, doc in enumerate(filtered_results, 1):
            print(
                f"   {i}. {doc.page_content[:60]}... (source: {doc.metadata['source']})"
            )

        # Verify all results are from "news" source (strict, like Milvus)
        for doc in filtered_results:
            assert (
                doc.metadata["source"] == "news"
            ), f"Filter failed: expected 'news', got '{doc.metadata['source']}'"

        print(
            f"✅ Filter working correctly - all {len(filtered_results)} results are from 'news' source"
        )

        # Test similarity search with score (same as Milvus docs)
        print("\n🔍 Testing search with score and filter...")
        docs_and_scores = vectorstore.similarity_search_with_score(
            "Will it be hot tomorrow?", k=1, filter={"source": "news"}
        )

        assert len(docs_and_scores) <= 1
        if docs_and_scores:
            doc, score = docs_and_scores[0]
            print(f"\n📊 Top result (score={score:.4f}): {doc.page_content[:60]}...")
            print(f"   Source: {doc.metadata.get('source', 'N/A')}")

            # Should be from news source
            assert doc.metadata["source"] == "news"
            print("✅ Score search with filter working correctly")

        # Cleanup
        vectorstore.delete(ids=ids)
        print(f"\n🧹 Cleanup: deleted {len(ids)} documents")
