"""Integration tests for async operations."""

import pytest

from seahorse_vector_store import SeahorseVectorStore


@pytest.mark.integration
@pytest.mark.asyncio
class TestAsyncOperations:
    """Integration tests for async vectorstore operations."""

    async def test_async_add_and_search(
        self,
        api_key: str,
        base_url: str,
        integration_texts: list,
        integration_metadatas: list,
    ) -> None:
        """Test async add texts and search."""
        vectorstore = SeahorseVectorStore(
            api_key=api_key,
            base_url=base_url,
            use_builtin_embedding=True,
        )

        # Add texts asynchronously
        ids = await vectorstore.aadd_texts(
            texts=integration_texts,
            metadatas=integration_metadatas,
        )

        # Verify
        assert len(ids) == len(integration_texts)
        assert all(isinstance(id, str) for id in ids)

        # Search asynchronously
        docs = await vectorstore.asimilarity_search(
            query="programming language",
            k=2,
        )

        # Verify search results
        assert len(docs) <= 2
        assert all(hasattr(doc, "page_content") for doc in docs)

        # Cleanup
        await vectorstore.adelete(ids=ids)

    async def test_async_search_with_score(
        self,
        api_key: str,
        base_url: str,
        integration_texts: list,
        integration_metadatas: list,
    ) -> None:
        """Test async search with scores."""
        vectorstore = SeahorseVectorStore(
            api_key=api_key,
            base_url=base_url,
        )

        # Add texts
        ids = await vectorstore.aadd_texts(
            texts=integration_texts,
            metadatas=integration_metadatas,
        )

        # Search with scores
        docs_and_scores = await vectorstore.asimilarity_search_with_score(
            query="machine learning",
            k=3,
        )

        # Verify
        assert len(docs_and_scores) <= 3
        for doc, score in docs_and_scores:
            assert hasattr(doc, "page_content")
            assert isinstance(score, float)
            assert score >= 0  # Distance should be non-negative

        # Cleanup
        await vectorstore.adelete(ids=ids)

    async def test_async_search_with_filter(
        self,
        api_key: str,
        base_url: str,
        integration_texts: list,
        integration_metadatas: list,
    ) -> None:
        """Test async search with metadata filter."""
        vectorstore = SeahorseVectorStore(
            api_key=api_key,
            base_url=base_url,
        )

        # Add texts
        ids = await vectorstore.aadd_texts(
            texts=integration_texts,
            metadatas=integration_metadatas,
        )

        # Search with filter
        docs = await vectorstore.asimilarity_search(
            query="test",
            k=5,
            filter={"source": "integration_test"},
        )

        # Verify
        assert len(docs) >= 0
        for doc in docs:
            assert doc.metadata.get("source") == "integration_test"

        # Cleanup
        await vectorstore.adelete(ids=ids)

    async def test_async_delete(
        self,
        api_key: str,
        base_url: str,
    ) -> None:
        """Test async delete operation."""
        vectorstore = SeahorseVectorStore(
            api_key=api_key,
            base_url=base_url,
        )

        # Add a test document
        ids = await vectorstore.aadd_texts(
            texts=["Test document for deletion"],
            metadatas=[{"test": "delete"}],
        )

        # Delete
        result = await vectorstore.adelete(ids=ids)

        # Verify
        assert result is True
