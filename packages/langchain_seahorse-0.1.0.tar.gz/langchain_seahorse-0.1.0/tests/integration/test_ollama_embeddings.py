"""Integration tests for Ollama embeddings.

Tests using Ollama embeddings running locally.
Requires: Ollama server running on localhost:11434 with qwen3-embedding:8b model
"""

import pytest

from seahorse_vector_store import SeahorseVectorStore


@pytest.fixture
def ollama_available() -> bool:
    """Check if Ollama is available."""
    try:
        import httpx

        # Check if langchain-ollama is installed
        try:
            import langchain_ollama  # noqa: F401
        except ImportError:
            return False

        # Check if Ollama server is running
        try:
            response = httpx.get("http://localhost:11434/api/tags", timeout=2.0)
            return response.status_code == 200
        except Exception:
            return False
    except ImportError:
        return False


@pytest.mark.integration
class TestOllamaEmbeddings:
    """Integration tests for Ollama embeddings."""

    def test_ollama_embeddings_integration(
        self,
        api_key: str,
        base_url: str,
        ollama_available: bool,
    ) -> None:
        """Test VectorStore with Ollama embeddings.

        Using qwen3-embedding:8b model running on localhost:11434
        """
        if not ollama_available:
            pytest.skip("Ollama not available on localhost:11434")

        try:
            from langchain_ollama import OllamaEmbeddings
        except ImportError:
            pytest.skip(
                "langchain-ollama not installed. Install with: pip install langchain-ollama"
            )

        # Initialize Ollama embeddings
        print("\n🔧 Initializing Ollama embeddings (qwen3-embedding:8b)...")
        embeddings = OllamaEmbeddings(
            model="qwen3-embedding:8b",
            base_url="http://localhost:11434",
        )

        # Test embedding dimension
        test_vector = embeddings.embed_query("test")
        print(f"📏 Ollama embedding dimension: {len(test_vector)}")

        # Note: Seahorse default table uses 1024 dimensions
        # qwen3-embedding:8b may have different dimensions
        # This test will fail if dimensions don't match
        expected_dim = 1024  # Seahorse default

        if len(test_vector) != expected_dim:
            pytest.skip(
                f"Ollama qwen3-embedding:8b dimension ({len(test_vector)}) "
                f"doesn't match Seahorse table dimension ({expected_dim}). "
                f"Create a table with matching dimensions to run this test."
            )

        # Initialize vectorstore with Ollama embeddings
        vectorstore = SeahorseVectorStore(
            api_key=api_key,
            base_url=base_url,
            embedding=embeddings,
            use_builtin_embedding=False,
        )

        # Test documents
        texts = [
            "Ollama is a tool for running large language models locally.",
            "Qwen is a series of large language models by Alibaba.",
            "Vector embeddings enable semantic search capabilities.",
        ]

        metadatas = [
            {"source": "ollama_docs", "topic": "ollama"},
            {"source": "qwen_docs", "topic": "qwen"},
            {"source": "ml_docs", "topic": "embeddings"},
        ]

        # Add texts with Ollama embeddings
        print("\n📝 Adding texts with Ollama embeddings...")
        ids = vectorstore.add_texts(texts=texts, metadatas=metadatas)

        assert len(ids) == 3
        print(f"✅ Successfully added {len(ids)} documents with Ollama embeddings")

        # Search
        print("\n🔍 Searching with Ollama-embedded query...")
        docs = vectorstore.similarity_search("What is Ollama used for?", k=2)

        assert len(docs) <= 2
        print(f"✅ Found {len(docs)} relevant documents")
        for i, doc in enumerate(docs, 1):
            print(f"  {i}. {doc.page_content[:60]}...")
            print(f"     Source: {doc.metadata['source']}")

        # Search with filter
        print("\n🔍 Searching with metadata filter...")
        filtered_docs = vectorstore.similarity_search(
            "embeddings", k=5, filter={"topic": "embeddings"}
        )

        for doc in filtered_docs:
            assert doc.metadata.get("topic") == "embeddings"
        print(f"✅ Filtered search returned {len(filtered_docs)} documents")

        # Cleanup
        vectorstore.delete(ids=ids)
        print(f"\n🧹 Cleanup: deleted {len(ids)} documents")

    @pytest.mark.asyncio
    async def test_ollama_embeddings_async(
        self,
        api_key: str,
        base_url: str,
        ollama_available: bool,
    ) -> None:
        """Test async operations with Ollama embeddings."""
        if not ollama_available:
            pytest.skip("Ollama not available")

        try:
            from langchain_ollama import OllamaEmbeddings
        except ImportError:
            pytest.skip("langchain-ollama not installed")

        embeddings = OllamaEmbeddings(
            model="qwen3-embedding:8b",
            base_url="http://localhost:11434",
        )

        # Check dimension compatibility
        test_vector = embeddings.embed_query("test")
        if len(test_vector) != 1024:
            pytest.skip(f"Dimension mismatch: {len(test_vector)} != 1024")

        vectorstore = SeahorseVectorStore(
            api_key=api_key,
            base_url=base_url,
            embedding=embeddings,
            use_builtin_embedding=False,
        )

        # Async add
        texts = ["Async test with Ollama embeddings"]
        metadatas = [{"test": "async_ollama"}]

        ids = await vectorstore.aadd_texts(texts=texts, metadatas=metadatas)

        assert len(ids) == 1
        print(f"\n✅ Async add with Ollama: {len(ids)} documents")

        # Async search
        docs = await vectorstore.asimilarity_search("ollama test", k=1)

        assert len(docs) <= 1
        print(f"✅ Async search with Ollama: {len(docs)} results")

        # Cleanup
        await vectorstore.adelete(ids=ids)
