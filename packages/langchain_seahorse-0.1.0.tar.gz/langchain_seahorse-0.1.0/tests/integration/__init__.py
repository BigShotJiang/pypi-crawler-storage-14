"""Integration tests for Seahorse Vector Store."""
