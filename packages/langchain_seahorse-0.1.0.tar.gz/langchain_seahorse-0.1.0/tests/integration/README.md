# Integration Tests

## 개요

Integration tests는 실제 Seahorse API를 호출하여 전체 시스템이 올바르게 작동하는지 검증합니다.

## 실행 방법

### 1. 환경 설정

`.env` 파일을 생성하고 Seahorse credentials를 설정하세요:

```bash
cp .env.example .env
```

`.env` 파일 내용:
```bash
SEAHORSE_API_KEY=your-api-key
SEAHORSE_BASE_URL=https://your-table-uuid.api.seahorse.dnotitia.ai
```

### 2. 기본 Integration Tests 실행

```bash
# 모든 integration tests
uv run pytest tests/integration/ -v

# 특정 테스트만 실행
uv run pytest tests/integration/test_add_texts.py -v
```

### 3. Ollama Tests 실행 (선택)

Ollama를 사용하는 테스트는 추가 설정이 필요합니다:

#### 사전 요구사항

1. **Ollama 설치 및 실행**
   ```bash
   # Ollama 설치 (macOS)
   brew install ollama
   
   # Ollama 서버 실행
   ollama serve
   ```

2. **모델 다운로드**
   ```bash
   # 임베딩 모델
   ollama pull qwen3-embedding:8b
   
   # LLM 모델 (RAG 테스트용)
   ollama pull qwen3:8b
   ```

3. **Python 패키지 설치**
   ```bash
   # Python 3.9+ 필요
   uv pip install langchain langchain-ollama
   ```

#### Ollama Tests 실행

```bash
# Ollama 임베딩 테스트
uv run pytest tests/integration/test_ollama_embeddings.py -v

# RAG 파이프라인 테스트
uv run pytest tests/integration/test_rag_pipeline.py -v
```

**참고**: Ollama 테스트는 다음 조건이 충족되지 않으면 자동으로 skip됩니다:
- Ollama 서버가 localhost:11434에서 실행 중
- 필요한 모델이 설치됨
- langchain, langchain-ollama 패키지 설치됨
- Python 3.9+ 환경

---

## 테스트 파일 설명

### 기본 Tests

#### `test_add_texts.py`
- 텍스트 추가 기능
- 메타데이터와 함께 추가
- `from_texts()` 클래스 메서드

#### `test_search.py`
- 기본 유사도 검색
- 점수와 함께 검색
- 메타데이터 필터 검색
- 벡터로 직접 검색

#### `test_delete.py`
- ID로 삭제
- 부분 삭제
- 빈 리스트 처리

#### `test_async_operations.py`
- 비동기 추가 및 검색
- 비동기 점수 검색
- 비동기 필터 검색
- 비동기 삭제

### LangChain 호환성 Tests

#### `test_langchain_compatibility.py`
- Milvus 문서와 동일한 샘플 사용
- LangChain 표준 패턴 검증
- 검색 결과 일관성 확인

Reference: [LangChain Milvus Integration](https://docs.langchain.com/oss/python/integrations/vectorstores/milvus)

#### `test_retriever.py`
- `as_retriever()` 기본 동작
- 메타데이터 필터와 retriever
- 커스텀 search_kwargs
- Async와 retriever 호환성

### Ollama Integration Tests (Optional)

#### `test_ollama_embeddings.py`
- Ollama 임베딩 사용 (qwen3-embedding:8b)
- 외부 임베딩으로 문서 추가
- 외부 임베딩으로 검색
- 비동기 Ollama 작업

**요구사항**:
- Ollama 서버: localhost:11434
- 모델: qwen3-embedding:8b

#### `test_rag_pipeline.py`
- 완전한 RAG 파이프라인
- Ollama LLM 사용 (qwen3:8b)
- RetrievalQA chain
- 메타데이터 필터와 RAG

Reference: [Milvus RAG Tutorial](https://milvus.io/docs/ko/integrate_with_langchain.md#Build-RAG-chain-with-Milvus-Vector-Store)

**요구사항**:
- Ollama 서버: localhost:11434
- LLM 모델: qwen3:8b
- 임베딩 모델: qwen3-embedding:8b (테스트에 따라)

---

## 테스트 마커

### `@pytest.mark.integration`
모든 integration tests에 적용됩니다.

### Skip 조건
- `SEAHORSE_API_KEY` 미설정 → 모든 tests skip
- `SEAHORSE_BASE_URL` 미설정 → 모든 tests skip
- Ollama 미실행 → Ollama tests만 skip
- 필요 패키지 미설치 → 해당 tests만 skip

---

## 실행 옵션

### 기본 테스트만 실행 (Ollama 제외)

```bash
uv run pytest tests/integration/ -v \
  --ignore=tests/integration/test_ollama_embeddings.py \
  --ignore=tests/integration/test_rag_pipeline.py
```

### 모든 테스트 실행 (Ollama 포함)

```bash
# Ollama가 실행 중이고 모델이 설치되어 있어야 함
uv run pytest tests/integration/ -v
```

### 특정 테스트만 실행

```bash
# LangChain 호환성만
uv run pytest tests/integration/test_langchain_compatibility.py -v

# Retriever만
uv run pytest tests/integration/test_retriever.py -v

# Ollama 임베딩만
uv run pytest tests/integration/test_ollama_embeddings.py -v

# RAG 파이프라인만
uv run pytest tests/integration/test_rag_pipeline.py -v
```

### Verbose 출력

```bash
uv run pytest tests/integration/ -v -s
# -s: print 문 출력 표시
```

---

## 트러블슈팅

### "SEAHORSE_API_KEY not set"

`.env` 파일을 생성하고 API credentials를 설정하세요.

### "Ollama not available"

```bash
# Ollama 서버 실행 확인
curl http://localhost:11434/api/tags

# 모델 확인
ollama list

# 모델 다운로드
ollama pull qwen3-embedding:8b
ollama pull qwen3:8b
```

### "langchain-ollama not installed"

```bash
# Python 3.9+ 환경에서
uv pip install langchain langchain-ollama
```

### "Dimension mismatch"

Ollama 임베딩 모델의 차원이 Seahorse 테이블과 일치하지 않으면 skip됩니다.
테이블을 해당 차원으로 재생성하거나, 다른 임베딩 모델을 사용하세요.

---

## 성능 고려사항

- Integration tests는 실제 API를 호출하므로 시간이 걸립니다
- 각 테스트는 cleanup을 수행하여 테스트 데이터를 삭제합니다
- Ollama tests는 로컬 모델을 사용하므로 네트워크 대기 시간이 없습니다

---

**마지막 업데이트**: 2025-11-21

