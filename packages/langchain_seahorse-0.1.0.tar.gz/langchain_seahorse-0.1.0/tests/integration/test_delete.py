"""Integration tests for delete functionality."""

import pytest

from seahorse_vector_store import SeahorseVectorStore


@pytest.mark.integration
class TestDelete:
    """Integration tests for deleting data from Seahorse."""

    def test_delete_by_ids(
        self,
        api_key: str,
        base_url: str,
        integration_texts: list,
        integration_metadatas: list,
    ) -> None:
        """Test deleting documents by IDs."""
        vectorstore = SeahorseVectorStore(
            api_key=api_key,
            base_url=base_url,
        )

        # Add texts
        ids = vectorstore.add_texts(
            texts=integration_texts,
            metadatas=integration_metadatas,
        )

        # Delete
        result = vectorstore.delete(ids=ids)

        # Verify
        assert result is True

    def test_delete_partial(
        self,
        api_key: str,
        base_url: str,
        integration_texts: list,
        integration_metadatas: list,
    ) -> None:
        """Test deleting subset of documents."""
        vectorstore = SeahorseVectorStore(
            api_key=api_key,
            base_url=base_url,
        )

        # Add texts
        ids = vectorstore.add_texts(
            texts=integration_texts,
            metadatas=integration_metadatas,
        )

        # Delete only first document
        result = vectorstore.delete(ids=[ids[0]])
        assert result is True

        # Cleanup remaining documents
        vectorstore.delete(ids=ids[1:])

    def test_delete_empty_list(
        self,
        api_key: str,
        base_url: str,
    ) -> None:
        """Test deleting with empty ID list."""
        vectorstore = SeahorseVectorStore(
            api_key=api_key,
            base_url=base_url,
        )

        # Delete empty list
        result = vectorstore.delete(ids=[])

        # Should return None
        assert result is None
