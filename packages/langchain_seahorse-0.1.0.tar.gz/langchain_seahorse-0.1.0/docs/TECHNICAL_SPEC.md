# LangChain VectorStore SDK - 기술 명세서

## 1. 프로젝트 개요

### 목적
Seahorse API Gateway를 LangChain의 VectorStore 인터페이스로 통합하여 Python 개발자들이 쉽게 사용할 수 있도록 SDK 제공

### 목표
- LangChain VectorStore 인터페이스 완전 구현
- Python 3.8+ 지원
- 동기/비동기 API 모두 지원
- PyPI 배포 (`langchain-seahorse`)

### 프로젝트 범위
- **Phase 1 (MVP)**: 기본 VectorStore 기능 (4주)
- **Phase 2 (Full)**: 전체 LangChain 표준 구현 (4주)
- **Phase 3 (Advanced)**: Seahorse 특화 기능 (2주)

---

## 2. API 엔드포인트 명세

### 2.1 Base URL

**확인 완료:**
- Production Base URL: `https://{table-uuid}.api.seahorse.dnotitia.ai`
  - 각 테이블마다 고유 UUID 자동 할당
  - 예시: `https://bb1974015e734908ac3fe77a7dc57083.api.seahorse.dnotitia.ai`
  - 테이블 생성 시 자동으로 생성됨
- Development 환경: `https://{table-uuid}.api.seahorse.dnotitia.com`

### 2.2 사용할 주요 엔드포인트

#### A. 데이터 삽입 (임베딩 포함)

**POST /v1/data/embedding**

```python
# Request
{
  "data": [
    {
      "id": "doc1_hash\u001e0",
      "text": "문서 내용",
      "metadata": "JSON 문자열"
    }
  ],
  "embedding_source": "text",
  "embedding_target": "embedding"
}

# Response (CoralResponse 래퍼)
{
  "success": true,
  "code": 200,
  "data": {
    "inserted_row_count": 1,
    "inserted_record_batches": 1,
    "elapsed_time": 1.0
  },
  "exception": null
}
```

**중요 사항:**
- `data` 배열에 여러 문서 전송 가능
- ~~⚠️ 최대 배열 크기 확인 필요~~ : 명시적인 배열 크기 제한은 없음
- 내부적으로 Inference API를 호출하여 임베딩 생성
- embedding_target 컬럼은 반드시 벡터 컬럼이어야 함

#### B. 시맨틱 검색

**POST /v1/data/semantic-search**

```python
# Request
{
  "query": "검색할 텍스트",
  "index_name": "embedding",
  "top_k": 5,
  "ef_search": 100,
  "projection": "text, metadata, distance"
}

# Response
{
  "success": true,
  "code": 200,
  "data": {
    "num_resultsets": 1,
    "schema": {...},
    "data": [
      [
        {
          "text": "문서 내용",
          "metadata": "{\"source\": \"doc.pdf\"}",
          "distance": 0.58199745
        }
      ]
    ]
  }
}
```

**중요 사항:**
- 응답의 `data` 필드는 이중 배열 (resultset들의 배열)
- 시맨틱 검색은 보통 1개의 resultset 반환
- `distance` 필드: 작을수록 더 유사 (0에 가까울수록 유사)
- **ef_search 최대값 확인 필요**: 명시적인 제한은 없지만 500으로 설정

#### C. 벡터 검색 (직접 벡터로 검색)

**POST /v1/data/indexes/{index_name}/vector-search**

```python
# Request
{
  "query_vectors": {
    "dense": [[0.1, 0.2, ..., 0.n]]
  },
  "top_k": 5,
  "ef_search": 100,
  "projection": "id, text, metadata, distance",
  "filter": "id = '100'"  # SQL WHERE 절
}

# Response
{
  "success": true,
  "code": 200,
  "data": {
    "num_resultsets": 1,  # query_vectors 개수만큼
    "schema": {...},
    "data": [[...]]
  }
}
```

**중요 사항:**
- 쿼리 벡터 차원은 테이블 스키마의 embedding 컬럼 차원과 일치해야 함
- 여러 벡터 동시 검색 가능 (query_vectors.dense에 여러 벡터)
- filter는 SQL WHERE 절 문법

#### D. 데이터 삭제

**POST /v1/data/delete**

```python
# Request
{
  "delete_condition": "id = 'doc1_hash\u001e0'"
}

# Response
{
  "success": true,
  "code": 200,
  "data": {
    "deleted_row_count": 1
  }
}
```

**중요 사항:**
- delete_condition은 SQL WHERE 절
- 미제공 시 전체 삭제되므로 주의
- IN 절로 여러 ID 동시 삭제 가능

#### E. 테이블 스키마 조회

**GET /v1/data/schema**

```python
# Response
{
  "success": true,
  "code": 200,
  "data": {
    "table_name": "my_table",
    "schema": {
      "fields": [
        {"name": "id", "data_type": "LargeUtf8", "nullable": false},
        {"name": "text", "data_type": "LargeUtf8", "nullable": false},
        {"name": "metadata", "data_type": "LargeUtf8", "nullable": false},
        {
          "name": "embedding",
          "data_type": {
            "FixedSizeList": [
              {"data_type": "Float32", "name": "item"},
              1024  # 벡터 차원
            ]
          },
          "nullable": false
        }
      ],
      "metadata": {
        "index_info": "[{\"column_id\":\"3\",\"index_type\":\"hnsw\",...}]"
      }
    }
  }
}
```

---

## 3. 응답 포맷 처리

### 3.1 CoralResponse 래퍼

대부분의 TABLE API는 CoralResponse로 래핑되어 있음:

```python
{
  "success": bool,      # 성공 여부
  "code": int,          # HTTP 상태 코드
  "data": object,       # 실제 응답 데이터
  "exception": object   # 에러 정보 (실패 시)
}
```

**구현 요구사항:**
- 성공 시: `data` 필드 추출하여 반환
- 실패 시: `exception` 필드에서 `error_code`와 `error_message` 추출
- HTTP 상태 코드와 `success` 필드 모두 확인

### 3.2 예외 케이스

**CoralResponse를 사용하지 않는 API:**
1. **Inference API** (`/v1/inference/*`)
   - OpenAI 호환 포맷으로 직접 응답
   - 래퍼 없이 바로 파싱

2. **Storage API의 바이너리 응답** (`GET /v1/storage/object`)
   - 파일 바이너리 직접 반환

---

## 4. 데이터 모델 매핑

### 4.1 LangChain Document → Seahorse Table

| LangChain 필드 | Seahorse 컬럼 | 타입 | 변환 로직 |
|---------------|--------------|------|----------|
| page_content | text | LargeUtf8 | 그대로 매핑 |
| metadata (dict) | metadata | LargeUtf8 | JSON 직렬화 (json.dumps) |
| (자동생성) | id/pk | LargeUtf8 | 아래 PK 생성 규칙 참고 |
| (자동생성) | embedding | FixedSizeList<Float32> | Inference API로 생성 |

### 4.2 Primary Key 생성 규칙

**포맷:**
```
{Document ID}{ASCII 30}{Chunk ID}
```

**상세:**
- **Document ID**: 중복 탐지용 해시값 (권장 길이: 128자)
  - 예: SHA-512 해시 또는 UUID
- **구분자**: ASCII 30 문자 (`\u001E` 또는 `\x1E`)
- **Chunk ID**: 0부터 시작하는 4바이트 부호 없는 정수 (최대: 2^32-1)

**Python 구현 예시:**
```python
import hashlib

def generate_pk(content: str, chunk_id: int = 0) -> str:
    """Primary Key 생성"""
    # Document ID: SHA-512 해시
    doc_id = hashlib.sha512(content.encode()).hexdigest()
    
    # 포맷: {doc_id}\x1e{chunk_id}
    return f"{doc_id}\x1e{chunk_id}"

# 예시
pk = generate_pk("문서 내용", 0)
# 결과: "abc123...xyz\x1e0"
```

**중요 사항:**
- 각 chunk의 PK는 **반드시 유일**해야 함
- 같은 문서의 여러 청크는 chunk_id만 증가
- LangChain에서는 보통 단일 Document = 단일 청크 (chunk_id = 0)

### 4.3 메타데이터 처리

**저장 시:**
```python
# LangChain metadata (dict)
metadata = {
    "source": "document.pdf",
    "page": 1,
    "author": "John"
}

# Seahorse metadata (JSON string)
metadata_str = json.dumps(metadata, ensure_ascii=False)
# '{"source": "document.pdf", "page": 1, "author": "John"}'
```

**조회 시:**
```python
# Seahorse에서 받은 JSON string
metadata_str = '{"source": "document.pdf", "page": 1}'

# LangChain metadata (dict)로 복원
metadata = json.loads(metadata_str)
```

**개발자 확인 내용**
- metadata 컬럼은 단순 String(LargeUtf8)임, Json 포맷의 string으로 저장해야함
- JSON 쿼리 지원 안됨

---

## 5. 메타데이터 필터링

### 5.1 LangChain 필터 → SQL WHERE 절 변환

LangChain의 dict 필터를 Seahorse SQL WHERE 절로 변환해야 함.

**기본 변환 규칙:**

```python
# LangChain 필터
filter = {
    "source": "doc.pdf",
    "page": 1
}
```

**지원가능한 연산자:**

| LangChain | SQL | 예시 |
|-----------|-----|------|
| `{"key": "value"}` | `= 'value'` | 기본 동등 |
| `{"key": {"$eq": "value"}}` | `= 'value'` | 명시적 동등 |

**개발자 확인 내용:**
1. metadata 컬럼의 실제 타입: String
2. JSONB 연산자 지원 불가능
3. 중첩 JSON 쿼리 지원 불가능: Flat한 JSON만 지원
4. 현재는 LIKE 패턴으로 equal 연산만 지원 가능함

**String 타입일 경우 대안:**
```python
# metadata가 String 타입이면 JSON 파싱 불가
# 전체 문자열 LIKE 패턴으로 검색
where_clause = "metadata LIKE '%\"source\": \"doc.pdf\"%'"
```

---

## 6. Embedding 처리 전략

### 6.1 ⚠️ 중요: Inference API 사용 불가

**Seahorse Inference API (`/v1/inference/*`)는 테이블 base_url로 호출할 수 없습니다.**

따라서:
- ✅ `/v1/data/embedding` 사용 (Seahorse 내장 임베딩)
- ✅ 외부 임베딩 사용 (OpenAI, Cohere 등)
- ❌ `/v1/inference/embedding` 직접 호출 불가

### 6.2 권장: Seahorse 내장 임베딩 사용

**장점:**
- `/v1/data/embedding` 엔드포인트가 텍스트 + 임베딩을 한 번에 처리
- 네트워크 왕복 감소
- 벡터 차원 불일치 문제 없음

**단점:**
- Seahorse의 특정 모델만 사용 가능
- LangChain의 다양한 Embedding 제공자 활용 불가

### 6.3 대안: 외부 LangChain Embeddings 지원

**사용 패턴:**
```python
from langchain_openai import OpenAIEmbeddings
from langchain_seahorse import SeahorseVectorStore

# 외부 Embeddings 사용
vectorstore = SeahorseVectorStore(
    api_key="seahorse-key",
    embedding=OpenAIEmbeddings(api_key="openai-key")
)
```

**구현 방법:**
1. 사용자가 제공한 Embeddings로 벡터 생성
2. `/v1/data` 엔드포인트로 JSONL 형식으로 삽입 (임베딩 포함)

**⚠️ 주의사항:**
- 벡터 차원이 테이블 스키마와 일치해야 함
- 차원 불일치 시 명확한 에러 메시지 필요

### 6.4 구현 방식: 하이브리드

```python
class SeahorseVectorStore(VectorStore):
    def __init__(
        self,
        api_key: str,
        base_url: str,
        embedding: Optional[Embeddings] = None,
        use_builtin_embedding: bool = True,
        **kwargs
    ):
        if use_builtin_embedding and embedding is None:
            # Seahorse 내장 임베딩 사용 (/v1/data/embedding)
            self._use_builtin = True
        elif embedding is not None:
            # 외부 Embeddings 사용
            self._use_builtin = False
            self._embedding = embedding
        else:
            raise ValueError("Either use_builtin_embedding or embedding must be provided")
```

### 6.5 벡터 차원 정보

**확인 완료:**
- 기본 모델: `seongil-dn/bge-m3-3800_steps_v2_234`
- **벡터 차원**: 1024 (고정)
- 테이블 스키마에서 확인 가능: `GET /v1/data/schema`

---

## 7. 성능 및 제한사항

### 7.1 배치 처리

**개발자 확인:**
- `/v1/data/embedding`의 `data` 배열 최대 크기는? 제한 없음
- 권장 배치 크기는? 1024
- 메모리 제한은? 명시적 제한은 없음

**임시 권장값 (확인 필요):**
```python
SMALL_BATCH_SIZE = 100   # 이하면 직접 API 호출
MEDIUM_BATCH_SIZE = 1000  # 이하면 여러 번 나눠서 호출
# 이상이면 파일 업로드 + batch-insert 고려
```

### 7.2 Rate Limiting

**⚠️ 확인 필요:**
- 현재 명확한 Rate Limiting 정책 미확인
- 429 에러 발생 시 Retry-After 헤더 확인 필요
- Rate limit 정보 헤더 확인 필요

**구현 시 고려사항:**
```python
# Retry 로직 (서버 에러에 대한 재시도)
RETRYABLE_STATUS_CODES = [408, 429, 500, 502, 503, 504]
MAX_RETRIES = 3
RETRY_DELAY = 1.0  # seconds
BACKOFF_FACTOR = 2.0  # 지수 백오프
```

**권장 사항:**
- 개발 중 429 에러가 발생하면 재시도 로직 테스트
- 프로덕션 환경에서 Rate Limit 정보 수집

### 7.3 데이터 크기 제한

API 명세에서 확인된 제한:
- JSON 페이로드 최대: 20MB
- Multipart Form 최대: 8GB
- **단일 요청의 최대 행 수에 대해 명시적 제한은 없음**

---

## 8. 에러 처리

### 8.1 에러 코드

| 에러 코드 | HTTP Status | 설명 | 재시도 |
|---------|------------|------|-------|
| 400 | 400 | Bad Request | ❌ |
| 400001 | 400 | Bad Request (상세) | ❌ |
| 401 | 401 | Unauthorized | ❌ |
| 403 | 403 | Forbidden | ❌ |
| 404 | 404 | Not Found | ❌ |
| 429 | 429 | Rate Limit | ✅ |
| 500 | 500 | Internal Server Error | ✅ |
| 500001 | 500 | Internal Error | ✅ |
| 502 | 502 | Bad Gateway | ✅ |
| 503 | 503 | Service Unavailable | ✅ |
| 504 | 504 | Gateway Timeout | ✅ |

### 8.2 에러 응답 파싱

```python
# CoralResponse 에러
{
  "success": false,
  "code": 400,
  "data": null,
  "exception": {
    "error_code": 400001,
    "error_message": "Bad Request: Invalid vector dimension"
  }
}

# 파싱 로직
if not response_data.get("success"):
    error_info = response_data.get("exception", {})
    error_code = error_info.get("error_code")
    error_message = error_info.get("error_message")
    raise SeahorseAPIError(error_code, error_message)
```

---

## 9. 테스트 환경

**개발자 확인:**

### 9.1 환경 정보

- **Production Base URL**: `https://455fe13765664952bed80e7c22dd3436.api.seahorse.dnotitia.ai`
- **Development/Local**: `http://9683ea76604642ac8dd8ac05934b05b8.api.seahorse.dnotitia.com`
- 환경 변수는 루트 디렉토리의 `.env` 파일 참고

### 9.2 테스트 계정
- ✅ 테스트용 API Key: `.env` 파일에 설정됨
- ✅ 테스트용 테이블: 생성 완료
  - 스키마: id (LargeUtf8), text (LargeUtf8), metadata (LargeUtf8), embedding (FixedSizeList<Float32, 1024>)
  - 인덱스: HNSW (M=16, ef_construction=128, space=ipspace)
  - active_set_size_limit: 50000
- 테스트 환경의 데이터 보존 정책: 만료 정책 없음, 유지됨
- API Key 발급 방법: https://console.seahorse.dnotitia.ai/main/management/api-keys

### 9.3 테이블 생성
- SDK에서 테이블 자동 생성 가능한가?: 불가능
- 테이블 생성 API 존재하는가?: 없음
- 기본 스키마로 테이블 자동 생성 지원?: 불가능

---

## 10. 요약: 개발 전 필수 확인사항

### 즉시 확인 필요 (High Priority)

1. **Base URL 및 환경**
   - [x] Production Base URL 형식 확인
   - [x] ~~Staging~~ Dev 환경 존재 여부 및 URL
   - [x] 테스트용 API Key 발급 (`.env` 파일에 설정됨)

2. **metadata 컬럼 타입**
   - [x] String인가 JSONB인가? → LargeUtf8 (String)
   - [x] JSON 쿼리 연산자 지원 여부 → 미지원
   - [x] 필터링 가능 범위 → LIKE 패턴만 가능

3. **배치 처리 제한**
   - [x] `/v1/data/embedding` 배열 최대 크기 → 명시적 제한 없음
   - [x] 권장 배치 크기 → 1024
   - [x] `/v1/inference/embedding` 배치 지원 여부 → 미지원

4. **벡터 차원**
   - [x] 기본 임베딩 모델의 벡터 차원 → 1024 (고정)
   - [x] 테이블 생성 시 차원 지정 방법 → 콘솔에서 생성 시 지정

### 개발 중 확인 가능 (Medium Priority)

5. **Rate Limiting**
   - [ ] 제한 정책
   - [ ] Retry-After 헤더 지원
   - [ ] Rate limit 정보 헤더

6. **테이블 관리**
   - [x] 테이블 생성 API 존재 여부 → 없음
   - [x] SDK에서 자동 생성 가능 여부 → 불가능
   - [x] 기본 스키마 구조 → id, text, metadata, embedding (모두 필수)

7. **에러 처리**
   - [ ] 추가 에러 코드
   - [ ] 상세 에러 메시지 포맷

이 정보들이 확정되면 개발을 안전하게 진행할 수 있습니다.

