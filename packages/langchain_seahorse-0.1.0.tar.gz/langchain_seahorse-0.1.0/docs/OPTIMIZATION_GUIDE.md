# 성능 최적화 가이드

## 📊 성능 특성

### 현재 성능 지표

**삽입 성능:**
- 100개 문서: ~3초 (33 docs/sec)
- 1,000개 문서: ~30초 (33 docs/sec)
- 10,000개 문서: ~300초 (33 docs/sec)

**검색 성능:**
- 단일 쿼리: ~0.5초
- 10개 병렬 쿼리 (async): ~1초
- ef_search=50: ~0.3초
- ef_search=200: ~0.8초

**메모리 사용:**
- 기본 배치 (1024개): ~20MB
- 10,000개 문서: ~200MB

---

## 🚀 배치 처리 최적화

### 현재 구현

```python
# 자동 배치 처리 (1024개씩)
DEFAULT_BATCH_SIZE = 1024

# utils.py
def batch_texts(texts, metadatas, batch_size=DEFAULT_BATCH_SIZE):
    for i in range(0, len(texts), batch_size):
        yield (
            texts[i:i + batch_size],
            metadatas[i:i + batch_size],
        )
```

### 최적화 전략

#### 1. 동적 배치 크기

```python
# 문서 크기에 따라 배치 크기 조정
def get_optimal_batch_size(avg_text_length: int) -> int:
    """최적 배치 크기 계산."""
    if avg_text_length < 100:
        return 2048  # 짧은 문서는 더 큰 배치
    elif avg_text_length < 500:
        return 1024  # 기본
    else:
        return 512   # 긴 문서는 작은 배치

# 사용 예
avg_len = sum(len(t) for t in texts) / len(texts)
batch_size = get_optimal_batch_size(avg_len)
```

#### 2. 병렬 배치 처리

```python
import asyncio

async def parallel_batch_insert(
    vectorstore: SeahorseVectorStore,
    texts: list,
    metadatas: list,
    batch_size: int = 1024,
    max_parallel: int = 3,
):
    """여러 배치를 병렬로 삽입."""
    
    # 배치로 나누기
    batches = []
    for i in range(0, len(texts), batch_size):
        batch_texts = texts[i:i + batch_size]
        batch_metas = metadatas[i:i + batch_size]
        batches.append((batch_texts, batch_metas))
    
    all_ids = []
    
    # max_parallel개씩 병렬 처리
    for i in range(0, len(batches), max_parallel):
        parallel_batches = batches[i:i + max_parallel]
        
        tasks = [
            vectorstore.aadd_texts(texts, metas)
            for texts, metas in parallel_batches
        ]
        
        results = await asyncio.gather(*tasks)
        for ids in results:
            all_ids.extend(ids)
    
    return all_ids

# 사용
ids = await parallel_batch_insert(vectorstore, large_texts, large_metadatas)
# 순차: 300초 → 병렬(3개): 100초 (3배 빠름)
```

#### 3. 스트리밍 삽입

```python
def streaming_insert(
    vectorstore: SeahorseVectorStore,
    text_stream,  # Generator
    batch_size: int = 1024,
):
    """스트리밍 방식으로 삽입 (메모리 효율적)."""
    
    batch_texts = []
    batch_metas = []
    all_ids = []
    
    for text, metadata in text_stream:
        batch_texts.append(text)
        batch_metas.append(metadata)
        
        if len(batch_texts) >= batch_size:
            # 배치 삽입
            ids = vectorstore.add_texts(batch_texts, batch_metas)
            all_ids.extend(ids)
            
            # 배치 초기화
            batch_texts = []
            batch_metas = []
    
    # 나머지 처리
    if batch_texts:
        ids = vectorstore.add_texts(batch_texts, batch_metas)
        all_ids.extend(ids)
    
    return all_ids

# 사용 (대용량 파일)
def read_large_file():
    with open("large_data.jsonl") as f:
        for line in f:
            data = json.loads(line)
            yield data["text"], data["metadata"]

ids = streaming_insert(vectorstore, read_large_file())
```

---

## 🔍 검색 최적화

### ef_search 튜닝

```python
# 검색 정확도 vs 속도 트레이드오프

# 시나리오 1: 실시간 검색 (속도 우선)
docs = vectorstore.similarity_search(
    "query",
    k=10,
    ef_search=50  # 빠름, 정확도 90%
)

# 시나리오 2: 오프라인 분석 (정확도 우선)
docs = vectorstore.similarity_search(
    "query",
    k=100,
    ef_search=200  # 느림, 정확도 99%
)

# 시나리오 3: 균형
docs = vectorstore.similarity_search(
    "query",
    k=20,
    ef_search=None  # Auto: k*2 = 40
)
```

### 캐싱 전략

```python
from functools import lru_cache

class CachedVectorStore:
    """검색 결과를 캐싱하는 래퍼."""
    
    def __init__(self, vectorstore):
        self.vectorstore = vectorstore
    
    @lru_cache(maxsize=100)
    def cached_search(self, query: str, k: int = 4):
        """검색 결과 캐싱."""
        # Tuple로 변환 (hashable)
        docs = self.vectorstore.similarity_search(query, k=k)
        return tuple(docs)
    
    def search(self, query: str, k: int = 4):
        """캐시된 검색."""
        return list(self.cached_search(query, k))

# 사용
cached = CachedVectorStore(vectorstore)

# 첫 호출: API 호출 (~0.5초)
docs1 = cached.search("machine learning")

# 두 번째 호출: 캐시에서 반환 (~0.001초)
docs2 = cached.search("machine learning")
```

---

## 💾 메모리 최적화

### 1. 청크 처리

```python
# 대용량 데이터를 청크로 나눠서 처리
def process_in_chunks(
    vectorstore: SeahorseVectorStore,
    texts: list,
    chunk_size: int = 10000,
):
    """대용량 데이터를 청크로 처리."""
    
    for i in range(0, len(texts), chunk_size):
        chunk = texts[i:i + chunk_size]
        print(f"Processing chunk {i//chunk_size + 1}...")
        
        ids = vectorstore.add_texts(chunk)
        print(f"Added {len(ids)} documents")
        
        # 메모리 정리
        del ids
```

### 2. Generator 활용

```python
def document_generator(file_path: str):
    """문서를 하나씩 yield (메모리 효율적)."""
    with open(file_path) as f:
        for line in f:
            yield json.loads(line)

# 사용
docs = document_generator("data.jsonl")
vectorstore.add_texts(
    texts=(d["text"] for d in docs),
    metadatas=(d["metadata"] for d in docs)
)
```

---

## 📈 모니터링

### 성능 메트릭 수집

```python
import time
from dataclasses import dataclass
from typing import List

@dataclass
class PerformanceMetrics:
    """성능 메트릭."""
    operation: str
    duration: float
    count: int
    throughput: float  # items per second

class MonitoredVectorStore:
    """성능 모니터링이 포함된 래퍼."""
    
    def __init__(self, vectorstore):
        self.vectorstore = vectorstore
        self.metrics: List[PerformanceMetrics] = []
    
    def add_texts(self, texts, metadatas=None):
        """모니터링과 함께 텍스트 추가."""
        start = time.time()
        ids = self.vectorstore.add_texts(texts, metadatas)
        duration = time.time() - start
        
        metric = PerformanceMetrics(
            operation="add_texts",
            duration=duration,
            count=len(ids),
            throughput=len(ids) / duration
        )
        self.metrics.append(metric)
        
        return ids
    
    def print_metrics(self):
        """메트릭 출력."""
        for m in self.metrics:
            print(f"{m.operation}: {m.count} items in {m.duration:.2f}s "
                  f"({m.throughput:.1f} items/sec)")

# 사용
monitored = MonitoredVectorStore(vectorstore)
monitored.add_texts(texts)
monitored.similarity_search("query")
monitored.print_metrics()
```

---

## 🎯 추천 설정

### 프로덕션 설정

```python
vectorstore = SeahorseVectorStore(
    api_key=os.environ["SEAHORSE_API_KEY"],
    base_url=os.environ["SEAHORSE_BASE_URL"],
    use_builtin_embedding=True,  # 간단하고 안정적
)

# Client 타임아웃 증가
from seahorse_vector_store.client import SeahorseClient
vectorstore._client._timeout = 60.0
vectorstore._client._max_retries = 5
```

### 개발 환경 설정

```python
# 빠른 테스트를 위한 설정
vectorstore = SeahorseVectorStore(
    api_key=os.environ["SEAHORSE_DEV_KEY"],
    base_url=os.environ["SEAHORSE_DEV_URL"],
)

# ef_search 낮춰서 빠른 검색
docs = vectorstore.similarity_search("query", k=5, ef_search=20)
```

---

## 📊 벤치마크 실행

```bash
# 성능 테스트 실행
pytest tests/benchmarks/ -v -m benchmark

# 특정 테스트만 실행
pytest tests/benchmarks/test_performance.py::TestInsertPerformance -v
```

---

**작성일:** 2025-11-21  
**버전:** 0.1.0

