# 테스트 요구사항

## 1. 테스트 전략

### 1.1 테스트 피라미드

```
       ┌─────────────┐
       │ E2E Tests   │  10%
       │             │
     ┌─┴─────────────┴─┐
     │ Integration     │  30%
     │ Tests           │
   ┌─┴─────────────────┴─┐
   │ Unit Tests          │  60%
   │                     │
   └─────────────────────┘
```

- **Unit Tests (60%)**: 개별 함수/메서드 테스트
- **Integration Tests (30%)**: 실제 API 호출 테스트
- **E2E Tests (10%)**: 전체 워크플로우 테스트

### 1.2 테스트 커버리지 목표

- 전체 코드 커버리지: **80% 이상**
- 핵심 로직 (client.py, vectorstores.py): **90% 이상**
- 유틸리티 (utils.py, filters.py): **85% 이상**

---

## 2. Unit Tests

### 2.1 테스트할 컴포넌트

#### A. filters.py

```python
# tests/unit/test_filters.py
import pytest
from langchain_seahorse.filters import convert_filter_to_sql


class TestFilterConversion:
    """필터 변환 로직 테스트.
    
    ⚠️ 중요: metadata는 String 타입이며 LIKE 패턴만 지원
    현재는 equal 연산만 가능
    """
    
    def test_simple_equality(self):
        """단순 동등 비교 (LIKE 패턴)."""
        filter = {"source": "doc.pdf"}
        result = convert_filter_to_sql(filter)
        assert "LIKE" in result
        assert "source" in result
        assert "doc.pdf" in result
    
    def test_numeric_equality(self):
        """숫자 동등 비교."""
        filter = {"page": 1}
        result = convert_filter_to_sql(filter)
        assert "LIKE" in result
        assert "page" in result
        assert "1" in result
    
    def test_boolean_equality(self):
        """불리언 동등 비교."""
        filter = {"is_published": True}
        result = convert_filter_to_sql(filter)
        assert "LIKE" in result
        assert "is_published" in result
        assert "true" in result.lower()
    
    def test_multiple_conditions(self):
        """여러 조건 조합."""
        filter = {
            "source": "doc.pdf",
            "page": 1
        }
        result = convert_filter_to_sql(filter)
        assert "AND" in result
        assert "source" in result
        assert "page" in result
    
    def test_eq_operator(self):
        """$eq 연산자."""
        filter = {"source": {"$eq": "doc.pdf"}}
        result = convert_filter_to_sql(filter)
        assert "LIKE" in result
        assert "doc.pdf" in result
    
    def test_unsupported_operator(self):
        """지원하지 않는 연산자 ($gt, $lt 등)."""
        # metadata가 String이므로 비교 연산자 미지원
        filter = {"page": {"$gt": 10}}
        with pytest.raises(ValueError) as exc_info:
            convert_filter_to_sql(filter)
        assert "not supported" in str(exc_info.value).lower()
    
    def test_invalid_operator(self):
        """지원하지 않는 연산자."""
        filter = {"field": {"$regex": "pattern"}}
        with pytest.raises(ValueError):
            convert_filter_to_sql(filter)
```

#### B. utils.py

```python
# tests/unit/test_utils.py
import pytest
from langchain_seahorse.utils import batch_texts, generate_pk


class TestUtils:
    """유틸리티 함수 테스트."""
    
    def test_batch_texts_basic(self):
        """기본 배치 분할."""
        texts = ["a", "b", "c", "d", "e"]
        metadatas = [{"i": i} for i in range(5)]
        
        batches = list(batch_texts(texts, metadatas, batch_size=2))
        
        assert len(batches) == 3
        assert len(batches[0][0]) == 2
        assert len(batches[1][0]) == 2
        assert len(batches[2][0]) == 1
    
    def test_batch_texts_exact_size(self):
        """배치 크기 정확히 맞는 경우."""
        texts = ["a", "b", "c", "d"]
        metadatas = [{}] * 4
        
        batches = list(batch_texts(texts, metadatas, batch_size=2))
        
        assert len(batches) == 2
        assert all(len(batch[0]) == 2 for batch in batches)
    
    def test_generate_pk_unique(self):
        """PK 고유성 테스트."""
        pk1 = generate_pk("text1", 0)
        pk2 = generate_pk("text2", 0)
        pk3 = generate_pk("text1", 1)
        
        # 다른 텍스트는 다른 PK
        assert pk1 != pk2
        
        # 같은 텍스트, 다른 chunk_id는 다른 PK
        assert pk1 != pk3
    
    def test_generate_pk_format(self):
        """PK 포맷 검증."""
        pk = generate_pk("test content", 0)
        
        # ASCII 30 구분자 포함
        assert "\x1e" in pk
        
        # chunk_id 포함
        assert pk.endswith("\x1e0")
    
    def test_generate_pk_reproducible(self):
        """같은 입력에 같은 PK 생성."""
        pk1 = generate_pk("same text", 0)
        pk2 = generate_pk("same text", 0)
        
        assert pk1 == pk2
```

#### C. exceptions.py

```python
# tests/unit/test_exceptions.py
import pytest
from langchain_seahorse.exceptions import (
    SeahorseAPIError,
    SeahorseAuthenticationError,
    SeahorseDimensionMismatchError,
)


class TestExceptions:
    """예외 클래스 테스트."""
    
    def test_api_error_message(self):
        """API 에러 메시지."""
        error = SeahorseAPIError(
            status_code=400,
            error_code=400001,
            error_message="Bad Request"
        )
        
        assert error.status_code == 400
        assert error.error_code == 400001
        assert "Bad Request" in str(error)
    
    def test_authentication_error_inheritance(self):
        """인증 에러 상속 관계."""
        error = SeahorseAuthenticationError(
            status_code=401,
            error_message="Unauthorized"
        )
        
        assert isinstance(error, SeahorseAPIError)
    
    def test_dimension_mismatch_error(self):
        """차원 불일치 에러."""
        error = SeahorseDimensionMismatchError(
            expected=1024,
            actual=768
        )
        
        assert error.expected == 1024
        assert error.actual == 768
        assert "1024" in str(error)
        assert "768" in str(error)
```

#### D. client.py (Mock 사용)

```python
# tests/unit/test_client.py
import pytest
from unittest.mock import Mock, patch, MagicMock
import httpx
from langchain_seahorse.client import SeahorseClient
from langchain_seahorse.exceptions import SeahorseAPIError


class TestSeahorseClient:
    """SeahorseClient 테스트."""
    
    @pytest.fixture
    def client(self):
        """클라이언트 인스턴스."""
        return SeahorseClient(
            base_url="http://test.com",
            api_key="test-key"
        )
    
    def test_init(self, client):
        """초기화."""
        assert client._base_url == "http://test.com"
        assert client._api_key == "test-key"
    
    @patch('httpx.Client.request')
    def test_unwrap_coral_response_success(self, mock_request, client):
        """CoralResponse 성공 응답 언래핑."""
        mock_response = Mock()
        mock_response.json.return_value = {
            "success": True,
            "code": 200,
            "data": {"result": "test"},
            "exception": None
        }
        mock_response.status_code = 200
        mock_request.return_value = mock_response
        
        response = client._request("GET", "/test")
        data = client._unwrap_coral_response(response)
        
        assert data == {"result": "test"}
    
    @patch('httpx.Client.request')
    def test_unwrap_coral_response_error(self, mock_request, client):
        """CoralResponse 에러 응답."""
        mock_response = Mock()
        mock_response.json.return_value = {
            "success": False,
            "code": 400,
            "data": None,
            "exception": {
                "error_code": 400001,
                "error_message": "Bad Request"
            }
        }
        mock_response.status_code = 400
        mock_request.return_value = mock_response
        
        with pytest.raises(SeahorseAPIError) as exc_info:
            response = client._request("GET", "/test")
            client._unwrap_coral_response(response)
        
        assert exc_info.value.error_code == 400001
    
    @patch('httpx.Client.request')
    def test_retry_on_500(self, mock_request, client):
        """500 에러 시 재시도."""
        # 첫 두 번 실패, 세 번째 성공
        mock_request.side_effect = [
            httpx.HTTPStatusError("500", request=Mock(), response=Mock(status_code=500)),
            httpx.HTTPStatusError("500", request=Mock(), response=Mock(status_code=500)),
            Mock(status_code=200, json=lambda: {"success": True, "data": {}}),
        ]
        
        response = client._request("GET", "/test")
        
        assert mock_request.call_count == 3
    
    @patch('httpx.Client.request')
    def test_no_retry_on_400(self, mock_request, client):
        """400 에러는 재시도 안 함."""
        mock_response = Mock()
        mock_response.status_code = 400
        mock_request.return_value = mock_response
        
        with pytest.raises(httpx.HTTPStatusError):
            client._request("GET", "/test")
        
        # 한 번만 호출
        assert mock_request.call_count == 1
```

---

## 3. Integration Tests

### 3.1 테스트 환경 설정

```python
# tests/conftest.py
import pytest
import os
from langchain_seahorse import SeahorseVectorStore


@pytest.fixture(scope="session")
def api_key():
    """테스트용 API key."""
    key = os.getenv("TEST_API_KEY")
    if not key:
        pytest.skip("TEST_API_KEY not set")
    return key


@pytest.fixture(scope="session")
def base_url():
    """테스트용 base URL."""
    url = os.getenv("TEST_BASE_URL")
    if not url:
        pytest.skip("TEST_BASE_URL not set")
    return url


@pytest.fixture
def vectorstore(api_key, base_url):
    """VectorStore 인스턴스."""
    return SeahorseVectorStore(
        api_key=api_key,
        base_url=base_url,
    )


@pytest.fixture
def sample_texts():
    """샘플 텍스트."""
    return [
        "Machine learning is a subset of artificial intelligence.",
        "Deep learning uses neural networks with multiple layers.",
        "Natural language processing deals with human language.",
    ]


@pytest.fixture
def sample_metadatas():
    """샘플 메타데이터."""
    return [
        {"source": "ml_basics.pdf", "page": 1, "category": "ML"},
        {"source": "dl_intro.pdf", "page": 5, "category": "DL"},
        {"source": "nlp_guide.pdf", "page": 10, "category": "NLP"},
    ]
```

### 3.2 Integration Test Cases

#### A. 데이터 삽입

```python
# tests/integration/test_add_texts.py
import pytest


class TestAddTexts:
    """add_texts 통합 테스트."""
    
    def test_add_texts_basic(self, vectorstore, sample_texts):
        """기본 텍스트 추가."""
        ids = vectorstore.add_texts(sample_texts)
        
        assert len(ids) == len(sample_texts)
        assert all(isinstance(id, str) for id in ids)
        assert all("\x1e" in id for id in ids)  # PK 포맷 확인
    
    def test_add_texts_with_metadata(self, vectorstore, sample_texts, sample_metadatas):
        """메타데이터와 함께 추가."""
        ids = vectorstore.add_texts(sample_texts, metadatas=sample_metadatas)
        
        assert len(ids) == len(sample_texts)
    
    def test_add_texts_empty(self, vectorstore):
        """빈 리스트 추가."""
        ids = vectorstore.add_texts([])
        
        assert len(ids) == 0
    
    def test_add_texts_large_batch(self, vectorstore):
        """대량 텍스트 추가."""
        texts = [f"Document {i}" for i in range(200)]
        metadatas = [{"index": i} for i in range(200)]
        
        ids = vectorstore.add_texts(texts, metadatas=metadatas)
        
        assert len(ids) == 200
    
    def test_add_texts_with_unicode(self, vectorstore):
        """유니코드 텍스트 추가."""
        texts = [
            "안녕하세요",
            "こんにちは",
            "你好",
            "مرحبا"
        ]
        
        ids = vectorstore.add_texts(texts)
        
        assert len(ids) == 4
```

#### B. 검색

```python
# tests/integration/test_search.py
import pytest


class TestSimilaritySearch:
    """similarity_search 통합 테스트."""
    
    @pytest.fixture(autouse=True)
    def setup(self, vectorstore, sample_texts, sample_metadatas):
        """테스트 데이터 삽입."""
        vectorstore.add_texts(sample_texts, metadatas=sample_metadatas)
        yield
        # Teardown: 삽입한 데이터 삭제
        # (구현 필요)
    
    def test_basic_search(self, vectorstore):
        """기본 검색."""
        docs = vectorstore.similarity_search("neural networks", k=2)
        
        assert len(docs) <= 2
        assert all(hasattr(doc, 'page_content') for doc in docs)
        assert all(hasattr(doc, 'metadata') for doc in docs)
    
    def test_search_with_k(self, vectorstore):
        """k 파라미터 테스트."""
        docs = vectorstore.similarity_search("learning", k=1)
        
        assert len(docs) == 1
    
    def test_search_with_filter(self, vectorstore):
        """필터 적용 검색."""
        docs = vectorstore.similarity_search(
            "learning",
            k=5,
            filter={"category": "ML"}
        )
        
        # 필터가 적용되어야 함
        assert all(doc.metadata.get("category") == "ML" for doc in docs)
    
    def test_search_with_score(self, vectorstore):
        """점수와 함께 검색."""
        docs_and_scores = vectorstore.similarity_search_with_score(
            "deep learning",
            k=2
        )
        
        assert len(docs_and_scores) <= 2
        
        for doc, score in docs_and_scores:
            assert hasattr(doc, 'page_content')
            assert isinstance(score, float)
            assert score >= 0  # distance는 0 이상
    
    def test_search_no_results(self, vectorstore):
        """결과 없는 검색."""
        docs = vectorstore.similarity_search(
            "completely unrelated query xyz123",
            k=5
        )
        
        # 결과가 있을 수도 있지만, 에러는 발생하지 않아야 함
        assert isinstance(docs, list)
```

#### C. 삭제

```python
# tests/integration/test_delete.py
import pytest


class TestDelete:
    """delete 통합 테스트."""
    
    def test_delete_by_ids(self, vectorstore, sample_texts):
        """ID로 삭제."""
        # 삽입
        ids = vectorstore.add_texts(sample_texts)
        
        # 첫 번째만 삭제
        success = vectorstore.delete(ids=[ids[0]])
        
        assert success is True
    
    def test_delete_multiple(self, vectorstore, sample_texts):
        """여러 문서 삭제."""
        ids = vectorstore.add_texts(sample_texts)
        
        # 여러 개 삭제
        success = vectorstore.delete(ids=ids[:2])
        
        assert success is True
    
    def test_delete_nonexistent(self, vectorstore):
        """존재하지 않는 ID 삭제."""
        # 에러가 발생하지 않아야 함
        success = vectorstore.delete(ids=["nonexistent_id\x1e0"])
        
        # False 또는 None 반환 가능
        assert success in [False, None]
```

#### D. 전체 워크플로우

```python
# tests/integration/test_workflow.py
import pytest


class TestFullWorkflow:
    """전체 워크플로우 E2E 테스트."""
    
    def test_add_search_delete(self, vectorstore):
        """추가 → 검색 → 삭제 워크플로우."""
        # 1. 추가
        texts = ["Python programming", "Java programming", "C++ programming"]
        metadatas = [{"lang": "python"}, {"lang": "java"}, {"lang": "cpp"}]
        ids = vectorstore.add_texts(texts, metadatas=metadatas)
        
        assert len(ids) == 3
        
        # 2. 검색
        docs = vectorstore.similarity_search("programming language", k=3)
        
        assert len(docs) >= 1
        assert any("programming" in doc.page_content.lower() for doc in docs)
        
        # 3. 필터링 검색
        docs_filtered = vectorstore.similarity_search(
            "programming",
            k=5,
            filter={"lang": "python"}
        )
        
        assert all(doc.metadata.get("lang") == "python" for doc in docs_filtered)
        
        # 4. 삭제
        success = vectorstore.delete(ids=ids)
        
        assert success is True
    
    def test_as_retriever(self, vectorstore, sample_texts):
        """Retriever로 사용."""
        vectorstore.add_texts(sample_texts)
        
        # Retriever 생성
        retriever = vectorstore.as_retriever(search_kwargs={"k": 2})
        
        # 검색
        docs = retriever.get_relevant_documents("machine learning")
        
        assert len(docs) <= 2
        assert all(hasattr(doc, 'page_content') for doc in docs)
```

---

## 4. 테스트 데이터

### 4.1 샘플 데이터셋

**⚠️ 개발자가 준비 필요:**

#### A. 작은 테스트 데이터셋 (10-100행)

```python
# tests/fixtures/sample_data.py
SMALL_DATASET = [
    {
        "text": "Machine learning is a field of artificial intelligence.",
        "metadata": {"source": "ml_intro.pdf", "page": 1}
    },
    {
        "text": "Deep learning is a subset of machine learning.",
        "metadata": {"source": "dl_basics.pdf", "page": 5}
    },
    # ... 더 많은 샘플
]

KOREAN_DATASET = [
    {
        "text": "인공지능은 인간의 학습능력을 컴퓨터로 구현하는 기술입니다.",
        "metadata": {"source": "ai_korean.pdf", "page": 1}
    },
    # ... 더 많은 한글 샘플
]
```

#### B. 메타데이터 패턴

```python
METADATA_PATTERNS = {
    "simple": {"source": "doc.pdf"},
    "with_page": {"source": "doc.pdf", "page": 1},
    "with_category": {"source": "doc.pdf", "category": "tech"},
    "nested": {"source": "doc.pdf", "author": {"name": "John", "email": "john@example.com"}},
    "with_numbers": {"source": "doc.pdf", "page": 10, "score": 0.95},
}
```

### 4.2 테스트 환경 변수

```bash
# .env.test
TEST_API_KEY=your-test-api-key
TEST_BASE_URL=https://test.api.seahorse.dnotitia.ai
TEST_TABLE_NAME=test_table_sdk

# 테스트 실행 시 자동으로 로드되도록 설정
```

---

## 5. 성능 테스트

### 5.1 벤치마크 테스트

```python
# tests/performance/test_benchmarks.py
import pytest
import time


class TestPerformance:
    """성능 테스트."""
    
    @pytest.mark.slow
    def test_add_texts_throughput(self, vectorstore):
        """텍스트 추가 처리량."""
        texts = [f"Document {i}" for i in range(1000)]
        
        start = time.time()
        vectorstore.add_texts(texts)
        elapsed = time.time() - start
        
        throughput = len(texts) / elapsed
        
        # 최소 처리량 확인
        assert throughput > 10  # documents per second
        print(f"Throughput: {throughput:.2f} docs/sec")
    
    @pytest.mark.slow
    def test_search_latency(self, vectorstore, sample_texts):
        """검색 지연시간."""
        vectorstore.add_texts(sample_texts * 100)  # 300 documents
        
        latencies = []
        for _ in range(10):
            start = time.time()
            vectorstore.similarity_search("test query", k=5)
            latencies.append(time.time() - start)
        
        avg_latency = sum(latencies) / len(latencies)
        
        # 평균 지연시간 확인
        assert avg_latency < 1.0  # 1초 이하
        print(f"Average latency: {avg_latency*1000:.2f}ms")
```

---

## 6. 테스트 실행

### 6.1 로컬 실행

```bash
# 전체 테스트
uv run pytest

# Unit tests만
uv run pytest tests/unit/

# Integration tests만 (API key 필요)
uv run pytest tests/integration/

# 특정 마커
uv run pytest -m "not slow"

# 커버리지 포함
uv run pytest --cov=langchain_seahorse --cov-report=html

# Verbose 모드
uv run pytest -v -s
```

### 6.2 CI에서 실행

```yaml
# .github/workflows/test.yml
- name: Run unit tests
  run: uv run pytest tests/unit/ --cov=langchain_seahorse

- name: Run integration tests
  env:
    TEST_API_KEY: ${{ secrets.TEST_API_KEY }}
    TEST_BASE_URL: ${{ secrets.TEST_BASE_URL }}
  run: uv run pytest tests/integration/
```

---

## 7. 테스트 체크리스트

### Phase 1: MVP

- [ ] Unit Tests
  - [ ] `convert_filter_to_sql()`
  - [ ] `generate_pk()`
  - [ ] `batch_texts()`
  - [ ] CoralResponse 언래핑
  - [ ] 에러 처리

- [ ] Integration Tests
  - [ ] `add_texts()` 기본
  - [ ] `similarity_search()` 기본
  - [ ] 에러 케이스

### Phase 2: Full Implementation

- [ ] Unit Tests
  - [ ] 모든 필터 연산자
  - [ ] 재시도 로직
  - [ ] 비동기 메서드

- [ ] Integration Tests
  - [ ] `similarity_search_with_score()`
  - [ ] `similarity_search_by_vector()`
  - [ ] `delete()`
  - [ ] 필터링 검색
  - [ ] 대량 데이터 처리

### Phase 3: Advanced

- [ ] Performance Tests
  - [ ] 처리량 테스트
  - [ ] 지연시간 테스트
  - [ ] 메모리 사용량 테스트

- [ ] E2E Tests
  - [ ] 전체 워크플로우
  - [ ] RAG 파이프라인
  - [ ] 다양한 시나리오

---

## 8. 테스트 실패 시 디버깅

### 8.1 로깅 활성화

```python
# tests/conftest.py
import logging

@pytest.fixture(scope="session", autouse=True)
def setup_logging():
    logging.basicConfig(
        level=logging.DEBUG,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )
```

### 8.2 디버그 모드

```bash
# pdb 사용
uv run pytest --pdb

# 특정 테스트만 디버그
uv run pytest tests/unit/test_filters.py::test_simple_equality --pdb

# 출력 캡처 비활성화
uv run pytest -s
```

---

## 9. 커버리지 리포트

### 9.1 HTML 리포트 생성

```bash
uv run pytest --cov=langchain_seahorse --cov-report=html

# htmlcov/index.html 브라우저로 열기
open htmlcov/index.html
```

### 9.2 커버리지 목표 설정

```toml
# pyproject.toml
[tool.pytest.ini_options]
addopts = "--cov=langchain_seahorse --cov-fail-under=80"
```

이 테스트 요구사항을 따라 견고한 SDK를 개발하세요!

