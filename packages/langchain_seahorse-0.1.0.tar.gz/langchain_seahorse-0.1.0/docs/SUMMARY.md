# LangChain Seahorse SDK - 개발 정보 요약

이 문서는 확인된 정보를 한눈에 볼 수 있도록 요약한 것입니다.

---

## ✅ 확인 완료된 핵심 정보

### 1. API 환경

| 항목 | 값 |
|-----|---|
| Production URL | `https://{table-uuid}.api.seahorse.dnotitia.ai` |
| Development URL | `https://{table-uuid}.api.seahorse.dnotitia.com` |
| URL 생성 | 테이블 생성 시 UUID 자동 할당 |
| API Key 발급 | https://console.seahorse.dnotitia.ai/main/management/api-keys |
| API Key 권한 | READ / WRITE |
| API Key 만료 | 현재 없음 |

### 2. 메타데이터 필터링 (⭐ 가장 중요)

| 항목 | 값 |
|-----|---|
| metadata 컬럼 타입 | LargeUtf8 (String) |
| JSONB 연산자 | ❌ 미지원 |
| JSON 쿼리 | ❌ 불가능 |
| 필터링 방법 | LIKE 패턴 사용 |
| 지원 연산자 | equal 연산만 가능 |
| JSON 중첩 | Flat한 JSON만 지원 |

**필터 변환 예시:**
```python
# LangChain 필터
{"source": "doc.pdf"}

# SQL WHERE 절
"metadata LIKE '%\"source\": \"doc.pdf\"%'"
```

### 3. 배치 처리

| 항목 | 값 |
|-----|---|
| `/v1/data/embedding` 배열 크기 | 명시적 제한 없음 |
| 권장 배치 크기 | 1024 |
| JSON 페이로드 최대 | 20MB |
| `/v1/inference/embedding` 배치 | ❌ 미지원 (반복 호출 필요) |
| 타임아웃 | 테스트 필요 |

### 4. 벡터 및 임베딩

| 항목 | 값 |
|-----|---|
| 기본 임베딩 모델 | `seongil-dn/bge-m3-3800_steps_v2_234` |
| 벡터 차원 | 1024 (현재 고정) |
| max_model_len | 1024 (임베딩 가능한 최대 차원) |
| 다른 차원 지원 | 원래는 가능하나 현재 파라미터로 열리지 않음 |

### 5. 테이블 관리

| 항목 | 값 |
|-----|---|
| 테이블 생성 API | ❌ 없음 |
| 생성 방법 | 콘솔 웹페이지에서만 가능 |
| SDK 자동 생성 | ❌ 불가능 |
| 사전 생성 필수 | ✅ 필수 |
| 기본 스키마 | id, text, metadata, embedding (모두 필수) |
| 추가 컬럼 | 테이블 생성 시 추가 가능 |

### 6. 미지원 기능

| 기능 | 상태 |
|-----|------|
| MMR 검색 | ❌ API 미지원 |
| Hybrid/Sparse 검색 | ⏳ 다음 버전 예정 |
| 세그먼트 통계 | ⚠️ deprecated 예정 (노출 불필요) |

---

## ❓ 아직 확인 필요

### Rate Limiting
- [ ] 제한 정책 (per second, per minute, per hour)
- [ ] API별 다른 제한 여부
- [ ] 429 에러 시 Retry-After 헤더 제공 여부
- [ ] Rate limit 정보 헤더 (X-RateLimit-*)

### 에러 코드
- [ ] 전체 에러 코드 목록
- [ ] 벡터 차원 불일치 시 에러 메시지 포맷
- [ ] Primary Key 중복 시 에러 메시지
- [ ] 필터 구문 오류 시 에러 메시지

### 성능 최적화
- [ ] ef_search 최댓값 (현재 500으로 설정)
- [ ] 병렬 처리 권장값
- [ ] 캐싱 정책

---

## 📋 개발 시작 전 준비사항

### 필수 (개발 불가능)
- [x] API 명세 확인
- [x] OpenAPI 스펙 확인
- [x] metadata 타입 확인
- [x] 테이블 스키마 확인
- [x] 벡터 차원 확인
- [x] 테스트용 API Key 발급 (env 파일에 설정)
- [x] 테스트용 테이블 생성

### 권장 (개발 시 참고)
- [x] Rust 클라이언트 코드 확인
- [x] LangChain VectorStore 인터페이스 확인
- [x] 다른 VectorStore 구현 참고

---

## 🎯 핵심 구현 포인트

### 1. Primary Key 생성
```python
import hashlib

def generate_pk(content: str, chunk_id: int = 0) -> str:
    doc_id = hashlib.sha512(content.encode()).hexdigest()
    return f"{doc_id}\x1e{chunk_id}"
```

### 2. 메타데이터 필터 변환
```python
def convert_filter_to_sql(filter: Dict[str, Any]) -> str:
    """LIKE 패턴으로 변환 (equal만 지원)"""
    conditions = []
    for key, value in filter.items():
        if isinstance(value, str):
            conditions.append(f"metadata LIKE '%\"{key}\": \"{value}\"%'")
        elif isinstance(value, (int, float)):
            conditions.append(f"metadata LIKE '%\"{key}\": {value}%'")
    return " AND ".join(conditions)
```

### 3. CoralResponse 언래핑
```python
def _unwrap_coral_response(response: httpx.Response) -> Any:
    data = response.json()
    
    if not data.get("success"):
        exception = data.get("exception", {})
        raise SeahorseAPIError(
            status_code=data.get("code"),
            error_code=exception.get("error_code"),
            error_message=exception.get("error_message"),
        )
    
    return data.get("data")
```

### 4. 배치 처리
```python
DEFAULT_BATCH_SIZE = 1024
MAX_JSON_SIZE = 20 * 1024 * 1024  # 20MB

# 1024개씩 나눠서 처리
for batch in batch_texts(texts, metadatas, batch_size=DEFAULT_BATCH_SIZE):
    client.insert_with_embedding(batch)
```

---

## 🚀 즉시 시작 가능한 항목

### Phase 1: MVP

1. **프로젝트 초기화** (즉시 가능)
   ```bash
   uv init langchain-seahorse
   cd langchain-seahorse
   uv add langchain-core httpx pydantic
   ```

2. **SeahorseClient 구현** (즉시 가능)
   - `__init__()`: API Key와 Base URL 설정
   - `insert_with_embedding()`: POST /v1/data/embedding
   - `semantic_search()`: POST /v1/data/semantic-search
   - `_unwrap_coral_response()`: CoralResponse 처리

3. **SeahorseVectorStore 구현** (즉시 가능)
   - `__init__()`: 클라이언트 초기화
   - `add_texts()`: 내장 임베딩으로 텍스트 추가
   - `similarity_search()`: 시맨틱 검색
   - `_generate_pk()`: Primary Key 생성

4. **필터 변환 로직** (즉시 가능)
   - LIKE 패턴 기반 equal 연산
   - 여러 조건 AND로 조합

---

## ⏸️ 테스트 필요 항목

개발 중 실제 API로 테스트하면서 확인해야 할 사항:

1. **타임아웃**
   - 대량 데이터 삽입 시 타임아웃 발생 여부
   - 적절한 타임아웃 값 설정

2. **에러 메시지 포맷**
   - 벡터 차원 불일치 시 정확한 메시지
   - Primary Key 중복 시 메시지
   - 각종 validation 에러 메시지

3. **필터 LIKE 패턴**
   - JSON 문자열 포맷팅 정확도
   - 특수 문자 이스케이프 필요 여부
   - 공백 처리 방식

4. **성능**
   - 최적 배치 크기 (1024가 실제로 최적인지)
   - ef_search 값에 따른 성능 차이
   - 대량 데이터 처리 시 병목

---

## 📝 다음 단계

### 개발자가 할 일

1. **즉시 시작**
   - 프로젝트 초기화 (uv init)
   - SeahorseClient 기본 구현
   - Primary Key 생성 로직 구현

2. **테스트 환경 요청**
   - 테스트용 API Key 발급
   - 테스트용 테이블 생성 (기본 스키마)
   - Base URL 수령

3. **개발 중 확인**
   - 필터 LIKE 패턴 동작 테스트
   - 에러 메시지 포맷 확인
   - 배치 크기 최적화 테스트

### API 관리자가 제공할 것

1. **즉시 제공**
   - [x] API 명세 문서
   - [x] OpenAPI 스펙 파일
   - [x] 테스트용 API Key (env 파일에 설정)
   - [x] 테스트용 테이블 (id, text, metadata, embedding 스키마)

2. **나중에 확인**
   - Rate Limiting 정책
   - 상세 에러 코드 목록
   - 성능 최적화 가이드

---

**마지막 업데이트:** 2025-11-21
**버전:** 0.1.0
**상태:** Phase 2 완료 ✅

---

## 🎉 Phase 2 개발 완료!

### 구현 완료 내역

#### ✅ Phase 1: MVP
- SeahorseVectorStore 기본 구현
- SeahorseClient (API 클라이언트)
- 메타데이터 필터링 (LIKE 패턴)
- Primary Key 자동 생성
- 에러 처리 및 재시도
- 35 unit tests 통과

#### ✅ Phase 2: Full Implementation
- 8개 비동기 메서드 구현
- 12개 비동기 tests 추가
- MMR 미지원 명시
- API 문서 작성
- 5개 예제 코드

### 📊 프로젝트 통계
- **테스트**: 47개 통과 ✅
- **커버리지**: 76% 
- **코드 라인**: 4,196줄
- **Python 파일**: 26개

### 🌐 환경 정보
- ✅ Production URL: `https://455fe13765664952bed80e7c22dd3436.api.seahorse.dnotitia.ai`
- ✅ Development URL: `http://9683ea76604642ac8dd8ac05934b05b8.api.seahorse.dnotitia.com`
- ✅ `.env` 파일로 credentials 관리
- ✅ 테이블: id, text, metadata, embedding (1024차원)

### 🚀 준비 완료!
PyPI 배포 가능 상태입니다!
