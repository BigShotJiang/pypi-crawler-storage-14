# Seahorse API Gateway - API 명세서

**버전**: v1.0.1-rc15
**최종 업데이트**: 2025-11-17  

> 📌 **버전 관리 정책**: 이 문서는 [Semantic Versioning](https://semver.org/)을 따릅니다.

## 📋 목차

1. 개요
2. 인증
3. 공통 응답 포맷
4. TABLE API 엔드포인트
5. INFERENCE API 엔드포인트
6. STORAGE API 엔드포인트
7. 사용 시나리오 예시
8. 파라미터 가이드
9. 주의사항
10. 에러코드
11. 성능 최적화 팁
12. 용어사전
13. 문제 해결 가이드

---

## 개요

Seahorse API Gateway는 벡터 데이터베이스, AI 추론, 스토리지 서비스를 통합한 API 게이트웨이입니다. 이 문서는 **TABLE**, **INFERENCE**, **STORAGE** 관련 API들을 다루며, 데이터 삽입, 조회, 수정, 삭제, 벡터 검색, AI 추론, 객체 스토리지 기능을 제공합니다.

---

## 인증

모든 API 요청에는 Bearer 토큰을 포함해야 합니다. API key는 https://console.seahorse.dnotitia.ai/main/management/api-keys 에서 생성 가능합니다.

```bash
-H "Authorization: Bearer <your-api-key>"
```

---

## 공통 응답 형식

모든 API는 다음과 같은 형식으로 응답합니다:

```json
{
  "success": true,
  "code": 200,
  "data": { /* 응답 데이터 */ },
  "exception": null
}
```

### 에러 응답 예시

```json
{
  "success": false,
  "code": 400,
  "data": null,
  "exception": {
    "error_code": 400001,
    "error_message": "Bad Request: Invalid input"
  }
}
```

---

## TABLE API 엔드포인트

### Base URL

https://console.seahorse.dnotitia.ai/main/tables 에서 생성한 테이블 상세 페이지에서 Host Name을 복사해서 사용할 수 있습니다.

```
https://bb1974015e734908ac3fe77a7dc57083.api.seahorse.dnotitia.ai
```

---

### 1. 테이블 스키마 조회

**GET** `/v1/data/schema`

- **설명**: 테이블의 구조, **Apache Arrow 스키마**와 메타데이터(예: 인덱스 설정)를 조회.

**요청 예시:**

```bash
curl -X GET "https://your-api-domain.com/v1/data/schema" \
  -H "Authorization: Bearer YOUR_TOKEN"
```

**성공 응답**

**응답 예시:**

```json
{
  "code": 200,
  "success": true,
  "data": {
    "table_name": "my_table1",
    "schema": {
      "fields": [
        {
          "data_type": "LargeUtf8",
          "dict_id": 0,
          "dict_is_ordered": false,
          "metadata": {},
          "name": "id",
          "nullable": false
        },
        {
          "data_type": "LargeUtf8",
          "dict_id": 0,
          "dict_is_ordered": false,
          "metadata": {},
          "name": "metadata",
          "nullable": false
        },
        {
          "data_type": "LargeUtf8",
          "dict_id": 0,
          "dict_is_ordered": false,
          "metadata": {},
          "name": "text",
          "nullable": false
        },
        {
          "data_type": {
            "FixedSizeList": [
              {
                "data_type": "Float32",
                "dict_id": 0,
                "dict_is_ordered": false,
                "metadata": {},
                "name": "item",
                "nullable": true
              },
              1024
            ]
          },
          "dict_id": 0,
          "dict_is_ordered": false,
          "metadata": {},
          "name": "embedding",
          "nullable": false
        }
      ],
      "metadata": {
        "active_set_size_limit": "50000",
        "index_info": "[{\"column_id\":\"3\",\"index_type\":\"hnsw\",\"parameters\":{\"M\":\"16\",\"ef_construction\":\"128\",\"space\":\"ipspace\"}}]",
        "table name": "my_table1"
      }
    }
  }
}
```

**필드 설명**

- **`table_name`**: 테이블 이름.
- **`schema`**: **Apache Arrow 스키마**
    - `fields` *(array of object)*: 컬럼 정의 목록.
        - `name` *(string)*: 컬럼명(스키마 내 유일).
        - `data_type` *(string | object)*: Arrow 타입
            - 예) "LargeUtf8" 또는
                
                ```
                { "FixedSizeList": [ { "data_type": "Float32", "name": "item", ... }, 1024 ] }
                ```
                
        - `nullable` *(boolean)*: NULL 허용 여부.
        - `dict_id` *(integer)*: 0이면 사전 인코딩 미사용(관습적).
        - `dict_is_ordered` *(boolean)*: 사전 인코딩 값 정렬 여부(미사용 시 false로 둘 수 있음).
        - `metadata` *(object)*: 컬럼 수준 메타데이터(없으면 {}).
    - `metadata` *(object)*: 테이블 수준 메타데이터.
        - `active_set_size_limit` *(string | number)*: 활성 세트 상한(예: "50000").
        - `index_info` *(string,*  **문자열화된 JSON***)*: 임베딩 **컬럼에 대한 인덱스 정의 리스트**
            
            ```
            "[{\"column_id\":\"3\",\"index_type\":\"hnsw\",\"parameters\":{\"M\":\"16\",\"ef_construction\":\"128\",\"space\":\"ipspace\"}}]"
            ```
            
            - `column_id`는 fields의 **0‑based index**를 가리킵니다(여기선 3 → embedding).

### **참고1) index_info 상세 구조**

**① Dense Embedding**

```
{
  "column_id": "3",
  "index_type": "hnsw",
  "parameters": {
    "M": "16",
    "ef_construction": "128",
    "space": "ipspace"
  }
}
```

- **index_type:** "hnsw", "diskbased" 지원
    - Dense vector 검색용 ANN(Approximate Nearest Neighbor) 인덱스.
    - `DISKBASED` 설정 시, 클러스터가 diskbased 인덱스를 지원하도록 사전 구성되어 있어야 합니다.
- **parameters:**
    - `M`: 각 노드가 연결할 최대 neighbor 수
    - `ef_construction`: 인덱스 구축 시 이웃 후보를 탐색하는 큐의 크기 (높을수록 정확도↑, 속도↓)
    - `space`: 벡터 간 거리 측정 방식 (ipspace = inner product, l2space = L2 distance)

### **참고2) dense embedding column 설명**

```json
{
  "data_type": {
    "FixedSizeList": [
      { "data_type": "Float32", "name": "item", "nullable": true },
      1024
    ]
  },
  "name": "embedding",
  "nullable": false
}
```

- **FixedSizeList**: 고정 길이 리스트(여기선 길이(dimension) 1024)
- 리스트의 각 요소:
    - **Float32**: 32비트 부동소수점 실수
    - nullable: true → 벡터 요소 중 일부가 null일 수 있음
- **용도**: 벡터 검색(ANN, embedding 기반 검색)을 위한 1024차원 임베딩 벡터

---

### 2. 데이터 삽입

**POST** `/v1/data`

- **설명**: JSON Lines(JSONL) 형식으로 여러 행을 스트리밍처럼 삽입합니다.
- **Query**
    - `batch_insert_size` *(int, optional)*: 레코드 배치 크기. 기본 1024.
- **Request Body**
    - **Content-Type**: `text/plain` (**주의: JSON이 아니라 JSONL**)
    - 각 줄이 하나의 JSON 레코드입니다.
    - **벡터 길이**(아래 예시 기준으로 `embedding`)는 테이블 생성 시 지정된 **차원**과 같아야 합니다. 
        - 1024 차원일 경우, embedding 데이터(배열)의 길이도 1024여야 합니다.
    - **PK(기본키) 생성 규칙 권장**:
        - 포맷: `{DocumentId}{RS(ASCII 30)}{ChunkId}`
        - Document Id: 중복 탐지를 위한 해시(권장 길이 ~128자)
        - 구분자: ASCII 30 (\u001E)
        - Chunk Id: 0부터 증가하는 4바이트 부호 없는 정수(최대 2^32-1)
        - **각 chunk의 pk는 반드시 유일**해야 합니다.
- **예시(JSONL)**

```json
{"id":"1","metadata":"{\"file_name\": \"abc.pdf\"}","text":"hello","embedding":[1.0,2.0,3.0]}
{"id":"2","metadata":"{\"file_name\": \"def.pdf\"}","text":"world","embedding":[4.0,5.0,6.0]}
{"id":"3","metadata":"{\"file_name\": \"ghi.pdf\"}","text":"rust","embedding":[7.0,8.0,9.0]}
```

- **요청 예시:**

```bash
curl -X POST "https://your-api-domain.com/v1/data?batch_insert_size=1024" \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -H "Content-Type: text/plain" \
  --data-raw '{
  "id": "1",
  "metadata": "{\"file_name\": \"abc.pdf\"}",
  "text": "hello",
  "embedding": [1.0, 2.0, 3.0]
}
{
  "id": "2",
  "metadata": "{\"file_name\": \"def.pdf\"}",
  "text": "world",
  "embedding": [4.0, 5.0, 6.0]
}'
```

- **성공 응답**(요약): 삽입된 배치 수, 행 수, 경과 시간.
- **응답 예시:**

```json
{
  "code": 200,
  "success": true,
  "data": {
    "inserted_row_count": 4,
    "inserted_record_batches": 1,
    "elapsed_time": null
  },
  "exception": null
}
```

---

### 3. 배치 데이터 삽입

**POST** `/v1/data/batch-insert`

- **설명**: 서버가 지정한 **파일 경로**에서 데이터를 대량으로 읽어와 삽입합니다. Parquet 같은 큰 파일에 적합.
- **Query**
    - `format` *(enum)*: 파일 형식. 기본 `Parquet`. (Jsonl, Parquet)
    - `batch_insert_size` *(int)*: 배치 크기. 기본 1024.
- **Request Body:**

```json
{
  "storage_type": "CEPH",
  "bucket": "my_bucket",
  "file_path": ["parquet/big.parquet"],
  "credentials": {
    "access_key": "accesskey",
    "secret_key": "secretkey"
  },
  "options": {
    "endpoint": "http://127.0.0.1:8080",
    "allow_http": true,
    "virtual_hosted_style": false
  },
  "file_job_parallel_size": 10
}
```

- **필드 설명:**
    - `storage_type`: 스토리지 유형 (AWS, S3, GCP, AZURE, CEPH, MINIO, S3_COMPATIBLE)
    - `bucket`: 버킷 이름 (optional)
    - `file_path`: 삽입할 파일 경로 배열 (required)
    - `directory_path`: 파일 디렉토리 경로 (optional)
    - `credentials`: 클라우드 스토리지 접근 자격증명 (optional)
        - `access_key`: 액세스 키
        - `secret_key`: 시크릿 키
    - `options`: 스토리지 연결 옵션 (optional)
        - `endpoint`: 엔드포인트 URL
        - `allow_http`: HTTP 허용 여부 (기본: false)
        - `virtual_hosted_style`: 가상 호스팅 스타일 요청 사용 여부 (기본: false)
        - `region`: 리전
    - `file_job_parallel_size`: 병렬 처리할 파일 수 (optional, 기본: 1)
    
    > **참고**: Jsonl (Json Lines) 형식은 벡터 데이터 삽입을 지원하지 않습니다.
    
- **성공 응답**: 삽입된 레코드 배치/행 수 등
- **응답 예시:**

```json
{
  "code": 200,
  "success": true,
  "data": {
    "inserted_row_count": 1,
    "inserted_record_batches": 1,
    "elapsed_time": null
  },
  "exception": null
}
```

---

### 4. 임베딩과 함께 데이터 삽입

**POST** `/v1/data/embedding`

- **설명**: `text` 등 원문에서 임베딩을 **모델 추론 엔드포인트**로 생성한 뒤, 그 결과를 벡터 컬럼에 저장하고 함께 삽입합니다.
- **Request Body**

```json
{
  "data": [
    {
      "id": "1",
      "metadata": "A",
      "text": "hello"
    },
    {
      "id": "2",
      "metadata": "B",
      "text": "world"
    }
  ],
  "embedding_source": "text",
  "embedding_target": "embedding"
}
```

- **필드 설명:**
    - `data`: 삽입할 데이터 배열 (예: `{id, text, metadata}`)
    - `embedding_source`: 임베딩할 텍스트가 있는 컬럼명 (예: `text`)
    - `embedding_target`: 생성된 임베딩 벡터를 저장할 컬럼명 (예: `embedding`)
        - 임베딩 타겟 컬럼은 반드시 벡터 컬럼이어야 합니다.
- **성공 응답**: 삽입된 배치/행 수
- **응답 예시:**

```json
{
  "code": 200,
  "success": true,
  "data": {
    "inserted_row_count": 1,
    "inserted_record_batches": 1,
    "elapsed_time": 1.0
  },
  "exception": null
}
```

---

### 5. 데이터 조회 (Scan)

**POST** `/v1/data/scan`

- **설명**: 전 노드를 스캔하며 조건에 맞는 데이터 반환. 일반 RDB의 `SELECT`와 유사.

**Request Body:**

```json
{
  "projection": "id, metadata, text",
  "filter": "id = '1'",
  "limit": 10
}
```

**필드 설명:**

- `projection`: 반환할 컬럼 (optional)
    - 기본값: "*" - 모든 컬럼
    - 예: `id, metadata, text`
- `filter`: 필터 조건 (SQL WHERE 절, optional, 기본값: "")
    - 예: `text like '%hello%'`
- `limit`: 반환할 최대 행 수 (optional, 기본값: 0 - 모든 행)

**요청 예시:**

```bash
curl -X POST "https://your-api-domain.com/v1/data/scan" \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "projection": "id, text",
    "filter": "id = '\''1'\''",
    "limit": 10
  }'
```

**성공 응답**: 단일 resultset(JSON 배열 + Arrow 스타일 스키마 메타)

**응답 예시:**

```json
{
  "code": 200,
  "success": true,
  "data": {
    "schema": {
      "fields": [
        {
          "name": "id",
          "data_type": "LargeUtf8",
          "dict_id": 0,
          "dict_is_ordered": false,
          "metadata": {},
          "nullable": false
        },
        {
          "name": "metadata",
          "data_type": "LargeUtf8",
          "dict_id": 0,
          "dict_is_ordered": false,
          "metadata": {},
          "nullable": false
        },
        {
          "name": "text",
          "data_type": "LargeUtf8",
          "dict_id": 0,
          "dict_is_ordered": false,
          "metadata": {},
          "nullable": false
        }
      ],
      "metadata": {}
    },
    "data": [
      {
        "id": "1",
        "metadata": "{\"file_name\": \"abc.pdf\"}",
        "text": "hello"
      }
    ]
  },
  "exception": null
}
```

---

### 6. 벡터 검색

**POST** `/v1/data/indexes/{index_name}/vector-search`

- **설명**: 주어진 **벡터 컬럼명(index_name)** 에 대해 벡터 유사도 검색 수행. ANN(HNSW 등) 기반.
- **Path Param**
    - `index_name`: 검색 대상 벡터 컬럼명(예: `embedding`)

**Request Body** 

```json
{
  "query_vectors": {
    "dense": [
      [0.1, 0.2, 0.3, 0.4],
      [0.5, 0.6, 0.7, 0.8]
    ]
  },
  "top_k": 3,
  "ef_search": 100,
  "projection": "id, metadata, text, distance",
  "filter": "video_id < 3000"
}
```

**필드 설명:**

- `query_vectors`: 검색할 벡터 (Dense 또는 Sparse) (required)
    - Dense: 2차원 float 배열 형식
        - **중요**: 각 벡터(배열)의 길이는 테이블의 해당 벡터 컬럼 차원 수와 동일해야 합니다.
        - 예: 테이블의 `embedding` 컬럼이 1024차원이면, `query_vectors.dense` 배열도 각각 1024개의 float 값을 가져야 합니다.
- `top_k`: 반환할 상위 결과 개수 (required)
- `ef_search`: 검색 정확도 (클수록 정확하지만 느림) (optional, 기본값: top_k와 동일)
- `projection`: 반환할 컬럼 (optional, 기본값: "*")
- `filter`: 필터 조건 (WHERE 절) (optional, 기본값: "")

**성공 응답**: 다중 resultset(질의 벡터 개수만큼), projection에 distance 선언 시 각 아이템에 `distance`(dense)

**응답 예시:**

```json
{
  "code": 200,
  "success": true,
  "data": {
    "num_resultsets": 2,
    "schema": {
      "fields": [
        {
          "name": "id",
          "data_type": "LargeUtf8",
          "dict_id": 0,
          "dict_is_ordered": false,
          "metadata": {},
          "nullable": false
        },
        {
          "name": "metadata",
          "data_type": "LargeUtf8",
          "dict_id": 0,
          "dict_is_ordered": false,
          "metadata": {},
          "nullable": false
        },
        {
          "name": "text",
          "data_type": "LargeUtf8",
          "dict_id": 0,
          "dict_is_ordered": false,
          "metadata": {},
          "nullable": false
        },
        {
          "name": "distance",
          "data_type": "Float32",
          "dict_id": 0,
          "dict_is_ordered": false,
          "metadata": {},
          "nullable": false
        }
      ],
      "metadata": {}
    },
    "data": [
      [
        {
          "id": "1",
          "metadata": "{\"file_name\": \"abc.pdf\"}",
          "text": "hello",
          "distance": 0.10213412
        },
        {
          "id": "2",
          "metadata": "{\"file_name\": \"def.pdf\"}",
          "text": "world",
          "distance": 0.20213412
        },
        {
          "id": "3",
          "metadata": "{\"file_name\": \"ghi.pdf\"}",
          "text": "rust",
          "distance": 0.30213412
        }
      ],
      [
        {
          "id": "4",
          "metadata": "{\"file_name\": \"jkl.pdf\"}",
          "text": "python",
          "distance": 0.15223412
        },
        {
          "id": "5",
          "metadata": "{\"file_name\": \"mno.pdf\"}",
          "text": "java",
          "distance": 0.25223412
        },
        {
          "id": "6",
          "metadata": "{\"file_name\": \"pqr.pdf\"}",
          "text": "go",
          "distance": 0.35223412
        }
      ]
    ]
  },
  "exception": null
}
```

---

### 7. 시맨틱 검색

**POST** `/v1/data/semantic-search`

- **설명**: 자연어 질의로 **가장 관련도 높은 문서 조각**을 찾습니다. 내부적으로 dense 벡터 기반 검색을 사용합니다.

**Request Body:**

```json
{
  "query": "dnotitia에 대해 설명해줘",
  "index_name": "embedding",
  "top_k": 5,
  "ef_search": 1000,
  "projection": "text, metadata, distance",
  "filter": "text like \'%hello%\'"
}
```

**필드 설명:**

- `query`: 검색할 자연어 질문 (required)
- `index_name`: 대상 벡터(dense) 컬럼 이름 (required)
- `top_k`: 반환할 상위 결과 개수 (required)
- `ef_search`: 검색 정확도 (optional, 기본값: top_k와 동일)
- `projection`: 반환할 컬럼 (optional, 기본값: "*")
- `filter`: 필터 조건 (WHERE 절) (optional, 기본값: "")

**요청 예시:**

```bash
curl -X POST "https://your-api-domain.com/v1/data/semantic-search" \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "query": "dnotitia에 대해 설명해줘",
    "index_name": "embedding",
    "top_k": 5
  }'
```

**성공 응답**: 단일 다중결과셋 형태(보통 1개의 resultset에 상위 k개). 점수는 `distance`가 포함됩니다.

**응답 예시:**

```json
{
  "code": 200,
  "success": true,
  "data": {
    "num_resultsets": 1,
    "schema": {
      "fields": [
        {
          "name": "text",
          "data_type": "LargeUtf8",
          "dict_id": 0,
          "dict_is_ordered": false,
          "metadata": {},
          "nullable": false
        },
        {
          "name": "metadata",
          "data_type": "LargeUtf8",
          "dict_id": 0,
          "dict_is_ordered": false,
          "metadata": {},
          "nullable": false
        },
        {
          "name": "distance",
          "data_type": "Float32",
          "dict_id": 0,
          "dict_is_ordered": false,
          "metadata": {},
          "nullable": true
        }
      ],
      "metadata": {}
    },
    "data": [
      [
        {
          "text": "Filename: test file 01",
          "metadata": "{\"source\": \"small/test-file-01.pdf\", \"page\": 638, \"file_name\": \"test-file-01.pdf\", \"processed_time\": 1747208826.8216445, \"source_type\": \"S3\"}",
          "distance": 0.58199745
        },
        {
          "text": "Filename: test file 02",
          "metadata": "{\"source\": \"small/test-file-02.pdf\", \"page\": 642, \"file_name\": \"test-file-02.pdf\", \"processed_time\": 1747208826.8216455, \"source_type\": \"S3\"}",
          "distance": 0.5931134
        },
        {
          "text": "Filename: test file 02",
          "metadata": "{\"source\": \"small/test-file-02.pdf\", \"page\": 640, \"file_name\": \"test-file-02.pdf\", \"processed_time\": 1747208826.821645, \"source_type\": \"S3\"}",
          "distance": 0.59964377
        },
        {
          "text": "Filename: test file 01",
          "metadata": "{\"source\": \"small/test-file-01.pdf\", \"page\": 56, \"file_name\": \"test-file-01.pdf\", \"processed_time\": 1747208783.0184922, \"source_type\": \"S3\"}",
          "distance": 0.60592294
        },
        {
          "text": "Filename: test file 01",
          "metadata": "{\"source\": \"small/test-file-01.pdf\", \"page\": 642, \"file_name\": \"test-file-01.pdf\", \"processed_time\": 1747208826.8216455, \"source_type\": \"S3\"}",
          "distance": 0.61381185
        }
      ]
    ]
  },
  "exception": null
}
```

---

### 8. 데이터 수정

**POST** `/v1/data/update`

- **설명**: 조건에 맞는 데이터를 갱신합니다.

**Request Body:**

```json
{
  "update_condition": "id = '1000'",
  "update_values": "text = 'changed_text'"
}
```

**필드 설명:**

- `update_condition`: 수정할 행의 조건 (SQL WHERE 절) (optional, 기본값: "" - 모든 행 수정)
- `update_values`: 수정할 값 (SQL SET 절과 유사) (required)

**요청 예시:**

```bash
curl -X POST "https://your-api-domain.com/v1/data/update" \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "update_condition": "id = '\''1000'\''",
    "update_values": "text = '\''changed_text'\''"
  }'
```

**성공 응답**: `updated_row_count`

**응답 예시:**

```json
{
  "code": 200,
  "success": true,
  "data": {
    "updated_row_count": 100
  },
  "exception": null
}
```

---

### 9. 데이터 삭제

**POST** `/v1/data/delete`

- **설명**: 조건에 맞는 데이터를 삭제합니다.

**Request Body:**

```json
{
  "delete_condition": "id = '1000'"
}
```

**필드 설명:**

- `delete_condition`: 삭제할 행의 조건 (SQL WHERE 절, optional, 기본값: "" - 모든 행 삭제)
    - **주의**: 미제공 시 전체 삭제될 수 있으니 주의하세요.

**요청 예시:**

```bash
curl -X POST "https://your-api-domain.com/v1/data/delete" \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "delete_condition": "id = '\''1000'\''"
  }'
```

**성공 응답**: `deleted_row_count`

**응답 예시:**

```json
{
  "code": 200,
  "success": true,
  "data": {
    "deleted_row_count": 1000
  },
  "exception": null
}
```

---

### 10. 데이터 내보내기

**POST** `/v1/data/export-temp`

- **설명**: 테이블 전체를 파일로 내보냅니다(주로 Parquet). 로컬/클라우드 스토리지 모두 지원.

**Request Body:**

```json
{
  "storage_type": "S3",
  "bucket": "my_bucket",
  "directory_path": "parquet/big.parquet",
  "format": "Parquet",
  "row_group_size": 80000000,
  "credentials": {
    "access_key": "accesskey",
    "secret_key": "secretkey"
  },
  "options": {
    "endpoint": "http://127.0.0.1:8080",
    "allow_http": true,
    "virtual_hosted_style": false
  }
}
```

**필드 설명:**

- `storage_type`: 스토리지 유형 (AWS, S3, GCP, AZURE, CEPH, MINIO, S3_COMPATIBLE) (optional, 기본값: LOCAL)
- `directory_path`: 내보낼 디렉토리 경로 (required)
- `format`: 파일 형식 (현재 Parquet만 지원) (required, 기본값: Parquet)
- `row_group_size`: Row Group 크기 (바이트) (optional, 기본값: 80000000 = 80MB)
- `bucket`: 버킷 이름 (optional)
- `credentials`: 클라우드 스토리지 접근 자격증명 (optional)
    - `access_key`: 액세스 키
    - `secret_key`: 시크릿 키
- `options`: 스토리지 연결 옵션 (optional)
    - `endpoint`: 엔드포인트 URL
    - `allow_http`: HTTP 허용 여부 (기본: false)
    - `virtual_hosted_style`: 가상 호스팅 스타일 요청 사용 여부 (기본: false)
    - `region`: 리전

**성공 응답**: 총 행 수, 로우 그룹 수, 경로 등 `export_result`

**응답 예시:**

```json
{
  "code": 200,
  "success": true,
  "data": {
    "elapsed_time": 1.0,
    "export_result": {
      "file_path": "parquet/big.parquet",
      "total_row_count": 100,
      "total_uncompressed_byte_size": 100000,
      "num_row_groups": 10,
      "average_uncompressed_row_group_size": 10000
    }
  },
  "exception": null
}
```

---

### 11. 인덱싱된 행 개수 조회

**GET** `/v1/data/indexed-row-count`

- **설명**: 벡터 인덱스 별로 **색인 완료된 개수**와 총 행 수를 반환.

**요청 예시:**

```bash
curl -X GET "https://your-api-domain.com/v1/data/indexed-row-count" \
  -H "Authorization: Bearer YOUR_TOKEN"
```

**성공 응답**: `indexed_counts[]`(인덱스명/타입/색인된 행 수), `total_row_count`

**응답 예시:**

```json
{
  "code": 200,
  "success": true,
  "data": {
    "total_row_count": 1000,
    "indexed_counts": [
      {
        "index_name": "embedding",
        "index_type": "hnsw",
        "indexed_row_count": 300
      }
    ]
  },
  "exception": null
}
```

---

### 12. 행 개수 조회

**GET** `/v1/data/row-count`

- **설명**: 테이블의 총 행 수를 반환.

**요청 예시:**

```bash
curl -X GET "https://your-api-domain.com/v1/data/row-count" \
  -H "Authorization: Bearer YOUR_TOKEN"
```

**성공 응답**: `total_row_count`

**응답 예시:**

```json
{
  "code": 200,
  "success": true,
  "data": {
    "total_row_count": 1073741824
  },
  "exception": null
}
```

---

### 13. 세그먼트 통계 조회

**GET** `/v1/data/segment-statistics`

- **설명**: 테이블의 세그먼트 정보를 조회 합니다. (세그먼트 단위의 행 수, 삭제 수, 활성/비활성 집합 크기, 노드, 인덱싱 현황 등)

**요청 예시:**

```bash
curl -X GET "https://your-api-domain.com/v1/data/segment-statistics" \
  -H "Authorization: Bearer YOUR_TOKEN"
```

**성공 응답**: `segment_statistics[]` 항목 배열

**응답 예시:**

```json
{
  "code": 200,
  "success": true,
  "data": {
    "segment_statistics": [
      {
        "table_name": "my_table",
        "node": "node1",
        "segment_id": "A",
        "row_count": 100000,
        "indexed_row_count": {},
        "deleted_row_count": 0,
        "active_set_row_count": 0,
        "active_set_size_limit": 0,
        "inactive_set_count": 0
      }
    ]
  },
  "exception": null
}
```

**필드 설명:**

- `table_name`: 테이블 이름
- `node`: 노드 식별자
- `segment_id`: 세그먼트 ID
- `row_count`: 전체 행 개수
- `indexed_row_count`: 인덱스별 인덱싱된 행 개수
- `deleted_row_count`: 삭제된 행 개수
- `active_set_row_count`: 활성 집합의 행 개수
- `active_set_size_limit`: 활성 집합 크기 제한
- `inactive_set_count`: 비활성 집합 개수

---

## INFERENCE API 엔드포인트


### Base URL

추후 추가 에정 

---

> 📌 **API 포맷**: INFERENCE API의 요청/응답 형식은 **OpenAI API 표준 스펙**과 호환됩니다. 엔드포인트 경로만 다르며(`/v1/inference/*`), 페이로드 구조는 OpenAI API와 동일하게 사용할 수 있습니다.

### 1. 채팅 응답 생성 (스트리밍)

**POST** `/v1/inference/chat`

- **설명**: 주어진 프롬프트에 대한 채팅 응답을 생성합니다. 스트리밍 방식을 지원합니다.

**Request Body:**

```json
{
  "model": "Qwen/Qwen3-30B-A3B",
  "messages": [
    {
      "role": "system",
      "content": "You are a helpful assistant."
    },
    {
      "role": "user",
      "content": "안녕하세요, 오늘 날씨 어때요?"
    }
  ],
  "max_tokens": 512,
  "temperature": 0.7,
  "stream": true
}
```

**필드 설명:**

- `model`: 사용할 모델명 (required)
- `messages`: 대화 메시지 배열 (required)
    - `role`: 메시지 역할 (`system`, `user`, `assistant`)
    - `content`: 메시지 내용
- `max_tokens`: 생성할 최대 토큰 수 (required)
- `temperature`: 생성 온도 (0.0 ~ 1.0) (required)
- `stream`: 스트리밍 여부 (optional)

**요청 예시:**

```bash
curl -X POST "https://your-api-domain.com/v1/inference/chat" \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "model": "Qwen/Qwen3-30B-A3B",
    "messages": [
      {
        "role": "system",
        "content": "You are a helpful assistant."
      },
      {
        "role": "user",
        "content": "안녕하세요, 오늘 날씨 어때요?"
      }
    ],
    "max_tokens": 512,
    "temperature": 0.7,
    "stream": true
  }'
```

**성공 응답** (스트리밍 - `text/event-stream` 형식):

```
{"choices":[{"delta":{"content":""},"finish_reason":null,"index":0,"logprobs":null}],"created":1749464396,"id":"chatcmpl-92a2882f186c496980c546b778416af6","model":"microsoft/Phi-4","object":"chat.completion.chunk"}
{"choices":[{"delta":{"content":"안녕"},"finish_reason":null,"index":0,"logprobs":null}],"created":1749464396,"id":"chatcmpl-92a2882f186c496980c546b778416af6","model":"microsoft/Phi-4","object":"chat.completion.chunk"}
{"choices":[{"delta":{"content":"하세요"},"finish_reason":null,"index":0,"logprobs":null}],"created":1749464396,"id":"chatcmpl-92a2882f186c496980c546b778416af6","model":"microsoft/Phi-4","object":"chat.completion.chunk"}
```

---

### 2. 임베딩 생성

**POST** `/v1/inference/embedding`

- **설명**: 주어진 텍스트에 대한 임베딩을 생성합니다.

**Request Body:**

```json
{
  "input": "세종대왕에 대해 설명해줘"
}
```

**필드 설명:**

- `input`: 임베딩할 텍스트 (required)

**요청 예시:**

```bash
curl -X POST "https://your-api-domain.com/v1/inference/embedding" \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "input": "세종대왕에 대해 설명해줘"
  }'
```

**성공 응답**:

```json
{
  "created": 1747108569,
  "data": [
    {
      "embedding": [
        -0.05682373046875,
        0.0457763671875,
        0.01442718505859375,
        -0.004894256591796875,
        -0.00580596923828125,
        -0.036529541015625,
        0.0435791015625,
        0.0020618438720703125
      ],
      "index": 0,
      "object": "embedding"
    }
  ],
  "id": "embd-f9b1c2191e3c480392691f05ec104d85",
  "model": "seongil-dn/bge-m3-3800_steps_v2_234",
  "object": "list",
  "usage": {
    "completion_tokens": 0,
    "prompt_tokens": 11,
    "prompt_tokens_details": null,
    "total_tokens": 11
  }
}
```

---

### 3. 모델 목록 조회

**GET** `/v1/inference/models`

- **설명**: 추론에 사용 가능한 모델 목록을 조회합니다.

**요청 예시:**

```bash
curl -X GET "https://your-api-domain.com/v1/inference/models" \
  -H "Authorization: Bearer YOUR_TOKEN"
```

**성공 응답**:

```json
{
  "data": [
    {
      "created": 1756885796,
      "id": "seongil-dn/bge-m3-3800_steps_v2_234",
      "max_model_len": 1024,
      "object": "model",
      "owned_by": "vllm",
      "parent": null,
      "permission": [
        {
          "allow_create_engine": false,
          "allow_fine_tuning": false,
          "allow_logprobs": true,
          "allow_sampling": true,
          "allow_search_indices": false,
          "allow_view": true,
          "created": 1756885796,
          "group": null,
          "id": "modelperm-cb01ad02375f4989a5730d7e103b03ab",
          "is_blocking": false,
          "object": "model_permission",
          "organization": "*"
        }
      ],
      "root": "seongil-dn/bge-m3-3800_steps_v2_234"
    }
  ],
  "object": "list"
}
```

---

## STORAGE API 엔드포인트


### Base URL

추후 추가 에정 

---

### 1. 객체 가져오기

**GET** `/v1/storage/object`

- **설명**: 객체 키로 스토리지에서 객체를 가져옵니다.

**Query Parameters:**

- `object_key`: 가져올 객체의 경로(키) (required)

**요청 예시:**

```bash
curl -X GET "https://your-api-domain.com/v1/storage/object?object_key=pdf/test.pdf" \
  -H "Authorization: Bearer YOUR_TOKEN"
```

**성공 응답**: 파일 바이너리 데이터 (Content-Disposition 헤더 포함)

---

### 2. 객체 업로드

**POST** `/v1/storage/object`

- **설명**: 스토리지에 객체를 업로드합니다.

**Request Body** (`multipart/form-data`):

- `file`: 업로드할 파일 (binary) (required)
- `path`: 객체 업로드 경로 (예: "pdf/test.pdf") (required)

**요청 예시:**

```bash
curl -X POST "https://your-api-domain.com/v1/storage/object" \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -F "file=@/path/to/local/file.pdf" \
  -F "path=pdf/test.pdf"
```

**성공 응답**:

```json
{
  "code": 200,
  "success": true,
  "data": {
    "message": "Success to put object to storage."
  },
  "exception": null
}
```

---

### 3. 객체 삭제

**DELETE** `/v1/storage/object`

- **설명**: 객체 키로 스토리지에서 객체를 삭제합니다.

**Query Parameters:**

- `object_key`: 삭제할 객체의 경로(키) (예: "pdf/test.pdf") (required)

**요청 예시:**

```bash
curl -X DELETE "https://your-api-domain.com/v1/storage/object?object_key=pdf/test.pdf" \
  -H "Authorization: Bearer YOUR_TOKEN"
```

**성공 응답**:

```json
{
  "code": 200,
  "success": true,
  "data": {
    "message": "Success to delete object from storage."
  },
  "exception": null
}
```

---

### 4. 객체 목록 조회

**GET** `/v1/storage/objects`

- **설명**: 경로, 확장자, 파일명으로 필터링하여 스토리지에서 객체 목록을 조회합니다.

**Query Parameters:**

- `path`: 객체 경로 (예: "path/to/folder/") (optional)
- `extension`: 파일 확장자 (예: "txt", "pdf", "parquet") (optional)
- `file_name`: 파일 이름 (optional)

**요청 예시:**

```bash
curl -X GET "https://your-api-domain.com/v1/storage/objects?path=pdf/&extension=pdf" \
  -H "Authorization: Bearer YOUR_TOKEN"
```

**성공 응답**:

```json
{
  "code": 200,
  "success": true,
  "data": {
    "object_list": [
      "file1.txt",
      "pdf/file2.txt"
    ]
  },
  "exception": null
}
```

---

### 5. 여러 객체 삭제

**DELETE** `/v1/storage/objects`

- **설명**: 객체 키와 경로로 스토리지에서 여러 객체를 삭제합니다.

**Request Body:**

```json
{
  "object_keys": [
    "my-file.pdf",
    "my-file.doc"
  ],
  "path": [
    "pdf/",
    "doc/"
  ]
}
```

**필드 설명:**

- `object_keys`: 삭제할 객체 키 배열 (required)
- `path`: 삭제할 객체 경로 배열 (required)

**요청 예시:**

```bash
curl -X DELETE "https://your-api-domain.com/v1/storage/objects" \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "object_keys": ["my-file.pdf", "my-file.doc"],
    "path": ["pdf/", "doc/"]
  }'
```

**성공 응답**:

```json
{
  "code": 200,
  "success": true,
  "data": {
    "deleted_object_count": 3,
    "deleted_objects": [
      "my-file.pdf",
      "my-file.doc",
      "doc/my-file-2.doc"
    ],
    "errors": [
      {
        "key": "pdf/",
        "error_code": "404",
        "error_message": "Objects not exist in path"
      }
    ]
  },
  "exception": null
}
```

**필드 설명:**

- `deleted_object_count`: 삭제된 객체 수
- `deleted_objects`: 성공적으로 삭제된 객체 키 목록
- `errors`: 삭제 중 발생한 에러 목록
    - `key`: 실패한 키(객체 키 또는 경로)
    - `error_code`: 에러 코드
    - `error_message`: 에러 메시지

---

## 사용 시나리오 예시: 문서 검색 시스템 구축

1. **테이블 스키마 확인**
    
    ```bash
    GET /v1/data/schema
    ```
    
2. **문서 데이터 + 임베딩 삽입**
    
    ```bash
    POST /v1/data/embedding
    ```
    
    ```json
    {
      "data": [
        {
          "id": "doc1",
          "text": "인공지능은 컴퓨터가 인간처럼 생각하고 학습하는 기술입니다.",
          "metadata": "{\"title\": \"AI 개론\"}"
        }
      ],
      "embedding_source": "text",
      "embedding_target": "embedding"
    }
    ```
    
3. **인덱싱 상태 확인**
    
    ```bash
    GET /v1/data/indexed-row-count
    ```
    
4. **자연어로 시맨틱 검색**
    
    ```bash
    POST /v1/data/semantic-search
    ```
    
    ```json
    {
      "query": "머신러닝 알고리즘",
      "index_name": "embedding",
      "top_k": 10,
      "ef_search": 100
    }
    ```
    

---

## 파라미터 가이드

### ef_search 설정 가이드

`ef_search`는 검색 정확도와 속도의 균형을 조절합니다.

| 값 | 정확도 | 속도 | 추천 용도 |
| --- | --- | --- | --- |
| top_k | 낮음 | 빠름 | 빠른 응답이 필요한 경우 |
| top_k * 2 | 중간 | 보통 | 일반적인 사용 |
| top_k * 5 | 높음 | 느림 | 정확도가 중요한 경우 |
| 1000+ | 매우 높음 | 매우 느림 | 최고 정확도가 필요한 경우 |

**예시:**

```json
{
  "top_k": 10,
  "ef_search": 50  // top_k * 5 = 높은 정확도
}
```

### batch_insert_size 설정 가이드

데이터 삽입 시 한 번에 처리할 행 수를 조절합니다.

| 데이터 크기 | 권장 batch_insert_size | 이유 |
| --- | --- | --- |
| 소량 (< 1000행) | 512 | 빠른 응답 |
| 중간 (1000~10000행) | 1024 (기본값) | 균형잡힌 성능 |
| 대량 (> 10000행) | 2048~4096 | 처리량 최적화 |

---

## 주의사항

### 1. Primary Key 중복

- 동일한 `id`(Primary Key)를 가진 데이터를 삽입하면 오류가 발생합니다.
- 청크(Chunk)별로 고유한 ID를 생성해야 합니다.

**올바른 예시:**

```
문서 "doc1"의 첫 번째 청크: "doc1_hash\u001E0"
문서 "doc1"의 두 번째 청크: "doc1_hash\u001E1"
문서 "doc2"의 첫 번째 청크: "doc2_hash\u001E0"
```

### 2. 임베딩 벡터 차원

- 삽입하는 벡터의 차원은 테이블 생성 시 지정한 차원과 일치해야 합니다.
- 예: 테이블이 1024차원이면 `[1.0, 2.0, ..., 1024번째 값]`

### 3. JSONL 형식 주의

- `/v1/data` 엔드포인트는 JSONL 형식을 사용합니다.
- 각 JSON 객체는 **한 줄에 하나씩** 작성되어야 합니다.

**잘못된 형식:**

```json
{
  "id": "1",
  "text": "hello"
}
```

**올바른 형식:**

```json
{"id": "1", "text": "hello"}
{"id": "2", "text": "world"}
```

### 4. 메타데이터 형식

- `metadata` 필드는 JSON 문자열로 저장됩니다.
- 이중 따옴표를 이스케이프해야 합니다.

**올바른 예시:**

```json
{
  "id": "1",
  "metadata": "{\"file_name\": \"abc.pdf\", \"page\": 1}"
}
```

### 5. 필터 조건 작성

- SQL WHERE 절 문법을 따릅니다.
- 문자열 비교 시 작은따옴표(`'`)를 사용합니다.

**올바른 예시:**

```json
{
  "filter": "id = '100' AND category = 'tech'"
}
```

---

## 에러 코드

| 코드 | 설명 | 해결 방법 |
| --- | --- | --- |
| 400 | Bad Request - 잘못된 요청 | 요청 본문의 형식과 필수 필드를 확인하세요 |
| 400001 | Bad Request - 특정 오류 | 에러 메시지의 세부 내용을 확인하세요 |
| 500 | Internal Server Error | 서버 로그를 확인하거나 관리자에게 문의하세요 |
| 500001 | Internal error | 서버 내부 오류입니다. 관리자에게 문의하세요 |

**에러 응답 예시:**

```json
{
  "code": 400,
  "success": false,
  "data": null,
  "exception": {
    "error_code": 400001,
    "error_message": "Bad Request: Invalid vector dimension. Expected 1024, got 512"
  }
}
```

---

## 성능 최적화 팁

### 1. 배치 삽입 활용

- 대량 데이터(parquet)는 `/v1/data/batch-insert`를 사용하세요.
- 여러 번 삽입하는 것보다 한 번에 배치로 삽입하는 것이 훨씬 빠릅니다.

### 2. 적절한 top_k 설정

- 필요한 만큼만 결과를 요청하세요.
- `top_k=100`보다 `top_k=10`이 훨씬 빠릅니다.

### 3. Projection 최소화

- 필요한 컬럼만 요청하세요.

```json
{
  "projection": "id, text"  // 모든 컬럼(*) 대신
}
```

### 4. 필터 활용

- 검색 전에 필터로 데이터를 줄이면 성능이 향상됩니다.

```json
{
  "filter": "category = 'tech' AND date > '2024-01-01'"
}
```

---

## 용어 사전

| 용어 | 설명 |
| --- | --- |
| **벡터(Vector)** | 데이터를 숫자 배열로 표현한 것 (예: [0.1, 0.2, 0.3]) |
| **임베딩(Embedding)** | 텍스트를 벡터로 변환하는 과정 |
| **Dense 벡터** | 모든 차원에 값이 있는 고정 크기 벡터 |
| **HNSW** | Hierarchical Navigable Small World - 빠른 벡터 검색 알고리즘 |
| **Projection** | 조회할 컬럼 지정 (SQL의 SELECT 절) |
| **Filter** | 조건 필터링 (SQL의 WHERE 절) |
| **top_k** | 상위 k개 결과 반환 |
| **ef_search** | 검색 정확도 파라미터 (클수록 정확하지만 느림) |
| **Segment** | 데이터베이스가 데이터를 관리하는 단위 |
| **JSONL** | JSON Lines - 한 줄에 하나의 JSON 객체 |

---

## 문제 해결 가이드

### Q1: "Invalid vector dimension" 오류가 발생해요

**A:** 테이블의 벡터 차원과 삽입하는 벡터의 차원이 일치하는지 확인하세요.

```bash
# 테이블 스키마 확인
GET /v1/data/schema
```

### Q2: 검색 결과가 너무 느려요

**A:** 다음 방법을 시도해보세요:

1. `ef_search` 값을 낮추기 (예: 1000 → 100)
2. `top_k` 값을 줄이기 (예: 100 → 10)
3. `filter`로 검색 범위 좁히기
4. 인덱싱이 완료되었는지 확인 (`GET /v1/data/indexed-row-count`)

### Q3: 데이터 삽입이 실패해요

**A:** 체크리스트:

- [ ]  JSONL 형식이 올바른가요? (한 줄에 하나의 JSON)
- [ ]  벡터 차원이 일치하나요?
- [ ]  Primary Key가 중복되지 않나요?
- [ ]  메타데이터가 JSON 문자열 형식인가요?

### Q4: 임베딩 생성이 실패해요

**A:** 확인사항:

- [ ]  `input` 필드를 제공했나요?
- [ ]  인증 토큰이 유효한가요?
- [ ]  모델이 사용 가능한 상태인가요? (`GET /v1/inference/models`로 확인)

---

