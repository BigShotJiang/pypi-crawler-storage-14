# LangChain VectorStore SDK - 아키텍처 설계

## 1. 패키지 구조

```
langchain-seahorse/
├── README.md
├── pyproject.toml
├── setup.py
├── LICENSE
├── .gitignore
│
├── langchain_seahorse/
│   ├── __init__.py
│   ├── vectorstores.py      # SeahorseVectorStore 클래스
│   ├── embeddings.py        # SeahorseEmbeddings 클래스
│   ├── client.py            # Low-level API 클라이언트
│   ├── filters.py           # 필터 변환 로직
│   ├── utils.py             # 유틸리티 함수
│   └── exceptions.py        # 커스텀 예외 클래스
│
├── tests/
│   ├── __init__.py
│   ├── conftest.py
│   ├── test_vectorstore.py
│   ├── test_embeddings.py
│   ├── test_client.py
│   ├── test_filters.py
│   └── integration/
│       ├── test_add_texts.py
│       ├── test_search.py
│       └── test_delete.py
│
├── examples/
│   ├── basic_usage.py
│   ├── rag_pipeline.py
│   ├── metadata_filtering.py
│   ├── async_usage.py
│   └── custom_embeddings.py
│
└── docs/
    ├── quickstart.md
    ├── api_reference.md
    └── advanced.md
```

---

## 2. 클래스 다이어그램

```
┌─────────────────────────────────────┐
│  langchain_core.vectorstores        │
│  BaseVectorStore                    │
└───────────────┬─────────────────────┘
                │
                │ inherits
                ▼
┌─────────────────────────────────────┐
│  SeahorseVectorStore                │
├─────────────────────────────────────┤
│ - _client: SeahorseClient           │
│ - _embedding: Embeddings            │
│ - _base_url: str                    │
│ - _api_key: str                     │
│ - _table_name: str                  │
│ - _use_builtin_embedding: bool      │
├─────────────────────────────────────┤
│ + add_texts(...)                    │
│ + similarity_search(...)            │
│ + similarity_search_with_score(...) │
│ + similarity_search_by_vector(...)  │
│ + delete(...)                       │
│ + as_retriever(...)                 │
│ + aadd_texts(...)                   │
│ + asimilarity_search(...)           │
└───────────────┬─────────────────────┘
                │
                │ uses
                ▼
┌─────────────────────────────────────┐
│  SeahorseClient                     │
├─────────────────────────────────────┤
│ - _base_url: str                    │
│ - _api_key: str                     │
│ - _session: httpx.Client            │
│ - _async_session: httpx.AsyncClient │
├─────────────────────────────────────┤
│ + insert_with_embedding(...)        │
│ + semantic_search(...)              │
│ + vector_search(...)                │
│ + delete_data(...)                  │
│ + get_embedding(...)                │
│ + get_table_schema(...)             │
│ + _request(...)                     │
│ + _unwrap_coral_response(...)       │
└─────────────────────────────────────┘

┌─────────────────────────────────────┐
│  SeahorseEmbeddings                 │
│  (langchain_core.embeddings.        │
│   Embeddings)                       │
├─────────────────────────────────────┤
│ - _client: SeahorseClient           │
├─────────────────────────────────────┤
│ + embed_documents(...)              │
│ + embed_query(...)                  │
│ + aembed_documents(...)             │
│ + aembed_query(...)                 │
└─────────────────────────────────────┘
```

---

## 3. 주요 클래스 설계

### 3.1 SeahorseVectorStore

```python
from typing import Any, Dict, Iterable, List, Optional, Tuple
from langchain_core.vectorstores import VectorStore
from langchain_core.documents import Document
from langchain_core.embeddings import Embeddings


class SeahorseVectorStore(VectorStore):
    """Seahorse API Gateway VectorStore implementation.
    
    이 클래스는 LangChain의 VectorStore 인터페이스를 구현하여
    Seahorse API Gateway를 벡터 저장소로 사용할 수 있게 합니다.
    
    Examples:
        >>> from langchain_seahorse import SeahorseVectorStore
        >>> 
        >>> # Seahorse 내장 임베딩 사용
        >>> # Dev URL: http://9683ea76604642ac8dd8ac05934b05b8.api.seahorse.dnotitia.com
        >>> # Prod URL: https://455fe13765664952bed80e7c22dd3436.api.seahorse.dnotitia.ai
        >>> vectorstore = SeahorseVectorStore(
        ...     api_key="your-api-key",
        ...     base_url="https://{table-uuid}.api.seahorse.dnotitia.ai"
        ... )
        >>> 
        >>> # 외부 임베딩 사용
        >>> from langchain_openai import OpenAIEmbeddings
        >>> vectorstore = SeahorseVectorStore(
        ...     api_key="your-api-key",
        ...     base_url="https://{table-uuid}.api.seahorse.dnotitia.ai",
        ...     embedding=OpenAIEmbeddings()
        ... )
    """
    
    def __init__(
        self,
        api_key: str,
        base_url: str,
        embedding: Optional[Embeddings] = None,
        use_builtin_embedding: bool = True,
        index_name: str = "embedding",
        **kwargs: Any,
    ) -> None:
        """Initialize SeahorseVectorStore.
        
        Args:
            api_key: Seahorse API key
            base_url: Seahorse API base URL (테이블별 고유 URL)
            embedding: LangChain Embeddings instance (optional)
            use_builtin_embedding: Seahorse 내장 임베딩 사용 여부
            index_name: 벡터 컬럼명 (기본: "embedding")
            **kwargs: Additional arguments
        """
        self._api_key = api_key
        self._base_url = base_url
        self._index_name = index_name
        self._use_builtin_embedding = use_builtin_embedding
        
        # SeahorseClient 초기화
        self._client = SeahorseClient(base_url=base_url, api_key=api_key)
        
        # Embedding 설정
        if use_builtin_embedding:
            if embedding is not None:
                raise ValueError(
                    "Cannot specify both use_builtin_embedding=True and embedding"
                )
            self._embedding = None
        else:
            if embedding is None:
                raise ValueError(
                    "Must provide embedding when use_builtin_embedding=False"
                )
            self._embedding = embedding
    
    def add_texts(
        self,
        texts: Iterable[str],
        metadatas: Optional[List[Dict[str, Any]]] = None,
        **kwargs: Any,
    ) -> List[str]:
        """텍스트를 벡터 저장소에 추가.
        
        Args:
            texts: 추가할 텍스트 목록
            metadatas: 각 텍스트의 메타데이터 (optional)
            **kwargs: 추가 인자
        
        Returns:
            생성된 document ID 목록
        """
        texts_list = list(texts)
        
        if metadatas is None:
            metadatas = [{} for _ in texts_list]
        elif len(metadatas) != len(texts_list):
            raise ValueError("metadatas must have same length as texts")
        
        if self._use_builtin_embedding:
            # Seahorse 내장 임베딩 사용
            return self._add_texts_with_builtin_embedding(texts_list, metadatas)
        else:
            # 외부 임베딩 사용
            return self._add_texts_with_external_embedding(texts_list, metadatas)
    
    def similarity_search(
        self,
        query: str,
        k: int = 4,
        filter: Optional[Dict[str, Any]] = None,
        **kwargs: Any,
    ) -> List[Document]:
        """자연어 쿼리로 유사 문서 검색.
        
        Args:
            query: 검색 쿼리 (자연어)
            k: 반환할 문서 수
            filter: 메타데이터 필터 (optional)
            **kwargs: 추가 인자 (ef_search 등)
        
        Returns:
            유사한 Document 목록
        """
        docs_and_scores = self.similarity_search_with_score(
            query, k=k, filter=filter, **kwargs
        )
        return [doc for doc, _ in docs_and_scores]
    
    def similarity_search_with_score(
        self,
        query: str,
        k: int = 4,
        filter: Optional[Dict[str, Any]] = None,
        **kwargs: Any,
    ) -> List[Tuple[Document, float]]:
        """유사도 점수와 함께 문서 검색.
        
        Args:
            query: 검색 쿼리
            k: 반환할 문서 수
            filter: 메타데이터 필터
            **kwargs: 추가 인자
        
        Returns:
            (Document, score) 튜플 목록
        """
        # 필터를 SQL WHERE 절로 변환
        filter_sql = self._convert_filter_to_sql(filter) if filter else None
        
        # ef_search 파라미터 추출
        ef_search = kwargs.get("ef_search", k * 2)
        
        # Semantic search API 호출
        results = self._client.semantic_search(
            query=query,
            top_k=k,
            index_name=self._index_name,
            ef_search=ef_search,
            filter_sql=filter_sql,
        )
        
        # 결과를 Document로 변환
        documents = []
        for item in results:
            doc = Document(
                page_content=item["text"],
                metadata=json.loads(item["metadata"]),
            )
            score = item["distance"]
            documents.append((doc, score))
        
        return documents
    
    def similarity_search_by_vector(
        self,
        embedding: List[float],
        k: int = 4,
        filter: Optional[Dict[str, Any]] = None,
        **kwargs: Any,
    ) -> List[Document]:
        """벡터로 직접 검색.
        
        Args:
            embedding: 검색할 벡터
            k: 반환할 문서 수
            filter: 메타데이터 필터
            **kwargs: 추가 인자
        
        Returns:
            유사한 Document 목록
        """
        # 구현...
        pass
    
    def delete(
        self,
        ids: Optional[List[str]] = None,
        **kwargs: Any,
    ) -> Optional[bool]:
        """문서 삭제.
        
        Args:
            ids: 삭제할 document ID 목록
            **kwargs: 추가 인자
        
        Returns:
            성공 여부
        """
        if not ids:
            return None
        
        # SQL IN 절 생성
        ids_quoted = [f"'{id}'" for id in ids]
        delete_condition = f"id IN ({', '.join(ids_quoted)})"
        
        # Delete API 호출
        result = self._client.delete_data(delete_condition=delete_condition)
        
        return result["deleted_row_count"] > 0
    
    def as_retriever(self, **kwargs: Any):
        """LangChain Retriever로 변환.
        
        Args:
            **kwargs: Retriever 설정
        
        Returns:
            VectorStoreRetriever instance
        """
        from langchain_core.retrievers import VectorStoreRetriever
        
        return VectorStoreRetriever(vectorstore=self, **kwargs)
    
    # 비동기 메서드
    async def aadd_texts(
        self,
        texts: Iterable[str],
        metadatas: Optional[List[Dict[str, Any]]] = None,
        **kwargs: Any,
    ) -> List[str]:
        """비동기 텍스트 추가."""
        # 구현...
        pass
    
    async def asimilarity_search(
        self,
        query: str,
        k: int = 4,
        **kwargs: Any,
    ) -> List[Document]:
        """비동기 검색."""
        # 구현...
        pass
    
    # Private 메서드
    def _add_texts_with_builtin_embedding(
        self,
        texts: List[str],
        metadatas: List[Dict[str, Any]],
    ) -> List[str]:
        """Seahorse 내장 임베딩으로 텍스트 추가."""
        # Primary Key 생성
        doc_ids = []
        data = []
        
        for i, (text, metadata) in enumerate(zip(texts, metadatas)):
            doc_id = self._generate_pk(text, chunk_id=0)
            doc_ids.append(doc_id)
            
            data.append({
                "id": doc_id,
                "text": text,
                "metadata": json.dumps(metadata, ensure_ascii=False),
            })
        
        # API 호출
        result = self._client.insert_with_embedding(
            data=data,
            embedding_source="text",
            embedding_target=self._index_name,
        )
        
        return doc_ids
    
    def _add_texts_with_external_embedding(
        self,
        texts: List[str],
        metadatas: List[Dict[str, Any]],
    ) -> List[str]:
        """외부 임베딩으로 텍스트 추가."""
        # 임베딩 생성
        embeddings = self._embedding.embed_documents(texts)
        
        # Primary Key 생성 및 데이터 준비
        doc_ids = []
        jsonl_lines = []
        
        for text, metadata, embedding in zip(texts, metadatas, embeddings):
            doc_id = self._generate_pk(text, chunk_id=0)
            doc_ids.append(doc_id)
            
            line = {
                "id": doc_id,
                "text": text,
                "metadata": json.dumps(metadata, ensure_ascii=False),
                self._index_name: embedding,
            }
            jsonl_lines.append(json.dumps(line, ensure_ascii=False))
        
        # JSONL 형식으로 삽입
        jsonl_data = "\n".join(jsonl_lines)
        result = self._client.insert_jsonl(jsonl_data)
        
        return doc_ids
    
    def _generate_pk(self, content: str, chunk_id: int = 0) -> str:
        """Primary Key 생성."""
        import hashlib
        doc_id = hashlib.sha512(content.encode()).hexdigest()
        return f"{doc_id}\x1e{chunk_id}"
    
    def _convert_filter_to_sql(
        self,
        filter: Dict[str, Any]
    ) -> str:
        """LangChain 필터를 SQL WHERE 절로 변환."""
        from .filters import convert_filter_to_sql
        return convert_filter_to_sql(filter)
    
    @classmethod
    def from_texts(
        cls,
        texts: List[str],
        embedding: Optional[Embeddings] = None,
        metadatas: Optional[List[Dict]] = None,
        **kwargs: Any,
    ):
        """텍스트 목록으로부터 VectorStore 생성."""
        vectorstore = cls(embedding=embedding, **kwargs)
        vectorstore.add_texts(texts, metadatas=metadatas)
        return vectorstore
```

### 3.2 SeahorseClient

```python
import httpx
from typing import Any, Dict, List, Optional
import json


class SeahorseClient:
    """Low-level Seahorse API client.
    
    CoralResponse 언래핑, 에러 처리, 재시도 로직 등을 담당합니다.
    """
    
    def __init__(
        self,
        base_url: str,
        api_key: str,
        timeout: float = 30.0,
        max_retries: int = 3,
    ) -> None:
        """Initialize client.
        
        Args:
            base_url: API base URL
            api_key: API key
            timeout: Request timeout (seconds)
            max_retries: Maximum retry attempts
        """
        self._base_url = base_url.rstrip("/")
        self._api_key = api_key
        self._timeout = timeout
        self._max_retries = max_retries
        
        # HTTP 클라이언트 설정
        headers = {
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
        }
        
        self._session = httpx.Client(
            headers=headers,
            timeout=timeout,
            follow_redirects=True,
        )
        
        self._async_session = httpx.AsyncClient(
            headers=headers,
            timeout=timeout,
            follow_redirects=True,
        )
    
    def __del__(self):
        """Clean up resources."""
        self._session.close()
    
    def insert_with_embedding(
        self,
        data: List[Dict[str, Any]],
        embedding_source: str = "text",
        embedding_target: str = "embedding",
    ) -> Dict[str, Any]:
        """POST /v1/data/embedding"""
        payload = {
            "data": data,
            "embedding_source": embedding_source,
            "embedding_target": embedding_target,
        }
        
        response = self._request("POST", "/v1/data/embedding", json=payload)
        return self._unwrap_coral_response(response)
    
    def semantic_search(
        self,
        query: str,
        top_k: int,
        index_name: str,
        ef_search: Optional[int] = None,
        projection: Optional[str] = None,
        filter_sql: Optional[str] = None,
    ) -> List[Dict[str, Any]]:
        """POST /v1/data/semantic-search"""
        payload = {
            "query": query,
            "top_k": top_k,
            "index_name": index_name,
        }
        
        if ef_search is not None:
            payload["ef_search"] = ef_search
        if projection is not None:
            payload["projection"] = projection
        if filter_sql is not None:
            payload["filter"] = filter_sql
        
        response = self._request("POST", "/v1/data/semantic-search", json=payload)
        result = self._unwrap_coral_response(response)
        
        # 첫 번째 resultset의 data 반환
        return result["data"][0]
    
    def vector_search(
        self,
        index_name: str,
        query_vectors: List[List[float]],
        top_k: int,
        ef_search: Optional[int] = None,
        projection: Optional[str] = None,
        filter_sql: Optional[str] = None,
    ) -> List[List[Dict[str, Any]]]:
        """POST /v1/data/indexes/{index_name}/vector-search"""
        payload = {
            "query_vectors": {"dense": query_vectors},
            "top_k": top_k,
        }
        
        if ef_search is not None:
            payload["ef_search"] = ef_search
        if projection is not None:
            payload["projection"] = projection
        if filter_sql is not None:
            payload["filter"] = filter_sql
        
        path = f"/v1/data/indexes/{index_name}/vector-search"
        response = self._request("POST", path, json=payload)
        result = self._unwrap_coral_response(response)
        
        return result["data"]
    
    def delete_data(
        self,
        delete_condition: str,
    ) -> Dict[str, Any]:
        """POST /v1/data/delete"""
        payload = {"delete_condition": delete_condition}
        
        response = self._request("POST", "/v1/data/delete", json=payload)
        return self._unwrap_coral_response(response)
    
    def get_embedding(
        self,
        text: str,
    ) -> List[float]:
        """POST /v1/inference/embedding (CoralResponse 없음!)"""
        payload = {"input": text}
        
        response = self._request("POST", "/v1/inference/embedding", json=payload)
        
        # Inference API는 CoralResponse 사용 안 함
        result = response.json()
        return result["data"][0]["embedding"]
    
    def get_table_schema(self) -> Dict[str, Any]:
        """GET /v1/data/schema"""
        response = self._request("GET", "/v1/data/schema")
        return self._unwrap_coral_response(response)
    
    def insert_jsonl(
        self,
        jsonl_data: str,
        batch_insert_size: int = 1024,
    ) -> Dict[str, Any]:
        """POST /v1/data (JSONL 형식)"""
        headers = {"Content-Type": "text/plain"}
        params = {"batch_insert_size": batch_insert_size}
        
        response = self._request(
            "POST",
            "/v1/data",
            data=jsonl_data,
            headers=headers,
            params=params,
        )
        return self._unwrap_coral_response(response)
    
    def _request(
        self,
        method: str,
        path: str,
        **kwargs: Any,
    ) -> httpx.Response:
        """HTTP 요청 (재시도 로직 포함)."""
        url = f"{self._base_url}{path}"
        
        last_exception = None
        for attempt in range(self._max_retries):
            try:
                response = self._session.request(method, url, **kwargs)
                
                # 재시도 가능한 에러인지 확인
                if response.status_code in [408, 429, 500, 502, 503, 504]:
                    if attempt < self._max_retries - 1:
                        # 지수 백오프
                        import time
                        delay = 2 ** attempt
                        time.sleep(delay)
                        continue
                
                response.raise_for_status()
                return response
                
            except httpx.HTTPStatusError as e:
                if e.response.status_code not in [408, 429, 500, 502, 503, 504]:
                    # 재시도 불가능한 에러
                    raise
                last_exception = e
            except httpx.RequestError as e:
                last_exception = e
        
        # 모든 재시도 실패
        raise last_exception
    
    def _unwrap_coral_response(self, response: httpx.Response) -> Any:
        """CoralResponse 언래핑."""
        data = response.json()
        
        if not data.get("success"):
            # 에러 응답
            exception = data.get("exception", {})
            error_code = exception.get("error_code")
            error_message = exception.get("error_message", "Unknown error")
            
            raise SeahorseAPIError(
                status_code=data.get("code", response.status_code),
                error_code=error_code,
                error_message=error_message,
            )
        
        return data.get("data")
```

### 3.3 SeahorseEmbeddings

```python
from typing import List
from langchain_core.embeddings import Embeddings


class SeahorseEmbeddings(Embeddings):
    """Seahorse Inference API를 LangChain Embeddings로 래핑.
    
    Examples:
        >>> from langchain_seahorse import SeahorseEmbeddings
        >>> # Dev URL: http://9683ea76604642ac8dd8ac05934b05b8.api.seahorse.dnotitia.com
        >>> # Prod URL: https://455fe13765664952bed80e7c22dd3436.api.seahorse.dnotitia.ai
        >>> 
        >>> embeddings = SeahorseEmbeddings(
        ...     api_key="your-api-key",
        ...     base_url="https://{table-uuid}.api.seahorse.dnotitia.ai"
        ... )
        >>> 
        >>> vectors = embeddings.embed_documents(["hello", "world"])
    """
    
    def __init__(
        self,
        api_key: str,
        base_url: str,
    ) -> None:
        """Initialize embeddings.
        
        Args:
            api_key: Seahorse API key
            base_url: Seahorse API base URL
        """
        self._client = SeahorseClient(base_url=base_url, api_key=api_key)
    
    def embed_documents(self, texts: List[str]) -> List[List[float]]:
        """문서 리스트 임베딩."""
        embeddings = []
        for text in texts:
            embedding = self._client.get_embedding(text)
            embeddings.append(embedding)
        return embeddings
    
    def embed_query(self, text: str) -> List[float]:
        """단일 쿼리 임베딩."""
        return self._client.get_embedding(text)
    
    async def aembed_documents(self, texts: List[str]) -> List[List[float]]:
        """비동기 문서 임베딩."""
        # 구현...
        pass
    
    async def aembed_query(self, text: str) -> List[float]:
        """비동기 쿼리 임베딩."""
        # 구현...
        pass
```

---

## 4. 에러 처리 아키텍처

```python
# exceptions.py

class SeahorseException(Exception):
    """Base exception for Seahorse SDK."""
    pass


class SeahorseAPIError(SeahorseException):
    """API 호출 실패."""
    
    def __init__(
        self,
        status_code: int,
        error_code: Optional[int] = None,
        error_message: str = "Unknown error",
    ):
        self.status_code = status_code
        self.error_code = error_code
        self.error_message = error_message
        super().__init__(f"[{status_code}] {error_message} (code: {error_code})")


class SeahorseAuthenticationError(SeahorseAPIError):
    """인증 실패 (401, 403)."""
    pass


class SeahorseRateLimitError(SeahorseAPIError):
    """Rate limit 초과 (429)."""
    pass


class SeahorseValidationError(SeahorseException):
    """입력 검증 실패."""
    pass


class SeahorseDimensionMismatchError(SeahorseValidationError):
    """벡터 차원 불일치."""
    
    def __init__(self, expected: int, actual: int):
        self.expected = expected
        self.actual = actual
        super().__init__(
            f"Vector dimension mismatch: expected {expected}, got {actual}"
        )
```

---

## 5. 필터 변환 로직

```python
# filters.py

from typing import Any, Dict


def convert_filter_to_sql(filter: Dict[str, Any]) -> str:
    """LangChain 필터를 SQL WHERE 절로 변환.
    
    ⚠️ 중요: metadata 컬럼은 String 타입이며 JSONB 연산자 미지원
    - LIKE 패턴을 사용하여 JSON 문자열 매칭
    - 현재는 equal 연산만 지원
    
    Args:
        filter: LangChain 스타일 필터
        
    Returns:
        SQL WHERE 절 문자열
        
    Examples:
        >>> convert_filter_to_sql({"source": "doc.pdf"})
        'metadata LIKE \'%"source": "doc.pdf"%\''
        
        >>> convert_filter_to_sql({"page": 10})
        'metadata LIKE \'%"page": 10%\''
    """
    conditions = []
    
    for key, value in filter.items():
        if isinstance(value, dict):
            # 연산자 포함
            condition = _convert_operator(key, value)
        else:
            # 단순 동등 비교
            condition = _convert_equality(key, value)
        
        conditions.append(condition)
    
    return " AND ".join(conditions)


def _convert_equality(key: str, value: Any) -> str:
    """단순 동등 비교 (LIKE 패턴 사용)."""
    # metadata는 String 타입이므로 LIKE 패턴 사용
    if isinstance(value, str):
        # JSON 형식으로 LIKE 패턴 생성
        # "key": "value" 형태로 검색
        escaped_value = value.replace("'", "\\'")
        return f"metadata LIKE '%\"{key}\": \"{escaped_value}\"%'"
    elif isinstance(value, (int, float)):
        # 숫자는 따옴표 없이
        return f"metadata LIKE '%\"{key}\": {value}%'"
    elif isinstance(value, bool):
        # bool은 true/false (소문자)
        bool_str = str(value).lower()
        return f"metadata LIKE '%\"{key}\": {bool_str}%'"
    else:
        raise ValueError(f"Unsupported value type: {type(value)}")


def _convert_operator(key: str, op_dict: Dict[str, Any]) -> str:
    """연산자 변환.
    
    ⚠️ 현재는 equal 연산만 지원 (LIKE 패턴)
    다른 연산자($gt, $lt 등)는 metadata가 String이므로 정확한 비교 불가능
    """
    op, value = list(op_dict.items())[0]
    
    if op == "$eq":
        return _convert_equality(key, value)
    else:
        # 다른 연산자는 현재 미지원
        raise ValueError(
            f"Operator '{op}' is not supported. "
            f"metadata column is String type and only equality check is supported."
        )
```

---

## 6. 배치 처리 전략

```python
# utils.py

from typing import Any, Dict, Iterable, List


# 배치 크기 설정 (확인 완료)
DEFAULT_BATCH_SIZE = 1024  # API 기본값과 동일
SMALL_BATCH_SIZE = 100     # 작은 배치용
MAX_JSON_SIZE = 20 * 1024 * 1024  # 20MB (JSON 페이로드 제한)


def batch_texts(
    texts: Iterable[str],
    metadatas: List[Dict[str, Any]],
    batch_size: int = DEFAULT_BATCH_SIZE,
):
    """텍스트를 배치로 나누기.
    
    Args:
        texts: 분할할 텍스트 목록
        metadatas: 메타데이터 목록
        batch_size: 배치당 항목 수 (기본: 1024)
        
    Yields:
        (텍스트 배치, 메타데이터 배치) 튜플
    """
    texts_list = list(texts)
    
    for i in range(0, len(texts_list), batch_size):
        yield (
            texts_list[i:i + batch_size],
            metadatas[i:i + batch_size] if metadatas else None,
        )
```

---

## 7. 의존성 관리

### pyproject.toml (uv 사용)

```toml
[project]
name = "langchain-seahorse"
version = "0.1.0"
description = "LangChain VectorStore integration for Seahorse API Gateway"
authors = [{name = "Your Name", email = "your.email@example.com"}]
readme = "README.md"
requires-python = ">=3.8"
license = {text = "MIT"}

dependencies = [
    "langchain-core>=0.2.0",
    "httpx>=0.27.0",
    "pydantic>=2.0.0",
]

[project.optional-dependencies]
dev = [
    "pytest>=8.0.0",
    "pytest-asyncio>=0.23.0",
    "pytest-mock>=3.12.0",
    "black>=24.0.0",
    "mypy>=1.8.0",
    "ruff>=0.3.0",
]

[build-system]
requires = ["hatchling"]
build-backend = "hatchling.build"

[tool.uv]
dev-dependencies = [
    "pytest>=8.0.0",
    "pytest-asyncio>=0.23.0",
    "pytest-mock>=3.12.0",
    "black>=24.0.0",
    "mypy>=1.8.0",
    "ruff>=0.3.0",
]
```

---

## 8. 개발 단계별 우선순위

### Phase 1: MVP (4주)

**목표**: 기본 VectorStore 동작

```python
# 구현할 메서드
- SeahorseClient.__init__()
- SeahorseClient.insert_with_embedding()
- SeahorseClient.semantic_search()
- SeahorseClient._request()
- SeahorseClient._unwrap_coral_response()

- SeahorseVectorStore.__init__()
- SeahorseVectorStore.add_texts()
- SeahorseVectorStore.similarity_search()
- SeahorseVectorStore.from_texts()

- 기본 에러 처리
- Primary Key 생성 로직
```

### Phase 2: Full Implementation (4주) ✅ 완료

**목표**: LangChain 표준 완전 구현

```python
# 구현 완료
✅ SeahorseVectorStore.similarity_search_with_score()
✅ SeahorseVectorStore.similarity_search_by_vector()
✅ SeahorseVectorStore.delete()
✅ SeahorseVectorStore.as_retriever()

✅ 필터 변환 로직 (filters.py)
❌ SeahorseEmbeddings 클래스 (Inference API 미지원)
✅ 비동기 메서드 (8개 async 메서드 구현)
   - aadd_texts, asimilarity_search, asimilarity_search_with_score
   - asimilarity_search_by_vector, asimilarity_search_by_vector_with_score
   - adelete
```

### Phase 3: Advanced (2주)

**목표**: 최적화 및 추가 기능

```python
# 추가 기능
- 배치 최적화 (대량 데이터 처리)
- 외부 Embeddings 지원 완성
- 성능 튜닝 및 최적화
- 상세 문서 및 예제 코드

# 미지원 기능 (확인 완료)
- MMR 검색: API 미지원
- Hybrid/Sparse 검색: 다음 버전 예정
- 세그먼트 통계: deprecated 예정
```

---

## 9. 테스트 환경 설정

### 9.1 환경 정보

✅ **개발 환경 준비 완료**

**Production 환경:**
- Base URL: `https://455fe13765664952bed80e7c22dd3436.api.seahorse.dnotitia.ai`
- API Key: `.env` 파일 참고
- 용도: 프로덕션 테스트 및 최종 검증

**Development 환경:**
- Base URL: `http://9683ea76604642ac8dd8ac05934b05b8.api.seahorse.dnotitia.com`
- API Key: `.env` 파일 참고
- 용도: 개발 및 통합 테스트

### 9.2 테이블 스키마

테스트용 테이블이 생성되어 있습니다 (상세: `docs/api/table-schema.json`):

```json
{
  "fields": [
    {
      "name": "id",
      "data_type": "LargeUtf8",
      "nullable": false,
      "metadata": {"primary_key": "true"}
    },
    {
      "name": "metadata",
      "data_type": "LargeUtf8",
      "nullable": false
    },
    {
      "name": "text",
      "data_type": "LargeUtf8",
      "nullable": false
    },
    {
      "name": "embedding",
      "data_type": {
        "FixedSizeList": [
          {"data_type": "Float32", "name": "item"},
          1024
        ]
      },
      "nullable": false
    }
  ],
  "metadata": {
    "active_set_size_limit": "50000",
    "index_info": "[{\"column_id\":\"3\",\"index_type\":\"hnsw\",\"parameters\":{\"M\":\"16\",\"ef_construction\":\"128\",\"space\":\"ipspace\"}}]"
  }
}
```

**HNSW 인덱스 설정:**
- M: 16
- ef_construction: 128
- space: ipspace (내적 유사도)
- active_set_size_limit: 50000

### 9.3 개발 시작 준비사항

- [x] API 환경 정보 확인
- [x] API Keys 발급 완료
- [x] 테스트 테이블 생성 완료
- [x] 테이블 스키마 확인
- [x] `.env` 파일 설정 완료
- [ ] Integration tests 작성
- [ ] 실제 API 호출 테스트

이제 바로 개발을 시작할 수 있습니다! 🚀

