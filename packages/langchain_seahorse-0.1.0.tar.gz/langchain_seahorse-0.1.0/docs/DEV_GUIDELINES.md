# 개발 가이드라인

## 1. 개발 환경 설정

### 1.1 필수 소프트웨어

- Python 3.8 - 3.12
- uv (패키지 관리)
- Git

### 1.2 프로젝트 초기화

```bash
# uv 설치 (없는 경우)
curl -LsSf https://astral.sh/uv/install.sh | sh

# 프로젝트 생성
uv init langchain-seahorse
cd langchain-seahorse

# 의존성 추가
uv add langchain-core httpx pydantic

# 개발 의존성 추가
uv add --dev pytest pytest-asyncio pytest-mock black mypy ruff

# 가상환경 활성화 (uv가 자동으로 관리)
source .venv/bin/activate
```

### 1.3 환경 변수 설정

`.env` 파일 생성 (이미 생성됨):

```bash
# Seahorse API 설정
# Production 환경
SEAHORSE_API_KEY=your-prod-api-key
SEAHORSE_BASE_URL=https://455fe13765664952bed80e7c22dd3436.api.seahorse.dnotitia.ai

# Development/Local 환경
SEAHORSE_DEV_API_KEY=your-dev-api-key
SEAHORSE_DEV_BASE_URL=http://9683ea76604642ac8dd8ac05934b05b8.api.seahorse.dnotitia.com

# 테스트 설정 (integration test용)
TEST_API_KEY=${SEAHORSE_DEV_API_KEY}
TEST_BASE_URL=${SEAHORSE_DEV_BASE_URL}
```

**참고:**
- Production URL: `https://455fe13765664952bed80e7c22dd3436.api.seahorse.dnotitia.ai`
- Development URL: `http://9683ea76604642ac8dd8ac05934b05b8.api.seahorse.dnotitia.com`
- 테이블 스키마: id, text, metadata, embedding (1024 차원)

**⚠️ 보안 주의:**
- `.env` 파일을 `.gitignore`에 추가
- API Key를 절대 코드에 하드코딩하지 말 것

---

## 2. 코딩 스타일

### 2.1 PEP 8 준수

- 라인 길이: 최대 88자 (Black 기본값)
- 들여쓰기: 공백 4칸
- 임포트 순서: 표준 라이브러리 → 서드파티 → 로컬

```python
# 좋은 예
import json
from typing import List, Optional

import httpx
from langchain_core.vectorstores import VectorStore

from langchain_seahorse.client import SeahorseClient
```

### 2.2 Type Hints 필수

모든 함수/메서드에 타입 힌트 작성:

```python
# 좋은 예
def add_texts(
    self,
    texts: List[str],
    metadatas: Optional[List[Dict[str, Any]]] = None,
    **kwargs: Any,
) -> List[str]:
    """텍스트 추가."""
    pass

# 나쁜 예
def add_texts(self, texts, metadatas=None, **kwargs):
    pass
```

### 2.3 Docstring (Google 스타일)

```python
def similarity_search(
    self,
    query: str,
    k: int = 4,
    filter: Optional[Dict[str, Any]] = None,
    **kwargs: Any,
) -> List[Document]:
    """자연어 쿼리로 유사 문서 검색.
    
    이 메서드는 Seahorse의 semantic-search API를 사용하여
    자연어 쿼리와 가장 유사한 문서를 검색합니다.
    
    Args:
        query: 검색 쿼리 (자연어)
        k: 반환할 문서 수 (기본: 4)
        filter: 메타데이터 필터 (optional)
            예: {"source": "doc.pdf", "page": {"$gt": 10}}
        **kwargs: 추가 인자
            ef_search (int): 검색 정확도 파라미터
    
    Returns:
        유사한 Document 객체 목록
    
    Raises:
        SeahorseAPIError: API 호출 실패 시
        SeahorseValidationError: 잘못된 파라미터 사용 시
    
    Examples:
        >>> vectorstore = SeahorseVectorStore(api_key="key", base_url="url")
        >>> docs = vectorstore.similarity_search("machine learning", k=5)
        >>> print(len(docs))
        5
    """
    pass
```

### 2.4 명명 규칙

- 클래스: `PascalCase` (예: `SeahorseVectorStore`)
- 함수/메서드: `snake_case` (예: `add_texts`)
- 상수: `UPPER_SNAKE_CASE` (예: `MAX_RETRIES`)
- Private 멤버: `_leading_underscore` (예: `_client`)

---

## 3. 코드 품질 도구

### 3.1 Black (코드 포매터)

```bash
# 실행
poetry run black langchain_seahorse/

# pyproject.toml 설정
[tool.black]
line-length = 88
target-version = ['py38', 'py39', 'py310', 'py311', 'py312']
include = '\.pyi?$'
```

### 3.2 Ruff (린터)

```bash
# 실행
poetry run ruff check langchain_seahorse/

# pyproject.toml 설정
[tool.ruff]
line-length = 88
target-version = "py38"

[tool.ruff.lint]
select = [
    "E",  # pycodestyle errors
    "W",  # pycodestyle warnings
    "F",  # pyflakes
    "I",  # isort
    "B",  # flake8-bugbear
    "C4", # flake8-comprehensions
]
ignore = [
    "E501",  # line too long (handled by black)
]
```

### 3.3 Mypy (타입 체커)

```bash
# 실행
poetry run mypy langchain_seahorse/

# pyproject.toml 설정
[tool.mypy]
python_version = "3.8"
strict = true
warn_return_any = true
warn_unused_configs = true
disallow_untyped_defs = true
```

### 3.4 Pre-commit Hook

`.pre-commit-config.yaml` 파일 생성:

```yaml
repos:
  - repo: https://github.com/psf/black
    rev: 24.0.0
    hooks:
      - id: black

  - repo: https://github.com/charliermarsh/ruff-pre-commit
    rev: v0.3.0
    hooks:
      - id: ruff
        args: [--fix]

  - repo: https://github.com/pre-commit/mirrors-mypy
    rev: v1.8.0
    hooks:
      - id: mypy
        additional_dependencies: [types-all]
```

설치 및 실행:

```bash
# Pre-commit 설치
uv add --dev pre-commit

# Git hook 설치
uv run pre-commit install

# 수동 실행
uv run pre-commit run --all-files
```

---

## 4. Git 워크플로우

### 4.1 브랜치 전략

**Main 브랜치:**
- `main`: 프로덕션 코드
- `develop`: 개발 브랜치

**Feature 브랜치:**
```bash
# 새 기능 개발
git checkout -b feature/add-async-support

# 버그 수정
git checkout -b fix/filter-conversion-bug

# 문서 작성
git checkout -b docs/update-readme
```

### 4.2 Commit Message

**Conventional Commits** 포맷 사용:

```
<type>(<scope>): <subject>

<body>

<footer>
```

**Type:**
- `feat`: 새 기능
- `fix`: 버그 수정
- `docs`: 문서 변경
- `style`: 코드 포맷팅 (기능 변경 없음)
- `refactor`: 리팩토링
- `test`: 테스트 추가/수정
- `chore`: 빌드, 설정 파일 변경

**예시:**

```bash
# 좋은 예
git commit -m "feat(vectorstore): add async similarity_search method"
git commit -m "fix(client): handle rate limit errors correctly"
git commit -m "docs(readme): add installation instructions"

# 나쁜 예
git commit -m "update code"
git commit -m "fixed bug"
```

### 4.3 Pull Request

**PR 제목:**
```
[Feature] Add async support for add_texts
[Fix] Fix metadata filter conversion
[Docs] Update API reference
```

**PR 설명 템플릿:**

```markdown
## 변경 사항
- 비동기 `aadd_texts()` 메서드 구현
- `httpx.AsyncClient` 통합

## 관련 이슈
Closes #123

## 테스트
- [x] Unit tests 추가
- [x] Integration tests 통과
- [ ] 수동 테스트 완료

## 체크리스트
- [x] 코드 스타일 준수 (Black, Ruff)
- [x] Type hints 추가
- [x] Docstring 작성
- [x] 테스트 작성
- [x] 문서 업데이트
```

---

## 5. 테스트 작성

### 5.1 테스트 구조

```
tests/
├── unit/
│   ├── test_vectorstore.py
│   ├── test_client.py
│   ├── test_filters.py
│   └── test_utils.py
├── integration/
│   ├── test_add_texts.py
│   ├── test_search.py
│   └── test_delete.py
└── conftest.py
```

### 5.2 Unit Test 예시

```python
# tests/unit/test_filters.py
import pytest
from langchain_seahorse.filters import convert_filter_to_sql


def test_simple_equality():
    """단순 동등 비교 테스트."""
    filter = {"source": "doc.pdf"}
    result = convert_filter_to_sql(filter)
    assert result == "metadata->>'source' = 'doc.pdf'"


def test_numeric_comparison():
    """숫자 비교 테스트."""
    filter = {"page": {"$gt": 10}}
    result = convert_filter_to_sql(filter)
    assert ">" in result
    assert "10" in result


def test_in_operator():
    """IN 연산자 테스트."""
    filter = {"category": {"$in": ["A", "B", "C"]}}
    result = convert_filter_to_sql(filter)
    assert "IN" in result
    assert "'A'" in result
```

### 5.3 Integration Test 예시

```python
# tests/integration/test_add_texts.py
import pytest
import os
from langchain_seahorse import SeahorseVectorStore


@pytest.fixture
def vectorstore():
    """VectorStore 인스턴스 생성."""
    api_key = os.getenv("TEST_API_KEY")
    base_url = os.getenv("TEST_BASE_URL")
    
    return SeahorseVectorStore(
        api_key=api_key,
        base_url=base_url,
    )


def test_add_texts_basic(vectorstore):
    """기본 텍스트 추가 테스트."""
    texts = ["hello", "world"]
    metadatas = [{"source": "test1"}, {"source": "test2"}]
    
    ids = vectorstore.add_texts(texts, metadatas=metadatas)
    
    assert len(ids) == 2
    assert all(isinstance(id, str) for id in ids)


def test_add_texts_with_search(vectorstore):
    """텍스트 추가 후 검색 테스트."""
    texts = ["machine learning is great", "deep learning is awesome"]
    vectorstore.add_texts(texts)
    
    # 검색
    results = vectorstore.similarity_search("learning", k=2)
    
    assert len(results) == 2
    assert any("learning" in doc.page_content.lower() for doc in results)
```

### 5.4 Mock 사용

```python
# tests/unit/test_vectorstore.py
import pytest
from unittest.mock import Mock, patch
from langchain_seahorse import SeahorseVectorStore


def test_add_texts_calls_client_correctly():
    """add_texts가 클라이언트를 올바르게 호출하는지 테스트."""
    with patch('langchain_seahorse.vectorstores.SeahorseClient') as MockClient:
        mock_client = MockClient.return_value
        mock_client.insert_with_embedding.return_value = {
            "inserted_row_count": 2
        }
        
        vectorstore = SeahorseVectorStore(
            api_key="test-key",
            base_url="http://test.com"
        )
        
        texts = ["hello", "world"]
        ids = vectorstore.add_texts(texts)
        
        # 클라이언트 호출 확인
        assert mock_client.insert_with_embedding.called
        call_args = mock_client.insert_with_embedding.call_args
        assert len(call_args[1]["data"]) == 2
```

### 5.5 테스트 실행

```bash
# 전체 테스트
uv run pytest

# 특정 파일
uv run pytest tests/unit/test_filters.py

# 특정 함수
uv run pytest tests/unit/test_filters.py::test_simple_equality

# 커버리지 포함
uv run pytest --cov=langchain_seahorse --cov-report=html

# 통합 테스트만
uv run pytest tests/integration/

# 마커 사용
uv run pytest -m "not slow"
```

---

## 6. 문서 작성

### 6.1 README.md 구조

```markdown
# LangChain Seahorse VectorStore

Seahorse API Gateway를 LangChain VectorStore로 사용할 수 있게 하는 Python SDK.

## 설치

```bash
pip install langchain-seahorse
```

## 빠른 시작

```python
from langchain_seahorse import SeahorseVectorStore

# 실제 환경:
# - Dev: http://9683ea76604642ac8dd8ac05934b05b8.api.seahorse.dnotitia.com
# - Prod: https://455fe13765664952bed80e7c22dd3436.api.seahorse.dnotitia.ai

vectorstore = SeahorseVectorStore(
    api_key="your-api-key",
    base_url="https://{table-uuid}.api.seahorse.dnotitia.ai"
)

# 문서 추가
vectorstore.add_texts(
    texts=["hello", "world"],
    metadatas=[{"source": "test"}]
)

# 검색
docs = vectorstore.similarity_search("greeting", k=5)
```

## 문서

- [API Reference](docs/api_reference.md)
- [Advanced Usage](docs/advanced.md)

## 라이선스

MIT
```

### 6.2 API Reference 자동 생성

```bash
# Sphinx 설치
uv add --dev sphinx sphinx-rtd-theme

# 문서 초기화
uv run sphinx-quickstart docs/

# API 문서 자동 생성
uv run sphinx-apidoc -o docs/source langchain_seahorse/

# 빌드
uv run sphinx-build -b html docs/source docs/build
```

---

## 7. 버전 관리

### 7.1 Semantic Versioning

**형식:** `MAJOR.MINOR.PATCH`

- **MAJOR**: Breaking changes
- **MINOR**: 새 기능 (하위 호환)
- **PATCH**: 버그 수정

**예시:**
- `0.1.0`: 첫 릴리스 (MVP)
- `0.2.0`: 비동기 지원 추가
- `0.2.1`: 필터 변환 버그 수정
- `1.0.0`: 안정 버전 (모든 LangChain 표준 구현)

### 7.2 CHANGELOG.md

```markdown
# Changelog

All notable changes to this project will be documented in this file.

## [Unreleased]

### Added
- 비동기 메서드 지원

### Fixed
- 메타데이터 필터 변환 버그 수정

## [0.1.0] - 2025-01-15

### Added
- 기본 VectorStore 구현
- `add_texts()` 메서드
- `similarity_search()` 메서드
- Seahorse 내장 임베딩 지원

### Changed
- None

### Deprecated
- None

### Removed
- None

### Fixed
- None

### Security
- None
```

---

## 8. CI/CD

### 8.1 GitHub Actions

`.github/workflows/test.yml`:

```yaml
name: Tests

on: [push, pull_request]

jobs:
  test:
    runs-on: ubuntu-latest
    strategy:
      matrix:
        python-version: ['3.8', '3.9', '3.10', '3.11', '3.12']
    
    steps:
      - uses: actions/checkout@v4
      
      - name: Set up Python
        uses: actions/setup-python@v4
        with:
          python-version: ${{ matrix.python-version }}
      
      - name: Install uv
        run: curl -LsSf https://astral.sh/uv/install.sh | sh
      
      - name: Install dependencies
        run: uv sync
      
      - name: Run linters
        run: |
          uv run black --check langchain_seahorse/
          uv run ruff check langchain_seahorse/
          uv run mypy langchain_seahorse/
      
      - name: Run tests
        run: uv run pytest --cov=langchain_seahorse
      
      - name: Upload coverage
        uses: codecov/codecov-action@v3
```

### 8.2 Release Workflow

`.github/workflows/release.yml`:

```yaml
name: Release

on:
  push:
    tags:
      - 'v*'

jobs:
  release:
    runs-on: ubuntu-latest
    
    steps:
      - uses: actions/checkout@v4
      
      - name: Set up Python
        uses: actions/setup-python@v4
        with:
          python-version: '3.11'
      
      - name: Install uv
        run: curl -LsSf https://astral.sh/uv/install.sh | sh
      
      - name: Build package
        run: uv build
      
      - name: Publish to PyPI
        env:
          UV_PUBLISH_TOKEN: ${{ secrets.PYPI_TOKEN }}
        run: uv publish
```

---

## 9. 개발 체크리스트

### Phase 1: MVP

- [ ] 프로젝트 초기화
- [ ] `SeahorseClient` 기본 구현
- [ ] `SeahorseVectorStore` 기본 메서드
  - [ ] `__init__()`
  - [ ] `add_texts()`
  - [ ] `similarity_search()`
- [ ] Primary Key 생성 로직
- [ ] CoralResponse 언래핑
- [ ] 기본 에러 처리
- [ ] Unit tests 작성
- [ ] README 작성

### Phase 2: Full Implementation

- [ ] 나머지 VectorStore 메서드
  - [ ] `similarity_search_with_score()`
  - [ ] `similarity_search_by_vector()`
  - [ ] `delete()`
  - [ ] `as_retriever()`
- [ ] 메타데이터 필터링
- [ ] `SeahorseEmbeddings` 구현
- [ ] 비동기 메서드
- [ ] Integration tests
- [ ] API 문서

### Phase 3: Advanced

- [ ] 배치 최적화 (대량 데이터 처리)
- [ ] 외부 Embeddings 완전 지원
- [ ] 성능 튜닝 및 최적화
- [ ] 상세 문서 작성
- [ ] 예제 코드 작성
- [ ] 사용자 가이드 작성

**미지원 기능 (확인 완료):**
- MMR 검색: API 미지원
- Hybrid/Sparse 검색: 다음 버전 예정
- 세그먼트 통계: deprecated 예정

---

## 10. 유용한 명령어 모음

```bash
# 개발 환경
uv sync              # 의존성 동기화
source .venv/bin/activate  # 가상환경 활성화

# 코드 품질
uv run black langchain_seahorse/
uv run ruff check langchain_seahorse/ --fix
uv run mypy langchain_seahorse/

# 테스트
uv run pytest
uv run pytest --cov=langchain_seahorse
uv run pytest -v -s  # verbose + print

# 문서
uv run sphinx-build -b html docs/source docs/build

# 빌드 및 배포
uv build
uv publish

# 버전 업데이트 (pyproject.toml에서 수동 변경)
# 0.1.0 -> 0.1.1 (patch)
# 0.1.0 -> 0.2.0 (minor)
# 0.1.0 -> 1.0.0 (major)
```

이 가이드라인을 따라 일관성 있는 고품질 코드를 작성하세요!

