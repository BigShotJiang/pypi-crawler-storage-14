"""Advanced metadata filtering example."""

import os

from seahorse_vector_store import SeahorseVectorStore


def main() -> None:
    """Demonstrate metadata filtering capabilities."""
    # Get credentials from environment
    api_key = os.environ.get("SEAHORSE_API_KEY")
    base_url = os.environ.get("SEAHORSE_BASE_URL")

    if not api_key or not base_url:
        print("Please set SEAHORSE_API_KEY and SEAHORSE_BASE_URL environment variables")
        return

    print("Demonstrating Metadata Filtering in Seahorse...")

    # Initialize vectorstore
    vectorstore = SeahorseVectorStore(
        api_key=api_key,
        base_url=base_url,
    )

    # Prepare documents with rich metadata
    documents = [
        {
            "text": "Python is a high-level programming language.",
            "metadata": {"language": "python", "difficulty": "beginner", "year": 2023},
        },
        {
            "text": "JavaScript is widely used for web development.",
            "metadata": {
                "language": "javascript",
                "difficulty": "beginner",
                "year": 2023,
            },
        },
        {
            "text": "Rust provides memory safety without garbage collection.",
            "metadata": {"language": "rust", "difficulty": "advanced", "year": 2023},
        },
        {
            "text": "Go is designed for concurrent programming.",
            "metadata": {"language": "go", "difficulty": "intermediate", "year": 2023},
        },
        {
            "text": "Python has extensive libraries for data science.",
            "metadata": {
                "language": "python",
                "difficulty": "intermediate",
                "year": 2023,
            },
        },
    ]

    texts = [doc["text"] for doc in documents]
    metadatas = [doc["metadata"] for doc in documents]

    # Add documents
    print("\n📝 Adding documents with metadata...")
    ids = vectorstore.add_texts(texts=texts, metadatas=metadatas)
    print(f"Added {len(ids)} documents")

    # Example 1: Filter by language
    print("\n" + "=" * 60)
    print("Example 1: Filter by Language (Python)")
    print("=" * 60)

    docs = vectorstore.similarity_search(
        query="programming language", k=10, filter={"language": "python"}
    )

    print(f"\nFound {len(docs)} Python documents:")
    for i, doc in enumerate(docs, 1):
        print(f"\n{i}. {doc.page_content}")
        print(f"   Metadata: {doc.metadata}")

    # Example 2: Filter by difficulty
    print("\n" + "=" * 60)
    print("Example 2: Filter by Difficulty (Beginner)")
    print("=" * 60)

    docs = vectorstore.similarity_search(
        query="programming", k=10, filter={"difficulty": "beginner"}
    )

    print(f"\nFound {len(docs)} beginner-level documents:")
    for i, doc in enumerate(docs, 1):
        print(f"\n{i}. {doc.page_content}")
        print(f"   Metadata: {doc.metadata}")

    # Example 3: Multiple filters (AND condition)
    print("\n" + "=" * 60)
    print("Example 3: Multiple Filters (Python + Intermediate)")
    print("=" * 60)

    docs = vectorstore.similarity_search(
        query="programming",
        k=10,
        filter={"language": "python", "difficulty": "intermediate"},
    )

    print(f"\nFound {len(docs)} documents matching both filters:")
    for i, doc in enumerate(docs, 1):
        print(f"\n{i}. {doc.page_content}")
        print(f"   Metadata: {doc.metadata}")

    # Example 4: Search with scores and filter
    print("\n" + "=" * 60)
    print("Example 4: Search with Scores + Filter")
    print("=" * 60)

    docs_and_scores = vectorstore.similarity_search_with_score(
        query="web development", k=10, filter={"language": "javascript"}
    )

    print(f"\nFound {len(docs_and_scores)} JavaScript documents:")
    for i, (doc, score) in enumerate(docs_and_scores, 1):
        print(f"\n{i}. Score: {score:.4f}")
        print(f"   Content: {doc.page_content}")
        print(f"   Metadata: {doc.metadata}")

    # Note: Current implementation
    print("\n" + "=" * 60)
    print("ℹ️  Important Notes")
    print("=" * 60)
    print(
        """
1. Seahorse metadata filtering uses LIKE pattern matching
2. Only equality checks are currently supported
3. Multiple filters are combined with AND logic
4. Metadata values must be flat (no nested objects)
    """
    )

    # Cleanup
    print("\n🧹 Cleaning up...")
    vectorstore.delete(ids=ids)
    print("✅ Metadata filtering example completed!")


if __name__ == "__main__":
    main()
