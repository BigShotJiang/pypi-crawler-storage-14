"""Example using external embeddings (OpenAI, Cohere, etc.)."""

import os

from seahorse_vector_store import SeahorseVectorStore


def main() -> None:
    """Example using external embeddings with Seahorse."""
    print("\n" + "=" * 60)
    print("Using External Embeddings with Seahorse")
    print("=" * 60)

    api_key = os.environ.get("SEAHORSE_API_KEY")
    base_url = os.environ.get("SEAHORSE_BASE_URL")
    openai_key = os.environ.get("OPENAI_API_KEY")

    if not api_key or not base_url:
        print("Please set SEAHORSE_API_KEY and SEAHORSE_BASE_URL")
        return

    if not openai_key:
        print("⚠️  OpenAI API key not found.")
        print("Set OPENAI_API_KEY to run this example.")
        return

    try:
        from langchain_openai import OpenAIEmbeddings
    except ImportError:
        print("⚠️  langchain-openai not installed.")
        print("Install it with: pip install langchain-openai")
        return

    print("\n📋 Important Notes:")
    print("-" * 60)
    print(
        """
⚠️  Seahorse Inference API Limitation:

The Seahorse Inference API (/v1/inference/*) cannot be called via
the table-specific base URL. Therefore, you must provide your own
external embeddings instance.

✅ Supported External Embeddings:
- OpenAI Embeddings
- Cohere Embeddings
- HuggingFace Embeddings
- Any LangChain-compatible Embeddings

⚠️  Vector Dimension Compatibility:
- Your embedding model's dimension must match your table's vector column
- Default Seahorse tables use 1024 dimensions
- Check your table schema: GET /v1/data/schema
    """
    )
    print("-" * 60)

    # Initialize vectorstore with OpenAI embeddings
    print("\n🔧 Initializing vectorstore with OpenAI embeddings...")
    vectorstore = SeahorseVectorStore(
        api_key=api_key,
        base_url=base_url,
        embedding=OpenAIEmbeddings(
            api_key=openai_key,
            model="text-embedding-3-small",  # 1536 dimensions
        ),
        use_builtin_embedding=False,
    )

    # Add documents
    texts = [
        "OpenAI's GPT models are transformer-based.",
        "BERT was introduced by Google in 2018.",
        "Claude is an AI assistant created by Anthropic.",
    ]

    metadatas = [
        {"model": "gpt", "org": "openai"},
        {"model": "bert", "org": "google"},
        {"model": "claude", "org": "anthropic"},
    ]

    print("\n📝 Adding documents with OpenAI embeddings...")
    try:
        ids = vectorstore.add_texts(texts=texts, metadatas=metadatas)
        print(f"✅ Added {len(ids)} documents")

        # Search
        print("\n🔍 Searching...")
        docs = vectorstore.similarity_search("transformer models", k=2)

        print(f"\n📄 Found {len(docs)} documents:")
        for i, doc in enumerate(docs, 1):
            print(f"\n{i}. {doc.page_content}")
            print(f"   Metadata: {doc.metadata}")

        # Cleanup
        print("\n🧹 Cleaning up...")
        vectorstore.delete(ids=ids)
        print("✅ Completed!")

    except Exception as e:
        print(f"\n❌ Error: {e}")
        print("\nPossible causes:")
        print("1. Vector dimension mismatch")
        print("2. Table configuration issue")
        print("3. API authentication issue")


if __name__ == "__main__":
    main()
