"""RAG (Retrieval-Augmented Generation) pipeline example."""

import os

from seahorse_vector_store import SeahorseVectorStore


def main() -> None:
    """Demonstrate a simple RAG pipeline with Seahorse."""
    # Get credentials from environment
    api_key = os.environ.get("SEAHORSE_API_KEY")
    base_url = os.environ.get("SEAHORSE_BASE_URL")

    if not api_key or not base_url:
        print("Please set SEAHORSE_API_KEY and SEAHORSE_BASE_URL environment variables")
        return

    print("Building RAG Pipeline with Seahorse VectorStore...")

    # Step 1: Initialize vectorstore
    vectorstore = SeahorseVectorStore(
        api_key=api_key,
        base_url=base_url,
    )

    # Step 2: Prepare knowledge base
    knowledge_base = [
        "Seahorse is a high-performance vector database API gateway.",
        "Seahorse supports HNSW indexing for fast similarity search.",
        "Seahorse can handle embeddings with up to 1024 dimensions.",
        "You can create tables and manage API keys through the Seahorse Console.",
        "Seahorse provides both built-in embeddings and support for external embedding models.",
    ]

    metadatas = [
        {"category": "overview", "page": 1},
        {"category": "indexing", "page": 2},
        {"category": "technical", "page": 3},
        {"category": "management", "page": 4},
        {"category": "embeddings", "page": 5},
    ]

    print("\n📚 Indexing knowledge base...")
    ids = vectorstore.add_texts(texts=knowledge_base, metadatas=metadatas)
    print(f"Indexed {len(ids)} documents")

    # Step 3: Convert to retriever
    print("\n🔍 Creating retriever...")
    retriever = vectorstore.as_retriever(
        search_type="similarity", search_kwargs={"k": 3}
    )

    # Step 4: RAG Query Function
    def rag_query(question: str) -> None:
        """Perform RAG query."""
        print(f"\n❓ Question: {question}")

        # Retrieve relevant documents
        docs = retriever.get_relevant_documents(question)

        print(f"\n📄 Retrieved {len(docs)} relevant documents:")
        for i, doc in enumerate(docs, 1):
            print(f"\n{i}. {doc.page_content}")
            print(f"   (Source: {doc.metadata})")

        # Generate context for LLM
        context = "\n\n".join([doc.page_content for doc in docs])

        print("\n💡 Context for LLM:")
        print("-" * 60)
        print(context)
        print("-" * 60)

        # Note: In a real RAG pipeline, you would pass this context
        # to an LLM (like GPT-4, Claude, etc.) to generate an answer
        print("\n(In a complete RAG system, this context would be sent to an LLM)")

    # Step 5: Run example queries
    print("\n" + "=" * 60)
    print("Running RAG Queries")
    print("=" * 60)

    rag_query("What is Seahorse?")
    rag_query("How does Seahorse handle indexing?")
    rag_query("What embedding options does Seahorse support?")

    # Cleanup
    print("\n🧹 Cleaning up...")
    vectorstore.delete(ids=ids)
    print("✅ RAG pipeline example completed!")


if __name__ == "__main__":
    main()
