"""Basic usage example for Seahorse VectorStore."""

import os

from seahorse_vector_store import SeahorseVectorStore


def main() -> None:
    """Demonstrate basic vectorstore operations."""
    # Get credentials from environment
    api_key = os.environ.get("SEAHORSE_API_KEY")
    base_url = os.environ.get("SEAHORSE_BASE_URL")

    if not api_key or not base_url:
        print("Please set SEAHORSE_API_KEY and SEAHORSE_BASE_URL environment variables")
        return

    # Initialize vectorstore with Seahorse built-in embeddings
    print("Initializing Seahorse VectorStore...")
    vectorstore = SeahorseVectorStore(
        api_key=api_key,
        base_url=base_url,
        use_builtin_embedding=True,
    )

    # Sample documents
    texts = [
        "Machine learning is a subset of artificial intelligence.",
        "Deep learning uses neural networks with multiple layers.",
        "Natural language processing enables computers to understand human language.",
        "Computer vision allows machines to interpret visual information.",
        "Reinforcement learning teaches agents through trial and error.",
    ]

    metadatas = [
        {"source": "ai_basics.pdf", "topic": "machine_learning"},
        {"source": "ai_basics.pdf", "topic": "deep_learning"},
        {"source": "nlp_guide.pdf", "topic": "nlp"},
        {"source": "cv_intro.pdf", "topic": "computer_vision"},
        {"source": "rl_guide.pdf", "topic": "reinforcement_learning"},
    ]

    # Add documents
    print("\nAdding documents...")
    ids = vectorstore.add_texts(texts=texts, metadatas=metadatas)
    print(f"Added {len(ids)} documents")
    print(f"Generated IDs: {ids[:2]}... (showing first 2)")

    # Similarity search
    print("\n--- Similarity Search ---")
    query = "What is deep learning?"
    docs = vectorstore.similarity_search(query=query, k=3)

    print(f"\nQuery: '{query}'")
    print(f"Found {len(docs)} similar documents:\n")
    for i, doc in enumerate(docs, 1):
        print(f"{i}. {doc.page_content}")
        print(f"   Metadata: {doc.metadata}\n")

    # Similarity search with scores
    print("\n--- Similarity Search with Scores ---")
    query = "neural networks"
    docs_and_scores = vectorstore.similarity_search_with_score(query=query, k=2)

    print(f"\nQuery: '{query}'")
    print(f"Found {len(docs_and_scores)} documents:\n")
    for i, (doc, score) in enumerate(docs_and_scores, 1):
        print(f"{i}. Score: {score:.4f}")
        print(f"   Content: {doc.page_content}")
        print(f"   Metadata: {doc.metadata}\n")

    # Metadata filtering
    print("\n--- Search with Metadata Filter ---")
    query = "artificial intelligence"
    filter_dict = {"source": "ai_basics.pdf"}
    docs = vectorstore.similarity_search(query=query, k=5, filter=filter_dict)

    print(f"\nQuery: '{query}'")
    print(f"Filter: {filter_dict}")
    print(f"Found {len(docs)} documents:\n")
    for i, doc in enumerate(docs, 1):
        print(f"{i}. {doc.page_content}")
        print(f"   Metadata: {doc.metadata}\n")

    # Delete documents
    print("\n--- Cleanup ---")
    success = vectorstore.delete(ids=ids)
    print(f"Deleted documents: {success}")

    print("\n✅ Example completed successfully!")


if __name__ == "__main__":
    main()
