"""Async usage example for Seahorse VectorStore."""

import asyncio
import os

from seahorse_vector_store import SeahorseVectorStore


async def main() -> None:
    """Demonstrate async vectorstore operations."""
    # Get credentials from environment
    api_key = os.environ.get("SEAHORSE_API_KEY")
    base_url = os.environ.get("SEAHORSE_BASE_URL")

    if not api_key or not base_url:
        print("Please set SEAHORSE_API_KEY and SEAHORSE_BASE_URL environment variables")
        return

    print("🚀 Async Seahorse VectorStore Example")
    print("=" * 60)

    # Initialize vectorstore
    vectorstore = SeahorseVectorStore(
        api_key=api_key,
        base_url=base_url,
        use_builtin_embedding=True,
    )

    # Sample documents
    texts = [
        "Async programming enables concurrent execution of code.",
        "Python's asyncio library provides async/await syntax.",
        "Async operations can improve application performance.",
    ]

    metadatas = [
        {"topic": "async", "level": "beginner"},
        {"topic": "python", "level": "intermediate"},
        {"topic": "performance", "level": "advanced"},
    ]

    # Add documents asynchronously
    print("\n📝 Adding documents asynchronously...")
    ids = await vectorstore.aadd_texts(texts=texts, metadatas=metadatas)
    print(f"✅ Added {len(ids)} documents")
    print(f"   IDs: {[id[:20] + '...' for id in ids[:2]]}")

    # Async search
    print("\n🔍 Searching asynchronously...")
    query = "How to use async in Python?"
    docs = await vectorstore.asimilarity_search(query=query, k=2)

    print(f"\n📄 Found {len(docs)} documents for query: '{query}'")
    for i, doc in enumerate(docs, 1):
        print(f"\n{i}. {doc.page_content}")
        print(f"   Metadata: {doc.metadata}")

    # Async search with scores
    print("\n📊 Searching with scores...")
    docs_and_scores = await vectorstore.asimilarity_search_with_score(
        query="async performance", k=3
    )

    print(f"\nFound {len(docs_and_scores)} documents:")
    for i, (doc, score) in enumerate(docs_and_scores, 1):
        print(f"\n{i}. Score: {score:.4f}")
        print(f"   Content: {doc.page_content[:60]}...")
        print(f"   Metadata: {doc.metadata}")

    # Async delete
    print("\n🧹 Cleaning up asynchronously...")
    success = await vectorstore.adelete(ids=ids)
    print(f"✅ Deleted documents: {success}")

    print("\n" + "=" * 60)
    print("✨ Async example completed!")


if __name__ == "__main__":
    asyncio.run(main())
