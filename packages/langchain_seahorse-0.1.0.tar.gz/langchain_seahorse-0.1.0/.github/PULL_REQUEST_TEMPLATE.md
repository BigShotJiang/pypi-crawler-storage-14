# Pull Request

## 📝 Description

<!-- 변경 사항에 대한 간단한 설명 -->

## 🎯 Type of Change

- [ ] Bug fix (non-breaking change which fixes an issue)
- [ ] New feature (non-breaking change which adds functionality)
- [ ] Breaking change (fix or feature that would cause existing functionality to not work as expected)
- [ ] Documentation update
- [ ] Performance improvement
- [ ] Code refactoring

## ✅ Checklist

- [ ] 코드가 PEP 8을 준수합니다
- [ ] Type hints를 추가했습니다
- [ ] Docstrings를 작성했습니다 (Google-style)
- [ ] Tests를 추가/업데이트 했습니다
- [ ] 모든 tests가 통과합니다 (`pytest tests/unit/`)
- [ ] Black으로 포맷했습니다 (`black seahorse_vector_store/`)
- [ ] Ruff로 린트했습니다 (`ruff check seahorse_vector_store/ --fix`)
- [ ] CHANGELOG.md를 업데이트했습니다
- [ ] 문서를 업데이트했습니다 (필요한 경우)

## 🧪 Testing

<!-- 테스트 방법 설명 -->

```bash
# 테스트 실행 명령어
uv run pytest tests/unit/ -v
```

## 📖 Documentation

<!-- 문서 변경사항이 있다면 설명 -->

## 💬 Additional Notes

<!-- 추가 정보나 참고사항 -->
