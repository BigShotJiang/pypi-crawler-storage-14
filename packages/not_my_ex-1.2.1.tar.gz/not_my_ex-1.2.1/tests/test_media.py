from pathlib import Path
from unittest.mock import patch

from pytest import mark, raises

from not_my_ex.media import Media


@mark.asyncio
@mark.parametrize("ext,width,height", (("png", 1, 2), ("jpeg", 2, 3)))
async def test_media_from_img(ext, width, height):
    img = Path(__file__).parent / f"image.{ext}"
    media = await Media.from_img(str(img))
    assert media.content == img.read_bytes()
    assert media.mime == f"image/{ext}"
    assert await media.dimensions() == (width, height)


@mark.asyncio
async def test_media_from_img_not_found():
    with raises(ValueError):
        await Media.from_img("/tmp/this-file-should-not-exist.png")


@mark.asyncio
async def test_media_from_img_without_mime_type():
    img = Path(__file__).parent / "image.png"
    with patch("not_my_ex.media.mime_for") as guess:
        guess.return_value = None
        with raises(ValueError):
            await Media.from_img(str(img))


def test_media_check_alt_text_with_existing_alt_text():
    media = Media("path", b"content", "mime", "alt")
    with patch("not_my_ex.media.input") as mock:
        media.check_alt_text()
        mock.assert_not_called()


def test_media_check_alt_text_with_user_input():
    media = Media("path", b"content", "mime")
    with patch("not_my_ex.media.input") as mock:
        mock.return_value = "alt"
        media.check_alt_text()
    assert media.alt == "alt"


@mark.asyncio
async def test_media_dimensions_for_not_an_image():
    media = await Media.from_img(__file__)
    assert await media.dimensions() is None
