from os import environ

from pytest import fixture

from not_my_ex.auth import EnvAuth

SETTINGS = {
    "BSKY_EMAIL": "python@mailinator.com",
    "BSKY_PASSWORD": "forty2",
    "MASTODON_TOKEN": "40two",
}


def pytest_configure(config):
    for key, value in SETTINGS.items():
        environ[f"NOT_MY_EX_{key}"] = value
    return config


@fixture
def auth():
    return EnvAuth()
