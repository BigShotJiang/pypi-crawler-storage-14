"""Manual utilities for batplot.

Instead of generating a PDF, this module exposes the packaged Markdown
manual as a plain text file and opens it in the user's preferred editor.
"""

from __future__ import annotations

from pathlib import Path
from typing import List

import hashlib
import os
import shlex
import subprocess
import sys
import tempfile

try:  # Python 3.9+ exposes .files API directly
	from importlib import resources as importlib_resources  # type: ignore[attr-defined]
except ImportError:  # pragma: no cover
	import importlib_resources  # type: ignore


MANUAL_RESOURCE = ("batplot.data", "USER_MANUAL.md")
TEXT_NAME = "batplot_manual.txt"
HASH_NAME = "batplot_manual.sha256"
MANUAL_RENDER_VERSION = "4"


def _manual_text() -> str:
	"""Load the Markdown manual bundled with the package."""
	package, resource = MANUAL_RESOURCE
	try:
		data = importlib_resources.files(package).joinpath(resource).read_text(encoding="utf-8")  # type: ignore[attr-defined]
		return data
	except Exception:
		pass
	try:
		with importlib_resources.open_text(package, resource, encoding="utf-8") as handle:  # type: ignore[attr-defined]
			return handle.read()
	except Exception:
		pass
	local_path = Path(__file__).resolve().parent / "data" / resource
	if local_path.exists():
		return local_path.read_text(encoding="utf-8")
	raise FileNotFoundError(f"Unable to locate manual resource '{resource}'. Tried package '{package}' and {local_path}")


def _manual_hash(text: str) -> str:
	digest = hashlib.sha256()
	digest.update(MANUAL_RENDER_VERSION.encode("utf-8"))
	digest.update(text.encode("utf-8"))
	return digest.hexdigest()


def _cache_dir() -> Path:
	env_override = os.environ.get("BATPLOT_CACHE_DIR")
	if env_override:
		target = Path(env_override).expanduser()
	elif os.name == "nt":
		base = Path(os.environ.get("LOCALAPPDATA", Path.home() / "AppData" / "Local"))
		target = base / "batplot"
	else:
		base = Path(os.environ.get("XDG_CACHE_HOME", Path.home() / ".cache"))
		target = base / "batplot"
	try:
		target.mkdir(parents=True, exist_ok=True)
		if os.access(target, os.W_OK):
			return target
	except OSError:
		pass
	fallback = Path(tempfile.gettempdir()) / "batplot-manual"
	fallback.mkdir(parents=True, exist_ok=True)
	return fallback


def _resolve_editor_command() -> List[str]:
	for var in ("BATPLOT_MANUAL_EDITOR", "VISUAL", "EDITOR"):
		cmd = os.environ.get(var)
		if cmd:
			return shlex.split(cmd)
	if sys.platform.startswith("win"):
		return ["notepad.exe"]
	if sys.platform.startswith("darwin"):
		return ["open"]
	return ["xdg-open"]


def _open_editor(path: Path) -> None:
	cmd = _resolve_editor_command()
	try:
		process_args = cmd + [str(path)]
		subprocess.Popen(process_args)
	except Exception as exc:  # pragma: no cover - best effort
		print(f"Manual saved to {path} (auto-open failed: {exc})")


def show_manual(open_viewer: bool = True) -> str:
	"""Ensure a plain-text manual exists and optionally open it."""
	text = _manual_text()
	target_dir = _cache_dir()
	txt_path = target_dir / TEXT_NAME
	hash_path = target_dir / HASH_NAME
	content_hash = _manual_hash(text)
	cached_hash = hash_path.read_text(encoding="utf-8").strip() if hash_path.exists() else ""

	if (not txt_path.exists()) or (cached_hash != content_hash):
		txt_path.write_text(text, encoding="utf-8")
		hash_path.write_text(content_hash, encoding="utf-8")

	if open_viewer:
		_open_editor(txt_path)
	return str(txt_path)


def main(argv: list[str] | None = None) -> int:
	path = show_manual(open_viewer=True)
	print(f"batplot manual ready at {path}")
	return 0


__all__ = ["show_manual", "main"]


if __name__ == "__main__":  # pragma: no cover
	sys.exit(main())

