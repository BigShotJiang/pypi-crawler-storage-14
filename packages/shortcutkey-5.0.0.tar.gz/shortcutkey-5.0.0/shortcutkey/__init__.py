"""shortcutkey - 通过快捷键打开指定软件的工具"""

__version__ = "5.0.0"
