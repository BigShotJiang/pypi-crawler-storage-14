import os
import subprocess
import sys
import platform
import re
import time

# 添加当前目录到Python路径，使其可以直接运行
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# 导入日志模块
from shortcutkey.logger import logger


class AppManager:
    """应用程序管理器"""
    
    def _is_app_in_foreground(self, app_path):
        """检查应用是否在前台"""
        try:
            if platform.system() == 'Darwin':  # macOS
                # 获取应用名称
                app_name = os.path.basename(app_path)
                if app_name.endswith('.app'):
                    app_name = app_name[:-4]
                
                # 使用AppleScript检查前台应用
                script = f"tell application \"System Events\" to get name of first application process whose frontmost is true"
                result = subprocess.run(['osascript', '-e', script], capture_output=True, text=True)
                frontmost_app = result.stdout.strip()
                
                logger.debug(f"macOS前台应用: {frontmost_app}, 目标应用: {app_name}")
                return frontmost_app.lower() == app_name.lower()
            
            elif platform.system() == 'Windows':  # Windows
                try:
                    import win32gui
                    
                    # 获取当前活动窗口
                    hwnd = win32gui.GetForegroundWindow()
                    if hwnd:
                        # 获取窗口标题
                        window_title = win32gui.GetWindowText(hwnd)
                        # 简单的包含匹配，实际应用可能需要更复杂的逻辑
                        logger.debug(f"Windows前台窗口: {window_title}")
                        # 尝试从app_path提取应用名称进行匹配
                        app_name = os.path.basename(app_path)
                        return app_name.lower() in window_title.lower()
                except ImportError:
                    logger.warning("缺少pywin32库，无法检查Windows前台应用")
                return False
            
            else:  # Linux
                # 对于Linux，实现会因桌面环境而异
                try:
                    # GNOME桌面环境检查
                    result = subprocess.run(['xdotool', 'getwindowfocus', 'getwindowname'], 
                                          capture_output=True, text=True)
                    if result.returncode == 0:
                        window_title = result.stdout.strip()
                        logger.debug(f"Linux前台窗口: {window_title}")
                        # 简单的包含匹配
                        app_name = os.path.basename(app_path)
                        return app_name.lower() in window_title.lower()
                except Exception:
                    logger.warning("无法检查Linux前台应用")
                return False
                
        except Exception as e:
            logger.error(f"检查应用是否在前台时出错: {str(e)}")
            return False
    
    def _minimize_app(self, app_path):
        """最小化应用"""
        try:
            if platform.system() == 'Darwin':  # macOS
                # 获取应用名称
                app_name = os.path.basename(app_path)
                if app_name.endswith('.app'):
                    app_name = app_name[:-4]
                
                # 使用AppleScript最小化应用
                script = f"tell application \"System Events\" to set visible of every process whose name is \"{app_name}\" to false"
                subprocess.run(['osascript', '-e', script], capture_output=True)
                logger.info(f"已最小化macOS应用: {app_name}")
                print(f"已最小化应用: {app_name}")
                return True
            
            elif platform.system() == 'Windows':  # Windows
                try:
                    import win32gui
                    
                    # 定义回调函数查找窗口
                    def callback(hwnd, app_name):
                        if app_name.lower() in win32gui.GetWindowText(hwnd).lower():
                            # 最小化窗口
                            win32gui.ShowWindow(hwnd, 6)  # SW_MINIMIZE = 6
                            return False
                        return True
                    
                    # 从app_path提取应用名称
                    app_name = os.path.basename(app_path)
                    # 遍历所有顶级窗口
                    win32gui.EnumWindows(callback, app_name)
                    logger.info(f"已尝试最小化Windows应用: {app_name}")
                    print(f"已最小化应用: {app_name}")
                    return True
                except ImportError:
                    logger.warning("缺少pywin32库，无法最小化Windows应用")
                    # 备用方案：尝试使用taskkill终止进程，可能不理想但可以作为备选
                    os.system(f'taskkill /IM "{os.path.basename(app_path)}" /F')
                    return False
            
            else:  # Linux
                # 对于Linux，使用xdotool最小化窗口
                try:
                    app_name = os.path.basename(app_path)
                    # 查找窗口ID并最小化
                    subprocess.run(['xdotool', 'search', '--name', app_name, 'windowminimize'], 
                                  capture_output=True)
                    logger.info(f"已最小化Linux应用: {app_name}")
                    print(f"已最小化应用: {app_name}")
                    return True
                except Exception as e:
                    logger.error(f"最小化Linux应用失败: {str(e)}")
                return False
                
        except Exception as e:
            logger.error(f"最小化应用时出错: {str(e)}")
            return False
    
    def open_app(self, app_path):
        """打开指定的应用程序，如果已在前台则最小化"""
        logger.info(f"尝试处理应用程序: {app_path}")
        try:
            # 检查应用是否在前台
            if self._is_app_in_foreground(app_path):
                logger.info(f"应用 {app_path} 已在前台，尝试最小化")
                self._minimize_app(app_path)
                return
            
            # 根据操作系统使用不同的方式打开应用程序
            if platform.system() == 'Darwin':  # macOS
                # 在 macOS 上，使用 open -a 命令打开应用程序
                logger.info(f"在macOS平台上打开应用: {app_path}")
                os.system(f'open -a "{app_path}"')
                logger.info(f"成功在macOS上打开应用: {app_path}")
            
            elif platform.system() == 'Windows':  # Windows
                logger.info(f"在Windows平台上打开应用: {app_path}")
                # 在 Windows 上，使用 start 命令或直接运行
                if app_path.endswith('.exe') or os.path.exists(app_path):
                    subprocess.Popen([app_path], shell=True)
                    logger.info(f"成功在Windows上打开应用(可执行文件): {app_path}")
                else:
                    # 尝试在 PATH 中查找程序
                    subprocess.Popen(app_path, shell=True)
                    logger.info(f"成功在Windows上打开应用(搜索PATH): {app_path}")
            
            else:  # Linux
                logger.info(f"在Linux平台上打开应用: {app_path}")
                # 在 Linux 上，直接运行命令
                subprocess.Popen([app_path], shell=True)
                logger.info(f"成功在Linux上打开应用: {app_path}")
            
            print(f"已打开应用程序: {app_path}")
            
        except Exception as e:
            logger.error(f"打开应用程序失败: {app_path}, 错误: {str(e)}")
            print(f"打开应用程序失败: {app_path}")
            print(f"错误信息: {e}")
    
    def find_applications(self):
        """查找系统中的应用程序"""
        logger.info("开始查找系统中的应用程序")
        apps = []
        
        if platform.system() == 'Darwin':  # macOS
            logger.info("在macOS平台上查找应用程序")
            # 使用system_profiler获取更完整的应用程序信息
            try:
                # 执行system_profiler命令并获取输出
                logger.info("使用system_profiler获取应用信息")
                result = subprocess.run(
                    ['system_profiler', 'SPApplicationsDataType', '-json'],
                    capture_output=True,
                    text=True,
                    check=True
                )
                
                # 解析JSON输出
                import json
                data = json.loads(result.stdout)
                
                # 提取应用程序信息
                if 'SPApplicationsDataType' in data:
                    for app_info in data['SPApplicationsDataType']:
                        app_name = app_info.get('_name', '')
                        app_location = app_info.get('path', '')
                        if app_name and app_location:
                            apps.append({
                                'name': app_name,
                                'location': app_location
                            })
                logger.info(f"成功从system_profiler获取 {len(apps)} 个应用")
            except Exception as e:
                logger.error(f"获取应用列表失败: {str(e)}")
                print(f"获取应用列表失败: {e}")
                # 备用方法：扫描/Applications目录
                applications_dir = '/Applications'
                logger.info(f"尝试备用方法：扫描目录 {applications_dir}")
                if os.path.exists(applications_dir):
                    try:
                        for app in os.listdir(applications_dir):
                            if app.endswith('.app'):
                                app_path = os.path.join(applications_dir, app)
                                apps.append({
                                    'name': app[:-4],  # 移除.app后缀
                                    'location': app_path
                                })
                        logger.info(f"从/Applications目录获取了 {len(apps)} 个应用")
                    except Exception as scan_error:
                        logger.error(f"扫描/Applications目录失败: {str(scan_error)}")
        
        elif platform.system() == 'Windows':  # Windows
            logger.info("在Windows平台上查找应用程序")
            # 查找常见的应用程序目录
            common_paths = [
                os.environ.get('ProgramFiles', 'C:/Program Files'),
                os.environ.get('ProgramFiles(x86)', 'C:/Program Files (x86)')
            ]
            
            for path in common_paths:
                if os.path.exists(path):
                    logger.info(f"扫描Windows应用目录: {path}")
                    try:
                        for item in os.listdir(path):
                            app_path = os.path.join(path, item)
                            if os.path.isdir(app_path):
                                # 查找 .exe 文件
                                for root, _, files in os.walk(app_path):
                                    for file in files:
                                        if file.endswith('.exe'):
                                            full_path = os.path.join(root, file)
                                            apps.append({
                                                'name': file[:-4],  # 移除.exe后缀
                                                'location': full_path
                                            })
                                            break
                    except Exception as e:
                        logger.error(f"扫描Windows目录 {path} 出错: {str(e)}")
            logger.info(f"成功获取 {len(apps)} 个Windows应用")
        
        else:  # Linux
            logger.info("在Linux平台上查找应用程序")
            # 扫描常见应用程序目录
            app_dirs = ['/usr/share/applications', '/usr/local/share/applications', os.path.expanduser('~/.local/share/applications')]
            for app_dir in app_dirs:
                if os.path.exists(app_dir):
                    logger.info(f"扫描Linux应用目录: {app_dir}")
                    try:
                        for file in os.listdir(app_dir):
                            if file.endswith('.desktop'):
                                desktop_file = os.path.join(app_dir, file)
                                try:
                                    with open(desktop_file, 'r') as f:
                                        content = f.read()
                                        # 提取应用名称和可执行文件路径
                                        name_match = re.search(r'Name=(.+)', content, re.MULTILINE)
                                        exec_match = re.search(r'Exec=(.+)', content, re.MULTILINE)
                                        if name_match and exec_match:
                                            app_name = name_match.group(1)
                                            exec_path = exec_match.group(1).strip()
                                            # 移除可能的参数
                                            exec_path = exec_path.split()[0]
                                            apps.append({
                                                'name': app_name,
                                                'location': exec_path
                                            })
                                except Exception as parse_error:
                                    logger.error(f"解析Linux桌面文件 {desktop_file} 出错: {str(parse_error)}")
                    except Exception as scan_error:
                        logger.error(f"扫描Linux目录 {app_dir} 出错: {str(scan_error)}")
            logger.info(f"成功获取 {len(apps)} 个Linux应用")
        
        logger.info(f"应用程序查找完成，共找到 {len(apps)} 个应用")
        return apps