class SupportedOEM:
    VIESSMANN = "viessmann" # Will depracted in future
    EON_HOME = "eon-home"