"""ErrorTags for timeout exceptions in the simplebench package."""
from .timeout import _TimeoutErrorTag

__all__ = ["_TimeoutErrorTag"]
