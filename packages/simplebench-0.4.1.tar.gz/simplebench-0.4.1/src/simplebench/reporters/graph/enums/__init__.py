"""Enums for the simplebench.graph package."""
from simplebench.reporters.graph.enums.image_type import ImageType

__all__ = [
    "ImageType",
]
