# FourierShift  
---  

## Overview  
The *Fourier Shift* imaging method is a classical single-pixel imaging technique that uses **Fourier patterns** as an orthogonal basis combined with a **shifting method**.  

| Development Status | Technique Specificity | Measurement Output Format | Example Patterns |
|--------------------|-----------------------|----------------------------|------------------|
| Functional and final | Shifting: unstable | Datacube | <p align="center"> <img src="img/fouriershift.png" alt="hub" width="100"/> </p> |


## install 
tested with python 3.9
```bash
pip install onepix_fouriershift
```

## 🔗 Source Code  
📁 Access the source code on GitHub:  
👉 [ONE-PIX – FourierShift Imaging Method](https://github.com/PhotonicsOpenProjects/ONE-PIX/tree/main/plugins/imaging_methods/FourierShift)

## 🧪 Author & Contributor  
🔧 Made by [POP](https://www.photonics-open-projects.com/) 💡
