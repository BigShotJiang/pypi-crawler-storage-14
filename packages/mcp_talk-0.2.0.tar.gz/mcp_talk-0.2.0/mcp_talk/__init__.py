"""MCP Talk - Inter-agent messaging via Model Context Protocol."""

__version__ = "0.1.0"
