![Demo](public/demo.png)

# Cynia Agents

Cynia Agents is a lightweight framework for running generative agents through a Streamlit interface.  
Generation logic lives in installable **components** which can be added or removed without modifying the UI.

The framework provides unified LLM, configuration, and artifact management, allowing agent developers to focus on building components that generate content.

The repository ships with only a simple example component.  Complex generators such as the Bukkit plugin agent can be distributed separately and dropped into the `components` folder.

## Installation

You can install Cynia Agents directly via pip:

```bash
pip install cynia-agents
```

## Usage

### Running the Application

To start the Cynia Agents UI, simply run:

```bash
cynia-agents
```

The application will launch in your default web browser. You can configure your API keys and choose an LLM provider from the **Configuration Center** page in the sidebar.

### Managing Components

You can manage your components in the **Component Center**:
- **Import ZIP**: Upload a ZIP file containing a component.
- **Import Folder**: Select a local folder to import as a component.
- **Dependencies**: Automatically install dependencies for your components.

### Developing Components

To develop a new component, navigate to your component's directory and run:

```bash
cynia-agents dev
```

This command will start the application and temporarily link your current directory as a component, allowing you to see changes in real-time.

See [COMPONENT_DEVELOPMENT.md](COMPONENT_DEVELOPMENT.md) for detailed information on building your own generators.

## Developing Components

A component is a Python module placed inside the `components/` directory. Here's a minimal example of a CyniaAgents component.

```python
from component_base import BaseComponent

class MyComponent(BaseComponent):
    name = "My Generator"
    description = "Does something amazing"
    # Declare any additional packages your component depends on
    requirements = ["pandas"]

    def render(self):
        import streamlit as st
        self.logger("Rendering my component")
        st.write("Hello from my component")
```

See [COMPONENT_DEVELOPMENT.md](COMPONENT_DEVELOPMENT.md) for information on building your own generators.
Components can be a single Python file or a folder containing multiple files. Single-file components keep their dependencies in a ``requirements`` list while multi-file components include a ``requirements.txt`` file.


## License
Licensed under the Apache 2.0 License.
