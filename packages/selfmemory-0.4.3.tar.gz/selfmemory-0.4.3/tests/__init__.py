# Tests for selfmemory-core package
