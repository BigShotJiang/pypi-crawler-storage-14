"""SelfMemory MCP Server with OAuth 2.1 via Hydra.

This package provides an MCP (Model Context Protocol) server for SelfMemory
with OAuth 2.1 authentication powered by Ory Hydra.
"""

__version__ = "0.1.0"
