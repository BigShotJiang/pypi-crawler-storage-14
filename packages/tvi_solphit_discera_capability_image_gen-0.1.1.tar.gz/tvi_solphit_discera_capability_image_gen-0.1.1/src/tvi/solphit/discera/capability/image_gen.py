# image_gen.py (Discera capability; Ingialla-backed)
from __future__ import annotations
import base64
from typing import Any, Dict, List

from tvi.solphit.base.logging import SolphitLogger

log = SolphitLogger.get_logger("discera.capabilities.image_gen")

# Ingialla Generator is the only integration point (same as other capabilities)
try:
    from tvi.solphit.ingialla.ask import Generator
    _HAS_LLM = True
except Exception as e:
    _HAS_LLM = False
    log.error("[image_gen] Ingialla not available: %s", e)


class ImageGenCapability:
    """
    Capability: image_gen

    Purpose:
    Generate an image from a text prompt using the Ingialla Generator backend,
    returning a base64-encoded PNG and a Markdown block for UI rendering.

    Intents:
    - "image_generation" : prompt → image
    - "visualization"    : diagrams/illustrations
    - "art"              : creative renders
    """

    name = "image_gen"

    @staticmethod
    def descriptor() -> Dict[str, Any]:
        return {
            "name": ImageGenCapability.name,
            "description": (
                "Generates images from a text prompt via Ingialla Generator (Ollama-backed). "
                "Returns a base64 PNG plus Markdown for plugin-only rendering. "
                "Honors the UI 'Be Concise' flag for compact captions."
            ),
            "intents": ["image_generation", "visualization", "art", "diagram"],
            "examples": [
                "Generate a futuristic city skyline at sunset, cinematic lighting.",
                "Create a labeled diagram showing the water cycle.",
                "Draw a cartoon cat riding a bicycle, pastel colors.",
            ],
            "tags": ["image", "generation", "art", "visual", "diagram", "picture"],
            "excludes": [],
        }

    @staticmethod
    def assets() -> Dict[str, List[str]]:
        """Plugin-only CSS/JS (keeps rendering consistent; no global dependency)."""
        css = r"""
        .discera .image-gen-result {
            margin: 12px 0;
            text-align: center;
        }
        .discera .image-gen-result img {
            max-width: 100%;
            border-radius: 12px;
            box-shadow: 0 2px 12px rgba(0,0,0,0.12);
            background: #222;
        }
        .discera .image-gen-caption {
            margin-top: 6px;
            color: #9ca3af;
            font-size: .95em;
        }
        """
        js = r"""/* No-op: rendering handled by plugin injection. */"""
        return {"css": [css], "js": [js]}

    def _render_markdown(self, prompt: str, image_b64: str, *, concise: bool) -> str:
        """Return Markdown/HTML block that your UI can drop directly into messages."""
        # Defensive: escape angle brackets in the prompt so it can't inject HTML
        safe_prompt = (
            (prompt or "")
            .replace("&", "&amp;")
            .replace("<", "&lt;")
            .replace(">", "&gt;")
        )

        if concise:
            # Compact: just the image and a short one-line caption
            return (
                f'<div class="image-gen-result">'
                f'data:image/png;base64,{image_b64}'
                f'<div class="image-gen-caption"><strong>Prompt:</strong> {safe_prompt}</div>'
                f'</div>'
            )

        # Default: heading + image + caption
        return (
            "### Generated Image\n"
            f"**Prompt:** {safe_prompt}\n\n"
            f'<div class="image-gen-result">'
            f'data:image/png;base64,{image_b64}'
            f'<div class="image-gen-caption">Rendered via Ingialla Generator</div>'
            f'</div>'
        )

    def _normalize_flags(self, args: Any, hints: Dict[str, Any]) -> Dict[str, Any]:
        """Read provider/model/concise from args or hints (matches your other capabilities)."""
        # concise flag mirrors Weather/WebSearch behavior
        concise = False
        if isinstance(args, dict):
            concise = bool(args.get("concise", False))
        if not concise and "concise" in hints:
            concise = bool(hints.get("concise"))

        provider = hints.get("provider") or "ollama"
        # Choose a default image model that’s commonly available; override via hints
        model = hints.get("model") or "stable-diffusion-xl"

        # Optional knobs (add more as needed; your UI can pass them in hints)
        width  = int(hints.get("width")  or 896)   # SDXL common default
        height = int(hints.get("height") or 512)
        steps  = int(hints.get("steps")  or 25)
        cfg    = float(hints.get("cfg_scale") or 7.5)  # classifier-free guidance (if supported)
        seed   = hints.get("seed")  # optional

        return {
            "provider": provider,
            "model": model,
            "concise": concise,
            "width": width,
            "height": height,
            "steps": steps,
            "cfg_scale": cfg,
            "seed": seed,
        }

    def _call_ingialla_for_image(
        self,
        prompt: str,
        *,
        provider: str,
        model: str,
        width: int,
        height: int,
        steps: int,
        cfg_scale: float,
        seed: Any,
    ) -> str:
        """
        Call Ingialla Generator for image output and return base64 PNG.

        We support multiple signatures to match different Ingalla builds:
        - generate_image(prompt, width=..., height=..., steps=..., cfg_scale=..., seed=...)
        - generate(prompt, contexts=[], history=[], output="image", ...)
        - generate(prompt, contexts=[], ...) -> {"image_base64": "..."} (dict payload)

        If none of the above is available, we raise an error (keeps the failure visible).
        """
        if not _HAS_LLM:
            raise RuntimeError("Ingialla Generator is not available (import failed).")

        gen = Generator(provider=provider, model=model, verbose=False)

        # 1) Preferred: dedicated image API
        if hasattr(gen, "generate_image"):
            b64 = gen.generate_image(
                prompt,
                width=width,
                height=height,
                steps=steps,
                cfg_scale=cfg_scale,
                seed=seed,
            )  # type: ignore[attr-defined]
            if isinstance(b64, str) and b64.strip():
                return b64.strip()

        # 2) Alternate: generic generate(...) with output hint
        try:
            result = gen.generate(
                prompt,
                contexts=[],
                history=[],
                output="image",  # many wrappers inspect this hint
                width=width,
                height=height,
                steps=steps,
                cfg_scale=cfg_scale,
                seed=seed,
            )
            # Some wrappers return a dict with the base64 in a known key
            if isinstance(result, dict):
                for key in ("image_base64", "image", "png_base64", "data"):
                    val = result.get(key)
                    if isinstance(val, str) and val.strip():
                        return val.strip()
            # Some return a raw base64 string
            if isinstance(result, str) and result.strip():
                # Heuristics: allow raw base64 or "data:image/png;base64,..." and normalize
                raw = result.strip()
                if raw.startswith("data:image"):
                    raw = raw.split(",", 1)[-1]
                # Quick validation it’s decodable (not stored—only checks)
                try:
                    base64.b64decode(raw, validate=True)
                    return raw
                except Exception:
                    pass
        except Exception as e:
            log.debug("[image_gen] Generator.generate (output=image) failed: %s", e)

        # 3) Fallback: plain generate(...) that returns a dict with image key
        try:
            result = gen.generate(prompt, contexts=[], history=[])
            if isinstance(result, dict):
                for key in ("image_base64", "image", "png_base64", "data"):
                    val = result.get(key)
                    if isinstance(val, str) and val.strip():
                        return val.strip()
        except Exception as e:
            log.debug("[image_gen] Generator.generate (plain) failed: %s", e)

        raise RuntimeError(
            "Ingialla Generator did not return an image. "
            "Ensure your image model is loaded and the Generator build supports image outputs."
        )

    # --------------------------- Public API ---------------------------

    def run_once(self, args: Any, **kwargs) -> Dict[str, Any]:
        """
        Args:
            args.question : prompt string (required)
            kwargs.hints  : provider/model/width/height/steps/cfg_scale/seed/concise
        Returns:
            {
                "answer": Markdown with embedded image,
                "image_base64": <base64 PNG>,
                "meta": {...}
            }
        """
        prompt = (getattr(args, "question", None) or args.get("question") or "").strip()
        hints: Dict[str, Any] = kwargs.get("hints") or {}

        flags = self._normalize_flags(args, hints)

        try:
            image_b64 = self._call_ingialla_for_image(
                prompt,
                provider=flags["provider"],
                model=flags["model"],
                width=flags["width"],
                height=flags["height"],
                steps=flags["steps"],
                cfg_scale=flags["cfg_scale"],
                seed=flags["seed"],
            )
        except Exception as ex:
            md = (
                f"### Image Generation Error\n"
                f"**Prompt:** {prompt}\n\n"
                f"Sorry, image generation failed: `{ex}`"
            )
            return {
                "answer": md,
                "image_base64": "",
                "meta": {"capability": self.name, **flags, "prompt": prompt, "error": str(ex)},
            }

        md = self._render_markdown(prompt, image_b64, concise=flags["concise"])
        return {
            "answer": md,
            "image_base64": image_b64,
            "meta": {"capability": self.name, **flags, "prompt": prompt},
        }

    async def run_stream(self, args: Any, **kwargs):
        """
        Streams the final answer as tokens (single-chunk emit; matches your framing).
        Events:
          - generation_started
          - token
          - generation_done
          - done
        """
        result = self.run_once(args, **kwargs)
        yield {"event": "generation_started", "data": {"capability": self.name}}
        # Emit Markdown as a single token; if you prefer chunking, split with _chunk_text(...)
        yield {"event": "token", "data": result.get("answer", "")}
        yield {"event": "generation_done", "data": {}}
        yield {"event": "done", "data": {}}


def register(registry):
    registry.register(ImageGenCapability())
