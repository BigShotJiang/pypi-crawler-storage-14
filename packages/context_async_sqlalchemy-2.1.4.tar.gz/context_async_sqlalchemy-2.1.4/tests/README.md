# Tests


The library is tested in the context of real asynchronous applications.
For this reason, the library’s tests are essentially the same as the
example tests -  each example includes a complete test suite that
verifies all of the library’s capabilities.

- [Tests with FastAPI](../examples/fastapi_example/tests)
- [Tests with Starlette](../examples/starlette_example/tests)
