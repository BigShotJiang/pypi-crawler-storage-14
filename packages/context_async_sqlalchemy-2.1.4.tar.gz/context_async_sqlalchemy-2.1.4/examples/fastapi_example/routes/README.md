# Handlers example

A module that contains all the application handlers.

The examples are fictional, but they’re designed to demonstrate the
various capabilities of the library.
