# License: MIT
# Copyright © 2023 Frequenz Energy-as-a-Service GmbH

"""Command line interface for versioning."""
