# Frequenz Repository Configuration Release Notes

## New Features

* Pytest v9.x is now supported.
