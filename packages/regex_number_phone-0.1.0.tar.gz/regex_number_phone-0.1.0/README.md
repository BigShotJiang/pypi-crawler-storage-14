# regex-number-phone

Phone number regex validator and formatter.  
**Cambodia** validation supported.

## Install

## Usage

```python
from regex_number_phone import is_valid_cambodia, format_to_international

print(is_valid_cambodia("012345678"))           # True
print(format_to_international("012345678"))     # +85512345678
print(format_to_international("+85570888888"))  # +85570888888