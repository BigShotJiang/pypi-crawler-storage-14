import re

# Cambodia phone prefixes (optional strict mode)
KH_PREFIXES = {
    "010",
    "011",
    "012",
    "014",
    "015",
    "016",
    "017",
    "018",
    "031",
    "032",
    "033",
    "034",
    "035",
    "036",
    "037",
    "038",
    "060",
    "061",
    "066",
    "067",
    "068",
    "069",
    "070",
    "071",
    "076",
    "077",
    "078",
    "081",
    "085",
    "086",
    "087",
    "088",
    "089",
    "090",
    "091",
    "093",
    "096",
    "097",
    "098",
}


def clean_number(phone: str) -> str:
    """Remove spaces, dash, +855, 855, leading zero."""
    phone = phone.replace(" ", "").replace("-", "")

    if phone.startswith("+855"):
        phone = phone[4:]
    elif phone.startswith("855"):
        phone = phone[3:]
    elif phone.startswith("0"):
        phone = phone[1:]

    return phone


def is_valid_cambodia(phone: str, strict_prefix: bool = False) -> bool:
    """Validate Cambodia phone number"""
    phone = clean_number(phone)

    # Check digit length
    if not phone.isdigit() or len(phone) not in (8, 9):
        return False

    # Check prefix (optional strict)
    if strict_prefix:
        prefix = phone[:3]
        if prefix not in KH_PREFIXES:
            return False

    # Basic regex (8–9 digit Cambodia numbers)
    return bool(re.fullmatch(r"\d{8,9}", phone))


def format_to_international(phone: str) -> str:
    """Return +855 format"""
    phone = clean_number(phone)

    if not is_valid_cambodia(phone):
        raise ValueError("Invalid Cambodia phone number")

    return "+855" + phone
