from __future__ import annotations

import os
from pathlib import Path

from pybind11.setup_helpers import Pybind11Extension, build_ext
from setuptools import setup

ROOT = Path(__file__).parent

SKIP_CPP = os.environ.get("CF_BASIC_SIGNAL_SKIP_CPP", "").lower() in {"1", "true", "yes"}
ENABLE_OPCUA = os.environ.get("CF_BASIC_SIGNAL_ENABLE_OPCUA_CPP", "").lower() in {"1", "true", "yes"}
OPEN62541_INCLUDE = os.environ.get("CF_BASIC_SIGNAL_OPEN62541_INCLUDE")
OPEN62541_LIB = os.environ.get("CF_BASIC_SIGNAL_OPEN62541_LIB")
OPEN62541_LIBNAME = os.environ.get("CF_BASIC_SIGNAL_OPEN62541_LIBNAME", "open62541")

ext_modules = []
if not SKIP_CPP:
    ext_modules.append(
        Pybind11Extension(
            "cf_basic_signal._dataproc_core",
            sources=[
                "cf_basic_signal/cpp/libdataproc_core.cpp",
                "cf_basic_signal/cpp/dataproc_core_pybind.cpp",
            ],
            cxx_std=17,
        )
    )
    ext_modules.append(
        Pybind11Extension(
            "cf_basic_signal._pipeline_backend_ops",
            sources=[
                "cf_basic_signal/cpp/libdataproc_core.cpp",
                "cf_basic_signal/cpp/pipeline_backend_ops.cpp",
            ],
            cxx_std=17,
        )
    )
    if ENABLE_OPCUA:
        opcua_libs = [name for name in [OPEN62541_LIBNAME or "open62541"] if name]
        if os.name == "nt":
            # open62541 static on Windows needs winsock + iphlpapi + secur32/advapi32/crypt32
            opcua_libs += ["ws2_32", "iphlpapi", "secur32", "advapi32", "crypt32"]
        ext_modules.append(
            Pybind11Extension(
                "cf_basic_signal._opcua_backend_ops",
                sources=["cf_basic_signal/cpp/opcua_backend_ops.cpp"],
                include_dirs=[p for p in [OPEN62541_INCLUDE] if p],
                library_dirs=[p for p in [OPEN62541_LIB] if p],
                libraries=opcua_libs,
                cxx_std=17,
            )
        )


setup(
    name="cf-basic-signal",
    version="0.1.10",
    description="Cogniflow basic signal StepPackage (InlineSource, HandleSink, FIFO/average) with optional C++ acceleration.",
    packages=["cf_basic_signal"],
    package_data={
        "cf_basic_signal": [
            "cf-step-package.yaml",
            "steps.ttl",
            "examples/*.json",
            "cpp/*.cpp",
            "cpp/*.hpp",
            "pipeline_plugin.json",
        ],
    },
    entry_points={
        "cogniflow.steps": [
            "cf.basic.signal = cf_basic_signal.steps:register_steps",
        ]
    },
    extras_require={
        "test": ["pytest>=7.4"],
    },
    ext_modules=ext_modules,
    cmdclass={"build_ext": build_ext},
    zip_safe=False,
)
