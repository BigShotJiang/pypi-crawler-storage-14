#premiumcalculator 

A simple python library that is used to calculate phone insurance premium.