from __future__ import annotations

import sys

from bear_shelf._internal._info import METADATA
from funcy_bear.constants.exit_code import ExitCode
from funcy_bear.context.arg_helpers import args_inject

from ._cmds import _ReturnedArgs, debug_info, get_args, get_version
from ._versioning import cli_bump


@args_inject(process=get_args)
def main(args: _ReturnedArgs) -> ExitCode:
    """Entry point for the CLI application.

    This function is executed when you type `bear-shelf` or `python -m bear-shelf`.

    Parameters:
        args: Arguments passed from the command line.

    Returns:
        An exit code.
    """
    match args.cmd:
        case "version":
            return get_version()
        case "bump":
            return cli_bump(args.bump_type, METADATA.version_tuple)
        case "debug":
            return debug_info(no_color=args.no_color)
        case "sync-storage":
            # TODO: Will return this after hotfix later.
            # generate_storage_file()
            return ExitCode.SUCCESS
        case _:
            print("Unknown command.", file=sys.stderr)
            return ExitCode.FAILURE


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
