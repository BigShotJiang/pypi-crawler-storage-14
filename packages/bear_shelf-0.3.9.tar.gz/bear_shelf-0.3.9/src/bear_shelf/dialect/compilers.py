"""A set of SQL compilers for the Bear Shelf dialect."""

from __future__ import annotations

from typing import Any

from sqlalchemy.sql.compiler import DDLCompiler, SQLCompiler

from bear_shelf.config import APP_CONFIG


class StatementCompiler(SQLCompiler):
    """SQL compiler for Bear Shelf dialect.

    We will use the base SQLCompiler as-is for now, as Bear Shelf
    primarily handles DDL via do_execute() methods in the dialect.
    """


class BearDDLCompiler(DDLCompiler):
    """DDL compiler for Bear Shelf dialect."""

    def visit_create_table(self, create: Any, **_) -> str:
        """Handle CREATE TABLE DDL - emit sentinel comment."""
        return f"{APP_CONFIG.info.ddl_comment_prefix} create {create.element.name} */"

    def visit_drop_table(self, drop: Any, **_) -> str:
        """Handle DROP TABLE DDL - emit sentinel comment."""
        return f"{APP_CONFIG.info.ddl_comment_prefix} drop {drop.element.name} */"
