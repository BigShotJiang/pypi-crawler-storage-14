"""Examples demonstrating Bear Shelf features."""
