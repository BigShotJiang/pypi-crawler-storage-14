from adam.commands.bash.bash import Bash
from adam.commands.command import Command
from adam.commands.commands_utils import show_pods, show_rollout
from adam.commands.devices.device import Device
from adam.repl_state import ReplState
from adam.utils import lines_to_tabular, log, log2
from adam.utils_k8s.custom_resources import CustomResources
from adam.utils_k8s.kube_context import KubeContext
from adam.utils_k8s.statefulsets import StatefulSets

class DeviceCass(Command, Device):
    COMMAND = f'{ReplState.C}:'

    # the singleton pattern
    def __new__(cls, *args, **kwargs):
        if not hasattr(cls, 'instance'): cls.instance = super(DeviceCass, cls).__new__(cls)

        return cls.instance

    def __init__(self, successor: Command=None):
        super().__init__(successor)

    def command(self):
        return DeviceCass.COMMAND

    def run(self, cmd: str, state: ReplState):
        if not self.args(cmd):
            return super().run(cmd, state)

        state.device = ReplState.C

        return state

    def completion(self, state: ReplState):
        return super().completion(state)

    def help(self, _: ReplState):
        return f'{DeviceCass.COMMAND}\t move to Cassandra Operations device'

    def ls(self, cmd: str, state: ReplState):
        if state.pod:
            return Bash().run('bash ' + cmd, state)
        elif state.sts and state.namespace:
            show_pods(StatefulSets.pods(state.sts, state.namespace), state.namespace, show_namespace=not KubeContext.in_cluster_namespace())
            show_rollout(state.sts, state.namespace)
        else:
            self.show_statefulsets()

    def show_statefulsets(self):
        ss = StatefulSets.list_sts_names()
        if len(ss) == 0:
            log2('No Cassandra clusters found.')
            return

        app_ids = CustomResources.get_app_ids()
        list = []
        for s in ss:
            cr_name = CustomResources.get_cr_name(s)
            app_id = 'Unknown'
            if cr_name in app_ids:
                app_id = app_ids[cr_name]
            list.append(f"{s} {app_id}")

        header = 'STATEFULSET_NAME@NAMESPACE APP_ID'
        if KubeContext.in_cluster_namespace():
            header = 'STATEFULSET_NAME APP_ID'
        log(lines_to_tabular(list, header))