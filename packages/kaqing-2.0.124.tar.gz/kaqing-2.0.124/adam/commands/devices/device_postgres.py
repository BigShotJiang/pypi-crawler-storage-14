from adam.commands.command import Command
from adam.commands.devices.device import Device
from adam.commands.postgres.postgres_context import PostgresContext
from adam.commands.postgres.postgres_utils import pg_database_names, pg_table_names
from adam.repl_state import ReplState
from adam.utils import lines_to_tabular, log

class DevicePostgres(Command, Device):
    COMMAND = f'{ReplState.P}:'

    # the singleton pattern
    def __new__(cls, *args, **kwargs):
        if not hasattr(cls, 'instance'): cls.instance = super(DevicePostgres, cls).__new__(cls)

        return cls.instance

    def __init__(self, successor: Command=None):
        super().__init__(successor)

    def command(self):
        return DevicePostgres.COMMAND

    def run(self, cmd: str, state: ReplState):
        if not self.args(cmd):
            return super().run(cmd, state)

        state.device = ReplState.P

        return state

    def completion(self, state: ReplState):
        return super().completion(state)

    def help(self, _: ReplState):
        return f'{DevicePostgres.COMMAND}\t move to Postgres Operations device'

    def ls(self, cmd: str, state: ReplState):
        if state.pg_path:
            pg: PostgresContext = PostgresContext.apply(state.namespace, state.pg_path)
            if pg.db:
                self.show_pg_tables(pg)
            else:
                self.show_pg_databases(pg)
        else:
            self.show_pg_hosts(state)

    def show_pg_hosts(self, state: ReplState):
        if state.namespace:
            def line(pg: PostgresContext):
                return f'{pg.path()},{pg.endpoint()}:{pg.port()},{pg.username()},{pg.password()}'

            lines = [line(PostgresContext.apply(state.namespace, pg)) for pg in PostgresContext.hosts(state.namespace)]

            log(lines_to_tabular(lines, 'NAME,ENDPOINT,USERNAME,PASSWORD', separator=','))
        else:
            def line(pg: PostgresContext):
                return f'{pg.path()},{pg.namespace},{pg.endpoint()}:{pg.port()},{pg.username()},{pg.password()}'

            lines = [line(PostgresContext.apply(state.namespace, pg)) for pg in PostgresContext.hosts(state.namespace)]

            log(lines_to_tabular(lines, 'NAME,NAMESPACE,ENDPOINT,USERNAME,PASSWORD', separator=','))

    def show_pg_databases(self, pg: PostgresContext):
        log(lines_to_tabular(pg_database_names(pg.namespace, pg.path()), 'DATABASE', separator=','))

    def show_pg_tables(self, pg: PostgresContext):
        log(lines_to_tabular(pg_table_names(pg.namespace, pg.path()), 'NAME', separator=','))
