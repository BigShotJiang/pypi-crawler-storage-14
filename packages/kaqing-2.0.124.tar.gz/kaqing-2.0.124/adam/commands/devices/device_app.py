from adam.apps import Apps
from adam.commands.bash.bash import Bash
from adam.commands.command import Command
from adam.commands.devices.device import Device
from adam.config import Config
from adam.repl_state import ReplState
from adam.utils import lines_to_tabular, log
from adam.utils_k8s.app_pods import AppPods
from adam.utils_k8s.ingresses import Ingresses

class DeviceApp(Command, Device):
    COMMAND = f'{ReplState.A}:'

    # the singleton pattern
    def __new__(cls, *args, **kwargs):
        if not hasattr(cls, 'instance'): cls.instance = super(DeviceApp, cls).__new__(cls)

        return cls.instance

    def __init__(self, successor: Command=None):
        super().__init__(successor)

    def command(self):
        return DeviceApp.COMMAND

    def run(self, cmd: str, state: ReplState):
        if not self.args(cmd):
            return super().run(cmd, state)

        state.device = ReplState.A

        return state

    def completion(self, state: ReplState):
        return super().completion(state)

    def help(self, _: ReplState):
        return f'{DeviceApp.COMMAND}\t move to App Operations device'

    def ls(self, cmd: str, state: ReplState):
        if state.app_pod:
            return Bash().run('bash ' + cmd, state)
        elif state.app_app:
            pods = AppPods.pod_names(state.namespace, state.app_env, state.app_app)

            log(lines_to_tabular(pods, 'POD_NAME'))
        elif state.app_env:
            def line(n: str, ns: str):
                host = Ingresses.get_host(Config().get('app.login.ingress', '{app_id}-k8singr-appleader-001').replace('{app_id}', f'{ns}-{n}'), ns)
                if not host:
                    return None

                endpoint = Config().get('app.login.url', 'https://{host}/{env}/{app}').replace('{host}', host).replace('{env}', state.app_env).replace('{app}', 'c3')
                if not endpoint:
                    return None

                return f"{n.split('-')[1]},{Ingresses.get_host(f'{ns}-{n}-k8singr-appleader-001', ns)},{endpoint}"

            svcs = [l for l in [line(n, ns) for n, ns in Apps.apps(state.app_env)] if l]

            log(lines_to_tabular(svcs, 'APP,HOST,ENDPOINT', separator=','))
        else:
            svcs = [n for n, ns in Apps.envs()]

            log(lines_to_tabular(svcs, 'ENV', separator=','))