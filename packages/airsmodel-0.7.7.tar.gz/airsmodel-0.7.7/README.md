# AIRS Model

This package contains the data model for sending requests to ARLAS Item Registration Services. It is part of the AIAS project, maintained by Gisaïa.
