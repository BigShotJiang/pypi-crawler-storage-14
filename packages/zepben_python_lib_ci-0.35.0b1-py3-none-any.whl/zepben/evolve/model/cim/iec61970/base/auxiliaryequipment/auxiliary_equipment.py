# Copyright (c) Zeppelin Bend Pty Ltd (Zepben) 2025 - All Rights Reserved.
# Unauthorized use, copy, or distribution of this file or its contents, via any medium is strictly prohibited.

from __future__ import annotations

from typing import Optional

from zepben.evolve.model.cim.iec61970.base.core.equipment import Equipment
from zepben.evolve.model.cim.iec61970.base.core.terminal import Terminal

__all__ = ["AuxiliaryEquipment", "FaultIndicator"]


class AuxiliaryEquipment(Equipment):
    """
    `AuxiliaryEquipment` describe equipment that is not performing any primary functions but support for the
    equipment performing the primary function.

    `AuxiliaryEquipment` is attached to primary equipment via an association with `zepben.evolve.cim.iec61970.base.core.Terminal`.
    """
    terminal: Optional[Terminal] = None
    """The `zepben.evolve.iec61970.base.core.terminal.Terminal`` at the `Equipment` where the `AuxiliaryEquipment` is attached."""


class FaultIndicator(AuxiliaryEquipment):
    """
    A FaultIndicator is typically only an indicator (which may or may not be remotely monitored), and not a piece of
    equipment that actually initiates a protection event. It is used for FLISR (Fault Location, Isolation and
    Restoration) purposes, assisting with the dispatch of crews to "most likely" part of the network (i.e. assists
    with determining circuit section where the fault most likely happened).
    """
    pass
