Printing the name of the document on footer is only allowed by default to invoices by
setting `account.display_name_in_footer` to True.

This module was developed because there is no way to print other document names on each
page of reports.

It will be useful for you if you want to print the name of the document in the footer
pages to quickly know what page belongs to what document.

Also you can define what documents will have the document name in its footer.
