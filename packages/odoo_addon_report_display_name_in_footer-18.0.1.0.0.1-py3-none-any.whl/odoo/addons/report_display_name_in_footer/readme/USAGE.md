To use this module, you need to:

1. Go to System Parameters.
2. Add your desired models or use 'all' to show document name on all type of documents.
3. Print a report for you desired model.
4. Check Footer to see document name.
