This module extends the pagination functionality in reports to display the name of the
document on each page of PDFs, allowing you to know which document each page belongs to
and in what order they should appear.

Pagination will appear on the left side and document name on the right side of the
footer.