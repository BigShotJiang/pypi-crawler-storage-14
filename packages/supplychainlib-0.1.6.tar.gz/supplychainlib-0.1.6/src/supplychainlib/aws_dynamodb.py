import boto3
import os
from decimal import Decimal

# Manage DynamoDB table operations
class DynamoDBManager:
    def __init__(self, table_name):
        # Initialize DynamoDB resource and table
        region = os.getenv("AWS_REGION", "us-east-1")
        resource = boto3.resource("dynamodb", region_name=region)
        self.table = resource.Table(table_name)

    def get_item(self, key):
        # Get item by key from DynamoDB table
        try:
            response = self.table.get_item(Key=key)
            return response.get("Item")
        except Exception as e: # If item does not exist returns None
            print("Error getting item from", self.table.name, e)
            return None

    def put_item(self, item):
        # Put an item into the table add or edit
        try:
            item = self._convert_floats_to_decimal(item)
            self.table.put_item(Item=item)
        except Exception as e:
            print("Error putting item in", self.table.name, e)

    def update_item(self, key, update_expr, values, names=None):
        # Update item in table with given expression
        try:
            params = {
                "Key": key,
                "UpdateExpression": update_expr, # update only specific attributes inventory quantities,order status,finished product stock
                "ExpressionAttributeValues": values,
            }
            if names:
                params["ExpressionAttributeNames"] = names
            self.table.update_item(**params)
        except Exception as e:
            print("Error updating item in", self.table.name, e)

    def delete_item(self, key):
        # Delete item by key
        try:
            self.table.delete_item(Key=key)
        except Exception as e:
            print("Error deleting item from", self.table.name, e)

    def scan_table(self):
        # Get all items from the table
        items = []
        try:
            response = self.table.scan()
            items.extend(response.get("Items", []))
            # loop to get all pages
            while "LastEvaluatedKey" in response:
                response = self.table.scan(ExclusiveStartKey=response["LastEvaluatedKey"])
                items.extend(response.get("Items", []))
            return [self._convert_decimal_to_float(item) for item in items] # convert decimal to float
        except Exception as e:
            print("Error scanning", self.table.name, e)
            return []

    def _convert_floats_to_decimal(self, item):
        # DynamoDB rejects float, so converting float to Decimal
        def convert(value):
            if isinstance(value, float):
                return Decimal(str(value))
            if isinstance(value, dict):
                return {k: convert(v) for k,v in value.items()}
            if isinstance(value, list):
                return [convert(v) for v in value]
            return value
        return {k: convert(v) for k,v in item.items()}

    def _convert_decimal_to_float(self, item):
        # Convert DynamoDB Decimals back to float 
        def convert(value):
            if isinstance(value, Decimal):
                return int(value) if value % 1 == 0 else float(value)
            if isinstance(value, dict):
                return {k: convert(v) for k,v in value.items()}
            if isinstance(value, list):
                return [convert(v) for v in value]
            return value
        return {k: convert(v) for k,v in item.items()}


# Domain-specific managers extending the base manager with initialization
# These classes inherit all base functionality and only configure the table name

class SupplierManager(DynamoDBManager):
    ''' Manages the Suppliers table
    Add suppliers, List suppliers, Read supplier cost & origin data'''
    def __init__(self):
        super().__init__("Suppliers")

    def list_active(self):
        # Returns all suppliers
        return self.scan_table()

class RawMaterialManager(DynamoDBManager):
    # Manages Raw Materials
    def __init__(self):
        super().__init__("RawMaterials")

    def list_for_supplier(self, supplier_id):
        # Get all raw materials for a supplier by scanning and filtering
        all_items = self.scan_table()
        return [item for item in all_items if item.get("supplier_id") == supplier_id]

class FinishedProductManager(DynamoDBManager):
    # Manages finished products table
    def __init__(self):
        super().__init__("FinishedProducts") # Used in Distributor orders and customer order pages


class PurchaseOrderManager(DynamoDBManager):
    def __init__(self):
        super().__init__("PurchaseOrders")

    def get_item(self, po_id):
        # Override to allow fetching by po_id key
        return super().get_item({"po_id": po_id})

    def delete_item(self, po_id):
        super().delete_item({"po_id": po_id})

class DistributorManager(DynamoDBManager):
    # Manages distributors table
    def __init__(self):
        super().__init__("Distributors")


class DistributorOrderManager(DynamoDBManager):
    # Manages distributor orders
    def __init__(self):
        super().__init__("DistributorOrders")


class DistributorInventoryManager(DynamoDBManager):
    # Manages distributor inventory records
    def __init__(self):
        super().__init__("DistributorInventory")

    def add_stock(self, distributor_id, product_id, quantity):
        # Add quantity to existing stock in inventory or create new if does not exist
        key = {"id": f"{distributor_id}#{product_id}"}
        self.update_item(
            key=key,
            update_expr="SET quantity = if_not_exists(quantity, :zero) + :qty",
            values={":qty": int(quantity), ":zero": 0},
        )

class CustomerOrderManager(DynamoDBManager):
    # Manages customer orders
    def __init__(self):
        super().__init__("CustomerOrders")
