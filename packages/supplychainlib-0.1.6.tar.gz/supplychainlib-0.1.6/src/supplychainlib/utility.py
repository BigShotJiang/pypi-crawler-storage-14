import random
import string
from datetime import datetime

# Utility class to help generate tracking and order IDs
class TrackingUtility:
    # Generate a unique identifier with prefix, current datetime and random suffix
    @staticmethod
    def generate(prefix):
        date_str = datetime.utcnow().strftime("%Y%m%d%H%M%S")
        # Simple random string of 4 uppercase letters or digits
        random_str = ''.join(random.choice(string.ascii_uppercase + string.digits) for _ in range(4))
        return prefix + "-" + date_str + "-" + random_str

# Utility class for inventory related checks
class InventoryUtility:
    # Check if quantity is less than or equal to a threshold safely
    @staticmethod
    def below_threshold(quantity, threshold):
        try:
            return int(quantity) <= int(threshold)
        except Exception:
            # Return False if conversion fails
            return False
