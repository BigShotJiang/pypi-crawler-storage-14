import boto3
import os
import zipfile
from botocore.exceptions import ClientError

class LambdaManager:
    # Manages Lambda function deployment and invocation
    
    def __init__(self, region='us-east-1'):
        self.region = region
        self.lambda_client = boto3.client('lambda', region_name=region)
        self.iam_client = boto3.client('iam', region_name=region)
    
    def create_or_update_function(self, function_name, zip_file_path, handler, role_arn, runtime='python3.9'):
        # Create or update Lambda function
        
        try:
            # Read ZIP file
            with open(zip_file_path, 'rb') as f:
                zip_content = f.read()
            
            # Check if function exists
            try:
                self.lambda_client.get_function(FunctionName=function_name)
                function_exists = True
            except ClientError as e:
                if e.response['Error']['Code'] == 'ResourceNotFoundException':
                    function_exists = False
                else:
                    raise e
            
            if function_exists:
                # Update existing function
                print(f"Updating Lambda function: {function_name}")
                response = self.lambda_client.update_function_code(
                    FunctionName=function_name,
                    ZipFile=zip_content
                )
                print(f"Function {function_name} updated successfully")
            else:
                # Create new function
                print(f"Creating Lambda function: {function_name}")
                response = self.lambda_client.create_function(
                    FunctionName=function_name,
                    Runtime=runtime,
                    Role=role_arn,
                    Handler=handler,
                    Code={'ZipFile': zip_content},
                    Timeout=30,
                    MemorySize=512
                )
                print(f"Function {function_name} created successfully")
            
            return response
            
        except ClientError as e:
            print(f"Error creating/updating Lambda function: {e}")
            return None
    
    def invoke_function(self, function_name, payload):
        # Invoke Lambda function with payload
        try:
            import json
            
            response = self.lambda_client.invoke(
                FunctionName=function_name,
                InvocationType='Event',
                Payload=json.dumps(payload)
            )
            
            print(f"Lambda function {function_name} invoked. Status: {response['StatusCode']}")
            return response['StatusCode'] == 202
            
        except ClientError as e:
            print(f"Error invoking Lambda function: {e}")
            return False
    
    def delete_function(self, function_name):
        #Delete Lambda function
        
        try:
            self.lambda_client.delete_function(FunctionName=function_name)
            print(f"Function {function_name} deleted successfully")
            return True
        except ClientError as e:
            print(f"Error deleting Lambda function: {e}")
            return False
    
    def get_function_info(self, function_name):
        # Get Lambda function information
        
        try:
            response = self.lambda_client.get_function(FunctionName=function_name)
            return response
        except ClientError as e:
            print(f"Error getting function info: {e}")
            return None
