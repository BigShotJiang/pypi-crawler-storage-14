from setuptools import setup, find_packages

setup(
    name='supplychainlib',
    version='0.1.3',
    author='Shridhar Malaghan',
    description='Private AWS-integrated library for the Gourmet Coffee Supply Chain project',
    package_dir={'': 'src'},
    packages=find_packages(where='src'),
    install_requires=['boto3'],
)
