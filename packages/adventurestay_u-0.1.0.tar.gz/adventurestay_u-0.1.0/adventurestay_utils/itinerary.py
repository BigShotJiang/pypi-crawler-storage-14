"""Helpers that provide human-readable itinerary summaries."""

from __future__ import annotations

from .models import AdventureBooking


def build_itinerary_summary(booking: AdventureBooking) -> str:
    """Return a concise itinerary summary string for confirmations."""

    inclusions = []
    if booking.package.includes_meals:
        inclusions.append("meals")
    if booking.package.includes_guide:
        inclusions.append("guide")

    inclusion_text = ", ".join(inclusions) if inclusions else "standard inclusions"

    return (
        f"{booking.package.name} in {booking.package.location}: "
        f"{booking.nights} nights for {booking.num_guests} guest(s) "
        f"from {booking.start_date:%d %b %Y} to {booking.end_date:%d %b %Y}. "
        f"Inclusions: {inclusion_text}. Total price: {booking.total_price:.2f}."
    )
