"""Domain models for adventure staycation packages and bookings."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import date


@dataclass(frozen=True)
class AdventurePackage:
    """Configuration for a single adventure staycation package."""

    package_id: str
    category: str
    name: str
    location: str
    base_price_per_night: float | None = None
    base_price_per_person: float | None = None
    max_guests: int = 1
    min_nights: int = 1
    max_nights: int = 7
    includes_meals: bool = False
    includes_guide: bool = False
    is_active: bool = True


@dataclass(frozen=True)
class BookingRequest:
    """Incoming booking request prior to persistence."""

    package_id: str
    start_date: date
    end_date: date
    num_guests: int


@dataclass(frozen=True)
class AdventureBooking:
    """Represents a confirmed booking derived from a package and validated request."""

    package: AdventurePackage
    start_date: date
    end_date: date
    num_guests: int
    nights: int
    total_price: float
