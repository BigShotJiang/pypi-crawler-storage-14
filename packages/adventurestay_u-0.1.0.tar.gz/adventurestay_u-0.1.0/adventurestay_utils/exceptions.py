"""Custom exceptions for adventure staycation domain."""


class InvalidDateRangeError(Exception):
    """Raised when booking dates are invalid."""


class InvalidGuestCountError(Exception):
    """Raised when requested guests fall outside package limits."""


class PackageNotAvailableError(Exception):
    """Raised when a package is not available for requested dates or capacity."""


class PackageConfigError(Exception):
    """Raised when a package is configured with invalid parameters."""
