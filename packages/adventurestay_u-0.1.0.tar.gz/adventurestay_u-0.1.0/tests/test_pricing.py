from dataclasses import replace
from datetime import date

from adventurestay_utils import (
    AdventurePackage,
    AdventurePriceCalculator,
    PackageBookingValidator,
)


def lodge_package(**overrides):
    base = AdventurePackage(
        package_id="LODGE1",
        category="LODGING",
        name="Hillside Cabin",
        location="Coorg",
        base_price_per_night=100.0,
        max_guests=4,
        min_nights=1,
        max_nights=5,
        includes_meals=True,
        includes_guide=False,
    )
    return replace(base, **overrides)


def trekking_package(**overrides):
    base = AdventurePackage(
        package_id="TREK1",
        category="TREKKING",
        name="Himalayan Trek",
        location="Manali",
        base_price_per_person=80.0,
        max_guests=10,
        min_nights=2,
        max_nights=10,
        includes_meals=False,
        includes_guide=True,
    )
    return replace(base, **overrides)


def test_base_price_for_lodging():
    package = lodge_package()
    request = PackageBookingValidator.create_booking_request(
        package, date(2025, 4, 1), date(2025, 4, 3), 2
    )
    price = AdventurePriceCalculator().calculate_price(request, package)
    assert price == 400.0  # 2 nights * 100 * 2 guests


def test_weekend_multiplier_applied():
    package = lodge_package()
    request = PackageBookingValidator.create_booking_request(
        package, date(2025, 4, 4), date(2025, 4, 6), 2
    )  # includes Saturday
    price = AdventurePriceCalculator().calculate_price(request, package)
    assert price == 480.0  # 400 * 1.2


def test_peak_season_multiplier_applied():
    package = trekking_package()
    request = PackageBookingValidator.create_booking_request(
        package, date(2025, 12, 10), date(2025, 12, 13), 3
    )
    price = AdventurePriceCalculator().calculate_price(request, package)
    base = 3 * 80.0 * 3  # nights * per-person * guests
    assert price == round(base * 1.3, 2)
