# adventurestay-utils

Core business logic for adventure staycation experiences such as trekking, hills staycations, jungle safaris, and rustic lodging. The package centralizes package configuration, booking validation, availability checking, and price calculations so that multiple web or backend apps can share the same rules.

## Installation

```bash
pip install adventurestay-utils
```

During local development inside this repo:

```bash
pip install -e .
```

## Usage

```python
from datetime import date
from adventurestay_utils import (
    AdventurePackage,
    PackageBookingValidator,
    PackageAvailabilityChecker,
    AdventurePriceCalculator,
    build_itinerary_summary,
    AdventureBooking,
)

package = AdventurePackage(
    package_id="JUNGLE001",
    category="JUNGLE_SAFARI",
    name="2N/3D Jungle Safari",
    location="Kanha",
    base_price_per_person=95.0,
    max_guests=8,
    min_nights=2,
    max_nights=4,
    includes_meals=True,
    includes_guide=True,
)

validator = PackageBookingValidator()
request = validator.create_booking_request(
    package, start_date=date(2025, 3, 10), end_date=date(2025, 3, 13), num_guests=4
)

availability_checker = PackageAvailabilityChecker()
availability_checker.check_availability(request, package, existing_bookings=[])

price = AdventurePriceCalculator().calculate_price(request, package)
booking = AdventureBooking(
    package=package,
    start_date=request.start_date,
    end_date=request.end_date,
    num_guests=request.num_guests,
    nights=(request.end_date - request.start_date).days,
    total_price=price,
)

print(build_itinerary_summary(booking))
```

## Development

1. Create/activate the provided `.venv`.
2. Install dependencies: `pip install -e .[dev]`.
3. Run tests: `python -m pytest`.
4. Build the package when ready for publishing:

   ```bash
   python -m pip install --upgrade build twine
   python -m build
   # twine upload dist/*   # requires credentials via environment variables
   ```

## Features

- Dataclass-based domain models for packages and bookings.
- Validators for dates, guest counts, and package configuration.
- Availability checker that prevents overlapping bookings beyond capacity.
- Pricing calculator with weekend and peak-season multipliers.
- Itinerary summary helper for emails and notifications.
