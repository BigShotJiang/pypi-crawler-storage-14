version = "5.5.5"
git_hash = "b4485490"
license_text = (
    "Licence can be found on:\n\nhttps://github.com/Feramance/qBitrr/blob/master/LICENSE"
)
patched_version = f"{version}-{git_hash}"
tagged_version = f"{version}"
