__version__ = "1.0.5-alpha"

from discord.ext.commands import *
