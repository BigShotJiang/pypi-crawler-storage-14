"""OpenRouter LLM implementation using OpenAI-compatible API."""

import os
from typing import Any

from vision_agents.plugins.openai import LLM as OpenAILLM


class OpenRouterLLM(OpenAILLM):
    """OpenRouter LLM that extends OpenAI LLM with OpenRouter-specific configuration.

    It proxies the regular models by setting base url.
    It supports create response like the regular openAI API. It doesn't support conversation id, so that requires customization

    TODO:
    - Use manual conversation storage
    """

    _instructions: str

    def __init__(
        self,
        *,
        api_key: str | None = None,
        base_url: str = "https://openrouter.ai/api/v1",
        model: str = "openrouter/andromeda-alpha",
        **kwargs: Any,
    ) -> None:
        """Initialize OpenRouter LLM.

        Args:
            api_key: OpenRouter API key. If not provided, uses OPENROUTER_API_KEY env var.
            base_url: OpenRouter API base URL.
            model: Model to use. Defaults to openai/gpt-4o.
            **kwargs: Additional arguments passed to OpenAI LLM.
        """
        if api_key is None:
            api_key = os.environ.get("OPENROUTER_API_KEY")
        super().__init__(
            api_key=api_key,
            base_url=base_url,
            model=model,
            **kwargs,
        )

    async def create_conversation(self):
        # Do nothing, dont call super
        pass

    async def create_response(self, *args: Any, **kwargs: Any):
        """Override create_response to handle OpenRouter-specific requirements.

        OpenRouter doesn't support the 'instructions' parameter like OpenAI does,
        so we convert it to a system message in the input.
        """
        # # Set max_output_tokens default because we're getting rate limited by OpenRouter
        # kwargs.setdefault("max_output_tokens", 1024)

        # Convert instructions to system message
        if not self._instructions:
            return await super().create_response(*args, **kwargs)

        # Get and normalize input to list format
        current_input = kwargs.get("input", args[0] if args else "Hello")
        if not isinstance(current_input, list):
            current_input = [
                {"content": str(current_input), "role": "user", "type": "message"}
            ]

        # Prepend system message with instructions
        kwargs["input"] = [
            {"content": self._instructions, "role": "system", "type": "message"},
            *current_input,
        ]

        # Temporarily clear instructions so parent doesn't add it
        self._instructions, original = None, self._instructions  # type: ignore[assignment]
        try:
            return await super().create_response(*args, **kwargs)
        finally:
            self._instructions = original

    def add_conversation_history(self, kwargs):
        # Use the manual storage
        # ensure the AI remembers the past conversation
        # TODO: there are additional formats to support here.
        new_messages = kwargs["input"]
        if not isinstance(new_messages, list):
            new_messages = [dict(content=new_messages, role="user", type="message")]

        # Build the message list
        messages = []

        if self._conversation:
            # Extract serializable message content from conversation history
            for m in self._conversation.messages:
                if isinstance(m.original, dict):
                    messages.append(m.original)
                else:
                    # For non-dict originals, use the normalized content
                    messages.append(
                        {"content": m.content, "role": "user", "type": "message"}
                    )

        # Add new messages
        messages.extend(new_messages)
        kwargs["input"] = messages

        # Add messages to conversation
        if self._conversation:
            normalized_messages = self._normalize_message(new_messages)
            for msg in normalized_messages:
                self._conversation.messages.append(msg)
