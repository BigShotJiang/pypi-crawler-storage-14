# PharmaAPI Python Client

A Python client library for the PharmaAPI - search and retrieve pharmaceutical data from French and US databases.

## Installation
```bash
pip install pharma-api-client
```

## Quick Start
```python
from pharma_api_client import PharmaAPIClient

# Initialize client
client = PharmaAPIClient(
    base_url="https://api.pharmadb.example.com",
    api_key="your-api-key"
)

# Search for products
response = client.search_by_ingredient("aspirin", limit=10)

# Convert to pandas DataFrame
df = response.to_df()
print(df.head())

# Clean up
client.close()
```

## Features

- 🔍 Search by name, ingredient, dosage form, strength
- 💊 Get product details by CIS ID or RxNorm code
- 💰 Access pricing information (French and US)
- 🔬 Professional tier: ATC codes, NDC lookup, US product names
- 📊 Easy DataFrame conversion with `.to_df()`
- 🛡️ Type hints and comprehensive error handling

## Documentation

See the [tutorial notebook](examples/tutorial.ipynb) for detailed examples.

## Requirements

- Python 3.7+
- requests
- pandas

## License

MIT License