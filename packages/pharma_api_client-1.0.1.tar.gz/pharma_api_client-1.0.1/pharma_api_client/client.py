import requests
from typing import Optional, Dict, Any, List
import pandas as pd

class PharmaAPIResponse:
    """Wrapper for API responses with DataFrame conversion"""
    
    def __init__(self, data: Dict[Any, Any]):
        self.data = data
        self._raw = data
    
    def to_df(self) -> pd.DataFrame:
        """Convert response to pandas DataFrame"""
        # Handle different response structures
        
        # Case 1: Response has a 'results' key (search results)
        if 'results' in self.data and isinstance(self.data['results'], list):
            return pd.DataFrame(self.data['results'])
        
        # Case 2: Response has 'products' key
        if 'products' in self.data and isinstance(self.data['products'], list):
            return pd.DataFrame(self.data['products'])
        
        # Case 3: Response has 'versions' key (single product with versions)
        if 'versions' in self.data and isinstance(self.data['versions'], list):
            return pd.DataFrame(self.data['versions'])
        
        # Case 4: Response is a list at the top level
        if isinstance(self.data, list):
            return pd.DataFrame(self.data)
        
        # Case 5: Single record - wrap in list
        if isinstance(self.data, dict) and not any(k in self.data for k in ['results', 'products', 'versions']):
            return pd.DataFrame([self.data])
        
        # Case 6: Stats or other dict - convert to single-row DataFrame
        return pd.DataFrame([self.data])
    
    def __getitem__(self, key):
        """Allow dict-like access"""
        return self.data[key]
    
    def __repr__(self):
        return f"PharmaAPIResponse({self.data})"
    
    def json(self) -> Dict[Any, Any]:
        """Get raw JSON data"""
        return self.data


class PharmaAPIClient:
    def __init__(self, base_url: str = 'https://dev.pharmapi.dynv6.net/api/v1', api_key: Optional[str] = None):
        self.base_url = base_url.rstrip('/')
        self.session = requests.Session()
        
        if api_key:
            self.session.headers.update({"X-API-Key": api_key})
    
    def _wrap_response(self, response_data: Dict[Any, Any]) -> PharmaAPIResponse:
        """Wrap JSON response in PharmaAPIResponse object"""
        return PharmaAPIResponse(response_data)
    
    def get_product(self, cis_id: str) -> PharmaAPIResponse:
        """Get product by CIS ID - Returns ALL versions"""
        url = f"{self.base_url}/product/{cis_id}"
        
        response = self.session.get(url)
        
        if response.status_code == 200:
            return self._wrap_response(response.json())
        elif response.status_code == 404:
            raise Exception("Product not found")
        else:
            response.raise_for_status()
    
    def get_product_by_rxnorm(self, rxcui: str) -> PharmaAPIResponse:
        """Get products by RxNorm code"""
        url = f"{self.base_url}/product/by-rxnorm/{rxcui}"
        
        response = self.session.get(url)
        
        if response.status_code == 200:
            return self._wrap_response(response.json())
        elif response.status_code == 404:
            raise Exception("RxNorm code not found")
        else:
            response.raise_for_status()
    
    def search_by_name(self, query: str, limit: int = 20) -> PharmaAPIResponse:
        """Search products by French drug description or RxNorm name"""
        url = f"{self.base_url}/search/by-name"
        params = {"q": query, "limit": limit}
        
        response = self.session.get(url, params=params)
        
        if response.status_code == 200:
            return self._wrap_response(response.json())
        else:
            response.raise_for_status()
    
    def search_by_ingredient(self, query: str, limit: int = 20) -> PharmaAPIResponse:
        """Search products by active ingredient"""
        url = f"{self.base_url}/search/by-ingredient"
        params = {"q": query, "limit": limit}
        
        response = self.session.get(url, params=params)
        
        if response.status_code == 200:
            return self._wrap_response(response.json())
        else:
            response.raise_for_status()
    
    def search_by_dosage_form(self, query: str, limit: int = 20) -> PharmaAPIResponse:
        """Search products by dosage form"""
        url = f"{self.base_url}/search/by-dosage-form"
        params = {"q": query, "limit": limit}
        
        response = self.session.get(url, params=params)
        
        if response.status_code == 200:
            return self._wrap_response(response.json())
        else:
            response.raise_for_status()
    
    def search_by_strength(self, query: str, limit: int = 20) -> PharmaAPIResponse:
        """Search products by strength"""
        url = f"{self.base_url}/search/by-strength"
        params = {"q": query, "limit": limit}
        
        response = self.session.get(url, params=params)
        
        if response.status_code == 200:
            return self._wrap_response(response.json())
        else:
            response.raise_for_status()
    
    def search_by_atc(self, code: str, limit: int = 50) -> PharmaAPIResponse:
        """Search products by ATC code (any level) - Professional tier only"""
        url = f"{self.base_url}/search/by-atc"
        params = {"code": code, "limit": limit}
        
        response = self.session.get(url, params=params)
        
        if response.status_code == 200:
            return self._wrap_response(response.json())
        elif response.status_code == 403:
            raise Exception("ATC search is only available in Professional tier. Upgrade to access this feature.")
        else:
            response.raise_for_status()
    
    def search_by_ndc(self, ndc: str) -> PharmaAPIResponse:
        """Search products by NDC code - Professional tier only"""
        url = f"{self.base_url}/search/by-ndc"
        params = {"ndc": ndc}
        
        response = self.session.get(url, params=params)
        
        if response.status_code == 200:
            return self._wrap_response(response.json())
        elif response.status_code == 403:
            raise Exception("NDC search is only available in Professional tier. Upgrade to access this feature.")
        elif response.status_code == 404:
            raise Exception("NDC code not found")
        else:
            response.raise_for_status()
    
    def search_by_product_name(self, query: str, limit: int = 20) -> PharmaAPIResponse:
        """Search by US product name - Professional tier only"""
        url = f"{self.base_url}/search/by-product-name"
        params = {"q": query, "limit": limit}
        
        response = self.session.get(url, params=params)
        
        if response.status_code == 200:
            return self._wrap_response(response.json())
        elif response.status_code == 403:
            raise Exception("Product name search is only available in Professional tier. Upgrade to access this feature.")
        else:
            response.raise_for_status()
    
    def get_us_pricing(self, ndc: str) -> PharmaAPIResponse:
        """Get US NADAC pricing for an NDC code - Professional tier only"""
        url = f"{self.base_url}/pricing/us/{ndc}"
        
        response = self.session.get(url)
        
        if response.status_code == 200:
            return self._wrap_response(response.json())
        elif response.status_code == 403:
            raise Exception("US pricing is only available in Professional tier. Upgrade to access this feature.")
        elif response.status_code == 404:
            raise Exception("NDC code not found")
        else:
            response.raise_for_status()
    
    def get_french_pricing(self, cis_id: str) -> PharmaAPIResponse:
        """Get French pricing - Professional tier includes more fields"""
        url = f"{self.base_url}/pricing/french/{cis_id}"
        
        response = self.session.get(url)
        
        if response.status_code == 200:
            return self._wrap_response(response.json())
        elif response.status_code == 404:
            raise Exception("Product not found")
        else:
            response.raise_for_status()
    
    def get_stats(self) -> PharmaAPIResponse:
        """Get database statistics"""
        url = f"{self.base_url}/stats"
        
        response = self.session.get(url)
        
        if response.status_code == 200:
            return self._wrap_response(response.json())
        else:
            response.raise_for_status()
    
    def close(self):
        """Close the session"""
        self.session.close()


# Context manager for easy cleanup
class PharmaAPIClientContext:
    def __init__(self, base_url: str, api_key: Optional[str] = None):
        self.client = PharmaAPIClient(base_url, api_key)
    
    def __enter__(self):
        return self.client
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        self.client.close()