from setuptools import setup, find_packages
import os

# Read the contents of README file
this_directory = os.path.abspath(os.path.dirname(__file__))
with open(os.path.join(this_directory, 'README.md'), encoding='utf-8') as f:
    long_description = f.read()

# Read version
version = {}
with open(os.path.join(this_directory, 'pharma_api_client', 'version.py')) as f:
    exec(f.read(), version)

setup(
    name='pharma-api-client',
    version=version['__version__'],
    author='pharma Api',
    author_email='toufik.ouadid@tritonis.co',
    description='A Python client for the PharmaAPI - pharmaceutical data API',
    long_description=long_description,
    long_description_content_type='text/markdown',
    url='https://dev.pharmapi.dynv6.net',
    packages=find_packages(exclude=['tests', 'examples']),
    classifiers=[
        'Development Status :: 4 - Beta',
        'Intended Audience :: Developers',
        'Intended Audience :: Healthcare Industry',
        'Topic :: Software Development :: Libraries :: Python Modules',
        'Topic :: Scientific/Engineering :: Medical Science Apps.',
        'License :: OSI Approved :: MIT License',
        'Programming Language :: Python :: 3',
        'Programming Language :: Python :: 3.7',
        'Programming Language :: Python :: 3.8',
        'Programming Language :: Python :: 3.9',
        'Programming Language :: Python :: 3.10',
        'Programming Language :: Python :: 3.11',
    ],
    python_requires='>=3.7',
    install_requires=[
        'requests>=2.25.0',
        'pandas>=1.2.0',
    ],
    extras_require={
        'dev': [
            'pytest>=6.0',
            'pytest-cov>=2.0',
            'black>=21.0',
            'flake8>=3.9',
            'mypy>=0.900',
        ],
        'docs': [
            'sphinx>=4.0',
            'sphinx-rtd-theme>=0.5',
        ],
    },
    keywords='pharmaceutical api drug medicine healthcare rxnorm ndc atc',
    project_urls={
        'Documentation': 'https://dev.pharmapi.dynv6.net/docs',
        'Source': 'https://dev.pharmapi.dynv6.net',
        'Bug Reports': 'https://dev.pharmapi.dynv6.net/contact',
    },
)