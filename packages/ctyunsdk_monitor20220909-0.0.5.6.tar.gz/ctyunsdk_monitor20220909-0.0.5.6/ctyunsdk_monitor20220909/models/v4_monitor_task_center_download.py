from typing import Optional, List
from dataclasses_json import dataclass_json
from dataclasses import dataclass


@dataclass_json
@dataclass
class V4MonitorTaskCenterDownloadRequest:
    regionID: str  # 资源池ID
    taskID: str  # 任务ID



@dataclass_json
@dataclass
class V4MonitorTaskCenterDownloadResponse:
    statusCode: Optional[int] = None
    error: Optional[str] = None
    message: Optional[str] = None
    description: Optional[str] = None
    errorCode: Optional[str] = None
    returnObj: Optional['V4MonitorTaskCenterDownloadReturnObj'] = None


@dataclass_json
@dataclass
class V4MonitorTaskCenterDownloadReturnObj:
    downloadUrl: Optional[str] = None  # 下载链接地址



