from typing import Optional, List
from dataclasses_json import dataclass_json
from dataclasses import dataclass


@dataclass_json
@dataclass
class V4MonitorHybridBoardListRequest:
    pass


@dataclass_json
@dataclass
class V4MonitorHybridBoardListResponse:
    statusCode: Optional[int] = None
    error: Optional[str] = None
    message: Optional[str] = None
    description: Optional[str] = None
    errorCode: Optional[str] = None
    returnObj: Optional['V4MonitorHybridBoardListReturnObj'] = None


@dataclass_json
@dataclass
class V4MonitorHybridBoardListReturnObj:
    boards: Optional[List['V4MonitorHybridBoardListReturnObjBoards']] = None  # 监控大盘列表
    quota: Optional[int] = None  # 监控大盘剩余配额，即当前可新创建数量


@dataclass_json
@dataclass
class V4MonitorHybridBoardListReturnObjBoards:
    boardID: Optional[str] = None  # 监控大盘ID
    name: Optional[str] = None  # 监控大盘名称
    createTime: Optional[int] = None  # 创建时间，时间戳，精确到秒
    updateTime: Optional[int] = None  # 最近更新时间, 时间戳，精确到秒



