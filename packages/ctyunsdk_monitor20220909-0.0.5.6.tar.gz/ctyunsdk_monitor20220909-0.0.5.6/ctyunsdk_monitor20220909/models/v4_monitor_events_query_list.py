from typing import Optional, List
from dataclasses_json import dataclass_json
from dataclasses import dataclass


@dataclass_json
@dataclass
class V4MonitorEventsQueryListRequest:
    regionID: str  # 资源池 ID
    service: str  # 服务，见事件监控：查询服务维度接口返回。
    dimension: str  # 维度，见事件监控：查询服务维度接口返回。
    startTime: int  # 查询起始时间戳
    endTime: int  # 查询截止时间戳
    eventNameList: Optional[List[str]] = None  # 本参数表示事件指标列表，事件指标见查询事件接口返回。不传，默认全部事件指标
    pageNo: Optional[int] = None  # 页码，默认为1
    pageSize: Optional[int] = None  # 页大小，默认为20
    resGroupID: Optional[str] = None  # 资源分组ID，在资源分组事件时传入



@dataclass_json
@dataclass
class V4MonitorEventsQueryListResponse:
    statusCode: Optional[int] = None
    error: Optional[str] = None
    message: Optional[str] = None
    description: Optional[str] = None
    errorCode: Optional[str] = None
    returnObj: Optional['V4MonitorEventsQueryListReturnObj'] = None


@dataclass_json
@dataclass
class V4MonitorEventsQueryListReturnObj:
    totalCount: Optional[int] = None  # 获取对象数据条数
    totalPage: Optional[int] = None  # 总页数
    currentCount: Optional[int] = None  # 当前页记录数
    eventList: Optional[List[object]] = None  # 事件列表



