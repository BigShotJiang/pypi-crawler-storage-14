from typing import Optional, List
from dataclasses_json import dataclass_json
from dataclasses import dataclass


@dataclass_json
@dataclass
class V41MonitorChangeAlarmRulesStatusRequest:
    regionID: str  # 资源池ID
    status: int  # 本参数表示告警规则状态。取值范围：<br>0：启用。<br>1：停用。<br>根据以上范围取值。
    alarmRuleIDList: List[str]  # 告警规则ID列表



@dataclass_json
@dataclass
class V41MonitorChangeAlarmRulesStatusResponse:
    statusCode: Optional[int] = None
    error: Optional[str] = None
    message: Optional[str] = None
    description: Optional[str] = None
    errorCode: Optional[str] = None
    returnObj: Optional['V41MonitorChangeAlarmRulesStatusReturnObj'] = None


@dataclass_json
@dataclass
class V41MonitorChangeAlarmRulesStatusReturnObj:
    success: Optional[bool] = None  # 是否成功



