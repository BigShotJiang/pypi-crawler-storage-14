from typing import Optional, List
from dataclasses_json import dataclass_json
from dataclasses import dataclass


@dataclass_json
@dataclass
class V4MonitorHybridBoardDeleteRequest:
    boardIDs: List[str]  # 监控大盘ID



@dataclass_json
@dataclass
class V4MonitorHybridBoardDeleteResponse:
    statusCode: Optional[int] = None
    error: Optional[str] = None
    message: Optional[str] = None
    description: Optional[str] = None
    errorCode: Optional[str] = None
    returnObj: Optional['V4MonitorHybridBoardDeleteReturnObj'] = None


@dataclass_json
@dataclass
class V4MonitorHybridBoardDeleteReturnObj:
    success: Optional[bool] = None  # 是否删除成功



