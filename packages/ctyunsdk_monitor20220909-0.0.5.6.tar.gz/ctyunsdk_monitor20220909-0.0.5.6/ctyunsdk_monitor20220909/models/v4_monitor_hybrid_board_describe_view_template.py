from typing import Optional, List
from dataclasses_json import dataclass_json
from dataclasses import dataclass


@dataclass_json
@dataclass
class V4MonitorHybridBoardDescribeViewTemplateRequest:
    viewTemplateID: str  # 模板ID



@dataclass_json
@dataclass
class V4MonitorHybridBoardDescribeViewTemplateResponse:
    statusCode: Optional[int] = None
    error: Optional[str] = None
    message: Optional[str] = None
    description: Optional[str] = None
    errorCode: Optional[str] = None
    returnObj: Optional['V4MonitorHybridBoardDescribeViewTemplateReturnObj'] = None


@dataclass_json
@dataclass
class V4MonitorHybridBoardDescribeViewTemplateReturnObj:
    viewTemplateID: Optional[str] = None  # 模板ID
    name: Optional[str] = None  # 模板名称
    description: Optional[str] = None  # 模板描述
    views: Optional[List['V4MonitorHybridBoardDescribeViewTemplateReturnObjViews']] = None  # 模板视图内容


@dataclass_json
@dataclass
class V4MonitorHybridBoardDescribeViewTemplateReturnObjViews:
    name: Optional[str] = None  # 监控视图名称
    type: Optional[str] = None  # 视图类型。取值范围:<br>timeSeries：折线图。<br>barChart：柱状图。<br>根据以上范围取值。
    description: Optional[str] = None  # 视图描述
    createTime: Optional[int] = None  # 创建时间，时间戳，精确到秒
    updateTime: Optional[int] = None  # 最近更新时间, 时间戳，精确到秒
    datasource: Optional['V4MonitorHybridBoardDescribeViewTemplateReturnObjViewsDatasource'] = None  # 数据源
    fieldConfig: Optional['V4MonitorHybridBoardDescribeViewTemplateReturnObjViewsFieldConfig'] = None  # 字段配置
    targets: Optional[List['V4MonitorHybridBoardDescribeViewTemplateReturnObjViewsTargets']] = None


@dataclass_json
@dataclass
class V4MonitorHybridBoardDescribeViewTemplateReturnObjViewsDatasource:
    type: Optional[str] = None  # 数据类型。取值范围:<br>prometheus<br>根据以上范围取值。
    namespace: Optional[str] = None  # 指标仓库名称


@dataclass_json
@dataclass
class V4MonitorHybridBoardDescribeViewTemplateReturnObjViewsFieldConfig:
    defaults: Optional['V4MonitorHybridBoardDescribeViewTemplateReturnObjViewsFieldConfigDefaults'] = None  # 默认配置


@dataclass_json
@dataclass
class V4MonitorHybridBoardDescribeViewTemplateReturnObjViewsFieldConfigDefaults:
    unit: Optional[str] = None  # 单位


@dataclass_json
@dataclass
class V4MonitorHybridBoardDescribeViewTemplateReturnObjViewsTargets:
    expr: Optional[str] = None  # prometheus表达式
    legendFormat: Optional[str] = None  # 图例格式化
    period: Optional[int] = None  # 周期



