from typing import Optional, List
from dataclasses_json import dataclass_json
from dataclasses import dataclass


@dataclass_json
@dataclass
class V4MonitorHybridBoardCreateViewRequest:
    boardID: str  # 监控大盘ID
    views: List['V4MonitorHybridBoardCreateViewRequestViews']  # 监控视图
    viewsQueryParams: Optional['V4MonitorHybridBoardCreateViewRequestViewsQueryParams'] = None  # 视图查询参数
    defaultDatasource: Optional['V4MonitorHybridBoardCreateViewRequestDefaultDatasource'] = None  # 默认数据源，如果views中datasource下的namespace配置了$namespace，则会自动替换为本配置值


@dataclass_json
@dataclass
class V4MonitorHybridBoardCreateViewRequestViewsQueryParams:
    job: Optional[List[str]] = None  # 任务，默认查询所有


@dataclass_json
@dataclass
class V4MonitorHybridBoardCreateViewRequestDefaultDatasource:
    type: str  # 数据类型。取值范围:<br>prometheus<br>根据以上范围取值。
    namespace: str  # 指标仓库名称，支持使用$namespace来自动替换为defaultDatasource的仓库名称


@dataclass_json
@dataclass
class V4MonitorHybridBoardCreateViewRequestViews:
    name: str  # 监控大盘视图名称
    type: str  # 视图类型。取值范围:<br>timeSeries：折线图。<br>barChart：柱状图。<br>table：表格。<br>根据以上范围取值。
    datasource: 'V4MonitorHybridBoardCreateViewRequestViewsDatasource'  # 数据源
    fieldConfig: 'V4MonitorHybridBoardCreateViewRequestViewsFieldConfig'  # 字段配置
    targets: List['V4MonitorHybridBoardCreateViewRequestViewsTargets']
    description: Optional[str] = None  # 视图描述


@dataclass_json
@dataclass
class V4MonitorHybridBoardCreateViewRequestViewsDatasource:
    type: str  # 数据类型。取值范围:<br>prometheus<br>根据以上范围取值。
    namespace: str  # 指标仓库名称，支持使用$namespace来自动替换为defaultDatasource的仓库名称


@dataclass_json
@dataclass
class V4MonitorHybridBoardCreateViewRequestViewsFieldConfig:
    defaults: 'V4MonitorHybridBoardCreateViewRequestViewsFieldConfigDefaults'  # 默认配置


@dataclass_json
@dataclass
class V4MonitorHybridBoardCreateViewRequestViewsFieldConfigDefaults:
    unit: str  # 单位


@dataclass_json
@dataclass
class V4MonitorHybridBoardCreateViewRequestViewsTargets:
    expr: str  # prometheus表达式
    legendFormat: Optional[str] = None  # 图例格式化
    period: Optional[int] = None  # 周期



@dataclass_json
@dataclass
class V4MonitorHybridBoardCreateViewResponse:
    statusCode: Optional[int] = None
    error: Optional[str] = None
    message: Optional[str] = None
    description: Optional[str] = None
    errorCode: Optional[str] = None
    returnObj: Optional['V4MonitorHybridBoardCreateViewReturnObj'] = None


@dataclass_json
@dataclass
class V4MonitorHybridBoardCreateViewReturnObj:
    viewIDs: Optional[List[str]] = None  # 视图ID



