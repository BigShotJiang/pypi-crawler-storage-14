var dmcfuncs = window.dashMantineFunctions = window.dashMantineFunctions || {};
var dmc = window.dash_mantine_components;
var iconify = window.dash_iconify;


dmcfuncs.renderOptionSelect = function ({ option, checked }) {

  const icons = {
   var: React.createElement(iconify.DashIconify, { icon: "mdi:input", width: 24 }),
   obj: React.createElement(iconify.DashIconify, { icon: "mdi:target", width: 24 }),
   con: React.createElement(iconify.DashIconify, { icon: "mdi:border-style", width: 24 }),
   obs: React.createElement(iconify.DashIconify, { icon: "mdi:eye", width: 24 }),
   set: React.createElement(iconify.DashIconify, { icon: "mdi:code-braces", width: 24 }),
  };

  const checkedIcon = React.createElement(iconify.DashIconify, {
    icon: "mdi:check",
    width: 24,
  });

  return React.createElement(
    dmc.Group,
    { flex: "1", gap: "xs" },
    icons[option.type],
    option.label,
    checked ? checkedIcon : null
  );
};
