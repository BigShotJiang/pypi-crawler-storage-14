"""
Examples demonstrating the use of optimization result converters.

This script shows how to convert results from scipy and other optimizers
into optiscope's OptimizationResult format.
"""

import numpy as np
from scipy.optimize import differential_evolution, least_squares, minimize

from optiscope.utils.converters import (
    from_custom_optimizer,
    from_optimization_history,
    from_scipy_differential_evolution,
    from_scipy_least_squares,
    from_scipy_minimize,
)


def example_scipy_minimize():
    """Example: Converting scipy.optimize.minimize result."""
    print("=" * 70)
    print("Example 1: scipy.optimize.minimize")
    print("=" * 70)

    # Define a simple optimization problem
    def rosenbrock(x):
        return (1 - x[0]) ** 2 + 100 * (x[1] - x[0] ** 2) ** 2

    # Solve with scipy
    result = minimize(rosenbrock, x0=[0, 0], method="BFGS")

    # Convert to OptimizationResult
    opt_result = from_scipy_minimize(
        result,
        problem_name="Rosenbrock Function",
        variable_names=["x", "y"],
        objective_name="rosenbrock",
        bounds=[(-5, 5), (-5, 5)],
        description="Classic Rosenbrock optimization problem",
    )

    print(opt_result)
    print(f"\nOptimal solution: {opt_result.design_variables}")
    print(f"Objective value: {opt_result.objectives}")
    print(f"\nMetadata: {opt_result.problem_metadata.metadata}")
    print()


def example_scipy_minimize_with_constraints():
    """Example: scipy.optimize.minimize with constraints."""
    print("=" * 70)
    print("Example 2: scipy.optimize.minimize with constraints")
    print("=" * 70)

    # Define problem with constraints
    def objective(x):
        return x[0] ** 2 + x[1] ** 2

    def constraint1(x):
        return x[0] + x[1] - 1  # x + y >= 1

    def constraint2(x):
        return x[0] - x[1]  # x >= y

    # Solve
    constraints = [
        {"type": "ineq", "fun": constraint1},
        {"type": "ineq", "fun": constraint2},
    ]

    result = minimize(objective, x0=[1, 1], constraints=constraints, method="SLSQP")

    # Evaluate constraints at solution
    x_opt = result.x
    c1_val = constraint1(x_opt)
    c2_val = constraint2(x_opt)

    # Convert to OptimizationResult
    opt_result = from_scipy_minimize(
        result,
        problem_name="Constrained Quadratic",
        variable_names=["x", "y"],
        objective_name="sum_of_squares",
        bounds=[(-10, 10), (-10, 10)],
        constraints_info=[
            {"name": "c1", "type": "ineq", "value": c1_val, "description": "x + y >= 1"},
            {"name": "c2", "type": "ineq", "value": c2_val, "description": "x >= y"},
        ],
    )

    print(opt_result)
    print(f"\nOptimal solution: {opt_result.design_variables}")
    print(f"Objective value: {opt_result.objectives}")
    print(f"Constraints: {opt_result.inequality_constraints}")
    print()


def example_differential_evolution():
    """Example: Converting scipy.optimize.differential_evolution result."""
    print("=" * 70)
    print("Example 3: scipy.optimize.differential_evolution")
    print("=" * 70)

    # Define Rastrigin function
    def rastrigin(x):
        return 10 * len(x) + sum(xi**2 - 10 * np.cos(2 * np.pi * xi) for xi in x)

    # Solve with differential evolution
    bounds = [(-5.12, 5.12), (-5.12, 5.12), (-5.12, 5.12)]
    result = differential_evolution(rastrigin, bounds, seed=42, maxiter=100)

    # Convert to OptimizationResult
    opt_result = from_scipy_differential_evolution(
        result,
        problem_name="Rastrigin Function",
        variable_names=["x1", "x2", "x3"],
        objective_name="rastrigin",
        bounds=bounds,
        description="Global optimization of Rastrigin function",
    )

    print(opt_result)
    print(f"\nOptimal solution: {opt_result.design_variables}")
    print(f"Objective value: {opt_result.objectives}")
    print()


def example_least_squares():
    """Example: Converting scipy.optimize.least_squares result."""
    print("=" * 70)
    print("Example 4: scipy.optimize.least_squares")
    print("=" * 70)

    # Define residual function (curve fitting)
    def residuals(params, x_data, y_data):
        a, b, c = params
        return y_data - (a * x_data**2 + b * x_data + c)

    # Generate some data
    x_data = np.linspace(0, 10, 50)
    y_true = 2 * x_data**2 + 3 * x_data + 1
    y_data = y_true + np.random.normal(0, 5, size=len(x_data))

    # Solve
    result = least_squares(residuals, x0=[1, 1, 1], args=(x_data, y_data))

    # Convert to OptimizationResult
    opt_result = from_scipy_least_squares(
        result,
        problem_name="Quadratic Curve Fitting",
        variable_names=["a", "b", "c"],
        bounds=[(0, 10), (0, 10), (-10, 10)],
        description="Fitting quadratic curve to noisy data",
    )

    print(opt_result)
    print(f"\nOptimal parameters: {opt_result.design_variables}")
    print(f"Cost: {opt_result.objectives}")
    print()


def example_optimization_history():
    """Example: Converting optimization history arrays."""
    print("=" * 70)
    print("Example 5: Optimization history from custom optimizer")
    print("=" * 70)

    # Simulate optimization history
    n_iterations = 50
    n_vars = 3
    n_objectives = 2
    n_constraints = 1

    # Generate fake history (converging to optimum)
    x_history = np.random.randn(n_iterations, n_vars) * np.linspace(10, 0.1, n_iterations)[:, None]
    f_history = (
        np.random.rand(n_iterations, n_objectives) * np.linspace(100, 1, n_iterations)[:, None]
    )
    g_history = (
        np.random.randn(n_iterations, n_constraints) * np.linspace(5, 0.1, n_iterations)[:, None]
    )

    # Convert to OptimizationResult
    opt_result = from_optimization_history(
        x_history=x_history,
        f_history=f_history,
        g_history=g_history,
        problem_name="Multi-objective Optimization",
        variable_names=["design_1", "design_2", "design_3"],
        objective_names=["cost", "weight"],
        constraint_names=["stress"],
        constraint_types=["ineq"],
        solver_name="CustomGeneticAlgorithm",
        description="Multi-objective optimization with constraints",
    )

    print(opt_result)
    print(f"\nNumber of iterations: {opt_result.n_points}")
    print(f"Design variables shape: {opt_result.design_variables.shape}")
    print(f"Objectives shape: {opt_result.objectives.shape}")
    print(f"Constraints shape: {opt_result.inequality_constraints.shape}")
    print()


def example_custom_optimizer():
    """Example: Converting custom optimizer result."""
    print("=" * 70)
    print("Example 6: Custom optimizer result")
    print("=" * 70)

    # Simulate custom optimizer output
    x_opt = np.array([1.5, 2.3, -0.5])
    f_opt = 42.7

    # Convert to OptimizationResult
    opt_result = from_custom_optimizer(
        x_opt=x_opt,
        f_opt=f_opt,
        problem_name="Engineering Design",
        variable_names=["length", "width", "height"],
        objective_names=["total_cost"],
        solver_name="ProprietaryOptimizer",
        n_evaluations=1000,
        computation_time=15.3,
        success=True,
        message="Converged successfully",
    )

    print(opt_result)
    print(f"\nOptimal solution: {opt_result.design_variables}")
    print(f"Objective value: {opt_result.objectives}")
    print(f"\nSummary: {opt_result.summary()}")
    print()


def example_save_and_load():
    """Example: Save and load converted results."""
    print("=" * 70)
    print("Example 7: Save and load converted results")
    print("=" * 70)

    # Create a simple result
    result = minimize(lambda x: x[0] ** 2 + x[1] ** 2, x0=[5, 5])
    opt_result = from_scipy_minimize(
        result, problem_name="Simple Quadratic", variable_names=["x", "y"]
    )

    # Save to JSON
    from optiscope.io import JSONHandler

    handler = JSONHandler()
    handler.write(opt_result, "/tmp/scipy_result.json")
    print("Saved to /tmp/scipy_result.json")

    # Load back
    loaded_result = handler.read("/tmp/scipy_result.json")
    print(f"Loaded result: {loaded_result}")
    print(f"Design variables: {loaded_result.design_variables}")
    print()


if __name__ == "__main__":
    example_scipy_minimize()
    example_scipy_minimize_with_constraints()
    example_differential_evolution()
    example_least_squares()
    example_optimization_history()
    example_custom_optimizer()
    example_save_and_load()

    print("=" * 70)
    print("All examples completed successfully!")
    print("=" * 70)
