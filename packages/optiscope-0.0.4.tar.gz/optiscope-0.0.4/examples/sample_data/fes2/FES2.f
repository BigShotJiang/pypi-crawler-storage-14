CCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCC
C
C     This is an example call of MIDACO 6.0
C     -------------------------------------
C
C     MIDACO solves Multi-Objective Mixed-Integer Non-Linear Problems:
C
C
C      Minimize     F_1(X),... F_O(X)  where X(1,...N-NI)   is CONTINUOUS
C                                      and   X(N-NI+1,...N) is DISCRETE
C
C      subject to   G_j(X)  =  0   (j=1,...ME)      equality constraints
C                   G_j(X) >=  0   (j=ME+1,...M)  inequality constraints
C
C      and bounds   XL <= X <= XU
C
C
C     The problem statement of this example is given below. You can use 
C     this example as template to run your own problem. To do so: Replace 
C     the objective functions 'F' (and in case the constraints 'G') given 
C     here with your own problem and follow the below instruction steps.
C
CCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCC
CCCCCCCCCCCCCCCCCCCCCCCCC   MAIN PROGRAM   CCCCCCCCCCCCCCCCCCCCCCCCCCCCC
CCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCC
      PROGRAM MAIN
      IMPLICIT NONE
CCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCC
C     Dimensions of the optimization problem        
      INTEGER O, N, NI, M, ME
C     Lower and upper bounds ('XL' & 'XU') and optimization variable 'X'
      DOUBLE PRECISION XL(1000), XU(1000), X(1000)
C     Objectives 'F(X)' and constraints 'G(X)' 
      DOUBLE PRECISION F(10), G(1000)            
C     MIDACO information and stop flags
      INTEGER IFLAG, ISTOP
C     MIDACO parameter
      DOUBLE PRECISION PARAM(13)
C     MIDACO integer 'IW' and real'RW' workspace and pareto front 'PF'
      INTEGER LIW, LRW, LPF 
      PARAMETER (LIW = 5000, LRW = 20000, LPF = 200000)       
      INTEGER IW(LIW)
      DOUBLE PRECISION RW(LRW),PF(LPF)
C     Parameter for stopping criteria, printing and license
      INTEGER MAXTIME, MAXEVAL, PRINTEVAL, SAVE2FILE, I
      CHARACTER*60 KEY
      KEY='MIDACO_LIMITED_VERSION___[CREATIVE_COMMONS_BY-NC-ND_LICENSE]'
CCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCC
CCC Step 1: Problem definition     CCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCC
CCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCC
C
C     Step 1.A : Problem dimensions
C     CCCCCCCCCCCCCCCCCCCCCCCCCCCCC
      O  = 3  ! Number of objectives
      N  = 2  ! Number of variables (in total)
      NI = 0  ! Number of integer variables (0 <= NI <= N)
      M  = 0  ! Number of constraints (in total)
      ME = 0  ! Number of equality constraints (0 <= ME <= M)
C
C     Step 1.B : Lower and upper bounds: 'XL' and 'XU'
C     CCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCC
      DO I = 1,N
         XL(I) = 0.0D0
         XU(I) = 1.0D0
      ENDDO
C         
C     Step 1.C : Starting point 'X'
C     CCCCCCCCCCCCCCCCCCCCCCCCCCCCC     
      DO I = 1,N          
          X(I) = XL(I) ! Here for example: starting point = lower bounds
      ENDDO
      
CCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCC
CCC Step 2: Choose stopping criteria and printing options    CCCCCCCCCCC
CCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCC
C
C     Step 2.A : Stopping criteria
C     CCCCCCCCCCCCCCCCCCCCCCCCCCCC
      MAXEVAL = 100000    ! Maximum evaluation budget (e.g. 1000000)
      MAXTIME = 60*60*24 ! Maximum time limit (e.g. 60*60*24 = 1 Day)
C
C     Step 2.B : Printing options
C     CCCCCCCCCCCCCCCCCCCCCCCCCCC
      PRINTEVAL = 10000 ! Print-Frequency for current best solution (e.g. 1000)
      SAVE2FILE = 999999    ! Save SCREEN and SOLUTION to TXT-files [0=NO/1=YES]
      
CCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCC
CCC Step 3: Choose MIDACO parameters (FOR ADVANCED USERS)    CCCCCCCCCCC
CCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCC

      PARAM( 1) = 0.0D0  ! ACCURACY
      PARAM( 2) = 0.0D0  ! SEED
      PARAM( 3) = 0.0D0  ! FSTOP
      PARAM( 4) = 0.0D0  ! ALGOSTOP
      PARAM( 5) = 0.0D0  ! EVALSTOP
      PARAM( 6) = 0.0D0  ! FOCUS
      PARAM( 7) = 0.0D0  ! ANTS
      PARAM( 8) = 0.0D0  ! KERNEL
      PARAM( 9) = 0.0D0  ! ORACLE
      PARAM(10) = 30000.0D0  ! PARETOMAX
      PARAM(11) = 0.00001D0  ! EPSILON  
      PARAM(12) = 0.0D0  ! BALANCE
      PARAM(13) = 0.0D0  ! CHARACTER 

CCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCC
C         
C       Call MIDACO by Reverse Communication
C      
CCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCC
C     Print MIDACO headline with basic information
      CALL MIDACO_PRINT(1,PRINTEVAL,SAVE2FILE,IFLAG,ISTOP,F,G,X,XL,
     &         XU,O,N,NI,M,ME,RW,PF,MAXEVAL,MAXTIME,PARAM,1,0,KEY)             
      DO WHILE(ISTOP.EQ.0) !~~~Start~of~reverse~communication~loop  

C       Evaluate Objective F(X) and constraints G(X)
        CALL PROBLEM_FUNCTION( F, G , X)   
        
C       Call MIDACO
        CALL MIDACO(1,O,N,NI,M,ME,X,F,G,XL,XU,IFLAG,
     &              ISTOP,PARAM,RW,LRW,IW,LIW,PF,LPF,KEY)            
C       Call MIDACO printing routine
        CALL MIDACO_PRINT(2,PRINTEVAL,SAVE2FILE,IFLAG,ISTOP,F,G,X,
     &     XL,XU,O,N,NI,M,ME,RW,PF,MAXEVAL,MAXTIME,PARAM,1,0,KEY)     
      ENDDO !~~~~~~~~~~~~~~~~~~~~End~of~reverse~communication~loop  
CCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCC
      ! PRINT*," Solution F(1) = ", F(1)
      ! PRINT*," Solution G(1) = ", G(1)
      ! PRINT*," Solution X(1) = ", X(1)            
CCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCC
      END
CCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCC
CCCCCCCCCCCCCCCCCCCCCCCCCCCC END OF MAIN CCCCCCCCCCCCCCCCCCCCCCCCCCCCCCC
CCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCC




CCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCC
CCCCCCCCCCCCCCCCCCCCCC   OPTIMIZATION PROBLEM   CCCCCCCCCCCCCCCCCCCCCCCC
CCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCC
      SUBROUTINE PROBLEM_FUNCTION(F,G,X)
CCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCC
      IMPLICIT NONE
CCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCC
      DOUBLE PRECISION F(*),G(*),X(*), pi
      integer n,i
CCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCC

      n = 2

      pi = 4.d0*atan(1.d0)

      f(1) = 0.d0
      f(2) = 0.d0  
      f(3) = 0.d0            

      do i = 1,n
        f(1) = f(1) 
     &   + ((x(i)-0.5d0*cos(10.d0*pi*(dble(i)/dble(n)))-0.5d0)**2.d0)
        f(2) = f(2) 
     &   + (abs(x(i)-sin(dble(i-1))**2.d0*cos(dble(i-1))**2.d0)**0.5d0)
        f(3) = f(3) 
     & + (abs(x(i)-0.25d0*cos(dble(i-1))*cos(dble(2*i-2))-0.5d0)**0.5d0)
      enddo

      END
CCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCC
CCCCCCCCCCCCCCCCCCCCCCCCCCCC END OF FILE CCCCCCCCCCCCCCCCCCCCCCCCCCCCCCC
CCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCC

