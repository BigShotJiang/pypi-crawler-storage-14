"""
Advanced features example: SPLOM, Knee Detection, and TOPSIS.

Demonstrates the newly implemented sophisticated analysis and visualization tools.
"""

from pathlib import Path

import numpy as np
import pandas as pd

from optiscope import OptimizationResult, ProblemMetadata
from optiscope.analysis import (
    compare_weight_scenarios,
    detect_knee_points,
    find_knee_region,
    sensitivity_analysis_topsis,
    smart_pareto_filter,
    topsis_from_result,
)
from optiscope.core import DesignVariable, Objective, OptimizationDirection
from optiscope.plotting import (
    plot_correlation_heatmap,
    plot_pareto_front_2d,
    plot_scatter_matrix,
)


def generate_test_problem(n_points: int = 200, seed: int = 42):
    """Generate synthetic multi-objective optimization problem."""
    np.random.seed(seed)

    # Design variables
    x1 = np.random.uniform(0, 10, n_points)
    x2 = np.random.uniform(0, 10, n_points)
    x3 = np.random.uniform(0, 10, n_points)
    x4 = np.random.uniform(0, 10, n_points)

    # Objectives (ZDT-like with 3 objectives)
    f1 = x1
    g = 1 + 9 * (x2 + x3 + x4) / 3
    h1 = 1 - np.sqrt(f1 / g)
    h2 = 1 - (f1 / g) ** 2
    f2 = g * h1
    f3 = g * h2

    # Add some noise
    f2 += np.random.normal(0, 0.1, n_points)
    f3 += np.random.normal(0, 0.1, n_points)

    # Constraints
    g1 = x1 + x2 - 12  # inequality
    h1_const = x3 - x4  # equality

    # Create result
    result = OptimizationResult(
        problem_metadata=ProblemMetadata(
            name="3-Objective Test Problem",
            solver="Random Sampling",
            n_design_variables=4,
            n_objectives=3,
            n_inequality_constraints=1,
            n_equality_constraints=1,
            n_evaluations=n_points,
        ),
        design_variables=pd.DataFrame(
            {"x1_width": x1, "x2_height": x2, "x3_depth": x3, "x4_thickness": x4}
        ),
        objectives=pd.DataFrame({"f1_cost": f1, "f2_weight": f2, "f3_volume": f3}),
        inequality_constraints=pd.DataFrame({"g1_size": g1}),
        equality_constraints=pd.DataFrame({"h1_balance": h1_const}),
    )

    # Add metadata
    result.add_variable_metadata(
        DesignVariable(name="x1_width", units="cm", lower_bound=0, upper_bound=10)
    )
    result.add_variable_metadata(
        DesignVariable(name="x2_height", units="cm", lower_bound=0, upper_bound=10)
    )
    result.add_variable_metadata(
        DesignVariable(name="x3_depth", units="cm", lower_bound=0, upper_bound=10)
    )
    result.add_variable_metadata(
        DesignVariable(name="x4_thickness", units="mm", lower_bound=0, upper_bound=10)
    )

    result.add_variable_metadata(
        Objective(name="f1_cost", units="$", direction=OptimizationDirection.MINIMIZE)
    )
    result.add_variable_metadata(
        Objective(name="f2_weight", units="kg", direction=OptimizationDirection.MINIMIZE)
    )
    result.add_variable_metadata(
        Objective(name="f3_volume", units="cm³", direction=OptimizationDirection.MINIMIZE)
    )

    return result


def example_1_scatter_matrix(result: OptimizationResult):
    """Example 1: Interactive scatter matrix (SPLOM)."""
    print("\n" + "=" * 70)
    print("EXAMPLE 1: Scatter Plot Matrix (SPLOM)")
    print("=" * 70)

    # Create scatter matrix with all variables
    print("\n1. Creating scatter matrix with objectives and design variables...")

    fig = plot_scatter_matrix(
        result,
        include_objectives=True,
        include_design_vars=True,
        max_vars=6,  # Limit to 6 for readability
        highlight_feasible=True,  # Color by feasibility
        show_distributions=True,
        show_correlations=True,
        marker_size=4,
    )

    # Save figure
    output_dir = Path("example_output/advanced_features")
    output_dir.mkdir(parents=True, exist_ok=True)
    fig.write_html(output_dir / "scatter_matrix.html")
    print(f"   Saved: {output_dir / 'scatter_matrix.html'}")

    # Create correlation heatmap
    print("\n2. Creating correlation heatmap...")

    fig_corr = plot_correlation_heatmap(
        result, include_objectives=True, include_design_vars=True, method="pearson"
    )

    fig_corr.write_html(output_dir / "correlation_heatmap.html")
    print(f"   Saved: {output_dir / 'correlation_heatmap.html'}")

    print("\n✓ Scatter matrix analysis completed!")


def example_2_knee_detection(result: OptimizationResult):
    """Example 2: Knee point detection."""
    print("\n" + "=" * 70)
    print("EXAMPLE 2: Knee Point Detection")
    print("=" * 70)

    # Assume we have a Pareto front (for demo, we'll filter first)
    print("\n1. Filtering to Pareto-like solutions...")

    # Simple Pareto approximation for demo
    pareto_indices = smart_pareto_filter(
        result.objectives[["f1_cost", "f2_weight"]],  # Use 2D for knee detection
        epsilon=0.15,
    )

    result.create_set(name="pareto_approx", indices=pareto_indices, created_by="smart_filter")
    print(f"   Pareto approximation: {len(pareto_indices)} points")

    # Detect knee points
    print("\n2. Detecting knee points...")

    pareto_objectives = result.objectives[["f1_cost", "f2_weight"]].iloc[pareto_indices]

    # Try different methods
    methods = ["angle", "distance", "tradeoff"]
    knee_results = {}

    for method in methods:
        knee_idx = detect_knee_points(pareto_objectives, method=method, n_knees=3)
        # Convert to original indices
        original_knee_idx = pareto_indices[knee_idx]
        knee_results[method] = original_knee_idx
        print(f"   {method.capitalize()} method: {len(knee_idx)} knees detected")

    # Use angle method for visualization
    knee_indices = knee_results["angle"]
    result.create_set(
        name="knee_points", indices=knee_indices, created_by="knee_detection", color="#FF6B6B"
    )

    # Find knee region
    print("\n3. Finding knee region...")
    region_indices, region_start, region_end = find_knee_region(
        pareto_objectives, width=0.15, method="angle"
    )
    original_region_idx = pareto_indices[region_indices]

    result.create_set(
        name="knee_region", indices=original_region_idx, created_by="knee_region", color="#FFD93D"
    )
    print(f"   Knee region: {len(region_indices)} points")

    # Visualize
    print("\n4. Visualizing Pareto front with knee points...")

    fig = plot_pareto_front_2d(
        result,
        obj_x="f1_cost",
        obj_y="f2_weight",
        pareto_set="pareto_approx",
        additional_sets=["knee_points", "knee_region"],
        show_dominated=True,
        show_ideal_nadir=True,
    )

    output_dir = Path("example_output/advanced_features")
    fig.write_html(output_dir / "knee_detection.html")
    print(f"   Saved: {output_dir / 'knee_detection.html'}")

    # Print knee point details
    print("\n5. Knee point details:")
    for i, idx in enumerate(knee_indices):
        print(f"\n   Knee {i + 1} (index {idx}):")
        print(f"      Cost:   {result.objectives.loc[idx, 'f1_cost']:.3f} $")
        print(f"      Weight: {result.objectives.loc[idx, 'f2_weight']:.3f} kg")
        print(f"      Volume: {result.objectives.loc[idx, 'f3_volume']:.3f} cm³")

    print("\n✓ Knee detection completed!")


def example_3_topsis(result: OptimizationResult):
    """Example 3: TOPSIS ranking."""
    print("\n" + "=" * 70)
    print("EXAMPLE 3: TOPSIS Multi-Criteria Decision Making")
    print("=" * 70)

    # Scenario 1: Equal weights
    print("\n1. TOPSIS with equal weights...")

    topsis_equal = topsis_from_result(
        result,
        weights=None,  # Equal weights
        return_details=True,
    )

    print("   Top 5 solutions (equal weights):")
    for i, idx in enumerate(topsis_equal["ranks"][:5]):
        print(f"      {i + 1}. Solution {idx}: score = {topsis_equal['scores'][idx]:.4f}")

    # Create set for top solutions
    top_10_equal = topsis_equal["ranks"][:10]
    result.create_set(name="topsis_top10_equal", indices=top_10_equal.tolist(), created_by="topsis")

    # Scenario 2: Cost-focused weights
    print("\n2. TOPSIS with cost-focused weights...")

    topsis_cost = topsis_from_result(
        result, weights={"f1_cost": 0.6, "f2_weight": 0.25, "f3_volume": 0.15}, return_details=True
    )

    print("   Top 5 solutions (cost-focused):")
    for i, idx in enumerate(topsis_cost["ranks"][:5]):
        print(f"      {i + 1}. Solution {idx}: score = {topsis_cost['scores'][idx]:.4f}")

    # Scenario 3: Weight-focused
    print("\n3. TOPSIS with weight-focused weights...")

    topsis_weight = topsis_from_result(
        result, weights={"f1_cost": 0.2, "f2_weight": 0.6, "f3_volume": 0.2}, return_details=True
    )

    print("   Top 5 solutions (weight-focused):")
    for i, idx in enumerate(topsis_weight["ranks"][:5]):
        print(f"      {i + 1}. Solution {idx}: score = {topsis_weight['scores'][idx]:.4f}")

    # Compare scenarios
    print("\n4. Comparing weight scenarios...")

    scenarios = {
        "equal": np.array([1 / 3, 1 / 3, 1 / 3]),
        "cost_focused": np.array([0.6, 0.25, 0.15]),
        "weight_focused": np.array([0.2, 0.6, 0.2]),
        "volume_focused": np.array([0.15, 0.25, 0.6]),
    }

    comparison = compare_weight_scenarios(
        result.objectives, scenarios, directions=["min", "min", "min"]
    )

    print("\n   Top 10 solutions comparison:")
    print(comparison.nsmallest(10, "avg_rank")[["avg_score", "avg_rank", "std_rank"]])

    # Sensitivity analysis
    print("\n5. Performing sensitivity analysis...")

    sensitivity = sensitivity_analysis_topsis(
        result.objectives,
        base_weights=np.array([1 / 3, 1 / 3, 1 / 3]),
        directions=["min", "min", "min"],
        perturbation=0.2,
        n_samples=100,
    )

    print("\n   Sensitivity Analysis Results:")
    print(f"      Most stable solution: {sensitivity['most_stable_solution']}")
    print(f"      Least stable solution: {sensitivity['least_stable_solution']}")
    print(f"      Average rank std dev: {sensitivity['avg_rank_std']:.2f}")

    # Show top-5 stability
    print("\n   Top-5 appearance frequency:")
    top_5_stable = sensitivity["top_k_stability"]["top_5"]
    stable_indices = np.argsort(top_5_stable)[::-1][:10]
    for idx in stable_indices:
        print(f"      Solution {idx}: {top_5_stable[idx] * 100:.1f}% of runs")

    print("\n✓ TOPSIS analysis completed!")


def main():
    """Run all advanced feature examples."""
    print("=" * 70)
    print("OPTISCOPE ADVANCED FEATURES DEMONSTRATION")
    print("=" * 70)

    # Generate test problem
    print("\nGenerating test problem...")
    result = generate_test_problem(n_points=200)
    print(f"Created problem: {result.problem_metadata.name}")
    print(f"  - {result.n_points} solutions")
    print(f"  - {len(result.objectives.columns)} objectives")
    print(f"  - {len(result.design_variables.columns)} design variables")

    # Run examples
    example_1_scatter_matrix(result)
    example_2_knee_detection(result)
    example_3_topsis(result)

    print("\n" + "=" * 70)
    print("ALL EXAMPLES COMPLETED!")
    print("=" * 70)
    print("\nOutput files saved to: example_output/advanced_features/")
    print("  - scatter_matrix.html")
    print("  - correlation_heatmap.html")
    print("  - knee_detection.html")


if __name__ == "__main__":
    main()
