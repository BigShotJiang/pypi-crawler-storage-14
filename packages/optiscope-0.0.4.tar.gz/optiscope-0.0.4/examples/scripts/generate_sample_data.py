import os

import numpy as np
import pandas as pd


def generate_sample_csv(filename="sample_optimization_data2.csv", num_rows=100):
    """
    Generates a sample CSV file with optimization data.

    The CSV will contain columns for design variables (x1, x2),
    objectives (f1, f2), and a constraint (g1).
    """

    # Design variables
    x1 = np.random.rand(num_rows) * 10
    x2 = np.random.rand(num_rows) * 5

    # Objectives (example: minimizing f1 and f2)
    f1 = x1**2 + x2
    f2 = (x2 - 2) ** 2 + x1

    # Inequality constraint (example: g1 <= 0)
    # Let's make some points feasible and some infeasible
    g1 = x1 + x2 - 7 + np.random.randn(num_rows) * 2

    data = {
        "x:x1": x1,
        "x:x2": x2,
        "f:f1": f1,
        "f:f2": f2,
        "g:g1": g1,
    }

    df = pd.DataFrame(data)

    # Ensure the directory exists
    output_dir = "examples/sample_data"
    os.makedirs(output_dir, exist_ok=True)
    filepath = os.path.join(output_dir, filename)

    df.to_csv(filepath, index=False)
    print(f"Generated sample data to {filepath}")


if __name__ == "__main__":
    generate_sample_csv()
