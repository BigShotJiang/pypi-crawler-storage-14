"""
Plotting examples for optiscope library.

This script demonstrates all available plotting functions in the optiscope package.
Functions demonstrated:
1. Pareto Viewer (2D/3D)
2. Parallel Coordinates
3. Scatter Matrix (SPLOM)
4. Correlation Heatmap
5. Time Series
6. Optimization History
7. Constraints Time Series
"""

import os
from pathlib import Path

import numpy as np
import pandas as pd

from optiscope import (
    Constraint,
    DesignVariable,
    Objective,
    OptimizationResult,
    ProblemMetadata,
)
from optiscope.analysis import detect_knee_points, smart_pareto_filter
from optiscope.core import OptimizationDirection
from optiscope.core.data_types import ConstraintType
from optiscope.plotting import (
    plot_correlation_heatmap,
    # Parallel coordinates
    plot_parallel_coordinates,
    plot_parallel_coordinates_comparison,
    # Pareto front visualization
    plot_pareto_front_2d,
    plot_pareto_front_3d,
    # Scatter matrix
    plot_scatter_matrix,
)
from optiscope.plotting.time_series import (
    plot_constraints_time_series,
    plot_optimization_history,
    plot_time_series,
)


def generate_test_problem(n_points: int = 200, seed: int = 42):
    """Generate synthetic multi-objective optimization problem."""
    np.random.seed(seed)

    # Design variables
    x1 = np.random.uniform(0, 10, n_points)
    x2 = np.random.uniform(0, 10, n_points)
    x3 = np.random.uniform(0, 10, n_points)
    x4 = np.random.uniform(0, 10, n_points)

    # Objectives (ZDT-like with 3 objectives)
    f1 = x1
    g = 1 + 9 * (x2 + x3 + x4) / 3
    h1 = 1 - np.sqrt(f1 / g)
    h2 = 1 - (f1 / g) ** 2
    f2 = g * h1
    f3 = g * h2

    # Add some noise and make the curves more interesting
    f2 += np.random.normal(0, 0.1, n_points)
    f3 += np.random.normal(0, 0.1, n_points)

    # Constraints
    g1 = x1 + x2 - 12  # inequality constraint: g1 <= 0
    g2 = x3 - x4 - 5  # inequality constraint: g2 <= 0
    h1_const = x3 - x4  # equality constraint: h1_const = 0

    # Observables (additional derived quantities)
    total_mass = x1 + x2 + x3 + x4
    efficiency = f1 / (f2 + 1e-6)
    cost = 100 * x1 + 50 * x2 + 75 * x3 + 60 * x4

    # Add iteration history (to simulate optimization iterations)
    iterations = np.arange(n_points)

    # Create result
    result = OptimizationResult(
        problem_metadata=ProblemMetadata(
            name="3-Objective Test Problem",
            description="Synthetic multi-objective optimization test problem",
            solver="Random Sampling",
            n_design_variables=4,
            n_objectives=3,
            n_inequality_constraints=2,
            n_equality_constraints=1,
            n_evaluations=n_points,
            solver_version="1.0",
            computation_time=None,
        ),
        design_variables=pd.DataFrame(
            {
                "x1_width": x1,
                "x2_height": x2,
                "x3_depth": x3,
                "x4_thickness": x4,
                "iteration": iterations,
            }
        ),
        objectives=pd.DataFrame({"f1_cost": f1, "f2_weight": f2, "f3_volume": f3}),
        inequality_constraints=pd.DataFrame(
            {"g1_size_constraint": g1, "g2_dimensional_constraint": g2}
        ),
        equality_constraints=pd.DataFrame({"h1_balance": h1_const}),
        observables=pd.DataFrame(
            {"total_mass": total_mass, "efficiency": efficiency, "cost": cost}
        ),
    )

    # Add metadata
    result.add_variable_metadata(
        DesignVariable(
            name="x1_width",
            description="Width parameter",
            units="cm",
            lower_bound=0,
            upper_bound=10,
            possible_values=None,
            initial_value=None,
        )
    )
    result.add_variable_metadata(
        DesignVariable(
            name="x2_height",
            description="Height parameter",
            units="cm",
            lower_bound=0,
            upper_bound=10,
            possible_values=None,
            initial_value=None,
        )
    )
    result.add_variable_metadata(
        DesignVariable(
            name="x3_depth",
            description="Depth parameter",
            units="cm",
            lower_bound=0,
            upper_bound=10,
            possible_values=None,
            initial_value=None,
        )
    )
    result.add_variable_metadata(
        DesignVariable(
            name="x4_thickness",
            description="Thickness parameter",
            units="mm",
            lower_bound=0,
            upper_bound=10,
            possible_values=None,
            initial_value=None,
        )
    )
    result.add_variable_metadata(
        DesignVariable(
            name="iteration",
            description="Iteration number",
            units=None,
            lower_bound=0,
            upper_bound=n_points,
            possible_values=None,
            initial_value=None,
        )
    )

    result.add_variable_metadata(
        Objective(
            name="f1_cost",
            description="Cost objective",
            units="$",
            direction=OptimizationDirection.MINIMIZE,
            lower_bound=None,
            upper_bound=None,
            ideal_value=None,
            nadir_value=None,
        )
    )
    result.add_variable_metadata(
        Objective(
            name="f2_weight",
            description="Weight objective",
            units="kg",
            direction=OptimizationDirection.MINIMIZE,
            lower_bound=None,
            upper_bound=None,
            ideal_value=None,
            nadir_value=None,
        )
    )
    result.add_variable_metadata(
        Objective(
            name="f3_volume",
            description="Volume objective",
            units="cm³",
            direction=OptimizationDirection.MINIMIZE,
            lower_bound=None,
            upper_bound=None,
            ideal_value=None,
            nadir_value=None,
        )
    )

    # Add constraint metadata
    result.add_variable_metadata(
        Constraint(
            name="g1_size_constraint",
            description="Size constraint",
            units=None,
            constraint_type=ConstraintType.INEQUALITY,
            reference_value=0,
            tolerance=0.1,
            lower_bound=None,
            upper_bound=None,
        )
    )
    result.add_variable_metadata(
        Constraint(
            name="g2_dimensional_constraint",
            description="Dimensional constraint",
            units=None,
            constraint_type=ConstraintType.INEQUALITY,
            reference_value=0,
            tolerance=0.1,
            lower_bound=None,
            upper_bound=None,
        )
    )
    result.add_variable_metadata(
        Constraint(
            name="h1_balance",
            description="Balance constraint",
            units=None,
            constraint_type=ConstraintType.EQUALITY,
            reference_value=0,
            tolerance=0.5,
            lower_bound=None,
            upper_bound=None,
        )
    )

    return result


def generate_comparison_problems():
    """Generate multiple optimization results for comparison."""
    # Create three different results with different characteristics
    results = {}

    # Base result
    results["Base"] = generate_test_problem(n_points=200, seed=42)

    # Result with different design space exploration
    results["Variant A"] = generate_test_problem(n_points=200, seed=123)

    # Result with more focused exploration
    np.random.seed(456)
    n_points = 200
    x1 = np.random.uniform(2, 8, n_points)  # More focused design space
    x2 = np.random.uniform(2, 8, n_points)
    x3 = np.random.uniform(2, 8, n_points)
    x4 = np.random.uniform(2, 8, n_points)

    # Objectives (same equations as in generate_test_problem)
    f1 = x1
    g = 1 + 9 * (x2 + x3 + x4) / 3
    h1 = 1 - np.sqrt(f1 / g)
    h2 = 1 - (f1 / g) ** 2
    f2 = g * h1
    f3 = g * h2
    f2 += np.random.normal(0, 0.05, n_points)  # Less noise
    f3 += np.random.normal(0, 0.05, n_points)

    # Create the result with the same structure
    results["Variant B"] = OptimizationResult(
        problem_metadata=ProblemMetadata(
            name="Focused Exploration",
            description="Exploration with focused design space",
            solver="NSGA-II",
            n_design_variables=4,
            n_objectives=3,
            n_inequality_constraints=0,
            n_equality_constraints=0,
            n_evaluations=n_points,
            solver_version="1.0",
            computation_time=None,
        ),
        design_variables=pd.DataFrame(
            {"x1_width": x1, "x2_height": x2, "x3_depth": x3, "x4_thickness": x4}
        ),
        objectives=pd.DataFrame({"f1_cost": f1, "f2_weight": f2, "f3_volume": f3}),
    )

    # Add same metadata for compatibility
    for var_name, var_props in zip(
        ["x1_width", "x2_height", "x3_depth", "x4_thickness"], [(2, 8), (2, 8), (2, 8), (2, 8)]
    ):
        results["Variant B"].add_variable_metadata(
            DesignVariable(
                name=var_name,
                description=f"{var_name} parameter",
                units="cm",
                lower_bound=var_props[0],
                upper_bound=var_props[1],
                possible_values=None,
                initial_value=None,
            )
        )

    results["Variant B"].add_variable_metadata(
        Objective(
            name="f1_cost",
            description="Cost objective",
            units="$",
            direction=OptimizationDirection.MINIMIZE,
            lower_bound=None,
            upper_bound=None,
            ideal_value=None,
            nadir_value=None,
        )
    )
    results["Variant B"].add_variable_metadata(
        Objective(
            name="f2_weight",
            description="Weight objective",
            units="kg",
            direction=OptimizationDirection.MINIMIZE,
            lower_bound=None,
            upper_bound=None,
            ideal_value=None,
            nadir_value=None,
        )
    )
    results["Variant B"].add_variable_metadata(
        Objective(
            name="f3_volume",
            description="Volume objective",
            units="cm³",
            direction=OptimizationDirection.MINIMIZE,
            lower_bound=None,
            upper_bound=None,
            ideal_value=None,
            nadir_value=None,
        )
    )

    return results


def setup_result_sets(result):
    """Create useful result sets for visualization."""
    # 1. Create Pareto set
    pareto_indices = smart_pareto_filter(result.objectives, epsilon=0.1, normalize=True)
    pareto_set = result.create_set(
        name="pareto_front",
        indices=pareto_indices,
        created_by="smart_filter",
        description="Pareto optimal solutions",
        color="#e74c3c",
    )
    print(f"Created 'pareto_front' set with {len(pareto_set)} solutions")

    # 2. Find feasible solutions (all constraints satisfied)
    if hasattr(result, "inequality_constraints") and not result.inequality_constraints.empty:
        g1_values = (
            result.inequality_constraints["g1_size_constraint"]
            if "g1_size_constraint" in result.inequality_constraints.columns
            else None
        )
        g2_values = (
            result.inequality_constraints["g2_dimensional_constraint"]
            if "g2_dimensional_constraint" in result.inequality_constraints.columns
            else None
        )
    else:
        g1_values = g2_values = None

    if hasattr(result, "equality_constraints") and not result.equality_constraints.empty:
        h1_values = (
            result.equality_constraints["h1_balance"]
            if "h1_balance" in result.equality_constraints.columns
            else None
        )
    else:
        h1_values = None

    # Check feasibility if constraints exist
    if g1_values is not None or g2_values is not None or h1_values is not None:
        # Start with all True
        feasible_mask = pd.Series([True] * result.n_points, index=range(result.n_points))

        # Apply constraints one by one
        if g1_values is not None:
            feasible_mask = feasible_mask & (g1_values <= 0)
        if g2_values is not None:
            feasible_mask = feasible_mask & (g2_values <= 0)
        if h1_values is not None:
            feasible_mask = feasible_mask & (np.abs(h1_values) <= 0.5)  # Tolerance for equality

        feasible_indices = feasible_mask[feasible_mask].index.tolist()

        feasible_set = result.create_set(
            name="feasible",
            indices=feasible_indices,
            created_by="constraint_filter",
            description="Solutions satisfying all constraints",
            color="#2ecc71",
        )
        print(f"Created 'feasible' set with {len(feasible_set)} solutions")

        # Create intersection: feasible Pareto solutions
        if pareto_set and feasible_set:
            feasible_pareto = feasible_set.intersection(pareto_set, name="feasible_pareto")
            result._set_manager.add_set(feasible_pareto)
            print(f"Created 'feasible_pareto' set with {len(feasible_pareto)} solutions")

    # 3. Knee points on 2D Pareto front (if pareto_set exists)
    if pareto_set and len(pareto_set) >= 5:
        # Get 2D objectives for knee detection
        pareto_objectives = result.objectives.iloc[pareto_indices][["f1_cost", "f2_weight"]]

        # Detect knee points
        knee_indices_relative = detect_knee_points(
            pareto_objectives, method="angle", n_knees=3, normalize=True
        )

        # Convert to original indices
        knee_indices = [pareto_indices[i] for i in knee_indices_relative]

        knee_set = result.create_set(
            name="knee_points",
            indices=knee_indices,
            created_by="knee_detection",
            description="Knee points on Pareto front",
            color="#9b59b6",
        )
        print(f"Created 'knee_points' set with {len(knee_set)} solutions")

    return result


def main():
    """Run all plotting examples."""
    print("=" * 70)
    print("OPTISCOPE PLOTTING EXAMPLES")
    print("=" * 70)

    # Create output directory
    output_dir = Path(__file__).parents[1] / "example_output" / "plotting_examples"
    output_dir.mkdir(parents=True, exist_ok=True)

    print("\nGenerating test data...")
    result = generate_test_problem(n_points=200)
    print("Test data generated successfully.")

    print("\nSetting up result sets...")
    result = setup_result_sets(result)

    print("\nGenerating plots...\n")

    # Example 1: 2D Pareto front
    print("1. Plot: 2D Pareto Front")
    fig_2d = plot_pareto_front_2d(
        result,
        obj_x="f1_cost",
        obj_y="f2_weight",
        pareto_set="pareto_front",
        additional_sets=["knee_points", "feasible_pareto"]
        if "knee_points" in result.list_sets()
        else ["feasible_pareto"],
        show_dominated=True,
        show_ideal_nadir=True,
        title="2D Pareto Front (Cost vs. Weight)",
    )
    fig_2d.write_html(output_dir / "pareto_front_2d.html")
    print(f"   ✓ Saved to {output_dir / 'pareto_front_2d.html'}")

    # Example 2: 3D Pareto front
    print("\n2. Plot: 3D Pareto Front")
    fig_3d = plot_pareto_front_3d(
        result,
        obj_x="f1_cost",
        obj_y="f2_weight",
        obj_z="f3_volume",
        pareto_set="pareto_front",
        show_dominated=True,
        show_surface=True,
        title="3D Pareto Front",
    )
    fig_3d.write_html(output_dir / "pareto_front_3d.html")
    print(f"   ✓ Saved to {output_dir / 'pareto_front_3d.html'}")

    # Example 3: Parallel coordinates
    print("\n3. Plot: Parallel Coordinates")
    fig_pc = plot_parallel_coordinates(
        result,
        include_design_vars=True,
        include_objectives=True,
        include_constraints=True,
        result_sets=["pareto_front", "feasible"],
        title="Parallel Coordinates Plot",
    )
    fig_pc.write_html(output_dir / "parallel_coordinates.html")
    print(f"   ✓ Saved to {output_dir / 'parallel_coordinates.html'}")

    # Example 4: Parallel coordinates with color by variable
    print("\n4. Plot: Parallel Coordinates (Color by Variable)")
    fig_pc_color = plot_parallel_coordinates(
        result,
        include_design_vars=True,
        include_objectives=True,
        color_by="f1_cost",
        highlight_feasible=False,
        title="Parallel Coordinates (Color by Cost)",
    )
    fig_pc_color.write_html(output_dir / "parallel_coordinates_color.html")
    print(f"   ✓ Saved to {output_dir / 'parallel_coordinates_color.html'}")

    # Example 5: Scatter matrix
    print("\n5. Plot: Scatter Matrix (SPLOM)")
    fig_splom = plot_scatter_matrix(
        result,
        include_objectives=True,
        include_design_vars=True,
        max_vars=6,
        highlight_feasible=True,
        show_distributions=True,
        show_correlations=True,
        marker_size=4,
        title="Scatter Plot Matrix",
    )
    fig_splom.write_html(output_dir / "scatter_matrix.html")
    print(f"   ✓ Saved to {output_dir / 'scatter_matrix.html'}")

    # Example 6: Correlation heatmap
    print("\n6. Plot: Correlation Heatmap")
    fig_corr = plot_correlation_heatmap(
        result,
        include_objectives=True,
        include_design_vars=True,
        method="pearson",
        title="Pearson Correlation Heatmap",
    )
    fig_corr.write_html(output_dir / "correlation_heatmap.html")
    print(f"   ✓ Saved to {output_dir / 'correlation_heatmap.html'}")

    # Example A: Time series plot
    print("\n7. Plot: Time Series (Design Variables)")
    fig_ts = plot_time_series(
        result,
        columns=["x1_width", "x2_height", "x3_depth", "x4_thickness"],
        data_attr="design_variables",
        title="Design Variables Evolution",
        show_markers=True,
        line_width=2,
        marker_size=4,
    )
    fig_ts.write_html(output_dir / "time_series.html")
    print(f"   ✓ Saved to {output_dir / 'time_series.html'}")

    # Example B: Constraints time series
    print("\n8. Plot: Constraints Time Series")
    fig_cts = plot_constraints_time_series(
        result,
        columns=["g1_size_constraint", "g2_dimensional_constraint", "h1_balance"],
        title="Constraints Evolution",
        show_markers=True,
        show_feasibility=True,
    )
    fig_cts.write_html(output_dir / "constraints_time_series.html")
    print(f"   ✓ Saved to {output_dir / 'constraints_time_series.html'}")

    # Example C: Full optimization history
    print("\n9. Plot: Optimization History (All Data)")
    figs_hist = plot_optimization_history(
        result,
        variables=["x1_width", "x2_height"],  # Subset for brevity
        objectives=["f1_cost", "f2_weight", "f3_volume"],
        constraints=["g1_size_constraint", "h1_balance"],
        observables=["efficiency", "total_mass"],
        show_markers=True,
        line_width=2,
        marker_size=4,
    )

    # Save each figure from the history
    for key, fig in figs_hist.items():
        fig.write_html(output_dir / f"optimization_history_{key}.html")
        print(f"   ✓ Saved to {output_dir / f'optimization_history_{key}.html'}")

    # Example D: Multi-result comparison
    print("\n10. Plot: Multi-Result Comparison (Parallel Coordinates)")
    results_dict = generate_comparison_problems()

    fig_compare = plot_parallel_coordinates_comparison(
        results=results_dict,
        include_design_vars=True,
        include_objectives=True,
        title="Algorithm Comparison - Parallel Coordinates",
    )
    fig_compare.write_html(output_dir / "multi_result_comparison.html")
    print(f"   ✓ Saved to {output_dir / 'multi_result_comparison.html'}")

    print("\n" + "=" * 70)
    print("PLOTTING EXAMPLES COMPLETED!")
    print("=" * 70)
    print(f"\nAll output files saved to: {output_dir}")
    print("\nList of generated files:")
    for file in sorted(os.listdir(output_dir)):
        if file.endswith(".html"):
            print(f"  - {file}")
    print("\nOpen the HTML files in a browser to view the interactive plots.")


if __name__ == "__main__":
    main()
