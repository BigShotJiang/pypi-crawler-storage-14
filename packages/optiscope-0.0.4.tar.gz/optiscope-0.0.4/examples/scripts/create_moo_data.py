import numpy as np
import pandas as pd
from pymoo.algorithms.moo.nsga2 import NSGA2
from pymoo.core.problem import ElementwiseProblem
from pymoo.optimize import minimize


class MyProblem(ElementwiseProblem):
    def __init__(self):
        super().__init__(
            n_var=2, n_obj=2, n_ieq_constr=2, xl=np.array([-2, -2]), xu=np.array([2, 2])
        )

    def _evaluate(self, x, out, *args, **kwargs):
        f1 = 100 * (x[0] ** 2 + x[1] ** 2)
        f2 = (x[0] - 1) ** 2 + x[1] ** 2

        g1 = 2 * (x[0] - 0.1) * (x[0] - 0.9) / 0.18
        g2 = -20 * (x[0] - 0.4) * (x[0] - 0.6) / 4.8

        out["F"] = [f1, f2]
        out["G"] = [g1, g2]


problem = MyProblem()

algorithm = NSGA2(pop_size=100, save_history=True)

res = minimize(problem, algorithm, ("n_gen", 100), verbose=False, seed=1)

# Export variables and objectives to one CSV file
# first convert it to dataframe
pareto_front = pd.DataFrame(np.column_stack((res.X, res.F)), columns=["x1", "x2", "f1", "f2"])
pareto_front.to_csv("pareto_front.csv", index=False)

# Save history as well
history = pd.DataFrame(res.history)
history.to_csv("history.csv", index=False)
