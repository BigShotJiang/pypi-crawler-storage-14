"""
Example script for using the analysis module.

This script demonstrates how to use the analysis features of optiscope,
including Pareto front detection, feasibility checking, and MCDA ranking.
"""

import pandas as pd

from optiscope.core.data_model import OptimizationResult
from optiscope.core.data_types import (
    Constraint,
    ConstraintType,
    Objective,
    OptimizationDirection,
)


def create_sample_result() -> OptimizationResult:
    """Creates a sample OptimizationResult for demonstration."""
    design_vars = pd.DataFrame(
        {
            "x1": [1, 2, 3, 4, 5],
            "x2": [5, 4, 3, 2, 1],
        }
    )
    objectives = pd.DataFrame(
        {
            "cost": [10, 8, 6, 9, 7],
            "performance": [7, 9, 8, 6, 10],
        }
    )
    constraints = pd.DataFrame(
        {
            "g1": [-1, 0.5, -2, 1, -0.5],  # <= 0
            "g2": [0, 0, -1, -2, 0],  # <= 0
        }
    )

    result = OptimizationResult(
        design_variables=design_vars,
        objectives=objectives,
        inequality_constraints=constraints,
    )

    result.add_variable_metadata(Objective(name="cost", direction=OptimizationDirection.MINIMIZE))
    result.add_variable_metadata(
        Objective(name="performance", direction=OptimizationDirection.MAXIMIZE)
    )
    result.add_variable_metadata(Constraint(name="g1", constraint_type=ConstraintType.INEQUALITY))
    result.add_variable_metadata(Constraint(name="g2", constraint_type=ConstraintType.INEQUALITY))
    return result


def main():
    """Main function to run the analysis examples."""
    print("Creating a sample optimization result...")
    result = create_sample_result()
    print("Sample result created with 5 solutions.")
    print("\\n" + "=" * 30 + "\\n")

    # 1. Find the Pareto front
    print("1. Identifying the Pareto front...")
    pareto_set = result.find_pareto_front()
    print(f"   - Pareto front set name: '{pareto_set.name}'")
    print(f"   - Number of Pareto optimal solutions: {len(pareto_set)}")
    print(f"   - Pareto optimal indices: {pareto_set.indices}")
    print("\\n" + "=" * 30 + "\\n")

    # 2. Check for feasibility
    print("2. Checking for feasible solutions...")
    feasible_set = result.check_feasibility()
    print(f"   - Feasible set name: '{feasible_set.name}'")
    print(f"   - Number of feasible solutions: {len(feasible_set)}")
    print(f"   - Feasible indices: {feasible_set.indices}")
    print("\\n" + "=" * 30 + "\\n")

    # 3. Find Pareto front from feasible solutions
    print("3. Identifying the Pareto front from feasible solutions...")
    feasible_pareto_set = result.find_pareto_front(set_name="feasible_pareto", from_set="feasible")
    print(f"   - Feasible Pareto set name: '{feasible_pareto_set.name}'")
    print(f"   - Number of feasible Pareto solutions: {len(feasible_pareto_set)}")
    print(f"   - Feasible Pareto indices: {feasible_pareto_set.indices}")
    print("\\n" + "=" * 30 + "\\n")

    # 4. Rank solutions using Weighted Sum Model (WSM)
    print("4. Ranking all solutions using the Weighted Sum Model...")
    weights = {"cost": 0.6, "performance": 0.4}
    print(f"   - Using weights: {weights}")
    scores = result.rank_with_wsm(weights)

    # Add scores as an observable
    result.add_custom_data("wsm_scores", pd.DataFrame(scores))

    print("   - WSM scores (lower is better):")
    print(scores)
    print("\\n" + "=" * 30 + "\\n")


if __name__ == "__main__":
    main()
