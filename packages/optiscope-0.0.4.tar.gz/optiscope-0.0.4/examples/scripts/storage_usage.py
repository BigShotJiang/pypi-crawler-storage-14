"""
Storage system usage examples.

This example demonstrates:
1. Using different storage backends
2. Storage manager with caching
3. Migration between backends
4. Persistent vs. temporary storage strategies
"""

import tempfile
from pathlib import Path

import numpy as np
import pandas as pd

from optiscope import OptimizationResult, ProblemMetadata
from optiscope.storage import (
    FileSystemStorage,
    MemoryStorage,
    create_storage_manager,
)


def create_sample_result(name: str, n_points: int = 50) -> OptimizationResult:
    """Create a sample optimization result."""
    np.random.seed(hash(name) % 2**32)

    x1 = np.random.uniform(0, 10, n_points)
    x2 = np.random.uniform(0, 10, n_points)

    f1 = x1
    f2 = (x2 + 1) / x1

    return OptimizationResult(
        problem_metadata=ProblemMetadata(
            name=name,
            solver="Example",
            n_design_variables=2,
            n_objectives=2,
        ),
        design_variables=pd.DataFrame({"x1": x1, "x2": x2}),
        objectives=pd.DataFrame({"f1": f1, "f2": f2}),
    )


def example_1_memory_storage():
    """Example 1: Basic memory storage."""
    print("=" * 60)
    print("Example 1: Memory Storage")
    print("=" * 60)

    # Create memory storage
    storage = MemoryStorage(max_memory_mb=50.0, eviction_policy="lru")

    # Save multiple results
    print("\n1. Saving results to memory...")
    for i in range(5):
        key = f"run_{i}"
        result = create_sample_result(f"Problem {i}", n_points=100)
        storage.save_result(key, result, metadata={"run_number": i})
        print(f"   Saved '{key}': {result.n_points} points")

    # List results
    print(f"\n2. Stored results: {storage.list_results()}")

    # Load a result
    print("\n3. Loading result 'run_2'...")
    loaded = storage.load_result("run_2")
    print(f"   Loaded: {loaded}")

    # Get metadata
    print("\n4. Result metadata:")
    meta = storage.get_result_metadata("run_2")
    for key, value in meta.items():
        print(f"   {key}: {value}")

    # Storage info
    print("\n5. Storage information:")
    info = storage.get_storage_info()
    for key, value in info.items():
        print(f"   {key}: {value}")

    print("\n✓ Memory storage example completed!")


def example_2_filesystem_storage():
    """Example 2: Filesystem storage."""
    print("\n" + "=" * 60)
    print("Example 2: Filesystem Storage")
    print("=" * 60)

    # Create temporary directory
    with tempfile.TemporaryDirectory() as tmpdir:
        storage_path = Path(tmpdir) / "optimization_storage"

        # Create filesystem storage
        storage = FileSystemStorage(base_path=storage_path, format="json", create_if_missing=True)

        print(f"\n1. Created storage at: {storage_path}")

        # Save results
        print("\n2. Saving results to filesystem...")
        for i in range(3):
            key = f"experiment_{i}"
            result = create_sample_result(f"Experiment {i}", n_points=80)
            storage.save_result(key, result)
            print(f"   Saved '{key}'")

        # Create a result set
        result = storage.load_result("experiment_0")
        pareto_indices = list(range(0, result.n_points, 10))  # Every 10th point
        result_set = result.create_set(
            name="sample_set", indices=pareto_indices, created_by="example"
        )
        storage.save_set("experiment_0", "sample_set", result_set)
        print("\n3. Created and saved result set 'sample_set'")

        # List results and sets
        print(f"\n4. Stored results: {storage.list_results()}")
        print(f"   Sets for 'experiment_0': {storage.list_sets('experiment_0')}")

        # Storage info
        print("\n5. Storage information:")
        info = storage.get_storage_info()
        for key, value in info.items():
            print(f"   {key}: {value}")

        # Show directory structure
        print("\n6. Directory structure:")
        for item in storage_path.rglob("*"):
            if item.is_file():
                rel_path = item.relative_to(storage_path)
                size_kb = item.stat().st_size / 1024
                print(f"   {rel_path} ({size_kb:.1f} KB)")

        print("\n✓ Filesystem storage example completed!")


def example_3_storage_manager():
    """Example 3: Storage manager with caching."""
    print("\n" + "=" * 60)
    print("Example 3: Storage Manager with Caching")
    print("=" * 60)

    with tempfile.TemporaryDirectory() as tmpdir:
        # Create storage manager with filesystem primary and memory cache
        manager = create_storage_manager(
            primary_type="filesystem",
            primary_config={"base_path": Path(tmpdir) / "primary"},
            use_cache=True,
            cache_size_mb=20.0,
        )

        print("\n1. Created storage manager with:")
        print("   - Primary: Filesystem (persistent)")
        print("   - Cache: Memory (fast access)")

        # Save results
        print("\n2. Saving results (goes to both primary and cache)...")
        for i in range(4):
            key = f"dataset_{i}"
            result = create_sample_result(f"Dataset {i}", n_points=60)
            manager.save_result(key, result)
            print(f"   Saved '{key}'")

        # First load (from cache)
        print("\n3. Loading 'dataset_1' (from cache)...")
        import time

        start = time.time()
        result = manager.load_result("dataset_1", use_cache=True)
        cache_time = time.time() - start
        print(f"   Cache load time: {cache_time * 1000:.2f} ms")

        # Clear cache and load again (from disk)
        manager.clear_cache()
        print("\n4. Loading 'dataset_1' (from disk after cache clear)...")
        start = time.time()
        result = manager.load_result("dataset_1", use_cache=False)
        disk_time = time.time() - start
        print(f"   Disk load time: {disk_time * 1000:.2f} ms")
        print(f"   Cache speedup: {disk_time / cache_time:.1f}x faster")

        # Storage info
        print("\n5. Storage information:")
        info = manager.get_storage_info()
        for backend, backend_info in info.items():
            print(f"\n   {backend.upper()}:")
            for key, value in backend_info.items():
                print(f"     {key}: {value}")

        manager.close()
        print("\n✓ Storage manager example completed!")


def example_4_migration():
    """Example 4: Migrating results between backends."""
    print("\n" + "=" * 60)
    print("Example 4: Backend Migration")
    print("=" * 60)

    with tempfile.TemporaryDirectory() as tmpdir:
        # Create manager with primary and secondary
        manager = create_storage_manager(
            primary_type="memory",
            secondary_type="filesystem",
            secondary_config={"base_path": Path(tmpdir) / "backup"},
        )

        print("\n1. Created storage manager with:")
        print("   - Primary: Memory (fast, temporary)")
        print("   - Secondary: Filesystem (slower, persistent)")

        # Save to primary only
        print("\n2. Saving results to primary (memory) only...")
        for i in range(3):
            key = f"temp_result_{i}"
            result = create_sample_result(f"Temp {i}", n_points=40)
            manager.save_result(key, result, replicate=False)

        print(f"   Primary has: {len(manager.list_results('primary'))} results")
        print(f"   Secondary has: {len(manager.list_results('secondary'))} results")

        # Sync to secondary
        print("\n3. Syncing primary -> secondary...")
        stats = manager.sync_backends(direction="primary_to_secondary")
        print(f"   Copied: {stats['copied']}")
        print(f"   Skipped: {stats['skipped']}")
        print(f"   Errors: {stats['errors']}")

        print("\n   After sync:")
        print(f"   Primary has: {len(manager.list_results('primary'))} results")
        print(f"   Secondary has: {len(manager.list_results('secondary'))} results")

        # Migrate specific result
        print("\n4. Migrating 'temp_result_0' back to primary...")
        manager.primary.delete_result("temp_result_0")
        manager.migrate_result("temp_result_0", "secondary", "primary")
        print("   Migration completed!")

        manager.close()
        print("\n✓ Migration example completed!")


def example_5_database_storage():
    """Example 5: Database storage (if available)."""
    print("\n" + "=" * 60)
    print("Example 5: Database Storage")
    print("=" * 60)

    from optiscope.storage import is_database_available

    if not is_database_available():
        print("\n⚠ Database backend not available.")
        print("   Install with: pip install optiscope[database]")
        return

    with tempfile.TemporaryDirectory() as tmpdir:
        # Create SQLite database storage
        db_path = Path(tmpdir) / "optimization.db"
        connection_string = f"sqlite:///{db_path}"

        manager = create_storage_manager(
            primary_type="database", primary_config={"connection_string": connection_string}
        )

        print(f"\n1. Created database storage at: {db_path}")

        # Save results
        print("\n2. Saving results to database...")
        for i in range(3):
            key = f"db_result_{i}"
            result = create_sample_result(f"DB Result {i}", n_points=100)
            manager.save_result(key, result)
            print(f"   Saved '{key}'")

        # Query metadata without loading data
        print("\n3. Querying metadata (fast, no data load)...")
        for key in manager.list_results():
            meta = manager.primary.get_result_metadata(key)
            print(f"   {key}: {meta['n_points']} points, modified at {meta['modified_at']}")

        # Storage info
        print("\n4. Storage information:")
        info = manager.get_storage_info()
        for key, value in info["primary"].items():
            print(f"   {key}: {value}")

        manager.close()
        print("\n✓ Database storage example completed!")


def main():
    """Run all examples."""
    print("=" * 60)
    print("STORAGE SYSTEM EXAMPLES")
    print("=" * 60)

    example_1_memory_storage()
    example_2_filesystem_storage()
    example_3_storage_manager()
    example_4_migration()
    example_5_database_storage()

    print("\n" + "=" * 60)
    print("ALL EXAMPLES COMPLETED!")
    print("=" * 60)


if __name__ == "__main__":
    main()
