"""
MIDACO File Import Example

Demonstrates importing and analyzing optimization results from MIDACO solver.
"""

from pathlib import Path

from optiscope import load_results
from optiscope.analysis import detect_knee_points, smart_pareto_filter
from optiscope.io import detect_midaco_files, read_midaco_pair
from optiscope.plotting import plot_parallel_coordinates, plot_pareto_front_2d


def example_1_auto_load():
    """Example 1: Auto-detect and load MIDACO files."""
    print("=" * 70)
    print("EXAMPLE 1: Auto-Load MIDACO Files")
    print("=" * 70)

    # Option 1: Use auto-detection if you know the file is MIDACO
    print("\n1. Using auto-detection:")
    result = load_results("PARETO.TXT")

    print(f"   Loaded: {result.problem_metadata.name}")
    print(f"   Solutions: {result.n_points}")
    print(f"   Objectives: {list(result.objectives.columns)}")
    print(f"   Design variables: {list(result.design_variables.columns)}")
    print(f"   Constraints: {len(result.inequality_constraints.columns)}")

    # Check for auto-created result sets
    if "midaco_best" in result.sets:
        print("\n   Auto-created sets:")
        print(f"     - 'midaco_best': {len(result.get_set('midaco_best'))} solution(s)")
        print(f"     - 'pareto_front': {len(result.get_set('pareto_front'))} solution(s)")


def example_2_load_both_files():
    """Example 2: Load both SOLUTION and PARETO files."""
    print("\n" + "=" * 70)
    print("EXAMPLE 2: Load Both Solution History and Pareto Front")
    print("=" * 70)

    # Load both files
    solution_result, pareto_result = read_midaco_pair(
        solution_file=Path("SOLUTION.TXT"), pareto_file=Path("PARETO.TXT")
    )

    print("\n1. Solution History:")
    print(f"   Total evaluations: {solution_result.n_points}")
    print(f"   Objectives: {solution_result.objectives.columns.tolist()}")

    print("\n2. Pareto Front:")
    print(f"   Non-dominated solutions: {pareto_result.n_points}")
    print("   Best solution (MIDACO): set 'midaco_best'")
    print("   Pareto approximation: set 'pareto_front'")

    # Compare convergence
    if solution_result.n_points > 0:
        first_obj = solution_result.objectives.iloc[0]
        best_obj = pareto_result.objectives.iloc[0]  # MIDACO best

        print("\n3. Convergence:")
        print(f"   First evaluation: {first_obj.tolist()}")
        print(f"   Best found: {best_obj.tolist()}")


def example_3_directory_search():
    """Example 3: Auto-detect MIDACO files in directory."""
    print("\n" + "=" * 70)
    print("EXAMPLE 3: Auto-Detect Files in Directory")
    print("=" * 70)

    # Detect MIDACO files in directory
    directory = Path("./midaco_results")
    found_files = detect_midaco_files(directory)

    print(f"\n1. Searching directory: {directory}")
    print("   Found files:")

    for file_type, filepath in found_files.items():
        print(f"     - {file_type}: {filepath.name}")

    # Load detected files
    if found_files:
        if "PARETO" in found_files:
            result = load_results(found_files["PARETO"])
            print(f"\n2. Loaded Pareto front: {result.n_points} solutions")
        elif "SOLUTION" in found_files:
            result = load_results(found_files["SOLUTION"])
            print(f"\n2. Loaded solution history: {result.n_points} evaluations")


def example_4_analyze_pareto():
    """Example 4: Complete analysis of MIDACO Pareto front."""
    print("\n" + "=" * 70)
    print("EXAMPLE 4: Analyze MIDACO Pareto Front")
    print("=" * 70)

    # Load Pareto front
    result = load_results("PARETO.TXT")

    print(f"\n1. Loaded Pareto front with {result.n_points} solutions")

    # Get the Pareto front set (excluding the best solution)
    pareto_set = result.get_set("pareto_front")
    print(f"   Pareto approximation: {len(pareto_set)} points")

    # Refine with Smart Pareto Filter
    print("\n2. Applying Smart Pareto Filter...")
    pareto_indices = pareto_set.indices
    pareto_objectives = result.objectives.iloc[pareto_indices]

    # Filter to representative points (assuming 2D for this example)
    if len(result.objectives.columns) == 2:
        filtered_indices = smart_pareto_filter(pareto_objectives, epsilon=0.1, normalize=True)

        # Map back to original indices
        filtered_original = [pareto_indices[i] for i in filtered_indices]

        result.create_set(
            name="representative_pareto",
            indices=filtered_original,
            created_by="smart_filter",
            description=f"Reduced from {len(pareto_indices)} to {len(filtered_original)} points",
        )

        print(f"   Reduced to {len(filtered_original)} representative points")

        # Detect knee points
        print("\n3. Detecting knee points...")
        knee_indices_local = detect_knee_points(
            pareto_objectives.iloc[filtered_indices], method="angle", n_knees=3
        )

        # Map through both filters
        knee_original = [filtered_original[i] for i in knee_indices_local]

        result.create_set(
            name="knee_points", indices=knee_original, created_by="knee_detection", color="#FF6B6B"
        )

        print(f"   Found {len(knee_original)} knee points:")
        for i, idx in enumerate(knee_original, 1):
            obj_vals = result.objectives.iloc[idx]
            print(f"     {i}. Solution {idx}: {obj_vals.tolist()}")

    # Visualize
    print("\n4. Creating visualizations...")

    # Pareto front plot
    if len(result.objectives.columns) >= 2:
        fig = plot_pareto_front_2d(
            result,
            obj_x=0,
            obj_y=1,
            pareto_set="pareto_front",
            additional_sets=["midaco_best", "representative_pareto", "knee_points"],
            show_dominated=False,
            show_ideal_nadir=True,
        )

        output_dir = Path("example_output/midaco")
        output_dir.mkdir(parents=True, exist_ok=True)
        fig.write_html(output_dir / "pareto_analysis.html")
        print(f"   Saved: {output_dir / 'pareto_analysis.html'}")

    # Parallel coordinates
    fig_parallel = plot_parallel_coordinates(
        result,
        include_design_vars=True,
        include_objectives=True,
        result_sets=["pareto_front", "representative_pareto", "knee_points"],
        line_opacity=0.6,
    )

    output_dir = Path("example_output/midaco")
    fig_parallel.write_html(output_dir / "parallel_coords.html")
    print(f"   Saved: {output_dir / 'parallel_coords.html'}")


def example_5_export_refined():
    """Example 5: Export refined Pareto front back to MIDACO format."""
    print("\n" + "=" * 70)
    print("EXAMPLE 5: Export Refined Results")
    print("=" * 70)

    # Load and refine
    result = load_results("PARETO.TXT")

    # Filter to representative points
    pareto_set = result.get_set("pareto_front")
    pareto_objectives = result.objectives.iloc[pareto_set.indices]

    if len(result.objectives.columns) == 2:
        filtered_indices = smart_pareto_filter(pareto_objectives, epsilon=0.1)
        filtered_original = [pareto_set.indices[i] for i in filtered_indices]

        result.create_set(
            name="refined_pareto", indices=filtered_original, created_by="smart_filter"
        )

        print(f"\n1. Refined Pareto front: {len(filtered_original)} points")

        # Export back to MIDACO format
        from optiscope.io.midaco_handler import MIDACoHandler

        handler = MIDACoHandler()
        output_path = Path("example_output/midaco/REFINED_PARETO.TXT")
        output_path.parent.mkdir(parents=True, exist_ok=True)

        handler.write(result, output_path, file_type="PARETO", include_pareto_set="refined_pareto")

        print(f"   Exported to: {output_path}")
        print("   Format: MIDACO PARETO.TXT")


def example_6_compare_midaco_best():
    """Example 6: Compare MIDACO's best with other analysis methods."""
    print("\n" + "=" * 70)
    print("EXAMPLE 6: Compare MIDACO Best with Other Methods")
    print("=" * 70)

    result = load_results("PARETO.TXT")

    # Get MIDACO's choice
    midaco_best_idx = result.get_set("midaco_best").indices[0]
    midaco_best = result.objectives.iloc[midaco_best_idx]

    print(f"\n1. MIDACO's best solution (index {midaco_best_idx}):")
    for col in result.objectives.columns:
        print(f"   {col}: {midaco_best[col]:.6f}")

    # Find knee point
    if len(result.objectives.columns) == 2:
        pareto_set = result.get_set("pareto_front")
        pareto_objectives = result.objectives.iloc[pareto_set.indices]

        knee_indices = detect_knee_points(pareto_objectives, method="angle", n_knees=1)

        knee_idx = pareto_set.indices[knee_indices[0]]
        knee_best = result.objectives.iloc[knee_idx]

        print(f"\n2. Knee point (index {knee_idx}):")
        for col in result.objectives.columns:
            print(f"   {col}: {knee_best[col]:.6f}")

        # Compare
        print("\n3. Comparison:")
        print(
            f"   MIDACO and knee point are {'the same' if midaco_best_idx == knee_idx else 'different'}"
        )

        if midaco_best_idx != knee_idx:
            print("\n   Differences:")
            for col in result.objectives.columns:
                diff = knee_best[col] - midaco_best[col]
                print(f"   {col}: {diff:+.6f}")


def main():
    """Run all MIDACO import examples."""
    print("=" * 70)
    print("MIDACO FILE IMPORT EXAMPLES")
    print("=" * 70)

    # Create sample MIDACO files if they don't exist
    print("\nNote: This example assumes MIDACO output files exist.")
    print("Expected files: SOLUTION.TXT and/or PARETO.TXT")

    try:
        example_1_auto_load()
    except FileNotFoundError:
        print("\n⚠ PARETO.TXT not found - skipping Example 1")

    try:
        example_2_load_both_files()
    except FileNotFoundError:
        print("\n⚠ SOLUTION.TXT or PARETO.TXT not found - skipping Example 2")

    try:
        example_3_directory_search()
    except Exception as e:
        print(f"\n⚠ Example 3 error: {e}")

    try:
        example_4_analyze_pareto()
    except FileNotFoundError:
        print("\n⚠ PARETO.TXT not found - skipping Example 4")

    try:
        example_5_export_refined()
    except FileNotFoundError:
        print("\n⚠ PARETO.TXT not found - skipping Example 5")

    try:
        example_6_compare_midaco_best()
    except FileNotFoundError:
        print("\n⚠ PARETO.TXT not found - skipping Example 6")

    print("\n" + "=" * 70)
    print("EXAMPLES COMPLETED")
    print("=" * 70)


if __name__ == "__main__":
    main()
