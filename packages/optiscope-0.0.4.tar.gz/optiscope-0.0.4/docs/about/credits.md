# Open Source Credits

OptiScope stands on the shoulders of giants. We gratefully acknowledge the following open-source projects that make this work possible.

## Core Dependencies

- **[NumPy](https://numpy.org/)**: The fundamental package for scientific computing with Python.
- **[Pandas](https://pandas.pydata.org/)**: Powerful data structures for data analysis, time series, and statistics.
- **[SciPy](https://scipy.org/)**: Fundamental algorithms for scientific computing in Python.
- **[Pydantic](https://docs.pydantic.dev/)**: Data validation using Python type hints.
- **[SQLAlchemy](https://www.sqlalchemy.org/)**: The Python SQL Toolkit and Object Relational Mapper.

## Visualization & Dashboard

- **[Plotly](https://plotly.com/python/)**: An interactive, open-source, and browser-based graphing library.
- **[Dash](https://dash.plotly.com/)**: A framework for building analytical web applications.
- **[Dash Mantine Components](https://www.dash-mantine-components.com/)**: Dash components based on Mantine React library.
- **[Dash Iconify](https://pypi.org/project/dash-iconify/)**: Icon component for Dash.
- **[Dash Extensions](https://www.dash-extensions.com/)**: A collection of utility components for Dash.
- **[Plotly Resampler](https://github.com/predict-idlab/plotly-resampler)**: Visualizing large time-series data.

## Data Handling

- **[h5py](https://www.h5py.org/)**: A Pythonic interface to the HDF5 binary data format.
- **[DuckDB](https://duckdb.org/)**: An in-process SQL OLAP database management system.
- **[Psycopg2](https://www.psycopg.org/)**: PostgreSQL database adapter for Python.

## Development & Testing

- **[Pytest](https://docs.pytest.org/)**: A framework that makes it easy to write small, readable tests.
- **[Ruff](https://docs.astral.sh/ruff/)**: An extremely fast Python linter and code formatter.
- **[Pre-commit](https://pre-commit.com/)**: A framework for managing and maintaining multi-language pre-commit hooks.

## Documentation

- **[MkDocs](https://www.mkdocs.org/)**: A fast, simple and downright gorgeous static site generator that's geared towards building project documentation.
- **[Material for MkDocs](https://squidfunk.github.io/mkdocs-material/)**: A powerful documentation theme for MkDocs.

---

*This list is automatically generated from the project's dependencies.*
