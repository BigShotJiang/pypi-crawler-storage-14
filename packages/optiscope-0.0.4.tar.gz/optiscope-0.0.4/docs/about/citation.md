# Citation

If you use OptiScope in your research, publications, or projects, we would appreciate it if you cite it.

## BibTeX Entry

```bibtex
@software{optiscope2024,
  title = {OptiScope: Modern Optimization Visualization and Analysis},
  author = {Rodrigues, Simão},
  year = {2024},
  url = {https://github.com/simaosr/optiscope},
  note = {Python library for multi-objective optimization analysis and visualization}
}
```

## Text Citation

> Rodrigues, S. (2024). OptiScope: Modern Optimization Visualization and Analysis. 
> Retrieved from https://github.com/simaosr/optiscope

## How to Cite

When citing OptiScope in your work, please include:

1. **The software name**: OptiScope
2. **The author**: Simão Rodrigues
3. **The year**: 2024
4. **The URL**: https://github.com/simaosr/optiscope

## Example Citations in Papers

### In the Methods Section

> "Optimization results were analyzed and visualized using OptiScope (Rodrigues, 2024), 
> a Python library for multi-objective optimization analysis."

### In the Tools/Software Section

> "We used OptiScope [1] for Pareto front identification, TOPSIS-based ranking, 
> and interactive visualization of the optimization results."
>
> [1] Rodrigues, S. (2024). OptiScope: Modern Optimization Visualization and Analysis. 
> https://github.com/simaosr/optiscope

## Acknowledgments

If you found OptiScope helpful for your research, we also appreciate acknowledgments in your papers:

> "The authors would like to thank the developers of OptiScope for providing 
> an open-source tool for optimization analysis and visualization."

## Why Cite?

Citing OptiScope helps:

- **Give credit** to the development effort
- **Increase visibility** of the tool in the research community
- **Help others** discover useful tools for their work
- **Support open-source** software development

## Questions?

If you have questions about how to cite OptiScope or need a different citation format, 
please [open an issue](https://github.com/simaosr/optiscope/issues) on GitHub.
