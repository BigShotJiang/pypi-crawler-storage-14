# About OptiScope

OptiScope is a modular library and dashboard for visualizing single- and multi-objective optimization results with Multi-Criteria Decision Analysis (MCDA) support.

## What is OptiScope?

Optimization processes often generate vast amounts of data, especially in multi-objective scenarios where trade-offs between conflicting objectives need to be analyzed. OptiScope aims to bridge the gap between raw optimization results and actionable insights.

It provides:
- A **Python Library** for programmatic access to data structures, I/O handlers, and analysis tools.
- A **Dash Application** for interactive exploration of results without writing code.

## Key Features

- **Unified Data Model**: Handle results from various solvers with a consistent interface.
- **Interactive Visualization**: Explore high-dimensional data using Parallel Coordinates, Scatter Matrices, and more.
- **Decision Support**: Apply MCDA methods like TOPSIS to rank and select solutions.
- **Extensibility**: Easily add support for new file formats and create custom visualization pages.

## Author

OptiScope is developed and maintained by **Simão Rodrigues**.

- **GitHub**: [simaosr](https://github.com/simaosr)

## AI-Assisted Development

!!! info "Transparency Notice"
    While the concept, design, and vision for OptiScope are original and driven by the my specific requirements and vision, a very significant portion of the codebase was developed with the assistance of Large Language Model (LLM) AI tools.
    
    These AI tools were used as collaborative coding assistants to help implement features, write documentation, and accelerate development. All architectural decisions, feature specifications, and quality control remain, to the maximum extent possible under human oversight.
    
    I believe in being transparent about the development process and acknowledge the valuable role that AI-assisted development tools played in bringing this project to life.

## License

OptiScope is open-source software licensed under the [MIT License](license.md).
