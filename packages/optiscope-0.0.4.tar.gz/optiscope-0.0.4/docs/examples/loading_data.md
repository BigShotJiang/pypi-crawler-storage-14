# Loading Data

OptiScope supports loading optimization results from various file formats.

## Supported Formats

OptiScope comes with built-in handlers for:

- **CSV** - Comma-separated values
- **JSON** - JavaScript Object Notation

## Basic Usage

### Loading from CSV

```python
from optiscope.io.csv_handler import CSVHandler

# Create a handler instance
csv_handler = CSVHandler()

# Load optimization results
result = csv_handler.read("path/to/results.csv")

# Access the data
print(f"Loaded {len(result.objectives)} solutions")
print(f"Objectives: {result.metadata.objective_names}")
print(f"Design variables: {result.metadata.design_var_names}")
```

### Loading from JSON

```python
from optiscope.io.json_handler import JSONHandler

# Create a handler instance
json_handler = JSONHandler()

# Load optimization results
result = json_handler.read("path/to/results.json")

# The result object is the same regardless of file format
print(f"Loaded {len(result.objectives)} solutions")
```

## Using the Format Registry

OptiScope automatically detects the file format based on the extension:

```python
from optiscope.io import load_results

# Automatically detects format from extension
result = load_results("path/to/results.csv")  # Uses CSVHandler
result = load_results("path/to/results.json")  # Uses JSONHandler
```

## Saving Results

You can save results in any supported format:

```python
from optiscope.io import save_results

# Save in different formats
save_results(result, "output.csv")
save_results(result, "output.json")
```

## Loading Multiple Files

Load and combine results from multiple optimization runs:

```python
from optiscope.io import load_results

# Load multiple results
results = []
for i in range(5):
    result = load_results(f"run_{i}.csv")
    results.append(result)

# Combine or compare results
print(f"Loaded {len(results)} optimization runs")
for i, result in enumerate(results):
    print(f"Run {i}: {len(result.objectives)} solutions")
```

## Advanced: Custom File Handlers

For custom file formats, you can create your own handler. See the [Custom File Handlers](file_handlers.md) guide for details.

## Data Structure

Regardless of the file format, all handlers return an `OptimizationResult` object with:

- **`objectives`**: NumPy array of objective values (n_solutions, n_objectives)
- **`design_vars`**: NumPy array of design variables (n_solutions, n_vars)
- **`constraints`**: Optional constraint values
- **`metadata`**: Metadata including variable names, optimization directions, etc.
- **`sets`**: Dictionary of result sets (subsets of solutions)

```python
# Access data from loaded result
print(f"Objectives shape: {result.objectives.shape}")
print(f"Design vars shape: {result.design_vars.shape}")
print(f"Optimization directions: {result.metadata.optimization_directions}")

# Access specific solutions
best_idx = result.objectives.iloc[:, 0].argmin()  # Best for first objective
print(f"Best solution objectives: {result.objectives[best_idx]}")
print(f"Best solution design vars: {result.design_vars[best_idx]}")
```
