# Examples

Welcome to the OptiScope examples section! Here you'll find comprehensive, practical examples covering all aspects of using OptiScope for optimization analysis and visualization.

## Available Examples

### [📥 Loading Data](loading_data.md)
Learn how to load optimization results from various file formats and understand the OptiScope data model.

### [📊 Working with Result Sets](result_sets.md)
Organize and track different subsets of solutions using result sets.

### [🔍 Analysis Examples](analysis.md)
Use OptiScope's analysis tools including Pareto identification, Smart Pareto Filter, TOPSIS, and knee detection.

### [📈 Visualization Examples](visualization.md)
Create powerful interactive visualizations including parallel coordinates, SPLOM, Pareto front plots, and optimization history.

### [🚀 Complete Workflow](complete_workflow.md)
A comprehensive end-to-end example demonstrating the full power of OptiScope from data loading to final results.

### [🔧 Custom File Handlers](file_handlers.md)
Create custom file handlers for proprietary or specialized data formats.

## Getting Started

If you're new to OptiScope, we recommend starting with the [Overview](library_usage.md) page, which provides a quick introduction and links to all detailed examples.

For a hands-on introduction, jump straight to the [Complete Workflow](complete_workflow.md) to see everything in action!
