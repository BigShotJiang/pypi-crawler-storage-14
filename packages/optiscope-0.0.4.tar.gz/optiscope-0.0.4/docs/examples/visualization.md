# Visualization Examples

This guide provides comprehensive examples of using OptiScope's visualization tools to explore and present optimization results.

## Parallel Coordinates Plot

Parallel coordinates are excellent for visualizing high-dimensional data and exploring trade-offs between multiple variables.

### Basic Usage

```python
from optiscope.plotting import plot_parallel_coordinates

# Basic usage - shows all objectives and design variables
fig = plot_parallel_coordinates(result)
fig.show()
```

### Customizing Display

```python
# Customize what to display
fig = plot_parallel_coordinates(
    result,
    include_design_vars=True,
    include_objectives=True,
    include_constraints=False,
    color_by="objective_0",  # Color lines by first objective
    highlight_feasible=True,  # Highlight feasible solutions
    title="Optimization Results - Parallel Coordinates"
)
fig.show()
```

### Highlighting Result Sets

```python
# Highlight specific result sets
# This is useful after creating result sets from analysis
fig = plot_parallel_coordinates(
    result,
    result_sets=["pareto_front", "top_3_recommended"],  # Show only these sets
    color_by="Set",  # Color by result set membership
    title="Pareto Front and Top Solutions"
)
fig.show()
```

### Saving Plots

```python
# Save to HTML for interactive sharing
fig.write_html("parallel_coordinates.html")

# Save as static image
fig.write_image("parallel_coordinates.png", width=1200, height=800)
```

## Scatter Plot Matrix (SPLOM)

SPLOM shows all pairwise relationships between variables in a grid layout.

### Auto-Select Variables

```python
from optiscope.plotting import plot_scatter_matrix

# Auto-select variables (limited to avoid overcrowding)
fig = plot_scatter_matrix(result)
fig.show()
```

### Manual Variable Selection

```python
# Manually specify variables to include
fig = plot_scatter_matrix(
    result,
    variables=["design_var_0", "design_var_1", "objective_0", "objective_1"],
    color_by="objective_0",
    show_distributions=True,  # Show histograms on diagonal
    title="Scatter Matrix - Key Variables"
)
fig.show()
```

### Highlighting Result Sets

```python
# Highlight result sets with different colors and markers
fig = plot_scatter_matrix(
    result,
    variables=["objective_0", "objective_1", "objective_2"],
    color_by="Set",  # Color by result set
    marker_by="Set",  # Different markers for different sets
    result_sets=["pareto_front", "filtered_pareto"],
    title="Pareto Front Analysis"
)
fig.show()
```

### Objectives Only

```python
# Focus on objective space only
objective_names = [f"objective_{i}" for i in range(len(result.metadata.objective_names))]
fig = plot_scatter_matrix(
    result,
    variables=objective_names,
    color_by="objective_0",
    show_distributions=True,
    title="Objective Space Exploration"
)
fig.show()
```

## Correlation Heatmap

Visualize correlations between all variables to identify relationships.

### All Variables

```python
from optiscope.plotting import plot_correlation_heatmap

# Show correlations for all variables
fig = plot_correlation_heatmap(
    result,
    include_objectives=True,
    include_design_vars=True,
    include_constraints=False,
    method="pearson",  # or "spearman" for rank correlation
    title="Variable Correlations"
)
fig.show()
```

### Objectives Only

```python
# Focus on objectives only
fig = plot_correlation_heatmap(
    result,
    include_objectives=True,
    include_design_vars=False,
    include_constraints=False,
    title="Objective Correlations"
)
fig.show()
```

### Design Variables Only

```python
# Focus on design variables
fig = plot_correlation_heatmap(
    result,
    include_objectives=False,
    include_design_vars=True,
    include_constraints=False,
    method="spearman",  # Spearman for non-linear relationships
    title="Design Variable Correlations"
)
fig.show()
```

## Pareto Front Visualization

Specialized plots for 2D and 3D Pareto fronts.

### 2D Pareto Front

```python
from optiscope.plotting import plot_pareto_front_2d

# Basic 2D Pareto front (for 2-objective problems)
fig_2d = plot_pareto_front_2d(
    result,
    obj_x=0,  # First objective on x-axis
    obj_y=1,  # Second objective on y-axis
    pareto_set="pareto_front",  # Name of the Pareto result set
    show_dominated=True,  # Show dominated solutions in gray
    show_ideal_nadir=True,  # Show ideal and nadir points
    title="Pareto Front - 2D View"
)
fig_2d.show()
```

### 3D Pareto Front

```python
from optiscope.plotting import plot_pareto_front_3d

# 3D Pareto front (for 3-objective problems)
fig_3d = plot_pareto_front_3d(
    result,
    obj_x=0,
    obj_y=1,
    obj_z=2,
    pareto_set="pareto_front",
    show_surface=True,  # Render as a surface
    title="Pareto Front - 3D View"
)
fig_3d.show()
```

### Comparing Pareto Fronts

```python
# Compare filtered vs full Pareto front
fig_comparison = plot_pareto_front_2d(
    result,
    obj_x=0,
    obj_y=1,
    result_sets=["pareto_front", "filtered_pareto"],
    color_by="Set",
    title="Full vs Filtered Pareto Front"
)
fig_comparison.show()
```

### Multiple Result Sets

```python
# Compare multiple result sets on Pareto front
fig = plot_pareto_front_2d(
    result,
    obj_x=0,
    obj_y=1,
    result_sets=["pareto_front", "filtered_pareto", "top_3_recommended", "knee_point"],
    color_by="Set",
    marker_by="Set",
    title="Pareto Front Analysis - All Result Sets"
)
fig.show()
```

## Optimization History Plots

Visualize how objectives, variables, and constraints evolve over iterations.

### Complete Optimization History

```python
from optiscope.plotting.time_series import plot_optimization_history

# Plot all optimization history (objectives, variables, constraints)
# This creates separate plots for each category
figs = plot_optimization_history(
    result,
    variables=None,  # None means auto-select all
    objectives=None,
    constraints=None,
    show_markers=True,
    show_feasibility=True
)

# Show each figure
for category, fig in figs.items():
    print(f"Showing {category}...")
    fig.show()
```

### Specific Objectives Over Time

```python
from optiscope.plotting.time_series import plot_time_series

# Plot specific objectives over time
fig_objectives = plot_time_series(
    result,
    columns=["objective_0", "objective_1"],
    data_attr="objectives",
    title="Objective Evolution",
    show_markers=True,
    single_plot=True  # Show all on one plot
)
fig_objectives.show()
```

### Design Variables Over Time

```python
# Plot design variables over time
fig_variables = plot_time_series(
    result,
    columns=["design_var_0", "design_var_1", "design_var_2"],
    data_attr="design_vars",
    title="Design Variable Evolution",
    show_markers=False,
    single_plot=False  # Separate subplot for each variable
)
fig_variables.show()
```

### Constraints Over Time

```python
from optiscope.plotting.time_series import plot_constraints_time_series

# Plot constraints to see feasibility evolution
if result.constraints is not None:
    fig_constraints = plot_constraints_time_series(
        result,
        columns=None,  # Auto-select all constraints
        title="Constraint Violation Over Time",
        show_markers=False,
        show_feasibility=True
    )
    fig_constraints.show()
```

### All Objectives in Separate Subplots

```python
# Show each objective in its own subplot
objective_names = [f"objective_{i}" for i in range(result.objectives.shape[1])]
fig = plot_time_series(
    result,
    columns=objective_names,
    data_attr="objectives",
    title="All Objectives Evolution",
    show_markers=False,
    single_plot=False  # Each objective gets its own subplot
)
fig.show()
```

## Large Optimization History (Resampled)

For very large datasets (thousands of iterations), use the resampled version for better performance.

### Basic Resampled Plot

```python
from optiscope.plotting.time_series import plot_time_series_resampled

# This requires plotly-resampler to be installed
# pip install plotly-resampler

# Plot large optimization history with automatic downsampling
fig_resampled = plot_time_series_resampled(
    result,
    columns=["objective_0", "objective_1", "objective_2"],
    data_attr="objectives",
    title="Objective Evolution (Resampled)",
    show_markers=False,  # Markers not recommended for large datasets
    single_plot=False,
    max_n_samples=1000  # Maximum points to show at any zoom level
)

# The plot will dynamically resample based on zoom level
fig_resampled.show()
```

### Resampled Design Variables

```python
# Use resampled version for design variables
fig_vars_resampled = plot_time_series_resampled(
    result,
    columns=None,  # Auto-select all design variables
    data_attr="design_vars",
    title="Design Variables (Resampled)",
    max_n_samples=500,
    single_plot=False
)
fig_vars_resampled.show()
```

### When to Use Resampled Plots

Use `plot_time_series_resampled` when:

- You have >10,000 iterations
- The regular plot is slow or unresponsive
- You want to zoom in on specific regions without loading all data

```python
# Check if resampling is needed
n_iterations = len(result.objectives)
if n_iterations > 10000:
    print(f"Dataset has {n_iterations} iterations - using resampled plot")
    fig = plot_time_series_resampled(
        result,
        columns=["objective_0"],
        data_attr="objectives",
        max_n_samples=1000
    )
else:
    print(f"Dataset has {n_iterations} iterations - using regular plot")
    fig = plot_time_series(
        result,
        columns=["objective_0"],
        data_attr="objectives"
    )
fig.show()
```

## Interactive Scatter Plot

Flexible scatter plot for exploring relationships between any two variables.

### Basic Scatter

```python
from optiscope.plotting.interactive_scatter import create_interactive_scatter

# Basic scatter plot
fig = create_interactive_scatter(
    result,
    x_var="design_var_0",
    y_var="objective_0",
    title="Design Variable vs Objective"
)
fig.show()
```

### With Color and Markers

```python
# Customize colors and markers
fig = create_interactive_scatter(
    result,
    x_var="objective_0",
    y_var="objective_1",
    color_by="objective_2",  # Color by third objective
    marker_by="Set",  # Different markers for different result sets
    result_sets=["pareto_front", "filtered_pareto"],
    title="Objective Space with Result Sets"
)
fig.show()
```

## Combining Visualizations

Create a comprehensive visualization dashboard by combining multiple plots.

### Multi-View Dashboard

```python
from optiscope.plotting import (
    plot_parallel_coordinates,
    plot_pareto_front_2d,
    plot_scatter_matrix,
    plot_correlation_heatmap
)

# 1. Parallel coordinates for overview
fig_parallel = plot_parallel_coordinates(
    result,
    result_sets=["pareto_front", "filtered_pareto", "best_solution"],
    color_by="Set",
    title="1. Overview - Parallel Coordinates"
)

# 2. Pareto front visualization
fig_pareto = plot_pareto_front_2d(
    result,
    obj_x=0,
    obj_y=1,
    result_sets=["pareto_front", "filtered_pareto", "best_solution"],
    color_by="Set",
    title="2. Pareto Front Analysis"
)

# 3. Scatter matrix of objectives
objective_names = [f"objective_{i}" for i in range(len(result.metadata.objective_names))]
fig_splom = plot_scatter_matrix(
    result,
    variables=objective_names,
    result_sets=["filtered_pareto", "best_solution"],
    color_by="Set",
    title="3. Objective Space - SPLOM"
)

# 4. Correlation heatmap
fig_corr = plot_correlation_heatmap(
    result,
    include_objectives=True,
    include_design_vars=True,
    title="4. Variable Correlations"
)

# Show all plots
fig_parallel.show()
fig_pareto.show()
fig_splom.show()
fig_corr.show()

# Save all plots
fig_parallel.write_html("1_parallel_coordinates.html")
fig_pareto.write_html("2_pareto_front.html")
fig_splom.write_html("3_scatter_matrix.html")
fig_corr.write_html("4_correlations.html")
```

### Before and After Analysis

```python
# Compare before and after applying analysis

# Before: All solutions
fig_before = plot_parallel_coordinates(
    result,
    color_by="objective_0",
    title="Before Analysis - All Solutions"
)

# After: Only filtered Pareto front
fig_after = plot_parallel_coordinates(
    result,
    result_sets=["filtered_pareto"],
    color_by="objective_0",
    title="After Analysis - Filtered Pareto Front"
)

fig_before.show()
fig_after.show()
```

## Customization Options

### Figure Size and Layout

```python
# Customize figure size
fig = plot_parallel_coordinates(result)
fig.update_layout(
    width=1400,
    height=600,
    margin=dict(l=50, r=50, t=80, b=50)
)
fig.show()
```

### Color Scales

```python
# Use different color scales
fig = plot_scatter_matrix(
    result,
    variables=["objective_0", "objective_1", "objective_2"],
    color_by="objective_0",
    colorscale="Viridis",  # or "Plasma", "Inferno", "RdBu", etc.
    title="Custom Color Scale"
)
fig.show()
```

### Themes

```python
# Apply different themes
fig = plot_pareto_front_2d(result, obj_x=0, obj_y=1)
fig.update_layout(template="plotly_dark")  # or "plotly_white", "ggplot2", etc.
fig.show()
```

## Export Options

### Save as HTML

```python
# Save interactive HTML (can be opened in browser)
fig = plot_parallel_coordinates(result)
fig.write_html(
    "interactive_plot.html",
    include_plotlyjs="cdn",  # Use CDN for smaller file size
    config={'displayModeBar': True}
)
```

### Save as Static Image

```python
# Requires kaleido: pip install kaleido

# Save as PNG
fig = plot_pareto_front_2d(result, obj_x=0, obj_y=1)
fig.write_image("pareto_front.png", width=1200, height=800, scale=2)

# Save as SVG (vector graphics)
fig.write_image("pareto_front.svg", width=1200, height=800)

# Save as PDF
fig.write_image("pareto_front.pdf", width=1200, height=800)
```

## Tips and Best Practices

### When to Use Each Visualization

- **Parallel Coordinates**: Best for exploring high-dimensional spaces and understanding variable relationships across all solutions
- **SPLOM**: Best for identifying correlations and patterns between specific variables
- **Pareto Front Plots**: Essential for 2-3 objective problems to visualize trade-offs
- **Time Series**: Essential for understanding convergence and optimization dynamics
- **Correlation Heatmap**: Quick overview of variable relationships

### Performance Considerations

```python
# For large datasets (>10,000 points)
# 1. Use resampled time series
# 2. Limit SPLOM variables to 5-7
# 3. Filter to result sets before plotting

# Example: Plot only Pareto front instead of all solutions
fig = plot_parallel_coordinates(
    result,
    result_sets=["pareto_front"],  # Much faster than all solutions
    color_by="objective_0"
)
```

### Creating Publication-Quality Figures

```python
# High-resolution, clean figures for papers
fig = plot_pareto_front_2d(result, obj_x=0, obj_y=1, pareto_set="pareto_front")

# Update for publication
fig.update_layout(
    template="plotly_white",
    font=dict(family="Arial", size=14),
    title=dict(font=dict(size=18)),
    width=800,
    height=600,
    margin=dict(l=80, r=50, t=80, b=80)
)

# Update axis labels
fig.update_xaxes(title_font=dict(size=16))
fig.update_yaxes(title_font=dict(size=16))

# Save as high-res PNG
fig.write_image("publication_figure.png", width=800, height=600, scale=3)
```
