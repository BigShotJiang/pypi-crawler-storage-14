---
hide:
  - navigation
  - toc
---
<!-- 
# OptiScope -->

#

<div align="center" markdown>
  <img src="assets/logo.svg" alt="OptiScope Logo" width="600"/>
  
  **Modern Optimization Visualization and Analysis**
  
  Comprehensive Python library for visualizing and analyzing single- and multi-objective optimization results.

  [Get Started](getting-started/installation.md){ .md-button .md-button--primary }
  [View Examples](examples/index.md){ .md-button }
  [GitHub](https://github.com/simaosr/optiscope){ .md-button }
</div>

---

## Features

<div class="grid cards" markdown>

-   :material-chart-scatter-plot:{ .lg .middle } **Rich Visualizations**

    ---

    Interactive Pareto fronts, parallel coordinates, scatter matrices, and more.
    
    [:octicons-arrow-right-24: Plotting Guide](user-guide/visualization.md)

-   :material-filter:{ .lg .middle } **Advanced Analysis**

    ---

    Smart Pareto Filter, knee point detection, TOPSIS, and quality metrics.
    
    [:octicons-arrow-right-24: Analysis Tools](user-guide/analysis.md)

-   :material-database:{ .lg .middle } **Flexible Storage**

    ---

    Memory, filesystem, or database backends with caching and replication.
    
    [:octicons-arrow-right-24: Storage Guide](user-guide/storage.md)

-   :material-application:{ .lg .middle } **Interactive Dashboard**

    ---

    Modular Dash application with auto-discovery and page templates.
    
    [:octicons-arrow-right-24: Dash App](dash-app/index.md)

-   :material-file-multiple:{ .lg .middle } **Format Agnostic**

    ---

    CSV, JSON, HDF5, and custom formats with automatic detection.
    
    [:octicons-arrow-right-24: File Formats](user-guide/file-formats.md)

-   :material-api:{ .lg .middle } **Extensible API**

    ---

    Clean, type-safe API with comprehensive documentation.
    
    [:octicons-arrow-right-24: API Reference](api-reference/index.md)

</div>

---

## Quick Example

```python
from optiscope import load_results
from optiscope.plotting import plot_pareto_front_2d
from optiscope.analysis import smart_pareto_filter, topsis_from_result

# Load optimization results
result = load_results("optimization_data.csv")

# Filter to representative Pareto points
pareto_indices = smart_pareto_filter(result.objectives, epsilon=0.15)
result.create_set("pareto", pareto_indices, "smart_filter")

# Visualize Pareto front
fig = plot_pareto_front_2d(
    result,
    obj_x="cost",
    obj_y="weight",
    pareto_set="pareto",
    show_ideal_nadir=True
)
fig.show()

# Rank solutions with TOPSIS
topsis_result = topsis_from_result(
    result,
    weights={"cost": 0.5, "weight": 0.3, "efficiency": 0.2}
)

print(f"Best solution: {topsis_result['ranks'][0]}")
```