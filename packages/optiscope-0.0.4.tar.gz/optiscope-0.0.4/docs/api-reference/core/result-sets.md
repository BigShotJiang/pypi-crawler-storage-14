# Result Sets

::: optiscope.core.result_set
