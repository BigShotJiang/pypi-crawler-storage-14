# Data Model

::: optiscope.core.data_model
