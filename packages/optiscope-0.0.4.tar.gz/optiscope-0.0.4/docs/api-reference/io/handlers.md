# Format Handlers

## Base Handler
::: optiscope.io.base

## CSV Handler
::: optiscope.io.csv_handler

## JSON Handler
::: optiscope.io.json_handler

## MIDACO Handler
::: optiscope.io.midaco_handler
