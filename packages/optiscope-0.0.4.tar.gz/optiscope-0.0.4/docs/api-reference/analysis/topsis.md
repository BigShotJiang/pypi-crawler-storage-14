# TOPSIS

::: optiscope.analysis.topsis
