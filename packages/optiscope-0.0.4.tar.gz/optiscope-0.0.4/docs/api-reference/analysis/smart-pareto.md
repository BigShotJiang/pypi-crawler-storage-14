# Smart Pareto Filter

::: optiscope.analysis.smart_pareto
