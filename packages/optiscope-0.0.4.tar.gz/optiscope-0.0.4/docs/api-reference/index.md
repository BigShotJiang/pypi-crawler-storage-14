# API Reference

Welcome to the OptiScope API Reference. This documentation is automatically generated from the source code.

## Core
- [Data Model](core/data-model.md)
- [Data Types](core/data-types.md)
- [Result Sets](core/result-sets.md)

## I/O
- [Format Handlers](io/handlers.md)
- [Registry](io/registry.md)

## Storage
- [Storage Backends](storage/backends.md)
- [Storage Manager](storage/manager.md)

## Plotting
- [Pareto Viewer](plotting/pareto-viewer.md)
- [Parallel Coordinates](plotting/parallel-coordinates.md)
- [Scatter Matrix](plotting/scatter-matrix.md)

## Analysis
- [Smart Pareto Filter](analysis/smart-pareto.md)
- [Knee Detection](analysis/knee-detection.md)
- [TOPSIS](analysis/topsis.md)
