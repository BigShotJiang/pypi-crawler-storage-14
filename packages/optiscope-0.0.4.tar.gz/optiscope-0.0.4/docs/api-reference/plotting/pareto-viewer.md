# Pareto Viewer

::: optiscope.plotting.pareto_viewer
