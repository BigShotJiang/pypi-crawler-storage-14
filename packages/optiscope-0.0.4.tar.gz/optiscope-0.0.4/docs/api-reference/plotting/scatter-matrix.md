# Scatter Matrix

::: optiscope.plotting.scatter_matrix
