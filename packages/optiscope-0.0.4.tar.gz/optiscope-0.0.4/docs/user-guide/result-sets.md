# Result Sets

Result Sets are a fundamental concept in OptiScope, allowing you to manage and analyze subsets of your optimization data. A `ResultSet` represents a **named subset of points** within an optimization result, rather than a collection of separate results.

## Overview

In complex optimization problems, you often generate thousands of solutions. Result Sets help you organize these solutions into meaningful groups, such as:

- **Pareto Front**: The set of non-dominated solutions.
- **Feasible Region**: Solutions that satisfy all constraints.
- **Selected Designs**: A manually curated list of interesting designs.
- **Cluster A**: A group of solutions with similar characteristics.

## Creating Result Sets

Result Sets can be created in several ways:

1.  **Filtering**: Create a set by applying criteria to the data (e.g., "Objective A < 0.5").
2.  **Manual Selection**: Manually select points from a plot in the Dash app.
3.  **Algorithmic Generation**: Use analysis tools like Pareto sorting or Cluster analysis to automatically generate sets.

## Set Operations

OptiScope supports standard set operations to combine and refine your result sets.

### Union
Combines two sets into a new set containing all unique points from both.
- **Use Case**: Merging "High Performance" and "Low Cost" sets to see all candidate solutions.

### Intersection
Creates a new set containing only points that exist in *both* parent sets.
- **Use Case**: Finding solutions that are both "High Performance" AND "Low Cost".

### Difference
Creates a new set containing points from the first set that are *not* in the second set.
- **Use Case**: Removing "High Risk" solutions from your "Candidate" set.

## Metadata and History

Each `ResultSet` maintains a history of how it was created. This includes:

- **Creation Method**: Whether it was filtered, manually selected, or algorithmically generated.
- **Operations**: A log of set operations (union, intersection, etc.) performed to create this set.
- **Parent Set**: Reference to the set it was derived from.

This lineage tracking ensures that you can always trace back why a particular solution is in a specific set.

## Using Result Sets in the Dash App

In the Dash App, Result Sets are a first-class citizen:

- **Visualization**: You can color-code plots by Result Set to visually distinguish groups.
- **Filtering**: You can choose to view only specific Result Sets in any plot.
- **Export**: You can export specific Result Sets to new files for reporting or further analysis.
