# Data Model

OptiScope uses a structured and extensible data model to represent optimization results. This model is designed to handle various types of optimization problems, from simple single-objective problems to complex multi-objective problems with many constraints and custom data types.

## Core Concepts

The central class in OptiScope is `OptimizationResult`. It serves as a container for all data associated with an optimization run, including:

- **Design Variables**: The input parameters that the optimizer adjusts.
- **Objectives**: The values to be minimized or maximized.
- **Constraints**: Conditions that the solution must satisfy (equality or inequality).
- **Observables**: Additional quantities computed during the optimization that are not objectives or constraints but are useful for analysis.
- **Metadata**: Information about the problem, solver, and variables.
- **Result Sets**: Named subsets of solutions (e.g., "Pareto Front", "Feasible Solutions").

### OptimizationResult

The `OptimizationResult` class organizes data into pandas DataFrames, ensuring efficient storage and manipulation. It guarantees that all data components (variables, objectives, etc.) are aligned, meaning the $i$-th row in the design variables DataFrame corresponds to the $i$-th row in the objectives DataFrame.

```python
from optiscope.core import OptimizationResult

# Accessing data
design_vars = result.design_variables
objectives = result.objectives
constraints = result.inequality_constraints
```

### Problem Metadata

The `ProblemMetadata` class stores high-level information about the optimization problem:

- `name`: Name of the problem.
- `description`: A brief description.
- `solver`: Name of the solver used.
- `run_date`: Date and time of the run.
- `n_evaluations`: Number of function evaluations.

## Variable Types

OptiScope defines specific metadata classes for different types of variables. These classes provide context such as units, bounds, and optimization direction.

### Design Variables

Represent the decision variables of the problem.

- **Properties**: `lower_bound`, `upper_bound`, `is_discrete`, `possible_values`, `initial_value`.

### Objectives

Represent the goals of the optimization.

- **Properties**: `direction` (MINIMIZE or MAXIMIZE), `ideal_value`, `nadir_value`.

### Constraints

Represent the restrictions on the design space.

- **Properties**: `constraint_type` (INEQUALITY, EQUALITY, BOUND), `reference_value`, `tolerance`.
- **Inequality**: $g(x) \le \text{reference\_value}$
- **Equality**: $h(x) = \text{reference\_value}$

### Observables

Represent auxiliary data computed during the run.

## Result Sets

`ResultSet`s allow you to group specific solutions for focused analysis. Common examples include:

- **Pareto Front**: The set of non-dominated solutions.
- **Feasible Set**: Solutions that satisfy all constraints.
- **User Selections**: Subsets manually selected by the user during analysis.

You can create, retrieve, and manipulate sets using the `OptimizationResult` methods:

```python
# Create a set of feasible solutions
feasible_set = result.check_feasibility(set_name="feasible")

# Get data for a specific set
pareto_data = result.get_set_data("pareto_front", category=DataTypeCategory.OBJECTIVE)
```
