# Visualization

OptiScope provides a comprehensive suite of visualization tools designed specifically for multi-objective optimization data. These tools help you explore high-dimensional design spaces, understand trade-offs, and identify patterns in your results.

## Overview

Optimization problems often involve many design variables and objectives, making traditional 2D plots insufficient. OptiScope's visualization tools are built to handle this complexity while remaining interactive and intuitive.

All visualization functions return Plotly figures, which means they are:
- **Interactive**: Pan, zoom, hover for details, and select data points.
- **Exportable**: Save as static images (PNG, SVG) or interactive HTML files.
- **Customizable**: Modify colors, labels, and styling to suit your needs.

## Parallel Coordinates Plot

The parallel coordinates plot is one of the most powerful tools for visualizing high-dimensional data. Each vertical axis represents a variable (design variable, objective, or constraint), and each line represents a solution.

### Key Features

- **Multi-dimensional Visualization**: Display all variables simultaneously.
- **Brushing**: Select ranges on any axis to filter solutions interactively.
- **Color Coding**: Color lines by objective value, feasibility, or result set membership.
- **Direction Awareness**: Automatically flips axes for minimization objectives to make better solutions appear higher.

### Use Cases

- **Exploring Trade-offs**: See how changing one variable affects others.
- **Identifying Patterns**: Spot correlations and clusters in your data.
- **Filtering Solutions**: Interactively narrow down to solutions of interest.

### Example Usage

```python
from optiscope.plotting import plot_parallel_coordinates

# Basic usage - auto-selects all variables
fig = plot_parallel_coordinates(result)

# Customize what to show
fig = plot_parallel_coordinates(
    result,
    include_design_vars=True,
    include_objectives=True,
    include_constraints=False,
    color_by="objective_0",  # Color by first objective
    highlight_feasible=True
)

fig.show()
```

## Pareto Front Viewer

The Pareto front viewer provides specialized 2D and 3D visualizations for exploring non-dominated solutions.

### 2D Pareto Front

Visualize the trade-off between two objectives with:
- **Pareto Set Highlighting**: Clearly distinguish dominated from non-dominated solutions.
- **Ideal and Nadir Points**: Reference points showing the best and worst objective values.
- **Reference Points**: Add custom reference points for comparison.
- **Multiple Sets**: Overlay multiple result sets for comparison.

### 3D Pareto Front

For three-objective problems:
- **Interactive 3D Scatter**: Rotate and zoom to explore the Pareto surface.
- **Optional Surface Rendering**: Visualize the Pareto front as a continuous surface.
- **Hover Information**: See all objective values and key design variables on hover.

### Example Usage

```python
from optiscope.plotting import plot_pareto_front_2d, plot_pareto_front_3d

# 2D Pareto front
fig_2d = plot_pareto_front_2d(
    result,
    obj_x=0,  # First objective
    obj_y=1,  # Second objective
    pareto_set="pareto_front",  # Name of the Pareto set
    show_dominated=True,
    show_ideal_nadir=True
)

# 3D Pareto front
fig_3d = plot_pareto_front_3d(
    result,
    obj_x=0,
    obj_y=1,
    obj_z=2,
    show_surface=True  # Render as surface
)
```

## Scatter Matrix (SPLOM)

The Scatter Plot Matrix shows all pairwise relationships between variables in a grid layout.

### Key Features

- **Pairwise Relationships**: See how every variable relates to every other variable.
- **Distribution Plots**: Diagonal shows histograms of individual variables.
- **Correlation Analysis**: Upper triangle can show correlation coefficients.
- **Linked Brushing**: Select points in one subplot to highlight them across all subplots.
- **Color Coding**: Color by any variable, result set, or feasibility.

### Use Cases

- **Correlation Discovery**: Identify which variables are correlated.
- **Outlier Detection**: Spot unusual solutions that don't follow patterns.
- **Variable Selection**: Determine which variables are most important.

### Example Usage

```python
from optiscope.plotting import plot_scatter_matrix

# Auto-select variables (limited to avoid overcrowding)
fig = plot_scatter_matrix(result)

# Manually specify variables
fig = plot_scatter_matrix(
    result,
    variables=["x1", "x2", "objective_0", "objective_1"],
    color_by="objective_0",
    show_distributions=True,
    show_correlations=True
)
```

## Interactive Scatter Plot

A flexible scatter plot for exploring relationships between any two variables.

### Key Features

- **Custom Axes**: Choose any variable for X and Y axes.
- **Multiple Results**: Overlay data from multiple optimization runs.
- **Result Set Filtering**: Show only specific result sets.
- **Color and Marker Customization**: Color and shape points by different attributes.

### Example Usage

```python
from optiscope.plotting import create_interactive_scatter

fig = create_interactive_scatter(
    result,
    x_var="design_var_0",
    y_var="objective_0",
    color_by="objective_1",
    marker_by="Set"  # Different markers for different sets
)
```

## Time Series Plot

For optimization runs that track convergence over iterations or time.

### Key Features

- **Convergence Tracking**: See how objectives improve over iterations.
- **Multiple Objectives**: Plot all objectives on the same chart.
- **Statistical Bands**: Show confidence intervals or ranges for stochastic optimizers.

## Correlation Heatmap

Visualize correlation coefficients between all variables as a heatmap.

### Example Usage

```python
from optiscope.plotting import plot_correlation_heatmap

fig = plot_correlation_heatmap(
    result,
    include_objectives=True,
    include_design_vars=True,
    method="pearson"  # or "spearman"
)
```

## Customization

All plotting functions support common customization options:

- **`width` and `height`**: Control figure dimensions.
- **`title`**: Set a custom title.
- **`theme`**: Choose from Plotly themes (`"plotly"`, `"plotly_white"`, `"plotly_dark"`, etc.).
- **`colorscale`**: Select color schemes (`"Viridis"`, `"Plasma"`, `"RdBu"`, etc.).

## Using in the Dash App

All these visualization tools are integrated into the Dash App with additional interactive controls:

- **Dynamic Variable Selection**: Choose which variables to plot using dropdowns.
- **Real-time Updates**: Plots update instantly as you change settings.
- **Export Options**: Download plots as images or HTML files.
- **Linked Views**: Selections in one plot can filter data in other plots.
