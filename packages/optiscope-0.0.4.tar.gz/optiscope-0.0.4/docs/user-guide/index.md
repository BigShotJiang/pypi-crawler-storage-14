# User Guide

Welcome to the OptiScope User Guide! This comprehensive guide will help you understand and effectively use OptiScope for your optimization analysis and visualization needs.

## Overview

OptiScope is a modern Python library designed to simplify the analysis and visualization of optimization results. Whether you're working with single-objective or multi-objective optimization problems, OptiScope provides the tools you need to:

- Load and manage optimization results from various file formats
- Organize and filter solutions using result sets
- Visualize high-dimensional optimization data
- Perform advanced analysis on Pareto fronts and solution spaces
- Store and retrieve results efficiently

## What's in This Guide

This user guide is organized into the following sections:

### [Data Model](data-model.md)
Learn about OptiScope's core data structures and how optimization results are represented. This section covers:

- The `OptimizationResult` class and its components
- Design variables, objectives, constraints, and observables
- Problem metadata and variable types
- How data is organized and accessed

### [File Formats](file-formats.md)
Discover the various file formats that OptiScope can read and write. This section includes:

- Supported input formats (CSV, JSON, HDF5, etc.)
- File format specifications and requirements
- How to load optimization results from different sources
- Creating custom file handlers for proprietary formats

### [Storage Backends](storage.md)
Understand how OptiScope manages data persistence and storage. Topics include:

- Available storage backends (Memory, HDF5, SQLite)
- Choosing the right storage backend for your needs
- Saving and loading optimization results
- Managing multiple results efficiently

### [Result Sets](result-sets.md)
Master the concept of result sets for organizing and analyzing subsets of solutions. Learn about:

- What result sets are and why they're useful
- Creating and managing result sets
- Common use cases (Pareto fronts, feasible solutions, user selections)
- Filtering and querying result sets

### [Visualization](visualization.md)
Explore OptiScope's powerful visualization capabilities. This section covers:

- Parallel coordinates plots for multi-dimensional data
- Pareto front viewers for multi-objective optimization
- Scatter matrix plots for correlation analysis
- Interactive scatter plots with customizable axes
- Optimization history visualization

### [Analysis Tools](analysis.md)
Leverage advanced analysis tools to gain insights from your optimization results:

- Pareto front identification and filtering
- Smart Pareto filtering for cleaner fronts
- TOPSIS (Technique for Order of Preference by Similarity to Ideal Solution)
- Knee point detection for trade-off analysis
- Feasibility analysis and constraint checking

## Getting Help

If you're new to OptiScope, we recommend starting with the [Getting Started](../getting-started/index.md) section, which provides a quick introduction and installation guide.

For practical examples and code snippets, check out the [Examples](../examples/index.md) section.

For detailed API documentation, refer to the [API Reference](../api-reference/index.md).

## Next Steps

Ready to dive in? Start with the [Data Model](data-model.md) to understand how OptiScope represents optimization data, or jump directly to any section that interests you using the navigation menu.
