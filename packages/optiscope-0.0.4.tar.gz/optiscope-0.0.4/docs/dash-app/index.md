# OptiScope Dash App

The OptiScope Dash App is a comprehensive web-based interface for visualizing and analyzing optimization results. It provides an intuitive, interactive environment for exploring multi-dimensional optimization data, managing datasets, and performing advanced analysis.

## What is the Dash App?

The Dash App is a standalone web application built with Plotly Dash that serves as the primary user interface for OptiScope. It transforms your optimization data into interactive visualizations and provides tools for in-depth analysis—all through your web browser.

**No coding required**: While OptiScope provides a powerful Python library, the Dash App offers a complete analysis environment without writing a single line of code.

## Key Features

### 📊 Interactive Visualizations
- **Parallel Coordinates**: Visualize high-dimensional data with interactive brushing and filtering
- **Scatter Matrices**: Explore relationships between variables and objectives
- **Interactive Scatter Plots**: Create custom 2D scatter plots with advanced filtering
- **Optimization History**: Track the evolution of variables, objectives, and constraints over time

### 💾 Data Management
- **Multiple Data Sources**: Upload and manage multiple optimization results simultaneously
- **Flexible Storage**: Support for CSV, JSON, SQLite, and DuckDB formats
- **Result Sets**: Create and manage custom subsets of optimization points
- **Export Capabilities**: Export selected results to database formats

### 🔍 Analysis Tools
- **Pareto Front Identification**: Automatically identify Pareto-optimal solutions
- **Smart Pareto Filtering**: Advanced filtering with epsilon-dominance
- **Feasibility Analysis**: Identify feasible and infeasible solutions
- **Set Management**: Create, edit, and delete custom sets of solutions

### 🎨 User Experience
- **Responsive Design**: Works seamlessly on desktop and tablet devices
- **Dark/Light Themes**: Choose your preferred visual theme
- **Real-time Updates**: Interactive components update instantly
- **Extensible Architecture**: Easy to add custom pages and visualizations

## Getting Started

### Running the App

To start the Dash app locally:

```bash
python -m optiscope.dash_app.app
```

The app will start at `http://127.0.0.1:8050`. Open this URL in your web browser.

### Quick Start Guide

1. **Load Data**: Navigate to [Data Manager](pages/data-manager.md) and upload your optimization results
2. **Explore**: Use [Data Viewer](pages/data-viewer.md) to browse your data
3. **Create Sets**: Use [Sets Manager](pages/sets-manager.md) to create Pareto and feasible sets
4. **Visualize**: Explore your data with [visualization pages](pages/index.md)
5. **Analyze**: Use interactive features to gain insights

## Documentation Structure

- **[Usage Guide](usage.md)**: Learn how to use the app effectively
- **[Page Reference](pages/index.md)**: Detailed documentation for each page
- **[Adding Pages](adding_pages.md)**: Extend the app with custom pages

## Who Should Use the Dash App?

### Optimization Engineers
- Analyze optimization results without coding
- Create visualizations for reports and presentations
- Compare different optimization runs
- Identify optimal solutions quickly

### Researchers
- Explore multi-objective optimization results
- Understand algorithm behavior
- Validate optimization convergence
- Publish-ready visualizations

### Decision Makers
- Review optimization outcomes
- Compare solution alternatives
- Understand trade-offs
- Make informed decisions

### Developers
- Prototype new analysis tools
- Extend with custom pages
- Integrate with existing workflows
- Build domain-specific applications

## Next Steps

- **[Usage Guide](usage.md)**: Learn the basics of using the app
- **[Data Manager](pages/data-manager.md)**: Start by loading your data
- **[Page Reference](pages/index.md)**: Explore all available pages
- **[Adding Pages](adding_pages.md)**: Customize the app for your needs
