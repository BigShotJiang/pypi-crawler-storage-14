# Using the Dash App

## Running the App

To start the Dash app locally, run the following command in your terminal:

```bash
python -m optiscope.dash_app.app
```

This will start the server at `http://127.0.0.1:8050`. Open this URL in your web browser to access the application.

## Navigation

The app features a sidebar navigation menu that organizes tools into categories:

- **Home**: Overview and quick access to recent results.
- **Data**: Tools for uploading and managing data.
- **Visualization**: Interactive plots for exploring results.
- **Analysis**: Advanced analysis tools like TOPSIS and Pareto filtering.

## Managing Data

1. Go to the **Data Manager** page.
2. Upload your result files (CSV, JSON, etc.).
3. The uploaded results will be available across all other pages.
4. You can select the active result set using the dropdown in the top header.

### Data Loading Behavior

When you upload files to the Data Manager, the application handles them differently based on their type:

- **Database Files (`.db`, `.sqlite`, `.duckdb`)**: 
  These files are **copied to a temporary file** on the server. The application then connects to this temporary file to query data as needed. This ensures efficient access without loading the entire database into memory.

- **Text/Data Files (CSV, JSON, etc.)**:
  The content of these files is read and **added to the local session database**. This means the data is fully ingested into the application's active storage for the current session.

- **Direct Database Connection**:
  Alternatively, you can **connect directly** to an existing database file on the server/local filesystem by providing its absolute path. In this case, the application connects to the file in-place **without creating a copy**. This is ideal for large databases or shared resources.
