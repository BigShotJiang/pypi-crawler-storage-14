# Dash App Overview

The OptiScope Dash App is a comprehensive web-based interface for visualizing and analyzing optimization results. It provides an intuitive, interactive environment for exploring multi-dimensional optimization data, managing datasets, and performing advanced analysis.

## Key Features

### 📊 Interactive Visualizations
- **Parallel Coordinates**: Visualize high-dimensional data with interactive brushing and filtering
- **Scatter Matrices**: Explore relationships between variables and objectives
- **Interactive Scatter Plots**: Create custom 2D scatter plots with advanced filtering
- **Optimization History**: Track the evolution of variables, objectives, and constraints over time

### 💾 Data Management
- **Multiple Data Sources**: Upload and manage multiple optimization results simultaneously
- **Flexible Storage**: Support for CSV, JSON, SQLite, and DuckDB formats
- **Result Sets**: Create and manage custom subsets of optimization points
- **Export Capabilities**: Export selected results to database formats

### 🔍 Analysis Tools
- **Pareto Front Identification**: Automatically identify Pareto-optimal solutions
- **Smart Pareto Filtering**: Advanced filtering with epsilon-dominance
- **Feasibility Analysis**: Identify feasible and infeasible solutions
- **Set Management**: Create, edit, and delete custom sets of solutions

### 🎨 User Experience
- **Responsive Design**: Works seamlessly on desktop and tablet devices
- **Dark/Light Themes**: Choose your preferred visual theme
- **Real-time Updates**: Interactive components update instantly
- **Extensible Architecture**: Easy to add custom pages and visualizations

## Application Structure

The app is organized into several categories:

### Data Management
- **Data Manager**: Upload, connect, and manage optimization results
- **Data Viewer**: Browse and explore your optimization data in table format
- **Sets Manager**: Create and manage custom sets of solutions

### Visualization
- **Parallel Coordinates**: Multi-dimensional visualization with parallel axes
- **Scatterplot Matrix**: Matrix of scatter plots for variable relationships
- **Interactive Scatter**: Customizable 2D scatter plots with filtering
- **Optimization History**: Time series visualization of optimization progress

### Utilities
- **Settings**: Configure application preferences
- **Logs**: View application logs for debugging
- **Storage Viewer**: Inspect the internal storage structure

## Getting Started

1. **Start the App**: Run `python -m optiscope.dash_app.app`
2. **Load Data**: Navigate to the Data Manager and upload your optimization results
3. **Explore**: Use the visualization pages to explore your data
4. **Analyze**: Create sets and perform analysis on your results
5. **Export**: Export your findings for further use

## Navigation

The app features a sidebar navigation menu that organizes tools by category. Pages marked with a home icon appear on the welcome page for quick access. The navigation is context-aware—pages requiring data will be disabled until you load results.

## Next Steps

- [Learn how to use the app](usage.md)
- [Explore individual pages](pages/home.md)
- [Learn how to add custom pages](adding_pages.md)
