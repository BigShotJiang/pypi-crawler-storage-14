# Dash App Pages

This section provides detailed documentation for each page in the OptiScope Dash App. Each page is designed for specific tasks in the optimization analysis workflow.

## Data Management Pages

### [Home](home.md)
The landing page providing quick access to all features and showing what's new in OptiScope.

### [Data Manager](data-manager.md)
Upload, connect to, and manage your optimization results. This is your starting point for working with data.

**Key Features:**
- Upload CSV, JSON, SQLite, and DuckDB files
- Connect to existing databases
- Export selected results
- Manage multiple data sources

### [Data Viewer](data-viewer.md)
Browse and explore your optimization data in a comprehensive table format.

**Key Features:**
- Sortable and filterable table
- View all variables, objectives, and constraints
- Select rows for analysis
- Filter by sets

### [Sets Manager](sets-manager.md)
Create and manage custom subsets of optimization solutions.

**Key Features:**
- Create custom sets manually
- Generate default sets (Pareto, feasible, etc.)
- Edit and delete sets
- Use sets across all visualization pages

## Visualization Pages

### [Parallel Coordinates](parallel-coordinates.md)
Visualize high-dimensional data with interactive parallel axes.

**Key Features:**
- Display many variables simultaneously
- Interactive brushing for filtering
- Color coding by sets or values
- Identify patterns and correlations

**Best For:**
- Multi-dimensional exploration
- Interactive filtering
- Pattern identification
- Trade-off analysis

### [Scatterplot Matrix](scatterplot-matrix.md)
View pairwise scatter plots of variables and objectives.

**Key Features:**
- All pairwise combinations
- Separate matrices for variables and objectives
- Correlation identification
- Multiple result comparison

**Best For:**
- Understanding variable relationships
- Identifying correlations
- Exploring objective trade-offs
- Pairwise analysis

### [Interactive Scatter](interactive-scatter.md)
Create customizable 2D scatter plots with advanced filtering.

**Key Features:**
- Custom axis selection
- Color and marker styling
- Set filtering
- Interactive point selection
- Detailed solution inspection

**Best For:**
- Focused 2D analysis
- Custom visualizations
- Solution selection
- Detailed exploration

### [Optimization History](optimization-history.md)
Track the evolution of variables, objectives, and constraints over time.

**Key Features:**
- Time series plots
- Convergence analysis
- Constraint evolution
- Performance for large datasets (resampler)

**Best For:**
- Convergence analysis
- Understanding optimization dynamics
- Constraint handling assessment
- Algorithm behavior analysis

## Utility Pages

### Settings
Configure application preferences including theme and language.

### Logs
View application logs for debugging and monitoring.

### Storage Viewer
Inspect the internal storage structure (advanced users).

## Page Selection Guide

### I want to...

**Load my data**
→ [Data Manager](data-manager.md)

**Browse my solutions**
→ [Data Viewer](data-viewer.md)

**Create groups of solutions**
→ [Sets Manager](sets-manager.md)

**See trade-offs between objectives**
→ [Parallel Coordinates](parallel-coordinates.md) or [Interactive Scatter](interactive-scatter.md)

**Understand variable relationships**
→ [Scatterplot Matrix](scatterplot-matrix.md)

**Analyze optimization progress**
→ [Optimization History](optimization-history.md)

**Find Pareto-optimal solutions**
→ [Sets Manager](sets-manager.md) (create default sets) then any visualization page

**Compare multiple results**
→ [Interactive Scatter](interactive-scatter.md) or [Scatterplot Matrix](scatterplot-matrix.md)

**Filter to specific solutions**
→ [Parallel Coordinates](parallel-coordinates.md) (brushing) or [Interactive Scatter](interactive-scatter.md) (set filtering)

## Typical Workflows

### Workflow 1: Initial Data Exploration

1. **[Data Manager](data-manager.md)**: Load your optimization results
2. **[Data Viewer](data-viewer.md)**: Browse the data
3. **[Sets Manager](sets-manager.md)**: Create default sets (Pareto, feasible)
4. **[Parallel Coordinates](parallel-coordinates.md)**: Explore multi-dimensional patterns
5. **[Interactive Scatter](interactive-scatter.md)**: Dive into specific relationships

### Workflow 2: Solution Selection

1. **[Data Manager](data-manager.md)**: Load results
2. **[Sets Manager](sets-manager.md)**: Create Pareto and feasible sets
3. **[Interactive Scatter](interactive-scatter.md)**: Filter by sets and select solutions
4. **[Data Viewer](data-viewer.md)**: Examine selected solutions in detail
5. **[Sets Manager](sets-manager.md)**: Create a new set from selected solutions

### Workflow 3: Optimization Analysis

1. **[Data Manager](data-manager.md)**: Load results
2. **[Optimization History](optimization-history.md)**: Check convergence
3. **[Sets Manager](sets-manager.md)**: Create sets based on findings
4. **[Parallel Coordinates](parallel-coordinates.md)**: Explore final solutions
5. **[Scatterplot Matrix](scatterplot-matrix.md)**: Understand relationships

### Workflow 4: Multi-Result Comparison

1. **[Data Manager](data-manager.md)**: Load multiple results
2. **[Interactive Scatter](interactive-scatter.md)**: Compare results visually
3. **[Scatterplot Matrix](scatterplot-matrix.md)**: Compare variable distributions
4. **[Data Viewer](data-viewer.md)**: Compare specific solutions

## Tips for Effective Use

### Start Simple
- Begin with Data Manager to load your data
- Use Data Viewer to get familiar with your results
- Create default sets before diving into visualizations

### Use Sets Effectively
- Create sets early in your analysis
- Use sets to filter visualizations
- Build sets iteratively as you learn more

### Combine Pages
- Use multiple pages for comprehensive analysis
- Validate findings across different views
- Build understanding progressively

### Leverage Interactivity
- Use brushing in Parallel Coordinates
- Select points in Interactive Scatter
- Filter and sort in Data Viewer
- Zoom and pan in all plots

## Next Steps

- Explore individual page documentation for detailed instructions
- Try the typical workflows with your data
- Experiment with different visualization combinations
- Create custom sets for your specific analysis needs
