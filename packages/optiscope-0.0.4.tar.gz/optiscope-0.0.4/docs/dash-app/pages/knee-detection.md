# Knee Detection Page

This page documents the **Knee Point Detection** analysis view in the OptiScope Dash application.

## Overview
The Knee Detection page helps users identify the **knee points** on a Pareto front – the solutions that represent the best trade‑off between competing objectives. Multiple detection methods are available:

- **Angle** – based on sharp turns in the front.
- **Distance** – farthest from the line connecting extremes.
- **Trade‑off** – changes in the trade‑off ratio.
- **Curvature** – high curvature regions.

## Features
- Select an optimization result to analyze.
- Choose a detection method from a dropdown.
- Visualize the first two objectives with knee points highlighted in red stars.
- Supports dark/light themes and responsive layout.

## Usage
1. Open the **Knee Detection** page from the navigation menu.
2. Choose a result using the **Result Selector**.
3. Pick a detection method from the dropdown.
4. The scatter plot updates, highlighting the detected knee points.

## Implementation Details
- Implemented in `optiscope/dash_app/pages/knee_detection/page.py`.
- Uses `optiscope.analysis.knee_detection.detect_knee_points` for the core algorithm.
- Follows the same layout conventions as other analysis pages.

## Future Enhancements
- Add a **region view** to display a broader knee region.
- Provide a **download** option for the identified knee points.
