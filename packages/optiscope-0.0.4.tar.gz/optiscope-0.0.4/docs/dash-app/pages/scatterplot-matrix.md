# Scatterplot Matrix

The Scatterplot Matrix page displays pairwise scatter plots of variables and objectives, making it easy to identify correlations and relationships in your optimization data.

## Overview

A scatterplot matrix (SPLOM) shows:
- All pairwise combinations of selected variables
- Scatter plots in a grid layout
- Correlations and relationships at a glance
- Separate matrices for variables and objectives

## Features

### Result Selection

**Select Result**: Choose which optimization result to visualize
- Currently supports single result selection
- Both matrices update when you change the selection

### Variable Selection

**Select Variables**: Choose which design variables to include
- **Default**: First 3 variables are selected
- **Recommendation**: Select 2-6 variables for best readability
- **Purpose**: Understand relationships between input parameters

### Objective Selection

**Select Objectives**: Choose which objectives to include
- **Default**: First 3 objectives are selected
- **Recommendation**: Select 2-6 objectives for clarity
- **Purpose**: Explore trade-offs between optimization goals

## Understanding the Plots

### Matrix Layout

Each matrix is organized as a grid:
- **Rows**: Represent one variable/objective
- **Columns**: Represent another variable/objective
- **Cell**: Scatter plot of row variable vs column variable

### Reading a Cell

- **X-axis**: Column variable
- **Y-axis**: Row variable
- **Points**: Individual solutions
- **Color**: Result name (when comparing multiple results)

### Diagonal

The diagonal cells (where row = column) are hidden since they would show a variable plotted against itself.

## Interpretation

### Correlation Patterns

**Positive Correlation**:
- Points form an upward-sloping line
- As one variable increases, the other increases
- Example: Larger size → higher cost

**Negative Correlation**:
- Points form a downward-sloping line
- As one variable increases, the other decreases
- Example: Higher efficiency → lower emissions

**No Correlation**:
- Points are scattered randomly
- Variables are independent
- No clear relationship

**Non-Linear Relationships**:
- Points form curves or clusters
- Complex dependencies
- May indicate constraints or physical limits

### Pareto Front in Objectives

For multi-objective optimization:
- Look for the "edge" of the point cloud
- This represents the Pareto front
- Shows trade-offs between objectives

## Usage Workflows

### Workflow 1: Variable Relationships

1. Select design variables of interest
2. Examine the variables matrix
3. Identify correlated parameters
4. Look for constraints or boundaries
5. Understand design space structure

### Workflow 2: Objective Trade-offs

1. Select all objectives
2. Examine the objectives matrix
3. Identify conflicting objectives (negative correlation)
4. Find synergistic objectives (positive correlation)
5. Understand multi-objective landscape

### Workflow 3: Variable-Objective Links

1. Select key variables and objectives
2. Look at cross-plots (variables vs objectives)
3. Identify which variables most affect each objective
4. Find sensitive parameters
5. Guide design decisions

### Workflow 4: Constraint Identification

1. Include constraint values as "observables"
2. Plot constraints against variables
3. Identify constraint boundaries
4. Understand feasible region shape

## Best Practices

### Selection Strategy

**Start Small**:
- Begin with 2-3 variables/objectives
- Add more as needed
- Too many creates visual clutter

**Choose Wisely**:
- Select most important or interesting variables
- Include conflicting objectives
- Add variables you suspect are related

**Balance**:
- 3-5 variables: Ideal for detailed analysis
- 6-8 variables: Still readable but dense
- \>8 variables: Consider splitting into multiple views

### Analysis Approach

**Systematic Scan**:
1. Scan each row left to right
2. Look for patterns in each column
3. Note strong correlations
4. Identify outliers

**Targeted Investigation**:
1. Focus on specific variable pairs
2. Zoom in on interesting regions
3. Compare with domain knowledge
4. Validate hypotheses

### Color Usage

When comparing multiple results:
- Different colors distinguish results
- Look for separation or overlap
- Identify result-specific patterns

## Common Patterns

### Design Variables

**Clustered Points**:
- Limited exploration of design space
- Optimizer converged to specific region
- May indicate local optimum

**Uniform Distribution**:
- Good design space coverage
- Effective exploration
- Diverse solutions

**Linear Relationships**:
- Variables are coupled
- May indicate redundancy
- Consider reducing dimensionality

### Objectives

**Pareto Front**:
- Points along an edge or curve
- Clear trade-off boundary
- Well-defined optimization problem

**Dominated Region**:
- Points away from the front
- Suboptimal solutions
- May indicate infeasible solutions

**Knee Points**:
- Sharp bends in the front
- Best compromise solutions
- High value for decision making

## Tips and Tricks

### Visualization

**Zoom and Pan**:
- Use Plotly's built-in zoom tools
- Focus on interesting regions
- Reset view with double-click

**Hover Information**:
- Hover over points for exact values
- Identify specific solutions
- Note solution indices

**Export**:
- Download plots for reports
- Save as PNG or SVG
- Include in presentations

### Analysis

**Compare Matrices**:
- Look for similar patterns in both matrices
- Identify variable-objective relationships
- Understand system behavior

**Outlier Investigation**:
- Identify points far from clusters
- Check if they're feasible
- Investigate why they're different

**Symmetry**:
- Matrix is symmetric (upper-right mirrors lower-left)
- Only need to examine one triangle
- Diagonal is omitted

## Advanced Usage

### Combining with Sets

1. Create sets in Sets Manager (e.g., Pareto, feasible)
2. View different sets separately
3. Compare patterns across sets
4. Identify set-specific characteristics

### Multi-Result Comparison

1. Load multiple results
2. Select all for comparison
3. Look for differences in patterns
4. Validate optimization consistency

### Sensitivity Analysis

1. Plot variables against objectives
2. Identify steep slopes (high sensitivity)
3. Find flat regions (low sensitivity)
4. Prioritize important variables

## Troubleshooting

### Too Many Points

- Use sets to filter solutions
- Select fewer variables/objectives
- Focus on Pareto front or feasible solutions

### Can't See Patterns

- Adjust number of selected variables
- Try different variable combinations
- Check axis scales

### Plots Not Updating

- Ensure a result is selected
- Check that variables/objectives are selected
- Refresh the page if needed

## Navigation

- **Path**: `/scatterplot-matrix`
- **Category**: Visualization
- **Icon**: Scatter plot icon
- **Requires Data**: Yes

## Related Pages

- **[Interactive Scatter](interactive-scatter.md)**: Detailed 2D scatter plots
- **[Parallel Coordinates](parallel-coordinates.md)**: Multi-dimensional visualization
- **[Data Viewer](data-viewer.md)**: Tabular data exploration
