# TOPSIS Analysis Page

This page documents the **TOPSIS** analysis view in the OptiScope Dash application.

## Overview
The TOPSIS page allows users to rank optimization solutions using the **Technique for Order Preference by Similarity to Ideal Solution**. Users can:

- Select an optimization result.
- Adjust the weight for each objective dynamically.
- Visualize the TOPSIS scores as an interactive bar chart.

## Features
- **Dynamic weight inputs** generated based on the number of objectives.
- **Real‑time score updates** when weights are changed.
- **Responsive design** with dark/light theme support.
- **Exportable plot** via Plotly's built‑in download options.

## Usage
1. Open the **TOPSIS** page from the navigation menu.
2. Choose a result using the **Result Selector**.
3. Adjust the weights for each objective in the generated number inputs.
4. The bar chart updates automatically to reflect the new ranking.

## Implementation Details
- The page is implemented in `optiscope/dash_app/pages/topsis/page.py`.
- It uses `optiscope.analysis.topsis.topsis` for the core ranking algorithm.
- The layout follows the standard pattern used by other analysis pages (e.g., Parallel Coordinates, Scatterplot Matrix).

## Future Enhancements
- Add a **sensitivity analysis** view to explore how weight variations affect rankings.
- Include a **download CSV** button for exporting the scores.
