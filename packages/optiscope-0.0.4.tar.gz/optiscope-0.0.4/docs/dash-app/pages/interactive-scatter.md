# Interactive Scatter

The Interactive Scatter page provides a highly customizable 2D scatter plot for exploring relationships between any two variables in your optimization data, with advanced filtering and interactive selection capabilities.

## Overview

This page allows you to:
- Create custom 2D scatter plots
- Select any variables for X and Y axes
- Filter by sets
- Color and style points by different attributes
- Select points interactively
- View detailed information about selected solutions

## Features

### Result Selection

**Select Results to Compare**: Choose one or more optimization results
- **Multi-select**: Compare multiple results simultaneously
- **Color coding**: Different results shown in different colors
- **Combined view**: All results plotted together

### Axis Selection

**X-Axis**: Choose the variable for the horizontal axis
**Y-Axis**: Choose the variable for the vertical axis

**Available Variables:**
- Design variables
- Objectives
- Constraints
- Observables
- Any computed or measured value

**Tips:**
- Plot objectives against each other to see trade-offs
- Plot variables against objectives to understand sensitivity
- Plot constraints to identify feasibility boundaries

### Color Coding

**Color By**: Choose how to color the points

**Options:**
- **Set**: Color by set membership (e.g., Pareto, feasible)
- **Any Variable**: Color by the value of any variable/objective
- **Result**: Color by which result the point belongs to

**Use Cases:**
- Highlight Pareto-optimal solutions
- Show feasibility status
- Visualize a third dimension
- Distinguish between results

### Marker Styling

**Marker By**: Choose how to style the point markers

**Options:**
- **Set**: Different markers for different sets
- **Any Variable**: Marker size based on variable value
- **Result**: Different markers for different results

**Benefits:**
- Add a fourth dimension to the plot
- Distinguish overlapping points
- Emphasize important solutions

### Set Filtering

**Filter by Set**: Show only points belonging to specific sets

**Workflow:**
1. Create sets in Sets Manager
2. Select sets to display
3. Plot updates to show only those points

**Use Cases:**
- Focus on Pareto front
- Show only feasible solutions
- Compare different solution subsets
- Isolate solutions of interest

## Interactive Features

### Point Selection

**Select Points**: Click and drag to select points
- **Box Select**: Drag to create a selection box
- **Lasso Select**: Draw a freeform selection
- **Click**: Select individual points

**Selected Point Information:**
- Annotations show point indices
- Details appear in side panels
- Can be used for further analysis

### Detail Panels

When you select points, three bar charts appear showing:

**Design Variables**:
- Values of all design variables for selected points
- Compare variable values across selections
- Identify variable patterns

**Objectives**:
- Objective values for selected points
- Compare solution quality
- See trade-offs

**Observables**:
- Observable values for selected points
- Additional metrics and computed values
- Extended analysis

**Chart Types:**
- **Bar charts**: For small selections (\<200 bars)
- **Lollipop charts**: For larger selections
  - Vertical style: Side-by-side comparison
  - Connected style: Trend visualization

## Usage Workflows

### Workflow 1: Objective Trade-off Analysis

1. Select X-axis: First objective
2. Select Y-axis: Second objective
3. Color by: "pareto" set
4. Observe the Pareto front
5. Select points to examine details

### Workflow 2: Variable Sensitivity

1. Select X-axis: Design variable
2. Select Y-axis: Objective
3. Color by: Another objective
4. Identify sensitive regions
5. Understand variable impact

### Workflow 3: Feasibility Exploration

1. Select X and Y axes of interest
2. Color by: "feasible" set
3. Marker by: Constraint value
4. Identify feasible region boundaries
5. Understand constraint impact

### Workflow 4: Multi-Result Comparison

1. Select multiple results
2. Choose relevant axes
3. Color by: Result
4. Compare solution distributions
5. Identify differences and similarities

### Workflow 5: Solution Selection

1. Plot relevant variables/objectives
2. Filter by important sets
3. Use lasso select to choose solutions
4. Examine details in bar charts
5. Note indices for set creation

## Best Practices

### Axis Selection

**Meaningful Combinations**:
- Conflicting objectives: See trade-offs
- Variable vs objective: Understand sensitivity
- Constraint vs variable: Find boundaries

**Scale Considerations**:
- Variables with similar ranges plot better
- Large scale differences may hide patterns
- Consider normalizing if needed

### Color Strategy

**Highlight What Matters**:
- Use color for the most important distinction
- Color by sets to show categories
- Color by values to show gradients
- Keep color schemes consistent

### Marker Usage

**Add Dimensions**:
- Use markers when color is already used
- Size markers by importance
- Different shapes for different categories
- Don't overuse—can create clutter

### Set Filtering

**Progressive Filtering**:
1. Start with all data
2. Filter to feasible solutions
3. Further filter to Pareto front
4. Finally filter to specific criteria

## Interpretation

### Scatter Plot Patterns

**Positive Correlation**:
- Points trend upward from left to right
- Variables increase together

**Negative Correlation**:
- Points trend downward from left to right
- Trade-off between variables

**Clusters**:
- Groups of nearby points
- Similar solution families
- Distinct design regions

**Outliers**:
- Points far from the main group
- Unusual solutions
- Potential errors or interesting cases

**Pareto Front**:
- Edge of the point cloud (for objectives)
- Non-dominated solutions
- Optimal trade-off curve

### Color Patterns

**Distinct Regions**:
- Different colors in different areas
- Set membership correlates with position
- Clear categorization

**Gradients**:
- Smooth color transitions
- Continuous variable relationships
- Trends across the space

**Mixed Colors**:
- Sets overlap in this projection
- Need additional dimensions to separate
- Consider different axes

## Tips and Tricks

### Visualization

**Zoom and Pan**:
- Use Plotly controls to zoom
- Pan to explore different regions
- Double-click to reset view

**Hover Information**:
- Hover over points for details
- See exact values
- Identify specific solutions

**Export**:
- Download plots for reports
- Save as PNG or SVG
- Include in presentations

### Analysis

**Multiple Views**:
- Create different plots for different aspects
- Compare patterns across views
- Build comprehensive understanding

**Iterative Exploration**:
- Start broad, then narrow down
- Use filters progressively
- Refine based on findings

**Combine with Other Pages**:
- Use Data Viewer to find indices
- Create sets based on selections
- Validate with Parallel Coordinates

## Advanced Features

### Lollipop Charts

For large selections (\>200 bars), the detail panels switch to lollipop charts:

**Vertical Style**:
- Side-by-side sticks for each variable
- Easy comparison across points
- Clear value visualization

**Connected Style**:
- Lines connecting values across variables
- Shows trends
- Identifies patterns

### Custom Data Exploration

1. **Hypothesis Testing**: Plot to test specific hypotheses
2. **Pattern Discovery**: Explore to find unexpected patterns
3. **Validation**: Confirm findings from other analyses
4. **Communication**: Create plots for presentations

## Troubleshooting

### Too Many Points

- Filter by sets to reduce density
- Use smaller marker sizes
- Apply transparency (if available)

### Can't See Patterns

- Try different axis combinations
- Adjust color schemes
- Use different marker styles

### Selection Not Working

- Ensure you're using the correct selection tool
- Check that points are visible
- Try refreshing the page

### Bar Charts Not Showing

- Ensure points are selected
- Check that the result has the required data
- Verify selection includes valid points

## Navigation

- **Path**: `/interactive_scatter`
- **Category**: Visualization
- **Icon**: Chart multiple icon
- **Requires Data**: Yes

## Related Pages

- **[Parallel Coordinates](parallel-coordinates.md)**: Multi-dimensional visualization
- **[Scatterplot Matrix](scatterplot-matrix.md)**: All pairwise plots
- **[Sets Manager](sets-manager.md)**: Create sets from selections
- **[Data Viewer](data-viewer.md)**: Detailed tabular view
