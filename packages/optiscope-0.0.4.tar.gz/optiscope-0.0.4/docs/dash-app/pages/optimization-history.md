# Optimization History

The Optimization History page visualizes the evolution of variables, objectives, constraints, and observables throughout the optimization process, showing how solutions improved over iterations.

## Overview

This page displays time series plots showing:
- How design variables changed during optimization
- Evolution of objective values
- Constraint satisfaction over time
- Observable values throughout the process

**Key Use**: Understand optimization dynamics and convergence behavior

## Features

### Result Selection

**Select Result**: Choose which optimization result to visualize
- Currently supports single result selection
- All plots update when you change the selection

**Note**: This page requires results with iteration/time information

### Variable Selection

Select which variables to display in each category:

**Design Variables**:
- Input parameters that were optimized
- Shows how the optimizer explored the design space
- Default: First 3 variables selected

**Objectives**:
- Optimization goals being minimized/maximized
- Shows improvement over time
- Default: First 3 objectives selected

**Constraints**:
- Inequality and equality constraints
- Shows feasibility evolution
- Default: First 3 constraints selected

**Observables**:
- Additional computed or measured values
- Shows derived metrics over time
- Default: First 3 observables selected

## Plot Types

### Time Series Plots

**Standard Mode** (for \<10,000 iterations):
- Full resolution plots
- All data points visible
- Interactive hover and zoom

**Resampled Mode** (for \>10,000 iterations):
- Automatically activated for large datasets
- Maintains visual fidelity while improving performance
- Uses plotly-resampler for efficient rendering

### Constraint Plots

Special visualization for constraints:
- **Feasibility Shading**: Background shows feasible region
- **Threshold Lines**: Shows constraint limits (0 for inequality)
- **Violation Highlighting**: Clearly shows when constraints are violated

## Understanding the Plots

### Design Variables Plot

**What it Shows**:
- How each design variable changed over iterations
- Exploration patterns
- Convergence behavior

**Interpretation**:
- **Flat lines**: Variable converged early
- **Oscillations**: Active search in that dimension
- **Trends**: Directional improvement
- **Jumps**: Major design changes or restarts

### Objectives Plot

**What it Shows**:
- Objective values at each iteration
- Improvement trajectory
- Convergence to optimal values

**Interpretation**:
- **Downward trend** (minimization): Improvement
- **Upward trend** (maximization): Improvement
- **Plateaus**: Convergence or local optimum
- **Spikes**: Exploration or constraint violations

### Constraints Plot

**What it Shows**:
- Constraint values over time
- Feasibility status
- Constraint violations

**Interpretation**:
- **Values ≤ 0**: Feasible (for inequality constraints)
- **Values \> 0**: Constraint violation
- **Approaching 0**: Active constraint
- **Far from 0**: Inactive constraint

**Visual Aids**:
- Green shading: Feasible region
- Red shading: Infeasible region
- Horizontal line at 0: Feasibility threshold

### Observables Plot

**What it Shows**:
- Evolution of computed or measured values
- Derived metrics over time
- System behavior indicators

**Interpretation**:
- Depends on specific observable
- Look for trends and patterns
- Correlate with objectives and variables

## Usage Workflows

### Workflow 1: Convergence Analysis

1. Select your result
2. View objectives plot
3. Identify when objectives stopped improving
4. Check if optimization converged
5. Assess solution quality

**Look For**:
- Clear convergence to stable values
- Continued improvement vs plateau
- Oscillations indicating non-convergence

### Workflow 2: Constraint Handling

1. Select relevant constraints
2. View constraints plot
3. Identify when feasibility was achieved
4. Check for persistent violations
5. Understand constraint activity

**Look For**:
- Transition from infeasible to feasible
- Active constraints (values near 0)
- Constraint violations over time

### Workflow 3: Design Space Exploration

1. Select design variables
2. View variables plot
3. Observe exploration patterns
4. Identify important variables
5. Understand optimizer behavior

**Look For**:
- Variables that changed significantly
- Variables that converged early
- Exploration vs exploitation phases

### Workflow 4: Multi-Objective Dynamics

1. Select all objectives
2. View objectives plot
3. Observe trade-off evolution
4. Identify when Pareto front was reached
5. Understand objective conflicts

**Look For**:
- Competing objectives (one improves, another worsens)
- Synergistic objectives (both improve together)
- Pareto front approximation over time

## Best Practices

### Variable Selection

**Start with Objectives**:
- Always view objectives first
- Understand overall performance
- Identify optimization success

**Add Variables Selectively**:
- Focus on most important variables
- Too many lines create clutter
- Add variables based on findings

**Include Constraints**:
- Always check feasibility evolution
- Understand constraint impact
- Identify problematic constraints

### Analysis Approach

**Sequential Analysis**:
1. Objectives: Did it improve?
2. Constraints: Is it feasible?
3. Variables: How did it get there?
4. Observables: What else changed?

**Comparative Analysis**:
- Compare early vs late iterations
- Identify phases of optimization
- Understand algorithm behavior

### Interpretation

**Convergence Indicators**:
- Objectives plateau
- Variables stabilize
- Constraints satisfied
- Observables steady

**Problem Indicators**:
- Objectives not improving
- Persistent constraint violations
- Erratic variable behavior
- Unexpected patterns

## Common Patterns

### Successful Optimization

**Characteristics**:
- Objectives improve steadily
- Variables converge to stable values
- Constraints become satisfied
- Clear convergence point

**Example**:
- Initial exploration (high variation)
- Improvement phase (objectives decrease)
- Refinement phase (small adjustments)
- Convergence (stable values)

### Struggling Optimization

**Characteristics**:
- Objectives oscillate without improvement
- Variables jump around
- Constraints repeatedly violated
- No clear convergence

**Possible Causes**:
- Poor algorithm settings
- Difficult optimization landscape
- Conflicting objectives
- Tight constraints

### Multi-Phase Optimization

**Characteristics**:
- Distinct phases visible in plots
- Sudden changes in behavior
- Multiple convergence attempts

**Interpretation**:
- Algorithm restarts
- Phase transitions
- Adaptive strategies

## Advanced Features

### Plotly Resampler

For large datasets (\>10,000 iterations):

**Benefits**:
- Maintains visual quality
- Improves performance
- Enables smooth interaction

**Usage**:
- Automatically activated
- Transparent to user
- Zoom and pan work normally

### Interactive Features

**Zoom and Pan**:
- Click and drag to zoom
- Pan to explore different time ranges
- Double-click to reset

**Hover Information**:
- Hover over lines for exact values
- See iteration number
- Compare multiple variables

**Legend**:
- Click to show/hide variables
- Double-click to isolate one variable
- Useful for complex plots

## Tips and Tricks

### Visualization

**Focus on Key Periods**:
- Zoom to early iterations for exploration phase
- Zoom to late iterations for convergence
- Compare different time ranges

**Isolate Variables**:
- Use legend to hide/show specific variables
- Focus on one or two at a time
- Reduce visual clutter

**Export Plots**:
- Download for reports
- Include in presentations
- Document optimization behavior

### Analysis

**Identify Phases**:
- Look for distinct behavioral changes
- Mark important iterations
- Understand algorithm strategy

**Correlate Plots**:
- Compare variables with objectives
- Link constraint violations to objective changes
- Understand cause and effect

**Validate Convergence**:
- Check if values truly stabilized
- Look for continued small improvements
- Assess if more iterations needed

## Troubleshooting

### Plots Not Showing

- Ensure result has iteration data
- Check that variables are selected
- Verify result is properly loaded

### Too Many Lines

- Reduce number of selected variables
- Use legend to hide some lines
- Focus on most important variables

### Can't See Patterns

- Try zooming to specific time ranges
- Adjust number of visible variables
- Check axis scales

### Performance Issues

- Resampler should activate automatically for large datasets
- If slow, try reducing number of plots
- Close other browser tabs

## Navigation

- **Path**: `/optimization-history`
- **Category**: Visualization
- **Icon**: Chart line icon
- **Requires Data**: Yes (with iteration information)

## Related Pages

- **[Interactive Scatter](interactive-scatter.md)**: Explore variable relationships
- **[Parallel Coordinates](parallel-coordinates.md)**: Multi-dimensional view
- **[Data Viewer](data-viewer.md)**: Examine specific iterations
