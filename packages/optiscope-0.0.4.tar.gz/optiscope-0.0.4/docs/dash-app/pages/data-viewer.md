# Data Viewer

The Data Viewer provides a tabular interface for browsing and exploring your optimization results. It allows you to view all variables, objectives, constraints, and observables in a sortable, filterable table.

## Overview

The Data Viewer displays optimization results in a comprehensive table format, making it easy to:
- Browse all data points in your optimization results
- Sort by any column
- Filter data based on specific criteria
- Select rows for further analysis
- Examine individual solution details

## Features

### Result Selection

**Select Result**: Choose which optimization result to view from the dropdown
- Only one result can be viewed at a time
- The table updates automatically when you change the selection

### Data Table

The main data table displays all available information for each solution:

**Columns Include:**
- **Design Variables**: Input parameters that were optimized
- **Objectives**: Optimization objectives (values to minimize/maximize)
- **Constraints**: Inequality and equality constraints
- **Observables**: Additional computed or measured values
- **Set Membership**: Which sets each point belongs to (if applicable)

**Table Features:**
- **Sortable**: Click column headers to sort ascending/descending
- **Filterable**: Use the filter row to narrow down results
- **Selectable**: Click rows to select them for analysis
- **Pagination**: Navigate through large datasets efficiently
- **Responsive**: Adapts to different screen sizes

### Row Selection

You can select individual rows or multiple rows:
- **Single Click**: Select/deselect a row
- **Shift+Click**: Select a range of rows
- **Ctrl/Cmd+Click**: Add/remove individual rows from selection

Selected rows can be used to:
- Create new sets (via Sets Manager)
- Analyze specific solutions
- Export subsets of data

### Set Filtering

If your result contains sets, you can filter the table to show only points belonging to specific sets:
- View points in the Pareto front
- Show only feasible solutions
- Display custom sets you've created

## Usage Workflow

### Basic Viewing

1. **Select a Result**: Choose an optimization result from the dropdown
2. **Browse Data**: Scroll through the table to explore solutions
3. **Sort**: Click column headers to sort by specific values
4. **Filter**: Use the filter inputs to narrow down results

### Advanced Filtering

1. **Column Filters**: Type in the filter row below headers
   - Numeric columns: Use operators like `>`, `<`, `=`
   - Text columns: Type partial matches
   - Example: `>0.5` in an objective column

2. **Set Filters**: Select specific sets to display
   - Shows only points belonging to selected sets
   - Useful for focusing on Pareto-optimal or feasible solutions

### Data Analysis

1. **Select Rows**: Click rows to select solutions of interest
2. **Examine Details**: Review all variables and objectives for selected points
3. **Create Sets**: Use selected rows to create new sets (via Sets Manager)
4. **Compare**: Sort and filter to compare different solutions

## Tips and Best Practices

### Performance
- For very large datasets (\>10,000 points), use filtering to reduce visible rows
- Pagination helps manage display of large result sets
- Consider creating sets for frequently accessed subsets

### Data Exploration
- Start by sorting objectives to find best solutions
- Use constraint columns to identify feasible solutions
- Filter by variable ranges to explore specific design spaces
- Combine multiple filters for targeted analysis

### Set Integration
- Create sets from selected rows for reuse in other pages
- Use existing sets to quickly filter to important solutions
- Combine Data Viewer with Sets Manager for powerful workflows

## Column Types

### Design Variables
- Input parameters that were varied during optimization
- Typically represent design choices or control parameters
- Values show the configuration for each solution

### Objectives
- Values that were optimized (minimized or maximized)
- Lower/higher values indicate better solutions (depending on optimization direction)
- Use for identifying optimal solutions

### Constraints
- **Inequality Constraints**: Must be ≤ 0 for feasibility
- **Equality Constraints**: Must be = 0 for feasibility
- Positive values indicate constraint violations

### Observables
- Additional computed or measured values
- Not directly optimized but useful for analysis
- May include derived metrics or intermediate calculations

## Navigation

- **Path**: `/data_viewer`
- **Category**: Data
- **Icon**: Table eye icon
- **Requires Data**: Yes

## Related Pages

- **[Sets Manager](sets-manager.md)**: Create sets from selected rows
- **[Data Manager](data-manager.md)**: Load and manage optimization results
- **[Interactive Scatter](interactive-scatter.md)**: Visualize data points graphically
