# Result Statistics

The Result Statistics page provides a comprehensive summary and statistical overview of a selected optimization result. It is designed to give users quick insights into the dataset's composition, problem dimensions, and metadata.

## Overview

This page displays high-level metrics and detailed metadata for:
- Optimization solutions (count, feasibility)
- Design variables (dimensionality, types)
- Objectives (number, directions)
- Constraints (number, violations)
- Observables (additional metrics)

**Key Use**: Quick assessment of optimization run characteristics and data quality.

## Features

### Result Selection

**Select Result**: Choose which optimization result to analyze.
- Supports single result selection.
- Dashboard updates automatically upon selection.

### Summary Dashboard

The dashboard is organized into cards providing key statistics:

**General Information**:
- **Total Solutions**: Total number of solutions in the result set.
- **Feasible Solutions**: Number (and percentage) of solutions satisfying all constraints.
- **Infeasible Solutions**: Number (and percentage) of solutions violating at least one constraint.

**Variables**:
- **Count**: Number of design variables.
- **Types**: Breakdown of variable types (e.g., continuous, integer, categorical).

**Objectives**:
- **Count**: Number of optimization objectives.
- **Directions**: Summary of minimization vs. maximization objectives.

**Constraints**:
- **Count**: Number of constraints.
- **Violations**: Overview of constraint satisfaction status.

**Observables**:
- **Count**: Number of tracked observables (if any).

### Metadata Viewer

A detailed view of the result's metadata, including:
- **Source**: Origin of the data (e.g., file path, database).
- **Date Created**: Timestamp of creation or import.
- **Description**: User-provided description or notes.
- **Other Metadata**: Any arbitrary metadata attached to the result set.

## Usage Workflows

### Workflow 1: Data Quality Check

1. Select a result.
2. Check **General Information** for the total and feasible solution counts.
3. Verify if the number of feasible solutions meets expectations.
4. Review **Constraints** statistics to understand feasibility issues.

### Workflow 2: Problem Dimension Analysis

1. Select a result.
2. Review **Variables** and **Objectives** cards.
3. Confirm the problem dimensions match the optimization formulation (e.g., correct number of decision variables and objectives).

### Workflow 3: Metadata Review

1. Select a result.
2. Expand the **Metadata** section (if applicable) to view details like source files, timestamps, and configuration notes.

## Navigation

- **Path**: `/result-statistics`
- **Category**: Visualization
- **Icon**: Chart/Statistics icon
- **Requires Data**: Yes

## Related Pages

- **[Data Viewer](data-viewer.md)**: Inspect raw tabular data.
- **[Optimization History](optimization-history.md)**: View evolution of metrics over time.
