# Sets Manager

The Sets Manager allows you to create, edit, and manage custom subsets of optimization solutions. Sets are powerful tools for organizing and analyzing specific groups of solutions.

## Overview

Sets are named collections of solution indices that allow you to:
- Group related solutions together
- Filter visualizations to specific solution subsets
- Organize analysis workflows
- Track important solutions across different views

## Features

### View Existing Sets

The main table displays all sets for the selected result:

**Columns:**
- **Checkbox**: Select sets for batch operations
- **Name**: Unique identifier for the set
- **Description**: Optional description of the set's purpose
- **Size**: Number of solutions in the set

### Create New Sets

**Manual Creation:**
1. Click **Add New Set**
2. Enter a name and description
3. Specify solution indices (comma-separated)
4. Click **Save**

**Example Indices:**
```
1, 5, 10, 15, 20
```

**Default Sets:**
Click **Create Default Sets** to automatically generate:
- **Feasible**: All solutions satisfying constraints
- **Non-Feasible**: Solutions violating one or more constraints
- **Pareto**: Pareto-optimal solutions
- **Optimal**: Best solutions (currently same as Pareto)
- **Smart Pareto**: Pareto front with epsilon-dominance filtering

### Edit Sets

1. **Select** a single set using the checkbox
2. Click **Edit Set**
3. Modify the name or description
4. Click **Save**

**Note:** You cannot edit the indices of an existing set. To change membership, create a new set.

### Delete Sets

1. **Select** one or more sets using checkboxes
2. Click **Delete Set**
3. Confirm the deletion

**Warning:** Deletion is permanent and cannot be undone.

## Default Sets Explained

### Feasible Set
Contains all solutions that satisfy all constraints:
- Inequality constraints ≤ 0
- Equality constraints = 0 (within tolerance)
- Essential for identifying viable solutions

### Non-Feasible Set
Contains solutions that violate at least one constraint:
- Useful for understanding constraint boundaries
- Can reveal trade-offs between objectives and constraints

### Pareto Set
Contains non-dominated solutions:
- No other solution is better in all objectives
- Represents the optimal trade-off frontier
- Key for multi-objective optimization analysis

### Optimal Set
Currently identical to the Pareto set:
- May be refined in future versions
- Represents the "best" solutions

### Smart Pareto Set
Pareto front with epsilon-dominance filtering:
- Reduces the number of solutions while maintaining diversity
- Epsilon value: 0.15 (15% tolerance)
- Useful for large Pareto fronts with many similar solutions

## Usage Workflows

### Workflow 1: Identify Best Solutions

1. Select your optimization result
2. Click **Create Default Sets**
3. View the **Pareto** set to see optimal trade-offs
4. Use **Smart Pareto** for a reduced, diverse set
5. Filter visualizations using these sets

### Workflow 2: Custom Analysis

1. Use Data Viewer to select interesting solutions
2. Note the indices of selected rows
3. Create a new set with those indices
4. Use the set in visualization pages

### Workflow 3: Constraint Analysis

1. Create default sets
2. Compare **Feasible** vs **Non-Feasible** sets
3. Analyze which constraints are most restrictive
4. Identify design space boundaries

### Workflow 4: Iterative Refinement

1. Start with Pareto set
2. Create subsets based on specific criteria
3. Analyze each subset separately
4. Refine sets based on findings

## Best Practices

### Naming Conventions
- Use descriptive names: `high_efficiency_solutions`, `low_cost_pareto`
- Include criteria in the name: `weight_under_100kg`
- Add version numbers for iterations: `pareto_v1`, `pareto_v2`

### Organization
- Create sets for different analysis perspectives
- Document set purposes in descriptions
- Delete unused sets to keep the workspace clean
- Use default sets as starting points

### Performance
- Smaller sets (\<1000 points) work best for interactive visualizations
- Use Smart Pareto for large Pareto fronts
- Create focused sets for specific analyses

## Set Usage in Other Pages

Sets created here can be used throughout the app:

### Data Viewer
- Filter table to show only set members
- Quickly access specific solution groups

### Visualization Pages
- **Parallel Coordinates**: Color by set membership
- **Interactive Scatter**: Filter to specific sets
- **Scatterplot Matrix**: Compare different sets

### Analysis
- Perform analysis on specific subsets
- Compare metrics across different sets
- Track solutions through different views

## Tips

### Finding Solution Indices
- Use Data Viewer to browse and note row numbers
- Indices are 0-based (first row is index 0)
- Selected rows in Data Viewer show their indices

### Set Operations
- Create complementary sets (e.g., feasible/non-feasible)
- Build hierarchical sets (e.g., pareto → smart_pareto → final_selection)
- Use sets to track analysis progression

### Validation
- Check set sizes after creation
- Verify indices are within valid range
- Use descriptions to document set criteria

## Troubleshooting

### Set Not Appearing
- Ensure you clicked **Save** after creating
- Check that the result is still loaded
- Refresh the page if needed

### Invalid Indices Error
- Verify indices are comma-separated numbers
- Ensure indices are within the result's range
- Check for typos or invalid characters

### Cannot Edit Set
- Only one set can be edited at a time
- Deselect other sets before editing
- To change indices, create a new set

## Navigation

- **Path**: `/sets_manager`
- **Category**: Data
- **Icon**: List group icon
- **Requires Data**: Yes

## Related Pages

- **[Data Viewer](data-viewer.md)**: Select rows to create sets
- **[Parallel Coordinates](parallel-coordinates.md)**: Visualize sets with color coding
- **[Interactive Scatter](interactive-scatter.md)**: Filter plots by sets
