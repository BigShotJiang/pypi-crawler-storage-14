# Home Page

The Home page serves as the landing page for the OptiScope Dash App, providing a quick overview and easy access to all available features.

## Overview

When you first launch the app or navigate to the root URL (`/`), you'll see the Home page. This page dynamically adapts based on whether you have loaded optimization results.

## Features

### Welcome Section

The welcome section displays:
- **Version Information**: Shows the current version of OptiScope
- **Quick Description**: Brief introduction to the platform
- **What's New**: Highlights of recent features and improvements

### Available Pages

The main section displays cards for all available pages, organized by category:

- **Data**: Pages for managing and viewing optimization data
- **Visualization**: Interactive plotting and visualization tools
- **Analysis**: Advanced analysis and filtering tools

### Smart Navigation

The Home page intelligently manages page access:

- **Data Manager**: Always accessible (you need this to load data)
- **Other Pages**: Disabled until you load at least one optimization result
- **Visual Feedback**: Grayed-out cards indicate pages that require data

## Usage

1. **First Time**: When you first open the app, only the Data Manager card is clickable
2. **After Loading Data**: Once you upload or connect to optimization results, all other pages become accessible
3. **Quick Access**: Click any enabled card to navigate directly to that page

## Tips

- Start by clicking the **Data Manager** card to upload your first optimization result
- The page automatically updates when you load or remove data
- Cards show a brief description of each page's functionality
- Use this page as a quick reference to navigate between different tools

## Navigation

- **Path**: `/`
- **Icon**: Home icon (🏠)
- **Always Accessible**: Yes
