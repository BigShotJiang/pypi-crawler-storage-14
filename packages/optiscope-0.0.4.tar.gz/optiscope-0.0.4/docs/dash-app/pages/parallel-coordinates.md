# Parallel Coordinates

The Parallel Coordinates page provides a powerful visualization for exploring high-dimensional optimization data. Each solution is represented as a line connecting values across multiple parallel axes.

## Overview

Parallel coordinates plots are ideal for:
- Visualizing many variables simultaneously
- Identifying patterns and correlations
- Interactive filtering through brushing
- Comparing multiple solutions
- Exploring trade-offs between objectives

## Features

### Result Selection

**Select Result**: Choose which optimization result to visualize
- Currently supports single result selection
- The plot updates automatically when you change the selection

### Column Selection

**Select Columns to Display**: Choose which variables to show as axes

**Available Column Types:**
- **Design Variables**: Input parameters
- **Objectives**: Optimization goals
- **Inequality Constraints**: Constraint values
- **Equality Constraints**: Constraint values
- **Observables**: Additional computed values

**Default**: The first 5 columns are selected automatically

**Tips:**
- Start with objectives to see solution quality
- Add key design variables to understand trade-offs
- Include constraints to identify feasibility boundaries
- Limit to 5-10 axes for best readability

### Color Coding

**Color By**: Choose how to color the lines

**Options:**
- **Result**: Color by result name (useful when comparing multiple results)
- **Any Column**: Color by the values of a specific variable/objective
- **Set Membership**: Color by which set solutions belong to

**Benefits:**
- Quickly identify patterns
- Highlight specific solution characteristics
- Distinguish between different groups

### Interactive Brushing

The most powerful feature of parallel coordinates is **brushing**:

1. **Click and drag** on any axis to select a range
2. **Multiple brushes**: Create ranges on multiple axes simultaneously
3. **Filtering**: Only lines passing through all brushes are highlighted
4. **Reset**: Click outside the brush to remove it

**Use Cases:**
- Find solutions within specific variable ranges
- Identify feasible solutions (constraint values ≤ 0)
- Explore trade-off regions
- Isolate interesting solution clusters

## Interpretation

### Reading the Plot

- **Each Line**: Represents one solution
- **Each Axis**: Represents one variable/objective
- **Line Position**: Shows the value on each axis
- **Line Color**: Indicates grouping or value (based on color selection)

### Patterns to Look For

**Parallel Lines**: 
- Strong correlation between adjacent axes
- Solutions with similar characteristics

**Crossing Lines**:
- Negative correlation
- Trade-offs between objectives

**Clusters**:
- Groups of similar solutions
- Distinct solution families

**Outliers**:
- Unusual or extreme solutions
- Potential errors or interesting edge cases

## Usage Workflows

### Workflow 1: Explore Pareto Front

1. Select your result
2. Choose all objectives as columns
3. Color by "pareto" set (if created)
4. Brush to explore different regions of the front
5. Identify trade-off patterns

### Workflow 2: Feasibility Analysis

1. Select objectives and constraints
2. Color by "feasible" set
3. Brush constraint axes at ≤ 0
4. See which objectives are achievable within constraints

### Workflow 3: Design Space Exploration

1. Select design variables and key objectives
2. Brush objectives to select good solutions
3. Observe which variable ranges produce good results
4. Identify promising design regions

### Workflow 4: Multi-Criteria Filtering

1. Select relevant columns
2. Brush multiple axes to define criteria
3. Narrow down to solutions meeting all criteria
4. Export or create a set from filtered solutions

## Best Practices

### Column Selection
- **Start Simple**: Begin with 3-5 most important columns
- **Add Gradually**: Add more columns as needed
- **Group Related**: Place related variables adjacent
- **Objectives First**: Start with objectives to see solution quality

### Axis Ordering
- Place correlated variables next to each other
- Put objectives at one end for easy comparison
- Group constraints together
- Experiment with different orderings

### Color Strategy
- Use color to highlight what matters most
- Color by objectives to see solution quality distribution
- Color by sets to compare different groups
- Color by constraints to identify feasibility

### Brushing Techniques
- **Broad to Narrow**: Start with wide brushes, then refine
- **One at a Time**: Add brushes incrementally
- **Reset Often**: Clear brushes to see the full picture
- **Combine**: Use multiple brushes for complex filtering

## Tips and Tricks

### Performance
- Limit to \<5000 solutions for smooth interaction
- Use sets to pre-filter large datasets
- Reduce number of axes if plot is slow

### Visualization
- Adjust browser zoom for better visibility
- Use full-screen mode for complex plots
- Export plots for presentations

### Analysis
- Look for "bundles" of lines indicating solution clusters
- Identify axes where lines spread out (high variance)
- Find axes where lines converge (low variance)
- Use brushing to validate hypotheses

## Common Use Cases

### Multi-Objective Optimization
- Visualize Pareto front trade-offs
- Identify knee points (best compromises)
- Explore objective space structure

### Constraint Handling
- Identify active constraints
- Find constraint boundaries
- Understand feasible region shape

### Sensitivity Analysis
- See which variables affect objectives most
- Identify robust solution regions
- Understand parameter interactions

### Solution Selection
- Filter to solutions meeting specific criteria
- Compare different solution families
- Narrow down to final candidates

## Troubleshooting

### Plot is Cluttered
- Reduce number of solutions (use sets)
- Decrease number of axes
- Use brushing to focus on specific regions

### Can't See Patterns
- Try different color schemes
- Reorder axes
- Adjust axis scales (if available)

### Brushing Not Working
- Ensure you're clicking and dragging on an axis
- Check that lines are visible
- Try refreshing the page

## Navigation

- **Path**: `/parallel-coordinates`
- **Category**: Visualization
- **Icon**: Math norm icon
- **Requires Data**: Yes

## Related Pages

- **[Interactive Scatter](interactive-scatter.md)**: 2D visualization alternative
- **[Scatterplot Matrix](scatterplot-matrix.md)**: Pairwise relationships
- **[Sets Manager](sets-manager.md)**: Create sets from filtered solutions
