# Getting Started

Welcome to OptiScope! This section will guide you through installing the library, understanding its core concepts, and getting up and running quickly.

- [Installation](installation.md): Learn how to install OptiScope and its dependencies.
- [Quickstart](quickstart.md): A hands-on guide to your first analysis with OptiScope.
- [Core Concepts](core-concepts.md): Understand the fundamental building blocks of the library, including the Data Model and Result Sets.
