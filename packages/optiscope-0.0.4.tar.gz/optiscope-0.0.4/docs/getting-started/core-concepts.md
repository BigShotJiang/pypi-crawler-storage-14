# Core Concepts

Understanding the core concepts of OptiScope will help you effectively use the library and the dashboard.

## Data Model

At the heart of OptiScope is a robust data model designed to handle optimization results.

### OptimizationResult
The `OptimizationResult` class represents the result of a single optimization run or a collection of points from a run. It stores:
- **Design Variables**: The input parameters of the optimization problem.
- **Objectives**: The values to be minimized or maximized.
- **Constraints**: Equality and inequality constraints.
- **Metadata**: Additional information about the problem, solver, and run time.

### ResultSet
A `ResultSet` represents a **named subset of points** within an optimization result. It allows you to group and identify specific solutions based on their characteristics. Result sets are useful for:
- **Focusing Analysis**: Isolating specific regions of the design or objective space.
- **Tagging**: Marking interesting points (e.g., "Pareto Front", "Selected Designs").
- **Set Operations**: Performing unions, intersections, and differences between groups of points.

## Input/Output (I/O)

OptiScope uses a flexible I/O system to read and write optimization results.

- **Format Handlers**: Specialized classes that handle reading and writing specific file formats (e.g., CSV, JSON, MIDACo).
- **Registry**: A central registry that automatically detects the file format and selects the appropriate handler.

## Visualization

OptiScope provides a suite of visualization tools tailored for high-dimensional optimization data.

- **Parallel Coordinates**: Visualizes high-dimensional data by plotting points as lines across parallel axes.
- **Scatter Matrix**: Shows pairwise relationships between variables.
- **Pareto Viewer**: Specialized plots for analyzing trade-offs between objectives.

## Analysis Tools

Beyond visualization, OptiScope includes tools for quantitative analysis.

- **Pareto Dominance**: Identifying non-dominated solutions.
- **TOPSIS**: A multi-criteria decision analysis method for ranking solutions.
- **Knee Point Detection**: Finding points that offer the best trade-off between conflicting objectives.

## The Dash App

The Dash App is a web-based interface that brings all these components together. It allows you to:
- Interactively explore data.
- Compare different optimization runs.
- Perform analysis without writing code.
