# Installation

OptiScope requires Python 3.10 or later.

## Installing from PyPI

The easiest way to install OptiScope is via pip:

```bash
pip install optiscope
```

## Installing from Source

For the latest development version, you can install directly from the GitHub repository:

```bash
git clone https://github.com/simaosr/optiscope.git
cd optiscope
pip install -e .
```

## Optional Dependencies

OptiScope has optional dependencies for development and documentation:

- **Development**: Includes testing and linting tools.
  ```bash
  pip install optiscope[dev]
  ```

- **Documentation**: Includes tools for building the documentation.
  ```bash
  pip install optiscope[docs]
  ```

- **All**: Installs all optional dependencies.
  ```bash
  pip install optiscope[all]
  ```

## Verifying Installation

To verify that OptiScope is installed correctly, you can run the following command in your terminal:

```bash
python -c "import optiscope; print(optiscope.__version__)"
```

If the installation was successful, this command should print the installed version number.
