## prepare
pip install build
pip install twine

## Build
[//]: # (bumpver update --patch)
python -m build

## Upload
twine upload dist/*

https://pypi.org/project/mcp-server-pliakh/0.1.0/

## Test
pip install mcp-server-pliakh
uvx --from mcp-server-pliakh mcp-server.exe

# Alternative build to include dependencies

