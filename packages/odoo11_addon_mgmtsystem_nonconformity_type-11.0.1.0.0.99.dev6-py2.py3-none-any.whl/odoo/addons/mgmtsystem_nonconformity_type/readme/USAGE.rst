NC Type

* Go to Management System → Nonconformity
* Create new Nonconformity
* Select a Nonconformity Type: default is Internal

NC Partner Quality E-mail

* Go to Partner → Contacts & Addresses → create/select a contact of type Quality Address
* Go to Management System → Nonconformity
* Create a new Nonconformity
* Set Type as Partner
* Click «Send by Email»
