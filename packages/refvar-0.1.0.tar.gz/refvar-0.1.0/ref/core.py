class Ref:
    __slots__ = ("value",)

    def __init__(self, value=None):
        self.value = value

    def __call__(self, new_value):
        self.value = new_value
        return self

    def __str__(self):
        return str(self.value)

    def __repr__(self):
        return f"Ref({self.value!r})"

    def __eq__(self, other):
        return self.value == other

    def __bool__(self):
        return bool(self.value)
