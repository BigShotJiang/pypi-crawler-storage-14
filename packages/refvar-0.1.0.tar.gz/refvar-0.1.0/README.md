# ref

A minimal and elegant reactive variable for Python.

```python
from ref import Ref

count = Ref(0)

print(count)   # 0

count(10)

print(count)   # 10

if count == 10:
    print("Works!")
