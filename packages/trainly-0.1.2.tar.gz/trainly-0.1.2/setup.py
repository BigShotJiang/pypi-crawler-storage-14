"""
Setup file for trainly Python SDK.
Minimal setup.py for backwards compatibility.
All configuration is in pyproject.toml
"""

from setuptools import setup

# All configuration is in pyproject.toml
setup()

