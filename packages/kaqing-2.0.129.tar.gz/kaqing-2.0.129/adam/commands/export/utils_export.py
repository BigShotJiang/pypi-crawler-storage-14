from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime
import io
import os
import re
import sqlite3
import time
from typing import Callable
import boto3
import pandas

from adam.commands.cql.cql_utils import cassandra_table_names, run_cql, table_spec
from adam.config import Config
from adam.repl_state import ReplState
from adam.utils import elapsed_time, lines_to_tabular, log, log2
from adam.utils_athena import Athena
from adam.utils_k8s.cassandra_nodes import CassandraNodes
from adam.utils_k8s.pods import Pods
from adam.utils_sqlite import SQLite

def display_export_session(export_session: str):
    Athena.clear_cache()

    keyspaces = {}
    for table in ExportDatabases.table_names(export_session):
        keyspace = table.split('.')[0]
        if keyspace in keyspaces:
            keyspaces[keyspace] += 1
        else:
            keyspaces[keyspace] = 1

    log(lines_to_tabular([f'{k},{v}' for k, v in keyspaces.items()], header='SCHEMA,# of TABLES', separator=','))

class ExportDatabases:
    def database_names():
        return list({n.split('_')[0] for n in SQLite.database_names() + Athena.database_names(Exporter.LIKE)})

    def table_names(session: str):
        tables = []

        for session in ExportDatabases.session_database_names(session):
            if session.startswith('s'):
                for table in SQLite.table_names(database=session):
                    tables.append(f'{SQLite.keyspace(session)}.{table}')
            else:
                for table in Athena.table_names(database=session, function='export'):
                    tables.append(f'{session}.{table}')

        return tables

    def session_database_names(db: str):
        eprefix = db
        if '_' in db:
            eprefix = db.split('_')[0]

        if db.startswith('s'):
            return SQLite.database_names(prefix=f'{eprefix}_')
        else:
            return Athena.database_names(like=f'{eprefix}_%')

class ExportSpec:
    def __init__(self, keyspace: str, consistency: str, tables: list['ExportTableSpec']):
        self.keyspace = keyspace
        self.consistency = consistency
        self.tables = tables

    def parse_specs(specs_str: str):
        keyspace: str = None
        consistency: str = None
        specs: list[ExportTableSpec] = None

        if specs_str:
            keyspace, specs_str = ExportSpec._extract_keyspace(specs_str.strip(' '))
            consistency, specs = ExportSpec._extract_consisteny(specs_str)

        return ExportSpec(keyspace, consistency, specs)

    def _extract_keyspace(spec_str: str) -> tuple[str, str]:
        keyspace = None
        rest = spec_str

        p = re.compile(r"\s*\*\s+in\s+(\S+)(.*)", re.IGNORECASE)
        match = p.match(spec_str)
        if match:
            keyspace = match.group(1).strip(' ')
            rest = match.group(2).strip(' ')
        elif spec_str.startswith('*'):
            keyspace = '*'
            rest = spec_str[1:].strip(' ')

        return keyspace, rest

    def _extract_consisteny(spec_str: str) -> tuple[str, list['ExportTableSpec']]:
        consistency = None

        p = re.compile(r"(.*?)with\s+consistency\s+(.*)", re.IGNORECASE)
        match = p.match(spec_str)
        if match:
            spec_str = match.group(1).strip(' ')
            consistency = match.group(2)

        if spec_str:
            p = r",\s*(?![^()]*\))"
            specs = re.split(p, spec_str)

            return consistency, [ExportTableSpec.parse(spec) for spec in specs]

        return consistency, None

class ExportTableSpec:
    def __init__(self, keyspace: str, table: str, columns: str = None, target_table: str = None):
        self.keyspace = keyspace
        self.table = table
        self.columns = columns
        self.target_table = target_table

    def parse(spec_str: str) -> 'ExportTableSpec':
        target = None

        p = re.compile(r"(.*?)\s+as\s+(.*)", re.IGNORECASE)
        match = p.match(spec_str)
        if match:
            spec_str = match.group(1)
            target = match.group(2)

        table = spec_str
        columns = None

        p = re.compile('(.*?)\.(.*?)\((.*)\)')
        match = p.match(spec_str)
        if match:
            keyspace = match.group(1)
            table = match.group(2)
            columns = match.group(3)
        else:
            p = re.compile('(.*?)\.(.*)')
            match = p.match(spec_str)
            if match:
                keyspace = match.group(1)
                table = match.group(2)

        return ExportTableSpec(keyspace, table, columns, target)

    def __eq__(self, other):
        if isinstance(other, ExportTableSpec):
            return self.keyspace == other.keyspace and self.table == other.table and self.columns == other.columns and self.target_table == other.target_table

        return False

    def __str__(self):
        return f'{self.keyspace}.{self.table}({self.columns}) as {self.target_table}'

class Exporter:
    LIKE = 'e%_%'

    def copy_tables(args: list[str], state: ReplState, max_workers = 0):
        return Exporter.export_tables(args, state, max_workers, kind='copy')

    def export_tables(args: list[str], state: ReplState, max_workers = 0, kind = 'export'):
        spec: ExportSpec = ExportSpec.parse_specs(' '.join(args))

        if not spec.keyspace:
            spec.keyspace = f'{state.namespace}_db'

        if not spec.tables:
            spec.tables = [ExportTableSpec.parse(t) for t in cassandra_table_names(state, keyspace=spec.keyspace)]

        if not max_workers:
            max_workers = Config().action_workers(kind, 8)

        exporter = Exporter.export_table if kind == 'export' else Exporter.copy_table
        if max_workers > 1 and len(spec.tables) > 1:
            log2(f'Executing on {len(spec.tables)} Cassandra tables in parallel...')
            start_time = time.time()
            try:
                with ThreadPoolExecutor(max_workers=max_workers) as executor:
                    futures = [executor.submit(exporter, table, state, True, consistency=spec.consistency) for table in spec.tables]
                    if len(futures) == 0:
                        return []

                return [future.result() for future in as_completed(futures)]
            finally:
                log2(f"{len(spec.tables)} parallel table export elapsed time: {elapsed_time(start_time)} with {max_workers} workers")
        else:
            return [exporter(table, state, multi_tables=len(spec.tables) > 1, consistency=spec.consistency) for table in spec.tables]

    def export_table(spec: ExportTableSpec, state: ReplState, multi_tables = True, consistency: str = None):
        table, target_table, columns = Exporter.resove_table_n_columns(spec, state)

        temp_dir = Config().get('export.temp_dir', '/c3/cassandra/tmp')
        db = state.export_session
        create_db = not db
        if create_db:
            db = f'e{datetime.now().strftime("%Y%m%d%H%M%S")[3:]}_{spec.keyspace}'
            state.export_session = db
        else:
            db = f"{db.split('_')[0]}_{spec.keyspace}"

        CassandraNodes.exec(state.pod, state.namespace, f'mkdir -p {temp_dir}/{db}', show_out=not multi_tables, shell='bash')
        csv_file = f'{temp_dir}/{db}/{table}.csv'
        succeeded = False
        try:
            suppress_ing_log = Config().is_debug() or multi_tables
            queries = []
            if consistency:
                queries.append(f'CONSISTENCY {consistency}')
            queries.append(f"COPY {spec.keyspace}.{table}({columns}) TO '{csv_file}' WITH HEADER = TRUE")
            ing(f'Dumping table {spec.keyspace}.{table}{f" with consistency {consistency}" if consistency else ""}',
                lambda: run_cql(state, ';'.join(queries), show_out=Config().is_debug()),
                suppress_log=suppress_ing_log)

            def upload_to_s3():
                bytes = Pods.read_file(state.pod, 'cassandra', state.namespace, csv_file)

                s3 = boto3.client('s3')
                s3.upload_fileobj(GeneratorStream(bytes), 'c3.ops--qing', f'export/{db}/{spec.keyspace}/{target_table}/{table}.csv')

            ing(f'Uploading to S3', upload_to_s3, suppress_log=suppress_ing_log)

            def create_schema():
                query = f'CREATE DATABASE IF NOT EXISTS {db};'
                if Config().is_debug():
                    log2(query)
                Athena.query(query, 'default')

                query = f'DROP TABLE IF EXISTS {target_table};'
                if Config().is_debug():
                    log2(query)
                Athena.query(query, db)

                # columns = ', '.join([f'{h.strip(" ")} string' for h in header[0].split(',')])
                athena_columns = ', '.join([f'{c} string' for c in columns.split(',')])
                query = f'CREATE EXTERNAL TABLE IF NOT EXISTS {target_table}(\n' + \
                        f'    {athena_columns})\n' + \
                            "ROW FORMAT SERDE 'org.apache.hadoop.hive.serde2.OpenCSVSerde'\n" + \
                            'WITH SERDEPROPERTIES (\n' + \
                            '    "separatorChar" = ",",\n' + \
                            '    "quoteChar"     = "\\"")\n' + \
                        f"LOCATION 's3://c3.ops--qing/export/{db}/{spec.keyspace}/{target_table}'\n" + \
                            'TBLPROPERTIES ("skip.header.line.count"="1");'
                if Config().is_debug():
                    log2(query)
                try:
                    Athena.query(query, db)
                except Exception as e:
                    log2(f'*** Failed query:\n{query}')
                    raise e

            ing(f"Creating database {db}" if create_db else f"Creating table {target_table}", create_schema, suppress_log=suppress_ing_log)

            succeeded = True
        except Exception as e:
            log2(e)
        finally:
            ing('Cleaning up temporary files',
                lambda: CassandraNodes.exec(state.pod, state.namespace, f'rm -rf {csv_file}', show_out=False, shell='bash'),
                suppress_log=suppress_ing_log)

        if succeeded:
            Athena.clear_cache()

            if not suppress_ing_log:
                query = f'select * from {target_table} limit 10'
                log2(query)
                Athena.run_query(query, db)

        return table

    def copy_table(spec: ExportTableSpec, state: ReplState, multi_tables = True, consistency: str = None):
        table, target_table, columns = Exporter.resove_table_n_columns(spec, state, include_ks_in_target=False, kind='copy')

        if not state.export_session:
            state.export_session = f's{datetime.now().strftime("%Y%m%d%H%M%S")[3:]}'

        db = f'{state.export_session}_{spec.keyspace}'

        conn = None
        try:
            # TODO /tmp ok?
            os.makedirs(SQLite.local_db_dir(), exist_ok=True)
            conn = sqlite3.connect(f'{SQLite.local_db_dir()}/{db}.db')

            temp_dir = Config().get('copy.temp_dir', '/c3/cassandra/tmp')
            CassandraNodes.exec(state.pod, state.namespace, f'mkdir -p {temp_dir}/{db}', show_out=not multi_tables, shell='bash')
            csv_file = f'{temp_dir}/{db}/{table}.csv'
            succeeded = False
            try:
                suppress_ing_log = Config().is_debug() or multi_tables
                queries = []
                if consistency:
                    queries.append(f'CONSISTENCY {consistency}')
                queries.append(f"COPY {spec.keyspace}.{table}({columns}) TO '{csv_file}' WITH HEADER = TRUE")
                ing(f'Dumping table {spec.keyspace}.{table}{f" with consistency {consistency}" if consistency else ""}',
                    lambda: run_cql(state, ';'.join(queries), show_out=Config().is_debug()),
                    suppress_log=suppress_ing_log)

                def upload_to_sqlite():
                    bytes = Pods.read_file(state.pod, 'cassandra', state.namespace, csv_file)
                    df = pandas.read_csv(GeneratorStream(bytes))

                    df.to_sql(target_table, conn, index=False, if_exists='replace')

                ing(f'Uploading to Sqlite', upload_to_sqlite, suppress_log=suppress_ing_log)

                succeeded = True
            except Exception as e:
                log2(e)
            finally:
                ing('Cleaning up temporary files',
                    lambda: CassandraNodes.exec(state.pod, state.namespace, f'rm -rf {csv_file}', show_out=False, shell='bash'),
                    suppress_log=suppress_ing_log)
        finally:
            if succeeded:
                SQLite.clear_cache()

                if not suppress_ing_log:
                    query = f'select * from {target_table} limit 10'
                    log2(query)
                    SQLite.run_query(conn, query)

            if conn:
                conn.close()

        return table

    def resove_table_n_columns(spec: ExportTableSpec, state: ReplState, include_ks_in_target = False, kind = 'export'):
        table = spec.table
        columns = spec.columns
        if not columns:
            columns = Config().get(f'{kind}.columns', f'<keys>')

        keyspaced_table = f'{spec.keyspace}.{spec.table}'
        if columns == '<keys>':
            columns = ','.join(table_spec(state, keyspaced_table, on_any=True).keys())
        elif columns == '<row-key>':
            columns = table_spec(state, keyspaced_table, on_any=True).row_key()
        elif columns == '*':
            columns = ','.join([c.name for c in table_spec(state, keyspaced_table, on_any=True).columns])

        if not columns:
            log2(f'ERROR: Empty columns on {table}.')
            return table, None, None

        target_table = spec.target_table if spec.target_table else table
        if not include_ks_in_target and '.' in target_table:
            target_table = target_table.split('.')[-1]

        return table, target_table, columns

def ing(msg: str, body: Callable[[], None], suppress_log=False):
    if not suppress_log:
        log2(f'{msg}...', nl=False)
    body()
    if not suppress_log:
        log2(' OK')

class GeneratorStream(io.RawIOBase):
    def __init__(self, generator):
        self._generator = generator
        self._buffer = b''  # Buffer to store leftover bytes from generator yields

    def readable(self):
        return True

    def _read_from_generator(self):
        try:
            chunk = next(self._generator)
            if isinstance(chunk, str):
                chunk = chunk.encode('utf-8')  # Encode if generator yields strings
            self._buffer += chunk
        except StopIteration:
            pass  # Generator exhausted

    def readinto(self, b):
        # Fill the buffer if necessary
        while len(self._buffer) < len(b):
            old_buffer_len = len(self._buffer)
            self._read_from_generator()
            if len(self._buffer) == old_buffer_len:  # Generator exhausted and buffer empty
                break

        bytes_to_read = min(len(b), len(self._buffer))
        b[:bytes_to_read] = self._buffer[:bytes_to_read]
        self._buffer = self._buffer[bytes_to_read:]
        return bytes_to_read

    def read(self, size=-1):
        if size == -1:  # Read all remaining data
            while True:
                old_buffer_len = len(self._buffer)
                self._read_from_generator()
                if len(self._buffer) == old_buffer_len:
                    break
            data = self._buffer
            self._buffer = b''
            return data
        else:
            # Ensure enough data in buffer
            while len(self._buffer) < size:
                old_buffer_len = len(self._buffer)
                self._read_from_generator()
                if len(self._buffer) == old_buffer_len:
                    break

            data = self._buffer[:size]
            self._buffer = self._buffer[size:]
            return data