from adam.commands.command import Command
from adam.repl_state import ReplState

# No action body, only for a help entry and auto-completion
class RemoveExportDatabasesX(Command):
    COMMAND = 'rmdbs'

    # the singleton pattern
    def __new__(cls, *args, **kwargs):
        if not hasattr(cls, 'instance'): cls.instance = super(RemoveExportDatabasesX, cls).__new__(cls)

        return cls.instance

    def __init__(self, successor: Command=None):
        super().__init__(successor)

    def command(self):
        return RemoveExportDatabasesX.COMMAND

    def required(self):
        return ReplState.X

    def completion(self, state: ReplState):
        return super().completion(state)

    def help(self, _: ReplState):
        return f'{RemoveExportDatabasesX.COMMAND}\t remove all export databases'