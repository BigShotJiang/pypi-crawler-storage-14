"""Lambda handlers for the fleet management API."""
# pylint: disable=missing-module-docstring,missing-function-docstring,missing-class-docstring,too-many-return-statements
import os
import traceback
from decimal import Decimal
# pylint: disable=too-many-return-statements
import json
import boto3
# fleetmanag_lib.py is available in the deployment package
from fleetmanag_lib import Vehicle
from botocore.exceptions import ClientError

# --- Environment Variables ---
TABLE_NAME = os.environ.get("TABLE_NAME", "FleetTable")
IMAGE_BUCKET_NAME = os.environ.get("IMAGE_BUCKET_NAME")
ALERT_TOPIC_ARN = os.environ.get("ALERT_TOPIC_ARN")
MILEAGE_THRESHOLD = 15000

# --- AWS Clients ---
dynamodb = boto3.resource("dynamodb")
table = dynamodb.Table(TABLE_NAME)
sns_client = boto3.client("sns")
s3_client = boto3.client("s3")

# --- Response Helpers ---
CORS_HEADERS = {
    "Content-Type": "application/json",
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type,Authorization,X-Amz-Date,X-Api-Key,X-Amz-Security-Token",
    "Access-Control-Allow-Methods": "DELETE,GET,OPTIONS,POST,PUT",
    "Access-Control-Max-Age": "600"
}

def response(status_code: int, body: dict, list = None) -> dict:
    """ creating an API Gateway proxy response."""
    if body is not None:
        # jSON serialization
        response_body = json.dumps(body, cls=DecimalEncoder)
    else:
        response_body = ""

    return {
        "statusCode": status_code,
        "headers": CORS_HEADERS,
        "body": response_body
    }

class DecimalEncoder(json.JSONEncoder):
    """Helper to convert DynamoDB's Decimal type to float for JSON serialization."""
    def default(self, o):
        if isinstance(o, Decimal):
            return float(o)
        return super().default(o)

def cors_preflight_response() -> dict:
    """Handles the HTTP OPTIONS."""
    return {
        "statusCode": 200,
        "headers": CORS_HEADERS,
        "body": ""
    }


def add_vehicle_handler(event):
    """POST /vehicles: Adds a new vehicle and alerts if mileage is high."""
    try:
        body = json.loads(event.get("body") or "{}")
        vehicle_id = body.get("vehicle_id")
        make = body.get("make")
        model = body.get("model")

        try:
            # converted to Decimal
            mileage = Decimal(str(body.get("mileage", 0)))
        except Exception:
            return response(400, {"error": "Mileage must be a valid number."})

        image_filename = body.get("image_filename")

        if not vehicle_id or not make or not model:
            return response(400, {"error": "vehicle_id, make, and model are required"})

        # 1. Using the Custom OOP Library as per the brief
        vehicle = Vehicle(vehicle_id=vehicle_id, make=make, model=model, mileage=mileage)

        image_url = f"https://{IMAGE_BUCKET_NAME}.s3.amazonaws.com/{image_filename}" if image_filename else ""

        # 3. Write and save in DynamoDB
        item = vehicle.to_dict(image_url=image_url)
        table.put_item(Item=item)

        # 4. Publish to SNS
        if mileage > MILEAGE_THRESHOLD and ALERT_TOPIC_ARN: # Check against Decimal mileage
            message = f"HIGH MILEAGE ALERT: Vehicle {vehicle.vehicle_id} ({vehicle.make} {vehicle.model}) has reached {mileage} miles."
            sns_client.publish(
                TopicArn=ALERT_TOPIC_ARN,
                Subject=f"ALERT: High Mileage for {vehicle.vehicle_id}",
                Message=message
            )

        return response(201, {"message": "Vehicle added successfully",
        "vehicle_id": vehicle_id, "image_url": image_url})

    except json.JSONDecodeError:
        return response(400, {"error": "Invalid JSON body"})
    except Exception as e:
        #  Loging  the full stack debugging
        print(f"Error processing POST /vehicles: {e}")
        print(traceback.format_exc())
        return response(500, {"error": "Internal server error. Check CloudWatch logs."})

def get_vehicles_handler():
    """
    Handles GET /vehicles: Scans the DynamoDB table and returns all vehicles.Return all vehicles as a JSON array
    """
    try:
        result = table.scan()
        return response(200, result.get("Items", []))
    except Exception as e:
        print(f"Error retrieving vehicles: {e}")
        print(traceback.format_exc())
        return response(500, {"error": "Could not retrieve vehicles."})


def update_vehicle_handler(event):
    """
    PUT /vehicles/{vehicle_id}: Updates an existing vehicle's make, model, or mileage.
    """
    vehicle_id = event.get("pathParameters", {}).get("vehicle_id")

    if not vehicle_id:
        return response(400, {"error": "Missing vehicle_id path parameter."})

    try:
        update_data = json.loads(event.get("body") or "{}")

        if not update_data: # Check for empty body
             return response(400, {"error": "Request body cannot be empty."})

        expression_parts = []
        expression_attribute_names = {}
        expression_attribute_values = {}

        valid_attributes = ['make', 'model', 'mileage']

        for key, value in update_data.items():
            if key in valid_attributes:
                attr_name_alias = f"#{key}"
                attr_value_alias = f":{key}"

                expression_parts.append(f"{attr_name_alias} = {attr_value_alias}")
                expression_attribute_names[attr_name_alias] = key

                if key == 'mileage':
                    # Convert mileage to Decimal for consistent DynamoDB storage
                    expression_attribute_values[attr_value_alias] = Decimal(str(value))
                else:
                    expression_attribute_values[attr_value_alias] = value

        if not expression_parts:
            return response(400, {"error": "No valid fields provided for update (make, model, or mileage)."})

        update_expression = "SET " + ", ".join(expression_parts)

        #  ensure the item exists
        try:
            result = table.update_item(
                Key={'vehicle_id': vehicle_id},
                UpdateExpression=update_expression,
                ExpressionAttributeNames=expression_attribute_names,
                ExpressionAttributeValues=expression_attribute_values,
                ConditionExpression='attribute_exists(vehicle_id)', # Ensure the item exists
                ReturnValues="ALL_NEW" # Returns the updated item
            )
        except ClientError as e:
            if e.response['Error']['Code'] == 'ConditionalCheckFailedException':
                 return response(404, {"error": f"Vehicle ID '{vehicle_id}' not found."})
            raise e

        return response(200, {"message": f"Vehicle {vehicle_id} updated successfully.", "updated_item": result.get("Attributes")})

    except json.JSONDecodeError:
        return response(400, {"error": "Invalid JSON body"})
    except Exception as e:
        # Log the full stack in CloudWatch
        print(f"Error updating vehicle {vehicle_id}: {e}")
        print(traceback.format_exc()) # Print the full stack trace
        return response(500, {"error": "Could not update vehicle. Check CloudWatch logs for details."})


def delete_vehicle_handler(event):
    """ DELETE /vehicles/{vehicle_id}: Deletes a vehicle by its ID."""
    vehicle_id = event.get("pathParameters", {}).get("vehicle_id")

    if not vehicle_id:
        return response(400, {"error": "Missing vehicle_id path parameter."})

    try:
        table.delete_item(Key={'vehicle_id': vehicle_id})

        return response(200, {"message": f"Vehicle {vehicle_id} deleted successfully."})
    except Exception as e:
        print(f"Error deleting vehicle {vehicle_id}: {e}")
        print(traceback.format_exc())

        return response(500, {"error": "Could not delete vehicle. Check CloudWatch for IAM/Boto3 error."})


def get_presigned_url_handler(event):
    """
    GET /upload-url: Generates an S3 pre-signed URL for a file upload.
    """
    file_name = event.get("queryStringParameters", {}).get("filename")

    if not file_name:
        return response(400, {"error": "Missing 'filename' query parameter."})

    try:
        presigned_url = s3_client.generate_presigned_url(
            ClientMethod='put_object',
            Params={
                'Bucket': IMAGE_BUCKET_NAME,
                'Key': file_name
            },
            ExpiresIn=300,
            HttpMethod='PUT'
        )
        return response(200, {
            "upload_url": presigned_url,
            "filename": file_name,
        })
    except Exception as e:
        print(f"Error generating presigned URL: {e}")
        print(traceback.format_exc())
        return response(500, {"error": "Could not generate upload URL."})


def lambda_handler(event, context):
    """Main entry point for the Lambda function. Routes requests based on method and path."""
    http_method = event.get("httpMethod")
    path = event.get("resource") or ""

    if http_method == "OPTIONS":
        return cors_preflight_response()

    # POST /vehicles (Add Vehicle)
    if http_method == "POST" and path == "/vehicles":
        return add_vehicle_handler(event)

    # GET /vehicles (Retrieve All Vehicles)
    if http_method == "GET" and path == "/vehicles":
        return get_vehicles_handler()

    # GET /vehicles/upload-url (Retrieve Presigned URL)
    if http_method == "GET" and path == "/vehicles/upload-url":
        return get_presigned_url_handler(event)

    # PUT /vehicles/{vehicle_id} (Update Vehicle)
    if http_method == "PUT" and path.startswith("/vehicles/"):
        return update_vehicle_handler(event)

    # DELETE /vehicles/{vehicle_id} (Delete Vehicle)
    if http_method == "DELETE" and path.startswith("/vehicles/"):
        return delete_vehicle_handler(event)

    # Default handler
    return response(404, {"error": "Not Found"})
    