"""Utility functions for Fleet Management."""
class Vehicle:
    """
    A simple class to represent a vehicle in the fleet,
    """
    def __init__(self, vehicle_id:
        str, make:
        str, model:
        str, mileage:
        int = 0, status: str = "available"):
        self.vehicle_id = vehicle_id
        self.make = make
        self.model = model
        self.mileage = mileage
        self.status = status
        # service threshold as a constant  the class
        self.service_internal = 15000

    def to_dict(self, image_url=None) -> dict:
        """
        Converts the vehicle object to a dictionary suitable for DynamoDB insertion,
        including maintenance status.
        """
        data = {
            "vehicle_id": self.vehicle_id,
            "make": self.make,
            "model": self.model,
            "mileage": self.mileage,
            "maintenance_due": self.mileage > self.service_internal
        }
        if image_url:
            data["image_url"] = image_url
        return data
        