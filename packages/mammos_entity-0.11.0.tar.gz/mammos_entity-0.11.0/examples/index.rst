mammos-entity
=============

``mammos-entity`` allows working with entities, a combination of quantity (number with unit) and ontology label.

.. toctree::
   :maxdepth: 1

   quickstart
   io