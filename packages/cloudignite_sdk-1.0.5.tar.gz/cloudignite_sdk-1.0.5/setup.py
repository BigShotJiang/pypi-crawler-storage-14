from setuptools import setup, find_packages

setup(
    name="cloudignite-sdk",
    version="1.0.5",
    description="Official Python SDK for CloudIgnite Authentication Services",
    long_description=open("README.md", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    author="CloudIgnite",
    author_email="arpitrangi72@gmail.com",
    url="https://cloudignite.in",
    packages=find_packages(),
    install_requires=[
        "requests>=2.25.0",
        "PyJWT>=2.0.0"
    ],
    python_requires=">=3.7",
    classifiers=[
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.7",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    project_urls={
        "Documentation": "https://cloudignite.in/docs",
        "Source": "https://github.com/cloudignite/sdk-python",
        "Tracker": "https://github.com/cloudignite/sdk-python/issues",
    },
)
