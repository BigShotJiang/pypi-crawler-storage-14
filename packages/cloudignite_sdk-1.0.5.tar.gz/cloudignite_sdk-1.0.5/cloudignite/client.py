import requests
from typing import Optional, Dict, Any, List

from .exceptions import APIError, InvalidCredentials, PermissionDenied, TokenExpired
from .models import User, AuthTokens
from .token_manager import TokenManager


BASE_URL = "https://api.cloudignite.in/v1"


def _check(resp):
    """Standard response validation"""
    if resp.status_code in (200, 201):
        try:
            return resp.json()
        except:
            return resp.text

    if resp.status_code == 401:
        raise InvalidCredentials(resp.text)

    if resp.status_code == 403:
        raise PermissionDenied(resp.status_code, resp.text)

    raise APIError(resp.status_code, resp.text)


class CloudIgnite:
    """
    Official CloudIgnite Python SDK
    --------------------------------
    Initialization:
        client = CloudIgnite(
            project_id="your-project-id",
            api_key="your-api-key"
        )
    """

    def __init__(self, project_id: str, api_key: str):
        self.project_id = project_id
        self.api_key = api_key
        self.session = requests.Session()
        self.tokens = TokenManager()

    # Build URL
    def _url(self, path: str):
        return f"{BASE_URL}/projects/{self.project_id}{path}"

    # Build headers
    def _headers(self):
        h = {"X-API-Key": self.api_key}
        if self.tokens.access_token:
            h["Authorization"] = f"Bearer {self.tokens.access_token}"
        return h

    # Core request handling
    def _req(self, method, path, body=None, params=None):
        resp = self.session.request(
            method,
            self._url(path),
            json=body,
            params=params,
            headers=self._headers(),
            timeout=30
        )

        # Auto-refresh token once
        if resp.status_code == 401 and self.tokens.refresh_token:
            try:
                self.refresh()
                resp = self.session.request(
                    method,
                    self._url(path),
                    json=body,
                    params=params,
                    headers=self._headers(),
                    timeout=30
                )
            except:
                pass

        return _check(resp)

    # --------------------------------------------------------------
    # AUTH
    # --------------------------------------------------------------

    def signup(self, email, password, metadata=None):
        data = self._req("POST", "/auth/signup", {
            "email": email,
            "password": password,
            "metadata": metadata or {}
        })

        user = User(**data["user"])
        tokens = AuthTokens(data["access_token"], data["refresh_token"])
        self.tokens.set_tokens(tokens.access_token, tokens.refresh_token)

        return user, tokens

    def login(self, email, password):
        data = self._req("POST", "/auth/login", {
            "email": email,
            "password": password
        })

        user = User(**data["user"])
        tokens = AuthTokens(data["access_token"], data["refresh_token"])
        self.tokens.set_tokens(tokens.access_token, tokens.refresh_token)

        return user, tokens

    def refresh(self):
        data = self._req("POST", "/auth/refresh", {
            "refresh_token": self.tokens.refresh_token
        })

        tokens = AuthTokens(data["access_token"], data["refresh_token"])
        self.tokens.set_tokens(tokens.access_token, tokens.refresh_token)

        return tokens

    def logout(self):
        self._req("POST", "/auth/logout", {
            "refresh_token": self.tokens.refresh_token
        })
        self.tokens.clear()
        return True

    def logout_all(self):
        self._req("POST", "/auth/logout-all")
        self.tokens.clear()
        return True

    # --------------------------------------------------------------
    # PASSWORD RESET
    # --------------------------------------------------------------

    def forgot_password(self, email: str):
        return self._req("POST", "/auth/forgot-password", {"email": email})

    def reset_password(self, email: str, otp: str, new_password: str):
        return self._req("POST", "/auth/reset-password", {
            "email": email,
            "otp": otp,
            "new_password": new_password
        })

    # --------------------------------------------------------------
    # EMAIL VERIFICATION
    # --------------------------------------------------------------

    def resend_verification(self, email: str):
        return self._req("POST", "/auth/resend-verification-email", {"email": email})

    def verify_email(self, token: str):
        return self._req("POST", "/auth/verify-email", {"token": token})

    # --------------------------------------------------------------
    # PROFILE
    # --------------------------------------------------------------

    def me(self):
        return self._req("GET", "/auth/me")

    def update_me(self, metadata: dict):
        return self._req("PATCH", "/auth/me", {"metadata": metadata})

    def change_password(self, old_password: str, new_password: str):
        return self._req("POST", "/auth/change-password", {
            "old_password": old_password,
            "new_password": new_password
        })

    def delete_account(self):
        return self._req("DELETE", "/auth/delete")

    # --------------------------------------------------------------
    # SESSIONS
    # --------------------------------------------------------------

    def list_sessions(self):
        return self._req("GET", "/auth/sessions")

    def revoke_session(self, session_id: str):
        return self._req("DELETE", f"/auth/sessions/{session_id}")

    # --------------------------------------------------------------
    # API KEYS
    # --------------------------------------------------------------

    def create_api_key(self, permissions=None, environment="prod"):
        return self._req("POST", "/auth/api-keys/create", {
            "permissions": permissions or {"read": True},
            "environment": environment
        })

    def list_api_keys(self):
        return self._req("GET", "/auth/api-keys")

    def delete_api_key(self, key_id: str):
        return self._req("DELETE", f"/auth/api-keys/{key_id}")

    # --------------------------------------------------------------
    # ADMIN USER MANAGEMENT
    # --------------------------------------------------------------

    def list_users(self, status=None, email=None):
        params = {}
        if status:
            params["status"] = status
        if email:
            params["email"] = email
        return self._req("GET", "/auth/users", params=params)

    def block_user(self, email: str, reason: Optional[str] = ""):
        return self._req("POST", "/auth/block-user", {
            "email": email,
            "reason": reason
        })

    def unblock_user(self, email: str):
        return self._req("POST", "/auth/unblock-user", {"email": email})

    def ban_user(self, email: str, reason: Optional[str] = ""):
        return self._req("POST", "/auth/ban-user", {
            "email": email,
            "reason": reason
        })

    def unban_user(self, email: str):
        return self._req("POST", "/auth/unban-user", {"email": email})

    # --------------------------------------------------------------
    # CLEAR EVERYTHING
    # --------------------------------------------------------------

    def clear_all(self):
        self.tokens.clear()
        self.api_key = None
