from dataclasses import dataclass
from typing import Optional, Dict, Any

@dataclass
class User:
    id: str
    email: str
    role: str = "user"
    metadata: Optional[Dict[str, Any]] = None
    email_verified: bool = False

@dataclass
class AuthTokens:
    access_token: str
    refresh_token: str
