import time
import jwt
from .exceptions import TokenExpired

class TokenManager:
    def __init__(self):
        self.access_token = None
        self.refresh_token = None

    def set_tokens(self, access, refresh):
        self.access_token = access
        self.refresh_token = refresh

    def clear(self):
        self.access_token = None
        self.refresh_token = None

    def get_access(self):
        if not self.access_token:
            raise TokenExpired("No access token")

        try:
            payload = jwt.decode(self.access_token, options={"verify_signature": False})
            exp = payload.get("exp")
            if exp and exp < int(time.time()):
                raise TokenExpired("Access token expired")
            return self.access_token
        except Exception:
            raise TokenExpired("Access token invalid")
