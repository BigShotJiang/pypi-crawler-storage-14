🌩 CloudIgnite Python SDK
Official Python SDK for CloudIgnite Authentication Services

The CloudIgnite SDK for Python provides a clean, simple, and efficient interface for developers to interact with the CloudIgnite platform. It allows seamless integration of CloudIgnite’s project-based authentication system into any Python application.

🚀 Features
🔐 Authentication

Email/password user login

Secure user signup

Refresh token rotation

JWT access tokens

Logout & session revocation

Multi-session support

👤 User Management

Fetch authenticated user (/me)

Update user metadata

Change password

Delete account

Manage sessions

🔑 API Keys

Create API keys

List API keys

Delete API keys

Automatic API Key header support (X-API-Key)

🛡 Security

Block/unblock users

Ban/unban users

Email verification

Password reset via OTP

Full audit logging

Rate-limited login (brute force protection)

📦 Installation
pip install cloudignite-sdk

🧪 Quick Start
from cloudignite import CloudIgnite

client = CloudIgnite("https://api.cloudignite.in/v1")

project_id = "your-project-id"

# Signup
user, tokens = client.signup(project_id, "user@example.com", "Password123!")

# Login
user, tokens = client.login(project_id, "user@example.com", "Password123!")

# Get current user
print(client.me(project_id))

# Create API Key
api_key = client.create_api_key(project_id, {"read": True})
client.set_api_key(api_key["api_key"])

📘 Documentation

Full documentation available at:

👉 https://cloudignite.in/docs

🧑‍💻 Requirements

Python 3.7+

requests

PyJWT