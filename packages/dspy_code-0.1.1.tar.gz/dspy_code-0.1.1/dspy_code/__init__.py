"""
DSPy Code - A command-line interface for the DSPy framework.

This package provides tools for creating, managing, and optimizing DSPy components
through natural language interactions.
"""

__version__ = "0.1.0"
__author__ = "DSPy Code Team"
