To be able to configure the Planned date some days before Deadline date.
