This module extends the functionality of Stock Picking dates to align the Deadline Date field with the Planned Date field in the first instance and to allow the Planned Date field to be used as a reference field when preparing deliveries.

As usual, allows the Planned Date field to be freely changed without affecting the Deadline Date field, but if the Deadline date field is changed on Pickings through another module, the Planned Date field on the Picking will also be updated to the Deadline Date.
