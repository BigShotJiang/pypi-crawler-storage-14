To use this module, you need to:

1. Sell a storable product to create pickings or create a new delivery.
2. Confirm the sale or picking.
3. Add the Commitment date to sale or Deadline date on stock moves. This will change deadline date and scheduled date of your pickings.
4. Change again Commitment date on sales or Deadline date on stock moves. This will change deadline date and scheduled date of your pickings.
5. Go to the picking and change Schedule date if you want to make a rescheduling.
