This module adds a button in the website cart that let users remove all the selected products at once
