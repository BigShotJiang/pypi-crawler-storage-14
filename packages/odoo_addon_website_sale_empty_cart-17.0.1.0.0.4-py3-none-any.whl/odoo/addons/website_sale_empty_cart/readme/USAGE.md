To use this module, you need to:

1. Go to the "/shop/cart" path of your server website. Example: "http://localhost:8069/shop/cart"
2. You will see your cart. If it is empty, go to "Shop" and add some products.
3. Click on the "Empty Cart" button.
4. You will see the cart with no products.
