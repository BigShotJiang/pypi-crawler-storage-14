evaluator package
==========================

.. automodule:: lightwin.evaluator
   :members:
   :undoc-members:
   :show-inheritance:

Subpackages
-----------

.. toctree::
   :maxdepth: 5

   lightwin.evaluator.simulation_output

Submodules
----------

.. toctree::
   :maxdepth: 5

   lightwin.evaluator.list_of_simulation_output_evaluators
   lightwin.evaluator.post_treaters
   lightwin.evaluator.specs
   lightwin.evaluator.testers
   lightwin.evaluator.types
