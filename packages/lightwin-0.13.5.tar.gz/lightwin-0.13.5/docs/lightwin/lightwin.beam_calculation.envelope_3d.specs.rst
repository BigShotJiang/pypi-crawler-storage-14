specs module
====================================================

.. automodule:: lightwin.beam_calculation.envelope_3d.specs
   :members:
   :undoc-members:
   :show-inheritance:
