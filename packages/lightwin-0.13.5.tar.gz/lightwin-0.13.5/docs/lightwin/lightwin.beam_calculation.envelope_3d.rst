envelope\_3d package
===============================================

.. automodule:: lightwin.beam_calculation.envelope_3d
   :members:
   :undoc-members:
   :show-inheritance:

Submodules
----------

.. toctree::
   :maxdepth: 5

   lightwin.beam_calculation.envelope_3d.beam_parameters_factory
   lightwin.beam_calculation.envelope_3d.element_envelope3d_parameters
   lightwin.beam_calculation.envelope_3d.element_envelope3d_parameters_factory
   lightwin.beam_calculation.envelope_3d.envelope_3d
   lightwin.beam_calculation.envelope_3d.simulation_output_factory
   lightwin.beam_calculation.envelope_3d.specs
   lightwin.beam_calculation.envelope_3d.transfer_matrices_p
   lightwin.beam_calculation.envelope_3d.transfer_matrix_factory
   lightwin.beam_calculation.envelope_3d.util
