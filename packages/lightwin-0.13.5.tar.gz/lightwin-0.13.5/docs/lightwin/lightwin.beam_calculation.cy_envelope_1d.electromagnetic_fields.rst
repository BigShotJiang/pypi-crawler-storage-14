electromagnetic\_fields module
==========================================================================

.. automodule:: lightwin.beam_calculation.cy_envelope_1d.electromagnetic_fields
   :members:
   :undoc-members:
   :show-inheritance:
