beam\_calculator\_base\_specs module
===============================================================

.. automodule:: lightwin.beam_calculation.beam_calculator_base_specs
   :members:
   :undoc-members:
   :show-inheritance:
