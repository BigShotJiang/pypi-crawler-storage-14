bayesian\_optimization module
==============================================================

.. automodule:: lightwin.optimisation.algorithms.bayesian_optimization
   :members:
   :undoc-members:
   :show-inheritance:
