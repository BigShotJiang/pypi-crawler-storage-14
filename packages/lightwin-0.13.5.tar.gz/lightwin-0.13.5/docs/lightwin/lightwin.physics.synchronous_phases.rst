synchronous\_phases module
===========================================

.. automodule:: lightwin.physics.synchronous_phases
   :members:
   :undoc-members:
   :show-inheritance:
