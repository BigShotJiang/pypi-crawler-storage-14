solenoid module
======================================

.. automodule:: lightwin.core.elements.solenoid
   :members:
   :undoc-members:
   :show-inheritance:
