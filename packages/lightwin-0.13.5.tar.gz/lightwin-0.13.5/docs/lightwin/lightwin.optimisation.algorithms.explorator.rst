explorator module
==================================================

.. automodule:: lightwin.optimisation.algorithms.explorator
   :members:
   :undoc-members:
   :show-inheritance:
