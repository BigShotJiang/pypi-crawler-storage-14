envelope\_1d module
===============================================================

.. automodule:: lightwin.beam_calculation.cy_envelope_1d.envelope_1d
   :members:
   :undoc-members:
   :show-inheritance:
