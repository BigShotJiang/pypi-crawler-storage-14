ui package
===================

.. automodule:: lightwin.ui
   :members:
   :undoc-members:
   :show-inheritance:

Submodules
----------

.. toctree::
   :maxdepth: 5

   lightwin.ui.workflow_setup
