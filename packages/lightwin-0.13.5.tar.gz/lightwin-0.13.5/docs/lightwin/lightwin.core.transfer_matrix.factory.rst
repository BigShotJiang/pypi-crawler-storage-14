factory module
=============================================

.. automodule:: lightwin.core.transfer_matrix.factory
   :members:
   :undoc-members:
   :show-inheritance:
