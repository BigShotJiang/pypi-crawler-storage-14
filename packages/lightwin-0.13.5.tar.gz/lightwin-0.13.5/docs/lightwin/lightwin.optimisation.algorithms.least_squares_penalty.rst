least\_squares\_penalty module
===============================================================

.. automodule:: lightwin.optimisation.algorithms.least_squares_penalty
   :members:
   :undoc-members:
   :show-inheritance:
