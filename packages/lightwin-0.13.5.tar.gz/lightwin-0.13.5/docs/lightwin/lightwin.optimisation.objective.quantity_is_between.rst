quantity\_is\_between module
============================================================

.. automodule:: lightwin.optimisation.objective.quantity_is_between
   :members:
   :undoc-members:
   :show-inheritance:
