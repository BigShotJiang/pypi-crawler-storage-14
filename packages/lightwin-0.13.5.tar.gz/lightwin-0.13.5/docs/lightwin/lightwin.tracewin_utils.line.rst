line module
====================================

.. automodule:: lightwin.tracewin_utils.line
   :members:
   :undoc-members:
   :show-inheritance:
