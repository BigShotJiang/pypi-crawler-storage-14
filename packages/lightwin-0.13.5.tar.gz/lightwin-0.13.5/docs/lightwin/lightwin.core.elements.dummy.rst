dummy module
===================================

.. automodule:: lightwin.core.elements.dummy
   :members:
   :undoc-members:
   :show-inheritance:
