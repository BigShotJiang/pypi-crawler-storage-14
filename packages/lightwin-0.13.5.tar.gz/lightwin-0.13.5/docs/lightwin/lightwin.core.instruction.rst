instruction module
================================

.. automodule:: lightwin.core.instruction
   :members:
   :undoc-members:
   :show-inheritance:
