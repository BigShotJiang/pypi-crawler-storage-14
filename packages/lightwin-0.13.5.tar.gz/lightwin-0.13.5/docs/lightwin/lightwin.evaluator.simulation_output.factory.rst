factory module
====================================================

.. automodule:: lightwin.evaluator.simulation_output.factory
   :members:
   :undoc-members:
   :show-inheritance:
