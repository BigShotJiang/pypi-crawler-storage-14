combine\_solutions module
==========================================

.. automodule:: lightwin.scripts.combine_solutions
   :members:
   :undoc-members:
   :show-inheritance:
