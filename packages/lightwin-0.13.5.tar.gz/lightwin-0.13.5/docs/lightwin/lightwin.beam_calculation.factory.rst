factory module
=========================================

.. automodule:: lightwin.beam_calculation.factory
   :members:
   :undoc-members:
   :show-inheritance:
