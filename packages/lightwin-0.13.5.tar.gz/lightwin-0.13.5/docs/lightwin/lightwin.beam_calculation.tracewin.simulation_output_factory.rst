simulation\_output\_factory module
======================================================================

.. automodule:: lightwin.beam_calculation.tracewin.simulation_output_factory
   :members:
   :undoc-members:
   :show-inheritance:
