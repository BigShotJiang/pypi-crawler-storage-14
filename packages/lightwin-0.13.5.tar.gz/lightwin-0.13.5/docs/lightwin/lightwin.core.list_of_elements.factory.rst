factory module
===============================================

.. automodule:: lightwin.core.list_of_elements.factory
   :members:
   :undoc-members:
   :show-inheritance:
