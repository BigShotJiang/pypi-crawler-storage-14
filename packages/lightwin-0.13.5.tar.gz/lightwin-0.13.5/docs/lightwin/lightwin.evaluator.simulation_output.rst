simulation\_output package
=============================================

.. automodule:: lightwin.evaluator.simulation_output
   :members:
   :undoc-members:
   :show-inheritance:

Submodules
----------

.. toctree::
   :maxdepth: 5

   lightwin.evaluator.simulation_output.factory
   lightwin.evaluator.simulation_output.presets
   lightwin.evaluator.simulation_output.simulation_output_evaluator
