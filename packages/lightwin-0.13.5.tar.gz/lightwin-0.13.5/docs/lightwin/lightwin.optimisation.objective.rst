objective package
=======================================

.. automodule:: lightwin.optimisation.objective
   :members:
   :undoc-members:
   :show-inheritance:

Submodules
----------

.. toctree::
   :maxdepth: 5

   lightwin.optimisation.objective.factory
   lightwin.optimisation.objective.helper
   lightwin.optimisation.objective.minimize_difference_with_ref
   lightwin.optimisation.objective.minimize_mismatch
   lightwin.optimisation.objective.objective
   lightwin.optimisation.objective.position
   lightwin.optimisation.objective.quantity_is_between
