fault\_scenario module
========================================

.. automodule:: lightwin.failures.fault_scenario
   :members:
   :undoc-members:
   :show-inheritance:
