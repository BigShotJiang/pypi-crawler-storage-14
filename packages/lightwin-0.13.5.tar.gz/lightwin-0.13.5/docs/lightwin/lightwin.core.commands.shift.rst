shift module
===================================

.. automodule:: lightwin.core.commands.shift
   :members:
   :undoc-members:
   :show-inheritance:
