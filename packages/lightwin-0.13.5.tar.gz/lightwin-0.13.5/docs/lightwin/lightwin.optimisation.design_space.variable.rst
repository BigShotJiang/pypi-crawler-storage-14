variable module
===================================================

.. automodule:: lightwin.optimisation.design_space.variable
   :members:
   :undoc-members:
   :show-inheritance:
