helper module
=============================================

.. automodule:: lightwin.optimisation.objective.helper
   :members:
   :undoc-members:
   :show-inheritance:
