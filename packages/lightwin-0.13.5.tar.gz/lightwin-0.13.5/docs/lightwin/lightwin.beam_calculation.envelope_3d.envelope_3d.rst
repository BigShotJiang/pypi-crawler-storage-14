envelope\_3d module
===========================================================

.. automodule:: lightwin.beam_calculation.envelope_3d.envelope_3d
   :members:
   :undoc-members:
   :show-inheritance:
