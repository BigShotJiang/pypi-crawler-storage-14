specs module
========================================================

.. automodule:: lightwin.beam_calculation.cy_envelope_1d.specs
   :members:
   :undoc-members:
   :show-inheritance:
