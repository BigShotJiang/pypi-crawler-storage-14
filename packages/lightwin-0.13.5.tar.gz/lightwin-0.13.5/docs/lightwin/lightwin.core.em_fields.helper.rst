helper module
======================================

.. automodule:: lightwin.core.em_fields.helper
   :members:
   :undoc-members:
   :show-inheritance:
