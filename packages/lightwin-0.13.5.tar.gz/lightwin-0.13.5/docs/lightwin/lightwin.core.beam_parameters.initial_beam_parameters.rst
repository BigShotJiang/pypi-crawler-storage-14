initial\_beam\_parameters module
===============================================================

.. automodule:: lightwin.core.beam_parameters.initial_beam_parameters
   :members:
   :undoc-members:
   :show-inheritance:
