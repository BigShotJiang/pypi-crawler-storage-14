error module
===================================

.. automodule:: lightwin.core.commands.error
   :members:
   :undoc-members:
   :show-inheritance:
