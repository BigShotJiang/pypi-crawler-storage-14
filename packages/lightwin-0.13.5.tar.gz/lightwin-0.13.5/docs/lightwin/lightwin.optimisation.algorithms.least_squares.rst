least\_squares module
======================================================

.. automodule:: lightwin.optimisation.algorithms.least_squares
   :members:
   :undoc-members:
   :show-inheritance:
