full\_specs module
==================================

.. automodule:: lightwin.config.full_specs
   :members:
   :undoc-members:
   :show-inheritance:
