workflow\_setup module
==================================

.. automodule:: lightwin.ui.workflow_setup
   :members:
   :undoc-members:
   :show-inheritance:
