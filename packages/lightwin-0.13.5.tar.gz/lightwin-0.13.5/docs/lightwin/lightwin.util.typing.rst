typing module
===========================

.. automodule:: lightwin.util.typing
   :members:
   :undoc-members:
   :show-inheritance:
