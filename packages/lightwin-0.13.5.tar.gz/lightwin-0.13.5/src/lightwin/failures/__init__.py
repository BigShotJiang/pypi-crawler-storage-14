"""
This folder holds all the modules related to breaking cavities and setting the
compensation scheme.
"""
