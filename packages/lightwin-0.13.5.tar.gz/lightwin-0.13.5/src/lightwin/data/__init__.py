"""This module packages some data file for examples and testing."""
