"""Here we define all the linac elements (TraceWin syntax)."""
