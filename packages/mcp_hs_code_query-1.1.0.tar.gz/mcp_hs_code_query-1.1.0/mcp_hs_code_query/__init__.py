"""MCP HS Code Query Server - 智能海关HS编码查询服务"""

__version__ = "1.0.0"
