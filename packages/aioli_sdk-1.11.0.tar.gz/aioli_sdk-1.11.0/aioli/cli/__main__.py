# © Copyright 2023-2025 Hewlett Packard Enterprise Development LP
from aioli.cli.cli import main  # noqa: I2041

if __name__ == "__main__":
    main()
