# flake8: noqa

# import apis into api package
from aiolirest.api.deployments_api import DeploymentsApi
from aiolirest.api.information_api import InformationApi
from aiolirest.api.packaged_models_api import PackagedModelsApi
from aiolirest.api.projects_api import ProjectsApi
from aiolirest.api.registries_api import RegistriesApi
from aiolirest.api.roles_api import RolesApi
from aiolirest.api.templates_api import TemplatesApi
from aiolirest.api.users_api import UsersApi

