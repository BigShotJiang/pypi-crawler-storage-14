import re

from dateutil import parser
from typing import Union

def parse_date(date_str: Union[bytes, str]):
    try:
        if isinstance(date_str, bytes):
            date_str = date_str.decode('utf-8')
        if re.match(r'\d{4}-\d{2}-\d{2}', date_str):
            return parser.parse(date_str, dayfirst=False)
        elif re.match(r'\d{2}[-.]\d{2}[-.]\d{4}', date_str):
            return parser.parse(date_str, dayfirst=True)
        elif re.match(r'\d{2}/\d{2}/\d{4}', date_str):
            return parser.parse(date_str, dayfirst=False)
    except Exception:
        return None
    return None