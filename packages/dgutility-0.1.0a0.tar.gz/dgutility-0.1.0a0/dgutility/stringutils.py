import inspect

def simple_translit(text: str):
    symbols = (u"абвгдеёжзийклмнопрстуфхцчшщъыьэюяАБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯ",
               u"abvgdeejzijklmnoprstufhzcss_y_euaABVGDEEJZIJKLMNOPRSTUFHZCSS_Y_EUA")
    tr = {ord(a): ord(b) for a, b in zip(*symbols)}
    return text.translate(tr)

def varName(var):
    lcls = inspect.stack()[2][0].f_locals
    for name in lcls:
        if id(var) == id(lcls[name]):
            return name
    return None

def get_com(count, word_root, endings=None):
    if endings is None:
        endings = ['', 'а', 'ов']
    if count == 0:
        word = word_root + endings[2]
    else:
        inumber = count % 100
        if 11 <= inumber <= 19:
            word = word_root + endings[2]
        else:
            iinumber = inumber % 10
            if iinumber == 1:
                word = word_root + endings[0]
            elif iinumber in [2,3,4]:
                word = word_root + endings[1]
            else:
                word = word_root + endings[2]
    return f'{count} {word}'
