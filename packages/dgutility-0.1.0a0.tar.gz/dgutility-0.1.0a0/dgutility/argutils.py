import sys
import os

def get_args():
    args = sys.argv
    args_d = {}
    for i, arg in enumerate(args):
        if i == 0:
            args_d['name'] = arg
            continue
        if arg.startswith('-') or arg.startswith('--'):
            arg = arg.lstrip('-')
            if i != len(args) - 1 and not (args[i + 1].startswith('-') or args[i + 1].startswith('--')):
                v = args[i + 1]
                for cast in (int, float, str):
                    try:
                        v = cast(v)
                        break
                    except ValueError:
                        continue
                args_d[arg] = v
            else:
                args_d[arg] = True
    return args_d

def get_log_param(args: dict):
    log_level = args.get('log_level') or args.get('ll') or 'INFO'
    log_name = args.get('log_name') or args.get('ln')
    log_dir = args.get('log_dir') or args.get('ld') or os.path.join(get_base_dir(), 'logs')
    return {'log_level': log_level, 'log_name': log_name, 'log_dir': log_dir}

def get_base_dir():
    return os.getcwd()
