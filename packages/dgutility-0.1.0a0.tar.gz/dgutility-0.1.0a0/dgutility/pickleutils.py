import pickle
from typing import Any

def pickle_data(data: Any, fname: str):
    with open(fname, 'wb') as f:
        pickle.dump(data, f)

def unpickle_data(fname: str, return_: Any = None):
    try:
        with open(fname, 'rb') as f:
            data = pickle.load(f)
    except FileNotFoundError:
        data = return_
    return data
