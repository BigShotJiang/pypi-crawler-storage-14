from itertools import chain

def slice_obj(iterable_object, step):
    steps = [i for i in range(len(iterable_object)) if i % step == 0 and i > 0]
    pairs = zip(chain([0], steps), chain(steps, [None]))
    for i, j in pairs:
        yield iterable_object[i:j]

def slice_portion(iterable_obj, portion_qty):
    k, m = divmod(len(iterable_obj), portion_qty)
    return (iterable_obj[i * k + min(i, m):(i + 1) * k + min(i + 1, m)] for i in range(portion_qty))

def slice_portion_2(iterable_obj, portion_qty):
    return slice_obj(iterable_obj, len(iterable_obj) // portion_qty + 1)
