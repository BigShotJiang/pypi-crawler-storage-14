def dict_compare(old_dict: dict, new_dict: dict):
    old_keys = set(old_dict.keys())
    new_keys = set(new_dict.keys())
    intersect = old_keys & new_keys
    added = new_keys - old_keys
    removed = old_keys - new_keys
    modified = {o: (old_dict[o], new_dict[o]) for o in intersect if old_dict[o] != new_dict[o]}
    same = set(o for o in intersect if old_dict[o] == new_dict[o] or (old_dict[o] is None and new_dict[o] is None))
    return {'added': list(added), 'removed': list(removed), 'modified': modified, 'same': list(same)}

def subset_dict(dict1: dict, dict2: dict):
    return set(dict1.items()) <= set(dict2.items())

def dict_find_keys(list_dict: list, filter: dict, multiple=True):
    result = [x for x in list_dict if subset_dict(filter, x)]
    if not multiple:
        return result[0] if result else {}
    return result
