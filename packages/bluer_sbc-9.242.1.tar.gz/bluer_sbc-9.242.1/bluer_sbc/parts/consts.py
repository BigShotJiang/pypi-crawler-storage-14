parts_url_prefix = (
    "https://github.com/kamangir/bluer-sbc/tree/main/bluer_sbc/docs/parts"
)
