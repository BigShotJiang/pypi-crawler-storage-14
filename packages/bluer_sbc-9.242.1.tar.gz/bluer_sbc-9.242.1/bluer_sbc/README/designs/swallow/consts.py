from bluer_objects.README.consts import assets_url


swallow_assets2 = assets_url(
    "swallow",
    volume=2,
)
