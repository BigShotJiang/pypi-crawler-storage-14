import json
import logging
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any, List, Dict

import httpx
import yaml
from pydantic import BaseModel, Field, ValidationError


class HttpMethod(str, Enum):
    GET = "GET"
    POST = "POST"
    PUT = "PUT"
    PATCH = "PATCH"
    DELETE = "DELETE"


class HeaderConfig(BaseModel):
    """Secure header configuration with environment variables support."""
    name: str
    value: str
    secure: bool = False

    class Config:
        frozen = True


class RequestSchemaConfig(BaseModel):
    """Schema definition for request payload population."""
    field_path: str  # JSON path-like: "data.user.id"
    value: Any
    value_type: str = "static"  # static, env, dynamic
    required: bool = True


class ResponseMappingConfig(BaseModel):
    """Response data extraction mapping."""
    field_path: str  # JSON path-like: "data.results[0].id"
    extract_as: str  # Name to extract as
    default: Any = None


class EndpointConfig(BaseModel):
    """Complete endpoint configuration."""
    name: str
    base_url: str
    path: str
    method: HttpMethod
    headers: List[HeaderConfig] = Field(default_factory=list)
    request_schema: List[RequestSchemaConfig] = Field(default_factory=list)
    response_mapping: List[ResponseMappingConfig] = Field(default_factory=list)
    timeout: int = 30
    retry_count: int = 3
    retry_backoff: float = 1.0

    @classmethod
    def validate_path(cls, v: str) -> str:
        if not v.startswith('/'):
            return f'/{v}'
        return v


class PayloadBuilder(ABC):
    """Abstract base for payload construction strategies."""
    @abstractmethod
    def build(self, schema: List[RequestSchemaConfig], context: Dict[str, Any]) -> Dict[str, Any]:
        """Build request payload from schema and context."""
        pass


class JsonPathPayloadBuilder(PayloadBuilder):
    """Builds nested JSON payloads using dot-notation paths."""
    def build(self, schema: List[RequestSchemaConfig], context: Dict[str, Any]) -> Dict[str, Any]:
        payload = {}

        for field_config in schema:
            value = self._resolve_value(field_config, context)
            if value is None and field_config.required:
                raise ValueError(f"Required field {field_config.field_path} has no value")

            self._set_nested_value(payload, field_config.field_path, value)

        return payload

    @staticmethod
    def _resolve_value(config: RequestSchemaConfig, context: Dict[str, Any]) -> Any:
        """Resolve value based on type: statis, env, or dynamic."""
        if config.value_type == "static":
            return config.value
        elif config.value_type == "env":
            import os
            return os.getenv(config.value)
        elif config.value_type == "dynamic":
            print(f"config value: {config.field_path}")
            print(f"context: {context}")
            return context.get(config.field_path)

        return config.value

    @staticmethod
    def _set_nested_value(obj: Dict, path: str, value: Any) -> None:
        """Set value in nested dict using dot notation."""
        parts = path.split('.')
        for part in parts[:-1]:
            obj = obj.setdefault(part, {})

        obj[parts[-1]] = value


class ResponseExtractor:
    """Extracts data from API responses based on mapping config."""
    def extract(
            self,
            response_data: Dict[str, Any],
            mappings: List[ResponseMappingConfig]
    ) -> Dict[str, Any]:
        """Extract mapped fields from response data."""
        result = {}

        for mapping in mappings:
            try:
                value = self._extract_by_path(response_data, mapping.field_path)
                result[mapping.extract_as] = value if value is not None else mapping.default

            except Exception as e:
                print(f"Failed to extract '{mapping.field_path}':\n{e}")
                result[mapping.extract_as] = mapping.default

        return result

    @staticmethod
    def _extract_by_path(obj: Any, path: str) -> Any:
        """Extract value using JSONPath-like notation."""
        parts = path.split('.')
        current = obj

        for part in parts:
            if '[' in part and ']' in part:
                key, idx = part.split('[')
                idx = int(idx.rstrip(']'))
                current = current[key][idx] if key else current[idx]
            else:
                current = current[part]

        return current


@dataclass
class APIClient:
    """HTTP client for REST API interactions."""
    config: EndpointConfig
    client: httpx.Client = field(init=False)
    logger: logging.Logger = field(init=False)

    def __post_init__(self):
        self.logger = logging.getLogger(f"APIClient.{self.config.name}")
        self.client = httpx.Client(
            base_url=self.config.base_url,
            timeout=self.config.timeout,
            follow_redirects=True
        )

    def __del__(self):
        if hasattr(self, "client"):
            self.client.close()

    def _build_headers(self) -> Dict[str, str]:
        """Build headers with secure value resolution."""
        headers = {}
        import os

        for header in self.config.headers:
            if header.secure:
                value = os.getenv(header.value)
                if value is None:
                    self.logger.warning(f"Secure header '{header.name}' env var '{header.value}' not found")
                    continue
                headers[header.name] = value
            else:
                headers[header.name] = header.value

        return headers

    def execute(
            self,
            payload: Dict[str, Any] | None = None,
            query_params: Dict[str, Any] | None = None
    ) -> httpx.Response:
        """Execute API request with retry logic."""
        headers = self._build_headers()

        for attempt in range(self.config.retry_count):
            try:
                response = self.client.request(
                    method=self.config.method.value,
                    url=self.config.path,
                    json=payload,
                    params=query_params,
                    headers=headers
                )
                response.raise_for_status()
                return response

            except httpx.HTTPStatusError as e:
                self.logger.error(f"HTTP {e.response.status_code}: {e.response.text}")
                if attempt == self.config.retry_count:
                    raise e

            except httpx.RequestError as e:
                self.logger.error(f"Request failed (attempt {attempt + 1}): {e}")
                if attempt == self.config.retry_count - 1:
                    raise

                import time
                time.sleep(self.config.retry_backoff * (attempt + 1))

        raise RuntimeError("Max retries exceeded")


class ConnectivityTester:
    """Tests REST endpoint connectivity with configurable behavior."""
    def __init__(self, config: EndpointConfig):
        self.config = config
        self.client = APIClient(config=config)
        self.payload_builder = JsonPathPayloadBuilder()
        self.response_extractor = ResponseExtractor()
        self.logger = logging.getLogger(f"ConnectivityTester.{self.config.name}")

    def test(self, context: Dict[str, Any] = None) -> Dict[str, Any]:
        """Execute connectivity test (template Method)."""
        context = context or {}

        self.logger.info(f"Starting connectivity test for '{self.config.name}'")

        try:
            payload = None
            if self.config.request_schema:
                payload = self.payload_builder.build(schema=self.config.request_schema, context=context)
                # self.logger.debug(f"Request payload:\n{json.dumps(payload, indent=2, default=str)}\n---")
                self.logger.debug(f"Request payload:\n{payload}\n---")

            response = self.client.execute(payload=payload)
            self.logger.info(f"Response status: {response.status_code}")

            response_data = response.json() if response.text else {}
            extracted = self.response_extractor.extract(
                response_data=response_data,
                mappings=self.config.response_mapping
            )

            return {
                "success": True,
                "status_code": response.status_code,
                "extracted_data": extracted,
                "raw_response": response_data
            }

        except Exception as e:
            self.logger.error(f"Connectivity test failed: {e}", exc_info=e)
            return {
                "success": False,
                "error": str(e),
                "error_type": type(e).__name__
            }


class ConfigurationManager:
    """Manages endpoint configurations and creates testers."""
    def __init__(self, config_path: Path):
        self.config_path = config_path
        self.endpoints: Dict[str, EndpointConfig] = {}
        self.logger = logging.getLogger("ConfigurationManager")
        self._load_config()

    def _load_config(self) -> None:
        """Load and validate YAML configuration."""
        try:
            with open(self.config_path, "r") as f:
                data = yaml.safe_load(f)

            for endpoint_data in data.get_strategy('endpoints', []):
                config = EndpointConfig.model_validate(endpoint_data)
                self.endpoints[config.name] = config
                self.logger.info(f"Loaded endpoint config: {config.name}")

        except Exception as e:
            self.logger.error(f"Failed to load endpoint config: {e}", exc_info=e)
            raise

    def build_response_mapping(self, content: List[Dict[str, Any]]) -> List[ResponseMappingConfig]:
        mappings = []
        for el in content:
            try:
                mappings.append(ResponseMappingConfig.model_validate(el))
            except ValidationError as e:
                self.logger.error(f"Failed to validate response mapping: {e}", exc_info=e)

        return mappings

    def extract_response_data(
            self,
            endpoint_name: str,
            context: Dict[str, Any],
            mappings: List[ResponseMappingConfig]
    ) -> Dict[str, Any]:
        if endpoint_name not in self.endpoints:
            raise ValueError(f"Endpoint '{endpoint_name}' not found in configuration")

        payload_builder = JsonPathPayloadBuilder()
        client = APIClient(config=self.endpoints[endpoint_name])
        extractor = ResponseExtractor()
        payload = payload_builder.build(
            schema=self.endpoints[endpoint_name].request_schema,
            context=context
        )
        response = client.execute(payload=payload)
        self.logger.info(f"Response status: {response.status_code}")
        response_data = response.json() if response.text else {}
        extracted = extractor.extract(
            response_data=response_data,
            mappings=mappings
        )
        return extracted

    def get_tester(self, endpoint_name: str) -> ConnectivityTester:
        """Factory method: create connectivity tester for endpoint."""
        if endpoint_name not in self.endpoints:
            raise KeyError(f"Endpoint '{endpoint_name}' not found in configuration")

        return ConnectivityTester(self.endpoints[endpoint_name])

    def test_all(self, context: Dict[str, Any] | None = None) -> Dict[str, Dict[str, Any]]:
        """Test all configured endpoints."""
        results = {}
        for name in self.endpoints:
            tester = self.get_tester(name)
            results[name] = tester.test(context)

        return results


if __name__ == '__main__':
    # Example: Load configuration and test endpoint
    config_manager = ConfigurationManager(Path("dashq_api.yaml"))

    # # Test specific endpoint
    # tester = config_manager.get_tester("dashq")
    # result = tester.test(context={"conversationId": "439484ef-403b-43c5-9908-884486149d0b"})
    #
    # print(json.dumps(result, indent=2))

    # # Test all endpoints
    # all_results = config_manager.test_all(context={"environment": "production"})
    # print(json.dumps(all_results, indent=2))

    content_ = [
        {
            "field_path": "payload.message",
            "extract_as": "agent_reply"
        },
        {
            "field_path": "payload.metadata",
            "extract_as": "generated_metadata"
        },
        {
            "field_path": "payload.handoffMetadata",
            "extract_as": "handoff_metadata"
        }
    ]

    mappings_ = config_manager.build_response_mapping(content=content_)
    response_data_ = config_manager.extract_response_data(
        endpoint_name="dashq",
        context={"conversationId": "439484ef-403b-43c5-9908-884486149d0b"},
        mappings=mappings_
    )

    print(f"extracted response data:\n{response_data_}")