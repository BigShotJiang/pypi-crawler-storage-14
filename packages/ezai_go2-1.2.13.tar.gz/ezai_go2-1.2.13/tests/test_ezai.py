#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
EZAI基础测试
"""

import unittest
import sys
import os

# 添加项目根目录到路径
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

class TestEZAI(unittest.TestCase):
    """EZAI基础测试类"""
    
    def test_import_camera(self):
        """测试Camera模块导入"""
        try:
            from ezai import Camera
            self.assertIsNotNone(Camera)
            print("✅ Camera模块导入成功")
        except ImportError as e:
            self.fail(f"Camera模块导入失败: {e}")
    
    def test_import_ui(self):
        """测试UI模块导入"""
        try:
            from ezai import OpenCVUI
            self.assertIsNotNone(OpenCVUI)
            print("✅ OpenCVUI模块导入成功")
        except ImportError as e:
            self.fail(f"OpenCVUI模块导入失败: {e}")
    
    def test_import_go2_optional(self):
        """测试Go2模块可选导入"""
        try:
            from ezai import Go2
            self.assertIsNotNone(Go2)
            print("✅ Go2模块导入成功")
        except ImportError:
            print("⚠️ Go2模块不可用（需要unitree-sdk2py）")
    
    def test_import_onnx_optional(self):
        """测试ONNX模块可选导入"""
        try:
            from ezai import ONNXWorkflow
            self.assertIsNotNone(ONNXWorkflow)
            print("✅ ONNXWorkflow模块导入成功")
        except ImportError:
            print("⚠️ ONNXWorkflow模块不可用（需要onnx依赖）")
    
    def test_import_rknn_optional(self):
        """测试RKNN模块可选导入"""
        try:
            from ezai import RKNNWorkflow
            self.assertIsNotNone(RKNNWorkflow)
            print("✅ RKNNWorkflow模块导入成功")
        except ImportError:
            print("⚠️ RKNNWorkflow模块不可用（需要rknn依赖）")
    
    def test_version_info(self):
        """测试版本信息"""
        from ezai import get_version, get_available_modules
        
        version = get_version()
        self.assertIsInstance(version, str)
        self.assertTrue(len(version) > 0)
        print(f"✅ 版本信息: {version}")
        
        modules = get_available_modules()
        self.assertIsInstance(modules, dict)
        print(f"✅ 模块信息: {modules}")
    
    def test_camera_creation(self):
        """测试Camera类创建"""
        from ezai import Camera
        
        try:
            camera = Camera()
            self.assertIsNotNone(camera)
            print("✅ Camera对象创建成功")
        except Exception as e:
            print(f"⚠️ Camera对象创建失败: {e}")
    
    def test_ui_creation(self):
        """测试OpenCVUI类创建"""
        from ezai import OpenCVUI
        
        try:
            ui = OpenCVUI()
            self.assertIsNotNone(ui)
            print("✅ OpenCVUI对象创建成功")
        except Exception as e:
            print(f"⚠️ OpenCVUI对象创建失败: {e}")

if __name__ == "__main__":
    print("开始EZAI测试...")
    print("=" * 50)
    
    unittest.main(verbosity=2)