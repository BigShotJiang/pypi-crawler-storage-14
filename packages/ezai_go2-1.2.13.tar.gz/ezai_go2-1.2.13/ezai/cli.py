#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
EZAI命令行工具
"""

import argparse
import sys

def print_version():
    """打印版本信息"""
    from ezai import get_version, print_info
    print(f"EZAI CLI v{get_version()}")
    print_info()

def check_modules():
    """检查模块可用性"""
    from ezai import get_available_modules
    modules = get_available_modules()
    
    print("模块状态检查:")
    print("=" * 40)
    for module, available in modules.items():
        status = "[OK] 可用" if available else "[FAIL] 不可用"
        print(f"{module:12} : {status}")
    
    # 给出安装建议
    print("\n安装建议:")
    if not modules.get('go2'):
        print("- Go2控制: 请安装 unitree-sdk2py")
    if not modules.get('onnx'):
        print("- ONNX推理: pip install ezai-go2[onnx]")
    if not modules.get('rknn'):
        print("- RKNN推理: pip install ezai-go2[rknn]")

def test_connection():
    """测试Go2连接"""
    try:
        from ezai import Go2
        print("正在测试Go2连接...")
        
        dog = Go2()
        if dog.interface:
            print(f"[OK] 网络接口: {dog.interface}")
        else:
            print("[FAIL] 未找到网络接口")
            
        # 这里可以添加更多连接测试
        print("[OK] Go2模块导入成功")
        
    except ImportError:
        print("[FAIL] Go2模块不可用，请安装 unitree-sdk2py")
    except Exception as e:
        print(f"[FAIL] 连接测试失败: {e}")

def main():
    """主函数"""
    parser = argparse.ArgumentParser(
        description="EZAI - 简单易用的AI机器人控制库命令行工具",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
示例:
  ezai --version              # 显示版本信息
  ezai --check-modules        # 检查模块状态
  ezai --test-connection      # 测试Go2连接
        """
    )
    
    parser.add_argument("--version", action="store_true", help="显示版本信息")
    parser.add_argument("--check-modules", action="store_true", help="检查模块可用性")
    parser.add_argument("--test-connection", action="store_true", help="测试Go2连接")
    
    # 如果没有参数，显示帮助
    if len(sys.argv) == 1:
        parser.print_help()
        return
    
    args = parser.parse_args()
    
    if args.version:
        print_version()
    elif args.check_modules:
        check_modules()
    elif args.test_connection:
        test_connection()

if __name__ == "__main__":
    main()