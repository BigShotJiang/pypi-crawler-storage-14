dapr uninstall
dapr init
pip install --upgrade pip
pip install mkdocs
pip install mkdocs-material
pip install "mkdocs-material[imaging]"
pip install mkdocs-jupyter
