"""Integration tests for quickstarts."""
