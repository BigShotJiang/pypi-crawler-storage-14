"""fsdata utils"""

import os

PACKAGE_NAME = "fsdata"

def make_cache_dir(name: str) -> str:
    cache_home = os.getenv("XDG_CACHE_HOME", "~/.cache")
    cache_home = os.path.expanduser(cache_home)
    return os.path.join(cache_home, PACKAGE_NAME, name)

