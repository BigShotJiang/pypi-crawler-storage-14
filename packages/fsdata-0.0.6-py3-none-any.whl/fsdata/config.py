"""fsdata configuration"""

import os
from pathlib import Path

from functools import lru_cache
from configparser import ConfigParser, Interpolation


CONFIG_FILE = "fsdata.ini"


class ExpandVars(Interpolation):
    """Interpolation which expands environment variables in values"""

    def before_read(self, parser, section, option, value):
        return os.path.expandvars(value)


@lru_cache
def read_config():
    """read configuration files"""
    config_home = os.getenv("XDG_CONFIG_HOME", "~/.config")

    file = Path(config_home, CONFIG_FILE).expanduser()

    if not file.exists():
        raise FileNotFoundError(f"Configuration file not found: {file}")

    config = ConfigParser(interpolation=ExpandVars())
    config.read(file)
    return config

