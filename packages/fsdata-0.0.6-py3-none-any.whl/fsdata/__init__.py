"""
fsdata

Collections of data files in a local or remote folder location.
Data is saved as parquet files with the extension `.parquet`

Configuration file `fsdata.ini`

Sample configuration:

[samples]
path = $HOME/samples
"""

from functools import lru_cache

from .config import read_config
from .utils import make_cache_dir
from .model import Collection


@lru_cache
def collection(name: str) -> Collection:
    """get collection by name"""
    config = read_config()
    
    try:
        section = config[name]
    except KeyError:
        raise AttributeError(f"Configuration for '{name}' not found!") from None

    path = section.get("path")
    cache_dir = make_cache_dir(name)

    return Collection(path, cache_dir=cache_dir)


def load(name: str, item:str):
    """load item from named collection"""
    col = collection(name)
    return col.load(item)    


def collections():
    """list available collection names from config"""
    config = read_config()
    return config.sections()

