"""Pydantic models for requests, responses, and entities."""
