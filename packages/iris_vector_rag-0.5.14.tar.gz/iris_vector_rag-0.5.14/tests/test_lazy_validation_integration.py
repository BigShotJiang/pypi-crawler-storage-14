"""
Full Integration Test for Lazy Validation (Feature 056)

This test demonstrates the complete lazy validation workflow:
1. Pipeline creation without database connection
2. Deferred validation on first use
3. Idempotency (validation runs once)
4. All three validation modes (True/False/"lazy")

Run: python test_lazy_validation_integration.py
"""

import time
from iris_vector_rag import create_pipeline
from iris_vector_rag.core.models import Document


def test_lazy_validation_end_to_end():
    """End-to-end integration test for lazy validation."""

    print("=" * 80)
    print("LAZY VALIDATION INTEGRATION TEST")
    print("=" * 80)

    # Test 1: Pipeline creation with lazy validation (no DB connection)
    print("\n[TEST 1] Creating pipeline with lazy validation...")
    start = time.time()

    try:
        pipeline = create_pipeline(
            pipeline_type="basic",
            validate_requirements="lazy"
        )
        creation_time = time.time() - start
        print(f"✅ Pipeline created in {creation_time:.3f}s (no database connection)")
        print(f"   - Pipeline type: {type(pipeline).__name__}")
        print(f"   - Has deferred validator: {hasattr(pipeline, '_deferred_validator')}")
        print(f"   - Validator present: {pipeline._deferred_validator is not None}")
    except Exception as e:
        print(f"❌ Pipeline creation failed: {e}")
        return False

    # Test 2: Verify deferred validator is attached
    print("\n[TEST 2] Checking deferred validator...")
    if hasattr(pipeline, '_deferred_validator') and pipeline._deferred_validator:
        validator = pipeline._deferred_validator
        print(f"✅ Deferred validator attached")
        print(f"   - Validator type: {type(validator).__name__}")
        print(f"   - Pipeline type: {validator.pipeline_type}")
        print(f"   - Already validated: {validator.is_validated}")
    else:
        print(f"❌ No deferred validator found")
        return False

    # Test 3: Verify LazyVectorStore is used
    print("\n[TEST 3] Checking vector store type...")
    print(f"   - Vector store type: {type(pipeline.vector_store).__name__}")
    if type(pipeline.vector_store).__name__ == "LazyVectorStore":
        print(f"✅ LazyVectorStore is being used (prevents immediate DB connection)")
    else:
        print(f"⚠️  Using {type(pipeline.vector_store).__name__} instead of LazyVectorStore")

    # Test 4: First database operation triggers validation
    print("\n[TEST 4] Triggering validation on first database operation...")
    print("   Calling pipeline.query('test query')...")

    start = time.time()
    try:
        result = pipeline.query("What is diabetes?")
        query_time = time.time() - start
        print(f"✅ Query executed in {query_time:.3f}s")
        print(f"   - Answer: {result['answer'][:100]}...")
        print(f"   - Documents retrieved: {len(result.get('retrieved_documents', []))}")
    except Exception as e:
        query_time = time.time() - start
        print(f"⚠️  Query failed after {query_time:.3f}s (expected without database)")
        print(f"   - Error type: {type(e).__name__}")
        print(f"   - Error message: {str(e)[:150]}...")

    # Test 5: Verify validator was removed (idempotency)
    print("\n[TEST 5] Checking idempotency (validator removed after first use)...")
    if pipeline._deferred_validator is None:
        print(f"✅ Validator removed after first use (idempotent)")
    else:
        print(f"❌ Validator still present: {pipeline._deferred_validator}")
        return False

    # Test 6: Second operation should NOT trigger validation
    print("\n[TEST 6] Second query should not re-validate...")
    start = time.time()
    try:
        result = pipeline.query("What are symptoms of diabetes?")
        query_time = time.time() - start
        print(f"✅ Second query executed in {query_time:.3f}s (no re-validation)")
    except Exception as e:
        query_time = time.time() - start
        print(f"⚠️  Second query failed after {query_time:.3f}s")
        print(f"   - Error: {str(e)[:100]}...")

    # Test 7: Test ingest() method
    print("\n[TEST 7] Testing ingest() method...")
    docs = [
        Document(page_content="Test document 1", metadata={"source": "test"}),
        Document(page_content="Test document 2", metadata={"source": "test"})
    ]
    try:
        pipeline.ingest(docs)
        print(f"✅ ingest() executed successfully")
    except Exception as e:
        print(f"⚠️  ingest() failed: {str(e)[:100]}...")

    print("\n" + "=" * 80)
    print("LAZY VALIDATION TEST COMPLETE")
    print("=" * 80)
    return True


def test_three_validation_modes():
    """Test all three validation modes."""

    print("\n" + "=" * 80)
    print("TESTING THREE VALIDATION MODES")
    print("=" * 80)

    # Mode 1: validate_requirements=True (eager validation)
    print("\n[MODE 1] validate_requirements=True (eager validation)")
    try:
        start = time.time()
        pipeline = create_pipeline("basic", validate_requirements=True)
        elapsed = time.time() - start
        print(f"✅ Eager validation succeeded in {elapsed:.3f}s")
    except Exception as e:
        elapsed = time.time() - start
        print(f"⚠️  Eager validation failed in {elapsed:.3f}s (expected without DB)")
        print(f"   - Error: {str(e)[:100]}...")

    # Mode 2: validate_requirements=False (skip validation)
    print("\n[MODE 2] validate_requirements=False (skip validation)")
    try:
        start = time.time()
        pipeline = create_pipeline("basic", validate_requirements=False)
        elapsed = time.time() - start
        print(f"✅ Skip validation mode created pipeline in {elapsed:.3f}s")
        print(f"   - Has deferred validator: {pipeline._deferred_validator is not None}")
    except Exception as e:
        elapsed = time.time() - start
        print(f"⚠️  Skip validation failed in {elapsed:.3f}s")
        print(f"   - Error: {str(e)[:100]}...")

    # Mode 3: validate_requirements="lazy" (deferred validation)
    print("\n[MODE 3] validate_requirements='lazy' (deferred validation)")
    try:
        start = time.time()
        pipeline = create_pipeline("basic", validate_requirements="lazy")
        elapsed = time.time() - start
        print(f"✅ Lazy validation created pipeline in {elapsed:.3f}s (no DB connection)")
        print(f"   - Has deferred validator: {pipeline._deferred_validator is not None}")
    except Exception as e:
        elapsed = time.time() - start
        print(f"❌ Lazy validation failed in {elapsed:.3f}s")
        print(f"   - Error: {str(e)[:100]}...")

    print("\n" + "=" * 80)
    print("VALIDATION MODES TEST COMPLETE")
    print("=" * 80)


def test_multi_query_rrf_lazy_validation():
    """Test lazy validation with MultiQueryRRFPipeline."""

    print("\n" + "=" * 80)
    print("TESTING LAZY VALIDATION WITH MULTI-QUERY RRF PIPELINE")
    print("=" * 80)

    print("\n[TEST] Creating multi_query_rrf pipeline with lazy validation...")
    try:
        start = time.time()
        pipeline = create_pipeline(
            pipeline_type="multi_query_rrf",
            validate_requirements="lazy"
        )
        elapsed = time.time() - start
        print(f"✅ Pipeline created in {elapsed:.3f}s")
        print(f"   - Pipeline type: {type(pipeline).__name__}")
        print(f"   - Has deferred validator: {pipeline._deferred_validator is not None}")

        # Try a query
        print("\n[TEST] Executing query on multi_query_rrf pipeline...")
        start = time.time()
        result = pipeline.query("What is machine learning?", top_k=5)
        elapsed = time.time() - start
        print(f"✅ Query executed in {elapsed:.3f}s")
        print(f"   - Queries generated: {len(result.get('metadata', {}).get('queries', []))}")
        print(f"   - Documents retrieved: {len(result.get('retrieved_documents', []))}")

    except Exception as e:
        elapsed = time.time() - start
        print(f"⚠️  Pipeline creation or query failed after {elapsed:.3f}s")
        print(f"   - Error: {str(e)[:150]}...")

    print("\n" + "=" * 80)
    print("MULTI-QUERY RRF TEST COMPLETE")
    print("=" * 80)


def test_parameter_validation():
    """Test parameter validation for validate_requirements."""

    print("\n" + "=" * 80)
    print("TESTING PARAMETER VALIDATION")
    print("=" * 80)

    # Test 1: Invalid type (should raise TypeError)
    print("\n[TEST 1] Invalid type (should reject)...")
    try:
        pipeline = create_pipeline("basic", validate_requirements=123)
        print(f"❌ Should have raised TypeError for integer value")
    except TypeError as e:
        print(f"✅ Correctly rejected invalid type: {str(e)[:100]}")
    except Exception as e:
        print(f"⚠️  Unexpected error: {e}")

    # Test 2: Invalid string (should raise TypeError)
    print("\n[TEST 2] Invalid string value (should reject)...")
    try:
        pipeline = create_pipeline("basic", validate_requirements="invalid")
        print(f"❌ Should have raised TypeError for invalid string")
    except TypeError as e:
        print(f"✅ Correctly rejected invalid string: {str(e)[:100]}")
    except Exception as e:
        print(f"⚠️  Unexpected error: {e}")

    # Test 3: Valid values (should accept)
    print("\n[TEST 3] Valid values (should accept)...")
    valid_values = [True, False, "lazy"]
    for val in valid_values:
        try:
            pipeline = create_pipeline("basic", validate_requirements=val)
            print(f"✅ Accepted valid value: {val}")
        except Exception as e:
            if "Pipeline" in str(e) and "not ready" in str(e):
                print(f"✅ Accepted valid value: {val} (validation failed as expected)")
            else:
                print(f"⚠️  Unexpected error for {val}: {str(e)[:100]}")

    print("\n" + "=" * 80)
    print("PARAMETER VALIDATION TEST COMPLETE")
    print("=" * 80)


if __name__ == "__main__":
    print("\n")
    print("╔" + "═" * 78 + "╗")
    print("║" + " " * 20 + "LAZY VALIDATION INTEGRATION TEST SUITE" + " " * 19 + "║")
    print("║" + " " * 25 + "Feature 056 - Full Validation" + " " * 24 + "║")
    print("╚" + "═" * 78 + "╝")

    # Run all tests
    success = True

    try:
        # Core lazy validation test
        if not test_lazy_validation_end_to_end():
            success = False

        # Three validation modes
        test_three_validation_modes()

        # Multi-query RRF pipeline
        test_multi_query_rrf_lazy_validation()

        # Parameter validation
        test_parameter_validation()

    except Exception as e:
        print(f"\n❌ INTEGRATION TEST SUITE FAILED: {e}")
        import traceback
        traceback.print_exc()
        success = False

    # Final summary
    print("\n")
    print("╔" + "═" * 78 + "╗")
    if success:
        print("║" + " " * 25 + "✅ INTEGRATION TEST PASSED" + " " * 26 + "║")
    else:
        print("║" + " " * 24 + "⚠️  INTEGRATION TEST COMPLETED" + " " * 24 + "║")
    print("╚" + "═" * 78 + "╝")
    print("\n")
