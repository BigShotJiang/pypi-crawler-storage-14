"""
Migration 001: Add raw data tracking and storage locations tables.

Adds support for:
- Tracking raw data sources used to create datasets
- Content-addressable storage (S3, local, etc.)
- Provenance tracking from raw data to final dataset
"""
import sqlite3


class Migration:
    version = 1
    description = "Add raw_data_sources and storage_locations tables"

    @staticmethod
    def upgrade(conn: sqlite3.Connection):
        """Add tables for raw data tracking and storage."""

        # Track raw data sources (PDFs, CSVs, databases, etc.)
        conn.execute("""
            CREATE TABLE IF NOT EXISTS raw_data_sources (
                workspace TEXT NOT NULL,
                name TEXT NOT NULL,
                version_hash TEXT NOT NULL,
                source_type TEXT NOT NULL,
                source_path TEXT NOT NULL,
                content_hash TEXT,
                size INTEGER,
                metadata_json TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (workspace, name, version_hash)
                    REFERENCES versions(workspace, name, version_hash)
            )
        """)

        # Index for faster queries
        conn.execute("""
            CREATE INDEX IF NOT EXISTS idx_raw_data_sources_dataset
            ON raw_data_sources(workspace, name, version_hash)
        """)

        # Track storage locations (content-addressable)
        conn.execute("""
            CREATE TABLE IF NOT EXISTS storage_locations (
                content_hash TEXT PRIMARY KEY,
                storage_backend TEXT NOT NULL,
                storage_uri TEXT NOT NULL,
                local_cache_path TEXT,
                size INTEGER,
                metadata_json TEXT,
                uploaded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)

    @staticmethod
    def downgrade(conn: sqlite3.Connection):
        """Remove raw data tracking tables."""
        conn.execute("DROP TABLE IF EXISTS raw_data_sources")
        conn.execute("DROP TABLE IF EXISTS storage_locations")
        conn.execute("DROP INDEX IF EXISTS idx_raw_data_sources_dataset")
