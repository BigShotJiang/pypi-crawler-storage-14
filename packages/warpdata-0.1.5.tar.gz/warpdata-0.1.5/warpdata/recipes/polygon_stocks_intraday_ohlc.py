"""
Polygon Stocks Intraday OHLC dataset recipe.

Downloads intraday OHLC (Open, High, Low, Close) bars for specific tickers
using Polygon's custom bars endpoint.

Supports any interval:
- 1minute, 5minute, 15minute, 30minute (intraday)
- 1hour, 2hour, 4hour (intraday)
- 1day, 1week (longer term)

Data fields per bar and ticker:
- timestamp (YYYY-MM-DD HH:MM:SS, ET - Eastern Time)
- ticker
- open
- high
- low
- close
- volume
- vwap (volume weighted average price)
- transactions (number of trades)

The recipe appends across runs and deduplicates on (timestamp, ticker).

API key:
- Reads key from env: POLYGON_API_KEY
- Requires Stocks plan (Basic, Starter, Developer, Advanced, or Business)

Plan limitations:
- Basic: 2 years history, end-of-day data
- Starter: 5 years history, 15-min delayed
- Developer: 10 years history, 15-min delayed
- Advanced: All history, real-time
- Business: All history, real-time

Example:
    >>> import warpdata as wd
    >>> # Get 1-hour bars for AAPL, TSLA (last 30 days)
    >>> result = wd.run_recipe(
    ...     "polygon_stocks_intraday_ohlc",
    ...     "warpdata://stocks/hourly-ohlc",
    ...     start_date="2024-10-01",
    ...     end_date="2024-11-05",
    ...     tickers=["AAPL", "TSLA", "MSFT"],
    ...     interval="1hour",
    ...     with_materialize=True
    ... )
"""
from pathlib import Path
from typing import List, Optional
import json
import pandas as pd
import sys
import os
from concurrent.futures import ThreadPoolExecutor, as_completed
import datetime as dt
import time

from ..api.recipes import RecipeContext
from .base import RecipeOutput


def polygon_stocks_intraday_ohlc(
    ctx: RecipeContext,
    start_date: str,
    end_date: str,
    tickers: List[str],
    *,
    interval: str = "1hour",
    polygon_api_key: Optional[str] = None,
    max_workers: int = 10,
    adjusted: bool = True,
) -> RecipeOutput:
    """
    Create Polygon Stocks Intraday OHLC dataset.

    Downloads intraday OHLC bars for specified tickers.

    Args:
        ctx: Recipe context
        start_date: Start date (YYYY-MM-DD)
        end_date: End date (YYYY-MM-DD)
        tickers: List of stock tickers (e.g., ["AAPL", "MSFT", "GOOGL"])
        interval: Bar interval (e.g., "1minute", "5minute", "1hour", "4hour", "1day")
        polygon_api_key: Polygon API key (or set POLYGON_API_KEY env var)
        max_workers: Max parallel workers (default: 10)
        adjusted: Adjust for splits (default: True)

    Returns:
        RecipeOutput with intraday OHLC data

    Examples:
        >>> import warpdata as wd
        >>> # 1-hour bars for day trading
        >>> result = wd.run_recipe(
        ...     "polygon_stocks_intraday_ohlc",
        ...     "warpdata://stocks/hourly-ohlc",
        ...     start_date="2024-10-01",
        ...     end_date="2024-11-05",
        ...     tickers=["AAPL", "TSLA", "MSFT", "GOOGL"],
        ...     interval="1hour",
        ...     with_materialize=True
        ... )
        >>> # 5-minute bars for scalping
        >>> result = wd.run_recipe(
        ...     "polygon_stocks_intraday_ohlc",
        ...     "warpdata://stocks/5min-ohlc",
        ...     start_date="2024-11-01",
        ...     end_date="2024-11-05",
        ...     tickers=["SPY", "QQQ", "IWM"],
        ...     interval="5minute",
        ...     with_materialize=True
        ... )
    """
    # Import polygon ETL
    polygon_etl_path = Path("/home/alerad/workspace/option_pricing/options_etl")
    if polygon_etl_path.exists():
        sys.path.insert(0, str(polygon_etl_path.parent))

    try:
        from options_etl.polygon_etl_module import PolygonETLAPI
    except ImportError as e:
        raise ImportError(
            f"Could not import polygon_etl_module. "
            f"Make sure /home/alerad/workspace/option_pricing is accessible"
        ) from e

    # Get API key
    api_key = polygon_api_key or os.environ.get("POLYGON_API_KEY")
    if not api_key:
        raise ValueError(
            "Polygon API key required. Set POLYGON_API_KEY env var or pass polygon_api_key parameter"
        )

    print(f"📊 Fetching Polygon Intraday OHLC Bars")
    print(f"  Date range: {start_date} to {end_date}")
    print(f"  Interval: {interval}")
    print(f"  Tickers: {len(tickers)} ({', '.join(tickers[:5])}{'...' if len(tickers) > 5 else ''})")
    print(f"  Max workers: {max_workers}")

    # Parse interval (e.g., "1hour" -> multiplier=1, timespan="hour")
    import re
    match = re.match(r'(\d+)(\w+)', interval)
    if not match:
        raise ValueError(f"Invalid interval format: {interval}. Expected format like '1hour', '5minute', '1day'")

    multiplier = int(match.group(1))
    timespan = match.group(2)

    # Validate timespan
    valid_timespans = ['second', 'minute', 'hour', 'day', 'week', 'month', 'quarter', 'year']
    if timespan not in valid_timespans:
        raise ValueError(f"Invalid timespan: {timespan}. Must be one of: {', '.join(valid_timespans)}")

    print(f"  Parsed: {multiplier} {timespan} bars")

    # Initialize Polygon ETL API
    etl = PolygonETLAPI(api_key=api_key)

    # Try to load existing data
    existing_df = None
    try:
        from ..api import load
        dataset_uri = ctx.dataset_id
        print(f"\n  🔄 Checking for existing data...")
        try:
            existing_df = load(dataset_uri, as_format="pandas")
            print(f"  ✓ Found existing dataset: {len(existing_df):,} records")
            print(f"    Date range: {existing_df['timestamp'].min()} to {existing_df['timestamp'].max()}")
        except Exception as load_err:
            print(f"  ℹ️  No existing dataset to merge: {load_err}")
    except Exception as e:
        print(f"  ⚠️  Error checking for existing data: {e}")

    # Fetch data for each ticker
    def fetch_ticker_bars(ticker: str):
        """Fetch intraday bars for a single ticker."""
        try:
            # Use Polygon REST API directly via ETL wrapper
            # Endpoint: /v2/aggs/ticker/{ticker}/range/{multiplier}/{timespan}/{from}/{to}
            url = f"https://api.polygon.io/v2/aggs/ticker/{ticker}/range/{multiplier}/{timespan}/{start_date}/{end_date}"
            params = {
                "adjusted": str(adjusted).lower(),
                "sort": "asc",
                "limit": 50000,  # Max allowed
                "apiKey": api_key
            }

            import urllib.request
            import urllib.parse

            query_string = urllib.parse.urlencode(params)
            full_url = f"{url}?{query_string}"

            req = urllib.request.Request(full_url, headers={"Accept": "application/json"})

            with urllib.request.urlopen(req, timeout=60) as resp:
                data = json.loads(resp.read())

            if data.get("status") != "OK":
                return ticker, [], f"API returned status: {data.get('status')}"

            results = data.get("results", [])
            if not results:
                return ticker, [], "No data returned"

            records = []
            for bar in results:
                # Convert timestamp from milliseconds to datetime
                ts = dt.datetime.fromtimestamp(bar['t'] / 1000, tz=dt.timezone.utc)

                record = {
                    'timestamp': ts.strftime('%Y-%m-%d %H:%M:%S'),
                    'ticker': ticker,
                    'open': bar.get('o', 0),
                    'high': bar.get('h', 0),
                    'low': bar.get('l', 0),
                    'close': bar.get('c', 0),
                    'volume': bar.get('v', 0),
                    'vwap': bar.get('vw', 0),
                    'transactions': bar.get('n', 0),
                }
                records.append(record)

            return ticker, records, None

        except Exception as e:
            return ticker, [], str(e)

    # Parallel fetch
    print(f"\n  🚀 Fetching data with {max_workers} workers...")
    all_records = []
    successful_tickers = []
    failed_tickers = []

    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        futures = {executor.submit(fetch_ticker_bars, ticker): ticker for ticker in tickers}

        completed = 0
        for future in as_completed(futures):
            ticker, records, error = future.result()
            completed += 1

            if error:
                failed_tickers.append((ticker, error))
                print(f"  [{completed}/{len(tickers)}] ❌ {ticker}: {error}")
            elif records:
                all_records.extend(records)
                successful_tickers.append(ticker)
                print(f"  [{completed}/{len(tickers)}] ✓ {ticker}: {len(records)} bars")
            else:
                failed_tickers.append((ticker, "No data"))
                print(f"  [{completed}/{len(tickers)}] ⚠️  {ticker}: No data")

    print(f"\n  📊 Summary:")
    print(f"    Successful: {len(successful_tickers)}/{len(tickers)} tickers")
    print(f"    Failed: {len(failed_tickers)}/{len(tickers)} tickers")
    if failed_tickers and len(failed_tickers) <= 10:
        for ticker, error in failed_tickers:
            print(f"      {ticker}: {error}")
    elif failed_tickers:
        print(f"    First 10 failures:")
        for ticker, error in failed_tickers[:10]:
            print(f"      {ticker}: {error}")

    if not all_records:
        if existing_df is not None and not existing_df.empty:
            print(f"\n  ⚠️  No new data collected, but returning existing data")
            output_file = ctx.work_dir / "polygon_intraday_ohlc.parquet"
            existing_df.to_parquet(output_file, index=False)
            return RecipeOutput(
                main=[output_file],
                metadata={"message": "No new data collected", "existing_records": len(existing_df)}
            )
        else:
            raise ValueError(f"No data collected for any of the {len(tickers)} tickers")

    print(f"\n  ✓ Collected {len(all_records):,} bars")

    # Create DataFrame
    df = pd.DataFrame(all_records)
    df['timestamp'] = pd.to_datetime(df['timestamp'])

    # Merge with existing data
    if existing_df is not None and not existing_df.empty:
        print(f"\n  📦 Merging with existing data...")
        existing_df['timestamp'] = pd.to_datetime(existing_df['timestamp'])
        combined_df = pd.concat([existing_df, df], ignore_index=True)
        print(f"  Combined: {len(combined_df):,} records")

        # Deduplicate
        initial_count = len(combined_df)
        combined_df = combined_df.drop_duplicates(subset=['timestamp', 'ticker'], keep='last')
        duplicates_removed = initial_count - len(combined_df)

        if duplicates_removed > 0:
            print(f"  🧹 Removed {duplicates_removed:,} duplicate records")

        df = combined_df

    # Sort by timestamp
    df = df.sort_values(['timestamp', 'ticker']).reset_index(drop=True)

    # Save to parquet
    output_file = ctx.work_dir / "polygon_intraday_ohlc.parquet"
    df.to_parquet(output_file, index=False)

    print(f"\n  ✅ Saved {len(df):,} bars")
    print(f"  📊 Date range: {df['timestamp'].min()} to {df['timestamp'].max()}")
    print(f"  🏢 Unique tickers: {df['ticker'].nunique()}")
    print(f"  📈 Total bars per ticker: ~{len(df) // df['ticker'].nunique()}")

    # Show sample
    print(f"\n  📊 Sample data:")
    print(df.head(3).to_string())

    # Generate documentation
    readme = f"""# Polygon Stocks Intraday OHLC Dataset

## Overview
Intraday OHLC bars from Polygon.io

## Configuration
- **Date Range**: {start_date} to {end_date}
- **Interval**: {interval} ({multiplier} {timespan} bars)
- **Tickers**: {len(successful_tickers)} tickers
- **Adjusted**: {adjusted}
- **Source**: Polygon.io Stocks API

## Schema

| Column | Type | Description |
|--------|------|-------------|
| timestamp | datetime | Bar timestamp (ET - Eastern Time) |
| ticker | string | Stock ticker symbol |
| open | float | Opening price |
| high | float | Highest price |
| low | float | Lowest price |
| close | float | Closing price |
| volume | int | Trading volume |
| vwap | float | Volume-weighted average price |
| transactions | int | Number of transactions |

## Usage

```python
import warpdata as wd

# Load data
df = wd.load("{ctx.dataset_id}", as_format="pandas")

# Filter specific ticker
aapl = df[df['ticker'] == 'AAPL']

# Calculate hourly returns
df['returns'] = df.groupby('ticker')['close'].pct_change()

# Intraday volatility
df['range'] = df['high'] - df['low']
df['volatility'] = (df['range'] / df['open']) * 100

# VWAP crossover strategy
df['price_above_vwap'] = df['close'] > df['vwap']

# Candlestick patterns
df['body'] = abs(df['close'] - df['open'])
df['upper_wick'] = df['high'] - df[['open', 'close']].max(axis=1)
df['lower_wick'] = df[['open', 'close']].min(axis=1) - df['low']
df['is_doji'] = df['body'] < (df['range'] * 0.1)
```

## Statistics
- Total bars: {len(df):,}
- Date range: {df['timestamp'].min()} to {df['timestamp'].max()}
- Unique tickers: {df['ticker'].nunique()}
- Interval: {interval}
- Successful tickers: {len(successful_tickers)}

## Tickers Included
{', '.join(sorted(successful_tickers))}
"""

    metadata = {
        "start_date": start_date,
        "end_date": end_date,
        "interval": interval,
        "multiplier": multiplier,
        "timespan": timespan,
        "tickers": len(successful_tickers),
        "successful_tickers": successful_tickers,
        "failed_tickers": [t for t, _ in failed_tickers],
        "records": len(df),
        "source": "Polygon.io Stocks API",
    }

    return RecipeOutput(
        main=[output_file],
        docs={"README.md": readme},
        metadata=metadata,
    )
