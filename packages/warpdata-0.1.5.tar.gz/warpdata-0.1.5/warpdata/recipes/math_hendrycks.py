"""
Hendrycks MATH benchmark recipe (parquet mirror).

Uses parquet files from HF dataset: nlile/hendrycks-MATH-benchmark
  - data/train-00000-of-00001.parquet
  - data/test-00000-of-00001.parquet

Schema:
  - problem: str
  - solution: str
  - answer: str
  - subject: str
  - level: int
  - unique_id: str
  - split: str (train|test)
"""
from __future__ import annotations

import pandas as pd
from ..api.recipes import RecipeContext
from .base import RecipeOutput
from ..engine.duck import get_engine


def _load_split(ctx: RecipeContext, split: str) -> pd.DataFrame:
    uri = f"hf://datasets/nlile/hendrycks-MATH-benchmark/data/{split}-00000-of-00001.parquet"
    local = ctx.download(uri)
    rel = get_engine().read_file(str(local), file_format="parquet")
    df = rel.df()
    df["split"] = split
    # ensure dtypes as strings for problem/solution/answer/subject and int for level where possible
    for col in ["problem", "solution", "answer", "subject", "unique_id"]:
        df[col] = df[col].astype(str)
    try:
        df["level"] = df["level"].astype(int)
    except Exception:
        pass
    return df[["problem", "solution", "answer", "subject", "level", "unique_id", "split"]]


def math_hendrycks(
    ctx: RecipeContext,
    include_splits=("train", "test"),
) -> RecipeOutput:
    parts = []
    for split in include_splits:
        try:
            parts.append(_load_split(ctx, split))
        except Exception as e:
            print(f"Warning: failed to load {split}: {e}")
    if not parts:
        raise RuntimeError("No splits loaded for hendrycks-MATH")

    df = pd.concat(parts, ignore_index=True)
    out_path = ctx.work_dir / "math_hendrycks.parquet"
    df.to_parquet(out_path, index=False)

    notes = f"""# Hendrycks MATH benchmark

Source: nlile/hendrycks-MATH-benchmark
Splits: {', '.join(include_splits)}
Rows: {len(df)}

Columns: problem, solution, answer, subject, level, unique_id, split
"""

    return RecipeOutput(
        main=[out_path],
        metadata={
            "source": "nlile/hendrycks-MATH-benchmark",
            "splits": {s: int((df["split"] == s).sum()) for s in df["split"].unique()},
            "total_rows": int(len(df)),
        },
        docs={"notes.md": notes},
    )

