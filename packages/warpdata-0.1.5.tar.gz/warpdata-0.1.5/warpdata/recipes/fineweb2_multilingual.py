"""
FineWeb-2 multilingual web text recipe.

This recipe samples from the HuggingFaceFW/fineweb-2 dataset, which
contains filtered web text for ~1.8k language–script pairs.

Goal:
    - Support the common `--limit` CLI flag as a *global* cap on the
      number of examples (document-count mode).
    - Optionally accept a `target_gb` budget to cap approximate text
      size in gigabytes, splitting that byte budget across languages.
    - Split budgets (docs or bytes) across multiple language-script
      subsets, either uniformly or using simple user-provided weights.

Dataset card (schema summary):
    - text: str
    - id: str
    - dump: str
    - url: str
    - date: str
    - file_path: str
    - language: str          (ISO 639-3, e.g. "rus")
    - language_score: float
    - language_script: str   (e.g. "Cyrl")
    - minhash_cluster_size: int
    - top_langs: str (JSON-like summary)

This recipe keeps the most useful columns for pretraining:
    text, id, dump, url, date, file_path,
    language, language_score, language_script,
    minhash_cluster_size, top_langs
"""
from __future__ import annotations

from typing import Dict, List, Optional, Any, Tuple
from pathlib import Path

import pandas as pd
import pyarrow as pa
import pyarrow.parquet as pq
from datasets import load_dataset

from ..api.recipes import RecipeContext
from .base import RecipeOutput


# A small default set of high-resource language-script subsets.
# Users can override this via the `subsets` parameter.
DEFAULT_SUBSETS: List[str] = [
    # Indo-European (Latin / Cyrillic)
    "rus_Cyrl",  # Russian
    "deu_Latn",  # German
    "spa_Latn",  # Spanish
    "fra_Latn",  # French
    "ita_Latn",  # Italian
    "por_Latn",  # Portuguese
    "pol_Latn",  # Polish
    "nld_Latn",  # Dutch
    "tur_Latn",  # Turkish
    "hin_Deva",  # Hindi
    # Major non‑IE languages
    "cmn_Hani",  # Mandarin Chinese
    "jpn_Jpan",  # Japanese
    "kor_Hang",  # Korean
    "arb_Arab",  # Standard Arabic
]


WRITE_CHUNK_SIZE = 50_000


def _compute_targets(
    total_units: int,
    subsets: List[str],
    weights: Optional[Dict[str, float]] = None,
) -> Dict[str, int]:
    """
    Compute target units per subset given a global budget.

    If `weights` is None, allocate uniformly across subsets.
    Otherwise, weights are normalized and used proportionally.
    """
    if total_units <= 0:
        raise ValueError("total_units must be positive")

    if not subsets:
        raise ValueError("subsets list must not be empty")

    if weights is None:
        # Uniform allocation
        base = total_units // len(subsets)
        remainder = total_units % len(subsets)
        targets: Dict[str, int] = {}
        for i, subset in enumerate(subsets):
            extra = 1 if i < remainder else 0
            targets[subset] = base + extra
        return targets

    # Proportional allocation
    total_w = sum(max(float(w), 0.0) for w in weights.values())
    if total_w <= 0:
        raise ValueError("All weights are zero or negative; cannot allocate budget.")

    # First pass: floor allocations
    targets: Dict[str, int] = {}
    used = 0
    for subset in subsets:
        w = max(float(weights.get(subset, 0.0)), 0.0)
        if w == 0.0:
            continue
        tgt = int(total_units * w / total_w)
        if tgt > 0:
            targets[subset] = tgt
            used += tgt

    # Distribute any remaining budget one-by-one in order of weight.
    remaining = total_units - used
    if remaining > 0:
        # Sort subsets by weight descending
        ordered = sorted(subsets, key=lambda s: weights.get(s, 0.0), reverse=True)
        idx = 0
        while remaining > 0 and ordered:
            s = ordered[idx % len(ordered)]
            if weights.get(s, 0.0) <= 0.0:
                idx += 1
                continue
            targets[s] = targets.get(s, 0) + 1
            remaining -= 1
            idx += 1

    return targets


def fineweb2_multilingual(
    ctx: RecipeContext,
    repo_id: str = "HuggingFaceFW/fineweb-2",
    subsets: Optional[List[str]] = None,
    limit: Optional[int] = None,
    target_gb: Optional[float] = None,
    weights: Optional[Dict[str, float]] = None,
) -> RecipeOutput:
    """
    Sample a multilingual mix from FineWeb-2 with a global budget.

    Args:
        ctx: Recipe context.
        repo_id: HF dataset ID (default: 'HuggingFaceFW/fineweb-2').
        subsets: List of language-script subsets to include
            (e.g., ['rus_Cyrl', 'deu_Latn', 'jpn_Jpan']). If None,
            a small default set of major languages is used.
        limit: Global cap on number of examples (wired to CLI --limit).
            Examples are split across subsets according to `weights`
            (if provided) or uniformly. Mutually exclusive with
            `target_gb`.
        target_gb: Approximate global cap on text size in gigabytes.
            When provided (and `limit` is None), the recipe uses
            streaming and tracks the number of UTF-8 bytes in `text`
            per subset, splitting the total byte budget across subsets
            according to `weights` (if provided) or uniformly.
        weights: Optional dict subset -> weight. If provided, it does
            NOT need to sum to 1; values are normalized internally.
            When omitted, subsets receive equal budgets.

    Returns:
        RecipeOutput with a single Parquet file.

    Notes:
        - FineWeb-2 excludes English; for English, use the original
          HuggingFaceFW/fineweb recipe.
        - This recipe uses streaming I/O for each subset to avoid
          loading entire subsets into memory.
    """
    if subsets is None:
        subsets = list(DEFAULT_SUBSETS)

    print(f"Loading FineWeb-2 from {repo_id}")
    print(f"  Subsets: {subsets}")
    if limit is not None and target_gb is not None:
        raise ValueError("Specify only one of limit (examples) or target_gb (GB), not both.")

    use_bytes_budget = target_gb is not None

    if use_bytes_budget:
        if target_gb is None or target_gb <= 0:
            raise ValueError("target_gb must be positive when provided.")
        total_bytes = int(target_gb * (1024**3))
        print(f"Global byte budget: ~{target_gb:.2f} GB ({total_bytes:,} bytes)")
        targets = _compute_targets(total_bytes, subsets, weights=weights)
        for subset, tgt_bytes in targets.items():
            print(f"  Target {subset}: ~{tgt_bytes / (1024**3):.2f} GB ({tgt_bytes:,} bytes)")
    else:
        if limit is None:
            raise ValueError(
                "fineweb2_multilingual requires a global --limit (number of examples) "
                "or target_gb (approximate GB of text). "
                "Pass --limit N on the CLI or target_gb=<float> via -p."
            )
        print(f"Global limit: {limit:,} examples")
        targets = _compute_targets(limit, subsets, weights=weights)
        for subset, tgt in targets.items():
            print(f"  Target {subset}: {tgt:,} examples")

    # Set up streaming Parquet writer so we don't keep all records in memory.
    out_path = ctx.work_dir / "fineweb2_multilingual.parquet"
    writer: Optional[pq.ParquetWriter] = None
    buffer: List[Dict[str, Any]] = []
    total_examples = 0

    for subset in subsets:
        target = targets.get(subset, 0)
        if target <= 0:
            print(f"  Skipping {subset} (target=0)")
            continue
        if use_bytes_budget:
            subset_target_bytes = target
            subset_target_gb = subset_target_bytes / (1024**3)
            print(
                f"\nSampling until ~{subset_target_gb:.2f} GB of text "
                f"from subset '{subset}'..."
            )
        else:
            print(f"\nSampling {target:,} examples from subset '{subset}'...")
        ds = load_dataset(repo_id, subset, split="train", streaming=True)

        count = 0
        bytes_accum = 0
        checkpoints: List[int] = []
        checkpoint_idx = 0
        if use_bytes_budget and subset_target_bytes > 0:
            # 4 checkpoints: 25%, 50%, 75%, 100% of the subset byte budget
            checkpoints = [
                int(subset_target_bytes * frac) for frac in (0.25, 0.5, 0.75, 1.0)
            ]

        for example in ds:
            if not use_bytes_budget and count >= target:
                break

            record = {
                "text": str(example.get("text", "")),
                "id": str(example.get("id", "")),
                "dump": str(example.get("dump", "")),
                "url": str(example.get("url", "")),
                "date": str(example.get("date", "")),
                "file_path": str(example.get("file_path", "")),
                "language": str(example.get("language", "")),
                "language_score": float(example.get("language_score", 0.0))
                if example.get("language_score") is not None
                else None,
                "language_script": str(example.get("language_script", "")),
                "minhash_cluster_size": int(example.get("minhash_cluster_size", 0))
                if example.get("minhash_cluster_size") is not None
                else None,
                "top_langs": str(example.get("top_langs", "")),
            }
            # Approximate bytes for this record (text only) in UTF-8
            text_bytes = len(record["text"].encode("utf-8", errors="ignore"))

            if use_bytes_budget:
                bytes_accum += text_bytes
                count += 1
            else:
                count += 1
            buffer.append(record)
            total_examples += 1

            if use_bytes_budget:
                # Per-language progress logs at ~25/50/75/100% of byte budget
                while checkpoints and checkpoint_idx < len(checkpoints) and bytes_accum >= checkpoints[checkpoint_idx]:
                    frac = (checkpoint_idx + 1) * 25
                    print(
                        f"    {subset}: reached ~{frac}% of byte budget "
                        f"({bytes_accum / (1024**3):.2f} GB, {count:,} docs)"
                    )
                    checkpoint_idx += 1

                # Stop once we've hit the subset's byte budget
                if bytes_accum >= subset_target_bytes:
                    print(
                        f"  Reached byte budget for {subset}: "
                        f"{bytes_accum / (1024**3):.2f} GB, {count:,} docs"
                    )
                    # Flush remaining buffered records for this subset before breaking.
                    if buffer:
                        df_chunk = pd.DataFrame(buffer)
                        table = pa.Table.from_pandas(df_chunk, preserve_index=False)
                        if writer is None:
                            writer = pq.ParquetWriter(out_path, table.schema)
                        writer.write_table(table)
                        buffer.clear()
                    break
            else:
                if count % 100_000 == 0:
                    print(f"    {subset}: {count:,} examples collected...")

            # Flush to disk periodically to keep memory bounded.
            if len(buffer) >= WRITE_CHUNK_SIZE:
                df_chunk = pd.DataFrame(buffer)
                table = pa.Table.from_pandas(df_chunk, preserve_index=False)
                if writer is None:
                    writer = pq.ParquetWriter(out_path, table.schema)
                writer.write_table(table)
                buffer.clear()

        if not use_bytes_budget:
            print(f"  Finished {subset}: {count:,} examples")

    # Flush any remaining buffered records
    if buffer:
        df_chunk = pd.DataFrame(buffer)
        table = pa.Table.from_pandas(df_chunk, preserve_index=False)
        if writer is None:
            writer = pq.ParquetWriter(out_path, table.schema)
        writer.write_table(table)
        buffer.clear()

    if writer is not None:
        writer.close()

    print(f"\nTotal examples collected (all subsets): {total_examples:,}")
    print(f"Saved to {out_path}")

    # Provenance: HF cache root
    raw_data_paths = []
    hf_cache = Path.home() / ".cache" / "huggingface" / "datasets" / repo_id.replace("/", "___")
    if hf_cache.exists():
        raw_data_paths.append(hf_cache)

    return RecipeOutput(
        main=[out_path],
        metadata={
            "total_examples": total_examples,
            "repo_id": repo_id,
            "subsets": subsets,
            "limit": limit,
            "target_gb": target_gb,
        },
        raw_data=raw_data_paths,
    )
