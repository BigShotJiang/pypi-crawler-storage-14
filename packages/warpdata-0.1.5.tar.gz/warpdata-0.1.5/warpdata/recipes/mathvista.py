"""
MathVista dataset recipe.

MathVista is a benchmark for evaluating mathematical reasoning in visual contexts.
It contains diverse math problems paired with images (diagrams, charts, plots, etc.).

Source: https://huggingface.co/datasets/AI4Math/MathVista
Paper: https://arxiv.org/abs/2310.02255

Splits:
- testmini: 1,000 examples (mini test set)
- test: 5,141 examples (full test set)

Question types: free-form and multiple-choice
Answer types: integer, float, list, text
Categories: geometry, algebra, statistics, etc.
"""
from pathlib import Path
from typing import Tuple
import pandas as pd
import json

from datasets import load_dataset

from ..api.recipes import RecipeContext
from .base import RecipeOutput


def mathvista(
    ctx: RecipeContext,
    repo_id: str = "AI4Math/MathVista",
    splits: Tuple[str, ...] = ("testmini", "test"),
) -> RecipeOutput:
    """
    Create MathVista visual mathematical reasoning dataset.

    Downloads MathVista from HuggingFace. Each example contains a math question,
    an associated image, and annotations about question/answer types.

    Args:
        ctx: Recipe context
        repo_id: HuggingFace repo ID
        splits: Which splits to include ("testmini", "test")

    Returns:
        RecipeOutput with single dataset

    Dataset columns:
        - pid: str - Problem ID
        - question: str - The math question
        - image: str - Image path/reference
        - choices: str - Multiple choice options (if applicable)
        - unit: str - Unit of measurement (if applicable)
        - precision: str - Required precision for answer
        - answer: str - Ground truth answer
        - question_type: str - Type of question (free_form, multiple_choice)
        - answer_type: str - Type of answer (integer, float, list, text)
        - metadata: str - Additional metadata (category, context, grade level, etc.)
        - query: str - Full query with hints
        - split: str - testmini/test

    Examples:
        >>> import warpdata as wd
        >>> result = wd.run_recipe(
        ...     "mathvista",
        ...     "warpdata://math/mathvista",
        ...     with_materialize=True
        ... )
        >>> df = wd.load("warpdata://math/mathvista", as_format="pandas")
        >>> # Filter by question type
        >>> free_form = df[df['question_type'] == 'free_form']
    """
    print(f"Loading MathVista from {repo_id}...")

    # Load all requested splits
    all_records = []

    for split_name in splits:
        print(f"  Loading {split_name} split...")
        ds = load_dataset(repo_id, split=split_name)

        print(f"  Processing {len(ds):,} examples...")

        for example in ds:
            # Convert metadata dict to JSON string if it's a dict
            metadata = example.get('metadata', '')
            if isinstance(metadata, dict):
                metadata = json.dumps(metadata)

            record = {
                'pid': str(example.get('pid', '')),
                'question': str(example.get('question', '')),
                'image': str(example.get('image', '')),
                'choices': str(example.get('choices', '')),
                'unit': str(example.get('unit', '')),
                'precision': str(example.get('precision', '')),
                'answer': str(example.get('answer', '')),
                'question_type': str(example.get('question_type', '')),
                'answer_type': str(example.get('answer_type', '')),
                'metadata': metadata,
                'query': str(example.get('query', '')),
                'split': split_name,
            }

            all_records.append(record)

    print(f"\nTotal examples: {len(all_records):,}")

    # Create DataFrame
    df = pd.DataFrame(all_records)

    # Write to output
    output_path = ctx.work_dir / "mathvista.parquet"
    df.to_parquet(output_path, index=False)

    print(f"Saved to {output_path}")
    print(f"\nSplit distribution:")
    print(df['split'].value_counts().to_string())
    print(f"\nQuestion type distribution:")
    print(df['question_type'].value_counts().to_string())
    print(f"\nAnswer type distribution:")
    print(df['answer_type'].value_counts().to_string())

    # Track raw data provenance
    raw_data_paths = []
    hf_cache = Path.home() / ".cache" / "huggingface" / "datasets" / repo_id.replace("/", "___")
    if hf_cache.exists():
        raw_data_paths.append(hf_cache)

    return RecipeOutput(
        main=[output_path],
        metadata={
            'total_examples': len(df),
            'splits': df['split'].value_counts().to_dict(),
            'question_types': df['question_type'].value_counts().to_dict(),
            'answer_types': df['answer_type'].value_counts().to_dict(),
            'source': repo_id,
        },
        raw_data=raw_data_paths,
    )
