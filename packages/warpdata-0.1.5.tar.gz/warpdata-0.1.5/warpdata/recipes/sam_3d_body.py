"""
Recipe for facebook/sam-3d-body-dataset from Hugging Face

Downloads SAM (Segment Anything Model) 3D body pose dataset.
Dataset contains multiple subsets with 3D body poses and meshes.

Subsets (12 total):
  - sa1b_train: 1,850 files (~11 GB) - Largest subset
  - egoexo4d_physical_train: 400 files (~2.4 GB)
  - egoexo4d_procedure_train: 200 files (~1.2 GB)
  - harmony4d_train: 200 files (~1.2 GB)
  - aic_train: 173 files (~1 GB)
  - egohumans_train: 125 files (~0.7 GB)
  - coco_train: 24 files (~0.14 GB)
  - 3dpw_train: 18 files (~0.11 GB)
  - ... and 4 more test sets

Usage:
    # Download sa1b (largest, 11GB)
    wd.run_recipe("sam_3d_body", "warpdata://vision/sam-3d-body-sa1b",
                  subsets=["sa1b_train"])

    # Download multiple subsets (~15GB total)
    wd.run_recipe("sam_3d_body", "warpdata://vision/sam-3d-body-15gb",
                  subsets=["sa1b_train", "egoexo4d_physical_train",
                          "egoexo4d_procedure_train"])

    # Download all (~18GB)
    wd.run_recipe("sam_3d_body", "warpdata://vision/sam-3d-body-full")

Parameters:
    subsets: list of str or None
        Which subsets to download (default: ["sa1b_train", "egoexo4d_physical_train"]
        for ~13.4GB). None = download all subsets (~18GB).

    limit_per_subset: int or None
        Max files per subset (for testing). None = all files.
"""
from pathlib import Path
from typing import Optional, List
from huggingface_hub import hf_hub_download, HfApi
import pyarrow.parquet as pq

from ..api.recipes import RecipeContext
from ..recipes.base import RecipeOutput


# Subset sizes (approximate, files × ~6MB each)
SUBSET_INFO = {
    "sa1b_train": (1850, 11.0),              # 11 GB
    "egoexo4d_physical_train": (400, 2.38),  # 2.4 GB
    "egoexo4d_procedure_train": (200, 1.19), # 1.2 GB
    "harmony4d_train": (200, 1.19),          # 1.2 GB
    "aic_train": (173, 1.03),                # 1.0 GB
    "egohumans_train": (125, 0.74),          # 0.7 GB
    "coco_train": (24, 0.14),                # 0.1 GB
    "3dpw_train": (18, 0.11),                # 0.1 GB
    "egoexo4d_physical_test": (10, 0.06),    # Test sets
    "egoexo4d_procedure_test": (10, 0.06),
    "harmony4d_test": (6, 0.04),
    "mpii_train": (6, 0.04),
}


def sam_3d_body(
    ctx: RecipeContext,
    subsets: Optional[List[str]] = None,
    limit_per_subset: Optional[int] = None,
) -> RecipeOutput:
    """
    Download SAM 3D body dataset from Hugging Face.

    Args:
        ctx: Recipe context
        subsets: List of subset names to download. Default: ["sa1b_train",
                 "egoexo4d_physical_train"] (~13.4 GB). None = all subsets.
        limit_per_subset: Max files per subset (for testing). None = all files.

    Returns:
        RecipeOutput with main dataset
    """
    repo_id = "facebook/sam-3d-body-dataset"

    # Default: download two largest subsets for ~13GB
    if subsets is None:
        subsets = ["sa1b_train", "egoexo4d_physical_train"]

    # Validate subsets
    for subset in subsets:
        if subset not in SUBSET_INFO:
            raise ValueError(f"Unknown subset: {subset}. Available: {list(SUBSET_INFO.keys())}")

    # Calculate total size
    total_files = 0
    total_size_gb = 0.0
    for subset in subsets:
        files, size = SUBSET_INFO[subset]
        if limit_per_subset:
            files = min(files, limit_per_subset)
        total_files += files
        total_size_gb += (files / SUBSET_INFO[subset][0]) * size  # Proportional size

    print(f"📊 SAM 3D Body Dataset Download")
    print(f"   Source: {repo_id}")
    print(f"   Subsets: {len(subsets)}")
    for subset in subsets:
        files, size = SUBSET_INFO[subset]
        if limit_per_subset:
            files = min(files, limit_per_subset)
            size = (files / SUBSET_INFO[subset][0]) * size
        print(f"     - {subset}: {files} files (~{size:.1f} GB)")
    print(f"   Total: {total_files:,} files (~{total_size_gb:.1f} GB)")
    if limit_per_subset:
        print(f"   Limit per subset: {limit_per_subset} files")
    print()

    # Get actual file list from HuggingFace
    print("📋 Fetching file list from HuggingFace...")
    api = HfApi()
    all_files = api.list_repo_files(repo_id, repo_type="dataset")
    parquet_files = [f for f in all_files if f.endswith('.parquet')]

    # Filter by requested subsets
    files_to_download = []
    for subset in subsets:
        subset_files = [f for f in parquet_files if f.startswith(f"data/{subset}/")]

        if limit_per_subset:
            subset_files = subset_files[:limit_per_subset]

        files_to_download.extend(subset_files)

    print(f"✓ Found {len(files_to_download):,} files to download")
    print()

    # Create work directory
    work_dir = ctx.work_dir / "sam_3d_body"
    work_dir.mkdir(parents=True, exist_ok=True)

    # Download files
    downloaded_files = []
    print(f"📥 Downloading files...")

    for i, filename in enumerate(files_to_download):
        try:
            local_path = hf_hub_download(
                repo_id=repo_id,
                filename=filename,
                repo_type="dataset",
                cache_dir=str(work_dir / "hf_cache")
            )

            downloaded_files.append(local_path)

            # Progress update every 100 files
            if (i + 1) % 100 == 0:
                progress = (i + 1) / len(files_to_download) * 100
                print(f"  [{i + 1:,}/{len(files_to_download):,}] {progress:.1f}% - {filename}")

        except Exception as e:
            print(f"  ⚠️  Failed to download {filename}: {e}")
            continue

    print(f"✓ Downloaded {len(downloaded_files):,} files")

    if not downloaded_files:
        raise RuntimeError("No files downloaded successfully")

    # Merge all parquet files
    print(f"\n🔄 Merging parquet files...")

    output_file = work_dir / "sam_3d_body.parquet"
    writer = None
    total_rows = 0
    merged_files = 0
    for i, file_path in enumerate(downloaded_files):
        try:
            table = pq.read_table(file_path)
            if writer is None:
                writer = pq.ParquetWriter(output_file, table.schema)
            writer.write_table(table)
            total_rows += table.num_rows
            merged_files += 1

            if (i + 1) % 500 == 0:
                print(f"  Merged {i + 1:,}/{len(downloaded_files):,} files... ({total_rows:,} rows)")
        except Exception as e:
            print(f"  ⚠️  Failed to read {file_path}: {e}")
            continue

    if writer is None or merged_files == 0:
        raise RuntimeError("No files loaded successfully")

    writer.close()

    print(f"✓ Merged dataset: {total_rows:,} rows")
    print(f"\n💾 Saved to {output_file}...")
    file_size_mb = output_file.stat().st_size / (1024**2)
    print(f"✓ Saved: {file_size_mb:.2f} MB")

    print(f"\n✅ Dataset complete")
    print(f"   Rows: {total_rows:,}")
    print(f"   Size: {file_size_mb:.2f} MB")
    print(f"   Subsets: {', '.join(subsets)}")

    return RecipeOutput(
        main=[output_file],
        metadata={
            "source": "huggingface",
            "repo_id": repo_id,
            "subsets": subsets,
            "files_downloaded": len(downloaded_files),
            "rows": total_rows,
            "size_mb": file_size_mb,
        }
    )
