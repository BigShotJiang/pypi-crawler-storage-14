"""
CoinGecko Safe Pools - COMPLETE DATA from megafilter.

Downloads ALL available pool data including:
- Token info (base & quote)
- Prices (USD, native, quote/base)
- Market cap & FDV
- Volumes (m5, m15, m30, h1, h6, h24)
- Transactions (buys, sells, buyers, sellers)
- Price changes (m5, m15, m30, h1, h6, h24)
- Reserves & liquidity
- Pool creation date
- DEX info

Safety filters:
- no_honeypot, good_gt_score, on_coingecko, has_social

API key:
- Requires CoinGecko Pro API key (Analyst plan or above)

Example:
    >>> import warpdata as wd
    >>> result = wd.run_recipe(
    ...     "coingecko_pools_safe_full",
    ...     "warpdata://crypto/coingecko/pools_safe_full",
    ...     network="eth",
    ...     top_n=100,
    ...     with_materialize=True
    ... )
"""
from __future__ import annotations

import os
import time
import threading
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

import pandas as pd

from ..api.recipes import RecipeContext
from .base import RecipeOutput


PRO_API_BASE = "https://pro-api.coingecko.com/api/v3"

_REQ_LOCK = threading.Lock()
_LAST_REQ_TS = 0.0
_MIN_INTERVAL_ENV = float(os.environ.get('COINGECKO_MIN_INTERVAL', '0')) if os.environ.get('COINGECKO_MIN_INTERVAL') else None


def _http_get_json(url: str, params: Optional[Dict[str, Any]] = None, *, api_key: Optional[str] = None, timeout: float = 30.0) -> Dict[str, Any]:
    import urllib.request
    import urllib.parse
    import json

    qs = urllib.parse.urlencode(params or {})
    full = f"{url}?{qs}" if qs else url

    headers = {
        "Accept": "application/json",
        "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
    }
    if api_key:
        headers["x-cg-pro-api-key"] = api_key

    req = urllib.request.Request(full, headers=headers, method="GET")

    global _LAST_REQ_TS
    with _REQ_LOCK:
        default_interval = 0.15 if api_key else 1.5
        min_interval = max(_MIN_INTERVAL_ENV or 0.0, default_interval)
        now = time.time()
        wait = _LAST_REQ_TS + min_interval - now
        if wait > 0:
            time.sleep(wait)
        _LAST_REQ_TS = time.time()

    backoff = 0.5
    for attempt in range(5):
        try:
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                data = resp.read()
                return json.loads(data)
        except Exception as e:
            import urllib.error
            if isinstance(e, urllib.error.HTTPError):
                code = e.code
                body = e.read().decode("utf-8", errors="replace") if hasattr(e, "read") else ""

                if code in (429, 403) or 500 <= code < 600:
                    if attempt < 4:
                        time.sleep(backoff)
                        backoff *= 2
                        continue
                    raise RuntimeError(f"HTTP {code} for {full} :: {body}")

                raise RuntimeError(f"HTTP {code} for {full} :: {body}")

            if attempt == 4:
                raise
    raise RuntimeError(f"Failed to fetch {full}")


def _safe_float(value, default=None):
    """Safely convert to float."""
    if value is None:
        return default
    try:
        return float(value)
    except (ValueError, TypeError):
        return default


def coingecko_pools_safe_full(
    ctx: RecipeContext,
    network: str,
    *,
    top_n: int = 100,
    dex: Optional[str] = None,
    api_key: Optional[str] = None,
) -> RecipeOutput:
    """
    Create complete safe pools dataset with ALL available data.

    Fetches ALL fields from megafilter endpoint:
    - Token info (base & quote, names, symbols, decimals, images)
    - Prices (USD, native currency, quote/base ratios)
    - Market data (market cap, FDV)
    - Volumes (5m, 15m, 30m, 1h, 6h, 24h)
    - Transactions (buys, sells, buyers, sellers for all timeframes)
    - Price changes (all timeframes)
    - Reserves & liquidity
    - Pool metadata (creation date, address, name)
    - DEX info

    Args:
        ctx: Recipe context
        network: Network ID (eth, bsc, polygon_pos, arbitrum, base, etc.)
        top_n: Number of pools to fetch (default: 100)
        dex: Optional DEX filter
        api_key: CoinGecko Pro API key (Analyst plan or above)

    Returns:
        RecipeOutput with complete pool data

    Examples:
        >>> import warpdata as wd
        >>> # Get top 100 safe pools with ALL data
        >>> result = wd.run_recipe(
        ...     "coingecko_pools_safe_full",
        ...     "warpdata://crypto/coingecko/pools_safe_full",
        ...     network="eth",
        ...     top_n=100,
        ...     with_materialize=True
        ... )
    """
    api_key = api_key or os.environ.get("COINGECKO_API_KEY")

    if not api_key:
        raise ValueError("CoinGecko Pro API key required (Analyst plan or above).")

    print(f"📊 Fetching Complete Safe Pools Data")
    print(f"  Network: {network}")
    print(f"  Top N: {top_n}")
    if dex:
        print(f"  DEX filter: {dex}")
    print(f"\n  🔒 Safety Filters:")
    print(f"     ✅ No honeypot tokens")
    print(f"     ✅ Good GT Score (>= 75)")
    print(f"     ✅ Listed on CoinGecko")
    print(f"     ✅ Has social links")

    url = f"{PRO_API_BASE}/onchain/pools/megafilter"

    params = {
        "networks": network,
        "checks": "no_honeypot,good_gt_score,on_coingecko,has_social",
        "include": "base_token,quote_token,dex",
    }

    if dex:
        params["dexes"] = dex

    all_pools = []
    page = 1
    max_pages = (top_n + 19) // 20  # 20 pools per page

    print(f"\n  🔄 Fetching pools...")

    while page <= max_pages and len(all_pools) < top_n:
        params["page"] = page

        try:
            response = _http_get_json(url, params, api_key=api_key)
            pools = response.get("data", [])
            included = response.get("included", [])

            if not pools:
                break

            # Build lookups
            tokens = {}
            dexes = {}
            for item in included:
                if item.get("type") == "token":
                    tokens[item["id"]] = item.get("attributes", {})
                elif item.get("type") == "dex":
                    dexes[item["id"]] = item.get("attributes", {})

            # Process all pools
            for pool in pools:
                attrs = pool.get("attributes", {})
                rels = pool.get("relationships", {})

                # Get token info
                base_token_id = rels.get("base_token", {}).get("data", {}).get("id")
                quote_token_id = rels.get("quote_token", {}).get("data", {}).get("id")
                dex_id = rels.get("dex", {}).get("data", {}).get("id")

                base_token = tokens.get(base_token_id, {})
                quote_token = tokens.get(quote_token_id, {})
                dex_info = dexes.get(dex_id, {})

                # Parse transactions
                txns = attrs.get("transactions", {})
                txns_m5 = txns.get("m5", {})
                txns_m15 = txns.get("m15", {})
                txns_m30 = txns.get("m30", {})
                txns_h1 = txns.get("h1", {})
                txns_h24 = txns.get("h24", {})

                # Parse volumes
                volumes = attrs.get("volume_usd", {})

                # Parse price changes
                price_changes = attrs.get("price_change_percentage", {})

                # Build complete record
                record = {
                    # Metadata
                    "fetched_at": datetime.now(timezone.utc).isoformat(),
                    "network": network,
                    "pool_id": pool.get("id"),
                    "pool_address": attrs.get("address"),
                    "pool_name": attrs.get("name"),
                    "pool_created_at": attrs.get("pool_created_at"),

                    # DEX
                    "dex_id": dex_id,
                    "dex_name": dex_info.get("name"),

                    # Base Token
                    "base_token_address": base_token.get("address"),
                    "base_token_symbol": base_token.get("symbol"),
                    "base_token_name": base_token.get("name"),
                    "base_token_decimals": base_token.get("decimals"),
                    "base_token_image_url": base_token.get("image_url"),
                    "base_token_coingecko_id": base_token.get("coingecko_coin_id"),

                    # Quote Token
                    "quote_token_address": quote_token.get("address"),
                    "quote_token_symbol": quote_token.get("symbol"),
                    "quote_token_name": quote_token.get("name"),
                    "quote_token_decimals": quote_token.get("decimals"),
                    "quote_token_image_url": quote_token.get("image_url"),
                    "quote_token_coingecko_id": quote_token.get("coingecko_coin_id"),

                    # Prices
                    "base_token_price_usd": _safe_float(attrs.get("base_token_price_usd")),
                    "base_token_price_native": _safe_float(attrs.get("base_token_price_native_currency")),
                    "quote_token_price_usd": _safe_float(attrs.get("quote_token_price_usd")),
                    "quote_token_price_native": _safe_float(attrs.get("quote_token_price_native_currency")),
                    "base_token_price_quote_token": _safe_float(attrs.get("base_token_price_quote_token")),
                    "quote_token_price_base_token": _safe_float(attrs.get("quote_token_price_base_token")),

                    # Market Data
                    "fdv_usd": _safe_float(attrs.get("fdv_usd")),
                    "market_cap_usd": _safe_float(attrs.get("market_cap_usd")),
                    "reserve_in_usd": _safe_float(attrs.get("reserve_in_usd")),

                    # Volumes (all timeframes)
                    "volume_usd_m5": _safe_float(volumes.get("m5")),
                    "volume_usd_m15": _safe_float(volumes.get("m15")),
                    "volume_usd_m30": _safe_float(volumes.get("m30")),
                    "volume_usd_h1": _safe_float(volumes.get("h1")),
                    "volume_usd_h6": _safe_float(volumes.get("h6")),
                    "volume_usd_h24": _safe_float(volumes.get("h24")),

                    # Price Changes (all timeframes)
                    "price_change_pct_m5": _safe_float(price_changes.get("m5")),
                    "price_change_pct_m15": _safe_float(price_changes.get("m15")),
                    "price_change_pct_m30": _safe_float(price_changes.get("m30")),
                    "price_change_pct_h1": _safe_float(price_changes.get("h1")),
                    "price_change_pct_h6": _safe_float(price_changes.get("h6")),
                    "price_change_pct_h24": _safe_float(price_changes.get("h24")),

                    # Transactions - 5 minutes
                    "txns_m5_buys": txns_m5.get("buys"),
                    "txns_m5_sells": txns_m5.get("sells"),
                    "txns_m5_buyers": txns_m5.get("buyers"),
                    "txns_m5_sellers": txns_m5.get("sellers"),

                    # Transactions - 15 minutes
                    "txns_m15_buys": txns_m15.get("buys"),
                    "txns_m15_sells": txns_m15.get("sells"),
                    "txns_m15_buyers": txns_m15.get("buyers"),
                    "txns_m15_sellers": txns_m15.get("sellers"),

                    # Transactions - 30 minutes
                    "txns_m30_buys": txns_m30.get("buys"),
                    "txns_m30_sells": txns_m30.get("sells"),
                    "txns_m30_buyers": txns_m30.get("buyers"),
                    "txns_m30_sellers": txns_m30.get("sellers"),

                    # Transactions - 1 hour
                    "txns_h1_buys": txns_h1.get("buys"),
                    "txns_h1_sells": txns_h1.get("sells"),
                    "txns_h1_buyers": txns_h1.get("buyers"),
                    "txns_h1_sellers": txns_h1.get("sellers"),

                    # Transactions - 24 hours
                    "txns_h24_buys": txns_h24.get("buys"),
                    "txns_h24_sells": txns_h24.get("sells"),
                    "txns_h24_buyers": txns_h24.get("buyers"),
                    "txns_h24_sellers": txns_h24.get("sellers"),

                    # Safety flag
                    "is_safe": True,
                }

                all_pools.append(record)

                if len(all_pools) >= top_n:
                    break

            print(f"     Page {page}: +{len(pools)} pools, {len(all_pools)} total")
            page += 1

        except Exception as e:
            print(f"     ⚠️  Page {page} failed: {e}")
            break

    if not all_pools:
        raise ValueError("No pools found")

    print(f"\n  ✓ Collected {len(all_pools):,} safe pools")

    # Create DataFrame
    df = pd.DataFrame(all_pools)

    # Sort by 24h volume
    if "volume_usd_h24" in df.columns:
        df = df.sort_values("volume_usd_h24", ascending=False)

    # Load existing and append
    out_file = ctx.work_dir / "coingecko_pools_safe_full.parquet"
    if out_file.exists():
        try:
            from ..api import load
            existing_df = load(ctx.dataset_id, as_format="pandas")
            print(f"\n  📦 Found existing dataset: {len(existing_df):,} records")

            df = pd.concat([existing_df, df], ignore_index=True)

            # Deduplicate on (fetched_at, pool_address)
            initial_count = len(df)
            df = df.drop_duplicates(subset=["fetched_at", "network", "pool_address"], keep="last")
            if len(df) < initial_count:
                print(f"  🧹 Removed {initial_count - len(df):,} duplicates")
        except Exception as e:
            print(f"  ℹ️  No existing dataset: {e}")

    df = df.reset_index(drop=True)

    # Save
    df.to_parquet(out_file, index=False)

    print(f"\n  ✅ Saved {len(df):,} records")
    print(f"  📊 Total columns: {len(df.columns)}")

    # Show stats
    if len(df) > 0:
        latest = df[df["fetched_at"] == df["fetched_at"].max()]
        print(f"\n  📈 Latest snapshot ({latest.iloc[0]['fetched_at']}):")
        print(f"     Pools: {len(latest):,}")
        print(f"     Unique base tokens: {latest['base_token_address'].nunique()}")
        print(f"     Total 24h volume: ${latest['volume_usd_h24'].sum():,.0f}")
        print(f"     Total reserves: ${latest['reserve_in_usd'].sum():,.0f}")

        top_pool = latest.iloc[0]
        print(f"\n  🏆 Top pool by volume:")
        print(f"     {top_pool['pool_name']}")
        print(f"     24h volume: ${top_pool['volume_usd_h24']:,.0f}")
        print(f"     DEX: {top_pool['dex_name']}")

    readme = f"""# CoinGecko Complete Safe Pools Data

## Overview
Complete pool data from CoinGecko megafilter with ALL available fields

## Safety Filters Applied
- ✅ No honeypot tokens
- ✅ Good GT Score (>= 75)
- ✅ Listed on CoinGecko
- ✅ Has social links

## Data Fields

### Pool Metadata
- pool_id, pool_address, pool_name, pool_created_at
- network, dex_id, dex_name
- fetched_at (snapshot timestamp)

### Base Token (14 fields)
- address, symbol, name, decimals
- image_url, coingecko_id
- price_usd, price_native, price_quote_token

### Quote Token (14 fields)
- address, symbol, name, decimals
- image_url, coingecko_id
- price_usd, price_native, price_base_token

### Market Data
- fdv_usd, market_cap_usd, reserve_in_usd

### Volumes (6 timeframes)
- volume_usd_m5, m15, m30, h1, h6, h24

### Price Changes (6 timeframes)
- price_change_pct_m5, m15, m30, h1, h6, h24

### Transactions (5 timeframes × 4 metrics = 20 fields)
For each timeframe (m5, m15, m30, h1, h24):
- buys, sells, buyers, sellers

## Total Fields: {len(df.columns)}

## Configuration
- Network: {network}
- Top N: {top_n}
- Records: {len(df):,}
- Pools: {df["pool_address"].nunique():,}

## Usage

```python
import warpdata as wd

df = wd.load("{ctx.dataset_id}", as_format="pandas")

# Get latest snapshot
latest = df[df["fetched_at"] == df["fetched_at"].max()]

# Top pools by 24h volume
top = latest.nlargest(10, "volume_usd_h24")
print(top[["pool_name", "volume_usd_h24", "reserve_in_usd", "dex_name"]])

# Analyze transaction patterns
print(latest[["pool_name", "txns_h24_buys", "txns_h24_sells"]].head())
```

## Statistics
- Total records: {len(df):,}
- Unique pools: {df["pool_address"].nunique():,}
- Snapshots: {df["fetched_at"].nunique():,}
- Network: {network}
"""

    return RecipeOutput(
        main=[out_file],
        docs={"README.md": readme},
        metadata={
            "network": network,
            "top_n": top_n,
            "pools": len(all_pools),
            "records": len(df),
            "snapshots": df["fetched_at"].nunique(),
            "total_fields": len(df.columns),
            "source": "CoinGecko Onchain API (Megafilter - Complete)",
        },
    )
