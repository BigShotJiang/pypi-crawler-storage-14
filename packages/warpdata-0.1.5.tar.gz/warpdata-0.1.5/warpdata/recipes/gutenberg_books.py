"""
Project Gutenberg books recipe (via Gutendex).

This recipe uses the public Gutendex API (https://gutendex.com) to
download metadata and full text for Project Gutenberg books.

It is designed as a metadata + text table:
    - book_id: int        – Gutenberg book ID
    - title: str          – Book title
    - authors: list[str]  – Author names
    - languages: list[str]
    - subjects: list[str]
    - bookshelves: list[str]
    - copyright: bool | None
    - download_count: int
    - media_type: str
    - text: str           – Full book text (best-effort plain text)

Notes:
    - This will perform many HTTP requests and can take a long time
      if run over the entire corpus. Use the ``max_books`` parameter
      to cap the number of books if you want a smaller slice.
    - Please respect Project Gutenberg and Gutendex terms of use and
      rate limits when running this recipe at scale.
"""
from __future__ import annotations

import json
import time
from typing import Any, Dict, List, Optional
from urllib.error import URLError, HTTPError
from urllib.parse import urlencode
from urllib.request import Request, urlopen

from concurrent.futures import ThreadPoolExecutor, as_completed

import pandas as pd
import pyarrow.parquet as pq

from ..api.recipes import RecipeContext
from .base import RecipeOutput
from ..core.cache import get_cache
from ..core.uris import parse_uri


def _http_get_json(url: str, timeout: float = 20.0, max_retries: int = 3, backoff: float = 1.5) -> Dict[str, Any]:
    """Fetch JSON from a URL with basic retries."""
    last_err: Optional[Exception] = None
    for attempt in range(max_retries):
        try:
            req = Request(url, headers={"User-Agent": "warpdata-gutenberg/0.1"})
            with urlopen(req, timeout=timeout) as resp:
                return json.load(resp)
        except (URLError, HTTPError, TimeoutError) as e:
            last_err = e
            sleep_for = backoff**attempt
            print(f"  Warning: error fetching {url!r}: {e} (retry in {sleep_for:.1f}s)")
            time.sleep(sleep_for)
    if last_err is not None:
        raise last_err
    return {}


def _http_get_text(url: str, timeout: float = 30.0, max_retries: int = 3, backoff: float = 1.5) -> Optional[str]:
    """Fetch text content from a URL, with retries."""
    last_err: Optional[Exception] = None
    for attempt in range(max_retries):
        try:
            req = Request(url, headers={"User-Agent": "warpdata-gutenberg/0.1"})
            with urlopen(req, timeout=timeout) as resp:
                # Assume text/* content; decode as UTF-8 with fallback.
                raw = resp.read()
                try:
                    return raw.decode("utf-8")
                except UnicodeDecodeError:
                    return raw.decode("latin-1", errors="replace")
        except (URLError, HTTPError, TimeoutError) as e:
            last_err = e
            sleep_for = backoff**attempt
            print(f"  Warning: error downloading text {url!r}: {e} (retry in {sleep_for:.1f}s)")
            time.sleep(sleep_for)
    print(f"  Failed to download text from {url!r} after {max_retries} attempts: {last_err}")
    return None


def _pick_text_url(formats: Dict[str, str]) -> Optional[str]:
    """
    Choose the best plain-text URL from Gutendex 'formats' dict.

    Preference order:
        - 'text/plain; charset=utf-8'
        - 'text/plain'
        - any key that starts with 'text/plain'
    """
    if not formats:
        return None

    if "text/plain; charset=utf-8" in formats:
        return formats["text/plain; charset=utf-8"]
    if "text/plain" in formats:
        return formats["text/plain"]

    for mime, url in formats.items():
        if mime.startswith("text/plain"):
            return url

    return None


def gutenberg_books(
    ctx: RecipeContext,
    base_url: str = "https://gutendex.com/books",
    max_books: Optional[int] = None,
    languages: Optional[List[str]] = None,
    max_workers: int = 4,
    continue_from: Optional[str] = None,
) -> RecipeOutput:
    """
    Download Project Gutenberg books (via Gutendex) into a Parquet table.

    Args:
        ctx: Recipe context.
        base_url: Gutendex base URL (default: "https://gutendex.com/books").
        max_books: Optional cap on number of books to download. ``None`` means
            "all available" (may be many tens of thousands of books and several
            GB of text; use with care).
        languages: Optional list of language codes to include (e.g., ["en"]).
            If provided, only books with at least one of these languages are kept.
        max_workers: Maximum number of concurrent workers used to download
            book texts. A small value (e.g., 4–6) keeps load reasonable for
            Gutendex / Project Gutenberg.
        continue_from: Optional dataset ID (e.g., 'warpdata://text/gutenberg-en-10k')
            whose existing page Parquet files should be reused. When provided,
            this recipe will look for 'gutenberg_books_page*.parquet' under that
            dataset's recipes directory, count their rows, and continue from the
            next Gutendex page, avoiding re-downloading earlier pages.

    Returns:
        RecipeOutput with one or more Parquet files (one per page).

    Dataset columns:
        - book_id: int
        - title: str
        - authors: list[str]
        - languages: list[str]
        - subjects: list[str]
        - bookshelves: list[str]
        - copyright: bool | None
        - download_count: int
        - media_type: str
        - text: str

    Example:
        >>> import warpdata as wd
        >>> result = wd.run_recipe(
        ...     "gutenberg_books",
        ...     "warpdata://text/gutenberg-en-10k",
        ...     max_books=10_000,
        ...     languages=["en"],
        ...     with_materialize=True,
        ... )
        >>> df = wd.load("warpdata://text/gutenberg-en-10k", as_format="pandas")
    """
    # Normalize languages to a list; allow comma-separated string from CLI -p languages="en,de".
    if isinstance(languages, str):  # type: ignore[unreachable]
        lang_list: Optional[List[str]] = [l.strip() for l in languages.split(",") if l.strip()]
    else:
        lang_list = languages

    if max_books is None:
        print(
            "Warning: max_books is None – this will attempt to download the full "
            "Gutendex corpus. This may take a long time and produce a very large dataset."
        )

    print(f"Loading Project Gutenberg metadata from {base_url} via Gutendex...")
    if lang_list:
        print(f"  Restricting to languages: {lang_list}")
    if max_books is not None:
        print(f"  Will download up to {max_books:,} books")

    processed_books = 0
    page_paths: List[Path] = []

    # Determine base directory for page files, supporting continue_from
    if continue_from:
        uri = parse_uri(continue_from)
        cache = get_cache()
        output_dir = cache.get_dataset_cache_dir(uri.workspace, uri.name, "recipes")
        print(f"\nUsing existing pages from: {output_dir}")
    else:
        output_dir = ctx.work_dir

    # Check for existing page files to support resume.
    existing_pages: Dict[int, Path] = {}
    for p in sorted(output_dir.glob("gutenberg_books_page*.parquet")):
        name = p.name
        # Expect pattern gutenberg_books_pageXXXXX.parquet
        try:
            idx_str = name.split("page", 1)[1].split(".parquet", 1)[0]
            idx = int(idx_str)
        except Exception:
            continue
        existing_pages[idx] = p

    if existing_pages:
        # Sum existing rows via Parquet metadata (cheap).
        for p in existing_pages.values():
            try:
                processed_books += pq.ParquetFile(p).metadata.num_rows
            except Exception:
                continue
        start_page_idx = max(existing_pages.keys()) + 1
        page_paths.extend(p for _, p in sorted(existing_pages.items()))
        print(
            f"\nResuming from page {start_page_idx} "
            f"(found {len(existing_pages)} existing page files, {processed_books:,} books)."
        )
    else:
        start_page_idx = 1

    page_idx = start_page_idx

    while True:
        if max_books is not None and processed_books >= max_books:
            print(f"\nReached max_books={max_books:,}; stopping pagination.")
            break

        params = {}
        if lang_list is not None:
            # Gutendex supports 'languages' filter as comma-separated list.
            params["languages"] = ",".join(lang_list)
        params["page"] = page_idx
        url = f"{base_url}?{urlencode(params)}"

        print(f"\nFetching page {page_idx}: {url}")
        try:
            data = _http_get_json(url)
        except Exception as e:
            print(f"  Error fetching page {page_idx}: {e} (stopping pagination).")
            break

        results: List[Dict[str, Any]] = data.get("results", [])
        if not results:
            print("  No results on this page; stopping.")
            break
        print(f"  Page {page_idx}: {len(results)} results")

        # Pre-filter books on this page and prepare download jobs.
        candidates: List[Dict[str, Any]] = []
        for book in results:
            if max_books is not None and processed_books + len(candidates) >= max_books:
                break

            book_langs = book.get("languages", []) or []
            if lang_list is not None and not any(lang in book_langs for lang in lang_list):
                continue

            formats = book.get("formats") or {}
            text_url = _pick_text_url(formats)
            if not text_url:
                continue

            candidates.append(
                {
                    "book": book,
                    "book_langs": book_langs,
                    "text_url": text_url,
                }
            )

        if not candidates:
            print(f"  No eligible books on page {page_idx} after filtering.")
        else:
            print(f"  Downloading texts for {len(candidates)} book(s) on page {page_idx}...")
            page_records: List[Dict[str, Any]] = []
            # Download book texts concurrently (IO-bound).
            with ThreadPoolExecutor(max_workers=max_workers) as executor:
                future_to_meta = {
                    executor.submit(_http_get_text, c["text_url"]): c for c in candidates
                }
                for future in as_completed(future_to_meta):
                    meta = future_to_meta[future]
                    book = meta["book"]
                    book_langs = meta["book_langs"]
                    try:
                        text = future.result()
                    except Exception as e:
                        print(f"  Warning: error in text download worker: {e}")
                        continue

                    if text is None:
                        # Failed to download text; skip.
                        continue

                    if max_books is not None and processed_books >= max_books:
                        break

                    authors_meta = book.get("authors") or []
                    authors: List[str] = [
                        a.get("name", "") for a in authors_meta if isinstance(a, dict)
                    ]

                    record: Dict[str, Any] = {
                        "book_id": int(book.get("id")),
                        "title": str(book.get("title", "")),
                        "authors": authors,
                        "languages": book_langs,
                        "subjects": book.get("subjects") or [],
                        "bookshelves": book.get("bookshelves") or [],
                        "copyright": book.get("copyright"),
                        "download_count": int(book.get("download_count", 0) or 0),
                        "media_type": str(book.get("media_type", "")),
                        "text": text,
                    }
                    page_records.append(record)
                    processed_books += 1

                    if processed_books % 100 == 0:
                        print(f"  Collected {processed_books:,} books so far...")

            # Flush this page to its own Parquet file so we can resume later.
            if page_records:
                df_page = pd.DataFrame(page_records)
                out_path = output_dir / f"gutenberg_books_page{page_idx:05d}.parquet"
                df_page.to_parquet(out_path, index=False)
                page_paths.append(out_path)
                print(
                    f"  Saved page {page_idx} with {len(df_page):,} books "
                    f"to {out_path.name}"
                )

        print(f"  Finished page {page_idx}; total collected so far: {processed_books:,}")

        # Prepare next page
        page_idx += 1

    print(f"\nTotal books collected: {processed_books:,}")

    if not page_paths:
        raise ValueError("No books were collected from Gutendex; check filters or network connectivity.")

    # Merge page files into a single Parquet for the dataset resource.
    merged_path = ctx.work_dir / "gutenberg_books.parquet"
    writer = None
    for p in page_paths:
        table = pq.read_table(p)
        if writer is None:
            writer = pq.ParquetWriter(merged_path, table.schema)
        writer.write_table(table)
    if writer is not None:
        writer.close()

    print(f"Saved merged Parquet to {merged_path}")

    return RecipeOutput(
        main=[merged_path],
        metadata={
            "total_books": processed_books,
            "source": "Project Gutenberg via Gutendex",
            "base_url": base_url,
            "languages": lang_list or [],
            "max_books": max_books,
        },
        raw_data=[],
    )
