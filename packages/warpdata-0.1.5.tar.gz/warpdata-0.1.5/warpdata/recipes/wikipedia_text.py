"""
Wikimedia Wikipedia text recipe.

This recipe builds a Wikipedia text corpus from the
``wikimedia/wikipedia`` HuggingFace dataset.

Features from the dataset (per article):
    - id: str
    - url: str
    - title: str
    - text: str
    - timestamp: str

Design goals:
    - Default: English-only snapshot (20231101.en).
    - Configurable presets for multiple languages, e.g.:
        * preset='en'   – English only (default)
        * preset='main' – a curated set of high-resource languages
        * preset='all'  – all languages available for the snapshot
    - Global ``limit`` over number of articles (optional).
    - Streaming + chunked Parquet writing to avoid high RAM usage.
"""
from __future__ import annotations

from pathlib import Path
from typing import Any, Dict, List, Optional

import pandas as pd
import pyarrow as pa
import pyarrow.parquet as pq
from datasets import get_dataset_config_names, load_dataset

from ..api.recipes import RecipeContext
from .base import RecipeOutput


WRITE_CHUNK_SIZE = 50_000

# Curated "main" Wikipedia languages for a general-purpose corpus.
MAIN_LANGS: List[str] = [
    "en",  # English
    "de",  # German
    "fr",  # French
    "es",  # Spanish
    "ru",  # Russian
    "zh",  # Chinese
    "ja",  # Japanese
    "pt",  # Portuguese
    "it",  # Italian
    "nl",  # Dutch
    "pl",  # Polish
    "ar",  # Arabic
    "tr",  # Turkish
    "ko",  # Korean
]


def _resolve_languages_for_snapshot(
    snapshot: str,
    preset: str,
    languages: Optional[List[str]],
) -> List[str]:
    """
    Resolve the list of language codes to use for a given snapshot.

    Args:
        snapshot: Snapshot date prefix (e.g., '20231101').
        preset: Language preset name ('en', 'main', 'all', or custom).
        languages: Optional explicit list of language codes. If provided,
            overrides preset.

    Returns:
        List of language codes (e.g., ['en', 'de', 'fr']).
    """
    # If explicit languages are provided, respect them.
    if languages:
        return [str(lang).strip() for lang in languages if str(lang).strip()]

    preset = (preset or "en").lower()

    # Discover available configs for this dataset.
    all_configs = get_dataset_config_names("wikimedia/wikipedia")
    # Example config names: '20231101.en', '20231101.de', ...
    available_langs = {
        cfg.split(".", 1)[1] for cfg in all_configs if cfg.startswith(f"{snapshot}.")
    }

    if preset in {"en", "default"}:
        langs = ["en"]
    elif preset == "main":
        # Use MAIN_LANGS but only keep those that exist for this snapshot.
        langs = [lang for lang in MAIN_LANGS if lang in available_langs]
    elif preset == "all":
        langs = sorted(available_langs)
    else:
        # Treat unknown preset as a single language code (e.g., 'de').
        if preset in available_langs:
            langs = [preset]
        else:
            raise ValueError(
                f"Unknown preset '{preset}' and no explicit languages provided. "
                f"Available language codes for snapshot {snapshot}: {sorted(available_langs)}"
            )

    if not langs:
        raise ValueError(
            f"No languages resolved for snapshot={snapshot}, preset={preset}. "
            "Check that the snapshot exists and that languages are available."
        )

    return langs


def wikipedia_text(
    ctx: RecipeContext,
    snapshot: str = "20231101",
    preset: str = "en",
    languages: Optional[List[str]] = None,
    limit: Optional[int] = None,
) -> RecipeOutput:
    """
    Create a Wikipedia text corpus from wikimedia/wikipedia.

    Args:
        ctx: Recipe context.
        snapshot: Snapshot date prefix used in config names
            (e.g., '20231101' → configs like '20231101.en').
        preset: Language preset:
            - 'en' / 'default': English only (config 'snapshot.en').
            - 'main': Curated set of major languages (see MAIN_LANGS).
            - 'all': All languages available for the snapshot.
            - any other value: treated as a single language code
              (e.g., preset='de' → German only).
        languages: Optional explicit list of language codes. If provided,
            this overrides the preset logic entirely.
        limit: Optional global cap on number of articles across all
            languages. None means "no global cap".

    Returns:
        RecipeOutput with a single Parquet file containing:
            - id: str
            - url: str
            - title: str
            - text: str
            - timestamp: str
            - language: str

    Notes:
        - Uses streaming + chunked Parquet writing to keep memory usage
          bounded, even for large multi-language mixes.
        - For CLI usage with presets:
              warp recipes run wikipedia_text warpdata://text/wikipedia-en
          or:
              warp recipes run wikipedia_text warpdata://text/wikipedia-main \\
                -p preset=main
    """
    # Normalize languages argument: allow comma-separated string via CLI.
    if isinstance(languages, str):  # type: ignore[unreachable]
        raw_langs = [part.strip() for part in languages.split(",") if part.strip()]
        languages_list: Optional[List[str]] = raw_langs
    else:
        languages_list = languages

    langs = _resolve_languages_for_snapshot(snapshot, preset, languages_list)

    print(f"Loading wikimedia/wikipedia snapshot={snapshot}")
    print(f"  Languages: {langs}")
    if limit is not None:
        print(f"  Global article limit: {limit:,}")

    # Streaming parquet writer
    out_path = ctx.work_dir / "wikipedia_text.parquet"
    writer: Optional[pq.ParquetWriter] = None
    buffer: List[Dict[str, Any]] = []
    total_articles = 0

    def flush_buffer():
        nonlocal writer, buffer
        if not buffer:
            return
        df = pd.DataFrame(buffer)
        table = pa.Table.from_pandas(df, preserve_index=False)
        if writer is None:
            writer = pq.ParquetWriter(out_path, table.schema)
        writer.write_table(table)
        buffer.clear()

    for lang in langs:
        config_name = f"{snapshot}.{lang}"
        print(f"\nSampling Wikipedia for language='{lang}' (config={config_name})...")

        ds = load_dataset(
            "wikimedia/wikipedia",
            config_name,
            split="train",
            streaming=True,
        )

        lang_count = 0

        for example in ds:
            if limit is not None and total_articles >= limit:
                print(
                    f"  Reached global limit: {total_articles:,} articles "
                    f"(stopping at language='{lang}')"
                )
                break

            record = {
                "id": str(example.get("id", "")),
                "url": str(example.get("url", "")),
                "title": str(example.get("title", "")),
                "text": str(example.get("text", "")),
                "timestamp": str(example.get("timestamp", "")),
                "language": lang,
            }

            buffer.append(record)
            total_articles += 1
            lang_count += 1

            if len(buffer) >= WRITE_CHUNK_SIZE:
                flush_buffer()

            if lang_count % 100_000 == 0:
                print(f"    {lang}: {lang_count:,} articles collected...")

        print(f"  Finished {lang}: {lang_count:,} articles")

        if limit is not None and total_articles >= limit:
            break

    # Final flush
    flush_buffer()
    if writer is not None:
        writer.close()

    print(f"\nTotal articles collected (all languages): {total_articles:,}")
    print(f"Saved to {out_path}")

    # Provenance: HF cache root for this dataset
    raw_data_paths: List[Path] = []
    hf_cache = (
        Path.home()
        / ".cache"
        / "huggingface"
        / "datasets"
        / "wikimedia___wikipedia"
    )
    if hf_cache.exists():
        raw_data_paths.append(hf_cache)

    return RecipeOutput(
        main=[out_path],
        metadata={
            "total_articles": total_articles,
            "snapshot": snapshot,
            "preset": preset,
            "languages": langs,
            "limit": limit,
            "repo_id": "wikimedia/wikipedia",
        },
        raw_data=raw_data_paths,
    )

