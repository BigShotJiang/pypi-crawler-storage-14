"""
Binance Symbol Map recipe.

Produces a mapping between Binance trading symbols and CoinGecko coin_ids
for the base asset, enabling joins between Binance datasets and CoinGecko.

Heuristic mapping:
- Use a small override dictionary for common assets
- Otherwise, coin_id = base_asset.lower()

No registration or network required for tests; allows dependency injection
of a symbol loader function.
"""
from __future__ import annotations

from typing import Callable, Dict, Optional, List
from pathlib import Path
import pandas as pd

from ..api.recipes import RecipeContext
from .base import RecipeOutput


DEFAULT_OVERRIDES: Dict[str, str] = {
    "BTC": "bitcoin",
    "ETH": "ethereum",
    "BNB": "binancecoin",
    "MIOTA": "iota",
    "IOTA": "iota",
    "BCH": "bitcoin-cash",
    "ETC": "ethereum-classic",
    "DOGE": "dogecoin",
    "ADA": "cardano",
    "TRX": "tron",
    "XRP": "ripple",
    "SOL": "solana",
    "MATIC": "matic-network",
    "DOT": "polkadot",
    "LTC": "litecoin",
}


def _normalize_map(df_symbols: pd.DataFrame, overrides: Dict[str, str]) -> pd.DataFrame:
    cols = {c.lower(): c for c in df_symbols.columns}
    # Standardize column names
    df = df_symbols.rename(
        columns={
            cols.get("symbol", "symbol"): "symbol",
            cols.get("base_asset", "base_asset"): "base_asset",
            cols.get("baseasset", "base_asset"): "base_asset",  # fallback
            cols.get("quote_asset", "quote_asset"): "quote_asset",
            cols.get("quoteasset", "quote_asset"): "quote_asset",
            cols.get("status", "status"): "status",
        }
    ).copy()

    # Heuristic coin_id
    def to_coin_id(base: Optional[str]) -> Optional[str]:
        if not base:
            return None
        b = str(base).upper()
        if b in overrides:
            return overrides[b]
        return str(base).lower()

    df["coin_id"] = df["base_asset"].map(to_coin_id)
    df["preferred_quote"] = (df["quote_asset"].str.upper() == "USDT").astype(int)
    return df


def binance_symbol_map(
    ctx: RecipeContext,
    *,
    load_symbols_fn: Optional[Callable[[], pd.DataFrame]] = None,
    overrides: Optional[Dict[str, str]] = None,
    load_coingecko_map_fn: Optional[Callable[[], pd.DataFrame]] = None,
) -> RecipeOutput:
    """
    Build a Binance→CoinGecko symbol mapping table.

    Args:
        ctx: Recipe context
        load_symbols_fn: Function returning a DataFrame with columns
            [symbol, base_asset, quote_asset, status]. If not provided,
            tries to read a local binance_symbols.parquet in work_dir.
        overrides: Optional dict from base_asset ticker to coin_id.
    """
    if load_symbols_fn is None:
        # Default: load from local symbols parquet produced by binance_symbols
        sym_path = ctx.work_dir / "binance_symbols.parquet"
        if not sym_path.exists():
            raise FileNotFoundError(
                f"Symbols file not found: {sym_path}. Run binance_symbols first or provide load_symbols_fn."
            )
        def load_symbols_fn():  # type: ignore
            return pd.read_parquet(sym_path)

    ov = {**DEFAULT_OVERRIDES, **(overrides or {})}
    df_symbols = load_symbols_fn()

    # Optional: enhance mapping using CoinGecko symbol→coin_id
    cg_map: Optional[Dict[str, str]] = None
    if load_coingecko_map_fn is not None:
        try:
            df_cg = load_coingecko_map_fn()  # expects columns: symbol, coin_id, optionally market_cap
            # Normalize
            need = {"symbol", "coin_id"}
            if not need.issubset(df_cg.columns):
                raise ValueError("CoinGecko map missing required columns: symbol, coin_id")
            df_cg = df_cg[[c for c in df_cg.columns if c in {"symbol", "coin_id", "market_cap"}]].copy()
            df_cg["symbol"] = df_cg["symbol"].astype(str).str.upper()
            # If duplicates by symbol, pick highest market cap if available
            if "market_cap" in df_cg.columns:
                df_cg = df_cg.sort_values(["symbol", "market_cap"], ascending=[True, False])
            df_cg = df_cg.drop_duplicates(subset=["symbol"], keep="first")
            cg_map = dict(zip(df_cg["symbol"], df_cg["coin_id"]))
        except Exception:
            cg_map = None

    df_map = _normalize_map(df_symbols, ov)
    if cg_map:
        # Fill coin_id from CG symbol map where override/default is not ideal
        # Prefer overrides; only override rows where coin_id equals lower(base_asset)
        mask_default = df_map["coin_id"].astype(str).str.lower() == df_map["base_asset"].astype(str).str.lower()
        base_upper = df_map["base_asset"].astype(str).str.upper()
        mapped = base_upper.map(cg_map)
        df_map.loc[mask_default & mapped.notna(), "coin_id"] = mapped[mask_default & mapped.notna()].values

    # Prefer USDT quote when multiple symbols share same base (e.g., BTCUSDT, BTCBUSD)
    df_map = df_map.sort_values(["base_asset", "preferred_quote"], ascending=[True, False])

    out_file = ctx.work_dir / "binance_symbol_map.parquet"
    out_file.parent.mkdir(parents=True, exist_ok=True)
    df_map.to_parquet(out_file, index=False)

    return RecipeOutput(
        main=[out_file],
        metadata={
            "source": "binance",
            "kind": "symbol-map",
            "rows": len(df_map),
        },
    )
