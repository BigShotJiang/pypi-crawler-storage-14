"""
Polygon Earnings dataset recipe.

Fetches earnings calendar data from Polygon.io Benzinga API.
Includes actual/estimated EPS, revenue, surprises, and dates.

Source: Polygon.io Benzinga Earnings API
"""
from pathlib import Path
from typing import List, Optional
import pandas as pd
import os
import requests
from datetime import datetime, timedelta

from ..api.recipes import RecipeContext
from .base import RecipeOutput


def polygon_earnings(
    ctx: RecipeContext,
    *,
    tickers: Optional[List[str]] = None,
    start_date: Optional[str] = None,
    end_date: Optional[str] = None,
    polygon_api_key: Optional[str] = None,
) -> RecipeOutput:
    """
    Create Polygon Earnings dataset.

    Downloads earnings calendar data including actual/estimated EPS, revenue, and dates.

    Args:
        ctx: Recipe context
        tickers: Optional list of tickers to filter (if None, gets all)
        start_date: Start date (YYYY-MM-DD) for earnings dates
        end_date: End date (YYYY-MM-DD) for earnings dates
        polygon_api_key: Polygon API key (or set POLYGON_API_KEY env var)

    Returns:
        RecipeOutput with earnings data

    Examples:
        >>> import warpdata as wd
        >>> # Get all earnings for specific tickers
        >>> result = wd.run_recipe(
        ...     "polygon_earnings",
        ...     "warpdata://earnings/tech-stocks",
        ...     tickers=["AAPL", "MSFT", "GOOGL"],
        ...     with_materialize=True
        ... )
        >>> # Get all earnings in date range
        >>> result = wd.run_recipe(
        ...     "polygon_earnings",
        ...     "warpdata://earnings/q4-2024",
        ...     start_date="2024-10-01",
        ...     end_date="2024-12-31",
        ...     with_materialize=True
        ... )
    """
    # Get API key
    api_key = polygon_api_key or os.environ.get("POLYGON_API_KEY")
    if not api_key:
        raise ValueError(
            "Polygon API key required. Set POLYGON_API_KEY env var or pass polygon_api_key parameter"
        )

    print(f"📊 Fetching Polygon Earnings data")
    if tickers:
        print(f"   Tickers: {', '.join(tickers[:10])}{'...' if len(tickers) > 10 else ''}")
    if start_date or end_date:
        print(f"   Date range: {start_date or 'beginning'} to {end_date or 'now'}")

    all_records = []
    base_url = "https://api.polygon.io/benzinga/v1/earnings"

    # If tickers specified, fetch per ticker
    if tickers:
        for ticker in tickers:
            print(f"  📈 Fetching {ticker}...")

            params = {
                "apiKey": api_key,
                "ticker": ticker,
                "limit": 50000,  # Max limit
            }

            if start_date:
                params["date.gte"] = start_date
            if end_date:
                params["date.lte"] = end_date

            try:
                response = requests.get(base_url, params=params)

                if response.status_code == 200:
                    data = response.json()
                    results = data.get("results", [])

                    if results:
                        all_records.extend(results)
                        print(f"    ✓ {len(results)} earnings events")
                    else:
                        print(f"    ℹ️  No earnings data")
                else:
                    print(f"    ⚠️  HTTP {response.status_code}")

            except Exception as e:
                print(f"    ⚠️  Error: {e}")

    else:
        # Fetch all earnings in date range (paginated)
        print(f"  📦 Fetching all earnings...")

        params = {
            "apiKey": api_key,
            "limit": 50000,
            "sort": "date.asc",
        }

        if start_date:
            params["date.gte"] = start_date
        if end_date:
            params["date.lte"] = end_date

        next_url = None
        page = 1

        while True:
            try:
                if next_url:
                    response = requests.get(next_url)
                else:
                    response = requests.get(base_url, params=params)

                if response.status_code != 200:
                    print(f"    ⚠️  HTTP {response.status_code}")
                    break

                data = response.json()
                results = data.get("results", [])

                if results:
                    all_records.extend(results)
                    print(f"    Page {page}: {len(results)} earnings events ({len(all_records):,} total)")

                # Check for next page
                next_url = data.get("next_url")
                if not next_url:
                    break

                page += 1

            except Exception as e:
                print(f"    ⚠️  Error: {e}")
                break

    if not all_records:
        raise ValueError("No earnings data found")

    print(f"\n  ✓ Total earnings events: {len(all_records):,}")

    # Convert to DataFrame
    df = pd.DataFrame(all_records)

    # Convert timestamps
    if 'last_updated' in df.columns:
        df['last_updated'] = pd.to_datetime(df['last_updated'], errors='coerce')

    # Ensure date column
    if 'date' in df.columns:
        df['date'] = pd.to_datetime(df['date'], errors='coerce').dt.strftime('%Y-%m-%d')

    # Sort by date and ticker
    if 'date' in df.columns and 'ticker' in df.columns:
        df = df.sort_values(['date', 'ticker'])

    # Save to parquet
    output_file = ctx.work_dir / "polygon_earnings.parquet"
    df.to_parquet(output_file, index=False)

    print(f"  ✓ Saved to {output_file.name}")

    # Show sample
    print(f"\n  📊 Sample data:")
    sample_cols = ['ticker', 'date', 'actual_eps', 'estimated_eps', 'eps_surprise_percent']
    available_cols = [col for col in sample_cols if col in df.columns]
    if available_cols:
        print(df[available_cols].head(3).to_string())

    # Generate documentation
    readme = f"""# Polygon Earnings Dataset

## Overview
Earnings calendar data from Polygon.io Benzinga API

## Configuration
- **Tickers**: {f"{len(tickers)} tickers" if tickers else "All tickers"}
- **Date Range**: {start_date or "All"} to {end_date or "All"}
- **Source**: Polygon.io Benzinga Earnings API

## Schema

| Column | Type | Description |
|--------|------|-------------|
| ticker | string | Stock ticker symbol |
| date | date | Earnings report date |
| time | string | Report time (BMO/AMC) |
| actual_eps | float | Actual reported EPS |
| estimated_eps | float | Analyst estimated EPS |
| eps_surprise | float | Absolute EPS surprise |
| eps_surprise_percent | float | Percentage EPS surprise |
| actual_revenue | float | Actual reported revenue |
| estimated_revenue | float | Analyst estimated revenue |
| revenue_surprise | float | Absolute revenue surprise |
| revenue_surprise_percent | float | Percentage revenue surprise |
| fiscal_year | int | Fiscal year |
| fiscal_period | string | Fiscal period (Q1, Q2, etc.) |
| company_name | string | Company name |
| importance | int | Event importance (0-5) |
| date_status | string | Status (projected/confirmed) |

## Usage

```python
import warpdata as wd

# Load earnings data
df = wd.load("warpdata://earnings/...", as_format="pandas")

# Filter by ticker
aapl_earnings = df[df['ticker'] == 'AAPL']

# Find earnings surprises
surprises = df[df['eps_surprise_percent'].abs() > 10]

# Upcoming earnings
upcoming = df[df['date_status'] == 'projected']
```

## Statistics
- Total events: {len(df):,}
- Unique tickers: {df['ticker'].nunique() if 'ticker' in df.columns else 'N/A'}
- Date range: {df['date'].min() if 'date' in df.columns else 'N/A'} to {df['date'].max() if 'date' in df.columns else 'N/A'}
"""

    metadata = {
        "total_events": len(df),
        "unique_tickers": int(df['ticker'].nunique()) if 'ticker' in df.columns else 0,
        "date_range": f"{df['date'].min()} to {df['date'].max()}" if 'date' in df.columns else None,
        "source": "Polygon.io Benzinga Earnings API",
    }

    return RecipeOutput(
        main=[output_file],
        docs={"README.md": readme},
        metadata=metadata,
    )
