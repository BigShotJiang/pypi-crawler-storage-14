"""
Polygon Stock Splits dataset recipe.

Fetches historical stock split events from Polygon.io.
Includes: execution dates, split ratios, ticker symbols.

Source: Polygon.io Reference API (/v3/reference/splits)
"""
from pathlib import Path
from typing import Optional, Dict, Any
import json
import pandas as pd
import sys
import os

from ..api.recipes import RecipeContext
from .base import RecipeOutput


def polygon_splits(
    ctx: RecipeContext,
    *,
    ticker: Optional[str] = None,
    execution_date: Optional[str] = None,
    execution_date_gte: Optional[str] = None,
    execution_date_lte: Optional[str] = None,
    reverse_split: Optional[bool] = None,
    order: str = "asc",
    limit: int = 1000,
    sort: str = "execution_date",
    polygon_api_key: Optional[str] = None,
    raw_data_dir: str = "recipes_raw_data/polygon_splits",
) -> RecipeOutput:
    """
    Create Polygon Stock Splits dataset.

    Downloads historical stock split events with execution dates and ratios.

    Args:
        ctx: Recipe context
        ticker: Filter by ticker symbol (e.g., "AAPL")
        execution_date: Filter by exact execution date (YYYY-MM-DD)
        execution_date_gte: Filter by execution date >= (YYYY-MM-DD)
        execution_date_lte: Filter by execution date <= (YYYY-MM-DD)
        reverse_split: Filter for reverse splits (split_from > split_to)
        order: Sort order (asc or desc, default: asc)
        limit: Maximum number of results (default: 1000)
        sort: Sort field (default: execution_date)
        polygon_api_key: Polygon API key (or set POLYGON_API_KEY env var)
        raw_data_dir: Directory to store raw JSON files

    Returns:
        RecipeOutput with stock split data

    Examples:
        >>> import warpdata as wd
        >>> # Fetch all AAPL splits
        >>> result = wd.run_recipe(
        ...     "polygon_splits",
        ...     "warpdata://splits/aapl",
        ...     ticker="AAPL",
        ...     with_materialize=True
        ... )
        >>> # Fetch recent reverse splits
        >>> result = wd.run_recipe(
        ...     "polygon_splits",
        ...     "warpdata://splits/reverse",
        ...     reverse_split=True,
        ...     execution_date_gte="2020-01-01",
        ...     with_materialize=True
        ... )
    """
    # Import polygon ETL
    polygon_etl_path = Path("/home/alerad/workspace/option_pricing/options_etl")
    if polygon_etl_path.exists():
        sys.path.insert(0, str(polygon_etl_path.parent))

    try:
        from options_etl.polygon_etl_module import PolygonETLAPI
    except ImportError as e:
        raise ImportError(
            f"Could not import polygon_etl_module. "
            f"Make sure /home/alerad/workspace/option_pricing is accessible"
        ) from e

    # Get API key
    api_key = polygon_api_key or os.environ.get("POLYGON_API_KEY")
    if not api_key:
        raise ValueError(
            "Polygon API key required. Set POLYGON_API_KEY env var or pass polygon_api_key parameter"
        )

    print(f"📊 Fetching Polygon Stock Splits")
    if ticker:
        print(f"   Ticker: {ticker}")
    if reverse_split is not None:
        print(f"   Reverse Splits Only: {reverse_split}")
    if execution_date:
        print(f"   Execution Date: {execution_date}")

    # Create raw data directory
    raw_dir = Path(raw_data_dir)
    raw_dir.mkdir(parents=True, exist_ok=True)

    # Initialize Polygon ETL API
    etl = PolygonETLAPI(api_key=api_key)

    # Prepare filters
    filters: Dict[str, Any] = {
        "order": order,
        "limit": limit,
        "sort": sort,
    }
    if ticker:
        filters["ticker"] = ticker
    if execution_date:
        filters["execution_date"] = execution_date
    if execution_date_gte:
        filters["execution_date.gte"] = execution_date_gte
    if execution_date_lte:
        filters["execution_date.lte"] = execution_date_lte
    if reverse_split is not None:
        filters["reverse_split"] = reverse_split

    # Fetch splits
    json_file = raw_dir / "splits.json"
    print(f"\n📈 Fetching stock splits...")

    try:
        result = etl.fetch_splits(out=str(json_file), **filters)
        print(f"  ✓ Fetched {result.get('count', 0):,} split records")
    except Exception as e:
        raise RuntimeError(f"Failed to fetch splits: {e}") from e

    # Load and process data
    if not json_file.exists():
        raise ValueError("No split data downloaded")

    with open(json_file) as f:
        data = json.load(f)

    if not isinstance(data, list) or len(data) == 0:
        raise ValueError("No split records found")

    # Convert to DataFrame
    df = pd.DataFrame(data)

    print(f"\n📊 Processing {len(df):,} split records...")

    # Convert execution_date to datetime
    if 'execution_date' in df.columns:
        df['execution_date'] = pd.to_datetime(df['execution_date'], errors='coerce')

    # Calculate split ratio
    if 'split_to' in df.columns and 'split_from' in df.columns:
        df['split_ratio'] = df['split_to'] / df['split_from']
        df['is_reverse_split'] = df['split_from'] > df['split_to']

    # Save to parquet
    output_file = ctx.work_dir / "polygon_splits.parquet"
    df.to_parquet(output_file, index=False)

    print(f"  ✓ Saved {len(df):,} records to {output_file.name}")

    # Show sample
    print(f"\n  📊 Columns: {list(df.columns)}")
    if len(df) > 0:
        print(f"\n  📋 Sample Splits:")
        for _, row in df.head(5).iterrows():
            ticker_str = row.get('ticker', 'N/A')
            date = row.get('execution_date', 'N/A')
            split_to = row.get('split_to', 0)
            split_from = row.get('split_from', 1)
            ratio = row.get('split_ratio', 0)
            print(f"    {ticker_str}: {split_to}-for-{split_from} ({ratio:.2f}x) on {date}")

    # Generate documentation
    readme = f"""# Polygon Stock Splits Dataset

## Overview
Historical stock split events from Polygon.io

## Configuration
- **Order**: {order}
- **Sort**: {sort}
- **Limit**: {limit:,}
{f"- **Ticker**: {ticker}" if ticker else ""}
{f"- **Reverse Splits Only**: {reverse_split}" if reverse_split is not None else ""}
{f"- **Execution Date**: {execution_date}" if execution_date else ""}

## Statistics
- **Total Splits**: {len(df):,}
- **Date Range**: {df['execution_date'].min()} to {df['execution_date'].max()}
- **Columns**: {len(df.columns)}
{f"- **Reverse Splits**: {df['is_reverse_split'].sum():,}" if 'is_reverse_split' in df.columns else ""}
{f"- **Forward Splits**: {(~df['is_reverse_split']).sum():,}" if 'is_reverse_split' in df.columns else ""}

## Key Fields

### Identification
- `ticker`: Stock ticker symbol
- `id`: Unique identifier for this split

### Split Details
- `execution_date`: Date when split was executed
- `split_to`: First number in split ratio (e.g., 2 in "2-for-1")
- `split_from`: Second number in split ratio (e.g., 1 in "2-for-1")
- `split_ratio`: Calculated ratio (split_to / split_from)
- `is_reverse_split`: Boolean indicating if split_from > split_to

## Understanding Split Ratios

### Forward Splits (split_to > split_from)
- **2-for-1**: Each share becomes 2 shares (split_ratio = 2.0)
- **3-for-1**: Each share becomes 3 shares (split_ratio = 3.0)
- **3-for-2**: Every 2 shares become 3 shares (split_ratio = 1.5)

### Reverse Splits (split_from > split_to)
- **1-for-2**: Every 2 shares become 1 share (split_ratio = 0.5)
- **1-for-10**: Every 10 shares become 1 share (split_ratio = 0.1)

Forward splits increase share count and decrease price.
Reverse splits decrease share count and increase price.

## Price Adjustments

Polygon.io automatically adjusts historical prices for splits in other endpoints
(e.g., Aggregates API). You can request both adjusted and unadjusted views.

## Usage

```python
import warpdata as wd

# Load splits data
splits = wd.load("warpdata://splits/all", as_format="pandas")

# Filter by ticker
aapl_splits = splits[splits['ticker'] == 'AAPL']

# Find reverse splits
reverse = splits[splits['is_reverse_split'] == True]

# Recent splits (last year)
import pandas as pd
recent = splits[splits['execution_date'] >= pd.Timestamp.now() - pd.Timedelta(days=365)]

# Most common split ratios
split_counts = splits['split_ratio'].value_counts()

# Companies with multiple splits
multi_splits = splits.groupby('ticker').size()
multi_splits = multi_splits[multi_splits > 1].sort_values(ascending=False)
```

## Source
Polygon.io Reference API - /v3/reference/splits
History: Records date back to October 25, 1978
Updated: Daily
"""

    # Track raw data provenance
    raw_data_paths = []
    if raw_dir.exists():
        raw_data_paths.append(raw_dir.absolute())

    metadata = {
        "total_splits": len(df),
        "columns": list(df.columns),
        "source": "Polygon.io Reference API",
        "endpoint": "/v3/reference/splits",
        "filters": filters,
    }

    return RecipeOutput(
        main=[output_file],
        subdatasets={},
        docs={"README.md": readme},
        metadata=metadata,
        raw_data=raw_data_paths,
    )
