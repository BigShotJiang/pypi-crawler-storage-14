"""
Polygon Options dataset recipe.

Fetches historical options data from Polygon.io API using the polygon_etl module.
Supports both grouped daily (all options) and chain snapshots (per underlying).

Source: Polygon.io Options API
Data types:
- Grouped daily: OHLC for all options contracts
- Chain snapshots: Greeks, IV, OI for option chains by underlying
"""
from pathlib import Path
from typing import List, Optional, Tuple
import json
import pandas as pd
import sys
import os

from ..api.recipes import RecipeContext
from .base import RecipeOutput, SubDataset


def polygon_options(
    ctx: RecipeContext,
    start_date: str,
    end_date: str,
    *,
    underlyings: Optional[List[str]] = None,
    fetch_grouped_daily: bool = True,
    fetch_chain_snapshots: bool = True,
    polygon_api_key: Optional[str] = None,
    raw_data_dir: str = "recipes_raw_data/polygon_options",
) -> RecipeOutput:
    """
    Create Polygon Options dataset.

    Downloads options data from Polygon.io and converts to Parquet.
    Can fetch:
    1. Grouped daily (all options OHLC for each date)
    2. Chain snapshots (greeks/IV/OI for specific underlyings)

    Args:
        ctx: Recipe context
        start_date: Start date (YYYY-MM-DD)
        end_date: End date (YYYY-MM-DD)
        underlyings: List of underlying tickers for chain snapshots (e.g., ["SPY", "QQQ"])
        fetch_grouped_daily: Whether to fetch grouped daily data
        fetch_chain_snapshots: Whether to fetch chain snapshots
        polygon_api_key: Polygon API key (or set POLYGON_API_KEY env var)
        raw_data_dir: Directory to store raw JSON files

    Returns:
        RecipeOutput with main dataset (grouped daily) and optional subdatasets (chain snapshots)

    Examples:
        >>> import warpdata as wd
        >>> # Fetch historical data for SPY options
        >>> result = wd.run_recipe(
        ...     "polygon_options",
        ...     "warpdata://options/spy-historical",
        ...     start_date="2024-01-01",
        ...     end_date="2024-01-31",
        ...     underlyings=["SPY"],
        ...     with_materialize=True
        ... )
        >>> df = wd.load("warpdata://options/spy-historical", as_format="pandas")
    """
    # Import the polygon ETL module
    polygon_etl_path = Path("/home/alerad/workspace/option_pricing/options_etl")
    if polygon_etl_path.exists():
        sys.path.insert(0, str(polygon_etl_path.parent))

    try:
        from options_etl.polygon_etl_module import PolygonETLAPI
    except ImportError as e:
        raise ImportError(
            f"Could not import polygon_etl_module. Make sure it's in your PYTHONPATH. "
            f"Tried: {polygon_etl_path.parent}"
        ) from e

    # Get API key
    api_key = polygon_api_key or os.environ.get("POLYGON_API_KEY")
    if not api_key:
        raise ValueError(
            "Polygon API key required. Set POLYGON_API_KEY env var or pass polygon_api_key parameter"
        )

    print(f"📊 Fetching Polygon Options data from {start_date} to {end_date}")

    # Create raw data directory
    raw_dir = Path(raw_data_dir)
    raw_dir.mkdir(parents=True, exist_ok=True)

    # Initialize Polygon ETL API
    etl = PolygonETLAPI(api_key=api_key)

    output_files = []
    subdatasets = {}
    metadata = {
        "start_date": start_date,
        "end_date": end_date,
        "source": "Polygon.io",
    }

    # 1. Fetch grouped daily (all options)
    if fetch_grouped_daily:
        print("\n📦 Fetching grouped daily data (all options)...")
        grouped_dir = raw_dir / "grouped_daily"

        result = etl.backfill_grouped_daily(
            start=start_date,
            end=end_date,
            out_dir=str(grouped_dir),
            sleep_ms=200,
        )

        print(f"   Downloaded {result['days']} days, {result['wrote']} total records")

        # Convert JSON files to Parquet
        print("   Converting to Parquet...")
        records = []
        for json_file in sorted(grouped_dir.glob("*.json")):
            date = json_file.stem
            try:
                data = json.loads(json_file.read_text())
                results = data.get("results", [])
                for r in results:
                    r["date"] = date
                    records.append(r)
            except Exception as e:
                print(f"   Warning: Failed to parse {json_file}: {e}")

        if records:
            df = pd.DataFrame(records)
            # Rename columns to standard names
            df = df.rename(columns={
                'T': 'ticker',
                'v': 'volume',
                'vw': 'vwap',
                'o': 'open',
                'c': 'close',
                'h': 'high',
                'l': 'low',
                't': 'timestamp',
                'n': 'transactions',
            })

            grouped_output = ctx.work_dir / "polygon_grouped_daily.parquet"
            df.to_parquet(grouped_output, index=False)
            output_files.append(grouped_output)

            metadata["grouped_daily_records"] = len(df)
            metadata["grouped_daily_days"] = result["days"]

            print(f"   ✓ Converted {len(df):,} records to {grouped_output}")

    # 2. Fetch chain snapshots (per underlying)
    if fetch_chain_snapshots and underlyings:
        print(f"\n🔗 Fetching chain snapshots for {len(underlyings)} underlyings...")

        for underlying in underlyings:
            print(f"\n   Processing {underlying}...")
            chain_dir = raw_dir / "snapshot_chain" / underlying

            result = etl.backfill_chain_snapshot(
                underlying=underlying,
                start=start_date,
                end=end_date,
                out_dir=str(raw_dir / "snapshot_chain"),
                sleep_ms=200,
            )

            print(f"   Downloaded {result['days']} days, {result['wrote']} total contracts")

            # Convert JSON files to Parquet
            print(f"   Converting {underlying} to Parquet...")
            records = []
            for json_file in sorted(chain_dir.glob("*.json")):
                try:
                    data = json.loads(json_file.read_text())
                    if isinstance(data, list):
                        records.extend(data)
                    else:
                        # Handle single object or wrapped results
                        results = data.get("results", []) if isinstance(data, dict) else []
                        records.extend(results)
                except Exception as e:
                    print(f"   Warning: Failed to parse {json_file}: {e}")

            if records:
                df = pd.DataFrame(records)

                # Flatten nested 'details' and 'greeks' if present
                if 'details' in df.columns:
                    details_df = pd.json_normalize(df['details'])
                    df = df.drop(columns=['details']).join(details_df, rsuffix='_detail')

                if 'greeks' in df.columns:
                    greeks_df = pd.json_normalize(df['greeks'])
                    df = df.drop(columns=['greeks']).join(greeks_df, rsuffix='_greek')

                chain_output = ctx.work_dir / f"polygon_chain_{underlying.lower()}.parquet"
                df.to_parquet(chain_output, index=False)

                subdatasets[f"chain_{underlying.lower()}"] = SubDataset(
                    name=f"chain_{underlying.lower()}",
                    files=[chain_output],
                    description=f"Option chain snapshots for {underlying} (greeks, IV, OI)",
                    metadata={
                        "underlying": underlying,
                        "records": len(df),
                        "days": result["days"],
                    }
                )

                print(f"   ✓ Converted {len(df):,} contracts to {chain_output}")

        metadata["underlyings"] = underlyings
        metadata["chain_datasets"] = len(subdatasets)

    # Generate documentation
    readme = f"""# Polygon Options Dataset

## Overview
Historical options data from Polygon.io

## Configuration
- **Date Range**: {start_date} to {end_date}
- **Grouped Daily**: {fetch_grouped_daily}
- **Chain Snapshots**: {fetch_chain_snapshots}
- **Underlyings**: {underlyings if underlyings else 'None'}

## Datasets

### Main Dataset (Grouped Daily)
OHLC data for all options contracts by date.

Columns:
- `ticker`: Option contract ticker
- `date`: Trading date
- `open`, `high`, `low`, `close`: Price data
- `volume`: Trading volume
- `vwap`: Volume-weighted average price
- `transactions`: Number of transactions

### Chain Snapshots (Subdatasets)
One subdataset per underlying, containing:
- Greeks (delta, gamma, theta, vega)
- Implied volatility
- Open interest
- Bid/ask spreads

## Usage

```python
import warpdata as wd

# Load grouped daily
df = wd.load("warpdata://options/<dataset>", as_format="pandas")

# Load chain snapshot for SPY
spy_chain = wd.load("warpdata://options/<dataset>-chain_spy", as_format="pandas")

# Filter by date
jan_data = df[df['date'] == '2024-01-15']
```
"""

    # Track raw data provenance
    raw_data_paths = []
    if raw_dir.exists():
        raw_data_paths.append(raw_dir.absolute())

    return RecipeOutput(
        main=output_files,
        subdatasets=subdatasets,
        docs={"README.md": readme},
        metadata=metadata,
        raw_data=raw_data_paths,
    )
