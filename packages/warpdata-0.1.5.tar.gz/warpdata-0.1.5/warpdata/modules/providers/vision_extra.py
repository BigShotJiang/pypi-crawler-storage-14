from __future__ import annotations
from ..base import BaseWarpDatasetModule


class CelebAAttrsModule(BaseWarpDatasetModule):
    id = "warp.dataset.celeba_attrs"
    version = "1.0.0"
    dataset_uri = "warpdata://vision/celeba-attrs"

