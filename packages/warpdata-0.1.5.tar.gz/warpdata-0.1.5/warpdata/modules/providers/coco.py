from __future__ import annotations
from ..base import BaseWarpDatasetModule


class CocoModule(BaseWarpDatasetModule):
    """Provider for vision/coco dataset (all splits combined)."""

    id = "warp.dataset.coco"
    version = "1.0.0"
    dataset_uri = "warpdata://vision/coco"


class CocoTrainModule(BaseWarpDatasetModule):
    """Provider for vision/coco-train dataset (train split)."""

    id = "warp.dataset.coco_train"
    version = "1.0.0"
    dataset_uri = "warpdata://vision/coco-train"


class CocoValModule(BaseWarpDatasetModule):
    """Provider for vision/coco-val dataset (val split)."""

    id = "warp.dataset.coco_val"
    version = "1.0.0"
    dataset_uri = "warpdata://vision/coco-val"

