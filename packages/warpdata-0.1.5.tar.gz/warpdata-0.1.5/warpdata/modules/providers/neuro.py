from __future__ import annotations
from ..base import BaseWarpDatasetModule
import warpdata as wd
from typing import Optional, Any, Dict


class DMTBrainsModule(BaseWarpDatasetModule):
    id = "warp.dataset.dmt_brains"
    version = "1.0.0"
    dataset_uri = "warpdata://neuro/dmt-brains"

    def ensure_signals(
        self,
        data_dir: str,
        window_sec: float = 2.0,
        step_sec: float = 1.0,
        max_channels: Optional[int] = None,
        with_materialize: bool = False,
        **kwargs,
    ) -> Dict[str, Any]:
        """
        Ensure the signals subdataset exists by running the recipe if needed.

        Args:
            data_dir: Path to raw EEG directory (with .bdf/.xdf and scales_results.csv)
            window_sec: Window length in seconds
            step_sec: Step length in seconds
            max_channels: Optional limit on number of EEG channels
            with_materialize: Materialize after registration

        Returns: result dict from wd.run_recipe
        """
        return wd.run_recipe(
            "dmt_brains",
            self.dataset_uri,
            data_dir=data_dir,
            include_signals=True,
            window_sec=window_sec,
            step_sec=step_sec,
            max_channels=max_channels,
            with_materialize=with_materialize,
            **kwargs,
        )

    def load_signals(self, as_format: str = "pandas") -> Any:
        """Load windowed EEG signals from the main dataset's 'signals' table."""
        return wd.load_table(self.dataset_uri, table="signals", as_format=as_format)
