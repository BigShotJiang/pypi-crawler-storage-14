from __future__ import annotations
from ..base import BaseWarpDatasetModule


class WineModule(BaseWarpDatasetModule):
    id = "warp.dataset.wine"
    version = "1.0.0"
    dataset_uri = "warpdata://uci/wine"

