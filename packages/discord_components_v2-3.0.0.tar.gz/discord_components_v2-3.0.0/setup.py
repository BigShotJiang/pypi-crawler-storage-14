from setuptools import setup, find_packages

setup(
    name="discord_components_v2",
    version="3.0.0",
    author="venxsa",
    author_email="little.f3x@gmail.com",
    description="An unofficial library for discord components v2.",
    long_description=open("README.md", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    url="https://github.com/venxsa/discord.py-components-v2",
    packages=find_packages(),
    python_requires=">=3.8",
    install_requires=[
        "discord.py",
        "aiohttp"
    ],
    include_package_data=True,
    classifiers=[
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Intended Audience :: Developers",
        "Topic :: Software Development :: Libraries :: Python Modules"
    ],
)
