import sys, traceback
from fansi_text import Yellow, Bold

def warn(message: str, warn_type: str = "Warning") -> None:
    """Print a formatted warning with traceback and yellow text.

    Args:
        message (str): The main warning text to display.
        warn_type (str, optional): An optional custom name for the warning; displayed in bold. Defaults to "Warning".
    """
    exc_type, exc_value, exc_traceback = sys.exc_info()

    frame = exc_traceback.tb_frame
    line_of_code = traceback.extract_tb(exc_traceback)[0].line

    out = f'''\
  File "{frame.f_code.co_filename}", line {frame.f_lineno}
     {line_of_code}
{Yellow(f"{Bold(warn_type)}: {message}")}'''

    print(out)