# PharmaAPI Python Client

A Python client library for the PharmaAPI - search and retrieve pharmaceutical data from French and US databases.

## Installation
```bash
pip install pharmapi
```

## Quick Start
```python
from pharmapi import PharmaAPIClient

# Initialize client
client = PharmaAPIClient(api_key="your-api-key")

# Search for products
response = client.search_by_ingredient("indapamide", limit=10)

# Convert to pandas DataFrame
df = response.to_df()
print(df.head())

# Clean up
client.close()
```

## Features

- 🔍 Search by name, ingredient, dosage form, strength
- 💊 Get product details by CIS ID or RxNorm code
- 💰 Access pricing information (French and US)
- 🔬 Professional tier: ATC codes, NDC lookup, US product names
- 📊 Easy DataFrame conversion with `.to_df()`
- 🛡️ Type hints and comprehensive error handling

## 📖 Documentation & Examples

- [Tutotial](https://dev.pharmapi.dynv6.net/notebook)
- [API Reference](https://dev.pharmapi.dynv6.net/docs)

## Requirements

- Python 3.7+
- requests
- pandas

## License

MIT License