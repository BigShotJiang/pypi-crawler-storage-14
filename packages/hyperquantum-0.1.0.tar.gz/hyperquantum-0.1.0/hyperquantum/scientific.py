"""
A lightweight scientific computing module inspired by SciPy.
Requires: numpy
This is not a full replacement for SciPy, but has basic features.
"""

import numpy as np
from math import sqrt, exp, log

# ================================================================
# SECTION 1 — Linear Algebra
# ================================================================

class linalg:
    @staticmethod
    def dot(a, b):
        return np.dot(a, b)

    @staticmethod
    def matmul(a, b):
        return np.matmul(a, b)

    @staticmethod
    def det(a):
        return np.linalg.det(a)

    @staticmethod
    def inv(a):
        return np.linalg.inv(a)

    @staticmethod
    def eig(a):
        return np.linalg.eig(a)

    @staticmethod
    def solve(a, b):
        return np.linalg.solve(a, b)


# ================================================================
# SECTION 2 — Statistics
# ================================================================

class stats:
    @staticmethod
    def mean(a):
        return np.mean(a)

    @staticmethod
    def median(a):
        return np.median(a)

    @staticmethod
    def var(a):
        return np.var(a)

    @staticmethod
    def std(a):
        return np.std(a)

    @staticmethod
    def corr(a, b):
        return np.corrcoef(a, b)[0, 1]

    @staticmethod
    def normalize(a):
        a = np.array(a)
        return (a - a.mean()) / a.std()


# ================================================================
# SECTION 3 — Calculus
# ================================================================

class calculus:
    @staticmethod
    def derivative(f, x, h=1e-5):
        return (f(x + h) - f(x - h)) / (2 * h)

    @staticmethod
    def integral(f, a, b, n=10000):
        x = np.linspace(a, b, n)
        y = np.vectorize(f)(x)
        return np.trapz(y, x)

    @staticmethod
    def solve_ode(f, y0, t):
        """Simple Euler ODE solver: dy/dt = f(y, t)"""
        y = y0
        values = [y0]
        for i in range(1, len(t)):
            dt = t[i] - t[i-1]
            y = y + dt * f(y, t[i-1])
            values.append(y)
        return np.array(values)


# ================================================================
# SECTION 4 — Optimization
# ================================================================

class optimize:
    @staticmethod
    def gradient_descent(f, x0, lr=0.01, steps=1000):
        x = x0
        for _ in range(steps):
            grad = calculus.derivative(f, x)
            x -= lr * grad
        return x


# ================================================================
# SECTION 5 — Interpolation
# ================================================================

class interpolate:
    @staticmethod
    def linear(x, xp, fp):
        return np.interp(x, xp, fp)

    @staticmethod
    def nearest(x, xp, fp):
        idx = np.argmin(np.abs(np.array(xp) - x))
        return fp[idx]


# ================================================================
# SECTION 6 — Signal Processing
# ================================================================

class signal:
    @staticmethod
    def convolve(a, b):
        return np.convolve(a, b)

    @staticmethod
    def fir_filter(signal, kernel):
        return np.convolve(signal, kernel, mode='same')

    @staticmethod
    def moving_average(a, window=3):
        kernel = np.ones(window) / window
        return np.convolve(a, kernel, mode='same')


# ================================================================
# SECTION 7 — Numerics
# ================================================================

class numerical:
    @staticmethod
    def roots(f, x0, max_iter=50):
        """Newton root finding"""
        x = x0
        for _ in range(max_iter):
            d = calculus.derivative(f, x)
            if d == 0:
                break
            x = x - f(x) / d
        return x

    @staticmethod
    def clamp(x, lo, hi):
        return max(lo, min(hi, x))


# ================================================================
# END OF MODULE
# ================================================================

if __name__ == "__main__":
    print("Scientific module loaded successfully.")
