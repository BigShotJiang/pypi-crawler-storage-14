"""
Pedagogical MiniNumPy — pure Python reimplementation of many NumPy features.

This module is intentionally educational: functions are written in straightforward
Python (lists, recursion) so you can read and learn how operations like broadcasting,
matrix multiplication, FFT, and linear algebra algorithms work.

NOT for production numerical work — use NumPy for performance.
"""

from __future__ import annotations
import math
import random
import cmath
import csv
import struct
import itertools
import sys
from typing import Any, Callable, Iterable, List, Tuple, Union, Optional

# ------------------------------
# Utilities for nested lists
# ------------------------------

def _is_sequence(x):
    return isinstance(x, (list, tuple))

def _ensure_list(x):
    if isinstance(x, tuple):
        return list(x)
    return x

def _deep_copy(obj):
    if _is_sequence(obj):
        return [_deep_copy(x) for x in obj]
    else:
        return obj

def _shape_of(x):
    """
    Determine shape of nested list structure.
    Ragged arrays will be treated as 1-D at the top-level.
    """
    if not _is_sequence(x):
        return ()
    if len(x) == 0:
        return (0,)
    # check if all inner shapes same
    first_shape = _shape_of(x[0])
    for el in x:
        if _shape_of(el) != first_shape:
            # ragged -> treat as 1-D
            return (len(x),)
    return (len(x),) + first_shape

def _flatten(x, out=None):
    """
    Flatten nested lists (depth-first). Returns Python list.
    """
    if out is None:
        out = []
    if not _is_sequence(x):
        out.append(x)
    else:
        for el in x:
            _flatten(el, out)
    return out

def _build_from_flat(flat: List[Any], shape: Tuple[int, ...]):
    """
    Build nested list from flat list according to shape tuple.
    flat is consumed from index 0 onwards.
    """
    if len(shape) == 0:
        return flat.pop(0)
    size = shape[0]
    res = []
    for _ in range(size):
        res.append(_build_from_flat(flat, shape[1:]))
    return res

def _prod(shape: Tuple[int, ...]) -> int:
    p = 1
    for d in shape:
        p *= d
    return p

def _iter_indices(shape: Tuple[int, ...]):
    """
    Yield all index tuples for given shape.
    """
    if not shape:
        yield ()
        return
    ranges = [range(s) for s in shape]
    for idx in itertools.product(*ranges):
        yield idx

def _get_at(nested, idx: Tuple[int, ...]):
    v = nested
    for i in idx:
        v = v[i]
    return v

def _set_at(nested, idx: Tuple[int, ...], value):
    v = nested
    for i in idx[:-1]:
        v = v[i]
    v[idx[-1]] = value

# ------------------------------
# NDArray class
# ------------------------------

class NDArray:
    """A simple n-dimensional array backed by nested Python lists."""
    def __init__(self, data: Any):
        # Accept scalars, lists, tuples, other NDArrays
        if isinstance(data, NDArray):
            self._data = _deep_copy(data._data)
        else:
            if _is_sequence(data):
                self._data = _deep_copy(list(data))
            else:
                self._data = data
        self.shape = _shape_of(self._data)

    def __repr__(self):
        return f"NDArray(shape={self.shape}, data={self._data})"

    def tolist(self):
        return _deep_copy(self._data)

    def flatten(self) -> NDArray:
        return NDArray(_flatten(self._data))

    def size(self) -> int:
        return _prod(self.shape)

    def ndim(self) -> int:
        return len(self.shape)

    # indexing supports ints, slices, tuple of ints/slices
    def __getitem__(self, idx):
        if isinstance(idx, tuple):
            data = self._data
            for k in idx:
                data = data[k]
            return NDArray(data)
        else:
            return NDArray(self._data[idx])

    def __setitem__(self, idx, value):
        if isinstance(idx, tuple):
            if not _is_sequence(value):
                _set_at(self._data, idx, value)
            else:
                _set_at(self._data, idx, _deep_copy(value))
        else:
            self._data[idx] = _deep_copy(value)

    # conversion to scalar for 0-D arrays
    def scalar(self):
        if self.shape == ():
            return self._data
        if self.shape == (1,) and not _is_sequence(self._data):
            return self._data
        raise ValueError("Not a scalar NDArray")

    # basic reductions
    def sum(self):
        return sum(_flatten(self._data))

    def mean(self):
        flat = _flatten(self._data)
        return sum(flat) / len(flat) if flat else 0.0

    def min(self):
        flat = _flatten(self._data)
        return min(flat)

    def max(self):
        flat = _flatten(self._data)
        return max(flat)

# ------------------------------
# Creation helpers
# ------------------------------

def array(obj) -> NDArray:
    """Create NDArray from nested lists or scalar."""
    return NDArray(obj)

def zeros(shape: Union[int, Tuple[int, ...]]):
    if isinstance(shape, int):
        shape = (shape,)
    total = _prod(shape)
    flat = [0]*total
    nested = _build_from_flat(flat[:], tuple(shape))
    return NDArray(nested)

def ones(shape: Union[int, Tuple[int, ...]]):
    if isinstance(shape, int):
        shape = (shape,)
    total = _prod(shape)
    flat = [1]*total
    nested = _build_from_flat(flat[:], tuple(shape))
    return NDArray(nested)

def full(shape: Union[int, Tuple[int, ...]], value):
    if isinstance(shape, int):
        shape = (shape,)
    total = _prod(shape)
    flat = [value]*total
    nested = _build_from_flat(flat[:], tuple(shape))
    return NDArray(nested)

def arange(start, stop=None, step=1):
    if stop is None:
        stop = start
        start = 0
    flat = list(range(start, stop, step))
    return NDArray(flat)

def linspace(start, stop, num=50):
    if num == 1:
        return NDArray([start])
    step = (stop - start) / (num - 1)
    flat = [start + i*step for i in range(num)]
    return NDArray(flat)

def eye(n):
    mat = []
    for i in range(n):
        row = [0]*n
        row[i] = 1
        mat.append(row)
    return NDArray(mat)

# ------------------------------
# Broadcasting helpers
# ------------------------------

def _broadcast_shape(shape_a: Tuple[int, ...], shape_b: Tuple[int, ...]) -> Tuple[int, ...]:
    la = len(shape_a)
    lb = len(shape_b)
    out = []
    for i in range(1, max(la, lb)+1):
        da = shape_a[-i] if i <= la else 1
        db = shape_b[-i] if i <= lb else 1
        if da == db or da == 1 or db == 1:
            out.append(max(da, db))
        else:
            raise ValueError(f"shapes {shape_a} and {shape_b} not broadcastable")
    return tuple(reversed(out))

def _index_for_shape(out_idx: Tuple[int,...], src_shape: Tuple[int,...]):
    """
    Map an index in the broadcasted output to index in source with src_shape.
    Right-align shapes.
    """
    if not src_shape:
        return ()
    offset = len(out_idx) - len(src_shape)
    res = []
    for i, dim in enumerate(src_shape):
        outdim = out_idx[offset + i]
        if dim == 1:
            res.append(0)
        else:
            res.append(outdim)
    return tuple(res)

# ------------------------------
# Elementwise operations with broadcasting
# ------------------------------

def _binary_op(a: NDArray, b: Union[NDArray, int, float], op: Callable[[Any,Any],Any]) -> NDArray:
    if not isinstance(a, NDArray):
        a = NDArray(a)
    if not isinstance(b, NDArray):
        b = NDArray(b)
    out_shape = _broadcast_shape(a.shape, b.shape)
    flat = []
    for idx in _iter_indices(out_shape):
        ia = _index_for_shape(idx, a.shape) if a.shape else ()
        ib = _index_for_shape(idx, b.shape) if b.shape else ()
        va = _get_at(a._data, ia) if ia != () else a._data
        vb = _get_at(b._data, ib) if ib != () else b._data
        flat.append(op(va, vb))
    nested = _build_from_flat(flat[:], out_shape)
    return NDArray(nested)

# arithmetic ops
def add(a, b): return _binary_op(a, b, lambda x,y: x + y)
def sub(a, b): return _binary_op(a, b, lambda x,y: x - y)
def mul(a, b): return _binary_op(a, b, lambda x,y: x * y)
def div(a, b): return _binary_op(a, b, lambda x,y: x / y)
def pow_(a, b): return _binary_op(a, b, lambda x,y: x ** y)

# in-place convenience operators (modify first)
def iadd(a: NDArray, b):
    res = add(a, b)
    a._data = res._data; a.shape = res.shape
    return a

def imul(a: NDArray, b):
    res = mul(a, b)
    a._data = res._data; a.shape = res.shape
    return a

# ------------------------------
# Universal functions (ufuncs)
# ------------------------------
def _make_ufunc(pyfn: Callable[[Any],Any]) -> Callable[[NDArray], NDArray]:
    def ufunc(x):
        if not isinstance(x, NDArray):
            x = NDArray(x)
        flat = _flatten(x._data)
        out = [_deep_copy(pyfn(v)) for v in flat]
        nested = _build_from_flat(out[:], x.shape)
        return NDArray(nested)
    return ufunc

sin = _make_ufunc(math.sin)
cos = _make_ufunc(math.cos)
tan = _make_ufunc(math.tan)
exp = _make_ufunc(math.exp)
log = _make_ufunc(math.log)
sqrt = _make_ufunc(math.sqrt)
abs_ = _make_ufunc(abs)

# ------------------------------
# Indexing utilities (boolean mask & fancy)
# ------------------------------

def where(cond: NDArray) -> List[int]:
    """
    Return flat indices where cond is True.
    """
    flat = _flatten(cond._data)
    return [i for i,v in enumerate(flat) if v]

def boolean_mask(arr: NDArray, mask: NDArray) -> NDArray:
    flat_arr = _flatten(arr._data)
    flat_mask = _flatten(mask._data)
    res = [a for a,m in zip(flat_arr, flat_mask) if m]
    return NDArray(res)

# ------------------------------
# Reshape / transpose / stack
# ------------------------------

def reshape(a: NDArray, shape: Tuple[int,...]) -> NDArray:
    flat = _flatten(a._data)
    if _prod(shape) != len(flat):
        raise ValueError("cannot reshape array of size {} into shape {}".format(len(flat), shape))
    nested = _build_from_flat(flat[:], tuple(shape))
    return NDArray(nested)

def transpose(a: NDArray, axes: Optional[Tuple[int,...]]=None) -> NDArray:
    if axes is None:
        if len(a.shape) != 2:
            raise NotImplementedError("transpose default axes only for 2D")
        rows, cols = a.shape
        mat = [[_get_at(a._data, (i,j)) for i in range(rows)] for j in range(cols)]
        return NDArray(mat)
    else:
        # generic axes permutation
        if len(axes) != len(a.shape):
            raise ValueError("axes must match dimensions")
        # permute by iterating all indices and rearranging
        out_shape = tuple(a.shape[ax] for ax in axes)
        flat = []
        for idx in _iter_indices(out_shape):
            src_idx = tuple(idx[axes.index(i)] for i in range(len(axes)))
            flat.append(_get_at(a._data, src_idx))
        nested = _build_from_flat(flat[:], out_shape)
        return NDArray(nested)

def vstack(arrays: List[NDArray]) -> NDArray:
    lists = [a._data for a in arrays]
    return NDArray(lists)

def hstack(arrays: List[NDArray]) -> NDArray:
    # simple for 2D arrays: concatenate columns
    rows = len(arrays[0]._data)
    out = []
    for r in range(rows):
        row = []
        for a in arrays:
            row.extend(a._data[r])
        out.append(row)
    return NDArray(out)

# ------------------------------
# Dot & matmul (ND-aware)
# ------------------------------

def dot(a: NDArray, b: NDArray) -> NDArray:
    # Flatten if 1D vectors; if 2D: treat as matrix multiplication
    if len(a.shape) == 1 and len(b.shape) == 1:
        fa = _flatten(a._data); fb = _flatten(b._data)
        return sum(x*y for x,y in zip(fa, fb))
    if len(a.shape) == 2 and len(b.shape) == 2:
        return matmul(a,b)
    # other cases: contract last axis of a with last axis of b
    raise NotImplementedError("dot supports 1D·1D and 2D·2D in this pedagogical version")

def matmul(a: NDArray, b: NDArray) -> NDArray:
    if len(a.shape) != 2 or len(b.shape) != 2:
        raise NotImplementedError("matmul supports 2D arrays only")
    m,n = a.shape; n2,p = b.shape
    if n != n2:
        raise ValueError("shapes not aligned for matmul")
    out = []
    for i in range(m):
        row = []
        for j in range(p):
            s = 0
            for k in range(n):
                s += _get_at(a._data, (i,k)) * _get_at(b._data, (k,j))
            row.append(s)
        out.append(row)
    return NDArray(out)

# ------------------------------
# Linear algebra: solve, inv, det, norm
# ------------------------------

def _gauss_jordan(matrix: List[List[float]], eps=1e-12):
    """
    Perform Gauss-Jordan elimination and return the inverse.
    matrix is a square list-of-lists (will be copied).
    Returns inverse as nested list.
    """
    n = len(matrix)
    A = [row[:] for row in matrix]
    # build identity
    I = [[1.0 if i==j else 0.0 for j in range(n)] for i in range(n)]
    for col in range(n):
        # find pivot
        pivot = col
        while pivot < n and abs(A[pivot][col]) < eps:
            pivot += 1
        if pivot == n:
            raise ValueError("Matrix is singular")
        # swap
        if pivot != col:
            A[col], A[pivot] = A[pivot], A[col]
            I[col], I[pivot] = I[pivot], I[col]
        # normalize pivot row
        pivval = A[col][col]
        A[col] = [v / pivval for v in A[col]]
        I[col] = [v / pivval for v in I[col]]
        # eliminate other rows
        for r in range(n):
            if r == col: continue
            factor = A[r][col]
            if factor == 0: continue
            A[r] = [a - factor*b for a,b in zip(A[r], A[col])]
            I[r] = [a - factor*b for a,b in zip(I[r], I[col])]
    return I

def inv(a: NDArray) -> NDArray:
    if len(a.shape) != 2 or a.shape[0] != a.shape[1]:
        raise ValueError("inv requires square 2D array")
    M = [list(map(float, row)) for row in a._data]
    I = _gauss_jordan(M)
    return NDArray(I)

def solve(A: NDArray, b: NDArray) -> NDArray:
    """
    Solve Ax = b for x. Uses Gaussian elimination (via augmented matrix).
    A: n x n, b: n or n x k
    """
    if len(A.shape) != 2:
        raise ValueError("A must be 2D")
    n = A.shape[0]
    if b.shape == (n,):
        # vector
        B = [[_get_at(b._data, (i,)) if len(b.shape)>0 else b._data[i] for _ in range(1)][0] for i in range(n)]
        # transform b to list
        bcol = _flatten(b._data)
        # build augmented matrix
        M = [ [float(A._data[i][j]) for j in range(n)] + [float(bcol[i])] for i in range(n) ]
        # forward elimination
        for k in range(n):
            # pivot
            i_max = max(range(k,n), key=lambda i: abs(M[i][k]))
            if abs(M[i_max][k]) < 1e-12:
                raise ValueError("Matrix is singular")
            M[k], M[i_max] = M[i_max], M[k]
            # normalize
            pivot = M[k][k]
            M[k] = [val / pivot for val in M[k]]
            for i in range(n):
                if i == k: continue
                factor = M[i][k]
                M[i] = [M[i][j] - factor*M[k][j] for j in range(n+1)]
        x = [row[-1] for row in M]
        return NDArray(x)
    else:
        # handle many RHS by solving per column
        raise NotImplementedError("solve supports vector b in this pedagogical version")

def det(a: NDArray) -> float:
    """
    Compute determinant via LU-ish recursion (works for small n).
    This is pedagogical; complexity is O(n!).
    We'll implement via LU (Doolittle) for better behavior.
    """
    n = a.shape[0]
    if n != a.shape[1]:
        raise ValueError("det requires square matrix")
    # LU decomposition with partial pivoting
    M = [ [float(v) for v in row] for row in a._data ]
    n = len(M)
    det_sign = 1
    for k in range(n):
        # find pivot
        i_max = max(range(k,n), key=lambda i: abs(M[i][k]))
        if abs(M[i_max][k]) < 1e-12:
            return 0.0
        if i_max != k:
            M[k], M[i_max] = M[i_max], M[k]
            det_sign *= -1
        pivot = M[k][k]
        for i in range(k+1, n):
            M[i][k] /= pivot
            for j in range(k+1, n):
                M[i][j] -= M[i][k]*M[k][j]
    # determinant is product of U diagonal times sign
    prod = det_sign
    for i in range(n):
        prod *= M[i][i]
    return prod

def norm(a: NDArray, ord: Optional[int]=2) -> float:
    flat = _flatten(a._data)
    if ord == 2 or ord is None:
        return math.sqrt(sum(x*x for x in flat))
    if ord == 1:
        return sum(abs(x) for x in flat)
    raise NotImplementedError("only ord=1 or 2 supported")

# ------------------------------
# QR via Gram-Schmidt (pedagogical)
# ------------------------------

def qr(A: NDArray) -> Tuple[NDArray, NDArray]:
    """
    Return Q, R where A = Q R.
    A: m x n
    """
    if len(A.shape) != 2:
        raise ValueError("qr expects 2D matrix")
    m,n = A.shape
    # convert columns to vectors
    cols = []
    for j in range(n):
        col = [_get_at(A._data, (i,j)) for i in range(m)]
        cols.append(col)
    Qcols = []
    R = [[0.0]*n for _ in range(n)]
    for j in range(n):
        v = cols[j][:]
        for i in range(len(Qcols)):
            qi = Qcols[i]
            # R[i][j] = qi dot v
            r = sum(qi[k]*v[k] for k in range(m))
            R[i][j] = r
            v = [v[k] - r*qi[k] for k in range(m)]
        normv = math.sqrt(sum(x*x for x in v))
        if normv < 1e-12:
            q = [0.0]*m
        else:
            q = [x / normv for x in v]
        Qcols.append(q)
        R[j][j] = normv
    # build Q matrix as m x n (orthonormal cols)
    Qmat = [ [Qcols[j][i] for j in range(n)] for i in range(m) ]
    return NDArray(Qmat), NDArray(R)

# ------------------------------
# SVD approximation (thin SVD via power iteration)
# ------------------------------

def _power_iteration(Amat: List[List[float]], num_iter=50):
    """
    Compute dominant eigenvector of A^T A (symmetric) using power iteration.
    Amat: m x n matrix (list of lists)
    returns vector size n (dominant singular vector)
    """
    m = len(Amat); n = len(Amat[0])
    # start with random vector
    v = [random.random() for _ in range(n)]
    # normalize
    normv = math.sqrt(sum(x*x for x in v))
    v = [x/normv for x in v]
    for _ in range(num_iter):
        # w = A^T (A v)
        # compute u = A v
        u = [ sum(Amat[i][j]*v[j] for j in range(n)) for i in range(m) ]
        # w = A^T u
        w = [ sum(Amat[i][j]*u[i] for i in range(m)) for j in range(n) ]
        normw = math.sqrt(sum(x*x for x in w))
        if normw == 0:
            break
        v = [x / normw for x in w]
    # approximate singular value sigma = ||A v||
    u = [ sum(Amat[i][j]*v[j] for j in range(n)) for i in range(m) ]
    sigma = math.sqrt(sum(x*x for x in u))
    return v, sigma, u

def svd_approx(A: NDArray, k: Optional[int]=None) -> Tuple[NDArray, NDArray, NDArray]:
    """
    Thin SVD approximation computing k leading singular values/vectors.
    Uses iterative deflation with power iteration. Pedagogical and approximate.
    Returns U (m x k), S (k,), Vt (k x n)
    """
    if len(A.shape) != 2:
        raise ValueError("svd_approx expects 2D matrix")
    m,n = A.shape
    if k is None:
        k = min(m,n)
    # copy matrix
    Amat = [row[:] for row in A._data]
    Ucols = []
    S = []
    Vrows = []
    for _ in range(k):
        v, sigma, uvec = _power_iteration(Amat)
        if sigma < 1e-10:
            break
        # normalize uvec
        if sigma != 0:
            uvec_norm = [x/sigma for x in uvec]
        else:
            uvec_norm = uvec
        Ucols.append(uvec_norm)
        S.append(sigma)
        Vrows.append(v)
        # deflate: A = A - sigma * (uvec_norm outer v)
        for i in range(m):
            for j in range(n):
                Amat[i][j] -= sigma * uvec_norm[i] * v[j]
    # build U as m x k, Vt as k x n
    U = [ [Ucols[j][i] for j in range(len(Ucols))] for i in range(m) ] if Ucols else [[0]*0 for _ in range(m)]
    Vt = [ row[:] for row in Vrows ]
    return NDArray(U), NDArray(S), NDArray(Vt)

# ------------------------------
# FFT (Cooley-Tukey recursive)
# ------------------------------

def _next_pow2(n):
    p = 1
    while p < n:
        p <<= 1
    return p

def fft(arr: NDArray) -> NDArray:
    """
    Compute FFT of 1D array arr (list-like). Zero-pads to next power of two.
    Returns NDArray of complex numbers.
    """
    flat = _flatten(arr._data)
    n = len(flat)
    m = _next_pow2(n)
    data = [complex(x) for x in flat] + [0]*(m-n)
    def _fft(a):
        N = len(a)
        if N == 1:
            return a
        even = _fft(a[0::2])
        odd = _fft(a[1::2])
        out = [0]*N
        for k in range(N//2):
            t = cmath.exp(-2j*math.pi*k/N) * odd[k]
            out[k] = even[k] + t
            out[k+N//2] = even[k] - t
        return out
    return NDArray(_fft(data))

def ifft(arr: NDArray) -> NDArray:
    flat = _flatten(arr._data)
    data = [complex(x) for x in flat]
    def _ifft(a):
        N = len(a)
        if N == 1:
            return a
        even = _ifft(a[0::2])
        odd = _ifft(a[1::2])
        out = [0]*N
        for k in range(N//2):
            t = cmath.exp(2j*math.pi*k/N) * odd[k]
            out[k] = even[k] + t
            out[k+N//2] = even[k] - t
        return out
    out = _ifft(data)
    N = len(out)
    return NDArray([x / N for x in out])

# ------------------------------
# Signal processing helpers
# ------------------------------

def convolve(a: NDArray, b: NDArray, mode='full') -> NDArray:
    fa = _flatten(a._data)
    fb = _flatten(b._data)
    la, lb = len(fa), len(fb)
    out_len = la + lb - 1
    out = [0]*out_len
    for i in range(la):
        for j in range(lb):
            out[i+j] += fa[i]*fb[j]
    if mode == 'full':
        return NDArray(out)
    elif mode == 'same':
        start = (lb-1)//2
        return NDArray(out[start:start+la])
    elif mode == 'valid':
        return NDArray(out[lb-1:la])
    else:
        raise ValueError("unknown mode")

def moving_average(a: NDArray, window: int=3) -> NDArray:
    fa = _flatten(a._data)
    n = len(fa)
    out = []
    for i in range(n):
        s = 0.0
        cnt = 0
        for j in range(i - window//2, i + window//2 + 1):
            if 0 <= j < n:
                s += fa[j]; cnt += 1
        out.append(s / cnt if cnt else 0.0)
    return NDArray(out)

# ------------------------------
# Random utilities (pure python)
# ------------------------------
_randstate = random.Random()

def seed(s: Optional[int]):
    _randstate.seed(s)

def rand(shape: Union[int, Tuple[int,...]] = None) -> NDArray:
    if shape is None:
        return NDArray(_randstate.random())
    if isinstance(shape, int):
        return NDArray([_randstate.random() for _ in range(shape)])
    flat = [_randstate.random() for _ in range(_prod(shape))]
    nested = _build_from_flat(flat, tuple(shape))
    return NDArray(nested)

def randint(low: int, high: Optional[int]=None, size: Union[int, Tuple[int,...], None]=None) -> NDArray:
    if high is None:
        high = low
        low = 0
    if size is None:
        return NDArray(_randstate.randint(low, high))
    if isinstance(size, int):
        return NDArray([_randstate.randint(low, high) for _ in range(size)])
    flat = [_randstate.randint(low, high) for _ in range(_prod(size))]
    nested = _build_from_flat(flat, tuple(size))
    return NDArray(nested)

def normal(mean=0.0, std=1.0, size: Optional[Union[int, Tuple[int,...]]]=None) -> NDArray:
    if size is None:
        return NDArray(_randstate.gauss(mean, std))
    if isinstance(size, int):
        return NDArray([_randstate.gauss(mean, std) for _ in range(size)])
    flat = [_randstate.gauss(mean, std) for _ in range(_prod(size))]
    nested = _build_from_flat(flat, tuple(size))
    return NDArray(nested)

def permutation(x: Iterable) -> NDArray:
    lst = list(x)
    _randstate.shuffle(lst)
    return NDArray(lst)

# ------------------------------
# File IO: CSV and simple binary
# ------------------------------

def save_csv(path: str, arr: NDArray):
    if len(arr.shape) != 2:
        raise ValueError("save_csv expects 2D array")
    with open(path, "w", newline="") as f:
        w = csv.writer(f)
        for row in arr._data:
            w.writerow(row)

def load_csv(path: str, dtype=float) -> NDArray:
    rows = []
    with open(path, newline="") as f:
        r = csv.reader(f)
        for row in r:
            rows.append([dtype(x) for x in row])
    return NDArray(rows)

def save_bin(path: str, arr: NDArray):
    flat = _flatten(arr._data)
    with open(path, "wb") as f:
        f.write(struct.pack("<I", arr.size()))
        for v in flat:
            f.write(struct.pack("<d", float(v)))

def load_bin(path: str) -> NDArray:
    with open(path, "rb") as f:
        n_bytes = f.read(4)
        n = struct.unpack("<I", n_bytes)[0]
        flat = [struct.unpack("<d", f.read(8))[0] for _ in range(n)]
    return NDArray(flat)

# ------------------------------
# Vectorize helper
# ------------------------------

def vectorize(pyfn: Callable[[Any],Any]):
    def vec(arr):
        flat = _flatten(arr._data) if isinstance(arr, NDArray) else arr
        out = [pyfn(x) for x in flat]
        if isinstance(arr, NDArray):
            nested = _build_from_flat(out[:], arr.shape)
            return NDArray(nested)
        return out
    return vec

# ------------------------------
# Utility printing / pretty
# ------------------------------

def pprint(arr: NDArray, max_width=80):
    print("NDArray shape:", arr.shape)
    s = str(arr._data)
    if len(s) > max_width:
        print(s[:max_width] + " ...")
    else:
        print(s)

# ------------------------------
# Tests / Demo
# ------------------------------

def _smoke_tests():
    print("Running smoke tests for pedagogical_mininumpy...")
    a = array([[1,2,3],[4,5,6]])
    b = array([[7,8,9],[10,11,12]])
    print("a:", a)
    print("b:", b)
    print("a + b:", add(a,b))
    print("a * 2:", mul(a,2))
    v = arange(5)
    print("v:", v)
    print("v linspace:", linspace(0,1,5))
    print("dot product:", dot(array([1,2,3]), array([4,5,6])))
    print("matmul a.T @ a:", matmul(transpose(a), a))
    print("det of 2x2:", det(array([[4,7],[2,6]])))
    A = array([[4,7],[2,6]])
    print("inv of A:", inv(A))
    # FFT test
    print("fft of [1,0,0,0]:", fft(array([1,0,0,0])))
    # random
    seed(42)
    print("rand(5):", rand(5))
    print("normal 2x2:", normal(0,1,(2,2)))
    # qr
    Q,R = qr(array([[1.0,2.0],[3.0,4.0]]))
    print("Q:", Q)
    print("R:", R)
    # svd approx
    U,S,Vt = svd_approx(array([[1.0,2.0],[3.0,4.0]]), k=2)
    print("S (approx):", S)
    print("convolve [1,2,3] with [0,1,0.5]:", convolve(array([1,2,3]), array([0,1,0.5])))
    print("moving average:", moving_average(array([1,2,3,4,5]), window=3))
    print("done.")

if __name__ == "__main__":
    _smoke_tests()
