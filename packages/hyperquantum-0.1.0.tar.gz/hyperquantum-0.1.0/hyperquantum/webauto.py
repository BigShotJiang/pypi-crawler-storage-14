# webauto.py
# Ultra-Advanced Web Automation + Scraping Engine
# Requires: playwright, aiohttp, bs4, rich

import asyncio
from playwright.async_api import async_playwright
import aiohttp
from bs4 import BeautifulSoup
from rich.console import Console
from rich.table import Table

console = Console()

class WebAuto:
    def __init__(self, headless=True):
        self.headless = headless
        self.browser = None
        self.context = None
        self.page = None

    async def start_browser(self):
        """Start the Playwright browser session."""
        pw = await async_playwright().start()
        self.browser = await pw.chromium.launch(headless=self.headless)
        self.context = await self.browser.new_context()
        self.page = await self.context.new_page()
        console.log("[green]Browser started successfully.")

    async def goto(self, url: str):
        """Navigate to a webpage."""
        if not self.page:
            await self.start_browser()
        await self.page.goto(url, wait_until="networkidle")
        console.log(f"[cyan]Navigated to {url}")

    async def get_html(self):
        """Return HTML content of current page."""
        if not self.page:
            raise RuntimeError("Browser not started!")
        html = await self.page.content()
        return html

    async def query(self, selector: str):
        """Return text of element using CSS selector."""
        element = await self.page.query_selector(selector)
        if element:
            return await element.text_content()
        return None

    async def fill(self, selector: str, text: str):
        """Fill input fields."""
        await self.page.fill(selector, text)
        console.log(f"[yellow]Filled {selector} with '{text}'")

    async def click(self, selector: str):
        """Click an element."""
        await self.page.click(selector)
        console.log(f"[yellow]Clicked {selector}")

    async def screenshot(self, file="screenshot.png"):
        """Take screenshot."""
        await self.page.screenshot(path=file)
        console.log(f"[magenta]Screenshot saved as {file}")

    async def js_exec(self, script: str):
        """Run custom JavaScript."""
        return await self.page.evaluate(script)

    async def scroll_to_bottom(self):
        """Scroll until the page ends."""
        console.log("[blue]Scrolling…")
        await self.page.evaluate("""
            () => {
                window.scrollTo(0, document.body.scrollHeight);
            }
        """)

    async def fetch(self, url: str) -> str:
        """Perform HTTP GET using aiohttp (API or raw HTML)."""
        async with aiohttp.ClientSession() as session:
            async with session.get(url) as res:
                return await res.text()

    async def scrape(self, url: str):
        """Fetch + BeautifulSoup scraper."""
        html = await self.fetch(url)
        soup = BeautifulSoup(html, "html.parser")

        # Display top-level tags as table
        table = Table(title=f"Scrape Results for {url}")
        table.add_column("Tag")
        table.add_column("Content")

        for tag in soup.find_all()[:10]:
            text = (tag.text or "").strip()
            table.add_row(tag.name, text[:75] + "…")

        console.print(table)
        return soup

    async def login(self, url: str, username_sel: str, password_sel: str,
                    submit_sel: str, username: str, password: str):
        """Login automation."""
        await self.goto(url)
        await self.fill(username_sel, username)
        await self.fill(password_sel, password)
        await self.click(submit_sel)
        console.log("[green]Login attempt completed.")

    async def close(self):
        """Close browser."""
        await self.browser.close()
        console.log("[red]Browser closed.")


# Helper function: quick scrape shortcut
async def quick_scrape(url: str):
    """Shortcut function for quick web scraping."""
    bot = WebAuto()
    await bot.start_browser()
    await bot.goto(url)
    data = await bot.get_html()
    await bot.close()
    return data

if __name__ == "__main__":
    async def main():
        wa = WebAuto(headless=False)
        await wa.start_browser()
        await wa.goto("https://example.com")
        print(await wa.query("h1"))
        await wa.screenshot("example.png")
        await wa.close()

    asyncio.run(main())
