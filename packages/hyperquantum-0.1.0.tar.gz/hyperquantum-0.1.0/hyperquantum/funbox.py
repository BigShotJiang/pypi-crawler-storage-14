#!/usr/bin/env python3
"""
funbox.py
A single-file fun toolkit combining:
 - meme generator (ASCII-style)
 - dungeon generator (roguelike grid)
 - terminal animation pack (spinner, progress bar, matrix rain, typing)
 - joke generator (multiple categories)
 - hacking-sim console (playful fake-hacker interface)

Only uses the Python standard library.
Author: ChatGPT (for HyperQuantum_ v0.1.0)
"""

from __future__ import annotations
import random
import math
import time
import os
import sys
import threading
import shutil
import textwrap
from typing import List, Tuple

# ---------------------------
# Terminal helpers & colors
# ---------------------------
ESC = "\x1b["
RESET = ESC + "0m"
BOLD = ESC + "1m"
DIM = ESC + "2m"
CLEAR_SCREEN = ESC + "2J" + ESC + "H"

def clear():
    if os.name == "nt":
        os.system("cls")
    else:
        sys.stdout.write(CLEAR_SCREEN)
        sys.stdout.flush()

def term_size():
    try:
        w, h = shutil.get_terminal_size()
    except:
        w, h = 80, 24
    return w, h

def color(text, code):
    return f"{ESC}{code}m{text}{RESET}"

def cyan(s): return color(s, '36')
def green(s): return color(s, '32')
def red(s): return color(s, '31')
def yellow(s): return color(s, '33')
def magenta(s): return color(s, '35')
def bold(s): return BOLD + s + RESET

# ---------------------------
# Meme generator (ASCII)
# - create a boxed meme with top/bottom text, optional art
# ---------------------------
MEME_ART = [
r"""
  /\_/\  
 ( o.o ) 
  > ^ <
""",
r"""
 (\_/)
 (•_•)
 / >🍪
""",
r"""
  ─────▄▀▀▀▄▄▄▄▄▄▄▀▀▀▄─────
  ────█▒▒░░░░░░░░░▒▒█────
  ───█▒░░░░░░░░░░░░░▒█───
""",
]

def wrap_text(text, width):
    return textwrap.wrap(text, width=width)

def create_meme(top: str, bottom: str, art: str=None, width:int=None):
    """Return a string containing an ASCII meme with top/bottom text and optional art."""
    tw, th = term_size()
    width = width or min(80, tw - 4)
    pad = 2
    inner_w = width - pad*2 - 2
    top_lines = wrap_text(top.upper(), inner_w)
    bot_lines = wrap_text(bottom.upper(), inner_w)
    art_lines = art.strip("\n").splitlines() if art else []
    content_lines = top_lines + [""] + art_lines + [""] + bot_lines
    box = []
    box.append("+" + "-"*(width-2) + "+")
    for line in content_lines:
        line = line[:inner_w]
        left = (inner_w - len(line))//2
        right = inner_w - len(line) - left
        box.append("|" + " "*pad + " "*left + line + " "*right + " "*pad + "|")
    box.append("+" + "-"*(width-2) + "+")
    return "\n".join(box)

def show_meme_demo():
    clear()
    art = random.choice(MEME_ART)
    meme = create_meme("WHEN PYTHON SAYS OK", "BUT YOUR CODE ACTUALLY WORKS", art=art)
    print(meme)
    print()
    input("Press Enter to return to menu...")

# ---------------------------
# Dungeon generator
# - simple BSP-like room placement + corridors
# - prints ASCII map
# ---------------------------
class Dungeon:
    def __init__(self, width=60, height=25, room_attempts=40, min_room=4, max_room=12, seed=None):
        self.w = width
        self.h = height
        self.room_attempts = room_attempts
        self.min_room = min_room
        self.max_room = max_room
        self.seed = seed or random.randrange(2**32)
        self.rng = random.Random(self.seed)
        self.map = [[' ' for _ in range(self.w)] for _ in range(self.h)]
        self.rooms = []

    def make_room(self, x, y, rw, rh):
        # carve room as floor '.'
        for i in range(y, y+rh):
            for j in range(x, x+rw):
                if 0 <= i < self.h and 0 <= j < self.w:
                    self.map[i][j] = '.'

    def make_h_corridor(self, x1, x2, y):
        for x in range(min(x1,x2), max(x1,x2)+1):
            if 0 <= y < self.h and 0 <= x < self.w:
                self.map[y][x] = '.'

    def make_v_corridor(self, y1, y2, x):
        for y in range(min(y1,y2), max(y1,y2)+1):
            if 0 <= y < self.h and 0 <= x < self.w:
                self.map[y][x] = '.'

    def generate(self):
        self.rng.seed(self.seed)
        self.map = [['#' for _ in range(self.w)] for _ in range(self.h)]
        self.rooms = []
        for _ in range(self.room_attempts):
            rw = self.rng.randint(self.min_room, self.max_room)
            rh = self.rng.randint(self.min_room, self.max_room)
            x = self.rng.randint(1, self.w - rw - 2)
            y = self.rng.randint(1, self.h - rh - 2)
            new_room = (x,y,rw,rh)
            ok = True
            for r in self.rooms:
                rx,ry,rrw,rrh = r
                if (x < rx+rrw+2 and x+rw+2 > rx and y < ry+rrh+2 and y+rh+2 > ry):
                    ok = False; break
            if ok:
                self.make_room(x,y,rw,rh)
                if self.rooms:
                    (prev_x, prev_y, prev_rw, prev_rh) = self.rooms[-1]
                    prev_center = (prev_x + prev_rw//2, prev_y + prev_rh//2)
                    new_center = (x + rw//2, y + rh//2)
                    if self.rng.choice([True, False]):
                        self.make_h_corridor(prev_center[0], new_center[0], prev_center[1])
                        self.make_v_corridor(prev_center[1], new_center[1], new_center[0])
                    else:
                        self.make_v_corridor(prev_center[1], new_center[1], prev_center[0])
                        self.make_h_corridor(prev_center[0], new_center[0], new_center[1])
                self.rooms.append(new_room)
        # add walls and edges
        for y in range(self.h):
            for x in range(self.w):
                if self.map[y][x] == '.':
                    # surround with floor char
                    pass
        # place player and stairs randomly in rooms
        if self.rooms:
            px = self.rng.randint(0, len(self.rooms)-1)
            rx,ry,rw,rh = self.rooms[px]
            player_x = rx + rw//2
            player_y = ry + rh//2
            self.map[player_y][player_x] = '@'
            # stairs
            sx = self.rng.randint(0, len(self.rooms)-1)
            while sx == px and len(self.rooms)>1: sx = (sx+1)%len(self.rooms)
            rx,ry,rw,rh = self.rooms[sx]
            sxpos = rx + rw//2
            sypos = ry + rh//2
            self.map[sypos][sxpos] = '>'
        return self.map

    def render(self):
        return "\n".join("".join(row) for row in self.map)

def show_dungeon_demo():
    clear()
    tw,th = term_size()
    d = Dungeon(width=min(80, tw-2), height=min(40, th-4))
    d.generate()
    print(bold("Dungeon (seed: {})".format(d.seed)))
    print(d.render())
    print()
    input("Explore complete. Press Enter to return to menu...")

# ---------------------------
# Terminal animation pack
# - spinner, progress bar, typing effect, matrix rain
# ---------------------------
class Spinner:
    _frames = ['|','/','-','\\']
    def __init__(self, text="Loading"):
        self.text = text
        self._running = False
        self._thread = None

    def start(self):
        self._running = True
        def run():
            i = 0
            while self._running:
                sys.stdout.write("\r" + self.text + " " + self._frames[i%len(self._frames)])
                sys.stdout.flush()
                i+=1
                time.sleep(0.12)
            sys.stdout.write("\r" + " "*(len(self.text)+4) + "\r")
        self._thread = threading.Thread(target=run, daemon=True)
        self._thread.start()

    def stop(self):
        self._running = False
        if self._thread:
            self._thread.join()

def progress_bar(total=50, duration=3.0, prefix="Progress"):
    start = time.time()
    for i in range(total+1):
        t = (time.time() - start)/duration
        if t > 1: t = 1
        filled = int(i)
        bar = "[" + "#"*filled + "-"*(total-filled) + "]"
        sys.stdout.write(f"\r{prefix} {bar} {int(t*100)}%")
        sys.stdout.flush()
        time.sleep(duration/total)
    sys.stdout.write("\n")

def typing_print(text, delay=0.02):
    for ch in text:
        sys.stdout.write(ch)
        sys.stdout.flush()
        time.sleep(delay)
    sys.stdout.write("\n")

def matrix_rain(duration=6.0, density=0.02):
    tw, th = term_size()
    cols = tw
    drops = [0 for _ in range(cols)]
    end = time.time() + duration
    chars = "abcdefghijklmnopqrstuvwxyz0123456789@#$%&*"
    try:
        while time.time() < end:
            line = ""
            for i in range(cols):
                if random.random() < density:
                    drops[i] = 1
                c = ' '
                if drops[i] > 0:
                    c = random.choice(chars)
                    drops[i] += 1
                    if drops[i] > th or random.random() < 0.02:
                        drops[i] = 0
                line += color(c, '32')  # green
            sys.stdout.write(line + "\n")
            sys.stdout.flush()
            time.sleep(0.08)
    except KeyboardInterrupt:
        pass

# ---------------------------
# Joke generator
# ---------------------------
JOKES = {
    "one-liner": [
        "I told my computer I needed a break, and it said 'No problem — I'll go to sleep.'",
        "Why do programmers prefer dark mode? Because light attracts bugs.",
        "A SQL query walks into a bar, walks up to two tables and asks: 'Can I join you?'"
    ],
    "dad": [
        "I'm reading a book about anti-gravity — it's impossible to put down!",
        "Why don't skeletons fight each other? They don't have the guts."
    ],
    "dev": [
        "There are 10 kinds of people: those who know binary and those who don't.",
        "To understand what recursion is, you must first understand recursion."
    ],
    "nerdy": [
        "Schrödinger's cat walks into a bar... and doesn't.",
        "Programmer (noun): An organism that turns caffeine into code."
    ]
}

def random_joke(category=None):
    if category and category in JOKES:
        return random.choice(JOKES[category])
    cat = random.choice(list(JOKES.keys()))
    return f"[{cat}] " + random.choice(JOKES[cat])

# ---------------------------
# Hacking-sim console (playful)
# - fake scan, brute, decrypt, exploit with animations
# ---------------------------
class HackSim:
    WAVES = ["INITIALIZING", "PROBING", "CONNECTING", "EXPLOIT", "SHELL"]
    def __init__(self):
        self.running = True
        self.files = {"/etc/passwd":"root:x:0:0:root:/root:/bin/bash\n", "/var/flag":"FLAG{h4x0r_playsafe}"}
        self.discovered = []
        self.key = "omega"

    def prompt(self):
        return green("hax@hyperquantum:~$ ")

    def type_out(self, text, delay=0.008):
        typing_print(text, delay=delay)

    def fake_scan(self, target="192.168.1.0/24"):
        spinner = Spinner(f"Scanning {target}")
        spinner.start()
        time.sleep(1.2 + random.random()*1.5)
        spinner.stop()
        # produce fake hosts
        hosts = []
        base = "192.168.1."
        for i in range(2, random.randint(6,12)):
            ip = base + str(random.randint(2,250))
            hosts.append(ip)
        self.discovered = hosts
        self.type_out(f"Found {len(hosts)} hosts: " + ", ".join(hosts))

    def fake_ssh_bruteforce(self, host):
        self.type_out(f"Attempting SSH bruteforce on {host}...")
        for i in range(8):
            sys.stdout.write(".")
            sys.stdout.flush()
            time.sleep(0.25 + random.random()*0.2)
        sys.stdout.write("\n")
        success = random.random() < 0.6
        if success:
            user = random.choice(["root","admin","oracle","ubuntu"])
            self.type_out(f"Success: logged in as {user}@{host}")
            return True
        else:
            self.type_out(red("Bruteforce failed."))
            return False

    def fake_exploit(self, host):
        self.type_out(f"Launching exploit against {host}...")
        progress_bar(total=30, duration=2.5, prefix="Exploit")
        if random.random() < 0.7:
            self.type_out(green("Exploit succeeded. Remote shell acquired."))
            return True
        else:
            self.type_out(red("Exploit failed. Target patched."))
            return False

    def fake_dump(self, path):
        self.type_out(f"Dumping {path} ...")
        if path in self.files:
            content = self.files[path]
            self.type_out("---- BEGIN DUMP ----")
            self.type_out(content)
            self.type_out("----  END DUMP  ----")
        else:
            self.type_out(red("File not found."))

    def fake_decrypt(self, blob):
        self.type_out("Attempting decryption...")
        spinner = Spinner("Cracking")
        spinner.start()
        time.sleep(2.0 + random.random()*1.5)
        spinner.stop()
        if random.random() < 0.5:
            self.type_out(green("Decryption success: ") + self.key)
            return self.key
        else:
            self.type_out(red("Decryption failed."))
            return None

    def start_interactive(self):
        clear()
        self.type_out(bold("Welcome to HyperQuantum Hacking Sim — Playful Mode"))
        self.type_out("Type 'help' for commands. Type 'exit' to quit.")
        while True:
            try:
                cmd = input(self.prompt()).strip()
            except (KeyboardInterrupt, EOFError):
                print()
                break
            if not cmd: continue
            parts = cmd.split()
            c = parts[0].lower()
            args = parts[1:]
            if c == "help":
                self.type_out("Commands: scan, bruteforce <host>, exploit <host>, dump <path>, decrypt <blob>, joke, anim, clear, exit")
            elif c == "scan":
                target = args[0] if args else "192.168.1.0/24"
                self.fake_scan(target)
            elif c == "bruteforce":
                if not args:
                    self.type_out("Usage: bruteforce <host>")
                else:
                    self.fake_ssh_bruteforce(args[0])
            elif c == "exploit":
                if not args:
                    self.type_out("Usage: exploit <host>")
                else:
                    self.fake_exploit(args[0])
            elif c == "dump":
                if not args:
                    self.type_out("Usage: dump <path>")
                else:
                    self.fake_dump(args[0])
            elif c == "decrypt":
                if not args:
                    self.type_out("Usage: decrypt <blob>")
                else:
                    self.fake_decrypt(" ".join(args))
            elif c == "joke":
                self.type_out(random_joke())
            elif c == "anim":
                self.type_out("Launching Matrix Rain (Ctrl+C to stop)...")
                try:
                    matrix_rain(duration=8.0)
                except KeyboardInterrupt:
                    self.type_out("Interrupted.")
            elif c == "clear":
                clear()
            elif c == "exit":
                self.type_out("Bye.")
                break
            else:
                self.type_out("Unknown command. Try 'help'.")

# ---------------------------
# Combined demo menu
# ---------------------------
def main_menu():
    h = HackSim()
    while True:
        clear()
        print(bold("=== HyperQuantum FunBox ==="))
        print("1) Meme generator")
        print("2) Dungeon generator")
        print("3) Animations pack")
        print("4) Joke generator")
        print("5) Hacking-sim console")
        print("6) Quick random bundle")
        print("0) Exit")
        choice = input("\nChoose: ").strip()
        if choice == "1":
            clear()
            top = input("Top text: ")
            bot = input("Bottom text: ")
            art = random.choice(MEME_ART) if input("Use random art? (Y/n) ").lower() != 'n' else None
            print(create_meme(top, bot, art=art))
            input("\nPress Enter → ")
        elif choice == "2":
            show_dungeon_demo()
        elif choice == "3":
            clear()
            print(bold("Animations Pack"))
            print("a) Spinner demo")
            print("b) Progress bar demo")
            print("c) Typing demo")
            print("d) Matrix rain demo")
            sub = input("Choose: ").strip().lower()
            if sub == 'a':
                s = Spinner("Spinning")
                s.start()
                time.sleep(3)
                s.stop()
                input("\nDone. Press Enter → ")
            elif sub == 'b':
                progress_bar(total=40, duration=4.0)
                input("\nDone. Press Enter → ")
            elif sub == 'c':
                typing_print("The quick brown fox jumps over the lazy dog...", delay=0.03)
                input("\nDone. Press Enter → ")
            elif sub == 'd':
                try:
                    matrix_rain(duration=6.0)
                except KeyboardInterrupt:
                    pass
                input("\nDone. Press Enter → ")
        elif choice == "4":
            clear()
            print("Joke categories:", ", ".join(JOKES.keys()))
            cat = input("Pick category or press Enter for random: ").strip()
            print("\n" + random_joke(cat if cat else None))
            input("\nNice. Press Enter → ")
        elif choice == "5":
            clear()
            h.start_interactive()
            input("\nReturning to menu... Press Enter → ")
        elif choice == "6":
            clear()
            print(bold("Random Bundle"))
            # random meme + short dungeon + a joke
            print("-- MEME --")
            print(create_meme("RANDOM BUNDLE", random_joke()))
            print("\n-- MINI DUNGEON --")
            d = Dungeon(width=40, height=16)
            d.generate()
            print(d.render())
            print("\n-- MATRIX (short) --")
            try:
                matrix_rain(duration=4.0)
            except KeyboardInterrupt:
                pass
            input("\nDone. Press Enter → ")
        elif choice == "0":
            print("Goodbye.")
            break
        else:
            input("Unknown choice. Press Enter → ")

if __name__ == "__main__":
    main_menu()
