"""
aiassistant.py
A mini AI toolkit: summarization, keywords, sentiment, chatbot, translation.
"""

import re
import random

# --------------------------------------------------------------
# BASIC TEXT UTILITIES
# --------------------------------------------------------------

def summarize(text, lines=5):
    """
    Simple summarizer: picks most important sentences based on word frequency.
    """
    sentences = re.split(r'(?<=[.!?]) +', text)
    if len(sentences) <= lines:
        return text

    words = re.findall(r'\w+', text.lower())
    freq = {}
    for w in words:
        freq[w] = freq.get(w, 0) + 1

    ranking = []
    for s in sentences:
        score = sum(freq.get(w, 0) for w in re.findall(r'\w+', s.lower()))
        ranking.append((score, s))

    ranking.sort(reverse=True)
    best = [s for _, s in ranking[:lines]]
    return " ".join(best)


def keywords(text, limit=10):
    """
    Extract top keywords using frequency.
    """
    words = re.findall(r'\w+', text.lower())
    freq = {}
    for w in words:
        if len(w) > 3:
            freq[w] = freq.get(w, 0) + 1

    top = sorted(freq.items(), key=lambda x: x[1], reverse=True)[:limit]
    return [w for w, c in top]


# --------------------------------------------------------------
# SENTIMENT ANALYSIS (simple lexicon based)
# --------------------------------------------------------------

positive_words = {"good", "great", "excellent", "happy", "nice", "love", "awesome", "amazing"}
negative_words = {"bad", "terrible", "sad", "angry", "hate", "horrible", "awful"}

def sentiment(text):
    """
    Very simple sentiment analyzer: returns positive/negative/neutral.
    """
    score = 0
    for w in re.findall(r'\w+', text.lower()):
        if w in positive_words:
            score += 1
        elif w in negative_words:
            score -= 1

    if score > 0:
        return "positive"
    if score < 0:
        return "negative"
    return "neutral"


# --------------------------------------------------------------
# CHATBOT ENGINE
# --------------------------------------------------------------

class ChatBot:
    def __init__(self):
        self.memory = []

    def reply(self, text):
        self.memory.append(text)

        # Rule-based demo replies
        text_lower = text.lower()
        if "hello" in text_lower or "hi" in text_lower:
            return "Hello! How can I assist you today?"
        if "your name" in text_lower:
            return "I am your AI assistant module."
        if "help" in text_lower:
            return "Sure! What do you need help with?"

        return random.choice([
            "Interesting… tell me more!",
            "I see. Continue.",
            "Why do you think that?",
            "That's fascinating!",
        ])


# --------------------------------------------------------------
# TRANSLATION (offline dummy + optional online)
# --------------------------------------------------------------

def translate(text, to="es"):
    """
    Fake offline translator (for demo). 
    Add online API later if needed.
    """
    if to == "es":
        return text.replace("the", "el").replace("a", "una")
    return text
