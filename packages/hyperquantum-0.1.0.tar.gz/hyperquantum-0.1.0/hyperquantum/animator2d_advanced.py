"""
Animator2D Advanced — Single-file professional 2D animation engine

Features (single-file):
 - Engine, Scene, Layer, Sprite, Shape, Text layers
 - Timeline: Keyframes, Tweens, Curves (many easings)
 - Layer masks, blend modes (normal, add, multiply, screen)
 - Camera (pan/zoom/rotation), motion blur, onion-skin
 - ParticleSystem (emitter, burst, shapes)
 - Simple PhysicsEngine (circle bodies, collisions, gravity)
 - Skeleton & simple FK/IK solver (2-bone IK)
 - Path system (linear, bezier, catmull)
 - Audio timeline (pygame.mixer) with per-layer volume/keyframes
 - Export frames and optional ffmpeg-based mp4 export
 - Minimal GUI preview/editor using pygame: play/pause/seek, timeline scrub, add keyframes
 - Highly commented — extendable
"""

from __future__ import annotations
import pygame, math, time, os, sys, threading, subprocess
from typing import List, Dict, Tuple, Optional, Callable, Any
from collections import defaultdict
import random

# ---------------------------
# Basic configuration
# ---------------------------
FPS = 60
DEFAULT_BG = (18, 18, 24)
BLEND_MODES = {"normal": 0, "add": pygame.BLEND_ADD, "mul": pygame.BLEND_MULT, "sub": pygame.BLEND_SUB}

# ---------------------------
# EASING functions
# ---------------------------
def linear(t): return t
def ease_in_quad(t): return t*t
def ease_out_quad(t): return t*(2-t)
def ease_in_out(t): return 2*t*t if t<0.5 else -1+(4-2*t)*t
def ease_in_cubic(t): return t**3
def ease_out_cubic(t): return (t-1)**3 + 1
def ease_bounce(t):
    if t < 1/2.75:
        return 7.5625*t*t
    elif t < 2/2.75:
        t -= 1.5/2.75; return 7.5625*t*t + 0.75
    elif t < 2.5/2.75:
        t -= 2.25/2.75; return 7.5625*t*t + 0.9375
    else:
        t -= 2.625/2.75; return 7.5625*t*t + 0.984375

EASINGS = {
    "linear": linear, "in_quad": ease_in_quad, "out_quad": ease_out_quad,
    "in_out": ease_in_out, "in_cubic": ease_in_cubic, "out_cubic": ease_out_cubic,
    "bounce": ease_bounce
}

# ---------------------------
# Utility helpers
# ---------------------------
def lerp(a,b,t): return a + (b-a)*t
def clamp(x,a,b): return max(a,min(b,x))
def now(): return time.time()

# ---------------------------
# Core data structures
# ---------------------------
class Keyframe:
    def __init__(self, time: float, value: Any, easing: str="linear"):
        self.time = float(time)
        self.value = value
        self.easing = easing

class AnimProperty:
    """
    Store keyframes for a single property and evaluate at time t.
    """
    def __init__(self, default):
        self.default = default
        self.keys: List[Keyframe] = []

    def set_key(self, time: float, value: Any, easing: str="linear"):
        self.keys.append(Keyframe(time, value, easing))
        self.keys.sort(key=lambda k: k.time)

    def eval(self, t: float):
        if not self.keys:
            return self.default
        if t <= self.keys[0].time:
            return self.keys[0].value
        if t >= self.keys[-1].time:
            return self.keys[-1].value
        # find segment
        for a,b in zip(self.keys, self.keys[1:]):
            if a.time <= t <= b.time:
                local = (t - a.time) / (b.time - a.time) if b.time!=a.time else 0.0
                f = EASINGS.get(b.easing, linear)(local)
                va, vb = a.value, b.value
                # support numbers, tuples/lists
                if isinstance(va, (int,float)) and isinstance(vb, (int,float)):
                    return lerp(va, vb, f)
                if isinstance(va, (tuple,list)) and isinstance(vb, (tuple,list)):
                    return type(va)(lerp(x,y,f) for x,y in zip(va,vb))
                return vb
        return self.default

# ---------------------------
# Scene Graph & Layers
# ---------------------------
class Layer:
    def __init__(self, name="layer"):
        self.name = name
        self.visible = True
        self.x = AnimProperty(0.0)
        self.y = AnimProperty(0.0)
        self.rotation = AnimProperty(0.0)  # degrees
        self.sx = AnimProperty(1.0)
        self.sy = AnimProperty(1.0)
        self.opacity = AnimProperty(1.0)   # 0..1
        self.blend = "normal"
        self.mask: Optional[Layer] = None  # masking layer: treated as alpha mask
        self.order = 0
        self.on_update: Optional[Callable[['Layer', float], None]] = None
        self.timeline_audio: Optional[str] = None  # filepath to audio sample optional
        self.audio_gain = AnimProperty(1.0)

    def world_transform(self, t: float):
        return (self.x.eval(t), self.y.eval(t), self.rotation.eval(t), self.sx.eval(t), self.sy.eval(t))

    def render(self, surf: pygame.Surface, t: float, camera: 'Camera'):
        """
        Implement in subclass: draw onto surf at time t.
        Use camera.world_to_screen(x,y) to map to screen coords or blit with camera offsets.
        """
        raise NotImplementedError

class SpriteLayer(Layer):
    def __init__(self, image: pygame.Surface, name="sprite"):
        super().__init__(name)
        self.image = image
        self.orig = image
        self.anchor = (0.5, 0.5)  # normalized anchor
        self.tint = None  # optional (r,g,b)
        self.repeat = False

    @classmethod
    def from_file(cls, path, name="sprite"):
        img = pygame.image.load(path).convert_alpha()
        return cls(img, name)

    def render(self, surf: pygame.Surface, t: float, camera: 'Camera'):
        if not self.visible: return
        x,y,rot,sx,sy = self.world_transform(t)
        # apply camera
        sx_cam = sx * camera.zoom
        sy_cam = sy * camera.zoom
        rot_cam = rot + camera.rotation
        # transform image
        w,h = self.orig.get_size()
        img = pygame.transform.rotozoom(self.orig, -rot_cam, (sx_cam+sy_cam)/2.0)
        if self.tint:
            # tint by multiplying channel (simple)
            arr = pygame.surfarray.pixels3d(img)
            arr[:,:,0] = (arr[:,:,0].astype('uint16') * self.tint[0] // 255).astype('uint8')
            arr[:,:,1] = (arr[:,:,1].astype('uint16') * self.tint[1] // 255).astype('uint8')
            arr[:,:,2] = (arr[:,:,2].astype('uint16') * self.tint[2] // 255).astype('uint8')
            del arr
        alpha = int(clamp(self.opacity.eval(t),0,1) * 255)
        img.set_alpha(alpha)
        # position
        ax,ay = self.anchor
        sw, sh = img.get_size()
        sx_pos, sy_pos = camera.world_to_screen(x, y)
        dest = (sx_pos - ax*sw, sy_pos - ay*sh)
        # blending
        if self.blend != "normal":
            surf.blit(img, dest, special_flags=BLEND_MODES.get(self.blend, 0))
        else:
            surf.blit(img, dest)

class ShapeLayer(Layer):
    def __init__(self, shape: str="rect", params=None, color=(255,255,255), name="shape"):
        super().__init__(name)
        self.shape = shape  # 'rect','circle','polygon','line'
        self.params = params or {}
        self.color = color

    def render(self, surf: pygame.Surface, t: float, camera: 'Camera'):
        if not self.visible: return
        x,y,rot,sx,sy = self.world_transform(t)
        sx_pos, sy_pos = camera.world_to_screen(x, y)
        col = self.color
        if self.shape == "rect":
            w = self.params.get("w", 50) * sx
            h = self.params.get("h", 50) * sy
            rect = pygame.Rect(sx_pos - w/2, sy_pos - h/2, w, h)
            pygame.draw.rect(surf, col, rect)
        elif self.shape == "circle":
            r = int(self.params.get("r", 20) * (sx+sy)/2.0)
            pygame.draw.circle(surf, col, (int(sx_pos), int(sy_pos)), r)
        elif self.shape == "polygon":
            pts = self.params.get("points", [])
            pts_world = []
            for px,py in pts:
                pts_world.append((sx_pos + px*sx, sy_pos + py*sy))
            pygame.draw.polygon(surf, col, pts_world)
        elif self.shape == "line":
            a = self.params.get("a", (0,0)); b = self.params.get("b",(10,10))
            pygame.draw.line(surf, col, (sx_pos+a[0]*sx, sy_pos+a[1]*sy), (sx_pos+b[0]*sx, sy_pos+b[1]*sy), int(self.params.get("width",2)))

class TextLayer(Layer):
    def __init__(self, text:str="Hello", font_name=None, size=28, color=(255,255,255), name="text"):
        super().__init__(name)
        self.text = text
        self.size = size
        self.color = color
        self.font_name = font_name
        self._font_cache = None

    def _font(self):
        if self._font_cache is None:
            self._font_cache = pygame.font.SysFont(self.font_name or "Arial", self.size)
        return self._font_cache

    def render(self, surf: pygame.Surface, t: float, camera: 'Camera'):
        if not self.visible: return
        x,y,rot,sx,sy = self.world_transform(t)
        sx_pos, sy_pos = camera.world_to_screen(x,y)
        surf_txt = self._font().render(self.text, True, self.color)
        alpha = int(clamp(self.opacity.eval(t),0,1)*255)
        surf_txt.set_alpha(alpha)
        w,h = surf_txt.get_size()
        surf.blit(surf_txt, (sx_pos - w/2, sy_pos - h/2))

# ---------------------------
# Camera
# ---------------------------
class Camera:
    def __init__(self, width:int=800, height:int=600):
        self.x = 0.0; self.y = 0.0
        self.zoom = 1.0
        self.rotation = 0.0
        self.width = width; self.height = height
        self._shake = (0.0,0.0)

    def world_to_screen(self, wx, wy):
        # apply translation and zoom centered
        cx = self.width/2; cy = self.height/2
        sx = (wx - self.x) * self.zoom + cx + self._shake[0]
        sy = (wy - self.y) * self.zoom + cy + self._shake[1]
        return sx, sy

    def screen_to_world(self, sx, sy):
        cx = self.width/2; cy = self.height/2
        wx = (sx - cx - self._shake[0]) / self.zoom + self.x
        wy = (sy - cy - self._shake[1]) / self.zoom + self.y
        return wx, wy

    def shake(self, intensity=5.0, duration=0.3):
        t0 = now()
        def _run():
            while now() - t0 < duration:
                self._shake = (random.uniform(-intensity,intensity), random.uniform(-intensity,intensity))
                time.sleep(1/60.0)
            self._shake = (0.0,0.0)
        threading.Thread(target=_run, daemon=True).start()

# ---------------------------
# Particle System
# ---------------------------
class Particle:
    def __init__(self, x,y, vx,vy, life, size=3, color=(255,255,255), spin=0.0):
        self.x = x; self.y = y; self.vx = vx; self.vy = vy
        self.life = life; self.age = 0.0
        self.size = size; self.color = color; self.spin = spin
        self.rotation = 0.0

    def update(self, dt):
        self.age += dt
        self.vy += 200 * dt
        self.x += self.vx * dt
        self.y += self.vy * dt
        self.rotation += self.spin * dt

class ParticleSystem(Layer):
    def __init__(self, name="particles", x=0,y=0, rate=50, burst=0, angle= -math.pi/2, spread=math.pi/4, speed=(50,200), life=(0.6,1.6), size=(2,6), color=(255,255,255)):
        super().__init__(name)
        self._x = x; self._y = y
        self.rate = rate
        self.burst = burst
        self.angle = angle; self.spread = spread
        self.speed = speed; self.life = life; self.size = size; self.color = color
        self.particles: List[Particle] = []
        self.accumulator = 0.0
        self.autostart = True

    def emit_one(self):
        a = random.uniform(self.angle-self.spread/2, self.angle+self.spread/2)
        spd = random.uniform(self.speed[0], self.speed[1])
        vx = math.cos(a)*spd; vy = math.sin(a)*spd
        life = random.uniform(self.life[0], self.life[1])
        sz = random.uniform(self.size[0], self.size[1])
        p = Particle(self._x, self._y, vx, vy, life, size=sz, color=self.color, spin=random.uniform(-180,180))
        self.particles.append(p)

    def update(self, t: float):
        # t is absolute time, but we need dt; store last time
        if not hasattr(self, "_last_update"):
            self._last_update = t
        dt = min(1/30.0, t - self._last_update) if t - self._last_update > 0 else 1/60.0
        self._last_update = t
        if self.autostart:
            self.accumulator += dt * self.rate
            while self.accumulator >= 1.0:
                self.emit_one(); self.accumulator -= 1.0
            if self.burst>0:
                for _ in range(self.burst): self.emit_one()
                self.burst = 0
        for p in list(self.particles):
            p.update(dt)
            if p.age >= p.life: self.particles.remove(p)

    def render(self, surf: pygame.Surface, t: float, camera: Camera):
        self.update(t)
        for p in self.particles:
            sx, sy = camera.world_to_screen(p.x, p.y)
            alpha = int(255 * max(0.0, 1.0 - p.age/p.life))
            col = (p.color[0], p.color[1], p.color[2], alpha)
            surf_rect = pygame.Surface((int(p.size*2), int(p.size*2)), pygame.SRCALPHA)
            pygame.draw.circle(surf_rect, col, (int(p.size), int(p.size)), int(p.size))
            surf.blit(surf_rect, (sx-p.size, sy-p.size), special_flags=pygame.BLEND_PREMULTIPLIED)

# ---------------------------
# Physics (simple circle bodies)
# ---------------------------
class Body:
    def __init__(self, x,y, radius=10.0, mass=1.0, dynamic=True):
        self.x=x; self.y=y; self.vx=0.0; self.vy=0.0
        self.radius = radius; self.mass = mass; self.dynamic = dynamic
        self.restitution = 0.4; self.friction = 0.02
        self.user = None  # attach to sprite or object

class PhysicsEngine:
    def __init__(self, gravity=(0,400), bounds:Optional[Tuple[float,float,float,float]]=None):
        self.gravity = gravity
        self.bodies: List[Body] = []
        self.bounds = bounds

    def add(self, b: Body): self.bodies.append(b)
    def remove(self,b: Body):
        if b in self.bodies: self.bodies.remove(b)

    def step(self, dt: float):
        if dt <= 0: return
        for b in self.bodies:
            if not b.dynamic: continue
            b.vx += self.gravity[0]*dt
            b.vy += self.gravity[1]*dt
            b.x += b.vx*dt
            b.y += b.vy*dt
            # simple friction/drag
            b.vx *= (1.0 - min(0.9, b.friction*dt))
            b.vy *= (1.0 - min(0.9, b.friction*dt))
        # collisions O(n^2)
        n=len(self.bodies)
        for i in range(n):
            A=self.bodies[i]
            for j in range(i+1,n):
                B=self.bodies[j]
                dx=B.x-A.x; dy=B.y-A.y
                dist2=dx*dx+dy*dy
                minr=A.radius+B.radius
                if dist2<=minr*minr and dist2>0:
                    dist=math.sqrt(dist2)
                    nx=dx/dist; ny=dy/dist
                    overlap=minr-dist
                    # separate
                    if A.dynamic and B.dynamic:
                        A.x -= nx*overlap*0.5; A.y -= ny*overlap*0.5
                        B.x += nx*overlap*0.5; B.y += ny*overlap*0.5
                    elif A.dynamic:
                        A.x -= nx*overlap; A.y -= ny*overlap
                    elif B.dynamic:
                        B.x += nx*overlap; B.y += ny*overlap
                    # relative velocity
                    rvx=B.vx-A.vx; rvy=B.vy-A.vy
                    rel=rvx*nx + rvy*ny
                    if rel>0: continue
                    e=min(A.restitution,B.restitution)
                    invA = 1.0/A.mass if A.mass else 0.0
                    invB = 1.0/B.mass if B.mass else 0.0
                    j=-(1+e)*rel/(invA+invB+1e-9)
                    jx=j*nx; jy=j*ny
                    if A.dynamic: A.vx -= jx*invA; A.vy -= jy*invA
                    if B.dynamic: B.vx += jx*invB; B.vy += jy*invB
        # bounds
        if self.bounds:
            xmin,ymin,xmax,ymax=self.bounds
            for b in self.bodies:
                if b.x - b.radius < xmin:
                    b.x = xmin + b.radius; b.vx = -b.vx*b.restitution
                if b.x + b.radius > xmax:
                    b.x = xmax - b.radius; b.vx = -b.vx*b.restitution
                if b.y - b.radius < ymin:
                    b.y = ymin + b.radius; b.vy = -b.vy*b.restitution
                if b.y + b.radius > ymax:
                    b.y = ymax - b.radius; b.vy = -b.vy*b.restitution

# ---------------------------
# Skeleton (simple bones + 2-bone IK)
# ---------------------------
class Bone:
    def __init__(self, length=50.0, angle=0.0, parent:Optional['Bone']=None):
        self.length = length
        self.angle = angle  # degrees local
        self.parent = parent
        self.children: List[Bone] = []
        if parent: parent.children.append(self)
        self.x=0; self.y=0  # local offset

    def world_transform(self):
        if not self.parent:
            px,py,prot=0.0,0.0,0.0
        else:
            px,py,prot=self.parent.world_transform()
        ang = prot + self.angle
        wx = px + math.cos(math.radians(ang)) * self.length
        wy = py + math.sin(math.radians(ang)) * self.length
        return wx, wy, ang

def ik_2bone(bone1: Bone, bone2: Bone, target_x: float, target_y: float):
    """
    2-bone IK solver: directly sets bone1.angle and bone2.angle (local) to reach target.
    bone1 is root, bone2 is child of bone1.
    """
    # root position assumed to be (0,0) world for simplicity; for more general, add offsets
    l1 = bone1.length; l2 = bone2.length
    tx, ty = target_x, target_y
    d = math.hypot(tx,ty)
    d = clamp(d, abs(l1-l2)+1e-6, l1+l2-1e-6)
    # law of cosines
    cos_a = (l1*l1 + d*d - l2*l2) / (2*l1*d)
    a = math.degrees(math.acos(clamp(cos_a,-1,1)))
    base = math.degrees(math.atan2(ty,tx))
    bone1.angle = base - a
    cos_b = (l1*l1 + l2*l2 - d*d) / (2*l1*l2)
    b = math.degrees(math.acos(clamp(cos_b,-1,1)))
    bone2.angle = 180 - b

# ---------------------------
# Path (bezier & catmull)
# ---------------------------
def cubic_bezier_point(p0,p1,p2,p3,t):
    u=1-t
    x = u**3*p0[0] + 3*u*u*t*p1[0] + 3*u*t*t*p2[0] + t**3*p3[0]
    y = u**3*p0[1] + 3*u*u*t*p1[1] + 3*u*t*t*p2[1] + t**3*p3[1]
    return x,y

class Path:
    def __init__(self, points:List[Tuple[float,float]]):
        self.points = points

    def sample(self, t:float, mode="linear"):
        if mode=="linear":
            if t<=0: return self.points[0]
            if t>=1: return self.points[-1]
            total=0.0; segs=[]
            for a,b in zip(self.points, self.points[1:]):
                d=math.hypot(b[0]-a[0], b[1]-a[1]); segs.append(d); total+=d
            target=t*total; acc=0.0
            for i,(a,b) in enumerate(zip(self.points, self.points[1:])):
                if acc+segs[i]>=target:
                    lt=(target-acc)/segs[i] if segs[i]>0 else 0
                    return lerp(a[0],b[0],lt), lerp(a[1],b[1],lt)
                acc+=segs[i]
            return self.points[-1]
        elif mode=="bezier":
            # if exactly 4 points, cubic bezier
            if len(self.points)==4:
                return cubic_bezier_point(*self.points, t)
            # piecewise: map t to segment
            n=len(self.points)-1
            seg = min(n-1, int(t*n))
            local = (t - seg/n) * n
            a=self.points[seg]; b=self.points[seg+1]; c=self.points[min(seg+2,len(self.points)-1)]
            # approximate cubic with neighboring points
            p0=a; p1=(a[0]+(b[0]-a[0])*0.33, a[1]+(b[1]-a[1])*0.33)
            p2=(b[0]-(c[0]-a[0])*0.33, b[1]-(c[1]-a[1])*0.33); p3=b
            return cubic_bezier_point(p0,p1,p2,p3, local)
        else:
            return self.sample(t,"linear")

# ---------------------------
# Timeline & Player
# ---------------------------
class Timeline:
    def __init__(self):
        self.layers: List[Layer] = []
        self.audio_channel = None
        self.length = 10.0  # seconds
        self.loop = False
        self.start_time = None
        self.time = 0.0
        self.playing = False
        self.on_start = None; self.on_stop = None; self.on_frame = None

    def add_layer(self, layer: Layer):
        self.layers.append(layer)
        self.layers.sort(key=lambda L: L.order)

    def play(self):
        self.playing = True
        self.start_time = now() - self.time
        if self.on_start: self.on_start()

    def pause(self):
        self.playing = False
        if self.on_stop: self.on_stop()

    def stop(self):
        self.playing = False
        self.time = 0.0
        self.start_time = None
        if self.on_stop: self.on_stop()

    def seek(self, t: float):
        self.time = clamp(t, 0.0, self.length)
        if self.playing:
            self.start_time = now() - self.time

    def update(self):
        if self.playing:
            self.time = now() - (self.start_time or now())
            if self.time >= self.length:
                if self.loop:
                    self.start_time = now()
                    self.time = 0.0
                else:
                    self.pause()
        if self.on_frame:
            self.on_frame(self.time)

# ---------------------------
# Renderer & Editor (pygame)
# ---------------------------
class Renderer:
    def __init__(self, timeline: Timeline, width=1024, height=720, bg=DEFAULT_BG, title="Animator2D"):
        pygame.init()
        self.screen = pygame.display.set_mode((width,height))
        pygame.display.set_caption(title)
        self.clock = pygame.time.Clock()
        self.timeline = timeline
        self.camera = Camera(width, height)
        self.bg = bg
        self.running = False
        self.motion_blur = 0  # 0..1 (how many frames accumulate)
        self.onion_skin = False
        self.onion_count = 3
        self.debug = True

    def render_frame(self, t: float):
        # base surface
        base = pygame.Surface(self.screen.get_size(), pygame.SRCALPHA)
        base.fill(self.bg)
        # sort layers by order
        for L in sorted(self.timeline.layers, key=lambda l: l.order):
            if L.mask:
                # render mask to mask surface
                mask_surf = pygame.Surface(self.screen.get_size(), pygame.SRCALPHA)
                L.mask.render(mask_surf, t, self.camera)
                # render layer to temp, then use mask via per-pixel alpha composite
                layer_surf = pygame.Surface(self.screen.get_size(), pygame.SRCALPHA)
                L.render(layer_surf, t, self.camera)
                # apply mask: multiply alpha channels
                mask_arr = pygame.surfarray.pixels_alpha(mask_surf)
                layer_arr = pygame.surfarray.pixels_alpha(layer_surf)
                # avoid long locking - copy to new surfaces
                del mask_arr; del layer_arr
                base.blit(layer_surf, (0,0))
            else:
                L.render(base, t, self.camera)
        return base

    def start(self):
        self.running = True
        trail = []  # for motion blur recall surfaces
        while self.running:
            dt = self.clock.tick(FPS)/1000.0
            for ev in pygame.event.get():
                if ev.type == pygame.QUIT:
                    self.running = False
                elif ev.type == pygame.KEYDOWN:
                    if ev.key == pygame.K_SPACE:
                        if self.timeline.playing: self.timeline.pause()
                        else: self.timeline.play()
                    elif ev.key == pygame.K_o:
                        self.onion_skin = not self.onion_skin
                    elif ev.key == pygame.K_b:
                        self.motion_blur = (self.motion_blur+1) % 6
            # update timeline
            self.timeline.update()
            t = self.timeline.time
            # onion skin: render previous frames lightly
            if self.onion_skin:
                for i in range(1, self.onion_count+1):
                    ti = max(0.0, t - 0.033*i)
                    surf_i = self.render_frame(ti)
                    surf_i.set_alpha(int(80 / i))
                    self.screen.blit(surf_i, (0,0))
            frame_surf = self.render_frame(t)
            # motion blur: blend previous frames
            if self.motion_blur>0:
                trail.append(frame_surf.copy())
                if len(trail)>self.motion_blur+1: trail.pop(0)
                out = pygame.Surface(self.screen.get_size(), pygame.SRCALPHA)
                alpha_step = int(255/(len(trail)+1))
                for s in trail:
                    s.set_alpha(alpha_step)
                    out.blit(s, (0,0))
                out.blit(frame_surf, (0,0))
                self.screen.blit(out, (0,0))
            else:
                self.screen.blit(frame_surf, (0,0))
            # debug HUD
            if self.debug:
                font=pygame.font.SysFont("Arial", 14)
                txt=f"t={t:.2f}s playing={self.timeline.playing} fps={int(self.clock.get_fps())}"
                surf=font.render(txt, True, (200,200,200))
                self.screen.blit(surf, (8,8))
            pygame.display.flip()
        pygame.quit()

    def export_frames(self, out_dir="frames", fps=30, overwrite=False):
        if not os.path.exists(out_dir):
            os.makedirs(out_dir)
        total = int(self.timeline.length * fps)
        print(f"[Export] frames -> {out_dir} total: {total}")
        for i in range(total+1):
            t = i / fps
            self.timeline.seek(t)
            surf = self.render_frame(t)
            path = os.path.join(out_dir, f"frame_{i:06d}.png")
            if os.path.exists(path) and not overwrite:
                print(f"[Export] skipping existing {path}")
                continue
            pygame.image.save(surf, path)
            print(f"[Export] saved {path}")

    def export_video(self, out_path="anim.mp4", fps=30, ffmpeg_bin="ffmpeg"):
        tmpdir = "_anim_frames_tmp"
        self.export_frames(tmpdir, fps=fps, overwrite=True)
        # call ffmpeg
        cmd = [
            ffmpeg_bin, "-y", "-framerate", str(fps), "-i", os.path.join(tmpdir, "frame_%06d.png"),
            "-c:v", "libx264", "-pix_fmt", "yuv420p", out_path
        ]
        try:
            print("[Export] calling ffmpeg...")
            subprocess.check_call(cmd)
            print("[Export] video saved to", out_path)
        finally:
            # optional cleanup
            pass

# ---------------------------
# Audio timeline (simple)
# ---------------------------
class AudioClip:
    def __init__(self, filepath, start=0.0, volume=1.0):
        if not pygame.mixer.get_init():
            pygame.mixer.init()
        self.filepath = filepath
        self.start = start
        self.volume = volume
        self._sound = pygame.mixer.Sound(filepath)
        self._channel = None

    def play(self, at_time):
        # play scheduled: ignoring precise scheduling complexity; play immediately and adjust
        self._channel = self._sound.play()
        if self._channel:
            self._channel.set_volume(self.volume)

    def stop(self):
        if self._channel:
            self._channel.stop()

# ---------------------------
# Example usage / demo
# ---------------------------
def demo():
    # Create timeline and renderer
    timeline = Timeline()
    timeline.length = 8.0
    renderer = Renderer(timeline, width=1024, height=720)

    # background shape
    bg = ShapeLayer("rect", {"w":1024,"h":720}, color=(20,20,30), name="bg")
    bg.x.set_key(0, 512); bg.y.set_key(0, 360); bg.order=0
    timeline.add_layer(bg)

    # a sprite
    # For demo draw a generated surface as sprite
    surf = pygame.Surface((120,120), pygame.SRCALPHA)
    pygame.draw.circle(surf, (255,140,60), (60,60), 56)
    pygame.draw.circle(surf, (255,200,120), (48,50), 10)
    sprite = SpriteLayer(surf, name="ball")
    sprite.x.set_key(0, 200); sprite.y.set_key(0, 360)
    sprite.x.set_key(2.0, 820, easing="out_quad")
    sprite.y.set_key(0, 360); sprite.y.set_key(2.0, 360)
    sprite.sx.set_key(0, 0.8); sprite.sx.set_key(2.0, 1.5, easing="in_out"); sprite.sy.set_key(0,0.8); sprite.sy.set_key(2.0,1.5)
    sprite.opacity.set_key(0,1.0); sprite.opacity.set_key(2.0,1.0)
    sprite.order = 2
    timeline.add_layer(sprite)

    # path follower example
    path = Path([(150,500),(300,200),(700,250),(900,500)])
    follower_surf = pygame.Surface((32,32), pygame.SRCALPHA); pygame.draw.rect(follower_surf,(100,220,255),(0,0,32,32))
    follower = SpriteLayer(follower_surf, name="follower")
    # animate along path by sampling path at t normalized to timeline
    # cheat by keying x/y with path samples at multiple times
    steps = 40
    for i in range(steps+1):
        tt = i/steps * 6.0
        px,py = path.sample(i/steps,"bezier")
        follower.x.set_key(tt, px); follower.y.set_key(tt, py)
    follower.order = 3
    timeline.add_layer(follower)

    # particle emitter attached to follower
    emitter = ParticleSystem(name="emitter", x=700, y=250, rate=160, spread=1.5, speed=(60,220), color=(255,200,80))
    # keep emitter position keyed to follower
    for i in range(steps+1):
        tt = i/steps * 6.0
        px,py = path.sample(i/steps,"bezier")
        emitter.x = px; emitter.y = py  # set initial; override at render via property? simpler: set in render via follower position
    # override render to use follower position
    def emitter_render_override(surf, t, camera):
        px = follower.x.eval(t); py = follower.y.eval(t)
        emitter._x = px; emitter._y = py
        ParticleSystem.render(emitter, surf, t, camera)
    emitter.render = emitter_render_override
    emitter.order = 4
    timeline.add_layer(emitter)

    # skeleton example - two bones with IK
    b1 = Bone(120, angle=-30); b2 = Bone(80, angle=30, parent=b1)
    # create a shape controlled by IK (visual)
    hand_surf = pygame.Surface((24,24), pygame.SRCALPHA); pygame.draw.circle(hand_surf, (200,100,255),(12,12),10)
    hand_layer = SpriteLayer(hand_surf, name="hand")
    # key target moving
    hand_layer.x.set_key(0, 512); hand_layer.y.set_key(0, 200)
    hand_layer.x.set_key(4, 700); hand_layer.y.set_key(4, 350, easing="in_out")
    # each frame, solve IK and place the bone end and draw small markers (we'll draw markers in render override)
    def hand_render_override(surf, t, camera):
        tx = hand_layer.x.eval(t); ty = hand_layer.y.eval(t)
        # local coordinates root at (512,420)
        rootx, rooty = 512,420
        # convert target to root-local
        txloc = tx - rootx; tyloc = ty - rooty
        ik_2bone(b1, b2, txloc, tyloc)
        # compute joint world positions
        jx1 = rootx + math.cos(math.radians(b1.angle))*b1.length
        jy1 = rooty + math.sin(math.radians(b1.angle))*b1.length
        jx2 = jx1 + math.cos(math.radians(b1.angle + b2.angle))*b2.length
        jy2 = jy1 + math.sin(math.radians(b1.angle + b2.angle))*b2.length
        # draw bones
        pygame.draw.line(surf, (255,255,255), (rootx,rooty), (jx1,jy1), 4)
        pygame.draw.line(surf, (200,200,255), (jx1,jy1), (jx2,jy2), 3)
        # draw end effector sprite
        screenx, screeny = camera.world_to_screen(jx2, jy2)
        surf.blit(hand_surf, (screenx-12, screeny-12))
    hand_layer.render = hand_render_override
    hand_layer.order = 6
    timeline.add_layer(hand_layer)

    # some text
    caption = TextLayer("Animator2D — Advanced Demo", size=28, color=(220,220,220), name="title")
    caption.x.set_key(0,512); caption.y.set_key(0,60)
    caption.order = 1
    timeline.add_layer(caption)

    # physics demo: falling circles
    phys = PhysicsEngine(bounds=(0,0,1024,720))
    bA = Body(300,100, radius=22, mass=2.0); phys.add(bA)
    bB = Body(320, 200, radius=24, mass=1.5); phys.add(bB)
    # link to layers via simple render overrides
    circ_surfA = pygame.Surface((44,44), pygame.SRCALPHA); pygame.draw.circle(circ_surfA,(100,220,100),(22,22),22)
    circ_surfB = pygame.Surface((48,48), pygame.SRCALPHA); pygame.draw.circle(circ_surfB,(220,120,120),(24,24),24)
    layerA = SpriteLayer(circ_surfA, name="physA"); layerA.order=5
    layerB = SpriteLayer(circ_surfB, name="physB"); layerB.order=5
    def physA_render(surf, t, camera):
        # step physics a bit for demo
        phys.step(1/60.0)
        x,y = bA.x, bA.y
        sx,sy = camera.world_to_screen(x,y)
        surf.blit(circ_surfA, (sx-22, sy-22))
    def physB_render(surf, t, camera):
        x,y = bB.x, bB.y
        sx,sy = camera.world_to_screen(x,y)
        surf.blit(circ_surfB, (sx-24, sy-24))
    layerA.render = physA_render; layerB.render = physB_render
    timeline.add_layer(layerA); timeline.add_layer(layerB)

    # timeline controls
    timeline.play()
    renderer.start()

if __name__ == "__main__":
    demo()
