"""
This file is a revised version of the standard library-'random'.
It includes more random generators and additional functionalities.
Requires the 'random' module.
"""
"""
REVISED RANDOM MODULE
---------------------

A custom randomization module inspired by Python's built-in `random`,
but with additional utilities:

• seed()
• randint()
• randfloat()
• choice()
• shuffle()
• weighted_choice()
• random_color()
• random_string()
• random_bool()
• coin_flip()
• dice()

Uses Python's built-in random internally.
"""

# Necessary imports
import random
import string


# ================================
# CORE FUNCTIONS
# ================================
def seed(value=None):
    """Set the seed for reproducible results."""
    random.seed(value)


def randint(a, b):
    """Return a random integer between a and b (inclusive)."""
    return random.randint(a, b)


def randfloat(a=0.0, b=1.0):
    """Return a random float between a and b."""
    return random.uniform(a, b)


def randrange(start, stop=None, step=1):
    """Return a random number from a range."""
    return random.randrange(start, stop, step)


def choice(seq):
    """Choose a random element from a sequence."""
    if not seq:
        raise ValueError("Cannot choose from an empty sequence")
    return random.choice(seq)


def shuffle(seq):
    """Shuffle a list in-place and also return it."""
    random.shuffle(seq)
    return seq


# ================================
# ADVANCED FEATURES
# ================================
def weighted_choice(options, weights):
    """
    Choose an element based on weights.
    
    options : list of items
    weights : list of positive numbers
    """
    if len(options) != len(weights):
        raise ValueError("Options and weights must be the same length.")
    return random.choices(options, weights=weights, k=1)[0]


def random_color(fmt="rgb"):
    """
    Generate a random color.
    
    • rgb → (r, g, b)
    • hex → "#A1F03B"
    """

    r, g, b = randint(0, 255), randint(0, 255), randint(0, 255)

    if fmt == "rgb":
        return (r, g, b)
    elif fmt == "hex":
        return "#{:02X}{:02X}{:02X}".format(r, g, b)
    else:
        raise ValueError("Invalid color format. Use 'rgb' or 'hex'.")


def random_bool():
    """Return True or False randomly."""
    return random.choice([True, False])


def coin_flip():
    """Return 'Heads' or 'Tails'."""
    return random.choice(["Heads", "Tails"])


def dice(sides=6):
    """Roll a dice with N sides."""
    return randint(1, sides)


def random_string(length=10, chars="letters+digits"):
    """
    Generate a random string.

    chars:
        • "letters"
        • "digits"
        • "letters+digits"
        • "all" (symbols too)
    """
    if chars == "letters":
        pool = string.ascii_letters
    elif chars == "digits":
        pool = string.digits
    elif chars == "letters+digits":
        pool = string.ascii_letters + string.digits
    elif chars == "all":
        pool = string.ascii_letters + string.digits + string.punctuation
    else:
        raise ValueError("Unknown character set")

    return "".join(random.choice(pool) for _ in range(length))


# ================================
# SPECIAL UTILITIES
# ================================
def random_point_2d(x_range, y_range):
    """Return a random 2D point (x, y)."""
    return (randfloat(*x_range), randfloat(*y_range))


def random_point_3d(x_range, y_range, z_range):
    """Return a random 3D point (x, y, z)."""
    return (
        randfloat(*x_range),
        randfloat(*y_range),
        randfloat(*z_range),
    )
