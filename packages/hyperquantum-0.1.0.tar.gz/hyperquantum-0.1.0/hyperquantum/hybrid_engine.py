"""
This file contains a game engine module like pygame but very advanced.
This module is a part of the HyperQuantum_ library.
It provides various functions and features to create both 2D and 3D games equally well.
"""
# hybrid_engine.py
"""
Hybrid 2D/3D single-file engine.

Dependencies:
    pip install pygame PyOpenGL numpy pymunk pillow

Features:
 - Window & input via pygame
 - OpenGL rendering (2D textured quads + 3D meshes)
 - Orthographic 2D camera + Perspective 3D camera
 - Scene & Entity system
 - Transform, Sprite2D, Mesh3D components
 - Basic shader loader, texture loader
 - Resource manager (images, shaders)
 - Simple pymunk-based 2D physics integration
 - Simple demo toggling 2D/3D scenes
"""

import sys, math, time, os
from collections import deque

# Imports with helpful messages
try:
    import pygame
    from pygame.locals import *
except Exception as e:
    raise RuntimeError("pygame is required: pip install pygame") from e

try:
    from OpenGL.GL import *
    from OpenGL.GLU import *
except Exception as e:
    raise RuntimeError("PyOpenGL is required: pip install PyOpenGL") from e

try:
    import numpy as np
except Exception as e:
    raise RuntimeError("numpy is required: pip install numpy") from e

# pymunk optional
try:
    import pymunk
except Exception:
    pymunk = None

try:
    from PIL import Image
except Exception:
    Image = None

# ----------------------
# Utilities
# ----------------------
def now(): return time.time()
def clamp(v,a,b): return max(a,min(b,v))
def identity_mat4():
    return np.eye(4, dtype=np.float32)

def translate(x,y,z):
    m = identity_mat4()
    m[3,0:3] = [x,y,z]
    return m

def perspective(fovy, aspect, near, far):
    f = 1.0 / math.tan(math.radians(fovy) / 2.0)
    m = np.zeros((4,4), dtype=np.float32)
    m[0,0] = f / aspect
    m[1,1] = f
    m[2,2] = (far + near) / (near - far)
    m[2,3] = -1.0
    m[3,2] = (2*far*near) / (near - far)
    return m

def orthographic(left, right, bottom, top, near, far):
    m = np.zeros((4,4), dtype=np.float32)
    m[0,0] = 2.0/(right-left)
    m[1,1] = 2.0/(top-bottom)
    m[2,2] = -2.0/(far-near)
    m[3,0] = -(right+left)/(right-left)
    m[3,1] = -(top+bottom)/(top-bottom)
    m[3,2] = -(far+near)/(far-near)
    m[3,3] = 1.0
    return m

def look_at(eye, target, up=(0,1,0)):
    e = np.array(eye, dtype=np.float32)
    t = np.array(target, dtype=np.float32)
    u = np.array(up, dtype=np.float32)
    z = e - t
    z = z / np.linalg.norm(z)
    x = np.cross(u, z)
    x = x / np.linalg.norm(x)
    y = np.cross(z, x)
    m = np.eye(4, dtype=np.float32)
    m[0,0:3] = x
    m[1,0:3] = y
    m[2,0:3] = z
    m[3,0:3] = e
    # invert transform
    return np.linalg.inv(m)

# ----------------------
# GL Shader helpers
# ----------------------
def compile_shader(src, shader_type):
    shader = glCreateShader(shader_type)
    glShaderSource(shader, src)
    glCompileShader(shader)
    ok = glGetShaderiv(shader, GL_COMPILE_STATUS)
    if not ok:
        err = glGetShaderInfoLog(shader).decode()
        raise RuntimeError("Shader compile error:\n" + err)
    return shader

def link_program(vs_src, fs_src):
    vs = compile_shader(vs_src, GL_VERTEX_SHADER)
    fs = compile_shader(fs_src, GL_FRAGMENT_SHADER)
    prog = glCreateProgram()
    glAttachShader(prog, vs)
    glAttachShader(prog, fs)
    glLinkProgram(prog)
    ok = glGetProgramiv(prog, GL_LINK_STATUS)
    if not ok:
        err = glGetProgramInfoLog(prog).decode()
        raise RuntimeError("Shader link error:\n" + err)
    # cleanup shaders (they stay attached)
    glDeleteShader(vs); glDeleteShader(fs)
    return prog

# ----------------------
# Basic Shaders
# ----------------------
DEFAULT_VS_3D = """
#version 130
in vec3 position;
in vec2 uv;
in vec3 normal;
uniform mat4 u_model;
uniform mat4 u_view;
uniform mat4 u_proj;
out vec2 v_uv;
out vec3 v_normal;
void main(){
    gl_Position = u_proj * u_view * u_model * vec4(position, 1.0);
    v_uv = uv;
    v_normal = mat3(u_model) * normal;
}
"""
DEFAULT_FS_3D = """
#version 130
in vec2 v_uv;
in vec3 v_normal;
uniform sampler2D u_tex;
uniform vec4 u_color;
out vec4 fragColor;
void main(){
    vec3 n = normalize(v_normal);
    float light = clamp(dot(n, normalize(vec3(0.5,0.8,0.6))) * 0.7 + 0.3, 0.0, 1.0);
    vec4 t = texture(u_tex, v_uv);
    fragColor = mix(u_color, t, t.a) * light;
}
"""

DEFAULT_VS_2D = """
#version 130
in vec3 position;
in vec2 uv;
uniform mat4 u_model;
uniform mat4 u_viewproj;
out vec2 v_uv;
void main(){
    gl_Position = u_viewproj * u_model * vec4(position,1.0);
    v_uv = uv;
}
"""
DEFAULT_FS_2D = """
#version 130
in vec2 v_uv;
uniform sampler2D u_tex;
uniform vec4 u_color;
out vec4 fragColor;
void main(){
    vec4 t = texture(u_tex, v_uv);
    fragColor = mix(u_color, t, t.a);
}
"""

# ----------------------
# Resource Manager
# ----------------------
class Resources:
    shaders = {}
    textures = {}
    def load_shader(self, key, vs_src, fs_src):
        if key in Resources.shaders: return Resources.shaders[key]
        prog = link_program(vs_src, fs_src)
        Resources.shaders[key] = prog
        return prog
    def load_texture(self, path):
        if path in Resources.textures: return Resources.textures[path]
        if not os.path.isfile(path):
            raise FileNotFoundError(path)
        if Image is None:
            raise RuntimeError("Pillow required for textures: pip install pillow")
        img = Image.open(path).transpose(Image.FLIP_TOP_BOTTOM).convert("RGBA")
        data = img.tobytes()
        w,h = img.size
        tex = glGenTextures(1)
        glBindTexture(GL_TEXTURE_2D, tex)
        glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, w, h, 0, GL_RGBA, GL_UNSIGNED_BYTE, data)
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR)
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR)
        glBindTexture(GL_TEXTURE_2D, 0)
        Resources.textures[path] = (tex, w, h)
        return Resources.textures[path]

# ----------------------
# Basic Mesh data
# (a unit quad and a cube)
# ----------------------
# Quad (position xyz, uv)
quad_vertices = np.array([
    # x,y,z,    u,v
    -0.5, -0.5, 0.0,  0.0, 0.0,
     0.5, -0.5, 0.0,  1.0, 0.0,
     0.5,  0.5, 0.0,  1.0, 1.0,
    -0.5,  0.5, 0.0,  0.0, 1.0
], dtype=np.float32)

quad_indices = np.array([0,1,2, 2,3,0], dtype=np.uint32)

cube_vertices = np.array([
    # positions        u v    normals (simple approximate)
    -0.5,-0.5,-0.5,  0,0,   0,0,-1,
     0.5,-0.5,-0.5,  1,0,   0,0,-1,
     0.5, 0.5,-0.5,  1,1,   0,0,-1,
    -0.5, 0.5,-0.5,  0,1,   0,0,-1,
    # front
    -0.5,-0.5, 0.5,  0,0,   0,0,1,
     0.5,-0.5, 0.5,  1,0,   0,0,1,
     0.5, 0.5, 0.5,  1,1,   0,0,1,
    -0.5, 0.5, 0.5,  0,1,   0,0,1,
    # left
    -0.5,-0.5,-0.5,  0,0,  -1,0,0,
    -0.5, 0.5,-0.5,  1,0,  -1,0,0,
    -0.5, 0.5, 0.5,  1,1,  -1,0,0,
    -0.5,-0.5, 0.5,  0,1,  -1,0,0,
    # right
     0.5,-0.5,-0.5,  0,0,   1,0,0,
     0.5, 0.5,-0.5,  1,0,   1,0,0,
     0.5, 0.5, 0.5,  1,1,   1,0,0,
     0.5,-0.5, 0.5,  0,1,   1,0,0,
    # bottom
    -0.5,-0.5,-0.5,  0,0,   0,-1,0,
     0.5,-0.5,-0.5,  1,0,   0,-1,0,
     0.5,-0.5, 0.5,  1,1,   0,-1,0,
    -0.5,-0.5, 0.5,  0,1,   0,-1,0,
    # top
    -0.5, 0.5,-0.5,  0,0,   0,1,0,
     0.5, 0.5,-0.5,  1,0,   0,1,0,
     0.5, 0.5, 0.5,  1,1,   0,1,0,
    -0.5, 0.5, 0.5,  0,1,   0,1,0,
], dtype=np.float32)

cube_indices = np.array([
 0,1,2, 2,3,0,
 4,5,6, 6,7,4,
 8,9,10, 10,11,8,
 12,13,14, 14,15,12,
 16,17,18, 18,19,16,
 20,21,22, 22,23,20
], dtype=np.uint32)

# ----------------------
# GL Buffer helpers
# ----------------------
def create_vbo(data, usage=GL_STATIC_DRAW):
    vbo = glGenBuffers(1)
    glBindBuffer(GL_ARRAY_BUFFER, vbo)
    glBufferData(GL_ARRAY_BUFFER, data.nbytes, data, usage)
    glBindBuffer(GL_ARRAY_BUFFER, 0)
    return vbo

def create_ebo(data, usage=GL_STATIC_DRAW):
    ebo = glGenBuffers(1)
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, ebo)
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, data.nbytes, data, usage)
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, 0)
    return ebo

# ----------------------
# Cameras
# ----------------------
class Camera2D:
    def __init__(self, width, height, x=0, y=0, zoom=1.0):
        self.width = width; self.height = height
        self.x=x; self.y=y; self.zoom=zoom
    def get_viewproj(self):
        hw = self.width/2.0/self.zoom; hh = self.height/2.0/self.zoom
        left = self.x - hw; right = self.x + hw
        bottom = self.y - hh; top = self.y + hh
        return orthographic(left, right, bottom, top, -1000, 1000)
    def world_to_screen(self, wx, wy):
        sx = (wx - self.x) * self.zoom + self.width/2.0
        sy = (wy - self.y) * self.zoom + self.height/2.0
        return int(sx), int(sy)

class Camera3D:
    def __init__(self, width, height, fovy=60.0, pos=(0,0,5), target=(0,0,0)):
        self.width = width; self.height = height
        self.fovy = fovy; self.pos = np.array(pos, dtype=np.float32); self.target = np.array(target, dtype=np.float32)
    def get_proj(self):
        aspect = max(0.1, self.width / float(self.height))
        return perspective(self.fovy, aspect, 0.1, 1000.0)
    def get_view(self):
        return look_at(self.pos, self.target)

# ----------------------
# Scene / Entity / Components
# ----------------------
class Component:
    def __init__(self): self.entity = None
    def start(self): pass
    def update(self, dt): pass
    def draw(self, *args, **kwargs): pass
    def on_destroy(self): pass

class Entity:
    def __init__(self, name="Entity"):
        self.name = name
        self.components = []
        self.x = 0.0; self.y = 0.0; self.z = 0.0
        self.sx = 1.0; self.sy = 1.0; self.sz = 1.0
        self.rotation = 0.0
        self.active = True
        self.scene = None
    def add(self, comp):
        comp.entity = self
        self.components.append(comp)
        try: comp.start()
        except Exception as e: print("comp start error", e)
        return comp
    def get(self, typ):
        for c in self.components:
            if isinstance(c, typ): return c
        return None
    def update(self, dt):
        if not self.active: return
        for c in self.components:
            try: c.update(dt)
            except Exception as e: print("comp update error", e)
    def draw(self, *args, **kwargs):
        if not self.active: return
        for c in self.components:
            try: c.draw(*args, **kwargs)
            except Exception as e: print("comp draw error", e)
    def transform_matrix(self):
        # simple model matrix (translate * rotateZ * scale)
        t = np.eye(4, dtype=np.float32)
        t[3,0:3] = [self.x, self.y, self.z]
        # rotation about Z
        r = np.eye(4, dtype=np.float32)
        a = math.radians(self.rotation)
        ca = math.cos(a); sa = math.sin(a)
        r[0,0] = ca; r[0,1] = -sa
        r[1,0] = sa; r[1,1] = ca
        s = np.eye(4, dtype=np.float32)
        s[0,0] = self.sx; s[1,1] = self.sy; s[2,2] = self.sz
        return s @ r @ t

class Scene:
    def __init__(self, engine):
        self.engine = engine
        self.entities = []
        self.timer = []
        # pymunk physics world for 2D usage (optional)
        self.space = pymunk.Space() if pymunk else None
        if self.space:
            self.space.gravity = (0.0, 800.0)
    def add(self, entity):
        entity.scene = self
        self.entities.append(entity)
        return entity
    def update(self, dt):
        for e in list(self.entities):
            e.update(dt)
        if self.space:
            # step physics
            try:
                self.space.step(dt)
            except Exception as ex:
                print("physics step error", ex)
    def draw(self):
        # 2D pass (orthographic)
        self.engine.begin_2d()
        # user draws 2D sprites by component
        for e in self.entities:
            e.draw(self.engine, pass_type='2d')
        self.engine.end_2d()
        # 3D pass (perspective)
        self.engine.begin_3d()
        for e in self.entities:
            e.draw(self.engine, pass_type='3d')
        self.engine.end_3d()

# ----------------------
# Components: Sprite2D (textured quad), Mesh3D (cube)
# ----------------------
class Sprite2D(Component):
    def __init__(self, texture_path=None, color=(1,1,1,1), size=(1.0,1.0)):
        super().__init__()
        self.texture_path = texture_path
        self.color = color
        self.size = size
        self.gl_tex = None
        self._prog = None
        self.vbo = None
        self.ebo = None
    def start(self):
        res = self.entity.scene.engine.resources
        self._prog = res.load_shader("2d", DEFAULT_VS_2D, DEFAULT_FS_2D)
        if self.texture_path:
            self.gl_tex = res.load_texture(self.texture_path)
        # create buffers for quad
        self.vbo = create_vbo(np.array(quad_vertices, dtype=np.float32))
        self.ebo = create_ebo(np.array(quad_indices, dtype=np.uint32))
    def draw(self, engine, pass_type='2d'):
        if pass_type!='2d': return
        prog = self._prog
        glUseProgram(prog)
        # compute model matrix from entity transform
        m = self.entity.transform_matrix()
        # scale quad by size
        sm = np.eye(4, dtype=np.float32)
        sm[0,0] = self.size[0]; sm[1,1] = self.size[1]
        model = sm @ m
        loc = glGetUniformLocation(prog, "u_model")
        glUniformMatrix4fv(loc, 1, GL_FALSE, model.T.flatten())
        # viewproj uniform
        vp_loc = glGetUniformLocation(prog, "u_viewproj")
        vp = engine.camera2d.get_viewproj()
        glUniformMatrix4fv(vp_loc, 1, GL_FALSE, vp.T.flatten())
        # color
        c_loc = glGetUniformLocation(prog, "u_color")
        glUniform4f(c_loc, *self.color)
        # bind texture if present
        if self.gl_tex:
            glActiveTexture(GL_TEXTURE0)
            glBindTexture(GL_TEXTURE_2D, self.gl_tex[0])
            tloc = glGetUniformLocation(prog, "u_tex")
            glUniform1i(tloc, 0)
        # enable arrays and draw
        glBindBuffer(GL_ARRAY_BUFFER, self.vbo)
        pos_loc = glGetAttribLocation(prog, "position")
        uv_loc = glGetAttribLocation(prog, "uv")
        glEnableVertexAttribArray(pos_loc)
        glVertexAttribPointer(pos_loc, 3, GL_FLOAT, GL_FALSE, 5*4, ctypes.c_void_p(0))
        glEnableVertexAttribArray(uv_loc)
        glVertexAttribPointer(uv_loc, 2, GL_FLOAT, GL_FALSE, 5*4, ctypes.c_void_p(3*4))
        glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, self.ebo)
        glDrawElements(GL_TRIANGLES, 6, GL_UNSIGNED_INT, None)
        # cleanup
        glDisableVertexAttribArray(pos_loc)
        glDisableVertexAttribArray(uv_loc)
        glBindBuffer(GL_ARRAY_BUFFER, 0)
        glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, 0)
        if self.gl_tex: glBindTexture(GL_TEXTURE_2D, 0)
        glUseProgram(0)

class Mesh3D(Component):
    def __init__(self, color=(0.7,0.7,0.9,1.0), textured=False, texture_path=None, scale=1.0):
        super().__init__()
        self.color=color; self.textured=textured; self.texture_path=texture_path; self.scale=scale
        self.vbo=None; self.ebo=None; self._prog=None; self.gl_tex=None
    def start(self):
        res = self.entity.scene.engine.resources
        self._prog = res.load_shader("3d", DEFAULT_VS_3D, DEFAULT_FS_3D)
        if self.textured and self.texture_path:
            self.gl_tex = res.load_texture(self.texture_path)
        self.vbo = create_vbo(np.array(cube_vertices, dtype=np.float32))
        self.ebo = create_ebo(np.array(cube_indices, dtype=np.uint32))
    def draw(self, engine, pass_type='3d'):
        if pass_type!='3d': return
        prog = self._prog
        glUseProgram(prog)
        # model matrix from entity
        m = self.entity.transform_matrix()
        # apply uniform scale
        sm = np.eye(4, dtype=np.float32)
        sm[0,0] = sm[1,1] = sm[2,2] = self.scale
        model = m @ sm
        locm = glGetUniformLocation(prog, "u_model")
        glUniformMatrix4fv(locm, 1, GL_FALSE, model.T.flatten())
        # view & proj
        view_loc = glGetUniformLocation(prog, "u_view")
        proj_loc = glGetUniformLocation(prog, "u_proj")
        view = engine.camera3d.get_view()
        proj = engine.camera3d.get_proj()
        glUniformMatrix4fv(view_loc, 1, GL_FALSE, view.T.flatten())
        glUniformMatrix4fv(proj_loc, 1, GL_FALSE, proj.T.flatten())
        # color
        col_loc = glGetUniformLocation(prog, "u_color")
        glUniform4f(col_loc, *self.color)
        # texture
        if self.gl_tex:
            glActiveTexture(GL_TEXTURE0)
            glBindTexture(GL_TEXTURE_2D, self.gl_tex[0])
            tloc = glGetUniformLocation(prog, "u_tex")
            glUniform1i(tloc, 0)
        # attributes: position(3), uv(2), normal(3) -> stride 8 floats
        glBindBuffer(GL_ARRAY_BUFFER, self.vbo)
        pos_loc = glGetAttribLocation(prog, "position")
        uv_loc = glGetAttribLocation(prog, "uv")
        n_loc = glGetAttribLocation(prog, "normal")
        glEnableVertexAttribArray(pos_loc)
        glVertexAttribPointer(pos_loc, 3, GL_FLOAT, GL_FALSE, 8*4, ctypes.c_void_p(0))
        glEnableVertexAttribArray(uv_loc)
        glVertexAttribPointer(uv_loc, 2, GL_FLOAT, GL_FALSE, 8*4, ctypes.c_void_p(3*4))
        glEnableVertexAttribArray(n_loc)
        glVertexAttribPointer(n_loc, 3, GL_FLOAT, GL_FALSE, 8*4, ctypes.c_void_p(5*4))
        glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, self.ebo)
        glDrawElements(GL_TRIANGLES, len(cube_indices), GL_UNSIGNED_INT, None)
        # cleanup
        glDisableVertexAttribArray(pos_loc)
        glDisableVertexAttribArray(uv_loc)
        glDisableVertexAttribArray(n_loc)
        glBindBuffer(GL_ARRAY_BUFFER, 0)
        glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, 0)
        if self.gl_tex: glBindTexture(GL_TEXTURE_2D, 0)
        glUseProgram(0)

# ----------------------
# Engine main class
# ----------------------
def create_vbo(data, usage=GL_STATIC_DRAW):
    return create_vbo_gl(data, usage)

def create_vbo_gl(data, usage=GL_STATIC_DRAW):
    vbo = glGenBuffers(1)
    glBindBuffer(GL_ARRAY_BUFFER, vbo)
    glBufferData(GL_ARRAY_BUFFER, data.nbytes, data, usage)
    glBindBuffer(GL_ARRAY_BUFFER, 0)
    return vbo

def create_ebo(data, usage=GL_STATIC_DRAW):
    ebo = glGenBuffers(1)
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, ebo)
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, data.nbytes, data, usage)
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, 0)
    return ebo

class Engine:
    def __init__(self, size=(1024,720), title="HybridEngine", gl_flags=DOUBLEBUF|OPENGL):
        pygame.display.gl_set_attribute(pygame.GL_CONTEXT_MAJOR_VERSION, 3)
        pygame.display.gl_set_attribute(pygame.GL_CONTEXT_MINOR_VERSION, 0)
        pygame.display.gl_set_attribute(pygame.GL_CONTEXT_PROFILE_MASK, pygame.GL_CONTEXT_PROFILE_CORE)
        pygame.display.set_mode(size, gl_flags)
        pygame.display.set_caption(title)
        self.screen_size = size
        self.clock = pygame.time.Clock()
        self.resources = Resources()
        self.current_scene = None
        self.camera2d = Camera2D(size[0], size[1])
        self.camera3d = Camera3D(size[0], size[1])
        # compile default shaders upfront
        self.resources.load_shader("2d", DEFAULT_VS_2D, DEFAULT_FS_2D)
        self.resources.load_shader("3d", DEFAULT_VS_3D, DEFAULT_FS_3D)
        # GL defaults
        glEnable(GL_BLEND); glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA)
        glEnable(GL_DEPTH_TEST)
        glDepthFunc(GL_LESS)
        # toggles
        self._in_2d = False
        self._in_3d = False
        # input
        self._mouse = (0,0)
        self.running = False

    def set_scene(self, scene):
        self.current_scene = scene

    # 2D pass helpers
    def begin_2d(self):
        # clear depth for 2D pass if mixing
        glDisable(GL_DEPTH_TEST)
        self._in_2d = True

    def end_2d(self):
        glEnable(GL_DEPTH_TEST)
        self._in_2d = False

    # 3D pass helpers
    def begin_3d(self):
        glEnable(GL_DEPTH_TEST)
        self._in_3d = True

    def end_3d(self):
        self._in_3d = False

    def main_loop(self, fps=60):
        self.running = True
        last = now()
        while self.running:
            cur = now(); dt = cur - last; last = cur
            if dt > 0.2: dt = 0.2
            # events
            for ev in pygame.event.get():
                if ev.type == pygame.QUIT:
                    self.quit()
                elif ev.type == pygame.KEYDOWN and ev.key == pygame.K_ESCAPE:
                    self.quit()
                elif ev.type == pygame.KEYDOWN and ev.key == pygame.K_F2:
                    # toggle debug: reset camera positions (demo)
                    self.camera3d.pos = np.array((0,0,5), dtype=np.float32)
                # pass to scene if it wants low-level events
            # update
            if self.current_scene:
                self.current_scene.update(dt)
            # render
            glViewport(0,0,self.screen_size[0], self.screen_size[1])
            glClearColor(0.08, 0.08, 0.1, 1.0)
            glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)
            if self.current_scene:
                self.current_scene.draw()
            # swap
            pygame.display.flip()
            self.clock.tick(fps)

    def quit(self):
        self.running = False
        pygame.quit()
        sys.exit()

# ----------------------
# Demo scenes
# ----------------------
def demo():
    # initialize engine
    eng = Engine(size=(1000,700))
    scene = Scene(eng)
    eng.set_scene(scene)

    # 2D Sprite entity
    s = Entity("sprite2d")
    s.x, s.y = -200, 0
    s.sx, s.sy = 120, 120  # quad size scale (maps to quad unit * size)
    spr = s.add(Sprite2D(texture_path=None, color=(0.9,0.6,0.3,1.0), size=(120,120)))
    # If you have an image, set texture_path to the file path, e.g. "sprite.png"
    # spr.texture_path = "sprite.png"
    scene.add(s)

    # 3D cube
    c = Entity("cube")
    c.x, c.y, c.z = 150, 0, 0
    c.sx = c.sy = c.sz = 1.5
    mesh = c.add(Mesh3D(color=(0.7,0.8,1.0,1.0), textured=False, scale=1.2))
    scene.add(c)

    # Add simple rotation behavior components
    class Rotator(Component):
        def update(self, dt):
            self.entity.rotation += 20 * dt
    s.add(Rotator()); c.add(Rotator())

    # Add simple input toggling: press TAB to move sprite in 2D vs cube in 3D
    def simple_input():
        keys = pygame.key.get_pressed()
        if keys[pygame.K_TAB]:
            # rotate faster
            s.rotation += 240 * 0.016
    # add a tiny component that reads keyboard each frame
    class InputComp(Component):
        def update(self, dt):
            keys = pygame.key.get_pressed()
            speed = 200 * dt
            if keys[pygame.K_LEFT]:
                s.x -= speed
            if keys[pygame.K_RIGHT]:
                s.x += speed
            if keys[pygame.K_UP]:
                s.y -= speed
            if keys[pygame.K_DOWN]:
                s.y += speed
            # 3D camera orbit with WASD
            if keys[pygame.K_a]:
                eng.camera3d.pos[0] -= 2*dt*60
            if keys[pygame.K_d]:
                eng.camera3d.pos[0] += 2*dt*60
            if keys[pygame.K_w]:
                eng.camera3d.pos[2] -= 2*dt*60
            if keys[pygame.K_s]:
                eng.camera3d.pos[2] += 2*dt*60
    root = Entity("root")
    root.add(InputComp())
    scene.add(root)

    # basic GUI: print instructions to console and draw simple hud using pygame text
    font = pygame.font.SysFont("Arial", 16)
    def draw_hud():
        surf = pygame.display.get_surface()
        txt = "Use arrow keys to move 2D sprite. WASD to move camera in 3D. ESC to quit."
        srf = font.render(txt, True, (220,220,220))
        # blit using pygame (after OpenGL flip, using glWindowPos will be complicated)
        # Instead draw overlay via glDrawPixels is slow; we'll use pygame to draw text on top by creating a texture.
        # Easiest method: call pygame.display.get_surface().blit then flip. But as we're using OpenGL context,
        # blitting with pygame is unreliable. We'll skip complex overlay in demo. Print to console instead:
        pass
    print("Demo running. Arrow keys	move 2D sprite. WASD	move 3D camera. ESC exit.")

    eng.main_loop()

if __name__ == "__main__":
    demo()
# End of hybrid_engine.py