"""
This file contains code for the math functions of the HyperQuantum_ Library.
It incldes operations like addition, subtraction, multiplication, division, etc.
Also more advanced functions like exponentiation, roots, basic algebra, and tetration.
"""

# Necessary imports
import math

# Functions
def addition(a, b):
    return a + b

def subtraction(a, b):
    return a - b

def multiplication(a, b):
    return a * b

def flr_div(a, b):
    return a // b and a % b

def cmpl_div(a, b):
    return a / b

def exponent(a, b):
    return a ** b

def sqrt(a):
    return a ** 0.5

def tetration(a, b):
    result = a
    for _ in range(b - 1):
        result = a ** result
    return result

def curt(a):
    return a ** (1/3)

def any_rt(a, b):
    return a ** (1/b)

def mod(a, b):
    return a % b

def negation(a):
    return -a

def basic_algebra(a, b, operation):
    if operation == 'add':
        return addition(a, b)
    elif operation == 'subtract':
        return subtraction(a, b)
    elif operation == 'multiply':
        return multiplication(a, b)
    elif operation == 'divide':
        return cmpl_div(a, b)
    else:
        raise ValueError("Unsupported operation")
    
def pi():
    return 3.141592653589793

def perimeter_shape(a, b, c, shape_type):
    if shape_type == "triangle":
        return a + b + c
    elif shape_type == "rectangle":
        return 2 * (a + b)
    elif shape_type == "square":
        return 4 * a
    elif shape_type == "circle":
        return 2 * pi() * a
    elif shape_type == "pentagon":
        return 5 * a
    elif shape_type == "hexagon":
        return 6 * a
    elif shape_type == "octagon":
        return 8 * a
    elif shape_type == "parallelogram":
        return 2 * (a + b)
    elif shape_type == "regular_trapezium":
        return a + b + (2 * c)
    else:
        raise ValueError("Unsupported shape type")
    
def area_shape(a, b, c, s, shape_type):
    if shape_type == "triangle":
        s = (a + b + c) / 2
        return math.sqrt(s * (s - a) * (s - b) * (s - c))
    elif shape_type == "rectangle":
        return a * b
    elif shape_type == "square":
        return a ** 2
    elif shape_type == "circle":
        return pi() * (a ** 2)
    elif shape_type == "pentagon":
        return (1/4) * math.sqrt(5 * (5 + 2 * math.sqrt(5))) * (a ** 2)
    elif shape_type == "hexagon":
        return (3 * math.sqrt(3) / 2) * (a ** 2)
    elif shape_type == "octagon":
        return 2 * (1 + math.sqrt(2)) * (a ** 2)
    elif shape_type == "parallelogram":
        return a * b
    elif shape_type == "regular_trapezium":
        return ((a + b) / 2) * c
    else:
        raise ValueError("Unsupported shape type")
    
def volume_shape(a, b, c, shape_type):
    if shape_type == "cube":
        return a ** 3
    elif shape_type == "cuboid":
        return a * b * c
    elif shape_type == "cylinder":
        return pi() * (a ** 2) * b
    elif shape_type == "sphere":
        return (4/3) * pi() * (a ** 3)
    elif shape_type == "cone":
        return (1/3) * pi() * (a ** 2) * b
    elif shape_type == "pyramid":
        return (1/3) * a * b * c
    else:
        raise ValueError("Unsupported shape type")
    
def surface_area_shape(a, b, c, shape_type):
    if shape_type == "cube":
        return 6 * (a ** 2)
    elif shape_type == "cuboid":
        return 2 * (a * b + b * c + a * c)
    elif shape_type == "cylinder":
        return 2 * pi() * a * (a + b)
    elif shape_type == "sphere":
        return 4 * pi() * (a ** 2)
    elif shape_type == "cone":
        slant_height = math.sqrt((a ** 2) + (b ** 2))
        return pi() * a * (a + slant_height)
    elif shape_type == "pyramid":
        base_area = a * b
        slant_height_a = math.sqrt((b / 2) ** 2 + c ** 2)
        slant_height_b = math.sqrt((a / 2) ** 2 + c ** 2)
        lateral_area = (a * slant_height_a + b * slant_height_b)
        return base_area + lateral_area
    else:
        raise ValueError("Unsupported shape type")
    
def factorial(a):
    if a < 0:
        raise ValueError("Factorial is not defined for negative numbers")
    elif a == 0 or a == 1:
        return 1
    else:
        result = 1
        for i in range(2, a + 1):
            result *= i
        return result
    
# Help functions
def help_math_functions():
    help_text = """
    HyperQuantum_ Math Functions Help:

    1. Basic Operations:
       - addition(a, b)
       - subtraction(a, b)
       - multiplication(a, b)
       - flr_div(a, b)
       - cmpl_div(a, b)

    2. Advanced Operations:
       - exponent(a, b)
       - sqrt(a)
       - tetration(a, b)
       - curt(a)
       - any_rt(a, b)
       - mod(a, b)
       - negation(a)

    3. Algebra:
       - basic_algebra(a, b, operation)

    4. Geometric Calculations:
       - perimeter_shape(a, b, c, shape_type)
       - area_shape(a, b, c, s, shape_type)
       - volume_shape(a, b, c, shape_type)
       - surface_area_shape(a, b, c, shape_type)

    5. Other Functions:
       - pi()
       - factorial(a)

    For more details on each function, refer to the documentation.
    """
    print(help_text)

def list():
    functions_list = [
        "addition",
        "subtraction",
        "multiplication",
        "flr_div",
        "cmpl_div",
        "exponent",
        "sqrt",
        "tetration",
        "curt",
        "any_rt",
        "mod",
        "negation",
        "basic_algebra",
        "perimeter_shape",
        "area_shape",
        "volume_shape",
        "surface_area_shape",
        "pi",
        "factorial"
    ]
    return functions_list

# End of HyperQuantum_ Math Functions Module