"""
This file is a simple ui module of the HyperQuantum_ library.
It provides basic UI components like Window, Button, TextBox, InputField, Image, Grid, Tabs, and MenuBar.
This module is built over pygame to facilitate easy UI creation and to make a light-weight UI system for anyone who will use this library.
"""

import pygame
import sys

pygame.init()

# -----------------------------
# Base Styles
# -----------------------------
FONT = pygame.font.SysFont("Arial", 20)

def draw_text(surface, text, pos, color=(255,255,255)):
    t = FONT.render(text, True, color)
    surface.blit(t, pos)


# -----------------------------
# Window
# -----------------------------
class Window:
    def __init__(self, title="MyUI", size=(600, 400), bg=(30, 30, 30)):
        self.size = size
        self.bg = bg
        self.screen = pygame.display.set_mode(size)
        pygame.display.set_caption(title)
        self.widgets = []

    def add(self, widget):
        widget.parent = self
        self.widgets.append(widget)

    def run(self):
        clock = pygame.time.Clock()
        while True:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()

                for w in self.widgets:
                    w.handle_event(event)

            self.screen.fill(self.bg)

            for w in self.widgets:
                w.draw(self.screen)

            pygame.display.flip()
            clock.tick(60)


# -----------------------------
# Button
# -----------------------------
class Button:
    def __init__(self, text, pos, size=(120, 40),
                 bg=(70,70,70), hover=(100,100,100),
                 text_color=(255,255,255), onclick=None):
        
        self.text = text
        self.x, self.y = pos
        self.w, self.h = size

        self.bg = bg
        self.hover = hover
        self.text_color = text_color

        self.onclick = onclick
        self.parent = None

    def rect(self):
        return pygame.Rect(self.x, self.y, self.w, self.h)

    def draw(self, screen):
        mouse = pygame.mouse.get_pos()
        color = self.hover if self.rect().collidepoint(mouse) else self.bg

        pygame.draw.rect(screen, color, self.rect(), border_radius=8)
        draw_text(screen, self.text, (self.x+10, self.y+10), self.text_color)

    def handle_event(self, event):
        if event.type == pygame.MOUSEBUTTONDOWN:
            if self.onclick and self.rect().collidepoint(event.pos):
                self.onclick()


# -----------------------------
# Text Box (Label)
# -----------------------------
class TextBox:
    def __init__(self, text, pos, color=(255,255,255)):
        self.text = text
        self.x, self.y = pos
        self.color = color
        self.parent = None

    def draw(self, screen):
        draw_text(screen, self.text, (self.x, self.y), self.color)

    def handle_event(self, event):
        pass


# -----------------------------
# Input Field
# -----------------------------
class InputField:
    def __init__(self, pos, size=(200, 40),
                 bg=(50,50,50), active_bg=(80,80,80),
                 text_color=(255,255,255)):
        
        self.x, self.y = pos
        self.w, self.h = size

        self.bg = bg
        self.active_bg = active_bg
        self.text_color = text_color

        self.text = ""
        self.active = False
        self.parent = None

    def rect(self):
        return pygame.Rect(self.x, self.y, self.w, self.h)

    def draw(self, screen):
        color = self.active_bg if self.active else self.bg
        pygame.draw.rect(screen, color, self.rect(), border_radius=6)

        draw_text(screen, self.text, (self.x+5, self.y+10), self.text_color)

    def handle_event(self, event):
        if event.type == pygame.MOUSEBUTTONDOWN:
            self.active = self.rect().collidepoint(event.pos)

        if self.active and event.type == pygame.KEYDOWN:
            if event.key == pygame.K_BACKSPACE:
                self.text = self.text[:-1]
            else:
                self.text += event.unicode


# -----------------------------
# Image Widget
# -----------------------------
class Image:
    def __init__(self, path, pos, size=None):
        self.img = pygame.image.load(path)
        if size:
            self.img = pygame.transform.scale(self.img, size)
        self.x, self.y = pos
        self.parent = None

    def draw(self, screen):
        screen.blit(self.img, (self.x, self.y))

    def handle_event(self, event):
        pass


# -----------------------------
# Grid Layout
# -----------------------------
class Grid:
    def __init__(self, pos, cell_size=(150, 50), columns=2, spacing=10):
        self.x, self.y = pos
        self.cell_w, self.cell_h = cell_size
        self.columns = columns
        self.spacing = spacing

        self.children = []
        self.parent = None

    def add(self, widget):
        self.children.append(widget)

    def draw(self, screen):
        for i, widget in enumerate(self.children):
            col = i % self.columns
            row = i // self.columns

            widget.x = self.x + col*(self.cell_w + self.spacing)
            widget.y = self.y + row*(self.cell_h + self.spacing)

            widget.draw(screen)

    def handle_event(self, event):
        for w in self.children:
            w.handle_event(event)


# -----------------------------
# Tabs
# -----------------------------
class Tabs:
    def __init__(self, pos, size):
        self.x, self.y = pos
        self.w, self.h = size
        self.tabs = {}
        self.active_tab = None
        self.parent = None
        self.tab_buttons = []

    def add_tab(self, name, widget_group):
        self.tabs[name] = widget_group

        btn_x = self.x + len(self.tab_buttons) * 110
        btn = Button(name, (btn_x, self.y), size=(100, 35),
                     onclick=lambda n=name: self.switch_tab(n))
        
        self.tab_buttons.append(btn)

        if self.active_tab is None:
            self.active_tab = name

    def switch_tab(self, name):
        self.active_tab = name

    def draw(self, screen):
        for btn in self.tab_buttons:
            btn.draw(screen)

        if self.active_tab:
            for w in self.tabs[self.active_tab]:
                w.draw(screen)

    def handle_event(self, event):
        for btn in self.tab_buttons:
            btn.handle_event(event)

        if self.active_tab:
            for w in self.tabs[self.active_tab]:
                w.handle_event(event)


# -----------------------------
# Menu Bar
# -----------------------------
class MenuBar:
    def __init__(self, pos=(0,0), height=40):
        self.x, self.y = pos
        self.h = height
        self.items = []
        self.parent = None

    def add(self, text, onclick):
        self.items.append(Button(text, pos=(10 + len(self.items)*120, self.y),
                                 size=(110, self.h-5), onclick=onclick))

    def draw(self, screen):
        pygame.draw.rect(screen, (50,50,50), (self.x, self.y, 10000, self.h))
        for item in self.items:
            item.draw(screen)

    def handle_event(self, event):
        for item in self.items:
            item.handle_event(event)


# -----------------------------
# EXPORTS (for user import)
# -----------------------------
__all__ = [
    "Window",
    "Button",
    "TextBox",
    "InputField",
    "Image",
    "Grid",
    "Tabs",
    "MenuBar"
]
# End of myui.py