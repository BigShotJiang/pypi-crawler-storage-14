"""
scriptkit.py
A tiny scripting language interpreter for automation.
"""

import time
import pyautogui

class ScriptEngine:
    def __init__(self):
        self.commands = {
            "PRINT": self.cmd_print,
            "WAIT": self.cmd_wait,
            "TYPE": self.cmd_type,
            "CLICK": self.cmd_click,
            "MOVE": self.cmd_move,
        }

    def run(self, script: str):
        for line in script.split("\n"):
            line = line.strip()
            if not line:
                continue

            parts = line.split(" ", 1)
            cmd = parts[0].upper()

            arg = parts[1] if len(parts) > 1 else ""

            if cmd in self.commands:
                self.commands[cmd](arg)
            else:
                print(f"[ERROR] Unknown command: {cmd}")

    # ---------------- Commands -----------------

    def cmd_print(self, arg):
        print(arg)

    def cmd_wait(self, arg):
        time.sleep(float(arg))

    def cmd_type(self, arg):
        pyautogui.write(arg)

    def cmd_click(self, arg):
        pyautogui.click()

    def cmd_move(self, arg):
        x, y = arg.split()
        pyautogui.moveTo(int(x), int(y))
