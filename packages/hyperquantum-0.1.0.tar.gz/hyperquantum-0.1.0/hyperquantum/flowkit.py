"""
flowkit.py
A simple flow-based programming engine (nodes + connections).
"""

class Node:
    def __init__(self, name, func=None):
        self.name = name
        self.func = func if func else lambda x: x
        self.outputs = []

    def connect(self, node):
        self.outputs.append(node)
        return node

    def run(self, value):
        result = self.func(value)
        for out in self.outputs:
            out.run(result)


class Flow:
    def __init__(self):
        self.start = None

    def set_start(self, node):
        self.start = node

    def execute(self, value=None):
        if not self.start:
            raise ValueError("No start node set.")
        self.start.run(value)


# --------------------------------------------------------------
# PRE-MADE NODES (you can add 50+ later)
# --------------------------------------------------------------

def PrintNode():
    return Node("print", lambda x: print(x) or x)

def UpperNode():
    return Node("upper", lambda x: x.upper())

def ReverseNode():
    return Node("reverse", lambda x: x[::-1])

def AddNode(n):
    return Node("add", lambda x: x + n)

# ---------------------------
# BaseNode and Flow support
# ---------------------------
from typing import Any, Dict, List, Optional, Callable

class BaseNode:
    """
    Base class for FlowKit nodes.

    - `name` and `category` can be overridden by subclasses.
    - `inputs` and `outputs` are lists of input/output names (strings).
    - `process(...)` should be implemented by subclasses. It receives positional
      or keyword args based on `inputs` and should return a dict mapping output
      names to values.
    - `connect(node, output_name=None)` links this node's output to another node.
      If output_name is omitted, the first declared output is used (or 'default').
    - `run(value)` executes node: it dispatches value(s) to `process` and forwards
      outputs to connected nodes.
    """

    name: str = "BaseNode"
    category: str = "Generic"
    inputs: List[str] = []
    outputs: List[str] = []

    def __init__(self, **kwargs):
        # store runtime state and connections
        # connections: { output_name: [node1, node2, ...] }
        self._connections: Dict[str, List[BaseNode]] = {}
        # initialize connection lists for declared outputs
        for out in getattr(self, "outputs", []) or []:
            self._connections[out] = []
        # a default bucket if a node doesn't declare outputs
        if not self._connections:
            self._connections["default"] = []
        # optional: local storage for node (params)
        self.params = kwargs

    def connect(self, node: "BaseNode", output_name: Optional[str] = None) -> "BaseNode":
        """
        Connect this node to `node`. If output_name is None, use the first output
        declared on this node (or 'default').
        Returns the connected node for chaining.
        """
        if output_name is None:
            if getattr(self, "outputs", None):
                output_name = self.outputs[0]
            else:
                output_name = "default"

        if output_name not in self._connections:
            # allow dynamic outputs
            self._connections[output_name] = []

        self._connections[output_name].append(node)
        return node

    def _call_process(self, *args, **kwargs) -> Dict[str, Any]:
        """
        Internal: call process method and normalize result to dict.
        Subclasses implement `process(...)`.
        """
        if not hasattr(self, "process"):
            # default passthrough behavior
            if len(args) == 1 and not kwargs:
                return { (self.outputs[0] if self.outputs else "default"): args[0] }
            return {}
        result = self.process(*args, **kwargs)
        if result is None:
            return {}
        if isinstance(result, dict):
            return result
        # if process returns single scalar, put into first output
        key = self.outputs[0] if getattr(self, "outputs", None) else "default"
        return {key: result}

    def run(self, value: Any = None):
        """
        Execute this node with `value`.
        - If this node declares no inputs, call process() with no args.
        - If value is a dict, map inputs to args by name.
        - If value is a scalar and node has exactly one input, call process(scalar).
        After process, dispatch each returned output value to connected nodes.
        """
        # prepare args for process
        try:
            if not getattr(self, "inputs", None):
                result_map = self._call_process()
            else:
                # if caller passed a dict we use names, otherwise try to map
                if isinstance(value, dict):
                    # build kwargs for inputs (missing keys -> None)
                    kwargs = {k: value.get(k, None) for k in self.inputs}
                    result_map = self._call_process(**kwargs)
                else:
                    # scalar / tuple mapping
                    if len(self.inputs) == 1:
                        result_map = self._call_process(value)
                    elif isinstance(value, (list, tuple)) and len(value) == len(self.inputs):
                        result_map = self._call_process(*value)
                    else:
                        # fallback: send value as first input and None for rest
                        args = [value] + [None]*(len(self.inputs)-1)
                        result_map = self._call_process(*args)
        except Exception as e:
            # safe failure mode: print error and do not crash entire flow
            print(f"[FlowKit] Error in node '{self.name}' process: {e}")
            result_map = {}

        # dispatch outputs
        if not result_map:
            return

        # For each declared output (or keys from result_map), forward to connected nodes
        for out_name, val in result_map.items():
            # if out_name not in connections, try default fallback
            conns = self._connections.get(out_name) or self._connections.get("default", [])
            for n in conns:
                # forward as dict if n expects named inputs; otherwise forward scalar
                if getattr(n, "inputs", None):
                    # if single input, forward scalar; if multiple, forward as dict with keys as their names when possible
                    if len(n.inputs) == 1:
                        n.run(val)
                    else:
                        # try to wrap by input name matching; if mismatch, pass scalar
                        if isinstance(val, dict):
                            n.run(val)
                        else:
                            n.run({ n.inputs[0]: val })
                else:
                    n.run(val)

    # convenience alias to support old usage where Node.connect returned node and .run expected scalar
    def __call__(self, value=None):
        return self.run(value)


# Optional Flow manager if you want a central runner (not required)
class Flow:
    def __init__(self):
        self.start_nodes: List[BaseNode] = []

    def add_start(self, node: BaseNode):
        self.start_nodes.append(node)

    def run(self, value: Any = None):
        for n in self.start_nodes:
            n.run(value)


class ToUpperNode(BaseNode):
    name = "ToUpper"
    category = "String"
    inputs = ["text"]
    outputs = ["upper_text"]

    def process(self, text):
        return {"upper_text": text.upper()}


class ToLowerNode(BaseNode):
    name = "ToLower"
    category = "String"
    inputs = ["text"]
    outputs = ["lower_text"]

    def process(self, text):
        return {"lower_text": text.lower()}


class SplitTextNode(BaseNode):
    name = "SplitText"
    category = "String"
    inputs = ["text", "sep"]
    outputs = ["parts"]

    def process(self, text, sep=" "):
        return {"parts": text.split(sep)}


class JoinTextNode(BaseNode):
    name = "JoinText"
    category = "String"
    inputs = ["parts", "sep"]
    outputs = ["text"]

    def process(self, parts, sep=" "):
        return {"text": sep.join(parts)}


class ReplaceTextNode(BaseNode):
    name = "ReplaceText"
    category = "String"
    inputs = ["text", "old", "new"]
    outputs = ["text"]

    def process(self, text, old, new):
        return {"text": text.replace(old, new)}


class ContainsNode(BaseNode):
    name = "Contains"
    category = "String"
    inputs = ["text", "keyword"]
    outputs = ["contains"]

    def process(self, text, keyword):
        return {"contains": keyword in text}


class SubstringNode(BaseNode):
    name = "Substring"
    category = "String"
    inputs = ["text", "start", "end"]
    outputs = ["substring"]

    def process(self, text, start, end):
        return {"substring": text[start:end]}


# ---------- LIST OPERATIONS ----------
class ListAppendNode(BaseNode):
    name = "ListAppend"
    category = "List"
    inputs = ["list", "item"]
    outputs = ["result"]

    def process(self, list, item):
        return {"result": list + [item]}


class ListExtendNode(BaseNode):
    name = "ListExtend"
    category = "List"
    inputs = ["list1", "list2"]
    outputs = ["result"]

    def process(self, list1, list2):
        return {"result": list1 + list2}


class ListSortNode(BaseNode):
    name = "ListSort"
    category = "List"
    inputs = ["list"]
    outputs = ["sorted_list"]

    def process(self, list):
        return {"sorted_list": sorted(list)}


class UniqueNode(BaseNode):
    name = "Unique"
    category = "List"
    inputs = ["list"]
    outputs = ["unique_list"]

    def process(self, list):
        return {"unique_list": list(dict.fromkeys(list))}


class ListReverseNode(BaseNode):
    name = "ListReverse"
    category = "List"
    inputs = ["list"]
    outputs = ["reversed"]

    def process(self, list):
        return {"reversed": list[::-1]}


# ---------- MATH NODES ----------
class ClampNode(BaseNode):
    name = "Clamp"
    category = "Math"
    inputs = ["value", "min_val", "max_val"]
    outputs = ["result"]

    def process(self, value, min_val, max_val):
        return {"result": max(min_val, min(value, max_val))}


class LerpNode(BaseNode):
    name = "Lerp"
    category = "Math"
    inputs = ["a", "b", "t"]
    outputs = ["result"]

    def process(self, a, b, t):
        return {"result": a + (b - a) * t}


class DistanceNode(BaseNode):
    name = "Distance"
    category = "Math"
    inputs = ["x1", "y1", "x2", "y2"]
    outputs = ["distance"]

    def process(self, x1, y1, x2, y2):
        return {"distance": ((x2 - x1)**2 + (y2 - y1)**2)**0.5}


class DotProductNode(BaseNode):
    name = "DotProduct"
    category = "Math"
    inputs = ["v1", "v2"]
    outputs = ["dot"]

    def process(self, v1, v2):
        return {"dot": sum(a*b for a, b in zip(v1, v2))}


class CrossProductNode(BaseNode):
    name = "CrossProduct"
    category = "Math"
    inputs = ["a", "b"]
    outputs = ["result"]

    def process(self, a, b):
        ax, ay, az = a
        bx, by, bz = b
        return {"result": (ay*bz - az*by, az*bx - ax*bz, ax*by - ay*bx)}


# ---------- DATETIME NODES ----------
import datetime

class NowNode(BaseNode):
    name = "Now"
    category = "DateTime"
    inputs = []
    outputs = ["now"]

    def process(self):
        return {"now": datetime.datetime.now()}


class FormatDateNode(BaseNode):
    name = "FormatDate"
    category = "DateTime"
    inputs = ["date", "fmt"]
    outputs = ["formatted"]

    def process(self, date, fmt):
        return {"formatted": date.strftime(fmt)}


class TimestampNode(BaseNode):
    name = "Timestamp"
    category = "DateTime"
    inputs = ["date"]
    outputs = ["timestamp"]

    def process(self, date):
        return {"timestamp": date.timestamp()}


# ---------- FILE SYSTEM ----------
import os

class ReadFileNode(BaseNode):
    name = "ReadFile"
    category = "File"
    inputs = ["path"]
    outputs = ["content"]

    def process(self, path):
        with open(path, "r", encoding="utf8") as f:
            return {"content": f.read()}


class WriteFileNode(BaseNode):
    name = "WriteFile"
    category = "File"
    inputs = ["path", "content"]
    outputs = ["success"]

    def process(self, path, content):
        with open(path, "w", encoding="utf8") as f:
            f.write(content)
        return {"success": True}


class FileExistsNode(BaseNode):
    name = "FileExists"
    category = "File"
    inputs = ["path"]
    outputs = ["exists"]

    def process(self, path):
        return {"exists": os.path.exists(path)}


# ---------- NETWORK ----------
import requests

class HttpGetNode(BaseNode):
    name = "HttpGet"
    category = "Network"
    inputs = ["url"]
    outputs = ["text"]

    def process(self, url):
        return {"text": requests.get(url).text}


class HttpStatusNode(BaseNode):
    name = "HttpStatus"
    category = "Network"
    inputs = ["url"]
    outputs = ["status_code"]

    def process(self, url):
        return {"status_code": requests.get(url).status_code}


class DownloadFileNode(BaseNode):
    name = "DownloadFile"
    category = "Network"
    inputs = ["url", "path"]
    outputs = ["success"]

    def process(self, url, path):
        data = requests.get(url).content
        with open(path, "wb") as f:
            f.write(data)
        return {"success": True}


# ---------- JSON / DATA ----------
import json

class JsonLoadNode(BaseNode):
    name = "JsonLoad"
    category = "Data"
    inputs = ["text"]
    outputs = ["data"]

    def process(self, text):
        return {"data": json.loads(text)}


class JsonDumpNode(BaseNode):
    name = "JsonDump"
    category = "Data"
    inputs = ["data"]
    outputs = ["text"]

    def process(self, data):
        return {"text": json.dumps(data, indent=2)}


# ---------- RANDOM ----------
import random

class RandomIntNode(BaseNode):
    name = "RandomInt"
    category = "Random"
    inputs = ["a", "b"]
    outputs = ["value"]

    def process(self, a, b):
        return {"value": random.randint(a, b)}


class RandomFloatNode(BaseNode):
    name = "RandomFloat"
    category = "Random"
    inputs = ["a", "b"]
    outputs = ["value"]

    def process(self, a, b):
        return {"value": random.uniform(a, b)}


class ChoiceNode(BaseNode):
    name = "Choice"
    category = "Random"
    inputs = ["list"]
    outputs = ["choice"]

    def process(self, list):
        return {"choice": random.choice(list)}


# ---------- AUDIO ----------
try:
    import sounddevice as sd
except:
    sd = None

class BeepNode(BaseNode):
    name = "Beep"
    category = "Audio"
    inputs = ["freq", "duration"]
    outputs = ["success"]

    def process(self, freq, duration):
        if not sd:
            return {"success": False}
        import numpy as np
        t = np.linspace(0, duration, int(44100*duration), False)
        tone = np.sin(freq * t * 2 * np.pi)
        sd.play(tone, 44100)
        sd.wait()
        return {"success": True}


# ---------- IMAGE ----------
try:
    from PIL import Image
except:
    Image = None

class LoadImageNode(BaseNode):
    name = "LoadImage"
    category = "Image"
    inputs = ["path"]
    outputs = ["image"]

    def process(self, path):
        if Image:
            return {"image": Image.open(path)}
        return {"image": None}


class SaveImageNode(BaseNode):
    name = "SaveImage"
    category = "Image"
    inputs = ["image", "path"]
    outputs = ["success"]

    def process(self, image, path):
        if Image:
            image.save(path)
            return {"success": True}
        return {"success": False}


# ---------- MISC ----------
class PrintNode(BaseNode):
    name = "Print"
    category = "Utility"
    inputs = ["value"]
    outputs = ["value"]

    def process(self, value):
        print(value)
        return {"value": value}


class TypeNode(BaseNode):
    name = "Type"
    category = "Utility"
    inputs = ["value"]
    outputs = ["type"]

    def process(self, value):
        return {"type": str(type(value))}


class SleepNode(BaseNode):
    name = "Sleep"
    category = "Utility"
    inputs = ["seconds"]
    outputs = ["status"]

    def process(self, seconds):
        import time
        time.sleep(seconds)
        return {"status": True}

