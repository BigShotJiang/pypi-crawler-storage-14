# uiextra.py
"""
=========================================================
 UIEXTRA - ADVANCED UI FRAMEWORK (Built on Tkinter)
=========================================================

Features:
    ✔ Modern UI elements
    ✔ Layouts: VBox, HBox, Grid
    ✔ Animations (fade, slide)
    ✔ Theming system
    ✔ Tabs, Menus, DropDown
    ✔ Styled Buttons, Labels, Inputs
    ✔ Image widgets
    ✔ Window manager
    ✔ Embedded frames (for app injection)
    ✔ Event system
    ✔ Canvas-based drawing
"""

import tkinter as tk
from tkinter import ttk
from PIL import Image, ImageTk
import time
import threading


# =========================================================
#  COLOR & THEME SYSTEM
# =========================================================

class Theme:
    def __init__(self):
        self.primary = "#4A90E2"
        self.accent = "#50E3C2"
        self.bg = "#1F1F1F"
        self.text = "#FFFFFF"
        self.button_bg = "#333333"
        self.button_hover = "#444444"

theme = Theme()


# =========================================================
#  BASE WIDGET CLASS
# =========================================================

class UIElement:
    def __init__(self, widget):
        self.widget = widget

    def show(self):
        self.widget.pack()

    def hide(self):
        self.widget.pack_forget()

    def set_position(self, x, y):
        self.widget.place(x=x, y=y)


# =========================================================
#  WINDOW
# =========================================================

class UIWindow:
    def __init__(self, title="UIExtra Window", size=(600, 500)):
        self.root = tk.Tk()
        self.root.title(title)
        self.root.geometry(f"{size[0]}x{size[1]}")
        self.root.configure(bg=theme.bg)

        # modern ttk
        style = ttk.Style()
        style.theme_use("clam")

    def add(self, widget):
        widget.show()

    def run(self):
        self.root.mainloop()


# =========================================================
#  LABEL
# =========================================================

class UILabel(UIElement):
    def __init__(self, window: UIWindow, text="", size=14):
        self.lbl = tk.Label(window.root,
                            text=text,
                            fg=theme.text,
                            bg=theme.bg,
                            font=("Segoe UI", size))
        super().__init__(self.lbl)

    def set_text(self, t):
        self.lbl.config(text=t)


# =========================================================
#  BUTTON
# =========================================================

class UIButton(UIElement):
    def __init__(self, window: UIWindow, text="Button", command=None):
        self.btn = tk.Button(
            window.root,
            text=text,
            bg=theme.button_bg,
            fg=theme.text,
            activebackground=theme.button_hover,
            activeforeground=theme.text,
            relief="flat",
            padx=10,
            pady=5,
            command=command
        )
        super().__init__(self.btn)


# =========================================================
#  INPUT FIELD
# =========================================================

class UIInput(UIElement):
    def __init__(self, window: UIWindow, placeholder=""):
        self.var = tk.StringVar()
        self.entry = tk.Entry(window.root,
                              textvariable=self.var,
                              bg="#262626",
                              fg=theme.text,
                              insertbackground=theme.text,
                              relief="flat")
        self.entry.insert(0, placeholder)
        super().__init__(self.entry)

    def get(self):
        return self.var.get()

    def set(self, t):
        self.var.set(t)


# =========================================================
#  IMAGE WIDGET
# =========================================================

class UIImage(UIElement):
    def __init__(self, window: UIWindow, path, size=(150, 150)):
        img = Image.open(path).resize(size, Image.ANTIALIAS)
        self.photo = ImageTk.PhotoImage(img)
        self.lbl = tk.Label(window.root, image=self.photo, bg=theme.bg)
        super().__init__(self.lbl)


# =========================================================
#  MENU BAR
# =========================================================

class UIMenuBar:
    def __init__(self, window: UIWindow):
        self.menu = tk.Menu(window.root)
        window.root.config(menu=self.menu)

    def add_menu(self, name, commands: dict):
        m = tk.Menu(self.menu, tearoff=0)
        for label, func in commands.items():
            m.add_command(label=label, command=func)
        self.menu.add_cascade(label=name, menu=m)


# =========================================================
#  TABS
# =========================================================

class UITabs(UIElement):
    def __init__(self, window: UIWindow, tabs: dict):
        self.notebook = ttk.Notebook(window.root)
        self.frames = {}

        for label, frame in tabs.items():
            f = tk.Frame(self.notebook, bg=theme.bg)
            self.notebook.add(f, text=label)
            self.frames[label] = f

        super().__init__(self.notebook)

    def get_frame(self, label):
        return self.frames[label]


# =========================================================
#  LAYOUTS
# =========================================================

class VBox(UIElement):
    def __init__(self, window: UIWindow, spacing=6):
        self.frame = tk.Frame(window.root, bg=theme.bg)
        self.spacing = spacing
        super().__init__(self.frame)

    def add(self, widget: UIElement):
        widget.widget.pack(pady=self.spacing)


class HBox(UIElement):
    def __init__(self, window: UIWindow, spacing=6):
        self.frame = tk.Frame(window.root, bg=theme.bg)
        self.spacing = spacing
        super().__init__(self.frame)

    def add(self, widget: UIElement):
        widget.widget.pack(side="left", padx=self.spacing)


class Grid(UIElement):
    def __init__(self, window: UIWindow):
        self.frame = tk.Frame(window.root, bg=theme.bg)
        super().__init__(self.frame)

    def add(self, widget: UIElement, row, col):
        widget.widget.grid(row=row, column=col, padx=4, pady=4)


# =========================================================
#  EMBEDDED FRAME
# =========================================================

class UIEmbed(UIElement):
    def __init__(self, window: UIWindow):
        frame = tk.Frame(window.root, bg=theme.bg)
        super().__init__(frame)

    def mount(self, widget: UIElement):
        widget.widget.pack(in_=self.widget)


# =========================================================
#  CANVAS DRAWING
# =========================================================

class UICanvas(UIElement):
    def __init__(self, window: UIWindow, size=(400, 300)):
        self.canvas = tk.Canvas(window.root,
                                width=size[0],
                                height=size[1],
                                bg=theme.bg,
                                highlightthickness=0)
        super().__init__(self.canvas)

    def line(self, x1, y1, x2, y2, color="white", w=2):
        self.canvas.create_line(x1, y1, x2, y2, fill=color, width=w)

    def circle(self, x, y, r, color="white"):
        self.canvas.create_oval(x-r, y-r, x+r, y+r, outline=color, width=2)

    def rect(self, x, y, w, h, color="white"):
        self.canvas.create_rectangle(x, y, x+w, y+h, outline=color, width=2)


# =========================================================
#  ANIMATIONS
# =========================================================

class Animation:
    @staticmethod
    def fade(widget: UIElement, duration=0.5):
        def _fade():
            for i in range(0, 100):
                alpha = i / 100
                try:
                    widget.widget.attributes("-alpha", alpha)
                except:
                    break
                time.sleep(duration / 100)

        threading.Thread(target=_fade).start()

    @staticmethod
    def slide(widget: UIElement, target_x, target_y, duration=0.3):
        x0 = widget.widget.winfo_x()
        y0 = widget.widget.winfo_y()
        steps = 40

        dx = (target_x - x0) / steps
        dy = (target_y - y0) / steps

        def _slide():
            for i in range(steps):
                widget.set_position(x0 + dx*i, y0 + dy*i)
                time.sleep(duration / steps)

        threading.Thread(target=_slide).start()


# =========================================================
#  DEMO
# =========================================================

if __name__ == "__main__":
    ui = UIWindow("UIExtra Demo", (800, 600))

    VBox1 = VBox(ui); VBox1.show()
    lbl = UILabel(ui, "UIExtra Framework Demo", 20); VBox1.add(lbl)
    btn = UIButton(ui, "Click Me"); VBox1.add(btn)

    tabs = UITabs(ui, {"Tab 1": None, "Tab 2": None})
    tabs.show()

    ui.run()
