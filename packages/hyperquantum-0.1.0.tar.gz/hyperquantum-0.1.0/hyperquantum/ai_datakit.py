# ai_datakit.py
"""
AI + Data Toolkit (combined modules 9,10,11,12)
- MiniTensor: tensor + autograd + small NN (Linear, MLP)
- DataForge: DataFrame & Series (CSV, groupby, agg)
- SmartSearch: TF-IDF, BM25, vector search, simple summarizer (TextRank)
- Recommender: user-item CF, item-item CF, SVD factorization, content-based

Dependencies: numpy (required). scipy optional (faster SVD).
"""

from __future__ import annotations
import math, csv, re, heapq, itertools, json, time
from typing import Any, Callable, Dict, Iterable, List, Optional, Tuple
import numpy as np

# optional scipy
try:
    import scipy.sparse.linalg as spla
    _has_scipy = True
except Exception:
    _has_scipy = False

# ---------------------------
# MiniTensor with Autograd
# ---------------------------
class Tensor:
    """
    Minimal tensor with autograd (reverse-mode).
    Wraps numpy arrays.
    """
    def __init__(self, data, requires_grad=False):
        self.data = np.array(data, dtype=float)
        self.grad = None
        self.requires_grad = requires_grad
        self._ctx = None  # function context for backprop

    def __repr__(self):
        return f"Tensor(shape={self.data.shape}, requires_grad={self.requires_grad})"

    # basic ops
    def __add__(self, other):
        other = other if isinstance(other, Tensor) else Tensor(other)
        out = Tensor(self.data + other.data, requires_grad=self.requires_grad or other.requires_grad)
        def _backward():
            if self.requires_grad:
                self.grad = (self.grad or 0) + out._ctx['grad_out']
            if other.requires_grad:
                other.grad = (other.grad or 0) + out._ctx['grad_out']
        out._ctx = {'parents': (self, other), 'op':'add', 'backward':_backward, 'grad_out': None}
        return out

    def __mul__(self, other):
        other = other if isinstance(other, Tensor) else Tensor(other)
        out = Tensor(self.data * other.data, requires_grad=self.requires_grad or other.requires_grad)
        def _backward():
            if self.requires_grad:
                self.grad = (self.grad or 0) + out._ctx['grad_out'] * other.data
            if other.requires_grad:
                other.grad = (other.grad or 0) + out._ctx['grad_out'] * self.data
        out._ctx = {'parents': (self, other), 'op':'mul', 'backward':_backward, 'grad_out': None}
        return out

    def matmul(self, other):
        other = other if isinstance(other, Tensor) else Tensor(other)
        out = Tensor(self.data.dot(other.data), requires_grad=self.requires_grad or other.requires_grad)
        def _backward():
            if self.requires_grad:
                self.grad = (self.grad or 0) + out._ctx['grad_out'].dot(other.data.T)
            if other.requires_grad:
                other.grad = (other.grad or 0) + self.data.T.dot(out._ctx['grad_out'])
        out._ctx = {'parents': (self, other), 'op':'matmul', 'backward':_backward, 'grad_out': None}
        return out

    def sum(self):
        out = Tensor(np.array(self.data.sum()), requires_grad=self.requires_grad)
        def _backward():
            if self.requires_grad:
                self.grad = (self.grad or 0) + out._ctx['grad_out'] * np.ones_like(self.data)
        out._ctx = {'parents': (self,), 'op':'sum', 'backward':_backward, 'grad_out': None}
        return out

    def mean(self):
        return self.sum() * (1.0 / self.data.size)

    # convenience
    def relu(self):
        out = Tensor(np.maximum(0, self.data), requires_grad=self.requires_grad)
        mask = (self.data > 0).astype(float)
        def _backward():
            if self.requires_grad:
                self.grad = (self.grad or 0) + out._ctx['grad_out'] * mask
        out._ctx = {'parents': (self,), 'op':'relu', 'backward':_backward, 'grad_out': None}
        return out

    def sigmoid(self):
        s = 1.0 / (1.0 + np.exp(-self.data))
        out = Tensor(s, requires_grad=self.requires_grad)
        def _backward():
            if self.requires_grad:
                self.grad = (self.grad or 0) + out._ctx['grad_out'] * s * (1 - s)
        out._ctx = {'parents': (self,), 'op':'sigmoid', 'backward':_backward, 'grad_out': None}
        return out

    def backward(self, grad_out=None):
        # simple autograd: assume scalar output
        if grad_out is None:
            grad_out = np.ones_like(self.data)
        self.grad = grad_out
        topo = []
        visited = set()
        def build(v):
            if v not in visited and getattr(v, "_ctx", None):
                visited.add(v)
                for p in v._ctx.get('parents', []):
                    build(p)
                topo.append(v)
        build(self)
        # traverse in reverse
        for node in reversed(topo):
            node._ctx['grad_out'] = node.grad
            # call backward to propagate
            node._ctx['backward']()

# ---------------------------
# Layers & Optimizers
# ---------------------------
class Module:
    def parameters(self) -> List[Tensor]:
        return []

class Linear(Module):
    def __init__(self, in_dim, out_dim):
        self.W = Tensor(np.random.randn(in_dim, out_dim) * math.sqrt(2.0/(in_dim+out_dim)), requires_grad=True)
        self.b = Tensor(np.zeros(out_dim), requires_grad=True)
    def __call__(self, x: np.ndarray):
        # x: np.ndarray batch x in_dim
        return Tensor(x).matmul(self.W) + self.b

    def parameters(self):
        return [self.W, self.b]

class MLP(Module):
    def __init__(self, dims: List[int], activation='relu'):
        self.layers = []
        for a,b in zip(dims[:-1], dims[1:]):
            self.layers.append(Linear(a,b))
        self.activation = activation
    def __call__(self, x: np.ndarray):
        t = Tensor(x)
        for i,layer in enumerate(self.layers):
            t = layer.W.matmul(t) if False else layer(t.data)  # use simple route: call layer
            # but layer returns Tensor via __call__ above
            if i != len(self.layers)-1:
                if self.activation == 'relu':
                    t = t.relu()
                else:
                    t = t.sigmoid()
        return t
    def parameters(self):
        ps=[]
        for l in self.layers:
            ps+=l.parameters()
        return ps

class SGD:
    def __init__(self, params: List[Tensor], lr=1e-3):
        self.params = params
        self.lr = lr
    def step(self):
        for p in self.params:
            if p.grad is None: continue
            p.data -= self.lr * p.grad
            p.grad = None

class Adam:
    def __init__(self, params: List[Tensor], lr=1e-3, betas=(0.9,0.999), eps=1e-8):
        self.params = params
        self.lr = lr
        self.b1, self.b2 = betas
        self.eps = eps
        self.m = [np.zeros_like(p.data) for p in params]
        self.v = [np.zeros_like(p.data) for p in params]
        self.t = 0
    def step(self):
        self.t += 1
        for i,p in enumerate(self.params):
            if p.grad is None: continue
            g = p.grad
            self.m[i] = self.b1 * self.m[i] + (1-self.b1)*g
            self.v[i] = self.b2 * self.v[i] + (1-self.b2)*(g*g)
            mhat = self.m[i]/(1-self.b1**self.t)
            vhat = self.v[i]/(1-self.b2**self.t)
            p.data -= self.lr * mhat / (np.sqrt(vhat) + self.eps)
            p.grad = None

# ---------------------------
# DataFrame (mini-Pandas)
# ---------------------------
class Series:
    def __init__(self, data: List[Any]):
        self.data = list(data)
    def __len__(self): return len(self.data)
    def mean(self):
        arr = [x for x in self.data if isinstance(x,(int,float))]
        return sum(arr)/len(arr) if arr else None
    def to_numpy(self):
        return np.array(self.data)

class DataFrame:
    def __init__(self, data: Optional[Dict[str, List[Any]]] = None):
        self.columns = []
        self._data = {}
        if data:
            self.columns = list(data.keys())
            self._data = {k:list(v) for k,v in data.items()}

    @classmethod
    def read_csv(cls, path, delimiter=","):
        with open(path,"r", encoding="utf8") as f:
            rdr = csv.DictReader(f, delimiter=delimiter)
            cols = rdr.fieldnames
            data = {c:[] for c in cols}
            for r in rdr:
                for c in cols:
                    data[c].append(r[c])
            return cls(data)

    def to_csv(self, path):
        with open(path,"w", newline='', encoding="utf8") as f:
            writer = csv.writer(f)
            writer.writerow(self.columns)
            for i in range(len(self)):
                writer.writerow([self._data[c][i] for c in self.columns])

    def __len__(self):
        if not self.columns: return 0
        return len(self._data[self.columns[0]])

    def head(self, n=5):
        out = {c:self._data[c][:n] for c in self.columns}
        return DataFrame(out)

    def add_column(self, name, values):
        self.columns.append(name); self._data[name] = list(values)

    def get_column(self, name):
        return Series(self._data[name])

    def filter(self, fn: Callable[[Dict[str,Any]], bool]):
        # fn receives row dict
        rows = []
        for i in range(len(self)):
            row = {c:self._data[c][i] for c in self.columns}
            if fn(row): rows.append(row)
        if not rows: return DataFrame({c:[] for c in self.columns})
        out = {c:[r[c] for r in rows] for c in self.columns}
        return DataFrame(out)

    def groupby(self, key: str):
        groups = {}
        for i in range(len(self)):
            k = self._data[key][i]
            groups.setdefault(k, {c:[] for c in self.columns})
            for c in self.columns:
                groups[k][c].append(self._data[c][i])
        # return dict of DataFrame
        return {k: DataFrame(v) for k,v in groups.items()}

    def agg(self, column: str, func: Callable[[List[Any]], Any]):
        cols = {}
        cols[column] = [func(self._data[column])]
        return DataFrame(cols)

    def join(self, other: 'DataFrame', on: str, how='inner'):
        left = self; right = other
        idx = {}
        for i in range(len(right)):
            key = right._data[on][i]
            idx.setdefault(key, []).append(i)
        out = {c:[] for c in (left.columns + [c for c in right.columns if c not in left.columns])}
        for i in range(len(left)):
            k = left._data[on][i]
            if k in idx:
                for j in idx[k]:
                    for c in left.columns:
                        out[c].append(left._data[c][i])
                    for c in right.columns:
                        if c not in left.columns:
                            out[c].append(right._data[c][j])
            elif how in ('left','outer'):
                for c in left.columns:
                    out[c].append(left._data[c][i])
                for c in right.columns:
                    if c not in left.columns:
                        out[c].append(None)
        return DataFrame(out)

    def to_dicts(self):
        rows=[]
        for i in range(len(self)):
            rows.append({c:self._data[c][i] for c in self.columns})
        return rows

# ---------------------------
# SmartSearch (TF-IDF, BM25, TextRank summarizer)
# ---------------------------
_token_re = re.compile(r"\w+")
def tokenize(text: str):
    return [t.lower() for t in _token_re.findall(text)]

class TFIDFIndex:
    def __init__(self, docs: Iterable[str]):
        self.docs = list(docs)
        self.N = len(self.docs)
        self.doc_tokens = [tokenize(d) for d in self.docs]
        self.df = {}
        for toks in self.doc_tokens:
            for t in set(toks):
                self.df[t] = self.df.get(t,0)+1
        self.idf = {t: math.log((self.N+1)/(1+self.df[t])) for t in self.df}
        self.tfidf_vecs = [self._tfidf_vector(toks) for toks in self.doc_tokens]

    def _tfidf_vector(self, toks):
        tf = {}
        for t in toks: tf[t]=tf.get(t,0)+1
        vec={}
        for t,count in tf.items():
            if t in self.idf:
                vec[t] = (count/len(toks)) * self.idf[t]
        return vec

    def _cosine(self, a: Dict[str,float], b: Dict[str,float]):
        num = 0.0
        for k,v in a.items():
            if k in b: num += v*b[k]
        na = math.sqrt(sum(v*v for v in a.values()))
        nb = math.sqrt(sum(v*v for v in b.values()))
        if na==0 or nb==0: return 0.0
        return num/(na*nb)

    def query(self, q: str, topk=5):
        qvec = self._tfidf_vector(tokenize(q))
        scores = []
        for i,vec in enumerate(self.tfidf_vecs):
            scores.append((self._cosine(qvec, vec), i))
        scores.sort(reverse=True)
        return [(self.docs[i], s) for s,i in scores[:topk]]

class BM25Index:
    def __init__(self, docs: Iterable[str], k1=1.5, b=0.75):
        self.docs = list(docs)
        self.tokens = [tokenize(d) for d in self.docs]
        self.N = len(self.docs)
        self.avgdl = sum(len(t) for t in self.tokens)/self.N
        self.df={}
        self.tf_list=[]
        for toks in self.tokens:
            tf={}
            for t in toks: tf[t]=tf.get(t,0)+1
            self.tf_list.append(tf)
            for t in tf.keys(): self.df[t] = self.df.get(t,0)+1
        self.k1=k1; self.b=b

    def idf(self, term):
        n = self.df.get(term,0)
        return math.log(1 + (self.N - n + 0.5)/(n + 0.5))

    def score(self, q_terms, idx):
        score=0.0
        dl = len(self.tokens[idx])
        tf = self.tf_list[idx]
        for t in q_terms:
            if t not in tf: continue
            idf = self.idf(t)
            denom = tf[t] + self.k1*(1-self.b + self.b*dl/self.avgdl)
            score += idf * tf[t] * (self.k1+1)/denom
        return score

    def query(self, q: str, topk=5):
        terms = tokenize(q)
        scores = [(self.score(terms,i), i) for i in range(self.N)]
        scores.sort(reverse=True)
        return [(self.docs[i], s) for s,i in scores[:topk]]

# TextRank summarizer (very small)
def summarize_textrank(text: str, sentences=3):
    sents = re.split(r'(?<=[.!?])\s+', text)
    if len(sents) <= sentences: return text
    toks = [set(tokenize(s)) for s in sents]
    n = len(sents)
    # build graph weights by word overlap
    scores = [0.0]*n
    adj = [[0.0]*n for _ in range(n)]
    for i in range(n):
        for j in range(n):
            if i==j: continue
            inter = toks[i] & toks[j]
            if len(toks[i])==0 or len(toks[j])==0: w=0
            else: w = len(inter)/ (math.log(1+len(toks[i])) + math.log(1+len(toks[j])))
            adj[i][j]=w
    # pagerank-like
    d=0.85
    scores = [1.0]*n
    for _ in range(20):
        new=[(1-d) for _ in range(n)]
        for i in range(n):
            for j in range(n):
                s = sum(adj[k][j] for k in range(n))
                if s>0:
                    new[i] += d * sum(adj[i][j]/s * scores[j] for j in range(n))
        scores=new
    ranked = sorted(range(n), key=lambda i: scores[i], reverse=True)[:sentences]
    ranked.sort()
    return " ".join(sents[i] for i in ranked)

# ---------------------------
# Recommender Systems
# ---------------------------
def cosine_sim(a: np.ndarray, b: np.ndarray):
    na = np.linalg.norm(a)
    nb = np.linalg.norm(b)
    if na==0 or nb==0: return 0.0
    return float(a.dot(b)/(na*nb))

class ItemItemCF:
    def __init__(self, user_item: Dict[int, Dict[int,float]]):
        # user_item: {user: {item: rating}}
        self.user_item = user_item
        # build item vectors
        self.item_users = {}
        for u,items in user_item.items():
            for it,r in items.items():
                self.item_users.setdefault(it, {})[u]=r
        # build item vectors (aligned)
        self.items = sorted(self.item_users.keys())

    def similar_items(self, item, topk=5):
        if item not in self.item_users: return []
        vec_i = self._vec_for_item(item)
        scores=[]
        for j in self.items:
            if j==item: continue
            vec_j = self._vec_for_item(j)
            scores.append((cosine_sim(vec_i, vec_j), j))
        scores.sort(reverse=True)
        return scores[:topk]

    def _vec_for_item(self, item):
        users = sorted(self.item_users.get(item, {}).keys())
        vec = np.array([self.item_users[item].get(u,0.0) for u in sorted(self._all_users())], dtype=float)
        return vec

    def _all_users(self):
        users = set()
        for u in self.user_item: users.add(u)
        return sorted(users)

class UserItemCF:
    def __init__(self, user_item: Dict[int, Dict[int,float]]):
        self.user_item = user_item
        self.users = sorted(user_item.keys())
        self.items = sorted({it for items in user_item.values() for it in items.keys()})
        # user vectors
        self.user_vecs = {u: np.array([user_item[u].get(it,0.0) for it in self.items]) for u in self.users}

    def recommend(self, user, topk=10):
        if user not in self.user_vecs: return []
        uvec = self.user_vecs[user]
        scores=[]
        for other in self.users:
            if other==user: continue
            v = self.user_vecs[other]
            sim = cosine_sim(uvec, v)
            scores.append((sim, other))
        scores.sort(reverse=True)
        # aggregate items from top neighbors
        recs={}
        for sim,other in scores[:5]:
            for it, r in self.user_item[other].items():
                if it in self.user_item[user]: continue
                recs[it] = recs.get(it,0)+sim*r
        return sorted(recs.items(), key=lambda x:x[1], reverse=True)[:topk]

class SVDRecommender:
    def __init__(self, user_item: Dict[int, Dict[int,float]], factors=20):
        self.user_item = user_item
        self.users = sorted(user_item.keys())
        self.items = sorted({it for items in user_item.values() for it in items.keys()})
        self.user_index = {u:i for i,u in enumerate(self.users)}
        self.item_index = {it:i for i,it in enumerate(self.items)}
        R = np.zeros((len(self.users), len(self.items)))
        for u,items in user_item.items():
            for it,r in items.items():
                R[self.user_index[u], self.item_index[it]] = r
        # SVD (with scipy if available or numpy)
        if _has_scipy:
            U,s,Vt = spla.svds(R, k=min(factors, min(R.shape)-1))
            S = np.diag(s)
            self.user_factors = U.dot(S)
            self.item_factors = Vt.T
        else:
            # numpy SVD (dense)
            U,s,Vt = np.linalg.svd(R, full_matrices=False)
            k = min(factors, U.shape[1])
            self.user_factors = U[:, :k]*s[:k]
            self.item_factors = Vt.T[:, :k]

    def predict(self, user, item):
        if user not in self.user_index or item not in self.item_index: return 0.0
        ui = self.user_index[user]; ii = self.item_index[item]
        return float(self.user_factors[ui].dot(self.item_factors[ii]))

    def recommend(self, user, topk=10):
        if user not in self.user_index: return []
        ui = self.user_index[user]
        scores = []
        for it in self.items:
            if it in self.user_item.get(user, {}): continue
            ii = self.item_index[it]
            scores.append((self.user_factors[ui].dot(self.item_factors[ii]), it))
        scores.sort(reverse=True)
        return scores[:topk]

# ---------------------------
# Utilities & Examples
# ---------------------------
def demo_search_and_recommender():
    docs = [
        "Deep learning for NLP and computer vision",
        "Graph neural networks and relational models",
        "NLP transformers and sequence to sequence models",
        "Optimization methods: SGD, Adam, RMSprop",
        "Recommender systems: collaborative and content based"
    ]
    idx = TFIDFIndex(docs)
    print("Query:", idx.query("NLP transformer", topk=3))

    bm = BM25Index(docs)
    print("BM25:", bm.query("optimization methods", topk=3))

    text = "This is a long paragraph about machine learning. It covers models, training, evaluation. Deep learning methods are powerful."
    print("Summary:", summarize_textrank(text, sentences=2))

    # recommender demo
    user_item = {
        1: {101:5, 102:3},
        2: {101:4, 103:5},
        3: {102:4, 104:2}
    }
    svd = SVDRecommender(user_item, factors=2)
    print("SVD recommend for user1:", svd.recommend(1))

if __name__ == "__main__":
    print("ai_datakit demo")
    demo_search_and_recommender()
