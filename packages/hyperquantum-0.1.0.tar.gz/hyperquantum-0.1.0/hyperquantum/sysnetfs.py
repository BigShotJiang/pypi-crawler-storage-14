# sysnetfs.py
# Ultra-advanced hybrid System + Network + Virtual FS engine

import os
import sys
import time
import platform
import shutil
import json
import base64
import socket
import threading
import subprocess
import psutil
import requests
from io import BytesIO
from cryptography.fernet import Fernet


# =====================================================
#          🔥  MASTER CLASS: SysNetFS
# =====================================================

class SysNetFS:
    def __init__(self):
        # Virtual filesystem stored in RAM
        self.vfs = {}                  # { path : bytes or dict }
        self.mounts = {}               # virtual -> real paths
        self.listeners = []            # (path, callback)
        self.encryption_key = Fernet.generate_key()
        self.crypto = Fernet(self.encryption_key)

    # =====================================================
    #                🔹 VIRTUAL FILESYSTEM
    # =====================================================

    def mkdir(self, path):
        self.vfs[path] = {}
        self._notify(path, "mkdir")

    def write(self, path, data):
        if isinstance(data, str):
            data = data.encode()
        self.vfs[path] = data
        self._notify(path, "write")

    def read(self, path):
        file = self.vfs.get(path)
        if isinstance(file, dict):
            raise TypeError("Path is a directory.")
        return file

    def listdir(self, path="/"):
        result = []
        for p in self.vfs:
            if p.startswith(path):
                result.append(p)
        return result

    def delete(self, path):
        if path in self.vfs:
            del self.vfs[path]
        self._notify(path, "delete")

    def rename(self, old, new):
        self.vfs[new] = self.vfs.pop(old)
        self._notify(old, "rename")

    # --- MOUNTING REAL FOLDERS ---

    def mount(self, virtual, real):
        self.mounts[virtual] = real

    def read_host(self, path):
        base = self.mounts.get(os.path.split(path)[0])
        if not base:
            raise FileNotFoundError("Virtual mount not found.")
        full = os.path.join(base, os.path.split(path)[1])
        return open(full, "rb").read()

    # --- ENCRYPTED FILES ---

    def write_secure(self, path, data):
        if isinstance(data, str):
            data = data.encode()
        enc = self.crypto.encrypt(data)
        self.vfs[path] = enc
        self._notify(path, "write_secure")

    def read_secure(self, path):
        data = self.vfs.get(path)
        return self.crypto.decrypt(data)

    # --- PACK / UNPACK VPAK ---

    def pack(self):
        """Return VFS packed as binary."""
        return json.dumps({p: base64.b64encode(self.vfs[p]).decode()
                           if isinstance(self.vfs[p], bytes) else "__dir__"
                           for p in self.vfs}).encode()

    def unpack(self, blob):
        """Load VFS from VPAK binary."""
        data = json.loads(blob.decode())
        for p, val in data.items():
            if val == "__dir__":
                self.vfs[p] = {}
            else:
                self.vfs[p] = base64.b64decode(val)

    # --- EVENT LISTENERS ---

    def add_listener(self, path, callback):
        self.listeners.append((path, callback))

    def _notify(self, path, event):
        for p, cb in self.listeners:
            if path.startswith(p):
                cb(path, event)


    # =====================================================
    #                🔹 SYSTEM UTILITIES
    # =====================================================

    def cpu_info(self):
        return {
            "brand": platform.processor(),
            "cores": psutil.cpu_count(),
            "freq": psutil.cpu_freq()._asdict(),
            "usage": psutil.cpu_percent(interval=1)
        }

    def ram_info(self):
        mem = psutil.virtual_memory()
        return {
            "total": mem.total,
            "available": mem.available,
            "percent": mem.percent
        }

    def disk_info(self):
        disk = psutil.disk_usage("/")
        return {
            "total": disk.total,
            "used": disk.used,
            "percent": disk.percent
        }

    def process_list(self):
        procs = []
        for p in psutil.process_iter(["pid", "name", "cpu_percent"]):
            procs.append(p.info)
        return procs

    def kill(self, pid):
        p = psutil.Process(pid)
        p.terminate()

    def exec_cmd(self, cmd):
        """Runs system command safely and returns output."""
        try:
            out = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT)
            return out.decode()
        except:
            return "ERROR executing command."

    def uptime(self):
        return time.time() - psutil.boot_time()


    # =====================================================
    #                🔹 NETWORK UTILITIES
    # =====================================================

    # --- HTTP client ---

    def request(self, method, url, **kwargs):
        r = requests.request(method, url, **kwargs)
        try:
            return r.json()
        except:
            return r.text

    def get(self, url, **kw):  return self.request("GET", url, **kw)
    def post(self, url, **kw): return self.request("POST", url, **kw)
    def put(self, url, **kw):  return self.request("PUT", url, **kw)
    def delete(self, url, **kw): return self.request("DELETE", url, **kw)

    # --- IP / network info ---

    def local_ip(self):
        return socket.gethostbyname(socket.gethostname())

    def public_ip(self):
        return requests.get("https://api.ipify.org").text

    def geolocate(self):
        return requests.get("https://ipinfo.io/json").json()

    # --- Port scanner ---

    def scan_port(self, host, port, timeout=0.3):
        s = socket.socket()
        s.settimeout(timeout)
        try:
            s.connect((host, port))
            return True
        except:
            return False
        finally:
            s.close()

    def scan_range(self, host, start, end):
        open_ports = []
        for p in range(start, end+1):
            if self.scan_port(host, p):
                open_ports.append(p)
        return open_ports

    # --- LAN device discovery ---

    def discover_lan(self, port=80):
        ip = self.local_ip().split(".")
        base = ".".join(ip[:3])
        devices = []

        def scan(ipaddr):
            if self.scan_port(ipaddr, port):
                devices.append(ipaddr)

        threads = []
        for i in range(1, 255):
            t = threading.Thread(target=scan, args=(f"{base}.{i}",))
            t.start()
            threads.append(t)

        for t in threads:
            t.join()

        return devices

    # --- Speed test ---

    def ping(self, host="8.8.8.8", count=4):
        times = []
        for _ in range(count):
            start = time.time()
            try:
                socket.create_connection((host, 53), 1).close()
            except:
                times.append(None)
            else:
                times.append((time.time() - start) * 1000)
        return times

    def download_speed(self):
        url = "https://speed.hetzner.de/1MB.bin"
        start = time.time()
        data = requests.get(url).content
        mbps = len(data) / (time.time() - start) / (1024*1024)
        return mbps

    def upload_speed(self):
        url = "https://httpbin.org/post"
        blob = os.urandom(1024 * 1024)
        start = time.time()
        requests.post(url, data=blob)
        mbps = len(blob) / (time.time() - start) / (1024*1024)
        return mbps
