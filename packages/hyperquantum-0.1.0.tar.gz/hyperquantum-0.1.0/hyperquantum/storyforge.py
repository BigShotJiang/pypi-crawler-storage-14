"""
storyforge.py
Random story, quest, character, and world generator.
Fun + zero external libraries.
"""

import random


NAMES = [
    "Aelon", "Kryos", "Velar", "Mira", "Serin", "Thorne", "Lyra", 
    "Jax", "Orion", "Kaelis", "Rava", "Drevan"
]

RACES = [
    "Human", "Elf", "Dwarf", "Synthoid", "Voidling", "Celestian"
]

PLANETS = [
    "Zerath-9", "Aurora Prime", "Nyxion", "Teralis", "Solmere",
    "Valtoria", "Cryon Delta"
]

ITEMS = [
    "Quantum Blade", "Soul Prism", "Aether Lens", "Gravity Bomb",
    "Nano Cloak", "Celestial Map"
]

QUESTS = [
    "retrieve the lost artifact",
    "slay the ancient beast",
    "explore the forbidden ruins",
    "decode the collapsing star signal",
    "save the drifting colony",
    "steal the emperor’s crown"
]


def random_character():
    return {
        "name": random.choice(NAMES),
        "race": random.choice(RACES),
        "age": random.randint(18, 400),
        "power": random.choice(["Fire", "Ice", "Quantum", "Shadow", "Light", "Time"])
    }


def random_planet():
    return {
        "name": random.choice(PLANETS),
        "environment": random.choice(["Frozen", "Desert", "Oceanic", "Toxic", "Jungle"]),
        "gravity": round(random.uniform(0.4, 2.5), 2),
        "population_millions": random.randint(1, 900)
    }


def random_item():
    return random.choice(ITEMS)


def random_quest():
    return random.choice(QUESTS)


def make_story():
    hero = random_character()
    planet = random_planet()
    quest = random_quest()
    item = random_item()

    return f"""
On the distant world of {planet['name']}, a {hero['race']} named {hero['name']}
embarks on a quest to {quest}.
Armed only with a {item}, they travel across {planet['environment'].lower()} lands
under {planet['gravity']}g gravity — unaware that destiny waits in the shadows...
"""


if __name__ == "__main__":
    print(make_story())
