"""
chaosart.py
Fun ASCII chaos generators for terminal art.
Only standard libraries used.
"""

import random
import math
import time
import os


# -------------------------
# BASIC GLITCH BLOCKS
# -------------------------
GLITCH_CHARS = ["#", "@", "%", "&", "$", "*", "=", "+", "-", ":", ".", " "]


def glitch(width=80, height=25):
    return "\n".join(
        "".join(random.choice(GLITCH_CHARS) for _ in range(width))
        for _ in range(height)
    )


# -------------------------
# WAVES
# -------------------------
def sine_wave(width=80, height=20, freq=0.15):
    lines = []
    for y in range(height):
        line = ""
        for x in range(width):
            v = math.sin(x * freq + y * 0.2)
            if v > 0.6:
                line += "*"
            elif v > 0.2:
                line += "+"
            elif v > -0.2:
                line += "-"
            else:
                line += "."
        lines.append(line)
    return "\n".join(lines)


# -------------------------
# MANDELBROT-LIKE FRACTAL (ASCII)
# -------------------------
def fractal(width=80, height=40, max_iter=25):
    art = []
    for y in range(height):
        line = []
        for x in range(width):
            cx = (x - width / 2) * 4.0 / width
            cy = (y - height / 2) * 2.0 / height

            zx = zy = 0
            it = 0
            while zx * zx + zy * zy < 4 and it < max_iter:
                xt = zx * zx - zy * zy + cx
                zy = 2 * zx * zy + cy
                zx = xt
                it += 1

            chars = " .:-=+*#%@"
            line.append(chars[int(it / max_iter * (len(chars) - 1))])
        art.append("".join(line))

    return "\n".join(art)


# -------------------------
# PARTICLE DRIFT ANIMATION
# -------------------------
def drift(particles=50, width=80, height=25, frames=80):
    pts = [(random.randint(0, width - 1), random.randint(0, height - 1)) for _ in range(particles)]

    for _ in range(frames):
        os.system("cls" if os.name == "nt" else "clear")
        grid = [[" " for _ in range(width)] for _ in range(height)]

        new_pts = []
        for x, y in pts:
            grid[y][x] = "*"
            x += random.choice([-1, 0, 1])
            y += random.choice([-1, 0, 1])
            x = x % width
            y = y % height
            new_pts.append((x, y))

        pts = new_pts
        print("\n".join("".join(row) for row in grid))
        time.sleep(0.04)
