# audiokit.py
"""
Advanced Audio Engine - audiokit.py
Features:
 - load/save WAV (+MP3 via pydub if available)
 - play (blocking/background) using sounddevice or simplewave
 - record microphone (sounddevice or pyaudio fallback)
 - mixing, fading, normalize, gain, crossfade
 - effects: delay/echo, convolution reverb (scipy), lowpass/highpass (scipy), distortion, compressor
 - synthesis: tone generators, ADSR, simple poly synth
 - speech: TTS via pyttsx3, speech recognition via SpeechRecognition
 - utilities: rms, loudness, spectrogram helpers
 - plugin hooks for custom processors
"""

import os, sys, time, threading, math, wave, io
from typing import Optional, Callable, List, Tuple, Any, Dict

# Optional heavy deps
try:
    import numpy as np
except Exception as e:
    raise RuntimeError("audiokit requires numpy. Install via `pip install numpy`.") from e

_has_scipy = False
try:
    import scipy.signal as spsig
    import scipy.fft as spfft
    _has_scipy = True
except Exception:
    _has_scipy = False

_has_sounddevice = False
try:
    import sounddevice as sd
    _has_sounddevice = True
except Exception:
    _has_sounddevice = False

_has_pydub = False
try:
    from pydub import AudioSegment
    _has_pydub = True
except Exception:
    _has_pydub = False

_has_pyttsx3 = False
try:
    import pyttsx3
    _has_pyttsx3 = True
except Exception:
    _has_pyttsx3 = False

_has_speechrec = False
try:
    import speech_recognition as sr
    _has_speechrec = True
except Exception:
    _has_speechrec = False

# --------------------------
# Basic audio buffer container
# --------------------------
class AudioBuffer:
    """
    Represents audio samples in float32 numpy array (shape: samples, channels)
    rate: sample rate (int)
    channels: number of channels
    """
    def __init__(self, samples: np.ndarray, rate: int = 44100):
        assert isinstance(samples, np.ndarray)
        assert samples.dtype == np.float32
        self.samples = samples
        self.rate = int(rate)
        # normalize shape
        if self.samples.ndim == 1:
            self.samples = self.samples.reshape(-1, 1)
        self.channels = self.samples.shape[1]

    @classmethod
    def silence(cls, seconds: float, rate=44100, channels=1):
        n = int(seconds * rate)
        return cls(np.zeros((n, channels), dtype=np.float32), rate)

    @classmethod
    def from_wav(cls, path: str):
        """
        Load WAV using wave + numpy (no external deps needed).
        """
        with wave.open(path, "rb") as wf:
            sr = wf.getframerate()
            ch = wf.getnchannels()
            sampwidth = wf.getsampwidth()
            frames = wf.readframes(wf.getnframes())
            dtype = None
            if sampwidth == 1:
                dtype = np.uint8
            elif sampwidth == 2:
                dtype = np.int16
            elif sampwidth == 4:
                dtype = np.int32
            else:
                raise RuntimeError("Unsupported sample width: %d" % sampwidth)
            arr = np.frombuffer(frames, dtype=dtype).astype(np.float32)
            # convert ints to [-1,1]
            if sampwidth == 1:
                arr = (arr - 128.0) / 128.0
            elif sampwidth == 2:
                arr = arr / 32768.0
            elif sampwidth == 4:
                arr = arr / 2147483648.0
            arr = arr.reshape(-1, ch)
            return cls(arr.copy(), rate=sr)

    @classmethod
    def from_file(cls, path: str):
        """
        Generic loader: WAV via builtin; MP3/others if pydub is installed.
        """
        ext = os.path.splitext(path)[1].lower()
        if ext == ".wav":
            return cls.from_wav(path)
        if _has_pydub:
            aud = AudioSegment.from_file(path)
            samples = np.array(aud.get_array_of_samples()).astype(np.float32)
            channels = aud.channels
            samples = samples.reshape(-1, channels)
            # normalize pydub sample width
            maxv = float(1 << (8*aud.sample_width - 1))
            samples /= maxv
            return cls(samples, rate=aud.frame_rate)
        raise RuntimeError("Unsupported format and pydub not available. Provide WAV or install pydub.")

    def to_wav_bytes(self, sampwidth=2):
        """
        Return WAV bytes. sampwidth = 2 -> int16.
        """
        out = io.BytesIO()
        nframes = self.samples.shape[0]
        nch = self.channels
        with wave.open(out, "wb") as wf:
            wf.setnchannels(nch)
            wf.setsampwidth(sampwidth)
            wf.setframerate(self.rate)
            # convert float32 -> int
            if sampwidth == 1:
                ints = np.clip((self.samples * 128.0 + 128.0), 0, 255).astype(np.uint8)
            elif sampwidth == 2:
                ints = np.clip(self.samples * 32767.0, -32768, 32767).astype(np.int16)
            elif sampwidth == 4:
                ints = np.clip(self.samples * 2147483647.0, -2147483648, 2147483647).astype(np.int32)
            else:
                raise RuntimeError("Unsupported sampwidth")
            wf.writeframes(ints.tobytes())
        return out.getvalue()

    def save_wav(self, path: str, sampwidth=2):
        data = self.to_wav_bytes(sampwidth=sampwidth)
        with open(path, "wb") as f:
            f.write(data)

    def duration(self):
        return self.samples.shape[0] / float(self.rate)

    def copy(self):
        return AudioBuffer(self.samples.copy(), self.rate)

    # --------------------
    # Basic transforms
    # --------------------
    def normalize(self, target=0.98):
        peak = np.max(np.abs(self.samples))
        if peak > 0:
            self.samples *= (target / peak)
        return self

    def rms(self):
        return float(np.sqrt(np.mean(self.samples**2)))

    def gain_db(self, db):
        factor = 10.0 ** (db / 20.0)
        self.samples *= factor
        return self

    def fade_in(self, seconds):
        n = int(seconds * self.rate)
        n = min(n, self.samples.shape[0])
        win = np.linspace(0.0, 1.0, n)[:, None]
        self.samples[:n] *= win
        return self

    def fade_out(self, seconds):
        n = int(seconds * self.rate)
        n = min(n, self.samples.shape[0])
        win = np.linspace(1.0, 0.0, n)[:, None]
        self.samples[-n:] *= win
        return self

    def apply_gain(self, linear_gain: float):
        self.samples *= linear_gain
        return self

    def resample(self, new_rate: int):
        """
        Simple resample using numpy interpolation (works reasonably).
        If scipy is available, use its resample for better quality.
        """
        if new_rate == self.rate:
            return self
        ratio = float(new_rate) / self.rate
        n_old = self.samples.shape[0]
        n_new = int(np.round(n_old * ratio))
        x_old = np.linspace(0, 1, n_old)
        x_new = np.linspace(0, 1, n_new)
        new = np.zeros((n_new, self.channels), dtype=np.float32)
        for ch in range(self.channels):
            new[:, ch] = np.interp(x_new, x_old, self.samples[:, ch])
        self.samples = new
        self.rate = int(new_rate)
        return self

    # Mixing and concatenation
    def pad_to(self, nframes):
        if nframes <= self.samples.shape[0]:
            return self
        pad = np.zeros((nframes - self.samples.shape[0], self.channels), dtype=np.float32)
        self.samples = np.vstack([self.samples, pad])
        return self

    def mix_with(self, other: "AudioBuffer", offset_seconds=0.0):
        """
        Mix other into this buffer at offset_seconds (this buffer length may be extended).
        Channels: if mismatch, mono/stereo handled by simple broadcasting.
        """
        off = int(round(offset_seconds * self.rate))
        # convert other's rate to this.rate if needed
        other_buf = other.copy()
        if other_buf.rate != self.rate:
            other_buf.resample(self.rate)
        n_needed = off + other_buf.samples.shape[0]
        if n_needed > self.samples.shape[0]:
            self.pad_to(n_needed)
        # channel handling
        if other_buf.channels != self.channels:
            if other_buf.channels == 1:
                other_samples = np.repeat(other_buf.samples, self.channels, axis=1)
            elif self.channels == 1:
                other_samples = other_buf.samples.mean(axis=1, keepdims=True)
            else:
                # simplistic: trim or pad
                minch = min(self.channels, other_buf.channels)
                other_samples = other_buf.samples[:, :minch]
                if minch < self.channels:
                    other_samples = np.pad(other_samples, ((0,0),(0,self.channels-minch)))
        else:
            other_samples = other_buf.samples
        self.samples[off:off+other_samples.shape[0], :other_samples.shape[1]] += other_samples
        return self

    def concat(self, other: "AudioBuffer"):
        other_buf = other.copy()
        if other_buf.rate != self.rate:
            other_buf.resample(self.rate)
        if other_buf.channels != self.channels:
            if other_buf.channels == 1:
                other_buf.samples = np.repeat(other_buf.samples, self.channels, axis=1)
            elif self.channels == 1:
                self.samples = np.repeat(self.samples, other_buf.channels, axis=1)
                self.channels = other_buf.channels
        self.samples = np.vstack([self.samples, other_buf.samples])
        return self

    # --------------------
    # Effects (basic)
    # --------------------
    def delay(self, delay_seconds=0.25, decay=0.5):
        off = int(round(delay_seconds * self.rate))
        out = np.zeros((self.samples.shape[0] + off, self.channels), dtype=np.float32)
        out[:self.samples.shape[0]] += self.samples
        out[off:off+self.samples.shape[0]] += self.samples * decay
        self.samples = out
        return self

    def simple_distortion(self, gain=1.0, threshold=0.6):
        self.samples *= gain
        self.samples = np.clip(self.samples, -threshold, threshold)
        self.samples /= max(threshold, 1e-9)
        return self

    def compressor(self, threshold_db=-18.0, ratio=3.0):
        # very simple hard-knee compressor operating per-sample
        thresh = 10.0**(threshold_db/20.0)
        s = self.samples
        mag = np.abs(s)
        over = mag > thresh
        gain = np.ones_like(s)
        gain[over] = (thresh + (mag[over]-thresh)/ratio) / mag[over]
        self.samples = s * gain
        return self

    def lowpass(self, cutoff_hz: float):
        if not _has_scipy:
            # naive single-pole
            rc = 1.0 / (2*math.pi*cutoff_hz)
            dt = 1.0 / self.rate
            alpha = dt / (rc + dt)
            y = np.zeros_like(self.samples)
            y[0] = self.samples[0]
            for n in range(1, self.samples.shape[0]):
                y[n] = y[n-1] + alpha * (self.samples[n] - y[n-1])
            self.samples = y
            return self
        # scipy butterworth filter
        b, a = spsig.butter(4, cutoff_hz / (0.5 * self.rate), btype='low')
        for ch in range(self.channels):
            self.samples[:, ch] = spsig.filtfilt(b, a, self.samples[:, ch])
        return self

    def highpass(self, cutoff_hz: float):
        if not _has_scipy:
            # approximate with simple diff filter
            kernel = np.array([1, -1])
            for ch in range(self.channels):
                self.samples[:, ch] = np.convolve(self.samples[:, ch], kernel, mode='same')
            return self
        b, a = spsig.butter(4, cutoff_hz / (0.5 * self.rate), btype='high')
        for ch in range(self.channels):
            self.samples[:, ch] = spsig.filtfilt(b, a, self.samples[:, ch])
        return self

    def convolve_reverb(self, ir: "AudioBuffer"):
        if not _has_scipy:
            raise RuntimeError("scipy required for convolution reverb")
        # make mono or channel-preserving by applying per-channel
        if ir.rate != self.rate:
            ir = ir.copy().resample(self.rate)
        L = self.samples.shape[0] + ir.samples.shape[0] - 1
        out = np.zeros((L, self.channels), dtype=np.float32)
        for ch in range(self.channels):
            a = self.samples[:, ch]
            b = ir.samples[:, 0] if ir.channels == 1 else ir.samples[:, min(ch, ir.channels-1)]
            out[:, ch] = spsig.fftconvolve(a, b)[:L]
        self.samples = out
        return self

    def pitch_shift(self, semitones: float):
        """
        Naive pitch shift by resampling: changes duration.
        For time-invariant pitch shift you'd need phase vocoder (not implemented).
        """
        factor = 2.0 ** (semitones / 12.0)
        new_rate = int(round(self.rate * factor))
        self.resample(new_rate)
        return self

    def time_stretch(self, factor: float):
        """
        Very naive time-stretch by resampling (changes pitch).
        """
        if factor <= 0:
            return self
        new_rate = int(round(self.rate / factor))
        self.resample(new_rate)
        return self

# --------------------------
# Playback and recording helpers
# --------------------------
class Player:
    """
    Simple playback wrapper. Uses sounddevice if available; otherwise uses wave+os default.
    """
    def __init__(self):
        self._stream = None
        self._thread = None
        self._stop = False

    def play(self, buffer: AudioBuffer, blocking=True):
        if _has_sounddevice:
            # convert to interleaved float32
            arr = buffer.samples.copy()
            if buffer.channels == 1:
                arr = arr[:, 0]
            def _cb():
                sd.play(arr, buffer.rate)
                sd.wait()
            if blocking:
                _cb()
            else:
                t = threading.Thread(target=_cb, daemon=True)
                t.start()
                return t
        else:
            # fallback: save temporary WAV and use system player (experimental)
            tmp = "_audiokit_play_tmp.wav"
            buffer.save_wav(tmp)
            if sys.platform.startswith("win"):
                import winsound
                winsound.PlaySound(tmp, winsound.SND_FILENAME)
            else:
                # use afplay (mac) or aplay (linux)
                player = "afplay" if sys.platform == "darwin" else "aplay"
                try:
                    os.system(f"{player} {tmp} &")
                except Exception:
                    pass
            return None

    def stop(self):
        if _has_sounddevice:
            sd.stop()

class Recorder:
    """
    Microphone recorder. Uses sounddevice when available.
    """
    def __init__(self, rate=44100, channels=1, device=None):
        self.rate = int(rate)
        self.channels = int(channels)
        self.device = device
        self._recording = False
        self._frames: List[np.ndarray] = []

    def record_seconds(self, seconds: float) -> AudioBuffer:
        if not _has_sounddevice:
            raise RuntimeError("sounddevice required for recording")
        self._frames = []
        rec = sd.rec(int(seconds * self.rate), samplerate=self.rate, channels=self.channels, dtype='float32')
        sd.wait()
        return AudioBuffer(rec, rate=self.rate)

    def record_to_buffer(self, seconds: float, out_path: Optional[str] = None) -> AudioBuffer:
        buf = self.record_seconds(seconds)
        if out_path:
            buf.save_wav(out_path)
        return buf

    def stream_record(self, callback: Callable[[np.ndarray], None], duration: Optional[float] = None):
        """
        Non-blocking stream: callback receives numpy frames
        """
        if not _has_sounddevice:
            raise RuntimeError("sounddevice required for recording")
        stop = False
        def cb(indata, frames, time_info, status):
            callback(indata.copy())
        stream = sd.InputStream(samplerate=self.rate, channels=self.channels, callback=cb, device=self.device)
        stream.start()
        if duration:
            sd.sleep(int(duration * 1000))
            stream.stop()
            stream.close()
        return stream

# --------------------------
# Synthesis helpers
# --------------------------
def generate_sine(freq: float, seconds: float, rate=44100, amp=1.0, phase=0.0):
    t = np.linspace(0, seconds, int(rate*seconds), endpoint=False)
    s = (amp * np.sin(2*np.pi*freq*t + phase)).astype(np.float32)
    return AudioBuffer(s.reshape(-1,1), rate=rate)

def generate_square(freq, seconds, rate=44100, amp=1.0):
    t = np.linspace(0, seconds, int(rate*seconds), endpoint=False)
    s = amp * np.sign(np.sin(2*np.pi*freq*t)).astype(np.float32)
    return AudioBuffer(s.reshape(-1,1), rate=rate)

def generate_saw(freq, seconds, rate=44100, amp=1.0):
    t = np.linspace(0, seconds, int(rate*seconds), endpoint=False)
    s = 2*amp*(t*freq - np.floor(0.5 + t*freq)).astype(np.float32)
    return AudioBuffer(s.reshape(-1,1), rate=rate)

# Envelope
def apply_adsr(buffer: AudioBuffer, attack=0.01, decay=0.05, sustain=0.7, release=0.1):
    n = buffer.samples.shape[0]
    sr = buffer.rate
    a = int(attack*sr); d = int(decay*sr); r = int(release*sr)
    sustain_level = sustain
    env = np.ones((n,1), dtype=np.float32) * sustain_level
    # attack
    if a>0:
        env[:a,0] = np.linspace(0,1,a)
    # decay
    if d>0:
        env[a:a+d,0] = np.linspace(1,sustain_level,d)
    # release
    if r>0 and n > (a+d):
        env[-r:,0] = np.linspace(sustain_level,0,r)
    buffer.samples *= env
    return buffer

# --------------------------
# TTS and speech recognition
# --------------------------
class Speech:
    @staticmethod
    def speak(text: str, engine: str = "pyttsx3", wait=True, rate: Optional[int]=None, voice: Optional[str]=None):
        """
        Speak text using pyttsx3 (offline). For better voices, user can plug in cloud TTS.
        """
        if not _has_pyttsx3:
            raise RuntimeError("pyttsx3 not available. Install via `pip install pyttsx3`.")
        tts = pyttsx3.init()
        if rate is not None:
            tts.setProperty('rate', rate)
        if voice is not None:
            voices = tts.getProperty('voices')
            for v in voices:
                if voice.lower() in v.name.lower() or voice.lower() in v.id.lower():
                    tts.setProperty('voice', v.id); break
        tts.say(text)
        if wait:
            tts.runAndWait()

    @staticmethod
    def recognize_from_file(path: str, engine: str = "google", language: str = "en-US", show_confidence=False):
        """
        Recognize speech from file. Requires speech_recognition installed.
        engine: 'google' uses free Google Web Speech (requires internet), 'sphinx' uses CMU Sphinx (offline if installed)
        """
        if not _has_speechrec:
            raise RuntimeError("speech_recognition required. Install via `pip install SpeechRecognition`.")
        r = sr.Recognizer()
        with sr.AudioFile(path) as source:
            audio = r.record(source)
        if engine == "google":
            return r.recognize_google(audio, language=language)
        elif engine == "sphinx":
            return r.recognize_sphinx(audio)
        else:
            return r.recognize_google(audio, language=language)

    @staticmethod
    def listen_live(callback: Callable[[str], None], timeout: Optional[float]=None, phrase_time_limit: Optional[float]=None):
        """
        Continuously listen and call callback with transcribed text.
        Requires microphone + speech_recognition.
        """
        if not _has_speechrec:
            raise RuntimeError("speech_recognition required. Install via `pip install SpeechRecognition`.")
        r = sr.Recognizer()
        mic = sr.Microphone()
        stop_flag = {"stop": False}
        def _worker():
            with mic as source:
                r.adjust_for_ambient_noise(source, duration=1.0)
                while not stop_flag["stop"]:
                    try:
                        audio = r.listen(source, timeout=timeout, phrase_time_limit=phrase_time_limit)
                        text = r.recognize_google(audio)
                        callback(text)
                    except sr.WaitTimeoutError:
                        continue
                    except Exception as e:
                        # ignore recognition errors but print
                        print("Speech listen error:", e)
                        continue
        t = threading.Thread(target=_worker, daemon=True)
        t.start()
        return stop_flag

# --------------------------
# Plugin system
# --------------------------
class PluginManager:
    def __init__(self):
        self.processors: List[Callable[[AudioBuffer], AudioBuffer]] = []

    def register(self, proc: Callable[[AudioBuffer], AudioBuffer]):
        self.processors.append(proc)

    def run(self, buffer: AudioBuffer) -> AudioBuffer:
        for p in self.processors:
            buffer = p(buffer)
        return buffer

# --------------------------
# Small CLI / Examples
# --------------------------
if __name__ == "__main__":
    print("audiokit demo")
    print("numpy:", np.__version__)
    print("scipy available:", _has_scipy)
    print("sounddevice available:", _has_sounddevice)
    print("pydub available:", _has_pydub)
    print("pyttsx3 available:", _has_pyttsx3)
    print("speech_recognition available:", _has_speechrec)

    # simple test: synth tone, save, play (if sounddevice available)
    tone = generate_sine(440.0, 2.0, rate=44100, amp=0.4)
    tone = apply_adsr(tone, attack=0.01, decay=0.05, sustain=0.8, release=0.2)
    tone.normalize()
    outp = "audiokit_demo_tone.wav"
    tone.save_wav(outp)
    print("Saved demo tone:", outp)
    p = Player()
    try:
        print("Playing demo tone (non-blocking if sounddevice)...")
        p.play(tone, blocking=True)
    except Exception as e:
        print("Playback error (missing sounddevice?), file created:", e)

    if _has_pyttsx3:
        print("Speaking 'Hello from Audiokit' via pyttsx3...")
        Speech.speak("Hello from Audiokit", wait=True)

    print("Demo complete.")
