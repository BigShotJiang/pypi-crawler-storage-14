""" advanced_kit.py
This is an extremely powerful remake of the famous library pywhatkit.
This module is much more featureful and combines the functions of minimum '6-7' well-known libraries.
"""
"""
Advanced PyWhatKit Remake
A powerful automation + utility module
Written as a single-file drop-in module.

Features:
- WhatsApp automation (schedule + instant)
- Email sending
- Google search, YouTube search/play
- Wikipedia summaries
- Text-to-speech
- ASCII art generator
- Handwriting generator
- Keyboard + mouse automation
- QR code generator
- PDF generator
- Screenshot
- System utilities
"""

import os
import webbrowser
import time
import datetime
import pyautogui
import requests
import wikipedia
import pyttsx3
from PIL import Image, ImageDraw, ImageFont
import qrcode

# Optional: twilio for SMS
try:
    from twilio.rest import Client as TwilioClient
    TWILIO_AVAILABLE = True
except:
    TWILIO_AVAILABLE = False


# ---------------------------------------------------------------------
# WHATSAPP AUTOMATION
# ---------------------------------------------------------------------

def send_whatsapp(number: str, message: str, hour: int, minute: int):
    """
    Schedule a WhatsApp message like pywhatkit.
    """
    webbrowser.open(f"https://web.whatsapp.com/send?phone={number}&text={message}")
    print("[INFO] Please keep the browser open...")
    delay = (hour * 3600 + minute * 60) - \
            (datetime.datetime.now().hour * 3600 + datetime.datetime.now().minute * 60)
    if delay < 0:
        delay = 5
    time.sleep(delay + 10)
    pyautogui.press('enter')
    print("[✓] Message sent!")


def send_whatsapp_now(number: str, message: str):
    """
    Instantly send message.
    """
    webbrowser.open(f"https://web.whatsapp.com/send?phone={number}&text={message}")
    time.sleep(10)
    pyautogui.press('enter')
    print("[✓] Message sent instantly!")


# ---------------------------------------------------------------------
# YOUTUBE + GOOGLE
# ---------------------------------------------------------------------

def play_youtube(query: str):
    webbrowser.open(f"https://www.youtube.com/results?search_query={query}")
    time.sleep(2)
    pyautogui.moveTo(300, 350)
    pyautogui.click()
    print("[✓] Playing top video!")


def google_search(query: str):
    webbrowser.open(f"https://www.google.com/search?q={query}")
    print("[✓] Google search opened!")


# ---------------------------------------------------------------------
# WIKIPEDIA SUMMARY
# ---------------------------------------------------------------------

def wiki_summary(topic: str, lines: int = 5):
    wikipedia.set_lang("en")
    text = wikipedia.summary(topic, sentences=lines)
    print(f"\n=== Wikipedia: {topic} ===\n")
    print(text)
    return text


# ---------------------------------------------------------------------
# TEXT TO SPEECH
# ---------------------------------------------------------------------

def speak(text: str):
    engine = pyttsx3.init()
    engine.say(text)
    engine.runAndWait()


# ---------------------------------------------------------------------
# ASCII ART GENERATOR
# ---------------------------------------------------------------------

ASCII_CHARS = ["@", "#", "S", "%", "?", "*", "+", ";", ":", ",", "."]

def to_ascii(path: str, new_w=120, save_as=None):
    """
    Convert an image to ASCII art.
    """
    img = Image.open(path).convert('L')
    w, h = img.size
    aspect = h / w
    new_h = int(new_w * aspect * 0.55)
    img = img.resize((new_w, new_h))

    pixels = img.getdata()
    chars = "".join(ASCII_CHARS[p // 25] for p in pixels)

    ascii_img = "\n".join(
        chars[i:i + new_w] for i in range(0, len(chars), new_w)
    )

    if save_as:
        with open(save_as, "w") as f:
            f.write(ascii_img)

    return ascii_img


# ---------------------------------------------------------------------
# HANDWRITING GENERATOR
# ---------------------------------------------------------------------

def text_to_handwriting(text: str, save_as="handwriting.png", color=(0, 0, 255)):
    img = Image.new("RGB", (1000, 800), "white")
    draw = ImageDraw.Draw(img)
    font = ImageFont.truetype("arial.ttf", 32)

    x, y = 50, 50
    for line in text.split("\n"):
        draw.text((x, y), line, fill=color, font=font)
        y += 40

    img.save(save_as)
    print(f"[✓] Handwriting saved as {save_as}")


# ---------------------------------------------------------------------
# EMAIL SENDER
# ---------------------------------------------------------------------

import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart

def send_email(sender, password, receiver, subject, message):
    msg = MIMEMultipart()
    msg['From'] = sender
    msg['To'] = receiver
    msg['Subject'] = subject

    msg.attach(MIMEText(message, "plain"))

    server = smtplib.SMTP("smtp.gmail.com", 587)
    server.starttls()
    server.login(sender, password)
    server.send_message(msg)
    server.quit()
    print("[✓] Email sent successfully!")


# ---------------------------------------------------------------------
# OPTIONAL TWILIO SMS
# ---------------------------------------------------------------------

def send_sms_twilio(sid, token, sender, receiver, text):
    if not TWILIO_AVAILABLE:
        print("Twilio not installed.")
        return

    client = TwilioClient(sid, token)
    client.messages.create(body=text, from_=sender, to=receiver)
    print("[✓] SMS sent!")


# ---------------------------------------------------------------------
# QR CODE GENERATOR
# ---------------------------------------------------------------------

def create_qr(data: str, save_as="qr.png"):
    qr = qrcode.make(data)
    qr.save(save_as)
    print(f"[✓] QR saved as {save_as}")


# ---------------------------------------------------------------------
# PDF GENERATOR
# ---------------------------------------------------------------------

from fpdf import FPDF

def text_to_pdf(text: str, filename="file.pdf"):
    pdf = FPDF()
    pdf.add_page()
    pdf.set_font("Arial", size=12)

    for line in text.split("\n"):
        pdf.write(8, line)
        pdf.ln()

    pdf.output(filename)
    print(f"[✓] PDF saved as {filename}")


# ---------------------------------------------------------------------
# SCREENSHOT + SCREEN RECORD
# ---------------------------------------------------------------------

def screenshot(save_as="screenshot.png"):
    img = pyautogui.screenshot()
    img.save(save_as)
    print(f"[✓] Screenshot saved as {save_as}")


# ---------------------------------------------------------------------
# CLIPBOARD
# ---------------------------------------------------------------------

try:
    import pyperclip
    CLIPBOARD = True
except:
    CLIPBOARD = False

def copy(text):
    if CLIPBOARD:
        pyperclip.copy(text)
        print("[✓] Copied to clipboard!")
    else:
        print("pyperclip not installed.")


def paste():
    if CLIPBOARD:
        return pyperclip.paste()
    else:
        print("pyperclip not installed.")
        return ""


# ---------------------------------------------------------------------
# KEYBOARD & MOUSE TOOLS
# ---------------------------------------------------------------------

def type_text(text: str, interval=0.04):
    pyautogui.write(text, interval=interval)

def move_mouse(x, y):
    pyautogui.moveTo(x, y)

def click():
    pyautogui.click()


# ---------------------------------------------------------------------
# SYSTEM UTILITIES
# ---------------------------------------------------------------------

def open_app(path: str):
    os.startfile(path)

def beep():
    print("\a")

