# ============================================
# HyperQuantum_ Package Initializer
# Version: 0.1.0
# Author: Universal Legend
# ============================================

__version__ = "0.1.0"
__author__ = "Universal Legend"
__all__ = [
    "advanced_kit",
    "ai_datakit",
    "aiassistant",
    "animator2d_advanced",
    "audiokit",
    "chaosart",
    "flowkit",
    "funbox",
    "hybrid_engine",
    "mathcalc1",
    "myui",
    "pedagogical_mininumppy",
    "physics2d",
    "rev_ran",
    "scientific",
    "scriptkit",
    "storyforge",
    "sysnetfs",
    "uiextra",
    "webauto"
]

# --- Import modules so they are available at package level ---

from . import advanced_kit
from . import ai_datakit
from . import aiassistant
from . import animator2d_advanced
from . import audiokit
from . import chaosart
from . import flowkit
from . import funbox
from . import hybrid_engine
from . import mathcalc1
from . import myui
from . import pedagogical_mininumppy
from . import physics2d
from . import rev_ran
from . import scientific
from . import scriptkit
from . import storyforge
from . import sysnetfs
from . import uiextra
from . import webauto

# Friendly greeting when imported
print("🔮 HyperQuantum_ v0.1.0 loaded — Welcome to the multiverse toolkit!")
