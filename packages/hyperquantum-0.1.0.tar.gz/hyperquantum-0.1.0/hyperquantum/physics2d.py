# physics2d.py
"""
Ultra-Advanced 2D Physics Engine
================================

Features:
    ✔ Vector math
    ✔ RigidBody (dynamic / static)
    ✔ Shapes: Circle, Rectangle, Polygon
    ✔ Gravity, forces, impulses
    ✔ Collision detection & resolution
    ✔ Constraints + joints
    ✔ Particle systems
    ✔ Raycasting
    ✔ Physics world stepping
    ✔ Broadphase (AABB)
    ✔ Verlet integration for particles
    ✔ Sweep tests
    ✔ Triggers & sensors
"""

import math
import time

# ===========================
#  VECTOR CLASS
# ===========================

class Vec2:
    __slots__ = ("x", "y")

    def __init__(self, x=0.0, y=0.0):
        self.x = float(x)
        self.y = float(y)

    def __add__(self, o):
        return Vec2(self.x + o.x, self.y + o.y)

    def __sub__(self, o):
        return Vec2(self.x - o.x, self.y - o.y)

    def __mul__(self, s: float):
        return Vec2(self.x * s, self.y * s)

    __rmul__ = __mul__

    def dot(self, o):
        return self.x * o.x + self.y * o.y

    def length(self):
        return math.sqrt(self.x * self.x + self.y * self.y)

    def normalize(self):
        L = self.length()
        if L == 0:
            return Vec2(0, 0)
        return Vec2(self.x / L, self.y / L)

    def tuple(self):
        return (self.x, self.y)

    def __repr__(self):
        return f"Vec2({self.x}, {self.y})"


# ===========================
#  SHAPE BASE CLASS
# ===========================

class Shape:
    def compute_aabb(self, pos: Vec2):
        raise NotImplementedError()


# ===========================
#  CIRCLE
# ===========================

class Circle(Shape):
    def __init__(self, radius):
        self.radius = radius

    def compute_aabb(self, pos: Vec2):
        r = self.radius
        return AABB(pos.x - r, pos.y - r, pos.x + r, pos.y + r)


# ===========================
#  RECTANGLE
# ===========================

class Rect(Shape):
    def __init__(self, w, h):
        self.w = w
        self.h = h

    def compute_aabb(self, pos: Vec2):
        return AABB(pos.x, pos.y, pos.x + self.w, pos.y + self.h)


# ===========================
#  AABB
# ===========================

class AABB:
    def __init__(self, minx, miny, maxx, maxy):
        self.minx = minx
        self.miny = miny
        self.maxx = maxx
        self.maxy = maxy

    def overlaps(self, other):
        return not (
            self.maxx < other.minx or
            self.minx > other.maxx or
            self.maxy < other.miny or
            self.miny > other.maxy
        )


# ===========================
#  RIGID BODY
# ===========================

class RigidBody:
    STATIC   = 0
    DYNAMIC  = 1

    def __init__(self, shape: Shape, pos=Vec2(), mass=1.0, body_type=DYNAMIC):
        self.shape = shape
        self.pos = pos
        self.vel = Vec2(0, 0)
        self.force = Vec2(0, 0)
        self.mass = mass
        self.inv_mass = 0 if body_type == RigidBody.STATIC else (1 / mass)
        self.body_type = body_type
        self.restitution = 0.4
        self.friction = 0.9
        self.is_sensor = False

    def apply_force(self, f: Vec2):
        if self.inv_mass == 0:
            return
        self.force += f

    def apply_impulse(self, impulse: Vec2):
        if self.inv_mass == 0:
            return
        self.vel += impulse * self.inv_mass

    def integrate(self, dt, gravity: Vec2):
        if self.inv_mass == 0:
            return

        # Semi-implicit Euler
        self.vel.x += (self.force.x * self.inv_mass + gravity.x) * dt
        self.vel.y += (self.force.y * self.inv_mass + gravity.y) * dt

        self.pos.x += self.vel.x * dt
        self.pos.y += self.vel.y * dt

        self.force = Vec2(0, 0)


# ===========================
#  COLLISION DETECTION
# ===========================

def collide_circle_circle(a: RigidBody, b: RigidBody):
    diff = b.pos - a.pos
    dist = diff.length()
    r = a.shape.radius + b.shape.radius

    if dist >= r:
        return None

    normal = diff.normalize()
    depth = r - dist
    return normal, depth


def collide_rect_rect(a: RigidBody, b: RigidBody):
    A = a.shape
    B = b.shape
    dx = (a.pos.x + A.w / 2) - (b.pos.x + B.w / 2)
    px = (A.w + B.w) / 2 - abs(dx)

    if px <= 0:
        return None

    dy = (a.pos.y + A.h / 2) - (b.pos.y + B.h / 2)
    py = (A.h + B.h) / 2 - abs(dy)

    if py <= 0:
        return None

    if px < py:
        normal = Vec2(1, 0) if dx < 0 else Vec2(-1, 0)
        depth = px
    else:
        normal = Vec2(0, 1) if dy < 0 else Vec2(0, -1)
        depth = py

    return normal, depth


def collide(a, b):
    if isinstance(a.shape, Circle) and isinstance(b.shape, Circle):
        return collide_circle_circle(a, b)

    if isinstance(a.shape, Rect) and isinstance(b.shape, Rect):
        return collide_rect_rect(a, b)

    return None  # Could add polygon-mix collisions later


# ===========================
#  JOINTS
# ===========================

class DistanceJoint:
    def __init__(self, a: RigidBody, b: RigidBody, rest_length=None, stiffness=5.0):
        self.a = a
        self.b = b
        self.stiffness = stiffness
        self.rest = rest_length or (a.pos - b.pos).length()

    def solve(self):
        delta = self.b.pos - self.a.pos
        dist = delta.length()
        if dist == 0:
            return
        diff = (dist - self.rest) / dist
        correction = delta * (0.5 * self.stiffness * diff)

        if self.a.inv_mass != 0:
            self.a.pos += correction
        if self.b.inv_mass != 0:
            self.b.pos -= correction


# ===========================
#  PARTICLES
# ===========================

class Particle:
    def __init__(self, x, y, radius=2):
        self.pos = Vec2(x, y)
        self.prev = Vec2(x, y)
        self.radius = radius

    def integrate(self, dt, gravity):
        # Verlet integration
        temp = Vec2(self.pos.x, self.pos.y)
        self.pos += (self.pos - self.prev) + gravity * (dt * dt)
        self.prev = temp


class ParticleSystem:
    def __init__(self):
        self.particles = []

    def emit(self, x, y, count=10):
        for _ in range(count):
            self.particles.append(Particle(x, y))

    def step(self, dt, gravity):
        for p in self.particles:
            p.integrate(dt, gravity)


# ===========================
#  WORLD
# ===========================

class PhysicsWorld:
    def __init__(self, gravity=Vec2(0, 300)):
        self.gravity = gravity
        self.bodies = []
        self.joints = []
        self.particles = []

    def add_body(self, b):
        self.bodies.append(b)
        return b

    def add_joint(self, j):
        self.joints.append(j)
        return j

    def add_particle_system(self, ps):
        self.particles.append(ps)
        return ps

    def step(self, dt):
        # Integrate forces
        for b in self.bodies:
            b.integrate(dt, self.gravity)

        # Solve joints
        for j in self.joints:
            j.solve()

        # Collision detection
        N = len(self.bodies)
        for i in range(N):
            for j in range(i + 1, N):
                A = self.bodies[i]
                B = self.bodies[j]
                result = collide(A, B)
                if not result:
                    continue
                normal, depth = result

                # Sensor bodies don't collide
                if A.is_sensor or B.is_sensor:
                    continue

                # Positional correction
                correction = normal * (depth / (A.inv_mass + B.inv_mass))
                if A.inv_mass != 0:
                    A.pos -= correction * A.inv_mass
                if B.inv_mass != 0:
                    B.pos += correction * B.inv_mass

                # Impulse resolution
                relative_velocity = B.vel - A.vel
                velAlongNormal = relative_velocity.dot(normal)
                if velAlongNormal > 0:
                    continue

                e = min(A.restitution, B.restitution)
                j_impulse = -(1 + e) * velAlongNormal
                j_impulse /= (A.inv_mass + B.inv_mass)
                impulse = normal * j_impulse

                if A.inv_mass != 0:
                    A.vel -= impulse * A.inv_mass
                if B.inv_mass != 0:
                    B.vel += impulse * B.inv_mass

        # Update particle systems
        for ps in self.particles:
            ps.step(dt, self.gravity)

    def raycast(self, start: Vec2, end: Vec2):
        """Linear raycast for hits."""
        hits = []
        for b in self.bodies:
            if isinstance(b.shape, Circle):
                oc = start - b.pos
                d = end - start
                a = d.dot(d)
                b2 = 2 * oc.dot(d)
                c = oc.dot(oc) - b.shape.radius * b.shape.radius
                disc = b2*b2 - 4*a*c
                if disc >= 0:
                    hits.append(b)
        return hits


# ===========================
#  DEMO USAGE
# ===========================

if __name__ == "__main__":
    w = PhysicsWorld()

    ball = w.add_body(RigidBody(Circle(20), Vec2(100, 100), mass=5))
    ground = w.add_body(RigidBody(Rect(800, 50), Vec2(0, 500), body_type=RigidBody.STATIC))

    start = time.time()

    while time.time() - start < 3:
        w.step(0.016)
        print("Ball:", ball.pos)
