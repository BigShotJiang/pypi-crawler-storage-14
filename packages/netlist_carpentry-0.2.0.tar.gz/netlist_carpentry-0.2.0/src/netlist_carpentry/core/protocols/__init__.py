"""Data structure protocols."""
