"""Miscellaneous stuff and utilities."""
