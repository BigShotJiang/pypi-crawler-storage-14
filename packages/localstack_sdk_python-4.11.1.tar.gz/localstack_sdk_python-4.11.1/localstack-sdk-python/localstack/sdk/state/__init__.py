from localstack.sdk.state.client import StateClient

__all__ = ["StateClient"]
