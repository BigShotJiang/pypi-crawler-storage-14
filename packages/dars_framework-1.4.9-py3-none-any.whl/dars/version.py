__version__ = "1.4.9"
__release_url__ = "https://github.com/ZtaMDev/Dars-Framework/releases/tag/1.4.9"
