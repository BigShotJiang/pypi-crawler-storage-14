# base.py
"""
Common utilities and abstractions shared by probabilistic graphical models.

Currently this module provides:

- ``validate_query_args``: shared argument checker for inference queries
  in both BayesianNetwork and MarkovNetwork.
"""
from __future__ import annotations

from typing import Any, Dict, List, Optional


def validate_query_args(
    model: Any,
    query_vars: List[Any],
    evidence: Optional[Dict[Any, Any]],
    elimination_order: Optional[List[Any]],
) -> Dict[Any, Any]:
    """
    Validate and normalise arguments for an inference query.

    Assumes ``model`` exposes:
        - model.nodes: mapping variable -> Node
        - model.var_domains: mapping variable -> list of values
    """
    if not hasattr(model, "nodes"):
        raise RuntimeError(
            "Model passed to validate_query_args lacks 'nodes' attribute."
        )
    if not hasattr(model, "var_domains"):
        raise RuntimeError(
            "Model passed to validate_query_args lacks 'var_domains' attribute."
        )

    nodes = getattr(model, "nodes")
    var_domains: Dict[Any, List[Any]] = getattr(model, "var_domains")

    # ---- 0) query_vars 非空 ----
    if query_vars is None or len(query_vars) == 0:
        raise ValueError("query_vars cannot be empty.")

    # ---- 1) evidence 归一化并检查类型 ----
    if evidence is None:
        evidence = {}
    elif not isinstance(evidence, dict):
        raise TypeError(
            "Evidence must be a dict mapping variable -> value, "
            f"but received type {type(evidence)}."
        )

    # ---- 2) 所有查询变量必须存在于图节点中 ----
    for var in query_vars:
        if var not in nodes:
            raise ValueError(
                f"Query variable '{var}' does not exist in the model nodes."
            )

    # ---- 3) 所有证据变量必须存在于图节点中 ----
    for ev in evidence.keys():
        if ev not in nodes:
            raise ValueError(
                f"Evidence variable '{ev}' does not exist in the model nodes."
            )

    # ---- 4) 查询变量与证据变量不能重叠 ----
    conflict_vars = set(query_vars) & set(evidence.keys())
    if conflict_vars:
        raise ValueError(
            f"Query variables {list(conflict_vars)} cannot also appear in evidence. "
            "Please remove them from either query or evidence."
        )

    # ---- 5) 证据取值必须在对应变量 domain 中 ----
    for ev, val in evidence.items():
        if ev in var_domains:
            if val not in var_domains[ev]:
                raise ValueError(
                    f"Evidence variable '{ev}' has illegal value '{val}'. "
                    f"Valid domain = {var_domains[ev]}"
                )

    # ---- 6) elimination_order: 变量存在性 + 不与 query/evidence 冲突 ----
    if elimination_order is not None:
        for var in elimination_order:
            if var not in nodes:
                raise ValueError(
                    f"Variable '{var}' in elimination_order "
                    f"does not exist in the model."
                )

        eo_conflict = set(elimination_order) & (set(query_vars) | set(evidence.keys()))
        if eo_conflict:
            raise ValueError(
                "elimination_order cannot contain query or evidence variables; "
                f"conflicting variables: {sorted(eo_conflict)}"
            )

    # ---- 7) 查询变量不能重复 ----
    if len(query_vars) != len(set(query_vars)):
        raise ValueError(
            f"Query variables contain duplicates: {query_vars}. "
            "Query variables must be unique."
        )

    # 统一返回标准化后的 evidence（保证是 dict）
    return evidence
