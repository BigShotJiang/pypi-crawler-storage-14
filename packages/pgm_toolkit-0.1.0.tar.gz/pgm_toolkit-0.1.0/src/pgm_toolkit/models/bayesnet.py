"""
BayesianNetwork implementation using Graph / Factor.
Supports adding nodes, CPDs and wiring an inference engine.
"""
from __future__ import annotations

from typing import Any, Dict, List, Optional

import numpy as np

from pgm_toolkit.core.graph import Factor, Graph, Node
from pgm_toolkit.models.base import validate_query_args


class BayesianNetwork(Graph):
    def __init__(self, name: str = "bayesian_network"):
        super().__init__(name)
        self.factors: List[Factor] = []  # CPDs as factors
        self.var_domains: Dict[Any, List[Any]] = {}
        self.inference_engine = None
        self._cpd_factors: Dict[Any, Factor] = {}  # ensure one CPD per var

    def is_directed(self) -> bool:
        return True

    # ---------- DAG-safe add_edge (检测环) ----------
    def add_edge(self, source: Any, target: Any, edge_type: str = "directed"):
        if edge_type != "directed":
            raise ValueError("BayesianNetwork only supports directed edges.")

        edge = super().add_edge(source, target, edge_type="directed")

        # cycle check: simple DFS from target back to source
        if self._has_cycle():
            # rollback
            self.edges.remove(edge)
            s = self.nodes[source if not isinstance(source, Node) else source.name]
            t = self.nodes[target if not isinstance(target, Node) else target.name]
            s.children.remove(t)
            t.parents.remove(s)
            raise ValueError(
                f"Adding edge {source} -> {target} would create a cycle in the BN."
            )
        return edge

    def _has_cycle(self) -> bool:
        """Detect cycle in directed graph using DFS."""
        visited: Dict[Any, int] = {}  # 0 = unvisited, 1 = visiting, 2 = done

        def dfs(v_name: Any) -> bool:
            state = visited.get(v_name, 0)
            if state == 1:
                return True  # back edge
            if state == 2:
                return False
            visited[v_name] = 1
            v = self.nodes[v_name]
            for child in v.children:
                if dfs(child.name):
                    return True
            visited[v_name] = 2
            return False

        for name in self.nodes:
            if visited.get(name, 0) == 0:
                if dfs(name):
                    return True
        return False

    # ---------- from_dict / to_dict ----------

    @classmethod
    def from_dict(cls, spec: Dict[str, Any]) -> "BayesianNetwork":
        """
        格式示例:

        spec = {
            "name": "my_bn",
            "variables": {
                "A": {
                    "domain": [0, 1],
                    "parents": [],
                    "cpd": [0.7, 0.3]
                },
                "B": {
                    "domain": [0, 1],
                    "parents": ["A"],
                    "cpd": [
                        [0.8, 0.2],   # P(B|A=0)
                        [0.1, 0.9],   # P(B|A=1)
                    ]
                }
            }
        }
        """
        bn = cls(spec.get("name", "bayesian_network_from_dict"))

        variables = spec.get("variables", {})
        if not variables:
            raise ValueError("from_dict: 'variables' cannot be empty.")

        # 1) 添加节点 & domain
        for var, info in variables.items():
            domain = info.get("domain")
            if domain is None:
                raise ValueError(f"from_dict: variable {var} is missing domain")
            bn.add_node(var, domain=list(domain))

        # 2) 添加 CPD（自动加边）
        for var, info in variables.items():
            parents = info.get("parents", [])
            if "cpd" not in info:
                raise ValueError(f"from_dict: variable {var} is missing 'cpd'")
            table = np.array(info["cpd"], dtype=float)
            bn.add_cpd(var, table, parents)

        return bn

    def to_dict(self) -> Dict[str, Any]:
        variables: Dict[str, Any] = {}
        for v_name, node in self.nodes.items():
            parents = [p.name for p in node.parents]
            factor = self._cpd_factors.get(v_name)
            if factor is None:
                raise ValueError(f"No CPD set for variable {v_name}")
            variables[v_name] = {
                "domain": list(self.var_domains[v_name]),
                "parents": parents,
                "cpd": factor.table.tolist(),
            }
        return {"name": self.name, "variables": variables}

    # ---------- add_node / add_cpd ----------

    def add_node(
        self,
        node: Any,
        node_type: str = "random_variable",
        domain: Optional[List[Any]] = None,
        value: Any = None,
    ) -> Node:
        node_obj = super().add_node(node, node_type, domain, value)
        if domain is not None:
            self.var_domains[node_obj.name] = list(domain)
            node_obj.domain = list(domain)
        return node_obj

    def _validate_cpd(self, var: Any, table: np.ndarray, parents: List[Any]) -> None:
        if var not in self.var_domains:
            raise ValueError(f"Domain for variable {var} must be set before adding CPD")
        for p in parents:
            if p not in self.var_domains:
                raise ValueError(f"Domain of parent {p} must be set before adding CPD")

        if var in self._cpd_factors:
            raise ValueError(f"CPD for variable {var} is already defined")

        if var in self.nodes:
            actual_parents = [p.name for p in self.nodes[var].parents]
            if actual_parents:
                if set(actual_parents) != set(parents):
                    raise ValueError(
                        f"Graph parents for {var} ({actual_parents}) do not match "
                        f"CPD parents {parents}."
                    )

        expected_shape = [len(self.var_domains[var])]
        for p in parents:
            expected_shape.append(len(self.var_domains[p]))
        expected_shape = tuple(expected_shape)
        if table.shape != expected_shape:
            raise ValueError(
                f"CPD table for {var} has shape "
                f"{table.shape}, expected {expected_shape}"
            )

        # 每组父配置下，对 var 的概率和为 1
        flat = table.reshape(len(self.var_domains[var]), -1)
        sums = flat.sum(axis=0)
        if not np.allclose(sums, 1.0, atol=1e-6):
            raise ValueError(
                f"CPD for {var} must sum to 1 over its domain for each parent config."
            )

    def add_cpd(
        self, var: Any, table: np.ndarray, parents: Optional[List[Any]] = None
    ) -> Factor:
        if parents is None:
            parents = []
        table = np.asarray(table, dtype=float)

        self._validate_cpd(var, table, parents)

        # 确保图结构父节点
        if var not in self.nodes:
            raise ValueError(f"Variable {var} must be added as node before CPD.")
        for p in parents:
            if p not in self.nodes:
                self.add_node(p, domain=self.var_domains[p])
            if self.nodes[p] not in self.nodes[var].parents:
                self.add_edge(p, var, edge_type="directed")

        scope = [var] + parents
        var_domains = {x: self.var_domains[x] for x in scope}
        factor = Factor(scope, table, var_domains)
        self.factors.append(factor)
        self._cpd_factors[var] = factor
        return factor

    def get_factors(self) -> List[Factor]:
        return list(self.factors)

    # ---------- inference wiring ----------

    def set_inference_engine(self, engine: Any) -> None:
        self.inference_engine = engine

    def query(
        self,
        query_vars: List[Any],
        evidence: Optional[Dict[Any, Any]] = None,
        elimination_order: Optional[List[Any]] = None,
    ):
        if self.inference_engine is None:
            raise RuntimeError(
                "No inference engine set. Call set_inference_engine(engine) first."
            )

        # 使用公共校验函数
        evidence = validate_query_args(self, query_vars, evidence, elimination_order)

        # 交给 inference_engine 处理
        return self.inference_engine.query(
            self, query_vars, evidence, elimination_order
        )
