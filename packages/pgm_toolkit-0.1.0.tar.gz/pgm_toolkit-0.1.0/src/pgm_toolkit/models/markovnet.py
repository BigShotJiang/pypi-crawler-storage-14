"""
MarkovNetwork implementation using Factor as potentials.

This class mirrors the BayesianNetwork interface enough to share
the same inference engines (e.g. VariableElimination, BeliefPropagation).
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional

import numpy as np

from pgm_toolkit.core.graph import Edge, Factor, Graph, Node

from .base import validate_query_args


class MarkovNetwork(Graph):
    def __init__(self, name: str = "markov_network"):
        super().__init__(name)
        self.potentials: List[Factor] = []
        self.var_domains: Dict[Any, List[Any]] = {}
        self.inference_engine = None

    # Markov networks are undirected by definition
    def is_directed(self) -> bool:
        return False

    # Override add_edge so that edges are undirected by default
    def add_edge(
        self,
        source: Any,
        target: Any,
        edge_type: str = "undirected",
    ) -> Edge:
        return super().add_edge(source, target, edge_type=edge_type)

    # ------------------------------------------------------------------
    # from_dict: 通过字典一次性构建整张 MN
    # ------------------------------------------------------------------
    @classmethod
    def from_dict(cls, spec: Dict[str, Any]) -> "MarkovNetwork":
        """
        构造格式示例:

        mn_spec = {
            "name": "my_mn",
            "variables": {
                "A": {"domain": [0, 1]},
                "B": {"domain": [0, 1]},
                "C": {"domain": [0, 1]}
            },
            "potentials": [
                {
                    "scope": ["A", "B"],
                    "table": [
                        [1.0, 2.0],
                        [3.0, 4.0]
                    ]
                },
                {
                    "scope": ["B", "C"],
                    "table": [
                        [2.0, 1.0],
                        [1.0, 3.0]
                    ]
                }
            ]
        }
        """
        mn = cls(spec.get("name", "markov_network_from_dict"))

        variables = spec.get("variables", {})
        if not variables:
            raise ValueError("from_dict: 'variables' 字段不能为空")

        for var, info in variables.items():
            domain = info.get("domain", None)
            if domain is None:
                raise ValueError(f"from_dict: variable {var} is missing domain")
            mn.add_node(var, domain=list(domain))

        for pot in spec.get("potentials", []):
            scope = pot["scope"]
            table = np.array(pot["table"], dtype=float)
            mn.add_potential(scope, table)

        return mn

    def to_dict(self) -> Dict[str, Any]:
        variables = {v: {"domain": list(dom)} for v, dom in self.var_domains.items()}
        pots = [
            {"scope": list(f.scope), "table": f.table.tolist()} for f in self.potentials
        ]
        return {"name": self.name, "variables": variables, "potentials": pots}

    def add_node(
        self,
        node: Any,
        node_type: str = "random_variable",
        domain: Optional[List[Any]] = None,
        value: Any = None,
    ) -> Node:
        node_obj = super().add_node(node, node_type, domain, value)
        if domain is not None:
            self.var_domains[node_obj.name] = list(domain)
            node_obj.domain = list(domain)
        return node_obj

    def _validate_potential(self, scope: List[Any], table: np.ndarray) -> None:
        if not scope:
            raise ValueError("Potential scope must contain at least one variable.")

        for v in scope:
            if v not in self.var_domains:
                raise ValueError(
                    f"Domain of variable {v} must be set before adding a potential."
                )

        expected_shape = tuple(len(self.var_domains[v]) for v in scope)
        if tuple(table.shape) != expected_shape:
            raise ValueError(
                f"Potential table shape {table.shape} does not match "
                f"expected shape {expected_shape} for scope {scope}."
            )

        if np.any(table < 0):
            raise ValueError(f"Potential over scope {scope} contains negative values.")

        for existing in self.potentials:
            if set(existing.scope) == set(scope):
                raise ValueError(f"Potential over scope {scope} already exists.")

    def add_potential(self, scope: List[Any], table: np.ndarray) -> Factor:
        """
        Add a potential factor over the given scope.

        Args:
            scope: list of variable names.
            table: numpy array whose shape matches the product of
                   the corresponding variable domains.
        """

        for v in scope:
            if v not in self.nodes:
                self.add_node(v)

        self._validate_potential(scope, table)

        f = Factor(scope, table, self.var_domains)
        self.potentials.append(f)

        for i in range(len(scope)):
            for j in range(i + 1, len(scope)):
                u_name, v_name = scope[i], scope[j]
                u_node = self.nodes[u_name]
                v_node = self.nodes[v_name]

                if v_node not in u_node.neighbors:
                    self.add_edge(u_name, v_name, edge_type="undirected")

        return f

    def get_factors(self) -> List[Factor]:
        return list(self.potentials)

    def set_inference_engine(self, engine) -> None:
        self.inference_engine = engine

    def query(
        self,
        query_vars: List[Any],
        evidence: Optional[Dict[Any, Any]] = None,
        elimination_order: Optional[List[Any]] = None,
    ):
        """Delegate inference to the configured inference engine."""
        if self.inference_engine is None:
            raise RuntimeError(
                "No inference engine set. Call set_inference_engine(engine) first."
            )

        evidence = validate_query_args(self, query_vars, evidence, elimination_order)

        return self.inference_engine.query(
            self, query_vars, evidence or {}, elimination_order
        )
