# Variational EM
# Classical EM

# - BayesianNetworkEM: 贝叶斯网络的EM算法
# - FactorGraphEM: 因子图的EM算法
# Chapter 11


# 放在对应model中
# - GaussianMixtureEM: 高斯混合模型的EM算法
# - HMM_EM (BaumWelch): 隐马尔可夫模型的EM算法
