# pgm_toolkit/structure/base.py
"""
Abstract interface for structure learning in PGM toolkit.

Defines:
    - StructureLearner: high level entry point
    - BaseStructureLearning: abstract base class for algorithms
"""

from __future__ import annotations
from typing import Any, Dict, Optional, List

from pgm_toolkit.models.bayesnet import BayesianNetwork
from pgm_toolkit.models.markovnet import MarkovNetwork
from pgm_toolkit.learning.structure_learning.score_based import HillClimbingStructure
from pgm_toolkit.learning.structure_learning.constraint_based import PCStructure
from pgm_toolkit.learning.structure_learning.hybrid import MMHCStructure

class BaseStructureLearning:
    """
    Abstract base class for structure-learning algorithms.

    Concrete subclasses must implement:
        learn_bn_structure(data)
        learn_mn_structure(data)
    """

    def learn_bn_structure(self, data, **kwargs) -> BayesianNetwork:
        raise NotImplementedError

    def learn_mn_structure(self, data, **kwargs) -> MarkovNetwork:
        raise NotImplementedError


# ------------------------------
# Top-level user-facing interface
# ------------------------------

class StructureLearner:
    """
    Top-level interface for performing structure learning.

    Parameters
    ----------
    algorithm : str
        Name of algorithm family: "hill_climbing", "pc", "mmhc", ...
    score : str
        For score-based algorithms: "bic", "mdl", "aic", "k2"...

    Examples
    --------
    >>> learner = StructureLearner(algorithm="hill_climbing", score="bic")
    >>> bn = learner.learn(data, model_type="bn")

    >>> learner = StructureLearner(algorithm="pc")
    >>> bn = learner.learn(data)
    """

    def __init__(self, algorithm: str, score: Optional[str] = None, **kwargs):
        self.algorithm = algorithm.lower()
        self.score = score
        self.kwargs = kwargs  # extra hyperparameters

        self._algo_impl = self._create_algorithm()

    # ---------- factory ----------
    def _create_algorithm(self) -> BaseStructureLearning:
        if self.algorithm in ("hill_climbing", "hc", "greedy"):

            return HillClimbingStructure(score=self.score, **self.kwargs)

        if self.algorithm in ("pc", "constraint", "pc_algorithm"):

            return PCStructure(**self.kwargs)

        if self.algorithm in ("mmhc", "hybrid"):

            return MMHCStructure(score=self.score, **self.kwargs)

        raise ValueError(f"Unknown structure-learning algorithm: {self.algorithm}")

    # ---------- main entry ----------
    def learn(
        self,
        data,
        model_type: str = "bn",
        **kwargs,
    ):
        """
        Learn BN or MN structure from data.

        Parameters
        ----------
        data : array-like (n_samples, n_vars)
            Discrete dataset.
        model_type : str, optional
            "bn" for BayesianNetwork, "mn" for MarkovNetwork.

        Returns
        -------
        BayesianNetwork or MarkovNetwork
        """
        model_type = model_type.lower()

        if model_type == "bn":
            return self._algo_impl.learn_bn_structure(data, **kwargs)
        elif model_type == "mn":
            return self._algo_impl.learn_mn_structure(data, **kwargs)
        else:
            raise ValueError(f"Unknown model type '{model_type}'. Use 'bn' or 'mn'.")
