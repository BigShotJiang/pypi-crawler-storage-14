import numpy as np
from scipy.special import gammaln


def count_joint_fortran(data, num_states):
    """
    Count occurrences of joint assignments in Fortran-order (column-major).

    Parameters
    ----------
    data : ndarray, shape (d, N)
        Each row is a discrete variable taking values in {0 ... num_states[i]-1}.
    num_states : list/array of length d
        Number of states for each variable.

    Returns
    -------
    counts : ndarray, shape (prod(num_states),)
        Count for each joint configuration in Fortran (column-major) ordering.
    """
    data = np.asarray(data, dtype=np.int64)
    num_states = np.asarray(num_states, dtype=np.int64)

    d, N = data.shape
    assert d == len(num_states), "Mismatch between data rows and num_states."

    if N == 0:
        return np.zeros(int(np.prod(num_states)), dtype=np.int64)

    # Fortran (column-major) strides:
    # index = x_0 + x_1*n0 + x_2*(n0*n1) + ...
    strides = np.concatenate(([1], np.cumprod(num_states[:-1])))

    # Compute linear index for each sample
    linear_index = np.dot(strides, data)

    # Count occurrences
    total_states = int(np.prod(num_states))
    counts = np.bincount(linear_index, minlength=total_states)

    return counts


def bde_score(
        child_data,
        parent_data,
        child_num_states,
        parent_num_states,
        ess=1.0
):
    # TODO 如果没传入child_num_states和parent_num_states根据数据读取
    """
    Compute the Bayesian Dirichlet (BDe/BDeu) score for a node in a Bayesian network.

    Parameters
    ----------
    child_data : ndarray shape (d_child, N)
        Child variable values (possibly multi-dimensional).
    parent_data : ndarray shape (d_parent, N)
        Parent variable values (possibly multi-dimensional). May be empty.
    child_num_states : list[int]
        Number of states for each child dimension.
    parent_num_states : list[int]
        Number of states for each parent dimension (can be empty).
    ess : float
        Equivalent Sample Size (ESS) used by BDeu.
        Dirichlet prior:
            α_ij = ess / (r * q)
        where:
            r = total child states
            q = total parent configurations

    Returns
    -------
    score : float
        The BDe/BDeu log score for this family (child variable + its parents).
    posterior_alpha : ndarray (r, q)
        Posterior Dirichlet parameters α_ij + N_ij.
    """

    # Step 1: Normalize child and parent state shapes
    child_data = np.asarray(child_data, dtype=np.int64)
    parent_data = np.asarray(parent_data, dtype=np.int64)

    num_child_states = int(np.prod(child_num_states))
    num_parent_configs = int(np.prod(parent_num_states)) if len(parent_num_states) > 0 else 1

    # Step 2: Count joint occurrences N_{ij}
    if parent_data.size > 0:
        joint_data = np.vstack((child_data, parent_data))
        joint_state_sizes = np.hstack((child_num_states, parent_num_states))
        joint_counts = count_joint_fortran(joint_data, joint_state_sizes)
    else:
        joint_counts = count_joint_fortran(child_data, child_num_states)

    # reshape as matrix N_{ij}
    counts_child_given_parents = joint_counts.reshape(
        num_child_states,
        num_parent_configs,
        order="F"
    )

    # Step 3: Construct Dirichlet prior α_ij
    # BDeu: α_ij = ESS / (r*q)

    alpha_ij = ess / (num_child_states * num_parent_configs)
    alpha_j = ess / num_parent_configs  # α_j = Σ_i α_ij

    # prior matrix α_{ij}
    alpha_matrix = np.full((num_child_states, num_parent_configs), alpha_ij, dtype=float)

    # posterior α_{ij} + N_{ij}
    posterior_alpha = alpha_matrix + counts_child_given_parents

    # Step 4: Compute BDe/BDeu score
    # Formula:
    # Σ_j [ log Γ(α_j) - log Γ(α_j + N_j)
    #       + Σ_i ( log Γ(α_ij + N_ij) - log Γ(α_ij) ) ]

    parent_counts = counts_child_given_parents.sum(axis=0)  # N_j

    score = np.sum(
        gammaln(alpha_j) - gammaln(alpha_j + parent_counts)
        + np.sum(gammaln(posterior_alpha), axis=0)
        - np.sum(gammaln(alpha_matrix), axis=0)
    )

    return score, posterior_alpha, counts_child_given_parents
