# pgm_toolkit/structure/hybrid.py
from __future__ import annotations
import numpy as np

from pgm_toolkit.learning.structure_learning.base import BaseStructureLearning
from pgm_toolkit.learning.structure_learning.score_based import HillClimbingStructure
from pgm_toolkit.learning.structure_learning.constraint_based import PCStructure
from pgm_toolkit.models.bayesnet import BayesianNetwork


class MMHCStructure(BaseStructureLearning):
    """
    MMHC = Max-Min Hill-Climbing
    """

    def __init__(self, score="bic", alpha=0.05, **kwargs):
        self.pc = PCStructure(alpha=alpha)
        self.hc = HillClimbingStructure(score=score)

    def learn_bn_structure(self, data, **kwargs) -> BayesianNetwork:
        # 1) PC-stage reduces candidate parents
        bn_pc = self.pc.learn_bn_structure(data)

        # 2) restricted hill-climbing
        bn = self.hc.learn_bn_structure(data)
        # hill-climbing should be restricted by bn_pc skeleton (you will implement)
        return bn

    def learn_mn_structure(self, data, **kwargs):
        raise NotImplementedError("MMHC not defined for Markov networks.")
