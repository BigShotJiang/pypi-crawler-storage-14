# PC # Chapter 9.5.1
# SGS
# pgm_toolkit/structure/constraint_based.py
from __future__ import annotations
import numpy as np

from pgm_toolkit.learning.structure_learning.base import BaseStructureLearning
from pgm_toolkit.models.bayesnet import BayesianNetwork


class PCStructure(BaseStructureLearning):
    """
    Constraint-based PC algorithm for Bayesian networks.
    """

    def __init__(self, alpha: float = 0.05, **kwargs):
        self.alpha = alpha
        self.kwargs = kwargs

    def _independent(self, x, y, S, data) -> bool:
        """
        Conditional independence test I(x; y | S).
        Placeholder, you can implement:
            - G-test
            - Chi-square test
            - Mutual information test
        """
        return False

    def learn_bn_structure(self, data, **kwargs) -> BayesianNetwork:
        n_vars = data.shape[1]
        var_names = [f"X{i}" for i in range(n_vars)]

        bn = BayesianNetwork("bn_pc")
        for name in var_names:
            domain = sorted(set(data[:, int(name[1:])]))
            bn.add_node(name, domain=domain)

        # PC skeleton construction
        graph = {v: set(var_names) - {v} for v in var_names}

        # remove edges based on conditional independence
        # orientation phase afterwards

        return bn

    def learn_mn_structure(self, data, **kwargs):
        raise NotImplementedError("PC algorithm is only defined for Bayesian Networks.")
