# - ConstraintBased: 基于约束的方法
# - ScoreBased: 基于评分的方法
# - HybridMethods: 混合方法
from .scoring import bde_score

__all__ = ["bde_score"]