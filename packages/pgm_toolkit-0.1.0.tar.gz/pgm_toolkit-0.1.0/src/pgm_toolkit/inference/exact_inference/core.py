from typing import Any, Dict, List, Optional


class InferenceEngine:
    def query(
        self,
        model,
        query_vars: List[Any],
        evidence: Dict[Any, Any],
        elimination_order: Optional[List[Any]] = None,
    ):
        raise NotImplementedError
