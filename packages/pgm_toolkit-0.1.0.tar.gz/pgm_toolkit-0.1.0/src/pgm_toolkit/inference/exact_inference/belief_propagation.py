# # Sum-Product BP 求边际分布 # Chapter 5.12
# # Max-Product BP 求最大后验 # Chapter 5.21
# # Loopy Belief Propagation 近似推断 # Chapter 28.7 Loopy Belief Propagation

"""
Sum-Product Belief Propagation (BP) inference engine.

This implementation works on the factor graph induced by a model
(BayesianNetwork or MarkovNetwork) that exposes:

- var_domains: Dict[var, List[values]]
- get_factors(): List[Factor]

For tree-structured factor graphs BP is exact.
For graphs with cycles we run loopy BP and treat the result as an approximation.

NOTE: This engine is designed to return **single-variable marginals** only.
For multi-variable joint / marginal queries, use Variable Elimination instead.
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional, Tuple

import numpy as np

from pgm_toolkit.core.graph import Factor
from pgm_toolkit.inference.exact_inference.core import InferenceEngine


class BeliefPropagation(InferenceEngine):
    def __init__(self, max_iter: int = 100, tol: float = 1e-6) -> None:
        """
        Args:
            max_iter: Maximum number of iterations for loopy BP.
            tol: Convergence tolerance on messages (max L_inf difference).
        """
        self.max_iter = max_iter
        self.tol = tol

    # ------------------------------------------------------------------
    # Factor graph construction / structure helpers
    # ------------------------------------------------------------------
    def _build_factor_graph(
        self, model
    ) -> Tuple[Dict[str, Dict], Dict[str, Dict], Dict[str, set]]:
        """Build a bipartite factor graph from the model's factors.

        Returns:
            variable_nodes: {var_name: {"domain": [...], "factors": set([...])}}
            factor_nodes: {"f_i": {"factor": Factor, "variables": set([...])}}
            edges: {node_name: set(neighbor_node_names)}
        """
        variable_nodes: Dict[str, Dict] = {}
        factor_nodes: Dict[str, Dict] = {}
        edges: Dict[str, set] = {}

        # Create variable nodes from all variables in factors
        for factor in model.get_factors():
            for var in factor.scope:
                if var not in variable_nodes:
                    # Get domain from model (preferred) or from factor.var_domains
                    if hasattr(model, "var_domains") and var in model.var_domains:
                        domain = list(model.var_domains[var])
                    else:
                        domain = list(factor.var_domains[var])
                    variable_nodes[var] = {
                        "type": "variable",
                        "domain": domain,
                        "factors": set(),
                    }

        # Create factor nodes and undirected edges
        for idx, factor in enumerate(model.get_factors()):
            factor_id = f"f_{idx}"
            factor_nodes[factor_id] = {
                "type": "factor",
                "factor": factor,
                "variables": set(factor.scope),
            }

            # Connect factor to its variables
            for var in factor.scope:
                # variable -> factor
                edges.setdefault(var, set()).add(factor_id)
                # factor -> variable
                edges.setdefault(factor_id, set()).add(var)
                # Track connections on variable side
                variable_nodes[var]["factors"].add(factor_id)

        return variable_nodes, factor_nodes, edges

    def _is_tree(self, edges: Dict[str, set]) -> bool:
        """Check if the (undirected) factor graph is a single tree."""
        if not edges:
            return True

        visited = set()
        # Take an arbitrary node as root for DFS
        start = next(iter(edges.keys()))
        stack = [(start, None)]

        while stack:
            node, parent = stack.pop()
            if node in visited:
                # Found a back-edge -> cycle
                return False
            visited.add(node)
            for neigh in edges[node]:
                if neigh != parent:
                    stack.append((neigh, node))

        # Check connectedness: all nodes must have been visited
        return len(visited) == len(edges)

    # ------------------------------------------------------------------
    # Message computation helpers
    # ------------------------------------------------------------------
    def _compute_message_var_to_factor(
        self,
        var: str,
        factor: str,
        messages: Dict[Tuple[str, str], Factor],
        edges: Dict[str, set],
        variable_nodes: Dict[str, Dict],
        factor_nodes: Dict[str, Dict],
    ) -> Factor:
        """Compute message m_{var -> factor}(var).

        Message is the product of all incoming messages from *other* factors
        to this variable.
        """
        other_factors = [f for f in edges[var] if f != factor]

        if not other_factors:
            # No other factors - send uniform message over var
            domain = variable_nodes[var]["domain"]
            table = np.ones(len(domain), dtype=float)
            return Factor([var], table, {var: domain}).normalize()

        message_factors: List[Factor] = []
        for other_factor in other_factors:
            msg_key = (other_factor, var)
            if msg_key in messages:
                message_factors.append(messages[msg_key])

        if not message_factors:
            # Fall back to uniform if we somehow have no incoming messages
            domain = variable_nodes[var]["domain"]
            table = np.ones(len(domain), dtype=float)
            return Factor([var], table, {var: domain}).normalize()

        result = Factor.multiply(message_factors)
        return result.normalize()

    def _compute_message_factor_to_var(
        self,
        factor: str,
        var: str,
        messages: Dict[Tuple[str, str], Factor],
        edges: Dict[str, set],
        variable_nodes: Dict[str, Dict],
        factor_nodes: Dict[str, Dict],
    ) -> Factor:
        """Compute message m_{factor -> var}(var)."""
        factor_obj: Factor = factor_nodes[factor]["factor"]
        other_vars = [v for v in factor_obj.scope if v != var]

        # If factor only depends on this variable, just copy it
        if not other_vars:
            return factor_obj.copy().normalize()

        # Multiply factor with incoming messages from all other variables
        message_factors: List[Factor] = [factor_obj]
        for other_var in other_vars:
            msg_key = (other_var, factor)
            if msg_key in messages:
                message_factors.append(messages[msg_key])

        result = Factor.multiply(message_factors)

        # Sum out all other variables to obtain a factor over 'var' only
        for other_var in other_vars:
            if other_var in result.scope:
                result = result.sum_out(other_var)

        return result.normalize()

    # ------------------------------------------------------------------
    # Tree-structured BP
    # ------------------------------------------------------------------
    def _belief_propagation_tree(
        self,
        model,
        query_vars: List[Any],
        evidence: Dict[Any, Any],
    ) -> Dict[Any, Factor]:
        """Run exact BP on tree-structured factor graphs.

        Returns:
            beliefs: mapping var -> Factor([var], ...)
        """
        # Step 0: reduce factors based on evidence
        reduced_factors = [f.reduce(evidence) for f in model.get_factors()]

        if not reduced_factors:
            return {}

        # Temporary model with reduced factors
        class TempModel:
            def __init__(self, factors):
                self._factors = factors

            def get_factors(self):
                return self._factors

        temp_model = TempModel(reduced_factors)
        variable_nodes, factor_nodes, edges = self._build_factor_graph(temp_model)

        if not variable_nodes:
            return {}

        # Initialize messages
        messages: Dict[Tuple[str, str], Factor] = {}

        # First pass: upward messages (post-order DFS from an arbitrary root)
        def dfs_up(node: str, parent: Optional[str] = None) -> None:
            for neigh in edges[node]:
                if neigh == parent:
                    continue
                dfs_up(neigh, node)

            if parent is not None:
                if node.startswith("f_"):
                    msg = self._compute_message_factor_to_var(
                        node, parent, messages, edges, variable_nodes, factor_nodes
                    )
                else:
                    msg = self._compute_message_var_to_factor(
                        node, parent, messages, edges, variable_nodes, factor_nodes
                    )
                messages[(node, parent)] = msg

        # Root can be any variable node
        root = next(iter(variable_nodes.keys()))
        dfs_up(root)

        # Second pass: downward messages (root -> leaves)
        def dfs_down(node: str, parent: Optional[str] = None) -> None:
            for neigh in edges[node]:
                if neigh == parent:
                    continue
                if node.startswith("f_"):
                    msg = self._compute_message_factor_to_var(
                        node, neigh, messages, edges, variable_nodes, factor_nodes
                    )
                else:
                    msg = self._compute_message_var_to_factor(
                        node, neigh, messages, edges, variable_nodes, factor_nodes
                    )
                messages[(node, neigh)] = msg
                dfs_down(neigh, node)

        dfs_down(root)

        # Compute final beliefs: product of all factor -> var messages
        beliefs: Dict[Any, Factor] = {}
        for var in variable_nodes.keys():
            if var in evidence:
                continue

            incoming: List[Factor] = []
            for factor_name in edges.get(var, []):
                msg_key = (factor_name, var)
                if msg_key in messages:
                    incoming.append(messages[msg_key])

            if not incoming:
                # No factors: use uniform prior over domain
                domain = variable_nodes[var]["domain"]
                table = np.ones(len(domain), dtype=float)
                beliefs[var] = Factor([var], table, {var: domain}).normalize()
            else:
                beliefs[var] = Factor.multiply(incoming).normalize()

        return beliefs

    # ------------------------------------------------------------------
    # Loopy BP
    # ------------------------------------------------------------------
    def _belief_propagation_loopy(
        self,
        model,
        query_vars: List[Any],
        evidence: Dict[Any, Any],
    ) -> Dict[Any, Factor]:
        """Run loopy BP on graphs with cycles.

        Returns approximate single-variable marginals.
        """
        reduced_factors = [f.reduce(evidence) for f in model.get_factors()]

        if not reduced_factors:
            return {}

        class TempModel:
            def __init__(self, factors):
                self._factors = factors

            def get_factors(self):
                return self._factors

        temp_model = TempModel(reduced_factors)
        variable_nodes, factor_nodes, edges = self._build_factor_graph(temp_model)

        if not variable_nodes:
            return {}

        # Initialize all messages to uniform
        messages: Dict[Tuple[str, str], Factor] = {}
        for node in edges:
            for neigh in edges[node]:
                if node.startswith("f_") and neigh in variable_nodes:
                    # factor -> variable
                    domain = variable_nodes[neigh]["domain"]
                    table = np.ones(len(domain), dtype=float)
                    messages[(node, neigh)] = Factor(
                        [neigh], table, {neigh: domain}
                    ).normalize()
                elif (not node.startswith("f_")) and neigh in factor_nodes:
                    # variable -> factor
                    domain = variable_nodes[node]["domain"]
                    table = np.ones(len(domain), dtype=float)
                    messages[(node, neigh)] = Factor(
                        [node], table, {node: domain}
                    ).normalize()

        # Iterate until convergence
        for _ in range(self.max_iter):
            max_diff = 0.0
            new_messages: Dict[Tuple[str, str], Factor] = dict(messages)

            for node in edges:
                for neigh in edges[node]:
                    if node.startswith("f_") and neigh in variable_nodes:
                        msg = self._compute_message_factor_to_var(
                            node, neigh, messages, edges, variable_nodes, factor_nodes
                        )
                    elif (not node.startswith("f_")) and neigh in factor_nodes:
                        msg = self._compute_message_var_to_factor(
                            node, neigh, messages, edges, variable_nodes, factor_nodes
                        )
                    else:
                        continue

                    key = (node, neigh)
                    old = messages.get(key)
                    if old is not None:
                        # Compare tables (they should have same scope)
                        diff = np.max(np.abs(msg.table - old.table))
                        if diff > max_diff:
                            max_diff = diff
                    new_messages[key] = msg

            messages = new_messages

            if max_diff < self.tol:
                break

        # Compute approximate beliefs
        beliefs: Dict[Any, Factor] = {}
        for var in variable_nodes.keys():
            if var in evidence:
                continue

            incoming: List[Factor] = []
            for factor_name in edges.get(var, []):
                msg_key = (factor_name, var)
                if msg_key in messages:
                    incoming.append(messages[msg_key])

            if not incoming:
                domain = variable_nodes[var]["domain"]
                table = np.ones(len(domain), dtype=float)
                beliefs[var] = Factor([var], table, {var: domain}).normalize()
            else:
                beliefs[var] = Factor.multiply(incoming).normalize()

        return beliefs

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------
    def query(
        self,
        model,
        query_vars: List[Any],
        evidence: Dict[Any, Any],
        elimination_order: Optional[List[Any]] = None,
    ) -> Factor:
        """Run belief propagation query.

        This engine is intended for single-variable marginals only.
        For multi-variable queries, use Variable Elimination instead.

        Args:
            model: BayesianNetwork / MarkovNetwork with get_factors(), var_domains.
            query_vars: list with a single variable name.
            evidence: mapping var -> value.
            elimination_order: ignored (present for API compatibility).
        """
        if not query_vars:
            raise ValueError(
                "BeliefPropagation.query requires at least one query variable."
            )

        if len(query_vars) > 1:
            raise ValueError(
                "BeliefPropagation currently supports only single-variable marginals.\n"
                "Use VariableElimination for multi-variable joint / marginal queries."
            )

        query_var = query_vars[0]

        # Handle evidence on the query variable directly
        if query_var in evidence:
            domain = model.var_domains[query_var]
            idx = domain.index(evidence[query_var])
            table = np.zeros(len(domain), dtype=float)
            table[idx] = 1.0
            return Factor([query_var], table, {query_var: domain})

        # If model has no factors, return uniform over domain
        if not hasattr(model, "get_factors") or not model.get_factors():
            domain = model.var_domains[query_var]
            table = np.ones(len(domain), dtype=float)
            return Factor([query_var], table, {query_var: domain}).normalize()

        # Decide whether to run tree BP or loopy BP
        variable_nodes, factor_nodes, edges = self._build_factor_graph(model)
        is_tree = self._is_tree(edges)

        if is_tree:
            beliefs = self._belief_propagation_tree(model, query_vars, evidence)
        else:
            beliefs = self._belief_propagation_loopy(model, query_vars, evidence)

        if query_var in beliefs:
            return beliefs[query_var].normalize()

        # Fallback: variable not in beliefs (e.g., isolated variable)
        if hasattr(model, "var_domains") and query_var in model.var_domains:
            domain = model.var_domains[query_var]
            table = np.ones(len(domain), dtype=float)
            return Factor([query_var], table, {query_var: domain}).normalize()

        raise ValueError(f"Query variable {query_var} not found in model.")


# Example usage and test
if __name__ == "__main__":
    # Test with simple Bayesian Network
    from pgm_toolkit.models.bayesnet import BayesianNetwork

    bn = BayesianNetwork()
    bn.add_node("A", domain=[0, 1])
    bn.add_node("B", domain=[0, 1])
    bn.add_node("C", domain=[0, 1])
    # bn.add_node("D", domain=[0, 1])

    # P(A)
    bn.add_cpd("A", np.array([0.7, 0.3]), parents=[])
    bn.add_cpd("B", np.array([0.2, 0.8]), parents=[])

    cpd = [[[0.9, 0.7], [0.2, 0.5]], [[0.1, 0.3], [0.8, 0.5]]]
    bn.add_cpd("C", np.array(cpd), parents=["A", "B"])
    # bn.add_cpd("D", np.array([[0.9,0.2],[0.1,0.8]]), parents=["C"])

    # Test belief propagation
    engine = BeliefPropagation()
    bn.set_inference_engine(engine)

    print("Tree-structured BN:")
    result = bn.query(["C"], evidence={"A": 0})
    print("P(C|A=0):", result.table)

    # from pgm_toolkit.models.markovnet import MarkovNetwork
    #
    # mn = MarkovNetwork()
    # mn.add_node("A", domain=[0, 1])
    # mn.add_node("B", domain=[0, 1])
    #
    # mn.add_potential(["A", "B"], np.array([[1, 2], [3, 8]]))
    #
    # engine = BeliefPropagation()
    # mn.set_inference_engine(engine)
    #
    # res = mn.query(["B"], evidence={})
    # print("P(B):", res.table)
