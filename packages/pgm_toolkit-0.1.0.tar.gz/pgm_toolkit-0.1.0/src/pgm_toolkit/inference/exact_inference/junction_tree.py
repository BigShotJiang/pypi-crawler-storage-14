# junction_tree.py
"""
Junction Tree (Clique Tree) exact inference.

This inference engine can work with both BayesianNetwork and MarkovNetwork
as long as the model exposes:

- model.nodes: Dict[var_name, Node]   (Node has .parents, .children, .neighbors)
- model.var_domains: Dict[var_name, List[values]]
- model.get_factors(): List[Factor]
- model.is_directed(): bool  (True for BayesianNetwork, False for MarkovNetwork)

For Bayesian networks we first build the *moral graph* and then triangulate it
to construct a junction tree.
For Markov networks we use the undirected graph structure directly.

The engine supports **multi-variable marginal queries** P(Q | evidence),
where Q is any subset of variables that is contained in at least one clique
of the junction tree. For more general queries one can fall back to
VariableElimination.
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional, Set, Tuple

import numpy as np

from pgm_toolkit.core.graph import Factor, Graph
from pgm_toolkit.inference.exact_inference.core import InferenceEngine


class JunctionTree(InferenceEngine):
    def __init__(self) -> None:
        super().__init__()

    # ------------------------------------------------------------------
    # Graph preprocessing: moralization / undirected adjacency
    # ------------------------------------------------------------------
    def _build_undirected_adj(self, model: Graph) -> Dict[Any, Set[Any]]:
        """
        Build an undirected adjacency list over variables.

        - For MarkovNetwork (is_directed() == False), we use node.neighbors.
        - For BayesianNetwork (is_directed() == True), we first moralize:
            * connect every parent-child as undirected edge
            * connect all pairs of parents of each child (marriage)
        """
        adj: Dict[Any, Set[Any]] = {name: set() for name in model.nodes.keys()}

        if not model.is_directed():
            # Markov network: neighbors already define an undirected graph
            for name, node in model.nodes.items():
                for neigh in node.neighbors:
                    adj[name].add(neigh.name)
                    adj[neigh.name].add(name)
        else:
            # Bayesian network: moralize
            for child_name, child_node in model.nodes.items():
                # connect parents with child (as undirected)
                for parent in child_node.parents:
                    p_name = parent.name
                    adj[child_name].add(p_name)
                    adj[p_name].add(child_name)

                # connect all pairs of parents (marriage)
                parents = list(child_node.parents)
                for i in range(len(parents)):
                    for j in range(i + 1, len(parents)):
                        u = parents[i].name
                        v = parents[j].name
                        adj[u].add(v)
                        adj[v].add(u)

        return adj

    # ------------------------------------------------------------------
    # Triangulation & clique construction
    # ------------------------------------------------------------------
    def _triangulate_and_get_cliques(self, adj: Dict[Any, Set[Any]]) -> List[Set[Any]]:
        """
        Very simple triangulation using a min-degree elimination heuristic.

        Returns a list of (not-yet-filtered) cliques, then filters out
        non-maximal ones to obtain the set of maximal cliques.
        """
        # Work on a copy
        work_adj: Dict[Any, Set[Any]] = {v: set(nbs) for v, nbs in adj.items()}
        cliques: List[Set[Any]] = []

        while work_adj:
            # choose node with smallest degree
            v = min(work_adj.keys(), key=lambda x: len(work_adj[x]))
            neighbors = list(work_adj[v])
            clique = set(neighbors)
            clique.add(v)
            cliques.append(clique)

            # add fill-in edges among neighbors (make them a clique)
            for i in range(len(neighbors)):
                for j in range(i + 1, len(neighbors)):
                    u = neighbors[i]
                    w = neighbors[j]
                    work_adj[u].add(w)
                    work_adj[w].add(u)

            # remove v from graph
            for u in neighbors:
                work_adj[u].discard(v)
            del work_adj[v]

        # keep only maximal cliques
        maximal_cliques: List[Set[Any]] = []
        for i, C in enumerate(cliques):
            if not any(C < D for j, D in enumerate(cliques) if i != j):
                maximal_cliques.append(C)

        return maximal_cliques

    # ------------------------------------------------------------------
    # Build junction tree (clique tree)
    # ------------------------------------------------------------------
    def _build_junction_tree(
        self, cliques: List[Set[Any]]
    ) -> Tuple[Dict[int, Set[int]], Dict[Tuple[int, int], Set[Any]]]:
        """
        Build a (maximum-weight) junction tree over the given cliques.

        Returns:
            jt_adj: adjacency list over clique indices
            seps:   mapping (i,j) with i<j -> separator variable set C_i ∩ C_j
        """
        n = len(cliques)
        if n == 0:
            return {}, {}

        # Build complete graph over cliques with edge weights = |intersection|
        edges: List[Tuple[int, int, int, Set[Any]]] = []  # (weight, i, j, sep)
        for i in range(n):
            for j in range(i + 1, n):
                sep = cliques[i] & cliques[j]
                if sep:
                    edges.append((len(sep), i, j, sep))

        # Kruskal's algorithm for maximum spanning tree
        edges.sort(reverse=True)  # largest separators first

        parent = list(range(n))

        def find(x: int) -> int:
            while parent[x] != x:
                parent[x] = parent[parent[x]]
                x = parent[x]
            return x

        jt_adj: Dict[int, Set[int]] = {i: set() for i in range(n)}
        seps: Dict[Tuple[int, int], Set[Any]] = {}

        for w, i, j, sep in edges:
            ri, rj = find(i), find(j)
            if ri == rj:
                continue
            parent[ri] = rj
            jt_adj[i].add(j)
            jt_adj[j].add(i)
            key = (i, j) if i < j else (j, i)
            seps[key] = sep

        # There may be isolated cliques (with no edges) if the graph is disconnected.
        # jt_adj already has them with empty neighbor sets.
        return jt_adj, seps

    # ------------------------------------------------------------------
    # Clique potentials & message passing
    # ------------------------------------------------------------------
    def _initialize_clique_potentials(
        self,
        model: Graph,
        cliques: List[Set[Any]],
        evidence: Dict[Any, Any],
    ) -> List[Factor]:
        """
        Create initial clique potentials by assigning model factors to cliques
        whose scopes contain the factor's scope, and multiplying them.

        Evidence is incorporated by reducing factors before assignment.
        """
        # Reduce all factors by evidence first
        reduced_factors = [f.reduce(evidence) for f in model.get_factors()]

        # Prepare one empty (uniform) potential for each clique
        clique_potentials: List[Factor] = []
        for C in cliques:
            scope = sorted(C)
            if not scope:
                # degenerate case
                table = np.array(1.0, dtype=float)
                clique_potentials.append(Factor([], table, model.var_domains))
            else:
                shape = tuple(len(model.var_domains[v]) for v in scope)
                table = np.ones(shape, dtype=float)
                clique_potentials.append(Factor(scope, table, model.var_domains))

        # Assign factors to cliques
        for f in reduced_factors:
            if not f.scope:
                # constant factor, multiply into all cliques (or one arbitrary clique)
                # here we just multiply into the first clique if exists
                if clique_potentials:
                    clique_potentials[0] = Factor.multiply([clique_potentials[0], f])
                continue

            f_scope_set = set(f.scope)
            assigned = False
            for idx, C in enumerate(cliques):
                if f_scope_set.issubset(C):
                    clique_potentials[idx] = Factor.multiply(
                        [clique_potentials[idx], f]
                    )
                    assigned = True
                    break
            if not assigned:
                raise ValueError(
                    f"Factor with scope {f.scope} not contained in any clique. "
                    "Check moralization / triangulation correctness."
                )

        # Optional: normalize clique potentials
        # (not required; they are unnormalized potentials)
        return clique_potentials

    def _calibrate_junction_tree(
        self,
        cliques: List[Set[Any]],
        jt_adj: Dict[int, Set[int]],
        seps: Dict[Tuple[int, int], Set[Any]],
        clique_potentials: List[Factor],
    ) -> List[Factor]:
        """
        Run sum-product message passing (collect-distribute) on the junction tree.

        Returns:
            clique_beliefs: calibrated marginals for each clique.
        """
        n = len(cliques)
        if n == 0:
            return []

        # Messages: (i,j) -> Factor over separator S_ij
        messages: Dict[Tuple[int, int], Factor] = {}

        # Helper: compute separator set for (i,j)
        def separator(i: int, j: int) -> Set[Any]:
            key = (i, j) if i < j else (j, i)
            return seps.get(key, set())

        # Send message from i -> j
        def send_message(i: int, j: int) -> None:
            S = separator(i, j)
            if not S:
                # no separator vars => no meaningful message; skip
                return

            # Combine clique potential with all incoming messages except from j
            factors = [clique_potentials[i]]
            for k in jt_adj[i]:
                if k == j:
                    continue
                key = (k, i)
                if key in messages:
                    factors.append(messages[key])

            combined = Factor.multiply(factors)

            # Sum out variables not in separator S
            for v in list(combined.scope):
                if v not in S:
                    combined = combined.sum_out(v)

            messages[(i, j)] = combined.normalize()

        visited: Set[int] = set()

        # Collect (upward) and distribute (downward) on each connected component
        def collect(root: int, parent: Optional[int]) -> None:
            for neigh in jt_adj[root]:
                if neigh == parent:
                    continue
                collect(neigh, root)
                send_message(neigh, root)

        def distribute(root: int, parent: Optional[int]) -> None:
            for neigh in jt_adj[root]:
                if neigh == parent:
                    continue
                send_message(root, neigh)
                distribute(neigh, root)

        for root in range(n):
            if root in visited:
                continue
            # DFS to mark component and perform calibration in that component
            stack = [root]
            comp_nodes: List[int] = []
            while stack:
                node = stack.pop()
                if node in visited:
                    continue
                visited.add(node)
                comp_nodes.append(node)
                for neigh in jt_adj[node]:
                    if neigh not in visited:
                        stack.append(neigh)

            # Choose 'root' as the root of this component and run collect/distribute
            collect(root, parent=None)
            distribute(root, parent=None)

        # Compute clique beliefs
        clique_beliefs: List[Factor] = []
        for i in range(n):
            factors = [clique_potentials[i]]
            for neigh in jt_adj[i]:
                key = (neigh, i)
                if key in messages:
                    factors.append(messages[key])
            belief = Factor.multiply(factors).normalize()
            clique_beliefs.append(belief)

        return clique_beliefs

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------
    def query(
        self,
        model: Graph,
        query_vars: List[Any],
        evidence: Dict[Any, Any],
        elimination_order: Optional[List[Any]] = None,
    ) -> Factor:
        """
        Compute P(query_vars | evidence) using the junction tree algorithm.

        This implementation supports queries where all query variables are
        contained in at least one clique. If no such clique exists, we raise
        an error and recommend using VariableElimination as a fallback.
        """
        if not query_vars:
            raise ValueError("JunctionTree.query requires at least one query variable.")

        # Handle the simple case where all query vars are evidence
        if all(v in evidence for v in query_vars):
            # delta distribution on the observed configuration
            domains = model.var_domains
            scopes = list(query_vars)
            shape = tuple(len(domains[v]) for v in scopes)
            table = np.zeros(shape, dtype=float)

            # find index corresponding to evidence assignment
            idx = tuple(domains[v].index(evidence[v]) for v in scopes)
            table[idx] = 1.0
            return Factor(scopes, table, domains)

        # If model has no factors, return uniform over joint domain of query vars
        if not hasattr(model, "get_factors") or not model.get_factors():
            domains = model.var_domains
            scopes = list(query_vars)
            shape = tuple(len(domains[v]) for v in scopes)
            table = np.ones(shape, dtype=float)
            return Factor(scopes, table, domains).normalize()

        # 1) Build undirected (moralized) adjacency
        adj = self._build_undirected_adj(model)

        # 2) Triangulate and get maximal cliques
        cliques = self._triangulate_and_get_cliques(adj)
        if not cliques:
            raise RuntimeError("No cliques found while building junction tree.")

        # 3) Build junction tree structure
        jt_adj, seps = self._build_junction_tree(cliques)

        # 4) Initialize clique potentials (with evidence)
        clique_potentials = self._initialize_clique_potentials(model, cliques, evidence)

        # 5) Calibrate the junction tree
        clique_beliefs = self._calibrate_junction_tree(
            cliques, jt_adj, seps, clique_potentials
        )

        # 6) Answer the query
        query_set = set(query_vars)

        # Try to find a clique that contains all query variables
        candidate_idx = None
        for idx, C in enumerate(cliques):
            if query_set.issubset(C):
                candidate_idx = idx
                break

        if candidate_idx is None:
            raise ValueError(
                "Current JunctionTree implementation only supports queries where "
                "all query variables are contained in at least one clique.\n"
                "For arbitrary query sets, please use VariableElimination."
            )

        belief = clique_beliefs[candidate_idx]

        # Sum out all variables not in query_vars
        for v in list(belief.scope):
            if v not in query_set:
                belief = belief.sum_out(v)

        return belief.normalize()


# Example usage and test
if __name__ == "__main__":
    # TODO 需要确定三角化的规则，或者输出clique来帮助确定有哪些clique然后再查询
    # Example: simple BN A -> B
    from pgm_toolkit.models.bayesnet import BayesianNetwork

    bn = BayesianNetwork()
    bn.add_node("A", domain=[0, 1])
    bn.add_node("B", domain=[0, 1])
    bn.add_node("C", domain=[0, 1])
    bn.add_edge("A", "C")
    bn.add_edge("B", "C")

    # P(A)
    bn.add_cpd("A", np.array([0.7, 0.3]), parents=[])
    bn.add_cpd("B", np.array([0.2, 0.8]), parents=[])

    cpd = [[[0.9, 0.7], [0.2, 0.5]], [[0.1, 0.3], [0.8, 0.5]]]
    bn.add_cpd("C", np.array(cpd), parents=["A", "B"])

    engine = JunctionTree()
    bn.set_inference_engine(engine)

    res = bn.query(["A", "B", "C"], evidence={})
    print(res.table)

    from pgm_toolkit.models.markovnet import MarkovNetwork

    mn = MarkovNetwork()
    mn.add_node("A", domain=[0, 1])
    mn.add_node("B", domain=[0, 1])
    mn.add_node("C", domain=[0, 1])
    mn.add_node("D", domain=[0, 1])

    mn.add_edge("A", "B")
    mn.add_edge("B", "C")
    mn.add_edge("B", "D")
    mn.add_edge("C", "D")

    # Add potentials
    mn.add_potential(["A", "B"], np.array([[2, 1], [1, 3]]))
    mn.add_potential(["B", "C"], np.array([[3, 1], [1, 2]]))
    mn.add_potential(["B", "D"], np.array([[2, 1], [1, 4]]))
    mn.add_potential(["C", "D"], np.array([[3, 2], [1, 5]]))

    mn.set_inference_engine(engine)

    result = mn.query(["B", "C", "D"], evidence={"A": 0})
    print(result.table)
