# # Chapter 5.1.1
#
# """
# Exact inference
# Authors: kkorovin@cs.cmu.edu
#
# """
# import itertools
#
# import numpy as np
# from inference.core import Inference
# from tqdm import tqdm
#
#
# class ExactInference(Inference):
#     """Special case BinaryMRF implementation"""
#
#     def _safe_norm_exp(self, logit):
#         logit -= np.max(logit, keepdims=True)
#         prob = np.exp(logit)
#         prob /= prob.sum(keepdims=True)
#         return prob
#
#     def compute_probs(self, W, b, n):
#         log_potentials = np.zeros([2] * n)
#         for state in itertools.product([0, 1], repeat=n):
#             state_ind = np.array(state)
#             state_val = 2 * state_ind - 1
#             log_potentials[state] = state_val.dot(W.dot(state_val)) + b.dot(state_val)
#         # probs = np.exp(log_potentials)
#         # probs /= probs.sum()
#         probs = self._safe_norm_exp(log_potentials)
#         return probs
#
#     def run_one(self, graph):
#         W = graph.W
#         b = graph.b
#         n = graph.n_nodes
#
#         # compute joint probabilities
#         # array of shape [2,...,2]
#         probs = self.compute_probs(W, b, n)
#         # print("M1:", probs[0, :, :].sum(), probs[1, :, :].sum())
#         # print("M2:", probs[:, 0, :].sum(), probs[:, 1, :].sum())
#
#         if self.mode == "marginal":
#             # select one state and compute marginal:
#             marginals = np.zeros((n, 2))  # [i, 0] is P(x_i=0)
#             for i in range(n):
#                 axes = tuple(j for j in range(n) if j != i)
#                 marginal = probs.sum(axis=axes)
#                 marginals[i] = marginal
#             return marginals
#
#         elif self.mode == "map":
#             binary_ind = np.unravel_index(probs.argmax(), probs.shape)
#             return 2 * np.array(binary_ind) - 1
#
#     def run(self, graphs, verbose=False):
#         self.verbose = verbose
#         res = []
#         graph_iterator = tqdm(graphs) if self.verbose else graphs
#         for graph in graph_iterator:
#             res.append(self.run_one(graph))
#         return res

# variable_elimination.py
"""
Variable Elimination inference engine (implements a pluggable interface).
Usage:
  from variable_elimination import VariableElimination
  engine = VariableElimination()
  bn.set_inference_engine(engine)
  result = bn.query(['A'], evidence={'B': 'b_val'})

Returns a Factor (normalized) over the query variables.
"""
from __future__ import annotations

from typing import Any, Dict, List, Optional

import numpy as np

from pgm_toolkit.core.graph import Factor
from pgm_toolkit.inference.exact_inference.core import InferenceEngine


class VariableElimination(InferenceEngine):
    def __init__(self, elimination_heuristic: Optional[str] = None):
        """elimination_heuristic: optional string
        to choose ordering strategy (e.g. 'min_fill')."""
        self.heuristic = elimination_heuristic

    def _pick_elimination_order(
        self, model, query_vars: List[Any], evidence: Dict[Any, Any]
    ) -> List[Any]:
        # naive: collect all vars in model factors, exclude query and evidence
        vars_in_factors = set()
        for f in model.get_factors():
            vars_in_factors.update(f.scope)
        to_eliminate = [
            v for v in vars_in_factors if v not in query_vars and v not in evidence
        ]
        # could implement min-fill/min-degree heuristics here
        return to_eliminate

    def query(
        self,
        model,
        query_vars: List[Any],
        evidence: Dict[Any, Any],
        elimination_order: Optional[List[Any]] = None,
    ):
        # 1) start with reduced factors
        factors = [f.reduce(evidence) for f in model.get_factors()]

        # 2) determine elimination order
        if elimination_order is None:
            elimination_order = self._pick_elimination_order(
                model, query_vars, evidence
            )

        # 3) eliminate variables
        for var in elimination_order:
            # collect factors containing var
            related = [f for f in factors if var in f.scope]
            if not related:
                continue
            # multiply them
            prod = Factor.multiply(related)
            # sum out var
            summed = prod.sum_out(var)
            # remove related and add summed
            factors = [f for f in factors if f not in related]
            factors.append(summed)

        # 4) multiply remaining factors
        if not factors:
            raise RuntimeError("No factors left after elimination")
        result = factors[0]
        for f in factors[1:]:
            result = Factor.multiply([result, f])

        # 5) if result contains extra variables not in query_vars, sum them out
        extra = [v for v in result.scope if v not in query_vars]
        for v in extra:
            result = result.sum_out(v)

        # 6) normalize
        return result.normalize()


# example usage and small smoke test
if __name__ == "__main__":
    # Example: simple BN A -> B
    from pgm_toolkit.models.bayesnet import BayesianNetwork

    # TODO 通过list或者dict或csv文件来自动读取图设置，同时检查合法性
    # (1.条件概率和为1 2贝叶斯网络中如果一个节点有多个父节点,那么cpd必须同时包含所有节点,而不能单独给出)
    bn = BayesianNetwork()
    bn.add_node("A", domain=[0, 1])
    bn.add_node("B", domain=[0, 1])
    bn.add_node("C", domain=[0, 1])
    # bn.add_node("D", domain=[0, 1])

    # P(A)
    bn.add_cpd("A", np.array([0.7, 0.3]), parents=[])
    bn.add_cpd("B", np.array([0.8, 0.2]), parents=[])

    cpd = [[[0.9, 0.7], [0.2, 0.5]], [[0.1, 0.3], [0.8, 0.5]]]
    bn.add_cpd("C", np.array(cpd), parents=["A", "B"])
    # bn.add_cpd("D", np.array([[0.9,0.2],[0.1,0.8]]), parents=["C"])

    engine = VariableElimination()
    bn.set_inference_engine(engine)

    res = bn.query(
        [
            "C",
        ],
        evidence={},
    )
    print(res.table)

    from pgm_toolkit.models.markovnet import MarkovNetwork

    mn = MarkovNetwork()
    mn.add_node("A", domain=[0, 1])
    mn.add_node("B", domain=[0, 1])
    mn.add_node("C", domain=[0, 1])
    mn.add_node("D", domain=[0, 1])

    # mn.add_edge("A", "B")
    # mn.add_edge("B", "C")
    # mn.add_edge("B", "D")
    # mn.add_edge("C", "D")

    # Add potentials
    mn.add_potential(["A", "B"], np.array([[2, 1], [1, 3]]))
    mn.add_potential(["B", "C"], np.array([[3, 1], [1, 2]]))
    mn.add_potential(["B", "D"], np.array([[2, 1], [1, 4]]))
    mn.add_potential(["C", "D"], np.array([[3, 2], [1, 5]]))

    mn.set_inference_engine(engine)

    result = mn.query(["B", "C", "D"], evidence={"A": 0})
    print(result.table)

# end of variable_elimination.py
