# Chapter 27
# Gibbs Sampling
# MCMC
# Importance Sampling
# Hamiltonian Monte Carlo


"""

Implements MCMC inference procedures.
Authors: kkorovin@cs.cmu.edu

TODO:
* How to obtain a MAP estimate from samples?
  (some sources suggest temperature in MH)
"""

import pickle
from collections import Counter

import numpy as np
import pandas as pd
from inference.core import Inference
from tqdm import tqdm


class GibbsSampling(Inference):
    """Gibbs sampling for binaryMRF."""

    def conditonal(self, i, X):
        """
        return P(x_i=1|other)
        """

        def sigmoid(x):
            return 1.0 / (1 + np.exp(-x))

        tmp = self.W[i, :].dot(X)
        return sigmoid(2 * (tmp + self.u[i]))

    def gibbs_sampling(self, n, burn_in=1000, stride=2):
        X = np.array([1 if np.random.rand() < 0.5 else -1 for i in range(self.d)])
        samples = [np.copy(X)]
        for i in range(stride * n + burn_in - 1):
            for j in range(self.d):
                p = self.conditonal(j, X)
                X[j] = +1 if np.random.rand() < p else -1
            samples.append(np.copy(X))
        return np.array(samples[burn_in::stride])

    def collect_samples(self, graphs, n):
        graph_iterator = tqdm(graphs) if self.verbose else graphs
        samples = []
        for graph in graph_iterator:
            self.W = graph.J
            self.u = graph.w
            self.d = graph.n_nodes

            sample = self.gibbs_sampling(n)
            samples.append(sample)

        return samples

    def run(self, graphs, n=1000, verbose=False):
        self.verbose = verbose
        graphs_samples = self.collect_samples(graphs, n)
        res = []
        for samples, graph in zip(graphs_samples, graphs):
            # for each graph, compute pos and neg probs
            if self.mode == "marginal":
                # for each [:, i], compute empirical shares of -1 and 1
                binary_samples = np.where(samples < 0, 0, 1)
                pos_probs = binary_samples.mean(axis=0)
                neg_pos = np.stack([1 - pos_probs, pos_probs], axis=1)
                assert neg_pos.shape == (graph.n_nodes, 2)
                res.append(neg_pos)
            elif self.mode == "map":
                cnt = Counter([tuple(row) for row in samples])
                most_freq = cnt.most_common(1)[0][0]
                res.append(most_freq)
        return res


if __name__ == "__main__":
    gibs = GibbsSampling("map")
    with open("../simulated_sample.pkl", "rb") as handle:
        data = pickle.load(handle)
        target, u, W = data["target"], data["w"], data["J"]
    # W = np.array([[0, -1, 0, 0, 0, 0, 0],
    #               [-1, 0, 1.5, 1, 0, 0, 0],
    #               [0, 1.5, 0, 0, 1.5, 2, -2],
    #               [0, 1, 0, 0, 0, 0, 0],
    #               [0, 0, 1.5, 0, 0, 0, 0],
    #               [0, 0, 2, 0, 0, 0, 0],
    #               [0, 0, -2, 0, 0, 0, 0]])
    # u = np.zeros(7)
    from graphical_models import BinaryMRF

    graphs = [BinaryMRF(W, u)]
    samples = gibs.collect_samples(graphs, 10000)
    res = samples[0]
    # print(samples[0])
    probs = []
    for i in range(1, 5):
        cnt = pd.DataFrame(res[:, [0, i]]).groupby([0, 1]).size().unstack(1).values
        probs.append(cnt / cnt.sum())
    print(probs)
