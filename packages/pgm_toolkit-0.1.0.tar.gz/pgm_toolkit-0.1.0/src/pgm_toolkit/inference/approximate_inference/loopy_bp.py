# Chapter 28.7 Loopy Belief Propagation
