# Chapter 23.2

# forward_backward算法在类中实现
