# graph.py
"""
Node, Edge, Graph base classes and Factor implementation used by both
BayesianNetwork and MarkovNetwork.
"""
from __future__ import annotations

from typing import Any, Dict, List, Optional, Set, Tuple

import numpy as np


class Node:
    """Graph node representing a random variable or other node."""

    def __init__(
        self,
        name: Any,
        node_type: str = "random_variable",
        domain: Optional[List[Any]] = None,
        value: Any = None,
    ):
        self.name = name
        self.node_type = node_type
        self.domain = list(domain) if domain is not None else []
        self.value = value

        # topology
        self.parents: Set[Node] = set()
        self.children: Set[Node] = set()
        self.neighbors: Set[Node] = set()

    def add_parent(self, parent: "Node") -> None:
        self.parents.add(parent)
        self.neighbors.add(parent)

    def add_child(self, child: "Node") -> None:
        self.children.add(child)
        self.neighbors.add(child)

    def add_neighbor(self, neighbor: "Node") -> None:
        self.neighbors.add(neighbor)

    def set_value(self, value: Any) -> None:
        self.value = value

    def __repr__(self) -> str:
        return f"Node({self.name!r}, type={self.node_type}, domain={self.domain})"

    def __hash__(self) -> int:
        return hash(self.name)

    def __eq__(self, other) -> bool:
        return isinstance(other, Node) and other.name == self.name


class Edge:
    """Graph edge for directed/undirected graphs."""

    def __init__(self, source: Node, target: Node, edge_type: str = "directed"):
        self.source = source
        self.target = target
        self.edge_type = edge_type

    def nodes(self) -> Tuple[Node, Node]:
        return (self.source, self.target)

    def is_incident_to(self, node: Node) -> bool:
        return node == self.source or node == self.target

    def __repr__(self) -> str:
        if self.edge_type == "directed":
            return f"Edge({self.source.name!r} -> {self.target.name!r})"
        return f"Edge({self.source.name!r} -- {self.target.name!r})"

    def __hash__(self) -> int:
        if self.edge_type == "directed":
            return hash((self.source, self.target, "directed"))
        else:
            return hash(frozenset([self.source, self.target]))

    def __eq__(self, other) -> bool:
        if not isinstance(other, Edge):
            return False
        if self.edge_type != other.edge_type:
            return False
        if self.edge_type == "directed":
            return self.source == other.source and self.target == other.target
        return {self.source, self.target} == {other.source, other.target}


class Graph:
    """Abstract graph container (base for BayesianNetwork and MarkovNetwork)."""

    def __init__(self, name: str = "unnamed"):
        self.name = name
        self.nodes: Dict[Any, Node] = {}
        self.edges: Set[Edge] = set()

    def add_node(
        self,
        node: Any,
        node_type: str = "random_variable",
        domain: Optional[List[Any]] = None,
        value: Any = None,
    ) -> Node:
        if isinstance(node, Node):
            node_obj = node
        else:
            node_obj = Node(node, node_type, domain, value)
        if node_obj.name in self.nodes:
            raise ValueError(f"Node {node_obj.name} already exists")
        self.nodes[node_obj.name] = node_obj
        return node_obj

    def add_edge(self, source: Any, target: Any, edge_type: str = "directed") -> Edge:
        if not isinstance(source, Node):
            source = self.nodes[source]
        if not isinstance(target, Node):
            target = self.nodes[target]
        edge = Edge(source, target, edge_type)
        if edge_type == "directed":
            source.add_child(target)
            target.add_parent(source)
        else:
            source.add_neighbor(target)
            target.add_neighbor(source)
        self.edges.add(edge)
        return edge

    def get_node(self, node_id: Any) -> Optional[Node]:
        return self.nodes.get(node_id)

    def is_directed(self) -> bool:
        raise NotImplementedError


class Factor:
    """
    Factor representation for discrete variables.

    scope: list of variables (ordering corresponds to axes in table)
    table: numpy ndarray with shape = tuple(len(domain(var)) for var in scope)
    var_domains: mapping variable -> list of values
    """

    def __init__(
        self, scope: List[Any], table: np.ndarray, var_domains: Dict[Any, List[Any]]
    ):
        self.scope = list(scope)
        self.table = np.array(table, dtype=float)
        self.var_domains = {k: list(v) for k, v in var_domains.items()}

        # 验证输入一致性
        if len(self.scope) != self.table.ndim:
            # 允许空scope的标量表
            if not (self.table.ndim == 0 and len(self.scope) == 0):
                raise ValueError(
                    f"Inconsistent scope/table: len(scope)={len(self.scope)}, "
                    f"table.ndim={self.table.ndim}"
                )

        # 验证所有scope变量都在var_domains中
        for var in self.scope:
            if var not in self.var_domains:
                raise ValueError(f"Variable {var} in scope but not in var_domains")

        # 验证表形状与变量域大小匹配
        expected_shape = tuple(len(self.var_domains[var]) for var in self.scope)
        if self.table.shape != expected_shape and len(self.scope) > 0:
            raise ValueError(
                f"Table shape {self.table.shape} "
                f"doesn't match expected shape {expected_shape}"
            )

        # 构建值到索引的映射
        self._val2idx = {
            v: {val: i for i, val in enumerate(self.var_domains[v])} for v in self.scope
        }

    def copy(self) -> "Factor":
        return Factor(
            list(self.scope),
            np.array(self.table, copy=True),
            {k: list(v) for k, v in self.var_domains.items()},
        )

    def reduce(self, evidence: Dict[Any, Any]) -> "Factor":
        """Apply evidence: fix variables in evidence
        (by value) and return reduced factor."""
        f = self.copy()

        # 按scope顺序处理证据，避免索引变化问题
        evidence_vars_in_scope = [var for var in f.scope if var in evidence]

        for var in evidence_vars_in_scope:
            val = evidence[var]
            axis = f.scope.index(var)
            idx = f._val2idx[var].get(val)
            if idx is None:
                raise ValueError(f"Value {val} not in domain of {var}")

            # 在指定轴上选择特定索引
            f.table = np.take(f.table, indices=idx, axis=axis)

            # 更新scope和映射
            f.scope.pop(axis)
            del f._val2idx[var]
            # evidence后更新scope
            if var in f.var_domains:
                del f.var_domains[var]

        # 确保空scope的表是标量
        if len(f.scope) == 0 and f.table.ndim != 0:
            f.table = f.table.reshape(())

        return f

    @staticmethod
    def multiply(factors: List["Factor"]) -> "Factor":
        if not factors:
            raise ValueError("No factors to multiply")

        # 如果只有一个因子，直接返回副本
        if len(factors) == 1:
            return factors[0].copy()

        # 确定新的scope，保持第一次出现的顺序
        new_scope: List[Any] = []
        var_domains: Dict[Any, List[Any]] = {}

        # 收集所有变量和域，检查冲突
        for f in factors:
            for v in f.scope:
                if v not in new_scope:
                    new_scope.append(v)
                # 检查域冲突
                if v in var_domains:
                    if var_domains[v] != f.var_domains[v]:
                        raise ValueError(
                            f"Domain mismatch for variable {v}: "
                            f"{var_domains[v]} vs {f.var_domains[v]}"
                        )
                else:
                    var_domains[v] = list(f.var_domains[v])

        # 构建结果数组形状
        shape = tuple(len(var_domains[v]) for v in new_scope)
        result = np.ones(shape, dtype=float)

        # 逐个因子相乘
        for f in factors:
            if not f.scope:  # 空scope因子（常数因子）
                result = result * f.table
                continue

            # 创建目标形状：对于new_scope中的每个变量，如果在f的scope中则用域大小，否则用1
            target_shape = []
            f_axes_in_new = []  # f的变量在new_scope中的位置

            for v in new_scope:
                if v in f.scope:
                    target_shape.append(len(var_domains[v]))
                    f_axes_in_new.append(new_scope.index(v))
                else:
                    target_shape.append(1)

            # 重塑f的表以匹配new_scope的顺序
            # 首先确定f的变量在new_scope中的位置
            f_axis_to_new_axis = [new_scope.index(var) for var in f.scope]

            # 转置f.table以匹配new_scope的顺序
            if len(f.scope) > 1:
                # 创建转置顺序：按f变量在new_scope中的位置排序
                transpose_order = np.argsort(f_axis_to_new_axis)
                f_table_transposed = np.transpose(f.table, transpose_order)
            else:
                f_table_transposed = f.table

            # 重塑到目标形状
            f_reshaped = f_table_transposed.reshape(target_shape)

            # 相乘
            result = result * f_reshaped

        return Factor(new_scope, result, var_domains)

    def sum_out(self, var: Any) -> "Factor":
        """Sum out a variable (marginalization)."""
        if var not in self.scope:
            return self.copy()

        axis = self.scope.index(var)
        new_table = np.sum(self.table, axis=axis)
        new_scope = list(self.scope)
        new_scope.pop(axis)

        # 更新var_domains
        new_var_domains = self.var_domains.copy()
        del new_var_domains[var]

        return Factor(new_scope, new_table, new_var_domains)

    def normalize(self) -> "Factor":
        """Normalize the factor to sum to 1."""
        s = float(np.sum(self.table))
        if s == 0:
            # 如果和为0，返回均匀分布（避免除以0）
            uniform_table = np.ones_like(self.table) / self.table.size
            return Factor(list(self.scope), uniform_table, self.var_domains)
        return Factor(list(self.scope), self.table / s, self.var_domains)

    def to_dict(self) -> Dict[Tuple[Tuple[Any, Any], ...], float]:
        """Flatten factor table to mapping from
        assignments to value (useful for debugging)."""
        out = {}
        if len(self.scope) == 0:
            return {(): float(self.table)}

        # 生成所有可能的赋值组合
        for idx in np.ndindex(*self.table.shape):
            assignment = tuple(
                (self.scope[i], self.var_domains[self.scope[i]][idx[i]])
                for i in range(len(self.scope))
            )
            out[assignment] = float(self.table[idx])
        return out

    def __repr__(self) -> str:
        return f"Factor(scope={self.scope}, shape={self.table.shape})"

    def __str__(self) -> str:
        return f"Factor over {self.scope}: {self.to_dict()}"
