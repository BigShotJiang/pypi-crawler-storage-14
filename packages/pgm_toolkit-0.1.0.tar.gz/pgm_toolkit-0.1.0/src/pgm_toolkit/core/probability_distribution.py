# - Distribution: 分布基类
# - Categorical: 分类分布
# - Gaussian: 高斯分布
# - ConditionalProbabilityTable: 条件概率表
# - Factor: 因子（用于无向图）
# Chapter 8.5
from abc import ABC, abstractmethod
from typing import Any, List, Optional

import numpy as np


class Distribution(ABC):
    """概率分布基类"""

    def __init__(self, distribution_type: str, **parameters):
        """
        初始化分布

        Args:
            distribution_type: 分布类型
            **parameters: 分布参数
        """
        self.distribution_type = distribution_type
        self.parameters = parameters

    @abstractmethod
    def sample(self, size: int = 1):
        """从分布中采样"""
        pass

    @abstractmethod
    def log_prob(self, value):
        """计算值的对数概率"""
        pass

    def prob(self, value):
        """计算值的概率"""
        return np.exp(self.log_prob(value))

    def __repr__(self):
        params_str = ", ".join(f"{k}={v}" for k, v in self.parameters.items())
        return f"{self.distribution_type}({params_str})"


class Categorical(Distribution):
    """分类分布"""

    def __init__(
        self, probabilities: List[float], categories: Optional[List[Any]] = None
    ):
        """
        初始化分类分布

        Args:
            probabilities: 各类别的概率
            categories: 类别标签，如果为None则使用索引
        """
        self.probabilities = np.array(probabilities)
        self.categories = categories or list(range(len(probabilities)))
        super().__init__(
            "categorical", probabilities=probabilities, categories=categories
        )

        # 归一化概率
        self.probabilities = self.probabilities / self.probabilities.sum()

    def sample(self, size: int = 1):
        indices = np.random.choice(
            len(self.probabilities), size=size, p=self.probabilities
        )
        if size == 1:
            return self.categories[indices[0]]
        return [self.categories[i] for i in indices]

    def log_prob(self, value):
        if value not in self.categories:
            return -np.inf
        idx = self.categories.index(value)
        return np.log(self.probabilities[idx])

    def __repr__(self):
        return (
            f"Categorical(probs={self.probabilities.tolist()}, "
            f"categories={self.categories})"
        )


class Gaussian(Distribution):
    """高斯分布"""

    def __init__(self, mean: float, variance: float):
        """
        初始化高斯分布

        Args:
            mean: 均值
            variance: 方差
        """
        self.mean = mean
        self.variance = variance
        self.std = np.sqrt(variance)
        super().__init__("gaussian", mean=mean, variance=variance)

    def sample(self, size: int = 1):
        return np.random.normal(self.mean, self.std, size)

    def log_prob(self, value):
        return -0.5 * (
            np.log(2 * np.pi * self.variance) + (value - self.mean) ** 2 / self.variance
        )

    def __repr__(self):
        return f"Gaussian(μ={self.mean}, σ²={self.variance})"
