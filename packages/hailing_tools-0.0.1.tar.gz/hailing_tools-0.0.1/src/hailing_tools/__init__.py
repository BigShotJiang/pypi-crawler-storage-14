from .core import notify, set_notify_config, get_logger, notify_hailing

__version__ = "0.0.1"
__all__ = ["notify", "set_notify_config", "get_logger", "notify_hailing"]

