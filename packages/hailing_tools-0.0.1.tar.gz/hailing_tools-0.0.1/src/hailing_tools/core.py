import requests
import logging
import sys
import os
from datetime import datetime

# =============================================================================
# Global Configuration (全局配置)
# =============================================================================

_CONFIG = {
    "device_key": None,
    "default_title": "Hailing Notification",
    "default_icon": None
}

def set_notify_config(device_key: str = None, title: str = None, icon: str = None):
    """
    设置全局默认参数，后续调用 notify 时无需重复传递。
    
    Args:
        device_key (str): 默认的 Bark Key
        title (str): 默认的通知标题
        icon (str): 默认的图标 URL
    """
    if device_key:
        _CONFIG["device_key"] = device_key
    if title:
        _CONFIG["default_title"] = title
    if icon:
        _CONFIG["default_icon"] = icon

# =============================================================================
# Tool 1: Logging Utils (日志工具)
# =============================================================================

def get_logger(name: str = "hailing", 
               log_dir: str = "logs", 
               log_filename: str = "app.log",
               level: int = logging.INFO,
               fmt: str = '%(asctime)s - %(levelname)s - [%(filename)s:%(lineno)d] - %(message)s',
               date_fmt: str = '%Y-%m-%d %H:%M:%S'):
    """
    获取一个配置好的 Logger，默认同时输出到控制台和 logs 文件夹下的文件。
    """
    # 1. 初始化 Logger
    logger = logging.getLogger(name)
    logger.setLevel(level)
    
    # 防止重复添加 handler
    if logger.handlers:
        return logger

    # 2. 创建 Formatter
    formatter = logging.Formatter(fmt=fmt, datefmt=date_fmt)

    # 3. 配置控制台输出
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setFormatter(formatter)
    logger.addHandler(console_handler)

    # 4. 配置从文件输出
    try:
        if not os.path.exists(log_dir):
            os.makedirs(log_dir)
            
        file_path = os.path.join(log_dir, log_filename)
        file_handler = logging.FileHandler(file_path, encoding='utf-8', mode='a')
        file_handler.setFormatter(formatter)
        logger.addHandler(file_handler)
    except Exception as e:
        print(f"Warning: Failed to create log file at {log_dir}. Error: {e}")

    return logger


# =============================================================================
# Tool 2: Notification Utils (通知工具)
# =============================================================================

_internal_logger = logging.getLogger("hailing.core")
if not _internal_logger.handlers:
    logging.basicConfig(level=logging.INFO, format='[Hailing] %(message)s')

def _send_bark(device_key, title, body, icon=None):
    """发送 Bark (iOS) 通知"""
    url = f"https://api.day.app/{device_key}/{title}/{body}"
    
    params = {}
    if icon:
        params['icon'] = icon

    try:
        response = requests.get(url, params=params, timeout=10)
        data = response.json()
        
        if data.get('code') == 200:
            _internal_logger.info(f"Notification sent to device ending in ...{device_key[-4:]}")
            return True
        else:
            _internal_logger.error(f"Bark Error: {data.get('message')}")
            return False
            
    except Exception as e:
        _internal_logger.error(f"Failed to send Bark notification: {e}")
        return False

def notify(body: str, title: str = None, device_key: str = None, icon: str = None):
    """
    发送 Bark 通知。
    
    参数优先级: 函数参数 > 全局 set_config > 默认值

    Args:
        body (str): 通知详情内容 (必填)
        title (str): 通知标题 (可选，不传则使用配置的默认标题)
        device_key (str): 你的 Bark App Key (可选，不传则使用配置的 Key)
        icon (str): 图标 URL (可选，不传则使用配置的图标)
    """
    # 1. 确定最终参数 (Arguments -> Config -> Default)
    final_key = device_key if device_key else _CONFIG["device_key"]
    final_title = title if title else _CONFIG["default_title"]
    final_icon = icon if icon else _CONFIG["default_icon"]

    # 2. 校验
    if not final_key:
        _internal_logger.error("Missing device_key! Call set_config(device_key='...') or pass it directly.")
        return False
        
    final_key = final_key.strip()
    
    # 3. 执行：调试模式
    if final_key.lower() == 'console':
        print(f"🔔 [Mock Notify] {final_title}")
        print(f"   Body: {body}")
        if final_icon:
            print(f"   Icon: {final_icon}")
        return True

    # 4. 执行：真实发送
    return _send_bark(final_key, final_title, body, final_icon)


def notify_hailing(body="任务已完成", title="Hailing通知"):
    """
    发送 Hailing 通知。
    """
    ios_device_key = "5dhHvEns5VVjvCVWbzmSQd"
    macos_device_key = "WBxMYxJfMgAMwDQmUQsRCN"
    icon="https://s1.imagehub.cc/images/2025/11/28/a891302c3864629c91c12b655272e299.md.jpg"

    ei = notify(body, title, device_key=ios_device_key, icon=icon)
    em = notify(body, title, device_key=macos_device_key, icon=icon)
    return ei, em