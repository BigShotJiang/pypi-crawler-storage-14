#!/usr/bin/env python3

from pprint import pprint

import zig_zon
print('zig_zon module:', zig_zon)

teststr = """
.{
    .asdf = "ccc",
    .my_bool = true,
    .my_float = 1.23,
    .my_hex_int = 0xdeadbeef,
    .my_negative_int = -432_123_111,
    .my_negative_big_int = -4611686018427387904,
    .my_optional = null,
}"""

testzon = zig_zon.parse(teststr)
print('teststr:')
pprint(testzon)

assert testzon['asdf'] == "ccc"
assert testzon['my_float'] == 1.23
assert testzon['my_hex_int'] == 0xdeadbeef
assert testzon['my_negative_int'] == -432_123_111
assert testzon['my_negative_big_int'] == -4611686018427387904
assert testzon['my_optional'] == None

print('build.zig.zon:')
with open('build.zig.zon') as fd:
    pprint(zig_zon.parse(fd.read()))
