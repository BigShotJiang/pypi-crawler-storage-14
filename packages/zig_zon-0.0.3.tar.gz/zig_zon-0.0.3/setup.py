from setuptools import Extension
from setuptools import setup
import sys
import os

# In this package the setuptools_zig_build cannot be imported as a dependency.
# on another package zig_build should be passed to setup()
sys.path.insert(0, os.path.normpath(os.path.join(__file__, '..')))  # nopep8
from setuptools_zig_build import ZigBuildExtension  # nopep8

zig_build = {
    "use_zig_python_package": True,
    "optimize": "ReleaseSmall",
    'test_step': 'test',  # this is failing on windows for now ;-/
    'extra_args': [],
}

setup(
    name='zig-zon',
    cmdclass={
        'build_ext': ZigBuildExtension(zig_build),
    },
    ext_modules=[Extension('zig_zon', [])],
    setup_requires=[
        "setuptools-scm",
        "ziglang==0.15.1",
    ],
)
