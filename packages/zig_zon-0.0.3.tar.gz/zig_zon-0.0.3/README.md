# Python Zig Zon Parser

A native python extension built with zig to parse zig-object-notation strings
into python objects.

# Usage (so far only linux)

install:

```bash
python3 -m pip install git+https://gitlab.com/dasimmet/python-zig-zon.git
```

running:

```python
import zig_zon
parsed = zig_zon.parse('.{.allyourcode = .are_belong_to_us, .asd = 123}')
print(parsed)
```

or, look at the [test](test.py)
