const std = @import("std");
const Build = std.Build;

pub const CPython = @import("CPython.zig");

pub fn build(b: *Build) void {
    const target = b.standardTargetOptions(.{});
    const optimize = b.standardOptimizeOption(.{});
    const python = CPython.findAddOption(b);

    const exe = b.addExecutable(.{
        .name = "zigwheeler",
        .root_module = b.addModule("zigwheeler", .{
            .root_source_file = b.path("src/zigwheeler.zig"),
            .target = target,
            .optimize = optimize,
        }),
    });
    b.installArtifact(exe);

    const lib = b.addLibrary(.{
        .name = "zig_zon",
        .root_module = b.addModule("zig_zon", .{
            .root_source_file = b.path("src/zig_zon.zig"),
            .target = target,
            .optimize = optimize,
        }),
        .linkage = .dynamic,
        .use_llvm = true,
    });
    CPython.installExtLib(b, lib);

    python.link(b, .{
        .lib = lib,
    });

    const install_test = b.addInstallFile(b.path("src/test_zig_zon.py"), "lib/test_zig_zon.py");
    b.default_step.dependOn(&install_test.step);
    const run = b.addRunArtifact(exe);
    if (b.args) |args| {
        run.addArgs(args);
    }
    b.step("run", "run the wheeler").dependOn(&run.step);

    const test_run = python.run_test(b, lib, b.path("src/test_zig_zon.py"));

    b.step("test", "run the python test script").dependOn(&test_run.step);
}
