# coding: utf-8

import sys
import os
from subprocess import run
from pathlib import Path
import shlex

from setuptools import Extension
from distutils.dist import Distribution
from setuptools.command.build_ext import build_ext as SetupToolsBuildExt


class ZigCompilerError(Exception):
    """Some compile/link operation failed."""


class BuildExt(SetupToolsBuildExt):
    def __init__(self, dist, zig_value):
        self._zig_value = zig_value
        super().__init__(dist)

    def build_extension(self, ext):
        ext: Extension
        if not self._zig_value:
            return super().build_extension(ext)

        build_zig_dir = "."
        if len(ext.sources) == 1:
            build_zig_dir = ext.sources[0]
        elif len(ext.sources) > 1:
            raise ZigCompilerError(
                "sources should only point to build.zig directory")

        target = Path(self.get_ext_fullpath(ext.name))

        output_ext = os.path.splitext(self.get_ext_filename(ext.name))[1]

        zig_out = Path(self.build_temp) / "zig-out"

        bld_cmd = [os.environ.get('PY_ZIG', 'zig'), 'build', 'install',
                   '-Dpython={}'.format(sys.executable), '--prefix', str(zig_out.absolute())]

        if isinstance(self._zig_value, dict):
            if 'use_zig_python_package' in self._zig_value and self._zig_value['use_zig_python_package'] == True:
                import ziglang
                bld_cmd[0] = os.path.join(
                    os.path.dirname(ziglang.__file__), "zig")

            if 'test_step' in self._zig_value:
                bld_cmd.append(self._zig_value['test_step'])

            if 'optimize' in self._zig_value:
                assert isinstance(self._zig_value['optimize'], str)
                assert self._zig_value['optimize'] in [
                    "Debug",
                    "ReleaseSafe",
                    "ReleaseFast",
                    "ReleaseSmall",
                ]
                bld_cmd.append(
                    '-Doptimize={}'.format(self._zig_value['optimize']))

            if 'extra_args' in self._zig_value:
                assert isinstance(self._zig_value['extra_args'], list)
                for arg in self._zig_value['extra_args']:
                    assert isinstance(arg, str)
                    bld_cmd.append(arg)

        os.makedirs(self.build_temp, exist_ok=True)
        print('\ncmd', shlex.join(bld_cmd))
        sys.stdout.flush()
        run(bld_cmd, check=True, cwd=build_zig_dir)

        output = None
        for subpath in ['', 'lib', 'bin/', 'lib/', 'bin/lib', 'lib/lib']:
            zig_output = zig_out / (subpath + ext.name + output_ext)
            if zig_output.exists():
                output = zig_output.absolute()
                break
            print('missing:', str(zig_output.absolute()), file=sys.stderr)

        if output == None:
            raise ZigCompilerError(f'expected output does not exist')

        print('found output:', str(output.absolute()),
              str(target), file=sys.stderr)

        if target.exists():
            target.unlink()
        else:
            target.parent.mkdir(exist_ok=True, parents=True)
        output.rename(target)


class ZigBuildExtension:
    def __init__(self, value):
        self._value = value

    def __call__(self, dist):
        return BuildExt(dist, zig_value=self._value)


def setup_build_zig(dist, keyword, value):
    assert isinstance(dist, Distribution)
    assert keyword == 'build_zig'
    be = dist.cmdclass.get('build_ext')
    dist.cmdclass['build_ext'] = ZigBuildExtension(value)
