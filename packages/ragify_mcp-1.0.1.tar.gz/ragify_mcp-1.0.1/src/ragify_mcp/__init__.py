"""
ragify-mcp: MCP Server for RAG documentation search with Qdrant and Ollama.
"""

from .server import main

__version__ = "1.0.1"
__all__ = ["main"]
