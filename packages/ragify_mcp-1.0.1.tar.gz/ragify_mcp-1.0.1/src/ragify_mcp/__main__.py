"""
Allow running as: python -m ragify_mcp
"""

from .server import main

if __name__ == "__main__":
    main()
