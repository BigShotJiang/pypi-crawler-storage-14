s = 'single quotes'
