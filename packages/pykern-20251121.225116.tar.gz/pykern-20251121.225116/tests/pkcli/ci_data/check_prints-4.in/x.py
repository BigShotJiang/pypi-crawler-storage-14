print({})
