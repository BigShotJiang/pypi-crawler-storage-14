s = "double quotes ok"
