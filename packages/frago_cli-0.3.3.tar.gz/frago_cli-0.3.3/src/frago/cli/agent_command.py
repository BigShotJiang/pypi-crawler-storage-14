#!/usr/bin/env python3
"""
Frago Agent Command - 通过 Claude CLI 执行非交互式 AI 任务

认证策略：
根据 `frago init` 写入的 ~/.frago/config.json 配置决定：
1. auth_method == "official" → 直接使用 Claude CLI
2. auth_method == "custom" → Claude CLI 使用 ~/.claude/settings.json 的 env
3. ccr_enabled == True 或 --use-ccr → 使用 CCR 代理
"""

import json
import os
import shutil
import subprocess
import sys
from pathlib import Path
from typing import Optional, Tuple

import click


# =============================================================================
# 配置加载
# =============================================================================

def get_frago_config_path() -> Path:
    """获取 frago 配置文件路径"""
    return Path.home() / ".frago" / "config.json"


def load_frago_config() -> Optional[dict]:
    """
    加载 frago 配置

    Returns:
        配置字典，如果不存在或损坏返回 None
    """
    config_path = get_frago_config_path()
    if not config_path.exists():
        return None

    try:
        with open(config_path, "r", encoding="utf-8") as f:
            return json.load(f)
    except (json.JSONDecodeError, IOError):
        return None


# =============================================================================
# 工具函数
# =============================================================================

def find_claude_cli() -> Optional[str]:
    """
    查找 claude CLI 路径

    Returns:
        claude 可执行文件路径，未找到返回 None
    """
    return shutil.which("claude")


def check_ccr_auth() -> Tuple[bool, Optional[dict]]:
    """
    检查 CCR (Claude Code Router) 配置

    CCR 通过设置 ANTHROPIC_BASE_URL 指向本地代理来工作

    Returns:
        (是否可用, 配置信息)
    """
    # 检查 ccr 命令是否存在
    ccr_path = shutil.which("ccr")
    if not ccr_path:
        return False, None

    # 检查配置文件
    config_path = Path.home() / ".claude-code-router" / "config.json"
    if not config_path.exists():
        return False, {"error": "CCR config file not found"}

    try:
        with open(config_path, "r") as f:
            config = json.load(f)

        # 检查是否有配置的 Provider
        providers = config.get("Providers", [])
        if not providers:
            return False, {"error": "No providers configured in CCR"}

        # 检查 CCR 服务状态
        try:
            result = subprocess.run(
                ["ccr", "status"],
                capture_output=True,
                text=True,
                timeout=5
            )
            is_running = "Running" in result.stdout and "Not Running" not in result.stdout
        except (subprocess.TimeoutExpired, FileNotFoundError):
            is_running = False

        return True, {
            "type": AuthType.CCR,
            "config_path": str(config_path),
            "providers": [p.get("name") for p in providers],
            "default_route": config.get("Router", {}).get("default", "unknown"),
            "is_running": is_running,
            "host": config.get("HOST", "127.0.0.1"),
            "port": config.get("PORT", 3456),
        }
    except (json.JSONDecodeError, IOError) as e:
        return False, {"error": f"Failed to read CCR config: {e}"}


def should_use_ccr(config: Optional[dict], force_ccr: bool = False) -> Tuple[bool, Optional[dict]]:
    """
    判断是否应该使用 CCR

    Args:
        config: frago 配置
        force_ccr: 是否强制使用 CCR (--use-ccr 标志)

    Returns:
        (是否使用 CCR, CCR 配置信息)
    """
    # 强制使用 CCR
    if force_ccr:
        ok, info = check_ccr_auth()
        return ok, info

    # 根据配置判断
    if config and config.get("ccr_enabled"):
        ok, info = check_ccr_auth()
        return ok, info

    return False, None


def verify_claude_working(timeout: int = 30) -> Tuple[bool, str]:
    """
    通过运行简单提示词验证 Claude CLI 是否正常工作

    Args:
        timeout: 超时时间（秒）

    Returns:
        (是否正常, 错误信息或成功信息)
    """
    try:
        result = subprocess.run(
            ["claude", "-p", "Say 'OK'", "--output-format", "json"],
            capture_output=True,
            text=True,
            timeout=timeout
        )

        if result.returncode == 0:
            try:
                response = json.loads(result.stdout)
                if response.get("type") == "result":
                    return True, "Claude CLI is working"
            except json.JSONDecodeError:
                pass
            return True, "Claude CLI responded"

        # 解析错误信息
        error_msg = result.stderr or result.stdout or "Unknown error"
        if "authentication" in error_msg.lower() or "unauthorized" in error_msg.lower():
            return False, "Authentication failed - please run 'claude' and use /login"
        if "rate limit" in error_msg.lower():
            return False, "Rate limited - please wait and try again"

        return False, f"Claude CLI error: {error_msg[:200]}"

    except subprocess.TimeoutExpired:
        return False, f"Claude CLI timed out after {timeout}s"
    except FileNotFoundError:
        return False, "Claude CLI not found"
    except Exception as e:
        return False, f"Unexpected error: {e}"


def run_claude_command(
    prompt: str,
    env: dict,
    output_format: str = "json",
    timeout: int = 120,
    model: Optional[str] = None,
    skip_permissions: bool = True
) -> Tuple[bool, str, Optional[dict]]:
    """
    执行 claude 命令并返回结果

    Args:
        prompt: 提示词
        env: 环境变量
        output_format: 输出格式
        timeout: 超时时间
        model: 模型
        skip_permissions: 是否跳过权限确认

    Returns:
        (是否成功, 原始输出, 解析后的 JSON)
    """
    cmd = ["claude", "-p", prompt, "--output-format", output_format]

    if model:
        cmd.extend(["--model", model])

    if skip_permissions:
        cmd.append("--dangerously-skip-permissions")

    try:
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            env=env,
            timeout=timeout
        )

        output = result.stdout

        if result.returncode == 0 and output_format == "json":
            try:
                parsed = json.loads(output)
                return True, output, parsed
            except json.JSONDecodeError:
                return True, output, None

        return result.returncode == 0, output, None

    except subprocess.TimeoutExpired:
        return False, f"Timeout after {timeout}s", None
    except Exception as e:
        return False, str(e), None


def parse_routing_response(response_text: str) -> Optional[dict]:
    """
    解析路由响应，提取 JSON

    Args:
        response_text: Claude 返回的文本

    Returns:
        解析后的路由信息，或 None
    """
    # 尝试直接解析
    try:
        return json.loads(response_text.strip())
    except json.JSONDecodeError:
        pass

    # 尝试从 markdown code block 中提取
    import re
    json_match = re.search(r'```(?:json)?\s*(\{.*?\})\s*```', response_text, re.DOTALL)
    if json_match:
        try:
            return json.loads(json_match.group(1))
        except json.JSONDecodeError:
            pass

    # 尝试从文本中找 JSON 对象
    json_match = re.search(r'\{[^{}]*"command"[^{}]*\}', response_text)
    if json_match:
        try:
            return json.loads(json_match.group(0))
        except json.JSONDecodeError:
            pass

    return None


# =============================================================================
# CLI 命令
# =============================================================================

@click.command("agent")
@click.argument("prompt", nargs=-1, required=True)
@click.option(
    "--model",
    type=str,
    default=None,
    help="指定模型 (sonnet, opus, haiku 或完整模型名)"
)
@click.option(
    "--timeout",
    type=int,
    default=600,
    help="执行超时时间（秒），默认 600"
)
@click.option(
    "--use-ccr",
    is_flag=True,
    help="强制使用 CCR (Claude Code Router)"
)
@click.option(
    "--dry-run",
    is_flag=True,
    help="仅显示将要执行的命令，不实际执行"
)
@click.option(
    "--ask",
    is_flag=True,
    help="启用权限确认（默认跳过）"
)
@click.option(
    "--direct",
    is_flag=True,
    help="直接执行，跳过路由分析"
)
def agent(
    prompt: tuple,
    model: Optional[str],
    timeout: int,
    use_ccr: bool,
    dry_run: bool,
    ask: bool,
    direct: bool
):
    """
    智能 Agent：分析意图并路由到对应的 frago 子命令

    两阶段执行流程：
    1. 分析用户提示词，判断应调用哪个 /frago.* 命令
    2. 使用对应命令执行实际任务

    \b
    示例:
      frago agent 帮我在 Upwork 上找 Python 工作
      frago agent 调研 YouTube 字幕提取接口
      frago agent 写一个配方提取 Twitter 评论
      frago agent --direct 列出当前目录     # 跳过路由，直接执行

    \b
    可用的子命令路由:
      /frago.dev.run    - 探索调研、信息收集
      /frago.dev.exec   - 一次性任务执行
      /frago.dev.recipe - 创建自动化配方
      /frago.dev.test   - 测试验证配方

    \b
    可用模型 (--model):
      sonnet, opus, haiku 或完整模型名
    """
    # 将多个参数拼接成完整提示词
    prompt_text = " ".join(prompt)

    # Step 1: 检查 claude CLI 是否存在
    claude_path = find_claude_cli()
    if not claude_path:
        click.echo("错误: 未找到 claude CLI", err=True)
        click.echo("请先安装 Claude Code: https://claude.ai/code", err=True)
        sys.exit(1)

    click.echo(f"✓ Claude CLI: {claude_path}")

    # Step 2: 加载 frago 配置
    frago_config = load_frago_config()
    if frago_config:
        auth_method = frago_config.get("auth_method", "official")
        if auth_method == "official":
            click.echo("✓ 认证方式: Claude CLI 原生")
        else:
            click.echo("✓ 认证方式: 自定义 API 端点")
    else:
        click.echo("⚠ 未找到 frago 配置，使用 Claude CLI 默认认证")
        click.echo("  提示: 运行 'frago init' 进行初始化配置")

    # Step 3: 判断是否使用 CCR
    env = os.environ.copy()
    use_ccr_mode, ccr_info = should_use_ccr(frago_config, use_ccr)

    if use_ccr_mode:
        if not ccr_info:
            click.echo("\n错误: CCR 配置无效", err=True)
            sys.exit(1)

        host = ccr_info.get("host", "127.0.0.1")
        port = ccr_info.get("port", 3456)
        env["ANTHROPIC_AUTH_TOKEN"] = "test"
        env["ANTHROPIC_BASE_URL"] = f"http://{host}:{port}"
        env["NO_PROXY"] = "127.0.0.1"
        env["DISABLE_TELEMETRY"] = "true"

        if not ccr_info.get("is_running"):
            click.echo("正在启动 CCR 服务...")
            subprocess.run(["ccr", "start"], capture_output=True, env=env)

        click.echo(f"✓ 使用 CCR: http://{host}:{port}")

    # Step 4: 权限确认
    if not ask and not dry_run:
        click.echo()
        click.echo("⚠ 将以 --dangerously-skip-permissions 模式运行")
        click.echo("  Claude 将跳过所有权限确认，直接执行任何操作")
        if not click.confirm("确认继续？", default=False):
            click.echo("已取消")
            sys.exit(0)

    skip_permissions = not ask

    # =========================================================================
    # 两阶段执行流程
    # =========================================================================

    if direct:
        # 直接模式：跳过路由，直接执行用户提示词
        click.echo(f"\n[Direct] 直接执行: {prompt_text}")
        target_command = None
        final_prompt = prompt_text
    else:
        # 阶段一：路由分析
        click.echo(f"\n[阶段一] 分析意图: {prompt_text}")

        routing_prompt = f"/frago.agent {prompt_text}"

        if dry_run:
            click.echo(f"[Dry Run] 路由提示词: {routing_prompt}")
            click.echo("[Dry Run] 跳过实际执行")
            return

        click.echo("  正在分析...")

        ok, output, parsed = run_claude_command(
            routing_prompt,
            env=env,
            output_format="json",
            timeout=60,
            model=model or "haiku",  # 路由分析用快速模型
            skip_permissions=skip_permissions
        )

        if not ok:
            click.echo(f"✗ 路由分析失败: {output}", err=True)
            sys.exit(1)

        # 从 JSON 响应中提取 result
        result_text = ""
        if parsed and parsed.get("result"):
            result_text = parsed.get("result", "")
        else:
            result_text = output

        # 解析路由结果
        routing = parse_routing_response(result_text)

        if not routing or "command" not in routing:
            click.echo(f"✗ 无法解析路由结果", err=True)
            click.echo(f"  原始响应: {result_text[:500]}", err=True)
            # 降级：直接执行
            click.echo("  降级为直接执行模式...")
            target_command = None
            final_prompt = prompt_text
        else:
            target_command = routing.get("command")
            final_prompt = routing.get("prompt", prompt_text)
            reason = routing.get("reason", "")

            click.echo(f"  ✓ 路由到: {target_command}")
            if reason:
                click.echo(f"  原因: {reason}")

    # 阶段二：执行实际命令
    if target_command:
        click.echo(f"\n[阶段二] 执行: {target_command} {final_prompt}")
        execution_prompt = f"{target_command} {final_prompt}"
    else:
        click.echo(f"\n[执行] {final_prompt}")
        execution_prompt = final_prompt

    # 构建最终命令
    cmd = ["claude", "-p", execution_prompt, "--output-format", "text"]

    if model:
        cmd.extend(["--model", model])

    if skip_permissions:
        cmd.append("--dangerously-skip-permissions")

    click.echo("-" * 60)

    # 执行命令（实时输出）
    try:
        process = subprocess.Popen(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            env=env,
            bufsize=1,
            universal_newlines=True
        )

        for line in iter(process.stdout.readline, ""):
            click.echo(line, nl=False)

        process.wait(timeout=timeout)

        click.echo("-" * 60)

        if process.returncode == 0:
            click.echo("✓ 执行完成")
        else:
            click.echo(f"✗ 执行失败 (退出码: {process.returncode})", err=True)
            sys.exit(process.returncode)

    except subprocess.TimeoutExpired:
        process.kill()
        click.echo(f"\n✗ 执行超时 ({timeout}s)", err=True)
        sys.exit(1)
    except KeyboardInterrupt:
        process.kill()
        click.echo("\n✗ 用户中断", err=True)
        sys.exit(130)
    except Exception as e:
        click.echo(f"\n✗ 执行错误: {e}", err=True)
        sys.exit(1)


# =============================================================================
# 辅助命令：检查认证状态
# =============================================================================

@click.command("agent-status")
def agent_status():
    """
    检查 Claude CLI 认证状态

    显示当前可用的认证方式和配置信息。
    """
    click.echo("Claude CLI 认证状态检查")
    click.echo("=" * 50)

    # 检查 claude CLI
    claude_path = find_claude_cli()
    if claude_path:
        click.echo(f"✓ Claude CLI: {claude_path}")
        # 获取版本
        try:
            result = subprocess.run(
                ["claude", "--version"],
                capture_output=True,
                text=True,
                timeout=5
            )
            if result.returncode == 0:
                click.echo(f"  版本: {result.stdout.strip()}")
        except Exception:
            pass
    else:
        click.echo("✗ Claude CLI: 未安装")
        return

    click.echo()

    # 加载 frago 配置
    click.echo("Frago 配置:")
    frago_config = load_frago_config()
    if frago_config:
        auth_method = frago_config.get("auth_method", "official")
        ccr_enabled = frago_config.get("ccr_enabled", False)
        init_completed = frago_config.get("init_completed", False)

        click.echo(f"  配置文件: {get_frago_config_path()}")
        click.echo(f"  认证方式: {'Claude CLI 原生' if auth_method == 'official' else '自定义 API 端点'}")
        click.echo(f"  CCR 启用: {'是' if ccr_enabled else '否'}")
        click.echo(f"  初始化状态: {'已完成' if init_completed else '未完成'}")
    else:
        click.echo("  ⚠ 未找到配置文件")
        click.echo(f"  提示: 运行 'frago init' 进行初始化配置")

    click.echo()

    # 检查 CCR 状态（如果启用）
    if frago_config and frago_config.get("ccr_enabled"):
        click.echo("CCR 状态:")
        ok, info = check_ccr_auth()
        if ok:
            click.echo(f"  ✓ CCR 可用")
            click.echo(f"    Providers: {', '.join(info.get('providers', []))}")
            click.echo(f"    运行状态: {'运行中' if info.get('is_running') else '未运行'}")
        else:
            click.echo("  ✗ CCR 不可用")
            if info and info.get("error"):
                click.echo(f"    原因: {info['error']}")
