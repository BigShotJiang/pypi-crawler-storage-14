# Register all tasks on import
from .task_names import register_all_tasks

register_all_tasks()

del register_all_tasks
