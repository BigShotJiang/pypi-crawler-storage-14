# sage_setup: distribution = sagemath-rankwidth

from sage.all__sagemath_rankwidth import *
