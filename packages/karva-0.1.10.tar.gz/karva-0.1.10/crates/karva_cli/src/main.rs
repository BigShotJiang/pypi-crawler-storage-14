use karva_cli::{ExitStatus, karva_main};

fn main() -> ExitStatus {
    karva_main(|args| args)
}
