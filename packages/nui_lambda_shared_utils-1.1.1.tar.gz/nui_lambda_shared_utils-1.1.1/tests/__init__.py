"""
Tests for lambda-shared-utils package.
"""
