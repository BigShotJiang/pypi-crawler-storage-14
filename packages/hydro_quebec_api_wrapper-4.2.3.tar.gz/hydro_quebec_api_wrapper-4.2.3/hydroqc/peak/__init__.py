"""Peak module."""
