"""
Agentic Astra package.

A Model Context Protocol (MCP) server for interacting with Astra DB.
"""

__version__ = "0.0.2"
__author__ = "Samuel Matioli"
__email__ = "smatioli@gmail.com"
