# Integrating Astra MCP Server with IBM Orchestrate

Generate and API key on IBM Orchestrate.

Info: https://developer.watson-orchestrate.ibm.com/getting_started/installing#ibm-cloud


```bash
orchestrate env add -n test -u https://api.us-south.watson-orchestrate.cloud.ibm.com/instances/ --activate 
```