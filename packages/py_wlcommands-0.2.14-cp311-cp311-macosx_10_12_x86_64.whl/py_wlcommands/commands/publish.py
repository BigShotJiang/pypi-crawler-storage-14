"""Publish command for WL Commands - Module entry point."""

from pathlib import Path
from typing import Any

from ..commands import Command, register_command
from ..exceptions import CommandError
from .publish.publish_command import PublishCommandImpl


@register_command("publish")
class PublishCommand(Command):
    """Command to publish the project to PyPI."""

    def __init__(self):
        """Initialize the publish command."""
        self._impl = PublishCommandImpl()

    @property
    def name(self) -> str:
        """Return the command name."""
        return self._impl.name

    @property
    def help(self) -> str:
        """Return the command help text."""
        return self._impl.help

    def add_arguments(self, parser: Any) -> None:
        """Add arguments to the parser."""
        self._impl.add_arguments(parser)

    def execute(self, *args: Any, **kwargs: Any) -> None:
        """Execute the publish command."""
        self._impl.execute(*args, **kwargs)
