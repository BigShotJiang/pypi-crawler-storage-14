from __future__ import annotations

import json
import os
import platform
import subprocess
import sys
import xml.etree.ElementTree as ET
from datetime import datetime
from pathlib import Path
from typing import Any

from ...utils.logging import log_info


def _read_json(path: str) -> dict[str, Any]:
    p = Path(path)
    if not p.exists():
        return {}
    try:
        return json.loads(p.read_text(encoding="utf-8"))
    except Exception:
        return {}


def _read_xml(path: str) -> ET.Element | None:
    p = Path(path)
    if not p.exists():
        return None
    try:
        tree = ET.parse(str(p))
        return tree.getroot()
    except Exception:
        return None


def _get_env_info() -> list[str]:
    now = datetime.now().isoformat(timespec="seconds")
    py_ver = sys.version.replace("\n", " ")
    os_info = f"{platform.system()} {platform.release()} ({platform.machine()})"
    try:
        import pytest as _pytest

        pytest_ver = getattr(_pytest, "__version__", "unknown")
    except Exception:
        pytest_ver = "unknown"
    return [
        f"时间: {now}",
        f"Python: {py_ver}",
        f"OS: {os_info}",
        f"pytest: {pytest_ver}",
    ]


def _fmt_pct(x: Any) -> str:
    try:
        v = float(x)
        return f"{v:.2f}%"
    except Exception:
        return "N/A"


def _coverage_totals(
    data: dict[str, Any],
) -> tuple[float | None, float | None, int, int, int]:
    files = data.get("files", {})
    num_files = len(files) if isinstance(files, dict) else 0
    covered_lines = 0
    total_lines = 0
    covered_branches = 0
    total_branches = 0
    if isinstance(files, dict):
        for info in files.values():
            s = info.get("summary", {})
            try:
                covered_lines += int(s.get("covered_lines", 0))
                total_lines += int(s.get("num_statements", s.get("num_lines", 0)))
                covered_branches += int(s.get("covered_branches", 0))
                total_branches += int(s.get("num_branches", 0))
            except Exception:
                pass
    line_pct = (covered_lines / total_lines * 100.0) if total_lines else None
    branch_pct = (covered_branches / total_branches * 100.0) if total_branches else None
    return (
        line_pct,
        branch_pct,
        total_lines,
        total_branches,
        num_files,
    )


def _file_entries(
    data: dict[str, Any], project_root: str
) -> list[tuple[str, float | None, float | None]]:
    files = data.get("files", {})
    res: list[tuple[str, float | None, float | None]] = []
    if isinstance(files, dict):
        for path, info in files.items():
            rel = path
            try:
                rel = str(
                    Path(path).resolve().relative_to(Path(project_root).resolve())
                )
            except Exception:
                pass
            lp = info.get("summary", {}).get("percent_covered")
            bp = info.get("summary", {}).get("percent_branches")
            if lp is None:
                lp = info.get("percent_covered")
            if bp is None:
                bp = info.get("percent_branches")
            try:
                lp_f = float(lp) if lp is not None else None
            except Exception:
                lp_f = None
            try:
                bp_f = float(bp) if bp is not None else None
            except Exception:
                bp_f = None
            res.append((rel, lp_f, bp_f))
    return res


def _write_md(path: str, lines: list[str]) -> None:
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text("\n".join(lines) + "\n", encoding="utf-8")


def _parse_junit(
    root: ET.Element | None,
) -> tuple[int, int, int, int, float, list[dict[str, str]]]:
    if root is None:
        return (0, 0, 0, 0, 0.0, [])
    suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
    tests = failures = errors = skipped = 0
    time = 0.0
    cases: list[dict[str, str]] = []
    for ts in suites:
        tests += int(ts.attrib.get("tests", 0))
        failures += int(ts.attrib.get("failures", 0))
        errors += int(ts.attrib.get("errors", 0))
        skipped += int(ts.attrib.get("skipped", 0))
        try:
            time += float(ts.attrib.get("time", 0.0))
        except Exception:
            pass
        for tc in ts.findall("testcase"):
            name = tc.attrib.get("name", "")
            classname = tc.attrib.get("classname", "")
            file_attr = tc.attrib.get("file", "")
            text = ""
            kind = ""
            fail = tc.find("failure")
            err = tc.find("error")
            if fail is not None:
                kind = "failure"
                text = (
                    fail.attrib.get("message", "") + "\n" + (fail.text or "")
                ).strip()
            elif err is not None:
                kind = "error"
                text = (err.attrib.get("message", "") + "\n" + (err.text or "")).strip()
            if kind:
                if len(text) > 1200:
                    text = text[:1200] + "\n..."
                cases.append(
                    {
                        "name": name,
                        "classname": classname,
                        "file": file_attr,
                        "kind": kind,
                        "text": text,
                    }
                )
    return (tests, failures, errors, skipped, time, cases)


def generate_reports(
    coverage_json_path: str,
    junit_xml_path: str,
    out_cov: str,
    out_err: str,
    project_root: str,
) -> str:
    try:
        log_info(f"Generating coverage report to: {out_cov}", lang="en")
        log_info(f"Generating error report to: {out_err}", lang="en")
        log_info(f"Coverage JSON source: {coverage_json_path}", lang="en")
        log_info(f"JUnit XML source: {junit_xml_path}", lang="en")
        log_info(f"生成覆盖率报告到: {out_cov}", lang="zh")
        log_info(f"生成错误报告到: {out_err}", lang="zh")
        log_info(f"覆盖率JSON来源: {coverage_json_path}", lang="zh")
        log_info(f"JUnit XML来源: {junit_xml_path}", lang="zh")
    except Exception:
        pass
    cov = _read_json(coverage_json_path)
    junit = _read_xml(junit_xml_path)
    env_info = _get_env_info()

    line_pct, branch_pct, num_lines, num_branches, num_files = _coverage_totals(cov)
    files = _file_entries(cov, project_root)
    top_files = sorted(files, key=lambda x: (x[1] or 0.0), reverse=True)[:10]
    low_files = sorted(files, key=lambda x: (x[1] or 0.0))[:10]

    cov_lines: list[str] = []
    cov_lines.append("# WL 测试覆盖率报告")
    cov_lines.append("")
    cov_lines.append("## 测试环境")
    cov_lines.extend([f"- {x}" for x in env_info])
    cov_lines.append("")
    cov_lines.append("## 总览")
    cov_lines.append(f"- 行覆盖率: {_fmt_pct(line_pct)}")
    cov_lines.append(f"- 分支覆盖率: {_fmt_pct(branch_pct)}")
    cov_lines.append(f"- 语句数: {num_lines if num_lines else 'N/A'}")
    cov_lines.append(f"- 分支数: {num_branches if num_branches else 'N/A'}")
    cov_lines.append(f"- 文件数: {num_files}")
    cov_lines.append("")
    cov_lines.append("## Top 文件")
    for rel, lp, bp in top_files:
        cov_lines.append(f"- `{rel}` | 行 {_fmt_pct(lp)} | 分支 {_fmt_pct(bp)}")
    cov_lines.append("")
    cov_lines.append("## 低覆盖率文件")
    for rel, lp, bp in low_files:
        cov_lines.append(f"- `{rel}` | 行 {_fmt_pct(lp)} | 分支 {_fmt_pct(bp)}")

    _write_md(out_cov, cov_lines)
    try:
        log_info(f"Coverage Markdown written: {out_cov}", lang="en")
        log_info(f"覆盖率Markdown已写入: {out_cov}", lang="zh")
    except Exception:
        pass

    tests, failures, errors, skipped, time_spent, cases = _parse_junit(junit)
    err_lines: list[str] = []
    err_lines.append("# WL 测试错误报告")
    err_lines.append("")
    err_lines.append("## 测试环境")
    err_lines.extend([f"- {x}" for x in env_info])
    err_lines.append("")
    err_lines.append("## 测试统计")
    err_lines.append(f"- 总用例: {tests}")
    err_lines.append(f"- 失败: {failures}")
    err_lines.append(f"- 错误: {errors}")
    err_lines.append(f"- 跳过: {skipped}")
    err_lines.append(f"- 总时长: {time_spent:.2f}s")
    err_lines.append("")
    err_lines.append("## 失败与错误明细")
    for c in cases:
        loc = c.get("file") or c.get("classname") or ""
        err_lines.append(
            f"- 用例: `{c.get('name', '')}` @ `{loc}` [{c.get('kind', '')}]"
        )
        err_lines.append("")
        err_lines.append("```")
        err_lines.append(c.get("text", ""))
        err_lines.append("```")
        err_lines.append("")

    _write_md(out_err, err_lines)
    try:
        log_info(f"Error Markdown written: {out_err}", lang="en")
        log_info(f"错误Markdown已写入: {out_err}", lang="zh")
    except Exception:
        pass

    summary = f"总行覆盖率 {_fmt_pct(line_pct)} | 分支覆盖率 {_fmt_pct(branch_pct)} | 文件数 {num_files} | 失败用例 {failures + errors}"
    return summary
