"""
Test command implementation for wl tool.
"""

import os
import subprocess
import sys
from pathlib import Path
from typing import Any

from ...exceptions import CommandError
from ...utils.logging import log_info
from ...utils.project_root import find_project_root
from ...utils.workspace_detector import WorkspaceDetector
from .. import register_command
from ..base import BaseCommand


@register_command("test")
class TestCommand(BaseCommand):
    """Command to run tests for the project."""

    # Tell pytest not to collect this class as a test class
    __test__ = False

    @property
    def name(self) -> str:
        """Get the command name."""
        return "test"

    @property
    def help(self) -> str:
        """Get the command help text."""
        return "Run project tests"

    def add_arguments(self, parser) -> None:
        """Add command-specific arguments."""
        parser.add_argument(
            "--report",
            action="store_true",
            help="Show detailed test report including verbose output and coverage",
        )
        parser.add_argument(
            "--debug",
            action="store_true",
            help="Run tests in debug mode with verbose output and tracebacks",
        )
        parser.add_argument(
            "args",
            nargs="*",
            help="Additional pytest args (e.g. -k expr)",
        )

    def _build_command_args(
        self, report_mode: bool, args, debug_mode: bool = False
    ) -> list[str]:
        """Build the command arguments for pytest."""
        cmd_args: list[str] = [self._get_python_executable(), "-m", "pytest"]

        # Add verbose flag in report mode or debug mode
        if report_mode or debug_mode:
            cmd_args.append("-v")
            if report_mode:
                cmd_args.append("--tb=short")  # Show shorter tracebacks for failures
            else:
                cmd_args.append("--tb=long")  # Show full tracebacks in debug mode
        else:
            # Default mode - same as python -m pytest --tb=no -q --no-header
            cmd_args.append("--tb=no")  # Don't show tracebacks
            cmd_args.append("-q")  # Quiet mode
            cmd_args.append("--no-header")  # Don't show pytest header

        # Add debug markers if in debug mode
        if debug_mode and "-xvs" not in args:
            cmd_args.extend(
                ["-xvs"]
            )  # Stop at first failure, verbose, show print output

        has_user_cov = any(arg.startswith("--cov") for arg in args)

        # Only add default coverage if no user-defined cov and plugin is available
        if report_mode:
            has_pytest_cov = self._check_pytest_cov()
            if has_pytest_cov and not has_user_cov:
                cmd_args.extend(
                    [
                        "--cov=py_wlcommands",
                        "--cov-branch",
                        "--cov-report=term-missing:skip-covered",
                    ]
                )
            todo_dir = Path(self._get_project_root()) / "todos"
            cov_json = str(todo_dir / "coverage.json")
            junit_xml = str(todo_dir / "junit.xml")
            cmd_args.extend(
                [f"--cov-report=json:{cov_json}", f"--junitxml={junit_xml}"]
            )

        # Add any additional user arguments
        if args:
            # Check if any argument looks like a test file/directory path (doesn't start with --)
            has_path_arg = any(not arg.startswith("--") for arg in args)
            cmd_args.extend(args)

            # Only add default test path if not in report mode and no path arguments provided
            if not report_mode and not has_path_arg:
                cmd_args.append("tests/")
        else:
            # If no args provided, add default test path
            cmd_args.append("tests/")

        return cmd_args

    def _handle_test_result(self, result, report_mode: bool) -> None:
        """
        Handle the test result based on return code.

        Args:
            result: The subprocess result object
            report_mode: Whether we're in report mode
        """
        if result.returncode == 0:
            # Tests passed
            if not report_mode:
                print("All tests passed successfully!")
        else:
            # Tests failed
            if not report_mode:
                # In quiet mode, show the output when tests fail
                if result.stdout:
                    print(result.stdout)
                if result.stderr:
                    print(result.stderr, file=sys.stderr)
                print(f"Tests failed with return code {result.returncode}")
            sys.exit(result.returncode)

    def execute(self, *args: Any, **kwargs: Any) -> None:
        """
        Execute the test command.

        Args:
            *args: Positional arguments (can include pytest arguments like --cov)
            **kwargs: Keyword arguments
        """
        # 显示当前使用的Python环境路径
        python_executable = self._get_python_executable()
        print(f"Running tests using Python environment: {python_executable}")

        report_mode = kwargs.get("report", False)
        debug_mode = kwargs.get("debug", False)

        # 处理特殊情况：如果args中有'debug'，将其移除并设置debug_mode为True
        passed_args = kwargs.get("args", [])
        if "debug" in passed_args:
            passed_args.remove("debug")
            debug_mode = True

        print(f"Debug mode: {debug_mode}")
        self._log_report_mode(report_mode)

        # Run pytest to execute tests
        try:
            project_root = self._get_project_root()
            todo_dir = Path(project_root) / "todos"
            todo_dir.mkdir(exist_ok=True)
            self._log_project_paths(project_root, todo_dir)

            cmd_args = self._build_command_args(report_mode, passed_args, debug_mode)

            env = self._build_env(self._get_project_root())

            if report_mode:
                # In report mode, pass through stdout/stderr to preserve colors and formatting
                result = subprocess.run(
                    cmd_args,
                    cwd=project_root,
                    check=False,
                    env=env,
                )
            else:
                # In quiet mode, also pass through stdout/stderr to preserve colors and formatting
                result = subprocess.run(
                    cmd_args,
                    cwd=project_root,
                    check=False,
                    env=env,
                )

            self._handle_test_result(result, report_mode)

            if report_mode:
                try:
                    from .test_reporter import generate_reports

                    cov_json = str(todo_dir / "coverage.json")
                    junit_xml = str(todo_dir / "junit.xml")
                    cov_md = str(todo_dir / "coverage.md")
                    err_md = str(todo_dir / "error.md")

                    self._log_report_paths(cov_json, junit_xml)

                    summary = generate_reports(
                        coverage_json_path=cov_json,
                        junit_xml_path=junit_xml,
                        out_cov=cov_md,
                        out_err=err_md,
                        project_root=project_root,
                    )

                    self._log_output_paths(cov_md, err_md)

                    if summary:
                        print(summary)

                    self._cleanup_temp_files(cov_json, junit_xml)
                except Exception as e:
                    print(f"Failed to generate markdown reports: {e}")
        except FileNotFoundError:
            print(
                "Error: pytest not found. Please install it using 'pip install pytest'"
            )
            sys.exit(1)
        except Exception as e:
            print(f"Error running tests: {e}")
            sys.exit(1)

    def _log_report_mode(self, report_mode: bool) -> None:
        try:
            log_info(f"Report mode: {report_mode}", lang="en")
            log_info(f"报告模式: {report_mode}", lang="zh")
        except Exception:
            pass

    def _log_project_paths(self, project_root: str, todo_dir: Path) -> None:
        try:
            log_info(f"Project root: {project_root}", lang="en")
            log_info(f"Todos dir: {todo_dir}", lang="en")
            log_info(f"项目根目录: {project_root}", lang="zh")
            log_info(f"报告目录: {todo_dir}", lang="zh")
        except Exception:
            pass

    def _build_env(self, project_root: str) -> dict:
        env = os.environ.copy()
        src_path = os.path.join(project_root, "src")
        if "PYTHONPATH" in env:
            env["PYTHONPATH"] = f"{src_path}{os.pathsep}{env['PYTHONPATH']}"
        else:
            env["PYTHONPATH"] = src_path
        return env

    def _log_report_paths(self, cov_json: str, junit_xml: str) -> None:
        try:
            log_info(f"Coverage JSON path: {cov_json}", lang="en")
            log_info(f"JUnit XML path: {junit_xml}", lang="en")
            log_info(f"Coverage JSON exists: {Path(cov_json).exists()}", lang="en")
            log_info(f"JUnit XML exists: {Path(junit_xml).exists()}", lang="en")
            log_info(f"覆盖率JSON路径: {cov_json}", lang="zh")
            log_info(f"JUnit XML路径: {junit_xml}", lang="zh")
            log_info(f"覆盖率JSON存在: {Path(cov_json).exists()}", lang="zh")
            log_info(f"JUnit XML存在: {Path(junit_xml).exists()}", lang="zh")
        except Exception:
            pass

    def _log_output_paths(self, cov_md: str, err_md: str) -> None:
        try:
            log_info(f"Coverage MD path: {cov_md}", lang="en")
            log_info(f"Error MD path: {err_md}", lang="en")
            log_info(f"Coverage MD exists: {Path(cov_md).exists()}", lang="en")
            log_info(f"Error MD exists: {Path(err_md).exists()}", lang="en")
            log_info(f"覆盖率Markdown路径: {cov_md}", lang="zh")
            log_info(f"错误Markdown路径: {err_md}", lang="zh")
            log_info(f"覆盖率Markdown存在: {Path(cov_md).exists()}", lang="zh")
            log_info(f"错误Markdown存在: {Path(err_md).exists()}", lang="zh")
        except Exception:
            pass

    def _cleanup_temp_files(self, cov_json: str, junit_xml: str) -> None:
        try:
            if Path(cov_json).exists():
                Path(cov_json).unlink(missing_ok=True)
            if Path(junit_xml).exists():
                Path(junit_xml).unlink(missing_ok=True)
        except Exception:
            pass

    def _check_pytest_cov(self) -> bool:
        """
        Check if pytest-cov plugin is available.

        Returns:
            bool: True if pytest-cov is available, False otherwise
        """
        # 使用try-except来检查pytest_cov是否可以导入
        # 这比subprocess调用更高效，也更容易在测试中被mock
        try:
            # 使用__import__函数动态导入，而不是直接使用import语句
            # 这样可以避免导入错误导致的问题
            __import__("pytest_cov")
            return True
        except ImportError:
            # 如果导入失败，返回False
            return False

    def _get_project_root(self) -> str:
        """
        Get the project root directory.

        Returns:
            str: Path to the project root directory
        """
        try:
            cwd = Path.cwd()
            if (cwd / "tests").exists() or (cwd / "src").exists():
                return str(cwd)
            root = find_project_root()
            return str(root)
        except Exception:
            return os.getcwd()

    def _get_python_executable(self) -> str:
        """
        Get the Python executable path, using the same logic as wl build dist.

        Returns:
            str: Path to the Python executable
        """
        try:
            detector = WorkspaceDetector()
            python_exe, _ = self._resolve_python(detector)
            return python_exe or sys.executable
        except Exception:
            # 如果出现问题，回退到系统Python
            return sys.executable

    def _resolve_python(self, detector: WorkspaceDetector) -> tuple[str | None, bool]:
        """
        Resolve Python executable path, with enhanced virtual environment detection.

        Args:
            detector: WorkspaceDetector instance

        Returns:
            tuple: (python_path, is_virtual_env)
        """
        # 1. 检查是否在uv工作区环境中
        is_workspace = detector.detect(Path.cwd())
        print(f"Debug: uv workspace detected: {is_workspace}")

        # 如果不在工作区，直接返回python命令
        if not is_workspace:
            return "python", False

        # 2. 尝试通过不同方式查找虚拟环境中的Python
        python_path = self._find_python_in_uv_workspace(detector)
        if python_path:
            return python_path, True

        python_path = self._find_python_in_custom_venv()
        if python_path:
            return python_path, True

        python_path = self._find_python_in_environment_venv()
        if python_path:
            return python_path, True

        # 3. 最后回退到系统Python
        print(f"Debug: Falling back to system Python: {sys.executable}")
        return sys.executable, False

    def _find_python_in_uv_workspace(self, detector: WorkspaceDetector) -> str | None:
        """查找uv工作区中的Python可执行文件。"""
        venv_root = detector.get_venv_path(Path.cwd())
        if not venv_root:
            return None

        print(f"Debug: get_venv_path result: {venv_root}")

        # 尝试标准Python路径
        python_exe = self._get_python_path_from_venv(venv_root)
        if self._is_valid_python_executable(python_exe):
            return python_exe

        # 尝试python3路径
        if not sys.platform.startswith("win"):
            python_exe_alt = str((venv_root / "bin" / "python3").absolute())
            if self._is_valid_python_executable(python_exe_alt):
                return python_exe_alt

        # 尝试使用uv run
        return self._get_python_using_uv_run()

    def _find_python_in_custom_venv(self) -> str | None:
        """使用_find_venv方法查找Python。"""
        venv_path = self._find_venv()
        if not venv_path:
            return None

        venv_root = Path(venv_path)
        print(f"Debug: Found venv using _find_venv: {venv_root}")

        python_exe = self._get_python_path_from_venv(venv_root)
        if self._is_valid_python_executable(python_exe):
            return python_exe

        return None

    def _find_python_in_environment_venv(self) -> str | None:
        """通过VIRTUAL_ENV环境变量查找Python。"""
        virtual_env = os.environ.get("VIRTUAL_ENV")
        if not virtual_env:
            return None

        venv_root = Path(virtual_env)
        print(f"Debug: Using VIRTUAL_ENV: {venv_root}")

        python_exe = self._get_python_path_from_venv(venv_root)
        if self._is_valid_python_executable(python_exe):
            return python_exe

        return None

    def _get_python_path_from_venv(self, venv_root: Path) -> str:
        """从虚拟环境根目录构造Python可执行文件路径。"""
        if sys.platform.startswith("win"):
            return str((venv_root / "Scripts" / "python.exe").absolute())
        else:
            return str((venv_root / "bin" / "python").absolute())

    def _is_valid_python_executable(self, python_path: str) -> bool:
        """检查Python可执行文件是否存在。"""
        print(f"Debug: Checking Python executable at: {python_path}")
        if Path(python_path).exists():
            print(f"Debug: Successfully found Python executable: {python_path}")
            return True
        print(f"Debug: Python executable does not exist at: {python_path}")
        return False

    def _get_python_using_uv_run(self) -> str | None:
        """使用uv run获取Python可执行文件路径。"""
        try:
            result = subprocess.run(
                [
                    "uv",
                    "run",
                    "python",
                    "-c",
                    "import sys; print(sys.executable)",
                ],
                capture_output=True,
                text=True,
                check=True,
            )
            uv_python = result.stdout.strip()
            print(f"Debug: Using uv run python result: {uv_python}")
            if Path(uv_python).exists():
                return uv_python
        except Exception as e:
            print(f"Debug: uv run python failed: {e}")
        return None

    def _find_venv(self) -> str | None:
        """
        Find virtual environment path if it exists.

        Returns:
            str | None: Path to virtual environment or None if not found
        """
        project_root = self._get_project_root()

        # Check common virtual environment locations
        possible_venv_paths = [
            os.path.join(project_root, ".venv"),
            os.path.join(project_root, "venv"),
        ]

        for venv_path in possible_venv_paths:
            if os.path.exists(os.path.join(venv_path, "pyvenv.cfg")):
                return venv_path

        return None
