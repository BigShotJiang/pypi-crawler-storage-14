from ....utils.logging import log_info as log_info
from .exceptions import GitInitializationError as GitInitializationError
from .log_manager import performance_monitor as performance_monitor
from _typeshed import Incomplete

class GitInitializer:
    env: Incomplete
    def __init__(self, env: dict[str, str]) -> None: ...
    @performance_monitor
    def initialize(self) -> None: ...
