from .logging import log_error as log_error, log_info as log_info
from .subprocess_utils import SubprocessExecutor as SubprocessExecutor
from dataclasses import dataclass
from pathlib import Path
from typing import TypedDict

class WorkspaceDetectionError(Exception):
    def __init__(self, message: str) -> None: ...

class WorkspaceDetectionRules(TypedDict, total=False):
    use_pyproject: bool
    use_uv_lock: bool
    use_uv_init: bool
    use_uv_tree: bool
    uv_tree_min_roots: int
    cwd: str

@dataclass
class ValidationResult:
    valid: bool
    details: dict[str, str]

class WorkspaceDetector:
    def __init__(self, rules: WorkspaceDetectionRules | None = None) -> None: ...
    def detect(self, project_root: Path | None = None) -> bool: ...
    def validate(self, project_root: Path | None = None) -> ValidationResult: ...
    def get_config(self) -> WorkspaceDetectionRules: ...
    def resolve_path(self, path: str | Path, project_root: Path | None = None) -> Path: ...
    def get_venv_path(self, project_root: Path | None = None) -> Path | None: ...
    def get_active_venv_path_str(self, project_root: Path | None = None) -> str: ...
