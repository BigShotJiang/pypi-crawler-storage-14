"""Test script with compute_d2J=False"""
import sys
import os
sys.path.insert(0, '../..')
from test_compute_dJdx import compute_dJdx_from_exchanges, load_exchange

print("Testing with compute_d2J=False (skips J_0 computation)...")

# Use available test data
base_path = 'FD_spinphon_results_0.001_k333_nocenter/idisp0_Ru0_0_0'
neg = load_exchange(os.path.join(base_path, 'negative/TB2J.pickle'))
pos = load_exchange(os.path.join(base_path, 'positive/TB2J.pickle'))

# Note: passing orig=None when compute_d2J=False
compute_dJdx_from_exchanges(None, neg, pos, 0.001, 'test_no_d2j_output', compute_d2J=False)

print("\nFirst 12 lines of output:")
with open('test_no_d2j_output/exchange.out', 'r') as f:
    for i, line in enumerate(f):
        if i < 12:
            print(line.rstrip())

print("\nChecking number of columns:")
with open('test_no_d2j_output/exchange.out', 'r') as f:
    for line in f:
        if not line.startswith('#'):
            parts = line.split()
            print(f"Found {len(parts)} columns (expected 12: no J_0, no d2J/dx2)")
            break

print("\nTest completed!")
