"""Test script with compute_d2J=True (default)"""
import sys
sys.path.insert(0, '../..')
from test_compute_dJdx import compute_dJdx_from_exchanges, load_exchange

print("Testing with compute_d2J=True (default)...")

orig = load_exchange('FD_spinphon_results_222/original/TB2J.pickle')
neg = load_exchange('FD_spinphon_results_222/negative/TB2J.pickle')
pos = load_exchange('FD_spinphon_results_222/positive/TB2J.pickle')

compute_dJdx_from_exchanges(orig, neg, pos, 0.01, 'test_with_d2j_output')

print("\nFirst 12 lines of output:")
with open('test_with_d2j_output/exchange.out', 'r') as f:
    for i, line in enumerate(f):
        if i < 12:
            print(line.rstrip())

print("\nChecking number of columns:")
with open('test_with_d2j_output/exchange.out', 'r') as f:
    for line in f:
        if not line.startswith('#'):
            parts = line.split()
            print(f"Found {len(parts)} columns (expected 14 with d2J)")
            break

print("\nTest completed!")
