"""
Test script for compute_dJdx_from_exchanges function with distance-based sorting.

PURPOSE:
    Tests the compute_dJdx_from_exchanges function using existing exchange data
    from FD_spinphon_results to verify:
    1. Distance-based sorting works correctly
    2. Output format matches TB2J exchange output order
    3. dJ/dx and d²J/dx² values are reasonable

USAGE:
    uv run python agent_files/debug_spinphon_fd/test_compute_dJdx.py

EXPECTED OUTPUT:
    Creates dJdx/exchange.out with sorted exchange interactions by distance
    and prints verification information.

FILES USED:
    - FD_spinphon_results/original/TB2J.pickle
    - FD_spinphon_results/negative/TB2J.pickle
    - FD_spinphon_results/positive/TB2J.pickle

DEBUG NOTES:
    - Uses pickle.load to read existing ExchangeNCL objects
    - Does not require supercellmap module
    - Tests only the derivative computation and output formatting
"""

import os
import pickle


def load_exchange(pickle_path):
    """Load exchange object from pickle file."""
    with open(pickle_path, "rb") as f:
        return pickle.load(f)


def compute_dJdx_from_exchanges(
    exchange_orig, exchange_neg, exchange_pos, amplitude, output_path, compute_d2J=True
):
    """
    Compute dJ/dx and optionally d²J/dx² from exchanges at three positions using finite difference.

    Args:
        exchange_orig: Exchange dict at zero displacement (can be None if compute_d2J=False)
        exchange_neg: Exchange dict at -amplitude
        exchange_pos: Exchange dict at +amplitude
        amplitude: Displacement amplitude in Angstrom
        output_path: Directory to save dJdx results
        compute_d2J: Whether to compute second derivative (default=True)
    """
    os.makedirs(output_path, exist_ok=True)

    # Extract isotropic exchange values (dict already contains the data)
    Jiso_orig = exchange_orig["exchange_Jdict"] if exchange_orig is not None else None
    Jiso_neg = exchange_neg["exchange_Jdict"]
    Jiso_pos = exchange_pos["exchange_Jdict"]

    # Get distance information (use neg or pos if orig not available)
    if exchange_orig is not None:
        distance_dict = exchange_orig["distance_dict"]
    else:
        distance_dict = exchange_neg["distance_dict"]

    # Compute first derivative: dJ/dx = (J_pos - J_neg) / (2*dx)
    # Note: multiply by 1e3 to convert from eV/A to meV/A
    dJiso_dx = {}
    keys_to_use = Jiso_orig.keys() if Jiso_orig is not None else Jiso_neg.keys()
    for key in keys_to_use:
        if key in Jiso_pos and key in Jiso_neg:
            dJiso_dx[key] = (Jiso_pos[key] - Jiso_neg[key]) / (2.0 * amplitude) * 1e3

    # Compute second derivative: d²J/dx² = (J_pos - 2*J_orig + J_neg) / (dx²)
    # Note: multiply by 1e3 to convert from eV/A² to meV/A²
    d2Jiso_dx2 = {}
    if compute_d2J and Jiso_orig is not None:
        for key in Jiso_orig.keys():
            if key in Jiso_pos and key in Jiso_neg:
                d2Jiso_dx2[key] = (
                    (Jiso_pos[key] - 2.0 * Jiso_orig[key] + Jiso_neg[key])
                    / (amplitude**2)
                    * 1e3
                )

    # Sort keys by first atom index (ispin), then by distance
    sorted_keys = sorted(dJiso_dx.keys(), key=lambda x: (x[1], distance_dict[x][1]))

    # Save results in text format (sorted by ispin then distance)
    output_file = os.path.join(output_path, "exchange.out")
    with open(output_file, "w") as f:
        if compute_d2J:
            f.write(
                "# Derivatives of isotropic exchange computed from finite difference\n"
            )
        else:
            f.write(
                "# First derivative of isotropic exchange computed from finite difference\n"
            )
        f.write(f"# dJ/dx = (J(+{amplitude}) - J(-{amplitude})) / (2*{amplitude})\n")
        if compute_d2J:
            f.write(
                f"# d²J/dx² = (J(+{amplitude}) - 2*J(0) + J(-{amplitude})) / ({amplitude}²)\n"
            )
        if compute_d2J:
            f.write(
                "# Units: J in meV, distances in Angstrom, dJ/dx in meV/Angstrom, d²J/dx² in meV/Angstrom²\n"
            )
        else:
            f.write("# Units: J in meV, distances in Angstrom, dJ/dx in meV/Angstrom\n")
        f.write("# Sorted by: first atom index (ispin), then by distance\n")
        if compute_d2J and Jiso_orig is not None:
            f.write(
                "# ispin jspin Rx Ry Rz distance(A) dx(A) dy(A) dz(A) J_0(meV) J_neg(meV) J_pos(meV) dJ/dx d2J/dx2\n"
            )
        elif Jiso_orig is None:
            if compute_d2J:
                f.write(
                    "# ispin jspin Rx Ry Rz distance(A) dx(A) dy(A) dz(A) J_neg(meV) J_pos(meV) dJ/dx d2J/dx2\n"
                )
            else:
                f.write(
                    "# ispin jspin Rx Ry Rz distance(A) dx(A) dy(A) dz(A) J_neg(meV) J_pos(meV) dJ/dx\n"
                )
        else:
            f.write(
                "# ispin jspin Rx Ry Rz distance(A) dx(A) dy(A) dz(A) J_0(meV) J_neg(meV) J_pos(meV) dJ/dx\n"
            )

        for key in sorted_keys:
            R, ispin, jspin = key
            Rx, Ry, Rz = R

            # Get distance vector and norm
            vec, distance = distance_dict[key]

            # Get J values (convert from eV to meV)
            Jneg = Jiso_neg[key] * 1e3
            Jpos = Jiso_pos[key] * 1e3

            # Write output line
            line = (
                f"{ispin:3d} {jspin:3d} {Rx:3d} {Ry:3d} {Rz:3d} "
                f"{distance:12.8f} {vec[0]:10.6f} {vec[1]:10.6f} {vec[2]:10.6f} "
            )
            if Jiso_orig is not None:
                J0 = Jiso_orig[key] * 1e3
                line += f"{J0:16.8f} "
            line += f"{Jneg:16.8f} {Jpos:16.8f} {dJiso_dx[key]:16.8f}"
            if compute_d2J and key in d2Jiso_dx2:
                line += f" {d2Jiso_dx2[key]:16.8f}"
            line += "\n"
            f.write(line)

    # Save in pickle format
    pickle_file = os.path.join(output_path, "dJdx.pickle")
    results = {
        "dJiso_dx": dJiso_dx,
        "Jiso_neg": Jiso_neg,
        "Jiso_pos": Jiso_pos,
        "amplitude": amplitude,
    }
    if Jiso_orig is not None:
        results["Jiso_orig"] = Jiso_orig
    if compute_d2J:
        results["d2Jiso_dx2"] = d2Jiso_dx2

    with open(pickle_file, "wb") as f:
        pickle.dump(results, f)

    print("Results saved to:")
    print(f"  {output_file}")
    print(f"  {pickle_file}")
    print(f"\nNumber of exchange interactions: {len(dJiso_dx)}")


def main():
    """Test compute_dJdx_from_exchanges with existing data."""

    # Define paths
    results_dir = "FD_spinphon_results"
    orig_pickle = os.path.join(results_dir, "original", "TB2J.pickle")
    neg_pickle = os.path.join(results_dir, "negative", "TB2J.pickle")
    pos_pickle = os.path.join(results_dir, "positive", "TB2J.pickle")
    dJdx_dir = os.path.join(results_dir, "dJdx")

    print("=" * 80)
    print("Testing compute_dJdx_from_exchanges with distance-based sorting")
    print("=" * 80)

    # Load exchange objects
    print("\nLoading exchange data...")
    print(f"  Original: {orig_pickle}")
    print(f"  Negative: {neg_pickle}")
    print(f"  Positive: {pos_pickle}")

    exchange_orig = load_exchange(orig_pickle)
    exchange_neg = load_exchange(neg_pickle)
    exchange_pos = load_exchange(pos_pickle)

    print("\nExchange objects loaded successfully!")
    print(f"  Original has {len(exchange_orig['exchange_Jdict'])} interactions")
    print(f"  Negative has {len(exchange_neg['exchange_Jdict'])} interactions")
    print(f"  Positive has {len(exchange_pos['exchange_Jdict'])} interactions")

    # Compute derivatives
    amplitude = 0.01  # Angstrom
    print(f"\nComputing dJ/dx with amplitude = {amplitude} Angstrom...")

    compute_dJdx_from_exchanges(
        exchange_orig, exchange_neg, exchange_pos, amplitude, dJdx_dir
    )

    # Read and display first few lines of output
    output_file = os.path.join(dJdx_dir, "exchange.out")
    print("\n" + "=" * 80)
    print("First 10 lines of output (sorted by distance):")
    print("=" * 80)

    with open(output_file, "r") as f:
        lines = f.readlines()
        for i, line in enumerate(lines[:15]):  # Show header + first 10 data lines
            print(line.rstrip())

    # Verify manual calculation for first non-header line
    print("\n" + "=" * 80)
    print("Manual verification of first interaction:")
    print("=" * 80)

    # Find first data line
    with open(output_file, "r") as f:
        for line in f:
            if not line.startswith("#"):
                parts = line.split()
                if len(parts) == 14:  # Updated: now has distance vector components
                    ispin, jspin, Rx, Ry, Rz = map(int, parts[:5])
                    distance, dx, dy, dz, J0, Jneg, Jpos, dJdx, d2Jdx2 = map(
                        float, parts[5:]
                    )

                    print(
                        f"Interaction: ispin={ispin}, jspin={jspin}, R=({Rx},{Ry},{Rz})"
                    )
                    print(f"Distance: {distance:.8f} Å")
                    print(f"Distance vector: ({dx:.8f}, {dy:.8f}, {dz:.8f}) Å")
                    print(f"J(0) = {J0:.8f} meV")
                    print(f"J(-dx) = {Jneg:.8f} meV")
                    print(f"J(+dx) = {Jpos:.8f} meV")
                    print(f"\nComputed dJ/dx = {dJdx:.8f} meV/Å")

                    # Manual calculation
                    manual_dJdx = (Jpos - Jneg) / (2.0 * amplitude)
                    print(f"Manual dJ/dx = (J(+dx) - J(-dx)) / (2*{amplitude})")
                    print(f"             = ({Jpos:.8f} - {Jneg:.8f}) / {2*amplitude}")
                    print(f"             = {manual_dJdx:.8f} meV/Å")

                    if abs(dJdx - manual_dJdx) < 1e-6:
                        print("\n✓ Manual calculation matches!")
                    else:
                        print(
                            f"\n✗ Manual calculation differs by {abs(dJdx - manual_dJdx):.2e}"
                        )

                    break

    print("\n" + "=" * 80)
    print("Test completed successfully!")
    print("=" * 80)


if __name__ == "__main__":
    main()
