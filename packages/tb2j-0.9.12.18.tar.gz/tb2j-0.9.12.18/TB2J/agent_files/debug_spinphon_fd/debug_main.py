"""
Debug script for spin-phonon coupling using double-sided finite difference method.

PURPOSE:
    This script uses the double-sided finite difference method from Oiju_FD2.py to
    calculate spin-phonon coupling parameters and their derivatives dJ/dx. It computes
    exchange parameters at both positive and negative displacements, then calculates
    dJ/dx = (J(+dx) - J(-dx)) / (2*dx).

USAGE:
    uv run python agent_files/debug_spinphon_fd/debug_main.py

EXPECTED OUTPUT:
    The script will create output directories with subdirectories:
    - original/: Exchange parameters at zero displacement (only if compute_d2J=True)
    - negative/: Exchange parameters at -amplitude displacement
    - positive/: Exchange parameters at +amplitude displacement
    - dJdx/: Computed derivatives dJ/dx in both text and pickle formats

PERFORMANCE OPTIONS:
    - compute_d2J: Set False to skip J(0) calculation and d2J/dx2 (~33% faster)
    - ispin0_only: Set True to only compute pairs with ispin=0 or jspin=0 (~93% faster)
    - Combined: ~95% reduction in computation time!

FILES USED:
    - Oiju_FD2.py: Source of double-sided finite difference implementation
    - Oiju_epw2.py: Reference for data path structure and interface

DEBUG NOTES:
    - Uses double-sided finite difference for better numerical accuracy
    - Computes full exchange tensor derivatives including DMI components
    - Results include isotropic, anisotropic, and DMI contributions to dJ/dx
    - Default settings use both optimizations for maximum speed
"""


# Add the TB2J directory to the Python path
# sys.path.insert(0, '/home_phythema/hexu/projects/TB2J/TB2J')

import numpy as np

from TB2J.Oiju_FD2 import gen_exchange_Oiju_FD_double_sided


def main():
    """Main function to run spin-phonon coupling calculation using double-sided finite difference method."""

    # Use the same data path structure as Oiju_epw2.py
    path = "/home_phythema/hexu/spinphon/2025-10-02_newdata/k555q555"
    nsc=2
    nkpt = 5


    # Configuration parameters matching Oiju_epw2.py example
    config = {
        "path": path,
        "colinear": True,
        "posfile": "scf.pwi",
        "prefix_up": "up/SrMnO3",
        "prefix_dn": "down/SrMnO3.down",
        "prefix_SOC": "wannier90",
        "epw_up_path": f"{path}/up",
        "epw_down_path": f"{path}/down",
        "epw_prefix_up": "epmat",
        "epw_prefix_dn": "epmat",
        "Ru": (0, 0, 0),
        "Rcut": 5,
        "efermi": 11.26,
        "magnetic_elements": ["Mn"],
        "kmesh": [3, 3, 3],
        "emin": -7.3363330034071295,
        "emax": 0.0,
        "nz": 70,
        "np": 1,
        "exclude_orbs": [],
        "description": "Double-sided finite difference calculation for dJ/dx",
        "list_iatom": None,
        "output_path": f"FD_spinphon_results_sc{nsc}_k{nkpt}",
        # Additional parameters for finite difference method
        "supercell_matrix": np.eye(3, dtype=int)*nsc,
        "amplitude": 0.003,
        "max_distance": None,
        # Performance optimization options
        "compute_d2J": False,      # Set True to compute second derivative d2J/dx2
        "ispin0_only": True,       # Set True to only compute pairs with ispin=0 or jspin=0
    }

    # Run calculation for a single displacement pattern (idisp=0)
    # You can modify this to loop over multiple displacement patterns
    displacement_patterns = [5, 6, 8, 0]  # Change to range(15) for all patterns

    print("=" * 80)
    print("Starting double-sided finite difference spin-phonon coupling calculation")
    print("=" * 80)
    print(f"Data path: {path}")
    print(f"Output path: {config['output_path']}")
    print(f"Displacement patterns: {displacement_patterns}")
    print(f"Amplitude: {config['amplitude']}")
    print(
        f"Method: dJ/dx = (J(+{config['amplitude']}) - J(-{config['amplitude']})) / (2*{config['amplitude']})"
    )
    print("\nPerformance optimizations:")
    print(f"  - compute_d2J: {config['compute_d2J']} {'(computes d2J/dx2)' if config['compute_d2J'] else '(skips J(0) calculation, ~33% faster)'}")
    print(f"  - ispin0_only: {config['ispin0_only']} {'(only pairs with ispin=0 or jspin=0, ~93% faster)' if config['ispin0_only'] else '(all pairs)'}")
    if not config['compute_d2J'] and config['ispin0_only']:
        print(f"  - Combined speedup: ~95% reduction in computation time!")
    print("=" * 80)

    for idisp in displacement_patterns:
        print(f"\n{'='*80}")
        print(f"Processing displacement pattern {idisp}")
        print(f"{'='*80}")

        try:
            gen_exchange_Oiju_FD_double_sided(idisp=idisp, **config)
            print(f"\n{'='*80}")
            print(f"Successfully completed displacement pattern {idisp}")
            print("Results saved in:")
            if config['compute_d2J']:
                print(f"  - {config['output_path']}/idisp{idisp}_Ru{config['Ru'][0]}_{config['Ru'][1]}_{config['Ru'][2]}/original/")
            print(f"  - {config['output_path']}/idisp{idisp}_Ru{config['Ru'][0]}_{config['Ru'][1]}_{config['Ru'][2]}/negative/")
            print(f"  - {config['output_path']}/idisp{idisp}_Ru{config['Ru'][0]}_{config['Ru'][1]}_{config['Ru'][2]}/positive/")
            print(f"  - {config['output_path']}/idisp{idisp}_Ru{config['Ru'][0]}_{config['Ru'][1]}_{config['Ru'][2]}/dJdx/")
            print(f"{'='*80}")

        except Exception as e:
            print(f"\nError processing displacement pattern {idisp}: {e}")
            import traceback

            traceback.print_exc()

    print("\n" + "=" * 80)
    print("Calculation completed!")
    print("=" * 80)
    print("Results structure:")
    print(f"  {config['output_path']}/")
    print(f"  └── idisp{{N}}_Ru{{X}}_{{Y}}_{{Z}}/")
    if config['compute_d2J']:
        print("      ├── original/         # Exchange at zero displacement")
    print("      ├── negative/         # Exchange at -amplitude")
    print("      ├── positive/         # Exchange at +amplitude")
    print("      └── dJdx/             # Computed dJ/dx derivatives")
    print("          ├── exchange.out  # Human-readable format")
    print("          └── dJdx.pickle   # Python dictionary format")
    print("\nOutput format:")
    if config['compute_d2J']:
        print("  - 14 columns: includes J_0, J_neg, J_pos, dJ/dx, d2J/dx2")
    else:
        print("  - 12 columns: includes J_neg, J_pos, dJ/dx (no J_0, no d2J/dx2)")
    if config['ispin0_only']:
        print("  - Only pairs with ispin=0 or jspin=0 included")
    print("=" * 80)


if __name__ == "__main__":
    main()
