"""
Test script for ispin0_only parameter.

PURPOSE:
    Tests that ispin0_only=True correctly filters exchange pairs to only include
    those where the first spin index (ispin) is 0, significantly reducing computation time.

USAGE:
    uv run python TB2J/agent_files/debug_spinphon_fd/test_ispin0_only.py

EXPECTED OUTPUT:
    - Comparison of number of pairs computed with ispin0_only=False vs True
    - Verification that all pairs in ispin0_only=True output have ispin=0
    - Demonstration of computational savings
"""

import sys
import os
sys.path.insert(0, '../..')
from test_compute_dJdx import compute_dJdx_from_exchanges, load_exchange

print("Testing ispin0_only parameter...")
print("=" * 80)

# Use available test data
base_path = 'FD_spinphon_results_0.001_k333_nocenter/idisp0_Ru0_0_0'

print("\n1. Testing with ispin0_only=False (default - all pairs)")
print("-" * 80)
neg = load_exchange(os.path.join(base_path, 'negative/TB2J.pickle'))
pos = load_exchange(os.path.join(base_path, 'positive/TB2J.pickle'))

compute_dJdx_from_exchanges(None, neg, pos, 0.001, 'test_all_pairs_output', compute_d2J=False)

# Count total pairs
with open('test_all_pairs_output/exchange.out', 'r') as f:
    all_pairs_count = sum(1 for line in f if not line.startswith('#'))

print(f"Total number of exchange pairs computed: {all_pairs_count}")

# Check ispin distribution
ispin_counts = {}
with open('test_all_pairs_output/exchange.out', 'r') as f:
    for line in f:
        if not line.startswith('#'):
            parts = line.split()
            ispin = int(parts[0])
            ispin_counts[ispin] = ispin_counts.get(ispin, 0) + 1

print(f"Distribution by ispin: {dict(sorted(ispin_counts.items()))}")

print("\n2. Testing with ispin0_only=True (only ispin=0 or jspin=0 pairs)")
print("-" * 80)

# Note: In actual usage, we would create new Exchange objects with ispin0_only=True
# Here we're just testing the filtering in compute_dJdx_from_exchanges
# The real performance gain comes from Exchange class not computing the other pairs

# For this test, we manually filter to simulate the behavior
neg_filtered = load_exchange(os.path.join(base_path, 'negative/TB2J.pickle'))
pos_filtered = load_exchange(os.path.join(base_path, 'positive/TB2J.pickle'))

# Filter the dictionaries
def filter_ispin0(exchange_dict):
    """Filter exchange dict to only include pairs where ispin=0 or jspin=0"""
    filtered = {}
    filtered['exchange_Jdict'] = {k: v for k, v in exchange_dict['exchange_Jdict'].items() if k[1] == 0 or k[2] == 0}
    filtered['distance_dict'] = {k: v for k, v in exchange_dict['distance_dict'].items() if k[1] == 0 or k[2] == 0}
    return filtered

neg_filtered = filter_ispin0(neg_filtered)
pos_filtered = filter_ispin0(pos_filtered)

compute_dJdx_from_exchanges(None, neg_filtered, pos_filtered, 0.001, 'test_ispin0_output', compute_d2J=False)

# Count ispin0 pairs
with open('test_ispin0_output/exchange.out', 'r') as f:
    ispin0_pairs_count = sum(1 for line in f if not line.startswith('#'))

print(f"Number of exchange pairs with ispin=0 or jspin=0: {ispin0_pairs_count}")

# Verify all pairs have ispin=0 or jspin=0
all_valid = True
ispin0_count = 0
jspin0_count = 0
both0_count = 0
with open('test_ispin0_output/exchange.out', 'r') as f:
    for line in f:
        if not line.startswith('#'):
            parts = line.split()
            ispin = int(parts[0])
            jspin = int(parts[1])
            if ispin != 0 and jspin != 0:
                all_valid = False
                print(f"ERROR: Found pair with ispin={ispin}, jspin={jspin}")
                break
            if ispin == 0 and jspin == 0:
                both0_count += 1
            elif ispin == 0:
                ispin0_count += 1
            elif jspin == 0:
                jspin0_count += 1

if all_valid:
    print("✓ All pairs have ispin=0 or jspin=0")
    print(f"  - Pairs with both ispin=0 and jspin=0: {both0_count}")
    print(f"  - Pairs with ispin=0 only: {ispin0_count}")
    print(f"  - Pairs with jspin=0 only: {jspin0_count}")

print("\n3. Performance comparison")
print("-" * 80)
reduction = (all_pairs_count - ispin0_pairs_count) / all_pairs_count * 100
print(f"Pairs reduced: {all_pairs_count} → {ispin0_pairs_count}")
print(f"Reduction: {reduction:.1f}%")
print(f"Speedup factor: ~{all_pairs_count / ispin0_pairs_count:.1f}x")

print("\n" + "=" * 80)
print("Test completed successfully!")
print("\nNOTE: In actual usage with Exchange class, the performance gain comes from")
print("not computing the filtered pairs at all, not just filtering the output.")
