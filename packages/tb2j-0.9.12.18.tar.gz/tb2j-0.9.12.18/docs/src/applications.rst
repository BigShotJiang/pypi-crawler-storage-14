Applications
*********************************************
.. toctree::
   :maxdepth: 2
   :caption: Contents:

   magnon_band.rst
   multibinit.rst
   eigen.rst
