"""Fill event structure."""

from dataclasses import dataclass
from ..core.enums import OrderSide
from ..core.types import Money, Price, Quantity, TimestampMs
from ..core.exceptions import ValidationError
from ..utils.validation import (
    ensure_valid_money,
    ensure_valid_price,
    ensure_valid_quantity,
    ensure_valid_timestamp,
    sanitize_instrument_id,
)


@dataclass(frozen=True)
class Fill:
    order_id: str
    instrument_id: str
    side: OrderSide
    quantity: Quantity
    price: Price
    fee: Money
    timestamp_ms: TimestampMs

    def __post_init__(self) -> None:
        if not self.order_id or not self.order_id.strip():
            raise ValidationError("order_id cannot be empty")

        instrument_id = sanitize_instrument_id(self.instrument_id)
        object.__setattr__(self, "instrument_id", instrument_id)

        ensure_valid_quantity(self.quantity, "quantity")
        ensure_valid_price(self.price, "price")
        ensure_valid_money(self.fee, "fee")
        ensure_valid_timestamp(self.timestamp_ms, "timestamp_ms")
