"""Percent-of-equity sizing."""

from __future__ import annotations

from decimal import Decimal
from ..core.types import Money, Price, Quantity


def percent_of_equity(equity: Money, percent: Decimal, price: Price) -> Quantity:
    if price == 0:
        raise ZeroDivisionError("price must be non-zero")
    return (Decimal(equity) * Decimal(percent)) / Decimal(price)
