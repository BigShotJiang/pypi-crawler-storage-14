__version__ = "0.1.0"

from .math.precision import ctx as decimal_context
from .config import get_config, set_config, QuantcoreConfig
from .health import check_health
from .bootstrap import init_quantcore

__all__ = [
    "decimal_context",
    "get_config",
    "set_config",
    "QuantcoreConfig",
    "check_health",
    "init_quantcore",
]
