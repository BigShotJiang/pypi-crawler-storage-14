"""Futures position implementation."""

from __future__ import annotations

from dataclasses import dataclass
from .base import BasePositionImpl


@dataclass(frozen=True)
class FuturesPosition(BasePositionImpl):
    """Standard futures positions built on the base implementation."""

    pass
