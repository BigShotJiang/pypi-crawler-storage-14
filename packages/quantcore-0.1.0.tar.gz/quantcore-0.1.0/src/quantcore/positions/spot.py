"""Spot position implementation."""

from __future__ import annotations

from dataclasses import dataclass
from .base import BasePositionImpl


@dataclass(frozen=True)
class SpotPosition(BasePositionImpl):
    """Spot positions reuse the generic BasePositionImpl behavior."""

    pass
