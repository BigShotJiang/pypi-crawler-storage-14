"""Return calculation utilities."""

from __future__ import annotations

from decimal import Decimal
from typing import Iterable


def simple_return(current: Decimal, previous: Decimal) -> Decimal:
    """Calculate simple return (current / previous - 1)."""
    if previous == 0:
        raise ZeroDivisionError("previous value must be non-zero")
    return (Decimal(current) / Decimal(previous)) - Decimal(1)


def log_return(current: Decimal, previous: Decimal) -> Decimal:
    """Calculate log return ln(current / previous)."""
    if previous == 0:
        raise ZeroDivisionError("previous value must be non-zero")
    ratio = Decimal(current) / Decimal(previous)
    if ratio <= 0:
        raise ValueError("log return requires positive ratio")
    return ratio.ln()


def cumulative_return(returns: Iterable[Decimal]) -> Decimal:
    """Aggregate multiple period returns into a cumulative return."""
    total = Decimal(1)
    for r in returns:
        total *= Decimal(1) + Decimal(r)
    return total - Decimal(1)
