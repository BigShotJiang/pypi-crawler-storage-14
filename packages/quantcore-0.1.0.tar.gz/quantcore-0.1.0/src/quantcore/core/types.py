"""Core type aliases for quantcore."""

from decimal import Decimal
from typing import NewType

Money = Decimal
Price = Decimal
Quantity = Decimal
Rate = Decimal
TimestampMs = NewType("TimestampMs", int)
