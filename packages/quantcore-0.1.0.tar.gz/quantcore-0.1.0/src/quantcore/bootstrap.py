from __future__ import annotations

import logging
import os
import sys
from typing import Literal

from .config import QuantcoreConfig, set_config, get_config
from .health import check_health
from .utils.logging import get_logger

logger = get_logger(__name__)

EnvName = Literal["development", "production", "testing"]


def _build_config(env: EnvName) -> QuantcoreConfig:
    """Create a QuantcoreConfig for the given environment, with env overrides."""
    if env == "development":
        config = QuantcoreConfig.development()
    elif env == "testing":
        config = QuantcoreConfig.testing()
    else:
        # default to production
        config = QuantcoreConfig.production()

    # Overlay environment-specific overrides only when explicitly provided
    overrides = {}
    env_decimal_precision = os.getenv("QUANTCORE_DECIMAL_PRECISION")
    if env_decimal_precision is not None:
        overrides["decimal_precision"] = int(env_decimal_precision)

    env_base_currency = os.getenv("QUANTCORE_BASE_CURRENCY")
    if env_base_currency is not None:
        overrides["base_currency"] = env_base_currency

    env_log_level = os.getenv("QUANTCORE_LOG_LEVEL")
    if env_log_level is not None:
        overrides["log_level"] = env_log_level

    env_strict_validation = os.getenv("QUANTCORE_STRICT_VALIDATION")
    if env_strict_validation is not None:
        overrides["strict_validation"] = env_strict_validation.lower() == "true"

    if overrides:
        config.override(**overrides)
    return config


def _validate_or_exit(config: QuantcoreConfig) -> None:
    """Validate config and exit the process on error."""
    errors = config.validate()
    if errors:
        for err in errors:
            logger.error("Configuration error", error=err)
        sys.exit(1)


def _apply_decimal_context(config: QuantcoreConfig) -> None:
    """Apply global decimal precision once at process startup."""
    config.apply_decimal_context()
    logger.info("Decimal precision set", precision=config.decimal_precision)


def _log_effective_config(config: QuantcoreConfig) -> None:
    """Log the effective configuration at startup."""
    cfg_dict = config.to_dict()
    logger.info("Quantcore configuration initialised", **cfg_dict)


def init_quantcore(
    env: EnvName | None = None,
    *,
    run_health_checks: bool = True,
) -> QuantcoreConfig:
    """Application entry point to initialise Quantcore.

    Typical usage at process startup:

        from quantcore.bootstrap import init_quantcore

        config = init_quantcore()
        # continue with app startup...

    Steps:
        1. Determine environment (env argument or QUANTCORE_ENV).
        2. Build config for env + environment overrides.
        3. Validate config and exit on error.
        4. Apply global decimal context ONCE.
        5. Install as global config via set_config().
        6. Optionally run health checks and exit on failure.
    """
    raw_env = (env or os.getenv("QUANTCORE_ENV", "production")).lower()
    if raw_env not in {"development", "production", "testing"}:
        logger.warning(
            "Unknown QUANTCORE_ENV, defaulting to production", env=raw_env
        )
        env_name: EnvName = "production"
    else:
        env_name = raw_env  # type: ignore[assignment]

    logger.info("Initialising Quantcore", env=env_name)

    config = _build_config(env_name)
    _validate_or_exit(config)
    _apply_decimal_context(config)

    # Install as global config
    set_config(config)
    _log_effective_config(get_config())

    if run_health_checks:
        health = check_health(include_operations_test=(env_name != "testing"))
        if not health.is_healthy:
            logger.error(
                "Initial health check failed",
                errors=health.errors,
                warnings=health.warnings,
                failed_components=[
                    c.name for c in health.components if not c.is_healthy
                ],
            )
            sys.exit(1)

    logger.info("Quantcore initialised successfully")
    return config


if __name__ == "__main__":
    # CLI bootstrap entry for:
    #   python -m quantcore.bootstrap
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    )
    init_quantcore()
