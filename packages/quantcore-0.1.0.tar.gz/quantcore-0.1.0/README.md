# Quantcore

**Pure Python trading math and domain models for quantitative finance.**

Quantcore is a lightweight, dependency-free library providing core primitives for trading systems: orders, positions, portfolio accounting, PnL calculation, risk metrics, sizing, health/monitoring, security utilities, and JSON serialization. All math uses `Decimal` to avoid floating-point drift.

[![Python 3.11+](https://img.shields.io/badge/python-3.11+-blue.svg)](https://www.python.org/downloads/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

> Disclaimer: This library is for informational and educational use only. It is not financial, investment, or trading advice. Use at your own risk. The authors and contributors accept no responsibility for any losses or damages. Ensure your usage complies with applicable laws and regulations.

---

## Features

- **Decimal-first math** - High-precision arithmetic for PnL, risk, sizing, and funding
- **Immutable positions** - Lot-level cost basis tracking (FIFO/LIFO/Average)
- **Multi-currency portfolio** - FX conversion, ledger, and cash flow accounting
- **Comprehensive PnL** - Realized, unrealized, funding, fees, slippage breakdowns
- **Risk & margin** - Sharpe/Sortino, drawdown, VaR, liquidation prices
- **Position sizing** - Fixed, percent-based, risk-based, Kelly criterion
- **Order types** - Market, limit, stop, trailing stop, iceberg
- **Observability** - Health checks plus metrics collection for timings/counters/gauges
- **Security utilities** - Audit trail, rate limiting, and input sanitization helpers
- **Serialization** - JSON codecs for positions, portfolios, ledger, and events
- **Zero dependencies** - Pure Python stdlib + `decimal`

---

## Installation

```bash
pip install -e .
```

**Requirements:** Python >= 3.11

---

## Quick Start

### 1. Initialise Quantcore (recommended)

```python
from quantcore.bootstrap import init_quantcore

config = init_quantcore(
    env="dev",              # "dev" | "test" | "production" | None
    run_health_checks=True  # run basic health checks on startup
)
```

This:

- Sets the global `Decimal` context (precision, rounding).
- Configures Quantcore logging.
- Optionally runs health checks and raises if unhealthy.

You can still access the active decimal context if needed:

```python
from quantcore import decimal_context

print(decimal_context.prec)
```

### 2. Position & PnL Calculation

```python
from decimal import Decimal
from quantcore.positions.base import BasePositionImpl
from quantcore.core.enums import OrderSide
from quantcore.events.fill import Fill
from quantcore.pnl import calculate_pnl, PnLMode

# Open position
pos = BasePositionImpl.flat("BTC-USD")
pos = pos.apply_fill(
    Fill("buy1", "BTC-USD", OrderSide.BUY, Decimal("1"), Decimal("10000"), Decimal("10"), 0)
)

# Partial close
pos = pos.apply_fill(
    Fill("sell1", "BTC-USD", OrderSide.SELL, Decimal("0.4"), Decimal("11000"), Decimal("4"), 1)
)

# Calculate PnL
pnl = calculate_pnl(position=pos, mark_price=Decimal("10500"), mode=PnLMode.BOTH)
print(f"Realized: {pnl.realized}, Unrealized: {pnl.unrealized}, Total: {pnl.total}")
```

### 3. Portfolio, Funding, and Metrics

```python
from decimal import Decimal
from quantcore.portfolio import Portfolio
from quantcore.events.funding import FundingEvent
from quantcore.monitoring.metrics import timed_operation, get_metrics

portfolio = Portfolio()
fills = [...]  # list[Fill]

with timed_operation("apply_fill_batch"):
    for fill in fills:
        portfolio.apply_fill(fill)

funding = FundingEvent(
    instrument_id="BTC-PERP",
    rate=Decimal("0.0001"),
    period_start_ms=0,
    period_end_ms=28800000,  # 8 hours
    index_price=Decimal("10500"),
)
portfolio.apply_funding(funding, fills=fills)

metrics = get_metrics().get_stats()
print(metrics["timings"]["apply_fill_batch"])
```

### 4. Security & Serialization

```python
from decimal import Decimal
from quantcore.security import AuditTrail, rate_limit, sanitize_all_fields
from quantcore.serialization.json_codec import save_to_file, load_from_file
from quantcore.portfolio import Portfolio

audit = AuditTrail()
audit.record_fill(
    user_id="user1",
    order_id="o1",
    instrument_id="BTC-USD",
    side="BUY",
    quantity=Decimal("1"),
    price=Decimal("10000"),
    fee=Decimal("10"),
)

@rate_limit(max_calls=10, time_window=1.0, identifier="order_submit")
def submit_order(payload: dict):
    safe = sanitize_all_fields(payload)
    # ... send to exchange
    return safe

portfolio = Portfolio()
save_to_file(portfolio, "portfolio.json")
restored = load_from_file("portfolio.json", Portfolio)
```

### 5. Health Checks

```python
from quantcore.health import check_health

health = check_health()
if not health.is_healthy:
    raise SystemExit(f"Unhealthy: {health.errors}")
```

---

## Architecture

| Module | Purpose |
|--------|---------|
| `quantcore.core` | Base types (`Money`, `Price`, `Quantity`), enums, exceptions |
| `quantcore.positions` | Position models with lot-level cost basis |
| `quantcore.portfolio` | Portfolio container, account balances, ledger |
| `quantcore.pnl` | PnL calculation engine with funding segmentation |
| `quantcore.orders` | Order types and state machine |
| `quantcore.risk` | Risk metrics, liquidation prices, exposure |
| `quantcore.margin` | Initial/maintenance margin, utilization |
| `quantcore.sizing` | Position sizing strategies |
| `quantcore.fees` | Fee calculation and VIP tiers |
| `quantcore.pricing` | Mark price, VWAP, slippage estimation |
| `quantcore.instruments` | Spot, perpetual, futures, options specs |
| `quantcore.data` | Market data structures (candles, orderbook, trades) |
| `quantcore.math` | Decimal rounding, returns, statistics, volatility |
| `quantcore.time` | Timestamp conversion, intervals |
| `quantcore.monitoring` | Metrics collection (timings, counters, gauges) |
| `quantcore.security` | Audit trail, rate limiting, sanitization helpers |
| `quantcore.serialization` | JSON codecs for portfolio, positions, ledger, events |
| `quantcore.health` | System health checks for config/imports/operations |
| `quantcore.utils` | Validation, formatting, logging, serialization helpers |

---

## Documentation

- **[Concepts](docs/concepts.md)** - Core ideas and data flow
- **[Quick Reference](docs/quickref.md)** - One-page cheatsheet
- **[API Reference](docs/api.md)** - Module documentation
- **[Production Guide](docs/PRODUCTION_GUIDE.md)** - Hardening, monitoring, and operations

---

## Testing

```bash
pip install -e ".[dev]"
pytest --cov=quantcore --cov-report=term-missing
ruff check src tests
black --check src tests
mypy --config-file mypy.ini src
```

---

## Design Principles

1. **Pure functions** - Immutable data structures, no side effects
2. **Type hints** - Full type coverage for IDE support
3. **Decimal precision** - No floating-point drift in financial calculations
4. **Zero dependencies** - Easy to audit, vendor, or embed
5. **Engine-agnostic** - Plug into any backtest or execution system

---

## Limitations

- **Not a trading engine** - No order matching, execution, or market connectivity
- **Not a backtester** - No historical simulation framework
- **Not a broker adapter** - No exchange API integrations
- **In-memory only** - No persistence layer (use your own DB)

Quantcore provides the **math and domain models**. You build the engine around it.

---

## Performance (example)

- **Portfolio updates**: ~1.6ms for 1000 fills
- **PnL calculation**: ~0.8ms for 1000-position portfolio
- **Cost basis matching**: ~0.12ms per FIFO match on 100 lots
- **Funding segmentation**: ~0.03ms per event with fill segments

See `benchmarks/` for reproducible tests.

---

## Contributing

See [CONTRIBUTING.md](CONTRIBUTING.md) for guidelines on code style, testing, and PR workflow.

---

## License

MIT License - see [LICENSE](LICENSE) for details.

---

## Support

- **Issues**: GitHub Issues
- **Discussions**: GitHub Discussions

Built for quantitative traders who need reliable, auditable trading math without heavyweight frameworks.
