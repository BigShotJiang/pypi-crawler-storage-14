from decimal import getcontext
import threading

import pytest

from quantcore.config import (
    QuantcoreConfig,
    get_config,
    set_config,
    reset_config,
)
from quantcore.bootstrap import init_quantcore


def test_config_from_env(monkeypatch):
    """Test loading config from environment without implicit global side effects."""
    monkeypatch.setenv("QUANTCORE_DECIMAL_PRECISION", "34")
    monkeypatch.setenv("QUANTCORE_BASE_CURRENCY", "EUR")
    monkeypatch.setenv("QUANTCORE_LOG_LEVEL", "DEBUG")

    # Reset to force reload from env
    reset_config()

    original_prec = getcontext().prec

    cfg = QuantcoreConfig.from_env()
    assert cfg.decimal_precision == 34
    assert cfg.base_currency == "EUR"
    assert cfg.log_level == "DEBUG"

    # from_env should NOT mutate global decimal context by itself
    assert getcontext().prec == original_prec

    # Applying decimal context should update global precision
    cfg.apply_decimal_context()
    assert getcontext().prec == 34

    # Cleanup
    getcontext().prec = original_prec
    reset_config()


def test_config_presets():
    """Test preset configurations."""
    dev = QuantcoreConfig.development()
    assert dev.log_level == "DEBUG"
    assert dev.enable_performance_logging is True

    prod = QuantcoreConfig.production()
    assert prod.decimal_precision == 34
    assert prod.log_level == "INFO"

    test = QuantcoreConfig.testing()
    assert test.log_level == "ERROR"
    assert test.enable_audit_logging is False


def test_config_override():
    """Test overriding config values (pure config object)."""
    cfg = QuantcoreConfig()
    original_prec = getcontext().prec

    # Override should only change the config object
    cfg.override(decimal_precision=50, log_level="WARNING")
    assert cfg.decimal_precision == 50
    assert cfg.log_level == "WARNING"

    # Global decimal context should remain unchanged until explicitly applied
    assert getcontext().prec == original_prec

    # When we apply the context, precision should update
    cfg.apply_decimal_context()
    assert getcontext().prec == 50

    # Reset global state
    getcontext().prec = original_prec
    reset_config()


def test_config_validation():
    """Test config validation."""
    cfg = QuantcoreConfig(decimal_precision=5)
    errors = cfg.validate()
    assert any("decimal_precision too low" in e for e in errors)

    cfg = QuantcoreConfig(log_level="INVALID")
    errors = cfg.validate()
    assert any("Invalid log_level" in e for e in errors)


def test_config_singleton():
    """Test global config singleton."""
    reset_config()

    # Seed global config explicitly (no more lazy creation)
    base_cfg = QuantcoreConfig.development()
    set_config(base_cfg)

    cfg1 = get_config()
    cfg2 = get_config()

    assert cfg1 is cfg2
    assert cfg1 is base_cfg

    reset_config()


def test_init_quantcore_helper():
    """Test bootstrap helper for one-shot initialization."""
    from quantcore.bootstrap import init_quantcore

    original_prec = getcontext().prec
    reset_config()

    # Use named environment, not a QuantcoreConfig instance
    cfg = init_quantcore("testing", run_health_checks=False)

    # init_quantcore should:
    # - return a QuantcoreConfig
    # - install it as the global config
    assert isinstance(cfg, QuantcoreConfig)
    assert get_config() is cfg

    # It should match the testing preset
    preset = QuantcoreConfig.testing()
    assert cfg.decimal_precision == preset.decimal_precision
    assert cfg.log_level == preset.log_level
    assert cfg.base_currency == preset.base_currency

    # Decimal precision should be applied
    assert getcontext().prec == preset.decimal_precision

    # Cleanup
    getcontext().prec = original_prec
    reset_config()


def test_config_thread_safety():
    """Test config is thread-safe (singleton per process)."""
    reset_config()

    # Ensure config is initialised before threads start calling get_config()
    seed = QuantcoreConfig.testing()
    set_config(seed)

    results = []

    def get_config_thread():
        cfg = get_config()
        results.append(cfg)

    threads = [threading.Thread(target=get_config_thread) for _ in range(10)]
    for t in threads:
        t.start()
    for t in threads:
        t.join()

    # All threads should get the same config instance
    assert len({id(r) for r in results}) == 1
    assert results and results[0] is seed

    reset_config()
