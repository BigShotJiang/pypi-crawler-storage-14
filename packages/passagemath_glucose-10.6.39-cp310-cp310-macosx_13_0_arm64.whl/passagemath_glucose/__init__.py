# sage_setup: distribution = sagemath-glucose

from sage.all__sagemath_glucose import *
