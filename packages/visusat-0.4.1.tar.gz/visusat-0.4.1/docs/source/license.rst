License
=======

VisuSat is an open-source project distributed under the **MIT License**.

The full license text is reproduced below:

.. literalinclude:: ../../LICENSE
   :language: none
   :linenos: