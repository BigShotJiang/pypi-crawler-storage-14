copernicus module
=================

.. automodule:: visusat.copernicus
   :members:
   :undoc-members:
   :show-inheritance:
