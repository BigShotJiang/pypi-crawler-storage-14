"""
ArXiv paper population module.

Clean, unified interface for populating arxiv paper datasets with:
- Smart paper selection (per-year quotas, category weights)
- ArXiv API integration (OAI-PMH for bulk, Search API fallback)
- PDF download with rate limiting and proxy support
- Text extraction
- Incremental updates with proper merging
"""
from .populate import arxiv_populate
from .api import ArxivAPI, ArxivPaper, load_proxy_credentials, DEFAULT_PROXY_FILE
from .api_oai import OAIHarvester, harvest_papers
from .selection import select_papers, DEFAULT_CATEGORY_WEIGHTS
from .download import download_pdfs, PDFDownloader
from .extract import extract_text_from_pdf

__all__ = [
    "arxiv_populate",
    "ArxivAPI",
    "ArxivPaper",
    "OAIHarvester",
    "harvest_papers",
    "select_papers",
    "download_pdfs",
    "PDFDownloader",
    "extract_text_from_pdf",
    "load_proxy_credentials",
    "DEFAULT_CATEGORY_WEIGHTS",
    "DEFAULT_PROXY_FILE",
]
