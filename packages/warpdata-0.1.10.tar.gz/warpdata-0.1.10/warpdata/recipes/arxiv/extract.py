"""
Text extraction from PDFs.

Extracts text using fast methods (pdftotext → PyPDF2 fallback).
"""
from __future__ import annotations

import re
from pathlib import Path
from shutil import which
from typing import Optional


def _has_pdftotext() -> bool:
    """Check if pdftotext (poppler-utils) is available."""
    return which("pdftotext") is not None


def extract_text_from_pdf(
    pdf_path: Path,
    max_pages: Optional[int] = None,
) -> tuple[str, Optional[str]]:
    """
    Extract text from PDF using fast methods.

    Tries:
    1. pdftotext (poppler-utils) - fast native extractor
    2. PyPDF2 - Python fallback

    Args:
        pdf_path: Path to PDF file
        max_pages: Optional limit on pages to extract

    Returns:
        Tuple of (text, error_message)
        - On success: (extracted_text, None)
        - On failure: ("", error_message)
    """
    pdf_path = Path(pdf_path)

    if not pdf_path.exists():
        return "", f"PDF not found: {pdf_path}"

    # Try pdftotext first (fastest)
    if _has_pdftotext():
        try:
            import subprocess
            args = ["pdftotext", "-layout", "-q"]
            if max_pages is not None:
                args += ["-f", "1", "-l", str(max_pages)]
            args += [str(pdf_path), "-"]

            result = subprocess.run(
                args,
                capture_output=True,
                text=True,
                timeout=30,
                check=False,
            )

            if result.returncode == 0 and result.stdout:
                return result.stdout.strip(), None
        except subprocess.TimeoutExpired:
            pass  # Fall through to PyPDF2
        except Exception:
            pass

    # Fallback to PyPDF2
    try:
        from PyPDF2 import PdfReader

        text_parts = []
        with open(pdf_path, "rb") as f:
            reader = PdfReader(f)
            pages = reader.pages[: (max_pages or len(reader.pages))]
            for page in pages:
                text = page.extract_text() or ""
                if text:
                    text_parts.append(text)

        text = "\n".join(text_parts).strip()
        if text:
            return text, None
        else:
            return "", "No text extracted (possibly scanned PDF)"

    except Exception as e:
        return "", f"Extraction failed: {str(e)}"


# Regex patterns for content analysis
_HAS_EQUATIONS_RE = re.compile(r'\$|\\\[|\\\(', re.IGNORECASE)
_HAS_FIGURES_RE = re.compile(r'\bfigure\b|fig\.', re.IGNORECASE)
_HAS_TABLES_RE = re.compile(r'\btable\b|\|.*\|', re.IGNORECASE)
_HAS_CODE_RE = re.compile(r'```|def\s+\w+\(|class\s+\w+[:\(]|import\s+\w+', re.IGNORECASE)


def analyze_content(text: str) -> dict[str, bool]:
    """
    Analyze extracted text for content features.

    Args:
        text: Extracted text content

    Returns:
        Dict with boolean flags for detected features
    """
    return {
        "has_equations": bool(_HAS_EQUATIONS_RE.search(text)),
        "has_figures": bool(_HAS_FIGURES_RE.search(text)),
        "has_tables": bool(_HAS_TABLES_RE.search(text)),
        "has_code": bool(_HAS_CODE_RE.search(text)),
    }
