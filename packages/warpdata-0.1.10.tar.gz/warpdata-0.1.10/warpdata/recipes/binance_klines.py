"""
Binance Klines dataset recipe.

Fetches klines for one or more symbols and writes a normalized Parquet
file suitable for joining with CoinGecko data (hourly/daily derivations
can be produced by grouping/rolling in downstream steps).

Notes:
- Public endpoint /api/v3/klines
- Allows dependency injection of fetch function for tests
"""
from __future__ import annotations

import os
import time
import threading
from typing import Any, Dict, Optional, Callable, List, Iterable
from pathlib import Path

import pandas as pd

from ..api.recipes import RecipeContext
from .base import RecipeOutput


BINANCE_API_BASE = os.environ.get("BINANCE_API_BASE", "https://api.binance.com")
_REQ_LOCK = threading.Lock()
_LAST_REQ_TS = 0.0


def _http_get_json(url: str, params: Optional[Dict[str, Any]] = None, timeout: float = 30.0) -> Any:
    import urllib.request
    import urllib.parse
    import json

    qs = urllib.parse.urlencode(params or {})
    full = f"{url}?{qs}" if qs else url

    headers = {
        "Accept": "application/json",
        "User-Agent": "warpdata-binance/1.0",
    }

    req = urllib.request.Request(full, headers=headers, method="GET")
    global _LAST_REQ_TS
    with _REQ_LOCK:
        # Honor IP rate limit ~1000 req / 5 min => ~0.3s/request
        min_interval = float(os.environ.get("BINANCE_MIN_INTERVAL", "0.3"))
        now = time.time()
        wait = _LAST_REQ_TS + min_interval - now
        if wait > 0:
            time.sleep(wait)
        _LAST_REQ_TS = time.time()

    with urllib.request.urlopen(req, timeout=timeout) as resp:
        data = resp.read()
        try:
            return json.loads(data)
        except Exception:
            return []


def _symbols_iter(symbols: Iterable[str]) -> List[str]:
    syms = [s for s in symbols if s]
    return syms


def binance_klines(
    ctx: RecipeContext,
    *,
    symbols: List[str],
    interval: str,
    start_time: Optional[int] = None,
    end_time: Optional[int] = None,
    limit: int = 1000,
    fetch_fn: Optional[Callable[[str, Optional[Dict[str, Any]]], Any]] = None,
) -> RecipeOutput:
    """
    Create Binance klines dataset for given symbols and interval.

    Args:
        ctx: Recipe context
        symbols: List of symbols (e.g., ['BTCUSDT'])
        interval: Kline interval (e.g., '1m', '1h', '1d')
        start_time: Start time (ms)
        end_time: End time (ms)
        limit: Max items per request (<=1000)
        fetch_fn: Optional HTTP fetch override (for tests)
    """
    fetch = fetch_fn or (lambda url, params: _http_get_json(url, params))
    rows: List[Dict[str, Any]] = []

    for sym in _symbols_iter(symbols):
        params: Dict[str, Any] = {"symbol": sym, "interval": interval, "limit": min(limit, 1000)}
        if start_time is not None:
            params["startTime"] = int(start_time)
        if end_time is not None:
            params["endTime"] = int(end_time)
        url = f"{BINANCE_API_BASE}/api/v3/klines"
        data = fetch(url, params)
        # Each entry is an array of 12 fields (see docs)
        for arr in data or []:
            if not isinstance(arr, (list, tuple)) or len(arr) < 11:
                continue
            rows.append(
                {
                    "open_time": int(arr[0]),
                    "open": float(arr[1]),
                    "high": float(arr[2]),
                    "low": float(arr[3]),
                    "close": float(arr[4]),
                    "volume": float(arr[5]),
                    "close_time": int(arr[6]),
                    "quote_volume": float(arr[7]),
                    "trades": int(arr[8]),
                    "taker_buy_volume": float(arr[9]),
                    "taker_buy_quote_volume": float(arr[10]),
                    "symbol": sym,
                    "interval": interval,
                }
            )

    df = pd.DataFrame(rows)

    out_file = ctx.work_dir / f"binance_klines_{interval}.parquet"
    out_file.parent.mkdir(parents=True, exist_ok=True)
    df.to_parquet(out_file, index=False)

    return RecipeOutput(
        main=[out_file],
        metadata={
            "source": "binance",
            "endpoint": "klines",
            "interval": interval,
            "symbols": symbols,
            "rows": len(df),
        },
    )
