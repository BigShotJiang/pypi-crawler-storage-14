"""
Polygon Snapshots dataset recipe.

Fetches real-time/EOD snapshots for stocks and options.
Includes: current price, gainers/losers, all tickers, individual contracts.

Source: Polygon.io Snapshot API
"""
from pathlib import Path
from typing import List, Optional
import json
import pandas as pd
import sys
import os
import datetime as dt

from ..api.recipes import RecipeContext
from .base import RecipeOutput, SubDataset


def polygon_snapshots(
    ctx: RecipeContext,
    *,
    snapshot_type: str = "tickers",
    tickers: Optional[List[str]] = None,
    direction: Optional[str] = None,
    include_otc: bool = False,
    date: Optional[str] = None,
    polygon_api_key: Optional[str] = None,
    raw_data_dir: str = "recipes_raw_data/polygon_snapshots",
) -> RecipeOutput:
    """
    Create Polygon Snapshots dataset.

    Downloads real-time or EOD snapshots for stocks/options.

    Args:
        ctx: Recipe context
        snapshot_type: Type of snapshot:
            - "tickers": Specific tickers (requires tickers parameter)
            - "all": All stocks snapshot
            - "gainers": Top gainers
            - "losers": Top losers
            - "option_contract": Single option contract snapshot (requires tickers with O: prefix)
        tickers: List of tickers (required for "tickers" and "option_contract" types)
        direction: "gainers" or "losers" (auto-set based on snapshot_type)
        include_otc: Include OTC stocks (default: False)
        date: Date for historical snapshots (YYYY-MM-DD, optional)
        polygon_api_key: Polygon API key (or set POLYGON_API_KEY env var)
        raw_data_dir: Directory to store raw JSON files

    Returns:
        RecipeOutput with snapshot data

    Examples:
        >>> import warpdata as wd
        >>> # Get current price for specific stocks
        >>> result = wd.run_recipe(
        ...     "polygon_snapshots",
        ...     "warpdata://snapshots/spy-qqq",
        ...     snapshot_type="tickers",
        ...     tickers=["SPY", "QQQ"],
        ...     with_materialize=True
        ... )
        >>> # Get top gainers
        >>> result = wd.run_recipe(
        ...     "polygon_snapshots",
        ...     "warpdata://snapshots/gainers",
        ...     snapshot_type="gainers",
        ...     with_materialize=True
        ... )
        >>> # Get all stocks snapshot
        >>> result = wd.run_recipe(
        ...     "polygon_snapshots",
        ...     "warpdata://snapshots/all-stocks",
        ...     snapshot_type="all",
        ...     with_materialize=True
        ... )
    """
    # Import polygon ETL
    polygon_etl_path = Path("/home/alerad/workspace/option_pricing/options_etl")
    if polygon_etl_path.exists():
        sys.path.insert(0, str(polygon_etl_path.parent))

    try:
        from options_etl.polygon_etl_module import PolygonETLAPI
    except ImportError as e:
        raise ImportError(
            f"Could not import polygon_etl_module. "
            f"Make sure /home/alerad/workspace/option_pricing is accessible"
        ) from e

    # Get API key
    api_key = polygon_api_key or os.environ.get("POLYGON_API_KEY")
    if not api_key:
        raise ValueError(
            "Polygon API key required. Set POLYGON_API_KEY env var or pass polygon_api_key parameter"
        )

    # Validate inputs
    if snapshot_type in ["tickers", "option_contract"] and not tickers:
        raise ValueError(f"snapshot_type '{snapshot_type}' requires tickers parameter")

    # Auto-set direction for gainers/losers
    if snapshot_type == "gainers":
        direction = "gainers"
    elif snapshot_type == "losers":
        direction = "losers"

    print(f"📊 Fetching Polygon Snapshots")
    print(f"   Type: {snapshot_type}")
    if tickers:
        print(f"   Tickers: {', '.join(tickers)}")
    if date:
        print(f"   Date: {date}")

    # Create raw data directory
    raw_dir = Path(raw_data_dir)
    raw_dir.mkdir(parents=True, exist_ok=True)

    # Initialize Polygon ETL API
    etl = PolygonETLAPI(api_key=api_key)

    output_files = []
    metadata = {
        "snapshot_type": snapshot_type,
        "source": "Polygon.io Snapshot API",
        "data_type": "snapshots",
        "timestamp": dt.datetime.now().isoformat(),
    }

    if date:
        metadata["date"] = date

    # Fetch based on snapshot type
    if snapshot_type == "tickers":
        # Individual ticker snapshots
        all_records = []
        for ticker in tickers:
            print(f"\n  Fetching {ticker}...")
            json_file = raw_dir / f"ticker_{ticker.lower()}.json"

            try:
                result = etl.fetch_stock_snapshot_ticker(
                    ticker=ticker,
                    out=str(json_file)
                )

                if json_file.exists():
                    with open(json_file) as f:
                        data = json.load(f)

                    # Flatten snapshot structure
                    if isinstance(data, dict) and 'ticker' in data:
                        record = {
                            'ticker': data.get('ticker'),
                            'updated': data.get('updated'),
                        }

                        # Add day data
                        if 'day' in data and isinstance(data['day'], dict):
                            day = data['day']
                            record.update({
                                'open': day.get('o'),
                                'high': day.get('h'),
                                'low': day.get('l'),
                                'close': day.get('c'),
                                'volume': day.get('v'),
                                'vwap': day.get('vw'),
                            })

                        # Add previous day
                        if 'prevDay' in data and isinstance(data['prevDay'], dict):
                            prev = data['prevDay']
                            record.update({
                                'prev_close': prev.get('c'),
                                'prev_open': prev.get('o'),
                                'prev_high': prev.get('h'),
                                'prev_low': prev.get('l'),
                                'prev_volume': prev.get('v'),
                            })

                        # Add min/max (52-week)
                        if 'min' in data and isinstance(data['min'], dict):
                            record['year_low'] = data['min'].get('c')
                        if 'max' in data and isinstance(data['max'], dict):
                            record['year_high'] = data['max'].get('c')

                        all_records.append(record)
                        print(f"    ✓ {ticker}: ${record.get('close', 'N/A')}")

            except Exception as e:
                print(f"    ⚠️  Error: {e}")

        if all_records:
            df = pd.DataFrame(all_records)
            output_file = ctx.work_dir / "polygon_snapshots_tickers.parquet"
            df.to_parquet(output_file, index=False)
            output_files.append(output_file)
            metadata["count"] = len(df)
            print(f"\n✓ Saved {len(df)} snapshots")

    elif snapshot_type == "all":
        # All stocks snapshot
        print("\n  Fetching all stocks...")
        json_file = raw_dir / "all_stocks.json"

        result = etl.fetch_stocks_snapshot_all(
            include_otc=include_otc,
            out=str(json_file)
        )

        if json_file.exists():
            with open(json_file) as f:
                data = json.load(f)

            # Extract tickers array
            tickers_data = data.get('tickers', []) if isinstance(data, dict) else data

            # Flatten each ticker
            records = []
            for t in tickers_data:
                record = {'ticker': t.get('ticker')}
                if 'day' in t and isinstance(t['day'], dict):
                    day = t['day']
                    record.update({
                        'open': day.get('o'),
                        'high': day.get('h'),
                        'low': day.get('l'),
                        'close': day.get('c'),
                        'volume': day.get('v'),
                        'vwap': day.get('vw'),
                    })
                records.append(record)

            df = pd.DataFrame(records)
            output_file = ctx.work_dir / "polygon_snapshots_all.parquet"
            df.to_parquet(output_file, index=False)
            output_files.append(output_file)
            metadata["count"] = len(df)
            print(f"  ✓ Saved {len(df)} stock snapshots")

    elif snapshot_type in ["gainers", "losers"]:
        # Gainers or losers
        print(f"\n  Fetching {direction}...")
        json_file = raw_dir / f"{direction}.json"

        result = etl.fetch_stocks_snapshot_direction(
            direction=direction,
            include_otc=include_otc,
            out=str(json_file)
        )

        if json_file.exists():
            with open(json_file) as f:
                data = json.load(f)

            tickers_data = data.get('tickers', []) if isinstance(data, dict) else data

            records = []
            for t in tickers_data:
                record = {'ticker': t.get('ticker')}
                if 'day' in t and isinstance(t['day'], dict):
                    day = t['day']
                    record.update({
                        'open': day.get('o'),
                        'high': day.get('h'),
                        'low': day.get('l'),
                        'close': day.get('c'),
                        'volume': day.get('v'),
                        'vwap': day.get('vw'),
                    })
                if 'todaysChange' in t:
                    record['change'] = t['todaysChange']
                if 'todaysChangePerc' in t:
                    record['change_pct'] = t['todaysChangePerc']
                records.append(record)

            df = pd.DataFrame(records)
            output_file = ctx.work_dir / f"polygon_snapshots_{direction}.parquet"
            df.to_parquet(output_file, index=False)
            output_files.append(output_file)
            metadata["count"] = len(df)
            print(f"  ✓ Saved {len(df)} {direction}")

    elif snapshot_type == "option_contract":
        # Individual option contract snapshots
        all_records = []
        for ticker in tickers:
            # Extract underlying from option ticker (O:SPY...)
            if ticker.startswith("O:"):
                parts = ticker.split("O:")
                if len(parts) == 2:
                    underlying = parts[1][:3]  # First 3 chars usually underlying
                else:
                    underlying = "UNKNOWN"
            else:
                underlying = ticker

            print(f"\n  Fetching {ticker}...")
            json_file = raw_dir / f"option_{ticker.replace(':', '_')}.json"

            try:
                result = etl.fetch_snapshot_contract(
                    underlying=underlying,
                    option_contract=ticker,
                    out=str(json_file)
                )

                if json_file.exists():
                    with open(json_file) as f:
                        data = json.load(f)

                    # Flatten option snapshot
                    record = {'ticker': ticker}

                    if 'details' in data and isinstance(data['details'], dict):
                        details = data['details']
                        record.update({
                            'strike': details.get('strike_price'),
                            'expiration': details.get('expiration_date'),
                            'contract_type': details.get('contract_type'),
                        })

                    if 'day' in data and isinstance(data['day'], dict):
                        day = data['day']
                        record.update({
                            'open': day.get('open'),
                            'high': day.get('high'),
                            'low': day.get('low'),
                            'close': day.get('close'),
                            'volume': day.get('volume'),
                        })

                    if 'greeks' in data and isinstance(data['greeks'], dict):
                        greeks = data['greeks']
                        record.update({
                            'delta': greeks.get('delta'),
                            'gamma': greeks.get('gamma'),
                            'theta': greeks.get('theta'),
                            'vega': greeks.get('vega'),
                        })

                    all_records.append(record)
                    print(f"    ✓ {ticker}")

            except Exception as e:
                print(f"    ⚠️  Error: {e}")

        if all_records:
            df = pd.DataFrame(all_records)
            output_file = ctx.work_dir / "polygon_snapshots_options.parquet"
            df.to_parquet(output_file, index=False)
            output_files.append(output_file)
            metadata["count"] = len(df)
            print(f"\n✓ Saved {len(df)} option snapshots")

    if not output_files:
        raise ValueError("No snapshot data downloaded")

    # Generate documentation
    readme = f"""# Polygon Snapshots Dataset

## Overview
Real-time/EOD snapshots from Polygon.io

## Configuration
- **Snapshot Type**: {snapshot_type}
- **Timestamp**: {metadata['timestamp']}
{f"- **Date**: {date}" if date else ""}
{f"- **Tickers**: {', '.join(tickers)}" if tickers else ""}

## Schema

Common fields across snapshot types:

| Column | Type | Description |
|--------|------|-------------|
| ticker | string | Ticker symbol |
| open | float | Opening price |
| high | float | Highest price |
| low | float | Lowest price |
| close | float | Closing price |
| volume | int | Trading volume |
| vwap | float | Volume-weighted average price |

Additional fields for gainers/losers:
- `change` - Absolute price change
- `change_pct` - Percentage change

Additional fields for tickers:
- `prev_close`, `prev_open`, `prev_high`, `prev_low` - Previous day data
- `year_high`, `year_low` - 52-week high/low

Additional fields for options:
- `strike`, `expiration`, `contract_type` - Contract details
- `delta`, `gamma`, `theta`, `vega` - Greeks

## Usage

```python
import warpdata as wd

# Load snapshot data
df = wd.load("warpdata://snapshots/...", as_format="pandas")

# Sort by volume
df_by_volume = df.sort_values('volume', ascending=False)

# Calculate change (if prev_close available)
if 'prev_close' in df.columns:
    df['change_pct'] = ((df['close'] - df['prev_close']) / df['prev_close'] * 100)
```

## Statistics
- Total snapshots: {metadata.get('count', 0):,}
- Snapshot type: {snapshot_type}
"""

    # Track raw data provenance
    raw_data_paths = []
    if raw_dir.exists():
        raw_data_paths.append(raw_dir.absolute())

    return RecipeOutput(
        main=output_files,
        docs={"README.md": readme},
        metadata=metadata,
        raw_data=raw_data_paths,
    )
