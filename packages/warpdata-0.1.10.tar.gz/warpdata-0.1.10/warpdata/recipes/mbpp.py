"""
MBPP (Mostly Basic Python Problems) recipe.

Loads sanitized or full MBPP parquet splits from Hugging Face:
  hf://datasets/mbpp/{sanitized|full}/{train,test,validation,prompt}-00000-of-00001.parquet

Schema (union across variants):
  - task_id: int
  - split: str
  - prompt: str (sanitized: 'prompt', full: 'text')
  - code: str
  - tests_json: str (JSON array of tests; sanitized: test_list, full: challenge_test_list)
  - test_setup_code: str (full only)
  - source_file: str (sanitized only)
"""
from __future__ import annotations

from typing import Tuple, List, Dict, Any
import json
import pandas as pd

from ..api.recipes import RecipeContext
from .base import RecipeOutput
from ..engine.duck import get_engine


def _load_split(ctx: RecipeContext, base: str, split: str, variant: str) -> pd.DataFrame:
    uri = f"{base}/{split}-00000-of-00001.parquet"
    local = ctx.download(uri)
    rel = get_engine().read_file(str(local), file_format="parquet")
    df = rel.df()

    # Harmonize fields
    if variant == "sanitized":
        prompt_col = "prompt"
        tests_col = "test_list"
        setup = None
        source_file = df.get("source_file")
    else:  # full
        prompt_col = "text"
        tests_col = "challenge_test_list"
        setup = df.get("test_setup_code")
        source_file = None

    def to_json_list(v):
        try:
            return json.dumps(v, ensure_ascii=False)
        except Exception:
            return json.dumps([str(v)], ensure_ascii=False)

    out = pd.DataFrame()
    out["task_id"] = df["task_id"].astype(int)
    out["split"] = split
    out["prompt"] = df[prompt_col].astype(str)
    out["code"] = df["code"].astype(str)
    out["tests_json"] = df[tests_col].apply(to_json_list)
    out["test_setup_code"] = setup.astype(str) if setup is not None else ""
    out["source_file"] = source_file.astype(str) if source_file is not None else ""
    return out


def mbpp(
    ctx: RecipeContext,
    variant: str = "sanitized",  # or "full"
    include_splits: Tuple[str, ...] = ("train", "validation", "test"),
) -> RecipeOutput:
    """
    Create MBPP dataset using HF parquet.
    """
    if variant not in ("sanitized", "full"):
        raise ValueError("variant must be 'sanitized' or 'full'")
    base = f"hf://datasets/mbpp/{variant}"

    parts: List[pd.DataFrame] = []
    for split in include_splits:
        try:
            parts.append(_load_split(ctx, base, split, variant))
        except Exception as e:
            print(f"Warning: failed to load split {split}: {e}")

    if not parts:
        raise RuntimeError("No splits loaded for MBPP")

    df = pd.concat(parts, ignore_index=True)
    out_path = ctx.work_dir / f"mbpp_{variant}.parquet"
    df.to_parquet(out_path, index=False)

    notes = f"""# MBPP ({variant})

Source: mbpp/{variant}
Splits: {', '.join(include_splits)}
Rows: {len(df)}

Columns:
- task_id: int
- split: str
- prompt: str
- code: str
- tests_json: JSON array
- test_setup_code: str
- source_file: str
"""

    return RecipeOutput(
        main=[out_path],
        metadata={
            "source": f"mbpp/{variant}",
            "splits": {s: int((df["split"] == s).sum()) for s in df["split"].unique()},
            "total_rows": int(len(df)),
        },
        docs={"notes.md": notes},
    )

