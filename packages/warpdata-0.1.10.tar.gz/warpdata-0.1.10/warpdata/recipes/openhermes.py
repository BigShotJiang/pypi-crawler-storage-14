"""
OpenHermes dataset recipe.

OpenHermes is a large-scale instruction-following dataset compiled from multiple sources.

Source: https://huggingface.co/datasets/teknium/OpenHermes-2.5
Paper: https://huggingface.co/teknium/OpenHermes-2.5-Mistral-7B

Dataset contains ~1 million high-quality instruction-response pairs from various sources
including GPT-4 generated data, Airoboros, CamelAI, and more.
"""
from pathlib import Path
from typing import Tuple
import pandas as pd

from datasets import load_dataset

from ..api.recipes import RecipeContext
from .base import RecipeOutput


def openhermes(
    ctx: RecipeContext,
    repo_id: str = "teknium/OpenHermes-2.5",
    split: str = "train",
) -> RecipeOutput:
    """
    Create OpenHermes instruction-following dataset.

    Downloads OpenHermes from HuggingFace. Contains conversations with system prompts,
    user instructions, and assistant responses.

    Args:
        ctx: Recipe context
        repo_id: HuggingFace repo ID
        split: Which split to include (default: "train")

    Returns:
        RecipeOutput with single dataset

    Dataset columns:
        - id: str - Unique identifier
        - conversations: list - List of conversation turns with role and content
        - source: str - Origin dataset
        - category: str - Topic category

    Examples:
        >>> import warpdata as wd
        >>> result = wd.run_recipe(
        ...     "openhermes",
        ...     "warpdata://nlp/openhermes",
        ...     with_materialize=True
        ... )
        >>> df = wd.load("warpdata://nlp/openhermes", as_format="pandas")
        >>> # Filter by source
        >>> gpt4_data = df[df['source'].str.contains('gpt4')]
    """
    print(f"Loading OpenHermes from {repo_id}...")

    # Load dataset
    print(f"  Loading {split} split...")
    ds = load_dataset(repo_id, split=split)

    print(f"  Processing {len(ds):,} examples...")

    # Process records
    all_records = []

    for example in ds:
        record = {
            'id': example.get('id', ''),
            'conversations': example.get('conversations', []),
            'source': example.get('source', ''),
            'category': example.get('category', ''),
        }
        all_records.append(record)

    print(f"\nTotal examples: {len(all_records):,}")

    # Create DataFrame
    df = pd.DataFrame(all_records)

    # Write to output
    output_path = ctx.work_dir / "openhermes.parquet"
    df.to_parquet(output_path, index=False)

    print(f"Saved to {output_path}")

    if 'source' in df.columns:
        print(f"\nSource distribution:")
        print(df['source'].value_counts().head(10).to_string())

    if 'category' in df.columns:
        print(f"\nCategory distribution:")
        print(df['category'].value_counts().head(10).to_string())

    # Track raw data provenance
    raw_data_paths = []
    hf_cache = Path.home() / ".cache" / "huggingface" / "datasets" / repo_id.replace("/", "___")
    if hf_cache.exists():
        raw_data_paths.append(hf_cache)

    return RecipeOutput(
        main=[output_path],
        metadata={
            'total_examples': len(df),
            'sources': df['source'].value_counts().to_dict() if 'source' in df.columns else {},
            'categories': df['category'].value_counts().to_dict() if 'category' in df.columns else {},
            'repo_id': repo_id,
        },
        raw_data=raw_data_paths,
    )
