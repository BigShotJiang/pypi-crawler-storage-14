"""
NuminaMath-LEAN Dataset Recipe.

Processes the AI-MO/NuminaMath-LEAN dataset from Hugging Face.
Extracts full AST from formal statements and proofs using the mathlib4 parser.

Dataset: https://huggingface.co/datasets/AI-MO/NuminaMath-LEAN
License: Apache 2.0
Size: ~104k problems with formal Lean 4 statements and proofs
"""
from pathlib import Path
from typing import Optional
import pandas as pd
import tempfile
from tqdm import tqdm
import multiprocessing as mp
import os
import json

from ..api.recipes import RecipeContext
from ..recipes.base import RecipeOutput
from .mathlib4 import extract_declarations_ast


def _process_problem(row_data):
    """Process a single problem row (worker function for parallel processing)."""
    idx, row = row_data

    # Extract AST from formal_statement
    statement_decls = []
    if pd.notna(row['formal_statement']) and row['formal_statement']:
        # Write statement to temp file for parsing
        with tempfile.NamedTemporaryFile(mode='w', suffix='.lean', delete=False) as f:
            f.write(row['formal_statement'])
            temp_path = Path(f.name)

        try:
            statement_decls = extract_declarations_ast(temp_path, limit=None)
        except Exception:
            pass  # If parsing fails, leave empty
        finally:
            temp_path.unlink()

    # Extract AST from formal_proof
    proof_decls = []
    if pd.notna(row['formal_proof']) and row['formal_proof']:
        # Combine statement + proof for full context
        full_code = row['formal_statement'] + "\n" + row['formal_proof']

        with tempfile.NamedTemporaryFile(mode='w', suffix='.lean', delete=False) as f:
            f.write(full_code)
            temp_path = Path(f.name)

        try:
            all_decls = extract_declarations_ast(temp_path, limit=None)
            # Proof declarations are those not in statement
            proof_decls = all_decls[len(statement_decls):]
        except Exception:
            pass  # If parsing fails, leave empty
        finally:
            temp_path.unlink()

    # Build record with original data + AST
    record = {
        # Original columns
        'uuid': row['uuid'],
        'problem': row['problem'],
        'question_type': row['question_type'],
        'answer': row['answer'] if pd.notna(row['answer']) else None,
        'author': row['author'],
        'formal_statement': row['formal_statement'],
        'formal_ground_truth': row['formal_ground_truth'] if pd.notna(row['formal_ground_truth']) else None,
        'ground_truth_type': row['ground_truth_type'],
        'formal_proof': row['formal_proof'] if pd.notna(row['formal_proof']) else None,
        'source': row['source'],
        'problem_type': row['problem_type'],
        'exam': row['exam'],
        # New AST columns
        'statement_declarations_json': json.dumps(statement_decls),
        'proof_declarations_json': json.dumps(proof_decls),
        'num_statement_declarations': len(statement_decls),
        'num_proof_declarations': len(proof_decls),
        'has_formal_proof': pd.notna(row['formal_proof']) and bool(row['formal_proof']),
    }
    return record


def numina_math_lean(
    ctx: RecipeContext,
    limit: Optional[int] = None,
) -> RecipeOutput:
    """
    Create NuminaMath-LEAN dataset with full AST extraction.

    Downloads the dataset from Hugging Face and extracts:
    - Full AST from formal_statement column
    - Full AST from formal_proof column
    - Original problem text and metadata

    Args:
        ctx: Recipe context
        limit: Optional limit on number of problems (for testing)

    Returns:
        RecipeOutput with processed dataset

    Columns:
        Original columns:
        - uuid: str - Unique identifier
        - problem: str - Natural language problem statement
        - question_type: str - Type of question
        - answer: str - Answer (if available)
        - author: str - Problem author
        - formal_statement: str - Lean 4 formal statement
        - formal_ground_truth: str - Ground truth (if available)
        - ground_truth_type: str - Type of ground truth
        - formal_proof: str - Lean 4 formal proof (if available)
        - source: str - Source of the problem
        - problem_type: str - Type of problem
        - exam: str - Exam name (if applicable)

        New AST extraction columns:
        - statement_declarations_json: str - Full AST from formal_statement
        - proof_declarations_json: str - Full AST from formal_proof
        - num_statement_declarations: int - Count of declarations in statement
        - num_proof_declarations: int - Count of declarations in proof
        - has_formal_proof: bool - Whether formal_proof is available

    Examples:
        >>> import warpdata as wd
        >>> result = wd.run_recipe(
        ...     "numina_math_lean",
        ...     "warpdata://math/numina_lean",
        ...     with_materialize=True
        ... )
        >>> df = wd.load("warpdata://math/numina_lean", as_format="pandas")
        >>> print(f"Problems: {len(df)}")
    """
    print("=" * 80)
    print("📦 NuminaMath-LEAN Dataset Recipe")
    print("=" * 80)

    # Download dataset from Hugging Face
    print("\n📥 Downloading dataset from Hugging Face...")
    try:
        from datasets import load_dataset
        dataset = load_dataset("AI-MO/NuminaMath-LEAN", split="train")
        print(f"✓ Downloaded {len(dataset):,} problems")

        # Track HuggingFace cache location for raw data provenance
        hf_cache_dir = Path.home() / ".cache" / "huggingface" / "datasets" / "AI-MO___numina_math-lean"

    except Exception as e:
        raise RuntimeError(f"Failed to download dataset: {e}")

    # Convert to pandas
    df = dataset.to_pandas()

    if limit:
        df = df.head(limit)
        print(f"  Limiting to {limit} problems for testing")

    # Auto-detect CPU cores and use 80% (max - 20%)
    n_cores = os.cpu_count() or 1
    n_workers = max(1, int(n_cores * 0.8))
    print(f"\n📊 Processing {len(df):,} problems using {n_workers} workers ({n_cores} cores detected)...")

    # Process problems in parallel
    with mp.Pool(processes=n_workers) as pool:
        records = list(tqdm(
            pool.imap(_process_problem, df.iterrows()),
            total=len(df),
            desc="Extracting AST",
            unit="problem"
        ))

    # Create DataFrame
    result_df = pd.DataFrame(records)

    print(f"\n✓ Processed {len(result_df):,} problems")

    # Statistics
    print(f"\n{'='*80}")
    print("Dataset Statistics")
    print(f"{'='*80}")
    print(f"Total problems:              {len(result_df):,}")
    print(f"Problems with formal proof:  {result_df['has_formal_proof'].sum():,}")
    print(f"Total statement declarations: {result_df['num_statement_declarations'].sum():,}")
    print(f"Total proof declarations:    {result_df['num_proof_declarations'].sum():,}")

    # Top sources
    print(f"\nTop sources:")
    source_counts = result_df['source'].value_counts().head(10)
    for source, count in source_counts.items():
        print(f"  {source:30s} {count:6,}")

    # Top problem types
    print(f"\nTop problem types:")
    type_counts = result_df['problem_type'].value_counts().head(10)
    for ptype, count in type_counts.items():
        print(f"  {ptype:30s} {count:6,}")

    # Save dataset
    output_path = ctx.work_dir / "numina_math_lean.parquet"
    result_df.to_parquet(output_path, index=False)

    print(f"\n💾 Saved dataset: {output_path}")

    # Metadata
    metadata = {
        'total_problems': len(result_df),
        'problems_with_proof': int(result_df['has_formal_proof'].sum()),
        'total_statement_declarations': int(result_df['num_statement_declarations'].sum()),
        'total_proof_declarations': int(result_df['num_proof_declarations'].sum()),
        'sources': source_counts.to_dict(),
        'problem_types': type_counts.to_dict(),
        'dataset_url': 'https://huggingface.co/datasets/AI-MO/NuminaMath-LEAN',
        'license': 'Apache 2.0',
    }

    print(f"\n{'='*80}")
    print("Recipe complete!")
    print(f"{'='*80}")

    # Collect raw data sources for provenance tracking
    raw_data_paths = []
    if hf_cache_dir.exists():
        # Add HuggingFace cache directory
        raw_data_paths.append(hf_cache_dir)
        print(f"\n📁 Raw data source: {hf_cache_dir}")

    return RecipeOutput(
        main=[output_path],
        metadata=metadata,
        raw_data=raw_data_paths,
    )
