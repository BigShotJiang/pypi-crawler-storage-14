"""
The Stack v2 code dataset recipe.

This recipe builds a code corpus from the gated HuggingFace dataset
``bigcode/the-stack-v2``. That dataset contains *metadata + IDs* for
source files; the actual file contents are stored in the Software
Heritage S3 bucket and must be fetched separately.

This recipe supports two modes:
  1. Metadata-only (default): create an index over files (blob_id,
     repo_name, path, language, license_type, etc.) without downloading
     code. This is light-weight and does not require AWS credentials.
  2. Full code mode: download file contents from Software Heritage S3
     and store them in a ``content`` column. This requires AWS
     credentials and the packages ``boto3`` and ``smart_open``.

The intent is to create a filtered, license-aware subset of The Stack v2
for code model pretraining, following BigCode’s recommended practices.

Reference dataset card:
    https://huggingface.co/datasets/bigcode/the-stack-v2

Important:
    - This recipe does *not* attempt to mirror the full 60+ TB corpus.
      Use the ``limit`` (documents) and/or ``target_gb`` (approx text
      size) parameters to bound the output.
    - For full bulk downloads you must comply with the BigCode /
      Software Heritage terms and obtain appropriate access.
"""
from __future__ import annotations

from pathlib import Path
from typing import Any, Dict, List, Optional, Set

import pandas as pd
import pyarrow.parquet as pq
from datasets import load_dataset

try:
    from tqdm.auto import tqdm
except Exception:  # pragma: no cover
    tqdm = None

from ..api.recipes import RecipeContext
from .base import RecipeOutput


def _ensure_s3_deps():
    """
    Import boto3 and smart_open on demand, with a clear error message
    if they are missing.
    """
    try:
        import boto3  # type: ignore
        from smart_open import open as sopen  # type: ignore
    except ImportError as e:
        raise ImportError(
            "Downloading code content from The Stack v2 requires "
            "'boto3' and 'smart_open[s3]'. Install them with:\n\n"
            "    pip install boto3 smart_open[s3]\n"
        ) from e
    return boto3, sopen


def _make_s3_client():
    """
    Create a boto3 S3 client using standard environment / config.

    AWS credentials for Software Heritage must be configured in the
    environment as described in the The Stack v2 dataset card.
    """
    boto3, _ = _ensure_s3_deps()
    session = boto3.Session()
    return session.client("s3")


def _download_swh_blob(
    blob_id: str,
    src_encoding: str,
    s3_client,
) -> str:
    """
    Download a single file content from Software Heritage S3.

    Args:
        blob_id: SWH blob ID from The Stack v2.
        src_encoding: Original encoding (e.g., 'UTF-8').
        s3_client: boto3 S3 client instance.

    Returns:
        Decoded text content (str). Returns an empty string on failure.
    """
    _, sopen = _ensure_s3_deps()

    s3_url = f"s3://softwareheritage/content/{blob_id}"
    try:
        # Objects are stored gzipped; smart_open handles decompression
        with sopen(
            s3_url,
            "rb",
            compression=".gz",
            transport_params={"client": s3_client},
        ) as fin:
            raw = fin.read()
    except Exception as e:
        print(f"  Warning: failed to download blob {blob_id}: {e}")
        return ""

    # Decode using the recorded encoding; fall back to UTF-8
    enc = src_encoding or "utf-8"
    try:
        return raw.decode(enc, errors="replace")
    except Exception:
        try:
            return raw.decode("utf-8", errors="replace")
        except Exception:
            return ""


def the_stack_v2(
    ctx: RecipeContext,
    repo_id: str = "bigcode/the-stack-v2",
    config: Optional[str] = None,
    languages: Optional[List[str]] = None,
    license_type: str = "permissive",
    exclude_generated: bool = True,
    exclude_vendor: bool = True,
    limit: Optional[int] = None,
    target_gb: Optional[float] = None,
    download_content: bool = False,
    chunk_size: int = 100_000,
) -> RecipeOutput:
    """
    Create a filtered The Stack v2 code dataset.

    Args:
        ctx: Recipe context.
        repo_id: HF dataset ID (default: 'bigcode/the-stack-v2').
        config: Optional HF config (e.g., 'Python', 'C++', 'Dockerfile')
            to restrict to a single language subset. If None, uses the
            default (all languages).
        languages: Optional list of values for the ``language`` column
            (e.g., ['Python', 'C++']). If provided, keep only rows where
            ``language`` is in this list.
        license_type: Filter on BigCode's license_type column:
            - 'permissive' (default): keep only permissively licensed files
            - 'no_license': keep only 'no_license' entries
            - 'all': do not filter by license_type
        exclude_generated: If True, drop rows where is_generated == True.
        exclude_vendor: If True, drop rows where is_vendor == True.
        limit: Global cap on number of files (documents). Mutually
            exclusive with target_gb.
        target_gb: Approximate cap on total text size (in GB) when
            download_content=True. This tracks the UTF-8 bytes of the
            ``content`` field and stops once the budget is reached.
        download_content: If True, download file contents from S3 and
            store them in a ``content`` column. Requires AWS access and
            'boto3' + 'smart_open[s3]'.
        chunk_size: Number of records per Parquet chunk when writing
            out. Large chunks are more efficient but use more memory.

    Returns:
        RecipeOutput with one or more Parquet files.

    Typical usage (Python-only, ~5GB):
        >>> import warpdata as wd
        >>> result = wd.run_recipe(
        ...     "the_stack_v2",
        ...     "warpdata://code/the-stack-v2-python-5gb",
        ...     config="Python",
        ...     languages=["Python"],
        ...     license_type="permissive",
        ...     exclude_generated=True,
        ...     exclude_vendor=True,
        ...     download_content=True,
        ...     target_gb=5.0,
        ...     with_materialize=True,
        ... )
    """
    if limit is not None and target_gb is not None:
        raise ValueError("Specify only one of limit (files) or target_gb (GB), not both.")

    if target_gb is not None and not download_content:
        raise ValueError(
            "target_gb is based on text bytes and requires download_content=True."
        )

    if languages is not None:
        # Normalize to a set of strings. Accept either a list of languages
        # or a single comma-separated string (useful from CLI -p).
        if isinstance(languages, str):
            raw_langs = [part.strip() for part in languages.split(",") if part.strip()]
        else:
            raw_langs = list(languages)
        lang_set = {str(lang) for lang in raw_langs}
    else:
        lang_set = None

    license_type = (license_type or "permissive").lower()
    if license_type not in {"permissive", "no_license", "all"}:
        raise ValueError(
            "license_type must be one of {'permissive', 'no_license', 'all'}"
        )

    print(f"📚 Loading The Stack v2 from {repo_id} (config={config or 'default'})")
    if lang_set:
        print(f"   Restricting to languages: {sorted(lang_set)}")
    print(f"   license_type filter: {license_type}")
    print(f"   exclude_generated: {exclude_generated}  exclude_vendor: {exclude_vendor}")

    if limit is not None:
        print(f"   Global file limit: {limit:,}")
    if target_gb is not None:
        total_bytes_budget = int(target_gb * (1024**3))
        print(f"   Global text byte budget: ~{target_gb:.2f} GB ({total_bytes_budget:,} bytes)")
    else:
        total_bytes_budget = None

    # Prepare streaming dataset from HF
    if config:
        ds = load_dataset(repo_id, config, split="train", streaming=True)
    else:
        ds = load_dataset(repo_id, split="train", streaming=True)

    # Prepare S3 client if we are downloading content
    s3_client = None
    if download_content:
        print("   Initializing S3 client for Software Heritage content...")
        s3_client = _make_s3_client()

    # Incremental Parquet writing
    chunk_records: List[Dict[str, Any]] = []
    parquet_paths: List[Path] = []
    part_idx = 0

    total_files = 0
    total_bytes = 0

    seen_blob_ids: Set[str] = set()

    # Resume support: detect existing chunk files and skip already-processed blob_ids.
    existing_chunks = sorted(ctx.work_dir.glob("the_stack_v2_part*.parquet"))
    if existing_chunks:
        print(f"\n   Found {len(existing_chunks)} existing chunk file(s); "
              f"attempting to resume and skip existing records.")
        for p in existing_chunks:
            parquet_paths.append(p)
            name = p.name
            try:
                idx_str = name.split("part", 1)[1].split(".parquet", 1)[0]
                idx = int(idx_str)
                if idx + 1 > part_idx:
                    part_idx = idx + 1
            except Exception:
                # If name parsing fails, just keep current part_idx.
                pass

            try:
                meta = pq.ParquetFile(p).metadata
                if meta is not None and meta.num_rows is not None:
                    total_files += meta.num_rows
            except Exception:
                pass

            # Collect blob_ids to prevent re-downloading the same content.
            try:
                table = pq.read_table(p, columns=["blob_id"])
                blob_col = table["blob_id"].to_pylist()
                seen_blob_ids.update(str(b) for b in blob_col if b is not None)
            except Exception:
                pass

            # Approximate bytes using length_bytes if available (for target_gb resumes).
            if target_gb is not None:
                try:
                    tbl_len = pq.read_table(p, columns=["length_bytes"])
                    vals = tbl_len["length_bytes"].to_pylist()
                    total_bytes += sum(int(v or 0) for v in vals)
                except Exception:
                    pass

        print(f"   Resuming with {total_files:,} already materialized files.")
        if total_bytes > 0 and target_gb is not None:
            print(f"   Approximate existing text size: {total_bytes / (1024**3):.2f} GB")

    # If we've already hit limits from existing chunks, short-circuit.
    if limit is not None and total_files >= limit:
        print(f"\n   Existing chunks already satisfy limit={limit:,}; no new files needed.")
        return RecipeOutput(
            main=parquet_paths,
            metadata={
                "total_files": total_files,
                "total_text_bytes": total_bytes,
                "repo_id": repo_id,
                "config": config,
                "languages": sorted(lang_set) if lang_set else None,
                "license_type": license_type,
                "exclude_generated": exclude_generated,
                "exclude_vendor": exclude_vendor,
                "limit": limit,
                "target_gb": target_gb,
                "download_content": download_content,
            },
            raw_data=[
                p
                for p in [
                    Path.home()
                    / ".cache"
                    / "huggingface"
                    / "datasets"
                    / repo_id.replace("/", "___")
                ]
                if p.exists()
            ],
        )

    if target_gb is not None and total_bytes_budget is not None and total_bytes >= total_bytes_budget:
        print(f"\n   Existing chunks already satisfy target_gb≈{target_gb:.2f} GB; no new files needed.")
        return RecipeOutput(
            main=parquet_paths,
            metadata={
                "total_files": total_files,
                "total_text_bytes": total_bytes,
                "repo_id": repo_id,
                "config": config,
                "languages": sorted(lang_set) if lang_set else None,
                "license_type": license_type,
                "exclude_generated": exclude_generated,
                "exclude_vendor": exclude_vendor,
                "limit": limit,
                "target_gb": target_gb,
                "download_content": download_content,
            },
            raw_data=[
                p
                for p in [
                    Path.home()
                    / ".cache"
                    / "huggingface"
                    / "datasets"
                    / repo_id.replace("/", "___")
                ]
                if p.exists()
            ],
        )

    def _flush_chunk():
        nonlocal part_idx
        if not chunk_records:
            return
        df = pd.DataFrame(chunk_records)
        out_path = ctx.work_dir / f"the_stack_v2_part{part_idx:04d}.parquet"
        df.to_parquet(out_path, index=False)
        parquet_paths.append(out_path)
        print(
            f"   Wrote chunk {part_idx} with {len(df):,} rows "
            f"to {out_path.name}"
        )
        chunk_records.clear()
        part_idx += 1

    # Optional progress bar (length unknown when streaming).
    if tqdm is not None:
        data_iter = tqdm(ds, desc="Filtering & downloading Stack v2", unit="file")
    else:
        data_iter = ds

    for i, example in enumerate(data_iter):
        # License filter
        lt = str(example.get("license_type", "") or "").lower()
        if license_type == "permissive" and lt != "permissive":
            continue
        if license_type == "no_license" and lt != "no_license":
            continue

        # Language filter
        lang = str(example.get("language", "") or "")
        if lang_set is not None and lang not in lang_set:
            continue

        # Vendor / generated filters
        if exclude_vendor and bool(example.get("is_vendor")):
            continue
        if exclude_generated and bool(example.get("is_generated")):
            continue

        blob_id = str(example.get("blob_id", "") or "")
        src_encoding = str(example.get("src_encoding", "") or "utf-8")

        if not blob_id:
            # Shouldn't happen, but skip just in case
            continue

        # Skip files we've already materialized in previous runs (resume).
        if seen_blob_ids and blob_id in seen_blob_ids:
            continue

        content_text = None
        text_bytes = 0

        if download_content:
            content_text = _download_swh_blob(blob_id, src_encoding, s3_client)
            if content_text:
                text_bytes = len(content_text.encode("utf-8", errors="ignore"))

            if total_bytes_budget is not None:
                if total_bytes + text_bytes > total_bytes_budget:
                    # If this single file would push us over budget,
                    # we still include it then stop.
                    print(
                        f"   Reached global byte budget after adding file {total_files + 1:,}: "
                        f"{(total_bytes + text_bytes) / (1024**3):.2f} GB"
                    )
                    total_bytes += text_bytes
                    total_files += 1

                    record = {
                        "blob_id": blob_id,
                        "path": example.get("path", ""),
                        "repo_name": example.get("repo_name", ""),
                        "language": lang,
                        "extension": example.get("extension", ""),
                        "license_type": lt,
                        "detected_licenses": example.get("detected_licenses", []),
                        "is_vendor": bool(example.get("is_vendor")),
                        "is_generated": bool(example.get("is_generated")),
                        "length_bytes": int(example.get("length_bytes", 0) or 0),
                        "content": content_text,
                    }
                    chunk_records.append(record)
                    _flush_chunk()
                    break

        # Build record (metadata + optional content)
        record = {
            "blob_id": blob_id,
            "path": example.get("path", ""),
            "repo_name": example.get("repo_name", ""),
            "language": lang,
            "extension": example.get("extension", ""),
            "license_type": lt,
            "detected_licenses": example.get("detected_licenses", []),
            "is_vendor": bool(example.get("is_vendor")),
            "is_generated": bool(example.get("is_generated")),
            "length_bytes": int(example.get("length_bytes", 0) or 0),
        }
        if download_content:
            record["content"] = content_text

        chunk_records.append(record)
        total_files += 1
        total_bytes += text_bytes

        if limit is not None and total_files >= limit:
            print(f"   Reached file limit: {total_files:,}")
            break

        if total_bytes_budget is not None and total_bytes >= total_bytes_budget:
            print(
                f"   Reached global byte budget: "
                f"{total_bytes / (1024**3):.2f} GB after {total_files:,} files"
            )
            break

        if total_files % 100_000 == 0:
            gb = total_bytes / (1024**3) if download_content else 0.0
            print(
                f"   Processed {total_files:,} files so far"
                + (f" (~{gb:.2f} GB of text)" if download_content else "")
            )

        if len(chunk_records) >= chunk_size:
            _flush_chunk()

    # Flush remaining records
    _flush_chunk()

    print(
        f"\n✅ Completed The Stack v2 recipe with {total_files:,} files "
        + (
            f"and ~{total_bytes / (1024**3):.2f} GB of text"
            if download_content
            else ""
        )
    )

    # Track raw data provenance: HF cache + note repo_id
    raw_data_paths: List[Path] = []
    hf_cache_root = Path.home() / ".cache" / "huggingface" / "datasets" / repo_id.replace("/", "___")
    if hf_cache_root.exists():
        raw_data_paths.append(hf_cache_root)

    return RecipeOutput(
        main=parquet_paths,
        metadata={
            "total_files": total_files,
            "total_text_bytes": total_bytes,
            "repo_id": repo_id,
            "config": config,
            "languages": sorted(lang_set) if lang_set else None,
            "license_type": license_type,
            "exclude_generated": exclude_generated,
            "exclude_vendor": exclude_vendor,
            "limit": limit,
            "target_gb": target_gb,
            "download_content": download_content,
        },
        raw_data=raw_data_paths,
    )
