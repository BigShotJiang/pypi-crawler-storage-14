"""
SEC EDGAR Earnings dataset recipe.

Fetches earnings dates from SEC EDGAR filings (10-Q, 10-K).
100% free, no API key required.

Source: SEC EDGAR Public API
"""
from pathlib import Path
from typing import List, Optional
import pandas as pd
import requests
import time
from datetime import datetime

from ..api.recipes import RecipeContext
from .base import RecipeOutput


def get_cik_from_ticker(ticker: str) -> Optional[str]:
    """Get CIK number from ticker symbol using SEC EDGAR."""
    # SEC requires a User-Agent header
    headers = {
        'User-Agent': 'WarpData Dataset Builder research@example.com'
    }

    # Get ticker to CIK mapping
    url = "https://www.sec.gov/files/company_tickers.json"

    try:
        response = requests.get(url, headers=headers)
        if response.status_code == 200:
            data = response.json()

            # Find ticker in the data
            for item in data.values():
                if item.get('ticker', '').upper() == ticker.upper():
                    cik = str(item['cik_str']).zfill(10)  # Pad to 10 digits
                    return cik
    except Exception as e:
        print(f"    ⚠️  Error getting CIK: {e}")

    return None


def get_earnings_dates_from_sec(ticker: str, cik: str) -> List[dict]:
    """Get earnings dates from SEC EDGAR filings."""
    headers = {
        'User-Agent': 'WarpData Dataset Builder research@example.com'
    }

    # Get company submissions
    url = f"https://data.sec.gov/submissions/CIK{cik}.json"

    try:
        time.sleep(0.1)  # SEC rate limit: 10 requests per second
        response = requests.get(url, headers=headers)

        if response.status_code != 200:
            return []

        data = response.json()

        # Extract filings
        filings = data.get('filings', {}).get('recent', {})

        if not filings:
            return []

        # Get arrays
        forms = filings.get('form', [])
        filing_dates = filings.get('filingDate', [])
        accession_numbers = filings.get('accessionNumber', [])
        primary_documents = filings.get('primaryDocument', [])

        earnings_events = []

        # Process each filing
        for i in range(len(forms)):
            form = forms[i]

            # Only earnings-related filings
            if form in ['10-Q', '10-K', '8-K']:
                filing_date = filing_dates[i] if i < len(filing_dates) else None
                accession = accession_numbers[i] if i < len(accession_numbers) else None
                primary_doc = primary_documents[i] if i < len(primary_documents) else None

                if filing_date:
                    # Determine quarter from filing date and form
                    quarter = None
                    if form == '10-Q':
                        month = int(filing_date.split('-')[1])
                        if month in [4, 5]:
                            quarter = 'Q1'
                        elif month in [7, 8]:
                            quarter = 'Q2'
                        elif month in [10, 11]:
                            quarter = 'Q3'
                    elif form == '10-K':
                        quarter = 'Q4'

                    earnings_events.append({
                        'ticker': ticker,
                        'cik': cik,  # Add CIK for downloading actual filings
                        'filing_date': filing_date,
                        'form_type': form,
                        'fiscal_period': quarter,
                        'accession_number': accession,
                        'primary_document': primary_doc,
                    })

        return earnings_events

    except Exception as e:
        print(f"    ⚠️  Error fetching filings: {e}")
        return []


def sec_earnings(
    ctx: RecipeContext,
    *,
    tickers: List[str],
    filing_types: Optional[List[str]] = None,
) -> RecipeOutput:
    """
    Create SEC EDGAR Earnings dataset.

    Downloads earnings dates from SEC EDGAR filings (10-Q, 10-K, 8-K).
    100% free, no API key required.

    Args:
        ctx: Recipe context
        tickers: List of ticker symbols
        filing_types: Types of filings to include (default: ['10-Q', '10-K'])

    Returns:
        RecipeOutput with earnings filing dates

    Examples:
        >>> import warpdata as wd
        >>> # Get earnings filings for tech stocks
        >>> result = wd.run_recipe(
        ...     "sec_earnings",
        ...     "warpdata://earnings/tech-stocks",
        ...     tickers=["AAPL", "MSFT", "GOOGL"],
        ...     with_materialize=True
        ... )
        >>> # Get all filing types
        >>> result = wd.run_recipe(
        ...     "sec_earnings",
        ...     "warpdata://earnings/all-filings",
        ...     tickers=["NVDA", "TSLA"],
        ...     filing_types=["10-Q", "10-K", "8-K"],
        ...     with_materialize=True
        ... )
    """
    if not tickers:
        raise ValueError("Must specify at least one ticker")

    if filing_types is None:
        filing_types = ['10-Q', '10-K']

    print(f"📊 Fetching SEC EDGAR Earnings data")
    print(f"   Tickers: {', '.join(tickers[:10])}{'...' if len(tickers) > 10 else ''}")
    print(f"   Filing types: {', '.join(filing_types)}")

    all_earnings = []

    for ticker in tickers:
        print(f"  📈 Fetching {ticker}...")

        # Get CIK
        cik = get_cik_from_ticker(ticker)
        if not cik:
            print(f"    ⚠️  Could not find CIK")
            continue

        print(f"    CIK: {cik}")

        # Get earnings dates
        earnings = get_earnings_dates_from_sec(ticker, cik)

        if earnings:
            # Filter by filing types
            earnings = [e for e in earnings if e['form_type'] in filing_types]

            if earnings:
                all_earnings.extend(earnings)
                print(f"    ✓ {len(earnings)} filings")
            else:
                print(f"    ℹ️  No filings matching types")
        else:
            print(f"    ℹ️  No filings found")

    if not all_earnings:
        raise ValueError("No earnings data found")

    print(f"\n  ✓ Total earnings filings: {len(all_earnings):,}")

    # Convert to DataFrame
    df = pd.DataFrame(all_earnings)

    # Sort by filing date and ticker
    df = df.sort_values(['filing_date', 'ticker'], ascending=[False, True])

    # Add year for convenience
    df['year'] = pd.to_datetime(df['filing_date']).dt.year

    # Save to parquet
    output_file = ctx.work_dir / "sec_earnings.parquet"
    df.to_parquet(output_file, index=False)

    print(f"  ✓ Saved to {output_file.name}")

    # Show sample
    print(f"\n  📊 Sample data:")
    sample_cols = ['ticker', 'filing_date', 'form_type', 'fiscal_period']
    available_cols = [col for col in sample_cols if col in df.columns]
    if available_cols:
        print(df[available_cols].head(5).to_string())

    # Generate documentation
    readme = f"""# SEC EDGAR Earnings Dataset

## Overview
Earnings filing dates from SEC EDGAR (10-Q, 10-K, 8-K)

100% free data from the U.S. Securities and Exchange Commission

## Configuration
- **Tickers**: {len(tickers)} tickers
- **Filing Types**: {', '.join(filing_types)}
- **Source**: SEC EDGAR Public API

## Schema

| Column | Type | Description |
|--------|------|-------------|
| ticker | string | Stock ticker symbol |
| filing_date | date | Date the filing was submitted to SEC |
| form_type | string | Filing type (10-Q, 10-K, 8-K) |
| fiscal_period | string | Fiscal period (Q1, Q2, Q3, Q4) |
| year | int | Year of filing |
| accession_number | string | SEC accession number (unique ID) |
| primary_document | string | Primary document filename |

## Filing Types

- **10-Q**: Quarterly report (Q1, Q2, Q3)
- **10-K**: Annual report (Q4 / fiscal year end)
- **8-K**: Current report (material events, often earnings announcements)

## Usage

```python
import warpdata as wd
import pandas as pd

# Load earnings data
df = wd.load("warpdata://earnings/...", as_format="pandas")

# Filter by ticker
aapl_earnings = df[df['ticker'] == 'AAPL']

# Get most recent earnings
recent = df.sort_values('filing_date', ascending=False).head(10)

# Count filings by quarter
quarterly_counts = df.groupby(['ticker', 'fiscal_period']).size()

# Get 10-K (annual) filings only
annual = df[df['form_type'] == '10-K']
```

## Statistics
- Total filings: {len(df):,}
- Unique tickers: {df['ticker'].nunique()}
- Date range: {df['filing_date'].min()} to {df['filing_date'].max()}
- Filing types: {df['form_type'].value_counts().to_dict()}

## Notes

- Filing dates represent when the document was submitted to SEC
- Actual earnings announcement may be before filing date
- 10-Q filings must be submitted within 40-45 days of quarter end
- 10-K filings must be submitted within 60-90 days of fiscal year end
"""

    metadata = {
        "total_filings": len(df),
        "unique_tickers": int(df['ticker'].nunique()),
        "date_range": f"{df['filing_date'].min()} to {df['filing_date'].max()}",
        "filing_types": df['form_type'].value_counts().to_dict(),
        "source": "SEC EDGAR Public API",
    }

    return RecipeOutput(
        main=[output_file],
        docs={"README.md": readme},
        metadata=metadata,
    )
