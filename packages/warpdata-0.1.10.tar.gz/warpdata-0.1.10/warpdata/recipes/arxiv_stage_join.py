"""
ArXiv Stage Join Recipe.

Joins PDF manifest with metadata, filters to only papers with both,
and optionally skips papers already processed (by pdf_sha1).
"""
from __future__ import annotations
from typing import Optional, Set

from ..api.recipes import RecipeContext
from ..recipes.base import RecipeOutput


def arxiv_stage_join(
    ctx: RecipeContext,
    manifest_id: str = "warpdata://arxiv/pdf-manifest",
    metadata_id: str = "warpdata://arxiv/metadata",
    existing_text_id: Optional[str] = None,  # Optional: skip already-processed papers
) -> RecipeOutput:
    """
    Join PDF manifest with metadata, filter to papers with both.

    Only keeps papers that have:
    1. Local PDF available (in manifest)
    2. Metadata record (from SQLite)
    3. Not already processed (optional: check existing_text_id)

    For papers with multiple PDFs (revisions), keeps newest by mtime.

    Args:
        ctx: Recipe context
        manifest_id: Dataset ID for PDF manifest
        metadata_id: Dataset ID for metadata
        existing_text_id: Optional dataset ID for already-processed papers

    Returns:
        RecipeOutput with staged Parquet

    Schema:
        All columns from metadata, plus:
        - path: string (absolute path to PDF)
        - pdf_sha1: string (SHA1 fingerprint)
        - size_bytes: int64
        - mtime: timestamp
    """
    print("🔗 Joining PDF manifest with metadata...")

    # Load manifest
    print(f"   Loading manifest: {manifest_id}")
    try:
        import warpdata as wd
        manifest_df = wd.load(manifest_id, as_format="pandas")
    except Exception as e:
        raise ValueError(f"Could not load manifest {manifest_id}: {e}")

    # Load metadata
    print(f"   Loading metadata: {metadata_id}")
    try:
        import warpdata as wd
        metadata_df = wd.load(metadata_id, as_format="pandas")
    except Exception as e:
        raise ValueError(f"Could not load metadata {metadata_id}: {e}")

    print(f"   Manifest: {len(manifest_df)} PDFs")
    print(f"   Metadata: {len(metadata_df)} papers")

    # Optional: Load existing processed papers
    existing_sha1s: Set[str] = set()
    if existing_text_id:
        try:
            import warpdata as wd
            print(f"   Loading existing processed papers: {existing_text_id}")
            existing_df = wd.load(existing_text_id, as_format="pandas")
            if "pdf_sha1" in existing_df.columns:
                existing_sha1s = set(existing_df["pdf_sha1"].dropna().unique())
                print(f"   Found {len(existing_sha1s)} already-processed PDFs")
        except Exception as e:
            print(f"   ⚠️  Could not load existing text dataset: {e}")
            print(f"   Continuing without deduplication...")

    # Join manifest + metadata on arxiv_id
    # Keep all metadata columns + path/pdf_sha1/size_bytes/mtime from manifest
    joined_df = metadata_df.merge(
        manifest_df[["arxiv_id", "path", "pdf_sha1", "size_bytes", "mtime"]],
        on="arxiv_id",
        how="inner",
    )

    print(f"   After join: {len(joined_df)} papers with both metadata and PDF")

    # If multiple PDFs for same arxiv_id (revisions), keep newest by mtime
    if len(joined_df) > 0:
        joined_df = joined_df.sort_values("mtime", ascending=False).drop_duplicates(
            subset=["arxiv_id"], keep="first"
        )
        print(f"   After dedup by arxiv_id: {len(joined_df)} papers")

    # Filter out already-processed PDFs
    if existing_sha1s and len(joined_df) > 0:
        before_count = len(joined_df)
        joined_df = joined_df[~joined_df["pdf_sha1"].isin(existing_sha1s)]
        skipped = before_count - len(joined_df)
        print(f"   Skipped {skipped} already-processed papers")
        print(f"   Remaining to process: {len(joined_df)} papers")

    # Write staged dataset
    if len(joined_df) > 0:
        staged_rel = ctx.engine.conn.from_df(joined_df)
        out_path = ctx.work_dir / "staged.parquet"
        ctx.write_parquet(staged_rel, out_path)
        print(f"   Wrote staged dataset: {out_path}")
    else:
        # Create empty file with schema
        import pandas as pd
        empty_df = pd.DataFrame({"arxiv_id": []})  # At least one column for DuckDB
        staged_rel = ctx.engine.conn.from_df(empty_df)
        out_path = ctx.work_dir / "staged.parquet"
        ctx.write_parquet(staged_rel, out_path)
        print(f"   ⚠️  No papers to stage (all already processed or no matches)")

    # Generate stats
    if len(joined_df) > 0:
        cat_counts = {}
        for idx, row in joined_df.iterrows():
            cats = row["categories"]
            if isinstance(cats, list):
                for cat in cats:
                    cat_counts[cat] = cat_counts.get(cat, 0) + 1
        year_counts = joined_df["year"].value_counts().to_dict() if "year" in joined_df.columns else {}
    else:
        cat_counts = {}
        year_counts = {}

    readme = f"""# ArXiv Staged Papers

## Overview
Papers ready for text extraction: have both metadata and local PDF, not yet processed.

## Statistics
- **Total staged**: {len(joined_df)}
- **Skipped (already processed)**: {len(existing_sha1s) if existing_sha1s else 0}
- **Manifest source**: {manifest_id}
- **Metadata source**: {metadata_id}

## Top Categories
"""
    for cat, count in sorted(cat_counts.items(), key=lambda x: -x[1])[:20]:
        readme += f"- **{cat}**: {count} papers\n"

    readme += "\n## Papers by Year\n"
    for year, count in sorted(year_counts.items(), reverse=True)[:10]:
        readme += f"- **{year}**: {count} papers\n"

    readme += """
## Schema
All metadata columns plus:
- `path`: Absolute path to PDF file
- `pdf_sha1`: SHA1 fingerprint for deduplication
- `size_bytes`: PDF file size
- `mtime`: Last modification time

## Usage
```python
import warpdata as wd
staged = wd.load("warpdata://arxiv/staged", as_format="pandas")
print(f"Papers ready for extraction: {len(staged)}")
```
"""

    return RecipeOutput(
        main=[out_path],
        subdatasets={},
        docs={"README.md": readme},
        metadata={
            "manifest_id": manifest_id,
            "metadata_id": metadata_id,
            "existing_text_id": existing_text_id,
            "total_staged": len(joined_df),
            "skipped_count": len(existing_sha1s) if existing_sha1s else 0,
        },
    )
