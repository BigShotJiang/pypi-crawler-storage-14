"""
Logician Dataset Recipe with FOL Symbolization.

Downloads logician dataset from HuggingFace Hub, extracts first-order logic
formulas, and encodes them symbolically with pysymbolizer.
"""
from __future__ import annotations
from pathlib import Path
from typing import List, Dict, Any, Tuple, Optional
import re
import json

import numpy as np

from ..api.recipes import RecipeContext
from ..recipes.base import RecipeOutput, SubDataset


def _normalize_logic_symbols(s: str) -> str:
    """Normalize common unicode/math logic symbols and synonyms to ASCII.

    This helps the downstream parser accept formulas that use symbols like
    ∀, ∃, ∧, ∨, ¬, →, ↔ or words like iff/implies.
    """
    replacements = [
        ("∀", "forall "),
        ("∃", "exists "),
        ("→", "->"),
        ("↔", "<->"),
        ("⇒", "->"),
        ("⇔", "<->"),
        ("∧", " and "),
        ("∨", " or "),
        ("¬", " ~"),
        ("⊢", " |- "),
        ("⟹", "->"),
        ("⟺", "<->"),
    ]
    s2 = s
    for a, b in replacements:
        s2 = s2.replace(a, b)
    # Common English synonyms
    s2 = re.sub(r"\biff\b", "<->", s2, flags=re.IGNORECASE)
    s2 = re.sub(r"\bimplies\b", "->", s2, flags=re.IGNORECASE)
    s2 = re.sub(r"\bnot\b", "~", s2, flags=re.IGNORECASE)
    return s2


def _extract_formulas_from_text(text: str) -> List[str]:
    """
    Extract pure FOL formulas from text, stripping natural language wrappers.

    Looks for patterns like:
    - "forall x: P(x) -> Q(x)"
    - "exists y: R(y)"
    - Formulas with logic operators (->, <->, or, and, ~)

    Strips natural language prefixes/suffixes like:
    - "From ... we can infer ..."
    - "Therefore ..."
    - "... via existential introduction"

    Args:
        text: Text possibly containing logic formulas

    Returns:
        List of extracted pure formula strings (validated by attempting parse)
    """
    formulas = []

    # Try to import parser for validation (if available)
    try:
        from pysymbolizer.parsers.logician import parse_logician
        has_parser = True
    except ImportError:
        has_parser = False

    # Split on common delimiters
    chunks = re.split(r'[.?;]|\bTherefore\b|\bThus\b|\bFinally\b', text)

    for chunk in chunks:
        chunk = chunk.strip()
        if not chunk:
            continue

        # Check if it looks like it contains a formula
        has_quantifier = bool(re.search(r'\b(forall|exists)\b|[∀∃]', chunk, re.IGNORECASE))
        has_logic_op = bool(re.search(r'(->|<->|\bor\b|\band\b|~|\bnot\b|[∧∨¬→↔])', chunk, re.IGNORECASE))
        has_predicate = bool(re.search(r'[A-Za-z_][A-Za-z_0-9]*\s*\(', chunk))

        if not (has_quantifier or (has_logic_op and has_predicate)):
            continue

        # Extract formula candidates using multiple strategies
        candidates = []

        # Strategy 1: Find quantified formulas
        # Pattern: (forall|exists|∀|∃) var: formula_body
        quantified_pattern = r'((?:forall|exists|∀|∃)\s*\w+\s*:\s*[^\n]+)'
        for match in re.finditer(quantified_pattern, chunk, re.IGNORECASE):
            candidates.append(match.group(1).strip())

        # Strategy 2: Try contents inside backticks or quotes as a single candidate
        for m in re.finditer(r'`([^`]+)`|"([^"]+)"|\'([^\']+)\'', chunk):
            seg = next(g for g in m.groups() if g)
            candidates.append(seg.strip())

        # Strategy 3: Try the whole chunk
        candidates.append(chunk)

        # Strategy 4: Remove common natural language prefixes/suffixes
        cleaned = chunk
        # Remove prefix patterns
        cleaned = re.sub(r'^(?:From|Can we|What can|Therefore|Thus)\s+', '', cleaned, flags=re.IGNORECASE)
        cleaned = re.sub(r'^(?:we|it|this)\s+(?:can\s+)?(?:infer|derive)\s+', '', cleaned, flags=re.IGNORECASE)
        # Remove suffix patterns
        cleaned = re.sub(r'\s+(?:via|using|through|by|can|from|we|name|if possible).*$', '', cleaned, flags=re.IGNORECASE)
        # Remove question marks and trailing text
        cleaned = re.sub(r'\?.*$', '', cleaned)
        candidates.append(cleaned.strip())

        # Try each candidate
        for candidate in candidates:
            if not candidate or len(candidate) < 5:
                continue

            # If parser available, validate
            if has_parser:
                try:
                    # Try raw candidate, then normalized variant in case symbols slipped through
                    try:
                        parse_logician(candidate)
                        validated = candidate
                    except Exception:
                        candidate2 = _normalize_logic_symbols(candidate)
                        parse_logician(candidate2)
                        validated = candidate2
                    formulas.append(validated)
                    break  # Found valid formula, move to next chunk
                except:
                    continue
            else:
                # Without parser, use heuristic validation
                # Must have quantifier or (logic op + predicate)
                if has_quantifier or (has_logic_op and has_predicate):
                    # Additional check: shouldn't have too many English words
                    words = candidate.lower().split()
                    english_words = ['can', 'we', 'from', 'infer', 'via', 'using', 'therefore',
                                    'thus', 'what', 'name', 'if', 'possible', 'them', 'step',
                                    'rule', 'being', 'used', 'each']
                    english_count = sum(1 for w in words if w in english_words)

                    # If less than 20% English words, probably a formula
                    if len(words) == 0 or english_count / len(words) < 0.2:
                        formulas.append(candidate)
                        break

    return formulas



def _count_quantifiers(text: str) -> Tuple[int, int]:
    """
    Count forall and exists quantifiers in text.

    Args:
        text: Text to analyze

    Returns:
        (n_forall, n_exists) tuple
    """
    n_forall = len(re.findall(r'\bforall\b', text, re.IGNORECASE))
    n_exists = len(re.findall(r'\bexists\b', text, re.IGNORECASE))
    return n_forall, n_exists


def _symbolize_formula(
    formula_str: str,
    adapter: Any  # SymPyGodelAdapter
) -> Tuple[Optional[str], Optional[str]]:
    """
    Symbolize a single formula using pysymbolizer.

    Args:
        formula_str: Formula string to symbolize
        adapter: pysymbolizer adapter

    Returns:
        (tokens_json, bits_hex) or (None, None) if parsing fails
    """
    try:
        from pysymbolizer.parsers.logician import parse_logician

        # Parse
        expr = parse_logician(formula_str)

        # Encode
        bits_packed = adapter.encode_expr(expr, flatten=False, pack_to_bytes=True)
        toks = adapter.decode_expr_tokens(adapter.encode_expr(expr, flatten=False))

        # Serialize
        tokens_json = json.dumps(toks, ensure_ascii=False)
        bits_hex = np.asarray(bits_packed).tobytes().hex()

        return tokens_json, bits_hex

    except Exception:
        # Silently fail - not all formulas will parse
        return None, None


def logician(
    ctx: RecipeContext,
    repo_id: str = "euclaise/logician",
    revision: str = "main",
    splits: Tuple[str, ...] = ("train",),
    symbolize: bool = True,
    codebook_m: int | None = 16,
) -> RecipeOutput:
    """
    Create logician dataset with FOL symbolization via pysymbolizer.

    Downloads logician dataset from HuggingFace Hub, extracts first-order
    logic formulas, and optionally encodes them with Gödel codes for
    strict Hamming geometry.

    Args:
        ctx: Recipe context
        repo_id: HuggingFace repo ID
        revision: Git revision (branch/tag/commit)
        splits: Which splits to include ("train", etc.)
        symbolize: If True, use pysymbolizer to encode formulas
        codebook_m: Gödel codebook length (for strict Hamming distance)

    Returns:
        RecipeOutput with main dataset and subdatasets

    Main dataset columns:
        - id: sample ID
        - instruction: logic problem/question
        - response: formal logic response
        - source: LogicInference_OA, EQUATE, or FOLIO
        - instruction_length: character count
        - response_length: character count
        - n_formulas: number of extracted formulas
        - n_forall, n_exists: quantifier counts

    Formulas subdataset columns:
        - id: sample ID (foreign key to main)
        - formula_idx: formula index within sample
        - formula: original formula string
        - formula_source: "instruction" or "response"
        - tokens_json: JSON array of canonical tokens (if symbolize=True)
        - bits_hex: hex-encoded Gödel bitstring (if symbolize=True)

    Examples:
        >>> import warpdata as wd
        >>> result = wd.run_recipe(
        ...     "logician",
        ...     "warpdata://logic/logician",
        ...     with_materialize=True
        ... )
        >>> main = wd.load("warpdata://logic/logician", as_format="pandas")
        >>> formulas = wd.load("warpdata://logic/logician-formulas", as_format="pandas")
    """
    if symbolize:
        try:
            from pysymbolizer import adapter_lmode_from_corpus, L_DOM
            from pysymbolizer.parsers.logician import parse_logician
        except Exception as e:
            raise RuntimeError(
                "pysymbolizer with FOL support required for symbolize=True. "
                "Ensure pysymbolizer is up to date with FOL parser."
            ) from e

    print(f"📊 Processing logician from {repo_id}@{revision}")

    rows_main: List[Dict[str, Any]] = []
    formulas_rows: List[Dict[str, Any]] = []
    corpus_formulas: List[str] = []  # Raw formula strings for building adapter

    sample_id = 0
    for split in splits:
        # HF parquet path (in data/ subdirectory)
        src = f"hf://datasets/{repo_id}/data/{split}-00000-of-00001.parquet"
        print(f"   Downloading {split} split from HF Hub...")
        local = ctx.download(src)
        rel = ctx.engine.conn.read_parquet(str(local))
        df = rel.df()

        print(f"   Processing {len(df)} samples from {split}...")
        for _, r in df.iterrows():
            instruction = str(r.get("instruction", ""))
            response = str(r.get("response", ""))
            source = str(r.get("source", ""))

            # Extract formulas
            inst_formulas = _extract_formulas_from_text(instruction)
            resp_formulas = _extract_formulas_from_text(response)

            # Count quantifiers
            full_text = instruction + " " + response
            n_forall, n_exists = _count_quantifiers(full_text)

            rows_main.append({
                "id": sample_id,
                "instruction": instruction,
                "response": response,
                "source": source,
                "instruction_length": len(instruction),
                "response_length": len(response),
                "n_formulas": len(inst_formulas) + len(resp_formulas),
                "n_forall": n_forall,
                "n_exists": n_exists,
            })

            # Store formulas for corpus
            if symbolize:
                corpus_formulas.extend(inst_formulas + resp_formulas)

            # Track formulas for this sample
            for idx, formula in enumerate(inst_formulas):
                formulas_rows.append({
                    "id": sample_id,
                    "formula_idx": idx,
                    "formula": formula,
                    "formula_source": "instruction",
                    "tokens_json": None,
                    "bits_hex": None,
                })

            for idx, formula in enumerate(resp_formulas, start=len(inst_formulas)):
                formulas_rows.append({
                    "id": sample_id,
                    "formula_idx": idx,
                    "formula": formula,
                    "formula_source": "response",
                    "tokens_json": None,
                    "bits_hex": None,
                })

            sample_id += 1

    print(f"   Total samples: {len(rows_main)}")
    print(f"   Total formulas: {len(formulas_rows)}")

    # Build symbolic adapter if requested
    adapter = None
    if symbolize and corpus_formulas:
        print(f"   Building symbolic adapter from {len(corpus_formulas)} formulas...")

        # Parse corpus (skip failures)
        parsed_corpus = []
        for formula_str in corpus_formulas:
            try:
                expr = parse_logician(formula_str)
                parsed_corpus.append(expr)
            except Exception:
                # Skip formulas that don't parse
                pass

        print(f"   Successfully parsed {len(parsed_corpus)}/{len(corpus_formulas)} formulas")

        if parsed_corpus:
            adapter = adapter_lmode_from_corpus(
                parsed_corpus,
                scheme="hadamard",
                m=codebook_m,
                domain=L_DOM
            )
            print(f"   Adapter: {adapter}")

            # Encode all formulas
            print("   Encoding formulas...")
            encoded_count = 0
            for row in formulas_rows:
                tokens_json, bits_hex = _symbolize_formula(row["formula"], adapter)
                row["tokens_json"] = tokens_json
                row["bits_hex"] = bits_hex
                if tokens_json is not None:
                    encoded_count += 1

            print(f"   Successfully encoded {encoded_count}/{len(formulas_rows)} formulas")

    # Write main dataset
    import pandas as pd
    main_df_rel = ctx.engine.conn.from_df(pd.DataFrame(rows_main))
    main_out = ctx.work_dir / "main.parquet"
    ctx.write_parquet(main_df_rel, main_out)
    print(f"   Wrote main dataset: {main_out}")

    # Write subdatasets
    subdatasets = {}

    # 1. Formulas subdataset
    if formulas_rows:
        formulas_df_rel = ctx.engine.conn.from_df(pd.DataFrame(formulas_rows))
        formulas_out = ctx.work_dir / "formulas.parquet"
        ctx.write_parquet(formulas_df_rel, formulas_out)
        print(f"   Wrote formulas subdataset: {formulas_out}")

        subdatasets["formulas"] = SubDataset(
            name="formulas",
            files=[formulas_out],
            description=(
                "Extracted logic formulas with optional symbolic "
                "tokens and Gödel encoding."
            ),
            filter_sql=None,
            metadata={"symbolize": bool(adapter is not None)},
        )

        # 1b. Pairs (edges) subdataset: all instruction x response pairs per sample
        try:
            fdf = formulas_df_rel.df()
            inst = fdf[fdf["formula_source"] == "instruction"].copy()
            resp = fdf[fdf["formula_source"] == "response"].copy()

            if not inst.empty and not resp.empty:
                # Cartesian product per id
                pairs = inst.merge(resp, on="id", how="inner", suffixes=("_inst", "_resp"))
                if not pairs.empty:
                    # Keep relevant columns; include tokens/bits if available
                    keep_cols = [
                        "id",
                        "formula_idx_inst",
                        "formula_inst",
                        "tokens_json_inst",
                        "bits_hex_inst",
                        "formula_idx_resp",
                        "formula_resp",
                        "tokens_json_resp",
                        "bits_hex_resp",
                    ]
                    # Rename for clarity
                    pairs = pairs.rename(
                        columns={
                            "formula_idx_x": "formula_idx_inst",
                            "formula_x": "formula_inst",
                            "tokens_json_x": "tokens_json_inst",
                            "bits_hex_x": "bits_hex_inst",
                            "formula_idx_y": "formula_idx_resp",
                            "formula_y": "formula_resp",
                            "tokens_json_y": "tokens_json_resp",
                            "bits_hex_y": "bits_hex_resp",
                        }
                    )
                    # Select/Order columns defensively
                    cols = [c for c in keep_cols if c in pairs.columns]
                    pairs = pairs[cols]

                    pairs_rel = ctx.engine.conn.from_df(pairs)
                    pairs_out = ctx.work_dir / "pairs.parquet"
                    ctx.write_parquet(pairs_rel, pairs_out)
                    subdatasets["pairs"] = SubDataset(
                        name="pairs",
                        files=[pairs_out],
                        description=(
                            "All instruction↔response formula pairs per sample "
                            "(cartesian product)."
                        ),
                        filter_sql=None,
                        metadata={
                            "symbolize": bool(adapter is not None),
                            "note": "Only ids with both sides produce pairs",
                        },
                    )
                    print(f"   Wrote pairs subdataset: {pairs_out}")

                    # Also create a filtered main subdataset with only ids that have pairs
                    paired_ids = set(pairs['id'].drop_duplicates().tolist())
                    import pandas as _pd
                    main_df = _pd.DataFrame(rows_main)
                    main_paired_df = main_df[main_df['id'].isin(paired_ids)]
                    paired_rel = ctx.engine.conn.from_df(main_paired_df)
                    paired_out = ctx.work_dir / "paired.parquet"
                    ctx.write_parquet(paired_rel, paired_out)
                    subdatasets["paired"] = SubDataset(
                        name="paired",
                        files=[paired_out],
                        description=(
                            "Subset of main containing only samples with at least one "
                            "instruction and one response formula."
                        ),
                        filter_sql=None,
                        metadata={"count_ids": len(paired_ids)},
                    )
                    print(f"   Wrote paired subdataset: {paired_out}")
        except Exception:
            # Best effort; skip if anything goes wrong (e.g., missing columns)
            pass

    # 2. Source-based subdatasets
    source_map = {
        "LogicInference_OA": "logicinferenceoa",
        "EQUATE": "equate",
        "FOLIO": "folio",
    }

    for source_type, subdataset_name in source_map.items():
        source_out = ctx.filter_and_write(
            main_df_rel,
            ctx.work_dir / f"{subdataset_name}.parquet",
            filter_sql=f"source = '{source_type}'"
        )
        subdatasets[subdataset_name] = SubDataset(
            name=subdataset_name,
            files=[source_out],
            description=f"Problems from {source_type} dataset",
            filter_sql=f"source = '{source_type}'"
        )
        print(f"   Wrote {subdataset_name} subdataset")

    # Generate documentation
    source_counts = {}
    for source_type in source_map.keys():
        count = sum(1 for r in rows_main if r["source"] == source_type)
        source_counts[source_type] = count

    notes = f"""# Logician Dataset

## Overview
Logic reasoning dataset with first-order logic (FOL) formulas from multiple sources.

## Configuration
- **Splits**: {', '.join(splits)}
- **Total samples**: {len(rows_main)}
- **Total formulas**: {len(formulas_rows)}
- **Symbolization**: {bool(adapter is not None)}
- **Source**: {repo_id}@{revision}

## Source Distribution
"""
    for source_type, count in source_counts.items():
        notes += f"- **{source_type}**: {count} samples\n"

    notes += f"""
## Structure

### Main Dataset
Each row represents one logic problem:
- `id`: unique sample ID
- `instruction`: logic problem or question
- `response`: formal logic response or answer
- `source`: dataset source (LogicInference_OA, EQUATE, FOLIO)
- `instruction_length`, `response_length`: character counts
- `n_formulas`: number of extracted logic formulas
- `n_forall`, `n_exists`: quantifier counts

### Formulas Subdataset
One row per extracted formula:
- `id`: sample ID (links to main dataset)
- `formula_idx`: index within sample
- `formula`: original formula string
- `formula_source`: "instruction" or "response"
"""

    if adapter is not None:
        encoded_count = sum(1 for r in formulas_rows if r.get('tokens_json') is not None)
        notes += f"""- `tokens_json`: JSON array of canonical symbolic tokens
- `bits_hex`: hex-encoded Gödel bitstring for Hamming geometry

### Symbolic Encoding
Formulas are canonicalized and encoded using pysymbolizer L-mode:
- **Alpha-normalization**: Bound variables renamed canonically (forall x ≡ forall y)
- **AC-normalization**: Commutative/associative operators sorted
- **Scheme**: Hadamard (strict Hamming distance)
- **Code length**: {codebook_m} bits per token
- **Vocabulary size**: {adapter.godel.k} tokens
- **Success rate**: {encoded_count}/{len(formulas_rows)} formulas ({100*encoded_count/len(formulas_rows):.1f}%)
- **Config hash**: {adapter.to_config().get('config_hash', 'unknown')}
"""

    notes += """
### Pairs Subdataset (Edges)
All instruction↔response pairs per sample (cartesian product):
- `id`: sample ID
- `formula_idx_inst`, `formula_inst`, `tokens_json_inst`, `bits_hex_inst`
- `formula_idx_resp`, `formula_resp`, `tokens_json_resp`, `bits_hex_resp`
Only samples with at least one formula on both sides will have pairs.

## Dataset Sources

### LogicInference_OA
First-order logic inference problems testing various inference rules.

### EQUATE
Natural language equations and comparisons translated to logic.

### FOLIO
First-order logic inference with structured premises and conclusions.

## Citation
```
@dataset{euclaise_logician,
  author = {euclaise},
  title = {logician},
  year = {2024},
  publisher = {Hugging Face},
  url = {https://huggingface.co/datasets/euclaise/logician}
}
```
"""

    readme = f"""# Logician Dataset

## Quick Start

```python
import warpdata as wd

# Load main dataset
main = wd.load("warpdata://logic/logician", as_format="pandas")

# Load formulas subdataset
formulas = wd.load("warpdata://logic/logician-formulas", as_format="pandas")

# Filter by source
logicinference = wd.load("warpdata://logic/logician-logicinferenceoa", as_format="pandas")
equate = wd.load("warpdata://logic/logician-equate", as_format="pandas")
folio = wd.load("warpdata://logic/logician-folio", as_format="pandas")

# Load instruction↔response pairs (only ids with both sides)
pairs = wd.load("warpdata://logic/logician-pairs", as_format="pandas")
```

## Statistics
- Total problems: {len(rows_main)}
- Extracted formulas: {len(formulas_rows)}
"""
    if adapter is not None:
        encoded_count = sum(1 for r in formulas_rows if r.get('tokens_json') is not None)
        readme += f"- Symbolically encoded: {encoded_count} ({100*encoded_count/len(formulas_rows):.1f}%)\n"

    readme += """
## Examples

### Instruction-Response Pairs
```python
# View sample problems
print(main[["instruction", "response", "source"]].head())
```

### Extracted Formulas
```python
# View formulas with their symbolic encodings
print(formulas[["formula", "formula_source"]].head())

# Load tokens for analysis
import json
tokens = json.loads(formulas.iloc[0]["tokens_json"])
print(tokens)
```
"""

    # Track raw data provenance
    raw_data_paths = []
    hf_cache = Path.home() / ".cache" / "huggingface" / "datasets" / repo_id.replace("/", "___")
    if hf_cache.exists():
        raw_data_paths.append(hf_cache)

    return RecipeOutput(
        main=[main_out],
        subdatasets=subdatasets,
        docs={"notes.md": notes, "README.md": readme},
        metadata={
            "repo_id": repo_id,
            "revision": revision,
            "symbolize": bool(adapter is not None),
            "total_samples": len(rows_main),
            "total_formulas": len(formulas_rows),
            "source_distribution": source_counts,
        },
        raw_data=raw_data_paths,
    )
