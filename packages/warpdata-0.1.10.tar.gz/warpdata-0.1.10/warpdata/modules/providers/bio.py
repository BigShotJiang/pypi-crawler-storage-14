from __future__ import annotations
from ..base import BaseWarpDatasetModule


class LINCSModule(BaseWarpDatasetModule):
    id = "warp.dataset.lincs"
    version = "1.0.0"
    dataset_uri = "warpdata://bio/lincs"


class LINCSGenesModule(BaseWarpDatasetModule):
    id = "warp.dataset.lincs_genes"
    version = "1.0.0"
    dataset_uri = "warpdata://bio/lincs-genes"


class LINCSSamplesModule(BaseWarpDatasetModule):
    id = "warp.dataset.lincs_samples"
    version = "1.0.0"
    dataset_uri = "warpdata://bio/lincs-samples"

