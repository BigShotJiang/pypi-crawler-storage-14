from __future__ import annotations
from ..base import BaseWarpDatasetModule


class ImageNet1KModule(BaseWarpDatasetModule):
    """Provider for vision/imagenet-1k dataset."""

    id = "warp.dataset.imagenet_1k"
    version = "1.0.0"
    dataset_uri = "warpdata://vision/imagenet-1k"


class ImageNet1KSampleModule(BaseWarpDatasetModule):
    """Provider for vision/imagenet-1k-sample dataset."""

    id = "warp.dataset.imagenet_1k_sample"
    version = "1.0.0"
    dataset_uri = "warpdata://vision/imagenet-1k-sample"

