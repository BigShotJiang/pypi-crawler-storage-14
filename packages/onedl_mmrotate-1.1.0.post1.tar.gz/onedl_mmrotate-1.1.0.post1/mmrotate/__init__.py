# Copyright (c) OpenMMLab. All rights reserved.
from .version import __version__

__all__ = ['__version__']
