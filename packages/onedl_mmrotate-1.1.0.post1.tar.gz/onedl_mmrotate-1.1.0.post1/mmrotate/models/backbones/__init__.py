# Copyright (c) OpenMMLab. All rights reserved.
from .re_resnet import ReResNet

__all__ = ['ReResNet']
