from colorama import Fore

def log(type, message):
    if type.lower() == "s":
        print(f"{Fore.GREEN}[SUCCESS]{Fore.RESET} {message}")
    if type.lower() == "w":
        print(f"{Fore.YELLOW}[WARNING]{Fore.RESET} {message}")
    if type.lower() == "e":
        print(f"{Fore.RED}[ERROR]{Fore.RESET} {message}")
    if type.lower() == "i":
        print(f"{Fore.BLUE}[INFO]{Fore.RESET} {message}")



