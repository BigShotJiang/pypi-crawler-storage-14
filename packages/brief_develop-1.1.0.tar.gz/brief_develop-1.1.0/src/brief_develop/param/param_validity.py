import functools
import inspect
from typing import Callable, Any

class ParamValidityError(ValueError):
    """自定义异常类，用于更清晰的错误定位"""
    pass

class param_validity:
    """
    有参类装饰器，验证多个条件表达式是否成立
    
    参数:
        *conditions: 任意数量的条件表达式
    """
    
    def __init__(self, *conditions):

        self.conditions = conditions

        # 预先分析条件函数的参数需求
        self.condition_params = []
    
        for condition in conditions:
        
            sig = inspect.signature(condition)
            param_names = list(sig.parameters.keys())

            # 构建详细的错误信息
            condition_str = getattr(condition, '__name__', f"")
            if condition_str == '<lambda>':
                condition_str = inspect.getsource(condition)
                condition_str = condition_str.split(':',1)[1].split(',',1)[0].strip()
                if '#' in condition_str:
                    condition_str = condition_str.split('#',1)[0].strip()

            self.condition_params.append(self.condition_params_info(names = param_names, condition= condition, condition_str= condition_str))
    
    def __call__(self, func: Callable) -> Callable:
        # 分析被装饰函数的参数信息
        self.func_sig = inspect.signature(func)
       
        
        @functools.wraps(func)
        def wrapper(*args, **kwargs) -> Any:
            
            # 获取参数
            bound_args = self.func_sig.bind(*args, **kwargs)
            bound_args.apply_defaults()
            all_args = bound_args.arguments

            try:

                for condition_params in self.condition_params:
                    condition_args = {}

                    # 提取条件函数需要的参数
                    param_names = condition_params['names']

                    for param_name in param_names:
                        if param_name in all_args:
                            condition_args[param_name] = all_args[param_name]
                        else:
                            raise ParamValidityError(f"参数 '{param_name}' 在被装饰函数中不存在")
                    
                    # 执行条件验证
                    condition = condition_params['condition']

                    if not condition(**condition_args):
                        # 获取条件函数的参数名
                        condition_name = condition_params['condition_str']
                        # 获取参数的实际值
                        param_values = {name: condition_args[name] for name in param_names}
                            
                        # 构建更详细的错误信息
                        error_msg = f"参数 {param_names} 不满足条件 {condition_name}，当前值: {param_values}"
                        raise ParamValidityError(error_msg)
                        
            except Exception as e:
                raise e
            
            # 所有条件都满足，执行原始函数
            try:
                return func(*args, **kwargs)
            except Exception as e:
                raise e
            
        return wrapper
    
    @staticmethod
    def condition_params_info(names = None, condition = None, condition_str = None, value = None) -> dict : 
        return  {
            'names': names,
            'condition': condition,
            'condition_str': condition_str,
        }
    
    