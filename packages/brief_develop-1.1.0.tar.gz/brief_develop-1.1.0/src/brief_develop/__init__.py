
__version__ = "1.1.0"
__author__ = "hh66dw"
__description__ = "一个轻量级的Python开发框架"
__license__ = "MIT"
__all__ = ['BriefTest', '__version__', '__author__', '__description__', '__license__']
