# Brief Develop

一个轻量级的Python开发框架，提供简洁高效的测试工具和参数验证功能。

## ✨ 特性

- **彩色测试输出**: 使用 `termcolor` 提供直观的彩色测试结果展示
- **灵活的测试框架**: 支持正常测试和异常测试，自动统计测试通过率

- **智能参数验证**: 基于装饰器的参数验证，支持复杂条件表达式
- **详细的错误信息**: 提供清晰的错误定位和参数值展示

- **轻量级设计**: 无复杂依赖，易于集成到现有项目
- **Python 3.7+ 兼容**: 支持广泛的Python版本

## 🚀 快速开始

### 前提条件

- Python 3.7 或更高版本
- pip 包管理器

### 安装

#### 从 PyPI 安装（推荐）
```bash
pip install brief-develop
```

#### 从源码安装（开发版本）
```bash
git clone https://gitee.com/hh66dw/brief_develop.git
cd brief_develop
pip install -e .
```

## 📖 使用指南

### 测试框架使用

```python
from brief_develop.test.BriefTest import BriefTest

# 创建测试实例
brief_test = BriefTest()

# 运行正常测试
def test_addition(a,b):
    return a+b

brief_test.run_test(    test_func        = lambda:test_addition(1,1),
                        detail           = lambda:f"test_addition 功能测试",
                        expected_source  = lambda:test_addition(1,1),
                        expected_message = 2
                    )

# 运行异常测试
def test_division_by_zero():
    1 / 0

brief_test.run_test(    test_func        = lambda: test_division_by_zero(),
                        detail           = lambda:f"test_division_by_zero 功能测试",
                        expected_message = "division by zero"
                    )

# 获取测试统计
print(f"测试通过率: {brief_test.get_stats()}%")
```


### 参数验证使用

```python
from brief_develop.param.param_validity import param_validity

# 参数验证
@param_validity(
    lambda username: len(username) >= 3,         
    lambda password: len(password) >= 8,          
    lambda email: '@' in email,                   
)
def create_account(username: str, password: str, email: str) -> str:
    return f"账户创建成功: {username} ({email})"

# 使用预定义的验证函数
def is_adult(age):
    return age >= 18

def has_valid_name(name):
    return len(name) > 0 and name[0].isupper()

@param_validity(is_adult, has_valid_name)
def create_profile(name: str, age: int) -> str:
    return f"个人资料创建成功: {name}, {age}岁"

# 测试示例
try:
   print(create_account("john", "password123", "john@example.com"))  # 应该成功
   print(create_account("admin", "pass", "admin@example.com"))       # 应该失败（密码太短）
except ValueError as e:
   print(f"错误: {e}")
    
try:
   print(create_profile("Bob", 20))  # 应该成功
   print(create_profile("bob", 20))  # 应该失败（首字母小写）
except ValueError as e:
   print(f"错误: {e}")
```

## 📚 API 文档

### BriefTest 类

#### `BriefTest()`
测试框架主类。

**方法：**

- `run_test(test_func, detail=None, expected_source=None, expected_message=None)`
  - **描述**: 运行单个测试用例
  - **参数**: 
    - `test_func`: 测试函数
    - `detail`: 测试描述信息
    - `expected_source`: 期望的源（None 表示期望异常）
    - `expected_message`: 期望的消息内容
  - **返回值**: 布尔值，表示测试是否通过

- `get_stats()`
  - **描述**: 获取测试统计信息
  - **返回值**: 测试通过率（百分比）

- `print_Brief_Test(message, color=None)`
  - **描述**: 彩色打印测试信息
  - **参数**:
    - `message`: 要打印的消息
    - `color`: 颜色名称（如 'red', 'green', 'yellow' 等）

### param_validity 装饰器

#### `@param_validity(*conditions)`
参数验证装饰器。

**参数：**
- `*conditions`: 任意数量的条件函数，每个函数应返回布尔值

## 💻 开发

### 项目结构
```
brief_develop/
├── src/
│   └── brief_develop/
│       ├── __init__.py
│       ├── BriefTest.py
│       └── param_validity.py
├── pyproject.toml
├── requirements.txt
├── LICENSE
└── README.md
```

## 🤝 贡献指南

我们欢迎各种形式的贡献！包括但不限于：

- 代码改进和功能添加
- 文档完善和翻译
- 测试用例补充
- 问题报告和功能建议

**贡献流程：**

1. **Fork 本仓库**
2. **创建特性分支** (`git checkout -b feature/AmazingFeature`)
3. **提交更改** (`git commit -m 'Add some AmazingFeature'`)
4. **推送到分支** (`git push origin feature/AmazingFeature`)
5. **开启 Pull Request**

请确保代码风格一致，并通过所有测试。

## 📝 版本历史

- **v1.1.0** (当前版本): 稳定版本，包含完整的测试框架和参数验证功能
- **v1.0.0**: 初始版本，基础功能实现

## 📄 许可证

本项目基于 MIT 许可证发行。详情请参阅 [LICENSE](LICENSE) 文件。

## 🙏 致谢

- 感谢 `termcolor` 库提供彩色输出功能
- 感谢所有为项目做出贡献的开发者

## 📞 联系方式

- **项目维护者**: hh66dw
- **邮箱**: hh66dw@163.com
- **项目主页**: https://gitee.com/hh66dw/brief_develop
- **问题反馈**: https://gitee.com/hh66dw/brief_develop/issues

## ❓ 常见问题

**Q: 如何解决 "参数不存在" 的错误？**
A: 请确保条件函数中使用的参数名与被装饰函数的参数名完全一致。

**Q: 测试框架支持异步函数吗？**
A: 当前版本主要支持同步函数。

---

**如果这个项目对您有帮助，请给个 ⭐️ 星标支持！**
