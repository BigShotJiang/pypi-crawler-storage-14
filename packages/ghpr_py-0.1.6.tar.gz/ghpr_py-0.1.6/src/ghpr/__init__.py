"""ghpr - GitHub PR/Issue management with local iteration and gist mirroring."""

__version__ = "0.1.0"
