"""
semantics.py3/src/semanticshare/io/__init__.py
Namespace: semanticshare.io
@since 0.0.1

TODO doc link
"""
