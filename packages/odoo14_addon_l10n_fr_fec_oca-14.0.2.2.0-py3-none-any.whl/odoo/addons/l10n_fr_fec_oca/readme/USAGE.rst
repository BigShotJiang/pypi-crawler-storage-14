Pour générer le *FEC*, allez dans le menu *Invoicing > Reporting > France > FEC* qui va démarrer l'assistant de génération du FEC.
