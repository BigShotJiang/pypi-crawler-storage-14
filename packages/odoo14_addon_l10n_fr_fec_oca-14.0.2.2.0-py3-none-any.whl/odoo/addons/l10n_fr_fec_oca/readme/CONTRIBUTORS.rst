* Alexis de Lattre <alexis.delattre@akretion.com>
* Odoo S.A. <https://www.odoo.com/>
