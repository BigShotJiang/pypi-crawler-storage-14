from __future__ import annotations

from .__main__ import *

__version__ = "0.7.1"
__name__ = "MinecraftDockerCLI"
