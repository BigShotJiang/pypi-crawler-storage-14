"""Emitter class for publishing events to Redis Streams."""

import asyncio
import logging
from typing import Any, overload

import orjson
from redis.asyncio import Redis
from redis.exceptions import ConnectionError, RedisError, TimeoutError
from redis.typing import EncodableT, FieldT

from rapids.emitter.context import get_correlation_id
from rapids.events.base import BaseEvent
from rapids.exceptions import EmitError

logger = logging.getLogger(__name__)


class EventEmitter:
    """Publishes events to a Redis Stream.

    Args:
        redis: Async Redis client
        stream: Target stream name (default: "events:all")
        maxlen: Auto-trim stream to this length (default: 100_000)
        max_retries: Maximum retry attempts on failure (default: 3)
        retry_delay: Base delay between retries in seconds (default: 0.1)
    """

    def __init__(
        self,
        redis: Redis,
        stream: str = "events:all",
        maxlen: int | None = 100_000,
        max_retries: int = 3,
        retry_delay: float = 0.1,
    ) -> None:
        if max_retries < 1:
            raise ValueError(f"max_retries must be >= 1, got {max_retries}")
        self._redis = redis
        self._stream = stream
        self._maxlen = maxlen
        self._max_retries = max_retries
        self._retry_delay = retry_delay

    @overload
    async def emit(
        self,
        event: BaseEvent,
        *,
        caused_by: BaseEvent | None = None,
    ) -> str: ...

    @overload
    async def emit(
        self,
        event: list[BaseEvent],
        *,
        caused_by: BaseEvent | None = None,
    ) -> list[str]: ...

    async def emit(
        self,
        event: BaseEvent | list[BaseEvent],
        *,
        caused_by: BaseEvent | None = None,
    ) -> str | list[str]:
        """Emit one or more events to the stream.

        Args:
            event: A single event or list of events to emit
            caused_by: Optional event that caused this one. When provided:
                - Sets causation_id to caused_by.id (if event has no causation_id)
                - Inherits correlation_id from caused_by (if event has no correlation_id)

        Returns:
            The Redis message ID (single event) or list of message IDs (batch)

        Note:
            Batch emit uses Redis pipeline for throughput (1 round-trip instead of N),
            but pipeline does not provide rollback. If some XADDs fail, others may
            succeed. The returned list contains message IDs for successful emits
            and raises EmitError on any failure.

        Correlation ID resolution order (first non-None wins):
            1. Event's explicit correlation_id
            2. caused_by event's correlation_id
            3. Context correlation_id (from correlation_scope)

        Causation ID resolution:
            1. Event's explicit causation_id
            2. caused_by event's id
        """
        if isinstance(event, list):
            if not event:
                return []
            return await self._emit_batch(event, caused_by)
        else:
            return await self._emit_single(event, caused_by)

    async def _emit_batch(
        self,
        events: list[BaseEvent],
        caused_by: BaseEvent | None = None,
    ) -> list[str]:
        """Emit multiple events using Redis pipeline for efficiency.

        Uses a single round-trip to Redis instead of N separate calls.
        Note: Pipeline provides no atomicity - partial failures are possible.

        Raises:
            EmitError: If the pipeline execution fails.
        """
        pipe = self._redis.pipeline()

        # Enqueue all XADDs on the pipeline
        for event in events:
            correlation_id, causation_id = self._resolve_ids(event, caused_by)
            message = self._serialize(event, correlation_id, causation_id)
            pipe.xadd(self._stream, message, maxlen=self._maxlen)

        try:
            results: list[Any] = await pipe.execute()
        except (ConnectionError, TimeoutError, RedisError) as e:
            # Pipeline failed - we don't know which events succeeded
            logger.error(
                "Pipeline failed emitting %d events to stream '%s': %s",
                len(events),
                self._stream,
                e,
            )
            raise EmitError(
                event_type=f"batch[{len(events)}]",
                event_id=events[0].id if events else "unknown",
                stream=self._stream,
                attempts=1,
                cause=e,
            ) from e

        # Convert results to string message IDs
        message_ids: list[str] = []
        for i, result in enumerate(results):
            if isinstance(result, bytes):
                message_ids.append(result.decode())
            elif isinstance(result, Exception):
                # Individual XADD failed within pipeline
                logger.error(
                    "Event '%s' (id=%s) failed in pipeline: %s",
                    events[i].event_type,
                    events[i].id,
                    result,
                )
                raise EmitError(
                    event_type=events[i].event_type,
                    event_id=events[i].id,
                    stream=self._stream,
                    attempts=1,
                    cause=result,
                ) from result
            else:
                message_ids.append(str(result))

        return message_ids

    async def _emit_single(
        self,
        event: BaseEvent,
        caused_by: BaseEvent | None = None,
    ) -> str:
        """Emit a single event to the stream with retry on failure.

        Raises:
            EmitError: If all retry attempts fail.
        """
        correlation_id, causation_id = self._resolve_ids(event, caused_by)
        message = self._serialize(event, correlation_id, causation_id)
        last_error: Exception | None = None

        for attempt in range(1, self._max_retries + 1):
            try:
                message_id: Any = await self._redis.xadd(
                    self._stream,
                    message,
                    maxlen=self._maxlen,
                )
                return (
                    message_id.decode()
                    if isinstance(message_id, bytes)
                    else str(message_id)
                )

            except (ConnectionError, TimeoutError) as e:
                # Retriable errors - connection issues
                last_error = e
                logger.warning(
                    "Redis connection error emitting event '%s' (id=%s) to stream '%s', "
                    "attempt %d/%d: %s",
                    event.event_type,
                    event.id,
                    self._stream,
                    attempt,
                    self._max_retries,
                    e,
                )

            except RedisError as e:
                # Other Redis errors - may or may not be retriable
                last_error = e
                logger.warning(
                    "Redis error emitting event '%s' (id=%s) to stream '%s', "
                    "attempt %d/%d: %s",
                    event.event_type,
                    event.id,
                    self._stream,
                    attempt,
                    self._max_retries,
                    e,
                )

            except Exception as e:
                # Unexpected errors - log and fail immediately
                logger.error(
                    "Unexpected error emitting event '%s' (id=%s) to stream '%s': %s",
                    event.event_type,
                    event.id,
                    self._stream,
                    e,
                )
                raise EmitError(
                    event_type=event.event_type,
                    event_id=event.id,
                    stream=self._stream,
                    attempts=attempt,
                    cause=e,
                ) from e

            # Wait before retry with exponential backoff
            if attempt < self._max_retries:
                delay = self._retry_delay * (2 ** (attempt - 1))
                await asyncio.sleep(delay)

        # All retries exhausted
        if last_error is None:
            raise RuntimeError(
                f"Retries exhausted for event '{event.event_type}' (id={event.id}) "
                f"but no error was captured. This indicates a bug in the retry logic."
            )
        raise EmitError(
            event_type=event.event_type,
            event_id=event.id,
            stream=self._stream,
            attempts=self._max_retries,
            cause=last_error,
        ) from last_error

    def _resolve_ids(
        self,
        event: BaseEvent,
        caused_by: BaseEvent | None,
    ) -> tuple[str | None, str | None]:
        """Resolve correlation_id and causation_id for an event.

        Resolution order for correlation_id (first non-None wins):
            1. Event's explicit correlation_id
            2. caused_by event's correlation_id
            3. Context correlation_id (from correlation_scope)

        Resolution for causation_id:
            1. Event's explicit causation_id
            2. caused_by event's id

        Returns:
            Tuple of (correlation_id, causation_id)
        """
        # Resolve correlation_id
        correlation_id = event.correlation_id
        if correlation_id is None and caused_by is not None:
            correlation_id = caused_by.correlation_id
        if correlation_id is None:
            correlation_id = get_correlation_id()

        # Resolve causation_id
        causation_id = event.causation_id
        if causation_id is None and caused_by is not None:
            causation_id = caused_by.id

        return correlation_id, causation_id

    def _serialize(
        self,
        event: BaseEvent,
        correlation_id: str | None = None,
        causation_id: str | None = None,
    ) -> dict[FieldT, EncodableT]:
        """Serialize an event to Redis message format.

        Args:
            event: The event to serialize
            correlation_id: Resolved correlation ID (overrides event's value)
            causation_id: Resolved causation ID (overrides event's value)

        Returns a dict with string keys and values suitable for XADD.
        """
        # Get the event data as JSON (excluding base fields)
        event_data = event.model_dump(
            exclude={"id", "timestamp", "correlation_id", "causation_id", "metadata"},
            mode="json",
        )

        return {
            "event_type": event.event_type,
            "schema_version": str(event.schema_version),
            "data": _json_dumps(event_data),
            "id": event.id,
            "timestamp": event.timestamp.isoformat(),
            "correlation_id": correlation_id or "",
            "causation_id": causation_id or "",
            "metadata": _json_dumps(event.metadata),
        }


def _json_dumps(obj: Any) -> str:
    """Convert object to JSON string using orjson (~6x faster than stdlib).

    Raises:
        TypeError: If the object contains non-serializable values,
            with context about what failed to serialize.
    """
    try:
        return orjson.dumps(obj).decode()  # orjson returns bytes
    except TypeError as e:
        raise TypeError(
            f"Failed to serialize object to JSON: {e}. "
            f"Object type: {type(obj).__name__}, repr: {repr(obj)[:200]}"
        ) from e
