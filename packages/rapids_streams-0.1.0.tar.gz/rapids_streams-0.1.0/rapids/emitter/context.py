"""Context variables for correlation and causation tracking.

This module provides async-safe context propagation for correlation IDs,
allowing related events to be grouped together automatically.

Example:
    async with correlation_scope() as cid:
        await emitter.emit(UploadStarted(filename="report.pdf"))
        doc = await process_file()
        await emitter.emit(DocumentCreated(doc_id=doc.id))
        # Both events share the same correlation_id
"""

from collections.abc import AsyncGenerator
from contextlib import asynccontextmanager
from contextvars import ContextVar
from uuid import uuid4

# Context variables for automatic correlation tracking
_correlation_id: ContextVar[str | None] = ContextVar("correlation_id", default=None)
_causation_id: ContextVar[str | None] = ContextVar("causation_id", default=None)


def get_correlation_id() -> str | None:
    """Get the current correlation ID from context.

    Returns:
        The current correlation ID, or None if not in a correlation scope.
    """
    return _correlation_id.get()


def get_causation_id() -> str | None:
    """Get the current causation ID from context.

    Returns:
        The current causation ID, or None if not set.
    """
    return _causation_id.get()


def set_correlation_id(cid: str | None) -> None:
    """Set the correlation ID in context.

    Args:
        cid: The correlation ID to set, or None to clear.
    """
    _correlation_id.set(cid)


def set_causation_id(cid: str | None) -> None:
    """Set the causation ID in context.

    Args:
        cid: The causation ID to set, or None to clear.
    """
    _causation_id.set(cid)


@asynccontextmanager
async def correlation_scope(
    correlation_id: str | None = None,
) -> AsyncGenerator[str, None]:
    """Context manager that establishes a correlation scope.

    All events emitted within this scope will automatically have the same
    correlation_id (unless explicitly overridden on the event).

    Args:
        correlation_id: Optional correlation ID. If None, generates a UUID.

    Yields:
        The correlation ID for this scope.

    Example:
        async with correlation_scope() as cid:
            await emitter.emit(UploadStarted(filename="report.pdf"))
            doc = await process_file()
            await emitter.emit(DocumentCreated(doc_id=doc.id))
            await emitter.emit(UploadCompleted(doc_id=doc.id))
            # All three events share the same correlation_id (cid)

        # Can also use explicit ID:
        async with correlation_scope("request-123") as cid:
            assert cid == "request-123"
            await emitter.emit(SomeEvent(...))
    """
    cid = correlation_id if correlation_id is not None else str(uuid4())
    token = _correlation_id.set(cid)
    try:
        yield cid
    finally:
        _correlation_id.reset(token)
