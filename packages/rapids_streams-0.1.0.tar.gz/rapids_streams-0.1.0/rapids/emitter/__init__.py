"""Emitter package for Rapids."""

from rapids.emitter.context import (
    correlation_scope,
    get_causation_id,
    get_correlation_id,
    set_causation_id,
    set_correlation_id,
)
from rapids.emitter.core import EventEmitter

__all__ = [
    "EventEmitter",
    # Correlation context
    "correlation_scope",
    "get_correlation_id",
    "get_causation_id",
    "set_correlation_id",
    "set_causation_id",
]
