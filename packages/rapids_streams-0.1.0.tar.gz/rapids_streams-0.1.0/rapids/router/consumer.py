"""StreamConsumer wrapping Redis consumer group operations."""

import asyncio
import logging
from dataclasses import dataclass
from enum import Enum
from typing import Any

from redis.asyncio import Redis
from redis.exceptions import ResponseError

logger = logging.getLogger(__name__)


class ReadMode(str, Enum):
    """What kind of messages to read from the stream."""

    NEW = ">"  # Only new undelivered messages (normal consumption)
    PENDING = "0"  # Own pending messages (recovery on startup)


class GroupStartPosition(str, Enum):
    """Where a new consumer group starts reading in stream history."""

    BEGINNING = "0"  # Replay all historical messages
    LATEST = "$"  # Only messages after group creation


@dataclass(frozen=True, slots=True)
class ConsumerLag:
    """Consumer group lag metrics.

    Provides information about stream consumption state for health checks
    and monitoring.

    Attributes:
        stream_length: Total messages in the stream (XLEN)
        pending_count: Messages pending acknowledgment across the group
        consumers_count: Number of active consumers in the group
        last_delivered_id: Last message ID delivered to the group
        lag: Messages behind stream head (Redis 7.0+, None for older versions)
    """

    stream_length: int
    pending_count: int
    consumers_count: int
    last_delivered_id: str
    lag: int | None


class StreamConsumer:
    """Wraps Redis consumer group operations.

    Handles XGROUP CREATE, XREADGROUP, and XACK operations
    for consuming messages from a Redis Stream.
    """

    def __init__(
        self,
        redis: Redis,
        stream: str,
        group: str,
        consumer: str,
        batch_size: int = 10,
        block_ms: int = 5000,
        group_start_id: str | GroupStartPosition = GroupStartPosition.BEGINNING,
    ) -> None:
        """Initialize the stream consumer.

        Args:
            redis: Async Redis client
            stream: Stream name to consume from
            group: Consumer group name
            consumer: Unique consumer identifier
            batch_size: Number of messages to read per XREADGROUP
            block_ms: Blocking read timeout in milliseconds
            group_start_id: Starting message ID for new consumer groups (XGROUP CREATE).
                "0" = read from beginning (default, replay all history)
                "$" = read only new messages (from group creation time)
                "1234567890123-0" = start from specific message ID
        """
        self._redis = redis
        self._stream = stream
        self._group = group
        self._consumer = consumer
        self._batch_size = batch_size
        self._block_ms = block_ms
        self._group_start_id = group_start_id

    async def ensure_group(self) -> None:
        """Create the consumer group if it doesn't exist.

        Uses XGROUP CREATE with MKSTREAM to create both the
        stream and consumer group if they don't exist.

        If the group already exists and group_start_id="$", updates
        the group's last-delivered-ID to the current stream end.
        """
        try:
            await self._redis.xgroup_create(
                self._stream,
                self._group,
                id=self._group_start_id,
                mkstream=True,  # Create stream if needed
            )
            logger.info(
                f"Created consumer group '{self._group}' for stream '{self._stream}'"
            )
        except ResponseError as e:
            if "BUSYGROUP" in str(e):
                # Group already exists
                logger.debug(
                    f"Consumer group '{self._group}' already exists for stream '{self._stream}'"
                )
                # If group_start_id="$" (LATEST), update the group to start from current position
                if self._group_start_id in ("$", GroupStartPosition.LATEST):
                    await self._redis.xgroup_setid(
                        self._stream,
                        self._group,
                        id="$",
                    )
                    logger.debug(
                        f"Reset consumer group '{self._group}' to current stream position"
                    )
            else:
                raise

    async def read(self, read_mode: ReadMode = ReadMode.NEW) -> list[dict[str, Any]]:
        """Read messages from the stream.

        Args:
            read_mode: What kind of messages to read (XREADGROUP start ID):
                - ReadMode.NEW = Only new undelivered messages (default, normal consumption)
                - ReadMode.PENDING = Own pending messages (for recovery on startup)

        Returns:
            List of messages, each as a dict with 'id', 'data', and 'delivery_count' keys.
            delivery_count is 1 for new messages, fetched from XPENDING for pending.
        """
        # Don't block when reading pending messages (PENDING)
        # to avoid hanging when there are no pending messages
        block_ms = self._block_ms if read_mode == ReadMode.NEW else None

        result = await self._redis.xreadgroup(
            groupname=self._group,
            consumername=self._consumer,
            streams={self._stream: read_mode.value},
            count=self._batch_size,
            block=block_ms,
        )

        if not result:
            return []

        # Result format: [[stream_name, [(msg_id, data), ...]]]
        messages = []
        for _stream_name, stream_messages in result:
            for msg_id, data in stream_messages:
                # Decode bytes to strings
                decoded_id = msg_id.decode() if isinstance(msg_id, bytes) else msg_id
                decoded_data = {
                    k.decode() if isinstance(k, bytes) else k: v.decode()
                    if isinstance(v, bytes)
                    else v
                    for k, v in data.items()
                }
                messages.append(
                    {
                        "id": decoded_id,
                        "data": decoded_data,
                        # New messages have delivery_count=1, pending will be updated below
                        "delivery_count": 1,
                    }
                )

        # For pending messages, fetch actual delivery counts from XPENDING
        if read_mode == ReadMode.PENDING and messages:
            delivery_counts = await self._get_delivery_counts(
                [m["id"] for m in messages]
            )
            for msg in messages:
                if msg["id"] in delivery_counts:
                    msg["delivery_count"] = delivery_counts[msg["id"]]

        return messages

    async def _get_delivery_counts(self, message_ids: list[str]) -> dict[str, int]:
        """Get delivery counts for specific message IDs using XPENDING.

        Args:
            message_ids: List of message IDs to query

        Returns:
            Dict mapping message_id -> delivery_count
        """
        if not message_ids:
            return {}

        # XPENDING with range returns detailed info per message
        # We need to find min/max IDs to query the range
        min_id = min(message_ids)
        max_id = max(message_ids)

        # XPENDING stream group [start end count] returns:
        # [[msg_id, consumer, idle_time, delivery_count], ...]
        # Filter by consumer to avoid counting other consumers' messages in the range
        pending_info = await self._redis.xpending_range(
            self._stream,
            self._group,
            min=min_id,
            max=max_id,
            count=len(message_ids),
            consumername=self._consumer,
        )

        counts: dict[str, int] = {}
        for entry in pending_info:
            msg_id = entry["message_id"]
            if isinstance(msg_id, bytes):
                msg_id = msg_id.decode()
            counts[msg_id] = entry["times_delivered"]

        return counts

    async def ack(self, message_id: str) -> None:
        """Acknowledge a processed message.

        Args:
            message_id: The Redis message ID to acknowledge
        """
        await self._redis.xack(self._stream, self._group, message_id)

    async def autoclaim(
        self,
        min_idle_ms: int = 60_000,
        start: str = "0-0",
        count: int = 10,
    ) -> tuple[str, list[dict[str, Any]]]:
        """Claim pending messages from dead consumers using XAUTOCLAIM.

        XAUTOCLAIM (Redis 6.2+) atomically scans for and claims idle messages
        from other consumers. More efficient than XPENDING + XCLAIM.

        Args:
            min_idle_ms: Minimum idle time to claim (default: 60s)
            start: Cursor for scanning ("0-0" to start, then use returned cursor)
            count: Maximum messages to claim per call

        Returns:
            Tuple of (next_cursor, claimed_messages):
            - next_cursor: Use for next call ("0-0" means scan complete)
            - claimed_messages: List of messages with 'id', 'data', 'delivery_count'
        """
        # XAUTOCLAIM returns: [next_cursor, [[id, {fields}], ...], [deleted_ids]]
        result = await self._redis.xautoclaim(
            self._stream,
            self._group,
            self._consumer,
            min_idle_time=min_idle_ms,
            start_id=start,
            count=count,
        )

        next_cursor = result[0]
        if isinstance(next_cursor, bytes):
            next_cursor = next_cursor.decode()

        claimed_entries = result[1] if len(result) > 1 else []

        messages = []
        for msg_id, data in claimed_entries:
            if data is None:
                continue  # Message was deleted from stream
            decoded_id = msg_id.decode() if isinstance(msg_id, bytes) else msg_id
            decoded_data = {
                k.decode() if isinstance(k, bytes) else k: v.decode()
                if isinstance(v, bytes)
                else v
                for k, v in data.items()
            }
            messages.append(
                {
                    "id": decoded_id,
                    "data": decoded_data,
                    # Will be updated below with actual delivery count
                    "delivery_count": 1,
                }
            )

        # Fetch actual delivery counts for claimed messages
        if messages:
            delivery_counts = await self._get_delivery_counts(
                [m["id"] for m in messages]
            )
            for msg in messages:
                if msg["id"] in delivery_counts:
                    msg["delivery_count"] = delivery_counts[msg["id"]]

        return next_cursor, messages

    async def get_lag(self) -> ConsumerLag:
        """Get current lag metrics for this consumer group.

        Queries Redis via XLEN, XINFO GROUPS, and XPENDING in parallel
        for efficient metrics collection.

        Returns:
            ConsumerLag with stream and consumer group metrics.

        Raises:
            ResponseError: If stream or group doesn't exist.
        """
        # Execute queries in parallel for efficiency
        stream_length, groups_info, pending_info = await asyncio.gather(
            self._redis.xlen(self._stream),
            self._redis.xinfo_groups(self._stream),
            self._redis.xpending(self._stream, self._group),
        )

        # Find our group in the groups list
        group_info = None
        for g in groups_info:
            name = g.get("name", b"")
            if isinstance(name, bytes):
                name = name.decode()
            if name == self._group:
                group_info = g
                break

        if group_info is None:
            raise ResponseError(f"Consumer group '{self._group}' not found")

        # Extract last-delivered-id
        last_id = group_info.get("last-delivered-id", b"")
        if isinstance(last_id, bytes):
            last_id = last_id.decode()

        # Extract lag (Redis 7.0+ only, None for older versions)
        lag = group_info.get("lag")

        return ConsumerLag(
            stream_length=stream_length,
            pending_count=pending_info.get("pending", 0),
            consumers_count=group_info.get("consumers", 0),
            last_delivered_id=last_id,
            lag=lag,
        )
