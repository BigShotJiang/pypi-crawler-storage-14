"""EventRouter class with decorator and consume loop."""

import asyncio
import contextlib
import logging
import os
import socket
import types
from collections.abc import Awaitable, Callable
from datetime import UTC, datetime
from typing import Any, TypeVar, overload

import orjson
from redis.asyncio import Redis

from rapids.backoff import Backoff, exponential
from rapids.events.base import BaseEvent, Event, get_event_class
from rapids.events.generic import GenericEvent
from rapids.exceptions import (
    DeserializationError,
    MaxRetriesExceededError,
    NonRetryableError,
)
from rapids.router.consumer import (
    ConsumerLag,
    GroupStartPosition,
    ReadMode,
    StreamConsumer,
)
from rapids.router.handlers import HandlerRegistration, Target, resolve_event_types

logger = logging.getLogger(__name__)

# TypeVar for generic event types in @router.on() overloads
_EventT = TypeVar("_EventT", bound=BaseEvent)


def _generate_consumer_name() -> str:
    """Generate a unique consumer name from hostname and PID."""
    return f"{socket.gethostname()}-{os.getpid()}"


class EventRouter:
    """Routes events from Redis Streams to typed handlers.

    Example:
        router = EventRouter(redis=redis, group="my-service")

        @router.on(DocumentCreated)
        async def handle(event: DocumentCreated):
            print(f"Document {event.doc_id} created")

        await router.start()
    """

    def __init__(
        self,
        redis: Redis,
        stream: str = "events:all",
        group: str = "default",
        consumer: str | None = None,
        batch_size: int = 10,
        block_ms: int = 5000,
        handler_timeout: float = 30.0,
        group_start_id: str | GroupStartPosition = GroupStartPosition.BEGINNING,
        claim_interval: int = 10,
        claim_min_idle_ms: int = 60_000,
        # Retry and DLQ settings
        default_retries: int = 0,
        default_backoff: Backoff | None = None,
        max_deliveries: int = 5,
        dlq_stream: str | None = None,
        dlq_maxlen: int | None = 10_000,
    ) -> None:
        """Initialize the event router.

        Args:
            redis: Async Redis client
            stream: Stream to consume from (default: "events:all")
            group: Consumer group name (default: "default")
            consumer: Unique consumer identifier (auto-generated if None)
            batch_size: Messages per XREADGROUP (default: 10)
            block_ms: Blocking read timeout in ms (default: 5000)
            handler_timeout: Max seconds for handler execution (default: 30.0)
            group_start_id: Starting message ID for new consumer groups (XGROUP CREATE).
                "0" = read from beginning (default, replay all history)
                "$" = read only new messages (from group creation time)
                "1234567890123-0" = start from specific message ID
            claim_interval: XAUTOCLAIM every N read cycles (default: 10)
            claim_min_idle_ms: Claim messages idle longer than this (default: 60000ms)
            default_retries: Default quick in-process retries (default: 0, disabled)
            default_backoff: Default backoff strategy for quick retries (default: exponential)
            max_deliveries: Max Redis delivery count before DLQ (default: 5)
            dlq_stream: DLQ stream name (default: None, DLQ disabled)
            dlq_maxlen: Max DLQ stream length, approximate trim (default: 10000, None to disable)
        """
        self._redis = redis
        self._stream = stream
        self._group = group
        self._consumer = consumer or _generate_consumer_name()
        self._batch_size = batch_size
        self._block_ms = block_ms
        self._handler_timeout = handler_timeout
        self._group_start_id = group_start_id
        self._claim_interval = claim_interval
        self._claim_min_idle_ms = claim_min_idle_ms

        # Retry and DLQ settings
        self._default_retries = default_retries
        self._default_backoff = default_backoff or exponential()
        self._max_deliveries = max_deliveries
        self._dlq_stream = dlq_stream
        self._dlq_maxlen = dlq_maxlen

        self._handlers: list[HandlerRegistration] = []
        self._running = False
        self._stream_consumer: StreamConsumer | None = None
        self._consume_task: asyncio.Task[None] | None = None

        # State for inline claiming from dead consumers
        self._claim_cursor: str = "0-0"
        self._reads_since_claim: int = 0

    @overload
    def on(
        self,
        target: type[_EventT],
        *,
        timeout: float | None = None,
        retries: int | None = None,
        backoff: Backoff | None = None,
        retryable_exceptions: tuple[type[Exception], ...] = (Exception,),
    ) -> Callable[
        [Callable[[_EventT], Awaitable[None]]], Callable[[_EventT], Awaitable[None]]
    ]: ...

    @overload
    def on(
        self,
        target: str,
        *,
        timeout: float | None = None,
        retries: int | None = None,
        backoff: Backoff | None = None,
        retryable_exceptions: tuple[type[Exception], ...] = (Exception,),
    ) -> Callable[
        [Callable[[Event], Awaitable[None]]], Callable[[Event], Awaitable[None]]
    ]: ...

    @overload
    def on(
        self,
        target: types.UnionType,
        *,
        timeout: float | None = None,
        retries: int | None = None,
        backoff: Backoff | None = None,
        retryable_exceptions: tuple[type[Exception], ...] = (Exception,),
    ) -> Callable[
        [Callable[[BaseEvent], Awaitable[None]]], Callable[[BaseEvent], Awaitable[None]]
    ]: ...

    def on(
        self,
        target: Target,
        *,
        timeout: float | None = None,
        retries: int | None = None,
        backoff: Backoff | None = None,
        retryable_exceptions: tuple[type[Exception], ...] = (Exception,),
    ) -> Callable[[Callable[[Any], Awaitable[None]]], Callable[[Any], Awaitable[None]]]:
        """Decorator to register an event handler.

        Supports multiple subscription patterns:
            @router.on(DocumentCreated)           # Single event class
            @router.on(DocumentEvent)             # Base class (all subclasses)
            @router.on(DocCreated | DocDeleted)   # Union of classes
            @router.on("document.*")              # Glob pattern
            @router.on("*")                       # Catch-all

        Reliability options:
            @router.on(DocumentCreated, timeout=60)  # Custom timeout
            @router.on(MyEvent, retries=3, backoff=exponential(base=2))
            @router.on(MyEvent, retryable_exceptions=(ConnectionError, TimeoutError))

        Args:
            target: Event class, union of classes, or string pattern
            timeout: Max execution time in seconds (None = use router default)
            retries: Quick in-process retry attempts with backoff (None = use router default)
            backoff: Backoff strategy for quick retries (None = use router default)
            retryable_exceptions: Exception types that trigger retry (default: all exceptions)

        Returns:
            Decorator function
        """

        def decorator(
            fn: Callable[[Any], Awaitable[None]],
        ) -> Callable[[Any], Awaitable[None]]:
            event_types, event_classes, patterns = resolve_event_types(target)

            registration = HandlerRegistration(
                fn=fn,  # type: ignore[arg-type]
                event_types=event_types,
                event_classes=event_classes,
                patterns=patterns,
                timeout=timeout,
                retries=retries,
                backoff=backoff,
                retryable_exceptions=retryable_exceptions,
            )
            self._handlers.append(registration)

            # Log what was registered
            if patterns:
                logger.debug(
                    f"Registered handler {getattr(fn, '__name__', repr(fn))} "
                    f"for patterns: {patterns}"
                )
            else:
                logger.debug(
                    f"Registered handler {getattr(fn, '__name__', repr(fn))} "
                    f"for event types: {event_types}"
                )
            return fn

        return decorator

    async def start(self) -> None:
        """Start consuming events from the stream.

        Blocks until stop() is called or the task is cancelled.
        """
        self._stream_consumer = StreamConsumer(
            redis=self._redis,
            stream=self._stream,
            group=self._group,
            consumer=self._consumer,
            batch_size=self._batch_size,
            block_ms=self._block_ms,
            group_start_id=self._group_start_id,
        )

        await self._stream_consumer.ensure_group()

        self._running = True
        logger.info(
            f"Starting event router for stream '{self._stream}' "
            f"(group={self._group}, consumer={self._consumer})"
        )

        # Run consume loop in a task so stop() can cancel it promptly
        self._consume_task = asyncio.create_task(self._consume_loop())

        try:
            await self._consume_task
        except asyncio.CancelledError:
            logger.info("Event router task cancelled")
        finally:
            self._consume_task = None

    async def stop(self) -> None:
        """Signal the router to stop consuming.

        Cancels the consume task for prompt shutdown instead of waiting
        for the blocking read to timeout.
        """
        self._running = False
        logger.info("Stopping event router")

        # Cancel the consume task for immediate shutdown
        # Store reference to avoid race condition if task completes between check and cancel
        task = self._consume_task
        if task is not None:
            task.cancel()
            with contextlib.suppress(asyncio.CancelledError):
                await task

    async def get_consumer_lag(self) -> ConsumerLag:
        """Get current lag metrics for this router's consumer group.

        Queries Redis for stream length, group info, and pending message count.
        Can be called while the router is running for health checks or
        ad-hoc monitoring.

        Returns:
            ConsumerLag with stream and consumer group metrics.

        Raises:
            RuntimeError: If router hasn't been started yet.
            ResponseError: If stream or group doesn't exist.
        """
        if self._stream_consumer is None:
            raise RuntimeError(
                "Router not started. Call start() before querying lag, "
                "or use StreamConsumer directly for pre-start queries."
            )
        return await self._stream_consumer.get_lag()

    async def _consume_loop(self) -> None:
        """Main consume loop with inline recovery.

        Two-phase approach following Redis best practices:
        1. On startup: Recover OWN pending messages (XREADGROUP with "0")
        2. Normal mode: Read new messages + periodically XAUTOCLAIM
        """
        if self._stream_consumer is None:
            raise RuntimeError(
                "Stream consumer not initialized. Call start() before running consume loop."
            )

        consecutive_errors = 0

        # PHASE 1: Recover own pending messages on startup
        logger.info("Recovering own pending messages...")
        while self._running:
            try:
                messages = await self._stream_consumer.read(read_mode=ReadMode.PENDING)
                consecutive_errors = 0

                if not messages:
                    logger.info("Own pending messages recovered")
                    break  # Done with own pending

                for msg in messages:
                    await self._process_message(msg)

            except asyncio.CancelledError:
                return
            except Exception:
                consecutive_errors += 1
                delay = min(1.0 * (2**consecutive_errors), 60.0)
                logger.exception(f"Error recovering pending (retry in {delay:.1f}s)")
                await asyncio.sleep(delay)

        # PHASE 2: Normal consumption with inline XAUTOCLAIM
        while self._running:
            try:
                messages = await self._stream_consumer.read(read_mode=ReadMode.NEW)
                consecutive_errors = 0

                for msg in messages:
                    await self._process_message(msg)

                # Inline claiming from dead consumers
                self._reads_since_claim += 1
                if self._reads_since_claim >= self._claim_interval:
                    await self._claim_from_dead_consumers()
                    self._reads_since_claim = 0

            except asyncio.CancelledError:
                logger.info("Consume loop cancelled")
                break
            except Exception:
                consecutive_errors += 1
                delay = min(1.0 * (2**consecutive_errors), 60.0)
                logger.exception(f"Error in consume loop (retry in {delay:.1f}s)")
                await asyncio.sleep(delay)

    async def _process_message(self, msg: dict[str, Any]) -> None:
        """Process a single message from the stream.

        Flow:
        1. Check delivery count vs max_deliveries → DLQ if exceeded
        2. Deserialize to typed event → DLQ on error
        3. Find and run matching handlers with quick retries
        4. Non-retryable error → DLQ
        5. Retryable error after quick retries → leave pending for Redis retry
        6. Success → acknowledge message
        """
        if self._stream_consumer is None:
            raise RuntimeError(
                "Stream consumer not initialized. Call start() before processing messages."
            )

        msg_id = msg["id"]
        raw_data = msg["data"]
        delivery_count = msg.get("delivery_count", 1)

        # Check if message has exceeded max deliveries
        if delivery_count > self._max_deliveries:
            logger.warning(
                f"Message {msg_id} exceeded max deliveries "
                f"({delivery_count}/{self._max_deliveries}), sending to DLQ"
            )
            dlq_success = await self._send_to_dlq(
                msg_id,
                raw_data,
                reason="max_deliveries_exceeded",
                error=f"Delivery count {delivery_count} exceeded max {self._max_deliveries}",
            )
            if dlq_success:
                try:
                    await self._stream_consumer.ack(msg_id)
                except Exception:
                    # DLQ write succeeded but ack failed - message may be duplicated
                    # in DLQ on retry, but this is safer than losing the message
                    logger.exception(
                        f"Failed to ack message {msg_id} after DLQ write, "
                        "message may be duplicated in DLQ"
                    )
            # If DLQ write failed, leave pending for retry
            return

        # Deserialize to typed event
        try:
            event = self._deserialize(raw_data)
        except DeserializationError as e:
            logger.error(f"Failed to deserialize message {msg_id}: {e}")
            dlq_success = await self._send_to_dlq(
                msg_id,
                raw_data,
                reason="deserialization_error",
                error=str(e),
            )
            if dlq_success:
                try:
                    await self._stream_consumer.ack(msg_id)
                except Exception:
                    logger.exception(
                        f"Failed to ack message {msg_id} after DLQ write, "
                        "message may be duplicated in DLQ"
                    )
            # If DLQ write failed, leave pending for retry
            return

        # Find matching handlers
        matching_handlers = self._match_handlers(event)

        if not matching_handlers:
            logger.debug(f"No handlers for event type '{raw_data.get('event_type')}'")
            await self._stream_consumer.ack(msg_id)
            return

        # Dispatch to handlers
        try:
            await self._dispatch(event, matching_handlers)
            # Success - acknowledge the message
            await self._stream_consumer.ack(msg_id)

        except NonRetryableError as e:
            # Non-retryable error - send to DLQ immediately
            logger.error(f"Non-retryable error for message {msg_id}: {e}")
            dlq_success = await self._send_to_dlq(
                msg_id,
                raw_data,
                reason="non_retryable",
                error=str(e.cause),
                handler_name=e.handler_name,
            )
            if dlq_success:
                try:
                    await self._stream_consumer.ack(msg_id)
                except Exception:
                    logger.exception(
                        f"Failed to ack message {msg_id} after DLQ write, "
                        "message may be duplicated in DLQ"
                    )
            # If DLQ write failed, leave pending for retry

        except MaxRetriesExceededError:
            # Quick retries exhausted - leave pending for Redis-level retry
            # Message will be reclaimed by XAUTOCLAIM after claim_min_idle_ms
            logger.warning(
                f"Quick retries exhausted for message {msg_id} "
                f"(delivery {delivery_count}/{self._max_deliveries}), "
                f"leaving pending for Redis retry"
            )
            # Don't ack - message stays pending

        except Exception:
            # Unexpected error - leave pending for Redis-level retry
            logger.exception(f"Unexpected error processing message {msg_id}")
            # Don't ack - message stays pending

    def _deserialize(self, raw: dict[str, Any]) -> Event:
        """Deserialize raw message data to a typed event.

        Looks up the event class in the registry and validates
        the data with Pydantic. Falls back to GenericEvent for
        unknown event types.
        """
        event_type = raw.get("event_type", "")

        # Look up the event class
        event_cls = get_event_class(event_type)

        if event_cls is None:
            # Unknown event type - use GenericEvent
            try:
                timestamp_str = raw.get("timestamp")
                timestamp = (
                    datetime.fromisoformat(timestamp_str)
                    if timestamp_str
                    else datetime.now(UTC)
                )
                return GenericEvent(
                    raw_type=event_type,
                    data=orjson.loads(raw.get("data", "{}")),
                    id=raw.get("id", ""),
                    timestamp=timestamp,
                    correlation_id=raw.get("correlation_id") or None,
                    causation_id=raw.get("causation_id") or None,
                    metadata=orjson.loads(raw.get("metadata", "{}")),
                )
            except (ValueError, TypeError, orjson.JSONDecodeError) as e:
                raise DeserializationError(event_type, str(e)) from e

        # Deserialize to typed event
        try:
            event_data = orjson.loads(raw.get("data", "{}"))

            # Reconstruct the full event data
            # Include _schema_version and _timestamp for migration validators
            full_data = {
                **event_data,
                "_schema_version": int(raw.get("schema_version", 1)),
                "_timestamp": raw.get("timestamp"),
                "id": raw.get("id"),
                "timestamp": raw.get("timestamp"),
                "correlation_id": raw.get("correlation_id") or None,
                "causation_id": raw.get("causation_id") or None,
                "metadata": orjson.loads(raw.get("metadata", "{}")),
            }

            return event_cls.model_validate(full_data)

        except Exception as e:
            raise DeserializationError(event_type, str(e)) from e

    def _match_handlers(self, event: Event) -> list[HandlerRegistration]:
        """Find all handlers that match the given event.

        Delegates to each handler's matches() method, which uses
        event.routing_key for uniform matching across all event types.

        Phase 1: Exact event_type matching only.
        Phase 2: Adds base class and pattern matching.
        """
        return [h for h in self._handlers if h.matches(event)]

    async def _dispatch(
        self,
        event: Event,
        handlers: list[HandlerRegistration],
    ) -> None:
        """Dispatch an event to all matching handlers.

        Uses handler-specific timeout/retry config if set, otherwise falls back
        to router defaults. Implements quick in-process retries with backoff.
        """
        for handler in handlers:
            await self._execute_handler(handler, event)

    async def _execute_handler(
        self,
        handler: HandlerRegistration,
        event: Event,
    ) -> None:
        """Execute a single handler with quick retry logic.

        Implements in-process retries with exponential backoff for transient failures.
        Non-retryable exceptions are wrapped in NonRetryableError.
        After exhausting quick retries, raises to signal Redis-level retry.
        """
        timeout = (
            handler.timeout if handler.timeout is not None else self._handler_timeout
        )
        max_retries = (
            handler.retries if handler.retries is not None else self._default_retries
        )
        backoff_fn = handler.backoff or self._default_backoff
        retryable = handler.retryable_exceptions

        handler_name = handler.fn.__name__

        for attempt in range(max_retries + 1):  # +1 for initial attempt
            try:
                await asyncio.wait_for(handler.fn(event), timeout=timeout)
                return  # Success
            except Exception as e:
                is_retryable = isinstance(e, retryable)
                has_retries_left = attempt < max_retries

                if not is_retryable:
                    logger.error(
                        f"Handler {handler_name} failed with non-retryable "
                        f"{type(e).__name__} for event {event.id}: {e}"
                    )
                    raise NonRetryableError(handler_name, e, event.id) from e

                if has_retries_left:
                    delay = backoff_fn(attempt + 1)
                    logger.warning(
                        f"Handler {handler_name} failed (attempt {attempt + 1}/"
                        f"{max_retries + 1}), retrying in {delay:.2f}s: {e}"
                    )
                    await asyncio.sleep(delay)
                else:
                    # Quick retries exhausted
                    logger.error(
                        f"Handler {handler_name} failed after {max_retries + 1} "
                        f"attempts for event {event.id}: {e}"
                    )
                    raise MaxRetriesExceededError(
                        handler_name, max_retries + 1, event.id, e
                    ) from e

    async def _claim_from_dead_consumers(self) -> None:
        """Claim pending messages from dead consumers using XAUTOCLAIM."""
        if self._stream_consumer is None:
            return

        try:
            self._claim_cursor, messages = await self._stream_consumer.autoclaim(
                min_idle_ms=self._claim_min_idle_ms,
                start=self._claim_cursor,
            )

            if messages:
                logger.info(f"Claimed {len(messages)} messages from dead consumers")
                for msg in messages:
                    await self._process_message(msg)

        except Exception:
            logger.exception("Error claiming from dead consumers")
            self._claim_cursor = "0-0"  # Reset on error

    async def _send_to_dlq(
        self,
        msg_id: str,
        raw_data: dict[str, Any],
        reason: str,
        error: str | None = None,
        handler_name: str | None = None,
    ) -> bool:
        """Send a failed message to the dead letter queue.

        Args:
            msg_id: Original message ID from the stream
            raw_data: Original message data
            reason: Why the message was sent to DLQ (e.g., "max_deliveries_exceeded",
                    "deserialization_error", "non_retryable")
            error: Error message or exception details
            handler_name: Name of the handler that failed (if applicable)

        Returns:
            True if message was successfully written to DLQ (or DLQ is disabled),
            False if DLQ write failed. Callers should NOT ack the original message
            when this returns False, to ensure the message is retried.
        """
        if not self._dlq_stream:
            logger.warning(
                f"DLQ disabled, dropping failed message {msg_id} (reason: {reason})"
            )
            return True  # DLQ disabled is considered "success" - caller can ack

        dlq_entry = {
            "original_msg_id": msg_id,
            "original_stream": self._stream,
            "original_group": self._group,
            "reason": reason,
            "error": error or "",
            "handler": handler_name or "",
            "failed_at": datetime.now(UTC).isoformat(),
            # Include original message fields
            "event_type": raw_data.get("event_type", ""),
            "data": raw_data.get("data", "{}"),
            "id": raw_data.get("id", ""),
            "timestamp": raw_data.get("timestamp", ""),
            "correlation_id": raw_data.get("correlation_id", ""),
            "causation_id": raw_data.get("causation_id", ""),
            "metadata": raw_data.get("metadata", "{}"),
        }

        try:
            await self._redis.xadd(self._dlq_stream, dlq_entry, maxlen=self._dlq_maxlen)
            logger.info(f"Sent message {msg_id} to DLQ '{self._dlq_stream}': {reason}")
            return True
        except Exception:
            logger.exception(
                f"Failed to send message {msg_id} to DLQ, leaving pending for retry"
            )
            return False
