"""Handler registration and matching logic."""

import types
from dataclasses import dataclass, field
from typing import Union, get_args, get_origin

from rapids.backoff import Backoff
from rapids.events.base import BaseEvent, Event, get_all_subclasses
from rapids.types import Handler
from rapids.utils.patterns import glob_match

# Type alias for decorator targets
Target = type[BaseEvent] | types.UnionType | str


@dataclass
class HandlerRegistration:
    """Registration info for an event handler.

    Supports multiple matching strategies:
    - Exact event_type match via event_types set
    - Base class match via isinstance against event_classes
    - Glob pattern match via patterns set

    Reliability config (optional, falls back to router defaults):
    - timeout: Max execution time in seconds
    - retries: Number of retry attempts on failure
    - backoff: Backoff strategy for retries
    - retryable_exceptions: Exception types that trigger retry
    """

    fn: Handler
    event_types: set[str] = field(default_factory=set)
    event_classes: set[type[BaseEvent]] = field(default_factory=set)
    patterns: set[str] = field(default_factory=set)

    # Reliability config (None = use router default)
    timeout: float | None = None
    retries: int | None = None
    backoff: Backoff | None = None
    retryable_exceptions: tuple[type[Exception], ...] = field(default=(Exception,))

    def matches(self, event: Event) -> bool:
        """Check if this handler matches the given event.

        Matching order (first match wins):
        1. Exact event_type match (fastest, O(1) set lookup)
        2. isinstance check against registered classes (for base class matching)
        3. Glob pattern match (slowest, regex matching)

        Args:
            event: Event to check

        Returns:
            True if this handler should receive the event
        """
        key = event.routing_key

        # 1. Exact match on event_type
        if key in self.event_types:
            return True

        # 2. Base class match via isinstance
        # Only for BaseEvent subclasses (GenericEvent doesn't have class hierarchy)
        if self.event_classes and isinstance(event, BaseEvent):
            for cls in self.event_classes:
                if isinstance(event, cls):
                    return True

        # 3. Pattern match
        if self.patterns:
            for pattern in self.patterns:
                if glob_match(pattern, key):
                    return True

        return False


def resolve_event_types(
    target: Target,
) -> tuple[set[str], set[type[BaseEvent]], set[str]]:
    """Convert a decorator target to matching criteria.

    Handles:
        - Single event class: DocumentCreated
        - Base class: DocumentEvent (matches all subclasses)
        - Union type: DocumentCreated | DocumentDeleted
        - String pattern: "document.*"

    Args:
        target: Event class, union of classes, or string pattern

    Returns:
        Tuple of (event_types, event_classes, patterns)
    """
    event_types: set[str] = set()
    event_classes: set[type[BaseEvent]] = set()
    patterns: set[str] = set()

    if isinstance(target, str):
        # String pattern
        patterns.add(target)

    elif isinstance(target, types.UnionType) or get_origin(target) is Union:
        # Union type - recursively resolve each member
        args = (
            target.__args__ if isinstance(target, types.UnionType) else get_args(target)
        )
        for arg in args:
            sub_types, sub_classes, sub_patterns = resolve_event_types(arg)
            event_types.update(sub_types)
            event_classes.update(sub_classes)
            patterns.update(sub_patterns)

    elif isinstance(target, type) and issubclass(target, BaseEvent):
        # Event class - only add if event_type is non-empty
        if target.event_type:
            event_types.add(target.event_type)
        event_classes.add(target)

        # Check for subclasses (base class matching)
        subclasses = get_all_subclasses(target)
        for subcls in subclasses:
            if subcls.event_type:
                event_types.add(subcls.event_type)

    else:
        raise TypeError(
            f"Invalid target for @router.on(): {target!r}. "
            f"Expected event class, union of classes, or string pattern."
        )

    return event_types, event_classes, patterns
