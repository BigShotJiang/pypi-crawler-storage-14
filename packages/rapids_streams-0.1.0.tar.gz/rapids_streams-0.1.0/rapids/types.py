"""Type aliases used throughout Rapids."""

from typing import Any, Protocol, TypeVar

from rapids.events.base import BaseEvent

# TypeVar for generic event types in decorators
EventT = TypeVar("EventT", bound=BaseEvent)


class Handler(Protocol):
    """Protocol for async event handlers."""

    __name__: str

    async def __call__(self, event: Any) -> None: ...


# Raw Redis message format
RawMessage = dict[str, Any]
