"""Backoff strategy implementations."""

import math
import random
from typing import Protocol


class Backoff(Protocol):
    """Protocol for backoff strategies.

    A backoff strategy determines how long to wait between retry attempts.
    """

    def __call__(self, attempt: int) -> float:
        """Calculate delay for the given attempt number.

        Args:
            attempt: The attempt number (1-based: 1st retry, 2nd retry, etc.)

        Returns:
            Delay in seconds before the next attempt
        """
        ...


def exponential(
    base: float = 2.0,
    max_delay: float = 60.0,
    jitter: bool = True,
) -> Backoff:
    """Exponential backoff strategy.

    Delay = min(base^attempt, max_delay) with optional jitter.

    Args:
        base: Base for exponentiation (default: 2.0)
        max_delay: Maximum delay in seconds (default: 60.0)
        jitter: Add randomness to prevent thundering herd (default: True)

    Returns:
        Backoff function

    Examples:
        >>> backoff = exponential(jitter=False)
        >>> backoff(1)  # 2.0
        >>> backoff(2)  # 4.0
        >>> backoff(3)  # 8.0
    """

    def _backoff(attempt: int) -> float:
        # Cap the exponent to prevent OverflowError for large attempt values
        # max_exp is the largest exponent where base**max_exp <= max_delay
        max_exp = math.floor(math.log(max_delay) / math.log(base))
        if attempt > max_exp:
            # Would exceed max_delay, return max_delay directly
            delay = max_delay
        else:
            delay = min(base**attempt, max_delay)
        if jitter:
            # Add ±25% jitter
            delay = delay * (0.75 + random.random() * 0.5)
        return delay

    return _backoff  # type: ignore[return-value]


def linear(
    delay: float = 1.0,
    max_delay: float = 60.0,
) -> Backoff:
    """Linear backoff strategy.

    Delay = min(delay * attempt, max_delay)

    Args:
        delay: Base delay multiplier in seconds (default: 1.0)
        max_delay: Maximum delay in seconds (default: 60.0)

    Returns:
        Backoff function

    Examples:
        >>> backoff = linear(delay=2.0)
        >>> backoff(1)  # 2.0
        >>> backoff(2)  # 4.0
        >>> backoff(3)  # 6.0
    """

    def _backoff(attempt: int) -> float:
        return min(delay * attempt, max_delay)

    return _backoff  # type: ignore[return-value]


def constant(delay: float = 1.0) -> Backoff:
    """Constant backoff strategy.

    Always waits the same amount of time between retries.

    Args:
        delay: Delay in seconds (default: 1.0)

    Returns:
        Backoff function

    Examples:
        >>> backoff = constant(delay=5.0)
        >>> backoff(1)  # 5.0
        >>> backoff(2)  # 5.0
        >>> backoff(3)  # 5.0
    """

    def _backoff(attempt: int) -> float:
        _ = attempt  # Unused
        return delay

    return _backoff  # type: ignore[return-value]
