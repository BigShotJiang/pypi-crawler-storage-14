"""Utilities package for Rapids."""

from rapids.utils.patterns import glob_match

__all__ = ["glob_match"]
