"""Glob pattern matching for event types."""

import re
from functools import lru_cache


@lru_cache(maxsize=256)
def compile_pattern(pattern: str) -> re.Pattern[str]:
    """Compile a glob pattern to a regex.

    Patterns:
        * - matches a single segment (no dots)
        ** - matches any number of segments (including dots)
        * (alone) - catch-all, matches anything

    Examples:
        document.* -> matches document.created, not document.a.b
        document.** -> matches document.created and document.a.b
        *.created -> matches document.created, user.created
        * -> matches anything (catch-all)

    Args:
        pattern: Glob pattern string

    Returns:
        Compiled regex pattern
    """
    if pattern == "*":
        # Catch-all - match any non-empty string
        return re.compile(r"^.+$")

    # Build regex character by character
    result: list[str] = []
    i = 0
    while i < len(pattern):
        if i < len(pattern) - 1 and pattern[i : i + 2] == "**":
            # ** matches anything including dots
            result.append(".*")
            i += 2
        elif pattern[i] == "*":
            # * matches single segment (no dots)
            result.append("[^.]+")
            i += 1
        elif pattern[i] == ".":
            # Literal dot
            result.append(r"\.")
            i += 1
        else:
            # Escape any regex special characters
            result.append(re.escape(pattern[i]))
            i += 1

    return re.compile(f"^{''.join(result)}$")


def glob_match(pattern: str, event_type: str) -> bool:
    """Check if an event_type matches a glob pattern.

    Args:
        pattern: Glob pattern (e.g., "document.*", "**", "*")
        event_type: Event type string to match

    Returns:
        True if event_type matches the pattern
    """
    return compile_pattern(pattern).match(event_type) is not None
