"""Custom exceptions for Rapids."""


class RapidsError(Exception):
    """Base exception for all rapids errors."""


class DeserializationError(RapidsError):
    """Raised when an event fails to deserialize."""

    def __init__(self, event_type: str, message: str) -> None:
        self.event_type = event_type
        super().__init__(f"Failed to deserialize event '{event_type}': {message}")


class EmitError(RapidsError):
    """Raised when an event fails to emit to Redis after retries."""

    def __init__(
        self,
        event_type: str,
        event_id: str,
        stream: str,
        attempts: int,
        cause: Exception,
    ) -> None:
        self.event_type = event_type
        self.event_id = event_id
        self.stream = stream
        self.attempts = attempts
        super().__init__(
            f"Failed to emit event '{event_type}' (id={event_id}) to stream '{stream}' "
            f"after {attempts} attempts: {cause}"
        )


class HandlerTimeoutError(RapidsError):
    """Raised when a handler exceeds its timeout."""

    def __init__(self, handler_name: str, timeout: float, event_id: str) -> None:
        self.handler_name = handler_name
        self.timeout = timeout
        self.event_id = event_id
        super().__init__(
            f"Handler '{handler_name}' timed out after {timeout}s "
            f"processing event {event_id}"
        )


class MaxRetriesExceededError(RapidsError):
    """Raised when a handler exceeds max retry attempts."""

    def __init__(
        self,
        handler_name: str,
        max_attempts: int,
        event_id: str,
        last_error: Exception,
    ) -> None:
        self.handler_name = handler_name
        self.max_attempts = max_attempts
        self.event_id = event_id
        self.last_error = last_error
        super().__init__(
            f"Handler '{handler_name}' failed after {max_attempts} attempts "
            f"for event {event_id}: {last_error}"
        )


class NonRetryableError(RapidsError):
    """Raised when a handler fails with a non-retryable exception.

    This signals to the router that the message should be sent to DLQ
    immediately rather than being retried.
    """

    def __init__(
        self,
        handler_name: str,
        cause: Exception,
        event_id: str,
    ) -> None:
        self.handler_name = handler_name
        self.cause = cause
        self.event_id = event_id
        super().__init__(
            f"Non-retryable error in handler '{handler_name}' "
            f"for event {event_id}: {type(cause).__name__}: {cause}"
        )
