"""Event base classes with auto-registration and auto-naming."""

import inspect
import re
from abc import abstractmethod
from datetime import UTC, datetime
from typing import Any, ClassVar
from uuid import uuid4

from pydantic import BaseModel, Field

# Global registry mapping event_type strings to event classes
_event_registry: dict[str, type["BaseEvent"]] = {}


def get_event_class(event_type: str) -> type["BaseEvent"] | None:
    """Look up an event class by its event_type string."""
    return _event_registry.get(event_type)


def get_all_subclasses(cls: type["BaseEvent"]) -> list[type["BaseEvent"]]:
    """Get all registered subclasses of a given event class."""
    result = []
    for event_cls in _event_registry.values():
        if event_cls is not cls and issubclass(event_cls, cls):
            result.append(event_cls)
    return result


class Event(BaseModel):
    """Common base class for all events - typed or generic.

    This class provides the shared fields and interface for all events.
    Use BaseEvent for defining typed events with auto-registration,
    or GenericEvent for handling unknown event types.

    The routing_key property provides uniform access to the event type
    string used for routing and matching, regardless of event type.
    """

    model_config = {"frozen": True}

    # Common instance fields
    id: str = Field(default_factory=lambda: str(uuid4()))
    timestamp: datetime = Field(default_factory=lambda: datetime.now(UTC))
    correlation_id: str | None = None
    causation_id: str | None = None
    metadata: dict[str, Any] = Field(default_factory=dict)

    @property
    @abstractmethod
    def routing_key(self) -> str:
        """Event type string used for routing and matching.

        For typed events (BaseEvent subclasses), returns the class's event_type.
        For generic events, returns the raw_type from the message.
        """
        ...


def _camel_to_snake(name: str) -> str:
    """Convert CamelCase to snake_case.

    Examples:
        DocumentCreated -> document_created
        UserAccountSuspended -> user_account_suspended
        S3ObjectUploaded -> s3_object_uploaded
    """
    # Handle acronyms: S3Object -> S3_Object -> s3_object
    # Insert underscore before uppercase letters that follow lowercase letters
    s1 = re.sub(r"([a-z0-9])([A-Z])", r"\1_\2", name)
    # Insert underscore between consecutive uppercase letters followed by lowercase
    s2 = re.sub(r"([A-Z]+)([A-Z][a-z])", r"\1_\2", s1)
    return s2.lower()


def _generate_event_type(cls_name: str) -> str:
    """Generate event_type from class name.

    Examples:
        DocumentCreated -> document.created
        UserAccountSuspended -> user_account.suspended
        S3ObjectUploaded -> s3_object.uploaded
    """
    snake = _camel_to_snake(cls_name)
    parts = snake.split("_")

    if len(parts) < 2:
        # Single word like "Event" -> just use it
        return snake

    # Last part is the action (created, deleted, suspended, etc.)
    action = parts[-1]
    # Everything else is the domain
    domain = "_".join(parts[:-1])

    return f"{domain}.{action}"


class BaseEvent(Event):
    """Base class for typed events with auto-registration and auto-naming.

    Subclasses are automatically registered in the global event registry
    and assigned an event_type based on their class name.

    Example:
        class DocumentCreated(BaseEvent):
            doc_id: str
            title: str

        # event_type is automatically set to "document.created"
        # Class is registered in _event_registry

    Schema Versioning:
        Events support schema evolution via the schema_version class variable.
        Override schema_version when making breaking changes and use
        @model_validator(mode="before") to migrate old data:

        class UserCreated(BaseEvent):
            schema_version: ClassVar[int] = 2
            user_id: str
            email: str
            created_at: datetime  # Added in v2

            @model_validator(mode="before")
            @classmethod
            def _migrate(cls, data: dict) -> dict:
                if data.get("_schema_version", cls.schema_version) < 2:
                    data["created_at"] = data.get("_timestamp")
                return data
    """

    model_config = {"frozen": True, "extra": "ignore"}

    # Class variable for event type routing
    event_type: ClassVar[str] = ""

    # Schema version for event evolution (increment on breaking changes)
    schema_version: ClassVar[int] = 1

    # Set to True to skip auto-registration in the event registry
    _skip_registration: ClassVar[bool] = True

    @property
    def routing_key(self) -> str:
        """Return the event_type for routing."""
        return self.event_type

    def __init_subclass__(cls, **kwargs: Any) -> None:
        super().__init_subclass__(**kwargs)

        # Skip registration if explicitly opted out on this class (not inherited)
        if cls.__dict__.get("_skip_registration", False):
            return

        # Skip registration for abstract classes (have abstract methods)
        if inspect.isabstract(cls):
            return

        # Generate event_type if not explicitly set on this class
        # Check __dict__ to avoid inheriting parent's event_type
        if "event_type" not in cls.__dict__ or not cls.__dict__.get("event_type"):
            cls.event_type = _generate_event_type(cls.__name__)

        # Check for duplicate registration
        existing = _event_registry.get(cls.event_type)
        if existing is not None and existing is not cls:
            raise ValueError(
                f"Duplicate event_type '{cls.event_type}': "
                f"{cls.__name__} conflicts with {existing.__name__}"
            )

        # Register in global registry
        _event_registry[cls.event_type] = cls
