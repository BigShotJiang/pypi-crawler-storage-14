"""GenericEvent for unknown/unregistered event types."""

from typing import Any

from pydantic import Field

from rapids.events.base import Event


class GenericEvent(Event):
    """Fallback event for unknown/unregistered event types.

    Used when an event is received with an event_type that has no
    registered class in the event registry. Stores the raw payload
    data without schema validation.
    """

    model_config = {"frozen": True, "extra": "allow"}

    # The original event_type string from the message
    raw_type: str

    # The raw payload data
    data: dict[str, Any] = Field(default_factory=dict)

    @property
    def routing_key(self) -> str:
        """Return the raw_type for routing."""
        return self.raw_type
