"""Rapids CLI."""

import rapids


def main() -> None:
    """Entry point for the rapids CLI."""
    print(f"rapids {rapids.__version__}")


if __name__ == "__main__":
    main()
