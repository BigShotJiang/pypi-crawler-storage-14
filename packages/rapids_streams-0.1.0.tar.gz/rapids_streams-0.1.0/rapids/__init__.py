"""Rapids - Typed Event Router for Redis Streams."""

from rapids.emitter import (
    EventEmitter,
    correlation_scope,
    get_causation_id,
    get_correlation_id,
)
from rapids.events import BaseEvent, Event, GenericEvent, get_event_class
from rapids.exceptions import EmitError, RapidsError
from rapids.router import ConsumerLag, EventRouter, GroupStartPosition, ReadMode

__version__ = "0.1.0"

__all__ = [
    # Events
    "Event",
    "BaseEvent",
    "GenericEvent",
    "get_event_class",
    # Emitter
    "EventEmitter",
    # Correlation
    "correlation_scope",
    "get_correlation_id",
    "get_causation_id",
    # Router
    "ConsumerLag",
    "EventRouter",
    "GroupStartPosition",
    "ReadMode",
    # Exceptions
    "RapidsError",
    "EmitError",
]
