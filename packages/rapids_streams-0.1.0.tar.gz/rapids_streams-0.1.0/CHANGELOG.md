# Changelog

## 0.1.0 (2025-11-29)


### Features

* add backoff strategies with exponential, linear, and constant implementations ([4008307](https://github.com/AZX-PBC/rapids/commit/4008307d11e539eca4540b7344a3e97e004f27d1))
* add CLI entry point and script configuration for rapids ([146732f](https://github.com/AZX-PBC/rapids/commit/146732f1662f3e063c59c8da58b6b9052ecb5578))
* add ConsumerLag dataclass and integrate lag metrics into StreamConsumer and EventRouter ([491dd52](https://github.com/AZX-PBC/rapids/commit/491dd52f8954425acbab905becb2a04eab68a6f7))
* add TUI demo with event system and various widgets ([ecf4692](https://github.com/AZX-PBC/rapids/commit/ecf46921d66f87ac07579d9985bef23e901dc60e))
* enhance event routing with support for union types and glob patterns ([a83d0b0](https://github.com/AZX-PBC/rapids/commit/a83d0b09c5a94a29885169c228c071f66414750a))
* enhance event system with unified Event base class and routing_key property ([a5a0033](https://github.com/AZX-PBC/rapids/commit/a5a00338c4e1a7050141e567573324a8e5101cc1))
* implement correlation and causation tracking with context management ([e0efb07](https://github.com/AZX-PBC/rapids/commit/e0efb078960ea77d50e2a24204fd158c5a49e4a7))
* implement Rapids TUI demo with event system and widgets ([6204243](https://github.com/AZX-PBC/rapids/commit/6204243be0f6dace18e6566e9f4aa967a2ade5e6))
* implement schema versioning for events with migration support ([1e8a043](https://github.com/AZX-PBC/rapids/commit/1e8a0433fb2bfaaef97e62aa59a8e31625efb3d9))
* initial implementation of rapids ([f0f17cc](https://github.com/AZX-PBC/rapids/commit/f0f17cc487b7103a10bf76cc278dfef432cbb8d8))
* **router:** add reliability configuration for handlers ([bdda924](https://github.com/AZX-PBC/rapids/commit/bdda9249999b1d930094884f36a0e57d126fc92f))
* **router:** enhance StreamConsumer and EventRouter with group start position and read mode enums ([b96fa75](https://github.com/AZX-PBC/rapids/commit/b96fa750c7888afa54b7a29cc5208668ada8701b))


### Bug Fixes

* **consumer:** update parameter name for group start position in consumer initialization ([b57ba77](https://github.com/AZX-PBC/rapids/commit/b57ba771c460fac34cfd9c3759a409f48e793bae))
* suppress DeprecationWarning for testcontainers library's deprecated decorator ([fe051d6](https://github.com/AZX-PBC/rapids/commit/fe051d6487430572326a5ebac22e04dd16cf59ea))
* update project name to "rapids-streams" in pyproject.toml and uv.lock ([6fc7899](https://github.com/AZX-PBC/rapids/commit/6fc78996577a35ce57f7a24b82a52ac5edd4c4f0))


### Documentation

* enhance README with detailed features and usage examples ([49441d5](https://github.com/AZX-PBC/rapids/commit/49441d5c59f4b7da9c9bcf1d7fdbd7210e8cdaf3))
* expand Table of Contents in README for better navigation ([6030f91](https://github.com/AZX-PBC/rapids/commit/6030f91a904403b0062a2f552c2718b2c8848e37))
