# Claude Rules

## Task Completion
- Always run `make ci` at the end of every task to ensure code quality and tests pass

## Testing Strategy
- `make test` - Run all tests (unit + integration)
- `make test-unit` - Run unit tests only (fast, no Docker required)
- `make test-integration` - Run integration tests only (requires Docker)
- `make ci` - Run CI checks (lint + typecheck + all tests)
