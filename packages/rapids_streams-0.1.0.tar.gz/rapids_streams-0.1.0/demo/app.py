"""Main Textual app for the Rapids TUI demo."""

import os

from redis.asyncio import Redis
from textual.app import App, ComposeResult
from textual.binding import Binding
from textual.containers import Horizontal, ScrollableContainer, Vertical
from textual.widgets import Footer, Header

from rapids import Emitter
from demo.widgets.consumer_panel import ConsumerPanel
from demo.widgets.emitter_panel import EmitterPanel


class RapidsDemo(App):
    """Rapids Event System TUI Demo."""

    TITLE = "Rapids Event Demo"

    CSS = """
    Screen {
        background: $surface-darken-1;
    }

    #main-container {
        height: 1fr;
    }

    #consumers-container {
        width: 1fr;
        padding: 0 1;
    }

    #consumers-scroll {
        height: 1fr;
    }

    #consumers-list {
        height: auto;
    }
    """

    BINDINGS = [
        Binding("q", "quit", "Quit"),
        Binding("enter", "submit", "Submit Event"),
        Binding("+", "add_consumer", "Add Consumer"),
    ]

    def __init__(self) -> None:
        super().__init__()
        self._redis: Redis | None = None
        self._emitter: Emitter | None = None
        self._stream = "events:demo"
        self._consumer_count = 0
        self._consumers: list[ConsumerPanel] = []

    def compose(self) -> ComposeResult:
        yield Header()
        with Horizontal(id="main-container"):
            yield EmitterPanel()
            with Vertical(id="consumers-container"):
                with ScrollableContainer(id="consumers-scroll"):
                    yield Vertical(id="consumers-list")
        yield Footer()

    async def on_mount(self) -> None:
        """Initialize Redis and add first consumer."""
        redis_url = os.environ.get(
            "REDIS_URL", "redis://:dev_password@localhost:6379/0"
        )

        try:
            self._redis = Redis.from_url(redis_url)
            await self._redis.ping()
            self._log_emit("[green]Connected to Redis[/]")
        except Exception as e:
            self._log_emit(f"[red]Redis connection failed: {e}[/]")
            return

        self._emitter = Emitter(redis=self._redis, stream=self._stream)

        # Add first consumer
        await self._add_consumer()

    def _log_emit(self, message: str) -> None:
        """Log a message to the emitter panel."""
        try:
            panel = self.query_one(EmitterPanel)
            log = panel.query_one("#emit-log")
            log.write(message)
        except Exception:
            pass

    async def on_emitter_panel_event_emit_requested(
        self, message: EmitterPanel.EventEmitRequested
    ) -> None:
        """Handle event emission request from emitter panel."""
        if self._emitter is None:
            self._log_emit("[red]Emitter not ready[/]")
            return

        try:
            await self._emitter.emit(message.event)
            panel = self.query_one(EmitterPanel)
            panel.log_emitted(message.event)
        except Exception as e:
            self._log_emit(f"[red]Emit failed: {e}[/]")

    async def _add_consumer(self) -> None:
        """Add a new consumer panel."""
        if self._redis is None:
            return

        self._consumer_count += 1
        group_name = f"group-{self._consumer_count}"

        panel = ConsumerPanel(
            redis=self._redis,
            stream=self._stream,
            group_name=group_name,
            consumer_id=self._consumer_count,
        )
        self._consumers.append(panel)

        consumers_list = self.query_one("#consumers-list")
        await consumers_list.mount(panel)

    def action_submit(self) -> None:
        """Submit the selected event (Enter key)."""
        try:
            panel = self.query_one(EmitterPanel)
            panel._emit_selected_event()
        except Exception:
            pass

    async def action_add_consumer(self) -> None:
        """Add a new consumer (+ key)."""
        await self._add_consumer()

    async def action_quit(self) -> None:
        """Clean shutdown."""
        # Stop all consumers
        for consumer in self._consumers:
            await consumer.stop()

        # Close Redis
        if self._redis:
            await self._redis.aclose()

        self.exit()


def main() -> None:
    """Run the demo app."""
    app = RapidsDemo()
    app.run()


if __name__ == "__main__":
    main()
