"""Demo event definitions for the Rapids TUI demo."""

import random
import string

from rapids import BaseEvent


class UserCreated(BaseEvent):
    """User registration event."""

    user_id: str
    email: str


class UserDeleted(BaseEvent):
    """User deletion event."""

    user_id: str
    reason: str


class OrderPlaced(BaseEvent):
    """Order placement event."""

    order_id: str
    user_id: str
    total: float


class OrderShipped(BaseEvent):
    """Order shipment event."""

    order_id: str
    tracking_number: str


# List of all demo event classes
EVENT_CLASSES = [UserCreated, UserDeleted, OrderPlaced, OrderShipped]


def generate_random_event(event_class: type[BaseEvent]) -> BaseEvent:
    """Generate a random instance of the given event class."""
    user_id = f"user-{random.randint(1, 100):03d}"
    order_id = f"order-{random.randint(1, 1000):04d}"

    if event_class == UserCreated:
        return UserCreated(user_id=user_id, email=f"{user_id}@example.com")
    elif event_class == UserDeleted:
        reasons = ["inactive", "requested", "spam", "policy_violation"]
        return UserDeleted(user_id=user_id, reason=random.choice(reasons))
    elif event_class == OrderPlaced:
        return OrderPlaced(
            order_id=order_id,
            user_id=user_id,
            total=round(random.uniform(10, 500), 2),
        )
    elif event_class == OrderShipped:
        tracking = "".join(random.choices(string.ascii_uppercase + string.digits, k=8))
        return OrderShipped(order_id=order_id, tracking_number=f"TRK-{tracking}")
    else:
        raise ValueError(f"Unknown event class: {event_class}")
