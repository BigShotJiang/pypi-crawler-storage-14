"""Consumer panel widget that runs an EventRouter and displays consumed events."""

from redis.asyncio import Redis
from textual.app import ComposeResult
from textual.containers import Vertical
from textual.message import Message
from textual.widgets import RichLog, Static
from textual.worker import Worker, WorkerState

from rapids import EventRouter
from demo.events import (
    OrderPlaced,
    OrderShipped,
    UserCreated,
    UserDeleted,
)


class ConsumerPanel(Vertical):
    """A panel that runs a consumer and displays consumed events."""

    DEFAULT_CSS = """
    ConsumerPanel {
        height: 1fr;
        border: solid dodgerblue;
        border-title-color: dodgerblue;
        padding: 0 1;
        margin-bottom: 1;
    }

    ConsumerPanel > Static {
        text-style: bold;
        color: dodgerblue;
        height: 1;
    }

    ConsumerPanel > RichLog {
        height: 1fr;
        background: $surface;
    }
    """

    class EventConsumed(Message):
        """Message posted when an event is consumed."""

        def __init__(
            self, consumer_id: int, color: str, event_type: str, details: str
        ) -> None:
            self.consumer_id = consumer_id
            self.color = color
            self.event_type = event_type
            self.details = details
            super().__init__()

    def __init__(
        self,
        redis: Redis,
        stream: str,
        group_name: str,
        consumer_id: int,
    ) -> None:
        super().__init__()
        self._redis = redis
        self._stream = stream
        self._group_name = group_name
        self._consumer_id = consumer_id
        self._router: EventRouter | None = None
        self._worker: Worker[None] | None = None
        self.border_title = f"Consumer {consumer_id} ({group_name})"

    def compose(self) -> ComposeResult:
        yield Static(f"Group: {self._group_name}")
        yield RichLog(id=f"consumer-log-{self._consumer_id}", markup=True)

    async def on_mount(self) -> None:
        """Start the consumer when mounted."""
        self._start_consumer()

    def _start_consumer(self) -> None:
        """Start the consumer worker."""
        self._worker = self.run_worker(
            self._run_router(),
            name=f"consumer-{self._consumer_id}",
            exclusive=True,
        )

    async def _run_router(self) -> None:
        """Run the event router."""
        self._router = EventRouter(
            redis=self._redis,
            stream=self._stream,
            group=self._group_name,
            block_ms=500,
            group_start_id="$",  # Only receive new messages from now on
        )

        # Register handlers
        @self._router.on(UserCreated)
        async def on_user_created(event: UserCreated) -> None:
            self._post_event(
                "green",
                "UserCreated",
                f"{event.user_id} ({event.email})",
            )

        @self._router.on(UserDeleted)
        async def on_user_deleted(event: UserDeleted) -> None:
            self._post_event(
                "red",
                "UserDeleted",
                f"{event.user_id} - {event.reason}",
            )

        @self._router.on(OrderPlaced)
        async def on_order_placed(event: OrderPlaced) -> None:
            self._post_event(
                "blue",
                "OrderPlaced",
                f"{event.order_id} ${event.total:.2f}",
            )

        @self._router.on(OrderShipped)
        async def on_order_shipped(event: OrderShipped) -> None:
            self._post_event(
                "yellow",
                "OrderShipped",
                f"{event.order_id} {event.tracking_number}",
            )

        await self._router.start()

    def _post_event(self, color: str, event_type: str, details: str) -> None:
        """Post a message to update the UI."""
        self.post_message(
            self.EventConsumed(self._consumer_id, color, event_type, details)
        )

    def on_consumer_panel_event_consumed(self, message: EventConsumed) -> None:
        """Handle consumed event message and update the log."""
        if message.consumer_id == self._consumer_id:
            try:
                log = self.query_one(RichLog)
                log.write(
                    f"[bold {message.color}]{message.event_type}[/] {message.details}"
                )
            except Exception:
                pass  # Widget might be unmounted

    async def stop(self) -> None:
        """Stop the consumer."""
        if self._router:
            await self._router.stop()
        if self._worker and self._worker.state == WorkerState.RUNNING:
            self._worker.cancel()
