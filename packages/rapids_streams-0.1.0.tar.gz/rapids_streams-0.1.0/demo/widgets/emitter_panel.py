"""Emitter panel widget for selecting and emitting events."""

from textual.app import ComposeResult
from textual.containers import Vertical
from textual.message import Message
from textual.widgets import Button, OptionList, RichLog, Static
from textual.widgets.option_list import Option

from rapids import BaseEvent
from demo.events import EVENT_CLASSES, generate_random_event


class EmitterPanel(Vertical):
    """Left panel for selecting and emitting events."""

    DEFAULT_CSS = """
    EmitterPanel {
        width: 35;
        border: solid green;
        border-title-color: green;
        padding: 1;
    }

    EmitterPanel > Static {
        text-style: bold;
        color: green;
        text-align: center;
        margin-bottom: 1;
    }

    EmitterPanel > OptionList {
        height: auto;
        max-height: 8;
        margin-bottom: 1;
    }

    EmitterPanel > Button {
        width: 100%;
        margin-bottom: 1;
    }

    EmitterPanel > #emit-log {
        height: 1fr;
        border: solid $surface-lighten-2;
        background: $surface;
    }
    """

    class EventEmitRequested(Message):
        """Message sent when user wants to emit an event."""

        def __init__(self, event: BaseEvent) -> None:
            self.event = event
            super().__init__()

    def __init__(self) -> None:
        super().__init__()
        self.border_title = "Emitter"
        self._selected_class: type[BaseEvent] | None = EVENT_CLASSES[0]

    def compose(self) -> ComposeResult:
        yield Static("Select Event Type")
        yield OptionList(
            *[Option(cls.__name__, id=cls.__name__) for cls in EVENT_CLASSES],
            id="event-selector",
        )
        yield Button("Submit Event", id="submit-btn", variant="success")
        yield Static("Emitted Events", classes="section-title")
        yield RichLog(id="emit-log", markup=True, highlight=True)

    def on_mount(self) -> None:
        """Select the first option by default."""
        option_list = self.query_one("#event-selector", OptionList)
        option_list.highlighted = 0

    def on_option_list_option_selected(self, event: OptionList.OptionSelected) -> None:
        """Handle event type selection."""
        selected_name = str(event.option.id)
        for cls in EVENT_CLASSES:
            if cls.__name__ == selected_name:
                self._selected_class = cls
                break

    def on_option_list_option_highlighted(
        self, event: OptionList.OptionHighlighted
    ) -> None:
        """Update selection when highlighted changes."""
        if event.option and event.option.id:
            selected_name = str(event.option.id)
            for cls in EVENT_CLASSES:
                if cls.__name__ == selected_name:
                    self._selected_class = cls
                    break

    def on_button_pressed(self, event: Button.Pressed) -> None:
        """Handle submit button press."""
        if event.button.id == "submit-btn":
            self._emit_selected_event()

    def _emit_selected_event(self) -> None:
        """Generate and emit the selected event type."""
        if self._selected_class is None:
            return

        # Generate random event data
        event = generate_random_event(self._selected_class)

        # Post message to app to emit
        self.post_message(self.EventEmitRequested(event))

    def log_emitted(self, event: BaseEvent) -> None:
        """Log an emitted event to the panel."""
        log = self.query_one("#emit-log", RichLog)
        color = _event_color(event.event_type)
        log.write(f"[{color}]{event.event_type}[/] {event.id[:8]}...")


def _event_color(event_type: str) -> str:
    """Get color for event type."""
    colors = {
        "user.created": "green",
        "user.deleted": "red",
        "order.placed": "blue",
        "order.shipped": "yellow",
    }
    return colors.get(event_type, "white")
