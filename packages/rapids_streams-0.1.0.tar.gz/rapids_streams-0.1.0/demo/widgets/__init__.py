"""Demo widgets for Rapids TUI."""

from demo.widgets.consumer_panel import ConsumerPanel
from demo.widgets.emitter_panel import EmitterPanel

__all__ = ["EmitterPanel", "ConsumerPanel"]
