"""Entry point for running the demo with `python -m demo`."""

from demo.app import main

if __name__ == "__main__":
    main()
