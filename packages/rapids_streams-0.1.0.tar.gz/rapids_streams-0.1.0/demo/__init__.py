"""Rapids TUI Demo - Interactive event emission and consumption visualization."""

from demo.app import RapidsDemo

__all__ = ["RapidsDemo"]
