"""Tests for the correlation context module."""

import asyncio

import pytest

from rapids.emitter.context import (
    correlation_scope,
    get_causation_id,
    get_correlation_id,
    set_causation_id,
    set_correlation_id,
)


class TestGettersSetters:
    """Tests for get/set functions."""

    def test_get_correlation_id_default_is_none(self):
        """Test that correlation_id defaults to None."""
        # Reset to ensure clean state
        set_correlation_id(None)
        assert get_correlation_id() is None

    def test_get_causation_id_default_is_none(self):
        """Test that causation_id defaults to None."""
        set_causation_id(None)
        assert get_causation_id() is None

    def test_set_and_get_correlation_id(self):
        """Test setting and getting correlation_id."""
        set_correlation_id("test-corr-123")
        assert get_correlation_id() == "test-corr-123"
        # Cleanup
        set_correlation_id(None)

    def test_set_and_get_causation_id(self):
        """Test setting and getting causation_id."""
        set_causation_id("test-cause-456")
        assert get_causation_id() == "test-cause-456"
        # Cleanup
        set_causation_id(None)

    def test_set_correlation_id_to_none_clears_it(self):
        """Test that setting to None clears the value."""
        set_correlation_id("some-value")
        assert get_correlation_id() == "some-value"
        set_correlation_id(None)
        assert get_correlation_id() is None


class TestCorrelationScope:
    """Tests for correlation_scope context manager."""

    @pytest.mark.asyncio
    async def test_scope_generates_uuid_when_not_provided(self):
        """Test that scope generates a UUID when correlation_id not provided."""
        async with correlation_scope() as cid:
            assert cid is not None
            assert len(cid) == 36  # UUID format: 8-4-4-4-12
            assert "-" in cid
            assert get_correlation_id() == cid

    @pytest.mark.asyncio
    async def test_scope_uses_provided_correlation_id(self):
        """Test that scope uses the provided correlation_id."""
        async with correlation_scope("my-custom-id") as cid:
            assert cid == "my-custom-id"
            assert get_correlation_id() == "my-custom-id"

    @pytest.mark.asyncio
    async def test_scope_resets_on_exit(self):
        """Test that correlation_id is reset after scope exits."""
        # Ensure clean state
        set_correlation_id(None)

        async with correlation_scope("temp-id"):
            assert get_correlation_id() == "temp-id"

        # After scope, should be back to None
        assert get_correlation_id() is None

    @pytest.mark.asyncio
    async def test_scope_resets_on_exception(self):
        """Test that correlation_id is reset even if exception occurs."""
        set_correlation_id(None)

        with pytest.raises(ValueError, match="test error"):
            async with correlation_scope("temp-id"):
                assert get_correlation_id() == "temp-id"
                raise ValueError("test error")

        # Should be reset even after exception
        assert get_correlation_id() is None

    @pytest.mark.asyncio
    async def test_nested_scopes(self):
        """Test that nested scopes work correctly."""
        set_correlation_id(None)

        async with correlation_scope("outer") as outer_cid:
            assert outer_cid == "outer"
            assert get_correlation_id() == "outer"

            async with correlation_scope("inner") as inner_cid:
                assert inner_cid == "inner"
                assert get_correlation_id() == "inner"

            # Back to outer scope
            assert get_correlation_id() == "outer"

        # Back to None
        assert get_correlation_id() is None

    @pytest.mark.asyncio
    async def test_scope_preserves_previous_value(self):
        """Test that scope restores previous value, not just None."""
        set_correlation_id("existing-value")

        async with correlation_scope("temporary") as cid:
            assert cid == "temporary"
            assert get_correlation_id() == "temporary"

        # Should restore previous value
        assert get_correlation_id() == "existing-value"

        # Cleanup
        set_correlation_id(None)

    @pytest.mark.asyncio
    async def test_concurrent_tasks_have_isolated_scopes(self):
        """Test that concurrent tasks have isolated correlation contexts."""
        results = {}

        async def task_with_scope(name: str, delay: float):
            async with correlation_scope(f"scope-{name}") as cid:
                results[f"{name}_start"] = get_correlation_id()
                await asyncio.sleep(delay)
                results[f"{name}_end"] = get_correlation_id()
                return cid

        # Run two tasks concurrently with different delays
        # Task A starts first but finishes last
        # Task B starts second but finishes first
        task_a = asyncio.create_task(task_with_scope("A", 0.02))
        task_b = asyncio.create_task(task_with_scope("B", 0.01))

        await asyncio.gather(task_a, task_b)

        # Each task should have maintained its own scope
        assert results["A_start"] == "scope-A"
        assert results["A_end"] == "scope-A"
        assert results["B_start"] == "scope-B"
        assert results["B_end"] == "scope-B"

    @pytest.mark.asyncio
    async def test_empty_string_correlation_id_is_used(self):
        """Test that empty string is treated as a valid correlation_id."""
        async with correlation_scope("") as cid:
            assert cid == ""
            assert get_correlation_id() == ""
