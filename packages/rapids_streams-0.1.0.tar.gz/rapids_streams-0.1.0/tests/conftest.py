"""Pytest fixtures for Rapids tests."""

import pytest
import pytest_asyncio
from fakeredis import aioredis as fakeredis

import rapids.emitter.core as emitter_module


@pytest.fixture
def anyio_backend():
    """Use asyncio backend for pytest-asyncio."""
    return "asyncio"


@pytest_asyncio.fixture
async def redis():
    """Provide a fake Redis client for testing."""
    client = fakeredis.FakeRedis()
    yield client
    await client.aclose()


@pytest.fixture(scope="module")
def redis_container():
    """Start a Redis container for testcontainers tests.

    Scoped to module to reuse the container across tests.
    """
    from testcontainers.redis import RedisContainer

    with RedisContainer() as container:
        yield container


@pytest_asyncio.fixture
async def real_redis(redis_container):
    """Provide a real Redis client via testcontainers.

    This fixture creates an async Redis client connected to
    the module-scoped container.
    """
    from redis.asyncio import Redis

    host = redis_container.get_container_host_ip()
    port = redis_container.get_exposed_port(6379)
    client = Redis(host=host, port=int(port), db=0)
    await client.ping()
    yield client
    await client.aclose()


@pytest.fixture(autouse=True)
def reset_emitter():
    """Reset the default emitter before each test."""
    emitter_module._default_emitter = None
    yield
    emitter_module._default_emitter = None
