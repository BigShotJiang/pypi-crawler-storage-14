"""Tests for the router module."""

import asyncio
import contextlib
import json

import pytest
from redis.exceptions import ResponseError

from rapids import BaseEvent, Event, EventRouter
from rapids.events.generic import GenericEvent
from rapids.router.consumer import (
    ConsumerLag,
    GroupStartPosition,
    ReadMode,
    StreamConsumer,
)
from rapids.router.handlers import HandlerRegistration, resolve_event_types


class RouterDocumentCreated(BaseEvent):
    """Test event for router tests."""

    doc_id: str
    title: str


class RouterDocumentDeleted(BaseEvent):
    """Another test event."""

    doc_id: str
    deleted_by: str


class TestHandlerRegistration:
    """Tests for HandlerRegistration."""

    def test_matches_exact_event_type(self):
        """Test matching by exact event type."""

        async def handler(event: BaseEvent) -> None:
            pass

        reg = HandlerRegistration(
            fn=handler,
            event_types={"router_document.created"},
        )

        event = RouterDocumentCreated(doc_id="123", title="Test")
        assert reg.matches(event) is True

    def test_no_match_wrong_type(self):
        """Test no match for different event type."""

        async def handler(event: BaseEvent) -> None:
            pass

        reg = HandlerRegistration(
            fn=handler,
            event_types={"router_document.deleted"},
        )

        event = RouterDocumentCreated(doc_id="123", title="Test")
        assert reg.matches(event) is False

    def test_matches_uses_routing_key(self):
        """Test that matches() uses the unified routing_key property."""

        async def handler(event: Event) -> None:
            pass

        reg = HandlerRegistration(
            fn=handler,
            event_types={"custom.type"},
        )

        # GenericEvent should match via routing_key (raw_type)
        generic_event = GenericEvent(raw_type="custom.type", data={})
        assert reg.matches(generic_event) is True

        # BaseEvent should match via routing_key (event_type)
        typed_event = RouterDocumentCreated(doc_id="123", title="Test")
        assert typed_event.routing_key == "router_document.created"

        reg2 = HandlerRegistration(
            fn=handler,
            event_types={"router_document.created"},
        )
        assert reg2.matches(typed_event) is True


class TestResolveEventTypes:
    """Tests for resolve_event_types function."""

    def test_resolve_single_class(self):
        """Test resolving a single event class."""
        event_types, event_classes, patterns = resolve_event_types(
            RouterDocumentCreated
        )

        assert event_types == {"router_document.created"}
        assert RouterDocumentCreated in event_classes
        assert patterns == set()

    def test_resolve_string_pattern(self):
        """Test resolving a string pattern."""
        event_types, event_classes, patterns = resolve_event_types("document.*")

        assert event_types == set()
        assert event_classes == set()
        assert patterns == {"document.*"}

    def test_resolve_catch_all_pattern(self):
        """Test resolving catch-all pattern."""
        event_types, event_classes, patterns = resolve_event_types("*")

        assert event_types == set()
        assert event_classes == set()
        assert patterns == {"*"}

    def test_resolve_union_type(self):
        """Test resolving union type."""
        event_types, event_classes, patterns = resolve_event_types(
            RouterDocumentCreated | RouterDocumentDeleted
        )

        assert "router_document.created" in event_types
        assert "router_document.deleted" in event_types
        assert RouterDocumentCreated in event_classes
        assert RouterDocumentDeleted in event_classes
        assert patterns == set()

    def test_resolve_base_class_with_subclasses(self):
        """Test resolving base class includes subclass event_types."""
        from typing import ClassVar

        class TestBaseEvent(BaseEvent):
            _skip_registration: ClassVar[bool] = True
            entity_id: str

        class TestSubEventA(TestBaseEvent):
            name: str

        class TestSubEventB(TestBaseEvent):
            value: int

        event_types, event_classes, patterns = resolve_event_types(TestBaseEvent)

        # Should include subclass event_types but NOT empty base class event_type
        assert "test_sub_event.a" in event_types
        assert "test_sub_event.b" in event_types
        assert "" not in event_types  # Empty event_types should be excluded
        # Base class should be in event_classes for isinstance matching
        assert TestBaseEvent in event_classes

    def test_resolve_invalid_target_raises(self):
        """Test that invalid target raises TypeError."""
        import pytest

        with pytest.raises(TypeError, match="Invalid target"):
            resolve_event_types(123)  # type: ignore[arg-type]


class TestStreamConsumer:
    """Tests for StreamConsumer."""

    @pytest.mark.asyncio
    async def test_ensure_group_creates_group(self, redis):
        """Test that ensure_group creates the consumer group."""
        consumer = StreamConsumer(
            redis=redis,
            stream="test:events",
            group="test-group",
            consumer="consumer-1",
        )

        await consumer.ensure_group()

        # Verify group was created by checking XINFO GROUPS
        groups = await redis.xinfo_groups("test:events")
        assert len(groups) == 1
        assert groups[0]["name"] == b"test-group"

    @pytest.mark.asyncio
    async def test_ensure_group_idempotent(self, redis):
        """Test that ensure_group is idempotent."""
        consumer = StreamConsumer(
            redis=redis,
            stream="test:events",
            group="test-group",
            consumer="consumer-1",
        )

        # Call twice - should not raise
        await consumer.ensure_group()
        await consumer.ensure_group()

        groups = await redis.xinfo_groups("test:events")
        assert len(groups) == 1

    @pytest.mark.asyncio
    async def test_read_returns_messages(self, redis):
        """Test reading messages from stream."""
        # Add some messages first
        await redis.xadd(
            "test:events",
            {
                "event_type": "router_document.created",
                "data": json.dumps({"doc_id": "123", "title": "Test"}),
                "id": "event-1",
                "timestamp": "2024-01-15T10:00:00Z",
                "correlation_id": "",
                "causation_id": "",
                "metadata": "{}",
            },
        )

        consumer = StreamConsumer(
            redis=redis,
            stream="test:events",
            group="test-group",
            consumer="consumer-1",
            block_ms=100,  # Short timeout for tests
        )
        await consumer.ensure_group()

        messages = await consumer.read()

        assert len(messages) == 1
        assert messages[0]["data"]["event_type"] == "router_document.created"
        assert messages[0]["data"]["id"] == "event-1"

    @pytest.mark.asyncio
    async def test_ack_removes_from_pending(self, redis):
        """Test that ack removes message from pending."""
        # Add a message
        await redis.xadd(
            "test:events",
            {"event_type": "test", "data": "{}"},
        )

        consumer = StreamConsumer(
            redis=redis,
            stream="test:events",
            group="test-group",
            consumer="consumer-1",
            block_ms=100,
        )
        await consumer.ensure_group()

        # Read the message (puts it in pending)
        messages = await consumer.read()
        assert len(messages) == 1

        # Check pending count
        pending = await redis.xpending("test:events", "test-group")
        assert pending["pending"] == 1

        # Ack the message
        await consumer.ack(messages[0]["id"])

        # Check pending is now empty
        pending = await redis.xpending("test:events", "test-group")
        assert pending["pending"] == 0

    @pytest.mark.asyncio
    async def test_read_empty_returns_empty_list(self, redis):
        """Test that read() returns empty list when no new messages."""
        consumer = StreamConsumer(
            redis=redis,
            stream="test:events",
            group="test-group",
            consumer="consumer-1",
            block_ms=10,  # Very short timeout
        )
        await consumer.ensure_group()

        # Read with no messages should return empty list
        messages = await consumer.read()
        assert messages == []

    @pytest.mark.asyncio
    async def test_ensure_group_reraises_non_busygroup_error(self, redis):
        """Test that ensure_group re-raises non-BUSYGROUP errors."""
        from unittest.mock import AsyncMock, patch

        from redis.exceptions import ResponseError

        consumer = StreamConsumer(
            redis=redis,
            stream="test:events",
            group="test-group",
            consumer="consumer-1",
        )

        # Mock xgroup_create to raise a different error
        with patch.object(
            redis, "xgroup_create", new_callable=AsyncMock
        ) as mock_create:
            mock_create.side_effect = ResponseError("SOME_OTHER_ERROR")

            with pytest.raises(ResponseError, match="SOME_OTHER_ERROR"):
                await consumer.ensure_group()

    @pytest.mark.asyncio
    async def test_start_from_dollar_only_reads_new_messages(self, redis):
        """Test that group_start_id='$' only reads messages after group creation."""
        # Add a message BEFORE creating the consumer group
        await redis.xadd(
            "test:events",
            {"event_type": "old_event", "data": "{}"},
        )

        # Create consumer with group_start_id="$"
        consumer = StreamConsumer(
            redis=redis,
            stream="test:events",
            group="test-group-dollar",
            consumer="consumer-1",
            block_ms=100,
            group_start_id=GroupStartPosition.LATEST,
        )
        await consumer.ensure_group()

        # Add a message AFTER creating the consumer group
        await redis.xadd(
            "test:events",
            {"event_type": "new_event", "data": "{}"},
        )

        # Should only read the new message
        messages = await consumer.read()
        assert len(messages) == 1
        assert messages[0]["data"]["event_type"] == "new_event"

    @pytest.mark.asyncio
    async def test_start_from_zero_reads_all_messages(self, redis):
        """Test that group_start_id='0' reads all messages from beginning."""
        # Add a message BEFORE creating the consumer group
        await redis.xadd(
            "test:events",
            {"event_type": "old_event", "data": "{}"},
        )

        # Create consumer with group_start_id=BEGINNING (default)
        consumer = StreamConsumer(
            redis=redis,
            stream="test:events",
            group="test-group-zero",
            consumer="consumer-1",
            block_ms=100,
            group_start_id=GroupStartPosition.BEGINNING,
        )
        await consumer.ensure_group()

        # Should read the old message
        messages = await consumer.read()
        assert len(messages) == 1
        assert messages[0]["data"]["event_type"] == "old_event"

    @pytest.mark.asyncio
    async def test_read_with_start_id_zero_uses_correct_start_id(self, redis):
        """Test that read(read_mode=PENDING) passes correct start_id to Redis."""
        from unittest.mock import AsyncMock, patch

        consumer = StreamConsumer(
            redis=redis,
            stream="test:events",
            group="test-group-pending",
            consumer="consumer-1",
            block_ms=100,
        )

        # Mock xreadgroup to verify correct parameters
        with patch.object(
            redis, "xreadgroup", new_callable=AsyncMock
        ) as mock_xreadgroup:
            mock_xreadgroup.return_value = []
            await consumer.read(read_mode=ReadMode.PENDING)

            # Verify read_mode="0" is passed and blocking is disabled
            mock_xreadgroup.assert_called_once()
            call_kwargs = mock_xreadgroup.call_args.kwargs
            assert call_kwargs["streams"] == {"test:events": "0"}
            assert call_kwargs["block"] is None  # No blocking for pending recovery

    @pytest.mark.asyncio
    async def test_read_with_start_id_zero_does_not_block(self, redis):
        """Test that read(read_mode=PENDING) doesn't block when no pending messages."""
        import time

        consumer = StreamConsumer(
            redis=redis,
            stream="test:events",
            group="test-group-noblock",
            consumer="consumer-1",
            block_ms=5000,  # Long timeout that would cause delay if blocking
        )
        await consumer.ensure_group()

        # Reading with read_mode=PENDING should return immediately (no blocking)
        start = time.monotonic()
        messages = await consumer.read(read_mode=ReadMode.PENDING)
        elapsed = time.monotonic() - start

        assert messages == []
        # Should complete much faster than block_ms
        assert elapsed < 1.0

    @pytest.mark.asyncio
    async def test_autoclaim_returns_cursor_and_messages(self, redis):
        """Test that autoclaim() returns next cursor and claimed messages."""
        # Add a message and read it with consumer-1
        await redis.xadd(
            "test:events",
            {"event_type": "claim_test", "data": "{}"},
        )

        consumer1 = StreamConsumer(
            redis=redis,
            stream="test:events",
            group="test-group-claim",
            consumer="consumer-1",
            block_ms=100,
        )
        await consumer1.ensure_group()

        # Consumer 1 reads but doesn't ack
        messages = await consumer1.read()
        assert len(messages) == 1

        # Consumer 2 claims the message
        consumer2 = StreamConsumer(
            redis=redis,
            stream="test:events",
            group="test-group-claim",
            consumer="consumer-2",
            block_ms=100,
        )

        # Claim with 0 idle time to claim immediately for testing
        next_cursor, claimed = await consumer2.autoclaim(min_idle_ms=0, start="0-0")

        # Should return cursor and claimed message
        assert isinstance(next_cursor, str)
        assert len(claimed) == 1
        assert claimed[0]["data"]["event_type"] == "claim_test"

    @pytest.mark.asyncio
    async def test_autoclaim_handles_empty_result(self, redis):
        """Test that autoclaim() handles no claimable messages."""
        consumer = StreamConsumer(
            redis=redis,
            stream="test:events",
            group="test-group-empty-claim",
            consumer="consumer-1",
            block_ms=100,
        )
        await consumer.ensure_group()

        # No messages to claim
        next_cursor, claimed = await consumer.autoclaim(min_idle_ms=0, start="0-0")

        assert next_cursor == "0-0"  # No messages, cursor stays at start
        assert claimed == []

    @pytest.mark.asyncio
    async def test_get_delivery_counts_filters_by_consumer(self, redis):
        """Verify _get_delivery_counts only returns this consumer's messages.

        When multiple consumers have pending messages in the same ID range,
        _get_delivery_counts should only return counts for the calling consumer,
        not messages pending for other consumers.
        """
        stream = "test:filter-stream"
        group = "test-filter-group"

        # Create two consumers
        consumer1 = StreamConsumer(
            redis=redis, stream=stream, group=group, consumer="consumer-1", block_ms=100
        )
        consumer2 = StreamConsumer(
            redis=redis, stream=stream, group=group, consumer="consumer-2", block_ms=100
        )

        await consumer1.ensure_group()

        # Add 2 messages
        msg1_id = await redis.xadd(stream, {"event_type": "test", "data": "{}"})
        msg2_id = await redis.xadd(stream, {"event_type": "test", "data": "{}"})

        # Consumer1 reads msg1 (doesn't ack)
        await redis.xreadgroup(group, "consumer-1", streams={stream: ">"}, count=1)
        # Consumer2 reads msg2 (doesn't ack)
        await redis.xreadgroup(group, "consumer-2", streams={stream: ">"}, count=1)

        # Decode IDs for comparison
        msg1_id_str = msg1_id.decode() if isinstance(msg1_id, bytes) else msg1_id
        msg2_id_str = msg2_id.decode() if isinstance(msg2_id, bytes) else msg2_id

        # Get delivery counts for consumer1 - should only see msg1
        counts1 = await consumer1._get_delivery_counts([msg1_id_str, msg2_id_str])
        assert msg1_id_str in counts1  # Consumer1 owns msg1
        assert msg2_id_str not in counts1  # Consumer2 owns msg2, should not appear

        # Get delivery counts for consumer2 - should only see msg2
        counts2 = await consumer2._get_delivery_counts([msg1_id_str, msg2_id_str])
        assert msg1_id_str not in counts2  # Consumer1 owns msg1, should not appear
        assert msg2_id_str in counts2  # Consumer2 owns msg2


class TestEventRouter:
    """Tests for EventRouter."""

    def test_on_decorator_registers_handler(self, redis):
        """Test that @on decorator registers the handler."""
        router = EventRouter(redis=redis, group="test-group")

        @router.on(RouterDocumentCreated)
        async def handler(event: RouterDocumentCreated) -> None:
            pass

        assert len(router._handlers) == 1
        assert "router_document.created" in router._handlers[0].event_types

    def test_handler_type_matches_event_class(self, redis):
        """Test that handler parameter type must match @on() event class.

        The generic types on @router.on() ensure that static type checkers
        (ty/mypy/pyright) will catch mismatches. For example, this would
        fail type checking:

            @router.on(RouterDocumentCreated)
            async def bad(event: RouterDocumentDeleted) -> None:  # type error!
                pass

        This test verifies correct typing works at runtime.
        """
        router = EventRouter(redis=redis, group="test-group")

        @router.on(RouterDocumentCreated)
        async def good(event: RouterDocumentCreated) -> None:
            pass

        assert len(router._handlers) == 1

    def test_multiple_handlers_same_event(self, redis):
        """Test registering multiple handlers for same event."""
        router = EventRouter(redis=redis, group="test-group")

        @router.on(RouterDocumentCreated)
        async def handler1(event: RouterDocumentCreated) -> None:
            pass

        @router.on(RouterDocumentCreated)
        async def handler2(event: RouterDocumentCreated) -> None:
            pass

        assert len(router._handlers) == 2

    def test_match_handlers_finds_correct_handlers(self, redis):
        """Test _match_handlers finds correct handlers."""
        router = EventRouter(redis=redis, group="test-group")

        @router.on(RouterDocumentCreated)
        async def handle_created(event: RouterDocumentCreated) -> None:
            pass

        @router.on(RouterDocumentDeleted)
        async def handle_deleted(event: RouterDocumentDeleted) -> None:
            pass

        event = RouterDocumentCreated(doc_id="123", title="Test")
        matching = router._match_handlers(event)

        assert len(matching) == 1
        assert matching[0].fn.__name__ == "handle_created"

    def test_deserialize_known_event(self, redis):
        """Test deserializing a known event type."""
        router = EventRouter(redis=redis, group="test-group")

        raw = {
            "event_type": "router_document.created",
            "data": json.dumps({"doc_id": "123", "title": "Test"}),
            "id": "event-1",
            "timestamp": "2024-01-15T10:00:00+00:00",
            "correlation_id": "corr-123",
            "causation_id": "",
            "metadata": "{}",
        }

        event = router._deserialize(raw)

        assert isinstance(event, RouterDocumentCreated)
        assert event.doc_id == "123"
        assert event.title == "Test"
        assert event.id == "event-1"
        assert event.correlation_id == "corr-123"

    def test_deserialize_unknown_event(self, redis):
        """Test deserializing an unknown event type."""
        router = EventRouter(redis=redis, group="test-group")

        raw = {
            "event_type": "unknown.event.type",
            "data": json.dumps({"foo": "bar"}),
            "id": "event-1",
            "timestamp": "2024-01-15T10:00:00+00:00",
            "correlation_id": "",
            "causation_id": "",
            "metadata": "{}",
        }

        event = router._deserialize(raw)

        assert isinstance(event, GenericEvent)
        assert event.raw_type == "unknown.event.type"
        assert event.data == {"foo": "bar"}

    @pytest.mark.asyncio
    async def test_dispatch_calls_handlers(self, redis):
        """Test that dispatch calls matching handlers."""
        router = EventRouter(redis=redis, group="test-group")

        results = []

        @router.on(RouterDocumentCreated)
        async def handler(event: RouterDocumentCreated) -> None:
            results.append(event.doc_id)

        event = RouterDocumentCreated(doc_id="123", title="Test")
        matching = router._match_handlers(event)

        await router._dispatch(event, matching)

        assert results == ["123"]

    @pytest.mark.asyncio
    async def test_dispatch_calls_multiple_handlers(self, redis):
        """Test that dispatch calls all matching handlers."""
        router = EventRouter(redis=redis, group="test-group")

        results = []

        @router.on(RouterDocumentCreated)
        async def handler1(event: RouterDocumentCreated) -> None:
            results.append("handler1")

        @router.on(RouterDocumentCreated)
        async def handler2(event: RouterDocumentCreated) -> None:
            results.append("handler2")

        event = RouterDocumentCreated(doc_id="123", title="Test")
        matching = router._match_handlers(event)

        await router._dispatch(event, matching)

        assert "handler1" in results
        assert "handler2" in results

    @pytest.mark.asyncio
    async def test_process_message_full_flow(self, redis):
        """Test processing a message end-to-end."""
        router = EventRouter(redis=redis, stream="test:events", group="test-group")

        results = []

        @router.on(RouterDocumentCreated)
        async def handler(event: RouterDocumentCreated) -> None:
            results.append(event.doc_id)

        # Create consumer and add message
        router._stream_consumer = StreamConsumer(
            redis=redis,
            stream="test:events",
            group="test-group",
            consumer="test-consumer",
        )
        await router._stream_consumer.ensure_group()

        # Add message to stream
        await redis.xadd(
            "test:events",
            {
                "event_type": "router_document.created",
                "data": json.dumps({"doc_id": "123", "title": "Test"}),
                "id": "event-1",
                "timestamp": "2024-01-15T10:00:00+00:00",
                "correlation_id": "",
                "causation_id": "",
                "metadata": "{}",
            },
        )

        # Read and process
        messages = await router._stream_consumer.read()
        assert len(messages) == 1

        await router._process_message(messages[0])

        assert results == ["123"]

        # Verify message was acked
        pending = await redis.xpending("test:events", "test-group")
        assert pending["pending"] == 0

    def test_deserialize_invalid_data_raises(self, redis):
        """Test that invalid event data raises DeserializationError."""
        from rapids.exceptions import DeserializationError

        router = EventRouter(redis=redis, group="test-group")

        raw = {
            "event_type": "router_document.created",
            "data": "invalid json{",  # Invalid JSON
            "id": "event-1",
            "timestamp": "2024-01-15T10:00:00+00:00",
            "correlation_id": "",
            "causation_id": "",
            "metadata": "{}",
        }

        with pytest.raises(DeserializationError):
            router._deserialize(raw)

    def test_deserialize_generic_event_invalid_timestamp_raises(self, redis):
        """Test that invalid timestamp in GenericEvent raises DeserializationError."""
        from rapids.exceptions import DeserializationError

        router = EventRouter(redis=redis, group="test-group")

        raw = {
            "event_type": "unknown.event.type",  # Unknown type -> GenericEvent path
            "data": "{}",
            "id": "event-1",
            "timestamp": "not-a-valid-timestamp",  # Invalid timestamp
            "correlation_id": "",
            "causation_id": "",
            "metadata": "{}",
        }

        with pytest.raises(DeserializationError, match="unknown.event.type"):
            router._deserialize(raw)

    def test_deserialize_generic_event_invalid_data_json_raises(self, redis):
        """Test that invalid data JSON in GenericEvent raises DeserializationError."""
        from rapids.exceptions import DeserializationError

        router = EventRouter(redis=redis, group="test-group")

        raw = {
            "event_type": "unknown.event.type",  # Unknown type -> GenericEvent path
            "data": "invalid json{",  # Invalid JSON
            "id": "event-1",
            "timestamp": "2024-01-15T10:00:00+00:00",
            "correlation_id": "",
            "causation_id": "",
            "metadata": "{}",
        }

        with pytest.raises(DeserializationError, match="unknown.event.type"):
            router._deserialize(raw)

    def test_deserialize_generic_event_invalid_metadata_json_raises(self, redis):
        """Test that invalid metadata JSON in GenericEvent raises DeserializationError."""
        from rapids.exceptions import DeserializationError

        router = EventRouter(redis=redis, group="test-group")

        raw = {
            "event_type": "unknown.event.type",  # Unknown type -> GenericEvent path
            "data": "{}",
            "id": "event-1",
            "timestamp": "2024-01-15T10:00:00+00:00",
            "correlation_id": "",
            "causation_id": "",
            "metadata": "{invalid metadata",  # Invalid JSON
        }

        with pytest.raises(DeserializationError, match="unknown.event.type"):
            router._deserialize(raw)

    def test_match_handlers_with_generic_event(self, redis):
        """Test matching handlers for GenericEvent by raw_type."""
        router = EventRouter(redis=redis, group="test-group")

        # Register handler with event_type that matches raw_type
        async def handler(event: BaseEvent) -> None:
            pass

        from rapids.router.handlers import HandlerRegistration

        registration = HandlerRegistration(
            fn=handler,
            event_types={"unknown.type"},
        )
        router._handlers.append(registration)

        # Create a GenericEvent
        event = GenericEvent(raw_type="unknown.type", data={})
        matching = router._match_handlers(event)

        assert len(matching) == 1

    @pytest.mark.asyncio
    async def test_dispatch_handler_exception_raises_max_retries_exceeded(self, redis):
        """Test that handler exceptions are wrapped in MaxRetriesExceededError."""
        from rapids.exceptions import MaxRetriesExceededError

        router = EventRouter(redis=redis, group="test-group")

        @router.on(RouterDocumentCreated)
        async def failing_handler(event: RouterDocumentCreated) -> None:
            raise ValueError("Handler failed")

        event = RouterDocumentCreated(doc_id="123", title="Test")
        matching = router._match_handlers(event)

        with pytest.raises(MaxRetriesExceededError) as exc_info:
            await router._dispatch(event, matching)
        assert isinstance(exc_info.value.last_error, ValueError)
        assert "Handler failed" in str(exc_info.value.last_error)

    @pytest.mark.asyncio
    async def test_dispatch_handler_timeout(self, redis):
        """Test that slow handlers are cancelled after timeout."""
        from rapids.exceptions import MaxRetriesExceededError

        router = EventRouter(redis=redis, group="test-group", handler_timeout=0.1)

        @router.on(RouterDocumentCreated)
        async def slow_handler(event: RouterDocumentCreated) -> None:
            await asyncio.sleep(10)  # Much longer than timeout

        event = RouterDocumentCreated(doc_id="123", title="Test")
        matching = router._match_handlers(event)

        with pytest.raises(MaxRetriesExceededError) as exc_info:
            await router._dispatch(event, matching)
        assert isinstance(exc_info.value.last_error, TimeoutError)

    @pytest.mark.asyncio
    async def test_stop_sets_running_false(self, redis):
        """Test that stop() sets _running to False."""
        router = EventRouter(redis=redis, group="test-group")
        router._running = True

        await router.stop()

        assert router._running is False

    @pytest.mark.asyncio
    async def test_process_message_no_handlers_logs_debug(self, redis, caplog):
        """Test that processing a message with no handlers logs debug message."""
        import logging

        router = EventRouter(redis=redis, stream="test:events", group="test-group")

        # Create consumer
        router._stream_consumer = StreamConsumer(
            redis=redis,
            stream="test:events",
            group="test-group",
            consumer="test-consumer",
        )
        await router._stream_consumer.ensure_group()

        # Add a message that has no registered handlers
        await redis.xadd(
            "test:events",
            {
                "event_type": "unhandled.event.type",
                "data": "{}",
                "id": "event-1",
                "timestamp": "2024-01-15T10:00:00+00:00",
                "correlation_id": "",
                "causation_id": "",
                "metadata": "{}",
            },
        )

        messages = await router._stream_consumer.read()
        assert len(messages) == 1

        with caplog.at_level(logging.DEBUG):
            await router._process_message(messages[0])

        assert "No handlers for event type" in caplog.text

    @pytest.mark.asyncio
    async def test_process_message_deserialization_error_acks_message(self, redis):
        """Test that DeserializationError still acks the message to prevent infinite retry."""
        router = EventRouter(redis=redis, stream="test:events", group="test-group")

        # Create consumer
        router._stream_consumer = StreamConsumer(
            redis=redis,
            stream="test:events",
            group="test-group",
            consumer="test-consumer",
        )
        await router._stream_consumer.ensure_group()

        # Add a message with invalid data
        await redis.xadd(
            "test:events",
            {
                "event_type": "router_document.created",
                "data": "{invalid json",  # Invalid JSON
                "id": "event-1",
                "timestamp": "2024-01-15T10:00:00+00:00",
                "correlation_id": "",
                "causation_id": "",
                "metadata": "{}",
            },
        )

        messages = await router._stream_consumer.read()
        assert len(messages) == 1

        # Process should not raise - just log and ack
        await router._process_message(messages[0])

        # Message should be acked (not pending)
        pending = await redis.xpending("test:events", "test-group")
        assert pending["pending"] == 0

    @pytest.mark.asyncio
    async def test_process_message_handler_exception_does_not_ack(self, redis):
        """Test that handler exceptions prevent message ack (for redelivery)."""
        router = EventRouter(redis=redis, stream="test:events", group="test-group")

        @router.on(RouterDocumentCreated)
        async def failing_handler(event: RouterDocumentCreated) -> None:
            raise ValueError("Handler failed")

        # Create consumer
        router._stream_consumer = StreamConsumer(
            redis=redis,
            stream="test:events",
            group="test-group",
            consumer="test-consumer",
        )
        await router._stream_consumer.ensure_group()

        # Add a message
        await redis.xadd(
            "test:events",
            {
                "event_type": "router_document.created",
                "data": '{"doc_id": "123", "title": "Test"}',
                "id": "event-1",
                "timestamp": "2024-01-15T10:00:00+00:00",
                "correlation_id": "",
                "causation_id": "",
                "metadata": "{}",
            },
        )

        messages = await router._stream_consumer.read()
        assert len(messages) == 1

        # Process should not raise outward - exception is caught
        await router._process_message(messages[0])

        # Message should NOT be acked (still pending for redelivery)
        pending = await redis.xpending("test:events", "test-group")
        assert pending["pending"] == 1

    @pytest.mark.asyncio
    async def test_dispatch_multiple_handlers_second_fails(self, redis):
        """Test that if second handler fails, first handler's success is not rolled back.

        This verifies partial success behavior: when multiple handlers match
        an event and a later handler fails, earlier handlers' side effects persist.
        """
        from rapids.exceptions import MaxRetriesExceededError

        router = EventRouter(redis=redis, group="test")
        results = []

        @router.on(RouterDocumentCreated)
        async def handler1(event: RouterDocumentCreated) -> None:
            results.append("h1")

        @router.on(RouterDocumentCreated)
        async def handler2(event: RouterDocumentCreated) -> None:
            results.append("h2_start")
            raise ValueError("Handler 2 failed")

        event = RouterDocumentCreated(doc_id="123", title="Test")
        matching = router._match_handlers(event)

        # Second handler will fail, wrapping in MaxRetriesExceededError
        with pytest.raises(MaxRetriesExceededError) as exc_info:
            await router._dispatch(event, matching)

        # First handler completed successfully before second failed
        assert "h1" in results
        assert "h2_start" in results
        assert isinstance(exc_info.value.last_error, ValueError)


class TestConsumeLoopErrorHandling:
    """Tests for consume loop error handling."""

    @pytest.mark.asyncio
    async def test_consume_loop_without_start_raises(self, redis):
        """Test that _consume_loop raises if called before start()."""
        router = EventRouter(redis=redis, stream="test:events", group="test-group")

        # _stream_consumer is None since start() wasn't called
        with pytest.raises(RuntimeError, match="Stream consumer not initialized"):
            await router._consume_loop()

    @pytest.mark.asyncio
    async def test_process_message_without_start_raises(self, redis):
        """Test that _process_message raises if stream_consumer is None."""
        router = EventRouter(redis=redis, stream="test:events", group="test-group")

        # _stream_consumer is None since start() wasn't called
        with pytest.raises(RuntimeError, match="Stream consumer not initialized"):
            await router._process_message({"id": "test", "data": {}})

    @pytest.mark.asyncio
    async def test_consume_loop_recovers_from_transient_errors(self, redis):
        """Test that consume loop continues after transient errors with backoff."""
        from unittest.mock import AsyncMock, patch

        router = EventRouter(redis=redis, stream="test:events", group="test-group")

        # Create a mock stream consumer
        mock_consumer = AsyncMock()
        call_count = 0

        async def read_with_errors(read_mode: ReadMode = ReadMode.NEW):
            nonlocal call_count
            call_count += 1

            # Phase 1: Pending recovery - first call returns empty to skip to phase 2
            if read_mode == ReadMode.PENDING:
                return []

            # Phase 2: Normal consumption with errors
            if call_count <= 3:  # 1 pending check + 2 errors
                raise ConnectionError("Transient error")
            # After errors, stop the router
            router._running = False
            return []

        mock_consumer.read = read_with_errors
        mock_consumer.autoclaim = AsyncMock(return_value=("0-0", []))
        router._stream_consumer = mock_consumer
        router._running = True

        sleep_calls = []

        async def mock_sleep(delay):
            sleep_calls.append(delay)

        with patch("rapids.router.core.asyncio.sleep", side_effect=mock_sleep):
            await router._consume_loop()

        # Should have called read multiple times (1 pending + 2 errors + 1 success)
        assert call_count == 4
        # Should have slept twice with exponential backoff
        assert len(sleep_calls) == 2
        # First backoff: min(1.0 * 2^1, 60) = 2.0
        assert sleep_calls[0] == 2.0
        # Second backoff: min(1.0 * 2^2, 60) = 4.0
        assert sleep_calls[1] == 4.0


class TestPendingRecovery:
    """Tests for pending message recovery functionality."""

    @pytest.mark.asyncio
    async def test_consume_loop_recovers_own_pending_on_startup(self, redis):
        """Test that _consume_loop recovers own pending before reading new."""
        from unittest.mock import AsyncMock

        router = EventRouter(redis=redis, stream="test:events", group="test-group")

        # Track which phases were called
        phase_calls = []

        async def mock_read(read_mode: ReadMode = ReadMode.NEW):
            phase_calls.append(read_mode)
            if read_mode == ReadMode.PENDING:
                # Return one pending message, then empty to complete Phase 1
                if phase_calls.count(ReadMode.PENDING) == 1:
                    return [
                        {
                            "id": "pending-1",
                            "data": {
                                "event_type": "test.event",
                                "data": "{}",
                                "id": "evt-1",
                                "timestamp": "2024-01-15T10:00:00+00:00",
                                "correlation_id": "",
                                "causation_id": "",
                                "metadata": "{}",
                            },
                        }
                    ]
                return []  # No more pending, move to Phase 2
            else:
                # Phase 2: Stop after first new read
                router._running = False
                return []

        mock_consumer = AsyncMock()
        mock_consumer.read = mock_read
        mock_consumer.ack = AsyncMock()
        mock_consumer.autoclaim = AsyncMock(return_value=("0-0", []))
        router._stream_consumer = mock_consumer
        router._running = True

        await router._consume_loop()

        # Should have called read(PENDING) for pending recovery first
        assert ReadMode.PENDING in phase_calls
        # Should have called read(NEW) for new messages
        assert ReadMode.NEW in phase_calls
        # Phase 1 should come before Phase 2
        first_pending_idx = phase_calls.index(ReadMode.PENDING)
        first_new_idx = phase_calls.index(ReadMode.NEW)
        assert first_pending_idx < first_new_idx

    @pytest.mark.asyncio
    async def test_consume_loop_calls_autoclaim_after_interval(self, redis):
        """Test that _consume_loop calls autoclaim every N reads."""
        from unittest.mock import AsyncMock

        router = EventRouter(
            redis=redis,
            stream="test:events",
            group="test-group",
            claim_interval=3,  # Call autoclaim every 3 reads
        )

        read_count = 0
        autoclaim_calls = []

        async def mock_read(read_mode: ReadMode = ReadMode.NEW):
            nonlocal read_count
            if read_mode == ReadMode.PENDING:
                return []  # Skip pending recovery
            read_count += 1
            if read_count >= 7:  # Stop after 7 reads
                router._running = False
            return []

        async def mock_autoclaim(**kwargs):
            autoclaim_calls.append(read_count)
            return ("0-0", [])

        mock_consumer = AsyncMock()
        mock_consumer.read = mock_read
        mock_consumer.autoclaim = mock_autoclaim
        router._stream_consumer = mock_consumer
        router._running = True

        await router._consume_loop()

        # With claim_interval=3, should call autoclaim at reads 3 and 6
        assert 3 in autoclaim_calls
        assert 6 in autoclaim_calls
        assert len(autoclaim_calls) == 2

    @pytest.mark.asyncio
    async def test_claim_from_dead_consumers_processes_messages(self, redis):
        """Test that claimed messages are processed normally."""
        from unittest.mock import AsyncMock

        router = EventRouter(redis=redis, stream="test:events", group="test-group")

        processed_ids = []

        @router.on("test.*")
        async def handler(event):
            processed_ids.append(event.id)

        async def mock_autoclaim(**kwargs):
            return (
                "0-0",
                [
                    {
                        "id": "claimed-1",
                        "data": {
                            "event_type": "test.claimed",
                            "data": "{}",
                            "id": "evt-claimed",
                            "timestamp": "2024-01-15T10:00:00+00:00",
                            "correlation_id": "",
                            "causation_id": "",
                            "metadata": "{}",
                        },
                    }
                ],
            )

        mock_consumer = AsyncMock()
        mock_consumer.autoclaim = mock_autoclaim
        mock_consumer.ack = AsyncMock()
        router._stream_consumer = mock_consumer

        await router._claim_from_dead_consumers()

        # Claimed message should be processed
        assert "evt-claimed" in processed_ids

    @pytest.mark.asyncio
    async def test_claim_from_dead_consumers_resets_cursor_on_error(self, redis):
        """Test that cursor resets to 0-0 on autoclaim error."""
        from unittest.mock import AsyncMock

        router = EventRouter(redis=redis, stream="test:events", group="test-group")
        router._claim_cursor = "12345-0"  # Non-zero cursor

        async def mock_autoclaim(**kwargs):
            raise ConnectionError("Redis connection lost")

        mock_consumer = AsyncMock()
        mock_consumer.autoclaim = mock_autoclaim
        router._stream_consumer = mock_consumer

        # Should not raise, but reset cursor
        await router._claim_from_dead_consumers()

        assert router._claim_cursor == "0-0"

    @pytest.mark.asyncio
    async def test_claim_from_dead_consumers_noop_without_consumer(self, redis):
        """Test that _claim_from_dead_consumers is a no-op without stream_consumer."""
        router = EventRouter(redis=redis, stream="test:events", group="test-group")
        router._stream_consumer = None

        # Should not raise
        await router._claim_from_dead_consumers()

    def test_router_init_claim_params(self, redis):
        """Test that router accepts claim configuration parameters."""
        router = EventRouter(
            redis=redis,
            stream="test:events",
            group="test-group",
            claim_interval=5,
            claim_min_idle_ms=30_000,
        )

        assert router._claim_interval == 5
        assert router._claim_min_idle_ms == 30_000
        assert router._claim_cursor == "0-0"
        assert router._reads_since_claim == 0

    @pytest.mark.asyncio
    async def test_stop_during_phase1_skips_phase2(self, redis):
        """stop() called during Phase 1 prevents Phase 2 from running."""
        from unittest.mock import AsyncMock

        router = EventRouter(redis=redis, stream="test:events", group="test-group")

        phase_calls = []

        async def mock_read(read_mode: ReadMode = ReadMode.NEW):
            phase_calls.append(read_mode)
            if read_mode == ReadMode.PENDING:
                # After processing one batch, set _running=False (simulates stop())
                if len([c for c in phase_calls if c == ReadMode.PENDING]) == 1:
                    return [
                        {
                            "id": "msg-1",
                            "data": {
                                "event_type": "test.event",
                                "data": "{}",
                                "id": "evt-1",
                                "timestamp": "2024-01-15T10:00:00+00:00",
                                "correlation_id": "",
                                "causation_id": "",
                                "metadata": "{}",
                            },
                        }
                    ]
                # Second call in Phase 1 - stop the router
                router._running = False
                return []
            # Phase 2 - should never be reached
            return []

        mock_consumer = AsyncMock()
        mock_consumer.read = mock_read
        mock_consumer.ack = AsyncMock()
        router._stream_consumer = mock_consumer
        router._running = True

        await router._consume_loop()

        # Phase 2 should never have been called
        assert ReadMode.NEW not in phase_calls
        # Only Phase 1 calls
        assert all(c == ReadMode.PENDING for c in phase_calls)

    @pytest.mark.asyncio
    async def test_cancelled_error_in_phase1_returns_immediately(self, redis):
        """CancelledError during Phase 1 causes immediate return."""
        from unittest.mock import AsyncMock

        router = EventRouter(redis=redis, stream="test:events", group="test-group")

        phase_calls = []

        async def mock_read(read_mode: ReadMode = ReadMode.NEW):
            phase_calls.append(read_mode)
            if read_mode == ReadMode.PENDING:
                raise asyncio.CancelledError()
            return []

        mock_consumer = AsyncMock()
        mock_consumer.read = mock_read
        router._stream_consumer = mock_consumer
        router._running = True

        # Should not raise - CancelledError is caught and returns
        await router._consume_loop()

        # Only one call to Phase 1, no Phase 2
        assert phase_calls == [ReadMode.PENDING]
        # Router should still be running (return doesn't set _running=False)
        assert router._running is True

    @pytest.mark.asyncio
    async def test_phase1_processes_multiple_batches(self, redis):
        """Phase 1 loops until no more pending messages."""
        from unittest.mock import AsyncMock

        router = EventRouter(redis=redis, stream="test:events", group="test-group")

        phase1_batch_count = 0
        processed_messages = []

        def make_message(batch_num: int):
            return {
                "id": f"msg-{batch_num}",
                "data": {
                    "event_type": "test.event",
                    "data": "{}",
                    "id": f"evt-{batch_num}",
                    "timestamp": "2024-01-15T10:00:00+00:00",
                    "correlation_id": "",
                    "causation_id": "",
                    "metadata": "{}",
                },
            }

        async def mock_read(read_mode: ReadMode = ReadMode.NEW):
            nonlocal phase1_batch_count
            if read_mode == ReadMode.PENDING:
                phase1_batch_count += 1
                # Return 3 batches, then empty
                if phase1_batch_count <= 3:
                    return [make_message(phase1_batch_count)]
                return []  # No more pending
            # Phase 2: stop immediately
            router._running = False
            return []

        @router.on("test.*")
        async def handler(event):
            processed_messages.append(event.id)

        mock_consumer = AsyncMock()
        mock_consumer.read = mock_read
        mock_consumer.ack = AsyncMock()
        mock_consumer.autoclaim = AsyncMock(return_value=("0-0", []))
        router._stream_consumer = mock_consumer
        router._running = True

        await router._consume_loop()

        # Should have processed 3 messages in Phase 1
        assert len(processed_messages) == 3
        assert processed_messages == ["evt-1", "evt-2", "evt-3"]
        # Phase 1 was called 4 times (3 with messages, 1 empty)
        assert phase1_batch_count == 4

    @pytest.mark.asyncio
    async def test_phase1_error_backoff_and_retry(self, redis):
        """Phase 1 uses exponential backoff on errors."""
        from unittest.mock import AsyncMock, patch

        router = EventRouter(redis=redis, stream="test:events", group="test-group")

        call_count = 0
        sleep_delays = []

        async def mock_read(read_mode: ReadMode = ReadMode.NEW):
            nonlocal call_count
            if read_mode == ReadMode.PENDING:
                call_count += 1
                if call_count <= 2:
                    raise ConnectionError("Redis unavailable")
                # Third call succeeds with empty (Phase 1 complete)
                return []
            # Phase 2
            router._running = False
            return []

        async def mock_sleep(delay):
            sleep_delays.append(delay)

        mock_consumer = AsyncMock()
        mock_consumer.read = mock_read
        mock_consumer.autoclaim = AsyncMock(return_value=("0-0", []))
        router._stream_consumer = mock_consumer
        router._running = True

        with patch("rapids.router.core.asyncio.sleep", side_effect=mock_sleep):
            await router._consume_loop()

        # Should have retried twice with backoff
        assert len(sleep_delays) == 2
        assert sleep_delays[0] == 2.0  # min(1.0 * 2^1, 60) = 2.0
        assert sleep_delays[1] == 4.0  # min(1.0 * 2^2, 60) = 4.0

    @pytest.mark.asyncio
    async def test_stop_during_phase2_exits_cleanly(self, redis):
        """stop() called during Phase 2 exits the loop cleanly."""
        from unittest.mock import AsyncMock

        router = EventRouter(redis=redis, stream="test:events", group="test-group")

        phase2_read_count = 0

        async def mock_read(read_mode: ReadMode = ReadMode.NEW):
            nonlocal phase2_read_count
            if read_mode == ReadMode.PENDING:
                return []  # Skip Phase 1
            phase2_read_count += 1
            if phase2_read_count >= 3:
                router._running = False
            return []

        mock_consumer = AsyncMock()
        mock_consumer.read = mock_read
        mock_consumer.autoclaim = AsyncMock(return_value=("0-0", []))
        router._stream_consumer = mock_consumer
        router._running = True

        await router._consume_loop()

        # Phase 2 should have run 3 times before stopping
        assert phase2_read_count == 3
        assert router._running is False

    @pytest.mark.asyncio
    async def test_cancelled_error_in_phase2_breaks_loop(self, redis):
        """CancelledError during Phase 2 breaks out of the loop."""
        from unittest.mock import AsyncMock

        router = EventRouter(redis=redis, stream="test:events", group="test-group")

        phase_calls = []

        async def mock_read(read_mode: ReadMode = ReadMode.NEW):
            phase_calls.append(read_mode)
            if read_mode == ReadMode.PENDING:
                return []  # Skip Phase 1
            # Phase 2: raise CancelledError
            raise asyncio.CancelledError()

        mock_consumer = AsyncMock()
        mock_consumer.read = mock_read
        router._stream_consumer = mock_consumer
        router._running = True

        # Should not raise - CancelledError is caught and breaks
        await router._consume_loop()

        # Phase 1 was called once (empty), Phase 2 was called once (cancelled)
        assert phase_calls == [ReadMode.PENDING, ReadMode.NEW]
        # Router is still running (break doesn't set _running=False)
        assert router._running is True

    @pytest.mark.asyncio
    async def test_running_false_during_phase1_skips_phase2(self, redis):
        """If _running becomes False during Phase 1 processing, Phase 2 never starts."""
        from unittest.mock import AsyncMock

        router = EventRouter(redis=redis, stream="test:events", group="test-group")

        phase_calls = []

        async def mock_read(read_mode: ReadMode = ReadMode.NEW):
            phase_calls.append(read_mode)
            if read_mode == ReadMode.PENDING:
                # Return empty to exit Phase 1 loop via break
                return []
            return []

        mock_consumer = AsyncMock()
        mock_consumer.read = mock_read
        mock_consumer.autoclaim = AsyncMock(return_value=("0-0", []))
        router._stream_consumer = mock_consumer

        # Set _running=False BEFORE starting
        router._running = False

        await router._consume_loop()

        # Neither phase should have run because _running was False
        assert phase_calls == []

    @pytest.mark.asyncio
    async def test_consecutive_errors_reset_on_success(self, redis):
        """consecutive_errors resets to 0 after successful read in each phase."""
        from unittest.mock import AsyncMock, patch

        router = EventRouter(redis=redis, stream="test:events", group="test-group")

        phase1_calls = 0
        phase2_calls = 0
        sleep_delays = []

        async def mock_read(read_mode: ReadMode = ReadMode.NEW):
            nonlocal phase1_calls, phase2_calls
            if read_mode == ReadMode.PENDING:
                phase1_calls += 1
                if phase1_calls == 1:
                    raise ConnectionError("Phase 1 error")
                # Second call succeeds
                return []
            else:
                phase2_calls += 1
                if phase2_calls == 1:
                    raise ConnectionError("Phase 2 error")
                # Second call in Phase 2 - stop
                router._running = False
                return []

        async def mock_sleep(delay):
            sleep_delays.append(delay)

        mock_consumer = AsyncMock()
        mock_consumer.read = mock_read
        mock_consumer.autoclaim = AsyncMock(return_value=("0-0", []))
        router._stream_consumer = mock_consumer
        router._running = True

        with patch("rapids.router.core.asyncio.sleep", side_effect=mock_sleep):
            await router._consume_loop()

        # Should have 2 sleep calls - one for Phase 1 error, one for Phase 2 error
        assert len(sleep_delays) == 2
        # Both should be 2.0 (first error in each phase: 2^1 = 2)
        # This proves consecutive_errors reset between successful reads
        assert sleep_delays[0] == 2.0  # Phase 1: first error
        assert sleep_delays[1] == 2.0  # Phase 2: first error (counter was reset)


class TestEventRouterWithRealRedis:
    """Tests that require real Redis (blocking XREADGROUP behavior)."""

    @pytest.mark.integration
    @pytest.mark.asyncio
    async def test_stop_cancels_consume_task(self, real_redis):
        """Test that stop() cancels the consume task for prompt shutdown."""
        # Clean up any existing stream/group
        with contextlib.suppress(ResponseError):
            await real_redis.delete("test:events")

        router = EventRouter(
            redis=real_redis,
            stream="test:events",
            group="test-group",
            block_ms=5000,  # Long timeout - would delay shutdown without cancellation
        )

        # Start router in background
        start_task = asyncio.create_task(router.start())

        # Give it time to start the consume loop
        await asyncio.sleep(0.1)

        # Verify the consume task is running
        assert router._running is True
        assert router._consume_task is not None

        # Stop should cancel immediately, not wait for block_ms
        stop_start = asyncio.get_event_loop().time()
        await router.stop()
        stop_duration = asyncio.get_event_loop().time() - stop_start

        # Should complete much faster than block_ms (5 seconds)
        assert stop_duration < 1.0

        # Consume task should be cleaned up
        assert router._consume_task is None
        assert router._running is False

        # Wait for start_task to complete
        await start_task

    @pytest.mark.integration
    @pytest.mark.asyncio
    async def test_start_handles_external_cancellation(self, real_redis):
        """Test that start() handles external task cancellation gracefully."""
        # Clean up any existing stream/group
        with contextlib.suppress(ResponseError):
            await real_redis.delete("test:events")

        router = EventRouter(
            redis=real_redis,
            stream="test:events",
            group="test-group",
            block_ms=100,
        )

        # Start router in background
        start_task = asyncio.create_task(router.start())

        # Give it time to start
        await asyncio.sleep(0.1)

        # Cancel from outside (simulating shutdown signal)
        start_task.cancel()

        # Should complete gracefully without raising (CancelledError is caught internally)
        await start_task

        # Router should be in clean state
        assert router._consume_task is None

    @pytest.mark.integration
    @pytest.mark.asyncio
    async def test_consume_loop_processes_messages(self, real_redis):
        """Test that the consume loop actually processes messages."""
        # Clean up any existing stream/group
        stream = "test:consume:events"
        with contextlib.suppress(ResponseError):
            await real_redis.delete(stream)

        results = []

        router = EventRouter(
            redis=real_redis,
            stream=stream,
            group="test-group",
            block_ms=100,
        )

        @router.on(RouterDocumentCreated)
        async def handler(event: RouterDocumentCreated) -> None:
            results.append(event.doc_id)

        # Add a message to the stream before starting
        await real_redis.xadd(
            stream,
            {
                "event_type": "router_document.created",
                "data": '{"doc_id": "123", "title": "Test"}',
                "id": "evt-1",
                "timestamp": "2024-01-15T10:00:00+00:00",
                "correlation_id": "",
                "causation_id": "",
                "metadata": "{}",
            },
        )

        # Start router in background
        start_task = asyncio.create_task(router.start())

        # Wait for message to be processed
        for _ in range(20):
            if results:
                break
            await asyncio.sleep(0.1)

        await router.stop()
        await start_task

        assert results == ["123"]


class TestBaseClassMatching:
    """Tests for base class subscription."""

    def test_handler_matches_subclass_events(self, redis):
        """Handler for base class receives subclass events."""
        from typing import ClassVar

        class TestDocumentEvent(BaseEvent):
            _skip_registration: ClassVar[bool] = True
            doc_id: str

        class TestDocCreated(TestDocumentEvent):
            title: str

        class TestDocDeleted(TestDocumentEvent):
            deleted_by: str

        router = EventRouter(redis=redis, group="test")

        @router.on(TestDocumentEvent)
        async def handler(event: TestDocumentEvent) -> None:
            pass

        # Both subclass events should match
        created = TestDocCreated(doc_id="1", title="Test")
        deleted = TestDocDeleted(doc_id="2", deleted_by="user")

        assert len(router._match_handlers(created)) == 1
        assert len(router._match_handlers(deleted)) == 1

    def test_isinstance_fallback_for_new_subclasses(self, redis):
        """Handler matches new subclasses via isinstance even if registered after."""
        from typing import ClassVar

        class TestEntityEvent(BaseEvent):
            _skip_registration: ClassVar[bool] = True
            entity_id: str

        router = EventRouter(redis=redis, group="test")

        @router.on(TestEntityEvent)
        async def handler(event: TestEntityEvent) -> None:
            pass

        # Define subclass AFTER registering handler
        class TestEntityCreated(TestEntityEvent):
            name: str

        event = TestEntityCreated(entity_id="1", name="Test")

        # Should still match via isinstance check
        matching = router._match_handlers(event)
        assert len(matching) == 1


class TestUnionTypeMatching:
    """Tests for union type subscription."""

    def test_union_matches_either_type(self, redis):
        """Handler with union matches either event type."""
        router = EventRouter(redis=redis, group="test")

        @router.on(RouterDocumentCreated | RouterDocumentDeleted)
        async def handler(event: Event) -> None:
            pass

        created = RouterDocumentCreated(doc_id="1", title="Test")
        deleted = RouterDocumentDeleted(doc_id="2", deleted_by="user")

        assert len(router._match_handlers(created)) == 1
        assert len(router._match_handlers(deleted)) == 1

    def test_union_does_not_match_other_types(self, redis):
        """Handler with union doesn't match unrelated events."""

        class TestOtherEvent(BaseEvent):
            value: str

        router = EventRouter(redis=redis, group="test")

        @router.on(RouterDocumentCreated | RouterDocumentDeleted)
        async def handler(event: Event) -> None:
            pass

        other = TestOtherEvent(value="test")
        assert len(router._match_handlers(other)) == 0


class TestPatternMatching:
    """Tests for pattern-based subscription."""

    def test_single_segment_pattern(self, redis):
        """Single segment pattern matches correct events."""
        router = EventRouter(redis=redis, group="test")

        @router.on("router_document.*")
        async def handler(event: Event) -> None:
            pass

        created = RouterDocumentCreated(doc_id="1", title="Test")
        deleted = RouterDocumentDeleted(doc_id="2", deleted_by="user")

        assert len(router._match_handlers(created)) == 1
        assert len(router._match_handlers(deleted)) == 1

    def test_catch_all_pattern(self, redis):
        """Catch-all pattern matches all events."""
        router = EventRouter(redis=redis, group="test")

        @router.on("*")
        async def handler(event: Event) -> None:
            pass

        created = RouterDocumentCreated(doc_id="1", title="Test")
        generic = GenericEvent(raw_type="unknown.event", data={})

        assert len(router._match_handlers(created)) == 1
        assert len(router._match_handlers(generic)) == 1

    def test_pattern_matches_generic_event(self, redis):
        """Pattern matching works for GenericEvent via raw_type."""
        router = EventRouter(redis=redis, group="test")

        @router.on("legacy.*")
        async def handler(event: Event) -> None:
            pass

        # GenericEvent should match via raw_type
        event = GenericEvent(raw_type="legacy.event", data={})
        assert len(router._match_handlers(event)) == 1

        # Different pattern shouldn't match
        other = GenericEvent(raw_type="modern.event", data={})
        assert len(router._match_handlers(other)) == 0

    def test_pattern_no_match_different_prefix(self, redis):
        """Pattern doesn't match events with different prefix."""
        router = EventRouter(redis=redis, group="test")

        @router.on("document.*")
        async def handler(event: Event) -> None:
            pass

        # router_document.* doesn't match document.*
        event = RouterDocumentCreated(doc_id="1", title="Test")
        assert len(router._match_handlers(event)) == 0


class TestHandlerReliabilityConfig:
    """Tests for handler timeout/retry configuration via on() parameters."""

    def test_on_with_custom_timeout(self, redis):
        """Test that @router.on() accepts custom timeout parameter."""
        router = EventRouter(redis=redis, group="test", handler_timeout=30.0)

        @router.on(RouterDocumentCreated, timeout=60.0)
        async def handler(event: RouterDocumentCreated) -> None:
            pass

        assert len(router._handlers) == 1
        assert router._handlers[0].timeout == 60.0

    def test_on_with_custom_retries(self, redis):
        """Test that @router.on() accepts custom retries parameter."""
        router = EventRouter(redis=redis, group="test")

        @router.on(RouterDocumentCreated, retries=5)
        async def handler(event: RouterDocumentCreated) -> None:
            pass

        assert len(router._handlers) == 1
        assert router._handlers[0].retries == 5

    def test_on_with_custom_backoff(self, redis):
        """Test that @router.on() accepts custom backoff parameter."""
        from rapids.backoff import exponential

        router = EventRouter(redis=redis, group="test")
        backoff = exponential(base=3.0)

        @router.on(RouterDocumentCreated, backoff=backoff)
        async def handler(event: RouterDocumentCreated) -> None:
            pass

        assert len(router._handlers) == 1
        assert router._handlers[0].backoff is backoff

    def test_on_with_custom_retryable_exceptions(self, redis):
        """Test that @router.on() accepts custom retryable_exceptions parameter."""
        router = EventRouter(redis=redis, group="test")

        @router.on(RouterDocumentCreated, retryable_exceptions=(ValueError, TypeError))
        async def handler(event: RouterDocumentCreated) -> None:
            pass

        assert len(router._handlers) == 1
        assert router._handlers[0].retryable_exceptions == (ValueError, TypeError)

    def test_on_with_all_reliability_params(self, redis):
        """Test that @router.on() accepts all reliability parameters together."""
        from rapids.backoff import linear

        router = EventRouter(redis=redis, group="test")
        backoff = linear(delay=2.0)

        @router.on(
            RouterDocumentCreated,
            timeout=120.0,
            retries=10,
            backoff=backoff,
            retryable_exceptions=(IOError,),
        )
        async def handler(event: RouterDocumentCreated) -> None:
            pass

        reg = router._handlers[0]
        assert reg.timeout == 120.0
        assert reg.retries == 10
        assert reg.backoff is backoff
        assert reg.retryable_exceptions == (IOError,)

    def test_on_defaults_to_none(self, redis):
        """Test that @router.on() without params defaults to None."""
        router = EventRouter(redis=redis, group="test")

        @router.on(RouterDocumentCreated)
        async def handler(event: RouterDocumentCreated) -> None:
            pass

        reg = router._handlers[0]
        assert reg.timeout is None
        assert reg.retries is None
        assert reg.backoff is None
        # retryable_exceptions has a default
        assert reg.retryable_exceptions == (Exception,)

    @pytest.mark.asyncio
    async def test_dispatch_uses_handler_timeout(self, redis):
        """Test that _dispatch() uses handler-specific timeout."""
        from rapids.exceptions import MaxRetriesExceededError

        router = EventRouter(redis=redis, group="test", handler_timeout=10.0)

        @router.on(RouterDocumentCreated, timeout=0.1)
        async def slow_handler(event: RouterDocumentCreated) -> None:
            await asyncio.sleep(10)  # Much longer than handler timeout

        event = RouterDocumentCreated(doc_id="123", title="Test")
        matching = router._match_handlers(event)

        # Should timeout after handler's 0.1s, not router's 10s
        with pytest.raises(MaxRetriesExceededError) as exc_info:
            await router._dispatch(event, matching)
        assert isinstance(exc_info.value.last_error, TimeoutError)

    @pytest.mark.asyncio
    async def test_dispatch_falls_back_to_router_timeout(self, redis):
        """Test that _dispatch() falls back to router timeout when handler has None."""
        from rapids.exceptions import MaxRetriesExceededError

        router = EventRouter(redis=redis, group="test", handler_timeout=0.1)

        @router.on(RouterDocumentCreated)  # No timeout specified
        async def slow_handler(event: RouterDocumentCreated) -> None:
            await asyncio.sleep(10)

        event = RouterDocumentCreated(doc_id="123", title="Test")
        matching = router._match_handlers(event)

        # Should timeout after router's 0.1s
        with pytest.raises(MaxRetriesExceededError) as exc_info:
            await router._dispatch(event, matching)
        assert isinstance(exc_info.value.last_error, TimeoutError)

    def test_on_with_pattern_and_reliability(self, redis):
        """Test that pattern-based handlers also accept reliability params."""
        router = EventRouter(redis=redis, group="test")

        @router.on("document.*", timeout=45.0, retries=3)
        async def handler(event) -> None:
            pass

        reg = router._handlers[0]
        assert reg.patterns == {"document.*"}
        assert reg.timeout == 45.0
        assert reg.retries == 3

    def test_on_with_union_and_reliability(self, redis):
        """Test that union type handlers also accept reliability params."""
        router = EventRouter(redis=redis, group="test")

        @router.on(RouterDocumentCreated | RouterDocumentDeleted, timeout=30.0)
        async def handler(event) -> None:
            pass

        reg = router._handlers[0]
        assert "router_document.created" in reg.event_types
        assert "router_document.deleted" in reg.event_types
        assert reg.timeout == 30.0


class TestMultipleMatchingStrategies:
    """Tests for combining different matching strategies."""

    def test_event_matches_multiple_handlers(self, redis):
        """Single event can match multiple handlers with different strategies."""
        router = EventRouter(redis=redis, group="test")

        results = []

        @router.on(RouterDocumentCreated)
        async def exact_handler(event: RouterDocumentCreated) -> None:
            results.append("exact")

        @router.on("router_document.*")
        async def pattern_handler(event: Event) -> None:
            results.append("pattern")

        @router.on("*")
        async def catch_all(event: Event) -> None:
            results.append("catch_all")

        event = RouterDocumentCreated(doc_id="1", title="Test")
        matching = router._match_handlers(event)

        assert len(matching) == 3

    def test_generic_event_only_matches_patterns(self, redis):
        """GenericEvent only matches via exact type or patterns, not isinstance."""
        from typing import ClassVar

        class TestBaseEvent(BaseEvent):
            _skip_registration: ClassVar[bool] = True
            entity_id: str

        router = EventRouter(redis=redis, group="test")

        @router.on(TestBaseEvent)
        async def base_handler(event: TestBaseEvent) -> None:
            pass

        @router.on("test.*")
        async def pattern_handler(event: Event) -> None:
            pass

        # GenericEvent won't match base class handler (not isinstance)
        generic = GenericEvent(raw_type="test.something", data={})
        matching = router._match_handlers(generic)

        # Should only match pattern, not base class
        assert len(matching) == 1
        assert matching[0].fn.__name__ == "pattern_handler"


class TestQuickRetryLoop:
    """Tests for quick in-process retry with backoff."""

    @pytest.mark.asyncio
    async def test_execute_handler_success_no_retry(self, redis):
        """Test successful handler execution without retries."""
        router = EventRouter(redis=redis, group="test", default_retries=3)

        results = []

        @router.on(RouterDocumentCreated)
        async def handler(event: RouterDocumentCreated) -> None:
            results.append(event.doc_id)

        event = RouterDocumentCreated(doc_id="123", title="Test")
        await router._execute_handler(router._handlers[0], event)

        assert results == ["123"]

    @pytest.mark.asyncio
    async def test_execute_handler_retries_on_failure(self, redis):
        """Test that handler retries on failure with backoff."""
        from rapids.backoff import constant

        router = EventRouter(
            redis=redis, group="test", default_retries=3, default_backoff=constant(0.01)
        )

        attempts = []

        @router.on(RouterDocumentCreated)
        async def handler(event: RouterDocumentCreated) -> None:
            attempts.append(len(attempts) + 1)
            if len(attempts) < 3:
                raise ValueError("Transient error")

        event = RouterDocumentCreated(doc_id="123", title="Test")
        await router._execute_handler(router._handlers[0], event)

        # Should have attempted 3 times (2 failures, 1 success)
        assert attempts == [1, 2, 3]

    @pytest.mark.asyncio
    async def test_execute_handler_max_retries_exceeded(self, redis):
        """Test MaxRetriesExceededError when quick retries exhausted."""
        from rapids.backoff import constant
        from rapids.exceptions import MaxRetriesExceededError

        router = EventRouter(
            redis=redis, group="test", default_retries=2, default_backoff=constant(0.01)
        )

        attempts = []

        @router.on(RouterDocumentCreated)
        async def handler(event: RouterDocumentCreated) -> None:
            attempts.append(len(attempts) + 1)
            raise ValueError("Permanent error")

        event = RouterDocumentCreated(doc_id="123", title="Test")

        with pytest.raises(MaxRetriesExceededError) as exc_info:
            await router._execute_handler(router._handlers[0], event)

        assert exc_info.value.max_attempts == 3  # initial + 2 retries
        assert exc_info.value.event_id == event.id
        assert attempts == [1, 2, 3]

    @pytest.mark.asyncio
    async def test_execute_handler_non_retryable_exception(self, redis):
        """Test that non-retryable exceptions immediately raise NonRetryableError."""
        from rapids.backoff import constant
        from rapids.exceptions import NonRetryableError

        router = EventRouter(
            redis=redis, group="test", default_retries=3, default_backoff=constant(0.01)
        )

        attempts = []

        @router.on(RouterDocumentCreated, retryable_exceptions=(ConnectionError,))
        async def handler(event: RouterDocumentCreated) -> None:
            attempts.append(len(attempts) + 1)
            raise ValueError("Not retryable")

        event = RouterDocumentCreated(doc_id="123", title="Test")

        with pytest.raises(NonRetryableError) as exc_info:
            await router._execute_handler(router._handlers[0], event)

        assert exc_info.value.handler_name == "handler"
        assert isinstance(exc_info.value.cause, ValueError)
        # Should only attempt once (no retry for non-retryable)
        assert attempts == [1]

    @pytest.mark.asyncio
    async def test_execute_handler_uses_handler_level_config(self, redis):
        """Test that handler-level config overrides router defaults."""
        from rapids.backoff import constant

        router = EventRouter(
            redis=redis,
            group="test",
            default_retries=5,  # Router default
            default_backoff=constant(1.0),
        )

        attempts = []

        @router.on(RouterDocumentCreated, retries=1, backoff=constant(0.01))
        async def handler(event: RouterDocumentCreated) -> None:
            attempts.append(len(attempts) + 1)
            raise ValueError("Error")

        event = RouterDocumentCreated(doc_id="123", title="Test")

        from rapids.exceptions import MaxRetriesExceededError

        with pytest.raises(MaxRetriesExceededError):
            await router._execute_handler(router._handlers[0], event)

        # Should use handler's retries=1 (initial + 1 retry = 2 attempts)
        assert attempts == [1, 2]

    @pytest.mark.asyncio
    async def test_execute_handler_no_retries_configured(self, redis):
        """Test that with retries=0, MaxRetriesExceededError is raised after 1 attempt."""
        from rapids.exceptions import MaxRetriesExceededError

        router = EventRouter(redis=redis, group="test", default_retries=0)

        attempts = []

        @router.on(RouterDocumentCreated)
        async def handler(event: RouterDocumentCreated) -> None:
            attempts.append(len(attempts) + 1)
            raise ValueError("Error")

        event = RouterDocumentCreated(doc_id="123", title="Test")

        # With no retries, should raise MaxRetriesExceededError wrapping original
        with pytest.raises(MaxRetriesExceededError) as exc_info:
            await router._execute_handler(router._handlers[0], event)

        assert exc_info.value.max_attempts == 1
        assert isinstance(exc_info.value.last_error, ValueError)
        assert attempts == [1]

    @pytest.mark.asyncio
    async def test_execute_handler_timeout_per_attempt(self, redis):
        """Test that timeout applies per attempt, not total."""
        from rapids.backoff import constant

        router = EventRouter(
            redis=redis,
            group="test",
            handler_timeout=0.1,
            default_retries=2,
            default_backoff=constant(0.01),
        )

        attempts = []

        @router.on(RouterDocumentCreated)
        async def slow_handler(event: RouterDocumentCreated) -> None:
            attempts.append(len(attempts) + 1)
            if len(attempts) < 3:
                await asyncio.sleep(10)  # Timeout on first two attempts
            # Third attempt succeeds quickly

        event = RouterDocumentCreated(doc_id="123", title="Test")
        await router._execute_handler(router._handlers[0], event)

        # All 3 attempts should have been made (2 timeouts, 1 success)
        assert attempts == [1, 2, 3]

    @pytest.mark.asyncio
    async def test_handler_cancelled_error_propagates(self, redis):
        """Test that CancelledError propagates immediately for graceful shutdown.

        CancelledError is special in asyncio - it signals task cancellation
        and should not be caught and wrapped in MaxRetriesExceededError.
        """
        router = EventRouter(redis=redis, group="test", default_retries=3)

        @router.on(RouterDocumentCreated)
        async def handler(event: RouterDocumentCreated) -> None:
            raise asyncio.CancelledError()

        event = RouterDocumentCreated(doc_id="123", title="Test")

        # CancelledError should propagate, not be wrapped
        with pytest.raises(asyncio.CancelledError):
            await router._execute_handler(router._handlers[0], event)


class TestDLQIntegration:
    """Tests for Dead Letter Queue functionality."""

    @pytest.mark.asyncio
    async def test_send_to_dlq_writes_message(self, redis):
        """Test that _send_to_dlq writes message to DLQ stream and returns True."""
        router = EventRouter(
            redis=redis, stream="test:events", group="test", dlq_stream="test:dlq"
        )

        raw_data = {
            "event_type": "test.event",
            "data": '{"foo": "bar"}',
            "id": "evt-123",
            "timestamp": "2024-01-15T10:00:00+00:00",
            "correlation_id": "corr-1",
            "causation_id": "cause-1",
            "metadata": "{}",
        }

        result = await router._send_to_dlq(
            msg_id="12345-0",
            raw_data=raw_data,
            reason="test_reason",
            error="Test error message",
            handler_name="test_handler",
        )

        assert result is True

        # Read from DLQ
        messages = await redis.xrange("test:dlq")
        assert len(messages) == 1

        _, data = messages[0]
        assert data[b"original_msg_id"] == b"12345-0"
        assert data[b"original_stream"] == b"test:events"
        assert data[b"reason"] == b"test_reason"
        assert data[b"error"] == b"Test error message"
        assert data[b"handler"] == b"test_handler"
        assert data[b"event_type"] == b"test.event"
        assert b"failed_at" in data

    @pytest.mark.asyncio
    async def test_send_to_dlq_disabled(self, redis, caplog):
        """Test that _send_to_dlq returns True when DLQ is disabled."""
        import logging

        router = EventRouter(
            redis=redis, stream="test:events", group="test", dlq_stream=None
        )

        with caplog.at_level(logging.WARNING):
            result = await router._send_to_dlq(
                msg_id="12345-0",
                raw_data={},
                reason="test_reason",
            )

        assert result is True  # DLQ disabled is considered success
        assert "DLQ disabled" in caplog.text

    @pytest.mark.asyncio
    async def test_send_to_dlq_failure_returns_false(self, redis, caplog):
        """Test that _send_to_dlq returns False when Redis write fails."""
        import logging
        from unittest.mock import AsyncMock, patch

        router = EventRouter(
            redis=redis, stream="test:events", group="test", dlq_stream="test:dlq"
        )

        # Mock xadd to raise an exception
        with patch.object(redis, "xadd", new_callable=AsyncMock) as mock_xadd:
            mock_xadd.side_effect = ConnectionError("Redis unavailable")

            with caplog.at_level(logging.ERROR):
                result = await router._send_to_dlq(
                    msg_id="12345-0",
                    raw_data={},
                    reason="test_reason",
                )

        assert result is False
        assert "Failed to send message" in caplog.text
        assert "leaving pending for retry" in caplog.text

    @pytest.mark.asyncio
    async def test_send_to_dlq_applies_maxlen(self, redis):
        """Test that DLQ stream is trimmed by maxlen."""
        router = EventRouter(
            redis=redis,
            stream="test:events",
            group="test",
            dlq_stream="test:dlq",
            dlq_maxlen=3,  # Small maxlen for testing
        )

        # Send more messages than maxlen
        for i in range(5):
            await router._send_to_dlq(
                msg_id=f"msg-{i}",
                raw_data={"event_type": f"test.event.{i}"},
                reason="test_reason",
            )

        # Stream should be trimmed to approximately maxlen
        # (approximate trim may leave slightly more than maxlen)
        length = await redis.xlen("test:dlq")
        assert length <= 5  # At most 5 (what we added)
        assert length >= 3  # At least maxlen (approximate allows some over)

    @pytest.mark.asyncio
    async def test_process_message_max_deliveries_to_dlq(self, redis):
        """Test that messages exceeding max_deliveries go to DLQ."""
        router = EventRouter(
            redis=redis,
            stream="test:events",
            group="test",
            max_deliveries=3,
            dlq_stream="test:dlq",
        )

        # Set up stream consumer
        router._stream_consumer = StreamConsumer(
            redis=redis,
            stream="test:events",
            group="test",
            consumer="test-consumer",
        )
        await router._stream_consumer.ensure_group()

        # Add message
        await redis.xadd(
            "test:events",
            {
                "event_type": "test.event",
                "data": "{}",
                "id": "evt-1",
                "timestamp": "2024-01-15T10:00:00+00:00",
                "correlation_id": "",
                "causation_id": "",
                "metadata": "{}",
            },
        )

        messages = await router._stream_consumer.read()
        assert len(messages) == 1

        # Simulate delivery_count > max_deliveries
        messages[0]["delivery_count"] = 4

        await router._process_message(messages[0])

        # Message should be in DLQ
        dlq_messages = await redis.xrange("test:dlq")
        assert len(dlq_messages) == 1

        _, data = dlq_messages[0]
        assert data[b"reason"] == b"max_deliveries_exceeded"

        # Original message should be acked
        pending = await redis.xpending("test:events", "test")
        assert pending["pending"] == 0

    @pytest.mark.asyncio
    async def test_process_message_deserialization_error_to_dlq(self, redis):
        """Test that deserialization errors send message to DLQ."""
        router = EventRouter(
            redis=redis,
            stream="test:events",
            group="test",
            dlq_stream="test:dlq",
        )

        router._stream_consumer = StreamConsumer(
            redis=redis,
            stream="test:events",
            group="test",
            consumer="test-consumer",
        )
        await router._stream_consumer.ensure_group()

        # Add message with invalid JSON
        await redis.xadd(
            "test:events",
            {
                "event_type": "router_document.created",
                "data": "{invalid json",
                "id": "evt-1",
                "timestamp": "2024-01-15T10:00:00+00:00",
                "correlation_id": "",
                "causation_id": "",
                "metadata": "{}",
            },
        )

        messages = await router._stream_consumer.read()
        await router._process_message(messages[0])

        # Message should be in DLQ
        dlq_messages = await redis.xrange("test:dlq")
        assert len(dlq_messages) == 1

        _, data = dlq_messages[0]
        assert data[b"reason"] == b"deserialization_error"

    @pytest.mark.asyncio
    async def test_process_message_non_retryable_to_dlq(self, redis):
        """Test that non-retryable errors send message to DLQ."""
        router = EventRouter(
            redis=redis,
            stream="test:events",
            group="test",
            dlq_stream="test:dlq",
            default_retries=3,
        )

        @router.on(RouterDocumentCreated, retryable_exceptions=(ConnectionError,))
        async def handler(event: RouterDocumentCreated) -> None:
            raise ValueError("Non-retryable error")

        router._stream_consumer = StreamConsumer(
            redis=redis,
            stream="test:events",
            group="test",
            consumer="test-consumer",
        )
        await router._stream_consumer.ensure_group()

        await redis.xadd(
            "test:events",
            {
                "event_type": "router_document.created",
                "data": '{"doc_id": "123", "title": "Test"}',
                "id": "evt-1",
                "timestamp": "2024-01-15T10:00:00+00:00",
                "correlation_id": "",
                "causation_id": "",
                "metadata": "{}",
            },
        )

        messages = await router._stream_consumer.read()
        await router._process_message(messages[0])

        # Message should be in DLQ
        dlq_messages = await redis.xrange("test:dlq")
        assert len(dlq_messages) == 1

        _, data = dlq_messages[0]
        assert data[b"reason"] == b"non_retryable"
        assert data[b"handler"] == b"handler"

        # Original message should be acked
        pending = await redis.xpending("test:events", "test")
        assert pending["pending"] == 0

    @pytest.mark.asyncio
    async def test_process_message_retryable_leaves_pending(self, redis):
        """Test that retryable errors leave message pending for Redis retry."""
        from rapids.backoff import constant

        router = EventRouter(
            redis=redis,
            stream="test:events",
            group="test",
            dlq_stream="test:dlq",
            default_retries=1,
            default_backoff=constant(0.01),
        )

        @router.on(RouterDocumentCreated)
        async def handler(event: RouterDocumentCreated) -> None:
            raise ValueError("Retryable error")

        router._stream_consumer = StreamConsumer(
            redis=redis,
            stream="test:events",
            group="test",
            consumer="test-consumer",
        )
        await router._stream_consumer.ensure_group()

        await redis.xadd(
            "test:events",
            {
                "event_type": "router_document.created",
                "data": '{"doc_id": "123", "title": "Test"}',
                "id": "evt-1",
                "timestamp": "2024-01-15T10:00:00+00:00",
                "correlation_id": "",
                "causation_id": "",
                "metadata": "{}",
            },
        )

        messages = await router._stream_consumer.read()
        await router._process_message(messages[0])

        # Message should NOT be in DLQ (yet)
        dlq_messages = await redis.xrange("test:dlq")
        assert len(dlq_messages) == 0

        # Message should still be pending for Redis retry
        pending = await redis.xpending("test:events", "test")
        assert pending["pending"] == 1

    @pytest.mark.asyncio
    async def test_process_message_dlq_failure_leaves_pending(self, redis):
        """Test that messages are NOT acked when DLQ write fails."""
        from unittest.mock import AsyncMock, patch

        router = EventRouter(
            redis=redis,
            stream="test:events",
            group="test",
            max_deliveries=3,
            dlq_stream="test:dlq",
        )

        router._stream_consumer = StreamConsumer(
            redis=redis,
            stream="test:events",
            group="test",
            consumer="test-consumer",
        )
        await router._stream_consumer.ensure_group()

        # Add message
        await redis.xadd(
            "test:events",
            {
                "event_type": "test.event",
                "data": "{}",
                "id": "evt-1",
                "timestamp": "2024-01-15T10:00:00+00:00",
                "correlation_id": "",
                "causation_id": "",
                "metadata": "{}",
            },
        )

        messages = await router._stream_consumer.read()
        assert len(messages) == 1

        # Simulate delivery_count > max_deliveries (should go to DLQ)
        messages[0]["delivery_count"] = 4

        # Mock _send_to_dlq to fail
        with patch.object(router, "_send_to_dlq", new_callable=AsyncMock) as mock_dlq:
            mock_dlq.return_value = False  # DLQ write failed

            await router._process_message(messages[0])

        # Message should NOT be acked - still pending for retry
        pending = await redis.xpending("test:events", "test")
        assert pending["pending"] == 1

    @pytest.mark.asyncio
    async def test_process_message_non_retryable_dlq_failure_leaves_pending(
        self, redis
    ):
        """Test that non-retryable errors leave message pending if DLQ write fails."""
        from unittest.mock import AsyncMock, patch

        router = EventRouter(
            redis=redis,
            stream="test:events",
            group="test",
            dlq_stream="test:dlq",
            default_retries=3,
        )

        @router.on(RouterDocumentCreated, retryable_exceptions=(ConnectionError,))
        async def handler(event: RouterDocumentCreated) -> None:
            raise ValueError("Non-retryable error")

        router._stream_consumer = StreamConsumer(
            redis=redis,
            stream="test:events",
            group="test",
            consumer="test-consumer",
        )
        await router._stream_consumer.ensure_group()

        await redis.xadd(
            "test:events",
            {
                "event_type": "router_document.created",
                "data": '{"doc_id": "123", "title": "Test"}',
                "id": "evt-1",
                "timestamp": "2024-01-15T10:00:00+00:00",
                "correlation_id": "",
                "causation_id": "",
                "metadata": "{}",
            },
        )

        messages = await router._stream_consumer.read()

        # Mock _send_to_dlq to fail
        with patch.object(router, "_send_to_dlq", new_callable=AsyncMock) as mock_dlq:
            mock_dlq.return_value = False  # DLQ write failed

            await router._process_message(messages[0])

        # Message should NOT be acked - still pending for retry
        pending = await redis.xpending("test:events", "test")
        assert pending["pending"] == 1

    @pytest.mark.asyncio
    async def test_process_message_at_max_deliveries_not_dlq(self, redis):
        """delivery_count == max_deliveries should NOT trigger DLQ (only > does)."""
        router = EventRouter(
            redis=redis,
            group="test",
            max_deliveries=5,
            dlq_stream="test:dlq",
        )

        handler_called = []

        @router.on(RouterDocumentCreated)
        async def handler(event: RouterDocumentCreated) -> None:
            handler_called.append(True)

        router._stream_consumer = StreamConsumer(
            redis=redis,
            stream="test:events",
            group="test",
            consumer="test-consumer",
        )
        await router._stream_consumer.ensure_group()

        await redis.xadd(
            "test:events",
            {
                "event_type": "router_document.created",
                "data": '{"doc_id": "123", "title": "Test"}',
                "id": "evt-1",
                "timestamp": "2024-01-15T10:00:00+00:00",
                "correlation_id": "",
                "causation_id": "",
                "metadata": "{}",
            },
        )

        messages = await router._stream_consumer.read()
        msg = messages[0]

        # Set delivery_count == max_deliveries (boundary case, should NOT go to DLQ)
        msg["delivery_count"] = 5  # max_deliveries is 5, so 5 == 5, not > 5

        await router._process_message(msg)

        # Handler should have been called (not skipped to DLQ)
        assert handler_called == [True]

        # DLQ should be empty
        dlq_len = await redis.xlen("test:dlq")
        assert dlq_len == 0

    @pytest.mark.asyncio
    async def test_dlq_write_succeeds_ack_fails_race(self, redis):
        """If DLQ write succeeds but ack fails, message stays pending (potential DLQ dup)."""
        router = EventRouter(
            redis=redis,
            group="test",
            max_deliveries=3,
            dlq_stream="test:dlq",
        )

        router._stream_consumer = StreamConsumer(
            redis=redis,
            stream="test:events",
            group="test",
            consumer="test-consumer",
        )
        await router._stream_consumer.ensure_group()

        await redis.xadd(
            "test:events",
            {
                "event_type": "router_document.created",
                "data": '{"doc_id": "123", "title": "Test"}',
                "id": "evt-1",
                "timestamp": "2024-01-15T10:00:00+00:00",
                "correlation_id": "",
                "causation_id": "",
                "metadata": "{}",
            },
        )

        messages = await router._stream_consumer.read()
        msg = messages[0]
        msg["delivery_count"] = 4  # Exceeds max_deliveries=3

        # Mock ack to fail after DLQ write succeeds
        original_ack = router._stream_consumer.ack

        async def failing_ack(msg_id):
            raise ConnectionError("ACK failed")

        router._stream_consumer.ack = failing_ack

        # Process should not raise (exception is caught internally)
        await router._process_message(msg)

        # Restore ack
        router._stream_consumer.ack = original_ack

        # DLQ should have the message (write succeeded)
        dlq_len = await redis.xlen("test:dlq")
        assert dlq_len == 1

        # Message is still pending (ack failed) - potential duplicate on retry
        pending = await redis.xpending("test:events", "test")
        assert pending["pending"] == 1

    @pytest.mark.asyncio
    async def test_max_deliveries_exceeded_dlq_failure(self, redis):
        """If max_deliveries exceeded and DLQ write fails, message stays pending."""
        from unittest.mock import AsyncMock, patch

        router = EventRouter(
            redis=redis,
            group="test",
            max_deliveries=3,
            dlq_stream="test:dlq",
        )

        router._stream_consumer = StreamConsumer(
            redis=redis,
            stream="test:events",
            group="test",
            consumer="test-consumer",
        )
        await router._stream_consumer.ensure_group()

        await redis.xadd(
            "test:events",
            {
                "event_type": "router_document.created",
                "data": '{"doc_id": "123", "title": "Test"}',
                "id": "evt-1",
                "timestamp": "2024-01-15T10:00:00+00:00",
                "correlation_id": "",
                "causation_id": "",
                "metadata": "{}",
            },
        )

        messages = await router._stream_consumer.read()
        msg = messages[0]
        msg["delivery_count"] = 4  # Exceeds max_deliveries=3

        # Mock _send_to_dlq to fail
        with patch.object(router, "_send_to_dlq", new_callable=AsyncMock) as mock_dlq:
            mock_dlq.return_value = False  # DLQ write failed

            await router._process_message(msg)

        # DLQ should be empty (write failed)
        dlq_len = await redis.xlen("test:dlq")
        assert dlq_len == 0

        # Message should NOT be acked - still pending for retry
        pending = await redis.xpending("test:events", "test")
        assert pending["pending"] == 1


class TestDeliveryCount:
    """Tests for delivery count tracking."""

    @pytest.mark.asyncio
    async def test_read_new_messages_delivery_count_1(self, redis):
        """Test that new messages have delivery_count=1."""
        await redis.xadd("test:events", {"event_type": "test", "data": "{}"})

        consumer = StreamConsumer(
            redis=redis,
            stream="test:events",
            group="test-group",
            consumer="consumer-1",
            block_ms=100,
        )
        await consumer.ensure_group()

        messages = await consumer.read(read_mode=ReadMode.NEW)

        assert len(messages) == 1
        assert messages[0]["delivery_count"] == 1

    @pytest.mark.asyncio
    async def test_autoclaim_returns_delivery_count(self, redis):
        """Test that autoclaim includes delivery count for claimed messages."""
        # Add a message and read with consumer-1 (don't ack)
        await redis.xadd("test:events", {"event_type": "test", "data": "{}"})

        consumer1 = StreamConsumer(
            redis=redis,
            stream="test:events",
            group="test-group",
            consumer="consumer-1",
            block_ms=100,
        )
        await consumer1.ensure_group()

        messages = await consumer1.read()
        assert len(messages) == 1

        # Now claim with consumer-2
        consumer2 = StreamConsumer(
            redis=redis,
            stream="test:events",
            group="test-group",
            consumer="consumer-2",
            block_ms=100,
        )

        _, claimed = await consumer2.autoclaim(min_idle_ms=0, start="0-0")

        assert len(claimed) == 1
        # Delivery count should be >= 1 (depends on whether XPENDING counts the claim)
        assert claimed[0]["delivery_count"] >= 1

    @pytest.mark.asyncio
    async def test_autoclaim_increments_delivery_count(self, redis):
        """Test that delivery_count correctly increments after multiple claims.

        This verifies that each XAUTOCLAIM increases the delivery_count tracked
        via XPENDING, ensuring accurate retry tracking.
        """
        stream = "test:delivery-increment"
        group = "test-increment-group"

        # Add a message
        await redis.xadd(stream, {"event_type": "test", "data": "{}"})

        consumer1 = StreamConsumer(
            redis=redis,
            stream=stream,
            group=group,
            consumer="consumer-1",
            block_ms=100,
        )
        await consumer1.ensure_group()

        # Consumer-1 reads the message (delivery_count = 1)
        messages = await consumer1.read(read_mode=ReadMode.NEW)
        assert len(messages) == 1
        assert messages[0]["delivery_count"] == 1

        # Consumer-2 claims it (delivery_count should be 2)
        consumer2 = StreamConsumer(
            redis=redis,
            stream=stream,
            group=group,
            consumer="consumer-2",
            block_ms=100,
        )
        _, claimed1 = await consumer2.autoclaim(min_idle_ms=0, start="0-0")
        assert len(claimed1) == 1
        assert claimed1[0]["delivery_count"] == 2

        # Consumer-3 claims it again (delivery_count should be 3)
        consumer3 = StreamConsumer(
            redis=redis,
            stream=stream,
            group=group,
            consumer="consumer-3",
            block_ms=100,
        )
        _, claimed2 = await consumer3.autoclaim(min_idle_ms=0, start="0-0")
        assert len(claimed2) == 1
        assert claimed2[0]["delivery_count"] == 3


class TestRouterDLQConfig:
    """Tests for router-level DLQ configuration."""

    def test_router_accepts_dlq_params(self, redis):
        """Test that EventRouter accepts DLQ configuration parameters."""
        router = EventRouter(
            redis=redis,
            stream="events",
            group="test",
            default_retries=3,
            max_deliveries=5,
            dlq_stream="events:dlq",
        )

        assert router._default_retries == 3
        assert router._max_deliveries == 5
        assert router._dlq_stream == "events:dlq"

    def test_router_default_backoff(self, redis):
        """Test that router has default exponential backoff."""
        router = EventRouter(redis=redis, group="test")

        # Default backoff should be exponential
        assert router._default_backoff is not None
        # First delay for exponential(base=2) is 2^1=2, with ±25% jitter: 1.5 to 2.5
        delay = router._default_backoff(1)
        assert 1.5 <= delay <= 2.5

    def test_router_custom_backoff(self, redis):
        """Test that router accepts custom default backoff."""
        from rapids.backoff import linear

        backoff = linear(delay=5.0)
        router = EventRouter(redis=redis, group="test", default_backoff=backoff)

        assert router._default_backoff is backoff
        assert router._default_backoff(1) == 5.0


class TestConsumerLag:
    """Tests for consumer lag monitoring."""

    @pytest.mark.asyncio
    async def test_consumer_lag_dataclass_is_frozen(self):
        """Test that ConsumerLag is immutable."""
        lag = ConsumerLag(
            stream_length=100,
            pending_count=5,
            consumers_count=2,
            last_delivered_id="1234567890123-0",
            lag=10,
        )

        with pytest.raises(AttributeError):
            lag.stream_length = 200  # type: ignore[misc]

    @pytest.mark.asyncio
    async def test_get_lag_returns_metrics(self, redis):
        """Test that get_lag returns valid ConsumerLag."""
        stream = "test:lag:metrics"
        group = "test-group"

        consumer = StreamConsumer(
            redis=redis,
            stream=stream,
            group=group,
            consumer="consumer-1",
        )
        await consumer.ensure_group()

        # Add some messages
        await redis.xadd(stream, {"data": "1"})
        await redis.xadd(stream, {"data": "2"})

        lag = await consumer.get_lag()

        assert isinstance(lag, ConsumerLag)
        assert lag.stream_length == 2
        assert lag.pending_count == 0  # No messages read yet
        assert lag.consumers_count >= 0
        assert lag.last_delivered_id is not None

    @pytest.mark.asyncio
    async def test_get_lag_with_pending_messages(self, redis):
        """Test that pending_count reflects unacked messages."""
        stream = "test:lag:pending"
        group = "test-group"

        consumer = StreamConsumer(
            redis=redis,
            stream=stream,
            group=group,
            consumer="consumer-1",
        )
        await consumer.ensure_group()

        # Add a message
        await redis.xadd(stream, {"data": "1"})

        # Read but don't ack
        messages = await consumer.read()
        assert len(messages) == 1

        lag = await consumer.get_lag()

        assert lag.stream_length == 1
        assert lag.pending_count == 1

    @pytest.mark.asyncio
    async def test_get_lag_after_ack(self, redis):
        """Test that pending_count decreases after ack."""
        stream = "test:lag:ack"
        group = "test-group"

        consumer = StreamConsumer(
            redis=redis,
            stream=stream,
            group=group,
            consumer="consumer-1",
        )
        await consumer.ensure_group()

        # Add and read a message
        await redis.xadd(stream, {"data": "1"})
        messages = await consumer.read()

        # Ack the message
        await consumer.ack(messages[0]["id"])

        lag = await consumer.get_lag()

        assert lag.stream_length == 1
        assert lag.pending_count == 0

    @pytest.mark.asyncio
    async def test_get_lag_group_not_found(self, redis):
        """Test that get_lag raises when group doesn't exist.

        Note: fakeredis raises IndexError instead of ResponseError,
        so we check for any exception. Integration tests verify real behavior.
        """
        stream = "test:lag:nogroup"

        # Create stream without group
        await redis.xadd(stream, {"data": "1"})

        consumer = StreamConsumer(
            redis=redis,
            stream=stream,
            group="nonexistent-group",
            consumer="consumer-1",
        )
        # Don't call ensure_group()

        # fakeredis behavior differs from real Redis here
        with pytest.raises((ResponseError, IndexError)):
            await consumer.get_lag()

    @pytest.mark.asyncio
    async def test_get_lag_lag_field_may_be_none(self, redis):
        """Test that lag field can be None (Redis < 7.0) or int."""
        stream = "test:lag:lagfield"
        group = "test-group"

        consumer = StreamConsumer(
            redis=redis,
            stream=stream,
            group=group,
            consumer="consumer-1",
        )
        await consumer.ensure_group()

        await redis.xadd(stream, {"data": "1"})

        lag = await consumer.get_lag()

        # lag can be None (Redis < 7.0) or int (Redis 7.0+)
        assert lag.lag is None or isinstance(lag.lag, int)


class TestEventRouterConsumerLag:
    """Tests for EventRouter.get_consumer_lag()."""

    @pytest.mark.asyncio
    async def test_get_consumer_lag_before_start_raises(self, redis):
        """Test that get_consumer_lag raises before start()."""
        router = EventRouter(redis=redis, stream="test:events", group="test")

        with pytest.raises(RuntimeError, match="not started"):
            await router.get_consumer_lag()

    @pytest.mark.asyncio
    async def test_get_consumer_lag_after_setup(self, redis):
        """Test get_consumer_lag works after stream consumer is set up."""
        stream = "test:router:lag"
        group = "test-group"

        router = EventRouter(
            redis=redis,
            stream=stream,
            group=group,
            block_ms=10,
        )

        # Manually set up stream consumer (simulates post-start state)
        router._stream_consumer = StreamConsumer(
            redis=redis,
            stream=stream,
            group=group,
            consumer="test-consumer",
        )
        await router._stream_consumer.ensure_group()

        # Add a message
        await redis.xadd(stream, {"event_type": "test", "data": "{}"})

        lag = await router.get_consumer_lag()

        assert isinstance(lag, ConsumerLag)
        assert lag.stream_length == 1


class TestSchemaVersionDeserialization:
    """Tests for schema_version deserialization and injection."""

    def test_deserialize_injects_schema_version(self, redis):
        """Verify _schema_version is injected during deserialization."""
        from typing import ClassVar

        from pydantic import model_validator

        class VersionAwareEvent(BaseEvent):
            event_type: ClassVar[str] = "version_aware.event"
            value: str
            received_version: int | None = None

            @model_validator(mode="before")
            @classmethod
            def capture_version(cls, data: dict) -> dict:
                # Capture the injected _schema_version
                data["received_version"] = data.pop("_schema_version", None)
                data.pop("_timestamp", None)  # Clean up
                return data

        router = EventRouter(redis=redis, group="test-group")

        raw = {
            "event_type": "version_aware.event",
            "schema_version": "2",
            "data": json.dumps({"value": "test"}),
            "id": "event-1",
            "timestamp": "2024-01-15T10:00:00+00:00",
            "correlation_id": "",
            "causation_id": "",
            "metadata": "{}",
        }

        event = router._deserialize(raw)

        assert isinstance(event, VersionAwareEvent)
        assert event.received_version == 2

    def test_deserialize_injects_timestamp(self, redis):
        """Verify _timestamp is injected during deserialization."""
        from typing import ClassVar

        from pydantic import model_validator

        class TimestampAwareEvent(BaseEvent):
            event_type: ClassVar[str] = "timestamp_aware.event"
            value: str
            received_timestamp: str | None = None

            @model_validator(mode="before")
            @classmethod
            def capture_timestamp(cls, data: dict) -> dict:
                data["received_timestamp"] = data.pop("_timestamp", None)
                data.pop("_schema_version", None)
                return data

        router = EventRouter(redis=redis, group="test-group")

        raw = {
            "event_type": "timestamp_aware.event",
            "schema_version": "1",
            "data": json.dumps({"value": "test"}),
            "id": "event-1",
            "timestamp": "2024-01-15T10:00:00+00:00",
            "correlation_id": "",
            "causation_id": "",
            "metadata": "{}",
        }

        event = router._deserialize(raw)

        assert isinstance(event, TimestampAwareEvent)
        assert event.received_timestamp == "2024-01-15T10:00:00+00:00"

    def test_deserialize_missing_schema_version_defaults_to_1(self, redis):
        """Backward compat: missing schema_version defaults to 1."""
        from typing import ClassVar

        from pydantic import model_validator

        class BackwardCompatEvent(BaseEvent):
            event_type: ClassVar[str] = "backward_compat.event"
            value: str
            received_version: int | None = None

            @model_validator(mode="before")
            @classmethod
            def capture_version(cls, data: dict) -> dict:
                data["received_version"] = data.pop("_schema_version", None)
                data.pop("_timestamp", None)
                return data

        router = EventRouter(redis=redis, group="test-group")

        # Old message format without schema_version field
        raw = {
            "event_type": "backward_compat.event",
            # No "schema_version" field - simulates pre-versioning message
            "data": json.dumps({"value": "old"}),
            "id": "event-1",
            "timestamp": "2024-01-15T10:00:00+00:00",
            "correlation_id": "",
            "causation_id": "",
            "metadata": "{}",
        }

        event = router._deserialize(raw)

        assert isinstance(event, BackwardCompatEvent)
        assert event.received_version == 1  # Default

    def test_deserialize_schema_version_converted_to_int(self, redis):
        """Verify schema_version string is converted to int."""
        from typing import ClassVar

        from pydantic import model_validator

        class IntVersionEvent(BaseEvent):
            event_type: ClassVar[str] = "int_version.event"
            value: str
            received_version: int | None = None

            @model_validator(mode="before")
            @classmethod
            def capture_version(cls, data: dict) -> dict:
                version = data.pop("_schema_version", None)
                # Verify it's an int, not a string
                assert isinstance(version, int), f"Expected int, got {type(version)}"
                data["received_version"] = version
                data.pop("_timestamp", None)
                return data

        router = EventRouter(redis=redis, group="test-group")

        raw = {
            "event_type": "int_version.event",
            "schema_version": "42",  # String from Redis
            "data": json.dumps({"value": "test"}),
            "id": "event-1",
            "timestamp": "2024-01-15T10:00:00+00:00",
            "correlation_id": "",
            "causation_id": "",
            "metadata": "{}",
        }

        event = router._deserialize(raw)

        assert event.received_version == 42


class TestSchemaMigration:
    """Tests for schema migration via model_validator."""

    def test_migration_v1_to_v2(self, redis):
        """Test model_validator migrates v1 data to v2 schema."""
        from typing import ClassVar

        from pydantic import model_validator

        class MigratingEventV2(BaseEvent):
            event_type: ClassVar[str] = "migrating.event"
            schema_version: ClassVar[int] = 2

            name: str
            currency: str  # Added in v2

            @model_validator(mode="before")
            @classmethod
            def migrate(cls, data: dict) -> dict:
                version = data.pop("_schema_version", cls.schema_version)
                data.pop("_timestamp", None)

                if version < 2:
                    data["currency"] = "USD"  # Default for v1

                return data

        router = EventRouter(redis=redis, group="test-group")

        # V1 message without currency field
        raw = {
            "event_type": "migrating.event",
            "schema_version": "1",
            "data": json.dumps({"name": "test-item"}),
            "id": "event-1",
            "timestamp": "2024-01-15T10:00:00+00:00",
            "correlation_id": "",
            "causation_id": "",
            "metadata": "{}",
        }

        event = router._deserialize(raw)

        assert isinstance(event, MigratingEventV2)
        assert event.name == "test-item"
        assert event.currency == "USD"  # Migrated

    def test_migration_can_use_timestamp(self, redis):
        """Verify _timestamp is available for deriving fields in migration."""
        from typing import ClassVar

        from pydantic import model_validator

        class TimestampMigrationEvent(BaseEvent):
            event_type: ClassVar[str] = "timestamp_migration.event"
            schema_version: ClassVar[int] = 2

            name: str
            created_at: str  # Derived from timestamp in v2

            @model_validator(mode="before")
            @classmethod
            def migrate(cls, data: dict) -> dict:
                version = data.pop("_schema_version", cls.schema_version)
                timestamp = data.pop("_timestamp", None)

                if version < 2:
                    data["created_at"] = timestamp or ""

                return data

        router = EventRouter(redis=redis, group="test-group")

        raw = {
            "event_type": "timestamp_migration.event",
            "schema_version": "1",
            "data": json.dumps({"name": "item"}),
            "id": "event-1",
            "timestamp": "2024-01-15T10:00:00+00:00",
            "correlation_id": "",
            "causation_id": "",
            "metadata": "{}",
        }

        event = router._deserialize(raw)

        assert event.created_at == "2024-01-15T10:00:00+00:00"

    def test_migration_chained_v1_v2_v3(self, redis):
        """Test multi-version migration chain (v1→v2→v3)."""
        from typing import ClassVar

        from pydantic import model_validator

        class ChainedMigrationEvent(BaseEvent):
            event_type: ClassVar[str] = "chained_migration.event"
            schema_version: ClassVar[int] = 3

            name: str
            currency: str  # Added in v2
            created_at: str  # Added in v3

            @model_validator(mode="before")
            @classmethod
            def migrate(cls, data: dict) -> dict:
                version = data.pop("_schema_version", cls.schema_version)
                timestamp = data.pop("_timestamp", None)

                # v1 → v2: add currency
                if version < 2:
                    data["currency"] = "USD"

                # v2 → v3: add created_at
                if version < 3:
                    data["created_at"] = timestamp or ""

                return data

        router = EventRouter(redis=redis, group="test-group")

        # V1 message
        raw = {
            "event_type": "chained_migration.event",
            "schema_version": "1",
            "data": json.dumps({"name": "old-item"}),
            "id": "event-1",
            "timestamp": "2024-01-15T10:00:00+00:00",
            "correlation_id": "",
            "causation_id": "",
            "metadata": "{}",
        }

        event = router._deserialize(raw)

        assert event.name == "old-item"
        assert event.currency == "USD"  # v1→v2
        assert event.created_at == "2024-01-15T10:00:00+00:00"  # v2→v3

    def test_no_migration_when_versions_match(self, redis):
        """No migration needed when stored version matches class version."""
        from typing import ClassVar

        from pydantic import model_validator

        class NoMigrationEvent(BaseEvent):
            event_type: ClassVar[str] = "no_migration.event"
            schema_version: ClassVar[int] = 2

            name: str
            currency: str
            migration_called: bool = False

            @model_validator(mode="before")
            @classmethod
            def migrate(cls, data: dict) -> dict:
                version = data.pop("_schema_version", cls.schema_version)
                data.pop("_timestamp", None)

                if version < 2:
                    # This should NOT be called when version matches
                    data["migration_called"] = True
                    data["currency"] = "USD"

                return data

        router = EventRouter(redis=redis, group="test-group")

        # V2 message - no migration needed
        raw = {
            "event_type": "no_migration.event",
            "schema_version": "2",
            "data": json.dumps({"name": "item", "currency": "EUR"}),
            "id": "event-1",
            "timestamp": "2024-01-15T10:00:00+00:00",
            "correlation_id": "",
            "causation_id": "",
            "metadata": "{}",
        }

        event = router._deserialize(raw)

        assert event.name == "item"
        assert event.currency == "EUR"  # Not overwritten
        assert event.migration_called is False

    def test_migration_removes_underscore_fields(self, redis):
        """Verify _schema_version and _timestamp don't leak to model."""
        from typing import ClassVar

        from pydantic import model_validator

        class CleanMigrationEvent(BaseEvent):
            event_type: ClassVar[str] = "clean_migration.event"
            schema_version: ClassVar[int] = 2

            name: str
            status: str = "active"

            @model_validator(mode="before")
            @classmethod
            def migrate(cls, data: dict) -> dict:
                # Remove injected fields
                data.pop("_schema_version", None)
                data.pop("_timestamp", None)
                return data

        router = EventRouter(redis=redis, group="test-group")

        raw = {
            "event_type": "clean_migration.event",
            "schema_version": "1",
            "data": json.dumps({"name": "item"}),
            "id": "event-1",
            "timestamp": "2024-01-15T10:00:00+00:00",
            "correlation_id": "",
            "causation_id": "",
            "metadata": "{}",
        }

        event = router._deserialize(raw)

        # Underscore fields should not be on the model
        assert not hasattr(event, "_schema_version")
        assert not hasattr(event, "_timestamp")

        # model_dump should not include them
        dumped = event.model_dump()
        assert "_schema_version" not in dumped
        assert "_timestamp" not in dumped
