"""Tests for backoff strategies."""

import pytest

from rapids.backoff import Backoff, constant, exponential, linear


class TestExponential:
    """Tests for exponential backoff strategy."""

    @pytest.mark.parametrize(
        ("attempt", "expected"),
        [
            (1, 2.0),
            (2, 4.0),
            (3, 8.0),
            (4, 16.0),
            (5, 32.0),
        ],
        ids=["2^1=2", "2^2=4", "2^3=8", "2^4=16", "2^5=32"],
    )
    def test_basic_values_no_jitter(self, attempt: int, expected: float):
        """Exponential backoff without jitter produces expected values."""
        backoff = exponential(base=2.0, jitter=False)
        assert backoff(attempt) == expected

    @pytest.mark.parametrize(
        ("base", "attempt", "expected"),
        [
            (3.0, 1, 3.0),
            (3.0, 2, 9.0),
            (3.0, 3, 27.0),
            (4.0, 1, 4.0),
            (4.0, 2, 16.0),
        ],
        ids=["3^1=3", "3^2=9", "3^3=27", "4^1=4", "4^2=16"],
    )
    def test_custom_base(self, base: float, attempt: int, expected: float):
        """Custom base changes exponential growth rate."""
        backoff = exponential(base=base, jitter=False)
        assert backoff(attempt) == expected

    @pytest.mark.parametrize(
        ("attempt", "expected"),
        [
            (1, 2.0),  # 2^1 = 2, under cap
            (3, 8.0),  # 2^3 = 8, under cap
            (4, 10.0),  # 2^4 = 16, capped to 10
            (10, 10.0),  # 2^10 = 1024, capped to 10
        ],
        ids=["under-cap-2", "under-cap-8", "capped-16->10", "capped-1024->10"],
    )
    def test_max_delay_cap(self, attempt: int, expected: float):
        """Delay is capped at max_delay."""
        backoff = exponential(base=2.0, max_delay=10.0, jitter=False)
        assert backoff(attempt) == expected

    @pytest.mark.parametrize(
        ("attempt", "base_delay"),
        [
            (1, 2.0),
            (2, 4.0),
            (3, 8.0),
        ],
        ids=["attempt-1", "attempt-2", "attempt-3"],
    )
    def test_jitter_range(self, attempt: int, base_delay: float):
        """Jitter produces values in ±25% range."""
        backoff = exponential(base=2.0, max_delay=100.0, jitter=True)
        results = [backoff(attempt) for _ in range(100)]
        min_expected = base_delay * 0.75
        max_expected = base_delay * 1.25
        assert all(min_expected <= r <= max_expected for r in results)
        # Should have some variance (not all the same)
        assert len(set(results)) > 1


class TestLinear:
    """Tests for linear backoff strategy."""

    @pytest.mark.parametrize(
        ("attempt", "expected"),
        [
            (1, 1.0),
            (2, 2.0),
            (3, 3.0),
            (10, 10.0),
        ],
        ids=["1*1=1", "1*2=2", "1*3=3", "1*10=10"],
    )
    def test_basic_values(self, attempt: int, expected: float):
        """Linear backoff produces expected values."""
        backoff = linear(delay=1.0)
        assert backoff(attempt) == expected

    @pytest.mark.parametrize(
        ("delay", "attempt", "expected"),
        [
            (2.0, 1, 2.0),
            (2.0, 2, 4.0),
            (2.0, 3, 6.0),
            (5.0, 1, 5.0),
            (5.0, 4, 20.0),
        ],
        ids=["2*1=2", "2*2=4", "2*3=6", "5*1=5", "5*4=20"],
    )
    def test_custom_delay(self, delay: float, attempt: int, expected: float):
        """Custom delay multiplier changes growth rate."""
        backoff = linear(delay=delay)
        assert backoff(attempt) == expected

    @pytest.mark.parametrize(
        ("attempt", "expected"),
        [
            (1, 1.0),  # 1*1 = 1, under cap
            (5, 5.0),  # 1*5 = 5, at cap
            (10, 5.0),  # 1*10 = 10, capped to 5
            (100, 5.0),  # 1*100 = 100, capped to 5
        ],
        ids=["under-cap", "at-cap", "capped-10->5", "capped-100->5"],
    )
    def test_max_delay_cap(self, attempt: int, expected: float):
        """Delay is capped at max_delay."""
        backoff = linear(delay=1.0, max_delay=5.0)
        assert backoff(attempt) == expected


class TestConstant:
    """Tests for constant backoff strategy."""

    @pytest.mark.parametrize(
        "attempt",
        [1, 2, 5, 10, 100],
        ids=["attempt-1", "attempt-2", "attempt-5", "attempt-10", "attempt-100"],
    )
    def test_same_value_all_attempts(self, attempt: int):
        """Constant backoff returns same value for all attempts."""
        backoff = constant(delay=1.0)
        assert backoff(attempt) == 1.0

    @pytest.mark.parametrize(
        ("delay", "attempt"),
        [
            (5.0, 1),
            (5.0, 10),
            (10.0, 1),
            (10.0, 100),
        ],
        ids=["5s-attempt1", "5s-attempt10", "10s-attempt1", "10s-attempt100"],
    )
    def test_custom_delay(self, delay: float, attempt: int):
        """Custom delay is returned for all attempts."""
        backoff = constant(delay=delay)
        assert backoff(attempt) == delay


class TestProtocolCompliance:
    """Tests that strategies comply with Backoff protocol."""

    @pytest.mark.parametrize(
        "strategy",
        [
            exponential(),
            linear(),
            constant(),
        ],
        ids=["exponential", "linear", "constant"],
    )
    def test_strategies_are_callable(self, strategy: Backoff):
        """All strategies return callable objects."""
        assert callable(strategy)

    @pytest.mark.parametrize(
        "strategy",
        [
            exponential(),
            linear(),
            constant(),
        ],
        ids=["exponential", "linear", "constant"],
    )
    def test_strategies_return_float(self, strategy: Backoff):
        """All strategies return float values."""
        result = strategy(1)
        assert isinstance(result, float)

    @pytest.mark.parametrize(
        ("strategy", "attempt"),
        [
            (exponential(), 1),
            (exponential(), 5),
            (exponential(), 100),
            (linear(), 1),
            (linear(), 5),
            (linear(), 100),
            (constant(), 1),
            (constant(), 5),
            (constant(), 100),
        ],
        ids=[
            "exp-1",
            "exp-5",
            "exp-100",
            "lin-1",
            "lin-5",
            "lin-100",
            "const-1",
            "const-5",
            "const-100",
        ],
    )
    def test_strategies_accept_attempt_number(self, strategy: Backoff, attempt: int):
        """All strategies accept an attempt number argument."""
        # Should not raise
        result = strategy(attempt)
        assert isinstance(result, float)
