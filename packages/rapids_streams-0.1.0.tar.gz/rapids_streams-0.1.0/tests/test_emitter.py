"""Tests for the emitter module."""

import json
from typing import ClassVar
from unittest.mock import patch

import pytest
from redis.exceptions import ConnectionError, RedisError, TimeoutError

from rapids import BaseEvent, EventEmitter, correlation_scope
from rapids.emitter.context import set_correlation_id
from rapids.exceptions import EmitError


class DocumentCreated(BaseEvent):
    """Test event for emitter tests."""

    doc_id: str
    title: str


class DocumentIndexed(BaseEvent):
    """Test event for causation chain tests."""

    doc_id: str
    index_name: str


class VersionedEvent(BaseEvent):
    """Test event with custom schema version."""

    event_type: ClassVar[str] = "versioned.event"
    schema_version: ClassVar[int] = 2

    item_id: str


class TestEmitter:
    """Tests for EventEmitter class."""

    def test_max_retries_must_be_at_least_one(self, redis):
        """Test that max_retries < 1 raises ValueError."""
        with pytest.raises(ValueError, match="max_retries must be >= 1"):
            EventEmitter(redis=redis, max_retries=0)

        with pytest.raises(ValueError, match="max_retries must be >= 1"):
            EventEmitter(redis=redis, max_retries=-1)

    @pytest.mark.asyncio
    async def test_emit_single_event(self, redis):
        """Test emitting a single event."""
        emitter = EventEmitter(redis=redis, stream="test:events")

        event = DocumentCreated(doc_id="123", title="Test Doc")
        msg_id = await emitter.emit(event)

        assert msg_id is not None
        assert "-" in msg_id  # Redis stream ID format

    @pytest.mark.asyncio
    async def test_emit_stores_correct_format(self, redis):
        """Test that emitted events have correct Redis format."""
        emitter = EventEmitter(redis=redis, stream="test:events")

        event = DocumentCreated(
            doc_id="123",
            title="Test Doc",
            correlation_id="corr-abc",
            metadata={"source": "test"},
        )
        msg_id = await emitter.emit(event)

        # Read back the message
        messages = await redis.xread({"test:events": "0"})
        assert len(messages) == 1

        stream_name, stream_messages = messages[0]
        assert len(stream_messages) == 1

        stored_id, data = stream_messages[0]
        assert stored_id.decode() == msg_id

        # Check message format
        assert data[b"event_type"].decode() == "document.created"
        assert data[b"id"].decode() == event.id
        assert data[b"correlation_id"].decode() == "corr-abc"

        # Check data field contains event-specific data
        event_data = json.loads(data[b"data"].decode())
        assert event_data["doc_id"] == "123"
        assert event_data["title"] == "Test Doc"

        # Check metadata
        metadata = json.loads(data[b"metadata"].decode())
        assert metadata["source"] == "test"

    @pytest.mark.asyncio
    async def test_emit_batch(self, redis):
        """Test emitting multiple events with emit([...])."""
        emitter = EventEmitter(redis=redis, stream="test:events")

        events = [
            DocumentCreated(doc_id="1", title="Doc 1"),
            DocumentCreated(doc_id="2", title="Doc 2"),
            DocumentCreated(doc_id="3", title="Doc 3"),
        ]
        msg_ids = await emitter.emit(events)

        assert len(msg_ids) == 3
        assert all("-" in msg_id for msg_id in msg_ids)

        # Verify all messages are in the stream
        length = await redis.xlen("test:events")
        assert length == 3

    @pytest.mark.asyncio
    async def test_emit_empty_batch(self, redis):
        """Test emitting an empty list returns empty list."""
        emitter = EventEmitter(redis=redis, stream="test:events")

        msg_ids = await emitter.emit([])

        assert msg_ids == []

        # Verify nothing was added to the stream
        exists = await redis.exists("test:events")
        assert not exists

    @pytest.mark.asyncio
    async def test_emit_with_maxlen(self, redis):
        """Test that MAXLEN is applied to stream."""
        emitter = EventEmitter(redis=redis, stream="test:events", maxlen=5)

        # Emit more than maxlen events
        for i in range(10):
            await emitter.emit(DocumentCreated(doc_id=str(i), title=f"Doc {i}"))

        # Stream should be trimmed to maxlen
        length = await redis.xlen("test:events")
        assert length <= 5


class TestEmitterRetry:
    """Tests for EventEmitter retry logic."""

    @pytest.mark.asyncio
    async def test_emit_retries_on_connection_error(self, redis):
        """Test that emit retries on ConnectionError."""
        emitter = EventEmitter(
            redis=redis,
            stream="test:events",
            max_retries=3,
            retry_delay=0.01,
        )
        event = DocumentCreated(doc_id="123", title="Test")

        # Mock xadd to fail twice then succeed
        call_count = 0
        original_xadd = redis.xadd

        async def failing_xadd(*args, **kwargs):
            nonlocal call_count
            call_count += 1
            if call_count < 3:
                raise ConnectionError("Connection lost")
            return await original_xadd(*args, **kwargs)

        with patch.object(redis, "xadd", side_effect=failing_xadd):
            msg_id = await emitter.emit(event)

        assert msg_id is not None
        assert call_count == 3

    @pytest.mark.asyncio
    async def test_emit_retries_on_timeout_error(self, redis):
        """Test that emit retries on TimeoutError."""
        emitter = EventEmitter(
            redis=redis,
            stream="test:events",
            max_retries=3,
            retry_delay=0.01,
        )
        event = DocumentCreated(doc_id="123", title="Test")

        call_count = 0
        original_xadd = redis.xadd

        async def failing_xadd(*args, **kwargs):
            nonlocal call_count
            call_count += 1
            if call_count < 2:
                raise TimeoutError("Timeout")
            return await original_xadd(*args, **kwargs)

        with patch.object(redis, "xadd", side_effect=failing_xadd):
            msg_id = await emitter.emit(event)

        assert msg_id is not None
        assert call_count == 2

    @pytest.mark.asyncio
    async def test_emit_retries_on_redis_error(self, redis):
        """Test that emit retries on general RedisError."""
        emitter = EventEmitter(
            redis=redis,
            stream="test:events",
            max_retries=3,
            retry_delay=0.01,
        )
        event = DocumentCreated(doc_id="123", title="Test")

        call_count = 0
        original_xadd = redis.xadd

        async def failing_xadd(*args, **kwargs):
            nonlocal call_count
            call_count += 1
            if call_count < 2:
                raise RedisError("Some Redis error")
            return await original_xadd(*args, **kwargs)

        with patch.object(redis, "xadd", side_effect=failing_xadd):
            msg_id = await emitter.emit(event)

        assert msg_id is not None
        assert call_count == 2

    @pytest.mark.asyncio
    async def test_emit_raises_emit_error_after_max_retries(self, redis):
        """Test that emit raises EmitError after exhausting retries."""
        emitter = EventEmitter(
            redis=redis,
            stream="test:events",
            max_retries=3,
            retry_delay=0.01,
        )
        event = DocumentCreated(doc_id="123", title="Test")

        async def always_fail(*args, **kwargs):
            raise ConnectionError("Connection lost")

        with patch.object(redis, "xadd", side_effect=always_fail):
            with pytest.raises(EmitError) as exc_info:
                await emitter.emit(event)

        error = exc_info.value
        assert error.event_type == "document.created"
        assert error.event_id == event.id
        assert error.stream == "test:events"
        assert error.attempts == 3
        assert "Connection lost" in str(error)

    @pytest.mark.asyncio
    async def test_emit_raises_emit_error_on_unexpected_exception(self, redis):
        """Test that unexpected exceptions raise EmitError immediately."""
        emitter = EventEmitter(
            redis=redis,
            stream="test:events",
            max_retries=3,
            retry_delay=0.01,
        )
        event = DocumentCreated(doc_id="123", title="Test")

        call_count = 0

        async def unexpected_error(*args, **kwargs):
            nonlocal call_count
            call_count += 1
            raise ValueError("Unexpected error")

        with patch.object(redis, "xadd", side_effect=unexpected_error):
            with pytest.raises(EmitError) as exc_info:
                await emitter.emit(event)

        # Should fail immediately without retrying
        assert call_count == 1
        error = exc_info.value
        assert error.attempts == 1
        assert "Unexpected error" in str(error)

    @pytest.mark.asyncio
    async def test_emit_error_preserves_cause(self, redis):
        """Test that EmitError preserves the original exception."""
        emitter = EventEmitter(
            redis=redis,
            stream="test:events",
            max_retries=1,
            retry_delay=0.01,
        )
        event = DocumentCreated(doc_id="123", title="Test")

        async def always_fail(*args, **kwargs):
            raise ConnectionError("Original error")

        with patch.object(redis, "xadd", side_effect=always_fail):
            with pytest.raises(EmitError) as exc_info:
                await emitter.emit(event)

        assert exc_info.value.__cause__ is not None
        assert isinstance(exc_info.value.__cause__, ConnectionError)

    @pytest.mark.asyncio
    async def test_emit_uses_exponential_backoff(self, redis):
        """Test that retry delays use exponential backoff."""
        emitter = EventEmitter(
            redis=redis,
            stream="test:events",
            max_retries=3,
            retry_delay=0.1,
        )
        event = DocumentCreated(doc_id="123", title="Test")

        async def always_fail(*args, **kwargs):
            raise ConnectionError("Connection lost")

        sleep_calls = []

        async def mock_sleep(delay):
            sleep_calls.append(delay)
            # Don't actually sleep in tests

        with patch.object(redis, "xadd", side_effect=always_fail):
            with patch("rapids.emitter.core.asyncio.sleep", side_effect=mock_sleep):
                with pytest.raises(EmitError):
                    await emitter.emit(event)

        # Should have 2 sleeps (between attempts 1-2 and 2-3)
        assert len(sleep_calls) == 2
        # Exponential backoff: 0.1 * 2^0 = 0.1, 0.1 * 2^1 = 0.2
        assert sleep_calls[0] == pytest.approx(0.1)
        assert sleep_calls[1] == pytest.approx(0.2)


class TestEmitterBatchErrors:
    """Tests for batch emit error handling."""

    @pytest.mark.asyncio
    async def test_batch_emit_pipeline_connection_error(self, redis):
        """Test that batch emit raises EmitError on pipeline ConnectionError."""
        emitter = EventEmitter(redis=redis, stream="test:events")

        events = [
            DocumentCreated(doc_id="1", title="Doc 1"),
            DocumentCreated(doc_id="2", title="Doc 2"),
        ]

        # Mock the pipeline to fail on execute
        original_pipeline = redis.pipeline

        def mock_pipeline(*args, **kwargs):
            pipe = original_pipeline(*args, **kwargs)

            async def failing_execute():
                raise ConnectionError("Pipeline connection lost")

            pipe.execute = failing_execute
            return pipe

        with patch.object(redis, "pipeline", side_effect=mock_pipeline):
            with pytest.raises(EmitError) as exc_info:
                await emitter.emit(events)

        error = exc_info.value
        assert error.event_type == "batch[2]"
        assert error.stream == "test:events"
        assert error.attempts == 1
        assert "Pipeline connection lost" in str(error)

    @pytest.mark.asyncio
    async def test_batch_emit_pipeline_timeout_error(self, redis):
        """Test that batch emit raises EmitError on pipeline TimeoutError."""
        emitter = EventEmitter(redis=redis, stream="test:events")

        events = [DocumentCreated(doc_id="1", title="Doc 1")]

        original_pipeline = redis.pipeline

        def mock_pipeline(*args, **kwargs):
            pipe = original_pipeline(*args, **kwargs)

            async def failing_execute():
                raise TimeoutError("Pipeline timeout")

            pipe.execute = failing_execute
            return pipe

        with patch.object(redis, "pipeline", side_effect=mock_pipeline):
            with pytest.raises(EmitError) as exc_info:
                await emitter.emit(events)

        error = exc_info.value
        assert "batch[1]" in error.event_type

    @pytest.mark.asyncio
    async def test_batch_emit_individual_xadd_failure(self, redis):
        """Test that batch emit raises EmitError when individual XADD fails in pipeline."""
        emitter = EventEmitter(redis=redis, stream="test:events")

        events = [
            DocumentCreated(doc_id="1", title="Doc 1"),
            DocumentCreated(doc_id="2", title="Doc 2"),
        ]

        original_pipeline = redis.pipeline

        def mock_pipeline(*args, **kwargs):
            pipe = original_pipeline(*args, **kwargs)

            async def execute_with_failure():
                # Return first success, second failure
                return [
                    b"1234567890123-0",
                    RedisError("XADD failed for second event"),
                ]

            pipe.execute = execute_with_failure
            return pipe

        with patch.object(redis, "pipeline", side_effect=mock_pipeline):
            with pytest.raises(EmitError) as exc_info:
                await emitter.emit(events)

        error = exc_info.value
        assert error.event_type == "document.created"
        assert error.event_id == events[1].id
        assert "XADD failed" in str(error)

    @pytest.mark.asyncio
    async def test_batch_emit_string_result_handling(self, redis):
        """Test that batch emit handles string results (non-bytes) from pipeline."""
        emitter = EventEmitter(redis=redis, stream="test:events")

        events = [DocumentCreated(doc_id="1", title="Doc 1")]

        original_pipeline = redis.pipeline

        def mock_pipeline(*args, **kwargs):
            pipe = original_pipeline(*args, **kwargs)

            async def execute_with_string_result():
                # Return a string instead of bytes
                return ["1234567890123-0"]

            pipe.execute = execute_with_string_result
            return pipe

        with patch.object(redis, "pipeline", side_effect=mock_pipeline):
            msg_ids = await emitter.emit(events)

        assert msg_ids == ["1234567890123-0"]


class TestEmitterSerialization:
    """Tests for event serialization edge cases."""

    @pytest.mark.asyncio
    async def test_emit_with_non_serializable_metadata_raises(self, redis):
        """Test that non-serializable metadata raises TypeError."""
        emitter = EventEmitter(redis=redis, stream="test:events")

        # Create an event with non-serializable metadata
        event = DocumentCreated(
            doc_id="123",
            title="Test",
            metadata={"callback": lambda x: x},  # Functions are not JSON serializable
        )

        with pytest.raises(TypeError, match="Failed to serialize"):
            await emitter.emit(event)


class TestCorrelationCausation:
    """Tests for correlation and causation tracking."""

    @pytest.mark.asyncio
    async def test_emit_injects_correlation_id_from_context(self, redis):
        """Test that emit injects correlation_id from correlation_scope."""
        emitter = EventEmitter(redis=redis, stream="test:events")

        async with correlation_scope("ctx-corr-123"):
            event = DocumentCreated(doc_id="123", title="Test")
            await emitter.emit(event)

        # Read back the message
        messages = await redis.xread({"test:events": "0"})
        _, stream_messages = messages[0]
        _, data = stream_messages[0]

        assert data[b"correlation_id"].decode() == "ctx-corr-123"

    @pytest.mark.asyncio
    async def test_emit_prefers_event_correlation_id_over_context(self, redis):
        """Test that event's explicit correlation_id wins over context."""
        emitter = EventEmitter(redis=redis, stream="test:events")

        async with correlation_scope("ctx-corr-123"):
            # Event has explicit correlation_id
            event = DocumentCreated(
                doc_id="123",
                title="Test",
                correlation_id="explicit-corr-456",
            )
            await emitter.emit(event)

        messages = await redis.xread({"test:events": "0"})
        _, stream_messages = messages[0]
        _, data = stream_messages[0]

        # Should use event's correlation_id, not context
        assert data[b"correlation_id"].decode() == "explicit-corr-456"

    @pytest.mark.asyncio
    async def test_emit_sets_causation_id_from_caused_by(self, redis):
        """Test that emit sets causation_id from caused_by event."""
        emitter = EventEmitter(redis=redis, stream="test:events")

        cause_event = DocumentCreated(doc_id="123", title="Original")
        effect_event = DocumentIndexed(doc_id="123", index_name="search")

        await emitter.emit(effect_event, caused_by=cause_event)

        messages = await redis.xread({"test:events": "0"})
        _, stream_messages = messages[0]
        _, data = stream_messages[0]

        assert data[b"causation_id"].decode() == cause_event.id

    @pytest.mark.asyncio
    async def test_emit_inherits_correlation_id_from_caused_by(self, redis):
        """Test that emit inherits correlation_id from caused_by event."""
        emitter = EventEmitter(redis=redis, stream="test:events")

        cause_event = DocumentCreated(
            doc_id="123",
            title="Original",
            correlation_id="chain-corr-789",
        )
        effect_event = DocumentIndexed(doc_id="123", index_name="search")

        await emitter.emit(effect_event, caused_by=cause_event)

        messages = await redis.xread({"test:events": "0"})
        _, stream_messages = messages[0]
        _, data = stream_messages[0]

        # Should inherit correlation_id from caused_by
        assert data[b"correlation_id"].decode() == "chain-corr-789"

    @pytest.mark.asyncio
    async def test_emit_event_correlation_id_wins_over_caused_by(self, redis):
        """Test that event's correlation_id wins over caused_by's correlation_id."""
        emitter = EventEmitter(redis=redis, stream="test:events")

        cause_event = DocumentCreated(
            doc_id="123",
            title="Original",
            correlation_id="cause-corr",
        )
        effect_event = DocumentIndexed(
            doc_id="123",
            index_name="search",
            correlation_id="effect-corr",
        )

        await emitter.emit(effect_event, caused_by=cause_event)

        messages = await redis.xread({"test:events": "0"})
        _, stream_messages = messages[0]
        _, data = stream_messages[0]

        # Event's explicit correlation_id should win
        assert data[b"correlation_id"].decode() == "effect-corr"

    @pytest.mark.asyncio
    async def test_emit_event_causation_id_wins_over_caused_by(self, redis):
        """Test that event's explicit causation_id wins over caused_by."""
        emitter = EventEmitter(redis=redis, stream="test:events")

        cause_event = DocumentCreated(doc_id="123", title="Original")
        effect_event = DocumentIndexed(
            doc_id="123",
            index_name="search",
            causation_id="explicit-cause-id",
        )

        await emitter.emit(effect_event, caused_by=cause_event)

        messages = await redis.xread({"test:events": "0"})
        _, stream_messages = messages[0]
        _, data = stream_messages[0]

        # Event's explicit causation_id should win
        assert data[b"causation_id"].decode() == "explicit-cause-id"

    @pytest.mark.asyncio
    async def test_emit_batch_applies_context_correlation_to_all(self, redis):
        """Test that batch emit applies context correlation_id to all events."""
        emitter = EventEmitter(redis=redis, stream="test:events")

        async with correlation_scope("batch-corr-123"):
            events = [
                DocumentCreated(doc_id="1", title="Doc 1"),
                DocumentCreated(doc_id="2", title="Doc 2"),
                DocumentCreated(doc_id="3", title="Doc 3"),
            ]
            await emitter.emit(events)

        messages = await redis.xread({"test:events": "0"})
        _, stream_messages = messages[0]

        # All events should have the same correlation_id
        for _, data in stream_messages:
            assert data[b"correlation_id"].decode() == "batch-corr-123"

    @pytest.mark.asyncio
    async def test_emit_batch_with_caused_by(self, redis):
        """Test that batch emit applies caused_by to all events."""
        emitter = EventEmitter(redis=redis, stream="test:events")

        cause_event = DocumentCreated(
            doc_id="original",
            title="Original",
            correlation_id="batch-chain-corr",
        )
        effect_events = [
            DocumentIndexed(doc_id="1", index_name="idx1"),
            DocumentIndexed(doc_id="2", index_name="idx2"),
        ]

        await emitter.emit(effect_events, caused_by=cause_event)

        messages = await redis.xread({"test:events": "0"})
        _, stream_messages = messages[0]

        # All events should have causation_id and inherit correlation_id
        for _, data in stream_messages:
            assert data[b"causation_id"].decode() == cause_event.id
            assert data[b"correlation_id"].decode() == "batch-chain-corr"

    @pytest.mark.asyncio
    async def test_caused_by_correlation_wins_over_context(self, redis):
        """Test that caused_by's correlation_id wins over context."""
        emitter = EventEmitter(redis=redis, stream="test:events")

        cause_event = DocumentCreated(
            doc_id="123",
            title="Original",
            correlation_id="cause-corr",
        )

        async with correlation_scope("ctx-corr"):
            effect_event = DocumentIndexed(doc_id="123", index_name="search")
            await emitter.emit(effect_event, caused_by=cause_event)

        messages = await redis.xread({"test:events": "0"})
        _, stream_messages = messages[0]
        _, data = stream_messages[0]

        # caused_by's correlation_id should win over context
        assert data[b"correlation_id"].decode() == "cause-corr"

    @pytest.mark.asyncio
    async def test_no_correlation_when_nothing_set(self, redis):
        """Test that correlation_id is empty when nothing is set."""
        # Ensure no context is set
        set_correlation_id(None)

        emitter = EventEmitter(redis=redis, stream="test:events")

        event = DocumentCreated(doc_id="123", title="Test")
        await emitter.emit(event)

        messages = await redis.xread({"test:events": "0"})
        _, stream_messages = messages[0]
        _, data = stream_messages[0]

        # Should be empty string (serialized None)
        assert data[b"correlation_id"].decode() == ""
        assert data[b"causation_id"].decode() == ""

    @pytest.mark.asyncio
    async def test_full_causation_chain(self, redis):
        """Test a full causation chain: A causes B causes C."""
        emitter = EventEmitter(redis=redis, stream="test:events")

        # Start a correlation scope
        async with correlation_scope("chain-test"):
            # Event A - the root
            event_a = DocumentCreated(doc_id="123", title="Root")
            await emitter.emit(event_a)

            # Event B - caused by A
            event_b = DocumentIndexed(doc_id="123", index_name="idx1")
            await emitter.emit(event_b, caused_by=event_a)

            # Event C - caused by B
            event_c = DocumentIndexed(doc_id="123", index_name="idx2")
            await emitter.emit(event_c, caused_by=event_b)

        messages = await redis.xread({"test:events": "0"})
        _, stream_messages = messages[0]

        # Event A: correlation from scope, no causation
        _, data_a = stream_messages[0]
        assert data_a[b"correlation_id"].decode() == "chain-test"
        assert data_a[b"causation_id"].decode() == ""

        # Event B: correlation inherited from A, causation = A.id
        _, data_b = stream_messages[1]
        assert data_b[b"correlation_id"].decode() == "chain-test"
        assert data_b[b"causation_id"].decode() == event_a.id

        # Event C: correlation inherited from B, causation = B.id
        _, data_c = stream_messages[2]
        assert data_c[b"correlation_id"].decode() == "chain-test"
        assert data_c[b"causation_id"].decode() == event_b.id


class TestSchemaVersionSerialization:
    """Tests for schema_version serialization."""

    @pytest.mark.asyncio
    async def test_emit_includes_schema_version(self, redis):
        """Verify schema_version is included in Redis message (default v1)."""
        emitter = EventEmitter(redis=redis, stream="test:events")

        event = DocumentCreated(doc_id="123", title="Test Doc")
        await emitter.emit(event)

        # Read back the message
        messages = await redis.xread({"test:events": "0"})
        _, stream_messages = messages[0]
        _, data = stream_messages[0]

        # Default schema_version should be "1"
        assert data[b"schema_version"].decode() == "1"

    @pytest.mark.asyncio
    async def test_emit_custom_schema_version(self, redis):
        """Verify custom schema_version is serialized correctly."""
        emitter = EventEmitter(redis=redis, stream="test:events")

        event = VersionedEvent(item_id="456")
        await emitter.emit(event)

        # Read back the message
        messages = await redis.xread({"test:events": "0"})
        _, stream_messages = messages[0]
        _, data = stream_messages[0]

        # Should have schema_version="2"
        assert data[b"schema_version"].decode() == "2"
        assert data[b"event_type"].decode() == "versioned.event"

    @pytest.mark.asyncio
    async def test_emit_batch_includes_schema_version(self, redis):
        """Verify batch emit includes schema_version for all events."""
        emitter = EventEmitter(redis=redis, stream="test:events")

        events = [
            DocumentCreated(doc_id="1", title="Doc 1"),  # v1
            VersionedEvent(item_id="2"),  # v2
            DocumentCreated(doc_id="3", title="Doc 3"),  # v1
        ]
        await emitter.emit(events)

        # Read back the messages
        messages = await redis.xread({"test:events": "0"})
        _, stream_messages = messages[0]

        # Verify schema_version for each event
        _, data1 = stream_messages[0]
        _, data2 = stream_messages[1]
        _, data3 = stream_messages[2]

        assert data1[b"schema_version"].decode() == "1"
        assert data2[b"schema_version"].decode() == "2"
        assert data3[b"schema_version"].decode() == "1"
