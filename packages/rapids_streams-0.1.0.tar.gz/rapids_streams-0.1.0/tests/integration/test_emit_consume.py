"""Integration tests for emit -> consume flow.

These tests verify the full emit -> consume cycle using testcontainers
with a real Redis instance. They test the actual consume loop behavior.
"""

import asyncio
import contextlib
from typing import ClassVar

import pytest
from pydantic import model_validator

from rapids import BaseEvent, EventEmitter, EventRouter, correlation_scope
from rapids.router.consumer import (
    ConsumerLag,
    GroupStartPosition,
    ReadMode,
    StreamConsumer,
)


class PropertyCreated(BaseEvent):
    """Test event for integration tests."""

    property_id: str
    address: str


class PropertyUpdated(BaseEvent):
    """Another test event."""

    property_id: str
    new_price: float


class PropertyIndexed(BaseEvent):
    """Test event for causation chain tests."""

    property_id: str
    index_name: str


class TestEmitConsumeFlow:
    """Integration tests for full emit -> consume flow."""

    @pytest.mark.integration
    async def test_emit_and_consume_single_event(self, real_redis):
        """Test emitting and consuming a single event."""
        stream = "integration:single:events"
        with contextlib.suppress(Exception):
            await real_redis.delete(stream)

        emitter = EventEmitter(redis=real_redis, stream=stream)
        results = []

        router = EventRouter(
            redis=real_redis,
            stream=stream,
            group="test-group",
            block_ms=100,
        )

        @router.on(PropertyCreated)
        async def handle_created(event: PropertyCreated) -> None:
            results.append(event.property_id)

        # Emit event
        await emitter.emit(
            PropertyCreated(property_id="prop-123", address="123 Main St")
        )

        # Start router in background
        async def run_router():
            with contextlib.suppress(asyncio.CancelledError):
                await router.start()

        router_task = asyncio.create_task(run_router())

        # Wait for message to be processed
        for _ in range(20):
            if results:
                break
            await asyncio.sleep(0.1)

        await router.stop()
        await router_task

        assert results == ["prop-123"]

    @pytest.mark.integration
    async def test_emit_multiple_events(self, real_redis):
        """Test emitting and consuming multiple events."""
        stream = "integration:multi:events"
        with contextlib.suppress(Exception):
            await real_redis.delete(stream)

        emitter = EventEmitter(redis=real_redis, stream=stream)
        results = []

        router = EventRouter(
            redis=real_redis,
            stream=stream,
            group="test-group",
            block_ms=100,
        )

        @router.on(PropertyCreated)
        async def handle_created(event: PropertyCreated) -> None:
            results.append(("created", event.property_id))

        @router.on(PropertyUpdated)
        async def handle_updated(event: PropertyUpdated) -> None:
            results.append(("updated", event.property_id))

        # Emit events
        await emitter.emit(PropertyCreated(property_id="prop-1", address="1 Main St"))
        await emitter.emit(PropertyUpdated(property_id="prop-1", new_price=500000.0))
        await emitter.emit(PropertyCreated(property_id="prop-2", address="2 Main St"))

        # Start router in background
        async def run_router():
            with contextlib.suppress(asyncio.CancelledError):
                await router.start()

        router_task = asyncio.create_task(run_router())

        # Wait for all messages to be processed
        for _ in range(30):
            if len(results) >= 3:
                break
            await asyncio.sleep(0.1)

        await router.stop()
        await router_task

        assert len(results) == 3
        assert ("created", "prop-1") in results
        assert ("updated", "prop-1") in results
        assert ("created", "prop-2") in results

    @pytest.mark.integration
    async def test_multiple_handlers_same_event(self, real_redis):
        """Test multiple handlers receiving the same event."""
        stream = "integration:handlers:events"
        with contextlib.suppress(Exception):
            await real_redis.delete(stream)

        emitter = EventEmitter(redis=real_redis, stream=stream)
        handler1_results = []
        handler2_results = []

        router = EventRouter(
            redis=real_redis,
            stream=stream,
            group="test-group",
            block_ms=100,
        )

        @router.on(PropertyCreated)
        async def handler1(event: PropertyCreated) -> None:
            handler1_results.append(event.property_id)

        @router.on(PropertyCreated)
        async def handler2(event: PropertyCreated) -> None:
            handler2_results.append(event.property_id)

        # Emit event
        await emitter.emit(
            PropertyCreated(property_id="prop-123", address="123 Main St")
        )

        # Start router in background
        async def run_router():
            with contextlib.suppress(asyncio.CancelledError):
                await router.start()

        router_task = asyncio.create_task(run_router())

        # Wait for message to be processed
        for _ in range(20):
            if handler1_results and handler2_results:
                break
            await asyncio.sleep(0.1)

        await router.stop()
        await router_task

        # Both handlers should have received the event
        assert handler1_results == ["prop-123"]
        assert handler2_results == ["prop-123"]

    @pytest.mark.integration
    async def test_messages_are_acked(self, real_redis):
        """Test that messages are acknowledged after processing."""
        stream = "integration:ack:events"
        group = "ack-test-group"
        with contextlib.suppress(Exception):
            await real_redis.delete(stream)

        emitter = EventEmitter(redis=real_redis, stream=stream)
        processed = []

        router = EventRouter(
            redis=real_redis,
            stream=stream,
            group=group,
            block_ms=100,
        )

        @router.on(PropertyCreated)
        async def handler(event: PropertyCreated) -> None:
            processed.append(event.property_id)

        # Emit event
        await emitter.emit(
            PropertyCreated(property_id="prop-123", address="123 Main St")
        )

        # Start router in background
        async def run_router():
            with contextlib.suppress(asyncio.CancelledError):
                await router.start()

        router_task = asyncio.create_task(run_router())

        # Wait for message to be processed
        for _ in range(20):
            if processed:
                break
            await asyncio.sleep(0.1)

        await router.stop()
        await router_task

        # Check that there are no pending messages after processing
        pending = await real_redis.xpending(stream, group)
        assert pending["pending"] == 0

    @pytest.mark.integration
    async def test_start_from_dollar_only_reads_new_messages(self, real_redis):
        """Test that group_start_id='$' only reads messages after group creation."""
        stream = "integration:startfrom:dollar"
        with contextlib.suppress(Exception):
            await real_redis.delete(stream)

        # Add a message BEFORE creating the consumer group
        await real_redis.xadd(
            stream,
            {"event_type": "old_event", "data": "{}"},
        )

        # Create consumer with group_start_id="$"
        consumer = StreamConsumer(
            redis=real_redis,
            stream=stream,
            group="test-group-dollar",
            consumer="consumer-1",
            block_ms=100,
            group_start_id=GroupStartPosition.LATEST,
        )
        await consumer.ensure_group()

        # Add a message AFTER creating the consumer group
        await real_redis.xadd(
            stream,
            {"event_type": "new_event", "data": "{}"},
        )

        # Should only read the new message
        messages = await consumer.read()
        assert len(messages) == 1
        assert messages[0]["data"]["event_type"] == "new_event"

    @pytest.mark.integration
    async def test_start_from_dollar_resets_existing_group(self, real_redis):
        """Test that group_start_id='$' resets position for existing groups.

        When a group already exists and ensure_group is called with group_start_id="$",
        it should use XGROUP SETID to reset the last-delivered-ID to the current
        stream end, skipping any unread messages.
        """
        stream = "integration:startfrom:reset"
        with contextlib.suppress(Exception):
            await real_redis.delete(stream)

        # Create a message
        await real_redis.xadd(
            stream,
            {"event_type": "msg1", "data": "{}"},
        )

        # Create group with group_start_id=BEGINNING first
        consumer1 = StreamConsumer(
            redis=real_redis,
            stream=stream,
            group="test-group-reset",
            consumer="consumer-1",
            block_ms=100,
            group_start_id=GroupStartPosition.BEGINNING,
        )
        await consumer1.ensure_group()

        # Add another message (this is unread by the group)
        await real_redis.xadd(
            stream,
            {"event_type": "msg2", "data": "{}"},
        )

        # Now create a NEW consumer with same group but group_start_id=LATEST
        # This should reset the group position to current end, skipping msg1 and msg2
        consumer2 = StreamConsumer(
            redis=real_redis,
            stream=stream,
            group="test-group-reset",
            consumer="consumer-2",
            block_ms=100,
            group_start_id=GroupStartPosition.LATEST,
        )
        await consumer2.ensure_group()

        # Add a third message AFTER the reset
        await real_redis.xadd(
            stream,
            {"event_type": "msg3", "data": "{}"},
        )

        # Should only read msg3 (the one after reset)
        # msg1 and msg2 should be skipped because we reset to "$"
        messages = await consumer2.read()
        assert len(messages) == 1
        assert messages[0]["data"]["event_type"] == "msg3"


class TestCorrelationCausationFlow:
    """Integration tests for correlation and causation tracking."""

    @pytest.mark.integration
    async def test_correlation_id_preserved_through_consume(self, real_redis):
        """Test that correlation_id is preserved when consuming events."""
        stream = "integration:correlation:events"
        with contextlib.suppress(Exception):
            await real_redis.delete(stream)

        emitter = EventEmitter(redis=real_redis, stream=stream)
        received_events: list[PropertyCreated] = []

        router = EventRouter(
            redis=real_redis,
            stream=stream,
            group="test-group",
            block_ms=100,
        )

        @router.on(PropertyCreated)
        async def handler(event: PropertyCreated) -> None:
            received_events.append(event)

        # Emit event with correlation scope
        async with correlation_scope("test-corr-123"):
            await emitter.emit(
                PropertyCreated(property_id="prop-1", address="123 Main St")
            )

        # Start router
        async def run_router():
            with contextlib.suppress(asyncio.CancelledError):
                await router.start()

        router_task = asyncio.create_task(run_router())

        # Wait for message to be processed
        for _ in range(20):
            if received_events:
                break
            await asyncio.sleep(0.1)

        await router.stop()
        await router_task

        assert len(received_events) == 1
        assert received_events[0].correlation_id == "test-corr-123"

    @pytest.mark.integration
    async def test_causation_chain_preserved_through_consume(self, real_redis):
        """Test that causation chain is preserved when consuming events."""
        stream = "integration:causation:events"
        with contextlib.suppress(Exception):
            await real_redis.delete(stream)

        emitter = EventEmitter(redis=real_redis, stream=stream)
        received_events: list[BaseEvent] = []

        router = EventRouter(
            redis=real_redis,
            stream=stream,
            group="test-group",
            block_ms=100,
        )

        @router.on(PropertyCreated)
        async def handle_created(event: PropertyCreated) -> None:
            received_events.append(event)

        @router.on(PropertyIndexed)
        async def handle_indexed(event: PropertyIndexed) -> None:
            received_events.append(event)

        # Create cause event with correlation
        cause_event = PropertyCreated(
            property_id="prop-1",
            address="123 Main St",
            correlation_id="chain-corr-456",
        )

        # Emit cause event
        await emitter.emit(cause_event)

        # Emit effect event with caused_by
        effect_event = PropertyIndexed(property_id="prop-1", index_name="search")
        await emitter.emit(effect_event, caused_by=cause_event)

        # Start router
        async def run_router():
            with contextlib.suppress(asyncio.CancelledError):
                await router.start()

        router_task = asyncio.create_task(run_router())

        # Wait for both messages to be processed
        for _ in range(30):
            if len(received_events) >= 2:
                break
            await asyncio.sleep(0.1)

        await router.stop()
        await router_task

        assert len(received_events) == 2

        # Find the events by type
        created = next(
            (e for e in received_events if isinstance(e, PropertyCreated)), None
        )
        indexed = next(
            (e for e in received_events if isinstance(e, PropertyIndexed)), None
        )
        assert created is not None, "PropertyCreated event not found in received_events"
        assert indexed is not None, "PropertyIndexed event not found in received_events"

        # Check correlation preserved
        assert created.correlation_id == "chain-corr-456"
        assert indexed.correlation_id == "chain-corr-456"

        # Check causation chain
        assert created.causation_id is None
        assert indexed.causation_id == cause_event.id

    @pytest.mark.integration
    async def test_handler_can_emit_with_caused_by(self, real_redis):
        """Test that handlers can emit events with caused_by for event chains."""
        stream = "integration:handler-emit:events"
        with contextlib.suppress(Exception):
            await real_redis.delete(stream)

        emitter = EventEmitter(redis=real_redis, stream=stream)
        all_events: list[BaseEvent] = []

        router = EventRouter(
            redis=real_redis,
            stream=stream,
            group="test-group",
            block_ms=100,
        )

        @router.on(PropertyCreated)
        async def handle_created(event: PropertyCreated) -> None:
            all_events.append(event)
            # Handler emits a follow-up event using the emitter instance
            await emitter.emit(
                PropertyIndexed(property_id=event.property_id, index_name="search"),
                caused_by=event,
            )

        @router.on(PropertyIndexed)
        async def handle_indexed(event: PropertyIndexed) -> None:
            all_events.append(event)

        # Emit initial event with correlation scope
        async with correlation_scope("handler-emit-corr"):
            await emitter.emit(
                PropertyCreated(property_id="prop-1", address="123 Main St")
            )

        # Start router
        async def run_router():
            with contextlib.suppress(asyncio.CancelledError):
                await router.start()

        router_task = asyncio.create_task(run_router())

        # Wait for both messages to be processed
        for _ in range(40):
            if len(all_events) >= 2:
                break
            await asyncio.sleep(0.1)

        await router.stop()
        await router_task

        assert len(all_events) == 2

        created = next((e for e in all_events if isinstance(e, PropertyCreated)), None)
        indexed = next((e for e in all_events if isinstance(e, PropertyIndexed)), None)
        assert created is not None, "PropertyCreated event not found in all_events"
        assert indexed is not None, "PropertyIndexed event not found in all_events"

        # Both should have same correlation_id
        assert created.correlation_id == "handler-emit-corr"
        assert indexed.correlation_id == "handler-emit-corr"

        # Indexed should be caused by Created
        assert indexed.causation_id == created.id


class TestPendingRecoveryIntegration:
    """Integration tests for pending message recovery."""

    @pytest.mark.integration
    async def test_read_with_start_id_zero_returns_pending(self, real_redis):
        """Test that read(read_mode=PENDING) returns own pending messages."""
        stream = "integration:pending:events"
        with contextlib.suppress(Exception):
            await real_redis.delete(stream)

        # Add a message
        await real_redis.xadd(
            stream,
            {"event_type": "pending_event", "data": "{}"},
        )

        consumer = StreamConsumer(
            redis=real_redis,
            stream=stream,
            group="test-group-pending",
            consumer="consumer-1",
            block_ms=100,
        )
        await consumer.ensure_group()

        # Read message (puts it in pending)
        messages = await consumer.read(read_mode=ReadMode.NEW)
        assert len(messages) == 1

        # Don't ack - message is now pending
        # Reading with read_mode=PENDING should return pending messages
        pending_messages = await consumer.read(read_mode=ReadMode.PENDING)
        assert len(pending_messages) == 1
        assert pending_messages[0]["data"]["event_type"] == "pending_event"

    @pytest.mark.integration
    async def test_own_pending_recovery_on_restart(self, real_redis):
        """Test that consumer recovers its own pending messages after restart."""
        stream = "integration:ownpending:events"
        group = "test-recovery-group"
        consumer_name = "consumer-1"

        with contextlib.suppress(Exception):
            await real_redis.delete(stream)

        # Add a message
        await real_redis.xadd(
            stream,
            {
                "event_type": "property.created",
                "data": '{"property_id": "123", "address": "Main St"}',
                "id": "evt-1",
                "timestamp": "2024-01-15T10:00:00+00:00",
                "correlation_id": "",
                "causation_id": "",
                "metadata": "{}",
            },
        )

        # Consumer 1: Read message but don't ack (simulates crash)
        consumer1 = StreamConsumer(
            redis=real_redis,
            stream=stream,
            group=group,
            consumer=consumer_name,
            block_ms=100,
        )
        await consumer1.ensure_group()
        messages = await consumer1.read(read_mode=ReadMode.NEW)
        assert len(messages) == 1
        # Don't ack - simulates crash before ack

        # Verify message is pending
        pending = await real_redis.xpending(stream, group)
        assert pending["pending"] == 1

        # Consumer restarts with same name (simulates recovery)
        results = []
        router = EventRouter(
            redis=real_redis,
            stream=stream,
            group=group,
            consumer=consumer_name,  # Same consumer name
            block_ms=100,
        )

        @router.on(PropertyCreated)
        async def handler(event: PropertyCreated) -> None:
            results.append(event.property_id)

        # Start router - should recover pending message in Phase 1
        async def run_router():
            with contextlib.suppress(asyncio.CancelledError):
                await router.start()

        router_task = asyncio.create_task(run_router())

        # Wait for message to be processed
        for _ in range(20):
            if results:
                break
            await asyncio.sleep(0.1)

        await router.stop()
        await router_task

        # Should have recovered and processed the pending message
        assert results == ["123"]

        # Message should be acked now
        pending = await real_redis.xpending(stream, group)
        assert pending["pending"] == 0

    @pytest.mark.integration
    async def test_autoclaim_from_dead_consumer(self, real_redis):
        """Test that XAUTOCLAIM claims messages from dead consumers."""
        stream = "integration:autoclaim:events"
        group = "test-autoclaim-group"

        with contextlib.suppress(Exception):
            await real_redis.delete(stream)

        # Add a message
        await real_redis.xadd(
            stream,
            {"event_type": "claim_test", "data": "{}"},
        )

        # Consumer A reads message but crashes (no ack)
        consumer_a = StreamConsumer(
            redis=real_redis,
            stream=stream,
            group=group,
            consumer="consumer-A",
            block_ms=100,
        )
        await consumer_a.ensure_group()
        messages = await consumer_a.read(read_mode=ReadMode.NEW)
        assert len(messages) == 1

        # Consumer B claims the message (with min_idle_ms=0 for immediate testing)
        consumer_b = StreamConsumer(
            redis=real_redis,
            stream=stream,
            group=group,
            consumer="consumer-B",
            block_ms=100,
        )

        next_cursor, claimed = await consumer_b.autoclaim(min_idle_ms=0, start="0-0")

        # Should have claimed the message
        assert len(claimed) == 1
        assert claimed[0]["data"]["event_type"] == "claim_test"

        # Message should now be owned by consumer-B
        pending_range = await real_redis.xpending_range(
            stream, group, min="-", max="+", count=10
        )
        assert len(pending_range) == 1
        pending_consumer = pending_range[0]["consumer"]
        if isinstance(pending_consumer, bytes):
            pending_consumer = pending_consumer.decode()
        assert pending_consumer == "consumer-B"


class TestConsumerLagIntegration:
    """Integration tests for consumer lag monitoring."""

    @pytest.mark.integration
    async def test_get_lag_with_real_redis(self, real_redis):
        """Test get_lag returns accurate metrics with real Redis."""
        stream = "integration:lag:basic"
        group = "lag-test-group"

        # Clean up
        with contextlib.suppress(Exception):
            await real_redis.delete(stream)

        consumer = StreamConsumer(
            redis=real_redis,
            stream=stream,
            group=group,
            consumer="consumer-1",
        )
        await consumer.ensure_group()

        # Add messages
        for i in range(5):
            await real_redis.xadd(stream, {"n": str(i)})

        lag = await consumer.get_lag()

        assert isinstance(lag, ConsumerLag)
        assert lag.stream_length == 5
        assert lag.pending_count == 0  # Nothing read yet
        assert lag.consumers_count >= 0
        assert lag.last_delivered_id == "0-0"  # Group just created

    @pytest.mark.integration
    async def test_lag_updates_after_consuming(self, real_redis):
        """Test that lag metrics update after consuming messages."""
        stream = "integration:lag:consume"
        group = "lag-consume-group"

        # Clean up
        with contextlib.suppress(Exception):
            await real_redis.delete(stream)

        consumer = StreamConsumer(
            redis=real_redis,
            stream=stream,
            group=group,
            consumer="consumer-1",
        )
        await consumer.ensure_group()

        # Add 3 messages
        for i in range(3):
            await real_redis.xadd(stream, {"n": str(i)})

        # Read all messages
        messages = await consumer.read()
        assert len(messages) == 3

        # Check lag - should show pending
        lag_before_ack = await consumer.get_lag()
        assert lag_before_ack.stream_length == 3
        assert lag_before_ack.pending_count == 3

        # Ack all messages
        for msg in messages:
            await consumer.ack(msg["id"])

        # Check lag - should be caught up
        lag_after_ack = await consumer.get_lag()
        assert lag_after_ack.stream_length == 3
        assert lag_after_ack.pending_count == 0

    @pytest.mark.integration
    async def test_router_get_consumer_lag_integration(self, real_redis):
        """Test EventRouter.get_consumer_lag() with real Redis."""
        stream = "integration:lag:router"
        group = "lag-router-group"

        # Clean up
        with contextlib.suppress(Exception):
            await real_redis.delete(stream)

        # Add messages before starting router
        for i in range(3):
            await real_redis.xadd(
                stream,
                {
                    "event_type": "property.created",
                    "data": f'{{"property_id": "{i}"}}',
                    "id": f"event-{i}",
                    "timestamp": "2024-01-01T00:00:00+00:00",
                    "correlation_id": "",
                    "causation_id": "",
                    "metadata": "{}",
                },
            )

        router = EventRouter(
            redis=real_redis,
            stream=stream,
            group=group,
            block_ms=100,
        )

        # Start router in background
        router_task = asyncio.create_task(router.start())

        # Give router time to start
        await asyncio.sleep(0.2)

        # Get lag via router
        lag = await router.get_consumer_lag()

        assert isinstance(lag, ConsumerLag)
        assert lag.stream_length == 3

        # Stop router
        await router.stop()
        await router_task


# Define versioned event at module level for registry
class VersionedOrderEvent(BaseEvent):
    """Event that has evolved through multiple schema versions.

    Evolution history:
    - v1: order_id, amount
    - v2: added currency (required)
    """

    event_type: ClassVar[str] = "versioned_order.event"
    schema_version: ClassVar[int] = 2

    order_id: str
    amount: float
    currency: str  # Added in v2

    @model_validator(mode="before")
    @classmethod
    def migrate(cls, data: dict) -> dict:
        version = data.pop("_schema_version", cls.schema_version)
        data.pop("_timestamp", None)

        if version < 2:
            data["currency"] = "USD"

        return data


class TestSchemaVersioningIntegration:
    """Integration tests for schema versioning emit -> consume flow."""

    @pytest.mark.integration
    async def test_emit_v1_consume_v2_with_migration(self, real_redis):
        """Full flow: simulate v1 message, consume with v2 event that migrates."""
        stream = "integration:versioning:v1v2"
        group = "versioning-test-group"

        with contextlib.suppress(Exception):
            await real_redis.delete(stream)

        results: list[VersionedOrderEvent] = []

        router = EventRouter(
            redis=real_redis,
            stream=stream,
            group=group,
            block_ms=100,
        )

        @router.on(VersionedOrderEvent)
        async def handler(event: VersionedOrderEvent) -> None:
            results.append(event)

        # Manually add v1 format message (simulating old producer)
        await real_redis.xadd(
            stream,
            {
                "event_type": "versioned_order.event",
                "schema_version": "1",  # V1 message
                "data": '{"order_id": "order-123", "amount": 99.99}',  # No currency
                "id": "evt-v1-1",
                "timestamp": "2024-01-15T10:00:00+00:00",
                "correlation_id": "",
                "causation_id": "",
                "metadata": "{}",
            },
        )

        # Start router
        async def run_router():
            with contextlib.suppress(asyncio.CancelledError):
                await router.start()

        router_task = asyncio.create_task(run_router())

        # Wait for message to be processed
        for _ in range(20):
            if results:
                break
            await asyncio.sleep(0.1)

        await router.stop()
        await router_task

        assert len(results) == 1
        event = results[0]
        assert event.order_id == "order-123"
        assert event.amount == 99.99
        assert event.currency == "USD"  # Migrated from v1

    @pytest.mark.integration
    async def test_emit_v2_consume_v2_no_migration(self, real_redis):
        """Full flow: same version needs no migration."""
        stream = "integration:versioning:v2v2"
        group = "versioning-v2-group"

        with contextlib.suppress(Exception):
            await real_redis.delete(stream)

        emitter = EventEmitter(redis=real_redis, stream=stream)
        results: list[VersionedOrderEvent] = []

        router = EventRouter(
            redis=real_redis,
            stream=stream,
            group=group,
            block_ms=100,
        )

        @router.on(VersionedOrderEvent)
        async def handler(event: VersionedOrderEvent) -> None:
            results.append(event)

        # Emit v2 event normally (will have schema_version=2)
        await emitter.emit(
            VersionedOrderEvent(order_id="order-456", amount=199.99, currency="EUR")
        )

        # Start router
        async def run_router():
            with contextlib.suppress(asyncio.CancelledError):
                await router.start()

        router_task = asyncio.create_task(run_router())

        # Wait for message to be processed
        for _ in range(20):
            if results:
                break
            await asyncio.sleep(0.1)

        await router.stop()
        await router_task

        assert len(results) == 1
        event = results[0]
        assert event.order_id == "order-456"
        assert event.amount == 199.99
        assert event.currency == "EUR"  # Not migrated, preserved

    @pytest.mark.integration
    async def test_forward_compat_new_optional_field(self, real_redis):
        """Old consumer ignores new fields from newer producer."""
        stream = "integration:versioning:forward"
        group = "versioning-forward-group"

        with contextlib.suppress(Exception):
            await real_redis.delete(stream)

        results: list[PropertyCreated] = []

        router = EventRouter(
            redis=real_redis,
            stream=stream,
            group=group,
            block_ms=100,
        )

        @router.on(PropertyCreated)
        async def handler(event: PropertyCreated) -> None:
            results.append(event)

        # Simulate a newer producer sending extra fields
        await real_redis.xadd(
            stream,
            {
                "event_type": "property.created",
                "schema_version": "1",
                "data": '{"property_id": "prop-789", "address": "123 Main", "new_future_field": "ignored"}',
                "id": "evt-forward-1",
                "timestamp": "2024-01-15T10:00:00+00:00",
                "correlation_id": "",
                "causation_id": "",
                "metadata": "{}",
            },
        )

        # Start router
        async def run_router():
            with contextlib.suppress(asyncio.CancelledError):
                await router.start()

        router_task = asyncio.create_task(run_router())

        # Wait for message to be processed
        for _ in range(20):
            if results:
                break
            await asyncio.sleep(0.1)

        await router.stop()
        await router_task

        # Should process successfully, ignoring unknown field
        assert len(results) == 1
        event = results[0]
        assert event.property_id == "prop-789"
        assert event.address == "123 Main"
        # Unknown field is ignored
        assert not hasattr(event, "new_future_field")
