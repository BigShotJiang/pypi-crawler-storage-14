"""Basic tests for rapids package."""

import rapids


def test_version():
    """Test that version is defined."""
    assert rapids.__version__ == "0.1.0"
