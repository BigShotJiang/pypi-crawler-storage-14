"""Tests for the events module."""

from rapids.events.base import (
    BaseEvent,
    Event,
    _camel_to_snake,
    _generate_event_type,
    get_all_subclasses,
    get_event_class,
)
from rapids.events.generic import GenericEvent


class TestAutoNaming:
    """Tests for auto-naming logic."""

    def test_camel_to_snake_simple(self):
        """Test simple CamelCase conversion."""
        assert _camel_to_snake("DocumentCreated") == "document_created"
        assert _camel_to_snake("UserDeleted") == "user_deleted"

    def test_camel_to_snake_multi_word(self):
        """Test multi-word CamelCase conversion."""
        assert _camel_to_snake("UserAccountSuspended") == "user_account_suspended"
        assert _camel_to_snake("PropertyListingUpdated") == "property_listing_updated"

    def test_camel_to_snake_acronyms(self):
        """Test handling of acronyms."""
        assert _camel_to_snake("S3ObjectUploaded") == "s3_object_uploaded"
        assert _camel_to_snake("XMLParser") == "xml_parser"
        assert _camel_to_snake("HTTPResponse") == "http_response"

    def test_generate_event_type_simple(self):
        """Test event type generation from class name."""
        assert _generate_event_type("DocumentCreated") == "document.created"
        assert _generate_event_type("UserDeleted") == "user.deleted"

    def test_generate_event_type_multi_word(self):
        """Test event type generation for multi-word domains."""
        assert _generate_event_type("UserAccountSuspended") == "user_account.suspended"
        assert (
            _generate_event_type("PropertyListingUpdated") == "property_listing.updated"
        )

    def test_generate_event_type_acronyms(self):
        """Test event type generation with acronyms."""
        assert _generate_event_type("S3ObjectUploaded") == "s3_object.uploaded"

    def test_generate_event_type_single_word(self):
        """Test event type generation for single-word class name."""
        assert _generate_event_type("Event") == "event"
        assert _generate_event_type("Notification") == "notification"


class TestBaseEvent:
    """Tests for BaseEvent class."""

    def test_auto_registration(self):
        """Test that subclasses are automatically registered."""

        class TestDocumentCreated(BaseEvent):
            doc_id: str

        # Should be registered with auto-generated event_type
        assert TestDocumentCreated.event_type == "test_document.created"
        assert get_event_class("test_document.created") is TestDocumentCreated

    def test_explicit_event_type(self):
        """Test explicit event_type override."""

        class LegacyEvent(BaseEvent):
            event_type = "legacy.custom.event"
            value: str

        assert LegacyEvent.event_type == "legacy.custom.event"
        assert get_event_class("legacy.custom.event") is LegacyEvent

    def test_skip_registration(self):
        """Test that classes with _skip_registration=True are not registered."""
        from typing import ClassVar

        class AbstractDocumentEvent(BaseEvent):
            _skip_registration: ClassVar[bool] = True
            doc_id: str

        # Should not be in registry
        assert get_event_class("abstract_document.event") is None

    def test_abstract_classes_not_registered(self):
        """Test that abstract classes are automatically skipped from registration."""
        from abc import abstractmethod

        class AbstractEntityEvent(BaseEvent):
            """Abstract base for entity events - should not be registered."""

            entity_id: str

            @abstractmethod
            def get_entity_type(self) -> str:
                """Return the entity type."""
                ...

        class ConcreteEntityCreated(AbstractEntityEvent):
            """Concrete implementation - should be registered."""

            name: str

            def get_entity_type(self) -> str:
                return "entity"

        # Abstract class should not be registered
        assert get_event_class("abstract_entity.event") is None

        # Concrete subclass should be registered
        assert get_event_class("concrete_entity.created") is ConcreteEntityCreated

    def test_duplicate_event_type_raises(self):
        """Test that duplicate event_type raises ValueError."""
        import pytest

        class UniqueEventOne(BaseEvent):
            event_type = "duplicate.test.event"
            value: str

        with pytest.raises(ValueError, match="Duplicate event_type"):

            class UniqueEventTwo(BaseEvent):
                event_type = "duplicate.test.event"
                other: int

    def test_default_fields(self):
        """Test default field values."""

        class SimpleEvent(BaseEvent):
            name: str

        event = SimpleEvent(name="test")

        assert event.id is not None
        assert len(event.id) == 36  # UUID format
        assert event.timestamp is not None
        assert event.correlation_id is None
        assert event.causation_id is None
        assert event.metadata == {}

    def test_custom_fields(self):
        """Test setting custom field values."""

        class CustomEvent(BaseEvent):
            value: int

        event = CustomEvent(
            value=42,
            correlation_id="corr-123",
            causation_id="cause-456",
            metadata={"key": "value"},
        )

        assert event.value == 42
        assert event.correlation_id == "corr-123"
        assert event.causation_id == "cause-456"
        assert event.metadata == {"key": "value"}

    def test_event_is_immutable(self):
        """Test that events cannot be mutated after creation."""
        import pytest
        from pydantic import ValidationError

        class ImmutableEvent(BaseEvent):
            name: str

        event = ImmutableEvent(name="original")

        with pytest.raises(ValidationError):
            event.name = "modified"

        with pytest.raises(ValidationError):
            event.correlation_id = "new-correlation"


class TestEventTypeInheritance:
    """Tests for event_type inheritance behavior."""

    def test_child_class_gets_own_event_type(self):
        """Test that child classes get their own generated event_type, not parent's."""
        from typing import ClassVar

        class ParentEventCreated(BaseEvent):
            _skip_registration: ClassVar[bool] = True
            parent_field: str = "parent"

        class ChildEventUpdated(ParentEventCreated):
            child_field: str = "child"

        # Child should have its own generated event_type, not inherit parent's
        assert ChildEventUpdated.event_type == "child_event.updated"
        assert get_event_class("child_event.updated") is ChildEventUpdated

    def test_child_without_explicit_event_type_gets_generated(self):
        """Test child class without explicit event_type gets auto-generated one."""

        class BaseDocumentEvent(BaseEvent):
            event_type = "base_document.event"
            doc_id: str = "123"

        class ChildDocumentArchived(BaseDocumentEvent):
            archived_by: str = "user"

        # Child should get its own generated event_type
        assert ChildDocumentArchived.event_type == "child_document.archived"
        assert get_event_class("child_document.archived") is ChildDocumentArchived

    def test_child_with_explicit_event_type_uses_it(self):
        """Test child class with explicit event_type uses the explicit value."""

        class ParentOrderEvent(BaseEvent):
            event_type = "parent_order.event"
            order_id: str = "order-1"

        class ChildOrderProcessed(ParentOrderEvent):
            event_type = "custom.order.processed"
            processor: str = "system"

        # Child should use its explicit event_type
        assert ChildOrderProcessed.event_type == "custom.order.processed"
        assert get_event_class("custom.order.processed") is ChildOrderProcessed

    def test_multiple_inheritance_levels(self):
        """Test event_type generation across multiple inheritance levels."""
        from typing import ClassVar

        class GrandparentEvent(BaseEvent):
            _skip_registration: ClassVar[bool] = True
            level: str = "grandparent"

        class ParentPaymentEvent(GrandparentEvent):
            payment_id: str = "pay-1"

        class ChildPaymentRefunded(ParentPaymentEvent):
            refund_reason: str = "requested"

        # Each level should have its own event_type
        assert ParentPaymentEvent.event_type == "parent_payment.event"
        assert ChildPaymentRefunded.event_type == "child_payment.refunded"

    def test_sibling_classes_get_different_event_types(self):
        """Test that sibling classes each get their own event_type."""
        from typing import ClassVar

        class CommonAncestorEvent(BaseEvent):
            _skip_registration: ClassVar[bool] = True
            common: str = "shared"

        class SiblingOneCreated(CommonAncestorEvent):
            one_field: str = "one"

        class SiblingTwoDeleted(CommonAncestorEvent):
            two_field: str = "two"

        # Each sibling should have its own event_type
        assert SiblingOneCreated.event_type == "sibling_one.created"
        assert SiblingTwoDeleted.event_type == "sibling_two.deleted"
        assert SiblingOneCreated.event_type != SiblingTwoDeleted.event_type

    def test_child_with_empty_event_type_gets_generated(self):
        """Test child class with empty string event_type gets auto-generated one."""

        class ParentInvoiceEvent(BaseEvent):
            event_type = "parent_invoice.event"
            invoice_id: str = "inv-1"

        class ChildInvoicePaid(ParentInvoiceEvent):
            event_type = ""  # Explicitly empty
            amount: float = 0.0

        # Child with empty event_type should get generated one
        assert ChildInvoicePaid.event_type == "child_invoice.paid"


class TestGetAllSubclasses:
    """Tests for get_all_subclasses function."""

    def test_get_subclasses(self):
        """Test retrieving all subclasses of a base class."""
        from typing import ClassVar

        class AbstractTestEvent(BaseEvent):
            _skip_registration: ClassVar[bool] = True
            entity_id: str

        class TestEventA(AbstractTestEvent):
            name: str

        class TestEventB(AbstractTestEvent):
            value: int

        subclasses = get_all_subclasses(AbstractTestEvent)

        assert TestEventA in subclasses
        assert TestEventB in subclasses
        assert AbstractTestEvent not in subclasses


class TestEventHierarchy:
    """Tests for Event base class and routing_key property."""

    def test_base_event_inherits_from_event(self):
        """Test that BaseEvent inherits from Event."""
        assert issubclass(BaseEvent, Event)

    def test_generic_event_inherits_from_event(self):
        """Test that GenericEvent inherits from Event."""
        assert issubclass(GenericEvent, Event)

    def test_base_event_routing_key(self):
        """Test that BaseEvent.routing_key returns event_type."""

        class TestRoutingEvent(BaseEvent):
            value: str

        event = TestRoutingEvent(value="test")
        assert event.routing_key == "test_routing.event"
        assert event.routing_key == TestRoutingEvent.event_type

    def test_generic_event_routing_key(self):
        """Test that GenericEvent.routing_key returns raw_type."""
        event = GenericEvent(raw_type="custom.type", data={"key": "value"})
        assert event.routing_key == "custom.type"
        assert event.routing_key == event.raw_type

    def test_event_isinstance_checks(self):
        """Test isinstance checks work with Event hierarchy."""

        class ConcreteTestEvent(BaseEvent):
            name: str

        typed_event = ConcreteTestEvent(name="test")
        generic_event = GenericEvent(raw_type="test.type", data={})

        # Both should be instances of Event
        assert isinstance(typed_event, Event)
        assert isinstance(generic_event, Event)

        # Type-specific checks
        assert isinstance(typed_event, BaseEvent)
        assert isinstance(generic_event, GenericEvent)
        assert not isinstance(typed_event, GenericEvent)
        assert not isinstance(generic_event, BaseEvent)

    def test_event_common_fields(self):
        """Test that both BaseEvent and GenericEvent have common fields from Event."""

        class TypedTestEvent(BaseEvent):
            data_field: str

        typed_event = TypedTestEvent(
            data_field="test",
            correlation_id="corr-1",
            causation_id="cause-1",
            metadata={"key": "val"},
        )

        generic_event = GenericEvent(
            raw_type="test.type",
            data={},
            correlation_id="corr-2",
            causation_id="cause-2",
            metadata={"other": "val"},
        )

        # Both have common fields
        for event in [typed_event, generic_event]:
            assert hasattr(event, "id")
            assert hasattr(event, "timestamp")
            assert hasattr(event, "correlation_id")
            assert hasattr(event, "causation_id")
            assert hasattr(event, "metadata")
            assert hasattr(event, "routing_key")


class TestGenericEvent:
    """Tests for GenericEvent class."""

    def test_generic_event_creation(self):
        """Test creating a GenericEvent."""
        event = GenericEvent(
            raw_type="unknown.event.type",
            data={"foo": "bar", "num": 123},
        )

        assert event.raw_type == "unknown.event.type"
        assert event.data == {"foo": "bar", "num": 123}
        assert event.id is not None
        assert event.timestamp is not None

    def test_generic_event_with_all_fields(self):
        """Test GenericEvent with all standard fields."""
        event = GenericEvent(
            raw_type="test.type",
            data={},
            id="custom-id",
            correlation_id="corr-123",
            causation_id="cause-456",
            metadata={"source": "test"},
        )

        assert event.id == "custom-id"
        assert event.correlation_id == "corr-123"
        assert event.causation_id == "cause-456"
        assert event.metadata == {"source": "test"}

    def test_generic_event_is_immutable(self):
        """Test that GenericEvent cannot be mutated after creation."""
        import pytest
        from pydantic import ValidationError

        event = GenericEvent(
            raw_type="test.type",
            data={"key": "value"},
        )

        with pytest.raises(ValidationError):
            event.raw_type = "modified.type"

        with pytest.raises(ValidationError):
            event.data = {"new": "data"}


class TestForwardCompatibility:
    """Tests for forward compatibility (extra='ignore' behavior)."""

    def test_extra_fields_ignored_on_creation(self):
        """Verify extra='ignore' allows unknown fields during model_validate."""

        class SimpleEventFC(BaseEvent):
            event_type = "simple_fc.event"
            name: str

        # Simulate deserializing data with extra fields (e.g., from newer producer)
        data = {
            "name": "test",
            "future_field": "from_v2",  # Unknown field
            "another_new_field": 123,  # Another unknown field
        }

        # Should not raise - extra fields are ignored
        event = SimpleEventFC.model_validate(data)
        assert event.name == "test"

    def test_extra_fields_not_stored_on_model(self):
        """Verify unknown fields don't end up on the model instance."""

        class CleanEventFC(BaseEvent):
            event_type = "clean_fc.event"
            value: int

        data = {
            "value": 42,
            "unknown_field": "should_not_appear",
            "_internal": "also_ignored",
        }

        event = CleanEventFC.model_validate(data)

        # Unknown fields should not be accessible
        assert not hasattr(event, "unknown_field")
        assert not hasattr(event, "_internal")

        # model_dump should not include unknown fields
        dumped = event.model_dump()
        assert "unknown_field" not in dumped
        assert "_internal" not in dumped

    def test_optional_field_addition_non_breaking(self):
        """Adding optional field doesn't break deserialization of old data."""

        class EvolvingEventFC(BaseEvent):
            event_type = "evolving_fc.event"
            required_field: str
            optional_new_field: str | None = None  # Added in v2

        # Old v1 data without the new optional field
        old_data = {"required_field": "original"}

        event = EvolvingEventFC.model_validate(old_data)
        assert event.required_field == "original"
        assert event.optional_new_field is None

        # New v2 data with the optional field
        new_data = {"required_field": "updated", "optional_new_field": "present"}

        event2 = EvolvingEventFC.model_validate(new_data)
        assert event2.required_field == "updated"
        assert event2.optional_new_field == "present"
