"""Tests for the exceptions module."""

from rapids.exceptions import (
    DeserializationError,
    RapidsError,
)


class TestRapidsError:
    """Tests for RapidsError base class."""

    def test_rapids_error_is_exception(self):
        """Test that RapidsError is an Exception."""
        err = RapidsError("test error")
        assert isinstance(err, Exception)
        assert str(err) == "test error"


class TestDeserializationError:
    """Tests for DeserializationError."""

    def test_stores_event_type(self):
        """Test that event_type is stored on the exception."""
        err = DeserializationError("user.created", "invalid JSON")
        assert err.event_type == "user.created"

    def test_error_message_contains_details(self):
        """Test that error message contains event type and reason."""
        err = DeserializationError("order.placed", "missing required field")
        msg = str(err)
        assert "order.placed" in msg
        assert "missing required field" in msg

    def test_is_rapids_error(self):
        """Test that DeserializationError is a RapidsError."""
        err = DeserializationError("test.event", "reason")
        assert isinstance(err, RapidsError)
