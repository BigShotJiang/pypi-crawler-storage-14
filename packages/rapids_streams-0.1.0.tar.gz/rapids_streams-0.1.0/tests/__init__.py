"""Rapids test suite."""
