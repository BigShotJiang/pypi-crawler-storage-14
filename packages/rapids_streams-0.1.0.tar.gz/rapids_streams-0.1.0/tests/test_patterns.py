"""Tests for glob pattern matching."""

import pytest

from rapids.utils.patterns import compile_pattern, glob_match


class TestGlobMatch:
    """Parametrized tests for glob_match function."""

    @pytest.mark.parametrize(
        ("pattern", "event_type", "expected"),
        [
            # Single segment wildcard (*) - matches
            ("document.*", "document.created", True),
            ("document.*", "document.deleted", True),
            ("document.*", "document.updated", True),
            ("*.created", "document.created", True),
            ("*.created", "user.created", True),
            ("*.*.created", "a.b.created", True),
            ("*.*.*", "a.b.c", True),
            # Single segment wildcard (*) - no match
            ("document.*", "document.compliance.failed", False),
            ("document.*", "document.a.b", False),
            ("document.*", "user.created", False),
            ("*.created", "document.deleted", False),
            ("*.*.created", "a.b.c.created", False),
            # Multi-segment wildcard (**) - matches
            ("document.**", "document.created", True),
            ("document.**", "document.compliance.failed", True),
            ("document.**", "document.a.b.c.d", True),
            ("**.created", "document.created", True),
            ("**.created", "deep.nested.created", True),
            ("start.**.end", "start.middle.end", True),
            ("start.**.end", "start.a.b.c.end", True),
            # Multi-segment wildcard (**) - no match
            ("**.created", "created", False),
            ("start.**.end", "start.end", False),
            # Catch-all (*) - matches
            ("*", "event", True),
            ("*", "document.created", True),
            ("*", "a.b.c.d", True),
            # Catch-all (*) - no match
            ("*", "", False),
            # Exact match (no wildcards)
            ("document.created", "document.created", True),
            ("document.created", "document.deleted", False),
            ("document.created", "user.created", False),
            # Edge cases
            ("**", "", True),  # ** matches empty (regex .*)
            ("document.*", "", False),
            ("a.*.b", "a..b", False),  # * requires at least one char
            ("a.**.b", "a..b", True),  # ** can match empty
            # Special regex chars should be escaped
            ("event[1]", "event[1]", True),
            ("event(test)", "event(test)", True),
            ("event+plus", "event+plus", True),
        ],
        ids=[
            # Single segment matches
            "single-*-suffix-created",
            "single-*-suffix-deleted",
            "single-*-suffix-updated",
            "single-*-prefix-doc",
            "single-*-prefix-user",
            "multi-single-*-match",
            "triple-single-*-match",
            # Single segment no match
            "single-*-no-multi-segment",
            "single-*-no-two-segments",
            "single-*-wrong-prefix",
            "single-*-wrong-suffix",
            "multi-single-*-no-extra",
            # Multi-segment matches
            "**-single-segment",
            "**-multi-segment",
            "**-deep-nested",
            "**-prefix-doc",
            "**-prefix-deep",
            "**-middle-one",
            "**-middle-many",
            # Multi-segment no match
            "**-no-bare-suffix",
            "**-middle-no-zero-seg",
            # Catch-all matches
            "catch-all-single",
            "catch-all-dotted",
            "catch-all-deep",
            # Catch-all no match
            "catch-all-empty",
            # Exact match
            "exact-match",
            "exact-no-match-deleted",
            "exact-no-match-prefix",
            # Edge cases
            "**-empty-string",
            "single-*-empty",
            "single-*-double-dot",
            "**-double-dot",
            "regex-brackets",
            "regex-parens",
            "regex-plus",
        ],
    )
    def test_glob_match(self, pattern: str, event_type: str, expected: bool):
        """Test glob pattern matching."""
        assert glob_match(pattern, event_type) is expected


class TestPatternCaching:
    """Tests for pattern compilation caching."""

    def test_same_pattern_returns_cached(self):
        """Same pattern returns cached compiled regex."""
        pattern1 = compile_pattern("document.*")
        pattern2 = compile_pattern("document.*")
        assert pattern1 is pattern2

    def test_different_patterns_not_same(self):
        """Different patterns return different compiled regexes."""
        pattern1 = compile_pattern("document.*")
        pattern2 = compile_pattern("user.*")
        assert pattern1 is not pattern2
