"""Callables for Azure AI."""
