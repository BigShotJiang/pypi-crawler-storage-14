Datetime Cycling
================

.. admonition:: Get a copy of this example
   :class: hint

   .. code-block:: console

      $ cylc get-resources examples/datetime-cycling

.. literalinclude:: flow.cylc
   :language: cylc

Run it with::

   $ cylc vip datetime-cycling
