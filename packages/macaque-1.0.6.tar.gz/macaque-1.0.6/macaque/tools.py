#!/usr/bin/python
"""
@Author  :  Lijiawei
@Date    :  2022/11/26 3:55 下午
@Desc    :  tools line.
"""
import os
import stat
from typing import List, Dict, Any
from airtest.core.api import shell


def make_file_executable(file_path: str) -> bool:
    """
    如果路径没有可执行权限，执行 chmod +x

    :param file_path: 文件路径
    :return: 如果文件存在且操作成功返回 True，否则返回 False
    """
    if os.path.isfile(file_path):
        mode = os.lstat(file_path)[stat.ST_MODE]
        executable = True if mode & stat.S_IXUSR else False
        if not executable:
            os.chmod(file_path, mode | stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH)
        return True
    return False


def log2list(log_file: str) -> List[Dict[str, Any]]:
    """
    转换日志文件为列表

    :param log_file: 日志文件路径
    :return: 崩溃信息列表，每个元素包含 crash_time 和 stack_trace
    """
    # 读取日志文件内容
    try:
        with open(log_file, encoding="utf-8") as file:
            log_content = file.read()
    except (FileNotFoundError, IOError) as e:
        return []

    crash_entries = log_content.split("\n\n")

    # 用于存储所有崩溃信息的列表
    crashes = []

    for entry in crash_entries:
        # 提取崩溃信息
        crash_start = entry.find("crash:")
        crash_end = entry.find("crashend")
        
        # 边界检查：如果找不到关键标记，跳过该条目
        if crash_start == -1 or crash_end == -1:
            continue
            
        crash_info = entry[crash_start:crash_end]

        # 提取崩溃时间
        date_marker = "(dump time: "
        date_start = crash_info.find(date_marker)
        if date_start == -1:
            crash_time = ""
        else:
            date_start += len(date_marker)
            date_end = crash_info.find(")", date_start)
            if date_end == -1:
                crash_time = ""
            else:
                crash_time = crash_info[date_start:date_end].replace("\n", "").replace("\t", "")

        # 提取崩溃堆栈信息
        stack_marker = "Long Msg:"
        stack_trace_start = crash_info.find(stack_marker)
        if stack_trace_start == -1:
            stack_trace = ""
        else:
            stack_trace_start += len(stack_marker)
            stack_trace = crash_info[stack_trace_start:].replace("\n", "").replace("\t", "")

        formatted_text_crash_time = [
            {f"line{i + 1}": line.strip()}
            for i, line in enumerate(crash_time.split("// ")) if line.strip()
        ]
        formatted_text_stack_trace = [
            {f"line{i + 1}": line.strip()}
            for i, line in enumerate(stack_trace.split("// ")) if line.strip()
        ]

        # 构造JSON对象并添加到列表中
        crash_data = {
            "crash_time": formatted_text_crash_time,
            "stack_trace": formatted_text_stack_trace,
        }
        crashes.append(crash_data)

    return crashes


def set_ime(ime: str = "com.netease.nie.yosemite/.ime.ImeService") -> None:
    """
    设置输入法

    :param ime: 输入法服务名称，默认为：com.netease.nie.yosemite/.ime.ImeService
    :return: None
    """
    shell(f"ime enable {ime}")
    shell(f"ime set {ime}")
