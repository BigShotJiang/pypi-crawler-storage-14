#!/usr/bin/python
"""
@Author  :  Lijiawei
@Date    :  2022/11/26 4:15 下午
@Desc    :  core line.
"""
import json
import os
import subprocess
from typing import Optional

from airtest.core.android.adb import ADB
from airtest.core.api import connect_device
from airtest.core.api import device
from airtest.core.api import stop_app
from airtest.core.assertions import assert_equal
from airtest.core.error import AdbShellError
from airtest.core.helper import log

from macaque.tools import log2list, set_ime

STATIC_PATH = os.path.dirname(os.path.realpath(__file__))
jar = os.path.join(STATIC_PATH, "jar")
libs = os.path.join(STATIC_PATH, "libs")


def prepare(
    udid: str,
    duration: int,
    package: str,
    throttle: int = 800,
    whitelist: Optional[str] = None,
    widget: Optional[str] = None,
    ime: bool = False,
) -> None:
    """
    准备并运行 macaque 稳定性测试

    :param udid: 设备 ID
    :param duration: 测试持续时间（分钟）
    :param package: 应用包名
    :param throttle: 事件频率（毫秒），默认 800
    :param whitelist: Activity 白名单，格式：com.example.app.MainActivity,com.test.app.StartActivity
    :param widget: 自定义屏蔽区域，格式：[{"bounds": "0.1,0.87,1,0.95"}]
    :param ime: 是否安装 ADB 键盘，默认 False
    :return: None
    """
    connect_device(
        f"Android:///{udid}?cap_method=MINICAP&&ori_method=MINICAPORI&&touch_method=MAXTOUCH"
    )

    if ime:
        try:
            set_ime()
        except Exception as e:
            log(arg=e, desc="设置 无界面IME 时出错")

    serialno = device().serialno
    adb = ADB(serialno=serialno)
    # 静音设置（媒体音量）
    # 音量流类型：0-通话音量，1-系统音量，2-铃声音量，3-媒体音量，4-闹钟音量，5-通知音量，6-蓝牙SCO
    log(arg="adb shell cmd media_session volume --stream 3 --set 0", desc="macaque setup")
    try:
        adb.shell("cmd media_session volume --stream 3 --set 0")
    except AdbShellError:
        pass
    # 推送 macaque 文件
    try:
        for j in os.listdir(jar):
            jar_file = os.path.join(jar, j)
            if os.path.isfile(jar_file):
                # 确保指定完整的目标路径，避免目录推送问题
                adb.push(jar_file, f"/sdcard/{j}")
    except (OSError, AdbShellError) as e:
        log(arg=e, desc="推送 jar 文件时出错")

    # 推送 libs 文件
    try:
        for lib_dir in os.listdir(libs):
            lib_path = os.path.join(libs, lib_dir)
            if os.path.isdir(lib_path):
                # 确保目标目录存在
                try:
                    adb.shell(f"mkdir -p /data/local/tmp/{lib_dir}")
                except AdbShellError:
                    pass
                # 推送目录下的所有文件（主要是 .so 文件）
                for file in os.listdir(lib_path):
                    file_path = os.path.join(lib_path, file)
                    if os.path.isfile(file_path):
                        # 确保指定完整的目标路径
                        adb.push(file_path, f"/data/local/tmp/{lib_dir}/{file}")
            elif os.path.isfile(lib_path):
                # 如果是单个文件，直接推送到目标位置
                adb.push(lib_path, f"/data/local/tmp/{lib_dir}")
    except (OSError, AdbShellError) as e:
        log(arg=e, desc="推送 libs 文件时出错")

    # bounds 边界设置
    if widget:
        log(arg=widget, desc="自定义 macaque 屏蔽区域")
        widget_file = os.path.join(STATIC_PATH, "max.widget.black")
        try:
            with open(file=widget_file, mode="w", encoding="utf-8") as f:
                widget_value = json.dumps([{"bounds": widget}])
                f.write(widget_value)
            # 推送 max.widget.black 到设备上
            adb.push(widget_file, "/sdcard/max.widget.black")
        except (IOError, OSError, AdbShellError) as e:
            log(arg=e, desc="创建或推送 widget 文件时出错")

    # --act-whitelist-file /sdcard/awl.strings
    if whitelist:
        log(arg=whitelist, desc="自定义 macaque 白名单")
        whitelist_file = os.path.join(STATIC_PATH, "awl.strings")
        try:
            with open(file=whitelist_file, mode="w", encoding="utf-8") as f:
                for white in str(whitelist).split(","):
                    f.write(f"{white}\n")
            # 推送 whitelist 到设备上
            adb.push(whitelist_file, "/sdcard/awl.strings")
            whitelist_flag = "--act-whitelist-file /sdcard/awl.strings"
        except (IOError, OSError, AdbShellError) as e:
            log(arg=e, desc="创建或推送 whitelist 文件时出错")
            whitelist_flag = ""
    else:
        whitelist_flag = ""

    # 构建 macaque 命令
    base_cmd = (
        f"CLASSPATH=/sdcard/macaque.jar:/sdcard/framework.jar:/sdcard/macaque-thirdpart.jar "
        f"exec app_process /system/bin com.android.commands.monkey.Monkey "
        f"-p {package} --agent reuseq --running-minutes {duration} "
        f"--throttle {throttle} -v -v"
    )
    if whitelist_flag:
        cmd = f"{base_cmd} {whitelist_flag} --bugreport"
    else:
        cmd = f"{base_cmd} --bugreport"

    log(arg=cmd, desc="macaque 命令")

    # 使用 subprocess 替代 os.system 以提高安全性
    adb_path = ADB.builtin_adb_path()
    subprocess.run([adb_path, "-s", udid, "shell", cmd], check=False)

    flag = 0
    oom = "/sdcard/oom-traces.log"
    crash = "/sdcard/crash-dump.log"
    
    # 检查 OOM 异常
    if adb.exists_file(oom):
        flag = 1
        try:
            adb.pull(oom, STATIC_PATH)
            oom_log_path = os.path.join(STATIC_PATH, "oom-traces.log")
            oom_log = log2list(oom_log_path)
            log(arg=oom_log, desc="存在 oom 异常")
            try:
                adb.shell(f"rm {oom}")
            except AdbShellError:
                pass
        except (AdbShellError, IOError) as e:
            log(arg=e, desc="处理 oom 日志时出错")
    else:
        log(arg=f"不存在异常：{oom}", desc="检查 oom 日志")

    # 检查 Crash 异常
    if adb.exists_file(crash):
        flag = 1
        try:
            adb.pull(crash, STATIC_PATH)
            crash_log_path = os.path.join(STATIC_PATH, "crash-dump.log")
            crash_log = log2list(crash_log_path)
            for c in crash_log:
                crash_time_data = c.get("crash_time", [])
                if crash_time_data:
                    crash_title = crash_time_data[0].get("line1", "未知崩溃")
                    log(arg=c, desc=f"crash: {crash_title}")
                else:
                    log(arg=c, desc="crash: 无法解析崩溃信息")
            try:
                adb.shell(f"rm {crash}")
            except AdbShellError:
                pass
        except (AdbShellError, IOError) as e:
            log(arg=e, desc="处理 crash 日志时出错")
    else:
        log(arg=f"不存在异常：{crash}", desc="检查 crash 日志")

    # teardown - 清理临时文件
    try:
        if ime:
            try:
                adb.shell("ime disable com.netease.nie.yosemite/.ime.ImeService")
            except AdbShellError:
                pass
        if whitelist:
            try:
                adb.shell("rm /sdcard/awl.strings")
            except AdbShellError:
                pass

        if widget:
            try:
                adb.shell("rm /sdcard/max.widget.black")
            except AdbShellError:
                pass

        log(arg="rm /sdcard/macaque*", desc="macaque teardown")
        stop_app(package)
    except Exception as e:
        log(arg=e, desc="清理资源时出错")

    if flag > 0:
        msg = "存在异常请检查 oom 或者 crash 日志"
    else:
        msg = "本次运行检测不存在异常"

    assert_equal(0, flag, msg)
