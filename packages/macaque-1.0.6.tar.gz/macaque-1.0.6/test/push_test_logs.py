#!/usr/bin/env python
"""
推送测试日志文件到手机
"""
import subprocess
import sys
import os


def get_adb_path():
    """获取 ADB 路径"""
    try:
        from airtest.core.android.adb import ADB
        return ADB.builtin_adb_path()
    except ImportError:
        # 如果无法导入，尝试使用系统 PATH 中的 adb
        return "adb"


def push_file(local_file: str, remote_path: str, udid: str = None) -> bool:
    """
    推送文件到手机
    
    :param local_file: 本地文件路径
    :param remote_path: 手机上的目标路径
    :param udid: 设备 ID（可选）
    :return: 是否成功
    """
    if not os.path.exists(local_file):
        print(f"错误：文件不存在 {local_file}")
        return False

    adb_path = get_adb_path()
    cmd = [adb_path]

    if udid:
        cmd.extend(["-s", udid])

    cmd.extend(["push", local_file, remote_path])

    print(f"执行命令: {' '.join(cmd)}")
    result = subprocess.run(cmd, capture_output=True, text=True)

    if result.returncode == 0:
        print(f"✓ 成功推送 {local_file} 到 {remote_path}")
        return True
    else:
        print(f"✗ 推送失败: {result.stderr}")
        return False


def main():
    """主函数"""
    # 获取设备 ID（如果有）
    udid = None
    if len(sys.argv) > 1:
        udid = sys.argv[1]
        print(f"使用设备: {udid}")

    # 获取当前目录
    script_dir = os.path.dirname(os.path.abspath(__file__))

    # 要推送的文件
    files_to_push = [
        ("test_oom-traces.log", "/sdcard/oom-traces.log"),
        ("test_crash-dump.log", "/sdcard/crash-dump.log"),
    ]

    print("开始推送测试日志文件...")
    print("-" * 50)

    success_count = 0
    for local_file, remote_path in files_to_push:
        local_path = os.path.join(script_dir, local_file)
        if push_file(local_path, remote_path, udid):
            success_count += 1
        print()

    print("-" * 50)
    print(f"完成！成功推送 {success_count}/{len(files_to_push)} 个文件")

    if success_count == len(files_to_push):
        print("\n测试文件已准备就绪，可以运行 macaque 进行验证。")
        return 0
    else:
        print("\n部分文件推送失败，请检查设备连接。")
        return 1


if __name__ == "__main__":
    sys.exit(main())
