#!/usr/bin/env python
"""
测试 log2list 函数解析日志文件
"""
import json
from macaque.tools import log2list


def test_log2list():
    """测试 log2list 函数"""
    test_files = [
        "test_oom-traces.log",
        "test_crash-dump.log",
    ]

    for test_file in test_files:
        print(f"\n{'=' * 60}")
        print(f"测试文件: {test_file}")
        print(f"{'=' * 60}")

        try:
            result = log2list(test_file)

            print(f"\n解析结果数量: {len(result)}")

            for i, crash_data in enumerate(result, 1):
                print(f"\n--- 崩溃 #{i} ---")
                print(f"崩溃时间信息:")
                crash_time = crash_data.get("crash_time", [])
                for time_item in crash_time:
                    for key, value in time_item.items():
                        print(f"  {key}: {value}")

                print(f"\n堆栈信息:")
                stack_trace = crash_data.get("stack_trace", [])
                for stack_item in stack_trace:
                    for key, value in stack_item.items():
                        print(f"  {key}: {value}")

                # 输出 JSON 格式
                print(f"\nJSON 格式:")
                print(json.dumps(crash_data, indent=2, ensure_ascii=False))

            if len(result) == 0:
                print("⚠️  警告：未解析到任何崩溃信息")
            else:
                print(f"\n✓ 成功解析 {len(result)} 条崩溃信息")

        except Exception as e:
            print(f"✗ 解析失败: {e}")
            import traceback
            traceback.print_exc()


if __name__ == "__main__":
    test_log2list()
