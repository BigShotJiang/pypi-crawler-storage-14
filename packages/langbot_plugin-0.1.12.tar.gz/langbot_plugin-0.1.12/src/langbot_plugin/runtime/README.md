# LangBot Plugin Runtime

与本仓库其他代码不同，Runtime 组件单独采用 AGPL 开源许可证授权，并遵循以下条款：

1. 若 Runtime 用于 LangBot 或 LangBot 组织下的其他项目，则适用相应项目的开源许可证。
2. LangBot 插件开发者所开发的插件，采用本仓库根目录下的 Apache 2.0 开源许可证授权。
3. 除上述情况外，使用 LangBot Runtime 时需遵循本目录下的 AGPL 开源许可证。
