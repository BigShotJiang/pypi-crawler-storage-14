====
Code
====

spelling.builder
================

.. automodule:: sphinxcontrib.spelling.builder
   :members:

spelling.checker
================

.. automodule:: sphinxcontrib.spelling.checker
   :members:

spelling.directive
==================

.. automodule:: sphinxcontrib.spelling.directive
   :members:

spelling.domain
================

.. automodule:: sphinxcontrib.spelling.domain
   :members:

spelling.filters
================

.. automodule:: sphinxcontrib.spelling.filters
   :members:

spelling.role
================

.. automodule:: sphinxcontrib.spelling.role
   :members:
