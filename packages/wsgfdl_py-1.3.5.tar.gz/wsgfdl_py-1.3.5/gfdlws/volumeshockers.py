import asyncio
import websockets
import json
import errno
import os

url = None
key = None
exg = None
dth = None
di= None
printed_once = False


def get(ws, exchange, Count,Series=None):
    if exchange == "":
        return "Exchange is mandatory."
    else:
        exg = exchange

    if Count == "":
        return "Count is mandatory."

    else:
        prd = Count 
    if Series == "":
        di = ''
    else:
        di = Series

    rmsg = asyncio.get_event_loop().run_until_complete(
        mass_subscribe_n_stream(ws, exg, prd, di))
    return rmsg


async def mass_subscribe_n_stream(ws, exg, prd, di):
    global printed_once
    try:
        req_msg = '{"MessageType":"GetVolumeShockers",'
        if exg is not None:
            req_msg = req_msg + '"Exchange":"' + exg + '"'
        if prd is not None:
            req_msg = req_msg + ',"Count":"' + str(prd) + '"'
        if di is not None:
            req_msg = req_msg + ',"Series":"' + di + '"'
        req_msg = str(req_msg + '}')
        if not printed_once:
            print("Request : " + req_msg)
            printed_once = True
        await ws.send(req_msg)
        rmsg = await get_msg(ws)
        return rmsg
    except:
        return 'In Exception...' + os.error


async def get_msg(ws):
    while True:
        try:
            message = await ws.recv()
            rslt = json.loads(message)
            if rslt["MessageType"] == 'LastRealtimeVolumeShockersResult':
                return message
        except websockets.ConnectionClosedOK:
            break
