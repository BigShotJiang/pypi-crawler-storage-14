import asyncio
import websockets
import json

url = None
key = None
exg = None
sym = None
msg = None
ity = None

exp = None
otp = None
srp = None
oa = None
dth =None
printed_once = False

def get(ws, exchange,product,periodictiy,period,Unsubscribe=None):
    exg = exchange
    sym = product
    exp= periodictiy
    srp = period
    
    rmsg = asyncio.get_event_loop().run_until_complete(mass_subscribe_n_stream(ws, exg, sym,exp,srp))
    return rmsg


def stop(ws, exchange, product, periodictiy,period,Unsubscribe=None):
    exg = exchange
    sym = product
    exp= periodictiy
    srp = period
    rmsg = asyncio.get_event_loop().run_until_complete(mass_unsubscribe_n_stream(ws, exg, sym,exp,srp))
    return rmsg


async def mass_subscribe_n_stream(ws, exg, sym,exp,srp):
    global  printed_once
    req_msg = str(
        '{"MessageType":"SubscribeSnapshotGreeks","Exchange":"' + exg + '","Unsubscribe":"false","Product":"' + sym + '","Periodicity":"' + exp + '","Period":"' + srp + '"}')
    await ws.send(req_msg)
    if not printed_once:
        print("Request : " + req_msg)
        printed_once = True
    rmsg = await get_msg(ws)
    return rmsg


async def mass_unsubscribe_n_stream(ws, exg, sym,exp,srp):
    global printed_once
    req_msg = str(
        '{"MessageType":"SubscribeSnapshotGreeks","Exchange":"' + exg + '","Unsubscribe":"true","Product":"' + sym + '","Periodicity":"' + exp + '","Period":"' + srp + '"}')
    if not printed_once:
        print("Request : " + req_msg)
        printed_once = True
    await ws.send(req_msg)
    rmsg = await get_msg(ws)
    return rmsg


async def get_msg(ws):
    while True:
        try:
            message = await ws.recv()
            rslt = json.loads(message)
            if rslt["MessageType"] == 'RealtimeSnapshotGreeksResult':
                return message
        except websockets.ConnectionClosedOK:
            break
