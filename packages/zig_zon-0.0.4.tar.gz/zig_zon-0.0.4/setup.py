from setuptools import Extension
from setuptools import setup
import sys
import os

# In this package the setuptools_zig_build cannot be imported as a dependency.
# on another package zig_build should be passed to setup()
sys.path.insert(0, os.path.normpath(os.path.join(__file__, '..')))  # nopep8
from setuptools_zig_build import ZigBuildExtension, ZigBuild  # nopep8

zig_build = ZigBuild(**{
    "use_ziglang_python_package": True,
    "optimize": "ReleaseSmall",  # passes -Doptimize= to zig build
    "pass_version_option": True,  # passes -Dversion=<pip package version> to zig build
    'test_step': 'test',  # this is failing on windows for now ;-/
    'extra_args': [],  # extra arguments to zig build
})

setup(
    name='zig-zon',
    packages=[],
    cmdclass={
        'build_ext': ZigBuildExtension(zig_build),
    },
    ext_modules=[Extension('zig_zon', [])],
    setup_requires=[],
)
