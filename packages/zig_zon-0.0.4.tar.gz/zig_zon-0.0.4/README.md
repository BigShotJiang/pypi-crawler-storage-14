# Python Zig Zon Parser

A native python extension built with zig to parse zig-object-notation strings
into python objects.

On PyPi it is only distributed in source, and built during install.
It therefore needs to download the `ziglang` python package.

# Usage

install:

```bash
python3 -m pip install zig-zon
```

running:

```python
import zig_zon
parsed = zig_zon.parse('.{.allyourcode = .are_belong_to_us, .asd = 123}')
print(parsed)
```

or, look at the [test](https://gitlab.com/dasimmet/python-zig-zon/-/blob/main/src/test_zig_zon.py)

# Developing

as opposed to other solutions, i want to develop using:

```
zig build test
```

so this command runs a python script that imports and uses the module
using the system `python` interpreter found in `PATH`. When the module is built using `pip`,
zig will get a `-Dpython=` option pointing to the right executable,
as well as a `-Dversion=` option for the pip package version.
