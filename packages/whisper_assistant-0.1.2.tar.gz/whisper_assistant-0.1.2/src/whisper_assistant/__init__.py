"""Whisper Assistant - Voice transcription tool using Groq API."""

__version__ = "0.1.2"
