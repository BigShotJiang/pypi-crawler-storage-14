# Tensorleap model parser
Used to parse model to the import format 
