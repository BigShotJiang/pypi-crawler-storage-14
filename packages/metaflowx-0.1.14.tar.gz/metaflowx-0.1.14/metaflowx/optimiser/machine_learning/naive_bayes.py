def naive_bayes():
    raise NotImplementedError("Naive Bayes coming soon… stay tuned.")