# Tests for CF Daemon
