"""
Context Foundry - Autonomous build orchestration system
"""

__version__ = "3.0.0"
