"""
Autonomous Evolution Mode
Maintains GitHub issue backlog by running Scout and creating issues
"""

from ..backlog_generator import BacklogGenerator

__all__ = ["BacklogGenerator"]
