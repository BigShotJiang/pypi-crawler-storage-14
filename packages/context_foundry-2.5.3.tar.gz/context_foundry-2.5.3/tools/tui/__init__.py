"""Context Foundry TUI Monitor"""

__version__ = "1.0.0"
