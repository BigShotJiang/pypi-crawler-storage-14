"""Reusable Skills Management for Context Foundry"""

from .manager import SkillsManager

__all__ = ["SkillsManager"]
