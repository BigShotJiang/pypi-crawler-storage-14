"""
Context Foundry Daemon TUI

A modern Terminal User Interface for managing CF Daemon builds with:
- Conversational build launcher (natural language interface)
- Real-time job monitoring dashboard
- Phase pipeline visualization
- Live log streaming
"""

__version__ = "1.0.0"
