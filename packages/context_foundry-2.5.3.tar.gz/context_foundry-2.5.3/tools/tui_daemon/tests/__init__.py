"""
Test suite for CF Daemon TUI

Test modules:
- test_daemon_client: DaemonClient SQLite integration tests
- test_conversation: NL parser tests
- test_log_streamer: Log polling tests
- test_job_submission: JobManager integration tests
- test_dashboard_updates: Auto-refresh tests
- test_conversation_flow: E2E conversation flow tests
"""
