ITL submodule
=============

```{eval-rst}
.. automodule:: majis.itl.reader
   :members:
   :no-index:
.. automodule:: majis.itl.export
   :members:
   :no-index:
.. automodule:: majis.itl.timeline
   :members:
   :no-index:
.. automodule:: majis.itl.eps.reader
   :members:
   :no-index:
.. automodule:: majis.itl.eps.export
   :members:
   :no-index:
.. automodule:: majis.itl.json.reader
   :members:
   :no-index:
.. automodule:: majis.itl.json.export
   :members:
   :no-index:
.. automodule:: majis.itl.json.schema
   :members:
   :no-index:
.. automodule:: majis.itl.csv.export
   :members:
   :no-index:
.. automodule:: majis.itl.cli
   :members:
   :no-index:
```
