"""Majis ITL in CSV format sub-module."""

from .export import save_csv

__all__ = [
    'save_csv',
]
