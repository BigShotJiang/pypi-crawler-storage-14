# agfapi

## Installation

`pip install agfapi`

Run `agfapi --help` from the command line.
