
from qckt.gatesutils.GatesUtils import stretched_opmatrix, combine_opmatrices_par, combine_opmatrices_seq, isunitary, opmat_dagger, CTL

