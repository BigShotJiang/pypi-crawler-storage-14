from .model import Scalar
from .repository import ScalarRepository
