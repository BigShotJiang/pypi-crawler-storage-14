from .model import Table
from .repository import TableRepository
