def test_import_package():
    import security_hyacinth
    assert hasattr(security_hyacinth, "__version__")

def test_cli_help(capsys):
    from security_hyacinth.cli import main
    import sys
    sys.argv = ["hyacinth"]
    try:
        main()
    except SystemExit:
        pass
    captured = capsys.readouterr()
    assert "usage" in captured.out.lower() or "usage" in captured.err.lower()

