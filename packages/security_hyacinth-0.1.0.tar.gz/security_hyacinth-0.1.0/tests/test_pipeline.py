from pathlib import Path
import json


def test_pipeline(tmp_path):
    xml = """
    <nmaprun>
      <host>
        <status state="up"/>
        <address addr="127.0.0.1"/>
        <ports>
          <port protocol="tcp" portid="80">
            <state state="open"/>
            <service name="http" product="nginx" version="1.20"/>
          </port>
        </ports>
      </host>
    </nmaprun>
    """.strip()

    allow = tmp_path / "allow.txt"
    allow.write_text("127.0.0.1\n", encoding="utf-8")

    from security_hyacinth.core.run import AuditContext, ingest_data, analyze_findings, generate_report
    ctx = AuditContext(str(allow), dry_run=True, log_file=None, config_path=None)

    raw = ingest_data(ctx, nmap_path=str(tmp_path / "nmap.xml"))
    (tmp_path / "nmap.xml").write_text(xml, encoding="utf-8")
    raw = ingest_data(ctx, nmap_path=str(tmp_path / "nmap.xml"))
    assert raw["assets"]

    analyzed = analyze_findings(ctx, raw, cve_feed_path=None)
    assert analyzed["risk"]
    md = generate_report(ctx, analyzed, fmt="md")
    html = generate_report(ctx, analyzed, fmt="html")
    assert "Hyacinth Report" in md
    assert "<html" in html

