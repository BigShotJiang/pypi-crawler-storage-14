from typing import List, Dict, Any


def cvss_guess(service: str | None, port: int | None) -> float:
    if service in {"ssh", "rdp"}:
        return 6.0
    if service in {"http", "https"}:
        return 7.0
    if port in {445, 139}:
        return 8.0
    if port in {21, 23}:
        return 7.5
    return 5.0


def map_risk(assets: List[Dict[str, Any]], cve_feed: Dict[str, Any]) -> List[Dict[str, Any]]:
    out: List[Dict[str, Any]] = []
    for a in assets:
        host = a.get("address")
        items = []
        for p in a.get("ports", []):
            sev = cvss_guess(p.get("service"), p.get("port"))
            items.append({
                "address": host,
                "port": p.get("port"),
                "service": p.get("service"),
                "severity": sev,
                "summary": "service exposure",
            })
        out.extend(items)
    out.sort(key=lambda x: x.get("severity", 0), reverse=True)
    return out

