from typing import List, Dict, Any


class Analyzer:
    def review(self, risk_items: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        reviewed = []
        for r in risk_items:
            sev = r.get("severity", 0)
            rec = "monitor"
            if sev >= 8.0:
                rec = "remediate immediately"
            elif sev >= 7.0:
                rec = "remediate soon"
            reviewed.append({
                "address": r.get("address"),
                "port": r.get("port"),
                "service": r.get("service"),
                "severity": sev,
                "recommendation": rec,
            })
        return reviewed

