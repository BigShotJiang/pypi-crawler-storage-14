from typing import Any, Dict
import importlib
import pkgutil


class BasePlugin:
    def process(self, data: Dict[str, Any]) -> Dict[str, Any]:
        return data


def load_plugins() -> list:
    plugins = []
    for _, name, ispkg in pkgutil.iter_modules(__path__):
        try:
            mod = importlib.import_module(f"security_hyacinth.plugins.{name}")
            if hasattr(mod, "Plugin"):
                plugins.append(mod.Plugin())
        except Exception:
            pass
    return plugins

