"""
Useful tools for OJM files.

Sources:

https://open2jam.wordpress.com/the-ojm-documentation

https://github.com/open2jamorg/open2jam/blob/master/tools/ojm_dumper/OJMDumper.java (Licensed under the Artistic License 2.0)

https://github.com/Estrol/O2Game/blob/master/Game/src/Data/OJM.cpp (Licensed under the MIT License)

This code uses other code that have the following licenses:

O2Game (MIT License):
https://github.com/Estrol/O2Game/blob/master/LICENSE

open2jam (Artistic License 2.0):
https://github.com/open2jamorg/open2jam/blob/master/LICENSE
"""

# this used to use the dataclasses package, but it just makes code cleaner and if it is removed then this uses zero packages
# it's crazy that the most complex script uses zero packages

ENCRYPTION_FLAGS = {"scramble1": 1, "scramble2": 2, "decode": 4, "decrypt": 8, "nami": 16, "0412": 32}

REARRANGE_TABLE = [
    0x10, 0x0E, 0x02, 0x09, 0x04, 0x00, 0x07, 0x01,
    0x06, 0x08, 0x0F, 0x0A, 0x05, 0x0C, 0x03, 0x0D,
    0x0B, 0x07, 0x02, 0x0A, 0x0B, 0x03, 0x05, 0x0D,
    0x08, 0x04, 0x00, 0x0C, 0x06, 0x0F, 0x0E, 0x10,
    0x01, 0x09, 0x0C, 0x0D, 0x03, 0x00, 0x06, 0x09,
    0x0A, 0x01, 0x07, 0x08, 0x10, 0x02, 0x0B, 0x0E,
    0x04, 0x0F, 0x05, 0x08, 0x03, 0x04, 0x0D, 0x06,
    0x05, 0x0B, 0x10, 0x02, 0x0C, 0x07, 0x09, 0x0A,
    0x0F, 0x0E, 0x00, 0x01, 0x0F, 0x02, 0x0C, 0x0D,
    0x00, 0x04, 0x01, 0x05, 0x07, 0x03, 0x09, 0x10,
    0x06, 0x0B, 0x0A, 0x08, 0x0E, 0x00, 0x04, 0x0B,
    0x10, 0x0F, 0x0D, 0x0C, 0x06, 0x05, 0x07, 0x01,
    0x02, 0x03, 0x08, 0x09, 0x0A, 0x0E, 0x03, 0x10,
    0x08, 0x07, 0x06, 0x09, 0x0E, 0x0D, 0x00, 0x0A,
    0x0B, 0x04, 0x05, 0x0C, 0x02, 0x01, 0x0F, 0x04,
    0x0E, 0x10, 0x0F, 0x05, 0x08, 0x07, 0x0B, 0x00,
    0x01, 0x06, 0x02, 0x0C, 0x09, 0x03, 0x0A, 0x0D,
    0x06, 0x0D, 0x0E, 0x07, 0x10, 0x0A, 0x0B, 0x00,
    0x01, 0x0C, 0x0F, 0x02, 0x03, 0x08, 0x09, 0x04,
    0x05, 0x0A, 0x0C, 0x00, 0x08, 0x09, 0x0D, 0x03,
    0x04, 0x05, 0x10, 0x0E, 0x0F, 0x01, 0x02, 0x0B,
    0x06, 0x07, 0x05, 0x06, 0x0C, 0x04, 0x0D, 0x0F,
    0x07, 0x0E, 0x08, 0x01, 0x09, 0x02, 0x10, 0x0A,
    0x0B, 0x00, 0x03, 0x0B, 0x0F, 0x04, 0x0E, 0x03,
    0x01, 0x00, 0x02, 0x0D, 0x0C, 0x06, 0x07, 0x05,
    0x10, 0x09, 0x08, 0x0A, 0x03, 0x02, 0x01, 0x00,
    0x04, 0x0C, 0x0D, 0x0B, 0x10, 0x05, 0x06, 0x0F,
    0x0E, 0x07, 0x09, 0x0A, 0x08, 0x09, 0x0A, 0x00,
    0x07, 0x08, 0x06, 0x10, 0x03, 0x04, 0x01, 0x02,
    0x05, 0x0B, 0x0E, 0x0F, 0x0D, 0x0C, 0x0A, 0x06,
    0x09, 0x0C, 0x0B, 0x10, 0x07, 0x08, 0x00, 0x0F,
    0x03, 0x01, 0x02, 0x05, 0x0D, 0x0E, 0x04, 0x0D,
    0x00, 0x01, 0x0E, 0x02, 0x03, 0x08, 0x0B, 0x07,
    0x0C, 0x09, 0x05, 0x0A, 0x0F, 0x04, 0x06, 0x10,
    0x01, 0x0E, 0x02, 0x03, 0x0D, 0x0B, 0x07, 0x00,
    0x08, 0x0C, 0x09, 0x06, 0x0F, 0x10, 0x05, 0x0A,
    0x04, 0x00
]

MASK_NAMI = b'\x6E\x61\x6D\x69'
MASK_0412 = b'\x30\x34\x31\x32'


class OMCHeader:
    """
    The OMCHeader class.

    Source: https://open2jam.wordpress.com/the-ojm-documentation

    Attributes:
        signature (bytes): File signature.
        wav_count (int): Amount of wav samples.
        ogg_count (int): Amount of ogg samples.
        wav_start (int): Offset of wav samples.
        ogg_start (int): Offset of ogg samples.
        file_size (int): Size of the file.
    """

    def __init__(self, signature: bytes, wav_count: int, ogg_count: int, wav_start: int, ogg_start: int,
                 file_size: int):
        self.signature = signature
        self.wav_count = wav_count
        self.ogg_count = ogg_count
        self.wav_start = wav_start
        self.ogg_start = ogg_start
        self.file_size = file_size

    def __repr__(self):
        attrs = ', '.join(f'{key}={value!r}' for key, value in vars(self).items())
        return f'{self.__class__.__name__}({attrs})'

    def __eq__(self, other):
        return vars(self) == vars(other) and isinstance(other, self.__class__)


class OMCSampleWav:
    """
    The OMCSampleWav class.

    Source: https://open2jam.wordpress.com/the-ojm-documentation

    Attributes:
        sample_name (bytes): Name of the sample.
        audio_format (int): Format of the wav audio.
        channels_count (int): Amount of channels in the wav.
        sample_rate (int): Sample rate of the wav.
        block_align (int): Block align of the wav.
        bits_per_sample (int): Bits per sample of the wav.
        unk_data (int): Unknown data.
        chunk_size (int): Size of the raw wav data.
        wav_data (bytes): The raw wav data (without header)
        final_wav (bytes): The raw wav data (with header)
    """

    def __init__(self, sample_name: bytes, audio_format: int, channels_count: int, sample_rate: int, bit_rate: int,
                 block_align: int, bits_per_sample: int, unk_data: int, chunk_size: int, wav_data: bytes,
                 final_wav: bytes):
        self.sample_name = sample_name
        self.audio_format = audio_format
        self.channels_count = channels_count
        self.sample_rate = sample_rate
        self.bit_rate = bit_rate
        self.block_align = block_align
        self.bits_per_sample = bits_per_sample
        self.unk_data = unk_data
        self.chunk_size = chunk_size
        self.wav_data = wav_data
        self.final_wav = final_wav

    def __repr__(self):
        attrs = ', '.join(f'{key}={value!r}' for key, value in vars(self).items())
        return f'{self.__class__.__name__}({attrs})'

    def __eq__(self, other):
        return vars(self) == vars(other) and isinstance(other, self.__class__)


class OMCSampleOGG:
    """
    The OMCSampleOGG class.

    Source: https://open2jam.wordpress.com/the-ojm-documentation

    Attributes:
        sample_name (bytes): Name of the sample.
        sample_size (int): The size (in bytes) of the sample.
        sample_data (bytes): The raw OGG data of the sample.
    """

    def __init__(self, sample_name: bytes, sample_size: int, sample_data: bytes):
        self.sample_name = sample_name
        self.sample_size = sample_size
        self.sample_data = sample_data

    def __repr__(self):
        attrs = ', '.join(f'{key}={value!r}' for key, value in vars(self).items())
        return f'{self.__class__.__name__}({attrs})'

    def __eq__(self, other):
        return vars(self) == vars(other) and isinstance(other, self.__class__)


class M30Header:
    """
    The M30Header class.

    Sources:

    https://open2jam.wordpress.com/the-ojm-documentation

    https://github.com/Estrol/O2Game/blob/master/Game/src/Data/OJM.cpp (Licensed under the MIT license)

    Attributes:
        signature (bytes): File signature.
        file_format_version (int): Version of the OJM.
        encryption_flag (int):
            1: scramble1,
            2: scramble2,
            4: decode,
            8: decrypt,
            16: nami,
            32: 0412
        sample_count (int): Amount of samples on the OJM file.
        samples_offset (int): Offset that the samples begin at.
        payload_size (int): Size of the file (without header)
        padding (int): Padding(?)
    """

    def __init__(self, signature: bytes, file_format_version: int, encryption_flag: int, sample_count: int,
                 samples_offset: int, payload_size: int, padding: int):
        self.signature = signature
        self.file_format_version = file_format_version
        self.encryption_flag = encryption_flag
        self.sample_count = sample_count
        self.samples_offset = samples_offset
        self.payload_size = payload_size
        self.padding = padding

    def __repr__(self):
        attrs = ', '.join(f'{key}={value!r}' for key, value in vars(self).items())
        return f'{self.__class__.__name__}({attrs})'

    def __eq__(self, other):
        return vars(self) == vars(other) and isinstance(other, self.__class__)


class M30Sample:
    """
    The M30Sample class.

    Source: https://open2jam.wordpress.com/the-ojm-documentation

    Attributes:
        sample_name (bytes): Name of the sample.
        sample_size (int): Size of the sample.
        codec_code (int): either 0 (background sound, note type 4, M###), or 5 (normal sound, W###).
        unk_fixed (int): Unknown data.
        unk_music_flag (int): Unknown data. Possibly a music flag.
        ref (int): The corresponding number on the OJN.
        unk_zero (int): Unknown data.
        pcm_samples (int): The amount of PCM samples on the ogg.
        sample (bytes): The full ogg sample.
    """

    def __init__(self, sample_name: bytes, sample_size: int, codec_code: int, unk_fixed: int, unk_music_flag: int,
                 ref: int, unk_zero: int, pcm_samples: int, sample: bytes):
        self.sample_name = sample_name
        self.sample_size = sample_size
        self.codec_code = codec_code
        self.unk_fixed = unk_fixed
        self.unk_music_flag = unk_music_flag
        self.ref = ref
        self.unk_zero = unk_zero
        self.pcm_samples = pcm_samples
        self.sample = sample

    def __repr__(self):
        attrs = ', '.join(f'{key}={value!r}' for key, value in vars(self).items())
        return f'{self.__class__.__name__}({attrs})'

    def __eq__(self, other):
        return vars(self) == vars(other) and isinstance(other, self.__class__)


# Stupid (XOR) encryption.
def acc_xor(data: bytes, acc_key_byte: int, acc_counter: int) -> list:
    """
    Decrypts bytes using acc_xor (but it's stupid so it's not actually xor)

    Usually found in the OMC/OJM file type.

    Sources:

    https://github.com/open2jamorg/open2jam/blob/master/tools/ojm_dumper/OJMDumper.java (Licensed under the Artistic License 2.0)

    https://github.com/Estrol/O2Game/blob/master/Game/src/Data/OJM.cpp (Licensed under the MIT license)

    :argument: A bytes object with the encrypted data.

    :return: A list object that contains the new acc_key_byte, the new acc_counter, and the unencrypted data.
    :rtype: list
    """

    result = bytearray(len(data))

    for i, b in enumerate(data):
        this_char = b

        if ((acc_key_byte << acc_counter) & 0x80) != 0:
            this_char = ~this_char & 0xFF

        result[i] = this_char
        acc_counter += 1

        if acc_counter > 7:
            acc_counter = 0
            acc_key_byte = b

    return [acc_key_byte, acc_counter, bytes(result)]


# (kind of) Stupid arrangement encryption.
def rearrange(data: bytes) -> bytes:
    """
    Rearranges data based on certain logic.

    Usually found in the OMC/OJM file type.

    Sources:

    https://github.com/open2jamorg/open2jam/blob/master/tools/ojm_dumper/OJMDumper.java (Licensed under the Artistic License 2.0)

    https://github.com/Estrol/O2Game/blob/master/Game/src/Data/OJM.cpp (Licensed under the MIT license)

    :argument: A bytes object with the arranged data.

    :return: A bytes object that has the rearranged data.
    :rtype: bytes
    """

    length = len(data)
    key = (length % 17) * 17
    block_size = length // 17

    res = bytearray(length)

    for i in range(17):
        in_offset = block_size * i
        out_index = REARRANGE_TABLE[key]
        out_offset = block_size * out_index

        res[out_offset:out_offset + block_size] = data[in_offset:in_offset + block_size]

        key += 1

    return bytes(res)


def xor_decrypt(data: bytes, xor: bytes) -> bytes:
    """
    XORs data based on a 4 byte key.

    Usually found in the M30 file type.

    Source: https://open2jam.wordpress.com/the-ojm-documentation (modified so you can use any key)

    :argument: A bytes object with the encrypted data.

    :return: A bytes object that has the unencrypted data.
    :rtype: bytes
    """

    result = bytearray(data)

    for i in range(0, len(result) - 3, 4):
        result[i + 0] ^= int(xor[0])
        result[i + 1] ^= int(xor[1])
        result[i + 2] ^= int(xor[2])
        result[i + 3] ^= int(xor[3])

    return bytes(result)


class OJM:
    """
    The OJM file class.

    Sources:

    https://github.com/open2jamorg/open2jam/blob/master/tools/ojm_dumper/OJMDumper.java (Licensed under the Artistic License 2.0)

    https://github.com/Estrol/O2Game/blob/master/Game/src/Data/OJM.cpp (Licensed under the MIT license)

    https://open2jam.wordpress.com/the-ojm-documentation

    Attributes:
        ojm_file (bytes): Raw bytes of the OJM file.
        header (either M30Header or OMCHeader): Parsed header of the OJM file.
        samples (list): All the samples in the OJM file put together in a list in either the M30Sample or OMCSample format.

    Arguments:
        ojm_file (bytes): Raw bytes of the OJM file.
    """

    def get_m30_header(self) -> M30Header:
        """
        NOTE: If you are trying to get the header using this, please use OJM.header.

        This is only for the M30 type of OJM file! If the file is an OMC/OJM type, this will not work.

        Gets the M30 header of the OJM file.

        Source: https://open2jam.wordpress.com/the-ojm-documentation

        :return: A M30Header object that has the header.
        :rtype: M30Header
        """

        signature = self.ojm_file[0:4]
        file_format_version = int.from_bytes(self.ojm_file[4:8], "little")
        encryption_flag = int.from_bytes(self.ojm_file[8:12], "little")
        sample_count = int.from_bytes(self.ojm_file[12:16], "little")
        samples_offset = int.from_bytes(self.ojm_file[16:20], "little")
        payload_size = int.from_bytes(self.ojm_file[20:24], "little")
        padding = int.from_bytes(self.ojm_file[24:28], "little")

        return M30Header(signature, file_format_version, encryption_flag, sample_count, samples_offset, payload_size,
                         padding)

    def get_omc_header(self) -> OMCHeader:
        """
        NOTE: If you are trying to get the header using this, please use OJM.header.

        This is only for the OMC/OJM type of OJM file! If the file is an M30 type, this will not work.

        Gets the OMC/OJM header of the OJM file.

        Source: https://open2jam.wordpress.com/the-ojm-documentation

        :return: An OMCHeader object that has the header.
        :rtype: OMCHeader
        """

        signature = self.ojm_file[0:4]
        wav_count = int.from_bytes(self.ojm_file[4:6], "little")
        ogg_count = int.from_bytes(self.ojm_file[6:8], "little")
        wav_start = int.from_bytes(self.ojm_file[8:12], "little")
        ogg_start = int.from_bytes(self.ojm_file[12:16], "little")
        file_size = int.from_bytes(self.ojm_file[16:20], "little")

        return OMCHeader(signature, wav_count, ogg_count, wav_start, ogg_start, file_size)

    def get_header(self):
        """
        NOTE: If you are trying to get the header using this, please use OJM.header.

        Gets the header of the OJM file.

        Source: https://open2jam.wordpress.com/the-ojm-documentation

        :return: Either a M30Header object or an OMCHeader object that has the header. Can also return None if the signature is invalid.
        :rtype: M30Header/OMCHeader/None
        """

        if self.ojm_file[0:4] == b'M30\x00':
            return self.get_m30_header()
        elif self.ojm_file[0:4] == b'OMC\x00':
            return self.get_omc_header()
        else:
            return None

    def extract_m30_samples(self) -> list:
        """
        NOTE: If you are trying to get the samples using this, please use OJM.samples.

        Gets the samples of the M30 OJM file.

        Sources:

        https://open2jam.wordpress.com/the-ojm-documentation

        https://github.com/Estrol/O2Game/blob/master/Game/src/Data/OJM.cpp (Licensed under the MIT license)

        :return: A list with all the samples in the form of M30Sample objects.
        :rtype: list
        """

        current_pos = self.header.samples_offset
        data = []

        for i in range(self.header.sample_count):
            # Get header data.
            sample_name = self.ojm_file[current_pos:current_pos + 32]
            sample_size = int.from_bytes(self.ojm_file[current_pos + 32:current_pos + 36], "little")
            codec_code = int.from_bytes(self.ojm_file[current_pos + 36:current_pos + 38], "little")
            unk_fixed = int.from_bytes(self.ojm_file[current_pos + 38:current_pos + 40], "little")
            unk_music_flag = int.from_bytes(self.ojm_file[current_pos + 40:current_pos + 44], "little")
            ref = int.from_bytes(self.ojm_file[current_pos + 44:current_pos + 46], "little")
            unk_zero = int.from_bytes(self.ojm_file[current_pos + 46:current_pos + 48], "little")
            pcm_samples = int.from_bytes(self.ojm_file[current_pos + 48:current_pos + 52], "little")
            sample = b''

            current_pos += 52  # Start at the audio data.

            # Set the sample variable to the full encrypted audio data.
            sample += self.ojm_file[current_pos:current_pos + ((sample_size // 4) * 4)]
            current_pos += round((sample_size // 4) * 4)

            # Decrypt data based on the encryption flag.
            if self.header.encryption_flag == 16:
                sample = xor_decrypt(sample, MASK_NAMI)
            elif self.header.encryption_flag == 32:
                sample = xor_decrypt(sample, MASK_0412)

            # If the sample size is not easily dividable by 4, leave the rest of the bytes unencrypted.
            if sample_size % 4 != 0:
                sample += self.ojm_file[current_pos:current_pos + sample_size % 4]
                current_pos += sample_size % 4

            # Assemble the M30Sample.
            data.append(M30Sample(sample_name, sample_size, codec_code, unk_fixed, unk_music_flag, ref,
                                  unk_zero, pcm_samples, sample))

        data.sort(key=lambda s: s.ref)  # Sort the samples by their ref value.
        return data

    def extract_omc_samples(self) -> list:
        """
        NOTE: If you are trying to get the samples using this, please use OJM.samples.

        Gets the samples of the OJM file. (OMC/OJM)

        Uses a stupid encryption and stupid arrangement logic, but I implemented it so you don't have to worry about it. You're welcome.

        Sources:

        https://open2jam.wordpress.com/the-ojm-documentation

        https://github.com/Estrol/O2Game/blob/master/Game/src/Data/OJM.cpp (Licensed under the MIT license)

        https://github.com/open2jamorg/open2jam/blob/master/tools/ojm_dumper/OJMDumper.java (Licensed under the Artistic License 2.0)

        :return: A list with all the samples in the form of OMCSampleWAV or OMCSampleOGG.
        :rtype: list
        """

        current_pos = self.header.wav_start

        data = []

        acc_key_byte = 0xFF
        acc_counter = 0

        wav_data = b''
        final_wav = b''

        for i in range(self.header.wav_count):
            # Get header data.
            sample_name = self.ojm_file[current_pos:current_pos + 32]
            audio_format = int.from_bytes(self.ojm_file[current_pos + 32:current_pos + 34], "little")
            channels_count = int.from_bytes(self.ojm_file[current_pos + 34:current_pos + 36], "little")
            sample_rate = int.from_bytes(self.ojm_file[current_pos + 36:current_pos + 40], "little")
            bit_rate = int.from_bytes(self.ojm_file[current_pos + 40:current_pos + 44], "little")
            block_align = int.from_bytes(self.ojm_file[current_pos + 44:current_pos + 46], "little")
            bits_per_sample = int.from_bytes(self.ojm_file[current_pos + 46:current_pos + 48], "little")
            unk_data = int.from_bytes(self.ojm_file[current_pos + 48:current_pos + 52], "little")
            chunk_size = int.from_bytes(self.ojm_file[current_pos + 52:current_pos + 56], "little")

            current_pos += 56  # Go to the audio data.

            if chunk_size != 0:  # Only unencrypt the audio data if it exists.
                wav_data = self.ojm_file[current_pos:current_pos + chunk_size]

                # Beginning of stupid.
                wav_data = rearrange(wav_data)  # Stupid rearrangement.
                decrypted_data = acc_xor(wav_data, acc_key_byte, acc_counter)  # Stupid decryption.

                acc_key_byte = decrypted_data[0]
                acc_counter = decrypted_data[1]
                wav_data = decrypted_data[2]
                # Ending of stupid.

                # Assemble the final wav file.
                final_wav = bytearray(b'RIFF')
                final_wav.extend((chunk_size + 36).to_bytes(4, 'little'))
                final_wav.extend(b'WAVEfmt \x10\x00\x00\x00')

                final_wav.extend(audio_format.to_bytes(2, 'little'))
                final_wav.extend(channels_count.to_bytes(2, 'little'))
                final_wav.extend(sample_rate.to_bytes(4, 'little'))
                final_wav.extend(bit_rate.to_bytes(4, 'little'))
                final_wav.extend(block_align.to_bytes(2, 'little'))
                final_wav.extend(bits_per_sample.to_bytes(2, 'little'))
                final_wav.extend(b'data')
                final_wav.extend(chunk_size.to_bytes(4, 'little'))
                final_wav.extend(wav_data)

            # Append the OMCSampleWav to the list.
            data.append(OMCSampleWav(sample_name, audio_format, channels_count, sample_rate, bit_rate, block_align,
                                     bits_per_sample,
                                     unk_data, chunk_size, wav_data, final_wav))

            current_pos += chunk_size  # Go to the next sample.

        for i in range(self.header.ogg_count):
            # Get header data.
            sample_name = self.ojm_file[current_pos:current_pos + 32]
            sample_size = int.from_bytes(self.ojm_file[current_pos + 32:current_pos + 36], 'little')
            sample_data = self.ojm_file[current_pos + 36:current_pos + 36 + sample_size]

            data.append(OMCSampleOGG(sample_name, sample_size, sample_data))  # Append the OMCSampleOGG to the list.

        return data

    def extract_samples(self) -> list:
        """
        NOTE: If you are trying to get the samples using this, please use OJM.samples.

        Gets the samples of the OJM file. (OMC/OJM/M30)

        Sources:

        https://open2jam.wordpress.com/the-ojm-documentation

        https://github.com/Estrol/O2Game/blob/master/Game/src/Data/OJM.cpp (Licensed under the MIT license)

        https://github.com/open2jamorg/open2jam/blob/master/tools/ojm_dumper/OJMDumper.java (Licensed under the Artistic License 2.0)

        :return: A list with all the samples in the form of either OMCSampleWav, OMCSampleOGG, or M30Sample. Can also return an empty list if the signature is invalid.
        :rtype: list
        """

        if self.ojm_file[0:4] == b'M30\x00':
            return self.extract_m30_samples()
        elif self.ojm_file[0:4] == b'OMC\x00':
            return self.extract_omc_samples()
        else:
            return []

    def __init__(self, ojm_file: bytes):
        self.ojm_file = ojm_file
        self.header = self.get_header()
        self.samples = self.extract_samples()


def make_m30_file(file_path: str, header: M30Header, samples: list) -> OJM:
    """
    Assembles an OJM file of the M30 type from a M30Header, and a list containing the samples in the format of M30Sample.

    :arg: file_path (str): The path to the file that the function will create.
    :arg: header (M30Header): The header in the form of an M30Header object.
    :arg: samples (list): A list containing all the samples, each sample in the M30Sample format.

    :return: An OJM object that contains the file that was just created.
    :rtype: OJM
    """

    with open(file_path, "wb") as f:
        f.write(header.signature)
        f.write(header.file_format_version.to_bytes(length=4, byteorder='little'))
        f.write(header.encryption_flag.to_bytes(length=4, byteorder='little'))
        f.write(header.sample_count.to_bytes(length=4, byteorder='little'))
        f.write(header.samples_offset.to_bytes(length=4, byteorder='little'))
        f.write(header.payload_size.to_bytes(length=4, byteorder='little'))
        f.write(header.padding.to_bytes(length=4, byteorder='little'))

        for sample in samples:
            f.write(sample.sample_name)
            f.write(sample.sample_size.to_bytes(length=4, byteorder='little'))
            f.write(sample.codec_code.to_bytes(length=2, byteorder='little'))
            f.write(sample.unk_fixed.to_bytes(length=2, byteorder='little'))
            f.write(sample.unk_music_flag.to_bytes(length=4, byteorder='little'))
            f.write(sample.ref.to_bytes(length=2, byteorder='little'))
            f.write(sample.unk_zero.to_bytes(length=2, byteorder='little'))
            f.write(sample.pcm_samples.to_bytes(length=4, byteorder='little'))

            if header.encryption_flag == 16:
                f.write(xor_decrypt(sample.sample[0:(sample.sample_size // 4) * 4], MASK_NAMI))
            elif header.encryption_flag == 32:
                f.write(xor_decrypt(sample.sample[0:(sample.sample_size // 4) * 4], MASK_0412))

            if sample.sample_size % 4 != 0:
                f.write(sample.sample[
                        (sample.sample_size // 4) * 4:((sample.sample_size // 4) * 4) + (sample.sample_size % 4)])

    with open(file_path, "rb") as rf:
        return OJM(rf.read())

def make_file(file_path: str, header, samples: list):
    """
    Assembles an OJM file form a header, and a list containing the samples.

    :arg: file_path (str): The path to the file that the function will create.
    :arg: header: The header of the OJM
    :arg: samples (list): A list containing all the samples, each sample in the M30Sample format.

    :return: An OJM object that contains the file that was just created.
    :rtype: OJM
    """

    if header.signature == b'M30\x00':
        return make_m30_file(file_path, header, samples)
    else:
        raise NotImplementedError