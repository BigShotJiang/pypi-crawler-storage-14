"""
This is not 100% finished! There are dates and some unknown bytes at the end of only some OJN list files that seem to be completely ignored.

If you know how the data for OJN List files are handled, you can contribute at https://github.com/SweepSweep2/o2tools

Useful tools for OJN List files.
"""

from o2tools import ojn
import struct

class OjnListHeader:
    """
    The OjnListHeader class.

    Attributes:
        ojn_count (int): Amount of OJNs in the OJN list.
    """

    def __init__(self, ojn_count):
        self.ojn_count = ojn_count

    def __repr__(self):
        attrs = ', '.join(f'{key}={value!r}' for key, value in vars(self).items())
        return f'{self.__class__.__name__}({attrs})'

    def __eq__(self, other):
        return vars(self) == vars(other) and isinstance(other, self.__class__)

class OJNList:
    """
    The OJN List file class.

    Attributes:
        ojn_list_file (bytes): Raw bytes of the OJN List file.
        header (OjnListHeader): Parsed header of the OJN List file.
        ojns (list): All the OJN headers in the OJN List file, stored as OjnHeaders (o2tools.ojn.OjnHeader).

    Arguments:
        ojn_list_file (bytes): Raw bytes of the OJN List file.
    """

    def get_header(self) -> OjnListHeader:
        """
        NOTE: If you are trying to get the header using this, please use OJNList.header.

        Parses the header of the OJN List file and returns an OjnListHeader object.

        :return: An OjnListHeader object that has all the information from the header.
        :rtype: OjnListHeader
        """

        return OjnListHeader(int.from_bytes(self.ojn_list_file[0:4], 'little')) # 1 line Goog...

    def get_ojns(self) -> list:
        """
        NOTE: If you are trying to get the OJNs using this, please use OJNList.ojns.

        Gets all the OJN headers in the file and stores them as OjnHeaders (o2tools.ojn.OjnHeader) inside a list.

        :return: A list that has all the headers in the OjnHeader format.
        :rtype: list
        """

        data = []
        current_pos = 4

        for i in range(self.header.ojn_count):
            data.append(ojn.get_header(self.ojn_list_file[current_pos:current_pos + 300]))
            current_pos += 300

        return data

    def __init__(self, ojn_list_file: bytes):
        self.ojn_list_file = ojn_list_file
        self.header = self.get_header()
        self.ojns = self.get_ojns()

def make_file(file_path: str, header: OjnListHeader, ojns: list) -> OJNList:
    """
    Some OJN Lists have dates at the end of them, which O2Tools currently does not support. That means the OJN Lists generated might not work in some versions of O2Jam.

    Assembles an OJN List file based off of an OjnListHeader object, and a list containing all the OJN headers in the form of an OjnHeader object (o2tools.ojn.OjnHeader).

    :return: The OJN List file in the form of the OJNList class.
    :rtype: OJNList
    """

    with open(file_path, "wb") as f:
        # Write the header to the file
        f.write(header.ojn_count.to_bytes(length=4, byteorder='little'))

        for ojn_header in ojns:
            f.write(ojn_header.song_id.to_bytes(length=4, byteorder='little'))
            f.write(ojn_header.signature)
            f.write(struct.pack("<f", ojn_header.encode_version))
            f.write(ojn_header.genre.to_bytes(length=4, byteorder='little'))
            f.write(struct.pack("<f", ojn_header.bpm))
            f.write(ojn_header.easy_level.to_bytes(length=2, byteorder='little'))
            f.write(ojn_header.normal_level.to_bytes(length=2, byteorder='little'))
            f.write(ojn_header.hard_level.to_bytes(length=2, byteorder='little'))
            f.write(b'\x00\x00')
            f.write(ojn_header.easy_event_count.to_bytes(length=4, byteorder='little'))
            f.write(ojn_header.normal_event_count.to_bytes(length=4, byteorder='little'))
            f.write(ojn_header.hard_event_count.to_bytes(length=4, byteorder='little'))
            f.write(ojn_header.easy_note_count.to_bytes(length=4, byteorder='little'))
            f.write(ojn_header.normal_note_count.to_bytes(length=4, byteorder='little'))
            f.write(ojn_header.hard_note_count.to_bytes(length=4, byteorder='little'))
            f.write(ojn_header.easy_measure_count.to_bytes(length=4, byteorder='little'))
            f.write(ojn_header.normal_measure_count.to_bytes(length=4, byteorder='little'))
            f.write(ojn_header.hard_measure_count.to_bytes(length=4, byteorder='little'))
            f.write(ojn_header.easy_package_count.to_bytes(length=4, byteorder='little'))
            f.write(ojn_header.normal_package_count.to_bytes(length=4, byteorder='little'))
            f.write(ojn_header.hard_package_count.to_bytes(length=4, byteorder='little'))
            f.write(ojn_header.old_encode_version.to_bytes(length=2, byteorder='little'))
            f.write(ojn_header.old_song_id.to_bytes(length=2, byteorder='little'))
            f.write(ojn_header.old_genre)
            f.write(ojn_header.bmp_size.to_bytes(length=4, byteorder='little'))
            f.write(ojn_header.old_file_version.to_bytes(length=4, byteorder='little'))
            f.write(ojn_header.title)
            f.write(ojn_header.artist)
            f.write(ojn_header.noter)
            f.write(ojn_header.ojm_file)
            f.write(ojn_header.cover_size.to_bytes(length=4, byteorder='little'))
            f.write(ojn_header.easy_time.to_bytes(length=4, byteorder='little'))
            f.write(ojn_header.normal_time.to_bytes(length=4, byteorder='little'))
            f.write(ojn_header.hard_time.to_bytes(length=4, byteorder='little'))
            f.write(ojn_header.easy_note_offset.to_bytes(length=4, byteorder='little'))
            f.write(ojn_header.normal_note_offset.to_bytes(length=4, byteorder='little'))
            f.write(ojn_header.hard_note_offset.to_bytes(length=4, byteorder='little'))
            f.write(ojn_header.cover_offset.to_bytes(length=4, byteorder='little'))

    with open(file_path, "rb") as rf:
        return OJNList(rf.read())
