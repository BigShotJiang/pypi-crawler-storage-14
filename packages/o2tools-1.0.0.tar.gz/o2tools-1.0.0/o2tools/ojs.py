"""
Useful tools for OJS files.

Sources:

https://github.com/Estrol/X3Solo/blob/master/Estrol.X3Solo/Parser/Data/OJSData.cs (licensed under the MIT License)

https://github.com/Estrol/X3Solo/blob/master/Estrol.X3Solo/Parser/Data/OJSFrame.cs (licensed under the MIT License)

This code uses other code that have the following licenses:

X3Solo (MIT License): https://github.com/Estrol/X3Solo/blob/master/LICENSE.txt
"""


class OjsHeader:
    """
    The OjsHeader class.

    Source: https://github.com/Estrol/X3Solo/blob/master/Estrol.X3Solo/Parser/Data/OJSData.cs (licensed under the MIT License)

    Attributes:
        file_format (int): Type of file.
        color_format (int): The color format of the OJS (in big endian).
        frame_count (int): The amount of frames in the OJS.
    """

    def __init__(self, file_format: int, color_format: int, frame_count: int):
        self.file_format = file_format
        self.color_format = color_format
        self.frame_count = frame_count

    def __repr__(self):
        attrs = ', '.join(f'{key}={value!r}' for key, value in vars(self).items())
        return f'{self.__class__.__name__}({attrs})'

    def __eq__(self, other):
        return vars(self) == vars(other) and isinstance(other, self.__class__)


class OjsFrame:
    """
    The OjsFrame class.

    Source: https://github.com/Estrol/X3Solo/blob/master/Estrol.X3Solo/Parser/Data/OJSFrame.cs (licensed under the MIT License)

    Attributes:
        transparent_color (int): The transparent color of the frame in the format BGR555.
        x (int): X position of the frame.
        y (int): Y position of the frame.
        width (int): Width of the frame.
        height (int): Height of the frame.
        offset (int): Offset of the frame.
        size (int): Size of the frame.
        unk (int): Unknown data.
        data (bytes): Data of the frame.
        bmp_file (bytes): BMP file.
    """

    def __init__(self, transparent_color: int, x: int, y: int, width: int, height: int, offset: int, size: int,
                 unk: int, data: bytes, bmp_file: bytes):
        self.transparent_color = transparent_color
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        self.offset = offset
        self.size = size
        self.unk = unk
        self.data = data
        self.bmp_file = bmp_file

    def __repr__(self):
        attrs = ', '.join(f'{key}={value!r}' for key, value in vars(self).items())
        return f'{self.__class__.__name__}({attrs})'

    def __eq__(self, other):
        return vars(self) == vars(other) and isinstance(other, self.__class__)


class OJS:
    """
    The OJS file class.

    Sources:

    https://github.com/Estrol/X3Solo/blob/master/Estrol.X3Solo/Parser/Data/OJSData.cs (licensed under the MIT License)

    https://github.com/Estrol/X3Solo/blob/master/Estrol.X3Solo/Parser/Data/OJSFrame.cs (licensed under the MIT License)

    Attributes:
        ojs_file (bytes): The raw bytes of the OJS file.
        header (OjsHeader): The header of the OJS file in the OjsHeader type.
        frames (list): A list containing all the frames in the OjsFrame type.

    Arguments:
        ojs_file (bytes): Raw bytes of the OJS file.
    """

    def get_header(self) -> OjsHeader:
        """
        NOTE: If you are trying to get the header using this, please use OJS.header.

        Parses the header of the OJS file and returns an OjsHeader object.

        Source: https://github.com/Estrol/X3Solo/blob/master/Estrol.X3Solo/Parser/Data/OJSData.cs (licensed under the MIT License)

        :return: An OjsHeader object that has all the information from the header.
        :rtype: OjsHeader
        """

        file_format = int.from_bytes(self.ojs_file[0:2], 'little')
        color_format = int.from_bytes(self.ojs_file[2:4], 'big')
        frame_count = int.from_bytes(self.ojs_file[4:6], 'little')

        return OjsHeader(file_format, color_format, frame_count)

    def get_frames(self) -> list:
        """
        NOTE: If you are trying to get the frames using this, please use OJS.frames.

        Gets the frames of the OJS file and returns a list containing all the frames in the OjsFrame format.

        Source: https://github.com/Estrol/X3Solo/blob/master/Estrol.X3Solo/Parser/Data/OJSFrame.cs (licensed under the MIT License)

        :return: A list that has all the frames in the OjsFrame format.
        :rtype: list
        """

        current_pos = 6
        data = []

        for i in range(self.header.frame_count):
            transparent_color = int.from_bytes(self.ojs_file[current_pos:current_pos + 2], 'little')
            x = int.from_bytes(self.ojs_file[current_pos + 2:current_pos + 4], 'little')
            y = int.from_bytes(self.ojs_file[current_pos + 4:current_pos + 6], 'little')
            width = int.from_bytes(self.ojs_file[current_pos + 6:current_pos + 8], 'little')
            height = int.from_bytes(self.ojs_file[current_pos + 8:current_pos + 10], 'little')
            offset = int.from_bytes(self.ojs_file[current_pos + 10:current_pos + 14], 'little')
            size = int.from_bytes(self.ojs_file[current_pos + 14:current_pos + 18], 'little')
            unk = int.from_bytes(self.ojs_file[current_pos + 18:current_pos + 20], 'little')

            current_pos += 20

            image_data = self.ojs_file[
                         8 + (self.header.frame_count * 20) + offset:8 + (self.header.frame_count * 20) + offset + size]

            # BITMAPFILEHEADER
            bmp_file = bytearray(b'BM')
            bmp_file.extend((len(image_data) + 54).to_bytes(4, 'little'))
            bmp_file.extend(b'\x00\x00\x00\x00\x36\x00\x00\x00')

            # BITMAPINFOHEADER
            bmp_file.extend(b'\x28\x00\x00\x00')
            bmp_file.extend(width.to_bytes(4, 'little'))
            bmp_file.extend(height.to_bytes(4, 'little'))
            bmp_file.extend(
                b'\x01\x00\x10\x00\x00\x00\x00\x00\x00\x00\x00\x00\xc4\x0e'
                b'\x00\x00\xc4\x0e\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00')

            # O2Jam image files have their rows in the correct order, so we
            # must reverse them to have them work in a BMP.
            row_size = width * 2
            image_data_split = []

            for x in range(height):
                start = x * row_size
                end = start + row_size

                data_to_append = image_data[start:end]

                # Each row of pixels in a BMP must have padding to be a multiple of 4 bytes. Why? To
                # make it compatible with a 37-year-old operating system. Fun.
                if len(data_to_append) % 4 != 0:
                    for y in range(len(data_to_append) % 4):
                        data_to_append += b'\x00'

                image_data_split.append(data_to_append)

            image_data_split.reverse()
            reconstructed_image_data = bytearray()

            for row in image_data_split:
                reconstructed_image_data.extend(row)

            bmp_file.extend(reconstructed_image_data)

            data.append(OjsFrame(transparent_color, x, y, width, height, offset, size, unk, image_data, bmp_file))

        return data

    def __init__(self, ojs_file: bytes):
        self.ojs_file = ojs_file
        self.header = self.get_header()
        self.frames = self.get_frames()


def make_file(file_path: str, header: OjsHeader, frames: list) -> OJS:
    """
    Assembles an OJS file based off of an OjsHeader object, and a list containing all the frames in the form of an OjsFrame object.

    Sources:

    https://github.com/Estrol/X3Solo/blob/master/Estrol.X3Solo/Parser/Data/OJSData.cs (licensed under the MIT License)

    https://github.com/Estrol/X3Solo/blob/master/Estrol.X3Solo/Parser/Data/OJSFrame.cs (licensed under the MIT License)

    :return: The OJS file in the form of the OJS class.
    :rtype: OJS
    """

    with open(file_path, "wb") as f:
        # Write the header to the file
        f.write(header.file_format.to_bytes(length=2, byteorder='little'))
        f.write(header.color_format.to_bytes(length=2, byteorder='little'))
        f.write(header.frame_count.to_bytes(length=2, byteorder='little'))

        for frame in frames:
            f.write(frame.transparent_color.to_bytes(length=2, byteorder='little'))
            f.write(frame.x.to_bytes(length=2, byteorder='little'))
            f.write(frame.y.to_bytes(length=2, byteorder='little'))
            f.write(frame.width.to_bytes(length=2, byteorder='little'))
            f.write(frame.height.to_bytes(length=2, byteorder='little'))
            f.write(frame.offset.to_bytes(length=4, byteorder='little'))
            f.write(frame.size.to_bytes(length=4, byteorder='little'))
            f.write(frame.unk.to_bytes(length=2, byteorder='little'))

        for frame in frames:
            f.write(frame.data)

    with open(file_path, "rb") as rf:
        return OJS(rf.read())
