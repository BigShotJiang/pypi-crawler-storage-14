"""
Useful tools for OPI files.

Source:

https://github.com/Estrol/X3Solo/blob/master/Estrol.X3Solo/Parser/OPIParser.cs (licensed under the MIT License)

This code uses other code that have the following licenses:

X3Solo (MIT License):

https://github.com/Estrol/X3Solo/blob/master/LICENSE.txt
"""

class OpiHeader:
    """
    The OpiHeader class.

    Source: https://github.com/Estrol/X3Solo/blob/master/Estrol.X3Solo/Parser/OPIParser.cs (licensed under the MIT License)

    Attributes:
        file_type (int): Type of file.
        file_count (int): The amount of files in the OPI.
    """

    def __init__(self, file_type: int, file_count: int):
        self.file_type = file_type
        self.file_count = file_count

    def __repr__(self):
        attrs = ', '.join(f'{key}={value!r}' for key, value in vars(self).items())
        return f'{self.__class__.__name__}({attrs})'

    def __eq__(self, other):
        return vars(self) == vars(other) and isinstance(other, self.__class__)

class OpiFile:
    """
    The OpiFile class.

    Source: https://github.com/Estrol/X3Solo/blob/master/Estrol.X3Solo/Parser/OPIParser.cs (licensed under the MIT License)

    Attributes:
        unk_int (int): Unknown data.
        file_name (bytes): Name of the file.
        offset (int): Offset of the file in the OPI file.
        size_1 (int): If this is the biggest size, it is the size of the file.
        size_2 (int): If this is the biggest size, it is the size of the file.
        unk_bytes (bytes): Unknown data.
        data (bytes): The file.
    """

    def __init__(self, unk_int: int, file_name: bytes, offset: int, size_1: int, size_2: int, unk_bytes: bytes, data: bytes):
        self.unk_int = unk_int
        self.file_name = file_name
        self.offset = offset
        self.size_1 = size_1
        self.size_2 = size_2
        self.unk_bytes = unk_bytes
        self.data = data

    def __repr__(self):
        attrs = ', '.join(f'{key}={value!r}' for key, value in vars(self).items())
        return f'{self.__class__.__name__}({attrs})'

    def __eq__(self, other):
        return vars(self) == vars(other) and isinstance(other, self.__class__)

class OPI:
    """
    The OPI file class.

    Attributes:
        opi_file (bytes): Raw bytes of the OPI file.
        header (OpiHeader): Parsed header of the OPI file.
        files (list): The files of the OPI stored in the OpiFile object.

    Arguments:
        opi_file (bytes): Raw bytes of the OPI file.
    """

    def get_header(self) -> OpiHeader:
        """
        NOTE: If you are trying to get the header using this, please use OPI.header.

        Parses the header of the OPI file and returns an OpiHeader object.

        Source: https://github.com/Estrol/X3Solo/blob/master/Estrol.X3Solo/Parser/OPIParser.cs (licensed under the MIT License)

        :return: An OpiHeader object that has all the information from the header.
        :rtype: OpiHeader
        """

        # 3 lines ¯\_(ツ)_/¯

        file_type = int.from_bytes(self.opi_file[0:4], 'little')
        file_count = int.from_bytes(self.opi_file[4:8], 'little')

        return OpiHeader(file_type, file_count)

    def get_files(self) -> list:
        """
        NOTE: If you are trying to get the files using this, please use OPI.files.

        Gets the files of the OPI file.

        Source: https://github.com/Estrol/X3Solo/blob/master/Estrol.X3Solo/Parser/OPIParser.cs (licensed under the MIT License)

        :return: A list that has all the files in the form of OpiFiles.
        :rtype: list
        """

        current_pos = len(self.opi_file) - (self.header.file_count * 152)
        data = []

        for i in range(self.header.file_count): # Repeat for the amount of files in the OPI file (
            unk_int = int.from_bytes(self.opi_file[current_pos:current_pos + 4], 'little')
            file_name = self.opi_file[current_pos + 4:current_pos + 132]
            offset = int.from_bytes(self.opi_file[current_pos + 132:current_pos + 136], 'little')
            size_1 = int.from_bytes(self.opi_file[current_pos + 136:current_pos + 140], 'little')
            size_2 = int.from_bytes(self.opi_file[current_pos + 140:current_pos + 144], 'little')
            unk_bytes = self.opi_file[current_pos + 144:current_pos + 152]
            current_pos += 152 # Go to the next file
            file_data = self.opi_file[offset:offset + max(size_1, size_2)]

            data.append(OpiFile(unk_int, file_name, offset, size_1, size_2, unk_bytes, file_data))

        return data

    def __init__(self, opi_file: bytes):
        self.opi_file = opi_file
        self.header = self.get_header()
        self.files = self.get_files()

def make_file(file_path: str, header: OpiHeader, files: list) -> OPI:
    """
    NOTE: This will not make a 1:1 replica of the image file, as it leaves out unnecessary bytes and sorts the files by their offsets.

    Assembles an OPI file based off of an OpiHeader object, and a list containing all the files in the form of an OpiFile object.

    It's also an OPI optimizer because it removes padding bytes.

    Source: https://github.com/Estrol/X3Solo/blob/master/Estrol.X3Solo/Parser/OPIParser.cs (licensed under the MIT License)

    :return: The OPI file in the form of the OPI class.
    :rtype: OPI
    """

    with open(file_path, "wb") as f:
        # Write the header to the file
        f.write(header.file_type.to_bytes(length=4, byteorder='little'))
        f.write(header.file_count.to_bytes(length=4, byteorder='little'))

        # Write all the file data to the file (make sure to sort by offset in case they do something weird with the offsets)
        files.sort(key=lambda x: x.offset)

        for file in files:
            file.offset = f.tell()
            f.write(file.data)
            file.size_1 = f.tell() - file.offset
            file.size_2 = f.tell() - file.offset

        for file in files:
            f.write(file.unk_int.to_bytes(length=4, byteorder='little'))
            f.write(file.file_name)
            f.write(file.offset.to_bytes(length=4, byteorder='little'))
            f.write(file.size_1.to_bytes(length=4, byteorder='little'))
            f.write(file.size_2.to_bytes(length=4, byteorder='little'))
            f.write(file.unk_bytes)

    with open(file_path, "rb") as rf:
        return OPI(rf.read())
