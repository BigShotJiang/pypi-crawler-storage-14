"""
Useful tools for OJN files.

Sources:

https://open2jam.wordpress.com/the-ojn-documentation
"""

import struct

GENRE_LIST = ["Ballad", "Rock", "Dance", "Techno", "Hip-hop", "Soul/R&B", "Jazz", "Funk", "Classical", "Traditional",
              "Etc"]


class NoteEvent:
    """
    The NoteEvent class.

    Source: https://open2jam.wordpress.com/2010/10/05/the-notes-section

    Attributes:
        value (int): Padding/Reference to the sample on the OJM file.
        volume (int): The volume to play the sample on. Goes from 1 to 15, and 0 is the max volume.
        pan (int): The panning of the sample. 1 to 7 is left to center, 0 or 8 is center, 9 to 15 is center to right.
        note_type (int):
            0 = normal note,
            2 = start of long note,
            3 = end of long note,
            4 = OGG sample trigger.
    """

    def __init__(self, value: int, volume: int, pan: int, note_type: int):
        self.value = value
        self.volume = volume
        self.pan = pan
        self.note_type = note_type

    def __repr__(self):
        attrs = ', '.join(f'{key}={value!r}' for key, value in vars(self).items())
        return f'{self.__class__.__name__}({attrs})'

    def __eq__(self, other):
        return (
            isinstance(other, self.__class__) and
            hasattr(self, "__dict__") and
            hasattr(other, "__dict__") and
            self.__dict__ == other.__dict__
        )


class PackageHeader:
    """
    The PackageHeader class.

    Source: https://open2jam.wordpress.com/2010/10/05/the-notes-section

    Attributes:
        measure (int): The measure in which the events inside this package will appear.
        channel (int):
            0 = measure fraction,
            1 = BPM change,
            2 = note on 1st lane,
            3 = note on 2nd lane,
            4 = note on 3rd lane,
            5 = note on 4th lane,
            6 = note on 5th lane,
            7 = note on 6th lane,
            8 = note on 7th lane,
            9 and onwards - autoplay sample
        event_count (int): The number of events inside this package.
    """

    def __init__(self, measure, channel, event_count):
        self.measure = measure
        self.channel = channel
        self.event_count = event_count

    def __repr__(self):
        attrs = ', '.join(f'{key}={value!r}' for key, value in vars(self).items())
        return f'{self.__class__.__name__}({attrs})'

    def __eq__(self, other):
        return vars(self) == vars(other) and isinstance(other, self.__class__)


class OjnNoteData:
    """
    The OjnNoteData class.

    Source: https://open2jam.wordpress.com/2010/10/05/the-notes-section

    Layout:
        {(measure, channel): [event_count, NoteEvent, NoteEvent, etc.]}

    Example:
        {(3, 4): [4, NoteEvent(0, 0, 0, 0), NoteEvent(0, 0, 0, 0), NoteEvent(5, 0, 0, 2), NoteEvent(6, 0, 0, 3)]}

    Attributes:
        note_data_easy (dict): Note data for the easy difficulty
        note_data_normal (dict): Note data for the medium difficulty
        note_data_hard (dict): Note data for the hard difficulty
    """

    def __init__(self, note_data_easy, note_data_normal, note_data_hard):
        self.note_data_easy = note_data_easy
        self.note_data_normal = note_data_normal
        self.note_data_hard = note_data_hard

    def __repr__(self):
        attrs = ', '.join(f'{key}={value!r}' for key, value in vars(self).items())
        return f'{self.__class__.__name__}({attrs})'

    def __eq__(self, other):
        return vars(self) == vars(other) and isinstance(other, self.__class__)


class OjnHeader:
    """
    The OjnHeader class.

    Source: https://open2jam.wordpress.com/the-ojn-documentation

    Attributes:
        song_id (int): The ID of the song, usually the same ID as in the name of the file.
        signature (bytes): Magic number to identify the files (usually ojn<null>)
        encode_version (float): The OJN encode version (usually 2.9)
        genre (int): A number that represents the genre of the song. All genres are in the GENRE_LIST constant.
        bpm (float): The song BPM (changing this will not affect the song speed).
        easy_level (int): The level of the easy difficulty.
        normal_level (int): The level of the medium difficulty.
        hard_level (int): The level of the hard difficulty.
        easy_event_count (int): The amount of events in the easy difficulty.
        normal_event_count (int): The amount of events in the medium difficulty.
        hard_event_count (int): The amount of events in the hard difficulty.
        easy_note_count (int): The amount of notes in the easy difficulty.
        normal_note_count (int): The amount of notes in the medium difficulty.
        hard_note_count (int): The amount of notes in the hard difficulty.
        easy_measure_count (int): The amount of measures in the easy difficulty.
        normal_measure_count (int): The amount of measures in the medium difficulty.
        hard_measure_count (int): The amount of measures in the hard difficulty.
        easy_package_count (int): The amount of packages in the easy difficulty.
        normal_package_count (int): The amount of packages in the medium difficulty.
        hard_package_count (int): The amount of packages in the hard difficulty.
        old_encode_version (int): Unused encode version that got superseded by encode_version.
        old_song_id (int): Unused song ID (most likely changed because this one is only a short)
        old_genre (bytes): Old genre string before they switched to the number-based genre system.
        bmp_size (int): The size (in bytes) of the thumbnail image.
        old_file_version (int): Old (?) version of the file. Needs more research.
        title (bytes): The title of the song.
        artist (bytes): The artist of the song.
        noter (bytes): The noter of the chart.
        ojm_file (bytes): The corresponding OJM file.
        cover_size (int): The size (in bytes) of the cover image.
        easy_time (int): The duration (in seconds) of the easy difficulty.
        normal_time (int): The duration (in seconds) of the medium difficulty.
        hard_time (int): The duration (in seconds) of the hard difficulty.
        easy_note_offset (int): The offset of the note section for the easy difficulty.
        normal_note_offset (int): The offset (in bytes) of the note section for the medium difficulty.
        hard_note_offset(int): The offset (in bytes) of the note section for the hard difficulty.
        cover_offset (int): The offset (in bytes) of the cover image.
    """

    def __init__(self, song_id, signature, encode_version, genre, bpm, easy_level, normal_level, hard_level,
                 easy_event_count, normal_event_count, hard_event_count, easy_note_count, normal_note_count,
                 hard_note_count, easy_measure_count, normal_measure_count, hard_measure_count, easy_package_count,
                 normal_package_count, hard_package_count, old_encode_version, old_song_id, old_genre, bmp_size,
                 old_file_version, title, artist, noter, ojm_file, cover_size, easy_time, normal_time, hard_time,
                 easy_note_offset, normal_note_offset, hard_note_offset, cover_offset):
        self.song_id = song_id
        self.signature = signature
        self.encode_version = encode_version
        self.genre = genre
        self.bpm = bpm
        self.easy_level = easy_level
        self.normal_level = normal_level
        self.hard_level = hard_level
        self.easy_event_count = easy_event_count
        self.normal_event_count = normal_event_count
        self.hard_event_count = hard_event_count
        self.easy_note_count = easy_note_count
        self.normal_note_count = normal_note_count
        self.hard_note_count = hard_note_count
        self.easy_measure_count = easy_measure_count
        self.normal_measure_count = normal_measure_count
        self.hard_measure_count = hard_measure_count
        self.easy_package_count = easy_package_count
        self.normal_package_count = normal_package_count
        self.hard_package_count = hard_package_count
        self.old_encode_version = old_encode_version
        self.old_song_id = old_song_id
        self.old_genre = old_genre
        self.bmp_size = bmp_size
        self.old_file_version = old_file_version
        self.title = title
        self.artist = artist
        self.noter = noter
        self.ojm_file = ojm_file
        self.cover_size = cover_size
        self.easy_time = easy_time
        self.normal_time = normal_time
        self.hard_time = hard_time
        self.easy_note_offset = easy_note_offset
        self.normal_note_offset = normal_note_offset
        self.hard_note_offset = hard_note_offset
        self.cover_offset = cover_offset

    def __repr__(self):
        attrs = ', '.join(f'{key}={value!r}' for key, value in vars(self).items())
        return f'{self.__class__.__name__}({attrs})'

    def __eq__(self, other):
        return vars(self) == vars(other) and isinstance(other, self.__class__)


class OJN:
    """
    The OJN file class.

    Attributes:
        ojn_file (bytes): Raw bytes of the OJN file.
        header (OjnHeader): Parsed header of the OJN file.
        note_data (OjnNoteData): The note data of the OJN file (all difficulties).
        thumbnail (bytes): The 8x8 BMP thumbnail of the OJN file.
        cover (bytes): The cover image of the OJN file.

    Arguments:
        ojn_file (bytes): Raw bytes of the OJN file.
    """

    def get_header(self) -> OjnHeader:
        """
        NOTE: If you are trying to get the header using this, please use OJN.header.

        Parses the header of the OJN file and returns an OjnHeader object.

        Source: https://open2jam.wordpress.com/the-ojn-documentation

        :return: An OjnHeader object that has all the information from the header.
        :rtype: OjnHeader
        """

        song_id = int.from_bytes(self.ojn_file[0:4], "little")
        signature = self.ojn_file[4:8]

        encode_version = struct.unpack("<f", self.ojn_file[8:12])[0]
        genre = int.from_bytes(self.ojn_file[12:16], "little")
        bpm = struct.unpack("<f", self.ojn_file[16:20])[0]

        easy_difficulty = int.from_bytes(self.ojn_file[20:22], "little")
        normal_difficulty = int.from_bytes(self.ojn_file[22:24], "little")
        hard_difficulty = int.from_bytes(self.ojn_file[24:26], "little")

        easy_event_count = int.from_bytes(self.ojn_file[28:32], "little")
        normal_event_count = int.from_bytes(self.ojn_file[32:36], "little")
        hard_event_count = int.from_bytes(self.ojn_file[36:40], "little")

        easy_note_count = int.from_bytes(self.ojn_file[40:44], "little")
        normal_note_count = int.from_bytes(self.ojn_file[44:48], "little")
        hard_note_count = int.from_bytes(self.ojn_file[48:52], "little")

        easy_measure_count = int.from_bytes(self.ojn_file[52:56], "little")
        normal_measure_count = int.from_bytes(self.ojn_file[56:60], "little")
        hard_measure_count = int.from_bytes(self.ojn_file[60:64], "little")

        easy_package_count = int.from_bytes(self.ojn_file[64:68], "little")
        normal_package_count = int.from_bytes(self.ojn_file[68:72], "little")
        hard_package_count = int.from_bytes(self.ojn_file[72:76], "little")

        old_encode_version = int.from_bytes(self.ojn_file[76:78], "little")
        old_song_id = int.from_bytes(self.ojn_file[78:80], "little")
        old_genre = self.ojn_file[80:100]

        thumbnail_size = int.from_bytes(self.ojn_file[100:104], "little")

        old_file_version = int.from_bytes(self.ojn_file[104:108], "little")

        title = self.ojn_file[108:172]
        artist = self.ojn_file[172:204]
        noter = self.ojn_file[204:236]
        ojm_file = self.ojn_file[236:268]

        cover_size = int.from_bytes(self.ojn_file[268:272], "little")

        easy_length = int.from_bytes(self.ojn_file[272:276], "little")
        normal_length = int.from_bytes(self.ojn_file[276:280], "little")
        hard_length = int.from_bytes(self.ojn_file[280:284], "little")

        easy_note_offset = int.from_bytes(self.ojn_file[284:288], "little")
        normal_note_offset = int.from_bytes(self.ojn_file[288:292], "little")
        hard_note_offset = int.from_bytes(self.ojn_file[292:296], "little")

        cover_offset = int.from_bytes(self.ojn_file[296:300], "little")

        return OjnHeader(song_id, signature, encode_version, genre, bpm, easy_difficulty, normal_difficulty,
                         hard_difficulty, easy_event_count, normal_event_count,
                         hard_event_count, easy_note_count, normal_note_count, hard_note_count, easy_measure_count,
                         normal_measure_count, hard_measure_count, easy_package_count,
                         normal_package_count, hard_package_count, old_encode_version, old_song_id, old_genre,
                         thumbnail_size, old_file_version, title, artist, noter,
                         ojm_file, cover_size, easy_length, normal_length, hard_length, easy_note_offset,
                         normal_note_offset, hard_note_offset, cover_offset)

    def parse_notes(self) -> OjnNoteData:
        """
        NOTE: If you are trying to get the note data using this, please use OJN.note_data.

        Parses the notes section of the OJN file and returns an OjnNoteData object.

        Source: https://open2jam.wordpress.com/2010/10/05/the-notes-section

        :return: An OjnNoteData object that has all the note data.
        :rtype: OjnNoteData
        """

        note_data_easy = {}
        note_data_normal = {}
        note_data_hard = {}

        current_pos = self.header.easy_note_offset

        for x in range(self.header.easy_package_count):
            # Read measure (4 bytes), channel (2 bytes), and event count (2 bytes).
            package = PackageHeader(int.from_bytes(self.ojn_file[current_pos:current_pos + 4], byteorder="little"),
                                    int.from_bytes(self.ojn_file[current_pos + 4:current_pos + 6], byteorder="little"),
                                    int.from_bytes(self.ojn_file[current_pos + 6:current_pos + 8], byteorder="little"))

            # Create a unique note ID for this measure and channel.
            note_id = (package.measure, package.channel)
            note_data_easy[note_id] = [package.event_count]

            # Start reading events after the measure, channel, and event count (8 bytes so far).
            event_pos = current_pos + 8

            # Read each event (4 bytes per event).
            for i in range(package.event_count):
                if package.channel > 1:  # Note/Sample
                    note_event = NoteEvent(int.from_bytes(self.ojn_file[event_pos:event_pos + 1], byteorder="little"),
                                           int.from_bytes(self.ojn_file[event_pos + 1:event_pos + 2],
                                                          byteorder="little"),
                                           int.from_bytes(self.ojn_file[event_pos + 2:event_pos + 3],
                                                          byteorder="little"),
                                           int.from_bytes(self.ojn_file[event_pos + 3:event_pos + 4],
                                                          byteorder="little"))

                    note_data_easy[note_id].append(note_event)
                elif package.channel == 1:  # BPM Change
                    new_bpm = struct.unpack("<f", self.ojn_file[event_pos:event_pos + 4])[0]

                    note_data_easy[note_id].append(new_bpm)
                elif package.channel == 0:  # Change percentage of measure used
                    measure_used = struct.unpack("<f", self.ojn_file[event_pos:event_pos + 4])[0]

                    note_data_easy[note_id].append(measure_used)

                event_pos += 4  # Move to the next event.

            # Update the position for the next measure/channel pair
            current_pos = event_pos

        current_pos = self.header.normal_note_offset  # Set the position to the medium note offset.

        for x in range(self.header.normal_package_count):
            # Read measure (4 bytes), channel (2 bytes), and event count (2 bytes).
            package = PackageHeader(int.from_bytes(self.ojn_file[current_pos:current_pos + 4], byteorder="little"),
                                    int.from_bytes(self.ojn_file[current_pos + 4:current_pos + 6], byteorder="little"),
                                    int.from_bytes(self.ojn_file[current_pos + 6:current_pos + 8], byteorder="little"))

            # Create a unique note ID for this measure and channel.
            note_id = (package.measure, package.channel)
            note_data_normal[note_id] = [package.event_count]

            # Start reading events after the measure, channel, and event count (8 bytes so far).
            event_pos = current_pos + 8

            # Read each event (4 bytes per event).
            for i in range(package.event_count):
                if package.channel > 1:  # Note/Sample
                    note_event = NoteEvent(int.from_bytes(self.ojn_file[event_pos:event_pos + 1], byteorder="little"),
                                           int.from_bytes(self.ojn_file[event_pos + 1:event_pos + 2],
                                                          byteorder="little"),
                                           int.from_bytes(self.ojn_file[event_pos + 2:event_pos + 3],
                                                          byteorder="little"),
                                           int.from_bytes(self.ojn_file[event_pos + 3:event_pos + 4],
                                                          byteorder="little"))

                    note_data_normal[note_id].append(note_event)
                elif package.channel == 1:  # BPM Change
                    new_bpm = struct.unpack("<f", self.ojn_file[event_pos:event_pos + 4])[0]

                    note_data_normal[note_id].append(new_bpm)
                elif package.channel == 0:  # Change percentage of measure used
                    measure_used = struct.unpack("<f", self.ojn_file[event_pos:event_pos + 4])[0]

                    note_data_normal[note_id].append(measure_used)

                event_pos += 4  # Move to the next event.

            # Update the position for the next measure/channel pair
            current_pos = event_pos

        current_pos = self.header.hard_note_offset  # Set the position to the hard note offset.

        for x in range(self.header.hard_package_count):
            # Read measure (4 bytes), channel (2 bytes), and event count (2 bytes).
            package = PackageHeader(int.from_bytes(self.ojn_file[current_pos:current_pos + 4], byteorder="little"),
                                    int.from_bytes(self.ojn_file[current_pos + 4:current_pos + 6], byteorder="little"),
                                    int.from_bytes(self.ojn_file[current_pos + 6:current_pos + 8], byteorder="little"))

            # Create a unique note ID for this measure and channel.
            note_id = (package.measure, package.channel)
            note_data_hard[note_id] = [package.event_count]

            # Start reading events after the measure, channel, and event count (8 bytes so far).
            event_pos = current_pos + 8

            # Read each event (4 bytes per event).
            for i in range(package.event_count):
                if package.channel > 1:  # Note/Sample
                    note_event = NoteEvent(int.from_bytes(self.ojn_file[event_pos:event_pos + 1], byteorder="little"),
                                           int.from_bytes(self.ojn_file[event_pos + 1:event_pos + 2],
                                                          byteorder="little"),
                                           int.from_bytes(self.ojn_file[event_pos + 2:event_pos + 3],
                                                          byteorder="little"),
                                           int.from_bytes(self.ojn_file[event_pos + 3:event_pos + 4],
                                                          byteorder="little"))

                    note_data_hard[note_id].append(note_event)
                elif package.channel == 1:  # BPM Change
                    new_bpm = struct.unpack("<f", self.ojn_file[event_pos:event_pos + 4])[0]

                    note_data_hard[note_id].append(new_bpm)
                elif package.channel == 0:  # Change percentage of measure used
                    measure_used = struct.unpack("<f", self.ojn_file[event_pos:event_pos + 4])[0]

                    note_data_hard[note_id].append(measure_used)

                event_pos += 4  # Move to the next event.

            # Update the position for the next measure/channel pair
            current_pos = event_pos

        return OjnNoteData(note_data_easy, note_data_normal, note_data_hard)

    def get_thumbnail(self) -> bytes:
        """
        NOTE: If you are trying to get the thumbnail using this, please use OJN.thumbnail.

        Gets the thumbnail (8x8 BMP) of the OJN.

        Source: https://open2jam.wordpress.com/the-ojn-documentation

        :return: A bytes object that contains the BMP.
        :rtype: bytes
        """

        return self.ojn_file[self.header.cover_offset + self.header.cover_size:len(self.ojn_file)]

    def get_cover(self) -> bytes:
        """
        NOTE: If you are trying to get the cover using this, please use OJN.cover.

        Gets the cover of the OJN.

        Source: https://open2jam.wordpress.com/the-ojn-documentation

        :return: A bytes object that contains the cover.
        :rtype: bytes
        """

        return self.ojn_file[self.header.cover_offset:self.header.cover_offset + self.header.cover_size]

    def __init__(self, ojn_file: bytes):
        self.ojn_file = ojn_file
        self.header = self.get_header()
        self.note_data = self.parse_notes()
        self.thumbnail = self.get_thumbnail()
        self.cover = self.get_cover()


def make_file(file_path: str, header: OjnHeader, notes: OjnNoteData, cover: bytes, thumbnail: bytes) -> OJN:
    """
    Assembles an OJN file from an OjnHeader, OjnNoteData, cover, and thumbnail.

    Source: https://open2jam.wordpress.com/the-ojn-documentation

    :arg: file_path (str): The path to the file that the function will create.
    :arg: header (OjnHeader): The header in the form of an OjnHeader object.
    :arg: notes (OjnNoteData): The notes in the form of an OjnNoteData object.
    :arg: cover (bytes): The JPG cover of the OJN.
    :arg: thumbnail (bytes): The 8x8 BMP thumbnail of the OJN.

    :return: An OJN object that contains the file that was just created.
    :rtype: OJN
    """

    with open(file_path, "wb") as f:
        # Write the header to the file
        f.write(header.song_id.to_bytes(length=4, byteorder='little'))
        f.write(header.signature)
        f.write(struct.pack("<f", header.encode_version))
        f.write(header.genre.to_bytes(length=4, byteorder='little'))
        f.write(struct.pack("<f", header.bpm))
        f.write(header.easy_level.to_bytes(length=2, byteorder='little'))
        f.write(header.normal_level.to_bytes(length=2, byteorder='little'))
        f.write(header.hard_level.to_bytes(length=2, byteorder='little'))
        f.write(b'\x00\x00')
        f.write(header.easy_event_count.to_bytes(length=4, byteorder='little'))
        f.write(header.normal_event_count.to_bytes(length=4, byteorder='little'))
        f.write(header.hard_event_count.to_bytes(length=4, byteorder='little'))
        f.write(header.easy_note_count.to_bytes(length=4, byteorder='little'))
        f.write(header.normal_note_count.to_bytes(length=4, byteorder='little'))
        f.write(header.hard_note_count.to_bytes(length=4, byteorder='little'))
        f.write(header.easy_measure_count.to_bytes(length=4, byteorder='little'))
        f.write(header.normal_measure_count.to_bytes(length=4, byteorder='little'))
        f.write(header.hard_measure_count.to_bytes(length=4, byteorder='little'))
        f.write(header.easy_package_count.to_bytes(length=4, byteorder='little'))
        f.write(header.normal_package_count.to_bytes(length=4, byteorder='little'))
        f.write(header.hard_package_count.to_bytes(length=4, byteorder='little'))
        f.write(header.old_encode_version.to_bytes(length=2, byteorder='little'))
        f.write(header.old_song_id.to_bytes(length=2, byteorder='little'))
        f.write(header.old_genre)
        f.write(header.bmp_size.to_bytes(length=4, byteorder='little'))
        f.write(header.old_file_version.to_bytes(length=4, byteorder='little'))
        f.write(header.title)
        f.write(header.artist)
        f.write(header.noter)
        f.write(header.ojm_file)
        f.write(header.cover_size.to_bytes(length=4, byteorder='little'))
        f.write(header.easy_time.to_bytes(length=4, byteorder='little'))
        f.write(header.normal_time.to_bytes(length=4, byteorder='little'))
        f.write(header.hard_time.to_bytes(length=4, byteorder='little'))
        f.write(header.easy_note_offset.to_bytes(length=4, byteorder='little'))
        f.write(header.normal_note_offset.to_bytes(length=4, byteorder='little'))
        f.write(header.hard_note_offset.to_bytes(length=4, byteorder='little'))
        f.write(header.cover_offset.to_bytes(length=4, byteorder='little'))

        for (measure, channel), value in notes.note_data_easy.items():  # ???
            # Write the current package to the file
            f.write(measure.to_bytes(length=4, byteorder='little'))
            f.write(channel.to_bytes(length=2, byteorder='little'))
            f.write(value[0].to_bytes(length=2, byteorder='little'))

            for data in value:
                if data != value[0]:  # If the data is not the event count
                    if isinstance(data, NoteEvent):  # If the data is a NoteEvent
                        # Write the NoteEvent to the file

                        f.write(data.value.to_bytes(length=1, byteorder='little'))
                        f.write(data.volume.to_bytes(length=1, byteorder='little'))
                        f.write(data.pan.to_bytes(length=1, byteorder='little'))
                        f.write(data.note_type.to_bytes(length=1, byteorder='little'))
                    else:  # If the data is a float
                        f.write(struct.pack("<f", data))  # Write the float to the file

        for (measure, channel), value in notes.note_data_normal.items():  # ??? again
            # Write the current package to the file
            f.write(measure.to_bytes(length=4, byteorder='little'))
            f.write(channel.to_bytes(length=2, byteorder='little'))
            f.write(value[0].to_bytes(length=2, byteorder='little'))

            for data in value:
                if data != value[0]:  # If the data is not the event count
                    if isinstance(data, NoteEvent):  # If the data is a NoteEvent
                        # Write the NoteEvent to the file

                        f.write(data.value.to_bytes(length=1, byteorder='little'))
                        f.write(data.volume.to_bytes(length=1, byteorder='little'))
                        f.write(data.pan.to_bytes(length=1, byteorder='little'))
                        f.write(data.note_type.to_bytes(length=1, byteorder='little'))
                    else:  # If the data is a float
                        f.write(struct.pack("<f", data))  # Write the float to the file

        for (measure, channel), value in notes.note_data_hard.items(): # ??-never mind i understand it now
            # Write the current package to the file
            f.write(measure.to_bytes(length=4, byteorder='little'))
            f.write(channel.to_bytes(length=2, byteorder='little'))
            f.write(value[0].to_bytes(length=2, byteorder='little'))

            for data in value:
                if data != value[0]:  # If the data is not the event count
                    if isinstance(data, NoteEvent):  # If the data is a NoteEvent
                        # Write the NoteEvent to the file

                        f.write(data.value.to_bytes(length=1, byteorder='little'))
                        f.write(data.volume.to_bytes(length=1, byteorder='little'))
                        f.write(data.pan.to_bytes(length=1, byteorder='little'))
                        f.write(data.note_type.to_bytes(length=1, byteorder='little'))
                    else:  # If the data is a float
                        f.write(struct.pack("<f", data))  # Write the float to the file

        f.write(cover)
        f.write(thumbnail)

    with open(file_path, "rb") as rf:
        return OJN(rf.read())


def get_header(ojn_file: bytes) -> OjnHeader:
    """
    Parses the header of the OJN file and returns an OjnHeader object.

    Source: https://open2jam.wordpress.com/the-ojn-documentation

    :arg: ojn_file (bytes): The raw bytes of the OJN file.

    :return: An OjnHeader object that has all the information from the header.
    :rtype: OjnHeader
    """

    song_id = int.from_bytes(ojn_file[0:4], "little")
    signature = ojn_file[4:8]

    encode_version = struct.unpack("<f", ojn_file[8:12])[0]
    genre = int.from_bytes(ojn_file[12:16], "little")
    bpm = struct.unpack("<f", ojn_file[16:20])[0]

    easy_difficulty = int.from_bytes(ojn_file[20:22], "little")
    normal_difficulty = int.from_bytes(ojn_file[22:24], "little")
    hard_difficulty = int.from_bytes(ojn_file[24:26], "little")

    easy_event_count = int.from_bytes(ojn_file[28:32], "little")
    normal_event_count = int.from_bytes(ojn_file[32:36], "little")
    hard_event_count = int.from_bytes(ojn_file[36:40], "little")

    easy_note_count = int.from_bytes(ojn_file[40:44], "little")
    normal_note_count = int.from_bytes(ojn_file[44:48], "little")
    hard_note_count = int.from_bytes(ojn_file[48:52], "little")

    easy_measure_count = int.from_bytes(ojn_file[52:56], "little")
    normal_measure_count = int.from_bytes(ojn_file[56:60], "little")
    hard_measure_count = int.from_bytes(ojn_file[60:64], "little")

    easy_package_count = int.from_bytes(ojn_file[64:68], "little")
    normal_package_count = int.from_bytes(ojn_file[68:72], "little")
    hard_package_count = int.from_bytes(ojn_file[72:76], "little")

    old_encode_version = int.from_bytes(ojn_file[76:78], "little")
    old_song_id = int.from_bytes(ojn_file[78:80], "little")
    old_genre = ojn_file[80:100]

    thumbnail_size = int.from_bytes(ojn_file[100:104], "little")

    old_file_version = int.from_bytes(ojn_file[104:108], "little")

    title = ojn_file[108:172]
    artist = ojn_file[172:204]
    noter = ojn_file[204:236]
    ojm_file = ojn_file[236:268]

    cover_size = int.from_bytes(ojn_file[268:272], "little")

    easy_length = int.from_bytes(ojn_file[272:276], "little")
    normal_length = int.from_bytes(ojn_file[276:280], "little")
    hard_length = int.from_bytes(ojn_file[280:284], "little")

    easy_note_offset = int.from_bytes(ojn_file[284:288], "little")
    normal_note_offset = int.from_bytes(ojn_file[288:292], "little")
    hard_note_offset = int.from_bytes(ojn_file[292:296], "little")

    cover_offset = int.from_bytes(ojn_file[296:300], "little")

    return OjnHeader(song_id, signature, encode_version, genre, bpm, easy_difficulty, normal_difficulty,
                     hard_difficulty, easy_event_count, normal_event_count,
                     hard_event_count, easy_note_count, normal_note_count, hard_note_count, easy_measure_count,
                     normal_measure_count, hard_measure_count, easy_package_count,
                     normal_package_count, hard_package_count, old_encode_version, old_song_id, old_genre,
                     thumbnail_size, old_file_version, title, artist, noter,
                     ojm_file, cover_size, easy_length, normal_length, hard_length, easy_note_offset,
                     normal_note_offset, hard_note_offset, cover_offset)
