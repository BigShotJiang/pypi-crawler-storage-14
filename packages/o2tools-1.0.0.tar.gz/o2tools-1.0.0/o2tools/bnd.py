"""
Useful tools for BND files.
"""

class BndHeader:
    """
    The BndHeader class.

    Attributes:
        signature (bytes): The signature of the BND file.
        object_count (int): The amount of objects in the BND file.
    """

    def __init__(self, signature: bytes, object_count: int):
        self.signature = signature
        self.object_count = object_count

    def __repr__(self):
        attrs = ', '.join(f'{key}={value!r}' for key, value in vars(self).items())
        return f'{self.__class__.__name__}({attrs})'

    def __eq__(self, other):
        return vars(self) == vars(other) and isinstance(other, self.__class__)

# Placeholder descriptions. Replace these if you know how the variables are used.
class BndObject:
    """
    The BndObject class.

    Attributes:
        start_x (int): The start_x of the object.
        start_y (int): The start_y of the object.
        end_x (int): The end_x of the object.
        end_y (int): The end_y of the object.
    """

    def __init__(self, start_x: int, start_y: int, end_x: int, end_y: int):
        self.start_x = start_x
        self.start_y = start_y
        self.end_x = end_x
        self.end_y = end_y

    def __repr__(self):
        attrs = ', '.join(f'{key}={value!r}' for key, value in vars(self).items())
        return f'{self.__class__.__name__}({attrs})'

    def __eq__(self, other):
        return vars(self) == vars(other) and isinstance(other, self.__class__)

class BND:
    """
    The BND file class.

    Attributes:
        bnd_file (bytes): Raw bytes of the BND file.
        header (BndHeader): Parsed header of the BND file.
        objects (list): All the objects in the BND file stored as BndObjects.

    Arguments:
        bnd_file (bytes): Raw bytes of the BND file.
    """

    def get_header(self) -> BndHeader:
        """
        NOTE: If you are trying to get the header using this, please use BND.header.

        Parses the header of the BND file and returns a BndHeader object.

        :return: A BndHeader object that has all the information from the header.
        :rtype: BndHeader
        """

        return BndHeader(self.bnd_file[0:4], int.from_bytes(self.bnd_file[4:6], byteorder='little'))

    def get_objects(self) -> list:
        """
        NOTE: If you are trying to get the objects using this, please use BND.objects.

        Gets all the objects from the BND file.

        :return: A list containing all the objects in the BND file in the form of a BndObject object.
        :rtype: list
        """

        data = []
        current_pos = 6

        for i in range(self.header.object_count):
            start_x = int.from_bytes(self.bnd_file[current_pos:current_pos + 4], byteorder='little')
            start_y = int.from_bytes(self.bnd_file[current_pos + 4:current_pos + 8], byteorder='little')
            end_x = int.from_bytes(self.bnd_file[current_pos + 8:current_pos + 12], byteorder='little')
            end_y = int.from_bytes(self.bnd_file[current_pos + 12:current_pos + 16], byteorder='little')

            current_pos += 16

            data.append(BndObject(start_x, start_y, end_x, end_y))

        return data

    def __init__(self, bnd_file: bytes):
        self.bnd_file = bnd_file
        self.header = self.get_header()
        self.objects = self.get_objects()

def make_file(file_path: str, header: BndHeader, objects: list) -> BND:
    """
    Assembles a BND file based off of an BndHeader object, and a list containing all the objects in the form of a BndObject object.

    :return: The BND file in the form of the BND class.
    :rtype: BND
    """

    with open(file_path, "wb") as f:
        # Write the header to the file
        f.write(header.signature)
        f.write(header.object_count.to_bytes(length=2, byteorder='little'))

        for bnd_object in objects:
            f.write(bnd_object.start_x.to_bytes(length=4, byteorder='little'))
            f.write(bnd_object.start_y.to_bytes(length=4, byteorder='little'))
            f.write(bnd_object.end_x.to_bytes(length=4, byteorder='little'))
            f.write(bnd_object.end_y.to_bytes(length=4, byteorder='little'))

    with open(file_path, "rb") as rf:
        return BND(rf.read())
