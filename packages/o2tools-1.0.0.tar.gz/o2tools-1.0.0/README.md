<p align="center">
  <img src="https://github.com/SweepSweep2/o2tools/blob/main/logo.png?raw=true"/>
</p>

<h2 align="center">O2Tools, a python package for manipulating O2Jam files.</h2>

# Features
- [x] Readable OJN Note Sections
- [x] OJM Sound Extraction (both M30 and OMC)
- [x] Interface/Avatar File Support
- [x] OJN List Support
- [x] Highly Documented
- [x] Easy to Use
- [x] Fully Object-Oriented

# Build Instructions

Install dependencies (build):

    pip install build

Inside the root of the project (where pyproject.toml is located), run:

    python -m build

This will generate the following files (inside the dist directory):

 * A .tar.gz source archive
 * A .whl (wheel) binary distribution

Run the following command (in the dist directory):
    
    pip install [name of wheel file].whl

# Contribution

You can contribute by filling in unknown data in the documentation/code.

# Documentation

The official docs are here: https://o2tools.readthedocs.io

They are not fully finished yet, and are still being worked on.
