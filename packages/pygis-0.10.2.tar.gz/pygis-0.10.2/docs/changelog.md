# Changelog

## v0.6.1 - JUl 8, 2022

- Added kaleido, pydeck, and keplergl

## v0.6.0 - Jun 19, 2022

- Added geemap extra packages

## v0.5.0 - Nov 29, 2022

- Updated geemap and leafmap versions

## v0.4.0 - Jul 26, 2022

- Pin ipython and ipykernel versions to reduce installation time on Colab.

## v0.3.0 - Jun 18, 2022

- Added geedim
- Reorder package list

## v0.2.0 - Jun 6, 2022

- Added dependencies
- Updated mkdocs
