#!/usr/bin/env python

"""Tests for `pygis` package."""


import unittest

from pygis import pygis


class TestPygis(unittest.TestCase):
    """Tests for `pygis` package."""

    def setUp(self):
        """Set up test fixtures, if any."""

    def tearDown(self):
        """Tear down test fixtures, if any."""

    def test_000_something(self):
        """Test something."""
