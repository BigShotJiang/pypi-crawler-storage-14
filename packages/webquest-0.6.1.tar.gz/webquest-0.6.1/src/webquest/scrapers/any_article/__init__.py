from webquest.scrapers.any_article.scraper import (
    AnyArticle,
    AnyArticleRequest,
    AnyArticleResponse,
)

__all__ = [
    "AnyArticle",
    "AnyArticleRequest",
    "AnyArticleResponse",
]
