from webquest.scrapers.any_article import AnyArticle
from webquest.scrapers.base_scraper import BaseScraper
from webquest.scrapers.duckduckgo_search import DuckDuckGoSearch
from webquest.scrapers.google_news_search import GoogleNewsSearch
from webquest.scrapers.openai_parser import OpenAIParser
from webquest.scrapers.youtube_search import YouTubeSearch
from webquest.scrapers.youtube_transcript import YouTubeTranscript

__all__ = [
    "AnyArticle",
    "BaseScraper",
    "DuckDuckGoSearch",
    "GoogleNewsSearch",
    "OpenAIParser",
    "YouTubeSearch",
    "YouTubeTranscript",
]
