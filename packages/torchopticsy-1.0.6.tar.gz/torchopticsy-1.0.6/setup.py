import os
import shutil
from setuptools import setup, find_packages
from torch.utils.cpp_extension import BuildExtension, CUDAExtension
import torch


def build_cuda_extension(name, sources):
    """Safe optional CUDA build."""
    # 1. CUDA runtime must exist
    if not torch.cuda.is_available():
        print(f"[torchopticsy] CUDA 不可用，跳过编译 {name}")
        return None

    # 2. nvcc must exist
    if shutil.which("nvcc") is None:
        print(f"[torchopticsy] 未检测到 NVCC，跳过编译 {name}")
        return None

    return CUDAExtension(
        name=name,
        sources=sources,
        include_dirs=["cuda"],
        extra_compile_args={
            "cxx": ["-O2"],
            "nvcc": ["-O2", "--use_fast_math"],
        },
    )


# 定义 CUDA 扩展（如果可编译）
cuda_sources = {
    "opticsyCUDA.Utils": ["cuda/Utils.cu"],
    "opticsyCUDA.FDTD": ["cuda/FDTD.cu"],
    "opticsyCUDA.FDTD4": ["cuda/FDTD4.cu"],
}

ext_modules = []
for name, src in cuda_sources.items():
    ext = build_cuda_extension(name, src)
    if ext is not None:
        ext_modules.append(ext)


setup(
    name="torchopticsy",
    version="1.0.6",
    description="PyTorch-based optics calculation",
    long_description="",
    long_description_content_type="text/markdown",
    author="YuningYe",
    author_email="1956860113@qq.com",
    license="MIT",
    packages=find_packages(),
    install_requires=[
        "torch",
        "opencv-python",
        "matplotlib",
        "tqdm",
        "scipy",
        "ipywidgets",
        "IPython",
    ],
    include_package_data=True,
    # 只有当有可编译扩展时才启用 BuildExtension
    ext_modules=ext_modules,
    cmdclass={"build_ext": BuildExtension} if ext_modules else {},
)
