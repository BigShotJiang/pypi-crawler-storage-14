__version__ = "1.0.5"
__author__ = "Amarjit Jha"
__app_name__ = "jha"
