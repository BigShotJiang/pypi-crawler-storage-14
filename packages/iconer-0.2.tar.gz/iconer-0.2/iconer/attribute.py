# coding:utf-8

__project__ = "iconer"
__version__ = "0.2"
__description__ = "Download website favorites."
__urlhome__ = "https://github.com/bondbox/iconer/"

# author
__author__ = "Mingzhe Zou"
__author_email__ = "zoumingzhe@outlook.com"
