# Copyright 2025 Camptocamp SA
# License AGPL-3.0 or later (http://www.gnu.org/licenses/agpl)
{
    "name": "Delivery Carrier Shipping Policy",
    "version": "18.0.1.0.0",
    "author": "Camptocamp,BCIM,Odoo Community Association (OCA)",
    "category": "Delivery",
    "depends": [
        "delivery",
    ],
    "website": "https://github.com/OCA/delivery-carrier",
    "data": [
        "views/delivery_carrier.xml",
    ],
    "installable": True,
    "license": "AGPL-3",
}
