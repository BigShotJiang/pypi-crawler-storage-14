# No pyproject block

output = {}
is_error = False

# Internal
exact_error = None
