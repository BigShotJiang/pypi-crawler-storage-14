# /// script
# requires-python = ">=3.11"
# dependencies = [
#   "requests<3",
#   "rich",
# ]
# ///

# /// script
# requires-python = ">=3.11"
# dependencies = [
#   "requests<3",
#   "rich",
# ]
# ///

output = {}
is_error = True

# Internal
exact_error = ValueError("Line 9: Duplicate 'script' block found.")
