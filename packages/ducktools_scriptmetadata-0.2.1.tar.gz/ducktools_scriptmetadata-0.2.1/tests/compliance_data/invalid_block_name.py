# Invalid block name - not a valid "type"

# /// script!!
# Anything under here should be ignored
# ///

output = {}
is_error = False

# Internal
exact_error = None
