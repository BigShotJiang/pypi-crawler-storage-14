# /// script
# requires-python = ">=3.11"
# dependencies = [
#   "requests<3",
#   "rich",
# ]


output = {}
is_error = False

# Internal
exact_error = None
