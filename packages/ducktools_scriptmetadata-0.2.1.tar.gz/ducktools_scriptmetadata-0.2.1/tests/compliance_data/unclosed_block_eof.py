"""
This is upside down because the block is at the end of the file.
"""

output = {}
is_error = False

# Internal
exact_error = None


# /// script
# requires-python = ">=3.11"
# dependencies = [
#   "requests<3",
#   "rich",
# ]
