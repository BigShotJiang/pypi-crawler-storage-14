# /// some-toml
#
# embedded-csharp = """
# /// <summary>
# /// text
# ///
# /// </summary>
# public class MyClass { }
# """
#
# other-value = 42
# ///
