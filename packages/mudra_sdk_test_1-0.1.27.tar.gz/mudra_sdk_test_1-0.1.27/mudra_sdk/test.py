import asyncio
import sys
import os
from pathlib import Path

from models.mudra import Mudra
from models.callbacks import MudraDelegate


# Add parent directory to path so mudra_sdk can be imported
parent_dir = Path(__file__).parent.parent
if str(parent_dir) not in sys.path:
    sys.path.insert(0, str(parent_dir))

import tkinter as tk
from threading import Thread
from mudra_sdk.models.mudra_device import MudraDevice


# Global reference to the event loop and thread
loop = None
loop_thread = None

devices_list = []

def update_devices_list(device):
    print(device.name)
    devices_list.append(device.name)
    listbox.after(0, refresh_listbox)

mudra = Mudra()
class MyMudraDelegate(MudraDelegate):
    def on_device_discovered(self, device: MudraDevice):
        print(f"Discovered: {device.name}")
        update_devices_list(device)

    def on_mudra_device_disconnected(self, device: MudraDevice):
        print(f"Device disconnected: {device.name}")

    def on_mudra_device_disconnecting(self, device: MudraDevice):
        print(f"Device disconnecting: {device.name}")

    def on_mudra_device_connected(self, device: MudraDevice):
        print(f"Device connected: {device.name}")

    def on_mudra_device_connecting(self, device: MudraDevice):
        print(f"Device connecting: {device.name}")

    def on_mudra_device_connection_failed(self, device: MudraDevice, error: str):
        print(f"Connection failed: {device.name}, Error: {error}")

    def on_bluetooth_state_changed(self, state: bool):
        print(f"Bluetooth state changed: {'On' if state else 'Off'}")

mudra.set_delegate(MyMudraDelegate())

def refresh_listbox():
    listbox.delete(0, tk.END)
    for dev_name in devices_list:
        listbox.insert(tk.END, dev_name)

def run_event_loop():
    """Run the event loop in a separate thread."""
    global loop
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    loop.run_forever()

def start_scan():
    global loop, loop_thread
    # Create event loop thread if it doesn't exist
    if loop_thread is None or not loop_thread.is_alive():
        loop_thread = Thread(target=run_event_loop, daemon=True)
        loop_thread.start()
        # Wait a bit for the loop to start
        import time
        time.sleep(0.1)
    
    # Schedule the scan on the event loop
    if loop is not None:
        asyncio.run_coroutine_threadsafe(mudra.ble_service.scan(), loop)

def stop_scan():
    global loop
    # Stop scanning using the same event loop
    if loop is not None:
        asyncio.run_coroutine_threadsafe(mudra.ble_service.stop_scanning(), loop)

# Set up basic Tkinter window
root = tk.Tk()
root.title("Mudra BLE Devices")

frame = tk.Frame(root)
frame.pack(padx=10, pady=10)

listbox = tk.Listbox(frame, width=40, height=10)
listbox.pack(pady=(0,10))

button_frame = tk.Frame(frame)
button_frame.pack()

start_btn = tk.Button(button_frame, text="Start Scanning", command=start_scan)
start_btn.pack(side=tk.LEFT, padx=5)

stop_btn = tk.Button(button_frame, text="Stop Scanning", command=stop_scan)
stop_btn.pack(side=tk.LEFT, padx=5)

root.mainloop()
