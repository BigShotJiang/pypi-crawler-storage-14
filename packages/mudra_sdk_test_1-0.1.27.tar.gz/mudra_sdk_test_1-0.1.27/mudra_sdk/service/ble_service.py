import asyncio
from typing import Callable, Optional
from bleak import BleakScanner
from bleak.backends.device import BLEDevice

from ..models.callbacks import MudraDelegate

from ..models.mudra_device import MudraDevice


class BleService:
    _instance = None
    _delegate: Optional[MudraDelegate] = None

    def __new__(cls, *args, **kwargs):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance

    def __init__(self, delegate:[MudraDelegate]):
        self._scan_task = None
        self._scanner: Optional[BleakScanner] = None
        self._delegate = delegate

    @property
    def _is_scanning(self) -> bool:
        """Check if currently scanning for devices."""
        return self._scan_task is not None and not self._scan_task.done()

    async def scan(self):
        """Start scanning for BLE devices."""
        if self._is_scanning:
            return
        print("Starting scan")
        self._scan_task = asyncio.create_task(self._scan_loop())

    async def stop_scanning(self):
        """Stop scanning for BLE devices."""
        if not self._is_scanning:
            return
        print("Stopping scan")
        
        # Cancel the scan task
        if self._scan_task and not self._scan_task.done():
            self._scan_task.cancel()
            try:
                await self._scan_task
            except asyncio.CancelledError:
                pass
        
        # Stop the scanner if it exists
        if self._scanner:
            try:
                await self._scanner.stop()
            except Exception:
                # Silently ignore errors when stopping (scanner might already be stopped)
                pass
            finally:
                self._scanner = None
        
        self._scan_task = None
        self._on_device_found = None

    async def _scan_loop(self):
        """Internal method that performs the actual scanning."""
        try:
            self._scanner = BleakScanner(detection_callback=self._on_device_detected)
            
            await self._scanner.start()
            print("Scan started successfully")
            
            # Keep scanning until cancelled
            while True:
                await asyncio.sleep(1)
                
        except asyncio.CancelledError:
            print("Scan cancelled")
            if self._scanner:
                try:
                    await self._scanner.stop()
                except Exception as e:
                    # Silently ignore errors when stopping (scanner might already be stopped)
                    pass
            raise
        except Exception as e:
            print(f"Error during scan: {e}")
            raise
        finally:
            self._scanner = None
            self._scan_task = None

    def _on_device_detected(self, device: BLEDevice, advertisement_data):
        if self._delegate:
            try:
                if device.name and "Mudra" in device.name:
                    mudra_device = MudraDevice(device)
                    self._delegate.on_device_discovered(mudra_device)
            except Exception as e:
                print(f"Error processing device {device.address}: {e}")
