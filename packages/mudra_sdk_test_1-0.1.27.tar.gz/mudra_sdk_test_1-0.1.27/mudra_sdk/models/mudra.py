from ..service.ble_service import BleService
from ..models.mudra_device import MudraDevice
from ..libs.library_loader import load_library
from ctypes import CDLL
from typing import Optional

from ..models.callbacks import MudraDelegate

class Mudra(MudraDelegate):
    _instance = None
    _delegate: Optional[MudraDelegate] = None
    ble_service: Optional[BleService] = None


    def __new__(cls, *args, **kwargs):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance

    def __init__(self):
        # Initialize your singleton state here if needed
        self._native_lib: Optional[CDLL] = None
        self._load_native_library()
        self.ble_service = BleService(delegate=self)

    def _load_native_library(self):
        """
        Load the native library for the current platform.
        This will automatically detect the platform and load the correct .dll/.so/.dylib
        """
        try:
            self._native_lib = load_library('MudraSDK', 'MudraSDK')
            print(f"Native library loaded: {self._native_lib}")
        except (FileNotFoundError, OSError) as e:
            # Handle the case where the library is not found or cannot be loaded
            print(f"Warning: Could not load native library: {e}")
            self._native_lib = None

    @property
    def native_lib(self) -> Optional[CDLL]:
        """Get the loaded native library, or None if not loaded."""
        return self._native_lib


    # --- Implementation of MudraDelegate abstract methods ---
    
    def set_delegate(self, delegate: MudraDelegate):
        self._delegate = delegate

    def on_device_discovered(self, device: MudraDevice):
        if self._delegate:
            self._delegate.on_device_discovered(device)

    def on_mudra_device_disconnected(self, device: MudraDevice):
        if self._delegate:
            self._delegate.on_mudra_device_disconnected(device)

    def on_mudra_device_disconnecting(self, device: MudraDevice):
        if self._delegate:
            self._delegate.on_mudra_device_disconnecting(device)

    def on_mudra_device_connected(self, device: MudraDevice):
        if self._delegate:
            self._delegate.on_mudra_device_connected(device)

    def on_mudra_device_connecting(self, device: MudraDevice):
        if self._delegate:
            self._delegate.on_mudra_device_connecting(device)

    def on_mudra_device_connection_failed(self, device: MudraDevice, error: str):
        if self._delegate:
            self._delegate.on_mudra_device_connection_failed(device, error)

    def on_bluetooth_state_changed(self, state: bool):
        if self._delegate:
            self._delegate.on_bluetooth_state_changed(state)

