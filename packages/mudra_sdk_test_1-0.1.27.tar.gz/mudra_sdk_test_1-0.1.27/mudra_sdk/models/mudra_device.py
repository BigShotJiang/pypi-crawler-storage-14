from bleak.backends.device import BLEDevice

class MudraDevice(BLEDevice):
    def __init__(self, ble_device: BLEDevice):
        super().__init__(ble_device.address, ble_device.name, ble_device.details)

