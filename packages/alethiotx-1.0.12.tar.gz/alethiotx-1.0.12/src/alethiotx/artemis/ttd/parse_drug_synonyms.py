import pandas as pd
import urllib.request

def parse_drug_synonyms(url: str = "https://ttd.idrblab.cn/files/download/", file: str = "P1-04-Drug_synonyms.txt"):
    """
    Parse drug synonyms data from the Therapeutic Target Database (TTD).
    This function downloads and parses a drug synonyms file from the TTD database,
    extracting drug IDs, drug names, and their associated synonyms. The data is
    returned as a pandas DataFrame with one row per drug-synonym pair.
    :param url: Base URL path where the TTD files are hosted.
                     Defaults to "https://ttd.idrblab.cn/files/download/".
    :type url: str, optional
    :param file: Name of the drug synonyms file to download.
                      Defaults to "P1-04-Drug_synonyms.txt".
    :type file: str, optional
    :return: A DataFrame containing drug synonym information with columns:
             - 'Drug ID': The TTD drug identifier
             - 'Drug Name': The primary name of the drug
             - 'Synonyms': Individual synonym for the drug (one per row)
    :rtype: pandas.DataFrame
    :raises urllib.error.URLError: If the file cannot be downloaded from the specified URL.
    :raises UnicodeDecodeError: If the downloaded file cannot be decoded as UTF-8.
    
    **Example**
    >>> df = parse_drug_synonyms()
    >>> print(df.head())
      Drug ID     Drug Name         Synonyms
    0  D00001  Acetaminophen     Paracetamol
    1  D00001  Acetaminophen  N-acetyl-p-aminophenol

    .. note::
       The function creates one row per synonym. If a drug has multiple synonyms,
       it will appear in multiple rows. Drugs without synonyms will have a single
       row with None in the 'Synonyms' column.
    """
    # Download the file from URL
    full_url = url + file
    print(f"Downloading file from {full_url}...")
    response = urllib.request.urlopen(full_url)
    lines = [line.decode('utf-8') for line in response.readlines()]
    print(f"Downloaded {len(lines)} lines")
    
    # Find where the actual data starts (after the header)
    data_start_idx = 0
    for idx, line in enumerate(lines):
        if line.strip().startswith('D') and '\t' in line:
            # Check if this looks like actual data (starts with drug ID)
            parts = line.strip().split('\t')
            if len(parts) >= 3 and parts[1] in ['TTDDRUID', 'DRUGNAME', 'SYNONYMS']:
                data_start_idx = idx
                break
    
    # Parse the data
    drug_data = {}
    current_drug_id = None
    
    for line in lines[data_start_idx:]:
        line = line.strip()
        if not line:
            continue
            
        parts = line.split('\t')
        if len(parts) < 3:
            continue
        
        drug_id = parts[0]
        field_type = parts[1]
        value = parts[2]
        
        # Initialize drug entry if new
        if drug_id not in drug_data:
            drug_data[drug_id] = {
                'Drug ID': drug_id,
                'Drug Name': None,
                'Synonyms': []
            }
        
        # Store the data based on field type
        if field_type == 'DRUGNAME':
            drug_data[drug_id]['Drug Name'] = value
        elif field_type == 'SYNONYMS':
            drug_data[drug_id]['Synonyms'].append(value)
    
    # Convert to DataFrame format (one row per synonym)
    rows = []
    for drug_id, data in drug_data.items():
        drug_name = data['Drug Name']
        synonyms = data['Synonyms']
        
        if synonyms:
            # Create one row for each synonym
            for synonym in synonyms:
                rows.append({
                    'Drug ID': drug_id,
                    'Drug Name': drug_name,
                    'Synonyms': synonym
                })
        else:
            # If no synonyms, create one row with empty synonym
            rows.append({
                'Drug ID': drug_id,
                'Drug Name': drug_name,
                'Synonyms': None
            })
    
    df = pd.DataFrame(rows)
    df.rename(columns={
        'Drug ID': 'TTD ID',
        'Drug Name': 'Common name'
    }, inplace=True)
    return df


if __name__ == "__main__":
    # Example usage - download from URL
    df = parse_drug_synonyms()
    df.to_csv("ttd_drug_synonyms_parsed.csv", index=False)
    
    print(f"\nTotal rows: {len(df)}")
    print(f"Unique drugs: {df['TTD ID'].nunique()}")
    print("\nFirst 10 rows:")
    print(df.head(10))
    print("\nDataFrame info:")
    print(df.info())
