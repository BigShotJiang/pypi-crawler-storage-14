


{"color":"rot","highEnergyConsumption":0,"currentEnergyprice":28.2219,"showAnnouncementSign":0}