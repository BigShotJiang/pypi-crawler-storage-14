


{"color":"rot","highEnergyConsumption":0,"currentEnergyprice":28.2208,"showAnnouncementSign":0}