


<div class="row"><div class="col-md-12"><div class="kachelRund"><table class="table table-striped"><tr><th>Fläche</th><th>Bezeichnung</th><th>Zähler-Nr.</th><th>Zeitpunkt</th><th class="alignright">Zählerstand</th><th>Einheit</th></tr></table><div class="col-lg-6 col-lg-offset-3"><div class="alert alert-danger text-center top-buffer" role="alert" id="Infofeld"><span class='glyphicon glyphicon-info-sign'></span> Für diesen Benutzer existieren zum o.g. Datum keine anzuzeigenden Zähler.</div></div><!-- /.col-lg-12 --></div></div></div>