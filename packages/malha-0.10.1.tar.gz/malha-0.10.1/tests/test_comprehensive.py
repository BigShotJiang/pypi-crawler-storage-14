"""
Comprehensive Test Suite for Malha v5.0 - State of the Art Coverage
====================================================================

This test suite provides maximum coverage for the Malha distributed data kernel.
"""

from __future__ import annotations

import json
import os
import shutil
import tempfile
from datetime import UTC, datetime, timedelta
from unittest.mock import AsyncMock, MagicMock

import pytest
from pydantic import Field
from registro import DomainResource, register
from registro import Resource as RegistroResource

from malha import (
    AsyncSQLAlchemyDriver,
    DuckDBDriver,
    Interceptor,
    KuzuActor,
    OptimisticLockError,
    Signal,
    SysOutbox,
    UnifiedDataManager,
)

# ============================================================================
# Domain Resources for Tests
# ============================================================================

class SampleUser(DomainResource):
    """Test user domain resource."""
    name: str = Field(..., min_length=1, max_length=100)
    email: str = Field(default="test@example.com")
    age: int | None = Field(None, ge=0, le=150)
    status: str = Field(default="active")
    tags: list[str] = Field(default_factory=list)

class SampleProduct(DomainResource):
    """Test product domain resource."""
    name: str
    price: float = Field(..., gt=0)
    stock: int = Field(default=0, ge=0)
    category: str = Field(default="general")

register("SampleUser", SampleUser)
register("SampleProduct", SampleProduct)


# ============================================================================
# Fixtures
# ============================================================================

@pytest.fixture
async def temp_dir():
    temp_path = tempfile.mkdtemp()
    yield temp_path
    shutil.rmtree(temp_path, ignore_errors=True)

@pytest.fixture
async def sql_driver(temp_dir):
    db_path = os.path.join(temp_dir, "test.db")
    driver = AsyncSQLAlchemyDriver(f"sqlite+aiosqlite:///{db_path}")
    await driver.create_tables()
    return driver

@pytest.fixture
async def graph_driver(temp_dir):
    graph_path = os.path.join(temp_dir, "test_graph")
    driver = KuzuActor(graph_path)
    yield driver
    await driver.close()

@pytest.fixture
async def analytics_driver(temp_dir):
    db_path = os.path.join(temp_dir, "test.db")
    driver = DuckDBDriver(db_path)
    yield driver
    driver.close()

@pytest.fixture
async def kernel(sql_driver, graph_driver, analytics_driver):
    manager = UnifiedDataManager(
        sql_driver=sql_driver, graph_driver=graph_driver,
        analytics_driver=analytics_driver, enable_monitoring=False, node_id="test-node",
    )
    await manager.boot()
    yield manager
    await manager.close()


# ============================================================================
# Tests: DomainResource Basics
# ============================================================================

class TestDomainResourceBasics:
    def test_create_user(self):
        user = SampleUser(name="Alice", email="alice@example.com", age=25)
        assert user.name == "Alice"
        assert user.rid.startswith("ri.")
        assert user.version == 1

    def test_user_validation_name_empty(self):
        with pytest.raises(ValueError):
            SampleUser(name="")

    def test_user_validation_age_negative(self):
        with pytest.raises(ValueError):
            SampleUser(name="Charlie", age=-5)


# ============================================================================
# Tests: Envelope Conversion
# ============================================================================

class TestEnvelopeConversion:
    def test_to_envelope(self):
        user = SampleUser(name="Alice", email="alice@example.com", age=25)
        envelope = user.to_envelope()
        assert isinstance(envelope, RegistroResource)
        assert envelope.rid == user.rid

    def test_from_envelope(self):
        envelope = RegistroResource(
            rid="ri.test.prod.testuser.123", version=1,
            meta_tags={"name": "Bob", "email": "bob@example.com", "age": 30},
        )
        user = SampleUser.from_envelope(envelope)
        assert user.name == "Bob"
        assert user.age == 30


# ============================================================================
# Tests: Signal System
# ============================================================================

class TestSignalSystem:
    @pytest.mark.asyncio
    async def test_signal_connect(self):
        signal = Signal("test")
        handler = MagicMock()
        signal.connect(handler)
        assert handler in signal._handlers

    @pytest.mark.asyncio
    async def test_signal_emit_sync(self):
        signal = Signal("test")
        handler = MagicMock()
        signal.connect(handler)
        await signal.emit({"test": "data"}, background=False)
        handler.assert_called_once_with({"test": "data"})

    @pytest.mark.asyncio
    async def test_signal_emit_async(self):
        signal = Signal("test")
        async_handler = AsyncMock()
        signal.connect(async_handler)
        await signal.emit({"test": "data"}, background=False)
        async_handler.assert_called_once_with({"test": "data"})


# ============================================================================
# Tests: Interceptor System
# ============================================================================

class TestInterceptorSystem:
    def test_interceptor_abstract(self):
        with pytest.raises(TypeError):
            Interceptor()

    @pytest.mark.asyncio
    async def test_interceptor_on_write(self, kernel):
        intercepted = []
        class WriteInterceptor(Interceptor):
            async def on_write(self, obj, agent=None): intercepted.append(obj)
            async def on_read(self, obj, agent=None): return obj
        kernel.add_interceptor(WriteInterceptor())
        user = SampleUser(name="Alice", email="alice@example.com")
        await kernel.save_versioned(user)
        assert len(intercepted) == 1


# ============================================================================
# Tests: BaseRepository
# ============================================================================

class TestBaseRepository:
    @pytest.mark.asyncio
    async def test_repository_create(self, kernel):
        repo = kernel.get_repository(SampleUser)
        async with await kernel.sql_driver.get_session() as session:
            user = await repo.create(session, {"name": "Alice", "email": "alice@example.com"})
            await session.commit()
        assert user.name == "Alice"
        assert user.id is not None

    @pytest.mark.asyncio
    async def test_repository_get_by_rid(self, kernel):
        repo = kernel.get_repository(SampleUser)
        async with await kernel.sql_driver.get_session() as session:
            created = await repo.create(session, {"name": "Bob", "email": "bob@example.com"})
            await session.commit()
            found = await repo.get(session, rid=created.rid)
        assert found.rid == created.rid

    @pytest.mark.asyncio
    async def test_repository_update(self, kernel):
        repo = kernel.get_repository(SampleUser)
        async with await kernel.sql_driver.get_session() as session:
            user = await repo.create(session, {"name": "Diana", "age": 28})
            await session.commit()
            updated = await repo.update(session, id=user.id, data={"age": 29})
            await session.commit()
        assert updated.age == 29
        assert updated.version == 2

    @pytest.mark.asyncio
    async def test_repository_optimistic_lock(self, kernel):
        repo = kernel.get_repository(SampleUser)
        async with await kernel.sql_driver.get_session() as session:
            user = await repo.create(session, {"name": "Eve"})
            await session.commit()
            with pytest.raises(OptimisticLockError):
                await repo.update(session, id=user.id, data={"age": 25}, expected_version=999)

    @pytest.mark.asyncio
    async def test_repository_delete(self, kernel):
        repo = kernel.get_repository(SampleUser)
        async with await kernel.sql_driver.get_session() as session:
            user = await repo.create(session, {"name": "Frank"})
            await session.commit()
            deleted = await repo.delete(session, id=user.id)
            await session.commit()
            found = await repo.get(session, id=user.id)
        assert deleted is True
        assert found is None

    @pytest.mark.asyncio
    async def test_repository_list(self, kernel):
        repo = kernel.get_repository(SampleUser)
        async with await kernel.sql_driver.get_session() as session:
            for i in range(5):
                await repo.create(session, {"name": f"User {i}"})
            await session.commit()
            users = await repo.list(session, skip=0, limit=10)
        assert len(users) == 5


# ============================================================================
# Tests: Time Travel (SCD Type 2)
# ============================================================================

class TestTimeTravel:
    @pytest.mark.asyncio
    async def test_get_history_empty(self, kernel):
        repo = kernel.get_repository(SampleUser)
        async with await kernel.sql_driver.get_session() as session:
            history = await repo.get_history(session, rid="ri.test.nonexistent")
        assert len(history) == 0

    @pytest.mark.asyncio
    async def test_get_history_single(self, kernel):
        user = SampleUser(name="Grace", email="grace@example.com")
        saved = await kernel.save_versioned(user)
        repo = kernel.get_repository(SampleUser)
        async with await kernel.sql_driver.get_session() as session:
            history = await repo.get_history(session, rid=saved.rid)
        assert len(history) == 1

    @pytest.mark.asyncio
    async def test_at_time_current(self, kernel):
        user = SampleUser(name="Ivy", email="ivy@example.com")
        saved = await kernel.save_versioned(user)
        repo = kernel.get_repository(SampleUser)
        now = datetime.now(UTC)
        async with await kernel.sql_driver.get_session() as session:
            found = await repo.get(session, rid=saved.rid, at_time=now)
        assert found is not None

    @pytest.mark.asyncio
    async def test_at_time_past(self, kernel):
        user = SampleUser(name="Kate", email="kate@example.com")
        saved = await kernel.save_versioned(user)
        repo = kernel.get_repository(SampleUser)
        past = datetime.now(UTC) - timedelta(days=365)
        async with await kernel.sql_driver.get_session() as session:
            found = await repo.get(session, rid=saved.rid, at_time=past)
        assert found is None


# ============================================================================
# Tests: save_versioned
# ============================================================================

class TestSaveVersioned:
    @pytest.mark.asyncio
    async def test_save_versioned_new(self, kernel):
        user = SampleUser(name="Alice", email="alice@example.com")
        saved = await kernel.save_versioned(user)
        assert saved.valid_from is not None
        assert saved.valid_to is None

    @pytest.mark.asyncio
    async def test_save_versioned_creates_new_version(self, kernel):
        user = SampleUser(name="Bob", email="bob@example.com", age=30)
        v1 = await kernel.save_versioned(user)
        rid = v1.rid

        # Update the returned object and save again
        # The save_versioned should create a new version with same RID
        v1.age = 31
        v2 = await kernel.save_versioned(v1)

        repo = kernel.get_repository(SampleUser)
        async with await kernel.sql_driver.get_session() as session:
            history = await repo.get_history(session, rid=rid)
        assert len(history) == 2

    @pytest.mark.asyncio
    async def test_save_versioned_origin_local(self, kernel):
        user = SampleUser(name="Charlie", email="charlie@example.com")
        saved = await kernel.save_versioned(user, origin="local")
        async with await kernel.sql_driver.get_session() as session:
            from sqlalchemy import select
            stmt = select(SysOutbox).where(SysOutbox.rid == saved.rid)
            result = await session.execute(stmt)
            events = result.scalars().all()
        assert len(events) >= 1

    @pytest.mark.asyncio
    async def test_save_versioned_origin_remote(self, kernel):
        user = SampleUser(name="Diana", email="diana@example.com")
        saved = await kernel.save_versioned(user, origin="remote-node")
        async with await kernel.sql_driver.get_session() as session:
            from sqlalchemy import select
            stmt = select(SysOutbox).where(SysOutbox.rid == saved.rid)
            result = await session.execute(stmt)
            events = result.scalars().all()
        assert len(events) == 0


# ============================================================================
# Tests: delete_versioned
# ============================================================================

class TestDeleteVersioned:
    @pytest.mark.asyncio
    async def test_delete_versioned_closes(self, kernel):
        user = SampleUser(name="Eve", email="eve@example.com")
        saved = await kernel.save_versioned(user)
        await kernel.delete_versioned(saved)
        async with await kernel.sql_driver.get_session() as session:
            from sqlalchemy import select
            stmt = select(RegistroResource).where(
                RegistroResource.rid == saved.rid, RegistroResource.valid_to.is_(None),
            )
            result = await session.execute(stmt)
            active = result.scalars().all()
        assert len(active) == 0


# ============================================================================
# Tests: Outbox Pattern
# ============================================================================

class TestOutboxPattern:
    @pytest.mark.asyncio
    async def test_outbox_item_created(self, kernel):
        user = SampleUser(name="Frank", email="frank@example.com")
        saved = await kernel.save_versioned(user, origin="local")
        async with await kernel.sql_driver.get_session() as session:
            from sqlalchemy import select
            stmt = select(SysOutbox).where(SysOutbox.rid == saved.rid)
            result = await session.execute(stmt)
            items = result.scalars().all()
        assert len(items) >= 1
        assert items[0].operation == "UPSERT"

    @pytest.mark.asyncio
    async def test_outbox_payload(self, kernel):
        user = SampleUser(name="Grace", email="grace@example.com", age=30)
        saved = await kernel.save_versioned(user, origin="local")
        async with await kernel.sql_driver.get_session() as session:
            from sqlalchemy import select
            stmt = select(SysOutbox).where(SysOutbox.rid == saved.rid)
            result = await session.execute(stmt)
            item = result.scalars().first()
        payload = json.loads(item.payload)
        assert payload["name"] == "Grace"
        assert payload["age"] == 30
