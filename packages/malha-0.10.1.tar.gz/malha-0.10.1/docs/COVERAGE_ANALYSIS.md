# Coverage Analysis: Path to 85%

## Current Status (80% Overall)

| Module | Coverage | Missing Lines |
|--------|----------|---------------|
| `malha/__init__.py` | 100% | - |
| `malha/malha.py` | 93% | 46 lines |
| `malha/instrumentation.py` | 92% | 8 lines |
| `malha/monitor.py` | 88% | 13 lines |
| `malha/drivers/__init__.py` | 60% | 2 lines |
| `malha/drivers/synapse.py` | 40% | 146 lines |
| `malha/protos/*` | 50-69% | Generated files |

## Analysis by Module

### 1. `malha/malha.py` (93% → Target: 95%)

**Uncovered Lines:**
- Lines 303, 329, 373, 386: Edge cases in repository create/update
- Lines 491, 503: Error handling in SQL operations
- Lines 620, 632, 636-643, 649, 673-675: Graph driver error paths
- Lines 751: Analytics driver edge case
- Lines 884-885, 896-897: Interceptor edge cases
- Lines 985: Save method edge case
- Lines 1068: Version check edge case
- Lines 1197-1214: Delete method paths
- Lines 1228-1229, 1280-1287: Outbox edge cases
- Lines 1515, 1558: Fork/close edge cases
- Lines 1666-1668: Outbox processor loop

**How to Cover:**
```python
# Test repository with raw data (not dict/BaseModel)
async def test_create_with_raw_data():
    repo.create(session, some_raw_object)

# Test graph driver failures
async def test_graph_upsert_failure():
    with patch.object(graph, 'upsert_node', side_effect=Exception):
        await kernel.save_versioned(obj)

# Test delete with version check
async def test_delete_with_expected_version():
    await kernel.delete(Model, id, expected_version=2)
```

### 2. `malha/monitor.py` (88% → Target: 92%)

**Uncovered Lines:**
- Lines 111-112: Initialization edge case
- Lines 160: Buffer lock edge case
- Lines 194-195, 210-211: Summary calculation paths
- Lines 252-254: Query edge case
- Lines 318-320: Stop without task

**How to Cover:**
```python
# Test monitor with empty metrics
async def test_get_summary_empty():
    summary = monitor.get_summary(hours=0)

# Test monitor query with filters
async def test_query_with_filters():
    await monitor.query(operation="save", status="error")
```

### 3. `malha/instrumentation.py` (92% → Target: 95%)

**Uncovered Lines:**
- Lines 154-155: Arrow ingestion fallback
- Lines 171-172: Flush error handling
- Lines 199: Periodic flush edge case
- Lines 230-240: Stop without start

**How to Cover:**
```python
# Test flush with Arrow failure (fallback to SQL)
async def test_flush_arrow_fallback():
    with patch('pyarrow.Table.from_pydict', side_effect=Exception):
        await instr._flush_metrics()

# Test double stop
async def test_double_stop():
    await instr.stop()
    await instr.stop()
```

### 4. `malha/drivers/synapse.py` (40% → Target: 60%)

**Challenge:** Requires actual gRPC connections for full coverage.

**Uncovered Sections:**
- Lines 42-45: Import error handling
- Lines 79-147: SynapseServicer methods
- Lines 158-275: Stream handling
- Lines 339-344, 397-427: Broadcast logic
- Lines 452-455, 492, 508-518: Connection management
- Lines 529-567, 582: Gossip protocol

**How to Cover:**
```python
# Mock gRPC channel and stub
async def test_broadcast_with_mock_channel():
    with patch('grpc.aio.insecure_channel') as mock_channel:
        mock_stub = AsyncMock()
        mock_channel.return_value.__aenter__.return_value = mock_stub
        await driver.broadcast(event)

# Test servicer methods directly
async def test_servicer_replicate():
    servicer = SynapseServicer(mock_kernel, "node-1")
    event = synapse_pb2.ReplicationEvent(...)
    await servicer.Replicate(event, mock_context)
```

### 5. `malha/drivers/__init__.py` (60% → Target: 100%)

**Uncovered Lines:**
- Lines 17-19: Conditional import when grpcio not available

**How to Cover:**
```python
# Test import without grpcio
def test_import_without_grpcio():
    with patch.dict('sys.modules', {'grpcio': None}):
        importlib.reload(malha.drivers)
        assert SynapseDriver is None
```

## Priority Actions for 85% Coverage

### High Impact (Easy)
1. Add tests for `delete()` method with version check
2. Add tests for monitor query with filters
3. Add tests for instrumentation Arrow fallback

### Medium Impact (Moderate)
4. Mock graph driver failures
5. Test outbox processor edge cases
6. Test fork with existing data

### Low Impact (Complex)
7. Mock gRPC for Synapse tests
8. Test all error handling paths

## Recommended Test Additions

```python
# tests/test_coverage_85.py

class TestDeleteWithVersion:
    async def test_delete_with_expected_version(self, kernel):
        saved = await kernel.save_versioned(obj)
        await kernel.delete(Model, saved.id, expected_version=1)

class TestMonitorQueries:
    async def test_query_by_operation(self, monitor):
        await monitor.collect_metric(operation="save", ...)
        results = await monitor.query(operation="save")
        
class TestInstrumentationFallback:
    async def test_arrow_fallback_to_sql(self, instr):
        with patch('pyarrow.Table.from_pydict', side_effect=Exception):
            await instr._flush_metrics()  # Should use SQL fallback

class TestSynapseWithMocks:
    async def test_broadcast_success(self):
        with patch('grpc.aio.insecure_channel'):
            await driver.broadcast(event)
```

## Coverage Goals

| Milestone | Coverage | Tests |
|-----------|----------|-------|
| Current | 80% | 195 |
| Phase 1 | 82% | ~205 |
| Phase 2 | 85% | ~220 |
| Stretch | 90% | ~250 |

## Notes

- **Proto files** (`synapse_pb2.py`, `synapse_pb2_grpc.py`) are auto-generated and shouldn't be tested directly
- **Synapse driver** coverage is limited by gRPC dependencies - consider integration tests
- Focus on **malha.py** and **monitor.py** for highest ROI
