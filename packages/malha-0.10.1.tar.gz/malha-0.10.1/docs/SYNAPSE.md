# Synapse - P2P Mesh Replication for Malha

## Overview

**Synapse** is Malha's distributed replication layer that transforms it from a local data manager into a **distributed kernel** with eventual consistency guarantees. It implements a peer-to-peer mesh network using gRPC bidirectional streaming.

## Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                    Malha Kernel (Node A)                    │
├─────────────────────────────────────────────────────────────┤
│  UnifiedDataManager                                         │
│    ├─ SQL Driver (Pessimistic Locking)                     │
│    ├─ Graph Driver (Kùzu)                                  │
│    ├─ Analytics Driver (DuckDB)                            │
│    └─ Replication Driver (Synapse) ◄─────┐                 │
│         ├─ gRPC Server (port 50051)      │                 │
│         └─ gRPC Clients (to peers)       │                 │
└──────────────────────────────────────────┼─────────────────┘
                                           │
                    ┌──────────────────────┼──────────────────┐
                    │                      │                  │
                    ▼                      ▼                  ▼
            ┌───────────────┐      ┌───────────────┐  ┌───────────────┐
            │  Node B       │      │  Node C       │  │  Node D       │
            │  (Peer)       │      │  (Peer)       │  │  (Peer)       │
            └───────────────┘      └───────────────┘  └───────────────┘
```

## Key Features

### 1. **Pessimistic Locking (SCD2 Hardening)**
- Uses `SELECT FOR UPDATE` to prevent race conditions
- Guarantees atomic version rotation in concurrent environments
- No duplicate active versions under high load

### 2. **Loop Prevention**
- Tracks `origin_node` for each event
- Remote events are NOT re-broadcast (prevents infinite loops)
- Idempotent event processing with transaction ID deduplication

### 3. **Resilience (DLQ + Exponential Backoff)**
- Dead Letter Queue for events that fail after 5 retries
- Exponential backoff: 2^n seconds between retries
- Critical errors don't block the entire outbox queue

### 4. **Dual-Write Consistency**
- SQL commit + Outbox insertion in same transaction (ACID)
- Graph sync + P2P broadcast happen asynchronously
- Eventual consistency guaranteed via outbox pattern

## Installation

### Basic Installation (without Synapse)
```bash
pip install malha
```

### With Synapse Support
```bash
pip install malha[synapse]
```

This installs:
- `grpcio>=1.60.0`
- `grpcio-tools>=1.60.0`
- `protobuf>=4.25.0`

### Compile Protocol Buffers
```bash
python scripts/compile_protos.py
```

Or manually:
```bash
python -m grpc_tools.protoc \
  -I. \
  --python_out=. \
  --grpc_python_out=. \
  malha/protos/synapse.proto
```

## Usage

### Single Node (No Replication)
```python
import asyncio
from malha import connect

async def main():
    # Standard Malha usage - no replication
    manager = await connect(
        url="sqlite+aiosqlite:///data.db",
        kuzu_path="data/kuzu"
    )
    
    # Use normally...
    await manager.close()

asyncio.run(main())
```

### Distributed Cluster (3 Nodes)

#### Node 1 (192.168.1.10)
```python
import asyncio
from malha import connect
from malha.drivers.synapse import SynapseDriver

async def main():
    # Create Synapse driver
    synapse = SynapseDriver(
        kernel_ref=None,  # Will be set by connect()
        node_id="node-1",
        port=50051,
        peers=[
            "192.168.1.11:50051",  # Node 2
            "192.168.1.12:50051",  # Node 3
        ]
    )
    
    # Connect with replication
    manager = await connect(
        url="sqlite+aiosqlite:///node1.db",
        kuzu_path="data/kuzu_node1",
        replication_driver=synapse
    )
    
    # Synapse driver is automatically started
    # All local writes will be replicated to peers
    
    # ... your application logic ...
    
    await manager.close()

asyncio.run(main())
```

#### Node 2 (192.168.1.11)
```python
synapse = SynapseDriver(
    kernel_ref=None,
    node_id="node-2",
    port=50051,
    peers=[
        "192.168.1.10:50051",  # Node 1
        "192.168.1.12:50051",  # Node 3
    ]
)

manager = await connect(
    url="sqlite+aiosqlite:///node2.db",
    kuzu_path="data/kuzu_node2",
    replication_driver=synapse
)
```

#### Node 3 (192.168.1.12)
```python
synapse = SynapseDriver(
    kernel_ref=None,
    node_id="node-3",
    port=50051,
    peers=[
        "192.168.1.10:50051",  # Node 1
        "192.168.1.11:50051",  # Node 2
    ]
)

manager = await connect(
    url="sqlite+aiosqlite:///node3.db",
    kuzu_path="data/kuzu_node3",
    replication_driver=synapse
)
```

## How It Works

### Write Path (Local → Remote)

1. **User writes data**:
   ```python
   await manager.save_versioned(resource)
   ```

2. **Pessimistic Lock** (SQL):
   ```sql
   SELECT * FROM resources WHERE rid = ? AND valid_to IS NULL FOR UPDATE;
   ```

3. **Atomic Commit** (SQL Transaction):
   - Close old version (`valid_to = NOW()`)
   - Insert new version
   - Insert outbox event with `origin_node = "local"`

4. **Outbox Processor** (Background Task):
   - Reads pending events
   - Syncs to Graph (Kùzu)
   - Broadcasts to Synapse (if configured)

5. **Synapse Broadcast** (gRPC):
   - Sends `ReplicationEvent` to all peers
   - Waits for `Ack` from each peer

### Read Path (Remote → Local)

1. **Peer sends event** via gRPC stream

2. **SynapseServicer receives**:
   - Checks deduplication cache
   - Deserializes payload

3. **Applies locally**:
   ```python
   await kernel.save_versioned(
       obj=resource,
       origin="node-2"  # ← Prevents re-broadcast
   )
   ```

4. **Sends Ack** back to peer

## Configuration

### Environment Variables
```bash
# Node identity
export MALHA_NODE_ID="node-1"

# Synapse port
export MALHA_SYNAPSE_PORT=50051

# Peer list (comma-separated)
export MALHA_PEERS="192.168.1.11:50051,192.168.1.12:50051"
```

### Programmatic Configuration
```python
import os

synapse = SynapseDriver(
    kernel_ref=None,
    node_id=os.getenv("MALHA_NODE_ID", "node-1"),
    port=int(os.getenv("MALHA_SYNAPSE_PORT", "50051")),
    peers=os.getenv("MALHA_PEERS", "").split(",")
)
```

## Monitoring

### Check Outbox Status
```python
from sqlmodel import select
from malha.malha import SysOutbox

async with manager.sql.get_session() as session:
    # Pending events
    pending = await session.execute(
        select(SysOutbox).where(SysOutbox.status == "PENDING")
    )
    print(f"Pending: {len(pending.scalars().all())}")
    
    # Dead letter queue
    dlq = await session.execute(
        select(SysOutbox).where(SysOutbox.status == "DEAD_LETTER")
    )
    print(f"DLQ: {len(dlq.scalars().all())}")
```

### Health Check
```python
# TODO: Implement health check endpoint
# For now, check logs for:
# - "[Synapse] Server started on port 50051"
# - "[Synapse] Connected to peer X"
```

## Performance Tuning

### Outbox Batch Size
Adjust in `_process_outbox()`:
```python
.limit(100)  # Default: 100 events per batch
```

### Retry Policy
Modify in `_process_outbox()`:
```python
if item.retries > 5:  # Default: 5 retries
    # Move to DLQ
```

### Broadcast Timeout
Adjust in `broadcast()`:
```python
await asyncio.wait_for(..., timeout=5.0)  # Default: 5 seconds
```

## Troubleshooting

### Proto Compilation Errors
```bash
# Ensure grpcio-tools is installed
pip install grpcio-tools

# Recompile
python scripts/compile_protos.py
```

### Connection Refused
- Check firewall rules (port 50051)
- Verify peer addresses are correct
- Ensure all nodes are running

### Infinite Loops
- Check `origin_node` tracking in logs
- Verify `save_versioned()` uses `origin` parameter correctly

### Dead Letter Queue Growing
- Investigate errors in DLQ items:
  ```sql
  SELECT * FROM sys_outbox WHERE status = 'DEAD_LETTER';
  ```
- Common causes:
  - Network partitions
  - Schema mismatches
  - Corrupted payloads

## Comparison: Malha vs. Traditional Databases

| Feature | Malha + Synapse | PostgreSQL | Cassandra |
|---------|----------------|------------|-----------|
| **Consistency** | Eventual (tunable) | Strong (ACID) | Eventual (tunable) |
| **Replication** | P2P Mesh | Leader-Follower | Ring (Gossip) |
| **Schema** | Flexible (Pydantic) | Rigid (SQL DDL) | Flexible (CQL) |
| **Graph Queries** | Native (Kùzu) | Extension (pg_graph) | No |
| **Analytics** | Native (DuckDB) | Extension (pg_analytics) | Spark integration |
| **Deployment** | Single binary | Server process | Cluster (3+ nodes) |

## Roadmap

- [ ] **TLS/mTLS Support**: Secure peer-to-peer communication
- [ ] **Conflict Resolution**: Custom merge strategies for concurrent writes
- [ ] **Compression**: Reduce network bandwidth (e.g., Snappy, LZ4)
- [ ] **Metrics**: Prometheus-compatible metrics endpoint
- [ ] **Dynamic Peer Discovery**: Service discovery via Consul/etcd
- [ ] **Partial Replication**: Replicate only specific RID prefixes
- [ ] **Causal Consistency**: Vector clocks for causal ordering

## References

- [Outbox Pattern](https://microservices.io/patterns/data/transactional-outbox.html)
- [gRPC Streaming](https://grpc.io/docs/what-is-grpc/core-concepts/#bidirectional-streaming-rpc)
- [SCD Type 2](https://en.wikipedia.org/wiki/Slowly_changing_dimension#Type_2:_add_new_row)
- [Pessimistic Locking](https://www.postgresql.org/docs/current/explicit-locking.html#LOCKING-ROWS)

## License

MIT License - See LICENSE file for details.
