"""
Malha Drivers Package
=====================

This package contains pluggable drivers for extending Malha's capabilities:

- synapse: P2P mesh replication driver for distributed synchronization

Usage:
    from malha.drivers.synapse import SynapseDriver
"""

__all__ = ["SynapseDriver"]

try:
    from .synapse import SynapseDriver
except ImportError:
    # gRPC dependencies not installed
    SynapseDriver = None
