"""Advanced Instrumentation - Metrics Collection and Flush to DuckDB.

This module implements the bridge between in-memory metrics collection
and persistent storage in DuckDB for time-series analysis.

Key Features:
- In-memory metrics collection (counters, gauges, histograms)
- Zero-copy ingestion via Arrow
- Periodic flush to DuckDB
- Time-series storage for trend analysis

Architecture:
    InMemoryMetrics (RAM)
        ↓
    KernelInstrumentation (Bridge)
        ↓
    DuckDB (Persistent Storage)

Usage:
    # Initialize
    instrumentation = KernelInstrumentation(analytics_driver)
    await instrumentation.start()
    
    # Collect metrics
    metrics.increment("save.count")
    metrics.set_gauge("outbox.lag", 42)
    with metrics.timer("save.latency"):
        await do_work()
    
    # Metrics auto-flush to DuckDB every interval
"""

import asyncio
import logging
import time
from collections import defaultdict
from contextlib import contextmanager
from datetime import UTC, datetime
from typing import Any

logger = logging.getLogger(__name__)


class InMemoryMetrics:
    """In-memory metrics collector with counters, gauges, and histograms."""

    def __init__(self):
        self._counters: dict[str, int] = defaultdict(int)
        self._gauges: dict[str, float] = {}
        self._histograms: dict[str, list[float]] = defaultdict(list)
        self._lock = asyncio.Lock()

    def increment(self, name: str, value: int = 1) -> None:
        """Increment a counter."""
        self._counters[name] += value

    def set_gauge(self, name: str, value: float) -> None:
        """Set a gauge value (current state)."""
        self._gauges[name] = value

    def record_histogram(self, name: str, value: float) -> None:
        """Record a value in a histogram (for percentiles)."""
        self._histograms[name].append(value)

    @contextmanager
    def timer(self, name: str):
        """Context manager for timing operations."""
        start = time.perf_counter()
        try:
            yield
        finally:
            duration_ms = (time.perf_counter() - start) * 1000
            self.record_histogram(name, duration_ms)

    async def get_snapshot(self) -> dict[str, Any]:
        """Get a snapshot of all metrics."""
        async with self._lock:
            snapshot = {
                "counters": dict(self._counters),
                "gauges": dict(self._gauges),
                "histograms": {},
            }

            # Calculate histogram stats
            for name, values in self._histograms.items():
                if values:
                    sorted_vals = sorted(values)
                    snapshot["histograms"][name] = {
                        "count": len(values),
                        "avg": sum(values) / len(values),
                        "min": sorted_vals[0],
                        "max": sorted_vals[-1],
                        "p50": sorted_vals[len(sorted_vals) // 2],
                        "p95": sorted_vals[int(len(sorted_vals) * 0.95)] if len(sorted_vals) > 1 else sorted_vals[0],
                        "p99": sorted_vals[int(len(sorted_vals) * 0.99)] if len(sorted_vals) > 1 else sorted_vals[0],
                    }

            return snapshot

    async def reset(self) -> None:
        """Reset all metrics (optional, for cumulative vs snapshot)."""
        async with self._lock:
            self._counters.clear()
            self._gauges.clear()
            self._histograms.clear()


# Global metrics instance
metrics = InMemoryMetrics()


class KernelInstrumentation:
    """Bridge between in-memory metrics and DuckDB storage.
    
    Periodically flushes metrics from RAM to DuckDB using Arrow for zero-copy.
    """

    def __init__(
        self,
        analytics_driver,
        interval: int = 15,
        node_id: str = "local",
    ):
        """Initialize instrumentation.
        
        Args:
            analytics_driver: DuckDB driver for storage
            interval: Flush interval in seconds
            node_id: Node identifier for distributed deployments
        """
        self.analytics = analytics_driver
        self.interval = interval
        self.node_id = node_id
        self._running = False
        self._task: asyncio.Task | None = None

        # Initialize sys_metrics table
        self._init_table()

    def _init_table(self) -> None:
        """Create sys_metrics table if it doesn't exist."""
        try:
            self.analytics.conn.execute("""
                CREATE TABLE IF NOT EXISTS sys_metrics (
                    ts TIMESTAMP,
                    metric VARCHAR,
                    type VARCHAR,
                    value DOUBLE,
                    tags VARCHAR,
                    node_id VARCHAR
                )
            """)
            logger.info("[Instrumentation] sys_metrics table initialized")
        except Exception as e:
            logger.error(f"[Instrumentation] Failed to initialize table: {e}")

    async def start(self) -> None:
        """Start periodic flush loop."""
        self._running = True
        self._task = asyncio.create_task(self._flush_loop())
        logger.info(f"[Instrumentation] Started (interval={self.interval}s)")

    async def _flush_loop(self) -> None:
        """Periodic flush: RAM → Arrow → DuckDB."""
        while self._running:
            try:
                await asyncio.sleep(self.interval)
                await self._flush_metrics()
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error(f"[Instrumentation] Flush error: {e}")

    async def _flush_metrics(self) -> None:
        """Flush current metrics to DuckDB."""
        try:
            # 1. Get snapshot
            snapshot = await metrics.get_snapshot()
            now = datetime.now(UTC)

            # 2. Transform to tabular format
            rows = []

            # Counters
            for name, val in snapshot["counters"].items():
                rows.append((now, name, "counter", float(val), "{}", self.node_id))

            # Gauges
            for name, val in snapshot["gauges"].items():
                rows.append((now, name, "gauge", float(val), "{}", self.node_id))

            # Histograms (avg, p95, p99)
            for name, stats in snapshot["histograms"].items():
                rows.append((now, f"{name}_avg", "histogram", stats["avg"], "{}", self.node_id))
                rows.append((now, f"{name}_p95", "histogram", stats["p95"], "{}", self.node_id))
                rows.append((now, f"{name}_p99", "histogram", stats["p99"], "{}", self.node_id))

            if not rows:
                return

            # 3. Zero-copy ingestion via Arrow
            try:
                import pyarrow as pa

                schema = pa.schema([
                    ("ts", pa.timestamp("us", tz="UTC")),
                    ("metric", pa.string()),
                    ("type", pa.string()),
                    ("value", pa.float64()),
                    ("tags", pa.string()),
                    ("node_id", pa.string()),
                ])

                table = pa.Table.from_pydict({
                    "ts": [r[0] for r in rows],
                    "metric": [r[1] for r in rows],
                    "type": [r[2] for r in rows],
                    "value": [r[3] for r in rows],
                    "tags": [r[4] for r in rows],
                    "node_id": [r[5] for r in rows],
                }, schema=schema)

                # Ingest via DuckDB
                await self.analytics.ingest_arrow("sys_metrics", table)

                logger.debug(f"[Instrumentation] Flushed {len(rows)} metrics")

            except ImportError:
                # Fallback: Direct SQL insert (slower)
                values_str = ", ".join([
                    f"('{r[0].isoformat()}', '{r[1]}', '{r[2]}', {r[3]}, '{r[4]}', '{r[5]}')"
                    for r in rows
                ])

                self.analytics.conn.execute(f"""
                    INSERT INTO sys_metrics (ts, metric, type, value, tags, node_id)
                    VALUES {values_str}
                """)

                logger.debug(f"[Instrumentation] Flushed {len(rows)} metrics (SQL fallback)")

        except Exception as e:
            logger.error(f"[Instrumentation] Failed to flush: {e}")

    async def stop(self) -> None:
        """Stop instrumentation and flush remaining metrics."""
        self._running = False

        if self._task:
            self._task.cancel()
            try:
                await self._task
            except asyncio.CancelledError:
                pass

        # Final flush
        await self._flush_metrics()

        logger.info("[Instrumentation] Stopped")
