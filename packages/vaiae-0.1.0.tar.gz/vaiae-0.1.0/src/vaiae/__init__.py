from .core import Core


class vaiae(Core):
    pass
