import logging
import logging.config
import yaml
from importlib.metadata import entry_points
from importlib.resources import files

import click

from .uber import UberShell

logger = logging.getLogger(__name__)


# Uber Shell ==================================================
@click.command()
@click.option(
    "-l",
    "--log-level",
    default="INFO",
    show_default=True,
    type=click.Choice(["DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"]),
    help="Set logging level.",
)
@click.option("-d", "--debug", is_flag=True)
def uber(log_level, debug):
    """
    Main script entry point for uber uber shell.

    Use uber -l INFO for REPL loop.
    """
    # logging
    if debug:
        logger_config = "logconfig.yaml"
        with (files("uber_shell.configurations") / logger_config).open("r") as f:
            cfg = yaml.safe_load(f)
        cfg["loggers"]["uber_shell"]["level"] = log_level
        logging.config.dictConfig(cfg)
        test_logger = logging.getLogger("archivum.TEST")
        test_logger.debug("Uber logger test @ DEBUG")
        test_logger.info("Uber logger test @ INFO")
        test_logger.warning("Uber logger test @ WARNING")
        test_logger.error("Uber logger test @ ERROR")

    shell = UberShell("uber", debug=debug)

    # Auto-Discover Plugins via entry points
    # 'group' matches the string in pyproject.toml
    discovered_plugins = entry_points(group="uber.plugins")

    for plugin in discovered_plugins:
        try:
            plugin_group = plugin.load()
            shell.register_plugin(plugin.name, plugin_group)

            if debug:
                click.echo(f"Loading plugin: {plugin.name}")
        except Exception as e:
            click.echo(f"Failed to load plugin {plugin.name}: {e}", err=True)

    shell.start()
