"""
UberShell Engine
================

This module provides the core REPL (Read-Eval-Print Loop) logic for the 'Uber Uber' interface.
It implements a Host/Plugin pattern allowing a central application (Host) to aggregate
commands from multiple independent CLI packages (Plugins) via Python Entry Points.

Core Concepts
-------------
1. **The Engine (`UberShell`)**: A reusable class that handles the prompt, history,
   tab-completion, system built-ins (cd, cls), and command dispatch.

2. **The Plugin (e.g., `quarto_tools`)**: A standalone CLI app. It advertises itself
   to the host using `[project.entry-points]` in `pyproject.toml`.

3. **The Host (e.g., `uber`)**: The master CLI. It uses `importlib.metadata` to
   discover all registered plugins and loads their commands into the shell.

4. **Uber Uber shell** implemented (moved from great2.uber) with self-discovery.

Implementation Guide
--------------------

### 1. Plugin Setup (The "Child" Package)
To make a package (e.g., `quarto_tools`) discoverable by `uber`:

A. **Edit `pyproject.toml`**:
   Add an entry point under the group `uber.plugins`. This can coexist safely
   with `[project.scripts]`.

   ```toml
   [project.scripts]
   qt = "quarto_tools.cli:entry"  # Creates qt.exe for Windows CMD

   [project.entry-points."uber.plugins"]
   qt = "quarto_tools.cli:entry" # Advertises 'qt' plugin to uber

B. **Install**:
Run `pip install -e .` (or `pip install .`) to register the entry point.

### 2. Host Setup (The "Parent" Package)

In `uber/cli.py`, use `importlib` to auto-load plugins.

### 3. Shortcuts (Python Functions)

Register arbitrary Python functions using lambdas.

```python
from .book_search import bk_search_work
shell.register_command("bk", lambda line: bk_search_work(tablefmt="simple"))
```

## Dependencies

  - click
  - prompt_toolkit
  - pathlib

version 2.1 Got rid of the extra fuzzy completer wrapping
version 2.0 Gemini 3 - 2025-11-22 - with toml entry point auto discovery
version 1.0 Gemini 3 - 2025-11-22
"""
import logging
import logging.config
import os
import shlex
import subprocess
from textwrap import wrap
import yaml

# import glob
# import os

# for uber uber self discovery
from importlib.metadata import entry_points

import click
from pathlib import Path
from typing import Callable, Dict, List, Optional

from prompt_toolkit.completion import (
    Completer,
    FuzzyCompleter,
    NestedCompleter,
    PathCompleter,
    WordCompleter,
)
from prompt_toolkit import PromptSession
from prompt_toolkit.formatted_text import HTML

# from prompt_toolkit.completion import FuzzyCompleter, NestedCompleter, PathCompleter

# from .utilities import clear_screen


logger = logging.getLogger(__name__)


class CommandHybridCompleter(Completer):
    """Fuzzy for command names; nested for per-command arguments."""

    def __init__(self, command_fuzzy_completer: Completer, nested_completer: Completer):
        self.command_fuzzy_completer = command_fuzzy_completer
        self.nested_completer = nested_completer

    def get_completions(self, document, complete_event):
        text = document.text_before_cursor

        # If we're still typing the first word (no space yet), do fuzzy on commands.
        if not text or " " not in text:
            yield from self.command_fuzzy_completer.get_completions(
                document, complete_event
            )
        else:
            # After the first space, delegate to NestedCompleter, which in turn
            # hands off to the per-command completer (e.g. RustFuzzyCompleter for `tt`).
            yield from self.nested_completer.get_completions(document, complete_event)


class UberShell:
    def __init__(self, prompt_label: str, debug: bool = False):
        self.prompt_label = prompt_label
        self.debug = debug

        # Core commands registered directly on this shell.
        self.command_registry: Dict[str, Callable[[str], None]] = {}

        # Map from first token to a prompt_toolkit Completer (or None).
        self.completer_map: Dict[str, Optional[object]] = {}

        # Plugins registered as top-level entry points (e.g. 'qt', 'archivum').
        # Each plugin owns a click.Group with its own subcommands.
        self.plugins: Dict[str, click.Group] = {}

        self._register_builtins()

    def register_command(
        self, name: str, callback: Callable[[str], None], completer=None
    ):
        """Registers a single command with a callback and optional completer."""
        self.command_registry[name] = callback
        self.completer_map[name] = completer

    def register_plugin(self, name: str, group: click.Group):
        """
        Register a plugin entry point without flattening its subcommands.

        Example:
            shell.register_plugin("qt", qt_group)

        Behavior:
            - 'qt' runs the plugin:
                * 'qt' alone -> plugin uber (if available) or plugin help.
                * 'qt cmd ...' -> runs 'cmd ...' through the plugin's click group.
            - completion:
                * fuzzy on 'qt' as a command name at the top level;
                * after 'qt ' completions are plugin subcommands.
        """
        self.plugins[name] = group

        # Runner understands "qt" vs "qt subcommand args..."
        self.command_registry[name] = create_plugin_runner(group, name)

        # Per-plugin completer: fuzzy over subcommand names after 'qt '.
        subcommand_names = sorted(group.commands.keys())
        subcommand_completer = FuzzyCompleter(
            WordCompleter(subcommand_names, ignore_case=True)
        )
        self.completer_map[name] = subcommand_completer

    def register_click_group(
        self,
        group: click.Group,
        runner_factory: Callable = None,
        exclude: List[str] = None,
        completers: Dict[str, object] = None,
    ):
        """
        Batch registers all commands from a Click Group. Flattens.

        Args:
            group: The Click Group to register.
            runner_factory: Function to create the command runner.
            exclude: List of command names to exclude.
            completers: Dict mapping command names to specific prompt_toolkit Completers.
        """
        if runner_factory is None:
            runner_factory = create_click_runner

        completers = completers or {}
        exclude_set = set(exclude or [])

        for name in group.commands.keys():
            if name not in exclude_set:
                self.register_command(
                    name, runner_factory(group), completer=completers.get(name)
                )

    def _register_builtins(self):
        self.builtins = {
            "cd",
            "pwd",
            "cls",
            "q",
            "x",
            "quit",
            "..",
            "exit",
            "help",
            "ev",
            "?",
            "h",
        }
        for b in self.builtins:
            self.completer_map[b] = None
        self.completer_map["cd"] = PathCompleter(only_directories=True, expanduser=True)

    def start(self, startup_commands: List[str] = None, prompt_function=None):
        """
        Starts the REPL loop.
        :param startup_commands: List of strings to execute immediately upon start.
        """
        # Initialize breadcrumb chain if not set already.
        # Top-level shell (e.g. uber or archivum standalone) seeds the chain.
        if "UBERSHELL_CHAIN" not in os.environ:
            os.environ["UBERSHELL_CHAIN"] = self.prompt_label

        # completers
        # caused problems cos fuzzy completer took over and trumped custom completers
        # completer = FuzzyCompleter(NestedCompleter(self.completer_map))

        # NestedCompleter dispatches on the first word (command name)
        # and then hands off to the per-command completer (which can be RustFuzzyCompleter).
        nested_completer = NestedCompleter(self.completer_map)

        # Fuzzy completer for command names only (keys of completer_map).
        command_names = sorted(self.completer_map.keys())
        command_word_completer = WordCompleter(command_names, ignore_case=True)
        command_fuzzy = FuzzyCompleter(command_word_completer)

        # Hybrid: fuzzy for first word; nested (and thus per-command / per-plugin)
        # for everything after the first space.
        completer = CommandHybridCompleter(command_fuzzy, nested_completer)

        # Use the hybrid
        session = PromptSession(
            completer=completer,
            complete_while_typing=True,
        )

        queue = list(startup_commands) if startup_commands else []

        # Separate core commands from plugin entry points for nicer help.
        core_cmds = sorted(
            cmd for cmd in self.command_registry.keys() if cmd not in self.plugins
        )

        plugin_lines: List[str] = []
        for plugin_name in sorted(self.plugins.keys()):
            group = self.plugins[plugin_name]
            subnames = ", ".join(sorted(group.commands.keys()))
            plugin_lines.append(
                "\n".join(
                    wrap(
                        f"  {plugin_name}: {subnames}\n",
                        width=65,
                        subsequent_indent="     ",
                    )
                )
            )

        help_text_lines = [
            f"Shell:         {self.prompt_label}\n",
            f"Core commands: {', '.join(core_cmds) if core_cmds else '(none)'}\n",
            f"Built-ins:     {', '.join(sorted(self.builtins))}\n",
        ]
        if plugin_lines:
            help_text_lines.append("Plugins:       ")
            help_text_lines.extend(plugin_lines)

        help_text = "\n".join(help_text_lines)

        if self.debug:
            click.echo(help_text)

        if prompt_function is None:

            def prompter():
                return HTML(f"<ansired>{self.prompt_label} > </ansired>")

        else:
            prompter = prompt_function

        while True:
            try:
                if queue:
                    text = queue.pop(0)
                    click.echo(f"{self.prompt_label} > {text}")
                else:
                    text = session.prompt(prompter()).strip()

                if not text:
                    continue
                if text in {"q", "x", "quit", "exit", ".."}:
                    break

                if text in {"h", "?", "help"}:
                    click.echo(help_text)
                    continue
                if text == "cls":
                    os.system("cls")
                    continue
                if text in {"pwd", "cwd"}:
                    click.echo(Path.cwd())
                    continue
                if text == "ev":
                    subprocess.Popen(
                        [
                            "C:\\Program Files\\Everything\\Everything.exe",
                            "-search",
                            f"path:{os.getcwd()}",
                        ]
                    )
                    continue
                if text.startswith("cd"):
                    try:
                        parts = text.split(maxsplit=1)
                        p = (
                            Path(parts[1]).expanduser()
                            if len(parts) > 1
                            else Path.home()
                        )
                        os.chdir(p)
                    except Exception as e:
                        click.echo(f"Error: {e}", err=True)
                    continue

                cmd_name = text.split()[0]
                if cmd_name in self.command_registry:
                    self.command_registry[cmd_name](text)
                else:
                    subprocess.run(text, shell=True)

            except KeyboardInterrupt:
                continue
            except EOFError:
                break
            except Exception as e:
                click.echo(
                    f"Unexpected error of type {type(e)}; ignoring.\n{str(e)[:500]}"
                )


# --- Shared Runner Factories ---
def create_click_runner(group: click.Group) -> Callable[[str], None]:
    """
    Factory: Wraps a Click Group to run within the shell.
    Passes the command line string to the group's main method.
    """

    def runner(line: str):
        try:
            group.main(args=shlex.split(line), standalone_mode=False, obj={})
        except SystemExit:
            pass

    return runner


def create_plugin_runner(group: click.Group, plugin_name: str) -> Callable[[str], None]:
    """
    Factory: Wraps a Click Group as a plugin entry point.

    Line syntax inside the uber-uber shell:

        archivum
            -> if 'uber' exists, run 'archivum uber'
               else show 'archivum --help'

        archivum uber ...
            -> run 'archivum uber ...'

        archivum --lib-name foo
            -> if 'uber' exists, run 'archivum uber --lib-name foo'
               else run 'archivum --lib-name foo'

    Also extends/restores UBERSHELL_CHAIN for breadcrumb prompts.
    """

    def runner(line: str):
        old_chain = os.environ.get("UBERSHELL_CHAIN")

        try:
            # Extend breadcrumb: uber -> uber > archivum, etc.
            if old_chain:
                os.environ["UBERSHELL_CHAIN"] = f"{old_chain} > {plugin_name}"
            else:
                os.environ["UBERSHELL_CHAIN"] = plugin_name

            parts = shlex.split(line)
            # parts[0] is the plugin name; rest are for the plugin.
            args = parts[1:]

            if not args:
                # bare 'archivum'
                if "uber" in group.commands:
                    target_args = ["uber"]
                else:
                    target_args = ["--help"]
            else:
                first = args[0]
                if first.startswith("-") and "uber" in group.commands:
                    # 'archivum --lib-name foo' -> 'archivum uber --lib-name foo'
                    target_args = ["uber"] + args
                else:
                    # 'archivum uber ...' or 'archivum some_other_subcmd ...'
                    target_args = args

            group.main(args=target_args, standalone_mode=False, obj={})
        except SystemExit:
            # keep the uber-uber shell alive
            pass
        finally:
            # Restore previous breadcrumb.
            if old_chain is None:
                os.environ.pop("UBERSHELL_CHAIN", None)
            else:
                os.environ["UBERSHELL_CHAIN"] = old_chain

    return runner


def create_nested_runner(callback_func: Callable) -> Callable[[str], None]:
    """
    Factory: For nested loops (e.g. running 'qt' inside 'uber').
    Ignores arguments and triggers the target function (usually an uber loop).
    """

    def runner(line: str):
        # We default debug to False or you can parse 'line' to check for --debug
        callback_func(debug=False)

    return runner
