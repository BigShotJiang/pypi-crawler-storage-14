# This defined the package level logger
import logging

logger = logging.getLogger(__name__)
