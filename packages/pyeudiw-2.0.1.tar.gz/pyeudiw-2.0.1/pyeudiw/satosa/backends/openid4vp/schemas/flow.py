from enum import Enum


class RemoteFlowType(Enum):
    SAME_DEVICE = "same_device"
    CROSS_DEVICE = "cross_device"
