class HttpError(Exception):
    pass