# TODO: move legacy test about entity configurations and endpoints we still have in openid4vp backend tests
