class InvalidTrustHandlerConfiguration(Exception):
    """
    Exception raised when the configuration of a trust handler is invalid.
    """
    pass