class KidError(Exception):
    pass


class KidNotFoundError(Exception):
    pass


class InvalidJwk(Exception):
    pass


class InvalidKid(Exception):
    pass
