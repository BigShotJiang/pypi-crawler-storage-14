class InvalidDPoPAth(Exception):
    pass


class InvalidDPoPKid(Exception):
    pass


class InvalidDPoP(Exception):
    pass
