# Utility Package for the Data Analytics Course

A collection of helper functions designed to simplify common data analytics
tasks so that students can focus on interpretation rather than implementation.

This utility package was developed specifically for the
[Data Analytics](https://discdown.org/dataanalytics/) course taught
at the [University of Innsbruck](https://uibk.ac.at). It contains a series of
miscellaneous functions, including:

* **radar:** A function for plotting segmented
  radar (star/spider) charts based on pandas DataFrames.
* **spineplot:** A convenience
  function for drawing two-dimensional spine plots from pandas DataFrames.

## Important

Please note that this package is in an early alpha state and even the name may
change in the near future. The following can be used to install the
latest development version:

```
python3 -m pip install git+https://github.com/retostauffer/polarchart
```

The releases on [test PyPi](https://test.pypi.org/project/polarchart/)
and [PyPi](https://pypi.org/project/polarchart/) might already be outdated
but will be done once the we leave the alpha state and have decided
on the name (planned for early 2026 to be used in our course
in the upcoming semester).

