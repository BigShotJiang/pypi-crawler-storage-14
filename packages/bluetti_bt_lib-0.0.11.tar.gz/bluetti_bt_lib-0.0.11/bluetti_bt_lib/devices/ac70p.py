from ..base_devices import BaseDeviceV2


class AC70P(BaseDeviceV2):
    def __init__(self):
        super().__init__()
