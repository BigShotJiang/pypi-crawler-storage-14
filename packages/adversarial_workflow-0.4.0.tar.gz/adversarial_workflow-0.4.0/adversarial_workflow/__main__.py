"""Allow execution via python -m adversarial_workflow."""
from .cli import main

if __name__ == "__main__":
    main()
