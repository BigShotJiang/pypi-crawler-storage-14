"""
Setup file for adversarial-workflow package.
Uses pyproject.toml for configuration (PEP 621).
"""

from setuptools import setup

# Configuration is in pyproject.toml
setup()
