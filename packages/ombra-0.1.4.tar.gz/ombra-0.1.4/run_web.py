"""
Example: Running ombra with the web UI.

This demonstrates how to use create_app() to get a FastAPI app
with workflow orchestration and UI built-in.
"""

from ombra import create_app

# Create FastAPI app with ombra built-in
# This gives you:
# - Auto-generated API endpoints for all workflows
# - Web UI at http://localhost:8000/workflows
# - API docs at http://localhost:8000/docs
#
# Define your workflows anywhere in your codebase using the @workflow decorator:
#
#   from ombra import workflow, step
#
#   @step()
#   def process_data(x: int) -> int:
#       return x * 2
#
#   @workflow(name="my_workflow", description="Process data")
#   def my_workflow(value: int) -> int:
#       result = process_data(value)
#       return result
#
# Workflows are automatically discovered from:
# - workflows/ directory
# - src/workflows/ directory

app = create_app()

if __name__ == "__main__":
    import uvicorn
    import copy

    # Get default uvicorn logging config and customize it
    log_config = copy.deepcopy(uvicorn.config.LOGGING_CONFIG)

    # Add filter to exclude polling endpoint logs
    log_config["filters"] = {
        "poll_filter": {
            "()": "run_web.PollEndpointFilter",
        }
    }
    log_config["handlers"]["access"]["filters"] = ["poll_filter"]

    print("=" * 60)
    print("🚀 Starting ombra Web UI")
    print("=" * 60)
    print("📍 Web UI:  http://localhost:8000/workflows")
    print("📖 API Docs: http://localhost:8000/docs")
    print("=" * 60)
    print("Press CTRL+C to stop")
    print()

    uvicorn.run(
        "run_web:app",
        host="0.0.0.0",
        port=8000,
        reload=True,
        log_config=log_config
    )


class PollEndpointFilter:
    """Filter out UI polling requests from access logs."""

    def filter(self, record):
        message = record.getMessage()
        # Filter out /api/executions requests (UI polls every 0.5s)
        return '/api/executions' not in message
