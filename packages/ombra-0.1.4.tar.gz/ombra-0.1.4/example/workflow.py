from ombra import workflow, File
from example.models import EmailDraft
from example.steps import analyze_document, draft_response_email

@workflow(name="process_document", description="Analyze a PDF and draft a response email")
async def process_document_workflow(file: File) -> EmailDraft:
    # Step 1: Analyze the PDF
    analysis = await analyze_document(file)
    
    # Step 2: Draft an email based on the analysis
    email_draft = await draft_response_email(analysis)
    
    return email_draft
