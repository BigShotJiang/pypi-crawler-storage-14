Always start with a plan with steps to solve the problem.
Ask for additional information if needed before starting to code, is always better to ask before executing than doing changes without all the info available.
Do one step at a time, report in a short sentence what you did, and tell me it is ready for me to test.
I'll be doing all the testing, so just do a small change and then check with me for testing the changes.
If you think something is wrong, give me your opinion based on best practices. It is way better if you tell me that something is wrong, than if you tell me "You're absolutely right!" on a bad idea.
Don't write tests.