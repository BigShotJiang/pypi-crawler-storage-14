from typing import List, get_type_hints, get_origin, get_args
from pydantic import BaseModel

class Message(BaseModel):
    content: str

def call_llm(messages: List[Message]):
    pass

hints = get_type_hints(call_llm)
print(f"Hints: {hints}")
param_type = hints['messages']
origin = get_origin(param_type)
print(f"Origin: {origin}")
args = get_args(param_type)
print(f"Args: {args}")

data = [{"content": "hello"}]
if origin is list and args:
    inner = args[0]
    print(f"Inner: {inner}")
    res = [inner.model_validate(x) for x in data]
    print(f"Result: {res}")
    print(f"Item type: {type(res[0])}")
