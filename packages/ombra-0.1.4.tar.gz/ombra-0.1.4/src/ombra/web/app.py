"""FastAPI web application for workflow orchestration UI."""

from contextlib import asynccontextmanager
from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from pathlib import Path
import ombra
import os # Added import
from ombra.logger import logger
from ..discovery import discover_workflows_in_directory
from .endpoints import create_workflow_endpoints, register_workflow_management_endpoints


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Lifecycle management for the application."""
    # Suppress uvicorn access logs for polling endpoints
    import logging
    
    class EndpointFilter(logging.Filter):
        def filter(self, record: logging.LogRecord) -> bool:
            return record.getMessage().find("GET /api/executions") == -1

    try:
        logging.getLogger("uvicorn.access").addFilter(EndpointFilter())
    except Exception:
        pass

    # Startup: Discover workflows
    project_root = Path.cwd()
    search_paths = []

    # Prioritize workflow directory from environment variable if set
    custom_workflows_dir = os.environ.get("OMBRA_WORKFLOWS_DIR")
    if custom_workflows_dir:
        custom_path = Path(custom_workflows_dir).resolve()
        if custom_path.is_dir():
            search_paths.append(custom_path)
        else:
            logger.warning(f"⚠️  Custom workflow directory '{custom_workflows_dir}' not found or not a directory. Skipping.")

    # Add default search paths
    search_paths.extend([
        project_root / "workflows",
        project_root / "src" / "workflows",
    ])

    for path in search_paths:
        if path.exists():
            try:
                discover_workflows_in_directory(path)
            except Exception as e:
                logger.error(f"   ❌ Error scanning {path}: {e}")

    workflows = ombra.get_all_workflows()

    logger.info("Starting Ombra")
    logger.info("Registering workflows...")
    
    if not workflows:
        logger.warning("⚠️  No workflows found. Create one in 'workflows/' or 'src/workflows/'.")
    else:
        # Log registered workflows
        for wf in workflows:
            logger.info(f"✅ Registered workflow: {wf.name}")

    # Cleanup old workflow schemas that no longer have code
    from ombra.execution import get_execution_manager
    exec_manager = get_execution_manager()

    active_workflow_names = {wf.name for wf in workflows}
    db_schemas = exec_manager.db.load_workflow_schemas()
    db_workflow_names = {schema['workflow_name'] for schema in db_schemas}
    orphaned_workflows = db_workflow_names - active_workflow_names

    if orphaned_workflows:
        for workflow_name in orphaned_workflows:
            exec_manager.db.delete_workflow_schema(workflow_name)

    # Register dynamic API endpoints from workflow schemas
    create_workflow_endpoints(app)

    # Register static management endpoints
    register_workflow_management_endpoints(app)

    # Final helpful links
    # ANSI: Bold (\033[1m) + Underline (\033[4m) + Cyan (\033[36m)
    link_style = "\033[1m\033[4m\033[36m"
    reset_style = "\033[0m"

    logger.info("")
    logger.info(f"📖 Run Workflows:    {link_style}http://localhost:8000/docs{reset_style}")
    logger.info(f"👀 View Executions:  {link_style}http://localhost:8000/workflows{reset_style}")
    logger.info("")

    yield

    # Shutdown
    logger.info("👋 Shutting down...")


# Get the web directory path
WEB_DIR = Path(__file__).parent
TEMPLATES_DIR = WEB_DIR / "templates"
STATIC_DIR = WEB_DIR / "static"

# Create FastAPI app with lifespan
app = FastAPI(
    lifespan=lifespan,
    openapi_tags=[
        {
            "name": "Workflows",
            "description": "Execute registered workflows with automatic checkpointing"
        },
        {
            "name": "Internal",
            "description": "Internal APIs for workflow management and monitoring"
        }
    ]
)

# Setup Jinja2 templates
templates = Jinja2Templates(directory=str(TEMPLATES_DIR))

# Mount static files (CSS, JS)
if STATIC_DIR.exists():
    app.mount("/static", StaticFiles(directory=str(STATIC_DIR)), name="static")


@app.get("/", response_class=HTMLResponse, include_in_schema=False)
async def home(request: Request):
    """Home page - redirect to workflows."""
    from fastapi.responses import RedirectResponse
    return RedirectResponse(url="/workflows", status_code=302)


@app.get("/workflows", response_class=HTMLResponse, include_in_schema=False)
async def workflows_page(request: Request):
    """Workflows page - list recent executions."""
    from ombra.execution import get_execution_manager

    execution_manager = get_execution_manager()

    # Get recent executions (last 100)
    all_executions = execution_manager.get_all_executions()
    recent_executions = sorted(
        all_executions,
        key=lambda e: e.started_at or e.completed_at or "",
        reverse=True
    )[:100]

    executions_data = [
        {
            "execution_id": ex.execution_id,
            "workflow_name": ex.workflow_name,
            "status": ex.status.value,
            "started_at": ex.started_at.strftime("%Y-%m-%d %H:%M:%S") if ex.started_at else None,
            "completed_at": ex.completed_at.strftime("%Y-%m-%d %H:%M:%S") if ex.completed_at else None,
            "num_steps": len(ex.step_executions),
            "error": ex.error
        }
        for ex in recent_executions
    ]

    return templates.TemplateResponse(
        "workflows.html",
        {
            "request": request,
            "executions": executions_data
        }
    )


@app.get("/executions/{execution_id}", response_class=HTMLResponse, include_in_schema=False)
async def execution_detail(request: Request, execution_id: str):
    """Execution detail page - show full details of a specific execution."""
    from ombra.execution import get_execution_manager
    from fastapi import HTTPException

    execution_manager = get_execution_manager()
    execution = execution_manager.get_execution(execution_id)

    if not execution:
        raise HTTPException(status_code=404, detail=f"Execution {execution_id} not found")

    # Convert execution to dict for template
    execution_data = {
        "execution_id": execution.execution_id,
        "workflow_name": execution.workflow_name,
        "status": execution.status.value,
        "started_at": execution.started_at.strftime("%Y-%m-%d %H:%M:%S") if execution.started_at else None,
        "completed_at": execution.completed_at.strftime("%Y-%m-%d %H:%M:%S") if execution.completed_at else None,
        "error": execution.error,
        "inputs": execution.inputs,
        "outputs": execution.outputs,
        "step_executions": execution.step_executions,
        "num_checkpoints": len(execution.checkpoints)
    }

    return templates.TemplateResponse(
        "execution_detail.html",
        {
            "request": request,
            "execution": execution_data
        }
    )


@app.get("/api/executions/{execution_id}", tags=["Internal"])
async def get_execution_json(execution_id: str):
    """Get execution details as JSON (API endpoint)."""
    from ombra.execution import get_execution_manager
    from fastapi import HTTPException

    execution_manager = get_execution_manager()
    execution = execution_manager.get_execution(execution_id)

    if not execution:
        raise HTTPException(status_code=404, detail="Execution not found")

    return execution.to_dict()


@app.get("/api/executions", tags=["Internal"])
async def get_executions_list(limit: int = 100):
    """Get list of recent executions."""
    from ombra.execution import get_execution_manager

    execution_manager = get_execution_manager()

    # Get recent executions (last N)
    all_executions = execution_manager.get_all_executions()
    recent_executions = sorted(
        all_executions,
        key=lambda e: e.started_at or e.completed_at or "",
        reverse=True
    )[:limit]

    executions_data = [
        {
            "execution_id": ex.execution_id,
            "workflow_name": ex.workflow_name,
            "status": ex.status.value,
            "started_at": ex.started_at.strftime("%Y-%m-%d %H:%M:%S") if ex.started_at else None,
            "completed_at": ex.completed_at.strftime("%Y-%m-%d %H:%M:%S") if ex.completed_at else None,
            "num_steps": len(ex.step_executions),
            "error": ex.error
        }
        for ex in recent_executions
    ]

    return executions_data


@app.get("/health", tags=["Internal"])
async def health():
    """Health check endpoint."""
    return {"status": "healthy"}


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000, reload=True)
