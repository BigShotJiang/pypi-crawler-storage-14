"""Global registry for workflow instances."""

from typing import Dict, List
from .workflow import Workflow


class WorkflowRegistry:
    """Central registry for all workflow instances."""

    def __init__(self):
        self._workflows: Dict[str, Workflow] = {}

    def register(self, workflow: Workflow) -> None:
        """Register a workflow instance.

        Args:
            workflow: The workflow instance to register.
        """
        if workflow.name in self._workflows:
            # Update existing workflow
            self._workflows[workflow.name] = workflow
        else:
            self._workflows[workflow.name] = workflow

    def get(self, name: str) -> Workflow | None:
        """Get a workflow by name.

        Args:
            name: The workflow name.

        Returns:
            The workflow instance or None if not found.
        """
        return self._workflows.get(name)

    def get_all(self) -> List[Workflow]:
        """Get all registered workflows.

        Returns:
            List of all workflow instances.
        """
        return list(self._workflows.values())

    def clear(self) -> None:
        """Clear all registered workflows."""
        self._workflows.clear()


# Global registry instance
_registry = WorkflowRegistry()


def register_workflow(workflow: Workflow) -> None:
    """Register a workflow in the global registry."""
    _registry.register(workflow)


def get_workflow(name: str) -> Workflow | None:
    """Get a workflow by name from the global registry."""
    return _registry.get(name)


def get_all_workflows() -> List[Workflow]:
    """Get all registered workflows from the global registry."""
    return _registry.get_all()


def clear_registry() -> None:
    """Clear the global workflow registry."""
    _registry.clear()
