/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./src/ombra/web/templates/**/*.html",
  ],
  theme: {
    extend: {
      colors: {
        // Theme: Omarchy (Tokyo Night)
        // Backgrounds
        'terminal-bg': '#1a1b26',           // Tokyo Night BG
        'terminal-bg-dark': '#16161e',      // Darker BG
        'terminal-bg-light': '#24283b',     // Storm BG (Cards)
        'terminal-bg-lighter': '#414868',   // Highlights
        'terminal-bg-hover': '#292e42',     // Hover
        'terminal-border': '#414868',       // Border
        'terminal-border-focus': '#7aa2f7', // Focus Blue

        // Text
        'terminal-text': '#c0caf5',         // Periwinkle
        'terminal-text-bright': '#ffffff',  // White
        'terminal-text-dim': '#a9b1d6',     // Dim
        'terminal-text-muted': '#565f89',   // Muted

        // Accents
        'accent-purple': '#bb9af7',         // Purple
        'accent-lavender': '#9d7cd8',       // Lavender
        'accent-mauve': '#9aa5ce',          // Mauve
        'accent-pink': '#f7768e',           // Pink/Red
        'accent-blue': '#7aa2f7',           // Blue
        'accent-sapphire': '#2ac3de',       // Cyan

        // Status
        'status-success': '#9ece6a',        // Green
        'status-running': '#7aa2f7',        // Blue
        'status-error': '#f7768e',          // Red
        'status-warning': '#e0af68',        // Yellow
        'status-pending': '#414868',        // Grey

        // Legacy
        primary: '#7aa2f7',
        'primary-dark': '#bb9af7',
      },
    },
  },
  plugins: [],
}
