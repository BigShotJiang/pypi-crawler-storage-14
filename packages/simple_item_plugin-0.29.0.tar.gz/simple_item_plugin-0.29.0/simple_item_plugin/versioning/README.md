# smithed.versioning
This doc will serve as an explanation on how to serve a fully versionable library with APIs.

> Coming soon
