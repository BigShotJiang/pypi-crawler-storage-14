from __future__ import annotations

from typing import Any, Dict

import requests


def post_json(url: str, payload: Dict[str, Any], timeout: int = 10) -> Dict[str, Any]:
    """Send a JSON POST request and return the decoded JSON response.

    Args:
        url: Target endpoint URL.
        payload: JSON-serializable payload body.
        timeout: Request timeout in seconds.

    Returns:
        Decoded JSON response body.

    Raises:
        requests.HTTPError: If the response indicates an error.
    """
    headers = {"Content-Type": "application/json", "Accept": "application/json"}
    response = requests.post(url, json=payload, headers=headers, timeout=timeout)
    response.raise_for_status()
    return response.json()
