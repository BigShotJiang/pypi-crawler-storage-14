from __future__ import annotations

from typing import Tuple

from .http import post_json


def get_xsts_token(user_token: str) -> Tuple[str, str]:
    """Exchange a user token for an XSTS token.

    Args:
        user_token: User token returned from the Xbox Live authenticate call.

    Returns:
        Tuple of (user_hash, xsts_token).
    """
    payload = {
        "Properties": {
            "SandboxId": "RETAIL",
            "UserTokens": [user_token],
        },
        "RelyingParty": "http://xboxlive.com",
        "TokenType": "JWT",
    }

    data = post_json("https://xsts.auth.xboxlive.com/xsts/authorize", payload)
    user_hash = data["DisplayClaims"]["xui"][0]["uhs"]
    xsts_token = data["Token"]
    return user_hash, xsts_token
