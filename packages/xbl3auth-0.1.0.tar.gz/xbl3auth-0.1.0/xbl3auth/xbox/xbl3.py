from __future__ import annotations


def format_xbl3(user_hash: str, xsts_token: str) -> str:
    """Format an XBL3.0 token string.

    Args:
        user_hash: Xbox user hash (uhs).
        xsts_token: XSTS token value.

    Returns:
        XBL3.0 token string in the form 'XBL3.0 x=<uhs>;<token>'.
    """
    return f"XBL3.0 x={user_hash};{xsts_token}"
