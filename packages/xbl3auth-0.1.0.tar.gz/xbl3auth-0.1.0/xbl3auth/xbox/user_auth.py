from __future__ import annotations

from typing import Tuple

from .http import post_json


def get_user_token(access_token: str) -> Tuple[str, str]:
    """Authenticate the user with Xbox Live and obtain the user token.

    Args:
        access_token: Microsoft bearer access token.

    Returns:
        Tuple of (user_hash, user_token).
    """
    payload = {
        "Properties": {
            "AuthMethod": "RPS",
            "SiteName": "user.auth.xboxlive.com",
            "RpsTicket": f"d={access_token}",
        },
        "RelyingParty": "http://auth.xboxlive.com",
        "TokenType": "JWT",
    }

    data = post_json("https://user.auth.xboxlive.com/user/authenticate", payload)
    user_hash = data["DisplayClaims"]["xui"][0]["uhs"]
    user_token = data["Token"]
    return user_hash, user_token
