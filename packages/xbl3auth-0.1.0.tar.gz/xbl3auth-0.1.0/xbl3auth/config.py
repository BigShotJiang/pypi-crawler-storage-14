from dataclasses import dataclass
from pathlib import Path

from platformdirs import user_data_dir


# Baked-in public client ID for xbl3auth.
# This is intentionally not a secret; it identifies the application to Microsoft.
DEFAULT_CLIENT_ID = "411a9d42-4773-47fc-a7a3-0c9ae8fb083f"


@dataclass
class XblAuthConfig:
    """Configuration for XBL3.0 authorization.

    Attributes:
        client_id: Azure AD public client application ID. Defaults to the built-in
            client ID so users do not need to register their own app.
        tenant: Tenant identifier, typically "consumers", "common", or a tenant ID.
        scope: Space-separated OAuth scope string for MSAL.
        authority_url: Base URL for the Microsoft identity authority.
    """
    client_id: str = DEFAULT_CLIENT_ID
    tenant: str = "consumers"
    scope: str = "XboxLive.signin offline_access"
    authority_url: str = "https://login.microsoftonline.com"


def get_app_data_dir(app_name: str = "xbl3auth", app_author: str = "DJStompZone") -> Path:
    r"""Return the per-user application data directory.

    This uses platform-native locations, for example:
      - Windows: C:\Users\<user>\AppData\Roaming\<author>\<app_name>
      - macOS: ~/Library/Application Support/<app_name>
      - Linux: ~/.config/<app_name>

    Args:
        app_name: Application name used in path construction.
        app_author: Author or vendor name, used on some platforms.

    Returns:
        Path object pointing to the appropriate data directory.
    """
    return Path(user_data_dir(app_name, app_author))
