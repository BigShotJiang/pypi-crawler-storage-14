from __future__ import annotations

from typing import Optional

from .base import SecretStorage


class InMemorySecretStorage(SecretStorage):
    """Simple in-memory secret storage for testing.

    This backend is not secure and should only be used in tests.
    """

    def __init__(self) -> None:
        self._data: dict[tuple[str, str], str] = {}

    def set_secret(self, service: str, key: str, value: str) -> None:
        self._data[(service, key)] = value

    def get_secret(self, service: str, key: str) -> Optional[str]:
        return self._data.get((service, key))

    def delete_secret(self, service: str, key: str) -> None:
        self._data.pop((service, key), None)
