from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Optional


class SecretStorage(ABC):
    """Abstract interface for storing and retrieving secrets.

    Implementations should provide secure storage appropriate to the environment.
    """

    @abstractmethod
    def set_secret(self, service: str, key: str, value: str) -> None:
        """Store a secret value.

        Args:
            service: Logical service name.
            key: Logical key identifier.
            value: Secret value to store.
        """

    @abstractmethod
    def get_secret(self, service: str, key: str) -> Optional[str]:
        """Retrieve a secret value.

        Args:
            service: Logical service name.
            key: Logical key identifier.

        Returns:
            The secret value if present, otherwise None.
        """

    @abstractmethod
    def delete_secret(self, service: str, key: str) -> None:
        """Delete a stored secret if it exists.

        Args:
            service: Logical service name.
            key: Logical key identifier.
        """
