from pandas import DataFrame, concat, read_csv

def get(trials: DataFrame, include_approved: bool = True) -> DataFrame:
    """
    Calculate clinical trial scores and statistics for target genes.

    This function analyzes clinical trial data to compute various metrics including
    phase distributions, phase scores, approved drug counts, and an overall clinical score
    for each target gene.

    :param trials: DataFrame containing clinical trial data with columns including
                   ``Target Gene``, ``NCTId``, ``Phase``, ``Approved``, and ``DrugBank ID``
    :type trials: DataFrame
    :param include_approved: Whether to include approved drugs in the total clinical score
                            calculation. If True, approved drugs contribute 20 points
                            each to the clinical score. Defaults to True.
    :type include_approved: bool, optional

    :return: DataFrame with the following columns for each target gene:
    * ``# Phase 1``: Count of Phase 1 trials
    * ``# Phase 2``: Count of Phase 2 trials
    * ``# Phase 3``: Count of Phase 3 trials
    * ``Phase Score``: Sum of phase numbers across all trials
    * ``# Approved Drugs``: Count of unique approved drugs
    * ``Clinical Score``: Total score (phase score + 20 * approved drugs if include_approved=True)

    Results are sorted by ``Clinical Score`` in descending order.
    
    :rtype: DataFrame

    :raises: May raise exceptions if required columns are missing from the input DataFrame
             or if phase values cannot be converted to integers.

    .. note::

       The function prints phase value counts as a side effect during execution.

    .. warning::

       The function assumes that Phase values end with a numeric character that can
       be extracted and converted to an integer.
    """
    # calculate number of trials in each phase
    phases = DataFrame(trials.groupby(by='Target Gene')[trials.columns].apply(lambda x: x[['NCTId', 'Phase']].drop_duplicates()['Phase'].value_counts())).unstack()
    phases[phases.isna()] = 0
    # calculate phase scores
    print(trials['Phase'].value_counts())
    phase_scores = DataFrame(trials.groupby(by='Target Gene')[trials.columns].apply(lambda x: sum(x[['NCTId', 'Phase']].drop_duplicates()['Phase'].str[-1].astype(int))))
    # # calculate number of approved drugs for each target
    # n_approved_drugs = DataFrame(trials.groupby(by='Target Gene')[trials.columns].apply(lambda x: len(x.loc[x['Approved'] == 1, 'TTD ID'].drop_duplicates())))
    # # concatenate all data frames
    res = concat([phases, phase_scores], axis = 1)
    res.columns = ['# Phase 1', '# Phase 2', '# Phase 3', 'Phase Score']
    # calculate a total clinical score
    # if include_approved:
    #     res['Clinical Score'] = res['Phase Score'] + res['# Approved Drugs'] * 20
    # else:
    #     res['Clinical Score'] = res['Phase Score']
    # sort by clinical score
    res = res.sort_values(by = 'Phase Score', ascending=False)

    return(res)

def load(date = '2025-11-11'):
    """
    Retrieve clinical scores for multiple disease types from S3 storage.

    This function reads CSV files containing clinical target data for various diseases
    from an S3 bucket, organized by date.

    :param date: The date string used to construct the S3 file paths, defaults to ``2025-11-11``
    :type date: str, optional
    :return: A tuple containing DataFrames for breast, lung, prostate, melanoma, bowel,
             diabetes, and cardiovascular clinical scores (in that order)
    :rtype: tuple of pandas.DataFrame
    :raises FileNotFoundError: If any of the CSV files do not exist at the specified S3 paths
    :raises ValueError: If the CSV files cannot be parsed correctly

    .. note::

       All CSV files are expected to be located in the S3 bucket at:
       ``s3://alethiotx-artemis/data/clinical_targets/{date}/{disease}.csv``

    .. warning::

       Ensure data exists
       for the specified date before calling this function.

    **Example**
    >>> breast, lung, prostate, melanoma, bowel, diabetes, cardio = load_clinical_scores('2025-11-11')
    >>> print(breast.shape)
    (100, 5)
    """
    breast = read_csv("s3://alethiotx-artemis/data/clinical_targets/" + date + "/breast.csv")
    lung = read_csv("s3://alethiotx-artemis/data/clinical_targets/" + date + "/lung.csv")
    prostate = read_csv("s3://alethiotx-artemis/data/clinical_targets/" + date + "/prostate.csv")
    melanoma = read_csv("s3://alethiotx-artemis/data/clinical_targets/" + date + "/melanoma.csv")
    bowel = read_csv("s3://alethiotx-artemis/data/clinical_targets/" + date + "/bowel.csv")
    diabetes = read_csv("s3://alethiotx-artemis/data/clinical_targets/" + date + "/diabetes.csv")
    cardiovascular = read_csv("s3://alethiotx-artemis/data/clinical_targets/" + date + "/cardiovascular.csv")

    return(breast, lung, prostate, melanoma, bowel, diabetes, cardiovascular)

# run when file is directly executed
if __name__ == '__main__': 
    # Import here to avoid circular imports
    from .trials import fetch as fetch_clinical_trials
    from ..ttd.match import clinical_trials as ttd_match_clinical_trials
    from ..drugbank.match import clinical_trials as drugbank_match_clinical_trials
    
    clinical_trials = fetch_clinical_trials(search="Breast Cancer")
    # matched_trials = ttd_match_clinical_trials(clinical_trials)
    matched_trials = drugbank_match_clinical_trials(clinical_trials)
    scores = get(matched_trials)
    # scores.to_csv("breast_clinical_scores_with_ttd.csv")
    scores.to_csv("breast_clinical_scores_with_drugbank.csv")

    # print("\nLoading clinical scores for multiple diseases from S3:")
    # breast, lung, prostate, melanoma, bowel, diabetes, cardiovascular = load('2025-11-11')
    # print("Clinical scores loaded:")
    # print(breast)
    # print(lung)
    # print(prostate)
    # print(melanoma)
    # print(bowel)
    # print(diabetes)
    # print(cardiovascular)