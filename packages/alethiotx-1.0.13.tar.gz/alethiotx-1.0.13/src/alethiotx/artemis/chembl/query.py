import chembl_downloader
import re

def infer_nct_year(nct_id):
    """
    Infer the approximate year a clinical trial was registered based on NCT ID.
    
    NCT IDs are sequential and follow approximate ranges:
    - NCT00000000-NCT00999999: ~1999-2004
    - NCT01000000-NCT01999999: ~2005-2011
    - NCT02000000-NCT02999999: ~2012-2015
    - NCT03000000-NCT03999999: ~2016-2018
    - NCT04000000-NCT04999999: ~2019-2021
    - NCT05000000-NCT05999999: ~2022-2023
    - NCT06000000+: ~2024+
    
    :param nct_id: NCT ID string (e.g., 'NCT04494425')
    :return: Estimated year as integer, or None if invalid format
    """
    if not isinstance(nct_id, str) or not nct_id.startswith('NCT'):
        return None
    
    # Extract the numeric part
    match = re.search(r'NCT(\d{8})', nct_id)
    if not match:
        return None
    
    num = int(match.group(1))
    
    # Approximate year ranges based on NCT ID ranges
    if num < 1000000:
        return 1999 + (num // 200000)  # ~1999-2004
    elif num < 2000000:
        return 2005 + ((num - 1000000) // 140000)  # ~2005-2011
    elif num < 3000000:
        return 2012 + ((num - 2000000) // 250000)  # ~2012-2015
    elif num < 4000000:
        return 2016 + ((num - 3000000) // 330000)  # ~2016-2018
    elif num < 5000000:
        return 2019 + ((num - 4000000) // 350000)  # ~2019-2021
    elif num < 6000000:
        return 2022 + ((num - 5000000) // 500000)  # ~2022-2023
    else:
        return 2024 + ((num - 6000000) // 500000)  # ~2024+

def all_molecules(version: str = '36'):
    """
    Query ChEMBL database for all drug molecules with clinical trial information.
    
    :param version: ChEMBL database version to query
    :return: DataFrame with drug and target information
    """
    
    sql_all_drugs = """
    SELECT 
        MD.chembl_id,
        MD.pref_name,
        DI.mesh_heading,
        DI.mesh_id,
        DI.max_phase_for_ind AS phase,
        IREF.ref_type AS reference_type,
        IREF.ref_id AS clinical_trial_id,
        TD.chembl_id AS target_chembl_id,
        TD.organism AS target_organism,
        TD.target_type,
        CS_TARGET.accession AS target_uniprot_id,
        COMP_SYN.component_synonym AS target_gene_name,
        DM.mechanism_of_action,
        DM.action_type,
        MD.molregno
    FROM MOLECULE_DICTIONARY MD
    INNER JOIN DRUG_INDICATION DI ON MD.molregno = DI.molregno
    INNER JOIN INDICATION_REFS IREF ON DI.drugind_id = IREF.drugind_id
    INNER JOIN DRUG_MECHANISM DM ON MD.molregno = DM.molregno
    INNER JOIN TARGET_DICTIONARY TD ON DM.tid = TD.tid
    LEFT JOIN TARGET_COMPONENTS TC ON TD.tid = TC.tid
    LEFT JOIN COMPONENT_SEQUENCES CS_TARGET ON TC.component_id = CS_TARGET.component_id
    LEFT JOIN COMPONENT_SYNONYMS COMP_SYN ON CS_TARGET.component_id = COMP_SYN.component_id AND COMP_SYN.syn_type = 'GENE_SYMBOL'
    WHERE IREF.ref_id IS NOT NULL 
        AND IREF.ref_type = 'ClinicalTrials'
        AND TD.organism = 'Homo sapiens'
    """
    df = chembl_downloader.query(sql_all_drugs, version=version)
    return df

if __name__ == '__main__':    
    # Query for all unique MeSH headings
    mesh_query = """
    SELECT DISTINCT
        mesh_heading,
        COUNT(DISTINCT molregno) as drug_count
    FROM DRUG_INDICATION
    WHERE mesh_heading IS NOT NULL
    GROUP BY mesh_heading
    ORDER BY drug_count DESC, mesh_heading
    """
    
    mesh_df = chembl_downloader.query(mesh_query, version='36')
    mesh_df.to_csv("chembl_mesh_headings.tsv", sep='\t', index=False)
    print(f"\nFound {len(mesh_df)} unique MeSH headings")
    print("\nTop 20 MeSH headings by drug count:")
    print(mesh_df.head(20))
    
    # Query for all drugs
    df = all_molecules()

    print(f"\nFinished querying all drugs with clinical trial information.")
    
    # Explode clinical_trial_id column if it contains multiple comma-separated IDs
    if 'clinical_trial_id' in df.columns and df['clinical_trial_id'].notna().any():
        df['clinical_trial_id'] = df['clinical_trial_id'].apply(
            lambda x: x.split(',') if isinstance(x, str) and ',' in x else [x] if x else []
        )
        df = df.explode('clinical_trial_id')
        df['clinical_trial_id'] = df['clinical_trial_id'].apply(lambda x: x.strip() if isinstance(x, str) else x)
        
        # Add inferred year column as integer
        df['trial_year'] = df['clinical_trial_id'].apply(infer_nct_year)
        df['trial_year'] = df['trial_year'].astype('Int64')  # Use nullable integer type
    
    df.drop_duplicates().to_csv("chembl_clinical_molecules.tsv", sep='\t', index=False)
    print(f"\nFound {len(df)} total drug-target-trial records")
    print(f"Unique molecules: {df['chembl_id'].nunique()}")
    print(df.head(10))