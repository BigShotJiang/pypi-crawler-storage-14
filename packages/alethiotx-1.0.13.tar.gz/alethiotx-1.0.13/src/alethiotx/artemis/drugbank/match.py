from re import escape, match
from pandas import DataFrame, concat, read_csv
from ..clinical.trials import fetch as fetch_clinical_trials

def clinical_trials(trials: DataFrame, date: str = '2025-03-26', pharm_action = False, approved_by = 'US') -> DataFrame:
    """
    Match clinical trials with DrugBank database entries based on intervention names.

    This function loads DrugBank data, filters it based on various criteria, and matches
    clinical trial interventions with drug synonyms from the DrugBank database.

    :param trials: DataFrame containing clinical trials data with an ``InterventionName`` column
    :type trials: DataFrame
    :param date: Date string for the DrugBank data snapshot in ``YYYY-MM-DD`` format, defaults to ``2025-03-26``
    :type date: str, optional
    :param pharm_action: If True, filter results to only include drugs with pharmacological action marked as ``Yes``, defaults to True
    :type pharm_action: bool, optional
    :param approved_by: Filter drugs by approval status. Options are ``US`` (US approved only), 
                        ``Other`` (approved in other countries), or ``Both`` (approved in both US and other countries), 
                        defaults to ``US``
    :type approved_by: str, optional
    :return: DataFrame containing matched clinical trials and DrugBank entries with the following transformations:
             - ``Target Name`` renamed to ``Target Gene``
             - ``Approved`` column added based on approval status (1 for approved, 0 otherwise)
             - ``US Approved`` and ``Other Approved`` columns removed
    :rtype: DataFrame
    :raises: May raise exceptions related to S3 access, CSV parsing, or DataFrame operations

    .. note::

       - The function filters out DrugBank entries without target information
       - Drug synonyms are filtered to lengths between 5 and 30 characters
       - Matching is performed using case-insensitive regex pattern matching
       - The function reads data from an S3 bucket at ``s3://alethiotx-artemis/data/drugbank/``

    .. warning::

       This function may be computationally expensive for large datasets due to nested loop matching
    """
    # load the drugbank data
    db = read_csv('s3://alethiotx-artemis-internal/data/drugbank/' + date + '/webdata.csv')

    # filter out drugs with no targets
    db = db[db['Target Name'] != 'Not Available']
    db = db[~db['Target Name'].isna()]

    # filter short and long synonyms
    db['Synonyms_length'] = db['Synonyms'].apply(lambda x: len(str(x)))
    db = db[(db['Synonyms_length'] > 5) & (db['Synonyms_length'] <= 30)]
    db = db.drop(columns=['Synonyms_length'])

    # ASSIGN DRUGBANK IDS
    # prepare for matching clinical trials interventions with drugbank synonyms
    db['synonym_lower'] = db['Synonyms'].apply(lambda x: str(x).lower())
    trials['intervention_lower'] = trials['InterventionName'].apply(str.lower)

    # Optimized matching - iterate through smaller dataset (trials) and vectorize DrugBank search
    print(f"Matching {len(trials)} clinical trials with {len(db)} DrugBank synonyms...")
    
    matches = []
    for trial_idx, trial_row in trials.iterrows():
        intervention = trial_row['intervention_lower']
        # Vectorized check: which DrugBank synonyms are contained in this intervention
        mask = db['synonym_lower'].apply(lambda syn: syn in intervention)
        matched_db = db[mask]
        
        if len(matched_db) > 0:
            # Add trial data to each matched DrugBank entry
            for _, db_row in matched_db.iterrows():
                combined = {**trial_row.to_dict(), **db_row.to_dict()}
                matches.append(combined)
    
    res = DataFrame(matches)
    
    # Clean up temporary columns
    if 'synonym_lower' in res.columns:
        res = res.drop(columns=['synonym_lower'])
    if 'intervention_lower' in res.columns:
        res = res.drop(columns=['intervention_lower'])
    
    print(f"Found {len(res)} matches")
    
    if len(res) == 0:
        print("No matches found")
        return DataFrame()

    res.rename(columns={
        'Target Name': 'Target Gene',
    }, inplace=True)

    return res

    if pharm_action:
        res = res[res['Pharmacological Action'] == 'Yes']

    if approved_by == 'US':
        res['Approved'] = res['US Approved']
        res['Approved'] = res['Approved'].apply(lambda x: 1 if x == 'YES' else 0)
    elif approved_by == 'Other':
        res['Approved'] = res['Other Approved']
        res['Approved'] = res['Approved'].apply(lambda x: 1 if x == 'YES' else 0)
    elif approved_by == 'Both':
        res['Approved'] = res[['US Approved', 'Other Approved']].apply(lambda x: 1 if all(x == 'YES') else 0, axis = 1)
    res = res.drop(columns=['US Approved', 'Other Approved'])

    return res

if __name__ == '__main__':
    trials = fetch_clinical_trials(search="Breast Cancer")
    db_trials = clinical_trials(trials)
    db_trials.to_csv("breast_clinical_trials_with_drugbank.csv", index = False)
    print(db_trials)