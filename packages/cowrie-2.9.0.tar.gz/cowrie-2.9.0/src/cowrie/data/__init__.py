# Copyright (c) 2009-2014 Upi Tamminen <desaster@gmail.com>
# See the COPYRIGHT file for more information

"""
Cowrie data package containing filesystem pickles, command outputs, and other static data files.
"""
