# Emulated shell backend
