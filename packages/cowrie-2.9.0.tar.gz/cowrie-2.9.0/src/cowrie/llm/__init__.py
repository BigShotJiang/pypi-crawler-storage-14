# ABOUTME: LLM backend package for cowrie honeypot.
# ABOUTME: Provides LLM-powered shell simulation instead of static command responses.
