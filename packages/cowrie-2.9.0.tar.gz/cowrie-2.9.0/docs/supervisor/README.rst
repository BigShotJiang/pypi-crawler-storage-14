Automatically starting Cowrie with supervisord
#################################################

* Copy the file ``cowrie.conf`` to ``/etc/supervisor/conf/``
