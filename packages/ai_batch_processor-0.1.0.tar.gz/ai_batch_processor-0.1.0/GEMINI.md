# AI Batch Project

## Project Overview

`ai-batch-project` is a Python-based utility designed for batch processing files (primarily images/text) using various Large Language Model (LLM) providers. It abstracts the complexity of interacting with different APIs and provides a unified interface for both realtime (concurrent) and offline (batch job) processing.

**Key Features:**
*   **Multi-Vendor Support:** Native handlers for Kimi (Moonshot), Qwen (Alibaba), Gemini (Google), and OpenAI-compatible APIs.
*   **Dual Processing Modes:**
    *   `realtime`: Uses asyncio and concurrency to process multiple files simultaneously.
    *   `offline`: Submits batch jobs to the provider (if supported, e.g., Qwen/Gemini) for large-scale async processing.
*   **CLI Interface:** Easy-to-use command-line interface with glob pattern support.
*   **Configurable:** YAML-based configuration for API keys and default settings.

## Directory Structure

```
.
├── config.yaml             # Main configuration file (API keys, defaults)
├── pyproject.toml          # Project metadata and dependencies
├── src/
│   └── ai_batch/
│       ├── cli.py          # CLI entry point
│       ├── main.py         # Main library interface (smart_process)
│       ├── core/           # Core logic (Processors, Managers)
│       ├── handlers/       # Vendor-specific API implementations
│       └── utils/          # Utility functions
└── test_script.py          # Example usage script
```

## Setup & Installation

The project uses `uv` for dependency management and requires Python 3.13+.

1.  **Install Dependencies:**
    ```bash
    uv sync
    # OR
    pip install -r requirements.txt
    ```

2.  **Configuration:**
    *   Copy or modify `config.yaml`.
    *   Set your API keys and preferred models in the `vendors` section.
    *   **Note:** API keys can be set in `config.yaml` or overridden via environment variables/CLI args (though `config.yaml` is the primary method used in the code).

## Usage

### CLI Usage

The primary entry point is `src/ai_batch/cli.py`. You can run it as a module:

```bash
python -m src.ai_batch.cli "path/to/files/*.jpg" --vendor gemini --prompt "Describe this image"
```

**Common Arguments:**
*   `input`: File path or glob pattern (e.g., `./imgs/*.png`).
*   `--vendor`: Target vendor (`kimi`, `qwen`, `gemini`, `openai`). Overrides default in config.
*   `--model`: Specific model to use.
*   `--prompt`: Instruction for the AI.
*   `--mode`: `realtime` (default) or `offline`.
*   `--config`: Path to a custom config file (default looks for `config.yaml` implicitly via logic).

### Library Usage

You can import `smart_process` to use the tool programmatically:

```python
import asyncio
from src.ai_batch import smart_process

async def main():
    results = await smart_process(
        input_target=["image1.jpg", "image2.jpg"],
        vendor="gemini",
        api_key="YOUR_KEY",
        model="gemini-1.5-pro",
        prompt="Analyze this"
    )
    print(results)

if __name__ == "__main__":
    asyncio.run(main())
```

## Development

*   **Handlers:** To add a new AI provider, create a new file in `src/ai_batch/handlers/` and register it in `get_handler_by_vendor`.
*   **Core Logic:**
    *   `RealtimeBatchProcessor`: Handles concurrent processing with semaphores.
    *   `BatchManager` (Qwen/Gemini): Handles specific offline batch API flows.
