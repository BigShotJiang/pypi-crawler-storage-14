def main():
    print("Hello from ai-batch-project!")


if __name__ == "__main__":
    main()
