# 🚀 AI Batch Processor

一个轻量级、高性能的通用大模型批量处理工具。支持 Kimi、Qwen、Gemini 和所有 OpenAI 兼容接口（如 DeepSeek）。

旨在通过统一的接口解决大批量文件（文本/图片）的处理需求，支持**高并发实时调用**和**低成本离线 Batch 任务**。

## ✨ 核心特性

- **多模型统一接入**：
  - 🇨🇳 **Kimi (Moonshot)**
  - 🇨🇳 **Qwen (通义千问)** - 支持实时 & Batch API
  - 🇺🇸 **Gemini (Google)** - 支持实时 & Batch API
  - 🌏 **OpenAI Compatible** - 支持 GPT-4, DeepSeek, Claude (via switch) 等
- **双模式运行**：
  - `realtime`：基于 `asyncio` 的高并发模式，适合追求速度的场景。
  - `offline`：利用厂商原生的 Batch API（如果支持），大幅降低 Token 成本（通常便宜 50%），适合非急需的海量任务。
- **智能处理**：
  - 自动识别输入文件类型（图片/文本）。
  - 内置并发控制（Semaphore），防止触发 API Rate Limit。
  - 结果实时流式写入 `.jsonl`，防止意外中断导致数据丢失。

## 🛠️ 安装

本项目使用 Python 3.13+ 开发。推荐使用 `uv` 或 `pip` 进行安装。

```bash
# 克隆项目
git clone https://github.com/your-repo/ai-batch-project.git
cd ai-batch-project

# 安装依赖
pip install -r requirements.txt
# 或者使用 uv
uv sync
```

## ⚙️ 配置

在项目根目录创建或修改 `config.yaml`。你可以参考以下模版：

```yaml
# 全局并发限制 (Realtime 模式)
concurrency: 5
default_vendor: "kimi"

vendors:
  kimi:
    api_key: "sk-xxxxxxxxxxxxxxxx"
    model: "moonshot-v1-8k"
  
  qwen:
    api_key: "sk-yyyyyyyyyyyyyyyy"
    model: "qwen-vl-max"
  
  gemini:
    api_key: "AIzaSyDxxxxxxxxxxx"
    model: "gemini-1.5-flash"
  
  openai:
    api_key: "sk-zzzzzzzzzzzzzz"
    base_url: "https://api.deepseek.com" # 示例：使用 DeepSeek
    model: "deepseek-chat"
```

> **注意**：API Key 也可以通过环境变量设置，但配置文件优先级较低，命令行参数优先级最高。

## 📖 使用指南

### 1. 命令行工具 (CLI)

最简单的使用方式。支持 glob 通配符批量读取文件。

**基本用法：**

```bash
# 使用 Kimi 处理所有图片
python -m src.ai_batch.cli "./images/*.jpg" --prompt "提取图中的文字" --vendor kimi

# 切换模型并指定配置文件
python -m src.ai_batch.cli "./docs/*.txt" -c config.yaml --vendor openai --model gpt-4o --prompt "总结这篇文章"
```

**参数说明：**

- `input`: 输入路径，支持文件夹或 `*.jpg` 等通配符。
- `--vendor`: 指定厂商 (`kimi`, `qwen`, `gemini`, `openai`)。
- `--model`: (可选) 覆盖配置文件中的模型名称。
- `--mode`: (可选) 处理模式，`realtime` (默认) 或 `offline` (离线任务)。
- `--prompt`: (可选) 发送给模型的提示词。

### 2. Python SDK 调用

你可以在自己的代码中引用 `smart_process`。

```python
import asyncio
from src.ai_batch import smart_process

async def main():
    files = ["data/a.jpg", "data/b.jpg"]
    
    results = await smart_process(
        input_target=files,
        vendor="qwen",
        api_key="你的KEY",     # 也可以从 config 加载
        model="qwen-vl-max",
        prompt="这张图里有什么？",
        mode="realtime"       # 或 'offline' 提交 Batch 任务
    )
    
    print(f"成功处理 {len(results)} 个文件")

if __name__ == "__main__":
    asyncio.run(main())
```

## 📂 项目结构

```text
.
├── config.yaml           # 配置文件
├── src/
│   └── ai_batch/
│       ├── cli.py        # 命令行入口
│       ├── main.py       # 核心逻辑入口
│       ├── core/         # 处理器 (Manager/Processor)
│       └── handlers/     # 各厂商的具体实现 (Kimi/Qwen/Gemini)
└── results/              # 默认结果输出目录
```

## 📝 TODO

- [ ] 增加 Token 消耗统计与成本预估。
- [ ] 完善错误重试机制 (Exponential Backoff)。
- [ ] 支持结构化输出 (JSON Schema)。
- [ ] 增加更多厂商支持 (Claude/Anthropic)。

## License

MIT
