import asyncio
import json
# 注意：这里直接引用包名，因为我们已经用 -e 安装了
from src.ai_batch import smart_process, load_config

async def main():
    # 1. 加载配置
    print("⚙️ 加载配置...")
    cfg = load_config(r"D:\PersonalArchive\Person\Tools\Test\20251128-1\test-data\config-test.yaml")
    
    # 2. 准备测试数据
    file_list = [r"D:\PersonalArchive\Person\Tools\Test\20251128-1\test-data\test.jpg"] 
    # 如果没有图片，代码会报错提示，这是正常的
    
    # 3. 运行测试 (使用 Kimi)
    print("\n🚀 启动 Kimi 视觉测试...")
    res = await smart_process(
        input_target=file_list,
        vendor="kimi",
        api_key=cfg["vendors"]["kimi"]["api_key"], 
        model=cfg["vendors"]["kimi"]["model"],
        prompt="这张图里有什么？输出 JSON",
        analyze_file=True
    )
    
    print("\n✅ 测试结果:")
    print(json.dumps(res, ensure_ascii=False, indent=2))

if __name__ == "__main__":
    asyncio.run(main())