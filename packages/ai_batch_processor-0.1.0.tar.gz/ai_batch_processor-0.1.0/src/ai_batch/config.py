import os
import yaml

def load_config(config_path=None):
    """
    加载顺序: 默认 -> YAML -> 环境变量
    """
    # 1. 默认配置
    config = {
        "default_vendor": "kimi",
        "concurrency": 5,
        "delete_temp_on_success": False,
        "vendors": {}
    }

    # 2. YAML 文件覆盖
    # 优先级: 传入路径 > ~/.aibatch/config.yaml > 当前目录 config.yaml
    paths_to_try = []
    if config_path: paths_to_try.append(config_path)
    paths_to_try.append(os.path.expanduser("~/.aibatch/config.yaml"))
    paths_to_try.append("config.yaml")

    final_yaml_path = None
    for p in paths_to_try:
        if os.path.exists(p):
            final_yaml_path = p
            break
    
    if final_yaml_path:
        print(f"⚙️ 加载配置文件: {final_yaml_path}")
        try:
            with open(final_yaml_path, 'r', encoding='utf-8') as f:
                yaml_conf = yaml.safe_load(f)
                if yaml_conf: config.update(yaml_conf)
        except Exception as e:
            print(f"⚠️ 配置文件加载失败: {e}")

    # 3. 环境变量覆盖 (仅覆盖 Key)
    # 格式: AIBATCH_VENDOR_KEY (例如 AIBATCH_KIMI_KEY)
    for v in ["kimi", "qwen", "gemini", "openai"]:
        env_key = f"AIBATCH_{v.upper()}_KEY"
        val = os.getenv(env_key)
        if val:
            if v not in config["vendors"]: config["vendors"][v] = {}
            config["vendors"][v]["api_key"] = val

    return config

def get_vendor_config(config, vendor_name):
    """获取特定厂商的配置，如果不存在返回空字典"""
    return config.get("vendors", {}).get(vendor_name, {})