import asyncio
import os
import json
import time
try:
    import aiofiles
    HAS_AIOFILES = True
except ImportError: HAS_AIOFILES = False
try:
    from tqdm.asyncio import tqdm
    HAS_TQDM = True
except ImportError: HAS_TQDM = False

class RealtimeBatchProcessor:
    def __init__(self, concurrency: int = 5, log_path: str = None, max_retries: int = 3):
        self.semaphore = asyncio.Semaphore(concurrency)
        self.log_path = log_path
        self.lock = asyncio.Lock()
        self.max_retries = max_retries
        if self.log_path and not os.path.exists(os.path.dirname(self.log_path)):
             try: os.makedirs(os.path.dirname(self.log_path))
             except: pass

    async def _worker(self, file_path, handler_func, **kwargs):
        async with self.semaphore:
            result = None
            attempt = 0
            while attempt <= self.max_retries:
                try:
                    result = await asyncio.to_thread(handler_func, file_path=file_path, **kwargs)
                    if isinstance(result, dict) and "error" in result:
                        err = str(result["error"]).lower()
                        # 重试关键词
                        if any(k in err for k in ["429", "overload", "rate limit", "timeout", "location", "precondition"]):
                            raise Exception(err)
                        break 
                    break 
                except Exception as e:
                    attempt += 1
                    if attempt <= self.max_retries:
                        await asyncio.sleep(2 ** attempt)
                    else:
                        result = {"error": f"Max retries exceeded: {str(e)}"}

            if self.log_path:
                record = {"file": file_path, "timestamp": time.time(), "result": result}
                async with self.lock:
                    try:
                        line = json.dumps(record, ensure_ascii=False) + "\n"
                        mode = 'a' if os.path.exists(self.log_path) else 'w'
                        if HAS_AIOFILES:
                            async with aiofiles.open(self.log_path, mode, encoding='utf-8') as f: await f.write(line)
                        else:
                            with open(self.log_path, mode, encoding='utf-8') as f: f.write(line)
                    except: pass
            return file_path, result

    async def run(self, file_list, handler_func, **kwargs):
        tasks = [self._worker(fp, handler_func, **kwargs) for fp in file_list if os.path.exists(fp)]
        print(f"🚀 [实时并发] 任务数: {len(tasks)} | 并发: {self.semaphore._value}")
        if HAS_TQDM: results = await tqdm.gather(*tasks, desc="实时进度")
        else: results = await asyncio.gather(*tasks)
        return {k: v for k, v in results}