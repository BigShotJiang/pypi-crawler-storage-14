import os
import json
import asyncio
import time
import mimetypes
from datetime import datetime
from pathlib import Path
from openai import OpenAI

# 尝试导入可选依赖
try:
    from tqdm.asyncio import tqdm
    HAS_TQDM = True
except ImportError:
    HAS_TQDM = False

# 引入工具函数
from ..utils.common import encode_image, parse_result

# ==============================================================================
# Qwen Batch Manager (阿里云百炼)
# ==============================================================================

class QwenBatchManager:
    """
    Qwen 离线批处理管理器
    支持:
    1. 文档模式 (qwen-long): 并发上传文件 -> 获取 FileID -> 提交 Batch
    2. 视觉模式 (qwen-vl): 本地转 Base64 -> 嵌入 JSONL -> 提交 Batch
    """
    def __init__(self, api_key, base_url=None):
        self.api_key = api_key
        # 默认使用阿里云百炼官方兼容端点
        self.base_url = base_url if base_url else "https://dashscope.aliyuncs.com/compatible-mode/v1"
        self.client = OpenAI(api_key=api_key, base_url=self.base_url)

    async def _upload_single_helper(self, file_path):
        """辅助：上传单个文件获取 ID (仅用于文档模式)"""
        try:
            return await asyncio.to_thread(
                self.client.files.create, 
                file=open(file_path, "rb"), 
                purpose="file-extract"
            )
        except: 
            return None

    async def run_batch_job(self, file_list: list, model: str, prompt: str, poll_interval=30):
        # 判断模式：包含 'vl' 视为视觉模型
        is_vision_model = "vl" in model.lower()
        batch_requests = []
        
        # --- 分支 A: 文档模式 (上传文件换 ID) ---
        if not is_vision_model:
            print(f"📦 [Qwen Batch] 文档模式: 准备上传 {len(file_list)} 个文件...")
            
            # 并发上传
            tasks = [self._upload_single_helper(fp) for fp in file_list if os.path.exists(fp)]
            if HAS_TQDM:
                uploads = await tqdm.gather(*tasks, desc="上传文件到阿里云")
            else:
                uploads = await asyncio.gather(*tasks)
            
            # 过滤失败的
            valid_uploads = []
            for i, up in enumerate(uploads):
                if up and hasattr(up, 'id'):
                    valid_uploads.append((file_list[i], up.id))
            
            if not valid_uploads: 
                return {"error": "所有文件上传失败，无法继续"}
            
            print(f"   ✅ 成功上传 {len(valid_uploads)} 个文件")

            # 构建请求体
            for f_path, f_id in valid_uploads:
                req = {
                    "custom_id": os.path.basename(f_path), 
                    "method": "POST", 
                    "url": "/v1/chat/completions",
                    "body": {
                        "model": model, 
                        "messages": [
                            {"role": "system", "content": f"fileid://{f_id}"}, 
                            {"role": "user", "content": prompt}
                        ]
                    }
                }
                batch_requests.append(req)

        # --- 分支 B: 视觉模式 (本地转 Base64) ---
        else:
            print(f"📦 [Qwen Batch] 视觉模式: 本地编码图片中...")
            for fp in file_list:
                if not os.path.exists(fp): continue
                try:
                    mime = mimetypes.guess_type(fp)[0] or "image/jpeg"
                    b64 = encode_image(fp)
                    
                    req = {
                        "custom_id": os.path.basename(fp),
                        "method": "POST", 
                        "url": "/v1/chat/completions",
                        "body": {
                            "model": model, 
                            "messages": [
                                {
                                    "role": "user", 
                                    "content": [
                                        {"type": "text", "text": prompt}, 
                                        {"type": "image_url", "image_url": {"url": f"data:{mime};base64,{b64}"}}
                                    ]
                                }
                            ]
                        }
                    }
                    batch_requests.append(req)
                except Exception as e:
                    print(f"⚠️ 图片 {os.path.basename(fp)} 编码失败: {e}")

        if not batch_requests: 
            return {"error": "无法构建任何有效请求"}

        # --- 通用流程: 生成 JSONL -> 提交 -> 轮询 ---
        
        # 1. 生成临时 JSONL
        ts = datetime.now().strftime("%Y%m%d%H%M%S")
        f_name = f"qwen_batch_{ts}.jsonl"
        with open(f_name, "w", encoding="utf-8") as f: 
            for r in batch_requests: 
                f.write(json.dumps(r, ensure_ascii=False) + "\n")
            
        try:
            # 2. 上传 JSONL 任务单
            print(f"📦 正在提交任务单 (Size: {os.path.getsize(f_name)/1024:.2f} KB)...")
            bf = self.client.files.create(file=Path(f_name), purpose="batch")
            
            # 3. 创建 Batch Job
            job = self.client.batches.create(
                input_file_id=bf.id, 
                endpoint="/v1/chat/completions", 
                completion_window="24h"
            )
            print(f"🚀 Batch Job 已创建! ID: {job.id}")
            
        except Exception as e: 
            return {"error": f"提交 Batch 失败: {str(e)}"}
        finally: 
            # 清理本地临时 JSONL
            try: os.remove(f_name)
            except: pass

        # 4. 轮询等待
        print("⏳ 等待 Qwen 处理 (24h内)...")
        start_time = time.time()
        while True:
            try:
                job = self.client.batches.retrieve(job.id)
                elapsed = int(time.time() - start_time)
                
                # 打印进度
                done = job.request_counts.completed if job.request_counts else 0
                total = job.request_counts.total if job.request_counts else 0
                print(f"   [{datetime.now().strftime('%H:%M:%S')}] 状态: {job.status} (进度: {done}/{total}) | 耗时: {elapsed}s")
                
                if job.status in ["completed", "failed", "expired", "cancelled"]: 
                    break
                await asyncio.sleep(poll_interval)
            except Exception as e:
                print(f"⚠️ 轮询状态报错: {e}")
                await asyncio.sleep(poll_interval)
            
        if job.status != "completed": 
            return {"error": f"Batch Job 结束状态异常: {job.status}"}
        
        # 5. 下载结果
        print("📥 下载 Qwen 结果...")
        res_map = {}
        if job.output_file_id:
            content = self.client.files.content(job.output_file_id).text
            for line in content.splitlines():
                if not line: continue
                obj = json.loads(line)
                custom_id = obj.get("custom_id")
                try: 
                    # 尝试提取 content 内容并解析为 JSON
                    ai_content = obj["response"]["body"]["choices"][0]["message"]["content"]
                    res_map[custom_id] = parse_result(ai_content)
                except: 
                    # 如果解析失败，保留原始对象方便调试
                    res_map[custom_id] = {"error": "Result Parse Error", "raw": obj}
        
        return res_map


# ==============================================================================
# Gemini Batch Manager (Google)
# ==============================================================================

class GeminiBatchManager:
    """
    Gemini 离线批处理管理器
    核心特性：
    1. 并发上传素材至 Google File API
    2. 带重试机制的轮询 (抗网络波动/IP限制)
    """
    def __init__(self, api_key, base_url=None):
        self.api_key = api_key
        # 延迟导入 Google SDK
        from google import genai
        client_kwargs = {"api_key": api_key}
        if base_url: client_kwargs["http_options"] = {"api_endpoint": base_url}
        self.client = genai.Client(**client_kwargs)

    async def _upload_single(self, file_path):
        """上传单个素材并等待处理完毕"""
        from google.genai import types
        if not os.path.exists(file_path): return None, None
        
        try:
            mime = mimetypes.guess_type(file_path)[0] or "application/octet-stream"
            
            # 使用流式上传 + 英文名规避 ASCII 错误
            with open(file_path, "rb") as f:
                up_file = await asyncio.to_thread(
                    self.client.files.upload, 
                    file=f, 
                    config=types.UploadFileConfig(display_name="batch_doc", mime_type=mime)
                )
            
            # 等待文件状态变为 ACTIVE (尤其是视频文件)
            retry = 0
            while retry < 10: # 最多等 20秒
                if up_file.state.name == "ACTIVE": 
                    return file_path, up_file.uri
                if up_file.state.name == "FAILED": 
                    return file_path, None
                
                await asyncio.sleep(2)
                try: 
                    up_file = await asyncio.to_thread(self.client.files.get, name=up_file.name)
                except: 
                    pass
                retry += 1
            
            return file_path, None # 超时
        except: 
            return file_path, None

    async def run_batch_job(self, file_list: list, model: str, prompt: str, poll_interval=30):
        print(f"📦 [Gemini Batch] 阶段 1/4: 上传 {len(file_list)} 个素材...")
        
        # 并发上传
        tasks = [self._upload_single(fp) for fp in file_list]
        if HAS_TQDM:
            uploads = await tqdm.gather(*tasks, desc="上传素材至 Google")
        else:
            uploads = await asyncio.gather(*tasks)
            
        valid = [x for x in uploads if x[1]]
        if not valid: return {"error": "所有素材上传失败"}
        
        print(f"   ✅ 成功上传 {len(valid)} 个素材")

        # 构建任务清单 (JSONL)
        print("📦 [Gemini Batch] 阶段 2/4: 构建任务清单...")
        batch_requests = []
        for fp, uri in valid:
            req = {
                "request": {
                    "contents": [
                        {
                            "role": "user", 
                            "parts": [
                                # 引用上传的 URI
                                {"file_data": {"file_uri": uri, "mime_type": mimetypes.guess_type(fp)[0]}}, 
                                {"text": prompt}
                            ]
                        }
                    ],
                    "generation_config": {"response_mime_type": "application/json", "temperature": 0.1}
                },
                "key": os.path.basename(fp) # 使用文件名作为 key
            }
            batch_requests.append(req)

        ts = datetime.now().strftime("%Y%m%d%H%M%S")
        f_name = f"gemini_batch_{ts}.jsonl"
        with open(f_name, "w", encoding="utf-8") as f:
            for r in batch_requests: 
                f.write(json.dumps(r, ensure_ascii=False) + "\n")

        # 提交 Job
        print("📦 [Gemini Batch] 阶段 3/4: 提交 Job...")
        try:
            from google.genai import types
            # 上传输入文件
            bf = self.client.files.upload(
                file=f_name, 
                config=types.UploadFileConfig(display_name="batch_input", mime_type="application/json")
            )
            # 创建任务
            job = self.client.batches.create(
                model=model, 
                src=bf.name, 
                config=types.CreateBatchJobConfig(display_name=f"job_{ts}")
            )
            print(f"🚀 Job Created: {job.name}")
        except Exception as e: 
            return {"error": f"提交失败: {str(e)}"}
        finally:
            try: os.remove(f_name)
            except: pass

        # 轮询 (带防崩溃护盾)
        print("⏳ [Gemini Batch] 阶段 4/4: 轮询等待 (含断连重试)...")
        start_time = time.time()
        fail_count = 0
        
        while True:
            try:
                job = self.client.batches.get(name=job.name)
                elapsed = int(time.time() - start_time)
                print(f"   [{datetime.now().strftime('%H:%M:%S')}] 状态: {job.state} | 耗时: {elapsed}s")
                
                if job.state in ["COMPLETED", "FAILED", "CANCELLED"]: 
                    break
                
                fail_count = 0 # 成功一次就重置计数
                await asyncio.sleep(poll_interval)

            except Exception as e:
                err = str(e)
                # 针对 IP/Region 错误进行死磕重试
                if any(k in err for k in ["400", "location", "precondition", "network", "server"]):
                    fail_count += 1
                    wait = min(60, 5 * fail_count)
                    print(f"⚠️ 网络/区域检测异常 (第{fail_count}次)，{wait}s后重试...")
                    await asyncio.sleep(wait)
                else:
                    return {"error": f"轮询崩溃: {err}"}

        if job.state != "COMPLETED": 
            return {"error": f"Job 最终状态: {job.state}"}

        # 下载结果
        print("📥 下载结果...")
        res_map = {}
        try:
            content = self.client.files.content(name=job.output_file).text
            for line in content.splitlines():
                if not line: continue
                obj = json.loads(line)
                key = obj.get("key", "unknown")
                try: 
                    # 提取 Gemini 的文本内容
                    text = obj["response"]["candidates"][0]["content"]["parts"][0]["text"]
                    res_map[key] = parse_result(text)
                except: 
                    res_map[key] = {"error": "Parse Error", "raw": obj}
        except Exception as e: 
            return {"error": f"下载失败: {str(e)}"}
            
        return res_map