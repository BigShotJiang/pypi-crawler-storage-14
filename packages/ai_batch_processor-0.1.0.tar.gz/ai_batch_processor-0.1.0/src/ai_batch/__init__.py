# 将核心入口函数暴露在顶层
from .main import smart_process
from .config import load_config

# 定义导出的符号列表
__all__ = ["smart_process", "load_config"]

# 版本号
__version__ = "0.1.0"