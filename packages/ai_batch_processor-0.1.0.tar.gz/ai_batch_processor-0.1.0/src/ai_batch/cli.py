import argparse
import asyncio
import json
import os
import glob
from .config import load_config, get_vendor_config
from .main import smart_process

def main():
    parser = argparse.ArgumentParser(description="AI Batch Processor CLI")
    
    # 核心参数
    parser.add_argument("input", help="输入文件路径，支持通配符 (如 ./imgs/*.jpg)")
    parser.add_argument("-c", "--config", help="配置文件路径")
    
    # 覆盖参数
    parser.add_argument("--vendor", help="指定厂商 (kimi/qwen/gemini/openai)")
    parser.add_argument("--model", help="覆盖模型名称")
    parser.add_argument("--prompt", default="Extract info", help="提示词")
    parser.add_argument("--mode", choices=["realtime", "offline"], default="realtime", help="处理模式")
    
    args = parser.parse_args()

    # 1. 加载配置
    cfg = load_config(args.config)
    
    # 2. 确定厂商
    vendor = args.vendor or cfg.get("default_vendor")
    if not vendor:
        print("❌ 错误: 未指定 vendor (请在 config 或 命令行中指定)")
        return

    # 3. 获取该厂商的参数 (Config + CLI Override)
    vendor_cfg = get_vendor_config(cfg, vendor)
    
    # 参数合并逻辑：CLI > Config > Error
    api_key = vendor_cfg.get("api_key") # Key 通常不在 CLI 传
    model = args.model or vendor_cfg.get("model")
    base_url = vendor_cfg.get("base_url") # base_url 通常在 config 里
    
    if not api_key or not model:
        print(f"❌ 错误: 厂商 {vendor} 缺少 api_key 或 model 配置")
        return

    # 4. 解析输入文件
    # 支持 glob 通配符
    if "*" in args.input:
        files = glob.glob(args.input)
    elif os.path.isdir(args.input):
        # 简单处理：如果是目录，读取所有文件
        files = [os.path.join(args.input, f) for f in os.listdir(args.input) if os.path.isfile(os.path.join(args.input, f))]
    else:
        files = [args.input]

    print(f"🔥 启动任务: Vendor={vendor}, Model={model}, Files={len(files)}")

    # 5. 运行
    res = asyncio.run(smart_process(
        input_target=files,
        vendor=vendor,
        api_key=api_key,
        model=model,
        base_url=base_url,
        prompt=args.prompt,
        mode=args.mode,
        concurrency=cfg.get("concurrency", 5),
        delete_temp_on_success=cfg.get("delete_temp_on_success", False),
        analyze_file=True
    ))

    print(json.dumps(res, ensure_ascii=False, indent=2))

if __name__ == "__main__":
    main()