import os
import re
import json
import base64

# 常量定义
MAX_FILE_SIZE_MB = 20 
MAX_BYTES = MAX_FILE_SIZE_MB * 1024 * 1024
THRESHOLD_LONG_CONTEXT = 7000   
THRESHOLD_K2_SWITCH = 100000    

def check_file_size(file_path):
    """防止内存溢出"""
    if not os.path.exists(file_path): return 
    size = os.path.getsize(file_path)
    if size > MAX_BYTES:
        raise ValueError(f"文件过大 ({size/1024/1024:.2f}MB)。限额 {MAX_FILE_SIZE_MB}MB。")

def encode_image(image_path):
    """图片转 Base64"""
    check_file_size(image_path)
    with open(image_path, "rb") as image_file:
        return base64.b64encode(image_file.read()).decode('utf-8')

def clean_json_string(raw_str):
    """深度清洗 JSON 字符串"""
    if not isinstance(raw_str, str): return str(raw_str)
    cleaned = re.sub(r'^```json\s*', '', raw_str, flags=re.MULTILINE)
    cleaned = re.sub(r'^```\s*', '', cleaned, flags=re.MULTILINE)
    cleaned = re.sub(r'```$', '', cleaned, flags=re.MULTILINE)
    return cleaned.strip()

def parse_result(raw_content):
    """通用结果解析器"""
    try:
        match = re.search(r"\{.*\}|\[.*\]", raw_content, re.DOTALL)
        if match: return json.loads(match.group())
    except: pass
    try:
        return json.loads(clean_json_string(raw_content))
    except: pass
    return raw_content