import os
import asyncio
from datetime import datetime
from .handlers import get_handler_by_vendor
from .core.processor import RealtimeBatchProcessor
from .core.manager import QwenBatchManager, GeminiBatchManager

async def smart_process(
    input_target, 
    vendor, 
    api_key, 
    model, 
    base_url=None,
    concurrency=5,
    mode="realtime", # realtime / offline
    log_path=None, 
    delete_temp_on_success=False,
    **kwargs
):
    if not api_key or not model: raise ValueError("必须提供 api_key 和 model")

    # 自动生成日志名
    if not log_path and isinstance(input_target, list):
        ts = datetime.now().strftime("%Y%m%d_%H%M%S")
        log_path = f"batch_log_{vendor}_{ts}.jsonl"

    # === 分流逻辑 ===
    if mode == "offline" and vendor.lower() == "qwen" and isinstance(input_target, list):
        mgr = QwenBatchManager(api_key, base_url)
        return await mgr.run_batch_job(input_target, model, kwargs.get("prompt",""))

    if mode == "offline" and vendor.lower() == "gemini" and isinstance(input_target, list):
        mgr = GeminiBatchManager(api_key, base_url)
        return await mgr.run_batch_job(input_target, model, kwargs.get("prompt",""))

    handler = get_handler_by_vendor(vendor)
    exec_kwargs = {"api_key": api_key, "model": model, "base_url": base_url, **kwargs}

    if isinstance(input_target, str):
        return await asyncio.to_thread(handler, file_path=input_target, **exec_kwargs)
    elif isinstance(input_target, list):
        if not input_target: return {}
        proc = RealtimeBatchProcessor(concurrency, log_path)
        final = await proc.run(input_target, handler, **exec_kwargs)
        if delete_temp_on_success and log_path and os.path.exists(log_path):
            try: os.remove(log_path)
            except: pass
        elif log_path: print(f"✅ 日志保留: {os.path.abspath(log_path)}")
        return final
    
    raise ValueError("输入参数错误")