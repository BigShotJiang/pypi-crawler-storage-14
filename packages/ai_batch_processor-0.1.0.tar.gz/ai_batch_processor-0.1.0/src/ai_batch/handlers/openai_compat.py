from pathlib import Path
import mimetypes
from openai import OpenAI
from ..utils.common import encode_image, parse_result

def handler(api_key, model, prompt, file_path=None, analyze_file=False, base_url=None, **kwargs):
    target_url = base_url if base_url else "https://api.openai.com/v1"
    client = OpenAI(api_key=api_key, base_url=target_url)
    messages = []
    
    try:
        if analyze_file:
            if not file_path: return {"error": "缺少 file_path"}
            file_obj = Path(file_path)
            mime_type, _ = mimetypes.guess_type(file_obj.name.lower())
            if not mime_type: mime_type = "application/octet-stream"

            if mime_type.startswith("image"):
                base64_img = encode_image(file_path)
                messages = [{"role": "user", "content": [{"type": "text", "text": prompt}, {"type": "image_url", "image_url": {"url": f"data:{mime_type};base64,{base64_img}"}}]}]
            else:
                try:
                    with open(file_path, 'r', encoding='utf-8') as f: content = f.read()
                    messages = [{"role": "user", "content": f"File Content:\n{content}\n\nTask: {prompt}"}]
                except: return {"error": "通用 OpenAI 接口暂不支持二进制文件"}
        else:
            messages = [{"role": "user", "content": prompt}]

        completion = client.chat.completions.create(model=model, messages=messages, temperature=0.1, **kwargs)
        # ✅ [新增] 打印 Token 消耗
        usage = completion.usage
        if usage:
            print(f"💰 [OpenAI Token] In: {usage.prompt_tokens} | Out: {usage.completion_tokens} | Total: {usage.total_tokens}")
        return parse_result(completion.choices[0].message.content)
    except Exception as e: return {"error": f"OpenAI Error: {str(e)}"}