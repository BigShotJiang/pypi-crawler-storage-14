from . import kimi, qwen, gemini, openai_compat

def get_handler_by_vendor(vendor: str):
    v = vendor.lower().strip()
    if v == "kimi": return kimi.handler
    if v == "qwen": return qwen.handler
    if v == "gemini": return gemini.handler
    if v in ["openai", "dmxapi", "deepseek"]: return openai_compat.handler
    raise ValueError(f"不支持的厂商: {vendor}")