临时放yolo模型的地方
后续需要通过 __onnx 内的脚本生成 onnx 模型。