# [
#     { "keys": ["ctrl+enter"], "command": "v_universal_chat" },
#     { "keys": ["ctrl+alt+`"], "command": "v_terminux" },
#     { "keys": ["ctrl+w"], "command": "v_close" }
# ]

import os, re
import re
import base64
import sublime
import sublime_plugin
import subprocess
import threading
import http.client
import json

def load_config():
    c = {}
    cfg_path = os.path.join(os.path.expanduser("~"), '.vsublime.cfg.py')
    if os.path.exists(cfg_path):
        try:
            with open(cfg_path, 'r', encoding='utf8') as f:
                s = f.read()
                s = '\n'.join([(i if not i.strip().startswith('#') else '') for i in s.splitlines()])
                t = re.findall(r'\[config\] *([^: ]+) *:(.*?)(?=\n\[|\Z)', s, flags=re.S)
                for k, v in t:
                    c[k] = v.strip()
                n = re.sub(r'\[config\] *([^: ]+) *:(.*?)(?=\n\[|\Z)', '', s, flags=re.S)
                extra = []
                for i in n.splitlines():
                    if i.strip():
                        extra.append(i.strip())
                c['extra'] = extra
        except: pass
    else:
        with open(cfg_path, 'w', encoding='utf8') as f:
            demo = [
                # ai code相关
                "[config] ai_code_api_key: none",
                "[config] ai_code_base_url: api.deepseek.com",
                "[config] ai_code_path: /chat/completions",
                "[config] ai_code_model: deepseek-chat",
                "[config] ai_code_max_search: 1000",
                # ai chat相关
                "[config] ai_chat_api_key: none",
                "[config] ai_chat_base_url: api.deepseek.com",
                "[config] ai_chat_path: /chat/completions",
                "[config] ai_chat_model: deepseek-chat",
                "[config] ai_chat_system: 你是一个知识渊博的人，你会回答我所有的问题。",
                "[config] ai_chat_max_search: 1000",
                # 其他功能
                "[config] max_line_length: 500",
                "[right] python ${file}",
            ]
            f.write('\n')
    return c

def get_chunk(json_data):
    choice = json_data["choices"][0]
    if "text" in choice:
        chunk = choice["text"]
    elif "delta" in choice:
        delta = choice.get("delta", {})
        chunk = delta.get("content", "") or ""
    else:
        chunk = ""
    return chunk










class AiCurrWindowCompletionCommand(sublime_plugin.TextCommand):
    def run(self, edit, type):
        cfg = load_config()
        ai_code_api_key = cfg.get('ai_code_api_key', '')
        ai_max_search = int(cfg.get('ai_max_search', 5000))
        selections = self.view.sel()
        if not selections:
            sublime.status_message("No text selected")
            return
        self.view.erase(edit, selections[0])
        selections = self.view.sel()
        prompt = self.view.substr(selections[0])
        cursor_start_pos = selections[0].begin()
        cursor_end_pos = selections[0].end()
        start_pos = max(0, cursor_start_pos - ai_max_search)
        before_text = self.view.substr(sublime.Region(start_pos, cursor_start_pos))
        prompt = before_text
        if type == 'add':
            suffix = None
        if type == 'insert':
            end_pos = min(self.view.size(), cursor_end_pos + ai_max_search)
            after_text = self.view.substr(sublime.Region(cursor_end_pos, end_pos))
            suffix = after_text
        cfg['prompt'] = prompt
        cfg['suffix'] = suffix
        sublime.status_message("Requesting code completion...")
        self.output_view = self.view
        thread = AiStreamingFixCodeApiThread(
            cfg,
            self.handle_stream_response,
            self.handle_completion,
            self.handle_error
        )
        thread.start()
    def handle_stream_response(self, text_chunk): sublime.set_timeout(lambda: self.append_to_output(text_chunk), 0)
    def append_to_output(self, text):
        if hasattr(self, 'output_view') and self.output_view: self.view.run_command("simple_stream_insert", {"text": text})
    def handle_completion(self): sublime.status_message("Completion finished in output window")
    def handle_error(self, error):
        sublime.status_message("Error: " + str(error))
        if hasattr(self, 'output_view') and self.output_view:
            self.view.run_command("simple_stream_insert", {"text": "\n\nError: " + str(error)})
class AppendTextCommand(sublime_plugin.TextCommand):
    def run(self, edit, text):
        self.view.insert(edit, self.view.size(), text)
        self.view.show(self.view.size())
class SimpleStreamInsertCommand(sublime_plugin.TextCommand):
    def run(self, edit, text):
        if not self.view.sel(): return
        start_pos = self.view.sel()[0].begin()
        end_pos = self.view.sel()[0].end()
        self.view.insert(edit, end_pos, text)
        new_pos = end_pos + len(text)
        self.view.sel().clear()
        self.view.sel().add(sublime.Region(start_pos, new_pos))
        self.view.show(new_pos)
class AiStreamingFixCodeApiThread(threading.Thread):
    def __init__(self, cfg, chunk_callback, completion_callback, error_callback):
        threading.Thread.__init__(self)
        self.base_url = cfg['ai_code_base_url']
        self.model = cfg['ai_code_model']
        self.path = cfg['ai_code_path']
        self.api_key = cfg['ai_code_api_key']
        self.prompt = cfg['prompt']
        self.suffix = cfg['suffix'] or ""
        self.max_tokens = int(cfg.get('max_tokens', 2048))
        self.chunk_callback = chunk_callback
        self.completion_callback = completion_callback
        self.error_callback = error_callback
        self.stop_event = threading.Event()
    def run(self):
        try:
            conn = http.client.HTTPSConnection(self.base_url.replace("https://", "").replace("http://", ""))
            tk = '''
你是一个代码补全助手。

下面提供插入点附近的上下文。
请生成应该插入到该位置的新代码。

⚠ 必须遵守：
1. 只输出新增代码。
2. 不要重复上下文。
3. 不要输出任何解释或 Markdown。
4. 不能修改 before/after 内容。
5. 你需要考虑缩进的内容，一定不能输出多余的空格！

================ 上下文 ================
{}
================ 插入点前 ================
{}
================ 插入点后 ================
{}
================ 结束 ================
                '''.format(self.prompt+self.suffix, self.prompt, self.suffix)
            messages =  [{"role": "system", "content": '你是一个代码补全助手。'}]
            messages.append({"role": "user", "content": tk})
            payload = json.dumps({
                "model": self.model,
                "messages": messages,
                "max_tokens": int(self.max_tokens),
                "stream": True
            })
            headers = {
                'Content-Type': 'application/json',
                'Accept': 'text/event-stream',
                'Authorization': 'Bearer ' + self.api_key
            }
            conn.request("POST", self.path, payload, headers)
            response = conn.getresponse()
            if response.status != 200:
                self.error_callback("API error: " + str(response.status) + " " + response.reason)
                return
            buffer = b""
            while not self.stop_event.is_set():
                chunk = response.read(16)
                if not chunk:
                    break
                buffer += chunk
                lines = buffer.split(b'\n')
                for line in lines[:-1]:
                    line = line.strip()
                    if not line:
                        continue
                    if line.startswith(b'data: '):
                        data = line[6:]
                        if data == b'[DONE]':
                            self.completion_callback()
                            return
                        try:
                            json_data = json.loads(data.decode('utf-8'))
                            if 'choices' in json_data and json_data['choices']:
                                self.chunk_callback(get_chunk(json_data))
                        except ValueError:
                            continue
                buffer = lines[-1]
            self.completion_callback()
        except Exception as e:
            self.error_callback(str(e))
        finally:
            try:
                conn.close()
            except:
                pass
    def stop(self):
        self.stop_event.set()

class CancelAiCompletionCommand(sublime_plugin.ApplicationCommand):
    def run(self):
        for thread in threading.enumerate():
            if isinstance(thread, (AiStreamingFixCodeApiThread, ApiStreamThread)):
                thread.stop()





























import sublime, sublime_plugin, os, re, json, threading, http.client
CHAT_MEMORY = {}
class VUniversalChatCommand(sublime_plugin.TextCommand):
    def run(self, edit):
        cfg = load_config()
        if not cfg.get('ai_chat_api_key') or cfg.get('ai_chat_api_key') == 'none':
            sublime.status_message("Error: ai_chat_api_key missing in .vsublime.cfg.py")
            return
        if self.view.name() != "AI Chat":
            chat_view = self.get_or_create_chat_view()
            if chat_view.id() not in CHAT_MEMORY:
                CHAT_MEMORY[chat_view.id()] = [{"role": "system", "content": cfg['ai_chat_system']}]
            self.view.window().focus_view(chat_view)
        else:
            sel = self.view.sel()[0]
            is_mutli = False
            if sel.empty():
                ai_max_search = int(cfg.get('ai_max_search', 5000))
                cursor_start_pos = sel.begin()
                start_pos = max(0, cursor_start_pos - ai_max_search)
                before_text = self.view.substr(sublime.Region(start_pos, cursor_start_pos)).rsplit('\n[End]', 1)[-1]
                sel_text = before_text.strip()
                is_mutli = True
            else:
                sel_text = self.view.substr(sel).strip()
            if not sel_text: return sublime.status_message("Type something to send")
            if is_mutli:
                start_pos = cursor_start_pos - len(before_text)
                if len(before_text) >= 1 and before_text[0] == '\n': start_pos += 1
                if len(before_text) >= 2 and before_text[1] == '\n': start_pos += 1
                cursor_start_pos = sel.begin()
                self.view.erase(edit, sublime.Region(start_pos, cursor_start_pos))
            else:
                if sel.end() >= self.view.size() - 5: 
                    self.view.erase(edit, sel)
            if not sel_text.strip():
                sublime.status_message("Select text to send")
                return
            self.view.run_command("universal_chat_send", {"user_input": sel_text, "cfg": cfg})
    def get_or_create_chat_view(self):
        win = self.view.window()
        for v in win.views():
            if v.name() == "AI Chat":
                win.focus_view(v)
                return v
        cv = win.new_file()
        cv.set_name("AI Chat")
        cv.set_scratch(True)
        cv.settings().set("word_wrap", True)
        cv.settings().set("wrap_width", 0)
        cv.set_syntax_file("Packages/Markdown/Markdown.sublime-syntax")
        return cv
class UniversalChatSendCommand(sublime_plugin.TextCommand):
    def run(self, edit, user_input, cfg):
        vid = self.view.id()
        if vid not in CHAT_MEMORY: 
            CHAT_MEMORY[vid] = [{"role": "system", "content": cfg['ai_chat_system']}]
        display_text = "[User]:\n" + user_input + "\n[AI]:\n"
        self.view.run_command("append_text", {"text": display_text})
        CHAT_MEMORY[vid].append({"role": "user", "content": user_input})
        th = ApiStreamThread(cfg, CHAT_MEMORY[vid], self.on_chunk, self.on_done, self.on_err)
        th.start()
    def on_chunk(self, text):
        sublime.set_timeout(lambda: self.view.run_command("append_text", {"text": text}), 0)
    def on_done(self, full_text):
        CHAT_MEMORY[self.view.id()].append({"role": "assistant", "content": full_text})
        sublime.set_timeout(lambda: self.view.set_status("ai_status", "AI Ready"), 0)
        sublime.set_timeout(lambda: self.view.run_command("append_text", {"text": '\n[End]\n\n'}), 0)
        print(json.dumps(CHAT_MEMORY[self.view.id()], indent=4, ensure_ascii=False))
    def on_err(self, err):
        msg = "\n[Error: " + str(err) + "]\n"
        sublime.set_timeout(lambda: self.view.run_command("append_text", {"text": msg}), 0)
class AppendTextCommand(sublime_plugin.TextCommand):
    def run(self, edit, text):
        self.view.insert(edit, self.view.size(), text)
        self.view.show(self.view.size())
class ApiStreamThread(threading.Thread):
    def __init__(self, cfg, msgs, chunk_cb, done_cb, err_cb):
        threading.Thread.__init__(self)
        self.c = cfg
        self.m = msgs
        self.cb = chunk_cb
        self.d_cb = done_cb
        self.e_cb = err_cb
        self.stop_event = threading.Event()
    def run(self):
        try:
            host = self.c['ai_chat_base_url'].replace("https://", "").replace("http://", "")
            conn = http.client.HTTPSConnection(host, timeout=30)
            payload = json.dumps({
                "model": self.c['ai_chat_model'], 
                "messages": self.m, 
                "max_tokens": int(self.c.get('max_tokens', 2048)), 
                "stream": True
            })
            headers = {
                'Content-Type': 'application/json', 
                'Accept': 'text/event-stream',
                'Authorization': 'Bearer ' + self.c['ai_chat_api_key']
            }
            conn.request("POST", self.c['ai_chat_path'], payload, headers)
            response = conn.getresponse()
            if response.status != 200:
                self.e_cb("API error: " + str(response.status) + " " + response.reason)
                return
            buffer = b""
            full_text = []
            while not self.stop_event.is_set():
                chunk = response.read(16)
                if not chunk:
                    break
                buffer += chunk
                lines = buffer.split(b'\n')
                for line in lines[:-1]:
                    line = line.strip()
                    if not line:
                        continue
                    if line.startswith(b'data: '):
                        data = line[6:]
                        if data == b'[DONE]':
                            self.d_cb("".join(full_text))
                            return
                        try:
                            json_data = json.loads(data.decode('utf-8'))
                            if 'choices' in json_data and json_data['choices']:
                                text_chunk = get_chunk(json_data)
                                full_text.append(text_chunk)
                                self.cb(text_chunk)
                        except ValueError:
                            continue
                buffer = lines[-1]
            self.d_cb("".join(full_text))
        except Exception as e:
            self.e_cb(str(e))
        finally:
            try:
                conn.close()
            except:
                pass
    def stop(self):
        self.stop_event.set()

class ClearChatMemoryCommand(sublime_plugin.TextCommand):
    def run(self, edit):
        if self.view.id() in CHAT_MEMORY: del CHAT_MEMORY[self.view.id()]
        self.view.run_command("append_text", {"text": "\n[Memory Cleared]\n"})



















class JsonDumpsCommand(sublime_plugin.TextCommand):
    def run(self, edit):
        region = sublime.Region(0, self.view.size())
        content = self.view.substr(region)
        try:
            data = json.loads(content)
            pretty = json.dumps(data, indent=4, ensure_ascii=False)
            self.view.replace(edit, region, pretty)
            sublime.status_message("JSON 格式化成功")
        except json.JSONDecodeError as e:
            sublime.status_message("JSON 解析错误: "+str(e))











class FoldExcessLengthOnLoad(sublime_plugin.EventListener):
    def __init__(self):
        self.max_line_length = 500
    def on_load(self, view):
        self.fold_excess_length(view)
    def fold_excess_length(self, view):
        cfg = load_config()
        max_line_length = int(cfg.get('max_line_length', self.max_line_length))
        for region in view.lines(sublime.Region(0, view.size())):
            line_text = view.substr(region)
            if len(line_text) > max_line_length:
                excess_region = sublime.Region(region.begin() + max_line_length, region.end())
                view.fold(excess_region)
    def on_activated(self, view):
        self.fold_excess_length(view)









def parse_cmd(self, command):
    cmd = []
    _cmds = command.split(' ')
    is_right = False
    is_bottom = False
    is_goback = False
    is_bat = False
    is_auto_close = False
    for i in range(10):
        if _cmds[0] == '[close]':
            _cmds = _cmds[1:]
            is_auto_close = True
        if _cmds[0] == '[right]':
            is_right = True
            _cmds = _cmds[1:]
        if _cmds[0] == '[bottom]':
            is_bottom = True
            _cmds = _cmds[1:]
        if _cmds[0] == '[back]':
            is_goback = True
            _cmds = _cmds[1:]
        if _cmds[0] == '[bat]':
            _cmds = _cmds[1:]
            is_bat = True
        if "&&" in _cmds:
            is_bat = True
    cmd.extend(_cmds)
    file_path = self.view.file_name()
    if not file_path:
        print('no curr file')
        return
    cwd = os.path.dirname(file_path)
    for idx, i in enumerate(cmd):
        if "${file}" in i:
            file_name = os.path.split(file_path)[-1]
            cmd[idx] = file_name.join(i.split("${file}"))
    if is_bat:
        with open(self.batfile, 'w', encoding='utf8') as f:
            f.write("chcp 65001\n")
            for i in " ".join(cmd).split('&&'):
                f.write(i + '\n')
        cmd = [self.batfile]
    print(cmd)
    print(cwd)
    window = sublime.active_window()
    if is_right:
        window.set_layout({
            "cols": [0.0, 0.5, 1.0],
            "rows": [0.0, 1.0],
            "cells": [[0, 0, 1, 1], [1, 0, 2, 1]]
        })
        window.focus_group(1)
    if is_bottom:
        window.set_layout({
            "cols": [0.0, 1.0],
            "rows": [0.0, 0.5, 1.0],
            "cells": [[0, 0, 1, 1], [0, 1, 1, 2]]
        })
        window.focus_group(1)
    self.view.window().run_command("terminus_open", {
        "cmd": cmd,
        "cwd": cwd,
        "auto_close": is_auto_close,
    })
    if (is_right or is_bottom) and is_goback:
        sublime.set_timeout(lambda:window.focus_group(0), 300)

class VTerminuxCommand(sublime_plugin.TextCommand):
    cfgfile = os.path.join(os.path.expanduser("~"),'.vsublime.cfg.py')
    batfile = os.path.join(os.path.expanduser("~"),'.temp.bat')
    def run(self, edit):
        cfg = load_config()
        tabs = []
        if cfg.get('ai_chat_api_key') and cfg.get('ai_chat_api_key') != 'none':
            tabs.append(['[ai chat] (Ctrl+Enter)', 'ai_chat'])
        if cfg.get('ai_code_api_key') and cfg.get('ai_code_api_key') != 'none':
            tabs.append(['[ai code insert]', 'ai_insert'])
            tabs.append(['[ai code add]', 'ai_add'])
            tabs.append(['[ai code cancel]', 'ai_cancel'])
        tabs.append(['[json.dumps 4]', 'json_dumps'])
        for i in cfg['extra']: tabs.append([i, i])
        tabs.append(('[*] open_config', 'open_config'))
        tabs.append(('[*] terminus_open', 'terminus_open'))
        options = [name for name, _ in tabs]
        self.view.window().show_quick_panel(options, lambda index: self.on_done(index, tabs))
    def on_done(self, index, tabs):
        if index == -1: return
        command = tabs[index][1]
        if command == 'ai_chat':         self.view.window().run_command("v_universal_chat"); return
        if command == 'ai_add':          self.view.window().run_command("ai_curr_window_completion", { "type": "add" }); return
        if command == 'ai_insert':       self.view.window().run_command("ai_curr_window_completion", { "type": "insert" }); return
        if command == 'ai_cancel':       self.view.window().run_command("cancel_ai_completion"); return
        if command == 'json_dumps':      self.view.window().run_command("json_dumps"); return
        if command == 'open_config':     sublime.active_window().open_file(self.cfgfile); return
        if command == 'terminus_open':   self.view.window().run_command("terminus_open", { "cwd": "${file_path}" }); return
        parse_cmd(self, command)

class VCloseCommand(sublime_plugin.TextCommand):
    def run(self, edit):
        layout_one = {"cols": [0.0, 1.0], "rows": [0.0, 1.0], "cells": [[0, 0, 1, 1]]}
        if self.view.window().num_groups() == 2 and len(self.view.window().views_in_group(1)) == 0:
            self.view.window().set_layout(layout_one)
        else:
            self.view.window().run_command("close")