# Copyright 2025 BBDevs
# Licensed under the Apache License, Version 2.0

"""Structured logging module with async support.

Author: A M (am@bbdevs.com)

Created At: 08 Nov 2025
"""

from __future__ import annotations

import logging
import sys
from contextvars import ContextVar
from typing import Any

import structlog


__all__ = [
    "LogContext",
    "configure_logging",
    "get_logger",
    "log_context",
]

# Context variable for log context (async-safe)
_log_context: ContextVar[dict[str, Any]] = ContextVar("log_context", default={})


class LogContext:
    """Context manager for adding context to logs.

    Usage:
        with LogContext(request_id="req-123", operation="container_create"):
            logger.info("creating container")
            # Logs will include request_id and operation
    """

    def __init__(self, **context):
        """Initialize log context.

        Args:
            **context: Key-value pairs to add to log context
        """
        self.context = context
        self.token = None

    def __enter__(self):
        """Enter context manager."""
        current = _log_context.get().copy()
        current.update(self.context)
        self.token = _log_context.set(current)
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """Exit context manager."""
        if self.token:
            _log_context.reset(self.token)
        return False


def log_context(**context) -> LogContext:
    """Create a log context manager.

    Args:
        **context: Key-value pairs to add to log context

    Returns:
        LogContext instance

    Example:
        with log_context(request_id="req-123"):
            logger.info("processing request")
    """
    return LogContext(**context)


def add_context_processor(logger, method_name, event_dict):
    """Add context from ContextVar to event dict.

    This processor adds context from the ContextVar to all log events.
    """
    context = _log_context.get()
    event_dict.update(context)
    return event_dict


def add_log_level_processor(logger, method_name, event_dict):
    """Add log level to event dict."""
    if method_name == "debug":
        event_dict["level"] = "DEBUG"
    elif method_name == "info":
        event_dict["level"] = "INFO"
    elif method_name == "warning":
        event_dict["level"] = "WARNING"
    elif method_name == "error":
        event_dict["level"] = "ERROR"
    elif method_name == "critical":
        event_dict["level"] = "CRITICAL"
    return event_dict


def configure_logging(
    level: str = "INFO",
    format: str = "human",  # "human" or "json"
    log_file: str | None = None,
) -> None:
    """Configure structured logging.

    Args:
        level: Log level (DEBUG, INFO, WARNING, ERROR, CRITICAL)
        format: Output format ("human" for development, "json" for production)
        log_file: Optional log file path

    Example:
        configure_logging(level="DEBUG", format="human")
    """
    # Configure standard logging
    logging.basicConfig(
        format="%(message)s",
        stream=sys.stdout,
        level=getattr(logging, level.upper()),
    )

    # Configure structlog processors
    processors = [
        structlog.stdlib.filter_by_level,  # Filter by log level - IMPORTANT!
        structlog.stdlib.add_log_level,
        structlog.stdlib.add_logger_name,
        structlog.processors.TimeStamper(fmt="iso"),
        structlog.processors.StackInfoRenderer(),
        add_context_processor,  # Add context from ContextVar
        add_log_level_processor,  # Add log level
    ]

    # Add format-specific processors
    if format == "json":
        processors.append(structlog.processors.JSONRenderer())
    else:
        # Human-readable format for development
        processors.extend(
            [
                structlog.processors.ExceptionPrettyPrinter(),
                structlog.dev.ConsoleRenderer(colors=True),
            ]
        )

    # Configure structlog
    structlog.configure(
        processors=processors,
        wrapper_class=structlog.stdlib.BoundLogger,
        context_class=dict,
        logger_factory=structlog.stdlib.LoggerFactory(),
        cache_logger_on_first_use=True,
    )

    # Configure file handler if specified
    if log_file:
        file_handler = logging.FileHandler(log_file)
        file_handler.setLevel(getattr(logging, level.upper()))
        logging.root.addHandler(file_handler)


def get_logger(name: str | None = None) -> structlog.stdlib.BoundLogger:
    """Get a structured logger instance.

    Args:
        name: Logger name (typically __name__)

    Returns:
        Configured structlog logger

    Example:
        logger = get_logger(__name__)
        logger.info("operation_started", operation="container_create")
    """
    return structlog.get_logger(name)
