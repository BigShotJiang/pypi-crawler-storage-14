# Copyright 2025 BBDevs
# Licensed under the Apache License, Version 2.0

"""Async concurrency helpers.

Author: A M (am@bbdevs.com)

Created At: 08 Nov 2025
"""

from __future__ import annotations

import asyncio
from collections.abc import Awaitable
from typing import TypeVar

from ..logging import get_logger


__all__ = [
    "gather_with_limit",
    "run_with_semaphore",
]

logger = get_logger(__name__)

T = TypeVar("T")


async def run_with_semaphore(
    semaphore: asyncio.Semaphore,
    coro: Awaitable[T],
) -> T:
    """Run a coroutine with semaphore rate limiting.

    Args:
        semaphore: Semaphore for rate limiting
        coro: Coroutine to run

    Returns:
        Result of coroutine

    Example:
        sem = asyncio.Semaphore(5)
        result = await run_with_semaphore(sem, fetch_data())
    """
    async with semaphore:
        return await coro


async def gather_with_limit(
    limit: int,
    *coros: Awaitable[T],
    return_exceptions: bool = False,
) -> list[T]:
    """Run multiple coroutines with concurrency limit.

    Args:
        limit: Maximum number of concurrent coroutines
        *coros: Coroutines to run
        return_exceptions: If True, exceptions are returned instead of raised

    Returns:
        List of results

    Example:
        results = await gather_with_limit(
            5,
            fetch_data(1),
            fetch_data(2),
            fetch_data(3),
        )
    """
    semaphore = asyncio.Semaphore(limit)

    logger.debug(
        "gather_with_limit_start",
        limit=limit,
        total_tasks=len(coros),
    )

    tasks = [run_with_semaphore(semaphore, coro) for coro in coros]
    results = await asyncio.gather(*tasks, return_exceptions=return_exceptions)

    logger.debug(
        "gather_with_limit_complete",
        limit=limit,
        total_tasks=len(coros),
    )

    return results
