# Copyright 2025 BBDevs
# Licensed under the Apache License, Version 2.0

"""Extended Thread class with logging and monitoring.

Author: A M (am@bbdevs.com)

Created At: 08 Nov 2025
"""

from __future__ import annotations

import threading
import time
from collections.abc import Callable
from contextvars import copy_context

from ..logging import get_logger


__all__ = ["LoggingThread"]

logger = get_logger(__name__)


class LoggingThread(threading.Thread):
    """Extended Thread class with automatic logging and context propagation.

    Features:
    - Automatic logging of thread lifecycle (start, run, exception, finish)
    - Thread name propagation to logs
    - Exception capturing and logging
    - Execution time tracking
    - Context propagation (contextvars)

    Usage:
        def worker(arg1, arg2):
            # Do work
            pass

        thread = LoggingThread(target=worker, args=(1, 2), name="worker-1")
        thread.start()
        thread.join()
    """

    def __init__(
        self,
        group=None,
        target: Callable | None = None,
        name: str | None = None,
        args: tuple = (),
        kwargs: dict | None = None,
        *,
        daemon: bool | None = None,
    ):
        """Initialize logging thread.

        Args:
            group: Reserved for future extension
            target: Callable object to be invoked by run()
            name: Thread name
            args: Argument tuple for target invocation
            kwargs: Dictionary of keyword arguments for target invocation
            daemon: Whether thread is a daemon thread
        """
        super().__init__(
            group=group,
            target=target,
            name=name,
            args=args,
            kwargs=kwargs or {},
            daemon=daemon,
        )
        self._target = target
        self._args = args
        self._kwargs = kwargs or {}
        self._start_time: float | None = None
        self._end_time: float | None = None
        self._exception: Exception | None = None
        self._context = copy_context()  # Capture context at creation time

    def run(self) -> None:
        """Run the thread with logging and exception handling."""
        self._start_time = time.time()

        logger.info(
            "thread_started",
            thread_name=self.name,
            thread_id=self.ident,
            daemon=self.daemon,
        )

        try:
            # Run target in captured context
            if self._target:
                self._context.run(self._target, *self._args, **self._kwargs)
        except Exception as e:
            self._exception = e
            logger.error(
                "thread_exception",
                thread_name=self.name,
                thread_id=self.ident,
                exception=str(e),
                exception_type=type(e).__name__,
                exc_info=True,
            )
        finally:
            self._end_time = time.time()
            duration_ms = (self._end_time - self._start_time) * 1000

            logger.info(
                "thread_finished",
                thread_name=self.name,
                thread_id=self.ident,
                duration_ms=duration_ms,
                success=self._exception is None,
            )

    @property
    def duration_ms(self) -> float | None:
        """Get thread execution duration in milliseconds.

        Returns:
            Duration in milliseconds or None if thread hasn't finished
        """
        if self._start_time is None or self._end_time is None:
            return None
        return (self._end_time - self._start_time) * 1000

    @property
    def exception(self) -> Exception | None:
        """Get exception raised by thread if any.

        Returns:
            Exception instance or None
        """
        return self._exception
