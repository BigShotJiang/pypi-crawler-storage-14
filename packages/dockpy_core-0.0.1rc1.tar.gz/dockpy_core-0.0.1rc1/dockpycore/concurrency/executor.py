# Copyright 2025 BBDevs
# Licensed under the Apache License, Version 2.0

"""Extended ThreadPoolExecutor with logging and monitoring.

Author: A M (am@bbdevs.com)

Created At: 08 Nov 2025
"""

from __future__ import annotations

import time
import uuid
from collections.abc import Callable
from concurrent.futures import Future, ThreadPoolExecutor
from contextvars import copy_context

from ..logging import get_logger


__all__ = ["LoggingThreadPoolExecutor"]

logger = get_logger(__name__)


class LoggingThreadPoolExecutor(ThreadPoolExecutor):
    """Extended ThreadPoolExecutor with automatic logging and monitoring.

    Features:
    - Automatic logging of task submission, start, completion, failure
    - Task execution time tracking
    - Worker thread monitoring
    - Queue size monitoring
    - Graceful shutdown with logging
    - Callback hooks for task lifecycle events
    - Context propagation (contextvars)

    Usage:
        async with LoggingThreadPoolExecutor(max_workers=10) as executor:
            future = executor.submit(blocking_operation, arg1, arg2)
            result = await asyncio.wrap_future(future)
    """

    def __init__(
        self,
        max_workers: int | None = None,
        thread_name_prefix: str = "LoggingThread",
        initializer: Callable | None = None,
        initargs: tuple = (),
    ):
        """Initialize logging thread pool executor.

        Args:
            max_workers: Maximum number of worker threads (default: min(32, cpu_count + 4))
            thread_name_prefix: Prefix for worker thread names
            initializer: Callable run at start of each worker thread
            initargs: Arguments for initializer
        """
        super().__init__(
            max_workers=max_workers,
            thread_name_prefix=thread_name_prefix,
            initializer=initializer,
            initargs=initargs,
        )
        self._task_count = 0
        self._active_tasks = 0

        logger.info(
            "executor_created",
            max_workers=self._max_workers,
            thread_name_prefix=thread_name_prefix,
        )

    def submit(self, fn: Callable, /, *args, **kwargs) -> Future:
        """Submit a callable to be executed with logging.

        Args:
            fn: Callable to execute
            *args: Positional arguments for callable
            **kwargs: Keyword arguments for callable

        Returns:
            Future representing the execution
        """
        task_id = str(uuid.uuid4())[:8]
        self._task_count += 1
        self._active_tasks += 1

        logger.debug(
            "task_submitted",
            task_id=task_id,
            function=fn.__name__,
            total_tasks=self._task_count,
            active_tasks=self._active_tasks,
        )

        # Capture context at submission time
        context = copy_context()

        # Wrap function with logging
        def wrapped_fn():
            start_time = time.time()

            logger.debug(
                "task_started",
                task_id=task_id,
                function=fn.__name__,
            )

            try:
                # Run in captured context
                result = context.run(fn, *args, **kwargs)

                duration_ms = (time.time() - start_time) * 1000
                logger.debug(
                    "task_completed",
                    task_id=task_id,
                    function=fn.__name__,
                    duration_ms=duration_ms,
                    success=True,
                )

                return result

            except Exception as e:
                duration_ms = (time.time() - start_time) * 1000
                logger.error(
                    "task_failed",
                    task_id=task_id,
                    function=fn.__name__,
                    duration_ms=duration_ms,
                    exception=str(e),
                    exception_type=type(e).__name__,
                    exc_info=True,
                )
                raise
            finally:
                self._active_tasks -= 1

        # Submit wrapped function
        future = super().submit(wrapped_fn)

        return future

    def shutdown(self, wait: bool = True, *, cancel_futures: bool = False) -> None:
        """Shutdown executor with logging.

        Args:
            wait: Wait for pending futures to complete
            cancel_futures: Cancel pending futures
        """
        logger.info(
            "executor_shutdown",
            wait=wait,
            cancel_futures=cancel_futures,
            total_tasks=self._task_count,
            active_tasks=self._active_tasks,
        )

        super().shutdown(wait=wait, cancel_futures=cancel_futures)

        logger.info("executor_shutdown_complete")

    def __enter__(self):
        """Enter context manager."""
        logger.debug("executor_context_enter")
        return super().__enter__()

    def __exit__(self, exc_type, exc_val, exc_tb):
        """Exit context manager."""
        logger.debug("executor_context_exit", has_exception=exc_type is not None)
        return super().__exit__(exc_type, exc_val, exc_tb)

    @property
    def task_count(self) -> int:
        """Get total number of tasks submitted.

        Returns:
            Total task count
        """
        return self._task_count

    @property
    def active_tasks(self) -> int:
        """Get number of currently active tasks.

        Returns:
            Active task count
        """
        return self._active_tasks
