# Copyright 2025 BBDevs
# Licensed under the Apache License, Version 2.0

"""Async utilities and helpers.

Author: A M (am@bbdevs.com)

Created At: 08 Nov 2025
"""

from __future__ import annotations

import asyncio
import functools
import time
from collections.abc import Awaitable, Callable
from typing import TypeVar

from .logging import get_logger


__all__ = [
    "async_retry",
    "async_timeout",
    "measure_time",
]

logger = get_logger(__name__)

T = TypeVar("T")


def async_retry(
    max_attempts: int = 3,
    delay: float = 1.0,
    backoff: float = 2.0,
    exceptions: tuple[type[Exception], ...] = (Exception,),
) -> Callable:
    """Decorator for retrying async functions with exponential backoff.

    Args:
        max_attempts: Maximum number of retry attempts
        delay: Initial delay between retries in seconds
        backoff: Multiplier for delay after each retry
        exceptions: Tuple of exception types to catch and retry

    Returns:
        Decorated function

    Example:
        @async_retry(max_attempts=3, delay=1.0, backoff=2.0)
        async def fetch_data():
            # May fail and be retried
            pass
    """

    def decorator(func: Callable[..., Awaitable[T]]) -> Callable[..., Awaitable[T]]:
        @functools.wraps(func)
        async def wrapper(*args, **kwargs) -> T:
            current_delay = delay

            for attempt in range(1, max_attempts + 1):
                try:
                    logger.debug(
                        "retry_attempt",
                        function=func.__name__,
                        attempt=attempt,
                        max_attempts=max_attempts,
                    )
                    return await func(*args, **kwargs)

                except exceptions as e:
                    if attempt == max_attempts:
                        logger.error(
                            "retry_exhausted",
                            function=func.__name__,
                            attempts=attempt,
                            exception=str(e),
                        )
                        raise

                    logger.warning(
                        "retry_failed",
                        function=func.__name__,
                        attempt=attempt,
                        exception=str(e),
                        next_delay=current_delay,
                    )

                    await asyncio.sleep(current_delay)
                    current_delay *= backoff

        return wrapper

    return decorator


def async_timeout(seconds: float) -> Callable:
    """Decorator for adding timeout to async functions.

    Args:
        seconds: Timeout in seconds

    Returns:
        Decorated function

    Raises:
        asyncio.TimeoutError: If function exceeds timeout

    Example:
        @async_timeout(30.0)
        async def long_operation():
            # Will timeout after 30 seconds
            pass
    """

    def decorator(func: Callable[..., Awaitable[T]]) -> Callable[..., Awaitable[T]]:
        @functools.wraps(func)
        async def wrapper(*args, **kwargs) -> T:
            try:
                logger.debug(
                    "timeout_start",
                    function=func.__name__,
                    timeout=seconds,
                )
                return await asyncio.wait_for(func(*args, **kwargs), timeout=seconds)

            except asyncio.TimeoutError:
                logger.error(
                    "timeout_exceeded",
                    function=func.__name__,
                    timeout=seconds,
                )
                raise

        return wrapper

    return decorator


def measure_time(func: Callable[..., Awaitable[T]]) -> Callable[..., Awaitable[T]]:
    """Decorator for measuring async function execution time.

    Args:
        func: Async function to measure

    Returns:
        Decorated function

    Example:
        @measure_time
        async def slow_operation():
            await asyncio.sleep(1)
    """

    @functools.wraps(func)
    async def wrapper(*args, **kwargs) -> T:
        start_time = time.time()

        try:
            result = await func(*args, **kwargs)
            duration_ms = (time.time() - start_time) * 1000

            logger.debug(
                "function_completed",
                function=func.__name__,
                duration_ms=duration_ms,
            )

            return result

        except Exception as e:
            duration_ms = (time.time() - start_time) * 1000

            logger.error(
                "function_failed",
                function=func.__name__,
                duration_ms=duration_ms,
                exception=str(e),
            )
            raise

    return wrapper
