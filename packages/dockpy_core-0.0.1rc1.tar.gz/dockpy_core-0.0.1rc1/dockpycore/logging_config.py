# Copyright 2025 BBDevs
# Licensed under the Apache License, Version 2.0

"""Logging configuration defaults.

Author: A M (am@bbdevs.com)

Created At: 08 Nov 2025
"""

from __future__ import annotations

import os
from pathlib import Path


__all__ = [
    "DEFAULT_LOG_DIR",
    "DEFAULT_LOG_FORMAT",
    "DEFAULT_LOG_LEVEL",
    "get_log_file",
    "get_log_format",
    "get_log_level",
]

# Default configuration
DEFAULT_LOG_LEVEL = "INFO"
DEFAULT_LOG_FORMAT = "human"  # "human" or "json"
DEFAULT_LOG_DIR = Path("logs")


def get_log_level() -> str:
    """Get log level from environment or default.

    Returns:
        Log level (DEBUG, INFO, WARNING, ERROR, CRITICAL)

    Environment:
        dockpycli_LOG_LEVEL: Override default log level
    """
    return os.getenv("dockpycli_LOG_LEVEL", DEFAULT_LOG_LEVEL).upper()


def get_log_format() -> str:
    """Get log format from environment or default.

    Returns:
        Log format ("human" or "json")

    Environment:
        dockpycli_LOG_FORMAT: Override default log format
    """
    return os.getenv("dockpycli_LOG_FORMAT", DEFAULT_LOG_FORMAT).lower()


def get_log_file(name: str = "dockpycli") -> Path | None:
    """Get log file path from environment or default.

    Args:
        name: Base name for log file

    Returns:
        Log file path or None if logging to file is disabled

    Environment:
        dockpycli_LOG_FILE: Override log file path
        dockpycli_LOG_DIR: Override log directory
    """
    # Check if file logging is explicitly disabled
    if os.getenv("dockpycli_LOG_FILE", "").lower() == "none":
        return None

    # Get custom log file path
    log_file = os.getenv("dockpycli_LOG_FILE")
    if log_file:
        return Path(log_file)

    # Get log directory
    log_dir = Path(os.getenv("dockpycli_LOG_DIR", str(DEFAULT_LOG_DIR)))

    # Create log directory if it doesn't exist
    log_dir.mkdir(parents=True, exist_ok=True)

    # Return log file path
    return log_dir / f"{name}.log"
