# Copyright 2025 BBDevs
# Licensed under the Apache License, Version 2.0

"""Type definitions for dockpycli.

Author: A M (am@bbdevs.com)

Created At: 08 Nov 2025
"""

from __future__ import annotations

from typing import TypedDict


__all__ = [
    "ContainerConfig",
    "ExecutorConfig",
    "HostConfig",
    "ImageConfig",
    "LogContext",
    "NetworkConfig",
    "VolumeConfig",
]


class ContainerConfig(TypedDict, total=False):
    """Docker container configuration.

    Based on Docker Engine API container create endpoint.
    """

    Image: str
    Cmd: list[str]
    Entrypoint: list[str]
    Env: list[str]
    ExposedPorts: dict[str, dict]
    Volumes: dict[str, dict]
    WorkingDir: str
    Labels: dict[str, str]
    StopSignal: str
    StopTimeout: int
    Hostname: str
    Domainname: str
    User: str
    AttachStdin: bool
    AttachStdout: bool
    AttachStderr: bool
    Tty: bool
    OpenStdin: bool
    StdinOnce: bool
    NetworkDisabled: bool


class HostConfig(TypedDict, total=False):
    """Docker host configuration.

    Based on Docker Engine API HostConfig object.
    """

    Binds: list[str]
    PortBindings: dict[str, list[dict]]
    NetworkMode: str
    RestartPolicy: dict[str, str | int]
    Memory: int
    MemorySwap: int
    MemoryReservation: int
    CpuShares: int
    CpuPeriod: int
    CpuQuota: int
    CpusetCpus: str
    CpusetMems: str
    Privileged: bool
    ReadonlyRootfs: bool
    Dns: list[str]
    DnsSearch: list[str]
    ExtraHosts: list[str]
    VolumesFrom: list[str]
    CapAdd: list[str]
    CapDrop: list[str]
    LogConfig: dict[str, str | dict]
    SecurityOpt: list[str]
    StorageOpt: dict[str, str]
    Ulimits: list[dict]


class ImageConfig(TypedDict, total=False):
    """Docker image configuration."""

    fromImage: str
    tag: str
    platform: str


class NetworkConfig(TypedDict, total=False):
    """Docker network configuration."""

    Name: str
    Driver: str
    Internal: bool
    Attachable: bool
    Ingress: bool
    IPAM: dict
    EnableIPv6: bool
    Options: dict[str, str]
    Labels: dict[str, str]


class VolumeConfig(TypedDict, total=False):
    """Docker volume configuration."""

    Name: str
    Driver: str
    DriverOpts: dict[str, str]
    Labels: dict[str, str]


class LogContext(TypedDict, total=False):
    """Logging context for structured logs."""

    request_id: str
    operation: str
    resource_type: str
    resource_id: str
    duration_ms: float
    status_code: int
    error: str
    worker_id: str
    task_id: str
    thread_name: str


class ExecutorConfig(TypedDict, total=False):
    """Configuration for LoggingThreadPoolExecutor."""

    max_workers: int
    thread_name_prefix: str
    initializer: callable
    initargs: tuple
