# Copyright 2025 BBDevs
# Licensed under the Apache License, Version 2.0

"""Exception hierarchy for dockpycli.

Author: A M (am@bbdevs.com)

Created At: 08 Nov 2025
"""

from __future__ import annotations


__all__ = [
    "APIError",
    "ConflictError",
    "ConnectionError",
    "ContainerError",
    "DockerError",
    "DockerSDKError",
    "ImageError",
    "NetworkError",
    "NotFound",
    "ThreadError",
    "ThreadPoolError",
    "TimeoutError",
    "ValidationError",
    "VolumeError",
]


class DockerError(Exception):
    """Base exception for all dockpy errors (shared across all packages).

    This is the top-level exception that all other exceptions inherit from.
    Used across core, SDK, and CLI packages.
    """

    def __init__(self, message: str, details: dict | None = None):
        """Initialize exception with message and optional details.

        Args:
            message: Human-readable error message
            details: Additional context/details as dictionary
        """
        super().__init__(message)
        self.message = message
        self.details = details or {}


class DockerSDKError(DockerError):
    """Base exception for SDK-level errors.

    All SDK-specific exceptions inherit from this class.
    Automatically logged when raised (if logger is available).
    """

    def __init__(self, message: str, **context):
        """Initialize exception with message and optional context.

        Args:
            message: Human-readable error message
            **context: Additional context (resource_id, operation, etc.)
        """
        super().__init__(message, details=context)
        self.context = context


class APIError(DockerSDKError):
    """Docker API returned an error response.

    Raised when Docker Engine API returns an error status code.
    """

    def __init__(self, message: str, status_code: int, response: dict | None = None, **context):
        """Initialize API error.

        Args:
            message: Error message
            status_code: HTTP status code from API
            response: Full API response body
            **context: Additional context
        """
        super().__init__(message, **context)
        self.status_code = status_code
        self.response = response or {}


class NotFound(APIError):
    """Resource not found (404).

    Raised when requested Docker resource doesn't exist.
    """

    def __init__(self, resource_type: str, resource_id: str, **context):
        """Initialize not found error.

        Args:
            resource_type: Type of resource (container, image, network, volume)
            resource_id: ID or name of resource
            **context: Additional context
        """
        message = f"{resource_type} '{resource_id}' not found"
        super().__init__(
            message,
            404,
            resource_type=resource_type,
            resource_id=resource_id,
            **context,
        )


class ContainerError(DockerSDKError):
    """Container operation error.

    Raised when container operation fails.
    """

    def __init__(self, message: str, container_id: str | None = None, **context):
        """Initialize container error.

        Args:
            message: Error message
            container_id: Container ID (if available)
            **context: Additional context
        """
        super().__init__(message, container_id=container_id, **context)
        self.container_id = container_id


class ImageError(DockerSDKError):
    """Image operation error.

    Raised when image operation fails.
    """

    def __init__(self, message: str, image: str | None = None, **context):
        """Initialize image error.

        Args:
            message: Error message
            image: Image name or ID (if available)
            **context: Additional context
        """
        super().__init__(message, image=image, **context)
        self.image = image


class NetworkError(DockerSDKError):
    """Network operation error.

    Raised when network operation fails.
    """

    def __init__(self, message: str, network_id: str | None = None, **context):
        """Initialize network error.

        Args:
            message: Error message
            network_id: Network ID (if available)
            **context: Additional context
        """
        super().__init__(message, network_id=network_id, **context)
        self.network_id = network_id


class VolumeError(DockerSDKError):
    """Volume operation error.

    Raised when volume operation fails.
    """

    def __init__(self, message: str, volume_name: str | None = None, **context):
        """Initialize volume error.

        Args:
            message: Error message
            volume_name: Volume name (if available)
            **context: Additional context
        """
        super().__init__(message, volume_name=volume_name, **context)
        self.volume_name = volume_name


class TimeoutError(DockerSDKError):
    """Operation timed out.

    Raised when operation exceeds timeout limit.
    """

    def __init__(self, message: str, timeout: float, **context):
        """Initialize timeout error.

        Args:
            message: Error message
            timeout: Timeout value in seconds
            **context: Additional context
        """
        super().__init__(message, timeout=timeout, **context)
        self.timeout = timeout


class ThreadPoolError(DockerSDKError):
    """Thread pool operation error.

    Raised when thread pool operation fails.
    """

    def __init__(self, message: str, **context):
        """Initialize thread pool error.

        Args:
            message: Error message
            **context: Additional context
        """
        super().__init__(message, **context)


class ThreadError(DockerSDKError):
    """Thread operation error.

    Raised when thread operation fails.
    """

    def __init__(self, message: str, thread_name: str | None = None, **context):
        """Initialize thread error.

        Args:
            message: Error message
            thread_name: Thread name (if available)
            **context: Additional context
        """
        super().__init__(message, thread_name=thread_name, **context)
        self.thread_name = thread_name


class ValidationError(DockerError):
    """Input validation error.

    Raised when input validation fails.
    """

    def __init__(self, field: str, message: str):
        """Initialize validation error.

        Args:
            field: Name of the field that failed validation
            message: Validation error message
        """
        super().__init__(f"Validation error on '{field}': {message}", {"field": field})
        self.field = field


class ConnectionError(DockerError):
    """Docker daemon connection error.

    Raised when cannot connect to Docker daemon.
    """

    def __init__(self, endpoint: str, reason: str | None = None):
        """Initialize connection error.

        Args:
            endpoint: Docker daemon endpoint (socket path or URL)
            reason: Reason for connection failure (if available)
        """
        msg = f"Cannot connect to Docker daemon at {endpoint}"
        if reason:
            msg += f": {reason}"
        super().__init__(msg, {"endpoint": endpoint, "reason": reason})
        self.endpoint = endpoint
        self.reason = reason


class ConflictError(APIError):
    """Resource conflict error (409).

    Raised when operation conflicts with existing resource.
    """

    def __init__(self, message: str, resource_type: str | None = None, **context):
        """Initialize conflict error.

        Args:
            message: Error message
            resource_type: Type of resource in conflict
            **context: Additional context
        """
        super().__init__(message, 409, resource_type=resource_type, **context)
        self.resource_type = resource_type
