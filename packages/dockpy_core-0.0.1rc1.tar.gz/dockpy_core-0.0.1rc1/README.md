# dockpy-core

Shared types, exceptions, logging, and threading utilities for the dockpy project.

## Installation

```bash
pip install dockpy-core
```

## Features

- **Exception Hierarchy**: Custom exception types with auto-logging
- **Structured Logging**: Built on structlog with context propagation
- **Threading**: Custom `LoggingThreadPoolExecutor` for concurrent operations
- **Type Hints**: Modern Python 3.10+ type annotations
- **Async Support**: Utilities for async/sync bridging

## Quick Start

```python
from dockpycore.logging import get_logger
from dockpycore.exceptions import DockerSDKError

logger = get_logger(__name__)

try:
    # Your code here
    pass
except DockerSDKError as e:
    logger.error("docker_error", error=str(e))
```

## Documentation

See the [main repository](https://gerrit.bbdevs.com/dockpy) for full documentation.

## License

Apache License 2.0 - See LICENSE file for details.

