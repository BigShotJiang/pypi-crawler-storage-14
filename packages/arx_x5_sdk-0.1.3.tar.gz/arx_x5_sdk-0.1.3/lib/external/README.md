# External Bundled Libraries

This directory contains external shared libraries that are bundled with the ARX X5 SDK to simplify distribution.

## libkdl_parser.so.1d

**Description**: KDL (Kinematics and Dynamics Library) URDF parser  
**Source**: ROS (Robot Operating System) ecosystem  
**License**: BSD (from ros-planning/kdl_parser)  
**Purpose**: Used by `libarx_x5_src.so` to parse URDF robot description files

### Why Bundled?

This library is typically part of ROS, which is a large framework. By bundling it:
- Users don't need to install full ROS to use the ARX X5 SDK
- Installation is simpler and more portable
- Version compatibility is guaranteed

### Build Process

During `pip install` or `uv pip install`, the `setup.py` script:
1. Copies `libkdl_parser.so.1d` from this directory to the package
2. Sets RPATH on `libarx_x5_src.so` so it finds dependencies in the same directory
3. Bundles everything in the Python wheel for distribution

### Technical Details

- **Size**: ~90KB
- **Dependencies**: `liborocos-kdl.so.1.5` (must be installed system-wide)
- **Architecture**: x86_64 (for other architectures, rebuild from source)

### License Compliance

The KDL parser library is licensed under BSD-3-Clause. If you redistribute this SDK, ensure you comply with the license terms. The original source can be found at:
- https://github.com/ros/kdl_parser

---
*Last updated: 2025-11-25*

