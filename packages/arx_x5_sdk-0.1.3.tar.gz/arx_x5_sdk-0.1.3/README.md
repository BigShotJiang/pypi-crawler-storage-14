# ARX X5 SDK

Python bindings for the ARX X5 robot arm. Control ARX X5 arms via CAN interface.

This package is based on the [official ARX X5 Python SDK](https://github.com/ARXroboticsX/ARX_X5/tree/main/py/arx_x5_python) and provides an easy-to-install, well-documented Python package published to [PyPI](https://pypi.org/project/arx-x5-sdk/).

**Special thanks to the ARX Robotics team for developing the original SDK and making it available to the community!**

## Why This Package?

- **Easy Installation**: `pip install arx-x5-sdk` (no complex build steps for users)
- **Bundled Dependencies**: Includes necessary libraries - no ROS installation required
- **Clean API**: Modular, better-documented Python interface
- **Production Ready**: Proper package structure with comprehensive documentation

## Installation

### Prerequisites

```bash
# Build and runtime dependencies
sudo apt install build-essential cmake python3-dev patchelf liborocos-kdl-dev liburdfdom-dev
```

> **Note**: KDL URDF parser is bundled - no ROS installation needed!

### Install from Source

```bash
git clone https://github.com/uma-robots/arx-x5-sdk.git
cd arx-x5-sdk
pip install .
```

> **Note**: Due to CMake build requirements, editable mode (`pip install -e .`) is not recommended. Reinstall after changes with `pip install --force-reinstall .`

## Quick Start

```python
from arx_x5_sdk import ArxInterface, ArmType

# Connect to arm on CAN interface
arm = ArxInterface("can0", ArmType.X5_2025)
```

> **Note**: For leader-follower teleoperation, you can use the same arm type (e.g. ArmType.X5_2025)

### Available Arm Types

```python
ArmType.FOLLOWER                  # Follower arm
ArmType.LEADER                    # Leader/master arm  
ArmType.X5_2025                   # X5 2025 model (default)
ArmType.X5_2025_LOWER_MASS_LINK6  # X5 2025 with corrected gravity compensation
```

## Advanced Usage

### Custom URDF

```python
from arx_x5_sdk import C_ArxInterface, get_urdf_path

urdf_path = get_urdf_path("x5_2025_lower_mass_link6.urdf")
arm = C_ArxInterface(urdf_path, "can0", 2)
```

### Get URDF Path

```python
from arx_x5_sdk import get_urdf_path, get_urdf_path_by_type, ArmType

# By filename
path = get_urdf_path("x5_2025.urdf")

# By arm type
path = get_urdf_path_by_type(ArmType.LEADER)
```

## Architecture Support

- **x86_64**: Fully supported
- **ARM64**: Supported (may have verbose output)

## Development & Publishing

This project uses GitHub Actions for CI/CD:

- **[`.github/workflows/build.yml`](.github/workflows/build.yml)** - CI testing on every push/PR
- **[`.github/workflows/publish.yml`](.github/workflows/publish.yml)** - Publish releases to PyPI (triggered by version tags)
- **[`.github/workflows/test-publish.yml`](.github/workflows/test-publish.yml)** - Test publishing to TestPyPI (manual)

See each workflow file for detailed documentation on triggers, usage, and requirements.

## Documentation

- **URDF files**: See `arx_x5_sdk/urdf/README.md` for gravity compensation fixes
- **Library details**: See `lib/arx_x5_src/README.md` for pre-built libraries info
- **Bundled dependencies**: See `lib/external/README.md` for third-party libraries

## Troubleshooting

**Build fails**: Check prerequisites are installed
```bash
sudo apt install build-essential cmake python3-dev patchelf liborocos-kdl-dev liburdfdom-dev
```

**Import fails**: Reinstall the package
```bash
pip install --force-reinstall .
```

**Gravity compensation issues**: Use `x5_2025_lower_mass_link6.urdf` (see `urdf/README.md`)
