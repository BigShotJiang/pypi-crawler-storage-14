"""ARX X5 SDK type definitions."""

from enum import IntEnum


class ArmType(IntEnum):
    """ARX arm type identifiers."""
    FOLLOWER = 0
    LEADER = 1
    X5_2025 = 2
    X5_2025_LOWER_MASS_LINK6 = 2  # Alias for X5_2025

