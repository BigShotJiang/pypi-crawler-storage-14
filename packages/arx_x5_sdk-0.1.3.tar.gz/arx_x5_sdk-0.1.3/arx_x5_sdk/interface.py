"""ARX X5 SDK high-level interface."""

from ._loader import load_extension
from .types import ArmType
from .utils import get_urdf_path_by_type

# Load C++ extension
_ext = load_extension()
C_ArxInterface = _ext.C_ArxInterface


class ArxInterface(C_ArxInterface):
    """
    High-level ARX interface with automatic URDF selection.
    
    Example:
        >>> arm = ArxInterface("can0", ArmType.X5_2025)
        >>> arm = ArxInterface("can1", arm_type=ArmType.LEADER)
    """
    
    def __init__(self, can_port: str, arm_type: ArmType | int = ArmType.X5_2025):
        """
        Initialize ARX interface.
        
        Args:
            can_port: CAN interface name (e.g., "can0")
            arm_type: Arm type (default: X5_2025)
        """
        urdf_path = get_urdf_path_by_type(arm_type)
        super().__init__(urdf_path, can_port, int(arm_type))

