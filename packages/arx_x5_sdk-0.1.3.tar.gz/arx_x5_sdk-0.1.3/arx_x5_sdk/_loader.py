"""Internal module for loading ARX X5 SDK C++ extensions."""

import ctypes
import importlib.util
from pathlib import Path


def load_extension():
    """
    Load the ARX X5 SDK C++ extension module.
    
    Returns:
        module: The loaded C++ extension module
        
    Raises:
        ImportError: If the extension or its dependencies cannot be loaded
    """
    package_dir = Path(__file__).parent.absolute()
    
    # Find the Python extension module
    so_files = list(package_dir.glob("arx_x5_sdk*.so"))
    if not so_files:
        raise ImportError(
            f"Extension module not found in {package_dir}. "
            "Reinstall the package with: pip install --force-reinstall arx-x5-sdk"
        )
    
    # Check for bundled dependency (informational only - RPATH handles loading)
    kdl_parser_lib = package_dir / "libkdl_parser.so.1d"
    if not kdl_parser_lib.exists():
        import warnings
        warnings.warn(
            f"Bundled dependency missing: {kdl_parser_lib}\n"
            "Reinstall the package to fix this."
        )
    
    # Preload main C++ library (libarx_x5_src.so)
    # This must be loaded with RTLD_GLOBAL before the Python extension
    lib_path = package_dir / "libarx_x5_src.so"
    arm64_lib_path = package_dir / "libarx_x5_src-arm64.so"
    
    loaded = False
    last_error = None
    
    for lib in [lib_path, arm64_lib_path]:
        if lib.exists():
            try:
                ctypes.CDLL(str(lib), mode=ctypes.RTLD_GLOBAL)
                loaded = True
                break
            except OSError as e:
                last_error = str(e)
                continue
    
    if not loaded:
        error_msg = f"Failed to load C++ library. Tried: {lib_path}"
        if arm64_lib_path != lib_path:
            error_msg += f", {arm64_lib_path}"
        if last_error:
            error_msg += f"\nError: {last_error}"
        raise ImportError(error_msg)
    
    # Load the Python extension module
    # Use "arx_x5_sdk" as module name (matches PyInit_arx_x5_sdk in the .so)
    spec = importlib.util.spec_from_file_location("arx_x5_sdk", so_files[0])
    if not spec or not spec.loader:
        raise ImportError(f"Failed to load extension: {so_files[0]}")
    
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    
    return module

