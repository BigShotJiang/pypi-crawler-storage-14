"""ARX X5 SDK utility functions."""

from pathlib import Path

from .types import ArmType

_PACKAGE_DIR = Path(__file__).parent


def get_urdf_path(urdf_name: str = "x5_2025.urdf") -> str:
    """
    Get path to a URDF file included in the package.
    
    Args:
        urdf_name: URDF filename (e.g., "x5_2025.urdf")
        
    Returns:
        Absolute path to the URDF file
        
    Raises:
        FileNotFoundError: If URDF file doesn't exist
    """
    urdf_path = _PACKAGE_DIR / "urdf" / urdf_name
    if not urdf_path.exists():
        raise FileNotFoundError(f"URDF not found: {urdf_path}")
    return str(urdf_path)


def get_urdf_path_by_type(arm_type: ArmType | int) -> str:
    """
    Get URDF path for a given arm type.
    
    Args:
        arm_type: ArmType enum or int (0-2)
        
    Returns:
        Absolute path to the URDF file
        
    Raises:
        ValueError: If arm_type is invalid
    """
    urdf_map = {
        0: "x5.urdf",                          # FOLLOWER
        1: "x5_master.urdf",                   # LEADER
        2: "x5_2025.urdf",                     # X5_2025 and X5_2025_LOWER_MASS_LINK6
    }
    
    type_int = int(arm_type)
    if type_int not in urdf_map:
        raise ValueError(f"Invalid arm_type: {arm_type} (must be 0, 1, or 2)")
    
    return get_urdf_path(urdf_map[type_int])

