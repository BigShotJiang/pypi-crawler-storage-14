# comparator
::: horde_model_reference.sync.comparator
