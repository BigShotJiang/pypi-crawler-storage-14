# metadata
::: horde_model_reference.service.v1.routers.metadata
