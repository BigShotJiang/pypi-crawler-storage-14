# shared
::: horde_model_reference.service.shared
