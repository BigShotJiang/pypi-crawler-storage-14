# legacy_models
::: horde_model_reference.legacy.classes.legacy_models
