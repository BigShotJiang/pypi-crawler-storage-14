# validate_sd
::: horde_model_reference.legacy.validate_sd
