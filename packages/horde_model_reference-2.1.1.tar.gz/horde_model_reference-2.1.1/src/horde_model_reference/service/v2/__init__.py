"""FastAPI service for the (v2) API for the Horde Model Reference."""
