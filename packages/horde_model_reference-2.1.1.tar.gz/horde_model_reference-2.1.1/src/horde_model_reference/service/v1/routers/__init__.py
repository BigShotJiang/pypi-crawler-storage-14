"""FastAPI routers for the legacy (v1) API service."""
