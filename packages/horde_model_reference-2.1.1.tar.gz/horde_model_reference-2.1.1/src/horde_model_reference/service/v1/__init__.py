"""The legacy (v1) API service for the Horde Model Reference."""
