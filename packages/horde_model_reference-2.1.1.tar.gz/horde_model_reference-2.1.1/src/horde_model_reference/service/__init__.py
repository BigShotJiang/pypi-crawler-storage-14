"""FastAPI service for accessing and manipulating the Horde Model Reference data."""
