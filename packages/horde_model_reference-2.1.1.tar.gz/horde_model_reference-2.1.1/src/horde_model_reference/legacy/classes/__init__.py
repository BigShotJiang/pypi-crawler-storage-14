"""Class definitions for legacy model database records."""
