from ..base_devices import BaseDeviceV2


class EP800(BaseDeviceV2):
    pass
