"""Configuration module for supported formats."""
