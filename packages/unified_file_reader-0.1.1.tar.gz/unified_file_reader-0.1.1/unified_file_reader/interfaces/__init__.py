"""Interfaces and abstract contracts for the reader system."""
