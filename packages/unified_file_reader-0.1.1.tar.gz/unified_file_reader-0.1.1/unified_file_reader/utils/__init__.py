"""Utility functions for file operations."""
