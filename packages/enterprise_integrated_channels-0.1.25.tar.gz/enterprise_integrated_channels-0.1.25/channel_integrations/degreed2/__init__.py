# -*- coding: utf-8 -*-
"""
The Degreed2 Integrated Channel package.
"""

__version__ = "0.0.1"
