from .app.main import main

main()
