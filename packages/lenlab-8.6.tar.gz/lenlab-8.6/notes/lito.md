New Evaluation-Module "LITO" without on-board debugger

Debugger Board XDS110-ETP https://www.ti.com/lit/ug/slau959/slau959.pdf
