# Python Project

2024-07-10

## Build Tool

Hatchling https://hatch.pypa.io/latest/

From this overview https://alpopkes.com/posts/python/packaging_tools/, I looked at rye, hatch, and flit.
Rye uses build and twine to build python packages. Build has only scarce documentation.
Flit cannot run "build steps", i.e. cannot compile the firmware binary.
