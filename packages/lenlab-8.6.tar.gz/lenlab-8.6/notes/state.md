# State

- not connected
  - no board
  - no firmware
  - error
- idle
- active
  - programmer
  - voltmeter
  - oscilloscope
  - bode


