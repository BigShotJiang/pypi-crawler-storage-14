# Qt

2024-10-11

## Plots

Qt offers QtCharts and QtGraphs. QtGraphs is the newer technology and supposed to replace QtCharts.
Today though (Qt 6.8), QtGraph does not support logarithmic axes.
