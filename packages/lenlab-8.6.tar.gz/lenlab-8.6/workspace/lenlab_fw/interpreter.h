#ifndef INTERPRETER_H
#define INTERPRETER_H

void interpreter_handleCommand(void);

#endif
