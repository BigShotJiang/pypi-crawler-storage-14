.. _gridder:

***************************************
Gridder (:mod:`pyvisgrid.core.gridder`)
***************************************

.. currentmodule:: pyvisgrid.core.gridder

Gridding submodule of :mod:`pyvisgrid.core`.


Reference/API
=============

.. automodapi:: pyvisgrid.core.gridder
    :inherited-members:
