"""Model-specific handling for different architectures."""

from .hooks import HookedModel

__all__ = [
    "HookedModel",
]
