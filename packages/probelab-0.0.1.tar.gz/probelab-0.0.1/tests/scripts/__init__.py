"""Scripts tests package."""
