from setup_wizard.config import load_config


def test_load_config_default():
    cfg = load_config(config_path="nonexistent.json")
    assert "runtime" in cfg
    assert "paths" in cfg
