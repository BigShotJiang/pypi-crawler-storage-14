from __future__ import annotations

from dataclasses import dataclass, field
from typing import List

from .prompts import console


@dataclass
class StepResult:
    name: str
    status: str  # "done", "skipped", "failed"
    details: str = ""


_results: List[StepResult] = []


def record_step(name: str, status: str, details: str = "") -> None:
    _results.append(StepResult(name=name, status=status, details=details))


def clear_results() -> None:
    _results.clear()


def print_health_summary() -> None:
    console.print()
    console.rule("[bold]Setup summary[/bold]")

    if not _results:
        console.print("No steps recorded.")
        return

    for step in _results:
        icon = {"done": "✅", "skipped": "⚠️", "failed": "❌"}.get(step.status, "•")
        line = f"{icon} [bold]{step.name}[/bold]: {step.status}"
        if step.details:
            line += f" – {step.details}"
        console.print(line)
