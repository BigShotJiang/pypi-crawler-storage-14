from __future__ import annotations

import os
import subprocess
from pathlib import Path
from typing import Dict, Any

from ..prompts import log, warn, section, ask_yes_no
from ..health import record_step
from .venv_step import venv_python_path


def run_health_checks(cfg: Dict[str, Any], auto_yes: bool) -> None:
    section("Health checks")

    app_import = cfg["paths"]["app_import"]

    log(
        "I can run a basic health check by importing your application module "
        f"({app_import}). This can catch obvious setup problems."
    )
    if not ask_yes_no(
        "Run health checks now?",
        default=True,
        auto_yes=auto_yes,
    ):
        record_step("health_check", "skipped", "User skipped")
        return

    # Build the small Python snippet we want to run
    code = f"import importlib; importlib.import_module('{app_import}')"

    # Prepare env: add ./src to PYTHONPATH if it exists (common src-layout)
    env = os.environ.copy()
    src_dir = Path("src")
    if src_dir.exists():
        existing = env.get("PYTHONPATH", "")
        new_path = str(src_dir.resolve())
        if existing:
            env["PYTHONPATH"] = new_path + os.pathsep + existing
        else:
            env["PYTHONPATH"] = new_path
        log(f"Health check: using PYTHONPATH={env['PYTHONPATH']}")

    py = venv_python_path(cfg)
    cmd = [str(py), "-c", code]
    log(f"Running health check in venv: {' '.join(cmd)}")

    try:
        subprocess.check_call(cmd, env=env)
        record_step("health_check", "done", f"Imported {app_import}")
        log("Import check succeeded.")
    except subprocess.CalledProcessError as e:
        warn(f"Health check failed: {e}")
        record_step("health_check", "failed", str(e))
