from __future__ import annotations

from typing import Dict, Any

from ..prompts import log, warn, section, ask_yes_no
from ..health import record_step
from .venv_step import run_in_venv


def install_dev_tools(cfg: Dict[str, Any], auto_yes: bool) -> None:
    tools = cfg.get("dev_tools") or []
    if not tools:
        return  # nothing to do

    section("Optional: Dev tools (formatters/linters)")

    log(
        "I can install optional dev tools (e.g. formatter and linter) into the project "
        "virtualenv. These won't affect any global Python installation."
    )
    log(f"Configured tools: {', '.join(tools)}")

    if not ask_yes_no(
        "Install these dev tools into the venv?",
        default=True,
        auto_yes=auto_yes,
    ):
        record_step("dev_tools", "skipped", "User skipped")
        return

    try:
        run_in_venv(cfg, ["-m", "pip", "install", *tools])
        record_step("dev_tools", "done", f"Installed: {', '.join(tools)}")
    except Exception as e:
        warn(f"Dev tools installation failed: {e}")
        record_step("dev_tools", "failed", str(e))
