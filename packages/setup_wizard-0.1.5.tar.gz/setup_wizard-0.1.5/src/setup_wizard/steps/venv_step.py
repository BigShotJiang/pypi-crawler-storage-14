from __future__ import annotations

import os
import subprocess
import sys
from pathlib import Path
from typing import Dict, Any, List, Optional, Tuple

from ..prompts import log, warn, section, ask_yes_no
from ..health import record_step

PROJECT_ROOT = Path.cwd()


def _probe_python(cmd: List[str]) -> Optional[Tuple[int, int]]:
    try:
        out = subprocess.check_output(
            cmd
            + [
                "-c",
                "import sys; print(f'{sys.version_info[0]}.{sys.version_info[1]}')",
            ],
            stderr=subprocess.DEVNULL,
            text=True,
        )
    except (OSError, subprocess.CalledProcessError):
        return None
    out = out.strip()
    try:
        major_str, minor_str = out.split(".")
        return int(major_str), int(minor_str)
    except Exception:
        return None


def _discover_target_python(
    cfg: Dict[str, Any], cli_python: Optional[str]
) -> Tuple[List[str], Tuple[int, int]]:
    min_py = cfg["runtime"]["_min_python_tuple"]

    if cli_python:
        cmd = [cli_python]
        ver = _probe_python(cmd)
        if not ver:
            raise RuntimeError(f"Could not execute target python: {cli_python}")
        if ver < min_py:
            raise RuntimeError(
                f"Target python {ver[0]}.{ver[1]} is too old. Need >= {min_py[0]}.{min_py[1]}"
            )
        return cmd, ver

    candidates: List[List[str]] = []
    candidates.append([sys.executable])

    preferred = cfg["runtime"].get("preferred_python")
    if preferred:
        if os.name == "nt":
            candidates.append(["py", f"-{preferred}"])
        else:
            candidates.append([f"python{preferred}"])

    if os.name == "nt":
        candidates += [
            ["py", "-3.14"],
            ["py", "-3.13"],
            ["py", "-3.12"],
            ["py", "-3.11"],
            ["python"],
        ]
    else:
        candidates += [
            ["python3.14"],
            ["python3.13"],
            ["python3.12"],
            ["python3.11"],
            ["python3"],
            ["python"],
        ]

    best: Optional[Tuple[List[str], Tuple[int, int]]] = None
    section("Python runtime")
    for cmd in candidates:
        ver = _probe_python(cmd)
        if not ver:
            continue
        log(f"Found candidate {' '.join(cmd)} -> Python {ver[0]}.{ver[1]}")
        if ver >= min_py:
            if best is None or ver > best[1]:
                best = (cmd, ver)

    if best is None:
        raise RuntimeError(
            f"Could not find a Python interpreter >= {min_py[0]}.{min_py[1]}.\n"
            "Install e.g. Python 3.14 and re-run setup-wizard with:\n"
            "  setup-wizard --python /path/to/python3.14"
        )

    cmd, ver = best
    log(f"Using target Python: {' '.join(cmd)} (version {ver[0]}.{ver[1]})")
    return cmd, ver


def venv_dir(cfg: Dict[str, Any]) -> Path:
    return PROJECT_ROOT / cfg["paths"]["venv_dir"]


def venv_python_path(cfg: Dict[str, Any]) -> Path:
    if os.name == "nt":
        return venv_dir(cfg) / "Scripts" / "python.exe"
    else:
        return venv_dir(cfg) / "bin" / "python"


def run_in_venv(cfg: Dict[str, Any], args: list[str]) -> None:
    py = venv_python_path(cfg)
    cmd = [str(py), *args]
    log(f"Running in venv: {' '.join(cmd)}")
    subprocess.check_call(cmd)


def ensure_venv(cfg: Dict[str, Any], cli_python: Optional[str], auto_yes: bool) -> bool:
    """
    Create or reuse venv based on config.
    Returns True if we should consider the venv available (even if reused),
    False if user chose to skip.
    """
    section("Step 1/3: Virtual environment")

    vdir = venv_dir(cfg)
    log(f"Configured venv dir: {vdir}")

    create = True
    if vdir.exists():
        log("A virtualenv already exists at that location.")
        create = False

    if not ask_yes_no(
        "Create or reuse the virtualenv for this project?",
        default=True,
        auto_yes=auto_yes,
    ):
        warn(
            "User chose to skip venv creation/reuse. Steps depending on venv may fail."
        )
        record_step("venv", "skipped", "User skipped venv")
        return False

    try:
        target_cmd, target_ver = _discover_target_python(cfg, cli_python)
    except Exception as e:
        warn(str(e))
        record_step("venv", "failed", str(e))
        return False

    if create:
        log(f"Creating virtualenv at {vdir} using {' '.join(target_cmd)}")
        try:
            # Try virtualenv first
            log("Trying: target_python -m virtualenv .venv")
            result = subprocess.run(
                target_cmd + ["-m", "virtualenv", str(vdir)],
                text=True,
                capture_output=True,
            )
            if result.returncode != 0:
                warn("virtualenv failed; falling back to stdlib venv.")
                if result.stderr:
                    warn(f"virtualenv stderr:\n{result.stderr}")
                subprocess.check_call(target_cmd + ["-m", "venv", str(vdir)])
                log("Created .venv using stdlib venv.")
            else:
                log("Created .venv using virtualenv.")
            record_step(
                "venv", "done", f"Created with Python {target_ver[0]}.{target_ver[1]}"
            )
        except Exception as e:
            record_step("venv", "failed", str(e))
            warn(f"Failed to create venv: {e}")
            return False
    else:
        log("Reusing existing virtualenv.")
        record_step("venv", "done", "Reused existing venv")

    return True
