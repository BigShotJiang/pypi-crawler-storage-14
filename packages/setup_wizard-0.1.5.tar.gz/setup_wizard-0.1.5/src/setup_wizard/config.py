from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict


DEFAULT_CONFIG: Dict[str, Any] = {
    "project_name": "Unnamed project",
    "runtime": {
        "min_python": "3.11",  # minimum project runtime
        "preferred_python": None,  # e.g. "3.14"
    },
    "paths": {
        "venv_dir": ".venv",
        "env_file": ".env",
        "env_example": ".env.example",
        "requirements": "requirements.txt",
        "app_import": "src",
        "readme": "README.md",
    },
    "dev_tools": [],  # e.g. ["black", "ruff"]
    "vscode": {
        "enable_launch": True,
        "entry_module": "src",
        "use_black_formatter": False,
    },
}


def _parse_version(ver: str) -> tuple[int, int]:
    parts = ver.split(".")
    if len(parts) == 1:
        return int(parts[0]), 0
    return int(parts[0]), int(parts[1])


def load_config(config_path: str | None = None) -> Dict[str, Any]:
    """
    Load config from a JSON file (default: setup_wizard.json in CWD),
    and merge with DEFAULT_CONFIG.
    """
    base = DEFAULT_CONFIG.copy()
    base["runtime"] = DEFAULT_CONFIG["runtime"].copy()
    base["paths"] = DEFAULT_CONFIG["paths"].copy()
    base["vscode"] = DEFAULT_CONFIG["vscode"].copy()
    base["dev_tools"] = list(DEFAULT_CONFIG["dev_tools"])

    path = Path(config_path or "setup_wizard.json")
    if not path.exists():
        return base

    data = json.loads(path.read_text(encoding="utf-8"))

    base["project_name"] = data.get("project_name", base["project_name"])

    runtime = data.get("runtime", {})
    base["runtime"].update(runtime)

    paths = data.get("paths", {})
    base["paths"].update(paths)

    vscode = data.get("vscode", {})
    base["vscode"].update(vscode)

    base["dev_tools"] = data.get("dev_tools", base["dev_tools"])

    # convenience: pre-parse min_python
    min_py_str = base["runtime"]["min_python"]
    base["runtime"]["_min_python_tuple"] = _parse_version(min_py_str)

    pref = base["runtime"].get("preferred_python")
    if pref:
        base["runtime"]["_preferred_python_tuple"] = _parse_version(pref)
    else:
        base["runtime"]["_preferred_python_tuple"] = None

    return base
