"""setup_wizard - interactive project setup wizard."""

__all__ = ["__version__"]

__version__ = "0.1.5"
