from setuptools import setup

print("[setup.py] --> Success!")

setup(
    name="demozeco",
    version="2.0.0",
    packages=["demozeco"],
)
