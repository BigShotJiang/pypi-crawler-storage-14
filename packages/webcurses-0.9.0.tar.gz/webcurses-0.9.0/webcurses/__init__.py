import threading
import time
import queue
import json
import logging
import sys
import os
from flask import Flask, Response, request, render_template_string

# Disable Flask logging
log = logging.getLogger('werkzeug')
log.setLevel(logging.ERROR)

app = Flask(__name__)

# Global state
SCREEN_WIDTH = 80
SCREEN_HEIGHT = 24
screen_buffer = [[' ' for _ in range(SCREEN_WIDTH)] for _ in range(SCREEN_HEIGHT)]
input_queue = queue.Queue()
clients = []

# Key constants (mapping to curses constants where possible/relevant)
KEY_DOWN = 258
KEY_UP = 259
KEY_LEFT = 260
KEY_RIGHT = 261
KEY_ENTER = 10 # ASCII for newline
KEY_BACKSPACE = 127

# Mapping from JS key names to curses constants or ASCII
KEY_MAP = {
    'ArrowDown': KEY_DOWN,
    'ArrowUp': KEY_UP,
    'ArrowLeft': KEY_LEFT,
    'ArrowRight': KEY_RIGHT,
    'Enter': KEY_ENTER,
    'Backspace': KEY_BACKSPACE,
    'Escape': 27,
}

import hashlib

last_hash = None

def _update_clients():
    """Notify all connected SSE clients that the screen has changed."""
    global last_hash
    # We don't actually push data here, just a signal or the data itself.
    # For simplicity, let's push the data.
    current_data = ["".join(row) for row in screen_buffer]
    data_str = json.dumps(current_data)
    
    # Compute hash
    new_hash = hashlib.md5(data_str.encode('utf-8')).hexdigest()
    
    if new_hash != last_hash:
        last_hash = new_hash
        msg = f"data: {data_str}\n\n"
        for q in clients:
            q.put(msg)

@app.route('/')
def index():
    path = os.path.join(os.path.dirname(__file__), 'templates', 'index.html')
    with open(path, 'r') as f:
        return render_template_string(f.read())

@app.route('/stream')
def stream():
    def event_stream():
        q = queue.Queue()
        clients.append(q)
        # Send initial screen
        data = json.dumps(["".join(row) for row in screen_buffer])
        yield f"data: {data}\n\n"
        try:
            while True:
                msg = q.get()
                yield msg
        except GeneratorExit:
            clients.remove(q)

    return Response(event_stream(), mimetype="text/event-stream")

@app.route('/input', methods=['POST'])
def input_route():
    data = request.json
    key = data.get('key')
    
    # Map key to integer code
    if key in KEY_MAP:
        code = KEY_MAP[key]
    elif len(key) == 1:
        code = ord(key)
    else:
        # Ignore unknown special keys for now
        return "OK"
    
    input_queue.put(code)
    return "OK"

def _run_server(port=8080):
    print(f"Webcurses running at http://localhost:{port}")
    try:
        app.run(host='0.0.0.0', port=port, threaded=True, use_reloader=False)
    except Exception as e:
        print(f"Server error: {e}")

@app.route('/shutdown', methods=['POST'])
def shutdown():
    raise RuntimeError('Server shutting down...')

# Curses-like API

class Window:
    def __init__(self, height, width, begin_y, begin_x):
        self.height = height
        self.width = width
        self.begin_y = begin_y
        self.begin_x = begin_x
        self.keypad_enabled = False
        self.timeout_ms = -1 # Blocking by default

    def getmaxyx(self):
        return self.height, self.width

    def addstr(self, y, x, string):
        # Handle basic wrapping or clipping? For now, simple clipping.
        for i, char in enumerate(string):
            if 0 <= y < self.height and 0 <= x + i < self.width:
                # Update global buffer directly for now (assuming one window)
                # In a real curses impl, this would be local to window until refresh
                # But here we treat the window as the screen.
                if 0 <= self.begin_y + y < SCREEN_HEIGHT and 0 <= self.begin_x + x + i < SCREEN_WIDTH:
                    screen_buffer[self.begin_y + y][self.begin_x + x + i] = char

    def addch(self, y, x, ch):
        self.addstr(y, x, str(ch))

    def clear(self):
        for y in range(self.height):
            for x in range(self.width):
                if 0 <= self.begin_y + y < SCREEN_HEIGHT and 0 <= self.begin_x + x < SCREEN_WIDTH:
                    screen_buffer[self.begin_y + y][self.begin_x + x] = ' '

    def refresh(self):
        _update_clients()

    def getch(self):
        try:
            if self.timeout_ms == -1:
                return input_queue.get()
            elif self.timeout_ms == 0:
                return input_queue.get_nowait()
            else:
                return input_queue.get(timeout=self.timeout_ms / 1000.0)
        except queue.Empty:
            return -1

    def keypad(self, yes):
        self.keypad_enabled = yes

    def timeout(self, delay):
        self.timeout_ms = delay
        
    def nodelay(self, flag):
        self.timeout_ms = 0 if flag else -1

    def inch(self, y, x):
        if 0 <= self.begin_y + y < SCREEN_HEIGHT and 0 <= self.begin_x + x < SCREEN_WIDTH:
            char = screen_buffer[self.begin_y + y][self.begin_x + x]
            return ord(char)
        return 0

# Global stdscr
stdscr = None

def initscr():
    global stdscr
    # Start server thread
    port = int(os.environ.get('WEBCURSES_PORT', '8080'))
    t = threading.Thread(target=_run_server, args=(port,), daemon=True)
    t.start()
    
    # Give it a moment to start?
    time.sleep(1)
    
    stdscr = Window(SCREEN_HEIGHT, SCREEN_WIDTH, 0, 0)
    return stdscr

def endwin():
    port = int(os.environ.get('WEBCURSES_PORT', '8080'))
    try:
        import urllib.request
        urllib.request.urlopen(f"http://localhost:{port}/shutdown", data=b"", timeout=1)
    except Exception:
        pass

def wrapper(func, *args, **kwargs):
    try:
        stdscr = initscr()
        return func(stdscr, *args, **kwargs)
    except Exception as e:
        # print(e)
        raise e
    finally:
        endwin()

def curs_set(visibility):
    pass

def DEBUG():
    pass




