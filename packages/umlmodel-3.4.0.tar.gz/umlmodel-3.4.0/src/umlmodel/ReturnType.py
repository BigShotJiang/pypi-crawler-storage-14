
from umlmodel.UmlType import UmlType

class ReturnType(UmlType):
    """
    Syntactic Sugar
    """
    pass
