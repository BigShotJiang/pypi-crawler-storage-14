
from umlmodel.UmlType import UmlType


class FieldType(UmlType):
    """
    Syntactic Sugar
    """
    pass
