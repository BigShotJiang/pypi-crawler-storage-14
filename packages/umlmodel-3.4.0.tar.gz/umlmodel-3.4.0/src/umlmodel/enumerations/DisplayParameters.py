
from enum import Enum


class DisplayParameters(Enum):
    """
    """

    DISPLAY_PARAMETERS        = 'Display Parameters'
    DO_NOT_DISPLAY_PARAMETERS = 'Do Not Display Parameters'
    UNSPECIFIED               = 'Unspecified'
