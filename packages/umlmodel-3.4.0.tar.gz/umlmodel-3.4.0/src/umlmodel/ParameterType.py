
from umlmodel.UmlType import UmlType

class ParameterType(UmlType):
    """
    Syntactic Sugar
    """
    pass
