"""
Manager-Klassen für spezialisierte Operationen.

Organisiert die High-Level API in fokussierte, wiederverwendbare Komponenten.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from loguru import logger

from .models import (
    Namespace,
    Role,
    SystemInfo,
    TimeZone,
    Unit,
)

if TYPE_CHECKING:
    from .client import QuestraDataCore


class BaseManager:
    """Basisklasse für alle Manager."""

    def __init__(self, client: QuestraDataCore):
        """
        Initialisiert den Manager.

        Args:
            client: QuestraDataCore Client für Low-Level Operationen
        """
        self._client = client


class CatalogManager(BaseManager):
    """
    Manager für Katalog-Operationen (System-Infos, Roles, Units, TimeZones).

    Bietet Zugriff auf system-weite Metadaten und Katalog-Informationen.
    """

    def get_system_info(self) -> SystemInfo:
        """
        Ruft System-Informationen ab.

        Returns:
            SystemInfo: System-Informationen inkl. Version

        Examples:
            ```python
            info = client.catalog.get_system_info()
            print(f"System Version: {info.version}")
            ```
        """
        logger.info("Getting system info")
        return self._client.queries.get_system_info()

    def list_namespaces(self) -> list[Namespace]:
        """
        Listet alle Namespaces auf.

        Returns:
            list[Namespace]: Liste von Namespace-Objekten

        Examples:
            ```python
            namespaces = client.catalog.list_namespaces()
            for ns in namespaces:
                print(f"- {ns.name}: {ns.description}")
            ```
        """
        logger.info("Listing namespaces")
        return self._client.queries.get_namespaces()

    def list_roles(self) -> list[Role]:
        """
        Listet alle Roles auf.

        Returns:
            list[Role]: Liste von Role-Objekten

        Examples:
            ```python
            roles = client.catalog.list_roles()
            for role in roles:
                print(f"- {role.name}: {role.description}")
            ```
        """
        logger.info("Listing roles")
        return self._client.queries.get_roles()

    def list_units(self) -> list[Unit]:
        """
        Listet alle Units auf.

        Returns:
            list[Unit]: Liste von Unit-Objekten

        Examples:
            ```python
            units = client.catalog.list_units()
            for unit in units:
                print(f"- {unit.symbol}: {unit.aggregation}")
            ```
        """
        logger.info("Listing units")
        return self._client.queries.get_units()

    def list_time_zones(self) -> list[TimeZone]:
        """
        Listet alle verfügbaren Zeitzonen auf.

        Returns:
            list[TimeZone]: Liste von TimeZone-Objekten

        Examples:
            ```python
            time_zones = client.catalog.list_time_zones()
            for tz in time_zones:
                print(f"- {tz.name}: UTC{tz.base_utc_offset}")
            ```
        """
        logger.info("Listing time zones")
        return self._client.queries.get_time_zones()
