"""REST-API Wrapper für Questra Data."""

from collections.abc import Callable

from loguru import logger

from .operations.rest_audit import AuditOperations
from .operations.rest_file import FileOperations
from .operations.rest_timeseries import TimeSeriesOperations


class RestAPI:
    """
    Aggregiert alle REST-API-Operationen.

    Bietet Zugriff auf TimeSeries-, File- und Audit-Endpoints.
    """

    def __init__(
        self,
        rest_get_func: Callable,
        rest_post_func: Callable,
    ):
        """
        Initialisiert die REST-API.

        Args:
            rest_get_func: Funktion für GET-Requests
            rest_post_func: Funktion für POST-Requests
        """
        logger.debug("Initializing REST API")

        self._timeseries = TimeSeriesOperations(
            rest_get_func=rest_get_func,
            rest_post_func=rest_post_func,
        )

        self._files = FileOperations(
            rest_get_func=rest_get_func,
            rest_post_func=rest_post_func,
        )

        self._audit = AuditOperations(
            rest_get_func=rest_get_func,
        )

        logger.debug("REST API initialized")

    @property
    def timeseries(self) -> TimeSeriesOperations:
        """
        Zugriff auf TimeSeries-Operationen.

        Returns:
            TimeSeriesOperations-Instanz
        """
        return self._timeseries

    @property
    def files(self) -> FileOperations:
        """
        Zugriff auf File-Operationen.

        Returns:
            FileOperations-Instanz
        """
        return self._files

    @property
    def audit(self) -> AuditOperations:
        """
        Zugriff auf Audit-Operationen.

        Returns:
            AuditOperations-Instanz
        """
        return self._audit
