"""System-bezogene Type Models."""

from __future__ import annotations

from dataclasses import dataclass


@dataclass
class MemoryInfo:
    """
    Speicher-Informationen.

    Attributes:
        total_mb: Gesamtspeicher in MB
        used_mb: Verwendeter Speicher in MB
        free_mb: Freier Speicher in MB
        available_percent: Verfügbarer Speicher in Prozent
    """

    total_mb: str  # DecimalWithPrecisionString
    used_mb: str  # DecimalWithPrecisionString
    free_mb: str  # DecimalWithPrecisionString
    available_percent: str  # DecimalWithPrecisionString

    @staticmethod
    def from_dict(data: dict) -> MemoryInfo:
        """Erstellt MemoryInfo aus GraphQL Response."""
        return MemoryInfo(
            total_mb=data["totalMb"],
            used_mb=data["usedMb"],
            free_mb=data["freeMb"],
            available_percent=data["availablePercent"],
        )


@dataclass
class MessageInfo:
    """
    Nachrichten-Informationen.

    Attributes:
        code: Nachrichtencode
        template: Nachrichtenvorlage (optional)
        category: Kategorie (optional)
    """

    code: str
    template: str | None = None
    category: str | None = None

    @staticmethod
    def from_dict(data: dict) -> MessageInfo:
        """Erstellt MessageInfo aus GraphQL Response."""
        return MessageInfo(
            code=data["code"],
            template=data.get("template"),
            category=data.get("category"),
        )


@dataclass
class SystemInfo:
    """
    System-Informationen.

    Attributes:
        dynamic_objects_version: Version von Dynamic Objects
        database_version: Version der Datenbank
        memory_info: Speicher-Informationen
        message_infos: Liste der Nachrichten-Informationen (optional, nur wenn explizit abgefragt)
    """

    dynamic_objects_version: str
    database_version: str
    memory_info: MemoryInfo
    message_infos: list[MessageInfo] | None = None

    @staticmethod
    def from_dict(data: dict) -> SystemInfo:
        """Erstellt SystemInfo aus GraphQL Response."""
        message_infos_data = data.get("messageInfos")
        return SystemInfo(
            dynamic_objects_version=data["dynamicObjectsVersion"],
            database_version=data["databaseVersion"],
            memory_info=MemoryInfo.from_dict(data["memoryInfo"]),
            message_infos=[MessageInfo.from_dict(m) for m in message_infos_data]
            if message_infos_data
            else None,
        )


@dataclass
class TimeZone:
    """
    Zeitzone.

    Attributes:
        name: Name der Zeitzone (z.B. "Europe/Berlin")
        base_utc_offset: Basis-UTC-Offset
        supports_daylight_saving_time: Unterstützt Sommerzeit
    """

    name: str
    base_utc_offset: str
    supports_daylight_saving_time: bool

    @staticmethod
    def from_dict(data: dict) -> TimeZone:
        """Erstellt TimeZone aus GraphQL Response."""
        return TimeZone(
            name=data["name"],
            base_utc_offset=data["baseUtcOffset"],
            supports_daylight_saving_time=data["supportsDaylightSavingTime"],
        )


@dataclass
class Unit:
    """
    Einheit.

    Attributes:
        symbol: Symbol der Einheit (z.B. "kW", "kWh")
        aggregation: Standard-Aggregation
    """

    symbol: str
    aggregation: str  # Aggregation__EnumType as string

    @staticmethod
    def from_dict(data: dict) -> Unit:
        """Erstellt Unit aus GraphQL Response."""
        return Unit(
            symbol=data["symbol"],
            aggregation=data["aggregation"],
        )


@dataclass
class UnitConversion:
    """
    Einheiten-Konvertierung.

    Attributes:
        target_unit: Zieleinheit
        source_unit: Quelleinheit (optional)
        factor: Umrechnungsfaktor
        offset: Umrechnungs-Offset
        interval: Optionales Intervall
    """

    target_unit: str
    factor: str  # DecimalWithPrecisionString
    offset: str  # DecimalWithPrecisionString
    source_unit: str | None = None
    interval: dict | None = None  # _Interval__Type

    @staticmethod
    def from_dict(data: dict) -> UnitConversion:
        """Erstellt UnitConversion aus GraphQL Response."""
        return UnitConversion(
            target_unit=data["targetUnit"],
            factor=data["factor"],
            offset=data["offset"],
            source_unit=data.get("sourceUnit"),
            interval=data.get("interval"),
        )


@dataclass
class Charset:
    """
    Zeichensatz.

    Attributes:
        value: Zeichensatz-Name
    """

    value: str

    @staticmethod
    def from_dict(data: dict) -> Charset:
        """Erstellt Charset aus GraphQL Response."""
        return Charset(value=data["value"])


@dataclass
class MediaType:
    """
    Medientyp (MIME-Typ).

    Attributes:
        value: MIME-Typ (z.B. "application/pdf")
    """

    value: str

    @staticmethod
    def from_dict(data: dict) -> MediaType:
        """Erstellt MediaType aus GraphQL Response."""
        return MediaType(value=data["value"])
