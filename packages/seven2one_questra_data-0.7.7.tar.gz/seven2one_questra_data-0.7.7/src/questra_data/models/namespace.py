"""Namespace Type Models."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime


@dataclass
class Namespace:
    """
    Namespace (Schema).

    Attributes:
        name: Name des Namespace
        is_system: System-Namespace Flag
        created_by: Ersteller UUID
        created_at: Erstellungszeitpunkt
        altered_by: Bearbeiter UUID
        altered_at: Bearbeitungszeitpunkt
        description: Optionale Beschreibung
    """

    name: str
    is_system: bool
    created_by: str
    created_at: datetime
    altered_by: str
    altered_at: datetime
    description: str | None = None

    @staticmethod
    def from_dict(data: dict) -> Namespace:
        """Erstellt Namespace aus GraphQL Response."""
        return Namespace(
            name=data["name"],
            is_system=data["isSystem"],
            created_by=data["createdBy"],
            created_at=datetime.fromisoformat(data["createdAt"].replace("Z", "+00:00")),
            altered_by=data["alteredBy"],
            altered_at=datetime.fromisoformat(data["alteredAt"].replace("Z", "+00:00")),
            description=data.get("description"),
        )
