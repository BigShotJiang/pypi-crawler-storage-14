"""REST-API Modelle für Questra Data."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime

# Importiere gemeinsam genutzte TimeSeries-Modelle
from .timeseries import (
    Aggregation,
    Interval,
    QuotationBehavior,
    TimeSeriesValue,
    ValueAlignment,
    ValueAvailability,
)


@dataclass
class TimeSeriesData:
    """
    Zeitreihen-Daten für eine TimeSeries.

    Attributes:
        time_series_id: ID der TimeSeries
        interval: Zeitintervall der Werte
        unit: Einheit der Werte
        time_zone: Zeitzone
        values: Liste der Zeitreihen-Werte
    """

    time_series_id: int
    interval: Interval
    unit: str | None = None
    time_zone: str | None = None
    values: list[TimeSeriesValue] = field(default_factory=list)


@dataclass
class TimeSeriesDataPayload:
    """
    Payload für Zeitreihen-Daten.

    Attributes:
        data: Liste von Zeitreihen-Daten
    """

    data: list[TimeSeriesData] = field(default_factory=list)


@dataclass
class SetTimeSeriesDataInput:
    """
    Input für das Setzen von Zeitreihen-Daten.

    Attributes:
        time_series_id: ID der TimeSeries
        values: Zu setzende Werte
        interval: Zeitintervall (optional)
        unit: Einheit (optional)
        time_zone: Zeitzone (optional)
        quotation_time: Quotierungszeitpunkt (optional)
    """

    time_series_id: int
    values: list[TimeSeriesValue]
    interval: Interval | None = None
    unit: str | None = None
    time_zone: str | None = None
    quotation_time: datetime | None = None


@dataclass
class TimeSeriesPayload:
    """
    Metadaten einer Zeitreihe.

    Attributes:
        id: TimeSeries ID
        created_by: Ersteller
        created_at: Erstellungszeitpunkt
        altered_by: Letzter Bearbeiter
        altered_at: Letzte Änderung
        interval: Zeitintervall
        value_alignment: Wert-Ausrichtung
        value_availability: Wert-Verfügbarkeit
        unit: Einheit
        time_zone: Zeitzone
        default_aggregation: Standard-Aggregation
        start_of_time: Zeitreihen-Beginn
        audit_enabled: Audit aktiviert
        quotation_enabled: Quotierung aktiviert
        default_quotation_behavior: Standard-Quotierungsverhalten
    """

    id: int
    created_by: str
    created_at: datetime
    altered_by: str
    altered_at: datetime
    interval: Interval
    value_alignment: ValueAlignment
    value_availability: ValueAvailability
    unit: str | None
    time_zone: str | None
    default_aggregation: Aggregation
    start_of_time: datetime
    audit_enabled: bool
    quotation_enabled: bool
    default_quotation_behavior: QuotationBehavior


@dataclass
class QuotationValue:
    """
    Einzelner Quotierungs-Wert.

    Attributes:
        time: Quotierungszeitpunkt
        from_time: Gültig von
        to_time: Gültig bis
    """

    time: datetime
    from_time: datetime
    to_time: datetime


@dataclass
class Quotations:
    """
    Quotierungen für eine TimeSeries.

    Attributes:
        time_series_id: ID der TimeSeries
        values: Liste der Quotierungs-Werte
    """

    time_series_id: int
    values: list[QuotationValue] = field(default_factory=list)


@dataclass
class QuotationsPayload:
    """
    Payload für Quotierungen.

    Attributes:
        items: Liste der Quotierungen
    """

    items: list[Quotations] = field(default_factory=list)


@dataclass
class File:
    """
    File-Metadaten.

    Attributes:
        id: File ID
        created_by: Ersteller
        created_at: Erstellungszeitpunkt
        name: Dateiname
        media_type: Media-Type
        charset: Zeichensatz
        size: Dateigröße in Bytes
        hash_algorithm: Hash-Algorithmus
        hash_base64: Hash in Base64
        inventory_property_id: ID der Inventory Property
        inventory_item_id: ID des Inventory Items
        deleted_at: Löschzeitpunkt
        storage_delete_attempts: Anzahl Löschversuche
        audit_enabled: Audit aktiviert
    """

    id: int
    created_by: str
    created_at: datetime
    name: str | None
    media_type: str | None
    charset: str | None
    size: int
    hash_algorithm: str | None
    hash_base64: str | None
    inventory_property_id: int
    inventory_item_id: int | None
    deleted_at: datetime | None
    storage_delete_attempts: int
    audit_enabled: bool


@dataclass
class ErrorPayload:
    """
    Fehler-Payload.

    Attributes:
        message: Fehlermeldung
        extensions: Zusätzliche Fehlerinformationen
    """

    message: str | None = None
    extensions: dict | None = None


@dataclass
class ProblemDetails:
    """
    RFC 7807 Problem Details.

    Attributes:
        type: URI-Referenz zum Problemtyp
        title: Kurze, lesbare Beschreibung
        status: HTTP-Statuscode
        detail: Detaillierte Fehlerbeschreibung
        instance: URI-Referenz zur spezifischen Probleminstanz
    """

    type: str | None = None
    title: str | None = None
    status: int | None = None
    detail: str | None = None
    instance: str | None = None
