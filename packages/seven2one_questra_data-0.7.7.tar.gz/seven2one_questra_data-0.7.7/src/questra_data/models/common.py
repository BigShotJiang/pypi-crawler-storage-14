"""Gemeinsame Type Models für Questra Data."""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum


class SortOrder(str, Enum):
    """
    Sortierreihenfolge.

    Attributes:
        ASC: Aufsteigend (A-Z, 0-9)
        DESC: Absteigend (Z-A, 9-0)
    """

    ASC = "ASC"
    DESC = "DESC"


class ConflictAction(str, Enum):
    """
    Aktion bei Konflikten beim Erstellen von Objekten.

    Attributes:
        RAISE_ERROR: Fehler werfen wenn Objekt bereits existiert
        IGNORE: Bestehende Objekte ignorieren (keine Änderung)
    """

    RAISE_ERROR = "RAISE_ERROR"
    IGNORE = "IGNORE"


@dataclass
class PageInfo:
    """
    Pagination-Informationen für Verbindungen.

    Attributes:
        has_next_page: Gibt es weitere Elemente nach dem aktuellen Set
        has_previous_page: Gibt es weitere Elemente vor dem aktuellen Set
        start_cursor: Cursor für Rückwärts-Pagination
        end_cursor: Cursor für Vorwärts-Pagination
    """

    has_next_page: bool
    has_previous_page: bool
    start_cursor: str | None = None
    end_cursor: str | None = None

    @staticmethod
    def from_dict(data: dict) -> PageInfo:
        """Erstellt PageInfo aus GraphQL Response."""
        return PageInfo(
            has_next_page=data["hasNextPage"],
            has_previous_page=data["hasPreviousPage"],
            start_cursor=data.get("startCursor"),
            end_cursor=data.get("endCursor"),
        )


@dataclass
class NamedItemResult:
    """
    Ergebnis von Mutations die ein benanntes Item erstellen/löschen.

    Entspricht _NamedItem__PayloadType aus dem GraphQL Schema.

    Attributes:
        name: Name des Items
        existed: True wenn Item bereits existierte, False wenn neu
    """

    name: str
    existed: bool

    @staticmethod
    def from_dict(data: dict) -> NamedItemResult:
        """Erstellt NamedItemResult aus GraphQL Response."""
        return NamedItemResult(
            name=data["name"],
            existed=data["existed"],
        )


@dataclass
class BackgroundJobResult:
    """
    Ergebnis von Mutations die einen Background-Job starten.

    Entspricht _BackgroundJobId__PayloadType aus dem GraphQL Schema.

    Attributes:
        background_job_id: ID des Background-Jobs
    """

    background_job_id: str

    @staticmethod
    def from_dict(data: dict) -> BackgroundJobResult:
        """Erstellt BackgroundJobResult aus GraphQL Response."""
        return BackgroundJobResult(
            background_job_id=data["backgroundJobId"],
        )


@dataclass
class TimeSeriesIdResult:
    """
    Ergebnis der TimeSeries-Erstellung.

    Entspricht _Id__PayloadType aus dem GraphQL Schema.

    Attributes:
        id: ID der erstellten TimeSeries
    """

    id: str  # LongNumberString

    @staticmethod
    def from_dict(data: dict) -> TimeSeriesIdResult:
        """Erstellt TimeSeriesIdResult aus GraphQL Response."""
        return TimeSeriesIdResult(
            id=data["_id"],
        )
