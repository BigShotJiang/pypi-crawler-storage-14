"""Permission-bezogene Type Models für Questra Data.

Diese Enums definieren die verfügbaren Berechtigungen und Permission-States
basierend auf dem GraphQL Schema.
"""

from enum import Enum


class InventoryPrivilege(str, Enum):
    """
    Inventory-Berechtigungen.

    Entspricht _InventoryPrivilege__EnumType aus dem GraphQL Schema.

    Attributes:
        SELECT: Berechtigung zum Lesen von Inventory-Daten
        INSERT: Berechtigung zum Einfügen von Items
        UPDATE: Berechtigung zum Aktualisieren von Items
        DELETE: Berechtigung zum Löschen von Items
        AUDIT: Berechtigung zum Zugriff auf Audit-Daten
    """

    SELECT = "SELECT"
    INSERT = "INSERT"
    UPDATE = "UPDATE"
    DELETE = "DELETE"
    AUDIT = "AUDIT"


class InventoryPropertyPrivilege(str, Enum):
    """
    Property-spezifische Berechtigungen.

    Entspricht _InventoryPropertyPrivilege__EnumType aus dem GraphQL Schema.

    Attributes:
        SELECT: Berechtigung zum Lesen der Property
        INSERT: Berechtigung zum Setzen der Property bei INSERT
        UPDATE: Berechtigung zum Ändern der Property bei UPDATE
    """

    SELECT = "SELECT"
    INSERT = "INSERT"
    UPDATE = "UPDATE"


class PermissionState(str, Enum):
    """
    Status einer Permission.

    Entspricht _PermissionState__EnumType aus dem GraphQL Schema.

    Attributes:
        DENY: Berechtigung explizit verweigert
        REVOKE: Berechtigung widerrufen (neutral)
        GRANT: Berechtigung gewährt
    """

    DENY = "DENY"
    REVOKE = "REVOKE"
    GRANT = "GRANT"
