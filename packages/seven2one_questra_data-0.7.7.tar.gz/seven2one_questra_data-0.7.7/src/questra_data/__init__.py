"""
Questra Data - Python Client für Dyno GraphQL API.

Bietet zwei APIs:
1. High-Level API (QuestraData) - Empfohlen für die meisten Anwendungsfälle
2. Low-Level API (QuestraDataCore) - Für fortgeschrittene Operationen

Die High-Level API abstrahiert die Komplexität von GraphQL und REST und bietet
eine benutzerfreundliche Schnittstelle.

Beispiel (High-Level API - empfohlen):
    from questra_authentication import QuestraAuthentication
    from questra_data import QuestraData
    from datetime import datetime

    # QuestraAuthentication erstellen
    auth_client = QuestraAuthentication(
        url="https://authentik.dev.example.com",
        username="ServiceUser",
        password="secret_password"
    )

    # Client initialisieren
    client = QuestraData(
        graphql_url="https://dev.example.com/graphql",
        auth_client=auth_client
    )

    # Zeitreihen-Werte laden (ein einziger Aufruf!)
    result = client.list_timeseries_values(
        inventory_name="Stromzaehler",
        namespace="Energie",
        timeseries_property="messwerte_Energie",
        from_time=datetime(2024, 1, 1),
        to_time=datetime(2024, 1, 31)
    )

    # Inventory Items laden
    items = client.list(
        inventory_name="TestUser",
        namespace="TestNamespace"
    )

Beispiel (Low-Level API):
    from questra_authentication import QuestraAuthentication
    from questra_data import QuestraDataCore

    # QuestraAuthentication für Authentifizierung erstellen
    auth_client = QuestraAuthentication(
        url="https://authentik.dev.example.com",
        username="ServiceUser",
        password="secret_password",
        oidc_discovery_paths=['/application/o/dyno']
    )

    # QuestraDataCore initialisieren
    client = QuestraDataCore(
        graphql_url="https://dyno.dev.example.com/graphql",
        auth_client=auth_client
    )

    # Inventories abfragen
    inventories = client.queries.get_inventories()

    # Namespace erstellen
    result = client.mutations.create_namespace(
        namespace_name="MyNamespace",
        description="Test Namespace"
    )
"""

import os
import sys

from loguru import logger

# Entferne Standard-Handler
logger.remove()

# Konfiguriere Logger basierend auf Umgebungsvariablen
LOG_LEVEL = os.getenv("questra_data_LOG_LEVEL", "WARNING")
LOG_FORMAT = os.getenv(
    "questra_data_LOG_FORMAT",
    "<green>{time:YYYY-MM-DD HH:mm:ss.SSS}</green> | "
    "<level>{level: <8}</level> | "
    "<cyan>{name}</cyan>:<cyan>{function}</cyan>:<cyan>{line}</cyan> | "
    "<level>{message}</level> | "
    "{extra}{exception}",
)

# Standard-Handler für stderr (WARNING+)
logger.add(
    sys.stdout,
    format=LOG_FORMAT,
    level=LOG_LEVEL,
    colorize=True,
    backtrace=True,
    diagnose=True,
)

# Optional: File-Handler wenn LOG_FILE gesetzt ist
LOG_FILE = os.getenv("questra_data_LOG_FILE")
if LOG_FILE:
    logger.add(
        LOG_FILE,
        format=LOG_FORMAT,
        level="DEBUG",
        rotation="10 MB",
        retention="7 days",
        compression="zip",
        enqueue=True,  # Thread-safe
    )

logger.debug("Questra Data logger initialized")

from .client import QuestraDataCore
from .exceptions import QuestraError, QuestraGraphQLError
from .highlevel_client import QuestraData
from .models import (
    Aggregation,  # TimeSeries-Modelle (gemeinsam genutzt)
    ConflictAction,
    CreateTimeSeriesInput,
    DataType,
    FileConfig,
    FilePropertyConfig,
    Interval,
    IntervalConfig,
    IntervalInfo,
    Inventory,
    InventoryPrivilege,
    InventoryProperty,
    InventoryPropertyPrivilege,
    InventoryRelation,
    InventoryType,
    Namespace,
    PageInfo,
    PermissionState,
    Quality,
    QuotationBehavior,
    RelationType,
    Role,
    SortOrder,
    StringConfig,
    StringPropertyConfig,
    TimeSeriesConfig,
    TimeSeriesPropertyConfig,
    TimeSeriesValue,
    TimeUnit,
    TimeZone,
    Unit,
    ValueAlignment,
    ValueAvailability,
)
from .models.inputs import (
    BoolProperty,
    DateProperty,
    DateTimeOffsetProperty,
    DateTimeProperty,
    DecimalProperty,
    FileProperty,
    GuidProperty,
    IntProperty,
    LongProperty,
    StringProperty,
    TimeProperty,
    TimeSeriesProperty,
)
from .models.rest import (
    ErrorPayload,
    File,
    ProblemDetails,
    Quotations,
    QuotationsPayload,
    QuotationValue,
    SetTimeSeriesDataInput,
    TimeSeriesData,
    TimeSeriesDataPayload,
    TimeSeriesPayload,
)
from .results import QueryResult, TimeSeriesResult

__version__ = "0.1.0"

__all__ = [
    # Hauptklassen
    "QuestraData",  # High-Level API (empfohlen für die meisten Anwendungsfälle)
    "QuestraDataCore",  # Low-Level API
    "QueryResult",  # Wrapper für Query-Ergebnisse mit .to_df() Support
    "TimeSeriesResult",  # Wrapper für TimeSeries-Ergebnisse mit .to_df() Support
    # Exceptions
    "QuestraError",  # Basis-Exception
    "QuestraGraphQLError",  # GraphQL-Fehler vom Server
    # GraphQL Models
    "Inventory",
    "InventoryType",
    "InventoryProperty",
    "InventoryRelation",
    "Namespace",
    "Role",
    "Unit",
    "TimeZone",
    "PageInfo",
    # GraphQL Enums
    "SortOrder",
    "ConflictAction",
    "RelationType",
    "DataType",
    # Input Models (für create_inventory)
    "StringPropertyConfig",
    "FilePropertyConfig",
    "TimeSeriesPropertyConfig",
    "IntervalConfig",
    "CreateTimeSeriesInput",
    # Spezialisierte Property-Klassen (vereinfachte API)
    "StringProperty",
    "IntProperty",
    "LongProperty",
    "DecimalProperty",
    "BoolProperty",
    "DateTimeProperty",
    "DateTimeOffsetProperty",
    "DateProperty",
    "TimeProperty",
    "GuidProperty",
    "FileProperty",
    "TimeSeriesProperty",
    # Output Config Models (aus Query Responses)
    "StringConfig",
    "FileConfig",
    "TimeSeriesConfig",
    "IntervalInfo",
    # Permissions
    "InventoryPrivilege",
    "InventoryPropertyPrivilege",
    "PermissionState",
    # TimeSeries Models (gemeinsam genutzt von GraphQL und REST)
    "TimeUnit",
    "Aggregation",
    "Quality",
    "QuotationBehavior",
    "ValueAlignment",
    "ValueAvailability",
    "Interval",
    "TimeSeriesValue",
    # REST-spezifische Models
    "TimeSeriesData",
    "TimeSeriesDataPayload",
    "SetTimeSeriesDataInput",
    "TimeSeriesPayload",
    "QuotationValue",
    "Quotations",
    "QuotationsPayload",
    "File",
    "ErrorPayload",
    "ProblemDetails",
]
