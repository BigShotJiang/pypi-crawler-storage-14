# Dateiverwaltung

Siehe [REST File Operations](../api/rest-operations.md#file-operationen) für vollständige Dokumentation der Datei-Operationen.

## Siehe auch

- [REST Operationen](../api/rest-operations.md)
- [FilePropertyConfig](../api/models-inventory.md)
