# Error Handling

Fehlerbehandlung in Questra Data.

## Exception Typen

Questra Data kann folgende Exceptions werfen:

### HTTP Errors

```python
from requests.exceptions import HTTPError

try:
    items = client.list("InvalidInventory", "InvalidNamespace")
except HTTPError as e:
    print(f"HTTP {e.response.status_code}: {e.response.text}")
```

Häufige HTTP-Fehler:

- `401 Unauthorized` - Authentifizierung fehlgeschlagen
- `403 Forbidden` - Keine Berechtigung
- `404 Not Found` - Inventory oder Namespace nicht gefunden
- `500 Internal Server Error` - Server-Fehler

### GraphQL Errors

```python
from gql.transport.exceptions import TransportQueryError

try:
    result = client.lowlevel.execute_raw("""
        query { invalidQuery }
    """)
except TransportQueryError as e:
    print(f"GraphQL Fehler: {e}")
```

### ValueError

```python
try:
    # Ungültige Parameter
    client.list(inventory_name="", namespace_name="")
except ValueError as e:
    print(f"Validierungs-Fehler: {e}")
```

## Error Handling Patterns

### Try-Except

```python
try:
    items = client.list("Stromzaehler", "Energie")
except HTTPError as e:
    if e.response.status_code == 404:
        print("Inventory nicht gefunden")
    else:
        raise
except TransportQueryError as e:
    print(f"GraphQL Fehler: {e}")
```

### Logging

```python
from loguru import logger

try:
    items = client.list("Stromzaehler", "Energie")
except Exception as e:
    logger.error(f"Fehler beim Laden: {e}")
    raise
```

## Siehe auch

- [QuestraData](../api/highlevel-client.md)
- [Best Practices](best-practices.md)
