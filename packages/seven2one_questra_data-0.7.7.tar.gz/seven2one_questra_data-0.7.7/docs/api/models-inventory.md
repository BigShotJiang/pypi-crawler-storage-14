# Inventory Models

Dataclasses für Inventory.

::: questra_data.models.common.SortOrder
    options:
      show_source: false
      heading_level: 2

::: questra_data.models.common.ConflictAction
    options:
      show_source: false
      heading_level: 2

::: questra_data.models.common.PageInfo
    options:
      show_source: false
      heading_level: 2
      show_docstring_attributes: true

::: questra_data.models.common.NamedItemResult
    options:
      show_source: false
      heading_level: 2
      show_docstring_attributes: true

::: questra_data.models.common.BackgroundJobResult
    options:
      show_source: false
      heading_level: 2
      show_docstring_attributes: true

::: questra_data.models.common.TimeSeriesIdResult
    options:
      show_source: false
      heading_level: 2
      show_docstring_attributes: true

::: questra_data.models.inputs.StringPropertyConfig
    options:
      show_source: false
      heading_level: 2
      show_docstring_attributes: true

::: questra_data.models.inputs.FilePropertyConfig
    options:
      show_source: false
      heading_level: 2
      show_docstring_attributes: true

::: questra_data.models.inputs.IntervalConfig
    options:
      show_source: false
      heading_level: 2
      show_docstring_attributes: true

::: questra_data.models.inputs.TimeSeriesPropertyConfig
    options:
      show_source: false
      heading_level: 2
      show_docstring_attributes: true

::: questra_data.models.inputs.InventoryProperty
    options:
      show_source: false
      heading_level: 2
      show_docstring_attributes: true

::: questra_data.models.inputs.TimeSeriesSpecifics
    options:
      show_source: false
      heading_level: 2
      show_docstring_attributes: true

::: questra_data.models.inputs.CreateTimeSeriesInput
    options:
      show_source: false
      heading_level: 2
      show_docstring_attributes: true

::: questra_data.models.inputs.InventoryRelation
    options:
      show_source: false
      heading_level: 2
      show_docstring_attributes: true

::: questra_data.models.inputs.BaseProperty
    options:
      show_source: false
      heading_level: 2
      show_docstring_attributes: true

::: questra_data.models.inputs.StringProperty
    options:
      show_source: false
      heading_level: 2
      show_docstring_attributes: true

::: questra_data.models.inputs.IntProperty
    options:
      show_source: false
      heading_level: 2
      show_docstring_attributes: true

::: questra_data.models.inputs.DecimalProperty
    options:
      show_source: false
      heading_level: 2
      show_docstring_attributes: true

::: questra_data.models.inputs.LongProperty
    options:
      show_source: false
      heading_level: 2
      show_docstring_attributes: true

::: questra_data.models.inputs.BoolProperty
    options:
      show_source: false
      heading_level: 2
      show_docstring_attributes: true

::: questra_data.models.inputs.DateTimeProperty
    options:
      show_source: false
      heading_level: 2
      show_docstring_attributes: true

::: questra_data.models.inputs.DateTimeOffsetProperty
    options:
      show_source: false
      heading_level: 2
      show_docstring_attributes: true

::: questra_data.models.inputs.DateProperty
    options:
      show_source: false
      heading_level: 2
      show_docstring_attributes: true

::: questra_data.models.inputs.TimeProperty
    options:
      show_source: false
      heading_level: 2
      show_docstring_attributes: true

::: questra_data.models.inputs.GuidProperty
    options:
      show_source: false
      heading_level: 2
      show_docstring_attributes: true

::: questra_data.models.inputs.FileProperty
    options:
      show_source: false
      heading_level: 2
      show_docstring_attributes: true

::: questra_data.models.inputs.TimeSeriesProperty
    options:
      show_source: false
      heading_level: 2
      show_docstring_attributes: true

::: questra_data.models.inventory.InventoryType
    options:
      show_source: false
      heading_level: 2

::: questra_data.models.inventory.RelationType
    options:
      show_source: false
      heading_level: 2

::: questra_data.models.inventory.DataType
    options:
      show_source: false
      heading_level: 2

::: questra_data.models.inventory.StringConfig
    options:
      show_source: false
      heading_level: 2
      show_docstring_attributes: true

::: questra_data.models.inventory.FileConfig
    options:
      show_source: false
      heading_level: 2
      show_docstring_attributes: true

::: questra_data.models.inventory.IntervalInfo
    options:
      show_source: false
      heading_level: 2
      show_docstring_attributes: true

::: questra_data.models.inventory.TimeSeriesConfig
    options:
      show_source: false
      heading_level: 2
      show_docstring_attributes: true

::: questra_data.models.inventory.InventoryProperty
    options:
      show_source: false
      heading_level: 2
      show_docstring_attributes: true

::: questra_data.models.inventory.InventoryRelation
    options:
      show_source: false
      heading_level: 2
      show_docstring_attributes: true

::: questra_data.models.inventory.Inventory
    options:
      show_source: false
      heading_level: 2
      show_docstring_attributes: true

::: questra_data.models.namespace.Namespace
    options:
      show_source: false
      heading_level: 2
      show_docstring_attributes: true
