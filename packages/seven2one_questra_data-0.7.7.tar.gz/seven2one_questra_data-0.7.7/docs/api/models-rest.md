# Rest Models

Dataclasses für Rest.

::: questra_data.models.rest.TimeSeriesData
    options:
      show_source: false
      heading_level: 2
      show_docstring_attributes: true

::: questra_data.models.rest.TimeSeriesDataPayload
    options:
      show_source: false
      heading_level: 2
      show_docstring_attributes: true

::: questra_data.models.rest.SetTimeSeriesDataInput
    options:
      show_source: false
      heading_level: 2
      show_docstring_attributes: true

::: questra_data.models.rest.TimeSeriesPayload
    options:
      show_source: false
      heading_level: 2
      show_docstring_attributes: true

::: questra_data.models.rest.QuotationValue
    options:
      show_source: false
      heading_level: 2
      show_docstring_attributes: true

::: questra_data.models.rest.Quotations
    options:
      show_source: false
      heading_level: 2
      show_docstring_attributes: true

::: questra_data.models.rest.QuotationsPayload
    options:
      show_source: false
      heading_level: 2
      show_docstring_attributes: true

::: questra_data.models.rest.File
    options:
      show_source: false
      heading_level: 2
      show_docstring_attributes: true

::: questra_data.models.rest.ErrorPayload
    options:
      show_source: false
      heading_level: 2
      show_docstring_attributes: true

::: questra_data.models.rest.ProblemDetails
    options:
      show_source: false
      heading_level: 2
      show_docstring_attributes: true
