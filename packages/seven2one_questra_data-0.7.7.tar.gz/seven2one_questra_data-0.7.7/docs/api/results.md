# Results

::: questra_data.results.QueryResult
    options:
      show_source: false
      heading_level: 2

::: questra_data.results.TimeSeriesResult
    options:
      show_source: false
      heading_level: 2
