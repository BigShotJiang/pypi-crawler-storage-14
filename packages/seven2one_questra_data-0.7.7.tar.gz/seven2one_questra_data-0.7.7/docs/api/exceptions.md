# Exceptions

::: questra_data.exceptions.QuestraError
    options:
      show_source: false
      heading_level: 2

::: questra_data.exceptions.QuestraGraphQLError
    options:
      show_source: false
      heading_level: 2
