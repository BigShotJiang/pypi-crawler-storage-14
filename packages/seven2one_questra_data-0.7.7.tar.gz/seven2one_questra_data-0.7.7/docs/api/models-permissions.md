# Permissions Models

Dataclasses für Permissions.

::: questra_data.models.permissions.InventoryPrivilege
    options:
      show_source: false
      heading_level: 2

::: questra_data.models.permissions.InventoryPropertyPrivilege
    options:
      show_source: false
      heading_level: 2

::: questra_data.models.permissions.PermissionState
    options:
      show_source: false
      heading_level: 2

::: questra_data.models.role.Role
    options:
      show_source: false
      heading_level: 2
      show_docstring_attributes: true
