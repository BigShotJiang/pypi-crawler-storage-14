# Timeseries Models

Dataclasses für Timeseries.

::: questra_data.models.timeseries.TimeUnit
    options:
      show_source: false
      heading_level: 2

::: questra_data.models.timeseries.Aggregation
    options:
      show_source: false
      heading_level: 2

::: questra_data.models.timeseries.Quality
    options:
      show_source: false
      heading_level: 2

::: questra_data.models.timeseries.QuotationBehavior
    options:
      show_source: false
      heading_level: 2

::: questra_data.models.timeseries.ValueAlignment
    options:
      show_source: false
      heading_level: 2

::: questra_data.models.timeseries.ValueAvailability
    options:
      show_source: false
      heading_level: 2

::: questra_data.models.timeseries.Interval
    options:
      show_source: false
      heading_level: 2
      show_docstring_attributes: true

::: questra_data.models.timeseries.TimeSeriesValue
    options:
      show_source: false
      heading_level: 2
      show_docstring_attributes: true
