# Installation

## Voraussetzungen

- Python >= 3.10
- pip (oder Ihr bevorzugter Paketmanager)

## Basis-Installation

```bash
pip install seven2one-questra-data
```

## Mit pandas-Unterstützung

Für Data Science Anwendungen und DataFrame-Unterstützung:

```bash
pip install seven2one-questra-data[pandas]
```

!!! tip "pandas empfohlen"
    Die pandas-Integration bietet DataFrames für Zeitreihen- und Inventory-Daten und ermöglicht nahtlose Datenanalyse. Empfohlen für die meisten Anwendungsfälle.

## Verifizierung

Nach der Installation können Sie überprüfen, ob alles korrekt funktioniert:

```python
from questra_data import QuestraData

print("✓ seven2one-questra-data erfolgreich installiert")

# pandas verfügbar?
try:
    import pandas as pd
    print("✓ pandas verfügbar - DataFrame-Methoden können verwendet werden")
except ImportError:
    print("✗ pandas nicht verfügbar")
    print("  Installation: pip install seven2one-questra-data[pandas]")
```

## Troubleshooting

### pandas wird nicht erkannt

Stelle sicher, dass pandas installiert ist:

```bash
pip show pandas
```

Falls nicht installiert:

```bash
pip install pandas>=2.0.0
```

## Abhängigkeiten

### Erforderlich

- Python >= 3.10
- gql >= 3.5.0
- requests >= 2.31.0
- loguru >= 0.7.0
- seven2one-questra-authentication >= 0.2.1
- requests-toolbelt >= 1.0.0

### Optional

- pandas >= 2.0.0 (für DataFrame-Unterstützung)

## Nächste Schritte

Nach erfolgreicher Installation:

- [Quickstart](quickstart.md) - Erste Schritte mit seven2one-questra-data
- [API-Übersicht](api-overview.md) - High-Level vs Low-Level API
