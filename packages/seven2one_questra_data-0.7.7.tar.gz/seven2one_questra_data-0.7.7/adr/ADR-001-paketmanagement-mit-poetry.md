# ADR-001: Paketmanagement mit poetry

**Status:** Akzeptiert
**Datum:** 2025-10-08
**Kontext:** PoC questra-data Python Package

## Kontext und Problemstellung

Für das questra-data Package muss ein Paketmanager gewählt werden. Die Standardoptionen sind `pip` mit `requirements.txt`, `setuptools` oder moderne Tools wie `poetry` oder `pipenv`.

Bei größeren Projekten mit mehreren Dependencies und komplexeren Abhängigkeitsbäumen wird das Dependency Management schnell unübersichtlich und fehleranfällig.

## Entscheidung

Wir verwenden **poetry** als Paketmanager für questra-data.

## Begründung

### Pro

- **Dependency Resolution:** Poetry löst Abhängigkeiten deterministisch auf und verhindert Versionskonflikte durch `poetry.lock`
- **Quasi-Standard:** Poetry hat sich in der Python-Community als moderner Standard etabliert
- **Build-System-Integration:** Vollständige Integration von Build (pyproject.toml PEP 517/518), Packaging und Publishing
- **Virtual Environment Management:** Automatische Verwaltung von Virtual Environments
- **Entwickler-Workflow:** Einheitliche Commands (`poetry add`, `poetry install`, `poetry publish`)
- **Bessere Skalierung:** Bei größeren Projekten mit vielen Dependencies deutlich übersichtlicher und wartbarer als pip
- **Separation von Direct und Transitive Dependencies:** Klare Trennung zwischen direkten Abhängigkeiten (pyproject.toml) und aufgelösten transitiven Dependencies (poetry.lock)

### Contra

- **Zusätzliches Tool:** Entwickler müssen poetry installiert haben (nicht Teil der Python-Standardinstallation)
- **Learning Curve:** Neue Commands und Konzepte für Entwickler, die nur pip kennen
- **Locked Ecosystem:** Stärkere Bindung an poetry als Tool (Migration zu anderem Tool erfordert Aufwand)
- **Performance:** Poetry kann bei großen Dependency-Trees langsamer sein als pip
- **Kompatibilität:** In manchen CI/CD-Umgebungen oder Legacy-Systemen nicht ohne weiteres verfügbar

## Alternativen

### pip + requirements.txt

- **Pro:** Standardtool, keine zusätzliche Installation
- **Contra:** Keine Dependency Resolution, manuelle Lock-Files, keine Build-Integration

### pipenv

- **Pro:** Ähnliche Features wie poetry
- **Contra:** Weniger aktive Entwicklung, langsamere Performance, kleinere Community

### PDM / Hatch

- **Pro:** Moderner, PEP-konform
- **Contra:** Noch weniger etabliert als poetry, kleinere Community

## Konsequenzen

### Positiv

- Deterministisches Dependency Management durch poetry.lock
- Vereinfachter Entwickler-Workflow
- Bessere Wartbarkeit bei steigender Komplexität
- Professionelleres Package-Publishing

### Negativ

- Alle Entwickler müssen poetry installieren
- CI/CD-Pipelines müssen poetry unterstützen
- Einarbeitungszeit für neue Entwickler

## Notizen

poetry ist für moderne Python-Projekte die empfohlene Wahl und entspricht den Best Practices der Python-Community (Stand 2025).
