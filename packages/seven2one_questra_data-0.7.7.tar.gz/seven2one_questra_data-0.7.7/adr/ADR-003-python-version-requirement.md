# ADR-003: Python Version Requirement

**Status:** Akzeptiert
**Datum:** 2025-10-10
**Kontext:** PoC questra-data Python Package

## Kontext und Problemstellung

Das questra-data Package muss eine Mindest-Python-Version festlegen. Dies beeinflusst:

- Verfügbare Sprachfeatures (Type Hints, Pattern Matching, etc.)
- Supportbarkeit auf verschiedenen Plattformen
- Lifecycle und Wartungsaufwand

Python-Versionen haben einen definierten Support-Lifecycle (ca. 5 Jahre pro Major.Minor-Version).

## Entscheidung

Wir unterstützen **Python 3.10 bis 3.14** als offiziell unterstützte Versionen.

Die Mindestversion ist **Python 3.10**.

## Begründung

### Pro

- **Aktiver Support:** Python 3.10 bis 3.14 sind alle im offiziellen Support (Stand 2025)
  - Python 3.10: Oktober 2021 - Oktober 2026
  - Python 3.11: Oktober 2022 - Oktober 2027
  - Python 3.12: Oktober 2023 - Oktober 2028
  - Python 3.13: Oktober 2024 - Oktober 2029
  - Python 3.14: Oktober 2025 - Oktober 2030
- **Moderne Type Hints:** Python 3.10+ unterstützt native Union-Types (`X | None` statt `Optional[X]`)
- **Bessere Generics:** `list[X]`, `dict[K, V]` statt `List[X]`, `Dict[K, V]`
- **Pattern Matching (3.10+):** Strukturelles Pattern Matching für komplexe Logik verfügbar
- **Performance:** Python 3.11+ bietet signifikante Performance-Verbesserungen (~25%)
- **Weite Verbreitung:** Python 3.10+ ist auf den meisten modernen Systemen verfügbar
- **CI/CD-Support:** Alle CI-Systeme unterstützen Python 3.10+

### Contra

- **Keine Legacy-Systeme:** Python 3.8 und 3.9 werden ausgeschlossen (beide End-of-Life 2024/2025)
- **Upgrade-Zwang:** User mit Python 3.9 oder älter müssen upgraden
- **Eingeschränkte Features:** Python 3.12+ Features (z.B. per-interpreter GIL) sind nicht verfügbar, wenn wir 3.10 unterstützen wollen

## Alternativen

### Python 3.8+

- **Pro:** Größere Nutzerbase, mehr Legacy-Systeme
- **Contra:** Python 3.8 End-of-Life Oktober 2024, keine modernen Type Hints

### Python 3.11+

- **Pro:** Bessere Performance, modernere Features
- **Contra:** Schließt Python 3.10 aus, die noch im Support ist

### Python 3.12+

- **Pro:** Neueste Features, beste Performance
- **Contra:** Zu restriktiv, schließt viele User aus

## Konsequenzen

### Positiv

- Nutzung moderner Python-Features (Union-Types, Pattern Matching)
- Abdeckung aller aktiv unterstützten Python-Versionen
- Zukunftssicher für die nächsten 5+ Jahre
- Keine Legacy-Altlasten (Python 3.8/3.9)

### Negativ

- User mit Python 3.9 oder älter müssen upgraden
- Keine Nutzung von Python 3.12+ exklusiven Features (wenn wir 3.10 kompatibel bleiben wollen)

## Implementation

```toml
# pyproject.toml
[tool.poetry.dependencies]
python = "^3.10"
```

```python
# Code kann nutzen:
from typing import TypeAlias

# Native Union Types (3.10+)
def get_item(item_id: int | None = None) -> dict | None:
    ...

# Native Generics (3.10+)
items: list[dict] = []
mapping: dict[str, int] = {}

# Pattern Matching (3.10+)
match response.status_code:
    case 200:
        return response.json()
    case 404:
        return None
    case _:
        raise Exception()
```

## Testing

CI/CD-Pipeline sollte Tests auf allen unterstützten Versionen ausführen:

```yaml
python-version: ["3.10", "3.11", "3.12", "3.13", "3.14"]
```

## Notizen

Diese Entscheidung folgt der offiziellen Python-Support-Policy und stellt sicher, dass nur aktiv unterstützte Versionen verwendet werden. Python 3.10 wurde als Mindestversion gewählt, weil hier die wichtigsten modernen Syntax-Features (Union-Types, native Generics) verfügbar sind.

Stand 2025 ist Python 3.9 End-of-Life (Oktober 2025), weshalb es nicht mehr sinnvoll ist, diese Version zu unterstützen.
