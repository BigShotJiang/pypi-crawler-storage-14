def main() -> None:
    print("Hello from natstat-cli!")
