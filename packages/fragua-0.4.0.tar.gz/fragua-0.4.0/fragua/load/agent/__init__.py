"""
Loader Agent Module.

This module contains:
-Loader agent class.

"""

from .loader import Loader

__all__ = ["Loader"]
