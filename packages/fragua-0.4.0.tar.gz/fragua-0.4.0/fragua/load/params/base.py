"""Load Params Class."""

from pandas import DataFrame

from fragua.core.params import Params


class LoadParams(Params):
    """Common parameters for loading agents."""

    data: DataFrame
    destination: str | None

    purpose: str | None = "Base load parameters shared by all data loading styles."

    FIELD_DESCRIPTIONS = {
        "data": "Pandas DataFrame containing the data to be loaded.",
        "destination": "Optional destination identifier (e.g., file path, database name, endpoint)",
    }

    def __init__(
        self, style: str, data: DataFrame, destination: str | None = None
    ) -> None:
        super().__init__(action="load", style=style)
        self.data = data
        self.destination = destination
