

class CallbackExecutionError(Exception):
    """
    exception that will be thrown if there was an execution error in a field-callback
    """
