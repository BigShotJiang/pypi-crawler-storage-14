from balderhub.crud.lib.scenario_features.single_data_filler_feature import SingleDataFillerFeature


class SingleDataUpdaterFeature(SingleDataFillerFeature):
    """
    Scenario Feature that updating a new data item in the system-under-test.
    """
