class ScravelyException(Exception):
    """Base exception for Scrapely"""
    pass


class ConnectionError(ScravelyException):
    """Connection related errors"""
    pass


class OperationError(ScravelyException):
    """Operation execution errors"""
    pass
