"""
Setup configuration for scrapely-client package
"""

from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="scrapely-client",
    version="0.1.0",
    author="Yahya Rehman",
    author_email="yahyarehman57@gmail.com",
    description="Python client for Scrapely browser automation service",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/YahyaRehman6/scrapely_client",
    packages=find_packages(),
    classifiers=[
        "Development Status :: 3 - Alpha",
        "Intended Audience :: Developers",
        "Topic :: Software Development :: Testing",
        "Topic :: Internet :: WWW/HTTP :: Browsers",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
    ],
    python_requires=">=3.8",
    install_requires=[
        "websocket-client>=1.0.0",
    ],
    extras_require={
        "dev": [],
    },
    project_urls={
        "Bug Reports": "https://github.com/YahyaRehman6/scrapely_client/issues",
        "Source": "https://github.com/YahyaRehman6/scrapely_client",
    },
)