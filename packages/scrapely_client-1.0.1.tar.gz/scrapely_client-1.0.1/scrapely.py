"""
Scrapely Client - Python client for Scrapely browser automation service
"""

import json
import uuid
from typing import Optional, List, Dict, Any, Union
from websocket import create_connection, WebSocket
from exceptions import ConnectionError, OperationError

class Element:
    """
    Represents a cached browser element with chainable methods.
    
    Usage:
        element = browser.get_element("#button")
        element.click()
        text = element.text()
        href = element.get_attribute("href")
    """
    
    def __init__(self, element_id: str, selector: str, browser: 'Scrapely'):
        """
        Initialize Element.
        
        Args:
            element_id: Cached element ID from the service
            selector: CSS selector used to find the element
            browser: Reference to the Scrapely browser instance
        """
        self.id = element_id
        self.selector = selector
        self._browser = browser
    
    def click(self, timeout: Optional[int] = None) -> bool:
        """
        Click this element.
        
        Args:
            timeout: Optional timeout in seconds
            
        Returns:
            True if click successful
        """
        return self._browser.click(element_id=self.id, timeout=timeout)
    
    def type(self, text: str, timeout: Optional[int] = None, clear: bool = False) -> bool:
        """
        Type text into this element (for input fields).
        
        Args:
            text: Text to input
            timeout: Optional timeout in seconds
            clear: Whether to clear existing text first
            
        Returns:
            True if type successful
        """
        return self._browser.type(text, element_id=self.id, timeout=timeout, clear=clear)
    
    def get_text(self, timeout: Optional[int] = None) -> str:
        """
        Get text content of this element.
        
        Args:
            timeout: Optional timeout in seconds
            
        Returns:
            Element text content
        """
        return self._browser.get_text(element_id=self.id, timeout=timeout)
    
    def get_attr(self, attribute: str, timeout: Optional[int] = None) -> Optional[str]:
        """
        Get attribute value from this element.
        
        Args:
            attribute: Attribute name (e.g., "href", "class", "data-id")
            timeout: Optional timeout in seconds
            
        Returns:
            Attribute value or None
        """
        return self._browser.get_attr(attribute, element_id=self.id, timeout=timeout)
    
    def scroll_to(self, timeout: Optional[int] = None) -> bool:
        """
        Scroll to this element.
        
        Args:
            timeout: Optional timeout in seconds
            
        Returns:
            True if scroll successful
        """
        return self._browser.scroll_to(element_id=self.id, timeout=timeout)
    
    def run_js(self, script: str, timeout: Optional[int] = None) -> Any:
        """
        Execute JavaScript on this element.
        
        Args:
            script: JavaScript code (element available as 'this' context)
            timeout: Optional timeout in seconds
            
        Returns:
            Script execution result
        """
        return self._browser.run_js_on_element(script, element_id=self.id, timeout=timeout)
    
    def exists(self, timeout: Optional[int] = None) -> bool:
        """
        Check if this element still exists.
        
        Args:
            timeout: Optional timeout in seconds
            
        Returns:
            True if element exists
        """
        return self._browser.exists(element_id=self.id, timeout=timeout)
    
    def find(self, selector: str, timeout: Optional[int] = None) -> Optional['Element']:
        """
        Find a child element within this element.
        
        Args:
            selector: CSS selector
            timeout: Optional timeout in seconds
            
        Returns:
            Child Element object or None
        """
        return self._browser.find(selector, element_id=self.id, timeout=timeout)
    
    def find_all(self, selector: str, timeout: Optional[int] = None) -> List['Element']:
        """
        Find all child elements within this element.
        
        Args:
            selector: CSS selector
            timeout: Optional timeout in seconds
            
        Returns:
            List of child Element objects
        """
        return self._browser.find(selector, element_id=self.id, timeout=timeout, multiple=True)
    
    def __repr__(self) -> str:
        return f"Element(id='{self.id}', selector='{self.selector}')"
    
    def __str__(self) -> str:
        return f"Element({self.selector})"


class Scrapely:
    """
    Python client for Scrapely browser automation service.
    
    Usage:
        # Method 1: Context manager (recommended)
        with Scrapely("ws://localhost:8000/connect") as browser:
            browser.goto("https://example.com")
            button = browser.find("#button")
            button.click()
            text = button.get_text()
        
        # Method 2: Manual connection
        browser = Scrapely("ws://localhost:8000/connect")
        browser.connect()
        try:
            browser.goto("https://example.com")
            browser.click("#button")
        finally:
            browser.close()
    """
    
    def __init__(self, url: str = "ws://localhost:5050/connect", timeout: int = 300):
        """
        Initialize Scrapely client.
        
        Args:
            url: WebSocket URL of the Scrapely service
            timeout: Connection timeout in seconds
        """
        self.url = url
        self.timeout = timeout
        self.ws: Optional[WebSocket] = None
        self._connected = False
    
    def connect(self) -> bool:
        """
        Establish connection to Scrapely service.
        
        Returns:
            True if connection successful
            
        Raises:
            ConnectionError: If connection fails
        """
        try:
            self.ws = create_connection(self.url, timeout=self.timeout)
            response = json.loads(self.ws.recv())
            
            if response.get("status"):
                self._connected = True
                return True
            else:
                raise ConnectionError(f"Service returned error: {response}")
                
        except Exception as e:
            raise ConnectionError(f"Failed to connect to Scrapely service: {e}")
    
    def _send_operation(self, method: str, kwargs: Dict[str, Any], 
                       description: str = "", retry_count: int = 0,
                       ignore_errors: bool = False) -> Dict[str, Any]:
        """
        Send a single operation to the service.
        
        Args:
            method: Browser method name
            kwargs: Method arguments
            description: Operation description for logging
            retry_count: Number of retries on failure
            ignore_errors: Whether to ignore errors
            
        Returns:
            Operation result dictionary
            
        Raises:
            OperationError: If operation fails and ignore_errors is False
        """
        if not self._connected:
            raise ConnectionError("Not connected. Call connect() first.")
        
        request_id = str(uuid.uuid4())
        payload = {
            "request_id": request_id,
            "method": method,
            "kwargs": kwargs,
            "description": description,
            "retry_count": retry_count,
            "ignore_errors": ignore_errors
        }
        
        self.ws.send(json.dumps(payload))
        response = json.loads(self.ws.recv())
        
        if not response.get("status") and not ignore_errors:
            error_msg = response.get("message", "Unknown error")
            raise OperationError(f"Operation '{method}' failed: {error_msg}")
        
        return response
    
    def _send_batch(self, operations: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """
        Send multiple operations as a batch.
        
        Args:
            operations: List of operation dictionaries
            
        Returns:
            List of operation results
        """
        if not self._connected:
            raise ConnectionError("Not connected. Call connect() first.")
        
        # Assign request IDs to operations without one
        for op in operations:
            if "request_id" not in op:
                op["request_id"] = str(uuid.uuid4())
        
        batch_id = str(uuid.uuid4())
        payload = {
            "batch_id": batch_id,
            "operations": operations
        }
        
        self.ws.send(json.dumps(payload))
        response = json.loads(self.ws.recv())
        
        return response.get("results", [])
    
    
    def goto(self, url: str, timeout: int = 15, wait_for_load: bool = True) -> bool:
        """
        Navigate to a URL.
        
        Args:
            url: Target URL
            timeout: Navigation timeout in seconds
            wait_for_load: Whether to wait for page to fully load
            
        Returns:
            True if navigation successful
        """
        result = self._send_operation(
            "goto",
            {"url": url, "timeout": timeout, "wait_for_load": wait_for_load},
            description=f"Navigate to {url}"
        )
        return result.get("data", False) if result.get("data") is not None else result.get("status", False)
    
    def wait_for_page(self, url: str, timeout: Optional[int] = None) -> bool:
        """
        Wait for page URL to match.
        
        Args:
            url: Expected URL or URL pattern
            timeout: Optional timeout in seconds
            
        Returns:
            True if page URL matches
        """
        result = self._send_operation(
            "wait_for_page",
            {"url": url, "timeout": timeout},
            description=f"Wait for page {url}"
        )
        return result.get("data", False) if result.get("data") is not None else result.get("status", False)
    
    def current_url(self) -> str:
        """
        Get current page URL.
        
        Returns:
            Current URL string
        """
        result = self._send_operation(
            "current_url",
            {},
            description="Get current URL"
        )
        data = result.get("data", {})
        if isinstance(data, dict):
            return data.get("text", "")
        return str(data) if data else ""
    
    
    def find(
        self,
        selector: Optional[str] = None,
        element_id: Optional[str] = None,
        timeout: Optional[int] = None,
        multiple: bool = False
    ) -> Union[Optional[Element], List[Element]]:
        """
        Universal element finder.
        
        Args:
            selector: CSS selector
            element_id: Parent element ID (for finding within parent)
            timeout: Optional timeout in seconds
            multiple: If True, return all matching elements
            
        Returns:
            Element object, List of Elements, or None
            
        Example:
            # Find single element
            button = browser.find("#submit-btn")
            
            # Find multiple elements
            items = browser.find(".list-item", multiple=True)
            
            # Find within parent
            parent = browser.find("#container")
            child = browser.find(".child", element_id=parent.id)
        """
        result = self._send_operation(
            "find",
            {
                "selector": selector,
                "element_id": element_id,
                "timeout": timeout,
                "multiple": multiple
            },
            description=f"Find element(s) {selector}"
        )
        
        data = result.get("data")
        if not data:
            return [] if multiple else None
        
        if multiple:
            if isinstance(data, list):
                return [
                    Element(
                        element_id=el.get("id"),
                        selector=el.get("selector"),
                        browser=self
                    )
                    for el in data if isinstance(el, dict)
                ]
            return []
        else:
            if isinstance(data, dict):
                return Element(
                    element_id=data.get("id"),
                    selector=data.get("selector"),
                    browser=self
                )
            return None
    
    def exists(
        self,
        selector: Optional[str] = None,
        element_id: Optional[str] = None
    ) -> bool:
        """
        Check if element exists.
        
        Args:
            selector: CSS selector
            element_id: Cached element ID
            
        Returns:
            True if element exists
        """
        result = self._send_operation(
            "exists",
            {"selector": selector, "element_id": element_id},
            description=f"Check existence of {selector or element_id}",
            ignore_errors=True
        )
        return result.get("data", False) if result.get("data") is not None else result.get("status", False)
    
    
    def click(
        self,
        selector: Optional[str] = None,
        element_id: Optional[str] = None,
        timeout: Optional[int] = None
    ) -> bool:
        """
        Click an element.
        
        Args:
            selector: CSS selector
            element_id: Cached element ID (internal use)
            timeout: Optional timeout in seconds
            
        Returns:
            True if click successful
        """
        kwargs = {"timeout": timeout}
        if element_id:
            kwargs["element_id"] = element_id
        else:
            kwargs["selector"] = selector
            
        result = self._send_operation(
            "click",
            kwargs,
            description=f"Click {selector or element_id}"
        )
        return result.get("data", False) if result.get("data") is not None else result.get("status", False)
    
    def type(
        self,
        text: str,
        selector: Optional[str] = None,
        element_id: Optional[str] = None,
        timeout: Optional[int] = None,
        clear: bool = False
    ) -> bool:
        """
        Type text into an input field.
        
        Args:
            text: Text to type
            selector: CSS selector
            element_id: Cached element ID (internal use)
            timeout: Optional timeout in seconds
            clear: Whether to clear existing text first
            
        Returns:
            True if type successful
        """
        kwargs = {"text": text, "timeout": timeout, "clear": clear}
        if element_id:
            kwargs["element_id"] = element_id
        else:
            kwargs["selector"] = selector
            
        result = self._send_operation(
            "type",
            kwargs,
            description=f"Type into {selector or element_id}"
        )
        return result.get("data", False) if result.get("data") is not None else result.get("status", False)
    
    def scroll_to(
        self,
        selector: Optional[str] = None,
        element_id: Optional[str] = None,
        timeout: Optional[int] = None
    ) -> bool:
        """
        Scroll to element.
        
        Args:
            selector: CSS selector
            element_id: Cached element ID (internal use)
            timeout: Optional timeout in seconds
            
        Returns:
            True if scroll successful
        """
        kwargs = {"timeout": timeout}
        if element_id:
            kwargs["element_id"] = element_id
        else:
            kwargs["selector"] = selector
            
        result = self._send_operation(
            "scroll_to",
            kwargs,
            description=f"Scroll to {selector or element_id}"
        )
        return result.get("data", False) if result.get("data") is not None else result.get("status", False)
    
    
    def get_text(
        self,
        selector: Optional[str] = None,
        element_id: Optional[str] = None,
        timeout: Optional[int] = None
    ) -> str:
        """
        Get text content of an element.
        
        Args:
            selector: CSS selector
            element_id: Cached element ID (internal use)
            timeout: Optional timeout in seconds
            
        Returns:
            Element text content
        """
        kwargs = {"timeout": timeout}
        if element_id:
            kwargs["element_id"] = element_id
        else:
            kwargs["selector"] = selector
            
        result = self._send_operation(
            "get_text",
            kwargs,
            description=f"Get text from {selector or element_id}"
        )
        data = result.get("data", "")
        if isinstance(data, dict):
            return data.get("text", "")
        return str(data) if data else ""
    
    def get_attr(
        self,
        attribute: str,
        selector: Optional[str] = None,
        element_id: Optional[str] = None,
        timeout: Optional[int] = None
    ) -> Optional[str]:
        """
        Get element attribute value.
        
        Args:
            attribute: Attribute name (e.g., "href", "class", "data-id")
            selector: CSS selector
            element_id: Cached element ID (internal use)
            timeout: Optional timeout in seconds
            
        Returns:
            Attribute value or None
        """
        kwargs = {"attribute": attribute, "timeout": timeout}
        if element_id:
            kwargs["element_id"] = element_id
        else:
            kwargs["selector"] = selector
            
        result = self._send_operation(
            "get_attr",
            kwargs,
            description=f"Get attribute {attribute}"
        )
        return result.get("data")
    
    
    def click_xpath(self, xpath: str) -> bool:
        """
        Click element by XPath using JavaScript.
        
        Args:
            xpath: XPath expression
            
        Returns:
            True if click successful
        """
        result = self._send_operation(
            "click_xpath",
            {"xpath": xpath},
            description=f"Click XPath: {xpath}"
        )
        return result.get("data", False) if result.get("data") is not None else result.get("status", False)
    
    def select_option(
        self,
        selector: str,
        index: Optional[int] = None,
        value: Optional[str] = None,
        timeout: int = 10
    ) -> bool:
        """
        Select option from dropdown.
        
        Args:
            selector: CSS selector for <select> element
            index: Option index to select
            value: Option value to select
            timeout: Timeout in seconds
            
        Returns:
            True if selection successful
        """
        result = self._send_operation(
            "select_option",
            {"selector": selector, "index": index, "value": value, "timeout": timeout},
            description=f"Select option in {selector}"
        )
        return result.get("data", False) if result.get("data") is not None else result.get("status", False)
    
    def run_js(self, script: str, *args) -> Any:
        """
        Execute JavaScript in browser context.
        
        Args:
            script: JavaScript code to execute
            *args: Arguments to pass to script
            
        Returns:
            Script execution result
        """
        result = self._send_operation(
            "run_js",
            {"script": script, "args": args},
            description="Execute JavaScript"
        )
        return result.get("data")
    
    def run_js_on_element(
        self,
        script: str,
        selector: Optional[str] = None,
        element_id: Optional[str] = None,
        timeout: Optional[int] = None
    ) -> Any:
        """
        Execute JavaScript on specific element.
        
        Args:
            script: JavaScript code (element available as 'this')
            selector: CSS selector
            element_id: Cached element ID (internal use)
            timeout: Optional timeout in seconds
            
        Returns:
            Script execution result
        """
        kwargs = {"script": script, "timeout": timeout}
        if element_id:
            kwargs["element_id"] = element_id
        else:
            kwargs["selector"] = selector
            
        result = self._send_operation(
            "run_js_on_element",
            kwargs,
            description="Execute JavaScript on element"
        )
        return result.get("data")
    
    def get_shadow_root(
        self,
        selector: Optional[str] = None,
        element_id: Optional[str] = None,
        timeout: int = 10
    ) -> Optional[str]:
        """
        Get shadow root element ID.
        
        Args:
            selector: CSS selector
            element_id: Cached element ID
            timeout: Timeout in seconds
            
        Returns:
            Shadow root element ID for use in subsequent operations
        """
        kwargs = {"timeout": timeout}
        if element_id:
            kwargs["element_id"] = element_id
        else:
            kwargs["selector"] = selector
            
        result = self._send_operation(
            "get_shadow_root",
            kwargs,
            description="Get shadow root"
        )
        return result.get("data")
    
    def drag_and_drop_to(
        self,
        draggable: str,
        droppable: str,
        timeout: int = 10
    ) -> bool:
        """
        Drag and drop element.
        
        Args:
            draggable: CSS selector for element to drag
            droppable: CSS selector for drop target
            timeout: Timeout in seconds
            
        Returns:
            True if drag and drop successful
        """
        result = self._send_operation(
            "drag_and_drop_to",
            {"draggable": draggable, "droppable": droppable, "timeout": timeout},
            description=f"Drag {draggable} to {droppable}"
        )
        return result.get("data", False) if result.get("data") is not None else result.get("status", False)
    
    
    def batch_operations(self, operations: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """
        Execute multiple operations in a batch.
        
        Args:
            operations: List of operation dictionaries with 'method' and 'kwargs' keys
            
        Returns:
            List of operation results
            
        Example:
            results = browser.batch_operations([
                {"method": "goto", "kwargs": {"url": "https://example.com"}},
                {"method": "click", "kwargs": {"selector": "#button"}},
                {"method": "get_text", "kwargs": {"selector": ".result"}}
            ])
        """
        return self._send_batch(operations)
    
    
    def close(self):
        """Close the WebSocket connection and cleanup resources."""
        if self.ws:
            try:
                self.ws.close()
            except:
                pass
            finally:
                self._connected = False
    
    def __enter__(self):
        """Context manager entry."""
        self.connect()
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        """Context manager exit."""
        self.close()
        return False

