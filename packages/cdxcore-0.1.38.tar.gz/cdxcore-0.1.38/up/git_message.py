"""
Produce message with cdxbasics code
"""

import cdxcore as cdxcore
print("Code base %s" % cdxcore.__version__)

