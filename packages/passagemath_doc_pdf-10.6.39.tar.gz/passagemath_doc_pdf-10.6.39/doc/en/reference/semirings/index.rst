Standard Semirings
==================

.. toctree::
   :maxdepth: 1

   sage/rings/semirings/non_negative_integer_semiring
   sage/rings/semirings/tropical_semiring

.. include:: ../footer.txt
