from .feedback_bot import main

main()
