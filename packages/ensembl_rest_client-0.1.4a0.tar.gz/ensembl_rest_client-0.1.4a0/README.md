# Getting Started with enembl-rest-client
__version__: `0.1.4a0`

enembl-rest-client provides Pythonic access to the Ensembl REST services. I build this for some of my other projects to use as there was not anything implemented at the time. It implemented most the current endpoints at `http://rest.ensembl.org` at the time but I have not checked all the current endpoints.

Note that not all the implemented endpoint methods have been tested properly. They are being tested as they are used and having a pytest test written for them.

Now there are other ensembl rest implementations. You may be better using these:

* https://pypi.org/project/pyEnsemblRest/
* https://pypi.org/project/ensembl-rest/

There is [online](https://cfinan.gitlab.io/ensembl-rest-client/index.html) documentation for ensembl-rest-client.

## Installation instructions
You can install using pip or conda.

### Installation using pip

```
pip install ensembl-rest-client
```

### Installation using conda
I maintain a conda package in my personal conda channel. To install this please run:

```
conda install -c cfin -c conda-forge ensembl-rest-client
```

## Basic usage
There are some examples in `./resources/examples` where `.` is the root of the cloned repository.

## Run tests
If you have cloned the repository, you can also run the tests using `pytest ./tests`, if any fail please contact us (see the contribution page for contact info).
