# flake8: noqa

# import apis into api package
from affinidi_tdk_credential_verification_client.api.default_api import DefaultApi

