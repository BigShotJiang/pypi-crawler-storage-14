import csv
import os

class CSVImporter():

    def load_full_csv(self, file_path):
        """Charge tout le fichier CSV sous forme de tableau de tableau."""
        if not os.path.exists(file_path):
            raise FileNotFoundError(f"Le fichier '{file_path}' n'existe pas.")

        with open(file_path, newline='', encoding='utf-8') as csvfile:
            reader = csv.reader(csvfile)
            data = [row for row in reader]
        return data

    def load_range(self, file_path, start_row, end_row, start_col=None, end_col=None):
        """Charge une portion du CSV :
        - lignes de start_row à end_row (1-based),
        - colonnes de start_col à end_col (facultatif, sinon toutes les colonnes).
        """
        full_data = self.load_full_csv(file_path)
        selected_rows = full_data[start_row-1:end_row]

        if start_col is not None and end_col is not None:
            # Slicing columns aussi
            selected_rows = [row[start_col-1:end_col] for row in selected_rows]

        return selected_rows
    
if __name__ == "__main__":
    CSVImporter().load_full_csv("/home/marc/Bureau/PER/comments.csv")
    CSVImporter().load_range("/home/marc/Bureau/PER/comments.csv",1,3)
