"""
zadar_applications

Provides pip-installable ROS1 message types for Zadar radar systems.
"""

from . import msgs

__all__ = ["msgs"]
__version__ = "0.1.0"
