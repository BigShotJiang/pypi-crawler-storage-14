# 1. Install Postfix non-interactively
sudo chmod -x scripts/wordcount_helper.s

# 2. Fix bugs - sample solution stored in /opt