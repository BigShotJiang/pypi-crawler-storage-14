from __future__ import annotations

import uuid
from os.path import join
from typing import TYPE_CHECKING, Iterable, NamedTuple, Optional
from typing import Any as TypingAny

from lxml import etree
from lxml.etree import Element, XMLParser, XMLSchema

import sila2
from sila2.config import ENCODING
from sila2.framework.abc.data_type import DataType
from sila2.framework.abc.named_data_node import NamedDataNode
from sila2.framework.pb2 import SiLAFramework_pb2
from sila2.framework.pb2.SiLAFramework_pb2 import Any as SilaAny
from sila2.framework.utils import xml_node_to_normalized_string

if TYPE_CHECKING:
    from sila2.client import ClientMetadataInstance
    from sila2.framework import DataTypeDefinition

ANYTYPE_XML_SCHEMA = XMLSchema(etree.parse(join(sila2.resource_dir, "xsd", "AnyTypeDataType.xsd")))
VOID_TYPE_XML = etree.fromstring(
    """<DataType xmlns="http://www.sila-standard.org">
      <Constrained>
        <DataType>
          <Basic>String</Basic>
        </DataType>
        <Constraints>
          <Length>0</Length>
        </Constraints>
      </Constrained>
    </DataType>
    """
)


class SilaAnyType(NamedTuple):
    type_xml: str
    """
    DataType element, must adhere to
    `AnyTypeDataType.xsd <https://gitlab.com/SiLA2/sila_base/-/blob/master/schema/AnyTypeDataType.xsd>`_
    """
    value: TypingAny
    """Value of the given type"""

    @staticmethod
    def create_void() -> SilaAnyType:
        """Create an instance representing Python's ``None`` (called "Void" in SiLA)."""
        return SilaAnyType(xml_node_to_normalized_string(VOID_TYPE_XML), None)


def parse_datatype_xml(xml_str: str, inject_missing_namespace: bool = False) -> Element:
    xml_bytes = xml_str.encode(ENCODING)

    # for compatibility with older versions of the framework, we inject the namespace if it is missing
    if inject_missing_namespace:
        naive_xml_node = etree.fromstring(xml_bytes, parser=XMLParser(resolve_entities=False))
        if naive_xml_node.tag == "DataType":
            naive_xml_node.attrib["xmlns"] = "http://www.sila-standard.org"
            xml_bytes = etree.tostring(naive_xml_node, encoding=ENCODING)

    return etree.fromstring(
        xml_bytes,
        parser=XMLParser(schema=ANYTYPE_XML_SCHEMA, encoding=ENCODING, resolve_entities=False),
    )


class Any(DataType[SilaAny, SilaAnyType]):
    message_type = SiLAFramework_pb2.Any

    def to_native_type(self, message: SilaAny, toplevel_named_data_node: Optional[NamedDataNode] = None) -> SilaAnyType:
        datatype_xml = parse_datatype_xml(message.type)
        if Any.__is_void(datatype_xml):
            return SilaAnyType.create_void()

        data_type = Any.__getdata_type(datatype_xml)

        msg = data_type.message_type.FromString(message.payload)
        native_value = data_type.to_native_type(msg, toplevel_named_data_node=toplevel_named_data_node)

        return SilaAnyType(xml_node_to_normalized_string(datatype_xml), native_value)

    def to_message(
        self,
        value: SilaAnyType,
        toplevel_named_data_node: Optional[NamedDataNode] = None,
        metadata: Optional[Iterable[ClientMetadataInstance]] = None,
    ) -> SilaAny:
        type_xml_str, native_value = value
        datatype_xml = parse_datatype_xml(type_xml_str, inject_missing_namespace=True)

        if Any.__is_void(datatype_xml) and native_value is None:
            native_value = ""

        data_type = Any.__getdata_type(datatype_xml)
        message = data_type.to_message(
            native_value, toplevel_named_data_node=toplevel_named_data_node, metadata=metadata
        )

        return SiLAFramework_pb2.Any(
            type=xml_node_to_normalized_string(datatype_xml),
            payload=message.SerializeToString(),
        )

    @staticmethod
    def __is_void(datatype_xml: Element) -> bool:
        return xml_node_to_normalized_string(datatype_xml) == xml_node_to_normalized_string(VOID_TYPE_XML)

    @staticmethod
    def __getdata_type(datatype_xml: Element) -> DataTypeDefinition:
        from sila2.framework.feature import Feature  # noqa: PLC0415 (local import)

        feature_xml = Any.__build_feature_xml(datatype_xml)

        return Feature(feature_xml)._data_type_definitions["Any"]

    @staticmethod
    def __build_feature_xml(datatype_xml: Element) -> str:
        datatype_xml_string = xml_node_to_normalized_string(datatype_xml)
        datatype_xml_string = datatype_xml_string.replace(
            '<DataType xmlns="http://www.sila-standard.org">',
            "<DataType>",
        )

        return f"""\
<?xml version="1.0" encoding="utf-8" ?>
<Feature SiLA2Version="1.0" FeatureVersion="1.0" Originator="org.silastandard"
         Category="tests"
         xmlns="http://www.sila-standard.org"
         xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
         xsi:schemaLocation="http://www.sila-standard.org
             https://gitlab.com/SiLA2/sila_base/raw/master/schema/FeatureDefinition.xsd">
    <Identifier>AnyFeature{str(uuid.uuid4()).replace("-", "")}</Identifier>
    <DisplayName>Any</DisplayName>
    <Description>Dummy feature for the SiLA2 Any type</Description>
    <DataTypeDefinition>
        <Identifier>Any</Identifier>
        <DisplayName>Any</DisplayName>
        <Description>Any</Description>
        {datatype_xml_string}
    </DataTypeDefinition>
</Feature>"""
