"""
BridgeLink - Expose Android devices remotely via NativeBridge
"""

__version__ = "0.3.0"
__author__ = "NativeBridge"
__email__ = "support@nativebridge.io"
