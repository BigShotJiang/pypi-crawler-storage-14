# cif-emdb-translator

The translator translates mmCIF files (.cif) into .xml header files
that comply with EMDB 3.x.x.x and later schemas
