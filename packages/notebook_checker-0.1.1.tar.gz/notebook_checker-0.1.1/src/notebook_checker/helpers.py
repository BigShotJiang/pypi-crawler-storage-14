def remove_existing(lst, check):
    for inst in [x for x in lst if check(x)]: lst.remove(inst)
