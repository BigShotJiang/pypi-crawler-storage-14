_notebook_log_store.clear()

