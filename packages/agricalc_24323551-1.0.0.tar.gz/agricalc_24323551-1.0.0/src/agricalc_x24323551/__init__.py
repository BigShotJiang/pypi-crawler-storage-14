
__version__ = "1.0.0"
__author__ = "Venkata Narasimha Vidya Sagar Earla"

from .crop_calculator import CropCalculator

__all__ = [
    'CropCalculator'
]
