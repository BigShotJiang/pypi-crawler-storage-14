"""
Utility functions for AgriCalc
"""

from datetime import datetime


def days_since_epoch(date: datetime) -> int:
    """Convert datetime to days since epoch"""
    epoch = datetime(1970, 1, 1)
    return (date - epoch).days


def days_between_dates(date1: datetime, date2: datetime) -> int:
    """Calculate days between two dates"""
    return abs((date2 - date1).days)


def validate_temperature(temp: float, param_name: str = "temperature") -> None:
    """Validate temperature value"""
    if temp < -50 or temp > 60:
        raise ValueError(f"{param_name} must be between -50°C and 60°C")


def validate_percentage(value: float, param_name: str = "value") -> None:
    """Validate percentage value"""
    if value < 0 or value > 100:
        raise ValueError(f"{param_name} must be between 0 and 100")


def convert_celsius_to_fahrenheit(celsius: float) -> float:
    """Convert Celsius to Fahrenheit"""
    return (celsius * 9/5) + 32


def convert_mm_to_inches(mm: float) -> float:
    """Convert millimeters to inches"""
    return mm / 25.4
