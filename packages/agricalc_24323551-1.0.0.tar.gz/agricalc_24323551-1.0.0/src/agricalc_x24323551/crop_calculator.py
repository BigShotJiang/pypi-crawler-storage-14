"""Simplified Crop Calculator - Essential Calculations Only"""

from datetime import datetime, date
from typing import Dict


class CropCalculator:
    
    @staticmethod
    def calculate_growth_status(planting_date: date, expected_days: int = 120) -> Dict:

        today = datetime.now().date()
        days_since_planting = (today - planting_date).days
        
        if days_since_planting < 0:
            days_since_planting = 0
        
        # Calculate progress percentage
        progress_percent = min(100, (days_since_planting / expected_days) * 100)
        
        # Determine growth stage
        if progress_percent < 25:
            stage = "Early Growth"
            stage_description = "Seedling establishment phase"
        elif progress_percent < 50:
            stage = "Vegetative"
            stage_description = "Active leaf and stem development"
        elif progress_percent < 75:
            stage = "Reproductive"
            stage_description = "Flowering and fruit development"
        elif progress_percent < 100:
            stage = "Maturation"
            stage_description = "Approaching harvest"
        else:
            stage = "Harvest Ready"
            stage_description = "Ready for harvest"
        
        days_remaining = max(0, expected_days - days_since_planting)
        
        return {
            'days_since_planting': days_since_planting,
            'expected_days': expected_days,
            'days_remaining': days_remaining,
            'progress_percent': round(progress_percent, 1),
            'stage': stage,
            'stage_description': stage_description,
            'harvest_ready': progress_percent >= 100
        }
    
    @staticmethod
    def calculate_water_needs(crop_area: float, days_since_planting: int, 
                             expected_days: int = 120) -> Dict:

        # Simple water coefficient based on growth stage
        progress = min(100, (days_since_planting / expected_days) * 100)
        
        if progress < 25:
            daily_water_mm = 3.0  # Early stage - low water need
        elif progress < 50:
            daily_water_mm = 5.0  # Vegetative - moderate water need
        elif progress < 75:
            daily_water_mm = 7.0  # Reproductive - high water need
        else:
            daily_water_mm = 4.0  # Maturation - reducing water need
        
        # Total daily requirement
        daily_water_liters = crop_area * 10000 * daily_water_mm / 1000  # Convert to liters
        
        # Weekly requirement
        weekly_water_liters = daily_water_liters * 7
        
        # Irrigation recommendation (simple)
        if daily_water_mm <= 3:
            irrigation_frequency = "Every 5-7 days"
        elif daily_water_mm <= 5:
            irrigation_frequency = "Every 3-4 days"
        else:
            irrigation_frequency = "Every 2-3 days"
        
        return {
            'daily_water_mm': round(daily_water_mm, 1),
            'daily_water_liters': round(daily_water_liters, 0),
            'weekly_water_liters': round(weekly_water_liters, 0),
            'irrigation_frequency': irrigation_frequency,
            'crop_area_ha': crop_area
        }
    
    @staticmethod
    def calculate_fertilizer_needs(crop_area: float, yield_target: float,
                                   crop_type: str = "general") -> Dict:

        # Simplified NPK ratios by crop type
        if crop_type.lower() in ["wheat", "rice", "maize", "cereal"]:
            n_rate = 0.020  # 20 kg N per 1000 kg yield
            p_rate = 0.010  # 10 kg P per 1000 kg yield
            k_rate = 0.015  # 15 kg K per 1000 kg yield
        elif crop_type.lower() in ["vegetable", "potato", "tomato"]:
            n_rate = 0.015
            p_rate = 0.012
            k_rate = 0.020
        elif crop_type.lower() in ["pulse", "soybean", "chickpea", "lentil"]:
            n_rate = 0.008  # Pulses fix their own nitrogen
            p_rate = 0.015
            k_rate = 0.018
        else:
            # General crop
            n_rate = 0.018
            p_rate = 0.010
            k_rate = 0.016
        
        # Calculate total fertilizer needed
        total_n = yield_target * n_rate
        total_p = yield_target * p_rate
        total_k = yield_target * k_rate
        
        # Total for the field
        field_n = total_n * crop_area
        field_p = total_p * crop_area
        field_k = total_k * crop_area
        
        # Simple application recommendation
        basal_n = round(field_n * 0.3, 1)  # 30% at planting
        top_dress_n = round(field_n * 0.7, 1)  # 70% during growth
        
        return {
            'nitrogen_kg_per_ha': round(total_n, 1),
            'phosphorus_kg_per_ha': round(total_p, 1),
            'potassium_kg_per_ha': round(total_k, 1),
            'total_nitrogen_kg': round(field_n, 1),
            'total_phosphorus_kg': round(field_p, 1),
            'total_potassium_kg': round(field_k, 1),
            'basal_application_n': basal_n,
            'top_dressing_n': top_dress_n,
            'npk_ratio': f"{int(total_n)}-{int(total_p)}-{int(total_k)}",
            'recommendation': f"Apply {basal_n} kg N at planting, {top_dress_n} kg N as top dressing"
        }
    
    @staticmethod
    def get_complete_recommendations(planting_date: date, crop_area: float,
                                    yield_target: float, expected_days: int = 120,
                                    crop_type: str = "general") -> Dict:

        growth = CropCalculator.calculate_growth_status(planting_date, expected_days)
        
        water = CropCalculator.calculate_water_needs(
            crop_area, 
            growth['days_since_planting'],
            expected_days
        )
        
        fertilizer = CropCalculator.calculate_fertilizer_needs(
            crop_area,
            yield_target,
            crop_type
        )
        
        return {
            'growth': growth,
            'water': water,
            'fertilizer': fertilizer,
            'summary': {
                'stage': growth['stage'],
                'progress': f"{growth['progress_percent']}%",
                'days_remaining': growth['days_remaining'],
                'water_today': f"{water['daily_water_liters']} liters",
                'irrigation': water['irrigation_frequency'],
                'fertilizer_npk': fertilizer['npk_ratio']
            }
        }
