# AgriCalc

algorithm-based agricultural calculations library.

## Features

-  Growing Degree Days (GDD) calculations
-  Evapotranspiration (ET) and irrigation scheduling
-  NPK fertilizer requirement calculations
-  Harvest maturity predictions
-  Formula-based recommendations
-  Based on FAO and university research

## Installation

```bash
pip install agricalc
