import cocoex
import doctest

doctest.testmod(cocoex)
