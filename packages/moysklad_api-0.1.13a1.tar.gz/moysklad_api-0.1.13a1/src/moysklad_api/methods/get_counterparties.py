from moysklad_api.methods import MSMethod
from moysklad_api.types import Counterparty, MetaArray


class GetCounterparties(MSMethod):
    """
    Use this method to list of counterparties.

    Source: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/counterparty#3-poluchit-spisok-kontragentov
    """

    __return__ = MetaArray[Counterparty]
    __api_method__ = "entity/counterparty"
