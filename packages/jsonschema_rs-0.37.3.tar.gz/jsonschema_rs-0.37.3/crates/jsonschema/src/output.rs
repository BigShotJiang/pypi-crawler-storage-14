//! Backwards-compatible re-exports for structured output helpers.

pub use crate::evaluation::{Annotations, ErrorDescription};
