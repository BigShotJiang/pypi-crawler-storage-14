"""
Subpackage containing matrix operations.
"""

from .elementary import *