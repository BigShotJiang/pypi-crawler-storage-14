# WhitePossum Package

This package implements differential functions.