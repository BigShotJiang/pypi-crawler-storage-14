"""HTTP client for VirtualDojo API."""

import time
from typing import Any, Optional

import httpx

from .config import (
    Credentials,
    Profile,
    config_manager,
    get_current_credentials,
    get_current_profile,
)
from .exceptions import (
    APIError,
    AuthenticationError,
    NetworkError,
    NotLoggedInError,
    TokenExpiredError,
)


class VirtualDojoClient:
    """Async HTTP client with automatic auth and tenant handling."""

    def __init__(
        self,
        profile: Optional[str] = None,
        *,
        timeout: float = 30.0,
    ):
        """Initialize the client.

        Args:
            profile: Profile name to use. If None, uses default profile.
            timeout: Request timeout in seconds.
        """
        self._profile_name = profile
        self._profile: Optional[Profile] = None
        self._credentials: Optional[Credentials] = None
        self._client: Optional[httpx.AsyncClient] = None
        self._timeout = timeout

    @property
    def profile(self) -> Profile:
        """Get the current profile."""
        if self._profile is None:
            self._profile = get_current_profile(self._profile_name)
        return self._profile

    @property
    def credentials(self) -> Credentials:
        """Get the current credentials."""
        if self._credentials is None:
            creds = get_current_credentials(self.profile.name)
            if creds is None or creds.token is None:
                raise NotLoggedInError()
            self._credentials = creds
        return self._credentials

    def _is_token_expired(self) -> bool:
        """Check if the current token is expired."""
        if self.credentials.expires_at is None:
            return False
        # Add 30 second buffer
        return time.time() > (self.credentials.expires_at - 30)

    async def _refresh_token(self) -> bool:
        """Attempt to refresh the JWT token.

        Returns:
            True if refresh was successful, False otherwise.
        """
        if self.credentials.token_type != "jwt" or not self.credentials.refresh_token:
            return False

        try:
            async with httpx.AsyncClient(
                base_url=self.profile.server,
                timeout=self._timeout,
            ) as client:
                response = await client.post(
                    "/api/v1/auth/refresh-token",
                    json={"refresh_token": self.credentials.refresh_token},
                )

                if response.status_code == 200:
                    data = response.json()
                    self._credentials.token = data["access_token"]
                    self._credentials.expires_at = time.time() + data.get(
                        "expires_in", 1800
                    )
                    if "refresh_token" in data:
                        self._credentials.refresh_token = data["refresh_token"]
                    config_manager.save_credentials(self._credentials)
                    return True
        except Exception:
            pass

        return False

    def _get_headers(self) -> dict[str, str]:
        """Get headers for API requests."""
        return {
            "Authorization": f"Bearer {self.credentials.token}",
            "X-Tenant-ID": self.profile.tenant,
            "Content-Type": "application/json",
        }

    async def __aenter__(self) -> "VirtualDojoClient":
        """Enter async context."""
        # Check token expiration
        if self._is_token_expired():
            if not await self._refresh_token():
                raise TokenExpiredError()

        self._client = httpx.AsyncClient(
            base_url=self.profile.server,
            headers=self._get_headers(),
            timeout=self._timeout,
        )
        return self

    async def __aexit__(self, *args: Any) -> None:
        """Exit async context."""
        if self._client:
            await self._client.aclose()
            self._client = None

    async def _handle_response(self, response: httpx.Response) -> None:
        """Handle API response and raise appropriate exceptions."""
        if response.status_code == 401:
            # Try token refresh
            if await self._refresh_token():
                # Update client headers with new token
                if self._client:
                    self._client.headers["Authorization"] = (
                        f"Bearer {self.credentials.token}"
                    )
                # Caller should retry the request
                raise TokenExpiredError()
            raise AuthenticationError(
                message="Authentication failed.",
                hint="Run 'vdojo login' to authenticate again.",
            )

        if response.status_code >= 400:
            try:
                detail = response.json().get("detail", "Unknown error")
            except Exception:
                detail = response.text or "Unknown error"
            raise APIError(response.status_code, detail)

    async def _request(
        self,
        method: str,
        path: str,
        *,
        params: Optional[dict[str, Any]] = None,
        json: Optional[dict[str, Any]] = None,
        retry_count: int = 1,
    ) -> dict[str, Any]:
        """Make an HTTP request with automatic retry on token refresh.

        Args:
            method: HTTP method (GET, POST, PUT, DELETE)
            path: API path
            params: Query parameters
            json: JSON body data
            retry_count: Number of retries remaining

        Returns:
            Response JSON data
        """
        if not self._client:
            raise RuntimeError("Client not initialized. Use 'async with' context.")

        try:
            response = await self._client.request(
                method, path, params=params, json=json
            )
            await self._handle_response(response)
            return response.json() if response.content else {}
        except TokenExpiredError:
            if retry_count > 0:
                # Update headers and retry
                self._client.headers["Authorization"] = (
                    f"Bearer {self.credentials.token}"
                )
                return await self._request(
                    method, path, params=params, json=json, retry_count=retry_count - 1
                )
            raise
        except httpx.ConnectError as e:
            raise NetworkError(f"Could not connect to {self.profile.server}") from e
        except httpx.TimeoutException as e:
            raise NetworkError("Request timed out") from e

    async def get(
        self, path: str, *, params: Optional[dict[str, Any]] = None
    ) -> dict[str, Any]:
        """Make a GET request."""
        return await self._request("GET", path, params=params)

    async def post(
        self, path: str, data: Optional[dict[str, Any]] = None
    ) -> dict[str, Any]:
        """Make a POST request."""
        return await self._request("POST", path, json=data)

    async def put(
        self, path: str, data: Optional[dict[str, Any]] = None
    ) -> dict[str, Any]:
        """Make a PUT request."""
        return await self._request("PUT", path, json=data)

    async def delete(self, path: str) -> dict[str, Any]:
        """Make a DELETE request."""
        return await self._request("DELETE", path)

    async def patch(
        self, path: str, data: Optional[dict[str, Any]] = None
    ) -> dict[str, Any]:
        """Make a PATCH request."""
        return await self._request("PATCH", path, json=data)


class SyncVirtualDojoClient:
    """Synchronous wrapper for VirtualDojoClient.

    This is used by Typer commands which don't support async natively.
    """

    def __init__(self, profile: Optional[str] = None, *, timeout: float = 30.0):
        self._profile_name = profile
        self._timeout = timeout

    def _run_async(self, coro: Any) -> Any:
        """Run an async coroutine synchronously."""
        import asyncio

        try:
            loop = asyncio.get_event_loop()
        except RuntimeError:
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)

        return loop.run_until_complete(coro)

    def get(self, path: str, *, params: Optional[dict[str, Any]] = None) -> dict[str, Any]:
        """Make a GET request."""
        async def _get() -> dict[str, Any]:
            async with VirtualDojoClient(
                self._profile_name, timeout=self._timeout
            ) as client:
                return await client.get(path, params=params)

        return self._run_async(_get())

    def post(
        self, path: str, data: Optional[dict[str, Any]] = None
    ) -> dict[str, Any]:
        """Make a POST request."""
        async def _post() -> dict[str, Any]:
            async with VirtualDojoClient(
                self._profile_name, timeout=self._timeout
            ) as client:
                return await client.post(path, data)

        return self._run_async(_post())

    def put(
        self, path: str, data: Optional[dict[str, Any]] = None
    ) -> dict[str, Any]:
        """Make a PUT request."""
        async def _put() -> dict[str, Any]:
            async with VirtualDojoClient(
                self._profile_name, timeout=self._timeout
            ) as client:
                return await client.put(path, data)

        return self._run_async(_put())

    def delete(self, path: str) -> dict[str, Any]:
        """Make a DELETE request."""
        async def _delete() -> dict[str, Any]:
            async with VirtualDojoClient(
                self._profile_name, timeout=self._timeout
            ) as client:
                return await client.delete(path)

        return self._run_async(_delete())
