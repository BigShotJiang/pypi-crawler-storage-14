import statistics
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

from agentops.utils.utils import safe_divide


@dataclass
class TestCaseEvaluationResult:
    """Class representing a single test case evaluation result."""

    name: str
    text_match: Optional[str] = None
    is_success: bool = False
    total_steps: float = 0
    llm_step: float = 0
    total_tool_calls: float = 0
    tool_call_precision: float = 0
    tool_call_recall: float = 0
    agent_routing_accuracy: float = 0
    avg_resp_time: float = 0
    failed_tool_calls: int = 0

    # Store any additional metrics not explicitly defined
    additional_metrics: Dict[str, Any] = field(default_factory=dict)

    def matches_count(self, match_value: str = "Summary Matched") -> int:
        """Check if this test case matches the specified value."""
        return 1 if self.text_match == match_value else 0

    def to_dict(self) -> Dict[str, Any]:
        """Convert the test case result to a dictionary."""
        result = {
            "dataset_name": self.name,
            "text_match": self.text_match,
            "is_success": self.is_success,
            "total_steps": self.total_steps,
            "llm_step": self.llm_step,
            "total_tool_calls": self.total_tool_calls,
            "tool_call_precision": self.tool_call_precision,
            "tool_call_recall": self.tool_call_recall,
            "agent_routing_accuracy": self.agent_routing_accuracy,
            "avg_resp_time": self.avg_resp_time,
            "failed_tool_calls": self.failed_tool_calls,
        }
        # Add any additional metrics
        result.update(self.additional_metrics)
        return result


@dataclass
class EvaluationResult:
    """Class representing a collection of test case evaluation results."""

    test_case_results: Dict[str, TestCaseEvaluationResult]

    @classmethod
    def from_csv(cls, data: List[Dict[str, Any]]) -> "EvaluationResult":
        """Create an EvaluationResult from CSV data."""
        results = {}
        for row in data:
            name = row["dataset_name"]

            # Extract standard fields
            standard_fields = {
                "name": name,
                "text_match": row.get("text_match"),
                "is_success": row.get("is_success", False),
                "total_steps": row.get("total_steps", 0),
                "llm_step": row.get("llm_step", 0),
                "total_tool_calls": row.get("total_tool_calls", 0),
                "tool_call_precision": row.get("tool_call_precision", 0),
                "tool_call_recall": row.get("tool_call_recall", 0),
                "agent_routing_accuracy": row.get("agent_routing_accuracy", 0),
                "avg_resp_time": row.get("avg_resp_time", 0),
                "failed_tool_calls": row.get("failed_tool_calls", 0),
            }

            # Extract additional fields not in the standard set
            additional_metrics = {}
            for key, value in row.items():
                if key not in standard_fields and key != "dataset_name":
                    additional_metrics[key] = value

            # Create the test case result
            result = TestCaseEvaluationResult(
                **standard_fields, additional_metrics=additional_metrics
            )
            results[name] = result

        return cls(results)

    def calculate_boolean_percent_true(
        self, values: List[bool]
    ) -> Dict[str, Any]:
        """Calculate statistics for boolean values."""
        return {
            "mean": sum(1 for v in values if v) / len(values) if values else 0,
            "count": len(values),
            "true_count": sum(1 for v in values if v),
            "false_count": sum(1 for v in values if not v),
        }

    def calculate_numeric_statistics(
        self, values: List[float]
    ) -> Dict[str, Any]:
        """Calculate statistics for numeric values."""
        try:
            stats = {
                "mean": statistics.mean(values),
                "median": statistics.median(values),
                "min": min(values),
                "max": max(values),
                "count": len(values),
            }
            if len(values) > 1:
                stats["std_dev"] = statistics.stdev(values)
            return stats
        except statistics.StatisticsError:
            # Handle empty lists or other statistical errors
            return {"error": "Could not compute statistics"}

    def compute_summary_statistics(self) -> Dict[str, Any]:
        """Compute summary statistics for all test cases."""
        stats = {}

        if not self.test_case_results:
            return stats

        # Get all fields from the first test case
        first_result = next(iter(self.test_case_results.values()))
        first_dict = first_result.to_dict()

        # Identify numeric and boolean columns
        for key, value in first_dict.items():
            if key == "dataset_name" or key == "text_match":
                continue

            # Collect values for this field from all test cases
            values = []
            for result in self.test_case_results.values():
                result_dict = result.to_dict()
                if key in result_dict:
                    values.append(result_dict[key])

            # Calculate statistics based on value type
            if values:
                if all(isinstance(v, bool) for v in values):
                    stats[key] = self.calculate_boolean_percent_true(values)
                elif all(isinstance(v, (int, float)) for v in values):
                    stats[key] = self.calculate_numeric_statistics(values)

        # Count summary matches
        match_count = sum(
            result.matches_count() for result in self.test_case_results.values()
        )
        stats["summary_matched_count"] = {
            "count": match_count,
            "percentage": (
                round(match_count / len(self.test_case_results) * 100, 2)
                if self.test_case_results
                else 0
            ),
        }

        return stats

    @property
    def test_count(self) -> int:
        """Get the total number of test cases."""
        return len(self.test_case_results)

    @property
    def summary_matched_count(self) -> int:
        """Get the count of summary matched test cases."""
        return sum(
            result.matches_count() for result in self.test_case_results.values()
        )

    @property
    def is_success_count(self) -> int:
        """Get the count of successful test cases."""
        return sum(
            1 for result in self.test_case_results.values() if result.is_success
        )

    def summary_match_ratio(self) -> float:
        """Calculate the ratio of summary matches to total tests."""
        return safe_divide(self.summary_matched_count, self.test_count)

    def is_success_ratio(self) -> float:
        """Calculate the ratio of successful tests to total tests."""
        return safe_divide(self.is_success_count, self.test_count)
