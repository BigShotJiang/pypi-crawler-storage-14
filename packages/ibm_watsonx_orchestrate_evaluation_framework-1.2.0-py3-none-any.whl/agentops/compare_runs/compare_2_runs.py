import csv
import os
import statistics
import sys
from collections import defaultdict
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional, Union

from jsonargparse import CLI

from agentops.arg_configs import CompareRunsConfig
from agentops.compare_runs.diff import DiffResults
from agentops.compare_runs.model import EvaluationResult
from agentops.utils.utils import create_table, read_file


def main(config: CompareRunsConfig):
    """Main function to compare two run result files."""
    # Extract values from config
    reference_file = config.reference_file_location
    experiment_file = config.experiment_file_location
    csv_output = config.csv_output
    column_stats_csv = config.column_stats_csv
    verbose = config.verbose

    try:
        # Read the files
        obj1 = read_file(reference_file)
        obj2 = read_file(experiment_file)

        # Create evaluation results
        result1 = EvaluationResult.from_csv(obj1)
        result2 = EvaluationResult.from_csv(obj2)

        # Create diff results
        diff_results = DiffResults(result1, result2)

        # Display summary statistics
        summary_stats = diff_results.summary_statistics()
        summary_table = create_table(summary_stats, title="Summary Statistics")
        print(
            "\nALL metrics are computed on OVERLAPPING test cases, ie cases that exist in both the Reference and Experiment runs\n"
        )
        print(
            "If Experiment - Reference is Positive, that's an increase in the metric. If Experiment - Reference is Negative, that's a decrease in the metric.\n"
        )
        summary_table.print()

        # Display exclusive tests
        if verbose:
            diff_results.display_exclusive_tests()

            # Display test cases with differing summary match and success status
            diff_results.display_differing_summary_matches()

        # Display tabular diff
        diff_results.compute_tabular_diff(verbose=verbose)

        # Write results to CSV if specified
        if csv_output:
            diff_results.to_csv(csv_output)

    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1

    return 0


if __name__ == "__main__":
    args = CLI(CompareRunsConfig, as_positional=False)
    sys.exit(main(args))

# Made with Bob
