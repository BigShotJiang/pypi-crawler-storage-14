# setups tracer for different agent frameworks

from dotenv import load_dotenv

load_dotenv()
import base64
import os

from opentelemetry.exporter.otlp.proto.http.trace_exporter import (
    OTLPSpanExporter,
)
from opentelemetry.sdk.trace.export import BatchSpanProcessor


def _setup_langfuse_sink():
    lf_public = os.getenv("LANGFUSE_PUBLIC_KEY")
    lf_secret = os.getenv("LANGFUSE_SECRET_KEY")
    lf_base_url = os.getenv("LANGFUSE_HOST").rstrip("/")
    if not lf_public or not lf_secret or not lf_base_url:
        raise RuntimeError(
            "Langfuse credentials missing. Please set LANGFUSE_PUBLIC_KEY, "
            "LANGFUSE_SECRET_KEY and LANGFUSE_HOST in the environment."
        )

    OTEL_ENDPOINT = f"{lf_base_url}/api/public/otel/v1/traces"
    auth_bytes = f"{lf_public}:{lf_secret}".encode("utf-8")
    auth_b64 = base64.b64encode(auth_bytes).decode("ascii")
    HEADERS = {"Authorization": f"Basic {auth_b64}"}
    return OTEL_ENDPOINT, HEADERS


def setup_langgraph_tracer():
    otel_endpoint, otel_headers = _setup_langfuse_sink()
    from phoenix.otel import register

    tracer_provider = register(
        endpoint=otel_endpoint, headers=otel_headers, auto_instrument=True
    )
    exporter = OTLPSpanExporter(endpoint=otel_endpoint, headers=otel_headers)
    tracer_provider.add_span_processor(BatchSpanProcessor(exporter))
    return tracer_provider


def setup_wxo_tracer():
    return setup_langgraph_tracer()


def setup_langflow_tracer():
    """Langflow starts a tracer on its own"""
    return None


def setup_pydantic_ai_tracer() -> None:
    otel_endpoint, otel_headers = _setup_langfuse_sink()
    from openinference.instrumentation.pydantic_ai import (
        OpenInferenceSpanProcessor,
    )
    from phoenix.otel import register

    tracer_provider = register(
        endpoint=otel_endpoint, headers=otel_headers, auto_instrument=True
    )
    tracer_provider.add_span_processor(OpenInferenceSpanProcessor())
    exporter = OTLPSpanExporter(endpoint=otel_endpoint, headers=otel_headers)
    tracer_provider.add_span_processor(BatchSpanProcessor(exporter))
    return tracer_provider


def setup_claude_agent_tracer():
    otel_endpoint, otel_headers = _setup_langfuse_sink()
    from dotenv import load_dotenv

    load_dotenv()
    import os

    from opentelemetry import context as otel_context
    from opentelemetry import trace
    from opentelemetry.sdk.trace import SpanProcessor, TracerProvider

    # Set environment variables for LangChain
    os.environ["LANGSMITH_OTEL_ENABLED"] = "true"
    os.environ["LANGSMITH_TRACING"] = "true"
    os.environ["LANGSMITH_OTEL_ONLY"] = "true"

    # Custom span processor to map session id to langfuse
    class LangsmithSessionToLangfuseProcessor(SpanProcessor):
        def on_start(self, span, parent_context=None):
            ctx = parent_context or otel_context.get_current()
            sess = ctx.get("session.id")
            if sess:
                span.set_attribute("session.id", sess)

    # Configure the OTLP exporter for your custom endpoint
    provider = TracerProvider()
    otlp_exporter = OTLPSpanExporter(
        endpoint=otel_endpoint, headers=otel_headers
    )
    processor = BatchSpanProcessor(otlp_exporter)
    provider.add_span_processor(LangsmithSessionToLangfuseProcessor())
    provider.add_span_processor(processor)
    trace.set_tracer_provider(provider)

    from langsmith.integrations.claude_agent_sdk import (
        configure_claude_agent_sdk,
    )

    configure_claude_agent_sdk()
