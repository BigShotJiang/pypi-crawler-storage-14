from dotenv import load_dotenv
from openinference.instrumentation import using_session

from agentops.arg_configs import ControllerConfig
from agentops.evaluation_controller.evaluation_controller import (
    EvaluationController,
)
from agentops.llm_user.base_user import BaseUserSimulator
from agentops.runtime_adapter.runtime_adapter import RuntimeAdapter
from agentops.runtime_adapter.wxo_runtime_adapter import WXORuntimeAdapter

load_dotenv()


class SimulationRunner:
    def __init__(
        self,
        user_agent: BaseUserSimulator,
        agent: RuntimeAdapter,
        config: ControllerConfig,
    ):
        self.evaluation_controller = EvaluationController(
            runtime=agent,
            llm_user=user_agent,
            config=config,
        )
        self.counter = 0

    def run_wrapper(self, session_id="session-id-test-00"):
        def run_task(*, item, **kwargs):
            """
            Task function for Langfuse experiment
            """
            new_session_id = session_id + "-" + self.counter.__str__()
            with using_session(new_session_id):
                input = item.input
                user_story = input.get("story")
                starting_sentence = input.get("starting_sentence")
                agent_name = input.get("agent")
                _, _, _, new_session_id = self.evaluation_controller.run(
                    self.counter,
                    agent_name=agent_name,
                    story=user_story,
                    starting_user_input=starting_sentence,
                    session_id=(
                        None
                        if isinstance(
                            self.evaluation_controller.runtime,
                            WXORuntimeAdapter,
                        )
                        else new_session_id
                    ),
                )
                self.counter += 1
            return new_session_id

        return run_task
