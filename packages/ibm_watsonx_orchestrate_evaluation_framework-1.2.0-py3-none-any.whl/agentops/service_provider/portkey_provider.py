from typing import Any, Dict, List, Optional, Sequence

from portkey_ai import Portkey

from agentops.service_provider.provider import Provider
from agentops.type import ChatCompletions, Choice, Message


class PortkeyProvider(Provider):
    """Provider that delegates to the Portkey AI client"""

    def __init__(
        self,
        provider: str,
        api_key: Optional[str] = None,
        model_id: Optional[str] = None,
        embedding_model: Optional[str] = None,
        base_url: Optional[str] = None,
        timeout: int = 60,
        system_prompt: Optional[str] = None,
        **kwargs,
    ) -> None:
        super().__init__()

        self.provider = provider
        self.api_key = api_key
        self.model_id = model_id
        self.embedding_model = embedding_model
        self.base_url = base_url
        self.timeout = timeout * 1000  # convert to ms
        self.system_prompt = system_prompt

        self._client = None
        if self.api_key is not None:
            client_kwargs = {
                "provider": self.provider,
                "Authorization": self.api_key,
            }
            if self.base_url:
                client_kwargs["base_url"] = base_url
            if self.timeout:
                client_kwargs["request_timeout"] = self.timeout

            client_kwargs.update(kwargs)
            self._client = Portkey(**client_kwargs)

    def _require_client(self) -> None:
        if self._client is None:
            raise ImportError(
                "portkey_ai client is not available. Install 'portkey_ai' and provide a valid api_key."
            )

    def chat(
        self,
        messages: Sequence[Dict[str, str]],
        params: Optional[Dict[str, Any]] = None,
    ) -> ChatCompletions:
        self._require_client()

        kwargs = {}
        if params:
            kwargs.update(params)

        resp = self._client.chat.completions.create(
            messages=messages, model=self.model_id, **kwargs
        )

        return ChatCompletions(
            choices=[
                Choice(
                    message=Message(
                        role=choice.message.role, content=choice.message.content
                    ),
                    finish_reason=choice.finish_reason,
                )
                for choice in resp.choices
            ],
            id=resp.id,
            model=resp.model,
        )

    def encode(self, sentences: List[str]) -> List[list]:
        if self.embedding_model is None:
            raise Exception(
                "embedding model id must be specified for text encoding"
            )

        self._require_client()

        try:
            resp = self._client.embeddings.create(
                inputs=sentences, model=self.embedding_model
            )
        except TypeError:
            resp = self._client.embeddings.create(
                inputs=sentences, model=self.embedding_model
            )

        if isinstance(resp, dict):
            if "data" in resp:
                return [d.get("embedding") for d in resp.get("data", [])]
            if "results" in resp:
                return [r.get("embedding") for r in resp.get("results", [])]

        if isinstance(resp, list):
            return resp

        try:
            return [list(e) for e in resp]
        except Exception:
            raise ValueError("Unexpected response from embeddings request")

    def old_query(self, sentence: str) -> str:
        pass

    def new_query(self, sentence: str) -> str:
        pass
