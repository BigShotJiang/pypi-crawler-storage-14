def simplified_argument_matching(expected, actual):
    if actual is None:
        return False
    for field in actual:
        if field not in expected:
            return False

    return True
