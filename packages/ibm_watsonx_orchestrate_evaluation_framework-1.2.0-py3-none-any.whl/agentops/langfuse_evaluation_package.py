from collections import defaultdict, deque
from typing import Any, Callable, Dict, List, Optional

import rich
from langfuse import get_client
from langfuse.experiment import ExperimentResult

from agentops.extractors import Extractor
from agentops.langfuse_collection import LangfuseCollection
from agentops.metrics import Evaluation
from agentops.metrics.journey_success import JourneySuccessMetric
from agentops.metrics.metrics import EvaluatorData
from agentops.metrics.tool_calling import ToolCalling
from agentops.otel_parser import parser as otel_parser
from agentops.type import (
    ExperimentResult,
    LangfuseDatasetModel,
    _convert_to_langfuse_format,
)
from agentops.utils import sync_langfuse_dataset

LANGFUSE_CLIENT = None


def default_aggregator(session_results: List[List[Evaluation]]):
    metric_names = [
        "journey_success",
        "total_tool_calls",
        "correct_tool_calls",
        "expected_tool_calls",
        "tool_calls_with_incorrect_parameter",
        "tool_call_recall",
        "tool_call_precision",
    ]
    group_metrics = defaultdict(list)

    for result in session_results:
        for metric in result:
            if metric["eval_name"] in metric_names:
                group_metrics[metric["eval_name"]].append(
                    {"value": metric["value"], "metadata": metric["metadata"]}
                )

    average_metric = []
    for metric_name, values in group_metrics.items():
        aggr = []
        for value in values:
            aggr.append(value.get("value"))

        metric_value = EvaluatorData(
            eval_name=f"Average_{metric_name}",
            value=round(sum(aggr) / len(aggr), 2),
            metadata=values[0]["metadata"],
        )
        average_metric.append(metric_value)

    return average_metric


class EvaluationRunner:
    def __init__(
        self,
        evaluation_name: str,
        run_name: str,
        session_ids: List[str],
        metrics: List[Evaluation],
        aggregator: Callable,
        collection: Optional[LangfuseCollection] = None,
        operator_configs: Dict[str, dict] = None,
    ):
        self.evaluation_name = evaluation_name
        self.run_name = run_name

        self.experiment_id = f"{self.evaluation_name}.{self.run_name}"

        self.collection = collection
        self.test_cases: List[LangfuseDatasetModel] = []

        if self.collection:
            client = (
                LANGFUSE_CLIENT
                if LANGFUSE_CLIENT is not None
                else self.collection.init_client()
            )
            langfuse_dataset = client.get_dataset(self.collection.name)
            for item in langfuse_dataset.items:
                data_model = _convert_to_langfuse_format(item)
                self.test_cases.append(data_model)

        self.session_ids = session_ids
        self.messages = [
            otel_parser.poll_messages(id) for id in self.session_ids
        ]

        if self.is_referenceless:
            assert len(self.session_ids) == len(self.messages)
        else:
            assert (
                len(self.session_ids)
                == len(self.messages)
                == len(self.test_cases)
            )

        self.metrics = metrics
        self.aggregator = aggregator
        self.operator_configs = operator_configs

    @property
    def is_referenceless(self):
        return self.collection is None

    @classmethod
    def _gather(cls, nodes):
        """Extract all the `operators` for the provided metrics.

        Here `operators` means either an evaluator or extractor.
        A `metric` may depend on another `extractor` or `evaluator`.
        We first gather all the dependencies that each metric and it's dependencies rely on.

        Return:
        - We return a mapping between the operator and the object.
        For example:
        {
            "Journey Success": journey_success,
            "Expected Tool Extractor": expected_tool_call_extractor
        }
        """

        op_mapping = {}

        while nodes:
            curr_node = nodes.pop()
            if curr_node.__class__.__name__ not in op_mapping:
                op_mapping[curr_node.__class__.__name__] = curr_node

            for deps in curr_node.dependencies:
                if deps.__class__.__name__ not in op_mapping:
                    nodes.append(deps)

        return op_mapping

    @classmethod
    def _scheduler(cls, metrics):
        op_mapping = cls._gather(nodes=metrics)

        eval_dag = defaultdict(list)
        in_degree = defaultdict(int)
        for op in op_mapping.values():
            for dependency in op.dependencies:
                eval_dag[dependency.__class__.__name__].append(
                    op.__class__.__name__
                )
                in_degree[op.__class__.__name__] += 1

            if op.__class__.__name__ not in in_degree:
                in_degree[op.__class__.__name__] = 0

        ordering = []
        queue = deque(
            [op for op, num_deps in in_degree.items() if num_deps == 0]
        )

        while queue:
            op = queue.popleft()
            ordering.append(op)

            for operator in eval_dag[op]:
                in_degree[operator] -= 1
                if in_degree[operator] == 0:
                    queue.append(operator)

        ordering = {op: op_mapping.get(op) for op in ordering}
        rich.print(
            "Executing the following operations: ", list(ordering.keys())
        )
        return ordering

    def evaluate(self):
        schedule = self._scheduler(metrics=self.metrics)
        metadata = {"experiment_id": self.experiment_id}
        total_metrics = []

        if self.is_referenceless:
            evaluation_items = self.messages
        else:
            evaluation_items = self.test_cases

        for idx, item in enumerate(evaluation_items):
            messages = self.messages[idx]
            context = {"extractor": {}, "metric": {}}

            ground_truth = None if self.is_referenceless else item

            for operator in schedule.values():
                if self.operator_configs is not None:
                    operator.config = self.operator_configs.get(
                        operator.__class__.__name__
                    )
                else:
                    operator.config = None
                if isinstance(operator, Evaluation):
                    context = operator.evaluate(
                        messages=messages,
                        ground_truth=ground_truth,
                        extracted_context=context,
                        metadata=metadata,
                    )
                if isinstance(operator, Extractor):
                    context = operator.extract(
                        messages=messages,
                        ground_truth=ground_truth,
                        extracted_context=context,
                        metadata=metadata,
                    )

            metrics = context.get("metric")
            metric_results = []

            for outputs in metrics.values():
                for output in outputs:
                    metric_results.append(output.model_dump())
                    sync_langfuse_dataset(
                        name=output.eval_name,
                        session_id=self.session_ids[idx],
                        value=output.value,
                        data_type=output.data_type,
                        metadata=output.metadata,
                    )

            total_metrics.append(metric_results)

        aggregate_metrics = self.aggregator(total_metrics)
        for metric in aggregate_metrics:
            sync_langfuse_dataset(
                name=metric.eval_name,
                value=metric.value,
                metadata=metric.metadata,
                data_type="NUMERIC",
                dataset_run_id=metric.metadata["experiment_id"],
            )

        return ExperimentResult(
            experiment_name=self.evaluation_name,
            run_id=self.run_name,
            experiment_id=self.experiment_id,
            metrics=total_metrics,
            session_ids=self.session_ids,
            aggregate_metrics=aggregate_metrics,
        )


if __name__ == "__main__":
    from argparse import ArgumentParser

    parser = ArgumentParser()
    parser.add_argument("--collection_name", "-c", required=False, type=str)
    parser.add_argument("--session_ids", "-s", nargs="+", required=True)

    args = parser.parse_args()

    collection_name = args.collection_name
    langfuse_collection = LangfuseCollection(name=collection_name)
    journey_sucess_metric = JourneySuccessMetric()
    tool_calling = ToolCalling()

    operator_configs = {
        "ExpectedToolExtractor": {"parameter": 10},
        "ExtractLabeledMessages": {"parameter": "default"},
        "JourneySuccessMetric": {"is_strict": False},
    }

    run = EvaluationRunner(
        evaluation_name="sample_evaluation",
        run_name="1",
        session_ids=args.session_ids,
        collection=langfuse_collection,
        metrics=[tool_calling, journey_sucess_metric],
        aggregator=default_aggregator,
        operator_configs=operator_configs,
    )

    experiment_results = run.evaluate()

    rich.print("----- Experiment Results ---- ")
    rich.print(experiment_results)
    rich.print("----------------------------- ")
