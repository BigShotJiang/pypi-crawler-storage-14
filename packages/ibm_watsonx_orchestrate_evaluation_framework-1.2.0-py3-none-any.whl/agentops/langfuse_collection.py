import json
from typing import List, Mapping, Union

import rich
from langfuse._client.datasets import DatasetItemClient
from langfuse.api.core.api_error import ApiError

from agentops.type import (
    GoalDetail,
    LangfuseCollectionModel,
    LangfuseDatasetModel,
    _convert_to_langfuse_format,
)


class LangfuseCollection:
    def __init__(self, name, description="", metadata: Mapping[str, str] = {}):
        self.name = name
        self.description = description
        self.metadata = metadata

    def init_client(self):
        from langfuse import get_client

        return get_client()

    def get_data_items(self) -> List[DatasetItemClient]:
        langfuse_client = self.init_client()
        dataset = langfuse_client.get_dataset(self.name)
        return dataset.items

    def upload(self, paths: Union[str, List[str]], overwrite: bool = False):
        langfuse_client = self.init_client()

        datasets = []
        if isinstance(paths, str):
            paths = [paths]

        for path in paths:
            with open(path, encoding="utf-8") as f:
                dataset = json.load(f)
                dataset = LangfuseDatasetModel(
                    starting_sentence=dataset.get("starting_sentence", ""),
                    story=dataset.get("story", ""),
                    goals=dataset.get("goals"),
                    goal_details=dataset.get("goal_details"),
                    agent=dataset.get("agent"),
                )
                datasets.append(dataset)

        collection = LangfuseCollectionModel(
            collection_name=self.name,
            collection_description=self.description,
            datasets=datasets,
            metadata=self.metadata,
        )

        rich.print(
            f"[g]Uploading {len(collection.datasets)} datasets to '{collection.collection_name}'"
        )
        langfuse_client.create_dataset(
            name=collection.collection_name,
            description=collection.collection_description,
            metadata=collection.metadata,
        )

        available_datasets = [
            _convert_to_langfuse_format(item) for item in self.get_data_items()
        ]
        for dataset in collection.datasets:
            if (not overwrite) and dataset in available_datasets:
                rich.print(
                    f"[g]Skipping upload! Dataset already available in collection '{collection.collection_name}'"
                )
                continue
            langfuse_client.create_dataset_item(
                dataset_name=collection.collection_name,
                input=dataset.langfuse_input,
                expected_output=dataset.langfuse_output,
            )

    def delete_item(self, item_id):
        """
        Deletes a single item given its id
        """
        langfuse_client = self.init_client()
        langfuse_client.api.dataset_items.delete(id=item_id)
        rich.print(f"[g]Deleted item {item_id} from '{self.name}'")

    def delete_all_items(self):
        """
        Deletes all items in the collection
        """
        try:
            items = self.get_data_items()
        except ApiError as e:
            if (
                e.status_code == 404
                and e.body["message"] == "Dataset not found"
            ):
                rich.print(
                    "[r]Dataset not found. No delete operation performed."
                )
                items = []
            else:
                # re-raise exception if the error is something other than dataset not found
                raise e

        n_items = 0
        for item in items:
            self.delete_item(item.id)
            n_items += 1
        rich.print(f"[g]Deleted {n_items} datasets from '{self.name}'")
