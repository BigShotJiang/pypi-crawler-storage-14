from dotenv import load_dotenv

load_dotenv()

import time
from collections import defaultdict
from functools import partial
from typing import Any, Dict, List, Optional

import rich
from langfuse import get_client

langfuse_client = None

from agentops.type import Message

from . import langflow_parser, langgraph_parser, pydantic_parser, wxo_parser


def poll_messages(session_id, timeout=10, poll_interval=2):
    start_time = time.time()

    while True:
        messages = parse_session(session_id)

        if len(messages) > 0:
            return messages

        elapsed_time = time.time() - start_time
        if elapsed_time >= timeout:
            rich.print("[r] Timeout reached, messages not available yet.[r]")
            return []

        time.sleep(poll_interval)


def parse_session(session_id):
    traces = get_traces(session_id)
    messages: list[Message] = []
    for tr in traces.data:
        trace_messages = parse_trace(tr)
        messages = add_messages(messages, trace_messages)
    return messages


def parse_trace(trace):
    messages: list[Message] = []
    agent_framework = get_agent_framework(trace)
    if agent_framework == "langfuse.langgraph_agent":
        parser_func = langgraph_parser.parse_observations
    elif agent_framework == "langfuse.langflow":
        parser_func = partial(
            langflow_parser.parse_observations, dfs_callable=dfs_
        )
    elif agent_framework == "langgraph_agent":
        parser_func = langgraph_parser.parse_observations
    elif agent_framework == "pydantic_ai":
        parser_func = pydantic_parser.parse_observations
        sys_message = pydantic_parser.get_system_message(trace)
        if sys_message:
            messages.append(sys_message)
    else:
        parser_func = None
        parsers_to_try = [
            partial(langflow_parser.parse_observations, dfs_callable=dfs_),
            wxo_parser.parse_observations,
        ]
    observations = get_observations(trace.observations)
    dfs_observations = dfs_(observations)
    if parser_func:
        parsed_messages = parser_func(observations, dfs_observations)
        messages = add_messages(messages, parsed_messages)
    else:
        for parser_func in parsers_to_try:
            try:
                parsed_messages = parser_func(observations, dfs_observations)
                if not parsed_messages:
                    continue
                messages = add_messages(messages, parsed_messages)
                break
            except Exception as e:
                print(e)
    return messages


def add_messages(messages: list[Message], parsed_messages: list[Message]):
    ret: list[Message] = []
    seen: set[str] = set()
    for msg in messages:
        msg_hash = msg.hash()
        if msg_hash in seen:
            continue
        seen.add(msg_hash)
        ret.append(msg)
    for msg in parsed_messages:
        msg_hash = msg.hash()
        if msg_hash in seen:
            continue
        seen.add(msg_hash)
        ret.append(msg)
    return ret


def get_agent_framework(trace):
    """
    Supported frameworks:
    - OpenInference
        - Pydantic AI
        - Langflow
        - Langgraph Agent
    - LangFuse
        - Langflow
        - LangGraph Agent
    """
    md_attrs = trace.metadata.get("attributes", {})
    scope = trace.metadata.get("scope", {})
    scope_name = scope.get("name", "")

    if scope_name == "langfuse-sdk":
        if trace.name == "LangGraph":
            return "langfuse.langgraph_agent"

    if "langflow.project.name" in md_attrs.keys():
        return "langflow"
    if "pydantic-ai" in scope_name:
        return "pydantic_ai"
    if "openinference.instrumentation.langchain" in scope_name:
        # TODO: need to find a better way to detect Langgraph Agent
        return "langgraph_agent"

    # check for langflow
    # get observations for trace
    observations = dfs_(get_observations(trace.observations))
    for obs in observations:
        if "from_langflow_component" in obs.obs.metadata.keys():
            return "langfuse.langflow"
    return "UNKNOWN"


def get_traces(session_id):
    client = langfuse_client if langfuse_client is not None else get_client()
    traces = client.api.trace.list(
        session_id=session_id,
        limit=100,
    )
    # sort by timestamp
    traces.data.sort(key=lambda x: x.timestamp)
    return traces


def get_observations(observations_ids):
    client = langfuse_client if langfuse_client is not None else get_client()
    observations = [
        client.api.observations.get(obs_id) for obs_id in observations_ids
    ]
    observations.sort(key=lambda x: x.start_time)
    observation_tree = build_observation_forest(observations)
    return observation_tree


class ObsNode:
    def __init__(self, obs: Any):
        self.obs = obs
        self.children: List["ObsNode"] = []
        self.parent: Optional["ObsNode"] = None

    def __repr__(self):
        return f"ObsNode(id={self.obs.id}, type={self.obs.type}, name={self.obs.name})"


def build_observation_forest(observations: List[Any]) -> List[ObsNode]:
    """Return list of root nodes; each has .children forming a tree."""
    nodes: Dict[str, ObsNode] = {}
    children_by_parent: Dict[Optional[str], List[ObsNode]] = defaultdict(list)

    # 1. Create nodes for each observation
    for o in observations:
        node = ObsNode(o)
        nodes[o.id] = node
        parent_id = getattr(o, "parent_observation_id", None)
        children_by_parent[parent_id].append(node)

    # 2. Attach children to parents
    for parent_id, child_nodes in children_by_parent.items():
        if parent_id is None:
            continue
        parent_node = nodes.get(parent_id)
        if parent_node:
            parent_node.children.extend(child_nodes)
            for child_node in child_nodes:
                child_node.parent = parent_node

    # 3. Roots are those with parent_observation_id == None
    roots = children_by_parent[None]
    return roots


def dfs_(observation_tree: List[ObsNode]):
    ret = []
    for node in observation_tree:
        ret.append(node)
        ret.extend(dfs_(node.children))
    return ret


if __name__ == "__main__":
    messages = poll_messages(session_id="93a24957-dd7a-425d-b821-88de49940a6e")

    print(messages)
