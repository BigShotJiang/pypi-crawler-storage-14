from agentops.otel_parser import parser as otel_parser
