import json

from agentops.type import ContentType, Function, Message, ToolCall


def get_system_message(trace):
    sys_instruction_json = trace.metadata.get("attributes", {}).get(
        "gen_ai.system_instructions"
    )
    if not sys_instruction_json:
        return None
    instruction = json.loads(sys_instruction_json)[0]["content"]
    return Message(role="system", content=instruction, type=ContentType.text)


def parse_observations(observation_tree, dfs_observations):
    messages = []
    for obs in dfs_observations:
        if obs.obs.type == "GENERATION":
            messages.extend(_get_messages(obs.obs.input))
            messages.extend(_get_messages(obs.obs.output))
    return messages


def _get_messages(data):
    messages = []
    for msg in data:
        if msg["role"] == "user":
            parts = msg["parts"]
            for part in parts:
                content_type = part["type"]
                if content_type == "text":
                    content = part["content"]
                    messages.append(
                        Message(
                            role="user", content=content, type=ContentType.text
                        )
                    )
                elif content_type == "tool_call_response":
                    tool_call_id = part["id"]
                    result = json.dumps(part["result"])
                    messages.append(
                        Message(
                            role="tool",
                            tool_call_id=tool_call_id,
                            content=result,
                            type=ContentType.tool_response,
                        )
                    )
        elif msg["role"] == "assistant":
            parts = msg["parts"]
            # TODO: assuming that only one message is present in the assistant parts
            content_type = parts[0]["type"]
            if content_type == "text":
                content = parts[0]["content"]
                messages.append(
                    Message(
                        role="assistant", content=content, type=ContentType.text
                    )
                )
            elif content_type == "tool_call":
                tool_calls = []
                for part in parts:
                    tool_call_id = part["id"]
                    tool_call_name = part["name"]
                    tool_call_arguments = part["arguments"]
                    tool_call = ToolCall(
                        id=tool_call_id,
                        function=Function(
                            name=tool_call_name, arguments=tool_call_arguments
                        ),
                    )
                    tool_calls.append(tool_call)
                messages.append(
                    Message(
                        role="assistant",
                        content="",
                        tool_calls=tool_calls,
                        type=ContentType.tool_call,
                    )
                )
    return messages
