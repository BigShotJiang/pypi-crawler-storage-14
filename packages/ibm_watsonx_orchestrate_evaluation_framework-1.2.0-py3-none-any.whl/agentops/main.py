import json
import os
import pathlib
from dataclasses import asdict
from datetime import datetime
from pathlib import Path

import yaml
from jsonargparse import CLI

from agentops.arg_configs import TestConfig
from agentops.clients import bootstrap_clients
from agentops.langfuse_collection import LangfuseCollection
from agentops.langfuse_evaluation_package import (
    EvaluationRunner,
    default_aggregator,
)
from agentops.metrics.journey_success import JourneySuccessMetric
from agentops.metrics.metrics import extract_metrics, format_metrics_for_display
from agentops.metrics.tool_calling import ToolCalling
from agentops.runner import process_test_case
from agentops.scheduler import (
    discover_tests,
    enumerate_jobs,
    filter_tests,
    run_jobs,
)
from agentops.utils.utils import SummaryPanel, create_table, csv_dump


def main(config: TestConfig):
    # setup
    clients = bootstrap_clients(config)
    if not getattr(config, "skip_available_results", False):
        ts = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
        config.output_dir = os.path.join(config.output_dir, ts)

    if not config.skip_legacy_evaluation:
        knowledge_base_output_folder = (
            Path(config.output_dir) / "knowledge_base_metrics"
        )
        knowledge_base_output_folder.mkdir(exist_ok=True, parents=True)
        detailed_rag_output_file = (
            knowledge_base_output_folder
            / "knowledge_base_detailed_metrics.json"
        )
        summary_rag_output_file = (
            Path(config.output_dir) / "knowledge_base_summary_metrics.json"
        )
        os.makedirs(os.path.join(config.output_dir, "messages"), exist_ok=True)

    # discover & schedule tests
    test_cases = discover_tests(
        config.test_paths, config.enable_recursive_search
    )
    # see if there are tags specified in config and filter on them
    filtered_test_cases = filter_tests(test_cases, config.tags)

    jobs = enumerate_jobs(
        filtered_test_cases,
        config.n_runs,
        config.skip_available_results,
        config.output_dir,
    )
    results = run_jobs(
        jobs, config, clients, process_test_case, config.num_workers
    )

    # extract
    tool_metrics, kb_summary, custom_metrics = extract_metrics(results)

    if not config.skip_legacy_evaluation:
        # write results
        csv_dump(
            pathlib.Path(config.output_dir) / "summary_metrics.csv",
            rows=[metric.model_dump() for metric in tool_metrics],
        )
        for file_path, key in [
            (detailed_rag_output_file, "detailed"),
            (summary_rag_output_file, "summary"),
        ]:
            with open(file_path, "w+", encoding="utf-8") as f:
                json.dump(
                    kb_summary.model_dump(by_alias=True)[key], f, indent=4
                )

        # print results
        SummaryPanel(kb_summary).print()
        tool_table = create_table(
            format_metrics_for_display(tool_metrics), title="Agent Metrics"
        )
        if tool_table:
            tool_table.print()
        if any(cm.custom_metrics for cm in custom_metrics):
            rows = []
            for cm in custom_metrics:
                row = {"dataset_name": cm.dataset_name}
                for m in cm.custom_metrics:
                    row[m.eval_name] = str(
                        m.value
                    )  # Convert to string to avoid type issues
                rows.append(row)
            custom_metrics_table = create_table(rows, title="Custom Metrics")
            if custom_metrics_table:
                custom_metrics_table.print()
    else:
        collection_name = config.collection_name
        collection = LangfuseCollection(
            name=collection_name,
            description="",
        )
        dataset_paths = []
        session_ids = []
        for test_case in test_cases:
            name = os.path.basename(test_case).replace(".json", "")
            with open(
                os.path.join(config.output_dir, f"{name}.metadata.json"), "r"
            ) as f:
                metadata = json.load(f)
            session_id = metadata["thread_id"]
            dataset_paths.append(test_case)
            session_ids.append(session_id)

        collection.delete_all_items()
        collection.upload(paths=dataset_paths)

        journey_sucess_metric = JourneySuccessMetric(config=asdict(config))
        tool_calling = ToolCalling()

        run = EvaluationRunner(
            evaluation_name=os.path.basename(config.output_dir) + "_evaluation",
            run_name=os.path.basename(config.output_dir) + "_run",
            session_ids=session_ids,
            collection=collection,
            metrics=[journey_sucess_metric, tool_calling],
            aggregator=default_aggregator,
            operator_configs=config.operator_configs,
        )

        evaluation_results = run.evaluate()
        collection.delete_all_items()

    # persist config
    with open(
        pathlib.Path(config.output_dir) / "config.yml", "w", encoding="utf-8"
    ) as f:
        yaml.safe_dump(asdict(config), f)

    if not config.skip_legacy_evaluation:
        print(f"Results saved to {config.output_dir}")
    else:
        print(f"Config and metadata saved to {config.output_dir}")
        print(
            f"Langfuse Evaluation run completed for collection {collection_name}:"
        )
        for session_id in session_ids:
            print(
                f" - http://localhost:3010/project/orchestrate-lite/sessions/{session_id}"
            )


if __name__ == "__main__":
    main(CLI(TestConfig, as_positional=False))
