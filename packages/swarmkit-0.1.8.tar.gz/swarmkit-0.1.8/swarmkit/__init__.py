"""SwarmKit Python SDK - Pythonic wrapper around the TypeScript SwarmKit SDK."""

from .agent import SwarmKit
from .config import (
    AgentConfig,
    E2BProvider,
    SandboxProvider,
    AgentType,
    ModelProvider,
    WorkspaceMode,
    ReasoningEffort,
)
from .events import (
    Event,
    StdoutEvent,
    StderrEvent,
    UpdateEvent,
    ErrorEvent,
    CompleteEvent,
)
from .results import (
    ExecuteResult,
    OutputFile,
)
from .bridge import (
    SandboxNotFoundError,
    BridgeConnectionError,
    BridgeBuildError,
)

__version__ = '0.1.8'

__all__ = [
    # Main class
    'SwarmKit',

    # Configuration
    'AgentConfig',
    'E2BProvider',
    'SandboxProvider',
    'AgentType',
    'ModelProvider',
    'WorkspaceMode',
    'ReasoningEffort',

    # Events
    'Event',
    'StdoutEvent',
    'StderrEvent',
    'UpdateEvent',
    'ErrorEvent',
    'CompleteEvent',

    # Results
    'ExecuteResult',
    'OutputFile',

    # Exceptions
    'SandboxNotFoundError',
    'BridgeConnectionError',
    'BridgeBuildError',
]
