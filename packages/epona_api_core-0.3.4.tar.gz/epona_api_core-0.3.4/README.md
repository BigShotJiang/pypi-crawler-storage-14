# api-core
Funcionalidades comums de API da Epona Consultoria.
