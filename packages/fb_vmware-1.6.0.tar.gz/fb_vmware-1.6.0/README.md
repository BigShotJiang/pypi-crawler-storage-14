# fb-vmware
A Python wrapper module around the pyvmomi module to simplify work and handling.
