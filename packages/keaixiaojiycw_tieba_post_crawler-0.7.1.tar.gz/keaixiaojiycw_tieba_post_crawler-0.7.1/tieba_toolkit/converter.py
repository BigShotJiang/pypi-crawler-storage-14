# -*- coding: utf-8 -*-
import json
import sys
import os
from pathlib import Path
from typing import Dict, Any, List, Optional

# 导入共享工具函数
# 确保您的 tieba_toolkit 目录下有 utils.py 且包含这些定义
try:
    from .utils import load_checkpoint, THREAD_ROOT, THREAD_INDEX_JSON
except ImportError:
    # 兼容直接运行此脚本的情况（虽然不推荐）
    THREAD_ROOT = Path("threads")
    THREAD_INDEX_JSON = THREAD_ROOT / "index.json"
    def load_checkpoint(tid): return {"last_page": 0, "seen_pids": []}

# ==============================================================================
# CSS 样式 (Apple 风格)
# ==============================================================================

NEW_CSS_STYLE = """
<style>
:root {
    --grid-unit: 8px;
    --radius-superellipse: 14px;
    --color-apple-blue: #007aff;
    --bg-color: #f5f5f7;
    --card-bg: #ffffff;
    --text-primary: #1d1d1f;
    --text-secondary: #86868b;
}
body {
    background-color: var(--bg-color);
    font-family: -apple-system, "SF Pro Text", "Helvetica Neue", "PingFang SC", sans-serif;
    color: var(--text-primary);
    padding: calc(var(--grid-unit) * 4);
    margin: 0;
    display: flex;
    justify-content: center;
    line-height: 1.6;
}
.thread-viewer-container {
    max-width: 750px;
    width: 100%;
    background-color: var(--card-bg);
    border-radius: var(--radius-superellipse);
    padding: calc(var(--grid-unit) * 4);
    box-shadow: 0 4px 24px rgba(0,0,0,0.04);
}
.thread-header {
    margin-bottom: 32px;
    border-bottom: 1px solid rgba(0,0,0,0.1);
    padding-bottom: 16px;
}
.thread-header h1 {
    font-size: 28px;
    font-weight: 700;
    margin: 0 0 8px 0;
    letter-spacing: -0.01em;
}
.thread-meta {
    font-size: 13px;
    color: var(--text-secondary);
    display: flex;
    gap: 16px;
}
.post {
    margin-bottom: 24px;
    padding-bottom: 24px;
    border-bottom: 1px solid rgba(0,0,0,0.05);
    animation: fadeIn 0.5s ease;
}
@keyframes fadeIn { from { opacity: 0; transform: translateY(10px); } to { opacity: 1; transform: translateY(0); } }
.user-info {
    display: flex;
    align-items: center;
    margin-bottom: 12px;
}
.user-name {
    font-weight: 600;
    font-size: 15px;
    color: #333;
    margin-right: 8px;
}
.user-role {
    font-size: 11px;
    padding: 2px 6px;
    background: #e67e22;
    color: white;
    border-radius: 4px;
}
.post-content p {
    margin: 8px 0;
    font-size: 16px;
    text-align: justify;
}
.image-container img {
    max-width: 100%;
    border-radius: 8px;
    margin: 8px 0;
    box-shadow: 0 2px 8px rgba(0,0,0,0.05);
}
.post-meta {
    margin-top: 12px;
    font-size: 12px;
    color: #999;
    display: flex;
    justify-content: space-between;
}
.pagination-controls {
    display: flex;
    justify-content: center;
    gap: 8px;
    margin-top: 40px;
    padding-top: 20px;
    border-top: 1px solid #eee;
}
.page-btn {
    padding: 6px 12px;
    border: 1px solid #e5e5e5;
    background: white;
    border-radius: 6px;
    cursor: pointer;
    color: var(--text-primary);
    transition: all 0.2s;
}
.page-btn:hover { background: #f5f5f5; }
.page-btn:disabled { opacity: 0.5; cursor: not-allowed; }
</style>
"""

# ==============================================================================
# JavaScript 逻辑 (修正版：移除了导致错误的转义符)
# ==============================================================================

def _generate_js_logic() -> str:
    # 注意：这里使用的是普通字符串，不需要转义反引号 ` 和 ${}
    return """
    const POST_LIST = document.getElementById('post-list');
    const PAG_CONTAINER = document.getElementById('pagination-container');
    const PAGE_INFO = document.getElementById('page-info');
    let METADATA = { start_page: 1, end_page: 1, max_page: 1 };
    let CURRENT_PAGE = 1;

    async function init() {
        try {
            // 加载 metadata.json
            const resp = await fetch('./metadata.json'); 
            if(!resp.ok) throw new Error("Metadata not found");
            METADATA = await resp.json();
            
            document.title = METADATA.title;
            document.getElementById('thread-title').textContent = METADATA.title;
            
            // 更新 TID 显示
            document.querySelector('.thread-meta span:first-child').textContent = `TID: ${METADATA.tid}`;
            
            loadPage(METADATA.start_page);
        } catch(e) {
            console.error(e);
            POST_LIST.innerHTML = `<p style='color:red;text-align:center;'>初始化失败: ${e.message}<br>请确保在 threads/${METADATA.tid || 'TID'}/ 目录下运行 HTTP 服务器。</p>`;
        }
    }

    async function loadPage(page) {
        if(page < METADATA.start_page || page > METADATA.end_page) return;
        CURRENT_PAGE = page;
        POST_LIST.innerHTML = '<p style="text-align:center;color:#999">正在加载...</p>';
        updateUI();

        // 构建 JSON 路径：posts/page_0001.json
        const jsonPath = METADATA.data_path_template.replace('{page_num:04d}', String(page).padStart(4, '0'));
        try {
            const resp = await fetch(jsonPath); 
            if(!resp.ok) throw new Error(`HTTP ${resp.status}`);
            const data = await resp.json();
            renderPosts(data);
        } catch(e) {
            POST_LIST.innerHTML = `<p style='color:red;text-align:center;'>加载第 ${page} 页失败: ${e.message}</p>`;
        }
        updateUI();
    }

    function renderPosts(posts) {
        POST_LIST.innerHTML = '';
        posts.forEach(post => {
            if(post.is_comment) return; 
            
            const article = document.createElement('article');
            article.className = 'post';
            
            // 构建用户信息
            let html = `<div class="user-info">
                <span class="user-name">${post.user_name || '未知'}</span>
                ${post.floor === 1 ? '<span class="user-role">楼主</span>' : ''}
            </div>`;
            
            // 构建正文
            html += `<div class="post-content">`;
            if(post.text) html += post.text.split('\\n').map(p=>`<p>${p}</p>`).join('');
            
            // 构建图片
            if(post.image_links && post.image_links.length) {
                html += `<div class="image-container">`;
                post.image_links.forEach(src => {
                    // 处理路径：确保使用本地 images/ 目录
                    // 假设 crawler 生成的链接包含 'images/' 前缀，或者我们只取文件名
                    const filename = src.split('/').pop();
                    const imagePath = `images/${filename}`; 
                    html += `<img src="${imagePath}" loading="lazy" alt="贴吧图片">`;
                });
                html += `</div>`;
            }
            html += `</div>`;
            
            // 构建底部信息
            html += `<div class="post-meta">
                <span>#${post.floor}</span>
                <span>${new Date(post.time * 1000).toLocaleString()}</span>
            </div>`;
            
            article.innerHTML = html;
            POST_LIST.appendChild(article);
        });
    }

    function updateUI() {
        PAGE_INFO.textContent = `第 ${CURRENT_PAGE} 页 / 共 ${METADATA.max_page} 页`;
        PAG_CONTAINER.innerHTML = '';
        
        const prev = document.createElement('button');
        prev.className = 'page-btn';
        prev.textContent = '上一页';
        prev.disabled = CURRENT_PAGE <= METADATA.start_page;
        prev.onclick = () => loadPage(CURRENT_PAGE - 1);
        
        const next = document.createElement('button');
        next.className = 'page-btn';
        next.textContent = '下一页';
        next.disabled = CURRENT_PAGE >= METADATA.end_page;
        next.onclick = () => loadPage(CURRENT_PAGE + 1);
        
        PAG_CONTAINER.append(prev, next);
    }

    window.onload = init;
    """

# ==============================================================================
# HTML 模板容器
# ==============================================================================

HTML_TEMPLATE = """
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{{THREAD_TITLE}}</title>
    {{CSS_STYLE}}
</head>
<body>
    <div class="thread-viewer-container">
        <header class="thread-header">
            <h1 id="thread-title">{{THREAD_TITLE}}</h1>
            <div class="thread-meta">
                <span>TID: {{THREAD_ID}}</span>
                <span id="page-info">加载中...</span>
            </div>
        </header>
        <main id="post-list"></main>
        <footer id="pagination-container" class="pagination-controls"></footer>
    </div>
    <script>
    {{JS_CODE}}
    </script>
</body>
</html>
"""

# ==============================================================================
# 辅助函数 (数据加载)
# ==============================================================================

def load_posts_data(tid: int, start: int, end: int) -> List[Dict]:
    """加载 JSON 数据 (用于 LLM 转换)"""
    data = []
    for i in range(start, end + 1):
        f = THREAD_ROOT / str(tid) / "posts" / f"page_{i:04d}.json"
        if f.exists():
            try:
                data.extend(json.load(open(f, 'r', encoding='utf-8')))
            except:
                pass
    return data

# ==============================================================================
# 核心转换逻辑
# ==============================================================================

def generate_html(tid: int, title: str, start: int, end: int, max_page: int):
    """生成 HTML 查看器"""
    tid_dir = THREAD_ROOT / str(tid)
    meta_file = tid_dir / "metadata.json"
    out_file = tid_dir / f"{tid}_view_{start}_{end}.html"
    
    # 1. 写入 metadata.json
    meta = {
        "title": title,
        "tid": tid,
        "max_page": max_page,
        "start_page": start,
        "end_page": end,
        "data_path_template": "posts/page_{page_num:04d}.json"
    }
    tid_dir.mkdir(parents=True, exist_ok=True)
    with open(meta_file, 'w', encoding='utf-8') as f:
        json.dump(meta, f, indent=2, ensure_ascii=False)
        
    # 2. 写入 HTML
    html = HTML_TEMPLATE.replace("{{THREAD_TITLE}}", title)
    html = html.replace("{{THREAD_ID}}", str(tid))
    html = html.replace("{{CSS_STYLE}}", NEW_CSS_STYLE)
    html = html.replace("{{JS_CODE}}", _generate_js_logic())
    
    with open(out_file, 'w', encoding='utf-8') as f:
        f.write(html)
        
    print(f"✅ HTML 生成完毕: {out_file}")
    print(f"👉 请在目录下运行 `python -m http.server` 并在浏览器访问该文件。")

def generate_llm(tid: int, title: str, start: int, end: int):
    """生成 LLM 训练数据"""
    data = load_posts_data(tid, start, end)
    out_file = THREAD_ROOT / str(tid) / f"{tid}_llm_training.jsonl"
    
    count = 0
    (THREAD_ROOT / str(tid)).mkdir(parents=True, exist_ok=True)
    
    with open(out_file, 'w', encoding='utf-8') as f:
        for item in data:
            if not item.get('text'): continue
            
            row = {
                "instruction": f"用户 {item.get('user_name')} 在帖子 '{title}' 中说了什么？",
                "input": "",
                "output": item.get('text')
            }
            f.write(json.dumps(row, ensure_ascii=False) + "\n")
            count += 1
            
    print(f"✅ LLM 数据生成完毕: {out_file} (共 {count} 条)")

# ==============================================================================
# CLI 入口
# ==============================================================================

def convert_thread(tid: int, convert_type: str, start_page: int = 1, end_page: int = None):
    # 1. 尝试加载检查点获取信息
    try:
        ckpt = load_checkpoint(tid)
        max_page = ckpt.get('last_page', 0)
    except:
        max_page = 0

    if max_page == 0:
        print(f"错误: 未找到帖子 {tid} 的有效数据 (checkpoint 不存在或无效)。")
        return

    # 2. 获取标题
    try:
        idx = json.load(open(THREAD_INDEX_JSON, 'r', encoding='utf-8'))
        title = idx.get(str(tid), f"Thread {tid}")
    except:
        title = f"Thread {tid}"

    # 3. 确定范围
    real_end = end_page if end_page and end_page <= max_page else max_page
    
    if start_page > real_end or start_page < 1:
        print(f"错误: 起始页码 {start_page} 无效。有效范围: 1 - {real_end}")
        return

    print(f"正在转换 TID:{tid} | 格式:{convert_type} | 范围:{start_page}-{real_end}")
    
    if convert_type == 'html':
        generate_html(tid, title, start_page, real_end, max_page)
    elif convert_type == 'llm':
        generate_llm(tid, title, start_page, real_end)
    else:
        print(f"未知格式: {convert_type}")

def list_crawled_threads() -> List[Dict[str, Any]]:
    if not THREAD_INDEX_JSON.exists():
        print("未找到 index.json。", file=sys.stderr)
        return []

    try:
        index_map = json.load(open(THREAD_INDEX_JSON, 'r', encoding='utf-8'))
    except:
        return []

    results = []
    print(f"\n{'TID':<12} | {'Title':<20} | {'Pages':<6}")
    print("-" * 45)
    for tid_str, title in index_map.items():
        tid = int(tid_str)
        ckpt = load_checkpoint(tid)
        pages = ckpt.get('last_page', 0)
        pids_count = len(ckpt.get("seen_pids", [])) 
        
        display_title = title[:20] + ('...' if len(title) > 20 else '')
        print(f"{tid:<12} | {display_title:<20} | {pages:<6} (PIDs:{pids_count})")
        results.append({'tid': tid_str, 'title': title, 'max_page': pages})
    print("-" * 45 + "\n")
    return results