from setuptools import setup, find_packages

# 确保 README.md 文件存在于项目根目录
try:
    with open('README.md', 'r', encoding='utf-8') as f:
        long_description = f.read()
except FileNotFoundError:
    long_description = '贴吧一体化异步爬取与HTML/LLM数据处理工具箱'

setup(
    # --- 1. 修改分发名 (Distribution Name) ---
    name='keaixiaojiycw-tieba-post-crawler', 
    
    # --- 版本更新到 0.7.1 ---
    version='0.7.1', 
    description='贴吧一体化异步爬取与HTML/LLM数据处理工具箱',
    long_description=long_description,
    long_description_content_type='text/markdown',
    
    # TODO: 请修改为您的信息
    author='keaixiaojiycw', 
    author_email='your.email@example.com', 
    url='https://github.com/yourusername/keaixiaojiycw-tieba-post-crawler', 
    license='MIT',

    # --- 2. 保持包名不变 (即目录名 tieba_toolkit) ---
    packages=find_packages(), 
    
    install_requires=[
        'aiotieba',
        'aiohttp',
        'aiofiles',
    ],
    
    # --- 3. 命令行入口 (CLI): 使用 tieba-crawler 名称 ---
    entry_points={
        'console_scripts': [
            # 用户将运行 tieba-crawler 命令
            'tieba-crawler = tieba_toolkit.cli:main', 
        ],
    },
    
    # --- 4. 修复后的分类器 (Classifier) 列表 ---
    classifiers=[
        # 开发状态
        'Development Status :: 4 - Beta',
        # 目标受众
        'Intended Audience :: Developers',
        # 许可证
        'License :: OSI Approved :: MIT License',
        # 操作系统支持
        'Operating System :: OS Independent',
        
        # FIX: 修正 Python 版本分类器格式（这是导致 400 错误的原因）
        'Programming Language :: Python :: 3',
        'Programming Language :: Python :: 3.8',
        'Programming Language :: Python :: 3.9',
        'Programming Language :: Python :: 3.10',
        'Programming Language :: Python :: 3.11',
        'Programming Language :: Python :: 3.12',
        
        # 主题
        'Topic :: Internet :: WWW/HTTP',
        'Topic :: Software Development :: Libraries :: Python Modules',
        'Framework :: AsyncIO',
    ],
    python_requires='>=3.8', # 设置最低支持的 Python 版本
)