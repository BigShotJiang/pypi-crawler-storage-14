def foo(x: float) -> float:
    """MUST FAIL — missing validate_Float."""
    return x
