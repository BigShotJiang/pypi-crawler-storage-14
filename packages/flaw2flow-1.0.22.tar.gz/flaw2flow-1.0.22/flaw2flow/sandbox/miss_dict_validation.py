def foo(d: dict) -> dict:
    """MUST FAIL — missing validation."""
    return d
