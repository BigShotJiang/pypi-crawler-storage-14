def foo(lst: list[str]) -> list[str]:
    """MUST FAIL — missing validation."""
    return lst
