def foo(s: str) -> str:
    """MUST FAIL — missing validator."""
    return s
