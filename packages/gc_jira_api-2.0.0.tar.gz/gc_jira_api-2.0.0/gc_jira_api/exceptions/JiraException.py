class JiraException(Exception):
    """Base class for all Jira exceptions."""

    pass
