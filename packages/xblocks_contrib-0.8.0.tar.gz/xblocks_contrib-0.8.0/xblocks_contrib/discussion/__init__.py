"""
Init for the DiscussionXBlock.
"""

from .discussion import DiscussionXBlock
