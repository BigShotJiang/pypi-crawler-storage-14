"""
Init for the PollBlock.
"""

from .poll import PollBlock
