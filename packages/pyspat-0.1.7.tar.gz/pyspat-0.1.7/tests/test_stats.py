import numpy as np
import pytest

from pyspat.core import RectangleWindow, PolyWindow, MaskWindow, PPP
from pyspat.stats import Kest, Lest, pcf, Gest, Fest, Jest

HAS_SHAPELY = True
try:
    import shapely.geometry as sgeom
except Exception:
    HAS_SHAPELY = False
    sgeom = None


@pytest.fixture(scope="module")
def rect_w():
    return RectangleWindow(0.0, 0.0, 256.0, 256.0, dtb_shape=(256, 256))


@pytest.fixture(scope="module")
def poly_w():
    if not HAS_SHAPELY:
        pytest.skip("shapely not available")
    return PolyWindow(
        sgeom.Polygon([(0, 0), (256, 0), (256, 256), (0, 256)]),
        dtb_shape=(256, 256),
    )


def _csr_ppp(lmbda, W, rng):
    n = rng.poisson(lmbda * W.area())
    xy = W.sample_uniform(n, rng)
    return PPP(xy, W)


@pytest.fixture(scope="module")
def rect_ppp(rect_w):
    rng = np.random.default_rng(202401)
    return _csr_ppp(0.05, rect_w, rng)


@pytest.fixture(scope="module")
def poly_ppp(poly_w):
    rng = np.random.default_rng(202402)
    return _csr_ppp(0.05, poly_w, rng)


@pytest.fixture(scope="module")
def r_grid():
    r = np.linspace(2.0, 40.0, 25)
    mid = (r >= 5.0) & (r <= 30.0)
    return r, mid


@pytest.fixture(scope="module")
def edges_grid():
    edges = np.linspace(2.0, 40.0, 60)
    centres = 0.5 * (edges[:-1] + edges[1:])
    mid = (centres >= 5.0) & (centres <= 30.0)
    return edges, centres, mid


def test_rect_K_L_translation_match_CSR(rect_ppp, r_grid):
    r, mid = r_grid
    K_hat = Kest(rect_ppp, r, correction="translation")
    K_theory = np.pi * r**2
    rel = np.abs(K_hat[mid] / K_theory[mid] - 1.0)
    assert np.median(rel) < 0.07
    assert rel.max() < 0.15
    L_hat = Lest(rect_ppp, r, correction="translation")
    assert np.sqrt(((L_hat[mid] - r[mid]) ** 2).mean()) < 1.0


def test_rect_pcf_translation_near_unity(rect_ppp, edges_grid):
    edges, centres, mid = edges_grid
    rmid, g = pcf(rect_ppp, edges, correction="translation")
    assert rmid.shape == centres.shape
    assert np.all(np.isfinite(g))
    assert np.median(np.abs(g[mid] - 1.0)) < 0.08
    assert np.max(np.abs(g[mid] - 1.0)) < 0.20


def test_rect_translation_vs_border_K_close_midrange(rect_ppp):
    r = np.linspace(4.0, 25.0, 15)
    Kt = Kest(rect_ppp, r, correction="translation")
    Kb = Kest(rect_ppp, r, correction="border")
    rel = np.abs(Kt - Kb) / (np.pi * r**2)
    assert np.median(rel) < 0.10
    assert rel.max() < 0.25


def test_rect_G_F_J_border_match_CSR(rect_ppp):
    lam = 0.05
    r = np.linspace(0.5, 8.0, 60)
    G = Gest(rect_ppp, r, method="border")
    F = Fest(
        rect_ppp,
        r,
        nsamp=1500,
        method="border",
        rng=np.random.default_rng(123),
    )
    J = Jest(
        rect_ppp,
        r,
        method_G="border",
        method_F="border",
        nsamp_F=1500,
        rng=np.random.default_rng(123),
    )
    theory = 1.0 - np.exp(-lam * np.pi * r**2)
    mask = np.isfinite(G) & np.isfinite(F)
    assert mask.any()
    assert np.median(np.abs(G[mask] - theory[mask])) < 0.08
    assert np.median(np.abs(F[mask] - theory[mask])) < 0.08
    stable = (theory >= 0.1) & (theory <= 0.9)
    jmask = mask & stable & np.isfinite(J)
    assert jmask.any()
    assert np.max(np.abs(J[jmask] - 1.0)) < 0.20


def test_rect_K_translation_scales_under_rescale(rect_w):
    rng = np.random.default_rng(14)
    xy = rect_w.sample_uniform(4000, rng)
    p = PPP(xy, rect_w)
    r = np.linspace(2.0, 25.0, 20)
    K0 = Kest(p, r, correction="translation")
    c = 2.0
    p2 = p.rescale(c)
    K2 = Kest(p2, c * r, correction="translation")
    assert np.allclose(K2, (c * c) * K0, rtol=2e-2, atol=1e-8)


def test_rect_pcf_integrates_to_K_differences(rect_ppp, edges_grid):
    edges, centres, mid = edges_grid
    rmid, g = pcf(rect_ppp, edges, correction="translation")
    K_hi = Kest(rect_ppp, edges[1:], correction="translation")
    K_lo = Kest(rect_ppp, edges[:-1], correction="translation")
    dK = K_hi - K_lo
    dr = np.diff(edges)
    approx = 2.0 * np.pi * rmid * g * dr
    rel = np.abs(approx[mid] - dK[mid]) / np.maximum(1e-9, np.abs(dK[mid]))
    assert np.median(rel) < 0.15
    assert np.max(rel) < 0.35


def test_rect_border_nan_when_r_huge(rect_w):
    rng = np.random.default_rng(16)
    xy = rect_w.sample_uniform(200, rng)
    p = PPP(xy, rect_w)
    r = np.array([1e9])
    assert np.isnan(Kest(p, r, correction="border")[0])
    assert np.isnan(
        Fest(
            p,
            r,
            method="border",
            nsamp=1000,
            rng=np.random.default_rng(1),
        )[0]
    )


@pytest.mark.skipif(not HAS_SHAPELY, reason="shapely not available")
def test_poly_K_L_translation_match_CSR(poly_ppp, r_grid):
    r, mid = r_grid
    K_hat = Kest(poly_ppp, r, correction="translation")
    K_theory = np.pi * r**2
    rel = np.abs(K_hat[mid] / K_theory[mid] - 1.0)
    assert np.median(rel) < 0.07
    assert rel.max() < 0.15
    L_hat = Lest(poly_ppp, r, correction="translation")
    assert np.sqrt(((L_hat[mid] - r[mid]) ** 2).mean()) < 1.0


@pytest.mark.skipif(not HAS_SHAPELY, reason="shapely not available")
def test_poly_pcf_translation_near_unity(poly_ppp, edges_grid):
    edges, centres, mid = edges_grid
    rmid, g = pcf(poly_ppp, edges, correction="translation")
    assert rmid.shape == centres.shape
    assert np.all(np.isfinite(g))
    assert np.median(np.abs(g[mid] - 1.0)) < 0.08
    assert np.max(np.abs(g[mid] - 1.0)) < 0.20


@pytest.mark.skipif(not HAS_SHAPELY, reason="shapely not available")
def test_poly_translation_vs_border_K_close_midrange(poly_ppp):
    r = np.linspace(4.0, 25.0, 15)
    Kt = Kest(poly_ppp, r, correction="translation")
    Kb = Kest(poly_ppp, r, correction="border")
    rel = np.abs(Kt - Kb) / (np.pi * r**2)
    assert np.median(rel) < 0.10
    assert rel.max() < 0.30


@pytest.mark.skipif(not HAS_SHAPELY, reason="shapely not available")
def test_poly_G_F_J_border_match_CSR(poly_ppp):
    lam = 0.05
    r = np.linspace(0.5, 8.0, 60)
    G = Gest(poly_ppp, r, method="border")
    F = Fest(
        poly_ppp,
        r,
        nsamp=2500,
        method="border",
        rng=np.random.default_rng(123),
    )
    J = Jest(
        poly_ppp,
        r,
        method_G="border",
        method_F="border",
        nsamp_F=2500,
        rng=np.random.default_rng(123),
    )
    theory = 1.0 - np.exp(-lam * np.pi * r**2)
    mask = np.isfinite(G) & np.isfinite(F)
    assert mask.any()
    assert np.median(np.abs(G[mask] - theory[mask])) < 0.08
    assert np.median(np.abs(F[mask] - theory[mask])) < 0.08
    stable = (theory >= 0.1) & (theory <= 0.9)
    jmask = mask & stable & np.isfinite(J)
    assert jmask.any()
    assert np.max(np.abs(J[jmask] - 1.0)) < 0.15


@pytest.mark.skipif(not HAS_SHAPELY, reason="shapely not available")
def test_poly_K_translation_scales_under_rescale(poly_w):
    rng = np.random.default_rng(24)
    xy = poly_w.sample_uniform(3500, rng)
    p = PPP(xy, poly_w)
    r = np.linspace(2.0, 25.0, 20)
    K0 = Kest(p, r, correction="translation")
    c = 2.0
    p2 = p.rescale(c)
    K2 = Kest(p2, c * r, correction="translation")
    assert np.allclose(K2, (c * c) * K0, rtol=2e-2, atol=1e-8)


@pytest.mark.skipif(not HAS_SHAPELY, reason="shapely not available")
def test_poly_pcf_integrates_to_K_differences(poly_ppp, edges_grid):
    edges, centres, mid = edges_grid
    rmid, g = pcf(poly_ppp, edges, correction="translation")
    K_hi = Kest(poly_ppp, edges[1:], correction="translation")
    K_lo = Kest(poly_ppp, edges[:-1], correction="translation")
    dK = K_hi - K_lo
    dr = np.diff(edges)
    approx = 2.0 * np.pi * rmid * g * dr
    rel = np.abs(approx[mid] - dK[mid]) / np.maximum(1e-9, np.abs(dK[mid]))
    assert np.median(rel) < 0.15
    assert np.max(rel) < 0.35


@pytest.mark.skipif(not HAS_SHAPELY, reason="shapely not available")
def test_poly_border_nan_when_r_huge(poly_w):
    rng = np.random.default_rng(26)
    xy = poly_w.sample_uniform(200, rng)
    p = PPP(xy, poly_w)
    r = np.array([1e9])
    assert np.isnan(Kest(p, r, correction="border")[0])
    assert np.isnan(
        Fest(
            p,
            r,
            method="border",
            nsamp=1000,
            rng=np.random.default_rng(1),
        )[0]
    )


def test_translation_K_almost_agrees_across_window_types_for_same_points():
    rng = np.random.default_rng(30)
    L = 200
    M = MaskWindow(np.ones((L, L), bool), spacing=(1.0, 1.0))
    R = RectangleWindow(0.0, 0.0, float(L), float(L))

    xy = M.sample_uniform(3000, rng)
    pM = PPP(xy, M)
    pR = PPP(xy, R)

    r = np.linspace(2.0, 25.0, 20)
    KM = Kest(pM, r, correction="translation")
    KR = Kest(pR, r, correction="translation")

    rel_MR = np.abs(KM - KR) / np.maximum(1e-9, np.pi * r**2)
    assert np.median(rel_MR) < 0.05
    assert rel_MR.max() < 0.12

    if HAS_SHAPELY:
        import shapely.geometry as sgeom
        P = PolyWindow(sgeom.Polygon([(0, 0), (L, 0), (L, L), (0, L)]))
        pP = PPP(xy, P)
        KP = Kest(pP, r, correction="translation")

        rel_MP = np.abs(KM - KP) / np.maximum(1e-9, np.pi * r**2)
        rel_RP = np.abs(KR - KP) / np.maximum(1e-9, np.pi * r**2)
        assert np.median(rel_MP) < 0.05 and rel_MP.max() < 0.12
        assert np.median(rel_RP) < 0.03 and rel_RP.max() < 0.10

def test_plot_smoke_rect(rect_ppp):
    # Single quick figure per stat.
    import numpy as np
    r = np.linspace(2.0, 30.0, 40)
    edges = np.linspace(2.0, 30.0, 41)

    # K, L
    Kest(rect_ppp, r, correction="translation", showplot=True)
    Lest(rect_ppp, r, correction="translation", showplot=True)

    # g
    rmid, g = pcf(rect_ppp, edges, correction="translation", showplot=True)
    assert rmid.shape == g.shape

    # G, F, J
    G = Gest(rect_ppp, r, method="border", showplot=True)
    F = Fest(rect_ppp, r, nsamp=1200, method="border",
             rng=np.random.default_rng(123), showplot=True)
    J = Jest(rect_ppp, r, method_G="border", method_F="border",
             nsamp_F=1200, rng=np.random.default_rng(123), showplot=True)

    assert np.all(np.isfinite(Kest(rect_ppp, r, showplot=False)) | np.isnan(G))
    assert G.shape == F.shape == J.shape == r.shape


def test_mask_translation_cache_reuse():
    import numpy as np
    from pyspat.core import MaskWindow, PPP
    import pyspat.stats as S

    L = 128
    M = MaskWindow(np.ones((L, L), bool), spacing=(1.0, 1.0))
    rng = np.random.default_rng(0)
    xy = M.sample_uniform(1000, rng)
    p = PPP(xy, M)

    before = len(S._MTW_CACHE)
    _ = S.Kest(p, np.linspace(2.0, 20.0, 10), showplot=False)  # builds cache
    after1 = len(S._MTW_CACHE)
    _ = S.Kest(p, np.linspace(2.0, 20.0, 10), showplot=False)  # reuses cache
    after2 = len(S._MTW_CACHE)

    assert after1 == before + 1
    assert after2 == after1


def test_distance_to_boundary_idempotent(rect_w):
    img1 = rect_w.distance_to_boundary()
    img2 = rect_w.distance_to_boundary()
    assert np.array_equal(img1.values, img2.values)
