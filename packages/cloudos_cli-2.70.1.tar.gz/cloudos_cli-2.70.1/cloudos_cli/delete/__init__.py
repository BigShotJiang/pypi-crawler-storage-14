"""
Functions and classes related to delete (results & workdir).
"""

from .results import delete_job_results


__all__ = ['results']
