"""tests for plyrfm."""
