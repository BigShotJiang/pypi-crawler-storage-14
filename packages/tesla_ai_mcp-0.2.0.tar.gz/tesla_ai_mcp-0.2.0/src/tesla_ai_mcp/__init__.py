import sys
import json
import os
import requests
from typing import Dict, Any

# MCP服务器地址 (生产环境)
MCP_SERVER_URL = "https://uther.xiaote.net/api/mcp/proxy"

def get_api_key():
    """获取API Key，优先从环境变量获取"""
    # 支持 TESLA_MCP_API_KEY（推荐）和旧版本 API_KEY（向后兼容）
    api_key = os.environ.get("TESLA_MCP_API_KEY") or os.environ.get("API_KEY") or os.environ.get("TESLA_MCP_KEY")
    if not api_key:
        error_response = {
            "jsonrpc": "2.0",
            "id": None,
            "error": {
                "code": -32600,
                "message": "TESLA_MCP_API_KEY 环境变量未设置。请在 Claude Desktop 配置或环境变量中设置。"
            }
        }
        print(json.dumps(error_response, ensure_ascii=False), flush=True)
        sys.exit(1)
    return api_key

def send_mcp_request(request: Dict[str, Any], api_key: str) -> Dict[str, Any]:
    """发送MCP请求到HTTP服务器"""
    try:
        response = requests.post(
            MCP_SERVER_URL,
            json={
                "api_key": api_key,
                "request": request
            },
            headers={"Content-Type": "application/json"},
            timeout=60  # 增加超时时间，因为车辆唤醒可能需要时间
        )
        response.raise_for_status()
        return response.json()
    except requests.exceptions.RequestException as e:
        return {
            "jsonrpc": "2.0",
            "id": request.get("id"),
            "error": {
                "code": -32603,
                "message": f"HTTP请求失败: {str(e)}"
            }
        }

def main():
    """主函数：从stdin读取请求，发送到HTTP服务器，输出响应"""
    api_key = get_api_key()
    
    # 强制设置 stdin/stdout 为 utf-8 编码，避免 Windows 下编码问题
    if sys.platform == 'win32':
        sys.stdin.reconfigure(encoding='utf-8')
        sys.stdout.reconfigure(encoding='utf-8')

    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue

        try:
            request = json.loads(line)
            response = send_mcp_request(request, api_key)
            print(json.dumps(response, ensure_ascii=False), flush=True)
        except json.JSONDecodeError as e:
            error_response = {
                "jsonrpc": "2.0",
                "id": None,
                "error": {
                    "code": -32700,
                    "message": f"Parse error: {str(e)}"
                }
            }
            print(json.dumps(error_response, ensure_ascii=False), flush=True)
        except Exception as e:
            error_response = {
                "jsonrpc": "2.0",
                "id": None,
                "error": {
                    "code": -32603,
                    "message": f"Internal error: {str(e)}"
                }
            }
            print(json.dumps(error_response, ensure_ascii=False), flush=True)

if __name__ == "__main__":
    main()

