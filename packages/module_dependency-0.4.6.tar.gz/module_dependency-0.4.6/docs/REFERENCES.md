# References

### Dependency Injector
- https://python-dependency-injector.ets-labs.org/containers/dynamic.html
- https://python-dependency-injector.ets-labs.org/providers/overriding.html