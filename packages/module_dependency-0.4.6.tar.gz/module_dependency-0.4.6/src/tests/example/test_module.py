from dependency.core import Module, module

def test_module():
    pass