"""
Memory Journal MCP Server - Database Module
Database operations and management for the Memory Journal system.
"""
