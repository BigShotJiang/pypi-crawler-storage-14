"""
Kubiya Control Plane SDK Version

This version must match between worker and control plane for compatibility.
Workers will check this version during registration and exit if mismatched.

Version is read from version.txt in the repository root (single source of truth).
"""


from pathlib import Path


def get_sdk_version() -> str:
    """Get the SDK version string from version.txt.

    Returns:
        str: Package version (e.g., "0.3.9")
    """
    try:
        version_file = Path(__file__).parent.parent.parent / "version.txt"
        return version_file.read_text().strip()
    except Exception:
        return "0.3.9"


__version__ = get_sdk_version()
