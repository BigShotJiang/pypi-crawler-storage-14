"""Web management interface for acemcp MCP server."""

from acemcp.web.app import create_app

__all__ = ["create_app"]
