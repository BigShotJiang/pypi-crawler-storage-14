
selected_directory = None
all_data = {
  'harmonization': None,
  'prediction-training': None,
  'prediction-testing': None,
}
input_files = {
  'harmonization': None,
  'prediction-training': None,
  'prediction-testing': None,
}
input_sites = {
  'harmonization': None,
  'prediction-training': None,
  'prediction-testing': None,
}
