# Changelog

All notable changes to Malha will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.11.1] - 2025-11-29

### 🔧 RFC-001 Completion: Additional Kernel Methods

Completes the RFC-001 implementation with additional methods required by upper layers.

#### New Methods

- **`kernel.find_process_by_idempotency(key)`**: Direct lookup of process by idempotency key
- **`kernel.unit_of_work()`**: Factory method to create UnitOfWork bound to kernel
- **`uow.rollback_to_savepoint(index)`**: Manual rollback to a specific savepoint index
- **`uow.session`**: Property to access underlying SQL session for advanced operations
- **`savepoint.index`**: Property to get savepoint index for manual rollback

#### Enhanced Savepoint

Savepoints now support real SQL savepoints when a session is available:
- Creates `SAVEPOINT sp_name` on enter
- Executes `ROLLBACK TO SAVEPOINT sp_name` on exception
- Executes `RELEASE SAVEPOINT sp_name` on success

```python
# New kernel factory method
async with kernel.unit_of_work() as uow:
    uow.add(agent_state)
    
    # Savepoint with SQL support
    async with uow.savepoint() as sp:
        await risky_operation()
        uow.add(result)
    
    await uow.commit()

# Direct idempotency lookup
existing = await kernel.find_process_by_idempotency(key)
if existing and existing.status == "COMPLETED":
    return existing.result_payload  # Cached result
```

#### Files Changed
- `malha/malha.py`: New methods and enhanced Savepoint
- `tests/test_fat_kernel.py`: 8 new tests (59 total)

---

## [0.11.0] - 2025-11-29

### 🧠 RFC-001: Runtime Cognitivo Transacional

Major release implementing the foundation for treating AI agent execution as durable, atomic transactions.

#### SysProcess Enhancements (Tarefa A)

Enhanced the `SysProcess` model to support crash recovery for AI agents:

- **`idempotency_key`**: Unique key (hash of prompt + user_id) to prevent duplicate processing
- **`lock_version`**: Optimistic locking for concurrent updates
- **`result_payload`**: Structured output storage when completed
- **`created_at` / `updated_at`**: Timestamps for debugging and tracing
- **`max_retries`**: Configurable retry limit
- **`SUSPENDED` / `RECOVERING`**: New status values for agent lifecycle

```python
# Idempotent agent execution
key = hashlib.sha256(f"{user_id}:{prompt}".encode()).hexdigest()
process, created = await kernel.get_or_create_process(
    idempotency_key=key,
    process_type="agent",
    process_name="ChatAgent",
)
if not created and process.status == "COMPLETED":
    return json.loads(process.result_payload)  # Cached result
```

#### UnitOfWork Savepoints (Tarefa B)

Added nested transaction support for AI agents trying multiple tools:

- **`Savepoint`**: Context manager for partial rollback
- **`uow.savepoint()`**: Create a savepoint within a UnitOfWork
- **`uow.rollback()`**: Explicit rollback method
- **`uow.is_committed`**: Property to check commit status

```python
async with UnitOfWork(kernel) as uow:
    uow.add(agent_state)  # This will be saved
    
    try:
        async with uow.savepoint():
            result = await risky_tool()  # If fails...
            uow.add(result)
    except ToolError:
        # ...only the savepoint is rolled back
        async with uow.savepoint():
            result = await fallback_tool()
            uow.add(result)
    
    await uow.commit()  # agent_state + successful tool
```

#### Process Locking (Tarefa C)

Pessimistic locking to prevent concurrent agent execution:

- **`acquire_process_lock()`**: SELECT FOR UPDATE semantics
- **`release_process_lock()`**: Release ownership
- **`get_or_create_process()`**: Idempotent process creation
- **`update_process_state()`**: Safe state updates with version checking

```python
# Exclusive agent processing
process = await kernel.acquire_process_lock(process_id, nowait=True)
if process is None:
    return {"status": "busy"}  # Another worker has it

try:
    await run_agent(process)
finally:
    await kernel.release_process_lock(process_id)
```

#### Files Changed
- `malha/malha.py`: SysProcess enhancements, Savepoint class, process locking methods
- `malha/__init__.py`: Export Savepoint
- `tests/test_fat_kernel.py`: 17 new tests for RFC-001 features

#### Migration Note
The `sys_process` table has new columns. Run migrations or recreate the table:
- `idempotency_key` (unique, indexed)
- `result_payload`
- `lock_version`
- `max_retries`
- `created_at`
- `updated_at`

---

## [0.10.4] - 2025-11-28

### 🔒 Distributed Systems Hardening

Critical fixes for race conditions and scalability in clustered deployments.

#### Boot Race Condition Fix (CAS Pattern)

**Problem:** In a cluster (e.g., 3 Kubernetes pods), multiple nodes booting simultaneously after a crash could claim the same zombie processes, causing double execution (duplicate charges, emails, etc.).

**Solution:** Implemented atomic state transition using Compare-and-Swap (CAS) pattern:
- `UPDATE ... WHERE status=RUNNING` atomically claims processes
- New `RECOVERING` transitional status prevents double-claim
- Each node only processes what it successfully claimed

```python
# Before (vulnerable):
zombies = session.execute(select(SysProcess)...).all()  # Dirty read
for proc in zombies:
    recover(proc)  # Race condition!

# After (atomic):
session.execute(update(SysProcess)
    .where(status="RUNNING")
    .values(status="RECOVERING", node_id=my_node_id))
my_zombies = session.execute(select(SysProcess)
    .where(status="RECOVERING", node_id=my_node_id)).all()
```

#### Synapse Gap Detection & Pagination

**Problem 1 (Log Gap):** If Janitor cleans events older than 7 days and a node is offline for 8 days, it requests events that no longer exist, causing data corruption.

**Problem 2 (Memory Exhaustion):** A node 1M events behind could cause the server to load all events into memory, crashing it.

**Solution:**
- **Gap Detection:** Check `min(id)` before serving events. If `requested_checkpoint < min_id`, return `CHECKPOINT_TOO_OLD` immediately
- **Keyset Pagination:** Always use `WHERE id > last_id LIMIT N` (O(1)) instead of OFFSET (O(n))
- **Hard Limit:** Server caps batch size at 1000 events regardless of client request

```python
# Gap detection
if checkpoint_id < min_available_id - 1:
    return ResumeResponse(status=CHECKPOINT_TOO_OLD, ...)

# Keyset pagination (efficient)
stmt = select(SysOutbox).where(id > checkpoint_id).limit(1000)
```

#### Files Changed
- `malha/boot.py`: Atomic zombie claiming with CAS pattern
- `malha/drivers/synapse.py`: Gap detection + keyset pagination

---

## [0.10.3] - 2025-11-28

### 🗄️ Embedded Alembic Migrations

Production-grade schema migrations without external CLI or config files.

#### Added

**AlembicDriver (`malha/drivers/alembic.py`)**
- `AlembicDriver` class for programmatic Alembic integration
- Injects kernel's SQLAlchemy engine (no duplicate connections)
- Automatic SQLite batch mode for safe DDL operations
- Custom `env.py` template with dependency injection
- Methods: `init()`, `upgrade()`, `downgrade()`, `create_revision()`, `auto_migrate()`
- `MigrationResult` and `MigrationInfo` dataclasses

**Migrator Integration**
- `Migrator.alembic` property for lazy AlembicDriver access
- `Migrator.auto_migrate()` for one-step create + upgrade
- `Migrator.upgrade()`, `downgrade()`, `init_alembic()` convenience methods

**Bootloader Integration**
- `auto_migrate` parameter for applying migrations on boot
- `migrations_path` parameter for custom migrations directory
- `BootResult.migrations_applied` field

**Exports**
- `AlembicDriver`, `MigrationInfo`, `init_migrations`, `run_migrations`

#### Dependencies
- Added `alembic>=1.13.0` to core dependencies

#### Why Embedded Alembic?
1. **Security**: No passwords in `alembic.ini` files
2. **Concurrency**: Reuses kernel's connection pool
3. **SQLite Safety**: Automatic batch mode for DDL operations
4. **DX**: Zero configuration for end users

---

## [0.10.2] - 2025-11-28

### 🚀 Multi-Get (Batch Retrieval)

#### Added
- `BaseRepository.mget()` builds a single `WHERE rid IN (...)` query (SCD2 aware)
- `UnifiedDataManager.mget()` exposes batch retrieval with governance interceptors

#### Tests
- Added `TestBatchRetrieval` in `tests/test_fat_kernel.py` covering happy path and interceptor trimming

---

## [0.10.1] - 2025-11-28

### 🔧 Patch Release

Hotfix to unblock PyPI publication.

#### Fixed

- Bumped package metadata (`pyproject.toml`, `__init__.py`, docs banner) to 0.10.1
- Rebuilt distribution artifacts for PyPI release

---

## [0.10.0] - 2025-11-28

### 🔄 Lifecycle Management - Boot, Maintenance & Enhanced Integrations

This release adds complete lifecycle management to the Malha kernel: automatic crash recovery (boot), garbage collection (maintenance), and enhanced database integrations.

#### Added

**Bootloader (Crash Recovery)**
- `Bootloader` class for automatic crash recovery on startup
- WAL recovery from `ParquetStreamDriver` (processes orphaned .wal files)
- Zombie process detection (finds RUNNING processes after restart)
- `@recoverable` decorator for workflow recovery registration
- `register_recovery_handler()` for manual handler registration
- `BootResult` dataclass with recovery statistics
- `boot_kernel()` convenience function

**Maintenance (Garbage Collection)**
- `Janitor` class for periodic data cleanup
  - Cleans old `SysOutbox` events (status=DONE)
  - Cleans old `SysProcess` records (terminal states)
  - Archives `ActionLog` to Parquet (cold storage)
  - Database optimization (SQLite VACUUM, Kùzu CHECKPOINT)
  - `schedule_daily()` for automatic scheduling
- `Migrator` class for schema evolution
  - `check_drift()` detects differences between model and DB
  - `apply_migrations()` for safe ADD COLUMN migrations
  - Dry-run mode by default (safe)
- `CleanupResult`, `MigrationResult`, `SchemaDrift` dataclasses

**Synapse Resume Protocol**
- `ResumeHandshake` RPC for checkpoint-based reconnection
- `ResumeRequest`/`ResumeResponse` protobuf messages
- Checkpoint tracking per peer (`_peer_checkpoints`)
- Automatic catch-up on reconnection (no data loss/duplication)
- Batch processing with `has_more` pagination

**Kùzu Configuration**
- `KuzuConfig` dataclass for graph database tuning:
  - `buffer_pool_size`: Memory allocation (default: 256MB)
  - `max_num_threads`: Query parallelism
  - `enable_compression`: Storage compression
  - `read_only`: Read-only mode for replicas
  - `max_db_size`: Maximum database size
  - `duckdb_path`: DuckDB file for hybrid queries
  - `auto_load_extensions`: Auto-load DuckDB/HTTPFS extensions
- Zero-copy federation between Kùzu and DuckDB
- `_load_extensions()` method for DuckDB ATTACH

**connect() Enhancements**
- `kuzu_config` parameter for graph database tuning
- `auto_boot=True` runs Bootloader automatically (skip on reset=True)
- `auto_cleanup=False` schedules daily Janitor at 3 AM
- `cleanup_retention_days=30` for data retention policy

**New Exception**
- `ConsistencyTimeoutError` for strict mode in `KuzuActor.query`

#### Fixed

**Watermark Consistency**
- Fixed `save_versioned`: watermark now updated AFTER commit (not before)
- Fixed `insert`: same watermark fix
- Fixed `insert_batch`: same watermark fix + flush before commit
- Prevents phantom watermarks if transaction fails

**KuzuActor.query Strict Mode**
- Added `strict` parameter to `query()` method
- When `strict=True`, raises `ConsistencyTimeoutError` instead of stale read
- Allows applications to choose fail-fast vs eventual consistency

---

## [0.9.0] - 2025-06-15

### 🏗️ Fat Kernel Architecture - Centralized Infrastructure

This release consolidates infrastructure responsibilities into the Malha kernel, following the "Fat Kernel" architecture pattern. Higher layers (semantico, perception, system) no longer manage low-level infrastructure - the kernel provides the "HOW" while other layers define the "WHAT".

#### Added

**Context Management (Centralized)**
- `set_kernel(kernel)`: Set the kernel in the current context (thread/async-safe)
- `get_kernel()`: Get the kernel from context (raises if not set)
- `clear_kernel()`: Clear the kernel from context (useful for testing)
- `connect()` now automatically sets the kernel in global context

**Stream Driver (Data Lake Writes)**
- `ParquetStreamDriver`: High-performance Parquet writer with Hive-style partitioning
- Automatic buffering with configurable flush threshold
- Zero-copy writes via PyArrow
- Partition column extraction from timestamps
- JSON fallback when PyArrow is not available

**Compute Driver (Script Execution)**
- `LocalComputeDriver`: Safe script execution using PEP 723 and uv
- AST-based security validation (blocks dangerous imports/patterns)
- Configurable timeout
- `ComputeResult` dataclass for structured results
- `RuntimeExecutionError` and `CodeSynthesisError` exceptions

**Transaction Management**
- `UnitOfWork`: Atomic transaction manager for multi-object operations
- Batch object persistence with graph link creation
- Automatic rollback on failure
- Context manager support (`async with UnitOfWork() as uow`)
- Kernel injection from context if not provided

**Process State Model**
- `SysProcess`: Durable process state for workflows and sagas
- `ProcessStatus` enum: PENDING, RUNNING, COMPLETED, FAILED, COMPENSATING, COMPENSATED, DEAD_LETTER
- Enables crash recovery for long-running processes
- Heartbeat tracking for liveness detection
- Parent/child process relationships

#### Changed

- `connect()` now accepts optional `stream_driver` and `compute_driver` parameters
- `connect()` automatically calls `set_kernel()` after initialization
- Updated module docstring with architecture diagram and migration guide

#### Migration Guide

```python
# Before (v0.8)
from semantico import set_kernel, get_kernel
kernel = await connect()
set_kernel(kernel)

# After (v0.9)
from malha import connect, get_kernel
kernel = await connect()  # Automatically sets kernel in context
# get_kernel() now works without explicit set_kernel()
```

#### Architecture

```
┌─────────────────────────────────────────────────────────────┐
│  Application Layer (semantico, kinetic, perception, etc.)   │
├─────────────────────────────────────────────────────────────┤
│  Malha Kernel (Fat Kernel)                                  │
│  ├─ Context: set_kernel(), get_kernel(), clear_kernel()     │
│  ├─ SQL Driver: AsyncSQLAlchemyDriver                       │
│  ├─ Graph Driver: KuzuActor                                 │
│  ├─ Analytics Driver: DuckDBDriver                          │
│  ├─ Stream Driver: ParquetStreamDriver (NEW)                │
│  ├─ Compute Driver: LocalComputeDriver (NEW)                │
│  ├─ Transaction: UnitOfWork (NEW)                           │
│  └─ Models: SysOutbox, SysProcess (NEW)                     │
└─────────────────────────────────────────────────────────────┘
```

---

## [0.7.1] - 2024-11-25

### ⚡ High-Performance Append-Only Insertion

This release adds optimized insertion methods for log tables and append-only data.

#### Added

**Append-Only Insertion (No SCD2 Overhead)**
- `kernel.insert(obj)`: Single record insertion without version locking
- `kernel.insert_batch(objects)`: Batch insertion in single transaction
- Optional `replicate=True` flag for outbox/graph sync
- Ideal for: audit logs, telemetry, event streams, immutable records

#### Performance Characteristics
- **No SELECT FOR UPDATE**: Skips pessimistic locking
- **No version closing**: Skips SCD2 logic entirely
- **Single transaction**: Batch inserts all records atomically
- **Optional replication**: Only adds outbox entries when needed

#### Use Cases
```python
# High-performance log insertion
log = AuditLog(action="user_login", user_id="123")
await kernel.insert(log)

# Batch telemetry (500 events in one transaction)
events = [TelemetryEvent(metric="cpu", value=v) for v in values]
await kernel.insert_batch(events)

# Append-only with graph sync
await kernel.insert(transaction, replicate=True)
```

---

## [0.7.0] - 2024-11-24

### 🌀 Helix Pattern Complete - Topology Sync & Ghost Nodes

This release completes the **Helix Pattern** implementation, enabling Virtual Objects to participate in the graph without being persisted in the SQL layer.

#### Added

**TopologySyncService (Graph Topology Materializer)**
- New `malha.services.TopologySyncService` class for materializing graph topology from external sources
- `sync_relationship()`: Sync FK relationships from external tables to graph edges
- `sync_bidirectional()`: Sync many-to-many relationships (junction tables)
- `bulk_create_edges()`: Optimized bulk edge creation
- `generate_virtual_rid()`: Deterministic RID generation using UUIDv5 hashing
- Progress callbacks for long-running sync operations
- Statistics tracking (total_syncs, total_edges_created, total_errors)

**Ghost Nodes (Helix Pattern)**
- `KuzuActor.ensure_ghost_schema()`: Creates Object node table and LINK relationship table
- `KuzuActor.create_edge(create_ghost_nodes=True)`: Auto-creates stub nodes for missing RIDs
- Ghost nodes have `virtual=true` flag to distinguish from SQL-persisted entities
- Enables connecting Virtual Objects that live in external systems

**Column Selection for Lightweight Queries**
- `query_federated(columns=[...])`: Select specific columns instead of `SELECT *`
- Reduces data transfer for topology extraction (only keys needed)
- SQL injection protection for column names

#### Changed
- `DuckDBDriver.query_federated()` now accepts optional `columns` parameter
- `UnifiedDataManager.query_federated()` passes `columns` to driver
- All `_build_*_query()` methods updated to support column selection

#### Technical Details
- Ghost Node schema uses generic `LINK` relationship table with `label` property
- Separate MERGE operations for Kùzu compatibility (no multi-MERGE support)
- Idempotent schema creation with `_ghost_schema_initialized` flag

---

## [0.6.1] - 2024-11-24

### 🎨 State-of-the-Art Developer Experience

#### Added
- **Context Manager**: `async with kernel` for automatic cleanup
- **Federation Shortcuts**: `from_postgres()`, `from_parquet()`, `from_csv()`, `from_sqlite()`
- **Dynamic Version**: Uses `importlib.metadata` (single source of truth)
- **Better Exports**: Organized `__all__` with categories

#### Fixed
- Removed DEBUG logs and print statements from production code
- Improved error messages with examples for all federation errors
- Fixed SQLite attach duplicate error handling

#### Documentation
- Complete README rewrite with Federation docs
- Added badges (PyPI, coverage, Python version)
- Added API reference tables

---

## [0.6.0] - 2024-11-24

### 🌐 Federation Support (Helix) - Zero-ETL Analytics

This release introduces **federated query capabilities** enabling Zero-ETL analytics across external data sources.

#### Added

**DuckDB Federation (Helix)**
- `DuckDBDriver.query_federated()`: Execute queries on external sources without data movement
- Support for multiple source types:
  - **PostgreSQL**: Direct TCP connection via `postgres_scan` with predicate pushdown
  - **Parquet**: Local files or S3 paths
  - **CSV**: Auto-detection of delimiters and types
  - **SQLite**: Attach and query external databases
  - **S3**: Configurable credentials and region
- `DuckDBDriver.query_df()`: Return results as JSON-serializable list of dicts
- Dynamic extension loading with `_load_extension()`
- S3 credential configuration for remote file access

**UnifiedDataManager Integration**
- `kernel.query_federated()`: Proxy method for semantic layer integration
- Enables VirtualObject pattern where domain objects delegate queries to kernel

**Comprehensive Test Suite**
- 41 new federation tests covering all source types
- Tests for error handling, validation, and edge cases
- Integration tests with kernel proxy

#### Technical Details

```python
# Query PostgreSQL directly (Zero-ETL)
customers = await kernel.query_federated({
    "type": "postgres",
    "dsn": "dbname=legacy user=reader host=db.example.com",
    "table": "customers"
}, "status = 'active' AND created_at > '2024-01-01'")

# Query Parquet on S3
events = await kernel.query_federated({
    "type": "parquet",
    "path": "s3://bucket/data/events.parquet"
}, "event_type = 'purchase'")
```

#### Benefits
- **Zero-ETL**: No pipelines needed to copy data from legacy systems
- **Predicate Pushdown**: DuckDB pushes filters to source, minimizing data transfer
- **Security**: Credentials used at runtime only, not persisted
- **Performance**: Query external data as if it were local

---

## [0.5.1] - 2024-11-24

### 🧪 Test Coverage Improvements

- Comprehensive gRPC mocking for Synapse driver (40% → 75%)
- Overall coverage improved to 87%
- 215 tests passing

---

## [0.5.0] - 2024-11-24

### 🎯 Major Architectural Refactoring - Domain Envelope Pattern

This release represents a **fundamental architectural evolution** of Malha, adopting the Domain Envelope pattern from `registro` v0.7.0+ and introducing comprehensive Time Travel capabilities.

#### Added

**Domain Envelope Pattern**
- Full integration with `registro.DomainResource` as the official base class
- Removed duplicate `BaseResource` implementation (~65 lines eliminated)
- Transparent envelope conversion (`to_envelope()` / `from_envelope()`)
- Schema-on-Read support via `meta_tags` JSON field
- Rich domain objects with Pydantic validation

**Time Travel (SCD Type 2 Support)**
- `BaseRepository.get()` enhanced with temporal parameters:
  - `rid`: Logical resource identifier
  - `version`: Specific version number
  - `at_time`: Point-in-time queries
  - `active_only`: Filter for active versions only
- New `BaseRepository.get_history()` method for complete version history
- Bitemporal timestamp tracking (`valid_from`, `valid_to`, `tx_from`, `tx_to`)
- Audit trail and historical data analysis capabilities

**Enhanced Repository**
- Queries operate on physical table (`Resource`)
- Returns hydrated domain objects automatically
- Supports filtering by SQL columns
- Optimistic locking with version checking

**Interceptor Improvements**
- Interceptors now receive `DomainResource` objects
- Enables rich domain validation and transformation
- Access to full object graph, not just SQL columns

**Outbox & Replication**
- Outbox payload is now domain object JSON (not physical envelope)
- Uses `global_registry` from `registro` for class discovery
- Synapse driver instantiates `DomainResource` on remote events
- Fallback to generic `DomainResource` if class not found

**Documentation**
- `MIGRATION_DOMAIN_ENVELOPE.md`: Complete migration guide
- `REFACTORING_SUMMARY.md`: Technical implementation details
- `TEST_RESULTS.md`: Comprehensive test results
- `examples/domain_envelope_example.py`: Practical usage examples

**Testing**
- 23 tests for Domain Envelope pattern (100% passing)
- 11 tests for Time Travel functionality (100% passing)
- Total: 34 new tests validating core functionality

#### Changed

**Dependencies**
- Updated `registro` from 0.5.1 to **0.7.0** (required)
- Requires Python 3.13+

**BaseRepository**
- `get()` signature changed to support Time Travel
- Queries always on `RegistroResource` (physical table)
- Returns hydrated `DomainResource` objects
- Added `get_history()` for version history

**UnifiedDataManager**
- `save_versioned()` accepts `DomainResource` (not `RegistroResource`)
- Converts to envelope internally via `to_envelope()`
- Outbox payload is domain object JSON
- Improved pessimistic locking with envelope handling

**Interceptor Protocol**
- `on_write()` and `on_read()` now receive `DomainResource`
- Breaking change: update custom interceptors

**SynapseDriver**
- Uses `global_registry` for class discovery
- Instantiates `DomainResource` on replication
- Improved error handling with fallbacks

**Exports**
- Added `OptimisticLockError` to public API
- Added `ValidationError` to public API
- Added `SysOutbox` to public API
- Added `BaseRepository` to public API

#### Fixed

- Envelope conversion preserves all domain fields
- Dynamic fields correctly stored in `meta_tags`
- Roundtrip conversion (Domain → Envelope → Domain) lossless
- Pessimistic locking works with envelope pattern
- Outbox processor handles domain objects correctly

### 📦 Migration Guide

#### Breaking Changes

1. **`malha.BaseResource` removed**
   - **Before:** `from malha import BaseResource`
   - **After:** `from registro import DomainResource`

2. **`BaseRepository.get()` signature changed**
   - **Before:** `get(session, id=None, version=None, **filters)`
   - **After:** `get(session, id=None, rid=None, version=None, at_time=None, active_only=True, **filters)`

3. **Interceptors receive `DomainResource`**
   - **Before:** `async def on_write(self, obj: RegistroResource, agent=None)`
   - **After:** `async def on_write(self, obj: DomainResource, agent=None)`

#### Code Migration

**Step 1: Update imports**
```python
# Before
from malha import BaseResource

# After
from registro import DomainResource, register
```

**Step 2: Update resource classes**
```python
# Before
class User(BaseResource):
    name: str
    email: str

# After
class User(DomainResource):
    name: str
    email: str

# Register for global discovery
register("User", User)
```

**Step 3: Update interceptors**
```python
# Before
class MyInterceptor(Interceptor):
    async def on_write(self, obj: RegistroResource, agent=None):
        pass

# After
class MyInterceptor(Interceptor):
    async def on_write(self, obj: DomainResource, agent=None):
        # Now has access to rich domain object
        if isinstance(obj, User):
            # Domain-specific validation
            pass
```

**Step 4: Use Time Travel features**
```python
repo = kernel.get_repository(User)

# Get current version
user = await repo.get(session, rid="ri.app.prod.user.123")

# Get specific version
user_v1 = await repo.get(session, rid="ri.app.prod.user.123", version=1)

# Point-in-time query
user_past = await repo.get(
    session,
    rid="ri.app.prod.user.123",
    at_time=datetime(2024, 1, 1)
)

# Get complete history
history = await repo.get_history(session, rid="ri.app.prod.user.123")
for version in history:
    print(f"Version {version.version}: {version.name}")
```

### ⚠️ Known Limitations

1. **SCD Type 2 Constraint**: `registro.Resource` has `UNIQUE` constraint on `rid`, preventing true SCD Type 2 (multiple versions with same RID). Each "update" creates new resource with new RID. Full SCD Type 2 requires schema change in `registro`.

2. **Performance**: Bulk operations (100+ records) may be slow due to outbox processing. Consider disabling outbox for batch imports.

### 📊 Statistics

- **Lines Added**: ~3,000
- **Lines Removed**: ~200
- **New Files**: 7
- **Modified Files**: 5
- **New Tests**: 34
- **Test Coverage**: 100% (Domain Envelope + Time Travel)
- **Breaking Changes**: 3 (documented above)

### 🎓 Learning Resources

- [Migration Guide](MIGRATION_DOMAIN_ENVELOPE.md)
- [Technical Summary](REFACTORING_SUMMARY.md)
- [Test Results](TEST_RESULTS.md)
- [Practical Example](examples/domain_envelope_example.py)

---

## [0.3.0] - 2024-11-24

### 🚀 Major Features - State of the Art Upgrade

This release transforms Malha into a **distributed data kernel** with production-grade concurrency control and P2P mesh replication.

#### Added

**Distributed Replication (Synapse)**
- New `ReplicationDriver` protocol for pluggable P2P drivers
- `SynapseDriver` implementation using gRPC bidirectional streaming
- Protocol buffer schema (`malha/protos/synapse.proto`)
- Automatic peer connection management
- Transaction ID deduplication for idempotency
- Health check endpoint for monitoring
- Loop prevention via origin tracking

**Concurrency Hardening**
- Pessimistic locking with `SELECT FOR UPDATE` in `save_versioned()`
- Prevents race conditions in SCD Type 2 version rotation
- Guarantees atomic closure of active versions under high load

**Resilient Outbox Processing**
- Dead Letter Queue (DLQ) for events that fail after 5 retries
- Exponential backoff retry strategy (2^n seconds)
- Non-blocking error handling
- Status tracking: `PENDING`, `RETRY`, `DONE`, `DEAD_LETTER`

**New SysOutbox Fields**
- `origin_node` (str): Tracks event origin for loop prevention
- `retries` (int): Counts retry attempts
- `next_retry_at` (datetime): Schedules next retry

**Documentation**
- `SYNAPSE.md`: Complete architecture and usage guide
- `QUICKSTART.md`: Installation and setup instructions
- `IMPLEMENTATION_STATUS.md`: Detailed implementation status
- `examples/distributed_cluster.py`: 3-node cluster example
- `scripts/compile_protos.py`: Proto compilation utility
- `migrations/001_add_synapse_fields.sql`: Database migration

**Testing**
- Integration test suite for Synapse features
- Tests for pessimistic locking
- Tests for DLQ and retry logic
- Tests for loop prevention

#### Changed

**Dependencies**
- Updated `politipo` from 0.4.2 to 0.5.1
- Updated `registro` from 0.3.1 to 0.5.1
- Added `pyarrow>=10.0.0` as core dependency

**UnifiedDataManager**
- Added optional `replication_driver` parameter to constructor
- Modified `save_versioned()` to accept `origin` parameter
- Enhanced `_process_outbox()` with resilience features
- Improved `close()` to handle non-async driver cleanup

**AsyncSQLAlchemyDriver**
- Fixed pool configuration for SQLite vs PostgreSQL
- Disabled echo logging in tests
- Improved connection pooling logic

**BaseResource**
- Updated to use Pydantic v2 `ConfigDict` instead of `class Config`
- Removed deprecation warnings

#### Fixed

- SQLAlchemy pool configuration errors with SQLite `:memory:` databases
- Pydantic v2 compatibility warnings
- DuckDB `close()` method async handling
- Datetime serialization in JSON payloads

### 📦 Optional Dependencies

New `synapse` extra for distributed replication:

```bash
pip install malha[synapse]
```

Includes:
- `grpcio>=1.60.0`
- `grpcio-tools>=1.60.0`
- `protobuf>=4.25.0`

### 🔄 Migration Guide

#### Database Migration

For existing databases, run:

```sql
-- SQLite
ALTER TABLE sys_outbox ADD COLUMN origin_node TEXT DEFAULT 'local';
ALTER TABLE sys_outbox ADD COLUMN retries INTEGER DEFAULT 0;
ALTER TABLE sys_outbox ADD COLUMN next_retry_at TIMESTAMP NULL;
CREATE INDEX idx_outbox_origin_node ON sys_outbox(origin_node);
```

Or use the provided migration file:

```bash
sqlite3 your_database.db < migrations/001_add_synapse_fields.sql
```

#### Code Changes

**Before (v0.2.x):**
```python
manager = await connect(
    url="sqlite+aiosqlite:///data.db",
    kuzu_path="data/kuzu"
)
```

**After (v0.3.0 - with replication):**
```python
from malha.drivers.synapse import SynapseDriver

synapse = SynapseDriver(
    kernel_ref=None,
    node_id="node-1",
    port=50051,
    peers=["192.168.1.10:50051"]
)

manager = await connect(
    url="sqlite+aiosqlite:///data.db",
    kuzu_path="data/kuzu",
    replication_driver=synapse  # ← New parameter
)
```

**Note:** Replication is **optional**. Existing code works without changes.

### ⚠️ Breaking Changes

None. This release is **backward compatible** with v0.2.x.

### 🐛 Known Issues

1. **SQLite Limitations**: `FOR UPDATE` may not work as expected with `:memory:` databases. Use PostgreSQL for production.
2. **Proto Compilation Required**: Synapse features require running `python scripts/compile_protos.py` before use.
3. **Test Coverage**: Integration tests at 50% coverage. Some edge cases need refinement.

### 📊 Statistics

- **Lines Added**: ~2,500
- **New Files**: 8
- **Modified Files**: 3
- **New Dependencies**: 3 (optional)
- **Test Coverage**: 50% (integration tests)

---

## [0.2.4] - 2024-11-XX

### Changed
- Improved repository pattern implementation
- Enhanced async session management
- Better error handling in outbox processor

### Fixed
- Session lifecycle issues
- Transaction commit errors

---

## [0.2.0] - 2024-XX-XX

### Added
- UnifiedDataManager with SQL, Graph, and Analytics drivers
- Outbox pattern for dual-write consistency
- KuzuActor for thread-safe graph operations
- DuckDBDriver for zero-copy analytics
- Repository pattern with optimistic locking
- Signal system for event handling

### Changed
- Migrated from v4 architecture to v5
- Async-first design throughout
- Improved type safety with Protocols

---

## [0.1.0] - 2024-XX-XX

### Added
- Initial release
- Basic data management capabilities
- SQLModel integration
- Pydantic support

---

## Upgrade Path

### From 0.2.x to 0.3.0

1. **Update dependencies:**
   ```bash
   pip install --upgrade malha
   ```

2. **Run database migration:**
   ```bash
   sqlite3 your_db.db < migrations/001_add_synapse_fields.sql
   ```

3. **(Optional) Install Synapse dependencies:**
   ```bash
   pip install malha[synapse]
   python scripts/compile_protos.py
   ```

4. **Update code** (only if using replication):
   ```python
   # Add replication_driver parameter
   manager = await connect(..., replication_driver=synapse)
   ```

### From 0.1.x to 0.3.0

Not recommended. Migrate to 0.2.x first, then to 0.3.0.

---

## Deprecations

None in this release.

---

## Security

No security vulnerabilities fixed in this release.

**Note**: Synapse P2P communication is currently **unencrypted**. For production use:
- Deploy on private networks
- Use VPN or firewall rules
- TLS/mTLS support planned for v0.4.0

---

## Contributors

- Kevin Saltarelli (@kevinsaltarelli) - Lead Developer

---

## Links

- [Documentation](README.md)
- [Synapse Guide](SYNAPSE.md)
- [Quick Start](QUICKSTART.md)
- [Implementation Status](IMPLEMENTATION_STATUS.md)
- [GitHub Repository](https://github.com/yourusername/malha)

---

[0.3.0]: https://github.com/yourusername/malha/compare/v0.2.4...v0.3.0
[0.2.4]: https://github.com/yourusername/malha/compare/v0.2.0...v0.2.4
[0.2.0]: https://github.com/yourusername/malha/compare/v0.1.0...v0.2.0
[0.1.0]: https://github.com/yourusername/malha/releases/tag/v0.1.0
