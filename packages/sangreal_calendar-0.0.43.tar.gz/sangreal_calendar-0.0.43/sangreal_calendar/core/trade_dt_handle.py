from functools import lru_cache

import pandas as pd
from sangreal_calendar.utils import dt_handle


# Constants for configuration
DEFAULT_BEGIN_DATE = '19900101'
DEFAULT_END_DATE = '20990101'
MAX_STEP_FORWARD = 600
MAX_STEP_BACKWARD = 600


class CalendarBase:
    def __init__(self, dates=None) -> None:
        # Initialize with empty Series if no dates provided
        if dates is None:
            self._dates = pd.Series(dtype='str')
        else:
            self._dates = dates

    @property
    def dates(self):
        return self._dates

    def inject(self, dates):
        if isinstance(dates, pd.Series):
            tmp_dates = dates
        else:
            tmp_dates = pd.Series(dates)
        tmp_dates = pd.to_datetime(tmp_dates).dt.strftime('%Y%m%d')
        self._dates = tmp_dates
        return


CALENDAR = CalendarBase()


@lru_cache(maxsize=128)
def get_trade_dts(begin_dt=DEFAULT_BEGIN_DATE, end_dt=DEFAULT_END_DATE):
    """[获取指定时间段的所有交易日]

    Keyword Arguments:
        begin_dt {str or datetime} -- [begin_dt] (default: {'19900101'})
        end_dt {str or datetime} -- [end_dt] (default: {'20990101'})

    Returns:
        [pd.Series] -- [trade_dts between begin_dt and end_dt]
    """
    # Use cached dates and avoid unnecessary copying
    dates = CALENDAR.dates
    begin_dt, end_dt = dt_handle(begin_dt), dt_handle(end_dt)

    # Use boolean indexing for efficient filtering
    mask = (dates >= begin_dt) & (dates <= end_dt)
    result = dates[mask].reset_index(drop=True)
    return result


@lru_cache(maxsize=1024)
def adjust_trade_dt(date, adjust='last'):
    """[adjust trade_dt]

    Arguments:
        date {[str or datetime]} -- [date]

    Keyword Arguments:
        adjust {str} -- [last or next] (default: {'last'})

    Raises:
        ValueError -- [f"adjust:{adjust} must be 'last' or 'next'!"]

    Returns:
        [str] -- [adjusted trade_dt with %Y%m%d type]
    """
    dates = CALENDAR.dates
    date = dt_handle(date)

    if adjust == 'last':
        # Use searchsorted for efficient finding
        idx = dates.searchsorted(date, side='right') - 1
        return dates.iloc[max(0, idx)]
    elif adjust == 'next':
        # Use searchsorted for efficient finding
        idx = dates.searchsorted(date, side='left')
        return dates.iloc[min(idx, len(dates) - 1)]
    else:
        raise ValueError(f"adjust:{adjust} must be 'last' or 'next'!")


@lru_cache(maxsize=1024)
def step_trade_dt(date, step=1):
    """[step trade_dt]

    Arguments:
        date {[str or datetime]} -- [date]

    Keyword Arguments:
        step {int} -- [step] (default: {1})

    Returns:
        [str] -- [date with %Y%m%d type]
    """
    dates = CALENDAR.dates
    date = dt_handle(date)

    if step >= 0:
        # Find first date >= input, then step forward
        idx = dates.searchsorted(date, side='left')
        target_idx = idx + step
        return dates.iloc[min(target_idx, len(dates) - 1)]
    else:
        # Find first date < input, then step backward
        idx = dates.searchsorted(date, side='left') - 1
        target_idx = idx + step  # step is negative
        return dates.iloc[max(target_idx, 0)]


@lru_cache(maxsize=1024)
def delta_trade_dt(begin_dt, end_dt):
    """[get length of trade_dt, include begin_dt and end_dt]

    Arguments:
        begin_dt {[str or datetime]} -- [begin_dt]
        end_dt {[tstr or datetime]} -- [end_dt]

    Returns:
        [int] -- [len of date_range]
    """
    dates = CALENDAR.dates
    begin_dt, end_dt = dt_handle(begin_dt), dt_handle(end_dt)

    # Use searchsorted for efficient range calculation
    start_idx = dates.searchsorted(begin_dt, side='left')
    end_idx = dates.searchsorted(end_dt, side='right')
    return end_idx - start_idx


if __name__ == "__main__":
    pass