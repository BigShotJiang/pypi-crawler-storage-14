To configure this module, you need to:

1. Go to Inventory App > Configuration > Operation Type.
1. Select incoming operation type like returns or create new.
1. Activate **Show Pick-up Address in report**.
