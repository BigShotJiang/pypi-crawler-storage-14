This module extends the functionality of stock and show pick-up address in incoming reports, like returns.
