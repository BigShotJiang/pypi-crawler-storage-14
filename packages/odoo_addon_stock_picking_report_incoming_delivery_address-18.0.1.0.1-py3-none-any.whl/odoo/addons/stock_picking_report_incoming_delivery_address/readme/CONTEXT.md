This module was developed because sometimes in incoming transaction types it is necessary to show the pick-up address, such as returns.

It will be useful if the carrier has to pick up the goods at the address where they were delivered.
