To use this module, you need to:

1. Go to Inventory App.
1. Create transfer with operation type configured to show pick-up address in report.
1. Print report **Delivery Slip** or **Picking Operations**.
