from setuptools import setup, find_packages
import pathlib

# Read README.md
HERE = pathlib.Path(__file__).parent
README = (HERE / "README.md").read_text(encoding="utf-8")

setup(
    name="guide_framework",
    version="1.0.8",   # <-- UPDATED VERSION
    description="GUIDE Framework – Ethical AI Governance, Explainability (XAI), Transparency & Responsible AI Auditing.",
    long_description=README,
    long_description_content_type="text/markdown",

    author="Kamal Master",
    author_email="ktabine@gmail.com",
    url="https://github.com/yourusername/guide-framework",

    packages=find_packages(),
    include_package_data=True,

    install_requires=[
        "openai",
        "requests",
        "numpy",
        "pandas",
        "scikit-learn"
    ],

    python_requires=">=3.8",

    classifiers=[
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Topic :: Scientific/Engineering :: Artificial Intelligence",
        "Topic :: Software Development :: Libraries :: Python Modules",
        "Intended Audience :: Developers",
        "Intended Audience :: Education",
        "Intended Audience :: Science/Research",
        "Intended Audience :: Information Technology",
    ],

    keywords=[
        "ethical-ai",
        "ai-governance",
        "xai",
        "explainability",
        "transparency",
        "responsible-ai",
        "fairness",
        "bias-audit",
        "equity",
        "governance",
        "guide-framework",
    ],
)
