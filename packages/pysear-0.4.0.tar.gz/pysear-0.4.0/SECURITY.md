# Security policy

To report a security vulnerability, use the [Report a vulnerability](https://github.com/Mainframe-Renewal-Project/sear/security/advisories/new) feature in GitHub.
