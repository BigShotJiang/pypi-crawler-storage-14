# Code of Conduct

All participants agree to abide by The [Linux Foundation Code of Conduct](http://events.linuxfoundation.org/code-of-conduct).

Additionally participants agree to abide by the [IBM Business Conduct Guidelines](https://www.ibm.com/investor/governance/business-conduct-guidelines).
