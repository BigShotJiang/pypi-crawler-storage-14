"""
Backward compatibility shim for the previous `pret.ui.joy` import path.
"""
from pret_joy import *  # noqa: F401,F403
