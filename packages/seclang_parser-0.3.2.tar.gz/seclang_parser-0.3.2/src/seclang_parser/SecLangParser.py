# Generated from SecLangParser.g4 by ANTLR 4.13.2
# encoding: utf-8
from antlr4 import *
from io import StringIO
import sys
if sys.version_info[1] > 5:
	from typing import TextIO
else:
	from typing.io import TextIO

def serializedATN():
    return [
        4,1,270,687,2,0,7,0,2,1,7,1,2,2,7,2,2,3,7,3,2,4,7,4,2,5,7,5,2,6,
        7,6,2,7,7,7,2,8,7,8,2,9,7,9,2,10,7,10,2,11,7,11,2,12,7,12,2,13,7,
        13,2,14,7,14,2,15,7,15,2,16,7,16,2,17,7,17,2,18,7,18,2,19,7,19,2,
        20,7,20,2,21,7,21,2,22,7,22,2,23,7,23,2,24,7,24,2,25,7,25,2,26,7,
        26,2,27,7,27,2,28,7,28,2,29,7,29,2,30,7,30,2,31,7,31,2,32,7,32,2,
        33,7,33,2,34,7,34,2,35,7,35,2,36,7,36,2,37,7,37,2,38,7,38,2,39,7,
        39,2,40,7,40,2,41,7,41,2,42,7,42,2,43,7,43,2,44,7,44,2,45,7,45,2,
        46,7,46,2,47,7,47,2,48,7,48,2,49,7,49,2,50,7,50,2,51,7,51,2,52,7,
        52,2,53,7,53,2,54,7,54,2,55,7,55,2,56,7,56,2,57,7,57,2,58,7,58,2,
        59,7,59,2,60,7,60,2,61,7,61,2,62,7,62,2,63,7,63,2,64,7,64,2,65,7,
        65,2,66,7,66,2,67,7,67,2,68,7,68,2,69,7,69,1,0,5,0,142,8,0,10,0,
        12,0,145,9,0,1,0,1,0,1,1,3,1,150,8,1,1,1,1,1,1,1,1,1,3,1,156,8,1,
        1,1,3,1,159,8,1,1,1,1,1,1,1,3,1,164,8,1,1,1,3,1,167,8,1,1,1,1,1,
        1,1,1,1,1,1,3,1,174,8,1,1,1,3,1,177,8,1,1,1,1,1,4,1,181,8,1,11,1,
        12,1,182,1,1,3,1,186,8,1,1,1,1,1,1,1,1,1,3,1,192,8,1,1,1,1,1,1,1,
        1,1,1,1,1,1,3,1,200,8,1,1,1,1,1,1,1,1,1,1,1,3,1,207,8,1,1,1,1,1,
        1,1,1,1,1,1,1,1,1,1,3,1,216,8,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,3,1,
        225,8,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,3,1,236,8,1,1,1,1,1,
        1,1,1,1,1,1,3,1,243,8,1,1,1,1,1,4,1,247,8,1,11,1,12,1,248,3,1,251,
        8,1,1,2,4,2,254,8,2,11,2,12,2,255,1,2,3,2,259,8,2,1,3,1,3,3,3,263,
        8,3,1,4,1,4,1,5,1,5,1,5,1,5,1,5,1,5,1,5,1,5,1,5,1,5,1,5,1,5,1,5,
        1,5,1,5,1,5,1,5,1,5,1,5,1,5,1,5,1,5,1,5,1,5,1,5,1,5,1,5,1,5,3,5,
        295,8,5,1,6,1,6,1,6,1,6,3,6,301,8,6,1,7,1,7,1,8,1,8,1,9,1,9,1,10,
        1,10,1,11,1,11,1,12,1,12,3,12,315,8,12,1,13,1,13,1,13,1,13,1,14,
        1,14,1,14,1,14,1,15,1,15,1,16,1,16,1,17,1,17,3,17,331,8,17,1,18,
        1,18,1,19,1,19,1,19,3,19,338,8,19,1,20,1,20,1,21,1,21,1,22,1,22,
        1,23,1,23,1,23,1,23,5,23,350,8,23,10,23,12,23,353,9,23,1,23,1,23,
        1,24,1,24,1,24,1,24,1,25,1,25,1,26,1,26,3,26,365,8,26,1,27,1,27,
        1,28,1,28,1,28,1,28,1,28,1,28,1,28,1,28,1,28,1,28,1,28,1,28,1,28,
        1,28,1,28,1,28,1,28,1,28,1,28,1,28,1,28,1,28,1,28,3,28,392,8,28,
        1,29,1,29,1,29,1,29,1,29,1,29,3,29,400,8,29,1,29,1,29,1,29,1,29,
        1,29,1,29,1,29,1,29,3,29,410,8,29,1,29,1,29,1,29,1,29,3,29,416,8,
        29,3,29,418,8,29,1,30,1,30,1,30,3,30,423,8,30,1,31,1,31,1,32,1,32,
        3,32,429,8,32,1,32,1,32,1,32,3,32,434,8,32,1,32,1,32,1,32,1,32,1,
        32,1,32,1,32,3,32,443,8,32,1,33,1,33,1,34,1,34,1,34,5,34,450,8,34,
        10,34,12,34,453,9,34,1,34,1,34,3,34,457,8,34,1,34,1,34,5,34,461,
        8,34,10,34,12,34,464,9,34,1,34,1,34,3,34,468,8,34,5,34,470,8,34,
        10,34,12,34,473,9,34,1,34,1,34,3,34,477,8,34,1,35,1,35,1,36,1,36,
        1,37,3,37,484,8,37,1,37,3,37,487,8,37,1,37,3,37,490,8,37,1,37,1,
        37,3,37,494,8,37,1,37,1,37,3,37,498,8,37,1,37,3,37,501,8,37,1,37,
        1,37,3,37,505,8,37,5,37,507,8,37,10,37,12,37,510,9,37,1,38,3,38,
        513,8,38,1,38,3,38,516,8,38,1,38,3,38,519,8,38,1,38,1,38,3,38,523,
        8,38,1,38,1,38,3,38,527,8,38,1,38,3,38,530,8,38,1,38,1,38,3,38,534,
        8,38,5,38,536,8,38,10,38,12,38,539,9,38,1,39,1,39,1,40,1,40,1,40,
        1,40,3,40,547,8,40,3,40,549,8,40,1,41,1,41,1,42,1,42,1,43,1,43,1,
        44,1,44,1,45,1,45,1,45,1,45,5,45,563,8,45,10,45,12,45,566,9,45,1,
        45,1,45,1,46,1,46,1,46,3,46,573,8,46,1,46,3,46,576,8,46,1,46,1,46,
        1,46,1,46,1,46,1,46,1,46,1,46,1,46,1,46,3,46,588,8,46,1,47,1,47,
        1,47,3,47,593,8,47,1,48,1,48,1,49,1,49,1,50,1,50,1,51,1,51,1,51,
        1,51,1,51,3,51,606,8,51,1,52,1,52,1,52,1,52,1,52,1,52,1,52,1,52,
        3,52,616,8,52,1,53,1,53,1,54,1,54,1,55,1,55,1,56,1,56,1,57,1,57,
        1,57,1,57,1,57,1,57,1,57,1,57,1,57,3,57,635,8,57,1,58,1,58,1,58,
        1,58,1,58,1,58,1,58,1,58,1,58,1,58,1,58,3,58,648,8,58,1,59,1,59,
        1,60,1,60,1,61,1,61,1,62,1,62,1,62,3,62,659,8,62,1,63,1,63,1,63,
        3,63,664,8,63,1,64,1,64,1,64,1,64,1,64,1,64,1,65,1,65,1,66,1,66,
        1,66,4,66,677,8,66,11,66,12,66,678,1,67,1,67,1,68,1,68,1,69,1,69,
        1,69,0,0,70,0,2,4,6,8,10,12,14,16,18,20,22,24,26,28,30,32,34,36,
        38,40,42,44,46,48,50,52,54,56,58,60,62,64,66,68,70,72,74,76,78,80,
        82,84,86,88,90,92,94,96,98,100,102,104,106,108,110,112,114,116,118,
        120,122,124,126,128,130,132,134,136,138,0,15,1,1,259,259,8,0,131,
        139,150,167,169,175,178,178,180,180,182,183,185,185,209,216,3,0,
        225,225,233,233,241,241,3,0,140,149,193,197,227,227,1,0,89,125,2,
        0,85,85,87,87,5,0,27,27,30,30,44,44,46,46,58,59,5,0,29,29,31,31,
        52,52,55,57,67,67,1,0,62,63,8,0,28,28,33,33,45,45,47,48,50,51,61,
        61,65,66,68,74,2,0,79,79,82,82,1,0,77,78,1,0,34,43,2,0,3,3,5,6,1,
        0,226,227,758,0,143,1,0,0,0,2,250,1,0,0,0,4,253,1,0,0,0,6,260,1,
        0,0,0,8,264,1,0,0,0,10,294,1,0,0,0,12,300,1,0,0,0,14,302,1,0,0,0,
        16,304,1,0,0,0,18,306,1,0,0,0,20,308,1,0,0,0,22,310,1,0,0,0,24,314,
        1,0,0,0,26,316,1,0,0,0,28,320,1,0,0,0,30,324,1,0,0,0,32,326,1,0,
        0,0,34,330,1,0,0,0,36,332,1,0,0,0,38,337,1,0,0,0,40,339,1,0,0,0,
        42,341,1,0,0,0,44,343,1,0,0,0,46,345,1,0,0,0,48,356,1,0,0,0,50,360,
        1,0,0,0,52,364,1,0,0,0,54,366,1,0,0,0,56,391,1,0,0,0,58,417,1,0,
        0,0,60,422,1,0,0,0,62,424,1,0,0,0,64,442,1,0,0,0,66,444,1,0,0,0,
        68,476,1,0,0,0,70,478,1,0,0,0,72,480,1,0,0,0,74,483,1,0,0,0,76,512,
        1,0,0,0,78,540,1,0,0,0,80,548,1,0,0,0,82,550,1,0,0,0,84,552,1,0,
        0,0,86,554,1,0,0,0,88,556,1,0,0,0,90,558,1,0,0,0,92,587,1,0,0,0,
        94,592,1,0,0,0,96,594,1,0,0,0,98,596,1,0,0,0,100,598,1,0,0,0,102,
        605,1,0,0,0,104,615,1,0,0,0,106,617,1,0,0,0,108,619,1,0,0,0,110,
        621,1,0,0,0,112,623,1,0,0,0,114,634,1,0,0,0,116,647,1,0,0,0,118,
        649,1,0,0,0,120,651,1,0,0,0,122,653,1,0,0,0,124,658,1,0,0,0,126,
        663,1,0,0,0,128,665,1,0,0,0,130,671,1,0,0,0,132,676,1,0,0,0,134,
        680,1,0,0,0,136,682,1,0,0,0,138,684,1,0,0,0,140,142,3,2,1,0,141,
        140,1,0,0,0,142,145,1,0,0,0,143,141,1,0,0,0,143,144,1,0,0,0,144,
        146,1,0,0,0,145,143,1,0,0,0,146,147,5,0,0,1,147,1,1,0,0,0,148,150,
        3,4,2,0,149,148,1,0,0,0,149,150,1,0,0,0,150,151,1,0,0,0,151,152,
        3,8,4,0,152,153,3,74,37,0,153,155,3,64,32,0,154,156,3,90,45,0,155,
        154,1,0,0,0,155,156,1,0,0,0,156,251,1,0,0,0,157,159,3,4,2,0,158,
        157,1,0,0,0,158,159,1,0,0,0,159,160,1,0,0,0,160,161,3,18,9,0,161,
        163,3,20,10,0,162,164,3,90,45,0,163,162,1,0,0,0,163,164,1,0,0,0,
        164,251,1,0,0,0,165,167,3,4,2,0,166,165,1,0,0,0,166,167,1,0,0,0,
        167,168,1,0,0,0,168,169,3,18,9,0,169,170,5,1,0,0,170,171,3,20,10,
        0,171,173,5,1,0,0,172,174,3,90,45,0,173,172,1,0,0,0,173,174,1,0,
        0,0,174,251,1,0,0,0,175,177,3,4,2,0,176,175,1,0,0,0,176,177,1,0,
        0,0,177,178,1,0,0,0,178,180,3,22,11,0,179,181,3,24,12,0,180,179,
        1,0,0,0,181,182,1,0,0,0,182,180,1,0,0,0,182,183,1,0,0,0,183,251,
        1,0,0,0,184,186,3,4,2,0,185,184,1,0,0,0,185,186,1,0,0,0,186,187,
        1,0,0,0,187,188,3,34,17,0,188,189,3,36,18,0,189,251,1,0,0,0,190,
        192,3,4,2,0,191,190,1,0,0,0,191,192,1,0,0,0,192,193,1,0,0,0,193,
        194,3,34,17,0,194,195,5,1,0,0,195,196,3,36,18,0,196,197,5,1,0,0,
        197,251,1,0,0,0,198,200,3,4,2,0,199,198,1,0,0,0,199,200,1,0,0,0,
        200,201,1,0,0,0,201,202,3,38,19,0,202,203,3,60,30,0,203,204,3,76,
        38,0,204,251,1,0,0,0,205,207,3,4,2,0,206,205,1,0,0,0,206,207,1,0,
        0,0,207,208,1,0,0,0,208,209,3,38,19,0,209,210,5,1,0,0,210,211,3,
        60,30,0,211,212,5,1,0,0,212,213,3,76,38,0,213,251,1,0,0,0,214,216,
        3,4,2,0,215,214,1,0,0,0,215,216,1,0,0,0,216,217,1,0,0,0,217,218,
        3,38,19,0,218,219,3,60,30,0,219,220,3,76,38,0,220,221,5,8,0,0,221,
        222,3,78,39,0,222,251,1,0,0,0,223,225,3,4,2,0,224,223,1,0,0,0,224,
        225,1,0,0,0,225,226,1,0,0,0,226,227,3,38,19,0,227,228,5,1,0,0,228,
        229,3,60,30,0,229,230,5,1,0,0,230,231,3,76,38,0,231,232,5,8,0,0,
        232,233,3,78,39,0,233,251,1,0,0,0,234,236,3,4,2,0,235,234,1,0,0,
        0,235,236,1,0,0,0,236,237,1,0,0,0,237,238,3,40,20,0,238,239,3,42,
        21,0,239,240,3,90,45,0,240,251,1,0,0,0,241,243,3,4,2,0,242,241,1,
        0,0,0,242,243,1,0,0,0,243,244,1,0,0,0,244,251,3,10,5,0,245,247,3,
        4,2,0,246,245,1,0,0,0,247,248,1,0,0,0,248,246,1,0,0,0,248,249,1,
        0,0,0,249,251,1,0,0,0,250,149,1,0,0,0,250,158,1,0,0,0,250,166,1,
        0,0,0,250,176,1,0,0,0,250,185,1,0,0,0,250,191,1,0,0,0,250,199,1,
        0,0,0,250,206,1,0,0,0,250,215,1,0,0,0,250,224,1,0,0,0,250,235,1,
        0,0,0,250,242,1,0,0,0,250,246,1,0,0,0,251,3,1,0,0,0,252,254,3,6,
        3,0,253,252,1,0,0,0,254,255,1,0,0,0,255,253,1,0,0,0,255,256,1,0,
        0,0,256,258,1,0,0,0,257,259,7,0,0,0,258,257,1,0,0,0,258,259,1,0,
        0,0,259,5,1,0,0,0,260,262,5,12,0,0,261,263,5,257,0,0,262,261,1,0,
        0,0,262,263,1,0,0,0,263,7,1,0,0,0,264,265,5,217,0,0,265,9,1,0,0,
        0,266,267,3,54,27,0,267,268,3,56,28,0,268,295,1,0,0,0,269,270,3,
        54,27,0,270,271,5,1,0,0,271,272,3,56,28,0,272,273,5,1,0,0,273,295,
        1,0,0,0,274,275,3,52,26,0,275,276,3,90,45,0,276,295,1,0,0,0,277,
        278,3,12,6,0,278,279,5,1,0,0,279,280,3,56,28,0,280,281,5,1,0,0,281,
        295,1,0,0,0,282,283,3,14,7,0,283,284,5,1,0,0,284,285,3,56,28,0,285,
        286,5,1,0,0,286,295,1,0,0,0,287,288,3,16,8,0,288,289,3,56,28,0,289,
        295,1,0,0,0,290,291,3,44,22,0,291,292,3,56,28,0,292,293,3,46,23,
        0,293,295,1,0,0,0,294,266,1,0,0,0,294,269,1,0,0,0,294,274,1,0,0,
        0,294,277,1,0,0,0,294,282,1,0,0,0,294,287,1,0,0,0,294,290,1,0,0,
        0,295,11,1,0,0,0,296,301,1,0,0,0,297,301,5,127,0,0,298,301,5,128,
        0,0,299,301,5,129,0,0,300,296,1,0,0,0,300,297,1,0,0,0,300,298,1,
        0,0,0,300,299,1,0,0,0,301,13,1,0,0,0,302,303,5,179,0,0,303,15,1,
        0,0,0,304,305,7,1,0,0,305,17,1,0,0,0,306,307,5,218,0,0,307,19,1,
        0,0,0,308,309,5,9,0,0,309,21,1,0,0,0,310,311,5,186,0,0,311,23,1,
        0,0,0,312,315,5,227,0,0,313,315,3,28,14,0,314,312,1,0,0,0,314,313,
        1,0,0,0,315,25,1,0,0,0,316,317,5,261,0,0,317,318,5,262,0,0,318,319,
        5,261,0,0,319,27,1,0,0,0,320,321,3,30,15,0,321,322,5,14,0,0,322,
        323,3,32,16,0,323,29,1,0,0,0,324,325,5,227,0,0,325,31,1,0,0,0,326,
        327,5,227,0,0,327,33,1,0,0,0,328,331,5,187,0,0,329,331,5,188,0,0,
        330,328,1,0,0,0,330,329,1,0,0,0,331,35,1,0,0,0,332,333,7,2,0,0,333,
        37,1,0,0,0,334,338,5,191,0,0,335,338,5,190,0,0,336,338,5,189,0,0,
        337,334,1,0,0,0,337,335,1,0,0,0,337,336,1,0,0,0,338,39,1,0,0,0,339,
        340,5,192,0,0,340,41,1,0,0,0,341,342,5,227,0,0,342,43,1,0,0,0,343,
        344,5,130,0,0,344,45,1,0,0,0,345,346,5,1,0,0,346,351,3,48,24,0,347,
        348,5,7,0,0,348,350,3,48,24,0,349,347,1,0,0,0,350,353,1,0,0,0,351,
        349,1,0,0,0,351,352,1,0,0,0,352,354,1,0,0,0,353,351,1,0,0,0,354,
        355,5,1,0,0,355,47,1,0,0,0,356,357,3,50,25,0,357,358,5,4,0,0,358,
        359,3,56,28,0,359,49,1,0,0,0,360,361,5,219,0,0,361,51,1,0,0,0,362,
        365,5,176,0,0,363,365,5,177,0,0,364,362,1,0,0,0,364,363,1,0,0,0,
        365,53,1,0,0,0,366,367,7,3,0,0,367,55,1,0,0,0,368,392,5,227,0,0,
        369,392,3,28,14,0,370,392,5,202,0,0,371,392,5,201,0,0,372,392,5,
        207,0,0,373,392,5,203,0,0,374,392,5,200,0,0,375,392,5,206,0,0,376,
        392,5,223,0,0,377,392,5,198,0,0,378,392,5,208,0,0,379,392,5,199,
        0,0,380,392,5,204,0,0,381,392,5,205,0,0,382,383,5,9,0,0,383,392,
        5,227,0,0,384,392,5,9,0,0,385,392,5,233,0,0,386,392,5,225,0,0,387,
        392,5,241,0,0,388,392,5,245,0,0,389,392,5,126,0,0,390,392,3,58,29,
        0,391,368,1,0,0,0,391,369,1,0,0,0,391,370,1,0,0,0,391,371,1,0,0,
        0,391,372,1,0,0,0,391,373,1,0,0,0,391,374,1,0,0,0,391,375,1,0,0,
        0,391,376,1,0,0,0,391,377,1,0,0,0,391,378,1,0,0,0,391,379,1,0,0,
        0,391,380,1,0,0,0,391,381,1,0,0,0,391,382,1,0,0,0,391,384,1,0,0,
        0,391,385,1,0,0,0,391,386,1,0,0,0,391,387,1,0,0,0,391,388,1,0,0,
        0,391,389,1,0,0,0,391,390,1,0,0,0,392,57,1,0,0,0,393,400,3,138,69,
        0,394,395,5,2,0,0,395,396,3,118,59,0,396,397,5,2,0,0,397,400,1,0,
        0,0,398,400,5,225,0,0,399,393,1,0,0,0,399,394,1,0,0,0,399,398,1,
        0,0,0,400,401,1,0,0,0,401,402,5,18,0,0,402,418,3,84,42,0,403,410,
        3,138,69,0,404,405,5,2,0,0,405,406,3,118,59,0,406,407,5,2,0,0,407,
        410,1,0,0,0,408,410,5,225,0,0,409,403,1,0,0,0,409,404,1,0,0,0,409,
        408,1,0,0,0,410,411,1,0,0,0,411,412,5,18,0,0,412,415,3,88,44,0,413,
        414,5,4,0,0,414,416,3,126,63,0,415,413,1,0,0,0,415,416,1,0,0,0,416,
        418,1,0,0,0,417,399,1,0,0,0,417,409,1,0,0,0,418,59,1,0,0,0,419,423,
        5,227,0,0,420,423,3,28,14,0,421,423,5,233,0,0,422,419,1,0,0,0,422,
        420,1,0,0,0,422,421,1,0,0,0,423,61,1,0,0,0,424,425,5,10,0,0,425,
        63,1,0,0,0,426,428,5,1,0,0,427,429,3,62,31,0,428,427,1,0,0,0,428,
        429,1,0,0,0,429,430,1,0,0,0,430,431,5,255,0,0,431,433,3,66,33,0,
        432,434,3,68,34,0,433,432,1,0,0,0,433,434,1,0,0,0,434,435,1,0,0,
        0,435,436,5,1,0,0,436,443,1,0,0,0,437,438,5,1,0,0,438,439,3,68,34,
        0,439,440,5,1,0,0,440,443,1,0,0,0,441,443,3,68,34,0,442,426,1,0,
        0,0,442,437,1,0,0,0,442,441,1,0,0,0,443,65,1,0,0,0,444,445,7,4,0,
        0,445,67,1,0,0,0,446,477,3,82,41,0,447,477,5,233,0,0,448,450,5,263,
        0,0,449,448,1,0,0,0,450,453,1,0,0,0,451,449,1,0,0,0,451,452,1,0,
        0,0,452,456,1,0,0,0,453,451,1,0,0,0,454,457,5,261,0,0,455,457,3,
        26,13,0,456,454,1,0,0,0,456,455,1,0,0,0,457,471,1,0,0,0,458,462,
        5,7,0,0,459,461,5,263,0,0,460,459,1,0,0,0,461,464,1,0,0,0,462,460,
        1,0,0,0,462,463,1,0,0,0,463,467,1,0,0,0,464,462,1,0,0,0,465,468,
        5,261,0,0,466,468,3,26,13,0,467,465,1,0,0,0,467,466,1,0,0,0,468,
        470,1,0,0,0,469,458,1,0,0,0,470,473,1,0,0,0,471,469,1,0,0,0,471,
        472,1,0,0,0,472,477,1,0,0,0,473,471,1,0,0,0,474,477,5,254,0,0,475,
        477,5,256,0,0,476,446,1,0,0,0,476,447,1,0,0,0,476,451,1,0,0,0,476,
        474,1,0,0,0,476,475,1,0,0,0,477,69,1,0,0,0,478,479,5,10,0,0,479,
        71,1,0,0,0,480,481,5,88,0,0,481,73,1,0,0,0,482,484,5,1,0,0,483,482,
        1,0,0,0,483,484,1,0,0,0,484,486,1,0,0,0,485,487,3,70,35,0,486,485,
        1,0,0,0,486,487,1,0,0,0,487,489,1,0,0,0,488,490,3,72,36,0,489,488,
        1,0,0,0,489,490,1,0,0,0,490,491,1,0,0,0,491,493,3,80,40,0,492,494,
        5,1,0,0,493,492,1,0,0,0,493,494,1,0,0,0,494,508,1,0,0,0,495,497,
        5,8,0,0,496,498,5,1,0,0,497,496,1,0,0,0,497,498,1,0,0,0,498,500,
        1,0,0,0,499,501,3,70,35,0,500,499,1,0,0,0,500,501,1,0,0,0,501,502,
        1,0,0,0,502,504,3,80,40,0,503,505,5,1,0,0,504,503,1,0,0,0,504,505,
        1,0,0,0,505,507,1,0,0,0,506,495,1,0,0,0,507,510,1,0,0,0,508,506,
        1,0,0,0,508,509,1,0,0,0,509,75,1,0,0,0,510,508,1,0,0,0,511,513,5,
        1,0,0,512,511,1,0,0,0,512,513,1,0,0,0,513,515,1,0,0,0,514,516,3,
        70,35,0,515,514,1,0,0,0,515,516,1,0,0,0,516,518,1,0,0,0,517,519,
        3,72,36,0,518,517,1,0,0,0,518,519,1,0,0,0,519,520,1,0,0,0,520,522,
        3,80,40,0,521,523,5,1,0,0,522,521,1,0,0,0,522,523,1,0,0,0,523,537,
        1,0,0,0,524,526,5,7,0,0,525,527,5,1,0,0,526,525,1,0,0,0,526,527,
        1,0,0,0,527,529,1,0,0,0,528,530,3,70,35,0,529,528,1,0,0,0,529,530,
        1,0,0,0,530,531,1,0,0,0,531,533,3,80,40,0,532,534,5,1,0,0,533,532,
        1,0,0,0,533,534,1,0,0,0,534,536,1,0,0,0,535,524,1,0,0,0,536,539,
        1,0,0,0,537,535,1,0,0,0,537,538,1,0,0,0,538,77,1,0,0,0,539,537,1,
        0,0,0,540,541,3,80,40,0,541,79,1,0,0,0,542,549,3,82,41,0,543,546,
        3,86,43,0,544,545,5,4,0,0,545,547,3,124,62,0,546,544,1,0,0,0,546,
        547,1,0,0,0,547,549,1,0,0,0,548,542,1,0,0,0,548,543,1,0,0,0,549,
        81,1,0,0,0,550,551,5,86,0,0,551,83,1,0,0,0,552,553,5,86,0,0,553,
        85,1,0,0,0,554,555,7,5,0,0,555,87,1,0,0,0,556,557,7,5,0,0,557,89,
        1,0,0,0,558,559,5,1,0,0,559,564,3,92,46,0,560,561,5,7,0,0,561,563,
        3,92,46,0,562,560,1,0,0,0,563,566,1,0,0,0,564,562,1,0,0,0,564,565,
        1,0,0,0,565,567,1,0,0,0,566,564,1,0,0,0,567,568,5,1,0,0,568,91,1,
        0,0,0,569,570,3,102,51,0,570,572,5,4,0,0,571,573,5,10,0,0,572,571,
        1,0,0,0,572,573,1,0,0,0,573,575,1,0,0,0,574,576,5,3,0,0,575,574,
        1,0,0,0,575,576,1,0,0,0,576,577,1,0,0,0,577,578,3,114,57,0,578,588,
        1,0,0,0,579,580,3,102,51,0,580,581,5,4,0,0,581,582,3,114,57,0,582,
        588,1,0,0,0,583,584,5,83,0,0,584,585,5,4,0,0,585,588,3,122,61,0,
        586,588,3,94,47,0,587,569,1,0,0,0,587,579,1,0,0,0,587,583,1,0,0,
        0,587,586,1,0,0,0,588,93,1,0,0,0,589,593,3,96,48,0,590,593,3,98,
        49,0,591,593,3,100,50,0,592,589,1,0,0,0,592,590,1,0,0,0,592,591,
        1,0,0,0,593,95,1,0,0,0,594,595,7,6,0,0,595,97,1,0,0,0,596,597,7,
        7,0,0,597,99,1,0,0,0,598,599,5,32,0,0,599,101,1,0,0,0,600,606,3,
        104,52,0,601,606,3,106,53,0,602,606,3,108,54,0,603,606,3,112,56,
        0,604,606,3,110,55,0,605,600,1,0,0,0,605,601,1,0,0,0,605,602,1,0,
        0,0,605,603,1,0,0,0,605,604,1,0,0,0,606,103,1,0,0,0,607,616,5,60,
        0,0,608,616,5,49,0,0,609,616,5,53,0,0,610,616,5,54,0,0,611,616,5,
        64,0,0,612,616,5,75,0,0,613,616,5,80,0,0,614,616,5,81,0,0,615,607,
        1,0,0,0,615,608,1,0,0,0,615,609,1,0,0,0,615,610,1,0,0,0,615,611,
        1,0,0,0,615,612,1,0,0,0,615,613,1,0,0,0,615,614,1,0,0,0,616,105,
        1,0,0,0,617,618,7,8,0,0,618,107,1,0,0,0,619,620,7,9,0,0,620,109,
        1,0,0,0,621,622,7,10,0,0,622,111,1,0,0,0,623,624,7,11,0,0,624,113,
        1,0,0,0,625,635,3,116,58,0,626,627,5,2,0,0,627,628,3,116,58,0,628,
        629,5,2,0,0,629,635,1,0,0,0,630,631,5,2,0,0,631,632,3,118,59,0,632,
        633,5,2,0,0,633,635,1,0,0,0,634,625,1,0,0,0,634,626,1,0,0,0,634,
        630,1,0,0,0,635,115,1,0,0,0,636,648,5,227,0,0,637,648,3,124,62,0,
        638,648,3,128,64,0,639,640,3,120,60,0,640,641,3,134,67,0,641,642,
        3,56,28,0,642,648,1,0,0,0,643,648,5,225,0,0,644,648,5,76,0,0,645,
        648,5,231,0,0,646,648,5,241,0,0,647,636,1,0,0,0,647,637,1,0,0,0,
        647,638,1,0,0,0,647,639,1,0,0,0,647,643,1,0,0,0,647,644,1,0,0,0,
        647,645,1,0,0,0,647,646,1,0,0,0,648,117,1,0,0,0,649,650,5,246,0,
        0,650,119,1,0,0,0,651,652,7,12,0,0,652,121,1,0,0,0,653,654,5,84,
        0,0,654,123,1,0,0,0,655,659,1,0,0,0,656,659,5,243,0,0,657,659,5,
        250,0,0,658,655,1,0,0,0,658,656,1,0,0,0,658,657,1,0,0,0,659,125,
        1,0,0,0,660,664,1,0,0,0,661,664,5,243,0,0,662,664,5,250,0,0,663,
        660,1,0,0,0,663,661,1,0,0,0,663,662,1,0,0,0,664,127,1,0,0,0,665,
        666,3,130,65,0,666,667,5,236,0,0,667,668,3,132,66,0,668,669,3,134,
        67,0,669,670,3,136,68,0,670,129,1,0,0,0,671,672,5,235,0,0,672,131,
        1,0,0,0,673,677,5,237,0,0,674,675,5,238,0,0,675,677,5,234,0,0,676,
        673,1,0,0,0,676,674,1,0,0,0,677,678,1,0,0,0,678,676,1,0,0,0,678,
        679,1,0,0,0,679,133,1,0,0,0,680,681,7,13,0,0,681,135,1,0,0,0,682,
        683,5,239,0,0,683,137,1,0,0,0,684,685,7,14,0,0,685,139,1,0,0,0,75,
        143,149,155,158,163,166,173,176,182,185,191,199,206,215,224,235,
        242,248,250,255,258,262,294,300,314,330,337,351,364,391,399,409,
        415,417,422,428,433,442,451,456,462,467,471,476,483,486,489,493,
        497,500,504,508,512,515,518,522,526,529,533,537,546,548,564,572,
        575,587,592,605,615,634,647,658,663,676,678
    ]

class SecLangParser ( Parser ):

    grammarFileName = "SecLangParser.g4"

    atn = ATNDeserializer().deserialize(serializedATN())

    decisionsToDFA = [ DFA(ds, i) for i, ds in enumerate(atn.decisionToState) ]

    sharedContextCache = PredictionContextCache()

    literalNames = [ "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                     "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                     "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                     "'#'", "'+'", "<INVALID>", "'*'", "'/'", "':='", "';'", 
                     "'<>'", "'<'", "'<='", "'>='", "'>'", "'('", "')'", 
                     "'accuracy'", "<INVALID>", "'append'", "'auditlog'", 
                     "'block'", "'capture'", "'chain'", "'ctl'", "'auditEngine'", 
                     "'auditLogParts'", "'requestBodyProcessor'", "'forceRequestBodyVariable'", 
                     "'requestBodyAccess'", "'ruleEngine'", "'ruleRemoveByTag'", 
                     "'ruleRemoveById'", "'ruleRemoveTargetById'", "'ruleRemoveTargetByTag'", 
                     "'deny'", "'deprecatevar'", "'drop'", "'exec'", "'expirevar'", 
                     "'id'", "'initcol'", "'logdata'", "'log'", "'maturity'", 
                     "'msg'", "'multiMatch'", "'noauditlog'", "'nolog'", 
                     "'pass'", "'pause'", "'phase'", "'prepend'", "'proxy'", 
                     "'redirect'", "'rev'", "'sanitiseArg'", "'sanitiseMatchedBytes'", 
                     "'sanitiseMatched'", "'sanitiseRequestHeader'", "'sanitiseResponseHeader'", 
                     "'setenv'", "'setrsc'", "'setsid'", "'setuid'", "'setvar'", 
                     "'severity'", "<INVALID>", "'skipAfter'", "'skip'", 
                     "'status'", "'tag'", "'ver'", "'xmlns'", "'t'", "<INVALID>", 
                     "<INVALID>", "<INVALID>", "'XML'", "'&'", "'beginsWith'", 
                     "'contains'", "'containsWord'", "'detectSQLi'", "'detectXSS'", 
                     "'endsWith'", "'eq'", "'fuzzyHash'", "'ge'", "'geoLookup'", 
                     "'gsbLookup'", "'gt'", "'inspectFile'", "<INVALID>", 
                     "'ipMatch'", "'le'", "'lt'", "<INVALID>", "'pm'", "'rbl'", 
                     "'rsub'", "'rx'", "'rxGlobal'", "'streq'", "'strmatch'", 
                     "'unconditionalMatch'", "'validateByteRange'", "'validateDTD'", 
                     "'validateHash'", "'validateSchema'", "'validateUrlEncoding'", 
                     "'validateUtf8Encoding'", "'verifyCC'", "'verifyCPF'", 
                     "'verifySSN'", "'verifySVNR'", "'within'", "<INVALID>", 
                     "'SecComponentSignature'", "'SecServerSignature'", 
                     "'SecWebAppId'", "'SecCacheTransformations'", "'SecChrootDir'", 
                     "'SecConnEngine'", "'SecHashEngine'", "'SecHashKey'", 
                     "'SecHashParam'", "'SecHashMethodRx'", "'SecHashMethodPm'", 
                     "'SecContentInjection'", "'SecArgumentSeparator'", 
                     "'SecAuditLogStorageDir'", "'SecAuditLogDirMode'", 
                     "'SecAuditEngine'", "'SecAuditLogFileMode'", "'SecAuditLog2'", 
                     "'SecAuditLog'", "'SecAuditLogFormat'", "'SecAuditLogParts'", 
                     "'SecAuditLogRelevantStatus'", "'SecAuditLogType'", 
                     "'SecDebugLog'", "'SecDebugLogLevel'", "'SecGeoLookupDb'", 
                     "'SecGsbLookupDb'", "'SecGuardianLog'", "'SecInterceptOnError'", 
                     "'SecConnReadStateLimit'", "'SecConnWriteStateLimit'", 
                     "'SecSensorId'", "'SecRuleInheritance'", "'SecRulePerfTime'", 
                     "'SecStreamInBodyInspection'", "'SecStreamOutBodyInspection'", 
                     "'SecPcreMatchLimit'", "'SecPcreMatchLimitRecursion'", 
                     "'SecArgumentsLimit'", "'SecRequestBodyJsonDepthLimit'", 
                     "'SecRequestBodyAccess'", "'SecRequestBodyInMemoryLimit'", 
                     "'SecRequestBodyLimit'", "'SecRequestBodyLimitAction'", 
                     "'SecRequestBodyNoFilesLimit'", "'SecResponseBodyAccess'", 
                     "'SecResponseBodyLimit'", "'SecResponseBodyLimitAction'", 
                     "'SecRuleEngine'", "'SecAction'", "'SecDefaultAction'", 
                     "'SecDisableBackendCompression'", "'SecMarker'", "'SecUnicodeMapFile'", 
                     "'Include'", "'SecCollectionTimeout'", "'SecHttpBlKey'", 
                     "'SecRemoteRules'", "'SecRemoteRulesFailAction'", "<INVALID>", 
                     "'SecRuleRemoveByMsg'", "'SecRuleRemoveByTag'", "'SecRuleUpdateTargetByTag'", 
                     "'SecRuleUpdateTargetByMsg'", "'SecRuleUpdateTargetById'", 
                     "'SecRuleUpdateActionById'", "'SecUploadKeepFiles'", 
                     "'SecTmpSaveUploadedFiles'", "'SecUploadDir'", "'SecUploadFileLimit'", 
                     "'SecUploadFileMode'", "'Abort'", "'DetectionOnly'", 
                     "'https'", "'Off'", "'On'", "<INVALID>", "'ProcessPartial'", 
                     "'Reject'", "'RelevantOnly'", "'Serial'", "'Warn'", 
                     "'SecXmlExternalEntity'", "'SecResponseBodyMimeType'", 
                     "'SecResponseBodyMimeTypesClear'", "'SecCookieFormat'", 
                     "'SecCookieV0Separator'", "'SecDataDir'", "'SecStatusEngine'", 
                     "'SecTmpDir'", "'SecRule'", "'SecRuleScript'", "<INVALID>", 
                     "<INVALID>", "<INVALID>", "<INVALID>", "'NATIVE'", 
                     "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                     "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                     "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                     "'.'", "<INVALID>", "'%{'", "<INVALID>", "<INVALID>", 
                     "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                     "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                     "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                     "<INVALID>", "<INVALID>", "'@'" ]

    symbolicNames = [ "<INVALID>", "QUOTE", "SINGLE_QUOTE", "EQUAL", "COLON", 
                      "EQUALS_PLUS", "EQUALS_MINUS", "COMMA", "PIPE", "CONFIG_VALUE_PATH", 
                      "NOT", "WS", "HASH", "PLUS", "MINUS", "STAR", "SLASH", 
                      "ASSIGN", "SEMI", "NOT_EQUAL", "LT", "LE", "GE", "GT", 
                      "LPAREN", "RPAREN", "ACTION_ACCURACY", "ACTION_ALLOW", 
                      "ACTION_APPEND", "ACTION_AUDIT_LOG", "ACTION_BLOCK", 
                      "ACTION_CAPTURE", "ACTION_CHAIN", "ACTION_CTL", "ACTION_CTL_AUDIT_ENGINE", 
                      "ACTION_CTL_AUDIT_LOG_PARTS", "ACTION_CTL_REQUEST_BODY_PROCESSOR", 
                      "ACTION_CTL_FORCE_REQ_BODY_VAR", "ACTION_CTL_REQUEST_BODY_ACCESS", 
                      "ACTION_CTL_RULE_ENGINE", "ACTION_CTL_RULE_REMOVE_BY_TAG", 
                      "ACTION_CTL_RULE_REMOVE_BY_ID", "ACTION_CTL_RULE_REMOVE_TARGET_BY_ID", 
                      "ACTION_CTL_RULE_REMOVE_TARGET_BY_TAG", "ACTION_DENY", 
                      "ACTION_DEPRECATE_VAR", "ACTION_DROP", "ACTION_EXEC", 
                      "ACTION_EXPIRE_VAR", "ACTION_ID", "ACTION_INITCOL", 
                      "ACTION_LOG_DATA", "ACTION_LOG", "ACTION_MATURITY", 
                      "ACTION_MSG", "ACTION_MULTI_MATCH", "ACTION_NO_AUDIT_LOG", 
                      "ACTION_NO_LOG", "ACTION_PASS", "ACTION_PAUSE", "ACTION_PHASE", 
                      "ACTION_PREPEND", "ACTION_PROXY", "ACTION_REDIRECT", 
                      "ACTION_REV", "ACTION_SANITISE_ARG", "ACTION_SANITISE_MATCHED_BYTES", 
                      "ACTION_SANITISE_MATCHED", "ACTION_SANITISE_REQUEST_HEADER", 
                      "ACTION_SANITISE_RESPONSE_HEADER", "ACTION_SETENV", 
                      "ACTION_SETRSC", "ACTION_SETSID", "ACTION_SETUID", 
                      "ACTION_SETVAR", "ACTION_SEVERITY", "ACTION_SEVERITY_VALUE", 
                      "ACTION_SKIP_AFTER", "ACTION_SKIP", "ACTION_STATUS", 
                      "ACTION_TAG", "ACTION_VER", "ACTION_XMLNS", "ACTION_TRANSFORMATION", 
                      "TRANSFORMATION_VALUE", "COLLECTION_NAME_ENUM", "VARIABLE_NAME_ENUM", 
                      "RUN_TIME_VAR_XML", "VAR_COUNT", "OPERATOR_BEGINS_WITH", 
                      "OPERATOR_CONTAINS", "OPERATOR_CONTAINS_WORD", "OPERATOR_DETECT_SQLI", 
                      "OPERATOR_DETECT_XSS", "OPERATOR_ENDS_WITH", "OPERATOR_EQ", 
                      "OPERATOR_FUZZY_HASH", "OPERATOR_GE", "OPERATOR_GEOLOOKUP", 
                      "OPERATOR_GSB_LOOKUP", "OPERATOR_GT", "OPERATOR_INSPECT_FILE", 
                      "OPERATOR_IP_MATCH_FROM_FILE", "OPERATOR_IP_MATCH", 
                      "OPERATOR_LE", "OPERATOR_LT", "OPERATOR_PM_FROM_FILE", 
                      "OPERATOR_PM", "OPERATOR_RBL", "OPERATOR_RSUB", "OPERATOR_RX", 
                      "OPERATOR_RX_GLOBAL", "OPERATOR_STR_EQ", "OPERATOR_STR_MATCH", 
                      "OPERATOR_UNCONDITIONAL_MATCH", "OPERATOR_VALIDATE_BYTE_RANGE", 
                      "OPERATOR_VALIDATE_DTD", "OPERATOR_VALIDATE_HASH", 
                      "OPERATOR_VALIDATE_SCHEMA", "OPERATOR_VALIDATE_URL_ENCODING", 
                      "OPERATOR_VALIDATE_UTF8_ENCODING", "OPERATOR_VERIFY_CC", 
                      "OPERATOR_VERIFY_CPF", "OPERATOR_VERIFY_SSN", "OPERATOR_VERIFY_SVNR", 
                      "OPERATOR_WITHIN", "AUDIT_PARTS", "CONFIG_COMPONENT_SIG", 
                      "CONFIG_SEC_SERVER_SIG", "CONFIG_SEC_WEB_APP_ID", 
                      "CONFIG_SEC_CACHE_TRANSFORMATIONS", "CONFIG_SEC_CHROOT_DIR", 
                      "CONFIG_CONN_ENGINE", "CONFIG_SEC_HASH_ENGINE", "CONFIG_SEC_HASH_KEY", 
                      "CONFIG_SEC_HASH_PARAM", "CONFIG_SEC_HASH_METHOD_RX", 
                      "CONFIG_SEC_HASH_METHOD_PM", "CONFIG_CONTENT_INJECTION", 
                      "CONFIG_SEC_ARGUMENT_SEPARATOR", "CONFIG_DIR_AUDIT_DIR", 
                      "CONFIG_DIR_AUDIT_DIR_MOD", "CONFIG_DIR_AUDIT_ENG", 
                      "CONFIG_DIR_AUDIT_FILE_MODE", "CONFIG_DIR_AUDIT_LOG2", 
                      "CONFIG_DIR_AUDIT_LOG", "CONFIG_DIR_AUDIT_LOG_FMT", 
                      "CONFIG_DIR_AUDIT_LOG_P", "CONFIG_DIR_AUDIT_STS", 
                      "CONFIG_DIR_AUDIT_TYPE", "CONFIG_DIR_DEBUG_LOG", "CONFIG_DIR_DEBUG_LVL", 
                      "CONFIG_DIR_GEO_DB", "CONFIG_DIR_GSB_DB", "CONFIG_SEC_GUARDIAN_LOG", 
                      "CONFIG_SEC_INTERCEPT_ON_ERROR", "CONFIG_SEC_CONN_R_STATE_LIMIT", 
                      "CONFIG_SEC_CONN_W_STATE_LIMIT", "CONFIG_SEC_SENSOR_ID", 
                      "CONFIG_SEC_RULE_INHERITANCE", "CONFIG_SEC_RULE_PERF_TIME", 
                      "CONFIG_SEC_STREAM_IN_BODY_INSPECTION", "CONFIG_SEC_STREAM_OUT_BODY_INSPECTION", 
                      "CONFIG_DIR_PCRE_MATCH_LIMIT", "CONFIG_DIR_PCRE_MATCH_LIMIT_RECURSION", 
                      "CONFIG_DIR_ARGS_LIMIT", "CONFIG_DIR_REQ_BODY_JSON_DEPTH_LIMIT", 
                      "CONFIG_DIR_REQ_BODY", "CONFIG_DIR_REQ_BODY_IN_MEMORY_LIMIT", 
                      "CONFIG_DIR_REQ_BODY_LIMIT", "CONFIG_DIR_REQ_BODY_LIMIT_ACTION", 
                      "CONFIG_DIR_REQ_BODY_NO_FILES_LIMIT", "CONFIG_DIR_RES_BODY", 
                      "CONFIG_DIR_RES_BODY_LIMIT", "CONFIG_DIR_RES_BODY_LIMIT_ACTION", 
                      "CONFIG_DIR_RULE_ENG", "CONFIG_DIR_SEC_ACTION", "CONFIG_DIR_SEC_DEFAULT_ACTION", 
                      "CONFIG_SEC_DISABLE_BACKEND_COMPRESS", "CONFIG_DIR_SEC_MARKER", 
                      "CONFIG_DIR_UNICODE_MAP_FILE", "CONFIG_INCLUDE", "CONFIG_SEC_COLLECTION_TIMEOUT", 
                      "CONFIG_SEC_HTTP_BLKEY", "CONFIG_SEC_REMOTE_RULES", 
                      "CONFIG_SEC_REMOTE_RULES_FAIL_ACTION", "CONFIG_SEC_RULE_REMOVE_BY_ID", 
                      "CONFIG_SEC_RULE_REMOVE_BY_MSG", "CONFIG_SEC_RULE_REMOVE_BY_TAG", 
                      "CONFIG_SEC_RULE_UPDATE_TARGET_BY_TAG", "CONFIG_SEC_RULE_UPDATE_TARGET_BY_MSG", 
                      "CONFIG_SEC_RULE_UPDATE_TARGET_BY_ID", "CONFIG_SEC_RULE_UPDATE_ACTION_BY_ID", 
                      "CONFIG_UPLOAD_KEEP_FILES", "CONFIG_UPLOAD_SAVE_TMP_FILES", 
                      "CONFIG_UPLOAD_DIR", "CONFIG_UPLOAD_FILE_LIMIT", "CONFIG_UPLOAD_FILE_MODE", 
                      "CONFIG_VALUE_ABORT", "CONFIG_VALUE_DETC", "CONFIG_VALUE_HTTPS", 
                      "CONFIG_VALUE_OFF", "CONFIG_VALUE_ON", "CONFIG_VALUE_PARALLEL", 
                      "CONFIG_VALUE_PROCESS_PARTIAL", "CONFIG_VALUE_REJECT", 
                      "CONFIG_VALUE_RELEVANT_ONLY", "CONFIG_VALUE_SERIAL", 
                      "CONFIG_VALUE_WARN", "CONFIG_XML_EXTERNAL_ENTITY", 
                      "CONFIG_DIR_RESPONSE_BODY_MP", "CONFIG_DIR_RESPONSE_BODY_MP_CLEAR", 
                      "CONFIG_DIR_SEC_COOKIE_FORMAT", "CONFIG_SEC_COOKIEV0_SEPARATOR", 
                      "CONFIG_DIR_SEC_DATA_DIR", "CONFIG_DIR_SEC_STATUS_ENGINE", 
                      "CONFIG_DIR_SEC_TMP_DIR", "CONFIG_DIR_SEC_RULE", "DIRECTIVE_SECRULESCRIPT", 
                      "OPTION_NAME", "SINGLE_QUOTE_BUT_SCAPED", "DOUBLE_SINGLE_QUOTE_BUT_SCAPED", 
                      "COMMA_BUT_SCAPED", "NATIVE", "NEWLINE", "VARIABLE_NAME", 
                      "IDENT", "INT", "DIGIT", "LETTER", "DICT_ELEMENT_REGEXP", 
                      "FREE_TEXT_QUOTE_MACRO_EXPANSION", "WS_STRING_MODE", 
                      "STRING", "MACRO_EXPANSION", "COLLECTION_NAME_SETVAR", 
                      "DOT", "COLLECTION_ELEMENT", "COLLECTION_WITH_MACRO", 
                      "VAR_ASSIGNMENT", "SPACE_SETVAR_ASSIGNMENT", "COMMA_SEPARATED_STRING", 
                      "WS_FILE_PATH_MODE", "XPATH_EXPRESSION", "XPATH_MODE_POP_CHARS", 
                      "ACTION_CTL_BODY_PROCESSOR_TYPE", "STRING_LITERAL", 
                      "SPACE_COL", "SPACE_VAR", "NEWLINE_VAR", "COLLECTION_ELEMENT_VALUE", 
                      "SPACE_COL_ELEM", "NEWLINE_COL_ELEM", "SKIP_CHARS", 
                      "OPERATOR_UNQUOTED_STRING", "AT", "OPERATOR_QUOTED_STRING", 
                      "COMMENT", "HASH_COMMENT_BLOCK", "BLOCK_COMMENT_END", 
                      "WS_REMOVE_SPACE", "INT_RANGE_VALUE", "MINUS_INT_RANGE", 
                      "WS_INT_RANGE", "PIPE_DEFAULT", "COMMA_DEFAULT", "COLON_DEFAULT", 
                      "EQUAL_DEFAULT", "NOT_DEFAULT", "QUOTE_DEFAULT", "SINGLE_QUOTE_SETVAR" ]

    RULE_configuration = 0
    RULE_stmt = 1
    RULE_comment_block = 2
    RULE_comment = 3
    RULE_engine_config_rule_directive = 4
    RULE_engine_config_directive = 5
    RULE_string_engine_config_directive = 6
    RULE_sec_marker_directive = 7
    RULE_engine_config_directive_with_param = 8
    RULE_rule_script_directive = 9
    RULE_file_path = 10
    RULE_remove_rule_by_id = 11
    RULE_remove_rule_by_id_values = 12
    RULE_operator_int_range = 13
    RULE_int_range = 14
    RULE_range_start = 15
    RULE_range_end = 16
    RULE_string_remove_rules = 17
    RULE_string_remove_rules_values = 18
    RULE_update_target_rules = 19
    RULE_update_action_rule = 20
    RULE_id = 21
    RULE_engine_config_sec_cache_transformations = 22
    RULE_option_list = 23
    RULE_option = 24
    RULE_option_name = 25
    RULE_engine_config_action_directive = 26
    RULE_stmt_audit_log = 27
    RULE_values = 28
    RULE_action_ctl_target_value = 29
    RULE_update_target_rules_values = 30
    RULE_operator_not = 31
    RULE_operator = 32
    RULE_operator_name = 33
    RULE_operator_value = 34
    RULE_var_not = 35
    RULE_var_count = 36
    RULE_variables = 37
    RULE_update_variables = 38
    RULE_new_target = 39
    RULE_var_stmt = 40
    RULE_variable_enum = 41
    RULE_ctl_variable_enum = 42
    RULE_collection_enum = 43
    RULE_ctl_collection_enum = 44
    RULE_actions = 45
    RULE_action = 46
    RULE_action_only = 47
    RULE_disruptive_action_only = 48
    RULE_non_disruptive_action_only = 49
    RULE_flow_action_only = 50
    RULE_action_with_params = 51
    RULE_metadata_action_with_params = 52
    RULE_disruptive_action_with_params = 53
    RULE_non_disruptive_action_with_params = 54
    RULE_data_action_with_params = 55
    RULE_flow_action_with_params = 56
    RULE_action_value = 57
    RULE_action_value_types = 58
    RULE_string_literal = 59
    RULE_ctl_action = 60
    RULE_transformation_action_value = 61
    RULE_collection_value = 62
    RULE_ctl_collection_value = 63
    RULE_setvar_action = 64
    RULE_col_name = 65
    RULE_setvar_stmt = 66
    RULE_assignment = 67
    RULE_var_assignment = 68
    RULE_ctl_id = 69

    ruleNames =  [ "configuration", "stmt", "comment_block", "comment", 
                   "engine_config_rule_directive", "engine_config_directive", 
                   "string_engine_config_directive", "sec_marker_directive", 
                   "engine_config_directive_with_param", "rule_script_directive", 
                   "file_path", "remove_rule_by_id", "remove_rule_by_id_values", 
                   "operator_int_range", "int_range", "range_start", "range_end", 
                   "string_remove_rules", "string_remove_rules_values", 
                   "update_target_rules", "update_action_rule", "id", "engine_config_sec_cache_transformations", 
                   "option_list", "option", "option_name", "engine_config_action_directive", 
                   "stmt_audit_log", "values", "action_ctl_target_value", 
                   "update_target_rules_values", "operator_not", "operator", 
                   "operator_name", "operator_value", "var_not", "var_count", 
                   "variables", "update_variables", "new_target", "var_stmt", 
                   "variable_enum", "ctl_variable_enum", "collection_enum", 
                   "ctl_collection_enum", "actions", "action", "action_only", 
                   "disruptive_action_only", "non_disruptive_action_only", 
                   "flow_action_only", "action_with_params", "metadata_action_with_params", 
                   "disruptive_action_with_params", "non_disruptive_action_with_params", 
                   "data_action_with_params", "flow_action_with_params", 
                   "action_value", "action_value_types", "string_literal", 
                   "ctl_action", "transformation_action_value", "collection_value", 
                   "ctl_collection_value", "setvar_action", "col_name", 
                   "setvar_stmt", "assignment", "var_assignment", "ctl_id" ]

    EOF = Token.EOF
    QUOTE=1
    SINGLE_QUOTE=2
    EQUAL=3
    COLON=4
    EQUALS_PLUS=5
    EQUALS_MINUS=6
    COMMA=7
    PIPE=8
    CONFIG_VALUE_PATH=9
    NOT=10
    WS=11
    HASH=12
    PLUS=13
    MINUS=14
    STAR=15
    SLASH=16
    ASSIGN=17
    SEMI=18
    NOT_EQUAL=19
    LT=20
    LE=21
    GE=22
    GT=23
    LPAREN=24
    RPAREN=25
    ACTION_ACCURACY=26
    ACTION_ALLOW=27
    ACTION_APPEND=28
    ACTION_AUDIT_LOG=29
    ACTION_BLOCK=30
    ACTION_CAPTURE=31
    ACTION_CHAIN=32
    ACTION_CTL=33
    ACTION_CTL_AUDIT_ENGINE=34
    ACTION_CTL_AUDIT_LOG_PARTS=35
    ACTION_CTL_REQUEST_BODY_PROCESSOR=36
    ACTION_CTL_FORCE_REQ_BODY_VAR=37
    ACTION_CTL_REQUEST_BODY_ACCESS=38
    ACTION_CTL_RULE_ENGINE=39
    ACTION_CTL_RULE_REMOVE_BY_TAG=40
    ACTION_CTL_RULE_REMOVE_BY_ID=41
    ACTION_CTL_RULE_REMOVE_TARGET_BY_ID=42
    ACTION_CTL_RULE_REMOVE_TARGET_BY_TAG=43
    ACTION_DENY=44
    ACTION_DEPRECATE_VAR=45
    ACTION_DROP=46
    ACTION_EXEC=47
    ACTION_EXPIRE_VAR=48
    ACTION_ID=49
    ACTION_INITCOL=50
    ACTION_LOG_DATA=51
    ACTION_LOG=52
    ACTION_MATURITY=53
    ACTION_MSG=54
    ACTION_MULTI_MATCH=55
    ACTION_NO_AUDIT_LOG=56
    ACTION_NO_LOG=57
    ACTION_PASS=58
    ACTION_PAUSE=59
    ACTION_PHASE=60
    ACTION_PREPEND=61
    ACTION_PROXY=62
    ACTION_REDIRECT=63
    ACTION_REV=64
    ACTION_SANITISE_ARG=65
    ACTION_SANITISE_MATCHED_BYTES=66
    ACTION_SANITISE_MATCHED=67
    ACTION_SANITISE_REQUEST_HEADER=68
    ACTION_SANITISE_RESPONSE_HEADER=69
    ACTION_SETENV=70
    ACTION_SETRSC=71
    ACTION_SETSID=72
    ACTION_SETUID=73
    ACTION_SETVAR=74
    ACTION_SEVERITY=75
    ACTION_SEVERITY_VALUE=76
    ACTION_SKIP_AFTER=77
    ACTION_SKIP=78
    ACTION_STATUS=79
    ACTION_TAG=80
    ACTION_VER=81
    ACTION_XMLNS=82
    ACTION_TRANSFORMATION=83
    TRANSFORMATION_VALUE=84
    COLLECTION_NAME_ENUM=85
    VARIABLE_NAME_ENUM=86
    RUN_TIME_VAR_XML=87
    VAR_COUNT=88
    OPERATOR_BEGINS_WITH=89
    OPERATOR_CONTAINS=90
    OPERATOR_CONTAINS_WORD=91
    OPERATOR_DETECT_SQLI=92
    OPERATOR_DETECT_XSS=93
    OPERATOR_ENDS_WITH=94
    OPERATOR_EQ=95
    OPERATOR_FUZZY_HASH=96
    OPERATOR_GE=97
    OPERATOR_GEOLOOKUP=98
    OPERATOR_GSB_LOOKUP=99
    OPERATOR_GT=100
    OPERATOR_INSPECT_FILE=101
    OPERATOR_IP_MATCH_FROM_FILE=102
    OPERATOR_IP_MATCH=103
    OPERATOR_LE=104
    OPERATOR_LT=105
    OPERATOR_PM_FROM_FILE=106
    OPERATOR_PM=107
    OPERATOR_RBL=108
    OPERATOR_RSUB=109
    OPERATOR_RX=110
    OPERATOR_RX_GLOBAL=111
    OPERATOR_STR_EQ=112
    OPERATOR_STR_MATCH=113
    OPERATOR_UNCONDITIONAL_MATCH=114
    OPERATOR_VALIDATE_BYTE_RANGE=115
    OPERATOR_VALIDATE_DTD=116
    OPERATOR_VALIDATE_HASH=117
    OPERATOR_VALIDATE_SCHEMA=118
    OPERATOR_VALIDATE_URL_ENCODING=119
    OPERATOR_VALIDATE_UTF8_ENCODING=120
    OPERATOR_VERIFY_CC=121
    OPERATOR_VERIFY_CPF=122
    OPERATOR_VERIFY_SSN=123
    OPERATOR_VERIFY_SVNR=124
    OPERATOR_WITHIN=125
    AUDIT_PARTS=126
    CONFIG_COMPONENT_SIG=127
    CONFIG_SEC_SERVER_SIG=128
    CONFIG_SEC_WEB_APP_ID=129
    CONFIG_SEC_CACHE_TRANSFORMATIONS=130
    CONFIG_SEC_CHROOT_DIR=131
    CONFIG_CONN_ENGINE=132
    CONFIG_SEC_HASH_ENGINE=133
    CONFIG_SEC_HASH_KEY=134
    CONFIG_SEC_HASH_PARAM=135
    CONFIG_SEC_HASH_METHOD_RX=136
    CONFIG_SEC_HASH_METHOD_PM=137
    CONFIG_CONTENT_INJECTION=138
    CONFIG_SEC_ARGUMENT_SEPARATOR=139
    CONFIG_DIR_AUDIT_DIR=140
    CONFIG_DIR_AUDIT_DIR_MOD=141
    CONFIG_DIR_AUDIT_ENG=142
    CONFIG_DIR_AUDIT_FILE_MODE=143
    CONFIG_DIR_AUDIT_LOG2=144
    CONFIG_DIR_AUDIT_LOG=145
    CONFIG_DIR_AUDIT_LOG_FMT=146
    CONFIG_DIR_AUDIT_LOG_P=147
    CONFIG_DIR_AUDIT_STS=148
    CONFIG_DIR_AUDIT_TYPE=149
    CONFIG_DIR_DEBUG_LOG=150
    CONFIG_DIR_DEBUG_LVL=151
    CONFIG_DIR_GEO_DB=152
    CONFIG_DIR_GSB_DB=153
    CONFIG_SEC_GUARDIAN_LOG=154
    CONFIG_SEC_INTERCEPT_ON_ERROR=155
    CONFIG_SEC_CONN_R_STATE_LIMIT=156
    CONFIG_SEC_CONN_W_STATE_LIMIT=157
    CONFIG_SEC_SENSOR_ID=158
    CONFIG_SEC_RULE_INHERITANCE=159
    CONFIG_SEC_RULE_PERF_TIME=160
    CONFIG_SEC_STREAM_IN_BODY_INSPECTION=161
    CONFIG_SEC_STREAM_OUT_BODY_INSPECTION=162
    CONFIG_DIR_PCRE_MATCH_LIMIT=163
    CONFIG_DIR_PCRE_MATCH_LIMIT_RECURSION=164
    CONFIG_DIR_ARGS_LIMIT=165
    CONFIG_DIR_REQ_BODY_JSON_DEPTH_LIMIT=166
    CONFIG_DIR_REQ_BODY=167
    CONFIG_DIR_REQ_BODY_IN_MEMORY_LIMIT=168
    CONFIG_DIR_REQ_BODY_LIMIT=169
    CONFIG_DIR_REQ_BODY_LIMIT_ACTION=170
    CONFIG_DIR_REQ_BODY_NO_FILES_LIMIT=171
    CONFIG_DIR_RES_BODY=172
    CONFIG_DIR_RES_BODY_LIMIT=173
    CONFIG_DIR_RES_BODY_LIMIT_ACTION=174
    CONFIG_DIR_RULE_ENG=175
    CONFIG_DIR_SEC_ACTION=176
    CONFIG_DIR_SEC_DEFAULT_ACTION=177
    CONFIG_SEC_DISABLE_BACKEND_COMPRESS=178
    CONFIG_DIR_SEC_MARKER=179
    CONFIG_DIR_UNICODE_MAP_FILE=180
    CONFIG_INCLUDE=181
    CONFIG_SEC_COLLECTION_TIMEOUT=182
    CONFIG_SEC_HTTP_BLKEY=183
    CONFIG_SEC_REMOTE_RULES=184
    CONFIG_SEC_REMOTE_RULES_FAIL_ACTION=185
    CONFIG_SEC_RULE_REMOVE_BY_ID=186
    CONFIG_SEC_RULE_REMOVE_BY_MSG=187
    CONFIG_SEC_RULE_REMOVE_BY_TAG=188
    CONFIG_SEC_RULE_UPDATE_TARGET_BY_TAG=189
    CONFIG_SEC_RULE_UPDATE_TARGET_BY_MSG=190
    CONFIG_SEC_RULE_UPDATE_TARGET_BY_ID=191
    CONFIG_SEC_RULE_UPDATE_ACTION_BY_ID=192
    CONFIG_UPLOAD_KEEP_FILES=193
    CONFIG_UPLOAD_SAVE_TMP_FILES=194
    CONFIG_UPLOAD_DIR=195
    CONFIG_UPLOAD_FILE_LIMIT=196
    CONFIG_UPLOAD_FILE_MODE=197
    CONFIG_VALUE_ABORT=198
    CONFIG_VALUE_DETC=199
    CONFIG_VALUE_HTTPS=200
    CONFIG_VALUE_OFF=201
    CONFIG_VALUE_ON=202
    CONFIG_VALUE_PARALLEL=203
    CONFIG_VALUE_PROCESS_PARTIAL=204
    CONFIG_VALUE_REJECT=205
    CONFIG_VALUE_RELEVANT_ONLY=206
    CONFIG_VALUE_SERIAL=207
    CONFIG_VALUE_WARN=208
    CONFIG_XML_EXTERNAL_ENTITY=209
    CONFIG_DIR_RESPONSE_BODY_MP=210
    CONFIG_DIR_RESPONSE_BODY_MP_CLEAR=211
    CONFIG_DIR_SEC_COOKIE_FORMAT=212
    CONFIG_SEC_COOKIEV0_SEPARATOR=213
    CONFIG_DIR_SEC_DATA_DIR=214
    CONFIG_DIR_SEC_STATUS_ENGINE=215
    CONFIG_DIR_SEC_TMP_DIR=216
    CONFIG_DIR_SEC_RULE=217
    DIRECTIVE_SECRULESCRIPT=218
    OPTION_NAME=219
    SINGLE_QUOTE_BUT_SCAPED=220
    DOUBLE_SINGLE_QUOTE_BUT_SCAPED=221
    COMMA_BUT_SCAPED=222
    NATIVE=223
    NEWLINE=224
    VARIABLE_NAME=225
    IDENT=226
    INT=227
    DIGIT=228
    LETTER=229
    DICT_ELEMENT_REGEXP=230
    FREE_TEXT_QUOTE_MACRO_EXPANSION=231
    WS_STRING_MODE=232
    STRING=233
    MACRO_EXPANSION=234
    COLLECTION_NAME_SETVAR=235
    DOT=236
    COLLECTION_ELEMENT=237
    COLLECTION_WITH_MACRO=238
    VAR_ASSIGNMENT=239
    SPACE_SETVAR_ASSIGNMENT=240
    COMMA_SEPARATED_STRING=241
    WS_FILE_PATH_MODE=242
    XPATH_EXPRESSION=243
    XPATH_MODE_POP_CHARS=244
    ACTION_CTL_BODY_PROCESSOR_TYPE=245
    STRING_LITERAL=246
    SPACE_COL=247
    SPACE_VAR=248
    NEWLINE_VAR=249
    COLLECTION_ELEMENT_VALUE=250
    SPACE_COL_ELEM=251
    NEWLINE_COL_ELEM=252
    SKIP_CHARS=253
    OPERATOR_UNQUOTED_STRING=254
    AT=255
    OPERATOR_QUOTED_STRING=256
    COMMENT=257
    HASH_COMMENT_BLOCK=258
    BLOCK_COMMENT_END=259
    WS_REMOVE_SPACE=260
    INT_RANGE_VALUE=261
    MINUS_INT_RANGE=262
    WS_INT_RANGE=263
    PIPE_DEFAULT=264
    COMMA_DEFAULT=265
    COLON_DEFAULT=266
    EQUAL_DEFAULT=267
    NOT_DEFAULT=268
    QUOTE_DEFAULT=269
    SINGLE_QUOTE_SETVAR=270

    def __init__(self, input:TokenStream, output:TextIO = sys.stdout):
        super().__init__(input, output)
        self.checkVersion("4.13.2")
        self._interp = ParserATNSimulator(self, self.atn, self.decisionsToDFA, self.sharedContextCache)
        self._predicates = None




    class ConfigurationContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def EOF(self):
            return self.getToken(SecLangParser.EOF, 0)

        def stmt(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(SecLangParser.StmtContext)
            else:
                return self.getTypedRuleContext(SecLangParser.StmtContext,i)


        def getRuleIndex(self):
            return SecLangParser.RULE_configuration

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterConfiguration" ):
                listener.enterConfiguration(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitConfiguration" ):
                listener.exitConfiguration(self)




    def configuration(self):

        localctx = SecLangParser.ConfigurationContext(self, self._ctx, self.state)
        self.enterRule(localctx, 0, self.RULE_configuration)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 143
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==1 or _la==12 or ((((_la - 127)) & ~0x3f) == 0 and ((1 << (_la - 127)) & -162131785608593409) != 0) or ((((_la - 191)) & ~0x3f) == 0 and ((1 << (_la - 191)) & 68987650175) != 0):
                self.state = 140
                self.stmt()
                self.state = 145
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 146
            self.match(SecLangParser.EOF)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class StmtContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def engine_config_rule_directive(self):
            return self.getTypedRuleContext(SecLangParser.Engine_config_rule_directiveContext,0)


        def variables(self):
            return self.getTypedRuleContext(SecLangParser.VariablesContext,0)


        def operator(self):
            return self.getTypedRuleContext(SecLangParser.OperatorContext,0)


        def comment_block(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(SecLangParser.Comment_blockContext)
            else:
                return self.getTypedRuleContext(SecLangParser.Comment_blockContext,i)


        def actions(self):
            return self.getTypedRuleContext(SecLangParser.ActionsContext,0)


        def rule_script_directive(self):
            return self.getTypedRuleContext(SecLangParser.Rule_script_directiveContext,0)


        def file_path(self):
            return self.getTypedRuleContext(SecLangParser.File_pathContext,0)


        def QUOTE(self, i:int=None):
            if i is None:
                return self.getTokens(SecLangParser.QUOTE)
            else:
                return self.getToken(SecLangParser.QUOTE, i)

        def remove_rule_by_id(self):
            return self.getTypedRuleContext(SecLangParser.Remove_rule_by_idContext,0)


        def remove_rule_by_id_values(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(SecLangParser.Remove_rule_by_id_valuesContext)
            else:
                return self.getTypedRuleContext(SecLangParser.Remove_rule_by_id_valuesContext,i)


        def string_remove_rules(self):
            return self.getTypedRuleContext(SecLangParser.String_remove_rulesContext,0)


        def string_remove_rules_values(self):
            return self.getTypedRuleContext(SecLangParser.String_remove_rules_valuesContext,0)


        def update_target_rules(self):
            return self.getTypedRuleContext(SecLangParser.Update_target_rulesContext,0)


        def update_target_rules_values(self):
            return self.getTypedRuleContext(SecLangParser.Update_target_rules_valuesContext,0)


        def update_variables(self):
            return self.getTypedRuleContext(SecLangParser.Update_variablesContext,0)


        def PIPE(self):
            return self.getToken(SecLangParser.PIPE, 0)

        def new_target(self):
            return self.getTypedRuleContext(SecLangParser.New_targetContext,0)


        def update_action_rule(self):
            return self.getTypedRuleContext(SecLangParser.Update_action_ruleContext,0)


        def id_(self):
            return self.getTypedRuleContext(SecLangParser.IdContext,0)


        def engine_config_directive(self):
            return self.getTypedRuleContext(SecLangParser.Engine_config_directiveContext,0)


        def getRuleIndex(self):
            return SecLangParser.RULE_stmt

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterStmt" ):
                listener.enterStmt(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitStmt" ):
                listener.exitStmt(self)




    def stmt(self):

        localctx = SecLangParser.StmtContext(self, self._ctx, self.state)
        self.enterRule(localctx, 2, self.RULE_stmt)
        self._la = 0 # Token type
        try:
            self.state = 250
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,18,self._ctx)
            if la_ == 1:
                self.enterOuterAlt(localctx, 1)
                self.state = 149
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==12:
                    self.state = 148
                    self.comment_block()


                self.state = 151
                self.engine_config_rule_directive()
                self.state = 152
                self.variables()
                self.state = 153
                self.operator()
                self.state = 155
                self._errHandler.sync(self)
                la_ = self._interp.adaptivePredict(self._input,2,self._ctx)
                if la_ == 1:
                    self.state = 154
                    self.actions()


                pass

            elif la_ == 2:
                self.enterOuterAlt(localctx, 2)
                self.state = 158
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==12:
                    self.state = 157
                    self.comment_block()


                self.state = 160
                self.rule_script_directive()
                self.state = 161
                self.file_path()
                self.state = 163
                self._errHandler.sync(self)
                la_ = self._interp.adaptivePredict(self._input,4,self._ctx)
                if la_ == 1:
                    self.state = 162
                    self.actions()


                pass

            elif la_ == 3:
                self.enterOuterAlt(localctx, 3)
                self.state = 166
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==12:
                    self.state = 165
                    self.comment_block()


                self.state = 168
                self.rule_script_directive()
                self.state = 169
                self.match(SecLangParser.QUOTE)
                self.state = 170
                self.file_path()
                self.state = 171
                self.match(SecLangParser.QUOTE)
                self.state = 173
                self._errHandler.sync(self)
                la_ = self._interp.adaptivePredict(self._input,6,self._ctx)
                if la_ == 1:
                    self.state = 172
                    self.actions()


                pass

            elif la_ == 4:
                self.enterOuterAlt(localctx, 4)
                self.state = 176
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==12:
                    self.state = 175
                    self.comment_block()


                self.state = 178
                self.remove_rule_by_id()
                self.state = 180 
                self._errHandler.sync(self)
                _alt = 1
                while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                    if _alt == 1:
                        self.state = 179
                        self.remove_rule_by_id_values()

                    else:
                        raise NoViableAltException(self)
                    self.state = 182 
                    self._errHandler.sync(self)
                    _alt = self._interp.adaptivePredict(self._input,8,self._ctx)

                pass

            elif la_ == 5:
                self.enterOuterAlt(localctx, 5)
                self.state = 185
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==12:
                    self.state = 184
                    self.comment_block()


                self.state = 187
                self.string_remove_rules()
                self.state = 188
                self.string_remove_rules_values()
                pass

            elif la_ == 6:
                self.enterOuterAlt(localctx, 6)
                self.state = 191
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==12:
                    self.state = 190
                    self.comment_block()


                self.state = 193
                self.string_remove_rules()
                self.state = 194
                self.match(SecLangParser.QUOTE)
                self.state = 195
                self.string_remove_rules_values()
                self.state = 196
                self.match(SecLangParser.QUOTE)
                pass

            elif la_ == 7:
                self.enterOuterAlt(localctx, 7)
                self.state = 199
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==12:
                    self.state = 198
                    self.comment_block()


                self.state = 201
                self.update_target_rules()
                self.state = 202
                self.update_target_rules_values()
                self.state = 203
                self.update_variables()
                pass

            elif la_ == 8:
                self.enterOuterAlt(localctx, 8)
                self.state = 206
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==12:
                    self.state = 205
                    self.comment_block()


                self.state = 208
                self.update_target_rules()
                self.state = 209
                self.match(SecLangParser.QUOTE)
                self.state = 210
                self.update_target_rules_values()
                self.state = 211
                self.match(SecLangParser.QUOTE)
                self.state = 212
                self.update_variables()
                pass

            elif la_ == 9:
                self.enterOuterAlt(localctx, 9)
                self.state = 215
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==12:
                    self.state = 214
                    self.comment_block()


                self.state = 217
                self.update_target_rules()
                self.state = 218
                self.update_target_rules_values()
                self.state = 219
                self.update_variables()
                self.state = 220
                self.match(SecLangParser.PIPE)
                self.state = 221
                self.new_target()
                pass

            elif la_ == 10:
                self.enterOuterAlt(localctx, 10)
                self.state = 224
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==12:
                    self.state = 223
                    self.comment_block()


                self.state = 226
                self.update_target_rules()
                self.state = 227
                self.match(SecLangParser.QUOTE)
                self.state = 228
                self.update_target_rules_values()
                self.state = 229
                self.match(SecLangParser.QUOTE)
                self.state = 230
                self.update_variables()
                self.state = 231
                self.match(SecLangParser.PIPE)
                self.state = 232
                self.new_target()
                pass

            elif la_ == 11:
                self.enterOuterAlt(localctx, 11)
                self.state = 235
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==12:
                    self.state = 234
                    self.comment_block()


                self.state = 237
                self.update_action_rule()
                self.state = 238
                self.id_()
                self.state = 239
                self.actions()
                pass

            elif la_ == 12:
                self.enterOuterAlt(localctx, 12)
                self.state = 242
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==12:
                    self.state = 241
                    self.comment_block()


                self.state = 244
                self.engine_config_directive()
                pass

            elif la_ == 13:
                self.enterOuterAlt(localctx, 13)
                self.state = 246 
                self._errHandler.sync(self)
                _alt = 1
                while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                    if _alt == 1:
                        self.state = 245
                        self.comment_block()

                    else:
                        raise NoViableAltException(self)
                    self.state = 248 
                    self._errHandler.sync(self)
                    _alt = self._interp.adaptivePredict(self._input,17,self._ctx)

                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Comment_blockContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def comment(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(SecLangParser.CommentContext)
            else:
                return self.getTypedRuleContext(SecLangParser.CommentContext,i)


        def BLOCK_COMMENT_END(self):
            return self.getToken(SecLangParser.BLOCK_COMMENT_END, 0)

        def EOF(self):
            return self.getToken(SecLangParser.EOF, 0)

        def getRuleIndex(self):
            return SecLangParser.RULE_comment_block

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterComment_block" ):
                listener.enterComment_block(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitComment_block" ):
                listener.exitComment_block(self)




    def comment_block(self):

        localctx = SecLangParser.Comment_blockContext(self, self._ctx, self.state)
        self.enterRule(localctx, 4, self.RULE_comment_block)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 253 
            self._errHandler.sync(self)
            _alt = 1
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt == 1:
                    self.state = 252
                    self.comment()

                else:
                    raise NoViableAltException(self)
                self.state = 255 
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,19,self._ctx)

            self.state = 258
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,20,self._ctx)
            if la_ == 1:
                self.state = 257
                _la = self._input.LA(1)
                if not(_la==-1 or _la==259):
                    self._errHandler.recoverInline(self)
                else:
                    self._errHandler.reportMatch(self)
                    self.consume()


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class CommentContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def HASH(self):
            return self.getToken(SecLangParser.HASH, 0)

        def COMMENT(self):
            return self.getToken(SecLangParser.COMMENT, 0)

        def getRuleIndex(self):
            return SecLangParser.RULE_comment

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterComment" ):
                listener.enterComment(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitComment" ):
                listener.exitComment(self)




    def comment(self):

        localctx = SecLangParser.CommentContext(self, self._ctx, self.state)
        self.enterRule(localctx, 6, self.RULE_comment)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 260
            self.match(SecLangParser.HASH)
            self.state = 262
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==257:
                self.state = 261
                self.match(SecLangParser.COMMENT)


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Engine_config_rule_directiveContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def CONFIG_DIR_SEC_RULE(self):
            return self.getToken(SecLangParser.CONFIG_DIR_SEC_RULE, 0)

        def getRuleIndex(self):
            return SecLangParser.RULE_engine_config_rule_directive

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterEngine_config_rule_directive" ):
                listener.enterEngine_config_rule_directive(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitEngine_config_rule_directive" ):
                listener.exitEngine_config_rule_directive(self)




    def engine_config_rule_directive(self):

        localctx = SecLangParser.Engine_config_rule_directiveContext(self, self._ctx, self.state)
        self.enterRule(localctx, 8, self.RULE_engine_config_rule_directive)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 264
            self.match(SecLangParser.CONFIG_DIR_SEC_RULE)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Engine_config_directiveContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def stmt_audit_log(self):
            return self.getTypedRuleContext(SecLangParser.Stmt_audit_logContext,0)


        def values(self):
            return self.getTypedRuleContext(SecLangParser.ValuesContext,0)


        def QUOTE(self, i:int=None):
            if i is None:
                return self.getTokens(SecLangParser.QUOTE)
            else:
                return self.getToken(SecLangParser.QUOTE, i)

        def engine_config_action_directive(self):
            return self.getTypedRuleContext(SecLangParser.Engine_config_action_directiveContext,0)


        def actions(self):
            return self.getTypedRuleContext(SecLangParser.ActionsContext,0)


        def string_engine_config_directive(self):
            return self.getTypedRuleContext(SecLangParser.String_engine_config_directiveContext,0)


        def sec_marker_directive(self):
            return self.getTypedRuleContext(SecLangParser.Sec_marker_directiveContext,0)


        def engine_config_directive_with_param(self):
            return self.getTypedRuleContext(SecLangParser.Engine_config_directive_with_paramContext,0)


        def engine_config_sec_cache_transformations(self):
            return self.getTypedRuleContext(SecLangParser.Engine_config_sec_cache_transformationsContext,0)


        def option_list(self):
            return self.getTypedRuleContext(SecLangParser.Option_listContext,0)


        def getRuleIndex(self):
            return SecLangParser.RULE_engine_config_directive

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterEngine_config_directive" ):
                listener.enterEngine_config_directive(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitEngine_config_directive" ):
                listener.exitEngine_config_directive(self)




    def engine_config_directive(self):

        localctx = SecLangParser.Engine_config_directiveContext(self, self._ctx, self.state)
        self.enterRule(localctx, 10, self.RULE_engine_config_directive)
        try:
            self.state = 294
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,22,self._ctx)
            if la_ == 1:
                self.enterOuterAlt(localctx, 1)
                self.state = 266
                self.stmt_audit_log()
                self.state = 267
                self.values()
                pass

            elif la_ == 2:
                self.enterOuterAlt(localctx, 2)
                self.state = 269
                self.stmt_audit_log()
                self.state = 270
                self.match(SecLangParser.QUOTE)
                self.state = 271
                self.values()
                self.state = 272
                self.match(SecLangParser.QUOTE)
                pass

            elif la_ == 3:
                self.enterOuterAlt(localctx, 3)
                self.state = 274
                self.engine_config_action_directive()
                self.state = 275
                self.actions()
                pass

            elif la_ == 4:
                self.enterOuterAlt(localctx, 4)
                self.state = 277
                self.string_engine_config_directive()
                self.state = 278
                self.match(SecLangParser.QUOTE)
                self.state = 279
                self.values()
                self.state = 280
                self.match(SecLangParser.QUOTE)
                pass

            elif la_ == 5:
                self.enterOuterAlt(localctx, 5)
                self.state = 282
                self.sec_marker_directive()
                self.state = 283
                self.match(SecLangParser.QUOTE)
                self.state = 284
                self.values()
                self.state = 285
                self.match(SecLangParser.QUOTE)
                pass

            elif la_ == 6:
                self.enterOuterAlt(localctx, 6)
                self.state = 287
                self.engine_config_directive_with_param()
                self.state = 288
                self.values()
                pass

            elif la_ == 7:
                self.enterOuterAlt(localctx, 7)
                self.state = 290
                self.engine_config_sec_cache_transformations()
                self.state = 291
                self.values()
                self.state = 292
                self.option_list()
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class String_engine_config_directiveContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def CONFIG_COMPONENT_SIG(self):
            return self.getToken(SecLangParser.CONFIG_COMPONENT_SIG, 0)

        def CONFIG_SEC_SERVER_SIG(self):
            return self.getToken(SecLangParser.CONFIG_SEC_SERVER_SIG, 0)

        def CONFIG_SEC_WEB_APP_ID(self):
            return self.getToken(SecLangParser.CONFIG_SEC_WEB_APP_ID, 0)

        def getRuleIndex(self):
            return SecLangParser.RULE_string_engine_config_directive

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterString_engine_config_directive" ):
                listener.enterString_engine_config_directive(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitString_engine_config_directive" ):
                listener.exitString_engine_config_directive(self)




    def string_engine_config_directive(self):

        localctx = SecLangParser.String_engine_config_directiveContext(self, self._ctx, self.state)
        self.enterRule(localctx, 12, self.RULE_string_engine_config_directive)
        try:
            self.state = 300
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [1]:
                self.enterOuterAlt(localctx, 1)

                pass
            elif token in [127]:
                self.enterOuterAlt(localctx, 2)
                self.state = 297
                self.match(SecLangParser.CONFIG_COMPONENT_SIG)
                pass
            elif token in [128]:
                self.enterOuterAlt(localctx, 3)
                self.state = 298
                self.match(SecLangParser.CONFIG_SEC_SERVER_SIG)
                pass
            elif token in [129]:
                self.enterOuterAlt(localctx, 4)
                self.state = 299
                self.match(SecLangParser.CONFIG_SEC_WEB_APP_ID)
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Sec_marker_directiveContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def CONFIG_DIR_SEC_MARKER(self):
            return self.getToken(SecLangParser.CONFIG_DIR_SEC_MARKER, 0)

        def getRuleIndex(self):
            return SecLangParser.RULE_sec_marker_directive

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterSec_marker_directive" ):
                listener.enterSec_marker_directive(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitSec_marker_directive" ):
                listener.exitSec_marker_directive(self)




    def sec_marker_directive(self):

        localctx = SecLangParser.Sec_marker_directiveContext(self, self._ctx, self.state)
        self.enterRule(localctx, 14, self.RULE_sec_marker_directive)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 302
            self.match(SecLangParser.CONFIG_DIR_SEC_MARKER)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Engine_config_directive_with_paramContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def CONFIG_CONN_ENGINE(self):
            return self.getToken(SecLangParser.CONFIG_CONN_ENGINE, 0)

        def CONFIG_CONTENT_INJECTION(self):
            return self.getToken(SecLangParser.CONFIG_CONTENT_INJECTION, 0)

        def CONFIG_DIR_ARGS_LIMIT(self):
            return self.getToken(SecLangParser.CONFIG_DIR_ARGS_LIMIT, 0)

        def CONFIG_DIR_DEBUG_LOG(self):
            return self.getToken(SecLangParser.CONFIG_DIR_DEBUG_LOG, 0)

        def CONFIG_DIR_DEBUG_LVL(self):
            return self.getToken(SecLangParser.CONFIG_DIR_DEBUG_LVL, 0)

        def CONFIG_DIR_GEO_DB(self):
            return self.getToken(SecLangParser.CONFIG_DIR_GEO_DB, 0)

        def CONFIG_DIR_GSB_DB(self):
            return self.getToken(SecLangParser.CONFIG_DIR_GSB_DB, 0)

        def CONFIG_DIR_PCRE_MATCH_LIMIT(self):
            return self.getToken(SecLangParser.CONFIG_DIR_PCRE_MATCH_LIMIT, 0)

        def CONFIG_DIR_PCRE_MATCH_LIMIT_RECURSION(self):
            return self.getToken(SecLangParser.CONFIG_DIR_PCRE_MATCH_LIMIT_RECURSION, 0)

        def CONFIG_DIR_REQ_BODY(self):
            return self.getToken(SecLangParser.CONFIG_DIR_REQ_BODY, 0)

        def CONFIG_DIR_REQ_BODY_JSON_DEPTH_LIMIT(self):
            return self.getToken(SecLangParser.CONFIG_DIR_REQ_BODY_JSON_DEPTH_LIMIT, 0)

        def CONFIG_DIR_REQ_BODY_LIMIT(self):
            return self.getToken(SecLangParser.CONFIG_DIR_REQ_BODY_LIMIT, 0)

        def CONFIG_DIR_REQ_BODY_LIMIT_ACTION(self):
            return self.getToken(SecLangParser.CONFIG_DIR_REQ_BODY_LIMIT_ACTION, 0)

        def CONFIG_DIR_REQ_BODY_NO_FILES_LIMIT(self):
            return self.getToken(SecLangParser.CONFIG_DIR_REQ_BODY_NO_FILES_LIMIT, 0)

        def CONFIG_DIR_RESPONSE_BODY_MP(self):
            return self.getToken(SecLangParser.CONFIG_DIR_RESPONSE_BODY_MP, 0)

        def CONFIG_DIR_RESPONSE_BODY_MP_CLEAR(self):
            return self.getToken(SecLangParser.CONFIG_DIR_RESPONSE_BODY_MP_CLEAR, 0)

        def CONFIG_DIR_RES_BODY(self):
            return self.getToken(SecLangParser.CONFIG_DIR_RES_BODY, 0)

        def CONFIG_DIR_RES_BODY_LIMIT(self):
            return self.getToken(SecLangParser.CONFIG_DIR_RES_BODY_LIMIT, 0)

        def CONFIG_DIR_RES_BODY_LIMIT_ACTION(self):
            return self.getToken(SecLangParser.CONFIG_DIR_RES_BODY_LIMIT_ACTION, 0)

        def CONFIG_DIR_RULE_ENG(self):
            return self.getToken(SecLangParser.CONFIG_DIR_RULE_ENG, 0)

        def CONFIG_DIR_SEC_COOKIE_FORMAT(self):
            return self.getToken(SecLangParser.CONFIG_DIR_SEC_COOKIE_FORMAT, 0)

        def CONFIG_DIR_SEC_DATA_DIR(self):
            return self.getToken(SecLangParser.CONFIG_DIR_SEC_DATA_DIR, 0)

        def CONFIG_DIR_SEC_STATUS_ENGINE(self):
            return self.getToken(SecLangParser.CONFIG_DIR_SEC_STATUS_ENGINE, 0)

        def CONFIG_DIR_SEC_TMP_DIR(self):
            return self.getToken(SecLangParser.CONFIG_DIR_SEC_TMP_DIR, 0)

        def CONFIG_DIR_UNICODE_MAP_FILE(self):
            return self.getToken(SecLangParser.CONFIG_DIR_UNICODE_MAP_FILE, 0)

        def CONFIG_SEC_ARGUMENT_SEPARATOR(self):
            return self.getToken(SecLangParser.CONFIG_SEC_ARGUMENT_SEPARATOR, 0)

        def CONFIG_SEC_CHROOT_DIR(self):
            return self.getToken(SecLangParser.CONFIG_SEC_CHROOT_DIR, 0)

        def CONFIG_SEC_COLLECTION_TIMEOUT(self):
            return self.getToken(SecLangParser.CONFIG_SEC_COLLECTION_TIMEOUT, 0)

        def CONFIG_SEC_CONN_R_STATE_LIMIT(self):
            return self.getToken(SecLangParser.CONFIG_SEC_CONN_R_STATE_LIMIT, 0)

        def CONFIG_SEC_CONN_W_STATE_LIMIT(self):
            return self.getToken(SecLangParser.CONFIG_SEC_CONN_W_STATE_LIMIT, 0)

        def CONFIG_SEC_COOKIEV0_SEPARATOR(self):
            return self.getToken(SecLangParser.CONFIG_SEC_COOKIEV0_SEPARATOR, 0)

        def CONFIG_SEC_DISABLE_BACKEND_COMPRESS(self):
            return self.getToken(SecLangParser.CONFIG_SEC_DISABLE_BACKEND_COMPRESS, 0)

        def CONFIG_SEC_GUARDIAN_LOG(self):
            return self.getToken(SecLangParser.CONFIG_SEC_GUARDIAN_LOG, 0)

        def CONFIG_SEC_HASH_ENGINE(self):
            return self.getToken(SecLangParser.CONFIG_SEC_HASH_ENGINE, 0)

        def CONFIG_SEC_HASH_KEY(self):
            return self.getToken(SecLangParser.CONFIG_SEC_HASH_KEY, 0)

        def CONFIG_SEC_HASH_METHOD_PM(self):
            return self.getToken(SecLangParser.CONFIG_SEC_HASH_METHOD_PM, 0)

        def CONFIG_SEC_HASH_METHOD_RX(self):
            return self.getToken(SecLangParser.CONFIG_SEC_HASH_METHOD_RX, 0)

        def CONFIG_SEC_HASH_PARAM(self):
            return self.getToken(SecLangParser.CONFIG_SEC_HASH_PARAM, 0)

        def CONFIG_SEC_HTTP_BLKEY(self):
            return self.getToken(SecLangParser.CONFIG_SEC_HTTP_BLKEY, 0)

        def CONFIG_SEC_INTERCEPT_ON_ERROR(self):
            return self.getToken(SecLangParser.CONFIG_SEC_INTERCEPT_ON_ERROR, 0)

        def CONFIG_SEC_REMOTE_RULES_FAIL_ACTION(self):
            return self.getToken(SecLangParser.CONFIG_SEC_REMOTE_RULES_FAIL_ACTION, 0)

        def CONFIG_SEC_RULE_INHERITANCE(self):
            return self.getToken(SecLangParser.CONFIG_SEC_RULE_INHERITANCE, 0)

        def CONFIG_SEC_RULE_PERF_TIME(self):
            return self.getToken(SecLangParser.CONFIG_SEC_RULE_PERF_TIME, 0)

        def CONFIG_SEC_SENSOR_ID(self):
            return self.getToken(SecLangParser.CONFIG_SEC_SENSOR_ID, 0)

        def CONFIG_SEC_STREAM_IN_BODY_INSPECTION(self):
            return self.getToken(SecLangParser.CONFIG_SEC_STREAM_IN_BODY_INSPECTION, 0)

        def CONFIG_SEC_STREAM_OUT_BODY_INSPECTION(self):
            return self.getToken(SecLangParser.CONFIG_SEC_STREAM_OUT_BODY_INSPECTION, 0)

        def CONFIG_XML_EXTERNAL_ENTITY(self):
            return self.getToken(SecLangParser.CONFIG_XML_EXTERNAL_ENTITY, 0)

        def getRuleIndex(self):
            return SecLangParser.RULE_engine_config_directive_with_param

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterEngine_config_directive_with_param" ):
                listener.enterEngine_config_directive_with_param(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitEngine_config_directive_with_param" ):
                listener.exitEngine_config_directive_with_param(self)




    def engine_config_directive_with_param(self):

        localctx = SecLangParser.Engine_config_directive_with_paramContext(self, self._ctx, self.state)
        self.enterRule(localctx, 16, self.RULE_engine_config_directive_with_param)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 304
            _la = self._input.LA(1)
            if not(((((_la - 131)) & ~0x3f) == 0 and ((1 << (_la - 131)) & 25508532324925951) != 0) or ((((_la - 209)) & ~0x3f) == 0 and ((1 << (_la - 209)) & 255) != 0)):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Rule_script_directiveContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def DIRECTIVE_SECRULESCRIPT(self):
            return self.getToken(SecLangParser.DIRECTIVE_SECRULESCRIPT, 0)

        def getRuleIndex(self):
            return SecLangParser.RULE_rule_script_directive

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterRule_script_directive" ):
                listener.enterRule_script_directive(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitRule_script_directive" ):
                listener.exitRule_script_directive(self)




    def rule_script_directive(self):

        localctx = SecLangParser.Rule_script_directiveContext(self, self._ctx, self.state)
        self.enterRule(localctx, 18, self.RULE_rule_script_directive)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 306
            self.match(SecLangParser.DIRECTIVE_SECRULESCRIPT)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class File_pathContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def CONFIG_VALUE_PATH(self):
            return self.getToken(SecLangParser.CONFIG_VALUE_PATH, 0)

        def getRuleIndex(self):
            return SecLangParser.RULE_file_path

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterFile_path" ):
                listener.enterFile_path(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitFile_path" ):
                listener.exitFile_path(self)




    def file_path(self):

        localctx = SecLangParser.File_pathContext(self, self._ctx, self.state)
        self.enterRule(localctx, 20, self.RULE_file_path)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 308
            self.match(SecLangParser.CONFIG_VALUE_PATH)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Remove_rule_by_idContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def CONFIG_SEC_RULE_REMOVE_BY_ID(self):
            return self.getToken(SecLangParser.CONFIG_SEC_RULE_REMOVE_BY_ID, 0)

        def getRuleIndex(self):
            return SecLangParser.RULE_remove_rule_by_id

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterRemove_rule_by_id" ):
                listener.enterRemove_rule_by_id(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitRemove_rule_by_id" ):
                listener.exitRemove_rule_by_id(self)




    def remove_rule_by_id(self):

        localctx = SecLangParser.Remove_rule_by_idContext(self, self._ctx, self.state)
        self.enterRule(localctx, 22, self.RULE_remove_rule_by_id)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 310
            self.match(SecLangParser.CONFIG_SEC_RULE_REMOVE_BY_ID)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Remove_rule_by_id_valuesContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return SecLangParser.RULE_remove_rule_by_id_values

     
        def copyFrom(self, ctx:ParserRuleContext):
            super().copyFrom(ctx)



    class Remove_rule_by_id_intContext(Remove_rule_by_id_valuesContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a SecLangParser.Remove_rule_by_id_valuesContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def INT(self):
            return self.getToken(SecLangParser.INT, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterRemove_rule_by_id_int" ):
                listener.enterRemove_rule_by_id_int(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitRemove_rule_by_id_int" ):
                listener.exitRemove_rule_by_id_int(self)


    class Remove_rule_by_id_int_rangeContext(Remove_rule_by_id_valuesContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a SecLangParser.Remove_rule_by_id_valuesContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def int_range(self):
            return self.getTypedRuleContext(SecLangParser.Int_rangeContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterRemove_rule_by_id_int_range" ):
                listener.enterRemove_rule_by_id_int_range(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitRemove_rule_by_id_int_range" ):
                listener.exitRemove_rule_by_id_int_range(self)



    def remove_rule_by_id_values(self):

        localctx = SecLangParser.Remove_rule_by_id_valuesContext(self, self._ctx, self.state)
        self.enterRule(localctx, 24, self.RULE_remove_rule_by_id_values)
        try:
            self.state = 314
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,24,self._ctx)
            if la_ == 1:
                localctx = SecLangParser.Remove_rule_by_id_intContext(self, localctx)
                self.enterOuterAlt(localctx, 1)
                self.state = 312
                self.match(SecLangParser.INT)
                pass

            elif la_ == 2:
                localctx = SecLangParser.Remove_rule_by_id_int_rangeContext(self, localctx)
                self.enterOuterAlt(localctx, 2)
                self.state = 313
                self.int_range()
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Operator_int_rangeContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def INT_RANGE_VALUE(self, i:int=None):
            if i is None:
                return self.getTokens(SecLangParser.INT_RANGE_VALUE)
            else:
                return self.getToken(SecLangParser.INT_RANGE_VALUE, i)

        def MINUS_INT_RANGE(self):
            return self.getToken(SecLangParser.MINUS_INT_RANGE, 0)

        def getRuleIndex(self):
            return SecLangParser.RULE_operator_int_range

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterOperator_int_range" ):
                listener.enterOperator_int_range(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitOperator_int_range" ):
                listener.exitOperator_int_range(self)




    def operator_int_range(self):

        localctx = SecLangParser.Operator_int_rangeContext(self, self._ctx, self.state)
        self.enterRule(localctx, 26, self.RULE_operator_int_range)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 316
            self.match(SecLangParser.INT_RANGE_VALUE)
            self.state = 317
            self.match(SecLangParser.MINUS_INT_RANGE)
            self.state = 318
            self.match(SecLangParser.INT_RANGE_VALUE)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Int_rangeContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def range_start(self):
            return self.getTypedRuleContext(SecLangParser.Range_startContext,0)


        def MINUS(self):
            return self.getToken(SecLangParser.MINUS, 0)

        def range_end(self):
            return self.getTypedRuleContext(SecLangParser.Range_endContext,0)


        def getRuleIndex(self):
            return SecLangParser.RULE_int_range

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterInt_range" ):
                listener.enterInt_range(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitInt_range" ):
                listener.exitInt_range(self)




    def int_range(self):

        localctx = SecLangParser.Int_rangeContext(self, self._ctx, self.state)
        self.enterRule(localctx, 28, self.RULE_int_range)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 320
            self.range_start()
            self.state = 321
            self.match(SecLangParser.MINUS)
            self.state = 322
            self.range_end()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Range_startContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def INT(self):
            return self.getToken(SecLangParser.INT, 0)

        def getRuleIndex(self):
            return SecLangParser.RULE_range_start

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterRange_start" ):
                listener.enterRange_start(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitRange_start" ):
                listener.exitRange_start(self)




    def range_start(self):

        localctx = SecLangParser.Range_startContext(self, self._ctx, self.state)
        self.enterRule(localctx, 30, self.RULE_range_start)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 324
            self.match(SecLangParser.INT)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Range_endContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def INT(self):
            return self.getToken(SecLangParser.INT, 0)

        def getRuleIndex(self):
            return SecLangParser.RULE_range_end

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterRange_end" ):
                listener.enterRange_end(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitRange_end" ):
                listener.exitRange_end(self)




    def range_end(self):

        localctx = SecLangParser.Range_endContext(self, self._ctx, self.state)
        self.enterRule(localctx, 32, self.RULE_range_end)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 326
            self.match(SecLangParser.INT)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class String_remove_rulesContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return SecLangParser.RULE_string_remove_rules

     
        def copyFrom(self, ctx:ParserRuleContext):
            super().copyFrom(ctx)



    class Remove_rule_by_msgContext(String_remove_rulesContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a SecLangParser.String_remove_rulesContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def CONFIG_SEC_RULE_REMOVE_BY_MSG(self):
            return self.getToken(SecLangParser.CONFIG_SEC_RULE_REMOVE_BY_MSG, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterRemove_rule_by_msg" ):
                listener.enterRemove_rule_by_msg(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitRemove_rule_by_msg" ):
                listener.exitRemove_rule_by_msg(self)


    class Remove_rule_by_tagContext(String_remove_rulesContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a SecLangParser.String_remove_rulesContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def CONFIG_SEC_RULE_REMOVE_BY_TAG(self):
            return self.getToken(SecLangParser.CONFIG_SEC_RULE_REMOVE_BY_TAG, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterRemove_rule_by_tag" ):
                listener.enterRemove_rule_by_tag(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitRemove_rule_by_tag" ):
                listener.exitRemove_rule_by_tag(self)



    def string_remove_rules(self):

        localctx = SecLangParser.String_remove_rulesContext(self, self._ctx, self.state)
        self.enterRule(localctx, 34, self.RULE_string_remove_rules)
        try:
            self.state = 330
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [187]:
                localctx = SecLangParser.Remove_rule_by_msgContext(self, localctx)
                self.enterOuterAlt(localctx, 1)
                self.state = 328
                self.match(SecLangParser.CONFIG_SEC_RULE_REMOVE_BY_MSG)
                pass
            elif token in [188]:
                localctx = SecLangParser.Remove_rule_by_tagContext(self, localctx)
                self.enterOuterAlt(localctx, 2)
                self.state = 329
                self.match(SecLangParser.CONFIG_SEC_RULE_REMOVE_BY_TAG)
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class String_remove_rules_valuesContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def STRING(self):
            return self.getToken(SecLangParser.STRING, 0)

        def VARIABLE_NAME(self):
            return self.getToken(SecLangParser.VARIABLE_NAME, 0)

        def COMMA_SEPARATED_STRING(self):
            return self.getToken(SecLangParser.COMMA_SEPARATED_STRING, 0)

        def getRuleIndex(self):
            return SecLangParser.RULE_string_remove_rules_values

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterString_remove_rules_values" ):
                listener.enterString_remove_rules_values(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitString_remove_rules_values" ):
                listener.exitString_remove_rules_values(self)




    def string_remove_rules_values(self):

        localctx = SecLangParser.String_remove_rules_valuesContext(self, self._ctx, self.state)
        self.enterRule(localctx, 36, self.RULE_string_remove_rules_values)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 332
            _la = self._input.LA(1)
            if not(((((_la - 225)) & ~0x3f) == 0 and ((1 << (_la - 225)) & 65793) != 0)):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Update_target_rulesContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return SecLangParser.RULE_update_target_rules

     
        def copyFrom(self, ctx:ParserRuleContext):
            super().copyFrom(ctx)



    class Update_target_by_tagContext(Update_target_rulesContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a SecLangParser.Update_target_rulesContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def CONFIG_SEC_RULE_UPDATE_TARGET_BY_TAG(self):
            return self.getToken(SecLangParser.CONFIG_SEC_RULE_UPDATE_TARGET_BY_TAG, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterUpdate_target_by_tag" ):
                listener.enterUpdate_target_by_tag(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitUpdate_target_by_tag" ):
                listener.exitUpdate_target_by_tag(self)


    class Update_target_by_idContext(Update_target_rulesContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a SecLangParser.Update_target_rulesContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def CONFIG_SEC_RULE_UPDATE_TARGET_BY_ID(self):
            return self.getToken(SecLangParser.CONFIG_SEC_RULE_UPDATE_TARGET_BY_ID, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterUpdate_target_by_id" ):
                listener.enterUpdate_target_by_id(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitUpdate_target_by_id" ):
                listener.exitUpdate_target_by_id(self)


    class Update_target_by_msgContext(Update_target_rulesContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a SecLangParser.Update_target_rulesContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def CONFIG_SEC_RULE_UPDATE_TARGET_BY_MSG(self):
            return self.getToken(SecLangParser.CONFIG_SEC_RULE_UPDATE_TARGET_BY_MSG, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterUpdate_target_by_msg" ):
                listener.enterUpdate_target_by_msg(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitUpdate_target_by_msg" ):
                listener.exitUpdate_target_by_msg(self)



    def update_target_rules(self):

        localctx = SecLangParser.Update_target_rulesContext(self, self._ctx, self.state)
        self.enterRule(localctx, 38, self.RULE_update_target_rules)
        try:
            self.state = 337
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [191]:
                localctx = SecLangParser.Update_target_by_idContext(self, localctx)
                self.enterOuterAlt(localctx, 1)
                self.state = 334
                self.match(SecLangParser.CONFIG_SEC_RULE_UPDATE_TARGET_BY_ID)
                pass
            elif token in [190]:
                localctx = SecLangParser.Update_target_by_msgContext(self, localctx)
                self.enterOuterAlt(localctx, 2)
                self.state = 335
                self.match(SecLangParser.CONFIG_SEC_RULE_UPDATE_TARGET_BY_MSG)
                pass
            elif token in [189]:
                localctx = SecLangParser.Update_target_by_tagContext(self, localctx)
                self.enterOuterAlt(localctx, 3)
                self.state = 336
                self.match(SecLangParser.CONFIG_SEC_RULE_UPDATE_TARGET_BY_TAG)
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Update_action_ruleContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def CONFIG_SEC_RULE_UPDATE_ACTION_BY_ID(self):
            return self.getToken(SecLangParser.CONFIG_SEC_RULE_UPDATE_ACTION_BY_ID, 0)

        def getRuleIndex(self):
            return SecLangParser.RULE_update_action_rule

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterUpdate_action_rule" ):
                listener.enterUpdate_action_rule(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitUpdate_action_rule" ):
                listener.exitUpdate_action_rule(self)




    def update_action_rule(self):

        localctx = SecLangParser.Update_action_ruleContext(self, self._ctx, self.state)
        self.enterRule(localctx, 40, self.RULE_update_action_rule)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 339
            self.match(SecLangParser.CONFIG_SEC_RULE_UPDATE_ACTION_BY_ID)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class IdContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def INT(self):
            return self.getToken(SecLangParser.INT, 0)

        def getRuleIndex(self):
            return SecLangParser.RULE_id

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterId" ):
                listener.enterId(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitId" ):
                listener.exitId(self)




    def id_(self):

        localctx = SecLangParser.IdContext(self, self._ctx, self.state)
        self.enterRule(localctx, 42, self.RULE_id)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 341
            self.match(SecLangParser.INT)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Engine_config_sec_cache_transformationsContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def CONFIG_SEC_CACHE_TRANSFORMATIONS(self):
            return self.getToken(SecLangParser.CONFIG_SEC_CACHE_TRANSFORMATIONS, 0)

        def getRuleIndex(self):
            return SecLangParser.RULE_engine_config_sec_cache_transformations

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterEngine_config_sec_cache_transformations" ):
                listener.enterEngine_config_sec_cache_transformations(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitEngine_config_sec_cache_transformations" ):
                listener.exitEngine_config_sec_cache_transformations(self)




    def engine_config_sec_cache_transformations(self):

        localctx = SecLangParser.Engine_config_sec_cache_transformationsContext(self, self._ctx, self.state)
        self.enterRule(localctx, 44, self.RULE_engine_config_sec_cache_transformations)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 343
            self.match(SecLangParser.CONFIG_SEC_CACHE_TRANSFORMATIONS)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Option_listContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def QUOTE(self, i:int=None):
            if i is None:
                return self.getTokens(SecLangParser.QUOTE)
            else:
                return self.getToken(SecLangParser.QUOTE, i)

        def option(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(SecLangParser.OptionContext)
            else:
                return self.getTypedRuleContext(SecLangParser.OptionContext,i)


        def COMMA(self, i:int=None):
            if i is None:
                return self.getTokens(SecLangParser.COMMA)
            else:
                return self.getToken(SecLangParser.COMMA, i)

        def getRuleIndex(self):
            return SecLangParser.RULE_option_list

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterOption_list" ):
                listener.enterOption_list(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitOption_list" ):
                listener.exitOption_list(self)




    def option_list(self):

        localctx = SecLangParser.Option_listContext(self, self._ctx, self.state)
        self.enterRule(localctx, 46, self.RULE_option_list)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 345
            self.match(SecLangParser.QUOTE)
            self.state = 346
            self.option()
            self.state = 351
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==7:
                self.state = 347
                self.match(SecLangParser.COMMA)
                self.state = 348
                self.option()
                self.state = 353
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 354
            self.match(SecLangParser.QUOTE)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class OptionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def option_name(self):
            return self.getTypedRuleContext(SecLangParser.Option_nameContext,0)


        def COLON(self):
            return self.getToken(SecLangParser.COLON, 0)

        def values(self):
            return self.getTypedRuleContext(SecLangParser.ValuesContext,0)


        def getRuleIndex(self):
            return SecLangParser.RULE_option

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterOption" ):
                listener.enterOption(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitOption" ):
                listener.exitOption(self)




    def option(self):

        localctx = SecLangParser.OptionContext(self, self._ctx, self.state)
        self.enterRule(localctx, 48, self.RULE_option)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 356
            self.option_name()
            self.state = 357
            self.match(SecLangParser.COLON)
            self.state = 358
            self.values()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Option_nameContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def OPTION_NAME(self):
            return self.getToken(SecLangParser.OPTION_NAME, 0)

        def getRuleIndex(self):
            return SecLangParser.RULE_option_name

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterOption_name" ):
                listener.enterOption_name(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitOption_name" ):
                listener.exitOption_name(self)




    def option_name(self):

        localctx = SecLangParser.Option_nameContext(self, self._ctx, self.state)
        self.enterRule(localctx, 50, self.RULE_option_name)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 360
            self.match(SecLangParser.OPTION_NAME)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Engine_config_action_directiveContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return SecLangParser.RULE_engine_config_action_directive

     
        def copyFrom(self, ctx:ParserRuleContext):
            super().copyFrom(ctx)



    class Config_dir_sec_actionContext(Engine_config_action_directiveContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a SecLangParser.Engine_config_action_directiveContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def CONFIG_DIR_SEC_ACTION(self):
            return self.getToken(SecLangParser.CONFIG_DIR_SEC_ACTION, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterConfig_dir_sec_action" ):
                listener.enterConfig_dir_sec_action(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitConfig_dir_sec_action" ):
                listener.exitConfig_dir_sec_action(self)


    class Config_dir_sec_default_actionContext(Engine_config_action_directiveContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a SecLangParser.Engine_config_action_directiveContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def CONFIG_DIR_SEC_DEFAULT_ACTION(self):
            return self.getToken(SecLangParser.CONFIG_DIR_SEC_DEFAULT_ACTION, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterConfig_dir_sec_default_action" ):
                listener.enterConfig_dir_sec_default_action(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitConfig_dir_sec_default_action" ):
                listener.exitConfig_dir_sec_default_action(self)



    def engine_config_action_directive(self):

        localctx = SecLangParser.Engine_config_action_directiveContext(self, self._ctx, self.state)
        self.enterRule(localctx, 52, self.RULE_engine_config_action_directive)
        try:
            self.state = 364
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [176]:
                localctx = SecLangParser.Config_dir_sec_actionContext(self, localctx)
                self.enterOuterAlt(localctx, 1)
                self.state = 362
                self.match(SecLangParser.CONFIG_DIR_SEC_ACTION)
                pass
            elif token in [177]:
                localctx = SecLangParser.Config_dir_sec_default_actionContext(self, localctx)
                self.enterOuterAlt(localctx, 2)
                self.state = 363
                self.match(SecLangParser.CONFIG_DIR_SEC_DEFAULT_ACTION)
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Stmt_audit_logContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def CONFIG_DIR_AUDIT_DIR_MOD(self):
            return self.getToken(SecLangParser.CONFIG_DIR_AUDIT_DIR_MOD, 0)

        def CONFIG_DIR_AUDIT_DIR(self):
            return self.getToken(SecLangParser.CONFIG_DIR_AUDIT_DIR, 0)

        def CONFIG_DIR_AUDIT_ENG(self):
            return self.getToken(SecLangParser.CONFIG_DIR_AUDIT_ENG, 0)

        def CONFIG_DIR_AUDIT_FILE_MODE(self):
            return self.getToken(SecLangParser.CONFIG_DIR_AUDIT_FILE_MODE, 0)

        def CONFIG_DIR_AUDIT_LOG2(self):
            return self.getToken(SecLangParser.CONFIG_DIR_AUDIT_LOG2, 0)

        def CONFIG_DIR_AUDIT_LOG_P(self):
            return self.getToken(SecLangParser.CONFIG_DIR_AUDIT_LOG_P, 0)

        def CONFIG_DIR_AUDIT_LOG(self):
            return self.getToken(SecLangParser.CONFIG_DIR_AUDIT_LOG, 0)

        def CONFIG_DIR_AUDIT_LOG_FMT(self):
            return self.getToken(SecLangParser.CONFIG_DIR_AUDIT_LOG_FMT, 0)

        def CONFIG_DIR_AUDIT_STS(self):
            return self.getToken(SecLangParser.CONFIG_DIR_AUDIT_STS, 0)

        def CONFIG_DIR_AUDIT_TYPE(self):
            return self.getToken(SecLangParser.CONFIG_DIR_AUDIT_TYPE, 0)

        def CONFIG_UPLOAD_KEEP_FILES(self):
            return self.getToken(SecLangParser.CONFIG_UPLOAD_KEEP_FILES, 0)

        def CONFIG_UPLOAD_FILE_LIMIT(self):
            return self.getToken(SecLangParser.CONFIG_UPLOAD_FILE_LIMIT, 0)

        def CONFIG_UPLOAD_FILE_MODE(self):
            return self.getToken(SecLangParser.CONFIG_UPLOAD_FILE_MODE, 0)

        def CONFIG_UPLOAD_DIR(self):
            return self.getToken(SecLangParser.CONFIG_UPLOAD_DIR, 0)

        def CONFIG_UPLOAD_SAVE_TMP_FILES(self):
            return self.getToken(SecLangParser.CONFIG_UPLOAD_SAVE_TMP_FILES, 0)

        def INT(self):
            return self.getToken(SecLangParser.INT, 0)

        def getRuleIndex(self):
            return SecLangParser.RULE_stmt_audit_log

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterStmt_audit_log" ):
                listener.enterStmt_audit_log(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitStmt_audit_log" ):
                listener.exitStmt_audit_log(self)




    def stmt_audit_log(self):

        localctx = SecLangParser.Stmt_audit_logContext(self, self._ctx, self.state)
        self.enterRule(localctx, 54, self.RULE_stmt_audit_log)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 366
            _la = self._input.LA(1)
            if not(((((_la - 140)) & ~0x3f) == 0 and ((1 << (_la - 140)) & 279223176896971775) != 0) or _la==227):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ValuesContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def INT(self):
            return self.getToken(SecLangParser.INT, 0)

        def int_range(self):
            return self.getTypedRuleContext(SecLangParser.Int_rangeContext,0)


        def CONFIG_VALUE_ON(self):
            return self.getToken(SecLangParser.CONFIG_VALUE_ON, 0)

        def CONFIG_VALUE_OFF(self):
            return self.getToken(SecLangParser.CONFIG_VALUE_OFF, 0)

        def CONFIG_VALUE_SERIAL(self):
            return self.getToken(SecLangParser.CONFIG_VALUE_SERIAL, 0)

        def CONFIG_VALUE_PARALLEL(self):
            return self.getToken(SecLangParser.CONFIG_VALUE_PARALLEL, 0)

        def CONFIG_VALUE_HTTPS(self):
            return self.getToken(SecLangParser.CONFIG_VALUE_HTTPS, 0)

        def CONFIG_VALUE_RELEVANT_ONLY(self):
            return self.getToken(SecLangParser.CONFIG_VALUE_RELEVANT_ONLY, 0)

        def NATIVE(self):
            return self.getToken(SecLangParser.NATIVE, 0)

        def CONFIG_VALUE_ABORT(self):
            return self.getToken(SecLangParser.CONFIG_VALUE_ABORT, 0)

        def CONFIG_VALUE_WARN(self):
            return self.getToken(SecLangParser.CONFIG_VALUE_WARN, 0)

        def CONFIG_VALUE_DETC(self):
            return self.getToken(SecLangParser.CONFIG_VALUE_DETC, 0)

        def CONFIG_VALUE_PROCESS_PARTIAL(self):
            return self.getToken(SecLangParser.CONFIG_VALUE_PROCESS_PARTIAL, 0)

        def CONFIG_VALUE_REJECT(self):
            return self.getToken(SecLangParser.CONFIG_VALUE_REJECT, 0)

        def CONFIG_VALUE_PATH(self):
            return self.getToken(SecLangParser.CONFIG_VALUE_PATH, 0)

        def STRING(self):
            return self.getToken(SecLangParser.STRING, 0)

        def VARIABLE_NAME(self):
            return self.getToken(SecLangParser.VARIABLE_NAME, 0)

        def COMMA_SEPARATED_STRING(self):
            return self.getToken(SecLangParser.COMMA_SEPARATED_STRING, 0)

        def ACTION_CTL_BODY_PROCESSOR_TYPE(self):
            return self.getToken(SecLangParser.ACTION_CTL_BODY_PROCESSOR_TYPE, 0)

        def AUDIT_PARTS(self):
            return self.getToken(SecLangParser.AUDIT_PARTS, 0)

        def action_ctl_target_value(self):
            return self.getTypedRuleContext(SecLangParser.Action_ctl_target_valueContext,0)


        def getRuleIndex(self):
            return SecLangParser.RULE_values

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterValues" ):
                listener.enterValues(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitValues" ):
                listener.exitValues(self)




    def values(self):

        localctx = SecLangParser.ValuesContext(self, self._ctx, self.state)
        self.enterRule(localctx, 56, self.RULE_values)
        try:
            self.state = 391
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,29,self._ctx)
            if la_ == 1:
                self.enterOuterAlt(localctx, 1)
                self.state = 368
                self.match(SecLangParser.INT)
                pass

            elif la_ == 2:
                self.enterOuterAlt(localctx, 2)
                self.state = 369
                self.int_range()
                pass

            elif la_ == 3:
                self.enterOuterAlt(localctx, 3)
                self.state = 370
                self.match(SecLangParser.CONFIG_VALUE_ON)
                pass

            elif la_ == 4:
                self.enterOuterAlt(localctx, 4)
                self.state = 371
                self.match(SecLangParser.CONFIG_VALUE_OFF)
                pass

            elif la_ == 5:
                self.enterOuterAlt(localctx, 5)
                self.state = 372
                self.match(SecLangParser.CONFIG_VALUE_SERIAL)
                pass

            elif la_ == 6:
                self.enterOuterAlt(localctx, 6)
                self.state = 373
                self.match(SecLangParser.CONFIG_VALUE_PARALLEL)
                pass

            elif la_ == 7:
                self.enterOuterAlt(localctx, 7)
                self.state = 374
                self.match(SecLangParser.CONFIG_VALUE_HTTPS)
                pass

            elif la_ == 8:
                self.enterOuterAlt(localctx, 8)
                self.state = 375
                self.match(SecLangParser.CONFIG_VALUE_RELEVANT_ONLY)
                pass

            elif la_ == 9:
                self.enterOuterAlt(localctx, 9)
                self.state = 376
                self.match(SecLangParser.NATIVE)
                pass

            elif la_ == 10:
                self.enterOuterAlt(localctx, 10)
                self.state = 377
                self.match(SecLangParser.CONFIG_VALUE_ABORT)
                pass

            elif la_ == 11:
                self.enterOuterAlt(localctx, 11)
                self.state = 378
                self.match(SecLangParser.CONFIG_VALUE_WARN)
                pass

            elif la_ == 12:
                self.enterOuterAlt(localctx, 12)
                self.state = 379
                self.match(SecLangParser.CONFIG_VALUE_DETC)
                pass

            elif la_ == 13:
                self.enterOuterAlt(localctx, 13)
                self.state = 380
                self.match(SecLangParser.CONFIG_VALUE_PROCESS_PARTIAL)
                pass

            elif la_ == 14:
                self.enterOuterAlt(localctx, 14)
                self.state = 381
                self.match(SecLangParser.CONFIG_VALUE_REJECT)
                pass

            elif la_ == 15:
                self.enterOuterAlt(localctx, 15)
                self.state = 382
                self.match(SecLangParser.CONFIG_VALUE_PATH)
                self.state = 383
                self.match(SecLangParser.INT)
                pass

            elif la_ == 16:
                self.enterOuterAlt(localctx, 16)
                self.state = 384
                self.match(SecLangParser.CONFIG_VALUE_PATH)
                pass

            elif la_ == 17:
                self.enterOuterAlt(localctx, 17)
                self.state = 385
                self.match(SecLangParser.STRING)
                pass

            elif la_ == 18:
                self.enterOuterAlt(localctx, 18)
                self.state = 386
                self.match(SecLangParser.VARIABLE_NAME)
                pass

            elif la_ == 19:
                self.enterOuterAlt(localctx, 19)
                self.state = 387
                self.match(SecLangParser.COMMA_SEPARATED_STRING)
                pass

            elif la_ == 20:
                self.enterOuterAlt(localctx, 20)
                self.state = 388
                self.match(SecLangParser.ACTION_CTL_BODY_PROCESSOR_TYPE)
                pass

            elif la_ == 21:
                self.enterOuterAlt(localctx, 21)
                self.state = 389
                self.match(SecLangParser.AUDIT_PARTS)
                pass

            elif la_ == 22:
                self.enterOuterAlt(localctx, 22)
                self.state = 390
                self.action_ctl_target_value()
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Action_ctl_target_valueContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def SEMI(self):
            return self.getToken(SecLangParser.SEMI, 0)

        def ctl_variable_enum(self):
            return self.getTypedRuleContext(SecLangParser.Ctl_variable_enumContext,0)


        def ctl_id(self):
            return self.getTypedRuleContext(SecLangParser.Ctl_idContext,0)


        def SINGLE_QUOTE(self, i:int=None):
            if i is None:
                return self.getTokens(SecLangParser.SINGLE_QUOTE)
            else:
                return self.getToken(SecLangParser.SINGLE_QUOTE, i)

        def string_literal(self):
            return self.getTypedRuleContext(SecLangParser.String_literalContext,0)


        def VARIABLE_NAME(self):
            return self.getToken(SecLangParser.VARIABLE_NAME, 0)

        def ctl_collection_enum(self):
            return self.getTypedRuleContext(SecLangParser.Ctl_collection_enumContext,0)


        def COLON(self):
            return self.getToken(SecLangParser.COLON, 0)

        def ctl_collection_value(self):
            return self.getTypedRuleContext(SecLangParser.Ctl_collection_valueContext,0)


        def getRuleIndex(self):
            return SecLangParser.RULE_action_ctl_target_value

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterAction_ctl_target_value" ):
                listener.enterAction_ctl_target_value(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitAction_ctl_target_value" ):
                listener.exitAction_ctl_target_value(self)




    def action_ctl_target_value(self):

        localctx = SecLangParser.Action_ctl_target_valueContext(self, self._ctx, self.state)
        self.enterRule(localctx, 58, self.RULE_action_ctl_target_value)
        self._la = 0 # Token type
        try:
            self.state = 417
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,33,self._ctx)
            if la_ == 1:
                self.enterOuterAlt(localctx, 1)
                self.state = 399
                self._errHandler.sync(self)
                token = self._input.LA(1)
                if token in [226, 227]:
                    self.state = 393
                    self.ctl_id()
                    pass
                elif token in [2]:
                    self.state = 394
                    self.match(SecLangParser.SINGLE_QUOTE)
                    self.state = 395
                    self.string_literal()
                    self.state = 396
                    self.match(SecLangParser.SINGLE_QUOTE)
                    pass
                elif token in [225]:
                    self.state = 398
                    self.match(SecLangParser.VARIABLE_NAME)
                    pass
                else:
                    raise NoViableAltException(self)

                self.state = 401
                self.match(SecLangParser.SEMI)
                self.state = 402
                self.ctl_variable_enum()
                pass

            elif la_ == 2:
                self.enterOuterAlt(localctx, 2)
                self.state = 409
                self._errHandler.sync(self)
                token = self._input.LA(1)
                if token in [226, 227]:
                    self.state = 403
                    self.ctl_id()
                    pass
                elif token in [2]:
                    self.state = 404
                    self.match(SecLangParser.SINGLE_QUOTE)
                    self.state = 405
                    self.string_literal()
                    self.state = 406
                    self.match(SecLangParser.SINGLE_QUOTE)
                    pass
                elif token in [225]:
                    self.state = 408
                    self.match(SecLangParser.VARIABLE_NAME)
                    pass
                else:
                    raise NoViableAltException(self)

                self.state = 411
                self.match(SecLangParser.SEMI)
                self.state = 412
                self.ctl_collection_enum()
                self.state = 415
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==4:
                    self.state = 413
                    self.match(SecLangParser.COLON)
                    self.state = 414
                    self.ctl_collection_value()


                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Update_target_rules_valuesContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def INT(self):
            return self.getToken(SecLangParser.INT, 0)

        def int_range(self):
            return self.getTypedRuleContext(SecLangParser.Int_rangeContext,0)


        def STRING(self):
            return self.getToken(SecLangParser.STRING, 0)

        def getRuleIndex(self):
            return SecLangParser.RULE_update_target_rules_values

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterUpdate_target_rules_values" ):
                listener.enterUpdate_target_rules_values(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitUpdate_target_rules_values" ):
                listener.exitUpdate_target_rules_values(self)




    def update_target_rules_values(self):

        localctx = SecLangParser.Update_target_rules_valuesContext(self, self._ctx, self.state)
        self.enterRule(localctx, 60, self.RULE_update_target_rules_values)
        try:
            self.state = 422
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,34,self._ctx)
            if la_ == 1:
                self.enterOuterAlt(localctx, 1)
                self.state = 419
                self.match(SecLangParser.INT)
                pass

            elif la_ == 2:
                self.enterOuterAlt(localctx, 2)
                self.state = 420
                self.int_range()
                pass

            elif la_ == 3:
                self.enterOuterAlt(localctx, 3)
                self.state = 421
                self.match(SecLangParser.STRING)
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Operator_notContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def NOT(self):
            return self.getToken(SecLangParser.NOT, 0)

        def getRuleIndex(self):
            return SecLangParser.RULE_operator_not

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterOperator_not" ):
                listener.enterOperator_not(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitOperator_not" ):
                listener.exitOperator_not(self)




    def operator_not(self):

        localctx = SecLangParser.Operator_notContext(self, self._ctx, self.state)
        self.enterRule(localctx, 62, self.RULE_operator_not)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 424
            self.match(SecLangParser.NOT)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class OperatorContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def QUOTE(self, i:int=None):
            if i is None:
                return self.getTokens(SecLangParser.QUOTE)
            else:
                return self.getToken(SecLangParser.QUOTE, i)

        def AT(self):
            return self.getToken(SecLangParser.AT, 0)

        def operator_name(self):
            return self.getTypedRuleContext(SecLangParser.Operator_nameContext,0)


        def operator_not(self):
            return self.getTypedRuleContext(SecLangParser.Operator_notContext,0)


        def operator_value(self):
            return self.getTypedRuleContext(SecLangParser.Operator_valueContext,0)


        def getRuleIndex(self):
            return SecLangParser.RULE_operator

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterOperator" ):
                listener.enterOperator(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitOperator" ):
                listener.exitOperator(self)




    def operator(self):

        localctx = SecLangParser.OperatorContext(self, self._ctx, self.state)
        self.enterRule(localctx, 64, self.RULE_operator)
        self._la = 0 # Token type
        try:
            self.state = 442
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,37,self._ctx)
            if la_ == 1:
                self.enterOuterAlt(localctx, 1)
                self.state = 426
                self.match(SecLangParser.QUOTE)
                self.state = 428
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==10:
                    self.state = 427
                    self.operator_not()


                self.state = 430
                self.match(SecLangParser.AT)
                self.state = 431
                self.operator_name()
                self.state = 433
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==86 or ((((_la - 233)) & ~0x3f) == 0 and ((1 << (_la - 233)) & 1352663041) != 0):
                    self.state = 432
                    self.operator_value()


                self.state = 435
                self.match(SecLangParser.QUOTE)
                pass

            elif la_ == 2:
                self.enterOuterAlt(localctx, 2)
                self.state = 437
                self.match(SecLangParser.QUOTE)
                self.state = 438
                self.operator_value()
                self.state = 439
                self.match(SecLangParser.QUOTE)
                pass

            elif la_ == 3:
                self.enterOuterAlt(localctx, 3)
                self.state = 441
                self.operator_value()
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Operator_nameContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def OPERATOR_UNCONDITIONAL_MATCH(self):
            return self.getToken(SecLangParser.OPERATOR_UNCONDITIONAL_MATCH, 0)

        def OPERATOR_DETECT_SQLI(self):
            return self.getToken(SecLangParser.OPERATOR_DETECT_SQLI, 0)

        def OPERATOR_DETECT_XSS(self):
            return self.getToken(SecLangParser.OPERATOR_DETECT_XSS, 0)

        def OPERATOR_VALIDATE_URL_ENCODING(self):
            return self.getToken(SecLangParser.OPERATOR_VALIDATE_URL_ENCODING, 0)

        def OPERATOR_VALIDATE_UTF8_ENCODING(self):
            return self.getToken(SecLangParser.OPERATOR_VALIDATE_UTF8_ENCODING, 0)

        def OPERATOR_INSPECT_FILE(self):
            return self.getToken(SecLangParser.OPERATOR_INSPECT_FILE, 0)

        def OPERATOR_FUZZY_HASH(self):
            return self.getToken(SecLangParser.OPERATOR_FUZZY_HASH, 0)

        def OPERATOR_VALIDATE_BYTE_RANGE(self):
            return self.getToken(SecLangParser.OPERATOR_VALIDATE_BYTE_RANGE, 0)

        def OPERATOR_VALIDATE_DTD(self):
            return self.getToken(SecLangParser.OPERATOR_VALIDATE_DTD, 0)

        def OPERATOR_VALIDATE_HASH(self):
            return self.getToken(SecLangParser.OPERATOR_VALIDATE_HASH, 0)

        def OPERATOR_VALIDATE_SCHEMA(self):
            return self.getToken(SecLangParser.OPERATOR_VALIDATE_SCHEMA, 0)

        def OPERATOR_VERIFY_CC(self):
            return self.getToken(SecLangParser.OPERATOR_VERIFY_CC, 0)

        def OPERATOR_VERIFY_CPF(self):
            return self.getToken(SecLangParser.OPERATOR_VERIFY_CPF, 0)

        def OPERATOR_VERIFY_SSN(self):
            return self.getToken(SecLangParser.OPERATOR_VERIFY_SSN, 0)

        def OPERATOR_VERIFY_SVNR(self):
            return self.getToken(SecLangParser.OPERATOR_VERIFY_SVNR, 0)

        def OPERATOR_GSB_LOOKUP(self):
            return self.getToken(SecLangParser.OPERATOR_GSB_LOOKUP, 0)

        def OPERATOR_RSUB(self):
            return self.getToken(SecLangParser.OPERATOR_RSUB, 0)

        def OPERATOR_WITHIN(self):
            return self.getToken(SecLangParser.OPERATOR_WITHIN, 0)

        def OPERATOR_CONTAINS_WORD(self):
            return self.getToken(SecLangParser.OPERATOR_CONTAINS_WORD, 0)

        def OPERATOR_CONTAINS(self):
            return self.getToken(SecLangParser.OPERATOR_CONTAINS, 0)

        def OPERATOR_ENDS_WITH(self):
            return self.getToken(SecLangParser.OPERATOR_ENDS_WITH, 0)

        def OPERATOR_EQ(self):
            return self.getToken(SecLangParser.OPERATOR_EQ, 0)

        def OPERATOR_GE(self):
            return self.getToken(SecLangParser.OPERATOR_GE, 0)

        def OPERATOR_GT(self):
            return self.getToken(SecLangParser.OPERATOR_GT, 0)

        def OPERATOR_IP_MATCH_FROM_FILE(self):
            return self.getToken(SecLangParser.OPERATOR_IP_MATCH_FROM_FILE, 0)

        def OPERATOR_IP_MATCH(self):
            return self.getToken(SecLangParser.OPERATOR_IP_MATCH, 0)

        def OPERATOR_LE(self):
            return self.getToken(SecLangParser.OPERATOR_LE, 0)

        def OPERATOR_LT(self):
            return self.getToken(SecLangParser.OPERATOR_LT, 0)

        def OPERATOR_PM_FROM_FILE(self):
            return self.getToken(SecLangParser.OPERATOR_PM_FROM_FILE, 0)

        def OPERATOR_PM(self):
            return self.getToken(SecLangParser.OPERATOR_PM, 0)

        def OPERATOR_RBL(self):
            return self.getToken(SecLangParser.OPERATOR_RBL, 0)

        def OPERATOR_RX(self):
            return self.getToken(SecLangParser.OPERATOR_RX, 0)

        def OPERATOR_RX_GLOBAL(self):
            return self.getToken(SecLangParser.OPERATOR_RX_GLOBAL, 0)

        def OPERATOR_STR_EQ(self):
            return self.getToken(SecLangParser.OPERATOR_STR_EQ, 0)

        def OPERATOR_STR_MATCH(self):
            return self.getToken(SecLangParser.OPERATOR_STR_MATCH, 0)

        def OPERATOR_BEGINS_WITH(self):
            return self.getToken(SecLangParser.OPERATOR_BEGINS_WITH, 0)

        def OPERATOR_GEOLOOKUP(self):
            return self.getToken(SecLangParser.OPERATOR_GEOLOOKUP, 0)

        def getRuleIndex(self):
            return SecLangParser.RULE_operator_name

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterOperator_name" ):
                listener.enterOperator_name(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitOperator_name" ):
                listener.exitOperator_name(self)




    def operator_name(self):

        localctx = SecLangParser.Operator_nameContext(self, self._ctx, self.state)
        self.enterRule(localctx, 66, self.RULE_operator_name)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 444
            _la = self._input.LA(1)
            if not(((((_la - 89)) & ~0x3f) == 0 and ((1 << (_la - 89)) & 137438953471) != 0)):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Operator_valueContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def variable_enum(self):
            return self.getTypedRuleContext(SecLangParser.Variable_enumContext,0)


        def STRING(self):
            return self.getToken(SecLangParser.STRING, 0)

        def INT_RANGE_VALUE(self, i:int=None):
            if i is None:
                return self.getTokens(SecLangParser.INT_RANGE_VALUE)
            else:
                return self.getToken(SecLangParser.INT_RANGE_VALUE, i)

        def operator_int_range(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(SecLangParser.Operator_int_rangeContext)
            else:
                return self.getTypedRuleContext(SecLangParser.Operator_int_rangeContext,i)


        def WS_INT_RANGE(self, i:int=None):
            if i is None:
                return self.getTokens(SecLangParser.WS_INT_RANGE)
            else:
                return self.getToken(SecLangParser.WS_INT_RANGE, i)

        def COMMA(self, i:int=None):
            if i is None:
                return self.getTokens(SecLangParser.COMMA)
            else:
                return self.getToken(SecLangParser.COMMA, i)

        def OPERATOR_UNQUOTED_STRING(self):
            return self.getToken(SecLangParser.OPERATOR_UNQUOTED_STRING, 0)

        def OPERATOR_QUOTED_STRING(self):
            return self.getToken(SecLangParser.OPERATOR_QUOTED_STRING, 0)

        def getRuleIndex(self):
            return SecLangParser.RULE_operator_value

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterOperator_value" ):
                listener.enterOperator_value(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitOperator_value" ):
                listener.exitOperator_value(self)




    def operator_value(self):

        localctx = SecLangParser.Operator_valueContext(self, self._ctx, self.state)
        self.enterRule(localctx, 68, self.RULE_operator_value)
        self._la = 0 # Token type
        try:
            self.state = 476
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [86]:
                self.enterOuterAlt(localctx, 1)
                self.state = 446
                self.variable_enum()
                pass
            elif token in [233]:
                self.enterOuterAlt(localctx, 2)
                self.state = 447
                self.match(SecLangParser.STRING)
                pass
            elif token in [261, 263]:
                self.enterOuterAlt(localctx, 3)
                self.state = 451
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                while _la==263:
                    self.state = 448
                    self.match(SecLangParser.WS_INT_RANGE)
                    self.state = 453
                    self._errHandler.sync(self)
                    _la = self._input.LA(1)

                self.state = 456
                self._errHandler.sync(self)
                la_ = self._interp.adaptivePredict(self._input,39,self._ctx)
                if la_ == 1:
                    self.state = 454
                    self.match(SecLangParser.INT_RANGE_VALUE)
                    pass

                elif la_ == 2:
                    self.state = 455
                    self.operator_int_range()
                    pass


                self.state = 471
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                while _la==7:
                    self.state = 458
                    self.match(SecLangParser.COMMA)
                    self.state = 462
                    self._errHandler.sync(self)
                    _la = self._input.LA(1)
                    while _la==263:
                        self.state = 459
                        self.match(SecLangParser.WS_INT_RANGE)
                        self.state = 464
                        self._errHandler.sync(self)
                        _la = self._input.LA(1)

                    self.state = 467
                    self._errHandler.sync(self)
                    la_ = self._interp.adaptivePredict(self._input,41,self._ctx)
                    if la_ == 1:
                        self.state = 465
                        self.match(SecLangParser.INT_RANGE_VALUE)
                        pass

                    elif la_ == 2:
                        self.state = 466
                        self.operator_int_range()
                        pass


                    self.state = 473
                    self._errHandler.sync(self)
                    _la = self._input.LA(1)

                pass
            elif token in [254]:
                self.enterOuterAlt(localctx, 4)
                self.state = 474
                self.match(SecLangParser.OPERATOR_UNQUOTED_STRING)
                pass
            elif token in [256]:
                self.enterOuterAlt(localctx, 5)
                self.state = 475
                self.match(SecLangParser.OPERATOR_QUOTED_STRING)
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Var_notContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def NOT(self):
            return self.getToken(SecLangParser.NOT, 0)

        def getRuleIndex(self):
            return SecLangParser.RULE_var_not

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterVar_not" ):
                listener.enterVar_not(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitVar_not" ):
                listener.exitVar_not(self)




    def var_not(self):

        localctx = SecLangParser.Var_notContext(self, self._ctx, self.state)
        self.enterRule(localctx, 70, self.RULE_var_not)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 478
            self.match(SecLangParser.NOT)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Var_countContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def VAR_COUNT(self):
            return self.getToken(SecLangParser.VAR_COUNT, 0)

        def getRuleIndex(self):
            return SecLangParser.RULE_var_count

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterVar_count" ):
                listener.enterVar_count(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitVar_count" ):
                listener.exitVar_count(self)




    def var_count(self):

        localctx = SecLangParser.Var_countContext(self, self._ctx, self.state)
        self.enterRule(localctx, 72, self.RULE_var_count)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 480
            self.match(SecLangParser.VAR_COUNT)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class VariablesContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def var_stmt(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(SecLangParser.Var_stmtContext)
            else:
                return self.getTypedRuleContext(SecLangParser.Var_stmtContext,i)


        def QUOTE(self, i:int=None):
            if i is None:
                return self.getTokens(SecLangParser.QUOTE)
            else:
                return self.getToken(SecLangParser.QUOTE, i)

        def var_not(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(SecLangParser.Var_notContext)
            else:
                return self.getTypedRuleContext(SecLangParser.Var_notContext,i)


        def var_count(self):
            return self.getTypedRuleContext(SecLangParser.Var_countContext,0)


        def PIPE(self, i:int=None):
            if i is None:
                return self.getTokens(SecLangParser.PIPE)
            else:
                return self.getToken(SecLangParser.PIPE, i)

        def getRuleIndex(self):
            return SecLangParser.RULE_variables

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterVariables" ):
                listener.enterVariables(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitVariables" ):
                listener.exitVariables(self)




    def variables(self):

        localctx = SecLangParser.VariablesContext(self, self._ctx, self.state)
        self.enterRule(localctx, 74, self.RULE_variables)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 483
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==1:
                self.state = 482
                self.match(SecLangParser.QUOTE)


            self.state = 486
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==10:
                self.state = 485
                self.var_not()


            self.state = 489
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==88:
                self.state = 488
                self.var_count()


            self.state = 491
            self.var_stmt()
            self.state = 493
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,47,self._ctx)
            if la_ == 1:
                self.state = 492
                self.match(SecLangParser.QUOTE)


            self.state = 508
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==8:
                self.state = 495
                self.match(SecLangParser.PIPE)
                self.state = 497
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==1:
                    self.state = 496
                    self.match(SecLangParser.QUOTE)


                self.state = 500
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==10:
                    self.state = 499
                    self.var_not()


                self.state = 502
                self.var_stmt()
                self.state = 504
                self._errHandler.sync(self)
                la_ = self._interp.adaptivePredict(self._input,50,self._ctx)
                if la_ == 1:
                    self.state = 503
                    self.match(SecLangParser.QUOTE)


                self.state = 510
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Update_variablesContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def var_stmt(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(SecLangParser.Var_stmtContext)
            else:
                return self.getTypedRuleContext(SecLangParser.Var_stmtContext,i)


        def QUOTE(self, i:int=None):
            if i is None:
                return self.getTokens(SecLangParser.QUOTE)
            else:
                return self.getToken(SecLangParser.QUOTE, i)

        def var_not(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(SecLangParser.Var_notContext)
            else:
                return self.getTypedRuleContext(SecLangParser.Var_notContext,i)


        def var_count(self):
            return self.getTypedRuleContext(SecLangParser.Var_countContext,0)


        def COMMA(self, i:int=None):
            if i is None:
                return self.getTokens(SecLangParser.COMMA)
            else:
                return self.getToken(SecLangParser.COMMA, i)

        def getRuleIndex(self):
            return SecLangParser.RULE_update_variables

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterUpdate_variables" ):
                listener.enterUpdate_variables(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitUpdate_variables" ):
                listener.exitUpdate_variables(self)




    def update_variables(self):

        localctx = SecLangParser.Update_variablesContext(self, self._ctx, self.state)
        self.enterRule(localctx, 76, self.RULE_update_variables)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 512
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==1:
                self.state = 511
                self.match(SecLangParser.QUOTE)


            self.state = 515
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==10:
                self.state = 514
                self.var_not()


            self.state = 518
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==88:
                self.state = 517
                self.var_count()


            self.state = 520
            self.var_stmt()
            self.state = 522
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,55,self._ctx)
            if la_ == 1:
                self.state = 521
                self.match(SecLangParser.QUOTE)


            self.state = 537
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==7:
                self.state = 524
                self.match(SecLangParser.COMMA)
                self.state = 526
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==1:
                    self.state = 525
                    self.match(SecLangParser.QUOTE)


                self.state = 529
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==10:
                    self.state = 528
                    self.var_not()


                self.state = 531
                self.var_stmt()
                self.state = 533
                self._errHandler.sync(self)
                la_ = self._interp.adaptivePredict(self._input,58,self._ctx)
                if la_ == 1:
                    self.state = 532
                    self.match(SecLangParser.QUOTE)


                self.state = 539
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class New_targetContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def var_stmt(self):
            return self.getTypedRuleContext(SecLangParser.Var_stmtContext,0)


        def getRuleIndex(self):
            return SecLangParser.RULE_new_target

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterNew_target" ):
                listener.enterNew_target(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitNew_target" ):
                listener.exitNew_target(self)




    def new_target(self):

        localctx = SecLangParser.New_targetContext(self, self._ctx, self.state)
        self.enterRule(localctx, 78, self.RULE_new_target)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 540
            self.var_stmt()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Var_stmtContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def variable_enum(self):
            return self.getTypedRuleContext(SecLangParser.Variable_enumContext,0)


        def collection_enum(self):
            return self.getTypedRuleContext(SecLangParser.Collection_enumContext,0)


        def COLON(self):
            return self.getToken(SecLangParser.COLON, 0)

        def collection_value(self):
            return self.getTypedRuleContext(SecLangParser.Collection_valueContext,0)


        def getRuleIndex(self):
            return SecLangParser.RULE_var_stmt

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterVar_stmt" ):
                listener.enterVar_stmt(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitVar_stmt" ):
                listener.exitVar_stmt(self)




    def var_stmt(self):

        localctx = SecLangParser.Var_stmtContext(self, self._ctx, self.state)
        self.enterRule(localctx, 80, self.RULE_var_stmt)
        self._la = 0 # Token type
        try:
            self.state = 548
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [86]:
                self.enterOuterAlt(localctx, 1)
                self.state = 542
                self.variable_enum()
                pass
            elif token in [85, 87]:
                self.enterOuterAlt(localctx, 2)
                self.state = 543
                self.collection_enum()
                self.state = 546
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==4:
                    self.state = 544
                    self.match(SecLangParser.COLON)
                    self.state = 545
                    self.collection_value()


                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Variable_enumContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def VARIABLE_NAME_ENUM(self):
            return self.getToken(SecLangParser.VARIABLE_NAME_ENUM, 0)

        def getRuleIndex(self):
            return SecLangParser.RULE_variable_enum

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterVariable_enum" ):
                listener.enterVariable_enum(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitVariable_enum" ):
                listener.exitVariable_enum(self)




    def variable_enum(self):

        localctx = SecLangParser.Variable_enumContext(self, self._ctx, self.state)
        self.enterRule(localctx, 82, self.RULE_variable_enum)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 550
            self.match(SecLangParser.VARIABLE_NAME_ENUM)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Ctl_variable_enumContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def VARIABLE_NAME_ENUM(self):
            return self.getToken(SecLangParser.VARIABLE_NAME_ENUM, 0)

        def getRuleIndex(self):
            return SecLangParser.RULE_ctl_variable_enum

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterCtl_variable_enum" ):
                listener.enterCtl_variable_enum(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitCtl_variable_enum" ):
                listener.exitCtl_variable_enum(self)




    def ctl_variable_enum(self):

        localctx = SecLangParser.Ctl_variable_enumContext(self, self._ctx, self.state)
        self.enterRule(localctx, 84, self.RULE_ctl_variable_enum)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 552
            self.match(SecLangParser.VARIABLE_NAME_ENUM)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Collection_enumContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def COLLECTION_NAME_ENUM(self):
            return self.getToken(SecLangParser.COLLECTION_NAME_ENUM, 0)

        def RUN_TIME_VAR_XML(self):
            return self.getToken(SecLangParser.RUN_TIME_VAR_XML, 0)

        def getRuleIndex(self):
            return SecLangParser.RULE_collection_enum

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterCollection_enum" ):
                listener.enterCollection_enum(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitCollection_enum" ):
                listener.exitCollection_enum(self)




    def collection_enum(self):

        localctx = SecLangParser.Collection_enumContext(self, self._ctx, self.state)
        self.enterRule(localctx, 86, self.RULE_collection_enum)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 554
            _la = self._input.LA(1)
            if not(_la==85 or _la==87):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Ctl_collection_enumContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def COLLECTION_NAME_ENUM(self):
            return self.getToken(SecLangParser.COLLECTION_NAME_ENUM, 0)

        def RUN_TIME_VAR_XML(self):
            return self.getToken(SecLangParser.RUN_TIME_VAR_XML, 0)

        def getRuleIndex(self):
            return SecLangParser.RULE_ctl_collection_enum

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterCtl_collection_enum" ):
                listener.enterCtl_collection_enum(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitCtl_collection_enum" ):
                listener.exitCtl_collection_enum(self)




    def ctl_collection_enum(self):

        localctx = SecLangParser.Ctl_collection_enumContext(self, self._ctx, self.state)
        self.enterRule(localctx, 88, self.RULE_ctl_collection_enum)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 556
            _la = self._input.LA(1)
            if not(_la==85 or _la==87):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ActionsContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def QUOTE(self, i:int=None):
            if i is None:
                return self.getTokens(SecLangParser.QUOTE)
            else:
                return self.getToken(SecLangParser.QUOTE, i)

        def action(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(SecLangParser.ActionContext)
            else:
                return self.getTypedRuleContext(SecLangParser.ActionContext,i)


        def COMMA(self, i:int=None):
            if i is None:
                return self.getTokens(SecLangParser.COMMA)
            else:
                return self.getToken(SecLangParser.COMMA, i)

        def getRuleIndex(self):
            return SecLangParser.RULE_actions

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterActions" ):
                listener.enterActions(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitActions" ):
                listener.exitActions(self)




    def actions(self):

        localctx = SecLangParser.ActionsContext(self, self._ctx, self.state)
        self.enterRule(localctx, 90, self.RULE_actions)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 558
            self.match(SecLangParser.QUOTE)
            self.state = 559
            self.action()
            self.state = 564
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==7:
                self.state = 560
                self.match(SecLangParser.COMMA)
                self.state = 561
                self.action()
                self.state = 566
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 567
            self.match(SecLangParser.QUOTE)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ActionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def action_with_params(self):
            return self.getTypedRuleContext(SecLangParser.Action_with_paramsContext,0)


        def COLON(self):
            return self.getToken(SecLangParser.COLON, 0)

        def action_value(self):
            return self.getTypedRuleContext(SecLangParser.Action_valueContext,0)


        def NOT(self):
            return self.getToken(SecLangParser.NOT, 0)

        def EQUAL(self):
            return self.getToken(SecLangParser.EQUAL, 0)

        def ACTION_TRANSFORMATION(self):
            return self.getToken(SecLangParser.ACTION_TRANSFORMATION, 0)

        def transformation_action_value(self):
            return self.getTypedRuleContext(SecLangParser.Transformation_action_valueContext,0)


        def action_only(self):
            return self.getTypedRuleContext(SecLangParser.Action_onlyContext,0)


        def getRuleIndex(self):
            return SecLangParser.RULE_action

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterAction" ):
                listener.enterAction(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitAction" ):
                listener.exitAction(self)




    def action(self):

        localctx = SecLangParser.ActionContext(self, self._ctx, self.state)
        self.enterRule(localctx, 92, self.RULE_action)
        self._la = 0 # Token type
        try:
            self.state = 587
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,65,self._ctx)
            if la_ == 1:
                self.enterOuterAlt(localctx, 1)
                self.state = 569
                self.action_with_params()
                self.state = 570
                self.match(SecLangParser.COLON)
                self.state = 572
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==10:
                    self.state = 571
                    self.match(SecLangParser.NOT)


                self.state = 575
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==3:
                    self.state = 574
                    self.match(SecLangParser.EQUAL)


                self.state = 577
                self.action_value()
                pass

            elif la_ == 2:
                self.enterOuterAlt(localctx, 2)
                self.state = 579
                self.action_with_params()
                self.state = 580
                self.match(SecLangParser.COLON)
                self.state = 581
                self.action_value()
                pass

            elif la_ == 3:
                self.enterOuterAlt(localctx, 3)
                self.state = 583
                self.match(SecLangParser.ACTION_TRANSFORMATION)
                self.state = 584
                self.match(SecLangParser.COLON)
                self.state = 585
                self.transformation_action_value()
                pass

            elif la_ == 4:
                self.enterOuterAlt(localctx, 4)
                self.state = 586
                self.action_only()
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Action_onlyContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def disruptive_action_only(self):
            return self.getTypedRuleContext(SecLangParser.Disruptive_action_onlyContext,0)


        def non_disruptive_action_only(self):
            return self.getTypedRuleContext(SecLangParser.Non_disruptive_action_onlyContext,0)


        def flow_action_only(self):
            return self.getTypedRuleContext(SecLangParser.Flow_action_onlyContext,0)


        def getRuleIndex(self):
            return SecLangParser.RULE_action_only

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterAction_only" ):
                listener.enterAction_only(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitAction_only" ):
                listener.exitAction_only(self)




    def action_only(self):

        localctx = SecLangParser.Action_onlyContext(self, self._ctx, self.state)
        self.enterRule(localctx, 94, self.RULE_action_only)
        try:
            self.state = 592
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [27, 30, 44, 46, 58, 59]:
                self.enterOuterAlt(localctx, 1)
                self.state = 589
                self.disruptive_action_only()
                pass
            elif token in [29, 31, 52, 55, 56, 57, 67]:
                self.enterOuterAlt(localctx, 2)
                self.state = 590
                self.non_disruptive_action_only()
                pass
            elif token in [32]:
                self.enterOuterAlt(localctx, 3)
                self.state = 591
                self.flow_action_only()
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Disruptive_action_onlyContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ACTION_ALLOW(self):
            return self.getToken(SecLangParser.ACTION_ALLOW, 0)

        def ACTION_BLOCK(self):
            return self.getToken(SecLangParser.ACTION_BLOCK, 0)

        def ACTION_DENY(self):
            return self.getToken(SecLangParser.ACTION_DENY, 0)

        def ACTION_DROP(self):
            return self.getToken(SecLangParser.ACTION_DROP, 0)

        def ACTION_PASS(self):
            return self.getToken(SecLangParser.ACTION_PASS, 0)

        def ACTION_PAUSE(self):
            return self.getToken(SecLangParser.ACTION_PAUSE, 0)

        def getRuleIndex(self):
            return SecLangParser.RULE_disruptive_action_only

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterDisruptive_action_only" ):
                listener.enterDisruptive_action_only(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitDisruptive_action_only" ):
                listener.exitDisruptive_action_only(self)




    def disruptive_action_only(self):

        localctx = SecLangParser.Disruptive_action_onlyContext(self, self._ctx, self.state)
        self.enterRule(localctx, 96, self.RULE_disruptive_action_only)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 594
            _la = self._input.LA(1)
            if not((((_la) & ~0x3f) == 0 and ((1 << _la) & 864779090593316864) != 0)):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Non_disruptive_action_onlyContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ACTION_AUDIT_LOG(self):
            return self.getToken(SecLangParser.ACTION_AUDIT_LOG, 0)

        def ACTION_CAPTURE(self):
            return self.getToken(SecLangParser.ACTION_CAPTURE, 0)

        def ACTION_SANITISE_MATCHED(self):
            return self.getToken(SecLangParser.ACTION_SANITISE_MATCHED, 0)

        def ACTION_LOG(self):
            return self.getToken(SecLangParser.ACTION_LOG, 0)

        def ACTION_MULTI_MATCH(self):
            return self.getToken(SecLangParser.ACTION_MULTI_MATCH, 0)

        def ACTION_NO_AUDIT_LOG(self):
            return self.getToken(SecLangParser.ACTION_NO_AUDIT_LOG, 0)

        def ACTION_NO_LOG(self):
            return self.getToken(SecLangParser.ACTION_NO_LOG, 0)

        def getRuleIndex(self):
            return SecLangParser.RULE_non_disruptive_action_only

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterNon_disruptive_action_only" ):
                listener.enterNon_disruptive_action_only(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitNon_disruptive_action_only" ):
                listener.exitNon_disruptive_action_only(self)




    def non_disruptive_action_only(self):

        localctx = SecLangParser.Non_disruptive_action_onlyContext(self, self._ctx, self.state)
        self.enterRule(localctx, 98, self.RULE_non_disruptive_action_only)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 596
            _la = self._input.LA(1)
            if not(((((_la - 29)) & ~0x3f) == 0 and ((1 << (_la - 29)) & 275356057605) != 0)):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Flow_action_onlyContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ACTION_CHAIN(self):
            return self.getToken(SecLangParser.ACTION_CHAIN, 0)

        def getRuleIndex(self):
            return SecLangParser.RULE_flow_action_only

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterFlow_action_only" ):
                listener.enterFlow_action_only(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitFlow_action_only" ):
                listener.exitFlow_action_only(self)




    def flow_action_only(self):

        localctx = SecLangParser.Flow_action_onlyContext(self, self._ctx, self.state)
        self.enterRule(localctx, 100, self.RULE_flow_action_only)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 598
            self.match(SecLangParser.ACTION_CHAIN)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Action_with_paramsContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def metadata_action_with_params(self):
            return self.getTypedRuleContext(SecLangParser.Metadata_action_with_paramsContext,0)


        def disruptive_action_with_params(self):
            return self.getTypedRuleContext(SecLangParser.Disruptive_action_with_paramsContext,0)


        def non_disruptive_action_with_params(self):
            return self.getTypedRuleContext(SecLangParser.Non_disruptive_action_with_paramsContext,0)


        def flow_action_with_params(self):
            return self.getTypedRuleContext(SecLangParser.Flow_action_with_paramsContext,0)


        def data_action_with_params(self):
            return self.getTypedRuleContext(SecLangParser.Data_action_with_paramsContext,0)


        def getRuleIndex(self):
            return SecLangParser.RULE_action_with_params

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterAction_with_params" ):
                listener.enterAction_with_params(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitAction_with_params" ):
                listener.exitAction_with_params(self)




    def action_with_params(self):

        localctx = SecLangParser.Action_with_paramsContext(self, self._ctx, self.state)
        self.enterRule(localctx, 102, self.RULE_action_with_params)
        try:
            self.state = 605
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [49, 53, 54, 60, 64, 75, 80, 81]:
                self.enterOuterAlt(localctx, 1)
                self.state = 600
                self.metadata_action_with_params()
                pass
            elif token in [62, 63]:
                self.enterOuterAlt(localctx, 2)
                self.state = 601
                self.disruptive_action_with_params()
                pass
            elif token in [28, 33, 45, 47, 48, 50, 51, 61, 65, 66, 68, 69, 70, 71, 72, 73, 74]:
                self.enterOuterAlt(localctx, 3)
                self.state = 602
                self.non_disruptive_action_with_params()
                pass
            elif token in [77, 78]:
                self.enterOuterAlt(localctx, 4)
                self.state = 603
                self.flow_action_with_params()
                pass
            elif token in [79, 82]:
                self.enterOuterAlt(localctx, 5)
                self.state = 604
                self.data_action_with_params()
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Metadata_action_with_paramsContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return SecLangParser.RULE_metadata_action_with_params

     
        def copyFrom(self, ctx:ParserRuleContext):
            super().copyFrom(ctx)



    class ACTION_MATURITYContext(Metadata_action_with_paramsContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a SecLangParser.Metadata_action_with_paramsContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def ACTION_MATURITY(self):
            return self.getToken(SecLangParser.ACTION_MATURITY, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterACTION_MATURITY" ):
                listener.enterACTION_MATURITY(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitACTION_MATURITY" ):
                listener.exitACTION_MATURITY(self)


    class ACTION_REVContext(Metadata_action_with_paramsContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a SecLangParser.Metadata_action_with_paramsContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def ACTION_REV(self):
            return self.getToken(SecLangParser.ACTION_REV, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterACTION_REV" ):
                listener.enterACTION_REV(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitACTION_REV" ):
                listener.exitACTION_REV(self)


    class ACTION_VERContext(Metadata_action_with_paramsContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a SecLangParser.Metadata_action_with_paramsContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def ACTION_VER(self):
            return self.getToken(SecLangParser.ACTION_VER, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterACTION_VER" ):
                listener.enterACTION_VER(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitACTION_VER" ):
                listener.exitACTION_VER(self)


    class ACTION_SEVERITYContext(Metadata_action_with_paramsContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a SecLangParser.Metadata_action_with_paramsContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def ACTION_SEVERITY(self):
            return self.getToken(SecLangParser.ACTION_SEVERITY, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterACTION_SEVERITY" ):
                listener.enterACTION_SEVERITY(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitACTION_SEVERITY" ):
                listener.exitACTION_SEVERITY(self)


    class ACTION_MSGContext(Metadata_action_with_paramsContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a SecLangParser.Metadata_action_with_paramsContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def ACTION_MSG(self):
            return self.getToken(SecLangParser.ACTION_MSG, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterACTION_MSG" ):
                listener.enterACTION_MSG(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitACTION_MSG" ):
                listener.exitACTION_MSG(self)


    class ACTION_PHASEContext(Metadata_action_with_paramsContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a SecLangParser.Metadata_action_with_paramsContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def ACTION_PHASE(self):
            return self.getToken(SecLangParser.ACTION_PHASE, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterACTION_PHASE" ):
                listener.enterACTION_PHASE(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitACTION_PHASE" ):
                listener.exitACTION_PHASE(self)


    class ACTION_IDContext(Metadata_action_with_paramsContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a SecLangParser.Metadata_action_with_paramsContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def ACTION_ID(self):
            return self.getToken(SecLangParser.ACTION_ID, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterACTION_ID" ):
                listener.enterACTION_ID(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitACTION_ID" ):
                listener.exitACTION_ID(self)


    class ACTION_TAGContext(Metadata_action_with_paramsContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a SecLangParser.Metadata_action_with_paramsContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def ACTION_TAG(self):
            return self.getToken(SecLangParser.ACTION_TAG, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterACTION_TAG" ):
                listener.enterACTION_TAG(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitACTION_TAG" ):
                listener.exitACTION_TAG(self)



    def metadata_action_with_params(self):

        localctx = SecLangParser.Metadata_action_with_paramsContext(self, self._ctx, self.state)
        self.enterRule(localctx, 104, self.RULE_metadata_action_with_params)
        try:
            self.state = 615
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [60]:
                localctx = SecLangParser.ACTION_PHASEContext(self, localctx)
                self.enterOuterAlt(localctx, 1)
                self.state = 607
                self.match(SecLangParser.ACTION_PHASE)
                pass
            elif token in [49]:
                localctx = SecLangParser.ACTION_IDContext(self, localctx)
                self.enterOuterAlt(localctx, 2)
                self.state = 608
                self.match(SecLangParser.ACTION_ID)
                pass
            elif token in [53]:
                localctx = SecLangParser.ACTION_MATURITYContext(self, localctx)
                self.enterOuterAlt(localctx, 3)
                self.state = 609
                self.match(SecLangParser.ACTION_MATURITY)
                pass
            elif token in [54]:
                localctx = SecLangParser.ACTION_MSGContext(self, localctx)
                self.enterOuterAlt(localctx, 4)
                self.state = 610
                self.match(SecLangParser.ACTION_MSG)
                pass
            elif token in [64]:
                localctx = SecLangParser.ACTION_REVContext(self, localctx)
                self.enterOuterAlt(localctx, 5)
                self.state = 611
                self.match(SecLangParser.ACTION_REV)
                pass
            elif token in [75]:
                localctx = SecLangParser.ACTION_SEVERITYContext(self, localctx)
                self.enterOuterAlt(localctx, 6)
                self.state = 612
                self.match(SecLangParser.ACTION_SEVERITY)
                pass
            elif token in [80]:
                localctx = SecLangParser.ACTION_TAGContext(self, localctx)
                self.enterOuterAlt(localctx, 7)
                self.state = 613
                self.match(SecLangParser.ACTION_TAG)
                pass
            elif token in [81]:
                localctx = SecLangParser.ACTION_VERContext(self, localctx)
                self.enterOuterAlt(localctx, 8)
                self.state = 614
                self.match(SecLangParser.ACTION_VER)
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Disruptive_action_with_paramsContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ACTION_PROXY(self):
            return self.getToken(SecLangParser.ACTION_PROXY, 0)

        def ACTION_REDIRECT(self):
            return self.getToken(SecLangParser.ACTION_REDIRECT, 0)

        def getRuleIndex(self):
            return SecLangParser.RULE_disruptive_action_with_params

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterDisruptive_action_with_params" ):
                listener.enterDisruptive_action_with_params(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitDisruptive_action_with_params" ):
                listener.exitDisruptive_action_with_params(self)




    def disruptive_action_with_params(self):

        localctx = SecLangParser.Disruptive_action_with_paramsContext(self, self._ctx, self.state)
        self.enterRule(localctx, 106, self.RULE_disruptive_action_with_params)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 617
            _la = self._input.LA(1)
            if not(_la==62 or _la==63):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Non_disruptive_action_with_paramsContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ACTION_APPEND(self):
            return self.getToken(SecLangParser.ACTION_APPEND, 0)

        def ACTION_CTL(self):
            return self.getToken(SecLangParser.ACTION_CTL, 0)

        def ACTION_EXEC(self):
            return self.getToken(SecLangParser.ACTION_EXEC, 0)

        def ACTION_EXPIRE_VAR(self):
            return self.getToken(SecLangParser.ACTION_EXPIRE_VAR, 0)

        def ACTION_DEPRECATE_VAR(self):
            return self.getToken(SecLangParser.ACTION_DEPRECATE_VAR, 0)

        def ACTION_INITCOL(self):
            return self.getToken(SecLangParser.ACTION_INITCOL, 0)

        def ACTION_LOG_DATA(self):
            return self.getToken(SecLangParser.ACTION_LOG_DATA, 0)

        def ACTION_PREPEND(self):
            return self.getToken(SecLangParser.ACTION_PREPEND, 0)

        def ACTION_SANITISE_ARG(self):
            return self.getToken(SecLangParser.ACTION_SANITISE_ARG, 0)

        def ACTION_SANITISE_MATCHED_BYTES(self):
            return self.getToken(SecLangParser.ACTION_SANITISE_MATCHED_BYTES, 0)

        def ACTION_SANITISE_REQUEST_HEADER(self):
            return self.getToken(SecLangParser.ACTION_SANITISE_REQUEST_HEADER, 0)

        def ACTION_SANITISE_RESPONSE_HEADER(self):
            return self.getToken(SecLangParser.ACTION_SANITISE_RESPONSE_HEADER, 0)

        def ACTION_SETUID(self):
            return self.getToken(SecLangParser.ACTION_SETUID, 0)

        def ACTION_SETRSC(self):
            return self.getToken(SecLangParser.ACTION_SETRSC, 0)

        def ACTION_SETSID(self):
            return self.getToken(SecLangParser.ACTION_SETSID, 0)

        def ACTION_SETENV(self):
            return self.getToken(SecLangParser.ACTION_SETENV, 0)

        def ACTION_SETVAR(self):
            return self.getToken(SecLangParser.ACTION_SETVAR, 0)

        def getRuleIndex(self):
            return SecLangParser.RULE_non_disruptive_action_with_params

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterNon_disruptive_action_with_params" ):
                listener.enterNon_disruptive_action_with_params(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitNon_disruptive_action_with_params" ):
                listener.exitNon_disruptive_action_with_params(self)




    def non_disruptive_action_with_params(self):

        localctx = SecLangParser.Non_disruptive_action_with_paramsContext(self, self._ctx, self.state)
        self.enterRule(localctx, 108, self.RULE_non_disruptive_action_with_params)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 619
            _la = self._input.LA(1)
            if not(((((_la - 28)) & ~0x3f) == 0 and ((1 << (_la - 28)) & 140058897809441) != 0)):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Data_action_with_paramsContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ACTION_XMLNS(self):
            return self.getToken(SecLangParser.ACTION_XMLNS, 0)

        def ACTION_STATUS(self):
            return self.getToken(SecLangParser.ACTION_STATUS, 0)

        def getRuleIndex(self):
            return SecLangParser.RULE_data_action_with_params

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterData_action_with_params" ):
                listener.enterData_action_with_params(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitData_action_with_params" ):
                listener.exitData_action_with_params(self)




    def data_action_with_params(self):

        localctx = SecLangParser.Data_action_with_paramsContext(self, self._ctx, self.state)
        self.enterRule(localctx, 110, self.RULE_data_action_with_params)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 621
            _la = self._input.LA(1)
            if not(_la==79 or _la==82):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Flow_action_with_paramsContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ACTION_SKIP(self):
            return self.getToken(SecLangParser.ACTION_SKIP, 0)

        def ACTION_SKIP_AFTER(self):
            return self.getToken(SecLangParser.ACTION_SKIP_AFTER, 0)

        def getRuleIndex(self):
            return SecLangParser.RULE_flow_action_with_params

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterFlow_action_with_params" ):
                listener.enterFlow_action_with_params(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitFlow_action_with_params" ):
                listener.exitFlow_action_with_params(self)




    def flow_action_with_params(self):

        localctx = SecLangParser.Flow_action_with_paramsContext(self, self._ctx, self.state)
        self.enterRule(localctx, 112, self.RULE_flow_action_with_params)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 623
            _la = self._input.LA(1)
            if not(_la==77 or _la==78):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Action_valueContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def action_value_types(self):
            return self.getTypedRuleContext(SecLangParser.Action_value_typesContext,0)


        def SINGLE_QUOTE(self, i:int=None):
            if i is None:
                return self.getTokens(SecLangParser.SINGLE_QUOTE)
            else:
                return self.getToken(SecLangParser.SINGLE_QUOTE, i)

        def string_literal(self):
            return self.getTypedRuleContext(SecLangParser.String_literalContext,0)


        def getRuleIndex(self):
            return SecLangParser.RULE_action_value

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterAction_value" ):
                listener.enterAction_value(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitAction_value" ):
                listener.exitAction_value(self)




    def action_value(self):

        localctx = SecLangParser.Action_valueContext(self, self._ctx, self.state)
        self.enterRule(localctx, 114, self.RULE_action_value)
        try:
            self.state = 634
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,69,self._ctx)
            if la_ == 1:
                self.enterOuterAlt(localctx, 1)
                self.state = 625
                self.action_value_types()
                pass

            elif la_ == 2:
                self.enterOuterAlt(localctx, 2)
                self.state = 626
                self.match(SecLangParser.SINGLE_QUOTE)
                self.state = 627
                self.action_value_types()
                self.state = 628
                self.match(SecLangParser.SINGLE_QUOTE)
                pass

            elif la_ == 3:
                self.enterOuterAlt(localctx, 3)
                self.state = 630
                self.match(SecLangParser.SINGLE_QUOTE)
                self.state = 631
                self.string_literal()
                self.state = 632
                self.match(SecLangParser.SINGLE_QUOTE)
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Action_value_typesContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def INT(self):
            return self.getToken(SecLangParser.INT, 0)

        def collection_value(self):
            return self.getTypedRuleContext(SecLangParser.Collection_valueContext,0)


        def setvar_action(self):
            return self.getTypedRuleContext(SecLangParser.Setvar_actionContext,0)


        def ctl_action(self):
            return self.getTypedRuleContext(SecLangParser.Ctl_actionContext,0)


        def assignment(self):
            return self.getTypedRuleContext(SecLangParser.AssignmentContext,0)


        def values(self):
            return self.getTypedRuleContext(SecLangParser.ValuesContext,0)


        def VARIABLE_NAME(self):
            return self.getToken(SecLangParser.VARIABLE_NAME, 0)

        def ACTION_SEVERITY_VALUE(self):
            return self.getToken(SecLangParser.ACTION_SEVERITY_VALUE, 0)

        def FREE_TEXT_QUOTE_MACRO_EXPANSION(self):
            return self.getToken(SecLangParser.FREE_TEXT_QUOTE_MACRO_EXPANSION, 0)

        def COMMA_SEPARATED_STRING(self):
            return self.getToken(SecLangParser.COMMA_SEPARATED_STRING, 0)

        def getRuleIndex(self):
            return SecLangParser.RULE_action_value_types

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterAction_value_types" ):
                listener.enterAction_value_types(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitAction_value_types" ):
                listener.exitAction_value_types(self)




    def action_value_types(self):

        localctx = SecLangParser.Action_value_typesContext(self, self._ctx, self.state)
        self.enterRule(localctx, 116, self.RULE_action_value_types)
        try:
            self.state = 647
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [227]:
                self.enterOuterAlt(localctx, 1)
                self.state = 636
                self.match(SecLangParser.INT)
                pass
            elif token in [1, 2, 7, 243, 250]:
                self.enterOuterAlt(localctx, 2)
                self.state = 637
                self.collection_value()
                pass
            elif token in [235]:
                self.enterOuterAlt(localctx, 3)
                self.state = 638
                self.setvar_action()
                pass
            elif token in [34, 35, 36, 37, 38, 39, 40, 41, 42, 43]:
                self.enterOuterAlt(localctx, 4)
                self.state = 639
                self.ctl_action()
                self.state = 640
                self.assignment()
                self.state = 641
                self.values()
                pass
            elif token in [225]:
                self.enterOuterAlt(localctx, 5)
                self.state = 643
                self.match(SecLangParser.VARIABLE_NAME)
                pass
            elif token in [76]:
                self.enterOuterAlt(localctx, 6)
                self.state = 644
                self.match(SecLangParser.ACTION_SEVERITY_VALUE)
                pass
            elif token in [231]:
                self.enterOuterAlt(localctx, 7)
                self.state = 645
                self.match(SecLangParser.FREE_TEXT_QUOTE_MACRO_EXPANSION)
                pass
            elif token in [241]:
                self.enterOuterAlt(localctx, 8)
                self.state = 646
                self.match(SecLangParser.COMMA_SEPARATED_STRING)
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class String_literalContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def STRING_LITERAL(self):
            return self.getToken(SecLangParser.STRING_LITERAL, 0)

        def getRuleIndex(self):
            return SecLangParser.RULE_string_literal

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterString_literal" ):
                listener.enterString_literal(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitString_literal" ):
                listener.exitString_literal(self)




    def string_literal(self):

        localctx = SecLangParser.String_literalContext(self, self._ctx, self.state)
        self.enterRule(localctx, 118, self.RULE_string_literal)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 649
            self.match(SecLangParser.STRING_LITERAL)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Ctl_actionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ACTION_CTL_FORCE_REQ_BODY_VAR(self):
            return self.getToken(SecLangParser.ACTION_CTL_FORCE_REQ_BODY_VAR, 0)

        def ACTION_CTL_REQUEST_BODY_ACCESS(self):
            return self.getToken(SecLangParser.ACTION_CTL_REQUEST_BODY_ACCESS, 0)

        def ACTION_CTL_RULE_ENGINE(self):
            return self.getToken(SecLangParser.ACTION_CTL_RULE_ENGINE, 0)

        def ACTION_CTL_RULE_REMOVE_BY_ID(self):
            return self.getToken(SecLangParser.ACTION_CTL_RULE_REMOVE_BY_ID, 0)

        def ACTION_CTL_RULE_REMOVE_BY_TAG(self):
            return self.getToken(SecLangParser.ACTION_CTL_RULE_REMOVE_BY_TAG, 0)

        def ACTION_CTL_RULE_REMOVE_TARGET_BY_ID(self):
            return self.getToken(SecLangParser.ACTION_CTL_RULE_REMOVE_TARGET_BY_ID, 0)

        def ACTION_CTL_RULE_REMOVE_TARGET_BY_TAG(self):
            return self.getToken(SecLangParser.ACTION_CTL_RULE_REMOVE_TARGET_BY_TAG, 0)

        def ACTION_CTL_AUDIT_ENGINE(self):
            return self.getToken(SecLangParser.ACTION_CTL_AUDIT_ENGINE, 0)

        def ACTION_CTL_AUDIT_LOG_PARTS(self):
            return self.getToken(SecLangParser.ACTION_CTL_AUDIT_LOG_PARTS, 0)

        def ACTION_CTL_REQUEST_BODY_PROCESSOR(self):
            return self.getToken(SecLangParser.ACTION_CTL_REQUEST_BODY_PROCESSOR, 0)

        def getRuleIndex(self):
            return SecLangParser.RULE_ctl_action

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterCtl_action" ):
                listener.enterCtl_action(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitCtl_action" ):
                listener.exitCtl_action(self)




    def ctl_action(self):

        localctx = SecLangParser.Ctl_actionContext(self, self._ctx, self.state)
        self.enterRule(localctx, 120, self.RULE_ctl_action)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 651
            _la = self._input.LA(1)
            if not((((_la) & ~0x3f) == 0 and ((1 << _la) & 17575006175232) != 0)):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Transformation_action_valueContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def TRANSFORMATION_VALUE(self):
            return self.getToken(SecLangParser.TRANSFORMATION_VALUE, 0)

        def getRuleIndex(self):
            return SecLangParser.RULE_transformation_action_value

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterTransformation_action_value" ):
                listener.enterTransformation_action_value(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitTransformation_action_value" ):
                listener.exitTransformation_action_value(self)




    def transformation_action_value(self):

        localctx = SecLangParser.Transformation_action_valueContext(self, self._ctx, self.state)
        self.enterRule(localctx, 122, self.RULE_transformation_action_value)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 653
            self.match(SecLangParser.TRANSFORMATION_VALUE)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Collection_valueContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def XPATH_EXPRESSION(self):
            return self.getToken(SecLangParser.XPATH_EXPRESSION, 0)

        def COLLECTION_ELEMENT_VALUE(self):
            return self.getToken(SecLangParser.COLLECTION_ELEMENT_VALUE, 0)

        def getRuleIndex(self):
            return SecLangParser.RULE_collection_value

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterCollection_value" ):
                listener.enterCollection_value(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitCollection_value" ):
                listener.exitCollection_value(self)




    def collection_value(self):

        localctx = SecLangParser.Collection_valueContext(self, self._ctx, self.state)
        self.enterRule(localctx, 124, self.RULE_collection_value)
        try:
            self.state = 658
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [-1, 1, 2, 7, 8, 12, 86, 127, 128, 129, 130, 131, 132, 133, 134, 135, 136, 137, 138, 139, 140, 141, 142, 143, 144, 145, 146, 147, 148, 149, 150, 151, 152, 153, 154, 155, 156, 157, 158, 159, 160, 161, 162, 163, 164, 165, 166, 167, 169, 170, 171, 172, 173, 174, 175, 176, 177, 178, 179, 180, 182, 183, 185, 186, 187, 188, 189, 190, 191, 192, 193, 194, 195, 196, 197, 209, 210, 211, 212, 213, 214, 215, 216, 217, 218, 227, 233, 254, 256, 261, 263]:
                self.enterOuterAlt(localctx, 1)

                pass
            elif token in [243]:
                self.enterOuterAlt(localctx, 2)
                self.state = 656
                self.match(SecLangParser.XPATH_EXPRESSION)
                pass
            elif token in [250]:
                self.enterOuterAlt(localctx, 3)
                self.state = 657
                self.match(SecLangParser.COLLECTION_ELEMENT_VALUE)
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Ctl_collection_valueContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def XPATH_EXPRESSION(self):
            return self.getToken(SecLangParser.XPATH_EXPRESSION, 0)

        def COLLECTION_ELEMENT_VALUE(self):
            return self.getToken(SecLangParser.COLLECTION_ELEMENT_VALUE, 0)

        def getRuleIndex(self):
            return SecLangParser.RULE_ctl_collection_value

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterCtl_collection_value" ):
                listener.enterCtl_collection_value(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitCtl_collection_value" ):
                listener.exitCtl_collection_value(self)




    def ctl_collection_value(self):

        localctx = SecLangParser.Ctl_collection_valueContext(self, self._ctx, self.state)
        self.enterRule(localctx, 126, self.RULE_ctl_collection_value)
        try:
            self.state = 663
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [-1, 1, 2, 7, 12, 127, 128, 129, 130, 131, 132, 133, 134, 135, 136, 137, 138, 139, 140, 141, 142, 143, 144, 145, 146, 147, 148, 149, 150, 151, 152, 153, 154, 155, 156, 157, 158, 159, 160, 161, 162, 163, 164, 165, 166, 167, 169, 170, 171, 172, 173, 174, 175, 176, 177, 178, 179, 180, 182, 183, 185, 186, 187, 188, 189, 190, 191, 192, 193, 194, 195, 196, 197, 209, 210, 211, 212, 213, 214, 215, 216, 217, 218, 227]:
                self.enterOuterAlt(localctx, 1)

                pass
            elif token in [243]:
                self.enterOuterAlt(localctx, 2)
                self.state = 661
                self.match(SecLangParser.XPATH_EXPRESSION)
                pass
            elif token in [250]:
                self.enterOuterAlt(localctx, 3)
                self.state = 662
                self.match(SecLangParser.COLLECTION_ELEMENT_VALUE)
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Setvar_actionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def col_name(self):
            return self.getTypedRuleContext(SecLangParser.Col_nameContext,0)


        def DOT(self):
            return self.getToken(SecLangParser.DOT, 0)

        def setvar_stmt(self):
            return self.getTypedRuleContext(SecLangParser.Setvar_stmtContext,0)


        def assignment(self):
            return self.getTypedRuleContext(SecLangParser.AssignmentContext,0)


        def var_assignment(self):
            return self.getTypedRuleContext(SecLangParser.Var_assignmentContext,0)


        def getRuleIndex(self):
            return SecLangParser.RULE_setvar_action

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterSetvar_action" ):
                listener.enterSetvar_action(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitSetvar_action" ):
                listener.exitSetvar_action(self)




    def setvar_action(self):

        localctx = SecLangParser.Setvar_actionContext(self, self._ctx, self.state)
        self.enterRule(localctx, 128, self.RULE_setvar_action)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 665
            self.col_name()
            self.state = 666
            self.match(SecLangParser.DOT)
            self.state = 667
            self.setvar_stmt()
            self.state = 668
            self.assignment()
            self.state = 669
            self.var_assignment()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Col_nameContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def COLLECTION_NAME_SETVAR(self):
            return self.getToken(SecLangParser.COLLECTION_NAME_SETVAR, 0)

        def getRuleIndex(self):
            return SecLangParser.RULE_col_name

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterCol_name" ):
                listener.enterCol_name(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitCol_name" ):
                listener.exitCol_name(self)




    def col_name(self):

        localctx = SecLangParser.Col_nameContext(self, self._ctx, self.state)
        self.enterRule(localctx, 130, self.RULE_col_name)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 671
            self.match(SecLangParser.COLLECTION_NAME_SETVAR)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Setvar_stmtContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def COLLECTION_ELEMENT(self, i:int=None):
            if i is None:
                return self.getTokens(SecLangParser.COLLECTION_ELEMENT)
            else:
                return self.getToken(SecLangParser.COLLECTION_ELEMENT, i)

        def COLLECTION_WITH_MACRO(self, i:int=None):
            if i is None:
                return self.getTokens(SecLangParser.COLLECTION_WITH_MACRO)
            else:
                return self.getToken(SecLangParser.COLLECTION_WITH_MACRO, i)

        def MACRO_EXPANSION(self, i:int=None):
            if i is None:
                return self.getTokens(SecLangParser.MACRO_EXPANSION)
            else:
                return self.getToken(SecLangParser.MACRO_EXPANSION, i)

        def getRuleIndex(self):
            return SecLangParser.RULE_setvar_stmt

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterSetvar_stmt" ):
                listener.enterSetvar_stmt(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitSetvar_stmt" ):
                listener.exitSetvar_stmt(self)




    def setvar_stmt(self):

        localctx = SecLangParser.Setvar_stmtContext(self, self._ctx, self.state)
        self.enterRule(localctx, 132, self.RULE_setvar_stmt)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 676 
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while True:
                self.state = 676
                self._errHandler.sync(self)
                token = self._input.LA(1)
                if token in [237]:
                    self.state = 673
                    self.match(SecLangParser.COLLECTION_ELEMENT)
                    pass
                elif token in [238]:
                    self.state = 674
                    self.match(SecLangParser.COLLECTION_WITH_MACRO)
                    self.state = 675
                    self.match(SecLangParser.MACRO_EXPANSION)
                    pass
                else:
                    raise NoViableAltException(self)

                self.state = 678 
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if not (_la==237 or _la==238):
                    break

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class AssignmentContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def EQUAL(self):
            return self.getToken(SecLangParser.EQUAL, 0)

        def EQUALS_PLUS(self):
            return self.getToken(SecLangParser.EQUALS_PLUS, 0)

        def EQUALS_MINUS(self):
            return self.getToken(SecLangParser.EQUALS_MINUS, 0)

        def getRuleIndex(self):
            return SecLangParser.RULE_assignment

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterAssignment" ):
                listener.enterAssignment(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitAssignment" ):
                listener.exitAssignment(self)




    def assignment(self):

        localctx = SecLangParser.AssignmentContext(self, self._ctx, self.state)
        self.enterRule(localctx, 134, self.RULE_assignment)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 680
            _la = self._input.LA(1)
            if not((((_la) & ~0x3f) == 0 and ((1 << _la) & 104) != 0)):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Var_assignmentContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def VAR_ASSIGNMENT(self):
            return self.getToken(SecLangParser.VAR_ASSIGNMENT, 0)

        def getRuleIndex(self):
            return SecLangParser.RULE_var_assignment

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterVar_assignment" ):
                listener.enterVar_assignment(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitVar_assignment" ):
                listener.exitVar_assignment(self)




    def var_assignment(self):

        localctx = SecLangParser.Var_assignmentContext(self, self._ctx, self.state)
        self.enterRule(localctx, 136, self.RULE_var_assignment)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 682
            self.match(SecLangParser.VAR_ASSIGNMENT)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Ctl_idContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def INT(self):
            return self.getToken(SecLangParser.INT, 0)

        def IDENT(self):
            return self.getToken(SecLangParser.IDENT, 0)

        def getRuleIndex(self):
            return SecLangParser.RULE_ctl_id

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterCtl_id" ):
                listener.enterCtl_id(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitCtl_id" ):
                listener.exitCtl_id(self)




    def ctl_id(self):

        localctx = SecLangParser.Ctl_idContext(self, self._ctx, self.state)
        self.enterRule(localctx, 138, self.RULE_ctl_id)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 684
            _la = self._input.LA(1)
            if not(_la==226 or _la==227):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx





