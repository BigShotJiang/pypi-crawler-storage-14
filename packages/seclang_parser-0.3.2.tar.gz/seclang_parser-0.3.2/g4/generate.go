// Copyright 2023 Felipe Zipitria
// SPDX-License-Identifier: Apache-2.0

package g4

//go:generate ../generate.sh
