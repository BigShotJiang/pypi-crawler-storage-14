"""
CLI entry point for the LangQuality toolkit.
"""

from .cli import main

if __name__ == "__main__":
    main()
