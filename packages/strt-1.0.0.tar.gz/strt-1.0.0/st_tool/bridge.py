import json
import os
import subprocess
import sys
import time
import threading

try:
    import socketio
except ImportError:
    print("Error: 'python-socketio[client]' library not found.")
    print("Please run 'st install pack' to install it.")
    sys.exit(1)

class LocalListener:
    def __init__(self):
        self.config_dir = os.path.join(os.path.expanduser('~'), '.st_tool')
        self.config_path = os.path.join(self.config_dir, 'config.json')
        # self.st_script_path = os.path.join(self.script_dir, 'st.py') # No longer needed
        self.config = {}
        self.sio = socketio.Client(reconnection_attempts=5, reconnection_delay=5)
        self.setup_events()

    def load_config(self):
        """Loads the configuration from config.json."""
        try:
            with open(self.config_path, 'r', encoding='utf-8') as f:
                self.config = json.load(f)
            return self.config.get('cloud_bridge', {})
        except (FileNotFoundError, json.JSONDecodeError):
            print("Error: Could not load or parse config.json.")
            return None

    def setup_events(self):
        """Defines handlers for socket.io events."""
        @self.sio.event
        def connect():
            print("--- Connection to Cloud Bridge established. ---")
            print("Listener is now online and waiting for commands.")

        @self.sio.event
        def connect_error(data):
            print(f"--- Connection failed: {data} ---")

        @self.sio.event
        def disconnect():
            print("--- Disconnected from Cloud Bridge. Will try to reconnect... ---")

        @self.sio.on('run_script')
        def on_run_script(data):
            command_str = data.get('command')
            if command_str:
                print(f"\n>>> Received command to execute: '{command_str}'")
                # Run the command in a separate thread to not block the listener
                thread = threading.Thread(target=self.execute_command, args=(command_str,))
                thread.start()

    def execute_command(self, command_str):
        """Executes the command and streams its output back to the server."""
        command_parts = command_str.split()
        
        try:
            # We use Popen to get real-time output
            process = subprocess.Popen(
                # Run the 'st' command directly as it's installed globally
                ['st'] + command_parts,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                encoding='utf-8',
                errors='replace'
            )

            # Stream output line by line
            for line in iter(process.stdout.readline, ''):
                print(line, end='') # Also print locally
                self.sio.emit('script_output', {'data': line})
            
            process.stdout.close()
            return_code = process.wait()
            final_message = f"\n--- Command '{command_str}' finished with exit code {return_code} ---"
            print(final_message)
            self.sio.emit('script_output', {'data': final_message})

        except Exception as e:
            error_message = f"Error executing command: {e}"
            print(error_message)
            self.sio.emit('script_output', {'data': error_message})

    def run(self):
        """Connects to the server and waits for events."""
        print("--- Starting ST Local Listener ---")
        bridge_config = self.load_config()
        if not bridge_config or not bridge_config.get('enabled'):
            print("Cloud Bridge is disabled in the configuration. Exiting.")
            return

        url = bridge_config.get('url')
        api_key = bridge_config.get('api_key')

        if not url or not api_key:
            print("Cloud Bridge URL or API Key is not configured. Exiting.")
            return

        headers = {'Authorization': api_key, 'X-Client-Type': 'listener'}
        self.sio.connect(url, headers=headers, transports=['websocket'])
        self.sio.wait()

if __name__ == "__main__":
    listener = LocalListener()
    try:
        listener.run()
    except KeyboardInterrupt:
        print("\n--- ST Local Listener stopped. ---")
        sys.exit(0)