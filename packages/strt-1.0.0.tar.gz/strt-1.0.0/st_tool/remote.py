# This file contains the SDK for remotely controlling the Cloud Brain.

import socketio
import threading
import time

class Client:
    """
    A client for connecting to and controlling a remote ST Cloud Brain instance.
    """
    def __init__(self, replit_url, api_key):
        """
        Initializes the remote client.

        :param replit_url: The full URL of the Replit project (e.g., "https://my-brain.replit.co").
        :param api_key: The secret API key configured in the Replit environment.
        """
        if not replit_url or not api_key:
            raise ValueError("Replit URL and API Key cannot be empty.")
            
        self.replit_url = replit_url
        self.api_key = api_key
        self.sio = socketio.Client(reconnection_attempts=5, reconnection_delay=5)
        self.is_connected = False
        self._output_callback = None
        self._setup_events()

    def _setup_events(self):
        """Internal method to set up standard socket.io event handlers."""
        @self.sio.event
        def connect():
            self.is_connected = True
            print("ST-SDK: Connection to Cloud Brain established.")

        @self.sio.event
        def disconnect():
            self.is_connected = False
            print("ST-SDK: Disconnected from Cloud Brain.")

        @self.sio.on('terminal_output')
        def on_terminal_output(data):
            """Handles incoming terminal output from the server."""
            if self._output_callback and callable(self._output_callback):
                self._output_callback(data.get('data', ''))

    def connect(self, wait_for_connection=True):
        """
        Connects to the Cloud Brain.

        :param wait_for_connection: If True, blocks until the connection is established.
        """
        if self.is_connected:
            print("ST-SDK: Already connected.")
            return
        try:
            print(f"ST-SDK: Connecting to {self.replit_url}...")
            headers = {'Authorization': self.api_key}
            self.sio.connect(self.replit_url, headers=headers, transports=['websocket'])
            if wait_for_connection:
                self.sio.wait() # This will block until disconnected. For background use, set to False.
        except Exception as e:
            print(f"ST-SDK: Connection failed: {e}")

    def connect_background(self):
        """Connects to the Cloud Brain in a separate thread, allowing the main script to continue."""
        if self.is_connected:
            print("ST-SDK: Already connected.")
            return
        
        thread = threading.Thread(target=self.connect, args=(True,))
        thread.daemon = True
        thread.start()
        time.sleep(2) # Give it a moment to establish connection

    def disconnect(self):
        """Disconnects from the Cloud Brain."""
        if self.is_connected:
            self.sio.disconnect()

    def execute(self, command, on_output=None):
        """
        Executes a command on the remote Cloud Brain.

        :param command: The command string to execute (e.g., "kitty").
        :param on_output: A callback function that receives each line of output from the command.
        """
        if not self.is_connected:
            print("ST-SDK: Not connected. Please call connect() or connect_background() first.")
            return
        
        self._output_callback = on_output
        self.sio.emit('execute_command', {'command': command})

    def send_input(self, data):
        """
        Sends input data to the currently running script on the Cloud Brain.

        :param data: The string data to send to the script's stdin.
        """
        if not self.is_connected:
            print("ST-SDK: Not connected.")
            return
        
        # Ensure data has a newline, as `input()` in Python expects it.
        if not isinstance(data, str):
            data = str(data)
        
        self.sio.emit('script_input', {'data': data + '\n'})