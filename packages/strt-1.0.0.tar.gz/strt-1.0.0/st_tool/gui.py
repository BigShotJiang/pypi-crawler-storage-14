import tkinter as tk
from tkinter import ttk, messagebox, filedialog
# ThemedTk is optional now, but we keep it for themed light modes
from ttkthemes import ThemedTk
import json
import webbrowser
import logging
import time
import shutil
import requests
import threading
import os
import uuid

PLUGIN_DIR_NAME = "plugins"

class ProjectManagerApp:
    def __init__(self, root):
        self.root = root
        self.root.title("st - Project & Plugin Manager")
        self.root.geometry("850x450")
        self.root.minsize(700, 400)

        # --- Config Path ---
        # Centralized config directory in user's home folder
        self.config_dir = os.path.join(os.path.expanduser('~'), '.st_tool')
        os.makedirs(self.config_dir, exist_ok=True)
        self.plugin_dir = os.path.join(self.config_dir, PLUGIN_DIR_NAME)
        self.config_path = os.path.join(self.config_dir, 'config.json')
        self.projects = {}
        self.keywords = {}
        self.groups = {}
        self.ui_settings = {}
        self.cloud_bridge_settings = {}
        self.selected_project_id = None
        self.auth_tokens = {}

        # --- Style Configuration for Dark Mode ---
        self.style = ttk.Style(self.root)
        # print(self.style.theme_names()) # To see available themes
        
        # Define colors for dark theme
        self.themes = {
            "light": {"theme": "arc", "bg": "#f0f0f0", "fg": "black", "list_bg": "white", "select_bg": "#0078d7", "select_fg": "white"},
            "dark": {"theme": "equilux", "bg": "#2b2b2b", "fg": "#bbbbbb", "list_bg": "#3c3f41", "select_bg": "#4b6eaf", "select_fg": "white"}
        }

        # --- UI Layout ---
        self.create_widgets()
        self.load_config()

    def create_widgets(self):
        # Main frame
        main_frame = ttk.Frame(self.root, padding="10")
        main_frame.pack(fill=tk.BOTH, expand=True)

        # --- Theme Toggle Button ---
        self.theme_button = ttk.Button(main_frame, text="Toggle Theme", command=self.toggle_theme)
        self.theme_button.pack(anchor="ne", pady=(0, 5), padx=5)

        # --- Notebook for Tabs ---
        self.notebook = ttk.Notebook(main_frame)
        self.notebook.pack(fill=tk.BOTH, expand=True)

        # --- Projects Tab ---
        projects_frame = ttk.Frame(self.notebook, padding="10")
        self.notebook.add(projects_frame, text='Projects')
        self.create_projects_tab(projects_frame)

        # --- Plugins Tab ---
        plugins_frame = ttk.Frame(self.notebook, padding="10")
        self.notebook.add(plugins_frame, text='Plugins')
        self.create_plugins_tab(plugins_frame)

        # --- Groups Tab ---
        groups_frame = ttk.Frame(self.notebook, padding="10")
        self.notebook.add(groups_frame, text='Groups')
        self.create_groups_tab(groups_frame)

        # --- NEW: Cloud Tab ---
        cloud_frame = ttk.Frame(self.notebook, padding="10")
        self.notebook.add(cloud_frame, text='Cloud')
        self.create_cloud_tab(cloud_frame)

    def create_projects_tab(self, parent_frame):
        # Left frame for project list
        left_frame = ttk.LabelFrame(parent_frame, text="Projects", padding="10")
        left_frame.grid(row=0, column=0, sticky="nsew", padx=(0, 10))
        parent_frame.grid_columnconfigure(0, weight=1)
        parent_frame.grid_rowconfigure(0, weight=1)

        self.project_listbox = tk.Listbox(left_frame, exportselection=False, 
                                          borderwidth=0,
                                          highlightthickness=0)
        self.project_listbox.pack(fill=tk.BOTH, expand=True)
        self.project_listbox.bind("<<ListboxSelect>>", self.on_project_select)

        # Right frame for details
        right_frame = ttk.LabelFrame(parent_frame, text="Project Details", padding="10")
        right_frame.grid(row=0, column=1, sticky="nsew")
        parent_frame.grid_columnconfigure(1, weight=2)

        # Project Name
        ttk.Label(right_frame, text="Project Name:").grid(row=0, column=0, sticky="w", pady=2)
        self.name_var = tk.StringVar()
        self.name_entry = ttk.Entry(right_frame, textvariable=self.name_var)
        self.name_entry.grid(row=0, column=1, columnspan=2, sticky="ew", pady=2)

        # Script Path
        ttk.Label(right_frame, text="Script Path:").grid(row=1, column=0, sticky="w", pady=2)
        self.path_var = tk.StringVar()
        self.path_entry = ttk.Entry(right_frame, textvariable=self.path_var)
        self.path_entry.grid(row=1, column=1, sticky="ew", pady=2)
        self.browse_project_button = ttk.Button(right_frame, text="Browse...", command=self.browse_file)
        self.browse_project_button.grid(row=1, column=2, sticky="ew", padx=(5, 0))

        # Keywords
        ttk.Label(right_frame, text="Keywords (comma-separated):").grid(row=2, column=0, sticky="w", pady=2)
        self.keywords_var = tk.StringVar()
        self.keywords_entry = ttk.Entry(right_frame, textvariable=self.keywords_var)
        self.keywords_entry.grid(row=2, column=1, columnspan=2, sticky="ew", pady=2)

        right_frame.grid_columnconfigure(1, weight=1)

        # --- Project Buttons Frame ---
        button_frame = ttk.Frame(right_frame)
        button_frame.grid(row=3, column=0, columnspan=3, sticky="ew", pady=(20, 0))

        ttk.Button(button_frame, text="New Project", command=self.new_project).pack(side=tk.LEFT, padx=(0, 5))
        ttk.Button(button_frame, text="Save", command=self.save_project).pack(side=tk.LEFT, padx=5)
        ttk.Button(button_frame, text="Delete", command=self.delete_project).pack(side=tk.LEFT, padx=5)
        ttk.Button(button_frame, text="Open Folder", command=self.open_project_folder).pack(side=tk.RIGHT, padx=(5, 0))

    def create_plugins_tab(self, parent_frame):
        # Left frame for plugin list
        left_frame = ttk.LabelFrame(parent_frame, text="Plugins (Commands)", padding="10")
        left_frame.grid(row=0, column=0, sticky="nsew", padx=(0, 10))
        parent_frame.grid_columnconfigure(0, weight=1)
        parent_frame.grid_rowconfigure(0, weight=1)

        self.plugin_listbox = tk.Listbox(left_frame, exportselection=False, borderwidth=0, highlightthickness=0)
        self.plugin_listbox.pack(fill=tk.BOTH, expand=True)
        self.plugin_listbox.bind("<<ListboxSelect>>", self.on_plugin_select)

        # Right frame for plugin editor
        right_frame = ttk.LabelFrame(parent_frame, text="Plugin Editor", padding="10")
        right_frame.grid(row=0, column=1, sticky="nsew")
        parent_frame.grid_columnconfigure(1, weight=2)

        # Plugin Command (Filename)
        ttk.Label(right_frame, text="Command (filename):").grid(row=0, column=0, sticky="w", pady=2)
        self.plugin_name_var = tk.StringVar()
        self.plugin_name_entry = ttk.Entry(right_frame, textvariable=self.plugin_name_var)
        self.plugin_name_entry.grid(row=0, column=1, sticky="ew", pady=2)
        ttk.Label(right_frame, text=".py").grid(row=0, column=2, sticky="w", padx=(2,0))

        # Plugin Code Editor
        self.plugin_code_text = tk.Text(right_frame, wrap="word", height=15, undo=True, borderwidth=0, highlightthickness=0)
        self.plugin_code_text.grid(row=1, column=0, columnspan=3, sticky="nsew", pady=(10, 0))
        right_frame.grid_rowconfigure(1, weight=1)
        right_frame.grid_columnconfigure(1, weight=1)

        # --- Plugin Buttons Frame ---
        button_frame = ttk.Frame(right_frame)
        button_frame.grid(row=2, column=0, columnspan=3, sticky="ew", pady=(10, 0))

        ttk.Button(button_frame, text="New Plugin", command=self.new_plugin).pack(side=tk.LEFT, padx=(0, 5))
        ttk.Button(button_frame, text="Save Plugin", command=self.save_plugin).pack(side=tk.LEFT, padx=5)
        ttk.Button(button_frame, text="Delete Plugin", command=self.delete_plugin).pack(side=tk.LEFT, padx=5)

    def create_groups_tab(self, parent_frame):
        # Left frame for group list
        left_frame = ttk.LabelFrame(parent_frame, text="Groups", padding="10")
        left_frame.grid(row=0, column=0, sticky="nsew", padx=(0, 10))
        parent_frame.grid_columnconfigure(0, weight=1)
        parent_frame.grid_rowconfigure(0, weight=1)

        self.group_listbox = tk.Listbox(left_frame, exportselection=False, borderwidth=0, highlightthickness=0)
        self.group_listbox.pack(fill=tk.BOTH, expand=True)
        self.group_listbox.bind("<<ListboxSelect>>", self.on_group_select)

        # Right frame for group details
        right_frame = ttk.LabelFrame(parent_frame, text="Group Details", padding="10")
        right_frame.grid(row=0, column=1, sticky="nsew")
        parent_frame.grid_columnconfigure(1, weight=2)

        # Group Name
        ttk.Label(right_frame, text="Group Name:").grid(row=0, column=0, sticky="w", pady=2)
        self.group_name_var = tk.StringVar()
        self.group_name_entry = ttk.Entry(right_frame, textvariable=self.group_name_var)
        self.group_name_entry.grid(row=0, column=1, sticky="ew", pady=2)
        right_frame.grid_columnconfigure(1, weight=1)
        
        # Group Description
        ttk.Label(right_frame, text="Description:").grid(row=1, column=0, sticky="w", pady=2)
        self.group_desc_var = tk.StringVar()
        self.group_desc_entry = ttk.Entry(right_frame, textvariable=self.group_desc_var)
        self.group_desc_entry.grid(row=1, column=1, sticky="ew", pady=2)

        # Orchestration Steps Frame
        steps_frame = ttk.LabelFrame(right_frame, text="Orchestration Steps", padding="10")
        steps_frame.grid(row=2, column=0, columnspan=2, sticky="nsew", pady=(10, 0))
        right_frame.grid_rowconfigure(1, weight=1)

        # This frame will hold the list of steps
        self.steps_list_frame = ttk.Frame(steps_frame)
        self.steps_list_frame.pack(fill="x", expand=True)
        steps_frame.grid_columnconfigure(0, weight=1)

        # Add Project to Group section
        add_step_frame = ttk.Frame(right_frame)
        add_step_frame.grid(row=3, column=0, columnspan=2, sticky="ew", pady=(10,0))
        self.add_project_combo_var = tk.StringVar()
        self.add_project_combo = ttk.Combobox(add_step_frame, textvariable=self.add_project_combo_var, state="readonly")
        self.add_project_combo.pack(side="left", fill="x", expand=True, padx=(0, 5))
        ttk.Button(add_step_frame, text="Add Step", command=self.add_step_to_group).pack(side="left")
        add_step_frame.grid_columnconfigure(0, weight=1)

        # --- Group Buttons Frame ---
        button_frame = ttk.Frame(right_frame)
        button_frame.grid(row=4, column=0, columnspan=2, sticky="ew", pady=(10, 0))
        ttk.Button(button_frame, text="New Group", command=self.new_group).pack(side=tk.LEFT, padx=(0, 5))
        ttk.Button(button_frame, text="Save Group", command=self.save_group).pack(side=tk.LEFT, padx=5)
        ttk.Button(button_frame, text="Delete Group", command=self.delete_group).pack(side=tk.LEFT, padx=5)

    def create_cloud_tab(self, parent_frame):
        # Notebook for different cloud providers
        cloud_notebook = ttk.Notebook(parent_frame)
        cloud_notebook.pack(fill="both", expand=True, pady=10)

        # --- Replit Frame ---
        replit_frame = ttk.Frame(cloud_notebook, padding="10")
        cloud_notebook.add(replit_frame, text='Replit (Easy Mode)')
        self.create_replit_subtab(replit_frame)

        # --- Google Cloud Frame ---
        gcp_frame = ttk.Frame(cloud_notebook, padding="10")
        cloud_notebook.add(gcp_frame, text='Google Cloud (Pro Mode)')
        self.create_gcp_subtab(gcp_frame)

    def create_replit_subtab(self, parent_frame):
        ttk.Label(parent_frame, text="Host your Cloud Brain on Replit for a quick and easy setup.", wraplength=400).pack(anchor="w", pady=5)
        
        settings_frame = ttk.LabelFrame(parent_frame, text="Replit Configuration", padding="10")
        settings_frame.pack(fill="x", pady=10)
        settings_frame.grid_columnconfigure(1, weight=1)

        ttk.Label(settings_frame, text="Replit URL:").grid(row=0, column=0, sticky="w", pady=2)
        ttk.Entry(settings_frame).grid(row=0, column=1, sticky="ew", pady=2)

        ttk.Label(settings_frame, text="API Key:").grid(row=1, column=0, sticky="w", pady=2)
        ttk.Entry(settings_frame, show="*").grid(row=1, column=1, sticky="ew", pady=2)

        ttk.Button(settings_frame, text="Save Replit Settings").grid(row=2, column=1, sticky="e", pady=10)

    def create_gcp_subtab(self, parent_frame):
        ttk.Label(parent_frame, text="Host on Google Compute Engine for a powerful, reliable, and professional setup.", wraplength=400).pack(anchor="w", pady=5)
        ttk.Button(parent_frame, text="View Setup Guide for Google Cloud").pack(pady=10)


    def browse_file(self):
        filepath = filedialog.askopenfilename(
            title="Select a script file",
            filetypes=(("Python scripts", "*.py"), ("Batch files", "*.bat"), ("All files", "*.*"))
        )
        if filepath:
            self.path_var.set(filepath)

    def load_config(self):
        # This is a temporary fix for a potential bug in ttkthemes on some systems
        # where the canvas background is not set correctly by the theme.
        canvas = tk.Canvas() # Dummy canvas to get default bg
        self.default_bg = canvas.cget("background")
        logging.info("Loading configuration...")
        self.auth_tokens = {}
        
        try:
            with open(self.config_path, 'r', encoding='utf-8') as f:
                config = json.load(f)
            self.projects = config.get('projects', {})
            self.keywords = config.get('keywords', {})
            self.groups = config.get('groups', {})
            self.ui_settings = config.get('ui_settings', {"theme": "light"})
            self.cloud_bridge_settings = config.get('cloud_bridge', {})
            self.auth_tokens = config.get('auth_tokens', {})
        except (FileNotFoundError, json.JSONDecodeError):
            logging.warning("Config file not found or invalid. Creating a new one.")
            self.projects = {}
            self.keywords = {}
            self.groups = {}
            self.ui_settings = {"theme": "light"}
            self.cloud_bridge_settings = {}
            self.auth_tokens = {}
            # Create a default config if it doesn't exist
            with open(self.config_path, 'w') as f:
                json.dump({"projects": {}, "keywords": {}, "groups": {}, "ui_settings": {"theme": "light"}, "cloud_bridge": {}}, f, indent=2)

        self.apply_theme()
        self.populate_project_list()
        self.populate_plugin_list()
        self.populate_group_list()

    def save_config(self):
        config_data = {'projects': self.projects, 'keywords': self.keywords, 
                       'groups': self.groups, 'ui_settings': self.ui_settings,
                       'auth_tokens': self.auth_tokens,
                       'cloud_bridge': self.cloud_bridge_settings}
        try:
            logging.info("Saving configuration to %s", self.config_path)
            with open(self.config_path, 'w', encoding='utf-8') as f:
                json.dump(config_data, f, indent=2, sort_keys=True)
            return True
        except Exception as e:
            logging.error("Failed to save config.json: %s", e)
            messagebox.showerror("Save Error", f"Failed to save config.json:\n{e}")
            return False

    def populate_project_list(self):
        self.project_listbox.delete(0, tk.END)
        self.project_id_map = {}
        sorted_projects = sorted(self.projects.items(), key=lambda item: item[1].get('name', '').lower())
        
        project_names = []
        for project_id, info in sorted_projects:
            display_name = info.get('name', project_id)
            self.project_listbox.insert(tk.END, display_name)
            self.project_id_map[self.project_listbox.size() - 1] = project_id
            project_names.append(display_name)
        
        # Update the combobox in the groups tab
        self.add_project_combo['values'] = project_names
        
        self.clear_details()

    def populate_group_list(self):
        self.group_listbox.delete(0, tk.END)
        for group_name in sorted(self.groups.keys()):
            self.group_listbox.insert(tk.END, group_name)

    def populate_plugin_list(self):
        self.plugin_listbox.delete(0, tk.END)
        if not os.path.isdir(self.plugin_dir):
            os.makedirs(self.plugin_dir)
        
        for filename in sorted(os.listdir(self.plugin_dir)):
            if filename.endswith(".py"):
                self.plugin_listbox.insert(tk.END, filename[:-3]) # Show command without .py

    def on_project_select(self, event=None):
        selection_indices = self.project_listbox.curselection()
        if not selection_indices:
            return
        
        selected_index = selection_indices[0]
        self.selected_project_id = self.project_id_map.get(selected_index)

        if self.selected_project_id:
            project_info = self.projects[self.selected_project_id]
            self.name_var.set(project_info.get('name', ''))
            self.path_var.set(project_info.get('path', ''))

            # Find all keywords for this project
            project_keywords = [kw for kw, pid in self.keywords.items() if pid == self.selected_project_id]
            self.keywords_var.set(", ".join(sorted(project_keywords)))

    def on_plugin_select(self, event=None):
        selection_indices = self.plugin_listbox.curselection()
        if not selection_indices:
            return
        
        selected_plugin_name = self.plugin_listbox.get(selection_indices[0])
        self.plugin_name_var.set(selected_plugin_name)
        
        filepath = os.path.join(self.plugin_dir, selected_plugin_name + ".py")
        try:
            with open(filepath, 'r', encoding='utf-8') as f:
                self.plugin_code_text.delete('1.0', tk.END)
                self.plugin_code_text.insert('1.0', f.read())
        except Exception as e:
            messagebox.showerror("Error", f"Could not read plugin file:\n{e}")

    def on_group_select(self, event=None):
        selection_indices = self.group_listbox.curselection()
        if not selection_indices:
            return

        group_name = self.group_listbox.get(selection_indices[0])
        group_data = self.groups.get(group_name, {})

        self.group_name_var.set(group_name)
        self.group_desc_var.set(group_data.get("description", ""))
        
        self.rebuild_steps_list(group_data.get("steps", []))
    
    def rebuild_steps_list(self, steps):
        # Clear existing steps
        for widget in self.steps_list_frame.winfo_children():
            widget.destroy()

        self.step_widgets = []
        for i, step in enumerate(steps):
            self.create_step_widget(step, i)

    def create_step_widget(self, step, index):
        project_id = step.get("project_id")
        project_name = self.projects.get(project_id, {}).get("name", f"Unknown ({project_id})")
        delay = step.get("delay", 0)

        step_frame = ttk.Frame(self.steps_list_frame, padding=5)
        step_frame.pack(fill="x", expand=True, pady=2)

        ttk.Label(step_frame, text=f"{index + 1}. {project_name}").pack(side="left", fill="x", expand=True)
        
        ttk.Button(step_frame, text="X", width=2, command=lambda i=index: self.remove_step_from_group(i)).pack(side="right")
        ttk.Button(step_frame, text="▼", width=2, command=lambda i=index: self.move_step(i, 1)).pack(side="right", padx=2)
        ttk.Button(step_frame, text="▲", width=2, command=lambda i=index: self.move_step(i, -1)).pack(side="right", padx=2)

        delay_var = tk.StringVar(value=str(delay))
        ttk.Entry(step_frame, textvariable=delay_var, width=5).pack(side="right", padx=5)
        ttk.Label(step_frame, text="Delay (s):").pack(side="right")

        self.step_widgets.append({"frame": step_frame, "project_id": project_id, "delay_var": delay_var})

    def clear_details(self):
        self.selected_project_id = None
        self.name_var.set("")
        self.path_var.set("")
        self.keywords_var.set("")
        self.project_listbox.selection_clear(0, tk.END)

    def new_project(self):
        self.clear_details()
        self.name_entry.focus_set()

    def save_project(self):
        name = self.name_var.get().strip()
        path = self.path_var.get().strip()
        keywords_str = self.keywords_var.get().strip()

        if not name or not path or not keywords_str:
            messagebox.showwarning("Incomplete Data", "Please fill in Project Name, Script Path, and at least one Keyword.")
            return

        new_keywords = {kw.strip().lower() for kw in keywords_str.split(',') if kw.strip()}
        
        # --- Logic for saving ---
        project_id_to_save = self.selected_project_id
        if not project_id_to_save: # This is a new project
            project_id_to_save = f"proj_{uuid.uuid4().hex[:8]}"

        # Update project info
        self.projects[project_id_to_save] = {'name': name, 'path': path}

        # Update keywords: remove old ones for this project, add new ones
        # First, remove all existing keywords pointing to this project ID
        keys_to_remove = [kw for kw, pid in self.keywords.items() if pid == project_id_to_save]
        for kw in keys_to_remove:
            del self.keywords[kw]
        
        # Then, add the new/updated keywords
        for kw in new_keywords:
            # Check if keyword is used by another project
            if kw in self.keywords and self.keywords[kw] != project_id_to_save:
                other_proj_id = self.keywords[kw]
                other_proj_name = self.projects.get(other_proj_id, {}).get('name', 'another project')
                messagebox.showwarning("Keyword Conflict", f"The keyword '{kw}' is already used by '{other_proj_name}'.\nPlease choose a different keyword.")
                return
            self.keywords[kw] = project_id_to_save

        if self.save_config():
            messagebox.showinfo("Success", f"Project '{name}' saved successfully.")
            self.load_config()

    def delete_project(self):
        if not self.selected_project_id:
            messagebox.showwarning("No Selection", "Please select a project to delete.")
            return

        project_name = self.projects[self.selected_project_id].get('name', 'this project')
        if not messagebox.askyesno("Confirm Deletion", f"Are you sure you want to delete '{project_name}'?"):
            return

        # Delete from projects
        del self.projects[self.selected_project_id]

        # Delete associated keywords
        keys_to_remove = [kw for kw, pid in self.keywords.items() if pid == self.selected_project_id]
        for kw in keys_to_remove:
            del self.keywords[kw]

        if self.save_config():
            messagebox.showinfo("Success", f"Project '{project_name}' has been deleted.")
            self.load_config()

    def open_project_folder(self):
        if not self.selected_project_id:
            messagebox.showwarning("No Selection", "Please select a project first.")
            return

        project_info = self.projects.get(self.selected_project_id)
        script_path = project_info.get('path')

        if not script_path or not os.path.exists(script_path):
            messagebox.showerror("Error", "The script path for this project is invalid or does not exist.")
            return

        folder_path = os.path.dirname(script_path)
        os.startfile(folder_path) # This opens the folder in Windows File Explorer

    # --- Group Methods ---
    def new_group(self):
        self.group_listbox.selection_clear(0, tk.END)
        self.group_name_var.set("")
        self.group_desc_var.set("")
        self.rebuild_steps_list([])
        self.group_name_entry.focus_set()

    def save_group(self):
        group_name = self.group_name_var.get().strip()
        if not group_name:
            messagebox.showwarning("Missing Name", "Group name cannot be empty.")
            return

        description = self.group_desc_var.get().strip()
        steps = []
        for step_widget in self.step_widgets:
            delay_str = step_widget["delay_var"].get()
            try:
                delay = int(delay_str) if delay_str else 0
            except ValueError:
                messagebox.showwarning("Invalid Delay", f"Delay must be a number. Found: '{delay_str}'")
                return
            steps.append({
                "project_id": step_widget["project_id"],
                "delay": delay
            })

        # Check if we are renaming and need to delete the old group
        selection_indices = self.group_listbox.curselection()
        if selection_indices:
            original_name = self.group_listbox.get(selection_indices[0])
            if original_name != group_name and original_name in self.groups:
                del self.groups[original_name]

        self.groups[group_name] = {"description": description, "steps": steps}

        if self.save_config():
            messagebox.showinfo("Success", f"Group '{group_name}' saved successfully.")
            self.populate_group_list()

    def delete_group(self):
        selection_indices = self.group_listbox.curselection()
        if not selection_indices:
            messagebox.showwarning("No Selection", "Please select a group to delete.")
            return

        group_name = self.group_listbox.get(selection_indices[0])
        if not messagebox.askyesno("Confirm Deletion", f"Are you sure you want to delete the '{group_name}' group?"):
            return

        if group_name in self.groups:
            del self.groups[group_name]
            if self.save_config():
                self.new_group()
                self.populate_group_list()

    def add_step_to_group(self):
        selected_project_name = self.add_project_combo_var.get()
        if not selected_project_name:
            messagebox.showwarning("No Project Selected", "Please select a project from the dropdown to add.")
            return

        # Find project_id from name
        project_id_to_add = None
        for pid, info in self.projects.items():
            if info.get("name") == selected_project_name:
                project_id_to_add = pid
                break
        
        if project_id_to_add:
            new_step = {"project_id": project_id_to_add, "delay": 0}
            self.create_step_widget(new_step, len(self.step_widgets))

    def remove_step_from_group(self, index):
        if 0 <= index < len(self.step_widgets):
            self.step_widgets.pop(index)
            # Re-render the list to update indices and visuals
            current_steps = []
            for step_widget in self.step_widgets:
                delay = int(step_widget["delay_var"].get() or 0)
                current_steps.append({"project_id": step_widget["project_id"], "delay": delay})
            self.rebuild_steps_list(current_steps)

    def move_step(self, index, direction):
        if not (0 <= index < len(self.step_widgets)):
            return
        
        new_index = index + direction
        if not (0 <= new_index < len(self.step_widgets)):
            return

        # Rebuild the list of steps in the new order
        current_steps = []
        for step_widget in self.step_widgets:
            delay = int(step_widget["delay_var"].get() or 0)
            current_steps.append({"project_id": step_widget["project_id"], "delay": delay})
        
        current_steps.insert(new_index, current_steps.pop(index))
        self.rebuild_steps_list(current_steps)

    # --- Plugin Methods ---
    def new_plugin(self):
        self.plugin_listbox.selection_clear(0, tk.END)
        self.plugin_name_var.set("")
        self.plugin_code_text.delete('1.0', tk.END)
        self.plugin_code_text.insert('1.0', 'import sys\nimport os\n\n# Your code here\nprint("Hello from new plugin!")\nprint(f"Arguments: {sys.argv[1:]}")\n')
        self.plugin_name_entry.focus_set()

    def save_plugin(self):
        plugin_name = self.plugin_name_var.get().strip()
        plugin_code = self.plugin_code_text.get('1.0', tk.END).strip()

        if not plugin_name:
            messagebox.showwarning("Missing Name", "Plugin command (filename) cannot be empty.")
            return

        # Basic validation for filename
        if any(c in plugin_name for c in r'<>:"/\|?*'):
            messagebox.showwarning("Invalid Name", "Plugin name contains invalid characters.")
            return

        filepath = os.path.join(self.plugin_dir, plugin_name + ".py")

        # Check if we are renaming and need to delete the old file
        selection_indices = self.plugin_listbox.curselection()
        if selection_indices:
            original_name = self.plugin_listbox.get(selection_indices[0])
            if original_name != plugin_name:
                original_filepath = os.path.join(self.plugin_dir, original_name + ".py")
                if os.path.exists(original_filepath):
                    os.remove(original_filepath)

        try:
            with open(filepath, 'w', encoding='utf-8') as f:
                f.write(plugin_code)
            messagebox.showinfo("Success", f"Plugin '{plugin_name}' saved successfully.")
            self.populate_plugin_list()
        except Exception as e:
            messagebox.showerror("Save Error", f"Failed to save plugin:\n{e}")

    def delete_plugin(self):
        selection_indices = self.plugin_listbox.curselection()
        if not selection_indices:
            messagebox.showwarning("No Selection", "Please select a plugin to delete.")
            return

        plugin_name = self.plugin_listbox.get(selection_indices[0])
        if not messagebox.askyesno("Confirm Deletion", f"Are you sure you want to delete the '{plugin_name}' plugin?"):
            return

        filepath = os.path.join(self.plugin_dir, plugin_name + ".py")
        try:
            os.remove(filepath)
            self.new_plugin() # Clear the fields
            self.populate_plugin_list()
        except Exception as e:
            messagebox.showerror("Delete Error", f"Failed to delete plugin:\n{e}")

    # --- Cloud Deployment Methods ---
    def open_deploy_dialog(self):
        if not self.auth_tokens.get('github'):
            messagebox.showerror("Authentication Required", "Please login with GitHub first.")
            return

        self.deploy_window = tk.Toplevel(self.root)
        self.deploy_window.title("Deploy New Cloud Project")
        self.deploy_window.geometry("450x200")
        
        frame = ttk.Frame(self.deploy_window, padding="15")
        frame.pack(fill="both", expand=True)

        # --- Local Project Selection ---
        ttk.Label(frame, text="Select Local Project to Deploy:").grid(row=0, column=0, sticky="w", pady=2)
        
        local_projects = [p.get('name', 'Unnamed') for p in self.projects.values()]
        self.deploy_local_project_var = tk.StringVar()
        deploy_combo = ttk.Combobox(frame, textvariable=self.deploy_local_project_var, values=local_projects, state="readonly")
        deploy_combo.grid(row=0, column=1, sticky="ew", pady=2)
        if local_projects:
            deploy_combo.current(0)

        # --- Cloud Project Name ---
        ttk.Label(frame, text="New Cloud Project Name:").grid(row=1, column=0, sticky="w", pady=2)
        self.deploy_cloud_name_var = tk.StringVar()
        ttk.Entry(frame, textvariable=self.deploy_cloud_name_var).grid(row=1, column=1, sticky="ew", pady=2)

        # --- Private Repo Checkbox ---
        self.deploy_private_var = tk.BooleanVar(value=True)
        ttk.Checkbutton(frame, text="Create as Private Repository", variable=self.deploy_private_var).grid(row=2, column=1, sticky="w", pady=5)

        # --- Deploy Button ---
        deploy_button = ttk.Button(frame, text="Start Deployment", command=self.start_deployment)
        deploy_button.grid(row=3, column=1, sticky="e", pady=(10,0))

        frame.grid_columnconfigure(1, weight=1)

    def start_deployment(self):
        """Starts the deployment process in a new thread."""
        local_project_name = self.deploy_local_project_var.get()
        cloud_project_name = self.deploy_cloud_name_var.get().strip()
        is_private = self.deploy_private_var.get()

        if not local_project_name or not cloud_project_name:
            messagebox.showerror("Error", "Please select a local project and provide a cloud project name.", parent=self.deploy_window)
            return

        # Disable the deploy window while processing
        self.deploy_window.grab_set()

        threading.Thread(target=self._deployment_flow, args=(local_project_name, cloud_project_name, is_private), daemon=True).start()

    def _deployment_flow(self, local_project_name, cloud_project_name, is_private):
        """The actual deployment logic."""
        logging.info("Starting deployment flow for '%s' as '%s'", local_project_name, cloud_project_name)
        github_token = self.auth_tokens.get('github')
        if not github_token:
            messagebox.showerror("Error", "GitHub token not found. Please re-authenticate.")
            self.deploy_window.grab_release()
            return

        # --- Step 1: Create GitHub Repository ---
        repo_url = None
        try:
            headers = {
                "Authorization": f"token {github_token}",
                "Accept": "application/vnd.github.v3+json"
            }
            data = {
                "name": cloud_project_name,
                "description": f"Cloud instance for ST-Tool project: {local_project_name}",
                "private": is_private
            }
            logging.info("Creating GitHub repository '%s'", cloud_project_name)
            response = requests.post("https://api.github.com/user/repos", headers=headers, json=data)
            response.raise_for_status() # Raise an exception for bad status codes (4xx or 5xx)
            repo_data = response.json()
            repo_url = repo_data.get("html_url")
            logging.info("Successfully created GitHub repo: %s", repo_url)
            messagebox.showinfo("Step 1 Complete", f"Successfully created GitHub repository: {repo_url}")
            # Next steps (uploading files, creating Replit) will go here.

        except requests.exceptions.HTTPError as e:
            error_details = e.response.json()
            message = error_details.get("message", "Unknown error")
            if "name already exists" in str(error_details):
                message = "A repository with this name already exists on your GitHub account."
            logging.error("GitHub repo creation failed: %s", message)
            messagebox.showerror("GitHub Error", f"Failed to create repository: {message}")
            self.deploy_window.destroy()
            return
        except Exception as e:
            logging.error("An unexpected error occurred during repo creation: %s", e)
            messagebox.showerror("Deployment Error", f"An unexpected error occurred: {e}")
        finally:
            # Re-enable the deploy window
            if self.deploy_window.winfo_exists():
                self.deploy_window.grab_release()

        if not repo_url:
            if self.deploy_window.winfo_exists():
                self.deploy_window.destroy()
            return

        # --- Step 2: Upload project files to GitHub ---
        try:
            messagebox.showinfo("Step 2: Uploading Files", "Now attempting to upload your project files to the new GitHub repository...", parent=self.deploy_window)
            logging.info("Finding local project path for '%s'", local_project_name)
            # Find the local project path
            local_project_path = None
            for proj in self.projects.values():
                if proj.get('name') == local_project_name and proj.get('path'):
                    local_project_path = os.path.dirname(proj.get('path'))
                    break
            if not local_project_path:
                raise Exception(f"Could not find the local path for project '{local_project_name}'.")
            logging.info("Uploading files from '%s' to '%s'", local_project_path, repo_url)
            self.upload_project_to_github(local_project_path, repo_url, github_token)
            logging.info("File upload to GitHub complete.")
            messagebox.showinfo("Step 2 Complete", "Successfully uploaded project files to GitHub.", parent=self.deploy_window)

            # --- Step 3: Create Replit project from GitHub repo ---
            messagebox.showinfo("Step 3: Deploying to Replit", "Now attempting to create a Replit project from the new GitHub repository...", parent=self.deploy_window)
            self.create_replit_from_github(repo_url)
            messagebox.showinfo("Deployment Complete!", "Your project has been successfully deployed to Replit from GitHub.", parent=self.deploy_window)
        except Exception as e:
            logging.error("An error occurred during Step 2 or 3 of deployment: %s", e)
            messagebox.showerror("Upload Error", f"Failed to upload files to GitHub: {e}", parent=self.deploy_window)
        finally:
            if self.deploy_window:
                if self.deploy_window.winfo_exists():
                    self.deploy_window.destroy()

    def apply_theme(self):
        current_theme_name = self.ui_settings.get("theme", "light")
        theme_props = self.themes.get(current_theme_name)

        self.root.set_theme(theme_props["theme"])
        self.root.configure(bg=theme_props["bg"])

        # Configure styles
        self.style.configure("TLabel", background=theme_props["bg"], foreground=theme_props["fg"])
        self.style.configure("TFrame", background=theme_props["bg"])
        self.style.configure("TLabelframe", background=theme_props["bg"], bordercolor=theme_props["list_bg"])
        self.style.configure("TLabelframe.Label", background=theme_props["bg"], foreground=theme_props["fg"])
        self.style.configure("TNotebook", background=theme_props["bg"])
        self.style.configure("TNotebook.Tab", background=theme_props["list_bg"], foreground=theme_props["fg"])
        self.style.map("TNotebook.Tab", background=[("selected", theme_props["select_bg"])], foreground=[("selected", theme_props["select_fg"])])
        self.style.configure("TButton", foreground=theme_props["fg"])
        self.style.configure("TCheckbutton", background=theme_props["bg"], foreground=theme_props["fg"])
        self.style.map("TCheckbutton", background=[('active', theme_props["bg"])])

        # Configure specific widgets
        for listbox in [self.project_listbox, self.plugin_listbox, self.group_listbox]:
            listbox.configure(background=theme_props["list_bg"], foreground=theme_props["fg"],
                              selectbackground=theme_props["select_bg"], selectforeground=theme_props["select_fg"])
        
        self.plugin_code_text.configure(background=theme_props["list_bg"], foreground=theme_props["fg"], insertbackground=theme_props["select_fg"])

    def toggle_theme(self):
        current_theme = self.ui_settings.get("theme", "light")
        new_theme = "dark" if current_theme == "light" else "light"
        self.ui_settings["theme"] = new_theme
        self.save_config()
        
        messagebox.showinfo("Theme Changed", "The theme has been changed. Please restart the GUI for the changes to take full effect.")
        self.root.destroy()


if __name__ == "__main__":
    # --- Setup professional logging ---
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - [%(levelname)s] - (%(threadName)-10s) - %(message)s',
    )
    # We need to load the config just to know which theme to apply on startup
    config_path = os.path.join(os.path.expanduser('~'), '.st_tool', 'config.json')
    theme_name = "light"
    try:
        with open(config_path, 'r') as f:
            config = json.load(f)
            theme_name = config.get('ui_settings', {}).get('theme', 'light')
    except (FileNotFoundError, json.JSONDecodeError):
        pass

    app_root = ThemedTk(theme="arc" if theme_name == "light" else "equilux")
    app = ProjectManagerApp(app_root)
    app_root.mainloop()

    def populate_project_list(self):
        self.project_listbox.delete(0, tk.END)
        self.project_id_map = {}
        sorted_projects = sorted(self.projects.items(), key=lambda item: item[1].get('name', '').lower())
        
        for project_id, info in sorted_projects:
            display_name = info.get('name', project_id)
            self.project_listbox.insert(tk.END, display_name)
            self.project_id_map[self.project_listbox.size() - 1] = project_id
        
        self.clear_details()
        self.rebuild_project_checklist()

    def rebuild_project_checklist(self):
        # Clear existing checklist
        for widget in self.scrollable_frame.winfo_children():
            widget.destroy()

        self.project_check_vars = {}
        sorted_projects = sorted(self.projects.items(), key=lambda item: item[1].get('name', '').lower())

        for project_id, info in sorted_projects:
            var = tk.BooleanVar()
            chk = ttk.Checkbutton(self.scrollable_frame, text=info.get('name', project_id), variable=var)
            chk.pack(anchor="w", padx=5, pady=2)
            self.project_check_vars[project_id] = var

    def populate_group_list(self):
        self.group_listbox.delete(0, tk.END)
        for group_name in sorted(self.groups.keys()):
            self.group_listbox.insert(tk.END, group_name)

    def populate_plugin_list(self):
        self.plugin_listbox.delete(0, tk.END)
        if not os.path.isdir(self.plugin_dir):
            os.makedirs(self.plugin_dir)
        
        for filename in sorted(os.listdir(self.plugin_dir)):
            if filename.endswith(".py"):
                self.plugin_listbox.insert(tk.END, filename[:-3]) # Show command without .py

    def on_project_select(self, event=None):
        selection_indices = self.project_listbox.curselection()
        if not selection_indices:
            return
        
        selected_index = selection_indices[0]
        self.selected_project_id = self.project_id_map.get(selected_index)

        if self.selected_project_id:
            project_info = self.projects[self.selected_project_id]
            self.name_var.set(project_info.get('name', ''))
            self.path_var.set(project_info.get('path', ''))

            # Find all keywords for this project
            project_keywords = [kw for kw, pid in self.keywords.items() if pid == self.selected_project_id]
            self.keywords_var.set(", ".join(sorted(project_keywords)))

    def on_plugin_select(self, event=None):
        selection_indices = self.plugin_listbox.curselection()
        if not selection_indices:
            return
        
        selected_plugin_name = self.plugin_listbox.get(selection_indices[0])
        self.plugin_name_var.set(selected_plugin_name)
        
        filepath = os.path.join(self.plugin_dir, selected_plugin_name + ".py")
        try:
            with open(filepath, 'r', encoding='utf-8') as f:
                self.plugin_code_text.delete('1.0', tk.END)
                self.plugin_code_text.insert('1.0', f.read())
        except Exception as e:
            messagebox.showerror("Error", f"Could not read plugin file:\n{e}")

    def on_group_select(self, event=None):
        selection_indices = self.group_listbox.curselection()
        if not selection_indices:
            return

        group_name = self.group_listbox.get(selection_indices[0])
        self.group_name_var.set(group_name)

        project_ids_in_group = self.groups.get(group_name, [])

        # Update checkboxes
        for project_id, var in self.project_check_vars.items():
            var.set(project_id in project_ids_in_group)


    def clear_details(self):
        self.selected_project_id = None
        self.name_var.set("")
        self.path_var.set("")
        self.keywords_var.set("")
        self.project_listbox.selection_clear(0, tk.END)

    def new_project(self):
        self.clear_details()
        self.name_entry.focus_set()

    def save_project(self):
        name = self.name_var.get().strip()
        path = self.path_var.get().strip()
        keywords_str = self.keywords_var.get().strip()

        if not name or not path or not keywords_str:
            messagebox.showwarning("Incomplete Data", "Please fill in Project Name, Script Path, and at least one Keyword.")
            return

        new_keywords = {kw.strip().lower() for kw in keywords_str.split(',') if kw.strip()}
        
        # --- Logic for saving ---
        project_id_to_save = self.selected_project_id
        if not project_id_to_save: # This is a new project
            project_id_to_save = f"proj_{uuid.uuid4().hex[:8]}"

        # Update project info
        self.projects[project_id_to_save] = {'name': name, 'path': path}

        # Update keywords: remove old ones for this project, add new ones
        # First, remove all existing keywords pointing to this project ID
        keys_to_remove = [kw for kw, pid in self.keywords.items() if pid == project_id_to_save]
        for kw in keys_to_remove:
            del self.keywords[kw]
        
        # Then, add the new/updated keywords
        for kw in new_keywords:
            # Check if keyword is used by another project
            if kw in self.keywords and self.keywords[kw] != project_id_to_save:
                other_proj_id = self.keywords[kw]
                other_proj_name = self.projects.get(other_proj_id, {}).get('name', 'another project')
                messagebox.showwarning("Keyword Conflict", f"The keyword '{kw}' is already used by '{other_proj_name}'.\nPlease choose a different keyword.")
                return
            self.keywords[kw] = project_id_to_save

        if self.save_config():
            messagebox.showinfo("Success", f"Project '{name}' saved successfully.")
            self.load_config()

    def delete_project(self):
        if not self.selected_project_id:
            messagebox.showwarning("No Selection", "Please select a project to delete.")
            return

        project_name = self.projects[self.selected_project_id].get('name', 'this project')
        if not messagebox.askyesno("Confirm Deletion", f"Are you sure you want to delete '{project_name}'?"):
            return

        # Delete from projects
        del self.projects[self.selected_project_id]

        # Delete associated keywords
        keys_to_remove = [kw for kw, pid in self.keywords.items() if pid == self.selected_project_id]
        for kw in keys_to_remove:
            del self.keywords[kw]

        if self.save_config():
            messagebox.showinfo("Success", f"Project '{project_name}' has been deleted.")
            self.load_config()

    def open_project_folder(self):
        if not self.selected_project_id:
            messagebox.showwarning("No Selection", "Please select a project first.")
            return

        project_info = self.projects.get(self.selected_project_id)
        script_path = project_info.get('path')

        if not script_path or not os.path.exists(script_path):
            messagebox.showerror("Error", "The script path for this project is invalid or does not exist.")
            return

        folder_path = os.path.dirname(script_path)
        os.startfile(folder_path) # This opens the folder in Windows File Explorer

    # --- Group Methods ---
    def new_group(self):
        self.group_listbox.selection_clear(0, tk.END)
        self.group_name_var.set("")
        for var in self.project_check_vars.values():
            var.set(False)
        self.group_name_entry.focus_set()

    def save_group(self):
        group_name = self.group_name_var.get().strip()
        if not group_name:
            messagebox.showwarning("Missing Name", "Group name cannot be empty.")
            return

        selected_project_ids = [pid for pid, var in self.project_check_vars.items() if var.get()]

        # Check if we are renaming and need to delete the old group
        selection_indices = self.group_listbox.curselection()
        if selection_indices:
            original_name = self.group_listbox.get(selection_indices[0])
            if original_name != group_name and original_name in self.groups:
                del self.groups[original_name]

        self.groups[group_name] = selected_project_ids

        if self.save_config():
            messagebox.showinfo("Success", f"Group '{group_name}' saved successfully.")
            self.populate_group_list()

    def delete_group(self):
        selection_indices = self.group_listbox.curselection()
        if not selection_indices:
            messagebox.showwarning("No Selection", "Please select a group to delete.")
            return

        group_name = self.group_listbox.get(selection_indices[0])
        if not messagebox.askyesno("Confirm Deletion", f"Are you sure you want to delete the '{group_name}' group?"):
            return

        if group_name in self.groups:
            del self.groups[group_name]
            if self.save_config():
                self.new_group()
                self.populate_group_list()

    # --- Plugin Methods ---
    def new_plugin(self):
        self.plugin_listbox.selection_clear(0, tk.END)
        self.plugin_name_var.set("")
        self.plugin_code_text.delete('1.0', tk.END)
        self.plugin_code_text.insert('1.0', 'import sys\nimport os\n\n# Your code here\nprint("Hello from new plugin!")\nprint(f"Arguments: {sys.argv[1:]}")\n')
        self.plugin_name_entry.focus_set()

    def save_plugin(self):
        plugin_name = self.plugin_name_var.get().strip()
        plugin_code = self.plugin_code_text.get('1.0', tk.END).strip()

        if not plugin_name:
            messagebox.showwarning("Missing Name", "Plugin command (filename) cannot be empty.")
            return

        # Basic validation for filename
        if any(c in plugin_name for c in r'<>:"/\|?*'):
            messagebox.showwarning("Invalid Name", "Plugin name contains invalid characters.")
            return

        filepath = os.path.join(self.plugin_dir, plugin_name + ".py")

        # Check if we are renaming and need to delete the old file
        selection_indices = self.plugin_listbox.curselection()
        if selection_indices:
            original_name = self.plugin_listbox.get(selection_indices[0])
            if original_name != plugin_name:
                original_filepath = os.path.join(self.plugin_dir, original_name + ".py")
                if os.path.exists(original_filepath):
                    os.remove(original_filepath)

        try:
            with open(filepath, 'w', encoding='utf-8') as f:
                f.write(plugin_code)
            messagebox.showinfo("Success", f"Plugin '{plugin_name}' saved successfully.")
            self.populate_plugin_list()
        except Exception as e:
            messagebox.showerror("Save Error", f"Failed to save plugin:\n{e}")

    def delete_plugin(self):
        selection_indices = self.plugin_listbox.curselection()
        if not selection_indices:
            messagebox.showwarning("No Selection", "Please select a plugin to delete.")
            return

        plugin_name = self.plugin_listbox.get(selection_indices[0])
        if not messagebox.askyesno("Confirm Deletion", f"Are you sure you want to delete the '{plugin_name}' plugin?"):
            return

        filepath = os.path.join(self.plugin_dir, plugin_name + ".py")
        try:
            os.remove(filepath)
            self.new_plugin() # Clear the fields
            self.populate_plugin_list()
        except Exception as e:
            messagebox.showerror("Delete Error", f"Failed to delete plugin:\n{e}")

    def apply_theme(self):
        current_theme_name = self.ui_settings.get("theme", "light")
        theme_props = self.themes.get(current_theme_name)

        self.root.set_theme(theme_props["theme"])
        self.root.configure(bg=theme_props["bg"])

        # Configure styles
        self.style.configure("TLabel", background=theme_props["bg"], foreground=theme_props["fg"])
        self.style.configure("TFrame", background=theme_props["bg"])
        self.style.configure("TLabelframe", background=theme_props["bg"], bordercolor=theme_props["list_bg"])
        self.style.configure("TLabelframe.Label", background=theme_props["bg"], foreground=theme_props["fg"])
        self.style.configure("TNotebook", background=theme_props["bg"])
        self.style.configure("TNotebook.Tab", background=theme_props["list_bg"], foreground=theme_props["fg"])
        self.style.map("TNotebook.Tab", background=[("selected", theme_props["select_bg"])], foreground=[("selected", theme_props["select_fg"])])
        self.style.configure("TButton", foreground=theme_props["fg"])
        self.style.configure("TCheckbutton", background=theme_props["bg"], foreground=theme_props["fg"])
        self.style.map("TCheckbutton", background=[('active', theme_props["bg"])])

        # Configure specific widgets
        for listbox in [self.project_listbox, self.plugin_listbox, self.group_listbox]:
            listbox.configure(background=theme_props["list_bg"], foreground=theme_props["fg"],
                              selectbackground=theme_props["select_bg"], selectforeground=theme_props["select_fg"])
        
        self.plugin_code_text.configure(background=theme_props["list_bg"], foreground=theme_props["fg"], insertbackground=theme_props["select_fg"])

    def toggle_theme(self):
        current_theme = self.ui_settings.get("theme", "light")
        new_theme = "dark" if current_theme == "light" else "light"
        self.ui_settings["theme"] = new_theme
        self.save_config()
        
        messagebox.showinfo("Theme Changed", "The theme has been changed. Please restart the GUI for the changes to take full effect.")
        self.root.destroy()


if __name__ == "__main__":
    # We need to load the config just to know which theme to apply on startup
    config_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'config.json')
    theme_name = "light"
    try:
        with open(config_path, 'r') as f:
            config = json.load(f)
            theme_name = config.get('ui_settings', {}).get('theme', 'light')
    except (FileNotFoundError, json.JSONDecodeError):
        pass

    app_root = ThemedTk(theme="arc" if theme_name == "light" else "equilux")
    app = ProjectManagerApp(app_root)
    app_root.mainloop()