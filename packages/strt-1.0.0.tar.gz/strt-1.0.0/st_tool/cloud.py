# This file is designed to be run on a cloud platform like Replit.
# It acts as a self-contained "Cloud Brain" that both listens for
# commands and executes them in the same environment.

from flask import Flask, request
from flask_socketio import SocketIO, emit, join_room, leave_room
import os
import logging
import subprocess
import sys
import threading

# IMPORTANT: On Replit, you would set this in the "Secrets" tab.
SECRET_KEY = os.environ.get("ST_BRIDGE_SECRET_KEY", "change-this-in-production")

app = Flask(__name__)
app.config['SECRET_KEY'] = SECRET_KEY
socketio = SocketIO(app)

# A dictionary to hold running processes, mapped by session ID.
# This is crucial for sending input to the correct process.
active_processes = {}


@app.route('/')
def index():
    return "ST Cloud Brain v3.0 is active.", 200

# --- WebSocket Event Handlers ---

@socketio.on('connect')
def handle_connect():
    """Handles a new connection from a remote control client (e.g., Discord bot)."""
    api_key = request.headers.get('Authorization')

    if not api_key or api_key != SECRET_KEY:
        print(f"Auth failed for client. Disconnecting.")
        return False # Reject connection

    # Each remote control client joins a room based on the API key.
    join_room(api_key)
    print(f"Remote control connected to room: {api_key}")
    emit('terminal_output', {'data': '--- Connection to Cloud Brain established. Ready for commands. ---'})

@socketio.on('disconnect')
def handle_disconnect():
    print(f"Remote control disconnected.")
    # Clean up any running process associated with this session
    process = active_processes.pop(request.sid, None)
    if process:
        print(f"Client disconnected, terminating process {process.pid}")
        process.terminate()

@socketio.on('execute_command')
def handle_execute_command(data):
    """Receives a command from a remote and executes it in a new thread."""
    command_str = data.get('command')
    if command_str:
        print(f"Received command to execute: '{command_str}'")
        # Run the command in a separate thread to not block the server.
        thread = threading.Thread(target=execute_and_stream, args=(command_str, request.sid))
        thread.start()

@socketio.on('script_input')
def handle_script_input(data):
    """Receives input from a remote and forwards it to the running script's stdin."""
    sid = request.sid
    process = active_processes.get(sid)

    if process and process.poll() is None: # Check if process exists and is running
        try:
            input_data = data.get('data', '')
            print(f"Forwarding input to process {process.pid}: {input_data.strip()}")
            process.stdin.write(input_data)
            process.stdin.flush()
        except Exception as e:
            print(f"Error writing to process stdin: {e}")


def execute_and_stream(command, sid):
    """
    Executes the command using st.py within the cloud environment
    and streams its output back to the client that requested it.
    """
    # This is the core change: We now run the project's main script directly.
    # We assume the project (e.g., 'Kitty') is a folder in the Replit environment.
    command_parts = command.split()
    project_name = command_parts[0] # e.g., 'kitty'
    project_args = command_parts[1:]

    # We need to find the actual path to the project's main script.
    # This logic will need to be more robust, perhaps reading a config file.
    # For now, we'll use a simple convention: ProjectName/main.py
    script_path = os.path.join(project_name.capitalize(), 'main.py')

    if not os.path.exists(script_path):
        error_message = f"Error: Project '{project_name}' not found at '{script_path}'."
        logging.error(error_message)
        socketio.emit('terminal_output', {'data': error_message}, room=sid)
        return

    try:
        process = subprocess.Popen(
            [sys.executable, script_path] + project_args,
            stdin=subprocess.PIPE,  # IMPORTANT: To allow writing to stdin
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            encoding='utf-8',
            errors='replace',
            cwd='.' # Run from the root directory of the project
        )
        
        # Store the process object so we can send input to it later
        active_processes[sid] = process

        # Stream output line by line
        for line in iter(process.stdout.readline, ''):
            # Emit the output only to the specific client that made the request
            socketio.emit('terminal_output', {'data': line}, room=sid)
        
        process.stdout.close()
        return_code = process.wait()
        final_message = f"\n--- Command '{command}' finished with exit code {return_code} ---"
        socketio.emit('terminal_output', {'data': final_message}, room=sid)

    except Exception as e:
        error_message = f"Error executing command: {e}"
        logging.error(error_message)
        socketio.emit('terminal_output', {'data': error_message}, room=sid)
    finally:
        # Clean up the process from our dictionary once it's finished
        if sid in active_processes:
            del active_processes[sid]

if __name__ == '__main__':
    # This allows running the Flask app. Replit will handle this automatically.
    socketio.run(app, host='0.0.0.0', port=81)