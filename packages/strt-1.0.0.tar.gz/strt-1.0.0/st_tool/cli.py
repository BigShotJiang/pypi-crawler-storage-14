import sys
import json
import shutil
import os
import subprocess
import time

PLUGIN_DIR_NAME = "plugins"

def main():
    """
    The main function for the 'st' command runner.
    It finds and executes the project script based on a keyword.
    """
    # In a library, we need a reliable way to find our data files.
    # For now, we assume config is in the user's home directory.
    config_dir = os.path.join(os.path.expanduser('~'), '.st_tool')

    # --- Migration Logic ---
    # If the new config dir doesn't exist, check for the old one and migrate.
    if not os.path.exists(config_dir):
        print("--- First time setup: Migrating configuration... ---")
        old_config_dir = os.path.join(os.path.expanduser('~'), 'Downloads', 'Tools', 'st - Logic')
        if os.path.isdir(old_config_dir):
            try:
                shutil.copytree(old_config_dir, config_dir)
                print(f"Successfully migrated config from {old_config_dir} to {config_dir}")
            except Exception as e:
                print(f"Warning: Could not migrate old config. A new one will be created. Error: {e}")
                os.makedirs(config_dir, exist_ok=True)
        else:
            os.makedirs(config_dir, exist_ok=True)

    os.makedirs(config_dir, exist_ok=True)
    config_path = os.path.join(config_dir, 'config.json')
    plugin_dir = os.path.join(config_dir, PLUGIN_DIR_NAME)

    # --- 0. Ensure plugin directory exists ---
    if not os.path.isdir(plugin_dir):
        os.makedirs(plugin_dir)

    # --- 1. Load Configuration ---
    try:
        with open(config_path, 'r', encoding='utf-8') as f:
            config = json.load(f)
        projects = config.get('projects', {})
        keywords = config.get('keywords', {})
        groups = config.get('groups', {})
    except FileNotFoundError:
        # Create a default config if it doesn't exist
        projects, keywords, groups = {}, {}, {}
        with open(config_path, 'w') as f:
            json.dump({"projects": {}, "keywords": {}, "groups": {}, "ui_settings": {"theme": "light"}, "cloud_bridge": {}}, f, indent=2)
    except json.JSONDecodeError:
        print(f"Error: Configuration file not found or corrupted at '{config_path}'.")
        print("Please run the GUI to set up your projects.")
        sys.exit(1)

    # --- 2. Check Command-Line Arguments ---
    if len(sys.argv) < 2:
        # --- Interactive Menu ---
        # Create a sorted list of projects
        sorted_projects = sorted(projects.values(), key=lambda p: p.get('name', '').lower())
        
        if not sorted_projects:
            print("No projects configured. Use 'st' to open the GUI and add projects.")
            sys.exit(0)
            
        for i, proj in enumerate(sorted_projects):
            print(f"  [{i+1}] {proj.get('name', 'Unnamed Project')}")
        
        print("\n  [g] Open GUI")
        print("  [q] Quit")

        try:
            choice = input("\nSelect a project to run: ").lower().strip()

            if choice == 'q':
                sys.exit(0)
            if choice == 'g':
                # Re-use the GUI launching logic
                sys.argv.append('gui') 
            elif choice.isdigit() and 1 <= int(choice) <= len(sorted_projects):
                selected_project = sorted_projects[int(choice) - 1]
                # Find the keyword for this project to run it
                # This is a bit inefficient but works. We find the first keyword that matches the project path.
                found_keyword = None
                for kw, pid in keywords.items():
                    if projects.get(pid, {}).get('path') == selected_project.get('path'):
                        found_keyword = kw
                        break
                if found_keyword:
                    sys.argv.append(found_keyword)
                else:
                    print("Error: Could not find a keyword to launch this project.")
                    sys.exit(1)
            else:
                print("Invalid selection.")
                sys.exit(1)
        except (KeyboardInterrupt, EOFError):
            print("\nOperation cancelled.")
            sys.exit(0)

    keyword = sys.argv[1].lower() # The first argument is the command/keyword

    # --- NEW: Install all packages command ---
    if keyword == 'install' and len(sys.argv) > 2 and sys.argv[2].lower() == 'pack':
        print("--- Installing all required packages for ST-Tools ---")
        # In a proper library, dependencies are handled by setup.py, but this is a good manual override.
        try:
            # We find the requirements file relative to this script's location inside the package
            req_path = os.path.join(os.path.dirname(__file__), '..', '..', 'requirements.txt')
            if not os.path.exists(req_path):
                 # Fallback for when installed in site-packages
                 req_path = os.path.join(os.path.dirname(__file__), 'requirements.txt')
            
            if not os.path.exists(req_path):
                 print("Could not locate requirements.txt. Installing manually...")
                 packages = ['requests', 'watchdog', 'ttkthemes', 'flask', 'Flask-SocketIO', 'python-socketio[client]']
                 subprocess.check_call([sys.executable, '-m', 'pip', 'install'] + packages)
            else:
                print("--> Updating pip...")
                subprocess.check_call([sys.executable, '-m', 'pip', 'install', '--upgrade', 'pip'])
                print("\n--> Installing packages from requirements.txt...")
                subprocess.check_call([sys.executable, '-m', 'pip', 'install', '-r', req_path])
            
            print("\n--- All packages installed successfully! ---")
        except subprocess.CalledProcessError:
            print(f"\n--- An error occurred during installation. ---")
            print("Please try running the command again in a terminal with administrator privileges.")
        except Exception as e:
            print(f"An unexpected error occurred: {e}")
        sys.exit(0)


    # --- Handle special commands ---
    if keyword == 'gui':
        try:
            # Simplified and robust GUI launcher. Always use python.exe to ensure errors are visible.
            gui_path = os.path.join(os.path.dirname(__file__), 'gui.py')
            subprocess.run([sys.executable, gui_path])
        except Exception as e:
            print(f"An error occurred while trying to launch the GUI: {e}")
        sys.exit(0)

    if keyword == 'gui:log':
        print("--- Starting GUI in Live Log Mode ---")
        try:
            gui_path = os.path.join(os.path.dirname(__file__), 'gui.py')
            process = subprocess.Popen(
                [sys.executable, gui_path],
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                encoding='utf-8',
                errors='replace'
            )
            # Stream output line by line
            for line in iter(process.stdout.readline, ''):
                print(line, end='')
            
            process.stdout.close()
            process.wait()
        except Exception as e:
            print(f"An error occurred while trying to launch the GUI logger: {e}")
        sys.exit(0)

    # --- NEW: Bridge command ---
    if keyword.startswith('bridge:'):
        action = keyword.split(':', 1)[1]
        if action == 'start':
            try:
                bridge_path = os.path.join(os.path.dirname(__file__), 'bridge.py')
                print("--- Starting the ST Local Listener in a new console... ---")
                # Use Popen to run in a new window/process without blocking
                subprocess.Popen([sys.executable, bridge_path], creationflags=subprocess.CREATE_NEW_CONSOLE)
            except Exception as e:
                print(f"An error occurred while trying to start the listener: {e}")
        elif action == 'how':
            # This should be moved to the GUI, but we keep it for now.
            print("Please use the GUI for setup instructions.")
        else:
            print(f"Unknown bridge command: '{action}'. Did you mean 'start'?")
        sys.exit(0)

    # --- NEW: Smart Watcher command ---
    if keyword == 'watch':
        if len(sys.argv) < 3:
            print("Usage: st watch <keyword> [--clear]")
            sys.exit(1)
        
        project_keyword = sys.argv[2].lower()
        clear_on_restart = '--clear' in sys.argv

        project_id = keywords.get(project_keyword)
        if not project_id or project_id not in projects:
            print(f"Error: Project with keyword '{project_keyword}' not found.")
            sys.exit(1)

        project_info = projects[project_id]
        script_path = project_info.get('path')
        if not script_path or not os.path.exists(script_path):
            print(f"Error: The script path for '{project_keyword}' is invalid.")
            sys.exit(1)

        try:
            from watchdog.observers import Observer
            from watchdog.events import FileSystemEventHandler
        except ImportError:
            print("Error: 'watchdog' library not found.")
            print("Please run 'st install pack' to install it.")
            sys.exit(1)

        class ChangeHandler(FileSystemEventHandler):
            def __init__(self, command, clear_screen=False):
                self.command = command
                self.clear_screen = clear_screen
                self.process = None
                self.start_process()

            def start_process(self):
                if self.clear_screen:
                    os.system('cls' if os.name == 'nt' else 'clear')
                print(f"--- [Watcher] Starting '{project_info.get('name', project_keyword)}'... ---")
                self.process = subprocess.Popen(self.command)

            def on_any_event(self, event):
                if event.is_directory or event.event_type not in ['modified', 'created', 'deleted']:
                    return
                print(f"\n--- [Watcher] Detected change in '{os.path.basename(event.src_path)}'. Restarting... ---")
                if self.process:
                    self.process.kill()
                    self.process.wait()
                self.start_process()

        watch_dir = os.path.dirname(script_path)
        command_to_run = [sys.executable, script_path] + [arg for arg in sys.argv[3:] if arg != '--clear']
        
        event_handler = ChangeHandler(command_to_run, clear_on_restart)
        observer = Observer()
        observer.schedule(event_handler, watch_dir, recursive=True)
        observer.start()
        print(f"--- Watching for file changes in '{watch_dir}'... (Press Ctrl+C to stop) ---")
        try:
            while True:
                time.sleep(1)
        except KeyboardInterrupt:
            observer.stop()
            if event_handler.process:
                event_handler.process.kill()
        observer.join()
        print("\n--- Watcher stopped. ---")
        sys.exit(0)

    if keyword.startswith("group:"):
        group_name = keyword.split(':', 1)[1]
        if not group_name:
            print("Error: Group name cannot be empty. Usage: st group:<group_name>")
            sys.exit(1)

        group_data = groups.get(group_name)
        if not group_data or not isinstance(group_data, dict):
            print(f"Error: Group '{group_name}' not found or is empty.")
            sys.exit(1)

        steps = group_data.get("steps", [])
        if not steps:
            print(f"Error: Group '{group_name}' has no steps defined.")
            sys.exit(1)

        for i, step in enumerate(steps):
            delay = step.get("delay", 0)
            proj_id = step.get("project_id")

            if delay > 0:
                print(f"  -> Waiting for {delay} second(s)...")
                time.sleep(delay)

            project_info = projects.get(proj_id)
            if not project_info or not project_info.get('path') or not os.path.exists(project_info.get('path')):
                print(f"  -> Warning: Skipping step {i+1}. Project '{project_info.get('name', proj_id)}' is misconfigured or deleted.")
                continue

            script_path = project_info['path']
            script_directory = os.path.dirname(script_path)
            print(f"  -> Step {i+1}: Starting '{project_info.get('name', proj_id)}'")
            subprocess.Popen([sys.executable, script_path], cwd=script_directory)
        sys.exit(0)

    # --- NEW: Plugin System Check ---
    # Try to match arguments to a plugin file
    args = sys.argv[1:]
    for i in range(len(args), 0, -1):
        # e.g., for "st git status --amend", it checks "git status --amend.py", then "git status.py", then "git.py"
        potential_cmd_parts = args[:i]
        potential_filename = " ".join(potential_cmd_parts) + ".py"
        plugin_path = os.path.join(plugin_dir, potential_filename)

        if os.path.isfile(plugin_path):
            remaining_args = args[i:]
            try:
                # Execute the plugin script, passing remaining arguments
                subprocess.Popen([sys.executable, plugin_path] + remaining_args, cwd=os.getcwd())
            except Exception as e:
                print(f"Error executing plugin '{potential_filename}': {e}")
            sys.exit(0)

    # If no plugin was found, continue to check for project keywords...


    # --- 3. Find and Run the Project ---
    project_id = keywords.get(keyword)

    if not project_id or project_id not in projects:
        print(f"Error: Keyword '{keyword}' not found or its project is not configured correctly.")
        print("Use 'st' to see available keywords or run the GUI to manage them.")
        sys.exit(1)

    project_info = projects[project_id]
    script_path = project_info.get('path')

    if not script_path or not os.path.exists(script_path):
        print(f"Error: The script path for '{keyword}' is invalid or does not exist:")
        print(f"  -> {script_path or 'Not specified'}")
        sys.exit(1)

    # --- 4. Execute the script ---
    try:
        script_directory = os.path.dirname(script_path)
        # print(f"--- Starting '{project_info.get('name', 'project')}' ---") # Suppressed output as requested
        # Use Popen to launch the script in a new process/window
        # Arguments after the keyword (e.g., st kitty --arg1)
        additional_args = [arg for arg in sys.argv[2:] if arg != '--clear']
        subprocess.Popen([sys.executable, script_path] + additional_args, cwd=script_directory)
    except Exception as e:
        print(f"An error occurred while trying to run the script: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()