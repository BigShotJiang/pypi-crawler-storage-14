from setuptools import setup, find_packages
import os

# Read the contents of your README file
this_directory = os.path.abspath(os.path.dirname(__file__))
with open(os.path.join(this_directory, 'README.md'), encoding='utf-8') as f:
    long_description = f.read()

setup(
    name='strt',  # The name of the package on PyPI
    version='1.0.0',
    author='hussain_syrer',
    author_email='h2311065@gmail.com',
    description='A versatile tool for managing and running local and cloud projects.',
    long_description=long_description,
    long_description_content_type='text/markdown',
    packages=find_packages(),
    include_package_data=True, # To include non-python files like config.json
    install_requires=[
        'requests', 'watchdog', 'ttkthemes', 'flask', 
        'Flask-SocketIO', 'python-socketio[client]'
    ],
    entry_points={
        'console_scripts': [
            'st = st_tool.cli:main',  # This creates the 'st' command
        ],
    },
)
