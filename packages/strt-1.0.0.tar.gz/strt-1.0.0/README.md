# ST-Tool

A versatile tool for managing and running local and cloud projects, with a powerful remote execution bridge.

Full documentation will be here.