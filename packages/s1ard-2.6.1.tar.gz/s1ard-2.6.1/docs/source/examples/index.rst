Examples
========

.. toctree::
   :maxdepth: 1

   nrb_cube.ipynb
