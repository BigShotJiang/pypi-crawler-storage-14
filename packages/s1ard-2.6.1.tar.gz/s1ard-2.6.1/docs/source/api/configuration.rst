Configuration
-------------

.. automodule:: s1ard.config
    :members:
    :undoc-members:
    :show-inheritance:

    .. autosummary::
        :nosignatures:

        gdal_conf
        get_config
        get_keys
        init
        read_config_file
        write