from .TSeriesClass import *

__version__ = '0.0.1.'
__author__ = 'Marzio Di Vece (marzio.divece@sns.it), Emanuele Agrimi (emanuele.agrimi@imtlucca.it), Samuele Tatullo (samuele.tatullo@imtlucca.it)'
