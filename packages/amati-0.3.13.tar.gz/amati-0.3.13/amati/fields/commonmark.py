"""
Convenience type so I can implement CommonMark validation later if it ever
feels necessary.

https://github.com/executablebooks/markdown-it-py looks to be the main
Python CommonMark parser
"""

type CommonMark = str
