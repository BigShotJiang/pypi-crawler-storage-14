# -*- coding: utf-8 -*-
"""NREL Turbine Models."""
from .parser import Turbines

__version__ = "0.2.0"