Installation
============

You can install ``czml3`` using ``pip``::

   pip install czml3

or ``conda``::

   conda install czml3 --channel conda-forge