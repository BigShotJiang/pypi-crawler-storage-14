User Manual
===========

.. toctree::

   installation
   features
   examples
   contributing