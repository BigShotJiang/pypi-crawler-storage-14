import pytest
import asyncio
import sys
import os

# Add src to path
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from src.moa.core.phi_safe_evaluator import PHISafeEvaluator, extract_regulatory_refs
from src.moa.integrations.mcp_client import RegulatoryMCPClient

@pytest.mark.asyncio
async def test_end_to_end_evaluation():
    """Test full MCP-enhanced evaluation pipeline."""
    
    # Initialize without API key (will fallback gracefully)
    client = RegulatoryMCPClient(api_key=None)
    evaluator = PHISafeEvaluator(client)
    
    test_text = """
    Patient consents to telehealth visit. CPT 99213 billed for consultation.
    Understands privacy risks per HIPAA protections. California AB-688 telehealth
    consent requirements followed. 42 CFR 410.78 telehealth regulations apply.
    Patient has right to refuse and may opt-out at any time.
    Technical limitations and risks of service interruption explained.
    """
    
    result = await evaluator.evaluate(test_text)
    
    # Assertions on structure
    assert "quality_score" in result
    assert 0.0 <= result["quality_score"] <= 1.0
    assert "billing_score" in result
    assert "static_rules_score" in result
    assert "vector_score" in result
    assert "refs" in result
    
    # Check extracted references
    assert "99213" in result["refs"]["billing_codes"]
    assert any("AB" in bill for bill in result["refs"]["bills"])
    assert any("CFR" in ref for ref in result["refs"]["cfr_refs"])
    
    # Static rules should pass most checks for this well-formed text
    assert result["static_rules_score"] >= 0.8
    
    print(f"✓ End-to-end test passed. Quality score: {result['quality_score']:.2f}")


@pytest.mark.asyncio
async def test_phi_safe_extraction():
    """Verify no PHI is sent to MCP."""
    
    text_with_phi = """
    Patient John Doe (SSN: 123-45-6789) seen on 01/15/2025.
    Phone: (555) 123-4567. Email: john@example.com.
    CPT 99213 for telehealth. AB-688 consent obtained.
    42 CFR 410.78 followed.
    """
    
    refs = extract_regulatory_refs(text_with_phi)
    
    # Should extract codes but NOT PHI
    assert "99213" in refs["billing_codes"]
    assert any("AB" in bill for bill in refs["bills"])
    assert any("CFR" in ref for ref in refs["cfr_refs"])
    
    # Verify no SSN, phone, or names extracted
    all_refs_str = str(refs)
    assert "123-45-6789" not in all_refs_str
    assert "555" not in all_refs_str
    assert "John Doe" not in all_refs_str
    assert "@example.com" not in all_refs_str
    
    print("✓ PHI safety test passed. No sensitive data in extracted references.")


@pytest.mark.asyncio
async def test_static_rules_scoring():
    """Test static rules scoring logic."""
    
    client = RegulatoryMCPClient(api_key=None)
    evaluator = PHISafeEvaluator(client)
    
    # Good consent text (should score high)
    good_text = """
    Patient consents to telehealth services. Risks and limitations explained.
    HIPAA privacy protections apply. Patient has right to refuse and request
    in-person visit. May opt-out at any time.
    """
    
    # Poor consent text (should score low)
    poor_text = "Visit completed."
    
    good_score = evaluator._static_rules_score(good_text, None)
    poor_score = evaluator._static_rules_score(poor_text, None)
    
    assert good_score > poor_score
    assert good_score >= 0.8  # Should pass most rules
    assert poor_score <= 0.4  # Should fail most rules
    
    print(f"✓ Static rules test passed. Good: {good_score:.2f}, Poor: {poor_score:.2f}")


def test_regulatory_refs_extraction():
    """Test regex extraction of billing codes, bills, and CFR refs."""
    
    text = """
    CPT codes: 99213, 99214, G0425
    Bills: AB-688, SB-221, HR-1234
    Regulations: 42 CFR 410.78, 45 CFR 164.500
    """
    
    refs = extract_regulatory_refs(text)
    
    # Check billing codes
    assert "99213" in refs["billing_codes"]
    assert "99214" in refs["billing_codes"]
    assert "G0425" in refs["billing_codes"]
    
    # Check bills
    assert any("AB" in bill and "688" in bill for bill in refs["bills"])
    assert any("SB" in bill and "221" in bill for bill in refs["bills"])
    
    # Check CFR refs
    assert any("42" in ref and "410.78" in ref for ref in refs["cfr_refs"])
    assert any("45" in ref and "164.500" in ref for ref in refs["cfr_refs"])
    
    print("✓ Regex extraction test passed.")


@pytest.mark.asyncio
async def test_graceful_degradation():
    """Test system behavior when MCP services unavailable."""
    
    # Initialize with invalid API key
    client = RegulatoryMCPClient(api_key="invalid_key_for_testing")
    evaluator = PHISafeEvaluator(client)
    
    test_text = "Patient consents. CPT 99213. AB-688 followed."
    
    # Should not raise exception, should return results with fallback scores
    result = await evaluator.evaluate(test_text)
    
    assert "quality_score" in result
    assert result["quality_score"] > 0  # Should have some score from static/vector
    
    # Billing score should fallback to neutral 0.5 when API unavailable
    # (since no results returned)
    assert "billing_score" in result
    
    print("✓ Graceful degradation test passed.")


if __name__ == "__main__":
    # Run tests manually
    print("\n=== Running MCP Integration Tests ===\n")
    
    asyncio.run(test_end_to_end_evaluation())
    asyncio.run(test_phi_safe_extraction())
    asyncio.run(test_static_rules_scoring())
    test_regulatory_refs_extraction()
    asyncio.run(test_graceful_degradation())
    
    print("\n✓ All tests passed!\n")
