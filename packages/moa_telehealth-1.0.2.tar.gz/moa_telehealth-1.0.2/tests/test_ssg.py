import pytest
import numpy as np
from moa.core.ssg import compute_ssg_fingerprint, encode_text_to_symbols

def test_ssg_latin_basic():
    """Test standard Latin text fingerprinting."""
    text = "Hello World"
    fp = compute_ssg_fingerprint(text)
    assert isinstance(fp, np.ndarray)
    assert len(fp) > 0
    # Basic check: shouldn't be all zeros for valid text
    assert np.any(fp != 0)

def test_ssg_cyrillic_safety():
    """Test that Cyrillic text doesn't crash and produces a valid fingerprint."""
    text = "Привет мир"  # "Hello World" in Russian
    
    # Should not raise exception
    fp = compute_ssg_fingerprint(text)
    
    assert isinstance(fp, np.ndarray)
    # Since Cyrillic maps to OTHER (27), we expect a fingerprint
    # It might be low-information but must be valid float array
    assert fp.dtype == float
    assert not np.any(np.isnan(fp))

def test_ssg_mixed_script():
    """Test mixed Latin and Cyrillic text."""
    text = "Hello Привет"
    fp = compute_ssg_fingerprint(text)
    assert isinstance(fp, np.ndarray)
    assert not np.any(np.isnan(fp))

def test_ssg_normalization():
    """Test NFKC normalization."""
    # Full-width "A" (U+FF21) should normalize to "A" and map to index 1
    text = "\uff21" 
    symbols = encode_text_to_symbols(text)
    assert symbols[0] == 1  # 'a' is 1

def test_ssg_empty_input():
    """Test empty string handling."""
    fp = compute_ssg_fingerprint("")
    assert isinstance(fp, np.ndarray)
    # Should be all zeros or valid empty state representation
    assert len(fp) > 0
