import pytest
from unittest.mock import MagicMock
from langchain_core.documents import Document
from moa.integrations.langchain_moa_filter import MOAFilterRunnable

class MockEmbeddings:
    def embed_documents(self, texts):
        # Return dummy embeddings based on text length to simulate variety
        return [[len(t) * 0.1] * 3 for t in texts]
    
    def embed_query(self, text):
        return [len(text) * 0.1] * 3

def test_moa_filter_runnable():
    # Setup
    embeddings = MockEmbeddings()
    exemplars = ["good content", "compliant text"]
    
    # Rule: Text must contain "safe"
    def rule_safe(text):
        return "safe" in text
    
    filter_runnable = MOAFilterRunnable(
        embeddings=embeddings,
        exemplars=exemplars,
        rules=[rule_safe],
        alpha=0.5, # Equal weight to rules and vectors
        threshold=0.5
    )
    
    # Test Data
    docs = [
        Document(page_content="safe and sound"), # Should pass (Rule=1, Vector=High)
        Document(page_content="dangerous"),      # Should fail (Rule=0, Vector=Low)
        Document(page_content="safe but weird"), # Should pass (Rule=1)
    ]
    
    # Execute
    filtered_docs = filter_runnable.invoke(docs)
    
    # Verify
    assert len(filtered_docs) >= 1
    assert filtered_docs[0].page_content == "safe and sound"
    
    # Check metadata
    assert 'moa_score' in filtered_docs[0].metadata
    assert filtered_docs[0].metadata['moa_rule_score'] == 1.0

if __name__ == "__main__":
    test_moa_filter_runnable()
    print("Test passed!")
