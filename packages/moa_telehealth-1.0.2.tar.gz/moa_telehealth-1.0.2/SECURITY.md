# Security & Responsible Use

## Supported Versions

Security fixes are provided for the main branch and for tagged releases v1.0 and higher.

---

## Reporting Vulnerabilities

Please report suspected vulnerabilities privately to: **<security@moa-telehealth.com>**  
Subject line: `MOA Security Issue`

Do **not** open public GitHub issues for sensitive security reports. A PGP key can be provided on request.

Include:

- Description of the issue and its impact
- Steps to reproduce
- Affected component (e.g., MCP server, LangChain integration, core library)

Do **not** include:

- Protected health information (PHI)
- Real patient names, MRNs, or clinic identifiers
- Live API keys, passwords, or production connection strings

---

## Responsible Use

- Magnetic Outlier Agent (MOA) is designed for RAG and telehealth compliance auditing, such as consent outlier detection via MCP or similar integration layers.
- **Protected health information (PHI) must be sanitized before being sent to MOA pipelines.** For example, use helper functions (such as `_contains_phi` in `regulatory_gateway.py`) to block PHI from logs and long-term storage.
- The software **must not be used for surveillance or profiling of individuals.** Users remain responsible for complying with HIPAA, GDPR, and local privacy regulations.
- Users deploying MOA in production environments must conduct their own security assessments and penetration testing.

---

## Key and Secret Handling

- API keys (e.g., Stripe, OpenAI, Gemini, OpenStates) **must** be stored only in environment files (such as `.env`) or secure secret managers.
- API keys **must never be committed** to version control.
- If a secret is ever committed, it **must be revoked immediately** in the provider dashboard and replaced with a new key.
- The `.env` file is excluded from git via `.gitignore`. If you find a key in git history, report it immediately as a security issue.

---

## PHI Handling Guidelines

MOA operates on vector embeddings and structured metadata, **not raw clinical notes**.

**Rules for PHI**:

1. **Never** pass raw clinical notes or patient names to any MOA function
2. **Always** use the built-in PHI guard (`_contains_phi`) before calling external APIs
3. **Sanitize** all text inputs: remove names, SSNs, MRNs, DOBs, phone numbers
4. **Audit logs** should not contain PHI; use pseudonymized identifiers

**Example (CORRECT)**:

```python
# ✅ Pass sanitized code only
mcp.lookup_billing_code("icd10", "F33.1")
```

**Example (INCORRECT)**:

```python
# ❌ Never pass patient names or raw notes
mcp.lookup_billing_code("icd10", "John Doe depression")  # PHI DETECTED error
```

---

## HIPAA and Compliance

If you deploy MOA in a HIPAA-covered environment:

1. **Business Associate Agreement (BAA)**: Third-party services (OpenAI, Anthropic, etc.) must have BAAs in place
2. **Minimum Necessary**: Only send the minimum data required for outlier detection
3. **Audit Trails**: Log all API calls with timestamps and user IDs
4. **Encryption**: Use TLS for all network traffic; encrypt embeddings at rest
5. **Access Controls**: Restrict MOA deployment to authorized clinical/IT staff

**MOA does not provide built-in HIPAA compliance.** It is a tool; you must configure your environment appropriately.

---

## Scope

Security reports are welcome for:

- Core MOA library (`src/moa/`)
- MCP server (`regulatory_mcp_server.py`)
- LangChain integration (`moa/integrations/langchain_moa_filter.py`)
- FastAPI endpoint (`regulatory_api.py`)
- Example applications

**Out of scope**:

- Third-party services (OpenAI, OpenStates, NLM, etc.)
- Downstream deployments modified beyond documented configuration
- Issues caused by deliberate misuse contrary to documentation

---

## Response Process

When a report is received:

1. **Acknowledgment** (within 48 hours)
2. **Triage** (severity assessment, affected components)
3. **Remediation** (fix development and testing)
4. **Disclosure** (patch release and brief advisory)

Good-faith reports respecting this policy will not result in legal action against the reporter.

---

## License & Patent

This software is licensed under the **Business Source License 1.1** and is protected by **U.S. Provisional Patent Application Serial No. 63/926,578**.

- Commercial/SaaS use before the change date (Nov 27, 2029) requires a license
- See [LICENSE](./LICENSE) and [PATENT_PENDING.md](./PATENT_PENDING.md)

---

Thank you for helping keep MOA secure.

© 2025 Michael Ordon. Patent Pending. All Rights Reserved.
