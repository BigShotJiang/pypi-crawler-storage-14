# Magnetic Outlier Agent (MOA)

**Patent Pending** • U.S. Provisional Serial No. 63/926,578 filed November 27, 2025  
**License** • Business Source License 1.1 (Change Date: November 27, 2029)  
**Trademarks Pending** • "Magnetic Outlier Agent" and "MOA"

---

## Overview

MOA is a geometric multi-metric outlier detection system for embedding vectors in Retrieval-Augmented Generation (RAG) pipelines. It uses a patented triple-metric approach combining centroid distance, local density, and graph curvature to identify low-quality or non-compliant documents before they reach your LLM.

**Use cases**:

- RAG quality filtering (remove hallucination-prone chunks)
- Telehealth compliance auditing (detect missing consent/risks language)
- Regulatory integration via MCP (ICD-10, CPT billing, state bills)

---

## Quick Start

```bash
pip install moa-telehealth
```

### Basic Usage

```python
from moa.filters import MOAOutlierFilter

# Initialize filter
moa = MOAOutlierFilter(threshold=1.5)

# Score documents
embeddings = [[0.1, 0.2, ...], ...]  # Your doc embeddings
scores, outliers = moa.score(embeddings)

# Filter out outliers
clean_docs = [doc for i, doc in enumerate(docs) if i not in outliers]
```

### LangChain Integration

```python
from langchain_community.embeddings import HuggingFaceEmbeddings
from moa.integrations.langchain import MOAOutlierFilter

# Initialize filter
embeddings = HuggingFaceEmbeddings(model_name="all-MiniLM-L6-v2")
filter = MOAOutlierFilter(embedding_model=embeddings, threshold=1.5)

# Filter documents in RAG pipeline
filtered_docs = filter.transform_documents(retrieved_docs)
```

### FastAPI Server (MCP)

Start the Model Context Protocol server:

```bash
python moa_mcp_server.py
```

API endpoints:

- `GET /health` - Health check
- `POST /audit` - Outlier detection (accepts text chunks)
- `POST /api/generate` - Gemini proxy

---

## IP & Security Status

- **Patent**: U.S. Provisional 63/926,578 (filed Nov 27, 2025) – See [PATENT_PENDING.md](./PATENT_PENDING.md)
- **License**: BUSL 1.1 (change date: 2029-11-27) – See [LICENSE](./LICENSE)
- **PyPI**: [moa-telehealth 1.0.0](https://pypi.org/project/moa-telehealth/1.0.0/) live
- **MCP Layer 3**: Regulatory integration complete – See [docs/REGULATORY_MCP_INTEGRATION.md](./docs/REGULATORY_MCP_INTEGRATION.md)
- **Security**: PHI handling & key management policies – See [SECURITY.md](./SECURITY.md)
- **Trademarks**: Filing in progress (deadline: Dec 4, 2025)

---

## Documentation

- **[Regulatory MCP Integration](./docs/REGULATORY_MCP_INTEGRATION.md)** - Free gov/insurance API integration
- **[Deployment Summary](./docs/DEPLOYMENT_SUMMARY.md)** - Production deployment guide
- **[Patent Pending](./PATENT_PENDING.md)** - Algorithm claims and scope
- **[Security](./SECURITY.md)** - Vulnerability reporting and responsible use

---

## Features

### Core Algorithm (Patent Pending)

- **Triple-metric scorer**: Combines centroid distance (d), local density (δ), and graph curvature (κ)
- **Bridge-path detection**: Identifies weak links in k-NN graphs
- **Spectral degradation**: Fourier analysis for time-ordered corpora

### Integrations

- ✅ **LangChain** - Drop-in RAG filter
- ✅ **MCP** - Claude Desktop tools for regulatory lookups
- ✅ **FastAPI** - RESTful endpoints for web/n8n
- ✅ **Streamlit** - Interactive compliance editor

### Regulatory Layer (MCP)

- **ICD-10 lookup** (NLM Clinical Tables) - Free, 1000/day
- **CPT billing** (eCFR §410.78) - Free, unlimited
- **State bills** (OpenStates) - Free, 5000/day (API key required)
- **PHI guard** - Automatic blocking of SSN/phone/names

### Known Limitations (v1.0.x)

- **Multilingual Support**: Optimized for English/Latin scripts. Non-Latin scripts (Cyrillic, CJK) are safely handled via a fallback bucket but have reduced sensitivity. Full multilingual support is scheduled for v1.1.

---

## License

**Business Source License 1.1**  
© 2025 Michael Ordon. Patent Pending U.S. Provisional 63/926,578. All Rights Reserved.

- **Permitted**: Evaluation, research, internal use (≤100 visits/month)
- **Restricted**: Commercial SaaS offerings before change date (2029-11-27)
- **Change License**: Apache 2.0 (after Nov 27, 2029)

For commercial licensing: <licensing@moa-telehealth.com>

---

## Citation

If you use MOA in research, please cite:

```bibtex
@misc{ordon2025moa,
  title={Magnetic Outlier Agent: Geometric Multi-Metric Outlier Detection for RAG Systems},
  author={Ordon, Michael},
  year={2025},
  note={U.S. Provisional Patent Application Serial No. 63/926,578}
}
```

---

## Contact

**Inventor**: Michael Ordon (Culver City, CA)  
**Email**: <contact@moa-telehealth.com>  
**Patent**: U.S. Provisional 63/926,578  
**License**: BUSL 1.1  
**Links**: [PyPI](https://pypi.org/project/moa-telehealth/) | [Patent Center](https://patentcenter.uspto.gov)
