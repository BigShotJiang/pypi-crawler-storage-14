# Patent Pending

U.S. Provisional Patent Application Serial No. 63/926,578 filed November 27, 2025  
Title: Geometric Multi-Metric Outlier Detection with Bridge-Path Curvature and Spectral Degradation Analysis for Embedding Vectors in Retrieval-Augmented Generation Systems

All core algorithms in this repository — including the triple-metric composite scorer (centroid distance + local density + graph curvature/clustering coefficient), bridge-path curvature proxy in k-NN graphs, and Fourier log-spectrum slope for sequential degradation in time-ordered corpora — are covered by pending patent claims.

Application to retrieval-augmented generation (RAG) and telehealth compliance includes:

- Filtering retrieval candidates before LLM context assembly
- Enriching metadata (e.g., `moa_score`, `moa_is_outlier`) in post-retrieval pipelines
- Integrating with regulatory/messaging gateways (e.g., MCP integration) for compliance auditing

Commercial deployment as a hosted service (SaaS), EHR integration, or on-premise use requires an enterprise license.

© 2025 Michael Ordon. Patent Pending. All Rights Reserved.
