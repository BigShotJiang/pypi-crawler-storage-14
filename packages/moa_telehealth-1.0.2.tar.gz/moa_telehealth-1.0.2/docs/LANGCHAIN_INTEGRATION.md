# MOA LangChain Integration Guide

This guide explains how to integrate MOA's outlier detection into your LangChain RAG pipelines.

## Overview

MOA provides **two complementary approaches** for filtering documents in RAG chains:

### 1. `MOAOutlierFilter` - Geometric Outlier Detection

**Best for:** Vector similarity-based filtering  
**Use when:** You want to remove off-topic or low-quality chunks based on embedding geometry

Uses MOA's core geometric algorithm (patent pending) to detect outliers in embedding space using three metrics:

- **d** (distance): Local density divergence
- **δ** (delta): Nearest-neighbor distance
- **κ** (kappa): Curvature in manifold space

```python
from moa.integrations.langchain import MOAOutlierFilter
from langchain_openai import OpenAIEmbeddings

embeddings = OpenAIEmbeddings(model="text-embedding-3-small")

# Initialize filter
moa_filter = MOAOutlierFilter(
    embedding_model=embeddings,
    k=15,               # Number of neighbors for density calculation
    threshold=1.5,      # Outlier threshold (std devs above mean)
    add_metadata=True   # Add MOA scores to document metadata
)

# Filter documents
filtered_docs = moa_filter.transform_documents(retrieved_docs)
```

### 2. `MOAFilterRunnable` - Neuro-Symbolic Filtering

**Best for:** Compliance and quality filtering with explicit rules  
**Use when:** You need both semantic similarity AND rule-based validation (e.g., PHI detection, length checks)

Combines deterministic rules with vector similarity to exemplars:

```text
score = α × rule_score + (1 - α) × vector_score
```

```python
from moa.integrations.langchain_moa_filter import MOAFilterRunnable, DEFAULT_RULES
from langchain_openai import OpenAIEmbeddings

embeddings = OpenAIEmbeddings(model="text-embedding-3-small")

# Define custom rules
def rule_no_phi(text: str) -> bool:
    """Block documents containing PHI patterns"""
    phi_patterns = ["SSN", "DOB:", "Patient ID:"]
    return not any(pattern in text for pattern in phi_patterns)

def rule_min_quality(text: str) -> bool:
    """Ensure minimum content quality"""
    return len(text) > 50 and text.count('.') >= 2

# Initialize neuro-symbolic filter
moa_filter = MOAFilterRunnable(
    embeddings=embeddings,
    exemplars=[
        "High-quality medical documentation with proper terminology.",
        "Detailed clinical assessment following standard protocols."
    ],
    rules=[rule_no_phi, rule_min_quality],
    alpha=0.6,         # 60% weight on rules, 40% on vector similarity
    threshold=0.8      # Minimum combined score to keep document
)

# Use in LangChain pipeline
filtered_docs = moa_filter.invoke(retrieved_docs)
```

## Installation

```bash
# Core MOA package
pip install moa-telehealth

# LangChain dependencies
pip install langchain langchain-core langchain-openai

# Optional: For demos with FAISS
pip install langchain-community faiss-cpu sentence-transformers
```

## Complete RAG Pipeline Example

Here's a full example integrating MOA into a LangChain RAG chain:

```python
import os
from dotenv import load_dotenv

load_dotenv()

from langchain_openai import ChatOpenAI, OpenAIEmbeddings
from langchain_community.vectorstores import Chroma
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.documents import Document
from langchain_core.runnables import RunnablePassthrough, RunnableLambda

from moa.integrations.langchain import MOAOutlierFilter, MOAFilterRunnable

# 1. Setup embeddings & vectorstore
embeddings = OpenAIEmbeddings(model="text-embedding-3-small")

docs = [
    Document(page_content="Telehealth consent requires discussion of risks.", metadata={"source": "guideline"}),
    Document(page_content="Billing code 99213 for established patient visit.", metadata={"source": "cpt"}),
    # ... more documents
]

vectorstore = Chroma.from_documents(docs, embeddings)
retriever = vectorstore.as_retriever(search_kwargs={"k": 10})

# 2. Setup MOA filter
moa_filter = MOAOutlierFilter(
    embedding_model=embeddings,
    threshold=1.5,
    k=15
)
moa_runnable = MOAFilterRunnable(moa_filter)

# 3. Build RAG chain with MOA filtering
def format_docs(docs):
    return "\n\n".join([f"[{i}] {doc.page_content}" for i, doc in enumerate(docs)])

def apply_moa(state):
    """Apply MOA filter to retrieved documents"""
    docs = state["docs"]
    filtered = moa_runnable.invoke(docs)
    print(f"MOA filtered {len(docs)} → {len(filtered)} docs")
    return {"docs": filtered, "question": state["question"]}

def build_prompt(state):
    context = format_docs(state["docs"])
    return {"context": context, "question": state["question"]}

prompt = ChatPromptTemplate.from_messages([
    ("system", "You are a helpful assistant. Use only the provided context."),
    ("human", "Context: {context}\n\nQuestion: {question}\nAnswer:")
])

llm = ChatOpenAI(model="gpt-4o-mini", temperature=0)

# Chain: Retrieve → Filter with MOA → Generate
chain = (
    RunnablePassthrough.assign(docs=lambda x: retriever.get_relevant_documents(x["question"]))
    | RunnableLambda(apply_moa)
    | RunnableLambda(build_prompt)
    | prompt
    | llm
)

# 4. Query
response = chain.invoke({"question": "What is required for telehealth consent?"})
print(response.content)
```

## Method Reference

### `MOAOutlierFilter`

#### Constructor Parameters

- `embedding_model: Embeddings` - LangChain Embeddings instance
- `k: int = 15` - Number of neighbors for local density calculation
- `threshold: float = 1.5` - Outlier threshold in standard deviations
- `keep_outliers: bool = False` - If True, keeps only outliers (inverse mode)
- `add_metadata: bool = True` - Whether to add MOA scores to document metadata

#### Methods

**`transform_documents(documents: List[Document]) -> List[Document]`**

- Filters documents by removing/keeping outliers
- Returns filtered list

**`score_documents(documents: List[Document]) -> Tuple[List[Document], np.ndarray, np.ndarray]`**

- Scores documents without filtering
- Returns: (documents with metadata, scores array, outlier mask)

**`atransform_documents(documents: List[Document]) -> List[Document]`**

- Async version of transform_documents

### `MOAFilterRunnable`

#### MOAFilterRunnable Parameters

- `embeddings: Embeddings` - LangChain Embeddings instance
- `exemplars: List[str]` - Example texts representing "good" documents
- `rules: List[Callable[[str], bool]]` - List of validation functions
- `threshold: float = 0.8` - Minimum combined score to keep document
- `alpha: float = 0.6` - Weight for rule score (1-alpha for vector score)

#### MOAFilterRunnable Methods

**`invoke(input: List[Document], config=None) -> List[Document]`**

- Filters documents using neuro-symbolic scoring
- Adds metadata: `moa_score`, `moa_rule_score`, `moa_vector_score`

## Demo Scripts

### 1. FAISS Vector Store Demo

Run the complete demo with FAISS:

```bash
python examples/langchain_rag_filter_demo.py
```

This demonstrates:

- Creating a medical document corpus
- Indexing in FAISS
- Detecting and removing a recipe "outlier" from medical docs

### 2. Integration Test

Verify the integration works:

```bash
python tests/verify_langchain_moa.py
```

### 3. Neuro-Symbolic Filter Test

Test rule-based filtering:

```bash
python tests/test_langchain_integration.py
```

## Performance Tuning

### Threshold Selection

- **Strict filtering (fewer docs):** `threshold = 1.0 - 1.2`
- **Standard (balanced):** `threshold = 1.5` (recommended)
- **Lenient (more docs):** `threshold = 2.0 - 2.5`

### K-Neighbors Selection

- **Small datasets (<100 docs):** `k = 5`
- **Medium datasets (100-1000 docs):** `k = 15` (recommended)
- **Large datasets (>1000 docs):** `k = 30-50`

### Alpha Tuning (Neuro-Symbolic)

- **Rule-heavy:** `alpha = 0.8` (80% rules, 20% vectors)
- **Balanced:** `alpha = 0.6` (default)
- **Vector-heavy:** `alpha = 0.4` (40% rules, 60% vectors)

## Common Use Cases

### 1. Healthcare RAG - Remove Off-Topic Chunks

```python
filter = MOAOutlierFilter(embedding_model=embeddings, threshold=1.5)
clean_docs = filter.transform_documents(retrieved_medical_docs)
```

### 2. Compliance Filtering - Block PHI

```python
from moa import DEFAULT_RULES, MOAFilterRunnable

filter = MOAFilterRunnable(
    embeddings=embeddings,
    exemplars=["Compliant medical documentation"],
    rules=DEFAULT_RULES,  # Includes PHI detection
    threshold=0.9
)
safe_docs = filter.invoke(retrieved_docs)
```

### 3. Quality Gate - Ensure Semantic Coherence

```python
# Invert mode: Find outliers for manual review
filter = MOAOutlierFilter(
    embedding_model=embeddings,
    threshold=1.2,
    keep_outliers=True  # Keep only outliers
)
suspicious_docs = filter.transform_documents(ingestion_batch)
```

## Metadata Added to Documents

Both filters add metadata to each document:

**MOAOutlierFilter:**

```python
{
    "moa_score": 0.234,        # Outlier score (higher = more outlier-like)
    "moa_is_outlier": False    # Boolean outlier flag
}
```

**MOAFilterRunnable:**

```python
{
    "moa_score": 0.85,          # Combined quality score
    "moa_rule_score": 1.0,      # Rules passing rate (0-1)
    "moa_vector_score": 0.72    # Vector similarity to exemplars
}
```

## Troubleshooting

### Import Errors

If you see `ModuleNotFoundError: No module named 'langchain'`:

```bash
pip install langchain langchain-core
```

### No Filtering Happening

- Lower the threshold: `threshold=1.0`
- Check metadata to see actual scores
- Ensure you have enough documents (minimum 3-5)

### All Documents Filtered Out

- Raise the threshold: `threshold=2.0`
- Check if your documents are actually similar
- Verify embeddings are working correctly

## Citation

If you use MOA's LangChain integration in research:

```bibtex
@software{moa2025,
  title={MOA: Magnetic Outlier Agent for RAG Systems},
  author={Ordon, Michael},
  year={2025},
  note={Patent Pending U.S. Provisional 63/926,578},
  url={https://github.com/grzywajk-beep/moa_v1}
}
```

## License

Business Source License 1.1 (BUSL-1.1)  
Change Date: 2029-11-27  
© 2025 Michael Ordon. All Rights Reserved.

## Support

- **Issues:** [GitHub Issues](https://github.com/grzywajk-beep/moa_v1/issues)
- **Email:** <contact@moa-telehealth.com>
- **Docs:** [Full Documentation](https://github.com/grzywajk-beep/moa_v1)

---

**Patent Pending:** U.S. Provisional Patent Application No. 63/926,578 filed November 27, 2025
