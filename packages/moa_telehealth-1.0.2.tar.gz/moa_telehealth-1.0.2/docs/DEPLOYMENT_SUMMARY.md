# MOA Telehealth Deployment Guide

This repository contains two distinct components:
1.  **MOA v1 (Backend/CLI)**: Python-based outlier detection for batch processing.
2.  **Mike's Way (Frontend)**: React-based real-time compliance editor.

## 1. MOA v1 (CLI & API)

### Installation
```bash
# Install as a Python package
pip install -e .
```

### CLI Usage
Run geometric outlier detection on a CSV file:
```bash
moa detect --input data/visits.csv --output report.json --threshold 1.5
```

### API Usage (Docker)
Build and run the API server:
```bash
docker build -t moa-api .
docker run -p 8000:8000 moa-api
```
Test the endpoint:
```bash
curl http://localhost:8000/health
```

---

## 2. Mike's Way Editor (Web App)

Located in `apps/mikes-way`.

### Local Development
```bash
cd apps/mikes-way
npm install
npm run dev
```

### Production Build
```bash
npm run build
# Output is in apps/mikes-way/dist
```

### Deploy to Vercel
1.  Install Vercel CLI: `npm i -g vercel`
2.  Run `vercel` inside `apps/mikes-way`.
3.  Set `GEMINI_API_KEY` in Vercel project settings.

### Deploy with Docker
```bash
cd apps/mikes-way
docker build -t mikes-way-app .
docker run -p 3000:80 mikes-way-app
```
