# Regulatory MCP Integration Guide

## Overview

**MOA Layer 3** provides PHI-safe regulatory and billing code lookups via free government APIs, fully integrated with the Magnetic Outlier Agent's compliance evaluation system.

**Status**: ✅ Production-ready (Patent Pending U.S. Provisional 63/926,578)

---

## Architecture

```text
┌─────────────────────────────────────────────────────────────┐
│                    MOA Intelligence Stack                    │
├─────────────────────────────────────────────────────────────┤
│  Layer 1: Math Core (d-δ-κ outlier detection)               │
│  Layer 2: RAG Filter (LangChain integration)                │
│  Layer 3: Regulatory MCP ← YOU ARE HERE                     │
└─────────────────────────────────────────────────────────────┘
```

### Components

1. **`regulatory_gateway.py`** - Core gateway wrapping free gov/insurance APIs
2. **`regulatory_mcp_server.py`** - MCP server for Claude Desktop integration  
3. **`regulatory_api.py`** - FastAPI endpoint for web/n8n integration
4. **`mcp_moa_rag.py`** - LangChain RAG integration example

---

## Free API Data Sources

| API | Purpose | Rate Limit | Auth Required |
|-----|---------|------------|---------------|
| **NLM Clinical Tables** | ICD-10 code lookup | 1000/day | No |
| **eCFR API** | CPT billing regulations (42 CFR §410.78) | Unlimited | No |
| **OpenStates v3** | State telehealth bill tracking | 5000/day | Free API key |
| **CMS Blue Button 2.0** | Medicaid eligibility (FHIR) | Unlimited | OAuth token |

---

## Quick Start

### 1. Install Dependencies

```bash
.\venv_clean\Scripts\activate
pip install mcp requests python-dotenv fastapi uvicorn langchain langchain-openai
```

### 2. Set Environment Variables

Create or update `.env` (already gitignored):

```env
# Optional: Required only for OpenStates bill tracking
OPENSTATES_API_KEY=your_key_here

# Optional: Required only for CMS Blue Button
CMS_OAUTH_TOKEN=your_token_here

# Required for LangChain RAG integration
OPENAI_API_KEY=your_openai_key
```

**Get a free OpenStates key**: <https://openstates.org/api/register/>

### 3. Test the Gateway

```bash
python src\moa\core\regulatory_gateway.py
```

**Expected output**:

```json
{
  "code_type": "icd10",
  "code": "F33.1",
  "description": "Major depressive disorder, recurrent, moderate",
  "source": "NLM Clinical Tables"
}
```

---

## Usage

### A. MCP Server (for Claude Desktop)

**Start the server**:

```bash
python regulatory_mcp_server.py
```

**From Claude Desktop**:

```text
@regulatory-mcp lookup_billing_code code_type="icd10" code="F33.1"
@regulatory-mcp check_state_bill_status state="ca" bill_query="telehealth consent"
```

### B. FastAPI Endpoint (for web/n8n)

**Start the server**:

```bash
python regulatory_api.py
```

**Test with curl**:

```bash
curl -X POST http://localhost:8000/lookup_billing \
  -H "Content-Type: application/json" \
  -d '{"code_type": "icd10", "code": "F33.1"}'

curl -X POST "http://localhost:8000/check_state_bill?state=ca&bill_query=telehealth"
```

### C. LangChain RAG Integration

```python
from src.moa.core.regulatory_gateway import MCPGateway
from langchain_openai import ChatOpenAI
from langchain.chains import RetrievalQA

mcp = MCPGateway()

# Inject compliance context into RAG queries
def enhanced_query(query: str):
    if "consent" in query.lower():
        compliance = mcp.check_state_bill_status("ca", "telehealth consent")
        context = f"State compliance: {compliance['status']}"
        query += f" {context}"
    
    # Use with your existing MOA-filtered RAG chain
    return qa_chain.run(query)
```

---

## PHI Safety

### Automatic PHI Detection

The gateway **blocks** any input matching these patterns:

- `\b\d{3}-\d{2}-\d{4}\b` → SSN
- `\b\d{3}-\d{3}-\d{4}\b` → Phone number
- `\b[A-Z][a-z]+ [A-Z][a-z]+\b` → Name pattern  
- `\b\d{1,2}/\d{1,2}/\d{4}\b` → Date (mm/dd/yyyy)

**Example**:

```python
mcp.lookup_billing_code("icd10", "John Doe")  
# ❌ ValueError: PHI DETECTED - refusing to call external API
```

### ⚠️ WARNING

**NEVER** expose `verify_medicaid_eligibility()` as an MCP tool. This method is for **backend-only** use with explicit patient consent and audit logs.

---

## Caching

All API results are cached for **24 hours** (86400 seconds) to:

- Respect free tier rate limits
- Reduce latency on repeated queries
- Enable offline operation after initial fetch

---

## API Reference

### `MCPGateway.lookup_billing_code(code_type, code)`

**Args**:

- `code_type` (str): `"icd10"` or `"cpt"`
- `code` (str): The billing code to lookup

**Returns**:

```json
{
  "code_type": "icd10",
  "code": "F33.1",
  "description": "Major depressive disorder, recurrent, moderate",
  "source": "NLM Clinical Tables"
}
```

**Error handling**:

```json
{
  "code_type": "icd10",
  "code": "INVALID",
  "error": "NLM lookup failed: ...",
  "source": "NLM Clinical Tables"
}
```

### `MCPGateway.check_state_bill_status(state, bill_query)`

**Args**:

- `state` (str): Two-letter state code (e.g., `"ca"`)
- `bill_query` (str): Search term (e.g., `"telehealth consent"`)

**Returns**:

```json
{
  "bills": [
    {
      "identifier": "AB 744",
      "title": "Telehealth: consent requirements",
      "updated_at": "2023-09-15"
    }
  ],
  "status": "Current",
  "source": "OpenStates"
}
```

**Fallback if no API key**:

```json
{
  "error": "OPENSTATES_API_KEY not set in environment"
}
```

---

## Integration with MOA Outlier Filter

**Compliance scoring formula**:

```text
Q(t,c) = α × S_rule(t,c) + (1-α) × S_vec(t,c)
```

Where:

- `S_rule` = regulatory compliance score (0–1, from MCP Layer 3)
- `S_vec` = semantic similarity (0–1, from embedding model)
- `α` = 0.7 (rule weight, adjustable)

### Example: Telehealth consent audit

```python
# User query: "Document depression video consult with consent"
1. MOA retrieves 4 candidate documents from vectorstore
2. MCP Layer 3 checks:
   - ICD code F33.1 validity ✅ (NLM)
   - CPT 99213 telehealth billing ✅ (eCFR §410.78)
   - CA consent law status ✅ (OpenStates: AB 744 passed)
3. MOA culls 1 outlier with d-δ-κ > threshold
4. Compliance score: Q(t,c) = 0.89 → PASS
```

---

## Deployment Checklist

- [x] Gateway tested (ICD-10 lookup working)
- [x] PHI guard tested (blocks SSN/phone/names)
- [x] 24h cache implemented
- [ ] Set `OPENSTATES_API_KEY` in production `.env`
- [ ] Set `CMS_OAUTH_TOKEN` if using Blue Button
- [ ] Configure MCP server in Claude Desktop `config.json`
- [ ] Deploy FastAPI endpoint behind HTTPS (for n8n/Streamlit)
- [ ] Add audit logs for all API calls (HIPAA compliance)

---

## Troubleshooting

### "OPENSTATES_API_KEY not set"

Get a free key: <https://openstates.org/api/register/>

Add to `.env`: `OPENSTATES_API_KEY=your_key_here`

### "NLM lookup failed"

The NLM Clinical Tables API occasionally has timeouts. The gateway:

1. Returns error with traceback (not a crash)
2. Does NOT cache failed lookups
3. Will retry on next call

### Numpy version conflict

You may see: `scipy 1.13.1 requires numpy<2.3,>=1.22.4, but you have numpy 2.3.5`

**Fix**:

```bash
pip install "numpy<2.3,>=1.22.4" --force-reinstall
```

---

## Next Steps

1. **Trademark filing** - "Magnetic Outlier Agent" + "MOA" (TEAS Plus ~$350)
2. **n8n node** - Wrap FastAPI endpoint as custom n8n node
3. **Streamlit demo** - Add "Regulatory Lookup" tab to Mike's Way Editor
4. **Enterprise sales** - Share this doc with CTOs as proof of compliance depth

---

## License

**Business Source License (BUSL) 1.1**  
Change date: 2029-11-27 → converts to Apache-2.0  
Patent Pending: U.S. Provisional 63/926,578 (filed Nov 27, 2025)

**Permitted**: Evaluation, research, internal use  
**Restricted**: Competing hosted/SaaS offerings before change date

---

**Questions?** File an issue or contact: <compliance@moa-telehealth.com>
