# LangChain Integration Quick Start

## Install

```bash
pip install moa-telehealth langchain langchain-core
```

## Basic Usage

### Option 1: Geometric Outlier Filter (Recommended for most RAG use cases)

```python
from moa.integrations.langchain import MOAOutlierFilter
from langchain_openai import OpenAIEmbeddings

embeddings = OpenAIEmbeddings()
filter = MOAOutlierFilter(embedding_model=embeddings, threshold=1.5)

# In your RAG chain
filtered_docs = filter.transform_documents(retrieved_docs)
```

### Option 2: Neuro-Symbolic Filter (For compliance + semantic filtering)

```python
from moa.integrations.langchain_moa_filter import MOAFilterRunnable

filter = MOAFilterRunnable(
    embeddings=embeddings,
    exemplars=["Good quality document example"],
    rules=[lambda text: len(text) > 50],
    alpha=0.6,        # 60% rules, 40% vectors
    threshold=0.8
)

filtered_docs = filter.invoke(retrieved_docs)
```

## Full Documentation

See [LANGCHAIN_INTEGRATION.md](./LANGCHAIN_INTEGRATION.md) for complete guide.

## Examples

- `examples/langchain_rag_filter_demo.py` - FAISS integration demo
- `examples/moa_langchain_integration.py` - Full RAG chain example
- `tests/verify_langchain_moa.py` - Verification test

## Tests

```bash
python tests/verify_langchain_moa.py
python tests/test_langchain_integration.py
```
