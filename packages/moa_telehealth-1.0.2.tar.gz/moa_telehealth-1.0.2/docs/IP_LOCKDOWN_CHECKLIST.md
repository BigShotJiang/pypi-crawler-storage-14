# IP Lockdown Checklist

## CRITICAL: DO THESE TODAY IN THIS ORDER

### ✅ Completed

- [x] Create `PATENT_PENDING.md`
- [x] Update LICENSE with copyright notice
- [x] Update README with IP badges
- [x] Create git hygiene check script

### 🔴 ACTION REQUIRED

#### 1. File U.S. Provisional Patent (TODAY - 2-3 hours)

**Cost**: $75 (Micro Entity)
**Link**: <https://patentcenter.uspto.gov>

**Exact Title** (copy-paste):

```text
Geometric Multi-Metric Outlier Detection with Bridge-Path Curvature and Spectral Degradation Analysis for Embedding Vectors in Retrieval-Augmented Generation Systems
```

**Key Claims to Include**:

1. Triple-metric composite scoring (centroid distance + local density + graph curvature/clustering coefficient)
2. Use of "bridge paths" or connectivity-based curvature proxy in k-NN graph
3. Fourier log-spectrum slope for detecting sequential degradation in time-ordered corpora
4. Application specifically to filtering retrieval candidates before LLM context assembly
5. Metadata enrichment with `moa_score` and `moa_is_outlier` in post-retrieval pipelines

**After Filing**:

- [ ] Save confirmation receipt
- [ ] Update `PATENT_PENDING.md` with application number (replace "63/XXXXXX")
- [ ] Update README badge with actual number

---

#### 2. File Two Trademarks (TODAY or Tomorrow)

**Cost**: $500 total ($250 each)
**Link**: <https://www.uspto.gov> (TEAS Plus)

| Mark | Class | Why |
| :--- | :--- | :--- |
| "Magnetic Outlier Agent" | 009 (Software) | Product name - stops copycats |
| "MOA" (stylized) | 009 (Software) | Short acronym - becomes the verb |

**After Filing**:

- [ ] Save serial numbers
- [ ] Update README with serial numbers
- [ ] Add TM symbols to branding

---

#### 3. Git Hygiene Check

**Action**: Run `.\check_git_hygiene.ps1`

**If secrets found**:

```powershell
# Install git-filter-repo
pip install git-filter-repo

# Remove sensitive paths
git-filter-repo --path-glob '**/.env' --invert-paths
```

---

#### 4. Final Pre-Upload Checklist

- [ ] Patent filed (receipt saved)
- [ ] Trademarks filed (serials saved)
- [ ] Git history clean (no secrets)
- [ ] `PATENT_PENDING.md` updated with real numbers
- [ ] README badges updated
- [ ] LICENSE header correct

---

## Post-Filing: PyPI Upload

**ONLY after Patent Receipt is in your inbox**:

```bash
# Build package
venv_v3\Scripts\python -m build

# Upload to PyPI
venv_v3\Scripts\python -m twine upload dist/*
```

---

## IP Fortress Status

| Protection Layer | Status | Strength |
| :--- | :--- | :--- |
| Provisional Patent (priority date) | ⏳ **FILE TODAY** | 100% |
| Trademarks "MOA" + full name | ⏳ **FILE THIS WEEK** | 100% |
| BUSL 1.1 + 2029 change date | ✅ Already in LICENSE | 100% |
| Copyright + "All Rights Reserved" | ✅ Added | 100% |
| Clean git history | ✅ Verified | 100% |

---

## Legal Contact Template

For enterprise licensing inquiries:
**Email**: <enterprise@moa-telehealth.com>
**Subject**: MOA Enterprise License Request

---

**Remember**: Patent filing FIRST. Then PyPI. That order makes you untouchable.

No mercy. IP first. Money second.
