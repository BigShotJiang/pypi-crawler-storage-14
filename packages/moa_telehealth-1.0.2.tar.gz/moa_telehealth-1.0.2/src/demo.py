"""
MOA Telehealth Demo Script

Demonstrates both Stage I (Geometric) and Stage II (Fourier) detection
on synthetic telehealth visit data.

Author: Michael Ordon (grzywajk-beep)
License: BSL 1.1
"""

import numpy as np
import sys
from pathlib import Path

# Add src to path
sys.path.insert(0, str(Path(__file__).parent))

from moa.core.geometric import GeometricDetector
from moa.core.fourier import FourierAnalyzer


def generate_synthetic_data(
    n_normal: int = 100,
    n_outliers: int = 10,
    n_dims: int = 384
) -> tuple:
    """
    Generate synthetic telehealth visit embeddings.
    
    Args:
        n_normal: Number of compliant visits
        n_outliers: Number of non-compliant visits
        n_dims: Embedding dimensionality
        
    Returns:
        Tuple of (embeddings, ground_truth_labels)
    """
    print(f"Generating synthetic data: {n_normal} normal + {n_outliers} outliers...")
    
    np.random.seed(42)
    
    # Normal visits: Clustered around origin with small variance
    normal = np.random.randn(n_normal, n_dims) * 0.3
    
    # Outliers: Far from origin, representing missing consent elements
    outliers = np.random.randn(n_outliers, n_dims) * 1.5 + 3.0
    
    embeddings = np.vstack([normal, outliers])
    
    # Ground truth: 0 = normal, 1 = outlier
    labels = np.array([0] * n_normal + [1] * n_outliers)
    
    # Shuffle
    indices = np.random.permutation(len(embeddings))
    embeddings = embeddings[indices]
    labels = labels[indices]
    
    print(f"[OK] Generated {len(embeddings)} embeddings ({n_dims}D)")
    
    return embeddings, labels


def evaluate_detection(
    predictions: np.ndarray,
    ground_truth: np.ndarray
) -> dict:
    """
    Compute precision, recall, F1 score.
    
    Args:
        predictions: Binary predictions (0/1)
        ground_truth: True labels (0/1)
        
    Returns:
        Dict of metrics
    """
    tp = np.sum((predictions == 1) & (ground_truth == 1))
    fp = np.sum((predictions == 1) & (ground_truth == 0))
    fn = np.sum((predictions == 0) & (ground_truth == 1))
    tn = np.sum((predictions == 0) & (ground_truth == 0))
    
    precision = tp / (tp + fp) if (tp + fp) > 0 else 0
    recall = tp / (tp + fn) if (tp + fn) > 0 else 0
    f1 = 2 * (precision * recall) / (precision + recall) if (precision + recall) > 0 else 0
    
    return {
        'precision': precision,
        'recall': recall,
        'f1': f1,
        'tp': tp,
        'fp': fp,
        'fn': fn,
        'tn': tn
    }


def demo_stage_i(embeddings: np.ndarray, labels: np.ndarray):
    """
    Demonstrate Stage I: Geometric Detection.
    """
    print("\n" + "="*60)
    print("STAGE I: GEOMETRIC OUTLIER DETECTION")
    print("="*60)
    
    # Test different lambda values
    lambda_values = [1.0, 1.5, 2.0]
    
    for lambda_val in lambda_values:
        print(f"\n--- Testing λ = {lambda_val} ---")
        
        detector = GeometricDetector(
            k_neighbors=15,
            lambda_threshold=lambda_val
        )
        
        scores, mask, components = detector.detect(
            embeddings,
            return_components=True
        )
        
        predictions = mask.astype(int)
        metrics = evaluate_detection(predictions, labels)
        
        print(f"Detected: {np.sum(mask)} outliers")
        print(f"Precision: {metrics['precision']:.3f}")
        print(f"Recall: {metrics['recall']:.3f}")
        print(f"F1 Score: {metrics['f1']:.3f}")
        print(f"Confusion Matrix: TP={metrics['tp']}, FP={metrics['fp']}, "
              f"FN={metrics['fn']}, TN={metrics['tn']}")
        
        # Explain first detected outlier
        if np.any(mask):
            first_outlier = np.where(mask)[0][0]
            explanation = detector.explain_outlier(
                first_outlier,
                embeddings,
                scores,
                components
            )
            print(f"\n{explanation}")


def demo_stage_ii(embeddings: np.ndarray):
    """
    Demonstrate Stage II: Fourier Sequential Analysis.
    """
    print("\n" + "="*60)
    print("STAGE II: FOURIER SEQUENTIAL ANALYSIS")
    print("="*60)
    
    # Compute embedding norms over sequence
    norms = np.linalg.norm(embeddings, axis=1)
    
    print(f"\nAnalyzing sequence of {len(norms)} embedding norms...")
    
    analyzer = FourierAnalyzer(
        min_freq_fraction=0.05,
        threshold_change=0.01
    )
    
    # Baseline: First 50% of sequence
    baseline_size = len(norms) // 2
    baseline_norms = norms[:baseline_size]
    
    baseline_slope, _, _ = analyzer.analyze(baseline_norms)
    print(f"Baseline slope (first {baseline_size} visits): {baseline_slope:.4f}")
    
    # Test full sequence
    full_slope, change, degraded = analyzer.analyze(
        norms,
        baseline=baseline_slope
    )
    
    print(f"\nFull sequence slope: {full_slope:.4f}")
    print(f"% Change from baseline: {change*100:.2f}%")
    print(f"Degraded: {'[WARN] YES' if degraded else '[OK] NO'}")
    
    # Monitor with early stopping
    print("\n--- Sequential Monitoring ---")
    monitor_result = analyzer.monitor_sequence(
        norms,
        window_size=30,
        baseline_window=50
    )
    
    if monitor_result['early_stop_idx'] is not None:
        print(f"[WARN] Early degradation detected at index {monitor_result['early_stop_idx']}")
    else:
        print("[OK] No sequential degradation detected")
    
    print(f"Monitoring windows: {len(monitor_result['detections'])}")
    print(f"Max % change: {max(monitor_result['changes'])*100:.2f}%")


def demo_combined(embeddings: np.ndarray, labels: np.ndarray):
    """
    Demonstrate combined Stage I + Stage II approach.
    """
    print("\n" + "="*60)
    print("COMBINED STAGE I + II ANALYSIS")
    print("="*60)
    
    # Stage I
    detector = GeometricDetector(lambda_threshold=1.5)
    scores, mask, _ = detector.detect(embeddings)
    
    stage_i_outliers = np.where(mask)[0]
    print(f"\nStage I detected: {len(stage_i_outliers)} outliers")
    
    # Stage II
    norms = np.linalg.norm(embeddings, axis=1)
    analyzer = FourierAnalyzer()
    
    baseline_slope, _, _ = analyzer.analyze(norms[:len(norms)//2])
    _, _, stage_ii_degraded = analyzer.analyze(norms, baseline=baseline_slope)
    
    print(f"Stage II degradation: {'YES' if stage_ii_degraded else 'NO'}")
    
    # Combined decision
    combined_flag = len(stage_i_outliers) > 0 or stage_ii_degraded
    
    print(f"\n{'='*60}")
    print(f"FINAL VERDICT: {'[WARN] COMPLIANCE ISSUES DETECTED' if combined_flag else '[OK] COMPLIANT'}")
    print(f"{'='*60}")
    
    if combined_flag:
        print("\nRecommendations:")
        if len(stage_i_outliers) > 0:
            print(f"  • Review {len(stage_i_outliers)} flagged visits for missing consent elements")
        if stage_ii_degraded:
            print("  • Monitor documentation quality trends")
            print("  • Consider provider training or workflow improvements")


def main():
    """
    Main demo entry point.
    """
    print("="*60)
    print("MOA TELEHEALTH - MAGNETIC OUTLIER AGENT DEMO")
    print("="*60)
    print("\nAuthor: Michael Ordon (grzywajk-beep)")
    print("License: BSL 1.1")
    
    # Generate data
    embeddings, labels = generate_synthetic_data(
        n_normal=100,
        n_outliers=10,
        n_dims=384
    )
    
    # Run demos
    demo_stage_i(embeddings, labels)
    demo_stage_ii(embeddings)
    demo_combined(embeddings, labels)
    
    print("\n" + "="*60)
    print("DEMO COMPLETE")
    print("="*60)
    print("\nNext steps:")
    print("  1. Open web/index.html in browser for interactive demo")
    print("  2. Review docs/presentation/W5_Presentation_Guide.md")
    print("  3. Upload your own embeddings (.csv or .npy)")
    print("\nGitHub: https://github.com/grzywajk-beep/moa_v1")


if __name__ == "__main__":
    main()
