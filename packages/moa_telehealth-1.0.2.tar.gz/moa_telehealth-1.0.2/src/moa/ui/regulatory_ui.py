import streamlit as st
import asyncio
import os
import sys

# Add project root to path to ensure imports work
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "../../../")))

from src.moa.core.phi_safe_evaluator import PHISafeEvaluator
from src.moa.integrations.mcp_client import RegulatoryMCPClient

@st.cache_resource
def get_evaluator() -> PHISafeEvaluator:
    # Use secrets or env vars for API key
    api_key = st.secrets.get("OPENSTATES_API_KEY") or os.getenv("OPENSTATES_API_KEY")
    client = RegulatoryMCPClient(api_key=api_key)
    return PHISafeEvaluator(client)

def run_async(coro):
    return asyncio.run(coro)

def main():
    st.set_page_config(page_title="MCP Regulatory Gateway", page_icon="🛡️", layout="wide")
    
    st.title("🛡️ MCP Regulatory Gateway")
    st.subheader("Consent & Telehealth Compliance Checker")
    st.caption("PHI Safety: ACTIVE (only codes and citations leave the note).")

    evaluator = get_evaluator()

    col1, col2 = st.columns([2, 1])
    
    with col1:
        clinical_text = st.text_area("Paste clinical/telehealth note (PHI stays local):", height=300)

    if st.button("Evaluate Compliance"):
        if not clinical_text.strip():
            st.warning("Enter some text first.")
            return

        with st.spinner("Evaluating with real-time regulatory checks..."):
            result = run_async(evaluator.evaluate(clinical_text))

        # Display Results
        st.divider()
        
        # Top-level metrics
        m1, m2, m3, m4 = st.columns(4)
        m1.metric("Overall Quality Score Q(t,c)", f"{result['quality_score']:.2f}")
        m2.metric("Billing Verification", f"{result['billing_score']:.2f}")
        m3.metric("Legislation Status", f"{result['legislation_score']:.2f}")
        m4.metric("CFR Compliance", f"{result['cfr_score']:.2f}")

        st.divider()
        
        # Detailed Breakdown
        c1, c2 = st.columns(2)
        
        with c1:
            st.info("Static & Vector Analysis")
            st.write(f"**Static Rules Score:** {result['static_rules_score']:.2f}")
            st.write(f"**Vector Similarity:** {result['vector_score']:.2f}")

        with c2:
            st.success("Real-time Regulatory Verification Details")
            with st.expander("View Extracted References"):
                st.write("**Billing codes:**", result["refs"]["billing_codes"])
                st.write("**Bills:**", result["refs"]["bills"])
                st.write("**CFR refs:**", result["refs"]["cfr_refs"])
            
            with st.expander("View Raw MCP Results"):
                st.json({
                    "billing_results": result["billing_results"],
                    "bill_results": result["bill_results"],
                    "cfr_results": result["cfr_results"],
                })

if __name__ == "__main__":
    main()
