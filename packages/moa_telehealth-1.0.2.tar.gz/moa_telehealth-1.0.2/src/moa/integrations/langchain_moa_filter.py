from typing import List, Dict, Any, Optional, Callable, Union
import numpy as np
from langchain_core.documents import Document
from langchain_core.embeddings import Embeddings
from langchain_core.runnables import RunnableSerializable
from pydantic import Field, PrivateAttr

class MOAFilterRunnable(RunnableSerializable):
    """
    LangChain Runnable that filters documents using MOA's Neuro-Symbolic logic.
    
    Combines deterministic rules with vector similarity to exemplars.
    Score = alpha * rule_score + (1 - alpha) * vector_score
    """
    
    embeddings: Embeddings
    exemplars: List[str]
    rules: List[Callable[[str], bool]] = Field(default_factory=list)
    threshold: float = 0.8
    alpha: float = 0.6
    
    _exemplar_embeddings: Optional[List[List[float]]] = PrivateAttr(default=None)

    class Config:
        arbitrary_types_allowed = True

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        # Pre-compute exemplar embeddings if possible, or do it lazily
        # For a Runnable, lazy init is often safer or done in a separate setup method
        # But here we'll do it lazily in _ensure_embeddings

    def _ensure_embeddings(self):
        if self._exemplar_embeddings is None and self.exemplars:
            self._exemplar_embeddings = self.embeddings.embed_documents(self.exemplars)

    def _compute_vector_score(self, doc_embedding: List[float]) -> float:
        if not self._exemplar_embeddings:
            return 0.0
        
        # Cosine similarity
        # A . B / (|A| * |B|)
        # Assuming normalized embeddings from the model usually, but let's be safe
        scores = []
        vec_a = np.array(doc_embedding)
        norm_a = np.linalg.norm(vec_a)
        
        for vec_b_list in self._exemplar_embeddings:
            vec_b = np.array(vec_b_list)
            norm_b = np.linalg.norm(vec_b)
            if norm_a == 0 or norm_b == 0:
                scores.append(0.0)
            else:
                scores.append(np.dot(vec_a, vec_b) / (norm_a * norm_b))
        
        return max(scores) if scores else 0.0

    def _compute_rule_score(self, text: str) -> float:
        if not self.rules:
            return 1.0 # Pass if no rules
        
        passes = sum(1 for rule in self.rules if rule(text))
        return passes / len(self.rules)

    def invoke(self, input: List[Document], config: Optional[Dict[str, Any]] = None) -> List[Document]:
        self._ensure_embeddings()
        
        # Embed input documents
        texts = [doc.page_content for doc in input]
        doc_embeddings = self.embeddings.embed_documents(texts)
        
        filtered_docs = []
        
        for doc, embedding in zip(input, doc_embeddings):
            rule_score = self._compute_rule_score(doc.page_content)
            vector_score = self._compute_vector_score(embedding)
            
            quality_score = (self.alpha * rule_score) + ((1 - self.alpha) * vector_score)
            
            # Add scores to metadata for debugging
            doc.metadata['moa_score'] = quality_score
            doc.metadata['moa_rule_score'] = rule_score
            doc.metadata['moa_vector_score'] = vector_score
            
            if quality_score >= self.threshold:
                filtered_docs.append(doc)
                
        return filtered_docs

# Default Rules (Example)
def rule_no_phi(text: str) -> bool:
    """Simple check for potential PHI patterns (stub)"""
    # Real implementation would use regex for SSN, Phone, etc.
    return "SSN" not in text

def rule_min_length(text: str) -> bool:
    return len(text) > 10

DEFAULT_RULES = [rule_no_phi, rule_min_length]
