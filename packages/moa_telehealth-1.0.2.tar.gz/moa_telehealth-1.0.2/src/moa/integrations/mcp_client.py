                    if resp.status_code == 200:
                        results[b] = resp.json()
                    else:
                        results[b] = {}
                except Exception:
                    results[b] = {}
        return results

    async def check_cfr(self, cfr_refs: List[str]) -> Dict[str, dict]:
        """
        Check CFR references for compliance.
        """
        if not cfr_refs:
            return {}
            
        results = {}
        async with httpx.AsyncClient() as client:
            for ref in cfr_refs:
                try:
                    headers = {"Authorization": f"Bearer {self.api_key}"} if self.api_key else {}
                    resp = await client.post(
                        f"{MCP_BASE_URL}/cfr/search",
                        headers=headers,
                        params={"query": ref},
                        timeout=5.0,
                    )
                    if resp.status_code == 200:
                        results[ref] = resp.json()
                    else:
                        results[ref] = {}
                except Exception:
                    results[ref] = {}
        return results

def run_mcp_tool(coro):
    """Helper to run async MCP tools in synchronous contexts"""
    try:
        loop = asyncio.get_event_loop()
    except RuntimeError:
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
    
    if loop.is_running():
        import nest_asyncio
        nest_asyncio.apply()
        return loop.run_until_complete(coro)
    return loop.run_until_complete(coro)
