"""
MOA LangChain Integration - RAG Outlier Filter
Custom DocumentTransformer for filtering low-quality chunks in RAG pipelines.

Usage:
    from moa.integrations.langchain import MOAOutlierFilter
    
    filter = MOAOutlierFilter(embedding_model, threshold=1.5)
    filtered_docs = filter.transform_documents(retrieved_docs)
"""

import numpy as np
from typing import List, Optional, Tuple
from langchain_core.documents import Document

try:
    from langchain_core.embeddings import Embeddings
    from langchain_core.runnables import Runnable
except ImportError:
    # Allow import without langchain for inspection, but fail on usage
    Embeddings = object
    Runnable = object

from moa.core.geometric import GeometricDetector


class MOAOutlierFilter:
    """
    LangChain-compatible document transformer that filters outliers using MOA.
    
    Filters out retrieved chunks that are geometric outliers in embedding space,
    preventing hallucinations from low-quality or off-topic retrieval.
    """
    
    def __init__(
        self,
        embedding_model: Embeddings,
        k: int = 15,
        threshold: float = 1.5,
        keep_outliers: bool = False,
        add_metadata: bool = True
    ):
        """
        Args:
            embedding_model: LangChain Embeddings instance
            k: Number of neighbors for local density
            threshold: Outlier score threshold (std devs)
            keep_outliers: If True, keep only outliers (inverse filtering)
            add_metadata: If True, add MOA scores to document metadata
        """
        self.embedding_model = embedding_model
        self.k = k
        self.threshold = threshold
        self.keep_outliers = keep_outliers
        self.add_metadata = add_metadata
        self.detector = GeometricDetector(k_neighbors=k, lambda_threshold=threshold)
    
    def transform_documents(self, documents: List[Document]) -> List[Document]:
        """
        Filter documents by MOA outlier detection.
        
        Args:
            documents: List of LangChain Document objects
        
        Returns:
            Filtered list of documents
        """
        if not documents:
            return documents
        
        # Generate embeddings for all documents
        texts = [doc.page_content for doc in documents]
        embeddings_list = self.embedding_model.embed_documents(texts)
        embeddings = np.array(embeddings_list)
        
        # Compute MOA scores
        scores, mask, _ = self.detector.detect(embeddings)
        
        # Filter documents
        filtered_docs = []
        for i, doc in enumerate(documents):
            is_outlier = mask[i]
            
            # Add metadata if requested
            if self.add_metadata:
                doc.metadata["moa_score"] = float(scores[i])
                doc.metadata["moa_is_outlier"] = bool(is_outlier)
            
            # Keep based on filter mode
            should_keep = is_outlier if self.keep_outliers else not is_outlier
            if should_keep:
                filtered_docs.append(doc)
        
        return filtered_docs
    
    async def atransform_documents(self, documents: List[Document]) -> List[Document]:
        """Async version (delegates to sync for now)."""
        return self.transform_documents(documents)

    def score_documents(self, documents: List[Document]) -> Tuple[List[Document], np.ndarray, np.ndarray]:
        """
        Score documents without filtering.
        
        Args:
            documents: List of LangChain Document objects
            
        Returns:
            Tuple of (documents with metadata, scores, outlier_mask)
        """
        if not documents:
            return documents, np.array([]), np.array([])
            
        # Generate embeddings
        texts = [doc.page_content for doc in documents]
        embeddings_list = self.embedding_model.embed_documents(texts)
        embeddings = np.array(embeddings_list)
        
        # Compute scores
        scores, mask, _ = self.detector.detect(embeddings)
        
        # Add metadata
        for i, doc in enumerate(documents):
            doc.metadata["moa_score"] = float(scores[i])
            doc.metadata["moa_is_outlier"] = bool(mask[i])
            
        return documents, scores, mask


# LangChain Runnable wrapper
class MOAFilterRunnable(Runnable):
    """Runnable wrapper for use in LCEL chains."""
    
    def __init__(self, filter: MOAOutlierFilter):
        self.filter = filter
    
    def invoke(self, input: List[Document], config=None) -> List[Document]:
        return self.filter.transform_documents(input)
    
    async def ainvoke(self, input: List[Document], config=None) -> List[Document]:
        return await self.filter.atransform_documents(input)
