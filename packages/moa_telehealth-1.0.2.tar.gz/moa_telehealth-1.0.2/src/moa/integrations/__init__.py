"""
MOA LangChain Integrations

Provides two complementary approaches for filtering documents in RAG pipelines:

1. MOAOutlierFilter: Geometric outlier detection using MOA's core algorithm
   - Best for: Vector similarity-based filtering
   - Use when: You want to remove off-topic or low-quality chunks based on embedding geometry
   
2. MOAFilterRunnable: Neuro-symbolic filtering combining rules + vectors
   - Best for: Compliance and quality filtering with explicit rules
   - Use when: You need both semantic similarity and rule-based validation
"""

try:
    from .langchain import MOAOutlierFilter, MOAFilterRunnable as MOAFilterRunnable_Geometric
    from .langchain_moa_filter import MOAFilterRunnable, DEFAULT_RULES
    
    __all__ = [
        "MOAOutlierFilter",           # Geometric outlier detection
        "MOAFilterRunnable",          # Neuro-symbolic (rules + vectors)
        "DEFAULT_RULES",              # Default compliance rules
    ]
except ImportError as e:
    # LangChain not installed
    __all__ = []
