"""
regulatory_mcp_server.py
MCP server exposing free regulatory/gov APIs to MOA.
"""

import os
import sys

# Ensure src is in path
sys.path.append(os.path.join(os.path.dirname(__file__), "src"))

try:
    from mcp.server.fastmcp import FastMCP
except ImportError:
    # Fallback if mcp is not installed, though we are trying to install it
    print("MCP library not found. Please run 'pip install mcp'.")
    sys.exit(1)

from moa.core.regulatory_gateway import MCPGateway

app = FastMCP("regulatory-mcp")
gateway = MCPGateway()

@app.tool()
def lookup_billing_code(code_type: str, code: str) -> dict:
    """
    Lookup ICD-10 or CPT codes via gov APIs (no PHI).
    
    Args:
        code_type: "icd10" or "cpt"
        code: The code to lookup (e.g. "F33.1")
    """
    return gateway.lookup_billing_code(code_type, code)

@app.tool()
def check_state_bill_status(state: str, bill_query: str) -> dict:
    """
    Check current telehealth bills for a state (OpenStates).
    
    Args:
        state: Two-letter state code (e.g. "ca")
        bill_query: Query string (e.g. "telehealth consent")
    """
    return gateway.check_state_bill_status(state, bill_query)

if __name__ == "__main__":
    app.run()
