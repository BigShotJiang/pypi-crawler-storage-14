from fastapi import FastAPI, HTTPException, Request
from pydantic import BaseModel
from typing import List
import numpy as np
import uvicorn
import stripe
from ..core.geometric import GeometricDetector
from ..core.gemma_slm_swap import SLMRuleChecker
from ..core.ssg import compute_ssg_fingerprint

app = FastAPI(title="MOA Telehealth API", version="1.0.0")

checker = SLMRuleChecker()
stripe.api_key = "sk_live_YourKeyHere"  # Env var

class DetectRequest(BaseModel):
    embeddings: List[List[float]]
    threshold: float = 1.5

class DetectResponse(BaseModel):
    outlier_count: int
    outlier_indices: List[int]
    scores: List[float]

class ConsentRequest(BaseModel):
    text: str

class ConsentResponse(BaseModel):
    passed: bool
    score: float
    details: str

class CheckoutRequest(BaseModel):
    success_url: str = "https://yourapp.com/success"
    cancel_url: str = "https://yourapp.com/cancel"

class FingerprintRequest(BaseModel):
    text: str

class FingerprintResponse(BaseModel):
    fingerprint: List[float]

@app.get("/health")
def health_check():
    return {"status": "healthy"}

@app.post("/detect", response_model=DetectResponse)
def detect_outliers(request: DetectRequest):
    try:
        embeddings = np.array(request.embeddings)
        detector = GeometricDetector(lambda_threshold=request.threshold)
        scores, mask, _ = detector.detect(embeddings)
        return {
            "outlier_count": int(np.sum(mask)),
            "outlier_indices": np.where(mask)[0].tolist(),
            "scores": scores.tolist()
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/consent-check", response_model=ConsentResponse)
def check_consent(request: ConsentRequest):
    try:
        result = checker.check_implied_consent(request.text)
        return ConsentResponse(**result)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/fingerprint", response_model=FingerprintResponse)
def get_fingerprint(request: FingerprintRequest):
    try:
        fp = compute_ssg_fingerprint(request.text)
        return {"fingerprint": fp.tolist()}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/create-sub")
def create_sub(request: CheckoutRequest):
    session = stripe.checkout.Session.create(
        payment_method_types=['card'],
        line_items=[{
            'price_data': {
                'currency': 'usd',
                'product_data': {'name': 'Pro SLM ($29/mo)'},
                'unit_amount': 2900,
                'recurring': {'interval': 'month'}
            },
            'quantity': 1
        }],
        mode='subscription',
        success_url=request.success_url,
        cancel_url=request.cancel_url
    )
    return {"url": session.url}

@app.post("/stripe-webhook")
async def stripe_webhook(request: Request):
    payload = await request.body()
    sig_header = request.headers.get('Stripe-Signature')
    if not sig_header:
        raise HTTPException(status_code=400, detail="Missing Stripe-Signature header")

    webhook_secret = "whsec_YourSecret"
    try:
        event = stripe.Webhook.construct_event(payload, sig_header, webhook_secret)
    except stripe.error.SignatureVerificationError as exc:
        raise HTTPException(status_code=400, detail=f"Signature verification failed: {exc}") from exc

    if event['type'] == 'checkout.session.completed':
        # n8n trigger: Unlock pro
        print("Sub confirmed—Gemma access granted.")
    return {"status": "success"}

if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8000)