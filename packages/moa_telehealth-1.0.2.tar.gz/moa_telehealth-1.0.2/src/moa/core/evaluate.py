from typing import Optional, Dict, Any

def r_billing_code_verified(mcp_result: Optional[Dict[str, Any]]) -> float:
    """
    Return 1.0 if billing code is valid and active, 0.0 if invalid, 0.5 if unknown.
    """
    if not mcp_result:
        return 0.5
    status = mcp_result.get("status")  # e.g. "active", "deleted", "unknown"
    if status == "active":
        return 1.0
    if status in {"deleted", "invalid"}:
        return 0.0
    return 0.5


def r_legislation_current(bill_result: Optional[Dict[str, Any]]) -> float:
    """
    Weight based on bill status (e.g., 'enacted' > 'introduced').
    """
    if not bill_result:
        return 0.5
    status = bill_result.get("status")  # "passed", "failed", "introduced", etc.
    if status in {"passed", "enacted"}:
        return 1.0
    if status in {"failed", "vetoed"}:
        return 0.0
    return 0.7  # in process


def r_cfr_compliance(cfr_result: Optional[Dict[str, Any]]) -> float:
    """
    Compare text against CFR/USC hits; 1.0 if fully aligned, lower if conflicts found.
    """
    if not cfr_result:
        return 0.5
    conflicts = cfr_result.get("conflicts", 0)
    if conflicts == 0:
        return 1.0
    if conflicts <= 2:
        return 0.6
    return 0.2


def compute_quality(
    t: str,
    c: Optional[Dict[str, Any]],
    static_rules_score: float,
    vector_score: float,
    billing_rule_score: float,
    legislation_rule_score: float,
    cfr_rule_score: float,
) -> float:
    """
    New Q(t, c) with MCP-enhanced rules.
    """
    # weights: adjust as needed / expose as config
    w_static = 0.35
    w_vector = 0.25
    w_billing = 0.15
    w_legislation = 0.15
    w_cfr = 0.10

    return (
        w_static * static_rules_score
        + w_vector * vector_score
        + w_billing * billing_rule_score
        + w_legislation * legislation_rule_score
        + w_cfr * cfr_rule_score
    )
