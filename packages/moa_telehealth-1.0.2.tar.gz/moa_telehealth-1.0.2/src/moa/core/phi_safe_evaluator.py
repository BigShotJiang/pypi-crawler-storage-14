import re
import logging
from typing import Dict, List, Optional, Any
from . import evaluate
from ..integrations.mcp_client import RegulatoryMCPClient

logger = logging.getLogger(__name__)

BILLING_CODE_PATTERN = re.compile(r"\b(99\d{3}|G0\d{3}|H[0-9A-Z]{3})\b")
CFR_PATTERN = re.compile(r"\b(\d+)\s*CFR\s*(\d+\.\d+)\b", re.IGNORECASE)
BILL_PATTERN = re.compile(r"\b(?:AB|SB|HB|HR)\s*\d+\b", re.IGNORECASE)

def extract_regulatory_refs(text: str) -> Dict[str, List[str]]:
    """
    Extract regulatory references from text.
    """
    codes = list(set(BILLING_CODE_PATTERN.findall(text)))
    cfrs = list(set(CFR_PATTERN.findall(text)))
    bills = list(set(BILL_PATTERN.findall(text)))
    return {
        "billing_codes": codes,
        "cfr_refs": [f"{title} CFR {section}" for title, section in cfrs],
        "bills": bills,
    }

class PHISafeEvaluator:
    def __init__(self, mcp_client: RegulatoryMCPClient):
        self.mcp_client = mcp_client

    async def evaluate(self, clinical_text: str, context: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """
        Full evaluation pipeline. Returns both Q(t, c) and details for UI.
        """
        # 1. Extract regulatory references (PHI-safe payload)
        refs = extract_regulatory_refs(clinical_text)

        # 2. Call MCP tools with sanitized payload
        try:
            billing_results = await self.mcp_client.verify_billing_codes(
                refs["billing_codes"]
            )
            bill_results = await self.mcp_client.check_bills(refs["bills"])
            cfr_results = await self.mcp_client.check_cfr(refs["cfr_refs"])
        except Exception as e:
            logger.exception("MCP call failed; falling back to static rules.")
            billing_results = {}
            bill_results = {}
            cfr_results = {}

        # 3. Compute MCP rule scores
        # Note: These rule functions expect a single result dict, but here we have a dict of results.
        # We'll take the average or minimum score for the set of codes/bills found.
        
        # Helper to aggregate scores
        def aggregate_score(results: Dict[str, Any], rule_func) -> float:
            if not results:
                return 0.5 # Neutral if no codes found
            scores = [rule_func(res) for res in results.values()]
            return sum(scores) / len(scores) if scores else 0.5

        billing_score = aggregate_score(billing_results, evaluate.r_billing_code_verified)
        legislation_score = aggregate_score(bill_results, evaluate.r_legislation_current)
        cfr_score = aggregate_score(cfr_results, evaluate.r_cfr_compliance)

        # 4. Compute existing static + vector scores
        static_rules_score = self._static_rules_score(clinical_text, context)
        vector_score = self._vector_similarity_score(clinical_text, context)

        q = evaluate.compute_quality(
            clinical_text,
            context,
            static_rules_score,
            vector_score,
            billing_score,
            legislation_score,
            cfr_score,
        )

        # 5. Audit log (only sanitized payload)
        logger.info(
            "MCP_EVAL",
            extra={
                "billing_codes": refs["billing_codes"],
                "bills": refs["bills"],
                "cfr_refs": refs["cfr_refs"],
                "billing_score": billing_score,
                "legislation_score": legislation_score,
                "cfr_score": cfr_score,
            },
        )

        return {
            "quality_score": q,
            "static_rules_score": static_rules_score,
            "vector_score": vector_score,
            "billing_score": billing_score,
            "legislation_score": legislation_score,
            "cfr_score": cfr_score,
            "refs": refs,
            "billing_results": billing_results,
            "bill_results": bill_results,
            "cfr_results": cfr_results,
        }

    def _static_rules_score(self, text: str, context: Optional[Dict[str, Any]]) -> float:
        """
        Static compliance rules for telehealth consent.
        
        Checks for:
        - Consent language presence
        - Risk disclosure
        - Privacy/HIPAA language
        - Patient rights language
        - Substantive documentation (length)
        """
        score = 0.0
        rules_passed = 0
        total_rules = 5
        
        # Rule 1: Consent language
        if re.search(r"(consent|authorize|agree)", text, re.IGNORECASE):
            rules_passed += 1
        
        # Rule 2: Risk disclosure
        if re.search(r"(risk|limitation|technical issue)", text, re.IGNORECASE):
            rules_passed += 1
        
        # Rule 3: Privacy/HIPAA
        if re.search(r"(privacy|hipaa|confidential)", text, re.IGNORECASE):
            rules_passed += 1
        
        # Rule 4: Patient rights (opt-out, record access)
        if re.search(r"(right to|may refuse|opt.?out)", text, re.IGNORECASE):
            rules_passed += 1
        
        # Rule 5: Minimum length (substantive documentation)
        if len(text) > 100:
            rules_passed += 1
        
        return rules_passed / total_rules

    def _vector_similarity_score(self, text: str, context: Optional[Dict[str, Any]]) -> float:
        """
        Compare text embedding to golden exemplar using cosine similarity.
        
        Requires: embedding_model (loaded from sentence-transformers)
        Falls back to 0.5 if embedding generation fails.
        """
        try:
            from sentence_transformers import SentenceTransformer
            import numpy as np
            
            # Load model (will be cached by sentence-transformers)
            model = SentenceTransformer('all-MiniLM-L6-v2')
            
            # Golden exemplar (ideal consent note)
            exemplar = """
            Patient consents to telehealth services. Understands technical limitations
            and potential privacy risks. HIPAA protections apply. Patient may opt out
            at any time and request in-person visit. All rights under California AB-688
            apply. Risks of technical failure explained.
            """
            
            # Generate embeddings
            text_emb = model.encode(text)
            exemplar_emb = model.encode(exemplar)
            
            # Cosine similarity
            similarity = np.dot(text_emb, exemplar_emb) / (
                np.linalg.norm(text_emb) * np.linalg.norm(exemplar_emb)
            )
            
            # Convert to [0, 1] score (cosine similarity is in [-1, 1])
            return float((similarity + 1) / 2)
        
        except Exception as e:
            logger.warning(f"Vector scoring failed: {e}. Falling back to 0.5")
            return 0.5
