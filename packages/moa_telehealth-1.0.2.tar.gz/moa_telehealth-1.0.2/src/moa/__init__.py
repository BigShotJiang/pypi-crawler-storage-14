from .core.geometric import GeometricDetector
from .core.fourier import FourierAnalyzer
from .core.ssg import compute_ssg_fingerprint

__version__ = "1.0.1"

__all__ = [
    "GeometricDetector",
    "FourierAnalyzer",
    "compute_ssg_fingerprint"
]

# Optional LangChain integrations
try:
    from .integrations.langchain import MOAOutlierFilter
    from .integrations.langchain_moa_filter import MOAFilterRunnable, DEFAULT_RULES
    __all__.extend(["MOAOutlierFilter", "MOAFilterRunnable", "DEFAULT_RULES"])
except ImportError:
    pass
