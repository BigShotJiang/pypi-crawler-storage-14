import stripe
from fastapi import FastAPI, HTTPException, Request
from pydantic import BaseModel

stripe.api_key = "sk_live_YourKeyHere"  # Env: os.getenv('STRIPE_SECRET')

app = FastAPI()

class CheckoutRequest(BaseModel):
    success_url: str = "https://yourapp.com/success"
    cancel_url: str = "https://yourapp.com/cancel"

@app.post("/create-checkout")
def create_checkout(request: CheckoutRequest):
    session = stripe.checkout.Session.create(
        payment_method_types=['card'],
        line_items=[{
            'price_data': {
                'currency': 'usd',
                'product_data': {'name': 'Pro SLM Evals ($29/mo Gemma Consent Checks)'},
                'unit_amount': 2900,  # $29
                'recurring': {'interval': 'month'}
            },
            'quantity': 1
        }],
        mode='subscription',
        success_url=request.success_url,
        cancel_url=request.cancel_url
    )
    return {"session_id": session.id, "url": session.url}  # Frontend redirect

@app.post("/webhook")
async def webhook(request: Request):
    payload = await request.body()
    sig_header = request.headers.get('Stripe-Signature')
    if not sig_header:
        raise HTTPException(status_code=400, detail="Missing Stripe-Signature header")

    webhook_secret = "whsec_YourSecret"  # Dashboard webhook
    try:
        event = stripe.Webhook.construct_event(payload, sig_header, webhook_secret)
    except stripe.error.SignatureVerificationError as exc:
        raise HTTPException(status_code=400, detail=f"Signature verification failed: {exc}") from exc

    if event['type'] == 'checkout.session.completed':
        # n8n trigger: Unlock pro (email via n8n workflow)
        print("Sub confirmed—pro SLM access granted.")
    return {"status": "success"}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8001)