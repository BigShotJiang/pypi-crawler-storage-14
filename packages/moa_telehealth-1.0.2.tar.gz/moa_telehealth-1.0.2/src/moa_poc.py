import numpy as np
from scipy.stats import zscore
import networkx as nx
from sklearn.neighbors import NearestNeighbors
from scipy.fft import fft, fftfreq
from scipy.stats import linregress
from sklearn.metrics import precision_recall_fscore_support
from sklearn.neighbors import LocalOutlierFactor
from sklearn.ensemble import IsolationForest

# Synthetic Data (Abstract-inspired: 384-dim, n=115, 10 outliers)
np.random.seed(42)
normal = np.random.randn(105, 384) * 0.1 + 1.0
outliers = np.random.randn(10, 384) * 0.1 + 1.2
embeds = np.vstack((normal, outliers))
true_labels = np.array([0]*105 + [1]*10)

def geometric_detect(embeds, k=15, lambda_thresh=1.5, eps=1e-8):
    N, d = embeds.shape
    c = np.mean(embeds, axis=0)
    
    nbrs = NearestNeighbors(n_neighbors=k+1).fit(embeds)
    _, indices = nbrs.kneighbors(embeds)
    
    G = nx.Graph()
    for i in range(N):
        G.add_node(i)
        for j in indices[i][1:]:
            dist = np.linalg.norm(embeds[i] - embeds[j])
            G.add_edge(i, j, weight=dist)
    
    d_i = np.linalg.norm(embeds - c, axis=1)
    delta_i = np.zeros(N)
    kappa_i = np.zeros(N)
    for i in range(N):
        neigh = list(G.neighbors(i))
        if neigh:
            neigh_dists = [G.edges[i,j]['weight'] for j in neigh]
            delta_i[i] = k / (np.sum(neigh_dists) + eps)
            kappa_i[i] = nx.clustering(G, i)
    
    z_d = zscore(d_i)
    z_delta = zscore(delta_i)
    z_kappa = zscore(kappa_i)
    s_i = z_d - z_delta - z_kappa
    
    mean_s, std_s = np.mean(s_i), np.std(s_i)
    pred = (s_i > mean_s + lambda_thresh * std_s).astype(int)
    
    outliers_idx = np.where(pred == 1)[0]
    bridge = None
    if len(outliers_idx) > 0:
        o = outliers_idx[0]
        core = np.argmin(s_i)
        try:
            bridge = nx.shortest_path(G, o, core)
        except:
            bridge = [o, core]
    
    p, r, f1, _ = precision_recall_fscore_support(true_labels, pred, average='binary', zero_division=0)
    
    return {'p': p, 'r': r, 'f1': f1, 'outliers': len(outliers_idx), 'bridge': bridge}

def fourier_analyze(norms, min_freq_frac=0.05, thresh_change=0.01):
    signal = np.array(norms)
    if len(signal) < 32:
        return {'error': 'Too short'}
    
    signal -= np.mean(signal)
    N = len(signal)
    yf = fft(signal)
    xf = fftfreq(N, 1)[:N//2]
    psd = 2.0 / N * np.abs(yf[:N//2]) ** 2
    log_psd = np.log10(np.clip(psd, 1e-12, None))
    
    num_low = max(2, int(len(xf) * min_freq_frac))
    low_idx = np.argsort(xf)[:num_low]
    low_x, low_y = xf[low_idx], log_psd[low_idx]
    
    slope, _, r2, _, _ = linregress(low_x, low_y)
    percent_change = 0.0
    degraded = percent_change > thresh_change
    
    return {'slope': slope, 'degraded': degraded}

# Baselines
lof = LocalOutlierFactor(n_neighbors=15, contamination=0.1).fit_predict(embeds)
lof_pred = (lof == -1).astype(int)
lof_p, lof_r, lof_f1, _ = precision_recall_fscore_support(true_labels, lof_pred, average='binary', zero_division=0)

iforest = IsolationForest(contamination=0.1).fit_predict(embeds)
if_pred = (iforest == -1).astype(int)
if_p, if_r, if_f1, _ = precision_recall_fscore_support(true_labels, if_pred, average='binary', zero_division=0)

norms = np.linalg.norm(embeds, axis=1)
geo = geometric_detect(embeds)
fourier = fourier_analyze(norms)

print("MOA Geometric:", geo)
print("MOA Fourier:", fourier)
print("LOF:", {'p': lof_p, 'r': lof_r, 'f1': lof_f1})
print("Isolation Forest:", {'p': if_p, 'r': if_r, 'f1': if_f1})
