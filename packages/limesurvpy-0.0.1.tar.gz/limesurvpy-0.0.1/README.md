# limesurvpy

A Python package to support evaluating LimeSurvey questionnaires. The package provides support for various types of questions (e.g., lists, multiple choice questions, rankings, etc.). For supported question types, the tool compiles dataframes of responses, and generates a number of pre-defined plots to support interpretation. For multi-lingual surveys, the tool supports presenting information in a specific locale.   
