__version__ = "0.23.2"


def get_version() -> str:
    return __version__
