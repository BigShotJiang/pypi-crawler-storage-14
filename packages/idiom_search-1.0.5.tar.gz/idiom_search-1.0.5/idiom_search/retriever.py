from pypinyin import lazy_pinyin
import re
import json
import logging
from collections import defaultdict
import os

# 日志配置（保留但降低调试级别的输出频率）
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(funcName)s - %(message)s",
    handlers=[logging.StreamHandler()]
)
logger = logging.getLogger(__name__)

# -------------------------- 1. 嵌入拼音前缀树的JSON（关键！） --------------------------
# 替换为你生成的3万+成语的拼音树JSON字符串
IDIOM_TRIE_JSON = ""  # 请粘贴你的JSON内容

# -------------------------- 2. 工具函数优化（减少重复计算） --------------------------
def chinese_to_pinyin(text: str) -> str:
    """将纯汉字转为无声调拼音字符串，非纯汉字返回空（添加缓存）"""
    if not isinstance(text, str) or not re.match(r'^[\u4e00-\u9fa5]+$', text):
        return ""
    # 单次调用完成拼音转换，避免循环内多次调用
    return ''.join(lazy_pinyin(text, style=0))

def calculate_match_rate(pinyin1: str, pinyin2: str) -> float:
    """优化匹配度计算：使用编辑距离算法，更好地处理字符插入、删除和替换的情况"""
    if not pinyin1 or not pinyin2:
        return 0.0
    
    len1, len2 = len(pinyin1), len(pinyin2)
    
    # 创建编辑距离矩阵
    dp = [[0] * (len2 + 1) for _ in range(len1 + 1)]
    
    # 初始化矩阵边界
    for i in range(len1 + 1):
        dp[i][0] = i
    for j in range(len2 + 1):
        dp[0][j] = j
    
    # 计算编辑距离
    for i in range(1, len1 + 1):
        for j in range(1, len2 + 1):
            if pinyin1[i-1] == pinyin2[j-1]:
                dp[i][j] = dp[i-1][j-1]  # 字符相同，无需操作
            else:
                # 选择插入、删除或替换中代价最小的操作
                dp[i][j] = min(
                    dp[i][j-1] + 1,      # 插入
                    dp[i-1][j] + 1,      # 删除
                    dp[i-1][j-1] + 1     # 替换
                )
    
    # 计算最大可能的编辑距离（两个字符串长度之和）
    max_distance = len1 + len2
    
    # 将编辑距离转换为匹配率（0.0-1.0）
    # 匹配率 = 1 - (编辑距离 / 最大可能距离)
    match_rate = 1 - (dp[len1][len2] / max_distance)
    
    return match_rate

# -------------------------- 3. 前缀树节点类（轻量化改造） --------------------------
class TrieNode:
    def __init__(self, node_dict: dict):
        self.children = node_dict["children"]  # 直接存储字典，避免递归创建对象
        self.idioms = node_dict["idioms"]

# -------------------------- 4. 检索器核心优化（预缓存+重写模糊匹配） --------------------------
class IdiomRetriever:
    def __init__(self, trie_json: str):
        """初始化：加载树+预缓存所有成语的拼音映射（核心优化）"""
        self.trie_dict = json.loads(trie_json)
        self.root = TrieNode(self.trie_dict)
        # 预缓存：{拼音长度: {拼音串: 成语列表}} —— 避免模糊检索遍历树
        self.idiom_pinyin_cache = defaultdict(dict)
        # 预缓存：所有成语的集合（快速去重）
        self.all_idioms = set()
        # 从前缀树中提取所有成语和拼音（仅初始化时执行一次）
        self._build_pinyin_cache(self.trie_dict, current_pinyin="")
        logger.info(f"初始化完成，缓存成语数：{len(self.all_idioms)}，拼音长度分组：{list(self.idiom_pinyin_cache.keys())}")

    def _build_pinyin_cache(self, node_dict: dict, current_pinyin: str):
        """深度优先遍历树，预缓存成语拼音映射（仅初始化执行）"""
        # 叶子节点有成语，加入缓存
        if node_dict["idioms"]:
            pinyin_len = len(current_pinyin)
            self.idiom_pinyin_cache[pinyin_len][current_pinyin] = node_dict["idioms"]
            self.all_idioms.update(node_dict["idioms"])
        # 遍历子节点
        for char, child_dict in node_dict["children"].items():
            self._build_pinyin_cache(child_dict, current_pinyin + char)

    def retrieve_exact(self, pinyin: str) -> list:
        """精准检索：优化为字典遍历，替代对象属性访问"""
        if not pinyin:
            return []
        node_dict = self.trie_dict
        for char in pinyin:
            if char not in node_dict["children"]:
                return []
            node_dict = node_dict["children"][char]
        return node_dict["idioms"]

    def retrieve_fuzzy(self, pinyin: str, threshold: float = 0.8, max_count: int = 0) -> list:
        """模糊检索：基于预缓存的拼音映射，替代DFS遍历（核心优化）
        
        Args:
            pinyin: 要搜索的拼音字符串
            threshold: 匹配度阈值
            max_count: 最大返回结果数量，0表示不限制
            
        Returns:
            匹配的成语列表
        """
        if not pinyin or threshold <= 0:
            return []
        
        # 存储(匹配度, 成语)元组的列表，用于排序
        matched_with_scores = []
        
        # 遍历所有可能长度的拼音串（不仅限于相同长度）
        # 为了提高效率，我们只考虑与目标拼音长度相近的拼音串
        target_len = len(pinyin)
        
        # 检查长度相近的拼音串（调整为±2个字符范围内，提高匹配率）
        for length_diff in [-1, 0, 1]:
            length = target_len + length_diff
            if length not in self.idiom_pinyin_cache:
                continue
                
            # 对于每个候选拼音，使用简化的过滤条件
            for cache_pinyin, idioms in self.idiom_pinyin_cache[length].items():
                # 1. 简化过滤：只检查第一个字符是否匹配（提高效率同时保证基本相关性）
                if pinyin[0] != cache_pinyin[0]:
                    continue
                
                # 2. 精确计算匹配率（去掉了过于严格的预过滤）
                match_rate = calculate_match_rate(pinyin, cache_pinyin)
                if match_rate >= threshold:
                    # 为每个成语记录匹配度
                    for idiom in idioms:
                        matched_with_scores.append((-match_rate, idiom))  # 使用负号进行降序排序
                        
                        # 如果已经找到足够数量的结果，可以提前结束搜索
                        if max_count > 0 and len(matched_with_scores) >= max_count * 2:  # 预留一些缓冲区用于去重
                            break
                
                # 如果已经找到足够数量的结果，可以提前结束搜索
                if max_count > 0 and len(matched_with_scores) >= max_count * 2:
                    break
            
            # 如果已经找到足够数量的结果，可以提前结束搜索
            if max_count > 0 and len(matched_with_scores) >= max_count * 2:
                break
        
        # 先排序（按匹配度降序），再去重
        # 使用负号排序是为了避免自定义排序函数，提高性能
        matched_with_scores.sort()
        
        # 去重并提取成语列表
        seen = set()
        result = []
        for _, idiom in matched_with_scores:
            if idiom not in seen:
                seen.add(idiom)
                result.append(idiom)
                
                # 应用max_count限制，找到足够数量就停止
                if max_count > 0 and len(result) >= max_count:
                    break
        
        return result

    def find_idioms_in_sentence(self, sentence: str, fuzzy_threshold: float = 0.8, max_count: int = 10) -> list:
        """
        核心修改：返回仅包含成语名称的一维列表，精准在前，模糊在后
        1. 提取元组中的成语字符串，去掉句子片段
        2. 全局去重，避免精准和模糊中出现重复成语
        3. 支持max_count参数，在搜索过程中限制结果数量
        """
        # 清洗句子：移除非汉字字符（单次处理）
        clean_sentence = re.sub(r'[^\u4e00-\u9fa5]', '', sentence)
        if len(clean_sentence) < 4:
            return []  # 无结果返回空列表
        
        exact_idiom_set = set()  # 仅存成语名称的精准集合
        fuzzy_idiom_set = set()  # 用于去重的模糊成语集合
        fuzzy_list = []  # 存储排序后的模糊成语列表
        sentence_len = len(clean_sentence)

        # 仅遍历4字片段（核心优化：减少2/3的循环次数）
        for i in range(sentence_len - 3):
            # 检查是否已经收集了足够的精准结果
            if max_count > 0 and len(exact_idiom_set) >= max_count:
                break

            fragment = clean_sentence[i:i+4]
            fragment_pinyin = chinese_to_pinyin(fragment)
            if not fragment_pinyin:
                continue

            # 精准检索：提取成语名称，加入精准集合
            exact_idioms = self.retrieve_exact(fragment_pinyin)
            exact_idiom_set.update(exact_idioms)

            # 如果需要模糊匹配且还需要更多结果
            if max_count <= 0 or len(exact_idiom_set) + len(fuzzy_idiom_set) < max_count:
                # 计算还需要的模糊结果数量
                remaining_needed = max_count - len(exact_idiom_set) - len(fuzzy_idiom_set) if max_count > 0 else 0
                
                # 模糊检索：提取成语名称，排除已精准匹配的，加入模糊集合
                # 传递remaining_needed参数，让retrieve_fuzzy也能提前停止
                fuzzy_idioms = self.retrieve_fuzzy(fragment_pinyin, fuzzy_threshold, remaining_needed)
                
                # 过滤掉已在精准匹配中的成语，并去重
                for idiom in fuzzy_idioms:
                    if idiom not in exact_idiom_set and idiom not in fuzzy_idiom_set:
                        fuzzy_idiom_set.add(idiom)
                        fuzzy_list.append(idiom)
                        
                        # 检查是否已经收集了足够的结果
                        if max_count > 0 and len(exact_idiom_set) + len(fuzzy_idiom_set) >= max_count:
                            break

        # 核心：拼接为纯成语列表，精准在前，模糊在后
        exact_list = list(exact_idiom_set)
        final_idiom_list = exact_list + fuzzy_list  # 精准成语 + 排序后的模糊成语

        # 应用max_count限制
        if max_count > 0:
            final_idiom_list = final_idiom_list[:max_count]

        logger.info(f"检索完成，精准匹配{len(exact_list)}条，模糊匹配{len(fuzzy_list)}条，总计{len(final_idiom_list)}条")
        return final_idiom_list


# 模块级别初始化检索器（预缓存仅执行一次）
current_dir = os.path.abspath(os.path.dirname(__file__))
json_name = os.path.join(current_dir, "idiom_trie.json")
with open(json_name, "r", encoding="utf-8") as f:
    content = f.read()
# 创建全局检索器实例，所有search_idiom调用共享
_retriever_instance = IdiomRetriever(content)


# -------------------------- 4.暴露函数供外部调用 --------------------------
def search_idiom(sentence: str, fuzzy_threshold: float = 0.8, max_count: int = 5) -> list:
    """搜索句子中的成语，使用预初始化的检索器实例"""
    return _retriever_instance.find_idioms_in_sentence(sentence, fuzzy_threshold, max_count)
    
# -------------------------- 5. 测试检索（适配纯成语列表的输出格式） --------------------------
if __name__ == "__main__":
    # 测试句子
    test_sentence1 = "他做事情总是三心二意，从来没有一心一意的时候。"
    test_sentence2 = "他一欣一意地完成工作，结果却画蛇添足了。"

    # 识别成语（计时查看优化效果）
    import time
    start = time.time()
    result1 = search_idiom(test_sentence1)
    result2 = search_idiom(test_sentence2, fuzzy_threshold=0.8)
    end = time.time()

    # 输出结果：纯成语列表格式
    print("===== 测试句子1结果 =====")
    print(f"匹配成语：{result1}")
    print("\n===== 测试句子2结果 =====")
    print(f"匹配成语：{result2}")
    print(f"\n总检索耗时：{end - start:.4f} 秒")