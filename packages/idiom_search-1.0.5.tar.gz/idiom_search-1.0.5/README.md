检索语句中是否有成语（Python 版）
=============================

   
用于检索语句中是否有成语。

## 关于

* Gitee: <https://gitee.com/cnhsqk/idiom_search>  
* PyPI: <https://pypi.org/project/idiom_search/> 
* Python version: >= 3.6.0
* License: MIT license  

## 安装

    $ pip install idiom-search

## 升级

    $ pip install -U idiom-search
     

## 依赖库

    pypinyin>=0.55.0

## 使用示例

首先导入库 
```
import idiom_search as idiom
``` 

### 检索一句话中是否包含成语。 
```
idiom.search_idiom('他一欣一意地完成工作，结果却画蛇添足了。')
>>> True
```

#### 功能说明：
``` 
search_idiom(sentence, fuzzy_threshold = 0.8)
    :param sentence: str,一句话
    :param fuzzy_threshold: int, 模糊匹配阈值，默认为：0.8。 值越高要求越精确。
    :return: list 按匹配有限度排列。匹配度越高的在数组中排行越靠前
```

实用式例：    

```
idiom.search_idiom(word='他一欣一意地完成工作，结果却画蛇添足了。')
>>> ['一心一意', '画蛇添足', '一心一力', '一心一计']
```

## 资源文件

* 源数据来源：https://github.com/pwxcoo/chinese-xinhua。  


## Lincese

    MIT License
    
    Copyright (c) 2025 tangwei-dev
    
