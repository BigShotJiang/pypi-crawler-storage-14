# tessbind

[![Actions Status][actions-badge]][actions-link]

[![PyPI version][pypi-version]][pypi-link]
[![PyPI platforms][pypi-platforms]][pypi-link]

<!-- SPHINX-START -->

<!-- prettier-ignore-start -->
[actions-badge]:            https://github.com/elohmeier/tessbind/workflows/CI/badge.svg
[actions-link]:             https://github.com/elohmeier/tessbind/actions
[pypi-link]:                https://pypi.org/project/tessbind/
[pypi-platforms]:           https://img.shields.io/pypi/pyversions/tessbind
[pypi-version]:             https://img.shields.io/pypi/v/tessbind

<!-- prettier-ignore-end -->
