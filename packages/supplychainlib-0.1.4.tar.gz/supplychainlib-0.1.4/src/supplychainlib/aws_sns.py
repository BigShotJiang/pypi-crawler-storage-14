# supplychainlib/aws_sns.py

import boto3
from django.conf import settings

class SNSManager:
    def __init__(self):
        self.sns_client = boto3.client('sns', region_name=settings.AWS_REGION)

    def ensure_topic_and_subscription(self, customer_email):
        topic_name = f"customer-order-{customer_email.replace('@','-').replace('.','-')}"
        topic_response = self.sns_client.create_topic(Name=topic_name)
        topic_arn = topic_response["TopicArn"]

        # Subscribe the customer ONLY if not subscribed
        subscribe = self.sns_client.list_subscriptions_by_topic(TopicArn=topic_arn)
        subscribed = any(subscribe["Endpoint"] == customer_email for sub in subscribe["Subscriptions"])

        if not subscribed:
            self.sns_client.subscribe(
                TopicArn=topic_arn,
                Protocol="email",
                Endpoint=customer_email
            )
        return topic_arn


    def send_order_notification(self, customer_email, order_id, product_name, quantity, total_price):
        # Ensure topic & email subscription, then send order status notification to the customer
        
        topic_arn = self.ensure_topic_and_subscription(customer_email)
        subject = f"Order Update - {order_id}"
        message = f"""Dear Customer,
Your order status has changed!
Order Details:
Order ID: {order_id}
Product: {product_name}
Quantity: {quantity}
Total Price: ${total_price:.2f}
Customer Email: {customer_email}

Thank you for shopping with us,
Gourmet Coffee Supply Chain
"""
        try:
            response = self.sns_client.publish(
                TopicArn=topic_arn,
                Subject=subject,
                Message=message
            )
            print(f"SNS notification sent successfully. MessageId: {response['MessageId']}")
            return True
        except Exception as e:
            print(f"Error sending SNS notification: {e}")
            return False
