import boto3
import os
from botocore.exceptions import ClientError


class S3BucketManager:
    # Invoice operations for the S3 bucket
    
    def __init__(self, bucket_name='gourmet-coffee-invoices', region='us-east-1'):
        self.bucket_name = bucket_name
        self.region = region
        self.s3_client = boto3.client('s3', region_name=region)
    
    def create_bucket(self): 
        # Create S3 bucket if it doesn't exist 
        try: 
            self.s3_client.head_bucket(Bucket=self.bucket_name) 
            print(f"Bucket {self.bucket_name} already exists") 
            return True 
        except ClientError as e: 
            error_code = e.response['Error']['Code'] 
            if error_code == '404': 
                try: 
                    self.s3_client.create_bucket(Bucket=self.bucket_name) 
                    print(f"Bucket {self.bucket_name} created successfully") 
                    return True
                except ClientError as create_error: 
                    print(f"Error creating bucket: {create_error}") 
                    return False 
            print(f"Error checking bucket: {e}") 
            return False
    
    def list_invoices(self):
        # List all invoices
        try:
            response = self.s3_client.list_objects_v2(
                Bucket=self.bucket_name,
                Prefix='invoices/'
            )
            invoices = []
            for obj in response.get('Contents', []):
                key = obj['Key']
                order_id = key.split('/')[-1].replace(".pdf", "")
                invoices.append({
                    "order_id": order_id,
                    "key": key,
                    "size": obj["Size"],
                    "last_modified": obj["LastModified"]
                })
            return invoices

        except ClientError as e:
            print(f"Error listing invoices: {e}")
            return []

    def generate_download_url(self, invoice_key, expiration=3600):
        # Generate URL for download
        try:
            return self.s3_client.generate_presigned_url(
                'get_object',
                Params={
                    'Bucket': self.bucket_name,
                    'Key': invoice_key
                },
                ExpiresIn=expiration
            )
        except ClientError as e:
            print(f"Error generating download URL: {e}")
            return None

    def upload_invoice(self, file_path, object_key):
        # Upload invoice to S3
        try:
            self.s3_client.upload_file(file_path, self.bucket_name, object_key)
            print(f"Invoice uploaded: {self.bucket_name}/{object_key}")
            return True
        except ClientError as e:
            print(f"Upload failed: {e}")
            return False

    def delete_invoice(self, key):
        # Delete invoice file from S3 bucket
        try:
            self.s3_client.delete_object(Bucket=self.bucket_name, Key=key)
            print(f"Deleted invoice: {key}")
            return True
        except Exception as e:
            print(f"Error deleting invoice: {e}")
            return False
