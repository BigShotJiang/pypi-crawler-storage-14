# src/discera_service/capabilities/image_gen.py (v24)
from __future__ import annotations
import os
import html
import base64
import hashlib
from io import BytesIO
from typing import Any, Dict, List, Optional

import torch
from diffusers import StableDiffusionXLPipeline
from diffusers import DPMSolverMultistepScheduler

import logging
log = logging.getLogger("discera.image_gen")

# ES image helpers (store generated images server-side)
from discera_service.images import es_images, save_image  # requires ELASTIC_URL

_PIPE: Optional[StableDiffusionXLPipeline] = None  # module-level singleton


class ImageGenCapability:
    """
    Discera capability: image_gen (v24)

    - Text-to-image via SDXL.
    - Preserves v19 behavior: robust auto-tune of settings, HTML block + base64 PNG return.
    - NEW: Stores generated image in Elasticsearch when conversation/user context is available
            (passed generically in `hints`: conversation_id, user_id).
    - Returns `meta.image_id` and emits a `meta` SSE event in streaming mode
      so the frontend can reuse the ES id for downstream detection.
    """
    name = "image_gen"

    # ---------- Descriptor & assets ----------
    @staticmethod
    def descriptor() -> Dict[str, Any]:
        return {
            "name": ImageGenCapability.name,
            "description": (
                "Generates images from text prompts using local Stable Diffusion XL. "
                "Stores the image in Elasticsearch and returns its image_id; also returns a base64 PNG for rendering."
            ),
            "intents": ["image_generation", "visualization", "art", "diagram"],
            "examples": [
                "Generate a futuristic city skyline at sunset.",
                "Create a diagram of the water cycle.",
                "Draw a cartoon cat riding a bicycle.",
            ],
            "tags": ["image", "generation", "art", "visual", "diagram", "picture"],
            "excludes": [],
        }

    @staticmethod
    def assets() -> Dict[str, List[str]]:
        css = r"""
.image-gen-result {
  margin: 12px 0;
  text-align: center;
}
.image-gen-result img {
  max-width: 100%;
  border-radius: 12px;
  box-shadow: 0 2px 12px rgba(0,0,0,0.12);
  background: #222;
}
.image-gen-caption { margin-top: 8px; color: #9ca3af; font-size: 0.92rem; }
.prompt-desc { font-size: 0.92rem; color: #9ca3af; }
"""
        return {"css": [css], "js": []}

    # ---------- utility coercers ----------
    @staticmethod
    def _pick(*vals, default=None):
        """Return the first non-empty value among vals (treat '', 'none', 'null' as empty)."""
        for v in vals:
            if v is None:
                continue
            s = str(v).strip() if isinstance(v, str) else v
            if s in ("", "none", "null"):
                continue
            return v
        return default

    @staticmethod
    def _to_int(val, default, *, lo=None, hi=None):
        """Coerce val to int with default and optional bounds."""
        if val is None or (isinstance(val, str) and val.strip().lower() in ("", "none", "null")):
            v = default
        else:
            try:
                v = int(val) if isinstance(val, int) else int(float(str(val)))
            except Exception:
                v = default
        if lo is not None:
            v = max(lo, v)
        if hi is not None:
            v = min(hi, v)
        return v

    @staticmethod
    def _to_float(val, default, *, lo=None, hi=None):
        """Coerce val to float with default and optional bounds."""
        if val is None or (isinstance(val, str) and val.strip().lower() in ("", "none", "null")):
            v = default
        else:
            try:
                v = float(val)
            except Exception:
                v = default
        if lo is not None:
            v = max(lo, v)
        if hi is not None:
            v = min(hi, v)
        return v

    # ---------- settings auto-tune (kept from v19; optional llm_gen) ----------
    def _auto_tune_image_settings(
        self,
        question: str,
        hints_in: Dict[str, Any],
        *,
        llm_gen: Any | None = None,
    ) -> Dict[str, Any]:
        """
        Prompt-aware heuristics + optional LLM extraction (if llm_gen is injected)
        for missing image knobs. Returns: width, height, steps, guidance, style, negative.
        """
        out = {
            "width": hints_in.get("width"),
            "height": hints_in.get("height"),
            "steps": hints_in.get("steps"),
            "guidance": hints_in.get("guidance"),
            "style": (hints_in.get("style") or "").strip().lower() or None,
            "negative": hints_in.get("negative"),
        }
        ql = (question or "").lower()
        want_large = any(k in ql for k in ["large", "big", "poster", "wallpaper", "high resolution", "hi-res"])

        # style detection
        if not out["style"]:
            if any(k in ql for k in ["vector", "flat", "cartoon", "illustration", "line art", "logo"]):
                out["style"] = "vector"
            elif any(k in ql for k in ["realistic", "photorealistic", "photo", "cinematic", "stars"]):
                out["style"] = "realistic"
            else:
                out["style"] = "default"

        MAX = int(os.getenv("DISCERA_IMAGE_MAX", "896"))
        MINW, MINH = 512, 384

        if out["width"] is None or out["height"] is None:
            if want_large:
                out["width"] = MAX
                out["height"] = MAX
            elif out["style"] == "vector":
                out["width"], out["height"] = 704, 512
            elif out["style"] == "realistic":
                out["width"], out["height"] = 768, 512
            else:
                out["width"], out["height"] = 640, 512

        if out["steps"] is None:
            out["steps"] = 24 if out["style"] == "vector" else 26
        if out["guidance"] is None:
            out["guidance"] = 7.5 if out["style"] == "vector" else 8.0

        if not (out["negative"] or ""):
            if out["style"] == "vector":
                out["negative"] = (
                    "blurry, out of focus, low quality, photorealistic, 3d render, noisy, watermark, text, logo"
                )
            elif out["style"] == "realistic":
                out["negative"] = (
                    "blurry, out of focus, low quality, oversaturated, caricature, cartoon, vector, watermark, text, logo"
                )
            else:
                out["negative"] = "blurry, out of focus, low quality, artifacts, noisy, watermark, text, logo"

        # Optional LLM extraction only if llm_gen is provided AND all core knobs were missing
        use_llm = bool(llm_gen)
        if use_llm and all(v is None for v in (hints_in.get("width"), hints_in.get("height"), hints_in.get("steps"), hints_in.get("guidance"))):
            try:
                instr = (
                    "Extract best image generation settings from the user request. "
                    "Return strict JSON with keys: width (int), height (int), steps (int), guidance (float), "
                    "style ('vector'|'realistic'|'default'), negative (string)."
                )
                txt = llm_gen.generate(
                    question=f"{instr}\n\nREQUEST:\n{question}",
                    contexts=[],
                    history=[],
                    concise=True,
                )
                import json as _json
                obj = _json.loads(txt) if (txt or "").strip().startswith("{") else {}
                out["width"] = int(obj.get("width", out["width"]))
                out["height"] = int(obj.get("height", out["height"]))
                out["steps"] = int(obj.get("steps", out["steps"]))
                out["guidance"] = float(obj.get("guidance", out["guidance"]))
                out["style"] = (obj.get("style") or out["style"]) or "default"
                out["negative"] = (obj.get("negative") or out["negative"]) or out["negative"]
            except Exception as _ex:
                log.debug("settings LLM extract failed: %s (using heuristics)", _ex)

        # final clamps (8 GB safe; raise caps if you have more VRAM)
        out["width"] = max(MINW, min(int(out["width"]), MAX))
        out["height"] = max(MINH, min(int(out["height"]), MAX))
        out["steps"] = max(12, min(int(out["steps"]), 28))
        out["guidance"] = max(5.0, min(float(out["guidance"]), 9.0))
        return out

    # ---------- extraction of prompt and knobs ----------
    def _extract(self, args: Any, hints: Dict[str, Any], *, llm_gen: Any | None) -> Dict[str, Any]:
        """
        Extract prompt and generation knobs from args/hints with robust coercion.
        Applies safe defaults and clamps to VRAM-friendly ranges.
        """
        prompt = (
            getattr(args, "question", None)
            or (args.get("question") if isinstance(args, dict) else None)
            or (args.get("q") if isinstance(args, dict) else None)
            or (hints.get("prompt") if isinstance(hints, dict) else None)
            or ""
        )
        prompt = str(prompt).strip()

        raw_width = self._pick(hints.get("width"), (args.get("width") if isinstance(args, dict) else None), getattr(args, "width", None))
        raw_height = self._pick(hints.get("height"), (args.get("height") if isinstance(args, dict) else None), getattr(args, "height", None))
        raw_steps = self._pick(hints.get("steps"), (args.get("steps") if isinstance(args, dict) else None), getattr(args, "steps", None))
        raw_guidance = self._pick(hints.get("guidance"), (args.get("guidance") if isinstance(args, dict) else None), getattr(args, "guidance", None))
        raw_negative = (self._pick(hints.get("negative"), (args.get("negative") if isinstance(args, dict) else None), getattr(args, "negative", None), default="") or "").strip()
        raw_style = (self._pick(hints.get("style"), (args.get("style") if isinstance(args, dict) else None), getattr(args, "style", None), default="") or "").strip().lower()

        need_auto = any(v in (None, "", False) for v in (raw_width, raw_height, raw_steps, raw_guidance))
        if need_auto or not raw_style or not raw_negative:
            auto = self._auto_tune_image_settings(
                prompt,
                {
                    "width": raw_width, "height": raw_height, "steps": raw_steps,
                    "guidance": raw_guidance, "style": raw_style, "negative": raw_negative,
                    "provider": hints.get("provider"), "model": hints.get("model"),
                },
                llm_gen=llm_gen,
            )
            raw_width = raw_width or auto.get("width")
            raw_height = raw_height or auto.get("height")
            raw_steps = raw_steps or auto.get("steps")
            raw_guidance = raw_guidance or auto.get("guidance")
            raw_style = raw_style or auto.get("style")
            raw_negative = raw_negative or auto.get("negative")

        width = self._to_int(raw_width, default=640, lo=256, hi=1024)
        height = self._to_int(raw_height, default=512, lo=256, hi=1024)
        steps = self._to_int(raw_steps, default=22, lo=10, hi=50)
        guidance = self._to_float(raw_guidance, default=7.0, lo=1.0, hi=12.0)

        width = max(256, min(int(width), 832))
        height = max(256, min(int(height), 832))
        steps = max(10, min(int(steps), 28))
        guidance = max(1.0, min(float(guidance), 9.0))

        seed_val = self._pick(hints.get("seed"), (args.get("seed") if isinstance(args, dict) else None), getattr(args, "seed", None), default=None)
        try:
            seed = int(seed_val) if seed_val is not None and str(seed_val).strip().lower() not in ("", "none", "null") else None
        except Exception:
            seed = None

        concise = bool(self._pick(hints.get("concise"), (args.get("concise") if isinstance(args, dict) else None), getattr(args, "concise", None), default=False))

        return {
            "prompt": prompt,
            "negative": raw_negative,
            "width": width,
            "height": height,
            "steps": steps,
            "guidance": guidance,
            "seed": seed,
            "style": raw_style or "default",
            "concise": concise,
        }

    # ---------- model loading ----------
    def _get_pipe(self) -> StableDiffusionXLPipeline:
        """
        Lazy-load the SDXL pipeline once per process; reuse thereafter.
        Prefers local weights. Respects HF_HOME/TRANSFORMERS_CACHE/DIFFUSERS_CACHE.
        Uses CPU/GPU offload to keep VRAM in check.
        """
        global _PIPE
        if _PIPE is not None:
            return _PIPE

        hf_home = os.getenv("HF_HOME", "/models/hf")
        os.environ.setdefault("HF_HOME", hf_home)
        os.environ.setdefault("TRANSFORMERS_CACHE", hf_home)
        os.environ.setdefault("DIFFUSERS_CACHE", hf_home)

        local_dir = os.getenv("SDXL_MODEL_DIR")
        model_id = os.getenv("SDXL_MODEL_ID", "stabilityai/stable-diffusion-xl-base-1.0")
        use_cuda = torch.cuda.is_available()
        dtype = torch.float16 if use_cuda else torch.float32

        if local_dir and os.path.isdir(local_dir):
            pipe = StableDiffusionXLPipeline.from_pretrained(local_dir, local_files_only=True, torch_dtype=dtype)
        else:
            pipe = StableDiffusionXLPipeline.from_pretrained(model_id, torch_dtype=dtype, cache_dir=hf_home)

        # VRAM savers
        try:
            if hasattr(pipe, "enable_vae_slicing"):
                pipe.enable_vae_slicing()
            if hasattr(pipe, "vae") and hasattr(pipe.vae, "enable_tiling"):
                pipe.vae.enable_tiling()
        except Exception:
            pass
        try:
            pipe.enable_attention_slicing()
        except Exception:
            pass
        try:
            pipe.enable_sequential_cpu_offload()
        except Exception:
            try:
                pipe.enable_model_cpu_offload()
            except Exception:
                pass
        try:
            pipe.enable_xformers_memory_efficient_attention()
        except Exception:
            try:
                torch.set_float32_matmul_precision("medium")
            except Exception:
                pass
        try:
            pipe.scheduler = DPMSolverMultistepScheduler.from_config(pipe.scheduler.config)
        except Exception:
            pass

        _PIPE = pipe
        return pipe

    # ---------- HTML helper ----------
    @staticmethod
    def _html_for_image(b64: str, prompt: str, caption: str = "") -> str:
        safe_prompt = html.escape(prompt or "")
        cap = html.escape(caption or "")

        return (
            f'<div class="image-gen-result">'
            f'<img src="data:image/png;base64,{b64}" alt="{safe_prompt}" loading="on" />'
            f'<p class="prompt-desc"><strong>Prompt:</strong> {safe_prompt}</p>'
            f'{(" · " + cap) if cap else ""}'
            f'</div>'
        )

    # ---------- execution ----------
    def run_once(self, args: Any, **kwargs) -> Dict[str, Any]:
        hints: Dict[str, Any] = kwargs.get("hints") or {}
        llm_gen = kwargs.get("llm_gen")  # injected (may be None)

        p = self._extract(args, hints, llm_gen=llm_gen)

        prompt = (
            getattr(args, "question", None)
            or (args.get("question") if isinstance(args, dict) else None)
            or (args.get("q") if isinstance(args, dict) else None)
            or (hints.get("prompt") if isinstance(hints, dict) else None)
            or ""
        )
        prompt = str(prompt).strip()
        if not prompt:
            return {
                "answer": "Please provide a prompt for image generation.",
                "image_base64": "",
                "meta": {"capability": self.name, "error": "missing_prompt"},
            }

        log.info(
            "[image_gen] prompt=%r width=%s height=%s steps=%s guidance=%s style=%s",
            p["prompt"], p["width"], p["height"], p["steps"], p["guidance"], p.get("style", "default"),
        )

        try:
            pipe = self._get_pipe()
            device = "cuda" if torch.cuda.is_available() else "cpu"

            # seed handling (keep v19 semantics)
            seed_used = None
            if p["seed"] is not None:
                seed_used = int(p["seed"])
                generator = torch.Generator(device=device).manual_seed(seed_used)
            else:
                seed_used = int.from_bytes(os.urandom(8), "big")
                generator = torch.Generator(device=device).manual_seed(seed_used)

            with torch.inference_mode():
                image = pipe(
                    prompt=prompt,
                    negative_prompt=p["negative"] or None,
                    width=p["width"],
                    height=p["height"],
                    num_inference_steps=p["steps"],
                    guidance_scale=p["guidance"],
                    generator=generator,
                ).images[0]

            buf = BytesIO()
            image.save(buf, format="PNG")
            image_bytes = buf.getvalue()
            image_b64 = base64.b64encode(image_bytes).decode("utf-8")

            # ---------- STORE IN ELASTICSEARCH ----------
            image_id = None
            conversation_id = (hints.get("conversation_id") or "").strip() or None
            user_id = (hints.get("user_id") or "").strip() or None

            if conversation_id and user_id:
                try:
                    es = es_images()
                    sha = hashlib.sha256(image_bytes).hexdigest()
                    doc = save_image(
                        es,
                        conversation_id=conversation_id,
                        user_id=user_id,
                        filename="generated.png",
                        media_type="image/png",
                        size=len(image_bytes),
                        content_bytes=image_bytes,
                        sha256=sha,
                    )
                    image_id = doc.get("_id")
                    log.info("image_gen: stored image id=%s conversation=%s user=%s", image_id, conversation_id, user_id)
                except Exception as ex:
                    log.warning("image_gen: ES store failed (non-fatal): %s", ex)
            else:
                log.warning("image_gen: missing conversation_id/user_id in hints; skipping ES store")

            caption = "" if not p["concise"] else ""
            html_block = self._html_for_image(image_b64, prompt, caption)

            meta = {
                "capability": self.name,
                "prompt": prompt,
                "negative": p["negative"],
                "width": p["width"],
                "height": p["height"],
                "steps": p["steps"],
                "guidance": p["guidance"],
                "style": p.get("style", "default"),
                "seed_requested": p["seed"],  # what caller asked for
                "seed_used": seed_used,
                "device": "cuda" if torch.cuda.is_available() else "cpu",
            }
            if image_id:
                meta["image_id"] = image_id

            return {
                "answer": html_block,           # FE renders this directly
                "image_base64": image_b64,      # still available to the UI if needed
                "meta": meta,                   # includes image_id when stored
            }

        except Exception as ex:
            md = (
                "### Image Generation Error\n"
                f"**Prompt:** {html.escape(prompt)}\n\n"
                f"Sorry, image generation failed: `{ex}`"
            )
            return {
                "answer": md,
                "image_base64": "",
                "meta": {"capability": self.name, "prompt": prompt, "error": str(ex)},
            }

    async def run_stream(self, args: Any, **kwargs):
        # stream a few events for consistency (diffusers has no token-by-token progress)
        def ev(name: str, data: Any) -> dict:
            import json as _json
            payload = _json.dumps(data, ensure_ascii=False) if isinstance(data, (dict, list)) else ("" if data is None else str(data))
            return {"event": name, "data": payload}

        yield ev("generation_started", {"capability": self.name})

        result = self.run_once(args, **kwargs)

        # ask FE to inject capability assets (CSS) once per session
        try:
            assets = self.assets()
            yield ev("assets", {"css": assets.get("css", []), "js": assets.get("js", [])})
        except Exception:
            pass

        # main HTML
        yield ev("token", result.get("answer", ""))

        # NEW: stream meta (includes image_id when present) so FE can reuse it later
        if isinstance(result, dict) and isinstance(result.get("meta"), dict):
            yield ev("meta", result["meta"])

        yield ev("generation_done", {})
        yield ev("done", {})


def register(registry):
    registry.register(ImageGenCapability())
