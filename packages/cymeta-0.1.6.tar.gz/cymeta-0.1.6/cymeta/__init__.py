"""
CyMeta: Cyclic Meta-Dictionary Compression for Transformer Models

A novel weight-compression and weight-reconstruction approach that replaces
large transformer weight matrices with compact meta-dictionaries, integer
index maps, and tiny contextual gating networks.
"""

__version__ = "0.1.6"

from cymeta.dictionary import MetaDictionary
from cymeta.index_map import IndexMap
from cymeta.gating import GatingNetwork
from cymeta.reconstruct import reconstruct_weights
from cymeta.models.linear import CyMetaLinear
from cymeta.models.attention import CyMetaAttention, CyMetaMultiHeadAttention
from cymeta.models.ffn import CyMetaFFN

__all__ = [
    "MetaDictionary",
    "IndexMap",
    "GatingNetwork",
    "reconstruct_weights",
    "CyMetaLinear",
    "CyMetaAttention",
    "CyMetaMultiHeadAttention",
    "CyMetaFFN",
]

