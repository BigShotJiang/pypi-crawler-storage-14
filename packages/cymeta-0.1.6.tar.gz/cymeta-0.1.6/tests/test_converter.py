"""Tests for HuggingFace conversion utilities."""

import torch
import torch.nn as nn

from cymeta.exports.converter import (
    ConversionConfig,
    convert_model_linear_layers,
)
from cymeta.models.linear import CyMetaLinear


class TinyModel(nn.Module):
    """Simple feed-forward network for conversion tests."""

    def __init__(self):
        super().__init__()
        self.linear1 = nn.Linear(16, 32)
        self.block = nn.Sequential(
            nn.Linear(32, 32),
            nn.ReLU(),
            nn.Linear(32, 8),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = self.linear1(x)
        x = self.block(x)
        return x


def test_convert_model_linear_layers():
    """Validate linear layers get replaced with CyMetaLinear and remain functional."""
    model = TinyModel()
    config = ConversionConfig(dict_size=8, compress_iterations=5, verbose=False)

    converted_model, converted_count = convert_model_linear_layers(model, config=config)

    assert converted_count == 3
    assert isinstance(converted_model.linear1, CyMetaLinear)
    assert isinstance(converted_model.block[0], CyMetaLinear)
    assert isinstance(converted_model.block[2], CyMetaLinear)

    x = torch.randn(2, 16)
    y = converted_model(x)
    assert y.shape == (2, 8)


