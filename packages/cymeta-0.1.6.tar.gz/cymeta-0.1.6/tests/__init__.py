"""Tests for CyMeta library."""

