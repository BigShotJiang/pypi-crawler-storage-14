"""
LogVault Client
Simple, intuitive API for logging audit events
"""

import requests
import asyncio
import aiohttp
from datetime import datetime
from typing import Optional, Dict, Any, Tuple, Union
import secrets
import json

from .exceptions import (
    AuthenticationError,
    RateLimitError,
    ValidationError,
    APIError
)


class Client:
    """
    Synchronous LogVault client

    Example:
        import logvault

        client = logvault.Client("lv_live_...")

        # Log an event (1 line!)
        event = client.log(
            action="user.login",
            user_id="user_123",
            resource="app",
            metadata={"ip": "1.2.3.4"}
        )

        print(f"Logged event: {event['id']}")
    """

    def __init__(
        self,
        api_key: str,
        base_url: str = "https://api.logvault.io",
        timeout: Union[float, Tuple[float, float]] = (5.0, 30.0),
        enable_nonce: bool = False
    ):
        """
        Initialize LogVault client

        Args:
            api_key: Your LogVault API key (lv_live_... or lv_test_...)
            base_url: API base URL (default: production)
            timeout: Request timeout (connect, read) tuple or single float. Default: (5.0, 30.0)
            enable_nonce: Enable replay protection (adds nonce header)
        """
        if not api_key:
            raise AuthenticationError("API key is required")

        if not api_key.startswith(("lv_live_", "lv_test_")):
            raise AuthenticationError("API key must start with lv_live_ or lv_test_")

        self.api_key = api_key
        self.base_url = base_url.rstrip('/')
        self.timeout = timeout
        self.enable_nonce = enable_nonce

        self.session = requests.Session()
        self.session.headers.update({
            'X-API-Key': self.api_key,
            'User-Agent': 'logvault-python/0.1.0',
            'Content-Type': 'application/json'
        })

    def log(
        self,
        action: str,
        user_id: str,
        resource: str = "app",
        metadata: Optional[Dict[str, Any]] = None,
        timestamp: Optional[datetime] = None
    ) -> Optional[Dict[str, Any]]:
        """
        Log an audit event (the main method!)

        Args:
            action: Action taken (format: entity.verb, e.g., "user.login")
            user_id: User who performed the action
            resource: Resource affected (default: "app")
            metadata: Additional event data (optional)
            timestamp: Event timestamp (default: now)

        Returns:
            Event response with ID and signature, or None if serialization fails (fail-safe).

        Example:
            event = client.log(
                action="document.delete",
                user_id="user_123",
                resource="document:456",
                metadata={"reason": "GDPR request"}
            )
        """
        # Prepare payload
        payload = {
            "action": action,
            "user_id": user_id,
            "resource": resource,
            "metadata": metadata or {}
        }

        if timestamp:
            payload["timestamp"] = timestamp.isoformat()

        # Defensive Coding: Fail-Safe Serialization
        # If serialization fails (e.g. circular ref), do NOT crash the user's app.
        try:
            json_payload = json.dumps(payload)
            # Naive size check on serialized payload
            if len(json_payload) > 1024 * 1024: # 1MB limit
                raise ValidationError("Log payload too large (max 1MB)")
        except (TypeError, ValueError) as e:
            # In a real SDK, you might want to log this to stderr or a fallback logger
            # For now, we fail silently/safely to protect the main application flow.
            # Alternatively, raise a non-fatal warning.
            # Here we choose to raise ValidationError to inform the dev, but ensure
            # it's specific to data issues, not crashes.
            # Actually, "Fail Safe" usually means returning None or logging.
            # Let's log to stderr and return None to ensure app stability.
            import sys
            print(f"[LogVault] Error: Could not serialize log payload: {e}", file=sys.stderr)
            return None

        # Add nonce if enabled
        headers = {}
        if self.enable_nonce:
            headers['X-Nonce'] = secrets.token_urlsafe(32)

        # Make request
        try:
            # requests.post with json= parameter does serialization internally,
            # but we already serialized to check size/validity.
            # So we pass data=json_payload and correct content-type is already set in session.
            response = self.session.post(
                f"{self.base_url}/v1/events",
                data=json_payload,
                headers=headers,
                timeout=self.timeout
            )

            # Handle errors
            if response.status_code == 401:
                raise AuthenticationError("Invalid API key")
            elif response.status_code == 429:
                raise RateLimitError(
                    "Rate limit exceeded",
                    retry_after=int(response.headers.get('Retry-After', 60))
                )
            elif response.status_code == 422:
                raise ValidationError(f"Validation error: {response.text}")
            elif response.status_code >= 400:
                # Sanitize: Don't include headers/full request in error message
                raise APIError(
                    f"API error: {response.text}",
                    status_code=response.status_code,
                    response=response.json() if response.content else {}
                )

            response.raise_for_status()
            return response.json()

        except requests.exceptions.Timeout as e:
            raise APIError("Request timeout") from e
        except requests.exceptions.RequestException as e:
            # Sanitize connection errors
            raise APIError(f"Connection error to LogVault: {type(e).__name__}") from e

    def list_events(
        self,
        page: int = 1,
        page_size: int = 50,
        user_id: Optional[str] = None,
        action: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        List audit events (paginated)

        Args:
            page: Page number (default: 1)
            page_size: Events per page (default: 50)
            user_id: Filter by user ID (optional)
            action: Filter by action (optional)

        Returns:
            Paginated list of events
        """
        params = {
            "page": page,
            "page_size": page_size
        }

        if user_id:
            params["user_id"] = user_id
        if action:
            params["action"] = action

        try:
            response = self.session.get(
                f"{self.base_url}/v1/events",
                params=params,
                timeout=self.timeout
            )

            # Handle errors (same as log())
            if response.status_code == 401:
                raise AuthenticationError("Invalid API key")
            elif response.status_code >= 400:
                raise APIError(
                    f"API error: {response.text}",
                    status_code=response.status_code
                )

            response.raise_for_status()
            return response.json()

        except requests.exceptions.Timeout as e:
            raise APIError("Request timeout") from e
        except requests.exceptions.RequestException as e:
            raise APIError(f"Connection error to LogVault: {type(e).__name__}") from e

    def close(self):
        """Close HTTP session"""
        self.session.close()

    def __enter__(self):
        """Context manager support"""
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """Context manager cleanup"""
        self.close()


class AsyncClient:
    """
    Async LogVault client (for async/await)

    Example:
        import logvault
        import asyncio

        async def main():
            async with logvault.AsyncClient("lv_live_...") as client:
                event = await client.log(
                    action="user.login",
                    user_id="user_123"
                )
                print(f"Logged: {event['id']}")

        asyncio.run(main())
    """

    def __init__(
        self,
        api_key: str,
        base_url: str = "https://api.logvault.io",
        timeout: Union[float, Tuple[float, float]] = (5.0, 30.0),
        enable_nonce: bool = False
    ):
        """Initialize async LogVault client"""
        if not api_key:
            raise AuthenticationError("API key is required")

        if not api_key.startswith(("lv_live_", "lv_test_")):
            raise AuthenticationError("API key must start with lv_live_ or lv_test_")

        self.api_key = api_key
        self.base_url = base_url.rstrip('/')
        # aiohttp expects a single total timeout or ClientTimeout object
        # If tuple is provided, we sum it or use the read part as approximation for now,
        # but strictly speaking aiohttp handles timeouts differently.
        # For simplicity in this version, we use the second value (total/read) if it's a tuple.
        if isinstance(timeout, tuple):
            total_timeout = timeout[1]
            connect_timeout = timeout[0]
            self.timeout = aiohttp.ClientTimeout(total=total_timeout, connect=connect_timeout)
        else:
            self.timeout = aiohttp.ClientTimeout(total=timeout)

        self.enable_nonce = enable_nonce

        self.session: Optional[aiohttp.ClientSession] = None

    async def _ensure_session(self):
        """Lazy session creation"""
        if self.session is None:
            self.session = aiohttp.ClientSession(
                headers={
                    'X-API-Key': self.api_key,
                    'User-Agent': 'logvault-python/0.1.0',
                    'Content-Type': 'application/json'
                },
                timeout=self.timeout
            )

    async def log(
        self,
        action: str,
        user_id: str,
        resource: str = "app",
        metadata: Optional[Dict[str, Any]] = None,
        timestamp: Optional[datetime] = None
    ) -> Optional[Dict[str, Any]]:
        """Log an audit event (async)"""
        await self._ensure_session()

        # Prepare payload
        payload = {
            "action": action,
            "user_id": user_id,
            "resource": resource,
            "metadata": metadata or {}
        }

        if timestamp:
            payload["timestamp"] = timestamp.isoformat()

        # Defensive Coding: Fail-Safe Serialization
        try:
            json_payload = json.dumps(payload)
            if len(json_payload) > 1024 * 1024: # 1MB limit
                raise ValidationError("Log payload too large (max 1MB)")
        except (TypeError, ValueError) as e:
            import sys
            print(f"[LogVault] Error: Could not serialize log payload: {e}", file=sys.stderr)
            return None

        # Add nonce if enabled
        headers = {}
        if self.enable_nonce:
            headers['X-Nonce'] = secrets.token_urlsafe(32)

        # Make request
        try:
            async with self.session.post(
                f"{self.base_url}/v1/events",
                data=json_payload, # Use pre-serialized data
                headers=headers
            ) as response:
                # Handle errors
                if response.status == 401:
                    raise AuthenticationError("Invalid API key")
                elif response.status == 429:
                    raise RateLimitError(
                        "Rate limit exceeded",
                        retry_after=int(response.headers.get('Retry-After', 60))
                    )
                elif response.status == 422:
                    text = await response.text()
                    raise ValidationError(f"Validation error: {text}")
                elif response.status >= 400:
                    text = await response.text()
                    raise APIError(
                        f"API error: {text}",
                        status_code=response.status
                    )

                return await response.json()

        except asyncio.TimeoutError as e:
            raise APIError("Request timeout") from e
        except aiohttp.ClientError as e:
            raise APIError(f"Connection error: {type(e).__name__}") from e

    async def list_events(
        self,
        page: int = 1,
        page_size: int = 50,
        user_id: Optional[str] = None,
        action: Optional[str] = None
    ) -> Dict[str, Any]:
        """List audit events (async)"""
        await self._ensure_session()

        params = {
            "page": page,
            "page_size": page_size
        }

        if user_id:
            params["user_id"] = user_id
        if action:
            params["action"] = action

        try:
            async with self.session.get(
                f"{self.base_url}/v1/events",
                params=params
            ) as response:
                # Handle errors
                if response.status == 401:
                    raise AuthenticationError("Invalid API key")
                elif response.status >= 400:
                    text = await response.text()
                    raise APIError(
                        f"API error: {text}",
                        status_code=response.status
                    )

                return await response.json()

        except asyncio.TimeoutError as e:
            raise APIError("Request timeout") from e
        except aiohttp.ClientError as e:
            raise APIError(f"Connection error: {type(e).__name__}") from e

    async def close(self):
        """Close HTTP session"""
        if self.session:
            await self.session.close()
            self.session = None

    async def __aenter__(self):
        """Async context manager support"""
        await self._ensure_session()
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Async context manager cleanup"""
        await self.close()
