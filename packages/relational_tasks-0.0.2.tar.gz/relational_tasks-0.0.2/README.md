# relational_tasks

Relational Reasoning Tasks for Artificial Neural Networks is a python3 library for generating relational reasoning tasks to evaluate relation and compositional reasoning for different artificial neural network architectures.

To install the most recent version available on [pypi](https://pypi.org/project/relational_tasks/):

```console
pip3 install relational_tasks
```

To install the most recent version available [here on github](https://github.com/abrsvn/relational_tasks) (likely more recent than what's available on pypi):

```console
git clone git@github.com:abrsvn/relational_tasks.git
cd relational_tasks
pip3 install .
```

The library is compatible with Python versions `>=3.12`.

If you use this library in your work, please cite it. Here's a basic BibTeX entry:

```
@misc{relational_tasks,
    author = {Adrian Brasoveanu, Jakub Dotlacil},
    title  = {{Relational Reasoning Tasks for Artificial Neural Networks}},
    year   = 2025,
    url    = {https://github.com/abrsvn/relational_tasks}
}
```
