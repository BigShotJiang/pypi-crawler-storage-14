"""
Relational Reasoning Tasks for Artificial Neural Networks
=========================================================

A library for generating relational reasoning tasks to evaluate the relational and compositional reasoning of different artificial neural network architectures.
"""

__version__ = "0.0.1"
__author__ = "Adrian Brasoveanu, Jakub Dotlacil"
