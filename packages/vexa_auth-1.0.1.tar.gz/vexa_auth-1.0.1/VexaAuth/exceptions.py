"""Custom exceptions for VexaAuth SDK"""


class VexaAuthError(Exception):
    """Base exception for all VexaAuth errors"""
    pass


class AuthenticationError(VexaAuthError):
    """Raised when authentication fails"""
    pass


class ValidationError(VexaAuthError):
    """Raised when validation fails"""
    pass


class NetworkError(VexaAuthError):
    """Raised when network request fails"""
    pass


class RateLimitError(VexaAuthError):
    """Raised when rate limit is exceeded"""
    pass
