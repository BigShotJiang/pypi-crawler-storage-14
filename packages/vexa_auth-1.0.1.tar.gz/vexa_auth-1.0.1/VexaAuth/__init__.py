"""
VexaAuth Python SDK
A modern, type-safe authentication SDK for VexaAuth
"""

from .client import VexaAuthClient
from .exceptions import VexaAuthError, AuthenticationError, ValidationError

__version__ = "1.0.0"
__all__ = ["VexaAuthClient", "VexaAuthError", "AuthenticationError", "ValidationError"]
