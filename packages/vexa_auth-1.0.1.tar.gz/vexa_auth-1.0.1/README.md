# VexaAuth Python SDK

[![PyPI version](https://badge.fury.io/py/vexa-auth.svg)](https://badge.fury.io/py/vexa-auth)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

Official Python SDK for VexaAuth - The modern, secure, and easy-to-use authentication & license management system.

## 🚀 Features

- **License Management**: Verify, activate, deactivate, and redeem licenses.
- **User Authentication**: Secure login, registration, and session management.
- **2FA Support**: Enable, verify, and manage Two-Factor Authentication.
- **User Variables**: Store and retrieve custom user data (cloud variables).
- **File Management**: Securely upload and download files with license restrictions.
- **Online Users**: Track and manage connected users in real-time.

## 📦 Installation

Install the package via pip:

```bash
pip install vexa-auth
```

## 🛠️ Quick Start

### Initialization

```python
from VexaAuth import VexaAuthClient

# Initialize with your API Key
client = VexaAuthClient(api_key="your_api_key_here")
```

### License Verification

```python
# Verify a license key
result = client.verify_license(
    license_key="XXXX-XXXX-XXXX-XXXX",
    hwid="user-hwid-123"  # Optional: Hardware ID for device locking
)

if result.get('valid'):
    print(f"License is valid! Type: {result['type']}")
else:
    print(f"Invalid license: {result.get('message')}")
```

### User Login

```python
try:
    user = client.login(
        username="user@example.com",
        password="secure_password",
        hwid="user-hwid-123"
    )
    print(f"Welcome back, {user['username']}!")
    print(f"Session Token: {user['token']}")
except Exception as e:
    print(f"Login failed: {e}")
```

### Cloud Variables

Store custom data for your users securely in the cloud.

```python
# Set a variable
client.set_user_variable("theme", "dark_mode")

# Get a variable
theme = client.get_user_variable("theme")
print(f"User theme: {theme['value']}")
```

### File Handling

Securely download files restricted to valid license holders.

```python
try:
    response = client.download_file(
        file_id="file_123",
        app_id="app_123",
        app_secret="secret_123",
        license_key="XXXX-XXXX-XXXX-XXXX"
    )
    
    with open("update.zip", "wb") as f:
        f.write(response.content)
    print("Download complete!")
except Exception as e:
    print(f"Download failed: {e}")
```

## 📚 Documentation

For full API documentation and advanced usage, please visit our [official documentation](https://docs.vexaauth.com).

## 🤝 Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

## 📄 License

This project is licensed under the MIT License - see the LICENSE file for details.
