#!/usr/bin/python3
"""
Модуль работы с графиками.
"""
from .graph_interface import IGraph

__all__ = ["IGraph"]
