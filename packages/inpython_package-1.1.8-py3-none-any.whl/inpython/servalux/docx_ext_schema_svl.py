from inpython.intools.in_docx_extract_canvas import extract_canvas_docx

def extract_schemas(file_to_extract,final_file):
    canvas = []
    canvas.append('<w:tbl><w:tr><w:tc><w:p><w:r><w:drawing><wp:inline><wp:docPr name="(\\.emf$|\\.wmf$)">*</wp:docPr></wp:inline></w:drawing></w:r></w:p></w:tc></w:tr></w:tbl>')
    canvas.append('<w:tbl><w:tr><w:tc><w:p><w:r><w:drawing><wp:inline><a:graphic><a:graphicData><pic:pic><pic:blipFill><a:blip link-rel="r:embed#(\\.wmf$|\\.png$)">*</a:blip></pic:blipFill></pic:pic></a:graphicData></a:graphic></wp:inline></w:drawing></w:r></w:p></w:tc></w:tr></w:tbl>')
    canvas_end = '<w:tbl><w:tr><w:tc><w:p><w:r><w:t>(Somme|Sous-total|Total HT net)</w:t></w:r></w:p></w:tc></w:tr></w:tbl>'

    extract_canvas_docx(
        file_to_extract,
        final_file,
        canvas,
        True,
        True,
        canvas_end
    )