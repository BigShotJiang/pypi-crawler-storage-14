# inpython.servalux init file
# executed when 'from inpython.servalux import *'

# !! update the list when new modules are added !!

__all__ = ["servalux-devis","docx_ext_schema_svl"]
