.. _ref_cli:

Command-line interface
======================

Use the ``ansys-launcher`` command-line interface to edit default
launch configurations.

Each product plugin defines configuration options for its products.

.. click:: ansys.tools.common.launcher._cli:cli
    :prog: ansys-launcher
    :nested: full
