# sage_setup: distribution = sagemath-cmr

from sage.all__sagemath_cmr import *
