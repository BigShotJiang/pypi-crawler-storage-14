"""Generated gRPC client stubs for Data Plane communication."""

# Import message types from generated proto
from . import rule_installation_pb2
from . import rule_installation_pb2_grpc

# Re-export for convenience
EnforceRequest = rule_installation_pb2.EnforceRequest
EnforceResponse = rule_installation_pb2.EnforceResponse
InstallRulesRequest = rule_installation_pb2.InstallRulesRequest
InstallRulesResponse = rule_installation_pb2.InstallRulesResponse
RemoveAgentRulesRequest = rule_installation_pb2.RemoveAgentRulesRequest
RemoveAgentRulesResponse = rule_installation_pb2.RemoveAgentRulesResponse
GetRuleStatsRequest = rule_installation_pb2.GetRuleStatsRequest
GetRuleStatsResponse = rule_installation_pb2.GetRuleStatsResponse
RuleInstance = rule_installation_pb2.RuleInstance
RuleEvidence = rule_installation_pb2.RuleEvidence
ParamValue = rule_installation_pb2.ParamValue
StringList = rule_installation_pb2.StringList
TableStats = rule_installation_pb2.TableStats
QueryTelemetryRequest = rule_installation_pb2.QueryTelemetryRequest
QueryTelemetryResponse = rule_installation_pb2.QueryTelemetryResponse
EnforcementSessionSummary = rule_installation_pb2.EnforcementSessionSummary
GetSessionRequest = rule_installation_pb2.GetSessionRequest
GetSessionResponse = rule_installation_pb2.GetSessionResponse

DataPlaneStub = rule_installation_pb2_grpc.DataPlaneStub

__all__ = [
    "DataPlaneStub",
    "EnforceRequest",
    "EnforceResponse",
    "InstallRulesRequest",
    "InstallRulesResponse",
    "RemoveAgentRulesRequest",
    "RemoveAgentRulesResponse",
    "GetRuleStatsRequest",
    "GetRuleStatsResponse",
    "RuleInstance",
    "RuleEvidence",
    "ParamValue",
    "StringList",
    "TableStats",
    "QueryTelemetryRequest",
    "QueryTelemetryResponse",
    "EnforcementSessionSummary",
    "GetSessionRequest",
    "GetSessionResponse",
]
