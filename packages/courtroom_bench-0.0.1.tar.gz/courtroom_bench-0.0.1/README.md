# courtroom-bench

A benchmark for evaluating LLMs in legal reasoning tasks.

## Installation

```bash
pip install courtroom-bench
```

## Usage

(Coming soon)
