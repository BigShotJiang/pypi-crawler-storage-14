import time

from electronics_fx.converter import CurrencyConverter


class _Resp429:
    status_code = 429
    text = "rate limit"

    def json(self):
        return {}


class _RespOK:
    status_code = 200
    text = "{}"

    def __init__(self, rates):
        self._rates = rates

    def json(self):
        return {"rates": self._rates}


def test_backoff_on_429(monkeypatch):
    calls = []

    def fake_get(url, params=None, headers=None, timeout=None):
        calls.append(1)
        return _Resp429()

    conv = CurrencyConverter(api_url="http://fake")
    monkeypatch.setattr("electronics_fx.converter.requests.get", fake_get)

    assert conv.convert(10, "EUR", "USD") is None
    first_call_count = len(calls)

    # Within backoff window, should not issue another HTTP call.
    assert conv.convert(5, "EUR", "USD") is None
    assert len(calls) == first_call_count


def test_convert_uses_loaded_rates(monkeypatch):
    def fake_get(url, params=None, headers=None, timeout=None):
        return _RespOK({"USD": 1.2, "EUR": 1.0})

    conv = CurrencyConverter(api_url="http://fake")
    monkeypatch.setattr("electronics_fx.converter.requests.get", fake_get)

    # First call loads rates.
    eur = conv.convert(10, "USD", "EUR")
    assert eur == 10 / 1.2  # normalized then multiplied by EUR rate (1.0)

    # Cached rates: no additional HTTP calls expected.
    monkeypatch.setattr("electronics_fx.converter.requests.get", lambda *args, **kwargs: (_ for _ in ()).throw(AssertionError("should not fetch again")))
    assert conv.convert(5, "USD", "EUR") == 5 / 1.2
