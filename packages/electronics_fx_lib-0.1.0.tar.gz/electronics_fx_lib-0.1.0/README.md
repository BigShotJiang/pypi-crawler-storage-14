# electronics-fx-lib

Currency converter library used by the Smart Inventory application. It wraps the https://api.exchangerate.host/latest endpoint and exposes a simple `CurrencyConverter` class.
