from setuptools import setup

setup(
    name="electronics-fx-lib",
    version="0.1.0",
    description="Currency converter library for Smart Inventory",
    author="Intern",
    packages=["electronics_fx"],
    install_requires=["requests>=2.30.0"],
    python_requires=">=3.11",
)
