import decimal
from typing import Dict, Iterable, List, Optional

ALLOWED_CODES = [
    "USD",
    "EUR",
    "GBP",
    "JPY",
    "CHF",
    "CAD",
    "AUD",
    "NZD",
    "CNY",
    "SEK",
    "NOK",
    "DKK",
    "INR",
    "BRL",
    "HKD",
    "SGD",
    "ZAR",
]

SYMBOLS: Dict[str, str] = {
    "USD": "$",
    "EUR": "€",
    "GBP": "£",
    "JPY": "¥",
    "CHF": "CHF",
    "CAD": "$",
    "AUD": "$",
    "NZD": "$",
    "CNY": "¥",
    "SEK": "kr",
    "NOK": "kr",
    "DKK": "kr",
    "INR": "₹",
    "BRL": "R$",
    "HKD": "$",
    "SGD": "$",
    "ZAR": "R",
}


def currency_symbol(code: Optional[str]) -> str:
    code = (code or "").upper()
    return SYMBOLS.get(code, code or "-")


def format_price(value, currency: Optional[str]) -> str:
    if value is None or value == "":
        return "-"
    if isinstance(value, decimal.Decimal):
        value = float(value)
    try:
        amount = float(value)
    except Exception:
        return "-"
    symbol = currency_symbol(currency)
    return f"{symbol}{amount:,.2f}"


def sorted_currencies(codes: Iterable[str]) -> List[str]:
    return sorted({c.upper() for c in codes if c})


def allowed_currencies() -> List[str]:
    return ALLOWED_CODES.copy()
