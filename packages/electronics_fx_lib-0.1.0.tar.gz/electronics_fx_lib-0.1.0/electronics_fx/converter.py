import logging
import os
import time
import requests
from dataclasses import dataclass, field
from typing import Dict, Optional

logger = logging.getLogger(__name__)


@dataclass
class CurrencyConverter:
    """OO currency converter used by Smart Inventory."""

    base_currency: str = field(default_factory=lambda: os.getenv("FX_BASE_CURRENCY", "EUR"))
    api_url: str = field(default_factory=lambda: os.getenv("FX_API_URL", "https://api.exchangerate.host/latest"))
    api_key: Optional[str] = field(default_factory=lambda: os.getenv("FX_API_KEY"))
    api_key_mode: str = field(default_factory=lambda: os.getenv("FX_API_KEY_MODE", "param"))  # param | header
    api_key_param: str = field(default_factory=lambda: os.getenv("FX_API_KEY_PARAM", "access_key"))
    api_key_header: str = field(default_factory=lambda: os.getenv("FX_API_KEY_HEADER", "apikey"))
    extra_params: Dict[str, str] = field(
        default_factory=lambda: {
            kv.split("=", 1)[0]: kv.split("=", 1)[1]
            for kv in os.getenv("FX_EXTRA_PARAMS", "").split("&")
            if kv and "=" in kv
        }
    )
    _rates: Dict[str, float] = field(default_factory=dict, init=False)
    _backoff_until: float = field(default=0, init=False)

    def _load_rates(self):
        """Load FX rates once with simple caching and rate-limit backoff."""
        now = time.time()
        if self._rates:
            logger.debug("CurrencyConverter._load_rates: using cached rates for base=%s", self.base_currency)
            return
        if now < self._backoff_until:
            logger.warning("CurrencyConverter._load_rates: in backoff until %s", self._backoff_until)
            return

        logger.debug(
            "CurrencyConverter._load_rates: fetching rates from %s with base=%s",
            self.api_url,
            self.base_currency,
        )
        try:
            params = {"base": self.base_currency}
            headers = {}
            params.update(self.extra_params)

            if self.api_key:
                if self.api_key_mode.lower() == "header":
                    headers[self.api_key_header] = self.api_key
                else:
                    params[self.api_key_param] = self.api_key

            resp = requests.get(self.api_url, params=params, headers=headers, timeout=5)
            logger.debug(
                "CurrencyConverter._load_rates: HTTP %s, response text=%s",
                resp.status_code,
                resp.text[:500],
            )
            if resp.status_code >= 400:
                logger.warning(
                    "CurrencyConverter._load_rates: http_error status=%s body=%s",
                    resp.status_code,
                    resp.text[:300],
                )
                if resp.status_code == 429:
                    # Back off for 1 hour on rate limit to avoid hammering API.
                    self._backoff_until = time.time() + 3600
                return

            data = resp.json()
            if data.get("success") is False:
                error = data.get("error") or {}
                logger.warning("CurrencyConverter._load_rates: FX API error=%s", error)
                return

            if "quotes" in data:
                source = data.get("source") or self.base_currency
                quotes = data.get("quotes") or {}
                self._rates = {k.replace(source, "", 1): v for k, v in quotes.items() if k.startswith(source)}
                self.base_currency = source
            else:
                self._rates = data.get("rates", {}) or {}

            logger.debug(
                "CurrencyConverter._load_rates: loaded %d rates (sample: %s)",
                len(self._rates),
                {k: self._rates[k] for k in list(self._rates)[:5]},
            )
        except Exception:
            logger.warning("CurrencyConverter._load_rates: failed to load FX rates", exc_info=True)
            return

    def convert(self, amount: float, from_currency: str, to_currency: str) -> Optional[float]:
        logger.debug(
            "CurrencyConverter.convert: amount=%s from=%s to=%s base=%s",
            amount,
            from_currency,
            to_currency,
            self.base_currency,
        )
        self._load_rates()

        if from_currency == to_currency:
            logger.debug("CurrencyConverter.convert: same currency, returning amount unchanged")
            return amount

        if not self._rates:
            logger.warning("CurrencyConverter.convert: no rates loaded, skipping conversion")
            return None

        if from_currency != self.base_currency:
            rate_from = self._rates.get(from_currency)
            if not rate_from:
                logger.warning("CurrencyConverter.convert: unknown source currency %s", from_currency)
                return None
            amount = amount / rate_from
            logger.debug("CurrencyConverter.convert: normalized to base=%s amount=%s", self.base_currency, amount)

        rate_to = self._rates.get(to_currency)
        if not rate_to:
            logger.warning("CurrencyConverter.convert: unknown target currency %s", to_currency)
            return None

        result = amount * rate_to
        logger.debug(
            "CurrencyConverter.convert: rate_to=%s result=%s", rate_to, result
        )
        return result

    def supported_currencies(self):
        """Return currencies available after rates load (falls back to base only)."""
        self._load_rates()
        if not self._rates:
            return [self.base_currency]
        return sorted({self.base_currency, *self._rates.keys()})
