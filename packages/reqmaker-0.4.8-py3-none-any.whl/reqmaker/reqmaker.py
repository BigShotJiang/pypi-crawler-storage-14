#!/data/data/com.termux/files/usr/bin/env python3
"""
Offline requirements.txt generator.

Features:
- Scans .py, extensionless Python scripts, .ipynb notebooks.
- Recurses directories.
- Supports scanning inside .whl, .zip, .tar.gz, .tar.xz.
- Excludes imports in stdlib using provided stdlib file.
- Resolves package names using provided mapping file.
- Offline package existence check using /sdcard/pip.txt.
- Multiprocessing for speed.
- --ignore for directories (venv, .git, etc.).
- Shows tqdm progress.
- Shows requirements.txt content at end.
- --debug for verbose logging.

Author: Isaac Onagh
"""

import os
import sys
import ast
import json
import tarfile
import zipfile
from pathlib import Path
from multiprocessing import Pool, cpu_count
from argparse import ArgumentParser
from tqdm import tqdm


# --------------------------
# UTILS
# --------------------------

def debug_print(debug, *args):
    if debug:
        print("[DEBUG]", *args)


def load_set_from_file(path, debug=False):
    s = set()
    try:
        with open(path, "r", encoding="utf-8") as f:
            for line in f:
                name = line.strip()
                if name:
                    s.add(name)
    except Exception as e:
        debug_print(debug, f"Failed loading file {path}: {e}")
    return s


def load_mapping(path, debug=False):
    mapping = {}
    try:
        with open(path, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line or "=" not in line:
                    continue
                mod, pkg = line.split("=", 1)
                mapping[mod.strip()] = pkg.strip()
    except Exception as e:
        debug_print(debug, f"Failed loading mapping {path}: {e}")
    return mapping


def is_python_script_without_extension(path):
    try:
        with open(path, "r", encoding="utf-8", errors="ignore") as f:
            first = f.readline()
            return first.startswith("#!") and "python" in first.lower()
    except:
        return False


def extract_imports_from_python(code, debug=False):
    try:
        tree = ast.parse(code)
    except Exception as e:
        debug_print(debug, f"AST parse error: {e}")
        return set()

    imports = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for n in node.names:
                imports.add(n.name.split(".")[0])
        elif isinstance(node, ast.ImportFrom):
            if node.module:
                imports.add(node.module.split(".")[0])
    return imports


def extract_imports_from_ipynb(path, debug=False):
    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
        imports = set()
        for cell in data.get("cells", []):
            if cell.get("cell_type") == "code":
                code = "".join(cell.get("source", []))
                imports |= extract_imports_from_python(code, debug)
        return imports
    except Exception as e:
        debug_print(debug, f"Failed reading notebook {path}: {e}")
        return set()


def scan_archive(path, debug=False):
    """Extract imports from .whl .zip .tar.gz .tar.xz files."""
    imports = set()
    debug_print(debug, f"Scanning archive: {path}")

    try:
        if zipfile.is_zipfile(path):
            with zipfile.ZipFile(path, "r") as z:
                for name in z.namelist():
                    if name.endswith(".py"):
                        try:
                            code = z.read(name).decode("utf-8", errors="ignore")
                            imports |= extract_imports_from_python(code, debug)
                        except Exception as e:
                            debug_print(debug, f"Error reading {name} in zip: {e}")

        elif tarfile.is_tarfile(path):
            with tarfile.open(path, "r:*") as t:
                for member in t.getmembers():
                    if member.isfile() and member.name.endswith(".py"):
                        try:
                            f = t.extractfile(member)
                            if f:
                                code = f.read().decode("utf-8", errors="ignore")
                                imports |= extract_imports_from_python(code, debug)
                        except Exception as e:
                            debug_print(debug, f"Error reading {member.name} in tar: {e}")
    except Exception as e:
        debug_print(debug, f"Archive read error {path}: {e}")

    return imports


def process_file(path, debug=False):
    """Worker used by multiprocessing."""
    path = Path(path)
    debug_print(debug, f"Processing file: {path}")

    # archive
    if path.suffix in {".whl", ".zip", ".gz", ".xz"} or any(
        str(path).endswith(ext) for ext in (".tar.gz", ".tar.xz")
    ):
        return scan_archive(path, debug)

    # jupyter
    if path.suffix == ".ipynb":
        return extract_imports_from_ipynb(path, debug)

    # python
    if path.suffix == ".py" or is_python_script_without_extension(path):
        try:
            with open(path, "r", encoding="utf-8", errors="ignore") as f:
                code = f.read()
            return extract_imports_from_python(code, debug)
        except Exception as e:
            debug_print(debug, f"Python read error {path}: {e}")
            return set()

    return set()


# --------------------------
# MAIN
# --------------------------

def main():
    parser = ArgumentParser(description="Generate requirements.txt offline.")
    parser.add_argument("--stdlib", required=True, help="Path to stdlib file.")
    parser.add_argument("--mapping", required=True, help="Path to module→package mapping file.")
    parser.add_argument("--pipdb", default="/sdcard/pip.txt", help="Local pip package list file.")
    parser.add_argument(
        "--ignore",
        nargs="*",
        default=["venv", ".venv", ".git", ".ipynb_checkpoints"],
        help="Directories to ignore.",
    )
    parser.add_argument("--debug", action="store_true", help="Enable verbose debug logs.")

    args = parser.parse_args()
    debug = args.debug

    stdlib = load_set_from_file(args.stdlib, debug)
    mapping = load_mapping(args.mapping, debug)
    pip_available = load_set_from_file(args.pipdb, debug)

    debug_print(debug, "Loaded stdlib:", len(stdlib))
    debug_print(debug, "Loaded mapping:", len(mapping))
    debug_print(debug, "Loaded pip db:", len(pip_available))

    # collect all files
    all_files = []
    for root, dirs, files in os.walk("."):
        dirs[:] = [d for d in dirs if d not in args.ignore]

        for f in files:
            path = os.path.join(root, f)
            all_files.append(path)

        # also consider non-extension scripts
        for f in files:
            if "." not in f:  # extensionless
                path = os.path.join(root, f)
                all_files.append(path)

    debug_print(debug, f"Total files collected: {len(all_files)}")

    # multiprocessing extraction
    imports = set()
    with Pool(cpu_count()) as pool:
        for result in tqdm(pool.imap_unordered(
                lambda p: process_file(p, debug), all_files),
                total=len(all_files),
                desc="Scanning"):
            imports |= result

    debug_print(debug, "Raw imports:", imports)

    # filter stdlib
    clean_imports = {m for m in imports if m not in stdlib}
    debug_print(debug, "After stdlib removal:", clean_imports)

    # mapping
    resolved = set()
    for mod in clean_imports:
        pkg = mapping.get(mod, mod)
        resolved.add(pkg)
        debug_print(debug, f"Mapping: {mod} → {pkg}")

    # offline pip check
    final_pkgs = {p for p in resolved if p in pip_available}
    debug_print(debug, "Final offline-verified packages:", final_pkgs)

    # write requirements
    with open("requirements.txt", "w", encoding="utf-8") as f:
        for pkg in sorted(final_pkgs):
            f.write(pkg + "\n")

    print("\n✔ requirements.txt created.\n")
    print("--------- requirements.txt ---------")
    with open("requirements.txt", "r", encoding="utf-8") as f:
        print(f.read())
    print("------------------------------------")


if __name__ == "__main__":
    main()
