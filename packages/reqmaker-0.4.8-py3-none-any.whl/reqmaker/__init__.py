#!/data/data/com.termux/files/usr/bin/env python3
"""
reqmaker - Offline requirements.txt generator.

Use the CLI:
    reqmaker --stdlib reqmaker/stdlib --mapping reqmaker/mapping
"""

__all__ = ["main"]

from .reqmaker import main
