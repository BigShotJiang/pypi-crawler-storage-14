from __future__ import annotations

import sys
from functools import wraps
from importlib import import_module, metadata
from typing import TYPE_CHECKING, Literal, cast

from ._helpers import check_version, split_name_op_version


if TYPE_CHECKING:
    from typing import Callable


def require_package(name_op_version: str) -> Callable:
    """
    Decorator to check if required package is installed.

    Parameters
    ----------
    name_op_version : str
        The package name, optionally with an operator and version.

    Raises
    ------
    ModuleNotFoundError
        If the package is not installed or the version does not meet the requirement.

    """
    name, op, required_version = split_name_op_version(name_op_version)
    name = name if name else ""
    op = cast(Literal["<", "<=", "==", ">=", ">"], op if op else ">=")
    required_version = required_version if required_version else ()

    def decorator(func: Callable):
        """Decorate function."""

        @wraps(func)
        def wrapper(*args, **kwargs):
            """Wrap function."""
            error_message = (
                f"{func.__name__} requires package '{name_op_version.replace(' ', '')}'"
            )

            try:
                import_module(name)

            except ModuleNotFoundError:
                raise ModuleNotFoundError(error_message)

            if required_version:
                current_version = metadata.version(name)
                current_version = tuple(
                    map(
                        lambda x: int(x) if x.isdigit() else x,
                        current_version.split("."),
                    )
                )

                if not check_version(current_version, required_version, op):
                    raise ModuleNotFoundError(error_message)

            return func(*args, **kwargs)

        return wrapper

    return decorator


def require_python(op_version: str) -> Callable:
    """
    Decorator to check if the current Python version meets the required version.

    Parameters
    ----------
    op_version : str
        The required Python version.

    Raises
    ------
    RuntimeError
        If the current Python version does not meet the requirement.

    """
    _, op, required_version = split_name_op_version(op_version)
    op = cast(Literal["<", "<=", "==", ">=", ">"], op if op else ">=")
    required_version = required_version if required_version else ()

    def decorator(func: Callable):
        @wraps(func)
        def wrapper(*args, **kwargs):
            """Wrap function."""
            if not check_version(sys.version_info[:3], required_version, op):
                print(sys.version_info)
                raise RuntimeError(
                    f"{func.__name__} requires python{op_version.replace(' ', '')}"
                )

            return func(*args, **kwargs)

        return wrapper

    return decorator
