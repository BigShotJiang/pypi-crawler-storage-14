"""demos package for agent email layer."""

