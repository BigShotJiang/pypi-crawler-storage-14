This module should allow a user to display, on smart buttons in a
picking:

- Previous pickings: the pickings associated to origin moves indicated in
  the moves in this picking
