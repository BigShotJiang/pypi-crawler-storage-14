"""Search Tools - Web search and content fetching capabilities

Usage:
    from search_tools import web_search, fetch_url

    # Search the web
    result = await web_search.ainvoke({"query": "python tutorials"})

    # Fetch full page content
    content = await fetch_url.ainvoke({"url": "https://docs.python.org/3/"})

    # Or in LangGraph
    tools = [web_search, fetch_url]
    llm_with_tools = llm.bind_tools(tools)
"""

from .python_tools import (
    web_search,
    search_google,
    search_duckduckgo,
    fetch_url,
    SearchResult,
)

__all__ = [
    "web_search",
    "search_google",
    "search_duckduckgo",
    "fetch_url",
    "SearchResult",
]
