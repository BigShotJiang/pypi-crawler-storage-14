import time
import os
from playsound import playsound

frames = [
    "🎉 HAPPY BIRTHDAY 🎉",
    "🥳 Wish You A Fantastic Year Ahead 🥳",
    "💖 Keep Smiling Always 💖",
    "✨ You Are Awesome ✨",
]


def play():
    # Play music async
    import threading

    # threading.Thread(target=lambda: playsound("music.mp3"), daemon=True).start()

    # Animation loop
    for i in range(4):
        for frame in frames:
            os.system("cls" if os.name == "nt" else "clear")
            print("\n\n" + frame.center(60))
            time.sleep(1)

    print("\n\n🎂🎂 HAPPY BIRTHDAY!!! 🎂🎂\n\n")


# if __name__ == "__main__":
#     play()
