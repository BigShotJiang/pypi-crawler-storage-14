from __future__ import annotations

__author__ = "Chris Steel"
__copyright__ = "Copyright 2025, Syntheticore Corporation"
__credits__ = ["Chris Steel"]
__date__ = "6/14/2025"
__license__ = "Syntheticore Confidential"
__version__ = "1.0"
__email__ = "csteel@syntheticore.com"
__status__ = "Production"

import logging
import os
import re
import sys
import time
import uuid
import warnings
from typing import Any, List, Tuple

from langchain_core.messages import AIMessage, HumanMessage, SystemMessage
from langchain_core.tools import tool
from langgraph.checkpoint.memory import MemorySaver
from langgraph.graph.state import CompiledStateGraph
try:
    from langchain.agents import create_agent as _create_langchain_agent  # type: ignore
except ImportError:  # pragma: no cover - fallback shim
    def _create_langchain_agent(*args, **kwargs):
        raise NotImplementedError("langchain.agents.create_agent is unavailable in this environment.")
from openai import OpenAI

from agentfoundry.agents.base_agent import BaseAgent
from agentfoundry.agents.memory.summary_utils import summarize_memory
from agentfoundry.agents.tools import memory_tools as mem_tools
from agentfoundry.agents.tools.document_reader import ingest_document
from agentfoundry.llm.llm_factory import LLMFactory  # type: ignore
from agentfoundry.registry.tool_registry import ToolRegistry
from agentfoundry.vectorstores.factory import VectorStoreFactory

# Module logger for orchestrator internals
logger = logging.getLogger('agentfoundry.agents.orchestrator')

# Suppress Pydantic underscore-field warnings
warnings.filterwarnings(
    "ignore",
    message="fields may not start with an underscore",
    category=RuntimeWarning,
)

single_agent_prompt = (
    "You are an AI Agent with access to a variety of tools, including memory, to assist the user.\n"
    "For each task, think first, which tool? what args?\n"
    "A task may require outputs and tool calls from multiple tools. Please be aware of which tools to use at each step, determine if another tool needs to be used.\n"
    "If a tool was created by the request of the user, then you can invoke that tool.\n"
    "\nMemory Usage and Tool Guidelines:\n"
    "- Store ephemeral chat turns in *thread_memory*.\n"
    "- Store personal prefs/emotions/values in *user_memory* (profile for key-value, facts for triples, semantic for text).\n"
    "- Store organization for organization-specific things like policies/compliance/organizational facts and info in *org_memory*.\n"
    "- Store general/vendor-neutral facts/docs that apply across users and organizations in *global_memory* only when not user/org-specific.\n"
    "- Summarize long text (>1K chars) before storing via summarize_any_memory.\n"
    "- Query appropriate memory level before responding; enforce security_level filters.\n"
    "- Keep k small on searches; prefer summaries for long contexts.\n"
    "- Delegate complex memory tasks to specialist agents (e.g., compliance_agent).\n"
    "- Store org/user/thread data in their respective memory tools; use global memory only for vendor-neutral or public facts. Do NOT store sensitive information in global memory.\n"
    "If the user asks for a new AI Tool, Python Tool, or Python code, delegate to the code_gen_agent (which owns the python_tool_creator tool) first, if possible.\n"
)

extra_tools_prompt = (
    "You are an agent that holds all the user-generated agentic tools. Review the provided tools and decide whether any are applicable to the user's request."
)

micropolicy_prompt = """
You are an expert in extracting compliance rules from text and return them exclusively as a valid JSON array. 

Each JSON object in the array MUST include these keys:
- "rule": (string) A short, concise title of the compliance rule.
- "description": (string) A clear, detailed explanation of the compliance rule.
- "value": (optional string) A specific numerical value or threshold explicitly mentioned in the rule.

JSON Example:
[{
"rule": "RSA encryption key length",
"description": "Minimum acceptable RSA encryption key length",
"value": "2048"
}]

STRICT REQUIREMENTS:
- You MUST respond ONLY with a valid JSON array.
- You MUST NOT include any summaries, commentary, explanations, or additional text outside the JSON structure.
- The description should be an actionable issue that can be used to CHECK if a rule is being enforced. For example, instead of "name a security officer", use something like "verify there is a named security officer"
"""

recall_vector_store = VectorStoreFactory.get_store()


# Create a specialist agent
def make_specialist(name: str, tools: List[tool], llm, prompt: str | None = None):
    """ Create a specialist agent with the given name, tools, and LLM."""
    agent_name = " ".join(name.split("_")[:-1])
    tool_list_str = "\n".join(
        f"- {t.name}: {t.description}"
        for t in tools
    )
    if prompt is None:
        prompt = (
            f"You are a {agent_name} agent.\n\n"
            "AVAILABLE TOOLS:\n"
            f"{tool_list_str}\n\n"
            "INSTRUCTIONS:\n"
            "- Assist ONLY with tasks related to the agent, or tasks that can be fulfilled by the tools provided.\n"
            "- After you're done with your tasks, respond to the supervisor directly.\n"
            "- Respond ONLY with the results of your work, do NOT include ANY other text."
        )
        if "SQL_database" in agent_name:
            prompt += "Do not assume or ask the user for the Database schema. First use a query to determine this."
    # Use LangGraph's in-memory checkpointer for thread-level state across steps.
    return _create_langchain_agent(
        model=llm,
        tools=tools,
        system_prompt=prompt,
        name=name,
        checkpointer=MemorySaver(),
    )


# Orchestrator with a single supervisor and any number of specialist agents
class Orchestrator(BaseAgent):
    """
    Orchestrator orchestrates multiple specialist agents and manages memory tools.

    Singleton: constructing ``Orchestrator(...)`` anywhere returns the same
    shared instance. The first construction performs full initialization; later
    constructions are no-ops and return the existing instance, so call sites do
    not need to change.
    """

    _instance: "Orchestrator | None" = None
    _initialized: bool = False

    def __new__(cls, *args, **kwargs):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance

    def load_orchestrator(self, *, tools=None, prompt: str | None = None, name: str = "supervisor", checkpointer=None) -> CompiledStateGraph:
        """Compile a LangGraph agent with the supplied tool set and prompt."""
        logger.info("Compiling supervisor with langchain.create_agent")
        return _create_langchain_agent(
            model=self.base_llm,
            tools=tools or self.master_tools,
            system_prompt=prompt or self.base_prompt,
            # Important: respect explicit checkpointer. If None, do NOT fall
            # back to self.memory – callers decide whether memory is desired.
            checkpointer=checkpointer,
            name=name,
        )

    def __init__(self, tool_registry: ToolRegistry, llm=None, provider: str = None, llm_model=None, base_prompt: str = None):
        # Avoid trying to re-initialize the singleton on later calls
        if self.__class__._initialized:
            return
        super().__init__()
        logger.info("Initializing Orchestrator")
        self.registry = tool_registry
        # Map agent names to tool identifiers; expect registry.agent_tools to be set
        # ------------------------------------------------------------------
        # Determine which tools belong to which specialist agent.
        #
        # The preferred mechanism is for application code to attach a
        # ``agent_tools`` attribute to the provided ``ToolRegistry`` instance –
        # a ``dict[str, list[Tool]]`` mapping each specialist-agent name to the
        # list of tools it can use.
        #
        # In practice many callers just populate the registry with tools but do
        # not provide such a mapping.  Prior behavior was to raise and abort
        # initialization when the mapping was missing, which stopped
        # QAssistant from running entirely (see GH-issue #-).  We now fall back
        # to a sane default: a single *generic* specialist that can use all
        # registered tools (or none if the registry is still empty).
        # ------------------------------------------------------------------

        agent_tool_map = getattr(self.registry, "agent_tools", None)

        if not isinstance(agent_tool_map, dict):
            # Historical contract – absence or wrong type is a *hard* error, so
            # callers are forced to supply an explicit mapping.  Several unit
            # tests rely on this behavior for validation.

            raise RuntimeError("Tool registry 'agent_tools' mapping missing or invalid")

        logger.info(f"Agent tool map keys: {list(agent_tool_map.keys())}")
        # Base LLM/prompt and checkpoint memory for thread-level state
        self.base_prompt = base_prompt or single_agent_prompt
        self.base_llm = llm or LLMFactory.get_llm_model(provider=provider, llm_model=llm_model)
        self.llm_model = llm_model
        self.curr_counter = 0
        self.memory = MemorySaver()
        # Assistants API: lazy client + cached assistant id
        self._oa_client: OpenAI | None = None
        self._assistant_id: str | None = None
        # Memory summary cache: key -> (timestamp, summary)
        self._mem_cache: dict[Tuple[str, str, str], Tuple[float, str]] = {}
        try:
            self._mem_ttl = int(os.getenv("AF_MEMORY_SUMMARY_TTL", "90"))
        except Exception:  # noqa
            self._mem_ttl = 90

        logger.info("Compiling supervisor with langchain.create_agent")

        supervisor_tools = []
        if hasattr(self.registry, "as_langchain_tools"):
            try:
                supervisor_tools = list(self.registry.as_langchain_tools())
            except Exception:  # noqa
                supervisor_tools = []

        # Remove potential duplicates (same object or same .name)
        unique_tools = []
        seen_names = set()
        for t in supervisor_tools or []:
            n = getattr(t, "name", None)
            if n and n not in seen_names:
                seen_names.add(n)
                unique_tools.append(t)

        self.master_tools = unique_tools

        # Pre-compute a filtered tool list without memory tools for "fast" runs
        self._memory_tool_names = {
            "save_thread_memory", "search_thread_memory", "delete_thread_memory",
            "save_user_memory", "search_user_memory", "delete_user_memory",
            "save_org_memory", "search_org_memory", "delete_org_memory",
            "save_global_memory", "search_global_memory", "delete_global_memory",
            "summarize_any_memory",
        }
        self._non_memory_tools = [
            t for t in self.master_tools if getattr(t, "name", "") not in self._memory_tool_names
        ]

        # Prompt to discourage memory when disabled
        self._no_memory_prompt = (
            "You are an AI Agent executing a single-turn task. "
            "Do not read, write, or summarize any memory. "
            "Rely only on the task content and non-memory tools. Keep responses concise."
        )

        # Default full-featured supervisor (with memory for chat flows)
        self.supervisor = self.load_orchestrator(checkpointer=self.memory)

        # Mark as initialized after successful setup
        self.__class__._initialized = True

        # --------------------------------------------------------------
        # Eager warm-up to avoid latency on the first request
        # --------------------------------------------------------------
        try:
            # 1) Prime LLM cache (already created as self.base_llm)
            _ = self.base_llm
            # 2) Prime vector store provider and common collections
            from agentfoundry.vectorstores.factory import VectorStoreFactory
            prov = VectorStoreFactory.get_provider()
            # Global collections
            try:
                prov.get_store(org_id=None)
                prov.get_store(org_id="global")
            except Exception:  # noqa
                pass
            # App default org if configured
            try:
                from agentfoundry.utils.config import Config as _Cfg
                default_org = str(_Cfg().get("ORG_ID", "") or "")
                if default_org:
                    prov.get_store(org_id=default_org)
            except Exception:  # noqa
                pass
            # 3) Prime KGraph factory singleton (provider init only)
            try:
                from agentfoundry.kgraph.factory import KGraphFactory
                KGraphFactory.get_instance()
            except Exception:  # noqa
                pass
        except Exception as _warm_err:
            logger.debug(f"Warm-up encountered a non-fatal error: {_warm_err}")

    @classmethod
    def get_instance(cls, tool_registry: ToolRegistry | None = None, llm=None, llm_model=None, base_prompt: str | None = None):
        """Return the singleton instance, initializing on the first call.

        Parameters other than ``tool_registry`` are used only on the first
        initialization. Later calls ignore them and return the existing
        instance to preserve backwards compatibility.
        """
        if cls._instance is None:
            if tool_registry is None:
                raise ValueError("Orchestrator.get_instance requires tool_registry on first call")
            return cls(tool_registry, llm=llm, llm_model=llm_model, base_prompt=base_prompt)
        return cls._instance

    # Create a specialist agent
    @staticmethod
    def create_agent(name: str, tools: List[tool], llm, prompt: str | None = None):
        """ Create a specialist agent with the given name, tools, and LLM."""
        agent_name = " ".join(name.split("_")[:-1])
        tool_list_str = "\n".join(
            f"- {t.name}: {t.description}"
            for t in tools
        )
        if prompt is None:
            prompt = (
                f"You are a {agent_name} agent.\n\n"
                "AVAILABLE TOOLS:\n"
                f"{tool_list_str}\n\n"
                "INSTRUCTIONS:\n"
                "- Assist ONLY with tasks related to the agent, or tasks that can be fulfilled by the tools provided.\n"
                "- After you're done with your tasks, respond to the supervisor directly.\n"
                "- Respond ONLY with the results of your work, do NOT include ANY other text."
            )
            if "SQL_database" in agent_name:
                prompt += "Do not assume or ask the user for the Database schema. First use a query to determine this."
        # Use LangGraph's in-memory checkpointer for thread-level state across steps.
        return _create_langchain_agent(
            model=llm,
            tools=tools,
            system_prompt=prompt,
            name=name,
            checkpointer=MemorySaver(),
        )

    @staticmethod
    def _content_to_text(content) -> str:
        if content is None:
            return ""
        if isinstance(content, str):
            return content
        if isinstance(content, (bytes, bytearray)):
            try:
                return content.decode("utf-8")
            except Exception:
                return content.decode("utf-8", errors="replace")
        if isinstance(content, (list, tuple)):
            parts: list[str] = []
            for seg in content:
                if isinstance(seg, dict):
                    if "text" in seg:
                        parts.append(str(seg.get("text") or ""))
                    elif "content" in seg:
                        parts.append(str(seg.get("content") or ""))
                    else:
                        parts.append(str(seg))
                else:
                    parts.append(str(seg))
            return "\n".join(p for p in parts if p)
        return str(content)

    @classmethod
    def _normalize_task_input(cls, task_input) -> list[dict[str, str]]:
        normalized: list[dict[str, str]] = []
        if isinstance(task_input, (list, tuple)):
            for item in task_input:
                if isinstance(item, dict):
                    role = item.get("role", "user")
                    content = cls._content_to_text(item.get("content"))
                else:
                    role = "user"
                    content = cls._content_to_text(item)
                normalized.append({"role": str(role or "user"), "content": content})
        elif isinstance(task_input, dict):
            normalized.append({
                "role": str(task_input.get("role", "user") or "user"),
                "content": cls._content_to_text(task_input.get("content")),
            })
        else:
            normalized.append({"role": "user", "content": cls._content_to_text(task_input)})
        if not normalized:
            normalized = [{"role": "user", "content": ""}]
        return normalized

    @classmethod
    def _coerce_task_messages(cls, task_input) -> list:
        """Convert various task input shapes into LangChain message objects."""

        if (
            isinstance(task_input, list)
            and task_input
            and isinstance(task_input[0], dict)
            and "role" in task_input[0]
            and "content" in task_input[0]
        ):
            normalized = task_input
        else:
            normalized = cls._normalize_task_input(task_input)

        messages = []
        for item in normalized:
            role = (item.get("role") or "user").lower()
            content = item.get("content", "")
            if role == "system":
                messages.append(SystemMessage(content=content))
            elif role in {"assistant", "ai"}:
                messages.append(AIMessage(content=content))
            else:
                messages.append(HumanMessage(content=content))
        return messages or [HumanMessage(content="")]

    def _build_memory_summary(self, config: dict) -> str:
        """Return a cached or freshly-computed memory summary based on config.

        Controlled by env AF_DISABLE_MEMORY_SUMMARY; when 'true', returns ''.
        Applies a TTL (AF_MEMORY_SUMMARY_TTL) to avoid recomputation bursts.
        """
        if os.getenv("AF_DISABLE_MEMORY_SUMMARY", "false").lower() in ("1", "true", "yes", "on"):
            return ""
        cfg = config.get("configurable", {}) if isinstance(config, dict) else {}
        uid = str(cfg.get("user_id", "") or "")
        tid = str(cfg.get("thread_id", "") or "")
        oid = str(cfg.get("org_id", "") or "")
        key = (uid, tid, oid)
        now = time.perf_counter()
        cached = self._mem_cache.get(key)
        if cached and (now - cached[0]) < self._mem_ttl:
            return cached[1]
        t0 = time.perf_counter()
        try:
            org_id_val = oid
            # Always include a short thread summary (different store/path)
            thread_sum = mem_tools.summarize_any_memory.invoke({
                "level": "thread",
                "config": {"configurable": {"user_id": uid, "thread_id": tid, "org_id": oid}},
            })
            # Consolidate user + org (+global when org provided) into a single summary call
            combined_filter = {}
            ors = []
            if uid:
                ors.append({"user_id": uid})
            if org_id_val:
                ors.append({"org_id": org_id_val})
            if len(ors) > 1:
                combined_filter = {"$or": ors}
            elif len(ors) == 1:
                combined_filter = ors[0]
            # Single pass summarization over user/org docs; function merges global if org_id provided
            base_sum = summarize_memory(combined_filter, org_id=org_id_val if org_id_val else None, max_tokens=8000)
            mem_summary = "\n".join(filter(None, [thread_sum, base_sum]))
        except Exception as _mem_err:
            mem_summary = ""
            logger.debug(f"Memory summarization failed: {_mem_err}")
        took_ms = int((time.perf_counter() - t0) * 1000)
        logger.info(f"timing: memory_summary_ms={took_ms} uid={uid} tid={tid} oid={oid} len={len(mem_summary)}")
        self._mem_cache[key] = (now, mem_summary)
        return mem_summary

    def run_task(self, task: str | list | dict, file_id: str = None, vector_store_id: str = None, *args, **kwargs):
        """Execute a **single-turn** user request.

        This helper is intended for *stateless* usage patterns such as:

        • CLI commands / shell scripts
        • Unit-tests or smoke-tests ("does the tool chain work?")
        • Cron jobs or batch workflows where each invocation is independent

        Behavior:
        1. Wraps *task* (string or list of role/content dicts) into LangChain messages.
        2. Prepends a summarized memory snapshot so the supervisor still has
           context (organization, user, thread) without sending the full
           chat history.
        3. Invokes the LangGraph supervisor and returns the assistant’s
           reply.  If *additional=True*, a tuple ``(reply, full_history)`` is
           returned which contains every intermediate agent/tool message.

        The method does **not** mutate the internal chat state; each call starts
        from a clean slate except for the injected memory summary.
        """
        # Optional flags
        return_additional = kwargs.get('additional', False)
        use_memory: bool = kwargs.get('use_memory', False)
        # New: allow callers to completely disable tools or restrict to a subset
        # Default to NO tools to keep token usage small for single-turn tasks.
        allow_tools: bool = kwargs.get('allow_tools', False)
        allowed_tool_names: list[str] | None = kwargs.get('allowed_tool_names')
        config = kwargs.get('config') or {"configurable": {"user_id": "1", "thread_id": "1", "org_id": "NA", "security_level": "1"}}
        file_ids: list[str] = []
        if file_id:
            file_ids.append(str(file_id))
        extra_file_ids = kwargs.get('file_ids')
        if extra_file_ids:
            if isinstance(extra_file_ids, (list, tuple, set)):
                file_ids.extend(str(fid) for fid in extra_file_ids)
            else:
                file_ids.append(str(extra_file_ids))
        if file_ids:
            seen_ids: set[str] = set()
            file_ids = [fid for fid in file_ids if not (fid in seen_ids or seen_ids.add(fid))]
            normalized_messages = self._normalize_task_input(task)
            if not vector_store_id:
                env_vs = (os.getenv("OPENAI_VECTOR_STORE_ID") or "").strip()
                vector_store_id = env_vs or None
            if vector_store_id:
                client = None
                for fid in file_ids:
                    try:
                        if client is None:
                            client = self._ensure_oa_client()
                        wait_for_vector_store_file_ready(client, vector_store_id, fid)
                    except Exception as wait_err:  # pragma: no cover - network dependent
                        logger.warning(
                            "run_task: waiting for vector store file failed (fid=%s vs=%s): %s",
                            fid,
                            vector_store_id,
                            wait_err,
                        )
                        vector_store_id = None
                        break
            else:
                logger.warning("run_task: vector_store_id missing; proceeding without file_search binding")
        else:
            normalized_messages = None
        task_preview = task if isinstance(task, str) else str(task)
        logger.info(
            "run_task invoked: additional=%s, use_memory=%s, task=%s",
            return_additional,
            use_memory,
            task_preview[:60],
        )
        # ------------------------------------------------------------------
        # Inject summarised long-term memory as a system message so that the
        # supervisor has compact context without blowing up token limits.
        # ------------------------------------------------------------------

        mem_summary = self._build_memory_summary(config) if use_memory else ""
        init_msgs = []
        if mem_summary:
            if len(mem_summary) > 400000:
                mem_summary = mem_summary[:400000]
            mem_summary_len = len(mem_summary)
            logger.info(f"run_task: use_memory: {use_memory} mem_summary_len={mem_summary_len} mem_cache_entries={len(self._mem_cache)}")
            init_msgs.append(SystemMessage(content=f"MEMORY_CONTEXT:\n{mem_summary}"))

        payload_for_messages = normalized_messages or self._normalize_task_input(task)
        init_msgs.extend(self._coerce_task_messages(payload_for_messages))

        if file_ids:
            try:
                reply, meta = self._chat_via_openai_responses(
                    messages=payload_for_messages,
                    mem_summary=mem_summary or None,
                    file_ids=file_ids,
                    vector_store_id=vector_store_id,
                )
                reply_text = reply if isinstance(reply, str) else str(reply)
                logger.info(
                    "run_task: Responses API path succeeded (attachments=%d, reply_chars=%d)",
                    len(file_ids),
                    len(reply_text),
                )
                return (reply, meta) if return_additional else reply
            except Exception as resp_err:
                logger.error(
                    "run_task: Responses API path failed; falling back to supervisor: %s",
                    resp_err,
                    exc_info=True,
                )

        init_payload_chars = 0
        for _msg in init_msgs:
            content = getattr(_msg, "content", "")
            if isinstance(content, (bytes, bytearray)):
                content = content.decode("utf-8", errors="replace")
            init_payload_chars += len(str(content))
        logger.info(
            "run_task: init_messages=%d init_payload_chars=%d task_chars=%d",
            len(init_msgs),
            init_payload_chars,
            len(task_preview),
        )

        init = {"messages": init_msgs}
        # Choose the appropriate supervisor based on memory usage preference
        if not use_memory:
            # Decide a tool list based on allow_tools/allowed_tool_names
            tool_list = []
            if allow_tools:
                if isinstance(allowed_tool_names, (list, tuple)) and allowed_tool_names:
                    name_set = {str(n) for n in allowed_tool_names}
                    tool_list = [t for t in self._non_memory_tools if getattr(t, 'name', None) in name_set]
                else:
                    tool_list = list(self._non_memory_tools)
            supervisor = _create_langchain_agent(
                model=self.base_llm,
                tools=tool_list,
                system_prompt=self._no_memory_prompt,
                checkpointer=None,
                name="NoMemorySupervisor",
            )
            _mn = getattr(self.base_llm, 'model_name', getattr(self.base_llm, 'model', type(self.base_llm).__name__))
            logger.info(f"run_task: using no-memory {_mn} supervisor with {len(tool_list)} tools (allow_tools={allow_tools})")
        else:
            supervisor = self.load_orchestrator(
                tools=self.master_tools,
                prompt=self.base_prompt,
                name=f"supervisor_{uuid.uuid4().hex}",
                checkpointer=MemorySaver(),
            )
            logger.info(
                "run_task: using fresh supervisor with memory and %d tools",
                len(self.master_tools),
            )

        if supervisor is None:
            raise RuntimeError("Supervisor not initialized; cannot execute task")

        t_invoke = time.perf_counter()
        try:
            _t0 = time.perf_counter()
            # logger.info(f"Type of supervisor is: {type(supervisor)}")
            responses = supervisor.invoke(init, config=config)  # noqa
            _dur_ms = (time.perf_counter() - _t0) * 1000.0
            # logger.info(f"Supervisor.invoke completed in {_dur_ms:.1f} ms")
            reply = responses['messages'][-1].content
            if isinstance(reply, (bytes, bytearray)):
                reply = reply.decode("utf-8", errors="replace")
            else:
                reply = str(reply)
            logger.debug(f"Supervisor responses: {responses}")
        except Exception as e:
            logger.error(f"Exception in run_task for task '{task_preview[:60]}': {e}", exc_info=True)
            return f"An error occurred in the task: '{task_preview}': {str(e)}"
        response_messages = responses.get('messages', []) if isinstance(responses, dict) else []
        resp_payload_chars = 0
        tool_call_count = 0
        for _msg in response_messages:
            content = getattr(_msg, "content", "")
            if isinstance(content, (bytes, bytearray)):
                content = content.decode("utf-8", errors="replace")
            resp_payload_chars += len(str(content))
            extra = getattr(_msg, "additional_kwargs", {}) or {}
            tool_calls = extra.get('tool_calls')
            if isinstance(tool_calls, (list, tuple)):
                tool_call_count += len(tool_calls)
            elif tool_calls:
                tool_call_count += 1
        invoke_ms = int((time.perf_counter() - t_invoke) * 1000)
        logger.info(
            "timing: invoke_ms=%d task_chars=%d reply_chars=%d response_messages=%d response_payload_chars=%d tool_calls=%d",
            invoke_ms,
            len(task_preview),
            len(reply),
            len(response_messages),
            resp_payload_chars,
            tool_call_count,
        )
        if return_additional:
            return reply, responses
        for i in range(self.curr_counter, len(responses['messages'])):
            inter = responses['messages'][i]
            if inter.content == "":
                if "tool_calls" in inter.additional_kwargs:
                    for tool_call in inter.additional_kwargs['tool_calls']:
                        logger.info(f"tool call: {tool_call['function']}")
            else:
                logger.debug(f"intermediate message: {str(responses['messages'][i].content).encode('utf-8')[:60]}...")
        self.curr_counter = len(responses['messages'])
        logger.info(f"run_task completed: reply: {reply[:120]}")
        return reply

    def chat(self, messages: list[dict], config: dict = None, additional: bool = False, file_ids: list[str] = None, vector_store_id: str = None):
        """Multi-turn conversational entry point.

        Parameters
        ----------
        messages : list[dict]
            Full chat history as a list of ``{"role": ..., "content": ...}``
            dictionaries.  Roles can be *system*, *user* or *assistant*.
        config : dict | None
            Memory / security context.  If *None* a sensible default with
            user_id, thread_id and org_id = "NA" is injected.
        additional : bool, default ``False``
            When *True* the complete supervisor output (all intermediate
            agent and tool messages) is returned alongside the assistant
            reply.

        Use-cases
        ---------
        • Long-running chat sessions in a UI where the front-end keeps the
          turn history and sends it on every request.
        • API endpoints where the caller supplies the conversation history.

        Unlike :py:meth:`run_task`, *chat* assumes the caller controls the
        message chronology; it therefore converts each raw dict to the
        appropriate LangChain ``Message`` object and then delegates to the
        common invocation helper.
        :param vector_store_id:
        :param messages:
        :param config:
        :param additional:
        :param file_ids:
        """
        logger.info(f"chat invoked: messages_count={len(messages)}, additional={additional}")
        if config is None:
            config = {"configurable": {"user_id": "1", "thread_id": "1", "org_id": "NA", "security_level": "1"}}
        logger.debug(f"chat config: {config}")
        # ------------------------------------------------------------------
        # Add summarised long-term memory as the very first system message of
        # the conversation for chat() as well.
        # ------------------------------------------------------------------

        mem_summary = self._build_memory_summary(config)

        # Convert raw messages to message objects
        msg_objs = []
        if mem_summary:
            if len(mem_summary) > 400_000:
                mem_summary = mem_summary[:400_000]
            msg_objs.append(SystemMessage(content=f"MEMORY_CONTEXT:\n{mem_summary}"))
        for msg in messages:
            role = msg.get("role", "").lower()
            content = msg.get("content", "")
            if role == "system":
                msg_objs.append(SystemMessage(content=content))
            elif role == "user":
                msg_objs.append(HumanMessage(content=content))
            elif role in ("assistant", "ai"):
                msg_objs.append(AIMessage(content=content))
            else:
                raise ValueError(f"Unknown message role: {role}")
        # If files are provided, route via the OpenAI Responses API (file_search)
        if file_ids:
            try:
                # Allow forcing Assistants path via env (compatibility with older SDKs)
                if os.getenv("AF_FORCE_ASSISTANTS_FOR_FILES", "").strip().lower() in ("1", "true", "yes", "on"):
                    raise RuntimeError("Forced Assistants path via AF_FORCE_ASSISTANTS_FOR_FILES")
                reply, meta = self._chat_via_openai_responses(messages=messages, mem_summary=mem_summary, file_ids=file_ids, vector_store_id=vector_store_id)
                if additional:
                    return reply, meta
                return reply
            except Exception as e:
                msg = str(e)
                if isinstance(e, TypeError) and "unexpected keyword argument 'attachments'" in msg:
                    logger.info(f"Responses API attachments not supported by installed OpenAI SDK: {msg}")
                else:
                    logger.exception(f"Responses API chat failed: {msg}")
                raise e

        init = {"messages": msg_objs}

        t_invoke = time.perf_counter()
        _t0 = time.perf_counter()
        responses = self.supervisor.invoke(init, config=config)  # noqa
        _dur_ms = (time.perf_counter() - _t0) * 1000.0
        logger.info(f"Supervisor.invoke completed in {_dur_ms:.1f} ms")
        reply = responses['messages'][-1].content
        invoke_ms = int((time.perf_counter() - t_invoke) * 1000)
        logger.info(f"timing: invoke_ms={invoke_ms} chat_msgs={len(messages)} reply_chars={len(str(reply))}")
        if additional:
            logger.info(f"chat completed with additional output: reply={reply}")
            return reply, responses
        logger.info(f"chat completed: reply={reply}")
        return reply

    def upload_file(self, file_path: str):
        pass

    def _ensure_oa_client(self) -> OpenAI:
        if self._oa_client is None:
            self._oa_client = OpenAI()
        return self._oa_client

    def _ensure_assistant(self) -> str:
        """Create or reuse a single assistant with file_search enabled."""
        if self._assistant_id:
            return self._assistant_id
        client = self._ensure_oa_client()
        # Choose model for Assistants API; allow override via env
        model = os.getenv("AF_ASSISTANTS_MODEL") or os.getenv("OPENAI_ASSISTANTS_MODEL") or "gpt-4o"
        name = os.getenv("AF_ASSISTANT_NAME", "Supervisor")
        base_instructions = self.base_prompt or "You are an AI assistant."
        assistant = client.beta.assistants.create(
            name=name,
            instructions=base_instructions,
            model=model,
            tools=[{"type": "file_search"}],  # noqa
        )
        self._assistant_id = assistant.id
        logger.info(f"Assistants API: created assistant id={assistant.id} model={model}")
        return assistant.id

    def _chat_via_openai_responses(self, *, messages: list[dict], mem_summary: str | None, file_ids: list[str], vector_store_id: str = None):
        """
        Use the Responses API with file_search to answer a prompt referencing
        uploaded files. Preferred over deprecated Assistants API.

        Returns (reply_text, metadata_dict)
        """
        client = self._ensure_oa_client()

        # Model selection for Responses API
        model = os.getenv("AF_RESPONSES_MODEL") or os.getenv("OPENAI_RESPONSES_MODEL") or "gpt-5-mini"

        # Build structured input; collect system text into instructions
        input_msgs: list[dict] = []
        inst_chunks: list[str] = []
        if self.base_prompt:
            inst_chunks.append(self.base_prompt)
        if mem_summary:
            summary = mem_summary if len(mem_summary) <= 200_000 else mem_summary[:200_000]
            # Prefer adding memory as system context to avoid echo in user text
            input_msgs.append({
                "role": "system",
                "content": [{"type": "input_text", "text": f"MEMORY_CONTEXT:\n{summary}"}],
            })
        for m in messages:
            role = (m.get("role") or "").lower()
            content = str(m.get("content", ""))
            if role == "system":
                inst_chunks.append(content)
            elif role in ("user", "assistant"):
                input_msgs.append({
                    "role": role,
                    "content": [{"type": "input_text", "text": content}],
                })
            else:
                raise ValueError(f"Unknown message role for Responses API: {role}")
        # Prepare tools for file_search when a vector store is available
        use_file_search = bool(vector_store_id)
        tools: list[dict[str, Any]] = (
            [{"type": "file_search", "vector_store_ids": [vector_store_id]}]
            if use_file_search
            else []
        )
        
        # Create the response synchronously
        t0 = time.perf_counter()
        # Prefer top-level attachments for Responses API (current SDK/server shape).
        # Older message-level attachments caused 400: Unknown parameter 'input[0].attachments'.
        attachments = None
        norm_ids: list[str] = []
        if file_ids:
            # Normalize inputs like 'openai://files/file-ABC' -> 'file-ABC'
            for fid in (file_ids or []):
                s = str(fid)
                m = re.search(r"(file-[A-Za-z0-9][A-Za-z0-9_-]*)", s)
                if m:
                    norm_ids.append(m.group(1))
                else:
                    logger.warning(f"Responses: skipping unrecognised file id format: {s!r}")
            # dedupe, preserve order
            seen = set()
            norm_ids = [x for x in norm_ids if not (x in seen or seen.add(x))]
            if norm_ids and use_file_search:
                attach_tools = [{"type": "file_search", "vector_store_ids": [vector_store_id]}]
                attachments = [{"file_id": fid, "tools": attach_tools} for fid in norm_ids]
        logger.debug(
            "Responses API call: model=%s tools=%d attachments=%d msgs=%d",
            model, len(tools or []), len(attachments or []), len(input_msgs)
        )
        base_kwargs = dict(
            model=model,
            input=input_msgs if input_msgs else messages[-1].get("content", ""),
            **({"instructions": "\n\n".join(inst_chunks)} if inst_chunks else {}),
        )
        if vector_store_id:
            base_kwargs["tools"] = [{"type": "file_search", "vector_store_ids": [vector_store_id]}]

        def _embed_files_into_input():

            added = 0
            for fid in norm_ids:
                try:
                    try:
                        meta = client.files.retrieve(fid)
                    except Exception:  # noqa
                        meta = None
                    name = getattr(meta, "filename", None) or getattr(meta, "name", None) or fid
                    # Fetch bytes
                    try:
                        r = client.files.content(fid)
                        # BinaryAPIResponseContent supports .read(); httpx Response has .content
                        raw = getattr(r, "read", None) and r.read() or getattr(r, "content", None)
                    except Exception:  # noqa
                        raw = None
                    text = None
                    if isinstance(raw, (bytes, bytearray)) and len(raw) > 0:
                        # Create a file-like for ingest_document
                        class _FileLike:
                            def __init__(self, data: bytes, filename: str):
                                self._data = data
                                self.filename = filename

                            def read(self):
                                return self._data

                        try:
                            text = ingest_document(_FileLike(raw, name))  # noqa
                        except Exception:  # noqa
                            text = None
                    if not text:
                        # Fallback marker when content couldn't be extracted
                        size = len(raw) if isinstance(raw, (bytes, bytearray)) else 0
                        text = f"[attachment unavailable or binary-only: {name} size={size} bytes]"
                    input_msgs.append({
                        "role": "system",
                        "content": [{"type": "input_text", "text": f"ATTACHED FILE: {name}\n\n{text}"}],
                    })
                    added += 1
                except Exception:  # noqa
                    continue
            return added

        inline_injected = False
        if norm_ids and not use_file_search:
            inline_injected = _embed_files_into_input() > 0

        try:
            if vector_store_id:
                # Vector store path – no attachments/tool_resources needed here
                resp = client.responses.create(**base_kwargs)
            elif norm_ids:
                # Prefer tool_resources with file_ids (no top-level tools)
                try:
                    resp = client.responses.create(**base_kwargs, tool_resources={"file_search": {"file_ids": norm_ids}})  # noqa
                except Exception:
                    # Fallback to attachments (still without top-level tools)
                    resp = client.responses.create(**base_kwargs, attachments=attachments) if attachments else client.responses.create(**base_kwargs)
            else:
                # Plain prompt
                resp = client.responses.create(**base_kwargs)
        except TypeError:
            # Older SDK signatures: attempt attachments first when files exist; else inline fallback
            try:
                if use_file_search and norm_ids:
                    resp = client.responses.create(**base_kwargs, tool_resources={"file_search": {"file_ids": norm_ids}})  # noqa
                else:
                    raise
            except Exception:  # noqa
                # As a final Responses-compatible fallback, inline file text
                if inline_injected or _embed_files_into_input() > 0:
                    resp = client.responses.create(model=model, input=input_msgs, tools=tools, **({"instructions": "\n\n".join(inst_chunks)} if inst_chunks else {}))  # noqa
                else:
                    raise
        except Exception as _e:
            s = str(_e)
            # If the server complains about attachments/tool_resources or tool config, try the other forms or inline
            if ("attachments" in s) or ("tool_resources" in s) or ("vector_store_ids" in s):
                try:
                    if use_file_search and norm_ids:
                        resp = client.responses.create(**base_kwargs, tool_resources={"file_search": {"file_ids": norm_ids}})  # noqa
                    else:
                        raise
                except Exception:  # noqa
                    # Inline file text fallback
                    if inline_injected or _embed_files_into_input() > 0:
                        resp = client.responses.create(model=model, input=input_msgs, tools=tools, **({"instructions": "\n\n".join(inst_chunks)} if inst_chunks else {}))  # noqa
                    else:
                        raise
            else:
                raise
        dt_ms = int((time.perf_counter() - t0) * 1000)

        # Extract text robustly
        try:
            reply_text = getattr(resp, "output_text", None)
        except Exception:  # noqa
            reply_text = None
        if not reply_text:
            try:
                chunks = []
                for item in getattr(resp, "output", []) or []:
                    for part in getattr(item, "content", []) or []:
                        # Different SDK versions use different shapes; try common ones
                        t = getattr(part, "type", None)
                        if t in ("output_text", "text"):
                            text_obj = getattr(part, "text", None)
                            val = getattr(text_obj, "value", None) if text_obj is not None else None
                            if not val:
                                # Fallback to str(part)
                                val = str(getattr(part, "text", ""))
                            if val:
                                chunks.append(str(val))
                if chunks:
                    reply_text = "\n".join(chunks)
            except Exception:  # noqa
                pass
        if not reply_text:
            reply_text = str(getattr(resp, "output", "")) or ""

        logger.info(
            "Responses chat completed: time_ms=%d chars=%d files=%d model=%s",
            dt_ms,
            len(reply_text or ""),
            len(file_ids or []),
            model,
        )
        meta = {
            "api": "responses",
            "model": model,
            "time_ms": dt_ms,
        }
        return reply_text, meta


def wait_for_vector_store_file_ready(client, vector_store_id: str, file_id: str, timeout_s: int = 1200, poll_s: float = 1.5):
    import time
    t0 = time.time()
    while True:
        # Newer SDKs: client.vector_stores.files.list(...) returns items with status
        files_page = client.vector_stores.files.list(vector_store_id=vector_store_id, limit=100)
        items = getattr(files_page, "data", []) or []
        status = None
        for it in items:
            if getattr(it, "id", None) == file_id:
                status = getattr(it, "status", None) or getattr(it, "state", None)
                break
        if status == "completed":
            return
        if status == "failed":
            raise RuntimeError(f"Vector store indexing failed for file {file_id}")
        if time.time() - t0 > timeout_s:
            raise TimeoutError(f"Timed out waiting for vector store to index file {file_id}")
        time.sleep(poll_s)


if __name__ == '__main__':
    print("Starting...")
    logger = logging.getLogger()
    logger.setLevel(logging.INFO)  # Set to DEBUG to capture all log levels
    # Create a handler that outputs to stdout
    stdout_handler = logging.StreamHandler(sys.stdout)
    # stdout_handler.setLevel(logging.INFO)
    # Create a formatter and set it on the handler
    # formatter = logging.Formatter("%(asctime)s - %(levelname)s - %(message)s")
    formatter = logging.Formatter(fmt='%(asctime)s %(levelname)-8s - %(name)-45s:%(lineno)-5s - %(message)s', datefmt='%Y-%m-%d %H:%M:%S')
    stdout_handler.setFormatter(formatter)
    # Add the handler to the logger
    logger.addHandler(stdout_handler)
    logging.getLogger("httpcore").setLevel(logging.WARNING)  # Suppress httpcore warnings
    logging.getLogger("openai").setLevel(logging.WARNING)  # Suppress OpenAI warnings
    logging.getLogger("urllib3").setLevel(logging.WARNING)
    logging.getLogger("httpx").setLevel(logging.WARNING)
    logging.getLogger("agentfoundry").setLevel(logging.INFO)
    # logger = logging.getLogger("agentfoundry.agents.orchestrator.__main__")

    registry = ToolRegistry()
    # Expose the registry tool for introspection
    registry_tool = registry.as_langchain_registry_tool()
    registry.register_tool(registry_tool)
    # Load shipped and configured tools safely
    registry.load_tools_from_directory()
    available_tools = registry.as_langchain_tools()
    logger.info(f"Available tools loaded: {[t.name for t in available_tools]}")

    # Group tools by agent name using stable names instead of fragile indexes
    tool_agent_dict = {
        # "AWS_agent": [],
        # "internet_request_agent": [],
        # "SQL_database_agent": [],
        # "python_and_CSV_agent": [],
        # "micropolicy_agent": [],
        # "user_tool_agent": [],
        # New specialist focused on all memory operations
        "memory_agent": [],
    }
    for t in available_tools:
        # if t.name in ["awscli_executor", "pdf_file_creator"]:
        #     tool_agent_dict["AWS_agent"].append(t)
        # if t.name in ["http_request_tool", "web_search_tool", "rest_api_tool", "pdf_file_creator"]:
        #     tool_agent_dict["internet_request_agent"].append(t)
        # if t.name in ["sql_server_query", "postgres_server_query", "pdf_file_creator"]:
        #     tool_agent_dict["SQL_database_agent"].append(t)
        # if t.name in [
        #    "python_code_runner",
        #    "summarize_csv",
        #    "pdf_file_creator",
        #    "pdf_editor",
        #    "document_reader",
        #    "python_file_writer",
        #    "python_tool_creator",
        # ]:
        #     tool_agent_dict["python_and_CSV_agent"].append(t)
        # if t.name == "document_reader":
        #     tool_agent_dict["micropolicy_agent"].append(t)
        # if t.name in ["user_generated_tool_invoker", "user_generated_tool_lister"]:
        #     tool_agent_dict["user_tool_agent"].append(t)
        # Route all memory tools to the dedicated memory agent
        if t.name in {
            # thread-level
            "save_thread_memory", "search_thread_memory", "delete_thread_memory",
            # user-level
            "save_user_memory", "search_user_memory", "delete_user_memory",
            # org-level
            "save_org_memory", "search_org_memory", "delete_org_memory",
            # global-level
            "save_global_memory", "search_global_memory", "delete_global_memory",
            # summarization helper
            "summarize_any_memory",
        }:
            tool_agent_dict["memory_agent"].append(t)

    registry.agent_tools = tool_agent_dict
    try:
        orchestrator = Orchestrator(registry)
        cfg = {'configurable': {'user_id': 'u1', 'thread_id': 't1', 'org_id': 'o1', 'security_level': "10"}}
        # response1 = orchestrator.run_task("Remember that my favorite color is blue.", config=cfg)
        # print("Task 1 Response:", response1)

        # Task 2: Recall memory
        task2 = "What is my favorite color?"
        response2 = orchestrator.run_task(task2, config=cfg)
        print("Task 2 Response:", response2)

        # Chat 1: Save memory
        chat1 = "My name is Chris, I am a user. Please remember that my favorite color is purple?"
        msg1 = [{"role": "user", "content": chat1}]
        chat_response1 = orchestrator.chat(msg1, config=cfg)
        print("Chat 1 Response:", chat_response1)

        chat2 = "I'm Chris, what is my favorite color?"
        msg2 = [{"role": "user", "content": chat2}]
        chat_response2 = orchestrator.chat(msg2, config=cfg)
        print("Chat 2 Response:", chat_response2)

        # Verify that the memory was recalled correctly
        # assert "blue" in response2.lower(), \
        #    "Memory recall failed: 'blue' not found in run_task response"
        assert "purple" in chat_response2.lower(), \
            "Memory recall failed: 'blue' not found in chat response"
        print("Smoke test passed: Memory successfully saved and recalled.")

        client = OpenAI()
        file = client.files.create(
            file=open("../quantify/data/RFx/solicitations/RFQ # 75D301-20-R-67928 NITS NIOSH v7.pdf", "rb"),
            purpose="assistants"
        )
        vector_store = client.vector_stores.create(
            name="RFQ Vector Store",
            file_ids=[file.id]
        )
        vector_store_id = vector_store.id
        # vector_store_id = "vs_68fa5da5fe7c81918640674d47ce92f6"

        print(f"File id: {file}, filename: {file.filename}, vector_store_id: {vector_store_id}")
        wait_for_vector_store_file_ready(client, vector_store.id, file.id)
        chat3 = "Analyze and summarize the attached solicitation, if you do not find the file, let me know"
        msg3 = [{"role": "user", "content": chat3}]
        file_id = "file-TauZBVjhSaw59XfG3NgYk7"
        # file_id = file.id
        chat_response3 = orchestrator.run_task(msg3, config=cfg, file_ids=[file_id], vector_store_id=vector_store_id)
        print("Chat 3 Response:", chat_response3)
        print("RFQ File Summary Response:", chat_response3)
    except Exception as e:
        print(f"ERROR (example harness): {e}")
        sys.exit(1)
