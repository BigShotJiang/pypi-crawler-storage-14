from imports import *
from abstract_apis import *
##url= 'https://typicallyoutliers.com'
##endpoint = 'utilities/resize_image'
##data={"path":"/mnt/24T/media/images/default_images/abstractendeavors.png"}
##img_path = postRequest(url=url,endpoint=endpoint,data=data)
##endpoint = 'utilities/extract_image_metadata'
##data={"path":img_path}
##result = postRequest(url=url,endpoint=endpoint,data=data)
##input(result)
domain="abstractendeavors.com/howdy"
info = getInfo(domain=domain,thumbnail='/home/flerb/Pictures/abstractendeavors/AE.png')
parsed_url_info = get_pared_url_info(info)
kwargs = get_kwargs_value(dict_obj={},keys=BOOL_KEYS,default={})  
info = get_meta_info(info,**kwargs)
##input(info)
meta_tags = generate_meta_tags(info,parsed_url_info.get('variants')[0])

input(meta_tags)
