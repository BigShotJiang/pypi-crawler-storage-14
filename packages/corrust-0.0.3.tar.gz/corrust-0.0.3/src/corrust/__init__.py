import time, threading, datetime, re, traceback, math
from typing import (Optional, Dict, Any, Tuple)
def now() -> datetime.datetime:
    return datetime.datetime.now()
def rpar(expr: Optional[str]) -> Optional[datetime.datetime]:
    if not expr:
        return None
    m = re.search(r"(\d+)([smhd])$", expr)
    if not m:
        return None
    value = int(m.group(1))
    unit = m.group(2)
    delta = {"s": 1,"m": 60,"h": 3600,"d": 86400,}[unit]
    return now() + datetime.timedelta(seconds=value * delta)
def piar(expr: Optional[str]) -> Optional[int]:
    if not expr:
        return None
    m = re.search(r"(\d+)([smhd])$", expr)
    if not m:
        return None
    value = int(m.group(1))
    unit = m.group(2)
    return value * {"s": 1,"m": 60,"h": 3600,"d": 86400,}[unit]
def appc(code: str, ctx: Dict[str, Any]) -> str:
    for key, val in ctx.items():
        code = code.replace(key, str(val))
    return code
class os:
    def __init__(self, name: str):
        self.name = name
        self.code: Optional[str] = None
        self.ctx: Dict[str, Any] = {}
        self.runauto = True
    def __lshift__(self, data):
        if isinstance(data, str):
            self.code = data
            self.ctx = {}
        else:
            self.code, self.ctx = data
            self.ctx = self.ctx or {}
        
        if self.runauto:
            self.eo()
        return self
    def eo(self):
        if not self.code:
            return
        src = appc(self.code, self.ctx)
        timestamp = time.strftime("%H:%M:%S")
        print(f"[{timestamp}] {self.name}.py")
        try:
            exec(src, {})
        except Exception as e:
            print(f"\nError in {self.name}.py")
            tb = traceback.format_exception_only(type(e), e)
            for line in tb:
                print(line, end='')
    def run(self, start=None, every=None, stop=None):
        if start is False or every is False or stop is False:
            self.runauto = False
            return
        self.runauto = False
        srt = rpar(start)
        interval = piar(every)
        spt = rpar(stop)
        def runner():
            if srt:
                while now() < srt:
                    time.sleep(0.05)
            if not interval:
                self.eo()
                return
            while True:
                current = now()
                if spt and current >= spt:
                    return
                self.eo()
                nt = current + datetime.timedelta(seconds=interval)
                while now() < nt:
                    if spt and now() >= spt:
                        return
                    time.sleep(0.05)
        thread = threading.Thread(target=runner, daemon=True)
        thread.start()
        return thread
_instances: Dict[str, os] = {}
def __getattr__(name: str):
    if name not in _instances:
        _instances[name] = os(name)
    return _instances[name]