"""Extraction tools - specialized data extraction from specific sites/patterns"""
