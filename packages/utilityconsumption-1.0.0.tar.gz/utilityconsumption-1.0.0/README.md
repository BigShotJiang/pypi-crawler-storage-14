# UtilityConsumption

This is a custom Python library for analyzing DynamoDB usage records.  
It provides functions to calculate consumption, costs, monthly totals, and detect usage spikes.