import boto3
import calendar
from boto3.dynamodb.conditions import Key
from collections import defaultdict

dynamodb = boto3.resource("dynamodb", region_name="us-east-1")
table = dynamodb.Table("usage_records_user")

# Dummy flat rates per supply type
RATES = {
    "electricity": 0.20,  # €/kWh
    "gas": 0.08,          # €/unit
    "steam": 0.10,        # €/unit
    "ac": 0.12            # €/unit
}

def fetch_user_records(user_id: str, supply_type: str = None) -> list[dict]:
    dynamodb = boto3.resource("dynamodb", region_name="us-east-1")
    table = dynamodb.Table("usage_records_user")
    response = table.query(
        KeyConditionExpression=Key("user_id").eq(user_id)
    )
    items = response["Items"]

    if supply_type:
        items = [item for item in items if item["supply_type"] == supply_type]

    return items

def calculate_total_consumption(user_id: str, supply_type: str = None) -> float:
    dynamodb = boto3.resource("dynamodb", region_name="us-east-1")
    table = dynamodb.Table("usage_records_user")
    records = fetch_user_records(user_id, supply_type)
    return sum(float(item["raw_value"]) for item in records)

def calculate_costs(user_id: str) -> dict:
    """
    Calculate costs for all supply types for a given customer.
    """
    dynamodb = boto3.resource("dynamodb", region_name="us-east-1")
    table = dynamodb.Table("usage_records_user")
    costs = {}
    for supply_type, rate in RATES.items():
        units = calculate_total_consumption(user_id, supply_type)
        costs[supply_type] = units * rate
    return costs

def monthly_totals_by_supply(user_id: str) -> dict:
    dynamodb = boto3.resource("dynamodb", region_name="us-east-1")
    table = dynamodb.Table("usage_records_user")
    records = fetch_user_records(user_id)
    supply_monthly = defaultdict(dict)

    for item in records:
        supply = item["supply_type"]
        month = item.get("month")
        if month:
            supply_monthly[supply][month] = float(item["raw_value"])

    return {s: dict(m) for s, m in supply_monthly.items()}

def parse_month_str(month_str: str) -> tuple[int, int]:
    """
    Convert 'MMM-YY' (e.g., 'NOV-25') into (year, month_num).
    Useful for chronological sorting of months.
    """
    dynamodb = boto3.resource("dynamodb", region_name="us-east-1")
    table = dynamodb.Table("usage_records_user")
    month_abbr, year_str = month_str.split("-")
    year = int("20" + year_str)  # '25' -> 2025
    month_num = list(calendar.month_abbr).index(month_abbr.capitalize())
    return (year, month_num)

def get_previous_month(current_month: str) -> str:
    """
    Derive the previous month string from current month.
    Format assumed: 'MMM-YY' (e.g., 'DEC-25').
    """
    dynamodb = boto3.resource("dynamodb", region_name="us-east-1")
    table = dynamodb.Table("usage_records_user")
    month_abbr, year_str = current_month.split("-")
    year = int("20" + year_str)  # convert '25' -> 2025
    month_num = list(calendar.month_abbr).index(month_abbr.capitalize())

    # Move one month back
    if month_num == 1:  # January
        prev_month_num = 12
        year -= 1
    else:
        prev_month_num = month_num - 1

    prev_month_abbr = calendar.month_abbr[prev_month_num].upper()
    prev_year_str = str(year)[-2:]  # last two digits
    return f"{prev_month_abbr}-{prev_year_str}"

def spike_messages(user_id: str, current_month: str, threshold: float = 0.2) -> dict:
    """
    Compare current month usage with derived previous month for each supply type.
    Only display a message if there is a spike (increase > threshold).
    """
    dynamodb = boto3.resource("dynamodb", region_name="us-east-1")
    table = dynamodb.Table("usage_records_user")
    monthly_data = monthly_totals_by_supply(user_id)
    previous_month = get_previous_month(current_month)
    messages = {}

    for supply, months in monthly_data.items():
        current_val = months.get(current_month)
        prev_val = months.get(previous_month)

        if current_val is None or prev_val is None:
            continue  # skip if data missing

        # Calculate percentage increase
        if prev_val > 0:
            increase_ratio = (current_val - prev_val) / prev_val
        else:
            increase_ratio = 0

        if increase_ratio >= threshold:
            # Spike detected → show suggestion
            if supply == "electricity":
                suggestion = "Switch to LED lighting, unplug idle devices, and shift heavy loads to off-peak hours."
            elif supply == "gas":
                suggestion = "Check boiler efficiency, insulate pipes, and reduce heating demand with better insulation."
            elif supply == "steam":
                suggestion = "Schedule industrial processes more efficiently and insulate steam lines to reduce losses."
            elif supply == "ac":
                suggestion = "Raise thermostat slightly, service AC units, and improve building insulation to cut cooling demand."
            else:
                suggestion = "Consider efficiency improvements and behavioral changes to reduce demand."

            messages[supply] = (
                f"Spike detected: {supply.capitalize()} usage jumped from {prev_val:.2f} in {previous_month} "
                f"to {current_val:.2f} in {current_month}. Suggestion: {suggestion}"
            )

    return messages