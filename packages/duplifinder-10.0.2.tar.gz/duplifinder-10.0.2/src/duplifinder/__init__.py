# src/duplifinder/__init__.py

"""Duplifinder: Detect duplicate Python definitions across projects."""

__all__ = ["Config", "EnhancedDefinitionVisitor", "main"]
