"""Small NumPy datasets for debugging/testing."""

