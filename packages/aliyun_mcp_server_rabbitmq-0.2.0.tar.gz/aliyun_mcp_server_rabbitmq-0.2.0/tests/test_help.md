
## 测试

### 阿里云凭据配置

在运行测试之前，需要配置阿里云访问凭据。可以通过以下方式配置：

#### 环境变量

在终端中设置环境变量：

```bash
cd ~

echo 'export ALIBABA_CLOUD_ACCESS_KEY_ID="你的AccessKeyID"' >> .zshrc
echo 'export ALIBABA_CLOUD_ACCESS_KEY_SECRET="你的AccessKeySecret"' >> .zshrc

source .zshrc
```

### 设置测试必须参数

设置tests/test_config.py中的地域、实例信息


### 运行测试

测试文件位于 `tests/openAPI/` 目录下，可以通过以下方式运行：

#### 使用 pytest 运行所有测试

```bash
# 使用 pip
pytest

# 使用 uv (推荐)
uv run pytest
```

#### 直接运行单个测试文件

测试文件可以作为独立脚本直接运行，无需 pytest：

```bash
# 使用标准 Python
python tests/openAPI/test_instance.py
python tests/openAPI/test_queue.py
python tests/openAPI/test_exchange.py
python tests/openAPI/test_binding.py
python tests/openAPI/test_vhost.py
python tests/openAPI/test_account.py
python tests/openAPI/test_config.py

# 使用 uv (推荐)
uv run python tests/openAPI/test_instance.py
uv run python tests/openAPI/test_queue.py
uv run python tests/openAPI/test_exchange.py
uv run python tests/openAPI/test_binding.py
uv run python tests/openAPI/test_vhost.py
uv run python tests/openAPI/test_account.py
uv run python tests/openAPI/test_config.py
```

