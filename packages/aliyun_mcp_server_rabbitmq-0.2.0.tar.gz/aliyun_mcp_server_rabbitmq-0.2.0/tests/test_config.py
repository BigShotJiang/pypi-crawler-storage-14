"""Test configuration for AliyunOpenAPI tests.

This module provides centralized configuration for all test files.
All test classes should import and use these values.
"""

# Aliyun RabbitMQ API endpoint; ref: https://api.aliyun.com/product/amqp-open
ENDPOINT = ""

# RabbitMQ instance ID
INSTANCE_ID = ""

