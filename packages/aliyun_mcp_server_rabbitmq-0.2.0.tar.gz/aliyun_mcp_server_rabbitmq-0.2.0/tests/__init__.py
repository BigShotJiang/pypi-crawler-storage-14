"""Tests for Aliyun MCP Server RabbitMQ."""




