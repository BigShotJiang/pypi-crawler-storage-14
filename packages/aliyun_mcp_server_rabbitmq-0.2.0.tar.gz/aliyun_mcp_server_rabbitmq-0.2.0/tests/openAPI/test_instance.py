"""Standalone test script for AliyunOpenAPI instance operations.

This script can be run directly without pytest:

Using standard Python:
    python tests/openAPI/test_instance.py

Using uv (recommended):
    uv run python tests/openAPI/test_instance.py

Make sure dependencies are installed first:
    uv sync
    # or
    pip install -e .
"""

import sys
from pathlib import Path
from typing import Optional

# Add src to path (need to go up two levels from tests/openAPI/ to project root)
sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from src.aliyunOpenAPI import AliyunOpenAPI
from tests.openAPI.check_credentials import check_credentials, print_instance_attributes
from tests.test_config import ENDPOINT, INSTANCE_ID


class TestGetInstance:
    """Test class for get_instance method."""
    
    def __init__(self, api: AliyunOpenAPI):
        self.api = api
        self.instance_id = INSTANCE_ID
        self.endpoint = ENDPOINT
    
    def run(self) -> int:
        """Run the test."""
        print("=" * 60)
        print("测试 AliyunOpenAPI.get_instance()")
        print("=" * 60)
        
        print(f"\n正在获取实例信息: {self.instance_id}")
        print(f"  endpoint: {self.endpoint}")
        print("-" * 60)
        
        try:
            instance = self.api.get_instance(self.instance_id, endpoint=self.endpoint)
            
            print("\n✓ 成功获取实例信息!")
            print(f"\n实例详情:")
            print(f"  Instance 对象: {instance}")
            print(f"  Instance 类型: {type(instance)}")
            
            print_instance_attributes(instance)
            
            print("\n" + "=" * 60)
            print("测试完成!")
            return 0
            
        except Exception as e:
            print(f"\n✗ 获取实例信息失败!")
            print(f"\n错误信息: {type(e).__name__}: {str(e)}")
            import traceback
            print("\n详细错误堆栈:")
            traceback.print_exc()
            print("\n" + "=" * 60)
            return 1


class TestGetInstanceList:
    """Test class for get_instance_list method."""
    
    def __init__(self, api: AliyunOpenAPI):
        self.api = api
        self.endpoint = ENDPOINT
    
    def run(
        self, 
        resource_group_id: Optional[str] = None,
        next_token: Optional[str] = None,
        max_results: int = 10
    ) -> int:
        """Run the test."""
        print("=" * 60)
        print("测试 AliyunOpenAPI.get_instance_list()")
        print("=" * 60)
        
        print(f"\n正在获取实例列表...")
        print(f"  参数:")
        print(f"    endpoint: {self.endpoint}")
        print(f"    resource_group_id: {resource_group_id}")
        print(f"    next_token: {next_token}")
        print(f"    max_results: {max_results}")
        print("-" * 60)
        
        try:
            instance_list = self.api.get_instance_list(
                endpoint=self.endpoint,
                resource_group_id=resource_group_id,
                next_token=next_token,
                max_results=max_results
            )
            
            print("\n✓ 成功获取实例列表!")
            print(f"\n返回结果:")
            print(f"  类型: {type(instance_list)}")
            
            # 检查返回的是列表还是数据对象
            if hasattr(instance_list, 'instances'):
                # 如果是 ListInstancesResponseBodyData 对象
                data = instance_list
                instances = data.instances or []
                print(f"  实例数量: {len(instances)}")
                if hasattr(data, 'next_token') and data.next_token:
                    print(f"  下一页 token: {data.next_token}")
                if hasattr(data, 'max_results'):
                    print(f"  最大结果数: {data.max_results}")
                
                if instances:
                    print(f"\n  实例列表:")
                    for idx, instance in enumerate(instances, 1):
                        print(f"\n  [{idx}] 实例详情:")
                        print(f"    类型: {type(instance)}")
                        print_instance_attributes(instance, f"实例 {idx} 属性")
                else:
                    print("\n  实例列表为空")
            elif isinstance(instance_list, list):
                # 如果直接返回列表
                print(f"  实例数量: {len(instance_list)}")
                if instance_list:
                    print(f"\n  实例列表:")
                    for idx, instance in enumerate(instance_list, 1):
                        print(f"\n  [{idx}] 实例详情:")
                        print(f"    类型: {type(instance)}")
                        print_instance_attributes(instance, f"实例 {idx} 属性")
                else:
                    print("\n  实例列表为空")
            else:
                # 未知类型，尝试打印所有属性
                print(f"  未知返回类型，尝试打印属性:")
                print_instance_attributes(instance_list, "返回对象属性")
            
            print("\n" + "=" * 60)
            print("测试完成!")
            return 0
            
        except Exception as e:
            print(f"\n✗ 获取实例列表失败!")
            print(f"\n错误信息: {type(e).__name__}: {str(e)}")
            import traceback
            print("\n详细错误堆栈:")
            traceback.print_exc()
            print("\n" + "=" * 60)
            return 1


def main():
    """Main test runner."""
    # 检查凭据配置
    if not check_credentials():
        print("\n" + "=" * 60)
        return 1
    
    api = AliyunOpenAPI()
    
    # 运行所有测试
    results = []
    
    # 测试 get_instance
    print("\n" + "=" * 60)
    test_get_instance = TestGetInstance(api)
    results.append(("get_instance", test_get_instance.run()))
    
    # 测试 get_instance_list
    print("\n" + "=" * 60)
    test_get_instance_list = TestGetInstanceList(api)
    results.append(("get_instance_list", test_get_instance_list.run(max_results=10)))
    
    # 汇总结果
    print("\n" + "=" * 60)
    print("测试结果汇总:")
    print("=" * 60)
    all_passed = True
    for test_name, result in results:
        status = "✓ 通过" if result == 0 else "✗ 失败"
        print(f"  {test_name}: {status}")
        if result != 0:
            all_passed = False
    
    print("=" * 60)
    return 0 if all_passed else 1


if __name__ == "__main__":
    sys.exit(main())

