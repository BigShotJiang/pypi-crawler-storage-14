"""Standalone test script for AliyunOpenAPI account operations.

This script can be run directly without pytest:

Using standard Python:
    python tests/openAPI/test_account.py

Using uv (recommended):
    uv run python tests/openAPI/test_account.py

Make sure dependencies are installed first:
    uv sync
    # or
    pip install -e .
"""

import os
import sys
from pathlib import Path
from typing import Optional

# Add src to path
sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from src.aliyunOpenAPI import AliyunOpenAPI
from tests.openAPI.check_credentials import check_credentials, print_object_attributes
from tests.test_config import ENDPOINT, INSTANCE_ID


class TestCreateAccount:
    """Test class for create_account method."""
    
    def __init__(self, api: AliyunOpenAPI):
        self.api = api
        self.instance_id = INSTANCE_ID
        self.endpoint = ENDPOINT
        self.access_key = os.getenv("ALIBABA_CLOUD_ACCESS_KEY_ID")
        self.secret_key = os.getenv("ALIBABA_CLOUD_ACCESS_KEY_SECRET")
    
    
    def run(self, remark: Optional[str] = None) -> int:
        """Run the test."""
        print("=" * 60)
        print("测试 AliyunOpenAPI.create_account()")
        print("=" * 60)
        
        print(f"\n正在创建账号...")
        print(f"  参数:")
        print(f"    instance_id: {self.instance_id}")
        print(f"    endpoint: {self.endpoint}")
        print(f"    access_key: {self.access_key[:8]}...")
        print(f"    secret_key: {'*' * 8}...")
        print(f"    remark: {remark}")
        print("-" * 60)
        
        try:
            result = self.api.create_account(
                instance_id=self.instance_id,
                access_key=self.access_key,
                secret_key=self.secret_key,
                endpoint=self.endpoint,
                remark=remark
            )
            
            print("\n✓ 成功创建账号!")
            print(f"\n返回结果:")
            print(f"  类型: {type(result)}")
            print_object_attributes(result, "返回对象属性", ['request_id', 'requestId'])
            
            print("\n" + "=" * 60)
            print("测试完成!")
            return 0
            
        except Exception as e:
            print(f"\n✗ 创建账号失败!")
            print(f"\n错误信息: {type(e).__name__}: {str(e)}")
            import traceback
            print("\n详细错误堆栈:")
            traceback.print_exc()
            print("\n" + "=" * 60)
            return 1


class TestListAccounts:
    """Test class for list_accounts method."""
    
    def __init__(self, api: AliyunOpenAPI):
        self.api = api
        self.instance_id = INSTANCE_ID
        self.endpoint = ENDPOINT
    
    def run(self) -> int:
        """Run the test."""
        print("=" * 60)
        print("测试 AliyunOpenAPI.list_accounts()")
        print("=" * 60)
        
        print(f"\n正在获取账号列表...")
        print(f"  参数:")
        print(f"    instance_id: {self.instance_id}")
        print(f"    endpoint: {self.endpoint}")
        print("-" * 60)
        
        try:
            result = self.api.list_accounts(
                instance_id=self.instance_id,
                endpoint=self.endpoint
            )
            
            print("\n✓ 成功获取账号列表!")
            print(f"\n返回结果:")
            print(f"  类型: {type(result)}")
            
            if hasattr(result, 'accounts'):
                accounts = result.accounts or []
                print(f"  账号数量: {len(accounts)}")
                
                if accounts:
                    print(f"\n  账号列表:")
                    for idx, account in enumerate(accounts, 1):
                        print(f"\n  [{idx}] 账号详情:")
                        print(f"    类型: {type(account)}")
                        print_object_attributes(account, f"账号 {idx} 属性", 
                                               ['user_name', 'userName', 'access_key', 'remark'])
                else:
                    print("\n  账号列表为空")
            else:
                print_object_attributes(result, "返回对象属性")
            
            print("\n" + "=" * 60)
            print("测试完成!")
            return 0
            
        except Exception as e:
            print(f"\n✗ 获取账号列表失败!")
            print(f"\n错误信息: {type(e).__name__}: {str(e)}")
            import traceback
            print("\n详细错误堆栈:")
            traceback.print_exc()
            print("\n" + "=" * 60)
            return 1


def main():
    """Main test runner."""
    # 检查凭据配置
    if not check_credentials():
        print("\n" + "=" * 60)
        return 1
    
    api = AliyunOpenAPI()
    
    # 运行所有测试
    results = []
    
    # 测试 create_account
    print("\n" + "=" * 60)
    test_create_account = TestCreateAccount(api)
    results.append(("create_account", test_create_account.run(remark="Test account")))
    
    # 测试 list_accounts
    print("\n" + "=" * 60)
    test_list_accounts = TestListAccounts(api)
    results.append(("list_accounts", test_list_accounts.run()))
    
    # 汇总结果
    print("\n" + "=" * 60)
    print("测试结果汇总:")
    print("=" * 60)
    all_passed = True
    for test_name, result in results:
        status = "✓ 通过" if result == 0 else "✗ 失败"
        print(f"  {test_name}: {status}")
        if result != 0:
            all_passed = False
    
    print("=" * 60)
    return 0 if all_passed else 1


if __name__ == "__main__":
    sys.exit(main())

