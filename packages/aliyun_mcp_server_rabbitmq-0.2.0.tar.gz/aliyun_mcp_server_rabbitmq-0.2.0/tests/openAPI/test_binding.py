"""Standalone test script for AliyunOpenAPI binding operations.

This script can be run directly without pytest:

Using standard Python:
    python tests/openAPI/test_binding.py

Using uv (recommended):
    uv run python tests/openAPI/test_binding.py

Make sure dependencies are installed first:
    uv sync
    # or
    pip install -e .
"""

import sys
from pathlib import Path
from typing import Optional

# Add src to path
sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from src.aliyunOpenAPI import AliyunOpenAPI
from tests.openAPI.check_credentials import check_credentials, print_object_attributes
from tests.test_config import ENDPOINT, INSTANCE_ID


class TestCreateBinding:
    """Test class for create_binding method."""
    
    def __init__(self, api: AliyunOpenAPI):
        self.api = api
        self.instance_id = INSTANCE_ID
        self.endpoint = ENDPOINT
        self.virtual_host = "/"
        self.source_exchange = "amq.direct"
        self.destination_name = "test_queue"
        self.binding_type = 0
    
    def run(self, binding_key: Optional[str] = None) -> int:
        """Run the test."""
        print("=" * 60)
        print("测试 AliyunOpenAPI.create_binding()")
        print("=" * 60)
        
        print(f"\n正在创建绑定...")
        print(f"  参数:")
        print(f"    instance_id: {self.instance_id}")
        print(f"    endpoint: {self.endpoint}")
        print(f"    virtual_host: {self.virtual_host}")
        print(f"    source_exchange: {self.source_exchange}")
        print(f"    destination_name: {self.destination_name}")
        print(f"    binding_key: {binding_key}")
        print(f"    binding_type: {self.binding_type}")
        print("-" * 60)
        
        try:
            result = self.api.create_binding(
                instance_id=self.instance_id,
                virtual_host=self.virtual_host,
                source_exchange=self.source_exchange,
                destination_name=self.destination_name,
                endpoint=self.endpoint,
                binding_key=binding_key,
                binding_type=self.binding_type
            )
            
            print("\n✓ 成功创建绑定!")
            print(f"\n返回结果:")
            print(f"  类型: {type(result)}")
            print_object_attributes(result, "返回对象属性", ['request_id', 'requestId'])
            
            print("\n" + "=" * 60)
            print("测试完成!")
            return 0
            
        except Exception as e:
            print(f"\n✗ 创建绑定失败!")
            print(f"\n错误信息: {type(e).__name__}: {str(e)}")
            import traceback
            print("\n详细错误堆栈:")
            traceback.print_exc()
            print("\n" + "=" * 60)
            return 1


class TestListBindings:
    """Test class for list_bindings method."""
    
    def __init__(self, api: AliyunOpenAPI):
        self.api = api
        self.instance_id = INSTANCE_ID
        self.endpoint = ENDPOINT
        self.virtual_host = "/"
    
    def run(self, next_token: Optional[str] = None, max_results: int = 10) -> int:
        """Run the test."""
        print("=" * 60)
        print("测试 AliyunOpenAPI.list_bindings()")
        print("=" * 60)
        
        print(f"\n正在获取绑定列表...")
        print(f"  参数:")
        print(f"    instance_id: {self.instance_id}")
        print(f"    endpoint: {self.endpoint}")
        print(f"    virtual_host: {self.virtual_host}")
        print(f"    next_token: {next_token}")
        print(f"    max_results: {max_results}")
        print("-" * 60)
        
        try:
            result = self.api.list_bindings(
                instance_id=self.instance_id,
                virtual_host=self.virtual_host,
                endpoint=self.endpoint,
                next_token=next_token,
                max_results=max_results
            )
            
            print("\n✓ 成功获取绑定列表!")
            print(f"\n返回结果:")
            print(f"  类型: {type(result)}")
            
            if hasattr(result, 'bindings'):
                bindings = result.bindings or []
                print(f"  绑定数量: {len(bindings)}")
                if hasattr(result, 'next_token') and result.next_token:
                    print(f"  下一页 token: {result.next_token}")
                if hasattr(result, 'max_results'):
                    print(f"  最大结果数: {result.max_results}")
                
                if bindings:
                    print(f"\n  绑定列表:")
                    for idx, binding in enumerate(bindings, 1):
                        print(f"\n  [{idx}] 绑定详情:")
                        print(f"    类型: {type(binding)}")
                        print_object_attributes(binding, f"绑定 {idx} 属性")
                else:
                    print("\n  绑定列表为空")
            else:
                print_object_attributes(result, "返回对象属性")
            
            print("\n" + "=" * 60)
            print("测试完成!")
            return 0
            
        except Exception as e:
            print(f"\n✗ 获取绑定列表失败!")
            print(f"\n错误信息: {type(e).__name__}: {str(e)}")
            import traceback
            print("\n详细错误堆栈:")
            traceback.print_exc()
            print("\n" + "=" * 60)
            return 1


def main():
    """Main test runner."""
    # 检查凭据配置
    if not check_credentials():
        print("\n" + "=" * 60)
        return 1
    
    api = AliyunOpenAPI()
    
    # 运行所有测试
    results = []
    
    # 测试 create_binding
    print("\n" + "=" * 60)
    test_create_binding = TestCreateBinding(api)
    results.append(("create_binding", test_create_binding.run(binding_key="test_key")))
    
    # 测试 list_bindings
    print("\n" + "=" * 60)
    test_list_bindings = TestListBindings(api)
    results.append(("list_bindings", test_list_bindings.run(max_results=10)))
    
    # 汇总结果
    print("\n" + "=" * 60)
    print("测试结果汇总:")
    print("=" * 60)
    all_passed = True
    for test_name, result in results:
        status = "✓ 通过" if result == 0 else "✗ 失败"
        print(f"  {test_name}: {status}")
        if result != 0:
            all_passed = False
    
    print("=" * 60)
    return 0 if all_passed else 1


if __name__ == "__main__":
    sys.exit(main())

