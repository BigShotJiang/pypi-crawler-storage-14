"""Standalone test script for AliyunOpenAPI vhost operations.

This script can be run directly without pytest:

Using standard Python:
    python tests/openAPI/test_vhost.py

Using uv (recommended):
    uv run python tests/openAPI/test_vhost.py

Make sure dependencies are installed first:
    uv sync
    # or
    pip install -e .
"""

import sys
from pathlib import Path
from typing import Optional

# Add src to path
sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from src.aliyunOpenAPI import AliyunOpenAPI
from tests.openAPI.check_credentials import check_credentials, print_object_attributes
from tests.test_config import ENDPOINT, INSTANCE_ID


class TestCreateVhost:
    """Test class for create_vhost method."""
    
    def __init__(self, api: AliyunOpenAPI):
        self.api = api
        self.instance_id = INSTANCE_ID
        self.endpoint = ENDPOINT
        self.virtual_host = "/"
    
    def run(self) -> int:
        """Run the test."""
        print("=" * 60)
        print("测试 AliyunOpenAPI.create_vhost()")
        print("=" * 60)
        
        print(f"\n正在创建虚拟主机...")
        print(f"  参数:")
        print(f"    instance_id: {self.instance_id}")
        print(f"    endpoint: {self.endpoint}")
        print(f"    virtual_host: {self.virtual_host}")
        print("-" * 60)
        
        try:
            result = self.api.create_vhost(
                instance_id=self.instance_id,
                virtual_host=self.virtual_host,
                endpoint=self.endpoint
            )
            
            print("\n✓ 成功创建虚拟主机!")
            print(f"\n返回结果:")
            print(f"  类型: {type(result)}")
            print_object_attributes(result, "返回对象属性", ['request_id', 'requestId'])
            
            print("\n" + "=" * 60)
            print("测试完成!")
            return 0
            
        except Exception as e:
            print(f"\n✗ 创建虚拟主机失败!")
            print(f"\n错误信息: {type(e).__name__}: {str(e)}")
            import traceback
            print("\n详细错误堆栈:")
            traceback.print_exc()
            print("\n" + "=" * 60)
            return 1


class TestListVhosts:
    """Test class for list_vhosts method."""
    
    def __init__(self, api: AliyunOpenAPI):
        self.api = api
        self.instance_id = INSTANCE_ID
        self.endpoint = ENDPOINT
    
    def run(self, next_token: Optional[str] = None, max_results: int = 10) -> int:
        """Run the test."""
        print("=" * 60)
        print("测试 AliyunOpenAPI.list_vhosts()")
        print("=" * 60)
        
        print(f"\n正在获取虚拟主机列表...")
        print(f"  参数:")
        print(f"    instance_id: {self.instance_id}")
        print(f"    endpoint: {self.endpoint}")
        print(f"    next_token: {next_token}")
        print(f"    max_results: {max_results}")
        print("-" * 60)
        
        try:
            result = self.api.list_vhosts(
                instance_id=self.instance_id,
                endpoint=self.endpoint,
                next_token=next_token,
                max_results=max_results
            )
            
            print("\n✓ 成功获取虚拟主机列表!")
            print(f"\n返回结果:")
            print(f"  类型: {type(result)}")
            
            if hasattr(result, 'vhosts'):
                vhosts = result.vhosts or []
                print(f"  虚拟主机数量: {len(vhosts)}")
                if hasattr(result, 'next_token') and result.next_token:
                    print(f"  下一页 token: {result.next_token}")
                if hasattr(result, 'max_results'):
                    print(f"  最大结果数: {result.max_results}")
                
                if vhosts:
                    print(f"\n  虚拟主机列表:")
                    for idx, vhost in enumerate(vhosts, 1):
                        print(f"\n  [{idx}] 虚拟主机详情:")
                        print(f"    类型: {type(vhost)}")
                        print_object_attributes(vhost, f"虚拟主机 {idx} 属性", 
                                               ['name', 'virtual_host', 'instance_id'])
                else:
                    print("\n  虚拟主机列表为空")
            else:
                print_object_attributes(result, "返回对象属性")
            
            print("\n" + "=" * 60)
            print("测试完成!")
            return 0
            
        except Exception as e:
            print(f"\n✗ 获取虚拟主机列表失败!")
            print(f"\n错误信息: {type(e).__name__}: {str(e)}")
            import traceback
            print("\n详细错误堆栈:")
            traceback.print_exc()
            print("\n" + "=" * 60)
            return 1


def main():
    """Main test runner."""
    # 检查凭据配置
    if not check_credentials():
        print("\n" + "=" * 60)
        return 1
    
    api = AliyunOpenAPI()
    
    # 运行所有测试
    results = []
    
    # 测试 create_vhost
    print("\n" + "=" * 60)
    test_create_vhost = TestCreateVhost(api)
    results.append(("create_vhost", test_create_vhost.run()))
    
    # 测试 list_vhosts
    print("\n" + "=" * 60)
    test_list_vhosts = TestListVhosts(api)
    results.append(("list_vhosts", test_list_vhosts.run(max_results=10)))
    
    # 汇总结果
    print("\n" + "=" * 60)
    print("测试结果汇总:")
    print("=" * 60)
    all_passed = True
    for test_name, result in results:
        status = "✓ 通过" if result == 0 else "✗ 失败"
        print(f"  {test_name}: {status}")
        if result != 0:
            all_passed = False
    
    print("=" * 60)
    return 0 if all_passed else 1


if __name__ == "__main__":
    sys.exit(main())

