"""Credentials check utility for AliyunOpenAPI tests.

This module provides credential checking functionality that can be used
across all test files.

Usage:
    from tests.openAPI.check_credentials import check_credentials
    
    if not check_credentials():
        sys.exit(1)
"""

import os
from pathlib import Path


def check_credentials() -> bool:
    """Check if credentials are configured."""
    print("检查阿里云凭据配置...")
    print("-" * 60)
    
    # 检查环境变量
    access_key_id = os.getenv("ALIBABA_CLOUD_ACCESS_KEY_ID")
    access_key_secret = os.getenv("ALIBABA_CLOUD_ACCESS_KEY_SECRET")
    
    if access_key_id and access_key_secret:
        print("✓ 找到环境变量配置:")
        print(f"  ALIBABA_CLOUD_ACCESS_KEY_ID: {access_key_id[:8]}...")
        print(f"  ALIBABA_CLOUD_ACCESS_KEY_SECRET: {'*' * 8}...")
        return True
    
    # 检查配置文件
    home = Path.home()
    cred_file = home / ".alibabacloud" / "credentials"
    
    if cred_file.exists():
        print(f"✓ 找到配置文件: {cred_file}")
        return True
    
    print("✗ 未找到凭据配置!")
    print("\n请使用以下方式之一配置凭据:")
    print("  1. 环境变量:")
    print("     export ALIBABA_CLOUD_ACCESS_KEY_ID='你的AccessKeyID'")
    print("     export ALIBABA_CLOUD_ACCESS_KEY_SECRET='你的AccessKeySecret'")
    print("  2. 配置文件:")
    print(f"     创建文件: {cred_file}")
    print("     内容格式:")
    print("     [default]")
    print("     type = access_key")
    print("     access_key_id = 你的AccessKeyID")
    print("     access_key_secret = 你的AccessKeySecret")
    print("\n详细说明请查看: CREDENTIALS.md")
    return False


def print_instance_attributes(instance, title: str = "实例属性"):
    """Print instance attributes in a formatted way."""
    print(f"\n  {title}:")
    
    # Instance 对象通常有这些属性
    attrs_to_check = [
        'instance_id', 'instanceId', 'id', 
        'instance_name', 'instanceName', 'name',
        'status', 'instance_type', 'instanceType',
        'region_id', 'regionId', 'region',
        'expire_time', 'expireTime',
        'create_time', 'createTime', 'order_create_time',
        'max_connections', 'maxConnections',
        'max_queues', 'maxQueues', 'max_queue',
        'max_vhosts', 'maxVhosts', 'max_vhost',
        'public_endpoint', 'private_endpoint', 'classic_endpoint',
        'edition', 'storage_size', 'max_tps', 'max_eip_tps'
    ]
    
    found_attrs = False
    for attr in attrs_to_check:
        if hasattr(instance, attr):
            value = getattr(instance, attr)
            print(f"    {attr}: {value}")
            found_attrs = True
    
    # 如果没有找到常见属性，尝试使用 __dict__
    if not found_attrs and hasattr(instance, '__dict__'):
        print("\n  所有实例属性:")
        for key, value in instance.__dict__.items():
            print(f"    {key}: {value}")


def print_object_attributes(obj, title: str = "对象属性", attrs_to_check: list = None):
    """Print object attributes in a formatted way."""
    print(f"\n  {title}:")
    
    if attrs_to_check:
        found_attrs = False
        for attr in attrs_to_check:
            if hasattr(obj, attr):
                value = getattr(obj, attr)
                print(f"    {attr}: {value}")
                found_attrs = True
        
        if not found_attrs and hasattr(obj, '__dict__'):
            print("\n  所有对象属性:")
            for key, value in obj.__dict__.items():
                print(f"    {key}: {value}")
    else:
        # 如果没有指定属性列表，打印所有属性
        if hasattr(obj, '__dict__'):
            for key, value in obj.__dict__.items():
                print(f"    {key}: {value}")
        else:
            print("    (无法获取对象属性)")


if __name__ == "__main__":
    """Run credential check standalone."""
    import sys
    if not check_credentials():
        sys.exit(1)
    else:
        print("\n✓ 凭据配置检查通过!")
        sys.exit(0)

