# 发布指南

本文档说明如何将 `aliyun-mcp-server-rabbitmq` 发布出去，让其他人也能使用。

## 发布前准备

### 1. 更新项目信息

在发布前，请确保 `pyproject.toml` 中的信息是正确的：

- **作者信息**：更新 `authors` 字段中的姓名和邮箱
- **版本号**：确保版本号符合语义化版本规范（如 `0.1.0`）
- **描述**：确保 `description` 准确描述了项目功能

### 2. 确保代码质量

```bash
# 运行测试
uv run pytest


### 3. 更新版本号

版本号在两个地方需要保持一致：
- `pyproject.toml` 中的 `version` 字段
- `src/constant.py` 中的 `MCP_SERVER_VERSION` 常量

## 发布方式

### 发布到 PyPI（推荐）

PyPI 是 Python 包的官方仓库，发布后任何人都可以通过 `pip install` 安装。

#### 步骤 1: 安装构建工具

```bash
# 使用 uv（推荐）
uv pip install build twine

# 或使用 pip
pip install build twine
```

#### 步骤 2: 构建分发包

```bash
# 清理之前的构建文件
rm -rf dist/ build/ *.egg-info

# 构建分发包
uv run python -m build
```

这会在 `dist/` 目录下生成两个文件：
- `aliyun-mcp-server-rabbitmq-0.1.0.tar.gz` (源码包)
- `aliyun_mcp_server_rabbitmq-0.1.0-py3-none-any.whl` (wheel 包)

#### 步骤 3: 检查分发包

```bash
# 检查分发包是否有问题
uv run twine check dist/*
```


#### 步骤 4: 正式发布到 PyPI

```bash
# 注册 PyPI 账号：https://pypi.org/account/register/
# 创建 API token：https://pypi.org/manage/account/token/

# 方式 1: 使用 API token（推荐，避免 OIDC 连接问题）
# 设置环境变量或使用 --username 和 --password 参数
export TWINE_USERNAME=__token__
export TWINE_PASSWORD=pypi-你的API-token

# 或直接在上传时指定
uv run twine upload dist/* --username __token__ --password pypi-你的API-token

# 方式 2: 使用配置文件（推荐用于生产环境）
# 创建 ~/.pypirc 文件：
# [pypi]
# username = __token__
# password = pypi-你的API-token

# 然后直接上传
uv run twine upload dist/*
```

#### 步骤 5: 验证发布

发布成功后，其他人可以通过以下方式安装：

```bash
pip install aliyun-mcp-server-rabbitmq
```

安装后可以直接使用：

```bash
aliyun-mcp-server-rabbitmq
```
   