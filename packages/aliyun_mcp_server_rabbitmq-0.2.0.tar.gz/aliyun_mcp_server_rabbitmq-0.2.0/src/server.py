"""Main entry point for Aliyun RabbitMQ MCP Server."""

import logging
import os
import sys
from pathlib import Path
from fastmcp import FastMCP

# Handle both direct execution and module execution
try:
    from .constant import MCP_SERVER_VERSION
    from .module import RabbitMQModule
except ImportError:
    # If relative import fails, we're running directly
    # Add parent directory to path and use absolute imports
    sys.path.insert(0, str(Path(__file__).parent.parent))
    from src.constant import MCP_SERVER_VERSION
    from src.module import RabbitMQModule

# Configure logger
logger = logging.getLogger(__name__)
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)


def main():
    """Main entry point for the MCP server."""
    # Print version on startup
    logger.info(f"Starting aliyun-mcp-server-rabbitmq v{MCP_SERVER_VERSION}")
    
    # Create FastMCP instance
    mcp = FastMCP("Aliyun RabbitMQ MCP Server")
    
    # Initialize RabbitMQModule without endpoint
    # Endpoint will be provided by MCP client during tool calls
    module = RabbitMQModule(mcp)
    logger.info("RabbitMQModule initialized (endpoint will be provided by client)")
    
    # Check if mutative tools should be enabled (via environment variable)
    allow_mutative_tools = os.getenv("ALLOW_MUTATIVE_TOOLS", "true").lower() == "true"
    logger.info(f"Mutative tools enabled: {allow_mutative_tools}")
    
    # Register all tools
    module.register_tools(allow_mutative_tools=allow_mutative_tools)
    logger.info("All tools registered")
    
    # Run the server
    # FastMCP automatically supports both stdio and HTTP transports
    # For HTTP, it supports streamable responses
    logger.info("Starting MCP server...")
    mcp.run()


if __name__ == "__main__":
    main()



