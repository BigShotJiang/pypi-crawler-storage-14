from typing import List, Dict, Literal
import base64
import hmac
import hashlib
import time
from alibabacloud_amqp_open20191212.client import Client as amqp_open20191212Client
from alibabacloud_credentials.client import Client as CredentialClient
from alibabacloud_tea_openapi import models as open_api_models
from alibabacloud_amqp_open20191212 import models as amqp_open_20191212_models


class AliyunOpenAPI:
    """Aliyun OpenAPI client for RabbitMQ."""
    def __init__(self, endpoint: str = None):
        # 客户端缓存，按 endpoint 存储
        self._client_cache: Dict[str, amqp_open20191212Client] = {}
        # 如果提供了 endpoint，则初始化默认客户端
        # 否则，客户端将在首次使用时根据传入的 endpoint 创建
        if endpoint:
            self.default_endpoint = endpoint
            self._get_client(self.default_endpoint)
        else:
            self.default_endpoint = None
    
    def _create_client(self, endpoint: str) -> amqp_open20191212Client:
        """
        使用凭据初始化账号Client
        @return: Client
        @throws Exception
        """
        # 工程代码建议使用更安全的无AK方式，凭据配置方式请参见：https://help.aliyun.com/document_detail/378659.html。
        credential = CredentialClient()
        config = open_api_models.Config(
            credential=credential
        )
        # Endpoint 请参考 https://api.aliyun.com/product/amqp-open
        config.endpoint = endpoint
        return amqp_open20191212Client(config)
    
    def _get_client(self, endpoint: str = None) -> amqp_open20191212Client:
        """
        获取指定 endpoint 的客户端，如果不存在则创建并缓存
        @param endpoint: 端点地址，如果为 None 则使用默认 endpoint
        @return: Client
        @raises ValueError: 如果 endpoint 为 None 且没有默认 endpoint
        """
        if endpoint is None:
            if self.default_endpoint is None:
                raise ValueError("endpoint must be provided when no default endpoint is set")
            endpoint = self.default_endpoint
        
        if endpoint not in self._client_cache:
            self._client_cache[endpoint] = self._create_client(endpoint)
        
        return self._client_cache[endpoint]
    
    def get_instance(self, instance_id: str, endpoint: str = None) -> amqp_open_20191212_models.GetInstanceResponseBodyData:
        request = amqp_open_20191212_models.GetInstanceRequest(
            instance_id=instance_id
        )
        client = self._get_client(endpoint)
        response = client.get_instance(request)
        return response.body.data

        
    def get_instance_list(
        self, 
        resource_group_id: str = None, 
        next_token: str = None,
        max_results: int = 10,
        endpoint: str = None
    ) -> amqp_open_20191212_models.ListInstancesResponseBodyData:
        """
        获取实例列表
        @param resource_group_id: 资源组ID
        @param next_token: 下一页token
        @param max_results: 最大返回结果数,范围1-100
        @param endpoint: 端点地址，如果为 None 则使用默认 endpoint
        @return: ListInstancesResponseBodyData,包含instances列表
        """
        request = amqp_open_20191212_models.ListInstancesRequest(
            resource_group_id=resource_group_id,
            next_token=next_token,
            max_results=max_results
        )
        client = self._get_client(endpoint)
        response = client.list_instances(request)
        return response.body.data
    
    def create_vhost(self, 
        instance_id: str, 
        virtual_host: str,
        endpoint: str = None
    ) -> amqp_open_20191212_models.CreateVirtualHostResponseBody:
        """
        创建虚拟主机
        @param instance_id: 实例ID
        @param virtual_host: 虚拟主机名称
        @param endpoint: 端点地址，如果为 None 则使用默认 endpoint
        @return: CreateVirtualHostResponseBody,包含request_id
        """
        request = amqp_open_20191212_models.CreateVirtualHostRequest(
            instance_id=instance_id,
            virtual_host=virtual_host
        )
        client = self._get_client(endpoint)
        response = client.create_virtual_host(request)
        return response.body
    
    def list_vhosts(self,
        instance_id: str,
        next_token: str = None,
        max_results: int = 10,
        endpoint: str = None
    ) -> amqp_open_20191212_models.ListVirtualHostsResponseBodyData:
        """
        获取虚拟主机列表
        @param instance_id: 实例ID
        @param next_token: 下一页token
        @param max_results: 最大返回结果数,范围1-100
        @param endpoint: 端点地址，如果为 None 则使用默认 endpoint
        @return: ListVhostsResponseBodyData,包含vhosts列表
        """
        request = amqp_open_20191212_models.ListVirtualHostsRequest(
            instance_id=instance_id,
            next_token=next_token,
            max_results=max_results
        )
        client = self._get_client(endpoint)
        response = client.list_virtual_hosts(request)
        return response.body.data
    
    def create_queue(self,
        instance_id: str,
        virtual_host: str,
        queue_name: str,
        auto_delete_state: bool = False,
        auto_expire_state: int = None,
        dead_letter_exchange: str = None,
        dead_letter_routing_key: str = None,
        exclusive_state: bool = False,
        max_length: int = None,
        maximum_priority: int = None,
        message_ttl: int = None,
        endpoint: str = None
    ) -> amqp_open_20191212_models.CreateQueueResponseBody:
        """
        创建队列
        @param instance_id: 实例ID
        @param virtual_host: 虚拟主机名称
        @param queue_name: 队列名称
        @param auto_delete_state: 是否自动删除
        @param auto_expire_state: 自动过期时间
        @param dead_letter_exchange: 死信交换机
        @param dead_letter_routing_key: 死信路由键
        @param exclusive_state: 是否独占
        @param max_length: 最大长度
        @param maximum_priority: 最大优先级
        @param message_ttl: 消息过期时间
        @param endpoint: 端点地址，如果为 None 则使用默认 endpoint
        @return: CreateQueueResponseBody,包含request_id
        """
        request = amqp_open_20191212_models.CreateQueueRequest(
            auto_delete_state=auto_delete_state,
            auto_expire_state=auto_expire_state,
            dead_letter_exchange=dead_letter_exchange,
            dead_letter_routing_key=dead_letter_routing_key,
            exclusive_state=exclusive_state,
            instance_id=instance_id,
            max_length=max_length,
            maximum_priority=maximum_priority,
            message_ttl=message_ttl,
            queue_name=queue_name,
            virtual_host=virtual_host,
        )
        client = self._get_client(endpoint)
        response = client.create_queue(request)
        return response.body

    def list_queues(self,
        instance_id: str,
        virtual_host: str,
        next_token: str = None,
        max_results: int = 10,
        endpoint: str = None
    ) -> amqp_open_20191212_models.ListQueuesResponseBodyData:
        """
        获取队列列表
        @param instance_id: 实例ID
        @param virtual_host: 虚拟主机名称
        @param next_token: 下一页token
        @param max_results: 最大返回结果数,范围1-100
        @param endpoint: 端点地址，如果为 None 则使用默认 endpoint
        @return: ListQueuesResponseBodyData,包含queues列表
        """
        request = amqp_open_20191212_models.ListQueuesRequest(
            instance_id=instance_id,
            virtual_host=virtual_host,
            next_token=next_token,
            max_results=max_results
        )
        client = self._get_client(endpoint)
        response = client.list_queues(request)
        return response.body.data

    def list_queue_consumers(self,
        instance_id: str,
        virtual_host: str,
        queue: str,
        query_count: int = 10,
        next_token: str = None,
        endpoint: str = None
    ) -> amqp_open_20191212_models.ListQueueConsumersResponseBody:
        """
        获取队列消费者列表
        @param instance_id: 实例ID
        @param virtual_host: 虚拟主机名称
        @param queue: 队列名称  
        @param query_count: 查询数量
        @param next_token: 下一页token
        @param endpoint: 端点地址，如果为 None 则使用默认 endpoint
        @return: ListQueueConsumersResponseBody,包含consumers列表
        """
        request = amqp_open_20191212_models.ListQueueConsumersRequest(
            instance_id=instance_id,
            virtual_host=virtual_host,
            queue=queue,
            query_count=query_count,
            next_token=next_token
        )
        client = self._get_client(endpoint)
        response = client.list_queue_consumers(request)
        return response.body
    
    def list_queue_bindings(self,
        instance_id: str,
        virtual_host: str,
        queue_name: str,
        next_token: str = None,
        max_results: int = 10,
        endpoint: str = None
    ) -> amqp_open_20191212_models.ListQueueUpStreamBindingsResponseBody:
        """
        查询指定Queue被哪些Exchange绑定
        @param instance_id: 实例ID
        @param virtual_host: 虚拟主机名称
        @param queue_name: 队列名称
        @param next_token: 下一页token
        @param max_results: 最大返回结果数,范围1-100
        @param endpoint: 端点地址，如果为 None 则使用默认 endpoint
        @return: ListQueueUpStreamBindingsResponseBody,包含bindings列表
        """
        request = amqp_open_20191212_models.ListQueueUpStreamBindingsRequest(
            instance_id=instance_id,
            virtual_host=virtual_host,
            queue_name=queue_name,
            next_token=next_token,  
            max_results=max_results
        )
        client = self._get_client(endpoint)
        response = client.list_queue_up_stream_bindings(request)
        return response.body
    
    def create_exchange(self,
        instance_id: str,
        virtual_host: str,
        exchange_name: str,
        exchange_type: str,
        xdelayed_type: str = None,  
        auto_delete_state: bool = False,
        internal: bool = False,
        alternate_exchange: str = None,
        endpoint: str = None
    ) -> amqp_open_20191212_models.CreateExchangeResponseBody:
        """
        创建交换机
        @param instance_id: 实例ID
        @param virtual_host: 虚拟主机名称
        @param exchange_name: 交换机名称
        @param exchange_type: 交换机类型,可选值: DIRECT/TOPIC/FANOUT/HEADERS/X_JMS_TOPIC/X_DELAYED_MESSAGE/X_CONSISTENT_HASH.必须大写
        @param xdelayed_type: 延迟交换机类型,可选值: DIRECT/TOPIC/FANOUT/HEADERS/X-JMS-TOPIC.必须大写
        @param auto_delete_state: 是否自动删除
        @param internal: 是否内部交换机
        @param alternate_exchange: 备用交换机名称
        @param endpoint: 端点地址，如果为 None 则使用默认 endpoint
        @return: CreateExchangeResponseBody,包含request_id
        """
        request = amqp_open_20191212_models.CreateExchangeRequest(
            instance_id=instance_id,
            virtual_host=virtual_host,
            exchange_name=exchange_name,
            exchange_type=exchange_type,
            xdelayed_type=xdelayed_type,
            auto_delete_state=auto_delete_state,
            internal=internal,
            alternate_exchange=alternate_exchange
        )
        client = self._get_client(endpoint)
        response = client.create_exchange(request)
        return response.body
    
    def list_exchanges(self,
        instance_id: str,
        virtual_host: str,
        next_token: str = None,
        max_results: int = 10,
        endpoint: str = None
    ) -> amqp_open_20191212_models.ListExchangesResponseBodyData:
        """
        查询指定实例下某一Vhost内创建的所有Exchange
        @param instance_id: 实例ID
        @param virtual_host: 虚拟主机名称
        @param next_token: 下一页token
        @param max_results: 最大返回结果数,范围1-100
        @param endpoint: 端点地址，如果为 None 则使用默认 endpoint
        @return: ListExchangesResponseBodyData,包含exchanges列表
        """
        request = amqp_open_20191212_models.ListExchangesRequest(
            instance_id=instance_id,
            virtual_host=virtual_host,
            next_token=next_token,
            max_results=max_results
        )
        client = self._get_client(endpoint)
        response = client.list_exchanges(request)
        return response.body.data

    def list_exchange_downstream_bindings(self,
        instance_id: str,
        virtual_host: str,
        exchange_name: str,
        next_token: str = None,
        max_results: int = 10,
        endpoint: str = None
    ) -> amqp_open_20191212_models.ListDownStreamBindingsResponseBodyData:
        """
        查询指定Exchange下游绑定了哪些Exchange或Queue
        @param instance_id: 实例ID
        @param virtual_host: 虚拟主机名称
        @param exchange_name: 交换机名称
        @param next_token: 下一页token
        @param max_results: 最大返回结果数,范围1-100
        @param endpoint: 端点地址，如果为 None 则使用默认 endpoint
        @return: ListDownStreamBindingsResponseBodyData,包含bindings列表
        """
        request = amqp_open_20191212_models.ListDownStreamBindingsRequest(
            instance_id=instance_id,
            virtual_host=virtual_host,
            exchange_name=exchange_name,
            next_token=next_token,
            max_results=max_results
        )
        client = self._get_client(endpoint)
        response = client.list_down_stream_bindings(request)
        return response.body.data
    
    def list_exchange_upstream_bindings(self,
        instance_id: str,
        virtual_host: str,
        exchange_name: str,
        next_token: str = None,
        max_results: int = 10,
        endpoint: str = None
    ) -> amqp_open_20191212_models.ListExchangeUpStreamBindingsResponseBodyData:
        """
        查询指定Exchange上游绑定了哪些Exchange
        @param instance_id: 实例ID
        @param virtual_host: 虚拟主机名称
        @param exchange_name: 交换机名称
        @param next_token: 下一页token
        @param max_results: 最大返回结果数,范围1-100
        @param endpoint: 端点地址，如果为 None 则使用默认 endpoint
        @return: ListExchangeUpStreamBindingsResponseBodyData,包含bindings列表
        """
        request = amqp_open_20191212_models.ListExchangeUpStreamBindingsRequest(
            instance_id=instance_id,
            virtual_host=virtual_host,
            exchange_name=exchange_name,
            next_token=next_token,
            max_results=max_results
        )
        client = self._get_client(endpoint)
        response = client.list_exchange_up_stream_bindings(request)
        return response.body.data
    
    def create_binding(self,
        instance_id: str,
        virtual_host: str,
        source_exchange: str,
        destination_name: str,
        binding_key: str = None,
        binding_type: Literal[0, 1] = 0,
        argument: str = None,
        endpoint: str = None
    ) -> amqp_open_20191212_models.CreateBindingResponseBody:
        """
        创建绑定
        @param instance_id: 实例ID
        @param virtual_host: 虚拟主机名称
        @param source_exchange: 源交换机名称
        @param destination_name: 目标名称
        @param binding_key: 绑定键
        @param binding_type: 绑定类型,0: queue, 1: exchange
        @param argument: 绑定参数
        @param endpoint: 端点地址，如果为 None 则使用默认 endpoint
        @return: CreateBindingResponseBody,包含request_id
        """
        request = amqp_open_20191212_models.CreateBindingRequest(
            instance_id=instance_id,
            virtual_host=virtual_host,
            source_exchange=source_exchange,
            destination_name=destination_name,
            binding_key=binding_key,
            binding_type=binding_type,
            argument=argument
        )
        client = self._get_client(endpoint)
        response = client.create_binding(request)
        return response.body
    
    def list_bindings(self,
        instance_id: str,
        virtual_host: str,
        next_token: str = None,
        max_results: int = 10,
        endpoint: str = None
    ) -> amqp_open_20191212_models.ListBindingsResponseBodyData:
        """
        查询指定实例下某一Vhost内创建的所有绑定
        @param instance_id: 实例ID
        @param virtual_host: 虚拟主机名称
        @param next_token: 下一页token
        @param max_results: 最大返回结果数,范围1-100
        @param endpoint: 端点地址，如果为 None 则使用默认 endpoint
        @return: ListBindingsResponseBodyData,包含bindings列表
        """
        request = amqp_open_20191212_models.ListBindingsRequest(
            instance_id=instance_id,
            virtual_host=virtual_host,
            next_token=next_token,
            max_results=max_results
        )
        client = self._get_client(endpoint)
        response = client.list_bindings(request)
        return response.body.data
     
    def create_account(self,
        instance_id: str,
        access_key: str,
        secret_key: str,
        remark: str = None,
        endpoint: str = None
    ) -> amqp_open_20191212_models.CreateAccountResponseBody:
        """
        创建用户名密码
        @param instance_id: 实例ID
        @param access_key: 账号访问密钥(AK)
        @param secret_key: 账号密钥(SK)
        @param remark: 备注
        @param endpoint: 端点地址，如果为 None 则使用默认 endpoint
        @return: CreateAccountResponseBody,包含request_id
        """
        # 计算user_name
        user_name = self._calculate_user_name(instance_id, access_key)
        
        # 计算签名参数
        signatures = self._calculate_signatures(secret_key)
        create_timestamp = int(signatures['create_timestamp'])
        signature = signatures['signature']
        secret_sign = signatures['secret_sign']
        
        request = amqp_open_20191212_models.CreateAccountRequest(
            instance_id=instance_id,
            account_access_key=access_key,
            user_name=user_name,
            signature=signature,
            create_timestamp=create_timestamp,
            secret_sign=secret_sign,
            remark=remark
        )
        client = self._get_client(endpoint)
        response = client.create_account(request)
        return response.body
    
    def list_accounts(self,
        instance_id: str,
        endpoint: str = None
    ) -> amqp_open_20191212_models.ListAccountsResponseBody:
        """
        查询实例下所有用户名密码
        @param instance_id: 实例ID
        @param endpoint: 端点地址，如果为 None 则使用默认 endpoint
        @return: ListAccountsResponseBody,包含accounts列表
        """
        request = amqp_open_20191212_models.ListAccountsRequest(
            instance_id=instance_id
        )
        client = self._get_client(endpoint)
        response = client.list_accounts(request)
        return response.body
    
    def _calculate_user_name(self,
        instance_id: str,
        account_access_key: str
    ) -> str:
        """
        计算用户名（私有方法）
        使用实例ID和账号访问密钥生成API使用的userName
        @param instance_id: 实例ID
        @param account_access_key: 账号访问密钥
        @return: Base64编码后的user_name
        """
        # 使用实例ID和账号访问密钥组成字符串
        str_to_encode = f"2:{instance_id}:{account_access_key}"
        # 生成Base64编码的userName
        encoded_bytes = base64.b64encode(str_to_encode.encode('utf-8'))
        user_name = encoded_bytes.decode('utf-8')
        return user_name
    
    def _calculate_signatures(self,
        secret_key: str
    ) -> Dict[str, str]:
        """
        计算签名参数（私有方法）
        使用密钥生成API使用的create_timestamp、signature、secret_sign
        @param secret_key: 账号的密钥(SK)
        @return: 包含create_timestamp、signature、secret_sign的字典
        """
        # 获取当前时间戳（毫秒）
        create_timestamp = str(int(time.time() * 1000))
        
        # 将字符串转换为字节
        sk_bytes = secret_key.encode('utf-8')
        timestamp_bytes = create_timestamp.encode('utf-8')
        
        # 生成SecretSign: HMAC-SHA1(sk, createTimestamp)
        secret_sign_mac = hmac.new(timestamp_bytes, sk_bytes, hashlib.sha1)
        secret_sign = secret_sign_mac.hexdigest().upper()
        
        # 生成signature: HMAC-SHA1(createTimestamp, sk)
        signature_mac = hmac.new(sk_bytes, timestamp_bytes, hashlib.sha1)
        signature = signature_mac.hexdigest().upper()
        
        return {
            'create_timestamp': create_timestamp,
            'signature': signature,
            'secret_sign': secret_sign
        }
    