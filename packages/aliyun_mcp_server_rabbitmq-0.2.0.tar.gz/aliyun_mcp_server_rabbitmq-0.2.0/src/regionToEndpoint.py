"""Region to Endpoint mapping for Aliyun RabbitMQ AMQP Open API."""

# 地域到Endpoint的映射关系
# 参考: https://api.aliyun.com/product/amqp-open
REGION_TO_ENDPOINT = {
    # 中国地域（13个）
    'cn-qingdao': 'amqp-open.cn-qingdao.aliyuncs.com',         # 华北1（青岛）
    'cn-beijing': 'amqp-open.cn-beijing.aliyuncs.com',        # 华北2（北京）
    'cn-zhangjiakou': 'amqp-open.cn-zhangjiakou.aliyuncs.com', # 华北3（张家口）
    'cn-huhehaote': 'amqp-open.cn-huhehaote.aliyuncs.com',    # 华北5（呼和浩特）
    'cn-wulanchabu': 'amqp-open.cn-wulanchabu.aliyuncs.com',   # 华北6（乌兰察布）
    'cn-hangzhou': 'amqp-open.cn-hangzhou.aliyuncs.com',       # 华东1（杭州）
    'cn-shanghai': 'amqp-open.cn-shanghai.aliyuncs.com',       # 华东2（上海）
    'cn-nanjing': 'amqp-open.cn-nanjing.aliyuncs.com',         # 华东5（南京）
    'cn-fuzhou': 'amqp-open.cn-fuzhou.aliyuncs.com',           # 华东6（福州）
    'cn-shenzhen': 'amqp-open.cn-shenzhen.aliyuncs.com',       # 华南1（深圳）
    'cn-heyuan': 'amqp-open.cn-heyuan.aliyuncs.com',          # 华南2（河源）
    'cn-guangzhou': 'amqp-open.cn-guangzhou.aliyuncs.com',     # 华南3（广州）
    'cn-chengdu': 'amqp-open.cn-chengdu.aliyuncs.com',         # 西南1（成都）
    
    # 中国香港
    'cn-hongkong': 'amqp-open.cn-hongkong.aliyuncs.com',       # 香港
    
    # 金融云地域
    'cn-beijing-finance-1': 'amqp-open.cn-beijing-finance-1.aliyuncs.com',  # 华北2金融云（北京）
    'cn-shanghai-finance-1': 'amqp-open.cn-shanghai-finance-1.aliyuncs.com', # 华东2金融云（上海）
    
    # 亚太地域
    'ap-southeast-1': 'amqp-open.ap-southeast-1.aliyuncs.com', # 新加坡
    'ap-southeast-2': 'amqp-open.ap-southeast-2.aliyuncs.com', # 澳大利亚（悉尼）
    'ap-southeast-3': 'amqp-open.ap-southeast-3.aliyuncs.com', # 马来西亚（吉隆坡）
    'ap-southeast-5': 'amqp-open.ap-southeast-5.aliyuncs.com', # 印度尼西亚（雅加达）
    'ap-southeast-6': 'amqp-open.ap-southeast-6.aliyuncs.com', # 菲律宾（马尼拉）
    'ap-southeast-7': 'amqp-open.ap-southeast-7.aliyuncs.com', # 泰国（曼谷）
    'ap-northeast-1': 'amqp-open.ap-northeast-1.aliyuncs.com', # 日本（东京）
    'ap-south-1': 'amqp-open.ap-south-1.aliyuncs.com',        # 印度（孟买）
    
    # 美国地域
    'us-west-1': 'amqp-open.us-west-1.aliyuncs.com',           # 美国西部1（硅谷）
    'us-east-1': 'amqp-open.us-east-1.aliyuncs.com',           # 美国东部1（弗吉尼亚）
    
    # 欧洲地域
    'eu-west-1': 'amqp-open.eu-west-1.aliyuncs.com',           # 英国（伦敦）
    'eu-central-1': 'amqp-open.eu-central-1.aliyuncs.com',    # 德国（法兰克福）
    
    # 中东地域
    'me-east-1': 'amqp-open.me-east-1.aliyuncs.com',           # 阿联酋（迪拜）
}

# 中文地域名到地域ID的映射
CHINESE_NAME_TO_REGION = {
    # 中国地域
    '青岛': 'cn-qingdao',
    '北京': 'cn-beijing',
    '张家口': 'cn-zhangjiakou',
    '呼和浩特': 'cn-huhehaote',
    '乌兰察布': 'cn-wulanchabu',
    '杭州': 'cn-hangzhou',
    '上海': 'cn-shanghai',
    '南京': 'cn-nanjing',
    '福州': 'cn-fuzhou',
    '深圳': 'cn-shenzhen',
    '河源': 'cn-heyuan',
    '广州': 'cn-guangzhou',
    '成都': 'cn-chengdu',
    '香港': 'cn-hongkong',
    # 金融云
    '北京金融云': 'cn-beijing-finance-1',
    '上海金融云': 'cn-shanghai-finance-1',
    '华北2金融云': 'cn-beijing-finance-1',
    '华东2金融云': 'cn-shanghai-finance-1',
    # 亚太地域
    '新加坡': 'ap-southeast-1',
    '悉尼': 'ap-southeast-2',
    '澳大利亚': 'ap-southeast-2',
    '吉隆坡': 'ap-southeast-3',
    '马来西亚': 'ap-southeast-3',
    '雅加达': 'ap-southeast-5',
    '印度尼西亚': 'ap-southeast-5',
    '马尼拉': 'ap-southeast-6',
    '菲律宾': 'ap-southeast-6',
    '曼谷': 'ap-southeast-7',
    '泰国': 'ap-southeast-7',
    '东京': 'ap-northeast-1',
    '日本': 'ap-northeast-1',
    '孟买': 'ap-south-1',
    '印度': 'ap-south-1',
    # 美国地域
    '硅谷': 'us-west-1',
    '美国西部': 'us-west-1',
    '美西': 'us-west-1',
    '弗吉尼亚': 'us-east-1',
    '美国东部': 'us-east-1',
    '美东': 'us-east-1',
    # 欧洲地域
    '伦敦': 'eu-west-1',
    '英国': 'eu-west-1',
    '法兰克福': 'eu-central-1',
    '德国': 'eu-central-1',
    # 中东地域
    '迪拜': 'me-east-1',
    '阿联酋': 'me-east-1',
}

# 英文城市名到地域ID的映射（用于处理如hangzhou -> cn-hangzhou的情况）
ENGLISH_NAME_TO_REGION = {
    'qingdao': 'cn-qingdao',
    'beijing': 'cn-beijing',
    'zhangjiakou': 'cn-zhangjiakou',
    'huhehaote': 'cn-huhehaote',
    'wulanchabu': 'cn-wulanchabu',
    'hangzhou': 'cn-hangzhou',
    'shanghai': 'cn-shanghai',
    'nanjing': 'cn-nanjing',
    'fuzhou': 'cn-fuzhou',
    'shenzhen': 'cn-shenzhen',
    'heyuan': 'cn-heyuan',
    'guangzhou': 'cn-guangzhou',
    'chengdu': 'cn-chengdu',
    'hongkong': 'cn-hongkong',
    'singapore': 'ap-southeast-1',
    'sydney': 'ap-southeast-2',
    'australia': 'ap-southeast-2',
    'kualalumpur': 'ap-southeast-3',
    'malaysia': 'ap-southeast-3',
    'jakarta': 'ap-southeast-5',
    'indonesia': 'ap-southeast-5',
    'manila': 'ap-southeast-6',
    'philippines': 'ap-southeast-6',
    'bangkok': 'ap-southeast-7',
    'thailand': 'ap-southeast-7',
    'tokyo': 'ap-northeast-1',
    'japan': 'ap-northeast-1',
    'mumbai': 'ap-south-1',
    'india': 'ap-south-1',
    'siliconvalley': 'us-west-1',
    'virginia': 'us-east-1',
    'london': 'eu-west-1',
    'frankfurt': 'eu-central-1',
    'germany': 'eu-central-1',
    'dubai': 'me-east-1',
    'uae': 'me-east-1',
}


def _normalize_region(region: str) -> str:
    """
    标准化地域输入,尝试将中文名或英文名转换为地域ID。
    
    支持带括号的格式,如"马来西亚(吉隆坡)",会尝试提取括号内外的内容进行匹配。
    
    Args:
        region: 地域输入,可能是地域ID、中文名或英文名
        
    Returns:
        标准化的地域ID,如果无法匹配则返回原始输入的小写形式
    """
    region_lower = region.lower().strip()
    
    # 1. 如果已经是标准地域ID格式,直接返回
    if region_lower in REGION_TO_ENDPOINT:
        return region_lower
    
    # 2. 处理带括号的格式,如"马来西亚(吉隆坡)"
    # 提取括号内的内容(通常是城市名)和括号外的内容(通常是国家/地区名)
    import re
    bracket_match = re.match(r'^(.+?)\((.+?)\)$', region)
    if bracket_match:
        outer_part = bracket_match.group(1).strip()  # 括号外的部分,如"马来西亚"
        inner_part = bracket_match.group(2).strip()   # 括号内的部分,如"吉隆坡"
        
        # 优先尝试括号内的内容(通常是更具体的城市名)
        if inner_part in CHINESE_NAME_TO_REGION:
            return CHINESE_NAME_TO_REGION[inner_part]
        if inner_part.lower() in ENGLISH_NAME_TO_REGION:
            return ENGLISH_NAME_TO_REGION[inner_part.lower()]
        
        # 再尝试括号外的内容
        if outer_part in CHINESE_NAME_TO_REGION:
            return CHINESE_NAME_TO_REGION[outer_part]
        if outer_part.lower() in ENGLISH_NAME_TO_REGION:
            return ENGLISH_NAME_TO_REGION[outer_part.lower()]
    
    # 3. 尝试中文名匹配
    if region in CHINESE_NAME_TO_REGION:
        return CHINESE_NAME_TO_REGION[region]
    
    # 4. 尝试英文名匹配
    if region_lower in ENGLISH_NAME_TO_REGION:
        return ENGLISH_NAME_TO_REGION[region_lower]
    
    # 5. 如果输入已经是完整的地域ID格式(如cn-hangzhou),直接返回
    if '-' in region_lower:
        return region_lower
    
    # 6. 尝试将单个城市名转换为地域ID格式
    # 例如: hangzhou -> cn-hangzhou
    common_cn_prefixes = ['cn-', 'ap-', 'us-', 'eu-', 'me-']
    if not any(region_lower.startswith(prefix) for prefix in common_cn_prefixes):
        # 尝试添加cn-前缀(最常见)
        potential_region = f'cn-{region_lower}'
        if potential_region in REGION_TO_ENDPOINT:
            return potential_region
    
    # 无法匹配,返回原始输入
    return region_lower


def region_to_endpoint(region: str) -> str:
    """
    将地域ID、中文名或英文名转换为对应的Endpoint地址。
    
    支持多种输入格式:
    - 标准地域ID: 'cn-hangzhou', 'ap-southeast-1' 等
    - 中文名: '杭州', '北京', '新加坡' 等
    - 英文名: 'hangzhou', 'beijing', 'singapore' 等
    
    如果地域不在支持列表中,会自动拼接为 amqp-open.{region}.aliyuncs.com 格式。
    
    Args:
        region: 地域ID、中文名或英文名,例如 'cn-hangzhou', '杭州', 'hangzhou' 等
        
    Returns:
        对应的Endpoint地址,例如 'amqp-open.cn-hangzhou.aliyuncs.com'
    """
    if not region:
        raise ValueError("Region cannot be empty")
    
    # 标准化地域输入
    normalized_region = _normalize_region(region)
    
    # 如果在支持列表中,直接返回
    if normalized_region in REGION_TO_ENDPOINT:
        return REGION_TO_ENDPOINT[normalized_region]
    
    # 如果不在支持列表中,自动拼接endpoint
    # 确保格式正确(如果已经是完整格式则直接使用,否则拼接)
    if normalized_region.startswith('amqp-open.'):
        return normalized_region
    else:
        return f'amqp-open.{normalized_region}.aliyuncs.com'


def get_supported_regions() -> list:
    """
    获取所有支持的地域列表。
    
    Returns:
        支持的地域ID列表
    """
    return sorted(REGION_TO_ENDPOINT.keys())

