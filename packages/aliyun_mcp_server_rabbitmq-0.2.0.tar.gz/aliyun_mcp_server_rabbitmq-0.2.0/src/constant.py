"""Constants for Aliyun RabbitMQ MCP Server."""

MCP_SERVER_VERSION = "0.2.0"





