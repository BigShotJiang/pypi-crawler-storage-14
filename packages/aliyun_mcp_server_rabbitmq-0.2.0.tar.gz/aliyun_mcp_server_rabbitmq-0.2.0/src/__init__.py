"""Aliyun MCP Server for RabbitMQ."""

__version__ = "0.1.0"




