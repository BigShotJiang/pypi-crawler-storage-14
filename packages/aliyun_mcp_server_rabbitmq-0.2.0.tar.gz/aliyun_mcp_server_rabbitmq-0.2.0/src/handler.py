"""RabbitMQ MCP Server handlers."""

from typing import Literal

from alibabacloud_amqp_open20191212 import models as amqp_open_20191212_models

from .aliyunOpenAPI import AliyunOpenAPI
from .regionToEndpoint import region_to_endpoint, get_supported_regions
 
##########################################
######      instance handlers       ######
##########################################

def get_instance(
    api: AliyunOpenAPI,
    instance_id: str,
    region: str
) -> amqp_open_20191212_models.GetInstanceResponseBodyData:
    endpoint = region_to_endpoint(region)
    return api.get_instance(instance_id, endpoint=endpoint);

def get_instance_list(
    api: AliyunOpenAPI,
    region: str,
    resource_group_id: str = None,
    next_token: str = None,
    max_results: int = 10
) -> amqp_open_20191212_models.ListInstancesResponseBodyData:
    endpoint = region_to_endpoint(region)
    return api.get_instance_list(resource_group_id, next_token, max_results, endpoint=endpoint);

########################################
######      vhost handlers       ######
########################################
def create_vhost(
    api: AliyunOpenAPI,
    instance_id: str,
    virtual_host: str,
    region: str
) -> amqp_open_20191212_models.CreateVirtualHostResponseBody:
    endpoint = region_to_endpoint(region)
    return api.create_vhost(instance_id, virtual_host, endpoint=endpoint);

def list_vhosts(
    api: AliyunOpenAPI,
    instance_id: str,
    region: str,
    next_token: str = None,
    max_results: int = 10
) -> amqp_open_20191212_models.ListVirtualHostsResponseBodyData:
    endpoint = region_to_endpoint(region)
    return api.list_vhosts(instance_id, next_token, max_results, endpoint=endpoint);

########################################
######      queue handlers       ######
########################################

def create_queue(
    api: AliyunOpenAPI,
    instance_id: str,
    virtual_host: str,
    queue_name: str,
    region: str,
    auto_delete_state: bool = False,
    auto_expire_state: int = None,
    dead_letter_exchange: str = None,
    dead_letter_routing_key: str = None,
    exclusive_state: bool = False,
    max_length: int = None,
    maximum_priority: int = None,
    message_ttl: int = None
) -> amqp_open_20191212_models.CreateQueueResponseBody:
    endpoint = region_to_endpoint(region)
    return api.create_queue(instance_id, virtual_host, queue_name, auto_delete_state, auto_expire_state, dead_letter_exchange, dead_letter_routing_key, exclusive_state, max_length, maximum_priority, message_ttl, endpoint=endpoint);

def list_queues(
    api: AliyunOpenAPI,
    instance_id: str,
    virtual_host: str,
    region: str,
    next_token: str = None,
    max_results: int = 10
) -> amqp_open_20191212_models.ListQueuesResponseBodyData:
    endpoint = region_to_endpoint(region)
    return api.list_queues(instance_id, virtual_host, next_token, max_results, endpoint=endpoint);

def list_queue_consumers(
    api: AliyunOpenAPI,
    instance_id: str,
    virtual_host: str,
    queue: str,
    region: str,
    query_count: int = 10,
    next_token: str = None
) -> amqp_open_20191212_models.ListQueueConsumersResponseBody:
    endpoint = region_to_endpoint(region)
    return api.list_queue_consumers(instance_id, virtual_host, queue, query_count, next_token, endpoint=endpoint);

def list_queue_bindings(
    api: AliyunOpenAPI,
    instance_id: str,
    virtual_host: str,
    queue_name: str,
    region: str,
    next_token: str = None,
    max_results: int = 10
) -> amqp_open_20191212_models.ListQueueUpStreamBindingsResponseBody:
    endpoint = region_to_endpoint(region)
    return api.list_queue_bindings(instance_id, virtual_host, queue_name, next_token, max_results, endpoint=endpoint);


###########################################
######      exchangen handlers       ######
###########################################

def list_exchanges(
    api: AliyunOpenAPI,
    instance_id: str,
    virtual_host: str,
    region: str,
    next_token: str = None,
    max_results: int = 10
) -> amqp_open_20191212_models.ListExchangesResponseBodyData:
    endpoint = region_to_endpoint(region)
    return api.list_exchanges(instance_id, virtual_host, next_token, max_results, endpoint=endpoint);

def create_exchange(
    api: AliyunOpenAPI,
    instance_id: str,
    virtual_host: str,
    exchange_name: str,
    exchange_type: str,
    region: str,
    xdelayed_type: str = None,
    auto_delete_state: bool = False,
    internal: bool = False,
    alternate_exchange: str = None
) -> amqp_open_20191212_models.CreateExchangeResponseBody:
    endpoint = region_to_endpoint(region)
    return api.create_exchange(instance_id, virtual_host, exchange_name, exchange_type, xdelayed_type, auto_delete_state, internal, alternate_exchange, endpoint=endpoint);

def list_exchange_downstream_bindings(
    api: AliyunOpenAPI,
    instance_id: str,
    virtual_host: str,
    exchange_name: str,
    region: str,
    next_token: str = None,
    max_results: int = 10
) -> amqp_open_20191212_models.ListDownStreamBindingsResponseBodyData:
    endpoint = region_to_endpoint(region)
    return api.list_exchange_downstream_bindings(instance_id, virtual_host, exchange_name, next_token, max_results, endpoint=endpoint);

def list_exchange_upstream_bindings(
    api: AliyunOpenAPI,
    instance_id: str,
    virtual_host: str,
    exchange_name: str,
    region: str,
    next_token: str = None,
    max_results: int = 10
) -> amqp_open_20191212_models.ListExchangeUpStreamBindingsResponseBodyData:
    endpoint = region_to_endpoint(region)
    return api.list_exchange_upstream_bindings(instance_id, virtual_host, exchange_name, next_token, max_results, endpoint=endpoint);


########################################
######      binding handlers       #####
########################################

def create_binding(
    api: AliyunOpenAPI,
    instance_id: str,
    virtual_host: str,
    source_exchange: str,
    destination_name: str,
    region: str,
    binding_key: str = None,
    binding_type: Literal[0, 1] = 0,
    argument: str = None
) -> amqp_open_20191212_models.CreateBindingResponseBody:
    endpoint = region_to_endpoint(region)
    return api.create_binding(instance_id, virtual_host, source_exchange, destination_name, binding_key, binding_type, argument, endpoint=endpoint);

def list_bindings(
    api: AliyunOpenAPI,
    instance_id: str,
    virtual_host: str,
    region: str,
    next_token: str = None,
    max_results: int = 10
) -> amqp_open_20191212_models.ListBindingsResponseBodyData:
    endpoint = region_to_endpoint(region)
    return api.list_bindings(instance_id, virtual_host, next_token, max_results, endpoint=endpoint);

########################################
######      account handlers       #####
########################################

def create_account(
    api: AliyunOpenAPI,
    instance_id: str,
    access_key: str,
    secret_key: str,
    region: str,
    remark: str = None
) -> amqp_open_20191212_models.CreateAccountResponseBody:
    endpoint = region_to_endpoint(region)
    return api.create_account(instance_id, access_key, secret_key, remark, endpoint=endpoint);

def list_accounts(
    api: AliyunOpenAPI,
    instance_id: str,
    region: str
) -> amqp_open_20191212_models.ListAccountsResponseBody:
    endpoint = region_to_endpoint(region)
    return api.list_accounts(instance_id, endpoint=endpoint);

########################################
######      region handlers       #####
########################################

def get_supported_regions_list() -> list:
    """
    获取所有支持的地域列表。
    
    Returns:
        支持的地域ID列表,按字母顺序排序
    """
    return get_supported_regions()

