"""RabbitMQ MCP Server module."""

import functools
import inspect
from functools import partial
from typing import Callable

from fastmcp import FastMCP

from .aliyunOpenAPI import AliyunOpenAPI
from .handler import (
    get_instance,
    get_instance_list,
    create_vhost,
    list_vhosts,
    create_queue,
    list_queues,
    list_queue_consumers,
    list_queue_bindings,
    list_exchanges,
    create_exchange,
    list_exchange_downstream_bindings,
    list_exchange_upstream_bindings,
    create_binding,
    list_bindings,
    create_account,
    list_accounts,
    get_supported_regions_list,
)

class RabbitMQModule:
    """RabbitMQ MCP Server module."""
    def __init__(self, mcp: FastMCP):
        self.mcp = mcp
        self.api = AliyunOpenAPI()

    def _bind_handler(self, handler: Callable) -> Callable:
        """
        Bind handler function with self.api as first argument.
        
        This is a workaround for fastmcp not accepting functools.partial.
        It creates a wrapper function that calls the handler with self.api bound,
        while preserving the function signature (without the 'api' parameter)
        for fastmcp's introspection.
        """
        # Create a partial function to bind self.api
        bound_func = partial(handler, self.api)
        
        # Convert partial to a regular function by creating a wrapper
        # This preserves the function signature for fastmcp's introspection
        @functools.wraps(handler)
        def wrapper(*args, **kwargs):
            return bound_func(*args, **kwargs)
        
        # Update __signature__ to remove the 'api' parameter
        # This allows fastmcp to correctly introspect the function parameters
        sig = inspect.signature(handler)
        params = list(sig.parameters.values())
        # Remove the first parameter (api) if it exists
        if params and params[0].name == 'api':
            new_params = params[1:]
            wrapper.__signature__ = sig.replace(parameters=new_params)
        
        return wrapper

    def register_tools(self, allow_mutative_tools: bool = True):
        """Register RabbitMQ management tools."""
        self._register_read_only_tools()
        if allow_mutative_tools:
            self._register_mutative_tools()

    def _register_read_only_tools(self):
        """Register read-only tools."""
        self.mcp.tool(
            self._bind_handler(get_instance),
            name="get_instance",
            description="Get a RabbitMQ instance"
        )
        self.mcp.tool(
            self._bind_handler(get_instance_list),
            name="get_instance_list",
            description="Get a list of RabbitMQ instances"
        )
        self.mcp.tool(
            self._bind_handler(list_vhosts),
            name="list_vhosts",
            description="Get a list of RabbitMQ vhosts"
        )
        self.mcp.tool(
            self._bind_handler(list_queues),
            name="list_queues",
            description="Get a list of RabbitMQ queues"
        )
        self.mcp.tool(
            self._bind_handler(list_queue_consumers),
            name="list_queue_consumers",
            description="Get a list of RabbitMQ queue consumers"
        )
        self.mcp.tool(
            self._bind_handler(list_queue_bindings),
            name="list_queue_bindings",
            description="Get a list of RabbitMQ queue bindings"
        )
        self.mcp.tool(
            self._bind_handler(list_exchanges),
            name="list_exchanges",
            description="Get a list of RabbitMQ exchanges"
        )
        self.mcp.tool(
            self._bind_handler(list_exchange_downstream_bindings),
            name="list_exchange_downstream_bindings",
            description="Get a list of RabbitMQ exchange downstream bindings"
        )
        self.mcp.tool(
            self._bind_handler(list_exchange_upstream_bindings),
            name="list_exchange_upstream_bindings",
            description="Get a list of RabbitMQ exchange upstream bindings"
        )
        self.mcp.tool(
            self._bind_handler(list_bindings),
            name="list_bindings",
            description="Get a list of RabbitMQ bindings"
        )
        self.mcp.tool(
            self._bind_handler(list_accounts),
            name="list_accounts",
            description="Get a list of RabbitMQ accounts"
        )
        self.mcp.tool(
            get_supported_regions_list,
            name="get_supported_regions",
            description="Get a list of all supported regions for RabbitMQ AMQP Open API"
        )

    def _register_mutative_tools(self):
        """Register mutative tools."""
        self.mcp.tool(
            self._bind_handler(create_vhost),
            name="create_vhost",
            description="Create a new RabbitMQ vhost"
        )
        self.mcp.tool(
            self._bind_handler(create_queue),
            name="create_queue",
            description="Create a new RabbitMQ queue"
        )
        self.mcp.tool(
            self._bind_handler(create_exchange),
            name="create_exchange",
            description="Create a new RabbitMQ exchange"
        )
        self.mcp.tool(
            self._bind_handler(create_binding),
            name="create_binding",
            description="Create a new RabbitMQ binding"
        )
        self.mcp.tool(
            self._bind_handler(create_account),
            name="create_account",
            description="Create a new RabbitMQ account"
        )