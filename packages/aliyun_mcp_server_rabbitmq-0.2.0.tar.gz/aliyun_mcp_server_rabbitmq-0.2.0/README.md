# Aliyun RabbitMQ MCP Server

一个用于阿里云 RabbitMQ 的 Model Context Protocol (MCP) 服务器，允许 LLM 通过 MCP 协议管理和操作阿里云 RabbitMQ 资源。


## 如何运行 MCP Server

本文档说明如何将 `server.py` 作为 MCP server 运行起来。

## 前置条件

1. **安装依赖**（如果还没有安装）：
   ```bash
   # 使用 uv（推荐）
   uv sync
   
   # 或使用 pip
   pip install -e .
   ```

2. **配置阿里云凭据**（通过环境变量）：
   ```bash
   export ALIBABA_CLOUD_ACCESS_KEY_ID="你的AccessKeyID"
   export ALIBABA_CLOUD_ACCESS_KEY_SECRET="你的AccessKeySecret"
   ```


## MCP 客户端配置
 
### Cursor 配置

#### 通过配置文件配置

在项目根目录下创建 `.cursor/mcp.json` 文件（如果目录不存在，需要先创建），或在用户目录下创建 `~/.cursor/mcp.json`：

**方案 1：使用 uv 运行（需要设置 PYTHONPATH）**

```json
{
  "mcpServers": {
    "aliyun-rabbitmq": {
      "command": "/pathTo/aliyun-mcp-server-rabbitmq/.venv/bin/python",
      "args": ["-m", "src.server"],
      "cwd": "/pathTo/aliyun-mcp-server-rabbitmq" 
    }
  }
}
```

**方案 2：使用已安装的命令（推荐，最简单）**

项目已经发布到阿里内部仓库，可以使用下列方式直接依赖。

```json
{
  "mcpServers": {
    "aliyun-rabbitmq": {
      "command": "uvx",
      "args": [
        "aliyun-mcp-server-rabbitmq"
      ],
      "env": {
        "CONNECTION_STRING": ""
      }
    }
  }
}
```
 

 


