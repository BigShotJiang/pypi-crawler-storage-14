This module will be installed automatically if the modules
*phone_validation* and *base_business_document_import* are installed.
