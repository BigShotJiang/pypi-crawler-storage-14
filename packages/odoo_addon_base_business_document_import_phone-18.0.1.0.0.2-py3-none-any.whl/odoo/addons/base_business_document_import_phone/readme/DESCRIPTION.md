With this module, Odoo will be able to use phone or mobile numbers to
find the appropriate partner when importing business documents. When the
*phone_validation* module from the official addons is installed, the
phone numbers are stored in E.164 format (for example: +33 1 41 98 12
42) in Odoo. This allows reliable search on phone or mobile numbers when
importing business documents.
