"""Tests for writing multiple entries for the same tag in different metadata formats."""
