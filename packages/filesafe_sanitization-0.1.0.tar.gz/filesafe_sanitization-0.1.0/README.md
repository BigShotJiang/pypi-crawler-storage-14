# filesafe

Minimal helper to sanitize filenames before uploading (e.g., to S3).

API:
- `safe_filename(name: str, max_len: int = 100, default: str = "file", ascii_only: bool = True) -> str`

Example:
```python
from filesafe import safe_filename
safe = safe_filename(" My Report (final).PDF ")
# "My_Report_final.pdf"
```