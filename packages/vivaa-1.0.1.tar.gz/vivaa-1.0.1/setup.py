from setuptools import setup, find_packages
from pathlib import Path

# Read the README file for long description
this_directory = Path(__file__).parent
readme_path = this_directory / "README.md"
long_description = readme_path.read_text(encoding="utf-8") if readme_path.exists() else ""

setup(
    name="vivaa",  # lowercase is best for PyPI package name
    version="1.0.1",
    author="Vishnu Vardhan Reddy Biyyapu",
    author_email="vardhan101101@gmail.com",
    description="VIVA – Versatile Intelligent Visual Annotator",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/your_github_username/VIVA",
    packages=find_packages(exclude=("tests", "docs", "examples")),
    include_package_data=True,
    install_requires=[
        "absl-py>=2.3.0",
        "albumentations>=2.0.6",
        "attrs>=25.3.0",
        "autopy>=4.0.1",
        "certifi>=2025.4.26",
        "cffi>=1.17.1",
        "colorama>=0.4.6",
        "cycler>=0.12.1",
        "docutils>=0.22.2",
        "filelock>=3.18.0",
        "flatbuffers>=25.2.10",
        "fonttools>=4.56.0",
        "fsspec>=2025.3.2",
        "jax>=0.6.1",
        "jaxlib>=0.6.1",
        "Jinja2>=3.1.6",
        "kiwisolver>=1.4.8",
        "matplotlib>=3.10.1",
        "ml_dtypes>=0.5.1",
        "numpy>=1.26.4",
        "opencv-contrib-python>=4.11.0.86",
        "opencv-python>=4.11.0.86",
        "opencv-python-headless>=4.11.0.86",
        "opt_einsum>=3.4.0",
        "pandas>=2.2.3",
        "pillow>=11.1.0",
        "pycparser>=2.22",
        "pydantic>=2.11.4",
        "PyQt5>=5.15.11",
        "PyQt5-Qt5>=5.15.2",
        "PyQt5_sip>=12.17.0",
        "PyYAML>=6.0.2",
        "requests>=2.32.3",
        "scipy>=1.15.3",
        "seaborn>=0.13.2",
        "sentencepiece>=0.2.0",
        "sounddevice>=0.5.2",
        "torch>=2.7.0",
        "torchvision>=0.22.0",
        "tqdm>=4.67.1",
        "typing_extensions>=4.13.2",
        "ultralytics>=8.3.133",
    ],
    entry_points={
        "console_scripts": [
            "vivaa=vivaa.main:main",  # allows `vivaa` command to run your app
        ],
    },
    keywords=(
        "annotation tool ai pyqt5 computer vision yolo dataset labeling "
        "image-processing vivaa"
    ),
    classifiers=[
        "Development Status :: 5 - Production/Stable",
        "Intended Audience :: Developers",
        "Intended Audience :: Education",
        "Topic :: Software Development :: Build Tools",
        "Topic :: Software Development :: User Interfaces",
        "Topic :: Scientific/Engineering :: Artificial Intelligence",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.10",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.8",
)
