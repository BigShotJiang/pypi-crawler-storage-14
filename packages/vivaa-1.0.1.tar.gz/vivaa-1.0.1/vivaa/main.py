from PyQt5.QtWidgets import QApplication
import sys
from .fun_pyqt5  import MainWindow


def main():
    try:
        app = QApplication(sys.argv)
        main_window = MainWindow()
        main_window.showMaximized()
        sys.exit(app.exec_())
    except Exception as e:
        print(f"Error in main: {e}")


if __name__ == '__main__':

    main()