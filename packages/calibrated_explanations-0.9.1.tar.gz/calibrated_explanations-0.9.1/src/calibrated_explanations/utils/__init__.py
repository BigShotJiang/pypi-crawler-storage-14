"""Shared utilities used across calibrated explanations."""
