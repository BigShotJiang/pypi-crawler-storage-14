# AUTHORS

This project distinguishes between core authors of the method and software, and broader community contributors.

## Main authors

- Helena Löfström
- Tuwe Löfström

## Authors (as referenced in the papers and software)

- Ulf Johansson
- Cecilia Sönströd
- Rudy Matela
- Johan Hallberg Szabadváry

For citation details, see docs/citing.md and the papers listed in the README.
