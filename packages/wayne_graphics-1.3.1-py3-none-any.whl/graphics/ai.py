# ai_wayne.py

from graphics.core import WayneGraphics
from graphics.shapes import drawRect, drawCircle, drawText
from graphics.events import onMousePress, onKeyPress
# groups API uses app.createGroup(canvas, shape)
# Assuming groups behave like wrappers with move(x,y) etc.

# ---------- Response ----------
class Response:
    def ok(self, message, data=None):
        return {"status": "ok", "message": message, "data": data or {}}

    def error(self, message, details=None):
        return {"status": "error", "message": message, "details": details or {}}


# ---------- Scene Controller ----------
class SceneController:
    def __init__(self, app):
        self.app = app
        self.canvas = app.canvas
        self.objects = {}   # id -> shape (canvas item or wrapper returned by draw*)
        self.labels = {}    # id -> optional text label item id
        self.groups = {}    # name -> group instance
        self._next_id = 1
        self.last_click = None

    def _alloc_id(self):
        i = self._next_id
        self._next_id += 1
        return i

    def _add(self, shape):
        shape_id = self._alloc_id()
        self.objects[shape_id] = shape
        return shape_id

    def draw_rect(self, x, y, w, h, color):
        shape = drawRect(self.canvas, x, y, w, h, color=color)
        return self._add(shape)

    def draw_circle(self, x, y, r, color):
        shape = drawCircle(self.canvas, x, y, r, color=color)
        return self._add(shape)

    def draw_text(self, x, y, text, font=("Courier", 14), color="black"):
        shape = drawText(self.canvas, x, y, text, font=font, color=color)
        return self._add(shape)

    def move(self, obj_id, dx, dy):
        shape = self.objects.get(obj_id)
        if not shape:
            return False
        try:
            # Wayne Graphics shapes typically expose canvas item IDs or wrappers with move
            if hasattr(shape, "move"):
                shape.move(dx, dy)
            else:
                # Fallback: canvas.move(item_id, dx, dy) if shape is a raw item id
                self.canvas.move(shape, dx, dy)
            # Move label if exists
            label_id = self.labels.get(obj_id)
            if label_id:
                self.canvas.move(label_id, dx, dy)
            return True
        except Exception:
            return False

    def delete(self, obj_id):
        shape = self.objects.get(obj_id)
        if not shape:
            return False
        try:
            # Try a common pattern: canvas.delete(item_id) or shape.delete()
            if hasattr(shape, "delete"):
                shape.delete()
            else:
                self.canvas.delete(shape)
            if obj_id in self.objects:
                del self.objects[obj_id]
            label_id = self.labels.pop(obj_id, None)
            if label_id:
                self.canvas.delete(label_id)
            return True
        except Exception:
            return False

    def style(self, obj_id, fill=None, outline=None, width=None):
        shape = self.objects.get(obj_id)
        if not shape:
            return False
        try:
            # If shapes are wrappers, expose setFill/setOutline/setWidth; otherwise use canvas.itemconfig
            if hasattr(shape, "setFill") and fill:
                shape.setFill(fill)
            if hasattr(shape, "setOutline") and outline:
                shape.setOutline(outline)
            if hasattr(shape, "setWidth") and width is not None:
                shape.setWidth(width)
            # Fallback Tk config if raw item id
            if not hasattr(shape, "setFill"):
                config = {}
                if fill: config["fill"] = fill
                if outline: config["outline"] = outline
                if width is not None: config["width"] = width
                if config:
                    self.canvas.itemconfig(shape, **config)
            return True
        except Exception:
            return False

    def label(self, obj_id, text, color="gray", font=("Courier", 10)):
        shape = self.objects.get(obj_id)
        if not shape:
            return False
        try:
            # Get a bounding box center to place label; fallback near origin
            try:
                bbox = self.canvas.bbox(shape)
                if bbox:
                    x = (bbox[0] + bbox[2]) // 2
                    y = bbox[1] - 12
                else:
                    x, y = 20, 20
            except Exception:
                x, y = 20, 20
            label_item = drawText(self.canvas, x, y, f"#{obj_id}: {text}", font=font, color=color)
            self.labels[obj_id] = label_item
            return True
        except Exception:
            return False

    def group(self, ids, name):
        items = []
        for i in ids:
            s = self.objects.get(i)
            if not s:
                return False
            items.append(s)
        # Create a group per docs: app.createGroup(canvas, shape) — extend to multiple by chaining
        # We'll make a simple composite group that holds items and offers move(x,y)
        grp = WayneGroup(self.app, items)
        self.groups[name] = grp
        return True

    def move_group(self, name, dx, dy):
        grp = self.groups.get(name)
        if not grp:
            return False
        grp.move(dx, dy)
        return True


class WayneGroup:
    """Composite group using Wayne Graphics semantics."""
    def __init__(self, app, items):
        self.app = app
        self.canvas = app.canvas
        self.items = items

    def move(self, dx, dy):
        for item in self.items:
            if hasattr(item, "move"):
                item.move(dx, dy)
            else:
                self.canvas.move(item, dx, dy)


# ---------- AI ----------
class AI:
    def __init__(self, app):
        self.app = app
        self.resp = Response()
        self.scene = SceneController(app)
        self._wire_events()

        # Optional: Show a quick hint in console
        print("Type commands and press Enter: e.g., 'draw circle at 300,200 radius 40 color red'")

    def _wire_events(self):
        # Capture last click for 'at click'
        def _on_click(x, y):
            self.scene.last_click = (x, y)
            print(self.resp.ok(f"Clicked at ({x},{y})")["message"])
        onMousePress(self.app.canvas, _on_click)

        # Use keypress to build a simple input buffer (console-based for simplicity)
        self._buffer = []

        def _on_key(char):
            if char == "\r" or char == "\n":
                cmd = "".join(self._buffer).strip()
                self._buffer.clear()
                if cmd:
                    self.ai_query(cmd)
            elif char == "\b":
                if self._buffer:
                    self._buffer.pop()
            else:
                self._buffer.append(char)
            # Optional live echo
            # print(">" + "".join(self._buffer))
        onKeyPress(self.app.root, _on_key)

    def ai_query(self, raw_text: str):
        intent = self._parse(raw_text)
        if intent is None:
            print(self.resp.error("Couldn't parse command")["message"])
            return
        result = self._dispatch(intent)
        print(result["message"])

    def _parse(self, t: str):
        """
        Supported:
          - draw circle at X,Y radius R color NAME
          - draw circle at click radius R color NAME
          - draw rect at X,Y width W height H color NAME
          - draw text at X,Y 'Your text' color NAME
          - move id ID by DX,DY
          - delete id ID
          - style id ID fill NAME outline NAME width W
          - group id ID1,ID2,... as NAME
          - move group NAME by DX,DY
          - label id ID 'text'
        """
        import re
        s = t.strip()

        # circle
        if s.lower().startswith("draw circle"):
            if "at click" in s.lower():
                r = _num(s, "radius", default=20)
                c = _word(s, "color", default="blue")
                return {"action": "draw_circle_click", "radius": r, "color": c}
            x, y = _coords(s, "at")
            r = _num(s, "radius")
            c = _word(s, "color", default="blue")
            return {"action": "draw_circle", "x": x, "y": y, "radius": r, "color": c}

        # rect
        if s.lower().startswith("draw rect"):
            x, y = _coords(s, "at")
            w = _num(s, "width")
            h = _num(s, "height")
            c = _word(s, "color", default="blue")
            return {"action": "draw_rect", "x": x, "y": y, "width": w, "height": h, "color": c}

        # text
        if s.lower().startswith("draw text"):
            x, y = _coords(s, "at")
            txt = _quoted(s) or _word(s, "text")
            c = _word(s, "color", default="black")
            return {"action": "draw_text", "x": x, "y": y, "text": txt, "color": c}

        # move object
        if s.lower().startswith("move id"):
            obj_id = _num(s, "id")
            dx, dy = _coords(s, "by")
            return {"action": "move", "id": obj_id, "dx": dx, "dy": dy}

        # delete
        if s.lower().startswith("delete id"):
            obj_id = _num(s, "id")
            return {"action": "delete", "id": obj_id}

        # style
        if s.lower().startswith("style id"):
            obj_id = _num(s, "id")
            fill = _word(s, "fill", default=None)
            outline = _word(s, "outline", default=None)
            width = _num(s, "width", default=None)
            return {"action": "style", "id": obj_id, "fill": fill, "outline": outline, "width": width}

        # group
        if s.lower().startswith("group id"):
            ids = _id_list(s)
            name = _word(s, "as")
            return {"action": "group", "ids": ids, "name": name}

        # move group
        if s.lower().startswith("move group"):
            name = _word(s, "group")
            dx, dy = _coords(s, "by")
            return {"action": "move_group", "name": name, "dx": dx, "dy": dy}

        # label
        if s.lower().startswith("label id"):
            obj_id = _num(s, "id")
            txt = _quoted(s) or _word(s, "label")
            return {"action": "label", "id": obj_id, "text": txt}

        return None

    def _dispatch(self, i):
        a = i["action"]

        if a == "draw_circle":
            shape_id = self.scene.draw_circle(i["x"], i["y"], i["radius"], i["color"])
            return self.resp.ok(f"Circle #{shape_id} at ({i['x']},{i['y']}) r={i['radius']} color {i['color']}")

        if a == "draw_circle_click":
            if not self.scene.last_click:
                return self.resp.error("No click recorded. Click in the canvas first.")
            x, y = self.scene.last_click
            shape_id = self.scene.draw_circle(x, y, i["radius"], i["color"])
            return self.resp.ok(f"Circle #{shape_id} at click ({x},{y}) r={i['radius']} color {i['color']}")

        if a == "draw_rect":
            shape_id = self.scene.draw_rect(i["x"], i["y"], i["width"], i["height"], i["color"])
            return self.resp.ok(f"Rect #{shape_id} at ({i['x']},{i['y']}) {i['width']}x{i['height']} color {i['color']}")

        if a == "draw_text":
            shape_id = self.scene.draw_text(i["x"], i["y"], i["text"], color=i["color"])
            return self.resp.ok(f"Text #{shape_id} at ({i['x']},{i['y']}) '{i['text']}' color {i['color']}")

        if a == "move":
            ok = self.scene.move(i["id"], i["dx"], i["dy"])
            return self.resp.ok(f"Moved #{i['id']} by ({i['dx']},{i['dy']})") if ok else self.resp.error(f"Object #{i['id']} not found")

        if a == "delete":
            ok = self.scene.delete(i["id"])
            return self.resp.ok(f"Deleted #{i['id']}") if ok else self.resp.error(f"Object #{i['id']} not found")

        if a == "style":
            ok = self.scene.style(i["id"], fill=i["fill"], outline=i["outline"], width=i["width"])
            return self.resp.ok(f"Styled #{i['id']} fill={i['fill']} outline={i['outline']} width={i['width']}") if ok else self.resp.error(f"Object #{i['id']} not found")

        if a == "group":
            ok = self.scene.group(i["ids"], i["name"])
            return self.resp.ok(f"Grouped {i['ids']} as '{i['name']}'") if ok else self.resp.error("One or more IDs not found")

        if a == "move_group":
            ok = self.scene.move_group(i["name"], i["dx"], i["dy"])
            return self.resp.ok(f"Moved group '{i['name']}' by ({i['dx']},{i['dy']})") if ok else self.resp.error(f"Group '{i['name']}' not found")

        if a == "label":
            ok = self.scene.label(i["id"], i["text"])
            return self.resp.ok(f"Labeled #{i['id']} '{i['text']}'") if ok else self.resp.error(f"Object #{i['id']} not found")

        return self.resp.error("Unknown action")


# ---------- Parsing helpers ----------
def _coords(text, keyword):
    import re
    m = re.search(rf"{keyword}\s+(-?\d+)\s*,\s*(-?\d+)", text, re.IGNORECASE)
    if not m:
        raise ValueError("coords not found")
    return int(m.group(1)), int(m.group(2))

def _num(text, keyword, default=None):
    import re
    m = re.search(rf"{keyword}\s+(-?\d+)", text, re.IGNORECASE)
    if not m:
        return default
    return int(m.group(1))

def _word(text, keyword, default=None):
    import re
    m = re.search(rf"{keyword}\s+([#a-zA-Z_][a-zA-Z0-9_#-]*)", text, re.IGNORECASE)
    return m.group(1) if m else default

def _id_list(text):
    import re
    m = re.search(r"id\s+([0-9,\s]+)\s+as", text, re.IGNORECASE)
    if not m:
        raise ValueError("id list not found")
    return [int(x.strip()) for x in m.group(1).split(",") if x.strip()]

def _quoted(text):
    import re
    m = re.search(r"'([^']+)'|\"([^\"]+)\"", text)
    return m.group(1) or m.group(2) if m else None


# ---------- Bootstrap ----------
def main():
    app = WayneGraphics(width=600, height=400, title="Wayne AI Demo")
    AI(app)
    app.run()

if __name__ == "__main__":
    main()