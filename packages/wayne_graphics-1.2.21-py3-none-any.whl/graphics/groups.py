class Group:
    def __init__(self, canvas, *items):
        """
        Create a group with one or more canvas items.
        :param canvas: The tkinter Canvas object
        :param items: Canvas item IDs (returned from drawRect, drawCircle, etc.)
        """
        self.canvas = canvas
        self.items = list(items)

    def add(self, *items):
        """Add new canvas items to the group."""
        self.items.extend(items)

    def move(self, dx, dy):
        """Move all items in the group by dx, dy."""
        for item in self.items:
            self.canvas.move(item, dx, dy)

    def delete(self):
        """Delete all items in the group from the canvas."""
        for item in self.items:
            self.canvas.delete(item)
        self.items.clear()

    def setFill(self, color):
        """Set fill color for all items (where applicable)."""
        for item in self.items:
            self.canvas.itemconfig(item, fill=color)

    def setOutline(self, color):
        """Set outline color for all items (where applicable)."""
        for item in self.items:
            self.canvas.itemconfig(item, outline=color)

    def setWidth(self, width):
        """Set line width for all items (where applicable)."""
        for item in self.items:
            self.canvas.itemconfig(item, width=width)

    def getItems(self):
        """Return the list of canvas item IDs in this group."""
        return self.items