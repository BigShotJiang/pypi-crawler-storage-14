from setuptools import setup, find_packages
from pathlib import Path

# Read the long description from README + CHANGELOG
this_dir = Path(__file__).parent
readme = (this_dir / "README.md").read_text(encoding="utf-8")
changelog = (this_dir / "CHANGELOG.md").read_text(encoding="utf-8")
long_description = readme + "\n\n" + changelog

classifiers = [
    "Development Status :: 3 - Alpha",          # change to Beta/Stable later
    "Intended Audience :: Education",
    "Intended Audience :: Science/Research",
    "Topic :: Scientific/Engineering :: Mathematics",
    "License :: OSI Approved :: MIT License",
    "Operating System :: OS Independent",
    "Programming Language :: Python :: 3",
    "Programming Language :: Python :: 3 :: Only",
]

setup(
    name="coordgeo",                    
    version="1.0.0",                    
    description="A 2D coordinate geometry library (points, lines, conics, triangles).",
    long_description=long_description,
    long_description_content_type="text/markdown", 
    url="https://github.com/karimkhan171271-cpu/coordgeo",  
    author="Kareem Khan",                
    author_email="karimkhan171271@gmail.com",
    license="MIT",
    classifiers=classifiers,
    keywords="coordinate geometry, math, conics, lines, circles, triangles",
    packages=find_packages(),            
    python_requires=">=3.8",
    install_requires=[
        "matplotlib>=3.0",              
    ],
    include_package_data=True,
)
