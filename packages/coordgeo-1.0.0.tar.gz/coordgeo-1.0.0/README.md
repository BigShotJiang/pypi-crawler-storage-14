coordgeo

A Python library for Coordinate Geometry — simple, intuitive, powerful.

This library provides mathematical classes (Point, Line, Circle, Ellipse, etc.) and tools for calculations and visualization in 2D geometry. It is built using OOP principles and designed to be easy to use even for beginners.

Installation
your_project/
│
├── main.py
└── coordgeo/
    ├── __init__.py
    ├── point.py
    ├── line.py
    ├── circle.py
    ├── parabola.py
    ├── ellipse.py
    ├── hyperbola.py
    ├── triangle.py
    └── plotting.py


Then in your Python file:

from coordgeo import *


or

import coordgeo

Quick Start Examples
1. Working with Points
from coordgeo import Point

p1 = Point(3, 4)
p2 = Point(8, 7)

print(p1.distance_to(p2))
print(p1.midpoint(p2))
print(p1.rotate(90))

2. Working with Lines
from coordgeo import Point, Line

L = Line.from_points(Point(0, 0), Point(4, 4))
print(L.slope)
print(L.contains(Point(2, 2)))

3. Circles
from coordgeo import Circle, Point

c = Circle(center=Point(0, 0), radius=5)
print(c.contains(Point(3, 4)))      # True
print(c.equation())


Creating a circle from a diameter:

c2 = Circle.from_diameter(Point(-3, 0), Point(3, 0))

4. Triangle properties
from coordgeo import Triangle, Point

T = Triangle(Point(0,0), Point(4,0), Point(0,3))
print("Area:", T.area)
print("Centroid:", T.centroid)
print("Incenter:", T.incenter)
print("Circumcenter:", T.circumcenter)
print("Orthocenter:", T.orthocenter)

5. Conics (Parabola, Ellipse, Hyperbola)
Parabola
from coordgeo import Parabola

P = Parabola(a=2, orientation="right")
print("Focus:", P.focus)
print("Directrix:", P.directrix)
print(P.equation())

Ellipse
from coordgeo import Ellipse

E = Ellipse(a=5, b=3)
print("Eccentricity:", E.eccentricity)
print("Foci:", E.focus_points)

Hyperbola
from coordgeo import Hyperbola

H = Hyperbola(a=5, b=3)
print("Eccentricity:", H.eccentricity)
print("Foci:", H.focus_points)
print("Asymptotes:", H.asymptote_slopes)

Visualization (Plotting)

The library supports matplotlib visualization.

Example:

from coordgeo import Circle, Point
from coordgeo.plotting import create_axes, plot_circle, show

fig, ax = create_axes()

C = Circle(center=Point(0,0), radius=4)
plot_circle(ax, C)

show()

Plot Triangle
from coordgeo import Triangle, Point
from coordgeo.plotting import create_axes, plot_triangle, show

fig, ax = create_axes()

T = Triangle(Point(0,0), Point(4,0), Point(0,3))
plot_triangle(ax, T)

show()

Importing Strategy
Recommended:
from coordgeo import Point, Line, Circle


Avoid:

from coordgeo import *


(because it imports too many names into global scope)

Error Handling & Tips

 If circles fail to construct from 3 points:
Make sure the points are not collinear.

 If plotting shows nothing:
Ensure you call show() at the end.

 If your line equation results in division error:
Your line might be vertical — slope is undefined (None).

 If conic is rotated or shifted:
Currently only standard conics at origin are supported — rotation/translation support is coming later.

Why use this library?

 Simple intuitive API
 Strong mathematical foundation
 Clear class structure
 Easy visualization support
 Excellent for learning coordinate geometry
 No unnecessary dependencies

License

MIT License — free to use and modify.
Author

Developed by Kareem Khan
For education, engineering, mathematics, and fun .