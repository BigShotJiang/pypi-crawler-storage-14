"""Task scheduling based on database objects."""

from __future__ import annotations

import logging
import os
import time
from abc import ABC, abstractmethod
from datetime import datetime, timedelta
from enum import Enum
from typing import Any, ClassVar
from zoneinfo import ZoneInfo

import arq
import pydantic
import redis
import redis.exceptions
from arq import run_worker
from arq.connections import RedisSettings

import objectdb
import objectdb.database

logger = logging.getLogger(__name__)


REDIS_HOST = os.environ["REDIS_HOST"]
REDIS_PORT = int(os.environ["REDIS_PORT"])
REDIS_CONNECT_RETRY_DELAY = 1


class Frequency(str, Enum):
    """Temporal frequency."""

    ONCE = "once"
    WEEKLY = "weekly"
    DAILY = "daily"

    def __str__(self) -> str:
        """Return literal value."""
        return self._value_  # pylint: disable=E1101


class Task(objectdb.database.DatabaseItem, ABC):
    """Database task item with information about its next execution."""

    frequency: Frequency
    next_run: datetime
    created_at: datetime = datetime.now(tz=ZoneInfo("UTC"))

    @pydantic.field_validator("next_run", "created_at")
    @classmethod
    def localize_datetime(cls, value: datetime) -> datetime:
        """Ensure timezone is attached after database operations."""
        if value.tzinfo is None:
            return value.replace(tzinfo=ZoneInfo("UTC"))
        return value

    @abstractmethod
    async def process(self, db: objectdb.database.Database) -> None:
        """Process task."""


async def process_task(ctx: Any, task: Task, db: objectdb.database.Database) -> None:  # noqa: ARG001 #pylint: disable=W0613
    """Process task item."""
    await task.process(db)
    match task.frequency:
        case Frequency.ONCE:
            await db.delete(Task, task.identifier)
            return
        case Frequency.DAILY:
            task.next_run = task.next_run + timedelta(days=1)
        case Frequency.WEEKLY:
            task.next_run = task.next_run + timedelta(weeks=1)
        case _:
            logger.warning("Unknown frequency for task %s, deleting", task)
            await db.delete(Task, task.identifier)
            return

    await db.upsert(task)
    logger.info("Executed task %s and updated next_run to %s", task, task.next_run)


async def check_scheduled_tasks(ctx: dict[str, Any], db: objectdb.database.Database) -> None:
    """Check scheduled tasks and enqueue them if they are up for."""
    now = datetime.now(tz=ZoneInfo("UTC"))
    for task in await db.find(Task, inherited="true"):
        if task.next_run > now:
            continue
        await ctx["redis"].enqueue_job("process_task", task)


class WorkerSettings:
    """arq configuration."""

    functions: ClassVar = [process_task]
    cron_jobs: ClassVar = [arq.cron(check_scheduled_tasks, second=59, unique=True)]
    redis_settings = RedisSettings(host=REDIS_HOST, port=REDIS_PORT)


def wait_for_redis_ready() -> None:
    """Ensure redis is ready to accept connections."""
    while True:
        try:
            logger.info("Connecting to redis")
            redis_connection = redis.Redis(host=REDIS_HOST, port=REDIS_PORT)
            logger.info("Pinging redis")
            redis_connection.ping()  # type: ignore
        except redis.exceptions.RedisError as exc:  # noqa: PERF203
            logger.warning("Redis could not be pinged: %s", exc)
            time.sleep(REDIS_CONNECT_RETRY_DELAY)
        else:
            logger.info("Redis is ready")
            return


if __name__ == "__main__":
    wait_for_redis_ready()
    run_worker(WorkerSettings)  # type: ignore
