from textual.app import App


class MyApp(App):
    pass
