export const SUCCESS_RESPONSE_STATUS = [200, 201];

export const SMUS_STARTUP_NOTIFICATIONS_ENDPOINT = '/api/poststartup';

export const SAGEMAKER_AUTH_DETAILS_ENDPOINT = '/aws/sagemaker/api/auth-details';




