
export const LINK_TYPE_SPARK_UI: string = "spark_ui";
export const LINK_TYPE_DRIVER_LOG: string = "driver_log";
export const CONNECTION_TYPE_EMR_EC2 = 'SPARK_EMR_EC2';
export const CONNECTION_TYPE_EMR_SERVERLESS = 'SPARK_EMR_SERVERLESS';
export const CONNECTION_TYPE_GLUE = 'SPARK_GLUE';
export const CONNECTION_TYPE_SPARK = 'SPARK';
export const CONNECTION_TYPE_EMR_EKS = 'SPARK_EMR_EKS';