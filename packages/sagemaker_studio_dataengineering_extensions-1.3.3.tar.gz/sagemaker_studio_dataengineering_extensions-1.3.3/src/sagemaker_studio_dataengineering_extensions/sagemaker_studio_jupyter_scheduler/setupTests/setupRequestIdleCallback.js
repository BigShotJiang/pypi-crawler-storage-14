// eslint-disable-next-line @typescript-eslint/no-empty-function
window.requestIdleCallback = function () {};
