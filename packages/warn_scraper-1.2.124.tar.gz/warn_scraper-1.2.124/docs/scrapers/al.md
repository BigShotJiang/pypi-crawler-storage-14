---
orphan: true
---

# Alabama

- [Homepage](https://www.madeinalabama.com/)
- Sample data links
  - https://www.madeinalabama.com/warn-list/
- Contact for data inquiries:
  -Toll Free: 800.248.0033
  -Media Inquiries: 334.242.0400
  -Email: contact@madeinalabama.com
- WARN Data Contact found by Cody: Jessica D. (phone # unknown)

### July 21, 2021 12PM
I had an intuition that I needed to call earlier in order to get a response, so I did! I called back and I was transferred to Jessica D. (sounded like Jessica Dent or Dint?). Unfortunately I had to leave a voicemail again, but at least I got somewhere.

### July 20, 2021
Second email follow-up (losing hope in that email address); Media Inquiries # rang a couple times and then I left another voicemail.  This is Alabama's 4:30Pm, so maybe it's worth calling them earlier in the morning and seeing if anyone picks up.

### July 13, 2021
Email follow-up

### July 1, 2021
Called the Media Inquiries number, left a voicemail with my callback number. Called the Toll Free number, left a voicemail with my callback number. Sent an email to the contact address with my questions.

### Jun 30th, 2021

The following are some specific issues with this data that needs further processing and phone calls:
- Q: I noticed in the last 8 lines of the data there are alternating rows of future dates and jan 1 1970, with some strange characters in the other fields. Do these lines mean anything, or can we discard them?
- ![image](https://user-images.githubusercontent.com/20691507/124038481-0c62aa00-d9b6-11eb-9498-fdc623798797.png)
