---
orphan: true
---

# Indiana

## Media Contact:
Scott Olson
317-234-8576
solson@dwd.in.gov

## General Contact
Indiana Department of Workforce Development
Workforce Transition Unit, SE308
10 North Senate Avenue
Indianapolis, IN 46204
warn-notice@dwd.in.gov

### July 21, 2021
Response:

>Cody:
>This error should be fixed soon.
>And we plan later this year to revamp the entire WARN notice site.
>Thanks for bringing this to our attention,
>
>Scott
>
Emailed Scott Olson, re: WARN #208. Asked if he could remove the erroneous table-within-a-table. I'm keeping the issue ticket up because until we get a response it isn't a bad idea to build robustness into the scraper.
![image](https://user-images.githubusercontent.com/20691507/126534841-676a823d-0255-4282-8dad-34d59f6a2bdc.png)
