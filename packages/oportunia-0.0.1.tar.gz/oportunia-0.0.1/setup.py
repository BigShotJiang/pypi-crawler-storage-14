from setuptools import setup, find_packages

setup(
    name="oportunia",
    version="0.0.1",
    author="Oportunia Team",
    author_email="contacto@oportunia.com",
    description="Official Oportunia namespace. For the SDK, please install 'licitpy'.",
    long_description="This package is a placeholder to reserve the Oportunia namespace.\n\n **To use our API, please install the official SDK:**\n\n`pip install licitpy`",
    long_description_content_type="text/markdown",
    url="https://oportunia.com",
    packages=find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires='>=3.6',
)
