# meshub-cli

Official CLI for Meshub - A powerful command-line interface for managing your Meshub projects.

## Installation

```bash
pip install meshub-cli
```

## License

MIT License - see LICENSE file for details.
