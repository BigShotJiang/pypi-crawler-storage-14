# Copyright (c) 2025, Meshub
# Licensed under the MIT License

"""Constants for Meshub CLI."""

__version__ = "0.0.1"
