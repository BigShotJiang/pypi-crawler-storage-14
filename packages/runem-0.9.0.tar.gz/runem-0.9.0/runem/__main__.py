"""Entry point for runem."""

from runem.cli import main  # pragma: no cover

if __name__ == "__main__":  # pragma: no cover
    main()
