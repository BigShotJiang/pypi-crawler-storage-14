"""The version of the software. Use `hatch` to upgrade this version number.

Please do not manually edit this value.
"""

# DO NOT EDIT MANUALLY.
__version__ = "0.2.0"
