
def library():
    print("This is a VGS library.")