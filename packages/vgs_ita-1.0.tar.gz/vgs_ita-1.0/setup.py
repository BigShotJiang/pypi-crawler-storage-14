import setuptools
from pathlib import Path

setuptools.setup(
    author= 'ITA',
    name = 'vgs_ita',
    version=1.0,
    long_description=Path("README.md").read_text(),
    packages=setuptools.find_packages(exclude=['tests','data'])
)
