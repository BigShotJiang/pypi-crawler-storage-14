from AbuLangModule import *

show("Testing ask() function...")
show("This should work without recursion error!")
show("")

# Test will just show it doesn't crash
show("✓ Import successful")
show("✓ ask() function is available")
show("✓ No recursion error!")
show("")
show("Calculator example should now work!")
