"""Test AbuLangModule"""

# Try different import methods
print("Testing AbuLangModule imports...")

try:
    from AbuLangModule.AbuLangModule import *
    print("✓ Import successful!")
    print("Testing show command...")
    show("Hello from AbuLang!")
    print("✓ show() works!")
    
    print("Testing math commands...")
    result = plus(10, 5)
    show(f"10 + 5 = {result}")
    print("✓ plus() works!")
    
    print("\n=== All tests passed! ===")
    
except ImportError as e:
    print(f"✗ Import failed: {e}")
except Exception as e:
    print(f"✗ Error: {e}")
