# 🚀 AbuLang - Natural Language Programming

A natural-language programming language that makes coding intuitive and accessible.

## ✨ NEW: AbuLang v2.0 with Module 4.0.0

**The most natural programming experience ever!**

### 🚀 Module 4.0.0 - Parentheses-Free Syntax
```abu
# No parentheses needed!
show "Hello, World!"
show math.sqrt 16
show ascii "A"
```

### 🎯 Smart Features
```abu
# Smart string interpolation
age = 25
show "Age: {age}, Next year: {age + 1}"

# Smart number types
x = 7.0  # → int automatically

# Built-in functions
show ascii "A"      # 65
show binary 10      # 0b1010

# Internal libraries (no libra needed!)
show math.sqrt 16
show stat.mean [1, 2, 3]

# Null objects with properties (JavaScript-like!)
person = null
person.name = "Abu"
person.age = 25
show "Name: {person.name}"
```

👉 **Module 4.0.0**: [MODULE_4.0.0_RELEASE.md](MODULE_4.0.0_RELEASE.md) | [Examples](examples/module-4-demo.abu)  
👉 **Smart Features**: [SMART_FEATURES_QUICK_REF.md](SMART_FEATURES_QUICK_REF.md) | [Full Documentation](docs/SMART_FEATURES.md)

## 📁 Project Structure

```
AbuLang CodingLang/
│
├── 📱 Core Application
│   ├── AbuLang.py          # Main application
│   ├── abulang_idle.py     # IDLE interface
│   ├── cli.py              # Command-line interface
│   ├── setup.py            # Package setup
│   └── AbuLang.bat         # Quick launcher
│
├── 🔧 Module/              # Core interpreter modules
│   ├── abu_core.py         # Core interpreter
│   ├── runner.py           # Code runner
│   ├── idle.py             # IDLE backend
│   └── idle_gui.py         # IDLE GUI
│
├── 🌐 web/                 # Web IDE
│   ├── abulang-ide-standalone.html  # Single-file IDE
│   └── playground/         # Multi-file IDE
│
├── 📦 dist/                # Distribution files
│   └── AbuLang.exe         # Windows executable
│
├── 🛠️ essentials/          # Essential resources
│   ├── commands.yaml       # Command definitions
│   └── python/             # Python dependencies
│
├── 🔨 build-scripts/       # Build & deployment
│   ├── build_exe.bat       # Windows build
│   ├── build_macos.sh      # macOS build
│   ├── build_android.sh    # Android build
│   ├── buildozer.spec      # Mobile config
│   └── cleanup.bat         # Cleanup script
│
├── 📖 docs/                # Documentation
│   ├── README.md           # This file
│   ├── GETTING_STARTED.txt # Quick start
│   ├── LANGUAGE_COMMANDS.md # Language reference
│   └── BUILD_OPTIONS.md    # Build guide
│
├── 📝 examples/            # Example code
│   └── example.abu         # Sample programs
│
└── 🧪 tests/               # Test files
    ├── test_*.py           # Python tests
    ├── test-*.html         # Web tests
    └── validate-*.js       # Validation scripts
```

## 🚀 Quick Start

### Run the Application
```bash
python AbuLang.py
```

### Run from Command Line
```bash
python cli.py example.abu
```

### Use Web IDE
Open `web/abulang-ide-standalone.html` in your browser

## 📚 Documentation

- **Getting Started:** `docs/GETTING_STARTED.txt`
- **Language Reference:** `docs/LANGUAGE_COMMANDS.md`
- **IDLE Commands:** `docs/IDLE_COMMANDS.md`
- **Build Guide:** `docs/BUILD_OPTIONS.md`

## 🔨 Building

### Windows Executable
```bash
cd build-scripts
build_exe.bat
```

### macOS Application
```bash
cd build-scripts
./build_macos.sh
```

### Android APK
```bash
cd build-scripts
./build_android.sh
```

## 🧪 Testing

```bash
cd tests
python test_abulang.py
```

## 📦 Installation

### From Source
```bash
pip install -e .
```

### From Executable
Run `dist/AbuLang.exe` (Windows)

## 🌐 Web IDE

Two versions available:

1. **Standalone** (`web/abulang-ide-standalone.html`)
   - Single HTML file
   - Works offline
   - Easy to share

2. **Playground** (`web/playground/`)
   - Multi-file version
   - Better for development
   - Deploy to web servers

## 🎯 Features

- ✅ Natural language syntax
- ✅ Easy to learn
- ✅ Cross-platform
- ✅ Web-based IDE
- ✅ Desktop application
- ✅ Mobile support (Android/iOS)
- ✅ Syntax highlighting
- ✅ Interactive IDLE

## 📝 Example Code

```abulang
# Hello World
show "Hello, World!"

# Variables
name = "Abu"
age = 25

# User Input
name = prompt "What's your name?"
show $"Hello {name}!"

# Conditionals
check age >= 18:
    show "You're an adult"
else:
    show "You're a minor"

# Loops
loopf i in range(5):
    show i

# Functions
def greet(name):
    show $"Hello {name}!"
    return name
```

## 🤝 Contributing

1. Fork the repository
2. Create your feature branch
3. Commit your changes
4. Push to the branch
5. Create a Pull Request

## 📄 License

See LICENSE file for details

## 🔗 Links

- **GitHub:** https://github.com/AbuCodingAI/AbuLangIDLE
- **Documentation:** See `docs/` folder
- **Web IDE:** `web/abulang-ide-standalone.html`

---

Made with ❤️ by Abu
