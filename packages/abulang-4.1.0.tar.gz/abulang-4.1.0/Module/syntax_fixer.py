"""
AbuLang Syntax Fixer - Fixes common syntax issues
"""

import re


class SyntaxFixer:
    """Fixes AbuLang syntax before execution"""
    
    @staticmethod
    def fix_show_command(line: str) -> str:
        """Fix show command syntax"""
        if line.startswith("show "):
            # Extract what comes after "show "
            content = line[5:].strip()
            
            # If it's a string literal (starts with quote), wrap it properly
            if (content.startswith('"') and content.endswith('"')) or \
               (content.startswith("'") and content.endswith("'")):
                # Already quoted, just convert to print
                return f"print({content})"
            
            # If it's not quoted, quote it
            if not content.startswith("("):
                return f'print("{content}")'
            
            # If it's a function call, keep as is
            return f"print({content})"
        
        return line
    
    @staticmethod
    def fix_ask_command(line: str) -> str:
        """Fix ask command syntax"""
        if line.startswith("ask "):
            content = line[4:].strip()
            
            if (content.startswith('"') and content.endswith('"')) or \
               (content.startswith("'") and content.endswith("'")):
                return f"input({content})"
            
            if not content.startswith("("):
                return f'input("{content}")'
            
            return f"input({content})"
        
        return line
    
    @staticmethod
    def fix_syntax(line: str) -> str:
        """Fix all syntax issues"""
        line = SyntaxFixer.fix_show_command(line)
        line = SyntaxFixer.fix_ask_command(line)
        return line


def fix_abulang_syntax(code: str) -> str:
    """Fix AbuLang syntax in code"""
    lines = code.split('\n')
    fixed_lines = []
    
    for line in lines:
        fixed_line = SyntaxFixer.fix_syntax(line)
        fixed_lines.append(fixed_line)
    
    return '\n'.join(fixed_lines)
