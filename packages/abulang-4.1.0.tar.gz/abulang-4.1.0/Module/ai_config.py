"""
Configuration for AI-assisted parsing in AbuLang

To use cloud AI services, set your API keys here or via environment variables
"""

import os


class AIConfig:
    """Configuration for AI parsing backends"""
    
    # Default backend: "pattern" (no API needed), "openai", "ollama", "anthropic"
    DEFAULT_BACKEND = "pattern"
    
    # API Keys (can also be set via environment variables)
    OPENAI_API_KEY = os.getenv("OPENAI_API_KEY", None)
    ANTHROPIC_API_KEY = os.getenv("ANTHROPIC_API_KEY", None)
    
    # Model configurations
    MODELS = {
        "openai": {
            "default": "gpt-3.5-turbo",
            "fast": "gpt-3.5-turbo",
            "powerful": "gpt-4",
        },
        "ollama": {
            "default": "llama2",
            "fast": "llama2",
            "powerful": "codellama",
        },
        "anthropic": {
            "default": "claude-3-haiku-20240307",
            "fast": "claude-3-haiku-20240307",
            "powerful": "claude-3-sonnet-20240229",
        }
    }
    
    # Fuzzy matching settings
    FUZZY_THRESHOLD = 0.6  # Minimum similarity for suggestions
    AUTO_CORRECT_THRESHOLD = 0.8  # Minimum similarity for auto-correction
    MAX_SUGGESTIONS = 3  # Number of suggestions to show
    
    @classmethod
    def get_api_key(cls, backend):
        """Get API key for specified backend"""
        if backend == "openai":
            return cls.OPENAI_API_KEY
        elif backend == "anthropic":
            return cls.ANTHROPIC_API_KEY
        return None
    
    @classmethod
    def get_model(cls, backend, tier="default"):
        """Get model name for backend and tier"""
        if backend in cls.MODELS:
            return cls.MODELS[backend].get(tier, cls.MODELS[backend]["default"])
        return None


# Quick setup functions
def setup_openai(api_key):
    """Quick setup for OpenAI"""
    AIConfig.OPENAI_API_KEY = api_key
    AIConfig.DEFAULT_BACKEND = "openai"


def setup_ollama(model="llama2"):
    """Quick setup for Ollama (local)"""
    AIConfig.DEFAULT_BACKEND = "ollama"
    AIConfig.MODELS["ollama"]["default"] = model


def setup_anthropic(api_key):
    """Quick setup for Anthropic Claude"""
    AIConfig.ANTHROPIC_API_KEY = api_key
    AIConfig.DEFAULT_BACKEND = "anthropic"
