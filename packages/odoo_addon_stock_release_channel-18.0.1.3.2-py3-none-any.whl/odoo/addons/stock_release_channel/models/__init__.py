from . import stock_move
from . import stock_picking
from . import stock_release_channel
from . import res_company
from . import res_config_settings
from . import res_partner
