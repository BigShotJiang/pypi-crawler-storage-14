injected_args = {
    "injected_string_parameter": "INJECTED",
}

def injected_args_getter():
    return injected_args
