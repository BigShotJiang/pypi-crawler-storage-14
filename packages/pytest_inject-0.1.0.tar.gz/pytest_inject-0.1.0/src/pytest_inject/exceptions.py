class PytestInjectError(Exception):
    pass
