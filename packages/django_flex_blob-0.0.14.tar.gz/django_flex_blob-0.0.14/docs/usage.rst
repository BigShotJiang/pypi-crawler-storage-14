=====
Usage
=====

To use Django Flex Blob in a project::

    import django_flex_blob
