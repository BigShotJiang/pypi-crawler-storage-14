"""Top-level package for Python Boilerplate."""

__author__ = "Ali Avani"
__email__ = "ali.avani.1410@gmail.com"
__version__ = "0.0.14"
