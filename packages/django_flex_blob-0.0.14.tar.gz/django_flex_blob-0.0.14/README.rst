================
Django Flex Blob
================


.. image:: https://img.shields.io/pypi/v/django-flex-blob.svg
        :target: https://pypi.python.org/pypi/django-flex-blob


A django app dedicated for managing media files and access to them


* Free software: MIT license
* Documentation: https://django-flex-blob.readthedocs.io.


Features
--------

* TODO

Credits
-------

This package was created with Cookiecutter_ and the `audreyr/cookiecutter-pypackage`_ project template.

.. _Cookiecutter: https://github.com/audreyr/cookiecutter
.. _`audreyr/cookiecutter-pypackage`: https://github.com/audreyr/cookiecutter-pypackage
