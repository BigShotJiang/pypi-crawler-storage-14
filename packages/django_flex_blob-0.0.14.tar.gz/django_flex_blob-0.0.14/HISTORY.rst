=======
History
=======

0.0.1 (2024-12-03)
------------------

* First release on PyPI.
