"""SocialMapper test suite."""
