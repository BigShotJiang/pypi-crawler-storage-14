from .constants import *
from .time_utils import swe_julday, swe_revjul, swe_deltat
from .planets import (
    swe_calc_ut,
    swe_calc,
    swe_get_ayanamsa_ut,
    swe_get_ayanamsa,
    swe_set_sid_mode,
)
from .houses import swe_houses, swe_houses_ex
from .state import set_topo as swe_set_topo
from .crossing import swe_solcross_ut, swe_mooncross_ut, swe_cross_ut
from .utils import difdeg2n

# API Aliases to match pyswisseph
# The original swe_set_topo and swe_set_sid_mode functions are removed
# as they are now directly imported or aliased.


# Helper function to pre-calculate positions for Arabic parts
def swe_calc_angles(jd_ut: float, lat: float, lon: float):
    """
    Pre-calculate and cache astrological angles and planet positions
    for use with Arabic parts.

    Args:
        jd_ut: Julian Day (UT)
        lat: Latitude (degrees)
        lon: Longitude (degrees)

    Returns:
        Dictionary with calculated positions
    """
    from .state import set_angles_cache
    from .angles import calc_angles

    # Set observer location
    swe_set_topo(lon, lat, 0)

    # Calculate angles
    angles_dict = calc_angles(jd_ut, lat, lon)
    
    # Calculate and add planet positions for Arabic parts
    from .constants import SE_SUN, SE_MOON, SE_MERCURY, SE_VENUS
    
    sun_pos, _ = swe_calc_ut(jd_ut, SE_SUN, 0)
    moon_pos, _ = swe_calc_ut(jd_ut, SE_MOON, 0)
    mercury_pos, _ = swe_calc_ut(jd_ut, SE_MERCURY, 0)
    venus_pos, _ = swe_calc_ut(jd_ut, SE_VENUS, 0)
    
    angles_dict['Sun'] = sun_pos[0]
    angles_dict['Moon'] = moon_pos[0]
    angles_dict['Mercury'] = mercury_pos[0]
    angles_dict['Venus'] = venus_pos[0]
    
    # Cache for Arabic parts
    set_angles_cache(angles_dict)
    
    return angles_dict

# Helper for Arabic parts
from .arabic_parts import calc_all_arabic_parts

# Constants (planet IDs, flags, sidereal modes)
from .constants import *

__version__ = "0.1.0"
__author__ = "Giacomo Battaglia"
__license__ = "LGPL-3.0"

__all__ = [
    # Time
    "swe_julday",
    "swe_revjul",
    "swe_deltat",
    # Planets
    "swe_calc_ut",
    "swe_get_planet_name",
    # Houses
    "swe_houses",
    "swe_house_pos",
    "swe_house_name",
    # Sidereal
    "swe_set_sid_mode",
    "swe_get_ayanamsa_ut",
    "swe_get_ayanamsa_name",
    # Observer
    "swe_set_topo",
    # Events
    "swe_solcross_ut",
    "swe_mooncross_ut",
    "swe_cross_ut",
    # Utilities
    "difdeg2n",
    # Helpers
    "calc_all_arabic_parts",
]
