class Role(object):
    """Languages"""

    SYSTEM_ADMIN = "System Admin"
    APP_USER = "App User"
    THIRD_PARTY = "Third Party"
    CRM_USER = "CRM User"
