"""Newline IWB Converter - A utility for converting Newline IWB files."""

__version__ = "0.1.0"
