"""MCP Server for Sentiment Analysis"""
