"""HyperNodes integrations with external libraries.

This package contains optional integrations with external libraries:
- daft: Distributed DataFrame-based execution engine
"""
