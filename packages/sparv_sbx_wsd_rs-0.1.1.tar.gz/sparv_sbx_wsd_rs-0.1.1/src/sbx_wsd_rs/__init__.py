"""Word sense disambiguation based on SALDO annotation."""

from . import wsd

__all__ = ["wsd"]
