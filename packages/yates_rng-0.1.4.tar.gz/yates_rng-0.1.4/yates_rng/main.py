from yates_rng import domino_search,rin

print(domino_search([2,3,4],5))