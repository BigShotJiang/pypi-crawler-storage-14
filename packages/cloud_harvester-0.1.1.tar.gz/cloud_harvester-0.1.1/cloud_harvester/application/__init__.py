from cloud_harvester.application.collect_resources import collect_resources

__all__ = ["collect_resources"]
