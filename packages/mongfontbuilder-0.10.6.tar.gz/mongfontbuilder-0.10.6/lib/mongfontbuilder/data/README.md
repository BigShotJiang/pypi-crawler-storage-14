# Data files

JSON files in this directory are not manually maintained. They are exported from [/data/](/data/) with [/data/export.ts](/data/export.ts).
