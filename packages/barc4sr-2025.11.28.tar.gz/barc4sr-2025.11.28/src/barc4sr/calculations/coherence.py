# SPDX-License-Identifier: CECILL-2.1
# Copyright (c) 2025 Synchrotron SOLEIL

"""
Coherence calculations.
"""

from __future__ import annotations


# ---------------------------------------------------------------------------
# coherent modes
# ---------------------------------------------------------------------------

def coherent_modes():
    raise NotImplementedError('Ohhh ohhh we are half way there! Ohhh ohhh this function is not implemented yet!')