# SPDX-FileCopyrightText: © 2023 Tenstorrent Inc.
# SPDX-License-Identifier: Apache-2.0

import tt_smi


if __name__ == "__main__":
    tt_smi.main()
