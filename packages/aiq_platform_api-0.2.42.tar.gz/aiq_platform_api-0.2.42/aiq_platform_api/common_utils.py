"""Backward compatibility module - re-exports all symbols from core/.

This module maintains backward compatibility for existing imports.
New code should import directly from aiq_platform_api.core.
"""

from aiq_platform_api.core import (
    # Logger
    AttackIQLogger,
    # Client
    AttackIQRestClient,
    # Constants - Enums
    ScenarioTemplateType,
    AssetStatus,
    UnifiedMitigationType,
    IntegrationName,
    AssessmentExecutionStrategy,
    DetectionStatus,
    DetectionOutcome,
    AnalystVerdict,
    # Constants - Mappings
    SCENARIO_TEMPLATE_IDS,
    ScenarioLanguageConfig,
    SCENARIO_LANGUAGES,
    DETECTION_TYPES,
    INTEGRATION_NAMES,
    # Utils - Tags
    TagSetUtils,
    TagUtils,
    TaggedItemUtils,
    # Utils - Results
    ResultsUtils,
    PhaseResultsUtils,
    PhaseLogsUtils,
    # Utils - Files
    FileUploadUtils,
    FileDownloadUtils,
    # Utils - Connectors
    ConnectorUtils,
    # Utils - Assets
    AssetUtils,
    # Utils - Assessments
    AssessmentUtils,
    # Utils - Scenarios
    ScenarioUtils,
    # Utils - Mitigations
    UnifiedMitigationUtils,
    UnifiedMitigationProjectUtils,
    UnifiedMitigationWithRelationsUtils,
    UnifiedMitigationReportingUtils,
)

# Module-level logger for backward compatibility
logger = AttackIQLogger.get_logger(__name__)

__all__ = [
    # Logger
    "AttackIQLogger",
    # Client
    "AttackIQRestClient",
    # Constants - Enums
    "ScenarioTemplateType",
    "AssetStatus",
    "UnifiedMitigationType",
    "IntegrationName",
    "AssessmentExecutionStrategy",
    "DetectionStatus",
    "DetectionOutcome",
    "AnalystVerdict",
    # Constants - Mappings
    "SCENARIO_TEMPLATE_IDS",
    "ScenarioLanguageConfig",
    "SCENARIO_LANGUAGES",
    "DETECTION_TYPES",
    "INTEGRATION_NAMES",
    # Utils - Tags
    "TagSetUtils",
    "TagUtils",
    "TaggedItemUtils",
    # Utils - Results
    "ResultsUtils",
    "PhaseResultsUtils",
    "PhaseLogsUtils",
    # Utils - Files
    "FileUploadUtils",
    "FileDownloadUtils",
    # Utils - Connectors
    "ConnectorUtils",
    # Utils - Assets
    "AssetUtils",
    # Utils - Assessments
    "AssessmentUtils",
    # Utils - Scenarios
    "ScenarioUtils",
    # Utils - Mitigations
    "UnifiedMitigationUtils",
    "UnifiedMitigationProjectUtils",
    "UnifiedMitigationWithRelationsUtils",
    "UnifiedMitigationReportingUtils",
]
