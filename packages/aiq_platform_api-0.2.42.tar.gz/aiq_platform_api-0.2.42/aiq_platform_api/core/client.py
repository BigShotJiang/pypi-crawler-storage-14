import logging
from http import HTTPStatus
from typing import Optional, Dict, Any, Generator
from urllib.parse import urlencode

import requests
from requests.exceptions import RequestException
from tenacity import (
    retry,
    stop_after_attempt,
    wait_exponential,
    before_sleep_log,
    retry_if_exception,
)

from aiq_platform_api.core.logger import AttackIQLogger

logger = AttackIQLogger.get_logger(__name__)


class AttackIQRestClient:
    """REST client for interacting with the AttackIQ platform.

    This class provides a clean, unified API for interacting with the AttackIQ platform.
    It handles authentication, pagination, and error handling for all platform endpoints.
    """

    def __init__(self, platform_url: str, platform_api_token: str):
        self.platform_url = platform_url.rstrip("/")
        is_jwt = "." in platform_api_token
        auth_prefix = "Bearer" if is_jwt else "Token"
        logger.debug(f"Token type detection: is_jwt={is_jwt}, using auth_prefix='{auth_prefix}'")
        logger.debug(f"Token preview: {platform_api_token[:10]}... (length: {len(platform_api_token)})")
        self.headers = {
            "Authorization": f"{auth_prefix} {platform_api_token}",
            "Content-Type": "application/json",
        }

    def get_object(self, endpoint: str, params: dict = None) -> Optional[Dict[str, Any]]:
        url = self._build_url(endpoint, params)
        logger.debug(f"Fetching object from {url}")
        return self._make_request(url, method="get", json=None)

    def get_all_objects(self, endpoint: str, params: dict = None) -> Generator[Dict[str, Any], None, None]:
        url = self._build_url(endpoint, params)
        logger.info(f"Fetching objects from {url}")
        total_count = None
        objects_yielded = 0
        while url:
            try:
                data = self._make_request(url, method="get", json=None)
                if not data:
                    logger.info("Received empty data, stopping pagination.")
                    break
                # Check if the response is the expected dict or just a list
                if isinstance(data, dict):
                    results = data.get("results", [])
                    if total_count is None:
                        total_count = data.get("count")
                    url = data.get("next")  # Get next page URL
                    if total_count is not None:
                        objects_left = total_count - objects_yielded
                        logger.info(f"Objects left: {objects_left}")
                    else:
                        logger.info("Total count not available in response.")
                elif isinstance(data, list):
                    logger.info("Received a direct list response (non-paginated).")
                    results = data
                    total_count = len(results)  # Count is just the length of the list
                    url = None  # No next page for a direct list response
                    logger.info(f"Yielding {total_count} objects from the list.")
                else:
                    logger.error(f"Unexpected data type received: {type(data)}. Stopping.")
                    break
                if not results:
                    logger.info("No results found in the current batch.")
                    # Keep url as is if it was set from dict, or None if it was a list
                    if url is None:  # Break if it was a list or dict had no next
                        break
                    else:  # Continue if it was a dict with a next url
                        continue
                for result in results:
                    yield result
                    objects_yielded += 1  # If it was a list response, url is already None, loop will terminate
            except RequestException as e:
                logger.error(f"Failed to fetch objects during pagination: {e}")
                break
            except Exception as e:
                logger.error(
                    f"An unexpected error occurred during pagination: {e}",
                    exc_info=True,
                )
                break

    def get_total_objects_count(self, endpoint: str, params: dict = None) -> Optional[int]:
        url = self._build_url(endpoint, params)
        data = self._make_request(url, method="get", json=None)
        return data.get("count") if data else None

    def post_object(self, endpoint: str, data: dict) -> Optional[Dict[str, Any]]:
        url = self._build_url(endpoint)
        logger.info(f"Posting object to {url} with data: {data}")
        return self._make_request(url, method="post", json=data)

    def patch_object(self, endpoint: str, data: dict) -> Optional[Dict[str, Any]]:
        url = self._build_url(endpoint)
        logger.info(f"Patching object at {url} with data: {data}")
        return self._make_request(url, method="patch", json=data)

    def delete_object(self, endpoint: str) -> Optional[Dict[str, Any]]:
        url = self._build_url(endpoint)
        logger.info(f"Deleting object at {url}")
        return self._make_request(url, method="delete", json=None)

    @staticmethod
    def _is_retryable_exception(exception):
        if isinstance(exception, RequestException):
            if exception.response is not None:
                return exception.response.status_code in [
                    HTTPStatus.BAD_GATEWAY,
                    HTTPStatus.SERVICE_UNAVAILABLE,
                    HTTPStatus.GATEWAY_TIMEOUT,
                ]
        return False

    @retry(
        stop=stop_after_attempt(3),
        wait=wait_exponential(multiplier=1, min=2, max=30),
        retry=retry_if_exception(_is_retryable_exception),
        reraise=True,
        before_sleep=before_sleep_log(logger, logging.DEBUG),
    )
    def upload_file(
        self,
        endpoint: str,
        file_name: str,
        file_content: bytes,
        content_type: Optional[str] = None,
        headers: Optional[Dict[str, str]] = None,
        data: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """Upload a single file (field name 'file') via multipart/form-data."""
        url = self._build_url(endpoint)
        logger.info(f"Uploading file to {url} with filename: {file_name}")
        resolved_headers = {k: v for k, v in self.headers.items() if k.lower() != "content-type"}
        if headers:
            resolved_headers.update(headers)

        files = {"file": (file_name, file_content, content_type or "application/octet-stream")}
        try:
            response = requests.request("post", url, headers=resolved_headers, files=files, data=data)
            return self._parse_response(response, url)
        except requests.RequestException as e:
            if e.response is not None:
                logger.error(
                    f"upload_file failed \n"
                    f"\turl: {url} \n"
                    f"\tstatus: {e.response.status_code} \n"
                    f"\tcontent: {e.response.text} \n"
                    f"\theaders: {resolved_headers} \n"
                    f"\texception: {e}"
                )
            else:
                logger.error(
                    f"upload_file failed \n" f"\turl: {url} \n" f"\theaders: {resolved_headers} \n" f"\texception: {e}"
                )
            raise

    def _build_url(self, endpoint: str, params: dict = None) -> str:
        if not endpoint.startswith(self.platform_url):
            endpoint = endpoint.lstrip("/")
            url = f"{self.platform_url}/{endpoint}"
        else:
            url = endpoint
        if params:
            url += f"?{urlencode(params)}"
        return url

    @retry(
        stop=stop_after_attempt(3),
        wait=wait_exponential(multiplier=1, min=2, max=30),
        retry=retry_if_exception(_is_retryable_exception),
        reraise=True,
        before_sleep=before_sleep_log(logger, logging.DEBUG),
    )
    def _make_request(self, url: str, method: str, json: Optional[Dict[str, Any]]) -> Dict[str, Any]:
        try:
            logger.debug(f"Request method: {method.upper()} for URL: {url}")
            method = method.lower()
            if method not in ["get", "post", "delete", "put", "patch"]:
                raise ValueError(f"Unsupported method: {method}")
            if method == "post" and json:
                logger.info(f"Request data: {json}")
            response = requests.request(method, url, headers=self.headers, json=json)
            return self._parse_response(response, url)
        except requests.RequestException as e:
            if e.response is not None:
                logger.error(
                    f"_make_request failed method: {method} \n"
                    f"\turl: {url} \n"
                    f"\tstatus: {e.response.status_code} \n"
                    f"\tcontent: {e.response.text} \n"
                    f"\tjson: {json} \n"
                    f"\theaders: {self.headers} \n"
                    f"\texception: {e}"
                )
            else:
                logger.error(
                    f"_make_request failed method: {method} \n"
                    f"\turl: {url} \n"
                    f"\tjson: {json} \n"
                    f"\theaders: {self.headers} \n"
                    f"\texception: {e}"
                )
            raise e

    @retry(
        stop=stop_after_attempt(3),
        wait=wait_exponential(multiplier=1, min=2, max=30),
        retry=retry_if_exception(_is_retryable_exception),
        reraise=True,
        before_sleep=before_sleep_log(logger, logging.DEBUG),
    )
    def download_bytes(self, endpoint: str) -> bytes:
        url = self._build_url(endpoint)
        logger.debug(f"Downloading bytes from {url}")
        response = requests.get(url, headers=self.headers, stream=True)
        try:
            response.raise_for_status()
        except requests.RequestException as e:
            logger.error(
                f"download_bytes failed \n"
                f"\turl: {url} \n"
                f"\tstatus: {response.status_code if response else 'n/a'} \n"
                f"\tcontent: {response.text if response and response.content else 'n/a'} \n"
                f"\texception: {e}"
            )
            raise
        return response.content

    @staticmethod
    def _parse_response(response: requests.Response, url: str) -> Dict[str, Any]:
        if response.status_code == HTTPStatus.NOT_FOUND:
            logger.error(f"Resource not found: {url}")
            return {}
        response.raise_for_status()
        if response.status_code in [
            HTTPStatus.NO_CONTENT,
            HTTPStatus.RESET_CONTENT,
        ]:
            logger.info(f"Request successful: {response.status_code} {response.reason}")
            return {"status_code": response.status_code}
        if response.content:
            return response.json()
        logger.info(f"Request successful but no content returned: {response.status_code} {response.reason}")
        return {"status_code": response.status_code}
