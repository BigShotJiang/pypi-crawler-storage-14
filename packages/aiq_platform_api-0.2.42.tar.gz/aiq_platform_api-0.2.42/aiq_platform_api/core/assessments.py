import itertools
import time
from typing import Optional, Dict, Any, Generator, List

from requests.exceptions import RequestException

from aiq_platform_api.core.client import AttackIQRestClient
from aiq_platform_api.core.constants import AssessmentExecutionStrategy
from aiq_platform_api.core.logger import AttackIQLogger

logger = AttackIQLogger.get_logger(__name__)


class AssessmentUtils:
    """Utilities for working with assessments providing a clean, unified API.

    API Endpoint: /v1/assessments, /v1/public/assessment, /v1/results
    """

    ASSESSMENT_ENDPOINT = "v1/assessments"
    PUBLIC_ENDPOINT = "v1/public/assessment"
    RESULTS_V1_ENDPOINT = "v1/results"
    RESULTS_V2_ENDPOINT = "v2/results"
    RUN_ASSESSMENT_V1_ENDPOINT = "v1/assessments/{}/run_all"
    RUN_ASSESSMENT_V2_ENDPOINT = "v2/assessments/{}/run_all"

    @staticmethod
    def get_assessments(
        client: AttackIQRestClient,
        params: Optional[Dict[str, Any]] = None,
        limit: Optional[int] = 10,
    ) -> Generator[Dict[str, Any], None, None]:
        """List all assessments, optionally filtered by params and limited to a specific count."""
        generator = client.get_all_objects(AssessmentUtils.ASSESSMENT_ENDPOINT, params=params)
        yield from itertools.islice(generator, limit)

    @staticmethod
    def _fetch_atomic_tests(client: AttackIQRestClient, assessment_id: str) -> List[Dict[str, Any]]:
        """Fetch tests with their scenarios and assets for an atomic assessment.

        Uses get_all_objects to handle pagination for tests, scenarios, and assets.
        """
        tests = list(client.get_all_objects("v1/tests", {"project_id": assessment_id}))
        for test in tests:
            test_id = test["id"]
            test["scenarios"] = list(client.get_all_objects("v1/test_scenarios", {"scenario_master_job": test_id}))
            test["assets"] = list(client.get_all_objects("v1/test_assets", {"scenario_master_job": test_id}))
        return tests

    @staticmethod
    def _compute_atomic_analysis(tests: List[Dict], version: int, boundaries: List) -> Dict[str, Any]:
        """Compute analysis metadata for an atomic assessment."""
        total_scenarios = sum(len(t.get("scenarios", [])) for t in tests)
        total_assets = sum(len(t.get("assets", [])) for t in tests)
        has_multi_asset = any(
            s.get("scenario", {}).get("is_multi_asset") for t in tests for s in t.get("scenarios", [])
        )
        is_network = bool(boundaries) and has_multi_asset

        if is_network:
            assessment_type = f"v{version} Atomic Network"
            estimated_jobs = total_scenarios * len(boundaries)
        else:
            assessment_type = f"v{version} Atomic Endpoint"
            estimated_jobs = sum(len(t.get("scenarios", [])) * max(len(t.get("assets", [])), 1) for t in tests)

        return {
            "assessment_type": assessment_type,
            "is_attack_graph": False,
            "is_network": is_network,
            "has_multi_asset_scenarios": has_multi_asset,
            "total_scenarios": total_scenarios,
            "total_assets": total_assets,
            "total_boundaries": len(boundaries) if is_network else 0,
            "estimated_jobs": estimated_jobs,
        }

    @staticmethod
    def _fetch_attack_graph(client: AttackIQRestClient, assessment_id: str) -> Optional[Dict[str, Any]]:
        """Fetch attack graph data for an assessment."""
        extra_url = client._build_url("v1/assessments/details", {"project_ids": assessment_id})
        extra = client._make_request(extra_url, method="get", json=None)
        attack_graph_id = extra.get("results", {}).get(assessment_id, {}).get("attack_graph_id") if extra else None
        if not attack_graph_id:
            return None
        return client.get_object(f"v1/attack_graphs/{attack_graph_id}")

    @staticmethod
    def _compute_attack_graph_analysis(graph: Dict[str, Any]) -> Dict[str, Any]:
        """Compute analysis metadata for an attack graph assessment."""
        graph_data = graph.get("graph", {})
        nodes = graph_data.get("graph", {})
        stages = graph_data.get("graph_meta", {}).get("stages", {})
        has_multi_asset = any(n.get("is_multi_asset") for n in nodes.values())
        graph_type = "MTAG" if has_multi_asset else "STAG"

        return {
            "assessment_type": f"Attack Graph {graph_type}",
            "is_attack_graph": True,
            "graph_type": graph_type,
            "total_nodes": len(nodes),
            "total_stages": len(stages),
            "has_multi_asset_nodes": has_multi_asset,
            "estimated_jobs": len(nodes),
        }

    @staticmethod
    def get_assessment_by_id(
        client: AttackIQRestClient, assessment_id: str, include_tests: bool = False
    ) -> Optional[Dict[str, Any]]:
        """Get assessment details with optional test configurations and analysis.

        Args:
            include_tests: If True, fetches test configurations and adds _analysis.

        Returns:
            Assessment dict. When include_tests=True, adds:
            - Atomic: tests[] with scenarios/assets, _analysis with type/counts
            - Attack graph: attack_graph structure, _analysis with nodes/stages
        """
        endpoint = f"{AssessmentUtils.ASSESSMENT_ENDPOINT}/{assessment_id}"
        logger.info(f"Fetching assessment details for ID: {assessment_id}")
        details = client.get_object(endpoint)

        if not include_tests or details is None:
            return details

        version = details.get("version", 1)
        boundaries = details.get("boundaries", [])

        if details.get("master_job_count", 0) > 0:
            tests = AssessmentUtils._fetch_atomic_tests(client, assessment_id)
            details["tests"] = tests
            details["_analysis"] = AssessmentUtils._compute_atomic_analysis(tests, version, boundaries)
        else:
            graph = AssessmentUtils._fetch_attack_graph(client, assessment_id)
            if graph:
                details["attack_graph"] = graph
                details["_analysis"] = AssessmentUtils._compute_attack_graph_analysis(graph)

        return details

    @staticmethod
    def search_assessments(
        client: AttackIQRestClient,
        query: Optional[str] = None,
        version: Optional[int] = None,
        created_after: Optional[str] = None,
        modified_after: Optional[str] = None,
        execution_strategy: Optional[int] = None,
        user_id: Optional[str] = None,
        is_attack_graph: Optional[bool] = None,
        project_template_id: Optional[str] = None,
        limit: int = 20,
        offset: int = 0,
        ordering: str = "-modified",
    ) -> Dict[str, Any]:
        """Search or list assessments with pagination.

        Args:
            version: Filter by assessment version (1 or 2). None returns both.
            created_after: ISO 8601 datetime to filter assessments created after.
            modified_after: ISO 8601 datetime to filter assessments modified after.
            execution_strategy: 0=PreventionAndDetection, 1=Prevention.
            user_id: Filter by user UUID.
            is_attack_graph: True for attack graphs, False for regular assessments.
            project_template_id: Filter by project template UUID.

        Returns {"count": total, "results": [...]} format for MCP compatibility.
        Note: minimal=true not used as it only returns id/name (too stripped down).
        """
        logger.info(f"Searching assessments: query='{query}', version={version}, limit={limit}, offset={offset}")
        params: Dict[str, Any] = {"page_size": limit, "offset": offset}
        if query:
            params["search"] = query
        if version is not None:
            params["version"] = version
        if created_after:
            params["created_after"] = created_after
        if modified_after:
            params["modified_after"] = modified_after
        if execution_strategy is not None:
            params["execution_strategy"] = execution_strategy
        if user_id:
            params["user_id"] = user_id
        if is_attack_graph is not None:
            params["is_attack_graph"] = str(is_attack_graph).lower()
        if project_template_id:
            params["project_template_id"] = project_template_id
        if ordering:
            params["ordering"] = ordering

        url = client._build_url(AssessmentUtils.ASSESSMENT_ENDPOINT, params)
        data = client._make_request(url, method="get", json=None)
        total_count = data.get("count", 0)
        results = data.get("results", [])
        logger.info(f"Found {total_count} total assessments, returning {len(results)}")
        return {"count": total_count, "results": results}

    @staticmethod
    def list_assessment_runs(
        client: AttackIQRestClient,
        assessment_id: str,
        limit: int = 20,
        offset: int = 0,
        ordering: str = "-created",
    ) -> Dict[str, Any]:
        """List runs for an assessment with pagination.

        Returns {"count": total, "results": [...]} format.
        Note: Runs don't support search queries - use list_assessments to find assessments first.
        """
        logger.info(f"Listing runs for assessment {assessment_id}: limit={limit}, offset={offset}")
        endpoint = f"{AssessmentUtils.PUBLIC_ENDPOINT}/{assessment_id}/runs"
        params: Dict[str, Any] = {}
        if ordering:
            params["ordering"] = ordering

        # Use get_all_objects which handles both list and paginated dict responses
        all_runs = list(client.get_all_objects(endpoint, params=params))
        total_count = len(all_runs)
        results = all_runs[offset : offset + limit]
        logger.info(f"Found {total_count} runs for assessment {assessment_id}, returning {len(results)}")
        return {"count": total_count, "results": results}

    @staticmethod
    def search_assessment_runs(
        client: AttackIQRestClient,
        assessment_id: str,
        limit: int = 20,
        offset: int = 0,
        ordering: str = "-created",
    ) -> Dict[str, Any]:
        """Deprecated: Use list_assessment_runs instead. Runs don't support search queries."""
        return AssessmentUtils.list_assessment_runs(client, assessment_id, limit, offset, ordering)

    @staticmethod
    def get_run(client: AttackIQRestClient, assessment_id: str, run_id: str) -> Optional[Dict[str, Any]]:
        """Get a specific run for an assessment.

        Returns None if run does not exist yet (common immediately after run creation).
        """
        endpoint = "v1/widgets/assessment_runs"
        params = {"project_id": assessment_id, "run_id": run_id}
        logger.debug(f"Getting run {run_id} for assessment {assessment_id}")

        try:
            results = client.get_object(endpoint, params=params)
            if results and isinstance(results, dict):
                runs = results["results"]
                if runs:
                    return runs[0]
        except RequestException as e:
            if e.response and e.response.status_code == 400:
                if "run does not exist" in e.response.text:
                    return None
            raise

        return None

    @staticmethod
    def get_most_recent_run_status(
        client: AttackIQRestClient, assessment_id: str, without_detection: bool = True
    ) -> Optional[Dict[str, Any]]:
        """Get the most recent run for an assessment with enriched status information."""
        logger.info(f"Getting most recent run status for assessment {assessment_id}")

        result = AssessmentUtils.list_assessment_runs(client, assessment_id, limit=1)
        runs = result.get("results", [])
        if runs:
            run = runs[0]
            run_id = run.get("id")
            logger.info(f"Found most recent run: {run_id}")

            # Get enriched status with progress counts
            status = AssessmentUtils.get_run_status(client, assessment_id, run_id, without_detection)
            if status:
                # Merge status fields into run object to preserve original fields
                run.update(status)

            return run

        logger.warning(f"No runs found for assessment {assessment_id}")
        return None

    @staticmethod
    def get_run_status(
        client: AttackIQRestClient,
        assessment_id: str,
        run_id: str,
        without_detection: bool = True,
    ) -> Optional[Dict[str, Any]]:
        """Check if a specific run is still executing."""
        logger.info(
            f"Checking status for run {run_id} of assessment {assessment_id} without detection: {without_detection}"
        )

        run = AssessmentUtils.get_run(client, assessment_id, run_id)
        if not run:
            logger.warning(f"Run ID {run_id} not found for assessment {assessment_id}")
            return None

        # Normalize to integers - API returns False for completed, integers for in-progress
        scenario_jobs = run.get("scenario_jobs_in_progress", 0)
        integration_jobs = run.get("integration_jobs_in_progress", 0)

        # Convert False to 0 for consistency
        scenario_jobs = 0 if scenario_jobs is False else scenario_jobs
        integration_jobs = 0 if integration_jobs is False else integration_jobs

        completed = scenario_jobs == 0 if without_detection else (scenario_jobs == 0 and integration_jobs == 0)

        # Include progress counts
        return {
            "scenario_jobs_in_progress": scenario_jobs,
            "integration_jobs_in_progress": integration_jobs,
            "completed": completed,
            "total_count": run.get("total_count", 0),
            "done_count": run.get("done_count", 0),
            "sent_count": run.get("sent_count", 0),
            "pending_count": run.get("pending_count", 0),
            "cancelled_count": run.get("cancelled_count", 0),
        }

    @staticmethod
    def is_run_complete(
        client: AttackIQRestClient,
        assessment_id: str,
        run_id: str,
        without_detection: bool = True,
    ) -> bool:
        """Convenience method to check if a run has completed."""
        status = AssessmentUtils.get_run_status(client, assessment_id, run_id, without_detection)
        return status.get("completed", False) if status else False

    @staticmethod
    def run_assessment(client: AttackIQRestClient, assessment_id: str, assessment_version: int) -> Optional[str]:
        """Run an assessment using the appropriate API version."""
        endpoint = (
            AssessmentUtils.RUN_ASSESSMENT_V2_ENDPOINT
            if assessment_version == 2
            else AssessmentUtils.RUN_ASSESSMENT_V1_ENDPOINT
        ).format(assessment_id)

        run_result = client.post_object(endpoint, data={})

        if not run_result:
            logger.error(f"Failed to start assessment {assessment_id}")
            return None

        run_id = run_result["run_id"]
        if not run_id:
            logger.error(f"No run ID in response for assessment {assessment_id}")
            return None

        logger.info(f"Assessment {assessment_id} (v{assessment_version}) started with run ID: {run_id}")
        return run_id

    @staticmethod
    def get_results_by_run_id(
        client: AttackIQRestClient,
        run_id: str,
        assessment_version: int,
        limit: Optional[int] = 10,
    ) -> Generator[Dict[str, Any], None, None]:
        """Get results for a specific run ID using the appropriate API version."""
        endpoint = (
            AssessmentUtils.RESULTS_V2_ENDPOINT if assessment_version == 2 else AssessmentUtils.RESULTS_V1_ENDPOINT
        )
        params = {"run_id": run_id, "assessment_results": "true"}
        logger.info(f"Fetching results for run ID: {run_id} from {endpoint}")

        generator = client.get_all_objects(endpoint, params=params)
        yield from itertools.islice(generator, limit)

    @staticmethod
    def get_result_details(
        client: AttackIQRestClient, result_id: str, assessment_version: int
    ) -> Optional[Dict[str, Any]]:
        """Get detailed information about a specific result."""
        base_endpoint = (
            AssessmentUtils.RESULTS_V2_ENDPOINT if assessment_version == 2 else AssessmentUtils.RESULTS_V1_ENDPOINT
        )
        endpoint = f"{base_endpoint}/{result_id}"
        logger.info(f"Fetching detailed result for ID: {result_id} from {endpoint}")
        return client.get_object(endpoint)

    @staticmethod
    def get_assets_in_assessment(
        client: AttackIQRestClient,
        assessment_id: str,
        limit: Optional[int] = 10,
    ) -> Generator[Dict[str, Any], None, None]:
        """List assets associated with an assessment, optionally limited to a specific count."""
        # Import here to avoid circular import
        from aiq_platform_api.core.assets import AssetUtils

        params = {"hide_hosted_agents": "true", "project_id": assessment_id}
        logger.info(f"Listing assets for assessment ID: {assessment_id}")
        generator = AssetUtils.get_assets(client, params=params)
        yield from itertools.islice(generator, limit)

    @staticmethod
    def wait_for_run_completion(
        client: AttackIQRestClient,
        assessment_id: str,
        run_id: str,
        timeout: int = 600,
        check_interval: int = 10,
        without_detection: bool = True,
    ) -> bool:
        """Wait for a run to complete, with timeout."""
        logger.info(
            f"Waiting for run {run_id} of assessment {assessment_id} to complete without detection: {without_detection}"
        )
        start_time = time.time()
        last_status = None

        while time.time() - start_time < timeout:
            run = AssessmentUtils.get_run(client, assessment_id, run_id)
            if not run:
                logger.warning(f"Run {run_id} not found")
                return False

            # API returns False for completed, integers for in-progress
            scenario_jobs = run.get("scenario_jobs_in_progress", 0)
            integration_jobs = run.get("integration_jobs_in_progress", 0)

            # Get progress counts
            total_count = run.get("total_count", 0)
            done_count = run.get("done_count", 0)

            # Check if completed (handles both False and 0)
            if without_detection:
                is_completed = not scenario_jobs
            else:
                is_completed = not scenario_jobs and not integration_jobs

            if is_completed:
                elapsed_time = round(time.time() - start_time, 2)
                logger.info(f"Run completed in {elapsed_time} seconds")
                return True

            # Show progress
            status_msg = f"Progress: {done_count}/{total_count} completed"
            if status_msg != last_status:
                logger.info(f"{status_msg}")
                last_status = status_msg

            time.sleep(check_interval)

        logger.warning(f"Run did not complete within {timeout} seconds")
        return False

    @staticmethod
    def get_execution_strategy(client: AttackIQRestClient, assessment_id: str) -> AssessmentExecutionStrategy:
        """Get assessment execution strategy (with or without detection validation)."""
        endpoint = f"{AssessmentUtils.ASSESSMENT_ENDPOINT}/{assessment_id}"
        assessment = client.get_object(endpoint)
        return AssessmentExecutionStrategy(assessment["execution_strategy"])

    @staticmethod
    def set_execution_strategy(client: AttackIQRestClient, assessment_id: str, with_detection: bool) -> bool:
        """Set assessment execution strategy (with or without detection validation)."""
        execution_strategy = (
            AssessmentExecutionStrategy.WITH_DETECTION
            if with_detection
            else AssessmentExecutionStrategy.WITHOUT_DETECTION
        )
        endpoint = f"{AssessmentUtils.ASSESSMENT_ENDPOINT}/{assessment_id}"
        result = client.patch_object(endpoint, {"execution_strategy": execution_strategy.value})
        return result is not None
