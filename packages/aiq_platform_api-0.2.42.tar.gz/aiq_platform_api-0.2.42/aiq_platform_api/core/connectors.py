import itertools
from typing import Optional, Dict, Any, Generator

from aiq_platform_api.core.client import AttackIQRestClient
from aiq_platform_api.core.logger import AttackIQLogger

logger = AttackIQLogger.get_logger(__name__)


class ConnectorUtils:
    """Utilities for working with company connectors.

    API Endpoint: /v1/company_connectors
    """

    ENDPOINT = "v1/company_connectors"

    @staticmethod
    def get_connectors(
        client: AttackIQRestClient, params: dict = None, limit: Optional[int] = 10
    ) -> Generator[Dict[str, Any], None, None]:
        """List connectors, optionally filtered and limited."""
        generator = client.get_all_objects(ConnectorUtils.ENDPOINT, params=params)
        yield from itertools.islice(generator, limit)

    @staticmethod
    def get_connector_by_id(client: AttackIQRestClient, connector_id: str):
        """Get a specific connector by its ID."""
        return client.get_object(f"{ConnectorUtils.ENDPOINT}/{connector_id}")
