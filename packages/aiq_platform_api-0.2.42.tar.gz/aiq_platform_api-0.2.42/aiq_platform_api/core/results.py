import itertools
from datetime import datetime
from typing import Optional, Dict, Any, Generator

from aiq_platform_api.core.client import AttackIQRestClient
from aiq_platform_api.core.logger import AttackIQLogger

logger = AttackIQLogger.get_logger(__name__)


class ResultsUtils:
    """Utilities for working with results in the AttackIQ platform.

    API Endpoint: /v1/results
    """

    ENDPOINT = "v1/results"

    @staticmethod
    def get_results(
        client: AttackIQRestClient,
        page: int = 1,
        page_size: int = 10,
        search: str = "",
        start_date: Optional[datetime] = None,
        end_date: Optional[datetime] = None,
        limit: Optional[int] = 10,
    ) -> Generator[Dict[str, Any], None, None]:
        """List results, optionally filtered and limited."""
        params = {
            "page": page,
            "page_size": page_size,
            "search": search,
        }
        if start_date:
            params["start_date"] = start_date.isoformat()
        if end_date:
            params["end_date"] = end_date.isoformat()
        generator = client.get_all_objects(ResultsUtils.ENDPOINT, params=params)
        yield from itertools.islice(generator, limit)

    @staticmethod
    def get_results_by_run_id(
        client: AttackIQRestClient, run_id: str, limit: Optional[int] = 10
    ) -> Generator[Dict[str, Any], None, None]:
        """Get assessment result summaries filtered by run ID, optionally limited."""
        endpoint_with_params = f"{ResultsUtils.ENDPOINT}?run_id={run_id}&assessment_results=true"
        logger.info(f"Fetching result summaries for run_id: {run_id} from constructed URL: {endpoint_with_params}")
        generator = client.get_all_objects(endpoint_with_params, params=None)
        yield from itertools.islice(generator, limit)

    @staticmethod
    def get_result_by_id(client: AttackIQRestClient, result_id: str) -> Optional[Dict[str, Any]]:
        """Get detailed results for a specific result ID."""
        endpoint = f"{ResultsUtils.ENDPOINT}/{result_id}"
        logger.info(f"Attempting to fetch result details from endpoint: {endpoint}.")
        return client.get_object(endpoint)


class PhaseResultsUtils:
    """Utilities for working with phase results in the AttackIQ platform.

    API Endpoint: /v1/phase_results
    """

    ENDPOINT = "v1/phase_results"

    @staticmethod
    def get_phase_results(
        client: AttackIQRestClient,
        assessment_id: str,
        project_run_id: Optional[str] = None,
        result_summary_id: Optional[str] = None,
        limit: Optional[int] = 10,
    ) -> Generator[dict, None, None]:
        """Get phase results, optionally filtered and limited."""
        # BEWARE: created_after is NOT supported by phase_results endpoint yet
        params = {"project_id": assessment_id}
        if project_run_id:
            params["project_run"] = project_run_id
        if result_summary_id:
            params["result_summary"] = result_summary_id
        generator = client.get_all_objects(PhaseResultsUtils.ENDPOINT, params=params)
        yield from itertools.islice(generator, limit)


class PhaseLogsUtils:
    """Utilities for working with phase logs in the AttackIQ platform.

    API Endpoint: /v1/phase_logs
    """

    ENDPOINT = "v1/phase_logs"

    @staticmethod
    def get_phase_logs(
        client: AttackIQRestClient,
        scenario_job_id: str,
        limit: Optional[int] = 10,
    ) -> Generator[dict, None, None]:
        """Get phase logs for a scenario job, optionally limited."""
        # BEWARE: created_after is NOT supported by phase_results endpoint yet
        params = {"scenario_job_id": scenario_job_id}
        generator = client.get_all_objects(PhaseLogsUtils.ENDPOINT, params=params)
        yield from itertools.islice(generator, limit)
