"""Custom exceptions used throughout the contextual graph package."""
