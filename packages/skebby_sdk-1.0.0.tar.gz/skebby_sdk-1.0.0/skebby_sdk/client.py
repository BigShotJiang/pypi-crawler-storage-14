from .api.auth import AuthApi
from .api.sms import SmsApi
from .api.user import UserApi
from .api.contacts import ContactsApi
from .api.received import ReceivedApi
from .api.templates import TemplatesApi
from .api.subaccounts import SubaccountsApi
from .api.tpoa import TpoaApi
from .api.two_factor import TwoFactorApi
from .api.landing_pages import LandingPagesApi
from .api.blacklist import BlacklistApi

class SkebbyClient:
    def __init__(self, username=None, password=None, user_key=None, session_key=None, access_token=None):
        """
        Initialize the Skebby Client.
        """
        self.user_key = user_key
        self.session_key = session_key
        self.access_token = access_token
        
        # Initialize API modules
        self.auth = AuthApi(self)
        self.sms = SmsApi(self)
        self.user = UserApi(self)
        self.contacts = ContactsApi(self)
        self.received = ReceivedApi(self)
        self.templates = TemplatesApi(self)
        self.subaccounts = SubaccountsApi(self)
        self.tpoa = TpoaApi(self)
        self.two_factor = TwoFactorApi(self)
        self.landing_pages = LandingPagesApi(self)
        self.blacklist = BlacklistApi(self)
        
        if username and password:
            if not self.user_key:
                self.user_key, self.access_token = self.auth.get_token(username, password)

    def get_headers(self):
        """
        Construct headers for API requests based on available credentials.
        """
        headers = {
            "Content-Type": "application/json"
        }
        
        if self.user_key:
            headers["user_key"] = self.user_key
            
        if self.access_token:
            headers["Access_token"] = self.access_token
        elif self.session_key:
            headers["Session_key"] = self.session_key
            
        return headers
