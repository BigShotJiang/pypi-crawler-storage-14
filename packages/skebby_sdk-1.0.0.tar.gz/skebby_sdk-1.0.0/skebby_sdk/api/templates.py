from typing import Dict, Any, Optional, List
from .base import BaseApi

class TemplatesApi(BaseApi):
    def create_template(self, text: str, name: Optional[str] = None, encoding: Optional[str] = None, 
                        sender: Optional[str] = None) -> Dict[str, Any]:
        """
        Create a new SMS template.
        
        :param text: The content of the template.
        :param name: The name of the template (optional).
        :param encoding: Message encoding (e.g., "GSM", "UCS2") (optional).
        :param sender: Default sender alias for the template (optional).
        :return: Dictionary containing the created template:
                 - id (int): Template ID
                 - name (str): Template name
                 - text (str): Template text
                 - encoding (str): Template encoding
                 - sender (str): Default sender
        """
        payload = {"text": text}
        if name is not None: 
            payload["name"] = name
        if encoding is not None: 
            payload["encoding"] = encoding
        if sender is not None: 
            payload["sender"] = sender
        return self._request("POST", "template", data=payload)

    def get_templates(self) -> List[Dict[str, Any]]:
        """
        Get all templates.
        
        :return: A list of all templates.
        """
        return self._request("GET", "template")

    def get_template(self, template_id: int) -> Dict[str, Any]:
        """
        Get a specific template.
        
        :param template_id: The ID of the template to retrieve.
        :return: A dictionary containing the template details.
        """
        return self._request("GET", f"template/{template_id}")

    def modify_template(self, template_id: int, operations: List[Dict[str, Any]]) -> Dict[str, Any]:
        """
        Modify an existing template using JSON Patch operations.
        
        Note: The official API uses PATCH with JSON Patch format (RFC 6902).
        
        :param template_id: The ID of the template to modify.
        :param operations: List of JSON Patch operations. Each operation is a dict with:
                          - 'op': Operation type ('replace', 'add', 'remove', 'copy', 'move', 'test')
                          - 'path': JSON pointer to the field (e.g., '/text', '/name', '/encoding', '/sender')
                          - 'value': New value for the field (required for 'replace' and 'add')
                          Example: [{"op": "replace", "path": "/text", "value": "new message"}]
        :return: A dictionary containing the updated template details.
        """
        return self._request("PATCH", f"template/{template_id}", data=operations)

    def delete_template(self, template_id: int) -> Dict[str, Any]:
        """
        Delete a template.
        
        :param template_id: The ID of the template to delete.
        :return: API response confirming deletion.
        """
        return self._request("DELETE", f"template/{template_id}")

