import base64
from typing import Tuple
from .base import BaseApi
from ..exceptions import SkebbyAuthException

class AuthApi(BaseApi):
    def login(self, username: str, password: str) -> Tuple[str, str]:
        """
        Authenticate using a session key.
        
        :param username: The registration email or username.
        :param password: The password.
        :return: A tuple containing (user_key, session_key).
        :raises SkebbyAuthException: If authentication fails.
        """
        credentials = f"{username}:{password}"
        encoded_credentials = base64.b64encode(credentials.encode()).decode()
        
        headers = {
            "Authorization": f"Basic {encoded_credentials}"
        }
        
        try:
            import requests
            url = f"{self.BASE_URL}/login"
            response = requests.get(url, headers=headers)
            response.raise_for_status()
            
            parts = response.text.split(';')
            if len(parts) >= 2:
                return parts[0], parts[1]
            else:
                raise SkebbyAuthException("Invalid response format from login endpoint")
                
        except Exception as e:
            raise SkebbyAuthException(f"Login failed: {str(e)}") from e

    def get_token(self, username: str, password: str) -> Tuple[str, str]:
        """
        Authenticate using a user token.
        
        :param username: The registration email or username.
        :param password: The password.
        :return: A tuple containing (user_key, access_token).
        :raises SkebbyAuthException: If authentication fails.
        """
        credentials = f"{username}:{password}"
        encoded_credentials = base64.b64encode(credentials.encode()).decode()
        
        headers = {
            "Authorization": f"Basic {encoded_credentials}"
        }
        
        try:
            import requests
            url = f"{self.BASE_URL}/token"
            response = requests.get(url, headers=headers)
            response.raise_for_status()
            
            parts = response.text.split(';')
            if len(parts) >= 2:
                return parts[0], parts[1]
            else:
                raise SkebbyAuthException("Invalid response format from token endpoint")
                
        except Exception as e:
            raise SkebbyAuthException(f"Token retrieval failed: {str(e)}") from e
