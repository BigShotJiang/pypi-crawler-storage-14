import requests
from ..exceptions import (
    SkebbyRequestException, 
    SkebbyAuthException,
    SkebbyValidationException,
    SkebbyNotFoundException,
    SkebbyRateLimitException,
    SkebbyServerException
)

class BaseApi:
    BASE_URL = "https://api.skebby.it/API/v1.0/REST"

    def __init__(self, client):
        self.client = client

    def _request(self, method, endpoint, params=None, data=None, headers=None):
        url = f"{self.BASE_URL}/{endpoint}"
        
        request_headers = self.client.get_headers()
        if headers:
            request_headers.update(headers)

        try:
            response = requests.request(
                method,
                url,
                params=params,
                json=data,
                headers=request_headers
            )
            response.raise_for_status()
            
            if not response.content:
                return None
                
            return response.json()
            
        except requests.exceptions.HTTPError as e:
            status_code = e.response.status_code
            error_msg = str(e)
            error_code = None
            error_body = None
            
            try:
                error_body = e.response.json()
                if isinstance(error_body, dict):
                    error_msg = error_body.get("message", error_body.get("error_message", str(error_body)))
                    error_code = error_body.get("code")
            except ValueError:
                error_msg = e.response.text or str(e)

            if status_code == 400:
                raise SkebbyValidationException(error_msg, error_code, error_body) from e
            elif status_code == 401:
                raise SkebbyAuthException(error_msg) from e
            elif status_code == 404:
                raise SkebbyNotFoundException(error_msg, error_code, error_body) from e
            elif status_code == 429:
                raise SkebbyRateLimitException(error_msg, error_code, error_body) from e
            elif 500 <= status_code < 600:
                raise SkebbyServerException(error_msg, error_code, error_body) from e
            else:
                raise SkebbyRequestException(error_msg, error_code, error_body) from e
                
        except requests.exceptions.RequestException as e:
            raise SkebbyRequestException(f"Request failed: {str(e)}") from e

    def _format_date(self, date_obj):
        """
        Format a date object to Skebby's expected format (YYYYMMDDHHmmSS).
        If it's already a string, return it as is.
        """
        if hasattr(date_obj, 'strftime'):
            return date_obj.strftime("%Y%m%d%H%M%S")
        return date_obj
