from typing import List, Dict, Any, Optional, Union
from .base import BaseApi

class ContactsApi(BaseApi):
    def add_contact(self, phone_number: str, name: Optional[str] = None, surname: Optional[str] = None, 
                    email: Optional[str] = None, gender: Optional[str] = None, fax: Optional[str] = None, 
                    zip: Optional[str] = None, address: Optional[str] = None, city: Optional[str] = None, 
                    province: Optional[str] = None, birthdate: Optional[str] = None, 
                    group_ids: Optional[List[str]] = None, **kwargs: Any) -> Dict[str, Any]:
        """
        Add a new contact.
        
        :param phone_number: The phone number of the contact (required).
        :param name: First name (optional).
        :param surname: Last name (optional).
        :param email: Email address (optional).
        :param gender: Gender (optional).
        :param fax: Fax number (optional).
        :param zip: ZIP/postal code (optional).
        :param address: Address (optional).
        :param city: City (optional).
        :param province: Province (optional).
        :param birthdate: Birthdate (optional).
        :param group_ids: List of group IDs to add the contact to (optional).
        :param kwargs: Other custom fields supported by the API.
        :return: Dictionary containing the created contact:
                 - id (int): Contact ID
                 - phoneNumber (str): Phone number
                 - name (str): Contact name
                 - surname (str): Contact surname
                 - email (str): Contact email
                 - groupIds (list): List of group IDs
        """
        payload = {
            "phoneNumber": phone_number
        }
        
        if name is not None: payload["name"] = name
        if surname is not None: payload["surname"] = surname
        if email is not None: payload["email"] = email
        if gender is not None: payload["gender"] = gender
        if fax is not None: payload["fax"] = fax
        if zip is not None: payload["zip"] = zip
        if address is not None: payload["address"] = address
        if city is not None: payload["city"] = city
        if province is not None: payload["province"] = province
        if birthdate is not None: payload["birthdate"] = birthdate
        if group_ids is not None: payload["groupIds"] = group_ids
        
        # Add any other provided fields
        payload.update(kwargs)
        
        return self._request("POST", "contact", data=payload)

    def add_multiple_contacts(self, contacts: List[Dict[str, Any]], update_existing_contact: bool = True) -> Dict[str, Any]:
        """
        Add multiple contacts.
        
        :param contacts: A list of dictionaries, each representing a contact.
                         Example: [{'phoneNumber': '...', 'name': '...'}, ...]
        :param update_existing_contact: Whether to update existing contacts (default True).
        :return: Dictionary containing:
                 - created (int): Number of contacts created
                 - updated (int): Number of contacts updated
                 - errors (list): List of errors if any
        """
        payload = {
            "contacts": contacts,
            "updateExistingContact": update_existing_contact
        }
        return self._request("POST", "contacts", data=payload)

    def get_contact(self, contact_id: int) -> Dict[str, Any]:
        """
        Get a specific contact by ID.
        
        :param contact_id: The ID of the contact to retrieve.
        :return: Dictionary containing contact details:
                 - id (int): Contact ID
                 - phoneNumber (str): Phone number
                 - name (str): Contact name
                 - surname (str): Contact surname
                 - email (str): Contact email
                 - groupIds (list): List of group IDs
        """
        return self._request("GET", f"contact/{contact_id}")

    def get_contacts(self, page_number: int = 1, page_size: int = 50) -> Dict[str, Any]:
        """
        Get all contacts with pagination.
        
        :param page_number: Page number (default 1).
        :param page_size: Items per page (default 50).
        :return: Dictionary containing:
                 - contacts (list): List of contact objects
                 - page_number (int): Current page number
                 - page_size (int): Number of items per page
                 - total_pages (int): Total number of pages
        """
        params = {
            "pageNumber": page_number,
            "pageSize": page_size
        }
        return self._request("GET", "contact", params=params)

    def get_custom_fields(self) -> List[Dict[str, Any]]:
        """
        List contact's custom fields.
        
        :return: List of custom field definitions:
                 - id (int): Field ID
                 - name (str): Field name
                 - type (str): Field type
        """
        return self._request("GET", "contacts/fields")

    def add_contact_to_blacklist_by_id(self, contact_id: int) -> Dict[str, Any]:
        """
        Add a contact to SMS blacklist by contact ID.
        
        :param contact_id: The ID of the contact to add to blacklist.
        :return: A dictionary containing the result of the operation.
        """
        return self._request("POST", f"contact/add_to_blacklist/{contact_id}")

    def add_phone_to_blacklist(self, phone_number: str) -> Dict[str, Any]:
        """
        Add a phone number to SMS blacklist.
        
        :param phone_number: The phone number to add to blacklist.
        :return: A dictionary containing the result of the operation.
        """
        params = {"phoneNumber": phone_number}
        return self._request("POST", "contact/add_to_blacklist", params=params)

    def add_multiple_contacts_to_blacklist(self, contact_ids: List[int]) -> Dict[str, Any]:
        """
        Add multiple contacts to SMS blacklist.
        
        :param contact_ids: A list of contact IDs to add to blacklist.
        :return: A dictionary containing the result.
        """
        payload = {"contactIds": contact_ids}
        return self._request("POST", "contacts/add_to_blacklist", data=payload)

    def create_group(self, name: str, description: Optional[str] = None) -> Dict[str, Any]:
        """
        Create a new contact group.
        
        :param name: The name of the group.
        :param description: Description of the group (optional).
        :return: Dictionary containing the created group:
                 - id (int): Group ID
                 - name (str): Group name
                 - description (str): Group description
        """
        payload = {"name": name}
        if description: payload["description"] = description
        return self._request("POST", "group", data=payload)

    def update_group(self, group_id: int, name: Optional[str] = None, description: Optional[str] = None) -> Dict[str, Any]:
        """
        Modify an existing contact group.
        
        :param group_id: The ID of the group to update.
        :param name: New name for the group (optional).
        :param description: New description for the group (optional).
        :return: A dictionary containing the updated group details.
        """
        payload = {}
        if name is not None: payload["name"] = name
        if description is not None: payload["description"] = description
        return self._request("PUT", f"group/{group_id}", data=payload)

    def get_groups(self, page_number: int = 1, page_size: int = 50) -> Dict[str, Any]:
        """
        Get all contact groups with pagination.
        
        :param page_number: Page number (default 1).
        :param page_size: Items per page (default 50).
        :return: Dictionary containing:
                 - groups (list): List of group objects
                 - page_number (int): Current page number
                 - page_size (int): Number of items per page
        """
        params = {
            "pageNumber": page_number,
            "pageSize": page_size
        }
        return self._request("GET", "groups", params=params)

    def delete_group(self, group_id: int) -> Dict[str, Any]:
        """
        Delete a contact group.
        
        :param group_id: The ID of the group to delete.
        :return: API response confirming deletion.
        """
        return self._request("DELETE", f"group/{group_id}")

    def add_contact_to_group(self, group_id: int, phone_number: str) -> Dict[str, Any]:
        """
        Add a contact to a group.
        
        :param group_id: The ID of the group.
        :param phone_number: The phone number of the contact.
        :return: API response.
        """
        payload = {"phoneNumber": phone_number}
        return self._request("PUT", f"group/{group_id}/contact", data=payload)

    def remove_contact_from_group(self, group_id: int, phone_number: str) -> Dict[str, Any]:
        """
        Remove a contact from a group.
        
        :param group_id: The ID of the group.
        :param phone_number: The phone number of the contact.
        :return: API response confirming removal.
        """
        return self._request("DELETE", f"group/{group_id}/contact/{phone_number}")

    def blacklist_add(self, phone_numbers: Union[str, List[str]]) -> Dict[str, Any]:
        """
        Add one or more phone numbers to the SMS blacklist.
        
        :param phone_numbers: A single phone number (string) or a list of phone numbers.
        :return: A dictionary containing the result.
        """
        if isinstance(phone_numbers, str):
            phone_numbers = [phone_numbers]
        payload = {"phoneNumbers": phone_numbers}
        return self._request("POST", "blacklist/sms", data=payload)

    def blacklist_get(self, from_date: Optional[str] = None, to_date: Optional[str] = None, 
                      page_number: Optional[int] = None, page_size: Optional[int] = None) -> Dict[str, Any]:
        """
        Get blacklisted numbers with optional filtering and pagination.
        
        :param from_date: Filter by start date (optional).
        :param to_date: Filter by end date (optional).
        :param page_number: Page number for pagination (optional).
        :param page_size: Page size for pagination (optional).
        :return: Dictionary containing:
                 - blacklist (list): List of blacklisted phone numbers
                 - page_number (int): Current page number
                 - page_size (int): Number of items per page
                 - total_pages (int): Total number of pages
        """
        params = {}
        if from_date is not None: params["from"] = from_date
        if to_date is not None: params["to"] = to_date
        if page_number is not None: params["pageNumber"] = page_number
        if page_size is not None: params["pageSize"] = page_size
        return self._request("GET", "blacklist/sms", params=params)

    def blacklist_remove(self, phone_number: str) -> Dict[str, Any]:
        """
        Remove a number from the SMS blacklist.
        
        :param phone_number: The phone number to remove.
        :return: API response confirming removal.
        """
        return self._request("DELETE", f"blacklist/sms/{phone_number}")

