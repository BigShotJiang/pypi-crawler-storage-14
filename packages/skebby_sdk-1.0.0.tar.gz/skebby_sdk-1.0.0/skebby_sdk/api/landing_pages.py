from typing import List, Dict, Any
from .base import BaseApi

class LandingPagesApi(BaseApi):
    """
    API for managing landing pages.
    
    Landing pages are web pages created through the Skebby platform
    that can be used for SMS campaigns and marketing.
    """
    
    def get_landing_pages(self) -> List[Dict[str, Any]]:
        """
        List all published landing pages.
        
        Returns a list of landing page objects containing information
        about each published landing page associated with your account.
        
        :return: A list of dictionaries, each containing landing page details.
                 Example structure:
                 [
                     {
                         "id": 123,
                         "name": "Summer Campaign",
                         "url": "https://...",
                         "created": "2024-01-01",
                         "status": "published"
                     },
                     ...
                 ]
        """
        return self._request("GET", "landings")
