from typing import Dict, Any
from .base import BaseApi

class UserApi(BaseApi):
    def get_status(self, get_money: bool = False, type_aliases: bool = False) -> Dict[str, Any]:
        """
        Get SMS credits and service status.
        
        :param get_money: If True, returns the credit balance in money (boolean).
        :param type_aliases: If True, returns the aliases for message types (boolean).
        :return: A dictionary containing the user's status.
                 Structure:
                 {
                     "money": float or null,
                     "sms": [
                         {"type": "SI", "quantity": int},
                         {"type": "TI", "quantity": int},
                         ...
                     ],
                     "email": {
                         "bandwidth": float,
                         "purchased": string,
                         "billing": string,
                         "expiry": string
                     }
                 }
        """
        params = {}
        if get_money: params["getMoney"] = "true"
        if type_aliases: params["typeAliases"] = "true"
        
        return self._request("GET", "status", params=params)
