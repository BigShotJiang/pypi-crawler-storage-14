from typing import Dict, Any, Optional, List, Union
from datetime import datetime
from .base import BaseApi

class BlacklistApi(BaseApi):
    """
    API for managing SMS blacklist.
    
    The blacklist prevents sending SMS to specific phone numbers.
    Numbers can be added individually or in batch.
    """
    
    def add_phone_number(self, phone_number: str) -> Dict[str, Any]:
        """
        Add a phone number to the SMS blacklist.
        
        :param phone_number: The phone number to add to blacklist (in international format, e.g., "+393471234567").
        :return: API response confirming the addition.
        
        Example:
            >>> client.blacklist.add_phone_number("+393471234567")
            {'result': 'OK'}
        """
        params = {"phoneNumber": phone_number}
        return self._request("POST", "blacklist/sms", params=params)
    
    def add_multiple_phone_numbers(self, phone_numbers: List[str]) -> Dict[str, Any]:
        """
        Add multiple phone numbers to the SMS blacklist.
        
        :param phone_numbers: List of phone numbers to add to blacklist.
        :return: Dictionary containing:
                 - added (int): Number of phone numbers successfully added
                 - errors (list, optional): List of errors if any
        
        Example:
            >>> client.blacklist.add_multiple_phone_numbers(["+393471234567", "+393471234568"])
            {'added': 2}
        """
        payload = {"phoneNumbers": phone_numbers}
        return self._request("POST", "blacklist/smsbatch", data=payload)
    
    def get_blacklist(self, from_date: Optional[Union[datetime, str]] = None, 
                      to_date: Optional[Union[datetime, str]] = None, 
                      page_number: int = 1, page_size: int = 50) -> Dict[str, Any]:
        """
        Retrieve the list of phone numbers in the SMS blacklist.
        
        :param from_date: Start date for filtering (datetime or YYYYMMDDHHmmSS) (optional).
        :param to_date: End date for filtering (datetime or YYYYMMDDHHmmSS) (optional).
        :param page_number: Page number (default 1).
        :param page_size: Items per page (default 50).
        :return: Dictionary containing:
                 - blacklist (list): List of blacklisted phone numbers
                 - page_number (int): Current page number
                 - page_size (int): Number of items per page
                 - total_pages (int): Total number of pages
        
        Example:
            >>> client.blacklist.get_blacklist()
            {
                'blacklist': [
                    {'phoneNumber': '+393471234567', 'addedDate': '20240101120000'},
                    {'phoneNumber': '+393471234568', 'addedDate': '20240101120100'}
                ],
                'page_number': 1,
                'page_size': 50,
                'total_pages': 1
            }
        """
        params = {
            "pageNumber": page_number,
            "pageSize": page_size
        }
        
        if from_date is not None:
            params["from"] = self._format_date(from_date)
        if to_date is not None:
            params["to"] = self._format_date(to_date)
        
        return self._request("GET", "blacklist/sms", params=params)
