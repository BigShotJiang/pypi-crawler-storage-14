from typing import List, Dict, Any, Optional, Union
from datetime import datetime
from .base import BaseApi

class SmsApi(BaseApi):
    def send_sms(self, message: str, recipients: List[str], message_type: str = "GP", sender: Optional[str] = None, 
                 scheduled_delivery_time: Optional[Union[datetime, str]] = None, order_id: Optional[str] = None, 
                 return_credits: bool = False, encoding: Optional[str] = None, validity_period: Optional[int] = None, 
                 delivery_notification_url: Optional[str] = None, allow_duplicate: bool = False) -> Dict[str, Any]:
        """
        Send an SMS message.
        
        :param message: The text of the message.
        :param recipients: List of phone numbers (strings) in international format (e.g., "+393471234567").
        :param message_type: Type of message. Common types: "GP" (Gateway Plus), "TI" (Top Interactive), "SI" (Standard Interactive).
        :param sender: Sender alias (TPOA). Must be pre-registered or numeric (optional).
        :param scheduled_delivery_time: datetime object or string (YYYYMMDDHHmmSS) for scheduled delivery (optional).
        :param order_id: Custom unique ID for the message order (optional).
        :param return_credits: If True, the response will include the remaining credits (optional).
        :param encoding: Message encoding (e.g., "UCS2" for emojis). Default is GSM 7-bit (optional).
        :param validity_period: Validity period of the message in minutes (optional).
        :param delivery_notification_url: URL to receive delivery reports via webhook (optional).
        :param allow_duplicate: If True, allows sending duplicate messages within a short timeframe (optional).
        :return: Dictionary containing:
                 - result (str): "OK" on success, or error message
                 - order_id (str): Unique identifier for the SMS order
                 - total_sent (int): Number of SMS sent or credits used
                 - remaining_credits (int, optional): Remaining credits if return_credits=True
                 - internal_order_id (str, optional): Internal order identifier
        """
        payload = {
            "message": message,
            "message_type": message_type,
            "recipient": recipients
        }
        
        if sender is not None: 
            payload["sender"] = sender
        if scheduled_delivery_time is not None: 
            payload["scheduled_delivery_time"] = self._format_date(scheduled_delivery_time)
        if order_id is not None: 
            payload["order_id"] = order_id
        if return_credits: 
            payload["returnCredits"] = True
        if encoding is not None: 
            payload["encoding"] = encoding
        if validity_period is not None: 
            payload["validity_period"] = validity_period
        if delivery_notification_url is not None: 
            payload["delivery_notification_url"] = delivery_notification_url
        if allow_duplicate: 
            payload["allow_duplicate"] = True
            
        return self._request("POST", "sms", data=payload)

    def send_parametric_sms(self, message: str, recipients: List[Dict[str, Any]], message_type: str = "GP", 
                           sender: Optional[str] = None, scheduled_delivery_time: Optional[Union[datetime, str]] = None, 
                           order_id: Optional[str] = None, return_credits: bool = False, encoding: Optional[str] = None, 
                           validity_period: Optional[int] = None, delivery_notification_url: Optional[str] = None, 
                           allow_duplicate: bool = False, allow_invalid_recipients: bool = False, 
                           return_remaining: bool = False) -> Dict[str, Any]:
        """
        Send a parametric SMS message.
        
        :param message: The text of the message with placeholders (e.g., "Hello ${name}").
        :param recipients: List of dictionaries, each containing 'recipient' (phone number) and parameter keys matching the placeholders.
                           Example: [{'recipient': '+39...', 'name': 'Mario'}]
        :param message_type: Type of message (e.g., "GP", "TI") (optional).
        :param sender: Sender alias (TPOA) (optional).
        :param scheduled_delivery_time: datetime object or string (YYYYMMDDHHmmSS) (optional).
        :param order_id: Custom unique ID (optional).
        :param return_credits: If True, returns remaining credits (optional).
        :param encoding: Message encoding (optional).
        :param validity_period: Validity period in minutes (optional).
        :param delivery_notification_url: Webhook URL (optional).
        :param allow_duplicate: Allow duplicates (optional).
        :param allow_invalid_recipients: If True, allows sending even if some recipients are invalid (optional).
        :param return_remaining: If True, returns remaining recipients info (optional).
        :return: Dictionary containing:
                 - result (str): "OK" on success, or error message
                 - order_id (str): Unique identifier for the SMS order
                 - total_sent (int): Number of SMS sent or credits used
                 - remaining_credits (int, optional): Remaining credits if return_credits=True
                 - internal_order_id (str, optional): Internal order identifier
        """
        payload = {
            "message": message,
            "message_type": message_type,
            "recipients": recipients
        }
        
        if sender is not None: 
            payload["sender"] = sender
        if scheduled_delivery_time is not None: 
            payload["scheduled_delivery_time"] = self._format_date(scheduled_delivery_time)
        if order_id is not None: 
            payload["order_id"] = order_id
        if return_credits: 
            payload["returnCredits"] = True
        if encoding is not None: 
            payload["encoding"] = encoding
        if validity_period is not None: 
            payload["validity_period"] = validity_period
        if delivery_notification_url is not None: 
            payload["delivery_notification_url"] = delivery_notification_url
        if allow_duplicate: 
            payload["allow_duplicate"] = True
        if allow_invalid_recipients: 
            payload["allowInvalidRecipients"] = True
        if return_remaining: 
            payload["returnRemaining"] = True
            
        return self._request("POST", "paramsms", data=payload)

    def send_sms_to_group(self, message: str, group_ids: List[str], message_type: str = "GP", 
                         sender: Optional[str] = None, scheduled_delivery_time: Optional[Union[datetime, str]] = None, 
                         order_id: Optional[str] = None, return_credits: bool = False, encoding: Optional[str] = None, 
                         validity_period: Optional[int] = None, delivery_notification_url: Optional[str] = None, 
                         allow_duplicate: bool = False) -> Dict[str, Any]:
        """
        Send an SMS message to one or more groups.
        
        :param message: The text of the message.
        :param group_ids: List of Group IDs (strings) to send to.
        :param message_type: Type of message (optional).
        :param sender: Sender alias (optional).
        :param scheduled_delivery_time: datetime object or string (optional).
        :param order_id: Custom unique ID (optional).
        :param return_credits: If True, returns remaining credits (optional).
        :param encoding: Message encoding (optional).
        :param validity_period: Validity period in minutes (optional).
        :param delivery_notification_url: Webhook URL (optional).
        :param allow_duplicate: Allow duplicates (optional).
        :return: Dictionary containing:
                 - result (str): "OK" on success, or error message
                 - order_id (str): Unique identifier for the SMS order
                 - total_sent (int): Number of SMS sent or credits used
                 - remaining_credits (int, optional): Remaining credits if return_credits=True
                 - internal_order_id (str, optional): Internal order identifier
        """
        payload = {
            "message": message,
            "message_type": message_type,
            "recipientsGroupdIds": group_ids
        }
        
        if sender is not None: 
            payload["sender"] = sender
        if scheduled_delivery_time is not None: 
            payload["scheduled_delivery_time"] = self._format_date(scheduled_delivery_time)
        if order_id is not None: 
            payload["order_id"] = order_id
        if return_credits: 
            payload["returnCredits"] = True
        if encoding is not None: 
            payload["encoding"] = encoding
        if validity_period is not None: 
            payload["validity_period"] = validity_period
        if delivery_notification_url is not None: 
            payload["delivery_notification_url"] = delivery_notification_url
        if allow_duplicate: 
            payload["allow_duplicate"] = True
            
        return self._request("POST", "smstogroups", data=payload)

    def delete_scheduled_message(self, order_id: str) -> Dict[str, Any]:
        """
        Delete a scheduled message by order_id.
        
        :param order_id: The Order ID of the scheduled message to delete.
        :return: Dictionary containing:
                 - order_id (str): The deleted order ID
        """
        return self._request("DELETE", f"sms/{order_id}")

    def delete_all_scheduled_messages(self) -> Dict[str, Any]:
        """
        Delete all scheduled messages.
        
        :return: Dictionary confirming bulk deletion of all scheduled messages.
        """
        return self._request("DELETE", "sms/bulk")

    def get_history(self, from_date: Union[datetime, str], to_date: Optional[Union[datetime, str]] = None, 
                    page_number: int = 1, page_size: int = 50, sort: Optional[str] = None, 
                    dir: Optional[str] = None) -> Dict[str, Any]:
        """
        Get sent SMS history.
        
        :param from_date: Start date (datetime or YYYYMMDDHHmmSS).
        :param to_date: End date (datetime or YYYYMMDDHHmmSS) (optional).
        :param page_number: Page number (default 1).
        :param page_size: Items per page (default 50).
        :param sort: Field to sort by (e.g., "scheduled_delivery_time") (optional).
        :param dir: Sort direction ("asc" or "desc") (optional).
        :return: Dictionary containing:
                 - messages (list): List of message objects with details
                 - page_number (int): Current page number
                 - page_size (int): Number of items per page
                 - total_pages (int): Total number of pages
        """
        params = {
            "pageNumber": page_number,
            "pageSize": page_size,
            "from": self._format_date(from_date)
        }
        
        if to_date is not None: 
            params["to"] = self._format_date(to_date)
        if sort is not None: 
            params["sort"] = sort
        if dir is not None: 
            params["dir"] = dir
                
        return self._request("GET", "smshistory", params=params)

    def get_recipient_history(self, recipient: str, from_date: Union[datetime, str], 
                              to_date: Optional[Union[datetime, str]] = None, page_number: int = 1, 
                              page_size: int = 50) -> Dict[str, Any]:
        """
        Get sent SMS history for a specific recipient.
        
        :param recipient: The phone number of the recipient.
        :param from_date: Start date (datetime or YYYYMMDDHHmmSS).
        :param to_date: End date (datetime or YYYYMMDDHHmmSS) (optional).
        :param page_number: Page number (default 1).
        :param page_size: Items per page (default 50).
        :return: Dictionary containing:
                 - messages (list): List of message objects sent to this recipient
                 - page_number (int): Current page number
                 - page_size (int): Number of items per page
                 - total_pages (int): Total number of pages
        """
        params = {
            "recipient": recipient,
            "pageNumber": page_number,
            "pageSize": page_size,
            "from": self._format_date(from_date)
        }
        if to_date is not None: 
            params["to"] = self._format_date(to_date)
        return self._request("GET", "rcptHistory", params=params)

    def get_rich_sms_statistics(self, order_id: str) -> Dict[str, Any]:
        """
        Get statistics for a Rich SMS.
        
        :param order_id: The Order ID of the Rich SMS.
        :return: Dictionary containing Rich SMS statistics:
                 - clicks (int): Number of clicks on links
                 - unique_clicks (int): Number of unique clicks
                 - landing_page_views (int): Number of landing page views
        """
        return self._request("GET", "smsrich/statistics", params={"order_id": order_id})

    def get_message_state(self, order_id: str) -> Dict[str, Any]:
        """
        Get the state of a sent message by Order ID.
        
        :param order_id: The Order ID of the message.
        :return: Dictionary containing:
                 - status (str): Message status (WAITING, SENT, DELIVERED, FAILED, etc.)
                 - recipient (str): Recipient phone number
                 - sent_date (str): Date/time when message was sent
        """
        return self._request("GET", f"sms/{order_id}")




