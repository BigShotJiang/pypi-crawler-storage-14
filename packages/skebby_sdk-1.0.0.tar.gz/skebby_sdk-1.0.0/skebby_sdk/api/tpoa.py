from typing import Dict, Any, Optional
from .base import BaseApi

class TpoaApi(BaseApi):
    def create_alias(self, alias: str, company_name: Optional[str] = None, contact_name: Optional[str] = None, 
                     contact_surname: Optional[str] = None, cod_fiscale: Optional[str] = None, 
                     vat_number: Optional[str] = None, contact_address: Optional[str] = None, 
                     contact_city: Optional[str] = None, contact_pcode: Optional[str] = None, 
                     contact_type: Optional[str] = None, contact_info: Optional[str] = None, 
                     **kwargs: Any) -> Dict[str, Any]:
        """
        Create a new TPOA alias.
        
        :param alias: The alias string (max 11 chars for alphanumeric).
        :param company_name: Company name (optional).
        :param contact_name: Contact first name (optional).
        :param contact_surname: Contact surname (optional).
        :param cod_fiscale: Fiscal code (optional).
        :param vat_number: VAT number (optional).
        :param contact_address: Contact address (optional).
        :param contact_city: Contact city (optional).
        :param contact_pcode: Contact postal code (optional).
        :param contact_type: Contact type, e.g., 'WEB', 'PEC' (optional).
        :param contact_info: Contact info, e.g., website or email (optional).
        :param kwargs: Additional fields.
        :return: Dictionary containing the created alias:
                 - id (int): Alias ID
                 - alias (str): Alias name
                 - status (str): Approval status
                 - company-name (str): Company name
        """
        alias_data = {"alias": alias}
        
        # Add optional fields with proper hyphenated keys as per API spec
        if company_name is not None:
            alias_data["company-name"] = company_name
        if contact_name is not None:
            alias_data["contact-name"] = contact_name
        if contact_surname is not None:
            alias_data["contact-surname"] = contact_surname
        if cod_fiscale is not None:
            alias_data["cod-fiscale"] = cod_fiscale
        if vat_number is not None:
            alias_data["vat-number"] = vat_number
        if contact_address is not None:
            alias_data["contact-address"] = contact_address
        if contact_city is not None:
            alias_data["contact-city"] = contact_city
        if contact_pcode is not None:
            alias_data["contact-pcode"] = contact_pcode
        if contact_type is not None:
            alias_data["contact-type"] = contact_type
        if contact_info is not None:
            alias_data["contact-info"] = contact_info
        
        alias_data.update(kwargs)
        
        payload = {"alias": alias_data}
        
        return self._request("POST", "alias", data=payload)

    def get_aliases(self, page_number: Optional[int] = None, page_size: Optional[int] = None, 
                    hide_not_approved: Optional[bool] = None) -> Dict[str, Any]:
        """
        Get all aliases with optional pagination and filtering.
        
        :param page_number: Page number for pagination (optional).
        :param page_size: Page size for pagination (optional).
        :param hide_not_approved: Hide not approved aliases (optional, boolean).
        :return: Dictionary containing:
                 - aliases (list): List of alias objects
                 - page_number (int): Current page number
                 - page_size (int): Number of items per page
        """
        params = {}
        if page_number is not None:
            params["pageNumber"] = page_number
        if page_size is not None:
            params["pageSize"] = page_size
        if hide_not_approved is not None:
            params["hide-not-approved"] = hide_not_approved
        
        return self._request("GET", "alias", params=params)

    def get_alias(self, alias_id: int) -> Dict[str, Any]:
        """
        Get a specific alias by ID.
        
        :param alias_id: The ID of the alias to retrieve.
        :return: A dictionary containing the alias details.
        """
        return self._request("GET", f"alias/{alias_id}")

    def delete_alias(self, alias_id: int) -> Dict[str, Any]:
        """
        Delete an alias by ID.
        
        :param alias_id: The ID of the alias to delete.
        :return: API response confirming deletion.
        """
        return self._request("DELETE", f"alias/{alias_id}")
