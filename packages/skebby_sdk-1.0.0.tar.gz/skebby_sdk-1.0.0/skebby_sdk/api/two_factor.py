from typing import Dict, Any, Optional
from .base import BaseApi

class TwoFactorApi(BaseApi):
    def request_pin(self, recipient: str, sender: Optional[str] = None, message_type: str = "GP", 
                    **kwargs: Any) -> Dict[str, Any]:
        """
        Request a 2FA PIN.
        
        :param recipient: The phone number to send the PIN to (required).
        :param sender: Sender alias (optional).
        :param message_type: Type of message - "GP" (default), "TI", "SI", or "AD" (optional).
        :param kwargs: Other optional fields (e.g., 'text' to customize the message).
        :return: Dictionary containing:
                 - result (str): "OK" on success
                 - pin_length (int): Length of the generated PIN
        """
        payload = {"recipient": recipient}
        
        if sender is not None:
            payload["sender"] = sender
        if message_type is not None:
            payload["message-type"] = message_type
        
        payload.update(kwargs)
        return self._request("POST", "2fa/request", data=payload)

    def verify_pin(self, recipient: str, pin: str) -> Dict[str, Any]:
        """
        Verify a 2FA PIN.
        
        :param recipient: The phone number associated with the PIN (required).
        :param pin: The PIN code to verify (required).
        :return: Dictionary containing:
                 - result (str): "success" if PIN is valid, "error" otherwise
        """
        payload = {
            "recipient": recipient,
            "pin": pin
        }
        return self._request("POST", "2fa/verify", data=payload)

