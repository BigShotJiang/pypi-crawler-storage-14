from typing import Dict, Any, Optional, Union, List
from datetime import datetime
from .base import BaseApi

class ReceivedApi(BaseApi):
    def get_new_messages(self, limit: Optional[int] = None, sim_id: Optional[str] = None) -> List[Dict[str, Any]]:
        """
        Get new received messages (unread).
        
        :param limit: Maximum number of messages to retrieve (optional).
        :param sim_id: Filter by SIM ID (optional).
        :return: List of message dictionaries containing:
                 - id (int): Message ID
                 - phoneNumber (str): Sender phone number
                 - text (str): Message text
                 - receivedDate (str): Date/time when message was received
                 - sender (str): Original sender/alias
        """
        params = {}
        if limit is not None: 
            params["limit"] = limit
        
        endpoint = "newsrsmsmessage"
        if sim_id is not None:
            endpoint = f"{endpoint}/{sim_id}"
            
        return self._request("GET", endpoint, params=params)

    def get_messages(self, from_date: Union[datetime, str], to_date: Optional[Union[datetime, str]] = None, 
                     page_number: int = 1, page_size: int = 50, sim_id: Optional[str] = None) -> Dict[str, Any]:
        """
        Get received SMS history (SIM).
        
        :param from_date: Start date (datetime or YYYYMMDDHHmmSS).
        :param to_date: End date (datetime or YYYYMMDDHHmmSS) (optional).
        :param page_number: Page number (default 1).
        :param page_size: Items per page (default 50).
        :param sim_id: Filter by SIM ID - if provided, uses path parameter (optional).
        :return: Dictionary containing:
                 - messages (list): List of message objects
                 - page_number (int): Current page number
                 - page_size (int): Number of items per page
        """
        params = {
            "from": self._format_date(from_date),
            "pageNumber": page_number,
            "pageSize": page_size
        }
        
        if to_date is not None: 
            params["to"] = self._format_date(to_date)
        
        endpoint = "srsmshistory"
        if sim_id is not None:
            endpoint = f"{endpoint}/{sim_id}"
        
        return self._request("GET", endpoint, params=params)

    def get_messages_after(self, sim_id: str, message_id: str, limit: Optional[int] = None) -> Dict[str, Any]:
        """
        Get the received SMS messages after a specified message.
        
        :param sim_id: The SIM ID to query.
        :param message_id: The message ID to start from.
        :param limit: Maximum number of messages to retrieve (optional).
        :return: Dictionary containing:
                 - messages (list): List of message objects after the specified message
                 - page_number (int): Current page number
                 - page_size (int): Number of items per page
        """
        params = {}
        if limit is not None:
            params["limit"] = limit
        
        endpoint = f"srsmshistory/{sim_id}/{message_id}"
        return self._request("GET", endpoint, params=params)

    def get_mo_messages(self, from_date: Optional[Union[datetime, str]] = None, 
                        to_date: Optional[Union[datetime, str]] = None, page_number: int = 1, 
                        page_size: int = 50, message_type: Optional[str] = None) -> Dict[str, Any]:
        """
        Get MO received messages (Keyword/Shortcode).
        
        :param from_date: Start date (datetime or YYYYMMDDHHmmSS) (optional).
        :param to_date: End date (datetime or YYYYMMDDHHmmSS) (optional).
        :param page_number: Page number (default 1).
        :param page_size: Items per page (default 50).
        :param message_type: Filter by message type (optional).
        :return: Dictionary containing:
                 - messages (list): List of MO message objects
                 - page_number (int): Current page number
                 - page_size (int): Number of items per page
        """
        params = {
            "pageNumber": page_number,
            "pageSize": page_size
        }
        
        if from_date is not None: 
            params["from"] = self._format_date(from_date)
        if to_date is not None: 
            params["to"] = self._format_date(to_date)
        if message_type is not None: 
            params["type"] = message_type
        
        return self._request("GET", "mosmshistory", params=params)

