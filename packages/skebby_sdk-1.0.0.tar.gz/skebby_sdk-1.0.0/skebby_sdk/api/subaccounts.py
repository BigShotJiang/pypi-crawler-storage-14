from typing import Dict, Any, Optional, List
from .base import BaseApi

class SubaccountsApi(BaseApi):
    def get_subaccounts(self, page_number: int = 1, page_size: int = 50) -> Dict[str, Any]:
        """
        Get the list of subaccounts.
        
        :param page_number: Page number (default 1).
        :param page_size: Items per page (default 50).
        :return: A dictionary containing the list of subaccounts and pagination info.
        """
        params = {
            "pageNumber": page_number,
            "pageSize": page_size
        }
        return self._request("GET", "subaccounts", params=params)

    def create_subaccount(self, login: str, password: str, company: str, name: str, surname: str, 
                          email: str, phone_number: str, **kwargs: Any) -> Dict[str, Any]:
        """
        Create a subaccount.
        
        :param login: Login/username for the subaccount (maps to 'login' in API).
        :param password: Password for the subaccount.
        :param company: Company name (maps to 'company-name' in API).
        :param name: First name.
        :param surname: Last name.
        :param email: Email address.
        :param phone_number: Phone number (maps to 'cell' in API).
        :param kwargs: Other optional fields with hyphenated keys (e.g., 'address', 'city', 'zip-code', 
                       'province', 'phone', 'fax', 'fiscal-code', 'piva', 'invoicing-email', 
                       'credit-eat-mode', 'language', 'use24', 'dfeu', 'superaccount', 
                       'num-cell-for-test-sms', 'id-subaccount-profile').
        :return: A dictionary containing the created subaccount details.
        """
        payload = {
            "login": login,
            "password": password,
            "company-name": company,
            "name": name,
            "surname": surname,
            "email": email,
            "cell": phone_number
        }
        payload.update(kwargs)
        return self._request("POST", "subaccount", data=payload)

    def get_subaccount(self, username: str) -> Dict[str, Any]:
        """
        Get subaccount details.
        
        :param username: The username of the subaccount.
        :return: A dictionary containing the subaccount details.
        """
        return self._request("GET", f"subaccount/{username}")

    def update_subaccount(self, username: str, lock_subaccount: Optional[bool] = None, 
                          **kwargs: Any) -> Dict[str, Any]:
        """
        Edit subaccount.
        
        :param username: The username of the subaccount to update.
        :param lock_subaccount: Optional boolean to lock/unlock the subaccount (query parameter).
        :param kwargs: Fields to update with hyphenated keys (e.g., 'name', 'surname', 'email', 
                       'company-name', 'address', 'city', 'zip-code', 'province', 'phone', 'cell', 
                       'fax', 'fiscal-code', 'piva', 'invoicing-email', 'credit-eat-mode', 
                       'language', 'use24', 'dfeu', 'superaccount', 'num-cell-for-test-sms', 
                       'id-subaccount-profile').
        :return: A dictionary containing the updated subaccount details.
        """
        params = {}
        if lock_subaccount is not None:
            params["lock-subaccount"] = lock_subaccount
        
        return self._request("PUT", f"subaccount/{username}", params=params if params else None, data=kwargs)

    def change_subaccount_webapp_password(self, username: str, password: str) -> Dict[str, Any]:
        """
        Change subaccount WebApp password.
        
        :param username: The username of the subaccount.
        :param password: The new password.
        :return: API response confirming password change.
        """
        payload = {"password": password}
        return self._request("POST", f"subaccount/{username}/changepwd", data=payload)

    def change_subaccount_api_password(self, username: str, password: str) -> Dict[str, Any]:
        """
        Change subaccount API password.
        
        :param username: The username of the subaccount.
        :param password: The new password.
        :return: API response confirming password change.
        """
        payload = {"password": password}
        return self._request("POST", f"subaccount/{username}/changepwd/api", data=payload)

    def get_subaccount_available_credits(self, username: str) -> Dict[str, Any]:
        """
        Get subaccount available credits.
        
        :param username: The username of the subaccount.
        :return: A dictionary containing the available credits.
        """
        return self._request("GET", f"subaccount/{username}/credit")

    def get_subaccount_purchases(self, username: str, page_number: int = 1, page_size: int = 50) -> Dict[str, Any]:
        """
        Get a subaccount's purchases.
        
        :param username: The username of the subaccount.
        :param page_number: Page number (default 1).
        :param page_size: Items per page (default 50).
        :return: A dictionary containing the purchases.
        """
        params = {
            "pageNumber": page_number,
            "pageSize": page_size
        }
        return self._request("GET", f"subaccount/{username}/purchase", params=params)

    def create_subaccount_purchase(self, username: str, purchase_type: str, amount: int, 
                                    method: str = "credit_card", **kwargs: Any) -> Dict[str, Any]:
        """
        Create a subaccount purchase.
        
        :param username: The username of the subaccount.
        :param purchase_type: Type of purchase (e.g., "SMS_GP", "SMS_TI").
        :param amount: Amount to purchase.
        :param method: Payment method (default "credit_card").
        :param kwargs: Other optional fields.
        :return: A dictionary containing the purchase details.
        """
        payload = {
            "type": purchase_type,
            "amount": amount,
            "method": method
        }
        payload.update(kwargs)
        return self._request("POST", f"subaccount/{username}/purchase", data=payload)

    def delete_subaccount_purchase(self, username: str, purchase_id: int) -> Dict[str, Any]:
        """
        Delete a subaccount's purchase.
        
        :param username: The username of the subaccount.
        :param purchase_id: The ID of the purchase to delete.
        :return: API response confirming deletion.
        """
        return self._request("DELETE", f"subaccount/{username}/purchase/{purchase_id}")

    def create_subaccount_profile(self, name: str, **kwargs: Any) -> Dict[str, Any]:
        """
        Create a subaccount profile.
        
        :param name: Name of the profile.
        :param kwargs: Other optional fields (e.g., 'isDefault', 'sharedGroups', 'sharedTemplates', 
                       'sharedBlacklists', 'enabledServices', 'enabledSMSQualities').
        :return: A dictionary containing the created profile.
        """
        payload = {"name": name}
        payload.update(kwargs)
        return self._request("POST", "subaccount/profile", data=payload)

    def update_subaccount_profile(self, profile_id: int, **kwargs: Any) -> Dict[str, Any]:
        """
        Update a subaccount profile.
        
        Note: The official API uses POST method for updates, not PUT.
        
        :param profile_id: The ID of the profile to update.
        :param kwargs: Fields to update (e.g., 'name', 'isDefault', 'sharedGroups', 'sharedTemplates', 
                       'sharedBlacklists', 'enabledServices', 'enabledSMSQualities').
        :return: A dictionary containing the updated profile.
        """
        return self._request("POST", f"subaccount/profile/{profile_id}", data=kwargs)

    def get_subaccount_profiles(self) -> List[Dict[str, Any]]:
        """
        Get all subaccount profiles.
        
        :return: A list of subaccount profiles.
        """
        return self._request("GET", "subaccount/profile")

    def get_subaccount_profile(self, profile_id: int) -> Dict[str, Any]:
        """
        Get a specific subaccount profile.
        
        :param profile_id: The ID of the profile.
        :return: A dictionary containing the profile details.
        """
        return self._request("GET", f"subaccount/profile/{profile_id}")

    def get_activable_services(self) -> Dict[str, Any]:
        """
        Get activable services.
        
        :return: A dictionary containing activable services.
        """
        return self._request("GET", "subaccount/activableservices")

    def remove_subaccount_profile(self, profile_id: int) -> Dict[str, Any]:
        """
        Remove a subaccount profile.
        
        :param profile_id: The ID of the profile to remove.
        :return: API response confirming deletion.
        """
        return self._request("DELETE", f"subaccount/profile/{profile_id}")
