class SkebbyException(Exception):
    """Base exception for Skebby SDK"""
    pass

class SkebbyAuthException(SkebbyException):
    """Raised when authentication fails"""
    pass

class SkebbyRequestException(SkebbyException):
    """Raised when an API request fails"""
    def __init__(self, message, error_code=None, response_body=None):
        super().__init__(message)
        self.error_code = error_code
        self.response_body = response_body

class SkebbyValidationException(SkebbyRequestException):
    """Raised when the request is invalid (400)"""
    pass

class SkebbyNotFoundException(SkebbyRequestException):
    """Raised when the resource is not found (404)"""
    pass

class SkebbyRateLimitException(SkebbyRequestException):
    """Raised when the rate limit is exceeded (429)"""
    pass

class SkebbyServerException(SkebbyRequestException):
    """Raised when the server encounters an error (5xx)"""
    pass
