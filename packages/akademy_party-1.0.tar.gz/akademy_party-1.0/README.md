# 🏫 SAGE Education - Gestão Institucional / ERP

**Versão:** 1.0  
**Módulo:** SAGE Education  
**Desenvolvedor:** Zacarias Juliano Capingala *(Homem Marketing)*  
**Data:** 21/11/2025

---

## 📘 Sobre o Projeto

**O SAGE Education** é um projeto ***livre e gratuito*** para ***educadores, instituições de ensino e governos***.
Ele fornece a funcionalidade de **Sistema de Gestão Académica (SGA), Sistema de Gestão Escolar (SGE) e Sistema de Informação Educacional (SIE)**.
O seu design ***modular, escalável e seguro*** permite que seja implementado em muitos cenários diferentes: desde **pequenas escolas** e **centros de formação** até **grandes sistemas nacionais de educação pública**.

O SAGE Education conta com uma comunidade crescente, comprometida e amigável que traz o melhor dos campos das ***ciências da educação, pedagogia, tecnologia educacional e ciências da computação***.
Não importa onde no mundo você vive, somos apaixonados por manter a educação e a tecnologia educacional como um direito humano inegociável.
Esperamos que você considere o **SAGE Education** motivador e inspirador, e estamos ansiosos para tê-lo como parte da equipe.

---

## ⚙️ Módulo Akademy Party

O **Akademy Party (Gestão de Entidades)** é um módulo complementar responsável **expandir as funcionalidades** do módulo de **Gestão de Entidades**, oferecendo ferramentas avançadas para administração entidades dentro da organização.  

---


## 🌐 Homepage

**Website:** [comunidadedosaber.ao](https://comunidadedosaber.ao)  
**E-mail:** [comercial@comunidadedosaber.ao](mailto:comercial@comunidadedosaber.ao)

---

## 💬 Suporte Técnico

Caso encontre erros ou deseje obter suporte técnico, entre em contato pelos canais abaixo:

- 📧 **E-mail:** [suporte@comunidadedosaber.ao](mailto:suporte@comunidadedosaber.ao)
- 💬 **WhatsApp:** [+244 926 585 345](https://wa.me/244926585345)

