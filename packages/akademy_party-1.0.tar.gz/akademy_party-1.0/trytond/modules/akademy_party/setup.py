entry_points="""
    [trytond.modules]
    akademy_party = trytond.modules.akademy_party
    """

