
# from vwsfriend.util.location_util import locationFromLatLon

def test_locationFromLatLon():
    # location = locationFromLatLon(latitude=53.60853453781239, longitude=10.19093520255688)
    # print (location)
    # assert location is not None

    # location = locationFromLatLon(latitude=53.60957750612437, longitude=10.184564007135274)
    # print (location)
    # assert location is not None

    # location = locationFromLatLon(latitude=53.61014, longitude=10.18435)
    # print (location)
    # assert location is not None

    # location = locationFromLatLon(latitude=53.66243, longitude=10.16044)
    # print (location)
    # assert location is not None

    # location = locationFromLatLon(latitude=53.65190, longitude=10.16269)
    # print (location)
    # assert location is not None
    assert True
