"""initial

Revision ID: 90636c798967
Revises: 
Create Date: 2021-09-06 14:06:46.975495

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '90636c798967'
down_revision = None
branch_labels = None
depends_on = None


def upgrade():
    pass


def downgrade():
    pass
