"""Analysis functionality for EPS data."""

from .sp500 import SP500

__all__ = [
    'SP500',
]

