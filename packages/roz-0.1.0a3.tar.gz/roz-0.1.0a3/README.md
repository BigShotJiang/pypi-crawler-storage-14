# Roz

Agentic Coding

> Roz: What if I known Industry Standard Practices, can I code better than human?