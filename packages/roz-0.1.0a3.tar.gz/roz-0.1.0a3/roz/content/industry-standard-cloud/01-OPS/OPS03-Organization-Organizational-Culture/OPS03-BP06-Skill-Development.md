# OPS03-BP06: Team members are enabled and encouraged to maintain and grow their skill sets

## Description

Hỗ trợ team phát triển kỹ năng.

## Implementation Guidance

- Training budget allocated per person
- Learning time built into schedules
- Certification support
- Conference attendance encouraged
- Internal knowledge sharing sessions

## Risk Level

Medium - Skill stagnation leads to technical debt and turnover.
