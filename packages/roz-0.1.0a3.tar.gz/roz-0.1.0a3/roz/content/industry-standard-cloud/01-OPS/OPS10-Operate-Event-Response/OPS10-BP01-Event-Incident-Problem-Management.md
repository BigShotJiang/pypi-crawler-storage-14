# OPS10-BP01: Use a process for event, incident, and problem management

## Description

Có process rõ ràng cho event management.

## Implementation Guidance

- ITIL-based incident management
- Clear incident declaration criteria
- Incident commander role
- War room procedures
- Problem management for root causes

## Risk Level

High - Ad-hoc incident response causes longer outages.
