# OPS07-BP01: Ensure personnel capability

## Description

Team có đủ skills và training.

## Implementation Guidance

- Skills matrix for team
- Training plans for gaps
- Cross-training for coverage
- Certification paths defined
- Regular skills assessments

## Risk Level

High - Untrained personnel cause longer incidents and mistakes.
