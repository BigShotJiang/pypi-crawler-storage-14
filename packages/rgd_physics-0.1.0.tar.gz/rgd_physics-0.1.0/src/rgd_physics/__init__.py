from .core.engine import PhysicsEngine
from .core.presets import Presets
from .core.exceptions import CausalityBreak

# Espone gli Aioni principali direttamente dalla root
from .chronon.aions.light import Aion128
from .chronon.aions.standard import Aion512
from .chronon.aions.heavy import Aion4096
from .chronon.aions.synthetic import SyntheticAion, AionV

__version__ = "0.1.0"  # <--- MODIFICATO QUI

__all__ = [
    "PhysicsEngine", 
    "Presets", 
    "CausalityBreak",
    "Aion128", "Aion512", "Aion4096", "SyntheticAion", "AionV"
]