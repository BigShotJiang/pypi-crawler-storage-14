"""
RGD-PHYSICS :: CONTINUOUS GEOMETRY (NEWTONIAN KERNEL)
Implements Spacetime as a Smooth Euclidean Manifold.
Used for 'Lean Mode' and legacy industrial robotics.
"""
import math
from ..core.interfaces import GeometryKernel, Microsecond
from ..chronon.interfaces import ChrononProtocol
from ..core.exceptions import CausalityBreak

class ContinuousGeometry(GeometryKernel):
    """
    The Newton Standard Kernel.
    Treats spacetime as continuous R^3 + Time.
    Ignores Quantum Noise / Planck Scale checks.
    """
    
    def check_structural_integrity(self, t0: ChrononProtocol, t1: ChrononProtocol, dt: Microsecond) -> None:
        # 1. DECODE SPEED LIMIT (If present)
        delta_raw = t0.laws_encoded
        mantissa = delta_raw & 0x1FFFFF
        
        # If mantissa is 0, we assume infinite speed (Debug/God Mode)
        if mantissa == 0:
            return

        c_limit = float(mantissa)

        # 2. CALCULATE EUCLIDEAN DISTANCE (3D only)
        # In Continuous mode, we ignore the 'w' (probability) dimension.
        x0, y0, z0, _ = t0.metric_coordinates
        x1, y1, z1, _ = t1.metric_coordinates
        
        distance = math.sqrt(
            (x1 - x0)**2 + (y1 - y0)**2 + (z1 - z0)**2
        )
        
        # 3. CHECK KINEMATIC LIMIT
        # v = d/t
        if dt <= 0: return # Instantaneous jumps allowed in Debug mode if dt=0
        
        velocity = distance / dt
        
        if velocity > c_limit:
            raise CausalityBreak(
                f"NEWTONIAN VIOLATION: Velocity {velocity:.2f} > Limit {c_limit:.2f}"
            )