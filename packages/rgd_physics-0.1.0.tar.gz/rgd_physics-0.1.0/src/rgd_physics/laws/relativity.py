"""
RGD-PHYSICS :: RELATIVITY LAW
Implements Computational Time Dilation.
Maps CPU Load to Relativistic Gamma Factor.
"""
import math
from ..core.interfaces import PhysicsLaw, Microsecond, PhysicsReport
from ..chronon.interfaces import ChrononProtocol

class Relativity(PhysicsLaw):
    """
    Audits the Time Dilation caused by high information density.
    Gravity = Lag.
    """
    
    @property
    def name(self) -> str:
        return "relativity"

    def audit(self, t0: ChrononProtocol, t1: ChrononProtocol, dt: Microsecond) -> PhysicsReport:
        """
        Calculates the Gamma Factor based on Cognitive Load.
        """
        # 1. GET LOCAL SPEED LIMIT (c)
        # Decoded from the T0 delta laws. Represents max throughput.
        delta_raw = t0.laws_encoded
        mantissa = delta_raw & 0x1FFFFF
        # Default c=1000 if not specified
        c_limit = float(mantissa) if mantissa > 0 else 1000.0
        
        # 2. ESTIMATE 'VELOCITY' (Cognitive Load)
        # In this synthetic physics, 'Velocity' is the density of the payload processing.
        # We use a modulo of the payload hash to simulate load variation.
        current_load = float(t1.payload_hash % int(c_limit))
        
        # 3. CALCULATE LORENTZ FACTOR (Gamma)
        # gamma = 1 / sqrt(1 - v^2/c^2)
        ratio = current_load / c_limit
        
        # Safety clamp to avoid division by zero at Event Horizon
        if ratio >= 0.99:
            gamma = 100.0 # Time is effectively frozen (Lag Infinite)
        else:
            gamma = 1.0 / math.sqrt(1 - ratio**2)
            
        return {
            "gamma_factor": gamma,
            "experienced_time": dt / gamma, # Time perceived by the robot
            "load_ratio": ratio
        }