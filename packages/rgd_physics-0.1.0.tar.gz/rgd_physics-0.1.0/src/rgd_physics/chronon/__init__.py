from .isotopes.v512 import T512
# from .isotopes.v128 import T128 (Quando lo faremo)
# from .isotopes.v4096 import T4096 (Quando lo faremo)

__all__ = ["T512"]