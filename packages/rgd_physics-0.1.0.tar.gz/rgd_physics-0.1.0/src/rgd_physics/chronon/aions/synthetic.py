"""
RGD-PHYSICS :: SYNTHETIC AION (Experimental)
Allows the creation of non-standard Aions (e.g., Aion-256, Aion-768).
Performance Note: These are NOT cache-aligned. Use for research only.
"""
from dataclasses import dataclass
from typing import Tuple, Any, Type

@dataclass(frozen=True)
class SyntheticAion:
    """
    Base class for custom Aions.
    Implements ChrononProtocol dynamically for arbitrary data.
    Warning: Not optimized for zero-copy serialization.
    """
    # Standard header is mandatory for Physics Engine
    anchor: int
    meta_data: int
    
    # Flexible internal storage (unpacked)
    _metric: Tuple[float, float, float, float]
    _payload: Any 

    @property
    def laws_encoded(self) -> int:
        return (self.meta_data >> 32) & 0xFFFFFFFF

    @property
    def metric_coordinates(self) -> Tuple[float, float, float, float]:
        return self._metric

    @property
    def payload_hash(self) -> int:
        """Safe hashing for arbitrary python objects."""
        try:
            return hash(self._payload)
        except TypeError:
            # Fallback for unhashable types (like dicts/lists)
            return hash(str(self._payload))

    def __repr__(self):
        return f"<SyntheticAion anchor={self.anchor} payload={str(self._payload)[:20]}...>"

def AionV(bits: int) -> Type[SyntheticAion]:
    """
    Factory to generate named classes for documentation/typing.
    Usage: 
        MyAion = AionV(256)
        instance = MyAion(...)
    """
    class_name = f'Aion{bits}'
    # Creazione dinamica della classe
    new_class = type(class_name, (SyntheticAion,), {
        '__doc__': f'Custom Synthetic Aion with {bits}-bit theoretical capacity.',
        '__module__': __name__
    })
    return new_class