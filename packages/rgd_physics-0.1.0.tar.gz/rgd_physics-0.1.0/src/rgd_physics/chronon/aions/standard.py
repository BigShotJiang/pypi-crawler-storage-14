"""
RGD-PHYSICS :: AION-512 (Standard Variant)
The standard unit of Vital Time. 64-Byte Cache-Aligned.
"""
import struct
from dataclasses import dataclass
from typing import Tuple

@dataclass(frozen=True, slots=True)
class Aion512:
    """
    The Standard Aion.
    Represents a specific configuration of the Chronon
    with a 'vital capacity' of 64 Bytes.

    Structure (8 x 64-bit Integers):
    [0] Anchor (Time + ID)
    [1] Metric Low (X, Y)
    [2] Metric High (Z, W)
    [3] Meta Data (Laws + Flags)
    [4-7] Payload (256-bit Vital State)
    """
    anchor: int
    metric_lo: int
    metric_hi: int
    meta_data: int
    
    # The Aion contains the "life" (payload)
    payload_0: int
    payload_1: int
    payload_2: int
    payload_3: int

    @property
    def aion_class(self) -> str:
        return "STANDARD (512-bit)"

    # --- PROTOCOL IMPLEMENTATION (ChrononProtocol) ---

    @property
    def laws_encoded(self) -> int:
        """
        Extracts the upper 32 bits of Meta Data.
        Contains the Delta Limit (Local Speed of Light).
        """
        return (self.meta_data >> 32) & 0xFFFFFFFF

    @property
    def metric_coordinates(self) -> Tuple[float, float, float, float]:
        """
        Unpacks compressed 128-bit coordinates (Metric Low/High) into 4 floats.
        Assumes fixed-point 32.32 packing or float32 packing.
        Simplified conversion used here for performance demonstration.
        """
        # Extract four 32-bit values from the two 64-bit integers
        x_int = (self.metric_lo >> 32) & 0xFFFFFFFF
        y_int = self.metric_lo & 0xFFFFFFFF
        z_int = (self.metric_hi >> 32) & 0xFFFFFFFF
        w_int = self.metric_hi & 0xFFFFFFFF
        
        # Mock Conversion: Treating them as scaled integers
        scale = 1000.0
        return (x_int/scale, y_int/scale, z_int/scale, w_int/scale)

    @property
    def payload_hash(self) -> int:
        """
        Calculates a fast hash of the vital state for thermodynamic auditing.
        Uses XOR for maximum speed (CPU cycle efficient).
        """
        return self.payload_0 ^ self.payload_1 ^ self.payload_2 ^ self.payload_3

    # --- ZERO-COPY SERIALIZATION ---
    
    # Struct Format: 8 Unsigned Long Longs (8 bytes * 8 = 64 bytes)
    # ! = Network Endian (Big Endian)
    # Q = unsigned long long (8 bytes)
    _STRUCT = struct.Struct('!8Q')

    def to_bytes(self) -> bytes:
        """Serializes the Aion into a raw 64-byte buffer."""
        return self._STRUCT.pack(
            self.anchor,
            self.metric_lo, self.metric_hi,
            self.meta_data,
            self.payload_0, self.payload_1, self.payload_2, self.payload_3
        )

    @classmethod
    def from_bytes(cls, buffer: bytes) -> 'Aion512':
        """Reconstructs the Aion from a raw buffer."""
        unpacked = cls._STRUCT.unpack(buffer)
        return cls(*unpacked)