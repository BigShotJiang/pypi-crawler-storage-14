"""
RGD-PHYSICS :: AION REGISTRY
Exposes the Periodic Table of Chronons.
"""
from .light import Aion128       # The Spark (16 Byte)
from .standard import Aion512    # The Breath (64 Byte)
from .heavy import Aion4096      # The Soul (512 Byte)
from .synthetic import SyntheticAion, AionV # Experimental

__all__ = [
    "Aion128", 
    "Aion512", 
    "Aion4096", 
    "SyntheticAion", 
    "AionV"
]