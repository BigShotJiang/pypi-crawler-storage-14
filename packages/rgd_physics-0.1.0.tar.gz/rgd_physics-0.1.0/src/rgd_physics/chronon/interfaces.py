"""
RGD-PHYSICS :: CHRONON PROTOCOL
Defines the universal contract for Time Atoms.
Any class implementing this protocol can be simulated by the RGD Engine.
"""
from typing import Protocol, runtime_checkable, Tuple

@runtime_checkable
class ChrononProtocol(Protocol):
    """
    The Interface that ALL Aions (Light, Standard, Heavy, Synthetic) must implement.
    The Physics Engine uses this protocol to interact with data without 
    knowing the specific implementation details (duck typing).
    """
    
    @property
    def anchor(self) -> int:
        """
        The Anchor Vertex (64-bit).
        Contains Universal Monotonic Timestamp + Entity ID.
        """
        ...
    
    @property
    def metric_coordinates(self) -> Tuple[float, float, float, float]:
        """
        Returns unpacked coordinates (x, y, z, w).
        - x, y, z: Spatial coordinates in the Lattice.
        - w: Probability Branch / Phase (for CFT coherence).
        """
        ...
    
    @property
    def laws_encoded(self) -> int:
        """
        The Delta Vertex (32-bit).
        Contains encoded local physics constants:
        - Local Speed of Light (c)
        - Synthetic Planck Scale (Resolution)
        """
        ...

    @property
    def payload_hash(self) -> int:
        """
        A numeric hash of the Vital Payload.
        Used by the Thermodynamics Law to calculate Entropy Generation
        without needing to read the full payload content.
        """
        ...