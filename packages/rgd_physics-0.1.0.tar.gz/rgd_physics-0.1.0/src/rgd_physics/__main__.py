"""
RGD-PHYSICS :: CLI ENTRY POINT
Allows running 'python -m rgd_physics' to demo the engine.
"""
import time
import sys
import random
from .core.presets import Presets
from .chronon.aions import Aion4096

# ANSI Colors for Terminal Coolness
CYAN = "\033[96m"
GREEN = "\033[92m"
YELLOW = "\033[93m"
RED = "\033[91m"
RESET = "\033[0m"
BOLD = "\033[1m"

def type_writer(text, delay=0.02):
    for char in text:
        sys.stdout.write(char)
        sys.stdout.flush()
        time.sleep(delay)
    print("")

def demo():
    print(f"{BOLD}{CYAN}")
    print(r"""
   ____  __________  ____  __  ____  _______ _________
  / __ \/ ____/ __ \/ __ \/ / / /\ \/ / ___//  _/ ___/
 / /_/ / / __/ / / / /_/ / /_/ /  \  /\__ \ / // /    
/ _, _/ /_/ / /_/ / ____/ __  /   / /___/ // // /___  
/_/ |_|\____/_____/_/   /_/ /_/   /_//____/___/\____/  
                                        KERNEL v9.5
    """)
    print(f"{RESET}")
    
    type_writer(f"[{GREEN}SYSTEM{RESET}] Initializing Chronon Field Theory Kernel...", 0.05)
    time.sleep(0.5)
    
    # 1. SETUP ENGINE
    print(f"[{YELLOW}INIT{RESET}] Loading Lattice Geometry (Planck Scale)... OK")
    print(f"[{YELLOW}INIT{RESET}] Activating Thermodynamics Law... OK")
    print(f"[{YELLOW}INIT{RESET}] Activating Relativistic Constraints... OK")
    
    engine = Presets.quantum_simulation()
    engine.boot()
    print("")

    # 2. CREATE ENTITY
    type_writer(f"[{CYAN}ENTITY{RESET}] Injecting Aion-4096 (The Soul) into the field...", 0.03)
    t0 = Aion4096(
        anchor=1000, 
        metric_lo=0, metric_hi=0, 
        meta_data=0xA000F, 
        p_data=tuple([random.randint(0, 2**64-1) for _ in range(60)])
    )
    time.sleep(0.5)

    # 3. RUN SIMULATION LOOP
    print(f"\n{BOLD}--- STARTING CAUSALITY STREAM ---{RESET}\n")
    
    for i in range(1, 6):
        # Simulate a movement
        # Increasing entropy slightly each step
        new_payload = list(t0.p_data)
        new_payload[0] = new_payload[0] ^ random.getrandbits(64) # Change state
        
        t1 = Aion4096(
            anchor=1000 + i,
            metric_lo=i * 100, # Moving in space
            metric_hi=0,
            meta_data=0xA000F,
            p_data=tuple(new_payload)
        )

        try:
            # Validate Step
            dt = 0.01
            report = engine.validate_step(t0, t1, dt=dt)
            
            # Extract Telemetry
            gamma = report.get('relativity', {}).get('gamma_factor', 1.0)
            heat = report.get('thermodynamics', {}).get('heat_rate', 0.0)
            
            print(f"FRAME {1000+i} | "
                  f"Δt: {dt}s | "
                  f"GAMMA: {GREEN}{gamma:.4f}{RESET} | "
                  f"ENTROPY: {RED}{heat:.2f} J/K{RESET} | "
                  f"STATUS: {GREEN}COHERENT{RESET}")
            
            t0 = t1 # Advance time
            time.sleep(0.2)
            
        except Exception as e:
            print(f"FRAME {1000+i} | STATUS: {RED}CRITICAL FAILURE{RESET} ({e})")
            break

    print(f"\n{CYAN}[SYSTEM] Simulation Halted. Reality integrity is 100%.{RESET}")

if __name__ == "__main__":
    demo()