"""
RGD-PHYSICS :: PRESETS
Ready-to-use Universe Configurations.
"""
from .engine import PhysicsEngine

# Forward imports (assuming standard structure)
from ..geometry.discrete import DiscreteGeometry
from ..geometry.continuous import ContinuousGeometry
from ..dynamics.particle import ParticleModel
from ..dynamics.string import StringModel
from ..laws.thermodynamics import Thermodynamics
from ..laws.relativity import Relativity
from ..laws.coherence import Coherence

class Presets:
    """Factory for standard engine configurations."""

    @staticmethod
    def lean() -> PhysicsEngine:
        """
        Returns a Newtonian, Particle-based engine.
        Fast, simple, no overhead. Ideal for Industrial Robotics.
        """
        return PhysicsEngine(
            kernel=ContinuousGeometry(),
            model=ParticleModel()
        )

    @staticmethod
    def quantum_simulation() -> PhysicsEngine:
        """
        Returns the full CFT suite (v9.5 Standard):
        - Lattice Geometry (Planck Scale)
        - String Dynamics (Resonance)
        - Laws: Thermodynamics + Relativity + Coherence
        Ideal for AGI and Bio-Heuristic Layers.
        """
        engine = PhysicsEngine(
            kernel=DiscreteGeometry(),
            model=StringModel()
        )
        engine.enable_law(Thermodynamics())
        engine.enable_law(Relativity())
        engine.enable_law(Coherence())
        return engine