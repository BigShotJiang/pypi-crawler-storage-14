"""
RGD-PHYSICS :: CORE INTERFACES
The abstract contracts that all physics modules must obey.
"""
from abc import ABC, abstractmethod
from typing import Dict, Any
from ..chronon.interfaces import ChrononProtocol

# Type aliases for semantic clarity
Microsecond = float
PhysicsReport = Dict[str, Any]

class GeometryKernel(ABC):
    """
    Defines the structure of Spacetime (The Board).
    Responsible for checking Metric Validity and Light Cones.
    """
    @abstractmethod
    def check_structural_integrity(self, t0: ChrononProtocol, t1: ChrononProtocol, dt: Microsecond) -> None:
        """
        Validates if the jump from T0 to T1 is geometrically allowed.
        Raises CausalityBreak or QuantumDecoherence.
        """
        pass

class DynamicsModel(ABC):
    """
    Defines the nature of the Entity (The Player).
    Responsible for checking Internal Consistency (Particle, String, Fluid).
    """
    @abstractmethod
    def validate_movement(self, t0: ChrononProtocol, t1: ChrononProtocol, dt: Microsecond) -> None:
        """
        Validates movement style.
        Raises CausalityBreak if the model constraints are violated.
        """
        pass

class PhysicsLaw(ABC):
    """
    Defines Universal Constraints (The Referee).
    Middleware layers that audit the cost of existence.
    """
    @property
    @abstractmethod
    def name(self) -> str:
        """Unique identifier for telemetry reports."""
        pass

    @abstractmethod
    def audit(self, t0: ChrononProtocol, t1: ChrononProtocol, dt: Microsecond) -> PhysicsReport:
        """
        Calculates costs (Entropy, Gamma Factor).
        Returns telemetry data. Raises PhysicsViolation if limits exceeded.
        """
        pass