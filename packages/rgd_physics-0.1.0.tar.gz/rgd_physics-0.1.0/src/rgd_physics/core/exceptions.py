"""
RGD-PHYSICS :: EXCEPTIONS
Standardized Error Protocol for Causality Violations.
"""

class PhysicsViolation(Exception):
    """
    Base class for all RGD physics errors.
    Carries telemetry data to explain WHY the violation occurred.
    """
    def __init__(self, message: str, telemetry: dict = None):
        super().__init__(message)
        self.telemetry = telemetry or {}

class CausalityBreak(PhysicsViolation):
    """
    CRITICAL: Event Horizon Violation.
    Raised when an entity moves faster than light or violates the Causal Vector.
    In v9.5, this usually triggers a Reality Fork.
    """
    pass

class QuantumDecoherence(PhysicsViolation):
    """
    NOISE: Planck Scale Violation.
    Raised when Time Interval (dt) is below the Effective Minimal Time.
    The operation is physically undefined.
    """
    pass

class ThermodynamicLimit(PhysicsViolation):
    """
    THROTTLING: Entropy Overflow.
    Raised when Cognitive Entropy generation exceeds dissipation capacity.
    """
    pass