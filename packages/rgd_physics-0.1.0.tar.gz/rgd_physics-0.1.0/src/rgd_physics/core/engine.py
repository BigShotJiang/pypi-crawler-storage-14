"""
RGD-PHYSICS :: ENGINE KERNEL
The central loop that coordinates Geometry, Dynamics, and Laws.
"""
from typing import List, Dict, Any
from .interfaces import GeometryKernel, DynamicsModel, PhysicsLaw
from ..chronon.interfaces import ChrononProtocol

class PhysicsEngine:
    """
    The Hypervisor of Reality.
    Validates transitions through the pipeline.
    """
    def __init__(self, kernel: GeometryKernel, model: DynamicsModel):
        self.kernel = kernel
        self.model = model
        self._laws: List[PhysicsLaw] = []
        self._booted = False

    def enable_law(self, law: PhysicsLaw) -> None:
        """Activates a middleware constraint."""
        self._laws.append(law)

    def boot(self):
        """Finalizes initialization."""
        self._booted = True
        print(f"[RGD KERNEL] Booted with {type(self.kernel).__name__} + {type(self.model).__name__}")

    def validate_step(self, t0: ChrononProtocol, t1: ChrononProtocol, dt: float) -> Dict[str, Any]:
        """
        The Atomic Validation Loop.
        1. Geometry Check (The Board)
        2. Dynamics Check (The Move)
        3. Laws Audit (The Cost)
        """
        if not self._booted:
            raise RuntimeError("Engine not booted. Call .boot() first.")

        telemetry = {}

        # STEP 1: KERNEL (Hard Constraints)
        self.kernel.check_structural_integrity(t0, t1, dt)
        
        # STEP 2: MODEL (Internal Consistency)
        self.model.validate_movement(t0, t1, dt)
        
        # STEP 3: LAWS (Middleware Audit)
        for law in self._laws:
            # Each law returns a report, or raises an Exception
            report = law.audit(t0, t1, dt)
            telemetry[law.name] = report
            
        return telemetry