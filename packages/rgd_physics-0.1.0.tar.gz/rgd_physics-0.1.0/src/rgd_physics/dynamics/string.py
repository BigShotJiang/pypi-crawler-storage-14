"""
RGD-PHYSICS :: STRING MODEL
The advanced model for harmonic entities (Avatars, Soft Robotics, AGI).
Treats existence as a vibration on a Worldsheet.
"""
from ..core.interfaces import DynamicsModel, Microsecond
from ..chronon.interfaces import ChrononProtocol
from ..core.exceptions import CausalityBreak

class StringModel(DynamicsModel):
    """
    Treats the entity as a Vibrating String.
    Enforces 'Harmonic Resonance'.
    Movements must be smooth; high-frequency jitter snaps the string.
    """
    
    def validate_movement(self, t0: ChrononProtocol, t1: ChrononProtocol, dt: Microsecond) -> None:
        # 1. CALCULATE PHASE SHIFT (W coordinate delta)
        # In RGD, the 'w' coordinate represents the probability phase.
        # Rapid changes in 'w' imply high-energy vibration across timelines.
        w0 = t0.metric_coordinates[3]
        w1 = t1.metric_coordinates[3]
        
        phase_shift = abs(w1 - w0)
        
        # Frequency = Cycles per Second
        frequency = phase_shift / dt if dt > 0 else 0.0
        
        # 2. CHECK RESONANCE LIMIT
        # Hardcoded threshold for v1.0. In v2.0 this comes from Aion metadata.
        MAX_RESONANCE_FREQ = 1000.0 # Hz
        
        if frequency > MAX_RESONANCE_FREQ:
            raise CausalityBreak(
                f"STRING SNAP: Resonance Frequency {frequency:.2f}Hz exceeds limit {MAX_RESONANCE_FREQ}Hz. "
                "Entity is vibrating too fast for the spacetime manifold."
            )