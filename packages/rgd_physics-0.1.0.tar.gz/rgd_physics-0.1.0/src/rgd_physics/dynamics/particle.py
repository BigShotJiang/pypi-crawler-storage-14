"""
RGD-PHYSICS :: PARTICLE MODEL
The standard model for rigid bodies (Robots, Vehicles).
"""
from ..core.interfaces import DynamicsModel, Microsecond
from ..chronon.interfaces import ChrononProtocol

class ParticleModel(DynamicsModel):
    """
    Treats the entity as a 0-dimensional Point Mass.
    No internal structure. Pure kinematic movement.
    """
    
    def validate_movement(self, t0: ChrononProtocol, t1: ChrononProtocol, dt: Microsecond) -> None:
        """
        Pass-through validation.
        If the Geometry Kernel approves the position, the Particle Model accepts it.
        """
        return None
    
        # In a more advanced version, we could check for Momentum conservation here.
        # For v1.0 Lean Mode, this is a pass-through.
