# coding: UTF-8
import sys
bstack1l11111_opy_ = sys.version_info [0] == 2
bstack11l11ll_opy_ = 2048
bstack111ll1l_opy_ = 7
def bstack1l1l11_opy_ (bstack11l1l_opy_):
    global bstack1l11_opy_
    bstack11l1111_opy_ = ord (bstack11l1l_opy_ [-1])
    bstack1l1ll1l_opy_ = bstack11l1l_opy_ [:-1]
    bstack11l11_opy_ = bstack11l1111_opy_ % len (bstack1l1ll1l_opy_)
    bstack1l1ll11_opy_ = bstack1l1ll1l_opy_ [:bstack11l11_opy_] + bstack1l1ll1l_opy_ [bstack11l11_opy_:]
    if bstack1l11111_opy_:
        bstack11lll1l_opy_ = unicode () .join ([unichr (ord (char) - bstack11l11ll_opy_ - (bstack11l111_opy_ + bstack11l1111_opy_) % bstack111ll1l_opy_) for bstack11l111_opy_, char in enumerate (bstack1l1ll11_opy_)])
    else:
        bstack11lll1l_opy_ = str () .join ([chr (ord (char) - bstack11l11ll_opy_ - (bstack11l111_opy_ + bstack11l1111_opy_) % bstack111ll1l_opy_) for bstack11l111_opy_, char in enumerate (bstack1l1ll11_opy_)])
    return eval (bstack11lll1l_opy_)
import json
import os
import threading
from bstack_utils.config import Config
from bstack_utils.constants import EVENTS, STAGE
from bstack_utils.helper import bstack11l111ll1ll_opy_, bstack1llll1111l_opy_, bstack1lll11ll1l_opy_, bstack11l11l1lll_opy_, \
    bstack11l111ll111_opy_
from bstack_utils.measure import measure
def bstack1111l1ll1_opy_(bstack1llll1ll1l1l_opy_):
    for driver in bstack1llll1ll1l1l_opy_:
        try:
            driver.quit()
        except Exception as e:
            pass
@measure(event_name=EVENTS.bstack1111llll_opy_, stage=STAGE.bstack111llllll_opy_)
def bstack1l1l1l1l1l_opy_(driver, status, reason=bstack1l1l11_opy_ (u"ࠪࠫ₆")):
    bstack11l111l1l1_opy_ = Config.bstack11lll1l1l_opy_()
    if bstack11l111l1l1_opy_.bstack1lllllll1ll_opy_():
        return
    bstack111111ll1_opy_ = bstack1lllll1l1_opy_(bstack1l1l11_opy_ (u"ࠫࡸ࡫ࡴࡔࡧࡶࡷ࡮ࡵ࡮ࡔࡶࡤࡸࡺࡹࠧ₇"), bstack1l1l11_opy_ (u"ࠬ࠭₈"), status, reason, bstack1l1l11_opy_ (u"࠭ࠧ₉"), bstack1l1l11_opy_ (u"ࠧࠨ₊"))
    driver.execute_script(bstack111111ll1_opy_)
@measure(event_name=EVENTS.bstack1111llll_opy_, stage=STAGE.bstack111llllll_opy_)
def bstack11l11lll11_opy_(page, status, reason=bstack1l1l11_opy_ (u"ࠨࠩ₋")):
    try:
        if page is None:
            return
        bstack11l111l1l1_opy_ = Config.bstack11lll1l1l_opy_()
        if bstack11l111l1l1_opy_.bstack1lllllll1ll_opy_():
            return
        bstack111111ll1_opy_ = bstack1lllll1l1_opy_(bstack1l1l11_opy_ (u"ࠩࡶࡩࡹ࡙ࡥࡴࡵ࡬ࡳࡳ࡙ࡴࡢࡶࡸࡷࠬ₌"), bstack1l1l11_opy_ (u"ࠪࠫ₍"), status, reason, bstack1l1l11_opy_ (u"ࠫࠬ₎"), bstack1l1l11_opy_ (u"ࠬ࠭₏"))
        page.evaluate(bstack1l1l11_opy_ (u"ࠨ࡟ࠡ࠿ࡁࠤࢀࢃࠢₐ"), bstack111111ll1_opy_)
    except Exception as e:
        print(bstack1l1l11_opy_ (u"ࠢࡆࡺࡦࡩࡵࡺࡩࡰࡰࠣ࡭ࡳࠦࡳࡦࡶࡷ࡭ࡳ࡭ࠠࡴࡧࡶࡷ࡮ࡵ࡮ࠡࡵࡷࡥࡹࡻࡳࠡࡨࡲࡶࠥࡶ࡬ࡢࡻࡺࡶ࡮࡭ࡨࡵࠢࡾࢁࠧₑ"), e)
def bstack1lllll1l1_opy_(type, name, status, reason, bstack1l11lllll1_opy_, bstack11l111lll_opy_):
    bstack1ll1l11ll_opy_ = {
        bstack1l1l11_opy_ (u"ࠨࡣࡦࡸ࡮ࡵ࡮ࠨₒ"): type,
        bstack1l1l11_opy_ (u"ࠩࡤࡶ࡬ࡻ࡭ࡦࡰࡷࡷࠬₓ"): {}
    }
    if type == bstack1l1l11_opy_ (u"ࠪࡥࡳࡴ࡯ࡵࡣࡷࡩࠬₔ"):
        bstack1ll1l11ll_opy_[bstack1l1l11_opy_ (u"ࠫࡦࡸࡧࡶ࡯ࡨࡲࡹࡹࠧₕ")][bstack1l1l11_opy_ (u"ࠬࡲࡥࡷࡧ࡯ࠫₖ")] = bstack1l11lllll1_opy_
        bstack1ll1l11ll_opy_[bstack1l1l11_opy_ (u"࠭ࡡࡳࡩࡸࡱࡪࡴࡴࡴࠩₗ")][bstack1l1l11_opy_ (u"ࠧࡥࡣࡷࡥࠬₘ")] = json.dumps(str(bstack11l111lll_opy_))
    if type == bstack1l1l11_opy_ (u"ࠨࡵࡨࡸࡘ࡫ࡳࡴ࡫ࡲࡲࡓࡧ࡭ࡦࠩₙ"):
        bstack1ll1l11ll_opy_[bstack1l1l11_opy_ (u"ࠩࡤࡶ࡬ࡻ࡭ࡦࡰࡷࡷࠬₚ")][bstack1l1l11_opy_ (u"ࠪࡲࡦࡳࡥࠨₛ")] = name
    if type == bstack1l1l11_opy_ (u"ࠫࡸ࡫ࡴࡔࡧࡶࡷ࡮ࡵ࡮ࡔࡶࡤࡸࡺࡹࠧₜ"):
        bstack1ll1l11ll_opy_[bstack1l1l11_opy_ (u"ࠬࡧࡲࡨࡷࡰࡩࡳࡺࡳࠨ₝")][bstack1l1l11_opy_ (u"࠭ࡳࡵࡣࡷࡹࡸ࠭₞")] = status
        if status == bstack1l1l11_opy_ (u"ࠧࡧࡣ࡬ࡰࡪࡪࠧ₟") and str(reason) != bstack1l1l11_opy_ (u"ࠣࠤ₠"):
            bstack1ll1l11ll_opy_[bstack1l1l11_opy_ (u"ࠩࡤࡶ࡬ࡻ࡭ࡦࡰࡷࡷࠬ₡")][bstack1l1l11_opy_ (u"ࠪࡶࡪࡧࡳࡰࡰࠪ₢")] = json.dumps(str(reason))
    bstack111ll1ll1_opy_ = bstack1l1l11_opy_ (u"ࠫࡧࡸ࡯ࡸࡵࡨࡶࡸࡺࡡࡤ࡭ࡢࡩࡽ࡫ࡣࡶࡶࡲࡶ࠿ࠦࡻࡾࠩ₣").format(json.dumps(bstack1ll1l11ll_opy_))
    return bstack111ll1ll1_opy_
def bstack1ll111ll_opy_(url, config, logger, bstack1l1l11lll_opy_=False):
    hostname = bstack1llll1111l_opy_(url)
    is_private = bstack11l11l1lll_opy_(hostname)
    try:
        if is_private or bstack1l1l11lll_opy_:
            file_path = bstack11l111ll1ll_opy_(bstack1l1l11_opy_ (u"ࠬ࠴ࡢࡳࡱࡺࡷࡪࡸࡳࡵࡣࡦ࡯ࠬ₤"), bstack1l1l11_opy_ (u"࠭࠮ࡣࡵࡷࡥࡨࡱ࠭ࡤࡱࡱࡪ࡮࡭࠮࡫ࡵࡲࡲࠬ₥"), logger)
            if os.environ.get(bstack1l1l11_opy_ (u"ࠧࡃࡔࡒ࡛ࡘࡋࡒࡔࡖࡄࡇࡐࡥࡌࡐࡅࡄࡐࡤࡔࡏࡕࡡࡖࡉ࡙ࡥࡅࡓࡔࡒࡖࠬ₦")) and eval(
                    os.environ.get(bstack1l1l11_opy_ (u"ࠨࡄࡕࡓ࡜࡙ࡅࡓࡕࡗࡅࡈࡑ࡟ࡍࡑࡆࡅࡑࡥࡎࡐࡖࡢࡗࡊ࡚࡟ࡆࡔࡕࡓࡗ࠭₧"))):
                return
            if (bstack1l1l11_opy_ (u"ࠩࡥࡶࡴࡽࡳࡦࡴࡶࡸࡦࡩ࡫ࡍࡱࡦࡥࡱ࠭₨") in config and not config[bstack1l1l11_opy_ (u"ࠪࡦࡷࡵࡷࡴࡧࡵࡷࡹࡧࡣ࡬ࡎࡲࡧࡦࡲࠧ₩")]):
                os.environ[bstack1l1l11_opy_ (u"ࠫࡇࡘࡏࡘࡕࡈࡖࡘ࡚ࡁࡄࡍࡢࡐࡔࡉࡁࡍࡡࡑࡓ࡙ࡥࡓࡆࡖࡢࡉࡗࡘࡏࡓࠩ₪")] = str(True)
                bstack1llll1ll1lll_opy_ = {bstack1l1l11_opy_ (u"ࠬ࡮࡯ࡴࡶࡱࡥࡲ࡫ࠧ₫"): hostname}
                bstack11l111ll111_opy_(bstack1l1l11_opy_ (u"࠭࠮ࡣࡵࡷࡥࡨࡱ࠭ࡤࡱࡱࡪ࡮࡭࠮࡫ࡵࡲࡲࠬ€"), bstack1l1l11_opy_ (u"ࠧ࡯ࡷࡧ࡫ࡪࡥ࡬ࡰࡥࡤࡰࠬ₭"), bstack1llll1ll1lll_opy_, logger)
    except Exception as e:
        pass
def bstack11l1111ll_opy_(caps, bstack1llll1ll1ll1_opy_):
    if bstack1l1l11_opy_ (u"ࠨࡤࡶࡸࡦࡩ࡫࠻ࡱࡳࡸ࡮ࡵ࡮ࡴࠩ₮") in caps:
        caps[bstack1l1l11_opy_ (u"ࠩࡥࡷࡹࡧࡣ࡬࠼ࡲࡴࡹ࡯࡯࡯ࡵࠪ₯")][bstack1l1l11_opy_ (u"ࠪࡰࡴࡩࡡ࡭ࠩ₰")] = True
        if bstack1llll1ll1ll1_opy_:
            caps[bstack1l1l11_opy_ (u"ࠫࡧࡹࡴࡢࡥ࡮࠾ࡴࡶࡴࡪࡱࡱࡷࠬ₱")][bstack1l1l11_opy_ (u"ࠬࡲ࡯ࡤࡣ࡯ࡍࡩ࡫࡮ࡵ࡫ࡩ࡭ࡪࡸࠧ₲")] = bstack1llll1ll1ll1_opy_
    else:
        caps[bstack1l1l11_opy_ (u"࠭ࡢࡳࡱࡺࡷࡪࡸࡳࡵࡣࡦ࡯࠳ࡲ࡯ࡤࡣ࡯ࠫ₳")] = True
        if bstack1llll1ll1ll1_opy_:
            caps[bstack1l1l11_opy_ (u"ࠧࡣࡴࡲࡻࡸ࡫ࡲࡴࡶࡤࡧࡰ࠴࡬ࡰࡥࡤࡰࡎࡪࡥ࡯ࡶ࡬ࡪ࡮࡫ࡲࠨ₴")] = bstack1llll1ll1ll1_opy_
def bstack1lllll1l11l1_opy_(bstack111l111l1l_opy_):
    bstack1llll1lll111_opy_ = bstack1lll11ll1l_opy_(threading.current_thread(), bstack1l1l11_opy_ (u"ࠨࡶࡨࡷࡹ࡙ࡴࡢࡶࡸࡷࠬ₵"), bstack1l1l11_opy_ (u"ࠩࠪ₶"))
    if bstack1llll1lll111_opy_ == bstack1l1l11_opy_ (u"ࠪࠫ₷") or bstack1llll1lll111_opy_ == bstack1l1l11_opy_ (u"ࠫࡸࡱࡩࡱࡲࡨࡨࠬ₸"):
        threading.current_thread().testStatus = bstack111l111l1l_opy_
    else:
        if bstack111l111l1l_opy_ == bstack1l1l11_opy_ (u"ࠬ࡬ࡡࡪ࡮ࡨࡨࠬ₹"):
            threading.current_thread().testStatus = bstack111l111l1l_opy_