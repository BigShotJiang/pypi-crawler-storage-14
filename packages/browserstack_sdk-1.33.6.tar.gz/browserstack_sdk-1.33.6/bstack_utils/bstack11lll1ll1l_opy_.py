# coding: UTF-8
import sys
bstack1l11111_opy_ = sys.version_info [0] == 2
bstack11l11ll_opy_ = 2048
bstack111ll1l_opy_ = 7
def bstack1l1l11_opy_ (bstack11l1l_opy_):
    global bstack1l11_opy_
    bstack11l1111_opy_ = ord (bstack11l1l_opy_ [-1])
    bstack1l1ll1l_opy_ = bstack11l1l_opy_ [:-1]
    bstack11l11_opy_ = bstack11l1111_opy_ % len (bstack1l1ll1l_opy_)
    bstack1l1ll11_opy_ = bstack1l1ll1l_opy_ [:bstack11l11_opy_] + bstack1l1ll1l_opy_ [bstack11l11_opy_:]
    if bstack1l11111_opy_:
        bstack11lll1l_opy_ = unicode () .join ([unichr (ord (char) - bstack11l11ll_opy_ - (bstack11l111_opy_ + bstack11l1111_opy_) % bstack111ll1l_opy_) for bstack11l111_opy_, char in enumerate (bstack1l1ll11_opy_)])
    else:
        bstack11lll1l_opy_ = str () .join ([chr (ord (char) - bstack11l11ll_opy_ - (bstack11l111_opy_ + bstack11l1111_opy_) % bstack111ll1l_opy_) for bstack11l111_opy_, char in enumerate (bstack1l1ll11_opy_)])
    return eval (bstack11lll1l_opy_)
import os
import tempfile
import math
from bstack_utils import bstack1l1lll1l_opy_
from bstack_utils.constants import bstack11ll1lll1l_opy_, bstack11l1l11llll_opy_
from bstack_utils.helper import bstack111llll11ll_opy_, get_host_info
from bstack_utils.bstack11l1lll1l1l_opy_ import bstack11l1lll1ll1_opy_
import json
import re
import sys
bstack1111l1lll1l_opy_ = bstack1l1l11_opy_ (u"ࠦࡷ࡫ࡴࡳࡻࡗࡩࡸࡺࡳࡐࡰࡉࡥ࡮ࡲࡵࡳࡧࠥỀ")
bstack1111ll1ll1l_opy_ = bstack1l1l11_opy_ (u"ࠧࡧࡢࡰࡴࡷࡆࡺ࡯࡬ࡥࡑࡱࡊࡦ࡯࡬ࡶࡴࡨࠦề")
bstack1111ll1l1ll_opy_ = bstack1l1l11_opy_ (u"ࠨࡲࡶࡰࡓࡶࡪࡼࡩࡰࡷࡶࡰࡾࡌࡡࡪ࡮ࡨࡨࡋ࡯ࡲࡴࡶࠥỂ")
bstack1111lll1l11_opy_ = bstack1l1l11_opy_ (u"ࠢࡳࡧࡵࡹࡳࡖࡲࡦࡸ࡬ࡳࡺࡹ࡬ࡺࡈࡤ࡭ࡱ࡫ࡤࠣể")
bstack1111l11l11l_opy_ = bstack1l1l11_opy_ (u"ࠣࡵ࡮࡭ࡵࡌ࡬ࡢ࡭ࡼࡥࡳࡪࡆࡢ࡫࡯ࡩࡩࠨỄ")
bstack1111ll1111l_opy_ = bstack1l1l11_opy_ (u"ࠤࡵࡹࡳ࡙࡭ࡢࡴࡷࡗࡪࡲࡥࡤࡶ࡬ࡳࡳࠨễ")
bstack1111lll11ll_opy_ = {
    bstack1111l1lll1l_opy_,
    bstack1111ll1ll1l_opy_,
    bstack1111ll1l1ll_opy_,
    bstack1111lll1l11_opy_,
    bstack1111l11l11l_opy_,
    bstack1111ll1111l_opy_
}
bstack1111ll1ll11_opy_ = {bstack1l1l11_opy_ (u"ࠪࡴࡾࡺࡥࡴࡶࠪỆ")}
logger = bstack1l1lll1l_opy_.get_logger(__name__, bstack11ll1lll1l_opy_)
class bstack1111l1lllll_opy_:
    def __init__(self):
        self.enabled = False
        self.name = None
    def enable(self, name):
        self.enabled = True
        self.name = name
    def disable(self):
        self.enabled = False
        self.name = None
    def bstack1111ll1l111_opy_(self):
        return self.enabled
    def get_name(self):
        return self.name
class bstack111lll11_opy_:
    _1ll11111l11_opy_ = None
    def __init__(self, config):
        self.bstack1111ll1llll_opy_ = False
        self.bstack1111l1l11l1_opy_ = False
        self.bstack1111ll11l11_opy_ = False
        self.bstack1111l1ll1l1_opy_ = False
        self.bstack1111l11l1ll_opy_ = None
        self.bstack1111lll11l1_opy_ = bstack1111l1lllll_opy_()
        self.bstack1111ll111l1_opy_ = None
        opts = config.get(bstack1l1l11_opy_ (u"ࠫࡹ࡫ࡳࡵࡑࡵࡧ࡭࡫ࡳࡵࡴࡤࡸ࡮ࡵ࡮ࡐࡲࡷ࡭ࡴࡴࡳࠨệ"), {})
        self.bstack1111l1lll11_opy_ = config.get(bstack1l1l11_opy_ (u"ࠬࡹ࡭ࡢࡴࡷࡗࡪࡲࡥࡤࡶ࡬ࡳࡳࡌࡥࡢࡶࡸࡶࡪࡈࡲࡢࡰࡦ࡬ࡪࡹࡅࡏࡘࠪỈ"), bstack1l1l11_opy_ (u"ࠨࠢỉ"))
        self.bstack1111l11l1l1_opy_ = config.get(bstack1l1l11_opy_ (u"ࠧࡴ࡯ࡤࡶࡹ࡙ࡥ࡭ࡧࡦࡸ࡮ࡵ࡮ࡇࡧࡤࡸࡺࡸࡥࡃࡴࡤࡲࡨ࡮ࡥࡴࡅࡏࡍࠬỊ"), bstack1l1l11_opy_ (u"ࠣࠤị"))
        bstack1111l1l1l11_opy_ = opts.get(bstack1111ll1111l_opy_, {})
        bstack1111ll111ll_opy_ = None
        if bstack1l1l11_opy_ (u"ࠩࡶࡳࡺࡸࡣࡦࠩỌ") in bstack1111l1l1l11_opy_:
            bstack1111l11111l_opy_ = bstack1111l1l1l11_opy_[bstack1l1l11_opy_ (u"ࠪࡷࡴࡻࡲࡤࡧࠪọ")]
            if bstack1111l11111l_opy_ is None or (isinstance(bstack1111l11111l_opy_, str) and bstack1111l11111l_opy_.strip() == bstack1l1l11_opy_ (u"ࠫࠬỎ")) or (isinstance(bstack1111l11111l_opy_, list) and len(bstack1111l11111l_opy_) == 0):
                bstack1111ll111ll_opy_ = []
            elif isinstance(bstack1111l11111l_opy_, list):
                bstack1111ll111ll_opy_ = bstack1111l11111l_opy_
            elif isinstance(bstack1111l11111l_opy_, str) and bstack1111l11111l_opy_.strip():
                bstack1111ll111ll_opy_ = bstack1111l11111l_opy_
            else:
                logger.warning(bstack1l1l11_opy_ (u"ࠧࡏ࡮ࡷࡣ࡯࡭ࡩࠦࡳࡰࡷࡵࡧࡪࠦࡶࡢ࡮ࡸࡩࠥ࡯࡮ࠡࡥࡲࡲ࡫࡯ࡧ࠻ࠢࡾࢁ࠳ࠦࡄࡦࡨࡤࡹࡱࡺࡩ࡯ࡩࠣࡸࡴࠦࡥ࡮ࡲࡷࡽࠥࡲࡩࡴࡶ࠱ࠦỏ").format(bstack1111l11111l_opy_))
                bstack1111ll111ll_opy_ = []
        self.__1111ll1l1l1_opy_(
            bstack1111l1l1l11_opy_.get(bstack1l1l11_opy_ (u"࠭ࡥ࡯ࡣࡥࡰࡪࡪࠧỐ"), False),
            bstack1111l1l1l11_opy_.get(bstack1l1l11_opy_ (u"ࠧ࡮ࡱࡧࡩࠬố"), bstack1l1l11_opy_ (u"ࠨࡴࡨࡰࡪࡼࡡ࡯ࡶࡉ࡭ࡷࡹࡴࠨỒ")),
            bstack1111ll111ll_opy_
        )
        self.__1111l11lll1_opy_(opts.get(bstack1111ll1l1ll_opy_, False))
        self.__1111lll1l1l_opy_(opts.get(bstack1111lll1l11_opy_, False))
        self.__1111l1l1lll_opy_(opts.get(bstack1111l11l11l_opy_, False))
    @classmethod
    def bstack11lll1l1l_opy_(cls, config=None):
        if cls._1ll11111l11_opy_ is None and config is not None:
            cls._1ll11111l11_opy_ = bstack111lll11_opy_(config)
        return cls._1ll11111l11_opy_
    @staticmethod
    def bstack1l11l1l1ll_opy_(config: dict) -> bool:
        bstack1111lll111l_opy_ = config.get(bstack1l1l11_opy_ (u"ࠩࡷࡩࡸࡺࡏࡳࡥ࡫ࡩࡸࡺࡲࡢࡶ࡬ࡳࡳࡕࡰࡵ࡫ࡲࡲࡸ࠭ồ"), {}).get(bstack1111l1lll1l_opy_, {})
        return bstack1111lll111l_opy_.get(bstack1l1l11_opy_ (u"ࠪࡩࡳࡧࡢ࡭ࡧࡧࠫỔ"), False)
    @staticmethod
    def bstack111lll11ll_opy_(config: dict) -> int:
        bstack1111lll111l_opy_ = config.get(bstack1l1l11_opy_ (u"ࠫࡹ࡫ࡳࡵࡑࡵࡧ࡭࡫ࡳࡵࡴࡤࡸ࡮ࡵ࡮ࡐࡲࡷ࡭ࡴࡴࡳࠨổ"), {}).get(bstack1111l1lll1l_opy_, {})
        retries = 0
        if bstack111lll11_opy_.bstack1l11l1l1ll_opy_(config):
            retries = bstack1111lll111l_opy_.get(bstack1l1l11_opy_ (u"ࠬࡳࡡࡹࡔࡨࡸࡷ࡯ࡥࡴࠩỖ"), 1)
        return retries
    @staticmethod
    def bstack1l11l1l1l_opy_(config: dict) -> dict:
        bstack1111ll11ll1_opy_ = config.get(bstack1l1l11_opy_ (u"࠭ࡴࡦࡵࡷࡓࡷࡩࡨࡦࡵࡷࡶࡦࡺࡩࡰࡰࡒࡴࡹ࡯࡯࡯ࡵࠪỗ"), {})
        return {
            key: value for key, value in bstack1111ll11ll1_opy_.items() if key in bstack1111lll11ll_opy_
        }
    @staticmethod
    def bstack1111lll1ll1_opy_():
        bstack1l1l11_opy_ (u"ࠢࠣࠤࠍࠤࠥࠦࠠࠡࠢࠣࠤࡈ࡮ࡥࡤ࡭ࠣ࡭࡫ࠦࡴࡩࡧࠣࡥࡧࡵࡲࡵࠢࡥࡹ࡮ࡲࡤࠡࡨ࡬ࡰࡪࠦࡥࡹ࡫ࡶࡸࡸ࠴ࠊࠡࠢࠣࠤࠥࠦࠠࠡࠤࠥࠦỘ")
        return os.path.exists(os.path.join(tempfile.gettempdir(), bstack1l1l11_opy_ (u"ࠣࡣࡥࡳࡷࡺ࡟ࡣࡷ࡬ࡰࡩࡥࡻࡾࠤộ").format(os.getenv(bstack1l1l11_opy_ (u"ࠤࡅࡖࡔ࡝ࡓࡆࡔࡖࡘࡆࡉࡋࡠࡖࡈࡗ࡙ࡎࡕࡃࡡࡘ࡙ࡎࡊࠢỚ")))))
    @staticmethod
    def bstack1111l1l1ll1_opy_(test_name: str):
        bstack1l1l11_opy_ (u"ࠥࠦࠧࠐࠠࠡࠢࠣࠤࠥࠦࠠࡄࡪࡨࡧࡰࠦࡩࡧࠢࡷ࡬ࡪࠦࡡࡣࡱࡵࡸࠥࡨࡵࡪ࡮ࡧࠤ࡫࡯࡬ࡦࠢࡨࡼ࡮ࡹࡴࡴ࠰ࠍࠤࠥࠦࠠࠡࠢࠣࠤࠧࠨࠢớ")
        bstack1111llll111_opy_ = os.path.join(tempfile.gettempdir(), bstack1l1l11_opy_ (u"ࠦ࡫ࡧࡩ࡭ࡧࡧࡣࡹ࡫ࡳࡵࡵࡢࡿࢂ࠴ࡴࡹࡶࠥỜ").format(os.getenv(bstack1l1l11_opy_ (u"ࠧࡈࡒࡐ࡙ࡖࡉࡗ࡙ࡔࡂࡅࡎࡣ࡙ࡋࡓࡕࡊࡘࡆࡤ࡛ࡕࡊࡆࠥờ"))))
        with open(bstack1111llll111_opy_, bstack1l1l11_opy_ (u"࠭ࡡࠨỞ")) as file:
            file.write(bstack1l1l11_opy_ (u"ࠢࡼࡿ࡟ࡲࠧở").format(test_name))
    @staticmethod
    def bstack1111llll11l_opy_(framework: str) -> bool:
       return framework.lower() in bstack1111ll1ll11_opy_
    @staticmethod
    def bstack11l11ll1111_opy_(config: dict) -> bool:
        bstack1111l111l11_opy_ = config.get(bstack1l1l11_opy_ (u"ࠨࡶࡨࡷࡹࡕࡲࡤࡪࡨࡷࡹࡸࡡࡵ࡫ࡲࡲࡔࡶࡴࡪࡱࡱࡷࠬỠ"), {}).get(bstack1111ll1ll1l_opy_, {})
        return bstack1111l111l11_opy_.get(bstack1l1l11_opy_ (u"ࠩࡨࡲࡦࡨ࡬ࡦࡦࠪỡ"), False)
    @staticmethod
    def bstack11l11l1ll1l_opy_(config: dict, bstack11l11llll11_opy_: int = 0) -> int:
        bstack1l1l11_opy_ (u"ࠥࠦࠧࠐࠠࠡࠢࠣࠤࠥࠦࠠࡈࡧࡷࠤࡹ࡮ࡥࠡࡨࡤ࡭ࡱࡻࡲࡦࠢࡷ࡬ࡷ࡫ࡳࡩࡱ࡯ࡨ࠱ࠦࡷࡩ࡫ࡦ࡬ࠥࡩࡡ࡯ࠢࡥࡩࠥࡧ࡮ࠡࡣࡥࡷࡴࡲࡵࡵࡧࠣࡲࡺࡳࡢࡦࡴࠣࡳࡷࠦࡡࠡࡲࡨࡶࡨ࡫࡮ࡵࡣࡪࡩ࠳ࠐࠠࠡࠢࠣࠤࠥࠦࠠࡂࡴࡪࡷ࠿ࠐࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࡨࡵ࡮ࡧ࡫ࡪࠤ࠭ࡪࡩࡤࡶࠬ࠾࡚ࠥࡨࡦࠢࡦࡳࡳ࡬ࡩࡨࡷࡵࡥࡹ࡯࡯࡯ࠢࡧ࡭ࡨࡺࡩࡰࡰࡤࡶࡾ࠴ࠊࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࡺ࡯ࡵࡣ࡯ࡣࡹ࡫ࡳࡵࡵࠣࠬ࡮ࡴࡴࠪ࠼ࠣࡘ࡭࡫ࠠࡵࡱࡷࡥࡱࠦ࡮ࡶ࡯ࡥࡩࡷࠦ࡯ࡧࠢࡷࡩࡸࡺࡳࠡࠪࡵࡩࡶࡻࡩࡳࡧࡧࠤ࡫ࡵࡲࠡࡲࡨࡶࡨ࡫࡮ࡵࡣࡪࡩ࠲ࡨࡡࡴࡧࡧࠤࡹ࡮ࡲࡦࡵ࡫ࡳࡱࡪࡳࠪ࠰ࠍࠤࠥࠦࠠࠡࠢࠣࠤࡗ࡫ࡴࡶࡴࡱࡷ࠿ࠐࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤ࡮ࡴࡴ࠻ࠢࡗ࡬ࡪࠦࡦࡢ࡫࡯ࡹࡷ࡫ࠠࡵࡪࡵࡩࡸ࡮࡯࡭ࡦ࠱ࠎࠥࠦࠠࠡࠢࠣࠤࠥࠨࠢࠣỢ")
        bstack1111l111l11_opy_ = config.get(bstack1l1l11_opy_ (u"ࠫࡹ࡫ࡳࡵࡑࡵࡧ࡭࡫ࡳࡵࡴࡤࡸ࡮ࡵ࡮ࡐࡲࡷ࡭ࡴࡴࡳࠨợ"), {}).get(bstack1l1l11_opy_ (u"ࠬࡧࡢࡰࡴࡷࡆࡺ࡯࡬ࡥࡑࡱࡊࡦ࡯࡬ࡶࡴࡨࠫỤ"), {})
        bstack1111l11ll11_opy_ = 0
        bstack1111ll11l1l_opy_ = 0
        if bstack111lll11_opy_.bstack11l11ll1111_opy_(config):
            bstack1111ll11l1l_opy_ = bstack1111l111l11_opy_.get(bstack1l1l11_opy_ (u"࠭࡭ࡢࡺࡉࡥ࡮ࡲࡵࡳࡧࡶࠫụ"), 5)
            if isinstance(bstack1111ll11l1l_opy_, str) and bstack1111ll11l1l_opy_.endswith(bstack1l1l11_opy_ (u"ࠧࠦࠩỦ")):
                try:
                    percentage = int(bstack1111ll11l1l_opy_.strip(bstack1l1l11_opy_ (u"ࠨࠧࠪủ")))
                    if bstack11l11llll11_opy_ > 0:
                        bstack1111l11ll11_opy_ = math.ceil((percentage * bstack11l11llll11_opy_) / 100)
                    else:
                        raise ValueError(bstack1l1l11_opy_ (u"ࠤࡗࡳࡹࡧ࡬ࠡࡶࡨࡷࡹࡹࠠ࡮ࡷࡶࡸࠥࡨࡥࠡࡲࡵࡳࡻ࡯ࡤࡦࡦࠣࡪࡴࡸࠠࡱࡧࡵࡧࡪࡴࡴࡢࡩࡨ࠱ࡧࡧࡳࡦࡦࠣࡸ࡭ࡸࡥࡴࡪࡲࡰࡩࡹ࠮ࠣỨ"))
                except ValueError as e:
                    raise ValueError(bstack1l1l11_opy_ (u"ࠥࡍࡳࡼࡡ࡭࡫ࡧࠤࡵ࡫ࡲࡤࡧࡱࡸࡦ࡭ࡥࠡࡸࡤࡰࡺ࡫ࠠࡧࡱࡵࠤࡲࡧࡸࡇࡣ࡬ࡰࡺࡸࡥࡴ࠼ࠣࡿࢂࠨứ").format(bstack1111ll11l1l_opy_)) from e
            else:
                bstack1111l11ll11_opy_ = int(bstack1111ll11l1l_opy_)
        logger.info(bstack1l1l11_opy_ (u"ࠦࡒࡧࡸࠡࡨࡤ࡭ࡱࡻࡲࡦࡵࠣࡸ࡭ࡸࡥࡴࡪࡲࡰࡩࠦࡳࡦࡶࠣࡸࡴࡀࠠࡼࡿࠣࠬ࡫ࡸ࡯࡮ࠢࡦࡳࡳ࡬ࡩࡨ࠼ࠣࡿࢂ࠯ࠢỪ").format(bstack1111l11ll11_opy_, bstack1111ll11l1l_opy_))
        return bstack1111l11ll11_opy_
    def bstack1111l1l111l_opy_(self):
        return self.bstack1111l1ll1l1_opy_
    def bstack1111ll11111_opy_(self):
        return self.bstack1111l11l1ll_opy_
    def bstack1111lll1lll_opy_(self):
        return self.bstack1111ll111l1_opy_
    def __1111ll1l1l1_opy_(self, enabled, mode, source=None):
        try:
            self.bstack1111l1ll1l1_opy_ = bool(enabled)
            if mode not in [bstack1l1l11_opy_ (u"ࠬࡸࡥ࡭ࡧࡹࡥࡳࡺࡆࡪࡴࡶࡸࠬừ"), bstack1l1l11_opy_ (u"࠭ࡲࡦ࡮ࡨࡺࡦࡴࡴࡐࡰ࡯ࡽࠬỬ")]:
                logger.warning(bstack1l1l11_opy_ (u"ࠢࡊࡰࡹࡥࡱ࡯ࡤࠡࡵࡰࡥࡷࡺࠠࡴࡧ࡯ࡩࡨࡺࡩࡰࡰࠣࡱࡴࡪࡥࠡࠩࡾࢁࠬࠦࡰࡳࡱࡹ࡭ࡩ࡫ࡤ࠯ࠢࡇࡩ࡫ࡧࡵ࡭ࡶ࡬ࡲ࡬ࠦࡴࡰࠢࠪࡶࡪࡲࡥࡷࡣࡱࡸࡋ࡯ࡲࡴࡶࠪ࠲ࠧử").format(mode))
                mode = bstack1l1l11_opy_ (u"ࠨࡴࡨࡰࡪࡼࡡ࡯ࡶࡉ࡭ࡷࡹࡴࠨỮ")
            self.bstack1111l11l1ll_opy_ = mode
            self.bstack1111ll111l1_opy_ = []
            if source is None:
                self.bstack1111ll111l1_opy_ = None
            elif isinstance(source, list):
                self.bstack1111ll111l1_opy_ = source
            elif isinstance(source, str) and source.endswith(bstack1l1l11_opy_ (u"ࠩ࠱࡮ࡸࡵ࡮ࠨữ")):
                self.bstack1111ll111l1_opy_ = self._1111l1l1111_opy_(source)
            self.__1111l1llll1_opy_()
        except Exception as e:
            logger.error(bstack1l1l11_opy_ (u"ࠥࡊࡦ࡯࡬ࡦࡦࠣࡸࡴࠦࡳࡦࡶࠣࡷࡲࡧࡲࡵࠢࡶࡩࡱ࡫ࡣࡵ࡫ࡲࡲࠥࡩ࡯࡯ࡨ࡬࡫ࡺࡸࡡࡵ࡫ࡲࡲࠥ࠳ࠠࡦࡰࡤࡦࡱ࡫ࡤ࠻ࠢࡾࢁ࠱ࠦ࡭ࡰࡦࡨ࠾ࠥࢁࡽ࠭ࠢࡶࡳࡺࡸࡣࡦ࠼ࠣࡿࢂ࠴ࠠࡆࡴࡵࡳࡷࡀࠠࡼࡿࠥỰ").format(enabled, mode, source, e))
    def bstack1111l111lll_opy_(self):
        return self.bstack1111ll1llll_opy_
    def __1111l11lll1_opy_(self, value):
        self.bstack1111ll1llll_opy_ = bool(value)
        self.__1111l1llll1_opy_()
    def bstack1111l1111l1_opy_(self):
        return self.bstack1111l1l11l1_opy_
    def __1111lll1l1l_opy_(self, value):
        self.bstack1111l1l11l1_opy_ = bool(value)
        self.__1111l1llll1_opy_()
    def bstack1111l11llll_opy_(self):
        return self.bstack1111ll11l11_opy_
    def __1111l1l1lll_opy_(self, value):
        self.bstack1111ll11l11_opy_ = bool(value)
        self.__1111l1llll1_opy_()
    def __1111l1llll1_opy_(self):
        if self.bstack1111l1ll1l1_opy_:
            self.bstack1111ll1llll_opy_ = False
            self.bstack1111l1l11l1_opy_ = False
            self.bstack1111ll11l11_opy_ = False
            self.bstack1111lll11l1_opy_.enable(bstack1111ll1111l_opy_)
        elif self.bstack1111ll1llll_opy_:
            self.bstack1111l1l11l1_opy_ = False
            self.bstack1111ll11l11_opy_ = False
            self.bstack1111l1ll1l1_opy_ = False
            self.bstack1111lll11l1_opy_.enable(bstack1111ll1l1ll_opy_)
        elif self.bstack1111l1l11l1_opy_:
            self.bstack1111ll1llll_opy_ = False
            self.bstack1111ll11l11_opy_ = False
            self.bstack1111l1ll1l1_opy_ = False
            self.bstack1111lll11l1_opy_.enable(bstack1111lll1l11_opy_)
        elif self.bstack1111ll11l11_opy_:
            self.bstack1111ll1llll_opy_ = False
            self.bstack1111l1l11l1_opy_ = False
            self.bstack1111l1ll1l1_opy_ = False
            self.bstack1111lll11l1_opy_.enable(bstack1111l11l11l_opy_)
        else:
            self.bstack1111lll11l1_opy_.disable()
    def bstack1lllll111l_opy_(self):
        return self.bstack1111lll11l1_opy_.bstack1111ll1l111_opy_()
    def bstack11l1lll1ll_opy_(self):
        if self.bstack1111lll11l1_opy_.bstack1111ll1l111_opy_():
            return self.bstack1111lll11l1_opy_.get_name()
        return None
    def _1111l1l1111_opy_(self, bstack1111ll1l11l_opy_):
        bstack1l1l11_opy_ (u"ࠦࠧࠨࠊࠡࠢࠣࠤࠥࠦࠠࠡࡒࡤࡶࡸ࡫ࠠࡋࡕࡒࡒࠥࡹ࡯ࡶࡴࡦࡩࠥࡩ࡯࡯ࡨ࡬࡫ࡺࡸࡡࡵ࡫ࡲࡲࠥ࡬ࡩ࡭ࡧࠣࡥࡳࡪࠠࡧࡱࡵࡱࡦࡺࠠࡪࡶࠣࡪࡴࡸࠠࡴ࡯ࡤࡶࡹࠦࡳࡦ࡮ࡨࡧࡹ࡯࡯࡯࠰ࠍࠤࠥࠦࠠࠡࠢࠣࠤࡆࡸࡧࡴ࠼ࠍࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࡵࡲࡹࡷࡩࡥࡠࡨ࡬ࡰࡪࡥࡰࡢࡶ࡫ࠤ࠭ࡹࡴࡳࠫ࠽ࠤࡕࡧࡴࡩࠢࡷࡳࠥࡺࡨࡦࠢࡍࡗࡔࡔࠠࡤࡱࡱࡪ࡮࡭ࡵࡳࡣࡷ࡭ࡴࡴࠠࡧ࡫࡯ࡩࠏࠦࠠࠡࠢࠣࠤࠥࠦࡒࡦࡶࡸࡶࡳࡹ࠺ࠋࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦ࡬ࡪࡵࡷ࠾ࠥࡌ࡯ࡳ࡯ࡤࡸࡹ࡫ࡤࠡ࡮࡬ࡷࡹࠦ࡯ࡧࠢࡵࡩࡵࡵࡳࡪࡶࡲࡶࡾࠦࡣࡰࡰࡩ࡭࡬ࡻࡲࡢࡶ࡬ࡳࡳࡹࠊࠡࠢࠣࠤࠥࠦࠠࠡࠤࠥࠦự")
        if not os.path.isfile(bstack1111ll1l11l_opy_):
            logger.error(bstack1l1l11_opy_ (u"࡙ࠧ࡯ࡶࡴࡦࡩࠥ࡬ࡩ࡭ࡧࠣࠫࢀࢃࠧࠡࡦࡲࡩࡸࠦ࡮ࡰࡶࠣࡩࡽ࡯ࡳࡵ࠰ࠥỲ").format(bstack1111ll1l11l_opy_))
            return []
        data = None
        try:
            with open(bstack1111ll1l11l_opy_, bstack1l1l11_opy_ (u"ࠨࡲࠣỳ")) as f:
                data = json.load(f)
        except json.JSONDecodeError as e:
            logger.error(bstack1l1l11_opy_ (u"ࠢࡆࡴࡵࡳࡷࠦࡰࡢࡴࡶ࡭ࡳ࡭ࠠࡋࡕࡒࡒࠥ࡬ࡲࡰ࡯ࠣࡷࡴࡻࡲࡤࡧࠣࡪ࡮ࡲࡥࠡࠩࡾࢁࠬࡀࠠࡼࡿࠥỴ").format(bstack1111ll1l11l_opy_, e))
            return []
        _1111l1ll11l_opy_ = None
        _1111l111l1l_opy_ = None
        def _1111ll11lll_opy_():
            bstack1111ll1lll1_opy_ = {}
            bstack1111l1l11ll_opy_ = {}
            try:
                if self.bstack1111l1lll11_opy_.startswith(bstack1l1l11_opy_ (u"ࠨࡽࠪỵ")) and self.bstack1111l1lll11_opy_.endswith(bstack1l1l11_opy_ (u"ࠩࢀࠫỶ")):
                    bstack1111ll1lll1_opy_ = json.loads(self.bstack1111l1lll11_opy_)
                else:
                    bstack1111ll1lll1_opy_ = dict(item.split(bstack1l1l11_opy_ (u"ࠪ࠾ࠬỷ")) for item in self.bstack1111l1lll11_opy_.split(bstack1l1l11_opy_ (u"ࠫ࠱࠭Ỹ")) if bstack1l1l11_opy_ (u"ࠬࡀࠧỹ") in item) if self.bstack1111l1lll11_opy_ else {}
                if self.bstack1111l11l1l1_opy_.startswith(bstack1l1l11_opy_ (u"࠭ࡻࠨỺ")) and self.bstack1111l11l1l1_opy_.endswith(bstack1l1l11_opy_ (u"ࠧࡾࠩỻ")):
                    bstack1111l1l11ll_opy_ = json.loads(self.bstack1111l11l1l1_opy_)
                else:
                    bstack1111l1l11ll_opy_ = dict(item.split(bstack1l1l11_opy_ (u"ࠨ࠼ࠪỼ")) for item in self.bstack1111l11l1l1_opy_.split(bstack1l1l11_opy_ (u"ࠩ࠯ࠫỽ")) if bstack1l1l11_opy_ (u"ࠪ࠾ࠬỾ") in item) if self.bstack1111l11l1l1_opy_ else {}
            except json.JSONDecodeError as e:
                logger.error(bstack1l1l11_opy_ (u"ࠦࡊࡸࡲࡰࡴࠣࡴࡦࡸࡳࡪࡰࡪࠤ࡫࡫ࡡࡵࡷࡵࡩࠥࡨࡲࡢࡰࡦ࡬ࠥࡳࡡࡱࡲ࡬ࡲ࡬ࡹ࠺ࠡࡽࢀࠦỿ").format(e))
            logger.debug(bstack1l1l11_opy_ (u"ࠧࡌࡥࡢࡶࡸࡶࡪࠦࡢࡳࡣࡱࡧ࡭ࠦ࡭ࡢࡲࡳ࡭ࡳ࡭ࡳࠡࡨࡵࡳࡲࠦࡥ࡯ࡸ࠽ࠤࢀࢃࠬࠡࡅࡏࡍ࠿ࠦࡻࡾࠤἀ").format(bstack1111ll1lll1_opy_, bstack1111l1l11ll_opy_))
            return bstack1111ll1lll1_opy_, bstack1111l1l11ll_opy_
        if _1111l1ll11l_opy_ is None or _1111l111l1l_opy_ is None:
            _1111l1ll11l_opy_, _1111l111l1l_opy_ = _1111ll11lll_opy_()
        def bstack1111l1ll111_opy_(name, bstack1111l1111ll_opy_):
            if name in _1111l111l1l_opy_:
                return _1111l111l1l_opy_[name]
            if name in _1111l1ll11l_opy_:
                return _1111l1ll11l_opy_[name]
            if bstack1111l1111ll_opy_.get(bstack1l1l11_opy_ (u"࠭ࡦࡦࡣࡷࡹࡷ࡫ࡂࡳࡣࡱࡧ࡭࠭ἁ")):
                return bstack1111l1111ll_opy_[bstack1l1l11_opy_ (u"ࠧࡧࡧࡤࡸࡺࡸࡥࡃࡴࡤࡲࡨ࡮ࠧἂ")]
            return None
        if isinstance(data, dict):
            bstack1111l1l1l1l_opy_ = []
            bstack1111l111ll1_opy_ = re.compile(bstack1l1l11_opy_ (u"ࡳࠩࡡ࡟ࡆ࠳࡚࠱࠯࠼ࡣࡢ࠱ࠤࠨἃ"))
            for name, bstack1111l1111ll_opy_ in data.items():
                if not isinstance(bstack1111l1111ll_opy_, dict):
                    continue
                url = bstack1111l1111ll_opy_.get(bstack1l1l11_opy_ (u"ࠩࡸࡶࡱ࠭ἄ"))
                if url is None or (isinstance(url, str) and url.strip() == bstack1l1l11_opy_ (u"ࠪࠫἅ")):
                    logger.warning(bstack1l1l11_opy_ (u"ࠦࡗ࡫ࡰࡰࡵ࡬ࡸࡴࡸࡹࠡࡗࡕࡐࠥ࡯ࡳࠡ࡯࡬ࡷࡸ࡯࡮ࡨࠢࡩࡳࡷࠦࡳࡰࡷࡵࡧࡪࠦࠧࡼࡿࠪ࠾ࠥࢁࡽࠣἆ").format(name, bstack1111l1111ll_opy_))
                    continue
                if not bstack1111l111ll1_opy_.match(name):
                    logger.warning(bstack1l1l11_opy_ (u"ࠧࡏ࡮ࡷࡣ࡯࡭ࡩࠦࡳࡰࡷࡵࡧࡪࠦࡩࡥࡧࡱࡸ࡮࡬ࡩࡦࡴࠣࡪࡴࡸ࡭ࡢࡶࠣࡪࡴࡸࠠࠨࡽࢀࠫ࠿ࠦࡻࡾࠤἇ").format(name, bstack1111l1111ll_opy_))
                    continue
                if len(name) > 30 or len(name) < 1:
                    logger.warning(bstack1l1l11_opy_ (u"ࠨࡓࡰࡷࡵࡧࡪࠦࡩࡥࡧࡱࡸ࡮࡬ࡩࡦࡴࠣࠫࢀࢃࠧࠡ࡯ࡸࡷࡹࠦࡨࡢࡸࡨࠤࡦࠦ࡬ࡦࡰࡪࡸ࡭ࠦࡢࡦࡶࡺࡩࡪࡴࠠ࠲ࠢࡤࡲࡩࠦ࠳࠱ࠢࡦ࡬ࡦࡸࡡࡤࡶࡨࡶࡸ࠴ࠢἈ").format(name))
                    continue
                bstack1111l1111ll_opy_ = bstack1111l1111ll_opy_.copy()
                bstack1111l1111ll_opy_[bstack1l1l11_opy_ (u"ࠧ࡯ࡣࡰࡩࠬἉ")] = name
                bstack1111l1111ll_opy_[bstack1l1l11_opy_ (u"ࠨࡨࡨࡥࡹࡻࡲࡦࡄࡵࡥࡳࡩࡨࠨἊ")] = bstack1111l1ll111_opy_(name, bstack1111l1111ll_opy_)
                if not bstack1111l1111ll_opy_.get(bstack1l1l11_opy_ (u"ࠩࡩࡩࡦࡺࡵࡳࡧࡅࡶࡦࡴࡣࡩࠩἋ")) or bstack1111l1111ll_opy_.get(bstack1l1l11_opy_ (u"ࠪࡪࡪࡧࡴࡶࡴࡨࡆࡷࡧ࡮ࡤࡪࠪἌ")) == bstack1l1l11_opy_ (u"ࠫࠬἍ"):
                    logger.warning(bstack1l1l11_opy_ (u"ࠧࡌࡥࡢࡶࡸࡶࡪࠦࡢࡳࡣࡱࡧ࡭ࠦ࡮ࡰࡶࠣࡷࡵ࡫ࡣࡪࡨ࡬ࡩࡩࠦࡦࡰࡴࠣࡷࡴࡻࡲࡤࡧࠣࠫࢀࢃࠧ࠻ࠢࡾࢁࠧἎ").format(name, bstack1111l1111ll_opy_))
                    continue
                if bstack1111l1111ll_opy_.get(bstack1l1l11_opy_ (u"࠭ࡢࡢࡵࡨࡆࡷࡧ࡮ࡤࡪࠪἏ")) and bstack1111l1111ll_opy_[bstack1l1l11_opy_ (u"ࠧࡣࡣࡶࡩࡇࡸࡡ࡯ࡥ࡫ࠫἐ")] == bstack1111l1111ll_opy_[bstack1l1l11_opy_ (u"ࠨࡨࡨࡥࡹࡻࡲࡦࡄࡵࡥࡳࡩࡨࠨἑ")]:
                    logger.warning(bstack1l1l11_opy_ (u"ࠤࡉࡩࡦࡺࡵࡳࡧࠣࡦࡷࡧ࡮ࡤࡪࠣࡥࡳࡪࠠࡣࡣࡶࡩࠥࡨࡲࡢࡰࡦ࡬ࠥࡩࡡ࡯ࡰࡲࡸࠥࡨࡥࠡࡶ࡫ࡩࠥࡹࡡ࡮ࡧࠣࡪࡴࡸࠠࡴࡱࡸࡶࡨ࡫ࠠࠨࡽࢀࠫ࠿ࠦࡻࡾࠤἒ").format(name, bstack1111l1111ll_opy_))
                    continue
                bstack1111l1l1l1l_opy_.append(bstack1111l1111ll_opy_)
            return bstack1111l1l1l1l_opy_
        return data
    def bstack111l1111lll_opy_(self):
        data = {
            bstack1l1l11_opy_ (u"ࠪࡶࡺࡴ࡟ࡴ࡯ࡤࡶࡹࡥࡳࡦ࡮ࡨࡧࡹ࡯࡯࡯ࠩἓ"): {
                bstack1l1l11_opy_ (u"ࠫࡪࡴࡡࡣ࡮ࡨࡨࠬἔ"): self.bstack1111l1l111l_opy_(),
                bstack1l1l11_opy_ (u"ࠬࡳ࡯ࡥࡧࠪἕ"): self.bstack1111ll11111_opy_(),
                bstack1l1l11_opy_ (u"࠭ࡳࡰࡷࡵࡧࡪ࠭἖"): self.bstack1111lll1lll_opy_()
            }
        }
        return data
    def bstack1111l1ll1ll_opy_(self, config):
        bstack1111l11ll1l_opy_ = {}
        bstack1111l11ll1l_opy_[bstack1l1l11_opy_ (u"ࠧࡳࡷࡱࡣࡸࡳࡡࡳࡶࡢࡷࡪࡲࡥࡤࡶ࡬ࡳࡳ࠭἗")] = {
            bstack1l1l11_opy_ (u"ࠨࡧࡱࡥࡧࡲࡥࡥࠩἘ"): self.bstack1111l1l111l_opy_(),
            bstack1l1l11_opy_ (u"ࠩࡰࡳࡩ࡫ࠧἙ"): self.bstack1111ll11111_opy_()
        }
        bstack1111l11ll1l_opy_[bstack1l1l11_opy_ (u"ࠪࡶࡪࡸࡵ࡯ࡡࡳࡶࡪࡼࡩࡰࡷࡶࡰࡾࡥࡦࡢ࡫࡯ࡩࡩ࠭Ἒ")] = {
            bstack1l1l11_opy_ (u"ࠫࡪࡴࡡࡣ࡮ࡨࡨࠬἛ"): self.bstack1111l1111l1_opy_()
        }
        bstack1111l11ll1l_opy_[bstack1l1l11_opy_ (u"ࠬࡸࡵ࡯ࡡࡳࡶࡪࡼࡩࡰࡷࡶࡰࡾࡥࡦࡢ࡫࡯ࡩࡩࡥࡦࡪࡴࡶࡸࠬἜ")] = {
            bstack1l1l11_opy_ (u"࠭ࡥ࡯ࡣࡥࡰࡪࡪࠧἝ"): self.bstack1111l111lll_opy_()
        }
        bstack1111l11ll1l_opy_[bstack1l1l11_opy_ (u"ࠧࡴ࡭࡬ࡴࡤ࡬ࡡࡪ࡮࡬ࡲ࡬ࡥࡡ࡯ࡦࡢࡪࡱࡧ࡫ࡺࠩ἞")] = {
            bstack1l1l11_opy_ (u"ࠨࡧࡱࡥࡧࡲࡥࡥࠩ἟"): self.bstack1111l11llll_opy_()
        }
        if self.bstack1l11l1l1ll_opy_(config):
            bstack1111l11ll1l_opy_[bstack1l1l11_opy_ (u"ࠩࡵࡩࡹࡸࡹࡠࡶࡨࡷࡹࡹ࡟ࡰࡰࡢࡪࡦ࡯࡬ࡶࡴࡨࠫἠ")] = {
                bstack1l1l11_opy_ (u"ࠪࡩࡳࡧࡢ࡭ࡧࡧࠫἡ"): True,
                bstack1l1l11_opy_ (u"ࠫࡲࡧࡸࡠࡴࡨࡸࡷ࡯ࡥࡴࠩἢ"): self.bstack111lll11ll_opy_(config)
            }
        if self.bstack11l11ll1111_opy_(config):
            bstack1111l11ll1l_opy_[bstack1l1l11_opy_ (u"ࠬࡧࡢࡰࡴࡷࡣࡧࡻࡩ࡭ࡦࡢࡳࡳࡥࡦࡢ࡫࡯ࡹࡷ࡫ࠧἣ")] = {
                bstack1l1l11_opy_ (u"࠭ࡥ࡯ࡣࡥࡰࡪࡪࠧἤ"): True,
                bstack1l1l11_opy_ (u"ࠧ࡮ࡣࡻࡣ࡫ࡧࡩ࡭ࡷࡵࡩࡸ࠭ἥ"): self.bstack11l11l1ll1l_opy_(config)
            }
        return bstack1111l11ll1l_opy_
    def bstack1ll11l1ll1_opy_(self, config):
        bstack1l1l11_opy_ (u"ࠣࠤࠥࠎࠥࠦࠠࠡࠢࠣࠤࠥࡉ࡯࡭࡮ࡨࡧࡹࡹࠠࡣࡷ࡬ࡰࡩࠦࡤࡢࡶࡤࠤࡧࡿࠠ࡮ࡣ࡮࡭ࡳ࡭ࠠࡢࠢࡦࡥࡱࡲࠠࡵࡱࠣࡸ࡭࡫ࠠࡤࡱ࡯ࡰࡪࡩࡴ࠮ࡤࡸ࡭ࡱࡪ࠭ࡥࡣࡷࡥࠥ࡫࡮ࡥࡲࡲ࡭ࡳࡺ࠮ࠋࠢࠣࠤࠥࠦࠠࠡࠢࡄࡶ࡬ࡹ࠺ࠋࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࡢࡶ࡫࡯ࡨࡤࡻࡵࡪࡦࠣࠬࡸࡺࡲࠪ࠼ࠣࡘ࡭࡫ࠠࡖࡗࡌࡈࠥࡵࡦࠡࡶ࡫ࡩࠥࡨࡵࡪ࡮ࡧࠤࡹࡵࠠࡤࡱ࡯ࡰࡪࡩࡴࠡࡦࡤࡸࡦࠦࡦࡰࡴ࠱ࠎࠥࠦࠠࠡࠢࠣࠤࠥࡘࡥࡵࡷࡵࡲࡸࡀࠊࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࡪࡩࡤࡶ࠽ࠤࡗ࡫ࡳࡱࡱࡱࡷࡪࠦࡦࡳࡱࡰࠤࡹ࡮ࡥࠡࡥࡲࡰࡱ࡫ࡣࡵ࠯ࡥࡹ࡮ࡲࡤ࠮ࡦࡤࡸࡦࠦࡥ࡯ࡦࡳࡳ࡮ࡴࡴ࠭ࠢࡲࡶࠥࡔ࡯࡯ࡧࠣ࡭࡫ࠦࡦࡢ࡫࡯ࡩࡩ࠴ࠊࠡࠢࠣࠤࠥࠦࠠࠡࠤࠥࠦἦ")
        if not (config.get(bstack1l1l11_opy_ (u"ࠩࡩࡶࡦࡳࡥࡸࡱࡵ࡯ࠬἧ"), None) in bstack11l1l11llll_opy_ and self.bstack1111l1l111l_opy_()):
            return None
        bstack1111l11l111_opy_ = os.environ.get(bstack1l1l11_opy_ (u"ࠪࡆࡗࡕࡗࡔࡇࡕࡗ࡙ࡇࡃࡌࡡࡗࡉࡘ࡚ࡈࡖࡄࡢ࡙࡚ࡏࡄࠨἨ"), None)
        logger.debug(bstack1l1l11_opy_ (u"ࠦࡠࡩ࡯࡭࡮ࡨࡧࡹࡈࡵࡪ࡮ࡧࡈࡦࡺࡡ࡞ࠢࡆࡳࡱࡲࡥࡤࡶ࡬ࡲ࡬ࠦࡢࡶ࡫࡯ࡨࠥࡪࡡࡵࡣࠣࡪࡴࡸࠠࡣࡷ࡬ࡰࡩࠦࡕࡖࡋࡇ࠾ࠥࢁࡽࠣἩ").format(bstack1111l11l111_opy_))
        try:
            bstack11l1llll1ll_opy_ = bstack1l1l11_opy_ (u"ࠧࡺࡥࡴࡶࡲࡶࡨ࡮ࡥࡴࡶࡵࡥࡹ࡯࡯࡯࠱ࡤࡴ࡮࠵ࡶ࠲࠱ࡥࡹ࡮ࡲࡤࡴ࠱ࡾࢁ࠴ࡩ࡯࡭࡮ࡨࡧࡹ࠳ࡢࡶ࡫࡯ࡨ࠲ࡪࡡࡵࡣࠥἪ").format(bstack1111l11l111_opy_)
            payload = {
                bstack1l1l11_opy_ (u"ࠨࡰࡳࡱ࡭ࡩࡨࡺࡎࡢ࡯ࡨࠦἫ"): config.get(bstack1l1l11_opy_ (u"ࠧࡱࡴࡲ࡮ࡪࡩࡴࡏࡣࡰࡩࠬἬ"), bstack1l1l11_opy_ (u"ࠨࠩἭ")),
                bstack1l1l11_opy_ (u"ࠤࡥࡹ࡮ࡲࡤࡏࡣࡰࡩࠧἮ"): config.get(bstack1l1l11_opy_ (u"ࠪࡦࡺ࡯࡬ࡥࡐࡤࡱࡪ࠭Ἧ"), os.path.basename(os.path.abspath(os.getcwd()))),
                bstack1l1l11_opy_ (u"ࠦࡧࡻࡩ࡭ࡦࡕࡹࡳࡏࡤࡦࡰࡷ࡭࡫࡯ࡥࡳࠤἰ"): os.environ.get(bstack1l1l11_opy_ (u"ࠧࡈࡒࡐ࡙ࡖࡉࡗ࡙ࡔࡂࡅࡎࡣࡇ࡛ࡉࡍࡆࡢࡖ࡚ࡔ࡟ࡊࡆࡈࡒ࡙ࡏࡆࡊࡇࡕࠦἱ"), bstack1l1l11_opy_ (u"ࠨࠢἲ")),
                bstack1l1l11_opy_ (u"ࠢ࡯ࡱࡧࡩࡎࡴࡤࡦࡺࠥἳ"): int(os.environ.get(bstack1l1l11_opy_ (u"ࠣࡄࡕࡓ࡜࡙ࡅࡓࡕࡗࡅࡈࡑ࡟ࡏࡑࡇࡉࡤࡏࡎࡅࡇ࡛ࠦἴ")) or bstack1l1l11_opy_ (u"ࠤ࠳ࠦἵ")),
                bstack1l1l11_opy_ (u"ࠥࡸࡴࡺࡡ࡭ࡐࡲࡨࡪࡹࠢἶ"): int(os.environ.get(bstack1l1l11_opy_ (u"ࠦࡇࡘࡏࡘࡕࡈࡖࡘ࡚ࡁࡄࡍࡢࡘࡔ࡚ࡁࡍࡡࡑࡓࡉࡋ࡟ࡄࡑࡘࡒ࡙ࠨἷ")) or bstack1l1l11_opy_ (u"ࠧ࠷ࠢἸ")),
                bstack1l1l11_opy_ (u"ࠨࡨࡰࡵࡷࡍࡳ࡬࡯ࠣἹ"): get_host_info(),
            }
            logger.debug(bstack1l1l11_opy_ (u"ࠢ࡜ࡥࡲࡰࡱ࡫ࡣࡵࡄࡸ࡭ࡱࡪࡄࡢࡶࡤࡡ࡙ࠥࡥ࡯ࡦ࡬ࡲ࡬ࠦࡢࡶ࡫࡯ࡨࠥࡪࡡࡵࡣࠣࡴࡦࡿ࡬ࡰࡣࡧ࠾ࠥࢁࡽࠣἺ").format(payload))
            response = bstack11l1lll1ll1_opy_.bstack1111lll1111_opy_(bstack11l1llll1ll_opy_, payload)
            if response:
                logger.debug(bstack1l1l11_opy_ (u"ࠣ࡝ࡦࡳࡱࡲࡥࡤࡶࡅࡹ࡮ࡲࡤࡅࡣࡷࡥࡢࠦࡂࡶ࡫࡯ࡨࠥࡪࡡࡵࡣࠣࡧࡴࡲ࡬ࡦࡥࡷ࡭ࡴࡴࠠࡳࡧࡶࡴࡴࡴࡳࡦ࠼ࠣࡿࢂࠨἻ").format(response))
                return response
            else:
                logger.error(bstack1l1l11_opy_ (u"ࠤ࡞ࡧࡴࡲ࡬ࡦࡥࡷࡆࡺ࡯࡬ࡥࡆࡤࡸࡦࡣࠠࡇࡣ࡬ࡰࡪࡪࠠࡵࡱࠣࡧࡴࡲ࡬ࡦࡥࡷࠤࡧࡻࡩ࡭ࡦࠣࡨࡦࡺࡡࠡࡨࡲࡶࠥࡨࡵࡪ࡮ࡧࠤ࡚࡛ࡉࡅ࠼ࠣࡿࢂࠨἼ").format(bstack1111l11l111_opy_))
                return None
        except Exception as e:
            logger.error(bstack1l1l11_opy_ (u"ࠥ࡟ࡨࡵ࡬࡭ࡧࡦࡸࡇࡻࡩ࡭ࡦࡇࡥࡹࡧ࡝ࠡࡇࡻࡧࡪࡶࡴࡪࡱࡱࠤ࡮ࡴࠠࡤࡱ࡯ࡰࡪࡩࡴࡪࡰࡪࠤࡧࡻࡩ࡭ࡦࠣࡨࡦࡺࡡࠡࡨࡲࡶࠥࡨࡵࡪ࡮ࡧࠤ࡚࡛ࡉࡅࠢࡾࢁ࠿ࠦࡻࡾࠤἽ").format(bstack1111l11l111_opy_, e))
            return None