# coding: UTF-8
import sys
bstack1l11111_opy_ = sys.version_info [0] == 2
bstack11l11ll_opy_ = 2048
bstack111ll1l_opy_ = 7
def bstack1l1l11_opy_ (bstack11l1l_opy_):
    global bstack1l11_opy_
    bstack11l1111_opy_ = ord (bstack11l1l_opy_ [-1])
    bstack1l1ll1l_opy_ = bstack11l1l_opy_ [:-1]
    bstack11l11_opy_ = bstack11l1111_opy_ % len (bstack1l1ll1l_opy_)
    bstack1l1ll11_opy_ = bstack1l1ll1l_opy_ [:bstack11l11_opy_] + bstack1l1ll1l_opy_ [bstack11l11_opy_:]
    if bstack1l11111_opy_:
        bstack11lll1l_opy_ = unicode () .join ([unichr (ord (char) - bstack11l11ll_opy_ - (bstack11l111_opy_ + bstack11l1111_opy_) % bstack111ll1l_opy_) for bstack11l111_opy_, char in enumerate (bstack1l1ll11_opy_)])
    else:
        bstack11lll1l_opy_ = str () .join ([chr (ord (char) - bstack11l11ll_opy_ - (bstack11l111_opy_ + bstack11l1111_opy_) % bstack111ll1l_opy_) for bstack11l111_opy_, char in enumerate (bstack1l1ll11_opy_)])
    return eval (bstack11lll1l_opy_)
import os
from uuid import uuid4
from bstack_utils.helper import bstack11ll111l_opy_, bstack111lll1lll1_opy_
from bstack_utils.bstack1l1l1l1l11_opy_ import bstack1lllll1ll1l1_opy_
class bstack1111ll1ll1_opy_:
    def __init__(self, name=None, code=None, uuid=None, file_path=None, started_at=None, framework=None, tags=[], scope=[], bstack1llll1l1l1ll_opy_=None, bstack1llll1l1l11l_opy_=True, bstack1l1111111ll_opy_=None, bstack11ll1l1l11_opy_=None, result=None, duration=None, bstack1111lll1ll_opy_=None, meta={}):
        self.bstack1111lll1ll_opy_ = bstack1111lll1ll_opy_
        self.name = name
        self.code = code
        self.file_path = file_path
        self.uuid = uuid
        if not self.uuid and bstack1llll1l1l11l_opy_:
            self.uuid = uuid4().__str__()
        self.started_at = started_at
        self.framework = framework
        self.tags = tags
        self.scope = scope
        self.bstack1llll1l1l1ll_opy_ = bstack1llll1l1l1ll_opy_
        self.bstack1l1111111ll_opy_ = bstack1l1111111ll_opy_
        self.bstack11ll1l1l11_opy_ = bstack11ll1l1l11_opy_
        self.result = result
        self.duration = duration
        self.meta = meta
        self.hooks = []
    def bstack111l1111l1_opy_(self):
        if self.uuid:
            return self.uuid
        self.uuid = uuid4().__str__()
        return self.uuid
    def bstack111l1ll1ll_opy_(self, meta):
        self.meta = meta
    def bstack111ll111ll_opy_(self, hooks):
        self.hooks = hooks
    def bstack1llll1ll11ll_opy_(self):
        bstack1llll1l1ll1l_opy_ = os.path.relpath(self.file_path, start=os.getcwd())
        return {
            bstack1l1l11_opy_ (u"࠭ࡦࡪ࡮ࡨࡣࡳࡧ࡭ࡦࠩ₺"): bstack1llll1l1ll1l_opy_,
            bstack1l1l11_opy_ (u"ࠧ࡭ࡱࡦࡥࡹ࡯࡯࡯ࠩ₻"): bstack1llll1l1ll1l_opy_,
            bstack1l1l11_opy_ (u"ࠨࡸࡦࡣ࡫࡯࡬ࡦࡲࡤࡸ࡭࠭₼"): bstack1llll1l1ll1l_opy_
        }
    def set(self, **kwargs):
        for key, val in kwargs.items():
            if not hasattr(self, key):
                raise TypeError(bstack1l1l11_opy_ (u"ࠤࡘࡲࡪࡾࡰࡦࡥࡷࡩࡩࠦࡡࡳࡩࡸࡱࡪࡴࡴ࠻ࠢࠥ₽") + key)
            setattr(self, key, val)
    def bstack1llll1ll11l1_opy_(self):
        return {
            bstack1l1l11_opy_ (u"ࠪࡲࡦࡳࡥࠨ₾"): self.name,
            bstack1l1l11_opy_ (u"ࠫࡧࡵࡤࡺࠩ₿"): {
                bstack1l1l11_opy_ (u"ࠬࡲࡡ࡯ࡩࠪ⃀"): bstack1l1l11_opy_ (u"࠭ࡰࡺࡶ࡫ࡳࡳ࠭⃁"),
                bstack1l1l11_opy_ (u"ࠧࡤࡱࡧࡩࠬ⃂"): self.code
            },
            bstack1l1l11_opy_ (u"ࠨࡵࡦࡳࡵ࡫ࡳࠨ⃃"): self.scope,
            bstack1l1l11_opy_ (u"ࠩࡷࡥ࡬ࡹࠧ⃄"): self.tags,
            bstack1l1l11_opy_ (u"ࠪࡪࡷࡧ࡭ࡦࡹࡲࡶࡰ࠭⃅"): self.framework,
            bstack1l1l11_opy_ (u"ࠫࡸࡺࡡࡳࡶࡨࡨࡤࡧࡴࠨ⃆"): self.started_at
        }
    def bstack1llll1l1l1l1_opy_(self):
        return {
         bstack1l1l11_opy_ (u"ࠬࡳࡥࡵࡣࠪ⃇"): self.meta
        }
    def bstack1llll1l11l1l_opy_(self):
        return {
            bstack1l1l11_opy_ (u"࠭ࡣࡶࡵࡷࡳࡲࡘࡥࡳࡷࡱࡔࡦࡸࡡ࡮ࠩ⃈"): {
                bstack1l1l11_opy_ (u"ࠧࡳࡧࡵࡹࡳࡥ࡮ࡢ࡯ࡨࠫ⃉"): self.bstack1llll1l1l1ll_opy_
            }
        }
    def bstack1llll1l11ll1_opy_(self, bstack1llll1ll111l_opy_, details):
        step = next(filter(lambda st: st[bstack1l1l11_opy_ (u"ࠨ࡫ࡧࠫ⃊")] == bstack1llll1ll111l_opy_, self.meta[bstack1l1l11_opy_ (u"ࠩࡶࡸࡪࡶࡳࠨ⃋")]), None)
        step.update(details)
    def bstack11ll111111_opy_(self, bstack1llll1ll111l_opy_):
        step = next(filter(lambda st: st[bstack1l1l11_opy_ (u"ࠪ࡭ࡩ࠭⃌")] == bstack1llll1ll111l_opy_, self.meta[bstack1l1l11_opy_ (u"ࠫࡸࡺࡥࡱࡵࠪ⃍")]), None)
        step.update({
            bstack1l1l11_opy_ (u"ࠬࡹࡴࡢࡴࡷࡩࡩࡥࡡࡵࠩ⃎"): bstack11ll111l_opy_()
        })
    def bstack111ll1111l_opy_(self, bstack1llll1ll111l_opy_, result, duration=None):
        bstack1l1111111ll_opy_ = bstack11ll111l_opy_()
        if bstack1llll1ll111l_opy_ is not None and self.meta.get(bstack1l1l11_opy_ (u"࠭ࡳࡵࡧࡳࡷࠬ⃏")):
            step = next(filter(lambda st: st[bstack1l1l11_opy_ (u"ࠧࡪࡦࠪ⃐")] == bstack1llll1ll111l_opy_, self.meta[bstack1l1l11_opy_ (u"ࠨࡵࡷࡩࡵࡹࠧ⃑")]), None)
            step.update({
                bstack1l1l11_opy_ (u"ࠩࡩ࡭ࡳ࡯ࡳࡩࡧࡧࡣࡦࡺ⃒ࠧ"): bstack1l1111111ll_opy_,
                bstack1l1l11_opy_ (u"ࠪࡨࡺࡸࡡࡵ࡫ࡲࡲ⃓ࠬ"): duration if duration else bstack111lll1lll1_opy_(step[bstack1l1l11_opy_ (u"ࠫࡸࡺࡡࡳࡶࡨࡨࡤࡧࡴࠨ⃔")], bstack1l1111111ll_opy_),
                bstack1l1l11_opy_ (u"ࠬࡸࡥࡴࡷ࡯ࡸࠬ⃕"): result.result,
                bstack1l1l11_opy_ (u"࠭ࡦࡢ࡫࡯ࡹࡷ࡫ࠧ⃖"): str(result.exception) if result.exception else None
            })
    def add_step(self, bstack1llll1l1ll11_opy_):
        if self.meta.get(bstack1l1l11_opy_ (u"ࠧࡴࡶࡨࡴࡸ࠭⃗")):
            self.meta[bstack1l1l11_opy_ (u"ࠨࡵࡷࡩࡵࡹ⃘ࠧ")].append(bstack1llll1l1ll11_opy_)
        else:
            self.meta[bstack1l1l11_opy_ (u"ࠩࡶࡸࡪࡶࡳࠨ⃙")] = [ bstack1llll1l1ll11_opy_ ]
    def bstack1llll1l1lll1_opy_(self):
        return {
            bstack1l1l11_opy_ (u"ࠪࡹࡺ࡯ࡤࠨ⃚"): self.bstack111l1111l1_opy_(),
            bstack1l1l11_opy_ (u"ࠫࡷ࡫ࡳࡶ࡮ࡷࠫ⃛"): bstack1l1l11_opy_ (u"ࠬࡶࡥ࡯ࡦ࡬ࡲ࡬࠭⃜"),
            **self.bstack1llll1ll11l1_opy_(),
            **self.bstack1llll1ll11ll_opy_(),
            **self.bstack1llll1l1l1l1_opy_()
        }
    def bstack1llll1l11l11_opy_(self):
        if not self.result:
            return {}
        data = {
            bstack1l1l11_opy_ (u"࠭ࡦࡪࡰ࡬ࡷ࡭࡫ࡤࡠࡣࡷࠫ⃝"): self.bstack1l1111111ll_opy_,
            bstack1l1l11_opy_ (u"ࠧࡥࡷࡵࡥࡹ࡯࡯࡯ࡡ࡬ࡲࡤࡳࡳࠨ⃞"): self.duration,
            bstack1l1l11_opy_ (u"ࠨࡴࡨࡷࡺࡲࡴࠨ⃟"): self.result.result
        }
        if data[bstack1l1l11_opy_ (u"ࠩࡵࡩࡸࡻ࡬ࡵࠩ⃠")] == bstack1l1l11_opy_ (u"ࠪࡪࡦ࡯࡬ࡦࡦࠪ⃡"):
            data[bstack1l1l11_opy_ (u"ࠫ࡫ࡧࡩ࡭ࡷࡵࡩࡤࡺࡹࡱࡧࠪ⃢")] = self.result.bstack1llllll1ll1_opy_()
            data[bstack1l1l11_opy_ (u"ࠬ࡬ࡡࡪ࡮ࡸࡶࡪ࠭⃣")] = [{bstack1l1l11_opy_ (u"࠭ࡢࡢࡥ࡮ࡸࡷࡧࡣࡦࠩ⃤"): self.result.bstack111ll11l1l1_opy_()}]
        return data
    def bstack1llll1ll1111_opy_(self):
        return {
            bstack1l1l11_opy_ (u"ࠧࡶࡷ࡬ࡨ⃥ࠬ"): self.bstack111l1111l1_opy_(),
            **self.bstack1llll1ll11l1_opy_(),
            **self.bstack1llll1ll11ll_opy_(),
            **self.bstack1llll1l11l11_opy_(),
            **self.bstack1llll1l1l1l1_opy_()
        }
    def bstack111l111l11_opy_(self, event, result=None):
        if result:
            self.result = result
        if bstack1l1l11_opy_ (u"ࠨࡕࡷࡥࡷࡺࡥࡥ⃦ࠩ") in event:
            return self.bstack1llll1l1lll1_opy_()
        elif bstack1l1l11_opy_ (u"ࠩࡉ࡭ࡳ࡯ࡳࡩࡧࡧࠫ⃧") in event:
            return self.bstack1llll1ll1111_opy_()
    def bstack111l1l1l11_opy_(self):
        pass
    def stop(self, time=None, duration=None, result=None):
        self.bstack1l1111111ll_opy_ = time if time else bstack11ll111l_opy_()
        self.duration = duration if duration else bstack111lll1lll1_opy_(self.started_at, self.bstack1l1111111ll_opy_)
        if result:
            self.result = result
class bstack111ll11ll1_opy_(bstack1111ll1ll1_opy_):
    def __init__(self, hooks=[], bstack111l1ll11l_opy_={}, *args, **kwargs):
        self.hooks = hooks
        self.bstack111l1ll11l_opy_ = bstack111l1ll11l_opy_
        super().__init__(*args, **kwargs, bstack11ll1l1l11_opy_=bstack1l1l11_opy_ (u"ࠪࡸࡪࡹࡴࠨ⃨"))
    @classmethod
    def bstack1llll1l1l111_opy_(cls, scenario, feature, test, **kwargs):
        steps = []
        for step in scenario.steps:
            steps.append({
                bstack1l1l11_opy_ (u"ࠫ࡮ࡪࠧ⃩"): id(step),
                bstack1l1l11_opy_ (u"ࠬࡺࡥࡹࡶ⃪ࠪ"): step.name,
                bstack1l1l11_opy_ (u"࠭࡫ࡦࡻࡺࡳࡷࡪ⃫ࠧ"): step.keyword,
            })
        return bstack111ll11ll1_opy_(
            **kwargs,
            meta={
                bstack1l1l11_opy_ (u"ࠧࡧࡧࡤࡸࡺࡸࡥࠨ⃬"): {
                    bstack1l1l11_opy_ (u"ࠨࡰࡤࡱࡪ⃭࠭"): feature.name,
                    bstack1l1l11_opy_ (u"ࠩࡳࡥࡹ࡮⃮ࠧ"): feature.filename,
                    bstack1l1l11_opy_ (u"ࠪࡨࡪࡹࡣࡳ࡫ࡳࡸ࡮ࡵ࡮ࠨ⃯"): feature.description
                },
                bstack1l1l11_opy_ (u"ࠫࡸࡩࡥ࡯ࡣࡵ࡭ࡴ࠭⃰"): {
                    bstack1l1l11_opy_ (u"ࠬࡴࡡ࡮ࡧࠪ⃱"): scenario.name
                },
                bstack1l1l11_opy_ (u"࠭ࡳࡵࡧࡳࡷࠬ⃲"): steps,
                bstack1l1l11_opy_ (u"ࠧࡦࡺࡤࡱࡵࡲࡥࡴࠩ⃳"): bstack1lllll1ll1l1_opy_(test)
            }
        )
    def bstack1llll1l11lll_opy_(self):
        return {
            bstack1l1l11_opy_ (u"ࠨࡪࡲࡳࡰࡹࠧ⃴"): self.hooks
        }
    def bstack1llll1ll1l11_opy_(self):
        if self.bstack111l1ll11l_opy_:
            return {
                bstack1l1l11_opy_ (u"ࠩ࡬ࡲࡹ࡫ࡧࡳࡣࡷ࡭ࡴࡴࡳࠨ⃵"): self.bstack111l1ll11l_opy_
            }
        return {}
    def bstack1llll1ll1111_opy_(self):
        return {
            **super().bstack1llll1ll1111_opy_(),
            **self.bstack1llll1l11lll_opy_()
        }
    def bstack1llll1l1lll1_opy_(self):
        return {
            **super().bstack1llll1l1lll1_opy_(),
            **self.bstack1llll1ll1l11_opy_()
        }
    def bstack111l1l1l11_opy_(self):
        return bstack1l1l11_opy_ (u"ࠪࡸࡪࡹࡴࡠࡴࡸࡲࠬ⃶")
class bstack111ll1ll1l_opy_(bstack1111ll1ll1_opy_):
    def __init__(self, hook_type, *args,bstack111l1ll11l_opy_={}, **kwargs):
        self.hook_type = hook_type
        self.bstack1l1ll1lll1l_opy_ = None
        self.bstack111l1ll11l_opy_ = bstack111l1ll11l_opy_
        super().__init__(*args, **kwargs, bstack11ll1l1l11_opy_=bstack1l1l11_opy_ (u"ࠫ࡭ࡵ࡯࡬ࠩ⃷"))
    def bstack1111ll1111_opy_(self):
        return self.hook_type
    def bstack1llll1l1llll_opy_(self):
        return {
            bstack1l1l11_opy_ (u"ࠬ࡮࡯ࡰ࡭ࡢࡸࡾࡶࡥࠨ⃸"): self.hook_type
        }
    def bstack1llll1ll1111_opy_(self):
        return {
            **super().bstack1llll1ll1111_opy_(),
            **self.bstack1llll1l1llll_opy_()
        }
    def bstack1llll1l1lll1_opy_(self):
        return {
            **super().bstack1llll1l1lll1_opy_(),
            bstack1l1l11_opy_ (u"࠭ࡴࡦࡵࡷࡣࡷࡻ࡮ࡠ࡫ࡧࠫ⃹"): self.bstack1l1ll1lll1l_opy_,
            **self.bstack1llll1l1llll_opy_()
        }
    def bstack111l1l1l11_opy_(self):
        return bstack1l1l11_opy_ (u"ࠧࡩࡱࡲ࡯ࡤࡸࡵ࡯ࠩ⃺")
    def bstack111l1ll111_opy_(self, bstack1l1ll1lll1l_opy_):
        self.bstack1l1ll1lll1l_opy_ = bstack1l1ll1lll1l_opy_