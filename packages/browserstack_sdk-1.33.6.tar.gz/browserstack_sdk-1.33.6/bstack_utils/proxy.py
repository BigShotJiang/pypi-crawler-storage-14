# coding: UTF-8
import sys
bstack1l11111_opy_ = sys.version_info [0] == 2
bstack11l11ll_opy_ = 2048
bstack111ll1l_opy_ = 7
def bstack1l1l11_opy_ (bstack11l1l_opy_):
    global bstack1l11_opy_
    bstack11l1111_opy_ = ord (bstack11l1l_opy_ [-1])
    bstack1l1ll1l_opy_ = bstack11l1l_opy_ [:-1]
    bstack11l11_opy_ = bstack11l1111_opy_ % len (bstack1l1ll1l_opy_)
    bstack1l1ll11_opy_ = bstack1l1ll1l_opy_ [:bstack11l11_opy_] + bstack1l1ll1l_opy_ [bstack11l11_opy_:]
    if bstack1l11111_opy_:
        bstack11lll1l_opy_ = unicode () .join ([unichr (ord (char) - bstack11l11ll_opy_ - (bstack11l111_opy_ + bstack11l1111_opy_) % bstack111ll1l_opy_) for bstack11l111_opy_, char in enumerate (bstack1l1ll11_opy_)])
    else:
        bstack11lll1l_opy_ = str () .join ([chr (ord (char) - bstack11l11ll_opy_ - (bstack11l111_opy_ + bstack11l1111_opy_) % bstack111ll1l_opy_) for bstack11l111_opy_, char in enumerate (bstack1l1ll11_opy_)])
    return eval (bstack11lll1l_opy_)
import os
from urllib.parse import urlparse
from bstack_utils.config import Config
from bstack_utils.messages import bstack111l111ll11_opy_
bstack11l111l1l1_opy_ = Config.bstack11lll1l1l_opy_()
def bstack1llllll11111_opy_(url):
    try:
        result = urlparse(url)
        return all([result.scheme, result.netloc])
    except:
        return False
def bstack1llllll11l1l_opy_(bstack1llllll11l11_opy_, bstack1llllll111ll_opy_):
    from pypac import get_pac
    from pypac import PACSession
    from pypac.parser import PACFile
    import socket
    if os.path.isfile(bstack1llllll11l11_opy_):
        with open(bstack1llllll11l11_opy_) as f:
            pac = PACFile(f.read())
    elif bstack1llllll11111_opy_(bstack1llllll11l11_opy_):
        pac = get_pac(url=bstack1llllll11l11_opy_)
    else:
        raise Exception(bstack1l1l11_opy_ (u"ࠧࡑࡣࡦࠤ࡫࡯࡬ࡦࠢࡧࡳࡪࡹࠠ࡯ࡱࡷࠤࡪࡾࡩࡴࡶ࠽ࠤࢀࢃࠧΊ").format(bstack1llllll11l11_opy_))
    session = PACSession(pac)
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect((bstack1l1l11_opy_ (u"ࠣ࠺࠱࠼࠳࠾࠮࠹ࠤ῜"), 80))
        bstack1llllll111l1_opy_ = s.getsockname()[0]
        s.close()
    except:
        bstack1llllll111l1_opy_ = bstack1l1l11_opy_ (u"ࠩ࠳࠲࠵࠴࠰࠯࠲ࠪ῝")
    proxy_url = session.get_pac().find_proxy_for_url(bstack1llllll111ll_opy_, bstack1llllll111l1_opy_)
    return proxy_url
def bstack1l1l1ll1l_opy_(config):
    return bstack1l1l11_opy_ (u"ࠪ࡬ࡹࡺࡰࡑࡴࡲࡼࡾ࠭῞") in config or bstack1l1l11_opy_ (u"ࠫ࡭ࡺࡴࡱࡵࡓࡶࡴࡾࡹࠨ῟") in config
def bstack1l1llllll1_opy_(config):
    if not bstack1l1l1ll1l_opy_(config):
        return
    if config.get(bstack1l1l11_opy_ (u"ࠬ࡮ࡴࡵࡲࡓࡶࡴࡾࡹࠨῠ")):
        return config.get(bstack1l1l11_opy_ (u"࠭ࡨࡵࡶࡳࡔࡷࡵࡸࡺࠩῡ"))
    if config.get(bstack1l1l11_opy_ (u"ࠧࡩࡶࡷࡴࡸࡖࡲࡰࡺࡼࠫῢ")):
        return config.get(bstack1l1l11_opy_ (u"ࠨࡪࡷࡸࡵࡹࡐࡳࡱࡻࡽࠬΰ"))
def bstack1l1llllll_opy_(config, bstack1llllll111ll_opy_):
    proxy = bstack1l1llllll1_opy_(config)
    proxies = {}
    if config.get(bstack1l1l11_opy_ (u"ࠩ࡫ࡸࡹࡶࡐࡳࡱࡻࡽࠬῤ")) or config.get(bstack1l1l11_opy_ (u"ࠪ࡬ࡹࡺࡰࡴࡒࡵࡳࡽࡿࠧῥ")):
        if proxy.endswith(bstack1l1l11_opy_ (u"ࠫ࠳ࡶࡡࡤࠩῦ")):
            proxies = bstack1l1ll1ll1l_opy_(proxy, bstack1llllll111ll_opy_)
        else:
            proxies = {
                bstack1l1l11_opy_ (u"ࠬ࡮ࡴࡵࡲࡶࠫῧ"): proxy
            }
    bstack11l111l1l1_opy_.bstack1lll1111l_opy_(bstack1l1l11_opy_ (u"࠭ࡰࡳࡱࡻࡽࡘ࡫ࡴࡵ࡫ࡱ࡫ࡸ࠭Ῠ"), proxies)
    return proxies
def bstack1l1ll1ll1l_opy_(bstack1llllll11l11_opy_, bstack1llllll111ll_opy_):
    proxies = {}
    global bstack1llllll11ll1_opy_
    if bstack1l1l11_opy_ (u"ࠧࡑࡃࡆࡣࡕࡘࡏ࡙࡛ࠪῩ") in globals():
        return bstack1llllll11ll1_opy_
    try:
        proxy = bstack1llllll11l1l_opy_(bstack1llllll11l11_opy_, bstack1llllll111ll_opy_)
        if bstack1l1l11_opy_ (u"ࠣࡆࡌࡖࡊࡉࡔࠣῪ") in proxy:
            proxies = {}
        elif bstack1l1l11_opy_ (u"ࠤࡋࡘ࡙ࡖࠢΎ") in proxy or bstack1l1l11_opy_ (u"ࠥࡌ࡙࡚ࡐࡔࠤῬ") in proxy or bstack1l1l11_opy_ (u"ࠦࡘࡕࡃࡌࡕࠥ῭") in proxy:
            bstack1llllll1111l_opy_ = proxy.split(bstack1l1l11_opy_ (u"ࠧࠦࠢ΅"))
            if bstack1l1l11_opy_ (u"ࠨ࠺࠰࠱ࠥ`") in bstack1l1l11_opy_ (u"ࠢࠣ῰").join(bstack1llllll1111l_opy_[1:]):
                proxies = {
                    bstack1l1l11_opy_ (u"ࠨࡪࡷࡸࡵࡹࠧ῱"): bstack1l1l11_opy_ (u"ࠤࠥῲ").join(bstack1llllll1111l_opy_[1:])
                }
            else:
                proxies = {
                    bstack1l1l11_opy_ (u"ࠪ࡬ࡹࡺࡰࡴࠩῳ"): str(bstack1llllll1111l_opy_[0]).lower() + bstack1l1l11_opy_ (u"ࠦ࠿࠵࠯ࠣῴ") + bstack1l1l11_opy_ (u"ࠧࠨ῵").join(bstack1llllll1111l_opy_[1:])
                }
        elif bstack1l1l11_opy_ (u"ࠨࡐࡓࡑ࡛࡝ࠧῶ") in proxy:
            bstack1llllll1111l_opy_ = proxy.split(bstack1l1l11_opy_ (u"ࠢࠡࠤῷ"))
            if bstack1l1l11_opy_ (u"ࠣ࠼࠲࠳ࠧῸ") in bstack1l1l11_opy_ (u"ࠤࠥΌ").join(bstack1llllll1111l_opy_[1:]):
                proxies = {
                    bstack1l1l11_opy_ (u"ࠪ࡬ࡹࡺࡰࡴࠩῺ"): bstack1l1l11_opy_ (u"ࠦࠧΏ").join(bstack1llllll1111l_opy_[1:])
                }
            else:
                proxies = {
                    bstack1l1l11_opy_ (u"ࠬ࡮ࡴࡵࡲࡶࠫῼ"): bstack1l1l11_opy_ (u"ࠨࡨࡵࡶࡳ࠾࠴࠵ࠢ´") + bstack1l1l11_opy_ (u"ࠢࠣ῾").join(bstack1llllll1111l_opy_[1:])
                }
        else:
            proxies = {
                bstack1l1l11_opy_ (u"ࠨࡪࡷࡸࡵࡹࠧ῿"): proxy
            }
    except Exception as e:
        print(bstack1l1l11_opy_ (u"ࠤࡶࡳࡲ࡫ࠠࡦࡴࡵࡳࡷࠨ "), bstack111l111ll11_opy_.format(bstack1llllll11l11_opy_, str(e)))
    bstack1llllll11ll1_opy_ = proxies
    return proxies