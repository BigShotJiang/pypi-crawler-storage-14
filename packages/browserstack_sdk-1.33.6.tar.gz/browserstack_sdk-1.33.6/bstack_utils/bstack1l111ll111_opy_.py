# coding: UTF-8
import sys
bstack1l11111_opy_ = sys.version_info [0] == 2
bstack11l11ll_opy_ = 2048
bstack111ll1l_opy_ = 7
def bstack1l1l11_opy_ (bstack11l1l_opy_):
    global bstack1l11_opy_
    bstack11l1111_opy_ = ord (bstack11l1l_opy_ [-1])
    bstack1l1ll1l_opy_ = bstack11l1l_opy_ [:-1]
    bstack11l11_opy_ = bstack11l1111_opy_ % len (bstack1l1ll1l_opy_)
    bstack1l1ll11_opy_ = bstack1l1ll1l_opy_ [:bstack11l11_opy_] + bstack1l1ll1l_opy_ [bstack11l11_opy_:]
    if bstack1l11111_opy_:
        bstack11lll1l_opy_ = unicode () .join ([unichr (ord (char) - bstack11l11ll_opy_ - (bstack11l111_opy_ + bstack11l1111_opy_) % bstack111ll1l_opy_) for bstack11l111_opy_, char in enumerate (bstack1l1ll11_opy_)])
    else:
        bstack11lll1l_opy_ = str () .join ([chr (ord (char) - bstack11l11ll_opy_ - (bstack11l111_opy_ + bstack11l1111_opy_) % bstack111ll1l_opy_) for bstack11l111_opy_, char in enumerate (bstack1l1ll11_opy_)])
    return eval (bstack11lll1l_opy_)
from browserstack_sdk.bstack1l11l11l1_opy_ import bstack11l1ll1l11_opy_
from browserstack_sdk.bstack111l1l11l1_opy_ import RobotHandler
def bstack111111ll_opy_(framework):
    if framework.lower() == bstack1l1l11_opy_ (u"ࠬࡶࡹࡵࡧࡶࡸࠬ᭤"):
        return bstack11l1ll1l11_opy_.version()
    elif framework.lower() == bstack1l1l11_opy_ (u"࠭ࡲࡰࡤࡲࡸࠬ᭥"):
        return RobotHandler.version()
    elif framework.lower() == bstack1l1l11_opy_ (u"ࠧࡣࡧ࡫ࡥࡻ࡫ࠧ᭦"):
        import behave
        return behave.__version__
    else:
        return bstack1l1l11_opy_ (u"ࠨࡷࡱ࡯ࡳࡵࡷ࡯ࠩ᭧")
def bstack1ll111l11l_opy_():
    import importlib.metadata
    framework_name = []
    framework_version = []
    try:
        from selenium import webdriver
        framework_name.append(bstack1l1l11_opy_ (u"ࠩࡶࡩࡱ࡫࡮ࡪࡷࡰࠫ᭨"))
        framework_version.append(importlib.metadata.version(bstack1l1l11_opy_ (u"ࠥࡷࡪࡲࡥ࡯࡫ࡸࡱࠧ᭩")))
    except:
        pass
    try:
        import playwright
        framework_name.append(bstack1l1l11_opy_ (u"ࠫࡵࡲࡡࡺࡹࡵ࡭࡬࡮ࡴࠨ᭪"))
        framework_version.append(importlib.metadata.version(bstack1l1l11_opy_ (u"ࠧࡶ࡬ࡢࡻࡺࡶ࡮࡭ࡨࡵࠤ᭫")))
    except:
        pass
    return {
        bstack1l1l11_opy_ (u"࠭࡮ࡢ࡯ࡨ᭬ࠫ"): bstack1l1l11_opy_ (u"ࠧࡠࠩ᭭").join(framework_name),
        bstack1l1l11_opy_ (u"ࠨࡸࡨࡶࡸ࡯࡯࡯ࠩ᭮"): bstack1l1l11_opy_ (u"ࠩࡢࠫ᭯").join(framework_version)
    }