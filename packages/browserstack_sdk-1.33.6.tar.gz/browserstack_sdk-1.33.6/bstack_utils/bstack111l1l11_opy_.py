# coding: UTF-8
import sys
bstack1l11111_opy_ = sys.version_info [0] == 2
bstack11l11ll_opy_ = 2048
bstack111ll1l_opy_ = 7
def bstack1l1l11_opy_ (bstack11l1l_opy_):
    global bstack1l11_opy_
    bstack11l1111_opy_ = ord (bstack11l1l_opy_ [-1])
    bstack1l1ll1l_opy_ = bstack11l1l_opy_ [:-1]
    bstack11l11_opy_ = bstack11l1111_opy_ % len (bstack1l1ll1l_opy_)
    bstack1l1ll11_opy_ = bstack1l1ll1l_opy_ [:bstack11l11_opy_] + bstack1l1ll1l_opy_ [bstack11l11_opy_:]
    if bstack1l11111_opy_:
        bstack11lll1l_opy_ = unicode () .join ([unichr (ord (char) - bstack11l11ll_opy_ - (bstack11l111_opy_ + bstack11l1111_opy_) % bstack111ll1l_opy_) for bstack11l111_opy_, char in enumerate (bstack1l1ll11_opy_)])
    else:
        bstack11lll1l_opy_ = str () .join ([chr (ord (char) - bstack11l11ll_opy_ - (bstack11l111_opy_ + bstack11l1111_opy_) % bstack111ll1l_opy_) for bstack11l111_opy_, char in enumerate (bstack1l1ll11_opy_)])
    return eval (bstack11lll1l_opy_)
from bstack_utils.constants import bstack11l1llll1l1_opy_
def bstack1l1ll1lll1_opy_(bstack11l1llll1ll_opy_):
    from browserstack_sdk.sdk_cli.cli import cli
    from bstack_utils.helper import bstack11l1l1l1_opy_
    host = bstack11l1l1l1_opy_(cli.config, [bstack1l1l11_opy_ (u"ࠢࡢࡲ࡬ࡷࠧ៊"), bstack1l1l11_opy_ (u"ࠣࡣࡸࡸࡴࡳࡡࡵࡧࠥ់"), bstack1l1l11_opy_ (u"ࠤࡤࡴ࡮ࠨ៌")], bstack11l1llll1l1_opy_)
    return bstack1l1l11_opy_ (u"ࠪࡿࢂ࠵ࡻࡾࠩ៍").format(host, bstack11l1llll1ll_opy_)