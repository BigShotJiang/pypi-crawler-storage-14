# coding: UTF-8
import sys
bstack1l11111_opy_ = sys.version_info [0] == 2
bstack11l11ll_opy_ = 2048
bstack111ll1l_opy_ = 7
def bstack1l1l11_opy_ (bstack11l1l_opy_):
    global bstack1l11_opy_
    bstack11l1111_opy_ = ord (bstack11l1l_opy_ [-1])
    bstack1l1ll1l_opy_ = bstack11l1l_opy_ [:-1]
    bstack11l11_opy_ = bstack11l1111_opy_ % len (bstack1l1ll1l_opy_)
    bstack1l1ll11_opy_ = bstack1l1ll1l_opy_ [:bstack11l11_opy_] + bstack1l1ll1l_opy_ [bstack11l11_opy_:]
    if bstack1l11111_opy_:
        bstack11lll1l_opy_ = unicode () .join ([unichr (ord (char) - bstack11l11ll_opy_ - (bstack11l111_opy_ + bstack11l1111_opy_) % bstack111ll1l_opy_) for bstack11l111_opy_, char in enumerate (bstack1l1ll11_opy_)])
    else:
        bstack11lll1l_opy_ = str () .join ([chr (ord (char) - bstack11l11ll_opy_ - (bstack11l111_opy_ + bstack11l1111_opy_) % bstack111ll1l_opy_) for bstack11l111_opy_, char in enumerate (bstack1l1ll11_opy_)])
    return eval (bstack11lll1l_opy_)
import os
import json
from bstack_utils.bstack1l1lll1l_opy_ import get_logger
logger = get_logger(__name__)
class bstack11ll1111111_opy_(object):
  bstack1l1l1l1ll1_opy_ = os.path.join(os.path.expanduser(bstack1l1l11_opy_ (u"࠭ࡾࠨឭ")), bstack1l1l11_opy_ (u"ࠧ࠯ࡤࡵࡳࡼࡹࡥࡳࡵࡷࡥࡨࡱࠧឮ"))
  bstack11l1lllll1l_opy_ = os.path.join(bstack1l1l1l1ll1_opy_, bstack1l1l11_opy_ (u"ࠨࡥࡲࡱࡲࡧ࡮ࡥࡵ࠱࡮ࡸࡵ࡮ࠨឯ"))
  commands_to_wrap = None
  perform_scan = None
  bstack1lll11lll_opy_ = None
  bstack111ll1l1_opy_ = None
  bstack11ll11111l1_opy_ = None
  bstack11ll11l11ll_opy_ = None
  def __new__(cls):
    if not hasattr(cls, bstack1l1l11_opy_ (u"ࠩ࡬ࡲࡸࡺࡡ࡯ࡥࡨࠫឰ")):
      cls.instance = super(bstack11ll1111111_opy_, cls).__new__(cls)
      cls.instance.bstack11l1lllll11_opy_()
    return cls.instance
  def bstack11l1lllll11_opy_(self):
    try:
      with open(self.bstack11l1lllll1l_opy_, bstack1l1l11_opy_ (u"ࠪࡶࠬឱ")) as bstack11ll11ll1_opy_:
        bstack11l1llllll1_opy_ = bstack11ll11ll1_opy_.read()
        data = json.loads(bstack11l1llllll1_opy_)
        if bstack1l1l11_opy_ (u"ࠫࡨࡵ࡭࡮ࡣࡱࡨࡸ࠭ឲ") in data:
          self.bstack11ll1111ll1_opy_(data[bstack1l1l11_opy_ (u"ࠬࡩ࡯࡮࡯ࡤࡲࡩࡹࠧឳ")])
        if bstack1l1l11_opy_ (u"࠭ࡳࡤࡴ࡬ࡴࡹࡹࠧ឴") in data:
          self.bstack1l1l1ll1l1_opy_(data[bstack1l1l11_opy_ (u"ࠧࡴࡥࡵ࡭ࡵࡺࡳࠨ឵")])
        if bstack1l1l11_opy_ (u"ࠨࡰࡲࡲࡇ࡙ࡴࡢࡥ࡮ࡍࡳ࡬ࡲࡢࡃ࠴࠵ࡾࡉࡨࡳࡱࡰࡩࡔࡶࡴࡪࡱࡱࡷࠬា") in data:
          self.bstack11l1lllllll_opy_(data[bstack1l1l11_opy_ (u"ࠩࡱࡳࡳࡈࡓࡵࡣࡦ࡯ࡎࡴࡦࡳࡣࡄ࠵࠶ࡿࡃࡩࡴࡲࡱࡪࡕࡰࡵ࡫ࡲࡲࡸ࠭ិ")])
    except:
      pass
  def bstack11l1lllllll_opy_(self, bstack11ll11l11ll_opy_):
    if bstack11ll11l11ll_opy_ != None:
      self.bstack11ll11l11ll_opy_ = bstack11ll11l11ll_opy_
  def bstack1l1l1ll1l1_opy_(self, scripts):
    if scripts != None:
      self.perform_scan = scripts.get(bstack1l1l11_opy_ (u"ࠪࡷࡨࡧ࡮ࠨី"),bstack1l1l11_opy_ (u"ࠫࠬឹ"))
      self.bstack1lll11lll_opy_ = scripts.get(bstack1l1l11_opy_ (u"ࠬ࡭ࡥࡵࡔࡨࡷࡺࡲࡴࡴࠩឺ"),bstack1l1l11_opy_ (u"࠭ࠧុ"))
      self.bstack111ll1l1_opy_ = scripts.get(bstack1l1l11_opy_ (u"ࠧࡨࡧࡷࡖࡪࡹࡵ࡭ࡶࡶࡗࡺࡳ࡭ࡢࡴࡼࠫូ"),bstack1l1l11_opy_ (u"ࠨࠩួ"))
      self.bstack11ll11111l1_opy_ = scripts.get(bstack1l1l11_opy_ (u"ࠩࡶࡥࡻ࡫ࡒࡦࡵࡸࡰࡹࡹࠧើ"),bstack1l1l11_opy_ (u"ࠪࠫឿ"))
  def bstack11ll1111ll1_opy_(self, commands_to_wrap):
    if commands_to_wrap != None and len(commands_to_wrap) != 0:
      self.commands_to_wrap = commands_to_wrap
  def store(self):
    try:
      with open(self.bstack11l1lllll1l_opy_, bstack1l1l11_opy_ (u"ࠫࡼ࠭ៀ")) as file:
        json.dump({
          bstack1l1l11_opy_ (u"ࠧࡩ࡯࡮࡯ࡤࡲࡩࡹࠢេ"): self.commands_to_wrap,
          bstack1l1l11_opy_ (u"ࠨࡳࡤࡴ࡬ࡴࡹࡹࠢែ"): {
            bstack1l1l11_opy_ (u"ࠢࡴࡥࡤࡲࠧៃ"): self.perform_scan,
            bstack1l1l11_opy_ (u"ࠣࡩࡨࡸࡗ࡫ࡳࡶ࡮ࡷࡷࠧោ"): self.bstack1lll11lll_opy_,
            bstack1l1l11_opy_ (u"ࠤࡪࡩࡹࡘࡥࡴࡷ࡯ࡸࡸ࡙ࡵ࡮࡯ࡤࡶࡾࠨៅ"): self.bstack111ll1l1_opy_,
            bstack1l1l11_opy_ (u"ࠥࡷࡦࡼࡥࡓࡧࡶࡹࡱࡺࡳࠣំ"): self.bstack11ll11111l1_opy_
          },
          bstack1l1l11_opy_ (u"ࠦࡳࡵ࡮ࡃࡕࡷࡥࡨࡱࡉ࡯ࡨࡵࡥࡆ࠷࠱ࡺࡅ࡫ࡶࡴࡳࡥࡐࡲࡷ࡭ࡴࡴࡳࠣះ"): self.bstack11ll11l11ll_opy_
        }, file)
    except Exception as e:
      logger.error(bstack1l1l11_opy_ (u"ࠧࡋࡲࡳࡱࡵࠤࡼ࡮ࡩ࡭ࡧࠣࡷࡹࡵࡲࡪࡰࡪࠤࡨࡵ࡭࡮ࡣࡱࡨࡸࡀࠠࡼࡿࠥៈ").format(e))
      pass
  def bstack1lll1l11ll_opy_(self, command_name):
    try:
      return any(command.get(bstack1l1l11_opy_ (u"࠭࡮ࡢ࡯ࡨࠫ៉")) == command_name for command in self.commands_to_wrap)
    except:
      return False
bstack11111llll_opy_ = bstack11ll1111111_opy_()