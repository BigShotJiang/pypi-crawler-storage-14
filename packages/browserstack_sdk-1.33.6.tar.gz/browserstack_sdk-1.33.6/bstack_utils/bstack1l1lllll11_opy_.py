# coding: UTF-8
import sys
bstack1l11111_opy_ = sys.version_info [0] == 2
bstack11l11ll_opy_ = 2048
bstack111ll1l_opy_ = 7
def bstack1l1l11_opy_ (bstack11l1l_opy_):
    global bstack1l11_opy_
    bstack11l1111_opy_ = ord (bstack11l1l_opy_ [-1])
    bstack1l1ll1l_opy_ = bstack11l1l_opy_ [:-1]
    bstack11l11_opy_ = bstack11l1111_opy_ % len (bstack1l1ll1l_opy_)
    bstack1l1ll11_opy_ = bstack1l1ll1l_opy_ [:bstack11l11_opy_] + bstack1l1ll1l_opy_ [bstack11l11_opy_:]
    if bstack1l11111_opy_:
        bstack11lll1l_opy_ = unicode () .join ([unichr (ord (char) - bstack11l11ll_opy_ - (bstack11l111_opy_ + bstack11l1111_opy_) % bstack111ll1l_opy_) for bstack11l111_opy_, char in enumerate (bstack1l1ll11_opy_)])
    else:
        bstack11lll1l_opy_ = str () .join ([chr (ord (char) - bstack11l11ll_opy_ - (bstack11l111_opy_ + bstack11l1111_opy_) % bstack111ll1l_opy_) for bstack11l111_opy_, char in enumerate (bstack1l1ll11_opy_)])
    return eval (bstack11lll1l_opy_)
import threading
import logging
import bstack_utils.accessibility as bstack1l1111l1l1_opy_
from bstack_utils.helper import bstack1lll11ll1l_opy_
logger = logging.getLogger(__name__)
def bstack11l1lllll_opy_(bstack1l11llll1l_opy_):
  return True if bstack1l11llll1l_opy_ in threading.current_thread().__dict__.keys() else False
def bstack11l11l111_opy_(context, *args):
    tags = getattr(args[0], bstack1l1l11_opy_ (u"ࠧࡵࡣࡪࡷࠬ៘"), [])
    bstack1l1111ll_opy_ = bstack1l1111l1l1_opy_.bstack1l111llll_opy_(tags)
    threading.current_thread().isA11yTest = bstack1l1111ll_opy_
    try:
      bstack1l111l11_opy_ = threading.current_thread().bstackSessionDriver if bstack11l1lllll_opy_(bstack1l1l11_opy_ (u"ࠨࡤࡶࡸࡦࡩ࡫ࡔࡧࡶࡷ࡮ࡵ࡮ࡅࡴ࡬ࡺࡪࡸࠧ៙")) else context.browser
      if bstack1l111l11_opy_ and bstack1l111l11_opy_.session_id and bstack1l1111ll_opy_ and bstack1lll11ll1l_opy_(
              threading.current_thread(), bstack1l1l11_opy_ (u"ࠩࡤ࠵࠶ࡿࡐ࡭ࡣࡷࡪࡴࡸ࡭ࠨ៚"), None):
          threading.current_thread().isA11yTest = bstack1l1111l1l1_opy_.bstack1ll1ll11_opy_(bstack1l111l11_opy_, bstack1l1111ll_opy_)
    except Exception as e:
       logger.debug(bstack1l1l11_opy_ (u"ࠪࡊࡦ࡯࡬ࡦࡦࠣࡸࡴࠦࡳࡵࡣࡵࡸࠥࡧ࠱࠲ࡻࠣ࡭ࡳࠦࡢࡦࡪࡤࡺࡪࡀࠠࡼࡿࠪ៛").format(str(e)))
def bstack1lll1l1ll_opy_(bstack1l111l11_opy_):
    if bstack1lll11ll1l_opy_(threading.current_thread(), bstack1l1l11_opy_ (u"ࠫ࡮ࡹࡁ࠲࠳ࡼࡘࡪࡹࡴࠨៜ"), None) and bstack1lll11ll1l_opy_(
      threading.current_thread(), bstack1l1l11_opy_ (u"ࠬࡧ࠱࠲ࡻࡓࡰࡦࡺࡦࡰࡴࡰࠫ៝"), None) and not bstack1lll11ll1l_opy_(threading.current_thread(), bstack1l1l11_opy_ (u"࠭ࡡ࠲࠳ࡼࡣࡸࡺ࡯ࡱࠩ៞"), False):
      threading.current_thread().a11y_stop = True
      bstack1l1111l1l1_opy_.bstack1ll1l1lll1_opy_(bstack1l111l11_opy_, name=bstack1l1l11_opy_ (u"ࠢࠣ៟"), path=bstack1l1l11_opy_ (u"ࠣࠤ០"))