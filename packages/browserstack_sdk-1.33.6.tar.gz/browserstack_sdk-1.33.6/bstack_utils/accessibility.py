# coding: UTF-8
import sys
bstack1l11111_opy_ = sys.version_info [0] == 2
bstack11l11ll_opy_ = 2048
bstack111ll1l_opy_ = 7
def bstack1l1l11_opy_ (bstack11l1l_opy_):
    global bstack1l11_opy_
    bstack11l1111_opy_ = ord (bstack11l1l_opy_ [-1])
    bstack1l1ll1l_opy_ = bstack11l1l_opy_ [:-1]
    bstack11l11_opy_ = bstack11l1111_opy_ % len (bstack1l1ll1l_opy_)
    bstack1l1ll11_opy_ = bstack1l1ll1l_opy_ [:bstack11l11_opy_] + bstack1l1ll1l_opy_ [bstack11l11_opy_:]
    if bstack1l11111_opy_:
        bstack11lll1l_opy_ = unicode () .join ([unichr (ord (char) - bstack11l11ll_opy_ - (bstack11l111_opy_ + bstack11l1111_opy_) % bstack111ll1l_opy_) for bstack11l111_opy_, char in enumerate (bstack1l1ll11_opy_)])
    else:
        bstack11lll1l_opy_ = str () .join ([chr (ord (char) - bstack11l11ll_opy_ - (bstack11l111_opy_ + bstack11l1111_opy_) % bstack111ll1l_opy_) for bstack11l111_opy_, char in enumerate (bstack1l1ll11_opy_)])
    return eval (bstack11lll1l_opy_)
import os
import json
import requests
import logging
import threading
import bstack_utils.constants as bstack11ll11ll11l_opy_
from urllib.parse import urlparse
from bstack_utils.constants import bstack11ll11ll111_opy_ as bstack11ll11ll1ll_opy_, EVENTS
from bstack_utils.bstack11111llll_opy_ import bstack11111llll_opy_
from bstack_utils.helper import bstack11ll111l_opy_, bstack111l1l11ll_opy_, bstack1llll1l1l_opy_, bstack11ll1l11l11_opy_, \
  bstack11ll1l1111l_opy_, bstack11ll1111_opy_, get_host_info, bstack11ll1l11l1l_opy_, bstack11l1lll1l_opy_, error_handler, bstack11ll111llll_opy_, bstack11ll11l1111_opy_, bstack1lll11ll1l_opy_
from browserstack_sdk._version import __version__
from bstack_utils.bstack1l1lll1l_opy_ import get_logger
from bstack_utils.bstack1111ll1l1_opy_ import bstack1ll111l1ll1_opy_
from selenium.webdriver.chrome.options import Options as ChromeOptions
from browserstack_sdk.sdk_cli.cli import cli
from bstack_utils.constants import *
logger = get_logger(__name__)
bstack1111ll1l1_opy_ = bstack1ll111l1ll1_opy_()
@error_handler(class_method=False)
def _11ll1l1l11l_opy_(driver, bstack111111lll1_opy_):
  response = {}
  try:
    caps = driver.capabilities
    response = {
        bstack1l1l11_opy_ (u"ࠫࡴࡹ࡟࡯ࡣࡰࡩࠬᙷ"): caps.get(bstack1l1l11_opy_ (u"ࠬࡶ࡬ࡢࡶࡩࡳࡷࡳࡎࡢ࡯ࡨࠫᙸ"), None),
        bstack1l1l11_opy_ (u"࠭࡯ࡴࡡࡹࡩࡷࡹࡩࡰࡰࠪᙹ"): bstack111111lll1_opy_.get(bstack1l1l11_opy_ (u"ࠧࡰࡵ࡙ࡩࡷࡹࡩࡰࡰࠪᙺ"), None),
        bstack1l1l11_opy_ (u"ࠨࡤࡵࡳࡼࡹࡥࡳࡡࡱࡥࡲ࡫ࠧᙻ"): caps.get(bstack1l1l11_opy_ (u"ࠩࡥࡶࡴࡽࡳࡦࡴࡑࡥࡲ࡫ࠧᙼ"), None),
        bstack1l1l11_opy_ (u"ࠪࡦࡷࡵࡷࡴࡧࡵࡣࡻ࡫ࡲࡴ࡫ࡲࡲࠬᙽ"): caps.get(bstack1l1l11_opy_ (u"ࠫࡧࡸ࡯ࡸࡵࡨࡶ࡛࡫ࡲࡴ࡫ࡲࡲࠬᙾ"), None)
    }
  except Exception as error:
    logger.debug(bstack1l1l11_opy_ (u"ࠬࡋࡸࡤࡧࡳࡸ࡮ࡵ࡮ࠡ࡫ࡱࠤ࡫࡫ࡴࡤࡪ࡬ࡲ࡬ࠦࡰ࡭ࡣࡷࡪࡴࡸ࡭ࠡࡦࡨࡸࡦ࡯࡬ࡴࠢࡺ࡭ࡹ࡮ࠠࡦࡴࡵࡳࡷࠦ࠺ࠡࠩᙿ") + str(error))
  return response
def on():
    if os.environ.get(bstack1l1l11_opy_ (u"࠭ࡂࡔࡡࡄ࠵࠶࡟࡟ࡋ࡙ࡗࠫ "), None) is None or os.environ[bstack1l1l11_opy_ (u"ࠧࡃࡕࡢࡅ࠶࠷࡙ࡠࡌ࡚ࡘࠬᚁ")] == bstack1l1l11_opy_ (u"ࠣࡰࡸࡰࡱࠨᚂ"):
        return False
    return True
def bstack1l11l1lll_opy_(config):
  return config.get(bstack1l1l11_opy_ (u"ࠩࡤࡧࡨ࡫ࡳࡴ࡫ࡥ࡭ࡱ࡯ࡴࡺࠩᚃ"), False) or any([p.get(bstack1l1l11_opy_ (u"ࠪࡥࡨࡩࡥࡴࡵ࡬ࡦ࡮ࡲࡩࡵࡻࠪᚄ"), False) == True for p in config.get(bstack1l1l11_opy_ (u"ࠫࡵࡲࡡࡵࡨࡲࡶࡲࡹࠧᚅ"), [])])
def bstack1ll1111l_opy_(config, bstack1l11111ll1_opy_):
  try:
    bstack11ll1l1l1ll_opy_ = config.get(bstack1l1l11_opy_ (u"ࠬࡧࡣࡤࡧࡶࡷ࡮ࡨࡩ࡭࡫ࡷࡽࠬᚆ"), False)
    if int(bstack1l11111ll1_opy_) < len(config.get(bstack1l1l11_opy_ (u"࠭ࡰ࡭ࡣࡷࡪࡴࡸ࡭ࡴࠩᚇ"), [])) and config[bstack1l1l11_opy_ (u"ࠧࡱ࡮ࡤࡸ࡫ࡵࡲ࡮ࡵࠪᚈ")][bstack1l11111ll1_opy_]:
      bstack11ll111l11l_opy_ = config[bstack1l1l11_opy_ (u"ࠨࡲ࡯ࡥࡹ࡬࡯ࡳ࡯ࡶࠫᚉ")][bstack1l11111ll1_opy_].get(bstack1l1l11_opy_ (u"ࠩࡤࡧࡨ࡫ࡳࡴ࡫ࡥ࡭ࡱ࡯ࡴࡺࠩᚊ"), None)
    else:
      bstack11ll111l11l_opy_ = config.get(bstack1l1l11_opy_ (u"ࠪࡥࡨࡩࡥࡴࡵ࡬ࡦ࡮ࡲࡩࡵࡻࠪᚋ"), None)
    if bstack11ll111l11l_opy_ != None:
      bstack11ll1l1l1ll_opy_ = bstack11ll111l11l_opy_
    bstack11ll1111lll_opy_ = os.getenv(bstack1l1l11_opy_ (u"ࠫࡇ࡙࡟ࡂ࠳࠴࡝ࡤࡐࡗࡕࠩᚌ")) is not None and len(os.getenv(bstack1l1l11_opy_ (u"ࠬࡈࡓࡠࡃ࠴࠵࡞ࡥࡊࡘࡖࠪᚍ"))) > 0 and os.getenv(bstack1l1l11_opy_ (u"࠭ࡂࡔࡡࡄ࠵࠶࡟࡟ࡋ࡙ࡗࠫᚎ")) != bstack1l1l11_opy_ (u"ࠧ࡯ࡷ࡯ࡰࠬᚏ")
    return bstack11ll1l1l1ll_opy_ and bstack11ll1111lll_opy_
  except Exception as error:
    logger.debug(bstack1l1l11_opy_ (u"ࠨࡇࡻࡧࡪࡶࡴࡪࡱࡱࠤ࡮ࡴࠠࡷࡧࡵ࡭࡫ࡿࡩ࡯ࡩࠣࡸ࡭࡫ࠠࡂࡥࡦࡩࡸࡹࡩࡣ࡫࡯࡭ࡹࡿࠠࡴࡧࡶࡷ࡮ࡵ࡮ࠡࡹ࡬ࡸ࡭ࠦࡥࡳࡴࡲࡶࠥࡀࠠࠨᚐ") + str(error))
  return False
def bstack1l111llll_opy_(test_tags):
  bstack1l1lll1ll11_opy_ = os.getenv(bstack1l1l11_opy_ (u"ࠩࡅࡖࡔ࡝ࡓࡆࡔࡖࡘࡆࡉࡋࡠࡖࡈࡗ࡙ࡥࡁࡄࡅࡈࡗࡘࡏࡂࡊࡎࡌࡘ࡞ࡥࡃࡐࡐࡉࡍࡌ࡛ࡒࡂࡖࡌࡓࡓࡥ࡙ࡎࡎࠪᚑ"))
  if bstack1l1lll1ll11_opy_ is None:
    return True
  bstack1l1lll1ll11_opy_ = json.loads(bstack1l1lll1ll11_opy_)
  try:
    include_tags = bstack1l1lll1ll11_opy_[bstack1l1l11_opy_ (u"ࠪ࡭ࡳࡩ࡬ࡶࡦࡨࡘࡦ࡭ࡳࡊࡰࡗࡩࡸࡺࡩ࡯ࡩࡖࡧࡴࡶࡥࠨᚒ")] if bstack1l1l11_opy_ (u"ࠫ࡮ࡴࡣ࡭ࡷࡧࡩ࡙ࡧࡧࡴࡋࡱࡘࡪࡹࡴࡪࡰࡪࡗࡨࡵࡰࡦࠩᚓ") in bstack1l1lll1ll11_opy_ and isinstance(bstack1l1lll1ll11_opy_[bstack1l1l11_opy_ (u"ࠬ࡯࡮ࡤ࡮ࡸࡨࡪ࡚ࡡࡨࡵࡌࡲ࡙࡫ࡳࡵ࡫ࡱ࡫ࡘࡩ࡯ࡱࡧࠪᚔ")], list) else []
    exclude_tags = bstack1l1lll1ll11_opy_[bstack1l1l11_opy_ (u"࠭ࡥࡹࡥ࡯ࡹࡩ࡫ࡔࡢࡩࡶࡍࡳ࡚ࡥࡴࡶ࡬ࡲ࡬࡙ࡣࡰࡲࡨࠫᚕ")] if bstack1l1l11_opy_ (u"ࠧࡦࡺࡦࡰࡺࡪࡥࡕࡣࡪࡷࡎࡴࡔࡦࡵࡷ࡭ࡳ࡭ࡓࡤࡱࡳࡩࠬᚖ") in bstack1l1lll1ll11_opy_ and isinstance(bstack1l1lll1ll11_opy_[bstack1l1l11_opy_ (u"ࠨࡧࡻࡧࡱࡻࡤࡦࡖࡤ࡫ࡸࡏ࡮ࡕࡧࡶࡸ࡮ࡴࡧࡔࡥࡲࡴࡪ࠭ᚗ")], list) else []
    excluded = any(tag in exclude_tags for tag in test_tags)
    included = len(include_tags) == 0 or any(tag in include_tags for tag in test_tags)
    return not excluded and included
  except Exception as error:
    logger.debug(bstack1l1l11_opy_ (u"ࠤࡈࡶࡷࡵࡲࠡࡹ࡫࡭ࡱ࡫ࠠࡷࡣ࡯࡭ࡩࡧࡴࡪࡰࡪࠤࡹ࡫ࡳࡵࠢࡦࡥࡸ࡫ࠠࡧࡱࡵࠤࡦࡩࡣࡦࡵࡶ࡭ࡧ࡯࡬ࡪࡶࡼࠤࡧ࡫ࡦࡰࡴࡨࠤࡸࡩࡡ࡯ࡰ࡬ࡲ࡬࠴ࠠࡆࡴࡵࡳࡷࠦ࠺ࠡࠤᚘ") + str(error))
  return False
def bstack11ll1l111ll_opy_(config, bstack11ll11l1ll1_opy_, bstack11ll111l1ll_opy_, bstack11ll11l1l11_opy_):
  bstack11ll1l11lll_opy_ = bstack11ll1l11l11_opy_(config)
  bstack11ll1111l11_opy_ = bstack11ll1l1111l_opy_(config)
  if bstack11ll1l11lll_opy_ is None or bstack11ll1111l11_opy_ is None:
    logger.error(bstack1l1l11_opy_ (u"ࠪࡉࡽࡩࡥࡱࡶ࡬ࡳࡳࠦࡷࡩ࡫࡯ࡩࠥࡩࡲࡦࡣࡷ࡭ࡳ࡭ࠠࡵࡧࡶࡸࠥࡸࡵ࡯ࠢࡩࡳࡷࠦࡂࡳࡱࡺࡷࡪࡸࡓࡵࡣࡦ࡯ࠥࡇࡣࡤࡧࡶࡷ࡮ࡨࡩ࡭࡫ࡷࡽࠥࡇࡵࡵࡱࡰࡥࡹ࡯࡯࡯࠼ࠣࡑ࡮ࡹࡳࡪࡰࡪࠤࡦࡻࡴࡩࡧࡱࡸ࡮ࡩࡡࡵ࡫ࡲࡲࠥࡺ࡯࡬ࡧࡱࠫᚙ"))
    return [None, None]
  try:
    settings = json.loads(os.getenv(bstack1l1l11_opy_ (u"ࠫࡇࡘࡏࡘࡕࡈࡖࡘ࡚ࡁࡄࡍࡢࡘࡊ࡙ࡔࡠࡃࡆࡇࡊ࡙ࡓࡊࡄࡌࡐࡎ࡚࡙ࡠࡅࡒࡒࡋࡏࡇࡖࡔࡄࡘࡎࡕࡎࡠ࡛ࡐࡐࠬᚚ"), bstack1l1l11_opy_ (u"ࠬࢁࡽࠨ᚛")))
    data = {
        bstack1l1l11_opy_ (u"࠭ࡰࡳࡱ࡭ࡩࡨࡺࡎࡢ࡯ࡨࠫ᚜"): config[bstack1l1l11_opy_ (u"ࠧࡱࡴࡲ࡮ࡪࡩࡴࡏࡣࡰࡩࠬ᚝")],
        bstack1l1l11_opy_ (u"ࠨࡤࡸ࡭ࡱࡪࡎࡢ࡯ࡨࠫ᚞"): config.get(bstack1l1l11_opy_ (u"ࠩࡥࡹ࡮ࡲࡤࡏࡣࡰࡩࠬ᚟"), os.path.basename(os.getcwd())),
        bstack1l1l11_opy_ (u"ࠪࡷࡹࡧࡲࡵࡖ࡬ࡱࡪ࠭ᚠ"): bstack11ll111l_opy_(),
        bstack1l1l11_opy_ (u"ࠫࡩ࡫ࡳࡤࡴ࡬ࡴࡹ࡯࡯࡯ࠩᚡ"): config.get(bstack1l1l11_opy_ (u"ࠬࡨࡵࡪ࡮ࡧࡈࡪࡹࡣࡳ࡫ࡳࡸ࡮ࡵ࡮ࠨᚢ"), bstack1l1l11_opy_ (u"࠭ࠧᚣ")),
        bstack1l1l11_opy_ (u"ࠧࡴࡱࡸࡶࡨ࡫ࠧᚤ"): {
            bstack1l1l11_opy_ (u"ࠨࡨࡵࡥࡲ࡫ࡷࡰࡴ࡮ࡒࡦࡳࡥࠨᚥ"): bstack11ll11l1ll1_opy_,
            bstack1l1l11_opy_ (u"ࠩࡩࡶࡦࡳࡥࡸࡱࡵ࡯࡛࡫ࡲࡴ࡫ࡲࡲࠬᚦ"): bstack11ll111l1ll_opy_,
            bstack1l1l11_opy_ (u"ࠪࡷࡩࡱࡖࡦࡴࡶ࡭ࡴࡴࠧᚧ"): __version__,
            bstack1l1l11_opy_ (u"ࠫࡱࡧ࡮ࡨࡷࡤ࡫ࡪ࠭ᚨ"): bstack1l1l11_opy_ (u"ࠬࡶࡹࡵࡪࡲࡲࠬᚩ"),
            bstack1l1l11_opy_ (u"࠭ࡴࡦࡵࡷࡊࡷࡧ࡭ࡦࡹࡲࡶࡰ࠭ᚪ"): bstack1l1l11_opy_ (u"ࠧࡴࡧ࡯ࡩࡳ࡯ࡵ࡮ࠩᚫ"),
            bstack1l1l11_opy_ (u"ࠨࡶࡨࡷࡹࡌࡲࡢ࡯ࡨࡻࡴࡸ࡫ࡗࡧࡵࡷ࡮ࡵ࡮ࠨᚬ"): bstack11ll11l1l11_opy_
        },
        bstack1l1l11_opy_ (u"ࠩࡶࡩࡹࡺࡩ࡯ࡩࡶࠫᚭ"): settings,
        bstack1l1l11_opy_ (u"ࠪࡺࡪࡸࡳࡪࡱࡱࡇࡴࡴࡴࡳࡱ࡯ࠫᚮ"): bstack11ll1l11l1l_opy_(),
        bstack1l1l11_opy_ (u"ࠫࡨ࡯ࡉ࡯ࡨࡲࠫᚯ"): bstack11ll1111_opy_(),
        bstack1l1l11_opy_ (u"ࠬ࡮࡯ࡴࡶࡌࡲ࡫ࡵࠧᚰ"): get_host_info(),
        bstack1l1l11_opy_ (u"࠭ࡢࡳࡱࡺࡷࡪࡸࡳࡵࡣࡦ࡯ࡆࡻࡴࡰ࡯ࡤࡸ࡮ࡵ࡮ࠨᚱ"): bstack1llll1l1l_opy_(config)
    }
    headers = {
        bstack1l1l11_opy_ (u"ࠧࡄࡱࡱࡸࡪࡴࡴ࠮ࡖࡼࡴࡪ࠭ᚲ"): bstack1l1l11_opy_ (u"ࠨࡣࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳ࠵ࡪࡴࡱࡱࠫᚳ"),
    }
    config = {
        bstack1l1l11_opy_ (u"ࠩࡤࡹࡹ࡮ࠧᚴ"): (bstack11ll1l11lll_opy_, bstack11ll1111l11_opy_),
        bstack1l1l11_opy_ (u"ࠪ࡬ࡪࡧࡤࡦࡴࡶࠫᚵ"): headers
    }
    response = bstack11l1lll1l_opy_(bstack1l1l11_opy_ (u"ࠫࡕࡕࡓࡕࠩᚶ"), bstack11ll11ll1ll_opy_ + bstack1l1l11_opy_ (u"ࠬ࠵ࡶ࠳࠱ࡷࡩࡸࡺ࡟ࡳࡷࡱࡷࠬᚷ"), data, config)
    bstack11ll11lll1l_opy_ = response.json()
    if bstack11ll11lll1l_opy_[bstack1l1l11_opy_ (u"࠭ࡳࡶࡥࡦࡩࡸࡹࠧᚸ")]:
      parsed = json.loads(os.getenv(bstack1l1l11_opy_ (u"ࠧࡃࡔࡒ࡛ࡘࡋࡒࡔࡖࡄࡇࡐࡥࡔࡆࡕࡗࡣࡆࡉࡃࡆࡕࡖࡍࡇࡏࡌࡊࡖ࡜ࡣࡈࡕࡎࡇࡋࡊ࡙ࡗࡇࡔࡊࡑࡑࡣ࡞ࡓࡌࠨᚹ"), bstack1l1l11_opy_ (u"ࠨࡽࢀࠫᚺ")))
      parsed[bstack1l1l11_opy_ (u"ࠩࡶࡧࡦࡴ࡮ࡦࡴ࡙ࡩࡷࡹࡩࡰࡰࠪᚻ")] = bstack11ll11lll1l_opy_[bstack1l1l11_opy_ (u"ࠪࡨࡦࡺࡡࠨᚼ")][bstack1l1l11_opy_ (u"ࠫࡸࡩࡡ࡯ࡰࡨࡶ࡛࡫ࡲࡴ࡫ࡲࡲࠬᚽ")]
      os.environ[bstack1l1l11_opy_ (u"ࠬࡈࡒࡐ࡙ࡖࡉࡗ࡙ࡔࡂࡅࡎࡣ࡙ࡋࡓࡕࡡࡄࡇࡈࡋࡓࡔࡋࡅࡍࡑࡏࡔ࡚ࡡࡆࡓࡓࡌࡉࡈࡗࡕࡅ࡙ࡏࡏࡏࡡ࡜ࡑࡑ࠭ᚾ")] = json.dumps(parsed)
      bstack11111llll_opy_.bstack1l1l1ll1l1_opy_(bstack11ll11lll1l_opy_[bstack1l1l11_opy_ (u"࠭ࡤࡢࡶࡤࠫᚿ")][bstack1l1l11_opy_ (u"ࠧࡴࡥࡵ࡭ࡵࡺࡳࠨᛀ")])
      bstack11111llll_opy_.bstack11ll1111ll1_opy_(bstack11ll11lll1l_opy_[bstack1l1l11_opy_ (u"ࠨࡦࡤࡸࡦ࠭ᛁ")][bstack1l1l11_opy_ (u"ࠩࡦࡳࡲࡳࡡ࡯ࡦࡶࠫᛂ")])
      bstack11111llll_opy_.store()
      return bstack11ll11lll1l_opy_[bstack1l1l11_opy_ (u"ࠪࡨࡦࡺࡡࠨᛃ")][bstack1l1l11_opy_ (u"ࠫࡦࡩࡣࡦࡵࡶ࡭ࡧ࡯࡬ࡪࡶࡼࡘࡴࡱࡥ࡯ࠩᛄ")], bstack11ll11lll1l_opy_[bstack1l1l11_opy_ (u"ࠬࡪࡡࡵࡣࠪᛅ")][bstack1l1l11_opy_ (u"࠭ࡩࡥࠩᛆ")]
    else:
      logger.error(bstack1l1l11_opy_ (u"ࠧࡆࡺࡦࡩࡵࡺࡩࡰࡰࠣࡻ࡭࡯࡬ࡦࠢࡵࡹࡳࡴࡩ࡯ࡩࠣࡆࡷࡵࡷࡴࡧࡵࡗࡹࡧࡣ࡬ࠢࡄࡧࡨ࡫ࡳࡴ࡫ࡥ࡭ࡱ࡯ࡴࡺࠢࡄࡹࡹࡵ࡭ࡢࡶ࡬ࡳࡳࡀࠠࠨᛇ") + bstack11ll11lll1l_opy_[bstack1l1l11_opy_ (u"ࠨ࡯ࡨࡷࡸࡧࡧࡦࠩᛈ")])
      if bstack11ll11lll1l_opy_[bstack1l1l11_opy_ (u"ࠩࡰࡩࡸࡹࡡࡨࡧࠪᛉ")] == bstack1l1l11_opy_ (u"ࠪࡍࡳࡼࡡ࡭࡫ࡧࠤࡨࡵ࡮ࡧ࡫ࡪࡹࡷࡧࡴࡪࡱࡱࠤࡵࡧࡳࡴࡧࡧ࠲ࠬᛊ"):
        for bstack11ll111ll11_opy_ in bstack11ll11lll1l_opy_[bstack1l1l11_opy_ (u"ࠫࡪࡸࡲࡰࡴࡶࠫᛋ")]:
          logger.error(bstack11ll111ll11_opy_[bstack1l1l11_opy_ (u"ࠬࡳࡥࡴࡵࡤ࡫ࡪ࠭ᛌ")])
      return None, None
  except Exception as error:
    logger.error(bstack1l1l11_opy_ (u"ࠨࡅࡹࡥࡨࡴࡹ࡯࡯࡯ࠢࡺ࡬࡮ࡲࡥࠡࡥࡵࡩࡦࡺࡩ࡯ࡩࠣࡸࡪࡹࡴࠡࡴࡸࡲࠥ࡬࡯ࡳࠢࡅࡶࡴࡽࡳࡦࡴࡖࡸࡦࡩ࡫ࠡࡃࡦࡧࡪࡹࡳࡪࡤ࡬ࡰ࡮ࡺࡹࠡࡃࡸࡸࡴࡳࡡࡵ࡫ࡲࡲ࠿ࠦࠢᛍ") +  str(error))
    return None, None
def bstack11ll11ll1l1_opy_():
  if os.getenv(bstack1l1l11_opy_ (u"ࠧࡃࡕࡢࡅ࠶࠷࡙ࡠࡌ࡚ࡘࠬᛎ")) is None:
    return {
        bstack1l1l11_opy_ (u"ࠨࡵࡷࡥࡹࡻࡳࠨᛏ"): bstack1l1l11_opy_ (u"ࠩࡨࡶࡷࡵࡲࠨᛐ"),
        bstack1l1l11_opy_ (u"ࠪࡱࡪࡹࡳࡢࡩࡨࠫᛑ"): bstack1l1l11_opy_ (u"ࠫࡇࡻࡩ࡭ࡦࠣࡧࡷ࡫ࡡࡵ࡫ࡲࡲࠥ࡮ࡡࡥࠢࡩࡥ࡮ࡲࡥࡥ࠰ࠪᛒ")
    }
  data = {bstack1l1l11_opy_ (u"ࠬ࡫࡮ࡥࡖ࡬ࡱࡪ࠭ᛓ"): bstack11ll111l_opy_()}
  headers = {
      bstack1l1l11_opy_ (u"࠭ࡁࡶࡶ࡫ࡳࡷ࡯ࡺࡢࡶ࡬ࡳࡳ࠭ᛔ"): bstack1l1l11_opy_ (u"ࠧࡃࡧࡤࡶࡪࡸࠠࠨᛕ") + os.getenv(bstack1l1l11_opy_ (u"ࠣࡄࡖࡣࡆ࠷࠱࡚ࡡࡍ࡛࡙ࠨᛖ")),
      bstack1l1l11_opy_ (u"ࠩࡆࡳࡳࡺࡥ࡯ࡶ࠰ࡘࡾࡶࡥࠨᛗ"): bstack1l1l11_opy_ (u"ࠪࡥࡵࡶ࡬ࡪࡥࡤࡸ࡮ࡵ࡮࠰࡬ࡶࡳࡳ࠭ᛘ")
  }
  response = bstack11l1lll1l_opy_(bstack1l1l11_opy_ (u"ࠫࡕ࡛ࡔࠨᛙ"), bstack11ll11ll1ll_opy_ + bstack1l1l11_opy_ (u"ࠬ࠵ࡴࡦࡵࡷࡣࡷࡻ࡮ࡴ࠱ࡶࡸࡴࡶࠧᛚ"), data, { bstack1l1l11_opy_ (u"࠭ࡨࡦࡣࡧࡩࡷࡹࠧᛛ"): headers })
  try:
    if response.status_code == 200:
      logger.info(bstack1l1l11_opy_ (u"ࠢࡃࡴࡲࡻࡸ࡫ࡲࡔࡶࡤࡧࡰࠦࡁࡤࡥࡨࡷࡸ࡯ࡢࡪ࡮࡬ࡸࡾࠦࡁࡶࡶࡲࡱࡦࡺࡩࡰࡰࠣࡘࡪࡹࡴࠡࡔࡸࡲࠥࡳࡡࡳ࡭ࡨࡨࠥࡧࡳࠡࡥࡲࡱࡵࡲࡥࡵࡧࡧࠤࡦࡺࠠࠣᛜ") + bstack111l1l11ll_opy_().isoformat() + bstack1l1l11_opy_ (u"ࠨ࡜ࠪᛝ"))
      return {bstack1l1l11_opy_ (u"ࠩࡶࡸࡦࡺࡵࡴࠩᛞ"): bstack1l1l11_opy_ (u"ࠪࡷࡺࡩࡣࡦࡵࡶࠫᛟ"), bstack1l1l11_opy_ (u"ࠫࡲ࡫ࡳࡴࡣࡪࡩࠬᛠ"): bstack1l1l11_opy_ (u"ࠬ࠭ᛡ")}
    else:
      response.raise_for_status()
  except requests.RequestException as error:
    logger.error(bstack1l1l11_opy_ (u"ࠨࡅࡹࡥࡨࡴࡹ࡯࡯࡯ࠢࡺ࡬࡮ࡲࡥࠡ࡯ࡤࡶࡰ࡯࡮ࡨࠢࡦࡳࡲࡶ࡬ࡦࡶ࡬ࡳࡳࠦ࡯ࡧࠢࡅࡶࡴࡽࡳࡦࡴࡖࡸࡦࡩ࡫ࠡࡃࡦࡧࡪࡹࡳࡪࡤ࡬ࡰ࡮ࡺࡹࠡࡃࡸࡸࡴࡳࡡࡵ࡫ࡲࡲ࡚ࠥࡥࡴࡶࠣࡖࡺࡴ࠺ࠡࠤᛢ") + str(error))
    return {
        bstack1l1l11_opy_ (u"ࠧࡴࡶࡤࡸࡺࡹࠧᛣ"): bstack1l1l11_opy_ (u"ࠨࡧࡵࡶࡴࡸࠧᛤ"),
        bstack1l1l11_opy_ (u"ࠩࡰࡩࡸࡹࡡࡨࡧࠪᛥ"): str(error)
    }
def bstack11ll1l11111_opy_(bstack11ll11lll11_opy_):
    return re.match(bstack1l1l11_opy_ (u"ࡵࠫࡣࡢࡤࠬࠪ࡟࠲ࡡࡪࠫࠪࡁࠧࠫᛦ"), bstack11ll11lll11_opy_.strip()) is not None
def bstack1ll11lllll_opy_(caps, options, desired_capabilities={}, config=None):
    try:
        if options:
          bstack11ll111l111_opy_ = options.to_capabilities()
        elif desired_capabilities:
          bstack11ll111l111_opy_ = desired_capabilities
        else:
          bstack11ll111l111_opy_ = {}
        bstack1l1ll1ll1l1_opy_ = (bstack11ll111l111_opy_.get(bstack1l1l11_opy_ (u"ࠫࡵࡲࡡࡵࡨࡲࡶࡲࡔࡡ࡮ࡧࠪᛧ"), bstack1l1l11_opy_ (u"ࠬ࠭ᛨ")).lower() or caps.get(bstack1l1l11_opy_ (u"࠭ࡰ࡭ࡣࡷࡪࡴࡸ࡭ࡏࡣࡰࡩࠬᛩ"), bstack1l1l11_opy_ (u"ࠧࠨᛪ")).lower())
        if bstack1l1ll1ll1l1_opy_ == bstack1l1l11_opy_ (u"ࠨ࡫ࡲࡷࠬ᛫"):
            return True
        if bstack1l1ll1ll1l1_opy_ == bstack1l1l11_opy_ (u"ࠩࡤࡲࡩࡸ࡯ࡪࡦࠪ᛬"):
            bstack1l1ll11l1l1_opy_ = str(float(caps.get(bstack1l1l11_opy_ (u"ࠪࡴࡱࡧࡴࡧࡱࡵࡱ࡛࡫ࡲࡴ࡫ࡲࡲࠬ᛭")) or bstack11ll111l111_opy_.get(bstack1l1l11_opy_ (u"ࠫࡧࡹࡴࡢࡥ࡮࠾ࡴࡶࡴࡪࡱࡱࡷࠬᛮ"), {}).get(bstack1l1l11_opy_ (u"ࠬࡵࡳࡗࡧࡵࡷ࡮ࡵ࡮ࠨᛯ"),bstack1l1l11_opy_ (u"࠭ࠧᛰ"))))
            if bstack1l1ll1ll1l1_opy_ == bstack1l1l11_opy_ (u"ࠧࡢࡰࡧࡶࡴ࡯ࡤࠨᛱ") and int(bstack1l1ll11l1l1_opy_.split(bstack1l1l11_opy_ (u"ࠨ࠰ࠪᛲ"))[0]) < float(bstack11ll1l11ll1_opy_):
                logger.warning(str(bstack11ll11l11l1_opy_))
                return False
            return True
        bstack1l1lllll111_opy_ = caps.get(bstack1l1l11_opy_ (u"ࠩࡥࡷࡹࡧࡣ࡬࠼ࡲࡴࡹ࡯࡯࡯ࡵࠪᛳ"), {}).get(bstack1l1l11_opy_ (u"ࠪࡨࡪࡼࡩࡤࡧࡑࡥࡲ࡫ࠧᛴ"), caps.get(bstack1l1l11_opy_ (u"ࠫࡩ࡫ࡶࡪࡥࡨࠫᛵ"), bstack1l1l11_opy_ (u"ࠬ࠭ᛶ")))
        if bstack1l1lllll111_opy_:
            logger.warning(bstack1l1l11_opy_ (u"ࠨࡁࡤࡥࡨࡷࡸ࡯ࡢࡪ࡮࡬ࡸࡾࠦࡁࡶࡶࡲࡱࡦࡺࡩࡰࡰࠣࡻ࡮ࡲ࡬ࠡࡴࡸࡲࠥࡵ࡮࡭ࡻࠣࡳࡳࠦࡄࡦࡵ࡮ࡸࡴࡶࠠࡣࡴࡲࡻࡸ࡫ࡲࡴ࠰ࠥᛷ"))
            return False
        browser = caps.get(bstack1l1l11_opy_ (u"ࠧࡣࡴࡲࡻࡸ࡫ࡲࡏࡣࡰࡩࠬᛸ"), bstack1l1l11_opy_ (u"ࠨࠩ᛹")).lower() or bstack11ll111l111_opy_.get(bstack1l1l11_opy_ (u"ࠩࡥࡶࡴࡽࡳࡦࡴࡑࡥࡲ࡫ࠧ᛺"), bstack1l1l11_opy_ (u"ࠪࠫ᛻")).lower()
        if browser != bstack1l1l11_opy_ (u"ࠫࡨ࡮ࡲࡰ࡯ࡨࠫ᛼"):
            logger.warning(bstack1l1l11_opy_ (u"ࠧࡇࡣࡤࡧࡶࡷ࡮ࡨࡩ࡭࡫ࡷࡽࠥࡇࡵࡵࡱࡰࡥࡹ࡯࡯࡯ࠢࡺ࡭ࡱࡲࠠࡳࡷࡱࠤࡴࡴ࡬ࡺࠢࡲࡲࠥࡉࡨࡳࡱࡰࡩࠥࡨࡲࡰࡹࡶࡩࡷࡹ࠮ࠣ᛽"))
            return False
        browser_version = caps.get(bstack1l1l11_opy_ (u"࠭ࡢࡳࡱࡺࡷࡪࡸࡖࡦࡴࡶ࡭ࡴࡴࠧ᛾")) or caps.get(bstack1l1l11_opy_ (u"ࠧࡣࡴࡲࡻࡸ࡫ࡲࡠࡸࡨࡶࡸ࡯࡯࡯ࠩ᛿")) or bstack11ll111l111_opy_.get(bstack1l1l11_opy_ (u"ࠨࡤࡵࡳࡼࡹࡥࡳࡘࡨࡶࡸ࡯࡯࡯ࠩᜀ")) or bstack11ll111l111_opy_.get(bstack1l1l11_opy_ (u"ࠩࡥࡷࡹࡧࡣ࡬࠼ࡲࡴࡹ࡯࡯࡯ࡵࠪᜁ"), {}).get(bstack1l1l11_opy_ (u"ࠪࡦࡷࡵࡷࡴࡧࡵ࡚ࡪࡸࡳࡪࡱࡱࠫᜂ")) or bstack11ll111l111_opy_.get(bstack1l1l11_opy_ (u"ࠫࡧࡹࡴࡢࡥ࡮࠾ࡴࡶࡴࡪࡱࡱࡷࠬᜃ"), {}).get(bstack1l1l11_opy_ (u"ࠬࡨࡲࡰࡹࡶࡩࡷࡥࡶࡦࡴࡶ࡭ࡴࡴࠧᜄ"))
        bstack1l1lll11l11_opy_ = bstack11ll11ll11l_opy_.bstack1l1llll1l1l_opy_
        bstack11ll1l1l1l1_opy_ = False
        if config is not None:
          bstack11ll1l1l1l1_opy_ = bstack1l1l11_opy_ (u"࠭ࡴࡶࡴࡥࡳࡘࡩࡡ࡭ࡧࠪᜅ") in config and str(config[bstack1l1l11_opy_ (u"ࠧࡵࡷࡵࡦࡴ࡙ࡣࡢ࡮ࡨࠫᜆ")]).lower() != bstack1l1l11_opy_ (u"ࠨࡨࡤࡰࡸ࡫ࠧᜇ")
        if os.environ.get(bstack1l1l11_opy_ (u"ࠩࡌࡗࡤࡔࡏࡏࡡࡅࡗ࡙ࡇࡃࡌࡡࡌࡒࡋࡘࡁࡠࡃ࠴࠵࡞ࡥࡓࡆࡕࡖࡍࡔࡔࠧᜈ"), bstack1l1l11_opy_ (u"ࠪࠫᜉ")).lower() == bstack1l1l11_opy_ (u"ࠫࡹࡸࡵࡦࠩᜊ") or bstack11ll1l1l1l1_opy_:
          bstack1l1lll11l11_opy_ = bstack11ll11ll11l_opy_.bstack1l1lllll1ll_opy_
        if browser_version and browser_version != bstack1l1l11_opy_ (u"ࠬࡲࡡࡵࡧࡶࡸࠬᜋ") and int(browser_version.split(bstack1l1l11_opy_ (u"࠭࠮ࠨᜌ"))[0]) <= bstack1l1lll11l11_opy_:
          logger.warning(bstack1ll1ll1l11l_opy_ (u"ࠧࡂࡥࡦࡩࡸࡹࡩࡣ࡫࡯࡭ࡹࡿࠠࡂࡷࡷࡳࡲࡧࡴࡪࡱࡱࠤࡼ࡯࡬࡭ࠢࡵࡹࡳࠦ࡯࡯࡮ࡼࠤࡴࡴࠠࡄࡪࡵࡳࡲ࡫ࠠࡣࡴࡲࡻࡸ࡫ࡲࠡࡸࡨࡶࡸ࡯࡯࡯ࠢࡪࡶࡪࡧࡴࡦࡴࠣࡸ࡭ࡧ࡮ࠡࡽࡰ࡭ࡳࡥࡡ࠲࠳ࡼࡣࡸࡻࡰࡱࡱࡵࡸࡪࡪ࡟ࡤࡪࡵࡳࡲ࡫࡟ࡷࡧࡵࡷ࡮ࡵ࡮ࡾ࠰ࠪᜍ"))
          return False
        if not options:
          bstack1l1lll111l1_opy_ = caps.get(bstack1l1l11_opy_ (u"ࠨࡩࡲࡳ࡬ࡀࡣࡩࡴࡲࡱࡪࡕࡰࡵ࡫ࡲࡲࡸ࠭ᜎ")) or bstack11ll111l111_opy_.get(bstack1l1l11_opy_ (u"ࠩࡪࡳࡴ࡭࠺ࡤࡪࡵࡳࡲ࡫ࡏࡱࡶ࡬ࡳࡳࡹࠧᜏ"), {})
          if bstack1l1l11_opy_ (u"ࠪ࠱࠲࡮ࡥࡢࡦ࡯ࡩࡸࡹࠧᜐ") in bstack1l1lll111l1_opy_.get(bstack1l1l11_opy_ (u"ࠫࡦࡸࡧࡴࠩᜑ"), []):
              logger.warning(bstack1l1l11_opy_ (u"ࠧࡇࡣࡤࡧࡶࡷ࡮ࡨࡩ࡭࡫ࡷࡽࠥࡇࡵࡵࡱࡰࡥࡹ࡯࡯࡯ࠢࡺ࡭ࡱࡲࠠ࡯ࡱࡷࠤࡷࡻ࡮ࠡࡱࡱࠤࡱ࡫ࡧࡢࡥࡼࠤ࡭࡫ࡡࡥ࡮ࡨࡷࡸࠦ࡭ࡰࡦࡨ࠲࡙ࠥࡷࡪࡶࡦ࡬ࠥࡺ࡯ࠡࡰࡨࡻࠥ࡮ࡥࡢࡦ࡯ࡩࡸࡹࠠ࡮ࡱࡧࡩࠥࡵࡲࠡࡣࡹࡳ࡮ࡪࠠࡶࡵ࡬ࡲ࡬ࠦࡨࡦࡣࡧࡰࡪࡹࡳࠡ࡯ࡲࡨࡪ࠴ࠢᜒ"))
              return False
        return True
    except Exception as error:
        logger.debug(bstack1l1l11_opy_ (u"ࠨࡅࡹࡥࡨࡴࡹ࡯࡯࡯ࠢ࡬ࡲࠥࡼࡡ࡭࡫ࡧࡥࡹ࡫ࠠࡢ࠳࠴ࡽࠥࡹࡵࡱࡲࡲࡶࡹࠦ࠺ࠣᜓ") + str(error))
        return False
def set_capabilities(caps, config):
  try:
    bstack1ll1llll111_opy_ = config.get(bstack1l1l11_opy_ (u"ࠧࡢࡥࡦࡩࡸࡹࡩࡣ࡫࡯࡭ࡹࡿࡏࡱࡶ࡬ࡳࡳࡹ᜔ࠧ"), {})
    bstack1ll1llll111_opy_[bstack1l1l11_opy_ (u"ࠨࡣࡸࡸ࡭࡚࡯࡬ࡧࡱ᜕ࠫ")] = os.getenv(bstack1l1l11_opy_ (u"ࠩࡅࡗࡤࡇ࠱࠲࡛ࡢࡎ࡜࡚ࠧ᜖"))
    bstack11ll11l111l_opy_ = json.loads(os.getenv(bstack1l1l11_opy_ (u"ࠪࡆࡗࡕࡗࡔࡇࡕࡗ࡙ࡇࡃࡌࡡࡗࡉࡘ࡚࡟ࡂࡅࡆࡉࡘ࡙ࡉࡃࡋࡏࡍ࡙࡟࡟ࡄࡑࡑࡊࡎࡍࡕࡓࡃࡗࡍࡔࡔ࡟࡚ࡏࡏࠫ᜗"), bstack1l1l11_opy_ (u"ࠫࢀࢃࠧ᜘"))).get(bstack1l1l11_opy_ (u"ࠬࡹࡣࡢࡰࡱࡩࡷ࡜ࡥࡳࡵ࡬ࡳࡳ࠭᜙"))
    if not config[bstack1l1l11_opy_ (u"࠭ࡢࡶ࡫࡯ࡨࡕࡸ࡯ࡥࡷࡦࡸࡒࡧࡰࠨ᜚")].get(bstack1l1l11_opy_ (u"ࠢࡢࡲࡳࡣࡦࡻࡴࡰ࡯ࡤࡸࡪࠨ᜛")):
      if bstack1l1l11_opy_ (u"ࠨࡤࡶࡸࡦࡩ࡫࠻ࡱࡳࡸ࡮ࡵ࡮ࡴࠩ᜜") in caps:
        caps[bstack1l1l11_opy_ (u"ࠩࡥࡷࡹࡧࡣ࡬࠼ࡲࡴࡹ࡯࡯࡯ࡵࠪ᜝")][bstack1l1l11_opy_ (u"ࠪࡥࡨࡩࡥࡴࡵ࡬ࡦ࡮ࡲࡩࡵࡻࡒࡴࡹ࡯࡯࡯ࡵࠪ᜞")] = bstack1ll1llll111_opy_
        caps[bstack1l1l11_opy_ (u"ࠫࡧࡹࡴࡢࡥ࡮࠾ࡴࡶࡴࡪࡱࡱࡷࠬᜟ")][bstack1l1l11_opy_ (u"ࠬࡧࡣࡤࡧࡶࡷ࡮ࡨࡩ࡭࡫ࡷࡽࡔࡶࡴࡪࡱࡱࡷࠬᜠ")][bstack1l1l11_opy_ (u"࠭ࡳࡤࡣࡱࡲࡪࡸࡖࡦࡴࡶ࡭ࡴࡴࠧᜡ")] = bstack11ll11l111l_opy_
      else:
        caps[bstack1l1l11_opy_ (u"ࠧࡣࡴࡲࡻࡸ࡫ࡲࡴࡶࡤࡧࡰ࠴ࡡࡤࡥࡨࡷࡸ࡯ࡢࡪ࡮࡬ࡸࡾࡕࡰࡵ࡫ࡲࡲࡸ࠭ᜢ")] = bstack1ll1llll111_opy_
        caps[bstack1l1l11_opy_ (u"ࠨࡤࡵࡳࡼࡹࡥࡳࡵࡷࡥࡨࡱ࠮ࡢࡥࡦࡩࡸࡹࡩࡣ࡫࡯࡭ࡹࡿࡏࡱࡶ࡬ࡳࡳࡹࠧᜣ")][bstack1l1l11_opy_ (u"ࠩࡶࡧࡦࡴ࡮ࡦࡴ࡙ࡩࡷࡹࡩࡰࡰࠪᜤ")] = bstack11ll11l111l_opy_
  except Exception as error:
    logger.debug(bstack1l1l11_opy_ (u"ࠥࡉࡽࡩࡥࡱࡶ࡬ࡳࡳࠦࡷࡩ࡫࡯ࡩࠥࡹࡥࡵࡶ࡬ࡲ࡬ࠦࡁࡤࡥࡨࡷࡸ࡯ࡢࡪ࡮࡬ࡸࡾࠦࡁࡶࡶࡲࡱࡦࡺࡩࡰࡰࠣࡧࡦࡶࡡࡣ࡫࡯࡭ࡹ࡯ࡥࡴ࠰ࠣࡉࡷࡸ࡯ࡳ࠼ࠣࠦᜥ") +  str(error))
def bstack1ll1ll11_opy_(driver, bstack11ll111ll1l_opy_):
  try:
    setattr(driver, bstack1l1l11_opy_ (u"ࠫࡧࡹࡴࡢࡥ࡮ࡅ࠶࠷ࡹࡔࡪࡲࡹࡱࡪࡓࡤࡣࡱࠫᜦ"), True)
    session = driver.session_id
    if session:
      bstack11ll11l1l1l_opy_ = True
      current_url = driver.current_url
      try:
        url = urlparse(current_url)
      except Exception as e:
        bstack11ll11l1l1l_opy_ = False
      bstack11ll11l1l1l_opy_ = url.scheme in [bstack1l1l11_opy_ (u"ࠧ࡮ࡴࡵࡲࠥᜧ"), bstack1l1l11_opy_ (u"ࠨࡨࡵࡶࡳࡷࠧᜨ")]
      if bstack11ll11l1l1l_opy_:
        if bstack11ll111ll1l_opy_:
          logger.info(bstack1l1l11_opy_ (u"ࠢࡔࡧࡷࡹࡵࠦࡦࡰࡴࠣࡅࡨࡩࡥࡴࡵ࡬ࡦ࡮ࡲࡩࡵࡻࠣࡸࡪࡹࡴࡪࡰࡪࠤ࡭ࡧࡳࠡࡵࡷࡥࡷࡺࡥࡥ࠰ࠣࡅࡺࡺ࡯࡮ࡣࡷࡩࠥࡺࡥࡴࡶࠣࡧࡦࡹࡥࠡࡧࡻࡩࡨࡻࡴࡪࡱࡱࠤࡼ࡯࡬࡭ࠢࡥࡩ࡬࡯࡮ࠡ࡯ࡲࡱࡪࡴࡴࡢࡴ࡬ࡰࡾ࠴ࠢᜩ"))
      return bstack11ll111ll1l_opy_
  except Exception as e:
    logger.error(bstack1l1l11_opy_ (u"ࠣࡇࡻࡧࡪࡶࡴࡪࡱࡱࠤ࡮ࡴࠠࡴࡶࡤࡶࡹ࡯࡮ࡨࠢࡤࡧࡨ࡫ࡳࡴ࡫ࡥ࡭ࡱ࡯ࡴࡺࠢࡤࡹࡹࡵ࡭ࡢࡶ࡬ࡳࡳࠦࡳࡤࡣࡱࠤ࡫ࡵࡲࠡࡶ࡫࡭ࡸࠦࡴࡦࡵࡷࠤࡨࡧࡳࡦ࠼ࠣࠦᜪ") + str(e))
    return False
def bstack1ll1l1lll1_opy_(driver, name, path):
  try:
    bstack1l1ll1l1ll1_opy_ = {
        bstack1l1l11_opy_ (u"ࠩࡷ࡬࡙࡫ࡳࡵࡔࡸࡲ࡚ࡻࡩࡥࠩᜫ"): threading.current_thread().current_test_uuid,
        bstack1l1l11_opy_ (u"ࠪࡸ࡭ࡈࡵࡪ࡮ࡧ࡙ࡺ࡯ࡤࠨᜬ"): os.environ.get(bstack1l1l11_opy_ (u"ࠫࡇࡘࡏࡘࡕࡈࡖࡘ࡚ࡁࡄࡍࡢࡘࡊ࡙ࡔࡉࡗࡅࡣ࡚࡛ࡉࡅࠩᜭ"), bstack1l1l11_opy_ (u"ࠬ࠭ᜮ")),
        bstack1l1l11_opy_ (u"࠭ࡴࡩࡌࡺࡸ࡙ࡵ࡫ࡦࡰࠪᜯ"): os.environ.get(bstack1l1l11_opy_ (u"ࠧࡃࡔࡒ࡛ࡘࡋࡒࡔࡖࡄࡇࡐࡥࡔࡆࡕࡗࡌ࡚ࡈ࡟ࡋ࡙ࡗࠫᜰ"), bstack1l1l11_opy_ (u"ࠨࠩᜱ"))
    }
    bstack1l1ll1ll111_opy_ = bstack1111ll1l1_opy_.bstack1l1ll1ll1ll_opy_(EVENTS.bstack1llll11lll_opy_.value)
    logger.debug(bstack1l1l11_opy_ (u"ࠩࡓࡩࡷ࡬࡯ࡳ࡯࡬ࡲ࡬ࠦࡳࡤࡣࡱࠤࡧ࡫ࡦࡰࡴࡨࠤࡸࡧࡶࡪࡰࡪࠤࡷ࡫ࡳࡶ࡮ࡷࡷࠬᜲ"))
    try:
      if (bstack1lll11ll1l_opy_(threading.current_thread(), bstack1l1l11_opy_ (u"ࠪ࡭ࡸࡇࡰࡱࡃ࠴࠵ࡾ࡚ࡥࡴࡶࠪᜳ"), None) and bstack1lll11ll1l_opy_(threading.current_thread(), bstack1l1l11_opy_ (u"ࠫࡦࡶࡰࡂ࠳࠴ࡽࡕࡲࡡࡵࡨࡲࡶࡲ᜴࠭"), None)):
        scripts = {bstack1l1l11_opy_ (u"ࠬࡹࡣࡢࡰࠪ᜵"): bstack11111llll_opy_.perform_scan}
        bstack11ll11l1lll_opy_ = json.loads(scripts[bstack1l1l11_opy_ (u"ࠨࡳࡤࡣࡱࠦ᜶")].replace(bstack1l1l11_opy_ (u"ࠢࡣࡴࡲࡻࡸ࡫ࡲࡴࡶࡤࡧࡰࡥࡥࡹࡧࡦࡹࡹࡵࡲ࠻ࠢࠥ᜷"), bstack1l1l11_opy_ (u"ࠣࠤ᜸")))
        bstack11ll11l1lll_opy_[bstack1l1l11_opy_ (u"ࠩࡤࡶ࡬ࡻ࡭ࡦࡰࡷࡷࠬ᜹")][bstack1l1l11_opy_ (u"ࠪࡱࡪࡺࡨࡰࡦࠪ᜺")] = None
        scripts[bstack1l1l11_opy_ (u"ࠦࡸࡩࡡ࡯ࠤ᜻")] = bstack1l1l11_opy_ (u"ࠧࡨࡲࡰࡹࡶࡩࡷࡹࡴࡢࡥ࡮ࡣࡪࡾࡥࡤࡷࡷࡳࡷࡀࠠࠣ᜼") + json.dumps(bstack11ll11l1lll_opy_)
        bstack11111llll_opy_.bstack1l1l1ll1l1_opy_(scripts)
        bstack11111llll_opy_.store()
        logger.debug(driver.execute_script(bstack11111llll_opy_.perform_scan))
      else:
        logger.debug(driver.execute_async_script(bstack11111llll_opy_.perform_scan, {bstack1l1l11_opy_ (u"ࠨ࡭ࡦࡶ࡫ࡳࡩࠨ᜽"): name}))
      bstack1111ll1l1_opy_.end(EVENTS.bstack1llll11lll_opy_.value, bstack1l1ll1ll111_opy_ + bstack1l1l11_opy_ (u"ࠢ࠻ࡵࡷࡥࡷࡺࠢ᜾"), bstack1l1ll1ll111_opy_ + bstack1l1l11_opy_ (u"ࠣ࠼ࡨࡲࡩࠨ᜿"), True, None)
    except Exception as error:
      bstack1111ll1l1_opy_.end(EVENTS.bstack1llll11lll_opy_.value, bstack1l1ll1ll111_opy_ + bstack1l1l11_opy_ (u"ࠤ࠽ࡷࡹࡧࡲࡵࠤᝀ"), bstack1l1ll1ll111_opy_ + bstack1l1l11_opy_ (u"ࠥ࠾ࡪࡴࡤࠣᝁ"), False, str(error))
    bstack1l1ll1ll111_opy_ = bstack1111ll1l1_opy_.bstack11ll1l111l1_opy_(EVENTS.bstack1l1llll1ll1_opy_.value)
    bstack1111ll1l1_opy_.mark(bstack1l1ll1ll111_opy_ + bstack1l1l11_opy_ (u"ࠦ࠿ࡹࡴࡢࡴࡷࠦᝂ"))
    try:
      if (bstack1lll11ll1l_opy_(threading.current_thread(), bstack1l1l11_opy_ (u"ࠬ࡯ࡳࡂࡲࡳࡅ࠶࠷ࡹࡕࡧࡶࡸࠬᝃ"), None) and bstack1lll11ll1l_opy_(threading.current_thread(), bstack1l1l11_opy_ (u"࠭ࡡࡱࡲࡄ࠵࠶ࡿࡐ࡭ࡣࡷࡪࡴࡸ࡭ࠨᝄ"), None)):
        scripts = {bstack1l1l11_opy_ (u"ࠧࡴࡥࡤࡲࠬᝅ"): bstack11111llll_opy_.perform_scan}
        bstack11ll11l1lll_opy_ = json.loads(scripts[bstack1l1l11_opy_ (u"ࠣࡵࡦࡥࡳࠨᝆ")].replace(bstack1l1l11_opy_ (u"ࠤࡥࡶࡴࡽࡳࡦࡴࡶࡸࡦࡩ࡫ࡠࡧࡻࡩࡨࡻࡴࡰࡴ࠽ࠤࠧᝇ"), bstack1l1l11_opy_ (u"ࠥࠦᝈ")))
        bstack11ll11l1lll_opy_[bstack1l1l11_opy_ (u"ࠫࡦࡸࡧࡶ࡯ࡨࡲࡹࡹࠧᝉ")][bstack1l1l11_opy_ (u"ࠬࡳࡥࡵࡪࡲࡨࠬᝊ")] = None
        scripts[bstack1l1l11_opy_ (u"ࠨࡳࡤࡣࡱࠦᝋ")] = bstack1l1l11_opy_ (u"ࠢࡣࡴࡲࡻࡸ࡫ࡲࡴࡶࡤࡧࡰࡥࡥࡹࡧࡦࡹࡹࡵࡲ࠻ࠢࠥᝌ") + json.dumps(bstack11ll11l1lll_opy_)
        bstack11111llll_opy_.bstack1l1l1ll1l1_opy_(scripts)
        bstack11111llll_opy_.store()
        logger.debug(driver.execute_script(bstack11111llll_opy_.perform_scan))
      else:
        logger.debug(driver.execute_async_script(bstack11111llll_opy_.bstack11ll11111l1_opy_, bstack1l1ll1l1ll1_opy_))
      bstack1111ll1l1_opy_.end(bstack1l1ll1ll111_opy_, bstack1l1ll1ll111_opy_ + bstack1l1l11_opy_ (u"ࠣ࠼ࡶࡸࡦࡸࡴࠣᝍ"), bstack1l1ll1ll111_opy_ + bstack1l1l11_opy_ (u"ࠤ࠽ࡩࡳࡪࠢᝎ"),True, None)
    except Exception as error:
      bstack1111ll1l1_opy_.end(bstack1l1ll1ll111_opy_, bstack1l1ll1ll111_opy_ + bstack1l1l11_opy_ (u"ࠥ࠾ࡸࡺࡡࡳࡶࠥᝏ"), bstack1l1ll1ll111_opy_ + bstack1l1l11_opy_ (u"ࠦ࠿࡫࡮ࡥࠤᝐ"),False, str(error))
    logger.info(bstack1l1l11_opy_ (u"ࠧࡇࡣࡤࡧࡶࡷ࡮ࡨࡩ࡭࡫ࡷࡽࠥࡺࡥࡴࡶ࡬ࡲ࡬ࠦࡦࡰࡴࠣࡸ࡭࡯ࡳࠡࡶࡨࡷࡹࠦࡣࡢࡵࡨࠤ࡭ࡧࡳࠡࡧࡱࡨࡪࡪ࠮ࠣᝑ"))
  except Exception as bstack1l1lll1l11l_opy_:
    logger.error(bstack1l1l11_opy_ (u"ࠨࡁࡤࡥࡨࡷࡸ࡯ࡢࡪ࡮࡬ࡸࡾࠦࡲࡦࡵࡸࡰࡹࡹࠠࡤࡱࡸࡰࡩࠦ࡮ࡰࡶࠣࡦࡪࠦࡰࡳࡱࡦࡩࡸࡹࡥࡥࠢࡩࡳࡷࠦࡴࡩࡧࠣࡸࡪࡹࡴࠡࡥࡤࡷࡪࡀࠠࠣᝒ") + str(path) + bstack1l1l11_opy_ (u"ࠢࠡࡇࡵࡶࡴࡸࠠ࠻ࠤᝓ") + str(bstack1l1lll1l11l_opy_))
def bstack11ll11lllll_opy_(driver):
    caps = driver.capabilities
    if caps.get(bstack1l1l11_opy_ (u"ࠣࡲ࡯ࡥࡹ࡬࡯ࡳ࡯ࡑࡥࡲ࡫ࠢ᝔")) and str(caps.get(bstack1l1l11_opy_ (u"ࠤࡳࡰࡦࡺࡦࡰࡴࡰࡒࡦࡳࡥࠣ᝕"))).lower() == bstack1l1l11_opy_ (u"ࠥࡥࡳࡪࡲࡰ࡫ࡧࠦ᝖"):
        bstack1l1ll11l1l1_opy_ = caps.get(bstack1l1l11_opy_ (u"ࠦࡦࡶࡰࡪࡷࡰ࠾ࡵࡲࡡࡵࡨࡲࡶࡲ࡜ࡥࡳࡵ࡬ࡳࡳࠨ᝗")) or caps.get(bstack1l1l11_opy_ (u"ࠧࡶ࡬ࡢࡶࡩࡳࡷࡳࡖࡦࡴࡶ࡭ࡴࡴࠢ᝘"))
        if bstack1l1ll11l1l1_opy_ and int(str(bstack1l1ll11l1l1_opy_)) < bstack11ll1l11ll1_opy_:
            return False
    return True
def bstack1lll1ll111_opy_(config):
  if bstack1l1l11_opy_ (u"࠭ࡡࡤࡥࡨࡷࡸ࡯ࡢࡪ࡮࡬ࡸࡾ࠭᝙") in config:
        return config[bstack1l1l11_opy_ (u"ࠧࡢࡥࡦࡩࡸࡹࡩࡣ࡫࡯࡭ࡹࡿࠧ᝚")]
  for platform in config.get(bstack1l1l11_opy_ (u"ࠨࡲ࡯ࡥࡹ࡬࡯ࡳ࡯ࡶࠫ᝛"), []):
      if bstack1l1l11_opy_ (u"ࠩࡤࡧࡨ࡫ࡳࡴ࡫ࡥ࡭ࡱ࡯ࡴࡺࠩ᝜") in platform:
          return platform[bstack1l1l11_opy_ (u"ࠪࡥࡨࡩࡥࡴࡵ࡬ࡦ࡮ࡲࡩࡵࡻࠪ᝝")]
  return None
def bstack1llll1l11l_opy_(bstack11ll111ll1_opy_):
  try:
    browser_name = bstack11ll111ll1_opy_[bstack1l1l11_opy_ (u"ࠫࡧࡸ࡯ࡸࡵࡨࡶࡤࡴࡡ࡮ࡧࠪ᝞")]
    browser_version = bstack11ll111ll1_opy_[bstack1l1l11_opy_ (u"ࠬࡨࡲࡰࡹࡶࡩࡷࡥࡶࡦࡴࡶ࡭ࡴࡴࠧ᝟")]
    chrome_options = bstack11ll111ll1_opy_[bstack1l1l11_opy_ (u"࠭ࡣࡩࡴࡲࡱࡪࡥ࡯ࡱࡶ࡬ࡳࡳࡹࠧᝠ")]
    try:
        bstack11ll111111l_opy_ = int(browser_version.split(bstack1l1l11_opy_ (u"ࠧ࠯ࠩᝡ"))[0])
    except ValueError as e:
        logger.error(bstack1l1l11_opy_ (u"ࠣࡇࡵࡶࡴࡸࠠࡸࡪ࡬ࡰࡪࠦࡣࡰࡰࡹࡩࡷࡺࡩ࡯ࡩࠣࡦࡷࡵࡷࡴࡧࡵࠤࡻ࡫ࡲࡴ࡫ࡲࡲࠧᝢ") + str(e))
        return False
    if not (browser_name and browser_name.lower() == bstack1l1l11_opy_ (u"ࠩࡦ࡬ࡷࡵ࡭ࡦࠩᝣ")):
        logger.warning(bstack1l1l11_opy_ (u"ࠥࡅࡨࡩࡥࡴࡵ࡬ࡦ࡮ࡲࡩࡵࡻࠣࡅࡺࡺ࡯࡮ࡣࡷ࡭ࡴࡴࠠࡸ࡫࡯ࡰࠥࡸࡵ࡯ࠢࡲࡲࡱࡿࠠࡰࡰࠣࡇ࡭ࡸ࡯࡮ࡧࠣࡦࡷࡵࡷࡴࡧࡵࡷ࠳ࠨᝤ"))
        return False
    if bstack11ll111111l_opy_ < bstack11ll11ll11l_opy_.bstack1l1lllll1ll_opy_:
        logger.warning(bstack1ll1ll1l11l_opy_ (u"ࠫࡆࡩࡣࡦࡵࡶ࡭ࡧ࡯࡬ࡪࡶࡼࠤࡆࡻࡴࡰ࡯ࡤࡸ࡮ࡵ࡮ࠡࡴࡨࡵࡺ࡯ࡲࡦࡵࠣࡇ࡭ࡸ࡯࡮ࡧࠣࡺࡪࡸࡳࡪࡱࡱࠤࢀࡉࡏࡏࡕࡗࡅࡓ࡚ࡓ࠯ࡏࡌࡒࡎࡓࡕࡎࡡࡑࡓࡓࡥࡂࡔࡖࡄࡇࡐࡥࡉࡏࡈࡕࡅࡤࡇ࠱࠲࡛ࡢࡗ࡚ࡖࡐࡐࡔࡗࡉࡉࡥࡃࡉࡔࡒࡑࡊࡥࡖࡆࡔࡖࡍࡔࡔࡽࠡࡱࡵࠤ࡭࡯ࡧࡩࡧࡵ࠲ࠬᝥ"))
        return False
    if chrome_options and any(bstack1l1l11_opy_ (u"ࠬ࠳࠭ࡩࡧࡤࡨࡱ࡫ࡳࡴࠩᝦ") in value for value in chrome_options.values() if isinstance(value, str)):
        logger.warning(bstack1l1l11_opy_ (u"ࠨࡁࡤࡥࡨࡷࡸ࡯ࡢࡪ࡮࡬ࡸࡾࠦࡁࡶࡶࡲࡱࡦࡺࡩࡰࡰࠣࡻ࡮ࡲ࡬ࠡࡰࡲࡸࠥࡸࡵ࡯ࠢࡲࡲࠥࡲࡥࡨࡣࡦࡽࠥ࡮ࡥࡢࡦ࡯ࡩࡸࡹࠠ࡮ࡱࡧࡩ࠳ࠦࡓࡸ࡫ࡷࡧ࡭ࠦࡴࡰࠢࡱࡩࡼࠦࡨࡦࡣࡧࡰࡪࡹࡳࠡ࡯ࡲࡨࡪࠦ࡯ࡳࠢࡤࡺࡴ࡯ࡤࠡࡷࡶ࡭ࡳ࡭ࠠࡩࡧࡤࡨࡱ࡫ࡳࡴࠢࡰࡳࡩ࡫࠮ࠣᝧ"))
        return False
    return True
  except Exception as e:
    logger.error(bstack1l1l11_opy_ (u"ࠢࡆࡴࡵࡳࡷࠦࡩ࡯ࠢࡦ࡬ࡪࡩ࡫ࡪࡰࡪࠤࡵࡲࡡࡵࡨࡲࡶࡲࠦࡳࡶࡲࡳࡳࡷࡺࠠࡧࡱࡵࠤࡱࡵࡣࡢ࡮ࠣࡇ࡭ࡸ࡯࡮ࡧ࠽ࠤࠧᝨ") + str(e))
    return False
def bstack1l111l11l1_opy_(bstack1l11ll11l_opy_, config):
    try:
      bstack1l1ll111ll1_opy_ = bstack1l1l11_opy_ (u"ࠨࡣࡦࡧࡪࡹࡳࡪࡤ࡬ࡰ࡮ࡺࡹࠨᝩ") in config and config[bstack1l1l11_opy_ (u"ࠩࡤࡧࡨ࡫ࡳࡴ࡫ࡥ࡭ࡱ࡯ࡴࡺࠩᝪ")] == True
      bstack11ll1l1l1l1_opy_ = bstack1l1l11_opy_ (u"ࠪࡸࡺࡸࡢࡰࡕࡦࡥࡱ࡫ࠧᝫ") in config and str(config[bstack1l1l11_opy_ (u"ࠫࡹࡻࡲࡣࡱࡖࡧࡦࡲࡥࠨᝬ")]).lower() != bstack1l1l11_opy_ (u"ࠬ࡬ࡡ࡭ࡵࡨࠫ᝭")
      if not (bstack1l1ll111ll1_opy_ and (not bstack1llll1l1l_opy_(config) or bstack11ll1l1l1l1_opy_)):
        return bstack1l11ll11l_opy_
      bstack11ll11llll1_opy_ = bstack11111llll_opy_.bstack11ll11l11ll_opy_
      if bstack11ll11llll1_opy_ is None:
        logger.debug(bstack1l1l11_opy_ (u"ࠨࡇࡰࡱࡪࡰࡪࠦࡣࡩࡴࡲࡱࡪࠦ࡯ࡱࡶ࡬ࡳࡳࡹࠠࡢࡴࡨࠤࡓࡵ࡮ࡦࠤᝮ"))
        return bstack1l11ll11l_opy_
      bstack11ll1l1l111_opy_ = int(str(bstack11ll11l1111_opy_()).split(bstack1l1l11_opy_ (u"ࠧ࠯ࠩᝯ"))[0])
      logger.debug(bstack1l1l11_opy_ (u"ࠣࡕࡨࡰࡪࡴࡩࡶ࡯ࠣࡺࡪࡸࡳࡪࡱࡱࠤࡩ࡫ࡴࡦࡥࡷࡩࡩࡀࠠࠣᝰ") + str(bstack11ll1l1l111_opy_) + bstack1l1l11_opy_ (u"ࠤࠥ᝱"))
      if bstack11ll1l1l111_opy_ == 3 and isinstance(bstack1l11ll11l_opy_, dict) and bstack1l1l11_opy_ (u"ࠪࡨࡪࡹࡩࡳࡧࡧࡣࡨࡧࡰࡢࡤ࡬ࡰ࡮ࡺࡩࡦࡵࠪᝲ") in bstack1l11ll11l_opy_ and bstack11ll11llll1_opy_ is not None:
        if bstack1l1l11_opy_ (u"ࠫ࡬ࡵ࡯ࡨ࠼ࡦ࡬ࡷࡵ࡭ࡦࡑࡳࡸ࡮ࡵ࡮ࡴࠩᝳ") not in bstack1l11ll11l_opy_[bstack1l1l11_opy_ (u"ࠬࡪࡥࡴ࡫ࡵࡩࡩࡥࡣࡢࡲࡤࡦ࡮ࡲࡩࡵ࡫ࡨࡷࠬ᝴")]:
          bstack1l11ll11l_opy_[bstack1l1l11_opy_ (u"࠭ࡤࡦࡵ࡬ࡶࡪࡪ࡟ࡤࡣࡳࡥࡧ࡯࡬ࡪࡶ࡬ࡩࡸ࠭᝵")][bstack1l1l11_opy_ (u"ࠧࡨࡱࡲ࡫࠿ࡩࡨࡳࡱࡰࡩࡔࡶࡴࡪࡱࡱࡷࠬ᝶")] = {}
        if bstack1l1l11_opy_ (u"ࠨࡣࡵ࡫ࡸ࠭᝷") in bstack11ll11llll1_opy_:
          if bstack1l1l11_opy_ (u"ࠩࡤࡶ࡬ࡹࠧ᝸") not in bstack1l11ll11l_opy_[bstack1l1l11_opy_ (u"ࠪࡨࡪࡹࡩࡳࡧࡧࡣࡨࡧࡰࡢࡤ࡬ࡰ࡮ࡺࡩࡦࡵࠪ᝹")][bstack1l1l11_opy_ (u"ࠫ࡬ࡵ࡯ࡨ࠼ࡦ࡬ࡷࡵ࡭ࡦࡑࡳࡸ࡮ࡵ࡮ࡴࠩ᝺")]:
            bstack1l11ll11l_opy_[bstack1l1l11_opy_ (u"ࠬࡪࡥࡴ࡫ࡵࡩࡩࡥࡣࡢࡲࡤࡦ࡮ࡲࡩࡵ࡫ࡨࡷࠬ᝻")][bstack1l1l11_opy_ (u"࠭ࡧࡰࡱࡪ࠾ࡨ࡮ࡲࡰ࡯ࡨࡓࡵࡺࡩࡰࡰࡶࠫ᝼")][bstack1l1l11_opy_ (u"ࠧࡢࡴࡪࡷࠬ᝽")] = []
          for arg in bstack11ll11llll1_opy_[bstack1l1l11_opy_ (u"ࠨࡣࡵ࡫ࡸ࠭᝾")]:
            if arg not in bstack1l11ll11l_opy_[bstack1l1l11_opy_ (u"ࠩࡧࡩࡸ࡯ࡲࡦࡦࡢࡧࡦࡶࡡࡣ࡫࡯࡭ࡹ࡯ࡥࡴࠩ᝿")][bstack1l1l11_opy_ (u"ࠪ࡫ࡴࡵࡧ࠻ࡥ࡫ࡶࡴࡳࡥࡐࡲࡷ࡭ࡴࡴࡳࠨក")][bstack1l1l11_opy_ (u"ࠫࡦࡸࡧࡴࠩខ")]:
              bstack1l11ll11l_opy_[bstack1l1l11_opy_ (u"ࠬࡪࡥࡴ࡫ࡵࡩࡩࡥࡣࡢࡲࡤࡦ࡮ࡲࡩࡵ࡫ࡨࡷࠬគ")][bstack1l1l11_opy_ (u"࠭ࡧࡰࡱࡪ࠾ࡨ࡮ࡲࡰ࡯ࡨࡓࡵࡺࡩࡰࡰࡶࠫឃ")][bstack1l1l11_opy_ (u"ࠧࡢࡴࡪࡷࠬង")].append(arg)
        if bstack1l1l11_opy_ (u"ࠨࡧࡻࡸࡪࡴࡳࡪࡱࡱࡷࠬច") in bstack11ll11llll1_opy_:
          if bstack1l1l11_opy_ (u"ࠩࡨࡼࡹ࡫࡮ࡴ࡫ࡲࡲࡸ࠭ឆ") not in bstack1l11ll11l_opy_[bstack1l1l11_opy_ (u"ࠪࡨࡪࡹࡩࡳࡧࡧࡣࡨࡧࡰࡢࡤ࡬ࡰ࡮ࡺࡩࡦࡵࠪជ")][bstack1l1l11_opy_ (u"ࠫ࡬ࡵ࡯ࡨ࠼ࡦ࡬ࡷࡵ࡭ࡦࡑࡳࡸ࡮ࡵ࡮ࡴࠩឈ")]:
            bstack1l11ll11l_opy_[bstack1l1l11_opy_ (u"ࠬࡪࡥࡴ࡫ࡵࡩࡩࡥࡣࡢࡲࡤࡦ࡮ࡲࡩࡵ࡫ࡨࡷࠬញ")][bstack1l1l11_opy_ (u"࠭ࡧࡰࡱࡪ࠾ࡨ࡮ࡲࡰ࡯ࡨࡓࡵࡺࡩࡰࡰࡶࠫដ")][bstack1l1l11_opy_ (u"ࠧࡦࡺࡷࡩࡳࡹࡩࡰࡰࡶࠫឋ")] = []
          for ext in bstack11ll11llll1_opy_[bstack1l1l11_opy_ (u"ࠨࡧࡻࡸࡪࡴࡳࡪࡱࡱࡷࠬឌ")]:
            if ext not in bstack1l11ll11l_opy_[bstack1l1l11_opy_ (u"ࠩࡧࡩࡸ࡯ࡲࡦࡦࡢࡧࡦࡶࡡࡣ࡫࡯࡭ࡹ࡯ࡥࡴࠩឍ")][bstack1l1l11_opy_ (u"ࠪ࡫ࡴࡵࡧ࠻ࡥ࡫ࡶࡴࡳࡥࡐࡲࡷ࡭ࡴࡴࡳࠨណ")][bstack1l1l11_opy_ (u"ࠫࡪࡾࡴࡦࡰࡶ࡭ࡴࡴࡳࠨត")]:
              bstack1l11ll11l_opy_[bstack1l1l11_opy_ (u"ࠬࡪࡥࡴ࡫ࡵࡩࡩࡥࡣࡢࡲࡤࡦ࡮ࡲࡩࡵ࡫ࡨࡷࠬថ")][bstack1l1l11_opy_ (u"࠭ࡧࡰࡱࡪ࠾ࡨ࡮ࡲࡰ࡯ࡨࡓࡵࡺࡩࡰࡰࡶࠫទ")][bstack1l1l11_opy_ (u"ࠧࡦࡺࡷࡩࡳࡹࡩࡰࡰࡶࠫធ")].append(ext)
        if bstack1l1l11_opy_ (u"ࠨࡲࡵࡩ࡫ࡹࠧន") in bstack11ll11llll1_opy_:
          if bstack1l1l11_opy_ (u"ࠩࡳࡶࡪ࡬ࡳࠨប") not in bstack1l11ll11l_opy_[bstack1l1l11_opy_ (u"ࠪࡨࡪࡹࡩࡳࡧࡧࡣࡨࡧࡰࡢࡤ࡬ࡰ࡮ࡺࡩࡦࡵࠪផ")][bstack1l1l11_opy_ (u"ࠫ࡬ࡵ࡯ࡨ࠼ࡦ࡬ࡷࡵ࡭ࡦࡑࡳࡸ࡮ࡵ࡮ࡴࠩព")]:
            bstack1l11ll11l_opy_[bstack1l1l11_opy_ (u"ࠬࡪࡥࡴ࡫ࡵࡩࡩࡥࡣࡢࡲࡤࡦ࡮ࡲࡩࡵ࡫ࡨࡷࠬភ")][bstack1l1l11_opy_ (u"࠭ࡧࡰࡱࡪ࠾ࡨ࡮ࡲࡰ࡯ࡨࡓࡵࡺࡩࡰࡰࡶࠫម")][bstack1l1l11_opy_ (u"ࠧࡱࡴࡨࡪࡸ࠭យ")] = {}
          bstack11ll111llll_opy_(bstack1l11ll11l_opy_[bstack1l1l11_opy_ (u"ࠨࡦࡨࡷ࡮ࡸࡥࡥࡡࡦࡥࡵࡧࡢࡪ࡮࡬ࡸ࡮࡫ࡳࠨរ")][bstack1l1l11_opy_ (u"ࠩࡪࡳࡴ࡭࠺ࡤࡪࡵࡳࡲ࡫ࡏࡱࡶ࡬ࡳࡳࡹࠧល")][bstack1l1l11_opy_ (u"ࠪࡴࡷ࡫ࡦࡴࠩវ")],
                    bstack11ll11llll1_opy_[bstack1l1l11_opy_ (u"ࠫࡵࡸࡥࡧࡵࠪឝ")])
        os.environ[bstack1l1l11_opy_ (u"ࠬࡏࡓࡠࡐࡒࡒࡤࡈࡓࡕࡃࡆࡏࡤࡏࡎࡇࡔࡄࡣࡆ࠷࠱࡚ࡡࡖࡉࡘ࡙ࡉࡐࡐࠪឞ")] = bstack1l1l11_opy_ (u"࠭ࡴࡳࡷࡨࠫស")
        return bstack1l11ll11l_opy_
      else:
        chrome_options = None
        if isinstance(bstack1l11ll11l_opy_, ChromeOptions):
          chrome_options = bstack1l11ll11l_opy_
        elif isinstance(bstack1l11ll11l_opy_, dict):
          for value in bstack1l11ll11l_opy_.values():
            if isinstance(value, ChromeOptions):
              chrome_options = value
              break
        if chrome_options is None:
          chrome_options = ChromeOptions()
          if isinstance(bstack1l11ll11l_opy_, dict):
            bstack1l11ll11l_opy_[bstack1l1l11_opy_ (u"ࠧࡰࡲࡷ࡭ࡴࡴࡳࠨហ")] = chrome_options
          else:
            bstack1l11ll11l_opy_ = chrome_options
        if bstack11ll11llll1_opy_ is not None:
          if bstack1l1l11_opy_ (u"ࠨࡣࡵ࡫ࡸ࠭ឡ") in bstack11ll11llll1_opy_:
                bstack11ll111l1l1_opy_ = chrome_options.arguments or []
                new_args = bstack11ll11llll1_opy_[bstack1l1l11_opy_ (u"ࠩࡤࡶ࡬ࡹࠧអ")]
                for arg in new_args:
                    if arg not in bstack11ll111l1l1_opy_:
                        chrome_options.add_argument(arg)
          if bstack1l1l11_opy_ (u"ࠪࡩࡽࡺࡥ࡯ࡵ࡬ࡳࡳࡹࠧឣ") in bstack11ll11llll1_opy_:
                existing_extensions = chrome_options.experimental_options.get(bstack1l1l11_opy_ (u"ࠫࡪࡾࡴࡦࡰࡶ࡭ࡴࡴࡳࠨឤ"), [])
                bstack11ll11111ll_opy_ = bstack11ll11llll1_opy_[bstack1l1l11_opy_ (u"ࠬ࡫ࡸࡵࡧࡱࡷ࡮ࡵ࡮ࡴࠩឥ")]
                for extension in bstack11ll11111ll_opy_:
                    if extension not in existing_extensions:
                        chrome_options.add_encoded_extension(extension)
          if bstack1l1l11_opy_ (u"࠭ࡰࡳࡧࡩࡷࠬឦ") in bstack11ll11llll1_opy_:
                bstack11ll1111l1l_opy_ = chrome_options.experimental_options.get(bstack1l1l11_opy_ (u"ࠧࡱࡴࡨࡪࡸ࠭ឧ"), {})
                bstack11ll111lll1_opy_ = bstack11ll11llll1_opy_[bstack1l1l11_opy_ (u"ࠨࡲࡵࡩ࡫ࡹࠧឨ")]
                bstack11ll111llll_opy_(bstack11ll1111l1l_opy_, bstack11ll111lll1_opy_)
                chrome_options.add_experimental_option(bstack1l1l11_opy_ (u"ࠩࡳࡶࡪ࡬ࡳࠨឩ"), bstack11ll1111l1l_opy_)
        os.environ[bstack1l1l11_opy_ (u"ࠪࡍࡘࡥࡎࡐࡐࡢࡆࡘ࡚ࡁࡄࡍࡢࡍࡓࡌࡒࡂࡡࡄ࠵࠶࡟࡟ࡔࡇࡖࡗࡎࡕࡎࠨឪ")] = bstack1l1l11_opy_ (u"ࠫࡹࡸࡵࡦࠩឫ")
        return bstack1l11ll11l_opy_
    except Exception as e:
      logger.error(bstack1l1l11_opy_ (u"ࠧࡋࡲࡳࡱࡵࠤࡼ࡮ࡩ࡭ࡧࠣࡥࡩࡪࡩ࡯ࡩࠣࡲࡴࡴ࠭ࡃࡕࠣ࡭ࡳ࡬ࡲࡢࠢࡤ࠵࠶ࡿࠠࡤࡪࡵࡳࡲ࡫ࠠࡰࡲࡷ࡭ࡴࡴࡳ࠻ࠢࠥឬ") + str(e))
      return bstack1l11ll11l_opy_