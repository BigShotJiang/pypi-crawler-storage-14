# coding: UTF-8
import sys
bstack1l11111_opy_ = sys.version_info [0] == 2
bstack11l11ll_opy_ = 2048
bstack111ll1l_opy_ = 7
def bstack1l1l11_opy_ (bstack11l1l_opy_):
    global bstack1l11_opy_
    bstack11l1111_opy_ = ord (bstack11l1l_opy_ [-1])
    bstack1l1ll1l_opy_ = bstack11l1l_opy_ [:-1]
    bstack11l11_opy_ = bstack11l1111_opy_ % len (bstack1l1ll1l_opy_)
    bstack1l1ll11_opy_ = bstack1l1ll1l_opy_ [:bstack11l11_opy_] + bstack1l1ll1l_opy_ [bstack11l11_opy_:]
    if bstack1l11111_opy_:
        bstack11lll1l_opy_ = unicode () .join ([unichr (ord (char) - bstack11l11ll_opy_ - (bstack11l111_opy_ + bstack11l1111_opy_) % bstack111ll1l_opy_) for bstack11l111_opy_, char in enumerate (bstack1l1ll11_opy_)])
    else:
        bstack11lll1l_opy_ = str () .join ([chr (ord (char) - bstack11l11ll_opy_ - (bstack11l111_opy_ + bstack11l1111_opy_) % bstack111ll1l_opy_) for bstack11l111_opy_, char in enumerate (bstack1l1ll11_opy_)])
    return eval (bstack11lll1l_opy_)
import threading
import tempfile
import os
import time
from datetime import datetime
from bstack_utils.bstack11l1lll1l1l_opy_ import bstack11l1lll1ll1_opy_
from bstack_utils.constants import bstack11l1l111ll1_opy_, bstack11ll1lll1l_opy_
from bstack_utils.bstack11lll1ll1l_opy_ import bstack111lll11_opy_
from bstack_utils import bstack1l1lll1l_opy_
bstack11l11lll111_opy_ = 10
class bstack1l1ll1ll11_opy_:
    def __init__(self, bstack1ll1l1ll1l_opy_, config, bstack11l11llll11_opy_=0):
        self.bstack11l11lll11l_opy_ = set()
        self.lock = threading.Lock()
        self.bstack11l11l1l1l1_opy_ = bstack1l1l11_opy_ (u"ࠢࡼࡿ࠲ࡸࡪࡹࡴࡰࡴࡦ࡬ࡪࡹࡴࡳࡣࡷ࡭ࡴࡴ࠯ࡢࡲ࡬࠳ࡻ࠷࠯ࡧࡣ࡬ࡰࡪࡪ࠭ࡵࡧࡶࡸࡸࠨᬼ").format(bstack11l1l111ll1_opy_)
        self.bstack11l11ll111l_opy_ = os.path.join(tempfile.gettempdir(), bstack1l1l11_opy_ (u"ࠣࡣࡥࡳࡷࡺ࡟ࡣࡷ࡬ࡰࡩࡥࡻࡾࠤᬽ").format(os.environ.get(bstack1l1l11_opy_ (u"ࠩࡅࡖࡔ࡝ࡓࡆࡔࡖࡘࡆࡉࡋࡠࡖࡈࡗ࡙ࡎࡕࡃࡡࡘ࡙ࡎࡊࠧᬾ"))))
        self.bstack11l11lll1l1_opy_ = os.path.join(tempfile.gettempdir(), bstack1l1l11_opy_ (u"ࠥࡪࡦ࡯࡬ࡦࡦࡢࡸࡪࡹࡴࡴࡡࡾࢁ࠳ࡺࡸࡵࠤᬿ").format(os.environ.get(bstack1l1l11_opy_ (u"ࠫࡇࡘࡏࡘࡕࡈࡖࡘ࡚ࡁࡄࡍࡢࡘࡊ࡙ࡔࡉࡗࡅࡣ࡚࡛ࡉࡅࠩᭀ"))))
        self.bstack11l11lllll1_opy_ = 2
        self.bstack1ll1l1ll1l_opy_ = bstack1ll1l1ll1l_opy_
        self.config = config
        self.logger = bstack1l1lll1l_opy_.get_logger(__name__, bstack11ll1lll1l_opy_)
        self.bstack11l11llll11_opy_ = bstack11l11llll11_opy_
        self.bstack11l11lll1ll_opy_ = False
        self.bstack11l11l1ll11_opy_ = not (
                            os.environ.get(bstack1l1l11_opy_ (u"ࠧࡈࡒࡐ࡙ࡖࡉࡗ࡙ࡔࡂࡅࡎࡣࡇ࡛ࡉࡍࡆࡢࡖ࡚ࡔ࡟ࡊࡆࡈࡒ࡙ࡏࡆࡊࡇࡕࠦᭁ")) and
                            os.environ.get(bstack1l1l11_opy_ (u"ࠨࡂࡓࡑ࡚ࡗࡊࡘࡓࡕࡃࡆࡏࡤࡔࡏࡅࡇࡢࡍࡓࡊࡅ࡙ࠤᭂ")) and
                            os.environ.get(bstack1l1l11_opy_ (u"ࠢࡃࡔࡒ࡛ࡘࡋࡒࡔࡖࡄࡇࡐࡥࡔࡐࡖࡄࡐࡤࡔࡏࡅࡇࡢࡇࡔ࡛ࡎࡕࠤᭃ"))
                        )
        if bstack111lll11_opy_.bstack11l11ll1111_opy_(config):
            self.bstack11l11lllll1_opy_ = bstack111lll11_opy_.bstack11l11l1ll1l_opy_(config, self.bstack11l11llll11_opy_)
            self.bstack11l11ll1l11_opy_()
    def bstack11l11ll11l1_opy_(self):
        return bstack1l1l11_opy_ (u"ࠣࡽࢀࡣࢀࢃ᭄ࠢ").format(self.config.get(bstack1l1l11_opy_ (u"ࠩࡥࡹ࡮ࡲࡤࡏࡣࡰࡩࠬᭅ")), os.environ.get(bstack1l1l11_opy_ (u"ࠪࡆࡗࡕࡗࡔࡇࡕࡗ࡙ࡇࡃࡌࡡࡅ࡙ࡎࡒࡄࡠࡔࡘࡒࡤࡏࡄࡆࡐࡗࡍࡋࡏࡅࡓࠩᭆ")))
    def bstack11l11ll1lll_opy_(self):
        try:
            if self.bstack11l11l1ll11_opy_:
                return
            with self.lock:
                try:
                    with open(self.bstack11l11lll1l1_opy_, bstack1l1l11_opy_ (u"ࠦࡷࠨᭇ")) as f:
                        bstack11l11ll1l1l_opy_ = set(line.strip() for line in f if line.strip())
                except FileNotFoundError:
                    bstack11l11ll1l1l_opy_ = set()
                bstack11l11l1l1ll_opy_ = bstack11l11ll1l1l_opy_ - self.bstack11l11lll11l_opy_
                if not bstack11l11l1l1ll_opy_:
                    return
                self.bstack11l11lll11l_opy_.update(bstack11l11l1l1ll_opy_)
                data = {bstack1l1l11_opy_ (u"ࠧ࡬ࡡࡪ࡮ࡨࡨ࡙࡫ࡳࡵࡵࠥᭈ"): list(self.bstack11l11lll11l_opy_), bstack1l1l11_opy_ (u"ࠨࡢࡶ࡫࡯ࡨࡓࡧ࡭ࡦࠤᭉ"): self.config.get(bstack1l1l11_opy_ (u"ࠧࡣࡷ࡬ࡰࡩࡔࡡ࡮ࡧࠪᭊ")), bstack1l1l11_opy_ (u"ࠣࡤࡸ࡭ࡱࡪࡒࡶࡰࡌࡨࡪࡴࡴࡪࡨ࡬ࡩࡷࠨᭋ"): os.environ.get(bstack1l1l11_opy_ (u"ࠩࡅࡖࡔ࡝ࡓࡆࡔࡖࡘࡆࡉࡋࡠࡄࡘࡍࡑࡊ࡟ࡓࡗࡑࡣࡎࡊࡅࡏࡖࡌࡊࡎࡋࡒࠨᭌ")), bstack1l1l11_opy_ (u"ࠥࡴࡷࡵࡪࡦࡥࡷࡒࡦࡳࡥࠣ᭍"): self.config.get(bstack1l1l11_opy_ (u"ࠫࡵࡸ࡯࡫ࡧࡦࡸࡓࡧ࡭ࡦࠩ᭎"))}
            response = bstack11l1lll1ll1_opy_.bstack11l11ll11ll_opy_(self.bstack11l11l1l1l1_opy_, data)
            if response.get(bstack1l1l11_opy_ (u"ࠧࡹࡴࡢࡶࡸࡷࠧ᭏")) == 200:
                self.logger.debug(bstack1l1l11_opy_ (u"ࠨࡓࡶࡥࡦࡩࡸࡹࡦࡶ࡮࡯ࡽࠥࡹࡥ࡯ࡶࠣࡪࡦ࡯࡬ࡦࡦࠣࡸࡪࡹࡴࡴ࠼ࠣࡿࢂࠨ᭐").format(data))
            else:
                self.logger.debug(bstack1l1l11_opy_ (u"ࠢࡇࡣ࡬ࡰࡪࡪࠠࡵࡱࠣࡷࡪࡴࡤࠡࡨࡤ࡭ࡱ࡫ࡤࠡࡶࡨࡷࡹࡹ࠺ࠡࡽࢀࠦ᭑").format(response))
        except Exception as e:
            self.logger.debug(bstack1l1l11_opy_ (u"ࠣࡇࡻࡧࡪࡶࡴࡪࡱࡱࠤࡩࡻࡲࡪࡰࡪࠤࡸ࡫࡮ࡥ࡫ࡱ࡫ࠥ࡬ࡡࡪ࡮ࡨࡨࠥࡺࡥࡴࡶࡶ࠾ࠥࢁࡽࠣ᭒").format(e))
    def bstack11l11llllll_opy_(self):
        if self.bstack11l11l1ll11_opy_:
            with self.lock:
                try:
                    with open(self.bstack11l11lll1l1_opy_, bstack1l1l11_opy_ (u"ࠤࡵࠦ᭓")) as f:
                        bstack11l11llll1l_opy_ = set(line.strip() for line in f if line.strip())
                    failed_count = len(bstack11l11llll1l_opy_)
                except FileNotFoundError:
                    failed_count = 0
                self.logger.debug(bstack1l1l11_opy_ (u"ࠥࡔࡴࡲ࡬ࡦࡦࠣࡪࡦ࡯࡬ࡦࡦࠣࡸࡪࡹࡴࡴࠢࡦࡳࡺࡴࡴࠡࠪ࡯ࡳࡨࡧ࡬ࠪ࠼ࠣࡿࢂࠨ᭔").format(failed_count))
                if failed_count >= self.bstack11l11lllll1_opy_:
                    self.logger.info(bstack1l1l11_opy_ (u"࡙ࠦ࡮ࡲࡦࡵ࡫ࡳࡱࡪࠠࡤࡴࡲࡷࡸ࡫ࡤࠡࠪ࡯ࡳࡨࡧ࡬ࠪ࠼ࠣࡿࢂࠦ࠾࠾ࠢࡾࢁࠧ᭕").format(failed_count, self.bstack11l11lllll1_opy_))
                    self.bstack11l11ll1ll1_opy_(failed_count)
                    self.bstack11l11lll1ll_opy_ = True
            return
        try:
            response = bstack11l1lll1ll1_opy_.bstack11l11llllll_opy_(bstack1l1l11_opy_ (u"ࠧࢁࡽࡀࡤࡸ࡭ࡱࡪࡎࡢ࡯ࡨࡁࢀࢃࠦࡣࡷ࡬ࡰࡩࡘࡵ࡯ࡋࡧࡩࡳࡺࡩࡧ࡫ࡨࡶࡂࢁࡽࠧࡲࡵࡳ࡯࡫ࡣࡵࡐࡤࡱࡪࡃࡻࡾࠤ᭖").format(self.bstack11l11l1l1l1_opy_, self.config.get(bstack1l1l11_opy_ (u"࠭ࡢࡶ࡫࡯ࡨࡓࡧ࡭ࡦࠩ᭗")), os.environ.get(bstack1l1l11_opy_ (u"ࠧࡃࡔࡒ࡛ࡘࡋࡒࡔࡖࡄࡇࡐࡥࡂࡖࡋࡏࡈࡤࡘࡕࡏࡡࡌࡈࡊࡔࡔࡊࡈࡌࡉࡗ࠭᭘")), self.config.get(bstack1l1l11_opy_ (u"ࠨࡲࡵࡳ࡯࡫ࡣࡵࡐࡤࡱࡪ࠭᭙"))))
            if response.get(bstack1l1l11_opy_ (u"ࠤࡶࡸࡦࡺࡵࡴࠤ᭚")) == 200:
                failed_count = response.get(bstack1l1l11_opy_ (u"ࠥࡪࡦ࡯࡬ࡦࡦࡗࡩࡸࡺࡳࡄࡱࡸࡲࡹࠨ᭛"), 0)
                self.logger.debug(bstack1l1l11_opy_ (u"ࠦࡕࡵ࡬࡭ࡧࡧࠤ࡫ࡧࡩ࡭ࡧࡧࠤࡹ࡫ࡳࡵࡵࠣࡧࡴࡻ࡮ࡵ࠼ࠣࡿࢂࠨ᭜").format(failed_count))
                if failed_count >= self.bstack11l11lllll1_opy_:
                    self.logger.info(bstack1l1l11_opy_ (u"࡚ࠧࡨࡳࡧࡶ࡬ࡴࡲࡤࠡࡥࡵࡳࡸࡹࡥࡥ࠼ࠣࡿࢂࠦ࠾࠾ࠢࡾࢁࠧ᭝").format(failed_count, self.bstack11l11lllll1_opy_))
                    self.bstack11l11ll1ll1_opy_(failed_count)
                    self.bstack11l11lll1ll_opy_ = True
            else:
                self.logger.error(bstack1l1l11_opy_ (u"ࠨࡆࡢ࡫࡯ࡩࡩࠦࡴࡰࠢࡳࡳࡱࡲࠠࡧࡣ࡬ࡰࡪࡪࠠࡵࡧࡶࡸࡸࡀࠠࡼࡿࠥ᭞").format(response))
        except Exception as e:
            self.logger.error(bstack1l1l11_opy_ (u"ࠢࡆࡺࡦࡩࡵࡺࡩࡰࡰࠣࡨࡺࡸࡩ࡯ࡩࠣࡴࡴࡲ࡬ࡪࡰࡪ࠾ࠥࢁࡽࠣ᭟").format(e))
    def bstack11l11ll1ll1_opy_(self, failed_count):
        with open(self.bstack11l11ll111l_opy_, bstack1l1l11_opy_ (u"ࠣࡹࠥ᭠")) as f:
            f.write(bstack1l1l11_opy_ (u"ࠤࡗ࡬ࡷ࡫ࡳࡩࡱ࡯ࡨࠥࡩࡲࡰࡵࡶࡩࡩࠦࡡࡵࠢࡾࢁࡡࡴࠢ᭡").format(datetime.now()))
            f.write(bstack1l1l11_opy_ (u"ࠥࡊࡦ࡯࡬ࡦࡦࠣࡸࡪࡹࡴࡴࠢࡦࡳࡺࡴࡴ࠻ࠢࡾࢁࡡࡴࠢ᭢").format(failed_count))
        self.logger.debug(bstack1l1l11_opy_ (u"ࠦࡆࡨ࡯ࡳࡶࠣࡆࡺ࡯࡬ࡥࠢࡩ࡭ࡱ࡫ࠠࡤࡴࡨࡥࡹ࡫ࡤ࠻ࠢࡾࢁࠧ᭣").format(self.bstack11l11ll111l_opy_))
    def bstack11l11ll1l11_opy_(self):
        def bstack11l11l1lll1_opy_():
            while not self.bstack11l11lll1ll_opy_:
                time.sleep(bstack11l11lll111_opy_)
                self.bstack11l11ll1lll_opy_()
                self.bstack11l11llllll_opy_()
        bstack11l11l1llll_opy_ = threading.Thread(target=bstack11l11l1lll1_opy_, daemon=True)
        bstack11l11l1llll_opy_.start()