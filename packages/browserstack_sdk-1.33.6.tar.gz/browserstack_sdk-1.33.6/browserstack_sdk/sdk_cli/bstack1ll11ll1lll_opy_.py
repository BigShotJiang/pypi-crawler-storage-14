# coding: UTF-8
import sys
bstack1l11111_opy_ = sys.version_info [0] == 2
bstack11l11ll_opy_ = 2048
bstack111ll1l_opy_ = 7
def bstack1l1l11_opy_ (bstack11l1l_opy_):
    global bstack1l11_opy_
    bstack11l1111_opy_ = ord (bstack11l1l_opy_ [-1])
    bstack1l1ll1l_opy_ = bstack11l1l_opy_ [:-1]
    bstack11l11_opy_ = bstack11l1111_opy_ % len (bstack1l1ll1l_opy_)
    bstack1l1ll11_opy_ = bstack1l1ll1l_opy_ [:bstack11l11_opy_] + bstack1l1ll1l_opy_ [bstack11l11_opy_:]
    if bstack1l11111_opy_:
        bstack11lll1l_opy_ = unicode () .join ([unichr (ord (char) - bstack11l11ll_opy_ - (bstack11l111_opy_ + bstack11l1111_opy_) % bstack111ll1l_opy_) for bstack11l111_opy_, char in enumerate (bstack1l1ll11_opy_)])
    else:
        bstack11lll1l_opy_ = str () .join ([chr (ord (char) - bstack11l11ll_opy_ - (bstack11l111_opy_ + bstack11l1111_opy_) % bstack111ll1l_opy_) for bstack11l111_opy_, char in enumerate (bstack1l1ll11_opy_)])
    return eval (bstack11lll1l_opy_)
import os
from datetime import datetime, timezone
from uuid import uuid4
from typing import Dict, List, Any, Tuple
from browserstack_sdk.sdk_cli.bstack1llll1l111l_opy_ import bstack1llll11l111_opy_
from browserstack_sdk.sdk_cli.utils.bstack1l1l11ll11_opy_ import bstack11llllllll1_opy_
from browserstack_sdk.sdk_cli.test_framework import (
    TestFramework,
    bstack1llll111lll_opy_,
    bstack1lllll111l1_opy_,
    bstack1llll1ll111_opy_,
    bstack1lllll1ll1l_opy_,
    bstack1lllll111ll_opy_,
)
from pathlib import Path
import grpc
from browserstack_sdk import sdk_pb2 as structs
from datetime import datetime, timezone
from typing import List, Dict, Any
import traceback
from bstack_utils.helper import bstack1l11llll111_opy_
from bstack_utils.bstack1111ll1l1_opy_ import bstack1ll111l1ll1_opy_
from bstack_utils.constants import EVENTS
from browserstack_sdk.sdk_cli.bstack1llll11l1l1_opy_ import bstack1lllll1lll1_opy_
from browserstack_sdk.sdk_cli.utils.bstack1ll1ll11l11_opy_ import bstack1ll1llllll1_opy_
from bstack_utils.bstack111lll1111_opy_ import bstack1lllll11l_opy_
bstack1l1l11111ll_opy_ = bstack1l11llll111_opy_()
bstack1l11111111l_opy_ = 1.0
bstack1l1l11lll1l_opy_ = bstack1l1l11_opy_ (u"ࠨࡕࡱ࡮ࡲࡥࡩ࡫ࡤࡂࡶࡷࡥࡨ࡮࡭ࡦࡰࡷࡷ࠲ࠨᕯ")
bstack11lll1l11l1_opy_ = bstack1l1l11_opy_ (u"ࠢࡕࡧࡶࡸࡑ࡫ࡶࡦ࡮ࠥᕰ")
bstack11lll1l11ll_opy_ = bstack1l1l11_opy_ (u"ࠣࡄࡸ࡭ࡱࡪࡌࡦࡸࡨࡰࠧᕱ")
bstack11lll1l1l11_opy_ = bstack1l1l11_opy_ (u"ࠤࡋࡳࡴࡱࡌࡦࡸࡨࡰࠧᕲ")
bstack11lll1l111l_opy_ = bstack1l1l11_opy_ (u"ࠥࡆࡺ࡯࡬ࡥࡎࡨࡺࡪࡲࡈࡰࡱ࡮ࡉࡻ࡫࡮ࡵࠤᕳ")
_1l11lll1111_opy_ = set()
class bstack1ll1l1l11l1_opy_(TestFramework):
    bstack11llll1lll1_opy_ = bstack1l1l11_opy_ (u"ࠦࡹ࡫ࡳࡵࡡࡩ࡭ࡽࡺࡵࡳࡧࡶࠦᕴ")
    bstack11lllll1lll_opy_ = bstack1l1l11_opy_ (u"ࠧࡺࡥࡴࡶࡢ࡬ࡴࡵ࡫ࡴࡡࡶࡸࡦࡸࡴࡦࡦࠥᕵ")
    bstack1l11111ll11_opy_ = bstack1l1l11_opy_ (u"ࠨࡴࡦࡵࡷࡣ࡭ࡵ࡯࡬ࡵࡢࡪ࡮ࡴࡩࡴࡪࡨࡨࠧᕶ")
    bstack11lll1lllll_opy_ = bstack1l1l11_opy_ (u"ࠢࡵࡧࡶࡸࡤ࡮࡯ࡰ࡭ࡢࡰࡦࡹࡴࡠࡵࡷࡥࡷࡺࡥࡥࠤᕷ")
    bstack11lll1l1lll_opy_ = bstack1l1l11_opy_ (u"ࠣࡶࡨࡷࡹࡥࡨࡰࡱ࡮ࡣࡱࡧࡳࡵࡡࡩ࡭ࡳ࡯ࡳࡩࡧࡧࠦᕸ")
    bstack1l11111ll1l_opy_: bool
    bstack1llll11l1l1_opy_: bstack1lllll1lll1_opy_  = None
    bstack1ll1ll1l111_opy_ = None
    bstack11lllll1ll1_opy_ = [
        bstack1llll111lll_opy_.BEFORE_ALL,
        bstack1llll111lll_opy_.AFTER_ALL,
        bstack1llll111lll_opy_.BEFORE_EACH,
        bstack1llll111lll_opy_.AFTER_EACH,
    ]
    def __init__(
        self,
        bstack1lll1lll111_opy_: Dict[str, str],
        bstack1lllll1111l_opy_: List[str]=[bstack1l1l11_opy_ (u"ࠤࡳࡽࡹ࡫ࡳࡵࠤᕹ")],
        bstack1llll11l1l1_opy_: bstack1lllll1lll1_opy_=None,
        bstack1ll1ll1l111_opy_=None
    ):
        super().__init__(bstack1lllll1111l_opy_, bstack1lll1lll111_opy_, bstack1llll11l1l1_opy_)
        self.bstack1l11111ll1l_opy_ = any(bstack1l1l11_opy_ (u"ࠥࡴࡾࡺࡥࡴࡶࠥᕺ") in item.lower() for item in bstack1lllll1111l_opy_)
        self.bstack1ll1ll1l111_opy_ = bstack1ll1ll1l111_opy_
    def track_event(
        self,
        context: bstack1lllll1ll1l_opy_,
        test_framework_state: bstack1llll111lll_opy_,
        test_hook_state: bstack1llll1ll111_opy_,
        *args,
        **kwargs,
    ):
        super().track_event(self, context, test_framework_state, test_hook_state, *args, **kwargs)
        if test_framework_state == bstack1llll111lll_opy_.TEST or test_framework_state in bstack1ll1l1l11l1_opy_.bstack11lllll1ll1_opy_:
            bstack11llllllll1_opy_(test_framework_state, test_hook_state)
        if test_framework_state == bstack1llll111lll_opy_.NONE:
            self.logger.warning(bstack1l1l11_opy_ (u"ࠦ࡮࡭࡮ࡰࡴࡨࡨࠥࡩࡡ࡭࡮ࡥࡥࡨࡱࠠࡵࡧࡶࡸࡤ࡬ࡲࡢ࡯ࡨࡻࡴࡸ࡫ࡠࡵࡷࡥࡹ࡫࠽ࡼࡶࡨࡷࡹࡥࡦࡳࡣࡰࡩࡼࡵࡲ࡬ࡡࡶࡸࡦࡺࡥࡾࠢࡷࡩࡸࡺ࡟ࡩࡱࡲ࡯ࡤࡹࡴࡢࡶࡨࡁࠧᕻ") + str(test_hook_state) + bstack1l1l11_opy_ (u"ࠧࠨᕼ"))
            return
        if not self.bstack1l11111ll1l_opy_:
            self.logger.warning(bstack1l1l11_opy_ (u"ࠨࡴࡳࡣࡦ࡯ࡤ࡫ࡶࡦࡰࡷ࠾ࠥࡻ࡮ࡴࡷࡳࡴࡴࡸࡴࡦࡦࠣࡪࡷࡧ࡭ࡦࡹࡲࡶࡰࡃࠢᕽ") + str(str(self.bstack1lllll1111l_opy_)) + bstack1l1l11_opy_ (u"ࠢࠣᕾ"))
            return
        if not isinstance(args, tuple) or len(args) == 0:
            self.logger.warning(bstack1l1l11_opy_ (u"ࠣࡶࡵࡥࡨࡱ࡟ࡦࡸࡨࡲࡹࡀࠠࡶࡰࡨࡼࡵ࡫ࡣࡵࡧࡧࠤࡦࡸࡧࡴ࠿ࡾࡥࡷ࡭ࡳࡾࠢ࡮ࡻࡦࡸࡧࡴ࠿ࠥᕿ") + str(kwargs) + bstack1l1l11_opy_ (u"ࠤࠥᖀ"))
            return
        instance = self.__11llll11l11_opy_(context, test_framework_state, test_hook_state, *args, **kwargs)
        if not instance:
            self.logger.debug(bstack1l1l11_opy_ (u"ࠥࡸࡷࡧࡣ࡬ࡡࡨࡺࡪࡴࡴ࠻ࠢࡸࡲ࡭ࡧ࡮ࡥ࡮ࡨࡨࠥ࡫ࡶࡦࡰࡷࡁࢀࡺࡥࡴࡶࡢࡪࡷࡧ࡭ࡦࡹࡲࡶࡰࡥࡳࡵࡣࡷࡩࢂ࠴ࡻࡵࡧࡶࡸࡤ࡮࡯ࡰ࡭ࡢࡷࡹࡧࡴࡦࡿࠣࡥࡷ࡭ࡳ࠾ࠤᖁ") + str(args) + bstack1l1l11_opy_ (u"ࠦࠧᖂ"))
            return
        try:
            if instance!= None and test_framework_state in bstack1ll1l1l11l1_opy_.bstack11lllll1ll1_opy_ and test_hook_state == bstack1llll1ll111_opy_.PRE:
                bstack1l1ll1ll111_opy_ = bstack1ll111l1ll1_opy_.bstack1l1ll1ll1ll_opy_(EVENTS.bstack1l11111lll_opy_.value)
                name = str(EVENTS.bstack1l11111lll_opy_.name)+bstack1l1l11_opy_ (u"ࠧࡀࠢᖃ")+str(test_framework_state.name)
                TestFramework.bstack1llll111ll1_opy_(instance, name, bstack1l1ll1ll111_opy_)
        except Exception as e:
            self.logger.debug(bstack1l1l11_opy_ (u"ࠨࡅࡹࡥࡨࡴࡹ࡯࡯࡯ࠢ࡬ࡲࠥ࡮࡯ࡰ࡭ࠣࡩࡷࡸ࡯ࡳࠢࡳࡶࡪࡀࠠࡼࡿࠥᖄ").format(e))
        try:
            if not TestFramework.bstack1lllll1l1ll_opy_(instance, TestFramework.bstack1lll1ll1lll_opy_) and test_hook_state == bstack1llll1ll111_opy_.PRE:
                test = bstack1ll1l1l11l1_opy_.__1l111111ll1_opy_(args[0])
                if test:
                    instance.data.update(test)
                    self.logger.debug(bstack1l1l11_opy_ (u"ࠢ࡭ࡱࡤࡨࡪࡪࠠࡪࡰࡶࡸࡦࡴࡣࡦ࠿ࡾ࡭ࡳࡹࡴࡢࡰࡦࡩ࠳ࡸࡥࡧࠪࠬࢁࠥ࡫ࡶࡦࡰࡷࡁࢀࡺࡥࡴࡶࡢࡪࡷࡧ࡭ࡦࡹࡲࡶࡰࡥࡳࡵࡣࡷࡩࢂ࠴ࠢᖅ") + str(test_hook_state) + bstack1l1l11_opy_ (u"ࠣࠤᖆ"))
            if test_framework_state == bstack1llll111lll_opy_.TEST:
                if test_hook_state == bstack1llll1ll111_opy_.PRE and not TestFramework.bstack1lllll1l1ll_opy_(instance, TestFramework.bstack1llll1l1111_opy_):
                    TestFramework.bstack1lllll1l11l_opy_(instance, TestFramework.bstack1llll1l1111_opy_, datetime.now(tz=timezone.utc))
                    self.logger.debug(bstack1l1l11_opy_ (u"ࠤࡶࡩࡹࠦࡴࡦࡵࡷ࠱ࡸࡺࡡࡳࡶࠣࡪࡴࡸࠠࡪࡰࡶࡸࡦࡴࡣࡦ࠿ࡾ࡭ࡳࡹࡴࡢࡰࡦࡩ࠳ࡸࡥࡧࠪࠬࢁࠥ࡫ࡶࡦࡰࡷࡁࢀࡺࡥࡴࡶࡢࡪࡷࡧ࡭ࡦࡹࡲࡶࡰࡥࡳࡵࡣࡷࡩࢂ࠴ࠢᖇ") + str(test_hook_state) + bstack1l1l11_opy_ (u"ࠥࠦᖈ"))
                elif test_hook_state == bstack1llll1ll111_opy_.POST and not TestFramework.bstack1lllll1l1ll_opy_(instance, TestFramework.bstack1llll1llll1_opy_):
                    TestFramework.bstack1lllll1l11l_opy_(instance, TestFramework.bstack1llll1llll1_opy_, datetime.now(tz=timezone.utc))
                    self.logger.debug(bstack1l1l11_opy_ (u"ࠦࡸ࡫ࡴࠡࡶࡨࡷࡹ࠳ࡥ࡯ࡦࠣࡪࡴࡸࠠࡪࡰࡶࡸࡦࡴࡣࡦ࠿ࡾ࡭ࡳࡹࡴࡢࡰࡦࡩ࠳ࡸࡥࡧࠪࠬࢁࠥ࡫ࡶࡦࡰࡷࡁࢀࡺࡥࡴࡶࡢࡪࡷࡧ࡭ࡦࡹࡲࡶࡰࡥࡳࡵࡣࡷࡩࢂ࠴ࠢᖉ") + str(test_hook_state) + bstack1l1l11_opy_ (u"ࠧࠨᖊ"))
            elif test_framework_state == bstack1llll111lll_opy_.LOG and test_hook_state == bstack1llll1ll111_opy_.POST:
                bstack1ll1l1l11l1_opy_.__11llll11ll1_opy_(instance, *args)
            elif test_framework_state == bstack1llll111lll_opy_.LOG_REPORT and test_hook_state == bstack1llll1ll111_opy_.POST:
                self.__11lllllll1l_opy_(instance, *args)
                self.__11lll1ll11l_opy_(instance)
            elif test_framework_state in bstack1ll1l1l11l1_opy_.bstack11lllll1ll1_opy_:
                self.__1l11111l11l_opy_(instance, test_framework_state, test_hook_state, *args)
            self.logger.debug(bstack1l1l11_opy_ (u"ࠨࡴࡳࡣࡦ࡯ࡤ࡫ࡶࡦࡰࡷ࠾ࠥ࡮ࡡ࡯ࡦ࡯ࡩࡩࠦࡥࡷࡧࡱࡸࡂࢁࡴࡦࡵࡷࡣ࡫ࡸࡡ࡮ࡧࡺࡳࡷࡱ࡟ࡴࡶࡤࡸࡪࢃ࠮ࡼࡶࡨࡷࡹࡥࡨࡰࡱ࡮ࡣࡸࡺࡡࡵࡧࢀࠤ࡮ࡴࡳࡵࡣࡱࡧࡪࡃࠢᖋ") + str(instance.ref()) + bstack1l1l11_opy_ (u"ࠢࠣᖌ"))
        except Exception as e:
            self.logger.error(e)
            traceback.print_exc()
        self.bstack1lll1llll1l_opy_(instance, (test_framework_state, test_hook_state), *args, **kwargs)
        try:
            if instance!= None and test_framework_state in bstack1ll1l1l11l1_opy_.bstack11lllll1ll1_opy_ and test_hook_state == bstack1llll1ll111_opy_.POST:
                name = str(EVENTS.bstack1l11111lll_opy_.name)+bstack1l1l11_opy_ (u"ࠣ࠼ࠥᖍ")+str(test_framework_state.name)
                bstack1l1ll1ll111_opy_ = TestFramework.bstack1llll1l11l1_opy_(instance, name)
                bstack1ll111l1ll1_opy_.end(EVENTS.bstack1l11111lll_opy_.value, bstack1l1ll1ll111_opy_+bstack1l1l11_opy_ (u"ࠤ࠽ࡷࡹࡧࡲࡵࠤᖎ"), bstack1l1ll1ll111_opy_+bstack1l1l11_opy_ (u"ࠥ࠾ࡪࡴࡤࠣᖏ"), True, None, test_framework_state.name)
        except Exception as e:
            self.logger.debug(bstack1l1l11_opy_ (u"ࠦࡊࡾࡣࡦࡲࡷ࡭ࡴࡴࠠࡪࡰࠣ࡬ࡴࡵ࡫ࠡࡧࡵࡶࡴࡸ࠺ࠡࡽࢀࠦᖐ").format(e))
    def bstack1llll11l11l_opy_(self):
        return self.bstack1l11111ll1l_opy_
    def __11llll1ll1l_opy_(self, *args):
        if len(args) > 2 and callable(getattr(args[2], bstack1l1l11_opy_ (u"ࠧ࡭ࡥࡵࡡࡵࡩࡸࡻ࡬ࡵࠤᖑ"), None)):
            rep = args[2].get_result()
            if rep:
                return TestFramework.bstack1lllll1llll_opy_(rep, [bstack1l1l11_opy_ (u"ࠨࡷࡩࡧࡱࠦᖒ"), bstack1l1l11_opy_ (u"ࠢࡰࡷࡷࡧࡴࡳࡥࠣᖓ"), bstack1l1l11_opy_ (u"ࠣࡲࡤࡷࡸ࡫ࡤࠣᖔ"), bstack1l1l11_opy_ (u"ࠤࡩࡥ࡮ࡲࡥࡥࠤᖕ"), bstack1l1l11_opy_ (u"ࠥࡷࡰ࡯ࡰࡱࡧࡧࠦᖖ"), bstack1l1l11_opy_ (u"ࠦࡱࡵ࡮ࡨࡴࡨࡴࡷࡺࡥࡹࡶࠥᖗ")])
        return None
    def __11lllllll1l_opy_(self, instance: bstack1lllll111l1_opy_, *args):
        result = self.__11llll1ll1l_opy_(*args)
        if not result:
            return
        failure = None
        bstack1llllll1ll1_opy_ = None
        if result.get(bstack1l1l11_opy_ (u"ࠧࡵࡵࡵࡥࡲࡱࡪࠨᖘ"), None) == bstack1l1l11_opy_ (u"ࠨࡦࡢ࡫࡯ࡩࡩࠨᖙ") and len(args) > 1 and getattr(args[1], bstack1l1l11_opy_ (u"ࠢࡦࡺࡦ࡭ࡳ࡬࡯ࠣᖚ"), None) is not None:
            failure = [{bstack1l1l11_opy_ (u"ࠨࡤࡤࡧࡰࡺࡲࡢࡥࡨࠫᖛ"): [args[1].excinfo.exconly(), result.get(bstack1l1l11_opy_ (u"ࠤ࡯ࡳࡳ࡭ࡲࡦࡲࡵࡸࡪࡾࡴࠣᖜ"), None)]}]
            bstack1llllll1ll1_opy_ = bstack1l1l11_opy_ (u"ࠥࡅࡸࡹࡥࡳࡶ࡬ࡳࡳࡋࡲࡳࡱࡵࠦᖝ") if bstack1l1l11_opy_ (u"ࠦࡆࡹࡳࡦࡴࡷ࡭ࡴࡴࠢᖞ") in getattr(args[1].excinfo, bstack1l1l11_opy_ (u"ࠧࡺࡹࡱࡧࡱࡥࡲ࡫ࠢᖟ"), bstack1l1l11_opy_ (u"ࠨࠢᖠ")) else bstack1l1l11_opy_ (u"ࠢࡖࡰ࡫ࡥࡳࡪ࡬ࡦࡦࡈࡶࡷࡵࡲࠣᖡ")
        bstack11llll111l1_opy_ = result.get(bstack1l1l11_opy_ (u"ࠣࡱࡸࡸࡨࡵ࡭ࡦࠤᖢ"), TestFramework.bstack1lllll11lll_opy_)
        if bstack11llll111l1_opy_ != TestFramework.bstack1lllll11lll_opy_:
            TestFramework.bstack1lllll1l11l_opy_(instance, TestFramework.bstack1llll11lll1_opy_, datetime.now(tz=timezone.utc))
        TestFramework.bstack1lll1l1ll1l_opy_(instance, {
            TestFramework.bstack1lll1lll1ll_opy_: failure,
            TestFramework.bstack1llllll11l1_opy_: bstack1llllll1ll1_opy_,
            TestFramework.bstack1llllll111l_opy_: bstack11llll111l1_opy_,
        })
    def __11llll11l11_opy_(
        self,
        context: bstack1lllll1ll1l_opy_,
        test_framework_state: bstack1llll111lll_opy_,
        test_hook_state: bstack1llll1ll111_opy_,
        *args,
        **kwargs,
    ):
        instance = None
        if test_framework_state == bstack1llll111lll_opy_.SETUP_FIXTURE:
            instance = self.__11llll1111l_opy_(context, test_framework_state, test_hook_state, *args, **kwargs)
        else:
            target = None # bstack11lll1ll111_opy_ bstack11lllll1l1l_opy_ this to be bstack1l1l11_opy_ (u"ࠤࡱࡳࡩ࡫ࡩࡥࠤᖣ")
            if test_framework_state == bstack1llll111lll_opy_.INIT_TEST:
                target = args[0] if isinstance(args[0], str) else None
                if target:
                    self.__11llllll111_opy_(context, test_framework_state, target, *args)
            elif test_framework_state == bstack1llll111lll_opy_.LOG:
                nodeid = getattr(getattr(args[0], bstack1l1l11_opy_ (u"ࠥࡲࡴࡪࡥࠣᖤ"), None), bstack1l1l11_opy_ (u"ࠦࡳࡵࡤࡦ࡫ࡧࠦᖥ"), None) if args else None
                if isinstance(nodeid, str):
                    target = nodeid
            elif getattr(args[0], bstack1l1l11_opy_ (u"ࠧࡴ࡯ࡥࡧ࡬ࡨࠧᖦ"), None):
                target = args[0].nodeid
            instance = TestFramework.bstack1llll1lll11_opy_(target) if target else None
        return instance
    def __1l11111l11l_opy_(
        self,
        instance: bstack1lllll111l1_opy_,
        test_framework_state: bstack1llll111lll_opy_,
        test_hook_state: bstack1llll1ll111_opy_,
        *args,
    ):
        key = test_framework_state.name
        bstack11lllllllll_opy_ = TestFramework.bstack1lll1llllll_opy_(instance, bstack1ll1l1l11l1_opy_.bstack11lllll1lll_opy_, {})
        if not key in bstack11lllllllll_opy_:
            bstack11lllllllll_opy_[key] = []
        bstack1l111111111_opy_ = TestFramework.bstack1lll1llllll_opy_(instance, bstack1ll1l1l11l1_opy_.bstack1l11111ll11_opy_, {})
        if not key in bstack1l111111111_opy_:
            bstack1l111111111_opy_[key] = []
        bstack1l111111l1l_opy_ = {
            bstack1ll1l1l11l1_opy_.bstack11lllll1lll_opy_: bstack11lllllllll_opy_,
            bstack1ll1l1l11l1_opy_.bstack1l11111ll11_opy_: bstack1l111111111_opy_,
        }
        if test_hook_state == bstack1llll1ll111_opy_.PRE:
            hook = {
                bstack1l1l11_opy_ (u"ࠨ࡫ࡦࡻࠥᖧ"): key,
                TestFramework.bstack1lllll11111_opy_: uuid4().__str__(),
                TestFramework.bstack1llll11ll11_opy_: TestFramework.bstack1llll1ll1l1_opy_,
                TestFramework.bstack1llll111l11_opy_: datetime.now(tz=timezone.utc),
                TestFramework.bstack1lllll1ll11_opy_: [],
                TestFramework.bstack1llll1111l1_opy_: args[1] if len(args) > 1 else bstack1l1l11_opy_ (u"ࠧࠨᖨ"),
                TestFramework.bstack1lll1lll11l_opy_: bstack1ll1llllll1_opy_.bstack11llll11l1l_opy_()
            }
            bstack11lllllllll_opy_[key].append(hook)
            bstack1l111111l1l_opy_[bstack1ll1l1l11l1_opy_.bstack11lll1lllll_opy_] = key
        elif test_hook_state == bstack1llll1ll111_opy_.POST:
            bstack11lll1lll11_opy_ = bstack11lllllllll_opy_.get(key, [])
            hook = bstack11lll1lll11_opy_.pop() if bstack11lll1lll11_opy_ else None
            if hook:
                result = self.__11llll1ll1l_opy_(*args)
                if result:
                    bstack11llll1l1l1_opy_ = result.get(bstack1l1l11_opy_ (u"ࠣࡱࡸࡸࡨࡵ࡭ࡦࠤᖩ"), TestFramework.bstack1llll1ll1l1_opy_)
                    if bstack11llll1l1l1_opy_ != TestFramework.bstack1llll1ll1l1_opy_:
                        hook[TestFramework.bstack1llll11ll11_opy_] = bstack11llll1l1l1_opy_
                hook[TestFramework.bstack1llll111111_opy_] = datetime.now(tz=timezone.utc)
                hook[TestFramework.bstack1lll1lll11l_opy_]= bstack1ll1llllll1_opy_.bstack11llll11l1l_opy_()
                self.bstack11llll1llll_opy_(hook)
                logs = hook.get(TestFramework.bstack1lll1ll11ll_opy_, [])
                if logs: self.bstack1l11lllllll_opy_(instance, logs)
                bstack1l111111111_opy_[key].append(hook)
                bstack1l111111l1l_opy_[bstack1ll1l1l11l1_opy_.bstack11lll1l1lll_opy_] = key
        TestFramework.bstack1lll1l1ll1l_opy_(instance, bstack1l111111l1l_opy_)
        self.logger.debug(bstack1l1l11_opy_ (u"ࠤࡷࡶࡦࡩ࡫ࡠࡪࡲࡳࡰࡥࡥࡷࡧࡱࡸ࠿ࠦࡴࡦࡵࡷࡣ࡭ࡵ࡯࡬ࡡࡶࡸࡦࡺࡥ࠾ࡽ࡮ࡩࡾࢃ࠮ࡼࡶࡨࡷࡹࡥࡨࡰࡱ࡮ࡣࡸࡺࡡࡵࡧࢀࠤ࡭ࡵ࡯࡬ࡵࡢࡷࡹࡧࡲࡵࡧࡧࡁࢀ࡮࡯ࡰ࡭ࡶࡣࡸࡺࡡࡳࡶࡨࡨࢂࠦࡨࡰࡱ࡮ࡷࡤ࡬ࡩ࡯࡫ࡶ࡬ࡪࡪ࠽ࠣᖪ") + str(bstack1l111111111_opy_) + bstack1l1l11_opy_ (u"ࠥࠦᖫ"))
    def __11llll1111l_opy_(
        self,
        context: bstack1lllll1ll1l_opy_,
        test_framework_state: bstack1llll111lll_opy_,
        test_hook_state: bstack1llll1ll111_opy_,
        *args,
        **kwargs,
    ):
        fixturedef = TestFramework.bstack1lllll1llll_opy_(args[0], [bstack1l1l11_opy_ (u"ࠦࡸࡩ࡯ࡱࡧࠥᖬ"), bstack1l1l11_opy_ (u"ࠧࡧࡲࡨࡰࡤࡱࡪࠨᖭ"), bstack1l1l11_opy_ (u"ࠨࡰࡢࡴࡤࡱࡸࠨᖮ"), bstack1l1l11_opy_ (u"ࠢࡪࡦࡶࠦᖯ"), bstack1l1l11_opy_ (u"ࠣࡷࡱ࡭ࡹࡺࡥࡴࡶࠥᖰ"), bstack1l1l11_opy_ (u"ࠤࡥࡥࡸ࡫ࡩࡥࠤᖱ")]) if len(args) > 0 else {}
        request = args[1] if len(args) > 1 else None
        scope = request.scope if hasattr(request, bstack1l1l11_opy_ (u"ࠥࡷࡨࡵࡰࡦࠤᖲ")) else fixturedef.get(bstack1l1l11_opy_ (u"ࠦࡸࡩ࡯ࡱࡧࠥᖳ"), None)
        fixturename = request.fixturename if hasattr(request, bstack1l1l11_opy_ (u"ࠧ࡬ࡩࡹࡶࡸࡶࡪࡴࡡ࡮ࡧࠥᖴ")) else None
        node = request.node if hasattr(request, bstack1l1l11_opy_ (u"ࠨ࡮ࡰࡦࡨࠦᖵ")) else None
        target = request.node.nodeid if hasattr(node, bstack1l1l11_opy_ (u"ࠢ࡯ࡱࡧࡩ࡮ࡪࠢᖶ")) else None
        baseid = fixturedef.get(bstack1l1l11_opy_ (u"ࠣࡤࡤࡷࡪ࡯ࡤࠣᖷ"), None) or bstack1l1l11_opy_ (u"ࠤࠥᖸ")
        if (not target or len(baseid) > 0) and hasattr(request, bstack1l1l11_opy_ (u"ࠥࡣࡵࡿࡦࡶࡰࡦ࡭ࡹ࡫࡭ࠣᖹ")):
            target = bstack1ll1l1l11l1_opy_.__1l111111l11_opy_(request._pyfuncitem.location) if hasattr(request._pyfuncitem, bstack1l1l11_opy_ (u"ࠦࡱࡵࡣࡢࡶ࡬ࡳࡳࠨᖺ")) else None
            if target and not TestFramework.bstack1llll1lll11_opy_(target):
                self.__11llllll111_opy_(context, test_framework_state, target, (target, request._pyfuncitem.location))
                node = request._pyfuncitem
                self.logger.debug(bstack1l1l11_opy_ (u"ࠧࡺࡲࡢࡥ࡮ࡣ࡫࡯ࡸࡵࡷࡵࡩࡤ࡫ࡶࡦࡰࡷ࠾ࠥ࡬ࡡ࡭࡮ࡥࡥࡨࡱࠠࡵࡣࡵ࡫ࡪࡺ࠽ࡼࡶࡤࡶ࡬࡫ࡴࡾࠢࡩ࡭ࡽࡺࡵࡳࡧࡱࡥࡲ࡫࠽ࡼࡨ࡬ࡼࡹࡻࡲࡦࡰࡤࡱࡪࢃࠠ࡯ࡱࡧࡩࡂࢁ࡮ࡰࡦࡨࢁࠥ࡫ࡶࡦࡰࡷࡁࢀࡺࡥࡴࡶࡢࡪࡷࡧ࡭ࡦࡹࡲࡶࡰࡥࡳࡵࡣࡷࡩࢂ࠴ࠢᖻ") + str(test_hook_state) + bstack1l1l11_opy_ (u"ࠨࠢᖼ"))
        if not fixturedef or not scope or not target:
            self.logger.warning(bstack1l1l11_opy_ (u"ࠢࡵࡴࡤࡧࡰࡥࡦࡪࡺࡷࡹࡷ࡫࡟ࡦࡸࡨࡲࡹࡀࠠࡶࡰ࡫ࡥࡳࡪ࡬ࡦࡦࠣࡩࡻ࡫࡮ࡵ࠿ࡾࡸࡪࡹࡴࡠࡨࡵࡥࡲ࡫ࡷࡰࡴ࡮ࡣࡸࡺࡡࡵࡧࢀ࠲ࢀࡺࡥࡴࡶࡢ࡬ࡴࡵ࡫ࡠࡵࡷࡥࡹ࡫ࡽࠡࡨ࡬ࡼࡹࡻࡲࡦࡦࡨࡪࡂࢁࡦࡪࡺࡷࡹࡷ࡫ࡤࡦࡨࢀࠤࡸࡩ࡯ࡱࡧࡀࡿࡸࡩ࡯ࡱࡧࢀࠤࡹࡧࡲࡨࡧࡷࡁࠧᖽ") + str(target) + bstack1l1l11_opy_ (u"ࠣࠤᖾ"))
            return None
        instance = TestFramework.bstack1llll1lll11_opy_(target)
        if not instance:
            self.logger.warning(bstack1l1l11_opy_ (u"ࠤࡷࡶࡦࡩ࡫ࡠࡨ࡬ࡼࡹࡻࡲࡦࡡࡨࡺࡪࡴࡴ࠻ࠢࡸࡲ࡭ࡧ࡮ࡥ࡮ࡨࡨࠥ࡫ࡶࡦࡰࡷࡁࢀࡺࡥࡴࡶࡢࡪࡷࡧ࡭ࡦࡹࡲࡶࡰࡥࡳࡵࡣࡷࡩࢂ࠴ࡻࡵࡧࡶࡸࡤ࡮࡯ࡰ࡭ࡢࡷࡹࡧࡴࡦࡿࠣࡪ࡮ࡾࡴࡶࡴࡨࡲࡦࡳࡥ࠾ࡽࡩ࡭ࡽࡺࡵࡳࡧࡱࡥࡲ࡫ࡽࠡࡵࡦࡳࡵ࡫࠽ࡼࡵࡦࡳࡵ࡫ࡽࠡࡤࡤࡷࡪ࡯ࡤ࠾ࡽࡥࡥࡸ࡫ࡩࡥࡿࠣࡸࡦࡸࡧࡦࡶࡀࠦᖿ") + str(target) + bstack1l1l11_opy_ (u"ࠥࠦᗀ"))
            return None
        bstack11lll1l1ll1_opy_ = TestFramework.bstack1lll1llllll_opy_(instance, bstack1ll1l1l11l1_opy_.bstack11llll1lll1_opy_, {})
        if os.getenv(bstack1l1l11_opy_ (u"ࠦࡘࡊࡋࡠࡅࡏࡍࡤࡌࡌࡂࡉࡢࡊࡎ࡞ࡔࡖࡔࡈࡗࠧᗁ"), bstack1l1l11_opy_ (u"ࠧ࠷ࠢᗂ")) == bstack1l1l11_opy_ (u"ࠨ࠱ࠣᗃ"):
            bstack11llll1l1ll_opy_ = bstack1l1l11_opy_ (u"ࠢ࠻ࠤᗄ").join((scope, fixturename))
            bstack1l1111111l1_opy_ = datetime.now(tz=timezone.utc)
            bstack11lll1ll1ll_opy_ = {
                bstack1l1l11_opy_ (u"ࠣ࡭ࡨࡽࠧᗅ"): bstack11llll1l1ll_opy_,
                bstack1l1l11_opy_ (u"ࠤࡷࡥ࡬ࡹࠢᗆ"): bstack1ll1l1l11l1_opy_.__11llll1l11l_opy_(request.node),
                bstack1l1l11_opy_ (u"ࠥࡪ࡮ࡾࡴࡶࡴࡨࠦᗇ"): fixturedef,
                bstack1l1l11_opy_ (u"ࠦࡸࡩ࡯ࡱࡧࠥᗈ"): scope,
                bstack1l1l11_opy_ (u"ࠧࡺࡹࡱࡧࠥᗉ"): None,
            }
            try:
                if test_hook_state == bstack1llll1ll111_opy_.POST and callable(getattr(args[-1], bstack1l1l11_opy_ (u"ࠨࡧࡦࡶࡢࡶࡪࡹࡵ࡭ࡶࠥᗊ"), None)):
                    bstack11lll1ll1ll_opy_[bstack1l1l11_opy_ (u"ࠢࡵࡻࡳࡩࠧᗋ")] = TestFramework.bstack1llll1ll11l_opy_(args[-1].get_result())
            except Exception as e:
                pass
            if test_hook_state == bstack1llll1ll111_opy_.PRE:
                bstack11lll1ll1ll_opy_[bstack1l1l11_opy_ (u"ࠣࡷࡸ࡭ࡩࠨᗌ")] = uuid4().__str__()
                bstack11lll1ll1ll_opy_[bstack1ll1l1l11l1_opy_.bstack1llll111l11_opy_] = bstack1l1111111l1_opy_
            elif test_hook_state == bstack1llll1ll111_opy_.POST:
                bstack11lll1ll1ll_opy_[bstack1ll1l1l11l1_opy_.bstack1llll111111_opy_] = bstack1l1111111l1_opy_
            if bstack11llll1l1ll_opy_ in bstack11lll1l1ll1_opy_:
                bstack11lll1l1ll1_opy_[bstack11llll1l1ll_opy_].update(bstack11lll1ll1ll_opy_)
                self.logger.debug(bstack1l1l11_opy_ (u"ࠤࡸࡴࡩࡧࡴࡦࡦࠣࡪ࡮ࡾࡴࡶࡴࡨࡲࡦࡳࡥ࠾ࡽࡩ࡭ࡽࡺࡵࡳࡧࡱࡥࡲ࡫ࡽࠡࡵࡦࡳࡵ࡫࠽ࡼࡵࡦࡳࡵ࡫ࡽࠡࡨ࡬ࡼࡹࡻࡲࡦ࠿ࠥᗍ") + str(bstack11lll1l1ll1_opy_[bstack11llll1l1ll_opy_]) + bstack1l1l11_opy_ (u"ࠥࠦᗎ"))
            else:
                bstack11lll1l1ll1_opy_[bstack11llll1l1ll_opy_] = bstack11lll1ll1ll_opy_
                self.logger.debug(bstack1l1l11_opy_ (u"ࠦࡸࡧࡶࡦࡦࠣࡪ࡮ࡾࡴࡶࡴࡨࡲࡦࡳࡥ࠾ࡽࡩ࡭ࡽࡺࡵࡳࡧࡱࡥࡲ࡫ࡽࠡࡵࡦࡳࡵ࡫࠽ࡼࡵࡦࡳࡵ࡫ࡽࠡࡨ࡬ࡼࡹࡻࡲࡦ࠿ࡾࡸࡪࡹࡴࡠࡨ࡬ࡼࡹࡻࡲࡦࡿࠣࡸࡷࡧࡣ࡬ࡧࡧࡣ࡫࡯ࡸࡵࡷࡵࡩࡸࡃࠢᗏ") + str(len(bstack11lll1l1ll1_opy_)) + bstack1l1l11_opy_ (u"ࠧࠨᗐ"))
        TestFramework.bstack1lllll1l11l_opy_(instance, bstack1ll1l1l11l1_opy_.bstack11llll1lll1_opy_, bstack11lll1l1ll1_opy_)
        self.logger.debug(bstack1l1l11_opy_ (u"ࠨࡳࡢࡸࡨࡨࠥ࡬ࡩࡹࡶࡸࡶࡪࡹ࠽ࡼ࡮ࡨࡲ࠭ࡺࡲࡢࡥ࡮ࡩࡩࡥࡦࡪࡺࡷࡹࡷ࡫ࡳࠪࡿࠣ࡭ࡳࡹࡴࡢࡰࡦࡩࡂࠨᗑ") + str(instance.ref()) + bstack1l1l11_opy_ (u"ࠢࠣᗒ"))
        return instance
    def __11llllll111_opy_(
        self,
        context: bstack1lllll1ll1l_opy_,
        test_framework_state: bstack1llll111lll_opy_,
        target: Any,
        *args,
    ):
        ctx = bstack1llll11l111_opy_.create_context(target)
        ob = bstack1lllll111l1_opy_(ctx, self.bstack1lllll1111l_opy_, self.bstack1lll1lll111_opy_, test_framework_state)
        TestFramework.bstack1lll1l1ll1l_opy_(ob, {
            TestFramework.bstack1lll1ll111l_opy_: context.test_framework_name,
            TestFramework.bstack1lll1l1lll1_opy_: context.test_framework_version,
            TestFramework.bstack1lll1ll1l11_opy_: [],
            bstack1ll1l1l11l1_opy_.bstack11llll1lll1_opy_: {},
            bstack1ll1l1l11l1_opy_.bstack1l11111ll11_opy_: {},
            bstack1ll1l1l11l1_opy_.bstack11lllll1lll_opy_: {},
        })
        if len(args) > 1 and isinstance(args[1], tuple):
            TestFramework.bstack1lllll1l11l_opy_(ob, TestFramework.bstack1llll11llll_opy_, str(args[1][0]))
        if context.platform_index >= 0:
            TestFramework.bstack1lllll1l11l_opy_(ob, TestFramework.bstack1llll11ll1l_opy_, context.platform_index)
        TestFramework.bstack1llllll11ll_opy_[ctx.id] = ob
        self.logger.debug(bstack1l1l11_opy_ (u"ࠣࡵࡤࡺࡪࡪࠠࡪࡰࡶࡸࡦࡴࡣࡦࠢࡦࡸࡽ࠴ࡩࡥ࠿ࡾࡧࡹࡾ࠮ࡪࡦࢀࠤࡹࡧࡲࡨࡧࡷࡁࢀࡺࡡࡳࡩࡨࡸࢂࠦࡡࡳࡩࡶࡁࢀࡧࡲࡨࡵࢀࠤ࡮ࡴࡳࡵࡣࡱࡧࡪࡹ࠽ࠣᗓ") + str(TestFramework.bstack1llllll11ll_opy_.keys()) + bstack1l1l11_opy_ (u"ࠤࠥᗔ"))
        return ob
    def bstack1llllll1l11_opy_(self, instance: bstack1lllll111l1_opy_, bstack1llll1111ll_opy_: Tuple[bstack1llll111lll_opy_, bstack1llll1ll111_opy_]):
        bstack11llll111ll_opy_ = (
            bstack1ll1l1l11l1_opy_.bstack11lll1lllll_opy_
            if bstack1llll1111ll_opy_[1] == bstack1llll1ll111_opy_.PRE
            else bstack1ll1l1l11l1_opy_.bstack11lll1l1lll_opy_
        )
        hook = bstack1ll1l1l11l1_opy_.bstack11llll11lll_opy_(instance, bstack11llll111ll_opy_)
        entries = hook.get(TestFramework.bstack1lllll1ll11_opy_, []) if isinstance(hook, dict) else []
        entries.extend(TestFramework.bstack1lll1llllll_opy_(instance, TestFramework.bstack1lll1ll1l11_opy_, []))
        return entries
    def bstack1llllll1111_opy_(self, instance: bstack1lllll111l1_opy_, bstack1llll1111ll_opy_: Tuple[bstack1llll111lll_opy_, bstack1llll1ll111_opy_]):
        bstack11llll111ll_opy_ = (
            bstack1ll1l1l11l1_opy_.bstack11lll1lllll_opy_
            if bstack1llll1111ll_opy_[1] == bstack1llll1ll111_opy_.PRE
            else bstack1ll1l1l11l1_opy_.bstack11lll1l1lll_opy_
        )
        bstack1ll1l1l11l1_opy_.bstack11lllll1111_opy_(instance, bstack11llll111ll_opy_)
        TestFramework.bstack1lll1llllll_opy_(instance, TestFramework.bstack1lll1ll1l11_opy_, []).clear()
    def bstack11llll1llll_opy_(self, hook: Dict[str, Any]) -> None:
        bstack1l1l11_opy_ (u"ࠥࠦࠧࠐࠠࠡࠢࠣࠤࠥࠦࠠࡑࡴࡲࡧࡪࡹࡳࡦࡵࠣࡸ࡭࡫ࠠࡉࡱࡲ࡯ࡑ࡫ࡶࡦ࡮ࠣࡥࡹࡺࡡࡤࡪࡰࡩࡳࡺࡳࠡࡵ࡬ࡱ࡮ࡲࡡࡳࠢࡷࡳࠥࡺࡨࡦࠢࡍࡥࡻࡧࠠࡪ࡯ࡳࡰࡪࡳࡥ࡯ࡶࡤࡸ࡮ࡵ࡮࠯ࠌࠣࠤࠥࠦࠠࠡࠢࠣࡘ࡭࡯ࡳࠡ࡯ࡨࡸ࡭ࡵࡤ࠻ࠌࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥ࠳ࠠࡄࡪࡨࡧࡰࡹࠠࡵࡪࡨࠤࡍࡵ࡯࡬ࡎࡨࡺࡪࡲࠠࡥ࡫ࡵࡩࡨࡺ࡯ࡳࡻࠣ࡭ࡳࡹࡩࡥࡧࠣࢂ࠴࠴ࡢࡳࡱࡺࡷࡪࡸࡳࡵࡣࡦ࡯࠴࡛ࡰ࡭ࡱࡤࡨࡪࡪࡁࡵࡶࡤࡧ࡭ࡳࡥ࡯ࡶࡶ࠲ࠏࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡ࠯ࠣࡊࡴࡸࠠࡦࡣࡦ࡬ࠥ࡬ࡩ࡭ࡧࠣ࡭ࡳࠦࡨࡰࡱ࡮ࡣࡱ࡫ࡶࡦ࡮ࡢࡪ࡮ࡲࡥࡴ࠮ࠣࡶࡪࡶ࡬ࡢࡥࡨࡷࠥࠨࡔࡦࡵࡷࡐࡪࡼࡥ࡭ࠤࠣࡻ࡮ࡺࡨࠡࠤࡋࡳࡴࡱࡌࡦࡸࡨࡰࠧࠦࡩ࡯ࠢ࡬ࡸࡸࠦࡰࡢࡶ࡫࠲ࠏࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡ࠯ࠣࡍ࡫ࠦࡡࠡࡨ࡬ࡰࡪࠦࡩ࡯ࠢࡷ࡬ࡪࠦࡤࡪࡴࡨࡧࡹࡵࡲࡺࠢࡰࡥࡹࡩࡨࡦࡵࠣࡥࠥࡳ࡯ࡥ࡫ࡩ࡭ࡪࡪࠠࡩࡱࡲ࡯࠲ࡲࡥࡷࡧ࡯ࠤ࡫࡯࡬ࡦ࠮ࠣ࡭ࡹࠦࡣࡳࡧࡤࡸࡪࡹࠠࡢࠢࡏࡳ࡬ࡋ࡮ࡵࡴࡼࠤࡴࡨࡪࡦࡥࡷࠤࡼ࡯ࡴࡩࠢࡤࡸࡹࡧࡣࡩ࡯ࡨࡲࡹࠦࡤࡦࡶࡤ࡭ࡱࡹ࠮ࠋࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤ࠲ࠦࡓࡪ࡯࡬ࡰࡦࡸ࡬ࡺ࠮ࠣ࡭ࡹࠦࡰࡳࡱࡦࡩࡸࡹࡥࡴࠢࡅࡹ࡮ࡲࡤࡍࡧࡹࡩࡱࠦࡡࡵࡶࡤࡧ࡭ࡳࡥ࡯ࡶࡶࠤࡱࡵࡣࡢࡶࡨࡨࠥ࡯࡮ࠡࡊࡲࡳࡰࡒࡥࡷࡧ࡯࠳ࡇࡻࡩ࡭ࡦࡏࡩࡻ࡫࡬ࡉࡱࡲ࡯ࡊࡼࡥ࡯ࡶࠣࡦࡾࠦࡲࡦࡲ࡯ࡥࡨ࡯࡮ࡨࠢࠥࡆࡺ࡯࡬ࡥࡎࡨࡺࡪࡲࠢࠡࡹ࡬ࡸ࡭ࠦࠢࡉࡱࡲ࡯ࡑ࡫ࡶࡦ࡮࠲ࡆࡺ࡯࡬ࡥࡎࡨࡺࡪࡲࡈࡰࡱ࡮ࡉࡻ࡫࡮ࡵࠤ࠱ࠎࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠ࠮ࠢࡗ࡬ࡪࠦࡣࡳࡧࡤࡸࡪࡪࠠࡍࡱࡪࡉࡳࡺࡲࡺࠢࡲࡦ࡯࡫ࡣࡵࡵࠣࡥࡷ࡫ࠠࡢࡦࡧࡩࡩࠦࡴࡰࠢࡷ࡬ࡪࠦࡨࡰࡱ࡮ࠫࡸࠦࠢ࡭ࡱࡪࡷࠧࠦ࡬ࡪࡵࡷ࠲ࠏࠦࠠࠡࠢࠣࠤࠥࠦࡁࡳࡩࡶ࠾ࠏࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣ࡬ࡴࡵ࡫࠻ࠢࡗ࡬ࡪࠦࡥࡷࡧࡱࡸࠥࡪࡩࡤࡶ࡬ࡳࡳࡧࡲࡺࠢࡦࡳࡳࡺࡡࡪࡰ࡬ࡲ࡬ࠦࡥࡹ࡫ࡶࡸ࡮ࡴࡧࠡ࡮ࡲ࡫ࡸࠦࡡ࡯ࡦࠣ࡬ࡴࡵ࡫ࠡ࡫ࡱࡪࡴࡸ࡭ࡢࡶ࡬ࡳࡳ࠴ࠊࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥ࡮࡯ࡰ࡭ࡢࡰࡪࡼࡥ࡭ࡡࡩ࡭ࡱ࡫ࡳ࠻ࠢࡏ࡭ࡸࡺࠠࡰࡨࠣࡔࡦࡺࡨࠡࡱࡥ࡮ࡪࡩࡴࡴࠢࡩࡶࡴࡳࠠࡵࡪࡨࠤ࡙࡫ࡳࡵࡎࡨࡺࡪࡲࠠ࡮ࡱࡱ࡭ࡹࡵࡲࡪࡰࡪ࠲ࠏࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࡦࡺ࡯࡬ࡥࡡ࡯ࡩࡻ࡫࡬ࡠࡨ࡬ࡰࡪࡹ࠺ࠡࡎ࡬ࡷࡹࠦ࡯ࡧࠢࡓࡥࡹ࡮ࠠࡰࡤ࡭ࡩࡨࡺࡳࠡࡨࡵࡳࡲࠦࡴࡩࡧࠣࡆࡺ࡯࡬ࡥࡎࡨࡺࡪࡲࠠ࡮ࡱࡱ࡭ࡹࡵࡲࡪࡰࡪ࠲ࠏࠦࠠࠡࠢࠣࠤࠥࠦࠢࠣࠤᗕ")
        global _1l11lll1111_opy_
        platform_index = os.environ[bstack1l1l11_opy_ (u"ࠫࡇࡘࡏࡘࡕࡈࡖࡘ࡚ࡁࡄࡍࡢࡔࡑࡇࡔࡇࡑࡕࡑࡤࡏࡎࡅࡇ࡛ࠫᗖ")]
        bstack1l11lll1l1l_opy_ = os.path.join(bstack1l1l11111ll_opy_, (bstack1l1l11lll1l_opy_ + str(platform_index)), bstack11lll1l1l11_opy_)
        if not os.path.exists(bstack1l11lll1l1l_opy_) or not os.path.isdir(bstack1l11lll1l1l_opy_):
            self.logger.debug(bstack1l1l11_opy_ (u"ࠧࡊࡩࡳࡧࡦࡸࡴࡸࡹࠡࡦࡲࡩࡸࠦ࡮ࡰࡶࠣࡩࡽ࡯ࡳࡵࡵࠣࡸࡴࠦࡰࡳࡱࡦࡩࡸࡹࠠࡼࡿࠥᗗ").format(bstack1l11lll1l1l_opy_))
            return
        logs = hook.get(bstack1l1l11_opy_ (u"ࠨ࡬ࡰࡩࡶࠦᗘ"), [])
        with os.scandir(bstack1l11lll1l1l_opy_) as entries:
            for entry in entries:
                abs_path = os.path.abspath(entry.path)
                if abs_path in _1l11lll1111_opy_:
                    self.logger.info(bstack1l1l11_opy_ (u"ࠢࡑࡣࡷ࡬ࠥࡧ࡬ࡳࡧࡤࡨࡾࠦࡰࡳࡱࡦࡩࡸࡹࡥࡥࠢࡾࢁࠧᗙ").format(abs_path))
                    continue
                if entry.is_file():
                    try:
                        timestamp = datetime.fromtimestamp(entry.stat().st_mtime, tz=timezone.utc).isoformat()
                    except Exception:
                        timestamp = bstack1l1l11_opy_ (u"ࠣࠤᗚ")
                    log_entry = bstack1lllll111ll_opy_(
                        kind=bstack1l1l11_opy_ (u"ࠤࡗࡉࡘ࡚࡟ࡂࡖࡗࡅࡈࡎࡍࡆࡐࡗࠦᗛ"),
                        message=bstack1l1l11_opy_ (u"ࠥࠦᗜ"),
                        level=bstack1l1l11_opy_ (u"ࠦࠧᗝ"),
                        timestamp=timestamp,
                        fileName=entry.name,
                        bstack1llll1l1lll_opy_=entry.stat().st_size,
                        bstack1llll11111l_opy_=bstack1l1l11_opy_ (u"ࠧࡓࡁࡏࡗࡄࡐࡤ࡛ࡐࡍࡑࡄࡈࠧᗞ"),
                        bstack1ll11l_opy_=os.path.abspath(entry.path),
                        bstack1lllll1l111_opy_=hook.get(TestFramework.bstack1lllll11111_opy_)
                    )
                    logs.append(log_entry)
                    _1l11lll1111_opy_.add(abs_path)
        platform_index = os.environ[bstack1l1l11_opy_ (u"࠭ࡂࡓࡑ࡚ࡗࡊࡘࡓࡕࡃࡆࡏࡤࡖࡌࡂࡖࡉࡓࡗࡓ࡟ࡊࡐࡇࡉ࡝࠭ᗟ")]
        bstack1l11111l111_opy_ = os.path.join(bstack1l1l11111ll_opy_, (bstack1l1l11lll1l_opy_ + str(platform_index)), bstack11lll1l1l11_opy_, bstack11lll1l111l_opy_)
        if not os.path.exists(bstack1l11111l111_opy_) or not os.path.isdir(bstack1l11111l111_opy_):
            self.logger.info(bstack1l1l11_opy_ (u"ࠢࡏࡱࠣࡆࡺ࡯࡬ࡥࡎࡨࡺࡪࡲࡈࡰࡱ࡮ࡉࡻ࡫࡮ࡵࠢࡤࡸࡹࡧࡣࡩ࡯ࡨࡲࡹࡹࠠࡥ࡫ࡵࡩࡨࡺ࡯ࡳࡻࠣࡪࡴࡻ࡮ࡥࠢࡤࡸ࠿ࠦࡻࡾࠤᗠ").format(bstack1l11111l111_opy_))
        else:
            self.logger.info(bstack1l1l11_opy_ (u"ࠣࡒࡵࡳࡨ࡫ࡳࡴ࡫ࡱ࡫ࠥࡈࡵࡪ࡮ࡧࡐࡪࡼࡥ࡭ࡊࡲࡳࡰࡋࡶࡦࡰࡷࠤࡦࡺࡴࡢࡥ࡫ࡱࡪࡴࡴࡴࠢࡩࡶࡴࡳࠠࡥ࡫ࡵࡩࡨࡺ࡯ࡳࡻ࠽ࠤࢀࢃࠢᗡ").format(bstack1l11111l111_opy_))
            with os.scandir(bstack1l11111l111_opy_) as entries:
                for entry in entries:
                    abs_path = os.path.abspath(entry.path)
                    if abs_path in _1l11lll1111_opy_:
                        self.logger.info(bstack1l1l11_opy_ (u"ࠤࡓࡥࡹ࡮ࠠࡢ࡮ࡵࡩࡦࡪࡹࠡࡲࡵࡳࡨ࡫ࡳࡴࡧࡧࠤࢀࢃࠢᗢ").format(abs_path))
                        continue
                    if entry.is_file():
                        try:
                            timestamp = datetime.fromtimestamp(entry.stat().st_mtime, tz=timezone.utc).isoformat()
                        except Exception:
                            timestamp = bstack1l1l11_opy_ (u"ࠥࠦᗣ")
                        log_entry = bstack1lllll111ll_opy_(
                            kind=bstack1l1l11_opy_ (u"࡙ࠦࡋࡓࡕࡡࡄࡘ࡙ࡇࡃࡉࡏࡈࡒ࡙ࠨᗤ"),
                            message=bstack1l1l11_opy_ (u"ࠧࠨᗥ"),
                            level=bstack1l1l11_opy_ (u"ࠨࡂࡶ࡫࡯ࡨࡑ࡫ࡶࡦ࡮ࠥᗦ"),
                            timestamp=timestamp,
                            fileName=entry.name,
                            bstack1llll1l1lll_opy_=entry.stat().st_size,
                            bstack1llll11111l_opy_=bstack1l1l11_opy_ (u"ࠢࡎࡃࡑ࡙ࡆࡒ࡟ࡖࡒࡏࡓࡆࡊࠢᗧ"),
                            bstack1ll11l_opy_=os.path.abspath(entry.path),
                            bstack1lll1ll1l1l_opy_=hook.get(TestFramework.bstack1lllll11111_opy_)
                        )
                        logs.append(log_entry)
                        _1l11lll1111_opy_.add(abs_path)
        hook[bstack1l1l11_opy_ (u"ࠣ࡮ࡲ࡫ࡸࠨᗨ")] = logs
    def bstack1l11lllllll_opy_(
        self,
        bstack1l11llll1ll_opy_: bstack1lllll111l1_opy_,
        entries: List[bstack1lllll111ll_opy_],
    ):
        req = structs.LogCreatedEventRequest()
        req.bin_session_id = os.environ.get(bstack1l1l11_opy_ (u"ࠤࡅࡖࡔ࡝ࡓࡆࡔࡖࡘࡆࡉࡋࡠࡅࡏࡍࡤࡈࡉࡏࡡࡖࡉࡘ࡙ࡉࡐࡐࡢࡍࡉࠨᗩ"))
        req.platform_index = TestFramework.bstack1lll1llllll_opy_(bstack1l11llll1ll_opy_, TestFramework.bstack1llll11ll1l_opy_)
        req.execution_context.hash = str(bstack1l11llll1ll_opy_.context.hash)
        req.execution_context.thread_id = str(bstack1l11llll1ll_opy_.context.thread_id)
        req.execution_context.process_id = str(bstack1l11llll1ll_opy_.context.process_id)
        for entry in entries:
            log_entry = req.logs.add()
            log_entry.test_framework_name = TestFramework.bstack1lll1llllll_opy_(bstack1l11llll1ll_opy_, TestFramework.bstack1lll1ll111l_opy_)
            log_entry.test_framework_version = TestFramework.bstack1lll1llllll_opy_(bstack1l11llll1ll_opy_, TestFramework.bstack1lll1l1lll1_opy_)
            log_entry.uuid = entry.bstack1lllll1l111_opy_
            log_entry.test_framework_state = bstack1l11llll1ll_opy_.state.name
            log_entry.message = entry.message.encode(bstack1l1l11_opy_ (u"ࠥࡹࡹ࡬࠭࠹ࠤᗪ"))
            log_entry.kind = entry.kind
            log_entry.timestamp = (
                entry.timestamp.isoformat()
                if isinstance(entry.timestamp, datetime)
                else datetime.now(tz=timezone.utc).isoformat()
            )
            log_entry.level = bstack1l1l11_opy_ (u"ࠦࠧᗫ")
            if entry.kind == bstack1l1l11_opy_ (u"࡚ࠧࡅࡔࡖࡢࡅ࡙࡚ࡁࡄࡊࡐࡉࡓ࡚ࠢᗬ"):
                log_entry.file_name = entry.fileName
                log_entry.file_size = entry.bstack1llll1l1lll_opy_
                log_entry.file_path = entry.bstack1ll11l_opy_
        def bstack1l1l1111lll_opy_():
            bstack11l1l1ll1_opy_ = datetime.now()
            try:
                self.bstack1ll1ll1l111_opy_.LogCreatedEvent(req)
                bstack1l11llll1ll_opy_.bstack1lllll111_opy_(bstack1l1l11_opy_ (u"ࠨࡧࡳࡲࡦ࠾ࡸ࡫࡮ࡥࡡ࡯ࡳ࡬ࡥࡣࡳࡧࡤࡸࡪࡪ࡟ࡦࡸࡨࡲࡹࡥࡡࡵࡶࡤࡧ࡭ࡳࡥ࡯ࡶࠥᗭ"), datetime.now() - bstack11l1l1ll1_opy_)
            except grpc.RpcError as e:
                self.log_error(bstack1l1l11_opy_ (u"ࠢࡳࡲࡦ࠱ࡪࡸࡲࡰࡴ࠽ࠤࡸ࡫࡮ࡥࡡ࡯ࡳ࡬ࡥࡣࡳࡧࡤࡸࡪࡪ࡟ࡦࡸࡨࡲࡹࡥࡡࡵࡶࡤࡧ࡭ࡳࡥ࡯ࡶࠣࡿࢂࠨᗮ").format(str(e)))
                traceback.print_exc()
        self.bstack1llll11l1l1_opy_.enqueue(bstack1l1l1111lll_opy_)
    def __11lll1ll11l_opy_(self, instance) -> None:
        bstack1l1l11_opy_ (u"ࠣࠤࠥࠎࠥࠦࠠࠡࠢࠣࠤࠥࡒ࡯ࡢࡦࡶࠤࡨࡻࡳࡵࡱࡰࠤࡹࡧࡧࡴࠢࡩࡳࡷࠦࡴࡩࡧࠣ࡫࡮ࡼࡥ࡯ࠢࡷࡩࡸࡺࠠࡧࡴࡤࡱࡪࡽ࡯ࡳ࡭ࠣ࡭ࡳࡹࡴࡢࡰࡦࡩ࠳ࠐࠠࠡࠢࠣࠤࠥࠦࠠࡄࡴࡨࡥࡹ࡫ࡳࠡࡣࠣࡨ࡮ࡩࡴࠡࡥࡲࡲࡹࡧࡩ࡯࡫ࡱ࡫ࠥࡺࡥࡴࡶࠣࡰࡪࡼࡥ࡭ࠢࡦࡹࡸࡺ࡯࡮ࠢࡰࡩࡹࡧࡤࡢࡶࡤࠤࡷ࡫ࡴࡳ࡫ࡨࡺࡪࡪࠠࡧࡴࡲࡱࠏࠦࠠࠡࠢࠣࠤࠥࠦࡃࡶࡵࡷࡳࡲ࡚ࡡࡨࡏࡤࡲࡦ࡭ࡥࡳࠢࡤࡲࡩࠦࡵࡱࡦࡤࡸࡪࡹࠠࡵࡪࡨࠤ࡮ࡴࡳࡵࡣࡱࡧࡪࠦࡳࡵࡣࡷࡩࠥࡻࡳࡪࡰࡪࠤࡸ࡫ࡴࡠࡵࡷࡥࡹ࡫࡟ࡦࡰࡷࡶ࡮࡫ࡳ࠯ࠌࠣࠤࠥࠦࠠࠡࠢࠣࠦࠧࠨᗯ")
        bstack1l111111l1l_opy_ = {bstack1l1l11_opy_ (u"ࠤࡦࡹࡸࡺ࡯࡮ࡡࡰࡩࡹࡧࡤࡢࡶࡤࠦᗰ"): bstack1ll1llllll1_opy_.bstack11llll11l1l_opy_()}
        from browserstack_sdk.sdk_cli.test_framework import TestFramework
        TestFramework.bstack1lll1l1ll1l_opy_(instance, bstack1l111111l1l_opy_)
    @staticmethod
    def bstack11llll11lll_opy_(instance: bstack1lllll111l1_opy_, bstack11llll111ll_opy_: str):
        bstack11llllll1ll_opy_ = (
            bstack1ll1l1l11l1_opy_.bstack1l11111ll11_opy_
            if bstack11llll111ll_opy_ == bstack1ll1l1l11l1_opy_.bstack11lll1l1lll_opy_
            else bstack1ll1l1l11l1_opy_.bstack11lllll1lll_opy_
        )
        bstack11llllll1l1_opy_ = TestFramework.bstack1lll1llllll_opy_(instance, bstack11llll111ll_opy_, None)
        bstack1l11111l1ll_opy_ = TestFramework.bstack1lll1llllll_opy_(instance, bstack11llllll1ll_opy_, None) if bstack11llllll1l1_opy_ else None
        return (
            bstack1l11111l1ll_opy_[bstack11llllll1l1_opy_][-1]
            if isinstance(bstack1l11111l1ll_opy_, dict) and len(bstack1l11111l1ll_opy_.get(bstack11llllll1l1_opy_, [])) > 0
            else None
        )
    @staticmethod
    def bstack11lllll1111_opy_(instance: bstack1lllll111l1_opy_, bstack11llll111ll_opy_: str):
        hook = bstack1ll1l1l11l1_opy_.bstack11llll11lll_opy_(instance, bstack11llll111ll_opy_)
        if isinstance(hook, dict):
            hook.get(TestFramework.bstack1lllll1ll11_opy_, []).clear()
    @staticmethod
    def __11llll11ll1_opy_(instance: bstack1lllll111l1_opy_, *args):
        if len(args) < 2 or not callable(getattr(args[1], bstack1l1l11_opy_ (u"ࠥ࡫ࡪࡺ࡟ࡳࡧࡦࡳࡷࡪࡳࠣᗱ"), None)):
            return
        if os.getenv(bstack1l1l11_opy_ (u"ࠦࡘࡊࡋࡠࡅࡏࡍࡤࡌࡌࡂࡉࡢࡐࡔࡍࡓࠣᗲ"), bstack1l1l11_opy_ (u"ࠧ࠷ࠢᗳ")) != bstack1l1l11_opy_ (u"ࠨ࠱ࠣᗴ"):
            bstack1ll1l1l11l1_opy_.logger.warning(bstack1l1l11_opy_ (u"ࠢࡪࡩࡱࡳࡷ࡯࡮ࡨࠢࡦࡥࡵࡲ࡯ࡨࠤᗵ"))
            return
        bstack11lllll1l11_opy_ = {
            bstack1l1l11_opy_ (u"ࠣࡵࡨࡸࡺࡶࠢᗶ"): (bstack1ll1l1l11l1_opy_.bstack11lll1lllll_opy_, bstack1ll1l1l11l1_opy_.bstack11lllll1lll_opy_),
            bstack1l1l11_opy_ (u"ࠤࡷࡩࡦࡸࡤࡰࡹࡱࠦᗷ"): (bstack1ll1l1l11l1_opy_.bstack11lll1l1lll_opy_, bstack1ll1l1l11l1_opy_.bstack1l11111ll11_opy_),
        }
        for when in (bstack1l1l11_opy_ (u"ࠥࡷࡪࡺࡵࡱࠤᗸ"), bstack1l1l11_opy_ (u"ࠦࡨࡧ࡬࡭ࠤᗹ"), bstack1l1l11_opy_ (u"ࠧࡺࡥࡢࡴࡧࡳࡼࡴࠢᗺ")):
            bstack11lll1lll1l_opy_ = args[1].get_records(when)
            if not bstack11lll1lll1l_opy_:
                continue
            records = [
                bstack1lllll111ll_opy_(
                    kind=TestFramework.bstack1lll1ll11l1_opy_,
                    message=r.message,
                    level=r.levelname if hasattr(r, bstack1l1l11_opy_ (u"ࠨ࡬ࡦࡸࡨࡰࡳࡧ࡭ࡦࠤᗻ")) and r.levelname else None,
                    timestamp=(
                        datetime.fromtimestamp(r.created, tz=timezone.utc)
                        if hasattr(r, bstack1l1l11_opy_ (u"ࠢࡤࡴࡨࡥࡹ࡫ࡤࠣᗼ")) and r.created
                        else None
                    ),
                )
                for r in bstack11lll1lll1l_opy_
                if isinstance(getattr(r, bstack1l1l11_opy_ (u"ࠣ࡯ࡨࡷࡸࡧࡧࡦࠤᗽ"), None), str) and r.message.strip()
            ]
            if not records:
                continue
            bstack11llll1l111_opy_, bstack11llllll1ll_opy_ = bstack11lllll1l11_opy_.get(when, (None, None))
            bstack11lllll11l1_opy_ = TestFramework.bstack1lll1llllll_opy_(instance, bstack11llll1l111_opy_, None) if bstack11llll1l111_opy_ else None
            bstack1l11111l1ll_opy_ = TestFramework.bstack1lll1llllll_opy_(instance, bstack11llllll1ll_opy_, None) if bstack11lllll11l1_opy_ else None
            if isinstance(bstack1l11111l1ll_opy_, dict) and len(bstack1l11111l1ll_opy_.get(bstack11lllll11l1_opy_, [])) > 0:
                hook = bstack1l11111l1ll_opy_[bstack11lllll11l1_opy_][-1]
                if isinstance(hook, dict) and TestFramework.bstack1lllll1ll11_opy_ in hook:
                    hook[TestFramework.bstack1lllll1ll11_opy_].extend(records)
                    continue
            logs = TestFramework.bstack1lll1llllll_opy_(instance, TestFramework.bstack1lll1ll1l11_opy_, [])
            logs.extend(records)
    @staticmethod
    def __1l111111ll1_opy_(test) -> Dict[str, Any]:
        bstack11lll11111_opy_ = bstack1ll1l1l11l1_opy_.__1l111111l11_opy_(test.location) if hasattr(test, bstack1l1l11_opy_ (u"ࠤ࡯ࡳࡨࡧࡴࡪࡱࡱࠦᗾ")) else getattr(test, bstack1l1l11_opy_ (u"ࠥࡲࡴࡪࡥࡪࡦࠥᗿ"), None)
        test_name = test.name if hasattr(test, bstack1l1l11_opy_ (u"ࠦࡳࡧ࡭ࡦࠤᘀ")) else None
        bstack11lllllll11_opy_ = test.fspath.strpath if hasattr(test, bstack1l1l11_opy_ (u"ࠧ࡬ࡳࡱࡣࡷ࡬ࠧᘁ")) and test.fspath else None
        if not bstack11lll11111_opy_ or not test_name or not bstack11lllllll11_opy_:
            return None
        code = None
        if hasattr(test, bstack1l1l11_opy_ (u"ࠨ࡯ࡣ࡬ࠥᘂ")):
            try:
                import inspect
                code = inspect.getsource(test.obj)
            except:
                pass
        bstack11lll1l1l1l_opy_ = []
        try:
            bstack11lll1l1l1l_opy_ = bstack1lllll11l_opy_.bstack111l111111_opy_(test)
        except:
            bstack1ll1l1l11l1_opy_.logger.warning(bstack1l1l11_opy_ (u"ࠢࡖࡰࡤࡦࡱ࡫ࠠࡵࡱࠣࡪ࡮ࡴࡤࠡࡶࡨࡷࡹࠦࡳࡤࡱࡳࡩࡸ࠲ࠠࡵࡧࡶࡸࠥࡹࡣࡰࡲࡨࡷࠥࡽࡩ࡭࡮ࠣࡦࡪࠦࡲࡦࡵࡲࡰࡻ࡫ࡤࠡ࡫ࡱࠤࡈࡒࡉࠣᘃ"))
        return {
            TestFramework.bstack1llll1l1ll1_opy_: uuid4().__str__(),
            TestFramework.bstack1lll1ll1lll_opy_: bstack11lll11111_opy_,
            TestFramework.bstack1llll11l1ll_opy_: test_name,
            TestFramework.bstack1lll1lllll1_opy_: getattr(test, bstack1l1l11_opy_ (u"ࠣࡰࡲࡨࡪ࡯ࡤࠣᘄ"), None),
            TestFramework.bstack1lllll11l11_opy_: bstack11lllllll11_opy_,
            TestFramework.bstack1lll1ll1111_opy_: bstack1ll1l1l11l1_opy_.__11llll1l11l_opy_(test),
            TestFramework.bstack1lll1l1l1ll_opy_: code,
            TestFramework.bstack1llllll111l_opy_: TestFramework.bstack1lllll11lll_opy_,
            TestFramework.bstack1lll1l1l11l_opy_: bstack11lll11111_opy_,
            TestFramework.bstack1llll1l1l11_opy_: bstack11lll1l1l1l_opy_
        }
    @staticmethod
    def __11llll1l11l_opy_(test) -> List[str]:
        markers = []
        current = test
        while current:
            own_markers = getattr(current, bstack1l1l11_opy_ (u"ࠤࡲࡻࡳࡥ࡭ࡢࡴ࡮ࡩࡷࡹࠢᘅ"), [])
            markers.extend([getattr(m, bstack1l1l11_opy_ (u"ࠥࡲࡦࡳࡥࠣᘆ"), None) for m in own_markers if getattr(m, bstack1l1l11_opy_ (u"ࠦࡳࡧ࡭ࡦࠤᘇ"), None)])
            current = getattr(current, bstack1l1l11_opy_ (u"ࠧࡶࡡࡳࡧࡱࡸࠧᘈ"), None)
        return markers
    @staticmethod
    def __1l111111l11_opy_(location):
        return bstack1l1l11_opy_ (u"ࠨ࠺࠻ࠤᘉ").join(filter(lambda x: isinstance(x, str), location))