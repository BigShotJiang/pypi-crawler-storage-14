# coding: UTF-8
import sys
bstack1l11111_opy_ = sys.version_info [0] == 2
bstack11l11ll_opy_ = 2048
bstack111ll1l_opy_ = 7
def bstack1l1l11_opy_ (bstack11l1l_opy_):
    global bstack1l11_opy_
    bstack11l1111_opy_ = ord (bstack11l1l_opy_ [-1])
    bstack1l1ll1l_opy_ = bstack11l1l_opy_ [:-1]
    bstack11l11_opy_ = bstack11l1111_opy_ % len (bstack1l1ll1l_opy_)
    bstack1l1ll11_opy_ = bstack1l1ll1l_opy_ [:bstack11l11_opy_] + bstack1l1ll1l_opy_ [bstack11l11_opy_:]
    if bstack1l11111_opy_:
        bstack11lll1l_opy_ = unicode () .join ([unichr (ord (char) - bstack11l11ll_opy_ - (bstack11l111_opy_ + bstack11l1111_opy_) % bstack111ll1l_opy_) for bstack11l111_opy_, char in enumerate (bstack1l1ll11_opy_)])
    else:
        bstack11lll1l_opy_ = str () .join ([chr (ord (char) - bstack11l11ll_opy_ - (bstack11l111_opy_ + bstack11l1111_opy_) % bstack111ll1l_opy_) for bstack11l111_opy_, char in enumerate (bstack1l1ll11_opy_)])
    return eval (bstack11lll1l_opy_)
from datetime import datetime, timezone
import os
import builtins
from pathlib import Path
from typing import Any, Tuple, Callable, List
from browserstack_sdk.sdk_cli.bstack1lll111ll11_opy_ import bstack1lll111l111_opy_, bstack1lll111l1ll_opy_, bstack1lll1111l11_opy_
from browserstack_sdk.sdk_cli.bstack1ll11l111l1_opy_ import bstack1ll1l1lllll_opy_
from browserstack_sdk.sdk_cli.bstack1ll1l1l111l_opy_ import bstack1ll1l111l1l_opy_
from browserstack_sdk.sdk_cli.bstack1ll111l1111_opy_ import bstack1ll1llll11l_opy_
from browserstack_sdk.sdk_cli.test_framework import TestFramework, bstack1llll111lll_opy_, bstack1lllll111l1_opy_, bstack1llll1ll111_opy_, bstack1lllll111ll_opy_
from json import dumps, JSONEncoder
import grpc
from browserstack_sdk import sdk_pb2 as structs
import sys
import traceback
import time
import json
from bstack_utils.helper import bstack1l1l111ll11_opy_, bstack1l11llll111_opy_
from bstack_utils.measure import measure
from bstack_utils.constants import *
bstack1l11lll1ll1_opy_ = [bstack1l1l11_opy_ (u"ࠤࡱࡥࡲ࡫ࠢዧ"), bstack1l1l11_opy_ (u"ࠥࡴࡦࡸࡥ࡯ࡶࠥየ"), bstack1l1l11_opy_ (u"ࠦࡨࡵ࡮ࡧ࡫ࡪࠦዩ"), bstack1l1l11_opy_ (u"ࠧࡹࡥࡴࡵ࡬ࡳࡳࠨዪ"), bstack1l1l11_opy_ (u"ࠨࡰࡢࡶ࡫ࠦያ")]
bstack1l1l11111ll_opy_ = bstack1l11llll111_opy_()
bstack1l1l11lll1l_opy_ = bstack1l1l11_opy_ (u"ࠢࡖࡲ࡯ࡳࡦࡪࡥࡥࡃࡷࡸࡦࡩࡨ࡮ࡧࡱࡸࡸ࠳ࠢዬ")
bstack1l1l11l1ll1_opy_ = {
    bstack1l1l11_opy_ (u"ࠣࡲࡼࡸࡪࡹࡴ࠯ࡲࡼࡸ࡭ࡵ࡮࠯ࡋࡷࡩࡲࠨይ"): bstack1l11lll1ll1_opy_,
    bstack1l1l11_opy_ (u"ࠤࡳࡽࡹ࡫ࡳࡵ࠰ࡳࡽࡹ࡮࡯࡯࠰ࡓࡥࡨࡱࡡࡨࡧࠥዮ"): bstack1l11lll1ll1_opy_,
    bstack1l1l11_opy_ (u"ࠥࡴࡾࡺࡥࡴࡶ࠱ࡴࡾࡺࡨࡰࡰ࠱ࡑࡴࡪࡵ࡭ࡧࠥዯ"): bstack1l11lll1ll1_opy_,
    bstack1l1l11_opy_ (u"ࠦࡵࡿࡴࡦࡵࡷ࠲ࡵࡿࡴࡩࡱࡱ࠲ࡈࡲࡡࡴࡵࠥደ"): bstack1l11lll1ll1_opy_,
    bstack1l1l11_opy_ (u"ࠧࡶࡹࡵࡧࡶࡸ࠳ࡶࡹࡵࡪࡲࡲ࠳ࡌࡵ࡯ࡥࡷ࡭ࡴࡴࠢዱ"): bstack1l11lll1ll1_opy_
    + [
        bstack1l1l11_opy_ (u"ࠨ࡯ࡳ࡫ࡪ࡭ࡳࡧ࡬࡯ࡣࡰࡩࠧዲ"),
        bstack1l1l11_opy_ (u"ࠢ࡬ࡧࡼࡻࡴࡸࡤࡴࠤዳ"),
        bstack1l1l11_opy_ (u"ࠣࡨ࡬ࡼࡹࡻࡲࡦ࡫ࡱࡪࡴࠨዴ"),
        bstack1l1l11_opy_ (u"ࠤ࡮ࡩࡾࡽ࡯ࡳࡦࡶࠦድ"),
        bstack1l1l11_opy_ (u"ࠥࡧࡦࡲ࡬ࡴࡲࡨࡧࠧዶ"),
        bstack1l1l11_opy_ (u"ࠦࡨࡧ࡬࡭ࡱࡥ࡮ࠧዷ"),
        bstack1l1l11_opy_ (u"ࠧࡹࡴࡢࡴࡷࠦዸ"),
        bstack1l1l11_opy_ (u"ࠨࡳࡵࡱࡳࠦዹ"),
        bstack1l1l11_opy_ (u"ࠢࡥࡷࡵࡥࡹ࡯࡯࡯ࠤዺ"),
        bstack1l1l11_opy_ (u"ࠣࡹ࡫ࡩࡳࠨዻ"),
    ],
    bstack1l1l11_opy_ (u"ࠤࡳࡽࡹ࡫ࡳࡵ࠰ࡰࡥ࡮ࡴ࠮ࡔࡧࡶࡷ࡮ࡵ࡮ࠣዼ"): [bstack1l1l11_opy_ (u"ࠥࡷࡹࡧࡲࡵࡲࡤࡸ࡭ࠨዽ"), bstack1l1l11_opy_ (u"ࠦࡹ࡫ࡳࡵࡵࡩࡥ࡮ࡲࡥࡥࠤዾ"), bstack1l1l11_opy_ (u"ࠧࡺࡥࡴࡶࡶࡧࡴࡲ࡬ࡦࡥࡷࡩࡩࠨዿ"), bstack1l1l11_opy_ (u"ࠨࡩࡵࡧࡰࡷࠧጀ")],
    bstack1l1l11_opy_ (u"ࠢࡱࡻࡷࡩࡸࡺ࠮ࡤࡱࡱࡪ࡮࡭࠮ࡄࡱࡱࡪ࡮࡭ࠢጁ"): [bstack1l1l11_opy_ (u"ࠣ࡫ࡱࡺࡴࡩࡡࡵ࡫ࡲࡲࡤࡶࡡࡳࡣࡰࡷࠧጂ"), bstack1l1l11_opy_ (u"ࠤࡤࡶ࡬ࡹࠢጃ")],
    bstack1l1l11_opy_ (u"ࠥࡴࡾࡺࡥࡴࡶ࠱ࡪ࡮ࡾࡴࡶࡴࡨࡷ࠳ࡌࡩࡹࡶࡸࡶࡪࡊࡥࡧࠤጄ"): [bstack1l1l11_opy_ (u"ࠦࡸࡩ࡯ࡱࡧࠥጅ"), bstack1l1l11_opy_ (u"ࠧࡧࡲࡨࡰࡤࡱࡪࠨጆ"), bstack1l1l11_opy_ (u"ࠨࡦࡶࡰࡦࠦጇ"), bstack1l1l11_opy_ (u"ࠢࡱࡣࡵࡥࡲࡹࠢገ"), bstack1l1l11_opy_ (u"ࠣࡷࡱ࡭ࡹࡺࡥࡴࡶࠥጉ"), bstack1l1l11_opy_ (u"ࠤ࡬ࡨࡸࠨጊ")],
    bstack1l1l11_opy_ (u"ࠥࡴࡾࡺࡥࡴࡶ࠱ࡪ࡮ࡾࡴࡶࡴࡨࡷ࠳࡙ࡵࡣࡔࡨࡵࡺ࡫ࡳࡵࠤጋ"): [bstack1l1l11_opy_ (u"ࠦ࡫࡯ࡸࡵࡷࡵࡩࡳࡧ࡭ࡦࠤጌ"), bstack1l1l11_opy_ (u"ࠧࡶࡡࡳࡣࡰࠦግ"), bstack1l1l11_opy_ (u"ࠨࡰࡢࡴࡤࡱࡤ࡯࡮ࡥࡧࡻࠦጎ")],
    bstack1l1l11_opy_ (u"ࠢࡱࡻࡷࡩࡸࡺ࠮ࡳࡷࡱࡲࡪࡸ࠮ࡄࡣ࡯ࡰࡎࡴࡦࡰࠤጏ"): [bstack1l1l11_opy_ (u"ࠣࡹ࡫ࡩࡳࠨጐ"), bstack1l1l11_opy_ (u"ࠤࡵࡩࡸࡻ࡬ࡵࠤ጑")],
    bstack1l1l11_opy_ (u"ࠥࡴࡾࡺࡥࡴࡶ࠱ࡱࡦࡸ࡫࠯ࡵࡷࡶࡺࡩࡴࡶࡴࡨࡷ࠳ࡔ࡯ࡥࡧࡎࡩࡾࡽ࡯ࡳࡦࡶࠦጒ"): [bstack1l1l11_opy_ (u"ࠦࡳࡵࡤࡦࠤጓ"), bstack1l1l11_opy_ (u"ࠧࡶࡡࡳࡧࡱࡸࠧጔ")],
    bstack1l1l11_opy_ (u"ࠨࡰࡺࡶࡨࡷࡹ࠴࡭ࡢࡴ࡮࠲ࡸࡺࡲࡶࡥࡷࡹࡷ࡫ࡳ࠯ࡏࡤࡶࡰࠨጕ"): [bstack1l1l11_opy_ (u"ࠢ࡯ࡣࡰࡩࠧ጖"), bstack1l1l11_opy_ (u"ࠣࡣࡵ࡫ࡸࠨ጗"), bstack1l1l11_opy_ (u"ࠤ࡮ࡻࡦࡸࡧࡴࠤጘ")],
}
_1l11lll1111_opy_ = set()
class bstack1ll11l1llll_opy_(bstack1ll1l1lllll_opy_):
    bstack1l1l11lll11_opy_ = bstack1l1l11_opy_ (u"ࠥࡸࡪࡹࡴࡠࡦࡨࡪࡪࡸࡲࡦࡦࠥጙ")
    bstack1l1l11ll111_opy_ = bstack1l1l11_opy_ (u"ࠦࡎࡔࡆࡐࠤጚ")
    bstack1l1l111l1ll_opy_ = bstack1l1l11_opy_ (u"ࠧࡋࡒࡓࡑࡕࠦጛ")
    bstack1l11lllll11_opy_: Callable
    bstack1l1l11l1l11_opy_: Callable
    def __init__(self, bstack1ll1ll1ll11_opy_, bstack1ll11lllll1_opy_):
        super().__init__()
        self.bstack1l1lllll11l_opy_ = bstack1ll11lllll1_opy_
        if os.getenv(bstack1l1l11_opy_ (u"ࠨࡓࡅࡍࡢࡇࡑࡏ࡟ࡇࡎࡄࡋࡤࡕ࠱࠲࡛ࠥጜ"), bstack1l1l11_opy_ (u"ࠢ࠲ࠤጝ")) != bstack1l1l11_opy_ (u"ࠣ࠳ࠥጞ") or not self.is_enabled():
            self.logger.warning(bstack1l1l11_opy_ (u"ࠤࠥጟ") + str(self.__class__.__name__) + bstack1l1l11_opy_ (u"ࠥࠤࡩ࡯ࡳࡢࡤ࡯ࡩࡩࠨጠ"))
            return
        TestFramework.bstack1llll1lll1l_opy_((bstack1llll111lll_opy_.TEST, bstack1llll1ll111_opy_.PRE), self.bstack1l1ll1l1l11_opy_)
        TestFramework.bstack1llll1lll1l_opy_((bstack1llll111lll_opy_.TEST, bstack1llll1ll111_opy_.POST), self.bstack1l1ll1l11ll_opy_)
        for event in bstack1llll111lll_opy_:
            for state in bstack1llll1ll111_opy_:
                TestFramework.bstack1llll1lll1l_opy_((event, state), self.bstack1l1l1l11111_opy_)
        bstack1ll1ll1ll11_opy_.bstack1llll1lll1l_opy_((bstack1lll111l1ll_opy_.bstack1lll11l1l1l_opy_, bstack1lll1111l11_opy_.POST), self.bstack1l1l11ll1ll_opy_)
        self.bstack1l11lllll11_opy_ = sys.stdout.write
        sys.stdout.write = self.bstack1l1l111l1l1_opy_(bstack1ll11l1llll_opy_.bstack1l1l11ll111_opy_, self.bstack1l11lllll11_opy_)
        self.bstack1l1l11l1l11_opy_ = sys.stderr.write
        sys.stderr.write = self.bstack1l1l111l1l1_opy_(bstack1ll11l1llll_opy_.bstack1l1l111l1ll_opy_, self.bstack1l1l11l1l11_opy_)
        self.bstack1l11lll1l11_opy_ = builtins.print
        builtins.print = self.bstack1l1l1111l1l_opy_()
    def is_enabled(self) -> bool:
        return True
    def bstack1l1l1l11111_opy_(
        self,
        f: TestFramework,
        instance: bstack1lllll111l1_opy_,
        bstack1llll1111ll_opy_: Tuple[bstack1llll111lll_opy_, bstack1llll1ll111_opy_],
        *args,
        **kwargs,
    ):
        if f.bstack1llll11l11l_opy_() and instance:
            bstack1l1l111lll1_opy_ = datetime.now()
            test_framework_state, test_hook_state = bstack1llll1111ll_opy_
            if test_framework_state == bstack1llll111lll_opy_.SETUP_FIXTURE:
                return
            elif test_framework_state == bstack1llll111lll_opy_.LOG:
                bstack11l1l1ll1_opy_ = datetime.now()
                entries = f.bstack1llllll1l11_opy_(instance, bstack1llll1111ll_opy_)
                if entries:
                    self.bstack1l11lllllll_opy_(instance, entries)
                    instance.bstack1lllll111_opy_(bstack1l1l11_opy_ (u"ࠦ࡬ࡸࡰࡤ࠼ࡶࡩࡳࡪ࡟࡭ࡱࡪࡣࡨࡸࡥࡢࡶࡨࡨࡤ࡫ࡶࡦࡰࡷࠦጡ"), datetime.now() - bstack11l1l1ll1_opy_)
                    f.bstack1llllll1111_opy_(instance, bstack1llll1111ll_opy_)
                instance.bstack1lllll111_opy_(bstack1l1l11_opy_ (u"ࠧࡵ࠱࠲ࡻ࠽ࡳࡳࡥࡡ࡭࡮ࡢࡸࡪࡹࡴࡠࡧࡹࡩࡳࡺࡳࠣጢ"), datetime.now() - bstack1l1l111lll1_opy_)
                return # bstack1l1l11l11l1_opy_ not send this event with the bstack1l1l11lllll_opy_ bstack1l1l111ll1l_opy_
            elif (
                test_framework_state == bstack1llll111lll_opy_.TEST
                and test_hook_state == bstack1llll1ll111_opy_.POST
                and not f.bstack1lllll1l1ll_opy_(instance, TestFramework.bstack1llll11lll1_opy_)
            ):
                self.logger.warning(bstack1l1l11_opy_ (u"ࠨࡤࡳࡱࡳࡴ࡮ࡴࡧࠡࡦࡸࡩࠥࡺ࡯ࠡ࡮ࡤࡧࡰࠦ࡯ࡧࠢࡵࡩࡸࡻ࡬ࡵࡵࠣࠦጣ") + str(TestFramework.bstack1lllll1l1ll_opy_(instance, TestFramework.bstack1llll11lll1_opy_)) + bstack1l1l11_opy_ (u"ࠢࠣጤ"))
                f.bstack1lllll1l11l_opy_(instance, bstack1ll11l1llll_opy_.bstack1l1l11lll11_opy_, True)
                return # bstack1l1l11l11l1_opy_ not send this event bstack1l1l1l1111l_opy_ bstack1l1l11l1lll_opy_
            elif (
                f.bstack1lll1llllll_opy_(instance, bstack1ll11l1llll_opy_.bstack1l1l11lll11_opy_, False)
                and test_framework_state == bstack1llll111lll_opy_.LOG_REPORT
                and test_hook_state == bstack1llll1ll111_opy_.POST
                and f.bstack1lllll1l1ll_opy_(instance, TestFramework.bstack1llll11lll1_opy_)
            ):
                self.logger.warning(bstack1l1l11_opy_ (u"ࠣ࡫ࡱ࡮ࡪࡩࡴࡪࡰࡪࠤ࡙࡫ࡳࡵࡈࡵࡥࡲ࡫ࡷࡰࡴ࡮ࡗࡹࡧࡴࡦ࠰ࡗࡉࡘ࡚ࠬࠡࡖࡨࡷࡹࡎ࡯ࡰ࡭ࡖࡸࡦࡺࡥ࠯ࡒࡒࡗ࡙ࠦࠢጥ") + str(TestFramework.bstack1lllll1l1ll_opy_(instance, TestFramework.bstack1llll11lll1_opy_)) + bstack1l1l11_opy_ (u"ࠤࠥጦ"))
                self.bstack1l1l1l11111_opy_(f, instance, (bstack1llll111lll_opy_.TEST, bstack1llll1ll111_opy_.POST), *args, **kwargs)
            bstack11l1l1ll1_opy_ = datetime.now()
            data = instance.data.copy()
            bstack1l11llllll1_opy_ = sorted(
                filter(lambda x: x.get(bstack1l1l11_opy_ (u"ࠥࡩࡻ࡫࡮ࡵࡡࡶࡸࡦࡸࡴࡦࡦࡢࡥࡹࠨጧ"), None), data.pop(bstack1l1l11_opy_ (u"ࠦࡹ࡫ࡳࡵࡡࡩ࡭ࡽࡺࡵࡳࡧࡶࠦጨ"), {}).values()),
                key=lambda x: x[bstack1l1l11_opy_ (u"ࠧ࡫ࡶࡦࡰࡷࡣࡸࡺࡡࡳࡶࡨࡨࡤࡧࡴࠣጩ")],
            )
            if bstack1ll1l111l1l_opy_.bstack1l1l111l11l_opy_ in data:
                data.pop(bstack1ll1l111l1l_opy_.bstack1l1l111l11l_opy_)
            data.update({bstack1l1l11_opy_ (u"ࠨࡴࡦࡵࡷࡣ࡫࡯ࡸࡵࡷࡵࡩࡸࠨጪ"): bstack1l11llllll1_opy_})
            instance.bstack1lllll111_opy_(bstack1l1l11_opy_ (u"ࠢ࡫ࡵࡲࡲ࠿ࡺࡥࡴࡶࡢࡪ࡮ࡾࡴࡶࡴࡨࡷࠧጫ"), datetime.now() - bstack11l1l1ll1_opy_)
            bstack11l1l1ll1_opy_ = datetime.now()
            event_json = dumps(data, cls=bstack1l1l11111l1_opy_)
            instance.bstack1lllll111_opy_(bstack1l1l11_opy_ (u"ࠣ࡬ࡶࡳࡳࡀ࡯࡯ࡡࡤࡰࡱࡥࡴࡦࡵࡷࡣࡪࡼࡥ࡯ࡶࡶࠦጬ"), datetime.now() - bstack11l1l1ll1_opy_)
            self.bstack1l1l111ll1l_opy_(instance, bstack1llll1111ll_opy_, event_json=event_json)
            instance.bstack1lllll111_opy_(bstack1l1l11_opy_ (u"ࠤࡲ࠵࠶ࡿ࠺ࡰࡰࡢࡥࡱࡲ࡟ࡵࡧࡶࡸࡤ࡫ࡶࡦࡰࡷࡷࠧጭ"), datetime.now() - bstack1l1l111lll1_opy_)
    def bstack1l1ll1l1l11_opy_(
        self,
        f: TestFramework,
        instance: bstack1lllll111l1_opy_,
        bstack1llll1111ll_opy_: Tuple[bstack1llll111lll_opy_, bstack1llll1ll111_opy_],
        *args,
        **kwargs,
    ):
        from bstack_utils.bstack1111ll1l1_opy_ import bstack1ll111l1ll1_opy_
        bstack1l1ll1ll111_opy_ = bstack1ll111l1ll1_opy_.bstack1l1ll1ll1ll_opy_(EVENTS.bstack11111l1ll_opy_.value)
        self.bstack1l1lllll11l_opy_.bstack1l1l111llll_opy_(instance, f, bstack1llll1111ll_opy_, *args, **kwargs)
        req = self.bstack1l1lllll11l_opy_.bstack1l11ll1llll_opy_(instance, f, bstack1llll1111ll_opy_, *args, **kwargs)
        self.bstack1l11lll11l1_opy_(f, instance, req)
        bstack1ll111l1ll1_opy_.end(EVENTS.bstack11111l1ll_opy_.value, bstack1l1ll1ll111_opy_ + bstack1l1l11_opy_ (u"ࠥ࠾ࡸࡺࡡࡳࡶࠥጮ"), bstack1l1ll1ll111_opy_ + bstack1l1l11_opy_ (u"ࠦ࠿࡫࡮ࡥࠤጯ"), status=True, failure=None, test_name=None)
    def bstack1l1ll1l11ll_opy_(
        self,
        f: TestFramework,
        instance: bstack1lllll111l1_opy_,
        bstack1llll1111ll_opy_: Tuple[bstack1llll111lll_opy_, bstack1llll1ll111_opy_],
        *args,
        **kwargs,
    ):
        if not f.bstack1lll1llllll_opy_(instance, self.bstack1l1lllll11l_opy_.bstack1l1l1l111ll_opy_, False):
            req = self.bstack1l1lllll11l_opy_.bstack1l11ll1llll_opy_(instance, f, bstack1llll1111ll_opy_, *args, **kwargs)
            self.bstack1l11lll11l1_opy_(f, instance, req)
    @measure(event_name=EVENTS.bstack1l1l1111l11_opy_, stage=STAGE.bstack111llllll_opy_)
    def bstack1l11lll11l1_opy_(
        self,
        f: TestFramework,
        instance: bstack1lllll111l1_opy_,
        req: structs.TestSessionEventRequest
    ):
        if not req:
            self.logger.debug(bstack1l1l11_opy_ (u"࡙ࠧ࡫ࡪࡲࡳ࡭ࡳ࡭ࠠࡕࡧࡶࡸࡘ࡫ࡳࡴ࡫ࡲࡲࡊࡼࡥ࡯ࡶࠣ࡫ࡗࡖࡃࠡࡥࡤࡰࡱࡀࠠࡏࡱࠣࡺࡦࡲࡩࡥࠢࡵࡩࡶࡻࡥࡴࡶࠣࡨࡦࡺࡡࠣጰ"))
            return
        bstack11l1l1ll1_opy_ = datetime.now()
        try:
            r = self.bstack1ll1ll1l111_opy_.TestSessionEvent(req)
            instance.bstack1lllll111_opy_(bstack1l1l11_opy_ (u"ࠨࡧࡳࡲࡦ࠾ࡸ࡫࡮ࡥࡡࡷࡩࡸࡺ࡟ࡴࡧࡶࡷ࡮ࡵ࡮ࡠࡧࡹࡩࡳࡺࠢጱ"), datetime.now() - bstack11l1l1ll1_opy_)
            f.bstack1lllll1l11l_opy_(instance, self.bstack1l1lllll11l_opy_.bstack1l1l1l111ll_opy_, r.success)
            if not r.success:
                self.logger.info(bstack1l1l11_opy_ (u"ࠢࡳࡧࡦࡩ࡮ࡼࡥࡥࠢࡩࡶࡴࡳࠠࡴࡧࡵࡺࡪࡸ࠺ࠡࠤጲ") + str(r) + bstack1l1l11_opy_ (u"ࠣࠤጳ"))
        except grpc.RpcError as e:
            self.logger.error(bstack1l1l11_opy_ (u"ࠤࡵࡴࡨ࠳ࡥࡳࡴࡲࡶ࠿ࠦࠢጴ") + str(e) + bstack1l1l11_opy_ (u"ࠥࠦጵ"))
            traceback.print_exc()
            raise e
    def bstack1l1l11ll1ll_opy_(
        self,
        f: bstack1ll1llll11l_opy_,
        _driver: object,
        exec: Tuple[bstack1lll111l111_opy_, str],
        _1l1l1l11l11_opy_: Tuple[bstack1lll111l1ll_opy_, bstack1lll1111l11_opy_],
        result: Any,
        *args,
        **kwargs,
    ):
        instance, method_name = exec
        if not bstack1ll1llll11l_opy_.bstack1l1l1lllll1_opy_(method_name):
            return
        if f.bstack1l1llll11l1_opy_(*args) == bstack1ll1llll11l_opy_.bstack1l1l111111l_opy_:
            bstack1l1l111lll1_opy_ = datetime.now()
            screenshot = result.get(bstack1l1l11_opy_ (u"ࠦࡻࡧ࡬ࡶࡧࠥጶ"), None) if isinstance(result, dict) else None
            if not isinstance(screenshot, str) or len(screenshot) <= 0:
                self.logger.warning(bstack1l1l11_opy_ (u"ࠧ࡯࡮ࡷࡣ࡯࡭ࡩࠦࡳࡤࡴࡨࡩࡳࡹࡨࡰࡶࠣ࡭ࡲࡧࡧࡦࠢࡥࡥࡸ࡫࠶࠵ࠢࡶࡸࡷࠨጷ"))
                return
            bstack1l11llll1ll_opy_ = self.bstack1l1l11l11ll_opy_(instance)
            if bstack1l11llll1ll_opy_:
                entry = bstack1lllll111ll_opy_(TestFramework.bstack1lll1l1l111_opy_, screenshot)
                self.bstack1l11lllllll_opy_(bstack1l11llll1ll_opy_, [entry])
                instance.bstack1lllll111_opy_(bstack1l1l11_opy_ (u"ࠨ࡯࠲࠳ࡼ࠾ࡴࡴ࡟ࡢࡨࡷࡩࡷࡥࡥࡹࡧࡦࡹࡹ࡫ࠢጸ"), datetime.now() - bstack1l1l111lll1_opy_)
            else:
                self.logger.warning(bstack1l1l11_opy_ (u"ࠢࡶࡰࡤࡦࡱ࡫ࠠࡵࡱࠣࡨࡪࡺࡥࡳ࡯࡬ࡲࡪࠦࡴࡦࡵࡷࠤ࡫ࡵࡲࠡࡹ࡫࡭ࡨ࡮ࠠࡵࡪ࡬ࡷࠥࡹࡣࡳࡧࡨࡲࡸ࡮࡯ࡵࠢࡺࡥࡸࠦࡴࡢ࡭ࡨࡲࠥࡨࡹࠡࡦࡵ࡭ࡻ࡫ࡲ࠾ࠢࡾࢁࠧጹ").format(instance.ref()))
        event = {}
        bstack1l11llll1ll_opy_ = self.bstack1l1l11l11ll_opy_(instance)
        if bstack1l11llll1ll_opy_:
            self.bstack1l1l11llll1_opy_(event, bstack1l11llll1ll_opy_)
            if event.get(bstack1l1l11_opy_ (u"ࠣ࡮ࡲ࡫ࡸࠨጺ")):
                self.bstack1l11lllllll_opy_(bstack1l11llll1ll_opy_, event[bstack1l1l11_opy_ (u"ࠤ࡯ࡳ࡬ࡹࠢጻ")])
            else:
                self.logger.debug(bstack1l1l11_opy_ (u"࡙ࠥࡳࡧࡢ࡭ࡧࠣࡸࡴࠦࡤࡦࡶࡨࡶࡲ࡯࡮ࡦࠢ࡯ࡳ࡬ࡹࠠࡧࡱࡵࠤࡦࡺࡴࡢࡥ࡫ࡱࡪࡴࡴࠡࡧࡹࡩࡳࡺࠢጼ"))
    @measure(event_name=EVENTS.bstack1l1l1l111l1_opy_, stage=STAGE.bstack111llllll_opy_)
    def bstack1l11lllllll_opy_(
        self,
        bstack1l11llll1ll_opy_: bstack1lllll111l1_opy_,
        entries: List[bstack1lllll111ll_opy_],
    ):
        self.bstack1l1ll11l111_opy_()
        req = structs.LogCreatedEventRequest()
        req.bin_session_id = self.bin_session_id
        req.platform_index = TestFramework.bstack1lll1llllll_opy_(bstack1l11llll1ll_opy_, TestFramework.bstack1llll11ll1l_opy_)
        req.execution_context.hash = str(bstack1l11llll1ll_opy_.context.hash)
        req.execution_context.thread_id = str(bstack1l11llll1ll_opy_.context.thread_id)
        req.execution_context.process_id = str(bstack1l11llll1ll_opy_.context.process_id)
        for entry in entries:
            log_entry = req.logs.add()
            log_entry.test_framework_name = TestFramework.bstack1lll1llllll_opy_(bstack1l11llll1ll_opy_, TestFramework.bstack1lll1ll111l_opy_)
            log_entry.test_framework_version = TestFramework.bstack1lll1llllll_opy_(bstack1l11llll1ll_opy_, TestFramework.bstack1lll1l1lll1_opy_)
            log_entry.uuid = TestFramework.bstack1lll1llllll_opy_(bstack1l11llll1ll_opy_, TestFramework.bstack1llll1l1ll1_opy_)
            log_entry.test_framework_state = bstack1l11llll1ll_opy_.state.name
            log_entry.message = entry.message.encode(bstack1l1l11_opy_ (u"ࠦࡺࡺࡦ࠮࠺ࠥጽ"))
            log_entry.kind = entry.kind
            log_entry.timestamp = (
                entry.timestamp.isoformat()
                if isinstance(entry.timestamp, datetime)
                else datetime.now(tz=timezone.utc).isoformat()
            )
            if isinstance(entry.level, str) and len(entry.level.strip()) > 0:
                log_entry.level = entry.level.strip()
            if entry.kind == bstack1l1l11_opy_ (u"࡚ࠧࡅࡔࡖࡢࡅ࡙࡚ࡁࡄࡊࡐࡉࡓ࡚ࠢጾ"):
                log_entry.file_name = entry.fileName
                log_entry.file_size = entry.bstack1llll1l1lll_opy_
                log_entry.file_path = entry.bstack1ll11l_opy_
        def bstack1l1l1111lll_opy_():
            bstack11l1l1ll1_opy_ = datetime.now()
            try:
                self.bstack1ll1ll1l111_opy_.LogCreatedEvent(req)
                if entry.kind == TestFramework.bstack1lll1l1l111_opy_:
                    bstack1l11llll1ll_opy_.bstack1lllll111_opy_(bstack1l1l11_opy_ (u"ࠨࡧࡳࡲࡦ࠾ࡸ࡫࡮ࡥࡡ࡯ࡳ࡬ࡥࡣࡳࡧࡤࡸࡪࡪ࡟ࡦࡸࡨࡲࡹࡥࡳࡤࡴࡨࡩࡳࡹࡨࡰࡶࠥጿ"), datetime.now() - bstack11l1l1ll1_opy_)
                elif entry.kind == TestFramework.bstack1lllll1l1l1_opy_:
                    bstack1l11llll1ll_opy_.bstack1lllll111_opy_(bstack1l1l11_opy_ (u"ࠢࡨࡴࡳࡧ࠿ࡹࡥ࡯ࡦࡢࡰࡴ࡭࡟ࡤࡴࡨࡥࡹ࡫ࡤࡠࡧࡹࡩࡳࡺ࡟ࡢࡶࡷࡥࡨ࡮࡭ࡦࡰࡷࠦፀ"), datetime.now() - bstack11l1l1ll1_opy_)
                else:
                    bstack1l11llll1ll_opy_.bstack1lllll111_opy_(bstack1l1l11_opy_ (u"ࠣࡩࡵࡴࡨࡀࡳࡦࡰࡧࡣࡱࡵࡧࡠࡥࡵࡩࡦࡺࡥࡥࡡࡨࡺࡪࡴࡴࡠ࡮ࡲ࡫ࠧፁ"), datetime.now() - bstack11l1l1ll1_opy_)
            except grpc.RpcError as e:
                self.log_error(bstack1l1l11_opy_ (u"ࠤࡵࡴࡨ࠳ࡥࡳࡴࡲࡶ࠿ࠦࠢፂ") + str(e))
                traceback.print_exc()
                raise e
        self.bstack1llll11l1l1_opy_.enqueue(bstack1l1l1111lll_opy_)
    @measure(event_name=EVENTS.bstack1l1l1111111_opy_, stage=STAGE.bstack111llllll_opy_)
    def bstack1l1l111ll1l_opy_(
        self,
        instance: bstack1lllll111l1_opy_,
        bstack1llll1111ll_opy_: Tuple[bstack1llll111lll_opy_, bstack1llll1ll111_opy_],
        event_json=None,
    ):
        self.bstack1l1ll11l111_opy_()
        req = structs.TestFrameworkEventRequest()
        req.bin_session_id = self.bin_session_id
        req.platform_index = TestFramework.bstack1lll1llllll_opy_(instance, TestFramework.bstack1llll11ll1l_opy_)
        req.test_framework_name = TestFramework.bstack1lll1llllll_opy_(instance, TestFramework.bstack1lll1ll111l_opy_)
        req.test_framework_version = TestFramework.bstack1lll1llllll_opy_(instance, TestFramework.bstack1lll1l1lll1_opy_)
        req.test_framework_state = bstack1llll1111ll_opy_[0].name
        req.test_hook_state = bstack1llll1111ll_opy_[1].name
        started_at = TestFramework.bstack1lll1llllll_opy_(instance, TestFramework.bstack1llll1l1111_opy_, None)
        if started_at:
            req.started_at = started_at.isoformat()
        ended_at = TestFramework.bstack1lll1llllll_opy_(instance, TestFramework.bstack1llll1llll1_opy_, None)
        if ended_at:
            req.ended_at = ended_at.isoformat()
        req.uuid = instance.ref()
        req.event_json = (event_json if event_json else dumps(instance.data, cls=bstack1l1l11111l1_opy_)).encode(bstack1l1l11_opy_ (u"ࠥࡹࡹ࡬࠭࠹ࠤፃ"))
        req.execution_context.hash = str(instance.context.hash)
        req.execution_context.thread_id = str(instance.context.thread_id)
        req.execution_context.process_id = str(instance.context.process_id)
        def bstack1l1l1111lll_opy_():
            bstack11l1l1ll1_opy_ = datetime.now()
            try:
                self.bstack1ll1ll1l111_opy_.TestFrameworkEvent(req)
                instance.bstack1lllll111_opy_(bstack1l1l11_opy_ (u"ࠦ࡬ࡸࡰࡤ࠼ࡶࡩࡳࡪ࡟ࡵࡧࡶࡸࡤ࡬ࡲࡢ࡯ࡨࡻࡴࡸ࡫ࡠࡧࡹࡩࡳࡺࠢፄ"), datetime.now() - bstack11l1l1ll1_opy_)
            except grpc.RpcError as e:
                self.log_error(bstack1l1l11_opy_ (u"ࠧࡸࡰࡤ࠯ࡨࡶࡷࡵࡲ࠻ࠢࠥፅ") + str(e))
                traceback.print_exc()
                raise e
        self.bstack1llll11l1l1_opy_.enqueue(bstack1l1l1111lll_opy_)
    def bstack1l1l11l11ll_opy_(self, instance: bstack1lll111l111_opy_):
        bstack1l1l11l111l_opy_ = TestFramework.bstack1lll1llll11_opy_(instance.context)
        for t in bstack1l1l11l111l_opy_:
            bstack1l11llll1l1_opy_ = TestFramework.bstack1lll1llllll_opy_(t, bstack1ll1l111l1l_opy_.bstack1l1l111l11l_opy_, [])
            if any(instance is d[1] for d in bstack1l11llll1l1_opy_):
                return t
    def bstack1l11lll11ll_opy_(self, message):
        self.bstack1l11lllll11_opy_(message + bstack1l1l11_opy_ (u"ࠨ࡜࡯ࠤፆ"))
    def log_error(self, message):
        self.bstack1l1l11l1l11_opy_(message + bstack1l1l11_opy_ (u"ࠢ࡝ࡰࠥፇ"))
    def bstack1l1l111l1l1_opy_(self, level, original_func):
        def bstack1l1l11l1111_opy_(*args):
            return_value = original_func(*args)
            if not args or not isinstance(args[0], str) or not args[0].strip():
                return return_value
            message = args[0].strip()
            if bstack1l1l11_opy_ (u"ࠣࡇࡹࡩࡳࡺࡄࡪࡵࡳࡥࡹࡩࡨࡦࡴࡐࡳࡩࡻ࡬ࡦࠤፈ") in message or bstack1l1l11_opy_ (u"ࠤ࡞ࡗࡉࡑࡃࡍࡋࡠࠦፉ") in message or bstack1l1l11_opy_ (u"ࠥ࡟࡜࡫ࡢࡅࡴ࡬ࡺࡪࡸࡍࡰࡦࡸࡰࡪࡣࠢፊ") in message:
                return return_value
            bstack1l1l11l111l_opy_ = TestFramework.bstack1llll1ll1ll_opy_()
            if not bstack1l1l11l111l_opy_:
                return return_value
            bstack1l11llll1ll_opy_ = next(
                (
                    instance
                    for instance in bstack1l1l11l111l_opy_
                    if TestFramework.bstack1lllll1l1ll_opy_(instance, TestFramework.bstack1llll1l1ll1_opy_)
                ),
                None,
            )
            if not bstack1l11llll1ll_opy_:
                return return_value
            entry = bstack1lllll111ll_opy_(TestFramework.bstack1lll1ll11l1_opy_, message, level)
            self.bstack1l11lllllll_opy_(bstack1l11llll1ll_opy_, [entry])
            return return_value
        return bstack1l1l11l1111_opy_
    def bstack1l1l1111l1l_opy_(self):
        def bstack1l1l11ll1l1_opy_(*args, **kwargs):
            try:
                self.bstack1l11lll1l11_opy_(*args, **kwargs)
                if not args:
                    return
                message = bstack1l1l11_opy_ (u"ࠫࠥ࠭ፋ").join(str(arg) for arg in args)
                if not message.strip():
                    return
                if bstack1l1l11_opy_ (u"ࠧࡋࡶࡦࡰࡷࡈ࡮ࡹࡰࡢࡶࡦ࡬ࡪࡸࡍࡰࡦࡸࡰࡪࠨፌ") in message:
                    return
                bstack1l1l11l111l_opy_ = TestFramework.bstack1llll1ll1ll_opy_()
                if not bstack1l1l11l111l_opy_:
                    return
                bstack1l11llll1ll_opy_ = next(
                    (
                        instance
                        for instance in bstack1l1l11l111l_opy_
                        if TestFramework.bstack1lllll1l1ll_opy_(instance, TestFramework.bstack1llll1l1ll1_opy_)
                    ),
                    None,
                )
                if not bstack1l11llll1ll_opy_:
                    return
                entry = bstack1lllll111ll_opy_(TestFramework.bstack1lll1ll11l1_opy_, message, bstack1ll11l1llll_opy_.bstack1l1l11ll111_opy_)
                self.bstack1l11lllllll_opy_(bstack1l11llll1ll_opy_, [entry])
            except Exception as e:
                try:
                    self.bstack1l11lll1l11_opy_(bstack1ll1ll1l11l_opy_ (u"ࠨ࡛ࡆࡸࡨࡲࡹࡊࡩࡴࡲࡤࡸࡨ࡮ࡥࡳࡏࡲࡨࡺࡲࡥ࡞ࠢࡏࡳ࡬ࠦࡣࡢࡲࡷࡹࡷ࡫ࠠࡦࡴࡵࡳࡷࡀࠠࡼࡧࢀࠦፍ"))
                except:
                    pass
        return bstack1l1l11ll1l1_opy_
    def bstack1l1l11llll1_opy_(self, event: dict, instance=None) -> None:
        global _1l11lll1111_opy_
        levels = [bstack1l1l11_opy_ (u"ࠢࡕࡧࡶࡸࡑ࡫ࡶࡦ࡮ࠥፎ"), bstack1l1l11_opy_ (u"ࠣࡄࡸ࡭ࡱࡪࡌࡦࡸࡨࡰࠧፏ")]
        bstack1l1l1111ll1_opy_ = bstack1l1l11_opy_ (u"ࠤࠥፐ")
        if instance is not None:
            try:
                bstack1l1l1111ll1_opy_ = TestFramework.bstack1lll1llllll_opy_(instance, TestFramework.bstack1llll1l1ll1_opy_)
            except Exception as e:
                self.logger.warning(bstack1l1l11_opy_ (u"ࠥࡉࡷࡸ࡯ࡳࠢࡪࡩࡹࡺࡩ࡯ࡩࠣࡹࡺ࡯ࡤࠡࡨࡵࡳࡲࠦࡩ࡯ࡵࡷࡥࡳࡩࡥࠣፑ").format(e))
        bstack1l11lll1lll_opy_ = []
        try:
            for level in levels:
                platform_index = os.environ[bstack1l1l11_opy_ (u"ࠫࡇࡘࡏࡘࡕࡈࡖࡘ࡚ࡁࡄࡍࡢࡔࡑࡇࡔࡇࡑࡕࡑࡤࡏࡎࡅࡇ࡛ࠫፒ")]
                bstack1l11lll1l1l_opy_ = os.path.join(bstack1l1l11111ll_opy_, (bstack1l1l11lll1l_opy_ + str(platform_index)), level)
                if not os.path.isdir(bstack1l11lll1l1l_opy_):
                    self.logger.debug(bstack1l1l11_opy_ (u"ࠧࡊࡩࡳࡧࡦࡸࡴࡸࡹࠡࡰࡲࡸࠥࡶࡲࡦࡵࡨࡲࡹࠦࡦࡰࡴࠣࡴࡷࡵࡣࡦࡵࡶ࡭ࡳ࡭ࠠࡕࡧࡶࡸࠥࡧ࡮ࡥࠢࡅࡹ࡮ࡲࡤࠡ࡮ࡨࡺࡪࡲࠠࡢࡶࡷࡥࡨ࡮࡭ࡦࡰࡷࡷࠥࢁࡽࠣፓ").format(bstack1l11lll1l1l_opy_))
                    continue
                file_names = os.listdir(bstack1l11lll1l1l_opy_)
                for file_name in file_names:
                    file_path = os.path.join(bstack1l11lll1l1l_opy_, file_name)
                    abs_path = os.path.abspath(file_path)
                    if abs_path in _1l11lll1111_opy_:
                        self.logger.info(bstack1l1l11_opy_ (u"ࠨࡐࡢࡶ࡫ࠤࡦࡲࡲࡦࡣࡧࡽࠥࡶࡲࡰࡥࡨࡷࡸ࡫ࡤࠡࡽࢀࠦፔ").format(abs_path))
                        continue
                    if os.path.isfile(file_path):
                        try:
                            bstack1l11llll11l_opy_ = os.path.getmtime(file_path)
                            timestamp = datetime.fromtimestamp(bstack1l11llll11l_opy_, tz=timezone.utc).isoformat()
                            file_size = os.path.getsize(file_path)
                            if level == bstack1l1l11_opy_ (u"ࠢࡕࡧࡶࡸࡑ࡫ࡶࡦ࡮ࠥፕ"):
                                entry = bstack1lllll111ll_opy_(
                                    kind=bstack1l1l11_opy_ (u"ࠣࡖࡈࡗ࡙ࡥࡁࡕࡖࡄࡇࡍࡓࡅࡏࡖࠥፖ"),
                                    message=bstack1l1l11_opy_ (u"ࠤࠥፗ"),
                                    level=level,
                                    timestamp=timestamp,
                                    fileName=file_name,
                                    bstack1llll1l1lll_opy_=file_size,
                                    bstack1llll11111l_opy_=bstack1l1l11_opy_ (u"ࠥࡑࡆࡔࡕࡂࡎࡢ࡙ࡕࡒࡏࡂࡆࠥፘ"),
                                    bstack1ll11l_opy_=os.path.abspath(file_path),
                                    bstack1l1ll111_opy_=bstack1l1l1111ll1_opy_
                                )
                            elif level == bstack1l1l11_opy_ (u"ࠦࡇࡻࡩ࡭ࡦࡏࡩࡻ࡫࡬ࠣፙ"):
                                entry = bstack1lllll111ll_opy_(
                                    kind=bstack1l1l11_opy_ (u"࡚ࠧࡅࡔࡖࡢࡅ࡙࡚ࡁࡄࡊࡐࡉࡓ࡚ࠢፚ"),
                                    message=bstack1l1l11_opy_ (u"ࠨࠢ፛"),
                                    level=level,
                                    timestamp=timestamp,
                                    fileName=file_name,
                                    bstack1llll1l1lll_opy_=file_size,
                                    bstack1llll11111l_opy_=bstack1l1l11_opy_ (u"ࠢࡎࡃࡑ࡙ࡆࡒ࡟ࡖࡒࡏࡓࡆࡊࠢ፜"),
                                    bstack1ll11l_opy_=os.path.abspath(file_path),
                                    bstack1lll1ll1l1l_opy_=bstack1l1l1111ll1_opy_
                                )
                            bstack1l11lll1lll_opy_.append(entry)
                            _1l11lll1111_opy_.add(abs_path)
                        except Exception as bstack1l1l111l111_opy_:
                            self.logger.error(bstack1l1l11_opy_ (u"ࠣࡇࡻࡧࡪࡶࡴࡪࡱࡱࠤࡷࡧࡩࡴࡧࡧࠤࡼ࡮ࡥ࡯ࠢࡳࡶࡴࡩࡥࡴࡵ࡬ࡲ࡬ࠦࡡࡵࡶࡤࡧ࡭ࡳࡥ࡯ࡶࡶࠤࢀࢃࠢ፝").format(bstack1l1l111l111_opy_))
        except Exception as e:
            self.logger.error(bstack1l1l11_opy_ (u"ࠤࡈࡼࡨ࡫ࡰࡵ࡫ࡲࡲࠥࡸࡡࡪࡵࡨࡨࠥࡽࡨࡦࡰࠣࡴࡷࡵࡣࡦࡵࡶ࡭ࡳ࡭ࠠࡢࡶࡷࡥࡨ࡮࡭ࡦࡰࡷࡷࠥࢁࡽࠣ፞").format(e))
        event[bstack1l1l11_opy_ (u"ࠥࡰࡴ࡭ࡳࠣ፟")] = bstack1l11lll1lll_opy_
class bstack1l1l11111l1_opy_(JSONEncoder):
    def __init__(self, **kwargs):
        self.bstack1l1l11l1l1l_opy_ = set()
        kwargs[bstack1l1l11_opy_ (u"ࠦࡸࡱࡩࡱ࡭ࡨࡽࡸࠨ፠")] = True
        super().__init__(**kwargs)
    def default(self, obj):
        return bstack1l11ll1lll1_opy_(obj, self.bstack1l1l11l1l1l_opy_)
def bstack1l11lllll1l_opy_(obj):
    return isinstance(obj, (str, int, float, bool, type(None)))
def bstack1l11ll1lll1_opy_(obj, bstack1l1l11l1l1l_opy_=None, max_depth=3):
    if bstack1l1l11l1l1l_opy_ is None:
        bstack1l1l11l1l1l_opy_ = set()
    if id(obj) in bstack1l1l11l1l1l_opy_ or max_depth <= 0:
        return None
    max_depth -= 1
    bstack1l1l11l1l1l_opy_.add(id(obj))
    if isinstance(obj, datetime):
        return obj.isoformat()
    bstack1l11lll111l_opy_ = TestFramework.bstack1llll1ll11l_opy_(obj)
    bstack1l1l11ll11l_opy_ = next((k.lower() in bstack1l11lll111l_opy_.lower() for k in bstack1l1l11l1ll1_opy_.keys()), None)
    if bstack1l1l11ll11l_opy_:
        obj = TestFramework.bstack1lllll1llll_opy_(obj, bstack1l1l11l1ll1_opy_[bstack1l1l11ll11l_opy_])
    if not isinstance(obj, dict):
        keys = []
        if hasattr(obj, bstack1l1l11_opy_ (u"ࠧࡥ࡟ࡴ࡮ࡲࡸࡸࡥ࡟ࠣ፡")):
            keys = getattr(obj, bstack1l1l11_opy_ (u"ࠨ࡟ࡠࡵ࡯ࡳࡹࡹ࡟ࡠࠤ።"), [])
        elif hasattr(obj, bstack1l1l11_opy_ (u"ࠢࡠࡡࡧ࡭ࡨࡺ࡟ࡠࠤ፣")):
            keys = getattr(obj, bstack1l1l11_opy_ (u"ࠣࡡࡢࡨ࡮ࡩࡴࡠࡡࠥ፤"), {}).keys()
        else:
            keys = dir(obj)
        obj = {k: getattr(obj, k, None) for k in keys if not str(k).startswith(bstack1l1l11_opy_ (u"ࠤࡢࠦ፥"))}
        if not obj and bstack1l11lll111l_opy_ == bstack1l1l11_opy_ (u"ࠥࡴࡦࡺࡨ࡭࡫ࡥ࠲ࡕࡵࡳࡪࡺࡓࡥࡹ࡮ࠢ፦"):
            obj = {bstack1l1l11_opy_ (u"ࠦࡵࡧࡴࡩࠤ፧"): str(obj)}
    result = {}
    for key, value in obj.items():
        if not bstack1l11lllll1l_opy_(key) or str(key).startswith(bstack1l1l11_opy_ (u"ࠧࡥࠢ፨")):
            continue
        if value is not None and bstack1l11lllll1l_opy_(value):
            result[key] = value
        elif isinstance(value, dict):
            r = bstack1l11ll1lll1_opy_(value, bstack1l1l11l1l1l_opy_, max_depth)
            if r is not None:
                result[key] = r
        elif isinstance(value, (list, tuple, set, frozenset)):
            result[key] = list(filter(None, [bstack1l11ll1lll1_opy_(o, bstack1l1l11l1l1l_opy_, max_depth) for o in value]))
    return result or None