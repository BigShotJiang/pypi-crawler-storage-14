# coding: UTF-8
import sys
bstack1l11111_opy_ = sys.version_info [0] == 2
bstack11l11ll_opy_ = 2048
bstack111ll1l_opy_ = 7
def bstack1l1l11_opy_ (bstack11l1l_opy_):
    global bstack1l11_opy_
    bstack11l1111_opy_ = ord (bstack11l1l_opy_ [-1])
    bstack1l1ll1l_opy_ = bstack11l1l_opy_ [:-1]
    bstack11l11_opy_ = bstack11l1111_opy_ % len (bstack1l1ll1l_opy_)
    bstack1l1ll11_opy_ = bstack1l1ll1l_opy_ [:bstack11l11_opy_] + bstack1l1ll1l_opy_ [bstack11l11_opy_:]
    if bstack1l11111_opy_:
        bstack11lll1l_opy_ = unicode () .join ([unichr (ord (char) - bstack11l11ll_opy_ - (bstack11l111_opy_ + bstack11l1111_opy_) % bstack111ll1l_opy_) for bstack11l111_opy_, char in enumerate (bstack1l1ll11_opy_)])
    else:
        bstack11lll1l_opy_ = str () .join ([chr (ord (char) - bstack11l11ll_opy_ - (bstack11l111_opy_ + bstack11l1111_opy_) % bstack111ll1l_opy_) for bstack11l111_opy_, char in enumerate (bstack1l1ll11_opy_)])
    return eval (bstack11lll1l_opy_)
import os
import threading
import os
from typing import Dict, Any
from dataclasses import dataclass
from collections import defaultdict
from datetime import timedelta
@dataclass
class bstack1llll1l1l1l_opy_:
    id: str
    hash: str
    thread_id: int
    process_id: int
    type: str
class bstack1llll11l111_opy_:
    bstack1lll1l11ll1_opy_ = bstack1l1l11_opy_ (u"ࠥࡦࡪࡴࡣࡩ࡯ࡤࡶࡰࠨᄌ")
    context: bstack1llll1l1l1l_opy_
    data: Dict[str, Any]
    platform_index: int
    def __init__(self, context: bstack1llll1l1l1l_opy_):
        self.context = context
        self.data = dict({bstack1llll11l111_opy_.bstack1lll1l11ll1_opy_: defaultdict(lambda: timedelta(microseconds=0))})
        self.platform_index = int(os.environ.get(bstack1l1l11_opy_ (u"ࠫࡇࡘࡏࡘࡕࡈࡖࡘ࡚ࡁࡄࡍࡢࡔࡑࡇࡔࡇࡑࡕࡑࡤࡏࡎࡅࡇ࡛ࠫᄍ"), bstack1l1l11_opy_ (u"ࠬ࠶ࠧᄎ")))
    def ref(self) -> str:
        return str(self.context.id)
    def bstack1lll1ll1ll1_opy_(self, target: object):
        return bstack1llll11l111_opy_.create_context(target) == self.context
    def bstack1lll1l11l1l_opy_(self, context: bstack1llll1l1l1l_opy_):
        return context and context.thread_id == self.context.thread_id and context.process_id == self.context.process_id
    def bstack1lllll111_opy_(self, key: str, value: timedelta):
        self.data[bstack1llll11l111_opy_.bstack1lll1l11ll1_opy_][key] += value
    def bstack1lll1l11lll_opy_(self) -> dict:
        return self.data[bstack1llll11l111_opy_.bstack1lll1l11ll1_opy_]
    @staticmethod
    def create_context(
        target: object,
        thread_id=threading.get_ident(),
        process_id=os.getpid(),
    ):
        return bstack1llll1l1l1l_opy_(
            id=hash(target),
            hash=hash(target),
            thread_id=thread_id,
            process_id=process_id,
            type=target,
        )