# coding: UTF-8
import sys
bstack1l11111_opy_ = sys.version_info [0] == 2
bstack11l11ll_opy_ = 2048
bstack111ll1l_opy_ = 7
def bstack1l1l11_opy_ (bstack11l1l_opy_):
    global bstack1l11_opy_
    bstack11l1111_opy_ = ord (bstack11l1l_opy_ [-1])
    bstack1l1ll1l_opy_ = bstack11l1l_opy_ [:-1]
    bstack11l11_opy_ = bstack11l1111_opy_ % len (bstack1l1ll1l_opy_)
    bstack1l1ll11_opy_ = bstack1l1ll1l_opy_ [:bstack11l11_opy_] + bstack1l1ll1l_opy_ [bstack11l11_opy_:]
    if bstack1l11111_opy_:
        bstack11lll1l_opy_ = unicode () .join ([unichr (ord (char) - bstack11l11ll_opy_ - (bstack11l111_opy_ + bstack11l1111_opy_) % bstack111ll1l_opy_) for bstack11l111_opy_, char in enumerate (bstack1l1ll11_opy_)])
    else:
        bstack11lll1l_opy_ = str () .join ([chr (ord (char) - bstack11l11ll_opy_ - (bstack11l111_opy_ + bstack11l1111_opy_) % bstack111ll1l_opy_) for bstack11l111_opy_, char in enumerate (bstack1l1ll11_opy_)])
    return eval (bstack11lll1l_opy_)
from browserstack_sdk.sdk_cli.bstack1ll11l111l1_opy_ import bstack1ll1l1lllll_opy_
from browserstack_sdk.sdk_cli.bstack1lll111ll11_opy_ import (
    bstack1lll111l1ll_opy_,
    bstack1lll1111l11_opy_,
    bstack1lll11lll11_opy_,
    bstack1lll111l111_opy_,
)
from browserstack_sdk.sdk_cli.bstack1ll111l1111_opy_ import bstack1ll1llll11l_opy_
from browserstack_sdk.sdk_cli.bstack1ll1ll1llll_opy_ import bstack1ll111ll111_opy_
from browserstack_sdk.sdk_cli.bstack1llll1l111l_opy_ import bstack1llll1l1l1l_opy_
from typing import Tuple, Dict, Any, List, Callable
from browserstack_sdk.sdk_cli.bstack1ll11l111l1_opy_ import bstack1ll1l1lllll_opy_
import weakref
class bstack1l1l1l1ll1l_opy_(bstack1ll1l1lllll_opy_):
    bstack1l1l1l1l1ll_opy_: str
    frameworks: List[str]
    drivers: Dict[str, Tuple[Callable, bstack1lll111l111_opy_]]
    pages: Dict[str, Tuple[Callable, bstack1lll111l111_opy_]]
    def __init__(self, bstack1l1l1l1l1ll_opy_: str, frameworks: List[str]):
        super().__init__()
        self.drivers = dict()
        self.pages = dict()
        self.bstack1l1l1l1ll11_opy_ = dict()
        self.bstack1l1l1l1l1ll_opy_ = bstack1l1l1l1l1ll_opy_
        self.frameworks = frameworks
        bstack1ll111ll111_opy_.bstack1llll1lll1l_opy_((bstack1lll111l1ll_opy_.bstack1lll111111l_opy_, bstack1lll1111l11_opy_.POST), self.__1l1l1l1l111_opy_)
        if any(bstack1ll1llll11l_opy_.NAME in f.lower().strip() for f in frameworks):
            bstack1ll1llll11l_opy_.bstack1llll1lll1l_opy_(
                (bstack1lll111l1ll_opy_.bstack1lll11l1l1l_opy_, bstack1lll1111l11_opy_.PRE), self.__1l1l1l11l1l_opy_
            )
            bstack1ll1llll11l_opy_.bstack1llll1lll1l_opy_(
                (bstack1lll111l1ll_opy_.QUIT, bstack1lll1111l11_opy_.POST), self.__1l1l1l11lll_opy_
            )
    def __1l1l1l1l111_opy_(
        self,
        f: bstack1ll111ll111_opy_,
        bstack1l1l1l1l1l1_opy_: object,
        exec: Tuple[bstack1lll111l111_opy_, str],
        bstack1llll1111ll_opy_: Tuple[bstack1lll111l1ll_opy_, bstack1lll1111l11_opy_],
        result: Any,
        *args,
        **kwargs,
    ):
        try:
            instance, method_name = exec
            if method_name != bstack1l1l11_opy_ (u"ࠤࡱࡩࡼࡥࡰࡢࡩࡨࠦዙ"):
                return
            contexts = bstack1l1l1l1l1l1_opy_.browser.contexts
            if contexts:
                for context in contexts:
                    if context.pages:
                        for page in context.pages:
                            if bstack1l1l11_opy_ (u"ࠥࡥࡧࡵࡵࡵ࠼ࡥࡰࡦࡴ࡫ࠣዚ") in page.url:
                                self.logger.debug(bstack1l1l11_opy_ (u"ࠦࡘࡺ࡯ࡳ࡫ࡱ࡫ࠥࡺࡨࡦࠢࡱࡩࡼࠦࡰࡢࡩࡨࠤ࡮ࡴࡳࡵࡣࡱࡧࡪࠨዛ"))
                                self.pages[instance.ref()] = weakref.ref(page), instance
                                bstack1lll11lll11_opy_.bstack1lllll1l11l_opy_(instance, self.bstack1l1l1l1l1ll_opy_, True)
                                self.logger.debug(bstack1l1l11_opy_ (u"ࠧࡥ࡟ࡰࡰࡢࡴࡦ࡭ࡥࡠ࡫ࡱ࡭ࡹࡀࠠࡪࡰࡶࡸࡦࡴࡣࡦ࠿ࠥዜ") + str(instance.ref()) + bstack1l1l11_opy_ (u"ࠨࠢዝ"))
        except Exception as e:
            self.logger.debug(bstack1l1l11_opy_ (u"ࠢࡆࡺࡦࡩࡵࡺࡩࡰࡰࠣ࡭ࡳࠦࡳࡵࡱࡵ࡭ࡳ࡭ࠠ࡯ࡧࡺࠤࡵࡧࡧࡦࠢ࠽ࠦዞ"),e)
    def __1l1l1l11l1l_opy_(
        self,
        f: bstack1ll1llll11l_opy_,
        driver: object,
        exec: Tuple[bstack1lll111l111_opy_, str],
        bstack1llll1111ll_opy_: Tuple[bstack1lll111l1ll_opy_, bstack1lll1111l11_opy_],
        result: Any,
        *args,
        **kwargs,
    ):
        instance, _ = exec
        if instance.ref() in self.drivers or bstack1lll11lll11_opy_.bstack1lll1llllll_opy_(instance, self.bstack1l1l1l1l1ll_opy_, False):
            return
        if not f.bstack1l1l1lll1ll_opy_(f.hub_url(driver)):
            self.bstack1l1l1l1ll11_opy_[instance.ref()] = weakref.ref(driver), instance
            bstack1lll11lll11_opy_.bstack1lllll1l11l_opy_(instance, self.bstack1l1l1l1l1ll_opy_, True)
            self.logger.debug(bstack1l1l11_opy_ (u"ࠣࡡࡢࡳࡳࡥࡳࡦ࡮ࡨࡲ࡮ࡻ࡭ࡠ࡫ࡱ࡭ࡹࡀࠠ࡯ࡱࡱࡣࡧࡸ࡯ࡸࡵࡨࡶࡸࡺࡡࡤ࡭ࡢࡨࡷ࡯ࡶࡦࡴࠣ࡭ࡳࡹࡴࡢࡰࡦࡩࡂࠨዟ") + str(instance.ref()) + bstack1l1l11_opy_ (u"ࠤࠥዠ"))
            return
        self.drivers[instance.ref()] = weakref.ref(driver), instance
        bstack1lll11lll11_opy_.bstack1lllll1l11l_opy_(instance, self.bstack1l1l1l1l1ll_opy_, True)
        self.logger.debug(bstack1l1l11_opy_ (u"ࠥࡣࡤࡵ࡮ࡠࡵࡨࡰࡪࡴࡩࡶ࡯ࡢ࡭ࡳ࡯ࡴ࠻ࠢ࡬ࡲࡸࡺࡡ࡯ࡥࡨࡁࠧዡ") + str(instance.ref()) + bstack1l1l11_opy_ (u"ࠦࠧዢ"))
    def __1l1l1l11lll_opy_(
        self,
        f: bstack1ll1llll11l_opy_,
        driver: object,
        exec: Tuple[bstack1lll111l111_opy_, str],
        bstack1llll1111ll_opy_: Tuple[bstack1lll111l1ll_opy_, bstack1lll1111l11_opy_],
        result: Any,
        *args,
        **kwargs,
    ):
        instance, _ = exec
        if not instance.ref() in self.drivers:
            return
        self.bstack1l1l1l1llll_opy_(instance)
        self.logger.debug(bstack1l1l11_opy_ (u"ࠧࡥ࡟ࡰࡰࡢࡷࡪࡲࡥ࡯࡫ࡸࡱࡤࡷࡵࡪࡶ࠽ࠤ࡮ࡴࡳࡵࡣࡱࡧࡪࡃࠢዣ") + str(instance.ref()) + bstack1l1l11_opy_ (u"ࠨࠢዤ"))
    def bstack1l1l1ll111l_opy_(self, context: bstack1llll1l1l1l_opy_, reverse=True) -> List[Tuple[Callable, bstack1lll111l111_opy_]]:
        matches = []
        if self.pages:
            for data in self.pages.values():
                if data[1].bstack1lll1l11l1l_opy_(context):
                    matches.append(data)
        if self.drivers:
            for data in self.drivers.values():
                if (
                    bstack1ll1llll11l_opy_.bstack1l1l1l1lll1_opy_(data[1])
                    and data[1].bstack1lll1l11l1l_opy_(context)
                    and getattr(data[0](), bstack1l1l11_opy_ (u"ࠢࡴࡧࡶࡷ࡮ࡵ࡮ࡠ࡫ࡧࠦዥ"), False)
                ):
                    matches.append(data)
        return sorted(matches, key=lambda d: d[1].bstack1llll1l11ll_opy_, reverse=reverse)
    def bstack1l1l1l11ll1_opy_(self, context: bstack1llll1l1l1l_opy_, reverse=True) -> List[Tuple[Callable, bstack1lll111l111_opy_]]:
        matches = []
        for data in self.bstack1l1l1l1ll11_opy_.values():
            if (
                data[1].bstack1lll1l11l1l_opy_(context)
                and getattr(data[0](), bstack1l1l11_opy_ (u"ࠣࡵࡨࡷࡸ࡯࡯࡯ࡡ࡬ࡨࠧዦ"), False)
            ):
                matches.append(data)
        return sorted(matches, key=lambda d: d[1].bstack1llll1l11ll_opy_, reverse=reverse)
    def bstack1l1l1ll1111_opy_(self, instance: bstack1lll111l111_opy_) -> bool:
        return instance and instance.ref() in self.drivers
    def bstack1l1l1l1llll_opy_(self, instance: bstack1lll111l111_opy_) -> bool:
        if self.bstack1l1l1ll1111_opy_(instance):
            self.drivers.pop(instance.ref())
            bstack1lll11lll11_opy_.bstack1lllll1l11l_opy_(instance, self.bstack1l1l1l1l1ll_opy_, False)
            return True
        return False