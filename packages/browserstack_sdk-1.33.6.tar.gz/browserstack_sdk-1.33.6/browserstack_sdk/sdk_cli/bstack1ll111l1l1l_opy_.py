# coding: UTF-8
import sys
bstack1l11111_opy_ = sys.version_info [0] == 2
bstack11l11ll_opy_ = 2048
bstack111ll1l_opy_ = 7
def bstack1l1l11_opy_ (bstack11l1l_opy_):
    global bstack1l11_opy_
    bstack11l1111_opy_ = ord (bstack11l1l_opy_ [-1])
    bstack1l1ll1l_opy_ = bstack11l1l_opy_ [:-1]
    bstack11l11_opy_ = bstack11l1111_opy_ % len (bstack1l1ll1l_opy_)
    bstack1l1ll11_opy_ = bstack1l1ll1l_opy_ [:bstack11l11_opy_] + bstack1l1ll1l_opy_ [bstack11l11_opy_:]
    if bstack1l11111_opy_:
        bstack11lll1l_opy_ = unicode () .join ([unichr (ord (char) - bstack11l11ll_opy_ - (bstack11l111_opy_ + bstack11l1111_opy_) % bstack111ll1l_opy_) for bstack11l111_opy_, char in enumerate (bstack1l1ll11_opy_)])
    else:
        bstack11lll1l_opy_ = str () .join ([chr (ord (char) - bstack11l11ll_opy_ - (bstack11l111_opy_ + bstack11l1111_opy_) % bstack111ll1l_opy_) for bstack11l111_opy_, char in enumerate (bstack1l1ll11_opy_)])
    return eval (bstack11lll1l_opy_)
import json
import os
import grpc
from browserstack_sdk import sdk_pb2 as structs
from packaging import version
import traceback
from browserstack_sdk.sdk_cli.bstack1ll11l111l1_opy_ import bstack1ll1l1lllll_opy_
from browserstack_sdk.sdk_cli.bstack1lll111ll11_opy_ import (
    bstack1lll111l1ll_opy_,
    bstack1lll1111l11_opy_,
    bstack1lll111l111_opy_,
)
from browserstack_sdk.sdk_cli.bstack1ll111l1111_opy_ import bstack1ll1llll11l_opy_
from datetime import datetime
from typing import Tuple, Any
from bstack_utils.messages import bstack1111l1l1_opy_
from bstack_utils.measure import measure
from bstack_utils.constants import *
import threading
import os
from bstack_utils.bstack1111ll1l1_opy_ import bstack1ll111l1ll1_opy_
class bstack1ll1lll1l11_opy_(bstack1ll1l1lllll_opy_):
    bstack1l111l1l111_opy_ = bstack1l1l11_opy_ (u"ࠤࡵࡩ࡬࡯ࡳࡵࡧࡵࡣ࡮ࡴࡩࡵࠤᏸ")
    bstack1l111l11l1l_opy_ = bstack1l1l11_opy_ (u"ࠥࡶࡪ࡭ࡩࡴࡶࡨࡶࡤࡹࡴࡢࡴࡷࠦᏹ")
    bstack1l111l111ll_opy_ = bstack1l1l11_opy_ (u"ࠦࡷ࡫ࡧࡪࡵࡷࡩࡷࡥࡳࡵࡱࡳࠦᏺ")
    def __init__(self, bstack1ll1111ll11_opy_):
        super().__init__()
        bstack1ll1llll11l_opy_.bstack1llll1lll1l_opy_((bstack1lll111l1ll_opy_.bstack1lll111111l_opy_, bstack1lll1111l11_opy_.PRE), self.bstack1l111ll1l11_opy_)
        bstack1ll1llll11l_opy_.bstack1llll1lll1l_opy_((bstack1lll111l1ll_opy_.bstack1lll11l1l1l_opy_, bstack1lll1111l11_opy_.PRE), self.bstack1l1l1ll1ll1_opy_)
        bstack1ll1llll11l_opy_.bstack1llll1lll1l_opy_((bstack1lll111l1ll_opy_.bstack1lll11l1l1l_opy_, bstack1lll1111l11_opy_.POST), self.bstack1l111l11lll_opy_)
        bstack1ll1llll11l_opy_.bstack1llll1lll1l_opy_((bstack1lll111l1ll_opy_.bstack1lll11l1l1l_opy_, bstack1lll1111l11_opy_.POST), self.bstack1l111l1lll1_opy_)
        bstack1ll1llll11l_opy_.bstack1llll1lll1l_opy_((bstack1lll111l1ll_opy_.QUIT, bstack1lll1111l11_opy_.POST), self.bstack1l111llll1l_opy_)
    def is_enabled(self) -> bool:
        return True
    def bstack1l111ll1l11_opy_(
        self,
        f: bstack1ll1llll11l_opy_,
        driver: object,
        exec: Tuple[bstack1lll111l111_opy_, str],
        bstack1llll1111ll_opy_: Tuple[bstack1lll111l1ll_opy_, bstack1lll1111l11_opy_],
        result: Any,
        *args,
        **kwargs,
    ):
        instance, method_name = exec
        if method_name != bstack1l1l11_opy_ (u"ࠧࡥ࡟ࡪࡰ࡬ࡸࡤࡥࠢᏻ"):
            return
        def wrapped(driver, init, *args, **kwargs):
            url = None
            try:
                if isinstance(kwargs.get(bstack1l1l11_opy_ (u"ࠨࡣࡰ࡯ࡰࡥࡳࡪ࡟ࡦࡺࡨࡧࡺࡺ࡯ࡳࠤᏼ")), str):
                    url = kwargs.get(bstack1l1l11_opy_ (u"ࠢࡤࡱࡰࡱࡦࡴࡤࡠࡧࡻࡩࡨࡻࡴࡰࡴࠥᏽ"))
                elif hasattr(kwargs.get(bstack1l1l11_opy_ (u"ࠣࡥࡲࡱࡲࡧ࡮ࡥࡡࡨࡼࡪࡩࡵࡵࡱࡵࠦ᏾")), bstack1l1l11_opy_ (u"ࠩࡢࡧࡱ࡯ࡥ࡯ࡶࡢࡧࡴࡴࡦࡪࡩࠪ᏿")):
                    url = kwargs.get(bstack1l1l11_opy_ (u"ࠥࡧࡴࡳ࡭ࡢࡰࡧࡣࡪࡾࡥࡤࡷࡷࡳࡷࠨ᐀"))._client_config.remote_server_addr
                else:
                    url = kwargs.get(bstack1l1l11_opy_ (u"ࠦࡨࡵ࡭࡮ࡣࡱࡨࡤ࡫ࡸࡦࡥࡸࡸࡴࡸࠢᐁ"))._url
            except Exception as e:
                url = bstack1l1l11_opy_ (u"ࠬ࠭ᐂ")
                self.logger.error(bstack1l1l11_opy_ (u"ࠨࡅࡳࡴࡲࡶࠥࡽࡨࡪ࡮ࡨࠤ࡬࡫ࡴࡵ࡫ࡱ࡫ࠥࡻࡲ࡭ࠢࡩࡶࡴࡳࠠࡥࡴ࡬ࡺࡪࡸ࠺ࠡࡽࢀࠦᐃ").format(e))
            self.logger.info(bstack1l1l11_opy_ (u"ࠢࡓࡧࡰࡳࡹ࡫ࠠࡔࡧࡵࡺࡪࡸࠠࡂࡦࡧࡶࡪࡹࡳࠡࡤࡨ࡭ࡳ࡭ࠠࡱࡣࡶࡷࡪࡪࠠࡢࡵࠣ࠾ࠥࢁࡽࠣᐄ").format(str(url)))
            self.bstack1l111l11ll1_opy_(instance, url, f, kwargs)
            self.logger.info(bstack1l1l11_opy_ (u"ࠣࡦࡵ࡭ࡻ࡫ࡲ࠯ࡽࡰࡩࡹ࡮࡯ࡥࡡࡱࡥࡲ࡫ࡽࠡࡲ࡯ࡥࡹ࡬࡯ࡳ࡯ࡢ࡭ࡳࡪࡥࡹ࠿ࡾࡴࡱࡧࡴࡧࡱࡵࡱࡤ࡯࡮ࡥࡧࡻࢁ࠿ࠦࡡࡳࡩࡶࡁࢀࡧࡲࡨࡵࢀࠤࡰࡽࡡࡳࡩࡶࡁࢀࡱࡷࡢࡴࡪࡷࢂࠨᐅ").format(method_name=method_name, platform_index=f.platform_index, args=args, kwargs=kwargs))
            threading.current_thread().bstackSessionDriver = driver
            return init(driver, *args, **kwargs)
        return wrapped
    def bstack1l1l1ll1ll1_opy_(
        self,
        f: bstack1ll1llll11l_opy_,
        driver: object,
        exec: Tuple[bstack1lll111l111_opy_, str],
        bstack1llll1111ll_opy_: Tuple[bstack1lll111l1ll_opy_, bstack1lll1111l11_opy_],
        result: Any,
        *args,
        **kwargs,
    ):
        instance, method_name = exec
        if f.bstack1lll1llllll_opy_(instance, bstack1ll1lll1l11_opy_.bstack1l111l1l111_opy_, False):
            return
        if not f.bstack1lllll1l1ll_opy_(instance, bstack1ll1llll11l_opy_.bstack1llll11ll1l_opy_):
            return
        platform_index = f.bstack1lll1llllll_opy_(instance, bstack1ll1llll11l_opy_.bstack1llll11ll1l_opy_)
        if f.bstack1l1llll1lll_opy_(method_name, *args) and len(args) > 1:
            bstack11l1l1ll1_opy_ = datetime.now()
            hub_url = bstack1ll1llll11l_opy_.hub_url(driver)
            self.logger.warning(bstack1l1l11_opy_ (u"ࠤ࡫ࡹࡧࡥࡵࡳ࡮ࡀࠦᐆ") + str(hub_url) + bstack1l1l11_opy_ (u"ࠥࠦᐇ"))
            bstack1l111l1l11l_opy_ = args[1][bstack1l1l11_opy_ (u"ࠦࡨࡧࡰࡢࡤ࡬ࡰ࡮ࡺࡩࡦࡵࠥᐈ")] if isinstance(args[1], dict) and bstack1l1l11_opy_ (u"ࠧࡩࡡࡱࡣࡥ࡭ࡱ࡯ࡴࡪࡧࡶࠦᐉ") in args[1] else None
            bstack1l111lllll1_opy_ = bstack1l1l11_opy_ (u"ࠨࡡ࡭ࡹࡤࡽࡸࡓࡡࡵࡥ࡫ࠦᐊ")
            if isinstance(bstack1l111l1l11l_opy_, dict):
                bstack11l1l1ll1_opy_ = datetime.now()
                r = self.bstack1l111l1ll11_opy_(
                    instance.ref(),
                    platform_index,
                    f.framework_name,
                    f.framework_version,
                    hub_url
                )
                instance.bstack1lllll111_opy_(bstack1l1l11_opy_ (u"ࠢࡨࡴࡳࡧ࠿ࡸࡥࡨ࡫ࡶࡸࡪࡸ࡟ࡪࡰ࡬ࡸࠧᐋ"), datetime.now() - bstack11l1l1ll1_opy_)
                try:
                    if not r.success:
                        self.logger.info(bstack1l1l11_opy_ (u"ࠣࡵࡲࡱࡪࡺࡨࡪࡰࡪࠤࡼ࡫࡮ࡵࠢࡺࡶࡴࡴࡧ࠻ࠢࠥᐌ") + str(r) + bstack1l1l11_opy_ (u"ࠤࠥᐍ"))
                        return
                    if r.hub_url:
                        f.bstack1l111ll1111_opy_(instance, driver, r.hub_url)
                        f.bstack1lllll1l11l_opy_(instance, bstack1ll1lll1l11_opy_.bstack1l111l1l111_opy_, True)
                except Exception as e:
                    self.logger.error(bstack1l1l11_opy_ (u"ࠥࡩࡷࡸ࡯ࡳࠤᐎ"), e)
    def bstack1l111l11lll_opy_(
        self,
        f: bstack1ll1llll11l_opy_,
        driver: object,
        exec: Tuple[bstack1lll111l111_opy_, str],
        bstack1llll1111ll_opy_: Tuple[bstack1lll111l1ll_opy_, bstack1lll1111l11_opy_],
        result: Any,
        *args,
        **kwargs,
    ):
            session_id = bstack1ll1llll11l_opy_.session_id(driver)
            if session_id:
                bstack1l111llll11_opy_ = bstack1l1l11_opy_ (u"ࠦࢀࢃ࠺ࡴࡶࡤࡶࡹࠨᐏ").format(session_id)
                bstack1ll111l1ll1_opy_.mark(bstack1l111llll11_opy_)
    def bstack1l111l1lll1_opy_(
        self,
        f: bstack1ll1llll11l_opy_,
        driver: object,
        exec: Tuple[bstack1lll111l111_opy_, str],
        bstack1llll1111ll_opy_: Tuple[bstack1lll111l1ll_opy_, bstack1lll1111l11_opy_],
        result: Any,
        *args,
        **kwargs,
    ):
        instance = exec[0]
        if f.bstack1lll1llllll_opy_(instance, bstack1ll1lll1l11_opy_.bstack1l111l11l1l_opy_, False):
            return
        ref = instance.ref()
        hub_url = bstack1ll1llll11l_opy_.hub_url(driver)
        if not hub_url:
            self.logger.warning(bstack1l1l11_opy_ (u"ࠧ࡬ࡡࡪ࡮ࡨࡨࠥࡺ࡯ࠡࡲࡤࡶࡸ࡫ࠠࡩࡷࡥࡣࡺࡸ࡬࠾ࠤᐐ") + str(hub_url) + bstack1l1l11_opy_ (u"ࠨࠢᐑ"))
            return
        framework_session_id = bstack1ll1llll11l_opy_.session_id(driver)
        if not framework_session_id:
            self.logger.warning(bstack1l1l11_opy_ (u"ࠢࡧࡣ࡬ࡰࡪࡪࠠࡵࡱࠣࡴࡦࡸࡳࡦࠢࡩࡶࡦࡳࡥࡸࡱࡵ࡯ࡤࡹࡥࡴࡵ࡬ࡳࡳࡥࡩࡥ࠿ࠥᐒ") + str(framework_session_id) + bstack1l1l11_opy_ (u"ࠣࠤᐓ"))
            return
        if bstack1ll1llll11l_opy_.bstack1l111lll11l_opy_(*args) == bstack1ll1llll11l_opy_.bstack1l111l1ll1l_opy_:
            bstack1l111ll11ll_opy_ = bstack1l1l11_opy_ (u"ࠤࡾࢁ࠿࡫࡮ࡥࠤᐔ").format(framework_session_id)
            bstack1l111llll11_opy_ = bstack1l1l11_opy_ (u"ࠥࡿࢂࡀࡳࡵࡣࡵࡸࠧᐕ").format(framework_session_id)
            bstack1ll111l1ll1_opy_.end(
                label=bstack1l1l11_opy_ (u"ࠦࡸࡪ࡫࠻ࡦࡵ࡭ࡻ࡫ࡲ࠻ࡲࡲࡷࡹ࠳ࡩ࡯࡫ࡷ࡭ࡦࡲࡩࡻࡣࡷ࡭ࡴࡴࠢᐖ"),
                start=bstack1l111llll11_opy_,
                end=bstack1l111ll11ll_opy_,
                status=True,
                failure=None
            )
            bstack11l1l1ll1_opy_ = datetime.now()
            r = self.bstack1l111ll11l1_opy_(
                ref,
                f.bstack1lll1llllll_opy_(instance, bstack1ll1llll11l_opy_.bstack1llll11ll1l_opy_, 0),
                f.framework_name,
                f.framework_version,
                framework_session_id,
                hub_url,
            )
            instance.bstack1lllll111_opy_(bstack1l1l11_opy_ (u"ࠧ࡭ࡲࡱࡥ࠽ࡶࡪ࡭ࡩࡴࡶࡨࡶࡤࡹࡴࡢࡴࡷࠦᐗ"), datetime.now() - bstack11l1l1ll1_opy_)
            f.bstack1lllll1l11l_opy_(instance, bstack1ll1lll1l11_opy_.bstack1l111l11l1l_opy_, r.success)
    def bstack1l111llll1l_opy_(
        self,
        f: bstack1ll1llll11l_opy_,
        driver: object,
        exec: Tuple[bstack1lll111l111_opy_, str],
        bstack1llll1111ll_opy_: Tuple[bstack1lll111l1ll_opy_, bstack1lll1111l11_opy_],
        result: Any,
        *args,
        **kwargs,
    ):
        instance = exec[0]
        if f.bstack1lll1llllll_opy_(instance, bstack1ll1lll1l11_opy_.bstack1l111l111ll_opy_, False):
            return
        ref = instance.ref()
        framework_session_id = bstack1ll1llll11l_opy_.session_id(driver)
        hub_url = bstack1ll1llll11l_opy_.hub_url(driver)
        bstack11l1l1ll1_opy_ = datetime.now()
        r = self.bstack1l111ll1lll_opy_(
            ref,
            f.bstack1lll1llllll_opy_(instance, bstack1ll1llll11l_opy_.bstack1llll11ll1l_opy_, 0),
            f.framework_name,
            f.framework_version,
            framework_session_id,
            hub_url,
        )
        instance.bstack1lllll111_opy_(bstack1l1l11_opy_ (u"ࠨࡧࡳࡲࡦ࠾ࡷ࡫ࡧࡪࡵࡷࡩࡷࡥࡳࡵࡱࡳࠦᐘ"), datetime.now() - bstack11l1l1ll1_opy_)
        f.bstack1lllll1l11l_opy_(instance, bstack1ll1lll1l11_opy_.bstack1l111l111ll_opy_, r.success)
    @measure(event_name=EVENTS.bstack111l1111_opy_, stage=STAGE.bstack111llllll_opy_)
    def bstack1l11l1ll1l1_opy_(self, platform_index: int, url: str, ref, user_input_params: bytes):
        req = structs.DriverInitRequest()
        req.bin_session_id = self.bin_session_id
        req.platform_index = platform_index
        req.user_input_params = user_input_params
        req.ref = ref
        req.hub_url = url
        self.logger.debug(bstack1l1l11_opy_ (u"ࠢࡳࡧࡪ࡭ࡸࡺࡥࡳࡡࡺࡩࡧࡪࡲࡪࡸࡨࡶࡤ࡯࡮ࡪࡶ࠽ࠤࠧᐙ") + str(req) + bstack1l1l11_opy_ (u"ࠣࠤᐚ"))
        try:
            r = self.bstack1ll1ll1l111_opy_.DriverInit(req)
            if not r.success:
                self.logger.debug(bstack1l1l11_opy_ (u"ࠤࡵࡩࡨ࡫ࡩࡷࡧࡧࠤ࡫ࡸ࡯࡮ࠢࡶࡩࡷࡼࡥࡳ࠼ࠣࡷࡺࡩࡣࡦࡵࡶࡁࠧᐛ") + str(r.success) + bstack1l1l11_opy_ (u"ࠥࠦᐜ"))
            return r
        except grpc.RpcError as e:
            self.logger.error(bstack1l1l11_opy_ (u"ࠦࡷࡶࡣ࠮ࡧࡵࡶࡴࡸ࠺ࠡࠤᐝ") + str(e) + bstack1l1l11_opy_ (u"ࠧࠨᐞ"))
            traceback.print_exc()
            raise e
    @measure(event_name=EVENTS.bstack1l111ll1l1l_opy_, stage=STAGE.bstack111llllll_opy_)
    def bstack1l111l1ll11_opy_(
        self,
        ref: str,
        platform_index: int,
        framework_name: str,
        framework_version: str,
        hub_url: str
    ):
        self.bstack1l1ll11l111_opy_()
        req = structs.AutomationFrameworkInitRequest()
        req.ref = ref
        req.bin_session_id = self.bin_session_id
        req.platform_index = platform_index
        req.framework_name = framework_name
        req.framework_version = framework_version
        req.hub_url = hub_url
        self.logger.debug(bstack1l1l11_opy_ (u"ࠨࡲࡦࡩ࡬ࡷࡹ࡫ࡲࡠ࡫ࡱ࡭ࡹࡀࠠࠣᐟ") + str(req) + bstack1l1l11_opy_ (u"ࠢࠣᐠ"))
        try:
            r = self.bstack1ll1ll1l111_opy_.AutomationFrameworkInit(req)
            if not r.success:
                self.logger.debug(bstack1l1l11_opy_ (u"ࠣࡴࡨࡧࡪ࡯ࡶࡦࡦࠣࡪࡷࡵ࡭ࠡࡵࡨࡶࡻ࡫ࡲ࠻ࠢࡶࡹࡨࡩࡥࡴࡵࡀࠦᐡ") + str(r.success) + bstack1l1l11_opy_ (u"ࠤࠥᐢ"))
            return r
        except grpc.RpcError as e:
            self.logger.error(bstack1l1l11_opy_ (u"ࠥࡶࡵࡩ࠭ࡦࡴࡵࡳࡷࡀࠠࠣᐣ") + str(e) + bstack1l1l11_opy_ (u"ࠦࠧᐤ"))
            traceback.print_exc()
            raise e
    @measure(event_name=EVENTS.bstack1l111lll1ll_opy_, stage=STAGE.bstack111llllll_opy_)
    def bstack1l111ll11l1_opy_(
        self,
        ref: str,
        platform_index: int,
        framework_name: str,
        framework_version: str,
        framework_session_id: str,
        hub_url: str,
    ):
        self.bstack1l1ll11l111_opy_()
        req = structs.AutomationFrameworkStartRequest()
        req.ref = ref
        req.bin_session_id = self.bin_session_id
        req.platform_index = platform_index
        req.framework_name = framework_name
        req.framework_version = framework_version
        req.framework_session_id = framework_session_id
        req.hub_url = hub_url
        self.logger.debug(bstack1l1l11_opy_ (u"ࠧࡸࡥࡨ࡫ࡶࡸࡪࡸ࡟ࡴࡶࡤࡶࡹࡀࠠࠣᐥ") + str(req) + bstack1l1l11_opy_ (u"ࠨࠢᐦ"))
        try:
            r = self.bstack1ll1ll1l111_opy_.AutomationFrameworkStart(req)
            if not r.success:
                self.logger.debug(bstack1l1l11_opy_ (u"ࠢࡳࡧࡦࡩ࡮ࡼࡥࡥࠢࡩࡶࡴࡳࠠࡴࡧࡵࡺࡪࡸ࠺ࠡࠤᐧ") + str(r) + bstack1l1l11_opy_ (u"ࠣࠤᐨ"))
            return r
        except grpc.RpcError as e:
            self.logger.error(bstack1l1l11_opy_ (u"ࠤࡵࡴࡨ࠳ࡥࡳࡴࡲࡶ࠿ࠦࠢᐩ") + str(e) + bstack1l1l11_opy_ (u"ࠥࠦᐪ"))
            traceback.print_exc()
            raise e
    @measure(event_name=EVENTS.bstack1l111l1llll_opy_, stage=STAGE.bstack111llllll_opy_)
    def bstack1l111ll1lll_opy_(
        self,
        ref: str,
        platform_index: int,
        framework_name: str,
        framework_version: str,
        framework_session_id: str,
        hub_url: str,
    ):
        self.bstack1l1ll11l111_opy_()
        req = structs.AutomationFrameworkStopRequest()
        req.ref = ref
        req.bin_session_id = self.bin_session_id
        req.platform_index = platform_index
        req.framework_name = framework_name
        req.framework_version = framework_version
        req.framework_session_id = framework_session_id
        req.hub_url = hub_url
        self.logger.debug(bstack1l1l11_opy_ (u"ࠦࡷ࡫ࡧࡪࡵࡷࡩࡷࡥࡳࡵࡱࡳ࠾ࠥࠨᐫ") + str(req) + bstack1l1l11_opy_ (u"ࠧࠨᐬ"))
        try:
            r = self.bstack1ll1ll1l111_opy_.AutomationFrameworkStop(req)
            if not r.success:
                self.logger.debug(bstack1l1l11_opy_ (u"ࠨࡲࡦࡥࡨ࡭ࡻ࡫ࡤࠡࡨࡵࡳࡲࠦࡳࡦࡴࡹࡩࡷࡀࠠࠣᐭ") + str(r) + bstack1l1l11_opy_ (u"ࠢࠣᐮ"))
            return r
        except grpc.RpcError as e:
            self.logger.error(bstack1l1l11_opy_ (u"ࠣࡴࡳࡧ࠲࡫ࡲࡳࡱࡵ࠾ࠥࠨᐯ") + str(e) + bstack1l1l11_opy_ (u"ࠤࠥᐰ"))
            traceback.print_exc()
            raise e
    @measure(event_name=EVENTS.bstack1lll11ll_opy_, stage=STAGE.bstack111llllll_opy_)
    def bstack1l111l11ll1_opy_(self, instance: bstack1lll111l111_opy_, url: str, f: bstack1ll1llll11l_opy_, kwargs):
        bstack1l111ll1ll1_opy_ = version.parse(f.framework_version)
        bstack1l111ll111l_opy_ = kwargs.get(bstack1l1l11_opy_ (u"ࠥࡳࡵࡺࡩࡰࡰࡶࠦᐱ"))
        bstack1l111lll111_opy_ = kwargs.get(bstack1l1l11_opy_ (u"ࠦࡩ࡫ࡳࡪࡴࡨࡨࡤࡩࡡࡱࡣࡥ࡭ࡱ࡯ࡴࡪࡧࡶࠦᐲ"))
        bstack1l11l1lll1l_opy_ = {}
        bstack1l111lll1l1_opy_ = {}
        bstack1l111l11l11_opy_ = None
        bstack1l111l1l1l1_opy_ = {}
        if bstack1l111lll111_opy_ is not None or bstack1l111ll111l_opy_ is not None: # check top level caps
            if bstack1l111lll111_opy_ is not None:
                bstack1l111l1l1l1_opy_[bstack1l1l11_opy_ (u"ࠬࡪࡥࡴ࡫ࡵࡩࡩࡥࡣࡢࡲࡤࡦ࡮ࡲࡩࡵ࡫ࡨࡷࠬᐳ")] = bstack1l111lll111_opy_
            if bstack1l111ll111l_opy_ is not None and callable(getattr(bstack1l111ll111l_opy_, bstack1l1l11_opy_ (u"ࠨࡴࡰࡡࡦࡥࡵࡧࡢࡪ࡮࡬ࡸ࡮࡫ࡳࠣᐴ"))):
                bstack1l111l1l1l1_opy_[bstack1l1l11_opy_ (u"ࠧࡰࡲࡷ࡭ࡴࡴࡳࡠࡣࡶࡣࡨࡧࡰࡢࡤ࡬ࡰ࡮ࡺࡩࡦࡵࠪᐵ")] = bstack1l111ll111l_opy_.to_capabilities()
        response = self.bstack1l11l1ll1l1_opy_(f.platform_index, url, instance.ref(), json.dumps(bstack1l111l1l1l1_opy_).encode(bstack1l1l11_opy_ (u"ࠣࡷࡷࡪ࠲࠾ࠢᐶ")))
        if response is not None and response.capabilities:
            bstack1l11l1lll1l_opy_ = json.loads(response.capabilities.decode(bstack1l1l11_opy_ (u"ࠤࡸࡸ࡫࠳࠸ࠣᐷ")))
            if not bstack1l11l1lll1l_opy_: # empty caps bstack1l11l1l1l1l_opy_ bstack1l11l1ll1ll_opy_ bstack1l11l1lll11_opy_ bstack1ll1111llll_opy_ or error in processing
                return
            bstack1l111l11l11_opy_ = f.bstack1ll1111ll1l_opy_[bstack1l1l11_opy_ (u"ࠥࡧࡷ࡫ࡡࡵࡧࡢࡳࡵࡺࡩࡰࡰࡶࡣ࡫ࡸ࡯࡮ࡡࡦࡥࡵࡹࠢᐸ")](bstack1l11l1lll1l_opy_)
        if bstack1l111ll111l_opy_ is not None and bstack1l111ll1ll1_opy_ >= version.parse(bstack1l1l11_opy_ (u"ࠫ࠸࠴࠸࠯࠲ࠪᐹ")):
            bstack1l111lll1l1_opy_ = None
        if (
                not bstack1l111ll111l_opy_ and not bstack1l111lll111_opy_
        ) or (
                bstack1l111ll1ll1_opy_ < version.parse(bstack1l1l11_opy_ (u"ࠬ࠹࠮࠹࠰࠳ࠫᐺ"))
        ):
            bstack1l111lll1l1_opy_ = {}
            bstack1l111lll1l1_opy_.update(bstack1l11l1lll1l_opy_)
        self.logger.info(bstack1111l1l1_opy_)
        if os.environ.get(bstack1l1l11_opy_ (u"ࠨࡂࡓࡑ࡚ࡗࡊࡘࡓࡕࡃࡆࡏࡤࡇࡕࡕࡑࡐࡅ࡙ࡏࡏࡏࠤᐻ")).lower().__eq__(bstack1l1l11_opy_ (u"ࠢࡵࡴࡸࡩࠧᐼ")):
            kwargs.update(
                {
                    bstack1l1l11_opy_ (u"ࠣࡥࡲࡱࡲࡧ࡮ࡥࡡࡨࡼࡪࡩࡵࡵࡱࡵࠦᐽ"): f.bstack1l111l1l1ll_opy_,
                }
            )
        if bstack1l111ll1ll1_opy_ >= version.parse(bstack1l1l11_opy_ (u"ࠩ࠷࠲࠶࠶࠮࠱ࠩᐾ")):
            if bstack1l111lll111_opy_ is not None:
                del kwargs[bstack1l1l11_opy_ (u"ࠥࡨࡪࡹࡩࡳࡧࡧࡣࡨࡧࡰࡢࡤ࡬ࡰ࡮ࡺࡩࡦࡵࠥᐿ")]
            kwargs.update(
                {
                    bstack1l1l11_opy_ (u"ࠦࡴࡶࡴࡪࡱࡱࡷࠧᑀ"): bstack1l111l11l11_opy_,
                    bstack1l1l11_opy_ (u"ࠧࡱࡥࡦࡲࡢࡥࡱ࡯ࡶࡦࠤᑁ"): True,
                    bstack1l1l11_opy_ (u"ࠨࡦࡪ࡮ࡨࡣࡩ࡫ࡴࡦࡥࡷࡳࡷࠨᑂ"): None,
                }
            )
        elif bstack1l111ll1ll1_opy_ >= version.parse(bstack1l1l11_opy_ (u"ࠧ࠴࠰࠻࠲࠵࠭ᑃ")):
            kwargs.update(
                {
                    bstack1l1l11_opy_ (u"ࠣࡦࡨࡷ࡮ࡸࡥࡥࡡࡦࡥࡵࡧࡢࡪ࡮࡬ࡸ࡮࡫ࡳࠣᑄ"): bstack1l111lll1l1_opy_,
                    bstack1l1l11_opy_ (u"ࠤࡲࡴࡹ࡯࡯࡯ࡵࠥᑅ"): bstack1l111l11l11_opy_,
                    bstack1l1l11_opy_ (u"ࠥ࡯ࡪ࡫ࡰࡠࡣ࡯࡭ࡻ࡫ࠢᑆ"): True,
                    bstack1l1l11_opy_ (u"ࠦ࡫࡯࡬ࡦࡡࡧࡩࡹ࡫ࡣࡵࡱࡵࠦᑇ"): None,
                }
            )
        elif bstack1l111ll1ll1_opy_ >= version.parse(bstack1l1l11_opy_ (u"ࠬ࠸࠮࠶࠵࠱࠴ࠬᑈ")):
            kwargs.update(
                {
                    bstack1l1l11_opy_ (u"ࠨࡤࡦࡵ࡬ࡶࡪࡪ࡟ࡤࡣࡳࡥࡧ࡯࡬ࡪࡶ࡬ࡩࡸࠨᑉ"): bstack1l111lll1l1_opy_,
                    bstack1l1l11_opy_ (u"ࠢ࡬ࡧࡨࡴࡤࡧ࡬ࡪࡸࡨࠦᑊ"): True,
                    bstack1l1l11_opy_ (u"ࠣࡨ࡬ࡰࡪࡥࡤࡦࡶࡨࡧࡹࡵࡲࠣᑋ"): None,
                }
            )
        else:
            kwargs.update(
                {
                    bstack1l1l11_opy_ (u"ࠤࡧࡩࡸ࡯ࡲࡦࡦࡢࡧࡦࡶࡡࡣ࡫࡯࡭ࡹ࡯ࡥࡴࠤᑌ"): bstack1l111lll1l1_opy_,
                    bstack1l1l11_opy_ (u"ࠥ࡯ࡪ࡫ࡰࡠࡣ࡯࡭ࡻ࡫ࠢᑍ"): True,
                    bstack1l1l11_opy_ (u"ࠦ࡫࡯࡬ࡦࡡࡧࡩࡹ࡫ࡣࡵࡱࡵࠦᑎ"): None,
                }
            )