# coding: UTF-8
import sys
bstack1l11111_opy_ = sys.version_info [0] == 2
bstack11l11ll_opy_ = 2048
bstack111ll1l_opy_ = 7
def bstack1l1l11_opy_ (bstack11l1l_opy_):
    global bstack1l11_opy_
    bstack11l1111_opy_ = ord (bstack11l1l_opy_ [-1])
    bstack1l1ll1l_opy_ = bstack11l1l_opy_ [:-1]
    bstack11l11_opy_ = bstack11l1111_opy_ % len (bstack1l1ll1l_opy_)
    bstack1l1ll11_opy_ = bstack1l1ll1l_opy_ [:bstack11l11_opy_] + bstack1l1ll1l_opy_ [bstack11l11_opy_:]
    if bstack1l11111_opy_:
        bstack11lll1l_opy_ = unicode () .join ([unichr (ord (char) - bstack11l11ll_opy_ - (bstack11l111_opy_ + bstack11l1111_opy_) % bstack111ll1l_opy_) for bstack11l111_opy_, char in enumerate (bstack1l1ll11_opy_)])
    else:
        bstack11lll1l_opy_ = str () .join ([chr (ord (char) - bstack11l11ll_opy_ - (bstack11l111_opy_ + bstack11l1111_opy_) % bstack111ll1l_opy_) for bstack11l111_opy_, char in enumerate (bstack1l1ll11_opy_)])
    return eval (bstack11lll1l_opy_)
import json
import time
from datetime import datetime, timezone
from browserstack_sdk.sdk_cli.bstack1lll111ll11_opy_ import (
    bstack1lll111l1ll_opy_,
    bstack1lll1111l11_opy_,
    bstack1lll11lll11_opy_,
    bstack1lll111l111_opy_,
    bstack1llll1l1l1l_opy_,
)
from browserstack_sdk.sdk_cli.bstack1ll111l1111_opy_ import bstack1ll1llll11l_opy_
from browserstack_sdk.sdk_cli.test_framework import TestFramework, bstack1llll111lll_opy_, bstack1llll1ll111_opy_, bstack1lllll111l1_opy_
from browserstack_sdk.sdk_cli.bstack1l1l1l1l11l_opy_ import bstack1l1l1l1ll1l_opy_
from typing import Tuple, Dict, Any, List, Union
from bstack_utils.helper import bstack1l1l111ll11_opy_
from browserstack_sdk import sdk_pb2 as structs
from bstack_utils.measure import measure
from bstack_utils.constants import *
from typing import Tuple, List, Any
class bstack1ll1l111l1l_opy_(bstack1l1l1l1ll1l_opy_):
    bstack1l11l111ll1_opy_ = bstack1l1l11_opy_ (u"ࠧࡺࡥࡴࡶࡢࡨࡷ࡯ࡶࡦࡴࡶࠦᑏ")
    bstack1l1l111l11l_opy_ = bstack1l1l11_opy_ (u"ࠨࡡࡶࡶࡲࡱࡦࡺࡩࡰࡰࡢࡷࡪࡹࡳࡪࡱࡱࡷࠧᑐ")
    bstack1l11l11l1ll_opy_ = bstack1l1l11_opy_ (u"ࠢ࡯ࡱࡱࡣࡧࡸ࡯ࡸࡵࡨࡶࡸࡺࡡࡤ࡭ࡢࡥࡺࡺ࡯࡮ࡣࡷ࡭ࡴࡴ࡟ࡴࡧࡶࡷ࡮ࡵ࡮ࡴࠤᑑ")
    bstack1l11l11l1l1_opy_ = bstack1l1l11_opy_ (u"ࠣࡶࡨࡷࡹࡥࡳࡦࡵࡶ࡭ࡴࡴࡳࠣᑒ")
    bstack1l11l11l111_opy_ = bstack1l1l11_opy_ (u"ࠤࡤࡹࡹࡵ࡭ࡢࡶ࡬ࡳࡳࡥࡩ࡯ࡵࡷࡥࡳࡩࡥࡠࡴࡨࡪࡸࠨᑓ")
    bstack1l1l1l111ll_opy_ = bstack1l1l11_opy_ (u"ࠥࡧࡧࡺ࡟ࡴࡧࡶࡷ࡮ࡵ࡮ࡠࡥࡵࡩࡦࡺࡥࡥࠤᑔ")
    bstack1l11l111111_opy_ = bstack1l1l11_opy_ (u"ࠦࡨࡨࡴࡠࡵࡨࡷࡸ࡯࡯࡯ࡡࡱࡥࡲ࡫ࠢᑕ")
    bstack1l11l111l11_opy_ = bstack1l1l11_opy_ (u"ࠧࡩࡢࡵࡡࡶࡩࡸࡹࡩࡰࡰࡢࡷࡹࡧࡴࡶࡵࠥᑖ")
    def __init__(self):
        super().__init__(bstack1l1l1l1l1ll_opy_=self.bstack1l11l111ll1_opy_, frameworks=[bstack1ll1llll11l_opy_.NAME])
        if not self.is_enabled():
            return
        TestFramework.bstack1llll1lll1l_opy_((bstack1llll111lll_opy_.BEFORE_EACH, bstack1llll1ll111_opy_.POST), self.bstack1l1111ll1l1_opy_)
        TestFramework.bstack1llll1lll1l_opy_((bstack1llll111lll_opy_.TEST, bstack1llll1ll111_opy_.PRE), self.bstack1l1ll1l1l11_opy_)
        TestFramework.bstack1llll1lll1l_opy_((bstack1llll111lll_opy_.TEST, bstack1llll1ll111_opy_.POST), self.bstack1l1ll1l11ll_opy_)
    def is_enabled(self) -> bool:
        return True
    def bstack1l1111ll1l1_opy_(
        self,
        f: TestFramework,
        instance: bstack1lllll111l1_opy_,
        bstack1llll1111ll_opy_: Tuple[bstack1llll111lll_opy_, bstack1llll1ll111_opy_],
        *args,
        **kwargs,
    ):
        bstack1l11llll1l1_opy_ = self.bstack1l111l11111_opy_(instance.context)
        if not bstack1l11llll1l1_opy_:
            self.logger.debug(bstack1l1l11_opy_ (u"ࠨࡳࡦࡶࡢࡥࡨࡺࡩࡷࡧࡢࡨࡷ࡯ࡶࡦࡴࡶ࠾ࠥࡴ࡯ࠡࡦࡵ࡭ࡻ࡫ࡲࠡࡨࡲࡶࠥ࡮࡯ࡰ࡭ࡢ࡭ࡳ࡬࡯࠾ࠤᑗ") + str(bstack1llll1111ll_opy_) + bstack1l1l11_opy_ (u"ࠢࠣᑘ"))
        f.bstack1lllll1l11l_opy_(instance, bstack1ll1l111l1l_opy_.bstack1l1l111l11l_opy_, bstack1l11llll1l1_opy_)
        bstack1l1111l1lll_opy_ = self.bstack1l111l11111_opy_(instance.context, bstack1l1111ll1ll_opy_=False)
        f.bstack1lllll1l11l_opy_(instance, bstack1ll1l111l1l_opy_.bstack1l11l11l1ll_opy_, bstack1l1111l1lll_opy_)
    def bstack1l1ll1l1l11_opy_(
        self,
        f: TestFramework,
        instance: bstack1lllll111l1_opy_,
        bstack1llll1111ll_opy_: Tuple[bstack1llll111lll_opy_, bstack1llll1ll111_opy_],
        *args,
        **kwargs,
    ):
        self.bstack1l1111ll1l1_opy_(f, instance, bstack1llll1111ll_opy_, *args, **kwargs)
        if not f.bstack1lll1llllll_opy_(instance, bstack1ll1l111l1l_opy_.bstack1l11l111111_opy_, False):
            self.__1l1111ll111_opy_(f,instance,bstack1llll1111ll_opy_)
    def bstack1l1ll1l11ll_opy_(
        self,
        f: TestFramework,
        instance: bstack1lllll111l1_opy_,
        bstack1llll1111ll_opy_: Tuple[bstack1llll111lll_opy_, bstack1llll1ll111_opy_],
        *args,
        **kwargs,
    ):
        self.bstack1l1111ll1l1_opy_(f, instance, bstack1llll1111ll_opy_, *args, **kwargs)
        if not f.bstack1lll1llllll_opy_(instance, bstack1ll1l111l1l_opy_.bstack1l11l111111_opy_, False):
            self.__1l1111ll111_opy_(f, instance, bstack1llll1111ll_opy_)
        if not f.bstack1lll1llllll_opy_(instance, bstack1ll1l111l1l_opy_.bstack1l11l111l11_opy_, False):
            self.__1l1111llll1_opy_(f, instance, bstack1llll1111ll_opy_)
    def bstack1l111l111l1_opy_(
        self,
        f: bstack1ll1llll11l_opy_,
        driver: object,
        exec: Tuple[bstack1lll111l111_opy_, str],
        bstack1llll1111ll_opy_: Tuple[bstack1lll111l1ll_opy_, bstack1lll1111l11_opy_],
        result: Any,
        *args,
        **kwargs,
    ):
        instance = exec[0]
        if not f.bstack1l1l1l1lll1_opy_(instance):
            return
        if f.bstack1lll1llllll_opy_(instance, bstack1ll1l111l1l_opy_.bstack1l11l111l11_opy_, False):
            return
        driver.execute_script(
            bstack1l1l11_opy_ (u"ࠣࡤࡵࡳࡼࡹࡥࡳࡵࡷࡥࡨࡱ࡟ࡦࡺࡨࡧࡺࡺ࡯ࡳ࠼ࠣࡿࢂࠨᑙ").format(
                json.dumps(
                    {
                        bstack1l1l11_opy_ (u"ࠤࡤࡧࡹ࡯࡯࡯ࠤᑚ"): bstack1l1l11_opy_ (u"ࠥࡷࡪࡺࡓࡦࡵࡶ࡭ࡴࡴࡓࡵࡣࡷࡹࡸࠨᑛ"),
                        bstack1l1l11_opy_ (u"ࠦࡦࡸࡧࡶ࡯ࡨࡲࡹࡹࠢᑜ"): {bstack1l1l11_opy_ (u"ࠧࡹࡴࡢࡶࡸࡷࠧᑝ"): result},
                    }
                )
            )
        )
        f.bstack1lllll1l11l_opy_(instance, bstack1ll1l111l1l_opy_.bstack1l11l111l11_opy_, True)
    def bstack1l111l11111_opy_(self, context: bstack1llll1l1l1l_opy_, bstack1l1111ll1ll_opy_= True):
        if bstack1l1111ll1ll_opy_:
            bstack1l11llll1l1_opy_ = self.bstack1l1l1ll111l_opy_(context, reverse=True)
        else:
            bstack1l11llll1l1_opy_ = self.bstack1l1l1l11ll1_opy_(context, reverse=True)
        return [f for f in bstack1l11llll1l1_opy_ if f[1].state != bstack1lll111l1ll_opy_.QUIT]
    @measure(event_name=EVENTS.bstack1111llll_opy_, stage=STAGE.bstack111llllll_opy_)
    def __1l1111llll1_opy_(
        self,
        f: TestFramework,
        instance: bstack1lllll111l1_opy_,
        bstack1llll1111ll_opy_: Tuple[bstack1llll111lll_opy_, bstack1llll1ll111_opy_],
    ):
        from browserstack_sdk.sdk_cli.cli import cli
        if not cli.config.get(bstack1l1l11_opy_ (u"ࠨࡴࡦࡵࡷࡇࡴࡴࡴࡦࡺࡷࡓࡵࡺࡩࡰࡰࡶࠦᑞ")).get(bstack1l1l11_opy_ (u"ࠢࡴ࡭࡬ࡴࡘ࡫ࡳࡴ࡫ࡲࡲࡘࡺࡡࡵࡷࡶࠦᑟ")):
            bstack1l11llll1l1_opy_ = f.bstack1lll1llllll_opy_(instance, bstack1ll1l111l1l_opy_.bstack1l1l111l11l_opy_, [])
            if not bstack1l11llll1l1_opy_:
                self.logger.debug(bstack1l1l11_opy_ (u"ࠣࡵࡨࡸࡤࡧࡣࡵ࡫ࡹࡩࡤࡪࡲࡪࡸࡨࡶࡸࡀࠠ࡯ࡱࠣࡨࡷ࡯ࡶࡦࡴࠣࡪࡴࡸࠠࡩࡱࡲ࡯ࡤ࡯࡮ࡧࡱࡀࠦᑠ") + str(bstack1llll1111ll_opy_) + bstack1l1l11_opy_ (u"ࠤࠥᑡ"))
                return
            driver = bstack1l11llll1l1_opy_[0][0]()
            status = f.bstack1lll1llllll_opy_(instance, TestFramework.bstack1llllll111l_opy_, None)
            if not status:
                self.logger.debug(bstack1l1l11_opy_ (u"ࠥࡷࡪࡺ࡟ࡢࡥࡷ࡭ࡻ࡫࡟ࡥࡴ࡬ࡺࡪࡸࡳ࠻ࠢࡱࡳࠥࡹࡴࡢࡶࡸࡷࠥ࡬࡯ࡳࠢࡷࡩࡸࡺࠬࠡࡪࡲࡳࡰࡥࡩ࡯ࡨࡲࡁࠧᑢ") + str(bstack1llll1111ll_opy_) + bstack1l1l11_opy_ (u"ࠦࠧᑣ"))
                return
            bstack1l11l11111l_opy_ = {bstack1l1l11_opy_ (u"ࠧࡹࡴࡢࡶࡸࡷࠧᑤ"): status.lower()}
            bstack1l11l111lll_opy_ = f.bstack1lll1llllll_opy_(instance, TestFramework.bstack1lll1lll1ll_opy_, None)
            if status.lower() == bstack1l1l11_opy_ (u"࠭ࡦࡢ࡫࡯ࡩࡩ࠭ᑥ") and bstack1l11l111lll_opy_ is not None:
                bstack1l11l11111l_opy_[bstack1l1l11_opy_ (u"ࠧࡳࡧࡤࡷࡴࡴࠧᑦ")] = bstack1l11l111lll_opy_[0][bstack1l1l11_opy_ (u"ࠨࡤࡤࡧࡰࡺࡲࡢࡥࡨࠫᑧ")][0] if isinstance(bstack1l11l111lll_opy_, list) else str(bstack1l11l111lll_opy_)
            driver.execute_script(
                bstack1l1l11_opy_ (u"ࠤࡥࡶࡴࡽࡳࡦࡴࡶࡸࡦࡩ࡫ࡠࡧࡻࡩࡨࡻࡴࡰࡴ࠽ࠤࢀࢃࠢᑨ").format(
                    json.dumps(
                        {
                            bstack1l1l11_opy_ (u"ࠥࡥࡨࡺࡩࡰࡰࠥᑩ"): bstack1l1l11_opy_ (u"ࠦࡸ࡫ࡴࡔࡧࡶࡷ࡮ࡵ࡮ࡔࡶࡤࡸࡺࡹࠢᑪ"),
                            bstack1l1l11_opy_ (u"ࠧࡧࡲࡨࡷࡰࡩࡳࡺࡳࠣᑫ"): bstack1l11l11111l_opy_,
                        }
                    )
                )
            )
            f.bstack1lllll1l11l_opy_(instance, bstack1ll1l111l1l_opy_.bstack1l11l111l11_opy_, True)
    @measure(event_name=EVENTS.bstack1ll11l1l1_opy_, stage=STAGE.bstack111llllll_opy_)
    def __1l1111ll111_opy_(
        self,
        f: TestFramework,
        instance: bstack1lllll111l1_opy_,
        bstack1llll1111ll_opy_: Tuple[bstack1llll111lll_opy_, bstack1llll1ll111_opy_]
    ):
        from browserstack_sdk.sdk_cli.cli import cli
        if not cli.config.get(bstack1l1l11_opy_ (u"ࠨࡴࡦࡵࡷࡇࡴࡴࡴࡦࡺࡷࡓࡵࡺࡩࡰࡰࡶࠦᑬ")).get(bstack1l1l11_opy_ (u"ࠢࡴ࡭࡬ࡴࡘ࡫ࡳࡴ࡫ࡲࡲࡓࡧ࡭ࡦࠤᑭ")):
            test_name = f.bstack1lll1llllll_opy_(instance, TestFramework.bstack1lll1l1l11l_opy_, None)
            if not test_name:
                self.logger.debug(bstack1l1l11_opy_ (u"ࠣࡱࡱࡣࡧ࡫ࡦࡰࡴࡨࡣࡹ࡫ࡳࡵ࠼ࠣࡱ࡮ࡹࡳࡪࡰࡪࠤࡹ࡫ࡳࡵࠢࡱࡥࡲ࡫ࠢᑮ"))
                return
            bstack1l11llll1l1_opy_ = f.bstack1lll1llllll_opy_(instance, bstack1ll1l111l1l_opy_.bstack1l1l111l11l_opy_, [])
            if not bstack1l11llll1l1_opy_:
                self.logger.debug(bstack1l1l11_opy_ (u"ࠤࡶࡩࡹࡥࡡࡤࡶ࡬ࡺࡪࡥࡤࡳ࡫ࡹࡩࡷࡹ࠺ࠡࡰࡲࠤࡸࡺࡡࡵࡷࡶࠤ࡫ࡵࡲࠡࡶࡨࡷࡹ࠲ࠠࡩࡱࡲ࡯ࡤ࡯࡮ࡧࡱࡀࠦᑯ") + str(bstack1llll1111ll_opy_) + bstack1l1l11_opy_ (u"ࠥࠦᑰ"))
                return
            for bstack1l11ll1l11l_opy_, bstack1l1111lll1l_opy_ in bstack1l11llll1l1_opy_:
                if not bstack1ll1llll11l_opy_.bstack1l1l1l1lll1_opy_(bstack1l1111lll1l_opy_):
                    continue
                driver = bstack1l11ll1l11l_opy_()
                if not driver:
                    continue
                driver.execute_script(
                    bstack1l1l11_opy_ (u"ࠦࡧࡸ࡯ࡸࡵࡨࡶࡸࡺࡡࡤ࡭ࡢࡩࡽ࡫ࡣࡶࡶࡲࡶ࠿ࠦࡻࡾࠤᑱ").format(
                        json.dumps(
                            {
                                bstack1l1l11_opy_ (u"ࠧࡧࡣࡵ࡫ࡲࡲࠧᑲ"): bstack1l1l11_opy_ (u"ࠨࡳࡦࡶࡖࡩࡸࡹࡩࡰࡰࡑࡥࡲ࡫ࠢᑳ"),
                                bstack1l1l11_opy_ (u"ࠢࡢࡴࡪࡹࡲ࡫࡮ࡵࡵࠥᑴ"): {bstack1l1l11_opy_ (u"ࠣࡰࡤࡱࡪࠨᑵ"): test_name},
                            }
                        )
                    )
                )
            f.bstack1lllll1l11l_opy_(instance, bstack1ll1l111l1l_opy_.bstack1l11l111111_opy_, True)
    def bstack1l1l111llll_opy_(
        self,
        instance: bstack1lllll111l1_opy_,
        f: TestFramework,
        bstack1llll1111ll_opy_: Tuple[bstack1llll111lll_opy_, bstack1llll1ll111_opy_],
        *args,
        **kwargs,
    ):
        self.bstack1l1111ll1l1_opy_(f, instance, bstack1llll1111ll_opy_, *args, **kwargs)
        bstack1l11llll1l1_opy_ = [d for d, _ in f.bstack1lll1llllll_opy_(instance, bstack1ll1l111l1l_opy_.bstack1l1l111l11l_opy_, [])]
        if not bstack1l11llll1l1_opy_:
            self.logger.debug(bstack1l1l11_opy_ (u"ࠤࡲࡲࡤࡧࡦࡵࡧࡵࡣࡹ࡫ࡳࡵ࠼ࠣࡲࡴࠦࡳࡦࡵࡶ࡭ࡴࡴࡳࠡࡶࡲࠤࡱ࡯࡮࡬ࠤᑶ"))
            return
        if not bstack1l1l111ll11_opy_():
            self.logger.debug(bstack1l1l11_opy_ (u"ࠥࡳࡳࡥࡡࡧࡶࡨࡶࡤࡺࡥࡴࡶ࠽ࠤࡳࡵࡴࠡࡤࡵࡳࡼࡹࡥࡳࡵࡷࡥࡨࡱࠠࡴࡧࡶࡷ࡮ࡵ࡮ࠣᑷ"))
            return
        for bstack1l111l1111l_opy_ in bstack1l11llll1l1_opy_:
            driver = bstack1l111l1111l_opy_()
            if not driver:
                continue
            timestamp = int(time.time() * 1000)
            data = bstack1l1l11_opy_ (u"ࠦࡔࡨࡳࡦࡴࡹࡥࡧ࡯࡬ࡪࡶࡼࡗࡾࡴࡣ࠻ࠤᑸ") + str(timestamp)
            driver.execute_script(
                bstack1l1l11_opy_ (u"ࠧࡨࡲࡰࡹࡶࡩࡷࡹࡴࡢࡥ࡮ࡣࡪࡾࡥࡤࡷࡷࡳࡷࡀࠠࡼࡿࠥᑹ").format(
                    json.dumps(
                        {
                            bstack1l1l11_opy_ (u"ࠨࡡࡤࡶ࡬ࡳࡳࠨᑺ"): bstack1l1l11_opy_ (u"ࠢࡢࡰࡱࡳࡹࡧࡴࡦࠤᑻ"),
                            bstack1l1l11_opy_ (u"ࠣࡣࡵ࡫ࡺࡳࡥ࡯ࡶࡶࠦᑼ"): {
                                bstack1l1l11_opy_ (u"ࠤࡷࡽࡵ࡫ࠢᑽ"): bstack1l1l11_opy_ (u"ࠥࡅࡳࡴ࡯ࡵࡣࡷ࡭ࡴࡴࠢᑾ"),
                                bstack1l1l11_opy_ (u"ࠦࡩࡧࡴࡢࠤᑿ"): data,
                                bstack1l1l11_opy_ (u"ࠧࡲࡥࡷࡧ࡯ࠦᒀ"): bstack1l1l11_opy_ (u"ࠨࡤࡦࡤࡸ࡫ࠧᒁ")
                            }
                        }
                    )
                )
            )
    def bstack1l11ll1llll_opy_(
        self,
        instance: bstack1lllll111l1_opy_,
        f: TestFramework,
        bstack1llll1111ll_opy_: Tuple[bstack1llll111lll_opy_, bstack1llll1ll111_opy_],
        *args,
        **kwargs,
    ):
        self.bstack1l1111ll1l1_opy_(f, instance, bstack1llll1111ll_opy_, *args, **kwargs)
        keys = [
            bstack1ll1l111l1l_opy_.bstack1l1l111l11l_opy_,
            bstack1ll1l111l1l_opy_.bstack1l11l11l1ll_opy_,
        ]
        bstack1l11llll1l1_opy_ = []
        for key in keys:
            bstack1l11llll1l1_opy_.extend(f.bstack1lll1llllll_opy_(instance, key, []))
        if not bstack1l11llll1l1_opy_:
            self.logger.debug(bstack1l1l11_opy_ (u"ࠢࡰࡰࡢࡥ࡫ࡺࡥࡳࡡࡷࡩࡸࡺ࠺ࠡࡷࡱࡥࡧࡲࡥࠡࡶࡲࠤ࡫࡯࡮ࡥࠢࡤࡲࡾࠦࡳࡦࡵࡶ࡭ࡴࡴࡳࠡࡶࡲࠤࡱ࡯࡮࡬ࠤᒂ"))
            return
        if f.bstack1lll1llllll_opy_(instance, bstack1ll1l111l1l_opy_.bstack1l1l1l111ll_opy_, False):
            self.logger.debug(bstack1l1l11_opy_ (u"ࠣࡱࡱࡣࡦ࡬ࡴࡦࡴࡢࡸࡪࡹࡴ࠻ࠢࡆࡆ࡙ࠦࡡ࡭ࡴࡨࡥࡩࡿࠠࡤࡴࡨࡥࡹ࡫ࡤࠣᒃ"))
            return
        self.bstack1l1ll11l111_opy_()
        bstack11l1l1ll1_opy_ = datetime.now()
        req = structs.TestSessionEventRequest()
        req.bin_session_id = self.bin_session_id
        req.platform_index = TestFramework.bstack1lll1llllll_opy_(instance, TestFramework.bstack1llll11ll1l_opy_)
        req.test_framework_name = TestFramework.bstack1lll1llllll_opy_(instance, TestFramework.bstack1lll1ll111l_opy_)
        req.test_framework_version = TestFramework.bstack1lll1llllll_opy_(instance, TestFramework.bstack1lll1l1lll1_opy_)
        req.test_framework_state = bstack1llll1111ll_opy_[0].name
        req.test_hook_state = bstack1llll1111ll_opy_[1].name
        req.test_uuid = TestFramework.bstack1lll1llllll_opy_(instance, TestFramework.bstack1llll1l1ll1_opy_)
        for bstack1l11ll1l11l_opy_, driver in bstack1l11llll1l1_opy_:
            try:
                webdriver = bstack1l11ll1l11l_opy_()
                if webdriver is None:
                    self.logger.debug(bstack1l1l11_opy_ (u"ࠤ࡚ࡩࡧࡊࡲࡪࡸࡨࡶࠥ࡯࡮ࡴࡶࡤࡲࡨ࡫ࠠࡪࡵࠣࡒࡴࡴࡥࠡࠪࡵࡩ࡫࡫ࡲࡦࡰࡦࡩࠥ࡫ࡸࡱ࡫ࡵࡩࡩ࠯ࠢᒄ"))
                    continue
                session = req.automation_sessions.add()
                session.provider = (
                    bstack1l1l11_opy_ (u"ࠥࡦࡷࡵࡷࡴࡧࡵࡷࡹࡧࡣ࡬ࠤᒅ")
                    if bstack1ll1llll11l_opy_.bstack1lll1llllll_opy_(driver, bstack1ll1llll11l_opy_.bstack1l1111ll11l_opy_, False)
                    else bstack1l1l11_opy_ (u"ࠦࡺࡴ࡫࡯ࡱࡺࡲࡤ࡭ࡲࡪࡦࠥᒆ")
                )
                session.ref = driver.ref()
                session.hub_url = bstack1ll1llll11l_opy_.bstack1lll1llllll_opy_(driver, bstack1ll1llll11l_opy_.bstack1l11l1l11ll_opy_, bstack1l1l11_opy_ (u"ࠧࠨᒇ"))
                session.framework_name = driver.framework_name
                session.framework_version = driver.framework_version
                session.framework_session_id = bstack1ll1llll11l_opy_.bstack1lll1llllll_opy_(driver, bstack1ll1llll11l_opy_.bstack1l11l1l1ll1_opy_, bstack1l1l11_opy_ (u"ࠨࠢᒈ"))
                caps = None
                if hasattr(webdriver, bstack1l1l11_opy_ (u"ࠢࡤࡣࡳࡥࡧ࡯࡬ࡪࡶ࡬ࡩࡸࠨᒉ")):
                    try:
                        caps = webdriver.capabilities
                        self.logger.debug(bstack1l1l11_opy_ (u"ࠣࡕࡸࡧࡨ࡫ࡳࡴࡨࡸࡰࡱࡿࠠࡳࡧࡷࡶ࡮࡫ࡶࡦࡦࠣࡧࡦࡶࡡࡣ࡫࡯࡭ࡹ࡯ࡥࡴࠢࡧ࡭ࡷ࡫ࡣࡵ࡮ࡼࠤ࡫ࡸ࡯࡮ࠢࡧࡶ࡮ࡼࡥࡳ࠰ࡦࡥࡵࡧࡢࡪ࡮࡬ࡸ࡮࡫ࡳࠣᒊ"))
                    except Exception as e:
                        self.logger.debug(bstack1l1l11_opy_ (u"ࠤࡉࡥ࡮ࡲࡥࡥࠢࡷࡳࠥ࡭ࡥࡵࠢࡦࡥࡵࡧࡢࡪ࡮࡬ࡸ࡮࡫ࡳࠡࡨࡵࡳࡲࠦࡤࡳ࡫ࡹࡩࡷ࠴ࡣࡢࡲࡤࡦ࡮ࡲࡩࡵ࡫ࡨࡷ࠿ࠦࠢᒋ") + str(e) + bstack1l1l11_opy_ (u"ࠥࠦᒌ"))
                try:
                    bstack1l1111lll11_opy_ = json.dumps(caps).encode(bstack1l1l11_opy_ (u"ࠦࡺࡺࡦ࠮࠺ࠥᒍ")) if caps else bstack1l1111lllll_opy_ (u"ࠧࢁࡽࠣᒎ")
                    req.capabilities = bstack1l1111lll11_opy_
                except Exception as e:
                    self.logger.debug(bstack1l1l11_opy_ (u"ࠨࡧࡦࡶࡢࡧࡧࡺ࡟ࡦࡸࡨࡲࡹࡀࠠࡧࡣ࡬ࡰࡪࡪࠠࡵࡱࠣࡷࡪࡴࡤࠡࡵࡨࡶ࡮ࡧ࡬ࡪࡼࡨࠤࡨࡧࡰࡴࠢࡩࡳࡷࠦࡲࡦࡳࡸࡩࡸࡺ࠺ࠡࠤᒏ") + str(e) + bstack1l1l11_opy_ (u"ࠢࠣᒐ"))
            except Exception as e:
                self.logger.error(bstack1l1l11_opy_ (u"ࠣࡇࡵࡶࡴࡸࠠࡱࡴࡲࡧࡪࡹࡳࡪࡰࡪࠤࡩࡸࡩࡷࡧࡵࠤ࡮ࡺࡥ࡮࠼ࠣࠦᒑ") + str(str(e)) + bstack1l1l11_opy_ (u"ࠤࠥᒒ"))
        req.execution_context.hash = str(instance.context.hash)
        req.execution_context.thread_id = str(instance.context.thread_id)
        req.execution_context.process_id = str(instance.context.process_id)
        return req
    def bstack1l1ll1lll11_opy_(
        self,
        f: TestFramework,
        instance: bstack1lllll111l1_opy_,
        bstack1llll1111ll_opy_: Tuple[bstack1llll111lll_opy_, bstack1llll1ll111_opy_],
        *args,
        **kwargs
    ):
        bstack1l11llll1l1_opy_ = f.bstack1lll1llllll_opy_(instance, bstack1ll1l111l1l_opy_.bstack1l1l111l11l_opy_, [])
        if not bstack1l1l111ll11_opy_() and len(bstack1l11llll1l1_opy_) == 0:
            bstack1l11llll1l1_opy_ = f.bstack1lll1llllll_opy_(instance, bstack1ll1l111l1l_opy_.bstack1l11l11l1ll_opy_, [])
        if not bstack1l11llll1l1_opy_:
            self.logger.debug(bstack1l1l11_opy_ (u"ࠥࡳࡳࡥࡢࡦࡨࡲࡶࡪࡥࡴࡦࡵࡷ࠾ࠥࡴ࡯ࠡࡦࡵ࡭ࡻ࡫ࡲࡴࠢࡩࡳࡷࠦࡨࡰࡱ࡮ࡣ࡮ࡴࡦࡰ࠿ࡾ࡬ࡴࡵ࡫ࡠ࡫ࡱࡪࡴࢃࠠࡢࡴࡪࡷࡂࢁࡡࡳࡩࡶࢁࠥࡱࡷࡢࡴࡪࡷࡂࠨᒓ") + str(kwargs) + bstack1l1l11_opy_ (u"ࠦࠧᒔ"))
            return {}
        if len(bstack1l11llll1l1_opy_) > 1:
            self.logger.debug(bstack1l1l11_opy_ (u"ࠧࡵ࡮ࡠࡤࡨࡪࡴࡸࡥࡠࡶࡨࡷࡹࡀࠠࡼ࡮ࡨࡲ࠭ࡪࡲࡪࡸࡨࡶࡤ࡯࡮ࡴࡶࡤࡲࡨ࡫ࡳࠪࡿࠣࡨࡷ࡯ࡶࡦࡴࡶࠤ࡫ࡵࡲࠡࡪࡲࡳࡰࡥࡩ࡯ࡨࡲࡁࢀ࡮࡯ࡰ࡭ࡢ࡭ࡳ࡬࡯ࡾࠢࡤࡶ࡬ࡹ࠽ࡼࡣࡵ࡫ࡸࢃࠠ࡬ࡹࡤࡶ࡬ࡹ࠽ࠣᒕ") + str(kwargs) + bstack1l1l11_opy_ (u"ࠨࠢᒖ"))
            return {}
        bstack1l11ll1l11l_opy_, bstack1l11ll11lll_opy_ = bstack1l11llll1l1_opy_[0]
        driver = bstack1l11ll1l11l_opy_()
        if not driver:
            self.logger.debug(bstack1l1l11_opy_ (u"ࠢࡰࡰࡢࡦࡪ࡬࡯ࡳࡧࡢࡸࡪࡹࡴ࠻ࠢࡱࡳࠥࡪࡲࡪࡸࡨࡶࠥ࡬࡯ࡳࠢ࡫ࡳࡴࡱ࡟ࡪࡰࡩࡳࡂࢁࡨࡰࡱ࡮ࡣ࡮ࡴࡦࡰࡿࠣࡥࡷ࡭ࡳ࠾ࡽࡤࡶ࡬ࡹࡽࠡ࡭ࡺࡥࡷ࡭ࡳ࠾ࠤᒗ") + str(kwargs) + bstack1l1l11_opy_ (u"ࠣࠤᒘ"))
            return {}
        capabilities = f.bstack1lll1llllll_opy_(bstack1l11ll11lll_opy_, bstack1ll1llll11l_opy_.bstack1l11l11llll_opy_)
        if not capabilities:
            self.logger.debug(bstack1l1l11_opy_ (u"ࠤࡲࡲࡤࡨࡥࡧࡱࡵࡩࡤࡺࡥࡴࡶ࠽ࠤࡳࡵࠠࡤࡣࡳࡥࡧ࡯࡬ࡪࡶ࡬ࡩࡸࠦࡦࡰࡷࡱࡨࠥ࡬࡯ࡳࠢ࡫ࡳࡴࡱ࡟ࡪࡰࡩࡳࡂࢁࡨࡰࡱ࡮ࡣ࡮ࡴࡦࡰࡿࠣࡥࡷ࡭ࡳ࠾ࡽࡤࡶ࡬ࡹࡽࠡ࡭ࡺࡥࡷ࡭ࡳ࠾ࠤᒙ") + str(kwargs) + bstack1l1l11_opy_ (u"ࠥࠦᒚ"))
            return {}
        return capabilities.get(bstack1l1l11_opy_ (u"ࠦࡦࡲࡷࡢࡻࡶࡑࡦࡺࡣࡩࠤᒛ"), {})
    def bstack1l1llll1111_opy_(
        self,
        f: TestFramework,
        instance: bstack1lllll111l1_opy_,
        bstack1llll1111ll_opy_: Tuple[bstack1llll111lll_opy_, bstack1llll1ll111_opy_],
        *args,
        **kwargs
    ):
        bstack1l11llll1l1_opy_ = f.bstack1lll1llllll_opy_(instance, bstack1ll1l111l1l_opy_.bstack1l1l111l11l_opy_, [])
        if not bstack1l1l111ll11_opy_() and len(bstack1l11llll1l1_opy_) == 0:
            bstack1l11llll1l1_opy_ = f.bstack1lll1llllll_opy_(instance, bstack1ll1l111l1l_opy_.bstack1l11l11l1ll_opy_, [])
        if not bstack1l11llll1l1_opy_:
            self.logger.debug(bstack1l1l11_opy_ (u"ࠧ࡭ࡥࡵࡡࡤࡹࡹࡵ࡭ࡢࡶ࡬ࡳࡳࡥࡤࡳ࡫ࡹࡩࡷࡀࠠ࡯ࡱࠣࡨࡷ࡯ࡶࡦࡴࡶࠤ࡫ࡵࡲࠡࡪࡲࡳࡰࡥࡩ࡯ࡨࡲࡁࢀ࡮࡯ࡰ࡭ࡢ࡭ࡳ࡬࡯ࡾࠢࡤࡶ࡬ࡹ࠽ࡼࡣࡵ࡫ࡸࢃࠠ࡬ࡹࡤࡶ࡬ࡹ࠽ࠣᒜ") + str(kwargs) + bstack1l1l11_opy_ (u"ࠨࠢᒝ"))
            return
        if len(bstack1l11llll1l1_opy_) > 1:
            self.logger.debug(bstack1l1l11_opy_ (u"ࠢࡨࡧࡷࡣࡦࡻࡴࡰ࡯ࡤࡸ࡮ࡵ࡮ࡠࡦࡵ࡭ࡻ࡫ࡲ࠻ࠢࡾࡰࡪࡴࠨࡥࡴ࡬ࡺࡪࡸ࡟ࡪࡰࡶࡸࡦࡴࡣࡦࡵࠬࢁࠥࡪࡲࡪࡸࡨࡶࡸࠦࡦࡰࡴࠣ࡬ࡴࡵ࡫ࡠ࡫ࡱࡪࡴࡃࡻࡩࡱࡲ࡯ࡤ࡯࡮ࡧࡱࢀࠤࡦࡸࡧࡴ࠿ࡾࡥࡷ࡭ࡳࡾࠢ࡮ࡻࡦࡸࡧࡴ࠿ࠥᒞ") + str(kwargs) + bstack1l1l11_opy_ (u"ࠣࠤᒟ"))
        bstack1l11ll1l11l_opy_, bstack1l11ll11lll_opy_ = bstack1l11llll1l1_opy_[0]
        driver = bstack1l11ll1l11l_opy_()
        if not driver:
            self.logger.debug(bstack1l1l11_opy_ (u"ࠤࡪࡩࡹࡥࡡࡶࡶࡲࡱࡦࡺࡩࡰࡰࡢࡨࡷ࡯ࡶࡦࡴ࠽ࠤࡳࡵࠠࡥࡴ࡬ࡺࡪࡸࠠࡧࡱࡵࠤ࡭ࡵ࡯࡬ࡡ࡬ࡲ࡫ࡵ࠽ࡼࡪࡲࡳࡰࡥࡩ࡯ࡨࡲࢁࠥࡧࡲࡨࡵࡀࡿࡦࡸࡧࡴࡿࠣ࡯ࡼࡧࡲࡨࡵࡀࠦᒠ") + str(kwargs) + bstack1l1l11_opy_ (u"ࠥࠦᒡ"))
            return
        return driver