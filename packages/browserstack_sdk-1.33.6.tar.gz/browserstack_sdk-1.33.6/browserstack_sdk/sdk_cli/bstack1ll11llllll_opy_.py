# coding: UTF-8
import sys
bstack1l11111_opy_ = sys.version_info [0] == 2
bstack11l11ll_opy_ = 2048
bstack111ll1l_opy_ = 7
def bstack1l1l11_opy_ (bstack11l1l_opy_):
    global bstack1l11_opy_
    bstack11l1111_opy_ = ord (bstack11l1l_opy_ [-1])
    bstack1l1ll1l_opy_ = bstack11l1l_opy_ [:-1]
    bstack11l11_opy_ = bstack11l1111_opy_ % len (bstack1l1ll1l_opy_)
    bstack1l1ll11_opy_ = bstack1l1ll1l_opy_ [:bstack11l11_opy_] + bstack1l1ll1l_opy_ [bstack11l11_opy_:]
    if bstack1l11111_opy_:
        bstack11lll1l_opy_ = unicode () .join ([unichr (ord (char) - bstack11l11ll_opy_ - (bstack11l111_opy_ + bstack11l1111_opy_) % bstack111ll1l_opy_) for bstack11l111_opy_, char in enumerate (bstack1l1ll11_opy_)])
    else:
        bstack11lll1l_opy_ = str () .join ([chr (ord (char) - bstack11l11ll_opy_ - (bstack11l111_opy_ + bstack11l1111_opy_) % bstack111ll1l_opy_) for bstack11l111_opy_, char in enumerate (bstack1l1ll11_opy_)])
    return eval (bstack11lll1l_opy_)
import json
import os
import grpc
import copy
import asyncio
import threading
from browserstack_sdk import sdk_pb2 as structs
from packaging import version
import traceback
from browserstack_sdk.sdk_cli.bstack1ll11l111l1_opy_ import bstack1ll1l1lllll_opy_
from browserstack_sdk.sdk_cli.bstack1lll111ll11_opy_ import (
    bstack1lll111l1ll_opy_,
    bstack1lll1111l11_opy_,
    bstack1lll111l111_opy_,
)
from bstack_utils.constants import *
from typing import Any, List, Union, Dict
from pathlib import Path
from browserstack_sdk.sdk_cli.bstack1ll1ll1llll_opy_ import bstack1ll111ll111_opy_
from datetime import datetime
from typing import Tuple, Any
from bstack_utils.messages import bstack1111l1l1_opy_
from bstack_utils.helper import bstack1l1l111ll11_opy_
import threading
import os
import urllib.parse
class bstack1ll111l1lll_opy_(bstack1ll1l1lllll_opy_):
    def __init__(self, bstack1ll11lllll1_opy_):
        super().__init__()
        bstack1ll111ll111_opy_.bstack1llll1lll1l_opy_((bstack1lll111l1ll_opy_.bstack1lll111111l_opy_, bstack1lll1111l11_opy_.PRE), self.bstack1l11ll11111_opy_)
        bstack1ll111ll111_opy_.bstack1llll1lll1l_opy_((bstack1lll111l1ll_opy_.bstack1lll111111l_opy_, bstack1lll1111l11_opy_.PRE), self.bstack1l11l1l111l_opy_)
        bstack1ll111ll111_opy_.bstack1llll1lll1l_opy_((bstack1lll111l1ll_opy_.bstack1lll111lll1_opy_, bstack1lll1111l11_opy_.PRE), self.bstack1l11l1l1l11_opy_)
        bstack1ll111ll111_opy_.bstack1llll1lll1l_opy_((bstack1lll111l1ll_opy_.bstack1lll11l1l1l_opy_, bstack1lll1111l11_opy_.PRE), self.bstack1l11ll1111l_opy_)
        bstack1ll111ll111_opy_.bstack1llll1lll1l_opy_((bstack1lll111l1ll_opy_.bstack1lll111111l_opy_, bstack1lll1111l11_opy_.PRE), self.bstack1l11l1ll11l_opy_)
        bstack1ll111ll111_opy_.bstack1llll1lll1l_opy_((bstack1lll111l1ll_opy_.QUIT, bstack1lll1111l11_opy_.PRE), self.on_close)
        self.bstack1ll11lllll1_opy_ = bstack1ll11lllll1_opy_
    def is_enabled(self) -> bool:
        return True
    def bstack1l11ll11111_opy_(
        self,
        f: bstack1ll111ll111_opy_,
        bstack1l11l1lllll_opy_: object,
        exec: Tuple[bstack1lll111l111_opy_, str],
        bstack1llll1111ll_opy_: Tuple[bstack1lll111l1ll_opy_, bstack1lll1111l11_opy_],
        result: Any,
        *args,
        **kwargs,
    ):
        instance, method_name = exec
        if method_name != bstack1l1l11_opy_ (u"ࠣ࡮ࡤࡹࡳࡩࡨࠣᎀ"):
            return
        if not bstack1l1l111ll11_opy_():
            self.logger.debug(bstack1l1l11_opy_ (u"ࠤࡕࡩࡹࡻࡲ࡯࡫ࡱ࡫ࠥ࡯࡮ࠡ࡮ࡤࡹࡳࡩࡨࠡ࡯ࡨࡸ࡭ࡵࡤ࠭ࠢࡱࡳࡹࠦࡢࡳࡱࡺࡷࡪࡸࡳࡵࡣࡦ࡯ࠥࡹࡥࡴࡵ࡬ࡳࡳࠨᎁ"))
            return
        def wrapped(bstack1l11l1lllll_opy_, launch, *args, **kwargs):
            response = self.bstack1l11l1ll1l1_opy_(f.platform_index, instance.ref(), json.dumps({bstack1l1l11_opy_ (u"ࠪ࡭ࡸࡖ࡬ࡢࡻࡺࡶ࡮࡭ࡨࡵࠩᎂ"): True}).encode(bstack1l1l11_opy_ (u"ࠦࡺࡺࡦ࠮࠺ࠥᎃ")))
            if response is not None and response.capabilities:
                if not bstack1l1l111ll11_opy_():
                    browser = launch(bstack1l11l1lllll_opy_)
                    return browser
                bstack1l11l1lll1l_opy_ = json.loads(response.capabilities.decode(bstack1l1l11_opy_ (u"ࠧࡻࡴࡧ࠯࠻ࠦᎄ")))
                if not bstack1l11l1lll1l_opy_: # empty caps bstack1l11l1l1l1l_opy_ bstack1l11l1ll1ll_opy_ bstack1l11l1lll11_opy_ bstack1ll1111llll_opy_ or error in processing
                    return
                bstack1l11l1ll111_opy_ = PLAYWRIGHT_HUB_URL + urllib.parse.quote(json.dumps(bstack1l11l1lll1l_opy_))
                f.bstack1lllll1l11l_opy_(instance, bstack1ll111ll111_opy_.bstack1l11l1l11ll_opy_, bstack1l11l1ll111_opy_)
                f.bstack1lllll1l11l_opy_(instance, bstack1ll111ll111_opy_.bstack1l11l11llll_opy_, bstack1l11l1lll1l_opy_)
                browser = bstack1l11l1lllll_opy_.connect(bstack1l11l1ll111_opy_)
                return browser
        return wrapped
    def bstack1l11l1l1l11_opy_(
        self,
        f: bstack1ll111ll111_opy_,
        Connection: object,
        exec: Tuple[bstack1lll111l111_opy_, str],
        bstack1llll1111ll_opy_: Tuple[bstack1lll111l1ll_opy_, bstack1lll1111l11_opy_],
        result: Any,
        *args,
        **kwargs,
    ):
        instance, method_name = exec
        if method_name != bstack1l1l11_opy_ (u"ࠨࡤࡪࡵࡳࡥࡹࡩࡨࠣᎅ"):
            self.logger.debug(bstack1l1l11_opy_ (u"ࠢࡓࡧࡷࡹࡷࡴࡩ࡯ࡩࠣ࡭ࡳࠦࡤࡪࡵࡳࡥࡹࡩࡨࠡ࡯ࡨࡸ࡭ࡵࡤ࠭ࠢࡱࡳࡹࠦࡢࡳࡱࡺࡷࡪࡸࡳࡵࡣࡦ࡯ࠥࡹࡥࡴࡵ࡬ࡳࡳࠨᎆ"))
            return
        if not bstack1l1l111ll11_opy_():
            return
        def wrapped(Connection, dispatch, *args, **kwargs):
            data = args[0]
            try:
                if args and args[0].get(bstack1l1l11_opy_ (u"ࠨࡲࡤࡶࡦࡳࡳࠨᎇ"), {}).get(bstack1l1l11_opy_ (u"ࠩࡥࡷࡕࡧࡲࡢ࡯ࡶࠫᎈ")):
                    bstack1l11l1l11l1_opy_ = args[0][bstack1l1l11_opy_ (u"ࠥࡴࡦࡸࡡ࡮ࡵࠥᎉ")][bstack1l1l11_opy_ (u"ࠦࡧࡹࡐࡢࡴࡤࡱࡸࠨᎊ")]
                    session_id = bstack1l11l1l11l1_opy_.get(bstack1l1l11_opy_ (u"ࠧࡹࡥࡴࡵ࡬ࡳࡳࡏࡤࠣᎋ"))
                    f.bstack1lllll1l11l_opy_(instance, bstack1ll111ll111_opy_.bstack1l11l1l1ll1_opy_, session_id)
            except Exception as e:
                self.logger.debug(bstack1l1l11_opy_ (u"ࠨࡅࡹࡥࡨࡴࡹ࡯࡯࡯ࠢ࡬ࡲࠥࡪࡩࡴࡲࡤࡸࡨ࡮ࠠ࡮ࡧࡷ࡬ࡴࡪ࠺ࠡࠤᎌ"), e)
            dispatch(Connection, *args)
        return wrapped
    def bstack1l11l1ll11l_opy_(
        self,
        f: bstack1ll111ll111_opy_,
        bstack1l11l1lllll_opy_: object,
        exec: Tuple[bstack1lll111l111_opy_, str],
        bstack1llll1111ll_opy_: Tuple[bstack1lll111l1ll_opy_, bstack1lll1111l11_opy_],
        result: Any,
        *args,
        **kwargs,
    ):
        instance, method_name = exec
        if method_name != bstack1l1l11_opy_ (u"ࠢࡤࡱࡱࡲࡪࡩࡴࠣᎍ"):
            return
        if not bstack1l1l111ll11_opy_():
            self.logger.debug(bstack1l1l11_opy_ (u"ࠣࡔࡨࡸࡺࡸ࡮ࡪࡰࡪࠤ࡮ࡴࠠࡤࡱࡱࡲࡪࡩࡴࠡ࡯ࡨࡸ࡭ࡵࡤ࠭ࠢࡱࡳࡹࠦࡢࡳࡱࡺࡷࡪࡸࡳࡵࡣࡦ࡯ࠥࡹࡥࡴࡵ࡬ࡳࡳࠨᎎ"))
            return
        def wrapped(bstack1l11l1lllll_opy_, connect, *args, **kwargs):
            response = self.bstack1l11l1ll1l1_opy_(f.platform_index, instance.ref(), json.dumps({bstack1l1l11_opy_ (u"ࠩ࡬ࡷࡕࡲࡡࡺࡹࡵ࡭࡬࡮ࡴࠨᎏ"): True}).encode(bstack1l1l11_opy_ (u"ࠥࡹࡹ࡬࠭࠹ࠤ᎐")))
            if response is not None and response.capabilities:
                bstack1l11l1lll1l_opy_ = json.loads(response.capabilities.decode(bstack1l1l11_opy_ (u"ࠦࡺࡺࡦ࠮࠺ࠥ᎑")))
                if not bstack1l11l1lll1l_opy_:
                    return
                bstack1l11l1ll111_opy_ = PLAYWRIGHT_HUB_URL + urllib.parse.quote(json.dumps(bstack1l11l1lll1l_opy_))
                if bstack1l11l1lll1l_opy_.get(bstack1l1l11_opy_ (u"ࠬࡨࡲࡰࡹࡶࡩࡷࡹࡴࡢࡥ࡮࠲ࡦࡩࡣࡦࡵࡶ࡭ࡧ࡯࡬ࡪࡶࡼࠫ᎒")):
                    browser = bstack1l11l1lllll_opy_.bstack1l11l1l1111_opy_(bstack1l11l1ll111_opy_)
                    return browser
                else:
                    args = list(args)
                    args[0] = bstack1l11l1ll111_opy_
                    return connect(bstack1l11l1lllll_opy_, *args, **kwargs)
        return wrapped
    def bstack1l11l1l111l_opy_(
        self,
        f: bstack1ll111ll111_opy_,
        bstack1l1l1l1l1l1_opy_: object,
        exec: Tuple[bstack1lll111l111_opy_, str],
        bstack1llll1111ll_opy_: Tuple[bstack1lll111l1ll_opy_, bstack1lll1111l11_opy_],
        result: Any,
        *args,
        **kwargs,
    ):
        instance, method_name = exec
        if method_name != bstack1l1l11_opy_ (u"ࠨ࡮ࡦࡹࡢࡴࡦ࡭ࡥࠣ᎓"):
            return
        if not bstack1l1l111ll11_opy_():
            self.logger.debug(bstack1l1l11_opy_ (u"ࠢࡓࡧࡷࡹࡷࡴࡩ࡯ࡩࠣ࡭ࡳࠦ࡮ࡦࡹࡢࡴࡦ࡭ࡥࠡ࡯ࡨࡸ࡭ࡵࡤ࠭ࠢࡱࡳࡹࠦࡢࡳࡱࡺࡷࡪࡸࡳࡵࡣࡦ࡯ࠥࡹࡥࡴࡵ࡬ࡳࡳࠨ᎔"))
            return
        def wrapped(bstack1l1l1l1l1l1_opy_, bstack1l11l1llll1_opy_, *args, **kwargs):
            contexts = bstack1l1l1l1l1l1_opy_.browser.contexts
            if contexts:
                for context in contexts:
                    if context.pages:
                        for page in context.pages:
                            if bstack1l1l11_opy_ (u"ࠣࡣࡥࡳࡺࡺ࠺ࡣ࡮ࡤࡲࡰࠨ᎕") in page.url:
                                return page
                            else:
                                return bstack1l11l1llll1_opy_(bstack1l1l1l1l1l1_opy_)
                    else:
                        return bstack1l11l1llll1_opy_(bstack1l1l1l1l1l1_opy_)
        return wrapped
    def bstack1l11l1ll1l1_opy_(self, platform_index: int, ref, user_input_params: bytes):
        req = structs.DriverInitRequest()
        req.bin_session_id = self.bin_session_id
        req.platform_index = platform_index
        req.user_input_params = user_input_params
        req.ref = ref
        self.logger.debug(bstack1l1l11_opy_ (u"ࠤࡵࡩ࡬࡯ࡳࡵࡧࡵࡣࡼ࡫ࡢࡥࡴ࡬ࡺࡪࡸ࡟ࡪࡰ࡬ࡸ࠿ࠦࠢ᎖") + str(req) + bstack1l1l11_opy_ (u"ࠥࠦ᎗"))
        try:
            r = self.bstack1ll1ll1l111_opy_.DriverInit(req)
            if not r.success:
                self.logger.debug(bstack1l1l11_opy_ (u"ࠦࡷ࡫ࡣࡦ࡫ࡹࡩࡩࠦࡦࡳࡱࡰࠤࡸ࡫ࡲࡷࡧࡵ࠾ࠥࡹࡵࡤࡥࡨࡷࡸࡃࠢ᎘") + str(r.success) + bstack1l1l11_opy_ (u"ࠧࠨ᎙"))
            return r
        except grpc.RpcError as e:
            self.logger.error(bstack1l1l11_opy_ (u"ࠨࡲࡱࡥ࠰ࡩࡷࡸ࡯ࡳ࠼ࠣࠦ᎚") + str(e) + bstack1l1l11_opy_ (u"ࠢࠣ᎛"))
            traceback.print_exc()
            raise e
    def bstack1l11ll1111l_opy_(
        self,
        f: bstack1ll111ll111_opy_,
        Connection: object,
        exec: Tuple[bstack1lll111l111_opy_, str],
        bstack1llll1111ll_opy_: Tuple[bstack1lll111l1ll_opy_, bstack1lll1111l11_opy_],
        result: Any,
        *args,
        **kwargs,
    ):
        instance, method_name = exec
        if method_name != bstack1l1l11_opy_ (u"ࠣࡡࡶࡩࡳࡪ࡟࡮ࡧࡶࡷࡦ࡭ࡥࡠࡶࡲࡣࡸ࡫ࡲࡷࡧࡵࠦ᎜"):
            return
        if not bstack1l1l111ll11_opy_():
            return
        def wrapped(Connection, bstack1l11l1l1lll_opy_, *args, **kwargs):
            return bstack1l11l1l1lll_opy_(Connection, *args, **kwargs)
        return wrapped
    def on_close(
        self,
        f: bstack1ll111ll111_opy_,
        bstack1l11l1lllll_opy_: object,
        exec: Tuple[bstack1lll111l111_opy_, str],
        bstack1llll1111ll_opy_: Tuple[bstack1lll111l1ll_opy_, bstack1lll1111l11_opy_],
        result: Any,
        *args,
        **kwargs,
    ):
        instance, method_name = exec
        if method_name != bstack1l1l11_opy_ (u"ࠤࡦࡰࡴࡹࡥࠣ᎝"):
            return
        if not bstack1l1l111ll11_opy_():
            self.logger.debug(bstack1l1l11_opy_ (u"ࠥࡖࡪࡺࡵࡳࡰ࡬ࡲ࡬ࠦࡩ࡯ࠢࡦࡰࡴࡹࡥࠡ࡯ࡨࡸ࡭ࡵࡤ࠭ࠢࡱࡳࡹࠦࡢࡳࡱࡺࡷࡪࡸࡳࡵࡣࡦ࡯ࠥࡹࡥࡴࡵ࡬ࡳࡳࠨ᎞"))
            return
        def wrapped(Connection, close, *args, **kwargs):
            return close(Connection)
        return wrapped