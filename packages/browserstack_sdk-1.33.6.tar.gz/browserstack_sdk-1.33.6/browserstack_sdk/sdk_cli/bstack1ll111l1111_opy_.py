# coding: UTF-8
import sys
bstack1l11111_opy_ = sys.version_info [0] == 2
bstack11l11ll_opy_ = 2048
bstack111ll1l_opy_ = 7
def bstack1l1l11_opy_ (bstack11l1l_opy_):
    global bstack1l11_opy_
    bstack11l1111_opy_ = ord (bstack11l1l_opy_ [-1])
    bstack1l1ll1l_opy_ = bstack11l1l_opy_ [:-1]
    bstack11l11_opy_ = bstack11l1111_opy_ % len (bstack1l1ll1l_opy_)
    bstack1l1ll11_opy_ = bstack1l1ll1l_opy_ [:bstack11l11_opy_] + bstack1l1ll1l_opy_ [bstack11l11_opy_:]
    if bstack1l11111_opy_:
        bstack11lll1l_opy_ = unicode () .join ([unichr (ord (char) - bstack11l11ll_opy_ - (bstack11l111_opy_ + bstack11l1111_opy_) % bstack111ll1l_opy_) for bstack11l111_opy_, char in enumerate (bstack1l1ll11_opy_)])
    else:
        bstack11lll1l_opy_ = str () .join ([chr (ord (char) - bstack11l11ll_opy_ - (bstack11l111_opy_ + bstack11l1111_opy_) % bstack111ll1l_opy_) for bstack11l111_opy_, char in enumerate (bstack1l1ll11_opy_)])
    return eval (bstack11lll1l_opy_)
import os
import traceback
from typing import Dict, Tuple, Callable, Type, List, Any
from urllib.parse import urlparse
from browserstack_sdk.sdk_cli.bstack1lll111ll11_opy_ import (
    bstack1lll11lll11_opy_,
    bstack1lll111l111_opy_,
    bstack1lll111l1ll_opy_,
    bstack1lll1111l11_opy_,
)
import copy
from datetime import datetime, timezone, timedelta
from bstack_utils.bstack1111ll1l1_opy_ import bstack1ll111l1ll1_opy_
from bstack_utils.constants import EVENTS
class bstack1ll1llll11l_opy_(bstack1lll11lll11_opy_):
    bstack1l1111l111l_opy_ = bstack1l1l11_opy_ (u"ࠢࡃࡔࡒ࡛ࡘࡋࡒࡔࡖࡄࡇࡐࡥࡐࡍࡃࡗࡊࡔࡘࡍࡠࡋࡑࡈࡊ࡞ࠢᘊ")
    NAME = bstack1l1l11_opy_ (u"ࠣࡵࡨࡰࡪࡴࡩࡶ࡯ࠥᘋ")
    bstack1l11l1l11ll_opy_ = bstack1l1l11_opy_ (u"ࠤ࡫ࡹࡧࡥࡵࡳ࡮ࠥᘌ")
    bstack1l11l1l1ll1_opy_ = bstack1l1l11_opy_ (u"ࠥࡪࡷࡧ࡭ࡦࡹࡲࡶࡰࡥࡳࡦࡵࡶ࡭ࡴࡴ࡟ࡪࡦࠥᘍ")
    bstack11lll11lll1_opy_ = bstack1l1l11_opy_ (u"ࠦ࡮ࡴࡰࡶࡶࡢࡧࡦࡶࡡࡣ࡫࡯࡭ࡹ࡯ࡥࡴࠤᘎ")
    bstack1l11l11llll_opy_ = bstack1l1l11_opy_ (u"ࠧࡩࡡࡱࡣࡥ࡭ࡱ࡯ࡴࡪࡧࡶࠦᘏ")
    bstack1l1111ll11l_opy_ = bstack1l1l11_opy_ (u"ࠨࡩࡴࡡࡥࡶࡴࡽࡳࡦࡴࡶࡸࡦࡩ࡫ࡠࡪࡸࡦࠧᘐ")
    bstack11lll11l11l_opy_ = bstack1l1l11_opy_ (u"ࠢࡴࡶࡤࡶࡹ࡫ࡤࡠࡣࡷࠦᘑ")
    bstack11lll1l1111_opy_ = bstack1l1l11_opy_ (u"ࠣࡧࡱࡨࡪࡪ࡟ࡢࡶࠥᘒ")
    bstack1llll11ll1l_opy_ = bstack1l1l11_opy_ (u"ࠤࡳࡰࡦࡺࡦࡰࡴࡰࡣ࡮ࡴࡤࡦࡺࠥᘓ")
    bstack1l111l1ll1l_opy_ = bstack1l1l11_opy_ (u"ࠥࡲࡪࡽࡳࡦࡵࡶ࡭ࡴࡴࠢᘔ")
    bstack11lll11l111_opy_ = bstack1l1l11_opy_ (u"ࠦ࡬࡫ࡴࠣᘕ")
    bstack1l1l111111l_opy_ = bstack1l1l11_opy_ (u"ࠧࡹࡣࡳࡧࡨࡲࡸ࡮࡯ࡵࠤᘖ")
    bstack1l1111l1ll1_opy_ = bstack1l1l11_opy_ (u"ࠨࡷ࠴ࡥࡨࡼࡪࡩࡵࡵࡧࡶࡧࡷ࡯ࡰࡵࠤᘗ")
    bstack1l1111l11l1_opy_ = bstack1l1l11_opy_ (u"ࠢࡸ࠵ࡦࡩࡽ࡫ࡣࡶࡶࡨࡷࡨࡸࡩࡱࡶࡤࡷࡾࡴࡣࠣᘘ")
    bstack11lll11llll_opy_ = bstack1l1l11_opy_ (u"ࠣࡳࡸ࡭ࡹࠨᘙ")
    bstack1lllll11ll1_opy_: Dict[str, List[Callable]] = dict()
    bstack1l111l1l1ll_opy_: str
    platform_index: int
    options: Any
    desired_capabilities: Any
    bstack1ll1111ll1l_opy_: Any
    bstack1l1111l1l11_opy_: Dict
    def __init__(
        self,
        bstack1l111l1l1ll_opy_: str,
        platform_index: int,
        framework_name: str,
        framework_version: str,
        classes: List[Type],
        bstack1ll1111ll1l_opy_: Dict[str, Any],
        methods=[bstack1l1l11_opy_ (u"ࠤࡢࡣ࡮ࡴࡩࡵࡡࡢࠦᘚ"), bstack1l1l11_opy_ (u"ࠥࡷࡹࡧࡲࡵࡡࡶࡩࡸࡹࡩࡰࡰࠥᘛ"), bstack1l1l11_opy_ (u"ࠦࡪࡾࡥࡤࡷࡷࡩࠧᘜ"), bstack1l1l11_opy_ (u"ࠧࡷࡵࡪࡶࠥᘝ")],
    ):
        super().__init__(
            framework_name,
            framework_version,
            classes,
        )
        self.bstack1l111l1l1ll_opy_ = bstack1l111l1l1ll_opy_
        self.platform_index = platform_index
        self.bstack1lll111ll1l_opy_(methods)
        self.bstack1ll1111ll1l_opy_ = bstack1ll1111ll1l_opy_
    @staticmethod
    def session_id(target: object, strict=True):
        return bstack1lll11lll11_opy_.get_data(bstack1ll1llll11l_opy_.bstack1l11l1l1ll1_opy_, target, strict)
    @staticmethod
    def hub_url(target: object, strict=True):
        return bstack1lll11lll11_opy_.get_data(bstack1ll1llll11l_opy_.bstack1l11l1l11ll_opy_, target, strict)
    @staticmethod
    def bstack11lll11l1ll_opy_(target: object, strict=True):
        return bstack1lll11lll11_opy_.get_data(bstack1ll1llll11l_opy_.bstack11lll11lll1_opy_, target, strict)
    @staticmethod
    def capabilities(target: object, strict=True):
        return bstack1lll11lll11_opy_.get_data(bstack1ll1llll11l_opy_.bstack1l11l11llll_opy_, target, strict)
    @staticmethod
    def bstack1l1l1l1lll1_opy_(instance: bstack1lll111l111_opy_) -> bool:
        return bstack1lll11lll11_opy_.bstack1lll1llllll_opy_(instance, bstack1ll1llll11l_opy_.bstack1l1111ll11l_opy_, False)
    @staticmethod
    def bstack1l1lll1llll_opy_(instance: bstack1lll111l111_opy_, default_value=None):
        return bstack1lll11lll11_opy_.bstack1lll1llllll_opy_(instance, bstack1ll1llll11l_opy_.bstack1l11l1l11ll_opy_, default_value)
    @staticmethod
    def bstack1l1ll11lll1_opy_(instance: bstack1lll111l111_opy_, default_value=None):
        return bstack1lll11lll11_opy_.bstack1lll1llllll_opy_(instance, bstack1ll1llll11l_opy_.bstack1l11l11llll_opy_, default_value)
    @staticmethod
    def bstack1l1l1lll1ll_opy_(hub_url: str, bstack11lll11ll11_opy_=bstack1l1l11_opy_ (u"ࠨ࠮ࡣࡴࡲࡻࡸ࡫ࡲࡴࡶࡤࡧࡰ࠴ࡣࡰ࡯ࠥᘞ")):
        try:
            bstack11lll11l1l1_opy_ = str(urlparse(hub_url).netloc) if hub_url else None
            return bstack11lll11l1l1_opy_.endswith(bstack11lll11ll11_opy_)
        except:
            pass
        return False
    @staticmethod
    def bstack1l1l1lllll1_opy_(method_name: str):
        return method_name == bstack1l1l11_opy_ (u"ࠢࡦࡺࡨࡧࡺࡺࡥࠣᘟ")
    @staticmethod
    def bstack1l1llll1lll_opy_(method_name: str, *args):
        return (
            bstack1ll1llll11l_opy_.bstack1l1l1lllll1_opy_(method_name)
            and bstack1ll1llll11l_opy_.bstack1l111lll11l_opy_(*args) == bstack1ll1llll11l_opy_.bstack1l111l1ll1l_opy_
        )
    @staticmethod
    def bstack1l1ll1111ll_opy_(method_name: str, *args):
        if not bstack1ll1llll11l_opy_.bstack1l1l1lllll1_opy_(method_name):
            return False
        if not bstack1ll1llll11l_opy_.bstack1l1111l1ll1_opy_ in bstack1ll1llll11l_opy_.bstack1l111lll11l_opy_(*args):
            return False
        bstack1l1l1ll1l1l_opy_ = bstack1ll1llll11l_opy_.bstack1l1l1lll11l_opy_(*args)
        return bstack1l1l1ll1l1l_opy_ and bstack1l1l11_opy_ (u"ࠣࡵࡦࡶ࡮ࡶࡴࠣᘠ") in bstack1l1l1ll1l1l_opy_ and bstack1l1l11_opy_ (u"ࠤࡥࡶࡴࡽࡳࡦࡴࡶࡸࡦࡩ࡫ࡠࡧࡻࡩࡨࡻࡴࡰࡴࠥᘡ") in bstack1l1l1ll1l1l_opy_[bstack1l1l11_opy_ (u"ࠥࡷࡨࡸࡩࡱࡶࠥᘢ")]
    @staticmethod
    def bstack1l1lll1lll1_opy_(method_name: str, *args):
        if not bstack1ll1llll11l_opy_.bstack1l1l1lllll1_opy_(method_name):
            return False
        if not bstack1ll1llll11l_opy_.bstack1l1111l1ll1_opy_ in bstack1ll1llll11l_opy_.bstack1l111lll11l_opy_(*args):
            return False
        bstack1l1l1ll1l1l_opy_ = bstack1ll1llll11l_opy_.bstack1l1l1lll11l_opy_(*args)
        return (
            bstack1l1l1ll1l1l_opy_
            and bstack1l1l11_opy_ (u"ࠦࡸࡩࡲࡪࡲࡷࠦᘣ") in bstack1l1l1ll1l1l_opy_
            and bstack1l1l11_opy_ (u"ࠧࡨࡲࡰࡹࡶࡩࡷࡹࡴࡢࡥ࡮ࡣࡦࡩࡣࡦࡵࡶ࡭ࡧ࡯࡬ࡪࡶࡼࡣࡦࡻࡴࡰ࡯ࡤࡸ࡮ࡵ࡮ࡠࡵࡦࡶ࡮ࡶࡴࠣᘤ") in bstack1l1l1ll1l1l_opy_[bstack1l1l11_opy_ (u"ࠨࡳࡤࡴ࡬ࡴࡹࠨᘥ")]
        )
    @staticmethod
    def bstack1l111lll11l_opy_(*args):
        return str(bstack1ll1llll11l_opy_.bstack1l1llll11l1_opy_(*args)).lower()
    @staticmethod
    def bstack1l1llll11l1_opy_(*args):
        return args[0] if args and type(args) in [list, tuple] and isinstance(args[0], str) else None
    @staticmethod
    def bstack1l1l1lll11l_opy_(*args):
        return args[1] if len(args) > 1 and isinstance(args[1], dict) else None
    @staticmethod
    def bstack1l11l111ll_opy_(driver):
        command_executor = getattr(driver, bstack1l1l11_opy_ (u"ࠢࡤࡱࡰࡱࡦࡴࡤࡠࡧࡻࡩࡨࡻࡴࡰࡴࠥᘦ"), None)
        if not command_executor:
            return None
        hub_url = str(command_executor) if isinstance(command_executor, (str, bytes)) else None
        hub_url = str(command_executor._url) if not hub_url and getattr(command_executor, bstack1l1l11_opy_ (u"ࠣࡡࡸࡶࡱࠨᘧ"), None) else None
        if not hub_url:
            client_config = getattr(command_executor, bstack1l1l11_opy_ (u"ࠤࡢࡧࡱ࡯ࡥ࡯ࡶࡢࡧࡴࡴࡦࡪࡩࠥᘨ"), None)
            if not client_config:
                return None
            hub_url = getattr(client_config, bstack1l1l11_opy_ (u"ࠥࡶࡪࡳ࡯ࡵࡧࡢࡷࡪࡸࡶࡦࡴࡢࡥࡩࡪࡲࠣᘩ"), None)
        return hub_url
    def bstack1l111ll1111_opy_(self, instance, driver, hub_url: str):
        result = False
        if not hub_url:
            return result
        command_executor = getattr(driver, bstack1l1l11_opy_ (u"ࠦࡨࡵ࡭࡮ࡣࡱࡨࡤ࡫ࡸࡦࡥࡸࡸࡴࡸࠢᘪ"), None)
        if command_executor:
            if isinstance(command_executor, (str, bytes)):
                setattr(driver, bstack1l1l11_opy_ (u"ࠧࡩ࡯࡮࡯ࡤࡲࡩࡥࡥࡹࡧࡦࡹࡹࡵࡲࠣᘫ"), hub_url)
                result = True
            elif hasattr(command_executor, bstack1l1l11_opy_ (u"ࠨ࡟ࡶࡴ࡯ࠦᘬ")):
                setattr(command_executor, bstack1l1l11_opy_ (u"ࠢࡠࡷࡵࡰࠧᘭ"), hub_url)
                result = True
        if result:
            self.bstack1l111l1l1ll_opy_ = hub_url
            bstack1ll1llll11l_opy_.bstack1lllll1l11l_opy_(instance, bstack1ll1llll11l_opy_.bstack1l11l1l11ll_opy_, hub_url)
            bstack1ll1llll11l_opy_.bstack1lllll1l11l_opy_(
                instance, bstack1ll1llll11l_opy_.bstack1l1111ll11l_opy_, bstack1ll1llll11l_opy_.bstack1l1l1lll1ll_opy_(hub_url)
            )
        return result
    @staticmethod
    def bstack1lll1l1ll11_opy_(bstack1llll1111ll_opy_: Tuple[bstack1lll111l1ll_opy_, bstack1lll1111l11_opy_]):
        return bstack1l1l11_opy_ (u"ࠣ࠼ࠥᘮ").join((bstack1lll111l1ll_opy_(bstack1llll1111ll_opy_[0]).name, bstack1lll1111l11_opy_(bstack1llll1111ll_opy_[1]).name))
    @staticmethod
    def bstack1llll1lll1l_opy_(bstack1llll1111ll_opy_: Tuple[bstack1lll111l1ll_opy_, bstack1lll1111l11_opy_], callback: Callable):
        bstack1lll1l1l1l1_opy_ = bstack1ll1llll11l_opy_.bstack1lll1l1ll11_opy_(bstack1llll1111ll_opy_)
        if not bstack1lll1l1l1l1_opy_ in bstack1ll1llll11l_opy_.bstack1lllll11ll1_opy_:
            bstack1ll1llll11l_opy_.bstack1lllll11ll1_opy_[bstack1lll1l1l1l1_opy_] = []
        bstack1ll1llll11l_opy_.bstack1lllll11ll1_opy_[bstack1lll1l1l1l1_opy_].append(callback)
    def bstack1lll11lllll_opy_(self, instance: bstack1lll111l111_opy_, method_name: str, bstack1lll11111l1_opy_: timedelta, *args, **kwargs):
        if not instance or method_name in (bstack1l1l11_opy_ (u"ࠤࡶࡸࡦࡸࡴࡠࡵࡨࡷࡸ࡯࡯࡯ࠤᘯ")):
            return
        cmd = args[0] if method_name == bstack1l1l11_opy_ (u"ࠥࡩࡽ࡫ࡣࡶࡶࡨࠦᘰ") and args and type(args) in [list, tuple] and isinstance(args[0], str) else None
        bstack11lll11ll1l_opy_ = bstack1l1l11_opy_ (u"ࠦ࠿ࠨᘱ").join(map(str, filter(None, [method_name, cmd])))
        instance.bstack1lllll111_opy_(bstack1l1l11_opy_ (u"ࠧࡪࡲࡪࡸࡨࡶ࠿ࠨᘲ") + bstack11lll11ll1l_opy_, bstack1lll11111l1_opy_)
    def bstack1lll11ll1l1_opy_(
        self,
        target: object,
        exec: Tuple[bstack1lll111l111_opy_, str],
        bstack1llll1111ll_opy_: Tuple[bstack1lll111l1ll_opy_, bstack1lll1111l11_opy_],
        result: Any,
        *args,
        **kwargs,
    ) -> Callable[..., Any]:
        instance, method_name = exec
        bstack1lll11l11l1_opy_, bstack1l1111l1111_opy_ = bstack1llll1111ll_opy_
        bstack1lll1l1l1l1_opy_ = bstack1ll1llll11l_opy_.bstack1lll1l1ll11_opy_(bstack1llll1111ll_opy_)
        self.logger.debug(bstack1l1l11_opy_ (u"ࠨ࡯࡯ࡡ࡫ࡳࡴࡱ࠺ࠡ࡯ࡨࡸ࡭ࡵࡤࡠࡰࡤࡱࡪࡃࡻ࡮ࡧࡷ࡬ࡴࡪ࡟࡯ࡣࡰࡩࢂࠦࡨࡰࡱ࡮ࡣ࡮ࡴࡦࡰ࠿ࡾ࡬ࡴࡵ࡫ࡠ࡫ࡱࡪࡴࢃࠠࡢࡴࡪࡷࡂࢁࡡࡳࡩࡶࢁࠥࡱࡷࡢࡴࡪࡷࡂࠨᘳ") + str(kwargs) + bstack1l1l11_opy_ (u"ࠢࠣᘴ"))
        if bstack1lll11l11l1_opy_ == bstack1lll111l1ll_opy_.QUIT:
            if bstack1l1111l1111_opy_ == bstack1lll1111l11_opy_.PRE:
                bstack1l1ll1ll111_opy_ = bstack1ll111l1ll1_opy_.bstack1l1ll1ll1ll_opy_(EVENTS.bstack11ll1111ll_opy_.value)
                bstack1lll11lll11_opy_.bstack1lllll1l11l_opy_(instance, EVENTS.bstack11ll1111ll_opy_.value, bstack1l1ll1ll111_opy_)
                self.logger.debug(bstack1l1l11_opy_ (u"ࠣ࡫ࡱࡷࡹࡧ࡮ࡤࡧࡀࡿࢂࠦ࡭ࡦࡶ࡫ࡳࡩࡥ࡮ࡢ࡯ࡨࡁࢀࢃࠠࡧࡴࡤࡱࡪࡽ࡯ࡳ࡭ࡢࡷࡹࡧࡴࡦ࠿ࡾࢁࠥ࡮࡯ࡰ࡭ࡢࡷࡹࡧࡴࡦ࠿ࡾࢁࠧᘵ").format(instance, method_name, bstack1lll11l11l1_opy_, bstack1l1111l1111_opy_))
        if bstack1lll11l11l1_opy_ == bstack1lll111l1ll_opy_.bstack1lll111111l_opy_:
            if bstack1l1111l1111_opy_ == bstack1lll1111l11_opy_.POST and not bstack1ll1llll11l_opy_.bstack1l11l1l1ll1_opy_ in instance.data:
                session_id = getattr(target, bstack1l1l11_opy_ (u"ࠤࡶࡩࡸࡹࡩࡰࡰࡢ࡭ࡩࠨᘶ"), None)
                if session_id:
                    instance.data[bstack1ll1llll11l_opy_.bstack1l11l1l1ll1_opy_] = session_id
        elif (
            bstack1lll11l11l1_opy_ == bstack1lll111l1ll_opy_.bstack1lll11l1l1l_opy_
            and bstack1ll1llll11l_opy_.bstack1l111lll11l_opy_(*args) == bstack1ll1llll11l_opy_.bstack1l111l1ll1l_opy_
        ):
            if bstack1l1111l1111_opy_ == bstack1lll1111l11_opy_.PRE:
                hub_url = bstack1ll1llll11l_opy_.bstack1l11l111ll_opy_(target)
                if hub_url:
                    instance.data.update(
                        {
                            bstack1ll1llll11l_opy_.bstack1l11l1l11ll_opy_: hub_url,
                            bstack1ll1llll11l_opy_.bstack1l1111ll11l_opy_: bstack1ll1llll11l_opy_.bstack1l1l1lll1ll_opy_(hub_url),
                            bstack1ll1llll11l_opy_.bstack1llll11ll1l_opy_: int(
                                os.environ.get(bstack1l1l11_opy_ (u"ࠥࡆࡗࡕࡗࡔࡇࡕࡗ࡙ࡇࡃࡌࡡࡓࡐࡆ࡚ࡆࡐࡔࡐࡣࡎࡔࡄࡆ࡚ࠥᘷ"), str(self.platform_index))
                            ),
                        }
                    )
                bstack1l1l1ll1l1l_opy_ = bstack1ll1llll11l_opy_.bstack1l1l1lll11l_opy_(*args)
                bstack11lll11l1ll_opy_ = bstack1l1l1ll1l1l_opy_.get(bstack1l1l11_opy_ (u"ࠦࡨࡧࡰࡢࡤ࡬ࡰ࡮ࡺࡩࡦࡵࠥᘸ"), None) if bstack1l1l1ll1l1l_opy_ else None
                if isinstance(bstack11lll11l1ll_opy_, dict):
                    instance.data[bstack1ll1llll11l_opy_.bstack11lll11lll1_opy_] = copy.deepcopy(bstack11lll11l1ll_opy_)
                    instance.data[bstack1ll1llll11l_opy_.bstack1l11l11llll_opy_] = bstack11lll11l1ll_opy_
            elif bstack1l1111l1111_opy_ == bstack1lll1111l11_opy_.POST:
                if isinstance(result, dict):
                    framework_session_id = result.get(bstack1l1l11_opy_ (u"ࠧࡼࡡ࡭ࡷࡨࠦᘹ"), dict()).get(bstack1l1l11_opy_ (u"ࠨࡳࡦࡵࡶ࡭ࡴࡴࡉࡥࠤᘺ"), None)
                    if framework_session_id:
                        instance.data.update(
                            {
                                bstack1ll1llll11l_opy_.bstack1l11l1l1ll1_opy_: framework_session_id,
                                bstack1ll1llll11l_opy_.bstack11lll11l11l_opy_: datetime.now(tz=timezone.utc),
                            }
                        )
        elif (
            bstack1lll11l11l1_opy_ == bstack1lll111l1ll_opy_.bstack1lll11l1l1l_opy_
            and bstack1ll1llll11l_opy_.bstack1l111lll11l_opy_(*args) == bstack1ll1llll11l_opy_.bstack11lll11llll_opy_
            and bstack1l1111l1111_opy_ == bstack1lll1111l11_opy_.POST
        ):
            instance.data[bstack1ll1llll11l_opy_.bstack11lll1l1111_opy_] = datetime.now(tz=timezone.utc)
        if bstack1lll1l1l1l1_opy_ in bstack1ll1llll11l_opy_.bstack1lllll11ll1_opy_:
            bstack1l1111l11ll_opy_ = None
            for callback in bstack1ll1llll11l_opy_.bstack1lllll11ll1_opy_[bstack1lll1l1l1l1_opy_]:
                try:
                    bstack1l1111l1l1l_opy_ = callback(self, target, exec, bstack1llll1111ll_opy_, result, *args, **kwargs)
                    if bstack1l1111l11ll_opy_ == None:
                        bstack1l1111l11ll_opy_ = bstack1l1111l1l1l_opy_
                except Exception as e:
                    self.logger.error(bstack1l1l11_opy_ (u"ࠢࡦࡴࡵࡳࡷࠦࡩ࡯ࡸࡲ࡯࡮ࡴࡧࠡࡥࡤࡰࡱࡨࡡࡤ࡭࠽ࠤࠧᘻ") + str(e) + bstack1l1l11_opy_ (u"ࠣࠤᘼ"))
                    traceback.print_exc()
            if bstack1lll11l11l1_opy_ == bstack1lll111l1ll_opy_.QUIT:
                if bstack1l1111l1111_opy_ == bstack1lll1111l11_opy_.POST:
                    bstack1l1ll1ll111_opy_ = bstack1lll11lll11_opy_.bstack1lll1llllll_opy_(instance, EVENTS.bstack11ll1111ll_opy_.value)
                    if bstack1l1ll1ll111_opy_!=None:
                        bstack1ll111l1ll1_opy_.end(EVENTS.bstack11ll1111ll_opy_.value, bstack1l1ll1ll111_opy_+bstack1l1l11_opy_ (u"ࠤ࠽ࡷࡹࡧࡲࡵࠤᘽ"), bstack1l1ll1ll111_opy_+bstack1l1l11_opy_ (u"ࠥ࠾ࡪࡴࡤࠣᘾ"), True, None)
            if bstack1l1111l1111_opy_ == bstack1lll1111l11_opy_.PRE and callable(bstack1l1111l11ll_opy_):
                return bstack1l1111l11ll_opy_
            elif bstack1l1111l1111_opy_ == bstack1lll1111l11_opy_.POST and bstack1l1111l11ll_opy_:
                return bstack1l1111l11ll_opy_
    def bstack1lll11l1ll1_opy_(
        self, method_name, previous_state: bstack1lll111l1ll_opy_, *args, **kwargs
    ) -> bstack1lll111l1ll_opy_:
        if method_name == bstack1l1l11_opy_ (u"ࠦࡤࡥࡩ࡯࡫ࡷࡣࡤࠨᘿ") or method_name == bstack1l1l11_opy_ (u"ࠧࡹࡴࡢࡴࡷࡣࡸ࡫ࡳࡴ࡫ࡲࡲࠧᙀ"):
            return bstack1lll111l1ll_opy_.bstack1lll111111l_opy_
        if method_name == bstack1l1l11_opy_ (u"ࠨࡱࡶ࡫ࡷࠦᙁ"):
            return bstack1lll111l1ll_opy_.QUIT
        if method_name == bstack1l1l11_opy_ (u"ࠢࡦࡺࡨࡧࡺࡺࡥࠣᙂ"):
            if previous_state != bstack1lll111l1ll_opy_.NONE:
                command_name = bstack1ll1llll11l_opy_.bstack1l111lll11l_opy_(*args)
                if command_name == bstack1ll1llll11l_opy_.bstack1l111l1ll1l_opy_:
                    return bstack1lll111l1ll_opy_.bstack1lll111111l_opy_
            return bstack1lll111l1ll_opy_.bstack1lll11l1l1l_opy_
        return bstack1lll111l1ll_opy_.NONE