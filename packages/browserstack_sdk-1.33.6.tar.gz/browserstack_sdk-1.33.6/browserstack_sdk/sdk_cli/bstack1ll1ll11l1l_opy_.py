# coding: UTF-8
import sys
bstack1l11111_opy_ = sys.version_info [0] == 2
bstack11l11ll_opy_ = 2048
bstack111ll1l_opy_ = 7
def bstack1l1l11_opy_ (bstack11l1l_opy_):
    global bstack1l11_opy_
    bstack11l1111_opy_ = ord (bstack11l1l_opy_ [-1])
    bstack1l1ll1l_opy_ = bstack11l1l_opy_ [:-1]
    bstack11l11_opy_ = bstack11l1111_opy_ % len (bstack1l1ll1l_opy_)
    bstack1l1ll11_opy_ = bstack1l1ll1l_opy_ [:bstack11l11_opy_] + bstack1l1ll1l_opy_ [bstack11l11_opy_:]
    if bstack1l11111_opy_:
        bstack11lll1l_opy_ = unicode () .join ([unichr (ord (char) - bstack11l11ll_opy_ - (bstack11l111_opy_ + bstack11l1111_opy_) % bstack111ll1l_opy_) for bstack11l111_opy_, char in enumerate (bstack1l1ll11_opy_)])
    else:
        bstack11lll1l_opy_ = str () .join ([chr (ord (char) - bstack11l11ll_opy_ - (bstack11l111_opy_ + bstack11l1111_opy_) % bstack111ll1l_opy_) for bstack11l111_opy_, char in enumerate (bstack1l1ll11_opy_)])
    return eval (bstack11lll1l_opy_)
from typing import Dict, List, Any, Callable, Tuple, Union
from browserstack_sdk import sdk_pb2 as structs
from browserstack_sdk.sdk_cli.bstack1ll11l111l1_opy_ import bstack1ll1l1lllll_opy_
from browserstack_sdk.sdk_cli.bstack1lll111ll11_opy_ import (
    bstack1lll111l1ll_opy_,
    bstack1lll1111l11_opy_,
    bstack1lll111l111_opy_,
)
from bstack_utils.helper import  bstack1lll11ll1l_opy_
from browserstack_sdk.sdk_cli.bstack1ll111l1111_opy_ import bstack1ll1llll11l_opy_
from browserstack_sdk.sdk_cli.test_framework import TestFramework, bstack1llll111lll_opy_, bstack1lllll111l1_opy_, bstack1llll1ll111_opy_, bstack1lllll111ll_opy_
from typing import Tuple, Any
import threading
from bstack_utils.bstack1llllll111_opy_ import bstack11ll1l11ll_opy_
from browserstack_sdk.sdk_cli.bstack1ll1l1l111l_opy_ import bstack1ll1l111l1l_opy_
from bstack_utils.percy import bstack1l1llll11l_opy_
from bstack_utils.percy_sdk import PercySDK
from bstack_utils.constants import *
import re
class bstack1ll1ll1l1l1_opy_(bstack1ll1l1lllll_opy_):
    def __init__(self, bstack1l11ll11ll1_opy_: Dict[str, str]):
        super().__init__()
        self.bstack1l11ll11ll1_opy_ = bstack1l11ll11ll1_opy_
        self.percy = bstack1l1llll11l_opy_()
        self.bstack11l111l1l_opy_ = bstack11ll1l11ll_opy_()
        self.bstack1l11ll1l111_opy_()
        bstack1ll1llll11l_opy_.bstack1llll1lll1l_opy_((bstack1lll111l1ll_opy_.bstack1lll11l1l1l_opy_, bstack1lll1111l11_opy_.PRE), self.bstack1l11ll1l1ll_opy_)
        TestFramework.bstack1llll1lll1l_opy_((bstack1llll111lll_opy_.TEST, bstack1llll1ll111_opy_.POST), self.bstack1l1ll1l11ll_opy_)
    def is_enabled(self) -> bool:
        return True
    def bstack1l1l11l11ll_opy_(self, instance: bstack1lll111l111_opy_, driver: object):
        bstack1l1l11l111l_opy_ = TestFramework.bstack1lll1llll11_opy_(instance.context)
        for t in bstack1l1l11l111l_opy_:
            bstack1l11llll1l1_opy_ = TestFramework.bstack1lll1llllll_opy_(t, bstack1ll1l111l1l_opy_.bstack1l1l111l11l_opy_, [])
            if any(instance is d[1] for d in bstack1l11llll1l1_opy_) or instance == driver:
                return t
    def bstack1l11ll1l1ll_opy_(
        self,
        f: bstack1ll1llll11l_opy_,
        driver: object,
        exec: Tuple[bstack1lll111l111_opy_, str],
        bstack1llll1111ll_opy_: Tuple[bstack1lll111l1ll_opy_, bstack1lll1111l11_opy_],
        result: Any,
        *args,
        **kwargs,
    ):
        try:
            instance, method_name = exec
            if not bstack1ll1llll11l_opy_.bstack1l1l1lllll1_opy_(method_name):
                return
            platform_index = f.bstack1lll1llllll_opy_(instance, bstack1ll1llll11l_opy_.bstack1llll11ll1l_opy_, 0)
            bstack1l11llll1ll_opy_ = self.bstack1l1l11l11ll_opy_(instance, driver)
            bstack1l11ll11l11_opy_ = TestFramework.bstack1lll1llllll_opy_(bstack1l11llll1ll_opy_, TestFramework.bstack1lll1lllll1_opy_, None)
            if not bstack1l11ll11l11_opy_:
                self.logger.debug(bstack1l1l11_opy_ (u"ࠨ࡯࡯ࡡࡳࡶࡪࡥࡥࡹࡧࡦࡹࡹ࡫࠺ࠡࡴࡨࡸࡺࡸ࡮ࡪࡰࡪࠤࡦࡹࠠࡴࡧࡶࡷ࡮ࡵ࡮ࠡ࡫ࡶࠤࡳࡵࡴࠡࡻࡨࡸࠥࡹࡴࡢࡴࡷࡩࡩࠨ፩"))
                return
            driver_command = f.bstack1l1llll11l1_opy_(*args)
            for command in bstack111lllll_opy_:
                if command == driver_command:
                    self.bstack11l1l111l_opy_(driver, platform_index)
            bstack1lll11llll_opy_ = self.percy.bstack11l1ll1ll1_opy_()
            if driver_command in bstack1l11ll11ll_opy_[bstack1lll11llll_opy_]:
                self.bstack11l111l1l_opy_.bstack1ll1lllll1_opy_(bstack1l11ll11l11_opy_, driver_command)
        except Exception as e:
            self.logger.error(bstack1l1l11_opy_ (u"ࠢࡰࡰࡢࡴࡷ࡫࡟ࡦࡺࡨࡧࡺࡺࡥ࠻ࠢࡨࡶࡷࡵࡲࠣ፪"), e)
    def bstack1l1ll1l11ll_opy_(
        self,
        f: TestFramework,
        instance: bstack1lllll111l1_opy_,
        bstack1llll1111ll_opy_: Tuple[bstack1llll111lll_opy_, bstack1llll1ll111_opy_],
        *args,
        **kwargs,
    ):
        from bstack_utils.bstack1111ll1l1_opy_ import bstack1ll111l1ll1_opy_
        bstack1l11llll1l1_opy_ = f.bstack1lll1llllll_opy_(instance, bstack1ll1l111l1l_opy_.bstack1l1l111l11l_opy_, [])
        if not bstack1l11llll1l1_opy_:
            self.logger.debug(bstack1l1l11_opy_ (u"ࠣࡱࡱࡣࡦ࡬ࡴࡦࡴࡢࡸࡪࡹࡴ࠻ࠢࡱࡳࠥࡪࡲࡪࡸࡨࡶࡸࠦࡦࡰࡴࠣ࡬ࡴࡵ࡫ࡠ࡫ࡱࡪࡴࡃࡻࡩࡱࡲ࡯ࡤ࡯࡮ࡧࡱࢀࠤࡦࡸࡧࡴ࠿ࡾࡥࡷ࡭ࡳࡾࠢ࡮ࡻࡦࡸࡧࡴ࠿ࠥ፫") + str(kwargs) + bstack1l1l11_opy_ (u"ࠤࠥ፬"))
            return
        if len(bstack1l11llll1l1_opy_) > 1:
            self.logger.debug(bstack1l1l11_opy_ (u"ࠥࡳࡳࡥࡡࡧࡶࡨࡶࡤࡺࡥࡴࡶ࠽ࠤࢀࡲࡥ࡯ࠪࡧࡶ࡮ࡼࡥࡳࡡ࡬ࡲࡸࡺࡡ࡯ࡥࡨࡷ࠮ࢃࠠࡥࡴ࡬ࡺࡪࡸࡳࠡࡨࡲࡶࠥ࡮࡯ࡰ࡭ࡢ࡭ࡳ࡬࡯࠾ࡽ࡫ࡳࡴࡱ࡟ࡪࡰࡩࡳࢂࠦࡡࡳࡩࡶࡁࢀࡧࡲࡨࡵࢀࠤࡰࡽࡡࡳࡩࡶࡁࠧ፭") + str(kwargs) + bstack1l1l11_opy_ (u"ࠦࠧ፮"))
        bstack1l11ll1l11l_opy_, bstack1l11ll11lll_opy_ = bstack1l11llll1l1_opy_[0]
        driver = bstack1l11ll1l11l_opy_()
        if not driver:
            self.logger.debug(bstack1l1l11_opy_ (u"ࠧࡵ࡮ࡠࡣࡩࡸࡪࡸ࡟ࡵࡧࡶࡸ࠿ࠦ࡮ࡰࠢࡧࡶ࡮ࡼࡥࡳࠢࡩࡳࡷࠦࡨࡰࡱ࡮ࡣ࡮ࡴࡦࡰ࠿ࡾ࡬ࡴࡵ࡫ࡠ࡫ࡱࡪࡴࢃࠠࡢࡴࡪࡷࡂࢁࡡࡳࡩࡶࢁࠥࡱࡷࡢࡴࡪࡷࡂࠨ፯") + str(kwargs) + bstack1l1l11_opy_ (u"ࠨࠢ፰"))
            return
        bstack1l11ll1ll11_opy_ = {
            TestFramework.bstack1llll11l1ll_opy_: bstack1l1l11_opy_ (u"ࠢࡵࡧࡶࡸࠥࡴࡡ࡮ࡧࠥ፱"),
            TestFramework.bstack1llll1l1ll1_opy_: bstack1l1l11_opy_ (u"ࠣࡶࡨࡷࡹࠦࡵࡶ࡫ࡧࠦ፲"),
            TestFramework.bstack1lll1lllll1_opy_: bstack1l1l11_opy_ (u"ࠤࡷࡩࡸࡺࠠࡳࡧࡵࡹࡳࠦ࡮ࡢ࡯ࡨࠦ፳")
        }
        bstack1l11ll11l1l_opy_ = { key: f.bstack1lll1llllll_opy_(instance, key) for key in bstack1l11ll1ll11_opy_ }
        bstack1l11ll1l1l1_opy_ = [key for key, value in bstack1l11ll11l1l_opy_.items() if not value]
        if bstack1l11ll1l1l1_opy_:
            for key in bstack1l11ll1l1l1_opy_:
                self.logger.debug(bstack1l1l11_opy_ (u"ࠥࡳࡳࡥࡡࡧࡶࡨࡶࡤࡺࡥࡴࡶ࠽ࠤࡲ࡯ࡳࡴ࡫ࡱ࡫ࠥࠨ፴") + str(key) + bstack1l1l11_opy_ (u"ࠦࠧ፵"))
            return
        platform_index = f.bstack1lll1llllll_opy_(instance, bstack1ll1llll11l_opy_.bstack1llll11ll1l_opy_, 0)
        if self.bstack1l11ll11ll1_opy_.percy_capture_mode == bstack1l1l11_opy_ (u"ࠧࡺࡥࡴࡶࡦࡥࡸ࡫ࠢ፶"):
            bstack1ll11111_opy_ = bstack1l11ll11l1l_opy_.get(TestFramework.bstack1lll1lllll1_opy_) + bstack1l1l11_opy_ (u"ࠨ࠭ࡵࡧࡶࡸࡨࡧࡳࡦࠤ፷")
            bstack1l1ll1ll111_opy_ = bstack1ll111l1ll1_opy_.bstack1l1ll1ll1ll_opy_(EVENTS.bstack1l11ll1ll1l_opy_.value)
            PercySDK.screenshot(
                driver,
                bstack1ll11111_opy_,
                bstack11l11ll1_opy_=bstack1l11ll11l1l_opy_[TestFramework.bstack1llll11l1ll_opy_],
                bstack1ll1l1l11l_opy_=bstack1l11ll11l1l_opy_[TestFramework.bstack1llll1l1ll1_opy_],
                bstack11ll1l1111_opy_=platform_index
            )
            bstack1ll111l1ll1_opy_.end(EVENTS.bstack1l11ll1ll1l_opy_.value, bstack1l1ll1ll111_opy_+bstack1l1l11_opy_ (u"ࠢ࠻ࡵࡷࡥࡷࡺࠢ፸"), bstack1l1ll1ll111_opy_+bstack1l1l11_opy_ (u"ࠣ࠼ࡨࡲࡩࠨ፹"), True, None, None, None, None, test_name=bstack1ll11111_opy_)
    def bstack11l1l111l_opy_(self, driver, platform_index):
        if self.bstack11l111l1l_opy_.bstack1ll1l1ll1_opy_() is True or self.bstack11l111l1l_opy_.capturing() is True:
            return
        self.bstack11l111l1l_opy_.bstack11111111_opy_()
        while not self.bstack11l111l1l_opy_.bstack1ll1l1ll1_opy_():
            bstack1l11ll11l11_opy_ = self.bstack11l111l1l_opy_.bstack11l111ll11_opy_()
            self.bstack1l1l11lll1_opy_(driver, bstack1l11ll11l11_opy_, platform_index)
        self.bstack11l111l1l_opy_.bstack11l111llll_opy_()
    def bstack1l1l11lll1_opy_(self, driver, bstack1ll1ll1l_opy_, platform_index, test=None):
        from bstack_utils.bstack1111ll1l1_opy_ import bstack1ll111l1ll1_opy_
        bstack1l1ll1ll111_opy_ = bstack1ll111l1ll1_opy_.bstack1l1ll1ll1ll_opy_(EVENTS.bstack1l11l1ll1l_opy_.value)
        if test != None:
            bstack11l11ll1_opy_ = getattr(test, bstack1l1l11_opy_ (u"ࠩࡱࡥࡲ࡫ࠧ፺"), None)
            bstack1ll1l1l11l_opy_ = getattr(test, bstack1l1l11_opy_ (u"ࠪࡹࡺ࡯ࡤࠨ፻"), None)
            PercySDK.screenshot(driver, bstack1ll1ll1l_opy_, bstack11l11ll1_opy_=bstack11l11ll1_opy_, bstack1ll1l1l11l_opy_=bstack1ll1l1l11l_opy_, bstack11ll1l1111_opy_=platform_index)
        else:
            PercySDK.screenshot(driver, bstack1ll1ll1l_opy_)
        bstack1ll111l1ll1_opy_.end(EVENTS.bstack1l11l1ll1l_opy_.value, bstack1l1ll1ll111_opy_+bstack1l1l11_opy_ (u"ࠦ࠿ࡹࡴࡢࡴࡷࠦ፼"), bstack1l1ll1ll111_opy_+bstack1l1l11_opy_ (u"ࠧࡀࡥ࡯ࡦࠥ፽"), True, None, None, None, None, test_name=bstack1ll1ll1l_opy_)
    def bstack1l11ll1l111_opy_(self):
        os.environ[bstack1l1l11_opy_ (u"࠭ࡂࡓࡑ࡚ࡗࡊࡘࡓࡕࡃࡆࡏࡤࡖࡅࡓࡅ࡜ࠫ፾")] = str(self.bstack1l11ll11ll1_opy_.success)
        os.environ[bstack1l1l11_opy_ (u"ࠧࡃࡔࡒ࡛ࡘࡋࡒࡔࡖࡄࡇࡐࡥࡐࡆࡔࡆ࡝ࡤࡉࡁࡑࡖࡘࡖࡊࡥࡍࡐࡆࡈࠫ፿")] = str(self.bstack1l11ll11ll1_opy_.percy_capture_mode)
        self.percy.bstack1l11ll111ll_opy_(self.bstack1l11ll11ll1_opy_.is_percy_auto_enabled)
        self.percy.bstack1l11ll111l1_opy_(self.bstack1l11ll11ll1_opy_.percy_build_id)