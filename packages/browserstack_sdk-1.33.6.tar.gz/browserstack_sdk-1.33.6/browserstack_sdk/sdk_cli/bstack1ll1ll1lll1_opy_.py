# coding: UTF-8
import sys
bstack1l11111_opy_ = sys.version_info [0] == 2
bstack11l11ll_opy_ = 2048
bstack111ll1l_opy_ = 7
def bstack1l1l11_opy_ (bstack11l1l_opy_):
    global bstack1l11_opy_
    bstack11l1111_opy_ = ord (bstack11l1l_opy_ [-1])
    bstack1l1ll1l_opy_ = bstack11l1l_opy_ [:-1]
    bstack11l11_opy_ = bstack11l1111_opy_ % len (bstack1l1ll1l_opy_)
    bstack1l1ll11_opy_ = bstack1l1ll1l_opy_ [:bstack11l11_opy_] + bstack1l1ll1l_opy_ [bstack11l11_opy_:]
    if bstack1l11111_opy_:
        bstack11lll1l_opy_ = unicode () .join ([unichr (ord (char) - bstack11l11ll_opy_ - (bstack11l111_opy_ + bstack11l1111_opy_) % bstack111ll1l_opy_) for bstack11l111_opy_, char in enumerate (bstack1l1ll11_opy_)])
    else:
        bstack11lll1l_opy_ = str () .join ([chr (ord (char) - bstack11l11ll_opy_ - (bstack11l111_opy_ + bstack11l1111_opy_) % bstack111ll1l_opy_) for bstack11l111_opy_, char in enumerate (bstack1l1ll11_opy_)])
    return eval (bstack11lll1l_opy_)
from browserstack_sdk.sdk_cli.bstack1ll11l111l1_opy_ import bstack1ll1l1lllll_opy_
from browserstack_sdk.sdk_cli.bstack1lll111ll11_opy_ import (
    bstack1lll111l1ll_opy_,
    bstack1lll1111l11_opy_,
    bstack1lll111l111_opy_,
)
from browserstack_sdk.sdk_cli.bstack1ll111l1111_opy_ import bstack1ll1llll11l_opy_
from typing import Tuple, Callable, Any
import grpc
from browserstack_sdk import sdk_pb2 as structs
from browserstack_sdk.sdk_cli.bstack1ll11l111l1_opy_ import bstack1ll1l1lllll_opy_
from bstack_utils.measure import measure
from bstack_utils.constants import *
import traceback
import os
import time
class bstack1ll1lll1ll1_opy_(bstack1ll1l1lllll_opy_):
    bstack1l1llll111l_opy_ = False
    def __init__(self):
        super().__init__()
        bstack1ll1llll11l_opy_.bstack1llll1lll1l_opy_((bstack1lll111l1ll_opy_.bstack1lll11l1l1l_opy_, bstack1lll1111l11_opy_.PRE), self.bstack1l1l1ll1ll1_opy_)
    def is_enabled(self) -> bool:
        return True
    def bstack1l1l1ll1ll1_opy_(
        self,
        f: bstack1ll1llll11l_opy_,
        driver: object,
        exec: Tuple[bstack1lll111l111_opy_, str],
        bstack1llll1111ll_opy_: Tuple[bstack1lll111l1ll_opy_, bstack1lll1111l11_opy_],
        result: Any,
        *args,
        **kwargs,
    ):
        hub_url = f.hub_url(driver)
        if f.bstack1l1l1lll1ll_opy_(hub_url):
            if not bstack1ll1lll1ll1_opy_.bstack1l1llll111l_opy_:
                self.logger.warning(bstack1l1l11_opy_ (u"ࠢ࡭ࡱࡦࡥࡱࠦࡳࡦ࡮ࡩ࠱࡭࡫ࡡ࡭ࠢࡩࡰࡴࡽࠠࡥ࡫ࡶࡥࡧࡲࡥࡥࠢࡩࡳࡷࠦࡂࡳࡱࡺࡷࡪࡸࡓࡵࡣࡦ࡯ࠥ࡯࡮ࡧࡴࡤࠤࡸ࡫ࡳࡴ࡫ࡲࡲࡸࠦࡨࡶࡤࡢࡹࡷࡲ࠽ࠣኴ") + str(hub_url) + bstack1l1l11_opy_ (u"ࠣࠤኵ"))
                bstack1ll1lll1ll1_opy_.bstack1l1llll111l_opy_ = True
            return
        command_name = f.bstack1l1llll11l1_opy_(*args)
        bstack1l1l1ll1l1l_opy_ = f.bstack1l1l1lll11l_opy_(*args)
        if command_name and command_name.lower() == bstack1l1l11_opy_ (u"ࠤࡩ࡭ࡳࡪࡥ࡭ࡧࡰࡩࡳࡺࠢ኶") and bstack1l1l1ll1l1l_opy_:
            framework_session_id = f.session_id(driver)
            locator_type, locator_value = bstack1l1l1ll1l1l_opy_.get(bstack1l1l11_opy_ (u"ࠥࡹࡸ࡯࡮ࡨࠤ኷"), None), bstack1l1l1ll1l1l_opy_.get(bstack1l1l11_opy_ (u"ࠦࡻࡧ࡬ࡶࡧࠥኸ"), None)
            if not framework_session_id or not locator_type or not locator_value:
                self.logger.warning(bstack1l1l11_opy_ (u"ࠧࢁࡣࡰ࡯ࡰࡥࡳࡪ࡟࡯ࡣࡰࡩࢂࡀࠠ࡮࡫ࡶࡷ࡮ࡴࡧࠡࡨࡵࡥࡲ࡫ࡷࡰࡴ࡮ࡣࡸ࡫ࡳࡴ࡫ࡲࡲࡤ࡯ࡤࠡࡱࡵࠤࡦࡸࡧࡴ࠰ࡸࡷ࡮ࡴࡧ࠾ࡽ࡯ࡳࡨࡧࡴࡰࡴࡢࡸࡾࡶࡥࡾࠢࡲࡶࠥࡧࡲࡨࡵ࠱ࡺࡦࡲࡵࡦ࠿ࠥኹ") + str(locator_value) + bstack1l1l11_opy_ (u"ࠨࠢኺ"))
                return
            def bstack1lll11ll1ll_opy_(driver, bstack1l1l1ll1l11_opy_, *args, **kwargs):
                from selenium.common.exceptions import NoSuchElementException
                try:
                    result = bstack1l1l1ll1l11_opy_(driver, *args, **kwargs)
                    response = self.bstack1l1l1llll11_opy_(
                        framework_session_id=framework_session_id,
                        is_success=True,
                        locator_type=locator_type,
                        locator_value=locator_value,
                    )
                    if response and response.execute_script:
                        driver.execute_script(response.execute_script)
                        self.logger.info(bstack1l1l11_opy_ (u"ࠢࡴࡷࡦࡧࡪࡹࡳ࠮ࡵࡦࡶ࡮ࡶࡴ࠻ࠢ࡯ࡳࡨࡧࡴࡰࡴࡢࡸࡾࡶࡥ࠾ࡽ࡯ࡳࡨࡧࡴࡰࡴࡢࡸࡾࡶࡥࡾࠢ࡯ࡳࡨࡧࡴࡰࡴࡢࡺࡦࡲࡵࡦ࠿ࠥኻ") + str(locator_value) + bstack1l1l11_opy_ (u"ࠣࠤኼ"))
                    else:
                        self.logger.warning(bstack1l1l11_opy_ (u"ࠤࡶࡹࡨࡩࡥࡴࡵ࠰ࡲࡴ࠳ࡳࡤࡴ࡬ࡴࡹࡀࠠ࡭ࡱࡦࡥࡹࡵࡲࡠࡶࡼࡴࡪࡃࡻ࡭ࡱࡦࡥࡹࡵࡲࡠࡶࡼࡴࡪࢃࠠ࡭ࡱࡦࡥࡹࡵࡲࡠࡸࡤࡰࡺ࡫࠽ࡼ࡮ࡲࡧࡦࡺ࡯ࡳࡡࡹࡥࡱࡻࡥࡾࠢࡵࡩࡸࡶ࡯࡯ࡵࡨࡁࠧኽ") + str(response) + bstack1l1l11_opy_ (u"ࠥࠦኾ"))
                    return result
                except NoSuchElementException as e:
                    locator = (locator_type, locator_value)
                    return self.__1l1l1ll11l1_opy_(
                        driver, bstack1l1l1ll1l11_opy_, e, framework_session_id, locator, *args, **kwargs
                    )
            bstack1lll11ll1ll_opy_.__name__ = command_name
            return bstack1lll11ll1ll_opy_
    def __1l1l1ll11l1_opy_(
        self,
        driver,
        bstack1l1l1ll1l11_opy_: Callable,
        exception,
        framework_session_id: str,
        locator: Tuple[str, str],
        *args,
        **kwargs,
    ):
        try:
            locator_type, locator_value = locator
            response = self.bstack1l1l1llll11_opy_(
                framework_session_id=framework_session_id,
                is_success=False,
                locator_type=locator_type,
                locator_value=locator_value,
            )
            if response and response.execute_script:
                driver.execute_script(response.execute_script)
                self.logger.info(bstack1l1l11_opy_ (u"ࠦ࡫ࡧࡩ࡭ࡷࡵࡩ࠲࡮ࡥࡢ࡮࡬ࡲ࡬࠳ࡴࡳ࡫ࡪ࡫ࡪࡸࡥࡥ࠼ࠣࡰࡴࡩࡡࡵࡱࡵࡣࡹࡿࡰࡦ࠿ࡾࡰࡴࡩࡡࡵࡱࡵࡣࡹࡿࡰࡦࡿࠣࡰࡴࡩࡡࡵࡱࡵࡣࡻࡧ࡬ࡶࡧࡀࠦ኿") + str(locator_value) + bstack1l1l11_opy_ (u"ࠧࠨዀ"))
                bstack1l1l1lll111_opy_ = self.bstack1l1l1ll11ll_opy_(
                    framework_session_id=framework_session_id,
                    locator_type=locator_type,
                )
                self.logger.info(bstack1l1l11_opy_ (u"ࠨࡦࡢ࡫࡯ࡹࡷ࡫࠭ࡩࡧࡤࡰ࡮ࡴࡧ࠮ࡴࡨࡷࡺࡲࡴ࠻ࠢ࡯ࡳࡨࡧࡴࡰࡴࡢࡸࡾࡶࡥ࠾ࡽ࡯ࡳࡨࡧࡴࡰࡴࡢࡸࡾࡶࡥࡾࠢ࡯ࡳࡨࡧࡴࡰࡴࡢࡺࡦࡲࡵࡦ࠿ࡾࡰࡴࡩࡡࡵࡱࡵࡣࡻࡧ࡬ࡶࡧࢀࠤ࡭࡫ࡡ࡭࡫ࡱ࡫ࡤࡸࡥࡴࡷ࡯ࡸࡂࠨ዁") + str(bstack1l1l1lll111_opy_) + bstack1l1l11_opy_ (u"ࠢࠣዂ"))
                if bstack1l1l1lll111_opy_.success and args and len(args) > 1:
                    args[1].update(
                        {
                            bstack1l1l11_opy_ (u"ࠣࡷࡶ࡭ࡳ࡭ࠢዃ"): bstack1l1l1lll111_opy_.locator_type,
                            bstack1l1l11_opy_ (u"ࠤࡹࡥࡱࡻࡥࠣዄ"): bstack1l1l1lll111_opy_.locator_value,
                        }
                    )
                    return bstack1l1l1ll1l11_opy_(driver, *args, **kwargs)
                elif os.environ.get(bstack1l1l11_opy_ (u"ࠥࡆࡗࡕࡗࡔࡇࡕࡗ࡙ࡇࡃࡌࡡࡄࡍࡤࡊࡅࡃࡗࡊࠦዅ"), False):
                    self.logger.info(bstack1ll1ll1l11l_opy_ (u"ࠦ࡫ࡧࡩ࡭ࡷࡵࡩ࠲࡮ࡥࡢ࡮࡬ࡲ࡬࠳ࡲࡦࡵࡸࡰࡹ࠳࡭ࡪࡵࡶ࡭ࡳ࡭࠺ࠡࡵ࡯ࡩࡪࡶࠨ࠴࠲ࠬࠤࡱ࡫ࡴࡵ࡫ࡱ࡫ࠥࡿ࡯ࡶࠢ࡬ࡲࡸࡶࡥࡤࡶࠣࡸ࡭࡫ࠠࡣࡴࡲࡻࡸ࡫ࡲࠡࡧࡻࡸࡪࡴࡳࡪࡱࡱࠤࡱࡵࡧࡴࠤ዆"))
                    time.sleep(300)
            else:
                self.logger.warning(bstack1l1l11_opy_ (u"ࠧ࡬ࡡࡪ࡮ࡸࡶࡪ࠳࡮ࡰ࠯ࡶࡧࡷ࡯ࡰࡵ࠼ࠣࡰࡴࡩࡡࡵࡱࡵࡣࡹࡿࡰࡦ࠿ࡾࡰࡴࡩࡡࡵࡱࡵࡣࡹࡿࡰࡦࡿࠣࡰࡴࡩࡡࡵࡱࡵࡣࡻࡧ࡬ࡶࡧࡀࡿࡱࡵࡣࡢࡶࡲࡶࡤࡼࡡ࡭ࡷࡨࢁࠥࡸࡥࡴࡲࡲࡲࡸ࡫࠽ࠣ዇") + str(response) + bstack1l1l11_opy_ (u"ࠨࠢወ"))
        except Exception as err:
            self.logger.warning(bstack1l1l11_opy_ (u"ࠢࡧࡣ࡬ࡰࡺࡸࡥ࠮ࡪࡨࡥࡱ࡯࡮ࡨ࠯ࡵࡩࡸࡻ࡬ࡵ࠼ࠣࡩࡷࡸ࡯ࡳ࠼ࠣࠦዉ") + str(err) + bstack1l1l11_opy_ (u"ࠣࠤዊ"))
        raise exception
    @measure(event_name=EVENTS.bstack1l1l1ll1lll_opy_, stage=STAGE.bstack111llllll_opy_)
    def bstack1l1l1llll11_opy_(
        self,
        framework_session_id: str,
        is_success: bool,
        locator_type: str,
        locator_value: str,
        platform_index=bstack1l1l11_opy_ (u"ࠤ࠳ࠦዋ"),
    ):
        self.bstack1l1ll11l111_opy_()
        req = structs.AISelfHealStepRequest()
        req.bin_session_id = self.bin_session_id
        req.platform_index = platform_index
        req.framework_session_id = framework_session_id
        req.is_success = is_success
        req.test_name = bstack1l1l11_opy_ (u"ࠥࠦዌ")
        req.locator_type = locator_type
        req.locator_value = locator_value
        try:
            r = self.bstack1ll1ll1l111_opy_.AISelfHealStep(req)
            self.logger.info(bstack1l1l11_opy_ (u"ࠦࡷ࡫ࡣࡦ࡫ࡹࡩࡩࠦࡦࡳࡱࡰࠤࡸ࡫ࡲࡷࡧࡵ࠾ࠥࠨው") + str(r) + bstack1l1l11_opy_ (u"ࠧࠨዎ"))
            return r
        except grpc.RpcError as e:
            self.logger.error(bstack1l1l11_opy_ (u"ࠨࡲࡱࡥ࠰ࡩࡷࡸ࡯ࡳ࠼ࠣࠦዏ") + str(e) + bstack1l1l11_opy_ (u"ࠢࠣዐ"))
            traceback.print_exc()
            raise e
    @measure(event_name=EVENTS.bstack1l1l1lll1l1_opy_, stage=STAGE.bstack111llllll_opy_)
    def bstack1l1l1ll11ll_opy_(self, framework_session_id: str, locator_type: str, platform_index=bstack1l1l11_opy_ (u"ࠣ࠲ࠥዑ")):
        self.bstack1l1ll11l111_opy_()
        req = structs.AISelfHealGetRequest()
        req.bin_session_id = self.bin_session_id
        req.platform_index = platform_index
        req.framework_session_id = framework_session_id
        req.locator_type = locator_type
        try:
            r = self.bstack1ll1ll1l111_opy_.AISelfHealGetResult(req)
            self.logger.info(bstack1l1l11_opy_ (u"ࠤࡵࡩࡨ࡫ࡩࡷࡧࡧࠤ࡫ࡸ࡯࡮ࠢࡶࡩࡷࡼࡥࡳ࠼ࠣࠦዒ") + str(r) + bstack1l1l11_opy_ (u"ࠥࠦዓ"))
            return r
        except grpc.RpcError as e:
            self.logger.error(bstack1l1l11_opy_ (u"ࠦࡷࡶࡣ࠮ࡧࡵࡶࡴࡸ࠺ࠡࠤዔ") + str(e) + bstack1l1l11_opy_ (u"ࠧࠨዕ"))
            traceback.print_exc()
            raise e