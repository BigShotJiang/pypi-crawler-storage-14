# coding: UTF-8
import sys
bstack1l11111_opy_ = sys.version_info [0] == 2
bstack11l11ll_opy_ = 2048
bstack111ll1l_opy_ = 7
def bstack1l1l11_opy_ (bstack11l1l_opy_):
    global bstack1l11_opy_
    bstack11l1111_opy_ = ord (bstack11l1l_opy_ [-1])
    bstack1l1ll1l_opy_ = bstack11l1l_opy_ [:-1]
    bstack11l11_opy_ = bstack11l1111_opy_ % len (bstack1l1ll1l_opy_)
    bstack1l1ll11_opy_ = bstack1l1ll1l_opy_ [:bstack11l11_opy_] + bstack1l1ll1l_opy_ [bstack11l11_opy_:]
    if bstack1l11111_opy_:
        bstack11lll1l_opy_ = unicode () .join ([unichr (ord (char) - bstack11l11ll_opy_ - (bstack11l111_opy_ + bstack11l1111_opy_) % bstack111ll1l_opy_) for bstack11l111_opy_, char in enumerate (bstack1l1ll11_opy_)])
    else:
        bstack11lll1l_opy_ = str () .join ([chr (ord (char) - bstack11l11ll_opy_ - (bstack11l111_opy_ + bstack11l1111_opy_) % bstack111ll1l_opy_) for bstack11l111_opy_, char in enumerate (bstack1l1ll11_opy_)])
    return eval (bstack11lll1l_opy_)
import os
import traceback
from typing import Dict, Tuple, Callable, Type, List, Any
from urllib.parse import urlparse
from browserstack_sdk.sdk_cli.bstack1lll111ll11_opy_ import (
    bstack1lll11lll11_opy_,
    bstack1lll111l111_opy_,
    bstack1lll111l1ll_opy_,
    bstack1lll1111l11_opy_,
)
import copy
from datetime import datetime, timezone, timedelta
class bstack1ll111ll111_opy_(bstack1lll11lll11_opy_):
    bstack1l1111l111l_opy_ = bstack1l1l11_opy_ (u"ࠦࡇࡘࡏࡘࡕࡈࡖࡘ࡚ࡁࡄࡍࡢࡔࡑࡇࡔࡇࡑࡕࡑࡤࡏࡎࡅࡇ࡛ࠦᒢ")
    bstack1l11l1l1ll1_opy_ = bstack1l1l11_opy_ (u"ࠧ࡬ࡲࡢ࡯ࡨࡻࡴࡸ࡫ࡠࡵࡨࡷࡸ࡯࡯࡯ࡡ࡬ࡨࠧᒣ")
    bstack1l11l1l11ll_opy_ = bstack1l1l11_opy_ (u"ࠨࡨࡶࡤࡢࡹࡷࡲࠢᒤ")
    bstack1l11l11llll_opy_ = bstack1l1l11_opy_ (u"ࠢࡤࡣࡳࡥࡧ࡯࡬ࡪࡶ࡬ࡩࡸࠨᒥ")
    bstack1l1111l1ll1_opy_ = bstack1l1l11_opy_ (u"ࠣࡹ࠶ࡧࡪࡾࡥࡤࡷࡷࡩࡸࡩࡲࡪࡲࡷࠦᒦ")
    bstack1l1111l11l1_opy_ = bstack1l1l11_opy_ (u"ࠤࡺ࠷ࡨ࡫ࡸࡦࡥࡸࡸࡪࡹࡣࡳ࡫ࡳࡸࡦࡹࡹ࡯ࡥࠥᒧ")
    NAME = bstack1l1l11_opy_ (u"ࠥࡴࡱࡧࡹࡸࡴ࡬࡫࡭ࡺࠢᒨ")
    bstack1l11111llll_opy_: Dict[str, List[Callable]] = dict()
    platform_index: int
    options: Any
    desired_capabilities: Any
    bstack1ll1111ll1l_opy_: Any
    bstack1l1111l1l11_opy_: Dict
    def __init__(
        self,
        platform_index: int,
        framework_name: str,
        framework_version: str,
        classes: List[Type],
        methods=[bstack1l1l11_opy_ (u"ࠦࡱࡧࡵ࡯ࡥ࡫ࠦᒩ"), bstack1l1l11_opy_ (u"ࠧࡩ࡯࡯ࡰࡨࡧࡹࠨᒪ"), bstack1l1l11_opy_ (u"ࠨ࡮ࡦࡹࡢࡴࡦ࡭ࡥࠣᒫ"), bstack1l1l11_opy_ (u"ࠢࡤ࡮ࡲࡷࡪࠨᒬ"), bstack1l1l11_opy_ (u"ࠣࡦ࡬ࡷࡵࡧࡴࡤࡪࠥᒭ")],
    ):
        super().__init__(
            framework_name,
            framework_version,
            classes,
        )
        self.platform_index = platform_index
        self.bstack1lll111ll1l_opy_(methods)
    def bstack1lll11lllll_opy_(self, instance: bstack1lll111l111_opy_, method_name: str, bstack1lll11111l1_opy_: timedelta, *args, **kwargs):
        pass
    def bstack1lll11ll1l1_opy_(
        self,
        target: object,
        exec: Tuple[bstack1lll111l111_opy_, str],
        bstack1llll1111ll_opy_: Tuple[bstack1lll111l1ll_opy_, bstack1lll1111l11_opy_],
        result: Any,
        *args,
        **kwargs,
    ) -> Callable[..., Any]:
        instance, method_name = exec
        bstack1lll11l11l1_opy_, bstack1l1111l1111_opy_ = bstack1llll1111ll_opy_
        bstack1lll1l1l1l1_opy_ = bstack1ll111ll111_opy_.bstack1lll1l1ll11_opy_(bstack1llll1111ll_opy_)
        if bstack1lll1l1l1l1_opy_ in bstack1ll111ll111_opy_.bstack1l11111llll_opy_:
            bstack1l1111l11ll_opy_ = None
            for callback in bstack1ll111ll111_opy_.bstack1l11111llll_opy_[bstack1lll1l1l1l1_opy_]:
                try:
                    bstack1l1111l1l1l_opy_ = callback(self, target, exec, bstack1llll1111ll_opy_, result, *args, **kwargs)
                    if bstack1l1111l11ll_opy_ == None:
                        bstack1l1111l11ll_opy_ = bstack1l1111l1l1l_opy_
                except Exception as e:
                    self.logger.error(bstack1l1l11_opy_ (u"ࠤࡨࡶࡷࡵࡲࠡ࡫ࡱࡺࡴࡱࡩ࡯ࡩࠣࡧࡦࡲ࡬ࡣࡣࡦ࡯࠿ࠦࠢᒮ") + str(e) + bstack1l1l11_opy_ (u"ࠥࠦᒯ"))
                    traceback.print_exc()
            if bstack1l1111l1111_opy_ == bstack1lll1111l11_opy_.PRE and callable(bstack1l1111l11ll_opy_):
                return bstack1l1111l11ll_opy_
            elif bstack1l1111l1111_opy_ == bstack1lll1111l11_opy_.POST and bstack1l1111l11ll_opy_:
                return bstack1l1111l11ll_opy_
    def bstack1lll11l1ll1_opy_(
        self, method_name, previous_state: bstack1lll111l1ll_opy_, *args, **kwargs
    ) -> bstack1lll111l1ll_opy_:
        if method_name == bstack1l1l11_opy_ (u"ࠫࡱࡧࡵ࡯ࡥ࡫ࠫᒰ") or method_name == bstack1l1l11_opy_ (u"ࠬࡩ࡯࡯ࡰࡨࡧࡹ࠭ᒱ") or method_name == bstack1l1l11_opy_ (u"࠭࡮ࡦࡹࡢࡴࡦ࡭ࡥࠨᒲ"):
            return bstack1lll111l1ll_opy_.bstack1lll111111l_opy_
        if method_name == bstack1l1l11_opy_ (u"ࠧࡥ࡫ࡶࡴࡦࡺࡣࡩࠩᒳ"):
            return bstack1lll111l1ll_opy_.bstack1lll111lll1_opy_
        if method_name == bstack1l1l11_opy_ (u"ࠨࡥ࡯ࡳࡸ࡫ࠧᒴ"):
            return bstack1lll111l1ll_opy_.QUIT
        return bstack1lll111l1ll_opy_.NONE
    @staticmethod
    def bstack1lll1l1ll11_opy_(bstack1llll1111ll_opy_: Tuple[bstack1lll111l1ll_opy_, bstack1lll1111l11_opy_]):
        return bstack1l1l11_opy_ (u"ࠤ࠽ࠦᒵ").join((bstack1lll111l1ll_opy_(bstack1llll1111ll_opy_[0]).name, bstack1lll1111l11_opy_(bstack1llll1111ll_opy_[1]).name))
    @staticmethod
    def bstack1llll1lll1l_opy_(bstack1llll1111ll_opy_: Tuple[bstack1lll111l1ll_opy_, bstack1lll1111l11_opy_], callback: Callable):
        bstack1lll1l1l1l1_opy_ = bstack1ll111ll111_opy_.bstack1lll1l1ll11_opy_(bstack1llll1111ll_opy_)
        if not bstack1lll1l1l1l1_opy_ in bstack1ll111ll111_opy_.bstack1l11111llll_opy_:
            bstack1ll111ll111_opy_.bstack1l11111llll_opy_[bstack1lll1l1l1l1_opy_] = []
        bstack1ll111ll111_opy_.bstack1l11111llll_opy_[bstack1lll1l1l1l1_opy_].append(callback)
    @staticmethod
    def bstack1l1l1lllll1_opy_(method_name: str):
        return True
    @staticmethod
    def bstack1l1llll1lll_opy_(method_name: str, *args) -> bool:
        return True
    @staticmethod
    def bstack1l1ll11lll1_opy_(instance: bstack1lll111l111_opy_, default_value=None):
        return bstack1lll11lll11_opy_.bstack1lll1llllll_opy_(instance, bstack1ll111ll111_opy_.bstack1l11l11llll_opy_, default_value)
    @staticmethod
    def bstack1l1l1l1lll1_opy_(instance: bstack1lll111l111_opy_) -> bool:
        return True
    @staticmethod
    def bstack1l1lll1llll_opy_(instance: bstack1lll111l111_opy_, default_value=None):
        return bstack1lll11lll11_opy_.bstack1lll1llllll_opy_(instance, bstack1ll111ll111_opy_.bstack1l11l1l11ll_opy_, default_value)
    @staticmethod
    def bstack1l1llll11l1_opy_(*args):
        return args[0] if args and type(args) in [list, tuple] and isinstance(args[0], str) else None
    @staticmethod
    def bstack1l1ll1111ll_opy_(method_name: str, *args):
        if not bstack1ll111ll111_opy_.bstack1l1l1lllll1_opy_(method_name):
            return False
        if not bstack1ll111ll111_opy_.bstack1l1111l1ll1_opy_ in bstack1ll111ll111_opy_.bstack1l111lll11l_opy_(*args):
            return False
        bstack1l1l1ll1l1l_opy_ = bstack1ll111ll111_opy_.bstack1l1l1lll11l_opy_(*args)
        return bstack1l1l1ll1l1l_opy_ and bstack1l1l11_opy_ (u"ࠥࡷࡨࡸࡩࡱࡶࠥᒶ") in bstack1l1l1ll1l1l_opy_ and bstack1l1l11_opy_ (u"ࠦࡧࡸ࡯ࡸࡵࡨࡶࡸࡺࡡࡤ࡭ࡢࡩࡽ࡫ࡣࡶࡶࡲࡶࠧᒷ") in bstack1l1l1ll1l1l_opy_[bstack1l1l11_opy_ (u"ࠧࡹࡣࡳ࡫ࡳࡸࠧᒸ")]
    @staticmethod
    def bstack1l1lll1lll1_opy_(method_name: str, *args):
        if not bstack1ll111ll111_opy_.bstack1l1l1lllll1_opy_(method_name):
            return False
        if not bstack1ll111ll111_opy_.bstack1l1111l1ll1_opy_ in bstack1ll111ll111_opy_.bstack1l111lll11l_opy_(*args):
            return False
        bstack1l1l1ll1l1l_opy_ = bstack1ll111ll111_opy_.bstack1l1l1lll11l_opy_(*args)
        return (
            bstack1l1l1ll1l1l_opy_
            and bstack1l1l11_opy_ (u"ࠨࡳࡤࡴ࡬ࡴࡹࠨᒹ") in bstack1l1l1ll1l1l_opy_
            and bstack1l1l11_opy_ (u"ࠢࡣࡴࡲࡻࡸ࡫ࡲࡴࡶࡤࡧࡰࡥࡡࡤࡥࡨࡷࡸ࡯ࡢࡪ࡮࡬ࡸࡾࡥࡡࡶࡶࡲࡱࡦࡺࡩࡰࡰࡢࡷࡨࡸࡩࡱࡶࠥᒺ") in bstack1l1l1ll1l1l_opy_[bstack1l1l11_opy_ (u"ࠣࡵࡦࡶ࡮ࡶࡴࠣᒻ")]
        )
    @staticmethod
    def bstack1l111lll11l_opy_(*args):
        return str(bstack1ll111ll111_opy_.bstack1l1llll11l1_opy_(*args)).lower()