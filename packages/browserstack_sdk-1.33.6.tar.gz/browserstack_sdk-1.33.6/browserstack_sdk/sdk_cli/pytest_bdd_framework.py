# coding: UTF-8
import sys
bstack1l11111_opy_ = sys.version_info [0] == 2
bstack11l11ll_opy_ = 2048
bstack111ll1l_opy_ = 7
def bstack1l1l11_opy_ (bstack11l1l_opy_):
    global bstack1l11_opy_
    bstack11l1111_opy_ = ord (bstack11l1l_opy_ [-1])
    bstack1l1ll1l_opy_ = bstack11l1l_opy_ [:-1]
    bstack11l11_opy_ = bstack11l1111_opy_ % len (bstack1l1ll1l_opy_)
    bstack1l1ll11_opy_ = bstack1l1ll1l_opy_ [:bstack11l11_opy_] + bstack1l1ll1l_opy_ [bstack11l11_opy_:]
    if bstack1l11111_opy_:
        bstack11lll1l_opy_ = unicode () .join ([unichr (ord (char) - bstack11l11ll_opy_ - (bstack11l111_opy_ + bstack11l1111_opy_) % bstack111ll1l_opy_) for bstack11l111_opy_, char in enumerate (bstack1l1ll11_opy_)])
    else:
        bstack11lll1l_opy_ = str () .join ([chr (ord (char) - bstack11l11ll_opy_ - (bstack11l111_opy_ + bstack11l1111_opy_) % bstack111ll1l_opy_) for bstack11l111_opy_, char in enumerate (bstack1l1ll11_opy_)])
    return eval (bstack11lll1l_opy_)
import os
from datetime import datetime, timezone
from uuid import uuid4
from typing import Dict, List, Any, Tuple
from browserstack_sdk.sdk_cli.bstack1llll1l111l_opy_ import bstack1llll11l111_opy_
from browserstack_sdk.sdk_cli.utils.bstack1l1l11ll11_opy_ import bstack11llllllll1_opy_
from pathlib import Path
import grpc
from browserstack_sdk import sdk_pb2 as structs
from browserstack_sdk.sdk_cli.test_framework import (
    TestFramework,
    bstack1llll111lll_opy_,
    bstack1lllll111l1_opy_,
    bstack1llll1ll111_opy_,
    bstack1lllll1ll1l_opy_,
    bstack1lllll111ll_opy_,
)
import traceback
from bstack_utils.helper import bstack1l11llll111_opy_
from bstack_utils.bstack1111ll1l1_opy_ import bstack1ll111l1ll1_opy_
from bstack_utils.constants import EVENTS
from browserstack_sdk.sdk_cli.utils.bstack1ll1ll11l11_opy_ import bstack1ll1llllll1_opy_
from browserstack_sdk.sdk_cli.bstack1llll11l1l1_opy_ import bstack1lllll1lll1_opy_
bstack1l1l11111ll_opy_ = bstack1l11llll111_opy_()
bstack1l1l11lll1l_opy_ = bstack1l1l11_opy_ (u"ࠤࡘࡴࡱࡵࡡࡥࡧࡧࡅࡹࡺࡡࡤࡪࡰࡩࡳࡺࡳ࠮ࠤᒼ")
bstack11lll1llll1_opy_ = bstack1l1l11_opy_ (u"ࠥࡌࡴࡵ࡫ࡍࡧࡹࡩࡱࠨᒽ")
bstack11llll1ll11_opy_ = bstack1l1l11_opy_ (u"ࠦࡇࡻࡩ࡭ࡦࡏࡩࡻ࡫࡬ࡉࡱࡲ࡯ࡊࡼࡥ࡯ࡶࠥᒾ")
bstack1l11111111l_opy_ = 1.0
_1l11lll1111_opy_ = set()
class PytestBDDFramework(TestFramework):
    bstack11llll1lll1_opy_ = bstack1l1l11_opy_ (u"ࠧࡺࡥࡴࡶࡢࡪ࡮ࡾࡴࡶࡴࡨࡷࠧᒿ")
    bstack11lllll1lll_opy_ = bstack1l1l11_opy_ (u"ࠨࡴࡦࡵࡷࡣ࡭ࡵ࡯࡬ࡵࡢࡷࡹࡧࡲࡵࡧࡧࠦᓀ")
    bstack1l11111ll11_opy_ = bstack1l1l11_opy_ (u"ࠢࡵࡧࡶࡸࡤ࡮࡯ࡰ࡭ࡶࡣ࡫࡯࡮ࡪࡵ࡫ࡩࡩࠨᓁ")
    bstack11lll1lllll_opy_ = bstack1l1l11_opy_ (u"ࠣࡶࡨࡷࡹࡥࡨࡰࡱ࡮ࡣࡱࡧࡳࡵࡡࡶࡸࡦࡸࡴࡦࡦࠥᓂ")
    bstack11lll1l1lll_opy_ = bstack1l1l11_opy_ (u"ࠤࡷࡩࡸࡺ࡟ࡩࡱࡲ࡯ࡤࡲࡡࡴࡶࡢࡪ࡮ࡴࡩࡴࡪࡨࡨࠧᓃ")
    bstack1l11111ll1l_opy_: bool
    bstack1llll11l1l1_opy_: bstack1lllll1lll1_opy_  = None
    bstack11lllll1ll1_opy_ = [
        bstack1llll111lll_opy_.BEFORE_ALL,
        bstack1llll111lll_opy_.AFTER_ALL,
        bstack1llll111lll_opy_.BEFORE_EACH,
        bstack1llll111lll_opy_.AFTER_EACH,
    ]
    def __init__(
        self,
        bstack1lll1lll111_opy_: Dict[str, str],
        bstack1lllll1111l_opy_: List[str]=[bstack1l1l11_opy_ (u"ࠥࡴࡾࡺࡥࡴࡶ࠰ࡦࡩࡪࠢᓄ")],
        bstack1llll11l1l1_opy_: bstack1lllll1lll1_opy_ = None,
        bstack1ll1ll1l111_opy_=None
    ):
        super().__init__(bstack1lllll1111l_opy_, bstack1lll1lll111_opy_, bstack1llll11l1l1_opy_)
        self.bstack1l11111ll1l_opy_ = any(bstack1l1l11_opy_ (u"ࠦࡵࡿࡴࡦࡵࡷ࠱ࡧࡪࡤࠣᓅ") in item.lower() for item in bstack1lllll1111l_opy_)
        self.bstack1ll1ll1l111_opy_ = bstack1ll1ll1l111_opy_
    def track_event(
        self,
        context: bstack1lllll1ll1l_opy_,
        test_framework_state: bstack1llll111lll_opy_,
        test_hook_state: bstack1llll1ll111_opy_,
        *args,
        **kwargs,
    ):
        super().track_event(self, context, test_framework_state, test_hook_state, *args, **kwargs)
        if test_framework_state == bstack1llll111lll_opy_.TEST or test_framework_state in PytestBDDFramework.bstack11lllll1ll1_opy_:
            bstack11llllllll1_opy_(test_framework_state, test_hook_state)
        if test_framework_state == bstack1llll111lll_opy_.NONE:
            self.logger.warning(bstack1l1l11_opy_ (u"ࠧ࡯ࡧ࡯ࡱࡵࡩࡩࠦࡣࡢ࡮࡯ࡦࡦࡩ࡫ࠡࡶࡨࡷࡹࡥࡦࡳࡣࡰࡩࡼࡵࡲ࡬ࡡࡶࡸࡦࡺࡥ࠾ࡽࡷࡩࡸࡺ࡟ࡧࡴࡤࡱࡪࡽ࡯ࡳ࡭ࡢࡷࡹࡧࡴࡦࡿࠣࡸࡪࡹࡴࡠࡪࡲࡳࡰࡥࡳࡵࡣࡷࡩࡂࠨᓆ") + str(test_hook_state) + bstack1l1l11_opy_ (u"ࠨࠢᓇ"))
            return
        if not self.bstack1l11111ll1l_opy_:
            self.logger.warning(bstack1l1l11_opy_ (u"ࠢࡵࡴࡤࡧࡰࡥࡥࡷࡧࡱࡸ࠿ࠦࡵ࡯ࡵࡸࡴࡵࡵࡲࡵࡧࡧࠤ࡫ࡸࡡ࡮ࡧࡺࡳࡷࡱ࠽ࠣᓈ") + str(str(self.bstack1lllll1111l_opy_)) + bstack1l1l11_opy_ (u"ࠣࠤᓉ"))
            return
        if not isinstance(args, tuple) or len(args) == 0:
            self.logger.warning(bstack1l1l11_opy_ (u"ࠤࡷࡶࡦࡩ࡫ࡠࡧࡹࡩࡳࡺ࠺ࠡࡷࡱࡩࡽࡶࡥࡤࡶࡨࡨࠥࡧࡲࡨࡵࡀࡿࡦࡸࡧࡴࡿࠣ࡯ࡼࡧࡲࡨࡵࡀࠦᓊ") + str(kwargs) + bstack1l1l11_opy_ (u"ࠥࠦᓋ"))
            return
        instance = self.__11llll11l11_opy_(context, test_framework_state, test_hook_state, *args, **kwargs)
        if not instance:
            self.logger.debug(bstack1l1l11_opy_ (u"ࠦࡹࡸࡡࡤ࡭ࡢࡩࡻ࡫࡮ࡵ࠼ࠣࡹࡳ࡮ࡡ࡯ࡦ࡯ࡩࡩࠦࡥࡷࡧࡱࡸࡂࢁࡴࡦࡵࡷࡣ࡫ࡸࡡ࡮ࡧࡺࡳࡷࡱ࡟ࡴࡶࡤࡸࡪࢃ࠮ࡼࡶࡨࡷࡹࡥࡨࡰࡱ࡮ࡣࡸࡺࡡࡵࡧࢀࠤࡦࡸࡧࡴ࠿ࠥᓌ") + str(args) + bstack1l1l11_opy_ (u"ࠧࠨᓍ"))
            return
        try:
            if instance!= None and test_framework_state in PytestBDDFramework.bstack11lllll1ll1_opy_ and test_hook_state == bstack1llll1ll111_opy_.PRE:
                bstack1l1ll1ll111_opy_ = bstack1ll111l1ll1_opy_.bstack1l1ll1ll1ll_opy_(EVENTS.bstack1l11111lll_opy_.value)
                name = str(EVENTS.bstack1l11111lll_opy_.name)+bstack1l1l11_opy_ (u"ࠨ࠺ࠣᓎ")+str(test_framework_state.name)
                TestFramework.bstack1llll111ll1_opy_(instance, name, bstack1l1ll1ll111_opy_)
        except Exception as e:
            self.logger.debug(bstack1l1l11_opy_ (u"ࠢࡆࡺࡦࡩࡵࡺࡩࡰࡰࠣ࡭ࡳࠦࡨࡰࡱ࡮ࠤࡪࡸࡲࡰࡴࠣࡴࡷ࡫࠺ࠡࡽࢀࠦᓏ").format(e))
        try:
            if test_framework_state == bstack1llll111lll_opy_.TEST:
                if not TestFramework.bstack1lllll1l1ll_opy_(instance, TestFramework.bstack1lll1ll1lll_opy_) and test_hook_state == bstack1llll1ll111_opy_.PRE:
                    if not (len(args) >= 3):
                        return
                    test = PytestBDDFramework.__1l111111ll1_opy_(args)
                    if test:
                        instance.data.update(test)
                        self.logger.debug(bstack1l1l11_opy_ (u"ࠣ࡮ࡲࡥࡩ࡫ࡤࠡ࡫ࡱࡷࡹࡧ࡮ࡤࡧࡀࡿ࡮ࡴࡳࡵࡣࡱࡧࡪ࠴ࡲࡦࡨࠫ࠭ࢂࠦࡥࡷࡧࡱࡸࡂࢁࡴࡦࡵࡷࡣ࡫ࡸࡡ࡮ࡧࡺࡳࡷࡱ࡟ࡴࡶࡤࡸࡪࢃ࠮ࠣᓐ") + str(test_hook_state) + bstack1l1l11_opy_ (u"ࠤࠥᓑ"))
                if test_hook_state == bstack1llll1ll111_opy_.PRE and not TestFramework.bstack1lllll1l1ll_opy_(instance, TestFramework.bstack1llll1l1111_opy_):
                    TestFramework.bstack1lllll1l11l_opy_(instance, TestFramework.bstack1llll1l1111_opy_, datetime.now(tz=timezone.utc))
                    PytestBDDFramework.__11lllll11ll_opy_(instance, args)
                    self.logger.debug(bstack1l1l11_opy_ (u"ࠥࡷࡪࡺࠠࡵࡧࡶࡸ࠲ࡹࡴࡢࡴࡷࠤ࡫ࡵࡲࠡ࡫ࡱࡷࡹࡧ࡮ࡤࡧࡀࡿ࡮ࡴࡳࡵࡣࡱࡧࡪ࠴ࡲࡦࡨࠫ࠭ࢂࠦࡥࡷࡧࡱࡸࡂࢁࡴࡦࡵࡷࡣ࡫ࡸࡡ࡮ࡧࡺࡳࡷࡱ࡟ࡴࡶࡤࡸࡪࢃ࠮ࠣᓒ") + str(test_hook_state) + bstack1l1l11_opy_ (u"ࠦࠧᓓ"))
                elif test_hook_state == bstack1llll1ll111_opy_.POST and not TestFramework.bstack1lllll1l1ll_opy_(instance, TestFramework.bstack1llll1llll1_opy_):
                    TestFramework.bstack1lllll1l11l_opy_(instance, TestFramework.bstack1llll1llll1_opy_, datetime.now(tz=timezone.utc))
                    self.logger.debug(bstack1l1l11_opy_ (u"ࠧࡹࡥࡵࠢࡷࡩࡸࡺ࠭ࡦࡰࡧࠤ࡫ࡵࡲࠡ࡫ࡱࡷࡹࡧ࡮ࡤࡧࡀࡿ࡮ࡴࡳࡵࡣࡱࡧࡪ࠴ࡲࡦࡨࠫ࠭ࢂࠦࡥࡷࡧࡱࡸࡂࢁࡴࡦࡵࡷࡣ࡫ࡸࡡ࡮ࡧࡺࡳࡷࡱ࡟ࡴࡶࡤࡸࡪࢃ࠮ࠣᓔ") + str(test_hook_state) + bstack1l1l11_opy_ (u"ࠨࠢᓕ"))
            elif test_framework_state == bstack1llll111lll_opy_.STEP:
                if test_hook_state == bstack1llll1ll111_opy_.PRE:
                    PytestBDDFramework.__11lll1ll1l1_opy_(instance, args)
                elif test_hook_state == bstack1llll1ll111_opy_.POST:
                    PytestBDDFramework.__1l11111l1l1_opy_(instance, args)
            elif test_framework_state == bstack1llll111lll_opy_.LOG and test_hook_state == bstack1llll1ll111_opy_.POST:
                PytestBDDFramework.__11llll11ll1_opy_(instance, *args)
            elif test_framework_state == bstack1llll111lll_opy_.LOG_REPORT and test_hook_state == bstack1llll1ll111_opy_.POST:
                self.__11lllllll1l_opy_(instance, *args)
                self.__11lll1ll11l_opy_(instance)
            elif test_framework_state in PytestBDDFramework.bstack11lllll1ll1_opy_:
                self.__1l11111l11l_opy_(instance, test_framework_state, test_hook_state, *args)
            self.logger.debug(bstack1l1l11_opy_ (u"ࠢࡵࡴࡤࡧࡰࡥࡥࡷࡧࡱࡸ࠿ࠦࡨࡢࡰࡧࡰࡪࡪࠠࡦࡸࡨࡲࡹࡃࡻࡵࡧࡶࡸࡤ࡬ࡲࡢ࡯ࡨࡻࡴࡸ࡫ࡠࡵࡷࡥࡹ࡫ࡽ࠯ࡽࡷࡩࡸࡺ࡟ࡩࡱࡲ࡯ࡤࡹࡴࡢࡶࡨࢁࠥ࡯࡮ࡴࡶࡤࡲࡨ࡫࠽ࠣᓖ") + str(instance.ref()) + bstack1l1l11_opy_ (u"ࠣࠤᓗ"))
        except Exception as e:
            self.logger.error(e)
            traceback.print_exc()
        self.bstack1lll1llll1l_opy_(instance, (test_framework_state, test_hook_state), *args, **kwargs)
        try:
            if instance!= None and test_framework_state in PytestBDDFramework.bstack11lllll1ll1_opy_ and test_hook_state == bstack1llll1ll111_opy_.POST:
                name = str(EVENTS.bstack1l11111lll_opy_.name)+bstack1l1l11_opy_ (u"ࠤ࠽ࠦᓘ")+str(test_framework_state.name)
                bstack1l1ll1ll111_opy_ = TestFramework.bstack1llll1l11l1_opy_(instance, name)
                bstack1ll111l1ll1_opy_.end(EVENTS.bstack1l11111lll_opy_.value, bstack1l1ll1ll111_opy_+bstack1l1l11_opy_ (u"ࠥ࠾ࡸࡺࡡࡳࡶࠥᓙ"), bstack1l1ll1ll111_opy_+bstack1l1l11_opy_ (u"ࠦ࠿࡫࡮ࡥࠤᓚ"), True, None, test_framework_state.name)
        except Exception as e:
            self.logger.debug(bstack1l1l11_opy_ (u"ࠧࡋࡸࡤࡧࡳࡸ࡮ࡵ࡮ࠡ࡫ࡱࠤ࡭ࡵ࡯࡬ࠢࡨࡶࡷࡵࡲ࠻ࠢࡾࢁࠧᓛ").format(e))
    def bstack1llll11l11l_opy_(self):
        return self.bstack1l11111ll1l_opy_
    def __11llll1ll1l_opy_(self, *args):
        if len(args) > 2 and callable(getattr(args[2], bstack1l1l11_opy_ (u"ࠨࡧࡦࡶࡢࡶࡪࡹࡵ࡭ࡶࠥᓜ"), None)):
            rep = args[2].get_result()
            if rep:
                return TestFramework.bstack1lllll1llll_opy_(rep, [bstack1l1l11_opy_ (u"ࠢࡸࡪࡨࡲࠧᓝ"), bstack1l1l11_opy_ (u"ࠣࡱࡸࡸࡨࡵ࡭ࡦࠤᓞ"), bstack1l1l11_opy_ (u"ࠤࡳࡥࡸࡹࡥࡥࠤᓟ"), bstack1l1l11_opy_ (u"ࠥࡪࡦ࡯࡬ࡦࡦࠥᓠ"), bstack1l1l11_opy_ (u"ࠦࡸࡱࡩࡱࡲࡨࡨࠧᓡ"), bstack1l1l11_opy_ (u"ࠧࡲ࡯࡯ࡩࡵࡩࡵࡸࡴࡦࡺࡷࠦᓢ")])
        return None
    def __11lllllll1l_opy_(self, instance: bstack1lllll111l1_opy_, *args):
        result = self.__11llll1ll1l_opy_(*args)
        if not result:
            return
        failure = None
        bstack1llllll1ll1_opy_ = None
        if result.get(bstack1l1l11_opy_ (u"ࠨ࡯ࡶࡶࡦࡳࡲ࡫ࠢᓣ"), None) == bstack1l1l11_opy_ (u"ࠢࡧࡣ࡬ࡰࡪࡪࠢᓤ") and len(args) > 1 and getattr(args[1], bstack1l1l11_opy_ (u"ࠣࡧࡻࡧ࡮ࡴࡦࡰࠤᓥ"), None) is not None:
            failure = [{bstack1l1l11_opy_ (u"ࠩࡥࡥࡨࡱࡴࡳࡣࡦࡩࠬᓦ"): [args[1].excinfo.exconly(), result.get(bstack1l1l11_opy_ (u"ࠥࡰࡴࡴࡧࡳࡧࡳࡶࡹ࡫ࡸࡵࠤᓧ"), None)]}]
            bstack1llllll1ll1_opy_ = bstack1l1l11_opy_ (u"ࠦࡆࡹࡳࡦࡴࡷ࡭ࡴࡴࡅࡳࡴࡲࡶࠧᓨ") if bstack1l1l11_opy_ (u"ࠧࡇࡳࡴࡧࡵࡸ࡮ࡵ࡮ࠣᓩ") in getattr(args[1].excinfo, bstack1l1l11_opy_ (u"ࠨࡴࡺࡲࡨࡲࡦࡳࡥࠣᓪ"), bstack1l1l11_opy_ (u"ࠢࠣᓫ")) else bstack1l1l11_opy_ (u"ࠣࡗࡱ࡬ࡦࡴࡤ࡭ࡧࡧࡉࡷࡸ࡯ࡳࠤᓬ")
        bstack11llll111l1_opy_ = result.get(bstack1l1l11_opy_ (u"ࠤࡲࡹࡹࡩ࡯࡮ࡧࠥᓭ"), TestFramework.bstack1lllll11lll_opy_)
        if bstack11llll111l1_opy_ != TestFramework.bstack1lllll11lll_opy_:
            TestFramework.bstack1lllll1l11l_opy_(instance, TestFramework.bstack1llll11lll1_opy_, datetime.now(tz=timezone.utc))
        TestFramework.bstack1lll1l1ll1l_opy_(instance, {
            TestFramework.bstack1lll1lll1ll_opy_: failure,
            TestFramework.bstack1llllll11l1_opy_: bstack1llllll1ll1_opy_,
            TestFramework.bstack1llllll111l_opy_: bstack11llll111l1_opy_,
        })
    def __11llll11l11_opy_(
        self,
        context: bstack1lllll1ll1l_opy_,
        test_framework_state: bstack1llll111lll_opy_,
        test_hook_state: bstack1llll1ll111_opy_,
        *args,
        **kwargs,
    ):
        instance = None
        if test_framework_state == bstack1llll111lll_opy_.SETUP_FIXTURE:
            instance = self.__11llll1111l_opy_(context, test_framework_state, test_hook_state, *args, **kwargs)
        else:
            target = None # bstack11lll1ll111_opy_ bstack11lllll1l1l_opy_ this to be bstack1l1l11_opy_ (u"ࠥࡲࡴࡪࡥࡪࡦࠥᓮ")
            if test_framework_state == bstack1llll111lll_opy_.INIT_TEST:
                target = args[0] if isinstance(args[0], str) else None
                if target:
                    self.__11llllll111_opy_(context, test_framework_state, target, *args)
            elif test_framework_state == bstack1llll111lll_opy_.LOG:
                nodeid = getattr(getattr(args[0], bstack1l1l11_opy_ (u"ࠦࡳࡵࡤࡦࠤᓯ"), None), bstack1l1l11_opy_ (u"ࠧࡴ࡯ࡥࡧ࡬ࡨࠧᓰ"), None) if args else None
                if isinstance(nodeid, str):
                    target = nodeid
            elif getattr(args[0], bstack1l1l11_opy_ (u"ࠨ࡮ࡰࡦࡨࠦᓱ"), None):
                target = args[0].node.nodeid
            elif getattr(args[0], bstack1l1l11_opy_ (u"ࠢ࡯ࡱࡧࡩ࡮ࡪࠢᓲ"), None):
                target = args[0].nodeid
            instance = TestFramework.bstack1llll1lll11_opy_(target) if target else None
        return instance
    def __1l11111l11l_opy_(
        self,
        instance: bstack1lllll111l1_opy_,
        test_framework_state: bstack1llll111lll_opy_,
        test_hook_state: bstack1llll1ll111_opy_,
        *args,
    ):
        key = test_framework_state.name
        bstack11lllllllll_opy_ = TestFramework.bstack1lll1llllll_opy_(instance, PytestBDDFramework.bstack11lllll1lll_opy_, {})
        if not key in bstack11lllllllll_opy_:
            bstack11lllllllll_opy_[key] = []
        bstack1l111111111_opy_ = TestFramework.bstack1lll1llllll_opy_(instance, PytestBDDFramework.bstack1l11111ll11_opy_, {})
        if not key in bstack1l111111111_opy_:
            bstack1l111111111_opy_[key] = []
        bstack1l111111l1l_opy_ = {
            PytestBDDFramework.bstack11lllll1lll_opy_: bstack11lllllllll_opy_,
            PytestBDDFramework.bstack1l11111ll11_opy_: bstack1l111111111_opy_,
        }
        if test_hook_state == bstack1llll1ll111_opy_.PRE:
            hook_name = args[1] if len(args) > 1 else None
            hook = {
                bstack1l1l11_opy_ (u"ࠣ࡭ࡨࡽࠧᓳ"): key,
                TestFramework.bstack1lllll11111_opy_: uuid4().__str__(),
                TestFramework.bstack1llll11ll11_opy_: TestFramework.bstack1llll1ll1l1_opy_,
                TestFramework.bstack1llll111l11_opy_: datetime.now(tz=timezone.utc),
                TestFramework.bstack1lllll1ll11_opy_: [],
                TestFramework.bstack1llll1111l1_opy_: hook_name,
                TestFramework.bstack1lll1lll11l_opy_: bstack1ll1llllll1_opy_.bstack11llll11l1l_opy_()
            }
            bstack11lllllllll_opy_[key].append(hook)
            bstack1l111111l1l_opy_[PytestBDDFramework.bstack11lll1lllll_opy_] = key
        elif test_hook_state == bstack1llll1ll111_opy_.POST:
            bstack11lll1lll11_opy_ = bstack11lllllllll_opy_.get(key, [])
            hook = bstack11lll1lll11_opy_.pop() if bstack11lll1lll11_opy_ else None
            if hook:
                result = self.__11llll1ll1l_opy_(*args)
                if result:
                    bstack11llll1l1l1_opy_ = result.get(bstack1l1l11_opy_ (u"ࠤࡲࡹࡹࡩ࡯࡮ࡧࠥᓴ"), TestFramework.bstack1llll1ll1l1_opy_)
                    if bstack11llll1l1l1_opy_ != TestFramework.bstack1llll1ll1l1_opy_:
                        hook[TestFramework.bstack1llll11ll11_opy_] = bstack11llll1l1l1_opy_
                hook[TestFramework.bstack1llll111111_opy_] = datetime.now(tz=timezone.utc)
                hook[TestFramework.bstack1lll1lll11l_opy_] = bstack1ll1llllll1_opy_.bstack11llll11l1l_opy_()
                self.bstack11llll1llll_opy_(hook)
                logs = hook.get(TestFramework.bstack1lll1ll11ll_opy_, [])
                self.bstack1l11lllllll_opy_(instance, logs)
                bstack1l111111111_opy_[key].append(hook)
                bstack1l111111l1l_opy_[PytestBDDFramework.bstack11lll1l1lll_opy_] = key
        TestFramework.bstack1lll1l1ll1l_opy_(instance, bstack1l111111l1l_opy_)
        self.logger.debug(bstack1l1l11_opy_ (u"ࠥࡸࡷࡧࡣ࡬ࡡ࡫ࡳࡴࡱ࡟ࡦࡸࡨࡲࡹࡀࠠࡵࡧࡶࡸࡤ࡮࡯ࡰ࡭ࡢࡷࡹࡧࡴࡦ࠿ࡾ࡯ࡪࡿࡽ࠯ࡽࡷࡩࡸࡺ࡟ࡩࡱࡲ࡯ࡤࡹࡴࡢࡶࡨࢁࠥ࡮࡯ࡰ࡭ࡶࡣࡸࡺࡡࡳࡶࡨࡨࡂࢁࡨࡰࡱ࡮ࡷࡤࡹࡴࡢࡴࡷࡩࡩࢃࠠࡩࡱࡲ࡯ࡸࡥࡦࡪࡰ࡬ࡷ࡭࡫ࡤ࠾ࠤᓵ") + str(bstack1l111111111_opy_) + bstack1l1l11_opy_ (u"ࠦࠧᓶ"))
    def __11llll1111l_opy_(
        self,
        context: bstack1lllll1ll1l_opy_,
        test_framework_state: bstack1llll111lll_opy_,
        test_hook_state: bstack1llll1ll111_opy_,
        *args,
        **kwargs,
    ):
        fixturedef = TestFramework.bstack1lllll1llll_opy_(args[0], [bstack1l1l11_opy_ (u"ࠧࡹࡣࡰࡲࡨࠦᓷ"), bstack1l1l11_opy_ (u"ࠨࡡࡳࡩࡱࡥࡲ࡫ࠢᓸ"), bstack1l1l11_opy_ (u"ࠢࡱࡣࡵࡥࡲࡹࠢᓹ"), bstack1l1l11_opy_ (u"ࠣ࡫ࡧࡷࠧᓺ"), bstack1l1l11_opy_ (u"ࠤࡸࡲ࡮ࡺࡴࡦࡵࡷࠦᓻ"), bstack1l1l11_opy_ (u"ࠥࡦࡦࡹࡥࡪࡦࠥᓼ")]) if len(args) > 0 else {}
        request = args[1] if len(args) > 1 else None
        scenario = args[2] if len(args) == 3 else None
        scope = request.scope if hasattr(request, bstack1l1l11_opy_ (u"ࠦࡸࡩ࡯ࡱࡧࠥᓽ")) else fixturedef.get(bstack1l1l11_opy_ (u"ࠧࡹࡣࡰࡲࡨࠦᓾ"), None)
        fixturename = request.fixturename if hasattr(request, bstack1l1l11_opy_ (u"ࠨࡦࡪࡺࡷࡹࡷ࡫࡮ࡢ࡯ࡨࠦᓿ")) else None
        node = request.node if hasattr(request, bstack1l1l11_opy_ (u"ࠢ࡯ࡱࡧࡩࠧᔀ")) else None
        target = request.node.nodeid if hasattr(node, bstack1l1l11_opy_ (u"ࠣࡰࡲࡨࡪ࡯ࡤࠣᔁ")) else None
        baseid = fixturedef.get(bstack1l1l11_opy_ (u"ࠤࡥࡥࡸ࡫ࡩࡥࠤᔂ"), None) or bstack1l1l11_opy_ (u"ࠥࠦᔃ")
        if (not target or len(baseid) > 0) and hasattr(request, bstack1l1l11_opy_ (u"ࠦࡤࡶࡹࡧࡷࡱࡧ࡮ࡺࡥ࡮ࠤᔄ")):
            target = PytestBDDFramework.__1l111111l11_opy_(request._pyfuncitem.location) if hasattr(request._pyfuncitem, bstack1l1l11_opy_ (u"ࠧࡲ࡯ࡤࡣࡷ࡭ࡴࡴࠢᔅ")) else None
            if target and not TestFramework.bstack1llll1lll11_opy_(target):
                self.__11llllll111_opy_(context, test_framework_state, target, (target, request._pyfuncitem.location))
                node = request._pyfuncitem
                self.logger.debug(bstack1l1l11_opy_ (u"ࠨࡴࡳࡣࡦ࡯ࡤ࡬ࡩࡹࡶࡸࡶࡪࡥࡥࡷࡧࡱࡸ࠿ࠦࡦࡢ࡮࡯ࡦࡦࡩ࡫ࠡࡶࡤࡶ࡬࡫ࡴ࠾ࡽࡷࡥࡷ࡭ࡥࡵࡿࠣࡪ࡮ࡾࡴࡶࡴࡨࡲࡦࡳࡥ࠾ࡽࡩ࡭ࡽࡺࡵࡳࡧࡱࡥࡲ࡫ࡽࠡࡰࡲࡨࡪࡃࡻ࡯ࡱࡧࡩࢂࠦࡥࡷࡧࡱࡸࡂࢁࡴࡦࡵࡷࡣ࡫ࡸࡡ࡮ࡧࡺࡳࡷࡱ࡟ࡴࡶࡤࡸࡪࢃ࠮ࠣᔆ") + str(test_hook_state) + bstack1l1l11_opy_ (u"ࠢࠣᔇ"))
        if not fixturedef or not scope or not target:
            self.logger.warning(bstack1l1l11_opy_ (u"ࠣࡶࡵࡥࡨࡱ࡟ࡧ࡫ࡻࡸࡺࡸࡥࡠࡧࡹࡩࡳࡺ࠺ࠡࡷࡱ࡬ࡦࡴࡤ࡭ࡧࡧࠤࡪࡼࡥ࡯ࡶࡀࡿࡹ࡫ࡳࡵࡡࡩࡶࡦࡳࡥࡸࡱࡵ࡯ࡤࡹࡴࡢࡶࡨࢁ࠳ࢁࡴࡦࡵࡷࡣ࡭ࡵ࡯࡬ࡡࡶࡸࡦࡺࡥࡾࠢࡩ࡭ࡽࡺࡵࡳࡧࡧࡩ࡫ࡃࡻࡧ࡫ࡻࡸࡺࡸࡥࡥࡧࡩࢁࠥࡹࡣࡰࡲࡨࡁࢀࡹࡣࡰࡲࡨࢁࠥࡺࡡࡳࡩࡨࡸࡂࠨᔈ") + str(target) + bstack1l1l11_opy_ (u"ࠤࠥᔉ"))
            return None
        instance = TestFramework.bstack1llll1lll11_opy_(target)
        if not instance:
            self.logger.warning(bstack1l1l11_opy_ (u"ࠥࡸࡷࡧࡣ࡬ࡡࡩ࡭ࡽࡺࡵࡳࡧࡢࡩࡻ࡫࡮ࡵ࠼ࠣࡹࡳ࡮ࡡ࡯ࡦ࡯ࡩࡩࠦࡥࡷࡧࡱࡸࡂࢁࡴࡦࡵࡷࡣ࡫ࡸࡡ࡮ࡧࡺࡳࡷࡱ࡟ࡴࡶࡤࡸࡪࢃ࠮ࡼࡶࡨࡷࡹࡥࡨࡰࡱ࡮ࡣࡸࡺࡡࡵࡧࢀࠤ࡫࡯ࡸࡵࡷࡵࡩࡳࡧ࡭ࡦ࠿ࡾࡪ࡮ࡾࡴࡶࡴࡨࡲࡦࡳࡥࡾࠢࡶࡧࡴࡶࡥ࠾ࡽࡶࡧࡴࡶࡥࡾࠢࡥࡥࡸ࡫ࡩࡥ࠿ࡾࡦࡦࡹࡥࡪࡦࢀࠤࡹࡧࡲࡨࡧࡷࡁࠧᔊ") + str(target) + bstack1l1l11_opy_ (u"ࠦࠧᔋ"))
            return None
        bstack11lll1l1ll1_opy_ = TestFramework.bstack1lll1llllll_opy_(instance, PytestBDDFramework.bstack11llll1lll1_opy_, {})
        if os.getenv(bstack1l1l11_opy_ (u"࡙ࠧࡄࡌࡡࡆࡐࡎࡥࡆࡍࡃࡊࡣࡋࡏࡘࡕࡗࡕࡉࡘࠨᔌ"), bstack1l1l11_opy_ (u"ࠨ࠱ࠣᔍ")) == bstack1l1l11_opy_ (u"ࠢ࠲ࠤᔎ"):
            bstack11llll1l1ll_opy_ = bstack1l1l11_opy_ (u"ࠣ࠼ࠥᔏ").join((scope, fixturename))
            bstack1l1111111l1_opy_ = datetime.now(tz=timezone.utc)
            bstack11lll1ll1ll_opy_ = {
                bstack1l1l11_opy_ (u"ࠤ࡮ࡩࡾࠨᔐ"): bstack11llll1l1ll_opy_,
                bstack1l1l11_opy_ (u"ࠥࡸࡦ࡭ࡳࠣᔑ"): PytestBDDFramework.__11llll1l11l_opy_(request.node, scenario),
                bstack1l1l11_opy_ (u"ࠦ࡫࡯ࡸࡵࡷࡵࡩࠧᔒ"): fixturedef,
                bstack1l1l11_opy_ (u"ࠧࡹࡣࡰࡲࡨࠦᔓ"): scope,
                bstack1l1l11_opy_ (u"ࠨࡴࡺࡲࡨࠦᔔ"): None,
            }
            try:
                if test_hook_state == bstack1llll1ll111_opy_.POST and callable(getattr(args[-1], bstack1l1l11_opy_ (u"ࠢࡨࡧࡷࡣࡷ࡫ࡳࡶ࡮ࡷࠦᔕ"), None)):
                    bstack11lll1ll1ll_opy_[bstack1l1l11_opy_ (u"ࠣࡶࡼࡴࡪࠨᔖ")] = TestFramework.bstack1llll1ll11l_opy_(args[-1].get_result())
            except Exception as e:
                pass
            if test_hook_state == bstack1llll1ll111_opy_.PRE:
                bstack11lll1ll1ll_opy_[bstack1l1l11_opy_ (u"ࠤࡸࡹ࡮ࡪࠢᔗ")] = uuid4().__str__()
                bstack11lll1ll1ll_opy_[PytestBDDFramework.bstack1llll111l11_opy_] = bstack1l1111111l1_opy_
            elif test_hook_state == bstack1llll1ll111_opy_.POST:
                bstack11lll1ll1ll_opy_[PytestBDDFramework.bstack1llll111111_opy_] = bstack1l1111111l1_opy_
            if bstack11llll1l1ll_opy_ in bstack11lll1l1ll1_opy_:
                bstack11lll1l1ll1_opy_[bstack11llll1l1ll_opy_].update(bstack11lll1ll1ll_opy_)
                self.logger.debug(bstack1l1l11_opy_ (u"ࠥࡹࡵࡪࡡࡵࡧࡧࠤ࡫࡯ࡸࡵࡷࡵࡩࡳࡧ࡭ࡦ࠿ࡾࡪ࡮ࡾࡴࡶࡴࡨࡲࡦࡳࡥࡾࠢࡶࡧࡴࡶࡥ࠾ࡽࡶࡧࡴࡶࡥࡾࠢࡩ࡭ࡽࡺࡵࡳࡧࡀࠦᔘ") + str(bstack11lll1l1ll1_opy_[bstack11llll1l1ll_opy_]) + bstack1l1l11_opy_ (u"ࠦࠧᔙ"))
            else:
                bstack11lll1l1ll1_opy_[bstack11llll1l1ll_opy_] = bstack11lll1ll1ll_opy_
                self.logger.debug(bstack1l1l11_opy_ (u"ࠧࡹࡡࡷࡧࡧࠤ࡫࡯ࡸࡵࡷࡵࡩࡳࡧ࡭ࡦ࠿ࡾࡪ࡮ࡾࡴࡶࡴࡨࡲࡦࡳࡥࡾࠢࡶࡧࡴࡶࡥ࠾ࡽࡶࡧࡴࡶࡥࡾࠢࡩ࡭ࡽࡺࡵࡳࡧࡀࡿࡹ࡫ࡳࡵࡡࡩ࡭ࡽࡺࡵࡳࡧࢀࠤࡹࡸࡡࡤ࡭ࡨࡨࡤ࡬ࡩࡹࡶࡸࡶࡪࡹ࠽ࠣᔚ") + str(len(bstack11lll1l1ll1_opy_)) + bstack1l1l11_opy_ (u"ࠨࠢᔛ"))
        TestFramework.bstack1lllll1l11l_opy_(instance, PytestBDDFramework.bstack11llll1lll1_opy_, bstack11lll1l1ll1_opy_)
        self.logger.debug(bstack1l1l11_opy_ (u"ࠢࡴࡣࡹࡩࡩࠦࡦࡪࡺࡷࡹࡷ࡫ࡳ࠾ࡽ࡯ࡩࡳ࠮ࡴࡳࡣࡦ࡯ࡪࡪ࡟ࡧ࡫ࡻࡸࡺࡸࡥࡴࠫࢀࠤ࡮ࡴࡳࡵࡣࡱࡧࡪࡃࠢᔜ") + str(instance.ref()) + bstack1l1l11_opy_ (u"ࠣࠤᔝ"))
        return instance
    def __11llllll111_opy_(
        self,
        context: bstack1lllll1ll1l_opy_,
        test_framework_state: bstack1llll111lll_opy_,
        target: Any,
        *args,
    ):
        ctx = bstack1llll11l111_opy_.create_context(target)
        ob = bstack1lllll111l1_opy_(ctx, self.bstack1lllll1111l_opy_, self.bstack1lll1lll111_opy_, test_framework_state)
        TestFramework.bstack1lll1l1ll1l_opy_(ob, {
            TestFramework.bstack1lll1ll111l_opy_: context.test_framework_name,
            TestFramework.bstack1lll1l1lll1_opy_: context.test_framework_version,
            TestFramework.bstack1lll1ll1l11_opy_: [],
            PytestBDDFramework.bstack11llll1lll1_opy_: {},
            PytestBDDFramework.bstack1l11111ll11_opy_: {},
            PytestBDDFramework.bstack11lllll1lll_opy_: {},
        })
        if len(args) > 1 and isinstance(args[1], tuple):
            TestFramework.bstack1lllll1l11l_opy_(ob, TestFramework.bstack1llll11llll_opy_, str(args[1][0]))
        if context.platform_index >= 0:
            TestFramework.bstack1lllll1l11l_opy_(ob, TestFramework.bstack1llll11ll1l_opy_, context.platform_index)
        TestFramework.bstack1llllll11ll_opy_[ctx.id] = ob
        self.logger.debug(bstack1l1l11_opy_ (u"ࠤࡶࡥࡻ࡫ࡤࠡ࡫ࡱࡷࡹࡧ࡮ࡤࡧࠣࡧࡹࡾ࠮ࡪࡦࡀࡿࡨࡺࡸ࠯࡫ࡧࢁࠥࡺࡡࡳࡩࡨࡸࡂࢁࡴࡢࡴࡪࡩࡹࢃࠠࡢࡴࡪࡷࡂࢁࡡࡳࡩࡶࢁࠥ࡯࡮ࡴࡶࡤࡲࡨ࡫ࡳ࠾ࠤᔞ") + str(TestFramework.bstack1llllll11ll_opy_.keys()) + bstack1l1l11_opy_ (u"ࠥࠦᔟ"))
        return ob
    @staticmethod
    def __11lllll11ll_opy_(instance, args):
        request, feature, scenario = args
        steps = []
        for step in scenario.steps:
            steps.append({
                bstack1l1l11_opy_ (u"ࠫ࡮ࡪࠧᔠ"): id(step),
                bstack1l1l11_opy_ (u"ࠬࡺࡥࡹࡶࠪᔡ"): step.name,
                bstack1l1l11_opy_ (u"࠭࡫ࡦࡻࡺࡳࡷࡪࠧᔢ"): step.keyword,
            })
        meta = {
            bstack1l1l11_opy_ (u"ࠧࡧࡧࡤࡸࡺࡸࡥࠨᔣ"): {
                bstack1l1l11_opy_ (u"ࠨࡰࡤࡱࡪ࠭ᔤ"): feature.name,
                bstack1l1l11_opy_ (u"ࠩࡳࡥࡹ࡮ࠧᔥ"): feature.filename,
                bstack1l1l11_opy_ (u"ࠪࡨࡪࡹࡣࡳ࡫ࡳࡸ࡮ࡵ࡮ࠨᔦ"): feature.description
            },
            bstack1l1l11_opy_ (u"ࠫࡸࡩࡥ࡯ࡣࡵ࡭ࡴ࠭ᔧ"): {
                bstack1l1l11_opy_ (u"ࠬࡴࡡ࡮ࡧࠪᔨ"): scenario.name
            },
            bstack1l1l11_opy_ (u"࠭ࡳࡵࡧࡳࡷࠬᔩ"): steps,
            bstack1l1l11_opy_ (u"ࠧࡦࡺࡤࡱࡵࡲࡥࡴࠩᔪ"): PytestBDDFramework.__11llll11111_opy_(request.node)
        }
        instance.data.update(
            {
                TestFramework.bstack1lll1lll1l1_opy_: meta
            }
        )
    def bstack11llll1llll_opy_(self, hook: Dict[str, Any]) -> None:
        bstack1l1l11_opy_ (u"ࠣࠤࠥࠎࠥࠦࠠࠡࠢࠣࠤࠥࡖࡲࡰࡥࡨࡷࡸ࡫ࡳࠡࡶ࡫ࡩࠥࡎ࡯ࡰ࡭ࡏࡩࡻ࡫࡬ࠡࡣࡷࡸࡦࡩࡨ࡮ࡧࡱࡸࡸࠦࡳࡪ࡯࡬ࡰࡦࡸࠠࡵࡱࠣࡸ࡭࡫ࠠࡋࡣࡹࡥࠥ࡯࡭ࡱ࡮ࡨࡱࡪࡴࡴࡢࡶ࡬ࡳࡳ࠴ࠊࠡࠢࠣࠤࠥࠦࠠࠡࡖ࡫࡭ࡸࠦ࡭ࡦࡶ࡫ࡳࡩࡀࠊࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣ࠱ࠥࡉࡨࡦࡥ࡮ࡷࠥࡺࡨࡦࠢࡋࡳࡴࡱࡌࡦࡸࡨࡰࠥࡪࡩࡳࡧࡦࡸࡴࡸࡹࠡ࡫ࡱࡷ࡮ࡪࡥࠡࢀ࠲࠲ࡧࡸ࡯ࡸࡵࡨࡶࡸࡺࡡࡤ࡭࠲࡙ࡵࡲ࡯ࡢࡦࡨࡨࡆࡺࡴࡢࡥ࡫ࡱࡪࡴࡴࡴ࠰ࠍࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦ࠭ࠡࡈࡲࡶࠥ࡫ࡡࡤࡪࠣࡪ࡮ࡲࡥࠡ࡫ࡱࠤ࡭ࡵ࡯࡬ࡡ࡯ࡩࡻ࡫࡬ࡠࡨ࡬ࡰࡪࡹࠬࠡࡴࡨࡴࡱࡧࡣࡦࡵ࡙ࠣࠦ࡫ࡳࡵࡎࡨࡺࡪࡲࠢࠡࡹ࡬ࡸ࡭ࠦࠢࡉࡱࡲ࡯ࡑ࡫ࡶࡦ࡮ࠥࠤ࡮ࡴࠠࡪࡶࡶࠤࡵࡧࡴࡩ࠰ࠍࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦ࠭ࠡࡋࡩࠤࡦࠦࡦࡪ࡮ࡨࠤ࡮ࡴࠠࡵࡪࡨࠤࡩ࡯ࡲࡦࡥࡷࡳࡷࡿࠠ࡮ࡣࡷࡧ࡭࡫ࡳࠡࡣࠣࡱࡴࡪࡩࡧ࡫ࡨࡨࠥ࡮࡯ࡰ࡭࠰ࡰࡪࡼࡥ࡭ࠢࡩ࡭ࡱ࡫ࠬࠡ࡫ࡷࠤࡨࡸࡥࡢࡶࡨࡷࠥࡧࠠࡍࡱࡪࡉࡳࡺࡲࡺࠢࡲࡦ࡯࡫ࡣࡵࠢࡺ࡭ࡹ࡮ࠠࡢࡶࡷࡥࡨ࡮࡭ࡦࡰࡷࠤࡩ࡫ࡴࡢ࡫࡯ࡷ࠳ࠐࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢ࠰ࠤࡘ࡯࡭ࡪ࡮ࡤࡶࡱࡿࠬࠡ࡫ࡷࠤࡵࡸ࡯ࡤࡧࡶࡷࡪࡹࠠࡃࡷ࡬ࡰࡩࡒࡥࡷࡧ࡯ࠤࡦࡺࡴࡢࡥ࡫ࡱࡪࡴࡴࡴࠢ࡯ࡳࡨࡧࡴࡦࡦࠣ࡭ࡳࠦࡈࡰࡱ࡮ࡐࡪࡼࡥ࡭࠱ࡅࡹ࡮ࡲࡤࡍࡧࡹࡩࡱࡎ࡯ࡰ࡭ࡈࡺࡪࡴࡴࠡࡤࡼࠤࡷ࡫ࡰ࡭ࡣࡦ࡭ࡳ࡭ࠠࠣࡄࡸ࡭ࡱࡪࡌࡦࡸࡨࡰࠧࠦࡷࡪࡶ࡫ࠤࠧࡎ࡯ࡰ࡭ࡏࡩࡻ࡫࡬࠰ࡄࡸ࡭ࡱࡪࡌࡦࡸࡨࡰࡍࡵ࡯࡬ࡇࡹࡩࡳࡺࠢ࠯ࠌࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥ࠳ࠠࡕࡪࡨࠤࡨࡸࡥࡢࡶࡨࡨࠥࡒ࡯ࡨࡇࡱࡸࡷࡿࠠࡰࡤ࡭ࡩࡨࡺࡳࠡࡣࡵࡩࠥࡧࡤࡥࡧࡧࠤࡹࡵࠠࡵࡪࡨࠤ࡭ࡵ࡯࡬ࠩࡶࠤࠧࡲ࡯ࡨࡵࠥࠤࡱ࡯ࡳࡵ࠰ࠍࠤࠥࠦࠠࠡࠢࠣࠤࡆࡸࡧࡴ࠼ࠍࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࡪࡲࡳࡰࡀࠠࡕࡪࡨࠤࡪࡼࡥ࡯ࡶࠣࡨ࡮ࡩࡴࡪࡱࡱࡥࡷࡿࠠࡤࡱࡱࡸࡦ࡯࡮ࡪࡰࡪࠤࡪࡾࡩࡴࡶ࡬ࡲ࡬ࠦ࡬ࡰࡩࡶࠤࡦࡴࡤࠡࡪࡲࡳࡰࠦࡩ࡯ࡨࡲࡶࡲࡧࡴࡪࡱࡱ࠲ࠏࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣ࡬ࡴࡵ࡫ࡠ࡮ࡨࡺࡪࡲ࡟ࡧ࡫࡯ࡩࡸࡀࠠࡍ࡫ࡶࡸࠥࡵࡦࠡࡒࡤࡸ࡭ࠦ࡯ࡣ࡬ࡨࡧࡹࡹࠠࡧࡴࡲࡱࠥࡺࡨࡦࠢࡗࡩࡸࡺࡌࡦࡸࡨࡰࠥࡳ࡯࡯࡫ࡷࡳࡷ࡯࡮ࡨ࠰ࠍࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࡤࡸ࡭ࡱࡪ࡟࡭ࡧࡹࡩࡱࡥࡦࡪ࡮ࡨࡷ࠿ࠦࡌࡪࡵࡷࠤࡴ࡬ࠠࡑࡣࡷ࡬ࠥࡵࡢ࡫ࡧࡦࡸࡸࠦࡦࡳࡱࡰࠤࡹ࡮ࡥࠡࡄࡸ࡭ࡱࡪࡌࡦࡸࡨࡰࠥࡳ࡯࡯࡫ࡷࡳࡷ࡯࡮ࡨ࠰ࠍࠤࠥࠦࠠࠡࠢࠣࠤࠧࠨࠢᔫ")
        global _1l11lll1111_opy_
        platform_index = os.environ[bstack1l1l11_opy_ (u"ࠩࡅࡖࡔ࡝ࡓࡆࡔࡖࡘࡆࡉࡋࡠࡒࡏࡅ࡙ࡌࡏࡓࡏࡢࡍࡓࡊࡅ࡙ࠩᔬ")]
        bstack1l11lll1l1l_opy_ = os.path.join(bstack1l1l11111ll_opy_, (bstack1l1l11lll1l_opy_ + str(platform_index)), bstack11lll1llll1_opy_)
        if not os.path.exists(bstack1l11lll1l1l_opy_) or not os.path.isdir(bstack1l11lll1l1l_opy_):
            return
        logs = hook.get(bstack1l1l11_opy_ (u"ࠥࡰࡴ࡭ࡳࠣᔭ"), [])
        with os.scandir(bstack1l11lll1l1l_opy_) as entries:
            for entry in entries:
                abs_path = os.path.abspath(entry.path)
                if abs_path in _1l11lll1111_opy_:
                    self.logger.info(bstack1l1l11_opy_ (u"ࠦࡕࡧࡴࡩࠢࡤࡰࡷ࡫ࡡࡥࡻࠣࡴࡷࡵࡣࡦࡵࡶࡩࡩࠦࡻࡾࠤᔮ").format(abs_path))
                    continue
                if entry.is_file():
                    try:
                        timestamp = datetime.fromtimestamp(entry.stat().st_mtime, tz=timezone.utc).isoformat()
                    except Exception:
                        timestamp = bstack1l1l11_opy_ (u"ࠧࠨᔯ")
                    log_entry = bstack1lllll111ll_opy_(
                        kind=bstack1l1l11_opy_ (u"ࠨࡔࡆࡕࡗࡣࡆ࡚ࡔࡂࡅࡋࡑࡊࡔࡔࠣᔰ"),
                        message=bstack1l1l11_opy_ (u"ࠢࠣᔱ"),
                        level=bstack1l1l11_opy_ (u"ࠣࠤᔲ"),
                        timestamp=timestamp,
                        fileName=entry.name,
                        bstack1llll1l1lll_opy_=entry.stat().st_size,
                        bstack1llll11111l_opy_=bstack1l1l11_opy_ (u"ࠤࡐࡅࡓ࡛ࡁࡍࡡࡘࡔࡑࡕࡁࡅࠤᔳ"),
                        bstack1ll11l_opy_=os.path.abspath(entry.path),
                        bstack1lllll1l111_opy_=hook.get(TestFramework.bstack1lllll11111_opy_)
                    )
                    logs.append(log_entry)
                    _1l11lll1111_opy_.add(abs_path)
        platform_index = os.environ[bstack1l1l11_opy_ (u"ࠪࡆࡗࡕࡗࡔࡇࡕࡗ࡙ࡇࡃࡌࡡࡓࡐࡆ࡚ࡆࡐࡔࡐࡣࡎࡔࡄࡆ࡚ࠪᔴ")]
        bstack1l11111l111_opy_ = os.path.join(bstack1l1l11111ll_opy_, (bstack1l1l11lll1l_opy_ + str(platform_index)), bstack11lll1llll1_opy_, bstack11llll1ll11_opy_)
        if not os.path.exists(bstack1l11111l111_opy_) or not os.path.isdir(bstack1l11111l111_opy_):
            self.logger.info(bstack1l1l11_opy_ (u"ࠦࡓࡵࠠࡃࡷ࡬ࡰࡩࡒࡥࡷࡧ࡯ࡌࡴࡵ࡫ࡆࡸࡨࡲࡹࠦࡡࡵࡶࡤࡧ࡭ࡳࡥ࡯ࡶࡶࠤࡩ࡯ࡲࡦࡥࡷࡳࡷࡿࠠࡧࡱࡸࡲࡩࠦࡡࡵ࠼ࠣࡿࢂࠨᔵ").format(bstack1l11111l111_opy_))
        else:
            self.logger.info(bstack1l1l11_opy_ (u"ࠧࡖࡲࡰࡥࡨࡷࡸ࡯࡮ࡨࠢࡅࡹ࡮ࡲࡤࡍࡧࡹࡩࡱࡎ࡯ࡰ࡭ࡈࡺࡪࡴࡴࠡࡣࡷࡸࡦࡩࡨ࡮ࡧࡱࡸࡸࠦࡦࡳࡱࡰࠤࡩ࡯ࡲࡦࡥࡷࡳࡷࡿ࠺ࠡࡽࢀࠦᔶ").format(bstack1l11111l111_opy_))
            with os.scandir(bstack1l11111l111_opy_) as entries:
                for entry in entries:
                    abs_path = os.path.abspath(entry.path)
                    if abs_path in _1l11lll1111_opy_:
                        self.logger.info(bstack1l1l11_opy_ (u"ࠨࡐࡢࡶ࡫ࠤࡦࡲࡲࡦࡣࡧࡽࠥࡶࡲࡰࡥࡨࡷࡸ࡫ࡤࠡࡽࢀࠦᔷ").format(abs_path))
                        continue
                    if entry.is_file():
                        try:
                            timestamp = datetime.fromtimestamp(entry.stat().st_mtime, tz=timezone.utc).isoformat()
                        except Exception:
                            timestamp = bstack1l1l11_opy_ (u"ࠢࠣᔸ")
                        log_entry = bstack1lllll111ll_opy_(
                            kind=bstack1l1l11_opy_ (u"ࠣࡖࡈࡗ࡙ࡥࡁࡕࡖࡄࡇࡍࡓࡅࡏࡖࠥᔹ"),
                            message=bstack1l1l11_opy_ (u"ࠤࠥᔺ"),
                            level=bstack1l1l11_opy_ (u"ࠥࡆࡺ࡯࡬ࡥࡎࡨࡺࡪࡲࠢᔻ"),
                            timestamp=timestamp,
                            fileName=entry.name,
                            bstack1llll1l1lll_opy_=entry.stat().st_size,
                            bstack1llll11111l_opy_=bstack1l1l11_opy_ (u"ࠦࡒࡇࡎࡖࡃࡏࡣ࡚ࡖࡌࡐࡃࡇࠦᔼ"),
                            bstack1ll11l_opy_=os.path.abspath(entry.path),
                            bstack1lll1ll1l1l_opy_=hook.get(TestFramework.bstack1lllll11111_opy_)
                        )
                        logs.append(log_entry)
                        _1l11lll1111_opy_.add(abs_path)
        hook[bstack1l1l11_opy_ (u"ࠧࡲ࡯ࡨࡵࠥᔽ")] = logs
    def bstack1l11lllllll_opy_(
        self,
        bstack1l11llll1ll_opy_: bstack1lllll111l1_opy_,
        entries: List[bstack1lllll111ll_opy_],
    ):
        req = structs.LogCreatedEventRequest()
        req.bin_session_id = os.environ.get(bstack1l1l11_opy_ (u"ࠨࡂࡓࡑ࡚ࡗࡊࡘࡓࡕࡃࡆࡏࡤࡉࡌࡊࡡࡅࡍࡓࡥࡓࡆࡕࡖࡍࡔࡔ࡟ࡊࡆࠥᔾ"))
        req.platform_index = TestFramework.bstack1lll1llllll_opy_(bstack1l11llll1ll_opy_, TestFramework.bstack1llll11ll1l_opy_)
        req.execution_context.hash = str(bstack1l11llll1ll_opy_.context.hash)
        req.execution_context.thread_id = str(bstack1l11llll1ll_opy_.context.thread_id)
        req.execution_context.process_id = str(bstack1l11llll1ll_opy_.context.process_id)
        for entry in entries:
            log_entry = req.logs.add()
            log_entry.test_framework_name = TestFramework.bstack1lll1llllll_opy_(bstack1l11llll1ll_opy_, TestFramework.bstack1lll1ll111l_opy_)
            log_entry.test_framework_version = TestFramework.bstack1lll1llllll_opy_(bstack1l11llll1ll_opy_, TestFramework.bstack1lll1l1lll1_opy_)
            log_entry.uuid = entry.bstack1lllll1l111_opy_ if entry.bstack1lllll1l111_opy_ else TestFramework.bstack1lll1llllll_opy_(bstack1l11llll1ll_opy_, TestFramework.bstack1llll1l1ll1_opy_)
            log_entry.test_framework_state = bstack1l11llll1ll_opy_.state.name
            log_entry.message = entry.message.encode(bstack1l1l11_opy_ (u"ࠢࡶࡶࡩ࠱࠽ࠨᔿ"))
            log_entry.kind = entry.kind
            log_entry.timestamp = (
                entry.timestamp.isoformat()
                if isinstance(entry.timestamp, datetime)
                else datetime.now(tz=timezone.utc).isoformat()
            )
            if isinstance(entry.level, str) and len(entry.level.strip()) > 0:
                log_entry.level = entry.level.strip()
            if entry.kind == bstack1l1l11_opy_ (u"ࠣࡖࡈࡗ࡙ࡥࡁࡕࡖࡄࡇࡍࡓࡅࡏࡖࠥᕀ"):
                log_entry.file_name = entry.fileName
                log_entry.file_size = entry.bstack1llll1l1lll_opy_
                log_entry.file_path = entry.bstack1ll11l_opy_
        def bstack1l1l1111lll_opy_():
            bstack11l1l1ll1_opy_ = datetime.now()
            try:
                self.bstack1ll1ll1l111_opy_.LogCreatedEvent(req)
                bstack1l11llll1ll_opy_.bstack1lllll111_opy_(bstack1l1l11_opy_ (u"ࠤࡪࡶࡵࡩ࠺ࡴࡧࡱࡨࡤࡲ࡯ࡨࡡࡦࡶࡪࡧࡴࡦࡦࡢࡩࡻ࡫࡮ࡵࡡࡤࡸࡹࡧࡣࡩ࡯ࡨࡲࡹࠨᕁ"), datetime.now() - bstack11l1l1ll1_opy_)
            except grpc.RpcError as e:
                self.log_error(bstack1l1l11_opy_ (u"ࠥࡶࡵࡩ࠭ࡦࡴࡵࡳࡷࡀࠠࡴࡧࡱࡨࡤࡲ࡯ࡨࡡࡦࡶࡪࡧࡴࡦࡦࡢࡩࡻ࡫࡮ࡵࡡࡤࡸࡹࡧࡣࡩ࡯ࡨࡲࡹࠦࡻࡾࠤᕂ").format(str(e)))
                traceback.print_exc()
        self.bstack1llll11l1l1_opy_.enqueue(bstack1l1l1111lll_opy_)
    def __11lll1ll11l_opy_(self, instance) -> None:
        bstack1l1l11_opy_ (u"ࠦࠧࠨࠊࠡࠢࠣࠤࠥࠦࠠࠡࡎࡲࡥࡩࡹࠠࡤࡷࡶࡸࡴࡳࠠࡵࡣࡪࡷࠥ࡬࡯ࡳࠢࡷ࡬ࡪࠦࡧࡪࡸࡨࡲࠥࡺࡥࡴࡶࠣࡪࡷࡧ࡭ࡦࡹࡲࡶࡰࠦࡩ࡯ࡵࡷࡥࡳࡩࡥ࠯ࠌࠣࠤࠥࠦࠠࠡࠢࠣࡇࡷ࡫ࡡࡵࡧࡶࠤࡦࠦࡤࡪࡥࡷࠤࡨࡵ࡮ࡵࡣ࡬ࡲ࡮ࡴࡧࠡࡶࡨࡷࡹࠦ࡬ࡦࡸࡨࡰࠥࡩࡵࡴࡶࡲࡱࠥࡳࡥࡵࡣࡧࡥࡹࡧࠠࡳࡧࡷࡶ࡮࡫ࡶࡦࡦࠣࡪࡷࡵ࡭ࠋࠢࠣࠤࠥࠦࠠࠡࠢࡆࡹࡸࡺ࡯࡮ࡖࡤ࡫ࡒࡧ࡮ࡢࡩࡨࡶࠥࡧ࡮ࡥࠢࡸࡴࡩࡧࡴࡦࡵࠣࡸ࡭࡫ࠠࡪࡰࡶࡸࡦࡴࡣࡦࠢࡶࡸࡦࡺࡥࠡࡷࡶ࡭ࡳ࡭ࠠࡴࡧࡷࡣࡸࡺࡡࡵࡧࡢࡩࡳࡺࡲࡪࡧࡶ࠲ࠏࠦࠠࠡࠢࠣࠤࠥࠦࠢࠣࠤᕃ")
        bstack1l111111l1l_opy_ = {bstack1l1l11_opy_ (u"ࠧࡩࡵࡴࡶࡲࡱࡤࡳࡥࡵࡣࡧࡥࡹࡧࠢᕄ"): bstack1ll1llllll1_opy_.bstack11llll11l1l_opy_()}
        TestFramework.bstack1lll1l1ll1l_opy_(instance, bstack1l111111l1l_opy_)
    @staticmethod
    def __11lll1ll1l1_opy_(instance, args):
        request, bstack1l111111lll_opy_ = args
        bstack11llllll11l_opy_ = id(bstack1l111111lll_opy_)
        bstack11lllll111l_opy_ = instance.data[TestFramework.bstack1lll1lll1l1_opy_]
        step = next(filter(lambda st: st[bstack1l1l11_opy_ (u"࠭ࡩࡥࠩᕅ")] == bstack11llllll11l_opy_, bstack11lllll111l_opy_[bstack1l1l11_opy_ (u"ࠧࡴࡶࡨࡴࡸ࠭ᕆ")]), None)
        step.update({
            bstack1l1l11_opy_ (u"ࠨࡵࡷࡥࡷࡺࡥࡥࡡࡤࡸࠬᕇ"): datetime.now(tz=timezone.utc)
        })
        index = next((i for i, st in enumerate(bstack11lllll111l_opy_[bstack1l1l11_opy_ (u"ࠩࡶࡸࡪࡶࡳࠨᕈ")]) if st[bstack1l1l11_opy_ (u"ࠪ࡭ࡩ࠭ᕉ")] == step[bstack1l1l11_opy_ (u"ࠫ࡮ࡪࠧᕊ")]), None)
        if index is not None:
            bstack11lllll111l_opy_[bstack1l1l11_opy_ (u"ࠬࡹࡴࡦࡲࡶࠫᕋ")][index] = step
        instance.data[TestFramework.bstack1lll1lll1l1_opy_] = bstack11lllll111l_opy_
    @staticmethod
    def __1l11111l1l1_opy_(instance, args):
        bstack1l1l11_opy_ (u"ࠨࠢࠣࠌࠣࠤࠥࠦࠠࠡࠢࠣࡻ࡭࡫࡮ࠡ࡮ࡨࡲࠥࡧࡲࡨࡵࠣ࡭ࡸࠦ࠲࠭ࠢ࡬ࡸࠥࡹࡩࡨࡰ࡬ࡪ࡮࡫ࡳࠡࡶ࡫ࡩࡷ࡫ࠠࡪࡵࠣࡲࡴࠦࡥࡹࡥࡨࡴࡹ࡯࡯࡯ࠌࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࡢࡴࡪࡷࠥࡧࡲࡦࠢ࠰ࠤࡠࡸࡥࡲࡷࡨࡷࡹ࠲ࠠࡴࡶࡨࡴࡢࠐࠠࠡࠢࠣࠤࠥࠦࠠࡪࡨࠣࡥࡷ࡭ࡳࠡࡣࡵࡩࠥ࠹ࠠࡵࡪࡨࡲࠥࡺࡨࡦࠢ࡯ࡥࡸࡺࠠࡷࡣ࡯ࡹࡪࠦࡩࡴࠢࡨࡼࡨ࡫ࡰࡵ࡫ࡲࡲࠏࠦࠠࠡࠢࠣࠤࠥࠦࠢࠣࠤᕌ")
        bstack1l1111111ll_opy_ = datetime.now(tz=timezone.utc)
        request = args[0]
        bstack1l111111lll_opy_ = args[1]
        bstack11llllll11l_opy_ = id(bstack1l111111lll_opy_)
        bstack11lllll111l_opy_ = instance.data[TestFramework.bstack1lll1lll1l1_opy_]
        step = None
        if bstack11llllll11l_opy_ is not None and bstack11lllll111l_opy_.get(bstack1l1l11_opy_ (u"ࠧࡴࡶࡨࡴࡸ࠭ᕍ")):
            step = next(filter(lambda st: st[bstack1l1l11_opy_ (u"ࠨ࡫ࡧࠫᕎ")] == bstack11llllll11l_opy_, bstack11lllll111l_opy_[bstack1l1l11_opy_ (u"ࠩࡶࡸࡪࡶࡳࠨᕏ")]), None)
            step.update({
                bstack1l1l11_opy_ (u"ࠪࡪ࡮ࡴࡩࡴࡪࡨࡨࡤࡧࡴࠨᕐ"): bstack1l1111111ll_opy_,
            })
        if len(args) > 2:
            exception = args[2]
            step.update({
                bstack1l1l11_opy_ (u"ࠫࡷ࡫ࡳࡶ࡮ࡷࠫᕑ"): bstack1l1l11_opy_ (u"ࠬ࡬ࡡࡪ࡮ࡨࡨࠬᕒ"),
                bstack1l1l11_opy_ (u"࠭ࡦࡢ࡫࡯ࡹࡷ࡫ࠧᕓ"): str(exception)
            })
        else:
            if step is not None:
                step.update({
                    bstack1l1l11_opy_ (u"ࠧࡳࡧࡶࡹࡱࡺࠧᕔ"): bstack1l1l11_opy_ (u"ࠨࡲࡤࡷࡸ࡫ࡤࠨᕕ"),
                })
        index = next((i for i, st in enumerate(bstack11lllll111l_opy_[bstack1l1l11_opy_ (u"ࠩࡶࡸࡪࡶࡳࠨᕖ")]) if st[bstack1l1l11_opy_ (u"ࠪ࡭ࡩ࠭ᕗ")] == step[bstack1l1l11_opy_ (u"ࠫ࡮ࡪࠧᕘ")]), None)
        if index is not None:
            bstack11lllll111l_opy_[bstack1l1l11_opy_ (u"ࠬࡹࡴࡦࡲࡶࠫᕙ")][index] = step
        instance.data[TestFramework.bstack1lll1lll1l1_opy_] = bstack11lllll111l_opy_
    @staticmethod
    def __11llll11111_opy_(node):
        try:
            examples = []
            if hasattr(node, bstack1l1l11_opy_ (u"࠭ࡣࡢ࡮࡯ࡷࡵ࡫ࡣࠨᕚ")):
                examples = list(node.callspec.params[bstack1l1l11_opy_ (u"ࠧࡠࡲࡼࡸࡪࡹࡴࡠࡤࡧࡨࡤ࡫ࡸࡢ࡯ࡳࡰࡪ࠭ᕛ")].values())
            return examples
        except:
            return []
    def bstack1llllll1l11_opy_(self, instance: bstack1lllll111l1_opy_, bstack1llll1111ll_opy_: Tuple[bstack1llll111lll_opy_, bstack1llll1ll111_opy_]):
        bstack11llll111ll_opy_ = (
            PytestBDDFramework.bstack11lll1lllll_opy_
            if bstack1llll1111ll_opy_[1] == bstack1llll1ll111_opy_.PRE
            else PytestBDDFramework.bstack11lll1l1lll_opy_
        )
        hook = PytestBDDFramework.bstack11llll11lll_opy_(instance, bstack11llll111ll_opy_)
        entries = hook.get(TestFramework.bstack1lllll1ll11_opy_, []) if isinstance(hook, dict) else []
        entries.extend(TestFramework.bstack1lll1llllll_opy_(instance, TestFramework.bstack1lll1ll1l11_opy_, []))
        return entries
    def bstack1llllll1111_opy_(self, instance: bstack1lllll111l1_opy_, bstack1llll1111ll_opy_: Tuple[bstack1llll111lll_opy_, bstack1llll1ll111_opy_]):
        bstack11llll111ll_opy_ = (
            PytestBDDFramework.bstack11lll1lllll_opy_
            if bstack1llll1111ll_opy_[1] == bstack1llll1ll111_opy_.PRE
            else PytestBDDFramework.bstack11lll1l1lll_opy_
        )
        PytestBDDFramework.bstack11lllll1111_opy_(instance, bstack11llll111ll_opy_)
        TestFramework.bstack1lll1llllll_opy_(instance, TestFramework.bstack1lll1ll1l11_opy_, []).clear()
    @staticmethod
    def bstack11llll11lll_opy_(instance: bstack1lllll111l1_opy_, bstack11llll111ll_opy_: str):
        bstack11llllll1ll_opy_ = (
            PytestBDDFramework.bstack1l11111ll11_opy_
            if bstack11llll111ll_opy_ == PytestBDDFramework.bstack11lll1l1lll_opy_
            else PytestBDDFramework.bstack11lllll1lll_opy_
        )
        bstack11llllll1l1_opy_ = TestFramework.bstack1lll1llllll_opy_(instance, bstack11llll111ll_opy_, None)
        bstack1l11111l1ll_opy_ = TestFramework.bstack1lll1llllll_opy_(instance, bstack11llllll1ll_opy_, None) if bstack11llllll1l1_opy_ else None
        return (
            bstack1l11111l1ll_opy_[bstack11llllll1l1_opy_][-1]
            if isinstance(bstack1l11111l1ll_opy_, dict) and len(bstack1l11111l1ll_opy_.get(bstack11llllll1l1_opy_, [])) > 0
            else None
        )
    @staticmethod
    def bstack11lllll1111_opy_(instance: bstack1lllll111l1_opy_, bstack11llll111ll_opy_: str):
        hook = PytestBDDFramework.bstack11llll11lll_opy_(instance, bstack11llll111ll_opy_)
        if isinstance(hook, dict):
            hook.get(TestFramework.bstack1lllll1ll11_opy_, []).clear()
    @staticmethod
    def __11llll11ll1_opy_(instance: bstack1lllll111l1_opy_, *args):
        if len(args) < 2 or not callable(getattr(args[1], bstack1l1l11_opy_ (u"ࠣࡩࡨࡸࡤࡸࡥࡤࡱࡵࡨࡸࠨᕜ"), None)):
            return
        if os.getenv(bstack1l1l11_opy_ (u"ࠤࡖࡈࡐࡥࡃࡍࡋࡢࡊࡑࡇࡇࡠࡎࡒࡋࡘࠨᕝ"), bstack1l1l11_opy_ (u"ࠥ࠵ࠧᕞ")) != bstack1l1l11_opy_ (u"ࠦ࠶ࠨᕟ"):
            PytestBDDFramework.logger.warning(bstack1l1l11_opy_ (u"ࠧ࡯ࡧ࡯ࡱࡵ࡭ࡳ࡭ࠠࡤࡣࡳࡰࡴ࡭ࠢᕠ"))
            return
        bstack11lllll1l11_opy_ = {
            bstack1l1l11_opy_ (u"ࠨࡳࡦࡶࡸࡴࠧᕡ"): (PytestBDDFramework.bstack11lll1lllll_opy_, PytestBDDFramework.bstack11lllll1lll_opy_),
            bstack1l1l11_opy_ (u"ࠢࡵࡧࡤࡶࡩࡵࡷ࡯ࠤᕢ"): (PytestBDDFramework.bstack11lll1l1lll_opy_, PytestBDDFramework.bstack1l11111ll11_opy_),
        }
        for when in (bstack1l1l11_opy_ (u"ࠣࡵࡨࡸࡺࡶࠢᕣ"), bstack1l1l11_opy_ (u"ࠤࡦࡥࡱࡲࠢᕤ"), bstack1l1l11_opy_ (u"ࠥࡸࡪࡧࡲࡥࡱࡺࡲࠧᕥ")):
            bstack11lll1lll1l_opy_ = args[1].get_records(when)
            if not bstack11lll1lll1l_opy_:
                continue
            records = [
                bstack1lllll111ll_opy_(
                    kind=TestFramework.bstack1lll1ll11l1_opy_,
                    message=r.message,
                    level=r.levelname if hasattr(r, bstack1l1l11_opy_ (u"ࠦࡱ࡫ࡶࡦ࡮ࡱࡥࡲ࡫ࠢᕦ")) and r.levelname else None,
                    timestamp=(
                        datetime.fromtimestamp(r.created, tz=timezone.utc)
                        if hasattr(r, bstack1l1l11_opy_ (u"ࠧࡩࡲࡦࡣࡷࡩࡩࠨᕧ")) and r.created
                        else None
                    ),
                )
                for r in bstack11lll1lll1l_opy_
                if isinstance(getattr(r, bstack1l1l11_opy_ (u"ࠨ࡭ࡦࡵࡶࡥ࡬࡫ࠢᕨ"), None), str) and r.message.strip()
            ]
            if not records:
                continue
            bstack11llll1l111_opy_, bstack11llllll1ll_opy_ = bstack11lllll1l11_opy_.get(when, (None, None))
            bstack11lllll11l1_opy_ = TestFramework.bstack1lll1llllll_opy_(instance, bstack11llll1l111_opy_, None) if bstack11llll1l111_opy_ else None
            bstack1l11111l1ll_opy_ = TestFramework.bstack1lll1llllll_opy_(instance, bstack11llllll1ll_opy_, None) if bstack11lllll11l1_opy_ else None
            if isinstance(bstack1l11111l1ll_opy_, dict) and len(bstack1l11111l1ll_opy_.get(bstack11lllll11l1_opy_, [])) > 0:
                hook = bstack1l11111l1ll_opy_[bstack11lllll11l1_opy_][-1]
                if isinstance(hook, dict) and TestFramework.bstack1lllll1ll11_opy_ in hook:
                    hook[TestFramework.bstack1lllll1ll11_opy_].extend(records)
                    continue
            logs = TestFramework.bstack1lll1llllll_opy_(instance, TestFramework.bstack1lll1ll1l11_opy_, [])
            logs.extend(records)
    @staticmethod
    def __1l111111ll1_opy_(args) -> Dict[str, Any]:
        request, feature, scenario = args
        bstack11lll11111_opy_ = request.node.nodeid
        test_name = PytestBDDFramework.__1l11111lll1_opy_(request.node, scenario)
        bstack11lllllll11_opy_ = feature.filename
        if not bstack11lll11111_opy_ or not test_name or not bstack11lllllll11_opy_:
            return None
        code = None
        return {
            TestFramework.bstack1llll1l1ll1_opy_: uuid4().__str__(),
            TestFramework.bstack1lll1ll1lll_opy_: bstack11lll11111_opy_,
            TestFramework.bstack1llll11l1ll_opy_: test_name,
            TestFramework.bstack1lll1lllll1_opy_: bstack11lll11111_opy_,
            TestFramework.bstack1lllll11l11_opy_: bstack11lllllll11_opy_,
            TestFramework.bstack1lll1ll1111_opy_: PytestBDDFramework.__11llll1l11l_opy_(feature, scenario),
            TestFramework.bstack1lll1l1l1ll_opy_: code,
            TestFramework.bstack1llllll111l_opy_: TestFramework.bstack1lllll11lll_opy_,
            TestFramework.bstack1lll1l1l11l_opy_: test_name
        }
    @staticmethod
    def __1l11111lll1_opy_(node, scenario):
        if hasattr(node, bstack1l1l11_opy_ (u"ࠧࡤࡣ࡯ࡰࡸࡶࡥࡤࠩᕩ")):
            parts = node.nodeid.rsplit(bstack1l1l11_opy_ (u"ࠣ࡝ࠥᕪ"))
            params = parts[-1]
            return bstack1l1l11_opy_ (u"ࠤࡾࢁࠥࡡࡻࡾࠤᕫ").format(scenario.name, params)
        return scenario.name
    @staticmethod
    def __11llll1l11l_opy_(feature, scenario) -> List[str]:
        return (list(feature.tags) if hasattr(feature, bstack1l1l11_opy_ (u"ࠪࡸࡦ࡭ࡳࠨᕬ")) else []) + (list(scenario.tags) if hasattr(scenario, bstack1l1l11_opy_ (u"ࠫࡹࡧࡧࡴࠩᕭ")) else [])
    @staticmethod
    def __1l111111l11_opy_(location):
        return bstack1l1l11_opy_ (u"ࠧࡀ࠺ࠣᕮ").join(filter(lambda x: isinstance(x, str), location))