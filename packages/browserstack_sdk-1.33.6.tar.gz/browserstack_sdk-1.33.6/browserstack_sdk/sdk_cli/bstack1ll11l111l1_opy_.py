# coding: UTF-8
import sys
bstack1l11111_opy_ = sys.version_info [0] == 2
bstack11l11ll_opy_ = 2048
bstack111ll1l_opy_ = 7
def bstack1l1l11_opy_ (bstack11l1l_opy_):
    global bstack1l11_opy_
    bstack11l1111_opy_ = ord (bstack11l1l_opy_ [-1])
    bstack1l1ll1l_opy_ = bstack11l1l_opy_ [:-1]
    bstack11l11_opy_ = bstack11l1111_opy_ % len (bstack1l1ll1l_opy_)
    bstack1l1ll11_opy_ = bstack1l1ll1l_opy_ [:bstack11l11_opy_] + bstack1l1ll1l_opy_ [bstack11l11_opy_:]
    if bstack1l11111_opy_:
        bstack11lll1l_opy_ = unicode () .join ([unichr (ord (char) - bstack11l11ll_opy_ - (bstack11l111_opy_ + bstack11l1111_opy_) % bstack111ll1l_opy_) for bstack11l111_opy_, char in enumerate (bstack1l1ll11_opy_)])
    else:
        bstack11lll1l_opy_ = str () .join ([chr (ord (char) - bstack11l11ll_opy_ - (bstack11l111_opy_ + bstack11l1111_opy_) % bstack111ll1l_opy_) for bstack11l111_opy_, char in enumerate (bstack1l1ll11_opy_)])
    return eval (bstack11lll1l_opy_)
import logging
import abc
from browserstack_sdk.sdk_cli.bstack1llll11l1l1_opy_ import bstack1lllll1lll1_opy_
class bstack1ll1l1lllll_opy_(abc.ABC):
    bin_session_id: str
    bstack1llll11l1l1_opy_: bstack1lllll1lll1_opy_
    def __init__(self):
        self.bstack1ll1ll1l111_opy_ = None
        self.config = None
        self.bin_session_id = None
        self.bstack1llll11l1l1_opy_ = None
        self.logger = logging.getLogger(self.__class__.__name__)
        self.logger.setLevel(logging.INFO)
    def bstack1ll1l1ll1l1_opy_(self):
        return (self.bstack1ll1ll1l111_opy_ != None and self.bin_session_id != None and self.bstack1llll11l1l1_opy_ != None)
    def configure(self, bstack1ll1ll1l111_opy_, config, bin_session_id: str, bstack1llll11l1l1_opy_: bstack1lllll1lll1_opy_):
        self.bstack1ll1ll1l111_opy_ = bstack1ll1ll1l111_opy_
        self.config = config
        self.bin_session_id = bin_session_id
        self.bstack1llll11l1l1_opy_ = bstack1llll11l1l1_opy_
        if self.bin_session_id:
            self.logger.debug(bstack1l1l11_opy_ (u"ࠨ࡛ࡼ࡫ࡧࠬࡸ࡫࡬ࡧࠫࢀࡡࠥࡩ࡯࡯ࡨ࡬࡫ࡺࡸࡥࡥࠢࡰࡳࡩࡻ࡬ࡦࠢࡾࡷࡪࡲࡦ࠯ࡡࡢࡧࡱࡧࡳࡴࡡࡢ࠲ࡤࡥ࡮ࡢ࡯ࡨࡣࡤࢃ࠺ࠡࡤ࡬ࡲࡤࡹࡥࡴࡵ࡬ࡳࡳࡥࡩࡥ࠿ࠥዖ") + str(self.bin_session_id) + bstack1l1l11_opy_ (u"ࠢࠣ዗"))
    def bstack1l1ll11l111_opy_(self):
        if not self.bin_session_id:
            raise ValueError(bstack1l1l11_opy_ (u"ࠣࡤ࡬ࡲࡤࡹࡥࡴࡵ࡬ࡳࡳࡥࡩࡥࠢࡦࡥࡳࡴ࡯ࡵࠢࡥࡩࠥࡔ࡯࡯ࡧࠥዘ"))
    @abc.abstractmethod
    def is_enabled(self) -> bool:
        return False