from setuptools import setup

setup(
    name="jema-ai",
    version="0.0.1",
    author="MKM Lab",
    author_email="support@mkmlife.com",
    description="This package has been moved to 'acodeai'. Please use 'pip install acodeai' instead.",
    long_description="""
# Jema-Ai Package Migration Notice

This package has been integrated into **acodeai**.

## Migration Guide

```bash
# Old (deprecated)
pip install jema-ai

# New (recommended)
pip install acodeai
```

## Usage

```python
# Old
from jema_ai import *

# New
from acodeai import JemaClient, AthenaClient
```

For more information, visit: https://github.com/mkmlab-hq/acodeai-python
""",
    long_description_content_type="text/markdown",
    url="https://github.com/mkmlab-hq/acodeai-python",
    py_modules=[],
    install_requires=["acodeai>=1.0.0"],
    classifiers=[
        "Development Status :: 7 - Inactive",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
    ],
    python_requires=">=3.11",
)
