#!/usr/bin/env python3
"""
SemBicho CLI - Entry point for console script
"""

# Import main function from the package's __main__ module
from sembicho.__main__ import main

if __name__ == '__main__':
    main()
