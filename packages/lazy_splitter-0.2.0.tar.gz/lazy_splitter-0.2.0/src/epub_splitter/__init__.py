"""EPUB chapter detection and splitting."""

__version__ = "0.1.0"
