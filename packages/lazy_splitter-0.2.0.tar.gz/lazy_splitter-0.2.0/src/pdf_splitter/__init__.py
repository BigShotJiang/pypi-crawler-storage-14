"""PDF Chapter Splitter - A CLI tool for intelligent PDF chapter detection and splitting."""

__version__ = "0.1.0"
