"""Main entry point for the PDF splitter CLI."""

from pdf_splitter.cli import main

if __name__ == "__main__":
    main()
