"""
Unit tests for template premium validation (minpremium and maxpremium).
"""
import os
import sys
import unittest

sys.path.append(os.path.join(os.path.dirname(__file__), '../..'))

from optrabot.tradetemplate.templatefactory import IronCondor, Template


class TemplatePremiumTests(unittest.TestCase):
	"""Test suite for template premium validation"""

	def test_max_premium_field_initialization(self) -> None:
		"""Test that max_premium field is properly initialized to None"""
		template = Template('TestTemplate')
		self.assertTrue(hasattr(template, 'max_premium'))
		self.assertIsNone(template.max_premium)

	def test_set_max_premium(self) -> None:
		"""Test that set_max_premium correctly sets the value"""
		template = Template('TestTemplate')
		template.set_max_premium(1.5)
		self.assertEqual(template.max_premium, 1.5)

	def test_meets_maximum_premium_when_not_set(self) -> None:
		"""Test that meets_maximum_premium returns True when max_premium is not set"""
		template = Template('TestTemplate')
		# Should always return True when max_premium is None
		self.assertTrue(template.meets_maximum_premium(-0.50))
		self.assertTrue(template.meets_maximum_premium(-1.00))
		self.assertTrue(template.meets_maximum_premium(-5.00))
		self.assertTrue(template.meets_maximum_premium(0.50))
		self.assertTrue(template.meets_maximum_premium(1.00))

	def test_meets_maximum_premium_credit_trade_within_limit(self) -> None:
		"""Test credit trade (negative premium) within max_premium limit"""
		template = Template('TestTemplate')
		template.set_max_premium(1.0)
		
		# Credit trades have negative premium
		# -0.50 means $0.50 credit received, which is within $1.00 max
		self.assertTrue(template.meets_maximum_premium(-0.50))
		self.assertTrue(template.meets_maximum_premium(-0.99))
		self.assertTrue(template.meets_maximum_premium(-1.00))  # Exactly at limit

	def test_meets_maximum_premium_credit_trade_exceeds_limit(self) -> None:
		"""Test credit trade (negative premium) exceeding max_premium limit"""
		template = Template('TestTemplate')
		template.set_max_premium(1.0)
		
		# -1.50 means $1.50 credit received, which exceeds $1.00 max
		self.assertFalse(template.meets_maximum_premium(-1.50))
		self.assertFalse(template.meets_maximum_premium(-2.00))
		self.assertFalse(template.meets_maximum_premium(-1.01))

	def test_meets_maximum_premium_debit_trade_within_limit(self) -> None:
		"""Test debit trade (positive premium) within max_premium limit"""
		template = Template('TestTemplate')
		template.set_max_premium(2.0)
		
		# Debit trades have positive premium
		# 0.50 means $0.50 debit paid, which is within $2.00 max
		self.assertTrue(template.meets_maximum_premium(0.50))
		self.assertTrue(template.meets_maximum_premium(1.99))
		self.assertTrue(template.meets_maximum_premium(2.00))  # Exactly at limit

	def test_meets_maximum_premium_debit_trade_exceeds_limit(self) -> None:
		"""Test debit trade (positive premium) exceeding max_premium limit"""
		template = Template('TestTemplate')
		template.set_max_premium(2.0)
		
		# 2.50 means $2.50 debit paid, which exceeds $2.00 max
		self.assertFalse(template.meets_maximum_premium(2.50))
		self.assertFalse(template.meets_maximum_premium(3.00))
		self.assertFalse(template.meets_maximum_premium(2.01))


class TemplateValidationTests(unittest.TestCase):
	"""Test suite for template validation including premium constraints"""

	def test_validate_max_premium_greater_than_min_premium(self) -> None:
		"""Test that validation passes when max_premium > min_premium"""
		template = IronCondor('TestIronCondor')
		template.setMinPremium(0.20)
		template.set_max_premium(1.00)
		
		self.assertTrue(template.validate())

	def test_validate_max_premium_equal_to_min_premium_fails(self) -> None:
		"""Test that validation fails when max_premium == min_premium"""
		template = IronCondor('TestIronCondor')
		template.setMinPremium(0.50)
		template.set_max_premium(0.50)
		
		self.assertFalse(template.validate())

	def test_validate_max_premium_less_than_min_premium_fails(self) -> None:
		"""Test that validation fails when max_premium < min_premium"""
		template = IronCondor('TestIronCondor')
		template.setMinPremium(1.00)
		template.set_max_premium(0.50)
		
		self.assertFalse(template.validate())

	def test_validate_only_min_premium_set(self) -> None:
		"""Test that validation passes when only min_premium is set"""
		template = IronCondor('TestIronCondor')
		template.setMinPremium(0.20)
		# max_premium remains None
		
		self.assertTrue(template.validate())

	def test_validate_only_max_premium_set(self) -> None:
		"""Test that validation passes when only max_premium is set"""
		template = IronCondor('TestIronCondor')
		# minPremium remains None
		template.set_max_premium(1.00)
		
		self.assertTrue(template.validate())

	def test_validate_neither_premium_set(self) -> None:
		"""Test that validation passes when neither premium is set"""
		template = IronCondor('TestIronCondor')
		# Both remain None
		
		self.assertTrue(template.validate())


class TemplatePremiumCombinedTests(unittest.TestCase):
	"""Test suite for combined min/max premium behavior"""

	def test_premium_within_both_limits(self) -> None:
		"""Test premium that satisfies both min and max requirements"""
		template = Template('TestTemplate')
		template.setMinPremium(0.20)
		template.set_max_premium(1.00)
		
		# -0.50 is $0.50 credit: >= $0.20 min and <= $1.00 max
		self.assertTrue(template.meetsMinimumPremium(-0.50))
		self.assertTrue(template.meets_maximum_premium(-0.50))

	def test_premium_below_minimum(self) -> None:
		"""Test premium that fails minimum requirement"""
		template = Template('TestTemplate')
		template.setMinPremium(0.50)
		template.set_max_premium(1.00)
		
		# -0.20 is $0.20 credit: < $0.50 min (fails)
		self.assertFalse(template.meetsMinimumPremium(-0.20))
		self.assertTrue(template.meets_maximum_premium(-0.20))

	def test_premium_exceeds_maximum(self) -> None:
		"""Test premium that fails maximum requirement"""
		template = Template('TestTemplate')
		template.setMinPremium(0.20)
		template.set_max_premium(1.00)
		
		# -1.50 is $1.50 credit: >= $0.20 min but > $1.00 max (fails max)
		self.assertTrue(template.meetsMinimumPremium(-1.50))
		self.assertFalse(template.meets_maximum_premium(-1.50))

	def test_premium_at_exact_limits(self) -> None:
		"""Test premium at exact min and max boundaries"""
		template = Template('TestTemplate')
		template.setMinPremium(0.50)
		template.set_max_premium(1.00)
		
		# -0.50 is exactly at min limit
		self.assertTrue(template.meetsMinimumPremium(-0.50))
		self.assertTrue(template.meets_maximum_premium(-0.50))
		
		# -1.00 is exactly at max limit
		self.assertTrue(template.meetsMinimumPremium(-1.00))
		self.assertTrue(template.meets_maximum_premium(-1.00))


if __name__ == '__main__':
	unittest.main()
