import os
import sys

sys.path.append(os.path.join(os.path.dirname(__file__), '..'))
import asyncio
import unittest
from datetime import datetime
from unittest.mock import AsyncMock, MagicMock, Mock, call, patch

from optrabot import models, schemas
from optrabot.broker.order import Order, OrderAction, OrderStatus, OrderType
from optrabot.managedtrade import ManagedTrade
from optrabot.trademanager import TradeManager
from optrabot.tradestatus import TradeStatus
from optrabot.tradetemplate.templatefactory import Template


class TradeManagerTests(unittest.TestCase):
	"""
	Unit tests for TradeManager class.
	Focus: Duplicate FILLED event handling and flow event emission.
	"""
	
	def setUp(self):
		"""Set up test fixtures"""
		# Reset singleton instance for each test
		TradeManager._instances = {}
		
	def tearDown(self):
		"""Clean up after tests"""
		# Shutdown TradeManager if it was created
		if TradeManager in TradeManager._instances:
			try:
				TradeManager._instances[TradeManager].shutdown()
			except:
				pass
		TradeManager._instances = {}
	
	def test_duplicate_filled_event_closing_order_ignored(self):
		"""
		OTB-XXX: Test that FILLED event after execution details is handled correctly.
		
		Scenario:
		- Multi-contract BAG order (Iron Condor with AMOUNT=3)
		- _onOrderExecutionDetailsEvent sets trade status to CLOSED (happens first)
		- Then _onOrderStatusChanged with FILLED is called
		- Should still send notifications and emit flow event
		- But should skip _close_trade() call (trade already closed)
		
		Expected:
		- _close_trade() is NOT called (trade already closed by execution details)
		- Notifications ARE sent
		- Flow event IS emitted
		- Tracking job IS removed
		- Debug log confirms skipping _close_trade()
		"""
		# Create mock managed trade
		mock_trade = Mock(spec=models.Trade)
		mock_trade.id = 691
		mock_trade.status = TradeStatus.OPEN
		
		mock_template = Mock(spec=Template)
		mock_template.name = "FINALIC100Income"
		mock_template.strategy = "Final IC 100 Income"
		mock_template.account = "DU6504444"
		
		# Create mock entry order
		entry_order = Mock(spec=Order)
		entry_order.broker_order_id = '132200'
		entry_order.status = OrderStatus.FILLED
		entry_order.averageFillPrice = 0.60
		
		managed_trade = ManagedTrade(mock_trade, mock_template, entry_order, "DU6504444")
		# Simulate that execution details event already closed the trade
		managed_trade.status = TradeStatus.CLOSED
		
		# Create mock closing order
		closing_order = Mock(spec=Order)
		closing_order.broker_order_id = '132218'
		closing_order.status = OrderStatus.OPEN
		closing_order.averageFillPrice = -0.9
		closing_order.symbol = 'SPX'
		managed_trade.closing_order = closing_order
		
		# Patch TradeManager methods and dependencies
		with patch('optrabot.trademanager.Session') as mock_session, \
		     patch('optrabot.trademanager.get_db_engine') as mock_engine, \
		     patch('optrabot.trademanager.crud') as mock_crud, \
		     patch('optrabot.trademanager.BrokerFactory') as mock_broker_factory, \
		     patch('optrabot.tradinghubclient.TradinghubClient') as mock_trading_hub, \
		     patch('optrabot.trademanager.AsyncIOScheduler') as mock_scheduler, \
		     patch('optrabot.trademanager.logger') as mock_logger:
			
			# Setup mocks
			mock_session_instance = MagicMock()
			mock_session.return_value.__enter__.return_value = mock_session_instance
			
			mock_db_trade = Mock(spec=models.Trade)
			mock_db_trade.id = 691
			mock_db_trade.status = TradeStatus.CLOSED
			mock_crud.getTrade.return_value = mock_db_trade
			
			mock_trading_hub_instance = AsyncMock()
			mock_trading_hub.return_value = mock_trading_hub_instance
			mock_trading_hub_instance.send_notification = AsyncMock()
			
			# Mock scheduler with tracking job
			mock_scheduler_instance = Mock()
			mock_tracking_job = Mock()
			mock_scheduler_instance.get_job = Mock(return_value=mock_tracking_job)
			mock_scheduler_instance.remove_job = Mock()
			mock_scheduler.return_value = mock_scheduler_instance
			
			# Create TradeManager instance
			tm = TradeManager()
			tm._trades = [managed_trade]
			
			# Mock _close_trade and _emit_trade_exit_event_delayed to track calls
			tm._close_trade = Mock()
			tm._emit_trade_exit_event_delayed = AsyncMock()
			
			# Simulate FILLED event from broker (after execution details already closed trade)
			# Note: closing_order.status is still OPEN here - the status change happens inside _onOrderStatusChanged
			closing_order.averageFillPrice = -0.9
			
			# Run order status change
			asyncio.run(tm._onOrderStatusChanged(closing_order, OrderStatus.FILLED))
			
			# Verify trade is still closed
			self.assertEqual(managed_trade.status, TradeStatus.CLOSED)
			
			# Verify closing order status was updated to FILLED
			self.assertEqual(closing_order.status, OrderStatus.FILLED)
			
			# Verify _close_trade() was NOT called (trade already closed)
			tm._close_trade.assert_not_called()
			
			# Verify debug log about skipping _close_trade
			debug_calls = [str(call) for call in mock_logger.debug.call_args_list]
			self.assertTrue(
				any("already closed by execution details" in call and "skipping _close_trade()" in call 
				    for call in debug_calls),
				"Expected debug log about skipping _close_trade()"
			)
			
			# Verify flow event WAS emitted (we still want events/notifications)
			self.assertEqual(tm._emit_trade_exit_event_delayed.call_count, 1)
			
			# Verify success log was written
			mock_logger.success.assert_called_once()
			self.assertIn("finished", str(mock_logger.success.call_args))
			
			# Verify notification was sent
			mock_trading_hub_instance.send_notification.assert_called_once()
			
			# Verify tracking job was removed
			mock_scheduler_instance.get_job.assert_called_once_with('TrackClosingOrder691')
			mock_scheduler_instance.remove_job.assert_called_once_with('TrackClosingOrder691')
	
	def test_duplicate_filled_event_take_profit_ignored(self):
		"""
		OTB-XXX: Test that FILLED event after execution details is handled correctly for Take Profit.
		
		Similar to closing order scenario, but for Take Profit exits.
		Execution details close the trade first, then status event arrives.
		"""
		# Create mock managed trade
		mock_trade = Mock(spec=models.Trade)
		mock_trade.id = 789
		mock_trade.status = TradeStatus.OPEN
		
		mock_template = Mock(spec=Template)
		mock_template.name = "TestTemplate"
		mock_template.account = "DU6504444"
		
		# Create mock entry order
		entry_order = Mock(spec=Order)
		entry_order.broker_order_id = '130599'
		entry_order.status = OrderStatus.FILLED
		entry_order.averageFillPrice = 0.60
		
		managed_trade = ManagedTrade(mock_trade, mock_template, entry_order, "DU6504444")
		# Simulate that execution details event already closed the trade
		managed_trade.status = TradeStatus.CLOSED
		
		# Create mock take profit order
		tp_order = Mock(spec=Order)
		tp_order.broker_order_id = '130600'
		tp_order.status = OrderStatus.OPEN
		tp_order.averageFillPrice = -1.20
		tp_order.symbol = 'SPX'
		managed_trade.takeProfitOrder = tp_order
		
		with patch('optrabot.trademanager.Session') as mock_session, \
		     patch('optrabot.trademanager.get_db_engine') as mock_engine, \
		     patch('optrabot.trademanager.crud') as mock_crud, \
		     patch('optrabot.trademanager.BrokerFactory') as mock_broker_factory, \
		     patch('optrabot.tradinghubclient.TradinghubClient') as mock_trading_hub, \
		     patch('optrabot.trademanager.AsyncIOScheduler') as mock_scheduler, \
		     patch('optrabot.trademanager.logger') as mock_logger:
			
			# Setup mocks
			mock_session_instance = MagicMock()
			mock_session.return_value.__enter__.return_value = mock_session_instance
			
			mock_db_trade = Mock(spec=models.Trade)
			mock_db_trade.id = 789
			mock_db_trade.status = TradeStatus.CLOSED
			mock_crud.getTrade.return_value = mock_db_trade
			
			mock_trading_hub_instance = AsyncMock()
			mock_trading_hub.return_value = mock_trading_hub_instance
			mock_trading_hub_instance.send_notification = AsyncMock()
			
			# Mock scheduler
			mock_scheduler_instance = Mock()
			mock_scheduler.return_value = mock_scheduler_instance
			
			# Create TradeManager instance
			tm = TradeManager()
			tm._trades = [managed_trade]
			tm._close_trade = Mock()
			tm._emit_trade_exit_event_delayed = AsyncMock()
			
			# Simulate FILLED event (after execution details already closed trade)
			# Note: tp_order.status is still OPEN here - the status change happens inside _onOrderStatusChanged
			tp_order.averageFillPrice = -1.20
			asyncio.run(tm._onOrderStatusChanged(tp_order, OrderStatus.FILLED))
			
			# Verify _close_trade() was NOT called
			tm._close_trade.assert_not_called()
			
			# Verify flow event WAS emitted
			self.assertEqual(tm._emit_trade_exit_event_delayed.call_count, 1)
			
			# Verify notification was sent
			mock_trading_hub_instance.send_notification.assert_called_once()
			
			# Verify debug log about skipping _close_trade
			debug_calls = [str(call) for call in mock_logger.debug.call_args_list]
			self.assertTrue(
				any("already closed by execution details" in call 
				    for call in debug_calls)
			)
	
	def test_duplicate_filled_event_stop_loss_ignored(self):
		"""
		OTB-XXX: Test that FILLED event after execution details is handled correctly for Stop Loss.
		
		Similar to closing order scenario, but for Stop Loss exits.
		Execution details close the trade first, then status event arrives.
		"""
		# Create mock managed trade
		mock_trade = Mock(spec=models.Trade)
		mock_trade.id = 790
		mock_trade.status = TradeStatus.OPEN
		
		mock_template = Mock(spec=Template)
		mock_template.name = "TestTemplate"
		mock_template.account = "DU6504444"
		
		# Create mock entry order
		entry_order = Mock(spec=Order)
		entry_order.broker_order_id = '130699'
		entry_order.status = OrderStatus.FILLED
		entry_order.averageFillPrice = 0.60
		
		managed_trade = ManagedTrade(mock_trade, mock_template, entry_order, "DU6504444")
		# Simulate that execution details event already closed the trade
		managed_trade.status = TradeStatus.CLOSED
		
		# Create mock stop loss order
		sl_order = Mock(spec=Order)
		sl_order.broker_order_id = '130700'
		sl_order.status = OrderStatus.OPEN
		sl_order.averageFillPrice = 1.50
		sl_order.symbol = 'SPX'
		managed_trade.stopLossOrder = sl_order
		
		with patch('optrabot.trademanager.Session') as mock_session, \
		     patch('optrabot.trademanager.get_db_engine') as mock_engine, \
		     patch('optrabot.trademanager.crud') as mock_crud, \
		     patch('optrabot.trademanager.BrokerFactory') as mock_broker_factory, \
		     patch('optrabot.tradinghubclient.TradinghubClient') as mock_trading_hub, \
		     patch('optrabot.trademanager.AsyncIOScheduler') as mock_scheduler, \
		     patch('optrabot.trademanager.logger') as mock_logger:
			
			# Setup mocks
			mock_session_instance = MagicMock()
			mock_session.return_value.__enter__.return_value = mock_session_instance
			
			mock_db_trade = Mock(spec=models.Trade)
			mock_db_trade.id = 790
			mock_db_trade.status = TradeStatus.CLOSED
			mock_crud.getTrade.return_value = mock_db_trade
			
			mock_trading_hub_instance = AsyncMock()
			mock_trading_hub.return_value = mock_trading_hub_instance
			mock_trading_hub_instance.send_notification = AsyncMock()
			
			# Mock scheduler
			mock_scheduler_instance = Mock()
			mock_scheduler.return_value = mock_scheduler_instance
			
			# Create TradeManager instance
			tm = TradeManager()
			tm._trades = [managed_trade]
			tm._close_trade = Mock()
			tm._emit_trade_exit_event_delayed = AsyncMock()
			
			# Simulate FILLED event (after execution details already closed trade)
			# Note: sl_order.status is still OPEN here - the status change happens inside _onOrderStatusChanged
			sl_order.averageFillPrice = 1.50
			asyncio.run(tm._onOrderStatusChanged(sl_order, OrderStatus.FILLED))
			
			# Verify _close_trade() was NOT called
			tm._close_trade.assert_not_called()
			
			# Verify flow event WAS emitted
			self.assertEqual(tm._emit_trade_exit_event_delayed.call_count, 1)
			
			# Verify notification was sent
			mock_trading_hub_instance.send_notification.assert_called_once()
			
			# Verify debug log about skipping _close_trade
			debug_calls = [str(call) for call in mock_logger.debug.call_args_list]
			self.assertTrue(
				any("already closed by execution details" in call 
				    for call in debug_calls)
			)


class ZeroPriceClosingTransactionTests(unittest.TestCase):
	"""
	Unit tests for creating $0 closing transactions for legs excluded from closing order.
	
	The implementation stores excluded legs when creating the closing order, but only
	creates the $0 transactions when the closing order is actually FILLED. This prevents
	orphaned transactions if the closing order is cancelled.
	"""
	
	def setUp(self):
		"""Set up test fixtures"""
		# Reset singleton instance for each test
		TradeManager._instances = {}
		
	def tearDown(self):
		"""Clean up after tests"""
		if TradeManager in TradeManager._instances:
			try:
				asyncio.run(TradeManager._instances[TradeManager].shutdown())
			except:
				pass
		TradeManager._instances = {}

	def test_excluded_legs_stored_but_no_transaction_created_on_create_closing_order(self):
		"""
		Test that when _create_closing_order is called, legs with no bid price are
		stored in excluded_closing_legs but NO transactions are created yet.
		
		Transactions are only created when the closing order is FILLED.
		
		Scenario (Trade 381):
		- Iron Condor trade with 4 legs
		- Trade closed 7 minutes before market close
		- Leg at strike 6580 has no bid price (bidPrice=0)
		- This leg is excluded from closing order
		- excluded_closing_legs should contain the leg
		- NO $0 transaction should be created yet
		"""
		from datetime import date

		from optrabot.broker.order import Leg, OptionRight

		# Create mock managed trade
		mock_trade = Mock(spec=models.Trade)
		mock_trade.id = 381
		mock_trade.symbol = 'SPX'
		mock_trade.status = TradeStatus.OPEN
		
		mock_template = Mock(spec=Template)
		mock_template.name = "0DTEIncomeIC"
		mock_template.account = "U11192378"
		
		# Create mock entry order
		entry_order = Mock(spec=Order)
		entry_order.broker_order_id = '999001'
		entry_order.status = OrderStatus.FILLED
		entry_order.action = OrderAction.SELL_TO_OPEN
		entry_order.quantity = 1
		
		managed_trade = ManagedTrade(mock_trade, mock_template, entry_order, "U11192378")
		managed_trade.status = TradeStatus.OPEN
		managed_trade.transactions = []
		managed_trade.current_price = -0.50  # Current position value
		
		# Create current legs - one with no bid price
		leg_with_bid = Leg(action=OrderAction.BUY, symbol='SPX', quantity=1)
		leg_with_bid.strike = 6595.0
		leg_with_bid.right = OptionRight.PUT
		leg_with_bid.bidPrice = 0.03  # Has bid price
		leg_with_bid.expiration = date.today()
		
		leg_no_bid = Leg(action=OrderAction.BUY, symbol='SPX', quantity=1)
		leg_no_bid.strike = 6580.0
		leg_no_bid.right = OptionRight.PUT
		leg_no_bid.bidPrice = 0  # No bid price - will be excluded
		leg_no_bid.expiration = date.today()
		
		managed_trade.current_legs = [leg_with_bid, leg_no_bid]
		
		with patch('optrabot.trademanager.Session') as mock_session, \
		     patch('optrabot.trademanager.get_db_engine') as mock_engine, \
		     patch('optrabot.trademanager.crud') as mock_crud, \
		     patch('optrabot.trademanager.BrokerFactory') as mock_broker_factory, \
		     patch('optrabot.trademanager.TradeHelper') as mock_trade_helper, \
		     patch('optrabot.trademanager.AsyncIOScheduler') as mock_scheduler, \
		     patch('optrabot.trademanager.logger') as mock_logger:
			
			# Setup session mock
			mock_session_instance = MagicMock()
			mock_session.return_value.__enter__.return_value = mock_session_instance
			
			# Track created transactions
			created_transactions = []
			def track_transaction(session, transaction):
				created_transactions.append(transaction)
			mock_crud.createTransaction.side_effect = track_transaction
			
			# Setup broker connector mock
			mock_broker = Mock()
			mock_broker.isConnected.return_value = True
			mock_broker.prepareOrder = AsyncMock()
			mock_broker.placeOrder = AsyncMock()
			mock_broker_factory.return_value.getBrokerConnectorByAccount.return_value = mock_broker
			
			# Setup scheduler mock
			mock_scheduler_instance = Mock()
			mock_scheduler.return_value = mock_scheduler_instance
			
			# Create TradeManager instance
			tm = TradeManager()
			tm._trades = [managed_trade]
			
			# Run _create_closing_order
			asyncio.run(tm._create_closing_order(managed_trade))
			
			# Verify NO transactions were created (deferred until FILLED)
			self.assertEqual(len(created_transactions), 0, 
				"No transactions should be created when creating closing order - only when FILLED")
			
			# Verify excluded_closing_legs contains the leg with no bid price
			self.assertEqual(len(managed_trade.excluded_closing_legs), 1,
				"Expected 1 leg in excluded_closing_legs")
			self.assertEqual(managed_trade.excluded_closing_legs[0].strike, 6580.0)
			
			# Verify log message about excluded leg
			info_calls = [str(call) for call in mock_logger.info.call_args_list]
			self.assertTrue(
				any('no bid price' in call 
				    for call in info_calls),
				f"Expected info log about leg with no bid price. Actual calls: {info_calls}"
			)

	def test_zero_price_transaction_created_when_method_called_directly(self):
		"""
		Test that _create_zero_price_closing_transactions creates the correct
		transactions when called directly (simulating what happens when FILLED).
		"""
		from datetime import date

		from optrabot.broker.order import Leg, OptionRight

		# Create mock managed trade
		mock_trade = Mock(spec=models.Trade)
		mock_trade.id = 381
		mock_trade.symbol = 'SPX'
		mock_trade.status = TradeStatus.OPEN
		
		mock_template = Mock(spec=Template)
		mock_template.name = "0DTEIncomeIC"
		mock_template.account = "U11192378"
		
		entry_order = Mock(spec=Order)
		entry_order.broker_order_id = '999001'
		entry_order.status = OrderStatus.FILLED
		entry_order.action = OrderAction.SELL_TO_OPEN
		entry_order.quantity = 1
		
		managed_trade = ManagedTrade(mock_trade, mock_template, entry_order, "U11192378")
		managed_trade.status = TradeStatus.OPEN
		managed_trade.transactions = []
		
		# Create excluded leg
		leg_no_bid = Leg(action=OrderAction.BUY, symbol='SPX', quantity=1)
		leg_no_bid.strike = 6580.0
		leg_no_bid.right = OptionRight.PUT
		leg_no_bid.bidPrice = 0
		leg_no_bid.expiration = date.today()
		
		excluded_legs = [leg_no_bid]
		
		with patch('optrabot.trademanager.Session') as mock_session, \
		     patch('optrabot.trademanager.get_db_engine') as mock_engine, \
		     patch('optrabot.trademanager.crud') as mock_crud, \
		     patch('optrabot.trademanager.BrokerFactory') as mock_broker_factory, \
		     patch('optrabot.trademanager.TradeHelper') as mock_trade_helper, \
		     patch('optrabot.trademanager.AsyncIOScheduler') as mock_scheduler, \
		     patch('optrabot.trademanager.logger') as mock_logger:
			
			mock_session_instance = MagicMock()
			mock_session.return_value.__enter__.return_value = mock_session_instance
			
			mock_crud.getMaxTransactionId.return_value = 8
			mock_db_trade = Mock(spec=models.Trade)
			mock_db_trade.id = 381
			mock_crud.getTrade.return_value = mock_db_trade
			
			created_transactions = []
			def track_transaction(session, transaction):
				created_transactions.append(transaction)
			mock_crud.createTransaction.side_effect = track_transaction
			
			mock_broker = Mock()
			mock_broker.isConnected.return_value = True
			mock_broker_factory.return_value.getBrokerConnectorByAccount.return_value = mock_broker
			
			mock_scheduler_instance = Mock()
			mock_scheduler.return_value = mock_scheduler_instance
			
			tm = TradeManager()
			tm._trades = [managed_trade]
			
			# Call _create_zero_price_closing_transactions directly
			asyncio.run(tm._create_zero_price_closing_transactions(managed_trade, excluded_legs))
			
			# Verify transaction was created
			self.assertEqual(len(created_transactions), 1, 
				"Expected exactly 1 transaction for the excluded leg")
			
			created_tx = created_transactions[0]
			
			# Verify transaction details
			self.assertEqual(created_tx.tradeid, 381)
			self.assertEqual(created_tx.id, 9)  # max_tx_id + 1
			self.assertEqual(created_tx.type, OrderAction.SELL)  # BUY position -> SELL to close
			self.assertEqual(created_tx.sectype, 'P')  # PUT
			self.assertEqual(created_tx.strike, 6580.0)
			self.assertEqual(created_tx.price, 0.0)  # Zero price
			self.assertEqual(created_tx.contracts, 1)
			self.assertIn('no bid price', created_tx.notes)
			
			# Verify TradeHelper.updateTrade was called to recalculate PNL
			mock_trade_helper.updateTrade.assert_called_once()
			
			# Verify log message about zero-price transaction
			info_calls = [str(call) for call in mock_logger.info.call_args_list]
			self.assertTrue(
				any('$0 closing transaction' in call and '6580' in call 
				    for call in info_calls),
				"Expected info log about $0 closing transaction for strike 6580"
			)

	def test_no_excluded_legs_when_all_legs_have_bid(self):
		"""
		Test that no legs are excluded when all legs have bid prices.
		"""
		from datetime import date

		from optrabot.broker.order import Leg, OptionRight

		# Create mock managed trade
		mock_trade = Mock(spec=models.Trade)
		mock_trade.id = 382
		mock_trade.symbol = 'SPX'
		
		mock_template = Mock(spec=Template)
		mock_template.name = "0DTEIncomeIC"
		mock_template.account = "U11192378"
		
		entry_order = Mock(spec=Order)
		entry_order.broker_order_id = '999002'
		entry_order.status = OrderStatus.FILLED
		entry_order.action = OrderAction.SELL_TO_OPEN
		entry_order.quantity = 1
		
		managed_trade = ManagedTrade(mock_trade, mock_template, entry_order, "U11192378")
		managed_trade.status = TradeStatus.OPEN
		managed_trade.transactions = []
		managed_trade.current_price = -0.50
		
		# Both legs have bid prices
		leg1 = Leg(action=OrderAction.BUY, symbol='SPX', quantity=1)
		leg1.strike = 6595.0
		leg1.right = OptionRight.PUT
		leg1.bidPrice = 0.03
		leg1.expiration = date.today()
		
		leg2 = Leg(action=OrderAction.BUY, symbol='SPX', quantity=1)
		leg2.strike = 6580.0
		leg2.right = OptionRight.PUT
		leg2.bidPrice = 0.05  # Has bid price
		leg2.expiration = date.today()
		
		managed_trade.current_legs = [leg1, leg2]
		
		with patch('optrabot.trademanager.Session') as mock_session, \
		     patch('optrabot.trademanager.get_db_engine') as mock_engine, \
		     patch('optrabot.trademanager.crud') as mock_crud, \
		     patch('optrabot.trademanager.BrokerFactory') as mock_broker_factory, \
		     patch('optrabot.trademanager.TradeHelper') as mock_trade_helper, \
		     patch('optrabot.trademanager.AsyncIOScheduler') as mock_scheduler, \
		     patch('optrabot.trademanager.logger') as mock_logger:
			
			mock_session_instance = MagicMock()
			mock_session.return_value.__enter__.return_value = mock_session_instance
			
			created_transactions = []
			mock_crud.createTransaction.side_effect = lambda s, t: created_transactions.append(t)
			
			mock_broker = Mock()
			mock_broker.isConnected.return_value = True
			mock_broker.prepareOrder = AsyncMock()
			mock_broker.placeOrder = AsyncMock()
			mock_broker_factory.return_value.getBrokerConnectorByAccount.return_value = mock_broker
			
			mock_scheduler_instance = Mock()
			mock_scheduler.return_value = mock_scheduler_instance
			
			tm = TradeManager()
			tm._trades = [managed_trade]
			
			asyncio.run(tm._create_closing_order(managed_trade))
			
			# Verify NO transactions were created
			self.assertEqual(len(created_transactions), 0,
				"No $0 transactions should be created when all legs have bid prices")
			
			# Verify no excluded legs
			self.assertEqual(len(managed_trade.excluded_closing_legs), 0,
				"No legs should be excluded when all have bid prices")


if __name__ == '__main__':
	unittest.main()
