import os
import sys
import unittest

sys.path.append(os.path.join(os.path.dirname(__file__), '..'))

from optrabot.marketdatatype import MarketDataType


class MarketDataTypeTests(unittest.TestCase):
	def setUp(self):
		self._cut = MarketDataType(MarketDataType.Live)
	
	def test_by_string(self) -> None:
		self._cut.byString('live')
		self.assertEqual(self._cut.Value, MarketDataType.Live, 'Expected Live Market Data Type')
		self._cut.byString('LiVe')
		self.assertEqual(self._cut.Value, MarketDataType.Live, 'Expected Live Market Data Type')
		self._cut.byString('delayed')
		self.assertEqual(self._cut.Value, MarketDataType.Delayed, 'Expected Delayed Market Data Type')
		self._cut.byString('DeLayeD')
		self.assertEqual(self._cut.Value, MarketDataType.Delayed, 'Expected Delayed Market Data Type')
		with self.assertRaises(ValueError):
			self._cut.byString('test')
		self.assertEqual(self._cut.Value, MarketDataType.Undefined)
	
	def test_to_string(self) -> None:
		self.assertAlmostEqual(self._cut.toString(), 'Live', 'Expected Market Data Type Live')
		self._cut.byValue(MarketDataType.Delayed)
		self.assertAlmostEqual(self._cut.toString(), 'Delayed', 'Expected Market Data Type Delayed')
		with self.assertRaises(ValueError):
			self._cut.byValue(99)
		self.assertEqual(self._cut.Value, MarketDataType.Undefined, 'Expected Market Data Type Undefined')
	
	def test__invalid_value(self) -> None:
		with self.assertRaises(ValueError):
			self._cut._invalidValue(99)
		self.assertEqual(self._cut.Value, MarketDataType.Undefined, 'Expected Market Data Type Undefined')