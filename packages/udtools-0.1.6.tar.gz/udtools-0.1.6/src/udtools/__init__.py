"""
udtools.

Python tools for Universal Dependencies.
"""

__version__ = "0.1.6"
__author__ = 'Daniel Zeman'
__credits__ = 'Universal Dependencies community'

from .validate import Validator

