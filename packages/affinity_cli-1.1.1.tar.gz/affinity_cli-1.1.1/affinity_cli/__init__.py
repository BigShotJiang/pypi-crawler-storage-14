"""Affinity CLI package metadata."""

__version__ = "1.1.0"
__author__ = "ind4skylivey"
__license__ = "MIT"
