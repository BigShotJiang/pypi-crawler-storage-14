__version__ = "0.1.2"

from MeowCore.main import MeowCore

__all__ = [
    "MeowCore"
]
