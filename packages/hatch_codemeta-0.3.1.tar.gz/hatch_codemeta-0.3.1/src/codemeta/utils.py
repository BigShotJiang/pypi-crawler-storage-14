from typing import Any
from pathlib import Path
from json import load
from csv import DictReader as csv_reader

from .exception import (
    NoDynamicField,
    TypeDynamicField,
    EmptyDynamicField,
    UnallowedDynamicField,
    FielddNotFound,
    BadMappingFile,
)
from .transliterator_factory import TransliteratorFactory


def get_fields_to_update(metadata: dict[str, Any]) -> list[str]:
    """
    Get dynamic fields from the metadata dict (returned by hatch)
    """
    field_allowlist = [
        "name",
        "version",
        "description",
        "readme",
        "requires-python",
        "license",
        "keywords",
        "classifiers",
        "urls",
        "dependencies",
        "optional-dependencies",
        "scripts",
        "gui-scripts",
        "entry-points",
    ]

    if "dynamic" not in metadata.keys():
        raise NoDynamicField(
            "no dynamic field defined in pyproject, see 'Getting Started' section in the documentation"
        )

    dynamic_fields = metadata["dynamic"]

    if not isinstance(dynamic_fields, list):
        raise TypeDynamicField(
            "dynamic fields is not a list but a {}".format(type(dynamic_fields))
        )

    if len(dynamic_fields) == 0:
        raise EmptyDynamicField("empty dynamic field")

    for dynamic_field in dynamic_fields:
        if not isinstance(dynamic_field, str):
            raise TypeDynamicField(
                "dynamic field {} is not a string but a {}".format(
                    dynamic_field,
                    type(dynamic_field),
                )
            )
        if dynamic_field not in field_allowlist:
            raise UnallowedDynamicField(
                "field {} is not allowed, only metadata can be dynamic, here is the list of allowed field: {}".format(
                    dynamic_field,
                    field_allowlist,
                )
            )

    return dynamic_fields


def get_index(haystack: list[str], needle: str) -> int:
    for i in range(len(haystack)):
        if haystack[i] == needle:
            return i
    raise FielddNotFound("{} field not found in the given list".format(needle))


def get_codemeta_field(dynamic_fields: list[str], mapping: Path) -> dict[str, Any]:
    """
    Fetch `codemeta.json` fields to get the only corresponding field
    from asked field
    """
    if len(dynamic_fields) == 0:
        raise EmptyDynamicField("no dynamic field given")

    codemeta: dict[str, Any]
    with open(Path("codemeta.json")) as file:
        codemeta = load(file)

    if not mapping.is_file():
        raise FileNotFoundError("mapping.csv not found in {}".format(mapping))

    with open(mapping) as file:
        reader = csv_reader(file, delimiter="	")

        fieldnames = reader.fieldnames
        if fieldnames is None:
            raise BadMappingFile("impossible to parse the file {}".format(mapping))

        if "codemeta" not in fieldnames:
            raise BadMappingFile(
                "no 'codemeta' column in the mapping file {}".format(mapping)
            )
        if "pyproject" not in fieldnames:
            raise BadMappingFile(
                "no 'pyproject' column in the mapping file {}".format(mapping)
            )

        codemeta_fields: list[str] = []
        codemeta_pyproject: list[str] = []

        for row in reader:
            codemeta_fields.append(row["codemeta"])
            codemeta_pyproject.append(row["pyproject"])

    data: dict[str, Any] = dict()
    for dynamic_field in dynamic_fields:
        if dynamic_field not in codemeta_pyproject:
            raise FielddNotFound(
                "{} field was not found in {}: ".format(dynamic_field, mapping)
            )
        index = get_index(codemeta_pyproject, dynamic_field)
        try:
            datum = codemeta[codemeta_fields[index]]
        except IndexError:
            raise BadMappingFile("'mapping.csv' is not valid, some cell are missing")
        except KeyError:
            raise FielddNotFound(
                "{} not found in 'codemeta.json'".format(codemeta_fields[index])
            )
        data[dynamic_field] = datum

    return data


def transliterate_fields(codemeta: dict[str, Any], mapping: Path) -> dict[str, Any]:
    """
    Transliterate codemeta fields to pyproject fields using method fetched
    from a given mapping file
    """
    field_allowlist = [
        "license",
        "name",
        "description",
        "readme",
        "softwareVersion",
        "author",
    ]
    if not mapping.is_file():
        raise FileNotFoundError("mapping.csv not found in {}".format(mapping))

    with open(mapping) as file:
        reader = csv_reader(file, delimiter="	")

        fieldnames = reader.fieldnames
        if fieldnames is None:
            raise BadMappingFile("impossible to parse the file {}".format(mapping))

        if "codemeta" not in fieldnames:
            raise BadMappingFile(
                "no 'codemeta' column in the mapping file {}".format(mapping)
            )
        if "pyproject" not in fieldnames:
            raise BadMappingFile(
                "no 'pyproject' column in the mapping file {}".format(mapping)
            )
        if "transliteration method" not in fieldnames:
            raise BadMappingFile(
                "no 'transliteration method' column in the mapping file {}".format(
                    mapping
                )
            )

        data: dict[str, list[str]] = dict()
        for key in ["codemeta", "pyproject", "transliteration method"]:
            data[key] = list()
        for row in reader:
            for key in ["codemeta", "pyproject", "transliteration method"]:
                try:
                    data[key].append(row[key])
                except KeyError:
                    raise BadMappingFile("{} column has empty cell")

    results: dict[str, Any] = dict()
    for key, value in codemeta.items():
        if key in field_allowlist:
            try:
                index = get_index(data["codemeta"], key)
            except FielddNotFound:
                continue
            if data["transliteration method"][index] == "":
                raise BadMappingFile("some row are missing in {}".format(mapping))
            new_key = data["pyproject"][index]
            transliterator = TransliteratorFactory.build(
                data["transliteration method"][index]
            )
            results[new_key] = transliterator.transliterate(value)
    return results


def update_fields(values: dict[str, Any], pyproject: dict[str, Any]):
    """
    Update pyproject dictionary with new value from the values dictionary
    """
    for key, value in values.items():
        pyproject[key] = value
