from typing import Any
from pathlib import Path
from hatchling.metadata.plugin.interface import MetadataHookInterface

from .utils import (
    get_fields_to_update,
    get_codemeta_field,
    update_fields,
    transliterate_fields,
)


class CodeMetaHook(MetadataHookInterface):
    """
    Hatchling plugin to import metadata to pyproject.toml from CodeMeta
    metadata stored in a codemetadata.json
    """

    PLUGIN_NAME = "codemeta"

    def update(self, metadata: dict[str, Any]) -> None:
        """
        Update the project table's metadata.

        Main loop
        """
        mapping_file = Path("data/mapping.csv")

        active_fields = get_fields_to_update(metadata)

        codemetadata = get_codemeta_field(active_fields, mapping_file)

        convert = transliterate_fields(codemetadata, mapping_file)

        update_fields(metadata, convert)
