from hatchling.plugin import hookimpl

from .plugin import CodeMetaHook


@hookimpl
def hatch_register_metadata_hook():
    return CodeMetaHook
