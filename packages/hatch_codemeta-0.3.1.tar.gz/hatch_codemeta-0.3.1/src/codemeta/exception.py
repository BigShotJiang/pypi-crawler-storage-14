class NoDynamicField(RuntimeError):
    pass


class TypeDynamicField(RuntimeError):
    pass


class EmptyDynamicField(RuntimeError):
    pass


class UnallowedDynamicField(RuntimeError):
    pass


class FielddNotFound(RuntimeError):
    pass


class BadMappingFile(RuntimeError):
    pass


class InvalidCodeMetaFile(RuntimeError):
    pass
