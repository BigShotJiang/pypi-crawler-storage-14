from abc import ABC, abstractmethod
from typing import Any

from .exception import InvalidCodeMetaFile


class Transliterator(ABC):
    """
    Interface implemented by every transliterator
    """

    @abstractmethod
    def transliterate(self, value: Any) -> Any:
        pass


class DirectTransliterator(Transliterator):
    """
    Don't change the value
    """

    def transliterate(self, value: Any) -> Any:
        return value


class AuthorTransliterator(Transliterator):
    """
    Convert a codemetadata author (Person | Organization) to a pyproject
    author (name and/or email)

    givenName is the necessary property of a Person, and is put as the name in
    the pyproject table. The email is fetched from the email property directly
    if it is defined

    The Organization term is not defined in the CodeMeta reference. For now, We
    consider that it contains at least a givenName and a email too.
    """

    def transliterate(self, value: Any) -> Any:
        authors: list[dict[str, str]] = []
        if not isinstance(value, list):
            raise InvalidCodeMetaFile(
                "author is not well definde in your codemetadata.json files. "
                "It should be a list of Person or Organization objects, not a {}"
                "See https://codemeta.github.io/terms/ for more information"
            )
        for item in value:
            author: dict[str, str] = dict()
            if not isinstance(item, dict):
                raise InvalidCodeMetaFile(
                    (
                        "author is not well defined in your codemetadata.json file. "
                        "It should be a Person or an Organization object, not a {}. "
                        "See https://codemeta.github.io/terms/ for more information"
                    ).format(type(item))
                )
            if "givenName" not in item.keys():
                raise InvalidCodeMetaFile(
                    "no givenName defined in your codemetadata.json file. givenName "
                    "is a mandatory property for a Person or Organization"
                )
            givenName = item["givenName"]

            if not isinstance(givenName, str):
                raise InvalidCodeMetaFile(
                    "givenName is {}. givenName must be a string".format(
                        type(givenName)
                    )
                )

            author["name"] = givenName

            if "email" in item.keys():
                email = item["email"]
                if not isinstance(email, str):
                    raise InvalidCodeMetaFile(
                        "email is {}. email property must be a string".format(
                            type(email)
                        )
                    )
                author["email"]
            authors.append(author)

        return authors


class TransliteratorFactory:
    """
    Factory to
    """

    @staticmethod
    def build(name: str) -> Transliterator:
        if name == "direct":
            return DirectTransliterator()
        elif name == "author":
            return AuthorTransliterator()
        else:
            raise ValueError("Unknown transliteration method {}".format(name))
