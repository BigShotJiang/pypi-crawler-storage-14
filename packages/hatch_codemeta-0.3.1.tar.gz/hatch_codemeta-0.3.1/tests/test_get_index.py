# needed for get_codemeta_field and transliterate_fields

from pytest import raises

from codemeta.exception import FielddNotFound
from codemeta.utils import get_index


def test_get_index():
    assert get_index(["a", "b"], "a") == 0
    assert get_index(["a", "b"], "b") == 1
    with raises(FielddNotFound):
        get_index(["a", "b"], "c")
    assert get_index(["a", "a"], "a") == 0
