from pathlib import Path
from shutil import copy2
from types import TracebackType
from contextlib import AbstractContextManager


def generate_name(number: int) -> str:
    return "codemeta.json.{}".format(".".join(["backup"] * number))


class CodemetaManager(AbstractContextManager):
    def __init__(self, temp_file: Path) -> None:
        self.temp_file = temp_file

    def __enter__(self):
        self.backup_number = 0

        if Path("codemeta.json").is_file():
            self.backup_number += 1
            while Path(generate_name(self.backup_number)).is_file():
                self.backup_number += 1
            Path("codemeta.json").rename(generate_name(self.backup_number))

        copy2(self.temp_file, Path("codemeta.json"))

    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        exc_value: BaseException | None,
        traceback: TracebackType | None,
    ):
        Path("codemeta.json").unlink()

        if self.backup_number != 0:
            Path(generate_name(self.backup_number)).rename("codemeta.json")
