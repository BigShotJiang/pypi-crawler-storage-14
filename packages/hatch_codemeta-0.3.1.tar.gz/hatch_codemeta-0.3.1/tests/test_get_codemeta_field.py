from pathlib import Path
from pytest import raises
from itertools import product
from json import JSONDecodeError

from codemeta.exception import (
    EmptyDynamicField,
    FielddNotFound,
    BadMappingFile,
)
from codemeta.utils import get_codemeta_field
from .codemeta_manager import CodemetaManager


def test_get_codemeta_field_load_codemeta():
    allow_list_fields = ["version", "description", "authors"]
    good_fields = list(list(fields) for fields in product(allow_list_fields))
    with CodemetaManager(Path("data/test/codemeta.json")):
        with raises(FileNotFoundError):
            get_codemeta_field(["version"], Path("/not/a/good/path"))
        with raises(BadMappingFile):
            get_codemeta_field(["version"], Path("data/test/mapping_bad_0.csv"))

        with raises(FielddNotFound):
            get_codemeta_field(["version"], Path("data/test/mapping_bad_1.csv"))
        with raises(FielddNotFound):
            get_codemeta_field(["non existing field"], Path("data/mapping.csv"))
        with raises(EmptyDynamicField):
            get_codemeta_field([], Path("data/mapping.csv"))
        for field in good_fields:
            get_codemeta_field(field, Path("data/mapping.csv"))

    with raises(IOError):
        get_codemeta_field(["version"], Path("data/test/mapping.csv"))

    with CodemetaManager(Path("data/test/codemeta_empty.json")):
        with raises(JSONDecodeError):
            get_codemeta_field(["version"], Path("data/mapping.csv"))
    with CodemetaManager(Path("data/test/codemeta_bad_0.json")):
        with raises(FielddNotFound):
            get_codemeta_field(["version"], Path("data/mapping.csv"))
    with CodemetaManager(Path("data/test/codemeta_bad_1.json")):
        with raises(FielddNotFound):
            get_codemeta_field(["version"], Path("data/mapping.csv"))
    with CodemetaManager(Path("data/test/codemeta_only_version.json")):
        get_codemeta_field(["version"], Path("data/mapping.csv"))
