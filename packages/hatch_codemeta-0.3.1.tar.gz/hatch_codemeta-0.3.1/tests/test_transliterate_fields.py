from pathlib import Path
from json import load
from pytest import raises

from codemeta.exception import BadMappingFile, InvalidCodeMetaFile
from codemeta.utils import transliterate_fields


def test_transliterate_fields():
    transliterate_fields(dict(), Path("data/mapping.csv"))
    with open("data/test/codemeta_bad_0.json") as file:
        codemeta = load(file)  # empty
        transliterate_fields(codemeta, Path("data/mapping.csv"))
    with open("data/test/codemeta_bad_1.json") as file:
        codemeta = load(file)
        transliterate_fields(codemeta, Path("data/mapping.csv"))
    with open("data/test/codemeta_bad_author_0.json") as file:
        codemeta = load(file)
        with raises(InvalidCodeMetaFile):
            transliterate_fields(codemeta, Path("data/mapping.csv"))
    with open("data/test/codemeta_bad_author_1.json") as file:
        codemeta = load(file)
        with raises(InvalidCodeMetaFile):
            transliterate_fields(codemeta, Path("data/mapping.csv"))
    with open("data/test/codemeta.json") as file:
        codemeta = load(file)
        with raises(FileNotFoundError):
            transliterate_fields(codemeta, Path("not/an/existing/path"))
        with raises(BadMappingFile):
            transliterate_fields(codemeta, Path("data/test/mapping_bad_0.csv"))
        with raises(BadMappingFile):
            transliterate_fields(codemeta, Path("data/test/mapping_bad_1.csv"))
        transliterate_fields(codemeta, Path("data/mapping.csv"))
