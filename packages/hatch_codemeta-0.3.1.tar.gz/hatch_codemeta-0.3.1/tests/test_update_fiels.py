from codemeta.utils import update_fields


def test_update_fields():
    table = {"test": "ok"}
    update_fields({"another": "one"}, table)
    assert table["another"] == "one"
    update_fields({"test": "not ok"}, table)
    assert table["test"] == "not ok"
