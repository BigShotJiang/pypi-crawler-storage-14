from pytest import fixture, raises
from string import ascii_letters
from random import choice
from itertools import product

from codemeta.exception import (
    EmptyDynamicField,
    NoDynamicField,
    TypeDynamicField,
    UnallowedDynamicField,
)
from codemeta.utils import get_fields_to_update


def test_get_fields_to_update_empty_dict():
    with raises(NoDynamicField):
        get_fields_to_update(dict())


def test_get_fields_to_update_no_dynamic():
    with raises(NoDynamicField):
        get_fields_to_update(
            {
                "name": "test",
                "version": "0.0.1",
                "description": "description",
                "dependencies": [],
            }
        )


def test_get_fields_to_update_type_dynamic():
    with raises(TypeDynamicField):
        get_fields_to_update(
            {
                "name": "test",
                "version": "0.0.1",
                "description": "description",
                "dependencies": [],
                "dynamic": "wrong",
            }
        )


def test_get_fields_to_update_empty_dynamic():
    with raises(EmptyDynamicField):
        get_fields_to_update(
            {
                "name": "test",
                "version": "0.0.1",
                "description": "description",
                "dependencies": [],
                "dynamic": [],
            }
        )


def generate_bad_field(length: int = 7) -> str:
    return "".join(choice(ascii_letters) for _ in range(length))


def generate_fields(bad: int = 0) -> list[list[str]]:
    possible_fields = [
        "name",
        "version",
        "description",
        "readme",
        "requires-python",
        "license",
        "keywords",
        "classifiers",
        "urls",
        "dependencies",
        "optional-dependencies",
        "scripts",
        "gui-scripts",
        "entry-points",
    ]
    for _ in range(bad):
        possible_fields.append(generate_bad_field())
    return list(list(fields) for fields in product(possible_fields))


def test_get_fields_to_update_dynamic_fields():
    for fields in generate_fields(0):
        assert (
            get_fields_to_update(
                {
                    "name": "test",
                    "version": "0.0.1",
                    "description": "description",
                    "dependencies": [],
                    "dynamic": fields,
                }
            )
            == fields
        )
    with raises(UnallowedDynamicField):
        for fields in generate_fields(1):
            assert (
                get_fields_to_update(
                    {
                        "name": "test",
                        "version": "0.0.1",
                        "description": "description",
                        "dependencies": [],
                        "dynamic": fields,
                    }
                )
                == fields
            )
