# Hatch CodeMeta

[CodeMeta](https://codemeta.github.io) schema is a standard metadata
syntax to describe "Scientific software and code". This syntax depends
of a `codemeta.json` file in the root folder of your project, which
act as a single source of trust.

[Hatch](https://hatch.pypa.io) is a python project manager which
is also linked to a build system named Hatchling. This build system
also manage the `pyproject.toml` file, that contains metadata
information about the given project, authors, description and such.

These information are also specified in `codemeta.json` file. This
project allows to specify all such metadata only in `codemeta.json`
and fill `pyproject.toml` information dynamically from this file.

## Getting Started

Include it as a plugin to your `pyproject.toml`

```toml
[build-system]
requires = ["hatchling", "hatch-codemeta"]
build-backend = "hatchling.build"
```

Make the fields you want to import as dynamic

```toml
[project]
...
dynamic = ["version", "description", "authors"]
```

And then, make sure Hatchling uses it

```toml
[tool.hatch.metadata.hooks.codemeta]
```

## Documentation

The documentation is available as [markdown files](doc/index.md).
