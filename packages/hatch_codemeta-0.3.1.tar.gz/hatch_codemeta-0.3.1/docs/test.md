# Tests

This software is tested with unit, integration and end to end tests.

## Unit test

### hatchling hook

On data returned by hatchling:

[ ] send bad type (not dict)
[ ] send bad types (keys)
[ ] send empty dictionary
[ ] test with different valid `pyproject.toml`

### Reading configuration

On `pyproject.toml` data:

[ ] no `pyproject.toml`
[x] empty `dynamic` field
[x] no `dynamic` field
[x] test with every combination of possible active field in `pyproject.toml`

### Fetching codemeta

On `codemeta.json` data:

[x] no `codemeta.json`
[x] malformed `codemeta.json`
[x] empty `codemeta.json`
[x] full `codemeta.json`
[x] only asked field defined

On `mapping.csv` data:

[x] no `mapping.csv`
[x] malformed `mapping.csv`
[x] unknown field in `mapping.csv`
[x] full `mapping.csv`
[x] only asked field defined

### Transliterating

Base function:

[x] give empty dictionary

For the Transliterator factory:

[x] non existent method name
[x] existent method name
[ ] direct call to the base interface/class

For each transliterator:

[x] give incorrect type
[x] give incorrect value
[x] give correct value and compare result to expected one

### Updating metadata

For result:

[x] compare updated dictionary to expected dictionary
[x] check it's the reference dictionary that is changed and not a copy

## Integration test

## End to end test

Check entire setup with correct configuration
