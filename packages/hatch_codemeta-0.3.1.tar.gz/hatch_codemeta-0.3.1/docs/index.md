# Documentation

This is a hatchling plugin, in the shape of a [Metadata hook plugin](https://hatch.pypa.io/latest/plugins/metadata-hook/reference/#metadata-hook-plugins)

The integrated fields of the pyproject metadata are:

- version
- description
- authors

The mapping between the pyproject and the codemeta fields is in
[mapping.csv file](../data/mapping.csv). This file also indicate
each transliteration method used to convert a given codemeta field
to a given pyproject one.

The goal of this software is to hydrate hatch metadata from a
`codemeta.json` file.

## Process

This task can be decomposed in five sub-tasks:

1. "catch" hatchling hook
2. reading configuration (get `project.dynamic` field in `pyproject.toml`)
3. fetching `codemeta.json` fields
4. transliterating fields
5. update the field and exit

### Hatchling hook

`hook.py` file is the entry point for hatchling hook, this file
contains a `SpecialMetadataHook` class from the `hatchling` module.

The main loop is in the `update` method of this class.

### Reading configuration

The first thing done by the loop is to check actual `pyproject.toml`
configuration, by calling `get_fields_to_update` function defined it is
own python file. This function returns the dynamic field or raise a
`NoDynamicField` exception if the `dynamic` field is empty or non existent.
It takes the dictionary given by hatchling.

### Fetching codemeta

Then, to fetch needed `codemeta.json` field, the
`get_codemeta_field` function, which take the fields returned by
`get_fields_to_update` and the path of `mapping.csv`, read
`codemeta.json` and use `mapping.csv` to return the correct field.
If any field do not exist, raise a `FielddNotFound` exception. It
returns a dictionary linking codemeta field to their data.

### Transliterating fields

Transliterating fields data is the next step. This is done by the
`transliterate_fields` function, which convert all the codemeta
fields to pyproject field. It returns a dictionary linking pyproject
field to their data, and take the dictionary of fields from codemeta
and the path to `mapping.csv`. It use transliterators to do this job.

#### Transliterator

Transliterator is an interface that every transliterator will inherit
from. It consists of a single function to implement : `transliterate`.
It takes one value and return this value transliterated.

Each transliterator is named as a possible method field in `mapping.csv`.
A factory is used to create an instance of the class corresponding to
the method name.

### Updating metadata

Finally, the `update_fields` function is used to update the dictionary
given by hatchling. It takes the dictionary returned by the
`transliterate_fields` function and the dictionary given by hatchling.
It returns nothing and add all the fields from the transliterated
dictionary to the dictionary given by hatchling, updating it.

## Code

All these function are defined in [utils.py](src/hatch-codemeta/utils.py)

## Tests

Test documentation is available [as a file](doc/test.md) in the
[same folder](doc/).
