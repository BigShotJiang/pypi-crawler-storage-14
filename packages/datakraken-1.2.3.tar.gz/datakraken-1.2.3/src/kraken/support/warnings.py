class DuplicateColumnWarning(Warning):
    pass
