def hello() -> str:
    return "Hello from dart-api-client!"
