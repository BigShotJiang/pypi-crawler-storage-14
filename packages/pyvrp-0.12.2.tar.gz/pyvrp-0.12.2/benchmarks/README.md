# Benchmarks

This directory contains microbenchmarks that are executed by default during CI runs.
These ensure PyVRP does not suffer unexpected performance regressions.
