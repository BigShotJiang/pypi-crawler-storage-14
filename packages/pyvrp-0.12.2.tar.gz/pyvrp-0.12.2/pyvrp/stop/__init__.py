from .FirstFeasible import FirstFeasible as FirstFeasible
from .MaxIterations import MaxIterations as MaxIterations
from .MaxRuntime import MaxRuntime as MaxRuntime
from .MultipleCriteria import MultipleCriteria as MultipleCriteria
from .NoImprovement import NoImprovement as NoImprovement
from .StoppingCriterion import StoppingCriterion as StoppingCriterion
