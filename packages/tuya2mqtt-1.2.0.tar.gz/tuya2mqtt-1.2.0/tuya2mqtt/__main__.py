from . import tuya2mqtt

if __name__ == "__main__":
    tuya2mqtt.main()
