from numpy import ndarray


class FileBackedArray(ndarray):
    pass
