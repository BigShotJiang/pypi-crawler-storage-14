from __future__ import print_function
import multiprocessing as mp
#import sys, os, wx, weakref
#sys.path = [os.path.dirname(os.path.dirname(__file__)),] + sys.path

if __name__ == '__main__':
    from ifigure.piscope import piscope
    piscope()
