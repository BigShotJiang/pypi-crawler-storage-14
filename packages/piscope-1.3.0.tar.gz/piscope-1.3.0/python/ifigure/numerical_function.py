from numpy import sin, cos, linspace
