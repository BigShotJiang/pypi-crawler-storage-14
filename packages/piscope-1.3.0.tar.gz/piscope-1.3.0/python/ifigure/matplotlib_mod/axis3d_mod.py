from mpl_toolkits.mplot3d.axis3d import XAxis as _XAxis
from mpl_toolkits.mplot3d.axis3d import YAxis as _YAxis
from mpl_toolkits.mplot3d.axis3d import ZAxis as _ZAxis


class XAxis(_XAxis):
    def set_ticks_position(self, position):
        pass
class YAxis(_YAxis):
    def set_ticks_position(self, position):
        pass
class ZAxis(_ZAxis):
    def set_ticks_position(self, position):
        pass
