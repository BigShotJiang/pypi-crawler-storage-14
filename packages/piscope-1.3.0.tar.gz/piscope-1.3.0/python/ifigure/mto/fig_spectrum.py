from ifigure.mto.fig_image import FigImage


class FigSpectum(FigImage):
    pass
