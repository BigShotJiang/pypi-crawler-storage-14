#
#    define default name space for PyScript
#

import numpy as np
from numpy import sin
from numpy import cos
from numpy import tan
from numpy import exp
from numpy import linspace
