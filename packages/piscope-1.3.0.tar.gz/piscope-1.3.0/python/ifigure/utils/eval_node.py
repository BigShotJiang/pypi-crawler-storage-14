from __future__ import print_function
# module to run script with __main__ condition

import numpy as np


def EvalNode(___instring___):
    print(___instring___)
    ___instring___
    return eval(___instring___)
