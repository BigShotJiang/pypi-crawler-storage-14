import sys
sys.path = [p for p in sys.path if p[0:15] != '/System/Library']
