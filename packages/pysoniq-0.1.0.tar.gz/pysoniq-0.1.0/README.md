# pysoniq

Minimal, pure-Python cross-platform audio playback library.

- **Pure Python** - No compiled extensions
- **Cross-platform** - Windows, macOS, Linux
- **Minimal dependencies** - Only numpy
- **Simple API** - Play, pause, stop, loop

## Installation
```bash
pip install pysoniq
```

## Use in context
```python
import pysoniq as ps
import numpy as np

# Play WAV file
ps.play('audio.wav')

# Play as numpy array
sr = 44100
t = np.linspace(0, 1.0, sr)
audio = 0.3 * np.sin(2 * np.pi * 440 * t)
ps.play(audio, samplerate=sr)

# Loop playback
ps.set_loop(True)
ps.play(audio, sr)

# Stop
ps.stop()
```

## Features

**Playback**
```python
ps.play(data, samplerate)  # Play audio
ps.stop()                   # Stop playback
ps.pause()                  # Pause
ps.resume()                 # Resume
```

**Looping**
```python
ps.set_loop(True)   # Enable loop
ps.is_looping()     # Check status
```

**Gain Control**
```python
ps.set_gain(0.5)           # 50% volume
ps.set_volume_db(-6.0)     # Set dB
audio = ps.adjust_gain_level(audio, 1.5)
```

**Audio I/O**
```python
audio, sr = ps.load('file.wav')
ps.save('output.wav', audio, sr)
```

## Platform Requirements

- **Windows**: Built-in (winsound)
- **macOS**: Built-in (afplay)
- **Linux**: ALSA (aplay) - usually pre-installed

## Limitations

- WAV format only (for now)
- Pause/resume uses time-based estimation
- Gain changes apply on next loop iteration

## License

MIT

## Author

laelume