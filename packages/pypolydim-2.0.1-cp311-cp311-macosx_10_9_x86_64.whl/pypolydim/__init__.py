import sys
import types

from .pypolydim import *
