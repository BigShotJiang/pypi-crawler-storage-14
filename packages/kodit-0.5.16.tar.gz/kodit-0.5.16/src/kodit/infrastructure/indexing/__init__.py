"""Infrastructure indexing module."""
