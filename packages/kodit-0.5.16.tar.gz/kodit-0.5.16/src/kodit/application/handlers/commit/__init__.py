"""Commit operation handlers."""
