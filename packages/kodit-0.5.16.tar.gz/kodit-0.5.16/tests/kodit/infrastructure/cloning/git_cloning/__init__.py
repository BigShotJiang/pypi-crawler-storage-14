"""Git cloning infrastructure tests."""
