"""Slicing tests."""
