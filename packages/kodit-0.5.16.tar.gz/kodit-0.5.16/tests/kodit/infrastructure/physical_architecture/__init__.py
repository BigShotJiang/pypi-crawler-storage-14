"""Physical architecture tests."""
