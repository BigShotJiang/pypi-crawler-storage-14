"""Detector tests."""
