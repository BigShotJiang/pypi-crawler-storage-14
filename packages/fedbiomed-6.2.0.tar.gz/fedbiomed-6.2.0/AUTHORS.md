# Fed-BioMed authors

This file lists all Fed-BioMed developers who wish to register themselves.
Authors are listed by alphabetical order. 
Each author can mention his/her name only or give more information in the following format:

- [Author Name](link to author site or author's email)

  A short bio and/or a short description of Fed-BioMed contributions (max 250 characters)


## Authors

- Paul Andrey
- Maya Assal
- Samy-Safwan Ayed
- Irene Balelli
- Nathan Bigaud
- Eleonore Birgy
- Yannick Bouillard
- Tristan Cabel
- Sergen Cansiz
- Lucie Chambon
- Gaurav D. Chaudary
- Francesco Cremonesi
- Erwan Demairy
- Ali Tolga Dincer
- Nejma El Kourdachi
- Yann Fraboni
- Thibaud Kloczko
- Lena Le Quintrec
- Nathan Lapel
- Côme Le Breton
- Jonathan Levy
- Marco Lorenzi
- Riham Nehmeh
- Ange Ouya
- Prapoojitha Santosha-Dasari
- Jose-Francisco Saray-Villamizar
- Andrea Senacheribbe
- Santiago-Smith Silva-Rincon
- Jean-Luc Szpyrka
- Riccardo Taiello
- Jhonatan Torres
- Marc Vesin
- Yaroslav Halchenko
- Carlos Zubiaga
