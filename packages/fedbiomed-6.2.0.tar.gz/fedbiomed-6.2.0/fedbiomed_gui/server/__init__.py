"""
GUI server module
"""
