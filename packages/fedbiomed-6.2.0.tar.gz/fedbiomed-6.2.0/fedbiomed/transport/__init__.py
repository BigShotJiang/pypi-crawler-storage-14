"""
Transport module to manage communication between researcher and
node components based on gRPC
"""
