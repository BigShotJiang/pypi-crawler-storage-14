# Changelog

All notable changes to this project will be documented in this file.

## [0.1.0] - 2024-12-01

### Added

- Initial release
- CLI tool `whatsease-mcp` to run MCP server from Whatsease OpenAPI spec
- Support for `include.json` configuration to filter exposed routes
- HTTP and stdio transport support
- Configurable host and port
