"""CLI entry point for whatsease-mcp."""

from __future__ import annotations

import click

from whatsease_mcp.server import create_mcp_server


@click.command()
@click.option(
    "--api-url",
    "-u",
    required=True,
    envvar="WHATSEASE_API_BASE_URL",
    help="Base URL of the Whatsease API (required). Can also be set via WHATSEASE_API_BASE_URL env var.",
)
@click.option(
    "--port",
    "-p",
    default=8001,
    type=int,
    help="Port to run the MCP server on (default: 8001)",
)
@click.option(
    "--host",
    "-h",
    default="0.0.0.0",
    help="Host to bind the MCP server to (default: 0.0.0.0)",
)
@click.option(
    "--include-config",
    "-c",
    default=None,
    type=click.Path(exists=False),
    help="Path to include.json config file (default: ./include.json)",
)
@click.option(
    "--transport",
    "-t",
    default="http",
    type=click.Choice(["http", "stdio"]),
    help="Transport type (default: http)",
)
def main(
    api_url: str,
    port: int,
    host: str,
    include_config: str | None,
    transport: str,
) -> None:
    """Run the Whatsease MCP server.

    Starts an MCP server that exposes Whatsease API endpoints as tools.

    Example:
        whatsease-mcp --api-url https://api.whatsease.com

        whatsease-mcp -u https://api.whatsease.com -p 8080 -h localhost
    """
    click.echo("Starting Whatsease MCP server...")
    click.echo(f"  API URL: {api_url}")
    click.echo(f"  Transport: {transport}")

    if transport == "http":
        click.echo(f"  Host: {host}")
        click.echo(f"  Port: {port}")

    if include_config:
        click.echo(f"  Config: {include_config}")

    mcp = create_mcp_server(
        api_base_url=api_url,
        include_config_path=include_config,
    )

    if transport == "http":
        mcp.run(transport="http", port=port, host=host)
    else:
        mcp.run(transport="stdio")


if __name__ == "__main__":
    main()
