"""MCP Server creation from OpenAPI spec."""

from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any

import httpx
from fastmcp import FastMCP
from fastmcp.server.openapi import MCPType, RouteMap

# Enable the new experimental parser for better compatibility
os.environ["FASTMCP_EXPERIMENTAL_ENABLE_NEW_OPENAPI_PARSER"] = "true"

# Map string to MCPType enum
MCP_TYPE_MAP = {
    "TOOL": MCPType.TOOL,
    "RESOURCE": MCPType.RESOURCE,
    "RESOURCE_TEMPLATE": MCPType.RESOURCE_TEMPLATE,
    "EXCLUDE": MCPType.EXCLUDE,
}


def load_include_config(config_path: str | None = None) -> list[dict[str, Any]]:
    """Load include.json configuration file.

    Args:
        config_path: Path to include.json. If None, looks in current directory.

    Returns:
        List of route configurations, or empty list if not found/empty.
    """
    if config_path is None:
        config_path = "include.json"

    path = Path(config_path)
    if not path.exists():
        return []

    try:
        with open(path, encoding="utf-8") as f:
            data = json.load(f)

        include_list = data.get("include", [])
        if not include_list:
            return []

        return include_list
    except (json.JSONDecodeError, KeyError):
        return []


def build_route_maps(include_config: list[dict[str, Any]]) -> list[RouteMap]:
    """Build RouteMap list from include configuration.

    Args:
        include_config: List of route configurations from include.json

    Returns:
        List of RouteMap objects
    """
    route_maps = []

    for config in include_config:
        mcp_type_str = config.get("mcp_type", "TOOL")
        mcp_type = MCP_TYPE_MAP.get(mcp_type_str, MCPType.TOOL)

        methods = config.get("methods")
        pattern = config.get("pattern", r".*")

        route_map = RouteMap(
            pattern=pattern,
            mcp_type=mcp_type,
            methods=methods if methods else None,
        )
        route_maps.append(route_map)

    # Always add exclude-all at the end
    route_maps.append(RouteMap(pattern=r".*", mcp_type=MCPType.EXCLUDE))

    return route_maps


def create_mcp_server(
    api_base_url: str,
    include_config_path: str | None = None,
) -> FastMCP:
    """Create an MCP server from OpenAPI spec.

    Args:
        api_base_url: Base URL of the API with OpenAPI spec
        include_config_path: Path to include.json config file

    Returns:
        FastMCP server instance
    """
    client = httpx.AsyncClient(base_url=api_base_url)
    openapi_spec = httpx.get(f"{api_base_url}/openapi.json").json()

    # Load include configuration
    include_config = load_include_config(include_config_path)

    # Build kwargs for from_openapi
    kwargs: dict[str, Any] = {
        "openapi_spec": openapi_spec,
        "client": client,
        "name": "Whatsease CRM API",
    }

    # Only add route_maps if include config is present and non-empty
    if include_config:
        kwargs["route_maps"] = build_route_maps(include_config)

    return FastMCP.from_openapi(**kwargs)
