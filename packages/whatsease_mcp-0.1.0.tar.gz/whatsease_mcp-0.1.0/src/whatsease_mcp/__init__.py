"""Whatsease MCP - CLI tool to run Whatsease MCP server from OpenAPI spec."""

__version__ = "0.1.0"
