# chromadb-mcp-ollama

Model Context Protocol server that mirrors the standard `chroma` MCP tools and adds first-class support for configuring Ollama embeddings (URL, model, timeout) so collections can be created with the Ollama embedding function.

## Running

```bash
uv run chromadb-mcp-ollama \
  --client-type persistent \
  --data-dir /path/to/chroma/data \
  --dotenv-path /path/to/.env \
  --ollama-url http://localhost:11434 \
  --ollama-model nomic-embed-text \
  --ollama-timeout 90
```

Key flags (all also respect environment variables):

- `--client-type` (`CHROMA_CLIENT_TYPE`): `http`, `cloud`, `persistent`, or `ephemeral`.
- `--data-dir` (`CHROMA_DATA_DIR`): path for persistent client data.
- `--host`/`--port` (`CHROMA_HOST`/`CHROMA_PORT`): Chroma server when using HTTP.
- `--tenant`/`--database`/`--api-key`: cloud auth parameters.
- `--dotenv-path` (`CHROMA_DOTENV_PATH`): optional env file to load before parsing flags.
- `--ollama-url` (`OLLAMA_URL`): base URL for Ollama when `embedding_function_name="ollama"`.
- `--ollama-model` (`OLLAMA_MODEL` or `OLLAMA_EMBED_MODEL`): Ollama embedding model name.
- `--ollama-timeout` (`OLLAMA_TIMEOUT`): Ollama request timeout in seconds.
- `--default-embedding-function-name` (`CHROMA_DEFAULT_EMBEDDING_FUNCTION_NAME`): embedding function to use when opening existing collections (set this to match the embedding used when the collection was created; e.g. `ollama`).

## MCP tools exposed

- `chroma_list_collections`
- `chroma_create_collection`
- `chroma_peek_collection`
- `chroma_get_collection_info`
- `chroma_get_collection_count`
- `chroma_modify_collection`
- `chroma_fork_collection`
- `chroma_delete_collection`
- `chroma_add_documents`
- `chroma_query_documents`
- `chroma_get_documents`
- `chroma_update_documents`
- `chroma_delete_documents`

The tool signatures match the stock `chroma` MCP server. When calling `chroma_create_collection`, set `embedding_function_name="ollama"` to use the Ollama embedding function with the configured URL/model.
