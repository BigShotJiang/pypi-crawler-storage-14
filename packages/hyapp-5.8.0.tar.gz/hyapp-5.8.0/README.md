Common utilities for a fastapi app.
