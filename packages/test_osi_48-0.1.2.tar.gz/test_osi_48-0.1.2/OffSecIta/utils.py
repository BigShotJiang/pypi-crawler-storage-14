from .corsi import corsi
 
def durata_totale():

	return sum(corso.length for corso in corsi)
