class Corso:

    def __init__(self, name, length, link):
        self.name = name
        self.length = length
        self.link = link 

    #def __str__(self): # Questo e un metodo per farlo funzionare  
    #   return f"{self.name} [{self.length} HOURS] ({self.link})"

    def __repr__(self):
        return f"{self.name} [{self.length} HOURS] ({self.link}) \n"
 
 
corsi = [
        Corso("Corso Hacking Etico", 60, "https://www.youtube.com/watch?v=L90xYiqqjBI&list=PLKZZXjqZrqQtKGgJuAYhzYczf1KIdswvO"),
        Corso("Corso Linux", 30, "https://www.youtube.com/watch?v=qcX89gkdlYs&list=PLKZZXjqZrqQvfAhgY7Nit5ynpK3kN_3tx"),
        Corso("Corso Linux personalizzazione", 15, "https://www.youtube.com/watch?v=zYgN2Ty16RA&list=PLKZZXjqZrqQslOV4EyEl40ZPxo7bpFHQE"),
        Corso("Corso di introduzione al Python Offensive", 15, "https://www.youtube.com/watch?v=Q6OCBq2nyzs&list=PLKZZXjqZrqQu7qZkgSsdU3lRpR7oISMXh")
        ]
 
#for corso in corsi:
#    print(corso) # Questo puo funzionare con il metodo __str__
 
# print(corsi)
 
def lista_corsi():
    for corso in corsi:
        print(corso)
