# Tesla AI MCP Client

[Tesla AI](https://www.xiaote.com/) 的官方 MCP 客户端。通过 Model Context Protocol 将您的 Tesla 车辆控制能力接入 Claude、Cursor 等 AI 工具。

## 安装

建议使用 `uv` 进行安装：

```bash
uv tool install tesla-ai-mcp
```

或者使用 pip：

```bash
pip install tesla-ai-mcp
```

## 配置

### 获取 API Key

1. 下载 **小特 App** 并绑定 Tesla 车辆。
2. 在 App 设置中获取 **API Key**。

### 配置 AI 工具

#### Claude Desktop

编辑配置文件（macOS: `~/Library/Application Support/Claude/claude_config.json`, Windows: `%APPDATA%\Claude\claude_config.json`）：

```json
{
  "mcpServers": {
    "tesla-ai": {
      "command": "uvx",
      "args": ["tesla-ai-mcp"],
      "env": {
        "API_KEY": "xte_YOUR_API_KEY_HERE"
      }
    }
  }
}
```

#### Cursor

在 Cursor 设置 -> MCP 中添加：

- 名称: `tesla-ai`
- 类型: `command`
- 命令: `uvx tesla-ai-mcp` (或 `tesla-ai-mcp` 如果已安装)
- 环境变量: `API_KEY=xte_...`

## License

MIT

