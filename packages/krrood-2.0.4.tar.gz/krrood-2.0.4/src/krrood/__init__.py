import importlib.metadata
import logging

__version__ = "2.0.4"


logger = logging.Logger("krrood")
logger.setLevel(logging.INFO)
