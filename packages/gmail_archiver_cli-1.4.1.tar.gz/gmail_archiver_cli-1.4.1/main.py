"""Entry point for Gmail Archiver CLI."""

from gmailarchiver.__main__ import app

if __name__ == "__main__":
    app()
