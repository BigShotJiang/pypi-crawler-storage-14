"""txt2tex - Convert whiteboard-style mathematical notation to LaTeX."""

__version__ = "0.1.0"
