# Hugging Face Spaces

## Installation

`pip install spaces`
