"""Version information for edge-api package."""

__version__ = "0.2.1"