"""Edge API Client module."""

from .edge_client import Edge

__all__ = ["Edge"]