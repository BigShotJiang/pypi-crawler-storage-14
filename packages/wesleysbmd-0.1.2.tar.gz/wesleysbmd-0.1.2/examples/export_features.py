#!/usr/bin/env -S uv run --quiet --script
# /// script
# requires-python = ">=3.10"
# dependencies = []
# ///

"""
BlockMD Feature Exporter - Export all feature blocks as tree view.

This script demonstrates using BMD query API to filter and display
blocks with type='feature' in a hierarchical tree format.

Usage:
    ./export_features.py
    uv run export_features.py
"""

import sys
from pathlib import Path

DIST_DIR = "examples/demo2.bmd"

# Add src to path for local development
src_path = Path(__file__).parent.parent / "src"
sys.path.insert(0, str(src_path))

from bmd.query import query


def main():
    """Export all feature blocks from demo.bmd as tree view."""
    
    # Get the demo file path
    demo_file = Path(__file__).parent / "demo.bmd"
    
    if not demo_file.exists():
        print(f"Error: {demo_file} not found!", file=sys.stderr)
        sys.exit(1)
    
    print("=" * 60)
    print("BlockMD Feature Exporter")
    print("=" * 60)
    print()
    print(f"Destination: {DIST_DIR}")
    print()
    
    # Query and filter features
    result = (query()
        .from_path(str(DIST_DIR))
        .where(source=lambda b: b.startswith('2025/'))
        .view('tree')
    )

    print(result)
    

if __name__ == "__main__":
    main()
