"""Factories module for dependency injection."""

from .service_factory import ServiceFactory

__all__ = ["ServiceFactory"]
