This directory contains dependencies for the meson build, as managed by
`meson's wrap tool <https://mesonbuild.com/Wrapdb-projects.html#meson-wrapdb-packages>`_.
