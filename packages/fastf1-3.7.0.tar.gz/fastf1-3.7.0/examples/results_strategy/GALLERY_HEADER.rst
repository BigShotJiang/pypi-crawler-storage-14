Strategy and Results Analysis
-----------------------------
