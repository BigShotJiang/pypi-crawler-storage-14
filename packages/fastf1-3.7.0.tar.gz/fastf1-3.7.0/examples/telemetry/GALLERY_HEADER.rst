Telemetry Analysis
------------------
