from onnx_diarization.clustering.vbx import VBxClustering

__all__ = [
    "VBxClustering",
]
