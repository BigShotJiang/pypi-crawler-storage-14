# AbuLang - Natural Language Programming

AbuLang is a natural-language programming language that makes coding intuitive and accessible. It translates human-readable syntax into Python, making programming easier for beginners and creative coders.

## Features

- **Natural Language Syntax**: Write code that reads like English
- **Python Integration**: All AbuLang commands work natively in Python IDLE
- **GUI Support**: Built-in GUI manager for creating interactive applications
- **3D Graphics**: Support for 3D scene creation and manipulation
- **File Operations**: Easy file reading, writing, and manipulation
- **Data Storage**: In-memory storage similar to browser localStorage
- **Text Processing**: Advanced text matching, encoding, and manipulation
- **Game Development**: Physics engine with gravity simulation
- **Web Support**: Browser-based IDE with Pyodide integration

## Installation

```bash
pip install AbuLang
```

## Quick Start

### Using AbuLang in Python IDLE

```python
from AbuLangModule import enable_abulang

enable_abulang()

show "Hello, World!"
name = ask "What is your name?"
show "Nice to meet you, " + name
```

### Using the AbuLang Interpreter

Create a file `script.abu`:

```abulang
show "Hello, World!"
name = ask "What is your name?"
show "Nice to meet you, " + name
```

Run it:

```bash
python -m AbuLangModule.interpreter script.abu
```

## Core Commands

### I/O Commands
- `show(...)` - Display output
- `ask(prompt)` - Get user input
- `multiple_choice_terminal(prompt, options)` - Show multiple choice menu

### Data Storage
- `Create DataStorage as varname` - Create isolated in-memory storage
  - Methods: `setItem(key, value)`, `getItem(key)`, `removeItem(key)`, `clear()`
  - Property: `length`

### Math Commands
- `plus(a, b)` - Add numbers
- `minus(a, b)` - Subtract numbers
- `multi(a, b)` - Multiply numbers
- `divid(a, b)` - Divide numbers
- `expon(a, b)` - Power (a^b)
- `modul(a, b)` - Modulo (a%b)
- `absof(x)` - Absolute value
- `sumup(list)` - Sum of list
- `avera(list)` - Average of list

### String Commands
- `strip(text)` - Remove spaces
- `lower(text)` - Lowercase
- `upper(text)` - Uppercase
- `replc(text, old, new)` - Replace text
- `findt(text, word)` - Find substring
- `lengt(text)` - Length
- `isolate(filter, list)` - Filter list by string

### File Commands
- `readf(file)` - Read file
- `write(file, text)` - Write file
- `get_line(n, file)` - Get line N from file
- `save_as(file)` - Save format buffer to file

### GUI Commands
- `gui_create(width, height, title)` - Create GUI window
- `obj_create(manager, shape, top_left, bottom_right)` - Create object
- `rgb(r, g, b)` - Convert RGB to hex color

### Advanced Features
- **Text Matching**: `match(text, pattern)` - Match text case to pattern
- **Cipher/Decipher**: `cipher(text, pattern)`, `decipher(text)` - Encode/decode text
- **Image Processing**: `move_to_replicate(gui, image_file, scale, pixel_size)` - Convert image to pixel art
- **Physics**: `on_earth()`, `on_moon()`, `on_jupiter()` - Set gravity types
- **3D Graphics**: `lib_3d()` - Import 3D library

## DataStorage Example

```python
from AbuLangModule import enable_abulang

enable_abulang()

# Create a DataStorage instance
Create DataStorage as db

# Store data
db.setItem("username", "Abu")
db.setItem("email", "abu@example.com")

# Retrieve data
show db.getItem("username")
show db.length
```

## GUI Example

```python
from AbuLangModule import enable_abulang

enable_abulang()

libra("abui")

# Create a GUI window
gui = gui_create(800, 600, "My App")

# Create objects
rect = obj_create(gui, "rect", (10, 10), (100, 100))
rect.set_color(rgb(255, 0, 0), "black")

# Run the GUI
gui.run()
```

## Documentation

For more detailed documentation, see:
- [DataStorage Guide](DATASTORAGE_GUIDE.md)
- [Import Guide](IMPORT_GUIDE.md)
- [Getting Started](../ABULANG_GETTING_STARTED.md)

## Requirements

- Python 3.8+
- PyYAML >= 5.4

## Optional Dependencies

For full features:
```bash
pip install AbuLang[full]
```

For chess AI:
```bash
pip install AbuLang[chess]
```

## License

MIT License

## Author

Abu

## Support

For issues, questions, or suggestions, please visit the project repository.
