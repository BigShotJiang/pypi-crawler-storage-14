from typing import Optional, List
from dataclasses_json import dataclass_json
from dataclasses import dataclass


@dataclass_json
@dataclass
class V4MonitorEventsCountDataRequest:
    regionID: str  # 资源池 ID
    eventName: str  # 本参数表示事件指标，事件指标见查询事件接口返回。
    service: str  # 服务，见事件监控：查询服务维度接口返回。
    dimension: str  # 维度，见事件监控：查询服务维度接口返回。
    startTime: int  # 查询起始时间戳
    endTime: int  # 查询截止时间戳
    period: int  # 统计周期
    resGroupID: Optional[str] = None  # 资源分组ID，在资源分组事件时传入



@dataclass_json
@dataclass
class V4MonitorEventsCountDataResponse:
    statusCode: Optional[int] = None
    error: Optional[str] = None
    message: Optional[str] = None
    description: Optional[str] = None
    errorCode: Optional[str] = None
    returnObj: Optional['V4MonitorEventsCountDataReturnObj'] = None


@dataclass_json
@dataclass
class V4MonitorEventsCountDataReturnObj:
    data: Optional[List[object]] = None  # 事件统计信息



