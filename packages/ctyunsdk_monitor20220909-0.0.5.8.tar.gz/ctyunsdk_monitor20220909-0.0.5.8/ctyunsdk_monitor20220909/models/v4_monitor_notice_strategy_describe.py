from typing import Optional, List
from dataclasses_json import dataclass_json
from dataclasses import dataclass


@dataclass_json
@dataclass
class V4MonitorNoticeStrategyDescribeRequest:
    noticeStrategyID: str  # 通知策略ID



@dataclass_json
@dataclass
class V4MonitorNoticeStrategyDescribeResponse:
    statusCode: Optional[int] = None
    error: Optional[str] = None
    message: Optional[str] = None
    description: Optional[str] = None
    errorCode: Optional[str] = None
    returnObj: Optional['V4MonitorNoticeStrategyDescribeReturnObj'] = None


@dataclass_json
@dataclass
class V4MonitorNoticeStrategyDescribeReturnObj:
    pass


