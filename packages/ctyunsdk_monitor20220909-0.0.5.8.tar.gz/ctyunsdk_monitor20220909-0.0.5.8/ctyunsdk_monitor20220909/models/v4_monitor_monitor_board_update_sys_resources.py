from typing import Optional, List
from dataclasses_json import dataclass_json
from dataclasses import dataclass


@dataclass_json
@dataclass
class V4MonitorMonitorBoardUpdateSysResourcesRequest:
    regionID: str  # 资源池ID
    boardID: str  # 系统监控看板ID
    resources: List['V4MonitorMonitorBoardUpdateSysResourcesRequestResources']  # 监控资源实例， 监控资源实例最多支持20个


@dataclass_json
@dataclass
class V4MonitorMonitorBoardUpdateSysResourcesRequestResources:
    resource: List['V4MonitorMonitorBoardUpdateSysResourcesRequestResourcesResource']  # 资源


@dataclass_json
@dataclass
class V4MonitorMonitorBoardUpdateSysResourcesRequestResourcesResource:
    key: str  # 资源实例标签键
    value: str  # 资源实例标签值



@dataclass_json
@dataclass
class V4MonitorMonitorBoardUpdateSysResourcesResponse:
    statusCode: Optional[int] = None
    error: Optional[str] = None
    message: Optional[str] = None
    description: Optional[str] = None
    errorCode: Optional[str] = None
    returnObj: Optional['V4MonitorMonitorBoardUpdateSysResourcesReturnObj'] = None


@dataclass_json
@dataclass
class V4MonitorMonitorBoardUpdateSysResourcesReturnObj:
    success: Optional[bool] = None  # 是否更新成功



