"""PDF MCP Server using FastMCP."""

from __future__ import annotations

import logging
from typing import Optional

from fastmcp import FastMCP

from .pdf_tools import add_text_watermark

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

mcp = FastMCP("PDF 添加文字水印")


@mcp.tool()
def add_text_watermark_direct(
    input_path: str,
    output_path: str,
    watermark_text: str,
    opacity: float = 0.1,
    font_size: int = 24,
    position: str = "center",
    color_r: float = 0.5,
    color_g: float = 0.5,
    color_b: float = 0.5,
    layout: str = "tile",
) -> str:
    """直接在PDF上添加文字水印（文字可选择、可复制）。
    
    Args:
        input_path: 输入PDF文件路径
        output_path: 输出PDF文件路径
        watermark_text: 水印文字内容
        opacity: 不透明度 (0.0-1.0)，通过调整颜色亮度实现，建议 0.03-0.1
        font_size: 字体大小
        position: 位置，可选 "center", "top-left", "top-right", "bottom-left", "bottom-right"
        color_r: 红色分量 (0.0-1.0)
        color_g: 绿色分量 (0.0-1.0)
        color_b: 蓝色分量 (0.0-1.0)
        layout: 布局模式，可选 "single"(单个), "corners"(四角), "tile"(平铺)
    
    Returns:
        添加文字水印结果的详细信息
    """

    try:
        result = add_text_watermark(
            input_path,
            output_path,
            watermark_text,
            opacity,
            font_size,
            position,
            0.0,
            (color_r, color_g, color_b),
            layout,
        )
        
        layout_tips = {
            "single": "单个位置",
            "corners": "四个角落",
            "tile": "整页平铺"
        }.get(layout, "单个位置")
        
        return (
            f"✅ 添加文字水印成功\n"
            f"输出文件: {result.output_path}\n"
            f"页数: {result.page_count}\n"
            f"水印类型: {result.watermark_type}\n"
            f"水印内容: {result.watermark_text}\n"
            f"布局方式: {layout_tips}\n"
            f"特点: 文字可选择、可复制"
        )
    
    except Exception as e:
        logger.error(f"Failed to add text watermark: {e}")
        raise e


def main():
    """启动MCP服务器。"""
    mcp.run()


if __name__ == "__main__":
    main()
