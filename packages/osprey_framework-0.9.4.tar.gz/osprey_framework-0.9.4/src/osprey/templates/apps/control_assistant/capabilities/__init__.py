"""
Capabilities for control assistant.

Thin wrappers around service layer that handle Osprey framework integration.
"""

