from pydantic import BaseModel, Field

from .currency import Currency
from .price_type import PriceType


class SalePrice(BaseModel):
    value: float
    currency: Currency
    price_type: PriceType = Field(..., alias="priceType")
