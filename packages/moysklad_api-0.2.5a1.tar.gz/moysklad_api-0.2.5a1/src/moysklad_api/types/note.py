from .entity import Entity


class Note(Entity):
    pass
