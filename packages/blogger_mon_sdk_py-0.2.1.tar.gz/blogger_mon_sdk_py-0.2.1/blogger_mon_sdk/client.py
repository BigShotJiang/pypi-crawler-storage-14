from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Callable

import requests


class BlogSDKError(Exception):
  """Custom error raised for BloggerMon API failures."""

  def __init__(self, message: str, status: Optional[int] = None, code: Optional[str] = None) -> None:
    super().__init__(message)
    self.status = status
    self.code = code


@dataclass
class BlogIdea:
  title: str
  description: str
  targetAudience: str
  keywords: List[str]
  trending: bool


class BlogSDK:
  """Python client mirroring the TypeScript SDK feature set."""

  def __init__(self, base_url: str = "https://ysqzeskcvmalzhvjyncp.supabase.co", api_key: Optional[str] = None, token: Optional[str] = None) -> None:
    if not base_url:
      raise ValueError("BlogSDK: base_url is required")

    self.base_url = base_url.rstrip("/")
    self.auth_header = api_key or token

    self.api_url = f"{self.base_url}/functions/v1/blog-api"
    self.rss_url = f"{self.base_url}/functions/v1/rss-feed"
    self.analyze_url = f"{self.base_url}/functions/v1/analyze-blog"
    self.idea_url = f"{self.base_url}/functions/v1/generate-blog-ideas"
    self.refine_url = f"{self.base_url}/functions/v1/refine-content"

  def set_auth(self, token: str) -> None:
    self.auth_header = token

  def _headers(self) -> Dict[str, str]:
    headers = {
      "Content-Type": "application/json",
    }

    if self.auth_header:
      if self.auth_header.startswith("bmk_"):
        headers["x-api-key"] = self.auth_header
      headers["Authorization"] = f"Bearer {self.auth_header}"

    return headers

  def _request(self, method: str, url: str, **kwargs: Any) -> Any:
    response = requests.request(method, url, headers=self._headers(), timeout=60, **kwargs)
    if response.ok:
      if response.content:
        return response.json()
      return None

    try:
      data = response.json()
      message = data.get("error") or data.get("message") or response.text
      code = data.get("code")
    except ValueError:
      message = response.text or f"HTTP {response.status_code}"
      code = None

    raise BlogSDKError(message, response.status_code, code)

  def get_posts(self, limit: int = 10, offset: int = 0, status: Optional[str] = None) -> Dict[str, Any]:
    params = {
      "limit": limit,
      "offset": offset,
    }
    if status:
      params["status"] = status
    return self._request("GET", self._join(self.api_url, "posts"), params=params)

  def get_post(self, post_id: str) -> Dict[str, Any]:
    return self._request("GET", self._join(self.api_url, "posts", post_id))

  def create_post(self, **data: Any) -> Dict[str, Any]:
    return self._request("POST", self._join(self.api_url, "posts"), json=data)

  def update_post(self, post_id: str, **data: Any) -> Dict[str, Any]:
    return self._request("PUT", self._join(self.api_url, "posts", post_id), json=data)

  def delete_post(self, post_id: str) -> None:
    self._request("DELETE", self._join(self.api_url, "posts", post_id))

  def get_rss_feed_url(self) -> str:
    return self.rss_url

  def get_open_api_url(self) -> str:
    return self.api_url

  def get_open_api_spec(self) -> Dict[str, Any]:
    return self._request("GET", self.api_url)

  def analyze_blog(self, title: str, content: str) -> Dict[str, Any]:
    self._ensure_auth("AI features require authentication.")
    return self._request("POST", self.analyze_url, json={"title": title, "content": content})

  def generate_ideas(self, user_input: str, niche: Optional[str] = None) -> Dict[str, Any]:
    self._ensure_auth("AI features require authentication.")
    payload = {"userInput": user_input}
    if niche:
      payload["niche"] = niche
    return self._request("POST", self.idea_url, json=payload)

  def refine_content(self, title: str, content: str) -> Dict[str, Any]:
    self._ensure_auth("AI features require authentication.")
    return self._request("POST", self.refine_url, json={"title": title, "content": content})

  def run_ai_workflow(
    self,
    options: Dict[str, Any],
    select_idea: Optional[Callable[[List[BlogIdea]], BlogIdea]] = None,
  ) -> Dict[str, Any]:
    self._ensure_auth("AI workflow requires authentication.")

    user_input = options.get("user_input") or options.get("userInput")
    if not user_input:
      raise ValueError("user_input is required")

    niche = options.get("niche")
    target_score = options.get("target_score") or options.get("targetScore") or 90
    auto_publish = options.get("auto_publish") or options.get("autoPublish") or False
    publish_status = options.get("publish_status") or options.get("publishStatus") or "draft"
    draft_content = options.get("draft_content") or options.get("draftContent")
    force_refine = options.get("force_refine") or options.get("forceRefine") or False

    ideas_result = self.generate_ideas(user_input, niche)
    ideas = [
      BlogIdea(**idea)
      for idea in ideas_result.get("ideas", [])
    ]
    if not ideas:
      raise BlogSDKError("Idea generation returned no results.")

    chosen = select_idea(ideas) if select_idea else ideas[0]
    initial_draft = draft_content or self._build_draft(chosen)

    analysis = self.analyze_blog(chosen.title, initial_draft)
    final_content = initial_draft
    refined_content = None

    if force_refine or analysis.get("score", 0) < target_score:
      refined = self.refine_content(chosen.title, final_content)
      refined_content = refined.get("refinedContent")
      final_content = refined_content or final_content

    published_post = None
    if auto_publish:
      published_post = self.create_post(title=chosen.title, content=final_content, status=publish_status)

    return {
      "idea": chosen.__dict__,
      "ideas": [idea.__dict__ for idea in ideas],
      "trending_topics": ideas_result.get("trendingTopics", []),
      "initial_draft": initial_draft,
      "final_content": final_content,
      "analysis": analysis,
      "refined_content": refined_content,
      "published_post": published_post,
    }

  def _build_draft(self, idea: BlogIdea) -> str:
    keywords = "\n".join(f"- {keyword}" for keyword in idea.keywords) if idea.keywords else "- Add keywords"
    return (
      f"# {idea.title}\n\n"
      f"{idea.description}\n\n"
      "## Who it's for\n"
      f"- {idea.targetAudience}\n\n"
      "## Outline\n"
      "- Introduction\n"
      "- Key insight 1\n"
      "- Key insight 2\n"
      "- Conclusion / Next steps\n\n"
      "## Keywords\n"
      f"{keywords}\n"
    )

  def _join(self, *parts: str) -> str:
    return "/".join(part.strip("/") for part in parts if part)

  def _ensure_auth(self, message: str) -> None:
    if not self.auth_header:
      raise BlogSDKError(message, status=401)

