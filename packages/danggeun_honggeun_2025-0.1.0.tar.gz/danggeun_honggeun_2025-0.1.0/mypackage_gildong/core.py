﻿def add(a: int, b: int) -> int:
    """두 숫자를 더해서 반환함"""
    return a + b