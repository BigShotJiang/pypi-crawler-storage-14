"""BOSA Connectors - Alias for gl_connector_sdk."""

import sys

from gl_connector_sdk import (  # noqa: F401
    BOSAConnectorToolGenerator,
    BosaAuthenticator,
    BosaConnector,
    BosaConnectorError,
    BosaConnectorModule,
)

# Import all submodules from gl_connector_sdk
import gl_connector_sdk.action  # noqa: E402
import gl_connector_sdk.action_response  # noqa: E402
import gl_connector_sdk.auth  # noqa: E402
import gl_connector_sdk.connector  # noqa: E402
import gl_connector_sdk.constant  # noqa: E402
import gl_connector_sdk.helpers  # noqa: E402
import gl_connector_sdk.models  # noqa: E402
import gl_connector_sdk.module  # noqa: E402
import gl_connector_sdk.tool  # noqa: E402

# Register all modules in sys.modules so they can be imported from bosa_connectors
# This allows: from bosa_connectors.module import BosaConnectorError
# Same as: from gl_connector_sdk.module import BosaConnectorError
sys.modules["bosa_connectors.action"] = gl_connector_sdk.action
sys.modules["bosa_connectors.action_response"] = gl_connector_sdk.action_response
sys.modules["bosa_connectors.auth"] = gl_connector_sdk.auth
sys.modules["bosa_connectors.auth.api_key"] = gl_connector_sdk.auth.api_key
sys.modules["bosa_connectors.auth.base"] = gl_connector_sdk.auth.base
sys.modules["bosa_connectors.connector"] = gl_connector_sdk.connector
sys.modules["bosa_connectors.constant"] = gl_connector_sdk.constant
sys.modules["bosa_connectors.helpers"] = gl_connector_sdk.helpers
sys.modules["bosa_connectors.helpers.authenticator"] = gl_connector_sdk.helpers.authenticator
sys.modules["bosa_connectors.helpers.integrations"] = gl_connector_sdk.helpers.integrations
sys.modules["bosa_connectors.helpers.tool_builder"] = gl_connector_sdk.helpers.tool_builder
sys.modules["bosa_connectors.helpers.tool_builder.base"] = gl_connector_sdk.helpers.tool_builder.base
sys.modules["bosa_connectors.helpers.tool_builder.gllm"] = gl_connector_sdk.helpers.tool_builder.gllm
sys.modules["bosa_connectors.helpers.tool_builder.json_schema_generator"] = (
    gl_connector_sdk.helpers.tool_builder.json_schema_generator
)
sys.modules["bosa_connectors.helpers.tool_builder.langchain"] = gl_connector_sdk.helpers.tool_builder.langchain
sys.modules["bosa_connectors.models"] = gl_connector_sdk.models
sys.modules["bosa_connectors.models.action"] = gl_connector_sdk.models.action
sys.modules["bosa_connectors.models.file"] = gl_connector_sdk.models.file
sys.modules["bosa_connectors.models.result"] = gl_connector_sdk.models.result
sys.modules["bosa_connectors.models.token"] = gl_connector_sdk.models.token
sys.modules["bosa_connectors.models.user"] = gl_connector_sdk.models.user
sys.modules["bosa_connectors.module"] = gl_connector_sdk.module
sys.modules["bosa_connectors.tool"] = gl_connector_sdk.tool

__all__ = [
    "BosaAuthenticator",
    "BosaConnector",
    "BosaConnectorError",
    "BosaConnectorModule",
    "BOSAConnectorToolGenerator",
]
