"""The entrypoint class for GL Connector SDKs.

This class serves as the main point where implementors will instantiate
in order to use Connector using this SDK. They only need to initialize
this class using the Base URL and API Key as such:

```python
# Initialize connector
connector =  BosaConnector(api_base_url="https://api.bosa.id/", api_key="your-key")

# Create action builders for different plugins
github = connector.connect('github')
gdrive = connector.connect('google_drive') # This is just an example

# Method 1: Direct execution with raw response
data, status = connector.execute('github', 'list_pull_requests',
    owner='GDP-ADMIN',
    repo='bosa',
    page=1,
    per_page=10
)

# Method 2: Direct execution with pagination
response = connector.run('github', 'list_pull_requests',
    owner='GDP-ADMIN',
    repo='bosa',
    page=1,
    per_page=10
)

# Method 3: Fluent interface with raw response
data, status = github.action('list_pull_requests')\
    .params({
        'owner': 'GDP-ADMIN',
        'repo': 'bosa',
        'page': 1,
        'per_page': 10
    })\
    .token('user-token')\
    .headers({'X-Custom-Header': 'value'})\
    .execute()

# Method 4: Fluent interface with pagination
response = github.action('list_pull_requests')\
    .params({
        'owner': 'GDP-ADMIN',
        'repo': 'bosa',
        'page': 1,
        'per_page': 10
    })\
    .token('user-token')\
    .headers({'X-Custom-Header': 'value'})\
    .run()

# Pagination example
data = response.get_data()
while response.has_next():
    response = response.next_page()
    data = response.get_data()
```

Authors:
    Samuel Lusandi (samuel.lusandi@gdplabs.id)
"""

import logging
from typing import Annotated, Any, Dict, List, Optional

import requests
from requests.exceptions import HTTPError
from typing_extensions import deprecated

from gl_connector_sdk.action import Action
from gl_connector_sdk.action_response import ActionResponse
from gl_connector_sdk.auth import ApiKeyAuthenticator
from gl_connector_sdk.constant import DEFAULT_API_KEY, DEFAULT_API_URL
from gl_connector_sdk.helpers.authenticator import BosaAuthenticator
from gl_connector_sdk.helpers.integrations import BosaIntegrationHelper
from gl_connector_sdk.models.file import ConnectorFile
from gl_connector_sdk.models.result import ActionResult
from gl_connector_sdk.models.token import BosaToken
from gl_connector_sdk.models.user import BosaUser, CreateUserResponse
from gl_connector_sdk.module import BosaConnectorError, BosaConnectorModule


class BosaConnector:
    """Main connector class that manages all GL Connector SDK modules."""

    DEFAULT_TIMEOUT = 30
    DEFAULT_MAX_ATTEMPTS = 1
    OAUTH2_FLOW_ENDPOINT = "/connectors/{name}/integrations"
    INTEGRATION_CHECK_ENDPOINT = "/connectors/{name}/integration-exists"

    _instance = None

    def __init__(self, api_base_url: str = DEFAULT_API_URL, api_key: str = DEFAULT_API_KEY):
        """Initialization."""
        if not hasattr(self, "_initialized"):
            self.api_base_url = api_base_url
            self.auth_scheme = ApiKeyAuthenticator(api_key)
            self.bosa_authenticator = BosaAuthenticator(api_base_url, api_key)
            self.bosa_integration_helper = BosaIntegrationHelper(api_base_url, api_key)
            self._modules: Dict[str, BosaConnectorModule] = {}
            self._initialized = True

    def get_available_modules(self) -> List[str]:
        """Scan and cache all available connector modules.

        Returns:
            List of available modules
        """
        try:
            response = requests.get(
                f"{self.api_base_url}/{BosaConnectorModule.INFO_PATH}",
                timeout=self.DEFAULT_TIMEOUT,
            )
            if response.status_code == 200:  # noqa PLR2004
                available_modules = response.json()
                return available_modules.keys()
            return []
        except Exception as e:
            raise BosaConnectorError(f"Failed to scan available modules: {str(e)}") from e

    def create_bosa_user(self, identifier: str) -> CreateUserResponse:
        """Create a BOSA User in the scope of Connector.

        Args:
            identifier: BOSA Username

        Returns:
            BOSA User Data with the secret
        """
        return self.bosa_authenticator.register(identifier)

    def authenticate_bosa_user(self, identifier: str, secret: str) -> BosaToken:
        """Triggers the authentication of the BOSA User in the scope of Connector.

        Args:
            identifier: BOSA Username
            secret: BOSA Password

        Returns:
            BOSA User Token
        """
        return self.bosa_authenticator.authenticate(identifier, secret)

    def initiate_connector_auth(self, app_name: str, token: str, callback_uri: str) -> str:
        """Triggers the OAuth2 flow for a connector for this API Key and User Token.

        Args:
            app_name: The name of the app/connector to use
            token: The BOSA User Token
            callback_uri: The callback URL to be used for the integration

        Returns:
            The redirect URL to be used for the integration
        """
        return self.bosa_integration_helper.initiate_integration(app_name, token, callback_uri)

    def initiate_plugin_configuration(self, app_name: str, token: str, config: dict[str, Any]) -> ActionResult:
        """Initiates a plugin configuration for a given app/connector.

        Args:
            app_name: The name of the app/connector to use
            token: The BOSA User Token
            config: The configuration for the integration

        Returns:
            Result that contains an error message (if any), and the success status.
        """
        return self.bosa_integration_helper.initiate_plugin_configuration(app_name, token, config)

    def get_user_info(self, token: str) -> BosaUser:
        """Gets the user information for a given token.

        Args:
            token: The BOSA User Token

        Returns:
            BOSA User
        """
        return self.bosa_authenticator.get_user(token)

    def user_has_integration(self, app_name: str, token: str) -> bool:
        """Checks whether or not a user has an integration for a given app in this client.

        Args:
            app_name: The name of the app/connector to use
            token: The BOSA User Token

        Returns:
            True if the user has an integration for the given app
        """
        return self.bosa_integration_helper.user_has_integration(app_name, token)

    def select_integration(self, app_name: str, token: str, user_identifier: str) -> ActionResult:
        """Selects a 3rd party integration for a user against a certain client.

        Args:
            token: The BOSA User Token
            app_name: The name of the app/connector to use
            user_identifier: User identifier to specify which integration to select

        Returns:
            Result that contains an error message (if any), and the success status.
        """
        return self.bosa_integration_helper.select_integration(app_name, token, user_identifier)

    def get_integration(self, app_name: str, token: str, user_identifier: str) -> dict:
        """Gets a 3rd party integration for a user against a certain client.

        Args:
            app_name: The name of the app/connector to use
            token: The BOSA User Token
            user_identifier: User identifier to specify which integration to get

        Returns:
            The integration data as a dictionary
        """
        return self.bosa_integration_helper.get_integration(app_name, token, user_identifier)

    def remove_integration(self, app_name: str, token: str, user_identifier: str) -> ActionResult:
        """Removes a 3rd party integration for a user against a certain client.

        Args:
            token: The BOSA User Token
            app_name: The name of the app/connector to use
            user_identifier: User identifier to specify which integration to remove

        Returns:
            Result that contains an error message (if any), and the success status.
        """
        return self.bosa_integration_helper.remove_integration(app_name, token, user_identifier)

    def get_connector(self, app_name: str) -> BosaConnectorModule:
        """Get or create an instance of a connector module.

        Args:
            app_name: The name of the app/connector to use

        Returns:
            BosaConnectorModule: The connector module
        """
        try:
            if app_name not in self._modules:
                application = BosaConnectorModule(app_name, self.api_base_url, BosaConnectorModule.INFO_PATH)
                self._modules[app_name] = application
        except BosaConnectorError as e:
            logging.warning(f"No connector found for app '{app_name}': {str(e)}")
            raise BosaConnectorError(f"No connector found for app '{app_name}': {str(e)}") from e
        except HTTPError as e:
            logging.warning(f"Connector failed to initialize: {str(e)}")
            raise BosaConnectorError(f"Connector failed to initialize: {str(e)}") from e
        except Exception as e:
            logging.warning(f"Failed to get connector for app '{app_name}': {str(e)}")
            raise BosaConnectorError(f"Failed to get connector for app '{app_name}': {str(e)}") from e
        return self._modules[app_name]

    def refresh_connector(self, app_name: str) -> None:
        """Refresh the connector module."""
        if app_name in self._modules:
            del self._modules[app_name]

    def connect(self, app_name: str) -> Action:
        """Connect to a specific module and prepare for action execution.

        Creates an Action instance for the specified connector..

        Example:
            # Create action builders for different connectors
            github = connector.connect('github')
            gdrive = connector.connect('google_drive') # This is just an example

        Args:
            app_name: The name of the app/connector to use (eg: 'github', 'google_drive', etc)

        Returns:
            Action: A new Action instance for the specified connector
        """
        module = self.get_connector(app_name)
        return Action(module, self.auth_scheme)

    def execute(  # noqa: PLR0913
        self,
        app_name: str,
        action: str,
        *,
        identifier: Optional[str] = None,
        account: Annotated[Optional[str], deprecated("Use 'identifier' instead; will be removed")] = None,
        max_attempts: int = DEFAULT_MAX_ATTEMPTS,
        input_: Dict[str, Any] = None,
        token: Optional[str] = None,
        headers: Optional[Dict[str, str]] = None,
        timeout: Optional[int] = DEFAULT_TIMEOUT,
        **kwargs,
    ) -> tuple[Dict[str, Any] | ConnectorFile, int]:
        """Execute an action on a specific module and return raw response.

        The method supports both ways of passing parameters:
        1. As a dictionary: execute(app_name, action, params_dict)
        2. As keyword arguments: execute(app_name, action, param1=value1, param2=value2)

        Args:
            app_name: The name of the app/connector to use
            action: The action to execute
            input_: Optional input data for the action
            token: The BOSA User Token
            identifier: Optional user integration account identifier
            account: Optional user integration account identifier (deprecated, remove this in the future)
            headers: Optional headers to include in the request
            max_attempts: The number of times the request can be retried for. Default is 0 (does not retry). Note that
                the backoff factor is 2^(N - 1) with the basic value being 1 second (1, 2, 4, 8, 16, 32, ...).
                Maximum number of retries is 10 with a maximum of 64 seconds per retry.
            timeout: Optional timeout for the request in seconds. Default is 30 seconds.
            **kwargs: Optional keyword arguments

        Returns:
            Tuple of (response, status_code) where response is the API response and status_code is the HTTP status code
        """
        module = self.get_connector(app_name)

        # If input_ is provided, use it as params
        # Otherwise, use kwargs as params
        params = input_ if isinstance(input_, dict) else kwargs

        return module.execute(
            action,
            max_attempts=max_attempts,
            input_=params,
            token=token,
            identifier=identifier or account,  # account is deprecated, remove this in the future
            authenticator=self.auth_scheme,
            headers=headers,
            timeout=timeout,
        )

    def run(  # noqa: PLR0913
        self,
        app_name: str,
        action: str,
        *,
        identifier: Optional[str] = None,
        account: Annotated[Optional[str], deprecated("Use 'identifier' instead; will be removed")] = None,
        max_attempts: int = DEFAULT_MAX_ATTEMPTS,
        input_: Dict[str, Any] = None,
        token: Optional[str] = None,
        headers: Optional[Dict[str, str]] = None,
        timeout: Optional[int] = DEFAULT_TIMEOUT,
        **kwargs,
    ) -> ActionResponse:
        """Execute an action on a specific module and return paginated response.

        The method supports both ways of passing parameters:
        1. As a dictionary: execute(app_name, action, input_dict)
        2. As keyword arguments: execute(app_name, action, param1=value1, param2=value2)

        Args:
            app_name: The name of the app/connector to use
            action: The action to execute
            input_: Optional input data for the action
            token: The BOSA User Token
            identifier: Optional user identifier to use for the request
            account: Optional user identifier to use for the request (deprecated, remove this in the future)
            headers: Optional headers to include in the request
            max_attempts: The number of times the request can be retried for. Default is 0 (does not retry). Note that
                the backoff factor is 2^(N - 1) with the basic value being 1 second (1, 2, 4, 8, 16, 32, ...).
                Maximum number of retries is 10 with a maximum of 64 seconds per retry.
            timeout: Optional timeout for the request in seconds. Default is 30 seconds.
            **kwargs: Optional keyword arguments

        Returns:
            ActionResponse: Response wrapper with pagination support
        """
        # If input_ is provided, use it as params
        # Otherwise, use kwargs as params
        params = input_ if isinstance(input_, dict) else kwargs

        executor = (
            self.connect(app_name)
            .action(action)
            .token(token)
            .headers(headers)
            .identifier(identifier or account)
            .max_attempts(max_attempts)
            .params(params)
            .timeout(timeout)
        )

        return executor.run()
