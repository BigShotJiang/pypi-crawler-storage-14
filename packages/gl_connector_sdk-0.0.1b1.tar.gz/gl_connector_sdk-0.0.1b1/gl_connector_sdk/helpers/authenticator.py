"""Authenticator module for Connector.

Authors:
    Samuel Lusandi (samuel.lusandi@gdplabs.id)
"""

import requests

from gl_connector_sdk.auth import ApiKeyAuthenticator
from gl_connector_sdk.constant import DEFAULT_API_KEY, DEFAULT_API_URL
from gl_connector_sdk.models.token import BosaToken
from gl_connector_sdk.models.user import BosaUser, CreateUserResponse


class BosaAuthenticator:
    """Authenticator for Connector."""

    DEFAULT_TIMEOUT = 10

    def __init__(
        self, api_base_url: str = DEFAULT_API_URL, api_key: str = DEFAULT_API_KEY
    ):
        """Initialize the BosaAuthenticator with the provided API key.

        Args:
            api_base_url (str): The base URL for the Connector. Defaults to DEFAULT_API_URL.
            api_key (str): The API key for authentication. Defaults to DEFAULT_API_KEY.
        """
        self.api_base_url = api_base_url
        self.auth_scheme = ApiKeyAuthenticator(api_key)

    def register(self, identifier: str) -> CreateUserResponse:
        """Register a BOSA User in the scope of Connector.

        Args:
            identifier: BOSA Username

        Returns:
            BOSA User Data with the secret
        """
        headers = {self.auth_scheme.API_KEY_HEADER: self.auth_scheme.api_key}
        response = requests.post(
            f"{self.api_base_url}/users",
            json={"identifier": identifier},
            headers=headers,
            timeout=self.DEFAULT_TIMEOUT,
        )

        if response.status_code != 200:  # noqa PLR2004
            raise ValueError(f"Failed to register user: {response.json()}")

        data = response.json()["data"]
        return CreateUserResponse.model_validate(data)

    def authenticate(self, identifier: str, secret: str) -> BosaToken:
        """Authenticate a BOSA User in the scope of Connector.

        Args:
            identifier: BOSA Username
            secret: BOSA Password

        Returns:
            BOSA User Token
        """
        headers = {self.auth_scheme.API_KEY_HEADER: self.auth_scheme.api_key}
        response = requests.post(
            f"{self.api_base_url}/auth/tokens",
            json={"identifier": identifier, "secret": secret},
            headers=headers,
            timeout=self.DEFAULT_TIMEOUT,
        )

        if response.status_code != 200:  # noqa PLR2004
            raise ValueError(f"Failed to authenticate user: {response.json()}")

        data = response.json()["data"]
        return BosaToken.model_validate(data)

    def get_user(self, token: str) -> BosaUser:
        """Get the current user from Connector.

        Args:
            token: The BOSA User Token

        Returns:
            BOSA User
        """
        headers = {
            self.auth_scheme.API_KEY_HEADER: self.auth_scheme.api_key,
            "Authorization": f"Bearer {token}",
        }
        response = requests.get(
            f"{self.api_base_url}/users/me",
            headers=headers,
            timeout=self.DEFAULT_TIMEOUT,
        )

        if response.status_code != 200:  # noqa PLR2004
            raise ValueError(f"Failed to receive user. {str(response.json())}")

        data = response.json()["data"]
        return BosaUser.model_validate(data)
