"""Helpers for GL Connector SDKs."""
