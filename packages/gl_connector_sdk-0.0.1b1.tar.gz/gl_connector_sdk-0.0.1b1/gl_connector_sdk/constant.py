DEFAULT_API_URL = "https://connector.gdplabs.id"
DEFAULT_API_KEY = "connector"
DEFAULT_SERVICE_PREFIX = "CONNECTOR"
