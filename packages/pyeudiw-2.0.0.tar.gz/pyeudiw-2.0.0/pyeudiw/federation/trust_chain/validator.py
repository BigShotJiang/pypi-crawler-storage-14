# TODO: move trust_chain_validator.py here
