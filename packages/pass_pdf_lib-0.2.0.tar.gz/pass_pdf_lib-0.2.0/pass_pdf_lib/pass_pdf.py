from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import A4
from reportlab.lib.pagesizes import letter
from reportlab.pdfgen import canvas
import tempfile


def generate_pass_pdf(pass_obj):
    """Generate a temporary PDF file containing pass details."""
    temp_file = tempfile.NamedTemporaryFile(delete=False, suffix=".pdf")
    c = canvas.Canvas(temp_file.name, pagesize=letter)

    c.setFont("Helvetica", 14)
    c.drawString(100, 750, f"City Pass")
    c.drawString(100, 720, f"Name: {pass_obj.fullname}")
    c.drawString(100, 700, f"Pass Number: {pass_obj.passnumber}")
    c.drawString(100, 680, f"Category: {pass_obj.category_id.categoryname}")
    c.drawString(100, 660, f"Source: {pass_obj.source}")
    c.drawString(100, 640, f"Destination: {pass_obj.destinations}")
    c.drawString(100, 620, f"Valid From: {pass_obj.fromdate}")
    c.drawString(100, 600, f"Valid To: {pass_obj.todate}")
    c.drawString(100, 580, f"Cost: ₹{pass_obj.cost}")

    c.save()
    return temp_file.name
