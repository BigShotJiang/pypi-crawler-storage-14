# pymlga

Version: 0.2.0

Python machine learning by genetic algorithm

