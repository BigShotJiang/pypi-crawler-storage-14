# codefusion/utils/helpers.py

def ensure_leading_dot(ext: str) -> str:
    """Ensure the extension starts with a dot."""
    return '.' + ext.lower().lstrip('.')
