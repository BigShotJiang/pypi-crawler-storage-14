__version__ = "1.0.0"

from .ui.cli import main
from .core.app import CodeFusionApp
