from warnings import warn

from kelvin.krn import *  # noqa

warn("kelvin.message.krn is deprecated, use kelvin.krn instead")
