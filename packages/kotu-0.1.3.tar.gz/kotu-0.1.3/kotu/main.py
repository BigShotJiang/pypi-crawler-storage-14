import random
import string
from typing import Optional, Dict

def create(url: str, slug: Optional[str] = None, custom_domain: Optional[str] = None) -> Dict[str, str]:
    """
    Simulate creating a shortened link (like Bitly).

    Parameters:
        url (str): The original URL to shorten.
        slug (str, optional): Custom slug preference (subject to fail if unavailable).
        custom_domain (str, optional): Custom domain for the shortened link.

    Returns:
        dict: A dictionary with:
            - 'link' (str): The generated shortened link.
            - 'status' (str): 'success' or 'fail'.
            - 'message' (str): Explanation message.
    """
    # Simulate random slug generation if not provided
    if slug:
        short_code = slug
    else:
        short_code = ''.join(random.choices(string.ascii_letters + string.digits, k=6))
    
    # Simulate custom domain or default
    domain = custom_domain if custom_domain else "kotu.me"
    
    # Simulate success/fail randomly (just for demonstration)
    if slug and slug.lower() == "taken":  # simulate slug unavailable
        return {
            "link": "",
            "status": "fail",
            "message": f"The slug '{slug}' is unavailable."
        }

    link = f"{domain}/{short_code}"
    return {
        "link": link,
        "status": "success",
        "message": f"Shortened URL created for {url}"
    }
