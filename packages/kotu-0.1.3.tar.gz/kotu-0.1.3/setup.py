from setuptools import setup, find_packages
from pathlib import Path

this_directory = Path(__file__).parent
long_description = (this_directory / "README.md").read_text(encoding="utf-8")

setup(
    name="kotu",
    version="0.1.3",
    packages=find_packages(),
    install_requires=[],
    author="Kotu Admin",
    description="Kotu.me — fast links, smart analytics, developer-first APIs.",
    long_description=long_description,
    long_description_content_type="text/markdown", 
    url="https://developer.kotu.me",
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ]
)
