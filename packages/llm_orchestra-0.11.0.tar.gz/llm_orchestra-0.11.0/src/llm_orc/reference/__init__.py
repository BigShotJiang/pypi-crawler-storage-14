"""Reference implementations for ScriptContract system."""
