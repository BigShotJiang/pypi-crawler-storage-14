"""Init for models (empty)."""
