# Copyright (c) 2025. All rights reserved.
"""Test suite for MUC Soundboard."""
