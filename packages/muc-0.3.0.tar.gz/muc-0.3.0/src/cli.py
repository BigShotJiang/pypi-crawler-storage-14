# Copyright (c) 2025. All rights reserved.
"""CLI interface using rich-click for beautiful output."""

import contextlib
import sys

import rich_click as click
from pynput import keyboard
from rich.console import Console
from rich.panel import Panel
from rich.table import Table

from .audio_manager import AudioManager
from .config import Config
from .exceptions import MUCError
from .hotkey_manager import HotkeyManager
from .logging_config import init_logging
from .metadata import MetadataManager
from .queue_manager import QueueManager
from .soundboard import Soundboard
from .validators import SUPPORTED_FORMATS, validate_audio_file, validate_audio_file_safe

# Configure rich-click
click.rich_click.TEXT_MARKUP = "rich"
click.rich_click.SHOW_ARGUMENTS = True
click.rich_click.GROUP_ARGUMENTS_OPTIONS = True
click.rich_click.STYLE_ERRORS_SUGGESTION = "magenta italic"
click.rich_click.ERRORS_SUGGESTION = "Try running the '--help' flag for more information."
click.rich_click.MAX_WIDTH = 100

console = Console()


def get_soundboard() -> tuple[Soundboard, AudioManager]:
    """Initialize and return soundboard and audio manager instances.

    Returns:
        Tuple containing initialized Soundboard and AudioManager instances.

    """
    config = Config()
    audio_manager = AudioManager(console)
    metadata_manager = MetadataManager()
    hotkey_manager = HotkeyManager(config)

    if config.output_device_id is not None:
        audio_manager.set_output_device(config.output_device_id)

    # Set volume from config (silently, without printing)
    audio_manager.volume = config.volume

    soundboard = Soundboard(
        audio_manager,
        config.sounds_dir,
        console,
        metadata_manager=metadata_manager,
        hotkey_manager=hotkey_manager,
    )
    return soundboard, audio_manager


@click.group(invoke_without_command=True)
@click.option("--debug", is_flag=True, help="Enable debug logging")
@click.pass_context
@click.version_option(version="0.3.0", prog_name="muc")
def cli(ctx: click.Context, debug: bool) -> None:  # noqa: FBT001
    """[bold cyan]MUC Soundboard[/bold cyan].

    Play audio files through your microphone in games using hotkeys.
    Perfect for CS, Battlefield, COD, and more! 🎮🎵
    """
    # Initialize logging
    init_logging(debug=debug)

    # Store debug flag in context for subcommands
    ctx.ensure_object(dict)
    ctx.obj["debug"] = debug

    if ctx.invoked_subcommand is None:
        console.print(
            Panel.fit(
                "[bold cyan]MUC Soundboard[/bold cyan]\n"
                "Play audio through your microphone in games!\n\n"
                "Run [bold]muc --help[/bold] to see all commands.",
                border_style="cyan",
            ),
        )


@cli.command()
def setup() -> None:
    """Configure your audio output device.

    Guides you through selecting a virtual audio device (like VB-Cable)
    to route sound to your microphone in games.
    """
    config = Config()
    audio_manager = AudioManager(console)

    console.print("\n[bold cyan]═══ Setup Wizard ═══[/bold cyan]\n")

    # Show all devices
    audio_manager.print_devices()

    # Check for virtual cable
    virtual_cable = audio_manager.find_virtual_cable()
    if virtual_cable is not None:
        console.print(
            f"[green]✓[/green] Found virtual audio device at ID [bold]{virtual_cable}[/bold]",
        )
        if click.confirm("Use this device?", default=True):
            audio_manager.set_output_device(virtual_cable)
            config.output_device_id = virtual_cable
            config.save()
            console.print("[green]✓[/green] Configuration saved!")
            return
    else:
        console.print("[yellow]⚠[/yellow] No virtual audio cable detected!")
        console.print("\n[dim]You need VB-Cable or similar virtual audio device.[/dim]")
        console.print("[dim]Download VB-Cable: https://vb-audio.com/Cable/[/dim]\n")

    # Manual selection
    device_id = click.prompt("Enter the device ID to use as output", type=int)
    if audio_manager.set_output_device(device_id):
        config.output_device_id = device_id
        config.save()
        console.print("[green]✓[/green] Configuration saved!")
    else:
        console.print("[red]✗[/red] Invalid device selection.")
        sys.exit(1)


@cli.command()
def devices() -> None:
    """List all available audio devices on your system."""
    audio_manager = AudioManager(console)
    audio_manager.print_devices()


@cli.command()
@click.argument("sound_name", required=False)
def play(sound_name: str | None) -> None:
    """Play a sound by name.

    If no sound name is provided, shows a list of available sounds.
    """
    soundboard, _ = get_soundboard()

    if not soundboard.sounds:
        console.print("[red]✗[/red] No sounds found in sounds directory.")
        console.print(f"[dim]Add audio files to: {soundboard.sounds_dir}[/dim]")
        sys.exit(1)

    if sound_name is None:
        soundboard.list_sounds()
        sound_name = str(click.prompt("Enter sound name to play", type=str))

    soundboard.play_sound(sound_name, blocking=True)


@cli.command()
@click.option("--tag", "-t", "filter_tag", help="Filter by tag (comma-separated for multiple)")
@click.option("--favorites", "-f", is_flag=True, help="Show only favorites")
def sounds(filter_tag: str | None, favorites: bool) -> None:  # noqa: FBT001
    """List all available sounds in your library.

    Use --tag to filter by tags, --favorites to show only favorites.
    """
    soundboard, _ = get_soundboard()
    metadata = MetadataManager()

    if not soundboard.sounds:
        console.print("[red]✗[/red] No sounds found.")
        console.print(f"[dim]Add audio files to: {soundboard.sounds_dir}[/dim]")
        sys.exit(1)

    # Get all sound names
    sound_names = sorted(soundboard.sounds.keys())

    # Filter by tag if specified
    if filter_tag:
        tags = [t.strip() for t in filter_tag.split(",")]
        tagged_sounds = set(metadata.get_sounds_by_tags(tags))
        sound_names = [s for s in sound_names if s in tagged_sounds]
        if not sound_names:
            console.print(f"[yellow]⚠[/yellow] No sounds found with tag(s): {filter_tag}")
            return

    # Filter by favorites if specified
    if favorites:
        favorite_sounds = set(metadata.get_favorites())
        sound_names = [s for s in sound_names if s in favorite_sounds]
        if not sound_names:
            console.print("[yellow]⚠[/yellow] No favorite sounds yet. Use 'muc favorite <sound>' to add.")
            return

    # Build table with extended columns
    title = "★ Favorite Sounds" if favorites else "Available Sounds"
    table = Table(title=title, show_header=True, header_style="bold cyan")
    table.add_column("#", style="dim", width=4, justify="right")
    table.add_column("Sound Name", style="white")
    table.add_column("Vol", style="cyan", justify="center", width=5)
    table.add_column("Tags", style="blue", max_width=20)
    table.add_column("Hotkey", style="green", justify="center", width=10)
    table.add_column("Plays", style="dim", justify="right", width=6)

    # Setup hotkeys to show in table
    soundboard.setup_hotkeys()

    for idx, name in enumerate(sound_names, 1):
        meta = metadata.get_metadata(name)

        # Volume indicator
        vol_display = f"{int(meta.volume * 100)}%"

        # Tags
        tags_str = ", ".join(meta.tags[:3]) if meta.tags else "-"
        if len(meta.tags) > 3:
            tags_str += "..."

        # Hotkey
        hotkey = next((k for k, v in soundboard.hotkeys.items() if v == name), None)
        hotkey_display = hotkey.upper() if hotkey else "-"

        # Favorite indicator
        fav_indicator = "★ " if meta.favorite else ""
        name_display = f"{fav_indicator}{name}"

        table.add_row(
            str(idx),
            name_display,
            vol_display,
            tags_str,
            hotkey_display,
            str(meta.play_count),
        )

    console.print(table)


@cli.command()
def hotkeys() -> None:
    """Show all configured hotkey bindings."""
    soundboard, _ = get_soundboard()

    if not soundboard.sounds:
        console.print("[red]✗[/red] No sounds found.")
        sys.exit(1)

    soundboard.setup_hotkeys()
    soundboard.list_hotkeys()


# ─────────────────────────────────────────────────────────────────────────────
# Tag Commands
# ─────────────────────────────────────────────────────────────────────────────


@cli.command()
@click.argument("sound_name")
@click.argument("tags", nargs=-1, required=True)
def tag(sound_name: str, tags: tuple[str, ...]) -> None:
    """Add tags to a sound.

    Example: muc tag airhorn meme loud effect
    """
    soundboard, _ = get_soundboard()
    metadata = MetadataManager()

    if sound_name not in soundboard.sounds:
        console.print(f"[red]✗[/red] Sound '{sound_name}' not found")
        sys.exit(1)

    added = [tag_name for tag_name in tags if metadata.add_tag(sound_name, tag_name)]

    if added:
        console.print(f"[green]✓[/green] Added tags to '{sound_name}': {', '.join(added)}")
    else:
        console.print(f"[yellow]⚠[/yellow] All tags already exist on '{sound_name}'")


@cli.command()
@click.argument("sound_name")
@click.argument("tags", nargs=-1, required=True)
def untag(sound_name: str, tags: tuple[str, ...]) -> None:
    """Remove tags from a sound.

    Example: muc untag airhorn loud
    """
    soundboard, _ = get_soundboard()
    metadata = MetadataManager()

    if sound_name not in soundboard.sounds:
        console.print(f"[red]✗[/red] Sound '{sound_name}' not found")
        sys.exit(1)

    removed = [tag_name for tag_name in tags if metadata.remove_tag(sound_name, tag_name)]

    if removed:
        console.print(f"[green]✓[/green] Removed tags from '{sound_name}': {', '.join(removed)}")
    else:
        console.print(f"[yellow]⚠[/yellow] None of the specified tags were on '{sound_name}'")


@cli.command()
def tags() -> None:
    """List all tags with their usage counts."""
    metadata = MetadataManager()
    tag_counts = metadata.get_all_tags_with_counts()

    if not tag_counts:
        console.print("[yellow]⚠[/yellow] No tags found. Use 'muc tag <sound> <tags>' to add tags.")
        return

    table = Table(title="Tags", show_header=True, header_style="bold cyan")
    table.add_column("Tag", style="blue")
    table.add_column("Sounds", style="white", justify="right")

    for tag_name, count in sorted(tag_counts.items()):
        table.add_row(tag_name, str(count))

    console.print(table)


# ─────────────────────────────────────────────────────────────────────────────
# Favorites Commands
# ─────────────────────────────────────────────────────────────────────────────


@cli.command()
@click.argument("sound_name")
@click.option("--on", "set_on", is_flag=True, help="Set as favorite")
@click.option("--off", "set_off", is_flag=True, help="Remove from favorites")
def favorite(sound_name: str, set_on: bool, set_off: bool) -> None:  # noqa: FBT001
    """Toggle or set favorite status for a sound.

    Examples:
        muc favorite airhorn          # Toggle
        muc favorite airhorn --on     # Add to favorites
        muc favorite airhorn --off    # Remove from favorites

    """
    soundboard, _ = get_soundboard()
    metadata = MetadataManager()

    if sound_name not in soundboard.sounds:
        console.print(f"[red]✗[/red] Sound '{sound_name}' not found")
        sys.exit(1)

    if set_on:
        metadata.set_favorite(sound_name, is_favorite=True)
        is_fav = True
    elif set_off:
        metadata.set_favorite(sound_name, is_favorite=False)
        is_fav = False
    else:
        is_fav = metadata.toggle_favorite(sound_name)

    status = "[yellow]★[/yellow] Favorite" if is_fav else "Not favorite"
    console.print(f"[green]✓[/green] '{sound_name}' is now: {status}")


@cli.command()
def favorites() -> None:
    """List all favorite sounds."""
    soundboard, _ = get_soundboard()
    metadata = MetadataManager()

    favorites_list = [name for name in soundboard.sounds if metadata.get_metadata(name).favorite]

    if not favorites_list:
        console.print("[yellow]⚠[/yellow] No favorites yet. Use 'muc favorite <sound>' to add.")
        return

    soundboard.setup_hotkeys()

    table = Table(title="★ Favorite Sounds", show_header=True, header_style="bold yellow")
    table.add_column("#", style="dim", width=4)
    table.add_column("Sound Name", style="white")
    table.add_column("Hotkey", style="green")

    for idx, name in enumerate(sorted(favorites_list), 1):
        hotkey = next((k for k, v in soundboard.hotkeys.items() if v == name), "-")
        table.add_row(str(idx), name, hotkey.upper() if hotkey != "-" else "-")

    console.print(table)


# ─────────────────────────────────────────────────────────────────────────────
# Per-Sound Volume and Info Commands
# ─────────────────────────────────────────────────────────────────────────────


@cli.command(name="sound-volume")
@click.argument("sound_name")
@click.argument("level", type=click.FloatRange(0.0, 2.0), required=False)
def sound_volume(sound_name: str, level: float | None) -> None:
    """Set or display volume for a specific sound.

    Volume range: 0.0 (mute) to 2.0 (200%).
    Final volume = sound_volume x global_volume

    Examples:
        muc sound-volume airhorn 0.5   # Set to 50%
        muc sound-volume airhorn       # Show current

    """
    soundboard, _ = get_soundboard()
    metadata = MetadataManager()

    if sound_name not in soundboard.sounds:
        console.print(f"[red]✗[/red] Sound '{sound_name}' not found")
        sys.exit(1)

    meta = metadata.get_metadata(sound_name)

    if level is None:
        percentage = int(meta.volume * 100)
        console.print(f"[cyan]Volume for '{sound_name}':[/cyan] {percentage}%")
    else:
        metadata.set_volume(sound_name, level)
        percentage = int(level * 100)
        console.print(f"[green]✓[/green] Volume for '{sound_name}' set to {percentage}%")


@cli.command()
@click.argument("sound_name")
@click.option("--preview", "-p", is_flag=True, help="Play first 3 seconds")
def info(sound_name: str, preview: bool) -> None:  # noqa: FBT001
    """Show detailed information about a sound.

    Example: muc info airhorn
    """
    soundboard, _ = get_soundboard()
    metadata = MetadataManager()

    if sound_name not in soundboard.sounds:
        console.print(f"[red]✗[/red] Sound '{sound_name}' not found")
        sys.exit(1)

    audio_path = soundboard.sounds[sound_name]
    meta = metadata.get_metadata(sound_name)

    # Get audio file info
    try:
        file_info = validate_audio_file(audio_path)
    except MUCError as e:
        console.print(f"[red]✗[/red] Cannot read file: {e.message}")
        sys.exit(1)

    # Format duration
    duration_mins = int(file_info.duration // 60)
    duration_secs = file_info.duration % 60
    duration_str = f"{duration_mins}:{duration_secs:05.2f}"

    # File size
    file_size = audio_path.stat().st_size
    size_str = f"{file_size / (1024 * 1024):.1f} MB" if file_size > 1024 * 1024 else f"{file_size / 1024:.1f} KB"

    # Last played formatting
    last_played_str = meta.last_played.strftime("%Y-%m-%d %H:%M") if meta.last_played else "Never"

    # Build info panel
    info_text = f"""[bold cyan]{sound_name}[/bold cyan]

[bold]File Information[/bold]
├── Path: {audio_path}
├── Format: {file_info.format}
├── Size: {size_str}
├── Duration: {duration_str}
├── Sample Rate: {file_info.sample_rate} Hz
└── Channels: {file_info.channels} ({"Stereo" if file_info.channels >= 2 else "Mono"})

[bold]Metadata[/bold]
├── Tags: {", ".join(meta.tags) if meta.tags else "None"}
├── Volume: {int(meta.volume * 100)}%
├── Favorite: {"Yes ★" if meta.favorite else "No"}
├── Play Count: {meta.play_count}
└── Last Played: {last_played_str}"""

    console.print(Panel(info_text, title=f"Sound Info: {sound_name}", border_style="cyan"))

    if preview:
        console.print("\n[dim]Playing preview...[/dim]")
        soundboard.play_sound(sound_name, blocking=True)


# ─────────────────────────────────────────────────────────────────────────────
# Custom Hotkey Commands
# ─────────────────────────────────────────────────────────────────────────────


@cli.command()
@click.argument("hotkey")
@click.argument("sound_name")
def bind(hotkey: str, sound_name: str) -> None:
    """Bind a hotkey to a sound.

    Hotkey format: <modifier>+<modifier>+<key>

    Examples:
        muc bind f1 airhorn
        muc bind "<ctrl>+<shift>+a" applause
        muc bind "<alt>+1" explosion

    Supported modifiers: ctrl, alt, shift, cmd (Mac)
    Supported keys: a-z, 0-9, f1-f12, space, etc.

    """
    soundboard, _ = get_soundboard()
    hotkey_mgr = HotkeyManager()

    if sound_name not in soundboard.sounds:
        console.print(f"[red]✗[/red] Sound '{sound_name}' not found")
        sys.exit(1)

    # Normalize hotkey format
    normalized = hotkey_mgr.normalize_hotkey(hotkey)

    if not normalized:
        console.print(f"[red]✗[/red] Invalid hotkey format: {hotkey}")
        console.print("[dim]Use format like: f1, <ctrl>+a, <ctrl>+<shift>+1[/dim]")
        sys.exit(1)

    # Check for conflicts
    existing = hotkey_mgr.get_binding(normalized)
    if existing and existing != sound_name:
        console.print(f"[yellow]⚠[/yellow] Hotkey {normalized} is bound to '{existing}'")
        if not click.confirm("Override?"):
            return

    hotkey_mgr.bind(normalized, sound_name)
    console.print(f"[green]✓[/green] Bound {normalized.upper()} → {sound_name}")


@cli.command()
@click.argument("hotkey_or_sound")
def unbind(hotkey_or_sound: str) -> None:
    """Unbind a hotkey or all hotkeys for a sound.

    Examples:
        muc unbind f1                    # Unbind F1 key
        muc unbind airhorn               # Unbind all keys for 'airhorn'

    """
    soundboard, _ = get_soundboard()
    hotkey_mgr = HotkeyManager()

    # Check if it's a sound name
    if hotkey_or_sound in soundboard.sounds:
        count = hotkey_mgr.unbind_sound(hotkey_or_sound)
        if count > 0:
            console.print(f"[green]✓[/green] Unbound {count} hotkey(s) from '{hotkey_or_sound}'")
        else:
            console.print(f"[yellow]⚠[/yellow] No hotkeys bound to '{hotkey_or_sound}'")
    else:
        # Treat as hotkey
        normalized = hotkey_mgr.normalize_hotkey(hotkey_or_sound)
        if normalized and hotkey_mgr.unbind(normalized):
            console.print(f"[green]✓[/green] Unbound {normalized.upper()}")
        else:
            console.print(f"[yellow]⚠[/yellow] No binding found for {hotkey_or_sound}")


@cli.command(name="hotkeys-reset")
def hotkeys_reset() -> None:
    """Clear all custom hotkey bindings."""
    hotkey_mgr = HotkeyManager()
    count = hotkey_mgr.clear_all()
    console.print(f"[green]✓[/green] Cleared {count} custom hotkey binding(s)")


# ─────────────────────────────────────────────────────────────────────────────
# Queue Commands
# ─────────────────────────────────────────────────────────────────────────────


@cli.group()
def queue() -> None:
    """Manage the sound playback queue."""


@queue.command(name="add")
@click.argument("sound_names", nargs=-1, required=True)
def queue_add(sound_names: tuple[str, ...]) -> None:
    """Add sounds to the queue.

    Example: muc queue add airhorn rickroll explosion
    """
    soundboard, _ = get_soundboard()
    queue_mgr = QueueManager()

    # Validate sound names
    valid_sounds = []
    for name in sound_names:
        if name in soundboard.sounds:
            valid_sounds.append(name)
        else:
            console.print(f"[yellow]⚠[/yellow] Sound '{name}' not found, skipping")

    if valid_sounds:
        queue_mgr.add(*valid_sounds)
        console.print(f"[green]✓[/green] Added {len(valid_sounds)} sound(s) to queue")
        console.print(f"[dim]Queue size: {queue_mgr.size()}[/dim]")
    else:
        console.print("[red]✗[/red] No valid sounds to add")


@queue.command(name="show")
def queue_show() -> None:
    """Display the current queue."""
    queue_mgr = QueueManager()
    items = queue_mgr.peek()

    if not items:
        console.print("[yellow]⚠[/yellow] Queue is empty")
        return

    table = Table(title="Sound Queue", show_header=True, header_style="bold cyan")
    table.add_column("#", style="dim", width=4, justify="right")
    table.add_column("Sound Name", style="white")

    for idx, name in enumerate(items, 1):
        table.add_row(str(idx), name)

    console.print(table)


@queue.command(name="clear")
def queue_clear() -> None:
    """Clear the queue."""
    queue_mgr = QueueManager()
    count = queue_mgr.clear()
    console.print(f"[green]✓[/green] Cleared {count} sound(s) from queue")


@queue.command(name="play")
def queue_play() -> None:
    """Play all sounds in the queue sequentially."""
    soundboard, _ = get_soundboard()
    queue_mgr = QueueManager()

    if queue_mgr.is_empty():
        console.print("[yellow]⚠[/yellow] Queue is empty")
        return

    total = queue_mgr.size()
    console.print(f"\n[bold cyan]Playing {total} sounds from queue...[/bold cyan]")
    console.print("[dim]Press Ctrl+C to stop[/dim]\n")

    try:
        idx = 1
        while True:
            sound_name = queue_mgr.next()
            if sound_name is None:
                break
            console.print(f"[cyan][{idx}/{total}][/cyan] ", end="")
            soundboard.play_sound(sound_name, blocking=True)
            idx += 1
    except KeyboardInterrupt:
        console.print("\n[yellow]⏸[/yellow] Queue playback interrupted.")
        soundboard.stop_sound()


@queue.command(name="skip")
def queue_skip() -> None:
    """Skip the next sound in the queue."""
    queue_mgr = QueueManager()
    skipped = queue_mgr.next()
    if skipped:
        console.print(f"[green]✓[/green] Skipped: {skipped}")
        console.print(f"[dim]Remaining: {queue_mgr.size()}[/dim]")
    else:
        console.print("[yellow]⚠[/yellow] Queue is empty")


@queue.command(name="shuffle")
def queue_shuffle() -> None:
    """Shuffle the queue."""
    queue_mgr = QueueManager()
    if queue_mgr.is_empty():
        console.print("[yellow]⚠[/yellow] Queue is empty")
        return
    queue_mgr.shuffle()
    console.print("[green]✓[/green] Queue shuffled")


# ─────────────────────────────────────────────────────────────────────────────
# Playlist Commands
# ─────────────────────────────────────────────────────────────────────────────


@cli.group()
def playlist() -> None:
    """Manage saved playlists."""


@playlist.command(name="save")
@click.argument("name")
def playlist_save(name: str) -> None:
    """Save the current queue as a playlist.

    Example: muc playlist save gaming
    """
    queue_mgr = QueueManager()
    if queue_mgr.save_playlist(name):
        console.print(f"[green]✓[/green] Saved playlist '{name}' ({queue_mgr.size()} sounds)")
    else:
        console.print("[red]✗[/red] Cannot save empty queue as playlist")


@playlist.command(name="load")
@click.argument("name")
@click.option("--append", "-a", is_flag=True, help="Append to current queue instead of replacing")
def playlist_load(name: str, append: bool) -> None:  # noqa: FBT001
    """Load a playlist into the queue.

    Example: muc playlist load gaming
    """
    queue_mgr = QueueManager()
    if queue_mgr.load_playlist(name, append=append):
        action = "Appended" if append else "Loaded"
        console.print(f"[green]✓[/green] {action} playlist '{name}' ({queue_mgr.size()} sounds in queue)")
    else:
        console.print(f"[red]✗[/red] Playlist '{name}' not found")


@playlist.command(name="list")
def playlist_list() -> None:
    """Show all saved playlists."""
    queue_mgr = QueueManager()
    playlists = queue_mgr.list_playlists()

    if not playlists:
        console.print("[yellow]⚠[/yellow] No playlists saved. Use 'muc playlist save <name>' to create one.")
        return

    table = Table(title="Saved Playlists", show_header=True, header_style="bold cyan")
    table.add_column("Name", style="white")
    table.add_column("Sounds", style="cyan", justify="right")

    for name, count in sorted(playlists.items()):
        table.add_row(name, str(count))

    console.print(table)


@playlist.command(name="delete")
@click.argument("name")
def playlist_delete(name: str) -> None:
    """Delete a saved playlist.

    Example: muc playlist delete gaming
    """
    queue_mgr = QueueManager()
    if queue_mgr.delete_playlist(name):
        console.print(f"[green]✓[/green] Deleted playlist '{name}'")
    else:
        console.print(f"[red]✗[/red] Playlist '{name}' not found")


@playlist.command(name="show")
@click.argument("name")
def playlist_show(name: str) -> None:
    """Show contents of a playlist.

    Example: muc playlist show gaming
    """
    queue_mgr = QueueManager()
    sounds = queue_mgr.get_playlist(name)

    if sounds is None:
        console.print(f"[red]✗[/red] Playlist '{name}' not found")
        return

    table = Table(title=f"Playlist: {name}", show_header=True, header_style="bold cyan")
    table.add_column("#", style="dim", width=4, justify="right")
    table.add_column("Sound Name", style="white")

    for idx, sound_name in enumerate(sounds, 1):
        table.add_row(str(idx), sound_name)

    console.print(table)


@cli.command()
def listen() -> None:
    """Start listening for hotkeys.

    Activates the soundboard to respond to hotkey presses.
    Uses both default (F1-F10) and custom hotkey bindings.
    Press ESC to stop listening.
    """
    soundboard, _ = get_soundboard()

    if not soundboard.sounds:
        console.print("[red]✗[/red] No sounds found.")
        console.print(f"[dim]Add audio files to: {soundboard.sounds_dir}[/dim]")
        sys.exit(1)

    soundboard.setup_hotkeys()
    soundboard.list_hotkeys()

    console.print("\n[bold green]Soundboard Active![/bold green]")
    console.print("[dim]Press ESC to stop, or Ctrl+C to exit.[/dim]\n")

    soundboard.start_listening()

    # Wait for ESC key
    def on_press(key: keyboard.Key) -> bool | None:
        if key == keyboard.Key.esc:
            return False
        return None

    try:
        with keyboard.Listener(on_press=on_press) as listener:  # pyright: ignore[reportArgumentType]
            listener.join()
    except KeyboardInterrupt:
        pass
    finally:
        soundboard.stop_listening()
        console.print("\n[yellow]Stopped listening.[/yellow]")


@cli.command()
def stop() -> None:
    """Stop any currently playing sound."""
    soundboard, _ = get_soundboard()
    soundboard.stop_sound()
    console.print("[yellow]■[/yellow] Stopped current sound.")


@cli.command()
def validate() -> None:
    """Validate all audio files in your library.

    Checks each audio file for corruption or format issues.
    """
    config = Config()
    sounds_dir = config.sounds_dir

    if not sounds_dir.exists():
        console.print(f"[red]✗[/red] Sounds directory not found: {sounds_dir}")
        sys.exit(1)

    audio_files = [f for f in sounds_dir.rglob("*") if f.suffix.lower() in SUPPORTED_FORMATS]

    if not audio_files:
        console.print("[yellow]⚠[/yellow] No audio files found to validate")
        return

    console.print(f"\n[cyan]Validating {len(audio_files)} audio files...[/cyan]\n")

    valid_count = 0
    invalid_files: list[tuple[str, str]] = []

    for audio_file in sorted(audio_files):
        info = validate_audio_file_safe(audio_file)

        if info.is_valid:
            console.print(
                f"[green]✓[/green] {audio_file.name} "
                f"[dim]({info.duration:.1f}s, {info.sample_rate}Hz, {info.channels}ch)[/dim]",
            )
            valid_count += 1
        else:
            console.print(f"[red]✗[/red] {audio_file.name}: {info.error}")
            invalid_files.append((audio_file.name, info.error or "Unknown error"))

    console.print(f"\n[bold]Results:[/bold] {valid_count} valid, {len(invalid_files)} invalid")

    if invalid_files:
        console.print("\n[yellow]Invalid files:[/yellow]")
        for name, error in invalid_files:
            console.print(f"  • {name}: [dim]{error}[/dim]")


@cli.command()
@click.argument("level", type=click.FloatRange(0.0, 1.0), required=False)
def volume(level: float | None) -> None:
    """Set or display the playback volume (0.0 to 1.0).

    Examples: mu volume 0.5 (set to 50%), mu volume (show current).
    """
    _, audio_manager = get_soundboard()
    if level is None:
        percentage = int(audio_manager.volume * 100)
        console.print(f"[cyan]Current volume:[/cyan] {percentage}%")
    else:
        audio_manager.set_volume(level)
        config = Config()
        config.volume = audio_manager.volume
        config.save()
        console.print("[green]✓[/green] Volume saved!")


@cli.command()
@click.option("--sequential", is_flag=True, help="Play sounds in alphabetical order instead of random.")
def auto(sequential: bool) -> None:  # noqa: FBT001
    """Play all sounds randomly, one after another.

    Each sound will play completely before the next one starts.
    Press Ctrl+C to stop playback.
    """
    soundboard, _ = get_soundboard()

    if not soundboard.sounds:
        console.print("[red]✗[/red] No sounds found.")
        console.print(f"[dim]Add audio files to: {soundboard.sounds_dir}[/dim]")
        sys.exit(1)

    with contextlib.suppress(KeyboardInterrupt):
        soundboard.play_all_sounds(shuffle=not sequential)


def _handle_play_sound(soundboard: Soundboard) -> None:
    """Handle playing a sound by name."""
    sound_name = click.prompt("Enter sound name")
    soundboard.play_sound(sound_name)


def _handle_hotkey_listener(soundboard: Soundboard) -> None:
    """Handle starting the hotkey listener."""
    console.print("\n[bold green]Listening for hotkeys...[/bold green]")
    console.print("[dim]Press ESC to stop.[/dim]\n")
    soundboard.start_listening()

    def on_press(key: keyboard.Key) -> bool | None:
        if key == keyboard.Key.esc:
            return False
        return None

    with keyboard.Listener(on_press=on_press) as listener:  # pyright: ignore[reportArgumentType]
        listener.join()

    soundboard.stop_listening()
    console.print("[yellow]Stopped listening.[/yellow]")


def _handle_change_device(audio_manager: AudioManager) -> None:
    """Handle changing the output device."""
    audio_manager.print_devices()
    device_id = click.prompt("Enter device ID", type=int)
    if audio_manager.set_output_device(device_id):
        config = Config()
        config.output_device_id = device_id
        config.save()


def _handle_volume(audio_manager: AudioManager) -> None:
    """Handle volume adjustment."""
    percentage = int(audio_manager.volume * 100)
    console.print(f"[cyan]Current volume:[/cyan] {percentage}%")
    volume_input = click.prompt(
        "Enter volume level (0-100)",
        type=click.IntRange(0, 100),
    )
    audio_manager.set_volume(volume_input / 100.0)
    config = Config()
    config.volume = audio_manager.volume
    config.save()


def _show_menu() -> None:
    """Display the interactive menu."""
    console.print("\n[bold cyan]═══ Soundboard Menu ═══[/bold cyan]")
    console.print("1. List all sounds")
    console.print("2. Play sound by name")
    console.print("3. View hotkey bindings")
    console.print("4. Start hotkey listener")
    console.print("5. Stop current sound")
    console.print("6. List audio devices")
    console.print("7. Change output device")
    console.print("8. Adjust volume")
    console.print("9. Auto-play all sounds")
    console.print("0. Exit")


def _handle_auto_play(soundboard: Soundboard) -> None:
    """Handle auto-play all sounds."""
    with contextlib.suppress(KeyboardInterrupt):
        soundboard.play_all_sounds()


@cli.command()
def interactive() -> None:
    """Launch interactive menu mode.

    Provides a text-based menu for exploring and using the soundboard.
    """
    soundboard, audio_manager = get_soundboard()

    if not soundboard.sounds:
        console.print("[red]✗[/red] No sounds found.")
        console.print(f"[dim]Add audio files to: {soundboard.sounds_dir}[/dim]")
        sys.exit(1)

    soundboard.setup_default_hotkeys()

    # Menu action dispatch table (lambdas needed for partial application)
    menu_actions = {
        "1": soundboard.list_sounds,
        "2": lambda: _handle_play_sound(soundboard),
        "3": soundboard.list_hotkeys,
        "4": lambda: _handle_hotkey_listener(soundboard),
        "5": soundboard.stop_sound,
        "6": audio_manager.print_devices,
        "7": lambda: _handle_change_device(audio_manager),
        "8": lambda: _handle_volume(audio_manager),
        "9": lambda: _handle_auto_play(soundboard),
    }

    while True:
        _show_menu()
        choice = click.prompt("\nEnter your choice", type=str).strip()

        if choice == "0":
            console.print("\n[cyan]Goodbye! 👋[/cyan]")
            break

        action = menu_actions.get(choice)
        if action:
            action()
        else:
            console.print("[red]Invalid choice.[/red]")


def main() -> None:
    """Entry point for the CLI."""
    try:
        cli()
    except KeyboardInterrupt:
        console.print("\n[yellow]Interrupted.[/yellow]")
        sys.exit(130)
    except MUCError as e:
        console.print(f"\n[red]✗[/red] {e.message}")
        console.print(f"[dim]💡 {e.suggestion}[/dim]")
        console.print(f"\n[dim]Error code: E{e.code} | Run with --debug for more details[/dim]")
        sys.exit(1)
    except (OSError, RuntimeError) as e:
        console.print(f"[red]Error:[/red] {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()
