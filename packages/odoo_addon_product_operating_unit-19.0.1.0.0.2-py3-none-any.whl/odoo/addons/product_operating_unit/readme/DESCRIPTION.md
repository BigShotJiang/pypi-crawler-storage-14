This module introduces the following features:

- It introduces the operating unit to the product template.
- The operating unit from the user is assigned by default when creating
  a new product template.
- In case of multi-company, no operating unit from another company to
  that assigned to the product can be set for it
- It implements user's security rules.
