# License LGPL-3.0 or later (https://www.gnu.org/licenses/lgpl.html).
from . import product_template
from . import product_category
