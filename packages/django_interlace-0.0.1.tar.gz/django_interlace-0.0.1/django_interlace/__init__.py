"""Django Interlace - Coming soon."""

__version__ = "0.0.1"
