# django-interlace

This is a placeholder package. Full release coming soon.
