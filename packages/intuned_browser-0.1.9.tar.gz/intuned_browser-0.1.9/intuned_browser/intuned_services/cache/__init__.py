from .cache import Cache

cache = Cache()
__all__ = ["cache"]
