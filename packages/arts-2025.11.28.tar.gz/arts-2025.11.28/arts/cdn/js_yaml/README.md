# Markdown CSS

这是 **js-yaml v4.1.1** 的修改版本，用于在网页中解析yaml文档。

# 原项目

本项目修改自：[js-yaml v4.1.1](https://github.com/nodeca/js-yaml/tree/74a01992953302040be3277c08ba214a06f00b87)

原作者：Vitaly Puzrin

原项目使用MIT许可证，原项目许可证副本：

[license.txt](js_yaml_v4.1.1/license.txt)

# 本项目
