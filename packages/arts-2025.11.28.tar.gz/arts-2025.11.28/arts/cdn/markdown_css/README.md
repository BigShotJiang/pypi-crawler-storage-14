# Markdown CSS

这是 **github-markdown-css v5.8.1** 的修改版本，用于在网页中渲染 GitHub 风格的 Markdown。

# 原项目

本项目修改自：[github-markdown-css v5.8.1](https://github.com/sindresorhus/github-markdown-css/tree/e771b613e93f868afd7ce2cdba2a2c7b6c649416)

原作者：Sindre Sorhus

原项目使用MIT许可证，原项目许可证副本：

[license.txt](github_markdown_css_v5.8.1/license.txt)

# 本项目
