"""priorityx: Entity prioritization and escalation detection using GLMM statistical models."""

__version__ = "0.2.6"

# API will be imported

__all__ = ["__version__"]
