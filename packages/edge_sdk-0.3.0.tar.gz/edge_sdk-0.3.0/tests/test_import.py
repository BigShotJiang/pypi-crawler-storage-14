"""Test that the package can be imported."""


def test_import():
    """Test basic package imports."""
    import edge_api
    from edge_api import EdgeAPIClient
    from edge_api.config import EdgeAPIConfig
    from edge_api.exceptions import EdgeAPIError

    assert hasattr(edge_api, "__version__")
    assert EdgeAPIClient is not None
    assert EdgeAPIConfig is not None
    assert EdgeAPIError is not None