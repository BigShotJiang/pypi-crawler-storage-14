"""Configuration for Edge API SDK."""

import os
from typing import Optional
from dotenv import load_dotenv

load_dotenv()


class EdgeAPIConfig:
    """Configuration manager for Edge API SDK."""

    # Default timeout optimized for large data queries (in seconds)
    DEFAULT_TIMEOUT = 600.0           # 10 minutes for large dataset queries

    def __init__(
        self,
        base_url: Optional[str] = None,
        api_key: Optional[str] = None,
        environment: str = "production",
        timeout: float = DEFAULT_TIMEOUT,
    ):
        self.base_url = base_url or os.getenv("EDGE_API_BASE_URL", "https://edge-api-730192956959.us-east4.run.app")
        self.api_key = api_key or os.getenv("EDGE_API_KEY")
        self.environment = environment
        self.timeout = timeout

        # Remove trailing slash from base URL
        if self.base_url.endswith("/"):
            self.base_url = self.base_url[:-1]

    @property
    def api_url(self) -> str:
        """Get the full API URL."""
        return f"{self.base_url}/v1/api"

    @property
    def headers(self) -> dict:
        """Get default headers for API requests."""
        headers = {
            "Content-Type": "application/json",
            "User-Agent": "edge-api-sdk/0.1.0",
        }
        if self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"
        return headers

    @property
    def is_configured(self) -> bool:
        """Check if the configuration is valid."""
        return bool(self.base_url)