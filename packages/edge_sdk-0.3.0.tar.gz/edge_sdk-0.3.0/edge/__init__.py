"""
Edge API - Python SDK for accessing Edge's agricultural commodity data.

This SDK provides easy access to:
- CME timeseries data
- USDA data (AMS, FAS, GATS, NASS)
- CFTC reports
- Weather/NOAA data
- Historical and current market data
"""

from .version import __version__
from .client.edge_client import Edge
from .exceptions import EdgeAPIError, ConfigurationError, DataNotFoundError

__all__ = [
    "__version__",
    "Edge",
    "EdgeAPIError",
    "ConfigurationError",
    "DataNotFoundError",
]