"""Custom exceptions for Edge API SDK."""


class EdgeAPIError(Exception):
    """Base exception for all Edge API errors."""
    pass


class ConfigurationError(EdgeAPIError):
    """Raised when there's a configuration issue."""
    pass


class DataNotFoundError(EdgeAPIError):
    """Raised when requested data is not found."""
    pass


class AuthenticationError(EdgeAPIError):
    """Raised when authentication fails."""
    pass


class DatabaseConnectionError(EdgeAPIError):
    """Raised when database connection fails."""
    pass


class InvalidParameterError(EdgeAPIError):
    """Raised when invalid parameters are provided."""
    pass