"""
Integration tests for spark-jdbc-ingestor using SQLite JDBC.

Note: Some tests are marked as xfail because SQLite has limitations
that don't apply to production databases (PostgreSQL, MySQL, etc.).
"""

import pytest


class TestFromTable:
    """Tests for from_table() functionality."""

    def test_from_table_loads_all_data(self, ingestor):
        """Test that from_table loads all rows from a table."""
        result = ingestor.from_table("employees").load()
        df = result.df

        assert df.count() == 10
        assert "id" in df.columns
        assert "name" in df.columns
        assert "salary" in df.columns

    def test_from_table_preserves_schema(self, ingestor):
        """Test that from_table preserves the expected column types."""
        result = ingestor.from_table("employees").load()
        df = result.df

        schema_dict = {field.name: field.dataType.simpleString() for field in df.schema.fields}

        assert "id" in schema_dict
        assert "name" in schema_dict
        assert "salary" in schema_dict

    def test_from_table_different_table(self, ingestor):
        """Test from_table works with different tables."""
        result = ingestor.from_table("products").load()
        df = result.df

        assert df.count() == 5
        assert "price" in df.columns
        assert "quantity" in df.columns


class TestFromQuery:
    """Tests for from_query() functionality."""

    def test_from_query_with_where_clause(self, ingestor):
        """Test from_query with a WHERE clause."""
        query = "(SELECT * FROM employees WHERE department = 'Engineering') as eng"
        result = ingestor.from_query(query).load()
        df = result.df

        assert df.count() == 5  # Alice, Bob, Diana, Grace, Jack
        for row in df.collect():
            assert row["department"] == "Engineering"

    def test_from_query_with_aggregation(self, ingestor):
        """Test from_query with aggregation."""
        query = "(SELECT department, COUNT(*) as emp_count, AVG(salary) as avg_salary FROM employees GROUP BY department) as dept_stats"
        result = ingestor.from_query(query).load()
        df = result.df

        assert df.count() == 3  # Engineering, Sales, Marketing
        assert "emp_count" in df.columns
        assert "avg_salary" in df.columns

    def test_from_query_with_join(self, ingestor, sqlite_db):
        """Test from_query with a simple select (SQLite join syntax)."""
        query = "(SELECT id, name, salary FROM employees WHERE salary > 80000) as high_earners"
        result = ingestor.from_query(query).load()
        df = result.df

        for row in df.collect():
            assert row["salary"] > 80000


class TestAddFilter:
    """Tests for add_filter() functionality."""

    def test_single_filter(self, ingestor):
        """Test adding a single filter."""
        result = ingestor.from_table("employees").add_filter("salary > 80000").load()
        df = result.df

        for row in df.collect():
            assert row["salary"] > 80000

    def test_multiple_filters(self, ingestor):
        """Test adding multiple filters (AND condition)."""
        result = (
            ingestor.from_table("employees")
            .add_filter("salary >= 70000")
            .add_filter("department = 'Engineering'")
            .load()
        )
        df = result.df

        for row in df.collect():
            assert row["salary"] >= 70000
            assert row["department"] == "Engineering"

    def test_filter_with_string_comparison(self, ingestor):
        """Test filter with string comparison."""
        result = ingestor.from_table("employees").add_filter("name = 'Alice'").load()
        df = result.df

        assert df.count() == 1
        assert df.first()["name"] == "Alice"


class TestPartitioning:
    """Tests for load() with partitioning options."""

    def test_load_with_partition_column(self, ingestor):
        """Test loading with automatic bound detection."""
        result = ingestor.from_table("employees").load(
            partition_column="id",
            num_partitions=2
        )
        df = result.df

        # Should still load all data
        assert df.count() == 10

    def test_load_with_explicit_bounds(self, ingestor):
        """Test loading with explicit lower and upper bounds."""
        result = ingestor.from_table("employees").load(
            partition_column="id",
            num_partitions=4,
            lower_bound=1,
            upper_bound=10
        )
        df = result.df

        assert df.count() == 10

    def test_load_without_partitioning(self, ingestor):
        """Test loading without partitioning (single partition)."""
        result = ingestor.from_table("employees").load()
        df = result.df

        assert df.count() == 10


class TestExecute:
    """Tests for execute() functionality."""

    def test_execute_simple_query(self, ingestor):
        """Test executing a simple SQL query."""
        query = "(SELECT COUNT(*) as total FROM employees) as count_query"
        df = ingestor.execute(query)

        assert df.first()["total"] == 10

    def test_execute_with_calculation(self, ingestor):
        """Test executing a query with calculations."""
        query = "(SELECT MAX(salary) - MIN(salary) as salary_range FROM employees) as range_query"
        df = ingestor.execute(query)

        result = df.first()["salary_range"]
        assert result == 95000.0 - 60000.0  # Grace - Henry


class TestAnalyze:
    """Tests for analyze() functionality."""

    def test_analyze_returns_statistics(self, ingestor):
        """Test that analyze returns expected statistics columns."""
        result = ingestor.from_table("employees").analyze(sample=10)

        expected_columns = ["ranking", "field_name", "min", "max", "avg", "stddev", "count", "count_distinct", "uniformity", "completeness"]
        for col in expected_columns:
            assert col in result.columns

    def test_analyze_includes_numeric_fields(self, ingestor):
        """Test that analyze includes numeric fields."""
        result = ingestor.from_table("employees").analyze(sample=10)

        field_names = [row["field_name"] for row in result.collect()]
        assert "id" in field_names
        assert "salary" in field_names

    def test_analyze_calculates_uniformity(self, ingestor):
        """Test that uniformity is calculated correctly."""
        result = ingestor.from_table("employees").analyze(sample=10)

        # id column should have uniformity = 1.0 (all unique)
        id_row = result.filter(result.field_name == "id").first()
        assert id_row is not None
        assert id_row["uniformity"] == 1.0  # 10 distinct / 10 sample


class TestToTable:
    """Tests for append() and overwrite() functionality."""

    def test_append_to_new_table(self, ingestor, spark):
        """Test appending data to a new Spark table."""
        table_name = "test_employees_append"

        result = ingestor.from_table("employees").load()
        result.append(table_name)

        # Verify data was written
        written_df = spark.read.table(table_name)
        assert written_df.count() == 10

    def test_overwrite_table(self, ingestor, spark):
        """Test overwriting a Spark table."""
        table_name = "test_employees_overwrite"

        # First write
        result1 = ingestor.from_table("employees").load()
        result1.overwrite(table_name)

        # Overwrite with filtered data
        result2 = ingestor.from_table("employees").add_filter("department = 'Engineering'").load()
        result2.overwrite(table_name)

        # Verify only Engineering employees remain
        written_df = spark.read.table(table_name)
        assert written_df.count() < 10
        for row in written_df.collect():
            assert row["department"] == "Engineering"


class TestEdgeCases:
    """Tests for edge cases and error handling."""

    def test_empty_result_with_filter(self, ingestor):
        """Test handling of empty results from filters."""
        result = ingestor.from_table("employees").add_filter("salary > 1000000").load()
        df = result.df

        assert df.count() == 0

    def test_special_characters_in_filter(self, ingestor):
        """Test filter with special characters (escaped properly)."""
        # This tests that the SQL is constructed correctly
        result = ingestor.from_table("employees").add_filter("department = 'Engineering'").load()
        df = result.df

        assert df.count() > 0

    def test_chained_operations_with_partitioning(self, ingestor):
        """Test chaining multiple operations with partitioning."""
        result = (
            ingestor.from_table("employees")
            .add_filter("salary >= 70000")
            .add_filter("id <= 8")
            .load(partition_column="id", num_partitions=2)
        )
        df = result.df

        for row in df.collect():
            assert row["salary"] >= 70000
            assert row["id"] <= 8

    def test_chained_operations(self, ingestor):
        """Test chaining multiple operations together without partitioning."""
        result = (
            ingestor.from_table("employees")
            .add_filter("salary >= 70000")
            .add_filter("id <= 8")
            .load()
        )
        df = result.df

        for row in df.collect():
            assert row["salary"] >= 70000
            assert row["id"] <= 8


class TestGetLastValue:
    """Tests for get_last_value() - reads max value from a Spark table.
    
    Note: get_last_value() reads from a Spark table (not JDBC source),
    so we need to create Spark tables first for testing.
    """

    def test_get_last_value_numeric(self, ingestor, spark):
        """Test getting the last (max) value of a numeric column."""
        # First, load data into a Spark table
        table_name = "test_last_value_numeric"
        result = ingestor.from_table("employees").load()
        result.overwrite(table_name)

        # Now test get_last_value
        last_id = ingestor.get_last_value(table_name, "id")

        assert last_id == 10  # Max id in employees table

    def test_get_last_value_salary(self, ingestor, spark):
        """Test getting the last (max) value of a salary column."""
        table_name = "test_last_value_salary"
        result = ingestor.from_table("employees").load()
        result.overwrite(table_name)

        last_salary = ingestor.get_last_value(table_name, "salary")

        assert last_salary == 95000.0  # Grace has highest salary

    def test_get_last_value_string(self, ingestor, spark):
        """Test getting the last (max) value of a string column."""
        table_name = "test_last_value_string"
        result = ingestor.from_table("employees").load()
        result.overwrite(table_name)

        last_name = ingestor.get_last_value(table_name, "name")

        # Max string value alphabetically
        assert last_name == "Jack"  # 'Jack' is last alphabetically among our names

    def test_get_last_value_with_default_on_empty_table(self, ingestor, spark):
        """Test that default_value is returned when table is empty."""
        from pyspark.sql.types import StructType, StructField, IntegerType

        # Create an empty table
        table_name = "test_last_value_empty"
        empty_schema = StructType([StructField("id", IntegerType(), True)])
        empty_df = spark.createDataFrame([], empty_schema)
        empty_df.write.mode("overwrite").saveAsTable(table_name)

        # Test with default value
        default_value = 0
        last_value = ingestor.get_last_value(table_name, "id", default_value)

        assert last_value == default_value

    def test_get_last_value_default_none(self, ingestor, spark):
        """Test that None is returned when table is empty and no default provided."""
        from pyspark.sql.types import StructType, StructField, IntegerType

        # Create an empty table
        table_name = "test_last_value_none"
        empty_schema = StructType([StructField("id", IntegerType(), True)])
        empty_df = spark.createDataFrame([], empty_schema)
        empty_df.write.mode("overwrite").saveAsTable(table_name)

        # Test without default value
        last_value = ingestor.get_last_value(table_name, "id")

        assert last_value is None


class TestWithLastValue:
    """Tests for with_last_value() - incremental ingestion filter.
    
    This method reads the max value from a Spark table and adds a filter
    to only load records greater than that value from the JDBC source.
    """

    def test_with_last_value_numeric_filter(self, ingestor, spark):
        """Test incremental filter with numeric column."""
        # Create a Spark table with some employees (simulating previously loaded data)
        table_name = "test_incremental_numeric"
        
        # Load only first 5 employees to simulate previous load
        result = ingestor.from_table("employees").add_filter("id <= 5").load()
        result.overwrite(table_name)

        # Now use with_last_value to get only new records (id > 5)
        incremental_result = (
            ingestor.from_table("employees")
            .with_last_value(table_name, "id")
            .load()
        )
        df = incremental_result.df

        # Should only get employees with id > 5
        assert df.count() == 5  # ids 6, 7, 8, 9, 10
        for row in df.collect():
            assert row["id"] > 5

    def test_with_last_value_with_default(self, ingestor, spark):
        """Test incremental filter with default value when table is empty."""
        from pyspark.sql.types import StructType, StructField, IntegerType

        # Create an empty table
        table_name = "test_incremental_default"
        empty_schema = StructType([StructField("id", IntegerType(), True)])
        empty_df = spark.createDataFrame([], empty_schema)
        empty_df.write.mode("overwrite").saveAsTable(table_name)

        # Use with_last_value with default_value = 0
        # This should add filter "id > 0", getting all records
        incremental_result = (
            ingestor.from_table("employees")
            .with_last_value(table_name, "id", default_value=0)
            .load()
        )
        df = incremental_result.df

        # Should get all 10 employees (all have id > 0)
        assert df.count() == 10

    def test_with_last_value_combined_with_other_filters(self, ingestor, spark):
        """Test with_last_value combined with other filters."""
        # Create a Spark table with some employees
        table_name = "test_incremental_combined"
        result = ingestor.from_table("employees").add_filter("id <= 3").load()
        result.overwrite(table_name)

        # Use with_last_value AND another filter
        incremental_result = (
            ingestor.from_table("employees")
            .with_last_value(table_name, "id")
            .add_filter("department = 'Engineering'")
            .load()
        )
        df = incremental_result.df

        # Should only get Engineering employees with id > 3
        for row in df.collect():
            assert row["id"] > 3
            assert row["department"] == "Engineering"

    def test_with_last_value_salary_filter(self, ingestor, spark):
        """Test incremental filter with salary column (float)."""
        # Create a table with low-salary employees
        table_name = "test_incremental_salary"
        result = ingestor.from_table("employees").add_filter("salary < 80000").load()
        result.overwrite(table_name)

        # Get the max salary from the table
        max_salary = ingestor.get_last_value(table_name, "salary")

        # Now use with_last_value to get higher salary employees
        incremental_result = (
            ingestor.from_table("employees")
            .with_last_value(table_name, "salary")
            .load()
        )
        df = incremental_result.df

        # All returned employees should have salary > max_salary
        for row in df.collect():
            assert row["salary"] > max_salary

