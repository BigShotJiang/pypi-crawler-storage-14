"""Interface for the `python -m scicookie`."""

from scicookie.cli import app

if __name__ == "__main__":
    app()
