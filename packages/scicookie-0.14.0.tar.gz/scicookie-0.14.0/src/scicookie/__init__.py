"""SciCookie is a wrap around cookiecutter with an improved TUI."""
