"""Package for a set of useful tools."""
