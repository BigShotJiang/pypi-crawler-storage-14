API references
==============

.. automodule:: {{cookiecutter.package_slug}}
    :members:

.. automodule:: {{cookiecutter.package_slug}}.{{cookiecutter.package_slug}}
    :members:
