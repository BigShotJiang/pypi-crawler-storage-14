Welcome to {{ cookiecutter.project_name }}'s documentation!
{{ "=" * ((cookiecutter.project_name|length) + 28) }}


.. toctree::
   :maxdepth: 2
   :caption: Contents:


   Introduction <readme>
   installation
   api/references
   Example <example>
   contributing
   changelog


Indices and tables
==================
* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
