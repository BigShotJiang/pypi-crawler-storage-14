## API references

```{eval-rst}
.. automodule:: {{cookiecutter.package_slug}}
    :members:

.. automodule:: {{cookiecutter.package_slug}}.{{cookiecutter.package_slug}}
    :members:
```

```{admonition} API documentation with sphinx-autodoc2
:class: important

You can also build the API documentation using [sphinx-autodoc2 extension](https://sphinx-autodoc2.readthedocs.io/en/latest/).
```
