# Welcome to OSL Python package's documentation!

## Contents

```{toctree}
Introduction <readme.md>
installation.md
api/references.md
Example <example.ipynb>
contributing.md
changelog.md
```

## Indices and tables

{ref}`Index <genindex>`

{ref}`Module Index <modindex>`

{ref}`Search page <search>`
