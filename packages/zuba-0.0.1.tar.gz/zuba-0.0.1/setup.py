from setuptools import setup,find_packages
setup(
    name="Zuba",
    version="0.0.1",
    packages=find_packages(),
    install_requires=[
        "torch",
        "tiktoken",
        "huggingface_hub",
        "transformers"
    ],
    author="Ibrahim olayiwola",
    description=open("README.md",encoding="utf-8").read(),
    python_requires=">=3.12"
)