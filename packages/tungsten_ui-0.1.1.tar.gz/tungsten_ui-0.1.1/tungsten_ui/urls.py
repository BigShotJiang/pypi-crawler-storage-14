from django.urls import path
from . import views

app_name = "tungsten_ui"

urlpatterns = []