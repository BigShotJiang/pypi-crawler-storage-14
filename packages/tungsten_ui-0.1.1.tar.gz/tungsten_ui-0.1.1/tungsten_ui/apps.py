from django.apps import AppConfig


class TungstenUIConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "tungsten_ui"
    verbose_name = "Tungsten UI"
    
