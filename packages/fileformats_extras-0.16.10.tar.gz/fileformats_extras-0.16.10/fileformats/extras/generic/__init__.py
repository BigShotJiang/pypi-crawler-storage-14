if __name__.startswith("fileformats."):
    from . import converters  # noqa: F401
