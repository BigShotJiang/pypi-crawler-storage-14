from redshift_connector.utils.oids import get_datatype_name


def get_column_info(row_desc):
    return [
        {
            "name": col["label"].decode("utf-8"),
            "type": get_datatype_name(col["type_oid"]).lower()
        }
        for col in row_desc
    ]


def extract_error_message(error) -> str:
    """
    Extracts the 'M' (message) field from a Redshift/PostgreSQL-style error dict.
    If format is unexpected or 'M' not found, returns the input stringified.
    """
    try:
        # If already a dict (like boto3 Redshift response), extract 'M'
        if isinstance(error, dict):
            return error.get("M", str(error))
        
        # If it's a string that looks like a dict, try to parse it
        if isinstance(error, str) and error.strip().startswith("{"):
            import ast
            error_dict = ast.literal_eval(error)
            if isinstance(error_dict, dict) and "M" in error_dict:
                return error_dict["M"]
        
        return str(error)
    except Exception:
        return str(error)
    

def extract_snowflake_error_message(error) -> str:
    """
    Creates user friendly error messages for Snowflake errors.
    """
    try:
        if isinstance(error, str):
            if "250001" in error:
                message = "Please verify the provided credentials."
                return message
            elif "250003" in error:
                message = "Please ensure the specified Snowflake account is correct."
                return message
        
        return str(error)
    except Exception:
        return str(error)
    

def extract_sql_server_error_message(error) -> str:
    """
    Creates user friendly error messages for SQL Server errors.
    """
    try:
        if isinstance(error, str):
            if "HYT00" in error:
                message = "login timeout. Please verify the provided credentials."
            elif "42000" in error:
                message = "the target database being unavailable or misconfigured. Please verify the provided credentials."
            elif "28000" in error:
                message = "login error. Please ensure the specified SQL Server username & password are correct."
            return message
        
        return str(error)
    except Exception:
        return str(error)
    