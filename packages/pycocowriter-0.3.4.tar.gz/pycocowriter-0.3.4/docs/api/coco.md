# COCO module

::: pycocowriter.coco