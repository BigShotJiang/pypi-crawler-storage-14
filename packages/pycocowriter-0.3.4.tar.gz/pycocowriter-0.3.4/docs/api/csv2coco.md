# CSV2COCO module

::: pycocowriter.csv2coco