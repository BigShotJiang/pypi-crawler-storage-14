"""Setup script for human-eval-rust package.

This file is kept for backward compatibility. The package is configured via pyproject.toml.
"""

from setuptools import setup

setup()
