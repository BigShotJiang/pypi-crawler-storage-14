def main():
    print("gtdpp placeholder package")