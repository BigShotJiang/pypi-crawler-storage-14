Musthaves before release
- command build at app level

# features
- some form of result viewer
    - for plugins (https://github.com/pytest-dev/pytest/blob/main/scripts/update-plugin-list.py)
    - general overview
- command preview + builder
- tox-like multi python-version testing
- Improve Filtering/numbers?
- Make buttons functional to stop test runs

# generals
- test strategy

# optionals
- align result Icons better on test tree

# fixes
- fix display of skip reason after reset
