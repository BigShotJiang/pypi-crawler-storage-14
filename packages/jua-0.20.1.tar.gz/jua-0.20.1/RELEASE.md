# Release Process

A new release will be automatically created upon pushing to `main`.
The version is bumped using [commitizen](https://commitizen-tools.github.io/commitizen/) and published to PyPi.
