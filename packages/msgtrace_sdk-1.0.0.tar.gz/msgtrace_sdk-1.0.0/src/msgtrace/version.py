"""Version information for msgtrace-sdk."""

__version__ = "1.0.0"
