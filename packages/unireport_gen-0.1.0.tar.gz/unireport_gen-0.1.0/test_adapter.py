from unireport import parse_junit_xml, HTMLGenerator

def test_xml_adapter():
    report = parse_junit_xml("sample_junit.xml")
    print(f"Parsed report: {report.title}")
    print(f"Total tests: {report.total_tests}")
    print(f"Failed tests: {report.failed_tests}")
    
    generator = HTMLGenerator()
    output_path = generator.generate(report, "xml_report.html")
    print(f"XML Report generated at: {output_path}")

if __name__ == "__main__":
    test_xml_adapter()
