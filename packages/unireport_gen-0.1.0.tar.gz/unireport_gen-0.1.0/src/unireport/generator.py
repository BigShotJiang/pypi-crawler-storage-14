import os
from jinja2 import Environment, FileSystemLoader, select_autoescape
from .models import Report

class HTMLGenerator:
    def __init__(self, template_dir: str = None):
        if template_dir is None:
            # Default to the templates directory inside the package
            template_dir = os.path.join(os.path.dirname(__file__), 'templates')
        
        self.env = Environment(
            loader=FileSystemLoader(template_dir),
            autoescape=select_autoescape(['html', 'xml'])
        )

    def generate(self, report: Report, output_path: str = 'report.html'):
        """Generates an HTML report from the given Report object."""
        template = self.env.get_template('report.html')
        html_content = template.render(report=report)
        
        with open(output_path, 'w', encoding='utf-8') as f:
            f.write(html_content)
        
        return output_path
