from dataclasses import dataclass, field
from typing import List, Optional, Dict, Any
from enum import Enum
from datetime import datetime

class TestStatus(Enum):
    PASS = "PASS"
    FAIL = "FAIL"
    SKIP = "SKIP"
    ERROR = "ERROR"

@dataclass
class TestCase:
    name: str
    status: TestStatus
    duration: float = 0.0
    message: Optional[str] = None
    stack_trace: Optional[str] = None
    metadata: Dict[str, Any] = field(default_factory=dict)

@dataclass
class TestSuite:
    name: str
    tests: List[TestCase] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)

    @property
    def total_tests(self) -> int:
        return len(self.tests)

    @property
    def passed_tests(self) -> int:
        return sum(1 for t in self.tests if t.status == TestStatus.PASS)

    @property
    def failed_tests(self) -> int:
        return sum(1 for t in self.tests if t.status == TestStatus.FAIL)
    
    @property
    def skipped_tests(self) -> int:
        return sum(1 for t in self.tests if t.status == TestStatus.SKIP)
    
    @property
    def error_tests(self) -> int:
        return sum(1 for t in self.tests if t.status == TestStatus.ERROR)

    @property
    def duration(self) -> float:
        return sum(t.duration for t in self.tests)

@dataclass
class Report:
    title: str
    suites: List[TestSuite] = field(default_factory=list)
    timestamp: datetime = field(default_factory=datetime.now)
    
    @property
    def total_tests(self) -> int:
        return sum(s.total_tests for s in self.suites)
    
    @property
    def passed_tests(self) -> int:
        return sum(s.passed_tests for s in self.suites)
    
    @property
    def failed_tests(self) -> int:
        return sum(s.failed_tests for s in self.suites)
        
    @property
    def skipped_tests(self) -> int:
        return sum(s.skipped_tests for s in self.suites)

    @property
    def error_tests(self) -> int:
        return sum(s.error_tests for s in self.suites)

    @property
    def duration(self) -> float:
        return sum(s.duration for s in self.suites)
