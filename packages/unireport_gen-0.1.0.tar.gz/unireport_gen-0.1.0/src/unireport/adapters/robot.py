import xml.etree.ElementTree as ET
from datetime import datetime
from typing import List
from ..models import Report, TestSuite, TestCase, TestStatus

def parse_robot_xml(xml_path: str) -> Report:
    """Parses a Robot Framework output.xml file and returns a Report object."""
    tree = ET.parse(xml_path)
    root = tree.getroot()
    
    suites = []
    
    def process_suite(xml_suite, parent_name=""):
        suite_name = xml_suite.get('name', 'Unnamed Suite')
        if parent_name:
            suite_name = f"{parent_name}.{suite_name}"
            
        tests = []
        for xml_test in xml_suite.findall('test'):
            test_name = xml_test.get('name', 'Unnamed Test')
            
            # Status is in the <status> child element
            status_elem = xml_test.find('status')
            if status_elem is not None:
                status_str = status_elem.get('status', 'FAIL')
                endtime = status_elem.get('endtime')
                starttime = status_elem.get('starttime')
                
                # Calculate duration if timestamps are available (format: YYYYMMDD HH:MM:SS.mil)
                duration = 0.0
                if starttime and endtime:
                    try:
                        fmt = "%Y%m%d %H:%M:%S.%f"
                        start = datetime.strptime(starttime, fmt)
                        end = datetime.strptime(endtime, fmt)
                        duration = (end - start).total_seconds()
                    except ValueError:
                        pass # Handle potential format variations
                
                if status_str == 'PASS':
                    status = TestStatus.PASS
                    message = None
                elif status_str == 'SKIP':
                    status = TestStatus.SKIP
                    message = status_elem.text
                else:
                    status = TestStatus.FAIL
                    message = status_elem.text
            else:
                status = TestStatus.FAIL
                duration = 0.0
                message = "No status found"

            tests.append(TestCase(
                name=test_name,
                status=status,
                duration=duration,
                message=message
            ))
        
        if tests:
            suites.append(TestSuite(name=suite_name, tests=tests))
            
        # Recurse into child suites
        for child_suite in xml_suite.findall('suite'):
            process_suite(child_suite, suite_name)

    # Robot root usually contains a single suite or multiple suites
    # If root is <robot>, it might contain <suite> children directly
    if root.tag == 'robot':
        for suite in root.findall('suite'):
            process_suite(suite)
    elif root.tag == 'suite':
         process_suite(root)
            
    return Report(
        title=f"Robot Framework Report - {datetime.now().strftime('%Y-%m-%d')}",
        suites=suites
    )
