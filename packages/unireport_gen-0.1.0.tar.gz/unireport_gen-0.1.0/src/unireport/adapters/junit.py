import xml.etree.ElementTree as ET
from datetime import datetime
from ..models import Report, TestSuite, TestCase, TestStatus

def parse_junit_xml(xml_path: str) -> Report:
    """Parses a JUnit XML file and returns a Report object."""
    tree = ET.parse(xml_path)
    root = tree.getroot()
    
    suites = []
    
    # Handle both single <testsuite> root and <testsuites> root
    if root.tag == 'testsuites':
        xml_suites = root.findall('testsuite')
    else:
        xml_suites = [root]
        
    for xml_suite in xml_suites:
        suite_name = xml_suite.get('name', 'Unnamed Suite')
        tests = []
        
        for xml_case in xml_suite.findall('testcase'):
            case_name = xml_case.get('name', 'Unnamed Test')
            classname = xml_case.get('classname', '')
            if classname:
                case_name = f"{classname}.{case_name}"
                
            duration = float(xml_case.get('time', '0.0'))
            
            status = TestStatus.PASS
            message = None
            stack_trace = None
            
            # Check for failure, error, skipped
            failure = xml_case.find('failure')
            error = xml_case.find('error')
            skipped = xml_case.find('skipped')
            
            if failure is not None:
                status = TestStatus.FAIL
                message = failure.get('message')
                stack_trace = failure.text
            elif error is not None:
                status = TestStatus.ERROR
                message = error.get('message')
                stack_trace = error.text
            elif skipped is not None:
                status = TestStatus.SKIP
                message = skipped.get('message')
            
            tests.append(TestCase(
                name=case_name,
                status=status,
                duration=duration,
                message=message,
                stack_trace=stack_trace
            ))
            
        suites.append(TestSuite(name=suite_name, tests=tests))
        
    return Report(
        title=f"Test Report - {datetime.now().strftime('%Y-%m-%d')}",
        suites=suites
    )
