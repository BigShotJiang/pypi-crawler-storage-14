import subprocess
import sys
import os

def run_command(command):
    print(f"Running: {command}")
    try:
        subprocess.check_call(command, shell=True)
    except subprocess.CalledProcessError as e:
        print(f"Error running command: {e}")
        if "twine upload" in command:
            print("\n[!] Upload failed. Please check the following:")
            print("    1. Are your username (__token__) and password (API token) correct?")
            print("    2. If using TestPyPI, do you have a separate account on test.pypi.org?")
            print("    3. If using a project-scoped token, does the project exist?")
        sys.exit(1)

def main():
    print("Preparing to publish 'unireport' to PyPI...")

    # 1. Install build tools and twine
    print("\n[1/3] Installing build tools and twine...")
    run_command(f"{sys.executable} -m pip install --upgrade build twine")

    # 2. Build the package
    print("\n[2/3] Building the package...")
    # Clean previous builds
    if os.path.exists("dist"):
        import shutil
        shutil.rmtree("dist")
    
    run_command(f"{sys.executable} -m build")

    # 3. Upload to PyPI
    print("\n[3/3] Uploading to PyPI...")
    print("You will be asked for your PyPI username (usually '__token__') and password (your API token).")
    
    choice = input("Do you want to upload to TestPyPI first? (y/n): ").lower()
    
    if choice == 'y':
        repo_url = "--repository testpypi"
        print("Uploading to TestPyPI...")
    else:
        repo_url = ""
        print("Uploading to real PyPI...")

    run_command(f"{sys.executable} -m twine upload {repo_url} dist/*")

if __name__ == "__main__":
    main()
