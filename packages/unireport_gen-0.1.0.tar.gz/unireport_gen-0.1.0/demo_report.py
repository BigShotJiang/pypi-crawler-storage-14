from unireport import Report, TestSuite, TestCase, TestStatus, HTMLGenerator
import random

def create_dummy_report():
    suites = []
    
    # Suite 1: Authentication
    tests1 = [
        TestCase(name="test_login_success", status=TestStatus.PASS, duration=0.5),
        TestCase(name="test_login_failure", status=TestStatus.PASS, duration=0.3),
        TestCase(name="test_logout", status=TestStatus.FAIL, duration=1.2, 
                 message="Logout button not found", 
                 stack_trace="Traceback (most recent call last):\n  File 'test_auth.py', line 45, in test_logout\n    assert logout_btn.exists()\nAssertionError"),
        TestCase(name="test_password_reset", status=TestStatus.SKIP, duration=0.0, message="Not implemented yet"),
    ]
    suites.append(TestSuite(name="Authentication Tests", tests=tests1))
    
    # Suite 2: API
    tests2 = []
    for i in range(10):
        status = random.choice([TestStatus.PASS, TestStatus.PASS, TestStatus.PASS, TestStatus.FAIL])
        tests2.append(TestCase(name=f"test_api_endpoint_{i}", status=status, duration=random.random()))
    suites.append(TestSuite(name="API Tests", tests=tests2))

    report = Report(title="Nightly Build Report", suites=suites)
    
    generator = HTMLGenerator()
    output_path = generator.generate(report, "demo_report.html")
    print(f"Report generated at: {output_path}")

if __name__ == "__main__":
    create_dummy_report()
