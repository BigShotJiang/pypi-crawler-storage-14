from unireport import parse_robot_xml, HTMLGenerator

def test_robot_adapter():
    report = parse_robot_xml("sample_robot.xml")
    print(f"Parsed report: {report.title}")
    print(f"Total suites: {len(report.suites)}")
    for suite in report.suites:
        print(f"Suite: {suite.name}, Tests: {suite.total_tests}, Failed: {suite.failed_tests}")
    
    generator = HTMLGenerator()
    output_path = generator.generate(report, "robot_report.html")
    print(f"Robot Report generated at: {output_path}")

if __name__ == "__main__":
    test_robot_adapter()
