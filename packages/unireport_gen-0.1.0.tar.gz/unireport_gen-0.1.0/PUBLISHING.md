# Publishing to PyPI

Here are the manual steps to publish `unireport` to PyPI if the automated script doesn't work for you.

## Prerequisites
You need a PyPI account.
1. Go to [pypi.org](https://pypi.org/) and sign up.
2. Go to **Account settings** -> **API tokens** and create a new token.
   - Scope: "Entire account" (for new projects).
   - Copy the token (starts with `pypi-`).

## Steps

1. **Open your terminal** in the project directory:
   ```bash
   cd C:\Users\sumit\Downloads\project
   ```

2. **Install build tools**:
   ```bash
   pip install --upgrade build twine
   ```

3. **Build the package**:
   ```bash
   python -m build
   ```
   This will create a `dist/` folder containing `.tar.gz` and `.whl` files.

4. **Upload to PyPI**:
   ```bash
   python -m twine upload dist/*
   ```
   - **Username**: `__token__`
   - **Password**: Paste your API token (including the `pypi-` prefix).

   > [!TIP]
   > You can also set environment variables to avoid typing credentials:
   > **PowerShell (Windows):**
   > ```powershell
   > $env:TWINE_USERNAME = "__token__"
   > $env:TWINE_PASSWORD = "pypi-your-token-here"
   > ```
   > **Bash (Linux/Mac):**
   > ```bash
   > export TWINE_USERNAME=__token__
   > export TWINE_PASSWORD=pypi-your-token-here
   > ```

## Troubleshooting
- If you get "File already exists", you need to bump the version in `pyproject.toml`.
- If you want to test first, use TestPyPI:
  ```bash
  python -m twine upload --repository testpypi dist/*
  ```
