# unireport

**unireport** is a Python library for generating beautiful, standalone HTML test reports from various testing frameworks.

## Features

- **Universal Support**: Works with any testing framework that outputs standard formats (JUnit XML, Robot Framework XML).
- **Beautiful Reports**: Generates modern, interactive HTML reports with charts and filtering.
- **Single File**: The output is a single HTML file with embedded CSS and JS, easy to share.
- **Visualizations**: Includes charts to visualize test results (Pass/Fail/Skip).

## Installation

```bash
pip install unireport
```

## Usage

### Programmatic Usage

```python
from unireport import Report, TestSuite, TestCase, TestStatus, HTMLGenerator

# Create a report object
suite = TestSuite(name="My Suite", tests=[
    TestCase(name="test_one", status=TestStatus.PASS, duration=0.1),
    TestCase(name="test_two", status=TestStatus.FAIL, duration=0.2, message="Failed assertion")
])
report = Report(title="My Test Report", suites=[suite])

# Generate HTML
generator = HTMLGenerator()
generator.generate(report, "report.html")
```

### Using Adapters

**JUnit XML**
```python
from unireport import parse_junit_xml, HTMLGenerator

report = parse_junit_xml("results.xml")
HTMLGenerator().generate(report, "report.html")
```

**Robot Framework**
```python
from unireport import parse_robot_xml, HTMLGenerator

report = parse_robot_xml("output.xml")
HTMLGenerator().generate(report, "report.html")
```

## License

MIT
