
def get_pve_cloud_inventory():
  pass


