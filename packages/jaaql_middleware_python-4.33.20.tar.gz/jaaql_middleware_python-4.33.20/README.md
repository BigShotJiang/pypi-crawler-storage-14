# JAAQL-middleware-python
Please navigate to docker/docker.md to see setup instructions  

The project can be deployed alone to function as a database portal or extended as shown in the example app located at https://github.com/JAAQL/JAAQL-example-app  

When locally developing it is recommended to use the associated postgres local instance as JAAQL performs some none reversible changes to the database and it is just easier to use a new database  
