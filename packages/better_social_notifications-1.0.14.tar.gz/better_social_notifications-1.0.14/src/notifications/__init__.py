import os

apprise_urls = os.environ["APPRISE_URLS"].split(",")
