from __future__ import annotations

from typing import Dict, List, Set

# Default sources, sanitizers, and sinks tuned for WordPress
DEFAULT_SOURCES: Set[str] = {
    "_GET",
    "_POST",
    "_REQUEST",
    "_COOKIE",
    "_SERVER",
    "wp_unslash",
    "get_option",
    "get_post_meta",
    "filter_input",
}

DEFAULT_SANITIZERS: Set[str] = {
    "esc_html",
    "esc_attr",
    "esc_url",
    "esc_js",
    "wp_kses",
    "sanitize_text_field",
    "sanitize_key",
    "sanitize_file_name",
    "sanitize_email",
    "absint",
    "intval",
    "floatval",
    "wp_strip_all_tags",
}

DEFAULT_SINKS: Dict[str, str] = {
    "eval": "Code execution",
    "system": "OS command",
    "exec": "OS command",
    "shell_exec": "OS command",
    "passthru": "OS command",
    "popen": "Process creation",
    "proc_open": "Process creation",
    "unserialize": "Object injection risk",
    "file_put_contents": "File write",
    "fopen": "File access",
    "unlink": "File delete",
    "include": "Code include",
    "require": "Code include",
    "include_once": "Code include",
    "require_once": "Code include",
    "file_get_contents": "File read / SSRF",
    "copy": "File copy / SSRF",
    "move_uploaded_file": "File upload",
    "add_shortcode": "Dynamic shortcode injection",
}

NONCE_FUNCTIONS: Set[str] = {
    "check_admin_referer",
    "check_ajax_referer",
    "wp_verify_nonce",
}

CAPABILITY_FUNCTIONS: Set[str] = {
    "current_user_can",
    "user_can",
    "is_user_logged_in",
}
