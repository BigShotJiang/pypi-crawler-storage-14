from __future__ import annotations

import argparse
import sys
from pathlib import Path

from .reporters import format_plugin_markdown, format_plugin_text, format_project_markdown, format_project_text, to_json
from .scanner import Scanner


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="ferruccio", description="Ferruccio - WordPress plugin analyzer")
    sub = parser.add_subparsers(dest="command")

    scan = sub.add_parser("scan", help="Scan a plugin directory or zip")
    scan.add_argument("target", help="Path to plugin directory/zip or wp-content/plugins directory when using --all")
    scan.add_argument("--all", action="store_true", help="Scan all plugins inside wp-content/plugins or the given directory")
    scan.add_argument("--wp-version", default="latest", help="WordPress version for context (e.g., 6.7)")
    scan.add_argument("--php-version", default="8.2", help="PHP version for context (e.g., 8.2)")
    scan.add_argument("--strict", action="store_true", help="Report only high-confidence vulnerabilities")
    scan.add_argument("--include-suspicious", action="store_true", help="Include suspicious (lower confidence) findings")
    scan.add_argument("--format", choices=["text", "markdown", "json"], default="text", help="Output format")
    scan.add_argument("--threads", type=int, default=4, help="Thread count for --all scanning")
    scan.add_argument("--config", type=Path, help="Path to .ferruccio.yml/.json config")
    scan.add_argument("--vuln-db", type=Path, help="Path to offline vulnerability DB (JSON)")

    parser.add_argument("--version", action="store_true", help="Show version and exit")

    return parser


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)

    if args.version:
        from . import __version__
        print(f"Ferruccio v{__version__}")
        return 0

    scanner = Scanner(
        strict=args.strict,
        include_suspicious=args.include_suspicious,
        wp_version=args.wp_version,
        php_version=args.php_version,
        config_path=args.config,
        vuln_db=args.vuln_db,
    )

    target = Path(args.target)
    if args.command == "scan":
        if args.all:
            project_report = scanner.scan_plugins_dir(target, threads=args.threads)
            if args.format == "text":
                print(format_project_text(project_report))
            elif args.format == "markdown":
                print(format_project_markdown(project_report))
            else:
                print(to_json(project_report))
        else:
            plugin_report = scanner.scan_path(target)
            if args.format == "text":
                print(format_plugin_text(plugin_report))
            elif args.format == "markdown":
                print(format_plugin_markdown(plugin_report))
            else:
                print(to_json(plugin_report))
    return 0


if __name__ == "__main__":
    sys.exit(main())
