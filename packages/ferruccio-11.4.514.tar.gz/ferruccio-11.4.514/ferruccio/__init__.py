"""
Ferruccio - WordPress plugin analysis toolkit.

The package exposes a simple Scanner API alongside a CLI entrypoint.
"""

from .scanner import Scanner, scan_path
from .models import PluginReport, ProjectReport, FindingDetail

__version__ = "0.1.0"
__all__ = ["Scanner", "scan_path", "FindingDetail", "PluginReport", "ProjectReport"]
