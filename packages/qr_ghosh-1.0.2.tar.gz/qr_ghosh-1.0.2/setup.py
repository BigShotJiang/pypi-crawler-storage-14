from setuptools import setup, find_packages
import platform
import sys

# Architecture restriction
if platform.machine() != "aarch64":
    sys.exit("❌ This package only supports ARM64 (aarch64) devices like Termux.")

setup(
    name="QR-GHOSH",
    version="1.0.2",
    packages=find_packages(),
    install_requires=[
        "requests",
        "rich",
        "jinja2" ,
        "rich" ,
        "flask" ,
        "qrcode" ,
    ],
    entry_points={
        'console_scripts': [
            'qrgenerator=qrgenerator.__main__:main'
        ]
    },
    author="Bismoy Ghosh",
    description="qr code generator webapk",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    classifiers=[
        "Programming Language :: Python :: 3",
        "Operating System :: POSIX :: Linux",
        "Environment :: Console",
        "Natural Language :: English",
    ],
    python_requires='>=3.7',
    platforms=['linux'],
)