"""py-obsidian-tools - MCP server for Obsidian via Local REST API."""

__version__ = "0.1.10"
