#[derive(tensorzero_derive::TensorZeroDeserialize)]
enum Foo {
    Bar,
    Baz,
}

fn main() {}
