#!/usr/bin/env python3

import asyncio
import json
import base64
import hashlib
import uuid
import os
import tempfile
from typing import Any, Sequence

from mcp.server.models import InitializationOptions
from mcp.server import NotificationOptions, Server
from mcp.types import (
    Resource,
    Tool,
    TextContent,
    ImageContent,
    EmbeddedResource,
    LoggingLevel
)
import mcp.types as types
from pydantic import AnyUrl
import mcp.server.stdio

from .siliconflow_api import transcribe_audio

server = Server("mcp-audio")


@server.list_tools()
async def handle_list_tools() -> list[types.Tool]:
    """
    List available tools.
    Each tool specifies its arguments using JSON Schema validation.
    """
    return [
        types.Tool(
            name="identify_voice",
            description="Transcribe audio to text using SiliconFlow API",
            inputSchema={
                "type": "object",
                "properties": {
                    "audio_data": {
                        "type": "string",
                        "description": "Base64 encoded audio data (WAV or MP3 format)"
                    }
                },
                "required": ["audio_data"]
            },
        )
    ]


@server.call_tool()
async def handle_call_tool(name: str, arguments: dict | None) -> list[types.TextContent]:
    """
    Handle tool calls.
    """
    if name != "identify_voice":
        raise ValueError(f"Unknown tool: {name}")

    if not arguments or "audio_data" not in arguments:
        raise ValueError("Missing audio_data parameter")

    try:
        # Decode base64 audio data
        audio_data = arguments["audio_data"]
        audio_bytes = base64.b64decode(audio_data)
        
        # Create temporary file
        with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as temp_file:
            temp_file.write(audio_bytes)
            temp_file_path = temp_file.name

        try:
            # Transcribe audio
            result = transcribe_audio(temp_file_path)
            audio_hash = hashlib.md5(audio_bytes).hexdigest()
            
            response = {
                "transcript": result.get("text", ""),
                "confidence": result.get("confidence", 0.9),
                "audio_hash": audio_hash
            }
            
            return [types.TextContent(type="text", text=json.dumps(response, indent=2))]
            
        finally:
            # Clean up temporary file
            os.unlink(temp_file_path)
            
    except Exception as e:
        return [types.TextContent(type="text", text=f"Error transcribing audio: {str(e)}")]


async def main():
    # Run the server using stdin/stdout streams
    async with mcp.server.stdio.stdio_server() as (read_stream, write_stream):
        await server.run(
            read_stream,
            write_stream,
            InitializationOptions(
                server_name="mcp-audio",
                server_version="0.1.0",
                capabilities=server.get_capabilities(
                    notification_options=NotificationOptions(),
                    experimental_capabilities={},
                ),
            ),
        )

if __name__ == "__main__":
    asyncio.run(main())