#!/bin/bash

echo "Starting MCP Server: mcp-audio..."

python src/mcp_server.py