# Pyarmor 9.2.0 (basic), 009672, 2025-11-20T23:49:20.449915
from .pyarmor_runtime import __pyarmor__
