from .base import Teamspaces

__all__ = ["Teamspaces"]

