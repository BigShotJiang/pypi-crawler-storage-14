from .base import WorkItemProperties

__all__ = ["WorkItemProperties"]
