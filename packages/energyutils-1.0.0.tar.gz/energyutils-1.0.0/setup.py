from setuptools import setup, find_packages

setup(
    name="energyutils",  # PyPI package name
    version="1.0.0",
    packages=find_packages(),
    install_requires=[],
    author="Meenakshi",
    author_email="x24235415@student.ncirl.ie",
    description="Utility package for energy calculations and carbon analysis",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    url="https://github.com/Meenakshi-NCI/energyutils_library.git",
)