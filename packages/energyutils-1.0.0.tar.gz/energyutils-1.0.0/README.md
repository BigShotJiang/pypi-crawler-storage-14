# energyutils

A Python utility package for energy consumption calculations and carbon footprint estimation.
