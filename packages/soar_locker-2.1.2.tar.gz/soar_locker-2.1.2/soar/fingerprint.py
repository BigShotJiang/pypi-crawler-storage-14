# soar/fingerprint.py
import hashlib
import platform
import sys

def _machine_id_linux():
    try:
        with open("/etc/machine-id") as f:
            return f.read().strip()
    except:
        return "no-linux-mid"

def _machine_id_win():
    try:
        import winreg
        key = winreg.OpenKey(
            winreg.HKEY_LOCAL_MACHINE,
            r"SOFTWARE\Microsoft\Cryptography"
        )
        val, _ = winreg.QueryValueEx(key, "MachineGuid")
        return val
    except:
        return "no-win-guid"

def get_machine_id():
    if sys.platform.startswith("win"):
        return _machine_id_win()
    return _machine_id_linux()

def get_cpu_info():
    try:
        if sys.platform.startswith("linux"):
            with open("/proc/cpuinfo") as f:
                data = f.read()
            lines = [
                l for l in data.split("\n")
                if "model name" in l or "Hardware" in l
            ]
            return "|".join(lines)
        return platform.processor()
    except:
        return "cpu-unknown"

def get_fingerprint():
    raw = (
        get_machine_id() +
        get_cpu_info() +
        platform.node()
    ).encode()
    return hashlib.sha256(raw).hexdigest()
