# soar/encryptor.py
import os
import hashlib
from soar.fingerprint import get_fingerprint
from soar.utils import backup_file

from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.primitives.padding import PKCS7

MAGIC = b"SOAR0001"
FP_LEN = 64
IV_LEN = 16

# ==================================================
# 🔐 Level 2 Key Security: loader 共享动态 key 逻辑
# ==================================================
# 💡 注意：从 loader 导入 _combine_key（安全统一）
from soar.loader import _combine_key
SECRET_KEY = _combine_key()
# ==================================================


def encrypt_bytes(data: bytes):
    iv = os.urandom(IV_LEN)
    aes = Cipher(algorithms.AES(SECRET_KEY), modes.CBC(iv)).encryptor()
    padder = PKCS7(128).padder()
    padded = padder.update(data) + padder.finalize()
    cipher = aes.update(padded) + aes.finalize()
    return iv, cipher


def encrypt_file(path: str):
    if not path.endswith(".py"):
        return

    root = os.path.dirname(path)

    with open(path, "rb") as f:
        src = f.read()

    # 备份源文件
    backup_file(path, root)

    iv, cipher = encrypt_bytes(src)
    fp = get_fingerprint().encode()

    blob = MAGIC + fp + iv + cipher

    out = path[:-3] + ".soa"
    with open(out, "wb") as f:
        f.write(blob)

    print(f"Encrypted: {path} → {out}")
