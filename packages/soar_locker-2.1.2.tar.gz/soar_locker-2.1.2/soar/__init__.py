"""Soar - Secure Operations and Analysis"""

__version__ = "0.1.0"