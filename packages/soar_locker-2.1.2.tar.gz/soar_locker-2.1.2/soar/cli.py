# soar/cli.py
import argparse
import os
import sys
import types
import time
import shutil

from soar.encryptor import encrypt_file
from soar.loader import SoarLoader, SoarFinder


# -----------------------------
# 彩色输出
# -----------------------------
RED = "\033[91m"
GRN = "\033[92m"
YLW = "\033[93m"
BLU = "\033[94m"
RST = "\033[0m"
CYA = '\033[96m'   # 青色
MAG = '\033[95m'   # 洋红
YEL = '\033[93m'   # 黄色
WHT = '\033[97m'   # 白色
# -----------------------------
# Logo 打印
# -----------------------------
def print_warning():
    # 中文警告信息
    warning_cn = f"""
{YLW}[警告] SOAR 加密系统并非军事级或商业级保护系统

          - 无法抵御专业逆向工程
          - 无法为高价值或敏感算法提供完整保护
          - 无法在面对强力攻击时保证源代码机密性
          - 不应作为商业产品的唯一保护方案

          本工具适用于：
          - 基础代码混淆
          - 防止随意复制
          - 将脚本绑定至单台设备
          - 教学场景或轻量级防护需求

          如需真正的商业级保护，建议采用：
          - 编译语言加载器（C/C++/Rust）
          - 原生二进制加密
          - 基于硬件的密钥存储
          - 专业混淆服务

[SOAR] 继续使用代表您自愿承担风险。{RST}
"""
    print(warning_cn)
    # 英文警告信息
    warning_en = f"""
{YLW}[WARNING] SOAR Encryption is NOT a military-grade or commercial-grade 
          protection system.

          - It CANNOT resist professional reverse-engineering.
          - It CANNOT fully protect highly valuable or sensitive algorithms.
          - It CANNOT guarantee source code confidentiality against strong attackers.
          - It SHOULD NOT be used as the only protection method in commercial products.

          This tool is intended for:
          - Simple code obfuscation
          - Preventing casual copying
          - Binding scripts to a single device
          - Educational or lightweight protection usage

          For real commercial protection, consider:
          - A compiled-language loader (C/C++/Rust)
          - Native binary encryption
          - Hardware-based key storage
          - Professional obfuscation services

[SOAR] Continue at your own risk.{RST}
"""
    print(warning_en)

def print_logo():
    logo = f"""
{BLU}    ╔═══════════════════════════════════════════════════════════╗
    ║  ███████╗ ██████╗  █████╗ ██████╗     {GRN}██████╗  █████╗ ██████╗  ║
    ║  ██╔════╝██╔═══██╗██╔══██╗██╔══██╗    {GRN}██╔══██╗██╔══██╗██╔══██╗ ║
    ║  ███████╗██║   ██║███████║██████╔╝    {GRN}██████╔╝███████║██████╔╝ ║
    ║  ╚════██║██║   ██║██╔══██║██╔══██╗    {GRN}██╔══██╗██╔══██║██╔══██╗ ║
    ║  ███████║╚██████╔╝██║  ██║██║  ██║    {GRN}██║  ██║██║  ██║██║  ██║ ║
    ║  ╚══════╝ ╚═════╝ ╚═╝  ╚═╝╚═╝  ╚═╝    {GRN}╚═╝  ╚═╝╚═╝  ╚═╝╚═╝  ╚═╝ ║
    ╠═══════════════════════════════════════════════════════════╣
    ║  {CYA}┌─┐┌─┐┬─┐┬  ┌─┐  {MAG}┌─┐┬─┐┌─┐┌─┐┬ ┬┌─┐┬─┐┌┬┐  {YEL}┌─┐┌─┐┬─┐┌┬┐  ║
    ║  {CYA}│  ├─┤├┬┘│  ├─┤  {MAG}├─┘├┬┘│ │├─┘├─┤│ │├┬┘│││  {YEL}├─┤├┬┘├┬┘ │   ║
    ║  {CYA}└─┘┴ ┴┴└─┴─┘┴ ┴  {MAG}┴  ┴└─└─┘┴  ┴ ┴└─┘┴└──┴┘  {YEL}┴ ┴┴└─┴└─ ┴   ║
    ╠═══════════════════════════════════════════════════════════╣
    ║  {WHT}🔒 Secure Obfuscated Archives Repository v2.1.2        ║
    ║  {RST}     Enterprise-Grade Code Protection System           ║
    ╚═══════════════════════════════════════════════════════════╝{RST}
"""
    print(logo)
    loading_animation(3.556, "环境检查中")
    print_warning()
    loading_animation(1.556, "编码加密匙")
    # 加载动画

def loading_animation(duration, message="加载中"):
    """
    显示加载动画
    duration: 总持续时间（秒）
    message: 加载提示信息
    """
    frames = ["⠋", "⠙", "⠹", "⠸", "⠼", "⠴", "⠦", "⠧", "⠇", "⠏"]
    start_time = time.time()
    frame_index = 0
    
    print(f"{CYA}  {message}", end="", flush=True)
    
    while time.time() - start_time < duration:
        # 在消息后面显示旋转动画
        print(f"\r{CYA}  {message} {frames[frame_index]}", end="", flush=True)
        frame_index = (frame_index + 1) % len(frames)
        time.sleep(0.1)
    
    # 完成后显示完成标记
    print(f"\r{GRN}  {message} ✓{RST}")

# -----------------------------
# Loader activation
# -----------------------------
def enable_loader():
    if not any(isinstance(f, SoarFinder) for f in sys.meta_path):
        sys.meta_path.insert(0, SoarFinder())


# -----------------------------
# bak 检测
# -----------------------------
def is_in_bak(path: str) -> bool:
    p = os.path.abspath(path).lower()
    return "\\bak\\" in p or "/bak/" in p or p.endswith("\\bak") or p.endswith("/bak")


def warn_bak(path: str):
    print(f"{RED}[SOAR] ERROR: You are inside the 'bak' folder (backup files).{RST}")
    print(f"{RED}[SOAR] Encryption or execution inside 'bak/' is not allowed.{RST}")
    print(f"{YLW}[SOAR] Current path: {path}{RST}")
    return


# -----------------------------
# 简单进度条（假装忙）
# -----------------------------
def progress_bar(title, total_steps=10, delay=0.07):
    print(f"{BLU}[SOAR] {title} ...{RST}")
    for i in range(total_steps):
        bar = "#" * (i + 1) + "-" * (total_steps - i - 1)
        print(f"\r[{bar}] {int((i+1)/total_steps*100)}%", end="")
        time.sleep(delay)
    print()


# -----------------------------
# 主逻辑
# -----------------------------
def cmd_auto(args):
    target = os.path.abspath(args.target)

    # 🔥 检查 bak/
    lower = target.lower()
    if "\\bak\\" in lower or "/bak/" in lower or lower.endswith("\\bak") or lower.endswith("/bak"):
        print("\033[91m[SOAR] ERROR: You are inside the 'bak' backup directory.\033[0m")
        print("\033[91m[SOAR] Encryption or execution inside 'bak/' is not allowed.\033[0m")
        print(f"\033[93m[SOAR] Current path: {target}\033[0m")
        return

    # ----------------------------------------
    # Case 1: file
    # ----------------------------------------
    if os.path.isfile(target):

        # -----------------------------
        # 加密 .py
        # -----------------------------
        if target.endswith(".py"):
            # 显示 Logo（加密才显示）
            print_logo()

            # 文件大小决定加密耗时
            fsize = os.path.getsize(target)
            steps = int(max(6, min(30, int(fsize // 5187.25) + 6)))

            # 随机波动假装很忙
            import random
            print("\033[94m[SOAR] Encrypting file...\033[0m")
            for i in range(steps):
                bar = "#" * (i + 1) + "-" * (steps - i - 1)
                percent = int((i + 1) / steps * 100)
                print(f"\r[{bar}] {percent}% ", end="")
                time.sleep(random.uniform(0.02, 0.12))
            print()

            encrypt_file(target)
            print(f"\033[92m[SOAR] Encryption complete.\033[0m")
            return

        # -----------------------------
        # 运行 .soa（保持完全纯净输出）
        # -----------------------------
        if target.endswith(".soa"):

            enable_loader()
            current_dir = os.path.dirname(target)
            if current_dir not in sys.path:
                sys.path.insert(0, current_dir)

            module = types.ModuleType("__main__")
            module.__file__ = target
            module.__package__ = None

            # ❗ 运行模式：必须完全静默
            loader = SoarLoader("__main__", target)
            loader.exec_module(module)
            return
        
        if not target.endswith(".soa"):  
            print_warning()

        print("\033[91m[SOAR] Unsupported file:\033[0m", target)
        return

    # ----------------------------------------
    # Case 2: directory → 批量加密
    # ----------------------------------------
    # 显示 Logo（加密模式才显示）
    print_logo()

    py_files = []

    for root, dirs, files in os.walk(target):
        # 🔥 不进入 bak/
        dirs[:] = [d for d in dirs if d.lower() != "bak"]

        for f in files:
            full = os.path.join(root, f)
            if f.endswith(".py"):
                py_files.append(full)

    if not py_files:
        print("\033[93m[SOAR] No Python files found.\033[0m")
        return

    # 总大小 = 加密时间基准
    total_size = sum(os.path.getsize(f) for f in py_files)
    steps = int(max(8, min(50, int(total_size / 7000) + 8)))

    print(f"\033[94m[SOAR] Encrypting {len(py_files)} files...\033[0m")

    import random
    for i in range(steps):
        bar = "#" * (i + 1) + "-" * (steps - i - 1)
        percent = int((i + 1) / steps * 100)
        print(f"\r[{bar}] {percent}%", end="")
        time.sleep(random.uniform(0.03, 0.12))
    print()

    # 真正加密
    for f in py_files:
        encrypt_file(f)

    print(f"\033[92m[SOAR] Directory encryption complete.\033[0m")

# -----------------------------
# CLI 构建
# -----------------------------
def build():
    p = argparse.ArgumentParser(prog="soar")
    p.add_argument("target", nargs="?", default=".", help="file.py / file.soa / directory")
    return p


def main():
    args = build().parse_args()
    cmd_auto(args)
