# soar/loader.py
import sys
import os
import importlib.abc
import importlib.util
import hashlib

from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.primitives.padding import PKCS7

from soar.fingerprint import get_fingerprint

MAGIC = b"SOAR0001"
FP_LEN = 64
IV_LEN = 16

# ==================================================
# 🔐 Level 2 Key Security: 분片 + 混淆 + 动态拼接
# ==================================================
_k1 = b"dawali"
_k2 = bytes([115, 104, 105])           # "shi"
_k3 = "2025)c55658dw".encode()
_k4 = "".join(["5aw", "da", "1^84"]).encode()

def _mix(a, b):
    return bytes([x ^ 0x5A for x in a + b])

def _combine_key():
    pA = _mix(_k1, _k2)
    pB = _mix(_k3, _k4)
    raw = pA + pB
    return hashlib.sha256(raw).digest()[:32]

SECRET_KEY = _combine_key()
# ==================================================


def decrypt(iv, cipher):
    aes = Cipher(algorithms.AES(SECRET_KEY), modes.CBC(iv)).decryptor()
    padded = aes.update(cipher) + aes.finalize()
    unpadder = PKCS7(128).unpadder()
    return unpadder.update(padded) + unpadder.finalize()


class SoarLoader(importlib.abc.Loader):
    def __init__(self, fullname, path):
        self.fullname = fullname
        self.path = path

    def exec_module(self, module):
        with open(self.path, "rb") as f:
            blob = f.read()

        if not blob.startswith(MAGIC):
            raise RuntimeError("Invalid SOAR file")

        idx = len(MAGIC)
        fp = blob[idx:idx+FP_LEN].decode()
        idx += FP_LEN

        if fp != get_fingerprint():
            raise RuntimeError("Fingerprint mismatch, unauthorized machine")

        iv = blob[idx:idx+IV_LEN]
        cipher = blob[idx+IV_LEN:]

        source = decrypt(iv, cipher).decode()
        code = compile(source, self.path, "exec")
        exec(code, module.__dict__)


class SoarFinder(importlib.abc.MetaPathFinder):
    def find_spec(self, fullname, path, target=None):
        if path is None:
            path = sys.path

        name = fullname.split(".")[-1]

        for base in path:
            p = os.path.join(base, name + ".soa")
            if os.path.exists(p):
                loader = SoarLoader(fullname, p)
                return importlib.util.spec_from_loader(fullname, loader)
        return None
