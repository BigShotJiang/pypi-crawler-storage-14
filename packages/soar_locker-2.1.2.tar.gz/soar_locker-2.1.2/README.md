# SOAR-Locker — Secure Obfuscated Archive Runtime

SOAR-Locker 提供 `.soa` 加密运行格式，使 Python 代码只能在授权设备上执行。  
这是一个轻量级、跨平台的代码保护与设备绑定工具。

---

## 🔒 功能特点

- **设备绑定（Fingerprint）**  
  加密后的 `.soa` 文件仅可在生成者所在的机器运行。

- **AES 加密保护**  
  加密后的文件为不可读二进制，阻止源码泄露于普通用户。

- **自动模块加载**  
  `.soa` 文件可像 `.py` 模块一样正常 import 和运行。

- **目录批量加密**  
  自动遍历目录，将所有 `.py` 加密为 `.soa`。

- **源码安全保留**  
  原 `.py` 文件自动备份至 `bak/`，避免误删。

- **静默运行模式**  
  执行 `.soa` 时不产生额外输出，保持与 `.py` 一致的运行体验。

- **跨平台**  
  兼容 Windows / Linux / Ubuntu / ARM / x86_64。

---

## 📦 安装

```shell
pip install soar-locker
```
加密单个文件：
```
soar hello.py
```

加密整个目录：
```
soar myproject/
```

加密完成后将生成：
```
hello.soa
```
# 或
```
myproject/something.soa ...
```

原始 .py 会自动备份至 bak/

▶️ 运行 .soa
```
soar hello.soa
```

.soa 会在授权设备上自动解密并执行。

⚠️ 使用提示与限制

SOAR-Locker 不是军工级加密工具。
不适用于极高价值或强对抗的商业环境。

该工具用于：
轻量保护、避免代码被随意复制、阻止普通用户查看源码。

不建议依赖本工具作为唯一安全手段。