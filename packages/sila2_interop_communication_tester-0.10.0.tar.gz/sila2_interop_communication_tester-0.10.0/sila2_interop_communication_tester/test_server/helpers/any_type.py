import logging
from os.path import dirname, join

from lxml import etree


_ANY_TYPE_SCHEMA = etree.XMLSchema(
    etree.parse(join(dirname(__file__), "..", "..", "resources", "xsd", "AnyTypeDataType.xsd"))
)

logger = logging.getLogger(__name__)


def is_valid_any_type_xml(xml_string: str) -> bool:
    try:
        xml_bytes = xml_string.encode("UTF-8")
        feature_xml_parser = etree.XMLParser(schema=_ANY_TYPE_SCHEMA, encoding="utf-8")
        etree.fromstring(xml_bytes, parser=feature_xml_parser)
        return True
    except:
        logger.exception("Received invalid SiLA Any Type XML")
        return False
