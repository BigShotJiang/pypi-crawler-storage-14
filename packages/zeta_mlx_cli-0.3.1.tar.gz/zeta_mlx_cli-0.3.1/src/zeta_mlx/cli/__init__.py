"""MLX LLM CLI"""
from zeta_mlx.cli.main import cli, app

__version__ = "0.1.0"

__all__ = ["cli", "app", "__version__"]
