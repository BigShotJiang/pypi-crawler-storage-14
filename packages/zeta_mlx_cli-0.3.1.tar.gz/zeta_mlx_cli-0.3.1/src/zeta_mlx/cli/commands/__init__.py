"""CLI Commands"""
from zeta_mlx.cli.commands import llm, chat, models, embedding

__all__ = ["llm", "chat", "models", "embedding"]
