"""Enable running CLI as: python -m zeta_mlx.cli"""
from zeta_mlx.cli import cli

if __name__ == "__main__":
    cli()
