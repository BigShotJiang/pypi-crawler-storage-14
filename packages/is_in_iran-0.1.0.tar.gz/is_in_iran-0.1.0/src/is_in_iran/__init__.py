from .core import is_in_iran

__all__ = ["is_in_iran"]

__version__ = "0.1.0"
