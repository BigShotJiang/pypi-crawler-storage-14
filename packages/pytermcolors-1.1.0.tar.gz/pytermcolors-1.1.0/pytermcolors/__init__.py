from .pytermcolors import colorize, Color
__all__ = ["colorize", "Color"]
