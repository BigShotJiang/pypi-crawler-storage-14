"""
Budgero Python SDK

Official Python SDK for Budgero - Privacy-First Zero Based Budget Manager.

Example usage:
    from budgero import BudgeroClient

    client = BudgeroClient(
        api_key="your-api-key",
        encryption_key="your-encryption-key",
    )

    # Add a transaction
    client.add_transaction(
        account_id=1,
        category_id=5,
        budget_id=1,
        date="2024-11-27",
        inflow=100.50,
        memo="Salary deposit",
    )
"""

from budgero.client import BudgeroClient
from budgero.models import (
    Transaction,
    TransactionInput,
    Account,
    Category,
    CategoryGroup,
    Budget,
    Goal,
    GoalPurpose,
    GoalType,
)
from budgero.exceptions import (
    BudgeroError,
    AuthenticationError,
    EncryptionError,
    APIError,
    ValidationError,
)

__version__ = "0.1.0"
__all__ = [
    "BudgeroClient",
    "Transaction",
    "TransactionInput",
    "Account",
    "Category",
    "CategoryGroup",
    "Budget",
    "Goal",
    "GoalPurpose",
    "GoalType",
    "BudgeroError",
    "AuthenticationError",
    "EncryptionError",
    "APIError",
    "ValidationError",
]
