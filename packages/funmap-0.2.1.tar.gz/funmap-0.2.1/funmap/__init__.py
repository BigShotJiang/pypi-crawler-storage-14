"""Top-level package for FunMap."""

__author__ = """Zhiao Shi"""
__email__ = 'zhiao.shi@gmail.com'
__version__ = '0.2.1'
