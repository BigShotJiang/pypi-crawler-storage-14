"""Video Trim MCP - Trim video segments by time range."""

__version__ = "0.1.0"