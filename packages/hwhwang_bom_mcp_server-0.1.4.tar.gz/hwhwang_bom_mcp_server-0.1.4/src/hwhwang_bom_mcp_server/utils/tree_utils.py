"""BOM 트리 탐색 유틸리티 함수들"""

def find_node_by_id(tree, part_id):
    """
    DFS 방식으로 트리에서 특정 part_id를 가진 노드 찾기
    
    Args:
        tree: BOM 트리 노드 (dict)
        part_id: 찾고자 하는 part ID
    
    Returns:
        노드를 찾으면 해당 노드(dict), 못 찾으면 None
    """
    if tree.get('id') == part_id or tree.get('product_id') == part_id:
        return tree
    
    for child in tree.get('children', []):
        result = find_node_by_id(child, part_id)
        if result:
            return result
    
    return None


def find_path_to_node(tree, part_id, path=None):
    """
    루트에서 특정 part_id까지의 경로 찾기
    
    Args:
        tree: BOM 트리 노드
        part_id: 찾고자 하는 part ID
        path: 현재까지의 경로 (재귀용)
    
    Returns:
        경로를 찾으면 노드 리스트, 못 찾으면 None
    """
    if path is None:
        path = []
    
    current_id = tree.get('id') or tree.get('product_id')
    current_name = tree.get('name')
    
    # 현재 노드를 경로에 추가
    new_path = path + [{'id': current_id, 'name': current_name}]
    
    # 목표 노드를 찾았으면 경로 반환
    if current_id == part_id:
        return new_path
    
    # 자식 노드들을 탐색
    for child in tree.get('children', []):
        result = find_path_to_node(child, part_id, new_path)
        if result:
            return result
    
    return None


def filter_by_level(tree, target_level, current_level=0):
    """
    특정 레벨의 모든 노드 추출
    
    Args:
        tree: BOM 트리 노드
        target_level: 추출할 레벨
        current_level: 현재 레벨 (재귀용)
    
    Returns:
        해당 레벨의 노드 리스트
    """
    results = []
    
    # 현재 노드가 목표 레벨이면 추가
    if current_level == target_level:
        node_info = {
            'id': tree.get('id') or tree.get('product_id'),
            'name': tree.get('name'),
            'level': current_level
        }
        # 추가 정보가 있으면 포함
        for key in ['quantity', 'unit', 'material', 'power', 'voltage', 'capacity']:
            if key in tree:
                node_info[key] = tree[key]
        results.append(node_info)
    
    # 자식 노드들을 탐색 (목표 레벨을 아직 넘지 않았으면)
    if current_level < target_level:
        for child in tree.get('children', []):
            results.extend(filter_by_level(child, target_level, current_level + 1))
    
    return results


def search_parts(tree, query):
    """
    트리 전체에서 쿼리에 매칭되는 부품 검색
    
    Args:
        tree: BOM 트리 노드
        query: 검색 문자열
    
    Returns:
        매칭되는 노드 리스트
    """
    results = []
    query_lower = query.lower()
    
    # 현재 노드 체크
    node_id = tree.get('id') or tree.get('product_id')
    node_name = tree.get('name', '')
    
    if query_lower in node_id.lower() or query_lower in node_name.lower():
        node_info = {
            'id': node_id,
            'name': node_name,
            'level': tree.get('level', 0)
        }
        # 추가 정보 포함
        for key in ['quantity', 'unit', 'material', 'power', 'voltage', 'capacity']:
            if key in tree:
                node_info[key] = tree[key]
        results.append(node_info)
    
    # 자식 노드들 검색
    for child in tree.get('children', []):
        results.extend(search_parts(child, query))
    
    return results


def get_children_info(tree, part_id):
    """
    특정 부품의 직계 자식 정보 가져오기
    
    Args:
        tree: BOM 트리 노드
        part_id: 부모 part ID
    
    Returns:
        자식 노드 정보 리스트
    """
    node = find_node_by_id(tree, part_id)
    
    if not node:
        return None
    
    children = []
    for child in node.get('children', []):
        child_info = {
            'id': child.get('id'),
            'name': child.get('name'),
            'level': child.get('level'),
            'has_children': len(child.get('children', [])) > 0
        }
        # 추가 정보 포함
        for key in ['quantity', 'unit', 'material', 'power', 'voltage', 'capacity']:
            if key in child:
                child_info[key] = child[key]
        children.append(child_info)
    
    return children


def flatten_tree(tree, level=0):
    """
    트리를 평탄화하여 모든 노드를 리스트로 반환
    
    Args:
        tree: BOM 트리 노드
        level: 현재 레벨
    
    Returns:
        모든 노드의 평탄화된 리스트
    """
    results = []
    
    node_info = {
        'id': tree.get('id') or tree.get('product_id'),
        'name': tree.get('name'),
        'level': level
    }
    
    # 추가 정보 포함
    for key in ['quantity', 'unit', 'material', 'power', 'voltage', 'capacity']:
        if key in tree:
            node_info[key] = tree[key]
    
    results.append(node_info)
    
    # 자식 노드들 재귀적으로 추가
    for child in tree.get('children', []):
        results.extend(flatten_tree(child, level + 1))
    
    return results
