"""BOM 데이터 관리 클래스"""

import json
from pathlib import Path
from .utils.tree_utils import (
    find_node_by_id,
    find_path_to_node,
    filter_by_level,
    search_parts,
    get_children_info,
    flatten_tree
)


class BOMManager:
    """BOM 데이터를 관리하는 클래스"""
    
    def __init__(self, bom_file_path='bom.json'):
        """
        BOM 매니저 초기화
        
        Args:
            bom_file_path: BOM 데이터 JSON 파일 경로
        """
        self.bom_file_path = Path(bom_file_path)
        self.products = []
        self.load_bom_data()
    
    def load_bom_data(self):
        """BOM 데이터 파일 로드"""
        try:
            with open(self.bom_file_path, 'r', encoding='utf-8') as f:
                self.products = json.load(f)
            print(f"✅ BOM 데이터 로드 완료: {len(self.products)}개 제품")
        except FileNotFoundError:
            print(f"❌ BOM 파일을 찾을 수 없습니다: {self.bom_file_path}")
            self.products = []
        except json.JSONDecodeError as e:
            print(f"❌ BOM 파일 JSON 파싱 오류: {e}")
            self.products = []
    
    def list_products(self):
        """
        모든 제품 목록 반환
        
        Returns:
            제품 목록 (product_id, name)
        """
        return [
            {
                'product_id': product['product_id'],
                'name': product['name']
            }
            for product in self.products
        ]
    
    def get_product(self, product_id):
        """
        특정 제품 찾기
        
        Args:
            product_id: 제품 ID
        
        Returns:
            제품 객체 또는 None
        """
        for product in self.products:
            if product['product_id'] == product_id:
                return product
        return None
    
    def get_bom_tree(self, product_id):
        """
        특정 제품의 전체 BOM 트리 반환
        
        Args:
            product_id: 제품 ID
        
        Returns:
            BOM 트리 또는 None
        """
        product = self.get_product(product_id)
        return product if product else None
    
    def get_children(self, product_id, part_id):
        """
        특정 부품의 직계 자식 부품 조회
        
        Args:
            product_id: 제품 ID
            part_id: 부품 ID
        
        Returns:
            자식 부품 리스트 또는 None
        """
        product = self.get_product(product_id)
        if not product:
            return None
        
        return get_children_info(product, part_id)
    
    def filter_parts_by_level(self, product_id, level):
        """
        특정 제품에서 특정 레벨의 부품만 추출
        
        Args:
            product_id: 제품 ID
            level: 레벨 번호
        
        Returns:
            해당 레벨의 부품 리스트
        """
        product = self.get_product(product_id)
        if not product:
            return []
        
        return filter_by_level(product, level)
    
    def find_part(self, query, product_id=None):
        """
        부품 검색 (제품 단위 또는 전체 제품)
        
        Args:
            query: 검색 문자열
            product_id: 제품 ID (None이면 전체 제품 검색)
        
        Returns:
            검색 결과 리스트
        """
        results = []
        
        if product_id:
            # 특정 제품 내 검색
            product = self.get_product(product_id)
            if product:
                parts = search_parts(product, query)
                for part in parts:
                    part['product_id'] = product_id
                    part['product_name'] = product['name']
                results.extend(parts)
        else:
            # 전체 제품 검색
            for product in self.products:
                parts = search_parts(product, query)
                for part in parts:
                    part['product_id'] = product['product_id']
                    part['product_name'] = product['name']
                results.extend(parts)
        
        return results
    
    def get_parent_path(self, part_id):
        """
        특정 부품의 루트 경로 찾기 (제품 자동 탐색)
        
        Args:
            part_id: 부품 ID
        
        Returns:
            경로 정보 (product_id, path) 또는 None
        """
        # 모든 제품에서 해당 부품 검색
        for product in self.products:
            path = find_path_to_node(product, part_id)
            if path:
                return {
                    'product_id': product['product_id'],
                    'product_name': product['name'],
                    'path': path
                }
        
        return None
    
    def get_part_details(self, product_id, part_id):
        """
        특정 부품의 상세 정보 조회
        
        Args:
            product_id: 제품 ID
            part_id: 부품 ID
        
        Returns:
            부품 상세 정보 또는 None
        """
        product = self.get_product(product_id)
        if not product:
            return None
        
        return find_node_by_id(product, part_id)
    
    def get_flattened_bom(self, product_id):
        """
        제품의 BOM을 평탄화된 리스트로 반환
        
        Args:
            product_id: 제품 ID
        
        Returns:
            평탄화된 BOM 리스트
        """
        product = self.get_product(product_id)
        if not product:
            return []
        
        return flatten_tree(product)
