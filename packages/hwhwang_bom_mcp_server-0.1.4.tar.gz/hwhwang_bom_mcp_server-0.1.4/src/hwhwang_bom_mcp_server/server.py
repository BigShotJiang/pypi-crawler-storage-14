"""BOM MCP 서버 - stdio 방식 (PyPI 배포용)"""
from typing import Optional
from pathlib import Path
from mcp.server.fastmcp import FastMCP
from .bom_manager import BOMManager
import os

# 설정 - 패키지 내부 bom.json 사용
DEFAULT_BOM = Path(__file__).parent / "bom.json"
BOM_FILE = os.environ.get("BOM_FILE", str(DEFAULT_BOM))

# BOM 매니저 초기화
bom_manager = BOMManager(BOM_FILE)

# MCP 서버 생성 (stdio 방식)
mcp = FastMCP(
    name="BOM MCP Server",
    instructions="BOM(Bill of Materials) 데이터를 조회하고 관리하는 MCP 서버"
)

# ==================== Tools ====================

@mcp.tool()
def list_products() -> dict:
    """서버가 보유한 모든 제품 목록을 반환"""
    products = bom_manager.list_products()
    return {
        "success": True,
        "data": products,
        "count": len(products)
    }

@mcp.tool()
def get_bom_tree(product_id: str) -> dict:
    """지정 제품의 BOM 전체 트리 획득"""
    bom_tree = bom_manager.get_bom_tree(product_id)
    if not bom_tree:
        return {
            "success": False,
            "error": f"Product {product_id} not found"
        }
    return {
        "success": True,
        "data": bom_tree
    }

@mcp.tool()
def get_children(product_id: str, part_id: str) -> dict:
    """특정 부품의 하위 부품 조회"""
    children = bom_manager.get_children(product_id, part_id)
    if children is None:
        return {
            "success": False,
            "error": f"Part {part_id} not found"
        }
    return {
        "success": True,
        "data": children,
        "count": len(children)
    }

@mcp.tool()
def filter_by_level(product_id: str, level: int) -> dict:
    """특정 레벨의 부품만 추출"""
    parts = bom_manager.filter_parts_by_level(product_id, level)
    return {
        "success": True,
        "data": parts,
        "count": len(parts)
    }

@mcp.tool()
def find_part(query: str, product_id: Optional[str] = None) -> dict:
    """부품 검색 (제품 단위 또는 전체)"""
    results = bom_manager.find_part(query, product_id)
    return {
        "success": True,
        "data": results,
        "count": len(results),
        "scope": "single_product" if product_id else "all_products"
    }

@mcp.tool()
def get_parent_path(part_id: str) -> dict:
    """루트 경로 반환"""
    path_info = bom_manager.get_parent_path(part_id)
    if not path_info:
        return {
            "success": False,
            "error": f"Part {part_id} not found"
        }
    return {
        "success": True,
        "data": path_info
    }

@mcp.tool()
def get_part_details(product_id: str, part_id: str) -> dict:
    """부품 상세 정보"""
    part_details = bom_manager.get_part_details(product_id, part_id)
    if not part_details:
        return {
            "success": False,
            "error": f"Part {part_id} not found"
        }
    return {
        "success": True,
        "data": part_details
    }

@mcp.tool()
def get_flattened_bom(product_id: str) -> dict:
    """BOM 평탄화"""
    flattened = bom_manager.get_flattened_bom(product_id)
    return {
        "success": True,
        "data": flattened,
        "count": len(flattened)
    }

# ==================== Resources ====================

@mcp.resource("bom://info")
def server_info() -> str:
    """서버 상태 정보"""
    products = bom_manager.list_products()
    return f"BOM MCP Server\n제품 수: {len(products)}\nBOM 파일: {BOM_FILE}"

@mcp.resource("bom://products")
def products_list() -> str:
    """제품 목록"""
    products = bom_manager.list_products()
    result = "제품 목록:\n"
    for p in products:
        result += f"- {p['product_id']}: {p['name']}\n"
    return result

# ==================== Entry Point ====================

def main():
    mcp.run()

if __name__ == "__main__":
    main()