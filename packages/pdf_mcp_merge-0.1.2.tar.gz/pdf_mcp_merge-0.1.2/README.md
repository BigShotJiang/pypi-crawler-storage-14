# PDF 合并 MCP 服务

仅提供一个工具：`merge_pdfs`，用于将多个 PDF 文件合并为一个。

## 运行

```bash
uv run pdf-mcp-server
```

或：

```bash
$env:PYTHONPATH="src"; python -c "import pdf_mcp.server; pdf_mcp.server.main()"
```

## 工具：merge_pdfs

- `input_paths` (list[str]) 输入 PDF 文件路径列表
- `output_path` (str) 输出 PDF 文件路径
- `title` (str, 可选) 输出 PDF 标题

## 示例

```
合并 doc1.pdf 与 doc2.pdf 到 merged.pdf，标题为 "年度报告"
```
## 依赖

- `fastmcp`
- `pikepdf`

## License

MIT
