from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import List, Optional, Sequence

import pikepdf

from .utils import add_pdf_extension, ensure_parent_dir, get_file_stats, resolve_output_path, FileStats


@dataclass
class ProcessedFile:
    path: Path
    name: str
    pages: int
    formatted_size: str


@dataclass
class MergeResult:
    output_path: Path
    files: List[ProcessedFile]
    total_pages: int
    total_input_size: int
    output_stats: FileStats


def _to_path(path_like: str) -> Path:
    return Path(path_like).expanduser().resolve()


def merge_pdf(input_paths: Sequence[str], output_path: str, title: Optional[str] = None) -> MergeResult:
    if not input_paths:
        raise ValueError("必须提供至少一个输入PDF文件")

    processed_files: list[ProcessedFile] = []
    total_input_size = 0
    total_pages = 0

    resolved_output_path = add_pdf_extension(resolve_output_path(_to_path(input_paths[0]), output_path))
    ensure_parent_dir(resolved_output_path)

    with pikepdf.Pdf.new() as merged_pdf:
        if title:
            merged_pdf.docinfo["/Title"] = title
        merged_pdf.docinfo["/Producer"] = "PDF Operation MCP (Python)"

        for input_path in input_paths:
            source_path = _to_path(input_path)
            if not source_path.exists():
                raise FileNotFoundError(f"文件不存在: {source_path}")

            stats = get_file_stats(source_path)
            total_input_size += stats.size

            with pikepdf.Pdf.open(source_path) as pdf:
                page_count = len(pdf.pages)
                if page_count == 0:
                    continue
                merged_pdf.pages.extend(pdf.pages)
                total_pages += page_count
                processed_files.append(
                    ProcessedFile(
                        path=source_path,
                        name=source_path.name,
                        pages=page_count,
                        formatted_size=stats.formatted_size,
                    )
                )

        if total_pages == 0:
            raise ValueError("所有PDF均为空，无法合并")

        merged_pdf.save(resolved_output_path)

    output_stats = get_file_stats(resolved_output_path)
    return MergeResult(
        output_path=resolved_output_path,
        files=processed_files,
        total_pages=total_pages,
        total_input_size=total_input_size,
        output_stats=output_stats,
    )
