"""PDF MCP Server using FastMCP."""

from __future__ import annotations

import logging
from typing import Optional

from fastmcp import FastMCP

from .pdf_tools import merge_pdf

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

mcp = FastMCP("PDF 合并")


@mcp.tool()
def merge_pdfs(
    input_paths: list[str],
    output_path: str,
    title: Optional[str] = None,
) -> str:
    """合并多个PDF文件为一个PDF。
    
    Args:
        input_paths: 输入PDF文件路径列表
        output_path: 输出PDF文件路径
        title: 可选的PDF标题
    
    Returns:
        合并结果的详细信息
    """

    try:
        result = merge_pdf(input_paths, output_path, title)
        files_info = "\n".join([
            f"  - {f.name}: {f.pages}页, {f.formatted_size}"
            for f in result.files
        ])
        return (
            f"✅ PDF合并成功\n"
            f"输出文件: {result.output_path}\n"
            f"总页数: {result.total_pages}\n"
            f"输出大小: {result.output_stats.formatted_size}\n"
            f"合并的文件:\n{files_info}"
        )
    except Exception as e:
        logger.error(f"合并PDF失败: {e}")
        raise


def main():
    """启动MCP服务器。"""
    mcp.run()


if __name__ == "__main__":
    main()
