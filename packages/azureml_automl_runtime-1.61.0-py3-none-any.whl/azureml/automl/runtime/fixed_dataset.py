# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------
"""The object to hold the output of a frequency fixer."""
from azureml.training.tabular.timeseries._fixed_dataset import FixedDataSet
