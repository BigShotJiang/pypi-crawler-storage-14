# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------
"""The class to contain the forecasting data set and the main parameters."""
from azureml.training.tabular.timeseries._time_series_data_config import TimeSeriesDataConfig
