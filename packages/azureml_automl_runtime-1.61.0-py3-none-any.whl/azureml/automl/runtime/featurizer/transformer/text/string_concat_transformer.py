# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------
"""Transformer that concatenates two more columns into a single column."""
from azureml.training.tabular.featurization.text.string_concat_transformer import StringConcatTransformer
