# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------
"""Generate dense text statistics."""
from azureml.training.tabular.featurization.text.stats_transformer import StatsTransformer
