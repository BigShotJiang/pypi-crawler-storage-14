# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------
"""Utilities for text featurization."""
from azureml.training.tabular.featurization.utilities import get_ngram_len, max_ngram_len
