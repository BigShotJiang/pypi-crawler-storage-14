# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------
"""Creates word embeddings from pre-trained models."""
from azureml.training.tabular.featurization.text.wordembedding_transformer import WordEmbeddingTransformer
