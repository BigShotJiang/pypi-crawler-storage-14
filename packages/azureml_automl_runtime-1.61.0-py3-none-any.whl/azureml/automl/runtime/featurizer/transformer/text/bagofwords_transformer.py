# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------
"""Generic bag of words transformer."""
from azureml.training.tabular.featurization.text.bagofwords_transformer import BagOfWordsTransformer
