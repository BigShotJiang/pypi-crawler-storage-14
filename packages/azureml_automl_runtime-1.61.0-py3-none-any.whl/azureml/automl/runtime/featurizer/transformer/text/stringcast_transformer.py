# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------
"""Cast input to string."""
from azureml.training.tabular.featurization.text.stringcast_transformer import StringCastTransformer
