# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------
"""Abstract MultiClass target encoder."""
from azureml.training.tabular.featurization.generic.abstract_multiclass_target_encoder import (
    AbstractMultiClassTargetEncoder,
)
