# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------
"""Add boolean imputation marker for values that are imputed."""
from azureml.training.tabular.featurization.generic.imputation_marker import ImputationMarker
