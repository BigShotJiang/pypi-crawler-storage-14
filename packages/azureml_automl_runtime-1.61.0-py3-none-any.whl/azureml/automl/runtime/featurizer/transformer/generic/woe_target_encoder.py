# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------
"""Weight of Evidence target encoder."""
from azureml.training.tabular.featurization.generic.woe_target_encoder import WoEBasedTargetEncoder
