# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------
"""Generic count based target encoder."""
from azureml.training.tabular.featurization.generic.countbased_target_encoder import CountBasedTargetEncoder
