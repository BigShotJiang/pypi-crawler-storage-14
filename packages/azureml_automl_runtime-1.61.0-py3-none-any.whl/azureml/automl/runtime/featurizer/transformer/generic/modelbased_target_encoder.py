# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------
"""Generic target encoder."""
from azureml.training.tabular.featurization.generic.modelbased_target_encoder import ModelBasedTargetEncoder
