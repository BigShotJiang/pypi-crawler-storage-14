# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------
"""Generic cross validation target encoder."""
from azureml.training.tabular.featurization.generic.crossvalidation_target_encoder import CrossValidationTargetEncoder
