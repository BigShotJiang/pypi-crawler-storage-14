# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------
"""Base logger class for all the transformers."""
from azureml.training.tabular.featurization._azureml_transformer import AzureMLTransformer as AutoMLTransformer
