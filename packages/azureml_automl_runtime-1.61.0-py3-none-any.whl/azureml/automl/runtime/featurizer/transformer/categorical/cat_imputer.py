# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------
"""Imputer for missing values in Categorical data."""
from azureml.training.tabular.featurization.categorical.cat_imputer import CatImputer
