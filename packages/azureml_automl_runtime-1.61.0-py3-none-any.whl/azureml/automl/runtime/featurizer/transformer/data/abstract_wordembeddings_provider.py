# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------
"""Base class for providing word embeddings."""
from azureml.training.tabular.featurization.data.abstract_wordembeddings_provider import AbstractWordEmbeddingsProvider
