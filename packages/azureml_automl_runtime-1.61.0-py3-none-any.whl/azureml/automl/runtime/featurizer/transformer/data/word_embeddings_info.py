# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------
"""Holder for embedding information."""
from azureml.training.tabular.featurization.data.word_embeddings_info import EmbeddingInfo, WordEmbeddingsInfo
