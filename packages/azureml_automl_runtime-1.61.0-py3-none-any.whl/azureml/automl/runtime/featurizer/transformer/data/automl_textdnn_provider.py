# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------
"""AutoML word embeddings provider."""
from azureml.training.tabular.featurization.data.pretrained_dnn_provider import \
    PretrainedDNNProvider as AutoMLPretrainedDNNProvider
