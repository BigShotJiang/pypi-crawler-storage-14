# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------
"""AutoML word embeddings provider."""
from azureml.training.tabular.featurization.data.wordembeddings_provider import \
    WordEmbeddingsProvider as AutoMLEmbeddingsProvider
