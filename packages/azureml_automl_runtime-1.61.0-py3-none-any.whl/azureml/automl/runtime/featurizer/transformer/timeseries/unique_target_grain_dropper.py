# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------
"""Drop unique target value grains from dataset."""
from azureml.training.tabular.featurization.timeseries.unique_target_grain_dropper import UniqueTargetGrainDropper
