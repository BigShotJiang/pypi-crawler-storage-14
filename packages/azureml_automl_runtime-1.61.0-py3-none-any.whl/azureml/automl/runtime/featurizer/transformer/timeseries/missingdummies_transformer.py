# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------
"""Add columns indicating corresponding numeric columns have NaN."""
from azureml.training.tabular.featurization.timeseries.missingdummies_transformer import MissingDummiesTransformer
