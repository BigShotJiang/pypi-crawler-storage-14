# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------
"""
Differencing the data.
"""

from azureml.training.tabular.featurization.timeseries.stationary_featurizer import StationaryFeaturizer
