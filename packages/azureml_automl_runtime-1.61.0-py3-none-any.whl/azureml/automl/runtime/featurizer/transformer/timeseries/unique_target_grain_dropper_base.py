# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------
"""Base class for unique target value grains dropper."""
from azureml.training.tabular.featurization.timeseries.unique_target_grain_dropper_base import (
    UniqueTargetGrainDropperBase
)
