# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------
from azureml.training.tabular.featurization.timeseries._distributed.aggregate_transformer \
    import AutoMLAggregateTransformer
