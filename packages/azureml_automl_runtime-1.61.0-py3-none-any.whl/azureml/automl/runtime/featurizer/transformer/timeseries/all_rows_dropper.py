# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------
"""The transform, dropping all rows."""
from azureml.training.tabular.featurization.timeseries.all_rows_dropper import AllRowsDropper
