# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------
from azureml.training.tabular.featurization.timeseries._distributed.aggregated_transformer_factory import (
    AggregatedTransformerFactory
)
