# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------
from azureml.automl.runtime.featurizer.transformer.timeseries._distributed.aggregate_transformer \
    import AutoMLAggregateTransformer
from azureml.automl.runtime.featurizer.transformer.timeseries._distributed.aggregated_transformer_factory import (
    AggregatedTransformerFactory
)
