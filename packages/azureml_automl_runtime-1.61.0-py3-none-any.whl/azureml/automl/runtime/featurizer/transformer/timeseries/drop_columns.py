# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------
"""Drop columns from dataset."""
from azureml.training.tabular.featurization.timeseries.drop_columns import DropColumns
