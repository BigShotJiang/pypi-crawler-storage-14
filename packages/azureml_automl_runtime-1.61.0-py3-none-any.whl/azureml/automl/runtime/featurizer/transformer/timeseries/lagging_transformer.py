# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------
"""Transforms the input data by adding lagging features."""
from azureml.training.tabular.featurization.timeseries.lagging_transformer import LaggingTransformer
