# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------
"""Encode categorical columns with integer codes."""
from azureml.training.tabular.featurization.timeseries.numericalize_transformer import NumericalizeTransformer
