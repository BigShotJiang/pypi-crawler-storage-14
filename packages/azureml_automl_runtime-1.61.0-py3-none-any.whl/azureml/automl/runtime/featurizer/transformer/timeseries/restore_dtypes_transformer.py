# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------
"""Fix the dtypes after the infertence."""
from azureml.training.tabular.featurization.timeseries.restore_dtypes_transformer import RestoreDtypesTransformer
