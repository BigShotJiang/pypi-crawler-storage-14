# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------
from azureml.training.tabular.featurization.timeseries._distributed._distributed_timeseries_util \
    import convert_grain_dict_to_str, collate_indicator_column_data_dictionaries
