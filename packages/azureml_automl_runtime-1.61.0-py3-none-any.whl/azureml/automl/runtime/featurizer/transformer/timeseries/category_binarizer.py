# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------
"""One-hot encoding for categorical columns."""
from azureml.training.tabular.featurization.timeseries.category_binarizer import CategoryBinarizer
