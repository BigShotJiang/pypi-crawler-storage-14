# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------
"""Aggregated grain dropper for distributed tasks."""
from azureml.training.tabular.featurization.timeseries._distributed.aggregated_grain_dropper import (
    AggregatedGrainDropper
)
