# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------
"""Drop grains from dataset."""
from azureml.training.tabular.featurization.timeseries.short_grain_dropper import ShortGrainDropper
