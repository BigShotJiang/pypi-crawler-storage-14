# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------
from azureml.training.tabular.models.forecasting_pipeline_wrapper_base \
    import ForecastingPipelineWrapperBase as ForecastModelWrapperBase
