# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------
from azureml.training.tabular.models._timeseries._prophet_model import ProphetModel, IMPORT_ERROR
