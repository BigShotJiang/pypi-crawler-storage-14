# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------
"""The wrapper for Exponential Smoothing models."""
from azureml.training.tabular.models._timeseries._exponential_smoothing import ExponentialSmoothing
