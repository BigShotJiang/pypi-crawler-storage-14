# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------
"""The abstract class for fitting one model per grain."""
from azureml.training.tabular.models._timeseries._multi_grain_forecast_base import _MultiGrainForecastBase
