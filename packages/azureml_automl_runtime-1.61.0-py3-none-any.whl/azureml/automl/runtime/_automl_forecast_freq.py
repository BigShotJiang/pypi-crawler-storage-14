# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------
"""The AutoMLForecastFreq object to handle the freq and its string representation."""
from azureml.training.tabular.timeseries._automl_forecast_freq import AutoMLForecastFreq
