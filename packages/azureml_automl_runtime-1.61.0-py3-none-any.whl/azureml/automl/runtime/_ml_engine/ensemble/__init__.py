# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------
"""Ensemble selection API module."""

from .ensemble_selector import EnsembleSelector
