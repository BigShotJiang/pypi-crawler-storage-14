import aiohttp
import asyncio
import sys
import os
import time
from kalameet.core.base import BasePlugin
from kalameet.core.logger import Logger
from kalameet.core.interface import Colors, UI 
from kalameet.core.engine import StealthMode
from kalameet.config import settings
from kalameet.core.translate import _

class dirbustFlashPlugin(BasePlugin):
    meta = {
        'name': 'dirbust-flash',
        'description': '',
        'author': 'rhkapota'
    }

    def __init__(self):
        super().__init__()
        self.logger = Logger(session_name="dirbust-flash")
        self.stealth = StealthMode()
        self.found_count = 0

    def add_arguments(self, parser):
        parser.add_argument("-t", "--target", required=True, help="Target URL")
        parser.add_argument("-d", "--data", help="Custom wordlist path (Optional)")
        parser.add_argument("--concurrency", type=int, default=50, help="Concurrent requests (Default: 50)[Max: 200]")

    async def fetch(self, session, url, semaphore):
        async with semaphore:
            try:
                headers = self.stealth.get_headers(url)
                async with session.get(url, headers=headers, allow_redirects=False, timeout=settings.DEFAULT_TIMEOUT, ssl=False) as response:
                    if response.status in [200, 301, 302, 403, 500]:
                        content = await response.read()
                        return (response.status, url, len(content))
            except:
                pass
        return None

    async def start_bombardment(self, target, wordlist_path, concurrency):
        UI.header(f"DIRECTORY BUSTER - FLASH")

        print(f"[{Colors.GREEN}+{Colors.ENDC}] Target lock: {Colors.GREEN}{target}{Colors.ENDC}")
        print(f"[{Colors.GREEN}+{Colors.ENDC}] Stealth Mode: {Colors.GREEN}Active{Colors.ENDC}")
    
        print(f"[{Colors.GREEN}+{Colors.ENDC}] Source: {os.path.basename(wordlist_path)}")

        try:
            with open(wordlist_path, 'r', encoding='utf-8', errors='ignore') as f:
                paths = [line.strip() for line in f if line.strip()]
        except Exception as e: 
            UI.print_error(f"Error reading wordlist: {e}")
            return

        print(f"[{Colors.GREEN}*{Colors.ENDC}] Loaded {len(paths)} paths. Scanning with {concurrency} concurrency...")
        
        semaphore = asyncio.Semaphore(concurrency)
        connector = aiohttp.TCPConnector(limit=concurrency, ssl=False)

        async with aiohttp.ClientSession(connector=connector) as session:
            tasks = []
            for path in paths:
                full_url = f"{target}/{path}" if not target.endswith('/') else f"{target}{path}"
                task = asyncio.create_task(self.fetch(session, full_url, semaphore))
                tasks.append(task)

            with UI.progress_bar() as progress:
                task_id = progress.add_task(f"[cyan]Scanning...", total=len(paths))
                
                for task in asyncio.as_completed(tasks):
                    result = await task
                    progress.advance(task_id, 1)
                    
                    if result:
                        code, url, length = result
                        self.found_count += 1
                        
                        if code == 200:
                            msg = f"[[bold green]+[/]] [[green]{code}[/]] [bold white]Found    :[/] [green]{url}[/]"
                            progress.console.print(msg)
                        elif code == 403:
                            msg = f"[[bold yellow]![/]] [[yellow]{code}[/]] [bold red]Forbidden:[/] [white]{url}[/]"
                            progress.console.print(msg)
                        elif code in [301, 302]:
                            msg = f"[[bold blue]*[/]] [[blue]{code}[/]] [bold magenta]Redirect :[/] [dim white]{url}[/]"
                            progress.console.print(msg)
                        elif code >= 500:
                            msg = f"[[bold red]X[/]] [[red]{code}[/]] [bold red]Error    :[/] [dim]{url}[/]"
                            progress.console.print(msg)

                        status_type = "Found" if code == 200 else "Info"
                        self.logger.log("Dirbust-Flash", status_type, f"Status {code}", {"url": url})

    def run(self, args):
        target = args.target
        if not target.startswith("http"): target = "http://" + target

        if args.data:
            wlist = args.data
        else:
            wlist = os.path.join(settings.WORDLIST_DIR, settings.WORDLISTS['dirs'])

        MAX_CONCURRENCY = 200
        if args.concurrency > MAX_CONCURRENCY:
            print(f"[{Colors.WARNING}!{Colors.ENDC}] {Colors.WARNING}Warning: Concurrency {args.concurrency} exceeds safe limit.{Colors.ENDC}")
            print(f"[{Colors.WARNING}!{Colors.ENDC}] Capping concurrency at {MAX_CONCURRENCY} to prevent instability.{Colors.ENDC}")
            args.concurrency = MAX_CONCURRENCY

        self.found_count = 0

        if sys.platform == 'win32':
            asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())

        start_time = time.time()
        try:
            asyncio.run(self.start_bombardment(target, wlist, args.concurrency))

            end_time = time.time()
            elapsed_time = end_time - start_time

            print("-" * 60)
            UI.print_success(f"Dirbust Complete. Total Found: {self.found_count}")
            UI.print_success(f"Execution Time: {elapsed_time:.2f} seconds")
        except KeyboardInterrupt:
            print(f"\n[{Colors.FAIL}-{Colors.ENDC}] {Colors.FAIL}{_('stopped')}{Colors.ENDC}")
            os._exit(0)