import requests
import concurrent.futures
import os
import time
import sys
from kalameet.core.base import BasePlugin
from kalameet.core.logger import Logger
from kalameet.core.interface import UI, Colors
from kalameet.core.engine import StealthMode
from kalameet.config import settings
from kalameet.core.translate import _

class dirbustPlugin(BasePlugin):
    meta = {
        'name': 'dirbust',
        'description': '',
        'author': 'rhkapota'
    }

    def __init__(self):
        super().__init__()
        self.logger = Logger(session_name="dirbust")
        self.stealth = StealthMode()
        self.found_count = 0 

    def add_arguments(self, parser):
        parser.add_argument("-t", "--target", required=True, help="Target URL")
        parser.add_argument("-d", "--data", help="Custom wordlist path (Optional)")
        parser.add_argument("-th", "--threads", type=int, default=10, help="Number of threads (Default: 10)[Max: 50]")

    def check_path(self, target_url, path):
        full_url = f"{target_url}/{path}"
        try:
            headers = self.stealth.get_headers(target_url)
            r = requests.head(full_url, headers=headers, timeout=settings.DEFAULT_TIMEOUT, allow_redirects=False)
            if r.status_code != 404:
                return (r.status_code, full_url)
        except: pass
        return None

    def run(self, args):
        target = args.target.rstrip('/')
        if not target.startswith("http"): target = "http://" + target
        
        UI.header(f"DIRECTORY BUSTER")
        
        print(f"[{Colors.GREEN}+{Colors.ENDC}] Target lock: {Colors.GREEN}{target}{Colors.ENDC}")
        print(f"[{Colors.GREEN}+{Colors.ENDC}] Stealth Mode: {Colors.GREEN}Active{Colors.ENDC}")
        
        if args.data:
            wordlist_path = args.data
            print(f"[{Colors.GREEN}+{Colors.ENDC}] Source: Custom Wordlist ({os.path.basename(wordlist_path)})")
        else:
            wordlist_path = os.path.join(settings.WORDLIST_DIR, settings.WORDLISTS['dirs'])
            print(f"[{Colors.GREEN}+{Colors.ENDC}] Source: Default Wordlist (directory.txt)")

        try:
            with open(wordlist_path, 'r', encoding='utf-8', errors='ignore') as f:
                paths = [line.strip() for line in f if line.strip()]
        except Exception as e: 
            UI.print_error(f"Error reading wordlist: {e}")
            return

        MAX_THREADS = 50
        if args.threads > MAX_THREADS:
            print(f"[{Colors.WARNING}!{Colors.ENDC}] {Colors.WARNING}Warning: {args.threads} threads requested.{Colors.ENDC} Capping at {MAX_THREADS} for stability.")
            args.threads = MAX_THREADS

        print(f"[{Colors.GREEN}*{Colors.ENDC}] Loaded {len(paths)} paths. Scanning with {args.threads} threads...")
        
        self.found_count = 0
        start_time = time.time()
        with UI.progress_bar() as progress:
            task = progress.add_task(f"[cyan]Scanning...", total=len(paths))
            
            with concurrent.futures.ThreadPoolExecutor(max_workers=args.threads) as executor:
                futures = {executor.submit(self.check_path, target, path): path for path in paths}
                
                for future in concurrent.futures.as_completed(futures):
                    progress.advance(task, 1)
                    try:
                        result = future.result()
                        if result:
                            code, url = result
                            self.found_count += 1
                            
                            if code == 200:
                                msg = f"[[bold green]+[/]] [[green]{code}[/]] [bold white]Found    :[/] [green]{url}[/]"
                                progress.console.print(msg)
                            elif code == 403:
                                msg = f"[[bold yellow]![/]] [[yellow]{code}[/]] [bold red]Forbidden:[/] [white]{url}[/]"
                                progress.console.print(msg)
                            elif code in [301, 302]:
                                msg = f"[[bold blue]*[/]] [[blue]{code}[/]] [bold magenta]Redirect :[/] [dim white]{url}[/]"
                                progress.console.print(msg)
                            elif code >= 500:
                                msg = f"[[bold red]X[/]] [[red]{code}[/]] [bold red]Error    :[/] [dim]{url}[/]"
                                progress.console.print(msg)
                            
                            status_type = "Found" if code == 200 else "Info"
                            self.logger.log("Dirbuster", status_type, f"Status {code}", {"url": url})
                    except: pass
        
            end_time = time.time() 
            elapsed_time = end_time - start_time

            print("-" * 60)
            UI.print_success(f"Dirbust Complete. Total Found: {self.found_count}")
            UI.print_success(f"Execution Time: {elapsed_time:.2f} seconds")