import requests
import json
import os
from kalameet.core.base import BasePlugin
from kalameet.core.logger import Logger
from kalameet.core.interface import UI, Colors
from kalameet.config import settings
from kalameet.core.engine import StealthMode

class subdomainPlugin(BasePlugin):
    meta = {
        'name': 'subdomain',
        'description': '',
        'author': 'rhkapota'
    }

    def __init__(self):
        super().__init__()
        self.logger = Logger(session_name="subdomain")
        self.subdomains = set()
        self.stealth = StealthMode()

    def add_arguments(self, parser):
        parser.add_argument("-t", "--target", required=True, help="Target Domain (e.g. google.com)")

    def query_crtsh(self, domain):
        with UI.console.status(f"[bold cyan]Querying Certificate Logs (crt.sh) for {domain}...[/]", spinner="dots"):
            url = f"https://crt.sh/?q=%.{domain}&output=json"
            try:
                headers = self.stealth.get_headers()
                r = requests.get(url, headers=headers, timeout=30)
                
                if r.status_code != 200:
                    UI.print_error(f"crt.sh failed (Status: {r.status_code})")
                    return False

                data = r.json()
                for entry in data:
                    name_value = entry['name_value']
                    for sub in name_value.split('\n'):
                        if sub.endswith(domain) and "*" not in sub:
                            self.subdomains.add(sub.lower())
                
                UI.print_success(f"crt.sh analysis complete.")
                return True

            except Exception as e:
                UI.print_error(f"crt.sh Error: {e}")
                return False

    def query_hackertarget(self, domain):
        with UI.console.status(f"[bold cyan]Querying HackerTarget API for {domain}...[/]", spinner="bouncingBall"):
            url = f"https://api.hackertarget.com/hostsearch/?q={domain}"
            try:
                headers = self.stealth.get_headers()
                r = requests.get(url, headers=headers, timeout=20)
                
                if "error" in r.text.lower():
                    return False

                for line in r.text.split('\n'):
                    if "," in line:
                        sub = line.split(',')[0]
                        if sub.endswith(domain):
                            self.subdomains.add(sub.lower())
                
                UI.print_success(f"HackerTarget analysis complete.")
                return True
            except:
                return False

    def run(self, args):
        domain = args.target.replace("https://", "").replace("http://", "").split('/')[0]
        all_good = True
        
        UI.header(f"SUBDOMAIN HUNTER")
        print(f"[{Colors.GREEN}+{Colors.ENDC}] Target lock: {Colors.GREEN}{domain}{Colors.ENDC}")
        print(f"[{Colors.GREEN}+{Colors.ENDC}] Stealth Mode: {Colors.GREEN}Active{Colors.ENDC}")
        
        success = self.query_crtsh(domain)
        
        if not success or len(self.subdomains) < 5:
            print(f"[{Colors.WARNING}!{Colors.ENDC}] {Colors.YELLOW}Results too low or failed.{Colors.YELLOW} Switching to backup source...{Colors.ENDC}")
            self.query_hackertarget(domain)

        if self.subdomains:
            UI.print_success(f"Found {len(self.subdomains)} unique subdomains:")
            
            sorted_subs = sorted(list(self.subdomains))
            
            limit = 500
            for i, sub in enumerate(sorted_subs):
                if i < limit:
                    print(f"    {Colors.MAGENTA}{sub}{Colors.ENDC}")
                    self.logger.log("Subdomain", "Found", sub)
            
            if len(sorted_subs) > limit:
                print(f"    ... and {Colors.BOLD}{len(sorted_subs) - limit}{Colors.ENDC} more.")
                outfile = os.path.join(settings.OUTPUT_DIR, f"subs_{domain}.txt")
                try:
                    with open(outfile, 'w') as f:
                        f.write('\n'.join(sorted_subs))
                    print("")
                    print(f"[{Colors.GREEN}+{Colors.ENDC}] Full list saved to: {outfile}{Colors.ENDC}")
                except:
                    UI.print_error("Failed to save output file.")
            all_good = True
        else:
            UI.print_error("No subdomains found. Target might be protected or offline.")
            all_good = False

        if all_good:
            print("")
            print(f"[{Colors.GREEN}✓{Colors.ENDC}] {Colors.GREEN}Scanning Complete{Colors.ENDC}")
        else:
            print("")
            print(f"[{Colors.RED}x{Colors.ENDC}] Issues Detected")