import os
from setuptools import setup, find_packages

# [PENTING] Mendapatkan path absolut dari folder setup.py
SETUP_DIR = os.path.dirname(os.path.abspath(__file__))

def get_requirements():
    """
    [FIX] Menggunakan jalur absolut untuk requirements.txt
    Ini mengatasi masalah saat build environment gagal menemukan file
    """
    # Menggabungkan path setup.py dengan nama file
    requirements_path = os.path.join(SETUP_DIR, 'requirements.txt')
    
    # Cek apakah requirements.txt ada di root
    if not os.path.exists(requirements_path):
        # Jika tidak ada, kemungkinan package berada di folder /kalameet
        requirements_path = os.path.join(SETUP_DIR, '../requirements.txt')
        
        if not os.path.exists(requirements_path):
            raise FileNotFoundError(f"requirements.txt not found at {requirements_path}")

    with open(requirements_path) as f:
        return [line.strip() for line in f if line.strip() and not line.startswith('#')]

setup(
    name='kalameet',
    version='5.2.0', # Updated version
    description='Autonomous Cyber Security Framework',
    author='rhkapota',
    author_email='kalameetttt@gmail.com',
    url='https://github.com/rhkapota/kalameet',
    license='MIT',
    
    # Mencari package 'kalameet'
    packages=find_packages(),
    
    # Instalasi dependencies (sudah diperbaiki pathnya)
    install_requires=get_requirements(),
    
    # [FIX] Entry Point yang benar ke file cli.py
    entry_points={
        'console_scripts': [
            'kalameet = kalameet.cli:main', # Target: kalameet/cli.py -> main()
        ],
    },
    
    # [WAJIB] Instruksikan setuptools untuk mencari file data (assets) via MANIFEST.in
    include_package_data=True, 
    
    python_requires='>=3.8',
)