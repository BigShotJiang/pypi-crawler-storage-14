# lll-simple-ai-shared

AI 相关数据类型定义

## Installation

```bash
pip install lll-simple-ai-shared
```
