# _*_ coding: utf-8 _*_
#
# hspylib-kafman v0.9.155
#
# Package: main.kafman
"""Package initialization."""

__all__ = [
    'core', 
    'views'
]
__version__ = '0.9.155'
