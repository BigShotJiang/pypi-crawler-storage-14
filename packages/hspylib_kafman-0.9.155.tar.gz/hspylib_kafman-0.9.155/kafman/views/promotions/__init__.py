# _*_ coding: utf-8 _*_
#
# hspylib-kafman v0.9.155
#
# Package: main.kafman.views.promotions
"""Package initialization."""

__all__ = [
    'form_area', 
    'form_pane'
]
__version__ = '0.9.155'
