# _*_ coding: utf-8 _*_
#
# hspylib-kafman v0.9.155
#
# Package: main.kafman.views.dialogs
"""Package initialization."""

__all__ = [
    'filters_dialog', 
    'settings_dialog'
]
__version__ = '0.9.155'
