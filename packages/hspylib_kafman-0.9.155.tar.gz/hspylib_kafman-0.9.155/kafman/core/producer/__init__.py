# _*_ coding: utf-8 _*_
#
# hspylib-kafman v0.9.155
#
# Package: main.kafman.core.producer
"""Package initialization."""

__all__ = [
    'producer_config', 
    'producer_worker'
]
__version__ = '0.9.155'
