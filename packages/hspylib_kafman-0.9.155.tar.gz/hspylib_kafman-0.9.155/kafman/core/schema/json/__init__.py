# _*_ coding: utf-8 _*_
#
# hspylib-kafman v0.9.155
#
# Package: main.kafman.core.schema.json
"""Package initialization."""

__all__ = [
    'json_parser', 
    'json_schema', 
    'json_type', 
    'property'
]
__version__ = '0.9.155'
