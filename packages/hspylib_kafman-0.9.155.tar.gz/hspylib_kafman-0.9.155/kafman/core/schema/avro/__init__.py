# _*_ coding: utf-8 _*_
#
# hspylib-kafman v0.9.155
#
# Package: main.kafman.core.schema.avro
"""Package initialization."""

__all__ = [
    'avro_schema', 
    'avro_type', 
    'field'
]
__version__ = '0.9.155'
