# _*_ coding: utf-8 _*_
#
# hspylib-kafman v0.9.155
#
# Package: main.kafman.core.exception
"""Package initialization."""

__all__ = [
    'exceptions'
]
__version__ = '0.9.155'
