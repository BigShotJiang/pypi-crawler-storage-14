"""
Tests for SetBit Python SDK
"""
