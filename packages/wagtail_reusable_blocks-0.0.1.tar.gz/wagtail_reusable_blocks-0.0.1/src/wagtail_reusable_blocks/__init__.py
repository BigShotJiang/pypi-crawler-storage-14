"""Reusable content blocks with slot-based templating for Wagtail CMS."""
