# imports from this package
import crackpy.crack_detection
import crackpy.crack_detection.utils
import crackpy.fracture_analysis
import crackpy.structure_elements
from .logging_config import setup_logging

setup_logging()

# package information
__version__ = "1.3.0"
