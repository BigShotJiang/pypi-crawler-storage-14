import crackpy.crack_detection.pipeline.pipeline
