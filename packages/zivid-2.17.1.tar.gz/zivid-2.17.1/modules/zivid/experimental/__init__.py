"""Experimental module. These APIs may change in the future."""

from zivid.experimental._pixel_mapping import PixelMapping
