#pragma once

#include <ZividPython/Wrappers.h>

namespace ZividPython::Toolbox
{
    void wrapAsSubmodule(pybind11::module &dest);
} // namespace ZividPython::Toolbox
