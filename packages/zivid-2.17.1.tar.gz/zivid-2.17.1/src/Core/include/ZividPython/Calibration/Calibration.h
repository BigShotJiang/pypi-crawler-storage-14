#pragma once

#include <ZividPython/Wrappers.h>

namespace ZividPython::Calibration
{
    void wrapAsSubmodule(pybind11::module &dest);
} // namespace ZividPython::Calibration
