from typing import Dict
import time

class CooldownManager:
    """
    Simple per-command per-user cooldown manager.
    Usage:
      cd = CooldownManager()
      if not cd.try_use("ban", user_id, 5000): -> still cooldown
    """

    def __init__(self):
        self._cds: Dict[str, Dict[int, float]] = {}

    def try_use(self, command: str, user_id: int, ms: int) -> bool:
        now = time.time() * 1000.0
        if command not in self._cds:
            self._cds[command] = {}
        user_map = self._cds[command]
        expires = user_map.get(user_id, 0)
        if now < expires:
            return False
        user_map[user_id] = now + ms
        return True

    def time_left(self, command: str, user_id: int) -> float:
        now = time.time() * 1000.0
        expires = self._cds.get(command, {}).get(user_id, 0)
        return max(0.0, expires - now)
