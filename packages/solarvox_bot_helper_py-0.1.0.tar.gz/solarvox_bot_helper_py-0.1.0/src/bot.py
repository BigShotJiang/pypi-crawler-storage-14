from typing import Optional
import discord
from discord.ext import commands
import importlib
import pathlib
import sys
from .command_loader import load_commands_from_folder
from .event_loader import load_events_from_folder

class SolarVoxBot(commands.Bot):
    def __init__(self, *, intents: discord.Intents | None = None, **kwargs):
        intents = intents or discord.Intents.default()
        super().__init__(command_prefix="!", intents=intents, **kwargs)
        # can store arbitrary metadata
        self.package_versions = {}

def create_bot(token: str, commands_path: Optional[str] = None, events_path: Optional[str] = None, intents: Optional[discord.Intents] = None) -> SolarVoxBot:
    """
    Create and return a SolarVoxBot instance. This will load commands/events if paths are provided.
    Each command module should expose async def setup(bot: SolarVoxBot) to register itself.
    Each event module should expose async def setup(bot: SolarVoxBot) or define `name` and `run` (sync/async).
    """
    bot = SolarVoxBot(intents=intents)
    # load commands
    if commands_path:
        load_commands_from_folder(bot, commands_path)

    # load events
    if events_path:
        load_events_from_folder(bot, events_path)

    # login is intentionally not called here; caller should call bot.run(token)
    bot.token = token
    return bot
