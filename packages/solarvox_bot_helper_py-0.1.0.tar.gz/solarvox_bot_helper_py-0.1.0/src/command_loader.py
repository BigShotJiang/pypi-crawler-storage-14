import importlib.util
import importlib.machinery
import importlib
import pathlib
import sys
from typing import Optional
import os
import traceback
from .bot import SolarVoxBot

def _import_module_from_path(path: str):
    path_obj = pathlib.Path(path)
    spec = importlib.util.spec_from_file_location(path_obj.stem, str(path_obj))
    if spec is None:
        raise ImportError(f"Cannot import {path}")
    module = importlib.util.module_from_spec(spec)
    loader = spec.loader
    assert loader is not None
    loader.exec_module(module)
    return module

def load_commands_from_folder(bot: SolarVoxBot, folder: str):
    """
    Loads all .py files in folder and calls their async setup(bot) if present.
    Command modules should expose:
      async def setup(bot): 
          # register commands via app_commands or add_cog
    """
    folder_path = pathlib.Path(folder)
    if not folder_path.exists():
        print(f"[SolarVox] commands folder not found: {folder}")
        return

    for file in folder_path.iterdir():
        if file.is_file() and file.suffix == ".py":
            try:
                mod = _import_module_from_path(str(file))
                if hasattr(mod, "setup"):
                    maybe = mod.setup
                    # support async or sync setup
                    if callable(maybe):
                        import asyncio
                        result = maybe(bot)
                        if hasattr(result, "__await__"):
                            # coroutine
                            asyncio.get_event_loop().create_task(result)
                        # else sync - already executed
                else:
                    print(f"[SolarVox] command module {file.name} has no setup(bot)")
            except Exception:
                print(f"[SolarVox] Failed to load command {file.name}")
                traceback.print_exc()
