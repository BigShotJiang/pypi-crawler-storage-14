import pathlib
import importlib.util
import traceback
from .bot import SolarVoxBot
import inspect

def _import_module_from_path(path: str):
    path_obj = pathlib.Path(path)
    spec = importlib.util.spec_from_file_location(path_obj.stem, str(path_obj))
    if spec is None:
        raise ImportError(f"Cannot import {path}")
    module = importlib.util.module_from_spec(spec)
    loader = spec.loader
    assert loader is not None
    loader.exec_module(module)
    return module

def load_events_from_folder(bot: SolarVoxBot, folder: str):
    """
    Loads event modules. Event module can define:
      - async def setup(bot):  # register listeners inside
    Or:
      - name = "ready"
        async def run(bot, *args): ...
      and loader will attach a listener to dispatch run(bot, *args)
    """
    folder_path = pathlib.Path(folder)
    if not folder_path.exists():
        print(f"[SolarVox] events folder not found: {folder}")
        return

    for file in folder_path.iterdir():
        if file.is_file() and file.suffix == ".py":
            try:
                mod = _import_module_from_path(str(file))
                if hasattr(mod, "setup"):
                    res = mod.setup(bot)
                    import asyncio
                    if hasattr(res, "__await__"):
                        asyncio.get_event_loop().create_task(res)
                    continue

                name = getattr(mod, "name", None)
                run = getattr(mod, "run", None)
                if name and callable(run):
                    # attach as a listener
                    if inspect.iscoroutinefunction(run):
                        bot.add_listener(run, name)
                    else:
                        # wrap sync function
                        async def _wrapper(*args, __run=run, __bot=bot, **kwargs):
                            try:
                                __run(__bot, *args, **kwargs)
                            except Exception as e:
                                print("[SolarVox] Event handler error:", e)
                        bot.add_listener(_wrapper, name)
                else:
                    print(f"[SolarVox] event module {file.name} missing setup or (name+run)")
            except Exception:
                print(f"[SolarVox] Failed to load event {file.name}")
                traceback.print_exc()
