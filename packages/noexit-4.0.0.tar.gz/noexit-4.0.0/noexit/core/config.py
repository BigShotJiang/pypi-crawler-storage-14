CONFIG = {
    "patch_builtin_exit": True,
    "patch_sys_exit": True,
    "patch_os_exit": True,
    "patch_exec": True,
    "patch_eval": True,
    "patch_ast": True,
    "patch_bytecode": True,
    "patch_imports": True,

    # يسمح لك إضافة Plugins إضافية
    "enable_plugins": True,
}
