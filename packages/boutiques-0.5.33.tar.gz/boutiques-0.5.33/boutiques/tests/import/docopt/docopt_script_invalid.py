"""
Sample Docopt script for bad docopt script import testing

Usage!!!:
  test_import A --y

Options:
  -x          X desc
"""
