"""
Sample Docopt script for bosh import testing

Usage:
  test_import X Y Z [options]

Options:
  -a --ay         A
  -b --bee        B
  -c --cee        C
  -h --help       Help descriptions
  -v --version    Versions
"""
