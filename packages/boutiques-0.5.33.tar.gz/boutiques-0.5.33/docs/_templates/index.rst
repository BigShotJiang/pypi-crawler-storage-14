
.. toctree::
    :caption: Boutiques documentation
    :maxdepth: 2

    cli
    pythonApi
