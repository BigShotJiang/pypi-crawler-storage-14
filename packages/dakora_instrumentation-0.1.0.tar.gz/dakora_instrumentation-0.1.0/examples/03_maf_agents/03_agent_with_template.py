#!/usr/bin/env python3
"""
03 - Agent with Template: Use Dakora templates for agent instructions.

Shows how to use Dakora's template management to define agent instructions,
enabling version tracking and A/B testing of different prompts.

WHAT YOU'LL LEARN:
- Using templates for agent instructions
- Template version tracking in traces
- Parameterized agent behavior

PREREQUISITES:
    pip install 'dakora-instrumentation[maf]'

ENVIRONMENT VARIABLES:
    DAKORA_API_KEY - Your Dakora project API key
    OPENAI_API_KEY - Your OpenAI API key

USES TEMPLATES:
    faq_responder - FAQ support agent
    technical_documentation - Code documentation agent
"""

import asyncio
import os

from agent_framework import ChatAgent
from agent_framework.openai import OpenAIChatClient
from dakora_instrumentation.frameworks.maf import DakoraIntegration
from dotenv import load_dotenv

from dakora_client import Dakora

load_dotenv()


async def main() -> None:
    """Run agents with Dakora template-driven instructions."""

    # Setup Dakora
    dakora = Dakora(
        api_key=os.getenv("DAKORA_API_KEY", "dk_proj_..."),
        base_url=os.getenv("DAKORA_BASE_URL", "http://localhost:8000"),
    )

    middleware = DakoraIntegration.setup(dakora, enable_sensitive_data=True)

    print("=" * 60)
    print("MAF Agent with Template Example")
    print("=" * 60)

    model = os.getenv("OPENAI_MODEL", "gpt-4o-mini")

    # Example 1: FAQ agent with customer support focus
    # Note: faq_responder and technical_documentation are default templates
    print("\n" + "-" * 40)
    print("1. FAQ Support Agent (friendly tone)")
    print("-" * 40)

    faq_instructions = await dakora.prompts.render(
        "faq_responder",
        {
            "question": "How do I get started with Dakora?",
            "knowledge_base": """
Dakora is an AI observability platform for managing prompts and tracking LLM usage.

Getting Started:
1. Sign up at dakora.io or self-host the open-source version
2. Create a project and get your API key
3. Install the Python client: pip install dakora-client
4. Initialize the client with your API key
5. Create prompts in the Studio UI or via API

Key Features:
- Prompt versioning and management
- Real-time cost tracking
- OpenTelemetry integration
- Budget controls
            """.strip(),
            "tone": "friendly and encouraging",
            "include_sources": False,
        },
    )
    print(f"   Template: faq_responder v{faq_instructions.version}")

    faq_agent = ChatAgent(
        id="faq-support-agent-v1",
        name="FAQSupportAgent",
        chat_client=OpenAIChatClient(model_id=model),
        instructions=f"You are a helpful support agent. Use this context to help users:\n\n{faq_instructions.text}",
        middleware=[middleware],
    )

    result = await faq_agent.run("I'm new to Dakora. How do I get started?")
    print(f"\n   Response: {result.messages[0].text}")

    # Example 2: Technical documentation agent
    print("\n" + "-" * 40)
    print("2. Documentation Agent (technical tone)")
    print("-" * 40)

    doc_instructions = await dakora.prompts.render(
        "technical_documentation",
        {
            "code_snippet": '''class DakoraClient:
    def __init__(self, api_key: str, base_url: str = "https://api.dakora.io"):
        self.api_key = api_key
        self.base_url = base_url

    async def render(self, template_id: str, inputs: dict) -> RenderResult:
        """Render a prompt template with given inputs."""
        response = await self._post(f"/prompts/{template_id}/render", inputs)
        return RenderResult(**response)''',
            "doc_sections": ["Overview", "Parameters", "Methods", "Examples"],
            "example_count": 1,
            "include_troubleshooting": False,
        },
    )
    print(f"   Template: technical_documentation v{doc_instructions.version}")

    doc_agent = ChatAgent(
        id="documentation-agent-v1",
        name="DocumentationAgent",
        chat_client=OpenAIChatClient(model_id=model),
        instructions=f"You are a technical writer. Generate documentation:\n\n{doc_instructions.text}",
        middleware=[middleware],
    )

    result = await doc_agent.run("Generate the documentation for this code")
    print(f"\n   Response: {result.messages[0].text[:500]}...")

    # Example 3: Same template, different parameters (professional FAQ)
    print("\n" + "-" * 40)
    print("3. FAQ Agent (professional tone)")
    print("-" * 40)

    pro_faq_instructions = await dakora.prompts.render(
        "faq_responder",
        {
            "question": "What are the security features of Dakora?",
            "knowledge_base": """
Dakora Security Features:

Authentication:
- API keys with SHA-256 hashing
- Clerk JWT integration for web UI
- Per-project key isolation

Data Protection:
- Azure Blob Storage with encryption at rest
- PostgreSQL with encrypted connections
- No prompt content stored in logs

Access Control:
- Multi-tenant workspace isolation
- Project-level permissions
- Audit logging for compliance
            """.strip(),
            "tone": "professional and precise",
            "include_sources": True,
        },
    )
    print(f"   Template: faq_responder v{pro_faq_instructions.version}")

    pro_faq_agent = ChatAgent(
        id="enterprise-faq-agent-v1",
        name="EnterpriseFAQAgent",
        chat_client=OpenAIChatClient(model_id=model),
        instructions=f"You are an enterprise support specialist:\n\n{pro_faq_instructions.text}",
        middleware=[middleware],
    )

    result = await pro_faq_agent.run("Tell me about Dakora's security features")
    print(f"\n   Response: {result.messages[0].text}")

    # Cleanup
    print("\nFlushing traces...")
    DakoraIntegration.force_flush()
    await dakora.close()

    print("\n✅ Done! Check Dakora Studio to see:")
    print("   - Each agent execution linked to its template")
    print("   - Templates: faq_responder, technical_documentation")
    print("   - Compare: same template, different parameters")


if __name__ == "__main__":
    asyncio.run(main())
