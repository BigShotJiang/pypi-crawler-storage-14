# amgi-paho-mqtt

:construction: This package is currently under development :construction:

AMGI will be here very soon

## Installation

```
pip install amgi-paho-mqtt==0.23.1
```

## Contact

For questions or suggestions, please contact [jack.burridge@mail.com](mailto:jack.burridge@mail.com).

## License

Copyright 2025 AMGI
