eumetsat\_products\_registry module
===================================

.. automodule:: visusat.eumetsat_products_registry
   :members:
   :undoc-members:
   :show-inheritance:
