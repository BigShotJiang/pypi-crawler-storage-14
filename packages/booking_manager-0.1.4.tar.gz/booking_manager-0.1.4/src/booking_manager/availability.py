from datetime import datetime

class AvailabilityChecker:
    
    def is_available(self, check_in, check_out, existing_bookings):
        #Convert date format to datetime format
        if isinstance(check_in, str):
            check_in = datetime.strptime(check_in, '%Y-%m-%d')
        if isinstance(check_out, str):
            check_out = datetime.strptime(check_out, '%Y-%m-%d')
        
        if check_out <= check_in:
            raise ValueError("Check-out must be after check-in")
        
        #Check for booking dateoverlaps
        for booking in existing_bookings:
            booking_in = booking['check_in']
            booking_out = booking['check_out']
            
            if isinstance(booking_in, str):
                booking_in = datetime.strptime(booking_in, '%Y-%m-%d')
            if isinstance(booking_out, str):
                booking_out = datetime.strptime(booking_out, '%Y-%m-%d')
            
            if check_in < booking_out and check_out > booking_in:
                return False
        
        return True