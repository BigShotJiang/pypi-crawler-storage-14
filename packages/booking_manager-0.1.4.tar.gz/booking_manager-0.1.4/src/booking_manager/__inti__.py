"""
Accommodation Manager Library

A Python library for accommodation booking management including price calculation,
notification formatting, and availability checking.
"""

__version__ = "0.1.0"
__author__ = "Saurabh"

from .calculator import PriceCalculator
from .notifications import NotificationFormatter
from .availability import AvailabilityChecker

__all__ = [
    'PriceCalculator',
    'NotificationFormatter',
    'AvailabilityChecker',
]