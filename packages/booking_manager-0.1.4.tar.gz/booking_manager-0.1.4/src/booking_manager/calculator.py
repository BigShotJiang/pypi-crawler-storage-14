
from datetime import datetime
from decimal import Decimal, ROUND_HALF_UP


class PriceCalculator:
    
    def __init__(self):
        pass
    
    def calculate_total(self, price_per_night, check_in_date, check_out_date):
     
        #Convert strings to datetime if needed
        if isinstance(check_in_date, str):
            check_in = datetime.strptime(check_in_date, '%Y-%m-%d')
        else:
            check_in = check_in_date
        
        if isinstance(check_out_date, str):
            check_out = datetime.strptime(check_out_date, '%Y-%m-%d')
        else:
            check_out = check_out_date
        
        #Validate dates
        if check_out <= check_in:
            raise ValueError("Check-out date must be after check-in date")
        
        #Calculate number of nights
        num_nights = (check_out - check_in).days
        
        #Calculate total price
        price_per_night_decimal = Decimal(str(price_per_night))
        total_price = (price_per_night_decimal * num_nights).quantize(
            Decimal('0.01'), 
            rounding=ROUND_HALF_UP
        )
        
        return {
            'num_nights': num_nights,
            'price_per_night': float(price_per_night_decimal),
            'total_price': float(total_price)
        }