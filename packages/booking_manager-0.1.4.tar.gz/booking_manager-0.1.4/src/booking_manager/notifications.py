from datetime import datetime

class NotificationFormatter:
    def __init__(self, currency='EUR', currency_symbol='€'):
        self.currency = currency
        self.currency_symbol = currency_symbol
    
    #format the notification for the admin approval request
    def format_admin_approval_request(self, booking_data):
        guest_email = booking_data.get('guest_email', 'N/A')
        guest_name = booking_data.get('guest_name', 'N/A')
        property_name = booking_data.get('property_name', 'N/A')
        special_requests = booking_data.get('special_requests', 'None')
        
        message = f"""
BOOKING APPROVAL REQUEST

Dear Administrator,

A new booking request requires your review.

BOOKING DETAILS:
Booking ID: {booking_data.get('booking_id')}
Property: {property_name}
Guest Name: {guest_name}
Guest Email: {guest_email}
Check-in: {booking_data.get('check_in_date')}
Check-out: {booking_data.get('check_out_date')}
Guests: {booking_data.get('num_guests', 1)}
Total Price: {self.currency_symbol}{booking_data.get('total_price'):.2f}

SPECIAL REQUESTS:
{special_requests}

Please review and approve or reject this booking.

Thank you,
Booking System
"""
        return message.strip()