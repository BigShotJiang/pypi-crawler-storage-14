﻿def check():
    msg = "[Disclosure] Are limitations and assumptions communicated transparently?"
    print(msg)
    return msg
