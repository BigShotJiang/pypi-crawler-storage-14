- [Fundación Esment](https://esment.org/):
  - Estefanía Bauzá

- [Tecnativa](https://www.tecnativa.com/):
  - Pedro M. Baeza
  - Christian Ramos