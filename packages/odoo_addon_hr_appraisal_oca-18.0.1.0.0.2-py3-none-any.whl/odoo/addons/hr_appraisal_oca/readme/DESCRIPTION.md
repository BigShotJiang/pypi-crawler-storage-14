This module helps maintain the employee motivation process through periodic performance
appraisals.

Managers can evaluate employee performance and enable employees to perform
self-assessments. Review forms can be customized according to organizational needs.
