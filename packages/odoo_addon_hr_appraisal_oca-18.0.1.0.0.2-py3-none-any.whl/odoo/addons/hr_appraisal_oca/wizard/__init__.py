from . import hr_appraisal_wizard
from . import send_mail_with_template_wizard
from . import res_config_settings
