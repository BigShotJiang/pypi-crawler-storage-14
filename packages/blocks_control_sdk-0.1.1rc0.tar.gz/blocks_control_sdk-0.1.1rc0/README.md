# Blocks Control SDK

A unified Python interface to interact with popular coding agents.

> Think of it like litellm, but for coding agents

## Supported Agents

- **Claude Code** - Anthropic's Claude
- **Gemini CLI** - Google's Gemini
- **Codex CLI** - OpenAI's Codex

## Installation

```bash
pip install blocks-control-sdk
```

You must also have the dependent agent packages installed to use a specific agent.

```bash
npm i -g @anthropic-ai/claude-code
npm i -g @google/gemini-cli
npm i -g @openai/codex-cli
```

## Usage

### Async Streaming

```python
import asyncio
from blocks_control_sdk import ClaudeCode, Codex, GeminiCLI


async def main():
    agent = ClaudeCode()
    async for message in agent.stream("Write a python script to print 'Hello, World!'"):
        print(message)

if __name__ == "__main__":
    asyncio.run(main())
```

### Sync with Callbacks

```python
from blocks_control_sdk import Codex

agent = Codex()

def on_message(notification):
    print(notification.message.content)

agent.register_notification(agent.notifications.NOTIFY_MESSAGE_V2, on_message)

agent.query("Write a python script to print 'Hello, World!'")
```

### All Agents

```python
from blocks_control_sdk import ClaudeCode, Codex, GeminiCLI

# Claude
claude = ClaudeCode()

# Gemini
gemini = GeminiCLI()

# Codex
codex = Codex()
```

## Environment Variables

```bash
export ANTHROPIC_API_KEY="your-key"  # For Claude
export GEMINI_API_KEY="your-key"     # For Gemini
export OPENAI_API_KEY="your-key"     # For Codex
```