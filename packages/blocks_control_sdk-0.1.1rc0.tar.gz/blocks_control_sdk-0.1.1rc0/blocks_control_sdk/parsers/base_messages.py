from typing import TYPE_CHECKING
from blocks_control_sdk.utils.logger import log
if TYPE_CHECKING:
    from litellm.types.utils import ModelResponse

BLOCKS_PROVIDER_SPECIFIC_FIELDS__IS_FINAL_MESSAGE = "blocks__is_final_message"

def print_litellm_model_response(resp: "ModelResponse"):
    log.debug(f"ROLE: {resp.choices[0].message.role}")
    log.debug(f"TEXT: {resp.choices[0].message.content}")
    log.debug(f"REASONING: {getattr(resp.choices[0].message, 'reasoning_content', None)}")
    log.debug(f"PROVIDER SPECIFIC FIELDS: {resp.choices[0].message.provider_specific_fields}")
    if resp.choices[0].message.tool_calls:
        for tc in resp.choices[0].message.tool_calls:
            log.debug(f"TOOL: {tc.function.name} {tc.function.arguments}")
    