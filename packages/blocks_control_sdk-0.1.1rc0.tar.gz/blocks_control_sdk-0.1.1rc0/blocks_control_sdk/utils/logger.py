"""Minimal logger for control module."""
import logging
import os

level = os.environ.get("CONTROL_LOG_LEVEL", "INFO").upper()
logging.basicConfig(
    level=getattr(logging, level, logging.INFO),
    format="%(message)s"
)

log = logging.getLogger("control")
log.setLevel(getattr(logging, level, logging.INFO))


def is_debug():
    return log.isEnabledFor(logging.DEBUG)


def error_debug(msg, *args, **kwargs):
    """Log as error only when debug level is enabled."""
    if log.isEnabledFor(logging.DEBUG):
        log.error(msg, *args, **kwargs)
