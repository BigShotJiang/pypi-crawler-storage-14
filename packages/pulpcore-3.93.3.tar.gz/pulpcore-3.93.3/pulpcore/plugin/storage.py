from pulpcore.app.models.storage import get_tls_path


__all__ = ["get_tls_path"]
