import click
import logging
import os

import django

os.environ.setdefault("DJANGO_SETTINGS_MODULE", "pulpcore.app.settings")

django.setup()

from django.conf import settings  # noqa: E402: module level not at top
from pulpcore.tasking.worker import PulpcoreWorker  # noqa: E402: module level not at top


_logger = logging.getLogger(__name__)


@click.option("--pid", help="Write the process ID number to a file at the specified path.")
@click.option(
    "--burst/--no-burst", help="Run in burst mode; terminate when no more tasks are available."
)
@click.option(
    "--reload/--no-reload", help="Reload worker on code changes. [requires hupper to be installed.]"
)
@click.option(
    "--auxiliary/--no-auxiliary",
    default=False,
    help="Auxiliary workers do not perform housekeeping duties.",
)
@click.option(
    "--name-template",
    type=str,
    help="Format string to use for the status name. "
    "'{pid}', '{hostname}', and '{fqdn} will be substituted.",
)
@click.command()
def worker(
    pid,
    burst,
    reload,
    auxiliary,
    name_template,
):
    """A Pulp worker."""

    if reload:
        try:
            import hupper
        except ImportError:
            click.echo("Could not load hupper. This is needed to use --reload.", err=True)
            exit(1)

        hupper.start_reloader(__name__ + ".worker")

    if pid:
        with open(os.path.expanduser(pid), "w") as fp:
            fp.write(str(os.getpid()))

    if name_template:
        settings.set("WORKER_NAME_TEMPLATE", name_template)

    _logger.info("Starting distributed type worker")

    PulpcoreWorker(auxiliary=auxiliary).run(burst=burst)
