from .torch import acceleration_device
from .torch import parameter_count

from .files import render_template
from .files import funnel

from .seed import seed_python
from .seed import seed_torch
from .seed import seed_numpy
from .seed import full_seed
