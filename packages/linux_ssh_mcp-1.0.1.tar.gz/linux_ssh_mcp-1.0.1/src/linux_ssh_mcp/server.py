"""Main MCP server implementation."""

import asyncio
import json
import structlog
from typing import Dict, List, Any, Optional
from datetime import datetime
import traceback

from mcp.server import Server
from mcp.server.models import InitializationOptions
from mcp.server.stdio import stdio_server
from mcp.types import (
    Resource, Tool, TextContent, ImageContent, EmbeddedResource,
    CallToolResult, ReadResourceResult, ListResourcesResult,
    ListToolsResult, EmptyResult
)

from .ssh_manager import SSHManager
from .security_validator import SecurityValidator
from .models import ServerConfig, SecurityConfig, MCPResponse
from .modules.system_info import SystemInfoModule
from .modules.file_manager import FileManager
from .modules.service_manager import ServiceManager
from .modules.process_manager import ProcessManager

logger = structlog.get_logger(__name__)


class LinuxSSHMCPServer:
    """Linux SSH MCP Server implementation."""

    def __init__(self):
        self.server = Server("linux-ssh-mcp")
        self.ssh_manager = SSHManager()
        self.security_config = SecurityConfig()
        self.security_validator = SecurityValidator(self.security_config)

        # Initialize modules
        self.system_info = SystemInfoModule(self.ssh_manager, self.security_validator)
        self.file_manager = FileManager(self.ssh_manager, self.security_validator)
        self.service_manager = ServiceManager(self.ssh_manager, self.security_validator)
        self.process_manager = ProcessManager(self.ssh_manager, self.security_validator)

        # Register handlers
        self._register_handlers()

        # Load initial configuration
        self._load_configuration()

    def _register_handlers(self):
        """Register MCP handlers."""

        @self.server.list_tools()
        async def handle_list_tools() -> ListToolsResult:
            """List available tools."""
            tools = [
                # Connection management
                Tool(
                    name="list_servers",
                    description="List all configured SSH servers",
                    inputSchema={
                        "type": "object",
                        "properties": {},
                    }
                ),
                Tool(
                    name="connect_server",
                    description="Connect to a SSH server",
                    inputSchema={
                        "type": "object",
                        "properties": {
                            "server_id": {
                                "type": "string",
                                "description": "Server identifier"
                            }
                        },
                        "required": ["server_id"]
                    }
                ),
                Tool(
                    name="disconnect_server",
                    description="Disconnect from a SSH server",
                    inputSchema={
                        "type": "object",
                        "properties": {
                            "server_id": {
                                "type": "string",
                                "description": "Server identifier"
                            }
                        },
                        "required": ["server_id"]
                    }
                ),
                Tool(
                    name="test_connection",
                    description="Test connection to a SSH server",
                    inputSchema={
                        "type": "object",
                        "properties": {
                            "server_id": {
                                "type": "string",
                                "description": "Server identifier"
                            }
                        },
                        "required": ["server_id"]
                    }
                ),
                # System information
                Tool(
                    name="get_system_info",
                    description="Get system information from a server",
                    inputSchema={
                        "type": "object",
                        "properties": {
                            "server_id": {
                                "type": "string",
                                "description": "Server identifier"
                            },
                            "category": {
                                "type": "string",
                                "enum": ["system", "cpu", "memory", "disk", "network", "processes", "services"],
                                "description": "Information category to retrieve"
                            }
                        },
                        "required": ["server_id"]
                    }
                ),
                # File operations
                Tool(
                    name="file_operations",
                    description="Perform file operations (read, write, list, delete, move, copy)",
                    inputSchema={
                        "type": "object",
                        "properties": {
                            "server_id": {
                                "type": "string",
                                "description": "Server identifier"
                            },
                            "operation": {
                                "type": "string",
                                "enum": ["read", "write", "list", "delete", "move", "copy"],
                                "description": "File operation to perform"
                            },
                            "path": {
                                "type": "string",
                                "description": "File path"
                            },
                            "content": {
                                "type": "string",
                                "description": "File content (for write operations)"
                            },
                            "destination": {
                                "type": "string",
                                "description": "Destination path (for move/copy operations)"
                            }
                        },
                        "required": ["server_id", "operation", "path"]
                    }
                ),
                # Process management
                Tool(
                    name="process_manager",
                    description="Manage processes (list, kill, get details)",
                    inputSchema={
                        "type": "object",
                        "properties": {
                            "server_id": {
                                "type": "string",
                                "description": "Server identifier"
                            },
                            "operation": {
                                "type": "string",
                                "enum": ["list", "kill", "details"],
                                "description": "Process operation to perform"
                            },
                            "pid": {
                                "type": "string",
                                "description": "Process ID (for kill/details operations)"
                            },
                            "filter_name": {
                                "type": "string",
                                "description": "Process name filter (for list operation)"
                            }
                        },
                        "required": ["server_id", "operation"]
                    }
                ),
                # Service management
                Tool(
                    name="service_manager",
                    description="Manage system services (list, status, start, stop, restart, enable, disable, logs)",
                    inputSchema={
                        "type": "object",
                        "properties": {
                            "server_id": {
                                "type": "string",
                                "description": "Server identifier"
                            },
                            "operation": {
                                "type": "string",
                                "enum": ["list", "status", "start", "stop", "restart", "enable", "disable", "logs"],
                                "description": "Service operation to perform"
                            },
                            "service": {
                                "type": "string",
                                "description": "Service name"
                            }
                        },
                        "required": ["server_id", "operation"]
                    }
                ),
                # Command execution
                Tool(
                    name="execute_command",
                    description="Execute a command on the server",
                    inputSchema={
                        "type": "object",
                        "properties": {
                            "server_id": {
                                "type": "string",
                                "description": "Server identifier"
                            },
                            "command": {
                                "type": "string",
                                "description": "Command to execute"
                            },
                            "timeout": {
                                "type": "number",
                                "description": "Timeout in seconds",
                                "default": 30
                            },
                            "category": {
                                "type": "string",
                                "enum": ["system_info", "file_operations", "text_processing", "network",
                                        "processes", "services", "packages", "docker", "kubernetes", "general"],
                                "description": "Command category for security validation",
                                "default": "general"
                            }
                        },
                        "required": ["server_id", "command"]
                    }
                ),
            ]
            return ListToolsResult(tools=tools)

        @self.server.call_tool()
        async def handle_call_tool(name: str, arguments: Dict[str, Any]) -> CallToolResult:
            """Handle tool calls."""
            try:
                if name == "list_servers":
                    return await self._handle_list_servers()
                elif name == "connect_server":
                    return await self._handle_connect_server(arguments)
                elif name == "disconnect_server":
                    return await self._handle_disconnect_server(arguments)
                elif name == "test_connection":
                    return await self._handle_test_connection(arguments)
                elif name == "get_system_info":
                    return await self._handle_get_system_info(arguments)
                elif name == "file_operations":
                    return await self._handle_file_operations(arguments)
                elif name == "process_manager":
                    return await self._handle_process_manager(arguments)
                elif name == "service_manager":
                    return await self._handle_service_manager(arguments)
                elif name == "execute_command":
                    return await self._handle_execute_command(arguments)
                else:
                    return CallToolResult(
                        content=[TextContent(type="text", text=f"Unknown tool: {name}")]
                    )

            except Exception as e:
                logger.error("Tool execution failed", tool=name, error=str(e), traceback=traceback.format_exc())
                return CallToolResult(
                    content=[TextContent(type="text", text=f"Error executing {name}: {str(e)}")]
                )

        @self.server.list_resources()
        async def handle_list_resources() -> ListResourcesResult:
            """List available resources."""
            return ListResourcesResult(resources=[])

    async def _handle_list_servers(self) -> CallToolResult:
        """Handle list_servers tool call."""
        servers = []
        for server_id in self.ssh_manager.list_servers():
            config = self.ssh_manager.get_server_info(server_id)
            if config:
                status = self.ssh_manager.get_server_status(server_id)
                servers.append({
                    "id": config.id,
                    "name": config.name,
                    "host": config.host,
                    "port": config.port,
                    "username": config.username,
                    "status": status.value,
                    "tags": config.tags
                })

        return CallToolResult(
            content=[TextContent(
                type="text",
                text=json.dumps(servers, indent=2, ensure_ascii=False)
            )]
        )

    async def _handle_connect_server(self, arguments: Dict[str, Any]) -> CallToolResult:
        """Handle connect_server tool call."""
        server_id = arguments["server_id"]
        success = await self.ssh_manager.connect(server_id)

        if success:
            message = f"Successfully connected to server {server_id}"
        else:
            message = f"Failed to connect to server {server_id}"

        return CallToolResult(
            content=[TextContent(type="text", text=message)]
        )

    async def _handle_disconnect_server(self, arguments: Dict[str, Any]) -> CallToolResult:
        """Handle disconnect_server tool call."""
        server_id = arguments["server_id"]
        await self.ssh_manager.disconnect(server_id)
        message = f"Disconnected from server {server_id}"

        return CallToolResult(
            content=[TextContent(type="text", text=message)]
        )

    async def _handle_test_connection(self, arguments: Dict[str, Any]) -> CallToolResult:
        """Handle test_connection tool call."""
        server_id = arguments["server_id"]
        success = await self.ssh_manager.test_connection(server_id)

        if success:
            # Get basic server info
            info = await self.ssh_manager.get_server_info_remote(server_id)
            message = f"Connection test successful for {server_id}\n\nServer Information:\n{json.dumps(info, indent=2, ensure_ascii=False)}"
        else:
            message = f"Connection test failed for {server_id}"

        return CallToolResult(
            content=[TextContent(type="text", text=message)]
        )

    async def _handle_get_system_info(self, arguments: Dict[str, Any]) -> CallToolResult:
        """Handle get_system_info tool call."""
        server_id = arguments["server_id"]
        category = arguments.get("category", "all")

        result = await self.system_info.get_system_info(server_id, category)

        return CallToolResult(
            content=[TextContent(
                type="text",
                text=json.dumps(result, indent=2, ensure_ascii=False, default=str)
            )]
        )

    async def _handle_file_operations(self, arguments: Dict[str, Any]) -> CallToolResult:
        """Handle file_operations tool call."""
        server_id = arguments["server_id"]
        operation = arguments["operation"]
        path = arguments["path"]

        kwargs = {}
        if operation in ["write", "move", "copy"]:
            if operation == "write":
                kwargs["content"] = arguments.get("content", "")
            else:
                kwargs["destination"] = arguments.get("destination")

        result = await self.file_manager.file_operations(server_id, operation, path, **kwargs)

        return CallToolResult(
            content=[TextContent(
                type="text",
                text=json.dumps(result, indent=2, ensure_ascii=False, default=str)
            )]
        )

    async def _handle_process_manager(self, arguments: Dict[str, Any]) -> CallToolResult:
        """Handle process_manager tool call."""
        server_id = arguments["server_id"]
        operation = arguments["operation"]

        if operation == "list":
            filter_name = arguments.get("filter_name")
            result = await self.process_manager.list_processes(server_id, filter_name)
        elif operation == "kill":
            pid = arguments.get("pid")
            signal = arguments.get("signal", "15")
            result = await self.process_manager.kill_process(server_id, pid, signal)
        elif operation == "details":
            pid = arguments.get("pid")
            result = await self.process_manager.get_process_details(server_id, pid)
        else:
            result = {"error": f"Unknown operation: {operation}"}

        return CallToolResult(
            content=[TextContent(
                type="text",
                text=json.dumps(result, indent=2, ensure_ascii=False, default=str)
            )]
        )

    async def _handle_service_manager(self, arguments: Dict[str, Any]) -> CallToolResult:
        """Handle service_manager tool call."""
        server_id = arguments["server_id"]
        operation = arguments["operation"]
        service = arguments.get("service")

        result = await self.service_manager.service_manager(server_id, operation, service)

        return CallToolResult(
            content=[TextContent(
                type="text",
                text=json.dumps(result, indent=2, ensure_ascii=False, default=str)
            )]
        )

    async def _handle_execute_command(self, arguments: Dict[str, Any]) -> CallToolResult:
        """Handle execute_command tool call."""
        server_id = arguments["server_id"]
        command = arguments["command"]
        timeout = arguments.get("timeout", 30)
        category = arguments.get("category", "general")

        # Security validation
        validation = await self.security_validator.validate_command(command, category)
        if not validation["allowed"]:
            return CallToolResult(
                content=[TextContent(
                    type="text",
                    text=f"Command validation failed: {validation['reason']}"
                )]
            )

        # Execute command
        result = await self.ssh_manager.execute_command(server_id, command, timeout)

        return CallToolResult(
            content=[TextContent(
                type="text",
                text=json.dumps(result.dict(), indent=2, ensure_ascii=False, default=str)
            )]
        )

    def _load_configuration(self):
        """Load server configuration."""
        # For now, add a demo server configuration
        # In production, this would load from a configuration file
        demo_config = ServerConfig(
            id="demo-server",
            name="Demo Linux Server",
            host="localhost",
            port=22,
            username="your_username",  # User should configure this
            auth_method="ssh_key",
            ssh_key_path="~/.ssh/id_rsa",
            tags=["demo", "development"]
        )

        self.ssh_manager.add_server(demo_config)

    async def run(self):
        """Run the MCP server."""
        async with stdio_server() as (read_stream, write_stream):
            await self.server.run(
                read_stream,
                write_stream,
                InitializationOptions(
                    server_name="linux-ssh-mcp",
                    server_version="1.0.0",
                    capabilities={
                        "tools": {},
                        "resources": {},
                    }
                )
            )

    async def shutdown(self):
        """Shutdown the server."""
        await self.ssh_manager.disconnect_all()
        logger.info("Linux SSH MCP Server shutdown complete")