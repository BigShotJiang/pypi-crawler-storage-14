"""
Linux SSH MCP Server

A secure MCP server for managing Linux systems via SSH connections.
Provides AI assistants with safe and controlled access to Linux system operations.
"""

__version__ = "1.0.1"
__author__ = "MCP Development Team"
__email__ = "dev@example.com"

from .server import LinuxSSHMCPServer
from .config_utils import get_config_dir, get_config_file_path

__all__ = ["LinuxSSHMCPServer", "get_config_dir", "get_config_file_path"]