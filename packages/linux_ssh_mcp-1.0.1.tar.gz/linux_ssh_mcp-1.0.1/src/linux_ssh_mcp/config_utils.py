"""Configuration utilities for Linux SSH MCP server."""

import os
import sys
from pathlib import Path
from typing import Optional
import platform

def get_config_dir(app_name: str = "linux-ssh-mcp") -> Path:
    """
    Get the platform-specific configuration directory.

    Follows standard conventions:
    - Linux/macOS: ~/.config/<app_name>/
    - Windows: %APPDATA%/<app_name>/

    Args:
        app_name: Name of the application

    Returns:
        Path object for the configuration directory
    """
    system = platform.system()

    if system == "Windows":
        # Windows: %APPDATA%/<app_name>/
        config_dir = Path(os.environ.get("APPDATA", "")) / app_name
    elif system == "Darwin":
        # macOS: ~/Library/Application Support/<app_name>/
        config_dir = Path.home() / "Library" / "Application Support" / app_name
    else:
        # Linux and other Unix-like: ~/.config/<app_name>/
        config_dir = Path.home() / ".config" / app_name

    return config_dir

def get_config_file_path(filename: str, app_name: str = "linux-ssh-mcp") -> Path:
    """
    Get the full path to a configuration file.

    Args:
        filename: Name of the configuration file
        app_name: Name of the application

    Returns:
        Path object for the configuration file
    """
    return get_config_dir(app_name) / filename

def ensure_config_dir(app_name: str = "linux-ssh-mcp") -> Path:
    """
    Ensure the configuration directory exists and is properly secured.

    Args:
        app_name: Name of the application

    Returns:
        Path object for the created configuration directory
    """
    config_dir = get_config_dir(app_name)
    config_dir.mkdir(parents=True, exist_ok=True)

    # Set secure permissions on Unix-like systems
    if platform.system() != "Windows":
        try:
            os.chmod(config_dir, 0o700)
        except (OSError, PermissionError):
            pass  # May fail in some environments

    return config_dir

def find_legacy_config_dir() -> Optional[Path]:
    """
    Find legacy configuration directory for migration purposes.

    Returns:
        Path to legacy config directory if found, None otherwise
    """
    legacy_paths = [
        Path.cwd() / "config",
        Path.home() / "linux-ssh-mcp" / "config",
        Path.home() / "config"
    ]

    for path in legacy_paths:
        if path.exists() and any(path.glob("*.yaml")):
            return path

    return None

def migrate_legacy_config(app_name: str = "linux-ssh-mcp") -> bool:
    """
    Migrate configuration from legacy location to standard location.

    Args:
        app_name: Name of the application

    Returns:
        True if migration was performed, False otherwise
    """
    legacy_dir = find_legacy_config_dir()
    if not legacy_dir:
        return False

    new_config_dir = get_config_dir(app_name)

    # Don't migrate if new config already exists
    if new_config_dir.exists() and any(new_config_dir.glob("*.yaml")):
        return False

    try:
        ensure_config_dir(app_name)

        # Copy all YAML files
        for yaml_file in legacy_dir.glob("*.yaml"):
            target_file = new_config_dir / yaml_file.name
            target_file.write_text(yaml_file.read_text(encoding='utf-8'), encoding='utf-8')

        return True
    except Exception:
        return False