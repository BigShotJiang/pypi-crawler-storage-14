"""Configuration manager for Linux SSH MCP server."""

import os
import yaml
import getpass
import asyncio
from typing import Dict, List, Optional, Any
from pathlib import Path
import structlog
from datetime import datetime

from .models import ServerConfig, AuthMethod
from .ssh_manager import SSHManager
from .config_utils import get_config_file_path, ensure_config_dir, migrate_legacy_config

logger = structlog.get_logger(__name__)


class ConfigManager:
    """Manages server configurations with security validation."""

    def __init__(self, config_file: Optional[str] = None):
        # Use standard config directory if no specific file provided
        if config_file is None:
            self.config_file = get_config_file_path("servers.yaml")
            # Try to migrate legacy configuration
            migrate_legacy_config()
        else:
            self.config_file = Path(config_file)

        self.servers: Dict[str, ServerConfig] = {}
        self.ensure_config_dir()
        self.load_config()

    def ensure_config_dir(self):
        """Ensure configuration directory exists."""
        self.config_file.parent.mkdir(parents=True, exist_ok=True)
        # Set secure permissions on config directory
        try:
            os.chmod(self.config_file.parent, 0o700)
        except Exception:
            pass  # May fail on Windows

    def load_config(self):
        """Load configuration from file."""
        if self.config_file.exists():
            try:
                with open(self.config_file, 'r', encoding='utf-8') as f:
                    data = yaml.safe_load(f)
                    if 'servers' in data:
                        for server_data in data['servers']:
                            config = ServerConfig(**server_data)
                            self.servers[config.id] = config
                        logger.info("Loaded server configurations", count=len(self.servers))
            except Exception as e:
                logger.error("Failed to load config file", error=str(e))
        else:
            logger.info("No config file found, starting with empty configuration")

    def save_config(self):
        """Save configuration to file."""
        try:
            servers_data = []
            for server in self.servers.values():
                server_dict = server.dict()
                # Remove sensitive data from plain text if needed
                if server_dict.get('auth_method') == 'password':
                    # In a real implementation, you might want to encrypt this
                    pass
                servers_data.append(server_dict)

            data = {'servers': servers_data}

            with open(self.config_file, 'w', encoding='utf-8') as f:
                yaml.dump(data, f, default_flow_style=False, indent=2)

            # Set secure permissions
            try:
                os.chmod(self.config_file, 0o600)
            except Exception:
                pass  # May fail on Windows

            logger.info("Saved server configurations", count=len(self.servers))
            return True
        except Exception as e:
            logger.error("Failed to save config file", error=str(e))
            return False

    def list_servers(self) -> List[ServerConfig]:
        """List all configured servers."""
        return list(self.servers.values())

    def get_server(self, server_id: str) -> Optional[ServerConfig]:
        """Get server configuration by ID."""
        return self.servers.get(server_id)

    def add_server_interactive(self) -> Dict[str, Any]:
        """Add server through interactive prompts."""
        try:
            print("\n=== Add New Server Configuration ===")

            # Basic server info
            server_id = input("Server ID (unique identifier): ").strip()
            if not server_id:
                return {"success": False, "error": "Server ID is required"}

            if server_id in self.servers:
                return {"success": False, "error": f"Server ID '{server_id}' already exists"}

            host = input("Host address (IP or hostname): ").strip()
            if not host:
                return {"success": False, "error": "Host address is required"}

            username = input("Username: ").strip()
            if not username:
                return {"success": False, "error": "Username is required"}

            port_str = input("SSH port (default 22): ").strip()
            port = int(port_str) if port_str else 22

            # Authentication method
            auth_method = self._get_auth_method_interactive()

            # Password or SSH key
            password = None
            ssh_key_path = None
            ssh_key_password = None

            if auth_method == "password":
                password = getpass.getpass("Password: ")
                if not password:
                    return {"success": False, "error": "Password is required"}

                # Confirm password
                confirm_password = getpass.getpass("Confirm password: ")
                if password != confirm_password:
                    return {"success": False, "error": "Passwords do not match"}

            elif auth_method == "ssh_key":
                ssh_key_path = input("SSH key path (default ~/.ssh/id_rsa): ").strip()
                if not ssh_key_path:
                    ssh_key_path = "~/.ssh/id_rsa"

                # Check if key exists
                key_path = os.path.expanduser(ssh_key_path)
                if not os.path.exists(key_path):
                    return {"success": False, "error": f"SSH key file not found: {ssh_key_path}"}

                # Test if key needs password
                test_password = getpass.getpass("SSH key password (leave empty if no password): ")
                if test_password:
                    ssh_key_password = test_password

            # Server details
            name = input("Server name (optional): ").strip()
            if not name:
                name = f"Server {server_id}"

            tags_str = input("Tags (comma-separated, optional): ").strip()
            tags = [tag.strip() for tag in tags_str.split(',')] if tags_str else []

            # Create configuration
            config = ServerConfig(
                id=server_id,
                name=name,
                host=host,
                port=port,
                username=username,
                auth_method=AuthMethod(auth_method),
                ssh_key_path=ssh_key_path,
                ssh_key_password=ssh_key_password,
                password=password,
                tags=tags
            )

            # Test connection
            print(f"\nTesting connection to {config.host}...")
            test_result = asyncio.run(self._test_connection(config))

            if not test_result["success"]:
                confirm = input(f"Connection test failed: {test_result['error']}\nSave anyway? (y/N): ").strip().lower()
                if confirm != 'y':
                    return {"success": False, "error": "Connection test failed and user cancelled"}

            # Save configuration
            self.servers[server_id] = config
            if self.save_config():
                return {
                    "success": True,
                    "server_id": server_id,
                    "message": f"Server '{server_id}' added successfully"
                }
            else:
                return {"success": False, "error": "Failed to save configuration"}

        except KeyboardInterrupt:
            return {"success": False, "error": "Operation cancelled by user"}
        except Exception as e:
            return {"success": False, "error": f"Unexpected error: {str(e)}"}

    def _get_auth_method_interactive(self) -> str:
        """Get authentication method interactively."""
        while True:
            print("\nAuthentication method:")
            print("1) Password")
            print("2) SSH Key")
            choice = input("Select authentication method (1-2): ").strip()

            if choice == "1":
                return "password"
            elif choice == "2":
                return "ssh_key"
            else:
                print("Invalid choice. Please select 1 or 2.")

    async def _test_connection(self, config: ServerConfig) -> Dict[str, Any]:
        """Test connection to a server."""
        ssh_manager = SSHManager()
        try:
            ssh_manager.add_server(config)
            success = await ssh_manager.connect(config.id)

            if success:
                # Test simple command
                result = await ssh_manager.execute_command(config.id, "whoami")
                await ssh_manager.disconnect(config.id)

                if result.success and "root" in result.stdout:
                    return {
                        "success": True,
                        "message": "Connection successful (root access)",
                        "user": "root"
                    }
                elif result.success:
                    return {
                        "success": True,
                        "message": f"Connection successful (user: {result.stdout.strip()})",
                        "user": result.stdout.strip()
                    }
                else:
                    return {
                        "success": False,
                        "error": "Connected but command execution failed"
                    }
            else:
                return {
                    "success": False,
                    "error": "Connection failed"
                }
        except Exception as e:
            return {
                "success": False,
                "error": f"Connection error: {str(e)}"
            }

    def update_server_password(self, server_id: str) -> Dict[str, Any]:
        """Update server password interactively."""
        if server_id not in self.servers:
            return {"success": False, "error": f"Server '{server_id}' not found"}

        config = self.servers[server_id]

        if config.auth_method != AuthMethod.PASSWORD:
            return {"success": False, "error": f"Server '{server_id}' uses {config.auth_method} authentication"}

        try:
            print(f"\n=== Update Password for Server '{server_id}' ===")
            print(f"Host: {config.host}")
            print(f"Username: {config.username}")

            old_password = getpass.getpass("Current password (leave empty to skip verification): ")

            if old_password:
                # Verify old password
                test_config = config.copy()
                test_config.password = old_password

                verification = asyncio.run(self._test_connection(test_config))
                if not verification["success"]:
                    return {"success": False, "error": "Current password verification failed"}

            new_password = getpass.getpass("New password: ")
            if not new_password:
                return {"success": False, "error": "New password is required"}

            confirm_password = getpass.getpass("Confirm new password: ")
            if new_password != confirm_password:
                return {"success": False, "error": "Passwords do not match"}

            # Update configuration
            config.password = new_password
            config.ssh_key_password = None  # Clear any SSH key password

            # Test new connection
            print(f"\nTesting new password...")
            test_result = asyncio.run(self._test_connection(config))

            if test_result["success"]:
                if self.save_config():
                    return {
                        "success": True,
                        "message": f"Password updated successfully for server '{server_id}'"
                    }
                else:
                    return {"success": False, "error": "Failed to save configuration"}
            else:
                return {
                    "success": False,
                    "error": f"New password test failed: {test_result['error']}"
                }

        except KeyboardInterrupt:
            return {"success": False, "error": "Operation cancelled by user"}
        except Exception as e:
            return {"success": False, "error": f"Unexpected error: {str(e)}"}

    def remove_server(self, server_id: str, confirm: bool = True) -> Dict[str, Any]:
        """Remove a server configuration."""
        if server_id not in self.servers:
            return {"success": False, "error": f"Server '{server_id}' not found"}

        config = self.servers[server_id]

        if confirm:
            print(f"\n=== Remove Server '{server_id}' ===")
            print(f"Name: {config.name}")
            print(f"Host: {config.host}")
            print(f"Username: {config.username}")

            response = input(f"Are you sure you want to remove this server? (yes/no): ").strip().lower()
            if response not in ['yes', 'y']:
                return {"success": False, "error": "Operation cancelled"}

        del self.servers[server_id]

        if self.save_config():
            return {
                "success": True,
                "message": f"Server '{server_id}' removed successfully"
            }
        else:
            return {"success": False, "error": "Failed to save configuration"}

    def rename_server(self, server_id: str, new_id: str, new_name: str = None, confirm: bool = True) -> Dict[str, Any]:
        """Rename a server configuration."""
        # 验证原服务器存在
        if server_id not in self.servers:
            return {"success": False, "error": f"Server '{server_id}' not found"}

        # 验证新ID唯一性
        if new_id in self.servers and new_id != server_id:
            return {"success": False, "error": f"Server ID '{new_id}' already exists"}

        old_config = self.servers[server_id]

        if confirm:
            print(f"\n=== Rename Server '{server_id}' ===")
            print(f"Current Name: {old_config.name}")
            print(f"Host: {old_config.host}")
            print(f"Username: {old_config.username}")
            print(f"New ID: {new_id}")
            if new_name:
                print(f"New Name: {new_name}")
            else:
                print(f"New Name: {old_config.name} (unchanged)")

            response = input("Are you sure you want to rename this server? (yes/no): ").strip().lower()
            if response not in ['yes', 'y']:
                return {"success": False, "error": "Operation cancelled"}

        # 创建新的服务器配置
        new_config = old_config.copy()
        new_config.id = new_id
        if new_name:
            new_config.name = new_name

        # 替换服务器配置
        del self.servers[server_id]
        self.servers[new_id] = new_config

        # 保存配置
        if self.save_config():
            return {
                "success": True,
                "message": f"Server '{server_id}' renamed to '{new_id}' successfully",
                "old_id": server_id,
                "new_id": new_id,
                "old_name": old_config.name,
                "new_name": new_config.name
            }
        else:
            # 如果保存失败，恢复原配置
            del self.servers[new_id]
            self.servers[server_id] = old_config
            return {"success": False, "error": "Failed to save configuration, changes reverted"}

    def export_config(self, export_file: str = None) -> Dict[str, Any]:
        """Export configuration to file."""
        if not export_file:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            export_file = f"servers_backup_{timestamp}.yaml"

        try:
            export_path = Path(export_file)
            servers_data = []

            for server in self.servers.values():
                server_dict = server.dict()
                # Remove sensitive data for export
                server_dict.pop('password', None)
                server_dict.pop('ssh_key_password', None)
                servers_data.append(server_dict)

            data = {'servers': servers_data, 'exported_at': datetime.now().isoformat()}

            with open(export_path, 'w', encoding='utf-8') as f:
                yaml.dump(data, f, default_flow_style=False, indent=2)

            return {
                "success": True,
                "message": f"Configuration exported to {export_path}",
                "export_file": str(export_path)
            }
        except Exception as e:
            return {"success": False, "error": f"Export failed: {str(e)}"}