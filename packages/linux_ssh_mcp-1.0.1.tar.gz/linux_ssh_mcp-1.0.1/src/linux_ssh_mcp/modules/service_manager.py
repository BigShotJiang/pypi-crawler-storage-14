"""Service manager module."""

import asyncio
import structlog
from typing import Dict, Any, Optional
from datetime import datetime
import re

logger = structlog.get_logger(__name__)


class ServiceManager:
    """Module for managing system services."""

    def __init__(self, ssh_manager, security_validator):
        self.ssh_manager = ssh_manager
        self.security = security_validator

    async def service_manager(self, host_id: str, operation: str, service: Optional[str] = None) -> Dict[str, Any]:
        """Manage system services."""
        try:
            if operation == "list":
                return await self._list_services(host_id)
            elif operation == "status" and service:
                return await self._get_service_status(host_id, service)
            elif operation in ["start", "stop", "restart", "reload", "enable", "disable"] and service:
                return await self._manage_service(host_id, service, operation)
            elif operation == "logs" and service:
                return await self._get_service_logs(host_id, service)
            else:
                return {"error": f"Invalid operation or missing service name: {operation}"}

        except Exception as e:
            logger.error("Service operation failed", host_id=host_id, operation=operation, service=service, error=str(e))
            return {"error": f"Service operation failed: {str(e)}"}

    async def _detect_service_manager(self, host_id: str) -> str:
        """Detect the service manager being used."""
        # Try systemd first
        result = await self.ssh_manager.execute_command(host_id, "systemctl --version")
        if result.success:
            return "systemd"

        # Try sysvinit
        result = await self.ssh_manager.execute_command(host_id, "service --version")
        if result.success:
            return "sysvinit"

        return "unknown"

    async def _list_services(self, host_id: str) -> Dict[str, Any]:
        """List all services."""
        manager = await self._detect_service_manager(host_id)

        if manager == "systemd":
            result = await self.ssh_manager.execute_command(host_id, "systemctl list-units --type=service --no-pager --no-legend")
            if result.success:
                services = []
                for line in result.stdout.strip().split('\n'):
                    if line.strip() and '.service' in line:
                        parts = line.strip().split(None, 4)
                        if len(parts) >= 4:
                            services.append({
                                "name": parts[0],
                                "load": parts[1],
                                "active": parts[2],
                                "sub": parts[3],
                                "description": parts[4] if len(parts) > 4 else ""
                            })

                return {
                    "host": host_id,
                    "timestamp": datetime.now().isoformat(),
                    "service_manager": manager,
                    "services": services,
                    "total_count": len(services),
                    "success": True
                }
        elif manager == "sysvinit":
            result = await self.ssh_manager.execute_command(host_id, "service --status-all 2>/dev/null")
            if result.success:
                services = []
                for line in result.stdout.strip().split('\n'):
                    if line.strip():
                        match = re.match(r'\[\s*([+-?])\s*\]\s*(.+)', line.strip())
                        if match:
                            status_char = match.group(1)
                            service_name = match.group(2)
                            status = "running" if status_char == "+" else "stopped" if status_char == "-" else "unknown"

                            services.append({
                                "name": service_name,
                                "status": status,
                                "description": ""
                            })

                return {
                    "host": host_id,
                    "timestamp": datetime.now().isoformat(),
                    "service_manager": manager,
                    "services": services,
                    "total_count": len(services),
                    "success": True
                }

        return {"error": f"Failed to list services with manager: {manager}"}

    async def _get_service_status(self, host_id: str, service: str) -> Dict[str, Any]:
        """Get service status."""
        manager = await self._detect_service_manager(host_id)

        if manager == "systemd":
            commands = {
                "status": f"systemctl status {service} --no-pager",
                "enabled": f"systemctl is-enabled {service}",
                "properties": f"systemctl show {service} --property=ActiveState,SubState,MainPID"
            }
        elif manager == "sysvinit":
            commands = {
                "status": f"service {service} status",
                "enabled": f"chkconfig --list {service} 2>/dev/null || echo 'unknown'"
            }
        else:
            return {"error": f"Unsupported service manager: {manager}"}

        results = {}
        for key, cmd in commands.items():
            result = await self.ssh_manager.execute_command(host_id, cmd)
            if result.success:
                results[key] = result.stdout.strip()

        return {
            "host": host_id,
            "timestamp": datetime.now().isoformat(),
            "service": service,
            "service_manager": manager,
            "status_info": results,
            "success": True
        }

    async def _manage_service(self, host_id: str, service: str, operation: str) -> Dict[str, Any]:
        """Manage service (start/stop/restart/enable/disable)."""
        manager = await self._detect_service_manager(host_id)

        if manager == "systemd":
            cmd = f"systemctl {operation} {service}"
        elif manager == "sysvinit":
            if operation in ["enable", "disable"]:
                if operation == "enable":
                    cmd = f"chkconfig {service} on 2>/dev/null || update-rc.d {service} defaults"
                else:
                    cmd = f"chkconfig {service} off 2>/dev/null || update-rc.d -f {service} remove"
            else:
                cmd = f"service {service} {operation}"
        else:
            return {"error": f"Unsupported service manager: {manager}"}

        # Get status before
        before_status = await self._get_service_status(host_id, service)

        # Execute operation
        result = await self.ssh_manager.execute_command(host_id, cmd)

        if result.success:
            # Wait a moment for the service to change state
            await asyncio.sleep(2)

            # Get status after
            after_status = await self._get_service_status(host_id, service)

            return {
                "host": host_id,
                "timestamp": datetime.now().isoformat(),
                "service": service,
                "operation": operation,
                "service_manager": manager,
                "success": True,
                "before_status": before_status.get("status_info", {}),
                "after_status": after_status.get("status_info", {}),
                "output": result.stdout.strip() if result.stdout else ""
            }
        else:
            return {
                "host": host_id,
                "timestamp": datetime.now().isoformat(),
                "service": service,
                "operation": operation,
                "success": False,
                "error": result.stderr
            }

    async def _get_service_logs(self, host_id: str, service: str, lines: int = 50) -> Dict[str, Any]:
        """Get service logs."""
        manager = await self._detect_service_manager(host_id)

        if manager == "systemd":
            cmd = f"journalctl -u {service} -n {lines} --no-pager"
        else:
            # For sysvinit, try common log files
            log_files = [
                f"/var/log/{service}.log",
                f"/var/log/{service}/{service}.log",
                "/var/log/syslog"
            ]

            for log_file in log_files:
                result = await self.ssh_manager.execute_command(host_id, f"test -f '{log_file}'")
                if result.success:
                    cmd = f"tail -{lines} '{log_file}'"
                    break
            else:
                return {"error": f"No log files found for service: {service}"}

        result = await self.ssh_manager.execute_command(host_id, cmd)
        if result.success:
            return {
                "host": host_id,
                "timestamp": datetime.now().isoformat(),
                "service": service,
                "service_manager": manager,
                "lines": lines,
                "logs": result.stdout.strip(),
                "success": True
            }
        else:
            return {"error": f"Failed to get logs for {service}: {result.stderr}"}