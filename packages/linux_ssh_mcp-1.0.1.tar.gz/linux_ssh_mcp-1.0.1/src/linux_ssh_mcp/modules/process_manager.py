"""Process manager module."""

import asyncio
import structlog
from typing import Dict, Any, Optional
from datetime import datetime
import re

logger = structlog.get_logger(__name__)


class ProcessManager:
    """Module for managing processes."""

    def __init__(self, ssh_manager, security_validator):
        self.ssh_manager = ssh_manager
        self.security = security_validator

    async def list_processes(self, host_id: str, filter_name: Optional[str] = None) -> Dict[str, Any]:
        """List processes."""
        try:
            if filter_name:
                cmd = f"ps aux | grep '{filter_name}' | grep -v grep"
            else:
                cmd = "ps aux --sort=-%cpu | head -30"  # Show top 30 processes by CPU

            result = await self.ssh_manager.execute_command(host_id, cmd)
            if result.success:
                processes = []
                lines = result.stdout.strip().split('\n')[1:]  # Skip header

                for line in lines:
                    if line.strip():
                        # Split into columns
                        parts = re.split(r'\s+', line.strip(), 10)
                        if len(parts) >= 11:
                            processes.append({
                                "user": parts[0],
                                "pid": int(parts[1]),
                                "cpu_percent": parts[2],
                                "memory_percent": parts[3],
                                "vsz": parts[4],
                                "rss": parts[5],
                                "tty": parts[6],
                                "stat": parts[7],
                                "start": parts[8],
                                "time": parts[9],
                                "command": parts[10]
                            })

                return {
                    "host": host_id,
                    "timestamp": datetime.now().isoformat(),
                    "operation": "list_processes",
                    "filter": filter_name,
                    "processes": processes,
                    "total_count": len(processes),
                    "success": True
                }
            else:
                return {"error": f"Failed to list processes: {result.stderr}"}

        except Exception as e:
            logger.error("Failed to list processes", host_id=host_id, error=str(e))
            return {"error": f"Failed to list processes: {str(e)}"}

    async def kill_process(self, host_id: str, pid: str, signal: str = "15") -> Dict[str, Any]:
        """Kill a process."""
        try:
            # Validate PID
            if not pid.isdigit():
                return {"error": f"Invalid PID format: {pid}"}

            # Check if process exists
            check_result = await self.ssh_manager.execute_command(host_id, f"ps -p {pid}")
            if not check_result.success:
                return {"error": f"Process {pid} does not exist"}

            # Kill process
            kill_cmd = f"kill -{signal} {pid}"
            result = await self.ssh_manager.execute_command(host_id, kill_cmd)

            if result.success:
                return {
                    "host": host_id,
                    "timestamp": datetime.now().isoformat(),
                    "operation": "kill_process",
                    "pid": pid,
                    "signal": signal,
                    "success": True,
                    "message": "Process killed successfully"
                }
            else:
                return {"error": f"Failed to kill process {pid}: {result.stderr}"}

        except Exception as e:
            logger.error("Failed to kill process", host_id=host_id, pid=pid, error=str(e))
            return {"error": f"Failed to kill process: {str(e)}"}

    async def get_process_details(self, host_id: str, pid: str) -> Dict[str, Any]:
        """Get detailed process information."""
        try:
            if not pid.isdigit():
                return {"error": f"Invalid PID format: {pid}"}

            # Check if process exists
            check_result = await self.ssh_manager.execute_command(host_id, f"ps -p {pid}")
            if not check_result.success:
                return {"error": f"Process {pid} does not exist"}

            # Get detailed information
            commands = {
                "basic_info": f"ps -p {pid} -o pid,ppid,user,%cpu,%mem,cmd",
                "environment": f"cat /proc/{pid}/environ 2>/dev/null | tr '\\0' '\\n' | head -10",
                "open_files": f"lsof -p {pid} 2>/dev/null | head -20",
                "memory_map": f"cat /proc/{pid}/smaps 2>/dev/null | head -50"
            }

            results = {}
            for key, cmd in commands.items():
                result = await self.ssh_manager.execute_command(host_id, cmd)
                if result.success:
                    results[key] = result.stdout.strip()
                else:
                    results[key] = f"Error: {result.stderr}"

            return {
                "host": host_id,
                "timestamp": datetime.now().isoformat(),
                "operation": "get_process_details",
                "pid": pid,
                "process_details": results,
                "success": True
            }

        except Exception as e:
            logger.error("Failed to get process details", host_id=host_id, pid=pid, error=str(e))
            return {"error": f"Failed to get process details: {str(e)}"}