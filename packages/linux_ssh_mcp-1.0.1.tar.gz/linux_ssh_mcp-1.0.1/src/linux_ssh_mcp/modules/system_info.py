"""System information module."""

import asyncio
import structlog
from typing import Dict, Any, Optional
from datetime import datetime

logger = structlog.get_logger(__name__)


class SystemInfoModule:
    """Module for retrieving system information."""

    def __init__(self, ssh_manager, security_validator):
        self.ssh_manager = ssh_manager
        self.security = security_validator

    async def get_system_info(self, host_id: str, category: str = "all") -> Dict[str, Any]:
        """Get system information."""
        try:
            if category == "system" or category == "all":
                basic_info = await self._get_basic_info(host_id)
            else:
                basic_info = {}

            if category == "cpu" or category == "all":
                cpu_info = await self._get_cpu_info(host_id)
            else:
                cpu_info = {}

            if category == "memory" or category == "all":
                memory_info = await self._get_memory_info(host_id)
            else:
                memory_info = {}

            if category == "disk" or category == "all":
                disk_info = await self._get_disk_info(host_id)
            else:
                disk_info = {}

            return {
                "host": host_id,
                "timestamp": datetime.now().isoformat(),
                "category": category,
                "system_info": basic_info,
                "cpu_info": cpu_info,
                "memory_info": memory_info,
                "disk_info": disk_info
            }

        except Exception as e:
            logger.error("Failed to get system info", host_id=host_id, error=str(e))
            return {
                "host": host_id,
                "timestamp": datetime.now().isoformat(),
                "error": str(e)
            }

    async def _get_basic_info(self, host_id: str) -> Dict[str, str]:
        """Get basic system information."""
        commands = {
            "hostname": "hostname",
            "uname": "uname -a",
            "uptime": "uptime",
            "os_release": "cat /etc/os-release 2>/dev/null || echo 'Unknown OS'"
        }

        info = {}
        for key, cmd in commands.items():
            result = await self.ssh_manager.execute_command(host_id, cmd)
            if result.success:
                info[key] = result.stdout.strip()
            else:
                info[key] = f"Error: {result.stderr}"

        return info

    async def _get_cpu_info(self, host_id: str) -> Dict[str, str]:
        """Get CPU information."""
        commands = {
            "cpu_model": "grep 'model name' /proc/cpuinfo | head -1 | cut -d':' -f2 | xargs",
            "cpu_cores": "nproc",
            "load_avg": "cat /proc/loadavg"
        }

        info = {}
        for key, cmd in commands.items():
            result = await self.ssh_manager.execute_command(host_id, cmd)
            if result.success:
                info[key] = result.stdout.strip()
            else:
                info[key] = f"Error: {result.stderr}"

        return info

    async def _get_memory_info(self, host_id: str) -> Dict[str, str]:
        """Get memory information."""
        result = await self.ssh_manager.execute_command(host_id, "free -h")
        if result.success:
            return {"memory_info": result.stdout.strip()}
        else:
            return {"memory_info": f"Error: {result.stderr}"}

    async def _get_disk_info(self, host_id: str) -> Dict[str, str]:
        """Get disk information."""
        result = await self.ssh_manager.execute_command(host_id, "df -h")
        if result.success:
            return {"disk_usage": result.stdout.strip()}
        else:
            return {"disk_usage": f"Error: {result.stderr}"}