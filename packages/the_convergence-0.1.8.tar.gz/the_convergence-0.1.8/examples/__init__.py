"""
The Convergence - Example configurations and templates.

This package contains working examples for various APIs and use cases.
"""

