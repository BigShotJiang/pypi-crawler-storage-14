"""
Template classes for custom template generation.

Based on proven patterns from working examples.
"""
