"""Command-line interface for The Convergence."""

