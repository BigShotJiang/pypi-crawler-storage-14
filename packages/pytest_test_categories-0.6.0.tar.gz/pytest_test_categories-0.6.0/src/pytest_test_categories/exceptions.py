"""Exception classes for pytest-test-categories.

This module defines the exception hierarchy for resource isolation violations.
These exceptions are raised when tests violate their size category's
resource restrictions.

Exception Hierarchy:
    HermeticityViolationError (base)
    +-- NetworkAccessViolationError
    +-- FilesystemAccessViolationError
    +-- SubprocessViolationError
    +-- DatabaseViolationError
    +-- SleepViolationError (future)

The base HermeticityViolationError provides common functionality:
- Test context (size, nodeid)
- Remediation guidance
- Formatted error messages

Example:
    >>> raise NetworkAccessViolationError(
    ...     test_size=TestSize.SMALL,
    ...     test_nodeid='test_module.py::test_function',
    ...     host='api.example.com',
    ...     port=443
    ... )
    NetworkAccessViolationError: Small tests cannot access the network.
    Test attempted to connect to: api.example.com:443

See Also:
    - ADR-001: docs/architecture/adr-001-network-isolation.md
    - ADR-002: docs/architecture/adr-002-filesystem-isolation.md
    - TimingViolationError: Existing exception in types.py (similar pattern)

"""

from __future__ import annotations

__all__ = [
    'DatabaseViolationError',
    'FilesystemAccessViolationError',
    'HermeticityViolationError',
    'NetworkAccessViolationError',
    'SubprocessViolationError',
]

from typing import TYPE_CHECKING

from pytest_test_categories.types import TestSize

if TYPE_CHECKING:
    from pathlib import Path

    from pytest_test_categories.ports.filesystem import FilesystemOperation as FsOp


class HermeticityViolationError(Exception):
    """Base exception for test hermeticity violations.

    Raised when a test violates its size category's resource restrictions.
    This is the base class for all resource violation exceptions.

    Subclasses should provide:
    - Specific violation details (host, path, command, etc.)
    - Appropriate remediation suggestions
    - Formatted error message

    Attributes:
        test_size: The test's size category.
        test_nodeid: The pytest node ID of the violating test.
        violation_type: A short description of the violation type.
        details: Specific details about the violation.
        remediation: List of suggestions for fixing the violation.

    Example:
        >>> class CustomViolation(HermeticityViolationError):
        ...     _adr_reference = 'docs/architecture/adr-003-custom-isolation.md'
        ...     def __init__(self, test_size, test_nodeid, custom_detail):
        ...         super().__init__(
        ...             test_size=test_size,
        ...             test_nodeid=test_nodeid,
        ...             violation_type='Custom resource access',
        ...             details=f'Accessed: {custom_detail}',
        ...             remediation=['Fix suggestion 1', 'Fix suggestion 2']
        ...         )

    """

    _adr_reference: str = 'docs/architecture/adr-001-network-isolation.md'

    def __init__(
        self,
        test_size: TestSize,
        test_nodeid: str,
        violation_type: str,
        details: str,
        remediation: list[str] | None = None,
    ) -> None:
        """Initialize a hermeticity violation error.

        Args:
            test_size: The test's size category.
            test_nodeid: The pytest node ID of the violating test.
            violation_type: A short description of the violation type.
            details: Specific details about the violation.
            remediation: List of suggestions for fixing the violation.

        """
        self.test_size = test_size
        self.test_nodeid = test_nodeid
        self.violation_type = violation_type
        self.details = details
        self.remediation = remediation or []

        message = self._format_message()
        super().__init__(message)

    def _format_message(self) -> str:
        """Format the error message with full context.

        Returns:
            A formatted multi-line error message.

        """
        lines = [
            '',
            '=' * 60,
            'HermeticityViolationError',
            '=' * 60,
            f'Test: {self.test_nodeid}',
            f'Category: {self.test_size.name}',
            f'Violation: {self.violation_type}',
            '',
            'Details:',
            f'  {self.details}',
            '',
        ]

        if self.remediation:
            lines.append(f'{self.test_size.name.capitalize()} tests have restricted resource access. Options:')
            for i, suggestion in enumerate(self.remediation, 1):
                lines.append(f'  {i}. {suggestion}')
            lines.append('')

        lines.append(f'Documentation: See {self._adr_reference}')
        lines.append('=' * 60)

        return '\n'.join(lines)


class NetworkAccessViolationError(HermeticityViolationError):
    """Raised when a test makes an unauthorized network request.

    This exception is raised when a test attempts to make a network
    connection that violates its size category's restrictions:
    - Small tests: No network access allowed
    - Medium tests: Only localhost connections allowed
    - Large/XLarge tests: All network access allowed

    Attributes:
        host: The attempted destination host.
        port: The attempted destination port.

    Example:
        >>> raise NetworkAccessViolationError(
        ...     test_size=TestSize.SMALL,
        ...     test_nodeid='tests/test_api.py::test_fetch_user',
        ...     host='api.example.com',
        ...     port=443
        ... )

    The error message includes:
    - Test identification (nodeid, size category)
    - Connection details (host:port)
    - Remediation suggestions (mocking, DI, size change)

    """

    def __init__(
        self,
        test_size: TestSize,
        test_nodeid: str,
        host: str,
        port: int,
    ) -> None:
        """Initialize a network access violation error.

        Args:
            test_size: The test's size category.
            test_nodeid: The pytest node ID of the violating test.
            host: The attempted destination host.
            port: The attempted destination port.

        """
        self.host = host
        self.port = port

        remediation = self._get_remediation(test_size)

        super().__init__(
            test_size=test_size,
            test_nodeid=test_nodeid,
            violation_type='Network access attempted',
            details=f'Attempted connection to: {host}:{port}',
            remediation=remediation,
        )

    @staticmethod
    def _get_remediation(test_size: TestSize) -> list[str]:
        """Get remediation suggestions based on test size.

        Args:
            test_size: The test's size category.

        Returns:
            List of remediation suggestions.

        """
        if test_size == TestSize.SMALL:
            return [
                'Mock the network call using responses, httpretty, or respx',
                'Use dependency injection to provide a fake HTTP client',
                'Change test category to @pytest.mark.medium (if network is required)',
            ]
        if test_size == TestSize.MEDIUM:
            return [
                'Use localhost for the service (e.g., run a local mock server)',
                'Mock the external service call',
                'Change test category to @pytest.mark.large (if external network is required)',
            ]
        return []  # Large/XLarge tests have no network restrictions


class FilesystemAccessViolationError(HermeticityViolationError):
    """Raised when a test makes an unauthorized filesystem access.

    This exception is raised when a test attempts filesystem access
    that violates its size category's restrictions:
    - Small tests: No filesystem access (except allowed paths)
    - Medium/Large/XLarge: All filesystem access allowed

    Attributes:
        path: The attempted path.
        operation: The type of operation attempted.

    Example:
        >>> raise FilesystemAccessViolationError(
        ...     test_size=TestSize.SMALL,
        ...     test_nodeid='tests/test_file.py::test_save',
        ...     path=Path('/etc/passwd'),
        ...     operation=FilesystemOperation.READ
        ... )

    The error message includes:
    - Test identification (nodeid, size category)
    - Path and operation details
    - Remediation suggestions (tmp_path, mocking, size change)

    """

    _adr_reference: str = 'docs/architecture/adr-002-filesystem-isolation.md'

    def __init__(
        self,
        test_size: TestSize,
        test_nodeid: str,
        path: Path,
        operation: FsOp,
    ) -> None:
        """Initialize a filesystem access violation error.

        Args:
            test_size: The test's size category.
            test_nodeid: The pytest node ID of the violating test.
            path: The attempted path.
            operation: The type of operation attempted.

        """
        # Import locally to avoid circular dependency

        self.path = path
        self.operation: FsOp = operation

        remediation = self._get_remediation(test_size, operation)

        super().__init__(
            test_size=test_size,
            test_nodeid=test_nodeid,
            violation_type='Filesystem access attempted',
            details=f'Attempted {operation.value} on: {path}',
            remediation=remediation,
        )

    @staticmethod
    def _get_remediation(test_size: TestSize, operation: FsOp) -> list[str]:
        """Get remediation suggestions based on test size and operation.

        Args:
            test_size: The test's size category.
            operation: The type of operation attempted.

        Returns:
            List of remediation suggestions.

        """
        # Import locally to avoid circular dependency
        from pytest_test_categories.ports.filesystem import FilesystemOperation as FsOp  # noqa: PLC0415

        if test_size == TestSize.SMALL:
            suggestions = [
                "Use pytest's tmp_path fixture for temporary files",
                'Mock file operations using pytest-mock (mocker fixture) or pyfakefs',
                'Use io.StringIO or io.BytesIO for in-memory file-like objects',
            ]
            if operation in (FsOp.READ, FsOp.STAT):
                suggestions.append('Embed test data as Python constants or use importlib.resources')
            suggestions.append('Change test category to @pytest.mark.medium (if filesystem access is required)')
            return suggestions
        return []  # Medium/Large/XLarge tests have no filesystem restrictions


class SubprocessViolationError(HermeticityViolationError):
    """Raised when a test attempts to spawn a subprocess.

    This exception is raised when a test attempts to spawn a subprocess
    that violates its size category's restrictions:
    - Small tests: No subprocess spawning allowed
    - Medium/Large/XLarge: All subprocess spawning allowed

    Small tests should run in a single process according to Google's
    test size definitions. Subprocess spawning introduces:
    - Non-determinism from external process behavior
    - I/O overhead from process creation
    - Timing variability that can cause flaky tests

    Attributes:
        command: The command that was attempted.
        command_args: The arguments passed to the command.
        method: The method used to spawn (e.g., 'subprocess.run', 'os.system').

    Example:
        >>> raise SubprocessViolationError(
        ...     test_size=TestSize.SMALL,
        ...     test_nodeid='tests/test_cli.py::test_run_command',
        ...     command='python',
        ...     command_args=('script.py', '--verbose'),
        ...     method='subprocess.run'
        ... )

    The error message includes:
    - Test identification (nodeid, size category)
    - Command and arguments details
    - Remediation suggestions (mocking, DI, size change)

    """

    _adr_reference: str = 'docs/architecture/adr-003-process-isolation.md'

    def __init__(
        self,
        test_size: TestSize,
        test_nodeid: str,
        command: str,
        command_args: tuple[str, ...],
        method: str,
    ) -> None:
        """Initialize a subprocess violation error.

        Args:
            test_size: The test's size category.
            test_nodeid: The pytest node ID of the violating test.
            command: The command that was attempted.
            command_args: The arguments passed to the command.
            method: The spawn method used (e.g., 'subprocess.run').

        """
        self.command = command
        self.command_args = command_args
        self.method = method

        args_str = ' '.join(command_args) if command_args else '(no args)'
        remediation = self._get_remediation(test_size, method)

        super().__init__(
            test_size=test_size,
            test_nodeid=test_nodeid,
            violation_type='Subprocess spawn attempted',
            details=f'Attempted {method}: {command} {args_str}',
            remediation=remediation,
        )

    @staticmethod
    def _get_remediation(test_size: TestSize, method: str) -> list[str]:
        """Get remediation suggestions based on test size and spawn method.

        Args:
            test_size: The test's size category.
            method: The spawn method used.

        Returns:
            List of remediation suggestions.

        """
        if test_size == TestSize.SMALL:
            suggestions = [
                f'Mock {method} using pytest-mock (mocker.patch)',
                'Use dependency injection to provide a fake command executor',
                'Test the logic that prepares subprocess arguments, not the spawn itself',
            ]
            if 'pytester' in method.lower() or method == 'subprocess.run':
                suggestions.append('Change test category to @pytest.mark.medium (pytester spawns subprocesses)')
            else:
                suggestions.append('Change test category to @pytest.mark.medium (if subprocess is required)')
            return suggestions
        return []  # Medium/Large/XLarge tests have no subprocess restrictions


class DatabaseViolationError(HermeticityViolationError):
    """Raised when a test attempts to connect to a database.

    This exception is raised when a test attempts to make a database
    connection that violates its size category's restrictions:
    - Small tests: No database access allowed (including :memory:)
    - Medium/Large/XLarge: All database access allowed

    Small tests should be hermetic and run entirely in memory without
    any I/O operations. Database connections, even to in-memory databases
    like sqlite3 :memory:, introduce:
    - I/O operations via the database engine
    - External state dependencies
    - Non-deterministic behavior potential
    - Additional process complexity

    Attributes:
        library: The database library name (e.g., 'sqlite3', 'psycopg2').
        connection_string: The connection string or database path.

    Example:
        >>> raise DatabaseViolationError(
        ...     test_size=TestSize.SMALL,
        ...     test_nodeid='tests/test_db.py::test_query',
        ...     library='sqlite3',
        ...     connection_string=':memory:'
        ... )

    The error message includes:
    - Test identification (nodeid, size category)
    - Library and connection details
    - Remediation suggestions (mocking, DI, size change)

    """

    _adr_reference: str = 'docs/architecture/adr-004-database-isolation.md'

    def __init__(
        self,
        test_size: TestSize,
        test_nodeid: str,
        library: str,
        connection_string: str,
    ) -> None:
        """Initialize a database violation error.

        Args:
            test_size: The test's size category.
            test_nodeid: The pytest node ID of the violating test.
            library: The database library name.
            connection_string: The connection string or database path.

        """
        self.library = library
        self.connection_string = connection_string

        remediation = self._get_remediation(test_size, library)

        super().__init__(
            test_size=test_size,
            test_nodeid=test_nodeid,
            violation_type='Database access attempted',
            details=f'Attempted {library} connection to: {connection_string}',
            remediation=remediation,
        )

    @staticmethod
    def _get_remediation(test_size: TestSize, library: str) -> list[str]:
        """Get remediation suggestions based on test size and database library.

        Args:
            test_size: The test's size category.
            library: The database library used.

        Returns:
            List of remediation suggestions.

        """
        if test_size == TestSize.SMALL:
            suggestions = [
                f'Mock {library}.connect using pytest-mock (mocker.patch)',
                'Use dependency injection to provide a fake database/repository',
                'Use in-memory data structures (dict, list) for test data',
                'Test business logic separately from database operations',
            ]
            if library == 'sqlalchemy':
                suggestions.append('Consider using SQLAlchemy events or a fake engine')
            suggestions.append('Change test category to @pytest.mark.medium (if database access is required)')
            return suggestions
        return []  # Medium/Large/XLarge tests have no database restrictions
