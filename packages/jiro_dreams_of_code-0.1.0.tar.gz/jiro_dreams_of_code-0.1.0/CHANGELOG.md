# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## \[Unreleased\]

### Added

- Initial project scaffolding
- Technical specification document
- Beads issue tracking integration
- Developer make targets for type checking, formatting, and pre-commit
- CI pre-commit job plus markdown formatting enforcement
- Dependabot automation for pip/uv and GitHub Actions
- Publish workflow to build/test/tag releases via PyPI
- AGENTS.md with commit philosophy and PR protocol
- Pre-commit hook to prevent direct commits to main branch
- Pre-commit hook to isolate .beads commits from code changes
