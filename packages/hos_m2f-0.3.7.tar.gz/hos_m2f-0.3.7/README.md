# HOS_M2F

Markdown 多格式转换与图形渲染：支持 DOCX/PDF/XML/JSON，以及将 Mermaid/Matplotlib/表格渲染为图片（PNG）。

## 功能
- `Markdown → DOCX/PDF/XML/JSON`
- `Mermaid → PNG`
- 自动识别 `python/matplotlib` 代码块并生成图像
- 自动识别 Markdown 表格，优先渲染为 PNG，失败回退为结构或文本

## 安装
```bash
python -m pip install HOS_M2F
# 首次使用需安装浏览器内核
python -m playwright install chromium
```

## 命令行
- 点号脚本（推荐）：
  ```bash
  HOS_M2F.2docx input.md output.docx
  HOS_M2F.2pdf  input.md output.pdf
  HOS_M2F.2xml  input.md output.xml
  HOS_M2F.2json input.md output.json
  HOS_M2F.2png  input.mmd output.png
  ```
- 模块方式：
  ```bash
  python -m hos_m2f.md2docx_mermaid input.md output.docx
  python -m hos_m2f.md2pdf          input.md output.pdf
  python -m hos_m2f.md2xml          input.md output.xml
  python -m hos_m2f.md2json         input.md output.json
  python -m hos_m2f.render_mermaid  input.mmd output.png
  ```

## 使用提示
- Mermaid 块以三引号代码块标注：
  ```
  ```mermaid
  graph TD
    A --> B
  ```
  ```
- 若使用内联 Mermaid（不加代码块围栏），包也会自动检测并渲染。
- 识别 `python/matplotlib` 代码块并保存为 PNG；表格将优先渲染为 PNG，失败时在 XML/JSON 中以结构形式呈现，在 PDF 中以简洁文本呈现。

## 发布流程（PyPI/TestPyPI）
按照 Python Packaging 官方教程进行（Packaging Python Projects）。本项目已配置：
- `pyproject.toml` 使用 Setuptools 后端
- 入口脚本以 `HOS_M2F.2*` 点号样式注册
- `README.md` 与 `LICENSE` 纳入包元数据

### 本地构建
```bash
python -m pip install -U build twine
python -m build
```

### 上传到 TestPyPI（推荐先试跑）
- 使用 API Token 文件，例如 `c:\Users\LXCXJXHX\Desktop\QUESTION\PYPI.txt`，内容以 `pypi-` 开头。
- 通过脚本：
  ```powershell
  ./scripts/publish_testpypi.ps1 -TokenPath "c:\Users\LXCXJXHX\Desktop\QUESTION\PYPI.txt"
  ```
  脚本将使用用户名 `__token__` 和文件中的 Token 上传。

### 上传到 PyPI（正式）
```powershell
./scripts/publish_pypi.ps1 -TokenPath "c:\Users\LXCXJXHX\Desktop\QUESTION\PYPI.txt"
```
> 如果使用账户口令而非 API Token，可将脚本中的用户名参数改为你的用户名（示例：`security_hyacinth`），并以口令作为密码。

## 许可证
MIT License，详见 `LICENSE`。

## 致谢
- Python Packaging User Guide: Packaging Python Projects
- Playwright, python-docx, Mermaid
