import sys
from pathlib import Path
import zipfile
import xml.etree.ElementTree as ET
from docx import Document
from docx.text.paragraph import Paragraph as _Paragraph
from docx.table import Table as _Table
from docx.enum.text import WD_ALIGN_PARAGRAPH
import json

NS_W = '{http://schemas.openxmlformats.org/wordprocessingml/2006/main}'
NS_REL = '{http://schemas.openxmlformats.org/officeDocument/2006/relationships}'
NS_A = '{http://schemas.openxmlformats.org/drawingml/2006/main}'
NS_PKG = '{http://schemas.openxmlformats.org/package/2006/relationships}'
NS_VML = '{urn:schemas-microsoft-com:vml}'

def _resolve_target(target: str) -> str:
    t = (target or '').replace('\\','/').lstrip('/')
    if t.startswith('../'):
        return 'word/' + t[3:]
    if t.startswith('word/'):
        return t
    if t.startswith('media/'):
        return 'word/' + t
    return 'word/' + t

def _collect_image_order(docx_path: Path):
    with zipfile.ZipFile(str(docx_path), 'r') as z:
        body_xml = z.read('word/document.xml')
        rels_xml = z.read('word/_rels/document.xml.rels')
    root = ET.fromstring(body_xml)
    rels = ET.fromstring(rels_xml)
    rid_to_target = {}
    rid_to_external = {}
    header_ids = []
    footer_ids = []
    for r in rels.findall('.//' + NS_PKG + 'Relationship'):
        rid = r.attrib.get('Id')
        tgt = r.attrib.get('Target')
        mode = r.attrib.get('TargetMode')
        typ = r.attrib.get('Type')
        if rid and tgt:
            if mode is None or mode != 'External':
                rid_to_target[rid] = tgt
            else:
                rid_to_external[rid] = tgt
            if typ and typ.endswith('/header'):
                header_ids.append((rid, tgt))
            elif typ and typ.endswith('/footer'):
                footer_ids.append((rid, tgt))
    body_order = []
    body_external = []
    # drawingML in body
    for blip in root.findall('.//' + NS_A + 'blip'):
        rid = blip.attrib.get(NS_REL + 'embed')
        if rid and rid in rid_to_target:
            body_order.append((rid, rid_to_target[rid]))
        rlink = blip.attrib.get(NS_REL + 'link')
        if rlink and rlink in rid_to_external:
            body_external.append(('body', rid_to_external[rlink]))
    # VML fallback in body
    for vimg in root.findall('.//' + NS_VML + 'imagedata'):
        rid = vimg.attrib.get(NS_REL + 'id')
        if rid and rid in rid_to_target:
            body_order.append((rid, rid_to_target[rid]))
        rlink = vimg.attrib.get(NS_REL + 'id')
        if rlink and rlink in rid_to_external:
            body_external.append(('body', rid_to_external[rlink]))

    def _collect_from_part(docx_path: Path, part_rel_target: str):
        with zipfile.ZipFile(str(docx_path), 'r') as z:
            part_xml = z.read(_resolve_target(part_rel_target))
            # header1.xml -> word/_rels/header1.xml.rels
            rels_name = 'word/_rels/' + Path(part_rel_target).name + '.rels'
            try:
                rels_xml_local = z.read(rels_name)
            except KeyError:
                rels_xml_local = b'<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"/>'
        root_local = ET.fromstring(part_xml)
        rels_local = ET.fromstring(rels_xml_local)
        rid2t = {}
        rid2ext = {}
        for r in rels_local.findall('.//' + NS_PKG + 'Relationship'):
            rid = r.attrib.get('Id')
            tgt = r.attrib.get('Target')
            mode = r.attrib.get('TargetMode')
            if rid and tgt:
                if mode is None or mode != 'External':
                    rid2t[rid] = tgt
                else:
                    rid2ext[rid] = tgt
        out = []
        out_ext = []
        for blip in root_local.findall('.//' + NS_A + 'blip'):
            rid = blip.attrib.get(NS_REL + 'embed')
            if rid and rid in rid2t:
                out.append((rid, rid2t[rid]))
            rlink = blip.attrib.get(NS_REL + 'link')
            if rlink and rlink in rid2ext:
                out_ext.append(rid2ext[rlink])
        for vimg in root_local.findall('.//' + NS_VML + 'imagedata'):
            rid = vimg.attrib.get(NS_REL + 'id')
            if rid and rid in rid2t:
                out.append((rid, rid2t[rid]))
            if rid and rid in rid2ext:
                out_ext.append(rid2ext[rid])
        return out, out_ext

    header_order = []
    header_external = []
    for _, tgt in header_ids:
        o, oe = _collect_from_part(docx_path, tgt)
        header_order.extend(o)
        header_external.extend(oe)
    footer_order = []
    footer_external = []
    for _, tgt in footer_ids:
        o, oe = _collect_from_part(docx_path, tgt)
        footer_order.extend(o)
        footer_external.extend(oe)
    externals = body_external + [('header', u) for u in header_external] + [('footer', u) for u in footer_external]
    return body_order, header_order, footer_order, externals

def _extract_images_zip(docx_path: Path, out_zip: Path, body_order, header_order, footer_order, externals):
    with zipfile.ZipFile(str(docx_path), 'r') as z, zipfile.ZipFile(str(out_zip), 'w', compression=zipfile.ZIP_DEFLATED) as zout:
        # body images
        for idx, ((_, target)) in enumerate(body_order, start=1):
            inner = _resolve_target(target)
            ext = Path(target).suffix.lower() or '.bin'
            data = z.read(inner)
            name = f'body/image_{idx:03d}{ext}'
            zout.writestr(name, data)
        # header images
        for idx, ((_, target)) in enumerate(header_order, start=1):
            inner = _resolve_target(target)
            ext = Path(target).suffix.lower() or '.bin'
            data = z.read(inner)
            name = f'header/image_{idx:03d}{ext}'
            zout.writestr(name, data)
        # footer images
        for idx, ((_, target)) in enumerate(footer_order, start=1):
            inner = _resolve_target(target)
            ext = Path(target).suffix.lower() or '.bin'
            data = z.read(inner)
            name = f'footer/image_{idx:03d}{ext}'
            zout.writestr(name, data)
        # manifest
        manifest = {
            'body': [f'body/image_{i+1:03d}{Path(t).suffix.lower() or ".bin"}' for i, (_, t) in enumerate(body_order)],
            'header': [f'header/image_{i+1:03d}{Path(t).suffix.lower() or ".bin"}' for i, (_, t) in enumerate(header_order)],
            'footer': [f'footer/image_{i+1:03d}{Path(t).suffix.lower() or ".bin"}' for i, (_, t) in enumerate(footer_order)],
            'external': [{'section': sec, 'url': url} for (sec, url) in externals],
        }
        zout.writestr('manifest.json', json.dumps(manifest, ensure_ascii=False, indent=2))

def _paragraph_to_md(p: _Paragraph):
    txt = p.text or ''
    name = (p.style.name if p.style else '') or ''
    if name.startswith('Heading'):
        try:
            lvl = int(name.split()[-1])
        except Exception:
            lvl = 1
        return '#' * max(1, min(6, lvl)) + ' ' + txt.strip()
    if 'List Bullet' in name:
        return '- ' + txt.strip()
    if 'List Number' in name:
        return '1. ' + txt.strip()
    return txt

def _table_to_md(t: _Table):
    rows = [[c.text.replace('\n', ' ').strip() for c in row.cells] for row in t.rows]
    if not rows:
        return []
    header = rows[0]
    body = rows[1:] if len(rows) > 1 else []
    # alignment per column based on first row cells
    aligns = []
    for idx, c in enumerate(t.rows[0].cells):
        try:
            a = c.paragraphs[0].alignment
        except Exception:
            a = None
        if a == WD_ALIGN_PARAGRAPH.CENTER:
            aligns.append(':---:')
        elif a == WD_ALIGN_PARAGRAPH.RIGHT:
            aligns.append('---:')
        elif a == WD_ALIGN_PARAGRAPH.LEFT:
            aligns.append(':---')
        else:
            aligns.append('---')
    out = [
        '| ' + ' | '.join(header) + ' |',
        '| ' + ' | '.join(aligns) + ' |',
    ]
    for r in body:
        out.append('| ' + ' | '.join(r) + ' |')
    return out

def convert_docx_to_md(docx_path: Path, out_md: Path):
    doc = Document(str(docx_path))
    md_lines = []
    body = doc.element.body
    for child in body.iterchildren():
        tag = child.tag
        if tag == NS_W + 'p':
            p = _Paragraph(child, doc)
            md_lines.append(_paragraph_to_md(p))
            md_lines.append('')
        elif tag == NS_W + 'tbl':
            t = _Table(child, doc)
            md_lines.extend(_table_to_md(t))
            md_lines.append('')
    out_md.write_text('\n'.join(md_lines), encoding='utf-8')
    body_order, header_order, footer_order, externals = _collect_image_order(docx_path)
    zip_path = out_md.with_suffix('.zip')
    _extract_images_zip(docx_path, zip_path, body_order, header_order, footer_order, externals)

def main():
    import argparse
    parser = argparse.ArgumentParser(
        prog='HOS_M2F.docx2md',
        description='DOCX 逆向为 Markdown，并按出现顺序打包图片到同名压缩包',
        epilog=(
            '示例:\n'
            '  HOS_M2F.docx2md input.docx output.md\n'
            '相关命令:\n'
            '  HOS_M2F.2docx input.md output.docx [-p paper|patent|softcopy] [-nm] [-nc] [-q]\n'
            '  HOS_M2F.batch input_dir output_dir [-p paper|patent|softcopy] [-nm] [-nc] [-q]\n'
        ),
    )
    parser.add_argument('input', help='输入 DOCX 文件路径')
    parser.add_argument('output', help='输出 Markdown 文件路径')
    args = parser.parse_args()
    inp = Path(args.input)
    outp = Path(args.output)
    convert_docx_to_md(inp, outp)

if __name__ == '__main__':
    main()
