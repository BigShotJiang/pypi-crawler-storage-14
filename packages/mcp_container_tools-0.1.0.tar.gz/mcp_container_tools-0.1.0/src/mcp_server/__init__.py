"""MCP Server - A well-structured Model Context Protocol server."""

from mcp_server.server import create_server

__version__ = "0.1.0"
__all__ = ["create_server"]
