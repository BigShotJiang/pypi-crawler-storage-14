import core

print(core.get_all_beyts())