"""
questions_mcp_server 顶层包

用于提供 `python -m questions_mcp_server` 启动方式，统一入口到 src.main.main。
"""

from .__main__ import main

__all__ = ["main"]

