# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------
"""Does not exist error."""


class DoesNotExistError(ValueError):
    """Throws a does not exist error."""

    pass
