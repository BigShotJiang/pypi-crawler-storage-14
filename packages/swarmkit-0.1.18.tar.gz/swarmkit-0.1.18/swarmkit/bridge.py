"""Node.js bridge subprocess manager for JSON-RPC communication."""

import asyncio
import json
import logging
import subprocess
import weakref
from pathlib import Path
from typing import Any, Callable, Dict, Optional


logger = logging.getLogger(__name__)


def _cleanup_process(process: subprocess.Popen):
    """Cleanup function to kill process on finalization."""
    if process and process.poll() is None:
        try:
            process.terminate()
            process.wait(timeout=2)
        except (subprocess.TimeoutExpired, Exception):
            try:
                process.kill()
                process.wait(timeout=1)
            except Exception:
                pass


class SandboxNotFoundError(Exception):
    """Raised when sandbox is not found (expired or killed)."""
    pass


class BridgeConnectionError(Exception):
    """Raised when bridge process fails to start or dies unexpectedly."""
    pass


class BridgeBuildError(Exception):
    """Raised when bridge build (npm install/build) fails."""
    pass


class BridgeManager:
    """Manages Node.js subprocess running the JSON-RPC bridge."""

    def __init__(self):
        self.process: Optional[subprocess.Popen] = None
        self.request_id = 0
        self.pending_requests: Dict[int, asyncio.Future] = {}
        self.event_callbacks: Dict[str, list[Callable]] = {
            'stdout': [],
            'stderr': [],
            'update': [],
            'error': [],
            'complete': [],
        }
        self.reader_task: Optional[asyncio.Task] = None
        self._finalizer = None

    async def start(self):
        """Start the Node.js bridge process."""
        if self.process is not None:
            return

        # Find bridge script (bundled version for distribution)
        bridge_dir = Path(__file__).parent.parent / 'bridge'
        bridge_script = bridge_dir / 'dist' / 'bridge.bundle.cjs'

        # Fallback to unbundled version for development
        if not bridge_script.exists():
            bridge_script = bridge_dir / 'dist' / 'bridge.js'

        # Auto-build bridge if missing (turnkey experience)
        if not bridge_script.exists():
            import shutil

            # Check if Node.js and npm are installed
            if not shutil.which('node'):
                raise BridgeBuildError(
                    "Bridge build failed: Node.js not found in PATH.\n"
                    "SwarmKit requires Node.js 18+ to run the TypeScript bridge.\n"
                    "Install from https://nodejs.org/ or run 'make build-dev' manually from packages/sdk-py/."
                )

            if not shutil.which('npm'):
                raise BridgeBuildError(
                    "Bridge build failed: npm not found in PATH.\n"
                    "npm is usually installed with Node.js - check your Node.js installation.\n"
                    "Alternatively, run 'make build-dev' manually from packages/sdk-py/."
                )

            logger.info("First run: building Node.js bridge...")
            try:
                # Run npm install/build in executor to avoid blocking event loop
                loop = asyncio.get_running_loop()

                # Install dependencies
                await loop.run_in_executor(
                    None,
                    lambda: subprocess.run(
                        ['npm', 'install'],
                        cwd=bridge_dir,
                        check=True,
                        capture_output=True,
                        text=True
                    )
                )

                # Build bridge (dev mode for readable debugging)
                await loop.run_in_executor(
                    None,
                    lambda: subprocess.run(
                        ['npm', 'run', 'build:dev'],
                        cwd=bridge_dir,
                        check=True,
                        capture_output=True,
                        text=True
                    )
                )
                logger.info("Bridge built successfully")
            except subprocess.CalledProcessError as e:
                raise BridgeBuildError(
                    f"Bridge build failed during npm execution.\n"
                    f"Error: {e.stderr}\n"
                    f"Try running 'make build-dev' or 'make build-prod' manually from packages/sdk-py/ to see the full error."
                ) from e

        # Start Node.js process
        self.process = subprocess.Popen(
            ['node', str(bridge_script)],
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,  # Merge stderr into stdout to prevent pipe deadlock
            text=True,
            bufsize=1,
        )

        # Register finalizer to ensure process is killed when manager is GC'd
        self._finalizer = weakref.finalize(self, _cleanup_process, self.process)

        # Start reading responses
        self.reader_task = asyncio.create_task(self._read_responses())

    async def stop(self):
        """Stop the Node.js bridge process."""
        if self.process is None:
            return

        # Note: We intentionally do NOT clear event_callbacks here
        # User-registered callbacks should persist across bridge restarts

        # Detach finalizer since we are manually stopping
        if self._finalizer:
            self._finalizer.detach()
            self._finalizer = None

        self.process.terminate()
        try:
            self.process.wait(timeout=5)
        except subprocess.TimeoutExpired:
            self.process.kill()
            self.process.wait()

        if self.reader_task:
            self.reader_task.cancel()
            try:
                await self.reader_task
            except asyncio.CancelledError:
                pass

        self.process = None
        self.reader_task = None

    def on(self, event_type: str, callback: Callable):
        """Register event callback."""
        if event_type in self.event_callbacks:
            self.event_callbacks[event_type].append(callback)

    async def call(self, method: str, params: Optional[Dict[str, Any]] = None) -> Any:
        """Call a JSON-RPC method and wait for response."""
        if self.process is None or self.process.stdin is None:
            raise BridgeConnectionError("Bridge not started. Call start() first.")

        self.request_id += 1
        request_id = self.request_id

        request = {
            'jsonrpc': '2.0',
            'method': method,
            'params': params or {},
            'id': request_id,
        }

        # Create future for response
        future = asyncio.Future()
        self.pending_requests[request_id] = future

        # Send request
        request_json = json.dumps(request) + '\n'
        self.process.stdin.write(request_json)
        self.process.stdin.flush()

        # Wait for response (error handling done in _handle_response)
        return await future

    async def _read_responses(self):
        """Read responses from bridge stdout."""
        if self.process is None or self.process.stdout is None:
            return

        try:
            loop = asyncio.get_running_loop()
            while True:
                line = await loop.run_in_executor(
                    None, self.process.stdout.readline
                )

                if not line:
                    break

                try:
                    message = json.loads(line)

                    # Check if it's an event notification
                    if 'method' in message and message.get('method') == 'event':
                        self._handle_event(message['params'])
                    # Check if it's a response
                    elif 'id' in message:
                        self._handle_response(message)

                except json.JSONDecodeError:
                    # Ignore non-JSON output (e.g., debug logs)
                    pass

        except Exception as e:
            logger.error(f"Bridge reader died: {e}")
        finally:
            # Fail all pending requests so callers don't hang
            error = BridgeConnectionError("Bridge process terminated unexpectedly")
            for request_id, future in list(self.pending_requests.items()):
                if not future.done():
                    future.set_exception(error)
            self.pending_requests.clear()

    def _handle_event(self, params: Dict[str, Any]):
        """Handle event notification from bridge."""
        event_type = params.get('type')

        if event_type == 'stdout':
            for callback in self.event_callbacks['stdout']:
                callback(params.get('data', ''))

        elif event_type == 'stderr':
            for callback in self.event_callbacks['stderr']:
                callback(params.get('data', ''))

        elif event_type == 'update':
            for callback in self.event_callbacks['update']:
                callback(params.get('data', ''))

        elif event_type == 'error':
            for callback in self.event_callbacks['error']:
                callback(params.get('error', ''))

        elif event_type == 'complete':
            for callback in self.event_callbacks['complete']:
                callback(params)

    def _handle_response(self, message: Dict[str, Any]):
        """Handle JSON-RPC response."""
        request_id = message.get('id')
        if request_id is None or request_id not in self.pending_requests:
            return

        future = self.pending_requests.pop(request_id)

        if 'error' in message:
            error = message['error']
            error_code = error.get('code', -32603)
            error_message = error.get('message', 'Unknown error')

            # Check for NotFoundError (code -32001 or message pattern)
            if error_code == -32001 or 'not found' in error_message.lower():
                future.set_exception(SandboxNotFoundError(error_message))
            else:
                future.set_exception(Exception(error_message))
        else:
            future.set_result(message.get('result'))
