# Псевдоним сервисной БД
SERVICE_DB_ALIAS = 'service'
