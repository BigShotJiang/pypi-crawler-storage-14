from dataclasses import (
    dataclass,
)
from datetime import (
    datetime,
)
from typing import (
    Iterable,
    Optional,
)

from celery.result import (
    AsyncResult,
)

from m3_db_utils.models import (
    ModelEnumValue,
)

from educommon import (
    logger,
)
from educommon.async_task.models import (
    AsyncTaskStatus,
    RunningTask,
)


@dataclass
class TaskResult:
    """Результат асинхронной задачи."""

    values: dict
    progress: str = ''
    error: str = ''
    state: str = ''


def get_running_task_result(running_task: 'RunningTask') -> TaskResult:
    """Возвращает информацию о состоянии и результатах асинхронной задачи."""
    task_id = str(running_task.id)
    async_result = AsyncResult(task_id)
    result = TaskResult(
        values={},
        state=async_result.state,
    )

    if async_result.result:
        if isinstance(async_result.result, Exception):
            if async_result.traceback:
                result.error = async_result.traceback
            else:
                result.error = async_result.result.__repr__()

        elif isinstance(async_result.result, dict):
            result.progress = async_result.result.get('progress', 'Неизвестно')
            result.values = async_result.result.get('values', {})

    else:
        # Результат задачи отсутствует. Проверим, не истёк ли строк хранения результата
        task_key = async_result.backend.get_key_for_task(task_id)
        task_result_is_none = async_result.backend.get(task_key) is None

        if task_result_is_none and (
            AsyncTaskStatus.is_finished(running_task.status)
            or running_task.finished_at is not None
        ):
            result.progress = 'Истек срок хранения результатов задачи'
            result.state = ''

    return result


def revoke_async_tasks(task_ids: Iterable[str]):
    """Прерывает выполнение асинхронных задач."""
    for task_id in task_ids:
        result = AsyncResult(task_id)
        status = AsyncTaskStatus.from_state(result.state)

        if AsyncTaskStatus.is_cancellable(status):
            if status == AsyncTaskStatus.STARTED:
                terminate = True
            else:
                terminate = False

            result.revoke(terminate=terminate)
            update_running_task(task_id, status=AsyncTaskStatus.REVOKED)


def update_running_task(task_id: str, **params):
    """Обновляет запись задачи RunningTask."""
    if 'status' in params and isinstance(params['status'], ModelEnumValue):
        params['status_id'] = params.pop('status').key

    RunningTask.objects.filter(id=task_id).update(**params)


def check_and_fix_task_status(
    running_task: 'RunningTask',
    dry_run: bool = False,
) -> tuple[Optional[AsyncTaskStatus], bool]:
    """Синхронизирует статус задачи в БД и Celery backend, если dry_run=False, либо просто возвращает celery статус.

    Args:
        running_task (RunningTask): Экземпляр задачи для проверки.
        dry_run (bool): Если True — только логирует несоответствия без обновления БД.

    Returns:
        status: Фактический статус задачи (AsyncTaskStatus) или UNKNOWN, если статус недоступен.
        is_updated: True, если статус был обновлен, False в противном случае.
    """
    task_result = get_running_task_result(running_task)
    if task_result.state:
        celery_status = AsyncTaskStatus.from_state(task_result.state)
    else:
        if running_task.status.key in (
            AsyncTaskStatus.PENDING.key,
            AsyncTaskStatus.RECEIVED.key,
            AsyncTaskStatus.STARTED.key,
            AsyncTaskStatus.RETRY.key,
        ):
            # Если задачи нет в очереди селери а в логах у нее активный статус, то ставим статус UNKNOWN
            celery_status = AsyncTaskStatus.UNKNOWN
        else:
            # Иначе оставляем без изменений
            celery_status = None

    if not dry_run and celery_status and celery_status.key != running_task.status.key:
        update_running_task(running_task.id, status=celery_status)
        is_updated = True
    else:
        is_updated = False

    return celery_status, is_updated


def sync_task_statuses(
    from_queued_at: Optional[datetime] = None,
    to_queued_at: Optional[datetime] = None,
    limit: Optional[int] = None,
    dry_run: bool = False,
    task_id: Optional[str] = None,
) -> None:
    """Синхронизирует статусы задач между Celery backend и БД.

    Args:
        from_queued_at: Дата начала периода.
        to_queued_at: Дата окончания периода.
        limit: Максимальное количество задач для проверки.
        dry_run: Если True — только логирует несоответствия без обновления БД.
        task_id: ID конкретной задачи (если указан, остальные фильтры игнорируются).
    """
    base_queryset = RunningTask.objects.select_related('status')

    if task_id:
        queryset = base_queryset.filter(id=task_id)
    else:
        queryset = base_queryset

        if from_queued_at:
            queryset = queryset.filter(queued_at__gte=from_queued_at)

        if to_queued_at:
            queryset = queryset.filter(queued_at__lte=to_queued_at)

        queryset = queryset.order_by('-queued_at')
        if limit:
            queryset = queryset[:limit]

    total_tasks = queryset.count()
    logger.info(f'Синхронизация статусов: проверка {total_tasks} задач...')

    mismatches = 0
    updated = 0

    for running_task in queryset:
        db_status = running_task.status
        celery_status, is_updated = check_and_fix_task_status(running_task, dry_run=dry_run)

        if celery_status and celery_status.key != db_status.key:
            mismatches += 1
            msg = (
                f'[{str(running_task.id)}] {running_task.name}: '
                f'{db_status.title} → {celery_status.title}'
            )

            if dry_run:
                logger.info(msg)
            elif is_updated:
                updated += 1
                logger.info(f'{msg} [ОБНОВЛЕНО]')

    if mismatches == 0:
        logger.info('Несоответствий статусов не найдено')
    else:
        if dry_run:
            logger.info(
                f'Найдено несоответствий: {mismatches}. '
                'Запустите без --dry-run для обновления статусов.'
            )
        else:
            logger.info(f'Найдено несоответствий: {mismatches}, обновлено задач: {updated}')
