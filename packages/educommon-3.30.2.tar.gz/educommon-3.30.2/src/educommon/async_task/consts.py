# формат времени старта задачи
TASK_START_TIME_FORMAT = '%H:%M %d.%m.%Y'

# отображение пользователя, если пользователь не задан
TASK_DEFAULT_USER_NAME = 'Система'

# Очередь для периодических задач.
TASK_QUEUE_NAME = 'periodic_task_default'
