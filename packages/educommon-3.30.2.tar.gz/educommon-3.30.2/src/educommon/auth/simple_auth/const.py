AUTH_CONTROLLER_URL = '/auth'
AUTH_PACK_URL = ''
LOGIN_PAGE_URL = '/login-page'
RESET_PASSWORD_PAGE_URL = '/reset-password-page'
RESET_PASSWORD_URL = '/reset-password'
CHANGE_RESET_PASSWORD_PAGE_URL = '/change-reset-password-page'
CHANGE_RESET_PASSWORD_URL = '/change-reset-password'

# Время жизни кода сброшенного пароля (в минутах)
RESET_CODES_LIFE = 10
