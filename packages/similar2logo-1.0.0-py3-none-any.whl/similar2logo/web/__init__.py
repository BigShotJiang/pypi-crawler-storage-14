"""Web interface for SIMILAR2Logo simulations."""

from .server import WebSimulation

__all__ = ["WebSimulation"]
