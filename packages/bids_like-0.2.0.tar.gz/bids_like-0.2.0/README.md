# BIDS_like

A lightweight Python library for handling BIDS-like datasets. They do not need to strictly follow the BIDS specification, but they should have a similar folder and file structure. All valid BIDS datasets are valid BIDS-like datasets.
