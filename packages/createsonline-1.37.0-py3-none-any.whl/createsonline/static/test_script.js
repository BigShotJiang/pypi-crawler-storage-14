console.log('🚀 CREATESONLINE v0.1.4 - Dynamic routing active!');

// Display feature announcement
setTimeout(() => {
    const features = [
        '✅ Automatic static file serving',
        '✅ No manual route configuration',
        '✅ Smart MIME type detection', 
        '✅ Built-in file caching',
        '✅ Security: Path traversal protection'
    ];
    
    console.log('\n🎯 Dynamic Static File Routing Features:');
    features.forEach(feature => console.log(`  ${feature}`));
}, 100);
