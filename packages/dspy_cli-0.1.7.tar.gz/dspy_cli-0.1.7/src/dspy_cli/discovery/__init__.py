"""Program discovery utilities."""

from dspy_cli.discovery.module_finder import discover_modules, DiscoveredModule

__all__ = ["discover_modules", "DiscoveredModule"]
