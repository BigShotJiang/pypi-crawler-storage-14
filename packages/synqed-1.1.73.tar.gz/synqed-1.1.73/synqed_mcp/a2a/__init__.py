"""a2a client module for mcp tools."""

from synqed_mcp.a2a.client import A2AClient

__all__ = ["A2AClient"]

