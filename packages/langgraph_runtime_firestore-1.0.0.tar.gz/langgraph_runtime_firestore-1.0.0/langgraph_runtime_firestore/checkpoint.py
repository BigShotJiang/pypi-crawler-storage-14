"""Firestore-based checkpoint implementation for LangGraph."""

from __future__ import annotations

import logging
import os
import typing

from langgraph.checkpoint.base import (
    Checkpoint,
    CheckpointMetadata,
    CheckpointTuple,
)
from langgraph_runtime_inmem.checkpoint import InMemorySaver

if typing.TYPE_CHECKING:
    from langchain_core.runnables import RunnableConfig
    from langgraph.checkpoint.base import SerializerProtocol

logger = logging.getLogger(__name__)

_EXCLUDED_KEYS = {"checkpoint_ns", "checkpoint_id", "run_id", "thread_id"}


class FirestoreCheckpointer(InMemorySaver):
    """Firestore-backed checkpointer that extends InMemorySaver.

    For now, this uses InMemorySaver as a base and persists to Firestore
    on put operations. Full async Firestore support can be added in future.
    """

    def __init__(
        self,
        *,
        serde: SerializerProtocol | None = None,
    ) -> None:
        super().__init__(serde=serde)
        self.firestore_db = None

    def put(
        self,
        config: RunnableConfig,
        checkpoint: Checkpoint,
        metadata: CheckpointMetadata,
        new_versions: dict[str, str | int | float],
    ) -> RunnableConfig:
        """Put checkpoint and persist to Firestore."""
        # Call parent implementation for in-memory storage
        result = super().put(config, checkpoint, metadata, new_versions)

        # TODO: Persist to Firestore asynchronously
        # This will be called from async context via run_in_executor
        # self._persist_to_firestore(config, checkpoint, metadata)

        return result

    def get_tuple(self, config: RunnableConfig) -> CheckpointTuple | None:
        """Get checkpoint tuple, potentially from Firestore."""
        # For now, use in-memory storage
        return super().get_tuple(config)


MEMORY = None


def Checkpointer(*args, unpack_hook=None, **kwargs):
    """Get or create a Firestore checkpointer instance."""
    global MEMORY
    if MEMORY is None:
        MEMORY = FirestoreCheckpointer()
    if unpack_hook is not None:
        from langgraph_api.serde import Serializer

        saver = FirestoreCheckpointer(
            serde=Serializer(__unpack_ext_hook__=unpack_hook), **kwargs
        )
        saver.writes = MEMORY.writes
        saver.blobs = MEMORY.blobs
        saver.storage = MEMORY.storage
        return saver
    return MEMORY


__all__ = ["Checkpointer"]
