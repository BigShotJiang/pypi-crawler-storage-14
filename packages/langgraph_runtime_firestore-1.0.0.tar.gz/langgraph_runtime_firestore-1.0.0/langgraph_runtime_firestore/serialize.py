from datetime import datetime
from typing import Any
from uuid import UUID




def serialize_for_firestore(obj: Any) -> Any:
    """Convert UUID and datetime objects to Firestore-compatible types (strings)."""
    if isinstance(obj, UUID):
        return str(obj)
    elif isinstance(obj, datetime):
        return obj.isoformat()
    elif isinstance(obj, dict):
        return {k: serialize_for_firestore(v) for k, v in obj.items()}
    elif isinstance(obj, (list, tuple)):
        return [serialize_for_firestore(item) for item in obj]
    return obj


def deserialize_from_firestore(obj: Any) -> Any:
    """Convert strings back to UUID and datetime objects."""
    if isinstance(obj, str):
        # Try to parse as UUID
        try:
            return UUID(obj)
        except (ValueError, AttributeError):
            pass
        # Try to parse as datetime
        try:
            return datetime.fromisoformat(obj)
        except (ValueError, TypeError):
            pass
    elif isinstance(obj, dict):
        return {k: deserialize_from_firestore(v) for k, v in obj.items()}
    elif isinstance(obj, list):
        return [deserialize_from_firestore(item) for item in obj]
    return obj