"""LangGraph Runtime - Auto-detects Firestore vs In-Memory based on configuration."""

import os

# Auto-detect which runtime to use based on environment variables
if os.getenv("FIRESTORE_CREDENTIALS_PATH"):
    # Use Firestore runtime
    from langgraph_runtime_firestore import (
        checkpoint,
        database,
        lifespan,
        metrics,
        ops,
        queue,
        retry,
        store,
    )
    from langgraph_runtime_firestore import __version__
else:
    # Use In-Memory runtime (default)
    from langgraph_runtime_inmem import (
        checkpoint,
        database,
        lifespan,
        metrics,
        ops,
        queue,
        retry,
        store,
    )
    from langgraph_runtime_inmem import __version__

__all__ = [
    "ops",
    "database",
    "checkpoint",
    "lifespan",
    "retry",
    "store",
    "queue",
    "metrics",
    "__version__",
]
