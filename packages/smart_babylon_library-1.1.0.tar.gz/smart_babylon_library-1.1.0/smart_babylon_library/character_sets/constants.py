# --------------------------------------------------------
# Licensed under the terms of the BSD 3-Clause License
# (see LICENSE for details).
# Copyright © 2025, Alexander Suvorov
# --------------------------------------------------------
# https://github.com/smartlegionlab
# --------------------------------------------------------
CYRILLIC_UPPERCASE = 'АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯ '
CYRILLIC_LOWERCASE = 'абвгдеёжзийклмнопрстуфхцчшщъыьэюя '

LATIN_UPPERCASE = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ '
LATIN_LOWERCASE = 'abcdefghijklmnopqrstuvwxyz '

DIGITS = '0123456789'

PUNCTUATION_MARKS = '.,!?;:"-–—()[]{}«»„“”‘’…/\\@#$%^&*+=|~` '
