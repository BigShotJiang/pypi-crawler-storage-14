from domino._impl.custommetrics.paths.api_metric_alerts_v1.post import ApiForpost


class ApiMetricAlertsV1(
    ApiForpost,
):
    pass
