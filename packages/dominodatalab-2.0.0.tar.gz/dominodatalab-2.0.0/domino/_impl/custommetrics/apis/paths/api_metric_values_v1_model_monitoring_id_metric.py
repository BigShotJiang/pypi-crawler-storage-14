from domino._impl.custommetrics.paths.api_metric_values_v1_model_monitoring_id_metric.get import ApiForget


class ApiMetricValuesV1ModelMonitoringIdMetric(
    ApiForget,
):
    pass
