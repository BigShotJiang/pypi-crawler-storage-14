from edri.dataclass.event import Event, event


@event
class Test(Event):
    pass
