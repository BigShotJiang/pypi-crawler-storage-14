"""Cell classes for streamlit-notebook.

This module provides the cell abstraction for streamlit-notebook,
including base :class:`Cell` class and specialized subclasses for
different content types.

Cell Types:
    - :class:`CodeCell`: Python code execution with output capture
    - :class:`MarkdownCell`: Formatted text with variable interpolation
    - :class:`HTMLCell`: Raw HTML rendering with variable interpolation

Cells support:
    - Selective reactivity (auto-rerun on changes)
    - Fragment execution (Streamlit fragments for performance)
    - One-shot execution (run once, then skip)
    - Output capture (stdout, stderr, results, exceptions)

Examples:
    Cells are typically created via notebook decorators::

        @nb.cell(type='code')
        def analyze():
            import pandas as pd
            df = pd.DataFrame({'x': [1, 2, 3]})
            st.dataframe(df)

        @nb.cell(type='markdown')
        def explanation():
            '''
            # Results
            The data has <<len(df)>> rows.
            '''

See Also:
    :class:`~streamlit_notebook.notebook.Notebook`: Notebook orchestrator
    :class:`~streamlit_notebook.cell_ui.CellUI`: Cell UI components
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any, Optional, Literal
import streamlit as st
from streamlit.errors import DuplicateWidgetID, StreamlitDuplicateElementKey
from .utils import format, short_id, rerun
from .cell_ui import CellUI, Code

if TYPE_CHECKING:
    from .notebook import Notebook

state = st.session_state

def display(obj: Any) -> None:
    """Display an object using Streamlit's rendering system.

    Attempts to display the object using ``st.write``, falling back to
    ``st.text(repr(obj))`` if that fails. Used internally for displaying
    cell execution results.

    Args:
        obj: The object to display. If None, nothing is displayed.

    Note:
        This is the default display hook for cells. Custom display behavior
        can be implemented via the notebook's display_hook.

    Examples:
        Typical usage in shell execution::

            result = 42
            display(result)  # Shows "42" in the UI

    See Also:
        :meth:`~streamlit_notebook.notebook.Notebook.display_hook`: Custom display
    """
    if obj is not None:
        try: 
            st.write(obj)
        except:
            st.text(repr(obj))

class CellType:

    def __init__(self,cell):
        self.cell:Cell=cell
        self.has_fragment_toggle=True
        self.has_reactive_toggle=True
        self.language='python'

    def is_reactive(self):
        return self.cell._reactive
    
    def is_fragment(self):
        return self.cell._fragment

    def exec(self):
        """
        Executes the code returned by self.get_exec_code()
        """
        with self.cell:
            response=self.cell.notebook.shell.run(self.cell.get_exec_code(),filename=f"<{self.cell.id}>")
        self.cell.set_output(response)  


    def get_exec_code(self):
        return self.cell.code
    
class PyType(CellType):

    def __init__(self,cell):
        super().__init__(cell)
        self.language='python'

    def get_exec_code(self):
        return self.cell.code
    
    def exec(self):
        """
        Executes the cell code.

        This method chooses between normal execution and fragment execution
        based on the cell's fragment attribute.
        """
        if self.cell.fragment:
            self._exec_as_fragment()
        else:
            self._exec_normally()


    @st.fragment
    def _exec_as_fragment(self):
        """
        Executes the cell as a Streamlit fragment.

        This method is decorated with @st.fragment and executes
        the cell's code within a Streamlit fragment context.
        """
        with self.cell:
            response=self.cell.notebook.shell.run(self.cell.get_exec_code(),filename=f"<{self.cell.id}>")
        self.cell.set_output(response) 

    def _exec_normally(self):
        """
        Executes the cell normally.

        This method runs the cell's code in the normal execution context.
        """
        with self.cell:
            response=self.cell.notebook.shell.run(self.cell.get_exec_code(),filename=f"<{self.cell.id}>")
        self.cell.set_output(response) 

class MDType(CellType):
    
    def __init__(self,cell):
        super().__init__(cell)
        self.language='markdown'
        self.has_fragment_toggle=False
        self.has_reactive_toggle=False

    def is_reactive(self):
        return True
    
    def is_fragment(self):
        return False
    
    def get_exec_code(self):
        """
        Formats the Markdown code and converts it to a st.markdown call.

        Returns:
            str: A string containing a st.markdown() call with the formatted Markdown content.

        This method processes the cell's content, formats any variables,
        and wraps it in a Streamlit markdown function call.
        """
        formatted_code=format(self.cell.code,**self.cell.notebook.shell.namespace).replace("'''","\'\'\'")
        code=f"st.markdown(r'''{formatted_code}''');"
        return code 

class HTMLType(CellType):
    
    def __init__(self,cell):
        super().__init__(cell)
        self.language='markdown'
        self.has_fragment_toggle=False
        self.has_reactive_toggle=False

    def is_reactive(self):
        return True
    
    def is_fragment(self):
        return False
    
    def get_exec_code(self):
        """
        Formats the HTML code and converts it to a st.html call.

        Returns:
            str: A string containing a st.html() call with the formatted HTML content.

        This method processes the cell's content, formats any variables,
        and wraps it in a Streamlit html function call.
        """
        formatted_code=format(self.cell.code,**self.cell.notebook.shell.namespace).replace("'''","\'\'\'")
        code=f"st.html(r'''{formatted_code}''');"
        return code 

_supported_types=dict(
    code=PyType,
    markdown=MDType,
    html=HTMLType
)

def _type_to_class(type:str)-> CellType:
    if type in _supported_types:
        return _supported_types[type]
    else:
        raise ValueError(f"Unknown cell type: {type}")

class Cell:

    """
    The base class for all types of cells in the notebook.

    This class provides the core functionality for cells, including
    code storage, execution, and UI management.

    Attributes:
        notebook (Notebook): The parent Notebook object.
        key (str): A unique identifier for the cell.
        code (str): The content of the cell (code, markdown, or HTML).
        reactive (bool): If True, the cell automatically reruns when its content changes.
        fragment (bool): If True, the cell runs as a Streamlit fragment.
        type (str): The type of the cell ("code", "markdown", or "html").
        ui (CellUI): The UI object managing the cell's interface.
        results (list): A list of results from the last execution.
        exception (Exception): Any exception raised during the last execution.

    Methods:
        show(): Renders the cell's layout and content.
        run(): Executes the cell's code.
        get_exec_code(): Returns the code to be executed.
        set_output(response): Sets the output of the cell after execution.
        show_output(): Displays the execution results (if any).
        move_up(): Moves the cell up in the notebook.
        move_down(): Moves the cell down in the notebook.
        delete(): Removes the cell from the notebook.
        to_dict(): Returns a dictionary representation of the cell.
    """
    def __init__(
        self,
        notebook: Notebook,
        key: str,
        type: str = "code",  # code, markdown, html
        code: str = "",
        reactive: bool = False,
        fragment: bool = False
    ) -> None:
        self.notebook = notebook
        self.container: Any = None
        self.output: Any = None
        self.output_area: Any = None
        self.stdout_area: Any = None
        self.stderr_area: Any = None
        self.visible = True
        self.stdout: Optional[str] = None
        self.stderr: Optional[str] = None
        self.results: list[Any] = []
        self.exception: Optional[Exception] = None
        self.ready = False
        self.has_run = False
        self._code = Code(value=code)
        self.last_code: Optional[str] = None
        self.key = key
        self.ui_key = short_id()
        self._reactive = reactive
        self._type: Optional[Literal['code', 'markdown', 'html']] = type
        self._fragment = fragment
        self.prepare_ui()

    @property
    def _type_object(self) -> CellType:
        return _type_to_class(self.type)(self)

    @property
    def language(self) -> str:
        return self._type_object.language

    @property
    def id(self) -> str:
        return f"Cell[{self.rank}]({self.key})"

    @property
    def type(self):
        return self._type

    @type.setter
    def type(self, value):
        self._set_type(value)

    @property
    def code(self) -> str:
        """
        The code written in the cell.

        Returns:
            str: The current code content of the cell.
        """
        return self._code.get_value()

    @code.setter
    def code(self, value: str) -> None:
        """
        Setter for the code property.

        Args:
            value (str): The new code content to set for the cell.
        """
        current_value = self._code.get_value()
        if current_value == value:
            return
        self._code.from_backend(value)
        self.ui_key = short_id()
        self.reset()
        rerun()

    @property
    def has_run_once(self) -> bool:
        """
        Checks if the cell has been run at least once with the current code.

        Returns:
            bool: True if the cell has been run once with the current code, False otherwise.
        """
        return self.last_code is not None and self.last_code == self.code

    @property
    def has_reactive_toggle(self):
        return self._type_object.has_reactive_toggle

    @property
    def reactive(self) -> bool:
        """Whether the cell automatically reruns on changes."""
        return self._type_object.is_reactive()

    @reactive.setter
    def reactive(self, value: bool) -> None:
        """Set the reactive state of the cell."""
        if self._reactive != value:
            self._reactive = value
            # Trigger UI update if needed
            if hasattr(self, 'ui') and hasattr(self.ui, 'buttons') and 'Reactive' in self.ui.buttons:
                self.ui.buttons['Reactive'].toggled = value
                rerun()

    @property
    def has_fragment_toggle(self):
        return self._type_object.has_fragment_toggle

    @property
    def fragment(self) -> bool:
        """Whether the cell runs as a Streamlit fragment."""
        return self._type_object.is_fragment()

    @fragment.setter
    def fragment(self, value: bool) -> None:
        """Set the fragment state of the cell."""
        if self._fragment != value:
            self._fragment = value
            # Trigger UI update if needed
            if hasattr(self, 'ui') and hasattr(self.ui, 'buttons') and 'Fragment' in self.ui.buttons:
                self.ui.buttons['Fragment'].toggled = value
                rerun()

    def __enter__(self) -> Cell:
        """
        Allows using the cell as a context manager.

        This method enables running code in the shell and directing its outputs to the cell
        by switching the notebook.current_cell property.

        Returns:
            Cell: The current cell instance.

        Example:
            with cell:
                notebook.shell.run(code)  # all shell outputs will be directed to the cell
        """
        self.saved_cell = self.notebook.current_cell
        self.notebook.current_cell = self
        return self

    def __exit__(self, exc_type: Any, exc_value: Any, exc_tb: Any) -> None:
        """
        Restores the notebook.current_cell property to its initial value.

        Args:
            exc_type: The type of the exception that was raised, if any.
            exc_value: The exception instance that was raised, if any.
            exc_tb: The traceback object encapsulating the call stack at the point where the exception occurred.
        """
        self.notebook.current_cell = self.saved_cell


    def prepare_ui(self):
        """
        Initializes the CellUI object and sets up the cell's user interface components.
        """
        self.ui=CellUI(code=self._code,lang=self.language,key=f"cell_ui_{self.ui_key}",response_mode="blur")
        self.ui.submit_callback=self.submit_callback
        self.ui.buttons["Reactive"].callback=self._toggle_reactive
        self.ui.buttons["Reactive"].toggled=self.reactive
        self.ui.buttons["Fragment"].callback=self._toggle_fragment
        self.ui.buttons["Fragment"].toggled=self.fragment
        self.ui.buttons["Up"].callback=self.move_up
        self.ui.buttons["Down"].callback=self.move_down
        self.ui.buttons["Close"].callback=self.delete
        self.ui.buttons["Run"].callback=self.run_callback
        self.ui.buttons["InsertAbove"].callback=self.insert_above
        self.ui.buttons["InsertBelow"].callback=self.insert_below
        self.ui.buttons["TypeCode"].callback=lambda: self._set_type("code")
        self.ui.buttons["TypeMarkdown"].callback=lambda: self._set_type("markdown")
        self.ui.buttons["TypeHTML"].callback=lambda: self._set_type("html")
        

    def update_ui(self):
        """
        Updates the cell's UI components based on the current cell state.
        """
        self.ui.lang=self.language
        self.ui.key=f"cell_ui_{self.ui_key}"
        self.ui.buttons['Fragment'].visible=self.has_fragment_toggle
        self.ui.buttons['Reactive'].visible=self.has_reactive_toggle

        self.ui.info_bar.set_info(dict(name=f"{self.id}:",style=dict(fontSize="14px",width="100%")))

        # Update type buttons to highlight current type with bold font
        for type_name, button_name in [("code", "TypeCode"), ("markdown", "TypeMarkdown"), ("html", "TypeHTML")]:
            if self.type == type_name:
                self.ui.buttons[button_name].style.update(fontWeight = 'bold',opacity='1')
            else:
                self.ui.buttons[button_name].style.update(fontWeight = 'normal',opacity='0.5')

    def initialize_output_area(self):
        """
        Prepares or clears the various containers used to display cell outputs.
        """
        self.output=self.output_area.container()
        with self.output:
            self.stdout_area=st.empty()
            self.stderr_area=st.empty()
        
    def prepare_skeleton(self):
        """
        Prepares the various containers used to display the cell UI and its outputs.
        """
        self.container=st.container()
        self.output_area=st.empty()
        self.initialize_output_area()
        self.ready=True # flag used by self.run() and shell hooks to signal that the cell has prepared the adequate containers to receive outputs

    def show(self):
        """
        Renders the cell's layout.

        This method is responsible for displaying the cell's UI components
        and managing its visibility based on notebook settings.
        """
        self.prepare_skeleton()

        if not self.notebook.app_mode and self.visible:
            with self.container.container():
                self.update_ui()
                self.ui.show()
                
        # Rerun only if the cell has been run at least once with the current code
        # This prevents premature execution when toggling "reactive" on a cell that hasn't run yet
        if self.reactive and self.has_run_once:
            self.run()

        self.show_output()
        
    def submit_callback(self):
        """
        Callback used to deal with the "submit" event from the UI.

        Runs the cell only if notebook.run_on_submit is true.
        """
        if self.notebook.run_on_submit:
            self.has_run=False
            self.run()
            self.notebook.notify(f"Executed `{self.id}`", icon="▶️")

    def run_callback(self):
        """
        Callback used to deal with the "run" event from the ui.

        Resets run_state to None and runs the cell.
        """
        self.has_run=False
        self.run()
        self.notebook.notify(f"Executed `{self.id}`", icon="▶️")

    def run(self):
        """
        Runs the cell's code.

        This method executes the cell's content, captures the output,
        and updates the cell's state accordingly.
        """
        if not self.has_run and self.code:
            self.last_code=self.code
            self.results=[]
            self.has_run=True
            if self.ready:
                # The cell skeleton is on screen and can receive outputs
                self.initialize_output_area()
                with self.output:
                    self.exec()
            else:
                # The cell skeleton isn't on screen yet
                # The code runs anyway, but the outputs will be shown after a refresh
                self.exec()
                rerun()   

    def set_output(self,response):
        """
        Assigns relevant fields of the shell response to the cell.

        Args:
            response (ShellResponse): The response object from code execution.

        This method updates the cell's stdout, stderr, and exception attributes.
        """
        self.stdout=response.stdout
        self.stderr=response.stderr
        self.exception=response.exception

    def show_output(self):
        """
        Displays the previous execution results.

        This method is called when a cell hasn't run in the current Streamlit run,
        displaying previous results without re-executing the code.
        """
        self.initialize_output_area()
        if self.stdout and self.notebook.show_stdout:
            with self.stdout_area:
                st.code(self.stdout,language="text")
        if self.stderr and self.notebook.show_stderr:
            with self.stderr_area:
                st.code(self.stderr,language="text")
        if self.results:
            with self.output:
                for result in self.results:
                    display(result)
        if self.exception:
            with self.output:
                formatted_traceback=f"**{type(self.exception).__name__}**: {str(self.exception)}\n```\n{self.exception.enriched_traceback_string}\n```"
                st.error(formatted_traceback)

    @property
    def rank(self):
        """
        Gets the current rank of the cell in the cells list.

        Returns:
            int: The index of the cell in the notebook's cell list.
        """
        return self.notebook.cells.index(self)
    
    def rerank(self,rank):
        """
        Moves the cell to a new rank.

        Args:
            rank (int): The new rank (position) for the cell in the notebook.
        """
        if 0<=rank<len(self.notebook.cells) and not rank==self.rank:
            # Remove from current position
            self.notebook.cells.remove(self)
            # Insert at new position
            self.notebook.cells.insert(rank, self)
            self.notebook.notify(f"Moved {self.id} to position {rank}", icon="↕️")
            rerun()

    def move_up(self):
        """
        Moves the cell up in the notebook.

        This method changes the cell's position, moving it one place earlier in the execution order.
        """
        self.rerank(self.rank-1)
        

    def move_down(self):
        """
        Moves the cell down in the notebook.

        This method changes the cell's position, moving it one place later in the execution order.
        """
        self.rerank(self.rank+1)


    def _toggle_reactive(self):
        """Toggles the 'Auto-Rerun' feature for the cell (internal)."""
        self._reactive = self.ui.buttons["Reactive"].toggled

    def _toggle_fragment(self):
        """Toggles the 'Fragment' feature for the cell (internal)."""
        self._fragment = self.ui.buttons["Fragment"].toggled

    def _set_type(self, new_type):
        """
        Changes the type of the cell (code, markdown, or html).

        Args:
            new_type (str): The new type for the cell ("code", "markdown", or "html")
        """
        if new_type == self.type:
            return  # Already this type, nothing to do
        
        if new_type in ("code","markdown", "html"):
            self._type = new_type
        else:
            raise ValueError(f"Invalid cell type: {new_type}. Must be 'code', 'markdown', or 'html'")

        self.notebook.notify(f"Changed cell {self.key} to {new_type}", icon="🔄")
        rerun()

    def insert_above(self):
        """
        Inserts a new cell above this cell in the notebook.
        """
        new_key = self.notebook.gen_cell_key()
        cell = new_cell(self.notebook, new_key, type=self.type, code="", reactive=False, fragment=False)
        # Insert at current position (pushing this cell down)
        self.notebook.cells.insert(self.rank, cell)
        self.notebook.notify(f"Created cell {new_key} above", icon="➕")
        rerun()

    def insert_below(self):
        """
        Inserts a new cell below this cell in the notebook.
        """
        new_key = self.notebook.gen_cell_key()
        cell = new_cell(self.notebook, new_key, type=self.type, code="", reactive=False, fragment=False)
        # Insert after current position
        self.notebook.cells.insert(self.rank + 1, cell)
        self.notebook.notify(f"Created cell {new_key} below", icon="➕")
        rerun()

    def delete(self):
        """
        Deletes the cell from the notebook.
        """
        if self in self.notebook.cells:
            self.notebook.cells.remove(self)
            self.notebook.notify(f"Deleted cell {self.key}", icon="🗑️")
            rerun()

    def reset(self):
        self.initialize_output_area()
        self.has_run=False
        self.last_code=None
        self.results=[]
        self.stdout=None
        self.stderr=None
        self.exception=None
    
    def to_dict(self):
        """
        Returns a minimal dict representation of the cell.

        Returns:
            dict: A dictionary containing the essential attributes of the cell.

        This method is used for serialization of the cell, containing only
        what is necessary to recreate it.
        """
        d=dict(
            key=self.key,
            type=self.type,
            code=self.code,
            reactive=self.reactive,
            fragment=self.fragment
        )
        return d
    
    # type dependent methods 

    def exec(self):
        return self._type_object.exec()


    def get_exec_code(self):
        """
        Get the code to execute.

        Returns:
            str: The code to be executed.

        Note:
            This method is overridden in subclasses to provide
            type-specific code preparation.
        """
        return self._type_object.get_exec_code()  
          


def new_cell(notebook,key,type="code",code="",reactive=False,fragment=False):
    """
    Returns a new cell, given a notebook object, a key, and optional kwargs.

    This function is used in the notebook.new_cell method to create cells of different types.

    Args:
        notebook (Notebook): The parent Notebook object.
        key: Unique identifier for the cell.
        type (str): The type of cell to create ("code", "markdown", or "html").
        code (str): Initial code or content for the cell.
        reactive (bool): Whether the cell should automatically re-run when UI refreshes.
        fragment (bool): Whether the cell should run as a Streamlit fragment.

    Returns:
        Cell: A new Cell object of the specified type.

    Raises:
        NotImplementedError: If an unsupported cell type is specified.
    """
    if not type in ("code","markdown","html"):
        raise NotImplementedError(f"Cell type {type} not implemented")
    return Cell(notebook,key,type=type,code=code,reactive=reactive,fragment=fragment)