from .compress import CompressAPI
