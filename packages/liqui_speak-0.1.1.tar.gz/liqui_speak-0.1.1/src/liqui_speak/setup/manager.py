"""Automated setup manager for Liqui-Speak."""

import importlib
import importlib.util
import logging
import subprocess
import sys
from pathlib import Path

from liqui_speak.models.downloader import ModelDownloader
from liqui_speak.platform.detector import PlatformDetector


class SetupManager:
    """Handles automatic installation of system dependencies and models."""

    def __init__(self):
        self.platform = PlatformDetector()
        self.model_downloader = ModelDownloader()
        self.setup_dir = Path.home() / ".liqui_speak"
        self.setup_dir.mkdir(exist_ok=True)
        self.logger = logging.getLogger("liqui_speak")

    def run_full_setup(self, verbose: bool = True) -> bool:
        """
        Run complete setup process.

        Args:
            verbose: Show detailed progress

        Returns:
            True if setup successful
        """
        if verbose:
            self.logger.info("Starting Liqui-Speak setup...")

        try:

            if verbose:
                self.logger.info("Installing system dependencies...")
            self._install_system_dependencies()


            if verbose:
                self.logger.info("Setting up Python environment...")
            self._setup_python_environment()


            if verbose:
                self.logger.info("Downloading models...")
            self._download_models()


            if verbose:
                self.logger.info("Verifying installation...")
            self._verify_installation()

            if verbose:
                self.logger.info("Setup complete! You can now use: liqui-speak your_audio.m4a")

            return True

        except Exception as e:

            self.logger.error(f"Setup failed: {e}")
            if not verbose:
                self.logger.info("Try running with --verbose for more details")
            return False

    def _install_system_dependencies(self) -> None:
        """Install PortAudio and FFmpeg system dependencies."""
        system = self.platform.system

        if system == "Darwin":
            self._install_macos_dependencies()
        elif system == "Linux":
            self._install_linux_dependencies()
        elif system == "Windows":
            self._install_windows_dependencies()
        else:
            raise RuntimeError(f"Unsupported platform: {system}")

    def _install_macos_dependencies(self) -> None:
        """Install dependencies on macOS."""
        if not self._command_exists("brew"):
            raise RuntimeError("Homebrew not found. Please install from https://brew.sh")

        packages = ["portaudio", "ffmpeg"]
        for package in packages:
            self.logger.info(f"Installing {package}...")
            subprocess.run(["brew", "install", package], check=True)

    def _confirm_sudo_action(self, action_description: str) -> bool:
        """Ask user for confirmation before running sudo commands."""
        self.logger.warning(f"This will run sudo commands to {action_description}")
        response = input("Continue? [y/N]: ").strip().lower()
        return response in ('y', 'yes')

    def _install_linux_dependencies(self) -> None:
        """Install dependencies on Linux."""
        if not self._confirm_sudo_action("install portaudio and ffmpeg"):
            raise RuntimeError("User cancelled installation")


        if self._command_exists("apt-get"):
            packages = ["portaudio19-dev", "ffmpeg"]
            subprocess.run(["sudo", "apt-get", "update"], check=False)
            subprocess.run(["sudo", "apt-get", "install", "-y"] + packages, check=True)

        elif self._command_exists("yum"):
            packages = ["portaudio-devel", "ffmpeg"]
            subprocess.run(["sudo", "yum", "install", "-y"] + packages, check=True)

        elif self._command_exists("pacman"):
            packages = ["portaudio", "ffmpeg"]
            subprocess.run(["sudo", "pacman", "-S", "--noconfirm"] + packages, check=True)
        else:
            raise RuntimeError("No supported package manager found (apt/yum/pacman)")

    def _install_windows_dependencies(self) -> None:
        """Install dependencies on Windows."""
        if self._command_exists("choco"):
            packages = ["portaudio", "ffmpeg"]
            for package in packages:
                subprocess.run(["choco", "install", package, "-y"], check=True)
        elif self._command_exists("scoop"):
            subprocess.run(["scoop", "install", "portaudio", "ffmpeg"], check=True)
        else:
            raise RuntimeError(
                "Chocolatey or Scoop not found. "
                "Please install Chocolatey from https://chocolatey.org"
            )

    def _setup_python_environment(self) -> None:
        """Verify Python version and install PyDub/python-magic if needed."""

        self.logger.info(f"Python {sys.version.split()[0]} detected")


        if importlib.util.find_spec("pydub") is not None:
            self.logger.info("PyDub already installed")
        else:
            self.logger.info("Installing PyDub...")
            subprocess.run([sys.executable, "-m", "pip", "install", "pydub"], check=True)


        self._install_python_magic()

    def _install_python_magic(self) -> None:
        """Install python-magic with platform-specific handling."""

        if importlib.util.find_spec("magic") is not None:
            self.logger.info("python-magic already installed")
            return

        system = self.platform.system

        if system == "Windows":

            self.logger.info("Installing python-magic-bin for Windows...")
            subprocess.run([sys.executable, "-m", "pip", "install", "python-magic-bin"], check=True)
        else:

            self.logger.info("Installing python-magic...")
            subprocess.run([sys.executable, "-m", "pip", "install", "python-magic"], check=True)


        try:
            importlib.util.find_spec("magic")
            self.logger.info("python-magic installation verified")
        except ImportError as e:
            if system == "Windows":
                raise RuntimeError(
                    "python-magic installation failed. Try manually installing "
                    "python-magic-bin: pip install python-magic-bin"
                ) from e
            else:
                raise RuntimeError(
                    f"python-magic installation failed. Ensure libmagic is installed: {e}"
                ) from e

    def _download_models(self) -> None:
        """Download LFM2-Audio model and binaries."""
        model_dir = self.setup_dir / "models"
        model_dir.mkdir(exist_ok=True)


        model_files = [
            "LFM2-Audio-1.5B-Q8_0.gguf",
            "mmproj-audioencoder-LFM2-Audio-1.5B-Q8_0.gguf",
            "audiodecoder-LFM2-Audio-1.5B-Q8_0.gguf"
        ]


        all_models_exist = all((model_dir / filename).exists() for filename in model_files)

        if all_models_exist:
            self.logger.info("Model files already downloaded")
        else:
            self.logger.info("Downloading LFM2-Audio-1.5B model files...")

            self.model_downloader.download_all_models(model_dir)


        from liqui_speak.platform.detector import PlatformDetector
        detector = PlatformDetector()
        platform = detector.get_supported_platform()

        if platform:
            binary_path = model_dir / "runners" / platform / "bin" / "llama-lfm2-audio"
            if binary_path.exists():
                self.logger.info(f"Binary already downloaded for {platform}")
            else:
                self.logger.info(f"Downloading {platform} binary...")
                binary_result = self.model_downloader.download_binary(model_dir, platform)
                if binary_result:
                    self.logger.info(f"Binary downloaded: {binary_result}")
        else:
            self.logger.warning(f"Platform {detector.system}-{detector.machine} not supported for binaries")

    def _verify_installation(self) -> None:
        """Verify that everything is working correctly."""

        deps = {
            "ffmpeg": self._command_exists("ffmpeg"),
            "pydub": self._check_python_module("pydub"),
            "python-magic": self._check_python_module("magic"),
        }

        missing = [name for name, installed in deps.items() if not installed]
        if missing:
            raise RuntimeError(f"Missing dependencies: {', '.join(missing)}")


        model_files = [
            "LFM2-Audio-1.5B-Q8_0.gguf",
            "mmproj-audioencoder-LFM2-Audio-1.5B-Q8_0.gguf",
            "audiodecoder-LFM2-Audio-1.5B-Q8_0.gguf"
        ]

        for filename in model_files:
            filepath = self.setup_dir / "models" / filename
            if not filepath.exists():
                raise RuntimeError(f"Missing model file: {filename}")

        self.logger.info("All dependencies verified")

    def _command_exists(self, command: str) -> bool:
        """Check if a system command exists."""
        try:

            if command == "ffmpeg":
                subprocess.run([command, "-version"],
                             capture_output=True, check=True)
            else:
                subprocess.run([command, "--version"],
                             capture_output=True, check=True)
            return True
        except (subprocess.CalledProcessError, FileNotFoundError):
            return False

    def _check_python_module(self, module: str) -> bool:
        """Check if a Python module is installed."""
        try:
            __import__(module)
            return True
        except ImportError:
            return False


