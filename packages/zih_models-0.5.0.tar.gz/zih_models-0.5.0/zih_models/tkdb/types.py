from datetime import timezone
from enum import StrEnum
from typing import Annotated

from pydantic import AfterValidator, AwareDatetime


def to_utc(dt: AwareDatetime) -> AwareDatetime:
    return dt.astimezone(timezone.utc)


DatetimeUTC = Annotated[AwareDatetime, AfterValidator(to_utc)]


class PhoneNumberType(StrEnum):
    """all possible types for a phone number"""

    PERSONAL = "personal"
    FUNCTIONAL = "functional"
    EXTERNAL = "external"
    BLOCKED = "blocked"
    LEGACY = "legacy"
