Installation
============

You can install Flask-PASET-Extended with pip:

.. code-block:: console

    $ pip install flask-paseto-extended
