API Reference
=============

.. automodule:: flask_paseto_extended
   :members:
   :undoc-members:
   :show-inheritance:
   :member-order: bysource
