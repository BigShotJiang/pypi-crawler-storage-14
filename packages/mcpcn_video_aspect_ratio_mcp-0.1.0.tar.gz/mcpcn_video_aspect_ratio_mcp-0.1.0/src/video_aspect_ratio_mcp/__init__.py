"""
Video Aspect Ratio MCP Server

A MCP server for adjusting video aspect ratio with padding or cropping.
"""

__version__ = "0.1.0"

from .main import main

__all__ = ["main"]
