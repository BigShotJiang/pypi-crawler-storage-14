import sqlite3
from pathlib import Path
import tempfile
from datetime import date


class Cache:
    def __init__(self) -> None:
        self.connection = sqlite3.connect(Path(tempfile.gettempdir(), f'{date.today().isoformat()}.db'))
        self.cursor = self.connection.cursor()

        self.cursor.execute("""
            CREATE TABLE IF NOT EXISTS cache (
                ts DATETIME DEFAULT CURRENT_TIMESTAMP,
                key TEXT PRIMARY KEY NOT NULL,
                value BLOB
            )
        """)

        self.cursor.execute('PRAGMA journal_mode=WAL;')

    def __del__(self) -> None:
        self.connection.commit()
        self.connection.close()