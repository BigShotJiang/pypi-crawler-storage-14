from .cls import Cache
from .func import _get, _put
from typing import Any

db = None


def cache(func) -> Any:
    global db

    if not db:
        db = Cache()

    def wrapper(*args, **kwargs):
        key, *_ = args

        if not isinstance(key, str):
            raise TypeError(f'First arg is not str type.')

        value = _get(db, key)

        if value is not None:
            return value

        value = func(*args, **kwargs)

        if value:
            _put(db, key, value)

        return value

    return wrapper
