from .dec import cache

__all__ = ['cache']
