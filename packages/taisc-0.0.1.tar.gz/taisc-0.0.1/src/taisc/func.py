import pickle
from .cls import Cache
from typing import Any


def _put(cache: Cache, key: str, value: Any) -> None:
    value = pickle.dumps(value)

    cache.cursor.execute("""
        INSERT INTO cache (key, value) VALUES (?, ?) 
        ON CONFLICT(key) DO UPDATE SET value = excluded.value, ts = CURRENT_TIMESTAMP;
    """, (key, value))


def _get(cache: Cache, key: str) -> Any:
    cache.cursor.execute("""
        SELECT value FROM cache WHERE key = (?);
    """, (key,))

    row = cache.cursor.fetchone()

    return None if not row else pickle.loads(*row)
