# Taisc

Simple persistent caching mechanism

## INSTALLING

How to install Taisc.

```bash
pip install taisc
```

## USING

How to use Taisc to fetch and store cache data.
If data is stored in the cache, then the decorated function is not run.

```python
from src.taisc import cache

@cache
def foo(key: str):
    return key * 2
```

## WARNING

Taisc pickles and unpickles values in order to store as BLOB in the sqlite3 database.

The [pickle module](https://docs.python.org/3/library/pickle.html) states: 

<div style="border: 2px solid red; padding: 15px; border-radius: 8px; background-color: #ffe4e4;">
<p style="color: black"><strong>Warning:</strong> The pickle module <strong>is not secure</strong>. Only unpickle data you trust.</p>
<p style="color: black">It is possible to construct malicious pickle data which will <strong>execute arbitrary code during unpickling</strong>. Never unpickle data that could have come from an untrusted source, or that could have been tampered with.</p>
</div>

