__version__ = "1.1.20251129.2"

import logging

logging.getLogger(__package__).setLevel(logging.DEBUG)
