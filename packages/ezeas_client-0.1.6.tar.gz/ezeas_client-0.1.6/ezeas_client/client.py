import time
import json
import hmac
import hashlib
import base64
from typing import Any, Dict, List, Optional, TypedDict, Union

import httpx


class ContactInput(TypedDict):
    external_id: str
    employee_number: str
    first_name: str
    last_name: str
    mobile: str
    email: str
    tenure_date: str


class TimesheetEntry(TypedDict):
    date: str
    hours_ordinary: float
    hours_time_and_half: float
    hours_double_time: float


class TimesheetInput(TypedDict):
    job_code: str
    timesheet_entries: List[TimesheetEntry]


class EzeasClient:
    """
    Minimal async client for Ezeas Client API using HS256 JWT.

    For production, base_url defaults to https://www.ezeas.com.
    For development, override base_url with http://localhost:8000.
    Account is resolved on the server from client_id.
    """

    def __init__(
        self,
        client_id: str,
        client_secret: str,
        _base_url: Optional[str] = None,
    ):
        self.client_id = client_id
        self.client_secret = client_secret
        self.base_url = (_base_url or "https://www.ezeas.com").rstrip("/")
        self._cached_token: Optional[str] = None
        self._cached_expiry: int = 0
        self._client: Optional[httpx.AsyncClient] = None

    async def __aenter__(self) -> "EzeasClient":
        self._client = httpx.AsyncClient(base_url=self.base_url, timeout=30.0)
        return self

    async def __aexit__(self, exc_type, exc, tb) -> None:
        if self._client is not None:
            await self._client.aclose()
            self._client = None

    # -------------------------------------------------------------
    # Internal: JWT helpers
    # -------------------------------------------------------------
    def _b64(self, data: bytes) -> str:
        return base64.urlsafe_b64encode(data).rstrip(b"=").decode("ascii")

    def _sign_hs256(self, message: bytes) -> str:
        signature = hmac.new(
            key=self.client_secret.encode("utf-8"),
            msg=message,
            digestmod=hashlib.sha256,
        ).digest()
        return self._b64(signature)

    def _generate_token(self) -> str:
        now = int(time.time())
        exp = now + 900  # 15 minutes

        header = {"alg": "HS256", "typ": "JWT"}
        payload = {
            "sub": self.client_id,
            "client_id": self.client_id,
            "iat": now,
            "exp": exp,
        }

        header_b64 = self._b64(json.dumps(header).encode("utf-8"))
        payload_b64 = self._b64(json.dumps(payload).encode("utf-8"))
        message = f"{header_b64}.{payload_b64}".encode("utf-8")

        signature = self._sign_hs256(message)
        token = f"{header_b64}.{payload_b64}.{signature}"

        self._cached_token = token
        self._cached_expiry = exp
        return token

    def _get_token(self) -> str:
        now = int(time.time())
        if self._cached_token and now < self._cached_expiry - 60:
            return self._cached_token
        return self._generate_token()

    # -------------------------------------------------------------
    # Internal: HTTP request
    # -------------------------------------------------------------
    async def _request(
        self,
        method: str,
        path: str,
        json_body: Optional[Any] = None,
    ) -> Any:
        if self._client is None:
            self._client = httpx.AsyncClient(
                base_url=self.base_url,
                timeout=30.0,
            )

        token = self._get_token()
        headers = {
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/json",
        }

        response = await self._client.request(
            method=method,
            url=path,
            headers=headers,
            json=json_body,
        )

        status = response.status_code

        if 200 <= status < 300:
            text = response.text.strip()
            return response.json() if text else None

        if 400 <= status < 500:
            try:
                detail = response.json()
            except Exception:
                detail = response.text
            raise Exception(f"{detail}")

        raise Exception(f"Internal server error {status}: {response.text}")

    # -------------------------------------------------------------
    # Public: API methods
    # -------------------------------------------------------------
    async def create_contact(
        self,
        data: Union[ContactInput, Dict[str, Any]],
    ) -> Any:
        """
        Create a contact for the account associated with this client_id.
        Expected shape follows ContactInput, but plain dict is accepted.
        """
        path = "/api/client/v1/contact"
        return await self._request("POST", path, json_body=data)

    async def create_timesheet(
        self,
        data: Union[TimesheetInput, Dict[str, Any]],
    ) -> Any:
        """
        Create a timesheet for the account associated with this client_id.
        Expected shape follows TimesheetInput, but plain dict is accepted.
        """
        path = "/api/client/v1/timesheet"
        return await self._request("POST", path, json_body=data)
