"""
Test suite for nitro-validator.
"""
