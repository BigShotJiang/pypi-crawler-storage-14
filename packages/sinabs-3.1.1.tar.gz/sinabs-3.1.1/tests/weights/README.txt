This file is solely to maintain this folder in git
--------------------------------------------------


This folder is used by tests to store and load weights 
