**HOW TOS**
=============

.. toctree::
   :maxdepth: 1

   synops_loss_ann
   synops_loss_snn
   custom_hooks
   activations
