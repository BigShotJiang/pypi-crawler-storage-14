# About this project

This project was brought to life by Sadique Sheik at SynSense, and over the years has received numerous contributions from Gregor Lenz, Felix Bauer, Nogay Küpelioğlu, Martino Sorbaro, Qian Liu and others. The logo has been designed by Dylan Muir. 