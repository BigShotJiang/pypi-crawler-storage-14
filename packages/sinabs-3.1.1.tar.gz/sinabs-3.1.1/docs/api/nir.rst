nir
===

This submodule provides the functionality to operate with `NIR <https://nnir.readthedocs.io/en/latest/>`_ representation.

.. autofunction:: sinabs.nir.to_nir

.. autofunction:: sinabs.nir.from_nir

