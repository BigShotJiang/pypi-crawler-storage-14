utils
=====

.. py:currentmodule:: sinabs.utils

.. autofunction:: sinabs.utils.reset_states
.. autofunction:: sinabs.utils.zero_grad
.. autofunction:: sinabs.utils.get_activations
.. autofunction:: sinabs.utils.get_network_activations
.. autofunction:: sinabs.utils.normalize_weights
.. autofunction:: sinabs.utils.set_batch_size
.. autofunction:: sinabs.utils.validate_memory_mapping_speck
