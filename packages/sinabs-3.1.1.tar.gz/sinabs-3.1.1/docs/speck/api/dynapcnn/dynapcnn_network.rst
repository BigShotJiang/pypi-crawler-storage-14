dynapcnn_network
================

This module describes the ``DynapcnnNetwork`` class that is used to transform a spiking neural network into a network that is compatible with dynapcnn.

.. automodule:: sinabs.backend.dynapcnn.dynapcnn_network
    :members:
