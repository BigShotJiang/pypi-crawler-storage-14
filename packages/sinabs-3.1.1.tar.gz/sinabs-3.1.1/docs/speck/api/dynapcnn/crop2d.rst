crop2d
======

.. autoclass:: sinabs.backend.dynapcnn.crop2d.Crop2d
    :members:
