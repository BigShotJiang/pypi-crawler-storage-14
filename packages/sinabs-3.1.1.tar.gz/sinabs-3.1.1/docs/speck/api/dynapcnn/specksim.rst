specksim
========


Specksim is a high performance Spiking-Convolutional Neural Network simulator which is written in C++.

.. automodule:: sinabs.backend.dynapcnn.specksim
    :members:
    :undoc-members: