chip_factory
============

.. autoclass:: sinabs.backend.dynapcnn.chip_factory.ChipFactory
    :members:
    :undoc-members:
