**PLUGINS**
===========

EXODUS
------
Train feedforward architectures with CUDA cores and the exodus algorithm. `Github repository <https://github.com/synsense/sinabs-exodus>`_ 

.. code-block:: shell

    pip install sinabs-exodus

