**GETTING STARTED**
===================

.. toctree::
   :maxdepth: 1

   install
   fundamentals
   iaf_neuron_model
   quickstart
   python_pyenv_pipenv
   