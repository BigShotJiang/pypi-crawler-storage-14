from .cli.main import cli

cli()
