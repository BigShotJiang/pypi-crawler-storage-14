"""A minimal library for comparing JSON objects with human-readable output."""

from .core import diff

__version__ = "0.1.0"
__all__ = ["diff"]
