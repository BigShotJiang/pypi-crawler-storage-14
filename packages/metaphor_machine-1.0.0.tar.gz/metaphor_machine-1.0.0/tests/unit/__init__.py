"""Unit tests for metaphor machine modules."""
