---
description: A valid test script with proper frontmatter
---
# Valid Script

This is a valid script with proper frontmatter and description.

## Steps
1. First step
2. Second step
3. Third step
