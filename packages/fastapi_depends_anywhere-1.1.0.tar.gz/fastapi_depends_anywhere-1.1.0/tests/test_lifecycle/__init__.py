"""Tests for fastapi_depends_anywhere.lifecycle module."""
