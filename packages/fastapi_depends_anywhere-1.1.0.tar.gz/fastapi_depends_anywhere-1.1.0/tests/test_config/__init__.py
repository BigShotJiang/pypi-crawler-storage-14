"""Tests for fastapi_depends_anywhere.config module."""
