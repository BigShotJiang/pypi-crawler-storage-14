"""
LogCost - Track what each log statement costs in production

Usage:
    import logcost  # ← That's it! Auto-installs tracking

    # Your existing code works unchanged
    import logging
    logger = logging.getLogger(__name__)
    logger.info("Processing order %s", order_id)  # ← Now tracked!

    # Optional: Export stats manually
    logcost.export("/path/to/stats.json")

GitHub: https://github.com/logcost/logcost-python
Docs: https://logcost.io/docs
"""

__version__ = "0.1.0"

from .tracker import (
    install,
    export,
    get_stats,
    reset,
    ignore_module,
    start_periodic_flush,
    stop_periodic_flush,
)
from .analyzer import CostAnalyzer
from .exporters import export_csv, export_prometheus, render_html_report
from .notifiers import (
    send_slack_notification,
    send_notification_if_configured,
)

# Auto-install on import (the magic!)
install()

__all__ = [
    "install",
    "export",
    "get_stats",
    "reset",
    "ignore_module",
    "start_periodic_flush",
    "stop_periodic_flush",
    "CostAnalyzer",
    "export_csv",
    "export_prometheus",
    "render_html_report",
    "send_slack_notification",
    "send_notification_if_configured",
]
