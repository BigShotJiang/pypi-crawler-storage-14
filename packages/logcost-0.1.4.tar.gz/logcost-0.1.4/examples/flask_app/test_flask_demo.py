#!/usr/bin/env python3
"""
Quick test to verify LogCost tracking works with Flask
"""
import sys

import pytest

pytest.importorskip("flask")

sys.path.insert(0, '.')

import logcost
from examples.flask_app.app import app, logger
import json

# Reset stats for clean test
logcost.reset()

# Create test client
client = app.test_client()

# Make some requests to generate logs
print("Making test requests...")
client.get('/')
client.get('/user/alice')
client.get('/user/bob')
client.get('/expensive')

# Get stats
stats = logcost.get_stats()

print(f"\nTracked {len(stats)} unique log statements:")
print("=" * 80)

for key, data in sorted(stats.items(), key=lambda x: x[1]['bytes'], reverse=True):
    print(f"\n{data['file']}:{data['line']}")
    print(f"  Level: {data['level']}")
    print(f"  Template: {data['message_template'][:80]}")
    print(f"  Count: {data['count']}")
    print(f"  Bytes: {data['bytes']:,}")

# Calculate total bytes
total_bytes = sum(data['bytes'] for data in stats.values())
total_count = sum(data['count'] for data in stats.values())

print("\n" + "=" * 80)
print(f"TOTAL: {total_count} log calls, {total_bytes:,} bytes")

# Export to file
output = logcost.export("/tmp/logcost_flask_demo.json")
print(f"\nStats exported to: {output}")
