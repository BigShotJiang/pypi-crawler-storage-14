"""
Main module file. This allows you to run python -m obsah
"""
from obsah import main  # pylint:disable=no-name-in-module
main()
