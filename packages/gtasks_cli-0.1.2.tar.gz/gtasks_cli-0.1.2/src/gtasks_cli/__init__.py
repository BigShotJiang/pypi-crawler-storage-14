"""Google Tasks CLI - A powerful command-line interface for managing Google Tasks."""

__version__ = "0.1.2"
__author__ = "Google Tasks CLI Team"
__email__ = "example@example.com"