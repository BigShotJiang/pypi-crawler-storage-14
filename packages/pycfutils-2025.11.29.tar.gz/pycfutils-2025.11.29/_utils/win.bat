@echo off

setlocal enabledelayedexpansion enableextensions

if defined NO_TEST (
    goto :eof
)
if defined NO_TESTS (
    goto :eof
)

:_test
    echo Testing...
    set PYTHONPATH=
    :: @TODO - cfati: End with \ (if no pattern given)
    if not defined TEST_VENV_PATTERN (
        :: set TEST_VENV_PATTERN="e:\Work\Dev\VEnvs\test0\"
        set TEST_VENV_PATTERN="e:\Work\Dev\VEnvs\test0\*test0"
    )
    if not defined TEST_WHEEL_DIR (
        set TEST_WHEEL_DIR="e:\Work\Dev\Repos\GitHub\CristiFati\pycfutils\src\dist"
    )
    call bat_funcs dirname %TEST_VENV_PATTERN% _VENVS_DIR
    set _VENVS_DIR=%_VENVS_DIR:"=%
    for /f %%g in ('dir /b /ad %TEST_VENV_PATTERN:"=%') do (
        echo Using environment: "%_VENVS_DIR%\%%g"
        call "%_VENVS_DIR%\%%g\Scripts\activate.bat"
        set _TESTS_DIR="%_VENVS_DIR%\%%g\Lib\site-packages\pycfutils\tests"
        python -VV
        python -m pip uninstall -y pycfutils
        python -m pip install pynput
        python -m pip -v install --no-index -f %TEST_WHEEL_DIR% pycfutils
        python -m unittest discover -s !_TESTS_DIR!
        echo Test dummy imports...
        python "!_TESTS_DIR:"=!\_manual.py"
        python -m pip uninstall -y pycfutils pynput
        call deactivate
    )
    set _PY_CODE=
    goto :eof
