"""Tests for ocrbridge-core package."""
