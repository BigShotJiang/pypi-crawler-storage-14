# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------
"""Contains distributed forecasting modules for AutoML DNN forecasting package."""
