# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------
"""Contains packages, modules and classes for AutoML forecasting package."""
__path__ = __import__('pkgutil').extend_path(__path__, __name__)
