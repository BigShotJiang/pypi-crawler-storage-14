"""Electricity consumption of 370 clients. https://archive.ics.uci.edu/ml/datasets/ElectricityLoadDiagrams20112014."""

from .data_source import ElectricityDataSource  # noqa: F401
