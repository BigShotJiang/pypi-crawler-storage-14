"""A data source an interface to the Parts dataset."""

from .data_source import PartsDataSource  # noqa: F401
