"""A data source an interface to the M5 dataset."""

from .data_source import M5DataSource  # noqa: F401
