"""Loads data from the GEFCom14-E competition."""

from .data_source import GEFCom14DataSource  # noqa: F401
