"""Supplies Github daily active user data for evaluating forecasting models."""

from .data_source import GithubDataSource  # noqa: F401
