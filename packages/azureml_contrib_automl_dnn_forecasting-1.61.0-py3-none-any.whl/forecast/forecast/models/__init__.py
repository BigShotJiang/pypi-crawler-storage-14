"""Components for constructing forecasting models as well as a couple "canned" demo architectures."""

from .model import ForecastingModel  # noqa: F401
