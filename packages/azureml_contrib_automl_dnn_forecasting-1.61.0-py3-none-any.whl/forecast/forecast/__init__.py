"""A framework for building and evaluating neural network based forecasting models."""
