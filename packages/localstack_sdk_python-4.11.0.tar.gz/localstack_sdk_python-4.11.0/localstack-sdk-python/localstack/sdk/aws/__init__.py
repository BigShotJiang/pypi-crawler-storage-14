from localstack.sdk.aws.client import AWSClient

__all__ = ["AWSClient"]
