# Meu Pacote

Este é a primeira versão de nosso Datapackage Manager de Minas Gerais.
