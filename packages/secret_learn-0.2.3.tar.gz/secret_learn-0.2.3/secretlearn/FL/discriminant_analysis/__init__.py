"""SecretFlow discriminant_analysis adapters"""
