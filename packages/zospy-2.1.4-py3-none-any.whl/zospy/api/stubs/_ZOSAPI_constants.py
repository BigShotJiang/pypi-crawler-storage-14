"""Provide autocompletion for `zospy.constants`.

This file is intentionally left empty.
"""

# ruff: noqa: N999
