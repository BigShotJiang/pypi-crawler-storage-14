"""Lark grammars for parsing OpticStudio analysis output files."""
