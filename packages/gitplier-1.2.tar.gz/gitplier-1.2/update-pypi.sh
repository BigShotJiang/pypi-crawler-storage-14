#!/bin/bash
. .venv/bin/activate
pip3 install --upgrade build
pip3 install --upgrade twine
python3 -m build
version=$(sed -n 's/^version = "\(.*\)"$/\1/p' pyproject.toml)
python3 -m twine upload dist/gitplier-$version.tar.gz dist/gitplier-$version-py3-none-any.whl
