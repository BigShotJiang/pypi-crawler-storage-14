from __future__ import annotations
import os
from typing import Iterator, TYPE_CHECKING
from ._exceptions import GitError
if TYPE_CHECKING:
    from ._repository import Repository


class FilesystemObject:
    """A base class for file info. The only attribute you can rely on to be present is
    `path` and `sha`. The `path` is always relative to the repository root."""
    path: str
    sha: str

    def __init__(self, repository: 'Repository', path: str, sha: str) -> None:
        self.path = path
        self.sha = sha
        self._repository = repository

    @classmethod
    def _construct(cls, repository: 'Repository', iterator: Iterator[str]) -> FilesystemObject:
        """An internal method to construct an appropriate subclass from an iterator."""
        data = next(iterator)
        fields = data.split(' ', 4)
        if len(fields) != 5:
            raise GitError(f'Unexpected output from git: "{data}"')
        if fields[0] == 'tree':
            return Directory(repository, fields[4], fields[1])
        if fields[0] == 'blob':
            try:
                mode = int(fields[2])
                size = int(fields[3])
            except ValueError:
                raise GitError(f'Unexpected output from git: "{data}"')
            return File(repository, fields[4], fields[1], mode, size)
        raise GitError(f'Unexpected output from git: "{data}"')


class Directory(FilesystemObject):
    """A directory. The available attributes are `path` and `sha`. The root directory has
    an empty `path`."""

    def ls(self) -> Iterator[FilesystemObject]:
        """Yield items in this directory. It's not recursive."""
        for obj in self._repository.ls(self.sha, recursive=False):
            obj.path = os.path.join(self.path, obj.path)
            yield obj


class File(FilesystemObject):
    """A non-directory. A file, a symlink, etc. The current version of gitplier does not
    distinguish those further but future versions might, as subclasses of `File`. To remain
    compatible, always use `isinstance(o, File)` instead of `type(o) == File`. The available
    attributes are `path`, `sha`, `mode` and `size`."""
    mode: int
    size: int

    def __init__(self, repository: 'Repository', path: str, sha: str, mode: int,
                 size: int) -> None:
        super().__init__(repository, path, sha)
        self.mode = mode
        self.size = size

    def get(self) -> bytes:
        """Return the content of this file."""
        return self._repository._get_blob(self.sha)
