class Config:
    enrich_token_usage = False
    exception_logger = None
    use_legacy_attributes = True
