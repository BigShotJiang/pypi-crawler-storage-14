# RAG Prompt Best Practices

## XML Tags recommended by Anthropic

```xml
<examples></examples>
<thinking></thinking>
<answer></answer>
```

```xml
<instructions>
1. Include sections: Revenue Growth, Profit Margins, Cash Flow.
2. Highlight strengths and areas for improvement.
</instructions>
```

```xml
You're a financial analyst at AcmeCorp. Generate a Q2 financial report for our investors.

AcmeCorp is a B2B SaaS company. Our investors value transparency and actionable insights.

Use this data for your report:<data>{{SPREADSHEET_DATA}}</data>

<instructions>
1. Include sections: Revenue Growth, Profit Margins, Cash Flow.
2. Highlight strengths and areas for improvement.
</instructions>

Make your tone concise and professional. Follow this structure:
<formatting_example>{{Q1_REPORT}}</formatting_example>
```

```xml
<instructions>
1. Analyze these clauses:
- Indemnification
- Limitation of liability
- IP ownership

2. Note unusual or concerning terms.

3. Compare to our standard contract.

4. Summarize findings in <findings> tags.

5. List actionable recommendations in <recommendations> tags.</instructions>
```

```xml
Use this data for your report:
<data>
{{SPREADSHEET_DATA}}
</data>
```

```xml
<example>
</example>
```

```xml
<formatting>
</formatting>
```

### Examples

```xml
Make your tone concise and professional. Follow this structure:
<formatting_example>{{Q1_REPORT}}</formatting_example>
```

### Nesting example extrapolated from anthropic examples

```xml
<article><title></title><text><text></article>
```