from datasets import load_dataset

ds = load_dataset("HIT-TMG/TruthReader_RAG_train")
from datasets import load_dataset

ds2 = load_dataset("FreedomIntelligence/RAG-Instruct")
import pandas as pd

# Login using e.g. `huggingface-cli login` to access this dataset
splits = {'train': 'covidqa/train-00000-of-00001.parquet', 'test': 'covidqa/test-00000-of-00001.parquet', 'validation': 'covidqa/validation-00000-of-00001.parquet'}
dfcovid = pd.read_parquet("hf://datasets/galileo-ai/ragbench/" + splits["train"])
import pandas as pd

# Login using e.g. `huggingface-cli login` to access this dataset
splits = {'train': 'cuad/train-00000-of-00001.parquet', 'validation': 'cuad/validation-00000-of-00001.parquet', 'test': 'cuad/test-00000-of-00001.parquet'}
dfcuad = pd.read_parquet("hf://datasets/galileo-ai/ragbench/" + splits["train"])
import pandas as pd

# Login using e.g. `huggingface-cli login` to access this dataset
splits = {'train': 'delucionqa/train-00000-of-00001.parquet', 'validation': 'delucionqa/validation-00000-of-00001.parquet', 'test': 'delucionqa/test-00000-of-00001.parquet'}
dfdelucionqa = pd.read_parquet("hf://datasets/galileo-ai/ragbench/" + splits["train"])
ds2
help(load_dataset)
ls /home/user/.cache/huggingface/
ls /home/user/.cache/huggingface/datasets
ls /home/user/.cache/huggingface/
ls /home/user/.cache/huggingface/xet
ls /home/user/.cache/huggingface/hub
from datasets import load_dataset

# Login using e.g. `huggingface-cli login` to access this dataset
ds3 = load_dataset("galileo-ai/ragbench", "covidqa")
dses = []
dses.append(ds)
dses.append(ds1)
dses.append(ds2)
dses.append(ds3)
for rbname in 'delucionqa cuad'.split():
    dses.append(load_dataset("galileo-ai/ragbench", rbname))
history -o -p -f rdrag-benchmarks.hist.ipy
history -f rdrag-benchmarks.hist.py
