.
├── build -> ../../llama.cpp/build
└── README-tree.txt

2 directories, 1 file
