full_version = "11.1.1"
short_version = ".".join(full_version.split(".", 2)[:2])
