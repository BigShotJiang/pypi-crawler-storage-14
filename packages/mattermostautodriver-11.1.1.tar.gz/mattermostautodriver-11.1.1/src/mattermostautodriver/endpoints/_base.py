class Base:
    def __init__(self, client):
        self.client = client
