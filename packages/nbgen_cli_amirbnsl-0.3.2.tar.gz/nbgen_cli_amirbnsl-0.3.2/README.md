# nbgen

A CLI tool to generate Jupyter Notebooks with data loading scripts.

## Installation

```bash
pip install nbgen-cli-amirbnsl
```

## Usage

```bash
nbgen my_notebook.ipynb
```

With Kaggle support:
```bash
nbgen my_kaggle_notebook.ipynb -k
```

### Credentials
The tool looks for Kaggle credentials in the following order:
1. Command line arguments: `--kaggle-user` and `--kaggle-key`
2. Environment variables: `KAGGLE_USERNAME` and `KAGGLE_KEY`
3. Kaggle configuration file: `~/.kaggle/kaggle.json`

If the notebook already exists, the new cells will be prepended to the top of the notebook.
