# AI Grader

Submission and grading system for AI bootcamp assignments. A Go backend + Vite frontend application that manages student submissions, hosts interactive ML/AI visualizations, and provides student dashboards with scores and leaderboards.

## ⚠️ IMPORTANT: Active Development Focus

**🎯 This project is actively developed for Batch 10+ using Convex backend.**

- ✅ **Active Development:** Batch 10+ with Convex real-time database
- ⚠️ **Legacy (Read-Only):** Batches 1-9 with Google Sheets (deprecated, no new features)

**For development and new features, see:**
- **[BATCH10_QUICKSTART.md](./BATCH10_QUICKSTART.md)** - Quick start guide
- **[CLAUDE.md](./CLAUDE.md)** - Complete development guide

## Features (Batch 10+)

**🎯 Active Features (Batch 10+):**
- ⚡ **Convex real-time database** - On-demand scoring, zero pre-computation
- 🎯 **Automated scoring engine** - 7 strategies with 6 preprocessing functions
- 🏆 **Auto-updating leaderboards** - Recalculate after each submission
- 📊 **Student submission management** - Real-time with Convex
- 🎨 **Interactive ML/AI visualizations** - KNN, K-means, PCA, Linear Regression, etc.
- 🔄 **Hot reload development** - Air for Go, Vite for frontend

**⚠️ Legacy Features (Deprecated):**
- Google Sheets integration (Batches 1-9 only, read-only)
- Google Drive integration (image storage, deprecated)
- BigQuery analytics (deprecated)

## Tech Stack

### Backend (Active Development)
- **Go** with Gin framework
- **Convex** (real-time database) ⭐ **PRIMARY**
- **Google Sheets API** (legacy only, deprecated)
- **BigQuery** (legacy only, deprecated)

### Frontend
- **Vite** with custom plugins
- **Alpine.js** for interactivity
- **TailwindCSS** for styling
- Interactive visualizations using GSAP, KaTeX, and marked.js

### Scoring Engine (Batch 10+)
- **7 scoring strategies**: exact, contains, containsAll, partial, numeric, image, regex
- **6 preprocessing functions**: trim, toLowerCase, normalizeWhitespace, removeAllSpaces, removeSpecialChars, decimalToPercent
- **Extensible registry pattern** for adding custom strategies/preprocessing
- **Manual score overrides** with admin audit trail

## Architecture

### 🎯 Primary System: Convex (Batch 10+)

**This is the active development focus:**

- Convex real-time database
- On-demand score calculation using scoring engine
- Automatic leaderboard updates after each submission
- YAML-based question configuration
- Extensible registry pattern

### ⚠️ Legacy System (DEPRECATED)

**Batches 1-9 - Read-only, no new development:**

- Google Sheets as primary data store
- Pre-computed scores stored in sheets
- Manual formula-based grading
- **Status:** Maintenance mode only
- YAML-based question configuration

### Conditional Routing

The system automatically routes requests based on `batch.useConvex` flag in `batches.yml`:

```yaml
# Legacy batch
- id: batch-9
  useConvex: false
  sheetId: "1abc..."

# Modern batch
- id: batch-10
  useConvex: true
  convexUrl: "https://your-project.convex.cloud"
```

## Development

### Prerequisites
- Go 1.18+
- Node.js 18+ for Vite frontend
- Google Cloud credentials (`.env` file)
- Air for hot reload
- Convex account (for Batch 10+)

### Setup

1. Clone the repository
```bash
git clone https://github.com/ruang-guru/ai-grader.git
cd ai-grader
```

2. Install dependencies
```bash
# Go dependencies
go mod download

# Frontend dependencies
npm install
```

3. Configure environment variables (`.env` file required)

4. (Optional) Set up Convex for new batches
```bash
npx convex login
npx convex dev
```

See [CONVEX_SETUP.md](./CONVEX_SETUP.md) for detailed Convex deployment guide.

### Running Locally

#### Backend with hot reload (Recommended)

**Option 1: Use dev script (auto-seeds questions)**
```bash
# Start with default batch (batch-10)
./scripts/dev.sh

# Or specify batch
./scripts/dev.sh batch-11
```

This script automatically:
- ✅ Checks Convex connection
- ✅ Seeds questions from YAML to Convex
- ✅ Starts backend with Air (hot reload)

**Option 2: Manual start**
```bash
# Manually seed questions first
go run scripts/seed_questions.go \
  config/questions/batch-10.yml \
  https://utmost-mole-417.convex.cloud

# Then start backend
air
```

#### Frontend development
```bash
npm run dev  # or: npx vite
```

#### Build frontend assets
```bash
npx vite build
```

### Testing

```bash
# Run all tests
go test ./...

# Run specific package tests
go test ./service/...

# Run Convex integration tests (requires CONVEX_URL env var)
CONVEX_URL=https://your-project.convex.cloud go test ./tests -v -run TestConvex

# Run rggrader E2E compatibility tests (requires backend running)
./test_rggrader_e2e.sh
```

#### rggrader E2E Tests

Test backward compatibility with the `rggrader` Python package:

```bash
# Prerequisites
pip install Pillow  # For image generation

# Start backend
air  # or: go run .

# Run E2E tests
./test_rggrader_e2e.sh
```

**What's tested:**
- ✅ Text submission via `/submit/bquery` (rggrader format)
- ✅ Image submission via `/submit/gdrive` (base64-encoded)
- ✅ Legacy field names (`id`, `name`, `assignment_name`)
- ✅ Routing to Convex backend
- ✅ Multiple submissions (highest score tracking)
- ✅ Student card display

See `docs/RGGRADER_COMPATIBILITY.md` for details.

## Deployment

### Production
The application is deployed on **Google Cloud Run**:
- **Service URL**: https://console.cloud.google.com/run/detail/asia-southeast1/ai-grader/revisions?project=silicon-airlock-153323

### CI/CD
Automated deployment via **Cloud Build**:
- **Build Triggers**: https://console.cloud.google.com/cloud-build/builds;region=global?query=trigger_id%3D%22357854e8-d717-4394-8ad3-811765a6b2b3%22&project=silicon-airlock-153323
- **Trigger**: Automatically builds and deploys on push to `main` branch

### Convex Deployment

```bash
# Deploy Convex functions
npx convex deploy

# Seed question configurations
go run scripts/seed_questions.go \
  config/questions/batch-10.yml \
  $CONVEX_URL
```

## Project Structure

```
.
├── handler/          # HTTP request handlers
├── service/          # Business logic layer
├── repo/             # Data access layer (Google Sheets + Convex)
├── entities/         # Domain models
├── model/            # API models and BigQuery schemas
├── templates/        # Go HTML templates
├── src/              # Vite source files (HTML, MD)
├── assets/           # Built frontend assets
├── convex/           # Convex backend (TypeScript)
│   ├── schema.ts           # Database schema (8 tables)
│   ├── scoring.ts          # Core scoring engine
│   ├── strategies.ts       # 7 scoring strategies
│   ├── preprocessing.ts    # 6 preprocessing functions
│   ├── leaderboard.ts      # Auto-recalculating leaderboard
│   ├── submissions.ts      # Submission mutations/queries
│   └── queries/            # Student, score, and misc queries
├── config/           # Configuration files
│   └── questions/          # Question configs per batch (YAML)
├── scripts/          # Utility scripts
│   └── seed_questions.go   # Seed questions to Convex
├── tests/            # Integration tests
├── .claude/          # Claude Code skills
│   └── skills/
│       ├── convert-answers-to-sheet.md
│       ├── create-scoring-strategy.md
│       └── create-preprocessing-strategy.md
├── batches.yml       # Batch configuration
└── main.go           # Application entry point
```

## Key Workflows

### Adding a New Batch (Batch 10+, using Convex)

1. **Add batch to `batches.yml`**
```yaml
- name: Mastering AI - Batch 11
  id: batch-11
  sheetId: ""  # Leave empty for Convex batches
  useConvex: true
  convexUrl: "https://your-project.convex.cloud"
  firstAssignment: Challenge-1
```

2. **Create question configuration**
```bash
cp config/questions/batch-10.yml config/questions/batch-11.yml
# Edit with your questions
```

3. **Seed questions to Convex**
```bash
go run scripts/seed_questions.go \
  config/questions/batch-11.yml \
  $CONVEX_URL
```

4. **Restart server** (Air will auto-reload)

See [MIGRATION_PLAN.md](./MIGRATION_PLAN.md) for complete guide.

### Creating Question Configurations

Use Claude Code skills to streamline question setup:

```bash
# Convert user-provided answers to YAML config
# Skill: convert-answers-to-sheet

# Add custom scoring strategy
# Skill: create-scoring-strategy

# Add custom preprocessing
# Skill: create-preprocessing-strategy
```

See `.claude/skills/` for detailed guides.

### Submission Flow

#### Legacy (Batches 1-9)
1. Student submits via frontend form
2. Request hits `/submission/submit/bquery` endpoint
3. Handler validates and extracts data
4. Service layer writes to Google Sheets and BigQuery
5. For image submissions, Google Drive API stores files

#### Modern (Batch 10+)
1. Student submits via frontend form
2. Request hits `/submission/submit/convex` endpoint
3. Handler validates and calls Convex action: `submitAssignment`
4. Convex inserts submission to database
5. **Leaderboard automatically recalculates** (background task)
6. For image submissions, tracks in `imageSubmissions` table

### Scoring Flow (Batch 10+)

When viewing a student card or leaderboard:
1. Query triggers score calculation for each question
2. Check for manual override first (if exists, return override)
3. Get question configuration (strategy, preprocessing, correct answers)
4. Get student's latest submission
5. Apply preprocessing to both submission and correct answers
6. Apply scoring strategy (exact, contains, partial, numeric, etc.)
7. Return score (0-100 or -1 for "not submitted")

**Note:** Scores are calculated on-demand, never pre-stored (except manual overrides).

## Scoring Strategies

| Strategy | Description | Example Use Case |
|----------|-------------|------------------|
| **exact** | Exact string match | Simple text answers |
| **contains** | Contains any correct answer (OR logic) | Keyword detection |
| **containsAll** | Contains all correct answers (AND logic) | Multi-part answers |
| **partial** | Percentage of correct answers found | Partial credit grading |
| **numeric** | Parse submission as number | ML model accuracy, percentages |
| **image** | Check if image submitted | Image-based assignments |
| **regex** | Regex pattern matching | Complex validation |

See [SCORING_ENGINE_DESIGN.md](./SCORING_ENGINE_DESIGN.md) for detailed documentation.

## Preprocessing Functions

| Function | Transform | Example |
|----------|-----------|---------|
| **trim** | Remove leading/trailing spaces | `"  hello  "` → `"hello"` |
| **removeAllSpaces** | Remove all whitespace | `"h e l l o"` → `"hello"` |
| **toLowerCase** | Convert to lowercase | `"HELLO"` → `"hello"` |
| **normalizeWhitespace** | Multiple spaces → single | `"hello    world"` → `"hello world"` |
| **removeSpecialChars** | Keep only alphanumeric | `"hello!"` → `"hello"` |
| **decimalToPercent** | 0.85 → 85 | `"0.95"` → `"95"` |

Preprocessing is applied to **both** student submissions and correct answers for fair comparison.

## Important Notes

### For All Batches
- Student IDs and batch IDs must match between systems
- Templates are embedded in Go binary via `//go:embed`
- The `sheetOrder` tag in structs maps Go fields to Sheet columns

### For Legacy Batches (1-9)
- Google Sheets acts as the primary database
- BigQuery is used for analytics and historical data
- Scores are pre-computed in sheets using formulas

### For Modern Batches (10+)
- Convex is the primary database
- Scores calculated on-demand (no pre-computation)
- Question configurations are version-controlled in YAML
- Leaderboard updates automatically after each submission
- Manual score overrides tracked with admin audit trail

## Documentation

| Document | Purpose |
|----------|---------|
| [CLAUDE.md](./CLAUDE.md) | Development guidance for Claude Code |
| [MIGRATION_PLAN.md](./MIGRATION_PLAN.md) | Complete migration guide (Sheets → Convex) |
| [SCORING_ENGINE_DESIGN.md](./SCORING_ENGINE_DESIGN.md) | Scoring engine architecture and usage |
| [CONVEX_SETUP.md](./CONVEX_SETUP.md) | Convex deployment and configuration |
| [IMPLEMENTATION_SUMMARY.md](./IMPLEMENTATION_SUMMARY.md) | Implementation handoff and checklist |

## Extending the System

### Adding New Scoring Strategy

Edit `convex/strategies.ts`:
```typescript
const STRATEGY_REGISTRY: Record<string, StrategyFunction> = {
  // ... existing strategies
  yourNewStrategy: ({ processedSubmission, processedCorrectAnswers }) => {
    // Your scoring logic (must return 0-100)
    return score;
  },
};
```

See `.claude/skills/create-scoring-strategy.md` for detailed guide.

### Adding New Preprocessing

Edit `convex/preprocessing.ts`:
```typescript
const PREPROCESSING_REGISTRY: Record<string, PreprocessingFunction> = {
  // ... existing steps
  yourNewStep: (input: string) => {
    // Your transformation (must return string)
    return transformedInput;
  },
};
```

See `.claude/skills/create-preprocessing-strategy.md` for detailed guide.

## Troubleshooting

### Scores always 0
- Check question configuration exists in Convex
- Verify `isActive: true` in YAML
- Re-seed: `go run scripts/seed_questions.go config/questions/batch-X.yml $CONVEX_URL`

### Leaderboard not updating
- Verify `submitAssignment` is an action (not mutation) in `convex/submissions.ts`
- Check Convex logs for errors in leaderboard calculation
- Manually trigger: Call `calculateLeaderboard` action from Convex dashboard

### Submission fails
- Check batch has `useConvex: true` in `batches.yml`
- Verify Convex URL is correct
- Check Convex deployment status

See troubleshooting sections in individual docs for more details.

## License

ISC
