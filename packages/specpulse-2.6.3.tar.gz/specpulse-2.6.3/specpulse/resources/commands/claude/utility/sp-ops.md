# Utility Commands

## Backup Operations
### /sp-backup
Backup current project state, configurations, and memory

## Restore Operations  
### /sp-restore
Restore project from previous backup

## Cleanup Operations
### /sp-clean
Clean up old files, temporary data, and optimize storage
