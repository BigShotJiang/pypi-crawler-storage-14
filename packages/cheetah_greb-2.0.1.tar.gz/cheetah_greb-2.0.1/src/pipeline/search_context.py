"""
Search context tracker for intelligent multi-turn search.

Tracks search state across turns to enable intelligent decision-making
without requiring LLM calls.
"""

from __future__ import annotations

from typing import List, Set
from dataclasses import dataclass, field
from .base import CandidateMatch


@dataclass
class SearchContext:
    """
    Tracks search state across multiple turns.

    Maintains information about search patterns and high-quality files
    to enable intelligent search decisions.
    """

    # Search patterns we've already tried
    seen_patterns: Set[str] = field(default_factory=set)

    # Candidate quality tracking
    high_quality_files: Set[str] = field(default_factory=set)

    def update_from_results(self, candidates: List[CandidateMatch]):
        """
        Update context from search results.

        Args:
            candidates: List of candidate matches from a search
        """
        for candidate in candidates:
            # Mark high quality if match looks promising
            if self._is_high_quality_match(candidate):
                self.high_quality_files.add(candidate.path)

    def _is_high_quality_match(self, candidate: CandidateMatch) -> bool:
        """
        Determine if a match looks high quality.

        Args:
            candidate: Candidate match to evaluate

        Returns:
            True if match appears high quality
        """
        # Long matches are usually more specific
        if len(candidate.matched_text) > 50:
            return True

        # Matches with context are better
        if candidate.context_before or candidate.context_after:
            return True

        # Check for code definition keywords
        definition_keywords = ['def ', 'class ', 'function ', 'const ', 'interface ', 'type ']
        if any(kw in candidate.matched_text for kw in definition_keywords):
            return True

        return False

    def get_high_quality_files(self, n: int = 5) -> List[str]:
        """
        Get high quality files.

        Args:
            n: Maximum number of files to return

        Returns:
            List of high quality file paths
        """
        return list(self.high_quality_files)[:n]

    def add_pattern(self, pattern: str):
        """
        Mark a search pattern as seen.

        Args:
            pattern: Search pattern to mark
        """
        self.seen_patterns.add(pattern.lower())

    def has_seen_pattern(self, pattern: str) -> bool:
        """
        Check if a pattern has been searched.

        Args:
            pattern: Pattern to check

        Returns:
            True if pattern has been seen
        """
        return pattern.lower() in self.seen_patterns
