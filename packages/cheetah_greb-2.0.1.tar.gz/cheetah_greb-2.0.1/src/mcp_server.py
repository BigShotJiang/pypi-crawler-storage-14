"""
Greb MCP Server - AI-powered code search.
"""

import asyncio
import logging
import os
import re
import sys
from typing import Any, Dict, List, Optional, TypedDict
from concurrent.futures import ThreadPoolExecutor

import httpx
from mcp.server.fastmcp import FastMCP

# Suppress httpx INFO logs
logging.getLogger("httpx").setLevel(logging.WARNING)

# Initialize FastMCP server
mcp = FastMCP("greb-mcp")

# Configuration from environment
# GREB_API_URL is the main URL for the GPU rerank service
GPU_API_URL = os.getenv("GREB_API_URL") or os.getenv("GREB_GPU_API_URL") or "https://search.grebmcp.com"
USER_AGENT = "greb-mcp/2.0.1"


class ExtractedKeywords(TypedDict):
    """Keywords extracted by the AI agent for search."""
    primary_terms: List[str]
    file_patterns: List[str]
    intent: str


async def make_greb_request(
    method: str,
    url: str,
    headers: Dict[str, str],
    params: Optional[Dict[str, Any]] = None,
    json_data: Optional[Dict[str, Any]] = None
) -> Optional[Dict[str, Any]]:
    """Make an async HTTP request to the Greb API."""
    async with httpx.AsyncClient(timeout=60.0) as client:
        try:
            if method.upper() == "GET":
                response = await client.get(url, headers=headers, params=params)
            elif method.upper() == "POST":
                response = await client.post(url, headers=headers, json=json_data)
            else:
                return None

            response.raise_for_status()
            return response.json()
        except Exception as e:
            print(f"API request error: {e}", file=sys.stderr)
            return None


def _smart_deduplicate(candidates: List, keywords: List[str]) -> List:
    """
    Smart deduplication: one result per file per keyword.
    """
    from collections import defaultdict
    
    file_candidates = defaultdict(list)
    for candidate in candidates:
        file_candidates[candidate.path].append(candidate)
    
    result = []
    
    for file_path, file_cands in file_candidates.items():
        best_per_keyword = {}
        
        for candidate in file_cands:
            matched_text_lower = candidate.matched_text.lower()
            context_lower = (
                (candidate.context_before or '') +
                matched_text_lower +
                (candidate.context_after or '')
            ).lower()
            
            matched_keyword = None
            for kw in keywords:
                if kw.lower() in context_lower:
                    if matched_keyword is None:
                        matched_keyword = kw
            
            if matched_keyword:
                if matched_keyword not in best_per_keyword:
                    best_per_keyword[matched_keyword] = candidate
                else:
                    existing = best_per_keyword[matched_keyword]
                    existing_context = len(existing.context_before or '') + len(existing.context_after or '')
                    new_context = len(candidate.context_before or '') + len(candidate.context_after or '')
                    if new_context > existing_context:
                        best_per_keyword[matched_keyword] = candidate
            else:
                if 'no_keyword' not in best_per_keyword:
                    best_per_keyword['no_keyword'] = candidate
        
        seen_ranges = []
        
        def ranges_overlap(s1, e1, s2, e2):
            return s1 <= e2 and s2 <= e1
        
        for keyword, candidate in best_per_keyword.items():
            start_line = candidate.line_number
            context_lines = len((candidate.context_after or '').split('\n')) if candidate.context_after else 0
            end_line = start_line + context_lines
            
            if any(ranges_overlap(start_line, end_line, s, e) for s, e in seen_ranges):
                continue
            
            seen_ranges.append((start_line, end_line))
            result.append(candidate)
    
    return result


def _select_best_search_terms(terms: List[str], n: int) -> List[str]:
    """Select best N search terms using quality scoring."""
    scored_terms = []
    
    for term in terms:
        score = 0.0
        score += min(len(term) / 20.0, 0.5)
        if '_' in term or (term != term.lower() and term != term.upper()):
            score += 0.3
        if re.match(r'^[a-zA-Z_][a-zA-Z0-9_]*$', term):
            score += 0.2
        common_words = ['the', 'a', 'an', 'is', 'in', 'to', 'for', 'of', 'and', 'or']
        if term.lower() in common_words:
            score -= 0.8
        if len(term) < 3:
            score -= 0.3
        scored_terms.append((term, score))
    
    scored_terms.sort(key=lambda x: x[1], reverse=True)
    return [term for term, score in scored_terms[:n] if score > 0]


def _turn2_ast_references(
    grep_tool,
    previous_results: List,
    search_context,
    directory: str,
    file_patterns: Optional[List[str]]
) -> List:
    """Turn 2: AST reference following."""
    from .pipeline.code_analyzer import FastCodeAnalyzer
    
    code_analyzer = FastCodeAnalyzer()
    
    # Get top files from Turn 1
    top_files = search_context.get_high_quality_files(n=5)
    if not top_files:
        top_files = [r.path for r in previous_results[:5]]
    
    # Extract AST references
    all_references = []
    for file_path in top_files:
        try:
            refs = code_analyzer.extract_references_fast(file_path)
            all_references.extend(refs)
        except Exception:
            continue
    
    # Score and select top references
    scored = []
    for ref in all_references:
        if search_context.has_seen_pattern(ref.name):
            continue
        score = ref.priority
        score += min(len(ref.name) / 30.0, 0.15)
        scored.append((ref, score))
    
    scored.sort(key=lambda x: x[1], reverse=True)
    top_refs = [ref for ref, score in scored[:2]]
    
    # Search for references
    candidates = []
    with ThreadPoolExecutor(max_workers=2) as executor:
        futures = []
        for ref in top_refs:
            if ref.type == 'import':
                pattern = ref.name
            elif ref.type == 'function_call':
                pattern = f"def {ref.name}"
            elif ref.type == 'function_def':
                pattern = f"{ref.name}("
            elif ref.type == 'class_def':
                pattern = f"class {ref.name}"
            else:
                pattern = ref.name
            
            if pattern and not search_context.has_seen_pattern(pattern):
                search_context.add_pattern(pattern)
                future = executor.submit(
                    grep_tool.search,
                    query=pattern,
                    directory=directory,
                    file_patterns=file_patterns,
                    case_sensitive=False,
                    context_lines=3
                )
                futures.append(future)
        
        for future in futures:
            try:
                results = future.result(timeout=3)
                candidates.extend(results)
            except Exception:
                continue
    
    return candidates


@mcp.tool()
async def code_search(
    query: str,
    keywords: ExtractedKeywords,
    directory: str = ".",
    file_patterns: List[str] = None
) -> str:
    """Search code using natural language queries powered by AI.

    Args:
        query: Natural language description of what to find
        keywords: Keywords extracted by the AI agent. Must include:
            - primary_terms: Main search keywords (e.g., ["authentication", "middleware"])
            - file_patterns: File extensions to search (e.g., ["*.py", "*.js"])
            - intent: Brief description of what you're looking for
        directory: FULL ABSOLUTE PATH to directory to search in (required for MCP, optional, default: current directory)
        file_patterns: File patterns to filter (optional, overrides keywords.file_patterns)

    Example:
        keywords = {
            "primary_terms": ["authentication", "middleware"],
            "file_patterns": ["*.js", "*.ts"],
            "intent": "find authentication middleware functions"
        }

    CRITICAL - DIRECTORY PATH REQUIREMENTS:
    
    You MUST provide the FULL ABSOLUTE PATH to the current workspace directory you are working in.
    DO NOT use relative paths like ".", "backend", or "src" - these will search the wrong location.
    
    How to get the correct workspace path:
    1. Check your current workspace root directory (where your project files are located)
    2. Use the FULL ABSOLUTE PATH of that workspace root
    3. If you need to search a subdirectory, append it to the workspace root path
    
    Examples of CORRECT paths:
        - Windows workspace: "D:\\greb_website" or "D:\\greb_website\\backend"
        - Linux/Mac workspace: "/home/user/myproject" or "/home/user/myproject/backend"
        - Current workspace: Use the full path shown in your workspace context
    
    Examples of WRONG paths (DO NOT USE):
        - "." (relative, will search wrong directory)
        - "backend" (relative, will search wrong directory)
        - "src" (relative, will search wrong directory)
    
    AFTER SEARCH: Once you get results, use the readFile tool to read all files
    line numbers shown in the highlights. This gives you full context without additional searches.
    """
    # Get API key from environment
    api_key = os.getenv("GREB_API_KEY")
    if not api_key:
        return "Error: GREB_API_KEY environment variable is required"

    # Directory validation
    if directory and not os.path.isabs(directory):
        return f"Error: MCP requires absolute paths. Got '{directory}'. Use full path like 'D:\\\\project' or '/home/user/project' instead."

    if directory == ".":
        directory = os.getcwd()

    headers = {
        "Authorization": f"Bearer {api_key}",
        "User-Agent": USER_AGENT,
        "Content-Type": "application/json"
    }

    # STEP 1: Local 2-turn search (like old implementation)
    from .pipeline.grep import GrepTool
    from .pipeline.search_context import SearchContext
    
    grep_tool = GrepTool()
    search_context = SearchContext()
    all_candidates = []
    
    # Get best search terms (scored by quality)
    raw_terms = keywords.get("primary_terms", [query])
    search_terms = _select_best_search_terms(raw_terms, n=2)
    if not search_terms:
        search_terms = raw_terms[:2]
    
    # TURN 1: Primary keyword search (parallel)
    for term in search_terms:
        search_context.add_pattern(term)
    
    with ThreadPoolExecutor(max_workers=2) as executor:
        futures = []
        for term in search_terms:
            future = executor.submit(
                grep_tool.search,
                query=term,
                directory=directory,
                file_patterns=file_patterns or keywords.get("file_patterns"),
                case_sensitive=False,
                context_lines=3
            )
            futures.append(future)
        
        for future in futures:
            try:
                results = future.result(timeout=3)
                all_candidates.extend(results)
            except Exception:
                continue
    
    search_context.update_from_results(all_candidates)
    
    # TURN 2: AST reference following
    turn2_candidates = _turn2_ast_references(
        grep_tool=grep_tool,
        previous_results=all_candidates,
        search_context=search_context,
        directory=directory,
        file_patterns=file_patterns or keywords.get("file_patterns")
    )
    all_candidates.extend(turn2_candidates)
    search_context.update_from_results(turn2_candidates)
    
    # SMART DEDUPLICATION: One result per file per keyword
    unique_matches = _smart_deduplicate(all_candidates, search_terms)
    
    if not unique_matches:
        return f"No results found for query: '{query}'"
    
    # STEP 2: Read file contents with 3-line context window
    # LIMIT: Max 200 candidates for BM42
    from .pipeline.read import ReadTool
    
    read_tool = ReadTool(max_file_size=500000)
    limited_matches = unique_matches[:200]  # LIMIT: Max 200 for GPU
    
    # Build a lookup map from (path, line_number) to grep match data
    # This ensures we can match spans back to their original grep data
    match_lookup = {}
    for match in limited_matches:
        key = (match.path, match.line_number)
        if key not in match_lookup:
            match_lookup[key] = match
    
    spans = read_tool.read_spans_from_candidates(limited_matches, window_size=3)
    
    # STEP 3: Prepare candidates for GPU API
    # Include BOTH grep match data (for BM42/FlashRank) AND full content (for Cerebras)
    candidates = []
    for span in spans:
        # Find the original grep match by path and approximate line number
        original_match = None
        for line_offset in range(0, 10):
            for sign in [0, 1, -1]:
                check_line = span.start_line + (line_offset * sign if sign else 0)
                key = (span.path, check_line)
                if key in match_lookup:
                    original_match = match_lookup[key]
                    break
            if original_match:
                break
        
        candidate = {
            "path": span.path,
            "start_line": span.start_line,
            "end_line": span.end_line,
            "content": span.text,  # Full span for Cerebras
        }
        
        # Add grep match data for BM42/FlashRank (CRITICAL for accuracy)
        if original_match:
            candidate["matched_text"] = original_match.matched_text
            candidate["context_before"] = original_match.context_before or ""
            candidate["context_after"] = original_match.context_after or ""
            candidate["line_number"] = original_match.line_number
            candidates.append(candidate)
        else:
            # Skip candidates where we can't find the original grep match
            # This ensures BM42/FlashRank get accurate data
            continue
    
    # STEP 4: Call GPU API for reranking
    try:
        gpu_response = await make_greb_request(
            method="POST",
            url=f"{GPU_API_URL}/v1/gpu-rerank",
            headers=headers,
            json_data={
                "query": query,
                "candidates": candidates,
                "keywords": {
                    "primary_terms": keywords.get("primary_terms", []),
                    "search_terms": keywords.get("primary_terms", []),
                    "file_patterns": keywords.get("file_patterns", []),
                    "intent": keywords.get("intent", query)
                },
                "top_k": 10
            }
        )
        
        if not gpu_response:
            return "Error: GPU rerank service unavailable"
        
        results = gpu_response.get('results', [])
        overall_reasoning = gpu_response.get('overall_reasoning')
        
    except Exception as e:
        return f"Error calling GPU rerank service: {e}"
    
    # STEP 5: Format results for MCP output
    if not results:
        return f"No results found for query: '{query}'"

    formatted_results = [f"## Found {len(results)} results for: {query}\n"]

    for i, result in enumerate(results, 1):
        path = result.get('path', 'unknown')
        score = result.get('score', 0.0)
        start_line = result.get('start_line', 1)
        end_line = result.get('end_line', 1)
        content = result.get('content', '')

        formatted_result = f"\n### {i}. {path}\n"
        formatted_result += f"**Relevance Score:** {score:.3f}\n"
        formatted_result += f"**Lines:** {start_line}-{end_line}\n"
        
        # Add the actual code content
        if content:
            formatted_result += f"\n**Code:**\n```\n{content}\n```\n"

        formatted_results.append(formatted_result)

    # Add overall reasoning
    if overall_reasoning:
        formatted_results.append(f"\n**Summary:**\n{overall_reasoning}")

    return "\n".join(formatted_results)


def main():
    """Initialize and run the MCP server."""
    import sys
    
    # Check required environment variables
    api_key = os.getenv("GREB_API_KEY")
    if not api_key:
        print("ERROR: GREB_API_KEY environment variable is required", file=sys.stderr)
        print("Set it in your MCP client configuration:", file=sys.stderr)
        print('  "env": { "GREB_API_KEY": "grb_your_api_key_here" }', file=sys.stderr)
        sys.exit(1)
    
    try:
        mcp.run(transport='stdio')
    except Exception as e:
        print(f"MCP Server Error: {e}", file=sys.stderr)
        import traceback
        traceback.print_exc(file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
