"""SWE-grep CLI - Cerebras-powered intelligent code search."""

from __future__ import annotations

from .main import main

__all__ = ["main"]