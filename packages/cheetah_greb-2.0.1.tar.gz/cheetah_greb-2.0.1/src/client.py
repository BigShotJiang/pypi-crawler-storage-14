"""
Greb Python Client SDK
This allows users to integrate Greb into their own applications and AI agents.

The client runs grep searches LOCALLY on user's machine, then sends
candidates to the API server for AI-powered reranking and billing.
"""

from __future__ import annotations

import os
import time
from typing import Optional, List, Dict, Any, Iterator
from dataclasses import dataclass

import httpx
from pydantic import BaseModel

# Import local search tools
import re
from concurrent.futures import ThreadPoolExecutor
from .pipeline.grep import GrepTool
from .pipeline.read import ReadTool
from .pipeline.base import CandidateMatch
from .pipeline.code_analyzer import FastCodeAnalyzer, CodeReference
from .pipeline.search_context import SearchContext


class SearchRequest(BaseModel):
    """Request model for code search - sends pre-searched candidates to server."""
    query: str
    candidates: List[Dict[str, Any]]  # Pre-searched matches from local grep
    max_results: Optional[int] = None


class SearchResult(BaseModel):
    """Individual search result."""
    path: str
    score: float
    highlights: List[Dict[str, Any]]
    summary: Optional[str] = None
    start_line: Optional[int] = None
    end_line: Optional[int] = None
    content: Optional[str] = None
    bm42_score: Optional[float] = None


class SearchResponse(BaseModel):
    """Response from code search."""
    results: List[SearchResult]
    total_candidates: int
    query: str
    execution_time_ms: Optional[float] = None
    extracted_keywords: Optional[Dict[str, Any]] = None
    tools_used: Optional[List[str]] = None
    overall_reasoning: Optional[str] = None


@dataclass
class ClientConfig:
    """Configuration for the Greb client."""
    api_key: str
    base_url: str
    timeout: int = 60
    max_retries: int = 3


class GrebClient:
    """
    Python client for Greb API.
    
    Usage:
        ```python
        from greb import GrebClient
        
        # Initialize with API key
        client = GrebClient(api_key="grb_your_api_key_here")
        
        # Search for code
        results = client.search(
            query="Find all database connection functions",
            directory="./src",
            file_patterns=["*.py", "*.js"]
        )
        
        for result in results.results:
            print(f"{result.path}: {result.summary}")
        ```
    """
    
    def __init__(
        self,
        api_key: Optional[str] = None,
        base_url: Optional[str] = None,
        timeout: int = 60,
        max_retries: int = 3,
        max_grep_results: int = None
    ):
        """
        Initialize the Greb client.
        
        Args:
            api_key: Your Greb API key (required or set GREB_API_KEY env var)
            base_url: API base URL (required or set GREB_API_URL env var)
            timeout: Request timeout in seconds
            max_retries: Maximum number of retry attempts
            max_grep_results: Max results from local grep (default: 1000)
        """
        self.api_key = api_key or os.getenv("GREB_API_KEY")
        if not self.api_key:
            raise ValueError(
                "API key is required. Set GREB_API_KEY environment variable "
                "or pass api_key parameter."
            )
        
        self.base_url = base_url or os.getenv("GREB_API_URL")
        if not self.base_url:
            raise ValueError(
                "API base URL is required. Set GREB_API_URL environment variable "
                "or pass base_url parameter."
            )
        
        self.timeout = timeout
        self.max_retries = max_retries
        
        # Initialize LOCAL search tools (run on user's machine)
        read_max_size = int(os.getenv("READ_MAX_FILE_SIZE", "5048576"))
        self.grep_tool = GrepTool()
        self.read_tool = ReadTool(max_file_size=read_max_size)
        self.code_analyzer = FastCodeAnalyzer()
        self.parallel_per_turn = 2  # Max parallel searches per turn
        
        # HTTP client for API requests
        self.client = httpx.Client(
            base_url=self.base_url,
            timeout=self.timeout,
            headers={
                "Authorization": f"Bearer {self.api_key}",
                "Content-Type": "application/json",
                "User-Agent": "greb-python/1.4.0"
            },
        )
    
    def search(
        self,
        query: str,
        keywords: Dict[str, Any],
        directory: Optional[str] = None,
        file_patterns: Optional[List[str]] = None,
        max_results: Optional[int] = None
    ) -> SearchResponse:
        """
        Search for code using natural language query.

        This method:
        1. Uses keywords provided by the calling agent
        2. Runs grep searches LOCALLY on your machine
        3. Reads file contents with context
        4. Sends candidates to GPU API for AI-powered reranking (BM42 + FlashRank + Cerebras)
        5. Returns ranked results with billing tracked

        Args:
            query: Natural language description of what you're looking for
            keywords: Extracted keywords from agent with structure:
                {
                    "primary_terms": ["term1", "term2"],
                    "file_patterns": ["*.py", "*.js"],
                    "intent": "description of search intent"
                }
            directory: Directory to search in (absolute or relative path)
            file_patterns: File patterns to filter (e.g., ["*.py", "*.js"])
            max_results: Maximum number of results to return (default: 10)

        Returns:
            SearchResponse containing ranked results

        Example:
            ```python
            keywords = {
                "primary_terms": ["authentication", "middleware"],
                "file_patterns": ["*.py", "*.js"],
                "intent": "find authentication middleware"
            }
            results = client.search(
                query="authentication middleware functions",
                keywords=keywords,
                directory="./backend/src",
            )
            ```
        """
        start_time = time.time()
        search_dir = os.path.abspath(directory) if directory else os.getcwd()
        top_k = max_results or int(os.getenv("TOP_K_RESULTS", "10"))
        search_context = SearchContext()
        
        # Get best search terms (scored by quality like old implementation)
        raw_terms = keywords.get("primary_terms", [query])
        search_terms = self._select_best_search_terms(raw_terms, n=self.parallel_per_turn)
        if not search_terms:
            search_terms = raw_terms[:self.parallel_per_turn]
        
        all_candidates: List[CandidateMatch] = []
        
        # TURN 1: Primary keyword search (parallel)
        turn1_candidates = self._turn1_primary_search(
            search_terms=search_terms,
            directory=search_dir,
            file_patterns=file_patterns or keywords.get("file_patterns"),
            search_context=search_context
        )
        all_candidates.extend(turn1_candidates)
        search_context.update_from_results(turn1_candidates)
        
        # TURN 2: AST reference following (parallel)
        turn2_candidates = self._turn2_ast_references(
            previous_results=turn1_candidates,
            search_context=search_context,
            directory=search_dir,
            file_patterns=file_patterns or keywords.get("file_patterns")
        )
        all_candidates.extend(turn2_candidates)
        search_context.update_from_results(turn2_candidates)
        
        # SMART DEDUPLICATION: One result per file per keyword (like old implementation)
        unique_matches = self._smart_deduplicate(all_candidates, search_terms)
        
        if not unique_matches:
            return SearchResponse(
                results=[],
                total_candidates=0,
                query=query,
                execution_time_ms=0.0,
                overall_reasoning="No matches found for the given query and keywords."
            )
        
        # STEP 2: Read file contents with 3-line context window
        # LIMIT: Max 200 candidates for GPU BM42
        limited_matches = unique_matches[:200]
        
        # Build a lookup map from (path, line_number) to grep match data
        # This ensures we can match spans back to their original grep data
        match_lookup = {}
        for match in limited_matches:
            key = (match.path, match.line_number)
            if key not in match_lookup:
                match_lookup[key] = match
        
        spans = self.read_tool.read_spans_from_candidates(limited_matches, window_size=3)
        
        # STEP 3: Prepare candidates for GPU API
        # Include BOTH grep match data (for BM42/FlashRank) AND full content (for Cerebras)
        candidates = []
        for span in spans:
            # Find the original grep match by path and approximate line number
            # The span's start_line should be close to the match's line_number
            original_match = None
            for line_offset in range(0, 10):  # Check nearby lines
                for sign in [0, 1, -1]:
                    check_line = span.start_line + (line_offset * sign if sign else 0)
                    key = (span.path, check_line)
                    if key in match_lookup:
                        original_match = match_lookup[key]
                        break
                if original_match:
                    break
            
            candidate = {
                "path": span.path,
                "start_line": span.start_line,
                "end_line": span.end_line,
                "content": span.text,  # Full span for Cerebras
            }
            
            # Add grep match data for BM42/FlashRank (CRITICAL for accuracy)
            if original_match:
                candidate["matched_text"] = original_match.matched_text
                candidate["context_before"] = original_match.context_before or ""
                candidate["context_after"] = original_match.context_after or ""
                candidate["line_number"] = original_match.line_number
                candidates.append(candidate)
            else:
                # Skip candidates where we can't find the original grep match
                # This ensures BM42/FlashRank get accurate data
                continue
        
        # STEP 4: Call GPU API for reranking (BM42 + FlashRank + Cerebras)
        try:
            response = self.client.post(
                "/v1/gpu-rerank",
                json={
                    "query": query,
                    "candidates": candidates,
                    "keywords": {
                        "primary_terms": keywords.get("primary_terms", []),
                        "search_terms": keywords.get("primary_terms", []),
                        "file_patterns": keywords.get("file_patterns", []),
                        "intent": keywords.get("intent", query)
                    },
                    "top_k": top_k
                }
            )
            response.raise_for_status()
            gpu_results = response.json()
            
        except httpx.HTTPStatusError as e:
            if e.response.status_code == 401:
                raise ValueError("Invalid API key")
            elif e.response.status_code == 402:
                raise ValueError("Insufficient credits. Add credits to continue.")
            elif e.response.status_code == 429:
                raise ValueError("Rate limit exceeded. Upgrade your plan for more requests.")
            else:
                raise ValueError(f"GPU rerank service error: {e}")
        except Exception as e:
            raise ValueError(f"Failed to call GPU rerank service: {e}")
        
        # STEP 5: Format results
        results = gpu_results.get("results", [])
        search_results = [
            SearchResult(
                path=result.get("path", "unknown"),
                score=result.get("score", 0.0),
                highlights=result.get("highlights", []),
                summary=result.get("highlights", [{}])[0].get("reason", "") if result.get("highlights") else None,
                start_line=result.get("start_line"),
                end_line=result.get("end_line"),
                content=result.get("content"),
                bm42_score=result.get("bm42_score")
            )
            for result in results
        ]
        
        execution_time = (time.time() - start_time) * 1000
        
        return SearchResponse(
            results=search_results,
            total_candidates=len(candidates),
            query=query,
            execution_time_ms=execution_time,
            overall_reasoning=results[0].get("overall_reasoning") if results else None
        )
    
    def _smart_deduplicate(
        self,
        candidates: List[CandidateMatch],
        keywords: List[str]
    ) -> List[CandidateMatch]:
        """
        Smart deduplication: one result per file per keyword.
        """
        from collections import defaultdict
        
        # Group candidates by file
        file_candidates = defaultdict(list)
        for candidate in candidates:
            file_candidates[candidate.path].append(candidate)
        
        result = []
        
        for file_path, file_cands in file_candidates.items():
            best_per_keyword = {}
            
            for candidate in file_cands:
                matched_text_lower = candidate.matched_text.lower()
                context_lower = (
                    (candidate.context_before or '') +
                    matched_text_lower +
                    (candidate.context_after or '')
                ).lower()
                
                # Find which keyword this candidate matches
                matched_keyword = None
                for kw in keywords:
                    if kw.lower() in context_lower:
                        if matched_keyword is None:
                            matched_keyword = kw
                
                if matched_keyword:
                    if matched_keyword not in best_per_keyword:
                        best_per_keyword[matched_keyword] = candidate
                    else:
                        # Prefer candidate with more context
                        existing = best_per_keyword[matched_keyword]
                        existing_context = len(existing.context_before or '') + len(existing.context_after or '')
                        new_context = len(candidate.context_before or '') + len(candidate.context_after or '')
                        if new_context > existing_context:
                            best_per_keyword[matched_keyword] = candidate
                else:
                    if 'no_keyword' not in best_per_keyword:
                        best_per_keyword['no_keyword'] = candidate
            
            # Deduplicate by checking for overlapping line ranges
            seen_ranges = []
            
            def ranges_overlap(s1, e1, s2, e2):
                return s1 <= e2 and s2 <= e1
            
            for keyword, candidate in best_per_keyword.items():
                start_line = candidate.line_number
                context_lines = len((candidate.context_after or '').split('\n')) if candidate.context_after else 0
                end_line = start_line + context_lines
                
                if any(ranges_overlap(start_line, end_line, s, e) for s, e in seen_ranges):
                    continue
                
                seen_ranges.append((start_line, end_line))
                result.append(candidate)
        
        return result
    
    def _select_best_search_terms(self, terms: List[str], n: int) -> List[str]:
        """
        Select best N search terms using quality scoring (like old implementation).
        No LLM calls - uses deterministic scoring.
        """
        scored_terms = []
        
        for term in terms:
            score = 0.0
            
            # Prefer longer, more specific terms
            score += min(len(term) / 20.0, 0.5)
            
            # Prefer terms with structure (camelCase, snake_case)
            if '_' in term or (term != term.lower() and term != term.upper()):
                score += 0.3
            
            # Prefer terms that look like identifiers
            if re.match(r'^[a-zA-Z_][a-zA-Z0-9_]*$', term):
                score += 0.2
            
            # Penalize very common words
            common_words = ['the', 'a', 'an', 'is', 'in', 'to', 'for', 'of', 'and', 'or']
            if term.lower() in common_words:
                score -= 0.8
            
            # Penalize very short terms
            if len(term) < 3:
                score -= 0.3
            
            scored_terms.append((term, score))
        
        # Sort by score and return top N
        scored_terms.sort(key=lambda x: x[1], reverse=True)
        return [term for term, score in scored_terms[:n] if score > 0]
    
    def _turn1_primary_search(
        self,
        search_terms: List[str],
        directory: str,
        file_patterns: Optional[List[str]],
        search_context: SearchContext
    ) -> List[CandidateMatch]:
        """
        Turn 1: Primary keyword search (parallel).
        Searches for the most important keywords first.
        """
        for term in search_terms:
            search_context.add_pattern(term)
        
        candidates = []
        with ThreadPoolExecutor(max_workers=self.parallel_per_turn) as executor:
            futures = []
            for term in search_terms:
                future = executor.submit(
                    self.grep_tool.search,
                    query=term,
                    directory=directory,
                    file_patterns=file_patterns,
                    case_sensitive=False,
                    context_lines=3
                )
                futures.append(future)
            
            for future in futures:
                try:
                    results = future.result(timeout=3)
                    candidates.extend(results)
                except Exception:
                    continue
        
        return candidates
    
    def _turn2_ast_references(
        self,
        previous_results: List[CandidateMatch],
        search_context: SearchContext,
        directory: str,
        file_patterns: Optional[List[str]]
    ) -> List[CandidateMatch]:
        """
        Turn 2: AST reference following (parallel).
        Analyzes top files from Turn 1 and searches for imports,
        function calls, and class references.
        """
        # Get top files from Turn 1
        top_files = search_context.get_high_quality_files(n=5)
        if not top_files:
            top_files = [r.path for r in previous_results[:5]]
        
        # Extract AST references from top files
        all_references: List[CodeReference] = []
        for file_path in top_files:
            try:
                refs = self.code_analyzer.extract_references_fast(file_path)
                all_references.extend(refs)
            except Exception:
                continue
        
        # Score and select top references
        top_refs = self._score_references(all_references, search_context)[:self.parallel_per_turn]
        
        candidates = []
        with ThreadPoolExecutor(max_workers=self.parallel_per_turn) as executor:
            futures = []
            
            for ref in top_refs:
                search_pattern = self._reference_to_search_pattern(ref)
                if search_pattern and not search_context.has_seen_pattern(search_pattern):
                    search_context.add_pattern(search_pattern)
                    future = executor.submit(
                        self.grep_tool.search,
                        query=search_pattern,
                        directory=directory,
                        file_patterns=file_patterns,
                        case_sensitive=False,
                        context_lines=3
                    )
                    futures.append(future)
            
            for future in futures:
                try:
                    results = future.result(timeout=3)
                    candidates.extend(results)
                except Exception:
                    continue
        
        return candidates
    
    def _score_references(
        self,
        references: List[CodeReference],
        search_context: SearchContext
    ) -> List[CodeReference]:
        """Score references by relevance, avoiding duplicates."""
        scored = []
        
        for ref in references:
            # Skip if we've already searched for this
            if search_context.has_seen_pattern(ref.name):
                continue
            
            score = ref.priority
            
            # Prefer longer names (more specific)
            score += min(len(ref.name) / 30.0, 0.15)
            
            scored.append((ref, score))
        
        # Sort by score
        scored.sort(key=lambda x: x[1], reverse=True)
        return [ref for ref, score in scored]
    
    def _reference_to_search_pattern(self, ref: CodeReference) -> Optional[str]:
        """Convert a code reference to a grep search pattern."""
        if ref.type == 'import':
            return ref.name
        elif ref.type == 'function_call':
            return f"def {ref.name}"
        elif ref.type == 'function_def':
            return f"{ref.name}("
        elif ref.type == 'class_def':
            return f"class {ref.name}"
        elif ref.type == 'identifier':
            return ref.name
        return None
    
    def chat(
        self,
        messages: List[Dict[str, str]],
        directory: Optional[str] = None,
        stream: bool = False
    ) -> Dict[str, Any] | Iterator[Dict[str, Any]]:
        """
        Use OpenAI-compatible chat completions with code search tools.
        
        Args:
            messages: List of message dicts with 'role' and 'content'
            directory: Working directory for code operations
            stream: Whether to stream the response
            
        Returns:
            Chat completion response or iterator if streaming
            
        Example:
            ```python
            response = client.chat(
                messages=[
                    {"role": "user", "content": "Find all API endpoints in the backend"}
                ],
                directory="./backend"
            )
            ```
        """
        payload = {
            "model": "greb",
            "messages": messages,
            "stream": stream
        }
        
        if directory:
            payload["metadata"] = {"directory": directory}
        
        if stream:
            return self._stream_chat(payload)
        else:
            response = self.client.post("/chat/completions", json=payload)
            response.raise_for_status()
            return response.json()
    
    def _stream_chat(self, payload: Dict[str, Any]) -> Iterator[Dict[str, Any]]:
        """Stream chat completion responses."""
        with self.client.stream("POST", "/chat/completions", json=payload) as response:
            response.raise_for_status()
            for line in response.iter_lines():
                if line.startswith("data: "):
                    data = line[6:]  # Remove "data: " prefix
                    if data.strip() != "[DONE]":
                        yield eval(data)  # Parse JSON
    
    def get_file(
        self,
        file_path: str,
        start_line: Optional[int] = None,
        end_line: Optional[int] = None
    ) -> Dict[str, Any]:
        """
        Get file content with optional line range.
        
        Args:
            file_path: Path to the file
            start_line: Starting line number (1-indexed)
            end_line: Ending line number (inclusive)
            
        Returns:
            File content and metadata
        """
        params = {"file_path": file_path}
        if start_line is not None:
            params["start_line"] = start_line
        if end_line is not None:
            params["end_line"] = end_line
        
        response = self.client.get("/file", params=params)
        response.raise_for_status()
        return response.json()
    
    def get_usage(self) -> Dict[str, Any]:
        """
        Get current API usage statistics.
        
        Returns:
            Usage statistics including requests, tokens, and credits
        """
        response = self.client.get("/usage")
        response.raise_for_status()
        return response.json()
    
    def health_check(self) -> Dict[str, Any]:
        """Check API health status."""
        response = self.client.get("/health")
        response.raise_for_status()
        return response.json()
    
    def close(self):
        """Close the HTTP client."""
        self.client.close()
    
    def __enter__(self):
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()


class AsyncGrebClient:
    """
    Async Python client for Greb API.
    
    Usage:
        ```python
        from greb import AsyncGrebClient
        
        async with AsyncGrebClient(api_key="grb_your_key") as client:
            results = await client.search(
                query="Find authentication logic",
                directory="./src"
            )
        ```
    """
    
    def __init__(
        self,
        api_key: Optional[str] = None,
        base_url: Optional[str] = None,
        timeout: int = 60,
        max_retries: int = 3
    ):
        self.api_key = api_key or os.getenv("GREB_API_KEY")
        if not self.api_key:
            raise ValueError(
                "API key is required. Set GREB_API_KEY environment variable "
                "or pass api_key parameter."
            )
        
        self.base_url = base_url or os.getenv("GREB_API_URL")
        if not self.base_url:
            raise ValueError(
                "API base URL is required. Set GREB_API_URL environment variable "
                "or pass base_url parameter."
            )
        
        self.timeout = timeout
        self.max_retries = max_retries
        
        self.client = httpx.AsyncClient(
            base_url=self.base_url,
            timeout=timeout,
            headers={
                "Authorization": f"Bearer {self.api_key}",
                "Content-Type": "application/json",
                "User-Agent": "swe-grep-python/1.0.0"
            }
        )
    
    async def search(
        self,
        query: str,
        directory: Optional[str] = None,
        file_patterns: Optional[List[str]] = None,
        max_results: Optional[int] = None
    ) -> SearchResponse:
        """Async version of search."""
        request = SearchRequest(
            query=query,
            directory=directory,
            file_patterns=file_patterns,
            max_results=max_results
        )
        
        response = await self.client.post(
            "/search",
            json=request.model_dump(exclude_none=True)
        )
        response.raise_for_status()
        
        return SearchResponse(**response.json())
    
    async def chat(
        self,
        messages: List[Dict[str, str]],
        directory: Optional[str] = None,
        stream: bool = False
    ):
        """Async version of chat."""
        payload = {
            "model": "greb",
            "messages": messages,
            "stream": stream
        }
        
        if directory:
            payload["metadata"] = {"directory": directory}
        
        if stream:
            return self._stream_chat(payload)
        else:
            response = await self.client.post("/chat/completions", json=payload)
            response.raise_for_status()
            return response.json()
    
    async def _stream_chat(self, payload: Dict[str, Any]):
        """Stream chat completion responses asynchronously."""
        async with self.client.stream("POST", "/chat/completions", json=payload) as response:
            response.raise_for_status()
            async for line in response.aiter_lines():
                if line.startswith("data: "):
                    data = line[6:]
                    if data.strip() != "[DONE]":
                        yield eval(data)
    
    async def get_file(
        self,
        file_path: str,
        start_line: Optional[int] = None,
        end_line: Optional[int] = None
    ) -> Dict[str, Any]:
        """Async version of get_file."""
        params = {"file_path": file_path}
        if start_line is not None:
            params["start_line"] = start_line
        if end_line is not None:
            params["end_line"] = end_line
        
        response = await self.client.get("/file", params=params)
        response.raise_for_status()
        return response.json()
    
    async def get_usage(self) -> Dict[str, Any]:
        """Async version of get_usage."""
        response = await self.client.get("/usage")
        response.raise_for_status()
        return response.json()
    
    async def health_check(self) -> Dict[str, Any]:
        """Async version of health_check."""
        response = await self.client.get("/health")
        response.raise_for_status()
        return response.json()
    
    async def close(self):
        """Close the async HTTP client."""
        await self.client.aclose()
    
    async def __aenter__(self):
        return self
    
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        await self.close()


# Convenience exports
__all__ = [
    "GrebClient",
    "AsyncGrebClient",
    "SearchRequest",
    "SearchResponse",
    "SearchResult",
    "ClientConfig",
]
