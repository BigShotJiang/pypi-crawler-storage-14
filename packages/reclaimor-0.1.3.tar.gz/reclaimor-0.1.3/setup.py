from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="reclaimor",
    version="0.1.3",
    author="Lakshmikanthan",
    author_email="",
    description="Advanced subdomain takeover reconnaissance & safe-vulnerability-detection",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/letchupkt/ReClaimor",
    packages=find_packages(),
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Information Technology",
        "Topic :: Security",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
    ],
    python_requires=">=3.10",
    install_requires=[
        "aiohttp>=3.9.0",
        "aiodns>=3.1.0",
        "rich>=13.7.0",
        "pyyaml>=6.0",
        "click>=8.1.0",
        "tqdm>=4.66.0",
        "dnspython>=2.4.0",
        "certifi>=2023.0.0",
        "colorama>=0.4.6",
    ],
    extras_require={
        "dev": [
            "pytest>=7.4.0",
            "pytest-asyncio>=0.21.0",
            "pytest-cov>=4.1.0",
            "black>=23.0.0",
            "flake8>=6.1.0",
            "mypy>=1.5.0",
            "ruff>=0.1.0",
        ],
    },
    entry_points={
        "console_scripts": [
            "reclaimor=reclaimor.cli:main",
        ],
    },
    include_package_data=True,
    package_data={
        "reclaimor": ["fingerprints/*.json", "templates/*.html"],
    },
)
