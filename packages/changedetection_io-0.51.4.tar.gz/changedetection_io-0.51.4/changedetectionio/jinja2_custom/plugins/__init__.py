"""
Jinja2 custom filter plugins for changedetection.io
"""
from .regex import regex_replace

__all__ = ['regex_replace']
