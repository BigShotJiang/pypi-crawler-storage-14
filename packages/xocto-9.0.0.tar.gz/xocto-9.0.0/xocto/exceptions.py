class SettlementPeriodError(Exception):
    """
    Basic exception raised while converting tz-aware datetime.
    """
