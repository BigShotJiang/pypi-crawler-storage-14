"""Copy of oj-verify
"""
