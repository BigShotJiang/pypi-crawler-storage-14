from decimal import Decimal
from typing import List, Optional

def find_least_price(prices: List[dict], key_name: Optional[str] = 'price') -> dict:

    if not prices:
        raise ValueError("Input array of prices cannot be empty.")

    return min(prices, key=lambda item: item[key_name])
