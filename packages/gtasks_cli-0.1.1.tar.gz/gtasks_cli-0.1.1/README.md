# Google Tasks CLI

A powerful, feature-rich CLI application for Google Tasks management in Python.

## Features

- Full Google Tasks API integration with OAuth2 authentication
- Advanced filtering and search capabilities
- Context management for different task views
- Reporting and analytics
- Time tracking and Pomodoro technique integration
- Recurring tasks and dependencies
- Offline mode with synchronization
- Import/export functionality
- [Optimized Advanced Sync](../ADVANCED_SYNC_OPTIMIZATION.md) for improved performance

## Installation

### From PyPI (Recommended)

The easiest way to install Google Tasks CLI is from PyPI:

```bash
pip install gtasks-cli
```

### Manual Installation

```bash
pip install -r requirements.txt
```

## Usage

After installing from PyPI:
```bash
gtasks --help
```

During development:
```bash
python -m gtasks_cli.main --help
```

Or after installation in development mode:

```bash
gtasks --help
```

## Development

This project follows a modular architecture with clear separation of concerns:
- **CLI Layer**: Command-line interface using Click framework
- **Core Layer**: Business logic for task and tasklist management
- **Integration Layer**: Google Tasks API integration and authentication
- **Storage Layer**: Local caching and configuration management
- **Reporting Layer**: Analytics and reporting functionality

### Building and Publishing

For information on building and publishing the package to PyPI, see [PYPI_UPLOAD.md](PYPI_UPLOAD.md).

## License

MIT