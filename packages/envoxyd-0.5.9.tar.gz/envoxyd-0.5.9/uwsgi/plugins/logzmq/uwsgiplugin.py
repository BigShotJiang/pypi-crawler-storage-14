
NAME='logzmq'
CFLAGS = []
LDFLAGS = []
LIBS = ['-lzmq']

GCC_LIST = ['plugin']
