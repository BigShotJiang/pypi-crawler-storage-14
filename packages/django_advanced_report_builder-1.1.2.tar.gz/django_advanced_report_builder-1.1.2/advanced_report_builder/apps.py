from django.apps import AppConfig


class AdvancedReportBuilderConfig(AppConfig):
    default_auto_field = 'django.db.models.AutoField'
    name = 'advanced_report_builder'
    verbose_name = 'Advanced Report builder'
