from django.dispatch import Signal

model_report_save = Signal()
