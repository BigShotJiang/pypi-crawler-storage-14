"""
Sufi AI - Unlimited Free LLM Chat
"""

__version__ = "1.0.3"

import requests

def chat(message, api_key="SufiLLM-33990wAGjPP6PpdPm2iApi"):
    url = "https://sufi-api-llm.vercel.app/v1/chat/completions"
    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json"
    }
    data = {
        "messages": [{"role": "user", "content": message}]
    }
    
    try:
        r = requests.post(url, headers=headers, json=data)
        r.raise_for_status()
        return r.json()["choices"][0]["message"]["content"]
    except Exception as e:
        return f"Error: {str(e)}"

# For direct script execution
if __name__ == "__main__":
    while True:
        msg = input("You: ")
        if msg.lower() in ["exit", "quit", "bye"]:
            break
        print("Sufi AI:", chat(msg))
        print("-" * 50)