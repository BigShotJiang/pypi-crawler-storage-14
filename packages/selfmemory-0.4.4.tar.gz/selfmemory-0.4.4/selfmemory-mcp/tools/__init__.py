"""ChatGPT-compatible MCP tools for SelfMemory."""
