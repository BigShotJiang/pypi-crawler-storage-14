"""
Embedding configurations.
"""

from .ollama import OllamaConfig

__all__ = [
    "OllamaConfig",
]
