# Wetraffic SDK

[![Documentation](https://img.shields.io/badge/docs-latest-blue.svg)](https://wetraffic-sdk-docs.s3-website-us-east-1.amazonaws.com)
[![PyPI version](https://badge.fury.io/py/wetraffic-sdk.svg)](https://badge.fury.io/py/wetraffic-sdk)
[![License](https://img.shields.io/pypi/l/wetraffic-sdk.svg)](https://github.com/trafficlabsrl/wetraffic-sdk/blob/main/LICENSE)
![Coverage](coverage.svg)
