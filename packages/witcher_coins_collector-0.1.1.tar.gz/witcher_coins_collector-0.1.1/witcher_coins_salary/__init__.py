
"""The Witcher Salary Calculator - Calculate coin payment for a witcher"""

from .calculator import coin_claim, print_greeting, main

__version__ = "0.1.0"
__all__ = ["coin_claim", "print_greeting", "main"]