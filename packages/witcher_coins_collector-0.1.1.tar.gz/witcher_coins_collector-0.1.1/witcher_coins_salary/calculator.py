# заплатите ведьмаку чеканной монетой

def print_greeting():
    """Приветствие ведьмака"""
    print("The Witcher has come to the village to kill the monster. What will you offer?")


def coin_claim():
    """Рассчитывает минимальное количество монет для оплаты ведьмаку"""

    # Номиналы монет
    cooper__small = 1
    cooper__large = 5
    silver = 10
    golden = 25

    golden_coin = 0
    silver_coin = 0
    copper_coin = 0
    coin_total = 0

    num = int(input("Enter the amount of money you want to pay: "))

    # Считаем золотые монеты
    while num >= golden:
        coin_total += 1
        golden_coin += 1
        num = num - golden

    # Считаем серебряные монеты
    while num >= silver:
        coin_total += 1
        silver_coin += 1
        num = num - silver

    # Считаем медные монеты
    while num >= cooper__large:
        coin_total += 1
        copper_coin += 1
        num = num - cooper__large

    while num >= cooper__small:
        coin_total += 1
        copper_coin += 1
        num = num - cooper__small

    print(f"\n--- Payment Summary ---")
    print(f"Total coins: {coin_total}")
    print(f"Golden coins: {golden_coin}")
    print(f"Silver coins: {silver_coin}")
    print(f"Copper coins: {copper_coin}")
    print(f"The Witcher accepts your payment! 🗡️")


def main():
    """Главная функция"""
    print_greeting()
    coin_claim()


if __name__ == "__main__":
    main()