#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Model components for node_fdm, including training and production wrappers."""
