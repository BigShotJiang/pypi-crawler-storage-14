#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Package initialization for node_fdm utilities and models."""
