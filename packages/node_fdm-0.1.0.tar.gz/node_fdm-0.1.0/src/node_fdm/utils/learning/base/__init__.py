#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Base learning building blocks: MLP blocks, normalizers, and structured layers."""
