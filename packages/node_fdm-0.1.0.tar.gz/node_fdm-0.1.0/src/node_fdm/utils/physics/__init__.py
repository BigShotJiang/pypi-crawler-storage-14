#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Physics utilities for atmospheric and flight dynamics calculations."""
