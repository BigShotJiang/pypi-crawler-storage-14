#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Initialization for the QAR architecture package."""
