#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Initialization for the OpenSky 2025 architecture package."""
