# Model wrappers

::: node_fdm.models.flight_dynamics_model
    options:
      show_root_heading: true
      show_root_full_path: false
      show_source: true

::: node_fdm.models.batch_neural_ode
    options:
      show_root_heading: true
      show_root_full_path: false
      show_source: true

::: node_fdm.models.flight_dynamics_model_prod
    options:
      show_root_heading: true
      show_root_full_path: false
      show_source: true
