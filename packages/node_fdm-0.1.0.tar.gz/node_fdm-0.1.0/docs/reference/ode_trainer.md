# ODE trainer

::: node_fdm.ode_trainer
    options:
      show_root_heading: true
      show_root_full_path: false
      show_source: true
