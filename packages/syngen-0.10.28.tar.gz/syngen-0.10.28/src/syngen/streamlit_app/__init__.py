from syngen.streamlit_app.start import start  # noqa: F401
