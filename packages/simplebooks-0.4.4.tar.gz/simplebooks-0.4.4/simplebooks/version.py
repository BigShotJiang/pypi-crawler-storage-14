
__version__ = '0.4.4'

def version() -> str:
    """Return the library version."""
    return __version__
