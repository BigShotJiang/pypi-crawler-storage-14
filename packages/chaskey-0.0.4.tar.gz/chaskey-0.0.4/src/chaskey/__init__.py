"""Pure python Chaskey-LTS cipher implementation."""

# convenience for importing purposes
from chaskey.chaskey import Chaskey  # noqa: F401
