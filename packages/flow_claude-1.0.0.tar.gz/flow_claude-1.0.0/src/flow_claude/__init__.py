"""Flow-Claude: Git-driven autonomous development system using Claude agent SDK."""

__version__ = "0.1.0"
