python -m flow_claude.commands.toggle_auto 
