import json
import os
import pathlib
import shutil

from utils.pretty_print import print_ok, print_warning
from utils.str_tools import clean_string, remove_unwanted_from_name


class Element:
    def __init__(self, path: pathlib.Path):
        self.path = path
        self.name = path.name
        self.first_level_directory_inside_root = [
            el.name for el in path.parents if len(el.parts) == 2
        ][0]

    @property
    def name_without_extension(self) -> str:
        return self.path.stem

    def get_theme_name(self) -> str:
        return self.path.parent.parts[-1].split("_")[0].lower() + "_" + self.name

    def get_theme_tag(self) -> str:
        theme_name = self.get_theme_name().split(".")[0]
        return (
            theme_name.split("_")[0].capitalize()
            + " - "
            + " ".join(theme_name.split("_")[1:]).capitalize()
        )

    def has_extension(self, extension: str) -> bool:
        """Method to check if the element is a file of a given extension.
        Please note that this check is made on the file extension only, does not inspect the file content.

        Args:
            extension (str): The file extension to check against, whithout the point.
            For example, 'png' for PNG files.

        Returns:
            bool: True if the element is a file and has the specified extension, False otherwise.
        """
        return self.path.is_file() and self.path.suffix == "." + extension

    @staticmethod
    def clean_string(
        base_string: str, is_folder: bool = False, ignore: list[str] | None = None
    ) -> str:
        """Clean the name.

        Args:
            ignore (list[str]): List of unwanted parts to remove from the name.

        Returns:
            str: the cleaned name.
        """
        cleaned_string = clean_string(base_string, is_folder=is_folder)
        if ignore is not None:
            cleaned_string = remove_unwanted_from_name(cleaned_string, ignore)
        return cleaned_string

    def copy(
        self,
        output_path: pathlib.Path,
    ):
        shutil.copyfile(
            self.path,
            output_path,
        )
        print_ok("Processed " + self.name)

    def __str__(self):
        return f"Element(name={self.name}, path={self.path})"


def go_through_fs_tree(
    full_path: pathlib.Path, output_path: pathlib.Path
) -> list[Element]:
    element_list = []
    for item in os.listdir(full_path):
        item_path = pathlib.Path(full_path) / item
        if os.path.isfile(item_path):
            if item.startswith("."):
                print_warning(
                    f"Skipping hidden file: {'/'.join(str(item_path).split('/')[-3:])}"
                )
                continue
            element_list.append(Element(item_path))

        elif os.path.isdir(item_path):
            element_list.extend(
                go_through_fs_tree(
                    full_path=item_path,
                    output_path=output_path,
                )
            )

    return element_list


class ThemeElement:
    def __init__(
        self,
        tag: str | None = None,
        stroke: str | None = None,
        color: str | None = None,
        icon: str | None = None,
    ):
        self.tag = tag
        self.stroke = stroke
        self.color = color
        self.icon = icon

    def as_dict(self) -> dict:
        dict_representation = {}
        for attribute, value in self.__dict__.items():
            if value is not None:
                dict_representation[attribute] = value
        return {
            "tag": self.tag,
            "stroke": self.stroke,
            "color": self.color,
            "icon": self.icon,
        }


class Theme:
    def __init__(self, name: str, description: str):
        self.name = name
        self.description = description
        self.elements: list[ThemeElement] = []

    def add_element(self, element: ThemeElement):
        self.elements.append(element)

    def create(self, path: pathlib.Path):
        json_dict = {
            "name": self.name,
            "description": self.description,
            "elements": [element.as_dict() for element in self.elements],
        }

        with open(path, "w") as f:
            json.dump(json_dict, f, indent=4)
