import click

import src.commands as commands


@click.group()
def stc():
    """Entrypoint for the CLI."""


stc.add_command(commands.clean)
stc.add_command(commands.create)


if __name__ == "__main__":
    stc()
