from juturna.utils.proc_utils._trx_utils import rescale_trx_words


__all__ = [
    'rescale_trx_words'
]