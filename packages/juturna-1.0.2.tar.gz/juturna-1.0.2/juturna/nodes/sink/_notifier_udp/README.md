# notifier_udp

## Node type: sink

## Node class name: NotifierUDP

## Node name: notifier_udp

