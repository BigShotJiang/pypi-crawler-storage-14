# video_file

## Node type: source

## Node class name: VideoFile

## Node name: video_file

