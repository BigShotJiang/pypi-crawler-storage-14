# json_http

Spawn a minimal HTTP server listening for incoming `POST` requests on a
configurable endpoint.

## Node type: source

## Node class name: JsonHttp

## Node name: json_http

