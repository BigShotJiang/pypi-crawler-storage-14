# json_websocket

Start a websocket server to receive object data.

The node implements a minimal websocket server, capable of receiving byte data
that are then converted into objects. The node produces messages containing
`ObjectPayload` payloads by copying all the keys in the received objects.

## Node type: source

## Node class name: JsonWebsocket

## Node name: json_websocket

