from setuptools import Extension
from setuptools import setup

setup(
    name='zig-zon',
    packages=[],
    zig_build={
        # tries to import 'ziglang' to get a zig compiler when building wheel
        "use_ziglang_python_package": True,
        # passes -Doptimize= to zig build
        "optimize": "ReleaseSmall",
        # passes -Dversion=<pip package version> to zig build
        "pass_version_option": True,
        'test_step': 'test',
        # extra arguments to zig build
        'extra_args': [],
    },
    ext_modules=[Extension('zig_zon', [])],
)
