::: mkdocs-click
    :module: dda.cli
    :command: dda
    :depth: 0
    :style: table
    :remove_ascii_art: true
