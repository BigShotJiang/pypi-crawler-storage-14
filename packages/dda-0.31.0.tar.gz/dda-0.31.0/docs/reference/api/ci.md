# CI utilities reference

-----

::: dda.utils.ci.running_in_ci
