"""
EventImpact Repository - Repository for event performance tracking.
"""

from typing import Optional, List, Dict, Any
from datetime import datetime, timedelta, timezone
from sqlalchemy import select, and_, func
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.exc import SQLAlchemyError
import logging
import uuid
from prisma_web3_py.utils.datetime import utc_now_naive

from ..models.event_impacts import EventImpacts
from .base_repository import BaseRepository

logger = logging.getLogger(__name__)


class EventImpactRepository(BaseRepository[EventImpacts]):
    """
    Event Impact Repository

    Provides interface for creating, updating, and querying event impact records
    for post-event analysis and strategy iteration.
    """

    def __init__(self):
        super().__init__(EventImpacts)

    # ========== CREATE METHODS ==========

    async def create_snapshot(
        self,
        session: AsyncSession,
        source_type: str,
        source_id: str,
        symbol: str,
        priority: str = 'medium',
        snapshot_config: Optional[Dict] = None,
        prices: Optional[Dict[str, float]] = None,
        meta: Optional[Dict] = None
    ) -> Optional[EventImpacts]:
        """
        Create a new event impact snapshot.

        Args:
            session: Database session
            source_type: Event source type ('news', 'twitter', 'manual')
            source_id: Reference ID to CryptoNews or AIAnalysisResult
            symbol: Main token symbol (will be uppercased)
            priority: Event priority ('critical', 'high', 'medium', 'low')
            snapshot_config: Sampling windows configuration
            prices: Initial prices dict {'t0': price, '30m': price, ...}
            meta: Additional context metadata

        Returns:
            Created EventImpacts object or None
        """
        try:
            if snapshot_config is None:
                snapshot_config = {
                    "t0": "event_time",
                    "t30m": 1800,  # 30 minutes in seconds
                    "t4h": 14400,   # 4 hours in seconds
                    "t24h": 86400   # 24 hours in seconds
                }

            if prices is None:
                prices = {}

            if meta is None:
                meta = {}

            # Normalize symbol to uppercase
            normalized_symbol = symbol.strip().upper()

            # Calculate changes if we have prices
            price_t0 = prices.get('t0')
            price_30m = prices.get('30m')
            price_4h = prices.get('4h')
            price_24h = prices.get('24h')

            change_30m = None
            change_4h = None
            change_24h = None

            if price_t0 and price_t0 > 0:
                if price_30m:
                    change_30m = (price_30m - price_t0) / price_t0
                if price_4h:
                    change_4h = (price_4h - price_t0) / price_t0
                if price_24h:
                    change_24h = (price_24h - price_t0) / price_t0

            impact = EventImpacts(
                source_type=source_type,
                source_id=source_id,
                symbol=normalized_symbol,
                priority=priority,
                snapshot_config=snapshot_config,
                price_t0=price_t0,
                price_30m=price_30m,
                price_4h=price_4h,
                price_24h=price_24h,
                change_30m=change_30m,
                change_4h=change_4h,
                change_24h=change_24h,
                vol_30m=prices.get('vol_30m'),
                meta=meta
            )

            session.add(impact)
            await session.flush()
            await session.refresh(impact)
            logger.debug(f"Created event impact: ID={impact.id}, symbol={symbol}, priority={priority}")
            return impact

        except SQLAlchemyError as e:
            logger.error(f"Error creating event impact snapshot: {e}")
            return None

    # ========== UPDATE METHODS ==========

    async def update_snapshot(
        self,
        session: AsyncSession,
        impact_id: uuid.UUID,
        new_prices: Dict[str, float],
        recalculate: bool = True
    ) -> Optional[EventImpacts]:
        """
        Update event impact snapshot with new price data.

        Used for backfilling +4h, +24h prices after event occurs.

        Args:
            session: Database session
            impact_id: EventImpacts UUID
            new_prices: New prices dict {'30m': price, '4h': price, '24h': price}
            recalculate: Whether to recalculate change percentages

        Returns:
            Updated EventImpacts object or None
        """
        try:
            stmt = select(EventImpacts).where(EventImpacts.id == impact_id)
            result = await session.execute(stmt)
            impact = result.scalar_one_or_none()

            if not impact:
                logger.warning(f"Event impact not found: {impact_id}")
                return None

            # Update prices
            if '30m' in new_prices:
                impact.price_30m = new_prices['30m']
            if '4h' in new_prices:
                impact.price_4h = new_prices['4h']
            if '24h' in new_prices:
                impact.price_24h = new_prices['24h']
            if 'vol_30m' in new_prices:
                impact.vol_30m = new_prices['vol_30m']

            # Recalculate changes
            if recalculate and impact.price_t0 and impact.price_t0 > 0:
                if impact.price_30m:
                    impact.change_30m = (float(impact.price_30m) - float(impact.price_t0)) / float(impact.price_t0)
                if impact.price_4h:
                    impact.change_4h = (float(impact.price_4h) - float(impact.price_t0)) / float(impact.price_t0)
                if impact.price_24h:
                    impact.change_24h = (float(impact.price_24h) - float(impact.price_t0)) / float(impact.price_t0)

            impact.updated_at = utc_now_naive()

            await session.flush()
            await session.refresh(impact)
            logger.debug(f"Updated event impact: ID={impact_id}")
            return impact

        except SQLAlchemyError as e:
            logger.error(f"Error updating event impact snapshot: {e}")
            return None

    async def update_meta(
        self,
        session: AsyncSession,
        impact_id: uuid.UUID,
        meta_update: Dict[str, Any]
    ) -> bool:
        """
        Update meta field of an event impact.

        Args:
            session: Database session
            impact_id: EventImpacts UUID
            meta_update: Dict to merge into meta field

        Returns:
            Success status
        """
        try:
            stmt = select(EventImpacts).where(EventImpacts.id == impact_id)
            result = await session.execute(stmt)
            impact = result.scalar_one_or_none()

            if not impact:
                return False

            # Merge meta
            current_meta = impact.meta or {}
            current_meta.update(meta_update)
            impact.meta = current_meta
            impact.updated_at = utc_now_naive()

            await session.flush()
            logger.debug(f"Updated event impact meta: ID={impact_id}")
            return True

        except SQLAlchemyError as e:
            logger.error(f"Error updating event impact meta: {e}")
            return False

    # ========== QUERY METHODS ==========

    async def get_by_id(
        self,
        session: AsyncSession,
        impact_id: uuid.UUID
    ) -> Optional[EventImpacts]:
        """
        Get event impact by UUID.

        Args:
            session: Database session
            impact_id: EventImpacts UUID

        Returns:
            EventImpacts or None
        """
        try:
            stmt = select(EventImpacts).where(EventImpacts.id == impact_id)
            result = await session.execute(stmt)
            return result.scalar_one_or_none()
        except SQLAlchemyError as e:
            logger.error(f"Error getting event impact by ID: {e}")
            return None

    async def get_by_source(
        self,
        session: AsyncSession,
        source_type: str,
        source_id: str
    ) -> Optional[EventImpacts]:
        """
        Get event impact by source reference.

        Args:
            session: Database session
            source_type: Source type ('news', 'twitter', 'manual')
            source_id: Source ID

        Returns:
            EventImpacts or None
        """
        try:
            stmt = select(EventImpacts).where(
                and_(
                    EventImpacts.source_type == source_type,
                    EventImpacts.source_id == source_id
                )
            )
            result = await session.execute(stmt)
            return result.scalar_one_or_none()
        except SQLAlchemyError as e:
            logger.error(f"Error getting event impact by source: {e}")
            return None

    async def list_by_priority(
        self,
        session: AsyncSession,
        priority: str,
        begin: Optional[datetime] = None,
        end: Optional[datetime] = None,
        limit: int = 100
    ) -> List[EventImpacts]:
        """
        List event impacts by priority within a time range.

        Used for generating priority-based reports.

        Args:
            session: Database session
            priority: Priority level ('critical', 'high', 'medium', 'low')
            begin: Start time (optional)
            end: End time (optional)
            limit: Result limit

        Returns:
            List of EventImpacts
        """
        try:
            stmt = select(EventImpacts).where(EventImpacts.priority == priority)

            if begin:
                stmt = stmt.where(EventImpacts.created_at >= begin)
            if end:
                stmt = stmt.where(EventImpacts.created_at <= end)

            stmt = stmt.order_by(EventImpacts.created_at.desc()).limit(limit)

            result = await session.execute(stmt)
            return list(result.scalars().all())

        except SQLAlchemyError as e:
            logger.error(f"Error listing impacts by priority: {e}")
            return []

    async def list_by_symbol(
        self,
        session: AsyncSession,
        symbol: str,
        hours: Optional[int] = None,
        limit: int = 50
    ) -> List[EventImpacts]:
        """
        List event impacts for a specific token.

        Args:
            session: Database session
            symbol: Token symbol
            hours: Optional time range in hours
            limit: Result limit

        Returns:
            List of EventImpacts
        """
        try:
            normalized_symbol = symbol.strip().upper()
            stmt = select(EventImpacts).where(EventImpacts.symbol == normalized_symbol)

            if hours:
                since = utc_now_naive() - timedelta(hours=hours)
                stmt = stmt.where(EventImpacts.created_at >= since)

            stmt = stmt.order_by(EventImpacts.created_at.desc()).limit(limit)

            result = await session.execute(stmt)
            return list(result.scalars().all())

        except SQLAlchemyError as e:
            logger.error(f"Error listing impacts by symbol: {e}")
            return []

    async def get_pending_updates(
        self,
        session: AsyncSession,
        window: str = '24h',
        limit: int = 100
    ) -> List[EventImpacts]:
        """
        Get event impacts that need price updates.

        Finds records where the time window has passed but price is not yet recorded.

        Args:
            session: Database session
            window: Time window to check ('30m', '4h', '24h')
            limit: Result limit

        Returns:
            List of EventImpacts pending updates
        """
        try:
            # Calculate time threshold based on window
            window_seconds = {
                '30m': 1800,
                '4h': 14400,
                '24h': 86400
            }.get(window, 86400)

            threshold = utc_now_naive() - timedelta(seconds=window_seconds)

            # Build query based on window
            if window == '30m':
                stmt = select(EventImpacts).where(
                    and_(
                        EventImpacts.created_at <= threshold,
                        EventImpacts.price_30m.is_(None),
                        EventImpacts.price_t0.isnot(None)
                    )
                )
            elif window == '4h':
                stmt = select(EventImpacts).where(
                    and_(
                        EventImpacts.created_at <= threshold,
                        EventImpacts.price_4h.is_(None),
                        EventImpacts.price_t0.isnot(None)
                    )
                )
            else:  # 24h
                stmt = select(EventImpacts).where(
                    and_(
                        EventImpacts.created_at <= threshold,
                        EventImpacts.price_24h.is_(None),
                        EventImpacts.price_t0.isnot(None)
                    )
                )

            stmt = stmt.order_by(EventImpacts.created_at.asc()).limit(limit)

            result = await session.execute(stmt)
            return list(result.scalars().all())

        except SQLAlchemyError as e:
            logger.error(f"Error getting pending updates: {e}")
            return []

    # ========== STATISTICS METHODS ==========

    async def get_impact_summary(
        self,
        session: AsyncSession,
        priority: Optional[str] = None,
        hours: Optional[int] = None
    ) -> Dict[str, Any]:
        """
        Get impact statistics summary.

        Args:
            session: Database session
            priority: Optional priority filter
            hours: Optional time range in hours

        Returns:
            Summary statistics dict
        """
        try:
            stmt = select(EventImpacts)

            if priority:
                stmt = stmt.where(EventImpacts.priority == priority)

            if hours:
                since = utc_now_naive() - timedelta(hours=hours)
                stmt = stmt.where(EventImpacts.created_at >= since)

            result = await session.execute(stmt)
            impacts = list(result.scalars().all())

            if not impacts:
                return {
                    'total': 0,
                    'by_priority': {},
                    'by_symbol': {},
                    'avg_change_30m': None,
                    'avg_change_4h': None,
                    'avg_change_24h': None
                }

            # Calculate statistics
            total = len(impacts)

            # Count by priority
            by_priority = {}
            for impact in impacts:
                by_priority[impact.priority] = by_priority.get(impact.priority, 0) + 1

            # Count by symbol
            by_symbol = {}
            for impact in impacts:
                by_symbol[impact.symbol] = by_symbol.get(impact.symbol, 0) + 1

            # Average changes
            changes_30m = [float(i.change_30m) for i in impacts if i.change_30m is not None]
            changes_4h = [float(i.change_4h) for i in impacts if i.change_4h is not None]
            changes_24h = [float(i.change_24h) for i in impacts if i.change_24h is not None]

            return {
                'total': total,
                'by_priority': by_priority,
                'by_symbol': by_symbol,
                'avg_change_30m': sum(changes_30m) / len(changes_30m) if changes_30m else None,
                'avg_change_4h': sum(changes_4h) / len(changes_4h) if changes_4h else None,
                'avg_change_24h': sum(changes_24h) / len(changes_24h) if changes_24h else None,
                'positive_30m': len([c for c in changes_30m if c > 0]),
                'negative_30m': len([c for c in changes_30m if c < 0]),
                'positive_4h': len([c for c in changes_4h if c > 0]),
                'negative_4h': len([c for c in changes_4h if c < 0]),
                'positive_24h': len([c for c in changes_24h if c > 0]),
                'negative_24h': len([c for c in changes_24h if c < 0]),
            }

        except SQLAlchemyError as e:
            logger.error(f"Error getting impact summary: {e}")
            return {'total': 0, 'by_priority': {}, 'by_symbol': {}}

    async def get_top_performers(
        self,
        session: AsyncSession,
        window: str = '4h',
        priority: Optional[str] = None,
        hours: Optional[int] = None,
        limit: int = 20
    ) -> List[EventImpacts]:
        """
        Get top performing events by price change.

        Args:
            session: Database session
            window: Time window ('30m', '4h', '24h')
            priority: Optional priority filter
            hours: Optional time range in hours
            limit: Result limit

        Returns:
            List of top performing EventImpacts
        """
        try:
            # Select appropriate change field
            change_field = {
                '30m': EventImpacts.change_30m,
                '4h': EventImpacts.change_4h,
                '24h': EventImpacts.change_24h
            }.get(window, EventImpacts.change_4h)

            stmt = select(EventImpacts).where(change_field.isnot(None))

            if priority:
                stmt = stmt.where(EventImpacts.priority == priority)

            if hours:
                since = utc_now_naive() - timedelta(hours=hours)
                stmt = stmt.where(EventImpacts.created_at >= since)

            stmt = stmt.order_by(change_field.desc()).limit(limit)

            result = await session.execute(stmt)
            return list(result.scalars().all())

        except SQLAlchemyError as e:
            logger.error(f"Error getting top performers: {e}")
            return []

    async def get_worst_performers(
        self,
        session: AsyncSession,
        window: str = '4h',
        priority: Optional[str] = None,
        hours: Optional[int] = None,
        limit: int = 20
    ) -> List[EventImpacts]:
        """
        Get worst performing events by price change.

        Args:
            session: Database session
            window: Time window ('30m', '4h', '24h')
            priority: Optional priority filter
            hours: Optional time range in hours
            limit: Result limit

        Returns:
            List of worst performing EventImpacts
        """
        try:
            # Select appropriate change field
            change_field = {
                '30m': EventImpacts.change_30m,
                '4h': EventImpacts.change_4h,
                '24h': EventImpacts.change_24h
            }.get(window, EventImpacts.change_4h)

            stmt = select(EventImpacts).where(change_field.isnot(None))

            if priority:
                stmt = stmt.where(EventImpacts.priority == priority)

            if hours:
                since = utc_now_naive() - timedelta(hours=hours)
                stmt = stmt.where(EventImpacts.created_at >= since)

            stmt = stmt.order_by(change_field.asc()).limit(limit)

            result = await session.execute(stmt)
            return list(result.scalars().all())

        except SQLAlchemyError as e:
            logger.error(f"Error getting worst performers: {e}")
            return []
