from .imagenet import ImageNetTransform
