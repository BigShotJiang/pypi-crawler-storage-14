QUEUE_BACKGROUND_TASKS = "fastapi_task_worker.task"
