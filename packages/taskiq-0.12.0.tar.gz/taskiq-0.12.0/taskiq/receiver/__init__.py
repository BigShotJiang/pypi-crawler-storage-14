"""Package for message receiver."""

from taskiq.receiver.receiver import Receiver

__all__ = ["Receiver"]
