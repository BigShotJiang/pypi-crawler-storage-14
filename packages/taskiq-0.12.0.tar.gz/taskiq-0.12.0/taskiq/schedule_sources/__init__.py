"""Package for schedule sources."""

from taskiq.schedule_sources.label_based import LabelScheduleSource

__all__ = [
    "LabelScheduleSource",
]
