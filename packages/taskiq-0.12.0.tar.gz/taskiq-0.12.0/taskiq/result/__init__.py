from .result import TaskiqResult

__all__ = [
    "TaskiqResult",
]
