class TaskiqDeprecationWarning(UserWarning):
    """Warning used to indicate deprecated functionality."""
