# for compatibility with opentelemetry-instrumentation
_instruments = ("taskiq >= 0.11.20",)
