# Installation

```bash

pip install twine

```

# Push

```bash

python setup.py sdist bdist_wheel

# generate token on pypi

twine upload dist/* --verbose --skip-existing
pypi-AgEIcHlwaS5vcmcCJDFlYTY4NGI4LTVkMTctNDM3Yy05YjdkLTIxM2M3ZjYzN2VhZAACDFsxLFsid2hydSJdXQACLFsyLFsiYTM2NTEzZTktNzg2ZS00MmU5LWE5MjctMGZmMWQxYWNlNjJlIl1dAAAGILS6OOSGU97C6929fSzIVMSAkDeyqOCZXyRWtYl3K3HD

# test whether uploading is success

pip install whru

```

```bash

# github
git commit -m "v1.2.3: read os env var"
git tag -a v1.2.3 -m "Release version 1.2.3"
git push origin v1.2.3
```



   twine upload --repository whru