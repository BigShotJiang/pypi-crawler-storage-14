"""Anthropic LLM provider implementation with full async + streaming support."""

import asyncio
import json
import os
from typing import AsyncIterator, Dict, Optional

import httpx

from namel3ss.ml.connectors.base import RetryConfig
from namel3ss.observability.logging import get_logger
from namel3ss.observability.metrics import record_metric

from .base import (
    LLMProvider,
    LLMResponse,
    LLMError,
    StreamChunk,
    StreamConfig,
    ProviderStreamingNotSupportedError,
)


logger = get_logger(__name__)


class AnthropicProvider(LLMProvider):
    """
    Anthropic LLM provider with production-grade async + streaming support.
    
    Features:
    - Real async HTTP requests via httpx.AsyncClient
    - True SSE token streaming with backpressure control
    - Timeout management (stream timeout, chunk timeout)
    - Cancellation propagation and cleanup
    - Concurrency control via semaphore
    - Retry logic with jitter backoff
    """
    
    DEFAULT_BASE_URL = "https://api.anthropic.com/v1"
    DEFAULT_VERSION = "2023-06-01"
    
    def __init__(self, *, model: str, api_key: Optional[str] = None, 
                 base_url: Optional[str] = None, api_version: Optional[str] = None,
                 max_concurrent: int = 10, **kwargs):
        """
        Initialize Anthropic provider.
        
        Args:
            model: Model name (e.g., "claude-3-5-sonnet-20241022")
            api_key: API key (defaults to ANTHROPIC_API_KEY env var)
            base_url: Base URL for API
            api_version: API version header
            max_concurrent: Maximum concurrent requests
            **kwargs: Additional parameters passed to LLMProvider
        """
        super().__init__(model=model, **kwargs)
        
        self.api_key = api_key or os.environ.get("ANTHROPIC_API_KEY")
        if not self.api_key:
            raise LLMError(
                "Anthropic API key not provided. Set ANTHROPIC_API_KEY environment variable "
                "or pass api_key parameter.",
                provider="anthropic"
            )
        
        self.base_url = base_url or os.environ.get("ANTHROPIC_BASE_URL", self.DEFAULT_BASE_URL)
        self.api_version = api_version or self.DEFAULT_VERSION
        self.retry_config = RetryConfig(
            max_attempts=3,
            base_delay=1.0,
            max_delay=60.0,
            jitter=0.2,
            timeout=60.0
        )
        
        # Concurrency control
        self._semaphore = asyncio.Semaphore(max_concurrent)
        self._client: Optional[httpx.AsyncClient] = None
    
    async def _get_client(self) -> httpx.AsyncClient:
        """Get or create async HTTP client."""
        if self._client is None or self._client.is_closed:
            self._client = httpx.AsyncClient(
                timeout=httpx.Timeout(60.0, read=120.0),
                limits=httpx.Limits(max_keepalive_connections=20, max_connections=100),
            )
        return self._client
    
    async def _close_client(self):
        """Close async HTTP client."""
        if self._client and not self._client.is_closed:
            await self._client.aclose()
            self._client = None
    
    def _build_headers(self) -> Dict[str, str]:
        """Build HTTP headers for Anthropic API."""
        return {
            "x-api-key": self.api_key,
            "anthropic-version": self.api_version,
            "Content-Type": "application/json",
        }
    
    def _build_request_body(self, prompt: str, *, system: Optional[str] = None,
                           stream: bool = False, **kwargs) -> Dict:
        """Build request body for Anthropic messages API."""
        messages = [{"role": "user", "content": prompt}]
        
        body = {
            "model": self.model,
            "messages": messages,
            "max_tokens": kwargs.get("max_tokens", self.max_tokens),
            "temperature": kwargs.get("temperature", self.temperature),
            "stream": stream,
        }
        
        if system:
            body["system"] = system
        
        if self.top_p is not None:
            body["top_p"] = self.top_p
        
        # Add any additional parameters
        for key in ("top_k", "stop_sequences", "metadata"):
            if key in kwargs:
                body[key] = kwargs[key]
        
        return body
    
    def _parse_response(self, response_data: Dict) -> LLMResponse:
        """Parse Anthropic API response into LLMResponse."""
        try:
            content_blocks = response_data.get("content", [])
            if not content_blocks:
                raise ValueError("No content in response")
            
            # Extract text from content blocks
            content = "".join(
                block.get("text", "") 
                for block in content_blocks 
                if block.get("type") == "text"
            )
            
            usage = response_data.get("usage", {})
            usage_dict = {
                "prompt_tokens": usage.get("input_tokens", 0),
                "completion_tokens": usage.get("output_tokens", 0),
                "total_tokens": usage.get("input_tokens", 0) + usage.get("output_tokens", 0),
            }
            
            return LLMResponse(
                content=content,
                model=response_data.get("model", self.model),
                usage=usage_dict,
                finish_reason=response_data.get("stop_reason"),
                metadata={
                    "response_id": response_data.get("id"),
                    "stop_reason": response_data.get("stop_reason"),
                }
            )
        except (KeyError, ValueError) as e:
            raise LLMError(
                f"Failed to parse Anthropic response: {e}",
                provider="anthropic",
                original_error=e
            )
    
    def generate(self, prompt: str, *, system: Optional[str] = None, **kwargs) -> LLMResponse:
        """
        Synchronous generate (wrapper around async).
        
        For production use, prefer agenerate() for proper async execution.
        """
        try:
            loop = asyncio.get_running_loop()
            # We're in an async context, should use agenerate instead
            raise LLMError(
                "Cannot call synchronous generate() from async context. Use agenerate() instead.",
                provider="anthropic"
            )
        except RuntimeError:
            # No running loop, we can create one
            return asyncio.run(self.agenerate(prompt, system=system, **kwargs))
    
    async def agenerate(self, prompt: str, *, system: Optional[str] = None, **kwargs) -> LLMResponse:
        """
        Generate completion using Anthropic API (async).
        
        Implements:
        - Real async HTTP via httpx.AsyncClient
        - Retry with jitter backoff
        - Timeout control
        - Concurrency limiting via semaphore
        """
        url = f"{self.base_url}/messages"
        headers = self._build_headers()
        body = self._build_request_body(prompt, system=system, stream=False, **kwargs)
        
        logger.info(f"Anthropic agenerate: model={self.model}, prompt_len={len(prompt)}")
        
        async with self._semaphore:
            client = await self._get_client()
            
            # Retry logic with exponential backoff
            attempt = 0
            last_error = None
            
            while attempt < self.retry_config.max_attempts:
                try:
                    response = await client.post(
                        url,
                        headers=headers,
                        json=body,
                        timeout=self.retry_config.timeout
                    )
                    
                    if response.status_code == 200:
                        response_data = response.json()
                        llm_response = self._parse_response(response_data)
                        
                        # Record metrics
                        record_metric("llm.generation.success", 1, 
                                    tags={"provider": "anthropic", "model": self.model})
                        record_metric("llm.tokens.total", llm_response.usage.get("total_tokens", 0),
                                    tags={"provider": "anthropic", "model": self.model})
                        
                        logger.info(f"Anthropic agenerate complete: tokens={llm_response.usage.get('total_tokens')}")
                        return llm_response
                    
                    # Handle retryable status codes
                    if response.status_code in {429, 500, 502, 503, 504}:
                        attempt += 1
                        if attempt < self.retry_config.max_attempts:
                            delay = self.retry_config.compute_delay(attempt)
                            logger.warning(
                                f"Anthropic API error {response.status_code}, retrying in {delay}s "
                                f"(attempt {attempt}/{self.retry_config.max_attempts})"
                            )
                            await asyncio.sleep(delay)
                            continue
                    
                    # Non-retryable error
                    error_msg = f"Anthropic API error: {response.status_code} - {response.text}"
                    logger.error(error_msg)
                    raise LLMError(error_msg, provider="anthropic", status_code=response.status_code)
                
                except (httpx.TimeoutException, httpx.TransportError) as e:
                    last_error = e
                    attempt += 1
                    if attempt < self.retry_config.max_attempts:
                        delay = self.retry_config.compute_delay(attempt)
                        logger.warning(
                            f"Anthropic network error: {e}, retrying in {delay}s "
                            f"(attempt {attempt}/{self.retry_config.max_attempts})"
                        )
                        await asyncio.sleep(delay)
                        continue
                    break
                
                except asyncio.CancelledError:
                    logger.info("Anthropic agenerate cancelled")
                    raise
                
                except Exception as e:
                    record_metric("llm.generation.error", 1, 
                                tags={"provider": "anthropic", "model": self.model})
                    if isinstance(e, LLMError):
                        raise
                    raise LLMError(
                        f"Anthropic request failed: {e}",
                        provider="anthropic",
                        original_error=e
                    )
            
            # All retries exhausted
            record_metric("llm.generation.error", 1, 
                        tags={"provider": "anthropic", "model": self.model})
            raise LLMError(
                f"Anthropic request failed after {self.retry_config.max_attempts} attempts: {last_error}",
                provider="anthropic",
                original_error=last_error
            )
    
    async def stream_generate(self, prompt: str, *, system: Optional[str] = None,
                             stream_config: Optional[StreamConfig] = None,
                             **kwargs) -> AsyncIterator[StreamChunk]:
        """
        Stream completion using Anthropic API with SSE.
        
        Implements:
        - True SSE token streaming
        - Chunk timeout (max idle time between chunks)
        - Stream timeout (max total time)
        - Backpressure control (max chunks)
        - Clean cancellation and connection closure
        """
        url = f"{self.base_url}/messages"
        headers = self._build_headers()
        body = self._build_request_body(prompt, system=system, stream=True, **kwargs)
        
        config = stream_config or StreamConfig()
        
        logger.info(f"Anthropic stream_generate: model={self.model}, prompt_len={len(prompt)}")
        
        async with self._semaphore:
            client = await self._get_client()
            
            chunk_count = 0
            start_time = asyncio.get_event_loop().time()
            accumulated_text = ""
            
            try:
                async with client.stream(
                    "POST",
                    url,
                    headers=headers,
                    json=body,
                    timeout=httpx.Timeout(
                        connect=10.0,
                        read=config.chunk_timeout,
                        write=10.0,
                        pool=None
                    )
                ) as response:
                    if response.status_code != 200:
                        error_text = await response.aread()
                        error_msg = f"Anthropic streaming error: {response.status_code} - {error_text.decode()}"
                        logger.error(error_msg)
                        raise LLMError(error_msg, provider="anthropic", status_code=response.status_code)
                    
                    # Parse SSE stream
                    async for line in response.aiter_lines():
                        # Check stream timeout
                        if config.stream_timeout:
                            elapsed = asyncio.get_event_loop().time() - start_time
                            if elapsed > config.stream_timeout:
                                logger.warning(f"Anthropic stream timeout after {elapsed}s")
                                raise asyncio.TimeoutError(f"Stream exceeded timeout of {config.stream_timeout}s")
                        
                        # Check max chunks
                        if config.max_chunks and chunk_count >= config.max_chunks:
                            logger.info(f"Anthropic stream reached max chunks: {config.max_chunks}")
                            return
                        
                        # Parse SSE format
                        if not line.strip():
                            continue
                        
                        # Anthropic uses "event: <type>" and "data: <json>"
                        if line.startswith("event: "):
                            event_type = line[7:].strip()
                            continue
                        
                        if line.startswith("data: "):
                            data = line[6:]  # Remove "data: " prefix
                            
                            try:
                                event_data = json.loads(data)
                                event_type = event_data.get("type")
                                
                                # Handle different event types
                                if event_type == "content_block_delta":
                                    delta = event_data.get("delta", {})
                                    if delta.get("type") == "text_delta":
                                        content = delta.get("text", "")
                                        
                                        if content:
                                            accumulated_text += content
                                            chunk_count += 1
                                            yield StreamChunk(
                                                content=content,
                                                finish_reason=None,
                                                model=self.model,
                                                metadata={"event_type": event_type}
                                            )
                                
                                elif event_type == "message_delta":
                                    # Final chunk with stop reason
                                    delta = event_data.get("delta", {})
                                    stop_reason = delta.get("stop_reason")
                                    
                                    if stop_reason:
                                        logger.info(f"Anthropic stream finished: reason={stop_reason}, chunks={chunk_count}")
                                        yield StreamChunk(
                                            content="",
                                            finish_reason=stop_reason,
                                            model=self.model,
                                            metadata={"event_type": event_type}
                                        )
                                
                                elif event_type == "message_stop":
                                    logger.info(f"Anthropic stream complete: chunks={chunk_count}")
                                    return
                                
                                elif event_type == "error":
                                    error_msg = event_data.get("error", {}).get("message", "Unknown error")
                                    raise LLMError(
                                        f"Anthropic streaming error: {error_msg}",
                                        provider="anthropic"
                                    )
                            
                            except json.JSONDecodeError as e:
                                logger.warning(f"Failed to parse Anthropic SSE chunk: {e}")
                                continue
                
                # Record success
                record_metric("llm.streaming.success", 1,
                            tags={"provider": "anthropic", "model": self.model})
                record_metric("llm.streaming.chunks", chunk_count,
                            tags={"provider": "anthropic", "model": self.model})
            
            except asyncio.CancelledError:
                logger.info(f"Anthropic stream cancelled after {chunk_count} chunks")
                record_metric("llm.streaming.cancelled", 1,
                            tags={"provider": "anthropic", "model": self.model})
                raise
            
            except asyncio.TimeoutError as e:
                record_metric("llm.streaming.timeout", 1,
                            tags={"provider": "anthropic", "model": self.model})
                raise LLMError(
                    f"Anthropic stream timeout: {e}",
                    provider="anthropic",
                    original_error=e
                )
            
            except Exception as e:
                record_metric("llm.streaming.error", 1,
                            tags={"provider": "anthropic", "model": self.model})
                if isinstance(e, LLMError):
                    raise
                raise LLMError(
                    f"Anthropic streaming failed: {e}",
                    provider="anthropic",
                    original_error=e
                )
    
    async def chat(self, messages, **kwargs) -> LLMResponse:
        """Generate completion for conversation (async)."""
        url = f"{self.base_url}/messages"
        headers = self._build_headers()
        
        # Convert messages to Anthropic format if needed
        anthropic_messages = []
        system_prompt = None
        
        for msg in messages:
            role = msg.get("role")
            content = msg.get("content")
            
            if role == "system":
                system_prompt = content
            else:
                anthropic_messages.append({"role": role, "content": content})
        
        body = {
            "model": self.model,
            "messages": anthropic_messages,
            "max_tokens": kwargs.get("max_tokens", self.max_tokens),
            "temperature": kwargs.get("temperature", self.temperature),
        }
        
        if system_prompt:
            body["system"] = system_prompt
        
        if self.top_p is not None:
            body["top_p"] = self.top_p
        
        async with self._semaphore:
            client = await self._get_client()
            
            try:
                response = await client.post(
                    url,
                    headers=headers,
                    json=body,
                    timeout=self.retry_config.timeout
                )
                
                if response.status_code != 200:
                    raise LLMError(
                        f"Anthropic API error: {response.status_code} - {response.text}",
                        provider="anthropic",
                        status_code=response.status_code
                    )
                
                return self._parse_response(response.json())
            
            except Exception as e:
                if isinstance(e, LLMError):
                    raise
                raise LLMError(
                    f"Anthropic chat request failed: {e}",
                    provider="anthropic",
                    original_error=e
                )
    
    async def __aenter__(self):
        """Async context manager entry."""
        await self._get_client()
        return self
    
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Async context manager exit with cleanup."""
        await self._close_client()
