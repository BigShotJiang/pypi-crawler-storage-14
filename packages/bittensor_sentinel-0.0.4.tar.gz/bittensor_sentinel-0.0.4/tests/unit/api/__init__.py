"""
Tests covering the package API versioned with ApiVer.

These tests will be run per each version of the API.
"""
