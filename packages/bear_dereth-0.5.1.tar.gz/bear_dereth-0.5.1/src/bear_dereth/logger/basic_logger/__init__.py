"""A basic logger to have around just in case the user doesn't already have one."""

from .basic_logger import BasicLogger

__all__ = ["BasicLogger"]
