"""A set of queue and priority queue implementations."""

from funcy_bear.tools.priority_queue import PriorityQueue
from funcy_bear.tools.simple_queue import SimpooQueue

__all__ = ["PriorityQueue", "SimpooQueue"]
