"""Settings Manager using BearBase backend."""

from __future__ import annotations

from contextlib import contextmanager
from functools import partial
from typing import TYPE_CHECKING, Any, Self

from pydantic import BaseModel
from sqlalchemy.orm import DeclarativeMeta, Mapped, mapped_column

from bear_shelf.database import BearShelfDB, DatabaseConfig, bearshelf_default_db
from bear_shelf.datastore.storage import StorageChoices  # noqa: TC001
from funcy_bear.typing_stuffs import parse_bool, str_to_type

from .settings_path import derive_settings_path as to_path

if TYPE_CHECKING:
    from collections.abc import Generator, Iterator
    from pathlib import Path

    from sqlalchemy.orm import Session

    from bear_shelf.api import BearBase, Table
    from bear_shelf.dialect.bear_dialect import BearShelfDialect


class SettingsDB(BearShelfDB):
    """Database manager for settings storage."""

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        """Initialize the SettingsDB with default parameters."""
        super().__init__(*args, **kwargs)

    @property
    def dialect(self) -> BearShelfDialect:
        """Get the database dialect."""
        return self.engine.dialect  # type: ignore[return-value]

    @property
    def dialect_base(self) -> BearBase:
        """Get the BearBase associated with the dialect."""
        return self.dialect.base

    @property
    def settings_table(self) -> Table:
        """Get the settings table model."""
        return self.dialect_base.table("settings")


Base: DeclarativeMeta = SettingsDB.get_base()


class Settings(Base):
    """SQLAlchemy model for settings storage."""

    __tablename__ = "settings"

    id: Mapped[int] = mapped_column(primary_key=True, autoincrement=True)
    key: Mapped[str] = mapped_column(nullable=False, default="")
    value: Mapped[str] = mapped_column(nullable=False, default="")
    type: Mapped[str] = mapped_column(nullable=False, default="str")


class DefaultSettings(BaseModel):
    """Default settings schema."""

    default_name: str = "settings"
    default_table: type[Settings] = Settings
    storage_type: StorageChoices = "toml"


CUSTOM_TYPE_MAP: dict[str, type] = {"epochtimestamp": int, "datetime": str}
DEFAULT_EXEMPT: frozenset[str] = frozenset({"memory", "default"})


class BearSettings:
    """Settings manager backed by BearBase instead of temp storage."""

    __slots__: tuple = (
        "_all_values",
        "_config",
        "_db",
        "_db_factory",
        "_default_table",
        "_settings",
        "_storage_type",
        "file_path",
        "name",
    )
    _default_settings: type[DefaultSettings] = DefaultSettings

    def __init__(
        self,
        name: str,
        file_name: str | None = None,
        path: Path | str | None = None,
        storage: StorageChoices = "toml",
        enable_wal: bool = False,
        config: DatabaseConfig | None = None,
        **kwargs,
    ) -> None:
        """Initialize BearBase-backed settings manager.

        Args:
            name: Name of the settings
            file_name: Optional specific file name
            path: Optional path to settings file
            storage (StorageChoices): Storage backend type
            enable_wal: Enable Write-Ahead Logging (default: False)
        """
        self.name: str = name
        self._settings = self._default_settings()
        self._storage_type = storage or self._settings.storage_type
        self.file_path: Path = to_path(name, file_name, path)
        self._all_values: dict[str, Any] | None = None
        self._config: DatabaseConfig = config or bearshelf_default_db(path=self.file_path, storage=self._storage_type)
        self._db_factory: partial[SettingsDB] = partial(
            SettingsDB,
            database_config=self._config,
            enable_wal=enable_wal,
            records={"settings": Settings},
            **kwargs,
        )
        self._db: SettingsDB | None = None

    def __del__(self) -> None:
        self.close()

    @property
    def db(self) -> SettingsDB:
        """Get or create the database instance."""
        if self._db is None:
            self._db = self._db_factory()
            self._db.create_tables()
        return self._db

    @property
    def closed(self) -> bool:
        """Check if database is closed."""
        return self._db is None

    def type_parsing(self, value: Any, value_type: str) -> Any:
        """Parse value to the specified type."""
        if value_type == "NoneType":
            return None
        if value_type == "bool":
            return parse_bool(value)
        typing: Any = str_to_type(value_type, custom_map=CUSTOM_TYPE_MAP)
        if typing is Any:
            typing = str
        try:
            return typing(value)
        except Exception:
            return value

    @property
    def get_all(self) -> dict[str, Any]:
        """Get all settings as dictionary."""
        if self._all_values is None:
            session: Session = self.db.get_session()
            records: list[Settings] = session.query(Settings).all()
            self._all_values = {record.key: self.type_parsing(record.value, record.type) for record in records}
            session.close()
        return self._all_values

    def get(self, key: str, default: Any = None) -> Any:
        """Get a setting value."""
        with self.db.open_session() as session:
            record: Settings | None = session.query(Settings).filter(Settings.key == key).first()
            if record:
                # Access fields while still in session to avoid detached instance issues
                value = record.value
                value_type = record.type
                return self.type_parsing(value, value_type)
        return default

    def set(self, key: str, value: Any) -> None:
        """Set a setting value."""
        self.upsert(key, value)

    def upsert(self, key: str, value: Any) -> None:
        """Insert or update a setting value."""
        value_type = type(value).__name__
        value_str = str(value)
        with self.db.open_session() as session:
            record: Settings | None = session.query(Settings).filter_by(key=key).first()
            if record:
                record.value = value_str
                record.type = value_type
            else:
                session.add(Settings(key=key, value=value_str, type=value_type))

        self.invalidate_cache()

    def has(self, key: str) -> bool:
        """Check if setting exists."""
        return key in self.get_all

    def keys(self) -> list[str]:
        """Get all setting keys."""
        return list(self.get_all.keys())

    def values(self) -> list[Any]:
        """Get all setting values."""
        return list(self.get_all.values())

    def items(self) -> list[tuple[str, Any]]:
        """Get all key-value pairs."""
        return list(self.get_all.items())

    def close(self) -> None:
        """Close the database."""
        if self._db is not None:
            self._db.close()
            self._db = None

    def invalidate_cache(self) -> None:
        """Invalidate the cached settings."""
        self._all_values = None

    @property
    def _class_name(self) -> str:
        return self.__class__.__name__

    def __getattr__(self, key: str) -> Any:
        """Handle dot notation access for settings."""
        if key in self.__slots__:
            raise AttributeError(f"'{key}' not initialized")
        if key.startswith("_"):
            raise AttributeError(f"'{self.__class__.__name__}' object has no attribute '{key}'")
        return self.get(key)

    def __setattr__(self, key: str, value: Any) -> None:
        """Handle dot notation assignment for settings."""
        if key in self.__slots__:
            object.__setattr__(self, key, value)
            return
        self.set(key=key, value=value)

    def __getitem__(self, key: str) -> Any:
        return self.get(key)

    def __setitem__(self, key: str, value: Any) -> None:
        self.set(key, value)

    def __iter__(self) -> Iterator[str]:
        return iter(self.keys())

    def __contains__(self, key: str) -> bool:
        return self.has(key)

    def __len__(self) -> int:
        return len(self.keys())

    def __bool__(self) -> bool:
        return not self.closed and len(self) > 0

    def __enter__(self) -> Self:
        return self

    def __exit__(self, exc_type: object, exc_value: object, traceback: object) -> None:
        self.close()

    def __repr__(self) -> str:
        return f"<{self._class_name} name='{self.name}'>"

    def __str__(self) -> str:
        return f"{self._class_name} for '{self.name}' with {len(self)} settings."


@contextmanager
def settings(
    name: str,
    file_name: str | None = None,
    path: str | Path | None = None,
    **kwargs,
) -> Generator[BearSettings]:
    """Context manager for SettingsManager.

    Args:
        name: Name of the settings
        file_name: Optional specific file name
        path: Optional path to settings file
        **kwargs: Additional arguments for BearSettings
    """
    sm: BearSettings = BearSettings(name, file_name=file_name, path=path, **kwargs)
    try:
        yield sm
    finally:
        sm.close()


class SettingsManager(BearSettings):
    """Alias for BearSettings."""


__all__ = ["BearSettings", "SettingsManager", "settings"]

# if __name__ == "__main__":
#     sm = BearSettings("test")
#     import random

#     sm.set("a", 1)
#     sm.set("b", value=True)
#     sm.set("c", value=random.uniform(0, 1))
#     sm.set("d", value="hello")
#     sm.set("e", value=None)

#     print(sm.get_all())
