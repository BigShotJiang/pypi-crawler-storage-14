# Copyright 2022 Sony Semiconductor Solutions, Inc. All rights reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ==============================================================================


import torch

from model_compression_toolkit.core.pytorch.constants import PLACEHOLDER


class DummyPlaceHolder(torch.nn.Module):
    """
    Class for PlaceHolder operator since a Pytorch model doesn't have one but FX does.
    """

    def __name__(self):
        return PLACEHOLDER  # pragma: no cover

    def forward(self, x):
        return x
