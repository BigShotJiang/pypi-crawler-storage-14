"""
Sync command - Bidirectional synchronization for external tools and repositories.

This module provides commands for synchronizing changes between external tool artifacts
(e.g., Spec-Kit, Linear, Jira), repository changes, and SpecFact plans using the
bridge architecture.
"""

from __future__ import annotations

import os
import shutil
from pathlib import Path
from typing import Any

import typer
from beartype import beartype
from icontract import ensure, require
from rich.console import Console
from rich.progress import Progress, SpinnerColumn, TextColumn

from specfact_cli import runtime
from specfact_cli.models.bridge import AdapterType
from specfact_cli.models.plan import Feature, PlanBundle
from specfact_cli.sync.speckit_sync import SpecKitSync
from specfact_cli.telemetry import telemetry


app = typer.Typer(help="Synchronize external tool artifacts and repository changes")
console = Console()


def _is_test_mode() -> bool:
    """Check if running in test mode."""
    # Check for TEST_MODE environment variable
    if os.environ.get("TEST_MODE") == "true":
        return True
    # Check if running under pytest (common patterns)
    import sys

    return any("pytest" in arg or "test" in arg.lower() for arg in sys.argv) or "pytest" in sys.modules


@beartype
@require(lambda repo: repo.exists(), "Repository path must exist")
@require(lambda repo: repo.is_dir(), "Repository path must be a directory")
@require(lambda bidirectional: isinstance(bidirectional, bool), "Bidirectional must be bool")
@require(lambda bundle: bundle is None or isinstance(bundle, str), "Bundle must be None or str")
@require(lambda overwrite: isinstance(overwrite, bool), "Overwrite must be bool")
@require(lambda adapter_type: adapter_type is not None, "Adapter type must be set")
@ensure(lambda result: result is None, "Must return None")
def _perform_sync_operation(
    repo: Path,
    bidirectional: bool,
    bundle: str | None,
    overwrite: bool,
    adapter_type: AdapterType,
) -> None:
    """
    Perform sync operation without watch mode.

    This is extracted to avoid recursion when called from watch mode callback.

    Args:
        repo: Path to repository
        bidirectional: Enable bidirectional sync
        bundle: Project bundle name
        overwrite: Overwrite existing tool artifacts
        adapter_type: Adapter type to use
    """
    from specfact_cli.importers.speckit_converter import SpecKitConverter
    from specfact_cli.importers.speckit_scanner import SpecKitScanner

    # Step 1: Detect tool repository (using bridge probe for auto-detection)
    from specfact_cli.sync.bridge_probe import BridgeProbe
    from specfact_cli.utils.structure import SpecFactStructure
    from specfact_cli.validators.schema import validate_plan_bundle

    probe = BridgeProbe(repo)
    capabilities = probe.detect()

    # For Spec-Kit adapter, use legacy scanner for now
    if adapter_type == AdapterType.SPECKIT:
        scanner = SpecKitScanner(repo)
        if not scanner.is_speckit_repo():
            console.print(f"[bold red]✗[/bold red] Not a {adapter_type.value} repository")
            console.print("[dim]Expected: .specify/ directory[/dim]")
            console.print("[dim]Tip: Use 'specfact bridge probe' to auto-detect tool configuration[/dim]")
            raise typer.Exit(1)

        console.print(f"[bold green]✓[/bold green] Detected {adapter_type.value} repository")
    else:
        console.print(f"[bold green]✓[/bold green] Using bridge adapter: {adapter_type.value}")
        # TODO: Implement generic adapter detection
        console.print("[yellow]⚠ Generic adapter not yet fully implemented[/yellow]")
        raise typer.Exit(1)

    # Step 1.5: Validate constitution exists and is not empty (Spec-Kit specific)
    if adapter_type == AdapterType.SPECKIT:
        has_constitution, constitution_error = scanner.has_constitution()
    else:
        has_constitution = True
        constitution_error = None
    if not has_constitution:
        console.print("[bold red]✗[/bold red] Constitution required")
        console.print(f"[red]{constitution_error}[/red]")
        console.print("\n[bold yellow]Next Steps:[/bold yellow]")
        console.print("1. Run 'specfact constitution bootstrap --repo .' to auto-generate constitution")
        console.print("2. Or run tool-specific constitution command in your AI assistant")
        console.print("3. Then run 'specfact sync bridge --adapter <adapter>' again")
        raise typer.Exit(1)

    # Check if constitution is minimal and suggest bootstrap
    constitution_path = repo / ".specify" / "memory" / "constitution.md"
    if constitution_path.exists():
        from specfact_cli.commands.constitution import is_constitution_minimal

        if is_constitution_minimal(constitution_path):
            # Auto-generate in test mode, prompt in interactive mode
            # Check for test environment (TEST_MODE or PYTEST_CURRENT_TEST)
            is_test_env = os.environ.get("TEST_MODE") == "true" or os.environ.get("PYTEST_CURRENT_TEST") is not None
            if is_test_env:
                # Auto-generate bootstrap constitution in test mode
                from specfact_cli.enrichers.constitution_enricher import ConstitutionEnricher

                enricher = ConstitutionEnricher()
                enriched_content = enricher.bootstrap(repo, constitution_path)
                constitution_path.write_text(enriched_content, encoding="utf-8")
            else:
                # Check if we're in an interactive environment
                if runtime.is_interactive():
                    console.print("[yellow]⚠[/yellow] Constitution is minimal (essentially empty)")
                    suggest_bootstrap = typer.confirm(
                        "Generate bootstrap constitution from repository analysis?",
                        default=True,
                    )
                    if suggest_bootstrap:
                        from specfact_cli.enrichers.constitution_enricher import ConstitutionEnricher

                        console.print("[dim]Generating bootstrap constitution...[/dim]")
                        enricher = ConstitutionEnricher()
                        enriched_content = enricher.bootstrap(repo, constitution_path)
                        constitution_path.write_text(enriched_content, encoding="utf-8")
                        console.print("[bold green]✓[/bold green] Bootstrap constitution generated")
                        console.print("[dim]Review and adjust as needed before syncing[/dim]")
                    else:
                        console.print(
                            "[dim]Skipping bootstrap. Run 'specfact constitution bootstrap' manually if needed[/dim]"
                        )
                else:
                    # Non-interactive mode: skip prompt
                    console.print("[yellow]⚠[/yellow] Constitution is minimal (essentially empty)")
                    console.print("[dim]Run 'specfact constitution bootstrap --repo .' to generate constitution[/dim]")

    console.print("[bold green]✓[/bold green] Constitution found and validated")

    # Step 2: Detect SpecFact structure
    specfact_exists = (repo / SpecFactStructure.ROOT).exists()

    if not specfact_exists:
        console.print("[yellow]⚠[/yellow] SpecFact structure not found")
        console.print(f"[dim]Initialize with: specfact plan init --scaffold --repo {repo}[/dim]")
        # Create structure automatically
        SpecFactStructure.ensure_structure(repo)
        console.print("[bold green]✓[/bold green] Created SpecFact structure")

    if specfact_exists:
        console.print("[bold green]✓[/bold green] Detected SpecFact structure")

    sync = SpecKitSync(repo)
    converter = SpecKitConverter(repo)

    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        console=console,
    ) as progress:
        # Step 3: Scan tool artifacts
        task = progress.add_task(f"[cyan]Scanning {adapter_type.value} artifacts...[/cyan]", total=None)
        # Keep description showing current activity (spinner will show automatically)
        progress.update(task, description=f"[cyan]Scanning {adapter_type.value} artifacts...[/cyan]")
        features = scanner.discover_features()
        # Update with final status after completion
        progress.update(task, description=f"[green]✓[/green] Found {len(features)} features in specs/")

        # Step 3.5: Validate tool artifacts for unidirectional sync
        if not bidirectional and len(features) == 0:
            console.print(f"[bold red]✗[/bold red] No {adapter_type.value} features found")
            console.print(
                f"[red]Unidirectional sync ({adapter_type.value} → SpecFact) requires at least one feature specification.[/red]"
            )
            console.print("\n[bold yellow]Next Steps:[/bold yellow]")
            if adapter_type == AdapterType.SPECKIT:
                console.print("1. Run '/speckit.specify' command in your AI assistant to create feature specifications")
                console.print("2. Optionally run '/speckit.plan' and '/speckit.tasks' to create complete artifacts")
            else:
                console.print(f"1. Create feature specifications in your {adapter_type.value} project")
            console.print(f"3. Then run 'specfact sync bridge --adapter {adapter_type.value}' again")
            console.print(
                f"\n[dim]Note: For bidirectional sync, {adapter_type.value} artifacts are optional if syncing from SpecFact → {adapter_type.value}[/dim]"
            )
            raise typer.Exit(1)

        # Step 4: Sync based on mode
        specfact_changes: dict[str, Any] = {}
        conflicts: list[dict[str, Any]] = []
        features_converted_speckit = 0

        if bidirectional:
            # Bidirectional sync: tool → SpecFact and SpecFact → tool
            # Step 5.1: tool → SpecFact (unidirectional sync)
            # Skip expensive conversion if no tool features found (optimization)
            merged_bundle: PlanBundle | None = None
            features_updated = 0
            features_added = 0
            
            if len(features) == 0:
                task = progress.add_task(f"[cyan]📝[/cyan] Converting {adapter_type.value} → SpecFact...", total=None)
                progress.update(
                    task,
                    description=f"[green]✓[/green] Skipped (no {adapter_type.value} features found)",
                )
                console.print(f"[dim]  - Skipped {adapter_type.value} → SpecFact (no features found)[/dim]")
                # Use existing plan bundle if available, otherwise create minimal empty one
                from specfact_cli.utils.structure import SpecFactStructure
                from specfact_cli.validators.schema import validate_plan_bundle

                # Use get_default_plan_path() to find the active plan (checks config or falls back to main.bundle.yaml)
                plan_path = SpecFactStructure.get_default_plan_path(repo)
                if plan_path and plan_path.exists():
                    # Show progress while loading plan bundle
                    progress.update(task, description="[cyan]Parsing plan bundle YAML...[/cyan]")
                    validation_result = validate_plan_bundle(plan_path)
                    if isinstance(validation_result, tuple):
                        is_valid, _error, loaded_plan_bundle = validation_result
                        if is_valid and loaded_plan_bundle:
                            # Show progress during validation (Pydantic validation can be slow for large bundles)
                            progress.update(
                                task, description=f"[cyan]Validating {len(loaded_plan_bundle.features)} features...[/cyan]"
                            )
                            merged_bundle = loaded_plan_bundle
                            progress.update(
                                task,
                                description=f"[green]✓[/green] Loaded plan bundle ({len(loaded_plan_bundle.features)} features)",
                            )
                        else:
                            # Fallback: create minimal bundle via converter (but skip expensive parsing)
                            progress.update(task, description=f"[cyan]Creating plan bundle from {adapter_type.value}...[/cyan]")
                            merged_bundle = _sync_speckit_to_specfact(repo, converter, scanner, progress, task)[0]
                    else:
                        progress.update(task, description=f"[cyan]Creating plan bundle from {adapter_type.value}...[/cyan]")
                        merged_bundle = _sync_speckit_to_specfact(repo, converter, scanner, progress, task)[0]
                else:
                    # No plan path found, create minimal bundle
                    progress.update(task, description=f"[cyan]Creating plan bundle from {adapter_type.value}...[/cyan]")
                    merged_bundle = _sync_speckit_to_specfact(repo, converter, scanner, progress, task)[0]
            else:
                task = progress.add_task(f"[cyan]Converting {adapter_type.value} → SpecFact...[/cyan]", total=None)
                # Show current activity (spinner will show automatically)
                progress.update(task, description=f"[cyan]Converting {adapter_type.value} → SpecFact...[/cyan]")
                merged_bundle, features_updated, features_added = _sync_speckit_to_specfact(
                    repo, converter, scanner, progress
                )

            if merged_bundle:
                if features_updated > 0 or features_added > 0:
                    progress.update(
                        task,
                        description=f"[green]✓[/green] Updated {features_updated}, Added {features_added} features",
                    )
                    console.print(f"[dim]  - Updated {features_updated} features[/dim]")
                    console.print(f"[dim]  - Added {features_added} new features[/dim]")
                else:
                    progress.update(
                        task,
                        description=f"[green]✓[/green] Created plan with {len(merged_bundle.features)} features",
                    )

            # Step 5.2: SpecFact → tool (reverse conversion)
            task = progress.add_task(f"[cyan]Converting SpecFact → {adapter_type.value}...[/cyan]", total=None)
            # Show current activity (spinner will show automatically)
            progress.update(task, description="[cyan]Detecting SpecFact changes...[/cyan]")

            # Detect SpecFact changes (for tracking/incremental sync, but don't block conversion)
            specfact_changes = sync.detect_specfact_changes(repo)

            # Use the merged_bundle we already loaded, or load it if not available
            # We convert even if no "changes" detected, as long as plan bundle exists and has features
            plan_bundle_to_convert: PlanBundle | None = None

            # Prefer using merged_bundle if it has features (already loaded above)
            if merged_bundle and len(merged_bundle.features) > 0:
                plan_bundle_to_convert = merged_bundle
            else:
                # Fallback: load plan bundle from bundle name or default
                plan_bundle_to_convert = None
                if bundle:
                    from specfact_cli.commands.plan import _convert_project_bundle_to_plan_bundle
                    from specfact_cli.utils.bundle_loader import load_project_bundle

                    bundle_dir = SpecFactStructure.project_dir(repo) / bundle
                    if bundle_dir.exists():
                        project_bundle = load_project_bundle(bundle_dir)
                        plan_bundle_to_convert = _convert_project_bundle_to_plan_bundle(project_bundle)
                else:
                    # Use get_default_plan_path() to find the active plan (legacy compatibility)
                    plan_path: Path | None = None
                    if hasattr(SpecFactStructure, "get_default_plan_path"):
                        plan_path = SpecFactStructure.get_default_plan_path(repo)
                    if plan_path and plan_path.exists():
                        progress.update(task, description="[cyan]Loading plan bundle...[/cyan]")
                        validation_result = validate_plan_bundle(plan_path)
                        if isinstance(validation_result, tuple):
                            is_valid, _error, plan_bundle = validation_result
                            if is_valid and plan_bundle and len(plan_bundle.features) > 0:
                                plan_bundle_to_convert = plan_bundle

            # Convert if we have a plan bundle with features
            if plan_bundle_to_convert and len(plan_bundle_to_convert.features) > 0:
                # Handle overwrite mode
                if overwrite:
                    progress.update(task, description="[cyan]Removing existing artifacts...[/cyan]")
                    # Delete existing Spec-Kit artifacts before conversion
                    specs_dir = repo / "specs"
                    if specs_dir.exists():
                        console.print("[yellow]⚠[/yellow] Overwrite mode: Removing existing Spec-Kit artifacts...")
                        shutil.rmtree(specs_dir)
                        specs_dir.mkdir(parents=True, exist_ok=True)
                        console.print("[green]✓[/green] Existing artifacts removed")

                # Convert SpecFact plan bundle to tool format
                total_features = len(plan_bundle_to_convert.features)
                progress.update(
                    task,
                    description=f"[cyan]Converting plan bundle to {adapter_type.value} format (0 of {total_features})...[/cyan]",
                )

                # Progress callback to update during conversion
                def update_progress(current: int, total: int) -> None:
                    progress.update(
                        task,
                        description=f"[cyan]Converting plan bundle to {adapter_type.value} format ({current} of {total})...[/cyan]",
                    )

                features_converted_speckit = converter.convert_to_speckit(plan_bundle_to_convert, update_progress)
                progress.update(
                    task,
                    description=f"[green]✓[/green] Converted {features_converted_speckit} features to {adapter_type.value}",
                )
                mode_text = "overwritten" if overwrite else "generated"
                console.print(
                    f"[dim]  - {mode_text.capitalize()} spec.md, plan.md, tasks.md for {features_converted_speckit} features[/dim]"
                )
                # Warning about Constitution Check gates
                console.print(
                    "[yellow]⚠[/yellow] [dim]Note: Constitution Check gates in plan.md are set to PENDING - review and check gates based on your project's actual state[/dim]"
                )
            else:
                progress.update(task, description=f"[green]✓[/green] No features to convert to {adapter_type.value}")
                features_converted_speckit = 0

            # Detect conflicts between both directions
            speckit_changes = sync.detect_speckit_changes(repo)
            conflicts = sync.detect_conflicts(speckit_changes, specfact_changes)

            if conflicts:
                console.print(f"[yellow]⚠[/yellow] Found {len(conflicts)} conflicts")
                console.print(f"[dim]Conflicts resolved using priority rules (SpecFact > {adapter_type.value} for artifacts)[/dim]")
            else:
                console.print("[bold green]✓[/bold green] No conflicts detected")
        else:
            # Unidirectional sync: tool → SpecFact
            task = progress.add_task("[cyan]Converting to SpecFact format...[/cyan]", total=None)
            # Show current activity (spinner will show automatically)
            progress.update(task, description="[cyan]Converting to SpecFact format...[/cyan]")

            merged_bundle, features_updated, features_added = _sync_speckit_to_specfact(
                repo, converter, scanner, progress
            )

            if features_updated > 0 or features_added > 0:
                task = progress.add_task("[cyan]🔀[/cyan] Merging with existing plan...", total=None)
                progress.update(
                    task,
                    description=f"[green]✓[/green] Updated {features_updated} features, Added {features_added} features",
                )
                console.print(f"[dim]  - Updated {features_updated} features[/dim]")
                console.print(f"[dim]  - Added {features_added} new features[/dim]")
            else:
                progress.update(
                    task, description=f"[green]✓[/green] Created plan with {len(merged_bundle.features)} features"
                )
                console.print(f"[dim]Created plan with {len(merged_bundle.features)} features[/dim]")

            # Report features synced
            console.print()
            if features:
                console.print("[bold cyan]Features synced:[/bold cyan]")
                for feature in features:
                    feature_key = feature.get("feature_key", "UNKNOWN")
                    feature_title = feature.get("title", "Unknown Feature")
                    console.print(f"  - [cyan]{feature_key}[/cyan]: {feature_title}")

        # Step 8: Output Results
        console.print()
        if bidirectional:
            console.print("[bold cyan]Sync Summary (Bidirectional):[/bold cyan]")
            console.print(f"  - {adapter_type.value} → SpecFact: Updated {features_updated}, Added {features_added} features")
            # Always show conversion result (we convert if plan bundle exists, not just when changes detected)
            if features_converted_speckit > 0:
                console.print(
                    f"  - SpecFact → {adapter_type.value}: {features_converted_speckit} features converted to {adapter_type.value} format"
                )
            else:
                console.print(f"  - SpecFact → {adapter_type.value}: No features to convert")
            if conflicts:
                console.print(f"  - Conflicts: {len(conflicts)} detected and resolved")
            else:
                console.print("  - Conflicts: None detected")

            # Post-sync validation suggestion
            if features_converted_speckit > 0:
                console.print()
                console.print("[bold cyan]Next Steps:[/bold cyan]")
                if adapter_type == AdapterType.SPECKIT:
                    console.print("  Run '/speckit.analyze' to validate artifact consistency and quality")
                else:
                    console.print(f"  Validate {adapter_type.value} artifact consistency and quality")
                console.print("  This will check for ambiguities, duplications, and constitution alignment")
        else:
            console.print("[bold cyan]Sync Summary (Unidirectional):[/bold cyan]")
            if features:
                console.print(f"  - Features synced: {len(features)}")
            if features_updated > 0 or features_added > 0:
                console.print(f"  - Updated: {features_updated} features")
                console.print(f"  - Added: {features_added} new features")
            console.print(f"  - Direction: {adapter_type.value} → SpecFact")

            # Post-sync validation suggestion
            console.print()
            console.print("[bold cyan]Next Steps:[/bold cyan]")
            if adapter_type == AdapterType.SPECKIT:
                console.print("  Run '/speckit.analyze' to validate artifact consistency and quality")
            else:
                console.print(f"  Validate {adapter_type.value} artifact consistency and quality")
            console.print("  This will check for ambiguities, duplications, and constitution alignment")

    console.print()
    console.print("[bold green]✓[/bold green] Sync complete!")


def _sync_speckit_to_specfact(
    repo: Path, converter: Any, scanner: Any, progress: Any, task: int | None = None
) -> tuple[PlanBundle, int, int]:
    """
    Sync tool artifacts to SpecFact format.

    Args:
        repo: Repository path
        converter: Tool converter instance (e.g., SpecKitConverter)
        scanner: Tool scanner instance (e.g., SpecKitScanner)
        progress: Rich Progress instance
        task: Optional progress task ID to update

    Returns:
        Tuple of (merged_bundle, features_updated, features_added)
    """
    from specfact_cli.generators.plan_generator import PlanGenerator
    from specfact_cli.utils.structure import SpecFactStructure
    from specfact_cli.validators.schema import validate_plan_bundle

    plan_path = SpecFactStructure.get_default_plan_path(repo)
    existing_bundle: PlanBundle | None = None

    if plan_path.exists():
        if task is not None:
            progress.update(task, description="[cyan]Validating existing plan bundle...[/cyan]")
        validation_result = validate_plan_bundle(plan_path)
        if isinstance(validation_result, tuple):
            is_valid, _error, bundle = validation_result
            if is_valid and bundle:
                existing_bundle = bundle
                # Deduplicate existing features by normalized key (clean up duplicates from previous syncs)
                from specfact_cli.utils.feature_keys import normalize_feature_key

                seen_normalized_keys: set[str] = set()
                deduplicated_features: list[Feature] = []
                for existing_feature in existing_bundle.features:
                    normalized_key = normalize_feature_key(existing_feature.key)
                    if normalized_key not in seen_normalized_keys:
                        seen_normalized_keys.add(normalized_key)
                        deduplicated_features.append(existing_feature)

                duplicates_removed = len(existing_bundle.features) - len(deduplicated_features)
                if duplicates_removed > 0:
                    existing_bundle.features = deduplicated_features
                    # Write back deduplicated bundle immediately to clean up the plan file
                    from specfact_cli.generators.plan_generator import PlanGenerator

                    if task is not None:
                        progress.update(
                            task,
                            description=f"[cyan]Deduplicating {duplicates_removed} duplicate features and writing cleaned plan...[/cyan]",
                        )
                    generator = PlanGenerator()
                    generator.generate(existing_bundle, plan_path)
                    if task is not None:
                        progress.update(
                            task,
                            description=f"[green]✓[/green] Removed {duplicates_removed} duplicates, cleaned plan saved",
                        )

    # Convert tool artifacts to SpecFact
    if task is not None:
        progress.update(task, description="[cyan]Converting tool artifacts to SpecFact format...[/cyan]")
    converted_bundle = converter.convert_plan(None if not existing_bundle else plan_path)

    # Merge with existing plan if it exists
    features_updated = 0
    features_added = 0

    if existing_bundle:
        if task is not None:
            progress.update(task, description="[cyan]Merging with existing plan bundle...[/cyan]")
        # Use normalized keys for matching to handle different key formats (e.g., FEATURE-001 vs 001_FEATURE_NAME)
        from specfact_cli.utils.feature_keys import normalize_feature_key

        # Build a map of normalized_key -> (index, original_key) for existing features
        normalized_key_map: dict[str, tuple[int, str]] = {}
        for idx, existing_feature in enumerate(existing_bundle.features):
            normalized_key = normalize_feature_key(existing_feature.key)
            # If multiple features have the same normalized key, keep the first one
            if normalized_key not in normalized_key_map:
                normalized_key_map[normalized_key] = (idx, existing_feature.key)

        for feature in converted_bundle.features:
            normalized_key = normalize_feature_key(feature.key)
            matched = False

            # Try exact match first
            if normalized_key in normalized_key_map:
                existing_idx, original_key = normalized_key_map[normalized_key]
                # Preserve the original key format from existing bundle
                feature.key = original_key
                existing_bundle.features[existing_idx] = feature
                features_updated += 1
                matched = True
            else:
                # Try prefix match for abbreviated vs full names
                # (e.g., IDEINTEGRATION vs IDEINTEGRATIONSYSTEM)
                # Only match if shorter is a PREFIX of longer with significant length difference
                # AND at least one key has a numbered prefix (041_, 042-, etc.) indicating Spec-Kit origin
                # This avoids false positives like SMARTCOVERAGE vs SMARTCOVERAGEMANAGER (both from code analysis)
                for existing_norm_key, (existing_idx, original_key) in normalized_key_map.items():
                    shorter = min(normalized_key, existing_norm_key, key=len)
                    longer = max(normalized_key, existing_norm_key, key=len)

                    # Check if at least one key has a numbered prefix (tool format, e.g., Spec-Kit)
                    import re

                    has_speckit_key = bool(
                        re.match(r"^\d{3}[_-]", feature.key) or re.match(r"^\d{3}[_-]", original_key)
                    )

                    # More conservative matching:
                    # 1. At least one key must have numbered prefix (tool origin, e.g., Spec-Kit)
                    # 2. Shorter must be at least 10 chars
                    # 3. Longer must start with shorter (prefix match)
                    # 4. Length difference must be at least 6 chars
                    # 5. Shorter must be < 75% of longer (to ensure significant difference)
                    length_diff = len(longer) - len(shorter)
                    length_ratio = len(shorter) / len(longer) if len(longer) > 0 else 1.0

                    if (
                        has_speckit_key
                        and len(shorter) >= 10
                        and longer.startswith(shorter)
                        and length_diff >= 6
                        and length_ratio < 0.75
                    ):
                        # Match found - use the existing key format (prefer full name if available)
                        if len(existing_norm_key) >= len(normalized_key):
                            # Existing key is longer (full name) - keep it
                            feature.key = original_key
                        else:
                            # New key is longer (full name) - use it but update existing
                            existing_bundle.features[existing_idx].key = feature.key
                        existing_bundle.features[existing_idx] = feature
                        features_updated += 1
                        matched = True
                        break

            if not matched:
                # New feature - add it
                existing_bundle.features.append(feature)
                features_added += 1

        # Update product themes
        themes_existing = set(existing_bundle.product.themes)
        themes_new = set(converted_bundle.product.themes)
        existing_bundle.product.themes = list(themes_existing | themes_new)

        # Write merged bundle
        if task is not None:
            progress.update(task, description="[cyan]Writing plan bundle to disk...[/cyan]")
        generator = PlanGenerator()
        generator.generate(existing_bundle, plan_path)
        return existing_bundle, features_updated, features_added
    # Write new bundle
    generator = PlanGenerator()
    generator.generate(converted_bundle, plan_path)
    return converted_bundle, 0, len(converted_bundle.features)


@app.command("bridge")
def sync_bridge(
    repo: Path = typer.Option(
        Path("."),
        "--repo",
        help="Path to repository",
        exists=True,
        file_okay=False,
        dir_okay=True,
    ),
    adapter: str = typer.Option(
        "speckit",
        "--adapter",
        help="Adapter type (speckit, generic-markdown). Default: auto-detect",
    ),
    bundle: str | None = typer.Option(
        None,
        "--bundle",
        help="Project bundle name for SpecFact → tool conversion (default: auto-detect)",
    ),
    bidirectional: bool = typer.Option(
        False,
        "--bidirectional",
        help="Enable bidirectional sync (tool ↔ SpecFact)",
    ),
    overwrite: bool = typer.Option(
        False,
        "--overwrite",
        help="Overwrite existing tool artifacts (delete all existing before sync)",
    ),
    watch: bool = typer.Option(
        False,
        "--watch",
        help="Watch mode for continuous sync",
    ),
    interval: int = typer.Option(
        5,
        "--interval",
        help="Watch interval in seconds (default: 5)",
        min=1,
    ),
    ensure_compliance: bool = typer.Option(
        False,
        "--ensure-compliance",
        help="Validate and auto-enrich plan bundle for tool compliance before sync",
    ),
) -> None:
    """
    Sync changes between external tool artifacts and SpecFact using bridge architecture.

    Synchronizes artifacts from external tools (e.g., Spec-Kit, Linear, Jira) with
    SpecFact project bundles using configurable bridge mappings.

    Supported adapters:
    - speckit: Spec-Kit projects (specs/, .specify/)
    - generic-markdown: Generic markdown-based specifications

    Example:
        specfact sync bridge --adapter speckit --repo . --bidirectional
        specfact sync bridge --repo . --bidirectional  # Auto-detect adapter
    """
    # Auto-detect adapter if not specified
    if adapter == "speckit" or adapter == "auto":
        from specfact_cli.sync.bridge_probe import BridgeProbe

        probe = BridgeProbe(repo)
        capabilities = probe.detect()
        if capabilities.tool == "speckit":
            adapter = "speckit"
        else:
            adapter = "generic-markdown"

    # Validate adapter
    try:
        adapter_type = AdapterType(adapter.lower())
    except ValueError:
        console.print(f"[bold red]✗[/bold red] Unsupported adapter: {adapter}")
        console.print(f"[dim]Supported adapters: {', '.join([a.value for a in AdapterType])}[/dim]")
        raise typer.Exit(1)

    telemetry_metadata = {
        "adapter": adapter,
        "bidirectional": bidirectional,
        "watch": watch,
        "overwrite": overwrite,
        "interval": interval,
    }

    with telemetry.track_command("sync.bridge", telemetry_metadata) as record:
        console.print(f"[bold cyan]Syncing {adapter_type.value} artifacts from:[/bold cyan] {repo}")

        # For now, Spec-Kit adapter uses legacy sync (will be migrated to bridge)
        if adapter_type != AdapterType.SPECKIT:
            console.print(f"[yellow]⚠ Generic adapter ({adapter_type.value}) not yet fully implemented[/yellow]")
            console.print("[dim]Falling back to Spec-Kit adapter for now[/dim]")
            # TODO: Implement generic adapter sync via bridge
            raise typer.Exit(1)

        # Ensure tool compliance if requested
        if ensure_compliance:
            console.print(f"\n[cyan]🔍 Validating plan bundle for {adapter_type.value} compliance...[/cyan]")
            from specfact_cli.utils.structure import SpecFactStructure
            from specfact_cli.validators.schema import validate_plan_bundle

            # Use provided bundle name or default
            plan_bundle = None
            if bundle:
                from specfact_cli.utils.bundle_loader import load_project_bundle

                bundle_dir = SpecFactStructure.project_dir(repo) / bundle
                if bundle_dir.exists():
                    project_bundle = load_project_bundle(bundle_dir)
                    # Convert to PlanBundle for validation (legacy compatibility)
                    from specfact_cli.commands.plan import _convert_project_bundle_to_plan_bundle

                    plan_bundle = _convert_project_bundle_to_plan_bundle(project_bundle)
                else:
                    console.print(f"[yellow]⚠ Bundle '{bundle}' not found, skipping compliance check[/yellow]")
                    plan_bundle = None
            else:
                # Legacy: Try to find default plan path (for backward compatibility)
                if hasattr(SpecFactStructure, "get_default_plan_path"):
                    plan_path = SpecFactStructure.get_default_plan_path(repo)
                    if plan_path and plan_path.exists():
                        validation_result = validate_plan_bundle(plan_path)
                        if isinstance(validation_result, tuple):
                            is_valid, _error, plan_bundle = validation_result
                            if not is_valid:
                                plan_bundle = None

            if plan_bundle:
                # Check for technology stack in constraints
                has_tech_stack = bool(
                    plan_bundle.idea
                    and plan_bundle.idea.constraints
                    and any(
                        "Python" in c or "framework" in c.lower() or "database" in c.lower()
                        for c in plan_bundle.idea.constraints
                    )
                )

                if not has_tech_stack:
                    console.print("[yellow]⚠ Technology stack not found in constraints[/yellow]")
                    console.print("[dim]Technology stack will be extracted from constraints during sync[/dim]")

                # Check for testable acceptance criteria
                features_with_non_testable = []
                for feature in plan_bundle.features:
                    for story in feature.stories:
                        testable_count = sum(
                            1
                            for acc in story.acceptance
                            if any(
                                keyword in acc.lower()
                                for keyword in ["must", "should", "verify", "validate", "ensure"]
                            )
                        )
                        if testable_count < len(story.acceptance) and len(story.acceptance) > 0:
                            features_with_non_testable.append((feature.key, story.key))

                if features_with_non_testable:
                    console.print(
                        f"[yellow]⚠ Found {len(features_with_non_testable)} stories with non-testable acceptance criteria[/yellow]"
                    )
                    console.print("[dim]Acceptance criteria will be enhanced during sync[/dim]")

                console.print("[green]✓ Plan bundle validation complete[/green]")
            else:
                console.print("[yellow]⚠ Plan bundle not found, skipping compliance check[/yellow]")

        # Resolve repo path to ensure it's absolute and valid (do this once at the start)
        resolved_repo = repo.resolve()
        if not resolved_repo.exists():
            console.print(f"[red]Error:[/red] Repository path does not exist: {resolved_repo}")
            raise typer.Exit(1)
        if not resolved_repo.is_dir():
            console.print(f"[red]Error:[/red] Repository path is not a directory: {resolved_repo}")
            raise typer.Exit(1)

        # Watch mode implementation (using bridge-based watch)
        if watch:
            from specfact_cli.sync.bridge_watch import BridgeWatch

            console.print("[bold cyan]Watch mode enabled[/bold cyan]")
            console.print(f"[dim]Watching for changes every {interval} seconds[/dim]\n")

            # Use bridge-based watch mode
            bridge_watch = BridgeWatch(
                repo_path=resolved_repo,
                bundle_name=bundle,
                interval=interval,
            )

            bridge_watch.watch()
            return

        # Legacy watch mode (for backward compatibility during transition)
        if False:  # Disabled - use bridge watch above
            from specfact_cli.sync.watcher import FileChange, SyncWatcher

            @beartype
            @require(lambda changes: isinstance(changes, list), "Changes must be a list")
            @require(
                lambda changes: all(hasattr(c, "change_type") for c in changes),
                "All changes must have change_type attribute",
            )
            @ensure(lambda result: result is None, "Must return None")
            def sync_callback(changes: list[FileChange]) -> None:
                """Handle file changes and trigger sync."""
                tool_changes = [c for c in changes if c.change_type == "spec_kit"]
                specfact_changes = [c for c in changes if c.change_type == "specfact"]

                if tool_changes or specfact_changes:
                    console.print(f"[cyan]Detected {len(changes)} change(s), syncing...[/cyan]")
                    # Perform one-time sync (bidirectional if enabled)
                    try:
                        # Re-validate resolved_repo before use (may have been cleaned up)
                        if not resolved_repo.exists():
                            console.print(f"[yellow]⚠[/yellow] Repository path no longer exists: {resolved_repo}\n")
                            return
                        if not resolved_repo.is_dir():
                            console.print(
                                f"[yellow]⚠[/yellow] Repository path is no longer a directory: {resolved_repo}\n"
                            )
                            return
                        # Use resolved_repo from outer scope (already resolved and validated)
                        _perform_sync_operation(
                            repo=resolved_repo,
                            bidirectional=bidirectional,
                            bundle=bundle,
                            overwrite=overwrite,
                            adapter_type=adapter_type,
                        )
                        console.print("[green]✓[/green] Sync complete\n")
                    except Exception as e:
                        console.print(f"[red]✗[/red] Sync failed: {e}\n")

            # Use resolved_repo for watcher (already resolved and validated)
            watcher = SyncWatcher(resolved_repo, sync_callback, interval=interval)
            watcher.watch()
            record({"watch_mode": True})
            return

        # Perform sync operation (extracted to avoid recursion in watch mode)
        # Use resolved_repo (already resolved and validated above)
        _perform_sync_operation(
            repo=resolved_repo,
            bidirectional=bidirectional,
            bundle=bundle,
            overwrite=overwrite,
            adapter_type=adapter_type,
        )
        record({"sync_completed": True})


@app.command("repository")
def sync_repository(
    repo: Path = typer.Option(
        Path("."),
        "--repo",
        help="Path to repository",
        exists=True,
        file_okay=False,
        dir_okay=True,
    ),
    target: Path | None = typer.Option(
        None,
        "--target",
        help="Target directory for artifacts (default: .specfact)",
    ),
    watch: bool = typer.Option(
        False,
        "--watch",
        help="Watch mode for continuous sync",
    ),
    interval: int = typer.Option(
        5,
        "--interval",
        help="Watch interval in seconds (default: 5)",
        min=1,
    ),
    confidence: float = typer.Option(
        0.5,
        "--confidence",
        help="Minimum confidence threshold for feature detection (default: 0.5)",
        min=0.0,
        max=1.0,
    ),
) -> None:
    """
    Sync code changes to SpecFact artifacts.

    Monitors repository code changes, updates plan artifacts based on detected
    features/stories, and tracks deviations from manual plans.

    Example:
        specfact sync repository --repo . --confidence 0.5
    """
    from specfact_cli.sync.repository_sync import RepositorySync

    telemetry_metadata = {
        "watch": watch,
        "interval": interval,
        "confidence": confidence,
    }

    with telemetry.track_command("sync.repository", telemetry_metadata) as record:
        console.print(f"[bold cyan]Syncing repository changes from:[/bold cyan] {repo}")

        # Resolve repo path to ensure it's absolute and valid (do this once at the start)
        resolved_repo = repo.resolve()
        if not resolved_repo.exists():
            console.print(f"[red]Error:[/red] Repository path does not exist: {resolved_repo}")
            raise typer.Exit(1)
        if not resolved_repo.is_dir():
            console.print(f"[red]Error:[/red] Repository path is not a directory: {resolved_repo}")
            raise typer.Exit(1)

        if target is None:
            target = resolved_repo / ".specfact"

        sync = RepositorySync(resolved_repo, target, confidence_threshold=confidence)

        if watch:
            from specfact_cli.sync.watcher import FileChange, SyncWatcher

            console.print("[bold cyan]Watch mode enabled[/bold cyan]")
            console.print(f"[dim]Watching for changes every {interval} seconds[/dim]\n")

            @beartype
            @require(lambda changes: isinstance(changes, list), "Changes must be a list")
            @require(
                lambda changes: all(hasattr(c, "change_type") for c in changes),
                "All changes must have change_type attribute",
            )
            @ensure(lambda result: result is None, "Must return None")
            def sync_callback(changes: list[FileChange]) -> None:
                """Handle file changes and trigger sync."""
                code_changes = [c for c in changes if c.change_type == "code"]

                if code_changes:
                    console.print(f"[cyan]Detected {len(code_changes)} code change(s), syncing...[/cyan]")
                    # Perform repository sync
                    try:
                        # Re-validate resolved_repo before use (may have been cleaned up)
                        if not resolved_repo.exists():
                            console.print(f"[yellow]⚠[/yellow] Repository path no longer exists: {resolved_repo}\n")
                            return
                        if not resolved_repo.is_dir():
                            console.print(
                                f"[yellow]⚠[/yellow] Repository path is no longer a directory: {resolved_repo}\n"
                            )
                            return
                        # Use resolved_repo from outer scope (already resolved and validated)
                        result = sync.sync_repository_changes(resolved_repo)
                        if result.status == "success":
                            console.print("[green]✓[/green] Repository sync complete\n")
                        elif result.status == "deviation_detected":
                            console.print(f"[yellow]⚠[/yellow] Deviations detected: {len(result.deviations)}\n")
                        else:
                            console.print(f"[red]✗[/red] Sync failed: {result.status}\n")
                    except Exception as e:
                        console.print(f"[red]✗[/red] Sync failed: {e}\n")

            # Use resolved_repo for watcher (already resolved and validated)
            watcher = SyncWatcher(resolved_repo, sync_callback, interval=interval)
            watcher.watch()
            record({"watch_mode": True})
            return

        # Use resolved_repo (already resolved and validated above)
        # Disable Progress in test mode to avoid LiveError conflicts
        if _is_test_mode():
            # In test mode, just run the sync without Progress
            result = sync.sync_repository_changes(resolved_repo)
        else:
            with Progress(
                SpinnerColumn(),
                TextColumn("[progress.description]{task.description}"),
                console=console,
            ) as progress:
                # Step 1: Detect code changes
                task = progress.add_task("Detecting code changes...", total=None)
                result = sync.sync_repository_changes(resolved_repo)
                progress.update(task, description=f"✓ Detected {len(result.code_changes)} code changes")

                # Step 2: Show plan updates
                if result.plan_updates:
                    task = progress.add_task("Updating plan artifacts...", total=None)
                    total_features = sum(update.get("features", 0) for update in result.plan_updates)
                    progress.update(task, description=f"✓ Updated plan artifacts ({total_features} features)")

                # Step 3: Show deviations
                if result.deviations:
                    task = progress.add_task("Tracking deviations...", total=None)
                    progress.update(task, description=f"✓ Found {len(result.deviations)} deviations")

        # Record sync results
        record(
            {
                "code_changes": len(result.code_changes),
                "plan_updates": len(result.plan_updates) if result.plan_updates else 0,
                "deviations": len(result.deviations) if result.deviations else 0,
            }
        )

        # Report results
        console.print(f"[bold cyan]Code Changes:[/bold cyan] {len(result.code_changes)}")
        if result.plan_updates:
            console.print(f"[bold cyan]Plan Updates:[/bold cyan] {len(result.plan_updates)}")
        if result.deviations:
            console.print(f"[yellow]⚠[/yellow] Found {len(result.deviations)} deviations from manual plan")
            console.print("[dim]Run 'specfact plan compare' for detailed deviation report[/dim]")
        else:
            console.print("[bold green]✓[/bold green] No deviations detected")
        console.print("[bold green]✓[/bold green] Repository sync complete!")
