# Cannot use starred expression here
yield (*x)

yield *x and y, z
