# No expression after `await`, an expression on another line
await

x + y