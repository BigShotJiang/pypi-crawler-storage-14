# Missing closing curly brace 3: Multiple elements without a trailing comma and the next
# token starts a statement.

{1, 2

def foo():
    pass