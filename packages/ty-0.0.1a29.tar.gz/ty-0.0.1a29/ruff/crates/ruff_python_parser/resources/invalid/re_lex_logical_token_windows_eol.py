if call(foo, [a, b
    def bar():
        pass
