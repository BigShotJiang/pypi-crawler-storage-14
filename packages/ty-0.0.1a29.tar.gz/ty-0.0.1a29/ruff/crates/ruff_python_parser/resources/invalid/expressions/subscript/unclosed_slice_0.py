x[:

x + y