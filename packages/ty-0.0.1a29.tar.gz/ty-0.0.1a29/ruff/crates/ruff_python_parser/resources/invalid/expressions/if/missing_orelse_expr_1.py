# Missing orelse expression, followed by an expression
x if expr else

1 + 1