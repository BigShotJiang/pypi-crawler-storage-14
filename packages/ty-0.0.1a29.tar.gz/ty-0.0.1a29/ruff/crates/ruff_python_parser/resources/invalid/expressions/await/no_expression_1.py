# No expression after `await`, a statement on another line
await

def foo():
    pass