# Yield from doesn't allow top-level starred expression unlike yield

yield from *x
yield from *x, y