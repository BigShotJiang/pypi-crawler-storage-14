# Unparenthesized named expressions are not allowed
yield x := 1

yield 1, x := 2, 3
