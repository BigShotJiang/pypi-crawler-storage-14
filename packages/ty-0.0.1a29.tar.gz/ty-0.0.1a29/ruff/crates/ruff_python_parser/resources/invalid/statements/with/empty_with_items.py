# There are no with items present.
# The parser should recover from this syntax error.

with : ...

x + y