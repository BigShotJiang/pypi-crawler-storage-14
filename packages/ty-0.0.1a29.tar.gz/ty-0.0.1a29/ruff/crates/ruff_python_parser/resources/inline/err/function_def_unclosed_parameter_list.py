def foo(a: int, b:
def foo():
    return 42
def foo(a: int, b: str
x = 10
