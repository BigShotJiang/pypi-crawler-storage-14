f"hello {x:} world"
f"hello {x:.3f} world"
