lambda: 1
