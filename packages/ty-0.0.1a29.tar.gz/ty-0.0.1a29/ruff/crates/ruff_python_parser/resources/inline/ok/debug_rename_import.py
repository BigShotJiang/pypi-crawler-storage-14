import __debug__ as debug
from __debug__ import Some
from x import __debug__ as debug
