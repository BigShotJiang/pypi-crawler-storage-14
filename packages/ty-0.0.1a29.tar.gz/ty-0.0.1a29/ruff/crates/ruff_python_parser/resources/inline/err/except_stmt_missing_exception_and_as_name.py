try:
    pass
except as:
    pass
