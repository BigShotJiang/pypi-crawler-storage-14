_
(_)
__
__init__
name
(name)

# Soft keywords used as name
match
case
type
