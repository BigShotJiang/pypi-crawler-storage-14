await x
await x + 1
await a and b
await f()
await [1, 2]
await {3, 4}
await {i: 5}
await 7, 8
await (9, 10)
await 1 == 1
await x if True else None
await (*x,)
await (lambda x: x)
await x ** -x
await x ** await y