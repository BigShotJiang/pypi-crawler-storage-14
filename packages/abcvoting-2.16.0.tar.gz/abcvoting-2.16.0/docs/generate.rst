abcvoting.generate
------------------

.. testsetup::

    from abcvoting.generate import *

.. automodule:: abcvoting.generate
   :members:
   :undoc-members:
