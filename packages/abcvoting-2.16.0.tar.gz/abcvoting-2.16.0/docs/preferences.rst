abcvoting.preferences
---------------------

.. testsetup::

    from abcvoting.preferences import *

.. automodule:: abcvoting.preferences
   :members:
   :undoc-members:
