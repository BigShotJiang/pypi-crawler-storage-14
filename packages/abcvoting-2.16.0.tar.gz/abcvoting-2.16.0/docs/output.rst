abcvoting.output
----------------

.. automodule:: abcvoting.output
   :members:
   :undoc-members:
