abcvoting.abcrules
------------------

.. testsetup::

    from abcvoting.abcrules import *

.. automodule:: abcvoting.abcrules
   :members:
   :undoc-members:

