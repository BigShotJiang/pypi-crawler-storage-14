abcvoting.scores
----------------

.. automodule:: abcvoting.scores
   :members:
   :undoc-members:

