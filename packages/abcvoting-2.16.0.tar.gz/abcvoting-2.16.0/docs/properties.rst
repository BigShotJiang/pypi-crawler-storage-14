abcvoting.properties
--------------------

.. testsetup::

    from abcvoting.properties import *

.. automodule:: abcvoting.properties
   :members:
   :undoc-members:
