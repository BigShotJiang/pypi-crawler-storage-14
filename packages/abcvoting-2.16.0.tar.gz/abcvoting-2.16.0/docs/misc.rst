abcvoting.misc
--------------

.. testsetup::

    from abcvoting.misc import *

.. automodule:: abcvoting.misc
   :members:
   :undoc-members:
