Acknowledgements
================

The following people have contributed code to this package or provided help with technical and
scientific questions (in alphabetic order):

- `Pawel Batko <https://github.com/pbatko>`_,
- `Elvi Cela <https://github.com/elvic96>`_,
- `Piotr Faliszewski <http://home.agh.edu.pl/~faliszew/>`_,
- `Stefan Schlomo Forster <https://github.com/stefanschlomoforster>`_,
- `Andrzej Kaczmarczyk <http://www.user.tu-berlin.de/droores/>`_,
- `Jonas Kompauer <https://github.com/JKompa>`_,
- `Benjamin Krenn <https://github.com/benjaminkrenn>`_,
- `Florian Lackner <https://github.com/Florian-Lackner>`_,
- `Martin Lackner <http://martin.lackner.xyz/>`_,
- `Martin Wustinger <https://github.com/mwustinger>`_,
- `Dominik Peters <http://dominik-peters.de/>`_,
- `Peter Regner <https://github.com/lumbric>`_,
- `Simon Rey <https://simonrey.fr/>`_,
- `Piotr Skowron <https://www.mimuw.edu.pl/~ps219737/>`_,
- `Stanisław Szufa <http://ww2.ii.uj.edu.pl/~szufa/>`_.

The development of this module has been supported by the Austrian Science Fund FWF, grant P31890.
