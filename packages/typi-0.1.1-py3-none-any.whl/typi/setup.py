from typing import Final

from typi.git import GitDependencyInstaller
from typi.typi import TypiConfiguration, Typi
from typi.parser import TypstTomlProjectConfigurationParser

from aiopath import AsyncPath


PROJECT_CONFIG_FILE: Final = "typst.toml"


async def create_typi(*, project_directory: AsyncPath, quiet: bool) -> Typi:
    parser = TypstTomlProjectConfigurationParser.create()
    return Typi.create(
        config=TypiConfiguration(verbose=not quiet),
        project=await parser.parse(project_directory / PROJECT_CONFIG_FILE),
        installer=GitDependencyInstaller.create(parser=parser),
    )
