import asyncio
import typer
from pathlib import Path

from typi.setup import create_typi

from aiopath import AsyncPath

app = typer.Typer(rich_markup_mode="markdown")


async def sync(*, project_directory: AsyncPath, quiet: bool) -> None:
    typi = await create_typi(project_directory=project_directory, quiet=quiet)
    await typi.sync()


@app.command()
def main(
    quiet: bool = typer.Option(False, "--quiet", help="Suppress verbose logging"),
    project_directory: Path = typer.Option(
        Path("."),
        "--project-directory",
        help="Path to the project directory",
        exists=True,
        file_okay=False,
        dir_okay=True,
        writable=True,
    ),
) -> None:
    """
    Install private local packages from git repositories.

    By default, **Typi** looks for a `typi.toml` file in the current working
    directory and installs any dependencies defined under `[tool.typi.dependencies]`
    as local packages.

    ### Example `typi.toml`

    ```toml
    [project]
    name = "my_project"
    version = "0.1.0"
    entrypoint = "main.typ"

    [tool.typi.dependencies]
    my-package = { git = "https://github.com/username/my-package.git" }
    ```

    Running `typi` in the same directory will clone the `my-package` repository
    and install it as a local package.
    """
    asyncio.run(sync(quiet=quiet, project_directory=AsyncPath(project_directory)))


if __name__ == "__main__":
    app()
