import tomllib
from typing import Protocol, TypedDict, cast
from dataclasses import dataclass

from typi.common import Metadata, DependencyInfo

from aiopath import AsyncPath
from async_lru import alru_cache


class DependencyData(TypedDict):
    git: str


class ToolTypiData(TypedDict):
    dependencies: dict[str, DependencyData]


class ToolData(TypedDict):
    typi: ToolTypiData


class MetadataData(TypedDict):
    name: str
    version: str


class TomlData(TypedDict):
    package: MetadataData
    tool: ToolData


class ContentLoader(Protocol):
    async def load(self, path: AsyncPath) -> str:
        """Loads content from the given path asynchronously."""
        ...


class AsyncContentLoader:
    async def load(self, path: AsyncPath) -> str:
        return await self._load(path)

    @staticmethod
    @alru_cache(maxsize=None)
    async def _load(path: AsyncPath) -> str:
        assert await path.exists(), f"Configuration file not found: {path}"

        async with path.open("r", encoding="utf-8") as file:
            return await file.read()


@dataclass(frozen=True)
class TomlProjectConfiguration:
    metadata: Metadata
    dependencies: list[DependencyInfo]


@dataclass(frozen=True)
class TypstTomlProjectConfigurationParser:
    loader: ContentLoader

    @staticmethod
    def create(
        loader: ContentLoader = AsyncContentLoader(),
    ) -> "TypstTomlProjectConfigurationParser":
        return TypstTomlProjectConfigurationParser(loader=loader)

    async def parse(self, path: AsyncPath) -> TomlProjectConfiguration:
        data = cast(TomlData, tomllib.loads(await self.loader.load(path)))

        metadata = self._parse_metadata(data)
        dependencies = await self._parse_dependencies(data)

        return TomlProjectConfiguration(metadata=metadata, dependencies=dependencies)

    async def metadata_from(self, config_file: AsyncPath) -> Metadata:
        return (await self.parse(config_file)).metadata

    def _parse_metadata(self, data: TomlData) -> Metadata:
        project_data = data.get("package", {})
        name = project_data.get("name", "unknown")
        version = project_data.get("version", "0.0.0")

        return Metadata(name=name, version=version)

    async def _parse_dependencies(self, data: TomlData) -> list[DependencyInfo]:
        parsed = []
        tool = data.get("tool", {})
        typi = tool.get("typi", {})

        for name, dependency in typi.get("dependencies", {}).items():
            assert "git" in dependency, "Only git dependencies are supported as of now."

            parsed.append(DependencyInfo(name=name, repository=dependency["git"]))

        return parsed
