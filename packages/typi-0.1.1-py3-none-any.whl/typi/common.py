from dataclasses import dataclass


@dataclass(frozen=True)
class DependencyInfo:
    name: str
    repository: str


@dataclass(frozen=True)
class Metadata:
    name: str
    version: str
