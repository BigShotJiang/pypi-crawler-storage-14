User Guide
==========

This guide will help you get started with OpenFire for fire safety engineering calculations.

.. toctree::
   :maxdepth: 2

   getting-started
   examples