#!/usr/bin/env python
# -*-coding: utf-8 -*-
# ----------------------
# gui.py
# Maximilian Beeskow
# 22.06.2021
# ----------------------
#
# MODULES
from modules.gui_grid import main

# TEST
if __name__ == "__main__":
    main()