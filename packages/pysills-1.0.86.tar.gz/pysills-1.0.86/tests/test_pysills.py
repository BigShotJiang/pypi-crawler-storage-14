from pysills import pysills

pysills()