# Pyarmor 9.2.0 (basic), 009672, 2025-12-01T22:05:17.480219
from .pyarmor_runtime import __pyarmor__
