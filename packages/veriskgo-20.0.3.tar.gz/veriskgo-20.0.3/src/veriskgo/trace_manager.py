from __future__ import annotations
import uuid
import threading
import time
import traceback
import json
import sys
import inspect
from datetime import datetime, timezone
from typing import Optional, Dict, Any
import functools

from .sqs import send_to_sqs

# ============================================================
# Safe Serialization Helpers
# ============================================================

def serialize_value(value: Any) -> Any:
    """Safe JSON serializer."""
    try:
        return json.loads(json.dumps(value, default=str))
    except Exception:
        return str(value)


def safe_locals(d: Dict[str, Any]) -> Dict[str, Any]:
    """Serialize locals safely and strip dunder/private vars."""
    return {k: serialize_value(v) for k, v in d.items() if not k.startswith("_")}


# ============================================================
# Core Trace Manager
# ============================================================

class TraceManager:
    """Centralized trace + span lifecycle manager."""

    _lock = threading.Lock()

    _active: Dict[str, Any] = {
        "trace_id": None,
        "spans": [],
        "stack": [],
    }

    @classmethod
    def finalize_and_send(
        cls,
        *,
        user_id: str,
        session_id: str,
        trace_name: str,
        trace_input: dict,
        trace_output: dict,
        extra_spans: list = [],
    ):
        """Safely finalize the trace and push to SQS."""
        bundle = cls.end_trace()

        if not bundle:
            print("[VeriskGO] ERROR: No trace bundle was created.")
            return False

        if extra_spans:
            bundle["spans"].extend(extra_spans)

        bundle["user_id"] = user_id
        bundle["session_id"] = session_id
        bundle["trace_name"] = trace_name
        bundle["trace_input"] = trace_input
        bundle["trace_output"] = trace_output

        send_to_sqs(bundle)
        print("[VeriskGO] Trace sent.\n")

        return True

    @staticmethod
    def _now() -> str:
        return datetime.now(timezone.utc).isoformat()

    @staticmethod
    def _id() -> str:
        return uuid.uuid4().hex

    # ---------------------------------------------------------
    # Trace API
    # ---------------------------------------------------------
    @classmethod
    def has_active_trace(cls) -> bool:
        return cls._active["trace_id"] is not None

    @classmethod
    def start_trace(cls, name: str, metadata: Optional[Dict[str, Any]] = None) -> str:
        with cls._lock:
            trace_id = cls._id()
            root_id = cls._id()

            root_span = {
                "span_id": root_id,
                "parent_span_id": None,
                "name": name,
                "type": "root",
                "timestamp": cls._now(),
                "input": None,
                "output": None,
                "metadata": metadata or {},
                "duration_ms": 0,
            }

            cls._active["trace_id"] = trace_id
            cls._active["spans"] = [root_span]
            cls._active["stack"] = [{"span_id": root_id, "start": time.time()}]

            return trace_id

    @classmethod
    def end_trace(cls, final_output: Optional[Any] = None) -> Optional[Dict[str, Any]]:
        with cls._lock:
            if not cls._active["trace_id"]:
                return None

            while cls._active["stack"]:
                cls._end_current_span()

            if final_output:
                cls._active["spans"][0]["output"] = final_output

            bundle = {
                "trace_id": cls._active["trace_id"],
                "spans": cls._active["spans"].copy(),
            }

            cls._active["trace_id"] = None
            cls._active["spans"] = []
            cls._active["stack"] = []

            return bundle

    # ---------------------------------------------------------
    # Span API
    # ---------------------------------------------------------
    @classmethod
    def start_span(
        cls,
        name: str,
        input_data: Optional[Any] = None,
        tags: Optional[Dict[str, Any]] = None,
    ) -> Optional[str]:

        with cls._lock:
            if not cls._active["trace_id"]:
                return None

            parent = cls._active["stack"][-1]["span_id"]
            sid = cls._id()

            span = {
                "span_id": sid,
                "parent_span_id": parent,
                "name": name,
                "type": "child",
                "timestamp": cls._now(),
                "input": input_data,
                "metadata": tags or {},
                "output": None,
                "duration_ms": 0,
            }

            cls._active["spans"].append(span)
            cls._active["stack"].append({"span_id": sid, "start": time.time()})

            return sid

    @classmethod
    def end_span(cls, span_id: Optional[str], output_data: Optional[Any] = None):
        with cls._lock:
            if not cls._active["stack"]:
                return

            for i in reversed(range(len(cls._active["stack"]))):
                entry = cls._active["stack"][i]

                if entry["span_id"] == span_id:
                    duration = int((time.time() - entry["start"]) * 1000)
                    cls._active["stack"].pop(i)

                    for sp in cls._active["spans"]:
                        if sp["span_id"] == span_id:
                            sp["duration_ms"] = duration
                            sp["output"] = output_data

                            # --- NEW: Bubble up LLM usage/cost so Langfuse reads them ---
                            if isinstance(output_data, dict):

                                # Langfuse expects flat tokens + cost at span level
                                if "usage" in output_data:
                                    sp["usage"] = output_data["usage"]
                                if "usage_details" in output_data:
                                    sp["usage_details"] = output_data["usage_details"]

                                if "cost" in output_data:
                                    sp["cost"] = output_data["cost"]
                                if "cost_details" in output_data:
                                    sp["cost_details"] = output_data["cost_details"]

                            return

    @classmethod
    def _end_current_span(cls, output_data=None):
        entry = cls._active["stack"].pop()
        sid = entry["span_id"]
        duration = int((time.time() - entry["start"]) * 1000)

        for sp in cls._active["spans"]:
            if sp["span_id"] == sid:
                sp["duration_ms"] = duration
                if output_data:
                    sp["output"] = output_data

                    if isinstance(output_data, dict):
                        if "usage" in output_data:
                            sp["usage"] = output_data["usage"]
                        if "usage_details" in output_data:
                            sp["usage_details"] = output_data["usage_details"]

                        if "cost" in output_data:
                            sp["cost"] = output_data["cost"]
                        if "cost_details" in output_data:
                            sp["cost_details"] = output_data["cost_details"]

                return


# ============================================================
# Helper: frame tracer for exact function internals
# ============================================================

def capture_function_locals(func):
    """
    Perfect B2 mode:
    - captures ONLY the true function frame (entry + exit)
    - avoids caller contamination
    - works in loops, nested calls, async, etc.
    """

    locals_before = {}
    locals_after = {}

    target_code = func.__code__
    target_name = func.__name__
    target_module = func.__module__

    entered = False
    depth = 0

    def tracer(frame, event, arg):
        nonlocal entered, depth

        if frame.f_code.co_name == target_name and frame.f_globals.get("__name__") == target_module:
            if not entered:
                entered = True
                depth = frame.f_lasti
                locals_before.update(safe_locals(frame.f_locals))

            if event == "return":
                locals_after.update(safe_locals(frame.f_locals))
                locals_after["_return"] = serialize_value(arg)

        return tracer

    return tracer, locals_before, locals_after


# ============================================================
# Decorator: track_function (B2 mode)
# ============================================================

def track_function(
    name: Optional[str] = None,
    *,
    tags: Optional[Dict[str, Any]] = None,
    capture_locals: bool = True,
    capture_self: bool = True,
):

    def decorator(func):

        span_name = name or func.__name__
        is_async = inspect.iscoroutinefunction(func)

        # -----------------------------------------------------
        # SYNC WRAPPER
        # -----------------------------------------------------
        def sync_wrapper(*args, **kwargs):

            if not TraceManager.has_active_trace():
                return func(*args, **kwargs)

            # Start span
            span_id = TraceManager.start_span(
                span_name,
                input_data={"args": serialize_value(args), "kwargs": serialize_value(kwargs)},
                tags=tags,
            )

            start = time.time()

            tracer, locals_before, locals_after = capture_function_locals(func)

            sys.settrace(tracer)
            try:
                result = func(*args, **kwargs)
            except Exception as e:
                sys.settrace(None)

                output = {
                    "status": "error",
                    "error": str(e),
                    "stacktrace": traceback.format_exc(),
                    "locals_before": locals_before,
                    "locals_after": locals_after,
                }

                TraceManager.end_span(span_id, output)
                raise

            sys.settrace(None)

            latency = int((time.time() - start) * 1000)

            output = {
                "status": "success",
                "latency_ms": latency,
                "locals_before": locals_before,
                "locals_after": locals_after,
                "output": serialize_value(result),
            }

            TraceManager.end_span(span_id, output)
            return result

        # -----------------------------------------------------
        # ASYNC WRAPPER
        # -----------------------------------------------------
        async def async_wrapper(*args, **kwargs):

            if not TraceManager.has_active_trace():
                return await func(*args, **kwargs)

            span_id = TraceManager.start_span(
                span_name,
                input_data={"args": serialize_value(args), "kwargs": serialize_value(kwargs)},
                tags=tags,
            )

            start = time.time()

            tracer, locals_before, locals_after = capture_function_locals(func)

            sys.settrace(tracer)
            try:
                result = await func(*args, **kwargs)
            except Exception as e:
                sys.settrace(None)

                output = {
                    "status": "error",
                    "error": str(e),
                    "stacktrace": traceback.format_exc(),
                    "locals_before": locals_before,
                    "locals_after": locals_after,
                }

                TraceManager.end_span(span_id, output)
                raise

            sys.settrace(None)

            latency = int((time.time() - start) * 1000)

            output = {
                "status": "success",
                "latency_ms": latency,
                "locals_before": locals_before,
                "locals_after": locals_after,
                "output": serialize_value(result),
            }

            TraceManager.end_span(span_id, output)
            return result

        return functools.wraps(func)(async_wrapper if is_async else sync_wrapper)

    return decorator
