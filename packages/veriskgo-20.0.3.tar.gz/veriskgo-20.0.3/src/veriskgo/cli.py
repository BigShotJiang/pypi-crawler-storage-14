# veriskgo/cli.py

import argparse
from .cli_instrument import instrument_project
from .cli_doctor import main as doctor_main


def main():
    parser = argparse.ArgumentParser(prog="veriskgo")
    parser.add_argument(
        "command",
        help="Available: instrument",
    )
    parser.add_argument(
        "--path",
        type=str,
        default=".",
        help="Root path to instrument (default = current directory)"
    )
    parser.add_argument(
        "--include-private",
        action="store_true",
        help="Instrument private functions"
    )
    parser.add_argument(
        "--exclude",
        nargs="*",
        default=[],
        help="Function names to exclude"
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Preview changes without writing"
    )

    args = parser.parse_args()

    if args.command == "instrument":
        instrument_project(
            root=args.path,
            skip_private=not args.include_private,
            exclude=args.exclude,
            dry_run=args.dry_run
        )
    
    elif args.command == "doctor":
        doctor_main()
    else:
        print(f"Unknown command: {args.command}")
