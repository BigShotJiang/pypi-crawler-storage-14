# seleniumbase package
__version__ = "4.44.18"
