from __future__ import annotations

from datetime import datetime

TIME_ZERO: datetime = datetime.min
