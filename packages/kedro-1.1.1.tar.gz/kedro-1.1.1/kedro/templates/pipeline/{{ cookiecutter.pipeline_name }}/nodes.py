"""
This is a boilerplate pipeline '{{ cookiecutter.pipeline_name }}'
generated using Kedro {{ cookiecutter.kedro_version }}
"""
