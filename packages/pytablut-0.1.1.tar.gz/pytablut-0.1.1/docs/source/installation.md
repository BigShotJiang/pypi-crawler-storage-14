# Installation

```bash
python3 -m pip install pytablut
```
