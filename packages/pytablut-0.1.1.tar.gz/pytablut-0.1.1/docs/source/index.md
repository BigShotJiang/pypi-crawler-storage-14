# Documentation

```{toctree}
:hidden:

installation
```

```{toctree}
:hidden:
:caption: Development

development/documentation.md

apidocs/index
```
