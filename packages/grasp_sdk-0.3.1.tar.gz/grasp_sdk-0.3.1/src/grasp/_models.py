"""Pydantic models for request and response validation."""

from datetime import datetime
from typing import Optional

from pydantic import BaseModel, ConfigDict, Field

from ._types import ProxyType, RecordingStatus, VideoFormat, RecordingQuality


class ProxySettings(BaseModel):
    """Proxy configuration settings."""

    enabled: bool = True
    type: ProxyType
    country: Optional[str] = None
    state: Optional[str] = None
    city: Optional[str] = None


class CreateOptions(BaseModel):
    """Options for creating a new container."""

    model_config = ConfigDict(populate_by_name=True)

    idle_timeout: Optional[int] = Field(None, alias="idleTimeout", description="Idle timeout in milliseconds")
    proxy: Optional[ProxySettings] = None


class BrowserSessionResponse(BaseModel):
    """Browser session information from API response."""

    model_config = ConfigDict(populate_by_name=True)

    ws_endpoint: Optional[str] = Field(None, alias="wsEndpoint")
    live_url: Optional[str] = Field(None, alias="liveURL")


class ContainerResponse(BaseModel):
    """Container information from API response."""

    model_config = ConfigDict(populate_by_name=True)

    id: str
    status: str = "running"
    created_at: Optional[str] = Field(None, alias="createdAt")
    browser: Optional[BrowserSessionResponse] = None


class RecordingStartOptions(BaseModel):
    """Options for starting a new recording."""

    model_config = ConfigDict(populate_by_name=True)

    output_dir: Optional[str] = Field(None, alias="output_dir", description="Custom output directory for the recording file")
    auto_upload: Optional[bool] = Field(False, alias="autoUpload", description="Automatically upload the recording to CDN when finished")
    framerate: Optional[int] = Field(30, description="Frame rate for the recording")
    max_duration: Optional[int] = Field(None, alias="maxDuration", description="Maximum recording duration in milliseconds")
    format: VideoFormat = Field("mp4", description="Video format for the recording")
    resolution: Optional[str] = Field(None, description="Resolution in format 'WIDTHxHEIGHT' (e.g., '1920x1080')")
    audio: Optional[bool] = Field(False, description="Whether to include audio in the recording")
    quality: RecordingQuality = Field("medium", description="Recording quality preset")


class RecordingItem(BaseModel):
    """Recording information."""

    model_config = ConfigDict(populate_by_name=True)

    id: str = Field(alias="recording_id")
    container_id: str = Field(alias="container_id")
    status: RecordingStatus
    error: Optional[str] = None
    local_path: str = Field(alias="output_path")
    cdn_url: Optional[str] = Field(None, alias="cdn_url")
    filename: str
    started_at: str = Field(alias="started_at")
    stopped_at: Optional[str] = Field(None, alias="stopped_at")
    duration_seconds: Optional[float] = Field(None, alias="duration_seconds")
    file_size_bytes: Optional[int] = Field(None, alias="file_size_bytes")
    format: VideoFormat
    framerate: int
    resolution: str