"""Type definitions for the Grasp SDK."""

from typing import Literal, Optional, TypedDict, Union

# Proxy types
ProxyType = Literal["mobile", "residential", "isp", "datacenter", "custom"]

# Container status
ContainerStatus = Literal["running", "stopped", "sleeping", "error"]

# Recording types
RecordingStatus = Literal["recording", "uploading", "finished", "failed"]
VideoFormat = Literal["mp4", "webm", "mkv"]
RecordingQuality = Literal["high", "medium", "low"]


class ProxySettingsDict(TypedDict, total=False):
    """TypedDict for proxy settings."""

    enabled: bool
    type: ProxyType
    country: Optional[str]
    state: Optional[str]
    city: Optional[str]


class CreateOptionsDict(TypedDict, total=False):
    """TypedDict for container creation options."""

    idle_timeout: Optional[int]
    proxy: Optional[ProxySettingsDict]


class RecordingStartOptionsDict(TypedDict, total=False):
    """TypedDict for recording start options."""

    output_dir: Optional[str]
    auto_upload: Optional[bool]
    framerate: Optional[int]
    max_duration: Optional[int]
    format: Optional[VideoFormat]
    resolution: Optional[str]
    audio: Optional[bool]
    quality: Optional[RecordingQuality]