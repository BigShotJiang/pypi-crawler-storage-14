"""
Mudra SDK - Python client for Mudra API
"""

__version__ = "0.1.26"
__author__ = "Foad Khoury"

# Import main classes/functions to make them available at package level

from .models.mudra import Mudra
from .models.mudra_device import MudraDevice
from .service.ble_service import BleService
from .libs.library_loader import load_library, get_mudra_library, get_platform_info

# Define what's available when someone does: from mudra_sdk import *
__all__ = [
    "Mudra",
    "MudraDevice",  
    "BleService",
    "load_library",
    "get_mudra_library",
    "get_platform_info",
    "MudraDelegate",
]