from abc import ABC, abstractmethod

from models.mudra_device import MudraDevice

from typing import Callable

OnBleDeviceDiscovered = Callable[[MudraDevice], None]


class MudraDelegate(ABC):
    @abstractmethod
    def on_device_discovered(self, device: MudraDevice):
        pass

    @abstractmethod
    def on_mudra_device_disconnected(self, device: MudraDevice):
        pass

    @abstractmethod
    def on_mudra_device_disconnecting(self, device: MudraDevice):
        pass

    @abstractmethod
    def on_mudra_device_connected(self, device: MudraDevice):
        pass

    @abstractmethod
    def on_mudra_device_connecting(self, device: MudraDevice):
        pass

    @abstractmethod
    def on_mudra_device_connection_failed(self, device: MudraDevice, error: str):
        pass

    @abstractmethod
    def on_bluetooth_state_changed(self, state: bool):
        pass