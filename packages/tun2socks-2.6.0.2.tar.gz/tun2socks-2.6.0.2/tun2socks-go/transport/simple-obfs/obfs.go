// Package obfs provides obfuscation functionality for Shadowsocks protocol.
package obfs
