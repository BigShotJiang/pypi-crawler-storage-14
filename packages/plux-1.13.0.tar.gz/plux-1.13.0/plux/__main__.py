"""
A plux frontend.
"""

from plux.cli import cli


def main(argv=None):
    cli.main(argv)


if __name__ == "__main__":
    main()
