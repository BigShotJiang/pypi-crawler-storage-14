"""
Python client for AIQA server - OpenTelemetry tracing decorators.
"""

from .tracing import (
    WithTracing,
    flush_spans,
    shutdown_tracing,
    set_span_attribute,
    set_span_name,
    get_active_span,
    provider,
    exporter,
)

__version__ = "0.1.0"

__all__ = [
    "WithTracing",
    "flush_spans",
    "shutdown_tracing",
    "set_span_attribute",
    "set_span_name",
    "get_active_span",
    "provider",
    "exporter",
    "__version__",
]

