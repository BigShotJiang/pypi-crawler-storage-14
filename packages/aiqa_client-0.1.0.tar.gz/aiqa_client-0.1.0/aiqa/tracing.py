"""
OpenTelemetry tracing setup and utilities. Initializes tracer provider on import.
Provides WithTracing decorator to automatically trace function calls.
"""

import os
import json
import logging
import inspect
from typing import Any, Callable, Optional, Dict
from functools import wraps
from opentelemetry import trace
from opentelemetry.sdk.trace import TracerProvider
from opentelemetry.sdk.trace.export import BatchSpanProcessor
from opentelemetry.sdk.resources import Resource
from opentelemetry.semconv.resource import ResourceAttributes
from opentelemetry.trace import Status, StatusCode
from opentelemetry.trace.propagation.tracecontext import TraceContextTextMapPropagator
from .aiqa_exporter import AIQASpanExporter

logger = logging.getLogger(__name__)

# Load environment variables
exporter = AIQASpanExporter()

# Initialize OpenTelemetry
provider = TracerProvider(
    resource=Resource.create(
        {
            ResourceAttributes.SERVICE_NAME: os.getenv("OTEL_SERVICE_NAME", "aiqa-service"),
        }
    )
)

provider.add_span_processor(BatchSpanProcessor(exporter))
trace.set_tracer_provider(provider)

# Get a tracer instance
tracer = trace.get_tracer("aiqa-tracer")


async def flush_spans() -> None:
    """
    Flush all pending spans to the server.
    Flushes also happen automatically every few seconds. So you only need to call this function
    if you want to flush immediately, e.g. before exiting a process.

    This flushes both the BatchSpanProcessor and the exporter buffer.
    """
    provider.force_flush()  # Synchronous method
    await exporter.flush()


async def shutdown_tracing() -> None:
    """
    Shutdown the tracer provider and exporter.
    It is not necessary to call this function.
    """
    provider.shutdown()  # Synchronous method
    await exporter.shutdown()


# Export provider and exporter for advanced usage
__all__ = ["provider", "exporter", "flush_spans", "shutdown_tracing", "WithTracing", "set_span_attribute", "set_span_name", "get_active_span"]


class TracingOptions:
    """Options for WithTracing decorator"""

    def __init__(
        self,
        name: Optional[str] = None,
        ignore_input: Optional[Any] = None,
        ignore_output: Optional[Any] = None,
        filter_input: Optional[Callable[[Any], Any]] = None,
        filter_output: Optional[Callable[[Any], Any]] = None,
    ):
        self.name = name
        self.ignore_input = ignore_input
        self.ignore_output = ignore_output
        self.filter_input = filter_input
        self.filter_output = filter_output


def _serialize_for_span(value: Any) -> Any:
    """
    Serialize a value for span attributes.
    OpenTelemetry only accepts primitives (bool, str, bytes, int, float) or sequences of those.
    Complex types (dicts, lists, objects) are converted to JSON strings.
    """
    # Keep primitives as is (including None)
    if value is None or isinstance(value, (str, int, float, bool, bytes)):
        return value
    
    # For sequences, check if all elements are primitives
    if isinstance(value, (list, tuple)):
        # If all elements are primitives, return as list
        if all(isinstance(item, (str, int, float, bool, bytes, type(None))) for item in value):
            return list(value)
        # Otherwise serialize to JSON string
        try:
            return json.dumps(value)
        except (TypeError, ValueError):
            return str(value)
    
    # For dicts and other complex types, serialize to JSON string
    try:
        return json.dumps(value)
    except (TypeError, ValueError):
        # If JSON serialization fails, convert to string
        return str(value)


def _prepare_input(args: tuple, kwargs: dict) -> Any:
    """Prepare input for span attributes."""
    if not args and not kwargs:
        return None
    if len(args) == 1 and not kwargs:
        return _serialize_for_span(args[0])
    # Multiple args or kwargs - combine into dict
    result = {}
    if args:
        result["args"] = [_serialize_for_span(arg) for arg in args]
    if kwargs:
        result["kwargs"] = {k: _serialize_for_span(v) for k, v in kwargs.items()}
    return result


def WithTracing(
    func: Optional[Callable] = None,
    *,
    name: Optional[str] = None,
    ignore_input: Optional[Any] = None,
    ignore_output: Optional[Any] = None,
    filter_input: Optional[Callable[[Any], Any]] = None,
    filter_output: Optional[Callable[[Any], Any]] = None,
):
    """
    Decorator to automatically create spans for function calls.
    Records input/output as span attributes. Spans are automatically linked via OpenTelemetry context.
    
    Works with both synchronous and asynchronous functions.
    
    Args:
        func: The function to trace (when used as @WithTracing)
        name: Optional custom name for the span (defaults to function name)
        ignore_input: Fields to ignore in input (not yet implemented)
        ignore_output: Fields to ignore in output (not yet implemented)
        filter_input: Function to filter/transform input before recording
        filter_output: Function to filter/transform output before recording
    
    Example:
        @WithTracing
        def my_function(x, y):
            return x + y
        
        @WithTracing
        async def my_async_function(x, y):
            return x + y
        
        @WithTracing(name="custom_name")
        def another_function():
            pass
    """
    def decorator(fn: Callable) -> Callable:
        fn_name = name or fn.__name__ or "_"
        
        # Check if already traced
        if hasattr(fn, "_is_traced"):
            logger.warning(f"Function {fn_name} is already traced, skipping tracing again")
            return fn
        
        is_async = inspect.iscoroutinefunction(fn)
        
        if is_async:
            @wraps(fn)
            async def async_traced_fn(*args, **kwargs):
                span = tracer.start_span(fn_name)
                
                # Prepare input
                input_data = _prepare_input(args, kwargs)
                if filter_input:
                    input_data = filter_input(input_data)
                if ignore_input and isinstance(input_data, dict):
                    # TODO: implement ignore_input logic
                    pass
                
                if input_data is not None:
                    # Serialize for span attributes (OpenTelemetry only accepts primitives or JSON strings)
                    serialized_input = _serialize_for_span(input_data)
                    span.set_attribute("input", serialized_input)
                
                try:
                    # Call the function within the span context
                    trace_id = format(span.get_span_context().trace_id, "032x")
                    logger.debug(f"do traceable stuff {fn_name} {trace_id}")
                    
                    with trace.use_span(span, end_on_exit=False):
                        result = await fn(*args, **kwargs)
                    
                    # Prepare output
                    output_data = result
                    if filter_output:
                        output_data = filter_output(output_data)
                    if ignore_output and isinstance(output_data, dict):
                        # TODO: implement ignore_output logic
                        pass
                    
                    span.set_attribute("output", _serialize_for_span(output_data))
                    span.set_status(Status(StatusCode.OK))
                    
                    return result
                except Exception as exception:
                    error = exception if isinstance(exception, Exception) else Exception(str(exception))
                    span.record_exception(error)
                    span.set_status(Status(StatusCode.ERROR, str(error)))
                    raise
                finally:
                    span.end()
            
            async_traced_fn._is_traced = True
            logger.debug(f"Function {fn_name} is now traced (async)")
            return async_traced_fn
        else:
            @wraps(fn)
            def sync_traced_fn(*args, **kwargs):
                span = tracer.start_span(fn_name)
                
                # Prepare input
                input_data = _prepare_input(args, kwargs)
                if filter_input:
                    input_data = filter_input(input_data)
                if ignore_input and isinstance(input_data, dict):
                    # TODO: implement ignore_input logic
                    pass
                
                if input_data is not None:
                    # Serialize for span attributes (OpenTelemetry only accepts primitives or JSON strings)
                    serialized_input = _serialize_for_span(input_data)
                    span.set_attribute("input", serialized_input)
                
                try:
                    # Call the function within the span context
                    trace_id = format(span.get_span_context().trace_id, "032x")
                    logger.debug(f"do traceable stuff {fn_name} {trace_id}")
                    
                    with trace.use_span(span, end_on_exit=False):
                        result = fn(*args, **kwargs)
                    
                    # Prepare output
                    output_data = result
                    if filter_output:
                        output_data = filter_output(output_data)
                    if ignore_output and isinstance(output_data, dict):
                        # TODO: implement ignore_output logic
                        pass
                    
                    span.set_attribute("output", _serialize_for_span(output_data))
                    span.set_status(Status(StatusCode.OK))
                    
                    return result
                except Exception as exception:
                    error = exception if isinstance(exception, Exception) else Exception(str(exception))
                    span.record_exception(error)
                    span.set_status(Status(StatusCode.ERROR, str(error)))
                    raise
                finally:
                    span.end()
            
            sync_traced_fn._is_traced = True
            logger.debug(f"Function {fn_name} is now traced (sync)")
            return sync_traced_fn
    
    # Support both @WithTracing and @WithTracing(...) syntax
    if func is None:
        return decorator
    else:
        return decorator(func)


def set_span_attribute(attribute_name: str, attribute_value: Any) -> bool:
    """
    Set an attribute on the active span.
    
    Returns:
        True if attribute was set, False if no active span found
    """
    span = trace.get_current_span()
    if span and span.is_recording():
        span.set_attribute(attribute_name, _serialize_for_span(attribute_value))
        return True
    return False

def set_span_name(span_name: str) -> bool:
    """
    Set the name of the active span.
    """
    span = trace.get_current_span()
    if span and span.is_recording():
        span.set_name(span_name)
        return True
    return False

def get_active_span() -> Optional[trace.Span]:
    """Get the currently active span."""
    return trace.get_current_span()

