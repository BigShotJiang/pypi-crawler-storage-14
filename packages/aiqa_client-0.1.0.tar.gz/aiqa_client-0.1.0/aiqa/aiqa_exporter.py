"""
OpenTelemetry span exporter that sends spans to the AIQA server API.
Buffers spans and flushes them periodically or on shutdown. Thread-safe.
"""

import os
import json
import logging
import threading
import time
from typing import List, Dict, Any, Optional
from opentelemetry.sdk.trace import ReadableSpan
from opentelemetry.sdk.trace.export import SpanExporter, SpanExportResult

logger = logging.getLogger(__name__)


class AIQASpanExporter(SpanExporter):
    """
    Exports spans to AIQA server. Buffers spans and auto-flushes every flush_interval_seconds.
    Call shutdown() before process exit to flush remaining spans.
    """

    def __init__(
        self,
        server_url: Optional[str] = None,
        api_key: Optional[str] = None,
        flush_interval_seconds: float = 5.0,
    ):
        """
        Initialize the AIQA span exporter.

        Args:
            server_url: URL of the AIQA server (defaults to AIQA_SERVER_URL env var)
            api_key: API key for authentication (defaults to AIQA_API_KEY env var)
            flush_interval_seconds: How often to flush spans to the server
        """
        self._server_url = server_url
        self._api_key = api_key
        self.flush_interval_ms = flush_interval_seconds * 1000
        self.buffer: List[Dict[str, Any]] = []
        self.buffer_lock = threading.Lock()
        self.flush_lock = threading.Lock()
        self.shutdown_requested = False
        self.flush_timer: Optional[threading.Thread] = None
        self._start_auto_flush()

    @property
    def server_url(self) -> str:         
        return self._server_url or os.getenv("AIQA_SERVER_URL", "").rstrip("/")

    @property
    def api_key(self) -> str:
        return self._api_key or os.getenv("AIQA_API_KEY", "")

    def export(self, spans: List[ReadableSpan]) -> SpanExportResult:
        """
        Export spans to the AIQA server. Adds spans to buffer for async flushing.
        """
        if not spans:
            return SpanExportResult.SUCCESS

        # Serialize and add to buffer
        with self.buffer_lock:
            serialized_spans = [self._serialize_span(span) for span in spans]
            self.buffer.extend(serialized_spans)

        return SpanExportResult.SUCCESS

    def _serialize_span(self, span: ReadableSpan) -> Dict[str, Any]:
        """Convert ReadableSpan to a serializable format."""
        span_context = span.get_span_context()
        
        # Get parent span ID
        parent_span_id = None
        if hasattr(span, "parent") and span.parent:
            parent_span_id = format(span.parent.span_id, "016x")
        elif hasattr(span, "parent_span_id") and span.parent_span_id:
            parent_span_id = format(span.parent_span_id, "016x")
        
        # Get span kind (handle both enum and int)
        span_kind = span.kind
        if hasattr(span_kind, "value"):
            span_kind = span_kind.value
        
        # Get status code (handle both enum and int)
        status_code = span.status.status_code
        if hasattr(status_code, "value"):
            status_code = status_code.value
        
        return {
            "name": span.name,
            "kind": span_kind,
            "parentSpanId": parent_span_id,
            "startTime": self._time_to_tuple(span.start_time),
            "endTime": self._time_to_tuple(span.end_time) if span.end_time else None,
            "status": {
                "code": status_code,
                "message": getattr(span.status, "description", None),
            },
            "attributes": dict(span.attributes) if span.attributes else {},
            "links": [
                {
                    "context": {
                        "traceId": format(link.context.trace_id, "032x"),
                        "spanId": format(link.context.span_id, "016x"),
                    },
                    "attributes": dict(link.attributes) if link.attributes else {},
                }
                for link in (span.links or [])
            ],
            "events": [
                {
                    "name": event.name,
                    "time": self._time_to_tuple(event.timestamp),
                    "attributes": dict(event.attributes) if event.attributes else {},
                }
                for event in (span.events or [])
            ],
            "resource": {
                "attributes": dict(span.resource.attributes) if span.resource.attributes else {},
            },
            "traceId": format(span_context.trace_id, "032x"),
            "spanId": format(span_context.span_id, "016x"),
            "traceFlags": span_context.trace_flags,
            "duration": self._time_to_tuple(span.end_time - span.start_time) if span.end_time else None,
            "ended": span.end_time is not None,
            "instrumentationLibrary": {
                "name": span.instrumentation_info.name if hasattr(span, "instrumentation_info") else "",
                "version": span.instrumentation_info.version if hasattr(span, "instrumentation_info") else None,
            },
        }

    def _time_to_tuple(self, nanoseconds: int) -> tuple:
        """Convert nanoseconds to (seconds, nanoseconds) tuple."""
        seconds = int(nanoseconds // 1_000_000_000)
        nanos = int(nanoseconds % 1_000_000_000)
        return (seconds, nanos)

    async def flush(self) -> None:
        """
        Flush buffered spans to the server. Thread-safe: ensures only one flush operation runs at a time.
        """
        with self.flush_lock:
            # Get current buffer and clear it atomically
            with self.buffer_lock:
                spans_to_flush = self.buffer[:]
                self.buffer.clear()

            if not spans_to_flush:
                return

            # Skip sending if server URL is not configured
            if not self.server_url:
                logger.warning(
                    f"Skipping flush: AIQA_SERVER_URL is not set. {len(spans_to_flush)} span(s) will not be sent."
                )
                return

            try:
                await self._send_spans(spans_to_flush)
            except Exception as error:
                logger.error(f"Error flushing spans to server: {error}")
                if self.shutdown_requested:
                    raise

    def _start_auto_flush(self) -> None:
        """Start the auto-flush timer."""
        if self.shutdown_requested:
            return

        def flush_worker():
            import asyncio
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
            
            while not self.shutdown_requested:
                try:
                    loop.run_until_complete(self.flush())
                    time.sleep(self.flush_interval_ms / 1000.0)
                except Exception as e:
                    logger.error(f"Error in auto-flush: {e}")
                    time.sleep(self.flush_interval_ms / 1000.0)
            
            # Final flush on shutdown
            if self.shutdown_requested:
                try:
                    loop.run_until_complete(self.flush())
                except Exception as e:
                    logger.error(f"Error in final flush: {e}")
                finally:
                    loop.close()

        flush_thread = threading.Thread(target=flush_worker, daemon=True)
        flush_thread.start()
        self.flush_timer = flush_thread

    async def _send_spans(self, spans: List[Dict[str, Any]]) -> None:
        """Send spans to the server API."""
        if not self.server_url:
            raise ValueError("AIQA_SERVER_URL is not set. Cannot send spans to server.")

        import aiohttp

        logger.debug(f"Sending {len(spans)} spans to server: {self.server_url}")

        headers = {
            "Content-Type": "application/json",
        }
        if self.api_key:
            headers["Authorization"] = f"ApiKey {self.api_key}"

        async with aiohttp.ClientSession() as session:
            async with session.post(
                f"{self.server_url}/span",
                json=spans,
                headers=headers,
            ) as response:
                if not response.ok:
                    error_text = await response.text()
                    raise Exception(
                        f"Failed to send spans: {response.status} {response.reason} - {error_text}"
                    )

    def shutdown(self) -> None:
        """Shutdown the exporter, flushing any remaining spans. Call before process exit."""
        self.shutdown_requested = True

        # Wait for flush thread to finish (it will do final flush)
        if self.flush_timer and self.flush_timer.is_alive():
            self.flush_timer.join(timeout=10.0)

        # Final flush attempt (synchronous)
        import asyncio
        try:
            loop = asyncio.get_event_loop()
            if loop.is_running():
                # If loop is running, schedule flush
                import concurrent.futures
                with concurrent.futures.ThreadPoolExecutor() as executor:
                    future = executor.submit(asyncio.run, self.flush())
                    future.result(timeout=10.0)
            else:
                loop.run_until_complete(self.flush())
        except RuntimeError:
            # No event loop, create one
            asyncio.run(self.flush())

