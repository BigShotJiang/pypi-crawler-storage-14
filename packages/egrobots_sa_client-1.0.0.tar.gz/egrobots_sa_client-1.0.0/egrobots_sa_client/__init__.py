"""
Egrobots SA Client

Python client for Arabic Speech Analysis service.
"""

from .client import EgrobotsSSAClient

__all__ = ["EgrobotsSSAClient"]

# Read version from VERSION file
try:
    from pathlib import Path
    _version_file = Path(__file__).parent.parent / "VERSION"
    __version__ = _version_file.read_text().strip()
except Exception:
    __version__ = "1.0.0"
