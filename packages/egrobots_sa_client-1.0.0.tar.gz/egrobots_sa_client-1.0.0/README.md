# Egrobots SA Client

Python client for Egrobots Arabic Speech Sentiment Analysis service.

## Installation

```bash
pip install egrobots-sa-client
```

## Quick Start

```python
from egrobots_sa_client import EgrobotsSSAClient

client = EgrobotsSSAClient()

# Batch processing
result = client.batch_process(
    audio_path="audio.mp3",
    endpoint="sentiment",  # or "conversation"
    enable_translation=False
)
```

## Configuration

Create a `.env` file:

```env
WEBSOCKET_URL=wss://your-service.com/ws/stream-sentiment
BASE_URL=https://your-service.com
```

## Documentation

See [CLIENT_USAGE.md](CLIENT_USAGE.md) for full documentation.

## License

MIT
