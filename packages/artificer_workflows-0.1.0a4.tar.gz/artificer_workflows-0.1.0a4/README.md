# artificer-workflows

A library for developing workflow graphs that run as MCP (Model Context Protocol) servers.

> **Alpha Release** - APIs may change.

## Installation

```bash
pip install artificer-workflows
```

## License

MIT
