APP_NAME = "artificer"
