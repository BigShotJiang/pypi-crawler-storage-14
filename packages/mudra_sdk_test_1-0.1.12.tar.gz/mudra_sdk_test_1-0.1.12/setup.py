from setuptools import setup, find_packages

setup(
    name="mudra_sdk_test_1",
    version="0.1.12",  
    packages=find_packages(),
    install_requires=[],
    include_package_data=True,
    author="Foad Khoury",
    description="Mudra SDK",
    python_requires=">=3.7",
)