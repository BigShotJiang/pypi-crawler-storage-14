# sage_setup: distribution = sagemath-kenzo

from sage.all__sagemath_kenzo import *
