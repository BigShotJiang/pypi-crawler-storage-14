"""
Malha Services
==============

Higher-level services built on top of the Malha kernel.

Services:
- TopologySyncService: Materializes graph topology from external data sources (Helix pattern)
"""

from .sync_service import TopologySyncService, generate_virtual_rid

__all__ = ["TopologySyncService", "generate_virtual_rid"]
