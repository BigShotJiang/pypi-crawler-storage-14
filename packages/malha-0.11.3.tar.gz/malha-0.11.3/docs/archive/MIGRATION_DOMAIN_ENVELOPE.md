# Guia de Migração: Padrão Domain Envelope

## 📋 Resumo

A `malha` foi refatorada para alinhar-se ao padrão **Domain Envelope** implementado no `registro` v0.6.0+. Esta mudança elimina a duplicação de lógica de mapeamento objeto-relacional e estabelece uma separação clara entre:

- **Camada Física (Envelope)**: `Resource` do `registro` - tabela SQL rígida e otimizada
- **Camada Lógica (Domínio)**: `DomainResource` - objetos Python/Pydantic puros e flexíveis

## 🎯 Motivação

### Problema Anterior
A `malha` tinha sua própria classe `BaseResource` que tentava resolver o **Conflito de Impedância** entre SQL e objetos de domínio. Isso criava:
- Duplicação de código com o `registro`
- Dois "tipos base" concorrentes
- Violação do princípio DRY

### Solução Atual
O `registro` agora implementa oficialmente o padrão Envelope:
- `Resource` (SQLModel, `table=True`) - envelope físico com colunas fixas + `meta_tags` JSON
- `DomainResource` (Pydantic puro, `table=False`) - objeto lógico com validação rica
- Métodos `to_envelope()` / `from_envelope()` para conversão bidirecional

## 🔄 Mudanças Principais

### 1. Imports Atualizados

**Antes:**
```python
from malha import BaseResource
```

**Depois:**
```python
from registro import DomainResource
```

### 2. Definição de Recursos de Domínio

**Antes:**
```python
from malha import BaseResource

class User(BaseResource):
    name: str
    email: str
    age: int
```

**Depois:**
```python
from registro import DomainResource

class User(DomainResource):
    name: str
    email: str
    age: int
```

**Nota:** O `DomainResource` já inclui campos base (`rid`, `version`, `created_at`, etc.) e implementa `to_envelope()` / `from_envelope()` automaticamente.

### 3. Repositórios

Os repositórios agora operam **transparentemente** no padrão Domain Envelope:

```python
# Definir repositório (sem mudanças na API)
repo = kernel.get_repository(User)

# Criar (recebe dict ou DomainResource, retorna DomainResource)
user = await repo.create(session, {"name": "Alice", "email": "alice@example.com"})

# Buscar (retorna DomainResource hidratado)
user = await repo.get(session, id=1)

# Atualizar (trabalha com DomainResource)
updated = await repo.update(session, id=1, data={"age": 30})

# Listar (retorna lista de DomainResource)
users = await repo.list(session, skip=0, limit=10)
```

**Internamente:**
- Queries são feitas na tabela física (`Resource`)
- Resultados são hidratados via `from_envelope()`
- Saves convertem via `to_envelope()`

### 4. UnifiedDataManager

#### save_versioned()

**Antes:**
```python
# Recebia RegistroResource
await kernel.save_versioned(obj=registro_resource)
```

**Depois:**
```python
# Recebe DomainResource
user = User(name="Bob", email="bob@example.com")
saved_user = await kernel.save_versioned(obj=user)
```

**Comportamento:**
1. Recebe `DomainResource`
2. Converte para envelope físico via `to_envelope()`
3. Opera na tabela `Resource` (SCD Type 2)
4. Retorna `DomainResource` hidratado

#### delete_versioned()

**Antes:**
```python
await kernel.delete_versioned(obj=registro_resource)
```

**Depois:**
```python
user = User(rid="ri.myapp.prod.user.123")
await kernel.delete_versioned(obj=user)
```

### 5. Interceptors

**Antes:**
```python
class MyInterceptor(Interceptor):
    async def on_write(self, obj: RegistroResource, agent=None):
        # obj era RegistroResource
        pass
```

**Depois:**
```python
class MyInterceptor(Interceptor):
    async def on_write(self, obj: DomainResource, agent=None):
        # obj agora é DomainResource (rico, com validação)
        if isinstance(obj, User):
            # Validação específica de domínio
            if not obj.email.endswith("@company.com"):
                raise ValidationError("Email must be corporate")
```

**Vantagem:** Interceptors agora trabalham com objetos de domínio ricos, permitindo validação e transformação na camada lógica.

### 6. Outbox Processing

O processador de outbox agora usa o **Global Registry** do `registro`:

```python
# Antes: usava kernel._model_registry local
model_cls = self._model_registry.get(model_name)

# Depois: usa global_registry do registro
from registro import registry as global_registry
model_cls = global_registry.get(model_name)
```

**Fallbacks:**
1. Global registry do `registro`
2. Local `_model_registry` (compatibilidade)
3. `DomainResource` genérico (se classe não encontrada)

### 7. Replicação (Synapse)

O `SynapseDriver` agora instancia `DomainResource` ao receber eventos remotos:

```python
# Antes
from registro import Resource as RegistroResource
resource = RegistroResource(**payload_dict)

# Depois
from registro import DomainResource, registry as global_registry
model_cls = global_registry.get(model_name) or DomainResource
resource = model_cls(**payload_dict)
```

## 🚀 Guia de Migração Passo a Passo

### Passo 1: Atualizar Definições de Recursos

```python
# Antes
from malha import BaseResource

class Product(BaseResource):
    name: str
    price: float
    stock: int

# Depois
from registro import DomainResource

class Product(DomainResource):
    name: str
    price: float
    stock: int
```

### Passo 2: Registrar Recursos no Global Registry

```python
from registro import register

# Registrar para que o outbox processor e synapse encontrem a classe
register("Product", Product)
register("User", User)
```

### Passo 3: Atualizar Interceptors (se houver)

```python
# Antes
class AuditInterceptor(Interceptor):
    async def on_write(self, obj: RegistroResource, agent=None):
        logger.info(f"Saving {obj.__class__.__name__}")

# Depois
class AuditInterceptor(Interceptor):
    async def on_write(self, obj: DomainResource, agent=None):
        # Agora pode acessar campos de domínio diretamente
        logger.info(f"Saving {obj.__class__.__name__}: {obj.rid}")
```

### Passo 4: Atualizar Testes

```python
# Antes
from malha import BaseResource

class TestResource(BaseResource):
    name: str

# Depois
from registro import DomainResource

class TestResource(DomainResource):
    name: str
```

## 📊 Comparação: Antes vs Depois

| Aspecto | Antes | Depois |
|---------|-------|--------|
| **Classe Base** | `malha.BaseResource` | `registro.DomainResource` |
| **Tabela SQL** | `BaseResource` tentava ser ambos | `Resource` (envelope físico) |
| **Conversão** | `to_record()` / `from_record()` | `to_envelope()` / `from_envelope()` |
| **Registry** | Local `_model_registry` | Global `registro.registry` |
| **Interceptors** | Operavam em `RegistroResource` | Operam em `DomainResource` |
| **Repositórios** | Queries em `model_cls` | Queries em `Resource`, hidratam para `DomainResource` |

## ✅ Checklist de Migração

- [ ] Substituir `from malha import BaseResource` por `from registro import DomainResource`
- [ ] Atualizar todas as classes de recursos para herdar de `DomainResource`
- [ ] Registrar recursos no global registry via `registro.register()`
- [ ] Atualizar interceptors para trabalhar com `DomainResource`
- [ ] Atualizar testes para usar `DomainResource`
- [ ] Remover referências a `to_record()` / `from_record()` (agora `to_envelope()` / `from_envelope()`)
- [ ] Verificar que `save_versioned()` e `delete_versioned()` recebem `DomainResource`

## 🎓 Conceitos Importantes

### Domain Envelope Pattern

```
┌─────────────────────────────────────────┐
│         Camada de Domínio               │
│  (DomainResource - Pydantic Puro)       │
│  - Validação rica                       │
│  - Tipos complexos (listas, grafos)     │
│  - Campos dinâmicos                     │
└──────────────┬──────────────────────────┘
               │ to_envelope()
               ▼
┌─────────────────────────────────────────┐
│         Camada Física                   │
│  (Resource - SQLModel table=True)       │
│  - Colunas SQL fixas                    │
│  - meta_tags (JSONB) para extras        │
│  - Otimizado para indexação             │
└─────────────────────────────────────────┘
```

### Fluxo de Dados

**Escrita:**
```
DomainResource → to_envelope() → Resource → SQL INSERT
```

**Leitura:**
```
SQL SELECT → Resource → from_envelope() → DomainResource
```

## 🐛 Troubleshooting

### Erro: "Model class not found in registry"

**Causa:** Classe de domínio não registrada no global registry.

**Solução:**
```python
from registro import register

register("MyResource", MyResource)
```

### Erro: "AttributeError: 'Resource' object has no attribute 'my_field'"

**Causa:** Tentando acessar campo de domínio diretamente no envelope físico.

**Solução:** Use `from_envelope()` para hidratar:
```python
# Errado
physical_record.my_custom_field  # Não existe em Resource

# Certo
domain_obj = MyResource.from_envelope(physical_record)
domain_obj.my_custom_field  # Funciona!
```

### Erro: "TypeError: to_record() missing"

**Causa:** Código antigo tentando usar `to_record()`.

**Solução:** Substitua por `to_envelope()`:
```python
# Antes
physical = obj.to_record()

# Depois
physical = obj.to_envelope()
```

## 📚 Recursos Adicionais

- [Documentação do Registro](https://github.com/yourusername/registro)
- [Padrão Domain Envelope](https://martinfowler.com/eaaCatalog/dataTransferObject.html)
- [Pydantic Documentation](https://docs.pydantic.dev/)

## 🤝 Contribuindo

Se encontrar problemas durante a migração ou tiver sugestões de melhorias, abra uma issue no repositório.

---

**Versão da Malha:** v0.4.0+  
**Versão do Registro:** v0.6.0+  
**Data:** 2024-11-24
