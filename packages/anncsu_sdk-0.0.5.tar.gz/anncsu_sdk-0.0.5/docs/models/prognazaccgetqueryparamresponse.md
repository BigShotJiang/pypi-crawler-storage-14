# PrognazaccGetQueryParamResponse

Successful operation


## Fields

| Field                                                                                | Type                                                                                 | Required                                                                             | Description                                                                          | Example                                                                              |
| ------------------------------------------------------------------------------------ | ------------------------------------------------------------------------------------ | ------------------------------------------------------------------------------------ | ------------------------------------------------------------------------------------ | ------------------------------------------------------------------------------------ |
| `res`                                                                                | *Optional[str]*                                                                      | :heavy_minus_sign:                                                                   | N/A                                                                                  | elencoodonimiprog                                                                    |
| `data`                                                                               | List[[models.PrognazaccGetQueryParamData](../models/prognazaccgetqueryparamdata.md)] | :heavy_minus_sign:                                                                   | N/A                                                                                  |                                                                                      |