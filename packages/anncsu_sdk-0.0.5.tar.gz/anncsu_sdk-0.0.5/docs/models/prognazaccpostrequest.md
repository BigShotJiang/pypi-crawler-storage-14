# PrognazaccPostRequest

search input data


## Fields

| Field              | Type               | Required           | Description        | Example            |
| ------------------ | ------------------ | ------------------ | ------------------ | ------------------ |
| `req`              | *Optional[str]*    | :heavy_minus_sign: | N/A                | prognazacc         |
| `prognazacc`       | *Optional[str]*    | :heavy_minus_sign: | N/A                | 6744962            |