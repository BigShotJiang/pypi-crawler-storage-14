# PrognazareaPostRequest

search input data


## Fields

| Field              | Type               | Required           | Description        | Example            |
| ------------------ | ------------------ | ------------------ | ------------------ | ------------------ |
| `req`              | *Optional[str]*    | :heavy_minus_sign: | N/A                | prognazarea        |
| `prognaz`          | *Optional[str]*    | :heavy_minus_sign: | N/A                | 919572             |