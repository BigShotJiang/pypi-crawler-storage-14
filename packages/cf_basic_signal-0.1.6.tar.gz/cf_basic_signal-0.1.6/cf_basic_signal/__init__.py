"""
cf_basic_signal package

Besides the Cogniflow StepPackage entrypoint, this package can act as a
pipeline_backend plugin by registering its Python ops on import when the
backend is available.
"""

from .pipeline_backend_plugin import register_pipeline_backend_ops

# Best-effort auto-registration for pipeline_backend users. This is a no-op
# when the compiled backend is not installed.
register_pipeline_backend_ops()

__all__ = ["register_pipeline_backend_ops"]
