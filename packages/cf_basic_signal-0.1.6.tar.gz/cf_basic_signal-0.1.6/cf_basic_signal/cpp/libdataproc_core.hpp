// Basic signal algorithms for cf_basic_signal package.
#pragma once

#include <cstddef>
#include <string>
#include <vector>

namespace cf_basic_signal {

double vector_sum(const std::vector<double>& values);

std::vector<double> fifo_window_buffer(const std::vector<double>& new_samples, std::size_t window_size,
                                       const std::string& fifo_id);

struct AverageResult {
    double mean;
    double standard_error;
};

AverageResult average(const std::vector<double>& values, const std::string& method,
                      const std::vector<double>* weights = nullptr);

void reset_fifo(const std::string& fifo_id);
void reset_all_fifos();

}  // namespace cf_basic_signal
