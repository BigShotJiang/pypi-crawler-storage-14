# cf.basic.signal StepPackage

Basic IO + signal-processing steps packaged for Cogniflow (InlineSource, HandleSink, FIFO buffer, averages, optional OPC UA source).

## Steps
- `cf:InlineSource` - emit inline payload (JSON if prefixed with inline://)
- `cf:HandleSinkStep` - stub sink that forwards to a handle (duckdb://, parquet://, inline://, etc.)
- `cf:FifoWindowBufferStep` - windowed buffer
- `cf:AverageStep` - arithmetic / geometric / harmonic mean
- `cf:OpcuaPhSource` - virtual OPC UA pH source

## Files
- `cf-step-package.yaml` - manifest
- `steps.ttl` - ontology fragment for the steps
- `cf_basic_signal/steps.py` - implementations (with optional C++ backend for signal ops)
- `examples/inline_to_sink.json` - minimal IO pipeline (InlineSource -> HandleSinkStep)
- `examples/golden_fifo_avg.json` - minimal signal pipeline (InlineSource -> FIFO -> Average)

## Pipeline backend plugin

The package now registers itself as a `pipeline_backend` plugin (Python ops):
- Ops: `inline_source`, `handle_sink`, `fifo_window_buffer`, `average`, `opcua_ph_source`
- Metadata: `pipeline_plugin.json` (api_version=1, Data ABI `Data-v1`)
- Importing `cf_basic_signal` will auto-register these ops when `pipeline_backend` is installed.

## Quick check
1) Install package:
```python
from core.step_package_manager import StepPackageManager
m = StepPackageManager("path/to/gui_sandbox.duckdb")
m.install_from_manifest("sand_toys/cf_basic_steps/cf_basic_signal/cf_basic_signal/cf-step-package.yaml")
```
2) Load server and verify:
```python
from core.algorithm_server import AlgorithmServer
s = AlgorithmServer("path/to/gui_sandbox.duckdb")
assert s.step_registry.has_step("cf:InlineSource")
assert s.step_registry.has_step("cf:HandleSinkStep")
assert s.step_registry.has_step("cf:FifoWindowBufferStep")
assert s.step_registry.has_step("cf:AverageStep")
```
3) Run the example pipelines via your runner. Expected outputs:
   - inline_to_sink: status `"handled via inline://dev-null"`
   - golden_fifo_avg: window `[4,5,6]`, mean `5.0`, small SE.

## Wheel builds & publishing
- Wheels are built with `cibuildwheel` for CPython 3.9-3.12 across Windows, Linux, and macOS (config in `pyproject.toml`).
- The workflow builds the single `cf-basic-signal` wheel (now including IO steps) and uploads it as an artifact.
- PyPI/TestPyPI publishing happens on tagged pushes via the trusted publisher action (`pypa/gh-action-pypi-publish`).
