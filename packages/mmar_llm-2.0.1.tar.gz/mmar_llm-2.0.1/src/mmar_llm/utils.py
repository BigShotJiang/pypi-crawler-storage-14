import tiktoken

from mmar_mapi.api import LLMPayload


def count_tokens(sentences: list[str]) -> list[int]:
    encoding = tiktoken.get_encoding("cl100k_base")
    return [len(encoding.encode(sentence)) for sentence in sentences]


# todo specify better type
def dump_messages(payload: LLMPayload) -> list[dict]:
    messages_json = [{"role": msg.role, "content": msg.content} for msg in payload.messages]
    return messages_json
