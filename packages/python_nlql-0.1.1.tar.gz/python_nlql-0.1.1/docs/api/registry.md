# Registry API Reference

## Functions

::: nlql.registry.functions.register_function
    options:
      show_source: true
      heading_level: 3

::: nlql.registry.functions.get_function
    options:
      show_source: true
      heading_level: 3

## Operators

::: nlql.registry.operators.register_operator
    options:
      show_source: true
      heading_level: 3

::: nlql.registry.operators.get_operator
    options:
      show_source: true
      heading_level: 3

## Splitters

::: nlql.registry.splitters.register_splitter
    options:
      show_source: true
      heading_level: 3

::: nlql.registry.splitters.get_splitter
    options:
      show_source: true
      heading_level: 3

## Embedding

::: nlql.registry.embedding.register_embedding_provider
    options:
      show_source: true
      heading_level: 3

::: nlql.registry.embedding.get_embedding_provider
    options:
      show_source: true
      heading_level: 3

