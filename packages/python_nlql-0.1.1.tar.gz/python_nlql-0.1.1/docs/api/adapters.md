# Adapters API Reference

::: nlql.adapters.base.BaseAdapter
    options:
      show_source: true
      heading_level: 2

::: nlql.adapters.base.QueryPlan
    options:
      show_source: true
      heading_level: 2

::: nlql.adapters.memory.MemoryAdapter
    options:
      show_source: true
      heading_level: 2

