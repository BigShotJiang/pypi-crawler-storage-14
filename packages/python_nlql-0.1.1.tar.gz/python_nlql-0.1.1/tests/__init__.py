"""Tests for NLQL."""

