"""Version information for NLQL."""

__version__ = "0.1.0"

