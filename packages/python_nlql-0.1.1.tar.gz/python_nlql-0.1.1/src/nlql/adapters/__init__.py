"""Data source adapters for NLQL."""

from nlql.adapters.base import BaseAdapter
from nlql.adapters.memory import MemoryAdapter

__all__ = [
    "BaseAdapter",
    "MemoryAdapter",
]

