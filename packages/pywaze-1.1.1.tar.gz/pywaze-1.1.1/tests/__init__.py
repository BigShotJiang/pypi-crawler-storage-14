"""Tests for pywaze."""
