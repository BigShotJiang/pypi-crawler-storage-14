__version__ = "v1.3.1"

from phases.commands.run import Run

loadProject = Run.loadProject
