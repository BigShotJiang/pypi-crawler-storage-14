import time
from typing import Sequence

from airflow.exceptions import AirflowException
from airflow.models import BaseOperator
from airflow.providers.amazon.aws.hooks.dms import DmsHook
from airflow.utils.context import Context

from applydigital_airflow_lib.utils.random_string import generate_random_alphanumeric


class AwsDmsTaskOperator(BaseOperator):
    template_fields: Sequence[str] = (
        "replication_task_id",
        "source_endpoint_arn",
        "target_endpoint_arn",
        "replication_instance_arn",
        "table_mappings",
        "migration_type",
        "create_task_kwargs",
    )
    template_fields_renderers = {
        "table_mappings": "json",
        "create_task_kwargs": "json",
    }
    
    def __init__(
        self,
        *,
        aws_conn_id: str = "aws_default",
        source_endpoint_arn: str,
        target_endpoint_arn: str,
        replication_instance_arn: str,
        replication_task_id: str,
        migration_type: str = "full-load",
        table_mappings: dict,
        create_task_kwargs: dict = {},
        add_sufix_on_replication_task_id: bool = False,
        **kwargs,
    ):
        super().__init__(**kwargs)
        self.replication_task_id = replication_task_id
        if add_sufix_on_replication_task_id:
            self.replication_task_id = f"{self.replication_task_id}-{generate_random_alphanumeric(6)}"
        self.source_endpoint_arn = source_endpoint_arn
        self.target_endpoint_arn = target_endpoint_arn
        self.replication_instance_arn = replication_instance_arn
        self.migration_type = migration_type
        self.table_mappings = table_mappings
        self.create_task_kwargs = create_task_kwargs
        self.aws_conn_id = aws_conn_id
        self.target_statuses = ["stopped"]
        self.termination_statuses = [
            "creating",
            "deleting",
            "failed",
            "failed-move",
            "modifying",
            "moving",
            "ready",
            "testing",
        ]
        self.hook = DmsHook(aws_conn_id=self.aws_conn_id)

    def execute(self, context: Context):
        task_arn = self.hook.create_replication_task(
            replication_task_id=self.replication_task_id,
            source_endpoint_arn=self.source_endpoint_arn,
            target_endpoint_arn=self.target_endpoint_arn,
            replication_instance_arn=self.replication_instance_arn,
            migration_type=self.migration_type,
            table_mappings=self.table_mappings,
            **self.create_task_kwargs,
        )
        try:
            self.log.info("DMS replication task(%s) is ready.", self.replication_task_id)
            
            self.hook.start_replication_task(
                replication_task_arn=task_arn,
                start_replication_task_type='start-replication'
            )
            self.log.info("DMS replication task(%s) is starting.", self.replication_task_id)
            
            self.log.info("Monitoring DMS task status...")
            
            while True:
                if not (status := self.hook.get_task_status(task_arn)):
                    message = f"Failed to read task status, task with ARN {task_arn} not found"
                    raise AirflowException(message)

                self.log.info("DMS Replication task (%s) has status: %s", task_arn, status)

                if status in self.target_statuses:
                    break

                if status in self.termination_statuses:
                    raise AirflowException(message)
                
                time.sleep(15)
                
            dms_client = self.hook.get_conn()
                
            table_statistics = dms_client.describe_table_statistics(
                ReplicationTaskArn=task_arn
            )

            log_statistics = []
            
            for table_statistic in table_statistics["TableStatistics"]:
                if table_statistic['TableState'] == 'Table error':
                    message = f"Failed to task {task_arn}, {table_statistic['SchemaName']}.{table_statistic['TableName']} had a error"
                    raise AirflowException(message)
                log_statistics.append(table_statistic)
                
            self.log.info("Table statistics...")
            self.log.info(log_statistics)

        except Exception as e:
            raise AirflowException(f"Failed to process DMS task: {str(e)}")
        
        finally:
            self.log.info(f"Deleting DMS task: {task_arn}")
            self.hook.delete_replication_task(replication_task_arn=task_arn)
