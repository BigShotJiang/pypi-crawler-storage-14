# Media Management Tools

## Introduction

`mm-tools` is designed to be a flexiable and light-weighted tool to manage your media assets, with AI features and powerful plugin system.

## Roadmap

[] Importing Media(Photos, Videos), supporting custom directory structure, raw/jpeg seperate directory, video metadata.
[] Database for media, support metadata, tagging, rating, description.
[] Database merging, import from LightRoom/Apple Photos.
[] AI features, embedding, VLM description, OCR results.
[] Movie metadata crawling.
[] Search by image, text and other custom filters.

