def main() -> None:
    print("Hello from mm-tools!")
