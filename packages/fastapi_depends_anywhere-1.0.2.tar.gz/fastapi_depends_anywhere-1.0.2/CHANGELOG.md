# CHANGELOG

<!-- version list -->

## v1.0.2 (2025-11-29)

### Documentation

- Add coverage badge to README
  ([`4ab1f49`](https://github.com/ADR-007/fastapi-depends-anywhere/commit/4ab1f49847457685cf3b53255a73492b850091ad))


## v1.0.1 (2025-11-28)

### Bug Fixes

- Pin versions
  ([`4e250bf`](https://github.com/ADR-007/fastapi-depends-anywhere/commit/4e250bf7e8b986f525f3fc2e40cb389d3801ff2a))

### Continuous Integration

- Fix CI
  ([`4f199ce`](https://github.com/ADR-007/fastapi-depends-anywhere/commit/4f199cebe041f4f4ee10dc22cf7b48aed2a63c1f))


## v1.0.0 (2025-11-28)

- Initial Release

## v1.0.0 (2025-11-28)

- Initial Release
