
# ahargan/core.py
BASE_JDN = 2460414
BASE_AHARGAN = 714404168575

weekday_names = [
    "Aitabaar","Somabar","Mangalbar",
    "Budhbar","Bihibar","Sukrabar","Sanibar"
]

def to_astro_year(year, era):
    if era == "CE":
        return year
    else:
        return 1 - year

def gregorian_to_jdn(year, month, day):
    a = (14 - month) // 12
    y = year + 4800 - a
    m = month + 12*a - 3
    return day + ((153*m + 2)//5) + 365*y + y//4 - y//100 + y//400 - 32045

def weekday_from_jdn(jdn):
    return weekday_names[(jdn + 1) % 7]

def convert_to_ahargan(era, year, month, day):
    ay = to_astro_year(year, era)
    jdn = gregorian_to_jdn(ay, month, day)
    ah = BASE_AHARGAN + (jdn - BASE_JDN)
    bar = weekday_from_jdn(jdn)
    return ah, bar, jdn

def convert_jdn(jdn):
    ah = BASE_AHARGAN + (jdn - BASE_JDN)
    bar = weekday_from_jdn(jdn)
    return ah, bar
