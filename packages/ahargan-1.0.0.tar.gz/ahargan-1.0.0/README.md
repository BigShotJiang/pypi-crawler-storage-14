
# ahargan

JDN-based Ahargan conversion library.

Example:
```python
from ahargan import convert_to_ahargan
ah, bar, jdn = convert_to_ahargan("CE", 2024, 4, 13)
print(ah, bar, jdn)
```
