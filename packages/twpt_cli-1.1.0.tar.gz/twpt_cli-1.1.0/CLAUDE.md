# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project Overview

ThreatWinds Pentest CLI is a command-line tool for managing automated penetration testing using containerized Kali Linux environments. It provides both HTTP REST and gRPC streaming APIs for scheduling pentests, monitoring progress, and downloading evidence.

## Running Commands

Entry point is `run.py`:
```bash
# Development setup
python3 -m venv venv
source venv/bin/activate  # On Linux/Mac
pip install -r requirements.txt

# Run the CLI
python run.py [command]

# Interactive shell (default when no args)
python run.py

# Common commands
python run.py configure
python run.py run example.com --watch
python run.py get <pentest-id>
python run.py download <pentest-id>
```

## Architecture

### Core Components

**Entry Point & CLI Framework**
- `run.py`: Simple entry point that imports and runs `twpt_cli.main.main()`
- `twpt_cli/main.py`: CLI application using Click framework, registers all commands (e.g., `run`, `get`, `download`)
- `twpt_cli/shell.py`: Interactive shell with readline support, command history, and tab completion

**SDK Layer** (`twpt_cli/sdk/`)
- `http_client.py`: REST API client for scheduling, status checks, evidence downloads
- `grpc_client.py`: gRPC streaming client for real-time pentest monitoring
- `models.py`: Pydantic data models with dual enum systems (HTTP uses string enums like "AGGRESSIVE", gRPC uses integer enums for protobuf compatibility)
- `pentest_pb2.py` & `pentest_pb2_grpc.py`: Generated protobuf definitions for gRPC

**Configuration** (`twpt_cli/config/`)
- `credentials.py`: Manages API credentials stored in `~/.twpt/config.json` (base64 encoded)
- `constants.py`: System-wide constants including Docker config, endpoints, timeouts
- Endpoint config stored in `~/.twpt/endpoint.json` for remote/local mode switching

**Docker Management** (`twpt_cli/docker/`)
- `container.py`: Docker container lifecycle management
- `docker_install.py`: Automated Docker installation for Linux distributions
- Container runs `ghcr.io/threatwinds/twpt-agent:latest` in privileged mode with host networking

**Commands** (`twpt_cli/commands/`)
Each command is a separate module with a Click command function:
- `init.py`: Configure remote/local endpoints
- `configure.py`: Set up API credentials
- `schedule_pentest.py`: Schedule pentests (command: `run`; legacy alias: `schedule-pentest`)
- `get_pentest.py`: Get pentest status (aliases: `get-pentest`, `get`)
- `download_evidence.py`: Download reports (aliases: `download-evidence`, `download`)
- `list_pentests.py`: List pentests (aliases: `list-pentests`, `list`)
- `update.py`: Update Docker toolkit
- `uninstall.py`: Remove toolkit
- `version_cmd.py`: Show version info

### Key Design Patterns

**Dual Protocol Support**
The CLI supports both HTTP (REST) and gRPC (streaming):
- HTTP for simple request/response operations
- gRPC with async/await for real-time pentest monitoring (used with `--watch` flag)
- `models.py` contains conversion functions between HTTP and gRPC formats

**Dual Enum System**
HTTP API uses string-based enums (`HTTPStyle.AGGRESSIVE = "AGGRESSIVE"`), while gRPC uses integer-based enums (`GRPCStyle.AGGRESSIVE = 1`) for protobuf compatibility. The `convert_http_to_grpc_request()` function handles mapping between them.

**Configuration Hierarchy**
1. Environment variables (`PT_API_HOST`, `PT_API_PORT`, `PT_GRPC_HOST`, `PT_GRPC_PORT`)
2. Endpoint config file (`~/.twpt/endpoint.json`) - takes precedence
3. Default values (localhost:9741 for API, localhost:9742 for gRPC)

**Interactive Shell vs Direct Commands**
- No arguments: Starts interactive shell
- With arguments: Executes command directly
- Shell uses `CliRunner` for non-streaming commands, `subprocess` for streaming commands (to avoid buffering issues)

## Testing

When testing the CLI:
- Always activate venv first: `source venv/bin/activate`
- Test both direct command mode and interactive shell mode
- For `--watch` flag testing, verify streaming output appears in real-time
- Test with both local Docker and remote endpoints
- Verify error handling and user-friendly error messages

## Common Development Tasks

**Adding a new command:**
1. Create module in `twpt_cli/commands/`
2. Implement Click command function
3. Import in `twpt_cli/commands/__init__.py`
4. Register in `twpt_cli/main.py` using `cli.add_command()`
5. Add to interactive shell command map in `twpt_cli/shell.py`

**Modifying protobuf definitions:**
1. Edit `.proto` files
2. Regenerate with: `python -m grpc_tools.protoc --python_out=. --grpc_python_out=. pentest.proto`
3. Update `models.py` if enum values change

**Docker configuration changes:**
Update `CONTAINER_CONFIG` in `twpt_cli/config/constants.py`

## Important Notes

- **Privileged Container**: The Docker container runs in privileged mode with host networking - this is required for pentesting operations
- **Streaming Buffer Issue**: Interactive shell uses `subprocess.run()` instead of `CliRunner` for `--watch` commands to prevent output buffering
- **Credential Storage**: API credentials are base64-encoded in `~/.twpt/config.json`, not encrypted
- **Remote Endpoints**: When `endpoint.json` exists with `use_remote: true`, it overrides environment variables and local Docker
- **Command Names**: Commands use simplified names (e.g., `run`, `get`, `download`) with legacy aliases maintained for backwards compatibility

## Security Context

This tool is designed for authorized penetration testing in controlled environments:
- Requires ThreatWinds API credentials
- Operates on explicitly defined targets
- Maintains audit trail through pentest IDs
- Evidence and reports are downloadable for compliance
