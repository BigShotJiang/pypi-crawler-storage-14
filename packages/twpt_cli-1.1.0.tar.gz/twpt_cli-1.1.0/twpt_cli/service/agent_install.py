"""Local agent installation and service management.

Supports Linux (Kali Linux, Ubuntu) with systemd service management.
The agent (pentest service) only runs on Linux systems.
The CLI itself can run on any platform (Linux, macOS, Windows).
"""

import os
import subprocess
import zipfile
import shutil
from pathlib import Path
from typing import Optional
import platform

import requests
from rich.console import Console
from rich.progress import Progress, DownloadColumn, TransferSpeedColumn, TimeRemainingColumn, BarColumn

from twpt_cli.config.constants import (
    DEFAULT_PT_PATH,
    AGENT_DOWNLOAD_URL,
    AGENT_DIR_NAME,
    SERVICE_NAME,
    SERVICE_DESCRIPTION,
)

console = Console()


def get_agent_path() -> Path:
    """Get the path where the agent is/will be installed.

    Returns:
        Path to agent directory (/opt/twpt/agent on Linux)
    """
    return DEFAULT_PT_PATH / AGENT_DIR_NAME


def get_current_platform() -> str:
    """Get the current platform name.

    Returns:
        Platform name: 'linux', 'darwin', or 'windows'
    """
    return platform.system().lower()


def check_linux_only() -> bool:
    """Check if the current platform is Linux.

    The agent service only runs on Linux (Kali Linux, Ubuntu).
    For other platforms, users should use remote mode to connect to a Linux agent.

    Returns:
        True if Linux, False otherwise
    """
    current = get_current_platform()
    if current != "linux":
        console.print(
            f"✗ Local agent installation is only supported on Linux (Kali, Ubuntu)",
            style="red"
        )
        console.print(f"  Current OS: {platform.system()}", style="dim")
        console.print(f"\n  For {platform.system()}, please use remote mode:", style="yellow")
        console.print(f"    twpt-cli init", style="white")
        console.print(f"    Then select 'remote' and enter the address of a Linux agent", style="dim")
        return False
    return True


def check_root_privileges() -> bool:
    """Check if running with root/sudo privileges.

    Returns:
        True if has root privileges, False otherwise
    """
    if os.geteuid() != 0:
        console.print("✗ Root privileges required for local agent installation", style="red")
        console.print("  Please run with sudo: sudo twpt-cli install-agent", style="yellow")
        return False
    return True


def download_agent() -> Optional[Path]:
    """Download the agent package from the official repository.

    Returns:
        Path to downloaded zip file, or None if failed
    """
    try:
        zip_path = DEFAULT_PT_PATH / "twpt-agent.zip"

        # Ensure directory exists
        DEFAULT_PT_PATH.mkdir(parents=True, exist_ok=True)

        console.print(f"Downloading agent from {AGENT_DOWNLOAD_URL}...", style="cyan")

        # Stream download with progress bar
        response = requests.get(AGENT_DOWNLOAD_URL, stream=True, timeout=300)
        response.raise_for_status()

        total_size = int(response.headers.get('content-length', 0))

        with Progress(
            "[progress.description]{task.description}",
            BarColumn(),
            DownloadColumn(),
            TransferSpeedColumn(),
            TimeRemainingColumn(),
            console=console,
        ) as progress:
            task = progress.add_task("Downloading...", total=total_size)

            with open(zip_path, 'wb') as f:
                for chunk in response.iter_content(chunk_size=8192):
                    if chunk:
                        f.write(chunk)
                        progress.update(task, advance=len(chunk))

        console.print(f"✓ Agent package downloaded", style="green")
        return zip_path

    except requests.RequestException as e:
        console.print(f"✗ Failed to download agent: {e}", style="red")
        return None
    except Exception as e:
        console.print(f"✗ Unexpected error downloading agent: {e}", style="red")
        return None


def extract_agent(zip_path: Path) -> bool:
    """Extract the agent package.

    Args:
        zip_path: Path to the downloaded zip file

    Returns:
        True if successful, False otherwise
    """
    try:
        agent_path = get_agent_path()

        console.print("Extracting agent package...", style="cyan")

        # Remove existing installation if present
        if agent_path.exists():
            console.print("Removing existing installation...", style="dim")
            shutil.rmtree(agent_path)

        # Create agent directory
        agent_path.mkdir(parents=True, exist_ok=True)

        # Extract zip file
        with zipfile.ZipFile(zip_path, 'r') as zip_ref:
            zip_ref.extractall(agent_path)

        console.print(f"✓ Agent extracted to {agent_path}", style="green")

        # Clean up zip file
        zip_path.unlink()

        return True

    except zipfile.BadZipFile:
        console.print(f"✗ Invalid zip file", style="red")
        return False
    except Exception as e:
        console.print(f"✗ Failed to extract agent: {e}", style="red")
        return False


def setup_python_environment() -> bool:
    """Setup Python virtual environment and install dependencies.

    Returns:
        True if successful, False otherwise
    """
    try:
        agent_path = get_agent_path()
        venv_path = agent_path / "venv"

        console.print("Setting up Python virtual environment...", style="cyan")

        # Check if python3 is available
        result = subprocess.run(
            ["python3", "--version"],
            capture_output=True,
            text=True
        )
        if result.returncode != 0:
            console.print("✗ python3 not found. Please install Python 3", style="red")
            return False

        console.print("Creating virtual environment...", style="dim")

        # Create virtual environment
        result = subprocess.run(
            ["python3", "-m", "venv", str(venv_path)],
            cwd=agent_path,
            capture_output=True,
            text=True
        )
        if result.returncode != 0:
            console.print(f"✗ Failed to create virtual environment: {result.stderr}", style="red")
            return False

        pip_path = venv_path / "bin" / "pip"
        venv_python_path = venv_path / "bin" / "python3"

        console.print("Upgrading pip...", style="dim")

        # Upgrade pip
        result = subprocess.run(
            [str(pip_path), "install", "--upgrade", "pip"],
            cwd=agent_path,
            capture_output=True,
            text=True
        )
        if result.returncode != 0:
            console.print(f"⚠ Warning: Failed to upgrade pip: {result.stderr}", style="yellow")

        # Install requirements if present
        requirements_path = agent_path / "requirements.txt"
        if requirements_path.exists():
            console.print("Installing Python dependencies...", style="dim")
            console.print("This may take several minutes...", style="dim")

            result = subprocess.run(
                [str(pip_path), "install", "--no-cache-dir", "-r", str(requirements_path)],
                cwd=agent_path,
                capture_output=True,
                text=True
            )
            if result.returncode != 0:
                console.print(f"✗ Failed to install dependencies: {result.stderr}", style="red")
                return False
        else:
            console.print("⚠ No requirements.txt found", style="yellow")

        # Update launcher shebang to use venv Python
        launcher_path = agent_path / "twpt-agent"
        if launcher_path.exists():
            with open(launcher_path, 'r') as f:
                lines = f.readlines()

            if lines and lines[0].startswith("#!"):
                lines[0] = f"#!{venv_python_path}\n"

            with open(launcher_path, 'w') as f:
                f.writelines(lines)

            # Make launcher executable
            os.chmod(launcher_path, 0o755)

        console.print(f"✓ Python environment ready", style="green")
        return True

    except Exception as e:
        console.print(f"✗ Failed to setup Python environment: {e}", style="red")
        return False


def install_service() -> bool:
    """Install the agent as a systemd service (Linux only).

    Returns:
        True if successful, False otherwise
    """
    try:
        agent_path = get_agent_path()
        launcher_path = agent_path / "twpt-agent"

        if not launcher_path.exists():
            console.print(f"✗ Agent launcher not found at {launcher_path}", style="red")
            return False

        console.print("Installing systemd service...", style="cyan")

        # Create systemd service file
        service_content = f"""[Unit]
Description={SERVICE_DESCRIPTION}
After=network.target

[Service]
Type=simple
User=root
WorkingDirectory={agent_path}
ExecStart={launcher_path}
Restart=always
RestartSec=10
Environment="API_PORT=9741"
Environment="GRPC_PORT=9742"

[Install]
WantedBy=multi-user.target
"""

        service_file_path = f"/etc/systemd/system/{SERVICE_NAME}.service"

        # Write service file
        with open(service_file_path, 'w') as f:
            f.write(service_content)

        console.print(f"✓ Service file created at {service_file_path}", style="green")

        # Reload systemd
        console.print("Reloading systemd daemon...", style="dim")
        result = subprocess.run(
            ["systemctl", "daemon-reload"],
            capture_output=True,
            text=True
        )
        if result.returncode != 0:
            console.print(f"✗ Failed to reload systemd: {result.stderr}", style="red")
            return False

        # Enable service
        console.print("Enabling service...", style="dim")
        result = subprocess.run(
            ["systemctl", "enable", SERVICE_NAME],
            capture_output=True,
            text=True
        )
        if result.returncode != 0:
            console.print(f"✗ Failed to enable service: {result.stderr}", style="red")
            return False

        console.print(f"✓ Service installed and enabled", style="green")
        return True

    except Exception as e:
        console.print(f"✗ Failed to install systemd service: {e}", style="red")
        return False


# Backward compatibility alias
install_systemd_service = install_service


def start_agent_service() -> bool:
    """Start the agent systemd service.

    Returns:
        True if successful, False otherwise
    """
    try:
        console.print("Starting agent service...", style="cyan")

        result = subprocess.run(
            ["systemctl", "start", SERVICE_NAME],
            capture_output=True,
            text=True
        )
        if result.returncode != 0:
            console.print(f"✗ Failed to start service: {result.stderr}", style="red")
            return False

        # Wait a moment and check status
        import time
        time.sleep(2)

        result = subprocess.run(
            ["systemctl", "is-active", SERVICE_NAME],
            capture_output=True,
            text=True
        )

        if result.stdout.strip() == "active":
            console.print(f"✓ Agent service started successfully", style="green")
            console.print(f"  API listening on: http://localhost:9741", style="dim")
            console.print(f"  gRPC listening on: localhost:9742", style="dim")
            return True
        else:
            console.print(f"✗ Service failed to start properly", style="red")
            console.print(f"  Check logs with: journalctl -u {SERVICE_NAME}", style="yellow")
            return False

    except Exception as e:
        console.print(f"✗ Failed to start service: {e}", style="red")
        return False


def stop_agent_service() -> bool:
    """Stop the agent systemd service.

    Returns:
        True if successful, False otherwise
    """
    try:
        console.print("Stopping agent service...", style="cyan")

        result = subprocess.run(
            ["systemctl", "stop", SERVICE_NAME],
            capture_output=True,
            text=True
        )
        if result.returncode != 0:
            console.print(f"✗ Failed to stop service: {result.stderr}", style="red")
            return False

        console.print(f"✓ Agent service stopped", style="green")
        return True

    except Exception as e:
        console.print(f"✗ Failed to stop service: {e}", style="red")
        return False


def remove_agent_service() -> bool:
    """Remove the agent systemd service.

    Returns:
        True if successful, False otherwise
    """
    try:
        console.print("Removing agent service...", style="cyan")

        # Stop service first
        subprocess.run(["systemctl", "stop", SERVICE_NAME], capture_output=True)

        # Disable service
        subprocess.run(
            ["systemctl", "disable", SERVICE_NAME],
            capture_output=True,
            text=True
        )

        # Remove service file
        service_file_path = f"/etc/systemd/system/{SERVICE_NAME}.service"
        if os.path.exists(service_file_path):
            os.remove(service_file_path)

        # Reload systemd
        subprocess.run(["systemctl", "daemon-reload"], capture_output=True)

        console.print(f"✓ Agent service removed", style="green")
        return True

    except Exception as e:
        console.print(f"✗ Failed to remove service: {e}", style="red")
        return False


def is_service_installed() -> bool:
    """Check if the agent systemd service is installed.

    Returns:
        True if installed, False otherwise
    """
    try:
        service_file_path = f"/etc/systemd/system/{SERVICE_NAME}.service"
        return os.path.exists(service_file_path)
    except Exception:
        return False


def is_service_running() -> bool:
    """Check if the agent systemd service is running.

    Returns:
        True if running, False otherwise
    """
    try:
        result = subprocess.run(
            ["systemctl", "is-active", SERVICE_NAME],
            capture_output=True,
            text=True
        )
        return result.stdout.strip() == "active"
    except Exception:
        return False


def remove_agent_files() -> bool:
    """Remove the agent installation files.

    Returns:
        True if successful, False otherwise
    """
    try:
        agent_path = get_agent_path()
        if agent_path.exists():
            shutil.rmtree(agent_path)
            console.print(f"✓ Agent files removed from {agent_path}", style="green")
        return True
    except Exception as e:
        console.print(f"✗ Failed to remove agent files: {e}", style="red")
        return False
