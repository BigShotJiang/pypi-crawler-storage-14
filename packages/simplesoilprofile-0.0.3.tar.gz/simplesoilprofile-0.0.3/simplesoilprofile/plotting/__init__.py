"""Plotting utilities for soil profile visualization."""

from .profile_plot import plot_profile

__all__ = ["plot_profile"]
