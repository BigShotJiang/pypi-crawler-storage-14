from .astradb_base import AstraDBBaseComponent

__all__ = [
    "AstraDBBaseComponent",
]
