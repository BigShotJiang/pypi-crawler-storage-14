"""Military color codes"""

# Military color codes for weather conditions
MILITARY_COLOR_CODES = {
    "BLU": "Blue",
    "WHT": "White",
    "GRN": "Green",
    "YLO": "Yellow",
    "AMB": "Amber",
    "RED": "Red",
}
