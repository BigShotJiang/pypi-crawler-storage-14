"""Catch Sunset - Track sunset, sunrise, moonrise, and moonset events."""

from catch_sunset.cli import cli


def main() -> None:
    """Entry point for the CLI application."""
    cli()
