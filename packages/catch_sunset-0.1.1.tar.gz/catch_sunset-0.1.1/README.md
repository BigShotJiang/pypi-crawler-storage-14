# Catch Sunset

A CLI tool to track sunset, sunrise, moonrise, and moonset events with optional alarm notifications via ntfy.sh.

## Installation

```bash
uv sync
```

## Usage

```bash
# Show today's events
catch-sunset today

# Show tomorrow's events with alarm notifications
catch-sunset tomorrow --set-alarm

# Show events with custom ntfy topic
catch-sunset today --set-alarm --ntfy-topic ntfy.sh/mysunset

# Show events for a date range
catch-sunset range --start-date 2025-01-15 --end-date 2025-01-20
```

## Features

- Auto-detects location via IP geolocation
- Manual location specification via --lat and --lon
- Configurable alert buffer time
- Optional alarm notifications via ntfy.sh
- Shows moon phase and moonrise/moonset during full moon periods
