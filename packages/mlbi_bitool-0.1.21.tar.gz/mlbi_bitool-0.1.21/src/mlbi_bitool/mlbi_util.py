import os, time, copy, collections
import numpy as np
import pandas as pd
from subprocess import Popen, PIPE
import shlex, shutil, tempfile
from typing import List, Tuple, Dict, Optional, Any

def run_command_old(cmd, prn = True):
    cnt = 0
    with Popen(cmd, shell=True, stdout=PIPE, bufsize=1, \
               text = True ) as p:
               # universal_newlines=prn ) as p:
        for line in p.stdout:
            if line.startswith('Tool returned:'):                    
                cnt += 1
            elif cnt > 0:
                pass
            else: 
                if prn:
                    print(line, end='')
                    
        exit_code = p.poll()
    return exit_code


def run_command(cmd, prn=True) -> int:
    
    with Popen(cmd, shell=True,
               stdout=PIPE,
               stderr=PIPE,
               text=True,
               bufsize=1) as p:

        # stdout_buf = []
        # stderr_buf = []

        # 실시간으로 stdout 읽기
        for line in p.stdout:
            if prn:
                print(line, end="")  # 화면에 출력
            # stdout_buf.append(line)

        # stderr 전체 읽기 (실시간 출력은 선택)
        for line in p.stderr:
            if prn:
                # stderr도 동일하게 출력
                print(line, end="")
            # stderr_buf.append(line)

        exit_code = p.wait()

    return exit_code #, "".join(stdout_buf), "".join(stderr_buf)
    
    
def get_file_name_of(file_name_ext):
    
    items = file_name_ext.split('.')
    file_name = items[0]
    for item in items[1:-1]:
        file_name = file_name + '.' + item
    ext = items[-1]
    
    return file_name


def get_file_name_and_ext_of(path_file_name_ext):

    file_name_ext = path_file_name_ext.split('/')[-1]
    items = file_name_ext.split('.')
    file_name = items[0]
    for item in items[1:-1]:
        file_name = file_name + '.' + item
    ext = items[-1]
    
    return file_name, ext


def get_path_filename_and_ext_of(path_file_name_ext):

    items = path_file_name_ext.split('/')
    if len(items) == 1:
        path = ''
    else:
        path = items[0]
        for itm in items[1:-1]:
            path = path + '/%s' % itm            
    file_name_ext = items[-1]
    
    items = file_name_ext.split('.')
    if (items[-1] == 'gz') & (len(items) > 2):
        file_name = items[0]
        for item in items[1:-2]:
            file_name = file_name + '.%s' % item
        ext = '%s.%s' % (items[-2], items[-1])
    elif len(items) == 1:
        file_name = items[0]
        ext = ''
    else:
        file_name = items[0]
        for item in items[1:-1]:
            file_name = file_name + '.%s' % item
        ext = items[-1]
    
    return path, file_name, ext
    

##############################
### Some usefule functions ###

def which( ai, value = True ) :
    wh = []
    a = list(ai)
    for k in range(len(a)): 
        if a[k] == value: 
            wh.append(k) 
    return(wh)


def get_col(nt_lst, n):
    
    lst = []
    for item in nt_lst: lst.append(item[n]) 
    return(lst)


def get_flag(values, bpos ):
    mask = np.repeat( 1 << bpos, len(values) )
    flag = (values & mask) > 0
    return(list(flag))


