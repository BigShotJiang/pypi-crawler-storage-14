class Foo:
    def foo(self) -> int:
        return 42
