print("Hello from Python module!")
