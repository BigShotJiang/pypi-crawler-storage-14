# Module to generate and scale AI datasets for pre-training and fine-tuning language models.
# --------------------------> A SAPIENS TECHNOLOGY®️ PRODUCTION) <--------------------------
from setuptools import setup, find_packages
package_name = 'sapiens_dataset'
version = '2.0.7'
setup(
    name=package_name,
    version=version,
    author='SAPIENS TECHNOLOGY',
    packages=find_packages(),
    include_package_data=True,
    install_requires=[
        'llama-cpp-python==0.3.6',
        'llamacpp==0.1.14',
        'requests',
        'beautifulsoup4',
        'markdownify',
        'tiktoken',
        'sapiens-file-interpreter',
        'mammoth',
        'PyMuPDF',
        'python-pptx',
        'utilities-nlp',
        'pandas',
        'tqdm',
        'wikipedia',
        'StackAPI'
    ],
    url='https://github.com/sapiens-technology/sapiens_dataset',
    license='Proprietary Software'
)
# Module to generate and scale AI datasets for pre-training and fine-tuning language models.
# --------------------------> A SAPIENS TECHNOLOGY®️ PRODUCTION) <--------------------------
