# Static version file
__version__ = "1.0.0"
version = "1.0.0"
__version_tuple__ = (1, 0, 0)
version_tuple = (1, 0, 0)
