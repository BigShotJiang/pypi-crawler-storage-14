# codefusion/core/reader.py
import logging
from pathlib import Path
import typing as t

logger = logging.getLogger(__name__)

def read_file_content(file_path: Path) -> t.Tuple[str, bool]:
    """Enhanced file reading with better encoding detection and size limits."""
    try:
        # Prevent reading excessively large files into memory
        if file_path.stat().st_size > 10 * 1024 * 1024:  # 10MB limit
            logger.warning(f"Skipping large file {file_path} (over 10MB)")
            return "ERROR: File is too large to be read.", True
    except Exception as e:
        logger.warning(f"Could not stat file {file_path}: {e}")
        return f"ERROR: Could not access file: {e}", True

    encodings = ['utf-8', 'utf-8-sig', 'latin-1', 'cp1252', 'iso-8859-1', 'ascii']
    
    for encoding in encodings:
        try:
            content = file_path.read_text(encoding=encoding)
            # Validate content isn't mostly binary
            if len(content) > 0:
                sample = content[:1000]
                non_printable = sum(1 for c in sample if ord(c) < 32 and c not in '\t\n\r')
                if non_printable / len(sample) > 0.1:
                    continue  # Try next encoding
            return content, False
        except (UnicodeDecodeError, UnicodeError):
            continue
        except Exception as e:
            logger.warning(f"Error reading {file_path}: {e}")
            return f"ERROR: Unable to read file: {e}", True
    
    # If all encodings fail
    msg = f"ERROR: Unable to decode file with any supported encoding"
    logger.warning(f"All encoding attempts failed for {file_path}")
    return msg, True
