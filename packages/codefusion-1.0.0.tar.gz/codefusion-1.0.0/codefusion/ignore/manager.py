# codefusion/ignore/manager.py
import logging
import fnmatch
from pathlib import Path
import typing as t
import sys

try:
    import gitignore_parser
except ImportError:
    # Don't sys.exit here, let the app handle it or warn
    gitignore_parser = None
    print("Warning: 'gitignore_parser' library not found. .gitignore support will be disabled.")
    print("Please install it: pip install gitignore-parser")

from ..utils.constants import DEFAULT_EXCLUDE_PATTERNS

logger = logging.getLogger(__name__)

class IgnoreManager:
    """Handles file and directory exclusion based on various ignore rules."""

    def __init__(self, root_dir: Path, ignore_file_name: str = ".codeignore",
                 use_gitignore: bool = True, extra_exclude_patterns: t.Optional[t.List[str]] = None,
                 output_file: t.Optional[Path] = None):
        self.root_dir = root_dir
        self.ignore_file_name = ignore_file_name
        self.use_gitignore = use_gitignore
        self.all_exclude_patterns: t.List[str] = list(DEFAULT_EXCLUDE_PATTERNS)
        if extra_exclude_patterns:
            self.all_exclude_patterns.extend(extra_exclude_patterns)

        self.custom_ignore_patterns: t.List[str] = []
        self.gitignore_matches: t.Optional[t.Callable[[t.Union[str, Path]], bool]] = None
        self.output_file = output_file

        self._load_ignore_rules()

    def _load_ignore_rules(self) -> None:
        """Load patterns from custom ignore file and .gitignore."""
        custom_ignore_path = self.root_dir / self.ignore_file_name
        if custom_ignore_path.is_file():
            try:
                with custom_ignore_path.open('r', encoding='utf-8') as f:
                    self.custom_ignore_patterns = [
                        line.strip() for line in f if line.strip() and not line.startswith('#')
                    ]
                logger.info(f"Loaded {len(self.custom_ignore_patterns)} patterns from {self.ignore_file_name}")
            except Exception as e:
                logger.warning(f"Failed to load ignore file {custom_ignore_path}: {e}")

        if self.use_gitignore:
            gitignore_path = self.root_dir / '.gitignore'
            if gitignore_path.is_file():
                try:
                    with gitignore_path.open('r', encoding='utf-8') as f:
                        self.gitignore_matches = gitignore_parser.parse_gitignore(str(gitignore_path))
                    logger.info("Loaded .gitignore patterns.")
                except Exception as e:
                    logger.warning(f"Failed to load or parse .gitignore file {gitignore_path}: {e}")
            else:
                logger.debug(".gitignore file not found in root directory.")
        else:
            logger.debug(".gitignore processing skipped by user.")

        logger.debug(f"Total default/extra exclude patterns: {len(self.all_exclude_patterns)}")

    def is_excluded(self, file_path: Path) -> bool:
        """
        Check if a file should be ignored based on all rules.

        Args:
            file_path: The absolute Path object of the file.

        Returns:
            True if the file should be ignored, False otherwise.
        """
        try:
            rel_path = file_path.relative_to(self.root_dir)
            rel_path_str = rel_path.as_posix()
        except ValueError:
            logger.warning(f"Could not get relative path for {file_path}")
            return True

        # 1. Check default/extra exclusion patterns
        for pattern in self.all_exclude_patterns:
            if fnmatch.fnmatch(rel_path_str, pattern) or \
               any(fnmatch.fnmatch(part, pattern) for part in rel_path.parts):
                 logger.debug(f"Ignoring '{rel_path_str}' due to default/extra pattern: '{pattern}'")
                 return True

        # 2. Check custom ignore patterns (.codeignore)
        if any(fnmatch.fnmatch(rel_path_str, pattern) for pattern in self.custom_ignore_patterns):
            logger.debug(f"Ignoring '{rel_path_str}' due to custom ignore pattern.")
            return True

        # 3. Check .gitignore patterns
        if self.gitignore_matches and self.gitignore_matches(file_path):
             logger.debug(f"Ignoring '{rel_path_str}' due to .gitignore pattern.")
             return True

        # 4. Exclude the output file itself
        if self.output_file and file_path.resolve() == self.output_file.resolve():
            logger.debug(f"Ignoring '{rel_path_str}' as it is the output file.")
            return True

        return False
