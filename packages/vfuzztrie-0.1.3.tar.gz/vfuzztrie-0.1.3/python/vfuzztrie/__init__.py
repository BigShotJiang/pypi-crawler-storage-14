from ._vfuzztrie import *


__doc__ = _vfuzztrie.__doc__
if hasattr(_vfuzztrie, "__all__"):
    __all__ = _vfuzztrie.__all__
