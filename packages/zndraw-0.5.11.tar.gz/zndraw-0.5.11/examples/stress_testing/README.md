# Stress Testing
The following scripts can be used to perform some stress testing on a given ZnDraw instance.
Do not use them against public servers which you are not hosting yourself.
