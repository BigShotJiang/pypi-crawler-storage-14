# ZnDraw App

To provide access to the `zndraw.ZnDraw` class without using `eventlet.monkey_patch()` all the `monkey_patch` features have been extracted into this minimal package.
