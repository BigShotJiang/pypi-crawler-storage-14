Advent of Code
==============

Each day of the Advent we will showcase one of ZnDraws features for you!

Each example - unless otherwise noted - assumes a running ZnDraw instance on ``http://localhost:5003``.

.. toctree::
   :maxdepth: 2
   :glob:

   2025/*
