.. _swh-storage-cli:

Command-line interface
======================

.. click:: swh.storage.cli:storage
   :prog: swh storage
   :nested: full
