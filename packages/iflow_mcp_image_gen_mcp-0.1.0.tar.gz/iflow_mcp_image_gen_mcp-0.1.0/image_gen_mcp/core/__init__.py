"""Core MCP server components."""
