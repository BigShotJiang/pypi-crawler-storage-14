# pylint: disable=consider-using-from-import, missing-module-docstring
from py3xui.utils import env

COOKIE_NAMES = ["3x-ui", "session"]
