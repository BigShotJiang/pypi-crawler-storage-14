#!/bin/bash
set -e

echo "Building wheel for x86_64 Linux..."

# Create dist directory if it doesn't exist
mkdir -p dist

# Build using Docker
docker build -f Dockerfile.build -t greeter-builder .
docker create --name greeter-builder-container greeter-builder
docker cp greeter-builder-container:/build/dist/. ./dist/
docker rm greeter-builder-container

echo "Build complete! Wheels are in the dist/ directory:"
ls -lh dist/*.whl

# Create Snowflake-compatible zip file
echo ""
echo "Creating Snowflake-compatible zip file..."
WHEEL_FILE=$(ls dist/*manylinux*.whl 2>/dev/null | head -1)
if [ -n "$WHEEL_FILE" ]; then
    # Extract wheel to temporary directory
    rm -rf dist/greeter_package
    mkdir -p dist/greeter_package
    cd dist/greeter_package
    unzip -q "../$(basename $WHEEL_FILE)"

    # Create zip with just the greeter package
    zip -q -r ../greeter.zip greeter
    cd ../..

    # Clean up
    rm -rf dist/greeter_package

    echo "Snowflake zip created: dist/greeter.zip"
    ls -lh dist/greeter.zip
else
    echo "Warning: No manylinux wheel found to create Snowflake zip"
fi
