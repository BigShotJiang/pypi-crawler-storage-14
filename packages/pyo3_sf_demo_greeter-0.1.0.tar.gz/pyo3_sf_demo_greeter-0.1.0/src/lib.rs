use pyo3::prelude::*;
use sysinfo::{System};

#[pyfunction]
fn greet(name: &str) -> String {
    let mut sys = System::new_all();
    sys.refresh_all();
    let os = System::name().unwrap_or("Unknown".to_string());
    let os_version = System::os_version().unwrap_or("Unknown".to_string());
    let host_name = System::host_name().unwrap_or("Unknown".to_string());
    format!("Hello, {}! using os={}, os_version={}, host_name={}.", name, os, os_version, host_name)
}

/// A Python module implemented in Rust. The name of this function must match
/// the `lib.name` setting in the `Cargo.toml`, else Python will not be able to
/// import the module.
#[pymodule]
fn _core(m: &Bound<'_, PyModule>) -> PyResult<()> {
    m.add_function(wrap_pyfunction!(greet, m)?)?;
    Ok(())
}
