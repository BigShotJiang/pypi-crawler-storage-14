from greeter import greet

print(greet(name="Alice"))
