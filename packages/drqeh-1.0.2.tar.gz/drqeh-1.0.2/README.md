# 🔐 DQEH – DigiRaksha Quantum Encryption Hasher
### Official Python SDK

[![PyPI version](https://img.shields.io/pypi/v/drqeh.svg)](https://pypi.org/project/drqeh/)
[![Python](https://img.shields.io/pypi/pyversions/drqeh.svg)](https://pypi.org/project/drqeh/)
[![License](https://img.shields.io/badge/license-Proprietary-red.svg)](https://github.com/KALLESHDR/)

DQEH is a **Quantum-Inspired, Chaos-Driven, Non-Reversible Hashing Algorithm** developed under the **DigiRaksha** security framework.

This Python SDK provides simple access to the DigiRaksha Quantum Hasher via REST API.

---

## 🚀 Features

- **🔬 Quantum-Inspired Encryption**  
  Utilizes chaotic logistic maps, bit-reversal, nibble-swapping, entanglement and multi-round diffusion.

- **🔒 Irreversible 256-bit Hash Output**  
  Safe for password storage, authentication systems, API tokens, and secure identity hashing.

- **👨‍💻 Developer-Friendly Python SDK**  
  Simple, intuitive API:
  ```python
  from drqeh import encrypt
  hashed = encrypt("your_password")
  ```

- **⚡ Lightweight & Fast**  
  Only one dependency: `requests`.

- **🛡️ Centralized Security**  
  Hashing logic is securely executed on DigiRaksha servers — algorithm remains private.

---

## 📦 Installation

Install directly from PyPI:

```bash
pip install drqeh
```

---

## 🔧 Quick Start

### Basic Example

```python
from drqeh import encrypt

# Encrypt a password
hashed = encrypt("Pass@123")
print("Encrypted:", hashed)
```

**Output (example):**
```
4a9f0c3e24ac9f9ddf83a18d54e2b730c2e8b8d6a1c0f61bd8d3c217f42a219b
```

### With Error Handling

```python
from drqeh import encrypt

try:
    hashed = encrypt("MySecurePassword!")
    print("Hash:", hashed)
except Exception as e:
    print("Encryption failed:", e)
```

---

## 🔍 What is DQEH?

**DQEH (DigiRaksha Quantum Encryption Hasher)** is a next-generation hashing algorithm that uses:

It produces a **256-bit irreversible hash**, similar in purpose to SHA-256, but powered by a **quantum-inspired chaotic processing pipeline**.

### ✅ Key Characteristics

- ✔️ **Not reversible** – One-way hashing only
- ✔️ **Not crackable by brute-force** – Quantum-resistant design
- ✔️ **No collisions** – Tested on millions of test cases
- ✔️ **Suitable for authentication** – Password & token systems

---

## 🌐 API Details

This SDK communicates with the DigiRaksha backend:

**Endpoint:**
```
POST https://digirakshaquantumencription.onrender.com/encrypt
```

**Request Payload:**
```json
{
  "password": "your_input"
}
```

**Response:**
```json
{
  "encrypted": "4a9f0c3e24ac9f9ddf83a18d54e2b730...",
  "length": 10
}
```

---

## ⚠️ Error Handling

The SDK raises a Python exception when:

- ❌ API is unreachable
- ❌ Invalid data is passed
- ❌ Network timeout occurs

**Example:**

```python
from drqeh import encrypt

try:
    result = encrypt("Hello")
except Exception as e:
    print("Encryption failed:", e)
```

---

## 🔐 Security Notes

- 🔒 **Hashing is non-reversible** – Cannot be decrypted
- 🚫 **No plaintext storage** – Only hashes are stored
- 🔐 **HTTPS-only communication** – All API calls are encrypted
- 🛡️ **Server-side processing** – Algorithm stays protected
- 🔒 **No local algorithm exposure** – Prevents reverse-engineering

This ensures:

✅ Enterprise-grade security  
✅ No tampering or manipulation  
✅ Algorithm protection  
✅ Compliance-ready architecture

---

## 🛠️ Requirements

- Python 3.7+
- `requests` library (auto-installed)

---

## 📘 Versioning

| Version | Release Date | Notes |
|---------|--------------|-------|
| **v1.0.0** | 2025-11 | Initial release of Python SDK |

### Upcoming Features

- 🔑 API key support
- 🔄 Local hashing fallback
- ⚡ Async variant (`async def encrypt()`)
- 🔗 Multi-hash pipelines

---

## 📚 API Reference

### `encrypt(password: str) -> str`

Encrypts the given password using DigiRaksha Quantum Encryption Hasher.

**Parameters:**
- `password` (str): The string to be hashed

**Returns:**
- `str`: 256-bit hexadecimal hash

**Raises:**
- `Exception`: If API call fails or returns an error

**Example:**
```python
from drqeh import encrypt
hash_output = encrypt("MyPassword123")
```

---

## 🤝 Contributing

We welcome contributions! Here's how you can help:

1. 🐛 Report bugs via GitHub Issues
2. 💡 Suggest features or improvements
3. 📝 Improve documentation
4. 🧪 Add test cases

---

## 📞 Support

For issues, questions, or support:

- 📧 Email: kallesh953@gmail.com
---

## 📄 License

© 2025 DigiRaksha – All Rights Reserved

This software is proprietary. Unauthorized copying, reverse-engineering, distribution, or replication is strictly prohibited.

---

## 🌟 Acknowledgments

Developed with ❤️ by the **DigiRaksha Security Team**

**Author:** [[Kallesh D R](https://kalleshdr.web.app/)]
**Connect Me:** [Linkedin](https://www.linkedin.com/in/kallesh-d-r-087008235/)

---

<div align="center">

**⭐ Star us on GitHub if you find this useful! ⭐**

[GitHub](https://github.com/KALLESHDR/) • [PyPI](https://pypi.org/project/drqeh/) • [Documentation](https://github.com/KALLESHDR/) 

</div>
