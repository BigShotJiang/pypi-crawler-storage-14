"""
Test file for AI Validator package
"""

def testValidatorInitialization():
    """Test that Validator can be initialized"""
    from aiValidator import Validator
    from aiValidator.config import Config
    
    validator = Validator(
        key="test_key",
        pid="test_product",
        mid="USQDQVKC68"
    )
    
    assert validator.key == "test_key"
    assert validator.pid == "test_product"
    assert validator.mid == "USQDQVKC68"
    assert validator.baseUrl == Config.BASE_URL
    print("✅ testValidatorInitialization passed")


def testQueueEndpoint():
    """Test queue endpoint is correctly formed"""
    from aiValidator import Validator
    from aiValidator.config import Config
    
    validator = Validator(
        key="test_key",
        pid="test_product",
        mid="USQDQVKC68"
    )
    
    expectedEndpoint = f"{Config.BASE_URL}{Config.QUEUE_ENDPOINT}"
    assert validator.queueEndpoint == expectedEndpoint
    print("✅ testQueueEndpoint passed")


def testExceptionsImport():
    """Test that all exceptions can be imported"""
    from aiValidator import (
        AIValidatorError,
        AuthenticationError,
        ValidationError,
        APIError
    )
    
    assert AIValidatorError is not None
    assert AuthenticationError is not None
    assert ValidationError is not None
    assert APIError is not None
    print("✅ testExceptionsImport passed")


def testMissingApiKey():
    """Test that missing API key raises error"""
    from aiValidator import Validator, AuthenticationError
    
    errorRaised = False
    try:
        validator = Validator(key="", pid="test", mid="test")
    except AuthenticationError:
        errorRaised = True
    
    assert errorRaised, "Should have raised AuthenticationError"
    print("✅ testMissingApiKey passed")


def testMissingProductId():
    """Test that missing product ID raises error"""
    from aiValidator import Validator
    
    errorRaised = False
    try:
        validator = Validator(key="test", pid="", mid="test")
    except ValueError:
        errorRaised = True
    
    assert errorRaised, "Should have raised ValueError"
    print("✅ testMissingProductId passed")


def testMissingMerchantId():
    """Test that missing merchant ID raises error"""
    from aiValidator import Validator
    
    errorRaised = False
    try:
        validator = Validator(key="test", pid="test", mid="")
    except ValueError:
        errorRaised = True
    
    assert errorRaised, "Should have raised ValueError"
    print("✅ testMissingMerchantId passed")


def testExtraParamMerging():
    """Test that extra params are properly handled"""
    from aiValidator import Validator
    
    validator = Validator(
        key="test_key",
        pid="test_product",
        mid="USQDQVKC68"
    )
    
    # This should not raise any errors
    extra = {
        "fc": "kyc",
        "fid": "123",
        "uid": "user_456",
        "formValues": {"field1": "value1"}
    }
    
    # We can't test the actual API call without mocking,
    # but we can verify the validator accepts it
    assert validator is not None
    print("✅ testExtraParamMerging passed")


def runAllTests():
    """Run all tests"""
    print("\n🧪 Running AI Validator Tests...\n")
    
    testValidatorInitialization()
    testQueueEndpoint()
    testExceptionsImport()
    testMissingApiKey()
    testMissingProductId()
    testMissingMerchantId()
    testExtraParamMerging()
    
    print("\n✅ All tests passed!\n")


if __name__ == "__main__":
    runAllTests()