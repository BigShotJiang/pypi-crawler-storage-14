"""
AI Validator - Python SDK for document validation and text extraction
"""

__version__ = "0.1.1"

from .validator import Validator
from .exceptions import (
    AIValidatorError,
    AuthenticationError,
    ValidationError,
    APIError
)

__all__ = [
    "Validator",
    "AIValidatorError", 
    "AuthenticationError",
    "ValidationError",
    "APIError"
]