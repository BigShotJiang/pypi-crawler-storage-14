"""Custom exceptions for AI Validator"""

class AIValidatorError(Exception):
    """Base exception for AI Validator"""
    pass


class AuthenticationError(AIValidatorError):
    """Raised when API key authentication fails"""
    pass


class ValidationError(AIValidatorError):
    """Raised when document validation fails"""
    pass


class APIError(AIValidatorError):
    """Raised when API request fails"""
    def __init__(self, message, statusCode=None, response=None):
        super().__init__(message)
        self.statusCode = statusCode
        self.response = response