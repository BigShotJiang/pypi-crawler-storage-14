"""Configuration for AI Validator"""


class Config:
    """Configuration class"""
    
    # =====================================================
    # CHANGE THIS URL WHEN READY FOR PRODUCTION
    # =====================================================
    # Development: http://127.0.0.1:5002
    # Production:  https://api.yourdomain.com
    # =====================================================
    
    BASE_URL = "http://127.0.0.1:5002"
    
    # API endpoints
    QUEUE_ENDPOINT = "/server/api3/queue/validation"
    
    # Default timeout
    DEFAULT_TIMEOUT = 30