# AI Validator

Python SDK for AI-powered document validation and text extraction.

## Installation
```bash
pip install ai-doc-validator-sdk
```

## Quick Start
```python
from ai-doc-Validator-sdk import Validator

# Initialize
validator = Validator(
    key="sk_test_xxxxxxxxxxxxxxxxxxxxxxxx",   # Your API key
    pid="tnmc",                                # Product ID (e.g., tnmc, kyc_pro, etc.)
    mid="USQDQVKC68"                           # Merchant/User ID (_id from your users collection)
)

# Extract text from a document
result = validator.extractText(
    publicUrl="https://your-bucket.s3.amazonaws.com/id-card.pdf",
    extra={
        "fc": "kyc",
        "fid": "F123456",
        "uid": "user_789",
        "ruid": "request_abc123"
    }
)

print(f"Status: {result['status']}")
print(f"Queue: {result['payload']['queueName']}")
```

## Features

- Text extraction from documents
- Face validation
- Combined validation
- Webhook support for async results

## Configuration

### Development (default)
```python
validator = Validator(
    apiKey="sk_test_...",
    productId="pId"
)
# Uses: http://127.0.0.1:5002
```

### Production
```python
validator = Validator(
    apiKey="sk_prod_...",
    productId="pId",
    environment="production"
)
# Uses: https://api.yourproduction.com
```

### Custom URL
```python
validator = Validator(
    apiKey="sk_test_...",
    productId="pId",
    baseUrl="http://your-custom-domain.com"
)
```