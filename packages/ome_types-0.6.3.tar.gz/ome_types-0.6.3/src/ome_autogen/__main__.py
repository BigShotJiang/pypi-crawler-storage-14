from ome_autogen.main import build_model  # pragma: no cover

build_model()  # pragma: no cover
