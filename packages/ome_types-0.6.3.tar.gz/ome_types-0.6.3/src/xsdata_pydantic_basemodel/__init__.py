"""xsdata pydantic plugin using BaseModel."""

__version__ = "0.1.0"  # FIXME when you pull it out of the ome-types repo
__author__ = "Talley Lambert"
__email__ = "talley.lambert@gmail.com"
