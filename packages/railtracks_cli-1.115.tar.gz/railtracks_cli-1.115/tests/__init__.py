"""
Tests for railtracks-cli package
"""
