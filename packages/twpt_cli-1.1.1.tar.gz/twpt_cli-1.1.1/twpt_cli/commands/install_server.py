"""Install local server command for ThreatWinds Pentest CLI.

This command installs the ThreatWinds Pentest Agent as a local systemd service.
LINUX ONLY: Supported on Kali Linux and Ubuntu.
"""

import sys
from pathlib import Path

import click
from rich.console import Console

from twpt_cli.config import save_credentials, clear_endpoint_config
from twpt_cli.config.constants import SERVICE_NAME
from twpt_cli.service import (
    download_agent,
    extract_agent,
    setup_python_environment,
    install_service,
    start_agent_service,
    is_service_installed,
    is_service_running,
    get_agent_path,
    check_linux_only,
    check_root_privileges,
)

console = Console()

# Constants
API_PORT = "9741"
GRPC_PORT = "9742"


@click.command(name='install-srv')
@click.option(
    '--api-key',
    help='API Key for ThreatWinds Pentest (required)'
)
@click.option(
    '--api-secret',
    help='API Secret for ThreatWinds Pentest (required)'
)
@click.option(
    '--force',
    is_flag=True,
    help='Force reinstall even if server is already running'
)
def install_server(api_key: str, api_secret: str, force: bool):
    """Install and configure local ThreatWinds Pentest server.

    LINUX ONLY: This command installs the ThreatWinds Pentest Agent as a
    local systemd service on your Linux system (Kali Linux or Ubuntu).

    This command will:
    1. Download the ThreatWinds Pentest agent
    2. Setup Python virtual environment with dependencies
    3. Install and enable systemd service
    4. Start the agent service
    5. Save API credentials
    6. Configure CLI to use local server

    The server will run as a systemd service and will be accessible at
    localhost:9741 (API) and localhost:9742 (gRPC).

    Requirements:
    - Linux (Kali Linux or Ubuntu)
    - Root/sudo privileges
    - Python 3.8+
    - Internet connection

    Examples:
        sudo twpt-cli install-srv --api-key YOUR_KEY --api-secret YOUR_SECRET
        sudo twpt-cli install-srv --force  # Force reinstall

    For macOS/Windows, use remote mode instead:
        twpt-cli init  # Then select 'remote' and provide server address
    """
    console.print("\n╔════════════════════════════════════════════╗", style="cyan")
    console.print("║   ThreatWinds Pentest Server Installation  ║", style="cyan")
    console.print("╚════════════════════════════════════════════╝\n", style="cyan")

    # Check if running on Linux
    if not check_linux_only():
        sys.exit(1)

    # Check for root privileges
    if not check_root_privileges():
        sys.exit(1)

    # Check if already running
    if not force:
        if is_service_installed() and is_service_running():
            console.print("✓ ThreatWinds server is already running", style="green")
            console.print("\nIf you want to reinstall, use the --force flag", style="yellow")
            console.print("  sudo twpt-cli install-srv --force", style="white")
            sys.exit(0)

    # Prompt for credentials if not provided
    if not api_key or not api_secret:
        console.print("[yellow]API credentials are required for the local server[/yellow]\n")
        if not api_key:
            api_key = console.input("Enter API/Pentest Key: ")
        if not api_secret:
            from rich.prompt import Prompt
            api_secret = Prompt.ask("Enter API/Pentest Secret", password=True, console=console)

    console.print("\nInstalling ThreatWinds Pentest Agent...\n", style="cyan")

    # Step 1: Download agent
    console.print("[bold]Step 1:[/bold] Downloading agent package...", style="blue")
    zip_path = download_agent()
    if not zip_path:
        console.print("\n✗ Installation failed", style="red")
        sys.exit(1)
    console.print()

    # Step 2: Extract agent
    console.print("[bold]Step 2:[/bold] Extracting agent...", style="blue")
    if not extract_agent(zip_path):
        console.print("\n✗ Installation failed", style="red")
        sys.exit(1)
    console.print()

    # Step 3: Setup Python environment
    console.print("[bold]Step 3:[/bold] Setting up Python environment...", style="blue")
    if not setup_python_environment():
        console.print("\n✗ Installation failed", style="red")
        sys.exit(1)
    console.print()

    # Step 4: Install systemd service
    console.print("[bold]Step 4:[/bold] Installing systemd service...", style="blue")
    if not install_service():
        console.print("\n✗ Installation failed", style="red")
        sys.exit(1)
    console.print()

    # Step 5: Start service
    console.print("[bold]Step 5:[/bold] Starting agent service...", style="blue")
    if not start_agent_service():
        console.print("\n✗ Installation failed", style="red")
        console.print("Check logs with: journalctl -u TWAgent -f", style="yellow")
        sys.exit(1)
    console.print()

    # Step 6: Save credentials
    console.print("[bold]Step 6:[/bold] Saving API credentials...", style="blue")
    try:
        save_credentials(api_key, api_secret)
        console.print("✓ API credentials saved", style="green")
    except Exception as e:
        console.print(f"✗ Failed to save credentials: {e}", style="red")
        sys.exit(1)

    # Step 7: Configure CLI to use local server
    console.print("\n[bold]Step 7:[/bold] Configuring CLI to use local server...", style="blue")
    try:
        # Clear any remote endpoint config to use localhost
        clear_endpoint_config()
        console.print("✓ CLI configured to use local server", style="green")
    except Exception as e:
        console.print(f"✗ Failed to configure CLI: {e}", style="red")
        sys.exit(1)

    # Success message
    console.print("\n╔════════════════════════════════════════════╗", style="green")
    console.print("║        Installation Completed!              ║", style="green bold")
    console.print("╚════════════════════════════════════════════╝\n", style="green")

    console.print("✓ The ThreatWinds Pentest server is running locally and ready to use!", style="green")

    agent_path = get_agent_path()
    console.print("\n[bold]Server Details:[/bold]", style="cyan")
    console.print(f"  Service Name: {SERVICE_NAME}", style="white")
    console.print(f"  Agent Path: {agent_path}", style="white")
    console.print(f"  API Endpoint: http://localhost:{API_PORT}", style="white")
    console.print(f"  gRPC Endpoint: localhost:{GRPC_PORT}", style="white")
    console.print(f"  Status: [green]Running[/green]")

    console.print("\n[bold]Quick Start:[/bold]", style="cyan")
    console.print("  twpt-cli                                    # Start interactive shell", style="white")
    console.print("  twpt-cli run --target example.com           # Run a pentest", style="white")
    console.print("  twpt-cli list                               # List pentests", style="white")

    console.print("\n[bold]Service Management:[/bold]", style="cyan")
    console.print(f"  systemctl status {SERVICE_NAME}             # Check status", style="white")
    console.print(f"  systemctl stop {SERVICE_NAME}               # Stop the server", style="white")
    console.print(f"  systemctl start {SERVICE_NAME}              # Start the server", style="white")
    console.print(f"  journalctl -u {SERVICE_NAME} -f             # View server logs", style="white")
    console.print("  twpt-cli uninstall --remove-data            # Uninstall everything\n", style="white")
