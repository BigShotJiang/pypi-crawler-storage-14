"""
Setup script for PZSpec package.

Note: This file is kept for backwards compatibility.
The primary configuration is in pyproject.toml.
"""

from setuptools import setup

if __name__ == "__main__":
    setup()
