import logging
import os
from glob import glob
from time import perf_counter
from typing import Dict, Optional

import optuna
import numpy as np
import torch
import torch.nn.functional as F
from sklearn.metrics import mean_absolute_error, r2_score
from torch.utils.data import DataLoader

from polymon.exp.score import scaling_error
from polymon.exp.utils import EarlyStopping
from polymon.model.base import ModelWrapper


class Trainer:
    """Trainer for the model.
    
    Args:
        out_dir (str): The directory to save the model and results.
        model (nn.Module): The model to train.
        lr (float): The learning rate.
        num_epochs (int): The number of epochs to train.
        logger (logging.Logger): The logger. If not provided, a logger will be
            created in the `out_dir`.
        ema_decay (float): The decay rate for the EMA. If 0, EMA will not be
            used. Default is 0.
        device (torch.device): The device to train on. Default is `cuda`.
        early_stopping_patience (int): The number of epochs to wait before 
            stopping the training. Default is 10.
    """
    def __init__(
        self,
        out_dir: str,
        model: ModelWrapper,
        lr: float,
        num_epochs: int,
        logger: logging.Logger,
        device: torch.device = 'cuda',
        early_stopping_patience: int = 10,
    ):
        os.makedirs(out_dir, exist_ok=True)
        self.out_dir = out_dir
        self.lr = lr
        self.num_epochs = num_epochs
        self.device = device
        self.model = model
        self.logger = logger
    
        # Early stopping
        self.early_stopping = EarlyStopping(
            patience=early_stopping_patience,
            save_dir=os.path.join(self.out_dir, 'ckpt'),
        )  

    def build_optimizer(self) -> torch.optim.Optimizer:
        """Build the optimizer.
        
        Returns:
            `torch.optim.Optimizer`: The optimizer.
        """
        return torch.optim.AdamW(
            self.model.parameters(), 
            lr=self.lr,
            weight_decay=1e-12
        )

    def train_step(
        self,
        ith_epoch: int,
        train_loader: DataLoader,
        val_loader: DataLoader,
        optimizer: torch.optim.Optimizer,
        label: str,
    ) -> float:
        """Train the model for one epoch.
        
        Args:
            ith_epoch (int): The current epoch.
            train_loader (DataLoader): The training data loader.
            val_loader (DataLoader): The validation data loader.
            optimizer (torch.optim.Optimizer): The optimizer.

        Returns:
            `float`: The F1 score on the validation set.
        """
        epoch_digits = len(str(self.num_epochs))
        
        for i, batch in enumerate(train_loader):
            optimizer.zero_grad()
            loss = self.model(batch, F.huber_loss, self.device)
            loss.backward()
            optimizer.step()

        # Report progress
        val_metrics = self.eval(val_loader, label)
        train_metrics = self.eval(train_loader, label)
        self.logger.info(
            f'[{str(ith_epoch).zfill(epoch_digits)}/{self.num_epochs}]'
            f'[Loss: {loss.item():.2f}]'
            f'[Train MAE: {train_metrics["mae"]:.3f}]'
            f'[Train R2: {train_metrics["r2"]:.3f}]'
            f'[Val MAE: {val_metrics["mae"]:.3f}]'
            f'[Val R2: {val_metrics["r2"]:.3f}]'
        )
        return val_metrics['mae']

    def train(
        self,
        train_loader: DataLoader,
        val_loader: DataLoader,
        test_loader: Optional[DataLoader] = None,
        label: str = 'Rg',
        trial: Optional[optuna.Trial] = None,
    ):
        """Train the model.
        
        Args:
            train_loader (DataLoader): The training data loader.
            val_loader (DataLoader): The validation data loader.
            test_loader (DataLoader): The test data loader.
            label (str): The label to train on.
            trial (optuna.Trial): The trial object. If provided, the model will
                be stopped training when the pruning is triggered.
            n_fold (int): The number of folds. This is used to report the 
        """
        start_time = perf_counter()
        optimizer = self.build_optimizer()
        for ith_epoch in range(self.num_epochs):
            val_mae = self.train_step(
                ith_epoch, 
                train_loader, 
                val_loader, 
                optimizer,
                label,
            )
            
            if trial is not None:
                trial.report(val_mae, ith_epoch)
                if trial.should_prune():
                    self.logger.info('Trial pruned')
                    raise optuna.TrialPruned()

            # Early stopping
            self.early_stopping(-val_mae, self.model, ith_epoch)
            if self.early_stopping.early_stop:
                self.logger.info(f'Early stopping at epoch {ith_epoch}')
                break
        
        # Load the best model
        ckpts = glob(os.path.join(self.out_dir, 'ckpt', '*.pt'))
        ckpts.sort(key=os.path.getmtime)
        save_path = ckpts[-1]
        self.model = ModelWrapper.from_file(save_path)
        self.logger.info(f'Load best model from {save_path}')

        # Evaluate the best model on the test set
        if test_loader is None:
            test_loader = val_loader
            self.logger.info('No test set provided, using validation set as test set')
            
        test_metrics = self.eval(test_loader, label)
        for metric_name, metric_value in test_metrics.items():
            self.logger.info(f'{metric_name}: {metric_value:.4f}')

        end_time = perf_counter()
        self.logger.info(f'Time taken: {end_time - start_time:.2f} seconds')
        self.logger.info(f'--------------------------------')
        
        test_err = test_metrics['mae']
        return test_err

    @torch.no_grad()
    def eval(
        self,
        loader: DataLoader,
        label: str,
    ) -> Dict[str, float]:
        """Evaluate the model on the given data loader.
        
        Args:
            loader (DataLoader): The data loader.
            metrics (List[Literal['mae', 'r2']]): The metrics to evaluate. If
                `None`, all metrics will be evaluated.
        
        Returns:
            `Dict[str, float]`: The metrics and their values.
        """
        self.model.eval()
        self.model.to(self.device)
        
        # Evaluate the model
        y_trues = []
        y_preds = []
        # sources = []
        for i, batch in enumerate(loader):
            batch = batch.to(self.device)
            y_pred = self.model.model(batch)
            y_pred = self.model.normalizer.inverse(y_pred)
            y_pred = y_pred + getattr(batch, 'estimated_y', 0)
            y_true = batch.y.detach() + getattr(batch, 'estimated_y', 0)
            y_trues.extend(y_true.cpu().numpy())
            y_preds.extend(y_pred.detach().cpu().numpy())
            # if getattr(batch, 'source', None) is not None:
            #     sources.extend(batch.source.cpu().numpy())
        
        # if len(sources) > 0:
        #     internal_mask = np.array(sources) == 1
        # else:
        #     internal_mask = np.ones(len(y_trues), dtype=bool)

        # if internal_mask.sum() == 0:
        #     return {'mae': np.nan, 'r2': np.nan, 'scaling_error': np.nan}

        y_trues = np.array(y_trues) # [internal_mask]
        y_preds = np.array(y_preds) # [internal_mask]
        if np.isnan(y_trues).any() or np.isnan(y_preds).any():
            return {'mae': np.nan, 'r2': np.nan, 'scaling_error': np.nan}
        metrics = {}
        metrics['mae'] = mean_absolute_error(y_trues, y_preds)
        metrics['r2'] = r2_score(y_trues, y_preds)
        metrics['scaling_error'] = scaling_error(y_trues, y_preds, label)
        return metrics