DEFAULT_BUILD_SCRIPT = "hatch_build.py"
DEFAULT_CONFIG_FILE = "hatch.toml"


class VersionEnvVars:
    VALIDATE_BUMP = "HATCH_VERSION_VALIDATE_BUMP"
