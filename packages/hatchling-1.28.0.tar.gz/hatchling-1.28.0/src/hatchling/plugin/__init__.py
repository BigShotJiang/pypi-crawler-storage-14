import pluggy

hookimpl = pluggy.HookimplMarker("hatch")
