import sys

if __name__ == "__main__":
    from hatchling.cli import hatchling

    sys.exit(hatchling())
