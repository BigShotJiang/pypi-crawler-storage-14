"""Scan result data structures."""
from dataclasses import dataclass, field
from typing import Optional, Dict, Any, List
from datetime import datetime


@dataclass
class ScanResult:
    """Result of a subdomain takeover scan."""
    
    domain: str
    vulnerable: bool
    confidence: int  # 0-100
    provider: Optional[str] = None
    cname: Optional[str] = None
    status_code: Optional[int] = None
    response_body: Optional[str] = None
    fingerprint_matched: Optional[str] = None
    exploit_attempted: bool = False
    exploit_successful: bool = False
    exploit_details: Optional[Dict[str, Any]] = None
    dns_records: Dict[str, List[str]] = field(default_factory=dict)
    tls_info: Optional[Dict[str, Any]] = None
    timestamp: datetime = field(default_factory=datetime.utcnow)
    scan_duration: float = 0.0
    error: Optional[str] = None
    notes: List[str] = field(default_factory=list)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for serialization."""
        return {
            "domain": self.domain,
            "vulnerable": self.vulnerable,
            "confidence": self.confidence,
            "provider": self.provider,
            "cname": self.cname,
            "status_code": self.status_code,
            "fingerprint_matched": self.fingerprint_matched,
            "exploit_attempted": self.exploit_attempted,
            "exploit_successful": self.exploit_successful,
            "exploit_details": self.exploit_details,
            "dns_records": self.dns_records,
            "tls_info": self.tls_info,
            "timestamp": self.timestamp.isoformat(),
            "scan_duration": self.scan_duration,
            "error": self.error,
            "notes": self.notes,
        }
    
    @property
    def severity(self) -> str:
        """Get severity level based on confidence."""
        if not self.vulnerable:
            return "safe"
        if self.confidence >= 90:
            return "critical"
        elif self.confidence >= 70:
            return "high"
        elif self.confidence >= 50:
            return "medium"
        else:
            return "low"
