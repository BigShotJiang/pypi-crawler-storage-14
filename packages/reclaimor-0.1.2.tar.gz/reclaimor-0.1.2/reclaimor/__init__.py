"""
ReClaimor - Advanced subdomain takeover scanner
Author: Lakshmikanthan (@letchu)
GitHub: https://github.com/letchupkt
"""

__version__ = "0.1.2"
__author__ = "Lakshmikanthan"
__license__ = "MIT"

from reclaimor.scanner.engine import Scanner
from reclaimor.scanner.result import ScanResult

__all__ = ["Scanner", "ScanResult", "__version__"]
