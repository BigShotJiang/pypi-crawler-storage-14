"""Configuration management for ReClaimor."""
import os
from pathlib import Path
from typing import Optional
import yaml


class Config:
    """Configuration container for ReClaimor."""
    
    def __init__(
        self,
        concurrency: int = 50,
        timeout: int = 15,
        retries: int = 3,
        auto_exploit: bool = False,
        safe_mode: bool = True,
        rate_limit: int = 10,
        webhook_url: Optional[str] = None,
        verbose: bool = False,
        debug: bool = False,
        user_agent: str = "ReClaimor/0.1.0",
        fingerprints_dir: Optional[Path] = None,
    ):
        self.concurrency = concurrency
        self.timeout = timeout
        self.retries = retries
        self.auto_exploit = auto_exploit
        self.safe_mode = safe_mode
        self.rate_limit = rate_limit
        self.webhook_url = webhook_url
        self.verbose = verbose
        self.debug = debug
        self.user_agent = user_agent
        self.fingerprints_dir = fingerprints_dir or self._default_fingerprints_dir()
    
    @staticmethod
    def _default_fingerprints_dir() -> Path:
        """Get default fingerprints directory."""
        return Path(__file__).parent / "fingerprints"
    
    @classmethod
    def from_file(cls, config_path: Path) -> "Config":
        """Load configuration from YAML file."""
        if not config_path.exists():
            return cls()
        
        with open(config_path, "r") as f:
            data = yaml.safe_load(f) or {}
        
        return cls(**data)
    
    @classmethod
    def from_default(cls) -> "Config":
        """Load configuration from default location (~/.reclaimor/config.yaml)."""
        default_path = Path.home() / ".reclaimor" / "config.yaml"
        return cls.from_file(default_path)
