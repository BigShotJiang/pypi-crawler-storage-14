from .conf import Config

conf = Config()
