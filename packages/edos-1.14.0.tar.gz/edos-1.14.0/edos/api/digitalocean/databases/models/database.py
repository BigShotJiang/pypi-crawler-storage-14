import dataclasses


@dataclasses.dataclass
class Database:
    name: str
