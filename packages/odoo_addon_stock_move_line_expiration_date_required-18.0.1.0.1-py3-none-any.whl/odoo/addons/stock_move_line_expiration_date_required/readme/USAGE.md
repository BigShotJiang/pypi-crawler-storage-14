Go to a warehouse entry that has a product with expiration date
configured to 0 days after receipt and fill in its expiration date
manually.

Check the expiration date is required now and doesn't let to continue
until you fill it.
