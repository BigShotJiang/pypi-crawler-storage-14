def test_foo() -> None:
    import xgboost  # noqa: F401
