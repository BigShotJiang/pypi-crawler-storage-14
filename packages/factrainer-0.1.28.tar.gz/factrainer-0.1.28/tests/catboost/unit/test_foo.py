def test_foo() -> None:
    import catboost  # noqa: F401
