# PredMode

::: factrainer.core.PredMode
