# SingleModelContainer

<!-- Workaround: Explicitly specifying members since the global options filter is not working as expected -->

::: factrainer.core.SingleModelContainer
    options:
        members: 
        - train 
        - predict 
        - evaluate
        - raw_model 
        - train_config 
        - pred_config 

