# CvModelContainer

<!-- Workaround: Explicitly specifying members since the global options filter is not working as expected -->

::: factrainer.core.CvModelContainer
    options:
        members: 
        - train 
        - predict 
        - evaluate
        - raw_model 
        - train_config 
        - pred_config 
        - cv_indices 
        - k_fold
