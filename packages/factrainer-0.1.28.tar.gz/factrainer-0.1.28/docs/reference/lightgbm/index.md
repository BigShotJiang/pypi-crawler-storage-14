# factrainer.lightgbm

Optionally installable plugin package for LightGBM integration.
