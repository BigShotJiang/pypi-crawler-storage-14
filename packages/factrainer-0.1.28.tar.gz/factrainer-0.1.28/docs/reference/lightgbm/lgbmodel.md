# LgbModel

::: factrainer.lightgbm.LgbModel
    options:
        members:
            - model