# LgbModelConfig

::: factrainer.lightgbm.LgbModelConfig
    options:
        members:
            - learner
            - predictor
            - train_config
            - pred_config
            - create