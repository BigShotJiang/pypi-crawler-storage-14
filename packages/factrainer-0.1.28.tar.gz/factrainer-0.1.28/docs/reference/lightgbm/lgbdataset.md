# LgbDataset

::: factrainer.lightgbm.LgbDataset
    options:
        members:
            - dataset