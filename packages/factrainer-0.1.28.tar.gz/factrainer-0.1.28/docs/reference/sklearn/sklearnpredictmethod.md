# SklearnPredictMethod

::: factrainer.sklearn.SklearnPredictMethod
