# SklearnTrainConfig

::: factrainer.sklearn.SklearnTrainConfig
    options:
        members:
            - estimator