# SklearnPredictConfig

::: factrainer.sklearn.SklearnPredictConfig
    options:
        members:
            - predict_method