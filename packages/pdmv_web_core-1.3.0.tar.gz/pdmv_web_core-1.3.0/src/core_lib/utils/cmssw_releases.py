"""This modules manages queries related to the cms-sw releases."""

import collections
import logging
import re
import time

import requests

from ..utils.cache import TimeoutCache
from ..utils.locker import Locker


class CMSSWReleases:
    """Load the cms-sw releases file and manage queries for it."""

    __singleton_instance = None

    def __new__(cls, *args, **kwargs):
        """Instantiate a singleton instance and manage it."""
        if cls.__singleton_instance is None:
            cls.__singleton_instance = super().__new__(cls)
        return cls.__singleton_instance

    def __init__(self):
        if hasattr(self, "_initialized") and self._initialized:
            return
        self.__setup__()

    def __setup__(self):
        self.logger = logging.getLogger()
        self._loading_strategies = [
            self._load_file_github,
            self._load_file_eos,
        ]
        self._locker = Locker()
        self._cache = TimeoutCache()
        self._release_file_validator = None
        self._initialized = True

    @property
    def _map(self) -> collections.ChainMap:
        with self._locker.get_lock("cmssw-releases"):
            releases_map = self._cache.get("map")
            if releases_map:
                return releases_map

            releases_map = self._load_build_release_tree()
            self._cache.set("map", releases_map)
            return releases_map

    def _load_build_release_tree(self):
        """Load the release file and create a map for it."""
        release_file = self._load_releases_file()
        release_file_validated = self._validate_release_file(release_file)
        return self._build_release_tree(release_file_validated)

    def _load_releases_file(self) -> list[str]:
        """Load the release's file."""
        releases_map_content: list[str] = []
        for loader in self._loading_strategies:
            content: list[str] = loader()
            if content:
                releases_map_content = content
                break

        if not releases_map_content:
            raise RuntimeError(
                "Unable to load the content of the `cmssw` releases file: releases.map"
            )
        else:
            return releases_map_content

    def _load_file_eos(self) -> list[str]:
        """Read the file via /cvmfs from the default expected path.

        Returns:
            The file's content read line by line. In case it is not
                possible to read the file, an empty list is returned.
        """
        releases_map_path = "/cvmfs/cms.cern.ch/releases.map"
        try:
            with open(file=releases_map_path, encoding="utf-8") as file:
                releases_map_content = file.readlines()
                return [line.strip() for line in releases_map_content]
        except Exception as e:
            self.logger.debug(
                "Unable to load the file using strategy _load_file_eos: %s",
                e,
                exc_info=True,
            )
            return []

    def _load_file_github(self) -> list[str]:
        """Read the file performing a query to the `cms-sw` official repository.

        Returns:
            The file's content read line by line. In case it is not
                possible to read the file, an empty list is returned.
        """
        releases_map_url = "https://raw.githubusercontent.com/cms-sw/cms-bot/refs/heads/master/releases.map"
        for _ in range(5):
            response = requests.get(url=releases_map_url)
            if response.status_code == 200:
                return [line.strip() for line in response.text.splitlines()]
            else:
                time.sleep(1)

        self.logger.debug("Unable to load the file using strategy _load_file_github")
        return []

    def _validate_release_file(self, releases_map_content: list[str]) -> list[str]:
        """Validate the format for the `releases.map` file.

        This discards records not complying with the expected pattern

        Returns:
            List of validated records from the file.
        """
        validated_records = []
        if not self._release_file_validator:
            validator = re.compile(
                r"^architecture=(slc?\d+|el\d+)+_[A-Za-z0-9]+_[^;]+;"
                r"label=CMSSW_\d+_\d+_[^;]+;"
                r"type=[^;]+;"
                r"state=[^;]+;"
                r"prodarch=\d+;"
                r"(?:[^;]+=[^;]+;)*$"
            )
            self._release_file_validator = validator

        for record in releases_map_content:
            if not self._release_file_validator.match(record):
                error_message = f"Unable to validate record ({record}) with regex ({self._release_file_validator.pattern}), discarding it"
                self.logger.debug(error_message)
            else:
                validated_records.append(record)

        return validated_records

    def _build_release_tree(
        self, releases_map_content: list[str]
    ) -> collections.ChainMap:
        """Build a release tree for querying releases and get the architecture."""
        records_list: list[dict] = []
        for record in releases_map_content:
            single_record_dict = {
                key: value
                for single_item in record.strip().split(";")
                if single_item
                for key, value in [single_item.split("=", 1)]
            }
            records_list.append(single_record_dict)

        # Build one view per release name and architecture
        by_label = {}
        by_architecture = {}
        for record in records_list:
            label = record["label"]
            architecture = record["architecture"]

            by_label.setdefault(label, []).append(record)
            by_architecture.setdefault(architecture, []).append(record)

        return collections.ChainMap(by_label, by_architecture)

    def _query_record(
        self,
        query: str,
        state: str = "Announced",
        prodarch: str = "1",
    ) -> list[dict]:
        """Perform a query giving the release name or the architecture."""
        view: list[dict] = self._map.get(query, [])
        filtered = [
            element
            for element in view
            if element.get("state") == state and element.get("prodarch") == prodarch
        ]
        elements_sorted = sorted(filtered, key=self._sort_release_record, reverse=True)
        return elements_sorted

    def _extract_first_number(self, sample: str) -> int | float:
        """Extract the first digits found in a string.

        Returns:
            The integer related to those digits, if not found
                a `float('inf')` will be returned.
        """
        try:
            found = re.search(r"\d+", sample)
            if found:
                return int(found.group())
            else:
                return float("inf")
        except:
            return float("inf")

    def _sort_release_record(self, record: dict):
        """Sort the release record by the architecture."""
        architecture = record.get("architecture", "X_Y_Z")
        os_name, _, compiler_name = architecture.split("_")
        os_version = self._extract_first_number(os_name)
        compiler_version = self._extract_first_number(compiler_name)
        return (os_version, compiler_version)

    def get_scram_arch(self, cmssw_release: str):
        """Get the scram architecture related to a cms-sw release"""
        options = self._query_record(query=cmssw_release)
        if options:
            most_recent_architecture = options[0]
            return most_recent_architecture.get("architecture")

        # Try to check if there's a default bugfix or minor for the release
        cmssw_name_components = cmssw_release.split("_")[:4]
        for idx_to_default in range(1, 4):
            cmssw_default_query = "_".join(cmssw_name_components)
            options = self._query_record(query=cmssw_default_query)
            if options:
                self.logger.debug(
                    "Using the family related default (%s) for (%s)",
                    cmssw_default_query,
                    cmssw_release,
                )
                most_recent_architecture = options[0]
                return most_recent_architecture.get("architecture")
            else:
                # Also the character X is used but only for development releases.
                cmssw_name_components[-idx_to_default] = "0"

        return None
