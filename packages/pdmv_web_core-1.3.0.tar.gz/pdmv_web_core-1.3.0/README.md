# PdmV Web Tool Core

This is a library that acts as a base for PdmV web tools. It has some useful functions as well as base code for objects, controllers and API.

# Installation

Install this component via:

```bash
pip install pdmv-web-core
```

All components are available under the `core_lib` package, for instance:

```python
from core_lib.utils.common_utils import run_commands_in_cmsenv
```
