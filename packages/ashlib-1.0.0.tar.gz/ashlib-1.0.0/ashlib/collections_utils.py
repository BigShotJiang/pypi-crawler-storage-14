"""
Collection and data manipulation utility functions.
"""

from typing import Any, Iterable, Callable, Optional
from itertools import islice


def chunk_list(items: list, chunk_size: int) -> list[list]:
    """
    Split a list into chunks of specified size.
    
    Args:
        items: List to chunk
        chunk_size: Size of each chunk
    
    Returns:
        List of chunks
    
    Example:
        >>> chunk_list([1, 2, 3, 4, 5], 2)
        [[1, 2], [3, 4], [5]]
    """
    return [items[i:i + chunk_size] for i in range(0, len(items), chunk_size)]


def flatten_dict(d: dict, parent_key: str = '', sep: str = '.') -> dict:
    """
    Flatten a nested dictionary.
    
    Args:
        d: Dictionary to flatten
        parent_key: Parent key prefix
        sep: Separator for nested keys
    
    Returns:
        Flattened dictionary
    
    Example:
        >>> flatten_dict({"a": {"b": 1, "c": 2}})
        {'a.b': 1, 'a.c': 2}
    """
    items = []
    for k, v in d.items():
        new_key = f"{parent_key}{sep}{k}" if parent_key else k
        if isinstance(v, dict):
            items.extend(flatten_dict(v, new_key, sep=sep).items())
        else:
            items.append((new_key, v))
    return dict(items)


def unflatten_dict(d: dict, sep: str = '.') -> dict:
    """
    Unflatten a dictionary with dotted keys.
    
    Args:
        d: Flattened dictionary
        sep: Separator used in keys
    
    Returns:
        Nested dictionary
    
    Example:
        >>> unflatten_dict({'a.b': 1, 'a.c': 2})
        {'a': {'b': 1, 'c': 2}}
    """
    result = {}
    for key, value in d.items():
        parts = key.split(sep)
        current = result
        for part in parts[:-1]:
            if part not in current:
                current[part] = {}
            current = current[part]
        current[parts[-1]] = value
    return result


def remove_duplicates(items: list, key: Optional[Callable] = None) -> list:
    """
    Remove duplicates from list while preserving order.
    
    Args:
        items: List with potential duplicates
        key: Optional function to extract comparison key
    
    Returns:
        List with duplicates removed
    
    Example:
        >>> remove_duplicates([1, 2, 2, 3, 1])
        [1, 2, 3]
    """
    seen = set()
    result = []
    
    for item in items:
        k = key(item) if key else item
        if k not in seen:
            seen.add(k)
            result.append(item)
    
    return result


def deep_merge(dict1: dict, dict2: dict) -> dict:
    """
    Deep merge two dictionaries.
    
    Args:
        dict1: First dictionary
        dict2: Second dictionary (takes precedence)
    
    Returns:
        Merged dictionary
    
    Example:
        >>> deep_merge({"a": 1, "b": {"c": 2}}, {"b": {"d": 3}})
        {'a': 1, 'b': {'c': 2, 'd': 3}}
    """
    result = dict1.copy()
    
    for key, value in dict2.items():
        if key in result and isinstance(result[key], dict) and isinstance(value, dict):
            result[key] = deep_merge(result[key], value)
        else:
            result[key] = value
    
    return result


def group_by(items: list, key: Callable) -> dict:
    """
    Group items by a key function.
    
    Args:
        items: List of items to group
        key: Function to extract grouping key
    
    Returns:
        Dictionary with grouped items
    
    Example:
        >>> group_by([1, 2, 3, 4], lambda x: x % 2)
        {1: [1, 3], 0: [2, 4]}
    """
    result = {}
    for item in items:
        k = key(item)
        if k not in result:
            result[k] = []
        result[k].append(item)
    return result


def partition(items: list, predicate: Callable) -> tuple[list, list]:
    """
    Partition list into two lists based on predicate.
    
    Args:
        items: List to partition
        predicate: Function that returns True/False
    
    Returns:
        Tuple of (items matching predicate, items not matching)
    
    Example:
        >>> partition([1, 2, 3, 4], lambda x: x % 2 == 0)
        ([2, 4], [1, 3])
    """
    true_items = []
    false_items = []
    
    for item in items:
        if predicate(item):
            true_items.append(item)
        else:
            false_items.append(item)
    
    return true_items, false_items


def pick_keys(d: dict, keys: list[str]) -> dict:
    """
    Pick specific keys from a dictionary.
    
    Args:
        d: Source dictionary
        keys: Keys to pick
    
    Returns:
        Dictionary with only specified keys
    
    Example:
        >>> pick_keys({"a": 1, "b": 2, "c": 3}, ["a", "c"])
        {'a': 1, 'c': 3}
    """
    return {k: d[k] for k in keys if k in d}


def omit_keys(d: dict, keys: list[str]) -> dict:
    """
    Omit specific keys from a dictionary.
    
    Args:
        d: Source dictionary
        keys: Keys to omit
    
    Returns:
        Dictionary without specified keys
    
    Example:
        >>> omit_keys({"a": 1, "b": 2, "c": 3}, ["b"])
        {'a': 1, 'c': 3}
    """
    return {k: v for k, v in d.items() if k not in keys}


def transpose_list(matrix: list[list]) -> list[list]:
    """
    Transpose a 2D list (swap rows and columns).
    
    Args:
        matrix: 2D list to transpose
    
    Returns:
        Transposed 2D list
    
    Example:
        >>> transpose_list([[1, 2], [3, 4]])
        [[1, 3], [2, 4]]
    """
    return list(map(list, zip(*matrix)))


def batch_items(items: Iterable, batch_size: int) -> Iterable[list]:
    """
    Batch items from an iterable efficiently.
    
    Args:
        items: Iterable to batch
        batch_size: Size of each batch
    
    Yields:
        Batches of items
    
    Example:
        >>> list(batch_items(range(5), 2))
        [[0, 1], [2, 3], [4]]
    """
    iterator = iter(items)
    while True:
        batch = list(islice(iterator, batch_size))
        if not batch:
            break
        yield batch
