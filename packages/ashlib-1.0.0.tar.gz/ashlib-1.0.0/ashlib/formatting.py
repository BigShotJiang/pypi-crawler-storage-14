"""
Formatting utility functions.
"""

import re
from typing import Optional


def format_currency(amount: float, currency: str = 'USD', symbol: str = '$') -> str:
    """
    Format number as currency.
    
    Args:
        amount: Amount to format
        currency: Currency code (default 'USD')
        symbol: Currency symbol (default '$')
    
    Returns:
        Formatted currency string
    
    Example:
        >>> format_currency(1234.56)
        '$1,234.56'
    """
    if currency == 'USD' or currency == 'EUR':
        return f"{symbol}{amount:,.2f}"
    else:
        return f"{amount:,.2f} {currency}"


def format_phone(phone: str, country: str = 'US') -> str:
    """
    Format phone number.
    
    Args:
        phone: Phone number (digits only)
        country: Country code (default 'US')
    
    Returns:
        Formatted phone number
    
    Example:
        >>> format_phone("1234567890")
        '(123) 456-7890'
    """
    # Remove non-digits
    digits = re.sub(r'\D', '', phone)
    
    if country == 'US' and len(digits) == 10:
        return f"({digits[:3]}) {digits[3:6]}-{digits[6:]}"
    elif country == 'US' and len(digits) == 11:
        return f"+{digits[0]} ({digits[1:4]}) {digits[4:7]}-{digits[7:]}"
    else:
        return phone


def abbreviate_number(num: float, precision: int = 1) -> str:
    """
    Abbreviate large numbers (1K, 1M, 1B, etc.).
    
    Args:
        num: Number to abbreviate
        precision: Decimal places (default 1)
    
    Returns:
        Abbreviated number string
    
    Example:
        >>> abbreviate_number(1500)
        '1.5K'
        >>> abbreviate_number(2500000)
        '2.5M'
    """
    num = float(num)
    
    if abs(num) < 1000:
        return str(int(num))
    
    suffixes = ['', 'K', 'M', 'B', 'T', 'Q']
    
    for i, suffix in enumerate(suffixes):
        size = 1000 ** i
        if abs(num) < 1000 * size:
            value = num / size
            if value == int(value):
                return f"{int(value)}{suffix}"
            else:
                return f"{value:.{precision}f}{suffix}"
    
    return f"{num:.{precision}e}"


def ordinal_number(n: int) -> str:
    """
    Convert number to ordinal (1st, 2nd, 3rd, etc.).
    
    Args:
        n: Number to convert
    
    Returns:
        Ordinal number string
    
    Example:
        >>> ordinal_number(1)
        '1st'
        >>> ordinal_number(23)
        '23rd'
    """
    if 11 <= n % 100 <= 13:
        suffix = 'th'
    else:
        suffix = {1: 'st', 2: 'nd', 3: 'rd'}.get(n % 10, 'th')
    
    return f"{n}{suffix}"


def format_percentage(value: float, decimals: int = 1) -> str:
    """
    Format number as percentage.
    
    Args:
        value: Value to format (0.0 to 1.0)
        decimals: Decimal places (default 1)
    
    Returns:
        Formatted percentage string
    
    Example:
        >>> format_percentage(0.8532, 2)
        '85.32%'
    """
    return f"{value * 100:.{decimals}f}%"


def format_bytes(bytes_value: int, precision: int = 2) -> str:
    """
    Format bytes as human-readable size.
    
    Args:
        bytes_value: Number of bytes
        precision: Decimal places (default 2)
    
    Returns:
        Formatted size string
    
    Example:
        >>> format_bytes(1536)
        '1.50 KB'
    """
    for unit in ['B', 'KB', 'MB', 'GB', 'TB', 'PB']:
        if bytes_value < 1024.0:
            return f"{bytes_value:.{precision}f} {unit}"
        bytes_value /= 1024.0
    
    return f"{bytes_value:.{precision}f} EB"


def format_duration(seconds: int) -> str:
    """
    Format seconds as human-readable duration.
    
    Args:
        seconds: Duration in seconds
    
    Returns:
        Formatted duration string
    
    Example:
        >>> format_duration(3665)
        '1h 1m 5s'
    """
    parts = []
    
    hours = seconds // 3600
    if hours:
        parts.append(f"{hours}h")
        seconds %= 3600
    
    minutes = seconds // 60
    if minutes:
        parts.append(f"{minutes}m")
        seconds %= 60
    
    if seconds or not parts:
        parts.append(f"{seconds}s")
    
    return ' '.join(parts)


def pluralize(count: int, singular: str, plural: Optional[str] = None) -> str:
    """
    Pluralize word based on count.
    
    Args:
        count: Count to check
        singular: Singular form
        plural: Plural form (adds 's' if None)
    
    Returns:
        Pluralized string with count
    
    Example:
        >>> pluralize(1, "apple")
        '1 apple'
        >>> pluralize(5, "apple")
        '5 apples'
    """
    if plural is None:
        plural = singular + 's'
    
    word = singular if count == 1 else plural
    return f"{count} {word}"


def title_case(text: str) -> str:
    """
    Convert text to title case (better than str.title()).
    
    Args:
        text: Text to convert
    
    Returns:
        Title-cased text
    
    Example:
        >>> title_case("the quick brown fox")
        'The Quick Brown Fox'
    """
    # Words that should stay lowercase in titles
    lowercase_words = {'a', 'an', 'and', 'as', 'at', 'but', 'by', 'for', 
                      'in', 'nor', 'of', 'on', 'or', 'so', 'the', 'to', 'up', 'yet'}
    
    words = text.split()
    result = []
    
    for i, word in enumerate(words):
        if i == 0 or word.lower() not in lowercase_words:
            result.append(word.capitalize())
        else:
            result.append(word.lower())
    
    return ' '.join(result)


def camel_case(text: str) -> str:
    """
    Convert text to camelCase.
    
    Args:
        text: Text to convert
    
    Returns:
        camelCase string
    
    Example:
        >>> camel_case("hello world example")
        'helloWorldExample'
    """
    words = re.sub(r'[^a-zA-Z0-9]', ' ', text).split()
    if not words:
        return ''
    
    return words[0].lower() + ''.join(word.capitalize() for word in words[1:])


def snake_case(text: str) -> str:
    """
    Convert text to snake_case.
    
    Args:
        text: Text to convert
    
    Returns:
        snake_case string
    
    Example:
        >>> snake_case("Hello World Example")
        'hello_world_example'
    """
    # Insert underscore before uppercase letters
    text = re.sub(r'(?<!^)(?=[A-Z])', '_', text)
    
    # Replace spaces and special chars with underscore
    text = re.sub(r'[^a-zA-Z0-9]', '_', text)
    
    # Remove multiple underscores
    text = re.sub(r'_+', '_', text)
    
    return text.lower().strip('_')


def kebab_case(text: str) -> str:
    """
    Convert text to kebab-case.
    
    Args:
        text: Text to convert
    
    Returns:
        kebab-case string
    
    Example:
        >>> kebab_case("Hello World Example")
        'hello-world-example'
    """
    return snake_case(text).replace('_', '-')
