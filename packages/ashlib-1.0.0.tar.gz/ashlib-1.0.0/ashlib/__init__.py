"""
AshLib - Asheer's personal utility library

A collection of commonly used functions to avoid code repetition.
"""

__version__ = "0.1.0"
__author__ = "Asheer"

from lib import * #Only non-namespaced functions

# Import modules for namespaced access
from . import security
from . import math_utils
from . import string_utils
from . import collections_utils
from . import datetime_utils
from . import file_utils
from . import validation
from . import web_utils
from . import formatting

__all__ = [
    # Math
    "add", "subtract", "multiply", "divide",
    
    # String
    "reverse_string", "capitalize_words", "count_vowels",
    
    # Collections
    "chunk_list", "flatten_dict", "unflatten_dict", "remove_duplicates",
    "deep_merge", "group_by", "partition", "pick_keys", "omit_keys",
    "transpose_list", "batch_items",
    
    # DateTime
    "format_relative_time", "parse_date", "get_timezone_offset",
    "is_business_day", "add_business_days", "get_quarter",
    "start_of_day", "end_of_day",
    
    # File
    "ensure_dir_exists", "get_file_size_human", "read_json_file",
    "write_json_file", "find_files", "get_file_extension",
    "change_file_extension", "get_relative_path", "file_age_seconds",
    
    # Validation
    "is_valid_json", "is_valid_uuid", "is_valid_email", "is_valid_url",
    "is_valid_ip", "normalize_whitespace", "truncate_string",
    "is_numeric", "is_valid_hex_color", "sanitize_string",
    
    # Web
    "parse_user_agent", "get_client_ip", "slugify", "parse_query_string",
    "build_query_string", "normalize_url", "extract_domain",
    "is_absolute_url", "add_query_params", "remove_query_params",
    
    # Formatting
    "format_currency", "format_phone", "abbreviate_number", "ordinal_number",
    "format_percentage", "format_bytes", "format_duration", "pluralize",
    "title_case", "camel_case", "snake_case", "kebab_case",
    
    # Security
    "constant_time_compare", "generate_secure_token", "generate_secure_password",
    "hash_password", "verify_password", "generate_hmac", "verify_hmac",
    "sanitize_filename", "is_safe_redirect_url",
]
