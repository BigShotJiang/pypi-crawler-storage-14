def aboutme(output="print"):
    content = "ashlib: A Python library by Asheer. altex.page"
    if output == "print":
        print(content)
    else:
        return content
    
class LibTooOldError(Exception):
    """Custom exception for deprecated library usage."""
    pass

class LibTooNewError(Exception):
    """Custom exception for library version incompatibility."""
    pass

def requiere_version(min_version, max_version=None):
    import pkg_resources
    current_version = pkg_resources.get_distribution("ashlib").version
    
    def version_tuple(v):
        # Remove 'e' prefix if present for exact version match
        v_clean = v.lstrip('e')
        return tuple(map(int, (v_clean.split("."))))
    
    # Check if exact version is required (starts with 'e')
    if min_version.startswith('e'):
        required_vt = version_tuple(min_version)
        curr_vt = version_tuple(current_version)
        
        if curr_vt != required_vt:
            raise LibTooOldError(f"ashlib version must be exactly {min_version[1:]}. Current version: {current_version}")
        return
    
    # Normal range checking
    min_vt = version_tuple(min_version)
    curr_vt = version_tuple(current_version)
    
    if curr_vt < min_vt:
        raise LibTooOldError(f"ashlib version {min_version} or higher is required. Current version: {current_version}")
    
    if max_version:
        max_vt = version_tuple(max_version)
        if curr_vt > max_vt:
            raise LibTooNewError(f"ashlib version must be less than or equal to {max_version}. Current version: {current_version}")