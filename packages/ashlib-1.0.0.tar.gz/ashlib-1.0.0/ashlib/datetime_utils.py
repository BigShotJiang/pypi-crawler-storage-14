"""
Date and time utility functions.
"""

from datetime import datetime, timedelta, timezone
from typing import Optional


def format_relative_time(dt: datetime, now: Optional[datetime] = None) -> str:
    """
    Format datetime as relative time (e.g., "2 hours ago", "3 days ago").
    
    Args:
        dt: Datetime to format
        now: Current datetime (defaults to now)
    
    Returns:
        Human-readable relative time string
    
    Example:
        >>> from datetime import datetime, timedelta
        >>> past = datetime.now() - timedelta(hours=2)
        >>> format_relative_time(past)
        '2 hours ago'
    """
    if now is None:
        now = datetime.now(dt.tzinfo) if dt.tzinfo else datetime.now()
    
    diff = now - dt
    seconds = diff.total_seconds()
    
    if seconds < 0:
        # Future time
        seconds = abs(seconds)
        suffix = "from now"
    else:
        suffix = "ago"
    
    intervals = [
        (31536000, "year"),
        (2592000, "month"),
        (604800, "week"),
        (86400, "day"),
        (3600, "hour"),
        (60, "minute"),
        (1, "second"),
    ]
    
    for interval_seconds, name in intervals:
        count = int(seconds // interval_seconds)
        if count > 0:
            plural = "s" if count > 1 else ""
            return f"{count} {name}{plural} {suffix}"
    
    return "just now"


def parse_date(date_string: str, formats: Optional[list[str]] = None) -> Optional[datetime]:
    """
    Parse a date string using multiple format attempts.
    
    Args:
        date_string: Date string to parse
        formats: List of format strings to try (uses common formats if None)
    
    Returns:
        Parsed datetime or None if parsing fails
    
    Example:
        >>> parse_date("2025-12-01")
        datetime.datetime(2025, 12, 1, 0, 0)
    """
    if formats is None:
        formats = [
            "%Y-%m-%d",
            "%Y/%m/%d",
            "%d-%m-%Y",
            "%d/%m/%Y",
            "%m-%d-%Y",
            "%m/%d/%Y",
            "%Y-%m-%d %H:%M:%S",
            "%Y-%m-%dT%H:%M:%S",
            "%Y-%m-%dT%H:%M:%S.%f",
            "%Y-%m-%dT%H:%M:%S%z",
        ]
    
    for fmt in formats:
        try:
            return datetime.strptime(date_string.strip(), fmt)
        except ValueError:
            continue
    
    return None


def get_timezone_offset(tz_name: str) -> Optional[int]:
    """
    Get timezone offset in hours from UTC.
    
    Args:
        tz_name: Timezone name (e.g., 'UTC', 'EST', 'PST')
    
    Returns:
        Offset in hours or None if timezone not recognized
    
    Example:
        >>> get_timezone_offset("UTC")
        0
    """
    tz_offsets = {
        "UTC": 0,
        "GMT": 0,
        "EST": -5,
        "EDT": -4,
        "CST": -6,
        "CDT": -5,
        "MST": -7,
        "MDT": -6,
        "PST": -8,
        "PDT": -7,
    }
    
    return tz_offsets.get(tz_name.upper())


def is_business_day(dt: datetime, holidays: Optional[list[datetime]] = None) -> bool:
    """
    Check if a date is a business day (Monday-Friday, not a holiday).
    
    Args:
        dt: Date to check
        holidays: Optional list of holiday dates
    
    Returns:
        True if business day, False otherwise
    
    Example:
        >>> from datetime import datetime
        >>> is_business_day(datetime(2025, 12, 1))  # Monday
        True
    """
    # Check if weekend (Saturday=5, Sunday=6)
    if dt.weekday() >= 5:
        return False
    
    # Check if holiday
    if holidays:
        dt_date = dt.date()
        for holiday in holidays:
            if holiday.date() == dt_date:
                return False
    
    return True


def add_business_days(dt: datetime, days: int, holidays: Optional[list[datetime]] = None) -> datetime:
    """
    Add business days to a date, skipping weekends and holidays.
    
    Args:
        dt: Starting date
        days: Number of business days to add
        holidays: Optional list of holiday dates
    
    Returns:
        New datetime after adding business days
    
    Example:
        >>> from datetime import datetime
        >>> start = datetime(2025, 12, 1)  # Monday
        >>> add_business_days(start, 5)  # Add 5 business days
        datetime.datetime(2025, 12, 8, 0, 0)
    """
    current = dt
    days_added = 0
    direction = 1 if days > 0 else -1
    days = abs(days)
    
    while days_added < days:
        current += timedelta(days=direction)
        if is_business_day(current, holidays):
            days_added += 1
    
    return current


def get_quarter(dt: datetime) -> int:
    """
    Get the quarter (1-4) for a given date.
    
    Args:
        dt: Date to get quarter for
    
    Returns:
        Quarter number (1-4)
    
    Example:
        >>> from datetime import datetime
        >>> get_quarter(datetime(2025, 12, 1))
        4
    """
    return (dt.month - 1) // 3 + 1


def start_of_day(dt: datetime) -> datetime:
    """
    Get the start of day (00:00:00) for a datetime.
    
    Args:
        dt: Datetime to process
    
    Returns:
        Datetime at start of day
    
    Example:
        >>> from datetime import datetime
        >>> start_of_day(datetime(2025, 12, 1, 15, 30, 45))
        datetime.datetime(2025, 12, 1, 0, 0)
    """
    return dt.replace(hour=0, minute=0, second=0, microsecond=0)


def end_of_day(dt: datetime) -> datetime:
    """
    Get the end of day (23:59:59.999999) for a datetime.
    
    Args:
        dt: Datetime to process
    
    Returns:
        Datetime at end of day
    
    Example:
        >>> from datetime import datetime
        >>> end_of_day(datetime(2025, 12, 1, 15, 30))
        datetime.datetime(2025, 12, 1, 23, 59, 59, 999999)
    """
    return dt.replace(hour=23, minute=59, second=59, microsecond=999999)
