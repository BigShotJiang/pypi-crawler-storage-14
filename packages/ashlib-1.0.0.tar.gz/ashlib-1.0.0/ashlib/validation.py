"""
Data validation utility functions.
"""

import re
import json
from uuid import UUID
from typing import Any


def is_valid_json(text: str) -> bool:
    """
    Check if a string is valid JSON.
    
    Args:
        text: String to validate
    
    Returns:
        True if valid JSON, False otherwise
    
    Example:
        >>> is_valid_json('{"key": "value"}')
        True
        >>> is_valid_json('not json')
        False
    """
    try:
        json.loads(text)
        return True
    except (json.JSONDecodeError, TypeError):
        return False


def is_valid_uuid(text: str, version: int = 4) -> bool:
    """
    Check if a string is a valid UUID.
    
    Args:
        text: String to validate
        version: UUID version to validate (default 4)
    
    Returns:
        True if valid UUID, False otherwise
    
    Example:
        >>> is_valid_uuid("550e8400-e29b-41d4-a716-446655440000")
        True
    """
    try:
        uuid_obj = UUID(text)
        return uuid_obj.version == version if version else True
    except (ValueError, AttributeError):
        return False


def is_valid_email(email: str) -> bool:
    """
    Validate email address format.
    
    Args:
        email: Email address to validate
    
    Returns:
        True if valid email format, False otherwise
    
    Example:
        >>> is_valid_email("user@example.com")
        True
        >>> is_valid_email("invalid.email")
        False
    """
    pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
    return bool(re.match(pattern, email))


def is_valid_url(url: str) -> bool:
    """
    Validate URL format.
    
    Args:
        url: URL to validate
    
    Returns:
        True if valid URL format, False otherwise
    
    Example:
        >>> is_valid_url("https://example.com")
        True
    """
    pattern = r'^https?://[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}(/.*)?$'
    return bool(re.match(pattern, url))


def is_valid_ip(ip: str, version: int = 4) -> bool:
    """
    Validate IP address.
    
    Args:
        ip: IP address to validate
        version: IP version (4 or 6)
    
    Returns:
        True if valid IP address, False otherwise
    
    Example:
        >>> is_valid_ip("192.168.1.1")
        True
    """
    if version == 4:
        pattern = r'^(\d{1,3}\.){3}\d{1,3}$'
        if not re.match(pattern, ip):
            return False
        return all(0 <= int(octet) <= 255 for octet in ip.split('.'))
    elif version == 6:
        pattern = r'^([0-9a-fA-F]{0,4}:){7}[0-9a-fA-F]{0,4}$'
        return bool(re.match(pattern, ip))
    return False


def normalize_whitespace(text: str) -> str:
    """
    Normalize whitespace in a string (collapse multiple spaces, strip).
    
    Args:
        text: String to normalize
    
    Returns:
        Normalized string
    
    Example:
        >>> normalize_whitespace("  hello    world  ")
        'hello world'
    """
    return ' '.join(text.split())


def truncate_string(text: str, max_length: int, suffix: str = "...") -> str:
    """
    Truncate string to maximum length with ellipsis.
    
    Args:
        text: String to truncate
        max_length: Maximum length including suffix
        suffix: Suffix to add when truncated (default "...")
    
    Returns:
        Truncated string
    
    Example:
        >>> truncate_string("This is a long string", 10)
        'This is...'
    """
    if len(text) <= max_length:
        return text
    
    return text[:max_length - len(suffix)] + suffix


def is_numeric(text: str) -> bool:
    """
    Check if string represents a number (int or float).
    
    Args:
        text: String to check
    
    Returns:
        True if numeric, False otherwise
    
    Example:
        >>> is_numeric("123.45")
        True
        >>> is_numeric("abc")
        False
    """
    try:
        float(text)
        return True
    except (ValueError, TypeError):
        return False


def is_valid_hex_color(color: str) -> bool:
    """
    Validate hex color code.
    
    Args:
        color: Color code to validate
    
    Returns:
        True if valid hex color, False otherwise
    
    Example:
        >>> is_valid_hex_color("#FF5733")
        True
        >>> is_valid_hex_color("#FFF")
        True
    """
    pattern = r'^#?([0-9A-Fa-f]{3}|[0-9A-Fa-f]{6})$'
    return bool(re.match(pattern, color))


def sanitize_string(text: str, allowed_chars: str = None) -> str:
    """
    Remove characters not in allowed set.
    
    Args:
        text: String to sanitize
        allowed_chars: Allowed characters (alphanumeric + space if None)
    
    Returns:
        Sanitized string
    
    Example:
        >>> sanitize_string("Hello@World!", "a-zA-Z ")
        'Hello World'
    """
    if allowed_chars is None:
        import string
        allowed_chars = string.ascii_letters + string.digits + ' '
    
    return ''.join(c for c in text if c in allowed_chars)
