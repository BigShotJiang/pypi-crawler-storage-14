"""
Network and web utility functions.
"""

import re
from urllib.parse import urlparse, parse_qs, urlencode, urlunparse
from typing import Optional


def parse_user_agent(user_agent: str) -> dict:
    """
    Parse user agent string to extract browser and OS info.
    
    Args:
        user_agent: User agent string
    
    Returns:
        Dictionary with browser and OS information
    
    Example:
        >>> parse_user_agent("Mozilla/5.0 (Windows NT 10.0) Chrome/91.0")
        {'browser': 'Chrome', 'version': '91.0', 'os': 'Windows'}
    """
    result = {
        'browser': 'Unknown',
        'version': 'Unknown',
        'os': 'Unknown'
    }
    
    # Browser detection
    browsers = [
        ('Chrome', r'Chrome/([\d.]+)'),
        ('Firefox', r'Firefox/([\d.]+)'),
        ('Safari', r'Version/([\d.]+).*Safari'),
        ('Edge', r'Edg/([\d.]+)'),
        ('Opera', r'OPR/([\d.]+)'),
    ]
    
    for browser, pattern in browsers:
        match = re.search(pattern, user_agent)
        if match:
            result['browser'] = browser
            result['version'] = match.group(1)
            break
    
    # OS detection
    if 'Windows' in user_agent:
        result['os'] = 'Windows'
    elif 'Mac OS' in user_agent or 'Macintosh' in user_agent:
        result['os'] = 'macOS'
    elif 'Linux' in user_agent:
        result['os'] = 'Linux'
    elif 'Android' in user_agent:
        result['os'] = 'Android'
    elif 'iOS' in user_agent or 'iPhone' in user_agent or 'iPad' in user_agent:
        result['os'] = 'iOS'
    
    return result


def get_client_ip(headers: dict, trusted_proxies: Optional[list[str]] = None) -> Optional[str]:
    """
    Extract client IP from request headers, handling proxies.
    
    Args:
        headers: Request headers dictionary
        trusted_proxies: List of trusted proxy IPs
    
    Returns:
        Client IP address or None
    
    Example:
        >>> headers = {"X-Forwarded-For": "203.0.113.1"}
        >>> get_client_ip(headers)
        '203.0.113.1'
    """
    # Check various headers used by proxies
    for header in ['X-Forwarded-For', 'X-Real-IP', 'CF-Connecting-IP']:
        if header in headers:
            ip = headers[header].split(',')[0].strip()
            return ip
    
    # Fallback to direct connection IP
    return headers.get('Remote-Addr')


def slugify(text: str, separator: str = '-') -> str:
    """
    Convert text to URL-friendly slug.
    
    Args:
        text: Text to slugify
        separator: Separator character (default '-')
    
    Returns:
        URL-friendly slug
    
    Example:
        >>> slugify("Hello World! This is a Test")
        'hello-world-this-is-a-test'
    """
    # Convert to lowercase
    text = text.lower()
    
    # Remove special characters
    text = re.sub(r'[^\w\s-]', '', text)
    
    # Replace whitespace and multiple separators
    text = re.sub(r'[\s_-]+', separator, text)
    
    # Remove leading/trailing separators
    return text.strip(separator)


def parse_query_string(query: str) -> dict:
    """
    Parse URL query string into dictionary.
    
    Args:
        query: Query string to parse
    
    Returns:
        Dictionary of query parameters
    
    Example:
        >>> parse_query_string("page=1&sort=name&filter=active")
        {'page': ['1'], 'sort': ['name'], 'filter': ['active']}
    """
    return parse_qs(query)


def build_query_string(params: dict) -> str:
    """
    Build URL query string from dictionary.
    
    Args:
        params: Dictionary of parameters
    
    Returns:
        URL-encoded query string
    
    Example:
        >>> build_query_string({"page": 1, "name": "John Doe"})
        'page=1&name=John+Doe'
    """
    return urlencode(params)


def normalize_url(url: str) -> str:
    """
    Normalize URL (lowercase scheme/domain, remove default ports, etc.).
    
    Args:
        url: URL to normalize
    
    Returns:
        Normalized URL
    
    Example:
        >>> normalize_url("HTTP://Example.com:80/Path")
        'http://example.com/Path'
    """
    parsed = urlparse(url)
    
    # Lowercase scheme and netloc
    scheme = parsed.scheme.lower()
    netloc = parsed.netloc.lower()
    
    # Remove default ports
    if (scheme == 'http' and netloc.endswith(':80')) or \
       (scheme == 'https' and netloc.endswith(':443')):
        netloc = netloc.rsplit(':', 1)[0]
    
    return urlunparse((
        scheme,
        netloc,
        parsed.path,
        parsed.params,
        parsed.query,
        parsed.fragment
    ))


def extract_domain(url: str) -> str:
    """
    Extract domain from URL.
    
    Args:
        url: URL to extract domain from
    
    Returns:
        Domain name
    
    Example:
        >>> extract_domain("https://www.example.com/path?query=1")
        'www.example.com'
    """
    parsed = urlparse(url)
    return parsed.netloc


def is_absolute_url(url: str) -> bool:
    """
    Check if URL is absolute (has scheme).
    
    Args:
        url: URL to check
    
    Returns:
        True if absolute URL, False otherwise
    
    Example:
        >>> is_absolute_url("https://example.com")
        True
        >>> is_absolute_url("/path/to/page")
        False
    """
    return bool(urlparse(url).scheme)


def add_query_params(url: str, params: dict) -> str:
    """
    Add query parameters to URL.
    
    Args:
        url: Base URL
        params: Parameters to add
    
    Returns:
        URL with added parameters
    
    Example:
        >>> add_query_params("https://example.com", {"page": 2})
        'https://example.com?page=2'
    """
    parsed = urlparse(url)
    query_dict = parse_qs(parsed.query)
    query_dict.update(params)
    
    new_query = urlencode(query_dict, doseq=True)
    
    return urlunparse((
        parsed.scheme,
        parsed.netloc,
        parsed.path,
        parsed.params,
        new_query,
        parsed.fragment
    ))


def remove_query_params(url: str, params: list[str]) -> str:
    """
    Remove specific query parameters from URL.
    
    Args:
        url: URL with query parameters
        params: List of parameter names to remove
    
    Returns:
        URL without specified parameters
    
    Example:
        >>> remove_query_params("https://example.com?a=1&b=2", ["b"])
        'https://example.com?a=1'
    """
    parsed = urlparse(url)
    query_dict = parse_qs(parsed.query)
    
    for param in params:
        query_dict.pop(param, None)
    
    new_query = urlencode(query_dict, doseq=True)
    
    return urlunparse((
        parsed.scheme,
        parsed.netloc,
        parsed.path,
        parsed.params,
        new_query,
        parsed.fragment
    ))
