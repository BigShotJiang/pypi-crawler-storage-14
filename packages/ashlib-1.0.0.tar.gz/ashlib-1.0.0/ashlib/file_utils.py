"""
File and path utility functions.
"""

import os
import json
from pathlib import Path
from typing import Any, Optional


def ensure_dir_exists(path: str) -> None:
    """
    Create directory and all parent directories if they don't exist.
    
    Args:
        path: Directory path to create
    
    Example:
        >>> ensure_dir_exists("path/to/directory")
    """
    Path(path).mkdir(parents=True, exist_ok=True)


def get_file_size_human(path: str) -> str:
    """
    Get file size in human-readable format (B, KB, MB, GB, TB).
    
    Args:
        path: Path to file
    
    Returns:
        Formatted file size string
    
    Example:
        >>> get_file_size_human("large_file.zip")
        '15.3 MB'
    """
    size = os.path.getsize(path)
    
    for unit in ['B', 'KB', 'MB', 'GB', 'TB']:
        if size < 1024.0:
            return f"{size:.1f} {unit}"
        size /= 1024.0
    
    return f"{size:.1f} PB"


def read_json_file(path: str, default: Any = None) -> Any:
    """
    Read and parse JSON file with error handling.
    
    Args:
        path: Path to JSON file
        default: Default value if file doesn't exist or is invalid
    
    Returns:
        Parsed JSON data or default value
    
    Example:
        >>> data = read_json_file("config.json", {})
    """
    try:
        with open(path, 'r', encoding='utf-8') as f:
            return json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        return default


def write_json_file(path: str, data: Any, indent: int = 2) -> bool:
    """
    Write data to JSON file with formatting.
    
    Args:
        path: Path to JSON file
        data: Data to write
        indent: Indentation spaces (default 2)
    
    Returns:
        True if successful, False otherwise
    
    Example:
        >>> write_json_file("data.json", {"key": "value"})
        True
    """
    try:
        ensure_dir_exists(os.path.dirname(path) or '.')
        with open(path, 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=indent, ensure_ascii=False)
        return True
    except Exception:
        return False


def find_files(directory: str, pattern: str = "*", recursive: bool = True) -> list[str]:
    """
    Find files matching a pattern in a directory.
    
    Args:
        directory: Directory to search
        pattern: Glob pattern to match (default "*")
        recursive: Search recursively if True
    
    Returns:
        List of matching file paths
    
    Example:
        >>> find_files("src", "*.py")
        ['src/main.py', 'src/utils.py']
    """
    path = Path(directory)
    
    if recursive:
        return [str(p) for p in path.rglob(pattern) if p.is_file()]
    else:
        return [str(p) for p in path.glob(pattern) if p.is_file()]


def get_file_extension(path: str, include_dot: bool = False) -> str:
    """
    Get file extension from path.
    
    Args:
        path: File path
        include_dot: Include the dot in extension
    
    Returns:
        File extension
    
    Example:
        >>> get_file_extension("document.pdf")
        'pdf'
    """
    ext = Path(path).suffix
    return ext if include_dot else ext.lstrip('.')


def change_file_extension(path: str, new_extension: str) -> str:
    """
    Change file extension in a path.
    
    Args:
        path: Original file path
        new_extension: New extension (with or without dot)
    
    Returns:
        Path with new extension
    
    Example:
        >>> change_file_extension("file.txt", ".md")
        'file.md'
    """
    p = Path(path)
    if not new_extension.startswith('.'):
        new_extension = '.' + new_extension
    return str(p.with_suffix(new_extension))


def get_relative_path(path: str, base: str) -> str:
    """
    Get relative path from base directory.
    
    Args:
        path: Target path
        base: Base directory
    
    Returns:
        Relative path
    
    Example:
        >>> get_relative_path("/home/user/docs/file.txt", "/home/user")
        'docs/file.txt'
    """
    return str(Path(path).relative_to(base))


def file_age_seconds(path: str) -> float:
    """
    Get file age in seconds since last modification.
    
    Args:
        path: File path
    
    Returns:
        Age in seconds
    
    Example:
        >>> age = file_age_seconds("log.txt")
    """
    import time
    mtime = os.path.getmtime(path)
    return time.time() - mtime
