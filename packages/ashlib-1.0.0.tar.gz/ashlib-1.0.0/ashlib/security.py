"""
Security utility functions for common security operations.
"""

import secrets
import hashlib
import hmac
from typing import Optional


def constant_time_compare(val1: str, val2: str) -> bool:
    """
    Compare two strings in constant time to prevent timing attacks.
    
    Args:
        val1: First string to compare
        val2: Second string to compare
    
    Returns:
        True if strings are equal, False otherwise
    
    Example:
        >>> constant_time_compare("secret123", "secret123")
        True
    """
    # Use a constant-time length check by always iterating through max length
    max_len = max(len(val1), len(val2))
    val1_bytes = val1.encode().ljust(max_len, b'\x00')
    val2_bytes = val2.encode().ljust(max_len, b'\x00')
    
    result = 0
    for x, y in zip(val1_bytes, val2_bytes):
        result |= x ^ y
    
    return result == 0 and len(val1) == len(val2)


def generate_secure_token(length: int = 32) -> str:
    """
    Generate a cryptographically secure random token.
    
    Args:
        length: Length of the token in bytes (default 32)
    
    Returns:
        Hex-encoded secure random token
    
    Example:
        >>> token = generate_secure_token(16)
        >>> len(token)
        32
    """
    return secrets.token_hex(length)


def generate_secure_password(length: int = 16) -> str:
    """
    Generate a secure random password with letters, digits, and punctuation.
    
    Args:
        length: Length of the password (default 16)
    
    Returns:
        Secure random password string
    
    Example:
        >>> pwd = generate_secure_password(20)
        >>> len(pwd)
        20
    """
    import string
    alphabet = string.ascii_letters + string.digits + string.punctuation
    return ''.join(secrets.choice(alphabet) for _ in range(length))


def hash_password(password: str, salt: Optional[str] = None) -> tuple[str, str]:
    """
    Hash a password using SHA-256 with a salt.
    
    Args:
        password: Password to hash
        salt: Optional salt (generates one if not provided)
    
    Returns:
        Tuple of (hashed_password, salt)
    
    Example:
        >>> hashed, salt = hash_password("mypassword")
        >>> len(hashed)
        64
    """
    if salt is None:
        salt = secrets.token_hex(16)
    
    pwd_hash = hashlib.sha256((password + salt).encode()).hexdigest()
    return pwd_hash, salt


def verify_password(password: str, hashed: str, salt: str) -> bool:
    """
    Verify a password against a hash and salt.
    
    Args:
        password: Password to verify
        hashed: Previously hashed password
        salt: Salt used in original hash
    
    Returns:
        True if password matches, False otherwise
    
    Example:
        >>> hashed, salt = hash_password("test123")
        >>> verify_password("test123", hashed, salt)
        True
    """
    pwd_hash, _ = hash_password(password, salt)
    return constant_time_compare(pwd_hash, hashed)


def generate_hmac(message: str, key: str, algorithm: str = 'sha256') -> str:
    """
    Generate HMAC for a message using a secret key.
    
    Args:
        message: Message to authenticate
        key: Secret key
        algorithm: Hash algorithm to use (default 'sha256')
    
    Returns:
        HMAC hex digest
    
    Example:
        >>> mac = generate_hmac("data", "secret_key")
        >>> len(mac)
        64
    """
    h = hmac.new(key.encode(), message.encode(), getattr(hashlib, algorithm))
    return h.hexdigest()


def verify_hmac(message: str, key: str, signature: str, algorithm: str = 'sha256') -> bool:
    """
    Verify HMAC signature for a message.
    
    Args:
        message: Message to verify
        key: Secret key
        signature: HMAC signature to verify against
        algorithm: Hash algorithm used (default 'sha256')
    
    Returns:
        True if signature is valid, False otherwise
    
    Example:
        >>> mac = generate_hmac("data", "key")
        >>> verify_hmac("data", "key", mac)
        True
    """
    expected = generate_hmac(message, key, algorithm)
    return constant_time_compare(expected, signature)


def sanitize_filename(filename: str) -> str:
    """
    Sanitize a filename to prevent path traversal attacks.
    
    Args:
        filename: Filename to sanitize
    
    Returns:
        Sanitized filename safe for use
    
    Example:
        >>> sanitize_filename("../../etc/passwd")
        'etcpasswd'
    """
    import string
    valid_chars = f"-_.() {string.ascii_letters}{string.digits}"
    return ''.join(c for c in filename if c in valid_chars).strip()


def is_safe_redirect_url(url: str, allowed_hosts: list[str]) -> bool:
    """
    Check if a redirect URL is safe (prevents open redirect vulnerabilities).
    
    Args:
        url: URL to check
        allowed_hosts: List of allowed hostnames
    
    Returns:
        True if URL is safe to redirect to, False otherwise
    
    Example:
        >>> is_safe_redirect_url("/home", ["example.com"])
        True
        >>> is_safe_redirect_url("https://evil.com", ["example.com"])
        False
    """
    from urllib.parse import urlparse
    
    # Relative URLs are safe
    if url.startswith('/') and not url.startswith('//'):
        return True
    
    parsed = urlparse(url)
    
    # No scheme or host means relative URL
    if not parsed.scheme and not parsed.netloc:
        return True
    
    # Check if host is in allowed list
    return parsed.netloc in allowed_hosts

