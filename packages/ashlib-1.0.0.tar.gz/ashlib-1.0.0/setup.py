from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="ashlib",
    version="1.0.0",
    author="Asheer",
    description="Asheer's personal Python library - reusable utility functions to avoid repetitive code",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/ItsAsheer/ashlib",
    packages=find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: Other/Proprietary License",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.7",
    install_requires=[],
)
