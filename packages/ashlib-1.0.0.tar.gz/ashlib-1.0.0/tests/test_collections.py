"""
Tests for collections utilities
"""

from ashlib.collections_utils import (
    chunk_list, flatten_dict, unflatten_dict, remove_duplicates,
    deep_merge, group_by, partition, pick_keys, omit_keys
)


def test_chunk_list():
    assert chunk_list([1, 2, 3, 4, 5], 2) == [[1, 2], [3, 4], [5]]
    assert chunk_list([1, 2, 3], 3) == [[1, 2, 3]]
    assert chunk_list([], 2) == []


def test_flatten_dict():
    nested = {"a": {"b": 1, "c": 2}, "d": 3}
    assert flatten_dict(nested) == {"a.b": 1, "a.c": 2, "d": 3}


def test_unflatten_dict():
    flat = {"a.b": 1, "a.c": 2, "d": 3}
    result = unflatten_dict(flat)
    assert result == {"a": {"b": 1, "c": 2}, "d": 3}


def test_remove_duplicates():
    assert remove_duplicates([1, 2, 2, 3, 1]) == [1, 2, 3]
    assert remove_duplicates([]) == []
    assert remove_duplicates([1, 1, 1]) == [1]


def test_deep_merge():
    dict1 = {"a": 1, "b": {"c": 2}}
    dict2 = {"b": {"d": 3}, "e": 4}
    result = deep_merge(dict1, dict2)
    assert result == {"a": 1, "b": {"c": 2, "d": 3}, "e": 4}


def test_group_by():
    items = [1, 2, 3, 4, 5, 6]
    result = group_by(items, lambda x: x % 2)
    assert result[0] == [2, 4, 6]
    assert result[1] == [1, 3, 5]


def test_partition():
    items = [1, 2, 3, 4, 5]
    evens, odds = partition(items, lambda x: x % 2 == 0)
    assert evens == [2, 4]
    assert odds == [1, 3, 5]


def test_pick_keys():
    d = {"a": 1, "b": 2, "c": 3}
    assert pick_keys(d, ["a", "c"]) == {"a": 1, "c": 3}


def test_omit_keys():
    d = {"a": 1, "b": 2, "c": 3}
    assert omit_keys(d, ["b"]) == {"a": 1, "c": 3}
