"""
Tests for web utilities
"""

from ashlib.web_utils import (
    slugify, parse_query_string, build_query_string,
    extract_domain, is_absolute_url
)


def test_slugify():
    assert slugify("Hello World!") == "hello-world"
    assert slugify("Test 123") == "test-123"
    assert slugify("Multiple   Spaces") == "multiple-spaces"


def test_parse_query_string():
    result = parse_query_string("page=1&sort=name")
    assert "page" in result
    assert "sort" in result


def test_build_query_string():
    result = build_query_string({"page": 1, "sort": "name"})
    assert "page=1" in result
    assert "sort=name" in result


def test_extract_domain():
    assert extract_domain("https://www.example.com/path") == "www.example.com"
    assert extract_domain("http://test.org") == "test.org"


def test_is_absolute_url():
    assert is_absolute_url("https://example.com") == True
    assert is_absolute_url("http://test.org") == True
    assert is_absolute_url("/path/to/page") == False
    assert is_absolute_url("relative/path") == False
