"""
Tests for string_utils module
"""

