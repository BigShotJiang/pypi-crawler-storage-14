"""
Tests for lib.py utilities
"""

import pytest
from ashlib.lib import aboutme, LibTooOldError, LibTooNewError, requiere_version
from ashlib import __version__


def test_aboutme_print(capsys):
    """Test aboutme function with print output."""
    aboutme()
    captured = capsys.readouterr()
    assert "ashlib" in captured.out
    assert "Asheer" in captured.out
    assert "altex.page" in captured.out


def test_aboutme_return():
    """Test aboutme function with return output."""
    result = aboutme(output="return")
    assert isinstance(result, str)
    assert "ashlib" in result
    assert "Asheer" in result
    assert "altex.page" in result


def test_lib_too_old_error():
    """Test LibTooOldError exception."""
    with pytest.raises(LibTooOldError):
        raise LibTooOldError("Test error message")


def test_lib_too_new_error():
    """Test LibTooNewError exception."""
    with pytest.raises(LibTooNewError):
        raise LibTooNewError("Test error message")


def test_requiere_version_current():
    """Test version requirement with current version."""
    # This should not raise an error with the current version
    try:
        requiere_version("0.0.1")
    except Exception as e:
        pytest.fail(f"requiere_version raised an unexpected exception: {e}")


def test_requiere_version_too_old():
    """Test version requirement when library is too old."""
    with pytest.raises(LibTooOldError) as exc_info:
        requiere_version("10.0.0")
    
    assert "10.0.0 or higher is required" in str(exc_info.value)
    assert __version__ in str(exc_info.value)


def test_requiere_version_too_new():
    """Test version requirement when library is too new."""
    with pytest.raises(LibTooNewError) as exc_info:
        requiere_version("0.0.1", max_version="0.0.5")
    
    assert "must be less than or equal to 0.0.5" in str(exc_info.value)
    assert __version__ in str(exc_info.value)


def test_requiere_version_in_range():
    """Test version requirement within valid range."""
    try:
        requiere_version("0.0.1", max_version="1.0.0")
    except Exception as e:
        pytest.fail(f"requiere_version raised an unexpected exception: {e}")


def test_version_tuple_parsing():
    """Test that version parsing works correctly."""
    # Current version should be greater than 0.0.1
    try:
        requiere_version("0.0.1")
        requiere_version(__version__)
    except Exception as e:
        pytest.fail(f"Version comparison failed: {e}")
    
    # Should fail when max version is below current
    with pytest.raises(LibTooNewError):
        requiere_version("0.0.1", max_version="0.0.1")


def test_requiere_exact_version():
    """Test exact version requirement with 'e' prefix."""
    # Should pass when version matches exactly
    try:
        requiere_version(f"e{__version__}")
    except Exception as e:
        pytest.fail(f"Exact version match should not raise exception: {e}")
    
    # Should fail when version doesn't match exactly
    with pytest.raises(LibTooOldError) as exc_info:
        requiere_version("e9.9.9")
    
    assert "must be exactly 9.9.9" in str(exc_info.value)
    assert __version__ in str(exc_info.value)
