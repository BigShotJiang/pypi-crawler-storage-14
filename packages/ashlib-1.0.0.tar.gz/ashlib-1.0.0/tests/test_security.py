"""
Tests for security utilities
"""

import pytest
from ashlib.security import (
    constant_time_compare, generate_secure_token, generate_secure_password,
    hash_password, verify_password, sanitize_filename
)


def test_constant_time_compare():
    assert constant_time_compare("hello", "hello") == True
    assert constant_time_compare("hello", "world") == False
    assert constant_time_compare("", "") == True


def test_generate_secure_token():
    token1 = generate_secure_token(16)
    token2 = generate_secure_token(16)
    
    assert len(token1) == 32  # 16 bytes = 32 hex chars
    assert token1 != token2  # Should be different


def test_generate_secure_password():
    pwd = generate_secure_password(20)
    assert len(pwd) == 20
    assert pwd.strip() != ""


def test_hash_and_verify_password():
    password = "test123"
    hashed, salt = hash_password(password)
    
    assert len(hashed) == 64  # SHA-256 hex
    assert verify_password(password, hashed, salt) == True
    assert verify_password("wrong", hashed, salt) == False


def test_sanitize_filename():
    assert sanitize_filename("test.txt") == "test.txt"
    assert "passwd" in sanitize_filename("../../etc/passwd")
    assert "/" not in sanitize_filename("path/to/file")
