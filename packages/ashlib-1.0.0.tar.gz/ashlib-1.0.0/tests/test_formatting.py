"""
Tests for formatting utilities
"""

from ashlib.formatting import (
    format_currency, abbreviate_number, ordinal_number,
    format_percentage, format_bytes, format_duration,
    pluralize, camel_case, snake_case, kebab_case
)


def test_format_currency():
    assert format_currency(1234.56) == "$1,234.56"
    assert format_currency(1000) == "$1,000.00"


def test_abbreviate_number():
    assert abbreviate_number(500) == "500"
    assert abbreviate_number(1500) == "1.5K"
    assert abbreviate_number(2500000) == "2.5M"
    assert abbreviate_number(1000000000) == "1.0B"


def test_ordinal_number():
    assert ordinal_number(1) == "1st"
    assert ordinal_number(2) == "2nd"
    assert ordinal_number(3) == "3rd"
    assert ordinal_number(4) == "4th"
    assert ordinal_number(11) == "11th"
    assert ordinal_number(21) == "21st"


def test_format_percentage():
    assert format_percentage(0.75, 1) == "75.0%"
    assert format_percentage(0.8532, 2) == "85.32%"


def test_format_bytes():
    assert format_bytes(1024) == "1.00 KB"
    assert format_bytes(1536) == "1.50 KB"
    assert format_bytes(1048576) == "1.00 MB"


def test_format_duration():
    assert format_duration(65) == "1m 5s"
    assert format_duration(3665) == "1h 1m 5s"
    assert format_duration(30) == "30s"


def test_pluralize():
    assert pluralize(1, "apple") == "1 apple"
    assert pluralize(5, "apple") == "5 apples"
    assert pluralize(2, "person", "people") == "2 people"


def test_camel_case():
    assert camel_case("hello world") == "helloWorld"
    assert camel_case("test example case") == "testExampleCase"


def test_snake_case():
    assert snake_case("Hello World") == "hello_world"
    assert snake_case("TestExample") == "test_example"


def test_kebab_case():
    assert kebab_case("Hello World") == "hello-world"
    assert kebab_case("TestExample") == "test-example"
