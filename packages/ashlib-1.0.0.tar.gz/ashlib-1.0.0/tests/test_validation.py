"""
Tests for validation utilities
"""

from ashlib.validation import (
    is_valid_json, is_valid_uuid, is_valid_email, is_valid_url,
    is_valid_ip, normalize_whitespace, truncate_string,
    is_numeric, is_valid_hex_color, sanitize_string
)


def test_is_valid_json():
    assert is_valid_json('{"key": "value"}') == True
    assert is_valid_json('{"key": 123}') == True
    assert is_valid_json('invalid json') == False
    assert is_valid_json('') == False


def test_is_valid_uuid():
    assert is_valid_uuid("550e8400-e29b-41d4-a716-446655440000") == True
    assert is_valid_uuid("not-a-uuid") == False
    assert is_valid_uuid("") == False


def test_is_valid_email():
    assert is_valid_email("user@example.com") == True
    assert is_valid_email("test.email+tag@domain.co.uk") == True
    assert is_valid_email("invalid.email") == False
    assert is_valid_email("@example.com") == False


def test_is_valid_url():
    assert is_valid_url("https://example.com") == True
    assert is_valid_url("http://test.org/path") == True
    assert is_valid_url("not a url") == False
    assert is_valid_url("ftp://example.com") == False


def test_is_valid_ip():
    assert is_valid_ip("192.168.1.1") == True
    assert is_valid_ip("0.0.0.0") == True
    assert is_valid_ip("256.1.1.1") == False
    assert is_valid_ip("not an ip") == False


def test_normalize_whitespace():
    assert normalize_whitespace("  hello    world  ") == "hello world"
    assert normalize_whitespace("test") == "test"
    assert normalize_whitespace("") == ""


def test_truncate_string():
    assert truncate_string("This is a long string", 10) == "This is..."
    assert truncate_string("Short", 10) == "Short"
    assert truncate_string("Exactly ten", 11) == "Exactly ten"


def test_is_numeric():
    assert is_numeric("123") == True
    assert is_numeric("123.45") == True
    assert is_numeric("-10") == True
    assert is_numeric("abc") == False


def test_is_valid_hex_color():
    assert is_valid_hex_color("#FF5733") == True
    assert is_valid_hex_color("#FFF") == True
    assert is_valid_hex_color("FF5733") == True
    assert is_valid_hex_color("#GG5733") == False


def test_sanitize_string():
    assert sanitize_string("Hello World") == "Hello World"
    assert "Hello World" in sanitize_string("Hello@World!")
