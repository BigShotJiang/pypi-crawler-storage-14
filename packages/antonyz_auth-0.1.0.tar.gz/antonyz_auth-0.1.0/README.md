# Antonyz Auth Client

A Python client library for the Antonyz Auth System.

## Installation

```bash
pip install Antonyz_Auth
```

## Usage

Here is a simple example of how to use the library in your application.

```python
import asyncio
from Antonyz_Auth import AntonyzAuth

async def main():
    # 1. Initialize
    # Replace with your actual server URL (ws:// or wss://)
    auth = AntonyzAuth("ws://localhost:8000")

    # 2. Connect
    key = "Antonyz-Lisence-Authed-XXXX-XXXX"
    success = await auth.connect(key)

    if success:
        # 3. Get User Info
        info = auth.get_user_info()
        print(f"Welcome {info.get('username')}!")
        print(f"Your Role: {info.get('role')}")

        # 4. Keep Alive
        # You must keep the event loop running for the heartbeat to work
        while True:
            await asyncio.sleep(1)
    else:
        print("Login Failed!")

if __name__ == "__main__":
    asyncio.run(main())
```

## Features

- **Automatic HWID Locking**: The library automatically grabs the device's UUID and sends it for validation.
- **Heartbeat System**: Automatically pings the server every 30 seconds to keep the connection alive.
- **Role Management**: Easy access to user roles for feature gating.
