from setuptools import setup, find_packages

setup(
    name="Antonyz_Auth",
    version="0.1.0",
    packages=find_packages(),
    install_requires=[
        "websockets",
        "requests",
        "platformdirs"
    ],
    author="Antonyz",
    description="Authentication client for Antonyz Auth System",
)
