import websockets
import asyncio
import json
import platform
import subprocess
import os

class UserInfo(dict):
    """Dictionary that supports dot notation access"""
    def __getattr__(self, attr):
        return self.get(attr)
    
    def __setattr__(self, key, value):
        self[key] = value

class AntonyzAuth:
    def __init__(self, server_url: str):
        self.server_url = server_url
        self.ws = None
        self.user_info = None
        self.is_connected = False
        self.last_error = None

    def get_hwid(self):
        # Simple HWID generation based on system info
        system = platform.system()
        if system == "Windows":
            try:
                return subprocess.check_output('wmic csproduct get uuid').decode().split('\n')[1].strip()
            except:
                return "UNKNOWN_HWID"
        else:
            # Fallback for other OS
            return "UNKNOWN_HWID_NON_WINDOWS"

    async def connect(self, key: str):
        self.last_error = None
        hwid = self.get_hwid()
        uri = f"{self.server_url}/ws/{key}?hwid={hwid}"
        try:
            self.ws = await websockets.connect(uri)
            response = await self.ws.recv()
            data = json.loads(response)
            
            if data.get("status") == "success":
                self.is_connected = True
                self.user_info = UserInfo({
                    "role": data.get("role"),
                    "username": data.get("username"),
                    "expiry": data.get("expiry"),
                    "key": key,
                    "hwid": hwid
                })
                asyncio.create_task(self._heartbeat())
                return True
            else:
                self.last_error = data.get('message')
                return False
        except websockets.exceptions.ConnectionClosed as e:
            self.last_error = e.reason or f"Connection closed with code {e.code}"
            return False
        except Exception as e:
            self.last_error = str(e)
            return False

    async def _heartbeat(self):
        while self.is_connected:
            try:
                await self.ws.send("ping")
                await asyncio.sleep(30) # Send ping every 30 seconds
            except:
                self.is_connected = False
                break

    def get_user_info(self):
        if not self.is_connected:
            return None
        return self.user_info

    async def close(self):
        if self.ws:
            await self.ws.close()
            self.is_connected = False
