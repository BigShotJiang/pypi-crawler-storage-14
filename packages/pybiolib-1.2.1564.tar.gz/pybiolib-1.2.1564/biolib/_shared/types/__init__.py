from biolib._shared.types.resource import ResourceUriDict, SemanticVersionDict

__all__ = ['ResourceUriDict', 'SemanticVersionDict']
