import unittest
import json
from typing import Dict
from pydantic import Field
from signet import AgentState, StateMachineGuard, StateStatus

# --- Mock Implementation for Testing ---
class MockTradeState(AgentState):
    # A simple state for buying/selling
    data: Dict[str, int] = Field(..., description="Must have price")

# Define a simple graph: START -> NEGOTIATING -> AGREED
MOCK_GRAPH = {
    "START": ["NEGOTIATING"],
    "NEGOTIATING": ["AGREED", "FAILED"],
    "AGREED": [],
    "FAILED": []
}

class TestSignetProtocol(unittest.TestCase):
    def setUp(self):
        # Create a fresh guard for each test
        self.guard = StateMachineGuard(MockTradeState, MOCK_GRAPH)

    def test_valid_flow(self):
        """Test a perfect, happy path execution."""
        # Step 1: START
        input1 = json.dumps({"step_id": 1, "status": "START", "data": {"price": 0}})
        state1 = self.guard.parse(input1)
        self.assertTrue(state1.verify_signature(self.guard.public_key))
        
        # Step 2: NEGOTIATING
        input2 = json.dumps({"step_id": 2, "status": "NEGOTIATING", "data": {"price": 100}})
        state2 = self.guard.parse(input2)
        self.assertEqual(state2.step_id, 2)

    def test_invalid_graph_move(self):
        """Test that jumping from START to AGREED (skipping NEGOTIATING) fails."""
        # Step 1: START
        self.guard.parse(json.dumps({"step_id": 1, "status": "START", "data": {"price": 0}}))
        
        # Step 2: Illegal Jump
        bad_input = json.dumps({"step_id": 2, "status": "AGREED", "data": {"price": 100}})
        
        with self.assertRaises(Exception) as context:
            self.guard.parse(bad_input)
        self.assertIn("ILLEGAL MOVE", str(context.exception))

    def test_schema_violation(self):
        """Test that missing data fields fails."""
        # Missing 'data' field entirely
        bad_input = json.dumps({"step_id": 1, "status": "START"})
        
        with self.assertRaises(Exception) as context:
            self.guard.parse(bad_input)
        self.assertIn("Schema Violation", str(context.exception))

    def test_tamper_proof(self):
        """Test that modifying a signed state invalidates the signature."""
        input1 = json.dumps({"step_id": 1, "status": "START", "data": {"price": 0}})
        state = self.guard.parse(input1)
        
        # Hacker tries to change price after signing
        state.data['price'] = 999999
        
        # Signature should now fail
        is_valid = state.verify_signature(self.guard.public_key)
        self.assertFalse(is_valid)

if __name__ == '__main__':
    unittest.main()