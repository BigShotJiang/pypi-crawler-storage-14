from setuptools import setup, find_packages

setup(
    name="signet-ai",  # This is what users type: pip install signet-ai
    version="0.1.0",
    description="Cryptographic state enforcement for AI Agents.",
    long_description=open("README.md").read() if open("README.md").read() else "",
    long_description_content_type="text/markdown",
    author="Harish Balasubramanian",
    author_email="harishbala153@gmail.com",
    url="https://github.com/harishbalasubramanian/signet",
    packages=find_packages(), # Automatically finds the 'signet' folder
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires='>=3.9',
    install_requires=[
        "pydantic>=2.0.0",
        "cryptography>=41.0.0"
    ],
)