import json
from typing import Any, List, Dict, Union, Optional
from .protocol import StateMachineGuard, AgentState

class SignetClient:
    def __init__(self, client: Any, guard: StateMachineGuard):
        self.client = client
        self.guard = guard

    def run(self, 
            messages: List[Dict[str, str]], 
            model: str, 
            max_retries: int = 3, 
            **kwargs) -> AgentState:
        
        current_messages = messages.copy()
        attempts = 0

        while attempts < max_retries:
            # Initialize to None so the except block is safe
            raw_content = None
            
            try:
                # 1. Call the LLM
                response = self.client.chat.completions.create(
                    model=model,
                    messages=current_messages,
                    response_format={"type": "json_object"}, 
                    **kwargs
                )
                raw_content = response.choices[0].message.content

                # 2. Try to Validate & Sign
                signed_state = self.guard.parse(raw_content)
                return signed_state

            except Exception as e:
                attempts += 1
                if attempts >= max_retries:
                    raise ValueError(f"Max Retries Exceeded. Last Error: {e}")

                # 3. FEEDBACK LOOP
                # Only append the LLM's output if we actually got one
                if raw_content:
                    current_messages.append({"role": "assistant", "content": raw_content})
                
                error_feedback = (
                    f"SYSTEM ERROR: Your output failed validation. Reason: {str(e)}. "
                    "You must correct your JSON structure or State Logic and try again."
                )
                current_messages.append({"role": "user", "content": error_feedback})

        raise ValueError("Max retries exceeded.")