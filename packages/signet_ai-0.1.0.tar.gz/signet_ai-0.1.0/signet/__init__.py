# signet/__init__.py

from .protocol import (
    AgentState, 
    StateMachineGuard, 
    StateStatus
)

__version__ = "0.1.0"

# This controls what is imported when someone types: from signet import *
__all__ = ["AgentState", "StateMachineGuard", "StateStatus"]