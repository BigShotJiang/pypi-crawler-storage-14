import base64
import json
from enum import Enum
from typing import Dict, Any, List, Optional, Type, Set
from pydantic import BaseModel, Field, ValidationError
from cryptography.hazmat.primitives.asymmetric import ed25519

# --- Custom Exceptions for Better Debugging ---
class SignetError(Exception):
    """Base exception for all Signet errors."""
    pass

class SchemaError(SignetError):
    """Raised when the LLM outputs invalid JSON or missing fields."""
    pass

class StateError(SignetError):
    """Raised when the Agent tries to make an illegal move in the graph."""
    pass

class IntegrityError(SignetError):
    """Raised when a signature verification fails (tampering detected)."""
    pass

# --- Core Enums ---
class StateStatus(str, Enum):
    """Standard statuses, though users can define their own strings too."""
    START = "START"
    OPEN = "OPEN"
    LOCKED = "LOCKED"
    FINALIZED = "FINALIZED"
    FAILED = "FAILED"

# --- The Base State Object ---
class AgentState(BaseModel):
    """
    The cryptographic envelope for an Agent's thought process.
    Users inherit from this to define their own schemas (e.g. RefundState).
    """
    step_id: int = Field(..., description="Monotonically increasing counter to prevent replay attacks.")
    status: str = Field(..., description="The current node in the state machine graph.")
    data: Dict[str, Any] = Field(..., description="The business logic payload (price, terms, etc).")
    signature: Optional[str] = Field(None, description="Ed25519 Signature of this state.")

    def _get_canonical_bytes(self) -> bytes:
        """
        Internal helper to generate a deterministic byte string for signing.
        Crucial: We exclude the signature field and force key sorting.
        """
        # Pydantic v2 model_dump returns a dict
        data_dict = self.model_dump(exclude={'signature'})
        # JSON dump with sort_keys=True ensures {a:1, b:2} is identical to {b:2, a:1}
        return json.dumps(data_dict, sort_keys=True).encode('utf-8')

    def sign_state(self, private_key: ed25519.Ed25519PrivateKey) -> None:
        """
        Cryptographically signs the state using the Agent's private key.
        """
        payload = self._get_canonical_bytes()
        sig_bytes = private_key.sign(payload)
        self.signature = base64.b64encode(sig_bytes).decode('utf-8')

    def verify_signature(self, public_key: ed25519.Ed25519PublicKey) -> bool:
        """
        Verifies that the state has not been modified since signing.
        """
        if not self.signature:
            return False
        try:
            payload = self._get_canonical_bytes()
            sig_bytes = base64.b64decode(self.signature)
            public_key.verify(sig_bytes, payload)
            return True
        except Exception:
            return False

# --- The Guardrail Engine ---
class StateMachineGuard:
    """
    The 'Referee' that manages the session, enforces the graph, and holds the keys.
    """
    def __init__(self, state_model: Type[AgentState], transition_graph: Dict[str, List[str]]):
        """
        Args:
            state_model: The Pydantic class defining the data schema (e.g. RefundState).
            transition_graph: A dict defining valid moves, e.g. {'START': ['OPEN']}.
        """
        self.state_model = state_model
        self.transitions = transition_graph
        
        # Identity: In a real app, load this from env vars or HSM
        self._private_key = ed25519.Ed25519PrivateKey.generate()
        self.public_key = self._private_key.public_key()
        
        # Memory: The immutable ledger of this session
        self.history: List[AgentState] = []

    def _validate_graph(self, new_state: AgentState):
        """
        Enforces the State Machine rules.
        """
        # 1. First State Check
        if not self.history:
            if new_state.step_id != 1:
                raise StateError(f"First state must have step_id=1, got {new_state.step_id}")
            
            # --- ADD THIS BLOCK ---
            # Enforce that we must begin at the "START" node
            if new_state.status != "START":
                raise StateError(f"Illegal Entry: Must start at 'START', but got '{new_state.status}'")
            # ----------------------
            
            return

        last_state = self.history[-1]

        # 2. Check Sequence (Anti-Replay / Anti-Skip)
        if new_state.step_id != last_state.step_id + 1:
             raise StateError(f"Step ID mismatch. Expected {last_state.step_id + 1}, got {new_state.step_id}")

        # 3. Check Graph Transitions
        allowed_next_states = self.transitions.get(last_state.status, [])
        if new_state.status not in allowed_next_states:
            raise StateError(
                f"ILLEGAL MOVE: Cannot transition from '{last_state.status}' to '{new_state.status}'. "
                f"Allowed moves: {allowed_next_states}"
            )

    def parse(self, llm_response: str) -> AgentState:
        """
        The main entry point. 
        Takes raw string -> Validates Schema -> Validates Graph -> Signs -> Returns Object.
        """
        try:
            # A. Parse JSON
            try:
                data_dict = json.loads(llm_response)
            except json.JSONDecodeError:
                raise SchemaError("LLM output was not valid JSON.")

            # B. Validate Pydantic Schema
            try:
                state_obj = self.state_model(**data_dict)
            except ValidationError as e:
                # We return a helpful error message so the LLM can self-correct
                raise SchemaError(f"Schema Violation: {e}")
            
            # C. Validate State Machine Logic
            self._validate_graph(state_obj)
            
            # D. Sign the State (The 'Notarization')
            state_obj.sign_state(self._private_key)
            self.history.append(state_obj)
            
            return state_obj

        except (SchemaError, StateError) as e:
            # Re-raise these as-is, they are 'logic' errors the User/Agent can fix
            raise e
        except Exception as e:
            # Catch-all for unexpected crashes
            raise SignetError(f"System Error: {str(e)}")

    def get_transcript(self) -> str:
        """
        Returns the full history as a verifiable JSON string.
        """
        return json.dumps([s.model_dump() for s in self.history], indent=2)