# 🔐 Signet (signet-ai)
**Cryptographic State Enforcement for AI Agents.**

[![PyPI version](https://img.shields.io/pypi/v/signet-ai.svg)](https://pypi.org/project/signet-ai/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

**Problem:** LLMs are probabilistic. They hallucinate.
**Solution:** Signet is deterministic. It forces your agent to adhere to a strict Cryptographic State Machine.

If your agent tries to output a state that violates your business logic (e.g., refunding > $100) or your process graph (e.g., skipping "Approval"), Signet **blocks it** and auto-corrects the LLM.

## 🚀 Features

* **Graph Enforcement:** Define valid transitions (START -> ANALYZING -> APPROVED). Signet blocks illegal jumps.
* **Self-Healing Middleware:** Automatically retries LLM calls with error feedback when hallucinations occur.
* **Tamper-Proof Logs:** Every state transition is cryptographically signed (Ed25519).
* **Visual Debugger:** Includes a local Streamlit dashboard to visualize your agent's logic.

## 📦 Installation

```bash
pip install signet-ai
```

## ⚡ Quick Start

### 1. Define your Logic
```python
from signet import AgentState, StateMachineGuard, StateStatus
from pydantic import Field
from typing import Dict

class RefundState(AgentState):
    # Enforce strict types on your data
    data: Dict[str, int] = Field(..., description="Must contain 'amount'")

# Define valid moves
REFUND_GRAPH = {
    "START": ["ANALYZING"],
    "ANALYZING": ["APPROVED", "DENIED"],
    "APPROVED": [],
    "DENIED": []
}
```

### 2. Wrap your LLM (Self-Healing)
```python
from signet.middleware import SignetClient
import openai

guard = StateMachineGuard(RefundState, REFUND_GRAPH)
client = SignetClient(openai.Client(), guard)

# Run the agent
# If the LLM tries to skip steps or output bad JSON, 
# Signet catches it, feeds the error back, and retries automatically.
final_state = client.run(
    messages=[{"role": "user", "content": "Process a refund for $50"}],
    model="gpt-4"
)

print(f"Signed: {final_state.signature}")
```

## 📊 Visual Debugger
Signet comes with a built-in dashboard to test your graph logic.

1. Create a file `viz.py` (see examples folder).
2. Run:
```bash
streamlit run viz.py
```

## 🛡️ The "Why"
Existing frameworks (LangGraph, AutoGen) manage *memory*. Signet manages *trust*.
Use Signet when you need to ensure that your agent followed the rules.