"""Outlink Extractor

A small utility to extract outbound links from a given URL
and export them to a CSV file.
"""

__version__ = "0.1.0"
