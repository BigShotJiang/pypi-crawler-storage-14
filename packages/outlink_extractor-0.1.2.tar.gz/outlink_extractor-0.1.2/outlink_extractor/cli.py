import argparse
import sys

from .core import extract_outlinks_to_csv


def main():
    parser = argparse.ArgumentParser(
        description="Extract outbound links from a URL into outlink.csv"
    )
    parser.add_argument(
        "url",
        help="URL to scan for outbound links (e.g. https://example.com)",
    )
    parser.add_argument(
        "-o",
        "--output",
        default="outlink.csv",
        help="Output CSV filename (default: outlink.csv)",
    )

    args = parser.parse_args()

    count = extract_outlinks_to_csv(args.url, args.output)

    if count:
        print(f"[outlink-extractor] Saved {count} outlinks to {args.output}")
    else:
        print(
            "[outlink-extractor] No outbound links found or there was an issue fetching the page. "
            f"Empty CSV created at {args.output}"
        )


if __name__ == "__main__":
    main()
