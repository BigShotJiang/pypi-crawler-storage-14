import csv
import sys
from urllib.parse import urlparse, urljoin

import requests
from bs4 import BeautifulSoup


def _is_external_link(href: str, base_netloc: str) -> bool:
    """
    Return True if href is an external (outbound) link
    compared to base_netloc.
    """
    if not href:
        return False

    parsed = urlparse(href)

    # Skip non-http(s) schemes: mailto:, tel:, javascript:, etc.
    if parsed.scheme and parsed.scheme not in {"http", "https"}:
        return False

    # Relative URL -> same domain, so not an outbound link
    if not parsed.netloc:
        return False

    return parsed.netloc != base_netloc


def extract_outlinks(url: str):
    """
    Extract outbound links from the provided URL.

    Returns a list of dicts with keys:
    - href
    - anchor_text
    """
    try:
        response = requests.get(url, timeout=15)
        response.raise_for_status()
    except Exception as e:
        print(f"[outlink-extractor] Failed to fetch URL: {e}", file=sys.stderr)
        return []

    soup = BeautifulSoup(response.text, "html.parser")
    parsed_base = urlparse(url)
    base_netloc = parsed_base.netloc

    outlinks = []

    for a in soup.find_all("a", href=True):
        href = a.get("href", "").strip()
        full_url = urljoin(url, href)

        if not _is_external_link(full_url, base_netloc):
            continue

        text = " ".join(a.get_text(strip=True).split())

        outlinks.append(
            {
                "href": full_url,
                "anchor_text": text,
            }
        )

    return outlinks


def extract_outlinks_to_csv(url: str, output_path: str = "outlink.csv") -> int:
    """
    Export in 3-column format:
    URL | Outlink | Anchor Text
    """
    outlinks = extract_outlinks(url)

    fieldnames = ["URL", "Outlink", "Anchor Text"]

    with open(output_path, "w", newline="", encoding="utf-8") as csvfile:
        writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
        writer.writeheader()

        for row in outlinks:
            writer.writerow({
                "URL": url,                           # source page
                "Outlink": row["href"],
                "Anchor Text": row["anchor_text"],
            })

    return len(outlinks)
