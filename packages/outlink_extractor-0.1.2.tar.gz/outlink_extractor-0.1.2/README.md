# outlink-extractor

A small Python tool to quickly extract **outbound links** from any given URL and export them into a CSV file.

**Developed by: Amal Alexander**  
**Email:** [amalalex95@gmail.com](mailto:amalalex95@gmail.com)

---

## Features

- Simple CLI command.
- Fetches a web page and parses all `<a>` tags.
- Filters only external (outbound) links.
- Exports results to `outlink.csv` (or a custom file name) in the current directory.

Each row in the CSV contains:

- `href` – Absolute URL of the outbound link  
- `anchor_text` – Cleaned anchor text  
- `rel` – rel attribute value (if present)  
- `target` – target attribute value (if present)

---

## Installation

You can install it locally from the source:

```bash
pip install .
```

Or, if you have the ZIP file:

```bash
pip install outlink-extractor.zip
```

(Replace with the actual path to your ZIP.)

---

## Usage

After installation, run from your terminal:

```bash
outlink-extractor https://example.com
```

This will create `outlink.csv` in the current directory.

You can also specify a custom output file:

```bash
outlink-extractor https://example.com -o my-outlinks.csv
```

---

## Notes

- Requires Python 3.8+
- Uses `requests` and `beautifulsoup4` under the hood.
- Intended for quick SEO checks, audits, and outbound link analysis.

---
