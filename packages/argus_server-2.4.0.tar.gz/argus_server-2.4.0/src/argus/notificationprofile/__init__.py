default_app_config = "argus.notificationprofile.apps.NotificationprofileConfig"
