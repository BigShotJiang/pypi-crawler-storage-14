default_app_config = "argus.auth.apps.AuthConfig"
