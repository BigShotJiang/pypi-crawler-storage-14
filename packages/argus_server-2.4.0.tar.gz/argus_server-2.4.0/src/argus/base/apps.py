from django.apps import AppConfig


class ArgusBaseConfig(AppConfig):
    name = "argus.base"
    label = "argus_base"
