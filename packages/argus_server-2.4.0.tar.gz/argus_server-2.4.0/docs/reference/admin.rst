============
Django admin
============

The project’s admin pages are reachable on ``/admin/``. Users need to have the
``is_staff`` field set to ``True`` the be allowed to access the admin.

Authorization tokens
====================

These can be accessed and generated at ``/admin/authtoken/token/``.
