.. _HTMX HowTos:

=============================
How Tos for the HTMx Frontend
=============================


.. toctree::
   :glob:

   htmx-frontend/*
