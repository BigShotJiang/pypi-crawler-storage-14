.. note::
   Open an issue on `Github <https://github.com/Uninett/Argus/issues>`_ to have
   your integration added to this list. It needs to be publicly accessible (and
   preferably available on PyPI) so we can check the code. We will link up both
   the source code repo (or homepage otherwise) and the PyPI-entry.
