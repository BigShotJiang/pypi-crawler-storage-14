# cocat

[![Build Status](https://github.com/SciQLop/cocat/workflows/test/badge.svg)](https://github.com/SciQLop/cocat/actions)
[![Code Coverage](https://img.shields.io/badge/coverage-100%25-green)](https://img.shields.io/badge/coverage-100%25-green)

CRDT-based [tscat](https://github.com/SciQLop/tscat).
