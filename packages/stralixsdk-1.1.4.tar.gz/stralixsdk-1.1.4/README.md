# StralixSDK

Official Python SDK for interacting with the Stralix Cloud SCNAC API.

## Installation

```bash
pip install stralixsdk
```

## Usage

```python
from stralixsdk import StralixClient

# Initialize the client
client = StralixClient(api_key="YOUR_API_KEY", base_url="https://sc01.stralix.cloud")

# Get blockchain info
info = client.get_info("LTC")
print(info)

# Get block count
count = client.get_block_count("LTC")
print(f"Current block height: {count}")
```

## Features

- Easy access to SCNAC API endpoints (v1)
- Simple Pythonic interface
- Automatic error handling
