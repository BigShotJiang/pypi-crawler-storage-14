class StralixSDKError(Exception):
    """Base exception for StralixSDK."""
    pass

class StralixConnectionError(StralixSDKError):
    """Raised when a network connection error occurs."""
    pass

class StralixAPIError(StralixSDKError):
    """Raised when the API returns an error response."""
    def __init__(self, message, status_code=None, response=None):
        super().__init__(message)
        self.status_code = status_code
        self.response = response

class StralixAuthError(StralixAPIError):
    """Raised when authentication fails (401/403)."""
    pass

class StralixNotFoundError(StralixAPIError):
    """Raised when a resource is not found (404)."""
    pass
