import logging
import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry
from typing import Optional, Dict, Any, Union, List
from .exceptions import (
    StralixSDKError,
    StralixConnectionError,
    StralixAPIError,
    StralixAuthError,
    StralixNotFoundError
)

# Configure default logger
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class StralixClient:
    """
    A high-level client for interacting with the Stralix Cloud SCNAC API.

    Attributes:
        api_key (str): The API key for authentication.
        base_url (str): The base URL of the SCNAC server.
        timeout (int): Request timeout in seconds.
    """

    def __init__(self, api_key: str, base_url: str, timeout: int = 30, retries: int = 3):
        """
        Initialize the StralixClient.

        Args:
            api_key (str): Your Stralix API Key.
            base_url (str): The URL of your SCNAC server (e.g., http://127.0.0.1:500).
            timeout (int, optional): Timeout for requests in seconds. Defaults to 30.
            retries (int, optional): Number of retries for failed requests. Defaults to 3.
        """
        self.api_key = api_key
        self.base_url = base_url.rstrip('/')
        self.timeout = timeout
        self.session = requests.Session()
        self.session.headers.update({
            'X-API-KEY': self.api_key,
            'User-Agent': 'StralixSDK/1.1.0'
        })

        # Configure Retry Logic
        retry_strategy = Retry(
            total=retries,
            backoff_factor=1,
            status_forcelist=[429, 500, 502, 503, 504],
            allowed_methods=["HEAD", "GET", "OPTIONS", "POST"]
        )
        adapter = HTTPAdapter(max_retries=retry_strategy)
        self.session.mount("http://", adapter)
        self.session.mount("https://", adapter)

    def __enter__(self):
        """Context manager entry."""
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """Context manager exit. Closes the session."""
        self.close()

    def close(self):
        """Close the underlying requests session."""
        self.session.close()

    def _request(self, method: str, endpoint: str, data: Optional[Dict] = None) -> Any:
        """
        Internal method to handle requests with error handling.

        Args:
            method (str): HTTP method (GET, POST, DELETE).
            endpoint (str): API endpoint path.
            data (Dict, optional): JSON payload for POST requests.

        Returns:
            Any: The parsed JSON response.

        Raises:
            StralixConnectionError: Network issues.
            StralixAuthError: Invalid API key.
            StralixNotFoundError: Resource not found.
            StralixAPIError: Other API errors.
        """
        url = f"{self.base_url}{endpoint}"
        print(f"DEBUG: Requesting {method} {url}")
        try:
            response = self.session.request(method, url, json=data, timeout=self.timeout)
            response.raise_for_status()
            return response.json()
        except requests.exceptions.ConnectionError as e:
            logger.error(f"Connection error to {url}: {e}")
            raise StralixConnectionError(f"Failed to connect to {self.base_url}") from e
        except requests.exceptions.Timeout as e:
            logger.error(f"Request timed out to {url}: {e}")
            raise StralixConnectionError(f"Request timed out") from e
        except requests.exceptions.HTTPError as e:
            status = e.response.status_code
            try:
                error_msg = e.response.json().get('detail', e.response.text)
            except ValueError:
                error_msg = e.response.text

            logger.error(f"API Error {status}: {error_msg}")

            if status in (401, 403):
                raise StralixAuthError(f"Authentication failed: {error_msg}", status, e.response) from e
            elif status == 404:
                raise StralixNotFoundError(f"Resource not found: {error_msg}", status, e.response) from e
            else:
                raise StralixAPIError(f"API Error {status}: {error_msg}", status, e.response) from e
        except requests.exceptions.RequestException as e:
            logger.error(f"Unexpected error: {e}")
            raise StralixSDKError(f"An unexpected error occurred: {e}") from e

    def _get(self, endpoint: str) -> Any:
        return self._request("GET", endpoint)

    def _post(self, endpoint: str, data: Optional[Dict] = None) -> Any:
        return self._request("POST", endpoint, data)

    def _delete(self, endpoint: str) -> Any:
        return self._request("DELETE", endpoint)

    # ==========================================
    # Blockchain Interaction (v1)
    # ==========================================

    def get_info(self, ticker: str) -> Dict[str, Any]:
        """Get summary of blockchain, network, and mining info."""
        return self._get(f"/v1/{ticker}/getinfo")

    def get_blockchain_info(self, ticker: str) -> Dict[str, Any]:
        """Get state of the blockchain processing."""
        return self._get(f"/v1/{ticker}/getblockchaininfo")

    def get_network_info(self, ticker: str) -> Dict[str, Any]:
        """Get state of the P2P network."""
        return self._get(f"/v1/{ticker}/getnetworkinfo")

    def get_mining_info(self, ticker: str) -> Dict[str, Any]:
        """Get mining-related information."""
        return self._get(f"/v1/{ticker}/getmininginfo")

    def get_net_totals(self, ticker: str) -> Dict[str, Any]:
        """Get total network traffic."""
        return self._get(f"/v1/{ticker}/getnettotals")

    def get_uptime(self, ticker: str) -> int:
        """Get node uptime in seconds."""
        return self._get(f"/v1/{ticker}/uptime")

    def get_block_count(self, ticker: str) -> int:
        """Get height of the most-work fully-validated chain."""
        return self._get(f"/v1/{ticker}/getblockcount")

    def get_best_block_hash(self, ticker: str) -> str:
        """Get hash of the best (tip) block."""
        return self._get(f"/v1/{ticker}/getbestblockhash")

    def get_block_hash(self, ticker: str, height: int) -> str:
        """Get hash of block at given height."""
        return self._get(f"/v1/{ticker}/getblockhash/{height}")

    def get_block(self, ticker: str, hash_or_height: Union[str, int]) -> Dict[str, Any]:
        """Get block data by hash or height."""
        return self._get(f"/v1/{ticker}/getblock/{hash_or_height}")

    def get_block_header(self, ticker: str, hash_val: str) -> Dict[str, Any]:
        """Get block header information."""
        return self._get(f"/v1/{ticker}/getblockheader/{hash_val}")

    def get_chain_tips(self, ticker: str) -> List[Dict[str, Any]]:
        """Return information about all known tips."""
        return self._get(f"/v1/{ticker}/getchaintips")

    def get_difficulty(self, ticker: str) -> float:
        """Get current proof-of-work difficulty."""
        return self._get(f"/v1/{ticker}/getdifficulty")

    def get_raw_transaction(self, ticker: str, txid: str) -> Dict[str, Any]:
        """Get raw transaction data."""
        return self._get(f"/v1/{ticker}/getrawtransaction/{txid}")

    def get_mempool_info(self, ticker: str) -> Dict[str, Any]:
        """Get active state of the memory pool."""
        return self._get(f"/v1/{ticker}/getmempoolinfo")

    def get_raw_mempool(self, ticker: str) -> List[str]:
        """Get all transaction IDs in the memory pool."""
        return self._get(f"/v1/{ticker}/getrawmempool")

    def get_tx_out(self, ticker: str, txid: str, n: int) -> Dict[str, Any]:
        """Get details about an unspent transaction output."""
        return self._get(f"/v1/{ticker}/gettxout/{txid}/{n}")

    def get_network_hashps(self, ticker: str) -> float:
        """Get estimated network hashes per second."""
        return self._get(f"/v1/{ticker}/getnetworkhashps")

    def get_block_template(self, ticker: str) -> Dict[str, Any]:
        """Get data needed to construct a block."""
        return self._get(f"/v1/{ticker}/getblocktemplate")

    def submit_block(self, ticker: str, hex_data: str) -> str:
        """Submit a new block to the network."""
        return self._post(f"/v1/{ticker}/submitblock", {"hex": hex_data})

    def get_peer_info(self, ticker: str) -> List[Dict[str, Any]]:
        """Get data about each connected network node."""
        return self._get(f"/v1/{ticker}/getpeerinfo")

    def get_connection_count(self, ticker: str) -> int:
        """Get number of connections to other nodes."""
        return self._get(f"/v1/{ticker}/getconnectioncount")

    def get_added_node_info(self, ticker: str) -> List[Dict[str, Any]]:
        """Get info about manually added nodes."""
        return self._get(f"/v1/{ticker}/getaddednodeinfo")

    def ping(self, ticker: str) -> None:
        """Request that a ping be sent to all other nodes."""
        return self._get(f"/v1/{ticker}/ping")

    def validate_address(self, ticker: str, address: str) -> Dict[str, Any]:
        """Return information about the given address."""
        return self._post(f"/v1/{ticker}/validateaddress", {"address": address})

    def estimate_fee(self, ticker: str, blocks: int) -> float:
        """Estimate fee for transaction confirmation."""
        return self._get(f"/v1/{ticker}/estimatefee/{blocks}")

    def estimate_smart_fee(self, ticker: str, blocks: int) -> Dict[str, Any]:
        """Estimate fee (more smart)."""
        return self._get(f"/v1/{ticker}/estimatesmartfee/{blocks}")

    def sign_message(self, ticker: str, privkey: str, message: str) -> str:
        """Sign a message with a private key."""
        return self._post(f"/v1/{ticker}/signmessagewithprivkey", {"privkey": privkey, "message": message})

    def verify_message(self, ticker: str, address: str, signature: str, message: str) -> bool:
        """Verify a signed message."""
        return self._post(f"/v1/{ticker}/verifymessage", {"address": address, "signature": signature, "message": message})

    def rpc_command(self, ticker: str, method: str, params: Optional[List] = None) -> Any:
        """Execute any arbitrary JSON-RPC method."""
        return self._post(f"/v1/{ticker}/rpc/{method}", params)

    def stop_node(self, ticker: str) -> str:
        """Stop the blockchain node server."""
        return self._post(f"/v1/{ticker}/stop")
