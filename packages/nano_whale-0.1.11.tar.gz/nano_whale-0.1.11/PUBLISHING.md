# 📦 Publishing Nano Whale to PyPI

This guide walks you through publishing the Nano Whale TUI to PyPI (Python Package Index).

## 📋 Prerequisites

Before publishing, ensure you have:

- [ ] Python 3.8+ installed
- [ ] A PyPI account (create at https://pypi.org/account/register/)
- [ ] A TestPyPI account for testing (https://test.pypi.org/account/register/)
- [ ] All project files are ready (README.md, LICENSE, pyproject.toml)

## 🔧 Setup

### 1. Install Build Tools

```bash
# Install build and twine
pip install --upgrade build twine
```

### 2. Update Version

Before each release, update the version in `pyproject.toml`:

```toml
[project]
name = "nano-whale"
version = "0.1.0"  # Update this (e.g., 0.1.1, 0.2.0, 1.0.0)
```

Follow [Semantic Versioning](https://semver.org/):
- **MAJOR** (1.0.0) - Incompatible API changes
- **MINOR** (0.1.0) - New features, backwards compatible
- **PATCH** (0.0.1) - Bug fixes, backwards compatible

### 3. Update URLs in pyproject.toml

Replace `yourusername` with your actual GitHub username:

```toml
[project.urls]
Homepage = "https://github.com/YOUR_USERNAME/nano-whale"
Repository = "https://github.com/YOUR_USERNAME/nano-whale"
Issues = "https://github.com/YOUR_USERNAME/nano-whale/issues"
```

## 🧪 Test Build Locally

### 1. Clean Previous Builds

```bash
# Remove old build artifacts
rm -rf dist/ build/ *.egg-info
# On Windows:
# rmdir /s /q dist build
# del /s /q *.egg-info
```

### 2. Build the Package

```bash
# Build from the docker_clui directory
cd docker_clui
python -m build
```

This creates two files in `dist/`:
- `nano-whale-0.1.0.tar.gz` (source distribution)
- `nano_whale-0.1.0-py3-none-any.whl` (wheel distribution)

### 3. Test Installation Locally

```bash
# Install from the wheel
pip install dist/nano_whale-0.1.0-py3-none-any.whl

# Test the command
nano-whale

# Uninstall after testing
pip uninstall nano-whale
```

## 🧪 Publish to TestPyPI (Recommended First)

TestPyPI is a separate instance for testing. Always test here first!

### 1. Upload to TestPyPI

```bash
python -m twine upload --repository testpypi dist/*
```

You'll be prompted for:
- **Username**: Your TestPyPI username
- **Password**: Your TestPyPI password (or use token)

### 2. Test Install from TestPyPI

```bash
# Install from TestPyPI
pip install --index-url https://test.pypi.org/simple/ --extra-index-url https://pypi.org/simple/ nano-whale

# Test the installation
nano-whale

# Uninstall
pip uninstall nano-whale
```

**Note**: `--extra-index-url` is needed because TestPyPI doesn't have all dependencies (like textual).

## 🚀 Publish to PyPI (Production)

Once you've tested on TestPyPI, publish to the real PyPI:

### 1. Upload to PyPI

```bash
python -m twine upload dist/*
```

You'll be prompted for:
- **Username**: Your PyPI username (or `__token__`)
- **Password**: Your PyPI password (or API token)

### 2. Verify on PyPI

Visit: https://pypi.org/project/nano-whale/

### 3. Test Installation

```bash
# Install from PyPI
pip install nano-whale

# Test
nano-whale

# Success! 🎉
```

## 🔐 Using API Tokens (Recommended)

API tokens are more secure than passwords.

### Create PyPI Token

1. Go to https://pypi.org/manage/account/token/
2. Click "Add API token"
3. Name: "nano-whale-upload"
4. Scope: "Project: nano-whale" (or "Entire account")
5. Copy the token (starts with `pypi-`)

### Create TestPyPI Token

1. Go to https://test.pypi.org/manage/account/token/
2. Follow same steps as above

### Configure Tokens

Create `~/.pypirc`:

```ini
[distutils]
index-servers =
    pypi
    testpypi

[pypi]
username = __token__
password = pypi-YOUR_PYPI_TOKEN_HERE

[testpypi]
repository = https://test.pypi.org/legacy/
username = __token__
password = pypi-YOUR_TESTPYPI_TOKEN_HERE
```

**Security**: Keep this file private! Add to `.gitignore`.

Now you can upload without entering credentials:

```bash
python -m twine upload --repository testpypi dist/*  # TestPyPI
python -m twine upload dist/*                          # PyPI
```

## 📝 Publishing Checklist

Before each release:

- [ ] Update version in `pyproject.toml`
- [ ] Update CHANGELOG (if you have one)
- [ ] Test the app locally: `python -m docker_clui.app`
- [ ] Update README.md with new features/changes
- [ ] Commit all changes to git
- [ ] Create a git tag: `git tag v0.1.0`
- [ ] Clean old builds: `rm -rf dist/`
- [ ] Build new package: `python -m build`
- [ ] Check package: `twine check dist/*`
- [ ] Test on TestPyPI first
- [ ] Install and test from TestPyPI
- [ ] Upload to PyPI
- [ ] Install and test from PyPI
- [ ] Push git tag: `git push origin v0.1.0`
- [ ] Create GitHub release

## 🔍 Verify Package Quality

Before uploading, check your package:

```bash
# Check package for common errors
twine check dist/*

# Output should be:
# Checking dist/nano-whale-0.1.0.tar.gz: PASSED
# Checking dist/nano_whale-0.1.0-py3-none-any.whl: PASSED
```

## 🐛 Troubleshooting

### "File already exists"

If you get this error, you've already uploaded this version. You need to:
1. Increment the version number
2. Rebuild: `python -m build`
3. Upload again

### "Invalid distribution"

Check that:
- `README.md` exists and is valid
- `LICENSE` file exists
- `pyproject.toml` is properly formatted
- All required fields are filled in

### "Package not found" after upload

Wait a few minutes. PyPI needs time to index new packages.

### Dependencies not installing

Make sure `dependencies` in `pyproject.toml` lists all required packages:
```toml
dependencies = [
    "textual>=0.40.0",
]
```

## 📊 Post-Publishing Tasks

After successful publication:

1. **Update README.md** on GitHub with installation instructions
2. **Create a GitHub Release** with the same version tag
3. **Announce** on social media, Reddit, etc.
4. **Monitor** PyPI download stats
5. **Respond** to issues and feedback

## 🔄 Updating the Package

To release a new version:

1. Make your changes
2. Update version in `pyproject.toml`: `0.1.0` → `0.1.1`
3. Clean and rebuild: 
   ```bash
   rm -rf dist/
   python -m build
   ```
4. Upload: `twine upload dist/*`

## 📈 Useful Commands

```bash
# Check package info
pip show nano-whale

# View package files
pip show -f nano-whale

# Check outdated dependencies
pip list --outdated

# Validate pyproject.toml
pip install validate-pyproject
validate-pyproject pyproject.toml
```

## 🔗 Resources

- [PyPI Help](https://pypi.org/help/)
- [Python Packaging Guide](https://packaging.python.org/)
- [Semantic Versioning](https://semver.org/)
- [Twine Documentation](https://twine.readthedocs.io/)
- [PEP 517 - Build Backend](https://peps.python.org/pep-0517/)

## 💡 Tips

- **Test on TestPyPI first** - Avoid mistakes on the main PyPI
- **Use semantic versioning** - Makes version management easier
- **Write good release notes** - Help users understand changes
- **Keep dependencies minimal** - Reduces conflicts
- **Respond to issues quickly** - Builds community trust

---

**Ready to publish? Follow the checklist and good luck! 🚀**