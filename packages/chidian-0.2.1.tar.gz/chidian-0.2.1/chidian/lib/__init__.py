"""
Internal library modules for chidian.

This package contains helper functions, parsers, and implementation details.
"""
