AITypeEnum
==========

.. autoclass:: inmydata.ConversationalData.AITypeEnum
    :members:
    :undoc-members:
    :show-inheritance:
    :no-index:
