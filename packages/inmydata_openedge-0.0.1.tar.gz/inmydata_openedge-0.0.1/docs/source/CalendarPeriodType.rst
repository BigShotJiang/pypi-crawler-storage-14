CalendarPeriodType
==================

.. autoclass:: inmydata.CalendarAssistant.CalendarPeriodType
    :members:
    :undoc-members:
    :show-inheritance:
    :no-index: