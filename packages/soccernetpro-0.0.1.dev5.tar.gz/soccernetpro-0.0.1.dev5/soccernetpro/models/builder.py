# soccernetpro/models/builder.py

from .backbones.video_mae import build_video_mae_backbone

def build_model(config, device):
    """
    Dispatch model builder based on cfg.MODEL.task
    """
    task = config.TASK.lower()
    
    if task == "classification":
        if config.MODEL.backbone == "video_mae":
            return build_video_mae_backbone(config, device)
    else:
        raise ValueError(f"Unsupported model type: {model_type}")
