*[API]: Application Programming Interface
*[ETL]: Extract, Transform, Load
*[ORM]: Object-Relational Mapping
*[SQL]: Structured Query Language
*[DSL]: Domain-Specific Language
*[CSV]: Comma-Separated Values
*[JSON]: JavaScript Object Notation
*[OIDC]: OpenID Connect

