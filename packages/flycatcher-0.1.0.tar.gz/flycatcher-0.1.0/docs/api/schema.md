# Schema API

Core schema definition classes and decorators.

::: flycatcher.base.Schema
    options:
      show_root_heading: true
      show_source: true
      heading_level: 2

::: flycatcher.base.model_validator
    options:
      show_root_heading: true
      show_source: true
      heading_level: 2
