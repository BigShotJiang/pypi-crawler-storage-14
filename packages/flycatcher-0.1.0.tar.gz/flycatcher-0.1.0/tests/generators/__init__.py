"""Tests for generator modules."""
