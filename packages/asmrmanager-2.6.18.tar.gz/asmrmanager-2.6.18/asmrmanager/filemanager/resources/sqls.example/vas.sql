select * from voice_actor
order by random()
limit 20;