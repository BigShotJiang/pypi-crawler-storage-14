import contextlib
import json
import locale as locale_module
from datetime import date, datetime, time
from decimal import Decimal
from typing import Any

from .base import DataType
from .registry import registry


def _set_locale(locale: str | None) -> str | None:
    """Set locale temporarily and return the previous locale."""
    if locale is None:
        return None
    prev = locale_module.getlocale(locale_module.LC_ALL)
    try:
        # Convert "it-IT" format to "it_IT.UTF-8" format
        normalized = locale.replace("-", "_")
        if "." not in normalized:
            normalized = f"{normalized}.UTF-8"
        locale_module.setlocale(locale_module.LC_ALL, normalized)
    except locale_module.Error:
        # Fallback: try without UTF-8
        with contextlib.suppress(locale_module.Error):
            locale_module.setlocale(locale_module.LC_ALL, locale.replace("-", "_"))
    return prev[0] if prev[0] else None


def _restore_locale(prev: str | None) -> None:
    """Restore previous locale."""
    if prev is not None:
        try:
            locale_module.setlocale(locale_module.LC_ALL, prev)
        except locale_module.Error:
            locale_module.setlocale(locale_module.LC_ALL, "")


class IntType(DataType):
    """Integer type - whole numbers."""

    name = "int"
    code = "L"
    aliases = ["LONG", "LONGINT", "I", "INT", "INTEGER"]
    python_type = int
    js_type = "number"
    sql_type = "INTEGER"
    align = "R"
    empty = 0
    default_format = "%d"

    def parse(self, value: str) -> int:
        return int(value)

    def serialize(self, value: Any) -> str:
        return str(value)

    def _format_with_locale(self, value: Any, fmt: str, locale: str | None) -> str:
        prev = _set_locale(locale)
        try:
            return locale_module.format_string(fmt, value, grouping=True)
        finally:
            _restore_locale(prev)


class FloatType(DataType):
    """Floating point type - decimal numbers with limited precision."""

    name = "float"
    code = "R"
    aliases = ["REAL", "FLOAT", "F"]
    python_type = float
    js_type = "number"
    sql_type = "REAL"
    align = "R"
    empty = 0.0
    default_format = "%.2f"

    def parse(self, value: str) -> float:
        return float(value)

    def serialize(self, value: Any) -> str:
        return str(value)

    def _format_with_locale(self, value: Any, fmt: str, locale: str | None) -> str:
        prev = _set_locale(locale)
        try:
            return locale_module.format_string(fmt, value, grouping=True)
        finally:
            _restore_locale(prev)


class BoolType(DataType):
    """Boolean type - true/false values."""

    name = "bool"
    code = "B"
    aliases = ["boolean", "BOOL", "BOOLEAN"]
    python_type = bool
    js_type = "boolean"
    sql_type = "BOOLEAN"
    align = "L"
    empty = False

    def parse(self, value: str) -> bool:
        return value.lower() in ("true", "1", "yes", "t", "on", "y")

    def serialize(self, value: Any) -> str:
        return "true" if value else "false"


class StrType(DataType):
    """String/text type."""

    name = "str"
    code = "T"
    aliases = ["TEXT", "P", "A", "S", "STRING"]
    python_type = str
    js_type = "string"
    sql_type = "VARCHAR"
    align = "L"
    empty = ""

    def parse(self, value: str) -> str:
        return value

    def serialize(self, value: Any) -> str:
        return str(value)


class JsonType(DataType):
    """JSON type - serialized dict/list structures."""

    name = "json"
    code = "JS"
    aliases = ["JSON"]
    python_type = dict  # Primary type, also handles list
    js_type = "object"
    sql_type = "JSON"
    align = "L"
    empty = None

    def parse(self, value: str) -> Any:
        return json.loads(value)

    def serialize(self, value: Any) -> str:
        return json.dumps(value)


class DecimalType(DataType):
    """Decimal type - exact decimal numbers (for money, etc.)."""

    name = "decimal"
    code = "N"
    aliases = ["NUMERIC", "DECIMAL"]
    python_type = Decimal
    js_type = "number"  # JS has no native Decimal
    sql_type = "DECIMAL"
    align = "R"
    empty = Decimal("0")
    default_format = "%.2f"

    def parse(self, value: str) -> Decimal:
        return Decimal(value)

    def serialize(self, value: Any) -> str:
        return str(value)

    def _format_with_locale(self, value: Any, fmt: str, locale: str | None) -> str:
        prev = _set_locale(locale)
        try:
            return locale_module.format_string(fmt, float(value), grouping=True)
        finally:
            _restore_locale(prev)


class DateType(DataType):
    """Date type - calendar date without time."""

    name = "date"
    code = "D"
    aliases = ["DATE"]
    python_type = date
    js_type = "Date"
    sql_type = "DATE"
    align = "L"
    empty = None
    default_format = "%x"  # Locale's appropriate date representation

    def parse(self, value: str) -> date:
        return date.fromisoformat(value)

    def serialize(self, value: Any) -> str:
        return str(value.isoformat())

    def _format_with_locale(self, value: Any, fmt: str, locale: str | None) -> str:
        prev = _set_locale(locale)
        try:
            result: str = value.strftime(fmt)
            return result
        finally:
            _restore_locale(prev)


class DateTimeType(DataType):
    """DateTime type - date with time."""

    name = "datetime"
    code = "DH"
    aliases = ["DATETIME", "DT", "DHZ", "timestamp"]
    python_type = datetime
    js_type = "Date"
    sql_type = "TIMESTAMP"
    align = "L"
    empty = None
    default_format = "%c"  # Locale's appropriate date and time representation

    def parse(self, value: str) -> datetime:
        return datetime.fromisoformat(value)

    def serialize(self, value: Any) -> str:
        return str(value.isoformat())

    def _format_with_locale(self, value: Any, fmt: str, locale: str | None) -> str:
        prev = _set_locale(locale)
        try:
            result: str = value.strftime(fmt)
            return result
        finally:
            _restore_locale(prev)


class TimeType(DataType):
    """Time type - time of day without date."""

    name = "time"
    code = "H"
    aliases = ["TIME", "HZ"]
    python_type = time
    js_type = "Date"
    sql_type = "TIME"
    align = "L"
    empty = None
    default_format = "%X"  # Locale's appropriate time representation

    def parse(self, value: str) -> time:
        return time.fromisoformat(value)

    def serialize(self, value: Any) -> str:
        return str(value.isoformat())

    def _format_with_locale(self, value: Any, fmt: str, locale: str | None) -> str:
        prev = _set_locale(locale)
        try:
            result: str = value.strftime(fmt)
            return result
        finally:
            _restore_locale(prev)


# Register built-in types
def register_builtins() -> None:
    registry.register(IntType)
    registry.register(FloatType)
    registry.register(BoolType)
    registry.register(StrType)
    registry.register(JsonType)
    registry.register(DecimalType)
    registry.register(DateType)
    registry.register(DateTimeType)
    registry.register(TimeType)


register_builtins()
