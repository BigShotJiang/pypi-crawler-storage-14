"""Data quality control calculation and aggregation."""
