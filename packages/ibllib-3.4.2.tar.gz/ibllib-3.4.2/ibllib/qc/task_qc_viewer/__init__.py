"""Interactive task QC viewer."""
