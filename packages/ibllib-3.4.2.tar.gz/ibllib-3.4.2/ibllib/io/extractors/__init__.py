"""IBL rig data pre-processing functions.

Extractor classes for loading raw rig data and returning ALF compliant pre-processed data.
"""
