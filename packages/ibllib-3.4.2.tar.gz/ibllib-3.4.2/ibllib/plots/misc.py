#!/usr/bin/env python
# -*- coding:utf-8 -*-
import warnings
from ibllib.plots import *  # noqa: F403,F401
warnings.warn('This module is deprecated and will be removed in future versions', DeprecationWarning)
