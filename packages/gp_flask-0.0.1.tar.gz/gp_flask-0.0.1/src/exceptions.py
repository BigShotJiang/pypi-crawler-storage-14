class ServerStoreException(BaseException):
    def __init__(self, *args: object) -> None:
        super().__init__(*args)

class LoadStorageException(BaseException):
    def __init__(self, *args: object) -> None:
        super().__init__(*args)