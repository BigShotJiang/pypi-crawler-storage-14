"""
MFT-Flow AI 核心功能模块

提供 CSV 解析、性能分析、测试方案生成等核心功能
"""

import csv
import json
from pathlib import Path
from typing import Dict, List, Any, Optional
import pandas as pd
try:
    import yaml
except ImportError:
    yaml = None


class CSVPerformanceParser:
    """CSV 性能数据解析器"""
    
    def __init__(self, file_path: str):
        self.file_path = file_path
        self.data = None
        self.load_csv()
    
    def load_csv(self):
        """加载 CSV 文件数据"""
        try:
            self.data = pd.read_csv(self.file_path)
        except Exception as e:
            raise ValueError(f"CSV 文件加载失败: {e}")
    
    def analyze_performance(self, primitives_threshold: float = 1000000.0) -> Dict[str, Any]:
        """分析性能数据"""
        if self.data is None:
            return {"error": "数据未加载"}
        
        # 过滤数据
        filtered_data = self.data
        if "RHI/PrimitivesDrawn" in self.data.columns:
            filtered_data = self.data[self.data["RHI/PrimitivesDrawn"] > primitives_threshold]
        
        if len(filtered_data) == 0:
            return {
                "error": f"没有找到 RHI/PrimitivesDrawn > {primitives_threshold} 的数据",
                "total_rows": len(self.data),
                "filtered_rows": 0
            }
        
        # 计算基础指标
        result = {
            "file_info": {
                "file_path": self.file_path,
                "total_rows": len(self.data),
                "filtered_rows": len(filtered_data),
                "primitives_threshold": primitives_threshold
            },
            "performance_metrics": {}
        }
        
        # 计算各列的平均值
        for column in filtered_data.columns:
            if pd.api.types.is_numeric_dtype(filtered_data[column]):
                avg_value = filtered_data[column].mean()
                max_value = filtered_data[column].max()
                
                result["performance_metrics"][column] = {
                    "average": round(float(avg_value), 2),
                    "peak": round(float(max_value), 2)
                }
        
        return result


class TestPlanGenerator:
    """测试方案生成器"""
    
    def __init__(self, config_path: Optional[str] = None):
        self.config = self.load_config(config_path)
    
    def load_config(self, config_path: Optional[str]) -> Dict[str, Any]:
        """加载配置文件"""
        if config_path and Path(config_path).exists():
            with open(config_path, 'r', encoding='utf-8') as f:
                return yaml.safe_load(f)
        
        # 默认配置
        return {
            "performance_standards": {
                "fps": {"min": 60, "target": 120},
                "memory": {"max": 8000},
                "cpu": {"max": 80}
            },
            "test_scenarios": ["局内", "局外", "加载", "战斗"]
        }
    
    def generate_plan(self, tapd_url: str, version: str = None) -> Dict[str, Any]:
        """生成测试方案"""
        return {
            "tapd_url": tapd_url,
            "version": version or "未指定",
            "test_scenarios": self.config.get("test_scenarios", []),
            "performance_standards": self.config.get("performance_standards", {}),
            "test_cases": self._generate_test_cases(),
            "tools": ["CSV Profiler", "APM", "Insight"]
        }
    
    def _generate_test_cases(self) -> List[Dict[str, Any]]:
        """生成测试用例"""
        return [
            {
                "id": f"TC-{i+1:03d}",
                "name": f"场景{i+1}性能测试",
                "priority": "P0",
                "steps": [
                    "启动游戏",
                    "进入测试场景",
                    "执行性能测试",
                    "收集数据"
                ]
            }
            for i in range(5)
        ]


class ReportGenerator:
    """报告生成器"""
    
    def generate_performance_report(self, analysis_result: Dict[str, Any]) -> str:
        """生成性能报告"""
        if "error" in analysis_result:
            return f"错误: {analysis_result['error']}"
        
        report = "# 性能测试报告\n\n"
        
        # 文件信息
        file_info = analysis_result.get("file_info", {})
        report += f"## 文件信息\n"
        report += f"- 文件路径: {file_info.get('file_path', 'N/A')}\n"
        report += f"- 总行数: {file_info.get('total_rows', 0)}\n"
        report += f"- 过滤后行数: {file_info.get('filtered_rows', 0)}\n"
        report += f"- Primitives 阈值: {file_info.get('primitives_threshold', 0)}\n\n"
        
        # 性能指标
        metrics = analysis_result.get("performance_metrics", {})
        report += "## 性能指标\n\n"
        
        for metric, values in metrics.items():
            report += f"### {metric}\n"
            report += f"- 平均值: {values.get('average', 'N/A')}\n"
            report += f"- 峰值: {values.get('peak', 'N/A')}\n\n"
        
        return report
    
    def generate_test_conclusion(self, test_data: Dict[str, Any]) -> str:
        """生成测试结论"""
        conclusion = "# 测试结论\n\n"
        
        conclusion += f"## 测试版本\n{test_data.get('version', '未指定')}\n\n"
        conclusion += f"## 测试场景\n{', '.join(test_data.get('test_scenarios', []))}\n\n"
        conclusion += "## 测试结果\n\n"
        
        # 这里可以根据实际测试数据生成结论
        conclusion += "### 性能表现\n"
        conclusion += "- 帧率: 符合预期\n"
        conclusion += "- 内存使用: 正常范围\n"
        conclusion += "- CPU 使用率: 正常\n\n"
        
        conclusion += "### 问题发现\n"
        conclusion += "- 无重大问题\n\n"
        
        conclusion += "### 建议\n"
        conclusion += "- 建议持续监控性能表现\n"
        
        return conclusion


def parse_csv_file(file_path: str, **kwargs) -> Dict[str, Any]:
    """解析 CSV 文件的便捷函数"""
    parser = CSVPerformanceParser(file_path)
    return parser.analyze_performance(**kwargs)


def generate_test_plan(tapd_url: str, version: str = None, config_path: str = None) -> Dict[str, Any]:
    """生成测试方案的便捷函数"""
    generator = TestPlanGenerator(config_path)
    return generator.generate_plan(tapd_url, version)


def generate_report(analysis_result: Dict[str, Any]) -> str:
    """生成报告的便捷函数"""
    generator = ReportGenerator()
    return generator.generate_performance_report(analysis_result)