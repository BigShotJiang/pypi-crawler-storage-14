"""
MFT-Flow AI: 借助AI，覆盖从需求分析、测试方案输出、测试数据分析到测试结论输出的一整套完整测试流程

这是一个完整的测试流程自动化工具，集成了多个 MCP 服务：
- TAPD MCP：获取需求信息
- CSV Parser MCP：解析性能数据
- iWiki MCP：文档生成和管理
- Sequential Thinking MCP：深度思考和分析

主要功能：
1. 需求分析：从 TAPD 获取需求并分析
2. 测试方案生成：基于模板生成测试方案
3. 性能数据分析：解析 CSV 性能数据
4. 测试结论输出：生成标准化测试报告
5. 文档管理：自动创建和更新 iWiki 文档
"""

__version__ = "0.1.0"
__author__ = "Tencent MFT Team"
__email__ = "mft-team@tencent.com"

from .cli import main

__all__ = ["main"]