"""
MFT-Flow AI 命令行接口

提供包的入口点和基本功能，包括：
- 启动 MCP 服务
- 配置管理
- 测试流程执行
"""

import click
import sys
import os
from pathlib import Path


@click.group()
@click.version_option()
def main():
    """MFT-Flow AI: 完整的测试流程自动化工具"""
    pass


@main.command()
@click.option("--port", default=8000, help="MCP 服务端口")
def start_server(port):
    """启动 CSV Parser MCP 服务"""
    try:
        from data_parser.data_parser import main as parser_main
        click.echo(f"启动 CSV Parser MCP 服务，端口: {port}")
        parser_main()
    except ImportError:
        click.echo("错误: 无法导入 data_parser 模块")
        sys.exit(1)


@main.command()
@click.argument("tapd_url")
@click.option("--version", default=None, help="测试版本")
@click.option("--output", default=None, help="输出文件路径")
def generate_test_plan(tapd_url, version, output):
    """根据 TAPD 需求生成测试方案"""
    click.echo(f"正在分析 TAPD 需求: {tapd_url}")
    click.echo(f"测试版本: {version or '未指定'}")
    
    # 这里可以调用实际的测试方案生成逻辑
    if output:
        click.echo(f"输出到: {output}")
    else:
        click.echo("测试方案生成完成")


@main.command()
@click.argument("csv_file")
@click.option("--threshold", default=1000000.0, help="Primitives 阈值")
def analyze_performance(csv_file, threshold):
    """分析 CSV 性能数据"""
    if not Path(csv_file).exists():
        click.echo(f"错误: 文件不存在: {csv_file}")
        sys.exit(1)
    
    click.echo(f"正在分析性能数据: {csv_file}")
    click.echo(f"Primitives 阈值: {threshold}")
    
    # 这里可以调用实际的性能分析逻辑
    click.echo("性能分析完成")


@main.command()
@click.argument("wiki_page_id")
@click.option("--title", default=None, help="文档标题")
@click.option("--content", default=None, help="文档内容文件路径")
def create_document(wiki_page_id, title, content):
    """创建 iWiki 文档"""
    click.echo(f"正在创建 iWiki 文档，页面ID: {wiki_page_id}")
    click.echo(f"标题: {title or '未指定'}")
    
    if content and Path(content).exists():
        click.echo(f"内容文件: {content}")
    
    click.echo("文档创建完成")


if __name__ == "__main__":
    main()