#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
MFT-Flow AI 打包配置

支持 pip install 安装的 setup.py 文件
"""

from setuptools import setup, find_packages
import os

# 读取 README.md 作为长描述
try:
    with open("README.md", "r", encoding="utf-8") as fh:
        long_description = fh.read()
except FileNotFoundError:
    long_description = "MFT-Flow AI: 借助AI，覆盖从需求分析、测试方案输出、测试数据分析到测试结论输出的一整套完整测试流程"

# 定义依赖项（与 pyproject.toml 保持一致）
requirements = [
    "mcp>=1.22.0",
    "fastmcp>=2.13.1",
    "numpy>=1.24.0",
    "pandas>=2.0.0",
    "PyYAML>=6.0",
    "requests>=2.25.0",
    "click>=8.0.0",
]

setup(
    name="mft-flow-ai",
    version="0.1.0",
    author="Tencent MFT Team",
    author_email="mft-team@tencent.com",
    description="MFT-Flow AI: 借助AI，覆盖从需求分析、测试方案输出、测试数据分析到测试结论输出的一整套完整测试流程",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://iwiki.woa.com/p/4016470628",
    packages=find_packages(where="src"),
    package_dir={"": "src"},
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "Topic :: Software Development :: Testing",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
    ],
    python_requires=">=3.10",
    install_requires=requirements,
    entry_points={
        "console_scripts": [
            "mft-flow-ai=mft_flow_ai.cli:main",
        ],
    },
    include_package_data=True,
    zip_safe=False,
)