# mft-flow-ai 借助AI，覆盖从需求分析、测试方案输出、测试数据分析到测试结论输出的一整套完整测试流程

```mermaid
graph TB
    Start([开始测试流程]) --> Step1[需求分析]
    
    subgraph Step1[需求分析阶段]
        A1[TAPD MCP<br/>获取需求内容] --> A2[Knot 知识库<br/>获取测试标准/模板/背景]
        A2 --> A3[AI 发散归纳总结<br/>形成测试需求]
    end
    
    Step1 --> Step2[测试用例输出]
    
    subgraph Step2[测试用例生成阶段]
        B1[基于需求分析结果] --> B2[结合测试模板]
        B2 --> B3[生成测试用例]
    end
    
    Step2 --> Step3[测试数据分析]
    
    subgraph Step3[测试数据分析阶段]
        C1[接收原始测试数据] --> C2{数据类型判断}
        C2 -->|CSV 性能数据| C3[CSV Parser MCP<br/>解析性能数据]
        C2 -->|PerfDog 数据| C4[PerfDog Parser MCP<br/>解析性能数据]
        C2 -->|其他数据| C5[其他 Parser MCP]
        C3 --> C6[输出标准化结果]
        C4 --> C6
        C5 --> C6
        C6 --> C7[标识核心问题点]
    end
    
    Step3 --> Step4[测试结论输出]
    
    subgraph Step4[测试结论生成阶段]
        D1[获取 Knot 测试结论模板] --> D2[填充测试数据]
        D2 --> D3[生成简明测试结论]
    end
    
    Step4 --> Step5[iWiki 文档生成]
    
    subgraph Step5[文档输出阶段]
        E1[整合所有内容] --> E2[生成 iWiki 文档]
        E2 --> E3[自动创建/更新文档]
        E3 --> E4[文档存档完成]
    end
    
    Step5 --> End([流程结束])
    
    %% 样式定义 - 白底/黑底通用配色
    classDef mcpStyle fill:#1976D2,stroke:#0D47A1,color:#fff,stroke-width:2px
    classDef knowledgeStyle fill:#388E3C,stroke:#1B5E20,color:#fff,stroke-width:2px
    classDef analysisStyle fill:#F57C00,stroke:#E65100,color:#fff,stroke-width:2px
    classDef outputStyle fill:#7B1FA2,stroke:#4A148C,color:#fff,stroke-width:2px
    classDef decisionStyle fill:#D32F2F,stroke:#B71C1C,color:#fff,stroke-width:2px
    
    class A1,C3,C4,C5 mcpStyle
    class A2,D1 knowledgeStyle
    class A3,B3,C7,D3 analysisStyle
    class E2,E3,E4 outputStyle
    class C2 decisionStyle
```


---

## 重要说明

### Python 版本要求

- **Python 3.10 及以上**
- 推荐下载地址：[Python 3.10.11](https://www.python.org/downloads/release/python-31011/)

---

## 安装

### 1. 下载工程

```bash
pip install -U mft-flow-ai --extra-index-url=https://${user}:${token}@mirrors.tencent.com/repository/pypi/tencent_pypi/simple
```

**参数说明：**
- `${user}`：你的腾讯工蜂用户名
- `${token}`：你的访问令牌

**获取 user 和 token：**
访问 [腾讯软件源平台](https://mirrors.tencent.com/#/private/pypi) 查看你的用户名和令牌。

### 2. 安装依赖包

```bash
pip install -U mft-ue4-csvprofile-parser --extra-index-url=https://${user}:${token}@mirrors.tencent.com/repository/pypi/tencent_pypi/simple
```

### 3. 安装其他依赖

```bash
pip install -r requirements.txt
```

---

## 如何实际发挥作用

### 1. 工具本身
**核心是知识库持续建设（如 Knot）增强 LLM 推理能力**，使其能达到专业测试同学的表达和分析能力。

- **知识库建设**：持续积累测试标准、测试模板、历史案例、最佳实践等内容
- **推理能力增强**：通过结构化知识和上下文学习，提升 AI 的专业测试能力
- **专业表达**：使 AI 输出符合团队规范和专业标准的测试文档

### 2. 团队使用
**在实际使用中去发现并提高可用性**。

- **实践反馈**：在真实测试场景中使用，收集问题和改进建议
- **持续优化**：根据团队反馈不断调整工具配置和知识库内容
- **经验沉淀**：将团队的测试经验和方法论固化到知识库中

### 3. 最新关于如何提问/沟通/模板/背景均存放在该路径，具体可看
https://iwiki.woa.com/p/4016470628

---

## Tools

本 MCP 服务集成以下工具：

### 1. TAPD MCP（必须）

**功能：** 集成腾讯 TAPD 需求缺陷管理平台，用于获取需求、任务、缺陷等信息

**主要能力：**
- 获取用户参与的项目列表
- 查询需求（Story）、任务（Task）、缺陷（Bug）
- 获取用户待办事项
- 查询迭代信息
- 获取字段配置信息

**使用场景：**
- 需求分析阶段：从 TAPD 获取需求详情
- 测试用例生成：基于需求内容生成测试用例
- 缺陷跟踪：查询和分析缺陷信息

### 2. csv_parser（若涉及到csv profiler数据解析，则必须）

**功能：** 解析 UE4/UE5 性能分析 CSV 文件，输出性能指标数据

**参数：**

| 参数名 | 类型 | 必填 | 默认值 | 说明 |
|--------|------|------|--------|------|
| `file_path` | string | 是 | - | CSV 文件的完整路径 |
| `primitives_threshold` | float | 否 | 1000000.0 | RHI/PrimitivesDrawn 过滤阈值 |

**返回数据：**

```json
{
  "file_info": {
    "file_path": "文件路径",
    "total_rows": 28078,
    "primitives_threshold": 1000000.0
  },
  "performance_metrics": {
    "fps": {
      "avg_fps": 41.82,
      "one_percent_low_fps": 7.68,
      "stutter_percentage": 1.12,
      "fps_38_percentage": 0.4724,
      "fps_48_percentage": 0.3592,
      "fps_58_percentage": 0.2891,
      "fps_68_percentage": 0.1997,
      "fps_100_percentage": 0.0523
    },
    "timing": {
      "avg_frametime_ms": 23.91,
      "avg_gamethreadtime_ms": 15.32,
      "avg_renderthreadtime_ms": 18.45,
      "avg_rhithreadtime_ms": 12.67,
      "avg_gputime_ms": 20.12
    },
    "rendering": {
      "avg_rhidrawcalls": 1494.23,
      "avg_rhiprimitivesdrawn": 3190394.56
    },
    "memory": {
      "avg_memory_mb": 6455.12,
      "peak_memory_mb": 7539.45,
      "avg_usedvideomemory_mb": 4945.67,
      "peak_usedvideomemory_mb": 5899.23
    },
    "file_io": {
      "read": {
        "avg_transfer_mb": 11731.45,
        "peak_transfer_mb": 21067.89,
        "avg_operation_count": 234.56,
        "peak_operation_count": 456.78
      },
      "write": {
        "avg_transfer_mb": 124.23,
        "peak_transfer_mb": 153.45,
        "avg_operation_count": 12.34,
        "peak_operation_count": 23.45
      }
    }
  }
}
```

### 3. iWiki MCP（若iwiki未在Knot中或者无法精准找到，则建议使用）

**功能：** 集成腾讯 iWiki 文档平台，用于文档的读取、创建和管理

**主要能力：**
- 搜索和获取 iWiki 文档内容
- 创建和更新文档
- 获取文档元数据和目录树
- 添加文档标签和评论
- 获取文档引用关系

**使用场景：**
- 知识库检索：从 Knot 获取测试标准、模板、背景知识
- 文档生成：自动创建测试报告和结论文档
- 文档存档：将测试结果归档到 iWiki

### 4. sequential-thinking（非必须，建议使用）

**功能：** 提供深度思考和问题分解能力，支持复杂问题的逐步推理

**主要能力：**
- 多步骤思考和推理
- 问题分解和分析
- 假设验证和迭代
- 思维链（Chain of Thought）生成

**使用场景：**
- 需求分析：深度理解和分解复杂需求
- 测试方案设计：逐步推导测试策略
- 问题诊断：分析性能问题根因

### 5. mcp-feedback-enhanced（非必须，建议使用）

**功能：** 提供交互式反馈机制，支持用户在任务执行过程中实时反馈和调整

**主要能力：**
- 阶段性任务确认
- 用户反馈收集
- 任务流程调整
- 交互式对话管理

**使用场景：**
- 测试流程确认：在关键节点获取用户反馈
- 方案调整：根据用户意见优化测试方案
- 结果验证：确认测试结论是否符合预期

---

## Windows 运行 MCP Server

### 启动服务

```powershell
C:\Users\username> powershell
PS C:\Users\username> python data_parser/data_parser.py --port 8000
```

**或者后台运行：**

```powershell
PS C:\Users\username> Start-Process -FilePath "python" -ArgumentList "data_parser/data_parser.py --port 8000" -WindowStyle Hidden
```

### 配置 mcp.json

在你的 MCP 客户端配置文件中添加mcp-feedback-enhanced、sequential-thinking、iWiki、csv-parser（针对需要解析UE的csv profiler数据的）：

```json
{
	"mcpServers":{
		"mcp-feedback-enhanced":{
			"command":"uvx",
			"args":[
				"mcp-feedback-enhanced@latest"
			],
			"timeout":600,
			"env":{
				"MCP_DESKTOP_MODE":"true",
				"MCP_WEB_PORT":"8765",
				"MCP_DEBUG":"false"
			},
			"autoApprove":[
				"interactive_feedback"
			]
		},
		"sequential-thinking":{
			"command":"npx",
			"args":[
				"-y",
				"@modelcontextprotocol/server-sequential-thinking"
			]
		},
 	  "iWiki": {
     	 "command": "npx",
     	 "args": [
       		 "-y",
        	"mcp-remote@latest",
        	"https://pre1.mcp.it.woa.com/app_iwiki_mcp/mcp3"      ],
     	 "disabled": false
 		 },
		"csv-parser":{
			"url":"http://127.0.0.1:8000/mcp",
			"transportType":"streamable-http",
			"disabled":false
		}
	}
}
```

### 停止 MCP Server

```powershell
C:\Users\username> powershell
PS C:\Users\username> Get-Process -Name "python" | Where-Object {$_.CommandLine -like "*data_parser.py*"}
PS C:\Users\username> Stop-Process -Id <进程ID> -Force
```


### 配置 User Rules(增加以下配置可以助于更有效/准确识别)

## 读取Knot中iwiki文档规则
- 【必须】识别规则：文档名称以【仅参考】开头的文档为参考文档
## CSV 数据解析规则
### 工具优先级
- 【必须】当用户要求解析 CSV 文件、分析性能数据、处理 Profile 数据时，**优先使用 `csv-parser` MCP 工具**
- 【必须】只有在 MCP 工具不可用或失败时，才考虑使用其他方法（如直接读取文件）
### 触发关键词
以下关键词应触发使用 `csv-parser` 工具：
- "解析 CSV"、"分析 CSV"、"处理 CSV"
- "Profile 数据"、"性能数据"、"性能分析"
- "UE4 性能"、"虚幻引擎性能"
- "帧率分析"、"FPS 分析"
### 工作流程
1. 识别用户请求中的 CSV 解析需求
2. 优先调用 `csv-parser` MCP 工具
3. 解析返回的 JSON 数据
4. 生成易读的表格和 mermaid 图表
5. 提供性能分析和优化建议
### 示例场景
**用户说**："帮我解析这份 CSV 数据"  
**应该做**：首先使用 `csv-parser` MCP 工具，而不是直接读取文件
- 【必须】跳过内容：不读取参考文档的具体内容
- 【必须】跳过子树：不读取参考文档下的任何层级的子文档
- 【必须】完全忽略：参考文档及其子文档树应被完全忽略，不纳入分析范围

