"""
Data Generator Library - A tool for generating synthetic data
"""

from .data_gen import DataGen

__version__ = "0.1.0"
__all__ = ["DataGen"]
