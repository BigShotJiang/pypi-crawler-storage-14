
from django.utils.translation import gettext_lazy as _

  
def find_least_price(prices: list, key_name: str = None) -> float:

    if not prices:
        raise ValueError("Input array of prices cannot be empty.")

    if key_name:
        # If a key is provided, we tell min() to use that key for comparison.
        # It uses a lambda function to extract the value for the key_name 
        # from each dictionary item.
        return min(prices, key=lambda item: item.get(key_name, float('inf')))
    else:
        # If no key is provided, assume the list contains simple numbers.
        return min(prices)