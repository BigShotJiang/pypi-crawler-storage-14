package_name = 'osbot_fast_api_serverless'
path=__path__[0]