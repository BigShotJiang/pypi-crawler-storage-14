# veriskgo/llm.py
import time
import traceback
import functools
import inspect
from typing import Any, Dict
from typing import Optional
from veriskgo.trace_manager import TraceManager
from veriskgo.trace_manager import serialize_value


def normalize_bedrock_usage(response: dict) -> Dict[str, int]:
    """Normalize Bedrock token usage."""
    usage = response.get("usage", {})

    input_tokens = usage.get("inputTokens", 0)
    output_tokens = usage.get("outputTokens", 0)

    return {
        "input": input_tokens,
        "output": output_tokens,
        "total": input_tokens + output_tokens,
    }


def extract_bedrock_text(response: dict) -> str:
    """Extract text from Bedrock response."""
    try:
        return response["output"]["message"]["content"][0]["text"]
    except Exception:
        return ""

# ============================================================
# Decorator: track_llm_call (Generation Span)
# ============================================================

def track_llm_call(name=None, tags=None):
    """
    Proper Langfuse-compatible LLM span generator.
    Marks span type = 'generation'
    """

    def decorator(func):
        span_name = name or func.__name__

        def parse_bedrock_response(resp):
            """Extract normalized fields."""
            text = resp["output"]["message"]["content"][0]["text"]

            # usage tokens
            usage = resp.get("usage", {})
            input_tokens = usage.get("inputTokens", 0)
            output_tokens = usage.get("outputTokens", 0)
            total_tokens = input_tokens + output_tokens

            # simple cost calc
            input_cost = input_tokens * 0.0000015
            output_cost = output_tokens * 0.000005

            return {
                "text": text,
                "usage_details": {
                    "input": input_tokens,
                    "output": output_tokens,
                    "total": total_tokens,
                },
                "cost_details": {
                    "input": round(input_cost, 6),
                    "output": round(output_cost, 6),
                    "total": round(input_cost + output_cost, 6),
                },
            }

        def wrapper(*args, **kwargs):

            # manually force span type = generation
            span_id = TraceManager.start_span(
                span_name,
                input_data={"prompt": args[0], "tags": tags},
                tags=tags,
            )

            # FIX: change span type at top level
            for sp in TraceManager._active["spans"]:
                if sp["span_id"] == span_id:
                    sp["type"] = "generation"

            start = time.time()

            try:
                resp = func(*args, **kwargs)
                latency = int((time.time() - start) * 1000)

                parsed = parse_bedrock_response(resp)

                # -------------------------
                # FIX: Insert Langfuse-compatible usage/cost fields
                # -------------------------
                TraceManager.end_span(
                    span_id,
                    {
                        "status": "success",
                        "model": resp.get("model"),
                        "latency_ms": latency,
                        "input": {
                            "prompt": args[0],
                            "model": resp.get("model"),
                            "messages": resp.get("messages"),
                        },
                        "output": {
                            "text": parsed["text"],
                            "finish_reason": "stop",
                        },

                        # OLD (kept so nothing breaks)
                        "usage_details": parsed["usage_details"],
                        "cost_details": parsed["cost_details"],

                        # NEW (Langfuse dashboard will now show tokens & cost)
                        "usage": {
                            "input_tokens": parsed["usage_details"]["input"],
                            "output_tokens": parsed["usage_details"]["output"],
                            "total_tokens": parsed["usage_details"]["total"],
                        },
                        "cost": {
                            "input_cost": parsed["cost_details"]["input"],
                            "output_cost": parsed["cost_details"]["output"],
                            "total_cost": parsed["cost_details"]["total"],
                        },
                    },
                )
                return parsed

            except Exception as e:
                latency = int((time.time() - start) * 1000)
                TraceManager.end_span(
                    span_id,
                    {
                        "status": "error",
                        "error": str(e),
                        "stacktrace": traceback.format_exc(),
                        "latency_ms": latency,
                    },
                )
                raise

        return functools.wraps(func)(wrapper)

    return decorator


# ============================================================
# Helper for LLM Response Processing
# ============================================================

def _process_llm_response(prompt: str, response: Dict[str, Any], latency_ms: int):
    """
    Converts Bedrock response → Langfuse-compliant `generation` span format.
    """

    # Extract output text
    try:
        text = response["output"]["message"]["content"][0]["text"]
    except Exception:
        text = ""

    # Extract usage
    usage = response.get("usage", {})
    input_tokens = usage.get("inputTokens", 0)
    output_tokens = usage.get("outputTokens", 0)
    total_tokens = input_tokens + output_tokens

    # Optional cost calculation
    input_cost = input_tokens * 0.0000015
    output_cost = output_tokens * 0.000005
    total_cost = input_cost + output_cost

    model = response.get("model", "unknown")

    return {
        "status": "success",
        "type": "generation",
        "latency_ms": latency_ms,
        "input": {
            "prompt": prompt,
            "model": model,
            "messages": [
                {"role": "user", "content": prompt}
            ],
        },
        "output": {
            "text": text,
            "finish_reason": "stop"
        },

        # Keep old fields
        "usage_details": {
            "input": input_tokens,
            "output": output_tokens,
            "total": total_tokens,
        },
        "cost_details": {
            "input": round(input_cost, 6),
            "output": round(output_cost, 6),
            "total": round(total_cost, 6),
        },

        # NEW fields Langfuse UI expects
        "usage": {
            "input_tokens": input_tokens,
            "output_tokens": output_tokens,
            "total_tokens": total_tokens,
        },
        "cost": {
            "input_cost": round(input_cost, 6),
            "output_cost": round(output_cost, 6),
            "total_cost": round(total_cost, 6),
        },

        "raw_response": serialize_value(response),
    }
