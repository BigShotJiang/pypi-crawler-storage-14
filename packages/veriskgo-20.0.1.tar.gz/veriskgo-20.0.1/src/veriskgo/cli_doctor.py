# veriskgo/cli_doctor.py

import os
import boto3
import json
import tempfile
import requests
import importlib.metadata
from veriskgo.sqs import _sqs_instance
from veriskgo.config import get_cfg 

def check_python():
    import sys
    version = sys.version.split(" ")[0]
    return True, version if sys.version_info >= (3, 8) else "Python < 3.8 not supported"


def check_veriskgo_installed():
    try:
        version = importlib.metadata.version("veriskgo")
        return True, version
    except Exception:
        return False, "veriskgo package not installed properly"


def check_aws_credentials():
    try:
        sts = boto3.client("sts")
        ident = sts.get_caller_identity()
        return True, f"UserID={ident['UserId']}"
    except Exception as e:
        return False, str(e)


def check_sqs_connectivity():
    try:
        client = _sqs_instance.client
        url = _sqs_instance.queue_url

        if not client:
            return False, "SQS client not initialized"

        client.get_queue_attributes(
            QueueUrl=url,
            AttributeNames=["QueueArn"]
        )
        return True, f"Connected → {url}"

    except Exception as e:
        return False, str(e)


def check_spillover_path():
    try:
        path = os.path.join(tempfile.gettempdir(), "veriskgo_spillover_test.txt")
        with open(path, "w") as f:
            f.write("ok")
        os.remove(path)
        return True, tempfile.gettempdir()
    except Exception as e:
        return False, str(e)
 

def print_status(label, ok, msg):
    icon = "✔" if ok else "✖"
    print(f"{icon} {label}: {msg}")


def main():
    print("\n🔍 VeriskGO Doctor — System Health Check\n")

    checks = [
        ("Python version", check_python),
        ("veriskgo installed", check_veriskgo_installed),
        ("AWS Credentials", check_aws_credentials),
        ("SQS Connectivity", check_sqs_connectivity),
        ("Spillover path", check_spillover_path), 
    ]

    all_ok = True
    for label, fn in checks:
        ok, msg = fn()
        print_status(label, ok, msg)
        if not ok:
            all_ok = False

    if all_ok:
        print("\n🎉 Everything looks good! VeriskGO is ready to run.\n")
    else:
        print("\n⚠ There are issues detected above. Please fix them before using VeriskGO.\n")
