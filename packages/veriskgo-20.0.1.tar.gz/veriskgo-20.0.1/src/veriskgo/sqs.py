# src/veriskgo/sqs.py

import json
import boto3
import queue
import threading
import time
import os
from typing import Optional, Dict, Any
from .config import get_cfg


SPILLOVER_FILE = "/tmp/veriskgo_spillover_queue.jsonl"


class _VeriskGoSQS:
    """
    PRODUCTION-GRADE SQS SENDER (NO AIObotocore)
    ==================================================
    Features:
    - ZERO message loss (RAM queue + spillover file)
    - Multiple worker threads for throughput
    - Crash-proof worker auto-restart
    - Batch sending (10 msgs)
    - Full retry system
    - Backwards compatible
    """

    def __init__(self):
        self.client: Optional[Any] = None
        self.queue_url: Optional[str] = None
        self.sqs_enabled = False
        self._init_once = False

        # UNBOUNDED queue → NO DROPS
        self._q: queue.Queue = queue.Queue(maxsize=0)

        # load spillover file on startup (if exists)
        self._load_spillover()

        # Start N worker threads (high throughput)
        self.worker_count = 4
        for i in range(self.worker_count):
            t = threading.Thread(
                target=self._safe_worker_loop,
                daemon=True
            )
            t.start()

        # AWS init
        self._auto_initialize()

    # -------------------------------------------------------
    # SPILLOVER SAVE / LOAD
    # -------------------------------------------------------
    def _spillover_save(self, message: Dict[str, Any]):
        """Save dropped messages to disk to guarantee durability."""
        try:
            with open(SPILLOVER_FILE, "a") as f:
                f.write(json.dumps(message) + "\n")
        except Exception as e:
            print("[veriskgo] Spillover save failed:", e)

    def _load_spillover(self):
        """Load leftover messages from previous crash run."""
        if not os.path.exists(SPILLOVER_FILE):
            return

        try:
            print("[veriskgo] Restoring spillover queue from disk...")

            with open(SPILLOVER_FILE, "r") as f:
                for line in f:
                    msg = json.loads(line.strip())
                    self._q.put(msg)

            os.remove(SPILLOVER_FILE)
            print("[veriskgo] Spillover restored.")

        except Exception as e:
            print("[veriskgo] Spillover load failed:", e)

    # -------------------------------------------------------
    # SAFE WORKER LOOP (AUTO-RESTART)
    # -------------------------------------------------------
    def _safe_worker_loop(self):
        while True:
            try:
                self._worker_loop()
            except Exception as e:
                print("[veriskgo] Worker crashed:", e)
                time.sleep(1)
                print("[veriskgo] Restarting worker...")

    # -------------------------------------------------------
    # ACTUAL WORKER LOOP
    # -------------------------------------------------------
    def _worker_loop(self):
        batch = []

        while True:
            try:
                msg = self._q.get(timeout=0.2)
                batch.append(msg)
            except queue.Empty:
                pass

            flush_size = len(batch) >= 10
            flush_time = batch and (time.time() % 1 < 0.25)

            if flush_size or flush_time:
                self._send_batch(batch)
                batch = []

    # -------------------------------------------------------
    # AWS SETUP
    # -------------------------------------------------------
    def _auto_initialize(self):
        if self._init_once and self.client:
            return

        cfg = get_cfg()
        self.queue_url = cfg.get("aws_sqs_url")

        if not self.queue_url:
            print("[veriskgo] No SQS URL → disabled.")
            return

        try:
            session = boto3.Session(
                profile_name=cfg.get("aws_profile"),
                region_name=cfg.get("aws_region", "us-east-1")
            )
            self.client = session.client("sqs")
            self.client.get_queue_attributes(
                QueueUrl=self.queue_url,
                AttributeNames=["QueueArn"]
            )
            self.sqs_enabled = True
            print(f"[veriskgo] SQS connected → {self.queue_url}")

        except Exception as e:
            print("[veriskgo] SQS init failed:", e)
            self.client = None
            self.sqs_enabled = False

        self._init_once = True

    # -------------------------------------------------------
    # PUBLIC SEND (NEVER BLOCKS, NEVER DROPS)
    # -------------------------------------------------------
    def send(self, message: Optional[Dict[str, Any]]) -> bool:
        if not message:
            return False

        try:
            self._q.put_nowait(message)  # never fails (unbounded)
            return True
        except Exception as e:
            print("[veriskgo] RAM queue unexpectedly failed:", e)
            self._spillover_save(message)
            return False

    # -------------------------------------------------------
    # SEND BATCH (WITH RETRY)
    # -------------------------------------------------------
    def _send_batch(self, batch):
        if not batch:
            return

        # ensure AWS client
        if not self.client or not self.sqs_enabled:
            self._auto_initialize()

        if not self.client or not self.sqs_enabled:
            print("[veriskgo] SQS unavailable → writing to spillover.")
            for msg in batch:
                self._spillover_save(msg)
            return

        entries = [{
            "Id": str(i),
            "MessageBody": json.dumps(msg)
        } for i, msg in enumerate(batch[:10])]

        try:
            self.client.send_message_batch(
                QueueUrl=self.queue_url,
                Entries=entries
            )
            print(f"[veriskgo] Batch sent ({len(entries)} items)")

        except Exception as e:
            print("[veriskgo] Batch send failed:", e)
            self._retry_individual(batch)

    # -------------------------------------------------------
    # FALLBACK RETRY FOR EACH MESSAGE
    # -------------------------------------------------------
    def _retry_individual(self, batch):
        # Ensure client exists
        if not self.client or not self.sqs_enabled:
            self._auto_initialize()

        # If still None → spillover and stop
        if not self.client:
            print("[veriskgo] Client still None → spillover all messages.")
            for msg in batch:
                self._spillover_save(msg)
            return

        client = self.client  # <-- Pylance now knows this is NOT None

        for msg in batch:
            try:
                client.send_message(
                    QueueUrl=self.queue_url,
                    MessageBody=json.dumps(msg)
                )
                print("[veriskgo] Single retry OK")
            except Exception as e:
                print("[veriskgo] Single retry FAILED:", e)
                self._spillover_save(msg)



# -------------------------------------------------------
# SINGLETON INSTANCE
# -------------------------------------------------------
_sqs_instance = _VeriskGoSQS()

def send_to_sqs(bundle: Optional[Dict[str, Any]]):
    return _sqs_instance.send(bundle)

def init_sqs() -> bool:
    return _sqs_instance.sqs_enabled
