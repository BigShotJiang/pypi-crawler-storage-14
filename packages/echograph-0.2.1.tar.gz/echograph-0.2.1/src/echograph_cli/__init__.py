"""EchoGraph CLI - Context Engineering for Claude Code."""

__version__ = "0.2.1"
