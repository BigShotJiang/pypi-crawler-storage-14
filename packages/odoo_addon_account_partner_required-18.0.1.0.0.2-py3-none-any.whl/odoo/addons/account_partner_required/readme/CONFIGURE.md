To configure this module, you need to:

1.  Go to the menu *Invoicing \> Configuration \> Accounting \> Chart of Accounts* and edit each account to configure the correct *Partner
    policy*.
