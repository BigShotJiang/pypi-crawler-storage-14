If you put a partner on an account move line with an account whose type
is configured with *Partner policy* = *never*, you will get an error
message.

If you don't put a partner on an account move line with an account whose
type is configured with *Partner policy* = *always*, you will get an
error message.
