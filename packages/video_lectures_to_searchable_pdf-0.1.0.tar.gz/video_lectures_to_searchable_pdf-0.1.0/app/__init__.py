"""Video Lectures to Searchable PDFs package."""

__all__ = ["config", "pipeline"]

