Welcome to the ministats docs
=============================

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   readme
   installation
   usage
   design
   history
   contributing


Indices and tables
==================
* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
