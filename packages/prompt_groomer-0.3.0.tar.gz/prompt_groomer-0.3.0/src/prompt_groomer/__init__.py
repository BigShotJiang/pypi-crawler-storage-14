"""
prompt-groomer has been renamed to llm-prompt-refiner.

This package is deprecated and will no longer receive updates.
Please migrate to the new package:

    pip uninstall prompt-groomer
    pip install llm-prompt-refiner

The API remains the same, just update your imports:
    from prompt_refiner import ...  # New import path
"""

import warnings


def _warn_moved():
    """Display deprecation warning when package is imported."""
    print("!" * 80)
    print("WARNING: 'prompt-groomer' has been renamed to 'llm-prompt-refiner'.")
    print("")
    print("This package is deprecated and will no longer receive updates.")
    print("")
    print("Please update your dependencies:")
    print("    pip uninstall prompt-groomer")
    print("    pip install llm-prompt-refiner")
    print("")
    print("Then update your imports:")
    print("    from prompt_refiner import ...  # Changed from prompt_groomer")
    print("")
    print("The new package is already installed as a dependency.")
    print("!" * 80)
    warnings.warn(
        "prompt-groomer is deprecated. Use llm-prompt-refiner instead. "
        "See https://pypi.org/project/llm-prompt-refiner/",
        DeprecationWarning,
        stacklevel=2,
    )


# Show warning immediately when package is imported
_warn_moved()

# Re-export everything from the new package for backward compatibility
try:
    from prompt_refiner import *  # noqa: F401, F403
except ImportError:
    # If the new package isn't installed yet, just show the warning
    pass
