# Security Policy

## Supported Versions

| Version | Supported          |
| ------- | ------------------ |
| 0.0.0   | :white_check_mark: |


## Reporting a Vulnerability

Report all the vulnerability to security@celesto.ai

PS: We don't have any reward program at this point of time.
