"""
Test Suite: TopologySyncService (Helix Pattern)
================================================

Tests for the topology synchronization service that materializes
graph relationships from external data sources.
"""

import csv
import os
import shutil
import sqlite3
import tempfile

import pytest

from malha import TopologySyncService, connect, generate_virtual_rid

# ============================================================================
# Fixtures
# ============================================================================

@pytest.fixture
def temp_dir():
    """Create a temporary directory for test files."""
    temp_path = tempfile.mkdtemp()
    yield temp_path
    shutil.rmtree(temp_path, ignore_errors=True)


@pytest.fixture
async def kernel(temp_dir):
    """Create a kernel instance."""
    db_path = os.path.join(temp_dir, "sync_test.db")
    graph_path = os.path.join(temp_dir, "sync_graph")

    kernel = await connect(
        url=f"sqlite+aiosqlite:///{db_path}",
        kuzu_path=graph_path,
        enable_monitoring=False,
    )
    yield kernel
    await kernel.close()


@pytest.fixture
def sqlite_orders_db(temp_dir):
    """Create a SQLite database with orders and customers."""
    db_path = os.path.join(temp_dir, "orders.db")
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()

    # Create orders table with FK to customers
    cursor.execute("""
        CREATE TABLE orders (
            id INTEGER PRIMARY KEY,
            customer_id INTEGER,
            amount REAL,
            status TEXT
        )
    """)

    # Insert test data
    orders = [
        (1, 100, 99.99, "completed"),
        (2, 100, 149.99, "completed"),
        (3, 101, 49.99, "pending"),
        (4, 102, 299.99, "completed"),
        (5, 100, 19.99, "cancelled"),
    ]
    cursor.executemany("INSERT INTO orders VALUES (?, ?, ?, ?)", orders)
    conn.commit()
    conn.close()

    return db_path


@pytest.fixture
def csv_relationships(temp_dir):
    """Create a CSV file with relationship data."""
    csv_path = os.path.join(temp_dir, "product_categories.csv")

    with open(csv_path, "w", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(["product_id", "category_id"])
        writer.writerow(["P001", "CAT-A"])
        writer.writerow(["P001", "CAT-B"])
        writer.writerow(["P002", "CAT-A"])
        writer.writerow(["P003", "CAT-C"])

    return csv_path


# ============================================================================
# Tests: generate_virtual_rid
# ============================================================================

class TestGenerateVirtualRid:
    """Tests for deterministic RID generation."""

    def test_generates_valid_rid_format(self):
        """Test RID has correct format."""
        rid = generate_virtual_rid("Customer", "12345")

        assert rid.startswith("ri.helix.virtual.")
        assert "customer" in rid.lower()
        assert len(rid.split(".")) == 5

    def test_deterministic_same_input_same_output(self):
        """Test same input always produces same RID."""
        rid1 = generate_virtual_rid("Order", "ORD-001")
        rid2 = generate_virtual_rid("Order", "ORD-001")

        assert rid1 == rid2

    def test_different_inputs_different_outputs(self):
        """Test different inputs produce different RIDs."""
        rid1 = generate_virtual_rid("Order", "ORD-001")
        rid2 = generate_virtual_rid("Order", "ORD-002")
        rid3 = generate_virtual_rid("Customer", "ORD-001")

        assert rid1 != rid2
        assert rid1 != rid3
        assert rid2 != rid3

    def test_case_sensitivity_in_namespace(self):
        """Test namespace is lowercased in RID."""
        rid = generate_virtual_rid("CustomerSalesforce", "123")

        assert "customersalesforce" in rid
        assert "CustomerSalesforce" not in rid

    def test_handles_special_characters_in_id(self):
        """Test handles special characters in external ID."""
        rid = generate_virtual_rid("Customer", "SF-123-ABC")

        assert rid.startswith("ri.helix.virtual.")
        # Should not raise


# ============================================================================
# Tests: TopologySyncService Initialization
# ============================================================================

class TestSyncServiceInit:
    """Tests for sync service initialization."""

    @pytest.mark.asyncio
    async def test_creates_with_kernel(self, kernel):
        """Test sync service can be created with kernel."""
        sync = TopologySyncService(kernel)

        assert sync.kernel is kernel
        assert sync.stats["total_syncs"] == 0
        assert sync.stats["total_edges_created"] == 0
        assert sync.stats["total_errors"] == 0

    @pytest.mark.asyncio
    async def test_stats_tracking(self, kernel):
        """Test stats are tracked correctly."""
        sync = TopologySyncService(kernel)

        stats = sync.get_stats()
        assert isinstance(stats, dict)
        assert "total_syncs" in stats

        # Stats should be a copy
        stats["total_syncs"] = 999
        assert sync.stats["total_syncs"] == 0

    @pytest.mark.asyncio
    async def test_reset_stats(self, kernel):
        """Test stats can be reset."""
        sync = TopologySyncService(kernel)
        sync.stats["total_syncs"] = 10
        sync.stats["total_edges_created"] = 100

        sync.reset_stats()

        assert sync.stats["total_syncs"] == 0
        assert sync.stats["total_edges_created"] == 0


# ============================================================================
# Tests: sync_relationship
# ============================================================================

class TestSyncRelationship:
    """Tests for relationship synchronization."""

    @pytest.mark.asyncio
    async def test_sync_from_sqlite(self, kernel, sqlite_orders_db):
        """Test syncing relationships from SQLite."""
        sync = TopologySyncService(kernel)

        edges = await sync.sync_relationship(
            source_config={
                "type": "sqlite",
                "path": sqlite_orders_db,
                "table": "orders",
            },
            source_pk_column="id",
            source_fk_column="customer_id",
            source_type="Order",
            target_type="Customer",
            relationship_label="PLACED_BY",
        )

        assert edges == 5  # All 5 orders
        assert sync.stats["total_syncs"] == 1
        assert sync.stats["total_edges_created"] == 5

    @pytest.mark.asyncio
    async def test_sync_with_filter(self, kernel, sqlite_orders_db):
        """Test syncing with SQL filter."""
        sync = TopologySyncService(kernel)

        edges = await sync.sync_relationship(
            source_config={
                "type": "sqlite",
                "path": sqlite_orders_db,
                "table": "orders",
            },
            source_pk_column="id",
            source_fk_column="customer_id",
            source_type="Order",
            target_type="Customer",
            relationship_label="PLACED_BY",
            sql_filter="status = 'completed'",
        )

        assert edges == 3  # Only completed orders

    @pytest.mark.asyncio
    async def test_sync_from_csv(self, kernel, csv_relationships):
        """Test syncing relationships from CSV."""
        sync = TopologySyncService(kernel)

        edges = await sync.sync_relationship(
            source_config={
                "type": "csv",
                "path": csv_relationships,
            },
            source_pk_column="product_id",
            source_fk_column="category_id",
            source_type="Product",
            target_type="Category",
            relationship_label="IN_CATEGORY",
        )

        assert edges == 4  # All 4 relationships

    @pytest.mark.asyncio
    async def test_sync_empty_result(self, kernel, sqlite_orders_db):
        """Test syncing with filter that returns no rows."""
        sync = TopologySyncService(kernel)

        edges = await sync.sync_relationship(
            source_config={
                "type": "sqlite",
                "path": sqlite_orders_db,
                "table": "orders",
            },
            source_pk_column="id",
            source_fk_column="customer_id",
            source_type="Order",
            target_type="Customer",
            relationship_label="PLACED_BY",
            sql_filter="status = 'nonexistent'",
        )

        assert edges == 0

    @pytest.mark.asyncio
    async def test_progress_callback(self, kernel, sqlite_orders_db):
        """Test progress callback is called."""
        sync = TopologySyncService(kernel)
        progress_calls = []

        def on_progress(processed, total):
            progress_calls.append((processed, total))

        await sync.sync_relationship(
            source_config={
                "type": "sqlite",
                "path": sqlite_orders_db,
                "table": "orders",
            },
            source_pk_column="id",
            source_fk_column="customer_id",
            source_type="Order",
            target_type="Customer",
            relationship_label="PLACED_BY",
            on_progress=on_progress,
        )

        # Should have final callback at minimum
        assert len(progress_calls) > 0
        assert progress_calls[-1] == (5, 5)


# ============================================================================
# Tests: sync_bidirectional
# ============================================================================

class TestSyncBidirectional:
    """Tests for bidirectional relationship synchronization."""

    @pytest.mark.asyncio
    async def test_creates_edges_both_directions(self, kernel, csv_relationships):
        """Test bidirectional sync creates edges in both directions."""
        sync = TopologySyncService(kernel)

        edges = await sync.sync_bidirectional(
            source_config={
                "type": "csv",
                "path": csv_relationships,
            },
            pk_column_a="product_id",
            pk_column_b="category_id",
            type_a="Product",
            type_b="Category",
            relationship_label="RELATED_TO",
        )

        # 4 forward + 4 reverse = 8 edges
        assert edges == 8


# ============================================================================
# Tests: bulk_create_edges
# ============================================================================

class TestBulkCreateEdges:
    """Tests for bulk edge creation."""

    @pytest.mark.asyncio
    async def test_bulk_create_edges(self, kernel):
        """Test bulk edge creation."""
        sync = TopologySyncService(kernel)

        edges = [
            (generate_virtual_rid("A", "1"), generate_virtual_rid("B", "1")),
            (generate_virtual_rid("A", "2"), generate_virtual_rid("B", "2")),
            (generate_virtual_rid("A", "3"), generate_virtual_rid("B", "3")),
        ]

        created = await sync.bulk_create_edges(edges, "LINKS_TO")

        assert created == 3
        assert sync.stats["total_edges_created"] == 3


# ============================================================================
# Tests: Column Selection (Lightweight Queries)
# ============================================================================

class TestColumnSelection:
    """Tests for lightweight column selection in federated queries."""

    @pytest.mark.asyncio
    async def test_query_federated_with_columns(self, kernel, sqlite_orders_db):
        """Test query_federated with specific columns."""
        result = await kernel.query_federated(
            {
                "type": "sqlite",
                "path": sqlite_orders_db,
                "table": "orders",
            },
            "1=1",
            columns=["id", "customer_id"],
        )

        assert len(result) == 5
        # Should only have the requested columns
        for row in result:
            assert "id" in row
            assert "customer_id" in row
            # amount and status should NOT be present
            assert "amount" not in row
            assert "status" not in row

    @pytest.mark.asyncio
    async def test_query_federated_all_columns_default(self, kernel, sqlite_orders_db):
        """Test query_federated returns all columns by default."""
        result = await kernel.query_federated(
            {
                "type": "sqlite",
                "path": sqlite_orders_db,
                "table": "orders",
            },
        )

        assert len(result) == 5
        # Should have all columns
        for row in result:
            assert "id" in row
            assert "customer_id" in row
            assert "amount" in row
            assert "status" in row


# ============================================================================
# Tests: Ghost Nodes (MERGE)
# ============================================================================

class TestGhostNodes:
    """Tests for Ghost Node creation via MERGE."""

    @pytest.mark.asyncio
    async def test_create_edge_with_ghost_nodes_default(self, kernel):
        """Test create_edge creates ghost nodes by default."""
        # Create edge between non-existent nodes
        await kernel.graph.create_edge(
            src="ri.helix.virtual.test.ghost1",
            dst="ri.helix.virtual.test.ghost2",
            label="GHOST_LINK",
            props={"test": True},
        )

        # Query should find the edge (nodes were created as ghosts)
        # Note: This depends on Kùzu supporting MERGE
        # The test verifies no exception is raised

    @pytest.mark.asyncio
    async def test_create_edge_without_ghost_nodes(self, kernel):
        """Test create_edge without ghost nodes fails for missing nodes."""
        # This should fail because nodes don't exist and we disabled ghost creation
        # Note: Behavior depends on Kùzu's MATCH semantics
        try:
            await kernel.graph.create_edge(
                src="ri.nonexistent.node1",
                dst="ri.nonexistent.node2",
                label="WILL_FAIL",
                create_ghost_nodes=False,
            )
        except Exception:
            pass  # Expected to fail or return empty


# ============================================================================
# Tests: Error Handling
# ============================================================================

class TestErrorHandling:
    """Tests for error handling in sync service."""

    @pytest.mark.asyncio
    async def test_invalid_source_config(self, kernel):
        """Test sync with invalid source config."""
        sync = TopologySyncService(kernel)

        with pytest.raises(ValueError, match="Unsupported federation source"):
            await sync.sync_relationship(
                source_config={"type": "invalid"},
                source_pk_column="id",
                source_fk_column="fk",
                source_type="A",
                target_type="B",
                relationship_label="LINK",
            )

    @pytest.mark.asyncio
    async def test_missing_column_in_source(self, kernel, sqlite_orders_db):
        """Test sync with non-existent column."""
        sync = TopologySyncService(kernel)

        # This should fail because 'nonexistent_column' doesn't exist
        with pytest.raises(Exception):
            await sync.sync_relationship(
                source_config={
                    "type": "sqlite",
                    "path": sqlite_orders_db,
                    "table": "orders",
                },
                source_pk_column="nonexistent_column",
                source_fk_column="customer_id",
                source_type="Order",
                target_type="Customer",
                relationship_label="PLACED_BY",
            )
