# Malha v0.4.0 - Implementation Roadmap
## Kernel de OGM Distribuído e Resiliente SotA

**Status:** 🚧 Planejamento  
**Target:** v0.4.0  
**Tempo:** 2-3 semanas  
**Current:** v0.3.1 (83% coverage)

---

## 🎯 Visão

Transformar Malha de "Backend Local" para **Kernel de Sistema Operacional de Dados Distribuído SotA**.

---

## 📋 Checklist de Implementação

### 🏗️ Fase 1: Refatoração de Modelos (3-4 dias)
**Prioridade:** 🔴 Alta

#### Separar BaseResource de RegistroResource
- [ ] BaseResource vira Pydantic puro (sem SQLModel)
- [ ] Adicionar `model_config = ConfigDict(extra='allow')`
- [ ] Criar `to_record()` e `from_record()`
- [ ] Adicionar `_raw_extra: Optional[str]` em RegistroResource
- [ ] Atualizar UnifiedDataManager para usar conversão
- [ ] Testes de conversão bidirecional
- [ ] Testes de Tolerant Reader

#### Atualizar SysOutbox
- [ ] Adicionar `origin_node: str = "local"`
- [ ] Adicionar `retries: int = 0`
- [ ] Adicionar `error: Optional[str] = None`
- [ ] Adicionar `next_retry_at: Optional[datetime] = None`
- [ ] Migração de schema
- [ ] Atualizar testes

---

### 🔒 Fase 2: Concorrência Pessimista (2-3 dias)
**Prioridade:** 🔴 Alta

#### Implementar Lock em save_versioned
- [ ] Adicionar parâmetro `origin: str = "local"`
- [ ] Implementar `select(...).with_for_update()`
- [ ] Atualizar SysOutbox com origin_node
- [ ] Teste com 10 threads simultâneas
- [ ] Teste de deadlock
- [ ] Benchmark de performance

---

### 🌐 Fase 3: Synapse P2P (5-7 dias)
**Prioridade:** 🟡 Média-Alta

#### Criar Protobuf
- [ ] Definir `synapse.proto` com SynapseMesh service
- [ ] Definir ReplicationEvent com origin_node_id
- [ ] Compilar protos

#### Implementar Servidor
- [ ] Criar SynapseServicer
- [ ] Implementar ReplicateStream RPC
- [ ] Implementar deduplicação (cache de tx_id)
- [ ] Evitar loops (check origin_node_id)
- [ ] HealthCheck RPC
- [ ] DiscoverPeers RPC

#### Implementar Cliente (Gossip)
- [ ] SynapseDriver com fan-out limitado
- [ ] Rotação periódica de peers
- [ ] Método broadcast() para active peers
- [ ] Descoberta de peers
- [ ] Health checks

#### Integração
- [ ] Adicionar replication_driver ao UnifiedDataManager
- [ ] Atualizar connect() com parâmetros de rede
- [ ] Testes com 3 nós
- [ ] Verificar propagação de eventos

---

### 🛡️ Fase 4: Resiliência (3-4 dias)
**Prioridade:** 🟢 Média

#### DLQ e Retry
- [ ] Implementar backoff exponencial
- [ ] DLQ após 5 tentativas
- [ ] Atualizar _process_outbox
- [ ] Apenas replicar se origin_node == "local"
- [ ] Testes de falha de rede
- [ ] Endpoint para reprocessar DLQ

#### KernelMonitor
- [ ] Criar coletor de métricas
- [ ] Buffer com flush periódico
- [ ] Tabela sys_metrics no DuckDB
- [ ] Métricas: events_sent, db_latency, outbox_size, dlq_size
- [ ] Dashboard query

---

### 🕸️ Fase 5: OGM Primitives (2-3 dias)
**Prioridade:** 🟢 Média

#### Expandir API do Grafo
- [ ] Método `get_neighbors(rid, label, direction)`
- [ ] Método `get_edge_props(source, target, label)`
- [ ] Método `traverse(start, pattern, max_depth)`
- [ ] Garantir thread-safety
- [ ] Testes de concorrência
- [ ] Benchmark

#### Registry de Modelos
- [ ] Adicionar _model_registry
- [ ] Método register_model()
- [ ] Método get_model_class()
- [ ] Documentar para Ontologic

---

## 📊 Cronograma

| Fase | Duração | Prioridade |
|------|---------|------------|
| Fase 1 | 3-4 dias | 🔴 Alta |
| Fase 2 | 2-3 dias | 🔴 Alta |
| Fase 3 | 5-7 dias | 🟡 Média-Alta |
| Fase 4 | 3-4 dias | 🟢 Média |
| Fase 5 | 2-3 dias | 🟢 Média |
| **TOTAL** | **15-21 dias** | |

---

## 🎯 Critérios de Sucesso

### Fase 1 ✅
- BaseResource é Pydantic puro
- Tolerant Reader funciona
- Testes 95%+ coverage

### Fase 2 ✅
- SELECT FOR UPDATE implementado
- Teste de 10 threads passa
- Performance <100ms overhead

### Fase 3 ✅
- 3 nós comunicam via Gossip
- Loops evitados
- Peer rotation funciona

### Fase 4 ✅
- DLQ após 5 tentativas
- Métricas coletadas
- Dashboard funciona

### Fase 5 ✅
- get_neighbors funciona
- Thread-safe
- Performance OK

---

## 🚀 Releases

- **v0.4.0-alpha.1:** Fase 1+2 (Breaking)
- **v0.4.0-beta.1:** Fase 3
- **v0.4.0-rc.1:** Fase 4+5
- **v0.4.0:** Final

---

## 🎉 Resultado Final

**Malha v0.4.0 será um Kernel de OGM Distribuído SotA:**

✅ Schema evolution sem crashes  
✅ Concorrência pessimista robusta  
✅ Rede P2P com Gossip  
✅ Self-healing com DLQ  
✅ Observabilidade embutida  
✅ Primitivas OGM completas  

**Status:** Pronto para iniciar Fase 1
