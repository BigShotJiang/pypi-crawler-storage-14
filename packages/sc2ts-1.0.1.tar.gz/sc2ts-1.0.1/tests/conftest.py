# We keep the fixtures in a separate modules so that the plugin can
# be excluded when running tests on the bare API
pytest_plugins = ["sc2ts_fixtures"]
