# `typ2docx`: Convert Math-Rich Typst Project to Microsoft Word Format

`typ2docx` is a command line tool that converts a Typst project to Microsoft
Word `.docx` format, with tables, cross-references, most of the styles, and most
importantly the math markups preserved. It combines the mature, comprehensive
document conversion of standard PDF-to-Word tools with Pandoc's high-quality
mathematical formula export.

You're encouraged to read this document thoroughly before using it, as I
employed many non-trivial hacks for this non-trivial problem! (It involves 6
different programming languages!)

If this tool enhanced your workflow, especially if it helped with your academic
publication, please consider crediting this project or sponsoring me. :heart:

> [!NOTE]
>
> If you don't care about the quality of math export, this tool is no different
> from other PDF-to-Word converter.
>
> If your project doesn't use any non-basic features in Typst, try Pandoc first.

## Installation

> [!NOTE]
>
> You may now try this tool without installing through
> [a web app](https://typ2docx.sgh.ng). Note that it runs on my scarce free-tier
> API quota, so please install this tool if you intend to use it more than once!

### Prerequisite

This tool is distributed via PyPI. Installation via
[`uv`](https://docs.astral.sh/uv/getting-started/installation/) is recommended.
You may also use `pipx` or other similar tools to install and run this program.
For more details, read
[`uv`'s guide on using tools](https://docs.astral.sh/uv/guides/tools/).

### Tool Installation

Execute the following command to install:

```sh
uv tool install typ2docx
```

> [!NOTE]
>
> The package installation process is expected to take some time, since it
> requires compiling a Rust extension. Read along to know why.

If you want to tinker with this program:

```sh
git clone git@github.com:sghng/typ2docx.git
cd typ2docx
# do your modifications...
uv tool install .
```

### Runtime Dependencies

The following runtime dependencies are also required:

- [Pandoc](https://pandoc.org/installing.html), a universal document converter,
  should be available in `PATH`.
- One of the supported [`.pdf` -> `.docx` engines](#pdf-docx-engines).

## Usage

Once the tool is installed, invoke it with the path to the entry point of your
Typst project and specify an engine to convert it into Microsoft Word `.docx`
format. For example:

```sh
# obtain your free Adobe PDF Services API key first
export PDF_SERVICES_CLIENT_ID=xxx
export PDF_SERVICES_CLIENT_SECRET=xxx
typ2docx main.typ -e pdfservices
```

Or, if you have Adobe Acrobat installed:

```sh
typ2docx --install-acrobat # only needed for first time using Acrobat engine
typ2docx main.typ -e acrobat
```

Run `typ2docx --help` to see the help info on how to use this tool.

### PDF -> DOCX Engines

You need to specify the engine used to convert a PDF to `.docx` file. Currently
there are two supported engines:

- [**Adobe PDFServices API:**](https://developer.adobe.com/document-services/apis/pdf-services/)
  It requires internet connection and valid PDFServices API credentials. This
  service comes with 500 free conversions per month, which should be enough for
  most people.
- [**Adobe Acrobat:**](https://acrobat.adobe.com) It uses Acrobat's JavaScript
  API to export a PDF to `.docx`. Either the free Acrobat Reader or the paid
  Acrobat Pro would work.

## What It Does and Does Not

There are some known issues -- which may or may not be a real issue depending on
your use cases. Read the [_Motivation_](#motivation) section to understand why I
built this tool.

- Text in SVG/PDF images are distorted.
- Some spaces between inline equations and regular text are missing.
- Not all stylings are preserved. (This is expected, just like for any file
  format conversion.)

## Similar Tools

- [Adobe Acrobat](https://acrobat.adobe.com) does a great job in converting PDF
  to `.docx`, but the math equations are completely messed up.
- [Microsoft Word](https://www.microsoft.com/en-us/microsoft-365/word) can also
  convert a PDF to `.docx` format. In my experience, it doesn't work as well as
  Adobe Acrobat.
- [`pdf2docx`](https://pypi.org/project/pdf2docx/) Python library doesn't work
  for most of my PDF files.
- [Pandoc](https://pandoc.org) provides superb support for math markup when
  converting `.typ` file to `.docx`, but its support for Typst is very limited.
  For example, it doesn't recognize basic functions like `#stroke`. It also
  doesn't support latest features in Typst, such as embedding PDF as image.
- [`typlite`](https://docs.rs/crate/typlite/) is a tool developed by the author
  of `tinymist`. Its support for conversion to `.docx` is limited, as it relies
  on HTML as an intermediary. Styles and cross-references are lost, and math are
  rendered as images.

## Motivation

This tool is developed so that a `.docx` export that meets the basic requirement
of academic paper submission can be produced. These requirements are very loose,
since the press has their own process for making a manuscript publication ready.

- Cross-referencing is NOT required.
- Figures are NOT required. They can be included as standalone attachments, as
  long as the names are matched.
- NO typesetting required.

With these said, the only true requirement is the quality of math equations,
which must be retained effectively. And in Microsoft Word, it should be in
Office Math Markup Language (OMML).

This tool is developed primarily to address the equation output problem.

## Solution

The idea is to export with both Adobe Acrobat and Pandoc, and merge the best
part in the two exports together.

- Branch 1
  - A preamble is injected to the Typst project entry point, so that all math
    are rendered as markers.
  - Typst compiles the project into PDF file.
  - This PDF file is converted to Word format by some converter.
- Branch 2
  - A Rust lib extracts all math source code in a Typst project.
  - The source code are put into a new Typst source file, in order of their
    appearance in original document.
  - This source file is converted to `.docx` with Pandoc, they are cleanly
    formatted with MathML.
- The two Microsoft Word files are unpacked. A XLST script merges the
  `document.xml` files by examining the markers. The result is finally repacked
  into a `.docx` file as output.

The math source code can not be extracted with purely static analysis or regex
matching, since the location where a content is defined can be different from
where it shows up in document, and multiple source files can be involved via
`#include` and `#import`. This necessitates the use of `typst` and `typst-eval`
Rust crates for parsing as well as evaluating the Typst project.

## Contribution

You are more than welcome to contribute by raising issues or opening pull
requests!
