This module extends the functionality of fleet to support vehicle owner data
and to allow you to add vehicle ownership, linking partners to vehicles.
