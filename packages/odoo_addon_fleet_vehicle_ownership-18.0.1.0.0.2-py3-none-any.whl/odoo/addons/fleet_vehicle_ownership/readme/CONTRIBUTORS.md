- Raimundo Junior <raimundopsjr@gmail.com>

- `Trey Kilobytes de Soluciones SL <https://www.trey.es>`__:
  - Vicent Cubells <vicent@trey.es>
