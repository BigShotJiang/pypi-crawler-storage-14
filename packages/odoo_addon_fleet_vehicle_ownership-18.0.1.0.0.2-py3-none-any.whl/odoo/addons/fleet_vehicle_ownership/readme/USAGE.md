To use this module, you need to:

1. Go to the vehicle form and associate an owner or go to the partner form and
associate a vehicle.
