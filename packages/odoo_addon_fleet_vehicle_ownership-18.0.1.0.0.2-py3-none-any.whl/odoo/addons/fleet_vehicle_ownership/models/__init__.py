from . import fleet_vehicle
from . import res_partner
