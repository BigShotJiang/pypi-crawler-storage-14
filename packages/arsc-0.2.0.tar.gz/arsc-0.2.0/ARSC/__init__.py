# ARSC/__init__.py
from .core import process_faa, compute_ARSC_extended_counts

__version__ = "0.2.0"
__author__ = "Satoshi Nishino"