# please don't modify this file,
# this is automatically updated by bump2version
__version__ = '1.0.6'
