# Attending Machine
Attending Machine.
<pre>
  pip install attending-machine
</pre>
Then:
```Python
  # Python
  import attending_machine
```
