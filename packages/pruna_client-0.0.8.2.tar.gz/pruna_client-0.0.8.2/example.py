import time

from pruna_client import PredictionStatus, PrunaClient

client = PrunaClient()

start_time = time.time()
response = client.generate(
    model="p-image",
    input={"prompt": "A beautiful sunset over a calm ocean"},
    sync=True,
)

if response.status == PredictionStatus.SUCCEEDED:
    generation_url = response.response["generation_url"]
    if generation_url:
        # Download the generated image
        image_bytes = client.download_content(generation_url)
        with open("generated_image.jpg", "wb") as f:
            f.write(image_bytes)
end_time = time.time()
print(f"Time taken from generate: {end_time - start_time} seconds")


start_time = time.time()
client.upload_file("generated_image.jpg")
end_time = time.time()
print(f"Time taken from upload_file: {end_time - start_time} seconds")
start_time = time.time()
client.upload_file("generated_image.jpg")
end_time = time.time()
print(f"Time taken from upload_file: {end_time - start_time} seconds")

start_time = time.time()
client.generate_image_edit(
    model="p-image-edit",
    prompt="A beautiful sunset over a calm ocean",
    images=["generated_image.jpg"],
    sync=True,
)
end_time = time.time()
print(f"Time taken from generate_image_edit: {end_time - start_time} seconds")

start_time = time.time()
responses = client.generate_batch(
    requests=[
        {"model": "p-image", "input": {"prompt": "A beautiful sunset over a calm ocean"}, "sync": True},
        {"model": "p-image", "input": {"prompt": "A beautiful sunset over a calm ocean"}, "sync": True},
    ]
)
end_time = time.time()
print(f"Time taken from generate_batch: {end_time - start_time} seconds")
for response in responses:
    if response.status == PredictionStatus.SUCCEEDED:
        generation_url = response.response["generation_url"]
        if generation_url:
            image_bytes = client.download_content(generation_url)
            with open("generated_image.jpg", "wb") as f:
                f.write(image_bytes)
                
                
curl -X POST https://api.replicate.com/v1/files \
  -H "Authorization: Token $REPLICATE_API_TOKEN" \
  -H 'Content-Type: multipart/form-data' \
  -F 'content=@0.png;type=image/png;filename=0.png' \
  -F 'metadata={"customer_reference_id": 123};type=application/json'
  
curl -X POST https://api.pruna.ai/v1/files \
-H "apikey: $PRUNA_API_KEY" \
-F "content=@0.png" \
> upload1.json
