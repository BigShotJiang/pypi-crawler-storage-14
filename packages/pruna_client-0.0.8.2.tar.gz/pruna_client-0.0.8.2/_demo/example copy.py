"""Speed test for async generation of 10 images."""
import asyncio
import time

from pruna_client import PrunaClient
from pruna_client.models import PredictionStatus


async def speed_test_async_generation() -> None:
    """Test async generation of 10 images and measure performance."""
    client = PrunaClient()
    
    # Create 10 different prompts for variety
    prompts = [
        "A beautiful sunset over a calm ocean",
        "A serene mountain landscape at dawn",
        "A futuristic city with flying cars",
        "A cozy coffee shop on a rainy day",
        "A magical forest with glowing mushrooms",
        "A vintage car on a desert highway",
        "A space station orbiting Earth",
        "A peaceful Japanese garden with cherry blossoms",
        "A steampunk mechanical dragon",
        "A tropical beach with palm trees",
    ]
    
    # Prepare batch requests
    requests = [
        {"model": "p-image", "input": {"prompt": prompt}, "sync": True}
        for prompt in prompts
    ]
    
    print(f"Starting async generation of {len(requests)} images...")
    print("-" * 60)
    
    # Measure total time
    start_time = time.time()
    print(f"Sending {len(requests)} requests concurrently at {start_time:.3f}s...")
    print("=" * 60)
    
    # Generate all images concurrently - send all requests at once
    # Wrap each request to log timing and verify concurrency
    from pruna_client.models import Response
    request_timings: list[dict] = []
    
    async def timed_request(request_dict: dict, index: int) -> Response:
        """Execute request with timing to verify concurrency."""
        req_start = time.time()
        request_timings.append({"index": index, "start": req_start - start_time, "prompt": request_dict['input']['prompt'][:40]})
        print(f"  [{index+1:2d}] Started at {req_start - start_time:7.3f}s - '{request_dict['input']['prompt'][:40]}...'")
        try:
            response = await client.agenerate(
                request_dict["model"],
                request_dict["input"],
                request_dict["sync"]
            )
            req_end = time.time()
            duration = req_end - req_start
            request_timings[-1]["end"] = req_end - start_time
            request_timings[-1]["duration"] = duration
            print(f"  [{index+1:2d}] Completed at {req_end - start_time:7.3f}s (took {duration:6.3f}s) - '{request_dict['input']['prompt'][:40]}...'")
            return response
        except Exception as e:
            req_end = time.time()
            duration = req_end - req_start
            request_timings[-1]["end"] = req_end - start_time
            request_timings[-1]["duration"] = duration
            request_timings[-1]["error"] = str(e)
            print(f"  [{index+1:2d}] Failed at {req_end - start_time:7.3f}s (took {duration:6.3f}s) - {e}")
            raise
    
    # Use asyncio.gather directly to ensure true concurrency
    tasks = [timed_request(req, i) for i, req in enumerate(requests)]
    gather_results = await asyncio.gather(*tasks, return_exceptions=True)
    
    print("=" * 60)
    print("\nConcurrency Analysis:")
    if request_timings:
        starts = [t["start"] for t in request_timings]
        ends = [t.get("end", 0) for t in request_timings]
        durations = [t.get("duration", 0) for t in request_timings]
        
        start_spread = max(starts) - min(starts)
        total_duration = max(ends) - min(starts) if ends else 0
        sum_durations = sum(durations)
        
        print(f"  Requests started within: {start_spread*1000:.1f}ms (should be <50ms for true concurrency)")
        print(f"  Total wall-clock time: {total_duration:.2f}s")
        print(f"  Sum of individual durations: {sum_durations:.2f}s")
        print(f"  Speedup ratio: {sum_durations/total_duration:.2f}x" if total_duration > 0 else "  Speedup ratio: N/A")
        
        if start_spread > 0.1:
            print("  ⚠️  WARNING: Requests started sequentially (not concurrent)!")
        elif sum_durations / total_duration < 1.5:
            print("  ⚠️  WARNING: Server appears to process requests sequentially!")
            print("     (Total time ≈ sum of individual times = server-side bottleneck)")
        else:
            print("  ✓ Requests sent concurrently, server processing in parallel")
    
    # Filter out exceptions and convert to list
    responses: list[Response] = []
    for i, resp in enumerate(gather_results):
        if isinstance(resp, Exception):
            print(f"  Request {i+1} raised exception: {resp}")
            # Create a failed response
            input_data = requests[i].get("input", {})
            if not isinstance(input_data, dict):
                input_data = {}
            responses.append(Response(
                id="failed",
                model=str(requests[i].get("model", "unknown")),
                inputs=input_data,
                status=PredictionStatus.FAILED,
                response={"error": str(resp)}
            ))
        elif isinstance(resp, Response):
            responses.append(resp)
    
    end_time = time.time()
    total_time = end_time - start_time
    
    # Analyze results
    successful = sum(1 for r in responses if r.status == PredictionStatus.SUCCEEDED)
    failed = len(responses) - successful
    
    print("\nResults:")
    print(f"  Total time: {total_time:.2f} seconds")
    print(f"  Average time per image: {total_time / len(requests):.2f} seconds")
    print(f"  Successful: {successful}/{len(requests)}")
    print(f"  Failed: {failed}/{len(requests)}")
    print(f"  Throughput: {len(requests) / total_time:.2f} images/second")
    
    # Show individual response times (if available in response)
    print("\nIndividual results:")
    for i, response in enumerate(responses):
        status_icon = "✓" if response.status == PredictionStatus.SUCCEEDED else "✗"
        print(f"  {status_icon} Image {i+1}: {response.status.value}")
    
    await client.aclose()


if __name__ == "__main__":
    asyncio.run(speed_test_async_generation())

