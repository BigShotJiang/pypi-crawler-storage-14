"""Test using requests.post directly to interact with Pruna API."""
import os
import time

import requests


def get_api_key() -> str:
    """Get API key from environment variable."""
    api_key = os.getenv("PRUNA_API_KEY")
    if not api_key:
        raise ValueError("PRUNA_API_KEY environment variable not set")
    return api_key


def test_file_upload_and_prediction(file_path: str) -> None:
    """Test file upload and prediction using requests.post directly."""
    api_key = get_api_key()
    base_url = "https://api.pruna.ai/v1"
    
    if not os.path.exists(file_path):
        print(f"Error: File {file_path} not found")
        return
    
    file_size = os.path.getsize(file_path)
    print("=" * 70)
    print("Direct API Test with requests.post")
    print("=" * 70)
    print(f"File: {file_path}")
    print(f"Size: {file_size / 1024 / 1024:.2f} MB")
    print("-" * 70)
    
    # Step 1: Upload file
    print("\n[Step 1] Uploading file...")
    print("-" * 70)
    upload_url = f"{base_url}/files"
    headers = {"apikey": api_key}
    
    start_time = time.time()
    with open(file_path, "rb") as f:
        files = {"content": (os.path.basename(file_path), f, "image/png")}
        response = requests.post(upload_url, headers=headers, files=files)
    
    upload_time = time.time() - start_time
    
    if response.status_code not in [200, 201]:
        print("✗ Upload failed")
        print(f"  Status code: {response.status_code}")
        print(f"  Response: {response.text}")
        return
    
    upload_data = response.json()
    file_id = upload_data.get("id")
    file_url = upload_data.get("urls", {}).get("get")
    
    print("✓ Upload successful")
    print(f"  Time: {upload_time:.3f} seconds")
    print(f"  Speed: {file_size / upload_time / 1024 / 1024:.2f} MB/s")
    print(f"  File ID: {file_id}")
    print(f"  File URL: {file_url}")
    
    # Step 2: Make prediction with uploaded file
    print("\n[Step 2] Making prediction with uploaded file...")
    print("-" * 70)
    
    prediction_url = f"{base_url}/predictions"
    prediction_headers = {
        "apikey": api_key,
        "Model": "p-image-edit",
        "Try-Sync": "true",
        "Content-Type": "application/json",
    }
    
    prediction_payload = {
        "input": {
            "prompt": "Transform into a watercolor painting style with vibrant colors",
            "images": [file_url],
            "reference_image": "1",
            "aspect_ratio": "16:9",
        }
    }
    
    start_time = time.time()
    response = requests.post(
        prediction_url, headers=prediction_headers, json=prediction_payload
    )
    prediction_time = time.time() - start_time
    
    if response.status_code not in [200, 201]:
        print(f"✗ Prediction failed: {response.status_code}")
        print(f"  Response: {response.text}")
        return
    
    prediction_data = response.json()
    status = prediction_data.get("status")
    generation_url = prediction_data.get("generation_url")
    
    print("✓ Prediction successful")
    print(f"  Time: {prediction_time:.3f} seconds")
    print(f"  Status: {status}")
    if generation_url:
        print(f"  Generation URL: {generation_url[:80]}...")
        
        # Step 3: Download result
        print("\n[Step 3] Downloading result...")
        print("-" * 70)
        
        download_headers = {"apikey": api_key}
        start_time = time.time()
        download_response = requests.get(generation_url, headers=download_headers)
        download_time = time.time() - start_time
        
        if download_response.status_code == 200:
            output_path = "result_direct_test.jpg"
            with open(output_path, "wb") as f:
                f.write(download_response.content)
            
            result_size = len(download_response.content)
            print("✓ Download successful")
            print(f"  Time: {download_time:.3f} seconds")
            print(f"  Size: {result_size / 1024 / 1024:.2f} MB")
            print(f"  Saved to: {output_path}")
        else:
            print(f"✗ Download failed: {download_response.status_code}")
    
    # Summary
    print("\n" + "=" * 70)
    print("Summary")
    print("=" * 70)
    print(f"Upload time: {upload_time:.3f} seconds")
    print(f"Prediction time: {prediction_time:.3f} seconds")
    if generation_url:
        print(f"Download time: {download_time:.3f} seconds")
        total_time = upload_time + prediction_time + download_time
        print(f"Total time: {total_time:.3f} seconds")
    print("\n✓ Test completed")


if __name__ == "__main__":
    file_path = "0.png"
    if not os.path.exists(file_path):
        print(f"Error: {file_path} not found in current directory")
        print(f"Current directory: {os.getcwd()}")
    else:
        test_file_upload_and_prediction(file_path)

