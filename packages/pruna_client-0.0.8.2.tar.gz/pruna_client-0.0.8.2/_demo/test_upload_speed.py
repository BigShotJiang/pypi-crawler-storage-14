"""Test script for file upload speed and caching mechanism."""
import asyncio
import hashlib
import os
import statistics
import time
from pathlib import Path

from PIL import Image

from pruna_client import PrunaClient


def get_file_hash(file_path: str) -> str:
    """Calculate SHA256 hash of file content."""
    with open(file_path, "rb") as f:
        return hashlib.sha256(f.read()).hexdigest()


async def test_upload_speed_and_cache(file_path: str) -> None:
    """Test file upload speed and caching mechanism."""
    client = PrunaClient()
    
    if not os.path.exists(file_path):
        print(f"Error: File {file_path} not found")
        return
    
    file_size = os.path.getsize(file_path)
    file_hash = get_file_hash(file_path)
    
    print("=" * 70)
    print("File Upload Speed and Cache Test")
    print("=" * 70)
    print(f"File: {file_path}")
    print(f"Size: {file_size / 1024 / 1024:.2f} MB")
    print(f"SHA256: {file_hash[:16]}...")
    print(f"Cache TTL: 600 seconds (10 minutes)")
    print(f"Cache Max Size: 128 entries")
    print("-" * 70)
    
    # Test 1: Initial upload (cache miss)
    print("\n[Test 1] Initial Upload (Cache Miss)")
    print("-" * 70)
    start_time = time.time()
    url1 = await client.aupload_file(file_path)
    upload_time_1 = time.time() - start_time
    
    if url1:
        print(f"✓ Upload successful")
        print(f"  Time: {upload_time_1:.3f} seconds")
        print(f"  Speed: {file_size / upload_time_1 / 1024 / 1024:.2f} MB/s")
        print(f"  URL: {url1[:60]}...")
    else:
        print("✗ Upload failed")
        await client.aclose()
        return
    
    # Test 2: Immediate cache hit (same file path)
    print("\n[Test 2] Immediate Cache Hit (Same File Path)")
    print("-" * 70)
    start_time = time.time()
    url2 = await client.aupload_file(file_path)
    upload_time_2 = time.time() - start_time
    
    if url2:
        cache_hit = url1 == url2
        print(f"{'✓' if cache_hit else '✗'} Upload successful")
        print(f"  Time: {upload_time_2:.3f} seconds")
        print(f"  Speed: {file_size / upload_time_2 / 1024 / 1024:.2f} MB/s" if upload_time_2 > 0 else "  Speed: N/A (instant)")
        print(f"  Cache Hit: {cache_hit}")
        if cache_hit:
            speedup = upload_time_1 / upload_time_2 if upload_time_2 > 0 else float('inf')
            print(f"  Speedup: {speedup:.1f}x faster")
    else:
        print("✗ Upload failed")
    
    # Test 3: Cache hit with Path object
    print("\n[Test 3] Cache Hit (Path Object)")
    print("-" * 70)
    start_time = time.time()
    url3 = await client.aupload_file(Path(file_path))
    upload_time_3 = time.time() - start_time
    
    if url3:
        cache_hit = url1 == url3
        print(f"{'✓' if cache_hit else '✗'} Upload successful")
        print(f"  Time: {upload_time_3:.3f} seconds")
        print(f"  Speed: {file_size / upload_time_3 / 1024 / 1024:.2f} MB/s" if upload_time_3 > 0 else "  Speed: N/A (instant)")
        print(f"  Cache Hit: {cache_hit}")
        if cache_hit:
            speedup = upload_time_1 / upload_time_3 if upload_time_3 > 0 else float('inf')
            print(f"  Speedup: {speedup:.1f}x faster")
    else:
        print("✗ Upload failed")
    
    # Test 4: Cache hit with PIL Image
    print("\n[Test 4] Cache Hit (PIL Image)")
    print("-" * 70)
    image = Image.open(file_path)
    start_time = time.time()
    url4 = await client.aupload_file(image)
    upload_time_4 = time.time() - start_time
    
    if url4:
        cache_hit = url1 == url4
        print(f"{'✓' if cache_hit else '✗'} Upload successful")
        print(f"  Time: {upload_time_4:.3f} seconds")
        print(f"  Speed: {file_size / upload_time_4 / 1024 / 1024:.2f} MB/s" if upload_time_4 > 0 else "  Speed: N/A (instant)")
        print(f"  Cache Hit: {cache_hit}")
        if cache_hit:
            speedup = upload_time_1 / upload_time_4 if upload_time_4 > 0 else float('inf')
            print(f"  Speedup: {speedup:.1f}x faster")
    else:
        print("✗ Upload failed")
    
    # Test 5: Cache hit with bytes
    print("\n[Test 5] Cache Hit (Bytes)")
    print("-" * 70)
    with open(file_path, "rb") as f:
        file_bytes = f.read()
    start_time = time.time()
    url5 = await client.aupload_file(file_bytes)
    upload_time_5 = time.time() - start_time
    
    if url5:
        cache_hit = url1 == url5
        print(f"{'✓' if cache_hit else '✗'} Upload successful")
        print(f"  Time: {upload_time_5:.3f} seconds")
        print(f"  Speed: {file_size / upload_time_5 / 1024 / 1024:.2f} MB/s" if upload_time_5 > 0 else "  Speed: N/A (instant)")
        print(f"  Cache Hit: {cache_hit}")
        if cache_hit:
            speedup = upload_time_1 / upload_time_5 if upload_time_5 > 0 else float('inf')
            print(f"  Speedup: {speedup:.1f}x faster")
    else:
        print("✗ Upload failed")
    
    # Test 6: Multiple sequential cache hits (performance test)
    print("\n[Test 6] Multiple Sequential Cache Hits (10 uploads)")
    print("-" * 70)
    cache_times: list[float] = []
    for i in range(10):
        start_time = time.time()
        url = await client.aupload_file(file_path)
        elapsed = time.time() - start_time
        cache_times.append(elapsed)
        if url != url1:
            print(f"  ⚠️  Upload {i+1}: Cache miss detected!")
    
    if cache_times:
        avg_time = statistics.mean(cache_times)
        min_time = min(cache_times)
        max_time = max(cache_times)
        median_time = statistics.median(cache_times)
        
        print(f"  Average time: {avg_time*1000:.3f} ms")
        print(f"  Min time: {min_time*1000:.3f} ms")
        print(f"  Max time: {max_time*1000:.3f} ms")
        print(f"  Median time: {median_time*1000:.3f} ms")
        if len(cache_times) > 1:
            stdev = statistics.stdev(cache_times)
            print(f"  Std deviation: {stdev*1000:.3f} ms")
    
    # Test 7: Concurrent cache hits
    print("\n[Test 7] Concurrent Cache Hits (5 parallel uploads)")
    print("-" * 70)
    
    async def timed_upload(index: int) -> tuple[int, float, str | None]:
        """Upload file and return timing."""
        start = time.time()
        url = await client.aupload_file(file_path)
        elapsed = time.time() - start
        return index, elapsed, url
    
    concurrent_start = time.time()
    tasks = [timed_upload(i) for i in range(5)]
    results = await asyncio.gather(*tasks)
    concurrent_total = time.time() - concurrent_start
    
    concurrent_times: list[float] = []
    all_urls_match = True
    for index, elapsed, url in results:
        concurrent_times.append(elapsed)
        if url != url1:
            all_urls_match = False
            print(f"  ⚠️  Upload {index+1}: Cache miss detected!")
    
    if concurrent_times:
        avg_time = statistics.mean(concurrent_times)
        print(f"  Total wall-clock time: {concurrent_total*1000:.3f} ms")
        print(f"  Average per upload: {avg_time*1000:.3f} ms")
        print(f"  All URLs match: {all_urls_match}")
    
    # Summary
    print("\n" + "=" * 70)
    print("Summary")
    print("=" * 70)
    print(f"Initial upload (cache miss): {upload_time_1:.3f} seconds")
    if upload_time_2 > 0:
        print(f"Cache hit (path): {upload_time_2:.3f} seconds ({upload_time_1/upload_time_2:.1f}x faster)")
    if upload_time_3 > 0:
        print(f"Cache hit (Path): {upload_time_3:.3f} seconds ({upload_time_1/upload_time_3:.1f}x faster)")
    if upload_time_4 > 0:
        print(f"Cache hit (PIL): {upload_time_4:.3f} seconds ({upload_time_1/upload_time_4:.1f}x faster)")
    if upload_time_5 > 0:
        print(f"Cache hit (bytes): {upload_time_5:.3f} seconds ({upload_time_1/upload_time_5:.1f}x faster)")
    
    if cache_times:
        avg_cache_time = statistics.mean(cache_times)
        print(f"\nAverage cache hit time: {avg_cache_time*1000:.3f} ms")
        print(f"Cache efficiency: {upload_time_1/avg_cache_time:.1f}x faster than initial upload")
    
    # Cache statistics
    print(f"\nCache Statistics:")
    print(f"  Cache size: {len(client._upload_cache)} entries")
    print(f"  Cache max size: {client._upload_cache.maxsize} entries")
    print(f"  Cache TTL: {client._upload_cache.ttl} seconds")
    
    await client.aclose()
    print("\n✓ Test completed")


if __name__ == "__main__":
    file_path = "0.png"
    if not os.path.exists(file_path):
        print(f"Error: {file_path} not found in current directory")
        print(f"Current directory: {os.getcwd()}")
    else:
        asyncio.run(test_upload_speed_and_cache(file_path))

