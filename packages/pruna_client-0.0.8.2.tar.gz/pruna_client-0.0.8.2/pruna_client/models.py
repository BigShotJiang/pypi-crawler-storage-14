"""Data models for Pruna API responses."""
from dataclasses import dataclass, field
from enum import Enum
from typing import Any

from pruna_client.logging import logger


class PredictionStatus(str, Enum):
    """Current status of the prediction."""

    STARTING = "starting"
    PROCESSING = "processing"
    SUCCEEDED = "succeeded"
    FAILED = "failed"
    CANCELED = "canceled"


class PredictionErrorCode(str, Enum):
    """Error code for programmatic handling."""

    INVALID_INPUT = "INVALID_INPUT"
    MODEL_ERROR = "MODEL_ERROR"
    TIMEOUT = "TIMEOUT"
    QUOTA_EXCEEDED = "QUOTA_EXCEEDED"
    INTERNAL_ERROR = "INTERNAL_ERROR"


@dataclass
class Error:
    """Unique request identifier for debugging."""

    request_id: str


@dataclass
class PredictionError:
    """Error details for a failed prediction."""

    code: PredictionErrorCode
    message: str
    details: str | None = None

    @classmethod
    def from_dict(
        cls, error_data: dict[str, Any] | None
    ) -> "PredictionError | dict[str, Any]":
        """Parse error data into PredictionError model."""
        if not error_data:
            return error_data
        try:
            code_str = error_data.get("code", "")
            code = (
                PredictionErrorCode(code_str)
                if code_str
                else PredictionErrorCode.INTERNAL_ERROR
            )
            return cls(
                code=code,
                message=error_data.get("message", ""),
                details=error_data.get("details"),
            )
        except (ValueError, KeyError):
            logger.error(f"Failed to parse error data: {error_data}")
            return error_data


@dataclass
class OutputFile:
    """Details of a generated content file."""

    url: str
    filename: str
    content_type: str
    size: int


@dataclass
class FileUploadResponse:
    """Response for a file upload."""

    id: str
    filename: str
    content_type: str
    size: int
    etag: str
    checksums: dict[str, str]
    metadata: dict[str, Any]
    created_at: str
    expires_at: str
    urls: dict[str, str]

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "FileUploadResponse | dict[str, Any]":
        """Parse file upload response into FileUploadResponse model."""
        try:
            return cls(
                id=data.get("id", ""),
                filename=data.get("filename", ""),
                content_type=data.get("content_type", ""),
                size=data.get("size", 0),
                etag=data.get("etag", ""),
                checksums=data.get("checksums", {}),
                metadata=data.get("metadata", {}),
                created_at=data.get("created_at", ""),
                expires_at=data.get("expires_at", ""),
                urls=data.get("urls", {}),
            )
        except Exception:
            logger.error(f"Failed to parse file upload response: {data}")
            return data


@dataclass
class PredictionResponse:
    """Initial response when a prediction is created."""

    id: str
    model: str
    input: dict[str, Any]
    status_url: str

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "PredictionResponse | dict[str, Any]":
        """Parse prediction creation response into PredictionResponse model."""
        try:
            # Handle both status_url and get_url field names
            status_url = data.get("status_url") or data.get("get_url", "")
            return cls(
                id=data.get("id", ""),
                model=data.get("model", ""),
                input=data.get("input", {}),
                status_url=status_url,
            )
        except Exception:
            logger.error(f"Failed to parse prediction creation response: {data}")
            return data


@dataclass
class PredictionStatusResponse:
    """Status response for a prediction."""

    status: PredictionStatus
    delivery_url: str | None = None
    message: str | None = None
    error: PredictionError | None = None

    @classmethod
    def from_dict(
        cls, data: dict[str, Any]
    ) -> "PredictionStatusResponse | dict[str, Any]":
        """Parse status response into PredictionStatusResponse model."""
        try:
            status_str = data.get("status", "")
            status = (
                PredictionStatus(status_str)
                if status_str
                else PredictionStatus.PROCESSING
            )
            error_data = data.get("error")
            error = PredictionError.from_dict(error_data) if error_data else None
            return cls(
                status=status,
                delivery_url=data.get("delivery_url"),
                message=data.get("message"),
                error=error,
            )
        except Exception:
            logger.error(f"Failed to parse status response: {data}")
            return data


@dataclass
class Response:
    """Unified response class for Pruna API predictions."""

    id: str
    model: str
    inputs: dict[str, Any]
    status: PredictionStatus = PredictionStatus.SUCCEEDED
    response: (
        PredictionStatusResponse
        | PredictionResponse
        | FileUploadResponse
        | dict[str, Any]
    ) = field(default_factory=dict)
