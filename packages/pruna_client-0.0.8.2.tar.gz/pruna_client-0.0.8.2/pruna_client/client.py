"""Pruna API client for synchronous and asynchronous image generation and editing."""
import asyncio
import base64
import hashlib
import os
import random
import time
from io import BytesIO
from pathlib import Path
from typing import Any, Callable

import httpx
from cachetools import TTLCache
from PIL import Image

from pruna_client.logging import logger
from pruna_client.models import PredictionStatus, Response

DEFAULT_POLL_INTERVAL = float(os.getenv("DEFAULT_PRUNA_POLL_INTERVAL", "0.5"))
DEFAULT_MAX_WAIT = float(os.getenv("DEFAULT_PRUNA_MAX_WAIT", "600"))
CACHE_MAXSIZE = int(os.getenv("CACHE_MAXSIZE", 10000))
CACHE_TTL = int(os.getenv("CACHE_TTL", "600"))
    
class PrunaClient:
    """Client for making synchronous and asynchronous requests to Pruna API."""

    DEFAULT_BASE_URL = "https://api.pruna.ai/v1"

    def __init__(
        self,
        api_key: str | None = None,
        max_retries: int = 3,
        backoff_factor: float = 1.0,
        retry_on_status: list[int] | None = None,
        timeout: float = 60.0,
        **kwargs: Any,
    ):
        """
        Initialize Pruna API client.

        Args:
            api_key: Your Pruna API key. If not provided, will use PRUNA_API_KEY env var.
            max_retries: Maximum number of retry attempts for failed requests. Defaults to 3.
            backoff_factor: Multiplier for exponential backoff delay. Defaults to 1.0.
            retry_on_status: List of HTTP status codes to retry on. Defaults to [429, 500, 502, 503, 504].
            timeout: Request timeout in seconds. Defaults to 60.0.
            **kwargs: Additional parameters to pass to the httpx.Client.

        Returns:
            PrunaClient object.

        Raises:
            ValueError: If API key is not provided and PRUNA_API_KEY environment variable is not set.
            httpx.RequestError: If the client fails to initialize.

        Example:
            >>> from pruna_client import PrunaClient
            >>> # Using API key directly
            >>> client = PrunaClient(api_key="your-api-key")
            >>> # Using environment variable
            >>> import os
            >>> os.environ["PRUNA_API_KEY"] = "your-api-key"
            >>> client = PrunaClient()
            >>> # With custom timeout and retries
            >>> client = PrunaClient(api_key="your-api-key", timeout=120.0, max_retries=5)
        """
        self.api_key = api_key or os.getenv("PRUNA_API_KEY")
        if not self.api_key:
            raise ValueError(
                "API key must be provided or set as PRUNA_API_KEY environment variable"
            )

        self.base_url = self.DEFAULT_BASE_URL
        self.base_headers = {"apikey": self.api_key, "Content-Type": "application/json"}
        self.max_retries = max_retries
        self.backoff_factor = backoff_factor
        self.retry_on_status = retry_on_status or [429, 500, 502, 503, 504]
        self.timeout = timeout

        # Configure granular timeouts for better performance
        timeout_config = (
            kwargs.pop("timeout")
            if "timeout" in kwargs
            else httpx.Timeout(
                timeout=timeout,
                connect=5.0,  # Reduced from 10.0 for faster connection establishment
                read=timeout,
                write=10.0,  # Reduced from 30.0 to fail faster on slow writes
                pool=2.0,  # Reduced from 5.0 to reduce connection pool overhead
            )
        )

        limits_config = (
            kwargs.pop("limits")
            if "limits" in kwargs
            else httpx.Limits(
                max_keepalive_connections=20,  # Increased for better connection reuse in batch operations
                max_connections=100,  # Increased to handle concurrent batch requests
                keepalive_expiry=300.0,  # Keep connections alive for 5 minutes for better reuse across requests
            )
        )

        # Define shared client arguments once
        http_client_args = {
            "headers": {"apikey": self.api_key},
            "timeout": timeout_config,
            "limits": limits_config,
            "http2": kwargs.pop(
                "http2", True
            ),  # Enable HTTP/2 by default for better performance
            "follow_redirects": kwargs.pop("follow_redirects", True),
        }
        # Pass remaining kwargs to both clients
        self.client = httpx.Client(**http_client_args, **kwargs)
        self._async_client = httpx.AsyncClient(**http_client_args, **kwargs)

        # Initialize TTL cache for file uploads (10 minutes)
        self._upload_cache = TTLCache(maxsize=CACHE_MAXSIZE, ttl=CACHE_TTL)

    def _run_async(self, coro: Any) -> Any:
        """Run an async coroutine synchronously."""
        return asyncio.run(coro)

    async def _process_batch(
        self,
        items: list[Any],
        async_func: Callable[[Any], Any],
        error_handler: Callable[[Any, int, Exception], Any] | None = None,
    ) -> list[Any]:
        """
        Generic batch processing helper that executes async functions concurrently.

        Args:
            items: List of items to process
            async_func: Async function to apply to each item
            error_handler: Optional function to handle errors (item, index, exception) -> result

        Returns:
            List of results in the same order as input items
        """
        if not items:
            return []

        tasks = [async_func(item) for item in items]
        results = await asyncio.gather(*tasks, return_exceptions=True)

        final_results: list[Any] = []
        for i, result in enumerate(results):
            if isinstance(result, Exception):
                if error_handler:
                    final_results.append(error_handler(items[i], i, result))
                else:
                    logger.error(
                        f"Error processing item at index {i}: {result}", exc_info=True
                    )
                    final_results.append(None)
            else:
                final_results.append(result)

        return final_results

    def _create_response(
        self,
        data: dict[str, Any],
        model: str,
        inputs: dict[str, Any],
        default_id: str = "unknown",
        is_error_response: bool = False,
    ) -> Response:
        """Helper method to create Response objects from API data."""
        # Always store response as dict for consistent .get() access
        response_data: dict[str, Any] = data

        # Determine status from data
        # If there's an error field or this is an HTTP error response, always mark as failed
        if data.get("error") or is_error_response:
            status = PredictionStatus.FAILED
        else:
            status_str = data.get("status", "failed")
            try:
                status = PredictionStatus(status_str)
            except ValueError:
                status = PredictionStatus.FAILED

        return Response(
            id=data.get("id", default_id),
            model=model,
            inputs=inputs,
            status=status,
            response=response_data,
        )

    async def agenerate(
        self, model: str, input: dict[str, Any], sync: bool = True, **kwargs: Any
    ) -> Response:
        """
        Async version of generate - generate content with any model asynchronously.

        Args:
            model: Model name (e.g., "p-image", "p-image-edit")
            input: Input parameters for the model
            sync: If True, use synchronous mode (waits for completion). If False, use async mode (returns immediately).
            **kwargs: Additional parameters to merge into input

        Returns:
            Response object.

        Raises:
            httpx.RequestError: For network or HTTP errors

        Example:
            >>> import asyncio
            >>> from pruna_client import PrunaClient
            >>> async def main():
            ...     client = PrunaClient(api_key="your-api-key")
            ...     # Synchronous mode (waits for completion)
            ...     response = await client.agenerate(
            ...         model="p-image",
            ...         input={"prompt": "A beautiful sunset"},
            ...         sync=True
            ...     )
            ...     # Asynchronous mode (returns immediately)
            ...     response = await client.agenerate(
            ...         model="p-image",
            ...         input={"prompt": "A forest"},
            ...         sync=False
            ...     )
            ...     # Poll for completion
            ...     final_response = client.poll_status(response=response)
            ...     await client.aclose()
            >>> asyncio.run(main())
        """
        headers = self.base_headers.copy()
        headers["Model"] = model

        if sync:
            headers["Try-Sync"] = "true"

        # Merge input and kwargs efficiently
        merged_input = {**input, **kwargs}
        payload = {"input": merged_input}

        response = await self._arequest_with_retry(
            "post",
            f"{self.base_url}/predictions",
            headers=headers,
            json=payload,
            timeout=self.timeout,
        )

        # Handle HTTP errors gracefully - parse error responses instead of raising
        if not response.is_success:
            try:
                data = response.json()
                return self._create_response(data, model, input, is_error_response=True)
            except ValueError:
                response.raise_for_status()

        data = response.json()

        # Synchronous mode - response contains generation_url and status
        if sync:
            return self._create_response(data, model, input)

        # Asynchronous mode - response contains prediction ID and get_url/status_url
        prediction_id = data.get("id")
        get_url = data.get("get_url") or data.get("status_url")

        if not prediction_id or not get_url:
            raise ValueError(
                "Missing prediction ID or get_url/status_url in async response"
            )

        # Store as dict for compatibility with .get() calls in tests
        # Ensure get_url is present for backward compatibility
        response_dict = data.copy()
        if "get_url" not in response_dict and get_url:
            response_dict["get_url"] = get_url

        return Response(
            id=prediction_id,
            model=data.get("model", model),
            inputs=data.get("input", input),
            status=PredictionStatus.STARTING,
            response=response_dict,
        )

    async def agenerate_batch(
        self,
        requests: list[dict[str, Any]],
    ) -> list[Response]:
        """
        Async version of generate_batch - generate content for multiple requests concurrently.

        Args:
            requests: List of request dictionaries, each containing:
                - model: Model name (required)
                - input: Input parameters dict (required)
                - sync: Boolean for sync/async mode (optional, defaults to True)
                - Additional kwargs can be included in the dict

        Returns:
            List of Response objects in the same order as input requests.
            Failed requests will have status=FAILED.

        Example:
            >>> import asyncio
            >>> from pruna_client import PrunaClient
            >>> async def main():
            ...     client = PrunaClient(api_key="your-api-key")
            ...     requests = [
            ...         {"model": "p-image", "input": {"prompt": "A sunset"}, "sync": True},
            ...         {"model": "p-image", "input": {"prompt": "A forest"}, "sync": True},
            ...     ]
            ...     responses = await client.agenerate_batch(requests)
            ...     await client.aclose()
            >>> asyncio.run(main())
        """

        async def _process_request(request_dict: dict[str, Any]) -> Response:
            """Process a single request."""
            model = request_dict.get("model")
            input_data = request_dict.get("input")
            sync = request_dict.get("sync", True)

            if not model or input_data is None:
                raise ValueError("Request must contain 'model' and 'input' keys")

            # Extract any additional kwargs from the request dict
            excluded_keys = {"model", "input", "sync"}
            kwargs = {k: v for k, v in request_dict.items() if k not in excluded_keys}

            return await self.agenerate(
                model=model, input=input_data, sync=sync, **kwargs
            )

        def _error_handler(
            request_dict: dict[str, Any], index: int, exc: Exception
        ) -> Response:
            """Handle errors in batch processing."""
            logger.error(
                f"Error processing batch request at index {index}: {exc}",
                exc_info=True,
            )
            return self._create_response(
                {"error": str(exc)},
                request_dict.get("model", None),
                request_dict.get("input", {}),
                default_id="failed",
                is_error_response=True,
            )

        return await self._process_batch(requests, _process_request, _error_handler)

    def generate(
        self, model: str, input: dict[str, Any], sync: bool = True, **kwargs: Any
    ) -> Response:
        """
        General method to generate content with any model.

        Args:
            model: Model name (e.g., "p-image", "p-image-edit")
            input: Input parameters for the model
            sync: If True, use synchronous mode (waits for completion). If False, use async mode (returns immediately).
            **kwargs: Additional  parameters to merge into input

        Returns:
            Response object.

        Raises:
            httpx.RequestError: For network or HTTP errors

        Example:
            >>> from pruna_client import PrunaClient
            >>> from pruna_client.models import PredictionStatus
            >>> client = PrunaClient(api_key="your-api-key")
            >>> # Synchronous mode (waits for completion)
            >>> response = client.generate(
            ...     model="p-image",
            ...     input={"prompt": "A beautiful sunset"},
            ...     sync=True
            ... )
            >>> # Access the generated content URL
            >>> if response.status == PredictionStatus.SUCCEEDED:
            ...     generation_url = response.response.get("generation_url")
            ...     if generation_url:
            ...         # Download the content
            ...         content = client.download_content(generation_url)
            ...         with open("output.jpg", "wb") as f:
            ...             f.write(content)
            >>> # Asynchronous mode (returns immediately)
            >>> response = client.generate(
            ...     model="p-image",
            ...     input={"prompt": "A forest"},
            ...     sync=False
            ... )
            >>> # Poll for completion
            >>> final_response = client.poll_status(response=response)
            >>> if final_response.status == PredictionStatus.SUCCEEDED:
            ...     generation_url = final_response.response.get("generation_url")
            ...     if generation_url:
            ...         content = client.download_content(generation_url)
            ...         with open("output.jpg", "wb") as f:
            ...             f.write(content)
            >>> client.close()
        """
        headers = self.base_headers.copy()
        headers["Model"] = model

        if sync:
            headers["Try-Sync"] = "true"

        # Merge input and kwargs efficiently
        merged_input = {**input, **kwargs}
        payload = {"input": merged_input}

        response = self._request_with_retry(
            "post",
            f"{self.base_url}/predictions",
            headers=headers,
            json=payload,
            timeout=self.timeout,
        )
        # Handle HTTP errors gracefully - parse error responses instead of raising
        if not response.is_success:
            try:
                data = response.json()
                return self._create_response(data, model, input, is_error_response=True)
            except ValueError:
                response.raise_for_status()

        data = response.json()

        # Synchronous mode - response contains generation_url and status
        if sync:
            return self._create_response(data, model, input)

        # Asynchronous mode - response contains prediction ID and get_url/status_url
        prediction_id = data.get("id")
        get_url = data.get("get_url") or data.get("status_url")

        if not prediction_id or not get_url:
            raise ValueError(
                "Missing prediction ID or get_url/status_url in async response"
            )

        # Store as dict for compatibility with .get() calls in tests
        # Ensure get_url is present for backward compatibility
        response_dict = data.copy()
        if "get_url" not in response_dict and get_url:
            response_dict["get_url"] = get_url

        return Response(
            id=prediction_id,
            model=data.get("model", model),
            inputs=data.get("input", input),
            status=PredictionStatus.STARTING,
            response=response_dict,
        )

    def generate_batch(
        self,
        requests: list[dict[str, Any]],
    ) -> list[Response]:
        """
        Generate content for multiple requests concurrently.

        Args:
            requests: List of request dictionaries, each containing:
                - model: Model name (required)
                - input: Input parameters dict (required)
                - sync: Boolean for sync/async mode (optional, defaults to True)
                - Additional kwargs can be included in the dict

        Returns:
            List of Response objects in the same order as input requests.
            Failed requests will have status=FAILED.

        Example:
            >>> from pruna_client import PrunaClient
            >>> client = PrunaClient(api_key="your-api-key")
            >>> requests = [
            ...     {"model": "p-image", "input": {"prompt": "A sunset"}, "sync": True},
            ...     {"model": "p-image", "input": {"prompt": "A forest"}, "sync": True},
            ... ]
            >>> responses = client.generate_batch(requests)
            >>> client.close()
        """
        return self._run_async(self.agenerate_batch(requests))

    def generate_text_to_image(
        self, model: str, prompt: str, sync: bool = True, **kwargs: Any
    ) -> Response:
        """
        Generate an image from a text prompt.

        Args:
            model: Model name (e.g., "p-image")
            prompt: Text description of the image to generate
            sync: If True, use synchronous mode (waits for completion). If False, use async mode (returns immediately).
            **kwargs: Additional parameters to pass to the API

        Returns:
            Response object containing the result.

        Raises:
            httpx.RequestError: For network or HTTP errors

        Example:
            >>> from pruna_client import PrunaClient
            >>> from pruna_client.models import PredictionStatus
            >>> client = PrunaClient(api_key="your-api-key")
            >>> response = client.generate_text_to_image(
            ...     model="p-image",
            ...     prompt="A beautiful sunset over the ocean",
            ...     sync=True
            ... )
            >>> # Access the generated image URL
            >>> if response.status == PredictionStatus.SUCCEEDED:
            ...     generation_url = response.response.get("generation_url")
            ...     if generation_url:
            ...         # Download the image
            ...         image_bytes = client.download_content(generation_url)
            ...         with open("generated_image.jpg", "wb") as f:
            ...             f.write(image_bytes)
            >>> client.close()
        """
        input_data = {"prompt": prompt, **kwargs}
        return self.generate(model=model, input=input_data, sync=sync)

    def generate_image_edit(
        self,
        model: str,
        prompt: str,
        images: list[str | Path | Image.Image | bytes],
        sync: bool = True,
        **kwargs: Any,
    ) -> Response:
        """
        Edit images using p-image-edit model.

        This method handles file uploads and then makes the editing request.

        Args:
            model: Model name (e.g., "p-image-edit")
            prompt: Text description of the desired edit
            images: List of images to upload and edit (1-5 images). Each can be:
                - str: File path or data URI (e.g., "data:image/png;base64,...")
                - Path: pathlib.Path object
                - Image.Image: PIL Image object
                - bytes: Raw file content
            sync: If True, use synchronous mode (waits for completion). If False, use async mode (returns immediately).
            **kwargs: Additional parameters to pass to the API

        Returns:
            Response object containing the result.

        Raises:
            httpx.RequestError: For network or HTTP errors
            IOError: For file reading errors

        Example:
            >>> from pruna_client import PrunaClient
            >>> from pruna_client.models import PredictionStatus
            >>> from pathlib import Path
            >>> client = PrunaClient(api_key="your-api-key")
            >>> # Using file path
            >>> response = client.generate_image_edit(
            ...     model="p-image-edit",
            ...     prompt="Make it more vibrant and colorful",
            ...     images=["path/to/image.jpg"],
            ...     sync=True
            ... )
            >>> # Access the generated image URL
            >>> if response.status == PredictionStatus.SUCCEEDED:
            ...     generation_url = response.response.get("generation_url")
            ...     if generation_url:
            ...         image_bytes = client.download_content(generation_url)
            ...         with open("edited_image.jpg", "wb") as f:
            ...             f.write(image_bytes)
            >>> # Using PIL Image
            >>> from PIL import Image
            >>> img = Image.open("input.jpg")
            >>> response = client.generate_image_edit(
            ...     model="p-image-edit",
            ...     prompt="Add a sunset in the background",
            ...     images=[img],
            ...     sync=True
            ... )
            >>> if response.status == PredictionStatus.SUCCEEDED:
            ...     generation_url = response.response.get("generation_url")
            ...     if generation_url:
            ...         image_bytes = client.download_content(generation_url)
            ...         with open("edited_image.jpg", "wb") as f:
            ...             f.write(image_bytes)
            >>> client.close()
        """

        # Upload files concurrently and get their URLs
        uploaded_urls = self.upload_file_batch(images)

        # Check if any uploads failed
        if None in uploaded_urls:
            failed_count = uploaded_urls.count(None)
            raise ValueError(
                f"Failed to upload {failed_count} out of {len(images)} image(s). "
                "Check API key permissions and file format."
            )

        # Prepare input data for editing
        input_data = {"prompt": prompt, "images": uploaded_urls, **kwargs}
        return self.generate(model=model, input=input_data, sync=sync)

    def generate_text_to_video(
        self, model: str, prompt: str, sync: bool = False, **kwargs: Any
    ) -> Response:
        """
        Generate a video from a text prompt.

        Args:
            model: Model name (e.g., "wan-t2v")
            prompt: Text description of the video to generate
            sync: If True, use synchronous mode (waits for completion). If False, use async mode (returns immediately).
            **kwargs: Additional parameters to pass to the API (e.g., num_frames, resolution, aspect_ratio, frames_per_second)

        Returns:
            Response object containing the result.
            For successful sync requests, response.response["output"] contains video bytes.

        Raises:
            httpx.RequestError: For network or HTTP errors

        Example:
            >>> from pruna_client import PrunaClient
            >>> from pruna_client.models import PredictionStatus
            >>> client = PrunaClient(api_key="your-api-key")
            >>> # Asynchronous mode (recommended for video generation)
            >>> response = client.generate_text_to_video(
            ...     model="wan-t2v",
            ...     prompt="A cat playing with a ball of yarn",
            ...     sync=False
            ... )
            >>> # Poll for completion
            >>> final_response = client.poll_status(response=response)
            >>> if final_response.status == PredictionStatus.SUCCEEDED:
            ...     # Access the generated video URL
            ...     generation_url = final_response.response.get("generation_url")
            ...     if generation_url:
            ...         # Download the video
            ...         video_bytes = client.download_content(generation_url)
            ...         with open("output.mp4", "wb") as f:
            ...             f.write(video_bytes)
            >>> client.close()
        """
        input_data = {"prompt": prompt, **kwargs}
        return self.generate(model=model, input=input_data, sync=sync)

    def generate_image_to_video(
        self,
        model: str,
        prompt: str,
        image: str | Image.Image,
        sync: bool = False,
        **kwargs: Any,
    ) -> Response:
        """
        Generate a video from an image and text prompt.

        This method handles image upload and then makes the video generation request.

        Args:
            model: Model name (e.g., "wan-i2v")
            prompt: Text description of the desired animation/motion
            image: Image to animate. Can be:
                - str: File path or data URI (e.g., "data:image/png;base64,...")
                - Image.Image: PIL Image object
            sync: If True, use synchronous mode (waits for completion). If False, use async mode (returns immediately).
            **kwargs: Additional parameters to pass to the API (e.g., num_frames, resolution, frames_per_second)

        Returns:
            Response object containing the result.
            For successful sync requests, response.response["output"] contains video bytes.

        Raises:
            httpx.RequestError: For network or HTTP errors
            IOError: For file reading errors

        Example:
            >>> from pruna_client import PrunaClient
            >>> from pruna_client.models import PredictionStatus
            >>> from PIL import Image
            >>> client = PrunaClient(api_key="your-api-key")
            >>> # Using file path
            >>> response = client.generate_image_to_video(
            ...     model="wan-i2v",
            ...     prompt="Gentle waves on the ocean",
            ...     image="path/to/image.jpg",
            ...     sync=False
            ... )
            >>> # Using PIL Image
            >>> img = Image.open("input.jpg")
            >>> response = client.generate_image_to_video(
            ...     model="wan-i2v",
            ...     prompt="Leaves swaying in the wind",
            ...     image=img,
            ...     sync=False
            ... )
            >>> # Poll for completion
            >>> final_response = client.poll_status(response=response)
            >>> if final_response.status == PredictionStatus.SUCCEEDED:
            ...     # Access the generated video URL
            ...     generation_url = final_response.response.get("generation_url")
            ...     if generation_url:
            ...         # Download the video
            ...         video_bytes = client.download_content(generation_url)
            ...         with open("output.mp4", "wb") as f:
            ...             f.write(video_bytes)
            >>> client.close()
        """
        # Upload image and get URL
        uploaded_url = self.upload_file(image)

        # Prepare input data for video generation
        input_data = {"prompt": prompt, "image": uploaded_url, **kwargs}
        return self.generate(model=model, input=input_data, sync=sync)

    def generate_video_edit(
        self,
        model: str,
        prompt: str,
        sync: bool = False,
        src_video: str | None = None,
        src_ref_images: list[str | Path | Image.Image | bytes] | None = None,
        **kwargs: Any,
    ) -> Response:
        """
        Generate or edit videos using the VACE model.

        This method supports video generation from text, video editing, and character-consistent animation.

        Args:
            model: Model name (e.g., "vace")
            prompt: Text description of the video content
            sync: If True, use synchronous mode (waits for completion). If False, use async mode (returns immediately).
            src_video: Optional source video file path or URL to edit or transform
            src_ref_images: Optional reference images for character consistency (1-3 images). Each can be:
                - str: File path, URL, or data URI (e.g., "data:image/png;base64,...")
                - Path: pathlib.Path object
                - Image.Image: PIL Image object
                - bytes: Raw file content
            **kwargs: Additional parameters to pass to the API (e.g., size, frame_num, speed_mode, sample_steps, seed)

        Returns:
            Response object containing the result.
            For successful sync requests, response.response["output"] contains video bytes.

        Raises:
            httpx.RequestError: For network or HTTP errors
            IOError: For file reading errors

        Example:
            >>> from pruna_client import PrunaClient
            >>> from pruna_client.models import PredictionStatus
            >>> from PIL import Image
            >>> client = PrunaClient(api_key="your-api-key")
            >>> # Generate video from text only
            >>> response = client.generate_video_edit(
            ...     model="vace",
            ...     prompt="A cat walking through a garden",
            ...     sync=False
            ... )
            >>> # Edit existing video
            >>> response = client.generate_video_edit(
            ...     model="vace",
            ...     prompt="Add a sunset in the background",
            ...     src_video="input.mp4",
            ...     sync=False
            ... )
            >>> # Character-consistent animation with reference images
            >>> ref_images = ["character1.jpg", "character2.jpg"]
            >>> response = client.generate_video_edit(
            ...     model="vace",
            ...     prompt="Character walking and talking",
            ...     src_ref_images=ref_images,
            ...     sync=False,
            ... )
            >>> # Poll for completion
            >>> final_response = client.poll_status(response=response)
            >>> if final_response.status == PredictionStatus.SUCCEEDED:
            ...     video_bytes = final_response.response["output"]
            ...     with open("output.mp4", "wb") as f:
            ...         f.write(video_bytes)
            >>> client.close()
        """
        input_data = {"prompt": prompt, **kwargs}

        # Upload source video if provided
        if src_video:
            uploaded_video_url = self.upload_file(src_video)
            if uploaded_video_url:
                input_data["src_video"] = uploaded_video_url
            else:
                raise ValueError("Failed to upload source video")

        # Upload reference images if provided
        if src_ref_images:
            uploaded_ref_urls = self.upload_file_batch(src_ref_images)
            # Add uploaded URLs to input_data if all uploads succeeded
            if uploaded_ref_urls and all(url is not None for url in uploaded_ref_urls):
                input_data["src_ref_images"] = uploaded_ref_urls
            else:
                failed_count = (
                    uploaded_ref_urls.count(None)
                    if uploaded_ref_urls
                    else len(src_ref_images)
                )
                raise ValueError(
                    f"Failed to upload {failed_count} out of {len(src_ref_images)} reference image(s)"
                )

        return self.generate(model=model, input=input_data, sync=sync)

    def poll_status(
        self,
        status_url: str | None = None,
        response: Response | None = None,
    ) -> Response:
        """
        Poll the status endpoint until the prediction is complete.

        Args:
            status_url: URL to poll for status (can be provided directly or via response)
            response: Response object from async generate() call

        Returns:
            Response object with final status and outputs.

        Raises:
            httpx.RequestError: For network or HTTP errors
            ValueError: If neither status_url nor response with get_url is provided

        Example:
            >>> from pruna_client import PrunaClient
            >>> client = PrunaClient(api_key="your-api-key")
            >>> # Start async generation
            >>> response = client.generate(
            ...     model="p-image",
            ...     input={"prompt": "A sunset"},
            ...     sync=False
            ... )
            >>> # Poll for completion using response object
            >>> final_response = client.poll_status(response=response)
            >>> # Or poll using status URL directly
            >>> status_url = response.response.get("get_url")
            >>> final_response = client.poll_status(status_url=status_url)
            >>> client.close()
        """
        # Get status URL from response if provided
        if response:
            if isinstance(response.response, dict) and "get_url" in response.response:
                status_url = response.response["get_url"]
            elif (
                isinstance(response.response, dict)
                and "status_url" in response.response
            ):
                status_url = response.response["status_url"]

        if not status_url:
            raise ValueError(
                "Either status_url or response with outputs containing get_url must be provided"
            )

        if not status_url:
            raise ValueError("status_url cannot be None")

        headers = {"apikey": self.api_key}
        start_time = time.time()

        while True:
            http_response = self._request_with_retry(
                "get", status_url, headers=headers, timeout=self.timeout
            )
            http_response.raise_for_status()

            data = http_response.json()

            # Parse status from data
            status_str = data.get("status", "processing")
            try:
                status = PredictionStatus(status_str)
            except ValueError:
                status = PredictionStatus.PROCESSING

            # Check if completed or failed
            if status in [PredictionStatus.SUCCEEDED, PredictionStatus.FAILED]:
                return self._create_response(
                    data,
                    response.model if response else "unknown",
                    response.inputs if response else {},
                    default_id=response.id if response else "unknown",
                )

            # Determine wait time from headers or default
            poll_interval = self._get_header_float(
                http_response.headers, "X-Poll-Interval", DEFAULT_POLL_INTERVAL
            )
            max_wait = self._get_header_float(
                http_response.headers, "X-Max-Wait", DEFAULT_MAX_WAIT
            )

            # Check timeout
            if time.time() - start_time > max_wait:
                return self._create_response(
                    {"error": f"Timeout after {max_wait} seconds"},
                    response.model if response else "unknown",
                    response.inputs if response else {},
                    default_id=response.id if response else "timeout",
                )

            # Wait before next poll
            time.sleep(poll_interval)

    async def _arequest_with_retry(
        self,
        method: str,
        url: str,
        retry_on_exceptions: tuple[type[Exception], ...] = (
            httpx.NetworkError,
            httpx.TimeoutException,
        ),
        **kwargs: Any,
    ) -> httpx.Response:
        """
        Make an async HTTP request with retry and exponential backoff.

        Args:
            method: HTTP method ('get', 'post', etc.)
            url: URL to request
            retry_on_exceptions: Tuple of exception types to retry on
            **kwargs: Additional arguments to pass to httpx method

        Returns:
            httpx.Response object

        Raises:
            httpx.RequestError: If all retries are exhausted
        """
        last_exception = None

        for attempt in range(self.max_retries + 1):
            try:
                response = await self._async_client.request(method, url, **kwargs)

                # Check if status code indicates we should retry
                if response.status_code in self.retry_on_status:
                    if attempt < self.max_retries:
                        delay = self.backoff_factor * (2**attempt) + random.uniform(
                            0, 1
                        )
                        logger.warning(
                            f"Request failed with status {response.status_code}. "
                            f"Retrying in {delay:.2f}s (attempt {attempt + 1}/{self.max_retries})"
                        )
                        await asyncio.sleep(delay)
                        continue
                    else:
                        response.raise_for_status()

                return response

            except retry_on_exceptions as e:
                last_exception = e
                if attempt < self.max_retries:
                    delay = self.backoff_factor * (2**attempt) + random.uniform(0, 1)
                    logger.warning(
                        f"Request failed with {type(e).__name__}: {e}. "
                        f"Retrying in {delay:.2f}s (attempt {attempt + 1}/{self.max_retries})"
                    )
                    await asyncio.sleep(delay)
                else:
                    logger.error(
                        f"Request failed after {self.max_retries + 1} attempts"
                    )
                    raise

        # This should never be reached, but type checker needs it
        if last_exception:
            raise last_exception
        raise httpx.RequestError("Request failed")

    def _request_with_retry(
        self,
        method: str,
        url: str,
        retry_on_exceptions: tuple[type[Exception], ...] = (
            httpx.NetworkError,
            httpx.TimeoutException,
        ),
        **kwargs: Any,
    ) -> httpx.Response:
        """
        Make an HTTP request with retry and exponential backoff.

        Args:
            method: HTTP method ('get', 'post', etc.)
            url: URL to request
            retry_on_exceptions: Tuple of exception types to retry on
            **kwargs: Additional arguments to pass to httpx method

        Returns:
            httpx.Response object

        Raises:
            httpx.RequestError: If all retries are exhausted
        """
        last_exception = None

        for attempt in range(self.max_retries + 1):
            try:
                import time

                t_start = time.time()
                response = self.client.request(method, url, **kwargs)
                t_end = time.time()
                # Note: This timing includes network latency, server processing, and response body download
                logger.info(f"Request time: {t_end - t_start} seconds")
                # Check if status code indicates we should retry
                if response.status_code in self.retry_on_status:
                    if attempt < self.max_retries:
                        delay = self.backoff_factor * (2**attempt) + random.uniform(
                            0, 1
                        )
                        logger.warning(
                            f"Request failed with status {response.status_code}. "
                            f"Retrying in {delay:.2f}s (attempt {attempt + 1}/{self.max_retries})"
                        )
                        time.sleep(delay)
                        continue
                    else:
                        response.raise_for_status()

                return response

            except retry_on_exceptions as e:
                last_exception = e
                if attempt < self.max_retries:
                    delay = self.backoff_factor * (2**attempt) + random.uniform(0, 1)
                    logger.warning(
                        f"Request failed with {type(e).__name__}: {e}. "
                        f"Retrying in {delay:.2f}s (attempt {attempt + 1}/{self.max_retries})"
                    )
                    time.sleep(delay)
                else:
                    logger.error(
                        f"Request failed after {self.max_retries + 1} attempts"
                    )
                    raise

        # This should never be reached, but type checker needs it
        if last_exception:
            raise last_exception
        raise httpx.RequestError("Request failed")

    def _get_header_float(self, headers: Any, key: str, default: float) -> float:
        """Extract float value from header or return default."""
        if key in headers:
            try:
                return float(headers[key])
            except (ValueError, TypeError):
                pass
        return float(default)


    def _extract_file_url(self, data: dict[str, Any]) -> str | None:
        """Extract file URL from API response data."""
        # Try urls object first
        urls = data.get("urls", {})
        if isinstance(urls, dict):
            # Try common URL field names
            for key in ["url", "download", "access", "public", "cdn"]:
                if key in urls:
                    return urls[key]
            # If no standard key found, use first value
            if urls:
                return list(urls.values())[0]

        # Fallback: check if response has a direct 'url' field
        if "url" in data:
            return data["url"]

        # Fallback: construct URL from file ID
        file_id = data.get("id")
        if file_id:
            return f"{self.base_url}/files/{file_id}"

        return None

    def _normalize_file(
        self, file_input: str | Path | Image.Image | bytes | BytesIO
    ) -> tuple[BytesIO, str, str] | None:
        """
        Normalize file input to BytesIO, filename, and content type for upload.

        Args:
            file_input: Can be:
                - str: File path or data URI
                - Path: pathlib.Path object
                - Image.Image: PIL Image object
                - bytes: Raw file content
                - BytesIO: BytesIO buffer object

        Returns:
            Tuple of (BytesIO buffer, filename, content_type), or None if error
        """
        try:
            filename = "file.bin"
            content_type = "application/octet-stream"

            # Handle PIL Image
            if isinstance(file_input, Image.Image):
                buffer = BytesIO()
                file_input.save(buffer, format="PNG")
                buffer.seek(0)
                return buffer, "image.png", "image/png"

            # Handle bytes
            if isinstance(file_input, bytes):
                return BytesIO(file_input), filename, content_type
            
            # Handle BytesIO
            if isinstance(file_input, BytesIO):
                # Save current position
                original_position = file_input.tell()
                file_input.seek(0)
                buffer_content = file_input.read()
                file_input.seek(original_position)  # Restore position
                return BytesIO(buffer_content), filename, content_type

            # Handle Path object or string path
            file_path: Path | None = None
            if isinstance(file_input, Path):
                file_path = file_input
            elif isinstance(file_input, str):
                # Handle data URI
                if file_input.startswith("data:"):
                    # Format: data:mime/type;base64,<base64_string>
                    try:
                        header, encoded = file_input.split(",", 1)
                        # Extract mime type
                        if ";" in header:
                            mime = header.split(":")[1].split(";")[0]
                            content_type = mime
                            # Guess extension from mime
                            ext = mime.split("/")[-1]
                            filename = f"file.{ext}"

                        image_bytes = base64.b64decode(encoded)
                        return BytesIO(image_bytes), filename, content_type
                    except Exception:
                        logger.warning("Failed to parse data URI")
                        return None
                # Handle file path string
                file_path = Path(file_input)

            # Process file path if we have one
            if file_path and file_path.is_file():
                filename = file_path.name
                ext = file_path.suffix.lower()
                content_type_map = {
                    ".jpg": "image/jpeg",
                    ".jpeg": "image/jpeg",
                    ".png": "image/png",
                    ".gif": "image/gif",
                    ".webp": "image/webp",
                    ".mp4": "video/mp4",
                    ".mov": "video/quicktime",
                    ".avi": "video/x-msvideo",
                    ".webm": "video/webm",
                }
                content_type = content_type_map.get(ext, "application/octet-stream")

                with file_path.open("rb") as f:
                    return BytesIO(f.read()), filename, content_type

            return None

        except Exception as e:
            logger.error(f"Error normalizing file: {e}", exc_info=True)
            return None

    def upload_file(self, file_input: str | Path | Image.Image | bytes | BytesIO) -> str | None:
        """
        Upload a file to Pruna API with TTL caching.

        Args:
            file_input: Can be:
                - str: File path, URL, or data URI
                - Path: pathlib.Path object
                - Image.Image: PIL Image object
                - bytes: Raw file content
                - BytesIO: BytesIO buffer object

        Returns:
            File URL if successful, None otherwise

        Example:
            >>> from pruna_client import PrunaClient
            >>> from pathlib import Path
            >>> from PIL import Image
            >>> client = PrunaClient(api_key="your-api-key")
            >>> # Upload from file path
            >>> url = client.upload_file("path/to/image.jpg")
            >>> # Upload PIL Image
            >>> img = Image.open("input.jpg")
            >>> url = client.upload_file(img)
            >>> # Upload from Path object
            >>> path = Path("image.png")
            >>> url = client.upload_file(path)
            >>> # Upload bytes
            >>> with open("image.jpg", "rb") as f:
            ...     image_bytes = f.read()
            >>> url = client.upload_file(image_bytes)
            >>> # URLs are returned as-is (no upload needed)
            >>> url = client.upload_file("https://example.com/image.jpg")
            >>> client.close()
        """
        return self._run_async(self.aupload_file(file_input))

    async def aupload_file(
        self, file_input: str | Path | Image.Image | bytes | BytesIO
    ) -> str | None:
        """
        Async version of upload_file - upload a file to Pruna API with TTL caching.

        Args:
            file_input: Can be:
                - str: File path, URL, or data URI
                - Path: pathlib.Path object
                - Image.Image: PIL Image object
                - bytes: Raw file content
                - BytesIO: BytesIO buffer object

        Returns:
            File URL if successful, None otherwise
        """
        # If input is already a URL, return it directly
        if isinstance(file_input, str) and (
            file_input.startswith("http://") or file_input.startswith("https://")
        ):
            return file_input

        try:
            # For PIL Images loaded from files, use original file bytes for cache key
            # to ensure cache hits when the same file is uploaded via path or PIL Image
            cache_key: str | None = None
            if isinstance(file_input, Image.Image):
                # Check if PIL Image has a filename attribute (from Image.open())
                if hasattr(file_input, "filename") and file_input.filename:
                    file_path = Path(file_input.filename)
                    if file_path.is_file():
                        # Use original file bytes for cache key
                        with file_path.open("rb") as f:
                            original_file_content = f.read()
                        cache_key = hashlib.sha256(original_file_content).hexdigest()
                        # Check cache before normalizing
                        cached_url = self._upload_cache.get(cache_key)
                        if cached_url:
                            logger.debug(f"Cache hit for PIL Image from file: {cache_key[:8]}...")
                            return cached_url
            
            # For bytes input, check cache early using the bytes directly
            if isinstance(file_input, bytes):
                cache_key = hashlib.sha256(file_input).hexdigest()
                cached_url = self._upload_cache.get(cache_key)
                if cached_url:
                    logger.debug(f"Cache hit for bytes input: {cache_key[:8]}...")
                    return cached_url
            
            # For BytesIO or other buffer-like objects, read and check cache early
            if isinstance(file_input, BytesIO):
                # Save current position
                original_position = file_input.tell()
                file_input.seek(0)
                buffer_content = file_input.read()
                file_input.seek(original_position)  # Restore position
                cache_key = hashlib.sha256(buffer_content).hexdigest()
                cached_url = self._upload_cache.get(cache_key)
                if cached_url:
                    logger.debug(f"Cache hit for BytesIO input: {cache_key[:8]}...")
                    return cached_url

            result = self._normalize_file(file_input)
            if not result:
                return None

            file_buffer, filename, content_type = result

            # Read file content once into memory
            file_buffer.seek(0)
            file_content = file_buffer.read()

            # Generate cache key from content if not already set
            if cache_key is None:
                cache_key = hashlib.sha256(file_content).hexdigest()

            # Check cache first
            cached_url = self._upload_cache.get(cache_key)
            if cached_url:
                logger.debug(f"Cache hit for file upload: {cache_key[:8]}...")
                return cached_url

            headers = {"apikey": self.api_key}

            # Upload using BytesIO from content
            files = {"content": (filename, BytesIO(file_content), content_type)}
            response = await self._arequest_with_retry(
                "post",
                f"{self.base_url}/files",
                headers=headers,
                files=files,
                timeout=self.timeout,
            )

            if not response.is_success:
                error_msg = (
                    f"Upload failed with status {response.status_code}: {response.text}"
                )
                logger.error(f"Error uploading file: {error_msg}")
                return None

            data = response.json()

            # Extract file URL directly from data
            file_url = self._extract_file_url(data)
            if not file_url:
                logger.warning(f"No URL found in file upload response: {data}")
                return None

            # Cache the successful upload
            self._upload_cache[cache_key] = file_url
            logger.debug(f"Cached file upload: {cache_key[:8]}... -> {file_url}")
            return file_url

        except Exception as e:
            logger.error(f"Error uploading file: {e}", exc_info=True)
            return None

    async def aupload_file_batch(
        self,
        file_inputs: list[str | Path | Image.Image | bytes],
    ) -> list[str | None]:
        """
        Async version of upload_file_batch - upload multiple files concurrently to Pruna API.

        Args:
            file_inputs: List of files to upload.
                - str: File path, URL, or data URI
                - Path: pathlib.Path object
                - Image.Image: PIL Image object
                - bytes: Raw file content

        Returns:
            List of file URLs in the same order as input. None values indicate failed uploads.
        """

        def _error_handler(file_input: Any, index: int, exc: Exception) -> str | None:
            """Handle errors in batch file uploads."""
            logger.error(f"Error uploading file at index {index}: {exc}", exc_info=True)
            return None

        return await self._process_batch(file_inputs, self.aupload_file, _error_handler)

    def upload_file_batch(
        self, file_inputs: list[str | Path | Image.Image | bytes]
    ) -> list[str | None]:
        """
        Upload multiple files concurrently to Pruna API.

        Args:
            file_inputs: List of files to upload.
                - str: File path, URL, or data URI
                - Path: pathlib.Path object
                - Image.Image: PIL Image object
                - bytes: Raw file content

        Returns:
            List of file URLs in the same order as input. None values indicate failed uploads.

        Example:
            >>> from pruna_client import PrunaClient
            >>> from pathlib import Path
            >>> client = PrunaClient(api_key="your-api-key")
            >>> # Upload multiple files
            >>> files = ["image1.jpg", "image2.png", Path("image3.jpg")]
            >>> urls = client.upload_file_batch(files)
            >>> # Check for failed uploads
            >>> for i, url in enumerate(urls):
            ...     if url is None:
            ...         print(f"Upload failed for file {i}")
            ...     else:
            ...         print(f"Uploaded: {url}")
            >>> client.close()
        """
        return self._run_async(self.aupload_file_batch(file_inputs))

    def download_content(self, url: str) -> bytes:
        """
        Download content from a URL.

        Args:
            url: URL of the content to download

        Returns:
            bytes: Content data

        Raises:
            httpx.RequestError: For network or HTTP errors

        Example:
            >>> from pruna_client import PrunaClient
            >>> client = PrunaClient(api_key="your-api-key")
            >>> # Download content from URL
            >>> url = "https://api.pruna.ai/v1/files/12345"
            >>> content = client.download_content(url)
            >>> # Save to file
            >>> with open("downloaded_file.jpg", "wb") as f:
            ...     f.write(content)
            >>> client.close()
        """
        headers = {"apikey": self.api_key}
        response = self._request_with_retry(
            "get", url, headers=headers, timeout=self.timeout
        )
        response.raise_for_status()
        return response.content

    def close(self) -> None:
        """Close the httpx clients and release resources."""
        self.client.close()
        # Note: async client should be closed with aclose() or await aclose()

    async def aclose(self) -> None:
        """Close the async httpx client and release resources."""
        await self._async_client.aclose()

    def __enter__(self) -> "PrunaClient":
        """Context manager entry."""
        return self

    def __exit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None:
        """Context manager exit - closes the client."""
        self.close()

    async def __aenter__(self) -> "PrunaClient":
        """Async context manager entry."""
        return self

    async def __aexit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None:
        """Async context manager exit - closes the async client."""
        await self.aclose()