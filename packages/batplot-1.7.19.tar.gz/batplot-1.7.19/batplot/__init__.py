"""batplot: Interactive plotting for battery data visualization."""

__version__ = "1.7.19"

__all__ = ["__version__"]
