"""
Bangla OCR - The Best Bangla/Bengali Text Recognition Package

A Transformer-based OCR package for recognizing Bangla handwritten and printed text
using a state-of-the-art Transformer architecture with ResNet-18 backbone.

✨ Features:
- Zero dependency conflicts
- Works with or without OpenCV
- Supports CUDA, MPS (Apple Silicon), and CPU
- Accepts file paths, numpy arrays, PIL Images, URLs, and bytes

🚀 Works flawlessly on:
- Google Colab (all versions)
- Kaggle Notebooks (CPU, GPU, TPU)
- Local environments (Windows, Linux, macOS, Apple Silicon)
- Docker containers
- Cloud platforms (AWS, GCP, Azure)

📦 Installation:
    pip install bangla-ocr
    
    # With OpenCV support (optional, for slightly better preprocessing):
    pip install bangla-ocr[cv-headless]

🔥 Quick Start:
    >>> from bangla_ocr import BanglaOCR
    >>> 
    >>> # Initialize with model and tokenizer
    >>> ocr = BanglaOCR('model.pth', 'tokenizer.pk')
    >>> 
    >>> # Predict from file path
    >>> text = ocr.predict('image.jpg')
    >>> print(text)
    >>> 
    >>> # Predict from URL
    >>> text = ocr.predict('https://example.com/bangla.jpg')
    >>> 
    >>> # Batch prediction
    >>> texts = ocr.predict_batch(['img1.jpg', 'img2.jpg'])
    >>> 
    >>> # Check model info
    >>> print(ocr.info)

Author: Bangla OCR Team
License: MIT
"""

__version__ = "1.0.0"
__author__ = "Bangla OCR Team"
__license__ = "MIT"

from .ocr import BanglaOCR
from .model import BanglaOCR as BanglaOCRModel, PositionalEncoding
from .services import Tokenizer, DataGenerator


def get_version() -> str:
    """Return the current version of bangla-ocr."""
    return __version__


def check_dependencies() -> dict:
    """
    Check which dependencies are available and their status.
    
    Returns:
        dict: Status of all dependencies including:
            - torch: PyTorch availability
            - torchvision: TorchVision availability
            - opencv: OpenCV availability (optional)
            - pillow: PIL/Pillow availability
            - numpy: NumPy availability
            - cuda: CUDA GPU availability
            - mps: Apple Silicon MPS availability
    
    Example:
        >>> from bangla_ocr import check_dependencies
        >>> deps = check_dependencies()
        >>> print(deps)
        {'torch': True, 'torchvision': True, 'opencv': False, 
         'pillow': True, 'numpy': True, 'cuda': True, 'mps': False}
    """
    status = {
        'torch': False,
        'torch_version': None,
        'torchvision': False,
        'opencv': False,
        'pillow': False,
        'numpy': False,
        'cuda': False,
        'cuda_version': None,
        'mps': False,
    }
    
    try:
        import torch
        status['torch'] = True
        status['torch_version'] = torch.__version__
        status['cuda'] = torch.cuda.is_available()
        if status['cuda']:
            status['cuda_version'] = torch.version.cuda
        if hasattr(torch.backends, 'mps'):
            try:
                status['mps'] = torch.backends.mps.is_available()
            except Exception:
                status['mps'] = False
    except ImportError:
        pass
    
    try:
        import torchvision
        status['torchvision'] = True
    except ImportError:
        pass
    
    try:
        import cv2
        status['opencv'] = True
    except ImportError:
        pass
    
    try:
        from PIL import Image
        status['pillow'] = True
    except ImportError:
        pass
    
    try:
        import numpy
        status['numpy'] = True
    except ImportError:
        pass
    
    return status


def print_info():
    """Print package info and dependency status."""
    print(f"Bangla OCR v{__version__}")
    print("=" * 40)
    deps = check_dependencies()
    for key, value in deps.items():
        status = "✓" if value else "✗"
        print(f"  {key}: {status} {value if value not in [True, False] else ''}")
    print("=" * 40)


__all__ = [
    # Main class
    'BanglaOCR',
    # Model components (for advanced users)
    'BanglaOCRModel', 
    'PositionalEncoding',
    'Tokenizer', 
    'DataGenerator',
    # Utility functions
    '__version__',
    'get_version',
    'check_dependencies',
    'print_info',
]
