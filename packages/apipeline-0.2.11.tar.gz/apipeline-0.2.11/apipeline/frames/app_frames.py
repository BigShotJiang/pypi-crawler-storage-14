from dataclasses import dataclass

from .base import Frame

#
# App frames. Application user-defined frames.
#


@dataclass
class AppFrame(Frame):
    pass
