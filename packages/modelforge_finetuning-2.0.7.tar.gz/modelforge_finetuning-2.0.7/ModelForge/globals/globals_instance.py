from .globals import GlobalSettings

global_manager = GlobalSettings()
