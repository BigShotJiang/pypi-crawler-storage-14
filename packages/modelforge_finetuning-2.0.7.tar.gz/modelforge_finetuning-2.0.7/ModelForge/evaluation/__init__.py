"""
Evaluation module for ModelForge.
Provides metrics computation and evaluation logic for different tasks.
"""
