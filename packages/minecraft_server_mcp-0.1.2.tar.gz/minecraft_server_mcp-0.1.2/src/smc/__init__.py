"""Minecraft Server MCP - Model Context Protocol server for Minecraft server management."""

__version__ = "0.1.2"
