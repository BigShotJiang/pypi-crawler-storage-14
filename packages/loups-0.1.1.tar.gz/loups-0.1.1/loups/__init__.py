"""loups module __init__ file."""

from .loups import Loups

__all__ = ["Loups"]
