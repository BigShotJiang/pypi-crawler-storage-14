"""Entry point for running loups as a module with python -m loups."""

from loups.cli import app

if __name__ == "__main__":
    app()
