<!-- Reusable snippets for documentation -->

<!-- Expected CLI output example -->
--8<-- [start:cli-output-example]
```
Scanning video: game_video.mp4

🥎 Scanning batters...  [Progress updates]

🏆 Scan complete! Found 12 batters in 5.2s

YouTube Chapters:
0:00:00 Game Start
0:01:15 Sarah Johnson #7
0:03:42 Emma Martinez #12
0:05:23 Lily Garcia #9
0:08:14 Olivia Brown #5
...
```
--8<-- [end:cli-output-example]
