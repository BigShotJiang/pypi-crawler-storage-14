from oasislmf.pytools.common.data import items_headers, items_dtype, items_fmt


headers = items_headers
dtype = items_dtype
fmt = items_fmt
cli_support = ['bintocsv', 'csvtobin']
