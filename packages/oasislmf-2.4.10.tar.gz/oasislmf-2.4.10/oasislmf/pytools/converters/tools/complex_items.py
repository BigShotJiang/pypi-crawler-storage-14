from oasislmf.pytools.common.data import complex_items_meta_headers, complex_items_meta_dtype, complex_items_meta_fmt


headers = complex_items_meta_headers
dtype = complex_items_meta_dtype
fmt = complex_items_meta_fmt
cli_support = ['bintocsv', 'csvtobin']
