from oasislmf.pytools.common.data import returnperiods_headers, returnperiods_dtype, returnperiods_fmt


headers = returnperiods_headers
dtype = returnperiods_dtype
fmt = returnperiods_fmt
cli_support = ['bintocsv', 'csvtobin']
