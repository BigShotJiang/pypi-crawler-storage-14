from oasislmf.pytools.common.data import coverages_headers, coverages_dtype, coverages_fmt


headers = coverages_headers
dtype = coverages_dtype
fmt = coverages_fmt
cli_support = ['bintocsv', 'csvtobin']
