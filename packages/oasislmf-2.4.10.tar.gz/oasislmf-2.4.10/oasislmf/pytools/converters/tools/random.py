from oasislmf.pytools.common.data import random_headers, random_dtype, random_fmt


headers = random_headers
dtype = random_dtype
fmt = random_fmt
cli_support = ['bintocsv', 'csvtobin']
