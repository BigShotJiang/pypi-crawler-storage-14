from oasislmf.pytools.common.data import fm_policytc_headers, fm_policytc_dtype, fm_policytc_fmt


headers = fm_policytc_headers
dtype = fm_policytc_dtype
fmt = fm_policytc_fmt
cli_support = ['bintocsv', 'csvtobin']
