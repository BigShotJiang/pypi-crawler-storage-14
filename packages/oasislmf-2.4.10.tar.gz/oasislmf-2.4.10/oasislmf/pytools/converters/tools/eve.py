from oasislmf.pytools.common.data import eve_headers, eve_dtype, eve_fmt


headers = eve_headers
dtype = eve_dtype
fmt = eve_fmt
cli_support = ['bintocsv', 'csvtobin']
