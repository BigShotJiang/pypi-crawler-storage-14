from oasislmf.pytools.aal.data import AAL_meanonly_headers, AAL_meanonly_dtype, AAL_meanonly_fmt


headers = AAL_meanonly_headers
dtype = AAL_meanonly_dtype
fmt = AAL_meanonly_fmt
cli_support = ['bintocsv', 'csvtobin', 'bintoparquet', 'parquettobin']
