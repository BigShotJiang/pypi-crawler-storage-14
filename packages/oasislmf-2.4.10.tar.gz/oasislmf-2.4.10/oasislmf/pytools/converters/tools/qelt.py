from oasislmf.pytools.elt.data import QELT_headers, QELT_dtype, QELT_fmt


headers = QELT_headers
dtype = QELT_dtype
fmt = QELT_fmt
cli_support = ['bintocsv', 'csvtobin', 'bintoparquet', 'parquettobin']
