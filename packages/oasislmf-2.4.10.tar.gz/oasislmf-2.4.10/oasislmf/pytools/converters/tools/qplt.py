from oasislmf.pytools.plt.data import QPLT_headers, QPLT_dtype, QPLT_fmt


headers = QPLT_headers
dtype = QPLT_dtype
fmt = QPLT_fmt
cli_support = ['bintocsv', 'csvtobin', 'bintoparquet', 'parquettobin']
