from oasislmf.pytools.aal.data import AAL_headers, AAL_dtype, AAL_fmt


headers = AAL_headers
dtype = AAL_dtype
fmt = AAL_fmt
cli_support = ['bintocsv', 'csvtobin', 'bintoparquet', 'parquettobin']
