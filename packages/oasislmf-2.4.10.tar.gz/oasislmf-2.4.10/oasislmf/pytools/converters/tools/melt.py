from oasislmf.pytools.elt.data import MELT_headers, MELT_dtype, MELT_fmt


headers = MELT_headers
dtype = MELT_dtype
fmt = MELT_fmt
cli_support = ['bintocsv', 'csvtobin', 'bintoparquet', 'parquettobin']
