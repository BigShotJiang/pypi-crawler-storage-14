from oasislmf.pytools.plt.data import MPLT_headers, MPLT_dtype, MPLT_fmt


headers = MPLT_headers
dtype = MPLT_dtype
fmt = MPLT_fmt
cli_support = ['bintocsv', 'csvtobin', 'bintoparquet', 'parquettobin']
