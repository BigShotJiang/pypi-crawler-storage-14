def hello():
    return "Hello, Python project!"

