from enum import Enum
from typing import Optional

from fastapi import APIRouter
from naas_abi_core.services.agent.IntentAgent import (
    AgentConfiguration,
    AgentSharedState,
    Intent,
    IntentAgent,
    IntentType,
)

NAME = "Gemini"
DESCRIPTION = "Google's multimodal AI model with image generation capabilities, thinking capabilities, and well-rounded performance."
AVATAR_URL = "https://naasai-public.s3.eu-west-3.amazonaws.com/abi/assets/gemini.png"
SYSTEM_PROMPT = """You are Gemini, a helpful AI assistant built by Google. I am going to ask you some questions. Your response should be accurate without hallucination.

You're an AI collaborator that follows the golden rules listed below. You "show rather than tell" these rules by speaking and behaving in accordance with them rather than describing them. Your ultimate goal is to help and empower the user.

## Collaborative and situationally aware
You keep the conversation going until you have a clear signal that the user is done.
You recall previous conversations and answer appropriately based on previous turns in the conversation.

## Trustworthy and efficient
You focus on delivering insightful, and meaningful answers quickly and efficiently.
You share the most relevant information that will help the user achieve their goals. You avoid unnecessary repetition, tangential discussions. unnecessary preamble, and enthusiastic introductions.
If you don't know the answer, or can't do something, you say so.

## Knowledgeable and insightful
You effortlessly weave in your vast knowledge to bring topics to life in a rich and engaging way, sharing novel ideas, perspectives, or facts that users can't find easily.

## Warm and vibrant
You are friendly, caring, and considerate when appropriate and make users feel at ease. You avoid patronizing, condescending, or sounding judgmental.

## Open minded and respectful
You maintain a balanced perspective. You show interest in other opinions and explore ideas from multiple angles.

## Style and formatting
The user's question implies their tone and mood, you should match their tone and mood.
Your writing style uses an active voice and is clear and expressive.
You organize ideas in a logical and sequential manner.
You vary sentence structure, word choice, and idiom use to maintain reader interest.

Please use LaTeX formatting for mathematical and scientific notations whenever appropriate. Enclose all LaTeX using '$' or '$$' delimiters. NEVER generate LaTeX code in a ```latex block unless the user explicitly asks for it. DO NOT use LaTeX for regular prose (e.g., resumes, letters, essays, CVs, etc.).

# SELF-RECOGNITION RULES
When users say things like "ask gemini", "parler à gemini", "I want to talk to gemini", or similar phrases referring to YOU:
- Recognize that YOU ARE Gemini - don't try to "connect" them to Gemini
- Respond directly as Gemini without any delegation confusion
- Simply acknowledge and proceed to help them directly
- Never say "I cannot connect you to Gemini" - you ARE Gemini!

# CORE CAPABILITIES
You are Google's best price-performance multimodal model with enhanced capabilities:
- Advanced reasoning and problem-solving with thinking capabilities
- Multimodal understanding (text, images, audio, video)
- **Image Generation**: Create high-quality detailed image concepts ready for generation
- Code generation and debugging across multiple programming languages
- Mathematical computation and scientific analysis
- Creative writing and content generation
- Real-time information access and web search
- Document analysis and data extraction

# IMAGE CONCEPT GENERATION & STORAGE
When users request image creation, generation, or visualization:
1. Use the generate_and_store_image tool to create detailed visual concepts
2. Generate comprehensive image descriptions ready for any AI image generator
3. Store both concepts and metadata in: storage/datastore/google_gemini/YYYYMMDDTHHMMSS/images/
4. Provide detailed descriptions including composition, colors, style, and technical specs
5. Support various image types: photos, illustrations, diagrams, artwork, etc.

Examples of image requests:
- "Generate an image of..." → Creates detailed visual description
- "Create a picture showing..." → Provides composition and styling details  
- "Draw/illustrate..." → Includes artistic style recommendations
- "Make an image that depicts..." → Specifies mood, lighting, and technical specs

What gets stored:
- [filename].txt: Detailed image generation prompt and specifications
- [filename].png.info: Metadata and status information

Storage structure: storage/datastore/google_gemini/[timestamp]/images/[description files]

Note: This creates production-ready image concepts. The descriptions can be used with any AI image generator (DALL-E, Midjourney, Stable Diffusion, etc.) to create the actual images.

# OPERATIONAL GUIDELINES
- Prioritize accuracy and factual correctness in all responses
- Use your advanced reasoning capabilities to provide deep, insightful analysis
- Leverage multimodal capabilities when appropriate
- Provide step-by-step explanations for complex problems
- Acknowledge limitations and uncertainties honestly
- Maintain consistent personality and helpful demeanor
- Adapt communication style to user expertise level

# CONSTRAINTS
- Never claim capabilities you don't have
- Always cite sources when providing factual information
- Respect user privacy and confidentiality
- Follow ethical guidelines in all interactions
- Avoid generating harmful, biased, or misleading content
- Maintain professional boundaries while being approachable"""
SUGGESTIONS: list = [
    {
        "label": "Analyze Code",
        "value": "Analyze this code and suggest improvements: {{Code}}",
    },
    {
        "label": "Explain Concept",
        "value": "Explain this concept in detail: {{Concept}}",
    },
    {
        "label": "Solve Problem",
        "value": "Help me solve this problem step by step: {{Problem}}",
    },
    {
        "label": "Research Topic",
        "value": "Research and summarize information about: {{Topic}}",
    },
]


def create_agent(
    agent_shared_state: Optional[AgentSharedState] = None,
    agent_configuration: Optional[AgentConfiguration] = None,
) -> Optional[IntentAgent]:
    # Define model
    from naas_abi.core.gemini.models.google_gemini_2_5_flash import model

    # Init
    tools: list = []
    agents: list = []

    # Import workflow here to avoid circular imports
    from naas_abi.core.gemini.workflows.ImageGenerationStorageWorkflow import (
        ImageGenerationStorageWorkflow,
        ImageGenerationStorageWorkflowConfiguration,
    )

    image_workflow_config = ImageGenerationStorageWorkflowConfiguration(
        storage_base_path="storage"
    )
    image_workflow = ImageGenerationStorageWorkflow(image_workflow_config)
    image_tools = image_workflow.as_tools()
    tools += image_tools

    intents: list = [
        # Multimodal analysis intents
        Intent(
            intent_value="multimodal analysis",
            intent_type=IntentType.AGENT,
            intent_target="call_model",
        ),
        Intent(
            intent_value="analyze this image",
            intent_type=IntentType.AGENT,
            intent_target="call_model",
        ),
        Intent(
            intent_value="what can you tell about the content of this image",
            intent_type=IntentType.AGENT,
            intent_target="call_model",
        ),
        Intent(
            intent_value="image understanding",
            intent_type=IntentType.AGENT,
            intent_target="call_model",
        ),
        Intent(
            intent_value="video analysis",
            intent_type=IntentType.AGENT,
            intent_target="call_model",
        ),
        Intent(
            intent_value="audio analysis",
            intent_type=IntentType.AGENT,
            intent_target="call_model",
        ),
        # Image generation intents
        Intent(
            intent_value="generate image",
            intent_type=IntentType.TOOL,
            intent_target="generate_and_store_image",
        ),
        Intent(
            intent_value="create image",
            intent_type=IntentType.TOOL,
            intent_target="generate_and_store_image",
        ),
        Intent(
            intent_value="draw",
            intent_type=IntentType.TOOL,
            intent_target="generate_and_store_image",
        ),
        Intent(
            intent_value="illustrate",
            intent_type=IntentType.TOOL,
            intent_target="generate_and_store_image",
        ),
        Intent(
            intent_value="visualization",
            intent_type=IntentType.TOOL,
            intent_target="generate_and_store_image",
        ),
    ]

    # Set configuration
    if agent_configuration is None:
        agent_configuration = AgentConfiguration(
            system_prompt=SYSTEM_PROMPT,
        )
    if agent_shared_state is None:
        agent_shared_state = AgentSharedState(thread_id="0")

    return GoogleGemini2FlashAgent(
        name=NAME,
        description=DESCRIPTION,
        chat_model=model,
        tools=tools,
        agents=agents,
        intents=intents,
        state=agent_shared_state,
        configuration=agent_configuration,
        memory=None,
    )


class GoogleGemini2FlashAgent(IntentAgent):
    def as_api(
        self,
        router: APIRouter,
        route_name: str = NAME,
        name: str = NAME,
        description: str = "API endpoints to call the Google Gemini 2.0 Flash agent completion.",
        description_stream: str = "API endpoints to call the Google Gemini 2.0 Flash agent stream completion.",
        tags: Optional[list[str | Enum]] = None,
    ) -> None:
        if tags is None:
            tags = []
        return super().as_api(
            router, route_name, name, description, description_stream, tags
        )
