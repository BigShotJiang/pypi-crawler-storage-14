// Stub utilities for deno_telemetry
// No-op functions to satisfy deno_fetch imports

export function updateSpanFromError() {}
export function updateSpanFromRequest() {}
export function updateSpanFromResponse() {}
