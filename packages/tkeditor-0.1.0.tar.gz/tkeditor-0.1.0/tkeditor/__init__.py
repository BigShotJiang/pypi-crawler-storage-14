from tkeditor.editor import Editor
__all__ = ["Editor"]