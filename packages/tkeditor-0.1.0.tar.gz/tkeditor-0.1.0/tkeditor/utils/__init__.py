from tkeditor.utils.helper import get_font

__all__ = ["get_font"]