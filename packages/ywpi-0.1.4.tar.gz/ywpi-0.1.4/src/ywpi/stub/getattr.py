import ywpi


def stub_getattr(name: str):
    pass
