"""Integrated menu widget combining prompt, file input, and menu options."""

from textual.widgets import TextArea, Input, Static
from textual.containers import Vertical
from textual.message import Message
from textual.app import ComposeResult
from textual.reactive import reactive
from textual import events
from textual.events import Key

from aristotlelib.tui.components.history_picker import HistoryPickerWidget
from aristotlelib.tui.components.file_path_input import FilePathInput
from aristotlelib.tui.menu_options import MenuOption, MenuOptionConfig, MENU_OPTIONS
from aristotlelib.project import ProjectStatus

# UI Constants for border formatting (removed hardcoded width - now dynamic)

class SubmittableTextArea(TextArea):
    """TextArea for multi-line input with Ctrl+S to submit.

    Ctrl+S is handled by the parent IntegratedMenuWidget via BINDINGS,
    allowing Enter to add newlines normally in the TextArea.
    """

    def on_mount(self) -> None:
        """Set up the widget after mounting."""
        # Scroll the parent container to show this widget
        # Use call_after_refresh to ensure the widget is fully laid out first
        self.call_after_refresh(self._scroll_into_view)

    def _scroll_into_view(self) -> None:
        """Scroll the parent container to show this widget."""
        # Find the parent scroll container
        try:
            from textual.containers import VerticalScroll
            parent = self.parent
            while parent and not isinstance(parent, VerticalScroll):
                parent = parent.parent
            if parent:
                parent.scroll_end(animate=True)
        except Exception:
            # If we can't find the scroll container, just skip
            pass


class IntegratedMenuWidget(Vertical):
    """
    Integrated menu with adaptive single input box and menu options.

    The widget allows users to:
    - Select from 4 menu options
    - Options 1-2: Single-line Input for file path
    - Option 3: Multi-line TextArea for freestyle prompt
    - Option 4: History picker
    - Submit with Ctrl+S
    """

    # Use Ctrl+S (save) as submit key - universally supported
    # Note: Ctrl+D doesn't work as it's intercepted by terminal/Textual as EOF
    BINDINGS = [
        ("ctrl+s", "submit_form", "Submit"),
    ]

    DEFAULT_CSS = """
    IntegratedMenuWidget {
        height: auto;
        padding: 1 0;
    }

    IntegratedMenuWidget Vertical {
        height: auto;
    }

    IntegratedMenuWidget #input-container {
        height: auto;
        margin-top: 1;
        margin-bottom: 1;
        width: 100%;
        max-width: 72;
        min-width: 40;
    }

    IntegratedMenuWidget TextArea {
        height: 6;
        border: solid $primary;
        margin-bottom: 1;
        width: 100%;
        max-width: 72;
        min-width: 40;
    }

    IntegratedMenuWidget Input {
        height: auto;
        border: solid $accent;
        margin-bottom: 1;
        width: 100%;
        max-width: 72;
        min-width: 40;
    }

    IntegratedMenuWidget .menu-options {
        height: auto;
        padding: 1 0;
        width: 100%;
        max-width: 72;
        min-width: 40;
    }

    IntegratedMenuWidget .menu-option {
        padding: 0;
    }

    IntegratedMenuWidget .menu-option.selected {
        color: $accent;
        text-style: bold;
    }
    """

    # Reactive state
    mode = reactive("navigation")  # "navigation" or "input"
    selected_option: MenuOption | None = reactive(None)  # None = no selection, or MenuOption enum value
    input_value = reactive("")  # Stores file path or prompt text
    history_filter: ProjectStatus | None = reactive(None)  # For VIEW_HISTORY option: None = all, or specific status
    history_selection_made = reactive(False)  # Track if history filter selection has been made

    class Submitted(Message):
        """Message emitted when user submits the form."""

        def __init__(self, option: MenuOption, prompt: str, file_path: str | None, history_filter: ProjectStatus | None = None):
            self.option = option
            self.prompt = prompt
            self.file_path = file_path
            self.history_filter = history_filter
            super().__init__()

    def compose(self) -> ComposeResult:
        """Create the integrated menu layout."""
        # Menu options - now shown FIRST (above input)
        with Vertical(classes="menu-options"):
            yield Static(id="menu-top-border", markup=False)
            yield Static(id="menu-blank-top", markup=False)
            for option in MenuOption:
                config = MENU_OPTIONS[option]
                num = option.to_number()
                yield Static(f"│  [{num}] {config.label}│", classes="menu-option", id=f"option-{num}")
            yield Static(id="menu-blank-bottom", markup=False)
            yield Static(id="menu-bottom-border", markup=False)

        # Input container - shown SECOND (below menu)
        # Initially hidden in navigation mode, shown in input mode
        with Vertical(id="input-container", classes="input-container"):
            yield Static(id="input-header", markup=False)  # Dynamic header
            # Input widget will be dynamically added based on selection
            yield Static(id="input-footer", markup=False)  # Bottom border

    def on_mount(self) -> None:
        """Initialize the widget state."""
        # Calculate border width based on terminal size
        border_width = self._get_border_width()

        # Start in navigation mode - hide input container
        container = self.query_one("#input-container")
        container.display = False

        # Update menu borders with calculated width
        self._update_menu_borders(border_width)

        # Make the widget focusable
        self.can_focus = True

        # Defer focus until after layout is complete to avoid premature scrolling
        # This ensures Textual's layout engine has calculated the correct scroll region
        self.call_later(self._delayed_focus)

    def _delayed_focus(self) -> None:
        """Focus the widget after layout is complete."""
        self.focus(scroll_visible=False)

    def on_terminal_resized(self, message) -> None:
        """Handle terminal resize by updating menu borders."""
        # Import here to avoid circular dependency
        from aristotlelib.tui.app import TerminalResized

        if isinstance(message, TerminalResized):
            new_width = self._get_border_width()
            self._update_menu_borders(new_width)

            # Re-render input container if in input mode
            if self.mode == "input" and self.selected_option is not None:
                self._update_ui_for_option(self.selected_option, auto_focus=False)

    def _transition_to_input_mode(self, option: MenuOption) -> None:
        """Transition from navigation mode to input mode."""
        self.mode = "input"
        self.selected_option = option
        self._show_collapsed_menu(option)
        self._update_ui_for_option(option, auto_focus=True)

    def _transition_to_navigation_mode(self) -> None:
        """Transition from input mode to navigation mode."""
        self.mode = "navigation"
        self.selected_option = None
        self.history_selection_made = False  # Reset history selection flag
        self._clear_input()
        self._show_full_menu()
        self.focus(scroll_visible=False)

    def _clear_input(self) -> None:
        """Clear the input widget and hide the input container."""
        try:
            # Remove existing input widget if present
            current_widget = self.query_one(".input-widget")
            current_widget.remove()
        except Exception:
            pass

        # Hide input container
        container = self.query_one("#input-container")
        container.display = False

    def _show_full_menu(self) -> None:
        """Show the full menu with all options."""
        border_width = self._get_border_width()
        content_width = border_width - 2

        # Show all option lines
        for option in MenuOption:
            num = option.to_number()
            opt_widget = self.query_one(f"#option-{num}", Static)
            opt_widget.display = True
            opt_widget.remove_class("selected")

        # Show blank lines
        self.query_one("#menu-blank-top", Static).display = True
        self.query_one("#menu-blank-bottom", Static).display = True

        # Update borders to full menu style
        top_border = self.query_one("#menu-top-border", Static)
        header_text = "╭─ Available Modes "
        top_border.update(f"{header_text}{'─' * (content_width - len(header_text) + 1)}╮")

        bottom_border = self.query_one("#menu-bottom-border", Static)
        footer_text = " ctrl+c to exit ─╯"
        bottom_border.update(f"╰{'─' * (content_width - len(footer_text) + 1)}{footer_text}")

    def _highlight_option(self, option: MenuOption) -> None:
        """Highlight an option in navigation mode (doesn't transition to input mode)."""
        for opt in MenuOption:
            num = opt.to_number()
            opt_widget = self.query_one(f"#option-{num}", Static)
            if opt == option:
                opt_widget.add_class("selected")
            else:
                opt_widget.remove_class("selected")

    def _show_collapsed_menu(self, option: MenuOption) -> None:
        """Show collapsed menu with only the selected option."""
        border_width = self._get_border_width()
        content_width = border_width - 2
        label_width = border_width - 8

        # Hide all options except the selected one
        for opt in MenuOption:
            num = opt.to_number()
            opt_widget = self.query_one(f"#option-{num}", Static)
            if opt == option:
                opt_widget.display = True
                opt_widget.add_class("selected")
                # Update the option text to match collapsed width
                config = MENU_OPTIONS[opt]
                opt_widget.update(f"│  [{num}] {config.label:<{label_width}}│")
            else:
                opt_widget.display = False

        # Hide blank lines for compact view
        self.query_one("#menu-blank-top", Static).display = False
        self.query_one("#menu-blank-bottom", Static).display = False

        # Update borders to collapsed style
        top_border = self.query_one("#menu-top-border", Static)
        header_text = "╭─ Available Modes "
        top_border.update(f"{header_text}{'─' * (content_width - len(header_text) + 1)}╮")

        bottom_border = self.query_one("#menu-bottom-border", Static)
        bottom_border.update(f"╰{'─' * content_width}╯")

    def _get_border_width(self) -> int:
        """Calculate border width based on terminal size."""
        terminal_width = self.app.size.width

        # Calculate minimum width needed for content
        max_label_len = max(len(cfg.label) for cfg in MENU_OPTIONS.values())
        content_min = max_label_len + 8  # "│  [X] label│"

        # Menu width should not exceed 72 characters to stay well within 80
        # Use min of: 72 max, content minimum, or terminal_width - 8 for padding
        max_width = 72
        return min(max_width, max(content_min, terminal_width - 8))

    def _update_menu_borders(self, border_width: int) -> None:
        """Update menu borders with the calculated width."""
        # Calculate content width (border_width - 2 for the side borders)
        content_width = border_width - 2
        # Label width for menu options: total line is border_width
        # "│  [X] " = 7 chars on left, "│" = 1 char on right, so label gets: border_width - 8
        label_width = border_width - 8

        # Update top border: "╭─ Available Modes " = 19 chars, then fill to content_width, then "╮"
        top_border = self.query_one("#menu-top-border", Static)
        header_text = "╭─ Available Modes "
        top_border.update(f"{header_text}{'─' * (content_width - len(header_text) + 1)}╮")

        # Update blank lines
        blank_top = self.query_one("#menu-blank-top", Static)
        blank_top.update(f"│{' ' * content_width}│")

        blank_bottom = self.query_one("#menu-blank-bottom", Static)
        blank_bottom.update(f"│{' ' * content_width}│")

        # Update bottom border
        bottom_border = self.query_one("#menu-bottom-border", Static)
        footer_text = " ctrl+c to exit ─╯"
        bottom_border.update(f"╰{'─' * (content_width - len(footer_text) + 1)}{footer_text}")

        # Update menu option lines
        for option in MenuOption:
            num = option.to_number()
            config = MENU_OPTIONS[option]
            option_widget = self.query_one(f"#option-{num}", Static)

            # Format label with truncation if needed
            label = config.label
            if len(label) > label_width:
                # Truncate with ellipsis
                label = label[:label_width - 3] + "..."

            # Format: "│  [X] label with padding│"
            # "│  " = 3 chars, "[X] " = 4 chars (total 7), label (padded), "│" = 1 char
            option_widget.update(f"│  [{num}] {label:<{label_width}}│")

    def action_submit_form(self) -> None:
        """Action called when Ctrl+S is pressed (via BINDINGS)."""
        if self._is_form_ready():
            self._submit_form()

    def _on_key(self, event: Key) -> None:
        """Handle keyboard shortcuts with capture priority (before children).

        The underscore prefix (_on_key vs on_key) means this is called in the
        "capture" phase BEFORE child widgets receive the event.
        """
        # ESCAPE KEY: Always intercept and return to navigation mode from input mode
        # This must be handled here in capture phase to intercept before Input widgets
        if event.key == "escape":
            if self.mode == "input":
                self._transition_to_navigation_mode()
                event.prevent_default()
                event.stop()
                return

        # For all other keys, we need to handle them here in capture phase
        # Otherwise they bubble up to parent widgets
        self._handle_key_event(event)

    def _handle_key_event(self, event: events.Key) -> None:
        """Handle keyboard shortcuts for navigation and input."""
        # NUMBER KEYS (1-4): Select option
        if event.key in ["1", "2", "3", "4"]:
            # In input mode with TextArea focused, let numbers through for typing
            if self.mode == "input":
                try:
                    textarea = self.query_one(".input-widget", TextArea)
                    if textarea.has_focus:
                        return
                except Exception:
                    pass

            # Convert number key to MenuOption enum
            option = MenuOption.from_number(int(event.key))
            if option:
                self._transition_to_input_mode(option)
                event.prevent_default()
                event.stop()
            return

        # ARROW KEYS: Navigation in navigation mode only
        if event.key in ["up", "down"]:
            # In input mode, check if we should let widgets handle arrows
            if self.mode == "input":
                try:
                    textarea = self.query_one(".input-widget", TextArea)
                    if textarea.has_focus:
                        return  # Let TextArea handle arrows
                except Exception:
                    pass
                # In input mode but not in TextArea - ignore arrows
                event.prevent_default()
                event.stop()
                return

            # Navigation mode: Handle menu navigation with up/down
            all_options = list(MenuOption)
            if event.key == "up":
                if self.selected_option is None:
                    # Start from last option if nothing selected
                    new_option = all_options[-1]
                else:
                    current_index = all_options.index(self.selected_option)
                    # Wrap around to last if at first
                    new_index = (current_index - 1) % len(all_options)
                    new_option = all_options[new_index]
                self.selected_option = new_option
                self._highlight_option(new_option)
                event.prevent_default()
                event.stop()
                return

            if event.key == "down":
                if self.selected_option is None:
                    # Start from first option if nothing selected
                    new_option = all_options[0]
                else:
                    current_index = all_options.index(self.selected_option)
                    # Wrap around to first if at last
                    new_index = (current_index + 1) % len(all_options)
                    new_option = all_options[new_index]
                self.selected_option = new_option
                self._highlight_option(new_option)
                event.prevent_default()
                event.stop()
                return

        # LEFT/RIGHT ARROWS: Let HistoryPicker handle them in input mode
        if event.key in ["left", "right"]:
            if self.mode == "input":
                try:
                    picker = self.query_one(".input-widget", HistoryPickerWidget)
                    if picker.has_focus:
                        return  # Let picker handle left/right
                except Exception:
                    pass
            # Otherwise prevent default
            event.prevent_default()
            event.stop()
            return

        # ENTER KEY: Different behavior based on mode
        if event.key == "enter":
            if self.mode == "navigation":
                # Transition to input mode if an option is selected
                if self.selected_option is not None:
                    self._transition_to_input_mode(self.selected_option)
                    event.prevent_default()
                    event.stop()
                    return
            else:  # input mode
                # In TextArea (freestyle), let Enter add newlines
                try:
                    textarea = self.query_one(".input-widget", TextArea)
                    if textarea.has_focus:
                        return  # Let TextArea handle Enter
                except Exception:
                    pass

                # Otherwise, submit if form is ready
                if self._is_form_ready():
                    self._submit_form()
                    event.prevent_default()
                    event.stop()
                    return

    def on_file_path_input_validated(self, event: FilePathInput.Validated) -> None:
        """Handle file path validation from FilePathInput widget."""
        # Store the validated path (for backward compatibility)
        self.input_value = event.file_path

    def on_history_picker_widget_selection_changed(self, event: HistoryPickerWidget.SelectionChanged) -> None:
        """Handle selection changes from HistoryPickerWidget."""
        # Update the history filter based on the picker's selection
        self.history_filter = event.filter_type
        self.history_selection_made = True

    def _update_ui_for_option(self, option: MenuOption, auto_focus: bool = True) -> None:
        """Update UI based on selected option.

        Args:
            option: The MenuOption enum value
            auto_focus: If True, auto-focus input widgets. If False, keep focus on parent (navigation mode).
        """
        config = MENU_OPTIONS[option]

        # Get the input container
        container = self.query_one("#input-container")

        container.display = True

        # Calculate border width dynamically
        border_width = self._get_border_width()

        # Update header with option label
        header = self.query_one("#input-header", Static)
        header_text = f"{config.label} (Ctrl+S to submit)"
        # Calculate padding: border_width - "┌─ " (3) - header_text - " ┐" (2) = border_width - 5 - len(header_text)
        padding_len = border_width - len(header_text) - 5
        if padding_len < 0:
            padding_len = 0
        header.update(f"┌─ {header_text} {'─' * padding_len}┐")

        # Update footer
        footer = self.query_one("#input-footer", Static)
        footer_text = " Esc to return to main menu ─┘"
        footer.update(f"└{'─' * (border_width - len(footer_text) - 1)}{footer_text}")

        # Check what type of widget we need
        needs_input = config.requires_file
        needs_picker = (option == MenuOption.VIEW_HISTORY)

        # Check current widget type
        try:
            current_widget = self.query_one(".input-widget")
            is_file_input = isinstance(current_widget, FilePathInput)
            is_textarea = isinstance(current_widget, TextArea)
            is_picker = isinstance(current_widget, HistoryPickerWidget)

            # If the widget type matches what we need, just clear it and reuse
            if needs_picker and is_picker:
                # Reuse existing picker
                pass
            elif (needs_input and is_file_input):
                # Reuse FilePathInput widget - clear it by updating the internal input
                try:
                    file_input = current_widget.query_one("#path-input", Input)
                    file_input.value = ""
                    current_widget.current_value = ""
                    # Update allowed extensions for the new option
                    current_widget.allowed_extensions = config.file_types
                    # Clear suggestions and cycling state
                    current_widget._suggestions = []
                    current_widget._preserved_suggestions = []
                    current_widget._suggestion_index = -1
                    current_widget._preserved_dir_path = ""
                    current_widget._preserved_prefix = ""
                    # Clear the suggestions display
                    suggestions_display = current_widget.query_one("#suggestions-display", Static)
                    suggestions_display.update("")
                    suggestions_display.remove_class("has-content")
                    # Only focus if auto_focus is True
                    if auto_focus:
                        file_input.focus(scroll_visible=False)
                except Exception:
                    # If clearing fails, just recreate
                    current_widget.remove()
                    self._create_and_mount_input(container, footer, config, option, auto_focus)
            elif (not needs_input and not needs_picker and is_textarea):
                # Reuse TextArea widget
                current_widget.text = ""
                current_widget.disabled = False
                # Only focus if auto_focus is True
                if auto_focus:
                    current_widget.focus(scroll_visible=False)
            else:
                # Need to swap widget types - remove old and mount new
                current_widget.remove()
                # Create and mount new widget immediately (remove is async, but we use class not ID)
                self._create_and_mount_input(container, footer, config, option, auto_focus)
        except Exception:
            # No existing widget, create one
            self._create_and_mount_input(container, footer, config, option, auto_focus)

        # Note: Menu highlighting is handled by _show_collapsed_menu() in input mode
        # and _show_full_menu() in navigation mode

    def _create_and_mount_input(self, container, footer, config: MenuOptionConfig, option: MenuOption, auto_focus: bool = True):
        """Helper to create and mount appropriate input widget.

        Args:
            container: The container to mount the widget in
            footer: The footer element to mount before
            config: The MenuOptionConfig for this option
            option: The MenuOption enum value
            auto_focus: If True, focus the widget after mounting. If False, don't focus.
        """
        if option == MenuOption.VIEW_HISTORY:
            # History picker
            new_input = HistoryPickerWidget(classes="input-widget")
        elif config.requires_file:
            # File input with tab completion and validation
            new_input = FilePathInput(
                allowed_extensions=config.file_types,
                classes="input-widget"
            )
        else:
            # Multi-line TextArea for freestyle
            new_input = SubmittableTextArea(
                text="",
                classes="input-widget"  # Use class instead of ID
            )

        container.mount(new_input, before=footer)
        # Only focus if auto_focus is True
        if auto_focus:
            new_input.focus(scroll_visible=False)

    def _is_form_ready(self) -> bool:
        """Check if the form is ready to be submitted."""
        if self.selected_option is None:
            # No option selected
            return False

        config = MENU_OPTIONS[self.selected_option]

        # VIEW_HISTORY is ready when picker has made a selection (even if it's None for "ALL")
        if self.selected_option == MenuOption.VIEW_HISTORY:
            return self.history_selection_made

        # Get the current input widget
        try:
            if config.requires_file:
                # File-based options: Check if FilePathInput is valid
                file_input = self.query_one(".input-widget", FilePathInput)
                return file_input.is_valid
            else:
                # FREESTYLE: Check if textarea has content
                textarea = self.query_one(".input-widget", TextArea)
                return bool(textarea.text and textarea.text.strip())
        except Exception:
            return False

    def _submit_form(self) -> None:
        """Submit the form."""
        if self.selected_option is None:
            # No option selected yet
            return

        config = MENU_OPTIONS[self.selected_option]

        # Get input based on option type
        if config.requires_file:
            # File-based options: File path from FilePathInput
            try:
                file_input = self.query_one(".input-widget", FilePathInput)
                file_path = file_input.get_validated_path()
                if not file_path:
                    # File not valid - don't submit
                    return
            except Exception:
                return
            prompt_text = config.prompt  # Use default prompt for file-based options
        elif self.selected_option == MenuOption.VIEW_HISTORY:
            # VIEW_HISTORY: No input required, submit immediately
            prompt_text = config.prompt
            file_path = None
        else:
            # FREESTYLE: prompt from textarea
            try:
                textarea = self.query_one(".input-widget", TextArea)
                prompt_text = textarea.text
                if not prompt_text or not prompt_text.strip():
                    return
            except Exception:
                return
            file_path = None

        # Emit submission message
        self.post_message(
            self.Submitted(
                option=self.selected_option,
                prompt=prompt_text,
                file_path=file_path,
                history_filter=self.history_filter if self.selected_option == MenuOption.VIEW_HISTORY else None
            )
        )
