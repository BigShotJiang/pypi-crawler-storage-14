"""Reusable UI components for the TUI."""
