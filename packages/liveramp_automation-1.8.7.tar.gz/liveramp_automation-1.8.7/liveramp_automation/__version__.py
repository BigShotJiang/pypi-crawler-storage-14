#   _ _
# | (_)_ _____ _ _ __ _ _ __  _ __
# | | \ V / -_) '_/ _` | '  \| '_ \
# |_|_|\_/\___|_| \__,_|_|_|_| .__/
#                            |_|
__title__ = "liveramp_automation"
__description__ = "Python Automation Framework for Humans."
__url__ = ""
__version__ = "1.8.7"
__build__ = 0x023100
__author__ = "Jasmine Qian"
__author_email__ = "jasmine.qian@liveramp.com"
__license__ = "Apache 2.0"
__copyright__ = "Copyright Jasmine Qian"
__cake__ = "\u2728 \U0001f370 \u2728"
