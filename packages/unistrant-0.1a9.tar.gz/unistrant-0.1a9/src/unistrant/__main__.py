from unistrant.app import main

if __name__ == "__main__":
    # Support invoking as a module. The script launcher invokes main
    # directly, so no special initialization should be performed here.
    main()
