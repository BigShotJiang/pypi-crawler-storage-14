class UnistrantError(Exception):
    pass


class RecordError(UnistrantError):
    pass
