"""
Quaternion class for rotation calculations.

To rotate a vector around and axis
>>> import numpy as np
>>> from karlternion import Quaternion
>>> # Make a rotation around [0, 0, 1] by 45 degree.
>>> q = Quaternion.from_axis_rotation(np.array([0, 0, 1]), np.deg2rad(45))
>>> v = np.array([1, 1, 0]) # Vector to rotate.
>>> q * v # Rotate vector.
array([0.0,  1.41421356e,  0.0])

To make a sequence of rotations, quaternions can be multiplied.
Consider a system where you have two rotation axes.
The first is Omega, which rotates around [0, 0, 1].
Then another axis, kappa, is mounted on the omega stage (i.e., when omega rotates, so will the kappa axis). When omega is at its origin, the kappa axis is [1, 1, 1].
>>> import numpy as np
>>> from karlternion import Quaternion
>>> omega = Quaternion.from_axis_rotation(np.array([0, 0, 1]), np.deg2rad(20))
>>> kappa = Quaternion.from_axis_rotation(np.array([1, 1, 1]), np.deg2rad(30))
>>> v = np.array([1, 0, 0])
>>> kappa * omega * v
array([ 0.77230395,  0.62470301, -0.1152942 ])

Can also convert to Euler angles,
>>> np.rad2deg((kappa * omega).to_euler())
array([23.53771943,  6.62059431, 38.96878306])

and rotation matrix,
>>> (kappa * omega).to_rotation_matrix()
array([[ 0.77230395, -0.54077305,  0.33333333],
       [ 0.62470301,  0.74175595, -0.24401694],
       [-0.1152942 ,  0.39668958,  0.9106836 ]])

Furthermore, it is also possible to do spherical interpolation, either between two quaternions (`Quaternion.slerp`) or two vectors.
>>> v1 = np.array([0, 0, 1])
>>> v2 = np.array([0, 1, 0])
>>> Quaternion.slerp_vector(v1, v2, 0.5)
array([0.        , 0.70710678, 0.70710678])

==============================================================================================

MIT License

Copyright (c) 2025 Karl O. R. Juul (kjuul@chem.au.dk) and Bo B. Iversen (bo@chem.au.dk)

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

"""

import numpy as np
import numpy.typing as npt

def signed_angle(v1: np.ndarray, v2: np.ndarray, up_reference: np.ndarray) -> float:
        cross = np.cross(v1, v2)
        dotprod = np.dot(v1, v2)
        sign = -1 if np.dot(cross, up_reference) < 0 else 1
        return np.arctan2(np.linalg.norm(cross), dotprod) * sign

def random_unit_vector(stream: np.random.Generator) -> np.ndarray:
    return Quaternion.random(stream) * np.array([1, 0, 0])

class Quaternion:
    # Good resource: https://danceswithcode.net/engineeringnotes/quaternions/quaternions.html
    def __init__(self, w: float = 1, x: float = 0, y: float = 0, z: float = 0) -> None:
        self._w = w
        self._x = x
        self._y = y
        self._z = z
    
    # -- Basic getters -- #
    def get(self) -> np.ndarray:
        '''Get an array of the quaternion coordinates (w, x, y, z).'''
        return np.array([self._w, self._x, self._y, self._z])
    
    def real(self) -> float:
        '''The selection function. Returns the real part of the quaternion (i.e., returns w).'''
        return self._w # Same as (q + q.conjugate()) / 2

    def imag(self) -> np.ndarray:
        '''Returns the imaginary part of the quaternion (i.e., returns x, y, z).'''
        return np.array([self._x, self._y, self._z]) # same as (q - q.conjugate()) / 2
    
    def conjugate(self) -> 'Quaternion':
        w, x, y, z = self.get()
        return Quaternion(w, -x, -y, -z)
    
    @staticmethod
    def identity() -> 'Quaternion':
        return Quaternion(1, 0, 0, 0)

    # -- Operators -- #
    def __add__(self, other: 'Quaternion') -> 'Quaternion':
        return Quaternion(*(self.get() + other.get()))
    
    def __sub__(self, other: 'Quaternion') -> 'Quaternion':
        return self + (-1) * other
    
    def __neg__(self):
        return Quaternion(*(-self.get()))

    def __truediv__(self, other) -> 'Quaternion':
        if isinstance(other, Quaternion):
            return self.__mul__(other.inverse())
        return self.__mul__(1/other)

    def __mul__(self, other) -> 'Quaternion':
        # Source: [QIA].
        if isinstance(other, Quaternion):
            s1, v1 = self.real(), self.imag()
            s2, v2 = other.real(), other.imag()
            return Quaternion(s1*s2 - np.dot(v1, v2), *(np.cross(v1, v2) + s1*v2 + s2*v1)) 
        elif isinstance(other, np.ndarray):
            assert other.shape == (3,), "Vector must be of shape (3,), but has shape" + other.shape + "!"
            v: Quaternion = Quaternion(0, *other)
            vrot: Quaternion = self * v * self.inverse()
            return vrot.imag() # Return the x, y, z components of the resulting quaternion.
        else: # Assumes scalar property.
            return Quaternion(*(other*self.get())) # Multiply scalar unto each coordinate.

    def __rmul__(self, other) -> 'Quaternion':
        return self.__mul__(other)

    def __matmul__(self, other: npt.NDArray[np.float32]):
        return np.apply_along_axis(self.__mul__, axis=1, arr=other)

    def __pow__(self, other: float) -> 'Quaternion':
        return self.pow(other)

    def dot(self, other: 'Quaternion') -> float:
        '''Quaternion dot product.'''
        # Sourece: [QIA], coll. 2.
        return np.dot(self.get(), other.get())

    def exp(self) -> 'Quaternion':
        '''Exponential. Quaternion must be a quaternion with the real part equal to 0.'''
        ## https://math.stackexchange.com/questions/939229/unit-quaternion-to-a-scalar-power
        #w: float = self.real()
        #u: Quaternion = (self - self.conjugate()) * 0.5
        #v = u.imag()
        #return np.exp(w) * Quaternion.from_axis_rotation(v / np.linalg.norm(v), 2 * u.magnitude())
        assert np.isclose(self.real(), 0)
        # u = imag(), dot(u, v) = theta. Since |v|=1 and u propto v, v = u/|u|.
        # Thus, theta = dot(u, u/|u|) = dot(u, u)/|u| = |u|**2/|u| = |u|
        theta = np.linalg.norm(self.imag())
        v = self.imag() # Only for cases where theta == 0.
        if not np.isclose(theta, 0):
            v = self.imag() / theta
        
        return Quaternion(np.cos(theta), *(np.sin(theta)*v))

    def log(self) -> 'Quaternion':
        '''Natural logarithm. Must be a unit quaternion.'''
        ## https://math.stackexchange.com/questions/939229/unit-quaternion-to-a-scalar-power
        #u: Quaternion = (self - self.conjugate()) * 0.5
        #u /= u.magnitude()
        # Source: [QIA].
        assert np.isclose(self.magnitude(), 1.0)
        theta = np.arccos(self.real())
        v = self.imag() / np.sin(theta)
        return Quaternion(0, *(theta * v))

    def pow(self, scalar: float) -> 'Quaternion':
        '''Exponentiation of unit quaternion.'''
        # Source: [QIA].
        return Quaternion.exp(scalar * Quaternion.log(self))
    
    @staticmethod
    def slerp(q0: 'Quaternion', q1: 'Quaternion', t: float) -> 'Quaternion':
        '''Spherical interpolation of q0 to q1 by factor t [0, 1]. Assumes q0 and q1 are unit quaternions.'''
        # Source: [QIA], p.g 42.
        #return q0 * (q0.conjugate() * q1)**t
        # Numerical stable version (from [QIA]) - eqn. 6.13, p. 47.
        if Quaternion.equals(q0, q1) or Quaternion.equals(q0, -q1):
            return q0
        
        omega = np.arccos(q0.dot(q1))
        return (q0 * np.sin((1 - t) * omega) + q1 * np.sin(t * omega)) / np.sin(omega)
    
    @staticmethod
    def slerp_vector(v1: npt.NDArray[np.float32], v2: npt.NDArray[np.float32], t: float) -> npt.NDArray[np.float32]:
        '''Convenience rotation for spherical interpolation from vector v1 to vector v2.'''
        q_final = Quaternion.from_vectors(v1, v2)
        qt = Quaternion.slerp(Quaternion.identity(), q_final, t)
        return qt * v1
    
    def equals(self, other: 'Quaternion', tol=1e-4):
        return self.distance(other) < tol

    def magnitude(self) -> float:
        '''The magnitude of the quaternion. Rotation quaternions should have unit magnitude.'''
        return np.sqrt(self.sqr_magnitude())

    def sqr_magnitude(self) -> float:
        '''Get the square magnitude of the quaternion.'''
        # Sourece: [QIA].
        w, x, y, z = self.get()
        return w * w + x * x + y * y + z * z # Same as self * self.congugate()

    def inverse(self) -> 'Quaternion':
        '''Note that for rotation quaternions, the inverse equals the conjugate.'''
        # Sourece: [QIA]
        return self.conjugate() / self.sqr_magnitude()
    
    def distance(self, other: 'Quaternion') -> float:
        return Quaternion.magnitude(self - other) # Source [QIA], top of p. 35.

    # -- Conversions -- #
    def to_euler(self) -> tuple[float]:
        '''https://en.wikipedia.org/wiki/Conversion_between_quaternions_and_Euler_angles'''
        w, x, y, z = self.get()
        # roll (x-axis rotation)
        sinr_cosp = 2 * (w * x + y * z)
        cosr_cosp = 1 - 2 * (x * x + y * y)
        roll = np.arctan2(sinr_cosp, cosr_cosp)

        # pitch (y-axis rotation)
        sinp = np.sqrt(1 + 2 * (w * y - x * z))
        cosp = np.sqrt(1 - 2 * (w * y - x * z))
        pitch = 2 * np.arctan2(sinp, cosp) - np.pi / 2

        # yaw (z-axis rotation)
        siny_cosp = 2 * (w * z + x * y)
        cosy_cosp = 1 - 2 * (y * y + z * z)
        yaw = np.arctan2(siny_cosp, cosy_cosp)

        return roll, pitch, yaw
    
    def get_axis_angle(self) -> tuple[npt.NDArray[np.float32], float]:
        '''Return a tuple of the axis and angle (radians) of rotation.'''
        angle = 2 * np.arccos(self.real())
        s = np.sqrt(1 - self.real()**2)
        if s < 1E-20: # If s close to zero, direction of axis not important
            return np.array([1, 0, 0]), angle
        return self.imag() / s, angle

    @classmethod
    def from_euler(cls, roll: float, pitch: float, yaw: float) -> 'Quaternion':
        '''roll (x), pitch (y), yaw (z), angles are in radians.
        https://en.wikipedia.org/wiki/Conversion_between_quaternions_and_Euler_angles'''
        # Abbreviations for the various angular functions
        cr = np.cos(roll * 0.5)
        sr = np.sin(roll * 0.5)
        cp = np.cos(pitch * 0.5)
        sp = np.sin(pitch * 0.5)
        cy = np.cos(yaw * 0.5)
        sy = np.sin(yaw * 0.5)

        w = cr * cp * cy + sr * sp * sy
        x = sr * cp * cy - cr * sp * sy
        y = cr * sp * cy + sr * cp * sy
        z = cr * cp * sy - sr * sp * cy

        return cls(w, x, y, z)
    
    @classmethod
    def from_axis_rotation(cls, axis: np.ndarray, angle: float) -> 'Quaternion':
        '''Create a quaternion that rotates about a axis by angle. Angle in radians.'''
        # https://math.stackexchange.com/questions/40164/how-do-you-rotate-a-vector-by-a-unit-quaternion
        axis = axis / np.linalg.norm(axis)
        a2 = angle * 0.5
        x, y, z = axis
        return cls(np.cos(a2), np.sin(a2)*x, np.sin(a2)*y, np.sin(a2)*z)
    
    @classmethod
    def from_vectors(cls, from_vector: npt.NDArray[np.float32], to_vector: npt.NDArray[np.float32]) -> 'Quaternion':
        '''Create a quaternion to rotate from from_vector to to_vector'''
        axis = np.cross(from_vector, to_vector)
        angle = np.arccos(np.dot(from_vector, to_vector)/(np.linalg.norm(from_vector)*np.linalg.norm(to_vector)))
        return Quaternion.from_axis_rotation(axis, angle)
    
    @classmethod
    def random(cls, stream: np.random.Generator) -> 'Quaternion':
        '''Generates a uniform random quaternion'''
        # https://stackoverflow.com/questions/38978441/creating-uniform-random-quaternion-and-multiplication-of-two-quaternions
        # Adapted from James J. Kuffner, 2004
        values = stream.random(3)
        # Magitude ensures that the total length is 1.
        magnutude = np.sqrt(values[0])
        rest_magnitude = np.sqrt(1.0 - values[0])
        angle1 = 2*np.pi*values[1]
        angle2 = 2*np.pi*values[2]
        w = np.cos(angle2)*magnutude
        x = np.sin(angle1)*rest_magnitude
        y = np.cos(angle1)*rest_magnitude
        z = np.sin(angle2)*magnutude
        return cls(w, x, y, z)
            
    @staticmethod
    def get_look_direction_rotation(up_vector: np.ndarray, look_at_vector: np.ndarray, local_forward: np.ndarray, local_up: np.ndarray) -> 'Quaternion':
        '''Get rotation to rotate to look in the direction of <look_at_vector> while having <up_vector> as the up direction (for a camera).
        local_forward and local_up are the vectors defining what is forward and up in the camera's local frame of reference.'''
        # To look in a direction, first rotating to face the desired direction.
        # Then tilt view to have the correct direction up.

        # Unit vectors pointing in up and forward in the end-coordinate system.
        up_axis = up_vector / np.linalg.norm(up_vector)
        look_at_axis = look_at_vector / np.linalg.norm(look_at_vector)

        # To align forwards, first find the rotation vector (one perpendicular to the plane spanned by global forward and the final forward).
        # This vector is normal to the plane spanned by df and final forward.
        df = look_at_axis - local_forward
        # Find the axis to rotate about in order to align the forwards.
        if np.all(np.isclose(df, 0)):
            # If already looking forward, there will be no rotation. This is just decor for the Quaternion.from_axis_rotation to work
            # as it requires that the axis has unit length.
            forward_align_axis = up_axis
        else:
            # Get a vector perpendicular to the plane of rotation (rotation vector).
            forward_align_axis = np.cross(look_at_axis, df)
            forward_align_axis /= np.linalg.norm(forward_align_axis)
        
        # Rotate to align forwards.
        forward_angle = signed_angle(local_forward, look_at_axis, up_axis) # Angle between the forward and global forward.
        q1: Quaternion = Quaternion.from_axis_rotation(forward_align_axis, forward_angle)

        # Rotate around forward (which is now the same as Transform.forward in local space) to align up.
        up_angle = signed_angle(q1.conjugate() * local_up, up_axis, forward_align_axis)
        q2: Quaternion = Quaternion.from_axis_rotation(local_forward, up_angle)
        return q2 * q1
    
    def to_rotation_matrix(self) -> np.ndarray:
        # https://automaticaddison.com/how-to-convert-a-quaternion-to-a-rotation-matrix/
        w, x, y, z = self.get()
        ww, wx, wy, wz = w * w, w * x, w * y, w * z
        xx, xy, xz = x * x, x * y, x * z
        yy, yz = y * y, y * z
        zz = z * z
        return 2*np.array([[ww + xx - 0.5, xy - wz, xz + wy],
                           [xy + wz, ww + yy - 0.5, yz - wx],
                           [xz - wy, yz + wx, ww + zz - 0.5]])
    
    # -- To string -- #
    def __str__(self) -> str:
        return str(self.get())
    
    def __repr__(self) -> str:
        return self.__str__()

# References:
# [QIA]: Quaternions, Interpolation and Animation. (1998). Dam, E. B., Koch, M., Lillholm, M.
