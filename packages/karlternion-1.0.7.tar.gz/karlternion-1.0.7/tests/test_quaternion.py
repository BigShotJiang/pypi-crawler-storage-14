import unittest
from karlternion.Rotations import Quaternion, random_unit_vector
import numpy as np
import numpy.testing as nptest

class QuatTest(unittest.TestCase):
    def test_get(self):
        q = Quaternion(1, 2, 3, 4)
        nptest.assert_array_equal(q.get(), np.array([1, 2, 3, 4]))
    
    def test_real(self):
        q = Quaternion(1, 2, 3, 4)
        self.assertEqual(q.real(), 1)

    def test_imag(self):
        q = Quaternion(1, 2, 3, 4)
        nptest.assert_array_equal(q.imag(), np.array([2, 3, 4]))

    def test_conjugate(self):
        q = Quaternion(1, 2, 3, 4).conjugate()
        nptest.assert_array_equal(q.get(), np.array([1, -2, -3, -4]))

    def test_add(self):
        q = Quaternion(1, 2, 3, 4)
        nptest.assert_array_equal((q + q).get(), np.array([2, 4, 6, 8]))

    def test_sub(self):
        q = Quaternion(1, 2, 3, 4)
        nptest.assert_array_equal((q - q).get(), np.zeros(4))

    def test_from_axis_rotation(self):
        q = Quaternion.from_axis_rotation(np.array([1, 1, 0]), np.deg2rad(45))
        self.assertAlmostEqual(np.rad2deg(np.arccos(q.real())), 45/2)
        # Check that the imag part is prop to (1,1,0) by testing whether the unit vector
        # pointing in that direction is equal to a unit vector pointing in (1,1,0) direction.
        nptest.assert_array_almost_equal(q.imag() / np.linalg.norm(q.imag()),
                                         np.array([1/np.sqrt(2), 1/np.sqrt(2), 0]))
        self.assertAlmostEqual(q.magnitude(), 1)

    def test_mul_quat_vec(self):
        ang = np.deg2rad(90)
        q = Quaternion.from_axis_rotation(np.array([1, 0, 0]), ang)
        v = np.array([0, 1, 0])
        R = np.array([[1, 0, 0], [0, np.cos(ang), -np.sin(ang)], [0, np.sin(ang), np.cos(ang)]])
        nptest.assert_array_almost_equal(q * v, v @ R.T)

    def test_to_euler(self):
        q = Quaternion.from_axis_rotation(np.array([1, 1, 1]), np.deg2rad(120))
        nptest.assert_almost_equal(np.rad2deg(q.to_euler()), np.array([90, 0, 90]))
        q = Quaternion.from_axis_rotation(np.array([1, 0, 0]), np.deg2rad(60))
        nptest.assert_almost_equal(np.rad2deg(q.to_euler()), np.array([60, 0, 0]))
        q = Quaternion.from_axis_rotation(np.array([0, 1, 0]), np.deg2rad(60))
        nptest.assert_almost_equal(np.rad2deg(q.to_euler()), np.array([0, 60, 0]))
        q = Quaternion.from_axis_rotation(np.array([0, 0, 1]), np.deg2rad(60))
        nptest.assert_almost_equal(np.rad2deg(q.to_euler()), np.array([0, 0, 60]))

    def test_mul_quat_quat(self):
        q1 = Quaternion.from_axis_rotation(np.array([1, 0, 0]), np.deg2rad(45))
        q2 = Quaternion.from_axis_rotation(np.array([0, 1, 0]), np.deg2rad(45))
        nptest.assert_array_almost_equal(np.rad2deg((q2 * q1).to_euler()), np.array([45, 45, 0]))

    def test_sqr_magnitude(self):
        q = Quaternion(1, 2, 3, 4)
        self.assertEqual(q.sqr_magnitude(), 1**2 + 2**2 + 3**2 + 4**2)
        self.assertEqual(q.sqr_magnitude(), (q * q.conjugate()).real())

    def test_from_euler(self):
        ang = np.deg2rad(90)
        q = Quaternion.from_euler(ang, 0, 0)
        nptest.assert_array_almost_equal(q.get(), np.array([1/np.sqrt(2), 1/np.sqrt(2), 0, 0]))
        q = Quaternion.from_euler(*np.deg2rad([30, 40, 50]))
        nptest.assert_array_almost_equal(np.rad2deg(q.to_euler()), np.array([30, 40, 50]))

    def test_random_unit_vector(self):
        stream = np.random.default_rng(seed=42)
        vec = random_unit_vector(stream)
        self.assertAlmostEqual(np.linalg.norm(vec), 1)

    def test_log(self):
        theta = np.pi/3
        v = np.array([0, 1, 1]).astype(np.float32)
        q = Quaternion.from_axis_rotation(v, 2*theta)
        log_q = q.log()
        v /= np.linalg.norm(v)
        log_q_expected = Quaternion(0, *(theta*v))
        nptest.assert_array_almost_equal(log_q.get(), log_q_expected.get())

    def test_exp(self):
        theta = np.pi/3
        v = np.array([1, 2, 0.])
        q = Quaternion.from_axis_rotation(v, 2*theta)
        q_result = Quaternion.exp(q.log())
        v /= np.linalg.norm(v)
        result_expected = Quaternion(np.cos(theta), *(np.sin(theta)*v))
        nptest.assert_array_almost_equal(q_result.get(), result_expected.get())

    def test_pow(self):
        theta = np.pi/3
        v = np.array([1, 2, 0.])
        q = Quaternion.from_axis_rotation(v, 2*theta)
        t = 0.5
        # Testing with prop. 15 from QIA.
        nptest.assert_array_almost_equal(Quaternion.log(q**t).get(), (t * q.log()).get())

    def test_dot(self):
        q1 = Quaternion(1, 2, 3, 4)
        q2 = Quaternion(1, 3, 4, 5)
        dot = q1.dot(q2)
        self.assertAlmostEqual(dot, 1*1 + 2*3 + 3*4 + 4*5)

    def test_slerp(self):
        v1 = np.array([0, 0, 1])
        v2 = np.array([0, 1, 0])
        q = Quaternion.from_axis_rotation(np.cross(v1, v2), np.arccos(np.dot(v1, v2)))
        for i in np.linspace(0, 1, 11):
            qs = Quaternion.slerp(Quaternion.identity(), q, i)
            expected_rot = Quaternion.from_axis_rotation(np.array([1, 0, 0]), -np.pi/2 * i)
            nptest.assert_array_almost_equal(qs.get(), expected_rot.get())

    def test_matmul(self):
        v1 = np.array([1, 1, 0])
        v2 = np.array([0, 3, 2])
        q = Quaternion.from_axis_rotation(np.array([1, 0, 1]), np.deg2rad(30))
        V = np.vstack((v1, v2))
        rotated = q @ V
        expected_rot_v1 = q * v1
        expected_rot_v2 = q * v2
        expected_rotated = np.vstack((expected_rot_v1, expected_rot_v2))
        nptest.assert_array_almost_equal(rotated, expected_rotated)

    def test_from_vectors(self):
        v1 = np.array([1, 0, 0])
        v2 = np.array([0, 0, 1])
        q = Quaternion.from_vectors(v1, v2)
        q_expected = Quaternion.from_axis_rotation(np.array([0, 1, 0]), -np.deg2rad(90))
        nptest.assert_array_almost_equal(q.get(), q_expected.get())
