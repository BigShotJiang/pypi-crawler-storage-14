# Quaternion
Class for quaternion calculations in python.

## Installation
Download from pypi using
`pip install karlternion`

## Example of use
To rotate a vector around and axis
```
>>> import numpy as np
>>> from karlternion import Quaternion
>>> # Make a rotation around [0, 0, 1] by 45 degree.
>>> q = Quaternion.from_axis_rotation(np.array([0, 0, 1]), np.deg2rad(45))
>>> v = np.array([1, 1, 0]) # Vector to rotate.
>>> q * v # Rotate vector.
array([0.0,  1.41421356e,  0.0])
```
To make a sequence of rotations, quaternions can be multiplied.
Consider a system where you have two rotation axes.
The first is Omega, which rotates around [0, 0, 1].
Then another axis, kappa, is mounted on the omega stage (i.e., when omega rotates, so will the kappa axis). When omega is at its origin, the kappa axis is [1, 1, 1].
```
>>> import numpy as np
>>> from karlternion import Quaternion
>>> omega = Quaternion.from_axis_rotation(np.array([0, 0, 1]), np.deg2rad(20))
>>> kappa = Quaternion.from_axis_rotation(np.array([1, 1, 1]), np.deg2rad(30))
>>> v = np.array([1, 0, 0])
>>> kappa * omega * v
array([ 0.77230395,  0.62470301, -0.1152942 ])
```
Can also convert to Euler angles,
```
>>> np.rad2deg((kappa * omega).to_euler())
array([23.53771943,  6.62059431, 38.96878306])
```
and rotation matrix,
```
>>> (kappa * omega).to_rotation_matrix()
array([[ 0.77230395, -0.54077305,  0.33333333],
       [ 0.62470301,  0.74175595, -0.24401694],
       [-0.1152942 ,  0.39668958,  0.9106836 ]])
```

Furthermore, it is also possible to do spherical interpolation, either between two quaternions (`Quaternion.slerp`) or two vectors.
```
>>> v1 = np.array([0, 0, 1])
>>> v2 = np.array([0, 1, 0])
>>> Quaternion.slerp_vector(v1, v2, 0.5)
array([0.        , 0.70710678, 0.70710678])
```