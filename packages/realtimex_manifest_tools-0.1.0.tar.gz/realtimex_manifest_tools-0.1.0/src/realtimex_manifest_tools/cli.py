# server.py
from fastmcp import FastMCP, Client, Context

import os
import json
import asyncio

from typing import List, Dict, Optional, Union

mcp = FastMCP("RealTimeX.AI Document Manifest Tools")

@mcp.tool
async def analyze_document_manifest(file_path:str) -> Dict:
    """Analyze manifest document."""
    import requests

    base_url = "http://testcrm.rtworkspace.com:8002"

    file_name = os.path.basename(file_path)

    url = f"{base_url}/analyze"

    files = {
        "file": (file_name, open(file_path, "rb"), "application/pdf")
    }

    response = requests.post(url, files=files)

    analysis = response.json()

    batch_id = analysis["batch_id"]

    # result = {
    #     "status": "success",
    #     "overall_analysis_status": analysis["overall_status"],
    #     "insights": analysis["insights"],
    #     "recommended_actions": analysis["recommended_actions"],
    #     "ui-components":[
    #         {
    #             "dataType": 'mcpUi',
    #             "data": {
    #                 "content": [
    #                     {
    #                         "type": "resource",
    #                         "resource": {
    #                             "uri": f'ui://doc-manifest/{batch_id}',
    #                             "mimeType": 'text/uri-list',
    #                             "text": f'{base_url}/?batchId={batch_id}',
    #                         }
    #                     }
    #                 ]   
    #             }    
    #         }
    #     ]
    # }

    result = {
        "status": "success",
        "overall_analysis_status": analysis["overall_status"],
        "insights": analysis["insights"],
        "recommended_actions": analysis["recommended_actions"],
        "ui-components":[
            {
                "dataType": "html",
                "data": {
                    "content": f"<a href='{base_url}/?batchId={batch_id}'>See more...</a>",
                    "language": None
                }    
            }
        ]
    }

    return result


# async def test():
#     async with Client(mcp) as client:
#         tools = await client.list_tools()
#         print("tools",tools)
#         result = await client.call_tool("analyze_document_manifest", {"file_path": "/Users/phuongnguyen/.realtimex.ai/storage/working-data/docmanifest/BATCH_2017_PTL_YAN_001.pdf"})
#         print(result.content[0].text)

# def main():
#     import asyncio
#     asyncio.run(test())



# if __name__ == "__main__":
#     import asyncio
#     asyncio.run(test())

def main():
    mcp.run()