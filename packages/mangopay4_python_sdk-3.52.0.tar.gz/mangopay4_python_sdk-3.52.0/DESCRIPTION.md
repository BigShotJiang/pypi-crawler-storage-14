This SDK is a client library for interacting with the Mangopay API.
