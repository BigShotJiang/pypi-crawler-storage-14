"""Classical template matching algorithm
"""

from .RV_precision import RV_precision
