import numpy as np


def weighted_mean(orders_RV, squared_uncertainties, RV_variance_estimator="simple"):
    finite_rvs = np.isfinite(orders_RV)
    finite_errs = np.isfinite(squared_uncertainties)

    if not np.equal(finite_errs, finite_rvs).all():
        raise Exception("Different position of finite elements on the weighted mean!")

    weights = np.divide(1, squared_uncertainties)  # 1/ e**2
    sum_weights = np.nansum(weights, axis=1)
    final_RV = np.nansum(np.multiply(weights, orders_RV), axis=1) / sum_weights

    No = squared_uncertainties.shape[1] - np.sum(np.isnan(squared_uncertainties), axis=1)
    if RV_variance_estimator == "simple":
        final_error = np.sqrt(1 / (sum_weights))
    elif RV_variance_estimator == "with_correction":
        final_error = np.sqrt(
            np.nansum(weights * (orders_RV - final_RV[:, np.newaxis]) ** 2, axis=1) / (sum_weights * (No - 1)),
        )

    # Ensuring that we never pass np.inf outside
    final_error[np.isinf(final_error)] = np.nan
    final_RV[np.isinf(final_RV)] = np.nan

    return final_RV, final_error
