﻿# Windows Security Audit Script
# Load shared functions
. "$PSScriptRoot\includes\functions.ps1"

# Run security audits
Invoke-W30
Invoke-W40
Invoke-W41