#!/bin/zsh
# Get the directory where this script is located
DIR="$(cd "$(dirname "$0")" && pwd)"
source "$DIR/includes/functions.sh"

# Run security audits
U-37
U-39