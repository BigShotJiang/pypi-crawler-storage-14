import asyncio
import typer
from typing import Final

from typi.typi import TypiConfiguration, Typi
from typi.parser import TypstTomlProjectConfigurationParser
from typi.git import GitDependencyInstaller

from aiopath import AsyncPath

app = typer.Typer()

PROJECT_CONFIG_FILE: Final = "typi.toml"


async def sync(quiet: bool) -> None:
    parser = TypstTomlProjectConfigurationParser.create()
    typi = Typi.create(
        config=TypiConfiguration(verbose=not quiet),
        project=await parser.parse(AsyncPath(PROJECT_CONFIG_FILE)),
        installer=GitDependencyInstaller.create(parser=parser),
    )

    await typi.sync()


@app.command()
def main(
    quiet: bool = typer.Option(False, "--quiet", help="Suppress verbose logging"),
) -> None:
    """
    Installs private local packages from git repositories.
    """
    asyncio.run(sync(quiet=quiet))


if __name__ == "__main__":
    app()
