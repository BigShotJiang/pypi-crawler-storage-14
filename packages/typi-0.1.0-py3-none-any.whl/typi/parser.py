import tomllib
from typing import Any, Final
from dataclasses import dataclass

from typi.common import Metadata, DependencyInfo

from aiopath import AsyncPath
from async_lru import alru_cache


type TomlData = dict[str, Any]

GIT_SUFFIX: Final = "git+"


@dataclass(frozen=True)
class TomlProjectConfiguration:
    metadata: Metadata
    dependencies: list[DependencyInfo]


class TypstTomlProjectConfigurationParser:
    @staticmethod
    def create() -> "TypstTomlProjectConfigurationParser":
        return TypstTomlProjectConfigurationParser()

    @alru_cache(maxsize=None)
    async def parse(self, path: AsyncPath) -> TomlProjectConfiguration:
        data = tomllib.loads(await path.read_text(encoding="utf-8"))

        metadata = self._parse_metadata(data)
        dependencies = await self._parse_dependencies(data)

        return TomlProjectConfiguration(metadata=metadata, dependencies=dependencies)

    async def metadata_from(self, config_file: AsyncPath) -> Metadata:
        return (await self.parse(config_file)).metadata

    def _parse_metadata(self, data: TomlData) -> Metadata:
        project_data = data.get("project", {})
        name = project_data.get("name", "unknown")
        version = project_data.get("version", "0.0.0")

        return Metadata(name=name, version=version)

    async def _parse_dependencies(self, data: TomlData) -> list[DependencyInfo]:
        parsed = []

        for dependency in data.get("project", {}).get("dependencies", []):
            if not dependency.startswith(GIT_SUFFIX):
                raise ValueError(
                    f"Unsupported dependency format: {dependency}. URL must start with '{GIT_SUFFIX}'."
                )

            parsed.append(
                DependencyInfo(
                    repository=(repo := dependency[len(GIT_SUFFIX) :]),
                    name=repo.split("/")[-1].replace(".git", ""),
                )
            )

        return parsed
