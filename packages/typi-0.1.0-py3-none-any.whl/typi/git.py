import sys
import os
import asyncio
from typing import Final, Protocol
from dataclasses import dataclass

from typi.common import DependencyInfo, Metadata

import aioshutil
from aiopath import AsyncPath


TYPI_CACHE_NAME: Final = ".typi_cache"
PROJECT_CONFIG_FILE: Final = "typst.toml"


class ProjectConfigurationParser(Protocol):
    async def metadata_from(self, config_file: AsyncPath) -> Metadata:
        """Parses project configuration file and returns its metadata."""
        ...


@dataclass(frozen=True)
class GitDependencyInstaller:
    """
    Installs Typst dependencies by cloning Git repositories and installing the
    packages locally.
    """

    parser: ProjectConfigurationParser
    cache_directory: AsyncPath
    typst_data_directory: AsyncPath

    @staticmethod
    def create(parser: ProjectConfigurationParser) -> "GitDependencyInstaller":
        return GitDependencyInstaller(
            parser=parser,
            cache_directory=temp_directory(),
            typst_data_directory=typst_data_directory(),
        )

    async def install(self, dependency: DependencyInfo, *, verbose: bool) -> None:
        cache = await self.cache_for(dependency)

        try:
            await self.clone(dependency, to=cache, verbose=verbose)
            metadata = await self.parser.metadata_from(
                config_file=cache / PROJECT_CONFIG_FILE
            )
            install_directory = self.install_directory_from(metadata)

            await self.move_package_files(dependency, cache, install_directory, verbose)

            print(f"✔ Installed {metadata.name}:{metadata.version}")
        except Exception as e:
            print(f"✖ Failed to install {dependency.name}: {e}")

    async def cache_for(self, dependency: DependencyInfo) -> AsyncPath:
        if await (repo_cache := self.cache_directory / dependency.name).exists():
            await aioshutil.rmtree(repo_cache)

        await repo_cache.mkdir(parents=True)

        return repo_cache

    async def clone(
        self, dependency: DependencyInfo, *, to: AsyncPath, verbose: bool
    ) -> None:
        if verbose:
            print(f"[{dependency.name}] Cloning {dependency.repository}...")

        process = await asyncio.create_subprocess_exec(
            "git",
            "clone",
            "--depth",
            "1",
            dependency.repository,
            to.resolve(),
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )

        _, stderr = await process.communicate()

        if process.returncode != 0:
            raise RuntimeError(
                f"Git clone failed for '{dependency.name}' (Exit: {process.returncode}):\n"
                f"{stderr.decode().strip()}"
            )

    def install_directory_from(self, metadata: Metadata) -> AsyncPath:
        return self.typst_data_directory / metadata.name / metadata.version

    async def move_package_files(
        self,
        dependency: DependencyInfo,
        repo_directory: AsyncPath,
        install_directory: AsyncPath,
        verbose: bool,
    ) -> None:
        if verbose:
            print(f"[{dependency.name}] Installing to {install_directory}...")

        if await install_directory.exists():
            await aioshutil.rmtree(install_directory)

        await install_directory.mkdir(parents=True, exist_ok=True)

        await aioshutil.copytree(repo_directory, install_directory, dirs_exist_ok=True)


def typst_data_directory() -> AsyncPath:
    match sys.platform:
        case "win32":
            print("Detected Windows OS")
            return AsyncPath(os.environ["APPDATA"]) / "typst" / "packages" / "local"
        case "darwin":
            print("Detected macOS")
            return (
                AsyncPath.home()
                / "Library"
                / "Application Support"
                / "typst"
                / "packages"
                / "local"
            )
        case _:  # Linux/Unix
            print("Detected Linux/Unix OS")
            xdg_data = os.environ.get(
                "XDG_DATA_HOME", os.path.expanduser("~/.local/share")
            )
            return AsyncPath(xdg_data) / "typst" / "packages" / "local"


def temp_directory() -> AsyncPath:
    return AsyncPath(__file__).parent / TYPI_CACHE_NAME
