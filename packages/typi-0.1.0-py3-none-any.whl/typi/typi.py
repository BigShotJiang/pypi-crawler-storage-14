import asyncio
from typing import Protocol
from dataclasses import dataclass

from typi.common import DependencyInfo


@dataclass(frozen=True)
class TypiConfiguration:
    verbose: bool


class ProjectConfiguration(Protocol):
    @property
    def dependencies(self) -> list[DependencyInfo]:
        """Returns a list of dependencies for the project."""
        ...


class DependencyInstaller(Protocol):
    async def install(self, dependency: DependencyInfo, *, verbose: bool) -> None:
        """Installs the given dependency."""
        ...


@dataclass(frozen=True)
class Typi:
    config: TypiConfiguration
    project: ProjectConfiguration
    installer: DependencyInstaller

    @staticmethod
    def create(
        config: TypiConfiguration,
        project: ProjectConfiguration,
        installer: DependencyInstaller,
    ) -> "Typi":
        return Typi(config=config, project=project, installer=installer)

    async def sync(self) -> None:
        await asyncio.gather(
            *(
                self.installer.install(it, verbose=self.config.verbose)
                for it in self.project.dependencies
            )
        )
