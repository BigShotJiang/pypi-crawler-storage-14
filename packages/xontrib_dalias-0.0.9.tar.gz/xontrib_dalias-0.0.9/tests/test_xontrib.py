def test_it_loads(load_xontrib):
    load_xontrib("dalias")
