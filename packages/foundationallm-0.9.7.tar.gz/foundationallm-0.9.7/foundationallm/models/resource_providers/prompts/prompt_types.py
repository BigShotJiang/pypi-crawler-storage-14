from enum import Enum

class PromptTypes(str, Enum):
    """Enumerator of Prompt Types."""
    MULTIPART = "multipart"
