class MessageContentItemTypes:
   """Message Content Item Type Constants"""
   TEXT = "text"
   IMAGE_FILE = "image_file"
   FILE_PATH = "file_path"
