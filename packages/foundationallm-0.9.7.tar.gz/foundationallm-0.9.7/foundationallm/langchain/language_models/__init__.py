"""Language model module"""
from .language_model_factory import LanguageModelFactory
