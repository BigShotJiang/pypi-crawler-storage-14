"""FoundationaLLM LangChain module"""
