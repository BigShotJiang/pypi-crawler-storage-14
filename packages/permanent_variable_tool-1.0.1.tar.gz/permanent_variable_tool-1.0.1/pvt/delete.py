import os 
import inspect
 
def delete(variable):
    """
    Deletes a variable file with the given name from the 'data' subdirectory.
    
    Args:
        variable (str): The name of the variable file to be deleted (without .var extension)
        
    Raises:
        FileNotFoundError: If the specified variable file doesn't exist
        
    Note:
        - The file should be located in a 'data' subdirectory of the current script's directory
        - Files should have the '.var' extension 
    """

    try:
        if not isinstance(variable, str):
            frame = inspect.currentframe().f_back 
            try:
                # 在当前作用域查找变量名 
                for name, val in frame.f_locals.items(): 
                    if val is variable:
                        variable = name  # 替换为变量名 
                        break
                else:
                    variable = str(variable)  # 找不到则转为字符串
            finally:
                del frame 
    except:
        # 如果出现任何异常（如变量未定义），直接当作字符串 
        variable = str(variable)
    
    path = os.path.join(f"C:\\pvt_data\\{variable}.var") 
    
    try:
        os.remove(path)  
    except FileNotFoundError as e:
        print(e)
