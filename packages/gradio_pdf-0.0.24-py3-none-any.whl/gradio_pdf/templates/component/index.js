import * as e from "../../../../../assets/svelte/svelte_internal_client.js";
import { getContext as as, untrack as fe, createEventDispatcher as ae, onMount as je, tick as se, onDestroy as os } from "../../../../../assets/svelte/svelte_svelte.js";
import "../../../../../assets/svelte/svelte_internal_flags_legacy.js";
import { spring as Ee } from "../../../../../assets/svelte/svelte_motion.js";
import "../../../../../assets/svelte/svelte_transition.js";
e.from_svg('<svg width="100%" height="100%" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="12" y1="19" x2="12" y2="5"></line><polyline points="5 12 12 5 19 12"></polyline></svg>');
e.from_svg('<svg width="100%" height="100%" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="12" y1="5" x2="12" y2="19"></line><polyline points="19 12 12 19 5 12"></polyline></svg>');
e.from_svg('<svg xmlns="http://www.w3.org/2000/svg" width="12px" height="24px" fill="currentColor" stroke-width="1.5" viewBox="0 0 12 24"><path d="M9 6L3 12L9 18" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" fill="none"></path></svg>');
e.from_svg('<svg xmlns="http://www.w3.org/2000/svg" width="24px" height="24px" fill="currentColor" stroke-width="1.5" viewBox="0 0 24 24" color="currentColor"><path stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" d="M21.044 5.704a.6.6 0 0 1 .956.483v11.626a.6.6 0 0 1-.956.483l-7.889-5.813a.6.6 0 0 1 0-.966l7.89-5.813ZM10.044 5.704a.6.6 0 0 1 .956.483v11.626a.6.6 0 0 1-.956.483l-7.888-5.813a.6.6 0 0 1 0-.966l7.888-5.813Z"></path></svg>');
e.from_svg('<svg width="100%" height="100%" viewBox="0 0 32 32"><path d="M28.828 3.172a4.094 4.094 0 0 0-5.656 0L4.05 22.292A6.954 6.954 0 0 0 2 27.242V30h2.756a6.952 6.952 0 0 0 4.95-2.05L28.828 8.829a3.999 3.999 0 0 0 0-5.657zM10.91 18.26l2.829 2.829l-2.122 2.121l-2.828-2.828zm-2.619 8.276A4.966 4.966 0 0 1 4.756 28H4v-.759a4.967 4.967 0 0 1 1.464-3.535l1.91-1.91l2.829 2.828zM27.415 7.414l-12.261 12.26l-2.829-2.828l12.262-12.26a2.047 2.047 0 0 1 2.828 0a2 2 0 0 1 0 2.828z" fill="currentColor"></path><path d="M6.5 15a3.5 3.5 0 0 1-2.475-5.974l3.5-3.5a1.502 1.502 0 0 0 0-2.121a1.537 1.537 0 0 0-2.121 0L3.415 5.394L2 3.98l1.99-1.988a3.585 3.585 0 0 1 4.95 0a3.504 3.504 0 0 1 0 4.949L5.439 10.44a1.502 1.502 0 0 0 0 2.121a1.537 1.537 0 0 0 2.122 0l4.024-4.024L13 9.95l-4.025 4.024A3.475 3.475 0 0 1 6.5 15z" fill="currentColor"></path></svg>');
e.from_svg('<svg xmlns="http://www.w3.org/2000/svg" width="100%" height="100%" viewBox="0 0 24 24"><path fill="currentColor" d="M2.753 2.933a.75.75 0 0 1 .814-.68l3.043.272c2.157.205 4.224.452 5.922.732c1.66.273 3.073.594 3.844.983c.197.1.412.233.578.415c.176.192.352.506.28.9c-.067.356-.304.59-.487.729a3.001 3.001 0 0 1-.695.369c-1.02.404-2.952.79-5.984 1.169c-1.442.18-2.489.357-3.214.522c.205.045.43.089.674.132c.992.174 2.241.323 3.568.437a31.21 31.21 0 0 1 3.016.398c.46.087.893.186 1.261.296c.352.105.707.236.971.412c.13.086.304.225.42.437a.988.988 0 0 1 .063.141A1.75 1.75 0 0 0 14.5 12.25v.158c-.758.154-1.743.302-2.986.444c-2.124.243-3.409.55-4.117.859c-.296.128-.442.236-.508.3c.026.037.073.094.156.17c.15.138.369.29.65.45c.56.316 1.282.61 1.979.838l2.637.814a.75.75 0 1 1-.443 1.433l-2.655-.819c-.754-.247-1.58-.578-2.257-.96a5.082 5.082 0 0 1-.924-.65c-.255-.233-.513-.544-.62-.935c-.12-.441-.016-.88.274-1.244c.261-.328.656-.574 1.113-.773c.92-.4 2.387-.727 4.545-.974c1.366-.156 2.354-.313 3.041-.462a16.007 16.007 0 0 0-.552-.114a29.716 29.716 0 0 0-2.865-.378c-1.352-.116-2.649-.27-3.7-.454c-.524-.092-1-.194-1.395-.307c-.376-.106-.75-.241-1.021-.426a1.186 1.186 0 0 1-.43-.49a.934.934 0 0 1 .059-.873c.13-.213.32-.352.472-.442a3.23 3.23 0 0 1 .559-.251c.807-.287 2.222-.562 4.37-.83c2.695-.338 4.377-.666 5.295-.962c-.638-.21-1.623-.427-2.89-.635c-1.65-.273-3.679-.515-5.816-.718l-3.038-.272a.75.75 0 0 1-.68-.814M17 12.25a.75.75 0 0 0-1.5 0v4.19l-.72-.72a.75.75 0 1 0-1.06 1.06l2 2a.75.75 0 0 0 1.06 0l2-2a.75.75 0 1 0-1.06-1.06l-.72.72z"></path></svg>');
e.from_svg('<svg xmlns="http://www.w3.org/2000/svg" width="24px" height="24px" viewBox="0 0 24 24"><rect x="2" y="4" width="20" height="18" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" fill="none"></rect><line x1="2" y1="9" x2="22" y2="9" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" fill="none"></line><line x1="7" y1="2" x2="7" y2="6" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" fill="none"></line><line x1="17" y1="2" x2="17" y2="6" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" fill="none"></line></svg>');
e.from_svg('<svg xmlns="http://www.w3.org/2000/svg" width="100%" height="100%" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" class="feather feather-camera"><path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z"></path><circle cx="12" cy="13" r="4"></circle></svg>');
e.from_svg('<svg viewBox="0 0 32 32"><path d="M28.828 3.172a4.094 4.094 0 0 0-5.656 0L4.05 22.292A6.954 6.954 0 0 0 2 27.242V30h2.756a6.952 6.952 0 0 0 4.95-2.05L28.828 8.829a3.999 3.999 0 0 0 0-5.657zM10.91 18.26l2.829 2.829l-2.122 2.121l-2.828-2.828zm-2.619 8.276A4.966 4.966 0 0 1 4.756 28H4v-.759a4.967 4.967 0 0 1 1.464-3.535l1.91-1.91l2.829 2.828zM27.415 7.414l-12.261 12.26l-2.829-2.828l12.262-12.26a2.047 2.047 0 0 1 2.828 0a2 2 0 0 1 0 2.828z" fill="currentColor"></path><path d="M6.5 15a3.5 3.5 0 0 1-2.475-5.974l3.5-3.5a1.502 1.502 0 0 0 0-2.121a1.537 1.537 0 0 0-2.121 0L3.415 5.394L2 3.98l1.99-1.988a3.585 3.585 0 0 1 4.95 0a3.504 3.504 0 0 1 0 4.949L5.439 10.44a1.502 1.502 0 0 0 0 2.121a1.537 1.537 0 0 0 2.122 0l4.024-4.024L13 9.95l-4.025 4.024A3.475 3.475 0 0 1 6.5 15z" fill="currentColor"></path></svg>');
e.from_svg('<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" aria-hidden="true" role="img" class="iconify iconify--carbon" width="100%" height="100%" preserveAspectRatio="xMidYMid meet" viewBox="0 0 32 32"><path fill="currentColor" d="M17.74 30L16 29l4-7h6a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2H6a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h9v2H6a4 4 0 0 1-4-4V8a4 4 0 0 1 4-4h20a4 4 0 0 1 4 4v12a4 4 0 0 1-4 4h-4.84Z"></path><path fill="currentColor" d="M8 10h16v2H8zm0 6h10v2H8z"></path></svg>');
e.from_svg('<svg width="100%" height="100%" stroke-width="1.5" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" color="currentColor"><path d="M5 13L9 17L19 7" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path></svg>');
e.from_svg('<svg xmlns="http://www.w3.org/2000/svg" width="100%" height="100%" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 6L8 10L12 6"></path></svg>');
e.from_svg('<svg xmlns="http://www.w3.org/2000/svg" width="100%" height="100%" viewBox="0 0 24 24" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" class="feather feather-circle"><circle cx="12" cy="12" r="10"></circle></svg>');
var ls = e.from_svg('<svg width="100%" height="100%" viewBox="0 0 24 24" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" xml:space="preserve" stroke="currentColor" style="fill-rule:evenodd;clip-rule:evenodd;stroke-linecap:round;stroke-linejoin:round;"><g transform="matrix(1.14096,-0.140958,-0.140958,1.14096,-0.0559523,0.0559523)"><path d="M18,6L6.087,17.913" style="fill:none;fill-rule:nonzero;stroke-width:2px;"></path></g><path d="M4.364,4.364L19.636,19.636" style="fill:none;fill-rule:nonzero;stroke-width:2px;"></path></svg>');
function pe(V) {
  var l = ls();
  e.append(V, l);
}
e.from_svg('<svg xmlns="http://www.w3.org/2000/svg" width="100%" height="100%" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1" stroke-linecap="round" stroke-linejoin="round" class="feather feather-closed-caption"><rect x="2" y="6" width="20" height="12" rx="2" ry="2"></rect><text x="12" y="15" font-family="sans-serif" font-size="8" font-weight="bold" fill="currentColor" stroke="none" text-anchor="middle">CC</text></svg>');
e.from_svg('<svg width="100%" height="100%" viewBox="0 0 32 32"><path fill="currentColor" d="m31 16l-7 7l-1.41-1.41L28.17 16l-5.58-5.59L24 9l7 7zM1 16l7-7l1.41 1.41L3.83 16l5.58 5.59L8 23l-7-7zm11.42 9.484L17.64 6l1.932.517L14.352 26z"></path></svg>');
e.from_svg('<svg width="100%" height="100%" viewBox="0 0 32 32"><circle cx="10" cy="12" r="2" fill="currentColor"></circle><circle cx="16" cy="9" r="2" fill="currentColor"></circle><circle cx="22" cy="12" r="2" fill="currentColor"></circle><circle cx="23" cy="18" r="2" fill="currentColor"></circle><circle cx="19" cy="23" r="2" fill="currentColor"></circle><path fill="currentColor" d="M16.54 2A14 14 0 0 0 2 16a4.82 4.82 0 0 0 6.09 4.65l1.12-.31a3 3 0 0 1 3.79 2.9V27a3 3 0 0 0 3 3a14 14 0 0 0 14-14.54A14.05 14.05 0 0 0 16.54 2Zm8.11 22.31A11.93 11.93 0 0 1 16 28a1 1 0 0 1-1-1v-3.76a5 5 0 0 0-5-5a5.07 5.07 0 0 0-1.33.18l-1.12.31A2.82 2.82 0 0 1 4 16A12 12 0 0 1 16.47 4A12.18 12.18 0 0 1 28 15.53a11.89 11.89 0 0 1-3.35 8.79Z"></path></svg>');
e.from_svg('<svg xmlns="http://www.w3.org/2000/svg" width="100%" height="100%" viewBox="0 0 24 24"><path fill="currentColor" d="M12 22q-2.05 0-3.875-.788t-3.187-2.15t-2.15-3.187T2 12q0-2.075.813-3.9t2.2-3.175T8.25 2.788T12.2 2q2 0 3.775.688t3.113 1.9t2.125 2.875T22 11.05q0 2.875-1.75 4.413T16 17h-1.85q-.225 0-.312.125t-.088.275q0 .3.375.863t.375 1.287q0 1.25-.687 1.85T12 22m-5.5-9q.65 0 1.075-.425T8 11.5t-.425-1.075T6.5 10t-1.075.425T5 11.5t.425 1.075T6.5 13m3-4q.65 0 1.075-.425T11 7.5t-.425-1.075T9.5 6t-1.075.425T8 7.5t.425 1.075T9.5 9m5 0q.65 0 1.075-.425T16 7.5t-.425-1.075T14.5 6t-1.075.425T13 7.5t.425 1.075T14.5 9m3 4q.65 0 1.075-.425T19 11.5t-.425-1.075T17.5 10t-1.075.425T16 11.5t.425 1.075T17.5 13"></path></svg>');
e.from_svg('<svg id="icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32" width="100%" height="100%"><path d="M23,20a5,5,0,0,0-3.89,1.89L11.8,17.32a4.46,4.46,0,0,0,0-2.64l7.31-4.57A5,5,0,1,0,18,7a4.79,4.79,0,0,0,.2,1.32l-7.31,4.57a5,5,0,1,0,0,6.22l7.31,4.57A4.79,4.79,0,0,0,18,25a5,5,0,1,0,5-5ZM23,4a3,3,0,1,1-3,3A3,3,0,0,1,23,4ZM7,19a3,3,0,1,1,3-3A3,3,0,0,1,7,19Zm16,9a3,3,0,1,1,3-3A3,3,0,0,1,23,28Z" fill="currentColor"></path></svg>');
e.from_svg('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 33 33" color="currentColor" aria-hidden="true" width="100%" height="100%"><path fill="currentColor" d="M28 10v18H10V10h18m0-2H10a2 2 0 0 0-2 2v18a2 2 0 0 0 2 2h18a2 2 0 0 0 2-2V10a2 2 0 0 0-2-2Z"></path><path fill="currentColor" d="M4 18H2V4a2 2 0 0 1 2-2h14v2H4Z"></path></svg>');
e.from_svg('<svg xmlns="http://www.w3.org/2000/svg" width="100%" height="100%" viewBox="0 0 256 256"><path fill="currentColor" d="M240 192a8 8 0 0 1-8 8h-32v32a8 8 0 0 1-16 0v-32H64a8 8 0 0 1-8-8V72H24a8 8 0 0 1 0-16h32V24a8 8 0 0 1 16 0v160h160a8 8 0 0 1 8 8M96 72h88v88a8 8 0 0 0 16 0V64a8 8 0 0 0-8-8H96a8 8 0 0 0 0 16"></path></svg>');
var hs = e.from_svg('<svg xmlns="http://www.w3.org/2000/svg" width="100%" height="100%" viewBox="0 0 32 32"><path fill="currentColor" d="M26 24v4H6v-4H4v4a2 2 0 0 0 2 2h20a2 2 0 0 0 2-2v-4zm0-10l-1.41-1.41L17 20.17V2h-2v18.17l-7.59-7.58L6 14l10 10l10-10z"></path></svg>');
function cs(V) {
  var l = hs();
  e.append(V, l);
}
e.from_svg('<svg class="dropdown-arrow svelte-gtiaeq" xmlns="http://www.w3.org/2000/svg" width="100%" height="100%" viewBox="0 0 18 18"><path d="M5 8l4 4 4-4z"></path></svg>');
e.from_svg('<svg class="dropdown-arrow svelte-wyly4p" xmlns="http://www.w3.org/2000/svg" width="100%" height="100%" viewBox="0 0 18 18"><circle cx="9" cy="9" r="8" class="circle svelte-wyly4p"></circle><path d="M5 8l4 4 4-4z"></path></svg>');
var us = e.from_svg('<svg xmlns="http://www.w3.org/2000/svg" width="100%" height="100%" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" class="feather feather-edit-2"><path d="M17 3a2.828 2.828 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5L17 3z"></path></svg>');
function ds(V) {
  var l = us();
  e.append(V, l);
}
e.from_svg('<svg xmlns="http://www.w3.org/2000/svg" width="100%" height="100%" viewBox="0 0 24 24"><g fill="none"><path fill="currentColor" d="m5.505 11.41l.53.53l-.53-.53ZM3 14.952h-.75H3ZM9.048 21v.75V21ZM11.41 5.505l-.53-.53l.53.53Zm1.831 12.34a.75.75 0 0 0 1.06-1.061l-1.06 1.06ZM7.216 9.697a.75.75 0 1 0-1.06 1.061l1.06-1.06Zm10.749 2.362l-5.905 5.905l1.06 1.06l5.905-5.904l-1.06-1.06Zm-11.93-.12l5.905-5.905l-1.06-1.06l-5.905 5.904l1.06 1.06Zm0 6.025c-.85-.85-1.433-1.436-1.812-1.933c-.367-.481-.473-.79-.473-1.08h-1.5c0 .749.312 1.375.78 1.99c.455.596 1.125 1.263 1.945 2.083l1.06-1.06Zm-1.06-7.086c-.82.82-1.49 1.488-1.945 2.084c-.468.614-.78 1.24-.78 1.99h1.5c0-.29.106-.6.473-1.08c.38-.498.962-1.083 1.812-1.933l-1.06-1.06Zm7.085 7.086c-.85.85-1.435 1.433-1.933 1.813c-.48.366-.79.472-1.08.472v1.5c.75 0 1.376-.312 1.99-.78c.596-.455 1.264-1.125 2.084-1.945l-1.06-1.06Zm-7.085 1.06c.82.82 1.487 1.49 2.084 1.945c.614.468 1.24.78 1.989.78v-1.5c-.29 0-.599-.106-1.08-.473c-.497-.38-1.083-.962-1.933-1.812l-1.06 1.06Zm12.99-12.99c.85.85 1.433 1.436 1.813 1.933c.366.481.472.79.472 1.08h1.5c0-.749-.312-1.375-.78-1.99c-.455-.596-1.125-1.263-1.945-2.083l-1.06 1.06Zm1.06 7.086c.82-.82 1.49-1.488 1.945-2.084c.468-.614.78-1.24.78-1.99h-1.5c0 .29-.106.6-.473 1.08c-.38.498-.962 1.083-1.812 1.933l1.06 1.06Zm0-8.146c-.82-.82-1.487-1.49-2.084-1.945c-.614-.468-1.24-.78-1.989-.78v1.5c.29 0 .599.106 1.08.473c.497.38 1.083.962 1.933 1.812l1.06-1.06Zm-7.085 1.06c.85-.85 1.435-1.433 1.933-1.812c.48-.367.79-.473 1.08-.473v-1.5c-.75 0-1.376.312-1.99.78c-.596.455-1.264 1.125-2.084 1.945l1.06 1.06Zm2.362 10.749L7.216 9.698l-1.06 1.061l7.085 7.085l1.06-1.06Z"></path><path stroke="currentColor" stroke-linecap="round" stroke-width="1.5" d="M9 21h12"></path></g></svg>');
e.from_svg('<svg fill="none" stroke="currentColor" viewBox="0 0 24 24" width="100%" height="100%" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path stroke-linecap="round" stroke-linejoin="round" d="M12 9v3.75m9-.75a9 9 0 11-18 0 9 9 0 0118 0zm-9 3.75h.008v.008H12v-.008z"></path></svg>');
e.from_svg('<svg xmlns="http://www.w3.org/2000/svg" width="100%" height="100%" viewBox="0 0 24 24"><path fill="currentColor" d="M21.03 2.97a3.578 3.578 0 0 0-5.06 0L14 4.94l-.013-.013a1.75 1.75 0 0 0-2.475 0l-.585.586a1.75 1.75 0 0 0 0 2.475l.012.012l-6.78 6.78a2.25 2.25 0 0 0-.659 1.592v.687l-1.28 2.347c-.836 1.533.841 3.21 2.374 2.375l2.347-1.28h.688a2.25 2.25 0 0 0 1.59-.66L16 13.061l.012.012a1.75 1.75 0 0 0 2.475 0l.586-.585a1.75 1.75 0 0 0 0-2.475L19.061 10l1.97-1.97a3.578 3.578 0 0 0 0-5.06ZM12 9.061l2.94 2.94l-6.78 6.78a.75.75 0 0 1-.531.22H6.75a.75.75 0 0 0-.359.09l-2.515 1.373a.234.234 0 0 1-.159.032a.264.264 0 0 1-.138-.075a.264.264 0 0 1-.075-.138a.234.234 0 0 1 .033-.158l1.372-2.515A.75.75 0 0 0 5 17.25v-.878a.75.75 0 0 1 .22-.53L12 9.06Z"></path></svg>');
e.from_svg('<svg xmlns="http://www.w3.org/2000/svg" width="24px" height="24px" fill="currentColor" stroke-width="1.5" viewBox="0 0 24 24" color="currentColor"><path stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" d="M2.956 5.704A.6.6 0 0 0 2 6.187v11.626a.6.6 0 0 0 .956.483l7.889-5.813a.6.6 0 0 0 0-.966l-7.89-5.813ZM13.956 5.704a.6.6 0 0 0-.956.483v11.626a.6.6 0 0 0 .956.483l7.889-5.813a.6.6 0 0 0 0-.966l-7.89-5.813Z"></path></svg>');
var fs = e.from_svg('<svg xmlns="http://www.w3.org/2000/svg" width="100%" height="100%" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" class="feather feather-file"><path d="M13 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V9z"></path><polyline points="13 2 13 9 20 9"></polyline></svg>');
function ke(V) {
  var l = fs();
  e.append(V, l);
}
e.from_svg('<svg fill="none" stroke="currentColor" viewBox="0 0 24 24" width="100%" height="100%" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path stroke-linecap="round" stroke-linejoin="round" d="M11.25 11.25l.041-.02a.75.75 0 011.063.852l-.708 2.836a.75.75 0 001.063.853l.041-.021M21 12a9 9 0 11-18 0 9 9 0 0118 0zm-9-3.75h.008v.008H12V8.25z"></path></svg>');
e.from_svg('<svg fill="none" stroke="currentColor" viewBox="0 0 24 24" width="100%" height="100%" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path stroke-linecap="round" stroke-linejoin="round" d="M9 12.75L11.25 15 15 9.75M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>');
e.from_svg('<svg xmlns="http://www.w3.org/2000/svg" width="100%" height="100%" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" class="feather feather-image"><rect x="3" y="3" width="18" height="18" rx="2" ry="2"></rect><circle cx="8.5" cy="8.5" r="1.5"></circle><polyline points="21 15 16 10 5 21"></polyline></svg>');
e.from_svg('<svg xmlns="http://www.w3.org/2000/svg" width="100%" height="100%" viewBox="0 0 256 256"><path fill="currentColor" d="M200 32h-36.26a47.92 47.92 0 0 0-71.48 0H56a16 16 0 0 0-16 16v168a16 16 0 0 0 16 16h144a16 16 0 0 0 16-16V48a16 16 0 0 0-16-16m-72 0a32 32 0 0 1 32 32H96a32 32 0 0 1 32-32m72 184H56V48h26.75A47.9 47.9 0 0 0 80 64v8a8 8 0 0 0 8 8h80a8 8 0 0 0 8-8v-8a47.9 47.9 0 0 0-2.75-16H200Z"></path></svg>');
e.from_svg('<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" aria-hidden="true" role="img" class="iconify iconify--mdi" width="100%" height="100%" preserveAspectRatio="xMidYMid meet" viewBox="0 0 24 24"><path fill="currentColor" d="M5 3h2v2H5v5a2 2 0 0 1-2 2a2 2 0 0 1 2 2v5h2v2H5c-1.07-.27-2-.9-2-2v-4a2 2 0 0 0-2-2H0v-2h1a2 2 0 0 0 2-2V5a2 2 0 0 1 2-2m14 0a2 2 0 0 1 2 2v4a2 2 0 0 0 2 2h1v2h-1a2 2 0 0 0-2 2v4a2 2 0 0 1-2 2h-2v-2h2v-5a2 2 0 0 1 2-2a2 2 0 0 1-2-2V5h-2V3h2m-7 12a1 1 0 0 1 1 1a1 1 0 0 1-1 1a1 1 0 0 1-1-1a1 1 0 0 1 1-1m-4 0a1 1 0 0 1 1 1a1 1 0 0 1-1 1a1 1 0 0 1-1-1a1 1 0 0 1 1-1m8 0a1 1 0 0 1 1 1a1 1 0 0 1-1 1a1 1 0 0 1-1-1a1 1 0 0 1 1-1Z"></path></svg>');
e.from_svg('<svg width="100%" height="100%" viewBox="0 0 17 17" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M1.35327 10.9495L6.77663 15.158C7.12221 15.4229 7.50051 15.5553 7.91154 15.5553C8.32258 15.5553 8.70126 15.4229 9.0476 15.158L14.471 10.9495" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"></path><path d="M7.23461 11.4324C7.23406 11.432 7.2335 11.4316 7.23295 11.4312L1.81496 7.2268C1.81471 7.22661 1.81446 7.22641 1.8142 7.22621C1.52269 6.99826 1.39429 6.73321 1.39429 6.37014C1.39429 6.00782 1.52236 5.74301 1.81325 5.51507C1.8136 5.5148 1.81394 5.51453 1.81428 5.51426L7.2331 1.30812C7.45645 1.13785 7.67632 1.06653 7.91159 1.06653C8.14692 1.06653 8.36622 1.13787 8.58861 1.30787C8.58915 1.30828 8.58969 1.30869 8.59023 1.30911L14.0082 5.51462C14.0085 5.51485 14.0088 5.51507 14.0091 5.51529C14.3008 5.74345 14.4289 6.00823 14.4289 6.37014C14.4289 6.73356 14.3006 6.99862 14.01 7.22634C14.0096 7.22662 14.0093 7.22689 14.0089 7.22717L8.59007 11.4322C8.36672 11.6024 8.14686 11.6738 7.91159 11.6738C7.67628 11.6738 7.45699 11.6024 7.23461 11.4324Z" stroke="currentColor" stroke-width="1.5"></path></svg>');
e.from_svg('<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" aria-hidden="true" role="img" class="iconify iconify--carbon" width="100%" height="100%" preserveAspectRatio="xMidYMid meet" viewBox="0 0 32 32"><path fill="currentColor" d="M4 2H2v26a2 2 0 0 0 2 2h26v-2H4v-3h22v-8H4v-4h14V5H4Zm20 17v4H4v-4ZM16 7v4H4V7Z"></path></svg>');
e.from_svg('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-maximize" width="100%" height="100%"><path d="M8 3H5a2 2 0 0 0-2 2v3m18 0V5a2 2 0 0 0-2-2h-3m0 18h3a2 2 0 0 0 2-2v-3M3 16v3a2 2 0 0 0 2 2h3"></path></svg>');
e.from_svg('<svg xmlns="http://www.w3.org/2000/svg" width="100%" height="100%" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-mic"><path d="M12 1a3 3 0 0 0-3 3v8a3 3 0 0 0 6 0V4a3 3 0 0 0-3-3z"></path><path d="M19 10v2a7 7 0 0 1-14 0v-2"></path><line x1="12" y1="19" x2="12" y2="23"></line><line x1="8" y1="23" x2="16" y2="23"></line></svg>');
e.from_svg('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-minimize" width="100%" height="100%"><path d="M8 3v3a2 2 0 0 1-2 2H3m18 0h-3a2 2 0 0 1-2-2V3m0 18v-3a2 2 0 0 1 2-2h3M3 16h3a2 2 0 0 1 2 2v3"></path></svg>');
e.from_svg('<svg xmlns="http://www.w3.org/2000/svg" width="100%" height="100%" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" class="feather feather-music"><path d="M9 18V5l12-2v13"></path><circle cx="6" cy="18" r="3"></circle><circle cx="18" cy="16" r="3"></circle></svg>');
e.from_svg('<svg xmlns="http://www.w3.org/2000/svg" width="100%" height="100%" viewBox="0 0 24 24"><g fill="none" stroke="currentColor" stroke-width="1.5"><path d="M2 12.026c0 5.146 3.867 9.387 8.847 9.96c.735.085 1.447-.228 1.97-.753a1.68 1.68 0 0 0 0-2.372c-.523-.525-.95-1.307-.555-1.934c1.576-2.508 9.738 3.251 9.738-4.9C22 6.488 17.523 2 12 2S2 6.489 2 12.026Z"></path><circle cx="17.5" cy="11.5" r=".75"></circle><circle cx="6.5" cy="11.5" r=".75"></circle><path d="M10.335 7a.75.75 0 1 1-1.5 0a.75.75 0 0 1 1.5 0Zm4.915 0a.75.75 0 1 1-1.5 0a.75.75 0 0 1 1.5 0Z"></path></g></svg>');
e.from_svg('<svg xmlns="http://www.w3.org/2000/svg" width="100%" height="100%" viewBox="0 0 24 24"><path fill="currentColor" d="M10.05 23q-.75 0-1.4-.337T7.575 21.7l-5.9-8.65q-.2-.3-.175-.65t.3-.6q.475-.475 1.125-.55t1.175.3L7 13.575V4q0-.425.288-.712T8 3t.713.288T9 4v11.5q0 .6-.537.888t-1.038-.063l-2.125-1.5l3.925 5.725q.125.2.35.325t.475.125H17q.825 0 1.413-.587T19 19V5q0-.425.288-.712T20 4t.713.288T21 5v14q0 1.65-1.175 2.825T17 23zM12 1q.425 0 .713.288T13 2v9q0 .425-.288.713T12 12t-.712-.288T11 11V2q0-.425.288-.712T12 1m4 1q.425 0 .713.288T17 3v8q0 .425-.288.713T16 12t-.712-.288T15 11V3q0-.425.288-.712T16 2m-3.85 14.5"></path></svg>');
e.from_svg('<svg fill="currentColor" width="100%" height="100%" viewBox="0 0 1920 1920" xmlns="http://www.w3.org/2000/svg"><g id="SVGRepo_bgCarrier" stroke-width="0"></g><g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round"></g><g id="SVGRepo_iconCarrier"><path d="M1752.768 221.109C1532.646.986 1174.283.986 954.161 221.109l-838.588 838.588c-154.052 154.165-154.052 404.894 0 558.946 149.534 149.421 409.976 149.308 559.059 0l758.738-758.626c87.982-88.094 87.982-231.417 0-319.51-88.32-88.208-231.642-87.982-319.51 0l-638.796 638.908 79.85 79.849 638.795-638.908c43.934-43.821 115.539-43.934 159.812 0 43.934 44.047 43.934 115.877 0 159.812l-758.739 758.625c-110.23 110.118-289.355 110.005-399.36 0-110.118-110.117-110.005-289.242 0-399.247l838.588-838.588c175.963-175.962 462.382-176.188 638.909 0 176.075 176.188 176.075 462.833 0 638.908l-798.607 798.72 79.849 79.85 798.607-798.72c220.01-220.123 220.01-578.485 0-798.607" fill-rule="evenodd"></path></g></svg>');
e.from_svg('<svg xmlns="http://www.w3.org/2000/svg" width="100%" height="100%" viewBox="0 0 24 24" fill="currentColor" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><rect x="6" y="4" width="4" height="16"></rect><rect x="14" y="4" width="4" height="16"></rect></svg>');
e.from_svg('<svg xmlns="http://www.w3.org/2000/svg" width="100%" height="100%" viewBox="0 0 24 24" fill="currentColor" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><polygon points="5 3 19 12 5 21 5 3"></polygon></svg>');
e.from_svg('<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" aria-hidden="true" role="img" class="iconify iconify--carbon" width="100%" height="100%" preserveAspectRatio="xMidYMid meet" viewBox="0 0 32 32"><circle cx="20" cy="4" r="2" fill="currentColor"></circle><circle cx="8" cy="16" r="2" fill="currentColor"></circle><circle cx="28" cy="12" r="2" fill="currentColor"></circle><circle cx="11" cy="7" r="2" fill="currentColor"></circle><circle cx="16" cy="24" r="2" fill="currentColor"></circle><path fill="currentColor" d="M30 3.413L28.586 2L4 26.585V2H2v26a2 2 0 0 0 2 2h26v-2H5.413Z"></path></svg>');
e.from_svg('<svg width="100%" height="100%" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M6 12H12M18 12H12M12 12V6M12 12V18" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path></svg>');
e.from_svg('<svg xmlns="http://www.w3.org/2000/svg" width="100%" height="100%" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-rotate-ccw" style="transform: rotateY(180deg);"><polyline points="1 4 1 10 7 10"></polyline><path d="M3.51 15a9 9 0 1 0 2.13-9.36L1 10"></path></svg>');
e.from_svg('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="100%" height="100%"><path d="M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z"></path></svg>');
e.from_svg('<svg xmlns="http://www.w3.org/2000/svg" width="100%" height="100%" viewBox="0 0 1024 1024"><path fill="currentColor" d="M672 418H144c-17.7 0-32 14.3-32 32v414c0 17.7 14.3 32 32 32h528c17.7 0 32-14.3 32-32V450c0-17.7-14.3-32-32-32zm-44 402H188V494h440v326z"></path><path fill="currentColor" d="M819.3 328.5c-78.8-100.7-196-153.6-314.6-154.2l-.2-64c0-6.5-7.6-10.1-12.6-6.1l-128 101c-4 3.1-3.9 9.1 0 12.3L492 318.6c5.1 4 12.7.4 12.6-6.1v-63.9c12.9.1 25.9.9 38.8 2.5c42.1 5.2 82.1 18.2 119 38.7c38.1 21.2 71.2 49.7 98.4 84.3c27.1 34.7 46.7 73.7 58.1 115.8c11 40.7 14 82.7 8.9 124.8c-.7 5.4-1.4 10.8-2.4 16.1h74.9c14.8-103.6-11.3-213-81-302.3z"></path></svg>');
e.from_svg('<svg viewBox="0 0 22 24" width="100%" height="100%" fill="none" xmlns="http://www.w3.org/2000/svg"><g id="SVGRepo_bgCarrier" stroke-width="0"></g><g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round"></g><g id="SVGRepo_iconCarrier"><path d="M19.1168 12.1484C19.474 12.3581 19.9336 12.2384 20.1432 11.8811C20.3528 11.5238 20.2331 11.0643 19.8758 10.8547L19.1168 12.1484ZM6.94331 4.13656L6.55624 4.77902L6.56378 4.78344L6.94331 4.13656ZM5.92408 4.1598L5.50816 3.5357L5.50816 3.5357L5.92408 4.1598ZM5.51031 5.09156L4.76841 5.20151C4.77575 5.25101 4.78802 5.29965 4.80505 5.34671L5.51031 5.09156ZM7.12405 11.7567C7.26496 12.1462 7.69495 12.3477 8.08446 12.2068C8.47397 12.0659 8.67549 11.6359 8.53458 11.2464L7.12405 11.7567ZM19.8758 12.1484C20.2331 11.9388 20.3528 11.4793 20.1432 11.122C19.9336 10.7648 19.474 10.6451 19.1168 10.8547L19.8758 12.1484ZM6.94331 18.8666L6.56375 18.2196L6.55627 18.2241L6.94331 18.8666ZM5.92408 18.8433L5.50815 19.4674H5.50815L5.92408 18.8433ZM5.51031 17.9116L4.80505 17.6564C4.78802 17.7035 4.77575 17.7521 4.76841 17.8016L5.51031 17.9116ZM8.53458 11.7567C8.67549 11.3672 8.47397 10.9372 8.08446 10.7963C7.69495 10.6554 7.26496 10.8569 7.12405 11.2464L8.53458 11.7567ZM19.4963 12.2516C19.9105 12.2516 20.2463 11.9158 20.2463 11.5016C20.2463 11.0873 19.9105 10.7516 19.4963 10.7516V12.2516ZM7.82931 10.7516C7.4151 10.7516 7.07931 11.0873 7.07931 11.5016C7.07931 11.9158 7.4151 12.2516 7.82931 12.2516V10.7516ZM19.8758 10.8547L7.32284 3.48968L6.56378 4.78344L19.1168 12.1484L19.8758 10.8547ZM7.33035 3.49414C6.76609 3.15419 6.05633 3.17038 5.50816 3.5357L6.34 4.78391C6.40506 4.74055 6.4893 4.73863 6.55627 4.77898L7.33035 3.49414ZM5.50816 3.5357C4.95998 3.90102 4.67184 4.54987 4.76841 5.20151L6.25221 4.98161C6.24075 4.90427 6.27494 4.82727 6.34 4.78391L5.50816 3.5357ZM4.80505 5.34671L7.12405 11.7567L8.53458 11.2464L6.21558 4.83641L4.80505 5.34671ZM19.1168 10.8547L6.56378 18.2197L7.32284 19.5134L19.8758 12.1484L19.1168 10.8547ZM6.55627 18.2241C6.4893 18.2645 6.40506 18.2626 6.34 18.2192L5.50815 19.4674C6.05633 19.8327 6.76609 19.8489 7.33035 19.509L6.55627 18.2241ZM6.34 18.2192C6.27494 18.1759 6.24075 18.0988 6.25221 18.0215L4.76841 17.8016C4.67184 18.4532 4.95998 19.1021 5.50815 19.4674L6.34 18.2192ZM6.21558 18.1667L8.53458 11.7567L7.12405 11.2464L4.80505 17.6564L6.21558 18.1667ZM19.4963 10.7516H7.82931V12.2516H19.4963V10.7516Z" fill="currentColor"></path></g></svg>');
e.from_svg('<svg enable-background="new 0 0 32 32" height="20" width="20" viewBox="0 0 32 32" fill="currentColor" xmlns="http://www.w3.org/2000/svg"><path d="m30 8h-4.1c-.5-2.3-2.5-4-4.9-4s-4.4 1.7-4.9 4h-14.1v2h14.1c.5 2.3 2.5 4 4.9 4s4.4-1.7 4.9-4h4.1zm-9 4c-1.7 0-3-1.3-3-3s1.3-3 3-3 3 1.3 3 3-1.3 3-3 3z"></path><path d="m2 24h4.1c.5 2.3 2.5 4 4.9 4s4.4-1.7 4.9-4h14.1v-2h-14.1c-.5-2.3-2.5-4-4.9-4s-4.4 1.7-4.9 4h-4.1zm9-4c1.7 0 3 1.3 3 3s-1.3 3-3 3-3-1.3-3-3 1.3-3 3-3z"></path><path d="m0 0h32v32h-32z" fill="none"></path></svg>');
e.from_svg('<svg xmlns="http://www.w3.org/2000/svg" width="100%" height="100%" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" class="feather feather-edit-2"><path d="M17 3a2.828 2.828 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5L17 3z"></path></svg>');
e.from_svg('<svg xmlns="http://www.w3.org/2000/svg" width="100%" height="100%" viewBox="0 0 24 24" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" class="feather feather-square"><rect x="3" y="3" width="18" height="18" rx="2" ry="2"></rect></svg>');
e.from_svg('<svg xmlns="http://www.w3.org/2000/svg" width="100%" height="100%" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" class="feather feather-table"><path d="M9 3H5a2 2 0 0 0-2 2v4m6-6h10a2 2 0 0 1 2 2v4M9 3v18m0 0h10a2 2 0 0 0 2-2V9M9 21H5a2 2 0 0 1-2-2V9m0 0h18"></path></svg>');
e.from_svg('<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" aria-hidden="true" role="img" class="iconify iconify--carbon" width="100%" height="100%" preserveAspectRatio="xMidYMid meet" viewBox="0 0 32 32"><path fill="currentColor" d="M12 15H5a3 3 0 0 1-3-3v-2a3 3 0 0 1 3-3h5V5a1 1 0 0 0-1-1H3V2h6a3 3 0 0 1 3 3zM5 9a1 1 0 0 0-1 1v2a1 1 0 0 0 1 1h5V9zm15 14v2a1 1 0 0 0 1 1h5v-4h-5a1 1 0 0 0-1 1z"></path><path fill="currentColor" d="M2 30h28V2Zm26-2h-7a3 3 0 0 1-3-3v-2a3 3 0 0 1 3-3h5v-2a1 1 0 0 0-1-1h-6v-2h6a3 3 0 0 1 3 3Z"></path></svg>');
e.from_svg(`<svg id="icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32" fill="currentColor" width="100%" height="100%"><defs><style>.cls-1 {
				fill: none;
			}</style></defs><rect x="12" y="12" width="2" height="12"></rect><rect x="18" y="12" width="2" height="12"></rect><path d="M4,6V8H6V28a2,2,0,0,0,2,2H24a2,2,0,0,0,2-2V8h2V6ZM8,28V8H24V28Z"></path><rect x="12" y="2" width="8" height="2"></rect><rect id="_Transparent_Rectangle_" data-name="&lt;Transparent Rectangle>" class="cls-1" width="32" height="32"></rect></svg>`);
e.from_svg('<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" aria-hidden="true" role="img" class="iconify iconify--carbon" width="100%" height="100%" preserveAspectRatio="xMidYMid meet" viewBox="0 0 32 32"><path fill="currentColor" d="M23 9.005h6a2 2 0 0 0 2-2v-4a2 2 0 0 0-2-2h-6a2 2 0 0 0-2 2v1H11v-1a2 2 0 0 0-2-2H3a2 2 0 0 0-2 2v4a2 2 0 0 0 2 2h6a2 2 0 0 0 2-2v-1h4v20a2.002 2.002 0 0 0 2 2h4v1a2 2 0 0 0 2 2h6a2 2 0 0 0 2-2v-4a2 2 0 0 0-2-2h-6a2 2 0 0 0-2 2v1h-4v-9h4v1a2 2 0 0 0 2 2h6a2 2 0 0 0 2-2v-4a2 2 0 0 0-2-2h-6a2 2 0 0 0-2 2v1h-4v-9h4v1a2 2 0 0 0 2 2Zm0-6h6v4h-6Zm-14 4H3v-4h6Zm14 18h6v4h-6Zm0-11h6v4h-6Z"></path></svg>');
e.from_svg('<svg xmlns="http://www.w3.org/2000/svg" width="100%" height="100%" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-scissors"><circle cx="6" cy="6" r="3"></circle><circle cx="6" cy="18" r="3"></circle><line x1="20" y1="4" x2="8.12" y2="15.88"></line><line x1="14.47" y1="14.48" x2="20" y2="20"></line><line x1="8.12" y1="8.12" x2="12" y2="12"></line></svg>');
var ps = e.from_svg('<svg aria-label="undo" xmlns="http://www.w3.org/2000/svg" width="100%" height="100%" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" class="feather feather-rotate-ccw"><polyline points="1 4 1 10 7 10"></polyline><path d="M3.51 15a9 9 0 1 0 2.13-9.36L1 10"></path></svg>');
function gs(V) {
  var l = ps();
  e.append(V, l);
}
var ms = e.from_svg('<svg xmlns="http://www.w3.org/2000/svg" width="90%" height="90%" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-upload"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path><polyline points="17 8 12 3 7 8"></polyline><line x1="12" y1="3" x2="12" y2="15"></line></svg>');
function vs(V) {
  var l = ms();
  e.append(V, l);
}
e.from_svg('<svg xmlns="http://www.w3.org/2000/svg" width="100%" height="100%" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" class="feather feather-video"><polygon points="23 7 16 12 23 17 23 7"></polygon><rect x="1" y="5" width="15" height="14" rx="2" ry="2"></rect></svg>');
e.from_svg('<svg xmlns="http://www.w3.org/2000/svg" width="100%" height="100%" viewBox="0 0 24 24"><path fill="currentColor" d="M12 16q1.875 0 3.188-1.312T16.5 11.5t-1.312-3.187T12 7T8.813 8.313T7.5 11.5t1.313 3.188T12 16m0-1.8q-1.125 0-1.912-.788T9.3 11.5t.788-1.912T12 8.8t1.913.788t.787 1.912t-.787 1.913T12 14.2m0 4.8q-3.65 0-6.65-2.037T1 11.5q1.35-3.425 4.35-5.462T12 4t6.65 2.038T23 11.5q-1.35 3.425-4.35 5.463T12 19"></path></svg>');
e.from_svg('<svg xmlns="http://www.w3.org/2000/svg" width="100%" height="100%" viewBox="0 0 24 24"><path fill="currentColor" d="m19.8 22.6l-4.2-4.15q-.875.275-1.762.413T12 19q-3.775 0-6.725-2.087T1 11.5q.525-1.325 1.325-2.463T4.15 7L1.4 4.2l1.4-1.4l18.4 18.4zM12 16q.275 0 .513-.025t.512-.1l-5.4-5.4q-.075.275-.1.513T7.5 11.5q0 1.875 1.313 3.188T12 16m7.3.45l-3.175-3.15q.175-.425.275-.862t.1-.938q0-1.875-1.312-3.187T12 7q-.5 0-.937.1t-.863.3L7.65 4.85q1.025-.425 2.1-.637T12 4q3.775 0 6.725 2.088T23 11.5q-.575 1.475-1.513 2.738T19.3 16.45m-4.625-4.6l-3-3q.7-.125 1.288.113t1.012.687t.613 1.038t.087 1.162"></path></svg>');
e.from_svg('<svg width="100%" height="100%" viewBox="0 0 24 24" stroke-width="1.5" fill="none" xmlns="http://www.w3.org/2000/svg" stroke="currentColor" color="currentColor"><title>Low volume</title><path d="M19.5 7.5C19.5 7.5 21 9 21 11.5C21 14 19.5 15.5 19.5 15.5" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path><path d="M2 13.8571V10.1429C2 9.03829 2.89543 8.14286 4 8.14286H6.9C7.09569 8.14286 7.28708 8.08544 7.45046 7.97772L13.4495 4.02228C14.1144 3.5839 15 4.06075 15 4.85714V19.1429C15 19.9392 14.1144 20.4161 13.4495 19.9777L7.45046 16.0223C7.28708 15.9146 7.09569 15.8571 6.9 15.8571H4C2.89543 15.8571 2 14.9617 2 13.8571Z" stroke-width="1.5"></path></svg>');
e.from_svg('<svg width="100%" height="100%" viewBox="0 0 24 24" stroke-width="1.5" fill="none" stroke="currentColor" xmlns="http://www.w3.org/2000/svg" color="currentColor"><title>High volume</title><path d="M1 13.8571V10.1429C1 9.03829 1.89543 8.14286 3 8.14286H5.9C6.09569 8.14286 6.28708 8.08544 6.45046 7.97772L12.4495 4.02228C13.1144 3.5839 14 4.06075 14 4.85714V19.1429C14 19.9392 13.1144 20.4161 12.4495 19.9777L6.45046 16.0223C6.28708 15.9146 6.09569 15.8571 5.9 15.8571H3C1.89543 15.8571 1 14.9617 1 13.8571Z" stroke-width="1.5"></path><path d="M17.5 7.5C17.5 7.5 19 9 19 11.5C19 14 17.5 15.5 17.5 15.5" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path><path d="M20.5 4.5C20.5 4.5 23 7 23 11.5C23 16 20.5 18.5 20.5 18.5" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path></svg>');
e.from_svg('<svg width="100%" height="100%" viewBox="0 0 24 24" stroke-width="1.5" fill="none" xmlns="http://www.w3.org/2000/svg" stroke="currentColor" color="currentColor"><title>Muted volume</title><g clip-path="url(#clip0_3173_16686)"><path d="M18 14L20.0005 12M22 10L20.0005 12M20.0005 12L18 10M20.0005 12L22 14" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path><path d="M2 13.8571V10.1429C2 9.03829 2.89543 8.14286 4 8.14286H6.9C7.09569 8.14286 7.28708 8.08544 7.45046 7.97772L13.4495 4.02228C14.1144 3.5839 15 4.06075 15 4.85714V19.1429C15 19.9392 14.1144 20.4161 13.4495 19.9777L7.45046 16.0223C7.28708 15.9146 7.09569 15.8571 6.9 15.8571H4C2.89543 15.8571 2 14.9617 2 13.8571Z" stroke-width="1.5"></path></g><defs><clipPath id="clip0_3173_16686"><rect width="24" height="24" fill="white"></rect></clipPath></defs></svg>');
e.from_svg('<svg fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24" width="100%" height="100%" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" stroke-linecap="round" stroke-linejoin="round"><path stroke-linecap="round" stroke-linejoin="round" d="M12 9v3.75m-9.303 3.376c-.866 1.5.217 3.374 1.948 3.374h14.71c1.73 0 2.813-1.874 1.948-3.374L13.949 3.378c-.866-1.5-3.032-1.5-3.898 0L2.697 16.126zM12 15.75h.007v.008H12v-.008z"></path></svg>');
e.from_svg('<svg xmlns="http://www.w3.org/2000/svg" width="100%" height="100%" viewBox="0 0 24 24"><path fill="currentColor" d="M12 2c-4.963 0-9 4.038-9 9c0 3.328 1.82 6.232 4.513 7.79l-2.067 1.378A1 1 0 0 0 6 22h12a1 1 0 0 0 .555-1.832l-2.067-1.378C19.18 17.232 21 14.328 21 11c0-4.962-4.037-9-9-9zm0 16c-3.859 0-7-3.141-7-7c0-3.86 3.141-7 7-7s7 3.14 7 7c0 3.859-3.141 7-7 7z"></path><path fill="currentColor" d="M12 6c-2.757 0-5 2.243-5 5s2.243 5 5 5s5-2.243 5-5s-2.243-5-5-5zm0 8c-1.654 0-3-1.346-3-3s1.346-3 3-3s3 1.346 3 3s-1.346 3-3 3z"></path></svg>');
e.from_svg('<svg xmlns="http://www.w3.org/2000/svg" width="100%" height="100%" viewBox="0 0 50 50" class="svelte-3g80w1"><circle cx="25" cy="25" r="20" fill="none" stroke-width="3.0" stroke-linecap="round" stroke-dasharray="94.2477796076938 94.2477796076938" stroke-dashoffset="0" class="svelte-3g80w1"><animateTransform attributeName="transform" type="rotate" from="0 25 25" to="360 25 25" repeatCount="indefinite" class="svelte-3g80w1"></animateTransform></circle></svg>');
e.from_svg('<svg xmlns="http://www.w3.org/2000/svg" width="100%" height="100%" viewBox="0 0 256 256"><path fill="currentColor" d="M144 120v88a8 8 0 0 1-8 8H48a8 8 0 0 1-8-8v-88a8 8 0 0 1 8-8h88a8 8 0 0 1 8 8m64 56a8 8 0 0 0-8 8v16h-24a8 8 0 0 0 0 16h24a16 16 0 0 0 16-16v-16a8 8 0 0 0-8-8m0-72a8 8 0 0 0-8 8v32a8 8 0 0 0 16 0v-32a8 8 0 0 0-8-8m-8-64h-16a8 8 0 0 0 0 16h16v16a8 8 0 0 0 16 0V56a16 16 0 0 0-16-16m-56 0h-32a8 8 0 0 0 0 16h32a8 8 0 0 0 0-16M48 88a8 8 0 0 0 8-8V56h16a8 8 0 0 0 0-16H56a16 16 0 0 0-16 16v24a8 8 0 0 0 8 8"></path></svg>');
e.from_svg('<svg width="100%" height="100%" stroke-width="1.5" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" color="currentColor"><path d="M19.1679 9C18.0247 6.46819 15.3006 4.5 11.9999 4.5C8.31459 4.5 5.05104 7.44668 4.54932 11" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path><path d="M16 9H19.4C19.7314 9 20 8.73137 20 8.4V5" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path><path d="M4.88146 15C5.92458 17.5318 8.64874 19.5 12.0494 19.5C15.7347 19.5 18.9983 16.5533 19.5 13" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path><path d="M8.04932 15H4.64932C4.31795 15 4.04932 15.2686 4.04932 15.6V19" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path></svg>');
e.from_svg('<svg width="100%" height="100%" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M12 20L12 4M12 20L7 15M12 20L17 15" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path></svg>');
e.from_svg('<svg xmlns="http://www.w3.org/2000/svg" width="100%" height="100%" viewBox="0 0 24 24"><path fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="m21 21l-4.343-4.343m0 0A8 8 0 1 0 5.343 5.343a8 8 0 0 0 11.314 11.314M11 8v6m-3-3h6"></path></svg>');
e.from_svg('<svg xmlns="http://www.w3.org/2000/svg" width="100%" height="100%" viewBox="0 0 24 24"><path fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="m21 21l-4.343-4.343m0 0A8 8 0 1 0 5.343 5.343a8 8 0 0 0 11.314 11.314M8 11h6"></path></svg>');
e.from_svg('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32"><path fill="currentColor" d="M12.1 2a9.8 9.8 0 0 0-5.4 1.6l6.4 6.4a2.1 2.1 0 0 1 .2 3a2.1 2.1 0 0 1-3-.2L3.7 6.4A9.84 9.84 0 0 0 2 12.1a10.14 10.14 0 0 0 10.1 10.1a11 11 0 0 0 2.6-.3l6.7 6.7a5 5 0 0 0 7.1-7.1l-6.7-6.7a11 11 0 0 0 .3-2.6A10 10 0 0 0 12.1 2m8 10.1a7.6 7.6 0 0 1-.3 2.1l-.3 1.1l.8.8l6.7 6.7a2.88 2.88 0 0 1 .9 2.1A2.72 2.72 0 0 1 27 27a2.9 2.9 0 0 1-4.2 0l-6.7-6.7l-.8-.8l-1.1.3a7.6 7.6 0 0 1-2.1.3a8.27 8.27 0 0 1-5.7-2.3A7.63 7.63 0 0 1 4 12.1a8.3 8.3 0 0 1 .3-2.2l4.4 4.4a4.14 4.14 0 0 0 5.9.2a4.14 4.14 0 0 0-.2-5.9L10 4.2a6.5 6.5 0 0 1 2-.3a8.27 8.27 0 0 1 5.7 2.3a8.5 8.5 0 0 1 2.4 5.9"></path></svg>');
e.from_svg('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32"><path fill="currentColor" d="M17.74 30L16 29l4-7h6a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2H6a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h9v2H6a4 4 0 0 1-4-4V8a4 4 0 0 1 4-4h20a4 4 0 0 1 4 4v12a4 4 0 0 1-4 4h-4.84Z"></path><path fill="currentColor" d="M8 10h16v2H8zm0 6h10v2H8z"></path></svg>');
e.from_svg('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32"><path fill="currentColor" d="M19 10h7v2h-7zm0 5h7v2h-7zm0 5h7v2h-7z"></path><path fill="currentColor" d="M28 5H4a2 2 0 0 0-2 2v18a2 2 0 0 0 2 2h24a2.003 2.003 0 0 0 2-2V7a2 2 0 0 0-2-2M4 7h11v18H4Zm13 18V7h11l.002 18Z"></path></svg>');
var bs = e.from_html('<div class="wrap svelte-1kz2yq3"><span><!></span> Drop PDF <span class="or svelte-1kz2yq3">- or -</span> Click to Upload</div>');
function ws(V, l) {
  let a = e.prop(l, "hovered", 8, !1);
  var s = bs(), S = e.child(s);
  let v;
  var _ = e.child(S);
  vs(_), e.reset(S), e.next(3), e.reset(s), e.template_effect(() => v = e.set_class(S, 1, "icon-wrap svelte-1kz2yq3", null, v, { hovered: a() })), e.append(V, s);
}
const As = [
  { color: "red", primary: 600, secondary: 100 },
  { color: "green", primary: 600, secondary: 100 },
  { color: "blue", primary: 600, secondary: 100 },
  { color: "yellow", primary: 500, secondary: 100 },
  { color: "purple", primary: 600, secondary: 100 },
  { color: "teal", primary: 600, secondary: 100 },
  { color: "orange", primary: 600, secondary: 100 },
  { color: "cyan", primary: 600, secondary: 100 },
  { color: "lime", primary: 500, secondary: 100 },
  { color: "pink", primary: 600, secondary: 100 }
], Ce = {
  inherit: "inherit",
  current: "currentColor",
  transparent: "transparent",
  black: "#000",
  white: "#fff",
  slate: {
    50: "#f8fafc",
    100: "#f1f5f9",
    200: "#e2e8f0",
    300: "#cbd5e1",
    400: "#94a3b8",
    500: "#64748b",
    600: "#475569",
    700: "#334155",
    800: "#1e293b",
    900: "#0f172a",
    950: "#020617"
  },
  gray: {
    50: "#f9fafb",
    100: "#f3f4f6",
    200: "#e5e7eb",
    300: "#d1d5db",
    400: "#9ca3af",
    500: "#6b7280",
    600: "#4b5563",
    700: "#374151",
    800: "#1f2937",
    900: "#111827",
    950: "#030712"
  },
  zinc: {
    50: "#fafafa",
    100: "#f4f4f5",
    200: "#e4e4e7",
    300: "#d4d4d8",
    400: "#a1a1aa",
    500: "#71717a",
    600: "#52525b",
    700: "#3f3f46",
    800: "#27272a",
    900: "#18181b",
    950: "#09090b"
  },
  neutral: {
    50: "#fafafa",
    100: "#f5f5f5",
    200: "#e5e5e5",
    300: "#d4d4d4",
    400: "#a3a3a3",
    500: "#737373",
    600: "#525252",
    700: "#404040",
    800: "#262626",
    900: "#171717",
    950: "#0a0a0a"
  },
  stone: {
    50: "#fafaf9",
    100: "#f5f5f4",
    200: "#e7e5e4",
    300: "#d6d3d1",
    400: "#a8a29e",
    500: "#78716c",
    600: "#57534e",
    700: "#44403c",
    800: "#292524",
    900: "#1c1917",
    950: "#0c0a09"
  },
  red: {
    50: "#fef2f2",
    100: "#fee2e2",
    200: "#fecaca",
    300: "#fca5a5",
    400: "#f87171",
    500: "#ef4444",
    600: "#dc2626",
    700: "#b91c1c",
    800: "#991b1b",
    900: "#7f1d1d",
    950: "#450a0a"
  },
  orange: {
    50: "#fff7ed",
    100: "#ffedd5",
    200: "#fed7aa",
    300: "#fdba74",
    400: "#fb923c",
    500: "#f97316",
    600: "#ea580c",
    700: "#c2410c",
    800: "#9a3412",
    900: "#7c2d12",
    950: "#431407"
  },
  amber: {
    50: "#fffbeb",
    100: "#fef3c7",
    200: "#fde68a",
    300: "#fcd34d",
    400: "#fbbf24",
    500: "#f59e0b",
    600: "#d97706",
    700: "#b45309",
    800: "#92400e",
    900: "#78350f",
    950: "#451a03"
  },
  yellow: {
    50: "#fefce8",
    100: "#fef9c3",
    200: "#fef08a",
    300: "#fde047",
    400: "#facc15",
    500: "#eab308",
    600: "#ca8a04",
    700: "#a16207",
    800: "#854d0e",
    900: "#713f12",
    950: "#422006"
  },
  lime: {
    50: "#f7fee7",
    100: "#ecfccb",
    200: "#d9f99d",
    300: "#bef264",
    400: "#a3e635",
    500: "#84cc16",
    600: "#65a30d",
    700: "#4d7c0f",
    800: "#3f6212",
    900: "#365314",
    950: "#1a2e05"
  },
  green: {
    50: "#f0fdf4",
    100: "#dcfce7",
    200: "#bbf7d0",
    300: "#86efac",
    400: "#4ade80",
    500: "#22c55e",
    600: "#16a34a",
    700: "#15803d",
    800: "#166534",
    900: "#14532d",
    950: "#052e16"
  },
  emerald: {
    50: "#ecfdf5",
    100: "#d1fae5",
    200: "#a7f3d0",
    300: "#6ee7b7",
    400: "#34d399",
    500: "#10b981",
    600: "#059669",
    700: "#047857",
    800: "#065f46",
    900: "#064e3b",
    950: "#022c22"
  },
  teal: {
    50: "#f0fdfa",
    100: "#ccfbf1",
    200: "#99f6e4",
    300: "#5eead4",
    400: "#2dd4bf",
    500: "#14b8a6",
    600: "#0d9488",
    700: "#0f766e",
    800: "#115e59",
    900: "#134e4a",
    950: "#042f2e"
  },
  cyan: {
    50: "#ecfeff",
    100: "#cffafe",
    200: "#a5f3fc",
    300: "#67e8f9",
    400: "#22d3ee",
    500: "#06b6d4",
    600: "#0891b2",
    700: "#0e7490",
    800: "#155e75",
    900: "#164e63",
    950: "#083344"
  },
  sky: {
    50: "#f0f9ff",
    100: "#e0f2fe",
    200: "#bae6fd",
    300: "#7dd3fc",
    400: "#38bdf8",
    500: "#0ea5e9",
    600: "#0284c7",
    700: "#0369a1",
    800: "#075985",
    900: "#0c4a6e",
    950: "#082f49"
  },
  blue: {
    50: "#eff6ff",
    100: "#dbeafe",
    200: "#bfdbfe",
    300: "#93c5fd",
    400: "#60a5fa",
    500: "#3b82f6",
    600: "#2563eb",
    700: "#1d4ed8",
    800: "#1e40af",
    900: "#1e3a8a",
    950: "#172554"
  },
  indigo: {
    50: "#eef2ff",
    100: "#e0e7ff",
    200: "#c7d2fe",
    300: "#a5b4fc",
    400: "#818cf8",
    500: "#6366f1",
    600: "#4f46e5",
    700: "#4338ca",
    800: "#3730a3",
    900: "#312e81",
    950: "#1e1b4b"
  },
  violet: {
    50: "#f5f3ff",
    100: "#ede9fe",
    200: "#ddd6fe",
    300: "#c4b5fd",
    400: "#a78bfa",
    500: "#8b5cf6",
    600: "#7c3aed",
    700: "#6d28d9",
    800: "#5b21b6",
    900: "#4c1d95",
    950: "#2e1065"
  },
  purple: {
    50: "#faf5ff",
    100: "#f3e8ff",
    200: "#e9d5ff",
    300: "#d8b4fe",
    400: "#c084fc",
    500: "#a855f7",
    600: "#9333ea",
    700: "#7e22ce",
    800: "#6b21a8",
    900: "#581c87",
    950: "#3b0764"
  },
  fuchsia: {
    50: "#fdf4ff",
    100: "#fae8ff",
    200: "#f5d0fe",
    300: "#f0abfc",
    400: "#e879f9",
    500: "#d946ef",
    600: "#c026d3",
    700: "#a21caf",
    800: "#86198f",
    900: "#701a75",
    950: "#4a044e"
  },
  pink: {
    50: "#fdf2f8",
    100: "#fce7f3",
    200: "#fbcfe8",
    300: "#f9a8d4",
    400: "#f472b6",
    500: "#ec4899",
    600: "#db2777",
    700: "#be185d",
    800: "#9d174d",
    900: "#831843",
    950: "#500724"
  },
  rose: {
    50: "#fff1f2",
    100: "#ffe4e6",
    200: "#fecdd3",
    300: "#fda4af",
    400: "#fb7185",
    500: "#f43f5e",
    600: "#e11d48",
    700: "#be123c",
    800: "#9f1239",
    900: "#881337",
    950: "#4c0519"
  }
};
As.reduce((V, { color: l, primary: a, secondary: s }) => ({
  ...V,
  [l]: {
    primary: Ce[l][a],
    secondary: Ce[l][s]
  }
}), {});
const ys = "GRADIO_ROOT", xs = typeof window < "u", Es = [
  "elem_id",
  "elem_classes",
  "visible",
  "interactive",
  "server_fns",
  "server",
  "id",
  "target",
  "theme_mode",
  "version",
  "root",
  "autoscroll",
  "max_file_size",
  "formatter",
  "client",
  "load_component",
  "scale",
  "min_width",
  "theme",
  "padding",
  "loading_status",
  "label",
  "show_label",
  "validation_error",
  "show_progress",
  "api_prefix",
  "container",
  "attached_events"
];
class ks {
  load_component;
  #t = e.state(e.proxy({}));
  get shared() {
    return e.get(this.#t);
  }
  set shared(l) {
    e.set(this.#t, l, !0);
  }
  #e = e.state(e.proxy({}));
  get props() {
    return e.get(this.#e);
  }
  set props(l) {
    e.set(this.#e, l, !0);
  }
  #s = e.state(e.proxy({}));
  get i18n() {
    return e.get(this.#s);
  }
  set i18n(l) {
    e.set(this.#s, l, !0);
  }
  dispatcher;
  last_update = null;
  shared_props = Es;
  constructor(l, a) {
    for (const v in l.shared_props)
      this.shared[v] = l.shared_props[v];
    for (const v in l.props)
      this.props[v] = l.props[v];
    if (a)
      for (const v in a)
        this.props[v] === void 0 && (this.props[v] = a[v]);
    if (this.i18n = this.props.i18n, this.load_component = this.shared.load_component, !xs || l.props?.__GRADIO_BROWSER_TEST__) return;
    const { register: s, dispatcher: S } = as(ys);
    s(l.shared_props.id, this.set_data.bind(this), this.get_data.bind(this)), this.dispatcher = S, e.user_effect(() => {
      for (const v in l.shared_props)
        this.shared[v] = l.shared_props[v];
      for (const v in l.props)
        this.props[v] = l.props[v];
      s(l.shared_props.id, this.set_data.bind(this), this.get_data.bind(this)), fe(() => {
        this.shared.id = l.shared_props.id;
      });
    });
  }
  dispatch(l, a) {
    this.dispatcher(this.shared.id, l, a);
  }
  async get_data() {
    return e.snapshot(this.props);
  }
  update(l) {
    this.set_data(l);
  }
  set_data(l) {
    for (const a in l)
      if (this.shared_props.includes(a)) {
        const s = a;
        this.shared[s] = l[s];
        continue;
      } else
        this.props[a] = l[a];
  }
}
var Cs = e.from_svg('<svg class="resize-handle svelte-1stq1b1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 10 10"><line x1="1" y1="9" x2="9" y2="1" stroke="gray" stroke-width="0.5" class="svelte-1stq1b1"></line><line x1="5" y1="9" x2="9" y2="5" stroke="gray" stroke-width="0.5" class="svelte-1stq1b1"></line></svg>'), Ss = e.from_html("<!> <!>", 1), Fs = e.from_html('<div class="placeholder svelte-1stq1b1"></div>'), Ds = e.from_html("<!> <!>", 1);
function Ts(V, l) {
  e.push(l, !1);
  let a = e.prop(l, "height", 8, void 0), s = e.prop(l, "min_height", 8, void 0), S = e.prop(l, "max_height", 8, void 0), v = e.prop(l, "width", 8, void 0), _ = e.prop(l, "elem_id", 8, ""), x = e.prop(l, "elem_classes", 24, () => []), C = e.prop(l, "variant", 8, "solid"), T = e.prop(l, "border_mode", 8, "base"), A = e.prop(l, "padding", 8, !0), n = e.prop(l, "type", 8, "normal"), f = e.prop(l, "test_id", 8, void 0), p = e.prop(l, "explicit_call", 8, !1), F = e.prop(l, "container", 8, !0), r = e.prop(l, "visible", 8, !0), w = e.prop(l, "allow_overflow", 8, !0), t = e.prop(l, "overflow_behavior", 8, "auto"), i = e.prop(l, "scale", 8, null), h = e.prop(l, "min_width", 8, 0), d = e.prop(l, "flex", 12, !1), E = e.prop(l, "resizable", 8, !1), k = e.prop(l, "rtl", 8, !1), L = e.prop(l, "fullscreen", 12, !1), M = e.mutable_source(L()), B = e.mutable_source(), U = n() === "fieldset" ? "fieldset" : "div", q = e.mutable_source(0), Z = e.mutable_source(0), K = e.mutable_source(null);
  function Y(rt) {
    L() && rt.key === "Escape" && L(!1);
  }
  const G = (rt) => {
    if (rt !== void 0) {
      if (typeof rt == "number")
        return rt + "px";
      if (typeof rt == "string")
        return rt;
    }
  }, j = (rt) => {
    let ut = rt.clientY;
    const dt = (lt) => {
      const ot = lt.clientY - ut;
      ut = lt.clientY, e.mutate(B, e.get(B).style.height = `${e.get(B).offsetHeight + ot}px`);
    }, ft = () => {
      window.removeEventListener("mousemove", dt), window.removeEventListener("mouseup", ft);
    };
    window.addEventListener("mousemove", dt), window.addEventListener("mouseup", ft);
  };
  e.legacy_pre_effect(
    () => (e.deep_read_state(L()), e.get(M), e.get(B)),
    () => {
      L() !== e.get(M) && (e.set(M, L()), L() ? (e.set(K, e.get(B).getBoundingClientRect()), e.set(q, e.get(B).offsetHeight), e.set(Z, e.get(B).offsetWidth), window.addEventListener("keydown", Y)) : (e.set(K, null), window.removeEventListener("keydown", Y)));
    }
  ), e.legacy_pre_effect(() => e.deep_read_state(r()), () => {
    r() || d(!1);
  }), e.legacy_pre_effect_reset(), e.init();
  var Q = e.comment(), J = e.first_child(Q);
  {
    var tt = (rt) => {
      var ut = Ds(), dt = e.first_child(ut);
      e.element(dt, () => U, !1, (ot, et) => {
        e.bind_this(ot, (m) => e.set(B, m), () => e.get(B)), e.attribute_effect(
          ot,
          (m, g) => ({
            "data-testid": f(),
            id: _(),
            class: `block ${m ?? ""}`,
            dir: k() ? "rtl" : "ltr",
            style: "",
            [e.CLASS]: {
              hidden: r() === "hidden",
              padded: A(),
              flex: d(),
              border_focus: T() === "focus",
              border_contrast: T() === "contrast",
              "hide-container": !p() && !F(),
              fullscreen: L(),
              animating: L() && e.get(K) !== null,
              "auto-margin": i() === null
            },
            [e.STYLE]: g
          }),
          [
            () => (e.deep_read_state(x()), e.untrack(() => x()?.join(" ") || "")),
            () => ({
              height: (e.deep_read_state(L()), e.deep_read_state(a()), e.untrack(() => L() ? void 0 : G(a()))),
              "min-height": (e.deep_read_state(L()), e.deep_read_state(s()), e.untrack(() => L() ? void 0 : G(s()))),
              "max-height": (e.deep_read_state(L()), e.deep_read_state(S()), e.untrack(() => L() ? void 0 : G(S()))),
              "--start-top": (e.get(K), e.untrack(() => e.get(K) ? `${e.get(K).top}px` : "0px")),
              "--start-left": (e.get(K), e.untrack(() => e.get(K) ? `${e.get(K).left}px` : "0px")),
              "--start-width": (e.get(K), e.untrack(() => e.get(K) ? `${e.get(K).width}px` : "0px")),
              "--start-height": (e.get(K), e.untrack(() => e.get(K) ? `${e.get(K).height}px` : "0px")),
              width: (e.deep_read_state(L()), e.deep_read_state(v()), e.untrack(() => L() ? void 0 : typeof v() == "number" ? `calc(min(${v()}px, 100%))` : G(v()))),
              "border-style": C(),
              overflow: w() ? t() : "hidden",
              "flex-grow": i(),
              "min-width": `calc(min(${h()}px, 100%))`,
              "border-width": "var(--block-border-width)"
            })
          ],
          void 0,
          void 0,
          "svelte-1stq1b1"
        );
        var D = Ss(), y = e.first_child(D);
        e.slot(y, l, "default", {}, null);
        var o = e.sibling(y, 2);
        {
          var u = (m) => {
            var g = Cs();
            e.event("mousedown", g, j), e.append(m, g);
          };
          e.if(o, (m) => {
            E() && m(u);
          });
        }
        e.append(et, D);
      });
      var ft = e.sibling(dt, 2);
      {
        var lt = (ot) => {
          var et = Fs();
          let D;
          e.template_effect(() => D = e.set_style(et, "", D, {
            height: e.get(q) + "px",
            width: e.get(Z) + "px"
          })), e.append(ot, et);
        };
        e.if(ft, (ot) => {
          L() && ot(lt);
        });
      }
      e.append(rt, ut);
    };
    e.if(J, (rt) => {
      (r() === !0 || r() === "hidden") && rt(tt);
    });
  }
  e.append(V, Q), e.pop();
}
function me() {
  return {
    async: !1,
    breaks: !1,
    extensions: null,
    gfm: !0,
    hooks: null,
    pedantic: !1,
    renderer: null,
    silent: !1,
    tokenizer: null,
    walkTokens: null
  };
}
let $t = me();
function Xe(V) {
  $t = V;
}
const Ye = /[&<>"']/, _s = new RegExp(Ye.source, "g"), We = /[<>"']|&(?!(#\d{1,7}|#[Xx][a-fA-F0-9]{1,6}|\w+);)/, Rs = new RegExp(We.source, "g"), Ls = {
  "&": "&amp;",
  "<": "&lt;",
  ">": "&gt;",
  '"': "&quot;",
  "'": "&#39;"
}, Se = (V) => Ls[V];
function Lt(V, l) {
  if (l) {
    if (Ye.test(V))
      return V.replace(_s, Se);
  } else if (We.test(V))
    return V.replace(Rs, Se);
  return V;
}
const Is = /&(#(?:\d+)|(?:#x[0-9A-Fa-f]+)|(?:\w+));?/ig;
function Ms(V) {
  return V.replace(Is, (l, a) => (a = a.toLowerCase(), a === "colon" ? ":" : a.charAt(0) === "#" ? a.charAt(1) === "x" ? String.fromCharCode(parseInt(a.substring(2), 16)) : String.fromCharCode(+a.substring(1)) : ""));
}
const Ps = /(^|[^\[])\^/g;
function yt(V, l) {
  let a = typeof V == "string" ? V : V.source;
  l = l || "";
  const s = {
    replace: (S, v) => {
      let _ = typeof v == "string" ? v : v.source;
      return _ = _.replace(Ps, "$1"), a = a.replace(S, _), s;
    },
    getRegex: () => new RegExp(a, l)
  };
  return s;
}
function Fe(V) {
  try {
    V = encodeURI(V).replace(/%25/g, "%");
  } catch {
    return null;
  }
  return V;
}
const Wt = { exec: () => null };
function De(V, l) {
  const a = V.replace(/\|/g, (v, _, x) => {
    let C = !1, T = _;
    for (; --T >= 0 && x[T] === "\\"; )
      C = !C;
    return C ? "|" : " |";
  }), s = a.split(/ \|/);
  let S = 0;
  if (s[0].trim() || s.shift(), s.length > 0 && !s[s.length - 1].trim() && s.pop(), l)
    if (s.length > l)
      s.splice(l);
    else
      for (; s.length < l; )
        s.push("");
  for (; S < s.length; S++)
    s[S] = s[S].trim().replace(/\\\|/g, "|");
  return s;
}
function Qt(V, l, a) {
  const s = V.length;
  if (s === 0)
    return "";
  let S = 0;
  for (; S < s && V.charAt(s - S - 1) === l; )
    S++;
  return V.slice(0, s - S);
}
function Ns(V, l) {
  if (V.indexOf(l[1]) === -1)
    return -1;
  let a = 0;
  for (let s = 0; s < V.length; s++)
    if (V[s] === "\\")
      s++;
    else if (V[s] === l[0])
      a++;
    else if (V[s] === l[1] && (a--, a < 0))
      return s;
  return -1;
}
function Te(V, l, a, s) {
  const S = l.href, v = l.title ? Lt(l.title) : null, _ = V[1].replace(/\\([\[\]])/g, "$1");
  if (V[0].charAt(0) !== "!") {
    s.state.inLink = !0;
    const x = {
      type: "link",
      raw: a,
      href: S,
      title: v,
      text: _,
      tokens: s.inlineTokens(_)
    };
    return s.state.inLink = !1, x;
  }
  return {
    type: "image",
    raw: a,
    href: S,
    title: v,
    text: Lt(_)
  };
}
function Os(V, l) {
  const a = V.match(/^(\s+)(?:```)/);
  if (a === null)
    return l;
  const s = a[1];
  return l.split(`
`).map((S) => {
    const v = S.match(/^\s+/);
    if (v === null)
      return S;
    const [_] = v;
    return _.length >= s.length ? S.slice(s.length) : S;
  }).join(`
`);
}
class ie {
  options;
  rules;
  // set by the lexer
  lexer;
  // set by the lexer
  constructor(l) {
    this.options = l || $t;
  }
  space(l) {
    const a = this.rules.block.newline.exec(l);
    if (a && a[0].length > 0)
      return {
        type: "space",
        raw: a[0]
      };
  }
  code(l) {
    const a = this.rules.block.code.exec(l);
    if (a) {
      const s = a[0].replace(/^ {1,4}/gm, "");
      return {
        type: "code",
        raw: a[0],
        codeBlockStyle: "indented",
        text: this.options.pedantic ? s : Qt(s, `
`)
      };
    }
  }
  fences(l) {
    const a = this.rules.block.fences.exec(l);
    if (a) {
      const s = a[0], S = Os(s, a[3] || "");
      return {
        type: "code",
        raw: s,
        lang: a[2] ? a[2].trim().replace(this.rules.inline.anyPunctuation, "$1") : a[2],
        text: S
      };
    }
  }
  heading(l) {
    const a = this.rules.block.heading.exec(l);
    if (a) {
      let s = a[2].trim();
      if (/#$/.test(s)) {
        const S = Qt(s, "#");
        (this.options.pedantic || !S || / $/.test(S)) && (s = S.trim());
      }
      return {
        type: "heading",
        raw: a[0],
        depth: a[1].length,
        text: s,
        tokens: this.lexer.inline(s)
      };
    }
  }
  hr(l) {
    const a = this.rules.block.hr.exec(l);
    if (a)
      return {
        type: "hr",
        raw: a[0]
      };
  }
  blockquote(l) {
    const a = this.rules.block.blockquote.exec(l);
    if (a) {
      let s = a[0].replace(/\n {0,3}((?:=+|-+) *)(?=\n|$)/g, `
    $1`);
      s = Qt(s.replace(/^ *>[ \t]?/gm, ""), `
`);
      const S = this.lexer.state.top;
      this.lexer.state.top = !0;
      const v = this.lexer.blockTokens(s);
      return this.lexer.state.top = S, {
        type: "blockquote",
        raw: a[0],
        tokens: v,
        text: s
      };
    }
  }
  list(l) {
    let a = this.rules.block.list.exec(l);
    if (a) {
      let s = a[1].trim();
      const S = s.length > 1, v = {
        type: "list",
        raw: "",
        ordered: S,
        start: S ? +s.slice(0, -1) : "",
        loose: !1,
        items: []
      };
      s = S ? `\\d{1,9}\\${s.slice(-1)}` : `\\${s}`, this.options.pedantic && (s = S ? s : "[*+-]");
      const _ = new RegExp(`^( {0,3}${s})((?:[	 ][^\\n]*)?(?:\\n|$))`);
      let x = "", C = "", T = !1;
      for (; l; ) {
        let A = !1;
        if (!(a = _.exec(l)) || this.rules.block.hr.test(l))
          break;
        x = a[0], l = l.substring(x.length);
        let n = a[2].split(`
`, 1)[0].replace(/^\t+/, (t) => " ".repeat(3 * t.length)), f = l.split(`
`, 1)[0], p = 0;
        this.options.pedantic ? (p = 2, C = n.trimStart()) : (p = a[2].search(/[^ ]/), p = p > 4 ? 1 : p, C = n.slice(p), p += a[1].length);
        let F = !1;
        if (!n && /^ *$/.test(f) && (x += f + `
`, l = l.substring(f.length + 1), A = !0), !A) {
          const t = new RegExp(`^ {0,${Math.min(3, p - 1)}}(?:[*+-]|\\d{1,9}[.)])((?:[ 	][^\\n]*)?(?:\\n|$))`), i = new RegExp(`^ {0,${Math.min(3, p - 1)}}((?:- *){3,}|(?:_ *){3,}|(?:\\* *){3,})(?:\\n+|$)`), h = new RegExp(`^ {0,${Math.min(3, p - 1)}}(?:\`\`\`|~~~)`), d = new RegExp(`^ {0,${Math.min(3, p - 1)}}#`);
          for (; l; ) {
            const E = l.split(`
`, 1)[0];
            if (f = E, this.options.pedantic && (f = f.replace(/^ {1,4}(?=( {4})*[^ ])/g, "  ")), h.test(f) || d.test(f) || t.test(f) || i.test(l))
              break;
            if (f.search(/[^ ]/) >= p || !f.trim())
              C += `
` + f.slice(p);
            else {
              if (F || n.search(/[^ ]/) >= 4 || h.test(n) || d.test(n) || i.test(n))
                break;
              C += `
` + f;
            }
            !F && !f.trim() && (F = !0), x += E + `
`, l = l.substring(E.length + 1), n = f.slice(p);
          }
        }
        v.loose || (T ? v.loose = !0 : /\n *\n *$/.test(x) && (T = !0));
        let r = null, w;
        this.options.gfm && (r = /^\[[ xX]\] /.exec(C), r && (w = r[0] !== "[ ] ", C = C.replace(/^\[[ xX]\] +/, ""))), v.items.push({
          type: "list_item",
          raw: x,
          task: !!r,
          checked: w,
          loose: !1,
          text: C,
          tokens: []
        }), v.raw += x;
      }
      v.items[v.items.length - 1].raw = x.trimEnd(), v.items[v.items.length - 1].text = C.trimEnd(), v.raw = v.raw.trimEnd();
      for (let A = 0; A < v.items.length; A++)
        if (this.lexer.state.top = !1, v.items[A].tokens = this.lexer.blockTokens(v.items[A].text, []), !v.loose) {
          const n = v.items[A].tokens.filter((p) => p.type === "space"), f = n.length > 0 && n.some((p) => /\n.*\n/.test(p.raw));
          v.loose = f;
        }
      if (v.loose)
        for (let A = 0; A < v.items.length; A++)
          v.items[A].loose = !0;
      return v;
    }
  }
  html(l) {
    const a = this.rules.block.html.exec(l);
    if (a)
      return {
        type: "html",
        block: !0,
        raw: a[0],
        pre: a[1] === "pre" || a[1] === "script" || a[1] === "style",
        text: a[0]
      };
  }
  def(l) {
    const a = this.rules.block.def.exec(l);
    if (a) {
      const s = a[1].toLowerCase().replace(/\s+/g, " "), S = a[2] ? a[2].replace(/^<(.*)>$/, "$1").replace(this.rules.inline.anyPunctuation, "$1") : "", v = a[3] ? a[3].substring(1, a[3].length - 1).replace(this.rules.inline.anyPunctuation, "$1") : a[3];
      return {
        type: "def",
        tag: s,
        raw: a[0],
        href: S,
        title: v
      };
    }
  }
  table(l) {
    const a = this.rules.block.table.exec(l);
    if (!a || !/[:|]/.test(a[2]))
      return;
    const s = De(a[1]), S = a[2].replace(/^\||\| *$/g, "").split("|"), v = a[3] && a[3].trim() ? a[3].replace(/\n[ \t]*$/, "").split(`
`) : [], _ = {
      type: "table",
      raw: a[0],
      header: [],
      align: [],
      rows: []
    };
    if (s.length === S.length) {
      for (const x of S)
        /^ *-+: *$/.test(x) ? _.align.push("right") : /^ *:-+: *$/.test(x) ? _.align.push("center") : /^ *:-+ *$/.test(x) ? _.align.push("left") : _.align.push(null);
      for (const x of s)
        _.header.push({
          text: x,
          tokens: this.lexer.inline(x)
        });
      for (const x of v)
        _.rows.push(De(x, _.header.length).map((C) => ({
          text: C,
          tokens: this.lexer.inline(C)
        })));
      return _;
    }
  }
  lheading(l) {
    const a = this.rules.block.lheading.exec(l);
    if (a)
      return {
        type: "heading",
        raw: a[0],
        depth: a[2].charAt(0) === "=" ? 1 : 2,
        text: a[1],
        tokens: this.lexer.inline(a[1])
      };
  }
  paragraph(l) {
    const a = this.rules.block.paragraph.exec(l);
    if (a) {
      const s = a[1].charAt(a[1].length - 1) === `
` ? a[1].slice(0, -1) : a[1];
      return {
        type: "paragraph",
        raw: a[0],
        text: s,
        tokens: this.lexer.inline(s)
      };
    }
  }
  text(l) {
    const a = this.rules.block.text.exec(l);
    if (a)
      return {
        type: "text",
        raw: a[0],
        text: a[0],
        tokens: this.lexer.inline(a[0])
      };
  }
  escape(l) {
    const a = this.rules.inline.escape.exec(l);
    if (a)
      return {
        type: "escape",
        raw: a[0],
        text: Lt(a[1])
      };
  }
  tag(l) {
    const a = this.rules.inline.tag.exec(l);
    if (a)
      return !this.lexer.state.inLink && /^<a /i.test(a[0]) ? this.lexer.state.inLink = !0 : this.lexer.state.inLink && /^<\/a>/i.test(a[0]) && (this.lexer.state.inLink = !1), !this.lexer.state.inRawBlock && /^<(pre|code|kbd|script)(\s|>)/i.test(a[0]) ? this.lexer.state.inRawBlock = !0 : this.lexer.state.inRawBlock && /^<\/(pre|code|kbd|script)(\s|>)/i.test(a[0]) && (this.lexer.state.inRawBlock = !1), {
        type: "html",
        raw: a[0],
        inLink: this.lexer.state.inLink,
        inRawBlock: this.lexer.state.inRawBlock,
        block: !1,
        text: a[0]
      };
  }
  link(l) {
    const a = this.rules.inline.link.exec(l);
    if (a) {
      const s = a[2].trim();
      if (!this.options.pedantic && /^</.test(s)) {
        if (!/>$/.test(s))
          return;
        const _ = Qt(s.slice(0, -1), "\\");
        if ((s.length - _.length) % 2 === 0)
          return;
      } else {
        const _ = Ns(a[2], "()");
        if (_ > -1) {
          const C = (a[0].indexOf("!") === 0 ? 5 : 4) + a[1].length + _;
          a[2] = a[2].substring(0, _), a[0] = a[0].substring(0, C).trim(), a[3] = "";
        }
      }
      let S = a[2], v = "";
      if (this.options.pedantic) {
        const _ = /^([^'"]*[^\s])\s+(['"])(.*)\2/.exec(S);
        _ && (S = _[1], v = _[3]);
      } else
        v = a[3] ? a[3].slice(1, -1) : "";
      return S = S.trim(), /^</.test(S) && (this.options.pedantic && !/>$/.test(s) ? S = S.slice(1) : S = S.slice(1, -1)), Te(a, {
        href: S && S.replace(this.rules.inline.anyPunctuation, "$1"),
        title: v && v.replace(this.rules.inline.anyPunctuation, "$1")
      }, a[0], this.lexer);
    }
  }
  reflink(l, a) {
    let s;
    if ((s = this.rules.inline.reflink.exec(l)) || (s = this.rules.inline.nolink.exec(l))) {
      const S = (s[2] || s[1]).replace(/\s+/g, " "), v = a[S.toLowerCase()];
      if (!v) {
        const _ = s[0].charAt(0);
        return {
          type: "text",
          raw: _,
          text: _
        };
      }
      return Te(s, v, s[0], this.lexer);
    }
  }
  emStrong(l, a, s = "") {
    let S = this.rules.inline.emStrongLDelim.exec(l);
    if (!S || S[3] && s.match(/[\p{L}\p{N}]/u))
      return;
    if (!(S[1] || S[2] || "") || !s || this.rules.inline.punctuation.exec(s)) {
      const _ = [...S[0]].length - 1;
      let x, C, T = _, A = 0;
      const n = S[0][0] === "*" ? this.rules.inline.emStrongRDelimAst : this.rules.inline.emStrongRDelimUnd;
      for (n.lastIndex = 0, a = a.slice(-1 * l.length + _); (S = n.exec(a)) != null; ) {
        if (x = S[1] || S[2] || S[3] || S[4] || S[5] || S[6], !x)
          continue;
        if (C = [...x].length, S[3] || S[4]) {
          T += C;
          continue;
        } else if ((S[5] || S[6]) && _ % 3 && !((_ + C) % 3)) {
          A += C;
          continue;
        }
        if (T -= C, T > 0)
          continue;
        C = Math.min(C, C + T + A);
        const f = [...S[0]][0].length, p = l.slice(0, _ + S.index + f + C);
        if (Math.min(_, C) % 2) {
          const r = p.slice(1, -1);
          return {
            type: "em",
            raw: p,
            text: r,
            tokens: this.lexer.inlineTokens(r)
          };
        }
        const F = p.slice(2, -2);
        return {
          type: "strong",
          raw: p,
          text: F,
          tokens: this.lexer.inlineTokens(F)
        };
      }
    }
  }
  codespan(l) {
    const a = this.rules.inline.code.exec(l);
    if (a) {
      let s = a[2].replace(/\n/g, " ");
      const S = /[^ ]/.test(s), v = /^ /.test(s) && / $/.test(s);
      return S && v && (s = s.substring(1, s.length - 1)), s = Lt(s, !0), {
        type: "codespan",
        raw: a[0],
        text: s
      };
    }
  }
  br(l) {
    const a = this.rules.inline.br.exec(l);
    if (a)
      return {
        type: "br",
        raw: a[0]
      };
  }
  del(l) {
    const a = this.rules.inline.del.exec(l);
    if (a)
      return {
        type: "del",
        raw: a[0],
        text: a[2],
        tokens: this.lexer.inlineTokens(a[2])
      };
  }
  autolink(l) {
    const a = this.rules.inline.autolink.exec(l);
    if (a) {
      let s, S;
      return a[2] === "@" ? (s = Lt(a[1]), S = "mailto:" + s) : (s = Lt(a[1]), S = s), {
        type: "link",
        raw: a[0],
        text: s,
        href: S,
        tokens: [
          {
            type: "text",
            raw: s,
            text: s
          }
        ]
      };
    }
  }
  url(l) {
    let a;
    if (a = this.rules.inline.url.exec(l)) {
      let s, S;
      if (a[2] === "@")
        s = Lt(a[0]), S = "mailto:" + s;
      else {
        let v;
        do
          v = a[0], a[0] = this.rules.inline._backpedal.exec(a[0])?.[0] ?? "";
        while (v !== a[0]);
        s = Lt(a[0]), a[1] === "www." ? S = "http://" + a[0] : S = a[0];
      }
      return {
        type: "link",
        raw: a[0],
        text: s,
        href: S,
        tokens: [
          {
            type: "text",
            raw: s,
            text: s
          }
        ]
      };
    }
  }
  inlineText(l) {
    const a = this.rules.inline.text.exec(l);
    if (a) {
      let s;
      return this.lexer.state.inRawBlock ? s = a[0] : s = Lt(a[0]), {
        type: "text",
        raw: a[0],
        text: s
      };
    }
  }
}
const Bs = /^(?: *(?:\n|$))+/, Hs = /^( {4}[^\n]+(?:\n(?: *(?:\n|$))*)?)+/, zs = /^ {0,3}(`{3,}(?=[^`\n]*(?:\n|$))|~{3,})([^\n]*)(?:\n|$)(?:|([\s\S]*?)(?:\n|$))(?: {0,3}\1[~`]* *(?=\n|$)|$)/, Zt = /^ {0,3}((?:-[\t ]*){3,}|(?:_[ \t]*){3,}|(?:\*[ \t]*){3,})(?:\n+|$)/, Us = /^ {0,3}(#{1,6})(?=\s|$)(.*)(?:\n+|$)/, Ze = /(?:[*+-]|\d{1,9}[.)])/, Ke = yt(/^(?!bull |blockCode|fences|blockquote|heading|html)((?:.|\n(?!\s*?\n|bull |blockCode|fences|blockquote|heading|html))+?)\n {0,3}(=+|-+) *(?:\n+|$)/).replace(/bull/g, Ze).replace(/blockCode/g, / {4}/).replace(/fences/g, / {0,3}(?:`{3,}|~{3,})/).replace(/blockquote/g, / {0,3}>/).replace(/heading/g, / {0,3}#{1,6}/).replace(/html/g, / {0,3}<[^\n>]+>\n/).getRegex(), ve = /^([^\n]+(?:\n(?!hr|heading|lheading|blockquote|fences|list|html|table| +\n)[^\n]+)*)/, Vs = /^[^\n]+/, be = /(?!\s*\])(?:\\.|[^\[\]\\])+/, Gs = yt(/^ {0,3}\[(label)\]: *(?:\n *)?([^<\s][^\s]*|<.*?>)(?:(?: +(?:\n *)?| *\n *)(title))? *(?:\n+|$)/).replace("label", be).replace("title", /(?:"(?:\\"?|[^"\\])*"|'[^'\n]*(?:\n[^'\n]+)*\n?'|\([^()]*\))/).getRegex(), $s = yt(/^( {0,3}bull)([ \t][^\n]+?)?(?:\n|$)/).replace(/bull/g, Ze).getRegex(), oe = "address|article|aside|base|basefont|blockquote|body|caption|center|col|colgroup|dd|details|dialog|dir|div|dl|dt|fieldset|figcaption|figure|footer|form|frame|frameset|h[1-6]|head|header|hr|html|iframe|legend|li|link|main|menu|menuitem|meta|nav|noframes|ol|optgroup|option|p|param|search|section|summary|table|tbody|td|tfoot|th|thead|title|tr|track|ul", we = /<!--(?:-?>|[\s\S]*?(?:-->|$))/, qs = yt("^ {0,3}(?:<(script|pre|style|textarea)[\\s>][\\s\\S]*?(?:</\\1>[^\\n]*\\n+|$)|comment[^\\n]*(\\n+|$)|<\\?[\\s\\S]*?(?:\\?>\\n*|$)|<![A-Z][\\s\\S]*?(?:>\\n*|$)|<!\\[CDATA\\[[\\s\\S]*?(?:\\]\\]>\\n*|$)|</?(tag)(?: +|\\n|/?>)[\\s\\S]*?(?:(?:\\n *)+\\n|$)|<(?!script|pre|style|textarea)([a-z][\\w-]*)(?:attribute)*? */?>(?=[ \\t]*(?:\\n|$))[\\s\\S]*?(?:(?:\\n *)+\\n|$)|</(?!script|pre|style|textarea)[a-z][\\w-]*\\s*>(?=[ \\t]*(?:\\n|$))[\\s\\S]*?(?:(?:\\n *)+\\n|$))", "i").replace("comment", we).replace("tag", oe).replace("attribute", / +[a-zA-Z:_][\w.:-]*(?: *= *"[^"\n]*"| *= *'[^'\n]*'| *= *[^\s"'=<>`]+)?/).getRegex(), Qe = yt(ve).replace("hr", Zt).replace("heading", " {0,3}#{1,6}(?:\\s|$)").replace("|lheading", "").replace("|table", "").replace("blockquote", " {0,3}>").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list", " {0,3}(?:[*+-]|1[.)]) ").replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", oe).getRegex(), js = yt(/^( {0,3}> ?(paragraph|[^\n]*)(?:\n|$))+/).replace("paragraph", Qe).getRegex(), Ae = {
  blockquote: js,
  code: Hs,
  def: Gs,
  fences: zs,
  heading: Us,
  hr: Zt,
  html: qs,
  lheading: Ke,
  list: $s,
  newline: Bs,
  paragraph: Qe,
  table: Wt,
  text: Vs
}, _e = yt("^ *([^\\n ].*)\\n {0,3}((?:\\| *)?:?-+:? *(?:\\| *:?-+:? *)*(?:\\| *)?)(?:\\n((?:(?! *\\n|hr|heading|blockquote|code|fences|list|html).*(?:\\n|$))*)\\n*|$)").replace("hr", Zt).replace("heading", " {0,3}#{1,6}(?:\\s|$)").replace("blockquote", " {0,3}>").replace("code", " {4}[^\\n]").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list", " {0,3}(?:[*+-]|1[.)]) ").replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", oe).getRegex(), Xs = {
  ...Ae,
  table: _e,
  paragraph: yt(ve).replace("hr", Zt).replace("heading", " {0,3}#{1,6}(?:\\s|$)").replace("|lheading", "").replace("table", _e).replace("blockquote", " {0,3}>").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list", " {0,3}(?:[*+-]|1[.)]) ").replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", oe).getRegex()
}, Ys = {
  ...Ae,
  html: yt(`^ *(?:comment *(?:\\n|\\s*$)|<(tag)[\\s\\S]+?</\\1> *(?:\\n{2,}|\\s*$)|<tag(?:"[^"]*"|'[^']*'|\\s[^'"/>\\s]*)*?/?> *(?:\\n{2,}|\\s*$))`).replace("comment", we).replace(/tag/g, "(?!(?:a|em|strong|small|s|cite|q|dfn|abbr|data|time|code|var|samp|kbd|sub|sup|i|b|u|mark|ruby|rt|rp|bdi|bdo|span|br|wbr|ins|del|img)\\b)\\w+(?!:|[^\\w\\s@]*@)\\b").getRegex(),
  def: /^ *\[([^\]]+)\]: *<?([^\s>]+)>?(?: +(["(][^\n]+[")]))? *(?:\n+|$)/,
  heading: /^(#{1,6})(.*)(?:\n+|$)/,
  fences: Wt,
  // fences not supported
  lheading: /^(.+?)\n {0,3}(=+|-+) *(?:\n+|$)/,
  paragraph: yt(ve).replace("hr", Zt).replace("heading", ` *#{1,6} *[^
]`).replace("lheading", Ke).replace("|table", "").replace("blockquote", " {0,3}>").replace("|fences", "").replace("|list", "").replace("|html", "").replace("|tag", "").getRegex()
}, Je = /^\\([!"#$%&'()*+,\-./:;<=>?@\[\]\\^_`{|}~])/, Ws = /^(`+)([^`]|[^`][\s\S]*?[^`])\1(?!`)/, ts = /^( {2,}|\\)\n(?!\s*$)/, Zs = /^(`+|[^`])(?:(?= {2,}\n)|[\s\S]*?(?:(?=[\\<!\[`*_]|\b_|$)|[^ ](?= {2,}\n)))/, Kt = "\\p{P}\\p{S}", Ks = yt(/^((?![*_])[\spunctuation])/, "u").replace(/punctuation/g, Kt).getRegex(), Qs = /\[[^[\]]*?\]\([^\(\)]*?\)|`[^`]*?`|<[^<>]*?>/g, Js = yt(/^(?:\*+(?:((?!\*)[punct])|[^\s*]))|^_+(?:((?!_)[punct])|([^\s_]))/, "u").replace(/punct/g, Kt).getRegex(), ti = yt("^[^_*]*?__[^_*]*?\\*[^_*]*?(?=__)|[^*]+(?=[^*])|(?!\\*)[punct](\\*+)(?=[\\s]|$)|[^punct\\s](\\*+)(?!\\*)(?=[punct\\s]|$)|(?!\\*)[punct\\s](\\*+)(?=[^punct\\s])|[\\s](\\*+)(?!\\*)(?=[punct])|(?!\\*)[punct](\\*+)(?!\\*)(?=[punct])|[^punct\\s](\\*+)(?=[^punct\\s])", "gu").replace(/punct/g, Kt).getRegex(), ei = yt("^[^_*]*?\\*\\*[^_*]*?_[^_*]*?(?=\\*\\*)|[^_]+(?=[^_])|(?!_)[punct](_+)(?=[\\s]|$)|[^punct\\s](_+)(?!_)(?=[punct\\s]|$)|(?!_)[punct\\s](_+)(?=[^punct\\s])|[\\s](_+)(?!_)(?=[punct])|(?!_)[punct](_+)(?!_)(?=[punct])", "gu").replace(/punct/g, Kt).getRegex(), si = yt(/\\([punct])/, "gu").replace(/punct/g, Kt).getRegex(), ii = yt(/^<(scheme:[^\s\x00-\x1f<>]*|email)>/).replace("scheme", /[a-zA-Z][a-zA-Z0-9+.-]{1,31}/).replace("email", /[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+(@)[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)+(?![-_])/).getRegex(), ni = yt(we).replace("(?:-->|$)", "-->").getRegex(), ri = yt("^comment|^</[a-zA-Z][\\w:-]*\\s*>|^<[a-zA-Z][\\w-]*(?:attribute)*?\\s*/?>|^<\\?[\\s\\S]*?\\?>|^<![a-zA-Z]+\\s[\\s\\S]*?>|^<!\\[CDATA\\[[\\s\\S]*?\\]\\]>").replace("comment", ni).replace("attribute", /\s+[a-zA-Z:_][\w.:-]*(?:\s*=\s*"[^"]*"|\s*=\s*'[^']*'|\s*=\s*[^\s"'=<>`]+)?/).getRegex(), ne = /(?:\[(?:\\.|[^\[\]\\])*\]|\\.|`[^`]*`|[^\[\]\\`])*?/, ai = yt(/^!?\[(label)\]\(\s*(href)(?:\s+(title))?\s*\)/).replace("label", ne).replace("href", /<(?:\\.|[^\n<>\\])+>|[^\s\x00-\x1f]*/).replace("title", /"(?:\\"?|[^"\\])*"|'(?:\\'?|[^'\\])*'|\((?:\\\)?|[^)\\])*\)/).getRegex(), es = yt(/^!?\[(label)\]\[(ref)\]/).replace("label", ne).replace("ref", be).getRegex(), ss = yt(/^!?\[(ref)\](?:\[\])?/).replace("ref", be).getRegex(), oi = yt("reflink|nolink(?!\\()", "g").replace("reflink", es).replace("nolink", ss).getRegex(), ye = {
  _backpedal: Wt,
  // only used for GFM url
  anyPunctuation: si,
  autolink: ii,
  blockSkip: Qs,
  br: ts,
  code: Ws,
  del: Wt,
  emStrongLDelim: Js,
  emStrongRDelimAst: ti,
  emStrongRDelimUnd: ei,
  escape: Je,
  link: ai,
  nolink: ss,
  punctuation: Ks,
  reflink: es,
  reflinkSearch: oi,
  tag: ri,
  text: Zs,
  url: Wt
}, li = {
  ...ye,
  link: yt(/^!?\[(label)\]\((.*?)\)/).replace("label", ne).getRegex(),
  reflink: yt(/^!?\[(label)\]\s*\[([^\]]*)\]/).replace("label", ne).getRegex()
}, ge = {
  ...ye,
  escape: yt(Je).replace("])", "~|])").getRegex(),
  url: yt(/^((?:ftp|https?):\/\/|www\.)(?:[a-zA-Z0-9\-]+\.?)+[^\s<]*|^email/, "i").replace("email", /[A-Za-z0-9._+-]+(@)[a-zA-Z0-9-_]+(?:\.[a-zA-Z0-9-_]*[a-zA-Z0-9])+(?![-_])/).getRegex(),
  _backpedal: /(?:[^?!.,:;*_'"~()&]+|\([^)]*\)|&(?![a-zA-Z0-9]+;$)|[?!.,:;*_'"~)]+(?!$))+/,
  del: /^(~~?)(?=[^\s~])([\s\S]*?[^\s~])\1(?=[^~]|$)/,
  text: /^([`~]+|[^`~])(?:(?= {2,}\n)|(?=[a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-]+@)|[\s\S]*?(?:(?=[\\<!\[`*~_]|\b_|https?:\/\/|ftp:\/\/|www\.|$)|[^ ](?= {2,}\n)|[^a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-](?=[a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-]+@)))/
}, hi = {
  ...ge,
  br: yt(ts).replace("{2,}", "*").getRegex(),
  text: yt(ge.text).replace("\\b_", "\\b_| {2,}\\n").replace(/\{2,\}/g, "*").getRegex()
}, Jt = {
  normal: Ae,
  gfm: Xs,
  pedantic: Ys
}, Yt = {
  normal: ye,
  gfm: ge,
  breaks: hi,
  pedantic: li
};
class Mt {
  tokens;
  options;
  state;
  tokenizer;
  inlineQueue;
  constructor(l) {
    this.tokens = [], this.tokens.links = /* @__PURE__ */ Object.create(null), this.options = l || $t, this.options.tokenizer = this.options.tokenizer || new ie(), this.tokenizer = this.options.tokenizer, this.tokenizer.options = this.options, this.tokenizer.lexer = this, this.inlineQueue = [], this.state = {
      inLink: !1,
      inRawBlock: !1,
      top: !0
    };
    const a = {
      block: Jt.normal,
      inline: Yt.normal
    };
    this.options.pedantic ? (a.block = Jt.pedantic, a.inline = Yt.pedantic) : this.options.gfm && (a.block = Jt.gfm, this.options.breaks ? a.inline = Yt.breaks : a.inline = Yt.gfm), this.tokenizer.rules = a;
  }
  /**
   * Expose Rules
   */
  static get rules() {
    return {
      block: Jt,
      inline: Yt
    };
  }
  /**
   * Static Lex Method
   */
  static lex(l, a) {
    return new Mt(a).lex(l);
  }
  /**
   * Static Lex Inline Method
   */
  static lexInline(l, a) {
    return new Mt(a).inlineTokens(l);
  }
  /**
   * Preprocessing
   */
  lex(l) {
    l = l.replace(/\r\n|\r/g, `
`), this.blockTokens(l, this.tokens);
    for (let a = 0; a < this.inlineQueue.length; a++) {
      const s = this.inlineQueue[a];
      this.inlineTokens(s.src, s.tokens);
    }
    return this.inlineQueue = [], this.tokens;
  }
  blockTokens(l, a = []) {
    this.options.pedantic ? l = l.replace(/\t/g, "    ").replace(/^ +$/gm, "") : l = l.replace(/^( *)(\t+)/gm, (x, C, T) => C + "    ".repeat(T.length));
    let s, S, v, _;
    for (; l; )
      if (!(this.options.extensions && this.options.extensions.block && this.options.extensions.block.some((x) => (s = x.call({ lexer: this }, l, a)) ? (l = l.substring(s.raw.length), a.push(s), !0) : !1))) {
        if (s = this.tokenizer.space(l)) {
          l = l.substring(s.raw.length), s.raw.length === 1 && a.length > 0 ? a[a.length - 1].raw += `
` : a.push(s);
          continue;
        }
        if (s = this.tokenizer.code(l)) {
          l = l.substring(s.raw.length), S = a[a.length - 1], S && (S.type === "paragraph" || S.type === "text") ? (S.raw += `
` + s.raw, S.text += `
` + s.text, this.inlineQueue[this.inlineQueue.length - 1].src = S.text) : a.push(s);
          continue;
        }
        if (s = this.tokenizer.fences(l)) {
          l = l.substring(s.raw.length), a.push(s);
          continue;
        }
        if (s = this.tokenizer.heading(l)) {
          l = l.substring(s.raw.length), a.push(s);
          continue;
        }
        if (s = this.tokenizer.hr(l)) {
          l = l.substring(s.raw.length), a.push(s);
          continue;
        }
        if (s = this.tokenizer.blockquote(l)) {
          l = l.substring(s.raw.length), a.push(s);
          continue;
        }
        if (s = this.tokenizer.list(l)) {
          l = l.substring(s.raw.length), a.push(s);
          continue;
        }
        if (s = this.tokenizer.html(l)) {
          l = l.substring(s.raw.length), a.push(s);
          continue;
        }
        if (s = this.tokenizer.def(l)) {
          l = l.substring(s.raw.length), S = a[a.length - 1], S && (S.type === "paragraph" || S.type === "text") ? (S.raw += `
` + s.raw, S.text += `
` + s.raw, this.inlineQueue[this.inlineQueue.length - 1].src = S.text) : this.tokens.links[s.tag] || (this.tokens.links[s.tag] = {
            href: s.href,
            title: s.title
          });
          continue;
        }
        if (s = this.tokenizer.table(l)) {
          l = l.substring(s.raw.length), a.push(s);
          continue;
        }
        if (s = this.tokenizer.lheading(l)) {
          l = l.substring(s.raw.length), a.push(s);
          continue;
        }
        if (v = l, this.options.extensions && this.options.extensions.startBlock) {
          let x = 1 / 0;
          const C = l.slice(1);
          let T;
          this.options.extensions.startBlock.forEach((A) => {
            T = A.call({ lexer: this }, C), typeof T == "number" && T >= 0 && (x = Math.min(x, T));
          }), x < 1 / 0 && x >= 0 && (v = l.substring(0, x + 1));
        }
        if (this.state.top && (s = this.tokenizer.paragraph(v))) {
          S = a[a.length - 1], _ && S.type === "paragraph" ? (S.raw += `
` + s.raw, S.text += `
` + s.text, this.inlineQueue.pop(), this.inlineQueue[this.inlineQueue.length - 1].src = S.text) : a.push(s), _ = v.length !== l.length, l = l.substring(s.raw.length);
          continue;
        }
        if (s = this.tokenizer.text(l)) {
          l = l.substring(s.raw.length), S = a[a.length - 1], S && S.type === "text" ? (S.raw += `
` + s.raw, S.text += `
` + s.text, this.inlineQueue.pop(), this.inlineQueue[this.inlineQueue.length - 1].src = S.text) : a.push(s);
          continue;
        }
        if (l) {
          const x = "Infinite loop on byte: " + l.charCodeAt(0);
          if (this.options.silent) {
            console.error(x);
            break;
          } else
            throw new Error(x);
        }
      }
    return this.state.top = !0, a;
  }
  inline(l, a = []) {
    return this.inlineQueue.push({ src: l, tokens: a }), a;
  }
  /**
   * Lexing/Compiling
   */
  inlineTokens(l, a = []) {
    let s, S, v, _ = l, x, C, T;
    if (this.tokens.links) {
      const A = Object.keys(this.tokens.links);
      if (A.length > 0)
        for (; (x = this.tokenizer.rules.inline.reflinkSearch.exec(_)) != null; )
          A.includes(x[0].slice(x[0].lastIndexOf("[") + 1, -1)) && (_ = _.slice(0, x.index) + "[" + "a".repeat(x[0].length - 2) + "]" + _.slice(this.tokenizer.rules.inline.reflinkSearch.lastIndex));
    }
    for (; (x = this.tokenizer.rules.inline.blockSkip.exec(_)) != null; )
      _ = _.slice(0, x.index) + "[" + "a".repeat(x[0].length - 2) + "]" + _.slice(this.tokenizer.rules.inline.blockSkip.lastIndex);
    for (; (x = this.tokenizer.rules.inline.anyPunctuation.exec(_)) != null; )
      _ = _.slice(0, x.index) + "++" + _.slice(this.tokenizer.rules.inline.anyPunctuation.lastIndex);
    for (; l; )
      if (C || (T = ""), C = !1, !(this.options.extensions && this.options.extensions.inline && this.options.extensions.inline.some((A) => (s = A.call({ lexer: this }, l, a)) ? (l = l.substring(s.raw.length), a.push(s), !0) : !1))) {
        if (s = this.tokenizer.escape(l)) {
          l = l.substring(s.raw.length), a.push(s);
          continue;
        }
        if (s = this.tokenizer.tag(l)) {
          l = l.substring(s.raw.length), S = a[a.length - 1], S && s.type === "text" && S.type === "text" ? (S.raw += s.raw, S.text += s.text) : a.push(s);
          continue;
        }
        if (s = this.tokenizer.link(l)) {
          l = l.substring(s.raw.length), a.push(s);
          continue;
        }
        if (s = this.tokenizer.reflink(l, this.tokens.links)) {
          l = l.substring(s.raw.length), S = a[a.length - 1], S && s.type === "text" && S.type === "text" ? (S.raw += s.raw, S.text += s.text) : a.push(s);
          continue;
        }
        if (s = this.tokenizer.emStrong(l, _, T)) {
          l = l.substring(s.raw.length), a.push(s);
          continue;
        }
        if (s = this.tokenizer.codespan(l)) {
          l = l.substring(s.raw.length), a.push(s);
          continue;
        }
        if (s = this.tokenizer.br(l)) {
          l = l.substring(s.raw.length), a.push(s);
          continue;
        }
        if (s = this.tokenizer.del(l)) {
          l = l.substring(s.raw.length), a.push(s);
          continue;
        }
        if (s = this.tokenizer.autolink(l)) {
          l = l.substring(s.raw.length), a.push(s);
          continue;
        }
        if (!this.state.inLink && (s = this.tokenizer.url(l))) {
          l = l.substring(s.raw.length), a.push(s);
          continue;
        }
        if (v = l, this.options.extensions && this.options.extensions.startInline) {
          let A = 1 / 0;
          const n = l.slice(1);
          let f;
          this.options.extensions.startInline.forEach((p) => {
            f = p.call({ lexer: this }, n), typeof f == "number" && f >= 0 && (A = Math.min(A, f));
          }), A < 1 / 0 && A >= 0 && (v = l.substring(0, A + 1));
        }
        if (s = this.tokenizer.inlineText(v)) {
          l = l.substring(s.raw.length), s.raw.slice(-1) !== "_" && (T = s.raw.slice(-1)), C = !0, S = a[a.length - 1], S && S.type === "text" ? (S.raw += s.raw, S.text += s.text) : a.push(s);
          continue;
        }
        if (l) {
          const A = "Infinite loop on byte: " + l.charCodeAt(0);
          if (this.options.silent) {
            console.error(A);
            break;
          } else
            throw new Error(A);
        }
      }
    return a;
  }
}
class re {
  options;
  constructor(l) {
    this.options = l || $t;
  }
  code(l, a, s) {
    const S = (a || "").match(/^\S*/)?.[0];
    return l = l.replace(/\n$/, "") + `
`, S ? '<pre><code class="language-' + Lt(S) + '">' + (s ? l : Lt(l, !0)) + `</code></pre>
` : "<pre><code>" + (s ? l : Lt(l, !0)) + `</code></pre>
`;
  }
  blockquote(l) {
    return `<blockquote>
${l}</blockquote>
`;
  }
  html(l, a) {
    return l;
  }
  heading(l, a, s) {
    return `<h${a}>${l}</h${a}>
`;
  }
  hr() {
    return `<hr>
`;
  }
  list(l, a, s) {
    const S = a ? "ol" : "ul", v = a && s !== 1 ? ' start="' + s + '"' : "";
    return "<" + S + v + `>
` + l + "</" + S + `>
`;
  }
  listitem(l, a, s) {
    return `<li>${l}</li>
`;
  }
  checkbox(l) {
    return "<input " + (l ? 'checked="" ' : "") + 'disabled="" type="checkbox">';
  }
  paragraph(l) {
    return `<p>${l}</p>
`;
  }
  table(l, a) {
    return a && (a = `<tbody>${a}</tbody>`), `<table>
<thead>
` + l + `</thead>
` + a + `</table>
`;
  }
  tablerow(l) {
    return `<tr>
${l}</tr>
`;
  }
  tablecell(l, a) {
    const s = a.header ? "th" : "td";
    return (a.align ? `<${s} align="${a.align}">` : `<${s}>`) + l + `</${s}>
`;
  }
  /**
   * span level renderer
   */
  strong(l) {
    return `<strong>${l}</strong>`;
  }
  em(l) {
    return `<em>${l}</em>`;
  }
  codespan(l) {
    return `<code>${l}</code>`;
  }
  br() {
    return "<br>";
  }
  del(l) {
    return `<del>${l}</del>`;
  }
  link(l, a, s) {
    const S = Fe(l);
    if (S === null)
      return s;
    l = S;
    let v = '<a href="' + l + '"';
    return a && (v += ' title="' + a + '"'), v += ">" + s + "</a>", v;
  }
  image(l, a, s) {
    const S = Fe(l);
    if (S === null)
      return s;
    l = S;
    let v = `<img src="${l}" alt="${s}"`;
    return a && (v += ` title="${a}"`), v += ">", v;
  }
  text(l) {
    return l;
  }
}
class xe {
  // no need for block level renderers
  strong(l) {
    return l;
  }
  em(l) {
    return l;
  }
  codespan(l) {
    return l;
  }
  del(l) {
    return l;
  }
  html(l) {
    return l;
  }
  text(l) {
    return l;
  }
  link(l, a, s) {
    return "" + s;
  }
  image(l, a, s) {
    return "" + s;
  }
  br() {
    return "";
  }
}
class Pt {
  options;
  renderer;
  textRenderer;
  constructor(l) {
    this.options = l || $t, this.options.renderer = this.options.renderer || new re(), this.renderer = this.options.renderer, this.renderer.options = this.options, this.textRenderer = new xe();
  }
  /**
   * Static Parse Method
   */
  static parse(l, a) {
    return new Pt(a).parse(l);
  }
  /**
   * Static Parse Inline Method
   */
  static parseInline(l, a) {
    return new Pt(a).parseInline(l);
  }
  /**
   * Parse Loop
   */
  parse(l, a = !0) {
    let s = "";
    for (let S = 0; S < l.length; S++) {
      const v = l[S];
      if (this.options.extensions && this.options.extensions.renderers && this.options.extensions.renderers[v.type]) {
        const _ = v, x = this.options.extensions.renderers[_.type].call({ parser: this }, _);
        if (x !== !1 || !["space", "hr", "heading", "code", "table", "blockquote", "list", "html", "paragraph", "text"].includes(_.type)) {
          s += x || "";
          continue;
        }
      }
      switch (v.type) {
        case "space":
          continue;
        case "hr": {
          s += this.renderer.hr();
          continue;
        }
        case "heading": {
          const _ = v;
          s += this.renderer.heading(this.parseInline(_.tokens), _.depth, Ms(this.parseInline(_.tokens, this.textRenderer)));
          continue;
        }
        case "code": {
          const _ = v;
          s += this.renderer.code(_.text, _.lang, !!_.escaped);
          continue;
        }
        case "table": {
          const _ = v;
          let x = "", C = "";
          for (let A = 0; A < _.header.length; A++)
            C += this.renderer.tablecell(this.parseInline(_.header[A].tokens), { header: !0, align: _.align[A] });
          x += this.renderer.tablerow(C);
          let T = "";
          for (let A = 0; A < _.rows.length; A++) {
            const n = _.rows[A];
            C = "";
            for (let f = 0; f < n.length; f++)
              C += this.renderer.tablecell(this.parseInline(n[f].tokens), { header: !1, align: _.align[f] });
            T += this.renderer.tablerow(C);
          }
          s += this.renderer.table(x, T);
          continue;
        }
        case "blockquote": {
          const _ = v, x = this.parse(_.tokens);
          s += this.renderer.blockquote(x);
          continue;
        }
        case "list": {
          const _ = v, x = _.ordered, C = _.start, T = _.loose;
          let A = "";
          for (let n = 0; n < _.items.length; n++) {
            const f = _.items[n], p = f.checked, F = f.task;
            let r = "";
            if (f.task) {
              const w = this.renderer.checkbox(!!p);
              T ? f.tokens.length > 0 && f.tokens[0].type === "paragraph" ? (f.tokens[0].text = w + " " + f.tokens[0].text, f.tokens[0].tokens && f.tokens[0].tokens.length > 0 && f.tokens[0].tokens[0].type === "text" && (f.tokens[0].tokens[0].text = w + " " + f.tokens[0].tokens[0].text)) : f.tokens.unshift({
                type: "text",
                text: w + " "
              }) : r += w + " ";
            }
            r += this.parse(f.tokens, T), A += this.renderer.listitem(r, F, !!p);
          }
          s += this.renderer.list(A, x, C);
          continue;
        }
        case "html": {
          const _ = v;
          s += this.renderer.html(_.text, _.block);
          continue;
        }
        case "paragraph": {
          const _ = v;
          s += this.renderer.paragraph(this.parseInline(_.tokens));
          continue;
        }
        case "text": {
          let _ = v, x = _.tokens ? this.parseInline(_.tokens) : _.text;
          for (; S + 1 < l.length && l[S + 1].type === "text"; )
            _ = l[++S], x += `
` + (_.tokens ? this.parseInline(_.tokens) : _.text);
          s += a ? this.renderer.paragraph(x) : x;
          continue;
        }
        default: {
          const _ = 'Token with "' + v.type + '" type was not found.';
          if (this.options.silent)
            return console.error(_), "";
          throw new Error(_);
        }
      }
    }
    return s;
  }
  /**
   * Parse Inline Tokens
   */
  parseInline(l, a) {
    a = a || this.renderer;
    let s = "";
    for (let S = 0; S < l.length; S++) {
      const v = l[S];
      if (this.options.extensions && this.options.extensions.renderers && this.options.extensions.renderers[v.type]) {
        const _ = this.options.extensions.renderers[v.type].call({ parser: this }, v);
        if (_ !== !1 || !["escape", "html", "link", "image", "strong", "em", "codespan", "br", "del", "text"].includes(v.type)) {
          s += _ || "";
          continue;
        }
      }
      switch (v.type) {
        case "escape": {
          const _ = v;
          s += a.text(_.text);
          break;
        }
        case "html": {
          const _ = v;
          s += a.html(_.text);
          break;
        }
        case "link": {
          const _ = v;
          s += a.link(_.href, _.title, this.parseInline(_.tokens, a));
          break;
        }
        case "image": {
          const _ = v;
          s += a.image(_.href, _.title, _.text);
          break;
        }
        case "strong": {
          const _ = v;
          s += a.strong(this.parseInline(_.tokens, a));
          break;
        }
        case "em": {
          const _ = v;
          s += a.em(this.parseInline(_.tokens, a));
          break;
        }
        case "codespan": {
          const _ = v;
          s += a.codespan(_.text);
          break;
        }
        case "br": {
          s += a.br();
          break;
        }
        case "del": {
          const _ = v;
          s += a.del(this.parseInline(_.tokens, a));
          break;
        }
        case "text": {
          const _ = v;
          s += a.text(_.text);
          break;
        }
        default: {
          const _ = 'Token with "' + v.type + '" type was not found.';
          if (this.options.silent)
            return console.error(_), "";
          throw new Error(_);
        }
      }
    }
    return s;
  }
}
class ee {
  options;
  constructor(l) {
    this.options = l || $t;
  }
  static passThroughHooks = /* @__PURE__ */ new Set([
    "preprocess",
    "postprocess",
    "processAllTokens"
  ]);
  /**
   * Process markdown before marked
   */
  preprocess(l) {
    return l;
  }
  /**
   * Process HTML after marked is finished
   */
  postprocess(l) {
    return l;
  }
  /**
   * Process all tokens before walk tokens
   */
  processAllTokens(l) {
    return l;
  }
}
class ci {
  defaults = me();
  options = this.setOptions;
  parse = this.#t(Mt.lex, Pt.parse);
  parseInline = this.#t(Mt.lexInline, Pt.parseInline);
  Parser = Pt;
  Renderer = re;
  TextRenderer = xe;
  Lexer = Mt;
  Tokenizer = ie;
  Hooks = ee;
  constructor(...l) {
    this.use(...l);
  }
  /**
   * Run callback for every token
   */
  walkTokens(l, a) {
    let s = [];
    for (const S of l)
      switch (s = s.concat(a.call(this, S)), S.type) {
        case "table": {
          const v = S;
          for (const _ of v.header)
            s = s.concat(this.walkTokens(_.tokens, a));
          for (const _ of v.rows)
            for (const x of _)
              s = s.concat(this.walkTokens(x.tokens, a));
          break;
        }
        case "list": {
          const v = S;
          s = s.concat(this.walkTokens(v.items, a));
          break;
        }
        default: {
          const v = S;
          this.defaults.extensions?.childTokens?.[v.type] ? this.defaults.extensions.childTokens[v.type].forEach((_) => {
            const x = v[_].flat(1 / 0);
            s = s.concat(this.walkTokens(x, a));
          }) : v.tokens && (s = s.concat(this.walkTokens(v.tokens, a)));
        }
      }
    return s;
  }
  use(...l) {
    const a = this.defaults.extensions || { renderers: {}, childTokens: {} };
    return l.forEach((s) => {
      const S = { ...s };
      if (S.async = this.defaults.async || S.async || !1, s.extensions && (s.extensions.forEach((v) => {
        if (!v.name)
          throw new Error("extension name required");
        if ("renderer" in v) {
          const _ = a.renderers[v.name];
          _ ? a.renderers[v.name] = function(...x) {
            let C = v.renderer.apply(this, x);
            return C === !1 && (C = _.apply(this, x)), C;
          } : a.renderers[v.name] = v.renderer;
        }
        if ("tokenizer" in v) {
          if (!v.level || v.level !== "block" && v.level !== "inline")
            throw new Error("extension level must be 'block' or 'inline'");
          const _ = a[v.level];
          _ ? _.unshift(v.tokenizer) : a[v.level] = [v.tokenizer], v.start && (v.level === "block" ? a.startBlock ? a.startBlock.push(v.start) : a.startBlock = [v.start] : v.level === "inline" && (a.startInline ? a.startInline.push(v.start) : a.startInline = [v.start]));
        }
        "childTokens" in v && v.childTokens && (a.childTokens[v.name] = v.childTokens);
      }), S.extensions = a), s.renderer) {
        const v = this.defaults.renderer || new re(this.defaults);
        for (const _ in s.renderer) {
          if (!(_ in v))
            throw new Error(`renderer '${_}' does not exist`);
          if (_ === "options")
            continue;
          const x = _, C = s.renderer[x], T = v[x];
          v[x] = (...A) => {
            let n = C.apply(v, A);
            return n === !1 && (n = T.apply(v, A)), n || "";
          };
        }
        S.renderer = v;
      }
      if (s.tokenizer) {
        const v = this.defaults.tokenizer || new ie(this.defaults);
        for (const _ in s.tokenizer) {
          if (!(_ in v))
            throw new Error(`tokenizer '${_}' does not exist`);
          if (["options", "rules", "lexer"].includes(_))
            continue;
          const x = _, C = s.tokenizer[x], T = v[x];
          v[x] = (...A) => {
            let n = C.apply(v, A);
            return n === !1 && (n = T.apply(v, A)), n;
          };
        }
        S.tokenizer = v;
      }
      if (s.hooks) {
        const v = this.defaults.hooks || new ee();
        for (const _ in s.hooks) {
          if (!(_ in v))
            throw new Error(`hook '${_}' does not exist`);
          if (_ === "options")
            continue;
          const x = _, C = s.hooks[x], T = v[x];
          ee.passThroughHooks.has(_) ? v[x] = (A) => {
            if (this.defaults.async)
              return Promise.resolve(C.call(v, A)).then((f) => T.call(v, f));
            const n = C.call(v, A);
            return T.call(v, n);
          } : v[x] = (...A) => {
            let n = C.apply(v, A);
            return n === !1 && (n = T.apply(v, A)), n;
          };
        }
        S.hooks = v;
      }
      if (s.walkTokens) {
        const v = this.defaults.walkTokens, _ = s.walkTokens;
        S.walkTokens = function(x) {
          let C = [];
          return C.push(_.call(this, x)), v && (C = C.concat(v.call(this, x))), C;
        };
      }
      this.defaults = { ...this.defaults, ...S };
    }), this;
  }
  setOptions(l) {
    return this.defaults = { ...this.defaults, ...l }, this;
  }
  lexer(l, a) {
    return Mt.lex(l, a ?? this.defaults);
  }
  parser(l, a) {
    return Pt.parse(l, a ?? this.defaults);
  }
  #t(l, a) {
    return (s, S) => {
      const v = { ...S }, _ = { ...this.defaults, ...v };
      this.defaults.async === !0 && v.async === !1 && (_.silent || console.warn("marked(): The async option was set to true by an extension. The async: false option sent to parse will be ignored."), _.async = !0);
      const x = this.#e(!!_.silent, !!_.async);
      if (typeof s > "u" || s === null)
        return x(new Error("marked(): input parameter is undefined or null"));
      if (typeof s != "string")
        return x(new Error("marked(): input parameter is of type " + Object.prototype.toString.call(s) + ", string expected"));
      if (_.hooks && (_.hooks.options = _), _.async)
        return Promise.resolve(_.hooks ? _.hooks.preprocess(s) : s).then((C) => l(C, _)).then((C) => _.hooks ? _.hooks.processAllTokens(C) : C).then((C) => _.walkTokens ? Promise.all(this.walkTokens(C, _.walkTokens)).then(() => C) : C).then((C) => a(C, _)).then((C) => _.hooks ? _.hooks.postprocess(C) : C).catch(x);
      try {
        _.hooks && (s = _.hooks.preprocess(s));
        let C = l(s, _);
        _.hooks && (C = _.hooks.processAllTokens(C)), _.walkTokens && this.walkTokens(C, _.walkTokens);
        let T = a(C, _);
        return _.hooks && (T = _.hooks.postprocess(T)), T;
      } catch (C) {
        return x(C);
      }
    };
  }
  #e(l, a) {
    return (s) => {
      if (s.message += `
Please report this to https://github.com/markedjs/marked.`, l) {
        const S = "<p>An error occurred:</p><pre>" + Lt(s.message + "", !0) + "</pre>";
        return a ? Promise.resolve(S) : S;
      }
      if (a)
        return Promise.reject(s);
      throw s;
    };
  }
}
const Gt = new ci();
function At(V, l) {
  return Gt.parse(V, l);
}
At.options = At.setOptions = function(V) {
  return Gt.setOptions(V), At.defaults = Gt.defaults, Xe(At.defaults), At;
};
At.getDefaults = me;
At.defaults = $t;
At.use = function(...V) {
  return Gt.use(...V), At.defaults = Gt.defaults, Xe(At.defaults), At;
};
At.walkTokens = function(V, l) {
  return Gt.walkTokens(V, l);
};
At.parseInline = Gt.parseInline;
At.Parser = Pt;
At.parser = Pt.parse;
At.Renderer = re;
At.TextRenderer = xe;
At.Lexer = Mt;
At.lexer = Mt.lex;
At.Tokenizer = ie;
At.Hooks = ee;
At.parse = At;
At.options;
At.setOptions;
At.use;
At.walkTokens;
At.parseInline;
Pt.parse;
Mt.lex;
const ui = /[\0-\x1F!-,\.\/:-@\[-\^`\{-\xA9\xAB-\xB4\xB6-\xB9\xBB-\xBF\xD7\xF7\u02C2-\u02C5\u02D2-\u02DF\u02E5-\u02EB\u02ED\u02EF-\u02FF\u0375\u0378\u0379\u037E\u0380-\u0385\u0387\u038B\u038D\u03A2\u03F6\u0482\u0530\u0557\u0558\u055A-\u055F\u0589-\u0590\u05BE\u05C0\u05C3\u05C6\u05C8-\u05CF\u05EB-\u05EE\u05F3-\u060F\u061B-\u061F\u066A-\u066D\u06D4\u06DD\u06DE\u06E9\u06FD\u06FE\u0700-\u070F\u074B\u074C\u07B2-\u07BF\u07F6-\u07F9\u07FB\u07FC\u07FE\u07FF\u082E-\u083F\u085C-\u085F\u086B-\u089F\u08B5\u08C8-\u08D2\u08E2\u0964\u0965\u0970\u0984\u098D\u098E\u0991\u0992\u09A9\u09B1\u09B3-\u09B5\u09BA\u09BB\u09C5\u09C6\u09C9\u09CA\u09CF-\u09D6\u09D8-\u09DB\u09DE\u09E4\u09E5\u09F2-\u09FB\u09FD\u09FF\u0A00\u0A04\u0A0B-\u0A0E\u0A11\u0A12\u0A29\u0A31\u0A34\u0A37\u0A3A\u0A3B\u0A3D\u0A43-\u0A46\u0A49\u0A4A\u0A4E-\u0A50\u0A52-\u0A58\u0A5D\u0A5F-\u0A65\u0A76-\u0A80\u0A84\u0A8E\u0A92\u0AA9\u0AB1\u0AB4\u0ABA\u0ABB\u0AC6\u0ACA\u0ACE\u0ACF\u0AD1-\u0ADF\u0AE4\u0AE5\u0AF0-\u0AF8\u0B00\u0B04\u0B0D\u0B0E\u0B11\u0B12\u0B29\u0B31\u0B34\u0B3A\u0B3B\u0B45\u0B46\u0B49\u0B4A\u0B4E-\u0B54\u0B58-\u0B5B\u0B5E\u0B64\u0B65\u0B70\u0B72-\u0B81\u0B84\u0B8B-\u0B8D\u0B91\u0B96-\u0B98\u0B9B\u0B9D\u0BA0-\u0BA2\u0BA5-\u0BA7\u0BAB-\u0BAD\u0BBA-\u0BBD\u0BC3-\u0BC5\u0BC9\u0BCE\u0BCF\u0BD1-\u0BD6\u0BD8-\u0BE5\u0BF0-\u0BFF\u0C0D\u0C11\u0C29\u0C3A-\u0C3C\u0C45\u0C49\u0C4E-\u0C54\u0C57\u0C5B-\u0C5F\u0C64\u0C65\u0C70-\u0C7F\u0C84\u0C8D\u0C91\u0CA9\u0CB4\u0CBA\u0CBB\u0CC5\u0CC9\u0CCE-\u0CD4\u0CD7-\u0CDD\u0CDF\u0CE4\u0CE5\u0CF0\u0CF3-\u0CFF\u0D0D\u0D11\u0D45\u0D49\u0D4F-\u0D53\u0D58-\u0D5E\u0D64\u0D65\u0D70-\u0D79\u0D80\u0D84\u0D97-\u0D99\u0DB2\u0DBC\u0DBE\u0DBF\u0DC7-\u0DC9\u0DCB-\u0DCE\u0DD5\u0DD7\u0DE0-\u0DE5\u0DF0\u0DF1\u0DF4-\u0E00\u0E3B-\u0E3F\u0E4F\u0E5A-\u0E80\u0E83\u0E85\u0E8B\u0EA4\u0EA6\u0EBE\u0EBF\u0EC5\u0EC7\u0ECE\u0ECF\u0EDA\u0EDB\u0EE0-\u0EFF\u0F01-\u0F17\u0F1A-\u0F1F\u0F2A-\u0F34\u0F36\u0F38\u0F3A-\u0F3D\u0F48\u0F6D-\u0F70\u0F85\u0F98\u0FBD-\u0FC5\u0FC7-\u0FFF\u104A-\u104F\u109E\u109F\u10C6\u10C8-\u10CC\u10CE\u10CF\u10FB\u1249\u124E\u124F\u1257\u1259\u125E\u125F\u1289\u128E\u128F\u12B1\u12B6\u12B7\u12BF\u12C1\u12C6\u12C7\u12D7\u1311\u1316\u1317\u135B\u135C\u1360-\u137F\u1390-\u139F\u13F6\u13F7\u13FE-\u1400\u166D\u166E\u1680\u169B-\u169F\u16EB-\u16ED\u16F9-\u16FF\u170D\u1715-\u171F\u1735-\u173F\u1754-\u175F\u176D\u1771\u1774-\u177F\u17D4-\u17D6\u17D8-\u17DB\u17DE\u17DF\u17EA-\u180A\u180E\u180F\u181A-\u181F\u1879-\u187F\u18AB-\u18AF\u18F6-\u18FF\u191F\u192C-\u192F\u193C-\u1945\u196E\u196F\u1975-\u197F\u19AC-\u19AF\u19CA-\u19CF\u19DA-\u19FF\u1A1C-\u1A1F\u1A5F\u1A7D\u1A7E\u1A8A-\u1A8F\u1A9A-\u1AA6\u1AA8-\u1AAF\u1AC1-\u1AFF\u1B4C-\u1B4F\u1B5A-\u1B6A\u1B74-\u1B7F\u1BF4-\u1BFF\u1C38-\u1C3F\u1C4A-\u1C4C\u1C7E\u1C7F\u1C89-\u1C8F\u1CBB\u1CBC\u1CC0-\u1CCF\u1CD3\u1CFB-\u1CFF\u1DFA\u1F16\u1F17\u1F1E\u1F1F\u1F46\u1F47\u1F4E\u1F4F\u1F58\u1F5A\u1F5C\u1F5E\u1F7E\u1F7F\u1FB5\u1FBD\u1FBF-\u1FC1\u1FC5\u1FCD-\u1FCF\u1FD4\u1FD5\u1FDC-\u1FDF\u1FED-\u1FF1\u1FF5\u1FFD-\u203E\u2041-\u2053\u2055-\u2070\u2072-\u207E\u2080-\u208F\u209D-\u20CF\u20F1-\u2101\u2103-\u2106\u2108\u2109\u2114\u2116-\u2118\u211E-\u2123\u2125\u2127\u2129\u212E\u213A\u213B\u2140-\u2144\u214A-\u214D\u214F-\u215F\u2189-\u24B5\u24EA-\u2BFF\u2C2F\u2C5F\u2CE5-\u2CEA\u2CF4-\u2CFF\u2D26\u2D28-\u2D2C\u2D2E\u2D2F\u2D68-\u2D6E\u2D70-\u2D7E\u2D97-\u2D9F\u2DA7\u2DAF\u2DB7\u2DBF\u2DC7\u2DCF\u2DD7\u2DDF\u2E00-\u2E2E\u2E30-\u3004\u3008-\u3020\u3030\u3036\u3037\u303D-\u3040\u3097\u3098\u309B\u309C\u30A0\u30FB\u3100-\u3104\u3130\u318F-\u319F\u31C0-\u31EF\u3200-\u33FF\u4DC0-\u4DFF\u9FFD-\u9FFF\uA48D-\uA4CF\uA4FE\uA4FF\uA60D-\uA60F\uA62C-\uA63F\uA673\uA67E\uA6F2-\uA716\uA720\uA721\uA789\uA78A\uA7C0\uA7C1\uA7CB-\uA7F4\uA828-\uA82B\uA82D-\uA83F\uA874-\uA87F\uA8C6-\uA8CF\uA8DA-\uA8DF\uA8F8-\uA8FA\uA8FC\uA92E\uA92F\uA954-\uA95F\uA97D-\uA97F\uA9C1-\uA9CE\uA9DA-\uA9DF\uA9FF\uAA37-\uAA3F\uAA4E\uAA4F\uAA5A-\uAA5F\uAA77-\uAA79\uAAC3-\uAADA\uAADE\uAADF\uAAF0\uAAF1\uAAF7-\uAB00\uAB07\uAB08\uAB0F\uAB10\uAB17-\uAB1F\uAB27\uAB2F\uAB5B\uAB6A-\uAB6F\uABEB\uABEE\uABEF\uABFA-\uABFF\uD7A4-\uD7AF\uD7C7-\uD7CA\uD7FC-\uD7FF\uE000-\uF8FF\uFA6E\uFA6F\uFADA-\uFAFF\uFB07-\uFB12\uFB18-\uFB1C\uFB29\uFB37\uFB3D\uFB3F\uFB42\uFB45\uFBB2-\uFBD2\uFD3E-\uFD4F\uFD90\uFD91\uFDC8-\uFDEF\uFDFC-\uFDFF\uFE10-\uFE1F\uFE30-\uFE32\uFE35-\uFE4C\uFE50-\uFE6F\uFE75\uFEFD-\uFF0F\uFF1A-\uFF20\uFF3B-\uFF3E\uFF40\uFF5B-\uFF65\uFFBF-\uFFC1\uFFC8\uFFC9\uFFD0\uFFD1\uFFD8\uFFD9\uFFDD-\uFFFF]|\uD800[\uDC0C\uDC27\uDC3B\uDC3E\uDC4E\uDC4F\uDC5E-\uDC7F\uDCFB-\uDD3F\uDD75-\uDDFC\uDDFE-\uDE7F\uDE9D-\uDE9F\uDED1-\uDEDF\uDEE1-\uDEFF\uDF20-\uDF2C\uDF4B-\uDF4F\uDF7B-\uDF7F\uDF9E\uDF9F\uDFC4-\uDFC7\uDFD0\uDFD6-\uDFFF]|\uD801[\uDC9E\uDC9F\uDCAA-\uDCAF\uDCD4-\uDCD7\uDCFC-\uDCFF\uDD28-\uDD2F\uDD64-\uDDFF\uDF37-\uDF3F\uDF56-\uDF5F\uDF68-\uDFFF]|\uD802[\uDC06\uDC07\uDC09\uDC36\uDC39-\uDC3B\uDC3D\uDC3E\uDC56-\uDC5F\uDC77-\uDC7F\uDC9F-\uDCDF\uDCF3\uDCF6-\uDCFF\uDD16-\uDD1F\uDD3A-\uDD7F\uDDB8-\uDDBD\uDDC0-\uDDFF\uDE04\uDE07-\uDE0B\uDE14\uDE18\uDE36\uDE37\uDE3B-\uDE3E\uDE40-\uDE5F\uDE7D-\uDE7F\uDE9D-\uDEBF\uDEC8\uDEE7-\uDEFF\uDF36-\uDF3F\uDF56-\uDF5F\uDF73-\uDF7F\uDF92-\uDFFF]|\uD803[\uDC49-\uDC7F\uDCB3-\uDCBF\uDCF3-\uDCFF\uDD28-\uDD2F\uDD3A-\uDE7F\uDEAA\uDEAD-\uDEAF\uDEB2-\uDEFF\uDF1D-\uDF26\uDF28-\uDF2F\uDF51-\uDFAF\uDFC5-\uDFDF\uDFF7-\uDFFF]|\uD804[\uDC47-\uDC65\uDC70-\uDC7E\uDCBB-\uDCCF\uDCE9-\uDCEF\uDCFA-\uDCFF\uDD35\uDD40-\uDD43\uDD48-\uDD4F\uDD74\uDD75\uDD77-\uDD7F\uDDC5-\uDDC8\uDDCD\uDDDB\uDDDD-\uDDFF\uDE12\uDE38-\uDE3D\uDE3F-\uDE7F\uDE87\uDE89\uDE8E\uDE9E\uDEA9-\uDEAF\uDEEB-\uDEEF\uDEFA-\uDEFF\uDF04\uDF0D\uDF0E\uDF11\uDF12\uDF29\uDF31\uDF34\uDF3A\uDF45\uDF46\uDF49\uDF4A\uDF4E\uDF4F\uDF51-\uDF56\uDF58-\uDF5C\uDF64\uDF65\uDF6D-\uDF6F\uDF75-\uDFFF]|\uD805[\uDC4B-\uDC4F\uDC5A-\uDC5D\uDC62-\uDC7F\uDCC6\uDCC8-\uDCCF\uDCDA-\uDD7F\uDDB6\uDDB7\uDDC1-\uDDD7\uDDDE-\uDDFF\uDE41-\uDE43\uDE45-\uDE4F\uDE5A-\uDE7F\uDEB9-\uDEBF\uDECA-\uDEFF\uDF1B\uDF1C\uDF2C-\uDF2F\uDF3A-\uDFFF]|\uD806[\uDC3B-\uDC9F\uDCEA-\uDCFE\uDD07\uDD08\uDD0A\uDD0B\uDD14\uDD17\uDD36\uDD39\uDD3A\uDD44-\uDD4F\uDD5A-\uDD9F\uDDA8\uDDA9\uDDD8\uDDD9\uDDE2\uDDE5-\uDDFF\uDE3F-\uDE46\uDE48-\uDE4F\uDE9A-\uDE9C\uDE9E-\uDEBF\uDEF9-\uDFFF]|\uD807[\uDC09\uDC37\uDC41-\uDC4F\uDC5A-\uDC71\uDC90\uDC91\uDCA8\uDCB7-\uDCFF\uDD07\uDD0A\uDD37-\uDD39\uDD3B\uDD3E\uDD48-\uDD4F\uDD5A-\uDD5F\uDD66\uDD69\uDD8F\uDD92\uDD99-\uDD9F\uDDAA-\uDEDF\uDEF7-\uDFAF\uDFB1-\uDFFF]|\uD808[\uDF9A-\uDFFF]|\uD809[\uDC6F-\uDC7F\uDD44-\uDFFF]|[\uD80A\uD80B\uD80E-\uD810\uD812-\uD819\uD824-\uD82B\uD82D\uD82E\uD830-\uD833\uD837\uD839\uD83D\uD83F\uD87B-\uD87D\uD87F\uD885-\uDB3F\uDB41-\uDBFF][\uDC00-\uDFFF]|\uD80D[\uDC2F-\uDFFF]|\uD811[\uDE47-\uDFFF]|\uD81A[\uDE39-\uDE3F\uDE5F\uDE6A-\uDECF\uDEEE\uDEEF\uDEF5-\uDEFF\uDF37-\uDF3F\uDF44-\uDF4F\uDF5A-\uDF62\uDF78-\uDF7C\uDF90-\uDFFF]|\uD81B[\uDC00-\uDE3F\uDE80-\uDEFF\uDF4B-\uDF4E\uDF88-\uDF8E\uDFA0-\uDFDF\uDFE2\uDFE5-\uDFEF\uDFF2-\uDFFF]|\uD821[\uDFF8-\uDFFF]|\uD823[\uDCD6-\uDCFF\uDD09-\uDFFF]|\uD82C[\uDD1F-\uDD4F\uDD53-\uDD63\uDD68-\uDD6F\uDEFC-\uDFFF]|\uD82F[\uDC6B-\uDC6F\uDC7D-\uDC7F\uDC89-\uDC8F\uDC9A-\uDC9C\uDC9F-\uDFFF]|\uD834[\uDC00-\uDD64\uDD6A-\uDD6C\uDD73-\uDD7A\uDD83\uDD84\uDD8C-\uDDA9\uDDAE-\uDE41\uDE45-\uDFFF]|\uD835[\uDC55\uDC9D\uDCA0\uDCA1\uDCA3\uDCA4\uDCA7\uDCA8\uDCAD\uDCBA\uDCBC\uDCC4\uDD06\uDD0B\uDD0C\uDD15\uDD1D\uDD3A\uDD3F\uDD45\uDD47-\uDD49\uDD51\uDEA6\uDEA7\uDEC1\uDEDB\uDEFB\uDF15\uDF35\uDF4F\uDF6F\uDF89\uDFA9\uDFC3\uDFCC\uDFCD]|\uD836[\uDC00-\uDDFF\uDE37-\uDE3A\uDE6D-\uDE74\uDE76-\uDE83\uDE85-\uDE9A\uDEA0\uDEB0-\uDFFF]|\uD838[\uDC07\uDC19\uDC1A\uDC22\uDC25\uDC2B-\uDCFF\uDD2D-\uDD2F\uDD3E\uDD3F\uDD4A-\uDD4D\uDD4F-\uDEBF\uDEFA-\uDFFF]|\uD83A[\uDCC5-\uDCCF\uDCD7-\uDCFF\uDD4C-\uDD4F\uDD5A-\uDFFF]|\uD83B[\uDC00-\uDDFF\uDE04\uDE20\uDE23\uDE25\uDE26\uDE28\uDE33\uDE38\uDE3A\uDE3C-\uDE41\uDE43-\uDE46\uDE48\uDE4A\uDE4C\uDE50\uDE53\uDE55\uDE56\uDE58\uDE5A\uDE5C\uDE5E\uDE60\uDE63\uDE65\uDE66\uDE6B\uDE73\uDE78\uDE7D\uDE7F\uDE8A\uDE9C-\uDEA0\uDEA4\uDEAA\uDEBC-\uDFFF]|\uD83C[\uDC00-\uDD2F\uDD4A-\uDD4F\uDD6A-\uDD6F\uDD8A-\uDFFF]|\uD83E[\uDC00-\uDFEF\uDFFA-\uDFFF]|\uD869[\uDEDE-\uDEFF]|\uD86D[\uDF35-\uDF3F]|\uD86E[\uDC1E\uDC1F]|\uD873[\uDEA2-\uDEAF]|\uD87A[\uDFE1-\uDFFF]|\uD87E[\uDE1E-\uDFFF]|\uD884[\uDF4B-\uDFFF]|\uDB40[\uDC00-\uDCFF\uDDF0-\uDFFF]/g, di = Object.hasOwnProperty;
class is {
  /**
   * Create a new slug class.
   */
  constructor() {
    this.occurrences, this.reset();
  }
  /**
   * Generate a unique slug.
  *
  * Tracks previously generated slugs: repeated calls with the same value
  * will result in different slugs.
  * Use the `slug` function to get same slugs.
   *
   * @param  {string} value
   *   String of text to slugify
   * @param  {boolean} [maintainCase=false]
   *   Keep the current case, otherwise make all lowercase
   * @return {string}
   *   A unique slug string
   */
  slug(l, a) {
    const s = this;
    let S = fi(l, a === !0);
    const v = S;
    for (; di.call(s.occurrences, S); )
      s.occurrences[v]++, S = v + "-" + s.occurrences[v];
    return s.occurrences[S] = 0, S;
  }
  /**
   * Reset - Forget all previous slugs
   *
   * @return void
   */
  reset() {
    this.occurrences = /* @__PURE__ */ Object.create(null);
  }
}
function fi(V, l) {
  return typeof V != "string" ? "" : (l || (V = V.toLowerCase()), V.replace(ui, "").replace(/ /g, "-"));
}
new is();
var Re = typeof globalThis < "u" ? globalThis : typeof window < "u" ? window : typeof global < "u" ? global : typeof self < "u" ? self : {}, ce = { exports: {} }, Le;
function pi() {
  return Le || (Le = 1, (function(V) {
    var l = typeof window < "u" ? window : typeof WorkerGlobalScope < "u" && self instanceof WorkerGlobalScope ? self : {};
    var a = (function(s) {
      var S = /(?:^|\s)lang(?:uage)?-([\w-]+)(?=\s|$)/i, v = 0, _ = {}, x = {
        /**
         * By default, Prism will attempt to highlight all code elements (by calling {@link Prism.highlightAll}) on the
         * current page after the page finished loading. This might be a problem if e.g. you wanted to asynchronously load
         * additional languages or plugins yourself.
         *
         * By setting this value to `true`, Prism will not automatically highlight all code elements on the page.
         *
         * You obviously have to change this value before the automatic highlighting started. To do this, you can add an
         * empty Prism object into the global scope before loading the Prism script like this:
         *
         * ```js
         * window.Prism = window.Prism || {};
         * Prism.manual = true;
         * // add a new <script> to load Prism's script
         * ```
         *
         * @default false
         * @type {boolean}
         * @memberof Prism
         * @public
         */
        manual: s.Prism && s.Prism.manual,
        /**
         * By default, if Prism is in a web worker, it assumes that it is in a worker it created itself, so it uses
         * `addEventListener` to communicate with its parent instance. However, if you're using Prism manually in your
         * own worker, you don't want it to do this.
         *
         * By setting this value to `true`, Prism will not add its own listeners to the worker.
         *
         * You obviously have to change this value before Prism executes. To do this, you can add an
         * empty Prism object into the global scope before loading the Prism script like this:
         *
         * ```js
         * window.Prism = window.Prism || {};
         * Prism.disableWorkerMessageHandler = true;
         * // Load Prism's script
         * ```
         *
         * @default false
         * @type {boolean}
         * @memberof Prism
         * @public
         */
        disableWorkerMessageHandler: s.Prism && s.Prism.disableWorkerMessageHandler,
        /**
         * A namespace for utility methods.
         *
         * All function in this namespace that are not explicitly marked as _public_ are for __internal use only__ and may
         * change or disappear at any time.
         *
         * @namespace
         * @memberof Prism
         */
        util: {
          encode: function i(h) {
            return h instanceof C ? new C(h.type, i(h.content), h.alias) : Array.isArray(h) ? h.map(i) : h.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/\u00a0/g, " ");
          },
          /**
           * Returns the name of the type of the given value.
           *
           * @param {any} o
           * @returns {string}
           * @example
           * type(null)      === 'Null'
           * type(undefined) === 'Undefined'
           * type(123)       === 'Number'
           * type('foo')     === 'String'
           * type(true)      === 'Boolean'
           * type([1, 2])    === 'Array'
           * type({})        === 'Object'
           * type(String)    === 'Function'
           * type(/abc+/)    === 'RegExp'
           */
          type: function(i) {
            return Object.prototype.toString.call(i).slice(8, -1);
          },
          /**
           * Returns a unique number for the given object. Later calls will still return the same number.
           *
           * @param {Object} obj
           * @returns {number}
           */
          objId: function(i) {
            return i.__id || Object.defineProperty(i, "__id", { value: ++v }), i.__id;
          },
          /**
           * Creates a deep clone of the given object.
           *
           * The main intended use of this function is to clone language definitions.
           *
           * @param {T} o
           * @param {Record<number, any>} [visited]
           * @returns {T}
           * @template T
           */
          clone: function i(h, d) {
            d = d || {};
            var E, k;
            switch (x.util.type(h)) {
              case "Object":
                if (k = x.util.objId(h), d[k])
                  return d[k];
                E = /** @type {Record<string, any>} */
                {}, d[k] = E;
                for (var L in h)
                  h.hasOwnProperty(L) && (E[L] = i(h[L], d));
                return (
                  /** @type {any} */
                  E
                );
              case "Array":
                return k = x.util.objId(h), d[k] ? d[k] : (E = [], d[k] = E, /** @type {Array} */
                /** @type {any} */
                h.forEach(function(M, B) {
                  E[B] = i(M, d);
                }), /** @type {any} */
                E);
              default:
                return h;
            }
          },
          /**
           * Returns the Prism language of the given element set by a `language-xxxx` or `lang-xxxx` class.
           *
           * If no language is set for the element or the element is `null` or `undefined`, `none` will be returned.
           *
           * @param {Element} element
           * @returns {string}
           */
          getLanguage: function(i) {
            for (; i; ) {
              var h = S.exec(i.className);
              if (h)
                return h[1].toLowerCase();
              i = i.parentElement;
            }
            return "none";
          },
          /**
           * Sets the Prism `language-xxxx` class of the given element.
           *
           * @param {Element} element
           * @param {string} language
           * @returns {void}
           */
          setLanguage: function(i, h) {
            i.className = i.className.replace(RegExp(S, "gi"), ""), i.classList.add("language-" + h);
          },
          /**
           * Returns the script element that is currently executing.
           *
           * This does __not__ work for line script element.
           *
           * @returns {HTMLScriptElement | null}
           */
          currentScript: function() {
            if (typeof document > "u")
              return null;
            if (document.currentScript && document.currentScript.tagName === "SCRIPT")
              return (
                /** @type {any} */
                document.currentScript
              );
            try {
              throw new Error();
            } catch (E) {
              var i = (/at [^(\r\n]*\((.*):[^:]+:[^:]+\)$/i.exec(E.stack) || [])[1];
              if (i) {
                var h = document.getElementsByTagName("script");
                for (var d in h)
                  if (h[d].src == i)
                    return h[d];
              }
              return null;
            }
          },
          /**
           * Returns whether a given class is active for `element`.
           *
           * The class can be activated if `element` or one of its ancestors has the given class and it can be deactivated
           * if `element` or one of its ancestors has the negated version of the given class. The _negated version_ of the
           * given class is just the given class with a `no-` prefix.
           *
           * Whether the class is active is determined by the closest ancestor of `element` (where `element` itself is
           * closest ancestor) that has the given class or the negated version of it. If neither `element` nor any of its
           * ancestors have the given class or the negated version of it, then the default activation will be returned.
           *
           * In the paradoxical situation where the closest ancestor contains __both__ the given class and the negated
           * version of it, the class is considered active.
           *
           * @param {Element} element
           * @param {string} className
           * @param {boolean} [defaultActivation=false]
           * @returns {boolean}
           */
          isActive: function(i, h, d) {
            for (var E = "no-" + h; i; ) {
              var k = i.classList;
              if (k.contains(h))
                return !0;
              if (k.contains(E))
                return !1;
              i = i.parentElement;
            }
            return !!d;
          }
        },
        /**
         * This namespace contains all currently loaded languages and the some helper functions to create and modify languages.
         *
         * @namespace
         * @memberof Prism
         * @public
         */
        languages: {
          /**
           * The grammar for plain, unformatted text.
           */
          plain: _,
          plaintext: _,
          text: _,
          txt: _,
          /**
           * Creates a deep copy of the language with the given id and appends the given tokens.
           *
           * If a token in `redef` also appears in the copied language, then the existing token in the copied language
           * will be overwritten at its original position.
           *
           * ## Best practices
           *
           * Since the position of overwriting tokens (token in `redef` that overwrite tokens in the copied language)
           * doesn't matter, they can technically be in any order. However, this can be confusing to others that trying to
           * understand the language definition because, normally, the order of tokens matters in Prism grammars.
           *
           * Therefore, it is encouraged to order overwriting tokens according to the positions of the overwritten tokens.
           * Furthermore, all non-overwriting tokens should be placed after the overwriting ones.
           *
           * @param {string} id The id of the language to extend. This has to be a key in `Prism.languages`.
           * @param {Grammar} redef The new tokens to append.
           * @returns {Grammar} The new language created.
           * @public
           * @example
           * Prism.languages['css-with-colors'] = Prism.languages.extend('css', {
           *     // Prism.languages.css already has a 'comment' token, so this token will overwrite CSS' 'comment' token
           *     // at its original position
           *     'comment': { ... },
           *     // CSS doesn't have a 'color' token, so this token will be appended
           *     'color': /\b(?:red|green|blue)\b/
           * });
           */
          extend: function(i, h) {
            var d = x.util.clone(x.languages[i]);
            for (var E in h)
              d[E] = h[E];
            return d;
          },
          /**
           * Inserts tokens _before_ another token in a language definition or any other grammar.
           *
           * ## Usage
           *
           * This helper method makes it easy to modify existing languages. For example, the CSS language definition
           * not only defines CSS highlighting for CSS documents, but also needs to define highlighting for CSS embedded
           * in HTML through `<style>` elements. To do this, it needs to modify `Prism.languages.markup` and add the
           * appropriate tokens. However, `Prism.languages.markup` is a regular JavaScript object literal, so if you do
           * this:
           *
           * ```js
           * Prism.languages.markup.style = {
           *     // token
           * };
           * ```
           *
           * then the `style` token will be added (and processed) at the end. `insertBefore` allows you to insert tokens
           * before existing tokens. For the CSS example above, you would use it like this:
           *
           * ```js
           * Prism.languages.insertBefore('markup', 'cdata', {
           *     'style': {
           *         // token
           *     }
           * });
           * ```
           *
           * ## Special cases
           *
           * If the grammars of `inside` and `insert` have tokens with the same name, the tokens in `inside`'s grammar
           * will be ignored.
           *
           * This behavior can be used to insert tokens after `before`:
           *
           * ```js
           * Prism.languages.insertBefore('markup', 'comment', {
           *     'comment': Prism.languages.markup.comment,
           *     // tokens after 'comment'
           * });
           * ```
           *
           * ## Limitations
           *
           * The main problem `insertBefore` has to solve is iteration order. Since ES2015, the iteration order for object
           * properties is guaranteed to be the insertion order (except for integer keys) but some browsers behave
           * differently when keys are deleted and re-inserted. So `insertBefore` can't be implemented by temporarily
           * deleting properties which is necessary to insert at arbitrary positions.
           *
           * To solve this problem, `insertBefore` doesn't actually insert the given tokens into the target object.
           * Instead, it will create a new object and replace all references to the target object with the new one. This
           * can be done without temporarily deleting properties, so the iteration order is well-defined.
           *
           * However, only references that can be reached from `Prism.languages` or `insert` will be replaced. I.e. if
           * you hold the target object in a variable, then the value of the variable will not change.
           *
           * ```js
           * var oldMarkup = Prism.languages.markup;
           * var newMarkup = Prism.languages.insertBefore('markup', 'comment', { ... });
           *
           * assert(oldMarkup !== Prism.languages.markup);
           * assert(newMarkup === Prism.languages.markup);
           * ```
           *
           * @param {string} inside The property of `root` (e.g. a language id in `Prism.languages`) that contains the
           * object to be modified.
           * @param {string} before The key to insert before.
           * @param {Grammar} insert An object containing the key-value pairs to be inserted.
           * @param {Object<string, any>} [root] The object containing `inside`, i.e. the object that contains the
           * object to be modified.
           *
           * Defaults to `Prism.languages`.
           * @returns {Grammar} The new grammar object.
           * @public
           */
          insertBefore: function(i, h, d, E) {
            E = E || /** @type {any} */
            x.languages;
            var k = E[i], L = {};
            for (var M in k)
              if (k.hasOwnProperty(M)) {
                if (M == h)
                  for (var B in d)
                    d.hasOwnProperty(B) && (L[B] = d[B]);
                d.hasOwnProperty(M) || (L[M] = k[M]);
              }
            var U = E[i];
            return E[i] = L, x.languages.DFS(x.languages, function(q, Z) {
              Z === U && q != i && (this[q] = L);
            }), L;
          },
          // Traverse a language definition with Depth First Search
          DFS: function i(h, d, E, k) {
            k = k || {};
            var L = x.util.objId;
            for (var M in h)
              if (h.hasOwnProperty(M)) {
                d.call(h, M, h[M], E || M);
                var B = h[M], U = x.util.type(B);
                U === "Object" && !k[L(B)] ? (k[L(B)] = !0, i(B, d, null, k)) : U === "Array" && !k[L(B)] && (k[L(B)] = !0, i(B, d, M, k));
              }
          }
        },
        plugins: {},
        /**
         * This is the most high-level function in Prism’s API.
         * It fetches all the elements that have a `.language-xxxx` class and then calls {@link Prism.highlightElement} on
         * each one of them.
         *
         * This is equivalent to `Prism.highlightAllUnder(document, async, callback)`.
         *
         * @param {boolean} [async=false] Same as in {@link Prism.highlightAllUnder}.
         * @param {HighlightCallback} [callback] Same as in {@link Prism.highlightAllUnder}.
         * @memberof Prism
         * @public
         */
        highlightAll: function(i, h) {
          x.highlightAllUnder(document, i, h);
        },
        /**
         * Fetches all the descendants of `container` that have a `.language-xxxx` class and then calls
         * {@link Prism.highlightElement} on each one of them.
         *
         * The following hooks will be run:
         * 1. `before-highlightall`
         * 2. `before-all-elements-highlight`
         * 3. All hooks of {@link Prism.highlightElement} for each element.
         *
         * @param {ParentNode} container The root element, whose descendants that have a `.language-xxxx` class will be highlighted.
         * @param {boolean} [async=false] Whether each element is to be highlighted asynchronously using Web Workers.
         * @param {HighlightCallback} [callback] An optional callback to be invoked on each element after its highlighting is done.
         * @memberof Prism
         * @public
         */
        highlightAllUnder: function(i, h, d) {
          var E = {
            callback: d,
            container: i,
            selector: 'code[class*="language-"], [class*="language-"] code, code[class*="lang-"], [class*="lang-"] code'
          };
          x.hooks.run("before-highlightall", E), E.elements = Array.prototype.slice.apply(E.container.querySelectorAll(E.selector)), x.hooks.run("before-all-elements-highlight", E);
          for (var k = 0, L; L = E.elements[k++]; )
            x.highlightElement(L, h === !0, E.callback);
        },
        /**
         * Highlights the code inside a single element.
         *
         * The following hooks will be run:
         * 1. `before-sanity-check`
         * 2. `before-highlight`
         * 3. All hooks of {@link Prism.highlight}. These hooks will be run by an asynchronous worker if `async` is `true`.
         * 4. `before-insert`
         * 5. `after-highlight`
         * 6. `complete`
         *
         * Some the above hooks will be skipped if the element doesn't contain any text or there is no grammar loaded for
         * the element's language.
         *
         * @param {Element} element The element containing the code.
         * It must have a class of `language-xxxx` to be processed, where `xxxx` is a valid language identifier.
         * @param {boolean} [async=false] Whether the element is to be highlighted asynchronously using Web Workers
         * to improve performance and avoid blocking the UI when highlighting very large chunks of code. This option is
         * [disabled by default](https://prismjs.com/faq.html#why-is-asynchronous-highlighting-disabled-by-default).
         *
         * Note: All language definitions required to highlight the code must be included in the main `prism.js` file for
         * asynchronous highlighting to work. You can build your own bundle on the
         * [Download page](https://prismjs.com/download.html).
         * @param {HighlightCallback} [callback] An optional callback to be invoked after the highlighting is done.
         * Mostly useful when `async` is `true`, since in that case, the highlighting is done asynchronously.
         * @memberof Prism
         * @public
         */
        highlightElement: function(i, h, d) {
          var E = x.util.getLanguage(i), k = x.languages[E];
          x.util.setLanguage(i, E);
          var L = i.parentElement;
          L && L.nodeName.toLowerCase() === "pre" && x.util.setLanguage(L, E);
          var M = i.textContent, B = {
            element: i,
            language: E,
            grammar: k,
            code: M
          };
          function U(Z) {
            B.highlightedCode = Z, x.hooks.run("before-insert", B), B.element.innerHTML = B.highlightedCode, x.hooks.run("after-highlight", B), x.hooks.run("complete", B), d && d.call(B.element);
          }
          if (x.hooks.run("before-sanity-check", B), L = B.element.parentElement, L && L.nodeName.toLowerCase() === "pre" && !L.hasAttribute("tabindex") && L.setAttribute("tabindex", "0"), !B.code) {
            x.hooks.run("complete", B), d && d.call(B.element);
            return;
          }
          if (x.hooks.run("before-highlight", B), !B.grammar) {
            U(x.util.encode(B.code));
            return;
          }
          if (h && s.Worker) {
            var q = new Worker(x.filename);
            q.onmessage = function(Z) {
              U(Z.data);
            }, q.postMessage(JSON.stringify({
              language: B.language,
              code: B.code,
              immediateClose: !0
            }));
          } else
            U(x.highlight(B.code, B.grammar, B.language));
        },
        /**
         * Low-level function, only use if you know what you’re doing. It accepts a string of text as input
         * and the language definitions to use, and returns a string with the HTML produced.
         *
         * The following hooks will be run:
         * 1. `before-tokenize`
         * 2. `after-tokenize`
         * 3. `wrap`: On each {@link Token}.
         *
         * @param {string} text A string with the code to be highlighted.
         * @param {Grammar} grammar An object containing the tokens to use.
         *
         * Usually a language definition like `Prism.languages.markup`.
         * @param {string} language The name of the language definition passed to `grammar`.
         * @returns {string} The highlighted HTML.
         * @memberof Prism
         * @public
         * @example
         * Prism.highlight('var foo = true;', Prism.languages.javascript, 'javascript');
         */
        highlight: function(i, h, d) {
          var E = {
            code: i,
            grammar: h,
            language: d
          };
          if (x.hooks.run("before-tokenize", E), !E.grammar)
            throw new Error('The language "' + E.language + '" has no grammar.');
          return E.tokens = x.tokenize(E.code, E.grammar), x.hooks.run("after-tokenize", E), C.stringify(x.util.encode(E.tokens), E.language);
        },
        /**
         * This is the heart of Prism, and the most low-level function you can use. It accepts a string of text as input
         * and the language definitions to use, and returns an array with the tokenized code.
         *
         * When the language definition includes nested tokens, the function is called recursively on each of these tokens.
         *
         * This method could be useful in other contexts as well, as a very crude parser.
         *
         * @param {string} text A string with the code to be highlighted.
         * @param {Grammar} grammar An object containing the tokens to use.
         *
         * Usually a language definition like `Prism.languages.markup`.
         * @returns {TokenStream} An array of strings and tokens, a token stream.
         * @memberof Prism
         * @public
         * @example
         * let code = `var foo = 0;`;
         * let tokens = Prism.tokenize(code, Prism.languages.javascript);
         * tokens.forEach(token => {
         *     if (token instanceof Prism.Token && token.type === 'number') {
         *         console.log(`Found numeric literal: ${token.content}`);
         *     }
         * });
         */
        tokenize: function(i, h) {
          var d = h.rest;
          if (d) {
            for (var E in d)
              h[E] = d[E];
            delete h.rest;
          }
          var k = new n();
          return f(k, k.head, i), A(i, k, h, k.head, 0), F(k);
        },
        /**
         * @namespace
         * @memberof Prism
         * @public
         */
        hooks: {
          all: {},
          /**
           * Adds the given callback to the list of callbacks for the given hook.
           *
           * The callback will be invoked when the hook it is registered for is run.
           * Hooks are usually directly run by a highlight function but you can also run hooks yourself.
           *
           * One callback function can be registered to multiple hooks and the same hook multiple times.
           *
           * @param {string} name The name of the hook.
           * @param {HookCallback} callback The callback function which is given environment variables.
           * @public
           */
          add: function(i, h) {
            var d = x.hooks.all;
            d[i] = d[i] || [], d[i].push(h);
          },
          /**
           * Runs a hook invoking all registered callbacks with the given environment variables.
           *
           * Callbacks will be invoked synchronously and in the order in which they were registered.
           *
           * @param {string} name The name of the hook.
           * @param {Object<string, any>} env The environment variables of the hook passed to all callbacks registered.
           * @public
           */
          run: function(i, h) {
            var d = x.hooks.all[i];
            if (!(!d || !d.length))
              for (var E = 0, k; k = d[E++]; )
                k(h);
          }
        },
        Token: C
      };
      s.Prism = x;
      function C(i, h, d, E) {
        this.type = i, this.content = h, this.alias = d, this.length = (E || "").length | 0;
      }
      C.stringify = function i(h, d) {
        if (typeof h == "string")
          return h;
        if (Array.isArray(h)) {
          var E = "";
          return h.forEach(function(U) {
            E += i(U, d);
          }), E;
        }
        var k = {
          type: h.type,
          content: i(h.content, d),
          tag: "span",
          classes: ["token", h.type],
          attributes: {},
          language: d
        }, L = h.alias;
        L && (Array.isArray(L) ? Array.prototype.push.apply(k.classes, L) : k.classes.push(L)), x.hooks.run("wrap", k);
        var M = "";
        for (var B in k.attributes)
          M += " " + B + '="' + (k.attributes[B] || "").replace(/"/g, "&quot;") + '"';
        return "<" + k.tag + ' class="' + k.classes.join(" ") + '"' + M + ">" + k.content + "</" + k.tag + ">";
      };
      function T(i, h, d, E) {
        i.lastIndex = h;
        var k = i.exec(d);
        if (k && E && k[1]) {
          var L = k[1].length;
          k.index += L, k[0] = k[0].slice(L);
        }
        return k;
      }
      function A(i, h, d, E, k, L) {
        for (var M in d)
          if (!(!d.hasOwnProperty(M) || !d[M])) {
            var B = d[M];
            B = Array.isArray(B) ? B : [B];
            for (var U = 0; U < B.length; ++U) {
              if (L && L.cause == M + "," + U)
                return;
              var q = B[U], Z = q.inside, K = !!q.lookbehind, Y = !!q.greedy, G = q.alias;
              if (Y && !q.pattern.global) {
                var j = q.pattern.toString().match(/[imsuy]*$/)[0];
                q.pattern = RegExp(q.pattern.source, j + "g");
              }
              for (var Q = q.pattern || q, J = E.next, tt = k; J !== h.tail && !(L && tt >= L.reach); tt += J.value.length, J = J.next) {
                var rt = J.value;
                if (h.length > i.length)
                  return;
                if (!(rt instanceof C)) {
                  var ut = 1, dt;
                  if (Y) {
                    if (dt = T(Q, tt, i, K), !dt || dt.index >= i.length)
                      break;
                    var et = dt.index, ft = dt.index + dt[0].length, lt = tt;
                    for (lt += J.value.length; et >= lt; )
                      J = J.next, lt += J.value.length;
                    if (lt -= J.value.length, tt = lt, J.value instanceof C)
                      continue;
                    for (var ot = J; ot !== h.tail && (lt < ft || typeof ot.value == "string"); ot = ot.next)
                      ut++, lt += ot.value.length;
                    ut--, rt = i.slice(tt, lt), dt.index -= tt;
                  } else if (dt = T(Q, 0, rt, K), !dt)
                    continue;
                  var et = dt.index, D = dt[0], y = rt.slice(0, et), o = rt.slice(et + D.length), u = tt + rt.length;
                  L && u > L.reach && (L.reach = u);
                  var m = J.prev;
                  y && (m = f(h, m, y), tt += y.length), p(h, m, ut);
                  var g = new C(M, Z ? x.tokenize(D, Z) : D, G, D);
                  if (J = f(h, m, g), o && f(h, J, o), ut > 1) {
                    var c = {
                      cause: M + "," + U,
                      reach: u
                    };
                    A(i, h, d, J.prev, tt, c), L && c.reach > L.reach && (L.reach = c.reach);
                  }
                }
              }
            }
          }
      }
      function n() {
        var i = { value: null, prev: null, next: null }, h = { value: null, prev: i, next: null };
        i.next = h, this.head = i, this.tail = h, this.length = 0;
      }
      function f(i, h, d) {
        var E = h.next, k = { value: d, prev: h, next: E };
        return h.next = k, E.prev = k, i.length++, k;
      }
      function p(i, h, d) {
        for (var E = h.next, k = 0; k < d && E !== i.tail; k++)
          E = E.next;
        h.next = E, E.prev = h, i.length -= k;
      }
      function F(i) {
        for (var h = [], d = i.head.next; d !== i.tail; )
          h.push(d.value), d = d.next;
        return h;
      }
      if (!s.document)
        return s.addEventListener && (x.disableWorkerMessageHandler || s.addEventListener("message", function(i) {
          var h = JSON.parse(i.data), d = h.language, E = h.code, k = h.immediateClose;
          s.postMessage(x.highlight(E, x.languages[d], d)), k && s.close();
        }, !1)), x;
      var r = x.util.currentScript();
      r && (x.filename = r.src, r.hasAttribute("data-manual") && (x.manual = !0));
      function w() {
        x.manual || x.highlightAll();
      }
      if (!x.manual) {
        var t = document.readyState;
        t === "loading" || t === "interactive" && r && r.defer ? document.addEventListener("DOMContentLoaded", w) : window.requestAnimationFrame ? window.requestAnimationFrame(w) : window.setTimeout(w, 16);
      }
      return x;
    })(l);
    V.exports && (V.exports = a), typeof Re < "u" && (Re.Prism = a), a.languages.markup = {
      comment: {
        pattern: /<!--(?:(?!<!--)[\s\S])*?-->/,
        greedy: !0
      },
      prolog: {
        pattern: /<\?[\s\S]+?\?>/,
        greedy: !0
      },
      doctype: {
        // https://www.w3.org/TR/xml/#NT-doctypedecl
        pattern: /<!DOCTYPE(?:[^>"'[\]]|"[^"]*"|'[^']*')+(?:\[(?:[^<"'\]]|"[^"]*"|'[^']*'|<(?!!--)|<!--(?:[^-]|-(?!->))*-->)*\]\s*)?>/i,
        greedy: !0,
        inside: {
          "internal-subset": {
            pattern: /(^[^\[]*\[)[\s\S]+(?=\]>$)/,
            lookbehind: !0,
            greedy: !0,
            inside: null
            // see below
          },
          string: {
            pattern: /"[^"]*"|'[^']*'/,
            greedy: !0
          },
          punctuation: /^<!|>$|[[\]]/,
          "doctype-tag": /^DOCTYPE/i,
          name: /[^\s<>'"]+/
        }
      },
      cdata: {
        pattern: /<!\[CDATA\[[\s\S]*?\]\]>/i,
        greedy: !0
      },
      tag: {
        pattern: /<\/?(?!\d)[^\s>\/=$<%]+(?:\s(?:\s*[^\s>\/=]+(?:\s*=\s*(?:"[^"]*"|'[^']*'|[^\s'">=]+(?=[\s>]))|(?=[\s/>])))+)?\s*\/?>/,
        greedy: !0,
        inside: {
          tag: {
            pattern: /^<\/?[^\s>\/]+/,
            inside: {
              punctuation: /^<\/?/,
              namespace: /^[^\s>\/:]+:/
            }
          },
          "special-attr": [],
          "attr-value": {
            pattern: /=\s*(?:"[^"]*"|'[^']*'|[^\s'">=]+)/,
            inside: {
              punctuation: [
                {
                  pattern: /^=/,
                  alias: "attr-equals"
                },
                {
                  pattern: /^(\s*)["']|["']$/,
                  lookbehind: !0
                }
              ]
            }
          },
          punctuation: /\/?>/,
          "attr-name": {
            pattern: /[^\s>\/]+/,
            inside: {
              namespace: /^[^\s>\/:]+:/
            }
          }
        }
      },
      entity: [
        {
          pattern: /&[\da-z]{1,8};/i,
          alias: "named-entity"
        },
        /&#x?[\da-f]{1,8};/i
      ]
    }, a.languages.markup.tag.inside["attr-value"].inside.entity = a.languages.markup.entity, a.languages.markup.doctype.inside["internal-subset"].inside = a.languages.markup, a.hooks.add("wrap", function(s) {
      s.type === "entity" && (s.attributes.title = s.content.replace(/&amp;/, "&"));
    }), Object.defineProperty(a.languages.markup.tag, "addInlined", {
      /**
       * Adds an inlined language to markup.
       *
       * An example of an inlined language is CSS with `<style>` tags.
       *
       * @param {string} tagName The name of the tag that contains the inlined language. This name will be treated as
       * case insensitive.
       * @param {string} lang The language key.
       * @example
       * addInlined('style', 'css');
       */
      value: function(S, v) {
        var _ = {};
        _["language-" + v] = {
          pattern: /(^<!\[CDATA\[)[\s\S]+?(?=\]\]>$)/i,
          lookbehind: !0,
          inside: a.languages[v]
        }, _.cdata = /^<!\[CDATA\[|\]\]>$/i;
        var x = {
          "included-cdata": {
            pattern: /<!\[CDATA\[[\s\S]*?\]\]>/i,
            inside: _
          }
        };
        x["language-" + v] = {
          pattern: /[\s\S]+/,
          inside: a.languages[v]
        };
        var C = {};
        C[S] = {
          pattern: RegExp(/(<__[^>]*>)(?:<!\[CDATA\[(?:[^\]]|\](?!\]>))*\]\]>|(?!<!\[CDATA\[)[\s\S])*?(?=<\/__>)/.source.replace(/__/g, function() {
            return S;
          }), "i"),
          lookbehind: !0,
          greedy: !0,
          inside: x
        }, a.languages.insertBefore("markup", "cdata", C);
      }
    }), Object.defineProperty(a.languages.markup.tag, "addAttribute", {
      /**
       * Adds an pattern to highlight languages embedded in HTML attributes.
       *
       * An example of an inlined language is CSS with `style` attributes.
       *
       * @param {string} attrName The name of the tag that contains the inlined language. This name will be treated as
       * case insensitive.
       * @param {string} lang The language key.
       * @example
       * addAttribute('style', 'css');
       */
      value: function(s, S) {
        a.languages.markup.tag.inside["special-attr"].push({
          pattern: RegExp(
            /(^|["'\s])/.source + "(?:" + s + ")" + /\s*=\s*(?:"[^"]*"|'[^']*'|[^\s'">=]+(?=[\s>]))/.source,
            "i"
          ),
          lookbehind: !0,
          inside: {
            "attr-name": /^[^\s=]+/,
            "attr-value": {
              pattern: /=[\s\S]+/,
              inside: {
                value: {
                  pattern: /(^=\s*(["']|(?!["'])))\S[\s\S]*(?=\2$)/,
                  lookbehind: !0,
                  alias: [S, "language-" + S],
                  inside: a.languages[S]
                },
                punctuation: [
                  {
                    pattern: /^=/,
                    alias: "attr-equals"
                  },
                  /"|'/
                ]
              }
            }
          }
        });
      }
    }), a.languages.html = a.languages.markup, a.languages.mathml = a.languages.markup, a.languages.svg = a.languages.markup, a.languages.xml = a.languages.extend("markup", {}), a.languages.ssml = a.languages.xml, a.languages.atom = a.languages.xml, a.languages.rss = a.languages.xml, (function(s) {
      var S = /(?:"(?:\\(?:\r\n|[\s\S])|[^"\\\r\n])*"|'(?:\\(?:\r\n|[\s\S])|[^'\\\r\n])*')/;
      s.languages.css = {
        comment: /\/\*[\s\S]*?\*\//,
        atrule: {
          pattern: RegExp("@[\\w-](?:" + /[^;{\s"']|\s+(?!\s)/.source + "|" + S.source + ")*?" + /(?:;|(?=\s*\{))/.source),
          inside: {
            rule: /^@[\w-]+/,
            "selector-function-argument": {
              pattern: /(\bselector\s*\(\s*(?![\s)]))(?:[^()\s]|\s+(?![\s)])|\((?:[^()]|\([^()]*\))*\))+(?=\s*\))/,
              lookbehind: !0,
              alias: "selector"
            },
            keyword: {
              pattern: /(^|[^\w-])(?:and|not|only|or)(?![\w-])/,
              lookbehind: !0
            }
            // See rest below
          }
        },
        url: {
          // https://drafts.csswg.org/css-values-3/#urls
          pattern: RegExp("\\burl\\((?:" + S.source + "|" + /(?:[^\\\r\n()"']|\\[\s\S])*/.source + ")\\)", "i"),
          greedy: !0,
          inside: {
            function: /^url/i,
            punctuation: /^\(|\)$/,
            string: {
              pattern: RegExp("^" + S.source + "$"),
              alias: "url"
            }
          }
        },
        selector: {
          pattern: RegExp(`(^|[{}\\s])[^{}\\s](?:[^{};"'\\s]|\\s+(?![\\s{])|` + S.source + ")*(?=\\s*\\{)"),
          lookbehind: !0
        },
        string: {
          pattern: S,
          greedy: !0
        },
        property: {
          pattern: /(^|[^-\w\xA0-\uFFFF])(?!\s)[-_a-z\xA0-\uFFFF](?:(?!\s)[-\w\xA0-\uFFFF])*(?=\s*:)/i,
          lookbehind: !0
        },
        important: /!important\b/i,
        function: {
          pattern: /(^|[^-a-z0-9])[-a-z0-9]+(?=\()/i,
          lookbehind: !0
        },
        punctuation: /[(){};:,]/
      }, s.languages.css.atrule.inside.rest = s.languages.css;
      var v = s.languages.markup;
      v && (v.tag.addInlined("style", "css"), v.tag.addAttribute("style", "css"));
    })(a), a.languages.clike = {
      comment: [
        {
          pattern: /(^|[^\\])\/\*[\s\S]*?(?:\*\/|$)/,
          lookbehind: !0,
          greedy: !0
        },
        {
          pattern: /(^|[^\\:])\/\/.*/,
          lookbehind: !0,
          greedy: !0
        }
      ],
      string: {
        pattern: /(["'])(?:\\(?:\r\n|[\s\S])|(?!\1)[^\\\r\n])*\1/,
        greedy: !0
      },
      "class-name": {
        pattern: /(\b(?:class|extends|implements|instanceof|interface|new|trait)\s+|\bcatch\s+\()[\w.\\]+/i,
        lookbehind: !0,
        inside: {
          punctuation: /[.\\]/
        }
      },
      keyword: /\b(?:break|catch|continue|do|else|finally|for|function|if|in|instanceof|new|null|return|throw|try|while)\b/,
      boolean: /\b(?:false|true)\b/,
      function: /\b\w+(?=\()/,
      number: /\b0x[\da-f]+\b|(?:\b\d+(?:\.\d*)?|\B\.\d+)(?:e[+-]?\d+)?/i,
      operator: /[<>]=?|[!=]=?=?|--?|\+\+?|&&?|\|\|?|[?*/~^%]/,
      punctuation: /[{}[\];(),.:]/
    }, a.languages.javascript = a.languages.extend("clike", {
      "class-name": [
        a.languages.clike["class-name"],
        {
          pattern: /(^|[^$\w\xA0-\uFFFF])(?!\s)[_$A-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\.(?:constructor|prototype))/,
          lookbehind: !0
        }
      ],
      keyword: [
        {
          pattern: /((?:^|\})\s*)catch\b/,
          lookbehind: !0
        },
        {
          pattern: /(^|[^.]|\.\.\.\s*)\b(?:as|assert(?=\s*\{)|async(?=\s*(?:function\b|\(|[$\w\xA0-\uFFFF]|$))|await|break|case|class|const|continue|debugger|default|delete|do|else|enum|export|extends|finally(?=\s*(?:\{|$))|for|from(?=\s*(?:['"]|$))|function|(?:get|set)(?=\s*(?:[#\[$\w\xA0-\uFFFF]|$))|if|implements|import|in|instanceof|interface|let|new|null|of|package|private|protected|public|return|static|super|switch|this|throw|try|typeof|undefined|var|void|while|with|yield)\b/,
          lookbehind: !0
        }
      ],
      // Allow for all non-ASCII characters (See http://stackoverflow.com/a/2008444)
      function: /#?(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\s*(?:\.\s*(?:apply|bind|call)\s*)?\()/,
      number: {
        pattern: RegExp(
          /(^|[^\w$])/.source + "(?:" + // constant
          (/NaN|Infinity/.source + "|" + // binary integer
          /0[bB][01]+(?:_[01]+)*n?/.source + "|" + // octal integer
          /0[oO][0-7]+(?:_[0-7]+)*n?/.source + "|" + // hexadecimal integer
          /0[xX][\dA-Fa-f]+(?:_[\dA-Fa-f]+)*n?/.source + "|" + // decimal bigint
          /\d+(?:_\d+)*n/.source + "|" + // decimal number (integer or float) but no bigint
          /(?:\d+(?:_\d+)*(?:\.(?:\d+(?:_\d+)*)?)?|\.\d+(?:_\d+)*)(?:[Ee][+-]?\d+(?:_\d+)*)?/.source) + ")" + /(?![\w$])/.source
        ),
        lookbehind: !0
      },
      operator: /--|\+\+|\*\*=?|=>|&&=?|\|\|=?|[!=]==|<<=?|>>>?=?|[-+*/%&|^!=<>]=?|\.{3}|\?\?=?|\?\.?|[~:]/
    }), a.languages.javascript["class-name"][0].pattern = /(\b(?:class|extends|implements|instanceof|interface|new)\s+)[\w.\\]+/, a.languages.insertBefore("javascript", "keyword", {
      regex: {
        pattern: RegExp(
          // lookbehind
          // eslint-disable-next-line regexp/no-dupe-characters-character-class
          /((?:^|[^$\w\xA0-\uFFFF."'\])\s]|\b(?:return|yield))\s*)/.source + // Regex pattern:
          // There are 2 regex patterns here. The RegExp set notation proposal added support for nested character
          // classes if the `v` flag is present. Unfortunately, nested CCs are both context-free and incompatible
          // with the only syntax, so we have to define 2 different regex patterns.
          /\//.source + "(?:" + /(?:\[(?:[^\]\\\r\n]|\\.)*\]|\\.|[^/\\\[\r\n])+\/[dgimyus]{0,7}/.source + "|" + // `v` flag syntax. This supports 3 levels of nested character classes.
          /(?:\[(?:[^[\]\\\r\n]|\\.|\[(?:[^[\]\\\r\n]|\\.|\[(?:[^[\]\\\r\n]|\\.)*\])*\])*\]|\\.|[^/\\\[\r\n])+\/[dgimyus]{0,7}v[dgimyus]{0,7}/.source + ")" + // lookahead
          /(?=(?:\s|\/\*(?:[^*]|\*(?!\/))*\*\/)*(?:$|[\r\n,.;:})\]]|\/\/))/.source
        ),
        lookbehind: !0,
        greedy: !0,
        inside: {
          "regex-source": {
            pattern: /^(\/)[\s\S]+(?=\/[a-z]*$)/,
            lookbehind: !0,
            alias: "language-regex",
            inside: a.languages.regex
          },
          "regex-delimiter": /^\/|\/$/,
          "regex-flags": /^[a-z]+$/
        }
      },
      // This must be declared before keyword because we use "function" inside the look-forward
      "function-variable": {
        pattern: /#?(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\s*[=:]\s*(?:async\s*)?(?:\bfunction\b|(?:\((?:[^()]|\([^()]*\))*\)|(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*)\s*=>))/,
        alias: "function"
      },
      parameter: [
        {
          pattern: /(function(?:\s+(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*)?\s*\(\s*)(?!\s)(?:[^()\s]|\s+(?![\s)])|\([^()]*\))+(?=\s*\))/,
          lookbehind: !0,
          inside: a.languages.javascript
        },
        {
          pattern: /(^|[^$\w\xA0-\uFFFF])(?!\s)[_$a-z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\s*=>)/i,
          lookbehind: !0,
          inside: a.languages.javascript
        },
        {
          pattern: /(\(\s*)(?!\s)(?:[^()\s]|\s+(?![\s)])|\([^()]*\))+(?=\s*\)\s*=>)/,
          lookbehind: !0,
          inside: a.languages.javascript
        },
        {
          pattern: /((?:\b|\s|^)(?!(?:as|async|await|break|case|catch|class|const|continue|debugger|default|delete|do|else|enum|export|extends|finally|for|from|function|get|if|implements|import|in|instanceof|interface|let|new|null|of|package|private|protected|public|return|set|static|super|switch|this|throw|try|typeof|undefined|var|void|while|with|yield)(?![$\w\xA0-\uFFFF]))(?:(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*\s*)\(\s*|\]\s*\(\s*)(?!\s)(?:[^()\s]|\s+(?![\s)])|\([^()]*\))+(?=\s*\)\s*\{)/,
          lookbehind: !0,
          inside: a.languages.javascript
        }
      ],
      constant: /\b[A-Z](?:[A-Z_]|\dx?)*\b/
    }), a.languages.insertBefore("javascript", "string", {
      hashbang: {
        pattern: /^#!.*/,
        greedy: !0,
        alias: "comment"
      },
      "template-string": {
        pattern: /`(?:\\[\s\S]|\$\{(?:[^{}]|\{(?:[^{}]|\{[^}]*\})*\})+\}|(?!\$\{)[^\\`])*`/,
        greedy: !0,
        inside: {
          "template-punctuation": {
            pattern: /^`|`$/,
            alias: "string"
          },
          interpolation: {
            pattern: /((?:^|[^\\])(?:\\{2})*)\$\{(?:[^{}]|\{(?:[^{}]|\{[^}]*\})*\})+\}/,
            lookbehind: !0,
            inside: {
              "interpolation-punctuation": {
                pattern: /^\$\{|\}$/,
                alias: "punctuation"
              },
              rest: a.languages.javascript
            }
          },
          string: /[\s\S]+/
        }
      },
      "string-property": {
        pattern: /((?:^|[,{])[ \t]*)(["'])(?:\\(?:\r\n|[\s\S])|(?!\2)[^\\\r\n])*\2(?=\s*:)/m,
        lookbehind: !0,
        greedy: !0,
        alias: "property"
      }
    }), a.languages.insertBefore("javascript", "operator", {
      "literal-property": {
        pattern: /((?:^|[,{])[ \t]*)(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\s*:)/m,
        lookbehind: !0,
        alias: "property"
      }
    }), a.languages.markup && (a.languages.markup.tag.addInlined("script", "javascript"), a.languages.markup.tag.addAttribute(
      /on(?:abort|blur|change|click|composition(?:end|start|update)|dblclick|error|focus(?:in|out)?|key(?:down|up)|load|mouse(?:down|enter|leave|move|out|over|up)|reset|resize|scroll|select|slotchange|submit|unload|wheel)/.source,
      "javascript"
    )), a.languages.js = a.languages.javascript, (function() {
      if (typeof a > "u" || typeof document > "u")
        return;
      Element.prototype.matches || (Element.prototype.matches = Element.prototype.msMatchesSelector || Element.prototype.webkitMatchesSelector);
      var s = "Loading…", S = function(r, w) {
        return "✖ Error " + r + " while fetching file: " + w;
      }, v = "✖ Error: File does not exist or is empty", _ = {
        js: "javascript",
        py: "python",
        rb: "ruby",
        ps1: "powershell",
        psm1: "powershell",
        sh: "bash",
        bat: "batch",
        h: "c",
        tex: "latex"
      }, x = "data-src-status", C = "loading", T = "loaded", A = "failed", n = "pre[data-src]:not([" + x + '="' + T + '"]):not([' + x + '="' + C + '"])';
      function f(r, w, t) {
        var i = new XMLHttpRequest();
        i.open("GET", r, !0), i.onreadystatechange = function() {
          i.readyState == 4 && (i.status < 400 && i.responseText ? w(i.responseText) : i.status >= 400 ? t(S(i.status, i.statusText)) : t(v));
        }, i.send(null);
      }
      function p(r) {
        var w = /^\s*(\d+)\s*(?:(,)\s*(?:(\d+)\s*)?)?$/.exec(r || "");
        if (w) {
          var t = Number(w[1]), i = w[2], h = w[3];
          return i ? h ? [t, Number(h)] : [t, void 0] : [t, t];
        }
      }
      a.hooks.add("before-highlightall", function(r) {
        r.selector += ", " + n;
      }), a.hooks.add("before-sanity-check", function(r) {
        var w = (
          /** @type {HTMLPreElement} */
          r.element
        );
        if (w.matches(n)) {
          r.code = "", w.setAttribute(x, C);
          var t = w.appendChild(document.createElement("CODE"));
          t.textContent = s;
          var i = w.getAttribute("data-src"), h = r.language;
          if (h === "none") {
            var d = (/\.(\w+)$/.exec(i) || [, "none"])[1];
            h = _[d] || d;
          }
          a.util.setLanguage(t, h), a.util.setLanguage(w, h);
          var E = a.plugins.autoloader;
          E && E.loadLanguages(h), f(
            i,
            function(k) {
              w.setAttribute(x, T);
              var L = p(w.getAttribute("data-range"));
              if (L) {
                var M = k.split(/\r\n?|\n/g), B = L[0], U = L[1] == null ? M.length : L[1];
                B < 0 && (B += M.length), B = Math.max(0, Math.min(B - 1, M.length)), U < 0 && (U += M.length), U = Math.max(0, Math.min(U, M.length)), k = M.slice(B, U).join(`
`), w.hasAttribute("data-start") || w.setAttribute("data-start", String(B + 1));
              }
              t.textContent = k, a.highlightElement(t);
            },
            function(k) {
              w.setAttribute(x, A), t.textContent = k;
            }
          );
        }
      }), a.plugins.fileHighlight = {
        /**
         * Executes the File Highlight plugin for all matching `pre` elements under the given container.
         *
         * Note: Elements which are already loaded or currently loading will not be touched by this method.
         *
         * @param {ParentNode} [container=document]
         */
        highlight: function(w) {
          for (var t = (w || document).querySelectorAll(n), i = 0, h; h = t[i++]; )
            a.highlightElement(h);
        }
      };
      var F = !1;
      a.fileHighlight = function() {
        F || (console.warn("Prism.fileHighlight is deprecated. Use `Prism.plugins.fileHighlight.highlight` instead."), F = !0), a.plugins.fileHighlight.highlight.apply(this, arguments);
      };
    })();
  })(ce)), ce.exports;
}
pi();
var Ie = {}, Me;
function gi() {
  return Me || (Me = 1, Prism.languages.python = {
    comment: {
      pattern: /(^|[^\\])#.*/,
      lookbehind: !0,
      greedy: !0
    },
    "string-interpolation": {
      pattern: /(?:f|fr|rf)(?:("""|''')[\s\S]*?\1|("|')(?:\\.|(?!\2)[^\\\r\n])*\2)/i,
      greedy: !0,
      inside: {
        interpolation: {
          // "{" <expression> <optional "!s", "!r", or "!a"> <optional ":" format specifier> "}"
          pattern: /((?:^|[^{])(?:\{\{)*)\{(?!\{)(?:[^{}]|\{(?!\{)(?:[^{}]|\{(?!\{)(?:[^{}])+\})+\})+\}/,
          lookbehind: !0,
          inside: {
            "format-spec": {
              pattern: /(:)[^:(){}]+(?=\}$)/,
              lookbehind: !0
            },
            "conversion-option": {
              pattern: /![sra](?=[:}]$)/,
              alias: "punctuation"
            },
            rest: null
          }
        },
        string: /[\s\S]+/
      }
    },
    "triple-quoted-string": {
      pattern: /(?:[rub]|br|rb)?("""|''')[\s\S]*?\1/i,
      greedy: !0,
      alias: "string"
    },
    string: {
      pattern: /(?:[rub]|br|rb)?("|')(?:\\.|(?!\1)[^\\\r\n])*\1/i,
      greedy: !0
    },
    function: {
      pattern: /((?:^|\s)def[ \t]+)[a-zA-Z_]\w*(?=\s*\()/g,
      lookbehind: !0
    },
    "class-name": {
      pattern: /(\bclass\s+)\w+/i,
      lookbehind: !0
    },
    decorator: {
      pattern: /(^[\t ]*)@\w+(?:\.\w+)*/m,
      lookbehind: !0,
      alias: ["annotation", "punctuation"],
      inside: {
        punctuation: /\./
      }
    },
    keyword: /\b(?:_(?=\s*:)|and|as|assert|async|await|break|case|class|continue|def|del|elif|else|except|exec|finally|for|from|global|if|import|in|is|lambda|match|nonlocal|not|or|pass|print|raise|return|try|while|with|yield)\b/,
    builtin: /\b(?:__import__|abs|all|any|apply|ascii|basestring|bin|bool|buffer|bytearray|bytes|callable|chr|classmethod|cmp|coerce|compile|complex|delattr|dict|dir|divmod|enumerate|eval|execfile|file|filter|float|format|frozenset|getattr|globals|hasattr|hash|help|hex|id|input|int|intern|isinstance|issubclass|iter|len|list|locals|long|map|max|memoryview|min|next|object|oct|open|ord|pow|property|range|raw_input|reduce|reload|repr|reversed|round|set|setattr|slice|sorted|staticmethod|str|sum|super|tuple|type|unichr|unicode|vars|xrange|zip)\b/,
    boolean: /\b(?:False|None|True)\b/,
    number: /\b0(?:b(?:_?[01])+|o(?:_?[0-7])+|x(?:_?[a-f0-9])+)\b|(?:\b\d+(?:_\d+)*(?:\.(?:\d+(?:_\d+)*)?)?|\B\.\d+(?:_\d+)*)(?:e[+-]?\d+(?:_\d+)*)?j?(?!\w)/i,
    operator: /[-+%=]=?|!=|:=|\*\*?=?|\/\/?=?|<[<=>]?|>[=>]?|[&|^~]/,
    punctuation: /[{}[\];(),.:]/
  }, Prism.languages.python["string-interpolation"].inside.interpolation.inside.rest = Prism.languages.python, Prism.languages.py = Prism.languages.python), Ie;
}
gi();
(function(V) {
  var l = /\\(?:[^a-z()[\]]|[a-z*]+)/i, a = {
    "equation-command": {
      pattern: l,
      alias: "regex"
    }
  };
  V.languages.latex = {
    comment: /%.*/,
    // the verbatim environment prints whitespace to the document
    cdata: {
      pattern: /(\\begin\{((?:lstlisting|verbatim)\*?)\})[\s\S]*?(?=\\end\{\2\})/,
      lookbehind: !0
    },
    /*
     * equations can be between $$ $$ or $ $ or \( \) or \[ \]
     * (all are multiline)
     */
    equation: [
      {
        pattern: /\$\$(?:\\[\s\S]|[^\\$])+\$\$|\$(?:\\[\s\S]|[^\\$])+\$|\\\([\s\S]*?\\\)|\\\[[\s\S]*?\\\]/,
        inside: a,
        alias: "string"
      },
      {
        pattern: /(\\begin\{((?:align|eqnarray|equation|gather|math|multline)\*?)\})[\s\S]*?(?=\\end\{\2\})/,
        lookbehind: !0,
        inside: a,
        alias: "string"
      }
    ],
    /*
     * arguments which are keywords or references are highlighted
     * as keywords
     */
    keyword: {
      pattern: /(\\(?:begin|cite|documentclass|end|label|ref|usepackage)(?:\[[^\]]+\])?\{)[^}]+(?=\})/,
      lookbehind: !0
    },
    url: {
      pattern: /(\\url\{)[^}]+(?=\})/,
      lookbehind: !0
    },
    /*
     * section or chapter headlines are highlighted as bold so that
     * they stand out more
     */
    headline: {
      pattern: /(\\(?:chapter|frametitle|paragraph|part|section|subparagraph|subsection|subsubparagraph|subsubsection|subsubsubparagraph)\*?(?:\[[^\]]+\])?\{)[^}]+(?=\})/,
      lookbehind: !0,
      alias: "class-name"
    },
    function: {
      pattern: l,
      alias: "selector"
    },
    punctuation: /[[\]{}&]/
  }, V.languages.tex = V.languages.latex, V.languages.context = V.languages.latex;
})(Prism);
(function(V) {
  var l = "\\b(?:BASH|BASHOPTS|BASH_ALIASES|BASH_ARGC|BASH_ARGV|BASH_CMDS|BASH_COMPLETION_COMPAT_DIR|BASH_LINENO|BASH_REMATCH|BASH_SOURCE|BASH_VERSINFO|BASH_VERSION|COLORTERM|COLUMNS|COMP_WORDBREAKS|DBUS_SESSION_BUS_ADDRESS|DEFAULTS_PATH|DESKTOP_SESSION|DIRSTACK|DISPLAY|EUID|GDMSESSION|GDM_LANG|GNOME_KEYRING_CONTROL|GNOME_KEYRING_PID|GPG_AGENT_INFO|GROUPS|HISTCONTROL|HISTFILE|HISTFILESIZE|HISTSIZE|HOME|HOSTNAME|HOSTTYPE|IFS|INSTANCE|JOB|LANG|LANGUAGE|LC_ADDRESS|LC_ALL|LC_IDENTIFICATION|LC_MEASUREMENT|LC_MONETARY|LC_NAME|LC_NUMERIC|LC_PAPER|LC_TELEPHONE|LC_TIME|LESSCLOSE|LESSOPEN|LINES|LOGNAME|LS_COLORS|MACHTYPE|MAILCHECK|MANDATORY_PATH|NO_AT_BRIDGE|OLDPWD|OPTERR|OPTIND|ORBIT_SOCKETDIR|OSTYPE|PAPERSIZE|PATH|PIPESTATUS|PPID|PS1|PS2|PS3|PS4|PWD|RANDOM|REPLY|SECONDS|SELINUX_INIT|SESSION|SESSIONTYPE|SESSION_MANAGER|SHELL|SHELLOPTS|SHLVL|SSH_AUTH_SOCK|TERM|UID|UPSTART_EVENTS|UPSTART_INSTANCE|UPSTART_JOB|UPSTART_SESSION|USER|WINDOWID|XAUTHORITY|XDG_CONFIG_DIRS|XDG_CURRENT_DESKTOP|XDG_DATA_DIRS|XDG_GREETER_DATA_DIR|XDG_MENU_PREFIX|XDG_RUNTIME_DIR|XDG_SEAT|XDG_SEAT_PATH|XDG_SESSION_DESKTOP|XDG_SESSION_ID|XDG_SESSION_PATH|XDG_SESSION_TYPE|XDG_VTNR|XMODIFIERS)\\b", a = {
    pattern: /(^(["']?)\w+\2)[ \t]+\S.*/,
    lookbehind: !0,
    alias: "punctuation",
    // this looks reasonably well in all themes
    inside: null
    // see below
  }, s = {
    bash: a,
    environment: {
      pattern: RegExp("\\$" + l),
      alias: "constant"
    },
    variable: [
      // [0]: Arithmetic Environment
      {
        pattern: /\$?\(\([\s\S]+?\)\)/,
        greedy: !0,
        inside: {
          // If there is a $ sign at the beginning highlight $(( and )) as variable
          variable: [
            {
              pattern: /(^\$\(\([\s\S]+)\)\)/,
              lookbehind: !0
            },
            /^\$\(\(/
          ],
          number: /\b0x[\dA-Fa-f]+\b|(?:\b\d+(?:\.\d*)?|\B\.\d+)(?:[Ee]-?\d+)?/,
          // Operators according to https://www.gnu.org/software/bash/manual/bashref.html#Shell-Arithmetic
          operator: /--|\+\+|\*\*=?|<<=?|>>=?|&&|\|\||[=!+\-*/%<>^&|]=?|[?~:]/,
          // If there is no $ sign at the beginning highlight (( and )) as punctuation
          punctuation: /\(\(?|\)\)?|,|;/
        }
      },
      // [1]: Command Substitution
      {
        pattern: /\$\((?:\([^)]+\)|[^()])+\)|`[^`]+`/,
        greedy: !0,
        inside: {
          variable: /^\$\(|^`|\)$|`$/
        }
      },
      // [2]: Brace expansion
      {
        pattern: /\$\{[^}]+\}/,
        greedy: !0,
        inside: {
          operator: /:[-=?+]?|[!\/]|##?|%%?|\^\^?|,,?/,
          punctuation: /[\[\]]/,
          environment: {
            pattern: RegExp("(\\{)" + l),
            lookbehind: !0,
            alias: "constant"
          }
        }
      },
      /\$(?:\w+|[#?*!@$])/
    ],
    // Escape sequences from echo and printf's manuals, and escaped quotes.
    entity: /\\(?:[abceEfnrtv\\"]|O?[0-7]{1,3}|U[0-9a-fA-F]{8}|u[0-9a-fA-F]{4}|x[0-9a-fA-F]{1,2})/
  };
  V.languages.bash = {
    shebang: {
      pattern: /^#!\s*\/.*/,
      alias: "important"
    },
    comment: {
      pattern: /(^|[^"{\\$])#.*/,
      lookbehind: !0
    },
    "function-name": [
      // a) function foo {
      // b) foo() {
      // c) function foo() {
      // but not “foo {”
      {
        // a) and c)
        pattern: /(\bfunction\s+)[\w-]+(?=(?:\s*\(?:\s*\))?\s*\{)/,
        lookbehind: !0,
        alias: "function"
      },
      {
        // b)
        pattern: /\b[\w-]+(?=\s*\(\s*\)\s*\{)/,
        alias: "function"
      }
    ],
    // Highlight variable names as variables in for and select beginnings.
    "for-or-select": {
      pattern: /(\b(?:for|select)\s+)\w+(?=\s+in\s)/,
      alias: "variable",
      lookbehind: !0
    },
    // Highlight variable names as variables in the left-hand part
    // of assignments (“=” and “+=”).
    "assign-left": {
      pattern: /(^|[\s;|&]|[<>]\()\w+(?:\.\w+)*(?=\+?=)/,
      inside: {
        environment: {
          pattern: RegExp("(^|[\\s;|&]|[<>]\\()" + l),
          lookbehind: !0,
          alias: "constant"
        }
      },
      alias: "variable",
      lookbehind: !0
    },
    // Highlight parameter names as variables
    parameter: {
      pattern: /(^|\s)-{1,2}(?:\w+:[+-]?)?\w+(?:\.\w+)*(?=[=\s]|$)/,
      alias: "variable",
      lookbehind: !0
    },
    string: [
      // Support for Here-documents https://en.wikipedia.org/wiki/Here_document
      {
        pattern: /((?:^|[^<])<<-?\s*)(\w+)\s[\s\S]*?(?:\r?\n|\r)\2/,
        lookbehind: !0,
        greedy: !0,
        inside: s
      },
      // Here-document with quotes around the tag
      // → No expansion (so no “inside”).
      {
        pattern: /((?:^|[^<])<<-?\s*)(["'])(\w+)\2\s[\s\S]*?(?:\r?\n|\r)\3/,
        lookbehind: !0,
        greedy: !0,
        inside: {
          bash: a
        }
      },
      // “Normal” string
      {
        // https://www.gnu.org/software/bash/manual/html_node/Double-Quotes.html
        pattern: /(^|[^\\](?:\\\\)*)"(?:\\[\s\S]|\$\([^)]+\)|\$(?!\()|`[^`]+`|[^"\\`$])*"/,
        lookbehind: !0,
        greedy: !0,
        inside: s
      },
      {
        // https://www.gnu.org/software/bash/manual/html_node/Single-Quotes.html
        pattern: /(^|[^$\\])'[^']*'/,
        lookbehind: !0,
        greedy: !0
      },
      {
        // https://www.gnu.org/software/bash/manual/html_node/ANSI_002dC-Quoting.html
        pattern: /\$'(?:[^'\\]|\\[\s\S])*'/,
        greedy: !0,
        inside: {
          entity: s.entity
        }
      }
    ],
    environment: {
      pattern: RegExp("\\$?" + l),
      alias: "constant"
    },
    variable: s.variable,
    function: {
      pattern: /(^|[\s;|&]|[<>]\()(?:add|apropos|apt|apt-cache|apt-get|aptitude|aspell|automysqlbackup|awk|basename|bash|bc|bconsole|bg|bzip2|cal|cargo|cat|cfdisk|chgrp|chkconfig|chmod|chown|chroot|cksum|clear|cmp|column|comm|composer|cp|cron|crontab|csplit|curl|cut|date|dc|dd|ddrescue|debootstrap|df|diff|diff3|dig|dir|dircolors|dirname|dirs|dmesg|docker|docker-compose|du|egrep|eject|env|ethtool|expand|expect|expr|fdformat|fdisk|fg|fgrep|file|find|fmt|fold|format|free|fsck|ftp|fuser|gawk|git|gparted|grep|groupadd|groupdel|groupmod|groups|grub-mkconfig|gzip|halt|head|hg|history|host|hostname|htop|iconv|id|ifconfig|ifdown|ifup|import|install|ip|java|jobs|join|kill|killall|less|link|ln|locate|logname|logrotate|look|lpc|lpr|lprint|lprintd|lprintq|lprm|ls|lsof|lynx|make|man|mc|mdadm|mkconfig|mkdir|mke2fs|mkfifo|mkfs|mkisofs|mknod|mkswap|mmv|more|most|mount|mtools|mtr|mutt|mv|nano|nc|netstat|nice|nl|node|nohup|notify-send|npm|nslookup|op|open|parted|passwd|paste|pathchk|ping|pkill|pnpm|podman|podman-compose|popd|pr|printcap|printenv|ps|pushd|pv|quota|quotacheck|quotactl|ram|rar|rcp|reboot|remsync|rename|renice|rev|rm|rmdir|rpm|rsync|scp|screen|sdiff|sed|sendmail|seq|service|sftp|sh|shellcheck|shuf|shutdown|sleep|slocate|sort|split|ssh|stat|strace|su|sudo|sum|suspend|swapon|sync|sysctl|tac|tail|tar|tee|time|timeout|top|touch|tr|traceroute|tsort|tty|umount|uname|unexpand|uniq|units|unrar|unshar|unzip|update-grub|uptime|useradd|userdel|usermod|users|uudecode|uuencode|v|vcpkg|vdir|vi|vim|virsh|vmstat|wait|watch|wc|wget|whereis|which|who|whoami|write|xargs|xdg-open|yarn|yes|zenity|zip|zsh|zypper)(?=$|[)\s;|&])/,
      lookbehind: !0
    },
    keyword: {
      pattern: /(^|[\s;|&]|[<>]\()(?:case|do|done|elif|else|esac|fi|for|function|if|in|select|then|until|while)(?=$|[)\s;|&])/,
      lookbehind: !0
    },
    // https://www.gnu.org/software/bash/manual/html_node/Shell-Builtin-Commands.html
    builtin: {
      pattern: /(^|[\s;|&]|[<>]\()(?:\.|:|alias|bind|break|builtin|caller|cd|command|continue|declare|echo|enable|eval|exec|exit|export|getopts|hash|help|let|local|logout|mapfile|printf|pwd|read|readarray|readonly|return|set|shift|shopt|source|test|times|trap|type|typeset|ulimit|umask|unalias|unset)(?=$|[)\s;|&])/,
      lookbehind: !0,
      // Alias added to make those easier to distinguish from strings.
      alias: "class-name"
    },
    boolean: {
      pattern: /(^|[\s;|&]|[<>]\()(?:false|true)(?=$|[)\s;|&])/,
      lookbehind: !0
    },
    "file-descriptor": {
      pattern: /\B&\d\b/,
      alias: "important"
    },
    operator: {
      // Lots of redirections here, but not just that.
      pattern: /\d?<>|>\||\+=|=[=~]?|!=?|<<[<-]?|[&\d]?>>|\d[<>]&?|[<>][&=]?|&[>&]?|\|[&|]?/,
      inside: {
        "file-descriptor": {
          pattern: /^\d/,
          alias: "important"
        }
      }
    },
    punctuation: /\$?\(\(?|\)\)?|\.\.|[{}[\];\\]/,
    number: {
      pattern: /(^|\s)(?:[1-9]\d*|0)(?:[.,]\d+)?\b/,
      lookbehind: !0
    }
  }, a.inside = V.languages.bash;
  for (var S = [
    "comment",
    "function-name",
    "for-or-select",
    "assign-left",
    "parameter",
    "string",
    "environment",
    "function",
    "keyword",
    "builtin",
    "boolean",
    "file-descriptor",
    "operator",
    "punctuation",
    "number"
  ], v = s.variable[1].inside, _ = 0; _ < S.length; _++)
    v[S[_]] = V.languages.bash[S[_]];
  V.languages.sh = V.languages.bash, V.languages.shell = V.languages.bash;
})(Prism);
Prism.languages.c = Prism.languages.extend("clike", {
  comment: {
    pattern: /\/\/(?:[^\r\n\\]|\\(?:\r\n?|\n|(?![\r\n])))*|\/\*[\s\S]*?(?:\*\/|$)/,
    greedy: !0
  },
  string: {
    // https://en.cppreference.com/w/c/language/string_literal
    pattern: /"(?:\\(?:\r\n|[\s\S])|[^"\\\r\n])*"/,
    greedy: !0
  },
  "class-name": {
    pattern: /(\b(?:enum|struct)\s+(?:__attribute__\s*\(\([\s\S]*?\)\)\s*)?)\w+|\b[a-z]\w*_t\b/,
    lookbehind: !0
  },
  keyword: /\b(?:_Alignas|_Alignof|_Atomic|_Bool|_Complex|_Generic|_Imaginary|_Noreturn|_Static_assert|_Thread_local|__attribute__|asm|auto|break|case|char|const|continue|default|do|double|else|enum|extern|float|for|goto|if|inline|int|long|register|return|short|signed|sizeof|static|struct|switch|typedef|typeof|union|unsigned|void|volatile|while)\b/,
  function: /\b[a-z_]\w*(?=\s*\()/i,
  number: /(?:\b0x(?:[\da-f]+(?:\.[\da-f]*)?|\.[\da-f]+)(?:p[+-]?\d+)?|(?:\b\d+(?:\.\d*)?|\B\.\d+)(?:e[+-]?\d+)?)[ful]{0,4}/i,
  operator: />>=?|<<=?|->|([-+&|:])\1|[?:~]|[-+*/%&|^!=<>]=?/
});
Prism.languages.insertBefore("c", "string", {
  char: {
    // https://en.cppreference.com/w/c/language/character_constant
    pattern: /'(?:\\(?:\r\n|[\s\S])|[^'\\\r\n]){0,32}'/,
    greedy: !0
  }
});
Prism.languages.insertBefore("c", "string", {
  macro: {
    // allow for multiline macro definitions
    // spaces after the # character compile fine with gcc
    pattern: /(^[\t ]*)#\s*[a-z](?:[^\r\n\\/]|\/(?!\*)|\/\*(?:[^*]|\*(?!\/))*\*\/|\\(?:\r\n|[\s\S]))*/im,
    lookbehind: !0,
    greedy: !0,
    alias: "property",
    inside: {
      string: [
        {
          // highlight the path of the include statement as a string
          pattern: /^(#\s*include\s*)<[^>]+>/,
          lookbehind: !0
        },
        Prism.languages.c.string
      ],
      char: Prism.languages.c.char,
      comment: Prism.languages.c.comment,
      "macro-name": [
        {
          pattern: /(^#\s*define\s+)\w+\b(?!\()/i,
          lookbehind: !0
        },
        {
          pattern: /(^#\s*define\s+)\w+\b(?=\()/i,
          lookbehind: !0,
          alias: "function"
        }
      ],
      // highlight macro directives as keywords
      directive: {
        pattern: /^(#\s*)[a-z]+/,
        lookbehind: !0,
        alias: "keyword"
      },
      "directive-hash": /^#/,
      punctuation: /##|\\(?=[\r\n])/,
      expression: {
        pattern: /\S[\s\S]*/,
        inside: Prism.languages.c
      }
    }
  }
});
Prism.languages.insertBefore("c", "function", {
  // highlight predefined macros as constants
  constant: /\b(?:EOF|NULL|SEEK_CUR|SEEK_END|SEEK_SET|__DATE__|__FILE__|__LINE__|__TIMESTAMP__|__TIME__|__func__|stderr|stdin|stdout)\b/
});
delete Prism.languages.c.boolean;
var Pe = {}, Ne;
function mi() {
  return Ne || (Ne = 1, (function(V) {
    var l = /\b(?:alignas|alignof|asm|auto|bool|break|case|catch|char|char16_t|char32_t|char8_t|class|co_await|co_return|co_yield|compl|concept|const|const_cast|consteval|constexpr|constinit|continue|decltype|default|delete|do|double|dynamic_cast|else|enum|explicit|export|extern|final|float|for|friend|goto|if|import|inline|int|int16_t|int32_t|int64_t|int8_t|long|module|mutable|namespace|new|noexcept|nullptr|operator|override|private|protected|public|register|reinterpret_cast|requires|return|short|signed|sizeof|static|static_assert|static_cast|struct|switch|template|this|thread_local|throw|try|typedef|typeid|typename|uint16_t|uint32_t|uint64_t|uint8_t|union|unsigned|using|virtual|void|volatile|wchar_t|while)\b/, a = /\b(?!<keyword>)\w+(?:\s*\.\s*\w+)*\b/.source.replace(/<keyword>/g, function() {
      return l.source;
    });
    V.languages.cpp = V.languages.extend("c", {
      "class-name": [
        {
          pattern: RegExp(/(\b(?:class|concept|enum|struct|typename)\s+)(?!<keyword>)\w+/.source.replace(/<keyword>/g, function() {
            return l.source;
          })),
          lookbehind: !0
        },
        // This is intended to capture the class name of method implementations like:
        //   void foo::bar() const {}
        // However! The `foo` in the above example could also be a namespace, so we only capture the class name if
        // it starts with an uppercase letter. This approximation should give decent results.
        /\b[A-Z]\w*(?=\s*::\s*\w+\s*\()/,
        // This will capture the class name before destructors like:
        //   Foo::~Foo() {}
        /\b[A-Z_]\w*(?=\s*::\s*~\w+\s*\()/i,
        // This also intends to capture the class name of method implementations but here the class has template
        // parameters, so it can't be a namespace (until C++ adds generic namespaces).
        /\b\w+(?=\s*<(?:[^<>]|<(?:[^<>]|<[^<>]*>)*>)*>\s*::\s*\w+\s*\()/
      ],
      keyword: l,
      number: {
        pattern: /(?:\b0b[01']+|\b0x(?:[\da-f']+(?:\.[\da-f']*)?|\.[\da-f']+)(?:p[+-]?[\d']+)?|(?:\b[\d']+(?:\.[\d']*)?|\B\.[\d']+)(?:e[+-]?[\d']+)?)[ful]{0,4}/i,
        greedy: !0
      },
      operator: />>=?|<<=?|->|--|\+\+|&&|\|\||[?:~]|<=>|[-+*/%&|^!=<>]=?|\b(?:and|and_eq|bitand|bitor|not|not_eq|or|or_eq|xor|xor_eq)\b/,
      boolean: /\b(?:false|true)\b/
    }), V.languages.insertBefore("cpp", "string", {
      module: {
        // https://en.cppreference.com/w/cpp/language/modules
        pattern: RegExp(
          /(\b(?:import|module)\s+)/.source + "(?:" + // header-name
          /"(?:\\(?:\r\n|[\s\S])|[^"\\\r\n])*"|<[^<>\r\n]*>/.source + "|" + // module name or partition or both
          /<mod-name>(?:\s*:\s*<mod-name>)?|:\s*<mod-name>/.source.replace(/<mod-name>/g, function() {
            return a;
          }) + ")"
        ),
        lookbehind: !0,
        greedy: !0,
        inside: {
          string: /^[<"][\s\S]+/,
          operator: /:/,
          punctuation: /\./
        }
      },
      "raw-string": {
        pattern: /R"([^()\\ ]{0,16})\([\s\S]*?\)\1"/,
        alias: "string",
        greedy: !0
      }
    }), V.languages.insertBefore("cpp", "keyword", {
      "generic-function": {
        pattern: /\b(?!operator\b)[a-z_]\w*\s*<(?:[^<>]|<[^<>]*>)*>(?=\s*\()/i,
        inside: {
          function: /^\w+/,
          generic: {
            pattern: /<[\s\S]+/,
            alias: "class-name",
            inside: V.languages.cpp
          }
        }
      }
    }), V.languages.insertBefore("cpp", "operator", {
      "double-colon": {
        pattern: /::/,
        alias: "punctuation"
      }
    }), V.languages.insertBefore("cpp", "class-name", {
      // the base clause is an optional list of parent classes
      // https://en.cppreference.com/w/cpp/language/class
      "base-clause": {
        pattern: /(\b(?:class|struct)\s+\w+\s*:\s*)[^;{}"'\s]+(?:\s+[^;{}"'\s]+)*(?=\s*[;{])/,
        lookbehind: !0,
        greedy: !0,
        inside: V.languages.extend("cpp", {})
      }
    }), V.languages.insertBefore("inside", "double-colon", {
      // All untokenized words that are not namespaces should be class names
      "class-name": /\b[a-z_]\w*\b(?!\s*::)/i
    }, V.languages.cpp["base-clause"]);
  })(Prism)), Pe;
}
mi();
Prism.languages.json = {
  property: {
    pattern: /(^|[^\\])"(?:\\.|[^\\"\r\n])*"(?=\s*:)/,
    lookbehind: !0,
    greedy: !0
  },
  string: {
    pattern: /(^|[^\\])"(?:\\.|[^\\"\r\n])*"(?!\s*:)/,
    lookbehind: !0,
    greedy: !0
  },
  comment: {
    pattern: /\/\/.*|\/\*[\s\S]*?(?:\*\/|$)/,
    greedy: !0
  },
  number: /-?\b\d+(?:\.\d+)?(?:e[+-]?\d+)?\b/i,
  punctuation: /[{}[\],]/,
  operator: /:/,
  boolean: /\b(?:false|true)\b/,
  null: {
    pattern: /\bnull\b/,
    alias: "keyword"
  }
};
Prism.languages.webmanifest = Prism.languages.json;
Prism.languages.sql = {
  comment: {
    pattern: /(^|[^\\])(?:\/\*[\s\S]*?\*\/|(?:--|\/\/|#).*)/,
    lookbehind: !0
  },
  variable: [
    {
      pattern: /@(["'`])(?:\\[\s\S]|(?!\1)[^\\])+\1/,
      greedy: !0
    },
    /@[\w.$]+/
  ],
  string: {
    pattern: /(^|[^@\\])("|')(?:\\[\s\S]|(?!\2)[^\\]|\2\2)*\2/,
    greedy: !0,
    lookbehind: !0
  },
  identifier: {
    pattern: /(^|[^@\\])`(?:\\[\s\S]|[^`\\]|``)*`/,
    greedy: !0,
    lookbehind: !0,
    inside: {
      punctuation: /^`|`$/
    }
  },
  function: /\b(?:AVG|COUNT|FIRST|FORMAT|LAST|LCASE|LEN|MAX|MID|MIN|MOD|NOW|ROUND|SUM|UCASE)(?=\s*\()/i,
  // Should we highlight user defined functions too?
  keyword: /\b(?:ACTION|ADD|AFTER|ALGORITHM|ALL|ALTER|ANALYZE|ANY|APPLY|AS|ASC|AUTHORIZATION|AUTO_INCREMENT|BACKUP|BDB|BEGIN|BERKELEYDB|BIGINT|BINARY|BIT|BLOB|BOOL|BOOLEAN|BREAK|BROWSE|BTREE|BULK|BY|CALL|CASCADED?|CASE|CHAIN|CHAR(?:ACTER|SET)?|CHECK(?:POINT)?|CLOSE|CLUSTERED|COALESCE|COLLATE|COLUMNS?|COMMENT|COMMIT(?:TED)?|COMPUTE|CONNECT|CONSISTENT|CONSTRAINT|CONTAINS(?:TABLE)?|CONTINUE|CONVERT|CREATE|CROSS|CURRENT(?:_DATE|_TIME|_TIMESTAMP|_USER)?|CURSOR|CYCLE|DATA(?:BASES?)?|DATE(?:TIME)?|DAY|DBCC|DEALLOCATE|DEC|DECIMAL|DECLARE|DEFAULT|DEFINER|DELAYED|DELETE|DELIMITERS?|DENY|DESC|DESCRIBE|DETERMINISTIC|DISABLE|DISCARD|DISK|DISTINCT|DISTINCTROW|DISTRIBUTED|DO|DOUBLE|DROP|DUMMY|DUMP(?:FILE)?|DUPLICATE|ELSE(?:IF)?|ENABLE|ENCLOSED|END|ENGINE|ENUM|ERRLVL|ERRORS|ESCAPED?|EXCEPT|EXEC(?:UTE)?|EXISTS|EXIT|EXPLAIN|EXTENDED|FETCH|FIELDS|FILE|FILLFACTOR|FIRST|FIXED|FLOAT|FOLLOWING|FOR(?: EACH ROW)?|FORCE|FOREIGN|FREETEXT(?:TABLE)?|FROM|FULL|FUNCTION|GEOMETRY(?:COLLECTION)?|GLOBAL|GOTO|GRANT|GROUP|HANDLER|HASH|HAVING|HOLDLOCK|HOUR|IDENTITY(?:COL|_INSERT)?|IF|IGNORE|IMPORT|INDEX|INFILE|INNER|INNODB|INOUT|INSERT|INT|INTEGER|INTERSECT|INTERVAL|INTO|INVOKER|ISOLATION|ITERATE|JOIN|KEYS?|KILL|LANGUAGE|LAST|LEAVE|LEFT|LEVEL|LIMIT|LINENO|LINES|LINESTRING|LOAD|LOCAL|LOCK|LONG(?:BLOB|TEXT)|LOOP|MATCH(?:ED)?|MEDIUM(?:BLOB|INT|TEXT)|MERGE|MIDDLEINT|MINUTE|MODE|MODIFIES|MODIFY|MONTH|MULTI(?:LINESTRING|POINT|POLYGON)|NATIONAL|NATURAL|NCHAR|NEXT|NO|NONCLUSTERED|NULLIF|NUMERIC|OFF?|OFFSETS?|ON|OPEN(?:DATASOURCE|QUERY|ROWSET)?|OPTIMIZE|OPTION(?:ALLY)?|ORDER|OUT(?:ER|FILE)?|OVER|PARTIAL|PARTITION|PERCENT|PIVOT|PLAN|POINT|POLYGON|PRECEDING|PRECISION|PREPARE|PREV|PRIMARY|PRINT|PRIVILEGES|PROC(?:EDURE)?|PUBLIC|PURGE|QUICK|RAISERROR|READS?|REAL|RECONFIGURE|REFERENCES|RELEASE|RENAME|REPEAT(?:ABLE)?|REPLACE|REPLICATION|REQUIRE|RESIGNAL|RESTORE|RESTRICT|RETURN(?:ING|S)?|REVOKE|RIGHT|ROLLBACK|ROUTINE|ROW(?:COUNT|GUIDCOL|S)?|RTREE|RULE|SAVE(?:POINT)?|SCHEMA|SECOND|SELECT|SERIAL(?:IZABLE)?|SESSION(?:_USER)?|SET(?:USER)?|SHARE|SHOW|SHUTDOWN|SIMPLE|SMALLINT|SNAPSHOT|SOME|SONAME|SQL|START(?:ING)?|STATISTICS|STATUS|STRIPED|SYSTEM_USER|TABLES?|TABLESPACE|TEMP(?:ORARY|TABLE)?|TERMINATED|TEXT(?:SIZE)?|THEN|TIME(?:STAMP)?|TINY(?:BLOB|INT|TEXT)|TOP?|TRAN(?:SACTIONS?)?|TRIGGER|TRUNCATE|TSEQUAL|TYPES?|UNBOUNDED|UNCOMMITTED|UNDEFINED|UNION|UNIQUE|UNLOCK|UNPIVOT|UNSIGNED|UPDATE(?:TEXT)?|USAGE|USE|USER|USING|VALUES?|VAR(?:BINARY|CHAR|CHARACTER|YING)|VIEW|WAITFOR|WARNINGS|WHEN|WHERE|WHILE|WITH(?: ROLLUP|IN)?|WORK|WRITE(?:TEXT)?|YEAR)\b/i,
  boolean: /\b(?:FALSE|NULL|TRUE)\b/i,
  number: /\b0x[\da-f]+\b|\b\d+(?:\.\d*)?|\B\.\d+\b/i,
  operator: /[-+*\/=%^~]|&&?|\|\|?|!=?|<(?:=>?|<|>)?|>[>=]?|\b(?:AND|BETWEEN|DIV|ILIKE|IN|IS|LIKE|NOT|OR|REGEXP|RLIKE|SOUNDS LIKE|XOR)\b/i,
  punctuation: /[;[\]()`,.]/
};
var Oe = {}, Be;
function vi() {
  return Be || (Be = 1, (function(V) {
    var l = /\b(?:abstract|assert|boolean|break|byte|case|catch|char|class|const|continue|default|do|double|else|enum|exports|extends|final|finally|float|for|goto|if|implements|import|instanceof|int|interface|long|module|native|new|non-sealed|null|open|opens|package|permits|private|protected|provides|public|record(?!\s*[(){}[\]<>=%~.:,;?+\-*/&|^])|requires|return|sealed|short|static|strictfp|super|switch|synchronized|this|throw|throws|to|transient|transitive|try|uses|var|void|volatile|while|with|yield)\b/, a = /(?:[a-z]\w*\s*\.\s*)*(?:[A-Z]\w*\s*\.\s*)*/.source, s = {
      pattern: RegExp(/(^|[^\w.])/.source + a + /[A-Z](?:[\d_A-Z]*[a-z]\w*)?\b/.source),
      lookbehind: !0,
      inside: {
        namespace: {
          pattern: /^[a-z]\w*(?:\s*\.\s*[a-z]\w*)*(?:\s*\.)?/,
          inside: {
            punctuation: /\./
          }
        },
        punctuation: /\./
      }
    };
    V.languages.java = V.languages.extend("clike", {
      string: {
        pattern: /(^|[^\\])"(?:\\.|[^"\\\r\n])*"/,
        lookbehind: !0,
        greedy: !0
      },
      "class-name": [
        s,
        {
          // variables, parameters, and constructor references
          // this to support class names (or generic parameters) which do not contain a lower case letter (also works for methods)
          pattern: RegExp(/(^|[^\w.])/.source + a + /[A-Z]\w*(?=\s+\w+\s*[;,=()]|\s*(?:\[[\s,]*\]\s*)?::\s*new\b)/.source),
          lookbehind: !0,
          inside: s.inside
        },
        {
          // class names based on keyword
          // this to support class names (or generic parameters) which do not contain a lower case letter (also works for methods)
          pattern: RegExp(/(\b(?:class|enum|extends|implements|instanceof|interface|new|record|throws)\s+)/.source + a + /[A-Z]\w*\b/.source),
          lookbehind: !0,
          inside: s.inside
        }
      ],
      keyword: l,
      function: [
        V.languages.clike.function,
        {
          pattern: /(::\s*)[a-z_]\w*/,
          lookbehind: !0
        }
      ],
      number: /\b0b[01][01_]*L?\b|\b0x(?:\.[\da-f_p+-]+|[\da-f_]+(?:\.[\da-f_p+-]+)?)\b|(?:\b\d[\d_]*(?:\.[\d_]*)?|\B\.\d[\d_]*)(?:e[+-]?\d[\d_]*)?[dfl]?/i,
      operator: {
        pattern: /(^|[^.])(?:<<=?|>>>?=?|->|--|\+\+|&&|\|\||::|[?:~]|[-+*/%&|^!=<>]=?)/m,
        lookbehind: !0
      },
      constant: /\b[A-Z][A-Z_\d]+\b/
    }), V.languages.insertBefore("java", "string", {
      "triple-quoted-string": {
        // http://openjdk.java.net/jeps/355#Description
        pattern: /"""[ \t]*[\r\n](?:(?:"|"")?(?:\\.|[^"\\]))*"""/,
        greedy: !0,
        alias: "string"
      },
      char: {
        pattern: /'(?:\\.|[^'\\\r\n]){1,6}'/,
        greedy: !0
      }
    }), V.languages.insertBefore("java", "class-name", {
      annotation: {
        pattern: /(^|[^.])@\w+(?:\s*\.\s*\w+)*/,
        lookbehind: !0,
        alias: "punctuation"
      },
      generics: {
        pattern: /<(?:[\w\s,.?]|&(?!&)|<(?:[\w\s,.?]|&(?!&)|<(?:[\w\s,.?]|&(?!&)|<(?:[\w\s,.?]|&(?!&))*>)*>)*>)*>/,
        inside: {
          "class-name": s,
          keyword: l,
          punctuation: /[<>(),.:]/,
          operator: /[?&|]/
        }
      },
      import: [
        {
          pattern: RegExp(/(\bimport\s+)/.source + a + /(?:[A-Z]\w*|\*)(?=\s*;)/.source),
          lookbehind: !0,
          inside: {
            namespace: s.inside.namespace,
            punctuation: /\./,
            operator: /\*/,
            "class-name": /\w+/
          }
        },
        {
          pattern: RegExp(/(\bimport\s+static\s+)/.source + a + /(?:\w+|\*)(?=\s*;)/.source),
          lookbehind: !0,
          alias: "static",
          inside: {
            namespace: s.inside.namespace,
            static: /\b\w+$/,
            punctuation: /\./,
            operator: /\*/,
            "class-name": /\w+/
          }
        }
      ],
      namespace: {
        pattern: RegExp(
          /(\b(?:exports|import(?:\s+static)?|module|open|opens|package|provides|requires|to|transitive|uses|with)\s+)(?!<keyword>)[a-z]\w*(?:\.[a-z]\w*)*\.?/.source.replace(/<keyword>/g, function() {
            return l.source;
          })
        ),
        lookbehind: !0,
        inside: {
          punctuation: /\./
        }
      }
    });
  })(Prism)), Oe;
}
vi();
Prism.languages.go = Prism.languages.extend("clike", {
  string: {
    pattern: /(^|[^\\])"(?:\\.|[^"\\\r\n])*"|`[^`]*`/,
    lookbehind: !0,
    greedy: !0
  },
  keyword: /\b(?:break|case|chan|const|continue|default|defer|else|fallthrough|for|func|go(?:to)?|if|import|interface|map|package|range|return|select|struct|switch|type|var)\b/,
  boolean: /\b(?:_|false|iota|nil|true)\b/,
  number: [
    // binary and octal integers
    /\b0(?:b[01_]+|o[0-7_]+)i?\b/i,
    // hexadecimal integers and floats
    /\b0x(?:[a-f\d_]+(?:\.[a-f\d_]*)?|\.[a-f\d_]+)(?:p[+-]?\d+(?:_\d+)*)?i?(?!\w)/i,
    // decimal integers and floats
    /(?:\b\d[\d_]*(?:\.[\d_]*)?|\B\.\d[\d_]*)(?:e[+-]?[\d_]+)?i?(?!\w)/i
  ],
  operator: /[*\/%^!=]=?|\+[=+]?|-[=-]?|\|[=|]?|&(?:=|&|\^=?)?|>(?:>=?|=)?|<(?:<=?|=|-)?|:=|\.\.\./,
  builtin: /\b(?:append|bool|byte|cap|close|complex|complex(?:64|128)|copy|delete|error|float(?:32|64)|u?int(?:8|16|32|64)?|imag|len|make|new|panic|print(?:ln)?|real|recover|rune|string|uintptr)\b/
});
Prism.languages.insertBefore("go", "string", {
  char: {
    pattern: /'(?:\\.|[^'\\\r\n]){0,10}'/,
    greedy: !0
  }
});
delete Prism.languages.go["class-name"];
var He = {}, ze;
function bi() {
  return ze || (ze = 1, (function(V) {
    for (var l = /\/\*(?:[^*/]|\*(?!\/)|\/(?!\*)|<self>)*\*\//.source, a = 0; a < 2; a++)
      l = l.replace(/<self>/g, function() {
        return l;
      });
    l = l.replace(/<self>/g, function() {
      return /[^\s\S]/.source;
    }), V.languages.rust = {
      comment: [
        {
          pattern: RegExp(/(^|[^\\])/.source + l),
          lookbehind: !0,
          greedy: !0
        },
        {
          pattern: /(^|[^\\:])\/\/.*/,
          lookbehind: !0,
          greedy: !0
        }
      ],
      string: {
        pattern: /b?"(?:\\[\s\S]|[^\\"])*"|b?r(#*)"(?:[^"]|"(?!\1))*"\1/,
        greedy: !0
      },
      char: {
        pattern: /b?'(?:\\(?:x[0-7][\da-fA-F]|u\{(?:[\da-fA-F]_*){1,6}\}|.)|[^\\\r\n\t'])'/,
        greedy: !0
      },
      attribute: {
        pattern: /#!?\[(?:[^\[\]"]|"(?:\\[\s\S]|[^\\"])*")*\]/,
        greedy: !0,
        alias: "attr-name",
        inside: {
          string: null
          // see below
        }
      },
      // Closure params should not be confused with bitwise OR |
      "closure-params": {
        pattern: /([=(,:]\s*|\bmove\s*)\|[^|]*\||\|[^|]*\|(?=\s*(?:\{|->))/,
        lookbehind: !0,
        greedy: !0,
        inside: {
          "closure-punctuation": {
            pattern: /^\||\|$/,
            alias: "punctuation"
          },
          rest: null
          // see below
        }
      },
      "lifetime-annotation": {
        pattern: /'\w+/,
        alias: "symbol"
      },
      "fragment-specifier": {
        pattern: /(\$\w+:)[a-z]+/,
        lookbehind: !0,
        alias: "punctuation"
      },
      variable: /\$\w+/,
      "function-definition": {
        pattern: /(\bfn\s+)\w+/,
        lookbehind: !0,
        alias: "function"
      },
      "type-definition": {
        pattern: /(\b(?:enum|struct|trait|type|union)\s+)\w+/,
        lookbehind: !0,
        alias: "class-name"
      },
      "module-declaration": [
        {
          pattern: /(\b(?:crate|mod)\s+)[a-z][a-z_\d]*/,
          lookbehind: !0,
          alias: "namespace"
        },
        {
          pattern: /(\b(?:crate|self|super)\s*)::\s*[a-z][a-z_\d]*\b(?:\s*::(?:\s*[a-z][a-z_\d]*\s*::)*)?/,
          lookbehind: !0,
          alias: "namespace",
          inside: {
            punctuation: /::/
          }
        }
      ],
      keyword: [
        // https://github.com/rust-lang/reference/blob/master/src/keywords.md
        /\b(?:Self|abstract|as|async|await|become|box|break|const|continue|crate|do|dyn|else|enum|extern|final|fn|for|if|impl|in|let|loop|macro|match|mod|move|mut|override|priv|pub|ref|return|self|static|struct|super|trait|try|type|typeof|union|unsafe|unsized|use|virtual|where|while|yield)\b/,
        // primitives and str
        // https://doc.rust-lang.org/stable/rust-by-example/primitives.html
        /\b(?:bool|char|f(?:32|64)|[ui](?:8|16|32|64|128|size)|str)\b/
      ],
      // functions can technically start with an upper-case letter, but this will introduce a lot of false positives
      // and Rust's naming conventions recommend snake_case anyway.
      // https://doc.rust-lang.org/1.0.0/style/style/naming/README.html
      function: /\b[a-z_]\w*(?=\s*(?:::\s*<|\())/,
      macro: {
        pattern: /\b\w+!/,
        alias: "property"
      },
      constant: /\b[A-Z_][A-Z_\d]+\b/,
      "class-name": /\b[A-Z]\w*\b/,
      namespace: {
        pattern: /(?:\b[a-z][a-z_\d]*\s*::\s*)*\b[a-z][a-z_\d]*\s*::(?!\s*<)/,
        inside: {
          punctuation: /::/
        }
      },
      // Hex, oct, bin, dec numbers with visual separators and type suffix
      number: /\b(?:0x[\dA-Fa-f](?:_?[\dA-Fa-f])*|0o[0-7](?:_?[0-7])*|0b[01](?:_?[01])*|(?:(?:\d(?:_?\d)*)?\.)?\d(?:_?\d)*(?:[Ee][+-]?\d+)?)(?:_?(?:f32|f64|[iu](?:8|16|32|64|size)?))?\b/,
      boolean: /\b(?:false|true)\b/,
      punctuation: /->|\.\.=|\.{1,3}|::|[{}[\];(),:]/,
      operator: /[-+*\/%!^]=?|=[=>]?|&[&=]?|\|[|=]?|<<?=?|>>?=?|[@?]/
    }, V.languages.rust["closure-params"].inside.rest = V.languages.rust, V.languages.rust.attribute.inside.string = V.languages.rust.string;
  })(Prism)), He;
}
bi();
var Ue = {}, Ve;
function wi() {
  return Ve || (Ve = 1, (function(V) {
    var l = /\/\*[\s\S]*?\*\/|\/\/.*|#(?!\[).*/, a = [
      {
        pattern: /\b(?:false|true)\b/i,
        alias: "boolean"
      },
      {
        pattern: /(::\s*)\b[a-z_]\w*\b(?!\s*\()/i,
        greedy: !0,
        lookbehind: !0
      },
      {
        pattern: /(\b(?:case|const)\s+)\b[a-z_]\w*(?=\s*[;=])/i,
        greedy: !0,
        lookbehind: !0
      },
      /\b(?:null)\b/i,
      /\b[A-Z_][A-Z0-9_]*\b(?!\s*\()/
    ], s = /\b0b[01]+(?:_[01]+)*\b|\b0o[0-7]+(?:_[0-7]+)*\b|\b0x[\da-f]+(?:_[\da-f]+)*\b|(?:\b\d+(?:_\d+)*\.?(?:\d+(?:_\d+)*)?|\B\.\d+)(?:e[+-]?\d+)?/i, S = /<?=>|\?\?=?|\.{3}|\??->|[!=]=?=?|::|\*\*=?|--|\+\+|&&|\|\||<<|>>|[?~]|[/^|%*&<>.+-]=?/, v = /[{}\[\](),:;]/;
    V.languages.php = {
      delimiter: {
        pattern: /\?>$|^<\?(?:php(?=\s)|=)?/i,
        alias: "important"
      },
      comment: l,
      variable: /\$+(?:\w+\b|(?=\{))/,
      package: {
        pattern: /(namespace\s+|use\s+(?:function\s+)?)(?:\\?\b[a-z_]\w*)+\b(?!\\)/i,
        lookbehind: !0,
        inside: {
          punctuation: /\\/
        }
      },
      "class-name-definition": {
        pattern: /(\b(?:class|enum|interface|trait)\s+)\b[a-z_]\w*(?!\\)\b/i,
        lookbehind: !0,
        alias: "class-name"
      },
      "function-definition": {
        pattern: /(\bfunction\s+)[a-z_]\w*(?=\s*\()/i,
        lookbehind: !0,
        alias: "function"
      },
      keyword: [
        {
          pattern: /(\(\s*)\b(?:array|bool|boolean|float|int|integer|object|string)\b(?=\s*\))/i,
          alias: "type-casting",
          greedy: !0,
          lookbehind: !0
        },
        {
          pattern: /([(,?]\s*)\b(?:array(?!\s*\()|bool|callable|(?:false|null)(?=\s*\|)|float|int|iterable|mixed|object|self|static|string)\b(?=\s*\$)/i,
          alias: "type-hint",
          greedy: !0,
          lookbehind: !0
        },
        {
          pattern: /(\)\s*:\s*(?:\?\s*)?)\b(?:array(?!\s*\()|bool|callable|(?:false|null)(?=\s*\|)|float|int|iterable|mixed|never|object|self|static|string|void)\b/i,
          alias: "return-type",
          greedy: !0,
          lookbehind: !0
        },
        {
          pattern: /\b(?:array(?!\s*\()|bool|float|int|iterable|mixed|object|string|void)\b/i,
          alias: "type-declaration",
          greedy: !0
        },
        {
          pattern: /(\|\s*)(?:false|null)\b|\b(?:false|null)(?=\s*\|)/i,
          alias: "type-declaration",
          greedy: !0,
          lookbehind: !0
        },
        {
          pattern: /\b(?:parent|self|static)(?=\s*::)/i,
          alias: "static-context",
          greedy: !0
        },
        {
          // yield from
          pattern: /(\byield\s+)from\b/i,
          lookbehind: !0
        },
        // `class` is always a keyword unlike other keywords
        /\bclass\b/i,
        {
          // https://www.php.net/manual/en/reserved.keywords.php
          //
          // keywords cannot be preceded by "->"
          // the complex lookbehind means `(?<!(?:->|::)\s*)`
          pattern: /((?:^|[^\s>:]|(?:^|[^-])>|(?:^|[^:]):)\s*)\b(?:abstract|and|array|as|break|callable|case|catch|clone|const|continue|declare|default|die|do|echo|else|elseif|empty|enddeclare|endfor|endforeach|endif|endswitch|endwhile|enum|eval|exit|extends|final|finally|fn|for|foreach|function|global|goto|if|implements|include|include_once|instanceof|insteadof|interface|isset|list|match|namespace|never|new|or|parent|print|private|protected|public|readonly|require|require_once|return|self|static|switch|throw|trait|try|unset|use|var|while|xor|yield|__halt_compiler)\b/i,
          lookbehind: !0
        }
      ],
      "argument-name": {
        pattern: /([(,]\s*)\b[a-z_]\w*(?=\s*:(?!:))/i,
        lookbehind: !0
      },
      "class-name": [
        {
          pattern: /(\b(?:extends|implements|instanceof|new(?!\s+self|\s+static))\s+|\bcatch\s*\()\b[a-z_]\w*(?!\\)\b/i,
          greedy: !0,
          lookbehind: !0
        },
        {
          pattern: /(\|\s*)\b[a-z_]\w*(?!\\)\b/i,
          greedy: !0,
          lookbehind: !0
        },
        {
          pattern: /\b[a-z_]\w*(?!\\)\b(?=\s*\|)/i,
          greedy: !0
        },
        {
          pattern: /(\|\s*)(?:\\?\b[a-z_]\w*)+\b/i,
          alias: "class-name-fully-qualified",
          greedy: !0,
          lookbehind: !0,
          inside: {
            punctuation: /\\/
          }
        },
        {
          pattern: /(?:\\?\b[a-z_]\w*)+\b(?=\s*\|)/i,
          alias: "class-name-fully-qualified",
          greedy: !0,
          inside: {
            punctuation: /\\/
          }
        },
        {
          pattern: /(\b(?:extends|implements|instanceof|new(?!\s+self\b|\s+static\b))\s+|\bcatch\s*\()(?:\\?\b[a-z_]\w*)+\b(?!\\)/i,
          alias: "class-name-fully-qualified",
          greedy: !0,
          lookbehind: !0,
          inside: {
            punctuation: /\\/
          }
        },
        {
          pattern: /\b[a-z_]\w*(?=\s*\$)/i,
          alias: "type-declaration",
          greedy: !0
        },
        {
          pattern: /(?:\\?\b[a-z_]\w*)+(?=\s*\$)/i,
          alias: ["class-name-fully-qualified", "type-declaration"],
          greedy: !0,
          inside: {
            punctuation: /\\/
          }
        },
        {
          pattern: /\b[a-z_]\w*(?=\s*::)/i,
          alias: "static-context",
          greedy: !0
        },
        {
          pattern: /(?:\\?\b[a-z_]\w*)+(?=\s*::)/i,
          alias: ["class-name-fully-qualified", "static-context"],
          greedy: !0,
          inside: {
            punctuation: /\\/
          }
        },
        {
          pattern: /([(,?]\s*)[a-z_]\w*(?=\s*\$)/i,
          alias: "type-hint",
          greedy: !0,
          lookbehind: !0
        },
        {
          pattern: /([(,?]\s*)(?:\\?\b[a-z_]\w*)+(?=\s*\$)/i,
          alias: ["class-name-fully-qualified", "type-hint"],
          greedy: !0,
          lookbehind: !0,
          inside: {
            punctuation: /\\/
          }
        },
        {
          pattern: /(\)\s*:\s*(?:\?\s*)?)\b[a-z_]\w*(?!\\)\b/i,
          alias: "return-type",
          greedy: !0,
          lookbehind: !0
        },
        {
          pattern: /(\)\s*:\s*(?:\?\s*)?)(?:\\?\b[a-z_]\w*)+\b(?!\\)/i,
          alias: ["class-name-fully-qualified", "return-type"],
          greedy: !0,
          lookbehind: !0,
          inside: {
            punctuation: /\\/
          }
        }
      ],
      constant: a,
      function: {
        pattern: /(^|[^\\\w])\\?[a-z_](?:[\w\\]*\w)?(?=\s*\()/i,
        lookbehind: !0,
        inside: {
          punctuation: /\\/
        }
      },
      property: {
        pattern: /(->\s*)\w+/,
        lookbehind: !0
      },
      number: s,
      operator: S,
      punctuation: v
    };
    var _ = {
      pattern: /\{\$(?:\{(?:\{[^{}]+\}|[^{}]+)\}|[^{}])+\}|(^|[^\\{])\$+(?:\w+(?:\[[^\r\n\[\]]+\]|->\w+)?)/,
      lookbehind: !0,
      inside: V.languages.php
    }, x = [
      {
        pattern: /<<<'([^']+)'[\r\n](?:.*[\r\n])*?\1;/,
        alias: "nowdoc-string",
        greedy: !0,
        inside: {
          delimiter: {
            pattern: /^<<<'[^']+'|[a-z_]\w*;$/i,
            alias: "symbol",
            inside: {
              punctuation: /^<<<'?|[';]$/
            }
          }
        }
      },
      {
        pattern: /<<<(?:"([^"]+)"[\r\n](?:.*[\r\n])*?\1;|([a-z_]\w*)[\r\n](?:.*[\r\n])*?\2;)/i,
        alias: "heredoc-string",
        greedy: !0,
        inside: {
          delimiter: {
            pattern: /^<<<(?:"[^"]+"|[a-z_]\w*)|[a-z_]\w*;$/i,
            alias: "symbol",
            inside: {
              punctuation: /^<<<"?|[";]$/
            }
          },
          interpolation: _
        }
      },
      {
        pattern: /`(?:\\[\s\S]|[^\\`])*`/,
        alias: "backtick-quoted-string",
        greedy: !0
      },
      {
        pattern: /'(?:\\[\s\S]|[^\\'])*'/,
        alias: "single-quoted-string",
        greedy: !0
      },
      {
        pattern: /"(?:\\[\s\S]|[^\\"])*"/,
        alias: "double-quoted-string",
        greedy: !0,
        inside: {
          interpolation: _
        }
      }
    ];
    V.languages.insertBefore("php", "variable", {
      string: x,
      attribute: {
        pattern: /#\[(?:[^"'\/#]|\/(?![*/])|\/\/.*$|#(?!\[).*$|\/\*(?:[^*]|\*(?!\/))*\*\/|"(?:\\[\s\S]|[^\\"])*"|'(?:\\[\s\S]|[^\\'])*')+\](?=\s*[a-z$#])/im,
        greedy: !0,
        inside: {
          "attribute-content": {
            pattern: /^(#\[)[\s\S]+(?=\]$)/,
            lookbehind: !0,
            // inside can appear subset of php
            inside: {
              comment: l,
              string: x,
              "attribute-class-name": [
                {
                  pattern: /([^:]|^)\b[a-z_]\w*(?!\\)\b/i,
                  alias: "class-name",
                  greedy: !0,
                  lookbehind: !0
                },
                {
                  pattern: /([^:]|^)(?:\\?\b[a-z_]\w*)+/i,
                  alias: [
                    "class-name",
                    "class-name-fully-qualified"
                  ],
                  greedy: !0,
                  lookbehind: !0,
                  inside: {
                    punctuation: /\\/
                  }
                }
              ],
              constant: a,
              number: s,
              operator: S,
              punctuation: v
            }
          },
          delimiter: {
            pattern: /^#\[|\]$/,
            alias: "punctuation"
          }
        }
      }
    }), V.hooks.add("before-tokenize", function(C) {
      if (/<\?/.test(C.code)) {
        var T = /<\?(?:[^"'/#]|\/(?![*/])|("|')(?:\\[\s\S]|(?!\1)[^\\])*\1|(?:\/\/|#(?!\[))(?:[^?\n\r]|\?(?!>))*(?=$|\?>|[\r\n])|#\[|\/\*(?:[^*]|\*(?!\/))*(?:\*\/|$))*?(?:\?>|$)/g;
        V.languages["markup-templating"].buildPlaceholders(C, "php", T);
      }
    }), V.hooks.add("after-tokenize", function(C) {
      V.languages["markup-templating"].tokenizePlaceholders(C, "php");
    });
  })(Prism)), Ue;
}
wi();
(function(V) {
  var l = /[*&][^\s[\]{},]+/, a = /!(?:<[\w\-%#;/?:@&=+$,.!~*'()[\]]+>|(?:[a-zA-Z\d-]*!)?[\w\-%#;/?:@&=+$.~*'()]+)?/, s = "(?:" + a.source + "(?:[ 	]+" + l.source + ")?|" + l.source + "(?:[ 	]+" + a.source + ")?)", S = /(?:[^\s\x00-\x08\x0e-\x1f!"#%&'*,\-:>?@[\]`{|}\x7f-\x84\x86-\x9f\ud800-\udfff\ufffe\uffff]|[?:-]<PLAIN>)(?:[ \t]*(?:(?![#:])<PLAIN>|:<PLAIN>))*/.source.replace(/<PLAIN>/g, function() {
    return /[^\s\x00-\x08\x0e-\x1f,[\]{}\x7f-\x84\x86-\x9f\ud800-\udfff\ufffe\uffff]/.source;
  }), v = /"(?:[^"\\\r\n]|\\.)*"|'(?:[^'\\\r\n]|\\.)*'/.source;
  function _(x, C) {
    C = (C || "").replace(/m/g, "") + "m";
    var T = /([:\-,[{]\s*(?:\s<<prop>>[ \t]+)?)(?:<<value>>)(?=[ \t]*(?:$|,|\]|\}|(?:[\r\n]\s*)?#))/.source.replace(/<<prop>>/g, function() {
      return s;
    }).replace(/<<value>>/g, function() {
      return x;
    });
    return RegExp(T, C);
  }
  V.languages.yaml = {
    scalar: {
      pattern: RegExp(/([\-:]\s*(?:\s<<prop>>[ \t]+)?[|>])[ \t]*(?:((?:\r?\n|\r)[ \t]+)\S[^\r\n]*(?:\2[^\r\n]+)*)/.source.replace(/<<prop>>/g, function() {
        return s;
      })),
      lookbehind: !0,
      alias: "string"
    },
    comment: /#.*/,
    key: {
      pattern: RegExp(/((?:^|[:\-,[{\r\n?])[ \t]*(?:<<prop>>[ \t]+)?)<<key>>(?=\s*:\s)/.source.replace(/<<prop>>/g, function() {
        return s;
      }).replace(/<<key>>/g, function() {
        return "(?:" + S + "|" + v + ")";
      })),
      lookbehind: !0,
      greedy: !0,
      alias: "atrule"
    },
    directive: {
      pattern: /(^[ \t]*)%.+/m,
      lookbehind: !0,
      alias: "important"
    },
    datetime: {
      pattern: _(/\d{4}-\d\d?-\d\d?(?:[tT]|[ \t]+)\d\d?:\d{2}:\d{2}(?:\.\d*)?(?:[ \t]*(?:Z|[-+]\d\d?(?::\d{2})?))?|\d{4}-\d{2}-\d{2}|\d\d?:\d{2}(?::\d{2}(?:\.\d*)?)?/.source),
      lookbehind: !0,
      alias: "number"
    },
    boolean: {
      pattern: _(/false|true/.source, "i"),
      lookbehind: !0,
      alias: "important"
    },
    null: {
      pattern: _(/null|~/.source, "i"),
      lookbehind: !0,
      alias: "important"
    },
    string: {
      pattern: _(v),
      lookbehind: !0,
      greedy: !0
    },
    number: {
      pattern: _(/[+-]?(?:0x[\da-f]+|0o[0-7]+|(?:\d+(?:\.\d*)?|\.\d+)(?:e[+-]?\d+)?|\.inf|\.nan)/.source, "i"),
      lookbehind: !0
    },
    tag: a,
    important: l,
    punctuation: /---|[:[\]{}\-,|>?]|\.\.\./
  }, V.languages.yml = V.languages.yaml;
})(Prism);
(function(V) {
  function l(a, s) {
    return "___" + a.toUpperCase() + s + "___";
  }
  Object.defineProperties(V.languages["markup-templating"] = {}, {
    buildPlaceholders: {
      /**
       * Tokenize all inline templating expressions matching `placeholderPattern`.
       *
       * If `replaceFilter` is provided, only matches of `placeholderPattern` for which `replaceFilter` returns
       * `true` will be replaced.
       *
       * @param {object} env The environment of the `before-tokenize` hook.
       * @param {string} language The language id.
       * @param {RegExp} placeholderPattern The matches of this pattern will be replaced by placeholders.
       * @param {(match: string) => boolean} [replaceFilter]
       */
      value: function(a, s, S, v) {
        if (a.language === s) {
          var _ = a.tokenStack = [];
          a.code = a.code.replace(S, function(x) {
            if (typeof v == "function" && !v(x))
              return x;
            for (var C = _.length, T; a.code.indexOf(T = l(s, C)) !== -1; )
              ++C;
            return _[C] = x, T;
          }), a.grammar = V.languages.markup;
        }
      }
    },
    tokenizePlaceholders: {
      /**
       * Replace placeholders with proper tokens after tokenizing.
       *
       * @param {object} env The environment of the `after-tokenize` hook.
       * @param {string} language The language id.
       */
      value: function(a, s) {
        if (a.language !== s || !a.tokenStack)
          return;
        a.grammar = V.languages[s];
        var S = 0, v = Object.keys(a.tokenStack);
        function _(x) {
          for (var C = 0; C < x.length && !(S >= v.length); C++) {
            var T = x[C];
            if (typeof T == "string" || T.content && typeof T.content == "string") {
              var A = v[S], n = a.tokenStack[A], f = typeof T == "string" ? T : T.content, p = l(s, A), F = f.indexOf(p);
              if (F > -1) {
                ++S;
                var r = f.substring(0, F), w = new V.Token(s, V.tokenize(n, a.grammar), "language-" + s, n), t = f.substring(F + p.length), i = [];
                r && i.push.apply(i, _([r])), i.push(w), t && i.push.apply(i, _([t])), typeof T == "string" ? x.splice.apply(x, [C, 1].concat(i)) : T.content = i;
              }
            } else T.content && _(T.content);
          }
          return x;
        }
        _(a.tokens);
      }
    }
  });
})(Prism);
new is();
const Ai = (V) => {
  const l = {};
  for (let a = 0, s = V.length; a < s; a++) {
    const S = V[a];
    for (const v in S)
      l[v] ? l[v] = l[v].concat(S[v]) : l[v] = S[v];
  }
  return l;
}, yi = [
  "abbr",
  "accept",
  "accept-charset",
  "accesskey",
  "action",
  "align",
  "alink",
  "allow",
  "allowfullscreen",
  "alt",
  "anchor",
  "archive",
  "as",
  "async",
  "autocapitalize",
  "autocomplete",
  "autocorrect",
  "autofocus",
  "autopictureinpicture",
  "autoplay",
  "axis",
  "background",
  "behavior",
  "bgcolor",
  "border",
  "bordercolor",
  "capture",
  "cellpadding",
  "cellspacing",
  "challenge",
  "char",
  "charoff",
  "charset",
  "checked",
  "cite",
  "class",
  "classid",
  "clear",
  "code",
  "codebase",
  "codetype",
  "color",
  "cols",
  "colspan",
  "compact",
  "content",
  "contenteditable",
  "controls",
  "controlslist",
  "conversiondestination",
  "coords",
  "crossorigin",
  "csp",
  "data",
  "datetime",
  "declare",
  "decoding",
  "default",
  "defer",
  "dir",
  "direction",
  "dirname",
  "disabled",
  "disablepictureinpicture",
  "disableremoteplayback",
  "disallowdocumentaccess",
  "download",
  "draggable",
  "elementtiming",
  "enctype",
  "end",
  "enterkeyhint",
  "event",
  "exportparts",
  "face",
  "for",
  "form",
  "formaction",
  "formenctype",
  "formmethod",
  "formnovalidate",
  "formtarget",
  "frame",
  "frameborder",
  "headers",
  "height",
  "hidden",
  "high",
  "href",
  "hreflang",
  "hreftranslate",
  "hspace",
  "http-equiv",
  "id",
  "imagesizes",
  "imagesrcset",
  "importance",
  "impressiondata",
  "impressionexpiry",
  "incremental",
  "inert",
  "inputmode",
  "integrity",
  "invisible",
  "ismap",
  "keytype",
  "kind",
  "label",
  "lang",
  "language",
  "latencyhint",
  "leftmargin",
  "link",
  "list",
  "loading",
  "longdesc",
  "loop",
  "low",
  "lowsrc",
  "manifest",
  "marginheight",
  "marginwidth",
  "max",
  "maxlength",
  "mayscript",
  "media",
  "method",
  "min",
  "minlength",
  "multiple",
  "muted",
  "name",
  "nohref",
  "nomodule",
  "nonce",
  "noresize",
  "noshade",
  "novalidate",
  "nowrap",
  "object",
  "open",
  "optimum",
  "part",
  "pattern",
  "ping",
  "placeholder",
  "playsinline",
  "policy",
  "poster",
  "preload",
  "pseudo",
  "readonly",
  "referrerpolicy",
  "rel",
  "reportingorigin",
  "required",
  "resources",
  "rev",
  "reversed",
  "role",
  "rows",
  "rowspan",
  "rules",
  "sandbox",
  "scheme",
  "scope",
  "scopes",
  "scrollamount",
  "scrolldelay",
  "scrolling",
  "select",
  "selected",
  "shadowroot",
  "shadowrootdelegatesfocus",
  "shape",
  "size",
  "sizes",
  "slot",
  "span",
  "spellcheck",
  "src",
  "srclang",
  "srcset",
  "standby",
  "start",
  "step",
  "style",
  "summary",
  "tabindex",
  "target",
  "text",
  "title",
  "topmargin",
  "translate",
  "truespeed",
  "trusttoken",
  "type",
  "usemap",
  "valign",
  "value",
  "valuetype",
  "version",
  "virtualkeyboardpolicy",
  "vlink",
  "vspace",
  "webkitdirectory",
  "width",
  "wrap"
], xi = [
  "accent-height",
  "accumulate",
  "additive",
  "alignment-baseline",
  "ascent",
  "attributename",
  "attributetype",
  "azimuth",
  "basefrequency",
  "baseline-shift",
  "begin",
  "bias",
  "by",
  "class",
  "clip",
  "clippathunits",
  "clip-path",
  "clip-rule",
  "color",
  "color-interpolation",
  "color-interpolation-filters",
  "color-profile",
  "color-rendering",
  "cx",
  "cy",
  "d",
  "dx",
  "dy",
  "diffuseconstant",
  "direction",
  "display",
  "divisor",
  "dominant-baseline",
  "dur",
  "edgemode",
  "elevation",
  "end",
  "fill",
  "fill-opacity",
  "fill-rule",
  "filter",
  "filterunits",
  "flood-color",
  "flood-opacity",
  "font-family",
  "font-size",
  "font-size-adjust",
  "font-stretch",
  "font-style",
  "font-variant",
  "font-weight",
  "fx",
  "fy",
  "g1",
  "g2",
  "glyph-name",
  "glyphref",
  "gradientunits",
  "gradienttransform",
  "height",
  "href",
  "id",
  "image-rendering",
  "in",
  "in2",
  "k",
  "k1",
  "k2",
  "k3",
  "k4",
  "kerning",
  "keypoints",
  "keysplines",
  "keytimes",
  "lang",
  "lengthadjust",
  "letter-spacing",
  "kernelmatrix",
  "kernelunitlength",
  "lighting-color",
  "local",
  "marker-end",
  "marker-mid",
  "marker-start",
  "markerheight",
  "markerunits",
  "markerwidth",
  "maskcontentunits",
  "maskunits",
  "max",
  "mask",
  "media",
  "method",
  "mode",
  "min",
  "name",
  "numoctaves",
  "offset",
  "operator",
  "opacity",
  "order",
  "orient",
  "orientation",
  "origin",
  "overflow",
  "paint-order",
  "path",
  "pathlength",
  "patterncontentunits",
  "patterntransform",
  "patternunits",
  "points",
  "preservealpha",
  "preserveaspectratio",
  "primitiveunits",
  "r",
  "rx",
  "ry",
  "radius",
  "refx",
  "refy",
  "repeatcount",
  "repeatdur",
  "restart",
  "result",
  "rotate",
  "scale",
  "seed",
  "shape-rendering",
  "specularconstant",
  "specularexponent",
  "spreadmethod",
  "startoffset",
  "stddeviation",
  "stitchtiles",
  "stop-color",
  "stop-opacity",
  "stroke-dasharray",
  "stroke-dashoffset",
  "stroke-linecap",
  "stroke-linejoin",
  "stroke-miterlimit",
  "stroke-opacity",
  "stroke",
  "stroke-width",
  "style",
  "surfacescale",
  "systemlanguage",
  "tabindex",
  "targetx",
  "targety",
  "transform",
  "transform-origin",
  "text-anchor",
  "text-decoration",
  "text-rendering",
  "textlength",
  "type",
  "u1",
  "u2",
  "unicode",
  "values",
  "viewbox",
  "visibility",
  "version",
  "vert-adv-y",
  "vert-origin-x",
  "vert-origin-y",
  "width",
  "word-spacing",
  "wrap",
  "writing-mode",
  "xchannelselector",
  "ychannelselector",
  "x",
  "x1",
  "x2",
  "xmlns",
  "y",
  "y1",
  "y2",
  "z",
  "zoomandpan"
], Ei = [
  "accent",
  "accentunder",
  "align",
  "bevelled",
  "close",
  "columnsalign",
  "columnlines",
  "columnspan",
  "denomalign",
  "depth",
  "dir",
  "display",
  "displaystyle",
  "encoding",
  "fence",
  "frame",
  "height",
  "href",
  "id",
  "largeop",
  "length",
  "linethickness",
  "lspace",
  "lquote",
  "mathbackground",
  "mathcolor",
  "mathsize",
  "mathvariant",
  "maxsize",
  "minsize",
  "movablelimits",
  "notation",
  "numalign",
  "open",
  "rowalign",
  "rowlines",
  "rowspacing",
  "rowspan",
  "rspace",
  "rquote",
  "scriptlevel",
  "scriptminsize",
  "scriptsizemultiplier",
  "selection",
  "separator",
  "separators",
  "stretchy",
  "subscriptshift",
  "supscriptshift",
  "symmetric",
  "voffset",
  "width",
  "xmlns"
];
Ai([
  Object.fromEntries(yi.map((V) => [V, ["*"]])),
  Object.fromEntries(xi.map((V) => [V, ["svg:*"]])),
  Object.fromEntries(Ei.map((V) => [V, ["math:*"]]))
]);
e.from_html("<span><!></span>");
e.from_html('<div class="svelte-1i9kj8o"><!></div>');
e.from_html('<span data-testid="block-info"><!></span> <!>', 1);
var ki = e.from_html('<label for="" data-testid="block-label"><span class="svelte-1fzogyz"><!></span> </label>');
function Ci(V, l) {
  let a = e.prop(l, "label", 8, null), s = e.prop(l, "Icon", 8), S = e.prop(l, "show_label", 8, !0), v = e.prop(l, "disable", 8, !1), _ = e.prop(l, "float", 8, !0), x = e.prop(l, "rtl", 8, !1);
  var C = ki();
  let T;
  var A = e.child(C), n = e.child(A);
  s()(n, {}), e.reset(A);
  var f = e.sibling(A);
  e.reset(C), e.template_effect(() => {
    e.set_attribute(C, "dir", x() ? "rtl" : "ltr"), T = e.set_class(C, 1, "svelte-1fzogyz", null, T, {
      hide: !S(),
      "sr-only": !S(),
      float: _(),
      "hide-label": v()
    }), e.set_text(f, ` ${a() ?? ""}`), C.dir = C.dir;
  }), e.append(V, C);
}
var Si = e.from_html("<a><!></a>");
function Fi(V, l) {
  const a = e.legacy_rest_props(l, ["children", "$$slots", "$$events", "$$legacy"]), s = e.legacy_rest_props(a, ["href", "download"]);
  e.push(l, !1);
  let S = e.prop(l, "href", 8, void 0), v = e.prop(l, "download", 8);
  const _ = ae();
  e.init();
  var x = Si(), C = e.derived(() => _.bind(null, "click"));
  e.attribute_effect(
    x,
    () => ({
      class: "download-link",
      href: S(),
      target: e.untrack(() => typeof window < "u" && window.__is_colab__ ? "_blank" : null),
      rel: "noopener noreferrer",
      download: v(),
      ...s,
      [e.STYLE]: { position: "relative" }
    }),
    void 0,
    void 0,
    void 0,
    "svelte-q1286o"
  );
  var T = e.child(x);
  e.slot(T, l, "default", {}, null), e.reset(x), e.event("click", x, function(...A) {
    e.get(C)?.apply(this, A);
  }), e.append(V, x), e.pop();
}
var Di = e.from_html('<span class="svelte-vvirtv"> </span>'), Ti = e.from_html("<button><!> <div><!> <!></div></button>");
function qt(V, l) {
  e.push(l, !1);
  const a = e.mutable_source();
  let s = e.prop(l, "Icon", 8), S = e.prop(l, "label", 8, ""), v = e.prop(l, "show_label", 8, !1), _ = e.prop(l, "pending", 8, !1), x = e.prop(l, "size", 8, "small"), C = e.prop(l, "padded", 8, !0), T = e.prop(l, "highlight", 8, !1), A = e.prop(l, "disabled", 8, !1), n = e.prop(l, "hasPopup", 8, !1), f = e.prop(l, "color", 8, "var(--block-label-text-color)"), p = e.prop(l, "transparent", 8, !1), F = e.prop(l, "background", 8, "var(--block-background-fill)"), r = e.prop(l, "border", 8, "transparent");
  e.legacy_pre_effect(() => (e.deep_read_state(T()), e.deep_read_state(f())), () => {
    e.set(a, T() ? "var(--color-accent)" : f());
  }), e.legacy_pre_effect_reset();
  var w = Ti();
  let t, i;
  var h = e.child(w);
  {
    var d = (B) => {
      var U = Di(), q = e.child(U, !0);
      e.reset(U), e.template_effect(() => e.set_text(q, S())), e.append(B, U);
    };
    e.if(h, (B) => {
      v() && B(d);
    });
  }
  var E = e.sibling(h, 2);
  let k;
  var L = e.child(E);
  e.component(L, s, (B, U) => {
    U(B, {});
  });
  var M = e.sibling(L, 2);
  e.slot(M, l, "default", {}, null), e.reset(E), e.reset(w), e.template_effect(() => {
    t = e.set_class(w, 1, "icon-button svelte-vvirtv", null, t, {
      pending: _(),
      padded: C(),
      highlight: T(),
      transparent: p()
    }), w.disabled = A(), e.set_attribute(w, "aria-label", S()), e.set_attribute(w, "aria-haspopup", n()), e.set_attribute(w, "title", S()), i = e.set_style(w, "", i, {
      "--border-color": r(),
      color: !A() && e.get(a) ? e.get(a) : "var(--block-label-text-color)",
      "--bg-color": A() ? "auto" : F()
    }), k = e.set_class(E, 1, "svelte-vvirtv", null, k, {
      "x-small": x() === "x-small",
      small: x() === "small",
      large: x() === "large",
      medium: x() === "medium"
    });
  }), e.event("click", w, function(B) {
    e.bubble_event.call(this, l, B);
  }), e.append(V, w), e.pop();
}
var _i = e.from_html('<div aria-label="Empty value"><div class="icon svelte-1xcwp1t"><!></div></div>');
function Ri(V, l) {
  e.push(l, !1);
  const a = e.mutable_source();
  let s = e.prop(l, "size", 8, "small"), S = e.prop(l, "unpadded_box", 8, !1), v = e.mutable_source();
  function _(n) {
    var f;
    if (!n) return !1;
    const { height: p } = n.getBoundingClientRect(), { height: F } = ((f = n.parentElement) === null || f === void 0 ? void 0 : f.getBoundingClientRect()) || { height: p };
    return p > F + 2;
  }
  e.legacy_pre_effect(() => e.get(v), () => {
    e.set(a, _(e.get(v)));
  }), e.legacy_pre_effect_reset();
  var x = _i();
  let C;
  var T = e.child(x), A = e.child(T);
  e.slot(A, l, "default", {}, null), e.reset(T), e.reset(x), e.bind_this(x, (n) => e.set(v, n), () => e.get(v)), e.template_effect(() => C = e.set_class(x, 1, "empty svelte-1xcwp1t", null, C, {
    small: s() === "small",
    large: s() === "large",
    unpadded_box: S(),
    small_parent: e.get(a)
  })), e.append(V, x), e.pop();
}
e.from_html('<h2 class="svelte-cmuu9m"> </h2>');
e.from_html('<p class="svelte-cmuu9m"> </p>');
e.from_html("<!> <!>", 1);
e.from_html('<span class="or svelte-cmuu9m"> </span> ', 1);
e.from_html(" <!>", 1);
e.from_html('<div class="wrap svelte-cmuu9m"><span><!></span> <!></div>');
e.from_html("<div><!></div>");
e.from_html('<button aria-label="Upload file"><!></button>');
e.from_html('<button aria-label="Record audio"><!></button>');
e.from_html('<button aria-label="Capture from camera"><!></button>');
e.from_html('<button aria-label="Paste from clipboard"><!></button>');
e.from_html('<span class="source-selection svelte-5d261r" data-testid="source-select"><!> <!> <!> <!></span>');
var Li = e.from_html("<div><!></div>");
function Ii(V, l) {
  let a = e.prop(l, "top_panel", 8, !0), s = e.prop(l, "display_top_corner", 8, !1), S = e.prop(l, "show_background", 8, !0);
  var v = Li(), _ = e.child(v);
  e.slot(_, l, "default", {}, null), e.reset(v), e.template_effect(() => e.set_class(v, 1, `icon-button-wrapper ${a() ? "top-panel" : ""} ${s() ? "display-top-corner" : "hide-top-corner"} ${S() ? "" : "no-background"}`, "svelte-1f7yqtk")), e.append(V, v);
}
async function Mi(V, l) {
  return V.map(
    (a) => new Pi({
      path: a.name,
      orig_name: a.name,
      blob: a,
      size: a.size,
      mime_type: a.type,
      is_stream: l
    })
  );
}
class Pi {
  path;
  url;
  orig_name;
  size;
  blob;
  is_stream;
  mime_type;
  alt_text;
  b64;
  meta = { _type: "gradio.FileData" };
  constructor({
    path: l,
    url: a,
    orig_name: s,
    size: S,
    blob: v,
    is_stream: _,
    mime_type: x,
    alt_text: C,
    b64: T
  }) {
    this.path = l, this.url = a, this.orig_name = s, this.size = S, this.blob = a ? void 0 : v, this.is_stream = _, this.mime_type = x, this.alt_text = C, this.b64 = T;
  }
}
typeof process < "u" && process.versions && process.versions.node;
class An extends TransformStream {
  #t = "";
  /** Constructs a new instance. */
  constructor(l = { allowCR: !1 }) {
    super({
      transform: (a, s) => {
        for (a = this.#t + a; ; ) {
          const S = a.indexOf(`
`), v = l.allowCR ? a.indexOf("\r") : -1;
          if (v !== -1 && v !== a.length - 1 && (S === -1 || S - 1 > v)) {
            s.enqueue(a.slice(0, v)), a = a.slice(v + 1);
            continue;
          }
          if (S === -1)
            break;
          const _ = a[S - 1] === "\r" ? S - 1 : S;
          s.enqueue(a.slice(0, _)), a = a.slice(S + 1);
        }
        this.#t = a;
      },
      flush: (a) => {
        if (this.#t === "")
          return;
        const s = l.allowCR && this.#t.endsWith("\r") ? this.#t.slice(0, -1) : this.#t;
        a.enqueue(s);
      }
    });
  }
}
var Ni = e.from_html("<img/>");
function Ge(V, l) {
  e.push(l, !0);
  var a = Ni();
  e.attribute_effect(
    a,
    (s) => ({
      src: l.src,
      class: s,
      "data-testid": l.data_testid,
      ...l.restProps
    }),
    [() => (l.class_names || []).join(" ")],
    void 0,
    void 0,
    "svelte-5xcf1t"
  ), e.replay_events(a), e.event("load", a, function(s) {
    e.bubble_event.call(this, l, s);
  }), e.append(V, a), e.pop();
}
e.from_html("<!> <!> <!>", 1);
e.from_html('<div class="image-container svelte-1vq0uw1"><!> <button class="svelte-1vq0uw1"><div><!></div></button></div>');
e.from_html("<!> <!>", 1);
var Oi = e.from_html('<a rel="noopener noreferrer"><!> <!></a>'), Bi = e.from_html("<button><!> <!></button>");
function $e(V, l) {
  e.push(l, !1);
  let a = e.prop(l, "elem_id", 8, ""), s = e.prop(l, "elem_classes", 24, () => []), S = e.prop(l, "visible", 8, !0), v = e.prop(l, "variant", 8, "secondary"), _ = e.prop(l, "size", 8, "lg"), x = e.prop(l, "value", 8, null), C = e.prop(l, "link", 8, null), T = e.prop(l, "icon", 8, null), A = e.prop(l, "disabled", 8, !1), n = e.prop(l, "scale", 8, null), f = e.prop(l, "min_width", 8, void 0);
  e.init();
  var p = e.comment(), F = e.first_child(p);
  {
    var r = (t) => {
      var i = Oi();
      let h, d;
      var E = e.child(i);
      {
        var k = (M) => {
          {
            let B = e.derived_safe_equal(() => ({ alt: `${x()} icon`, class: "button-icon" }));
            Ge(M, {
              get src() {
                return e.deep_read_state(T()), e.untrack(() => T().url);
              },
              get restProps() {
                return e.get(B);
              }
            });
          }
        };
        e.if(E, (M) => {
          T() && M(k);
        });
      }
      var L = e.sibling(E, 2);
      e.slot(L, l, "default", {}, null), e.reset(i), e.template_effect(
        (M) => {
          e.set_attribute(i, "href", C()), e.set_attribute(i, "aria-disabled", A()), h = e.set_class(i, 1, `${_() ?? ""} ${v() ?? ""} ${M ?? ""}`, "svelte-1ktvk49", h, {
            hidden: S() === !1 || S() === "hidden",
            disabled: A()
          }), e.set_attribute(i, "id", a()), d = e.set_style(i, "", d, {
            "flex-grow": n(),
            "pointer-events": A() ? "none" : null,
            width: n() === 0 ? "fit-content" : null,
            "min-width": typeof f() == "number" ? `calc(min(${f()}px, 100%))` : null
          });
        },
        [
          () => (e.deep_read_state(s()), e.untrack(() => s().join(" ")))
        ]
      ), e.append(t, i);
    }, w = (t) => {
      var i = Bi();
      let h, d;
      var E = e.child(i);
      {
        var k = (M) => {
          {
            let B = e.derived_safe_equal(() => ({ alt: `${x()} icon` })), U = e.derived_safe_equal(() => [`button-icon ${x() ? "right-padded" : ""}`]);
            Ge(M, {
              get restProps() {
                return e.get(B);
              },
              get class_names() {
                return e.get(U);
              },
              get src() {
                return e.deep_read_state(T()), e.untrack(() => T().url);
              }
            });
          }
        };
        e.if(E, (M) => {
          T() && M(k);
        });
      }
      var L = e.sibling(E, 2);
      e.slot(L, l, "default", {}, null), e.reset(i), e.template_effect(
        (M) => {
          h = e.set_class(i, 1, `${_() ?? ""} ${v() ?? ""} ${M ?? ""}`, "svelte-1ktvk49", h, { hidden: S() === !1 || S() === "hidden" }), e.set_attribute(i, "id", a()), i.disabled = A(), d = e.set_style(i, "", d, {
            "flex-grow": n(),
            width: n() === 0 ? "fit-content" : null,
            "min-width": typeof f() == "number" ? `calc(min(${f()}px, 100%))` : null
          });
        },
        [
          () => (e.deep_read_state(s()), e.untrack(() => s().join(" ")))
        ]
      ), e.event("click", i, function(M) {
        e.bubble_event.call(this, l, M);
      }), e.append(t, i);
    };
    e.if(F, (t) => {
      e.deep_read_state(C()), e.untrack(() => C() && C().length > 0) ? t(r) : t(w, !1);
    });
  }
  e.append(V, p), e.pop();
}
function ue(V) {
  let l = ["", "k", "M", "G", "T", "P", "E", "Z"], a = 0;
  for (; V > 1e3 && a < l.length - 1; )
    V /= 1e3, a++;
  let s = l[a];
  return (Number.isInteger(V) ? V : V.toFixed(1)) + s;
}
var Hi = e.from_html('<div><svg viewBox="-1200 -1200 3000 3000" fill="none" xmlns="http://www.w3.org/2000/svg" class="svelte-m6d381"><g><path d="M255.926 0.754768L509.702 139.936V221.027L255.926 81.8465V0.754768Z" fill="#FF7C00" fill-opacity="0.4" class="svelte-m6d381"></path><path d="M509.69 139.936L254.981 279.641V361.255L509.69 221.55V139.936Z" fill="#FF7C00" class="svelte-m6d381"></path><path d="M0.250138 139.937L254.981 279.641V361.255L0.250138 221.55V139.937Z" fill="#FF7C00" fill-opacity="0.4" class="svelte-m6d381"></path><path d="M255.923 0.232622L0.236328 139.936V221.55L255.923 81.8469V0.232622Z" fill="#FF7C00" class="svelte-m6d381"></path></g><g><path d="M255.926 141.5L509.702 280.681V361.773L255.926 222.592V141.5Z" fill="#FF7C00" fill-opacity="0.4" class="svelte-m6d381"></path><path d="M509.69 280.679L254.981 420.384V501.998L509.69 362.293V280.679Z" fill="#FF7C00" class="svelte-m6d381"></path><path d="M0.250138 280.681L254.981 420.386V502L0.250138 362.295V280.681Z" fill="#FF7C00" fill-opacity="0.4" class="svelte-m6d381"></path><path d="M255.923 140.977L0.236328 280.68V362.294L255.923 222.591V140.977Z" fill="#FF7C00" class="svelte-m6d381"></path></g></svg></div>');
function zi(V, l) {
  e.push(l, !1);
  const a = () => e.store_get(C, "$top", S), s = () => e.store_get(T, "$bottom", S), [S, v] = e.setup_stores();
  var _ = this && this.__awaiter || function(h, d, E, k) {
    function L(M) {
      return M instanceof E ? M : new E(function(B) {
        B(M);
      });
    }
    return new (E || (E = Promise))(function(M, B) {
      function U(K) {
        try {
          Z(k.next(K));
        } catch (Y) {
          B(Y);
        }
      }
      function q(K) {
        try {
          Z(k.throw(K));
        } catch (Y) {
          B(Y);
        }
      }
      function Z(K) {
        K.done ? M(K.value) : L(K.value).then(U, q);
      }
      Z((k = k.apply(h, d || [])).next());
    });
  };
  let x = e.prop(l, "margin", 8, !0);
  const C = Ee([0, 0]), T = Ee([0, 0]);
  let A;
  function n() {
    return _(this, void 0, void 0, function* () {
      yield Promise.all([C.set([125, 140]), T.set([-125, -140])]), yield Promise.all([C.set([-125, 140]), T.set([125, -140])]), yield Promise.all([C.set([-125, 0]), T.set([125, -0])]), yield Promise.all([C.set([125, 0]), T.set([-125, 0])]);
    });
  }
  function f() {
    return _(this, void 0, void 0, function* () {
      yield n(), A || f();
    });
  }
  function p() {
    return _(this, void 0, void 0, function* () {
      yield Promise.all([C.set([125, 0]), T.set([-125, 0])]), f();
    });
  }
  je(() => (p(), () => A = !0)), e.init();
  var F = Hi();
  let r;
  var w = e.child(F), t = e.child(w), i = e.sibling(t);
  e.reset(w), e.reset(F), e.template_effect(() => {
    r = e.set_class(F, 1, "svelte-m6d381", null, r, { margin: x() }), e.set_style(t, `transform: translate(${a(), e.untrack(() => a()[0]) ?? ""}px, ${a(), e.untrack(() => a()[1]) ?? ""}px);`), e.set_style(i, `transform: translate(${s(), e.untrack(() => s()[0]) ?? ""}px, ${s(), e.untrack(() => s()[1]) ?? ""}px);`);
  }), e.append(V, F), e.pop(), v();
}
var Ui = function(V, l, a, s) {
  function S(v) {
    return v instanceof a ? v : new a(function(_) {
      _(v);
    });
  }
  return new (a || (a = Promise))(function(v, _) {
    function x(A) {
      try {
        T(s.next(A));
      } catch (n) {
        _(n);
      }
    }
    function C(A) {
      try {
        T(s.throw(A));
      } catch (n) {
        _(n);
      }
    }
    function T(A) {
      A.done ? v(A.value) : S(A.value).then(x, C);
    }
    T((s = s.apply(V, l || [])).next());
  });
};
let te = [], de = !1;
const Vi = typeof window < "u", ns = Vi ? window.requestAnimationFrame : (V) => {
};
function Gi(V) {
  return Ui(this, arguments, void 0, function* (l, a = !0) {
    if (!(window.__gradio_mode__ === "website" || window.__gradio_mode__ !== "app" && a !== !0)) {
      if (te.push(l), !de) de = !0;
      else return;
      yield se(), ns(() => {
        let s = [0, 0];
        for (let S = 0; S < te.length; S++) {
          const _ = te[S].getBoundingClientRect();
          (S === 0 || _.top + window.scrollY <= s[0]) && (s[0] = _.top + window.scrollY, s[1] = S);
        }
        window.scrollTo({ top: s[0] - 20, behavior: "smooth" }), de = !1, te = [];
      });
    }
  });
}
var $i = e.from_html('<div class="validation-error svelte-124hqw6"> <button class="svelte-124hqw6"><!></button></div>'), qi = e.from_html('<div class="eta-bar svelte-124hqw6"></div>'), ji = e.from_html("<!> ", 1), Xi = e.from_html("<!> <!> <!> <!>", 1), Yi = e.from_html('<div class="progress-level svelte-124hqw6"><div class="progress-level-inner svelte-124hqw6"><!></div> <div class="progress-bar-wrap svelte-124hqw6"><div class="progress-bar svelte-124hqw6"></div></div></div>'), Wi = e.from_html('<p class="loading svelte-124hqw6"> </p> <!>', 1), Zi = e.from_html("<!> <div><!> <!></div> <!> <!>", 1), Ki = e.from_html('<div class="clear-status svelte-124hqw6"><!></div> <span class="error svelte-124hqw6"> </span> <!>', 1), Qi = e.from_html('<div data-testid="status-tracker"><!> <!></div>');
function Ji(V, l) {
  e.push(l, !0);
  let a = e.prop(l, "eta", 7, null), s = e.prop(l, "scroll_to_output", 3, !1), S = e.prop(l, "timer", 3, !0), v = e.prop(l, "show_progress", 3, "full"), _ = e.prop(l, "message", 3, null), x = e.prop(l, "progress", 3, null), C = e.prop(l, "variant", 3, "default"), T = e.prop(l, "loading_text", 3, "Loading..."), A = e.prop(l, "absolute", 3, !0), n = e.prop(l, "translucent", 3, !1), f = e.prop(l, "border", 3, !1), p = e.prop(l, "validation_error", 7, null), F = e.prop(l, "show_validation_error", 3, !0), r = e.prop(l, "type", 3, null), w, t = !1, i = e.state(0), h = e.state(null), d = e.state(null), E = e.state(!1), k = e.state(null);
  const L = e.derived(() => r() === "input" || !l.status || l.status === "complete" || v() === "hidden" || l.status == "streaming" || !!(F() && p()));
  let M = e.state(0);
  const B = e.derived(() => e.get(d) === null || e.get(d) <= 0 || !e.get(M) ? 0 : Math.min(e.get(M) / e.get(d), 1)), U = e.derived(() => e.get(M).toFixed(1));
  let q = e.derived(() => x() == null);
  function Z() {
    ns(() => {
      e.set(M, (performance.now() - e.get(i)) / 1e3), t && Z();
    });
  }
  let K = e.derived(() => {
    let ot = null;
    x() != null ? ot = x().map((y) => {
      if (y.index != null && y.length != null)
        return y.index / y.length;
      if (y.progress != null)
        return y.progress;
    }) : ot = null;
    let et, D = "";
    return ot ? (et = ot[ot.length - 1], et === 0 ? D = "0" : D = "150ms") : et = void 0, {
      progress_level: ot,
      last_progress_level: et,
      progress_bar_transition: D
    };
  });
  function Y() {
    t || (e.set(h, e.set(k, null), !0), e.set(i, performance.now(), !0), t = !0, Z());
  }
  function G() {
    e.set(h, e.set(k, null), !0), t && (t = !1);
  }
  e.user_effect(() => {
    l.status === "pending" ? Y() : fe(() => {
      G();
    });
  }), e.user_effect(() => {
    w && s() && (l.status === "pending" || l.status === "complete") && Gi(w, l.autoscroll);
  }), e.user_effect(() => {
    a() === null && a(e.get(h)), a() != null && e.get(h) !== a() && (e.set(d, (performance.now() - e.get(i)) / 1e3 + a()), e.set(k, e.get(d).toFixed(1), !0), e.set(h, a(), !0));
  });
  function j() {
    e.set(E, !1);
  }
  e.user_effect(() => {
    fe(() => {
      j();
    }), l.status === "error" && _() && e.set(E, !0);
  });
  var Q = Qi();
  let J, tt;
  var rt = e.child(Q);
  {
    var ut = (ot) => {
      var et = $i(), D = e.child(et), y = e.sibling(D), o = e.child(y);
      {
        let u = e.derived(() => l.i18n ? l.i18n("common.clear") : "Clear");
        qt(o, {
          get Icon() {
            return pe;
          },
          get label() {
            return e.get(u);
          },
          disabled: !1,
          size: "x-small",
          background: "var(--background-fill-primary)",
          color: "var(--error-background-text)",
          border: "var(--border-color-primary)",
          $$events: { click: () => p(null) }
        });
      }
      e.reset(y), e.reset(et), e.template_effect(() => e.set_text(D, `${p() ?? ""} `)), e.append(ot, et);
    };
    e.if(rt, (ot) => {
      p() && F() && ot(ut);
    });
  }
  var dt = e.sibling(rt, 2);
  {
    var ft = (ot) => {
      var et = Zi(), D = e.first_child(et);
      {
        var y = (N) => {
          var P = qi();
          let X;
          e.template_effect(() => X = e.set_style(P, "", X, {
            transform: `translateX(${(e.get(B) || 0) * 100 - 100}%)`
          })), e.append(N, P);
        };
        e.if(D, (N) => {
          C() === "default" && e.get(q) && v() === "full" && N(y);
        });
      }
      var o = e.sibling(D, 2);
      let u;
      var m = e.child(o);
      {
        var g = (N) => {
          var P = e.comment(), X = e.first_child(P);
          e.each(X, 17, x, e.index, (it, W) => {
            var st = e.comment(), ct = e.first_child(st);
            {
              var at = (nt) => {
                var ht = ji(), pt = e.first_child(ht);
                {
                  var vt = (mt) => {
                    var St = e.text();
                    e.template_effect((Et, Ft) => e.set_text(St, `${Et ?? ""}/${Ft ?? ""}`), [
                      () => ue(e.get(W).index || 0),
                      () => ue(e.get(W).length)
                    ]), e.append(mt, St);
                  }, bt = (mt) => {
                    var St = e.text();
                    e.template_effect((Et) => e.set_text(St, Et), [() => ue(e.get(W).index || 0)]), e.append(mt, St);
                  };
                  e.if(pt, (mt) => {
                    e.get(W).length != null ? mt(vt) : mt(bt, !1);
                  });
                }
                var wt = e.sibling(pt);
                e.template_effect(() => e.set_text(wt, ` ${e.get(W).unit ?? ""} |  `)), e.append(nt, ht);
              };
              e.if(ct, (nt) => {
                e.get(W).index != null && nt(at);
              });
            }
            e.append(it, st);
          }), e.append(N, P);
        }, c = (N) => {
          var P = e.comment(), X = e.first_child(P);
          {
            var it = (st) => {
              var ct = e.text();
              e.template_effect(() => e.set_text(ct, `queue: ${l.queue_position + 1}/${l.queue_size ?? ""} |`)), e.append(st, ct);
            }, W = (st) => {
              var ct = e.comment(), at = e.first_child(ct);
              {
                var nt = (ht) => {
                  var pt = e.text("processing |");
                  e.append(ht, pt);
                };
                e.if(
                  at,
                  (ht) => {
                    l.queue_position === 0 && ht(nt);
                  },
                  !0
                );
              }
              e.append(st, ct);
            };
            e.if(
              X,
              (st) => {
                l.queue_position !== null && l.queue_size !== void 0 && l.queue_position >= 0 ? st(it) : st(W, !1);
              },
              !0
            );
          }
          e.append(N, P);
        };
        e.if(m, (N) => {
          x() ? N(g) : N(c, !1);
        });
      }
      var b = e.sibling(m, 2);
      {
        var R = (N) => {
          var P = e.text();
          e.template_effect(() => e.set_text(P, `${e.get(U) ?? ""}${a() ? `/${e.get(k)}` : ""}s`)), e.append(N, P);
        };
        e.if(b, (N) => {
          S() && N(R);
        });
      }
      e.reset(o);
      var I = e.sibling(o, 2);
      {
        var O = (N) => {
          var P = Yi(), X = e.child(P), it = e.child(X);
          {
            var W = (nt) => {
              var ht = e.comment(), pt = e.first_child(ht);
              e.each(pt, 17, x, e.index, (vt, bt, wt) => {
                var mt = e.comment(), St = e.first_child(mt);
                {
                  var Et = (Ft) => {
                    var xt = Xi(), Tt = e.first_child(xt);
                    {
                      var It = (kt) => {
                        var Rt = e.text(" /");
                        e.append(kt, Rt);
                      };
                      e.if(Tt, (kt) => {
                        wt !== 0 && kt(It);
                      });
                    }
                    var Nt = e.sibling(Tt, 2);
                    {
                      var zt = (kt) => {
                        var Rt = e.text();
                        e.template_effect(() => e.set_text(Rt, e.get(bt).desc)), e.append(kt, Rt);
                      };
                      e.if(Nt, (kt) => {
                        e.get(bt).desc != null && kt(zt);
                      });
                    }
                    var Ut = e.sibling(Nt, 2);
                    {
                      var Ot = (kt) => {
                        var Rt = e.text("-");
                        e.append(kt, Rt);
                      };
                      e.if(Ut, (kt) => {
                        e.get(bt).desc != null && e.get(K).progress_level && e.get(K).progress_level[wt] != null && kt(Ot);
                      });
                    }
                    var _t = e.sibling(Ut, 2);
                    {
                      var Ct = (kt) => {
                        var Rt = e.text();
                        e.template_effect((Bt) => e.set_text(Rt, `${Bt ?? ""}%`), [
                          () => (100 * (e.get(K).progress_level[wt] || 0)).toFixed(1)
                        ]), e.append(kt, Rt);
                      };
                      e.if(_t, (kt) => {
                        e.get(K).progress_level != null && kt(Ct);
                      });
                    }
                    e.append(Ft, xt);
                  };
                  e.if(St, (Ft) => {
                    (e.get(bt).desc != null || e.get(K).progress_level && e.get(K).progress_level[wt] != null) && Ft(Et);
                  });
                }
                e.append(vt, mt);
              }), e.append(nt, ht);
            };
            e.if(it, (nt) => {
              x() != null && nt(W);
            });
          }
          e.reset(X);
          var st = e.sibling(X, 2), ct = e.child(st);
          let at;
          e.reset(st), e.reset(P), e.template_effect(() => at = e.set_style(ct, "", at, {
            width: `${e.get(K).last_progress_level * 100}%`,
            transition: e.get(K).progress_bar_transition
          })), e.append(N, P);
        }, H = (N) => {
          var P = e.comment(), X = e.first_child(P);
          {
            var it = (W) => {
              {
                let st = e.derived(() => C() === "default");
                zi(W, {
                  get margin() {
                    return e.get(st);
                  }
                });
              }
            };
            e.if(
              X,
              (W) => {
                v() === "full" && W(it);
              },
              !0
            );
          }
          e.append(N, P);
        };
        e.if(I, (N) => {
          e.get(K).last_progress_level != null ? N(O) : N(H, !1);
        });
      }
      var $ = e.sibling(I, 2);
      {
        var z = (N) => {
          var P = Wi(), X = e.first_child(P), it = e.child(X, !0);
          e.reset(X);
          var W = e.sibling(X, 2);
          e.slot(W, l, "additional-loading-text", {}, null), e.template_effect(() => e.set_text(it, T())), e.append(N, P);
        };
        e.if($, (N) => {
          S() || N(z);
        });
      }
      e.template_effect(() => u = e.set_class(o, 1, "progress-text svelte-124hqw6", null, u, {
        "meta-text-center": C() === "center",
        "meta-text": C() === "default"
      })), e.append(ot, et);
    }, lt = (ot) => {
      var et = e.comment(), D = e.first_child(et);
      {
        var y = (o) => {
          var u = Ki(), m = e.first_child(u), g = e.child(m);
          {
            let I = e.derived(() => l.i18n("common.clear"));
            qt(g, {
              get Icon() {
                return pe;
              },
              get label() {
                return e.get(I);
              },
              disabled: !1,
              $$events: {
                click: () => {
                  l.on_clear_status?.();
                }
              }
            });
          }
          e.reset(m);
          var c = e.sibling(m, 2), b = e.child(c, !0);
          e.reset(c);
          var R = e.sibling(c, 2);
          e.slot(R, l, "error", {}, null), e.template_effect((I) => e.set_text(b, I), [() => l.i18n("common.error")]), e.append(o, u);
        };
        e.if(
          D,
          (o) => {
            l.status === "error" && o(y);
          },
          !0
        );
      }
      e.append(ot, et);
    };
    e.if(dt, (ot) => {
      l.status === "pending" ? ot(ft) : ot(lt, !1);
    });
  }
  e.reset(Q), e.bind_this(Q, (ot) => w = ot, () => w), e.template_effect(() => {
    J = e.set_class(Q, 1, `wrap ${C() ?? ""} ${v() ?? ""}`, "svelte-124hqw6", J, {
      "no-click": p() && F(),
      hide: e.get(L),
      translucent: C() === "center" && (l.status === "pending" || l.status === "error") || n() || v() === "minimal" || p(),
      generating: l.status === "generating" && v() === "full",
      border: f()
    }), tt = e.set_style(Q, "", tt, {
      position: A() ? "absolute" : "static",
      padding: A() ? "0" : "var(--size-8) 0"
    });
  }), e.append(V, Q), e.pop();
}
e.from_html('<span class="toast-count svelte-17ll3xi"> </span>');
e.from_html('<div class="toast-separator svelte-17ll3xi"></div>');
e.from_html('<div><div data-testid="toast-text"><!></div></div> <!>', 1);
e.from_html('<div class="toast-messages svelte-17ll3xi"></div>');
e.from_html("<div></div>");
e.from_html('<div role="status" aria-live="polite" data-testid="toast-body"><div class="toast-header svelte-17ll3xi" role="button" tabindex="0"><div><!></div> <div class="toast-title-row svelte-17ll3xi"><span> <!></span> <div><!></div></div> <button type="button" aria-label="Close" data-testid="toast-close"><span aria-hidden="true">&#215;</span></button></div> <!> <!></div>');
e.from_html('<div class="toast-item svelte-l56nvb"><!></div>');
e.from_html('<div class="toast-wrap svelte-l56nvb"></div>');
e.from_html('<div class="streaming-bar svelte-xj6qzf"></div>');
var tn = e.from_html('<div class="file svelte-12marlv"><span><div class="progress-bar svelte-12marlv"><progress style="visibility:hidden;height:0;width:0;" max="100" class="svelte-12marlv"> </progress></div></span> <span class="file-name svelte-12marlv"> </span></div>'), en = e.from_html('<div><span class="uploading svelte-12marlv"> </span> <!></div>');
function sn(V, l) {
  e.push(l, !1);
  var a = this && this.__awaiter || function(k, L, M, B) {
    function U(q) {
      return q instanceof M ? q : new M(function(Z) {
        Z(q);
      });
    }
    return new (M || (M = Promise))(function(q, Z) {
      function K(j) {
        try {
          G(B.next(j));
        } catch (Q) {
          Z(Q);
        }
      }
      function Y(j) {
        try {
          G(B.throw(j));
        } catch (Q) {
          Z(Q);
        }
      }
      function G(j) {
        j.done ? q(j.value) : U(j.value).then(K, Y);
      }
      G((B = B.apply(k, L || [])).next());
    });
  };
  let s = e.prop(l, "upload_id", 8), S = e.prop(l, "root", 8), v = e.prop(l, "files", 8), _ = e.prop(l, "stream_handler", 8), x, C = e.mutable_source(!1), T = e.mutable_source(), A = e.mutable_source(), n = e.mutable_source(v().map((k) => Object.assign(Object.assign({}, k), { progress: 0 })));
  const f = ae();
  function p(k, L) {
    e.set(n, e.get(n).map((M) => (M.orig_name === k && (M.progress += L), M)));
  }
  function F(k) {
    return k.progress * 100 / (k.size || 0) || 0;
  }
  je(() => a(void 0, void 0, void 0, function* () {
    if (x = yield _()(new URL(`${S()}/gradio_api/upload_progress?upload_id=${s()}`)), x == null)
      throw new Error("Event source is not defined");
    x.onmessage = function(k) {
      return a(this, void 0, void 0, function* () {
        const L = JSON.parse(k.data);
        e.get(C) || e.set(C, !0), L.msg === "done" ? (x?.close(), f("done")) : (e.set(T, L), p(L.orig_name, L.chunk_size));
      });
    };
  })), os(() => {
    (x != null || x != null) && x.close();
  });
  function r(k) {
    let L = 0;
    return k.forEach((M) => {
      L += F(M);
    }), document.documentElement.style.setProperty("--upload-progress-width", (L / k.length).toFixed(2) + "%"), L / k.length;
  }
  e.legacy_pre_effect(() => e.get(n), () => {
    r(e.get(n));
  }), e.legacy_pre_effect(() => (e.get(T), e.get(n)), () => {
    e.set(A, e.get(T) || e.get(n)[0]);
  }), e.legacy_pre_effect_reset(), e.init();
  var w = en();
  let t;
  var i = e.child(w), h = e.child(i);
  e.reset(i);
  var d = e.sibling(i, 2);
  {
    var E = (k) => {
      var L = tn(), M = e.child(L), B = e.child(M), U = e.child(B), q = e.child(U, !0);
      e.reset(U), e.reset(B), e.reset(M);
      var Z = e.sibling(M, 2), K = e.child(Z, !0);
      e.reset(Z), e.reset(L), e.template_effect(
        (Y, G) => {
          e.set_value(U, Y), e.set_text(q, G), e.set_text(K, (e.get(A), e.untrack(() => e.get(A).orig_name)));
        },
        [
          () => (e.get(A), e.untrack(() => F(e.get(A)))),
          () => (e.get(A), e.untrack(() => F(e.get(A))))
        ]
      ), e.append(k, L);
    };
    e.if(d, (k) => {
      e.get(A) && k(E);
    });
  }
  e.reset(w), e.template_effect(() => {
    t = e.set_class(w, 1, "wrap svelte-12marlv", null, t, { progress: e.get(C) }), e.set_text(h, `Uploading ${e.get(n), e.untrack(() => e.get(n).length) ?? ""}
		${e.get(n), e.untrack(() => e.get(n).length > 1 ? "files" : "file") ?? ""}...`);
  }), e.append(V, w), e.pop();
}
function nn() {
  let V, l;
  return {
    drag(a, s = {}) {
      l = s;
      function S() {
        V = document.createElement("input"), V.type = "file", V.style.display = "none", V.setAttribute("aria-label", "File upload"), V.setAttribute("data-testid", "file-upload");
        const n = Array.isArray(l.accepted_types) ? l.accepted_types.join(",") : l.accepted_types || void 0;
        n && (V.accept = n), V.multiple = l.mode === "multiple" || !1, l.mode === "directory" && (V.webkitdirectory = !0, V.setAttribute("directory", ""), V.setAttribute("mozdirectory", "")), a.appendChild(V);
      }
      S();
      function v(n) {
        n.preventDefault(), n.stopPropagation();
      }
      function _(n) {
        n.preventDefault(), n.stopPropagation(), l.on_drag_change?.(!0);
      }
      function x(n) {
        n.preventDefault(), n.stopPropagation(), l.on_drag_change?.(!1);
      }
      function C(n) {
        if (n.preventDefault(), n.stopPropagation(), l.on_drag_change?.(!1), !n.dataTransfer?.files)
          return;
        const f = Array.from(n.dataTransfer.files);
        f.length > 0 && l.on_files?.(f);
      }
      function T() {
        l.disable_click || (V.value = "", V.click());
      }
      function A() {
        if (V.files) {
          const n = Array.from(V.files);
          n.length > 0 && l.on_files?.(n);
        }
      }
      return a.addEventListener("drag", v), a.addEventListener("dragstart", v), a.addEventListener("dragend", v), a.addEventListener("dragover", v), a.addEventListener("dragenter", _), a.addEventListener("dragleave", x), a.addEventListener("drop", C), a.addEventListener("click", T), V.addEventListener("change", A), {
        update(n) {
          l = n, V.remove(), S(), V.addEventListener("change", A);
        },
        destroy() {
          a.removeEventListener("drag", v), a.removeEventListener("dragstart", v), a.removeEventListener("dragend", v), a.removeEventListener("dragover", v), a.removeEventListener("dragenter", _), a.removeEventListener("dragleave", x), a.removeEventListener("drop", C), a.removeEventListener("click", T), V.removeEventListener("change", A), V.remove();
        }
      };
    },
    open_file_upload() {
      V && (V.value = "", V.click());
    }
  };
}
var rn = e.from_html("<button><!></button>"), an = e.from_html('<button aria-dropeffect="copy"><!></button>');
function on(V, l) {
  e.push(l, !1);
  const a = e.mutable_source();
  var s = this && this.__awaiter || function(m, g, c, b) {
    function R(I) {
      return I instanceof c ? I : new c(function(O) {
        O(I);
      });
    }
    return new (c || (c = Promise))(function(I, O) {
      function H(N) {
        try {
          z(b.next(N));
        } catch (P) {
          O(P);
        }
      }
      function $(N) {
        try {
          z(b.throw(N));
        } catch (P) {
          O(P);
        }
      }
      function z(N) {
        N.done ? I(N.value) : R(N.value).then(H, $);
      }
      z((b = b.apply(m, g || [])).next());
    });
  };
  const { drag: S, open_file_upload: v } = nn();
  let _ = e.prop(l, "filetype", 12, null), x = e.prop(l, "dragging", 12, !1), C = e.prop(l, "boundedheight", 8, !0), T = e.prop(l, "center", 8, !0), A = e.prop(l, "flex", 8, !0), n = e.prop(l, "file_count", 8, "single"), f = e.prop(l, "disable_click", 8, !1), p = e.prop(l, "root", 8), F = e.prop(l, "hidden", 8, !1), r = e.prop(l, "format", 8, "file"), w = e.prop(l, "uploading", 12, !1), t = e.prop(l, "show_progress", 8, !0), i = e.prop(l, "max_file_size", 8, null), h = e.prop(l, "upload", 8), d = e.prop(l, "stream_handler", 8), E = e.prop(l, "icon_upload", 8, !1), k = e.prop(l, "height", 8, void 0), L = e.prop(l, "aria_label", 8, void 0), M = e.prop(l, "upload_promise", 12, null);
  function B() {
    v();
  }
  let U = e.mutable_source(""), q = e.mutable_source(), Z = e.mutable_source(), K = null;
  const Y = () => {
    if (typeof navigator < "u") {
      const m = navigator.userAgent.toLowerCase();
      return m.indexOf("iphone") > -1 || m.indexOf("ipad") > -1;
    }
    return !1;
  }, G = ae(), j = ["image", "video", "audio", "text", "file"], Q = (m) => e.get(a) && m.startsWith(".") ? (K = !0, m) : e.get(a) && m.includes("file/*") ? "*" : m.startsWith(".") || m.endsWith("/*") ? m : j.includes(m) ? m + "/*" : "." + m;
  function J() {
    navigator.clipboard.read().then((m) => s(this, void 0, void 0, function* () {
      for (let g = 0; g < m.length; g++) {
        const c = m[g].types.find((b) => b.startsWith("image/"));
        if (c) {
          m[g].getType(c).then((b) => s(this, void 0, void 0, function* () {
            const R = new File([b], `clipboard.${c.replace("image/", "")}`);
            yield dt([R]);
          }));
          break;
        }
      }
    }));
  }
  function tt() {
    v();
  }
  function rt(m, g) {
    return M(new Promise((c, b) => s(this, void 0, void 0, function* () {
      yield se(), g ? e.set(U, g) : e.set(U, Math.random().toString(36).substring(2, 15)), w(!0);
      try {
        const R = yield h()(m, p(), e.get(U), i() !== null && i() !== void 0 ? i() : 1 / 0);
        return G("load", n() === "single" ? R?.[0] : R), c(R || []), w(!1), R || [];
      } catch (R) {
        G("error", R.message), w(!1), c([]);
      }
    }))), M();
  }
  function ut(m, g, c) {
    if (!m || m === "*" || m === "file/*" || Array.isArray(m) && m.some((R) => R === "*" || R === "file/*"))
      return !0;
    let b;
    if (typeof m == "string")
      b = m.split(",").map((R) => R.trim());
    else if (Array.isArray(m))
      b = m;
    else
      return !1;
    return b.includes(g) || b.some((R) => {
      const [I] = R.split("/").map((O) => O.trim());
      return R.endsWith("/*") && c.startsWith(I + "/");
    });
  }
  function dt(m, g) {
    return s(this, void 0, void 0, function* () {
      if (!m.length)
        return;
      let c = m.map((b) => new File([b], b instanceof File ? b.name : "file", { type: b.type }));
      return e.get(a) && K && (c = c.filter((b) => ft(b) ? !0 : (G("error", `Invalid file type: ${b.name}. Only ${_()} allowed.`), !1)), c.length === 0) ? [] : (e.set(q, yield Mi(c)), yield rt(e.get(q), g));
    });
  }
  function ft(m) {
    return _() ? (Array.isArray(_()) ? _() : [_()]).some((c) => {
      const b = Q(c);
      if (b.startsWith("."))
        return m.name.toLowerCase().endsWith(b.toLowerCase());
      if (b === "*")
        return !0;
      if (b.endsWith("/*")) {
        const [R] = b.split("/");
        return m.type.startsWith(R + "/");
      }
      return m.type === b;
    }) : !0;
  }
  function lt(m) {
    return s(this, void 0, void 0, function* () {
      const g = m.filter((c) => {
        const b = "." + c.name.toLowerCase().split(".").pop();
        return b && ut(e.get(Z), b, c.type) || (b && Array.isArray(_()) ? _().includes(b) : b === _()) ? !0 : (G("error", `Invalid file type only ${_()} allowed.`), !1);
      });
      if (r() != "blob")
        yield dt(g);
      else {
        if (n() === "single") {
          G("load", g[0]);
          return;
        }
        G("load", g);
      }
    });
  }
  function ot(m) {
    return s(this, void 0, void 0, function* () {
      var g;
      if (x(!1), !(!((g = m.dataTransfer) === null || g === void 0) && g.files)) return;
      const c = Array.from(m.dataTransfer.files).filter(ft);
      if (r() != "blob")
        yield dt(c);
      else {
        if (n() === "single") {
          G("load", c[0]);
          return;
        }
        G("load", c);
      }
    });
  }
  e.legacy_pre_effect(() => {
  }, () => {
    e.set(a, Y());
  }), e.legacy_pre_effect(() => (e.deep_read_state(_()), e.get(a)), () => {
    _() == null ? e.set(Z, null) : typeof _() == "string" ? e.set(Z, Q(_())) : e.get(a) && _().includes("file/*") ? e.set(Z, "*") : (_(_().map(Q)), e.set(Z, _().join(", ")));
  }), e.legacy_pre_effect_reset();
  var et = {
    open_upload: B,
    paste_clipboard: J,
    open_file_upload: tt,
    load_files: dt,
    load_files_from_drop: ot
  };
  e.init();
  var D = e.comment(), y = e.first_child(D);
  {
    var o = (m) => {
      var g = rn();
      let c, b;
      var R = e.child(g);
      e.slot(R, l, "default", {}, null), e.reset(g), e.template_effect(() => {
        e.set_attribute(g, "tabindex", F() ? -1 : 0), e.set_attribute(g, "aria-label", L() || "Paste from clipboard"), c = e.set_class(g, 1, "svelte-tgi0k0", null, c, {
          hidden: F(),
          center: T(),
          boundedheight: C(),
          flex: A(),
          "icon-mode": E()
        }), b = e.set_style(g, "", b, {
          height: E() ? "" : k() ? typeof k() == "number" ? k() + "px" : k() : "100%"
        });
      }), e.event("click", g, J), e.append(m, g);
    }, u = (m) => {
      var g = e.comment(), c = e.first_child(g);
      {
        var b = (I) => {
          var O = e.comment(), H = e.first_child(O);
          {
            var $ = (z) => {
              sn(z, {
                get root() {
                  return p();
                },
                get upload_id() {
                  return e.get(U);
                },
                get files() {
                  return e.get(q);
                },
                get stream_handler() {
                  return d();
                }
              });
            };
            e.if(H, (z) => {
              F() || z($);
            });
          }
          e.append(I, O);
        }, R = (I) => {
          var O = an();
          let H, $;
          var z = e.child(O);
          e.slot(z, l, "default", {}, null), e.reset(O), e.action(O, (N, P) => S?.(N, P), () => ({
            on_drag_change: (N) => N = N,
            on_files: (N) => lt(N),
            accepted_types: e.get(Z),
            mode: n(),
            disable_click: f()
          })), e.template_effect(() => {
            e.set_attribute(O, "tabindex", F() ? -1 : 0), e.set_attribute(O, "aria-label", L() || "Click to upload or drop files"), H = e.set_class(O, 1, "svelte-tgi0k0", null, H, {
              hidden: F(),
              center: T(),
              boundedheight: C(),
              flex: A(),
              disable_click: f(),
              "icon-mode": E()
            }), $ = e.set_style(O, "", $, {
              height: E() ? "" : k() ? typeof k() == "number" ? k() + "px" : k() : "100%"
            });
          }), e.append(I, O);
        };
        e.if(
          c,
          (I) => {
            w() && t() ? I(b) : I(R, !1);
          },
          !0
        );
      }
      e.append(m, g);
    };
    e.if(y, (m) => {
      _() === "clipboard" ? m(o) : m(u, !1);
    });
  }
  return e.append(V, D), e.bind_prop(l, "open_upload", B), e.bind_prop(l, "paste_clipboard", J), e.bind_prop(l, "open_file_upload", tt), e.bind_prop(l, "load_files", dt), e.bind_prop(l, "load_files_from_drop", ot), e.pop(et);
}
var ln = e.from_html("<!> <!> <!> <!> <!>", 1);
function hn(V, l) {
  e.push(l, !1);
  let a = e.prop(l, "editable", 8, !1), s = e.prop(l, "undoable", 8, !1), S = e.prop(l, "download", 8, null), v = e.prop(l, "i18n", 8);
  const _ = ae();
  e.init(), Ii(V, {
    children: (x, C) => {
      var T = ln(), A = e.first_child(T);
      {
        var n = (i) => {
          {
            let h = e.derived_safe_equal(() => (e.deep_read_state(v()), e.untrack(() => v()("common.edit"))));
            qt(i, {
              get Icon() {
                return ds;
              },
              get label() {
                return e.get(h);
              },
              $$events: { click: () => _("edit") }
            });
          }
        };
        e.if(A, (i) => {
          a() && i(n);
        });
      }
      var f = e.sibling(A, 2);
      {
        var p = (i) => {
          {
            let h = e.derived_safe_equal(() => (e.deep_read_state(v()), e.untrack(() => v()("common.undo"))));
            qt(i, {
              get Icon() {
                return gs;
              },
              get label() {
                return e.get(h);
              },
              $$events: { click: () => _("undo") }
            });
          }
        };
        e.if(f, (i) => {
          s() && i(p);
        });
      }
      var F = e.sibling(f, 2);
      {
        var r = (i) => {
          Fi(i, {
            get href() {
              return S();
            },
            download: !0,
            children: (h, d) => {
              {
                let E = e.derived_safe_equal(() => (e.deep_read_state(v()), e.untrack(() => v()("common.download"))));
                qt(h, {
                  get Icon() {
                    return cs;
                  },
                  get label() {
                    return e.get(E);
                  }
                });
              }
            },
            $$slots: { default: !0 }
          });
        };
        e.if(F, (i) => {
          S() && i(r);
        });
      }
      var w = e.sibling(F, 2);
      e.slot(w, l, "default", {}, null);
      var t = e.sibling(w, 2);
      {
        let i = e.derived_safe_equal(() => (e.deep_read_state(v()), e.untrack(() => v()("common.clear"))));
        qt(t, {
          get Icon() {
            return pe;
          },
          get label() {
            return e.get(i);
          },
          $$events: {
            click: (h) => {
              _("clear"), h.stopPropagation();
            }
          }
        });
      }
      e.append(x, T);
    },
    $$slots: { default: !0 }
  }), e.pop();
}
var cn = {
  /***/
  976: (
    /***/
    ((V, l, a) => {
      a.d(l, {
        AnnotationLayer: () => (
          /* binding */
          ot
        ),
        FreeTextAnnotationElement: () => (
          /* binding */
          q
        ),
        InkAnnotationElement: () => (
          /* binding */
          J
        ),
        StampAnnotationElement: () => (
          /* binding */
          ft
        )
      });
      var s = a(292), S = a(419), v = a(792);
      function _(et) {
        return Math.floor(Math.max(0, Math.min(1, et)) * 255).toString(16).padStart(2, "0");
      }
      function x(et) {
        return Math.max(0, Math.min(255, 255 * et));
      }
      class C {
        static CMYK_G([D, y, o, u]) {
          return ["G", 1 - Math.min(1, 0.3 * D + 0.59 * o + 0.11 * y + u)];
        }
        static G_CMYK([D]) {
          return ["CMYK", 0, 0, 0, 1 - D];
        }
        static G_RGB([D]) {
          return ["RGB", D, D, D];
        }
        static G_rgb([D]) {
          return D = x(D), [D, D, D];
        }
        static G_HTML([D]) {
          const y = _(D);
          return `#${y}${y}${y}`;
        }
        static RGB_G([D, y, o]) {
          return ["G", 0.3 * D + 0.59 * y + 0.11 * o];
        }
        static RGB_rgb(D) {
          return D.map(x);
        }
        static RGB_HTML(D) {
          return `#${D.map(_).join("")}`;
        }
        static T_HTML() {
          return "#00000000";
        }
        static T_rgb() {
          return [null];
        }
        static CMYK_RGB([D, y, o, u]) {
          return ["RGB", 1 - Math.min(1, D + u), 1 - Math.min(1, o + u), 1 - Math.min(1, y + u)];
        }
        static CMYK_rgb([D, y, o, u]) {
          return [x(1 - Math.min(1, D + u)), x(1 - Math.min(1, o + u)), x(1 - Math.min(1, y + u))];
        }
        static CMYK_HTML(D) {
          const y = this.CMYK_RGB(D).slice(1);
          return this.RGB_HTML(y);
        }
        static RGB_CMYK([D, y, o]) {
          const u = 1 - D, m = 1 - y, g = 1 - o, c = Math.min(u, m, g);
          return ["CMYK", u, m, g, c];
        }
      }
      var T = a(284);
      const A = 1e3, n = 9, f = /* @__PURE__ */ new WeakSet();
      function p(et) {
        return {
          width: et[2] - et[0],
          height: et[3] - et[1]
        };
      }
      class F {
        static create(D) {
          switch (D.data.annotationType) {
            case s.AnnotationType.LINK:
              return new w(D);
            case s.AnnotationType.TEXT:
              return new t(D);
            case s.AnnotationType.WIDGET:
              switch (D.data.fieldType) {
                case "Tx":
                  return new h(D);
                case "Btn":
                  return D.data.radioButton ? new k(D) : D.data.checkBox ? new E(D) : new L(D);
                case "Ch":
                  return new M(D);
                case "Sig":
                  return new d(D);
              }
              return new i(D);
            case s.AnnotationType.POPUP:
              return new B(D);
            case s.AnnotationType.FREETEXT:
              return new q(D);
            case s.AnnotationType.LINE:
              return new Z(D);
            case s.AnnotationType.SQUARE:
              return new K(D);
            case s.AnnotationType.CIRCLE:
              return new Y(D);
            case s.AnnotationType.POLYLINE:
              return new G(D);
            case s.AnnotationType.CARET:
              return new Q(D);
            case s.AnnotationType.INK:
              return new J(D);
            case s.AnnotationType.POLYGON:
              return new j(D);
            case s.AnnotationType.HIGHLIGHT:
              return new tt(D);
            case s.AnnotationType.UNDERLINE:
              return new rt(D);
            case s.AnnotationType.SQUIGGLY:
              return new ut(D);
            case s.AnnotationType.STRIKEOUT:
              return new dt(D);
            case s.AnnotationType.STAMP:
              return new ft(D);
            case s.AnnotationType.FILEATTACHMENT:
              return new lt(D);
            default:
              return new r(D);
          }
        }
      }
      class r {
        #t = null;
        #e = !1;
        constructor(D, {
          isRenderable: y = !1,
          ignoreBorder: o = !1,
          createQuadrilaterals: u = !1
        } = {}) {
          this.isRenderable = y, this.data = D.data, this.layer = D.layer, this.linkService = D.linkService, this.downloadManager = D.downloadManager, this.imageResourcesPath = D.imageResourcesPath, this.renderForms = D.renderForms, this.svgFactory = D.svgFactory, this.annotationStorage = D.annotationStorage, this.enableScripting = D.enableScripting, this.hasJSActions = D.hasJSActions, this._fieldObjects = D.fieldObjects, this.parent = D.parent, y && (this.container = this._createContainer(o)), u && this._createQuadrilaterals();
        }
        static _hasPopupData({
          titleObj: D,
          contentsObj: y,
          richText: o
        }) {
          return !!(D?.str || y?.str || o?.str);
        }
        get hasPopupData() {
          return r._hasPopupData(this.data);
        }
        updateEdited(D) {
          if (!this.container)
            return;
          this.#t ||= {
            rect: this.data.rect.slice(0)
          };
          const {
            rect: y
          } = D;
          y && this.#s(y);
        }
        resetEdited() {
          this.#t && (this.#s(this.#t.rect), this.#t = null);
        }
        #s(D) {
          const {
            container: {
              style: y
            },
            data: {
              rect: o,
              rotation: u
            },
            parent: {
              viewport: {
                rawDims: {
                  pageWidth: m,
                  pageHeight: g,
                  pageX: c,
                  pageY: b
                }
              }
            }
          } = this;
          o?.splice(0, 4, ...D);
          const {
            width: R,
            height: I
          } = p(D);
          y.left = `${100 * (D[0] - c) / m}%`, y.top = `${100 * (g - D[3] + b) / g}%`, u === 0 ? (y.width = `${100 * R / m}%`, y.height = `${100 * I / g}%`) : this.setRotation(u);
        }
        _createContainer(D) {
          const {
            data: y,
            parent: {
              page: o,
              viewport: u
            }
          } = this, m = document.createElement("section");
          m.setAttribute("data-annotation-id", y.id), this instanceof i || (m.tabIndex = A);
          const {
            style: g
          } = m;
          if (g.zIndex = this.parent.zIndex++, y.popupRef && m.setAttribute("aria-haspopup", "dialog"), y.alternativeText && (m.title = y.alternativeText), y.noRotate && m.classList.add("norotate"), !y.rect || this instanceof B) {
            const {
              rotation: N
            } = y;
            return !y.hasOwnCanvas && N !== 0 && this.setRotation(N, m), m;
          }
          const {
            width: c,
            height: b
          } = p(y.rect);
          if (!D && y.borderStyle.width > 0) {
            g.borderWidth = `${y.borderStyle.width}px`;
            const N = y.borderStyle.horizontalCornerRadius, P = y.borderStyle.verticalCornerRadius;
            if (N > 0 || P > 0) {
              const it = `calc(${N}px * var(--scale-factor)) / calc(${P}px * var(--scale-factor))`;
              g.borderRadius = it;
            } else if (this instanceof k) {
              const it = `calc(${c}px * var(--scale-factor)) / calc(${b}px * var(--scale-factor))`;
              g.borderRadius = it;
            }
            switch (y.borderStyle.style) {
              case s.AnnotationBorderStyleType.SOLID:
                g.borderStyle = "solid";
                break;
              case s.AnnotationBorderStyleType.DASHED:
                g.borderStyle = "dashed";
                break;
              case s.AnnotationBorderStyleType.BEVELED:
                (0, s.warn)("Unimplemented border style: beveled");
                break;
              case s.AnnotationBorderStyleType.INSET:
                (0, s.warn)("Unimplemented border style: inset");
                break;
              case s.AnnotationBorderStyleType.UNDERLINE:
                g.borderBottomStyle = "solid";
                break;
            }
            const X = y.borderColor || null;
            X ? (this.#e = !0, g.borderColor = s.Util.makeHexColor(X[0] | 0, X[1] | 0, X[2] | 0)) : g.borderWidth = 0;
          }
          const R = s.Util.normalizeRect([y.rect[0], o.view[3] - y.rect[1] + o.view[1], y.rect[2], o.view[3] - y.rect[3] + o.view[1]]), {
            pageWidth: I,
            pageHeight: O,
            pageX: H,
            pageY: $
          } = u.rawDims;
          g.left = `${100 * (R[0] - H) / I}%`, g.top = `${100 * (R[1] - $) / O}%`;
          const {
            rotation: z
          } = y;
          return y.hasOwnCanvas || z === 0 ? (g.width = `${100 * c / I}%`, g.height = `${100 * b / O}%`) : this.setRotation(z, m), m;
        }
        setRotation(D, y = this.container) {
          if (!this.data.rect)
            return;
          const {
            pageWidth: o,
            pageHeight: u
          } = this.parent.viewport.rawDims, {
            width: m,
            height: g
          } = p(this.data.rect);
          let c, b;
          D % 180 === 0 ? (c = 100 * m / o, b = 100 * g / u) : (c = 100 * g / o, b = 100 * m / u), y.style.width = `${c}%`, y.style.height = `${b}%`, y.setAttribute("data-main-rotation", (360 - D) % 360);
        }
        get _commonActions() {
          const D = (y, o, u) => {
            const m = u.detail[y], g = m[0], c = m.slice(1);
            u.target.style[o] = C[`${g}_HTML`](c), this.annotationStorage.setValue(this.data.id, {
              [o]: C[`${g}_rgb`](c)
            });
          };
          return (0, s.shadow)(this, "_commonActions", {
            display: (y) => {
              const {
                display: o
              } = y.detail, u = o % 2 === 1;
              this.container.style.visibility = u ? "hidden" : "visible", this.annotationStorage.setValue(this.data.id, {
                noView: u,
                noPrint: o === 1 || o === 2
              });
            },
            print: (y) => {
              this.annotationStorage.setValue(this.data.id, {
                noPrint: !y.detail.print
              });
            },
            hidden: (y) => {
              const {
                hidden: o
              } = y.detail;
              this.container.style.visibility = o ? "hidden" : "visible", this.annotationStorage.setValue(this.data.id, {
                noPrint: o,
                noView: o
              });
            },
            focus: (y) => {
              setTimeout(() => y.target.focus({
                preventScroll: !1
              }), 0);
            },
            userName: (y) => {
              y.target.title = y.detail.userName;
            },
            readonly: (y) => {
              y.target.disabled = y.detail.readonly;
            },
            required: (y) => {
              this._setRequired(y.target, y.detail.required);
            },
            bgColor: (y) => {
              D("bgColor", "backgroundColor", y);
            },
            fillColor: (y) => {
              D("fillColor", "backgroundColor", y);
            },
            fgColor: (y) => {
              D("fgColor", "color", y);
            },
            textColor: (y) => {
              D("textColor", "color", y);
            },
            borderColor: (y) => {
              D("borderColor", "borderColor", y);
            },
            strokeColor: (y) => {
              D("strokeColor", "borderColor", y);
            },
            rotation: (y) => {
              const o = y.detail.rotation;
              this.setRotation(o), this.annotationStorage.setValue(this.data.id, {
                rotation: o
              });
            }
          });
        }
        _dispatchEventFromSandbox(D, y) {
          const o = this._commonActions;
          for (const u of Object.keys(y.detail))
            (D[u] || o[u])?.(y);
        }
        _setDefaultPropertiesFromJS(D) {
          if (!this.enableScripting)
            return;
          const y = this.annotationStorage.getRawValue(this.data.id);
          if (!y)
            return;
          const o = this._commonActions;
          for (const [u, m] of Object.entries(y)) {
            const g = o[u];
            if (g) {
              const c = {
                detail: {
                  [u]: m
                },
                target: D
              };
              g(c), delete y[u];
            }
          }
        }
        _createQuadrilaterals() {
          if (!this.container)
            return;
          const {
            quadPoints: D
          } = this.data;
          if (!D)
            return;
          const [y, o, u, m] = this.data.rect;
          if (D.length === 1) {
            const [, {
              x: N,
              y: P
            }, {
              x: X,
              y: it
            }] = D[0];
            if (u === N && m === P && y === X && o === it)
              return;
          }
          const {
            style: g
          } = this.container;
          let c;
          if (this.#e) {
            const {
              borderColor: N,
              borderWidth: P
            } = g;
            g.borderWidth = 0, c = ["url('data:image/svg+xml;utf8,", '<svg xmlns="http://www.w3.org/2000/svg"', ' preserveAspectRatio="none" viewBox="0 0 1 1">', `<g fill="transparent" stroke="${N}" stroke-width="${P}">`], this.container.classList.add("hasBorder");
          }
          const b = u - y, R = m - o, {
            svgFactory: I
          } = this, O = I.createElement("svg");
          O.classList.add("quadrilateralsContainer"), O.setAttribute("width", 0), O.setAttribute("height", 0);
          const H = I.createElement("defs");
          O.append(H);
          const $ = I.createElement("clipPath"), z = `clippath_${this.data.id}`;
          $.setAttribute("id", z), $.setAttribute("clipPathUnits", "objectBoundingBox"), H.append($);
          for (const [, {
            x: N,
            y: P
          }, {
            x: X,
            y: it
          }] of D) {
            const W = I.createElement("rect"), st = (X - y) / b, ct = (m - P) / R, at = (N - X) / b, nt = (P - it) / R;
            W.setAttribute("x", st), W.setAttribute("y", ct), W.setAttribute("width", at), W.setAttribute("height", nt), $.append(W), c?.push(`<rect vector-effect="non-scaling-stroke" x="${st}" y="${ct}" width="${at}" height="${nt}"/>`);
          }
          this.#e && (c.push("</g></svg>')"), g.backgroundImage = c.join("")), this.container.append(O), this.container.style.clipPath = `url(#${z})`;
        }
        _createPopup() {
          const {
            container: D,
            data: y
          } = this;
          D.setAttribute("aria-haspopup", "dialog");
          const o = new B({
            data: {
              color: y.color,
              titleObj: y.titleObj,
              modificationDate: y.modificationDate,
              contentsObj: y.contentsObj,
              richText: y.richText,
              parentRect: y.rect,
              borderStyle: 0,
              id: `popup_${y.id}`,
              rotation: y.rotation
            },
            parent: this.parent,
            elements: [this]
          });
          this.parent.div.append(o.render());
        }
        render() {
          (0, s.unreachable)("Abstract method `AnnotationElement.render` called");
        }
        _getElementsByName(D, y = null) {
          const o = [];
          if (this._fieldObjects) {
            const u = this._fieldObjects[D];
            if (u)
              for (const {
                page: m,
                id: g,
                exportValues: c
              } of u) {
                if (m === -1 || g === y)
                  continue;
                const b = typeof c == "string" ? c : null, R = document.querySelector(`[data-element-id="${g}"]`);
                if (R && !f.has(R)) {
                  (0, s.warn)(`_getElementsByName - element not allowed: ${g}`);
                  continue;
                }
                o.push({
                  id: g,
                  exportValue: b,
                  domElement: R
                });
              }
            return o;
          }
          for (const u of document.getElementsByName(D)) {
            const {
              exportValue: m
            } = u, g = u.getAttribute("data-element-id");
            g !== y && f.has(u) && o.push({
              id: g,
              exportValue: m,
              domElement: u
            });
          }
          return o;
        }
        show() {
          this.container && (this.container.hidden = !1), this.popup?.maybeShow();
        }
        hide() {
          this.container && (this.container.hidden = !0), this.popup?.forceHide();
        }
        getElementsToTriggerPopup() {
          return this.container;
        }
        addHighlightArea() {
          const D = this.getElementsToTriggerPopup();
          if (Array.isArray(D))
            for (const y of D)
              y.classList.add("highlightArea");
          else
            D.classList.add("highlightArea");
        }
        get _isEditable() {
          return !1;
        }
        _editOnDoubleClick() {
          if (!this._isEditable)
            return;
          const {
            annotationEditorType: D,
            data: {
              id: y
            }
          } = this;
          this.container.addEventListener("dblclick", () => {
            this.linkService.eventBus?.dispatch("switchannotationeditormode", {
              source: this,
              mode: D,
              editId: y
            });
          });
        }
      }
      class w extends r {
        constructor(D, y = null) {
          super(D, {
            isRenderable: !0,
            ignoreBorder: !!y?.ignoreBorder,
            createQuadrilaterals: !0
          }), this.isTooltipOnly = D.data.isTooltipOnly;
        }
        render() {
          const {
            data: D,
            linkService: y
          } = this, o = document.createElement("a");
          o.setAttribute("data-element-id", D.id);
          let u = !1;
          return D.url ? (y.addLinkAttributes(o, D.url, D.newWindow), u = !0) : D.action ? (this._bindNamedAction(o, D.action), u = !0) : D.attachment ? (this.#e(o, D.attachment, D.attachmentDest), u = !0) : D.setOCGState ? (this.#s(o, D.setOCGState), u = !0) : D.dest ? (this._bindLink(o, D.dest), u = !0) : (D.actions && (D.actions.Action || D.actions["Mouse Up"] || D.actions["Mouse Down"]) && this.enableScripting && this.hasJSActions && (this._bindJSAction(o, D), u = !0), D.resetForm ? (this._bindResetFormAction(o, D.resetForm), u = !0) : this.isTooltipOnly && !u && (this._bindLink(o, ""), u = !0)), this.container.classList.add("linkAnnotation"), u && this.container.append(o), this.container;
        }
        #t() {
          this.container.setAttribute("data-internal-link", "");
        }
        _bindLink(D, y) {
          D.href = this.linkService.getDestinationHash(y), D.onclick = () => (y && this.linkService.goToDestination(y), !1), (y || y === "") && this.#t();
        }
        _bindNamedAction(D, y) {
          D.href = this.linkService.getAnchorUrl(""), D.onclick = () => (this.linkService.executeNamedAction(y), !1), this.#t();
        }
        #e(D, y, o = null) {
          D.href = this.linkService.getAnchorUrl(""), D.onclick = () => (this.downloadManager?.openOrDownloadData(y.content, y.filename, o), !1), this.#t();
        }
        #s(D, y) {
          D.href = this.linkService.getAnchorUrl(""), D.onclick = () => (this.linkService.executeSetOCGState(y), !1), this.#t();
        }
        _bindJSAction(D, y) {
          D.href = this.linkService.getAnchorUrl("");
          const o = /* @__PURE__ */ new Map([["Action", "onclick"], ["Mouse Up", "onmouseup"], ["Mouse Down", "onmousedown"]]);
          for (const u of Object.keys(y.actions)) {
            const m = o.get(u);
            m && (D[m] = () => (this.linkService.eventBus?.dispatch("dispatcheventinsandbox", {
              source: this,
              detail: {
                id: y.id,
                name: u
              }
            }), !1));
          }
          D.onclick || (D.onclick = () => !1), this.#t();
        }
        _bindResetFormAction(D, y) {
          const o = D.onclick;
          if (o || (D.href = this.linkService.getAnchorUrl("")), this.#t(), !this._fieldObjects) {
            (0, s.warn)('_bindResetFormAction - "resetForm" action not supported, ensure that the `fieldObjects` parameter is provided.'), o || (D.onclick = () => !1);
            return;
          }
          D.onclick = () => {
            o?.();
            const {
              fields: u,
              refs: m,
              include: g
            } = y, c = [];
            if (u.length !== 0 || m.length !== 0) {
              const I = new Set(m);
              for (const O of u) {
                const H = this._fieldObjects[O] || [];
                for (const {
                  id: $
                } of H)
                  I.add($);
              }
              for (const O of Object.values(this._fieldObjects))
                for (const H of O)
                  I.has(H.id) === g && c.push(H);
            } else
              for (const I of Object.values(this._fieldObjects))
                c.push(...I);
            const b = this.annotationStorage, R = [];
            for (const I of c) {
              const {
                id: O
              } = I;
              switch (R.push(O), I.type) {
                case "text": {
                  const $ = I.defaultValue || "";
                  b.setValue(O, {
                    value: $
                  });
                  break;
                }
                case "checkbox":
                case "radiobutton": {
                  const $ = I.defaultValue === I.exportValues;
                  b.setValue(O, {
                    value: $
                  });
                  break;
                }
                case "combobox":
                case "listbox": {
                  const $ = I.defaultValue || "";
                  b.setValue(O, {
                    value: $
                  });
                  break;
                }
                default:
                  continue;
              }
              const H = document.querySelector(`[data-element-id="${O}"]`);
              if (H) {
                if (!f.has(H)) {
                  (0, s.warn)(`_bindResetFormAction - element not allowed: ${O}`);
                  continue;
                }
              } else continue;
              H.dispatchEvent(new Event("resetform"));
            }
            return this.enableScripting && this.linkService.eventBus?.dispatch("dispatcheventinsandbox", {
              source: this,
              detail: {
                id: "app",
                ids: R,
                name: "ResetForm"
              }
            }), !1;
          };
        }
      }
      class t extends r {
        constructor(D) {
          super(D, {
            isRenderable: !0
          });
        }
        render() {
          this.container.classList.add("textAnnotation");
          const D = document.createElement("img");
          return D.src = this.imageResourcesPath + "annotation-" + this.data.name.toLowerCase() + ".svg", D.setAttribute("data-l10n-id", "pdfjs-text-annotation-type"), D.setAttribute("data-l10n-args", JSON.stringify({
            type: this.data.name
          })), !this.data.popupRef && this.hasPopupData && this._createPopup(), this.container.append(D), this.container;
        }
      }
      class i extends r {
        render() {
          return this.container;
        }
        showElementAndHideCanvas(D) {
          this.data.hasOwnCanvas && (D.previousSibling?.nodeName === "CANVAS" && (D.previousSibling.hidden = !0), D.hidden = !1);
        }
        _getKeyModifier(D) {
          return s.FeatureTest.platform.isMac ? D.metaKey : D.ctrlKey;
        }
        _setEventListener(D, y, o, u, m) {
          o.includes("mouse") ? D.addEventListener(o, (g) => {
            this.linkService.eventBus?.dispatch("dispatcheventinsandbox", {
              source: this,
              detail: {
                id: this.data.id,
                name: u,
                value: m(g),
                shift: g.shiftKey,
                modifier: this._getKeyModifier(g)
              }
            });
          }) : D.addEventListener(o, (g) => {
            if (o === "blur") {
              if (!y.focused || !g.relatedTarget)
                return;
              y.focused = !1;
            } else if (o === "focus") {
              if (y.focused)
                return;
              y.focused = !0;
            }
            m && this.linkService.eventBus?.dispatch("dispatcheventinsandbox", {
              source: this,
              detail: {
                id: this.data.id,
                name: u,
                value: m(g)
              }
            });
          });
        }
        _setEventListeners(D, y, o, u) {
          for (const [m, g] of o)
            (g === "Action" || this.data.actions?.[g]) && ((g === "Focus" || g === "Blur") && (y ||= {
              focused: !1
            }), this._setEventListener(D, y, m, g, u), g === "Focus" && !this.data.actions?.Blur ? this._setEventListener(D, y, "blur", "Blur", null) : g === "Blur" && !this.data.actions?.Focus && this._setEventListener(D, y, "focus", "Focus", null));
        }
        _setBackgroundColor(D) {
          const y = this.data.backgroundColor || null;
          D.style.backgroundColor = y === null ? "transparent" : s.Util.makeHexColor(y[0], y[1], y[2]);
        }
        _setTextStyle(D) {
          const y = ["left", "center", "right"], {
            fontColor: o
          } = this.data.defaultAppearanceData, u = this.data.defaultAppearanceData.fontSize || n, m = D.style;
          let g;
          const c = 2, b = (R) => Math.round(10 * R) / 10;
          if (this.data.multiLine) {
            const R = Math.abs(this.data.rect[3] - this.data.rect[1] - c), I = Math.round(R / (s.LINE_FACTOR * u)) || 1, O = R / I;
            g = Math.min(u, b(O / s.LINE_FACTOR));
          } else {
            const R = Math.abs(this.data.rect[3] - this.data.rect[1] - c);
            g = Math.min(u, b(R / s.LINE_FACTOR));
          }
          m.fontSize = `calc(${g}px * var(--scale-factor))`, m.color = s.Util.makeHexColor(o[0], o[1], o[2]), this.data.textAlignment !== null && (m.textAlign = y[this.data.textAlignment]);
        }
        _setRequired(D, y) {
          y ? D.setAttribute("required", !0) : D.removeAttribute("required"), D.setAttribute("aria-required", y);
        }
      }
      class h extends i {
        constructor(D) {
          const y = D.renderForms || D.data.hasOwnCanvas || !D.data.hasAppearance && !!D.data.fieldValue;
          super(D, {
            isRenderable: y
          });
        }
        setPropertyOnSiblings(D, y, o, u) {
          const m = this.annotationStorage;
          for (const g of this._getElementsByName(D.name, D.id))
            g.domElement && (g.domElement[y] = o), m.setValue(g.id, {
              [u]: o
            });
        }
        render() {
          const D = this.annotationStorage, y = this.data.id;
          this.container.classList.add("textWidgetAnnotation");
          let o = null;
          if (this.renderForms) {
            const u = D.getValue(y, {
              value: this.data.fieldValue
            });
            let m = u.value || "";
            const g = D.getValue(y, {
              charLimit: this.data.maxLen
            }).charLimit;
            g && m.length > g && (m = m.slice(0, g));
            let c = u.formattedValue || this.data.textContent?.join(`
`) || null;
            c && this.data.comb && (c = c.replaceAll(/\s+/g, ""));
            const b = {
              userValue: m,
              formattedValue: c,
              lastCommittedValue: null,
              commitKey: 1,
              focused: !1
            };
            this.data.multiLine ? (o = document.createElement("textarea"), o.textContent = c ?? m, this.data.doNotScroll && (o.style.overflowY = "hidden")) : (o = document.createElement("input"), o.type = "text", o.setAttribute("value", c ?? m), this.data.doNotScroll && (o.style.overflowX = "hidden")), this.data.hasOwnCanvas && (o.hidden = !0), f.add(o), o.setAttribute("data-element-id", y), o.disabled = this.data.readOnly, o.name = this.data.fieldName, o.tabIndex = A, this._setRequired(o, this.data.required), g && (o.maxLength = g), o.addEventListener("input", (I) => {
              D.setValue(y, {
                value: I.target.value
              }), this.setPropertyOnSiblings(o, "value", I.target.value, "value"), b.formattedValue = null;
            }), o.addEventListener("resetform", (I) => {
              const O = this.data.defaultFieldValue ?? "";
              o.value = b.userValue = O, b.formattedValue = null;
            });
            let R = (I) => {
              const {
                formattedValue: O
              } = b;
              O != null && (I.target.value = O), I.target.scrollLeft = 0;
            };
            if (this.enableScripting && this.hasJSActions) {
              o.addEventListener("focus", (O) => {
                if (b.focused)
                  return;
                const {
                  target: H
                } = O;
                b.userValue && (H.value = b.userValue), b.lastCommittedValue = H.value, b.commitKey = 1, this.data.actions?.Focus || (b.focused = !0);
              }), o.addEventListener("updatefromsandbox", (O) => {
                this.showElementAndHideCanvas(O.target);
                const H = {
                  value($) {
                    b.userValue = $.detail.value ?? "", D.setValue(y, {
                      value: b.userValue.toString()
                    }), $.target.value = b.userValue;
                  },
                  formattedValue($) {
                    const {
                      formattedValue: z
                    } = $.detail;
                    b.formattedValue = z, z != null && $.target !== document.activeElement && ($.target.value = z), D.setValue(y, {
                      formattedValue: z
                    });
                  },
                  selRange($) {
                    $.target.setSelectionRange(...$.detail.selRange);
                  },
                  charLimit: ($) => {
                    const {
                      charLimit: z
                    } = $.detail, {
                      target: N
                    } = $;
                    if (z === 0) {
                      N.removeAttribute("maxLength");
                      return;
                    }
                    N.setAttribute("maxLength", z);
                    let P = b.userValue;
                    !P || P.length <= z || (P = P.slice(0, z), N.value = b.userValue = P, D.setValue(y, {
                      value: P
                    }), this.linkService.eventBus?.dispatch("dispatcheventinsandbox", {
                      source: this,
                      detail: {
                        id: y,
                        name: "Keystroke",
                        value: P,
                        willCommit: !0,
                        commitKey: 1,
                        selStart: N.selectionStart,
                        selEnd: N.selectionEnd
                      }
                    }));
                  }
                };
                this._dispatchEventFromSandbox(H, O);
              }), o.addEventListener("keydown", (O) => {
                b.commitKey = 1;
                let H = -1;
                if (O.key === "Escape" ? H = 0 : O.key === "Enter" && !this.data.multiLine ? H = 2 : O.key === "Tab" && (b.commitKey = 3), H === -1)
                  return;
                const {
                  value: $
                } = O.target;
                b.lastCommittedValue !== $ && (b.lastCommittedValue = $, b.userValue = $, this.linkService.eventBus?.dispatch("dispatcheventinsandbox", {
                  source: this,
                  detail: {
                    id: y,
                    name: "Keystroke",
                    value: $,
                    willCommit: !0,
                    commitKey: H,
                    selStart: O.target.selectionStart,
                    selEnd: O.target.selectionEnd
                  }
                }));
              });
              const I = R;
              R = null, o.addEventListener("blur", (O) => {
                if (!b.focused || !O.relatedTarget)
                  return;
                this.data.actions?.Blur || (b.focused = !1);
                const {
                  value: H
                } = O.target;
                b.userValue = H, b.lastCommittedValue !== H && this.linkService.eventBus?.dispatch("dispatcheventinsandbox", {
                  source: this,
                  detail: {
                    id: y,
                    name: "Keystroke",
                    value: H,
                    willCommit: !0,
                    commitKey: b.commitKey,
                    selStart: O.target.selectionStart,
                    selEnd: O.target.selectionEnd
                  }
                }), I(O);
              }), this.data.actions?.Keystroke && o.addEventListener("beforeinput", (O) => {
                b.lastCommittedValue = null;
                const {
                  data: H,
                  target: $
                } = O, {
                  value: z,
                  selectionStart: N,
                  selectionEnd: P
                } = $;
                let X = N, it = P;
                switch (O.inputType) {
                  case "deleteWordBackward": {
                    const W = z.substring(0, N).match(/\w*[^\w]*$/);
                    W && (X -= W[0].length);
                    break;
                  }
                  case "deleteWordForward": {
                    const W = z.substring(N).match(/^[^\w]*\w*/);
                    W && (it += W[0].length);
                    break;
                  }
                  case "deleteContentBackward":
                    N === P && (X -= 1);
                    break;
                  case "deleteContentForward":
                    N === P && (it += 1);
                    break;
                }
                O.preventDefault(), this.linkService.eventBus?.dispatch("dispatcheventinsandbox", {
                  source: this,
                  detail: {
                    id: y,
                    name: "Keystroke",
                    value: z,
                    change: H || "",
                    willCommit: !1,
                    selStart: X,
                    selEnd: it
                  }
                });
              }), this._setEventListeners(o, b, [["focus", "Focus"], ["blur", "Blur"], ["mousedown", "Mouse Down"], ["mouseenter", "Mouse Enter"], ["mouseleave", "Mouse Exit"], ["mouseup", "Mouse Up"]], (O) => O.target.value);
            }
            if (R && o.addEventListener("blur", R), this.data.comb) {
              const O = (this.data.rect[2] - this.data.rect[0]) / g;
              o.classList.add("comb"), o.style.letterSpacing = `calc(${O}px * var(--scale-factor) - 1ch)`;
            }
          } else
            o = document.createElement("div"), o.textContent = this.data.fieldValue, o.style.verticalAlign = "middle", o.style.display = "table-cell", this.data.hasOwnCanvas && (o.hidden = !0);
          return this._setTextStyle(o), this._setBackgroundColor(o), this._setDefaultPropertiesFromJS(o), this.container.append(o), this.container;
        }
      }
      class d extends i {
        constructor(D) {
          super(D, {
            isRenderable: !!D.data.hasOwnCanvas
          });
        }
      }
      class E extends i {
        constructor(D) {
          super(D, {
            isRenderable: D.renderForms
          });
        }
        render() {
          const D = this.annotationStorage, y = this.data, o = y.id;
          let u = D.getValue(o, {
            value: y.exportValue === y.fieldValue
          }).value;
          typeof u == "string" && (u = u !== "Off", D.setValue(o, {
            value: u
          })), this.container.classList.add("buttonWidgetAnnotation", "checkBox");
          const m = document.createElement("input");
          return f.add(m), m.setAttribute("data-element-id", o), m.disabled = y.readOnly, this._setRequired(m, this.data.required), m.type = "checkbox", m.name = y.fieldName, u && m.setAttribute("checked", !0), m.setAttribute("exportValue", y.exportValue), m.tabIndex = A, m.addEventListener("change", (g) => {
            const {
              name: c,
              checked: b
            } = g.target;
            for (const R of this._getElementsByName(c, o)) {
              const I = b && R.exportValue === y.exportValue;
              R.domElement && (R.domElement.checked = I), D.setValue(R.id, {
                value: I
              });
            }
            D.setValue(o, {
              value: b
            });
          }), m.addEventListener("resetform", (g) => {
            const c = y.defaultFieldValue || "Off";
            g.target.checked = c === y.exportValue;
          }), this.enableScripting && this.hasJSActions && (m.addEventListener("updatefromsandbox", (g) => {
            const c = {
              value(b) {
                b.target.checked = b.detail.value !== "Off", D.setValue(o, {
                  value: b.target.checked
                });
              }
            };
            this._dispatchEventFromSandbox(c, g);
          }), this._setEventListeners(m, null, [["change", "Validate"], ["change", "Action"], ["focus", "Focus"], ["blur", "Blur"], ["mousedown", "Mouse Down"], ["mouseenter", "Mouse Enter"], ["mouseleave", "Mouse Exit"], ["mouseup", "Mouse Up"]], (g) => g.target.checked)), this._setBackgroundColor(m), this._setDefaultPropertiesFromJS(m), this.container.append(m), this.container;
        }
      }
      class k extends i {
        constructor(D) {
          super(D, {
            isRenderable: D.renderForms
          });
        }
        render() {
          this.container.classList.add("buttonWidgetAnnotation", "radioButton");
          const D = this.annotationStorage, y = this.data, o = y.id;
          let u = D.getValue(o, {
            value: y.fieldValue === y.buttonValue
          }).value;
          if (typeof u == "string" && (u = u !== y.buttonValue, D.setValue(o, {
            value: u
          })), u)
            for (const g of this._getElementsByName(y.fieldName, o))
              D.setValue(g.id, {
                value: !1
              });
          const m = document.createElement("input");
          if (f.add(m), m.setAttribute("data-element-id", o), m.disabled = y.readOnly, this._setRequired(m, this.data.required), m.type = "radio", m.name = y.fieldName, u && m.setAttribute("checked", !0), m.tabIndex = A, m.addEventListener("change", (g) => {
            const {
              name: c,
              checked: b
            } = g.target;
            for (const R of this._getElementsByName(c, o))
              D.setValue(R.id, {
                value: !1
              });
            D.setValue(o, {
              value: b
            });
          }), m.addEventListener("resetform", (g) => {
            const c = y.defaultFieldValue;
            g.target.checked = c != null && c === y.buttonValue;
          }), this.enableScripting && this.hasJSActions) {
            const g = y.buttonValue;
            m.addEventListener("updatefromsandbox", (c) => {
              const b = {
                value: (R) => {
                  const I = g === R.detail.value;
                  for (const O of this._getElementsByName(R.target.name)) {
                    const H = I && O.id === o;
                    O.domElement && (O.domElement.checked = H), D.setValue(O.id, {
                      value: H
                    });
                  }
                }
              };
              this._dispatchEventFromSandbox(b, c);
            }), this._setEventListeners(m, null, [["change", "Validate"], ["change", "Action"], ["focus", "Focus"], ["blur", "Blur"], ["mousedown", "Mouse Down"], ["mouseenter", "Mouse Enter"], ["mouseleave", "Mouse Exit"], ["mouseup", "Mouse Up"]], (c) => c.target.checked);
          }
          return this._setBackgroundColor(m), this._setDefaultPropertiesFromJS(m), this.container.append(m), this.container;
        }
      }
      class L extends w {
        constructor(D) {
          super(D, {
            ignoreBorder: D.data.hasAppearance
          });
        }
        render() {
          const D = super.render();
          D.classList.add("buttonWidgetAnnotation", "pushButton");
          const y = D.lastChild;
          return this.enableScripting && this.hasJSActions && y && (this._setDefaultPropertiesFromJS(y), y.addEventListener("updatefromsandbox", (o) => {
            this._dispatchEventFromSandbox({}, o);
          })), D;
        }
      }
      class M extends i {
        constructor(D) {
          super(D, {
            isRenderable: D.renderForms
          });
        }
        render() {
          this.container.classList.add("choiceWidgetAnnotation");
          const D = this.annotationStorage, y = this.data.id, o = D.getValue(y, {
            value: this.data.fieldValue
          }), u = document.createElement("select");
          f.add(u), u.setAttribute("data-element-id", y), u.disabled = this.data.readOnly, this._setRequired(u, this.data.required), u.name = this.data.fieldName, u.tabIndex = A;
          let m = this.data.combo && this.data.options.length > 0;
          this.data.combo || (u.size = this.data.options.length, this.data.multiSelect && (u.multiple = !0)), u.addEventListener("resetform", (I) => {
            const O = this.data.defaultFieldValue;
            for (const H of u.options)
              H.selected = H.value === O;
          });
          for (const I of this.data.options) {
            const O = document.createElement("option");
            O.textContent = I.displayValue, O.value = I.exportValue, o.value.includes(I.exportValue) && (O.setAttribute("selected", !0), m = !1), u.append(O);
          }
          let g = null;
          if (m) {
            const I = document.createElement("option");
            I.value = " ", I.setAttribute("hidden", !0), I.setAttribute("selected", !0), u.prepend(I), g = () => {
              I.remove(), u.removeEventListener("input", g), g = null;
            }, u.addEventListener("input", g);
          }
          const c = (I) => {
            const O = I ? "value" : "textContent", {
              options: H,
              multiple: $
            } = u;
            return $ ? Array.prototype.filter.call(H, (z) => z.selected).map((z) => z[O]) : H.selectedIndex === -1 ? null : H[H.selectedIndex][O];
          };
          let b = c(!1);
          const R = (I) => {
            const O = I.target.options;
            return Array.prototype.map.call(O, (H) => ({
              displayValue: H.textContent,
              exportValue: H.value
            }));
          };
          return this.enableScripting && this.hasJSActions ? (u.addEventListener("updatefromsandbox", (I) => {
            const O = {
              value(H) {
                g?.();
                const $ = H.detail.value, z = new Set(Array.isArray($) ? $ : [$]);
                for (const N of u.options)
                  N.selected = z.has(N.value);
                D.setValue(y, {
                  value: c(!0)
                }), b = c(!1);
              },
              multipleSelection(H) {
                u.multiple = !0;
              },
              remove(H) {
                const $ = u.options, z = H.detail.remove;
                $[z].selected = !1, u.remove(z), $.length > 0 && Array.prototype.findIndex.call($, (P) => P.selected) === -1 && ($[0].selected = !0), D.setValue(y, {
                  value: c(!0),
                  items: R(H)
                }), b = c(!1);
              },
              clear(H) {
                for (; u.length !== 0; )
                  u.remove(0);
                D.setValue(y, {
                  value: null,
                  items: []
                }), b = c(!1);
              },
              insert(H) {
                const {
                  index: $,
                  displayValue: z,
                  exportValue: N
                } = H.detail.insert, P = u.children[$], X = document.createElement("option");
                X.textContent = z, X.value = N, P ? P.before(X) : u.append(X), D.setValue(y, {
                  value: c(!0),
                  items: R(H)
                }), b = c(!1);
              },
              items(H) {
                const {
                  items: $
                } = H.detail;
                for (; u.length !== 0; )
                  u.remove(0);
                for (const z of $) {
                  const {
                    displayValue: N,
                    exportValue: P
                  } = z, X = document.createElement("option");
                  X.textContent = N, X.value = P, u.append(X);
                }
                u.options.length > 0 && (u.options[0].selected = !0), D.setValue(y, {
                  value: c(!0),
                  items: R(H)
                }), b = c(!1);
              },
              indices(H) {
                const $ = new Set(H.detail.indices);
                for (const z of H.target.options)
                  z.selected = $.has(z.index);
                D.setValue(y, {
                  value: c(!0)
                }), b = c(!1);
              },
              editable(H) {
                H.target.disabled = !H.detail.editable;
              }
            };
            this._dispatchEventFromSandbox(O, I);
          }), u.addEventListener("input", (I) => {
            const O = c(!0), H = c(!1);
            D.setValue(y, {
              value: O
            }), I.preventDefault(), this.linkService.eventBus?.dispatch("dispatcheventinsandbox", {
              source: this,
              detail: {
                id: y,
                name: "Keystroke",
                value: b,
                change: H,
                changeEx: O,
                willCommit: !1,
                commitKey: 1,
                keyDown: !1
              }
            });
          }), this._setEventListeners(u, null, [["focus", "Focus"], ["blur", "Blur"], ["mousedown", "Mouse Down"], ["mouseenter", "Mouse Enter"], ["mouseleave", "Mouse Exit"], ["mouseup", "Mouse Up"], ["input", "Action"], ["input", "Validate"]], (I) => I.target.value)) : u.addEventListener("input", function(I) {
            D.setValue(y, {
              value: c(!0)
            });
          }), this.data.combo && this._setTextStyle(u), this._setBackgroundColor(u), this._setDefaultPropertiesFromJS(u), this.container.append(u), this.container;
        }
      }
      class B extends r {
        constructor(D) {
          const {
            data: y,
            elements: o
          } = D;
          super(D, {
            isRenderable: r._hasPopupData(y)
          }), this.elements = o;
        }
        render() {
          this.container.classList.add("popupAnnotation");
          const D = new U({
            container: this.container,
            color: this.data.color,
            titleObj: this.data.titleObj,
            modificationDate: this.data.modificationDate,
            contentsObj: this.data.contentsObj,
            richText: this.data.richText,
            rect: this.data.rect,
            parentRect: this.data.parentRect || null,
            parent: this.parent,
            elements: this.elements,
            open: this.data.open
          }), y = [];
          for (const o of this.elements)
            o.popup = D, y.push(o.data.id), o.addHighlightArea();
          return this.container.setAttribute("aria-controls", y.map((o) => `${s.AnnotationPrefix}${o}`).join(",")), this.container;
        }
      }
      class U {
        #t = this.#m.bind(this);
        #e = this.#S.bind(this);
        #s = this.#y.bind(this);
        #n = this.#w.bind(this);
        #r = null;
        #i = null;
        #a = null;
        #h = null;
        #l = null;
        #u = null;
        #d = null;
        #c = !1;
        #o = null;
        #p = null;
        #g = null;
        #f = null;
        #b = !1;
        constructor({
          container: D,
          color: y,
          elements: o,
          titleObj: u,
          modificationDate: m,
          contentsObj: g,
          richText: c,
          parent: b,
          rect: R,
          parentRect: I,
          open: O
        }) {
          this.#i = D, this.#f = u, this.#a = g, this.#g = c, this.#u = b, this.#r = y, this.#p = R, this.#d = I, this.#l = o, this.#h = S.PDFDateString.toDateObject(m), this.trigger = o.flatMap((H) => H.getElementsToTriggerPopup());
          for (const H of this.trigger)
            H.addEventListener("click", this.#n), H.addEventListener("mouseenter", this.#s), H.addEventListener("mouseleave", this.#e), H.classList.add("popupTriggerArea");
          for (const H of o)
            H.container?.addEventListener("keydown", this.#t);
          this.#i.hidden = !0, O && this.#w();
        }
        render() {
          if (this.#o)
            return;
          const {
            page: {
              view: D
            },
            viewport: {
              rawDims: {
                pageWidth: y,
                pageHeight: o,
                pageX: u,
                pageY: m
              }
            }
          } = this.#u, g = this.#o = document.createElement("div");
          if (g.className = "popup", this.#r) {
            const W = g.style.outlineColor = s.Util.makeHexColor(...this.#r);
            CSS.supports("background-color", "color-mix(in srgb, red 30%, white)") ? g.style.backgroundColor = `color-mix(in srgb, ${W} 30%, white)` : g.style.backgroundColor = s.Util.makeHexColor(...this.#r.map((ct) => Math.floor(0.7 * (255 - ct) + ct)));
          }
          const c = document.createElement("span");
          c.className = "header";
          const b = document.createElement("h1");
          if (c.append(b), {
            dir: b.dir,
            str: b.textContent
          } = this.#f, g.append(c), this.#h) {
            const W = document.createElement("span");
            W.classList.add("popupDate"), W.setAttribute("data-l10n-id", "pdfjs-annotation-date-string"), W.setAttribute("data-l10n-args", JSON.stringify({
              date: this.#h.toLocaleDateString(),
              time: this.#h.toLocaleTimeString()
            })), c.append(W);
          }
          const R = this.#a, I = this.#g;
          if (I?.str && (!R?.str || R.str === I.str))
            T.XfaLayer.render({
              xfaHtml: I.html,
              intent: "richText",
              div: g
            }), g.lastChild.classList.add("richText", "popupContent");
          else {
            const W = this._formatContents(R);
            g.append(W);
          }
          let O = !!this.#d, H = O ? this.#d : this.#p;
          for (const W of this.#l)
            if (!H || s.Util.intersect(W.data.rect, H) !== null) {
              H = W.data.rect, O = !0;
              break;
            }
          const $ = s.Util.normalizeRect([H[0], D[3] - H[1] + D[1], H[2], D[3] - H[3] + D[1]]), N = O ? H[2] - H[0] + 5 : 0, P = $[0] + N, X = $[1], {
            style: it
          } = this.#i;
          it.left = `${100 * (P - u) / y}%`, it.top = `${100 * (X - m) / o}%`, this.#i.append(g);
        }
        _formatContents({
          str: D,
          dir: y
        }) {
          const o = document.createElement("p");
          o.classList.add("popupContent"), o.dir = y;
          const u = D.split(/(?:\r\n?|\n)/);
          for (let m = 0, g = u.length; m < g; ++m) {
            const c = u[m];
            o.append(document.createTextNode(c)), m < g - 1 && o.append(document.createElement("br"));
          }
          return o;
        }
        #m(D) {
          D.altKey || D.shiftKey || D.ctrlKey || D.metaKey || (D.key === "Enter" || D.key === "Escape" && this.#c) && this.#w();
        }
        #w() {
          this.#c = !this.#c, this.#c ? (this.#y(), this.#i.addEventListener("click", this.#n), this.#i.addEventListener("keydown", this.#t)) : (this.#S(), this.#i.removeEventListener("click", this.#n), this.#i.removeEventListener("keydown", this.#t));
        }
        #y() {
          this.#o || this.render(), this.isVisible ? this.#c && this.#i.classList.add("focused") : (this.#i.hidden = !1, this.#i.style.zIndex = parseInt(this.#i.style.zIndex) + 1e3);
        }
        #S() {
          this.#i.classList.remove("focused"), !(this.#c || !this.isVisible) && (this.#i.hidden = !0, this.#i.style.zIndex = parseInt(this.#i.style.zIndex) - 1e3);
        }
        forceHide() {
          this.#b = this.isVisible, this.#b && (this.#i.hidden = !0);
        }
        maybeShow() {
          this.#b && (this.#b = !1, this.#i.hidden = !1);
        }
        get isVisible() {
          return this.#i.hidden === !1;
        }
      }
      class q extends r {
        constructor(D) {
          super(D, {
            isRenderable: !0,
            ignoreBorder: !0
          }), this.textContent = D.data.textContent, this.textPosition = D.data.textPosition, this.annotationEditorType = s.AnnotationEditorType.FREETEXT;
        }
        render() {
          if (this.container.classList.add("freeTextAnnotation"), this.textContent) {
            const D = document.createElement("div");
            D.classList.add("annotationTextContent"), D.setAttribute("role", "comment");
            for (const y of this.textContent) {
              const o = document.createElement("span");
              o.textContent = y, D.append(o);
            }
            this.container.append(D);
          }
          return !this.data.popupRef && this.hasPopupData && this._createPopup(), this._editOnDoubleClick(), this.container;
        }
        get _isEditable() {
          return this.data.hasOwnCanvas;
        }
      }
      class Z extends r {
        #t = null;
        constructor(D) {
          super(D, {
            isRenderable: !0,
            ignoreBorder: !0
          });
        }
        render() {
          this.container.classList.add("lineAnnotation");
          const D = this.data, {
            width: y,
            height: o
          } = p(D.rect), u = this.svgFactory.create(y, o, !0), m = this.#t = this.svgFactory.createElement("svg:line");
          return m.setAttribute("x1", D.rect[2] - D.lineCoordinates[0]), m.setAttribute("y1", D.rect[3] - D.lineCoordinates[1]), m.setAttribute("x2", D.rect[2] - D.lineCoordinates[2]), m.setAttribute("y2", D.rect[3] - D.lineCoordinates[3]), m.setAttribute("stroke-width", D.borderStyle.width || 1), m.setAttribute("stroke", "transparent"), m.setAttribute("fill", "transparent"), u.append(m), this.container.append(u), !D.popupRef && this.hasPopupData && this._createPopup(), this.container;
        }
        getElementsToTriggerPopup() {
          return this.#t;
        }
        addHighlightArea() {
          this.container.classList.add("highlightArea");
        }
      }
      class K extends r {
        #t = null;
        constructor(D) {
          super(D, {
            isRenderable: !0,
            ignoreBorder: !0
          });
        }
        render() {
          this.container.classList.add("squareAnnotation");
          const D = this.data, {
            width: y,
            height: o
          } = p(D.rect), u = this.svgFactory.create(y, o, !0), m = D.borderStyle.width, g = this.#t = this.svgFactory.createElement("svg:rect");
          return g.setAttribute("x", m / 2), g.setAttribute("y", m / 2), g.setAttribute("width", y - m), g.setAttribute("height", o - m), g.setAttribute("stroke-width", m || 1), g.setAttribute("stroke", "transparent"), g.setAttribute("fill", "transparent"), u.append(g), this.container.append(u), !D.popupRef && this.hasPopupData && this._createPopup(), this.container;
        }
        getElementsToTriggerPopup() {
          return this.#t;
        }
        addHighlightArea() {
          this.container.classList.add("highlightArea");
        }
      }
      class Y extends r {
        #t = null;
        constructor(D) {
          super(D, {
            isRenderable: !0,
            ignoreBorder: !0
          });
        }
        render() {
          this.container.classList.add("circleAnnotation");
          const D = this.data, {
            width: y,
            height: o
          } = p(D.rect), u = this.svgFactory.create(y, o, !0), m = D.borderStyle.width, g = this.#t = this.svgFactory.createElement("svg:ellipse");
          return g.setAttribute("cx", y / 2), g.setAttribute("cy", o / 2), g.setAttribute("rx", y / 2 - m / 2), g.setAttribute("ry", o / 2 - m / 2), g.setAttribute("stroke-width", m || 1), g.setAttribute("stroke", "transparent"), g.setAttribute("fill", "transparent"), u.append(g), this.container.append(u), !D.popupRef && this.hasPopupData && this._createPopup(), this.container;
        }
        getElementsToTriggerPopup() {
          return this.#t;
        }
        addHighlightArea() {
          this.container.classList.add("highlightArea");
        }
      }
      class G extends r {
        #t = null;
        constructor(D) {
          super(D, {
            isRenderable: !0,
            ignoreBorder: !0
          }), this.containerClassName = "polylineAnnotation", this.svgElementName = "svg:polyline";
        }
        render() {
          this.container.classList.add(this.containerClassName);
          const D = this.data, {
            width: y,
            height: o
          } = p(D.rect), u = this.svgFactory.create(y, o, !0);
          let m = [];
          for (const c of D.vertices) {
            const b = c.x - D.rect[0], R = D.rect[3] - c.y;
            m.push(b + "," + R);
          }
          m = m.join(" ");
          const g = this.#t = this.svgFactory.createElement(this.svgElementName);
          return g.setAttribute("points", m), g.setAttribute("stroke-width", D.borderStyle.width || 1), g.setAttribute("stroke", "transparent"), g.setAttribute("fill", "transparent"), u.append(g), this.container.append(u), !D.popupRef && this.hasPopupData && this._createPopup(), this.container;
        }
        getElementsToTriggerPopup() {
          return this.#t;
        }
        addHighlightArea() {
          this.container.classList.add("highlightArea");
        }
      }
      class j extends G {
        constructor(D) {
          super(D), this.containerClassName = "polygonAnnotation", this.svgElementName = "svg:polygon";
        }
      }
      class Q extends r {
        constructor(D) {
          super(D, {
            isRenderable: !0,
            ignoreBorder: !0
          });
        }
        render() {
          return this.container.classList.add("caretAnnotation"), !this.data.popupRef && this.hasPopupData && this._createPopup(), this.container;
        }
      }
      class J extends r {
        #t = [];
        constructor(D) {
          super(D, {
            isRenderable: !0,
            ignoreBorder: !0
          }), this.containerClassName = "inkAnnotation", this.svgElementName = "svg:polyline", this.annotationEditorType = s.AnnotationEditorType.INK;
        }
        render() {
          this.container.classList.add(this.containerClassName);
          const D = this.data, {
            width: y,
            height: o
          } = p(D.rect), u = this.svgFactory.create(y, o, !0);
          for (const m of D.inkLists) {
            let g = [];
            for (const b of m) {
              const R = b.x - D.rect[0], I = D.rect[3] - b.y;
              g.push(`${R},${I}`);
            }
            g = g.join(" ");
            const c = this.svgFactory.createElement(this.svgElementName);
            this.#t.push(c), c.setAttribute("points", g), c.setAttribute("stroke-width", D.borderStyle.width || 1), c.setAttribute("stroke", "transparent"), c.setAttribute("fill", "transparent"), !D.popupRef && this.hasPopupData && this._createPopup(), u.append(c);
          }
          return this.container.append(u), this.container;
        }
        getElementsToTriggerPopup() {
          return this.#t;
        }
        addHighlightArea() {
          this.container.classList.add("highlightArea");
        }
      }
      class tt extends r {
        constructor(D) {
          super(D, {
            isRenderable: !0,
            ignoreBorder: !0,
            createQuadrilaterals: !0
          });
        }
        render() {
          return !this.data.popupRef && this.hasPopupData && this._createPopup(), this.container.classList.add("highlightAnnotation"), this.container;
        }
      }
      class rt extends r {
        constructor(D) {
          super(D, {
            isRenderable: !0,
            ignoreBorder: !0,
            createQuadrilaterals: !0
          });
        }
        render() {
          return !this.data.popupRef && this.hasPopupData && this._createPopup(), this.container.classList.add("underlineAnnotation"), this.container;
        }
      }
      class ut extends r {
        constructor(D) {
          super(D, {
            isRenderable: !0,
            ignoreBorder: !0,
            createQuadrilaterals: !0
          });
        }
        render() {
          return !this.data.popupRef && this.hasPopupData && this._createPopup(), this.container.classList.add("squigglyAnnotation"), this.container;
        }
      }
      class dt extends r {
        constructor(D) {
          super(D, {
            isRenderable: !0,
            ignoreBorder: !0,
            createQuadrilaterals: !0
          });
        }
        render() {
          return !this.data.popupRef && this.hasPopupData && this._createPopup(), this.container.classList.add("strikeoutAnnotation"), this.container;
        }
      }
      class ft extends r {
        constructor(D) {
          super(D, {
            isRenderable: !0,
            ignoreBorder: !0
          });
        }
        render() {
          return this.container.classList.add("stampAnnotation"), !this.data.popupRef && this.hasPopupData && this._createPopup(), this.container;
        }
      }
      class lt extends r {
        #t = null;
        constructor(D) {
          super(D, {
            isRenderable: !0
          });
          const {
            filename: y,
            content: o
          } = this.data.file;
          this.filename = (0, S.getFilenameFromUrl)(y, !0), this.content = o, this.linkService.eventBus?.dispatch("fileattachmentannotation", {
            source: this,
            filename: y,
            content: o
          });
        }
        render() {
          this.container.classList.add("fileAttachmentAnnotation");
          const {
            container: D,
            data: y
          } = this;
          let o;
          y.hasAppearance || y.fillAlpha === 0 ? o = document.createElement("div") : (o = document.createElement("img"), o.src = `${this.imageResourcesPath}annotation-${/paperclip/i.test(y.name) ? "paperclip" : "pushpin"}.svg`, y.fillAlpha && y.fillAlpha < 1 && (o.style = `filter: opacity(${Math.round(y.fillAlpha * 100)}%);`)), o.addEventListener("dblclick", this.#e.bind(this)), this.#t = o;
          const {
            isMac: u
          } = s.FeatureTest.platform;
          return D.addEventListener("keydown", (m) => {
            m.key === "Enter" && (u ? m.metaKey : m.ctrlKey) && this.#e();
          }), !y.popupRef && this.hasPopupData ? this._createPopup() : o.classList.add("popupTriggerArea"), D.append(o), D;
        }
        getElementsToTriggerPopup() {
          return this.#t;
        }
        addHighlightArea() {
          this.container.classList.add("highlightArea");
        }
        #e() {
          this.downloadManager?.openOrDownloadData(this.content, this.filename);
        }
      }
      class ot {
        #t = null;
        #e = null;
        #s = /* @__PURE__ */ new Map();
        constructor({
          div: D,
          accessibilityManager: y,
          annotationCanvasMap: o,
          annotationEditorUIManager: u,
          page: m,
          viewport: g
        }) {
          this.div = D, this.#t = y, this.#e = o, this.page = m, this.viewport = g, this.zIndex = 0, this._annotationEditorUIManager = u;
        }
        #n(D, y) {
          const o = D.firstChild || D;
          o.id = `${s.AnnotationPrefix}${y}`, this.div.append(D), this.#t?.moveElementInDOM(this.div, D, o, !1);
        }
        async render(D) {
          const {
            annotations: y
          } = D, o = this.div;
          (0, S.setLayerDimensions)(o, this.viewport);
          const u = /* @__PURE__ */ new Map(), m = {
            data: null,
            layer: o,
            linkService: D.linkService,
            downloadManager: D.downloadManager,
            imageResourcesPath: D.imageResourcesPath || "",
            renderForms: D.renderForms !== !1,
            svgFactory: new S.DOMSVGFactory(),
            annotationStorage: D.annotationStorage || new v.AnnotationStorage(),
            enableScripting: D.enableScripting === !0,
            hasJSActions: D.hasJSActions,
            fieldObjects: D.fieldObjects,
            parent: this,
            elements: null
          };
          for (const g of y) {
            if (g.noHTML)
              continue;
            const c = g.annotationType === s.AnnotationType.POPUP;
            if (c) {
              const I = u.get(g.id);
              if (!I)
                continue;
              m.elements = I;
            } else {
              const {
                width: I,
                height: O
              } = p(g.rect);
              if (I <= 0 || O <= 0)
                continue;
            }
            m.data = g;
            const b = F.create(m);
            if (!b.isRenderable)
              continue;
            if (!c && g.popupRef) {
              const I = u.get(g.popupRef);
              I ? I.push(b) : u.set(g.popupRef, [b]);
            }
            const R = b.render();
            g.hidden && (R.style.visibility = "hidden"), this.#n(R, g.id), b.annotationEditorType > 0 && (this.#s.set(b.data.id, b), this._annotationEditorUIManager?.renderAnnotationElement(b));
          }
          this.#r();
        }
        update({
          viewport: D
        }) {
          const y = this.div;
          this.viewport = D, (0, S.setLayerDimensions)(y, {
            rotation: D.rotation
          }), this.#r(), y.hidden = !1;
        }
        #r() {
          if (!this.#e)
            return;
          const D = this.div;
          for (const [y, o] of this.#e) {
            const u = D.querySelector(`[data-annotation-id="${y}"]`);
            if (!u)
              continue;
            o.className = "annotationContent";
            const {
              firstChild: m
            } = u;
            m ? m.nodeName === "CANVAS" ? m.replaceWith(o) : m.classList.contains("annotationContent") ? m.after(o) : m.before(o) : u.append(o);
          }
          this.#e.clear();
        }
        getEditableAnnotations() {
          return Array.from(this.#s.values());
        }
        getEditableAnnotation(D) {
          return this.#s.get(D);
        }
      }
    })
  ),
  /***/
  792: (
    /***/
    ((V, l, a) => {
      a.d(l, {
        /* harmony export */
        AnnotationStorage: () => (
          /* binding */
          x
        ),
        /* harmony export */
        PrintAnnotationStorage: () => (
          /* binding */
          C
        ),
        /* harmony export */
        SerializableEmpty: () => (
          /* binding */
          _
        )
        /* harmony export */
      });
      var s = a(292), S = a(310), v = a(651);
      const _ = Object.freeze({
        map: null,
        hash: "",
        transfer: void 0
      });
      class x {
        #t = !1;
        #e = /* @__PURE__ */ new Map();
        constructor() {
          this.onSetModified = null, this.onResetModified = null, this.onAnnotationEditor = null;
        }
        getValue(A, n) {
          const f = this.#e.get(A);
          return f === void 0 ? n : Object.assign(n, f);
        }
        getRawValue(A) {
          return this.#e.get(A);
        }
        remove(A) {
          if (this.#e.delete(A), this.#e.size === 0 && this.resetModified(), typeof this.onAnnotationEditor == "function") {
            for (const n of this.#e.values())
              if (n instanceof S.AnnotationEditor)
                return;
            this.onAnnotationEditor(null);
          }
        }
        setValue(A, n) {
          const f = this.#e.get(A);
          let p = !1;
          if (f !== void 0)
            for (const [F, r] of Object.entries(n))
              f[F] !== r && (p = !0, f[F] = r);
          else
            p = !0, this.#e.set(A, n);
          p && this.#s(), n instanceof S.AnnotationEditor && typeof this.onAnnotationEditor == "function" && this.onAnnotationEditor(n.constructor._type);
        }
        has(A) {
          return this.#e.has(A);
        }
        getAll() {
          return this.#e.size > 0 ? (0, s.objectFromMap)(this.#e) : null;
        }
        setAll(A) {
          for (const [n, f] of Object.entries(A))
            this.setValue(n, f);
        }
        get size() {
          return this.#e.size;
        }
        #s() {
          this.#t || (this.#t = !0, typeof this.onSetModified == "function" && this.onSetModified());
        }
        resetModified() {
          this.#t && (this.#t = !1, typeof this.onResetModified == "function" && this.onResetModified());
        }
        get print() {
          return new C(this);
        }
        get serializable() {
          if (this.#e.size === 0)
            return _;
          const A = /* @__PURE__ */ new Map(), n = new v.MurmurHash3_64(), f = [], p = /* @__PURE__ */ Object.create(null);
          let F = !1;
          for (const [r, w] of this.#e) {
            const t = w instanceof S.AnnotationEditor ? w.serialize(!1, p) : w;
            t && (A.set(r, t), n.update(`${r}:${JSON.stringify(t)}`), F ||= !!t.bitmap);
          }
          if (F)
            for (const r of A.values())
              r.bitmap && f.push(r.bitmap);
          return A.size > 0 ? {
            map: A,
            hash: n.hexdigest(),
            transfer: f
          } : _;
        }
        get editorStats() {
          let A = null;
          const n = /* @__PURE__ */ new Map();
          for (const f of this.#e.values()) {
            if (!(f instanceof S.AnnotationEditor))
              continue;
            const p = f.telemetryFinalData;
            if (!p)
              continue;
            const {
              type: F
            } = p;
            n.has(F) || n.set(F, Object.getPrototypeOf(f).constructor), A ||= /* @__PURE__ */ Object.create(null);
            const r = A[F] ||= /* @__PURE__ */ new Map();
            for (const [w, t] of Object.entries(p)) {
              if (w === "type")
                continue;
              let i = r.get(w);
              i || (i = /* @__PURE__ */ new Map(), r.set(w, i));
              const h = i.get(t) ?? 0;
              i.set(t, h + 1);
            }
          }
          for (const [f, p] of n)
            A[f] = p.computeTelemetryFinalData(A[f]);
          return A;
        }
      }
      class C extends x {
        #t;
        constructor(A) {
          super();
          const {
            map: n,
            hash: f,
            transfer: p
          } = A.serializable, F = structuredClone(n, p ? {
            transfer: p
          } : null);
          this.#t = {
            map: F,
            hash: f,
            transfer: p
          };
        }
        get print() {
          (0, s.unreachable)("Should not call PrintAnnotationStorage.print");
        }
        get serializable() {
          return this.#t;
        }
      }
    })
  ),
  /***/
  831: (
    /***/
    ((V, l, a) => {
      a.a(V, async (s, S) => {
        try {
          let K = function(g) {
            if (typeof g == "string" || g instanceof URL ? g = {
              url: g
            } : (g instanceof ArrayBuffer || ArrayBuffer.isView(g)) && (g = {
              data: g
            }), typeof g != "object")
              throw new Error("Invalid parameter in getDocument, need parameter object.");
            if (!g.url && !g.data && !g.range)
              throw new Error("Invalid parameter object: need either .data, .range or .url");
            const c = new J(), {
              docId: b
            } = c, R = g.url ? G(g.url) : null, I = g.data ? j(g.data) : null, O = g.httpHeaders || null, H = g.withCredentials === !0, $ = g.password ?? null, z = g.range instanceof tt ? g.range : null, N = Number.isInteger(g.rangeChunkSize) && g.rangeChunkSize > 0 ? g.rangeChunkSize : k;
            let P = g.worker instanceof lt ? g.worker : null;
            const X = g.verbosity, it = typeof g.docBaseUrl == "string" && !(0, x.isDataScheme)(g.docBaseUrl) ? g.docBaseUrl : null, W = typeof g.cMapUrl == "string" ? g.cMapUrl : null, st = g.cMapPacked !== !1, ct = g.CMapReaderFactory || U, at = typeof g.standardFontDataUrl == "string" ? g.standardFontDataUrl : null, nt = g.StandardFontDataFactory || Z, ht = g.stopAtErrors !== !0, pt = Number.isInteger(g.maxImageSize) && g.maxImageSize > -1 ? g.maxImageSize : -1, vt = g.isEvalSupported !== !1, bt = typeof g.isOffscreenCanvasSupported == "boolean" ? g.isOffscreenCanvasSupported : !v.isNodeJS, wt = Number.isInteger(g.canvasMaxAreaInBytes) ? g.canvasMaxAreaInBytes : -1, mt = typeof g.disableFontFace == "boolean" ? g.disableFontFace : v.isNodeJS, St = g.fontExtraProperties === !0, Et = g.enableXfa === !0, Ft = g.ownerDocument || globalThis.document, xt = g.disableRange === !0, Tt = g.disableStream === !0, It = g.disableAutoFetch === !0, Nt = g.pdfBug === !0, zt = z ? z.length : g.length ?? NaN, Ut = typeof g.useSystemFonts == "boolean" ? g.useSystemFonts : !v.isNodeJS && !mt, Ot = typeof g.useWorkerFetch == "boolean" ? g.useWorkerFetch : ct === x.DOMCMapReaderFactory && nt === x.DOMStandardFontDataFactory && W && at && (0, x.isValidFetchUrl)(W, document.baseURI) && (0, x.isValidFetchUrl)(at, document.baseURI), _t = g.canvasFactory || new B({
              ownerDocument: Ft
            }), Ct = g.filterFactory || new q({
              docId: b,
              ownerDocument: Ft
            }), kt = null;
            (0, v.setVerbosityLevel)(X);
            const Rt = {
              canvasFactory: _t,
              filterFactory: Ct
            };
            if (Ot || (Rt.cMapReaderFactory = new ct({
              baseUrl: W,
              isCompressed: st
            }), Rt.standardFontDataFactory = new nt({
              baseUrl: at
            })), !P) {
              const jt = {
                verbosity: X,
                port: f.GlobalWorkerOptions.workerPort
              };
              P = jt.port ? lt.fromPort(jt) : new lt(jt), c._worker = P;
            }
            const Bt = {
              docId: b,
              apiVersion: "4.2.67",
              data: I,
              password: $,
              disableAutoFetch: It,
              rangeChunkSize: N,
              length: zt,
              docBaseUrl: it,
              enableXfa: Et,
              evaluatorOptions: {
                maxImageSize: pt,
                disableFontFace: mt,
                ignoreErrors: ht,
                isEvalSupported: vt,
                isOffscreenCanvasSupported: bt,
                canvasMaxAreaInBytes: wt,
                fontExtraProperties: St,
                useSystemFonts: Ut,
                cMapUrl: Ot ? W : null,
                standardFontDataUrl: Ot ? at : null
              }
            }, Dt = {
              ignoreErrors: ht,
              disableFontFace: mt,
              fontExtraProperties: St,
              enableXfa: Et,
              ownerDocument: Ft,
              disableAutoFetch: It,
              pdfBug: Nt,
              styleElement: kt
            };
            return P.promise.then(function() {
              if (c.destroyed)
                throw new Error("Loading aborted");
              const jt = Y(P, Bt), rs = new Promise(function(le) {
                let Xt;
                z ? Xt = new w.PDFDataTransportStream(z, {
                  disableRange: xt,
                  disableStream: Tt
                }) : I || (Xt = ((Ht) => v.isNodeJS ? function() {
                  return typeof fetch < "u" && typeof Response < "u" && "body" in Response.prototype;
                }() && (0, x.isValidFetchUrl)(Ht.url) ? new t.PDFFetchStream(Ht) : new h.PDFNodeStream(Ht) : (0, x.isValidFetchUrl)(Ht.url) ? new t.PDFFetchStream(Ht) : new i.PDFNetworkStream(Ht))({
                  url: R,
                  length: zt,
                  httpHeaders: O,
                  withCredentials: H,
                  rangeChunkSize: N,
                  disableRange: xt,
                  disableStream: Tt
                })), le(Xt);
              });
              return Promise.all([jt, rs]).then(function([le, Xt]) {
                if (c.destroyed)
                  throw new Error("Loading aborted");
                const he = new p.MessageHandler(b, le, P.port), Ht = new ot(he, c, Xt, Dt, Rt);
                c._transport = Ht, he.send("Ready", null);
              });
            }).catch(c._capability.reject), c;
          }, G = function(g) {
            if (g instanceof URL)
              return g.href;
            try {
              return new URL(g, window.location).href;
            } catch {
              if (v.isNodeJS && typeof g == "string")
                return g;
            }
            throw new Error("Invalid PDF url data: either string or URL-object is expected in the url property.");
          }, j = function(g) {
            if (v.isNodeJS && typeof Buffer < "u" && g instanceof Buffer)
              throw new Error("Please provide binary data as `Uint8Array`, rather than `Buffer`.");
            if (g instanceof Uint8Array && g.byteLength === g.buffer.byteLength)
              return g;
            if (typeof g == "string")
              return (0, v.stringToBytes)(g);
            if (g instanceof ArrayBuffer || ArrayBuffer.isView(g) || typeof g == "object" && !isNaN(g?.length))
              return new Uint8Array(g);
            throw new Error("Invalid PDF binary data: either TypedArray, string, or array-like object is expected in the data property.");
          }, Q = function(g) {
            return typeof g == "object" && Number.isInteger(g?.num) && g.num >= 0 && Number.isInteger(g?.gen) && g.gen >= 0;
          };
          a.d(l, {
            /* harmony export */
            PDFDataRangeTransport: () => (
              /* binding */
              tt
            ),
            /* harmony export */
            PDFWorker: () => (
              /* binding */
              lt
            ),
            /* harmony export */
            build: () => (
              /* binding */
              m
            ),
            /* harmony export */
            getDocument: () => (
              /* binding */
              K
            ),
            /* harmony export */
            version: () => (
              /* binding */
              u
            )
            /* harmony export */
          });
          var v = a(292), _ = a(792), x = a(419), C = a(10), T = a(573), A = a(923), n = a(814), f = a(164), p = a(178), F = a(62), r = a(626), w = a(585), t = a(94), i = a(457), h = a(786), d = a(50), E = s([T, h]);
          [T, h] = E.then ? (await E)() : E;
          const k = 65536, L = 100, M = 5e3, B = v.isNodeJS ? T.NodeCanvasFactory : x.DOMCanvasFactory, U = v.isNodeJS ? T.NodeCMapReaderFactory : x.DOMCMapReaderFactory, q = v.isNodeJS ? T.NodeFilterFactory : x.DOMFilterFactory, Z = v.isNodeJS ? T.NodeStandardFontDataFactory : x.DOMStandardFontDataFactory;
          async function Y(g, c) {
            if (g.destroyed)
              throw new Error("Worker was destroyed");
            const b = await g.messageHandler.sendWithPromise("GetDocRequest", c, c.data ? [c.data.buffer] : null);
            if (g.destroyed)
              throw new Error("Worker was destroyed");
            return b;
          }
          class J {
            static #t = 0;
            constructor() {
              this._capability = Promise.withResolvers(), this._transport = null, this._worker = null, this.docId = `d${J.#t++}`, this.destroyed = !1, this.onPassword = null, this.onProgress = null;
            }
            get promise() {
              return this._capability.promise;
            }
            async destroy() {
              this.destroyed = !0;
              try {
                this._worker?.port && (this._worker._pendingDestroy = !0), await this._transport?.destroy();
              } catch (c) {
                throw this._worker?.port && delete this._worker._pendingDestroy, c;
              }
              this._transport = null, this._worker && (this._worker.destroy(), this._worker = null);
            }
          }
          class tt {
            constructor(c, b, R = !1, I = null) {
              this.length = c, this.initialData = b, this.progressiveDone = R, this.contentDispositionFilename = I, this._rangeListeners = [], this._progressListeners = [], this._progressiveReadListeners = [], this._progressiveDoneListeners = [], this._readyCapability = Promise.withResolvers();
            }
            addRangeListener(c) {
              this._rangeListeners.push(c);
            }
            addProgressListener(c) {
              this._progressListeners.push(c);
            }
            addProgressiveReadListener(c) {
              this._progressiveReadListeners.push(c);
            }
            addProgressiveDoneListener(c) {
              this._progressiveDoneListeners.push(c);
            }
            onDataRange(c, b) {
              for (const R of this._rangeListeners)
                R(c, b);
            }
            onDataProgress(c, b) {
              this._readyCapability.promise.then(() => {
                for (const R of this._progressListeners)
                  R(c, b);
              });
            }
            onDataProgressiveRead(c) {
              this._readyCapability.promise.then(() => {
                for (const b of this._progressiveReadListeners)
                  b(c);
              });
            }
            onDataProgressiveDone() {
              this._readyCapability.promise.then(() => {
                for (const c of this._progressiveDoneListeners)
                  c();
              });
            }
            transportReady() {
              this._readyCapability.resolve();
            }
            requestDataRange(c, b) {
              (0, v.unreachable)("Abstract method PDFDataRangeTransport.requestDataRange");
            }
            abort() {
            }
          }
          class rt {
            constructor(c, b) {
              this._pdfInfo = c, this._transport = b;
            }
            get annotationStorage() {
              return this._transport.annotationStorage;
            }
            get filterFactory() {
              return this._transport.filterFactory;
            }
            get numPages() {
              return this._pdfInfo.numPages;
            }
            get fingerprints() {
              return this._pdfInfo.fingerprints;
            }
            get isPureXfa() {
              return (0, v.shadow)(this, "isPureXfa", !!this._transport._htmlForXfa);
            }
            get allXfaHtml() {
              return this._transport._htmlForXfa;
            }
            getPage(c) {
              return this._transport.getPage(c);
            }
            getPageIndex(c) {
              return this._transport.getPageIndex(c);
            }
            getDestinations() {
              return this._transport.getDestinations();
            }
            getDestination(c) {
              return this._transport.getDestination(c);
            }
            getPageLabels() {
              return this._transport.getPageLabels();
            }
            getPageLayout() {
              return this._transport.getPageLayout();
            }
            getPageMode() {
              return this._transport.getPageMode();
            }
            getViewerPreferences() {
              return this._transport.getViewerPreferences();
            }
            getOpenAction() {
              return this._transport.getOpenAction();
            }
            getAttachments() {
              return this._transport.getAttachments();
            }
            getJSActions() {
              return this._transport.getDocJSActions();
            }
            getOutline() {
              return this._transport.getOutline();
            }
            getOptionalContentConfig({
              intent: c = "display"
            } = {}) {
              const {
                renderingIntent: b
              } = this._transport.getRenderingIntent(c);
              return this._transport.getOptionalContentConfig(b);
            }
            getPermissions() {
              return this._transport.getPermissions();
            }
            getMetadata() {
              return this._transport.getMetadata();
            }
            getMarkInfo() {
              return this._transport.getMarkInfo();
            }
            getData() {
              return this._transport.getData();
            }
            saveDocument() {
              return this._transport.saveDocument();
            }
            getDownloadInfo() {
              return this._transport.downloadInfoCapability.promise;
            }
            cleanup(c = !1) {
              return this._transport.startCleanup(c || this.isPureXfa);
            }
            destroy() {
              return this.loadingTask.destroy();
            }
            cachedPageNumber(c) {
              return this._transport.cachedPageNumber(c);
            }
            get loadingParams() {
              return this._transport.loadingParams;
            }
            get loadingTask() {
              return this._transport.loadingTask;
            }
            getFieldObjects() {
              return this._transport.getFieldObjects();
            }
            hasJSActions() {
              return this._transport.hasJSActions();
            }
            getCalculationOrderIds() {
              return this._transport.getCalculationOrderIds();
            }
          }
          class ut {
            #t = null;
            #e = !1;
            constructor(c, b, R, I = !1) {
              this._pageIndex = c, this._pageInfo = b, this._transport = R, this._stats = I ? new x.StatTimer() : null, this._pdfBug = I, this.commonObjs = R.commonObjs, this.objs = new D(), this._maybeCleanupAfterRender = !1, this._intentStates = /* @__PURE__ */ new Map(), this.destroyed = !1;
            }
            get pageNumber() {
              return this._pageIndex + 1;
            }
            get rotate() {
              return this._pageInfo.rotate;
            }
            get ref() {
              return this._pageInfo.ref;
            }
            get userUnit() {
              return this._pageInfo.userUnit;
            }
            get view() {
              return this._pageInfo.view;
            }
            getViewport({
              scale: c,
              rotation: b = this.rotate,
              offsetX: R = 0,
              offsetY: I = 0,
              dontFlip: O = !1
            } = {}) {
              return new x.PageViewport({
                viewBox: this.view,
                scale: c,
                rotation: b,
                offsetX: R,
                offsetY: I,
                dontFlip: O
              });
            }
            getAnnotations({
              intent: c = "display"
            } = {}) {
              const {
                renderingIntent: b
              } = this._transport.getRenderingIntent(c);
              return this._transport.getAnnotations(this._pageIndex, b);
            }
            getJSActions() {
              return this._transport.getPageJSActions(this._pageIndex);
            }
            get filterFactory() {
              return this._transport.filterFactory;
            }
            get isPureXfa() {
              return (0, v.shadow)(this, "isPureXfa", !!this._transport._htmlForXfa);
            }
            async getXfa() {
              return this._transport._htmlForXfa?.children[this._pageIndex] || null;
            }
            render({
              canvasContext: c,
              viewport: b,
              intent: R = "display",
              annotationMode: I = v.AnnotationMode.ENABLE,
              transform: O = null,
              background: H = null,
              optionalContentConfigPromise: $ = null,
              annotationCanvasMap: z = null,
              pageColors: N = null,
              printAnnotationStorage: P = null
            }) {
              this._stats?.time("Overall");
              const X = this._transport.getRenderingIntent(R, I, P), {
                renderingIntent: it,
                cacheKey: W
              } = X;
              this.#e = !1, this.#n(), $ ||= this._transport.getOptionalContentConfig(it);
              let st = this._intentStates.get(W);
              st || (st = /* @__PURE__ */ Object.create(null), this._intentStates.set(W, st)), st.streamReaderCancelTimeout && (clearTimeout(st.streamReaderCancelTimeout), st.streamReaderCancelTimeout = null);
              const ct = !!(it & v.RenderingIntentFlag.PRINT);
              st.displayReadyCapability || (st.displayReadyCapability = Promise.withResolvers(), st.operatorList = {
                fnArray: [],
                argsArray: [],
                lastChunk: !1,
                separateAnnots: null
              }, this._stats?.time("Page Request"), this._pumpOperatorList(X));
              const at = (pt) => {
                st.renderTasks.delete(nt), (this._maybeCleanupAfterRender || ct) && (this.#e = !0), this.#s(!ct), pt ? (nt.capability.reject(pt), this._abortOperatorList({
                  intentState: st,
                  reason: pt instanceof Error ? pt : new Error(pt)
                })) : nt.capability.resolve(), this._stats?.timeEnd("Rendering"), this._stats?.timeEnd("Overall");
              }, nt = new o({
                callback: at,
                params: {
                  canvasContext: c,
                  viewport: b,
                  transform: O,
                  background: H
                },
                objs: this.objs,
                commonObjs: this.commonObjs,
                annotationCanvasMap: z,
                operatorList: st.operatorList,
                pageIndex: this._pageIndex,
                canvasFactory: this._transport.canvasFactory,
                filterFactory: this._transport.filterFactory,
                useRequestAnimationFrame: !ct,
                pdfBug: this._pdfBug,
                pageColors: N
              });
              (st.renderTasks ||= /* @__PURE__ */ new Set()).add(nt);
              const ht = nt.task;
              return Promise.all([st.displayReadyCapability.promise, $]).then(([pt, vt]) => {
                if (this.destroyed) {
                  at();
                  return;
                }
                if (this._stats?.time("Rendering"), !(vt.renderingIntent & it))
                  throw new Error("Must use the same `intent`-argument when calling the `PDFPageProxy.render` and `PDFDocumentProxy.getOptionalContentConfig` methods.");
                nt.initializeGraphics({
                  transparency: pt,
                  optionalContentConfig: vt
                }), nt.operatorListChanged();
              }).catch(at), ht;
            }
            getOperatorList({
              intent: c = "display",
              annotationMode: b = v.AnnotationMode.ENABLE,
              printAnnotationStorage: R = null
            } = {}) {
              function I() {
                H.operatorList.lastChunk && (H.opListReadCapability.resolve(H.operatorList), H.renderTasks.delete($));
              }
              const O = this._transport.getRenderingIntent(c, b, R, !0);
              let H = this._intentStates.get(O.cacheKey);
              H || (H = /* @__PURE__ */ Object.create(null), this._intentStates.set(O.cacheKey, H));
              let $;
              return H.opListReadCapability || ($ = /* @__PURE__ */ Object.create(null), $.operatorListChanged = I, H.opListReadCapability = Promise.withResolvers(), (H.renderTasks ||= /* @__PURE__ */ new Set()).add($), H.operatorList = {
                fnArray: [],
                argsArray: [],
                lastChunk: !1,
                separateAnnots: null
              }, this._stats?.time("Page Request"), this._pumpOperatorList(O)), H.opListReadCapability.promise;
            }
            streamTextContent({
              includeMarkedContent: c = !1,
              disableNormalization: b = !1
            } = {}) {
              return this._transport.messageHandler.sendWithStream("GetTextContent", {
                pageIndex: this._pageIndex,
                includeMarkedContent: c === !0,
                disableNormalization: b === !0
              }, {
                highWaterMark: 100,
                size(I) {
                  return I.items.length;
                }
              });
            }
            getTextContent(c = {}) {
              if (this._transport._htmlForXfa)
                return this.getXfa().then((R) => d.XfaText.textContent(R));
              const b = this.streamTextContent(c);
              return new Promise(function(R, I) {
                function O() {
                  H.read().then(function({
                    value: z,
                    done: N
                  }) {
                    if (N) {
                      R($);
                      return;
                    }
                    Object.assign($.styles, z.styles), $.items.push(...z.items), O();
                  }, I);
                }
                const H = b.getReader(), $ = {
                  items: [],
                  styles: /* @__PURE__ */ Object.create(null)
                };
                O();
              });
            }
            getStructTree() {
              return this._transport.getStructTree(this._pageIndex);
            }
            _destroy() {
              this.destroyed = !0;
              const c = [];
              for (const b of this._intentStates.values())
                if (this._abortOperatorList({
                  intentState: b,
                  reason: new Error("Page was destroyed."),
                  force: !0
                }), !b.opListReadCapability)
                  for (const R of b.renderTasks)
                    c.push(R.completed), R.cancel();
              return this.objs.clear(), this.#e = !1, this.#n(), Promise.all(c);
            }
            cleanup(c = !1) {
              this.#e = !0;
              const b = this.#s(!1);
              return c && b && (this._stats &&= new x.StatTimer()), b;
            }
            #s(c = !1) {
              if (this.#n(), !this.#e || this.destroyed)
                return !1;
              if (c)
                return this.#t = setTimeout(() => {
                  this.#t = null, this.#s(!1);
                }, M), !1;
              for (const {
                renderTasks: b,
                operatorList: R
              } of this._intentStates.values())
                if (b.size > 0 || !R.lastChunk)
                  return !1;
              return this._intentStates.clear(), this.objs.clear(), this.#e = !1, !0;
            }
            #n() {
              this.#t && (clearTimeout(this.#t), this.#t = null);
            }
            _startRenderPage(c, b) {
              const R = this._intentStates.get(b);
              R && (this._stats?.timeEnd("Page Request"), R.displayReadyCapability?.resolve(c));
            }
            _renderPageChunk(c, b) {
              for (let R = 0, I = c.length; R < I; R++)
                b.operatorList.fnArray.push(c.fnArray[R]), b.operatorList.argsArray.push(c.argsArray[R]);
              b.operatorList.lastChunk = c.lastChunk, b.operatorList.separateAnnots = c.separateAnnots;
              for (const R of b.renderTasks)
                R.operatorListChanged();
              c.lastChunk && this.#s(!0);
            }
            _pumpOperatorList({
              renderingIntent: c,
              cacheKey: b,
              annotationStorageSerializable: R
            }) {
              const {
                map: I,
                transfer: O
              } = R, $ = this._transport.messageHandler.sendWithStream("GetOperatorList", {
                pageIndex: this._pageIndex,
                intent: c,
                cacheKey: b,
                annotationStorage: I
              }, O).getReader(), z = this._intentStates.get(b);
              z.streamReader = $;
              const N = () => {
                $.read().then(({
                  value: P,
                  done: X
                }) => {
                  if (X) {
                    z.streamReader = null;
                    return;
                  }
                  this._transport.destroyed || (this._renderPageChunk(P, z), N());
                }, (P) => {
                  if (z.streamReader = null, !this._transport.destroyed) {
                    if (z.operatorList) {
                      z.operatorList.lastChunk = !0;
                      for (const X of z.renderTasks)
                        X.operatorListChanged();
                      this.#s(!0);
                    }
                    if (z.displayReadyCapability)
                      z.displayReadyCapability.reject(P);
                    else if (z.opListReadCapability)
                      z.opListReadCapability.reject(P);
                    else
                      throw P;
                  }
                });
              };
              N();
            }
            _abortOperatorList({
              intentState: c,
              reason: b,
              force: R = !1
            }) {
              if (c.streamReader) {
                if (c.streamReaderCancelTimeout && (clearTimeout(c.streamReaderCancelTimeout), c.streamReaderCancelTimeout = null), !R) {
                  if (c.renderTasks.size > 0)
                    return;
                  if (b instanceof x.RenderingCancelledException) {
                    let I = L;
                    b.extraDelay > 0 && b.extraDelay < 1e3 && (I += b.extraDelay), c.streamReaderCancelTimeout = setTimeout(() => {
                      c.streamReaderCancelTimeout = null, this._abortOperatorList({
                        intentState: c,
                        reason: b,
                        force: !0
                      });
                    }, I);
                    return;
                  }
                }
                if (c.streamReader.cancel(new v.AbortException(b.message)).catch(() => {
                }), c.streamReader = null, !this._transport.destroyed) {
                  for (const [I, O] of this._intentStates)
                    if (O === c) {
                      this._intentStates.delete(I);
                      break;
                    }
                  this.cleanup();
                }
              }
            }
            get stats() {
              return this._stats;
            }
          }
          class dt {
            #t = /* @__PURE__ */ new Set();
            #e = Promise.resolve();
            postMessage(c, b) {
              const R = {
                data: structuredClone(c, b ? {
                  transfer: b
                } : null)
              };
              this.#e.then(() => {
                for (const I of this.#t)
                  I.call(this, R);
              });
            }
            addEventListener(c, b) {
              this.#t.add(b);
            }
            removeEventListener(c, b) {
              this.#t.delete(b);
            }
            terminate() {
              this.#t.clear();
            }
          }
          const ft = {
            isWorkerDisabled: !1,
            fakeWorkerId: 0
          };
          v.isNodeJS && (ft.isWorkerDisabled = !0, f.GlobalWorkerOptions.workerSrc ||= "./pdf.worker.mjs"), ft.isSameOrigin = function(g, c) {
            let b;
            try {
              if (b = new URL(g), !b.origin || b.origin === "null")
                return !1;
            } catch {
              return !1;
            }
            const R = new URL(c, b);
            return b.origin === R.origin;
          }, ft.createCDNWrapper = function(g) {
            const c = `await import("${g}");`;
            return URL.createObjectURL(new Blob([c], {
              type: "text/javascript"
            }));
          };
          class lt {
            static #t;
            constructor({
              name: c = null,
              port: b = null,
              verbosity: R = (0, v.getVerbosityLevel)()
            } = {}) {
              if (this.name = c, this.destroyed = !1, this.verbosity = R, this._readyCapability = Promise.withResolvers(), this._port = null, this._webWorker = null, this._messageHandler = null, b) {
                if (lt.#t?.has(b))
                  throw new Error("Cannot use more than one PDFWorker per port.");
                (lt.#t ||= /* @__PURE__ */ new WeakMap()).set(b, this), this._initializeFromPort(b);
                return;
              }
              this._initialize();
            }
            get promise() {
              return this._readyCapability.promise;
            }
            get port() {
              return this._port;
            }
            get messageHandler() {
              return this._messageHandler;
            }
            _initializeFromPort(c) {
              this._port = c, this._messageHandler = new p.MessageHandler("main", "worker", c), this._messageHandler.on("ready", function() {
              }), this._readyCapability.resolve(), this._messageHandler.send("configure", {
                verbosity: this.verbosity
              });
            }
            _initialize() {
              if (!ft.isWorkerDisabled && !lt.#e) {
                let {
                  workerSrc: c
                } = lt;
                try {
                  ft.isSameOrigin(window.location.href, c) || (c = ft.createCDNWrapper(new URL(c, window.location).href));
                  const b = new Worker(c, {
                    type: "module"
                  }), R = new p.MessageHandler("main", "worker", b), I = () => {
                    b.removeEventListener("error", O), R.destroy(), b.terminate(), this.destroyed ? this._readyCapability.reject(new Error("Worker was destroyed")) : this._setupFakeWorker();
                  }, O = () => {
                    this._webWorker || I();
                  };
                  b.addEventListener("error", O), R.on("test", ($) => {
                    if (b.removeEventListener("error", O), this.destroyed) {
                      I();
                      return;
                    }
                    $ ? (this._messageHandler = R, this._port = b, this._webWorker = b, this._readyCapability.resolve(), R.send("configure", {
                      verbosity: this.verbosity
                    })) : (this._setupFakeWorker(), R.destroy(), b.terminate());
                  }), R.on("ready", ($) => {
                    if (b.removeEventListener("error", O), this.destroyed) {
                      I();
                      return;
                    }
                    try {
                      H();
                    } catch {
                      this._setupFakeWorker();
                    }
                  });
                  const H = () => {
                    const $ = new Uint8Array();
                    R.send("test", $, [$.buffer]);
                  };
                  H();
                  return;
                } catch {
                  (0, v.info)("The worker has been disabled.");
                }
              }
              this._setupFakeWorker();
            }
            _setupFakeWorker() {
              ft.isWorkerDisabled || ((0, v.warn)("Setting up fake worker."), ft.isWorkerDisabled = !0), lt._setupFakeWorkerGlobal.then((c) => {
                if (this.destroyed) {
                  this._readyCapability.reject(new Error("Worker was destroyed"));
                  return;
                }
                const b = new dt();
                this._port = b;
                const R = `fake${ft.fakeWorkerId++}`, I = new p.MessageHandler(R + "_worker", R, b);
                c.setup(I, b);
                const O = new p.MessageHandler(R, R + "_worker", b);
                this._messageHandler = O, this._readyCapability.resolve(), O.send("configure", {
                  verbosity: this.verbosity
                });
              }).catch((c) => {
                this._readyCapability.reject(new Error(`Setting up fake worker failed: "${c.message}".`));
              });
            }
            destroy() {
              this.destroyed = !0, this._webWorker && (this._webWorker.terminate(), this._webWorker = null), lt.#t?.delete(this._port), this._port = null, this._messageHandler && (this._messageHandler.destroy(), this._messageHandler = null);
            }
            static fromPort(c) {
              if (!c?.port)
                throw new Error("PDFWorker.fromPort - invalid method signature.");
              const b = this.#t?.get(c.port);
              if (b) {
                if (b._pendingDestroy)
                  throw new Error("PDFWorker.fromPort - the worker is being destroyed.\nPlease remember to await `PDFDocumentLoadingTask.destroy()`-calls.");
                return b;
              }
              return new lt(c);
            }
            static get workerSrc() {
              if (f.GlobalWorkerOptions.workerSrc)
                return f.GlobalWorkerOptions.workerSrc;
              throw new Error('No "GlobalWorkerOptions.workerSrc" specified.');
            }
            static get #e() {
              try {
                return globalThis.pdfjsWorker?.WorkerMessageHandler || null;
              } catch {
                return null;
              }
            }
            static get _setupFakeWorkerGlobal() {
              const c = async () => this.#e ? this.#e : (await import(
                /*webpackIgnore: true*/
                this.workerSrc
              )).WorkerMessageHandler;
              return (0, v.shadow)(this, "_setupFakeWorkerGlobal", c());
            }
          }
          class ot {
            #t = /* @__PURE__ */ new Map();
            #e = /* @__PURE__ */ new Map();
            #s = /* @__PURE__ */ new Map();
            #n = /* @__PURE__ */ new Map();
            #r = null;
            constructor(c, b, R, I, O) {
              this.messageHandler = c, this.loadingTask = b, this.commonObjs = new D(), this.fontLoader = new C.FontLoader({
                ownerDocument: I.ownerDocument,
                styleElement: I.styleElement
              }), this._params = I, this.canvasFactory = O.canvasFactory, this.filterFactory = O.filterFactory, this.cMapReaderFactory = O.cMapReaderFactory, this.standardFontDataFactory = O.standardFontDataFactory, this.destroyed = !1, this.destroyCapability = null, this._networkStream = R, this._fullReader = null, this._lastProgress = null, this.downloadInfoCapability = Promise.withResolvers(), this.setupMessageHandler();
            }
            #i(c, b = null) {
              const R = this.#t.get(c);
              if (R)
                return R;
              const I = this.messageHandler.sendWithPromise(c, b);
              return this.#t.set(c, I), I;
            }
            get annotationStorage() {
              return (0, v.shadow)(this, "annotationStorage", new _.AnnotationStorage());
            }
            getRenderingIntent(c, b = v.AnnotationMode.ENABLE, R = null, I = !1) {
              let O = v.RenderingIntentFlag.DISPLAY, H = _.SerializableEmpty;
              switch (c) {
                case "any":
                  O = v.RenderingIntentFlag.ANY;
                  break;
                case "display":
                  break;
                case "print":
                  O = v.RenderingIntentFlag.PRINT;
                  break;
                default:
                  (0, v.warn)(`getRenderingIntent - invalid intent: ${c}`);
              }
              switch (b) {
                case v.AnnotationMode.DISABLE:
                  O += v.RenderingIntentFlag.ANNOTATIONS_DISABLE;
                  break;
                case v.AnnotationMode.ENABLE:
                  break;
                case v.AnnotationMode.ENABLE_FORMS:
                  O += v.RenderingIntentFlag.ANNOTATIONS_FORMS;
                  break;
                case v.AnnotationMode.ENABLE_STORAGE:
                  O += v.RenderingIntentFlag.ANNOTATIONS_STORAGE, H = (O & v.RenderingIntentFlag.PRINT && R instanceof _.PrintAnnotationStorage ? R : this.annotationStorage).serializable;
                  break;
                default:
                  (0, v.warn)(`getRenderingIntent - invalid annotationMode: ${b}`);
              }
              return I && (O += v.RenderingIntentFlag.OPLIST), {
                renderingIntent: O,
                cacheKey: `${O}_${H.hash}`,
                annotationStorageSerializable: H
              };
            }
            destroy() {
              if (this.destroyCapability)
                return this.destroyCapability.promise;
              this.destroyed = !0, this.destroyCapability = Promise.withResolvers(), this.#r?.reject(new Error("Worker was destroyed during onPassword callback"));
              const c = [];
              for (const R of this.#e.values())
                c.push(R._destroy());
              this.#e.clear(), this.#s.clear(), this.#n.clear(), this.hasOwnProperty("annotationStorage") && this.annotationStorage.resetModified();
              const b = this.messageHandler.sendWithPromise("Terminate", null);
              return c.push(b), Promise.all(c).then(() => {
                this.commonObjs.clear(), this.fontLoader.clear(), this.#t.clear(), this.filterFactory.destroy(), (0, n.cleanupTextLayer)(), this._networkStream?.cancelAllRequests(new v.AbortException("Worker was terminated.")), this.messageHandler && (this.messageHandler.destroy(), this.messageHandler = null), this.destroyCapability.resolve();
              }, this.destroyCapability.reject), this.destroyCapability.promise;
            }
            setupMessageHandler() {
              const {
                messageHandler: c,
                loadingTask: b
              } = this;
              c.on("GetReader", (R, I) => {
                (0, v.assert)(this._networkStream, "GetReader - no `IPDFStream` instance available."), this._fullReader = this._networkStream.getFullReader(), this._fullReader.onProgress = (O) => {
                  this._lastProgress = {
                    loaded: O.loaded,
                    total: O.total
                  };
                }, I.onPull = () => {
                  this._fullReader.read().then(function({
                    value: O,
                    done: H
                  }) {
                    if (H) {
                      I.close();
                      return;
                    }
                    (0, v.assert)(O instanceof ArrayBuffer, "GetReader - expected an ArrayBuffer."), I.enqueue(new Uint8Array(O), 1, [O]);
                  }).catch((O) => {
                    I.error(O);
                  });
                }, I.onCancel = (O) => {
                  this._fullReader.cancel(O), I.ready.catch((H) => {
                    if (!this.destroyed)
                      throw H;
                  });
                };
              }), c.on("ReaderHeadersReady", (R) => {
                const I = Promise.withResolvers(), O = this._fullReader;
                return O.headersReady.then(() => {
                  (!O.isStreamingSupported || !O.isRangeSupported) && (this._lastProgress && b.onProgress?.(this._lastProgress), O.onProgress = (H) => {
                    b.onProgress?.({
                      loaded: H.loaded,
                      total: H.total
                    });
                  }), I.resolve({
                    isStreamingSupported: O.isStreamingSupported,
                    isRangeSupported: O.isRangeSupported,
                    contentLength: O.contentLength
                  });
                }, I.reject), I.promise;
              }), c.on("GetRangeReader", (R, I) => {
                (0, v.assert)(this._networkStream, "GetRangeReader - no `IPDFStream` instance available.");
                const O = this._networkStream.getRangeReader(R.begin, R.end);
                if (!O) {
                  I.close();
                  return;
                }
                I.onPull = () => {
                  O.read().then(function({
                    value: H,
                    done: $
                  }) {
                    if ($) {
                      I.close();
                      return;
                    }
                    (0, v.assert)(H instanceof ArrayBuffer, "GetRangeReader - expected an ArrayBuffer."), I.enqueue(new Uint8Array(H), 1, [H]);
                  }).catch((H) => {
                    I.error(H);
                  });
                }, I.onCancel = (H) => {
                  O.cancel(H), I.ready.catch(($) => {
                    if (!this.destroyed)
                      throw $;
                  });
                };
              }), c.on("GetDoc", ({
                pdfInfo: R
              }) => {
                this._numPages = R.numPages, this._htmlForXfa = R.htmlForXfa, delete R.htmlForXfa, b._capability.resolve(new rt(R, this));
              }), c.on("DocException", function(R) {
                let I;
                switch (R.name) {
                  case "PasswordException":
                    I = new v.PasswordException(R.message, R.code);
                    break;
                  case "InvalidPDFException":
                    I = new v.InvalidPDFException(R.message);
                    break;
                  case "MissingPDFException":
                    I = new v.MissingPDFException(R.message);
                    break;
                  case "UnexpectedResponseException":
                    I = new v.UnexpectedResponseException(R.message, R.status);
                    break;
                  case "UnknownErrorException":
                    I = new v.UnknownErrorException(R.message, R.details);
                    break;
                  default:
                    (0, v.unreachable)("DocException - expected a valid Error.");
                }
                b._capability.reject(I);
              }), c.on("PasswordRequest", (R) => {
                if (this.#r = Promise.withResolvers(), b.onPassword) {
                  const I = (O) => {
                    O instanceof Error ? this.#r.reject(O) : this.#r.resolve({
                      password: O
                    });
                  };
                  try {
                    b.onPassword(I, R.code);
                  } catch (O) {
                    this.#r.reject(O);
                  }
                } else
                  this.#r.reject(new v.PasswordException(R.message, R.code));
                return this.#r.promise;
              }), c.on("DataLoaded", (R) => {
                b.onProgress?.({
                  loaded: R.length,
                  total: R.length
                }), this.downloadInfoCapability.resolve(R);
              }), c.on("StartRenderPage", (R) => {
                if (this.destroyed)
                  return;
                this.#e.get(R.pageIndex)._startRenderPage(R.transparency, R.cacheKey);
              }), c.on("commonobj", ([R, I, O]) => {
                if (this.destroyed || this.commonObjs.has(R))
                  return null;
                switch (I) {
                  case "Font":
                    const H = this._params;
                    if ("error" in O) {
                      const P = O.error;
                      (0, v.warn)(`Error during font loading: ${P}`), this.commonObjs.resolve(R, P);
                      break;
                    }
                    const $ = H.pdfBug && globalThis.FontInspector?.enabled ? (P, X) => globalThis.FontInspector.fontAdded(P, X) : null, z = new C.FontFaceObject(O, {
                      disableFontFace: H.disableFontFace,
                      ignoreErrors: H.ignoreErrors,
                      inspectFont: $
                    });
                    this.fontLoader.bind(z).catch(() => c.sendWithPromise("FontFallback", {
                      id: R
                    })).finally(() => {
                      !H.fontExtraProperties && z.data && (z.data = null), this.commonObjs.resolve(R, z);
                    });
                    break;
                  case "CopyLocalImage":
                    const {
                      imageRef: N
                    } = O;
                    (0, v.assert)(N, "The imageRef must be defined.");
                    for (const P of this.#e.values())
                      for (const [, X] of P.objs)
                        if (X.ref === N)
                          return X.dataLen ? (this.commonObjs.resolve(R, structuredClone(X)), X.dataLen) : null;
                    break;
                  case "FontPath":
                  case "Image":
                  case "Pattern":
                    this.commonObjs.resolve(R, O);
                    break;
                  default:
                    throw new Error(`Got unknown common object type ${I}`);
                }
                return null;
              }), c.on("obj", ([R, I, O, H]) => {
                if (this.destroyed)
                  return;
                const $ = this.#e.get(I);
                if (!$.objs.has(R)) {
                  if ($._intentStates.size === 0) {
                    H?.bitmap?.close();
                    return;
                  }
                  switch (O) {
                    case "Image":
                      $.objs.resolve(R, H), H?.dataLen > v.MAX_IMAGE_SIZE_TO_CACHE && ($._maybeCleanupAfterRender = !0);
                      break;
                    case "Pattern":
                      $.objs.resolve(R, H);
                      break;
                    default:
                      throw new Error(`Got unknown object type ${O}`);
                  }
                }
              }), c.on("DocProgress", (R) => {
                this.destroyed || b.onProgress?.({
                  loaded: R.loaded,
                  total: R.total
                });
              }), c.on("FetchBuiltInCMap", (R) => this.destroyed ? Promise.reject(new Error("Worker was destroyed.")) : this.cMapReaderFactory ? this.cMapReaderFactory.fetch(R) : Promise.reject(new Error("CMapReaderFactory not initialized, see the `useWorkerFetch` parameter."))), c.on("FetchStandardFontData", (R) => this.destroyed ? Promise.reject(new Error("Worker was destroyed.")) : this.standardFontDataFactory ? this.standardFontDataFactory.fetch(R) : Promise.reject(new Error("StandardFontDataFactory not initialized, see the `useWorkerFetch` parameter.")));
            }
            getData() {
              return this.messageHandler.sendWithPromise("GetData", null);
            }
            saveDocument() {
              this.annotationStorage.size <= 0 && (0, v.warn)("saveDocument called while `annotationStorage` is empty, please use the getData-method instead.");
              const {
                map: c,
                transfer: b
              } = this.annotationStorage.serializable;
              return this.messageHandler.sendWithPromise("SaveDocument", {
                isPureXfa: !!this._htmlForXfa,
                numPages: this._numPages,
                annotationStorage: c,
                filename: this._fullReader?.filename ?? null
              }, b).finally(() => {
                this.annotationStorage.resetModified();
              });
            }
            getPage(c) {
              if (!Number.isInteger(c) || c <= 0 || c > this._numPages)
                return Promise.reject(new Error("Invalid page request."));
              const b = c - 1, R = this.#s.get(b);
              if (R)
                return R;
              const I = this.messageHandler.sendWithPromise("GetPage", {
                pageIndex: b
              }).then((O) => {
                if (this.destroyed)
                  throw new Error("Transport destroyed");
                O.refStr && this.#n.set(O.refStr, c);
                const H = new ut(b, O, this, this._params.pdfBug);
                return this.#e.set(b, H), H;
              });
              return this.#s.set(b, I), I;
            }
            getPageIndex(c) {
              return Q(c) ? this.messageHandler.sendWithPromise("GetPageIndex", {
                num: c.num,
                gen: c.gen
              }) : Promise.reject(new Error("Invalid pageIndex request."));
            }
            getAnnotations(c, b) {
              return this.messageHandler.sendWithPromise("GetAnnotations", {
                pageIndex: c,
                intent: b
              });
            }
            getFieldObjects() {
              return this.#i("GetFieldObjects");
            }
            hasJSActions() {
              return this.#i("HasJSActions");
            }
            getCalculationOrderIds() {
              return this.messageHandler.sendWithPromise("GetCalculationOrderIds", null);
            }
            getDestinations() {
              return this.messageHandler.sendWithPromise("GetDestinations", null);
            }
            getDestination(c) {
              return typeof c != "string" ? Promise.reject(new Error("Invalid destination request.")) : this.messageHandler.sendWithPromise("GetDestination", {
                id: c
              });
            }
            getPageLabels() {
              return this.messageHandler.sendWithPromise("GetPageLabels", null);
            }
            getPageLayout() {
              return this.messageHandler.sendWithPromise("GetPageLayout", null);
            }
            getPageMode() {
              return this.messageHandler.sendWithPromise("GetPageMode", null);
            }
            getViewerPreferences() {
              return this.messageHandler.sendWithPromise("GetViewerPreferences", null);
            }
            getOpenAction() {
              return this.messageHandler.sendWithPromise("GetOpenAction", null);
            }
            getAttachments() {
              return this.messageHandler.sendWithPromise("GetAttachments", null);
            }
            getDocJSActions() {
              return this.#i("GetDocJSActions");
            }
            getPageJSActions(c) {
              return this.messageHandler.sendWithPromise("GetPageJSActions", {
                pageIndex: c
              });
            }
            getStructTree(c) {
              return this.messageHandler.sendWithPromise("GetStructTree", {
                pageIndex: c
              });
            }
            getOutline() {
              return this.messageHandler.sendWithPromise("GetOutline", null);
            }
            getOptionalContentConfig(c) {
              return this.#i("GetOptionalContentConfig").then((b) => new r.OptionalContentConfig(b, c));
            }
            getPermissions() {
              return this.messageHandler.sendWithPromise("GetPermissions", null);
            }
            getMetadata() {
              const c = "GetMetadata", b = this.#t.get(c);
              if (b)
                return b;
              const R = this.messageHandler.sendWithPromise(c, null).then((I) => ({
                info: I[0],
                metadata: I[1] ? new F.Metadata(I[1]) : null,
                contentDispositionFilename: this._fullReader?.filename ?? null,
                contentLength: this._fullReader?.contentLength ?? null
              }));
              return this.#t.set(c, R), R;
            }
            getMarkInfo() {
              return this.messageHandler.sendWithPromise("GetMarkInfo", null);
            }
            async startCleanup(c = !1) {
              if (!this.destroyed) {
                await this.messageHandler.sendWithPromise("Cleanup", null);
                for (const b of this.#e.values())
                  if (!b.cleanup())
                    throw new Error(`startCleanup: Page ${b.pageNumber} is currently rendering.`);
                this.commonObjs.clear(), c || this.fontLoader.clear(), this.#t.clear(), this.filterFactory.destroy(!0), (0, n.cleanupTextLayer)();
              }
            }
            cachedPageNumber(c) {
              if (!Q(c))
                return null;
              const b = c.gen === 0 ? `${c.num}R` : `${c.num}R${c.gen}`;
              return this.#n.get(b) ?? null;
            }
            get loadingParams() {
              const {
                disableAutoFetch: c,
                enableXfa: b
              } = this._params;
              return (0, v.shadow)(this, "loadingParams", {
                disableAutoFetch: c,
                enableXfa: b
              });
            }
          }
          const et = Symbol("INITIAL_DATA");
          class D {
            #t = /* @__PURE__ */ Object.create(null);
            #e(c) {
              return this.#t[c] ||= {
                ...Promise.withResolvers(),
                data: et
              };
            }
            get(c, b = null) {
              if (b) {
                const I = this.#e(c);
                return I.promise.then(() => b(I.data)), null;
              }
              const R = this.#t[c];
              if (!R || R.data === et)
                throw new Error(`Requesting object that isn't resolved yet ${c}.`);
              return R.data;
            }
            has(c) {
              const b = this.#t[c];
              return !!b && b.data !== et;
            }
            resolve(c, b = null) {
              const R = this.#e(c);
              R.data = b, R.resolve();
            }
            clear() {
              for (const c in this.#t) {
                const {
                  data: b
                } = this.#t[c];
                b?.bitmap?.close();
              }
              this.#t = /* @__PURE__ */ Object.create(null);
            }
            *[Symbol.iterator]() {
              for (const c in this.#t) {
                const {
                  data: b
                } = this.#t[c];
                b !== et && (yield [c, b]);
              }
            }
          }
          class y {
            #t = null;
            constructor(c) {
              this.#t = c, this.onContinue = null;
            }
            get promise() {
              return this.#t.capability.promise;
            }
            cancel(c = 0) {
              this.#t.cancel(null, c);
            }
            get separateAnnots() {
              const {
                separateAnnots: c
              } = this.#t.operatorList;
              if (!c)
                return !1;
              const {
                annotationCanvasMap: b
              } = this.#t;
              return c.form || c.canvas && b?.size > 0;
            }
          }
          class o {
            static #t = /* @__PURE__ */ new WeakSet();
            constructor({
              callback: c,
              params: b,
              objs: R,
              commonObjs: I,
              annotationCanvasMap: O,
              operatorList: H,
              pageIndex: $,
              canvasFactory: z,
              filterFactory: N,
              useRequestAnimationFrame: P = !1,
              pdfBug: X = !1,
              pageColors: it = null
            }) {
              this.callback = c, this.params = b, this.objs = R, this.commonObjs = I, this.annotationCanvasMap = O, this.operatorListIdx = null, this.operatorList = H, this._pageIndex = $, this.canvasFactory = z, this.filterFactory = N, this._pdfBug = X, this.pageColors = it, this.running = !1, this.graphicsReadyCallback = null, this.graphicsReady = !1, this._useRequestAnimationFrame = P === !0 && typeof window < "u", this.cancelled = !1, this.capability = Promise.withResolvers(), this.task = new y(this), this._cancelBound = this.cancel.bind(this), this._continueBound = this._continue.bind(this), this._scheduleNextBound = this._scheduleNext.bind(this), this._nextBound = this._next.bind(this), this._canvas = b.canvasContext.canvas;
            }
            get completed() {
              return this.capability.promise.catch(function() {
              });
            }
            initializeGraphics({
              transparency: c = !1,
              optionalContentConfig: b
            }) {
              if (this.cancelled)
                return;
              if (this._canvas) {
                if (o.#t.has(this._canvas))
                  throw new Error("Cannot use the same canvas during multiple render() operations. Use different canvas or ensure previous operations were cancelled or completed.");
                o.#t.add(this._canvas);
              }
              this._pdfBug && globalThis.StepperManager?.enabled && (this.stepper = globalThis.StepperManager.create(this._pageIndex), this.stepper.init(this.operatorList), this.stepper.nextBreakPoint = this.stepper.getNextBreakPoint());
              const {
                canvasContext: R,
                viewport: I,
                transform: O,
                background: H
              } = this.params;
              this.gfx = new A.CanvasGraphics(R, this.commonObjs, this.objs, this.canvasFactory, this.filterFactory, {
                optionalContentConfig: b
              }, this.annotationCanvasMap, this.pageColors), this.gfx.beginDrawing({
                transform: O,
                viewport: I,
                transparency: c,
                background: H
              }), this.operatorListIdx = 0, this.graphicsReady = !0, this.graphicsReadyCallback?.();
            }
            cancel(c = null, b = 0) {
              this.running = !1, this.cancelled = !0, this.gfx?.endDrawing(), o.#t.delete(this._canvas), this.callback(c || new x.RenderingCancelledException(`Rendering cancelled, page ${this._pageIndex + 1}`, b));
            }
            operatorListChanged() {
              if (!this.graphicsReady) {
                this.graphicsReadyCallback ||= this._continueBound;
                return;
              }
              this.stepper?.updateOperatorList(this.operatorList), !this.running && this._continue();
            }
            _continue() {
              this.running = !0, !this.cancelled && (this.task.onContinue ? this.task.onContinue(this._scheduleNextBound) : this._scheduleNext());
            }
            _scheduleNext() {
              this._useRequestAnimationFrame ? window.requestAnimationFrame(() => {
                this._nextBound().catch(this._cancelBound);
              }) : Promise.resolve().then(this._nextBound).catch(this._cancelBound);
            }
            async _next() {
              this.cancelled || (this.operatorListIdx = this.gfx.executeOperatorList(this.operatorList, this.operatorListIdx, this._continueBound, this.stepper), this.operatorListIdx === this.operatorList.argsArray.length && (this.running = !1, this.operatorList.lastChunk && (this.gfx.endDrawing(), o.#t.delete(this._canvas), this.callback())));
            }
          }
          const u = "4.2.67", m = "49b388101";
          S();
        } catch (k) {
          S(k);
        }
      });
    })
  ),
  /***/
  583: (
    /***/
    ((V, l, a) => {
      a.d(l, {
        /* harmony export */
        BaseCMapReaderFactory: () => (
          /* binding */
          _
        ),
        /* harmony export */
        BaseCanvasFactory: () => (
          /* binding */
          v
        ),
        /* harmony export */
        BaseFilterFactory: () => (
          /* binding */
          S
        ),
        /* harmony export */
        BaseSVGFactory: () => (
          /* binding */
          C
        ),
        /* harmony export */
        BaseStandardFontDataFactory: () => (
          /* binding */
          x
        )
        /* harmony export */
      });
      var s = a(292);
      class S {
        constructor() {
          this.constructor === S && (0, s.unreachable)("Cannot initialize BaseFilterFactory.");
        }
        addFilter(A) {
          return "none";
        }
        addHCMFilter(A, n) {
          return "none";
        }
        addHighlightHCMFilter(A, n, f, p, F) {
          return "none";
        }
        destroy(A = !1) {
        }
      }
      class v {
        constructor() {
          this.constructor === v && (0, s.unreachable)("Cannot initialize BaseCanvasFactory.");
        }
        create(A, n) {
          if (A <= 0 || n <= 0)
            throw new Error("Invalid canvas size");
          const f = this._createCanvas(A, n);
          return {
            canvas: f,
            context: f.getContext("2d")
          };
        }
        reset(A, n, f) {
          if (!A.canvas)
            throw new Error("Canvas is not specified");
          if (n <= 0 || f <= 0)
            throw new Error("Invalid canvas size");
          A.canvas.width = n, A.canvas.height = f;
        }
        destroy(A) {
          if (!A.canvas)
            throw new Error("Canvas is not specified");
          A.canvas.width = 0, A.canvas.height = 0, A.canvas = null, A.context = null;
        }
        _createCanvas(A, n) {
          (0, s.unreachable)("Abstract method `_createCanvas` called.");
        }
      }
      class _ {
        constructor({
          baseUrl: A = null,
          isCompressed: n = !0
        }) {
          this.constructor === _ && (0, s.unreachable)("Cannot initialize BaseCMapReaderFactory."), this.baseUrl = A, this.isCompressed = n;
        }
        async fetch({
          name: A
        }) {
          if (!this.baseUrl)
            throw new Error('The CMap "baseUrl" parameter must be specified, ensure that the "cMapUrl" and "cMapPacked" API parameters are provided.');
          if (!A)
            throw new Error("CMap name must be specified.");
          const n = this.baseUrl + A + (this.isCompressed ? ".bcmap" : ""), f = this.isCompressed ? s.CMapCompressionType.BINARY : s.CMapCompressionType.NONE;
          return this._fetchData(n, f).catch((p) => {
            throw new Error(`Unable to load ${this.isCompressed ? "binary " : ""}CMap at: ${n}`);
          });
        }
        _fetchData(A, n) {
          (0, s.unreachable)("Abstract method `_fetchData` called.");
        }
      }
      class x {
        constructor({
          baseUrl: A = null
        }) {
          this.constructor === x && (0, s.unreachable)("Cannot initialize BaseStandardFontDataFactory."), this.baseUrl = A;
        }
        async fetch({
          filename: A
        }) {
          if (!this.baseUrl)
            throw new Error('The standard font "baseUrl" parameter must be specified, ensure that the "standardFontDataUrl" API parameter is provided.');
          if (!A)
            throw new Error("Font filename must be specified.");
          const n = `${this.baseUrl}${A}`;
          return this._fetchData(n).catch((f) => {
            throw new Error(`Unable to load font data at: ${n}`);
          });
        }
        _fetchData(A) {
          (0, s.unreachable)("Abstract method `_fetchData` called.");
        }
      }
      class C {
        constructor() {
          this.constructor === C && (0, s.unreachable)("Cannot initialize BaseSVGFactory.");
        }
        create(A, n, f = !1) {
          if (A <= 0 || n <= 0)
            throw new Error("Invalid SVG dimensions");
          const p = this._createSVG("svg:svg");
          return p.setAttribute("version", "1.1"), f || (p.setAttribute("width", `${A}px`), p.setAttribute("height", `${n}px`)), p.setAttribute("preserveAspectRatio", "none"), p.setAttribute("viewBox", `0 0 ${A} ${n}`), p;
        }
        createElement(A) {
          if (typeof A != "string")
            throw new Error("Invalid SVG element type");
          return this._createSVG(A);
        }
        _createSVG(A) {
          (0, s.unreachable)("Abstract method `_createSVG` called.");
        }
      }
    })
  ),
  /***/
  923: (
    /***/
    ((V, l, a) => {
      a.d(l, {
        CanvasGraphics: () => (
          /* binding */
          D
        )
      });
      var s = a(292), S = a(419);
      const v = {
        FILL: "Fill",
        STROKE: "Stroke",
        SHADING: "Shading"
      };
      function _(y, o) {
        if (!o)
          return;
        const u = o[2] - o[0], m = o[3] - o[1], g = new Path2D();
        g.rect(o[0], o[1], u, m), y.clip(g);
      }
      class x {
        constructor() {
          this.constructor === x && (0, s.unreachable)("Cannot initialize BaseShadingPattern.");
        }
        getPattern() {
          (0, s.unreachable)("Abstract method `getPattern` called.");
        }
      }
      class C extends x {
        constructor(o) {
          super(), this._type = o[1], this._bbox = o[2], this._colorStops = o[3], this._p0 = o[4], this._p1 = o[5], this._r0 = o[6], this._r1 = o[7], this.matrix = null;
        }
        _createGradient(o) {
          let u;
          this._type === "axial" ? u = o.createLinearGradient(this._p0[0], this._p0[1], this._p1[0], this._p1[1]) : this._type === "radial" && (u = o.createRadialGradient(this._p0[0], this._p0[1], this._r0, this._p1[0], this._p1[1], this._r1));
          for (const m of this._colorStops)
            u.addColorStop(m[0], m[1]);
          return u;
        }
        getPattern(o, u, m, g) {
          let c;
          if (g === v.STROKE || g === v.FILL) {
            const b = u.current.getClippedPathBoundingBox(g, (0, S.getCurrentTransform)(o)) || [0, 0, 0, 0], R = Math.ceil(b[2] - b[0]) || 1, I = Math.ceil(b[3] - b[1]) || 1, O = u.cachedCanvases.getCanvas("pattern", R, I, !0), H = O.context;
            H.clearRect(0, 0, H.canvas.width, H.canvas.height), H.beginPath(), H.rect(0, 0, H.canvas.width, H.canvas.height), H.translate(-b[0], -b[1]), m = s.Util.transform(m, [1, 0, 0, 1, b[0], b[1]]), H.transform(...u.baseTransform), this.matrix && H.transform(...this.matrix), _(H, this._bbox), H.fillStyle = this._createGradient(H), H.fill(), c = o.createPattern(O.canvas, "no-repeat");
            const $ = new DOMMatrix(m);
            c.setTransform($);
          } else
            _(o, this._bbox), c = this._createGradient(o);
          return c;
        }
      }
      function T(y, o, u, m, g, c, b, R) {
        const I = o.coords, O = o.colors, H = y.data, $ = y.width * 4;
        let z;
        I[u + 1] > I[m + 1] && (z = u, u = m, m = z, z = c, c = b, b = z), I[m + 1] > I[g + 1] && (z = m, m = g, g = z, z = b, b = R, R = z), I[u + 1] > I[m + 1] && (z = u, u = m, m = z, z = c, c = b, b = z);
        const N = (I[u] + o.offsetX) * o.scaleX, P = (I[u + 1] + o.offsetY) * o.scaleY, X = (I[m] + o.offsetX) * o.scaleX, it = (I[m + 1] + o.offsetY) * o.scaleY, W = (I[g] + o.offsetX) * o.scaleX, st = (I[g + 1] + o.offsetY) * o.scaleY;
        if (P >= st)
          return;
        const ct = O[c], at = O[c + 1], nt = O[c + 2], ht = O[b], pt = O[b + 1], vt = O[b + 2], bt = O[R], wt = O[R + 1], mt = O[R + 2], St = Math.round(P), Et = Math.round(st);
        let Ft, xt, Tt, It, Nt, zt, Ut, Ot;
        for (let _t = St; _t <= Et; _t++) {
          if (_t < it) {
            const Dt = _t < P ? 0 : (P - _t) / (P - it);
            Ft = N - (N - X) * Dt, xt = ct - (ct - ht) * Dt, Tt = at - (at - pt) * Dt, It = nt - (nt - vt) * Dt;
          } else {
            let Dt;
            _t > st ? Dt = 1 : it === st ? Dt = 0 : Dt = (it - _t) / (it - st), Ft = X - (X - W) * Dt, xt = ht - (ht - bt) * Dt, Tt = pt - (pt - wt) * Dt, It = vt - (vt - mt) * Dt;
          }
          let Ct;
          _t < P ? Ct = 0 : _t > st ? Ct = 1 : Ct = (P - _t) / (P - st), Nt = N - (N - W) * Ct, zt = ct - (ct - bt) * Ct, Ut = at - (at - wt) * Ct, Ot = nt - (nt - mt) * Ct;
          const kt = Math.round(Math.min(Ft, Nt)), Rt = Math.round(Math.max(Ft, Nt));
          let Bt = $ * _t + kt * 4;
          for (let Dt = kt; Dt <= Rt; Dt++)
            Ct = (Ft - Dt) / (Ft - Nt), Ct < 0 ? Ct = 0 : Ct > 1 && (Ct = 1), H[Bt++] = xt - (xt - zt) * Ct | 0, H[Bt++] = Tt - (Tt - Ut) * Ct | 0, H[Bt++] = It - (It - Ot) * Ct | 0, H[Bt++] = 255;
        }
      }
      function A(y, o, u) {
        const m = o.coords, g = o.colors;
        let c, b;
        switch (o.type) {
          case "lattice":
            const R = o.verticesPerRow, I = Math.floor(m.length / R) - 1, O = R - 1;
            for (c = 0; c < I; c++) {
              let H = c * R;
              for (let $ = 0; $ < O; $++, H++)
                T(y, u, m[H], m[H + 1], m[H + R], g[H], g[H + 1], g[H + R]), T(y, u, m[H + R + 1], m[H + 1], m[H + R], g[H + R + 1], g[H + 1], g[H + R]);
            }
            break;
          case "triangles":
            for (c = 0, b = m.length; c < b; c += 3)
              T(y, u, m[c], m[c + 1], m[c + 2], g[c], g[c + 1], g[c + 2]);
            break;
          default:
            throw new Error("illegal figure");
        }
      }
      class n extends x {
        constructor(o) {
          super(), this._coords = o[2], this._colors = o[3], this._figures = o[4], this._bounds = o[5], this._bbox = o[7], this._background = o[8], this.matrix = null;
        }
        _createMeshCanvas(o, u, m) {
          const R = Math.floor(this._bounds[0]), I = Math.floor(this._bounds[1]), O = Math.ceil(this._bounds[2]) - R, H = Math.ceil(this._bounds[3]) - I, $ = Math.min(Math.ceil(Math.abs(O * o[0] * 1.1)), 3e3), z = Math.min(Math.ceil(Math.abs(H * o[1] * 1.1)), 3e3), N = O / $, P = H / z, X = {
            coords: this._coords,
            colors: this._colors,
            offsetX: -R,
            offsetY: -I,
            scaleX: 1 / N,
            scaleY: 1 / P
          }, it = $ + 4, W = z + 4, st = m.getCanvas("mesh", it, W, !1), ct = st.context, at = ct.createImageData($, z);
          if (u) {
            const ht = at.data;
            for (let pt = 0, vt = ht.length; pt < vt; pt += 4)
              ht[pt] = u[0], ht[pt + 1] = u[1], ht[pt + 2] = u[2], ht[pt + 3] = 255;
          }
          for (const ht of this._figures)
            A(at, ht, X);
          return ct.putImageData(at, 2, 2), {
            canvas: st.canvas,
            offsetX: R - 2 * N,
            offsetY: I - 2 * P,
            scaleX: N,
            scaleY: P
          };
        }
        getPattern(o, u, m, g) {
          _(o, this._bbox);
          let c;
          if (g === v.SHADING)
            c = s.Util.singularValueDecompose2dScale((0, S.getCurrentTransform)(o));
          else if (c = s.Util.singularValueDecompose2dScale(u.baseTransform), this.matrix) {
            const R = s.Util.singularValueDecompose2dScale(this.matrix);
            c = [c[0] * R[0], c[1] * R[1]];
          }
          const b = this._createMeshCanvas(c, g === v.SHADING ? null : this._background, u.cachedCanvases);
          return g !== v.SHADING && (o.setTransform(...u.baseTransform), this.matrix && o.transform(...this.matrix)), o.translate(b.offsetX, b.offsetY), o.scale(b.scaleX, b.scaleY), o.createPattern(b.canvas, "no-repeat");
        }
      }
      class f extends x {
        getPattern() {
          return "hotpink";
        }
      }
      function p(y) {
        switch (y[0]) {
          case "RadialAxial":
            return new C(y);
          case "Mesh":
            return new n(y);
          case "Dummy":
            return new f();
        }
        throw new Error(`Unknown IR type: ${y[0]}`);
      }
      const F = {
        COLORED: 1,
        UNCOLORED: 2
      };
      class r {
        static MAX_PATTERN_SIZE = 3e3;
        constructor(o, u, m, g, c) {
          this.operatorList = o[2], this.matrix = o[3] || [1, 0, 0, 1, 0, 0], this.bbox = o[4], this.xstep = o[5], this.ystep = o[6], this.paintType = o[7], this.tilingType = o[8], this.color = u, this.ctx = m, this.canvasGraphicsFactory = g, this.baseTransform = c;
        }
        createPatternCanvas(o) {
          const u = this.operatorList, m = this.bbox, g = this.xstep, c = this.ystep, b = this.paintType, R = this.tilingType, I = this.color, O = this.canvasGraphicsFactory;
          (0, s.info)("TilingType: " + R);
          const H = m[0], $ = m[1], z = m[2], N = m[3], P = s.Util.singularValueDecompose2dScale(this.matrix), X = s.Util.singularValueDecompose2dScale(this.baseTransform), it = [P[0] * X[0], P[1] * X[1]], W = this.getSizeAndScale(g, this.ctx.canvas.width, it[0]), st = this.getSizeAndScale(c, this.ctx.canvas.height, it[1]), ct = o.cachedCanvases.getCanvas("pattern", W.size, st.size, !0), at = ct.context, nt = O.createCanvasGraphics(at);
          nt.groupLevel = o.groupLevel, this.setFillAndStrokeStyleToContext(nt, b, I);
          let ht = H, pt = $, vt = z, bt = N;
          return H < 0 && (ht = 0, vt += Math.abs(H)), $ < 0 && (pt = 0, bt += Math.abs($)), at.translate(-(W.scale * ht), -(st.scale * pt)), nt.transform(W.scale, 0, 0, st.scale, 0, 0), at.save(), this.clipBbox(nt, ht, pt, vt, bt), nt.baseTransform = (0, S.getCurrentTransform)(nt.ctx), nt.executeOperatorList(u), nt.endDrawing(), {
            canvas: ct.canvas,
            scaleX: W.scale,
            scaleY: st.scale,
            offsetX: ht,
            offsetY: pt
          };
        }
        getSizeAndScale(o, u, m) {
          o = Math.abs(o);
          const g = Math.max(r.MAX_PATTERN_SIZE, u);
          let c = Math.ceil(o * m);
          return c >= g ? c = g : m = c / o, {
            scale: m,
            size: c
          };
        }
        clipBbox(o, u, m, g, c) {
          const b = g - u, R = c - m;
          o.ctx.rect(u, m, b, R), o.current.updateRectMinMax((0, S.getCurrentTransform)(o.ctx), [u, m, g, c]), o.clip(), o.endPath();
        }
        setFillAndStrokeStyleToContext(o, u, m) {
          const g = o.ctx, c = o.current;
          switch (u) {
            case F.COLORED:
              const b = this.ctx;
              g.fillStyle = b.fillStyle, g.strokeStyle = b.strokeStyle, c.fillColor = b.fillStyle, c.strokeColor = b.strokeStyle;
              break;
            case F.UNCOLORED:
              const R = s.Util.makeHexColor(m[0], m[1], m[2]);
              g.fillStyle = R, g.strokeStyle = R, c.fillColor = R, c.strokeColor = R;
              break;
            default:
              throw new s.FormatError(`Unsupported paint type: ${u}`);
          }
        }
        getPattern(o, u, m, g) {
          let c = m;
          g !== v.SHADING && (c = s.Util.transform(c, u.baseTransform), this.matrix && (c = s.Util.transform(c, this.matrix)));
          const b = this.createPatternCanvas(u);
          let R = new DOMMatrix(c);
          R = R.translate(b.offsetX, b.offsetY), R = R.scale(1 / b.scaleX, 1 / b.scaleY);
          const I = o.createPattern(b.canvas, "repeat");
          return I.setTransform(R), I;
        }
      }
      function w({
        src: y,
        srcPos: o = 0,
        dest: u,
        width: m,
        height: g,
        nonBlackColor: c = 4294967295,
        inverseDecode: b = !1
      }) {
        const R = s.FeatureTest.isLittleEndian ? 4278190080 : 255, [I, O] = b ? [c, R] : [R, c], H = m >> 3, $ = m & 7, z = y.length;
        u = new Uint32Array(u.buffer);
        let N = 0;
        for (let P = 0; P < g; P++) {
          for (const it = o + H; o < it; o++) {
            const W = o < z ? y[o] : 255;
            u[N++] = W & 128 ? O : I, u[N++] = W & 64 ? O : I, u[N++] = W & 32 ? O : I, u[N++] = W & 16 ? O : I, u[N++] = W & 8 ? O : I, u[N++] = W & 4 ? O : I, u[N++] = W & 2 ? O : I, u[N++] = W & 1 ? O : I;
          }
          if ($ === 0)
            continue;
          const X = o < z ? y[o++] : 255;
          for (let it = 0; it < $; it++)
            u[N++] = X & 1 << 7 - it ? O : I;
        }
        return {
          srcPos: o,
          destPos: N
        };
      }
      const t = 16, i = 100, h = 4096, d = 15, E = 10, k = 1e3, L = 16;
      function M(y, o) {
        if (y._removeMirroring)
          throw new Error("Context is already forwarding operations.");
        y.__originalSave = y.save, y.__originalRestore = y.restore, y.__originalRotate = y.rotate, y.__originalScale = y.scale, y.__originalTranslate = y.translate, y.__originalTransform = y.transform, y.__originalSetTransform = y.setTransform, y.__originalResetTransform = y.resetTransform, y.__originalClip = y.clip, y.__originalMoveTo = y.moveTo, y.__originalLineTo = y.lineTo, y.__originalBezierCurveTo = y.bezierCurveTo, y.__originalRect = y.rect, y.__originalClosePath = y.closePath, y.__originalBeginPath = y.beginPath, y._removeMirroring = () => {
          y.save = y.__originalSave, y.restore = y.__originalRestore, y.rotate = y.__originalRotate, y.scale = y.__originalScale, y.translate = y.__originalTranslate, y.transform = y.__originalTransform, y.setTransform = y.__originalSetTransform, y.resetTransform = y.__originalResetTransform, y.clip = y.__originalClip, y.moveTo = y.__originalMoveTo, y.lineTo = y.__originalLineTo, y.bezierCurveTo = y.__originalBezierCurveTo, y.rect = y.__originalRect, y.closePath = y.__originalClosePath, y.beginPath = y.__originalBeginPath, delete y._removeMirroring;
        }, y.save = function() {
          o.save(), this.__originalSave();
        }, y.restore = function() {
          o.restore(), this.__originalRestore();
        }, y.translate = function(m, g) {
          o.translate(m, g), this.__originalTranslate(m, g);
        }, y.scale = function(m, g) {
          o.scale(m, g), this.__originalScale(m, g);
        }, y.transform = function(m, g, c, b, R, I) {
          o.transform(m, g, c, b, R, I), this.__originalTransform(m, g, c, b, R, I);
        }, y.setTransform = function(m, g, c, b, R, I) {
          o.setTransform(m, g, c, b, R, I), this.__originalSetTransform(m, g, c, b, R, I);
        }, y.resetTransform = function() {
          o.resetTransform(), this.__originalResetTransform();
        }, y.rotate = function(m) {
          o.rotate(m), this.__originalRotate(m);
        }, y.clip = function(m) {
          o.clip(m), this.__originalClip(m);
        }, y.moveTo = function(u, m) {
          o.moveTo(u, m), this.__originalMoveTo(u, m);
        }, y.lineTo = function(u, m) {
          o.lineTo(u, m), this.__originalLineTo(u, m);
        }, y.bezierCurveTo = function(u, m, g, c, b, R) {
          o.bezierCurveTo(u, m, g, c, b, R), this.__originalBezierCurveTo(u, m, g, c, b, R);
        }, y.rect = function(u, m, g, c) {
          o.rect(u, m, g, c), this.__originalRect(u, m, g, c);
        }, y.closePath = function() {
          o.closePath(), this.__originalClosePath();
        }, y.beginPath = function() {
          o.beginPath(), this.__originalBeginPath();
        };
      }
      class B {
        constructor(o) {
          this.canvasFactory = o, this.cache = /* @__PURE__ */ Object.create(null);
        }
        getCanvas(o, u, m) {
          let g;
          return this.cache[o] !== void 0 ? (g = this.cache[o], this.canvasFactory.reset(g, u, m)) : (g = this.canvasFactory.create(u, m), this.cache[o] = g), g;
        }
        delete(o) {
          delete this.cache[o];
        }
        clear() {
          for (const o in this.cache) {
            const u = this.cache[o];
            this.canvasFactory.destroy(u), delete this.cache[o];
          }
        }
      }
      function U(y, o, u, m, g, c, b, R, I, O) {
        const [H, $, z, N, P, X] = (0, S.getCurrentTransform)(y);
        if ($ === 0 && z === 0) {
          const st = b * H + P, ct = Math.round(st), at = R * N + X, nt = Math.round(at), ht = (b + I) * H + P, pt = Math.abs(Math.round(ht) - ct) || 1, vt = (R + O) * N + X, bt = Math.abs(Math.round(vt) - nt) || 1;
          return y.setTransform(Math.sign(H), 0, 0, Math.sign(N), ct, nt), y.drawImage(o, u, m, g, c, 0, 0, pt, bt), y.setTransform(H, $, z, N, P, X), [pt, bt];
        }
        if (H === 0 && N === 0) {
          const st = R * z + P, ct = Math.round(st), at = b * $ + X, nt = Math.round(at), ht = (R + O) * z + P, pt = Math.abs(Math.round(ht) - ct) || 1, vt = (b + I) * $ + X, bt = Math.abs(Math.round(vt) - nt) || 1;
          return y.setTransform(0, Math.sign($), Math.sign(z), 0, ct, nt), y.drawImage(o, u, m, g, c, 0, 0, bt, pt), y.setTransform(H, $, z, N, P, X), [bt, pt];
        }
        y.drawImage(o, u, m, g, c, b, R, I, O);
        const it = Math.hypot(H, $), W = Math.hypot(z, N);
        return [it * I, W * O];
      }
      function q(y) {
        const {
          width: o,
          height: u
        } = y;
        if (o > k || u > k)
          return null;
        const m = 1e3, g = new Uint8Array([0, 2, 4, 0, 1, 0, 5, 4, 8, 10, 0, 8, 0, 2, 1, 0]), c = o + 1;
        let b = new Uint8Array(c * (u + 1)), R, I, O;
        const H = o + 7 & -8;
        let $ = new Uint8Array(H * u), z = 0;
        for (const W of y.data) {
          let st = 128;
          for (; st > 0; )
            $[z++] = W & st ? 0 : 255, st >>= 1;
        }
        let N = 0;
        for (z = 0, $[z] !== 0 && (b[0] = 1, ++N), I = 1; I < o; I++)
          $[z] !== $[z + 1] && (b[I] = $[z] ? 2 : 1, ++N), z++;
        for ($[z] !== 0 && (b[I] = 2, ++N), R = 1; R < u; R++) {
          z = R * H, O = R * c, $[z - H] !== $[z] && (b[O] = $[z] ? 1 : 8, ++N);
          let W = ($[z] ? 4 : 0) + ($[z - H] ? 8 : 0);
          for (I = 1; I < o; I++)
            W = (W >> 2) + ($[z + 1] ? 4 : 0) + ($[z - H + 1] ? 8 : 0), g[W] && (b[O + I] = g[W], ++N), z++;
          if ($[z - H] !== $[z] && (b[O + I] = $[z] ? 2 : 4, ++N), N > m)
            return null;
        }
        for (z = H * (u - 1), O = R * c, $[z] !== 0 && (b[O] = 8, ++N), I = 1; I < o; I++)
          $[z] !== $[z + 1] && (b[O + I] = $[z] ? 4 : 8, ++N), z++;
        if ($[z] !== 0 && (b[O + I] = 4, ++N), N > m)
          return null;
        const P = new Int32Array([0, c, -1, 0, -c, 0, 0, 0, 1]), X = new Path2D();
        for (R = 0; N && R <= u; R++) {
          let W = R * c;
          const st = W + o;
          for (; W < st && !b[W]; )
            W++;
          if (W === st)
            continue;
          X.moveTo(W % c, R);
          const ct = W;
          let at = b[W];
          do {
            const nt = P[at];
            do
              W += nt;
            while (!b[W]);
            const ht = b[W];
            ht !== 5 && ht !== 10 ? (at = ht, b[W] = 0) : (at = ht & 51 * at >> 4, b[W] &= at >> 2 | at << 2), X.lineTo(W % c, W / c | 0), b[W] || --N;
          } while (ct !== W);
          --R;
        }
        return $ = null, b = null, function(W) {
          W.save(), W.scale(1 / o, -1 / u), W.translate(0, -u), W.fill(X), W.beginPath(), W.restore();
        };
      }
      class Z {
        constructor(o, u) {
          this.alphaIsShape = !1, this.fontSize = 0, this.fontSizeScale = 1, this.textMatrix = s.IDENTITY_MATRIX, this.textMatrixScale = 1, this.fontMatrix = s.FONT_IDENTITY_MATRIX, this.leading = 0, this.x = 0, this.y = 0, this.lineX = 0, this.lineY = 0, this.charSpacing = 0, this.wordSpacing = 0, this.textHScale = 1, this.textRenderingMode = s.TextRenderingMode.FILL, this.textRise = 0, this.fillColor = "#000000", this.strokeColor = "#000000", this.patternFill = !1, this.fillAlpha = 1, this.strokeAlpha = 1, this.lineWidth = 1, this.activeSMask = null, this.transferMaps = "none", this.startNewPathAndClipBox([0, 0, o, u]);
        }
        clone() {
          const o = Object.create(this);
          return o.clipBox = this.clipBox.slice(), o;
        }
        setCurrentPoint(o, u) {
          this.x = o, this.y = u;
        }
        updatePathMinMax(o, u, m) {
          [u, m] = s.Util.applyTransform([u, m], o), this.minX = Math.min(this.minX, u), this.minY = Math.min(this.minY, m), this.maxX = Math.max(this.maxX, u), this.maxY = Math.max(this.maxY, m);
        }
        updateRectMinMax(o, u) {
          const m = s.Util.applyTransform(u, o), g = s.Util.applyTransform(u.slice(2), o), c = s.Util.applyTransform([u[0], u[3]], o), b = s.Util.applyTransform([u[2], u[1]], o);
          this.minX = Math.min(this.minX, m[0], g[0], c[0], b[0]), this.minY = Math.min(this.minY, m[1], g[1], c[1], b[1]), this.maxX = Math.max(this.maxX, m[0], g[0], c[0], b[0]), this.maxY = Math.max(this.maxY, m[1], g[1], c[1], b[1]);
        }
        updateScalingPathMinMax(o, u) {
          s.Util.scaleMinMax(o, u), this.minX = Math.min(this.minX, u[0]), this.minY = Math.min(this.minY, u[1]), this.maxX = Math.max(this.maxX, u[2]), this.maxY = Math.max(this.maxY, u[3]);
        }
        updateCurvePathMinMax(o, u, m, g, c, b, R, I, O, H) {
          const $ = s.Util.bezierBoundingBox(u, m, g, c, b, R, I, O, H);
          H || this.updateRectMinMax(o, $);
        }
        getPathBoundingBox(o = v.FILL, u = null) {
          const m = [this.minX, this.minY, this.maxX, this.maxY];
          if (o === v.STROKE) {
            u || (0, s.unreachable)("Stroke bounding box must include transform.");
            const g = s.Util.singularValueDecompose2dScale(u), c = g[0] * this.lineWidth / 2, b = g[1] * this.lineWidth / 2;
            m[0] -= c, m[1] -= b, m[2] += c, m[3] += b;
          }
          return m;
        }
        updateClipFromPath() {
          const o = s.Util.intersect(this.clipBox, this.getPathBoundingBox());
          this.startNewPathAndClipBox(o || [0, 0, 0, 0]);
        }
        isEmptyClip() {
          return this.minX === 1 / 0;
        }
        startNewPathAndClipBox(o) {
          this.clipBox = o, this.minX = 1 / 0, this.minY = 1 / 0, this.maxX = 0, this.maxY = 0;
        }
        getClippedPathBoundingBox(o = v.FILL, u = null) {
          return s.Util.intersect(this.clipBox, this.getPathBoundingBox(o, u));
        }
      }
      function K(y, o) {
        if (typeof ImageData < "u" && o instanceof ImageData) {
          y.putImageData(o, 0, 0);
          return;
        }
        const u = o.height, m = o.width, g = u % L, c = (u - g) / L, b = g === 0 ? c : c + 1, R = y.createImageData(m, L);
        let I = 0, O;
        const H = o.data, $ = R.data;
        let z, N, P, X;
        if (o.kind === s.ImageKind.GRAYSCALE_1BPP) {
          const it = H.byteLength, W = new Uint32Array($.buffer, 0, $.byteLength >> 2), st = W.length, ct = m + 7 >> 3, at = 4294967295, nt = s.FeatureTest.isLittleEndian ? 4278190080 : 255;
          for (z = 0; z < b; z++) {
            for (P = z < c ? L : g, O = 0, N = 0; N < P; N++) {
              const ht = it - I;
              let pt = 0;
              const vt = ht > ct ? m : ht * 8 - 7, bt = vt & -8;
              let wt = 0, mt = 0;
              for (; pt < bt; pt += 8)
                mt = H[I++], W[O++] = mt & 128 ? at : nt, W[O++] = mt & 64 ? at : nt, W[O++] = mt & 32 ? at : nt, W[O++] = mt & 16 ? at : nt, W[O++] = mt & 8 ? at : nt, W[O++] = mt & 4 ? at : nt, W[O++] = mt & 2 ? at : nt, W[O++] = mt & 1 ? at : nt;
              for (; pt < vt; pt++)
                wt === 0 && (mt = H[I++], wt = 128), W[O++] = mt & wt ? at : nt, wt >>= 1;
            }
            for (; O < st; )
              W[O++] = 0;
            y.putImageData(R, 0, z * L);
          }
        } else if (o.kind === s.ImageKind.RGBA_32BPP) {
          for (N = 0, X = m * L * 4, z = 0; z < c; z++)
            $.set(H.subarray(I, I + X)), I += X, y.putImageData(R, 0, N), N += L;
          z < b && (X = m * g * 4, $.set(H.subarray(I, I + X)), y.putImageData(R, 0, N));
        } else if (o.kind === s.ImageKind.RGB_24BPP)
          for (P = L, X = m * P, z = 0; z < b; z++) {
            for (z >= c && (P = g, X = m * P), O = 0, N = X; N--; )
              $[O++] = H[I++], $[O++] = H[I++], $[O++] = H[I++], $[O++] = 255;
            y.putImageData(R, 0, z * L);
          }
        else
          throw new Error(`bad image kind: ${o.kind}`);
      }
      function Y(y, o) {
        if (o.bitmap) {
          y.drawImage(o.bitmap, 0, 0);
          return;
        }
        const u = o.height, m = o.width, g = u % L, c = (u - g) / L, b = g === 0 ? c : c + 1, R = y.createImageData(m, L);
        let I = 0;
        const O = o.data, H = R.data;
        for (let $ = 0; $ < b; $++) {
          const z = $ < c ? L : g;
          ({
            srcPos: I
          } = w({
            src: O,
            srcPos: I,
            dest: H,
            width: m,
            height: z,
            nonBlackColor: 0
          })), y.putImageData(R, 0, $ * L);
        }
      }
      function G(y, o) {
        const u = ["strokeStyle", "fillStyle", "fillRule", "globalAlpha", "lineWidth", "lineCap", "lineJoin", "miterLimit", "globalCompositeOperation", "font", "filter"];
        for (const m of u)
          y[m] !== void 0 && (o[m] = y[m]);
        y.setLineDash !== void 0 && (o.setLineDash(y.getLineDash()), o.lineDashOffset = y.lineDashOffset);
      }
      function j(y) {
        if (y.strokeStyle = y.fillStyle = "#000000", y.fillRule = "nonzero", y.globalAlpha = 1, y.lineWidth = 1, y.lineCap = "butt", y.lineJoin = "miter", y.miterLimit = 10, y.globalCompositeOperation = "source-over", y.font = "10px sans-serif", y.setLineDash !== void 0 && (y.setLineDash([]), y.lineDashOffset = 0), !s.isNodeJS) {
          const {
            filter: o
          } = y;
          o !== "none" && o !== "" && (y.filter = "none");
        }
      }
      function Q(y, o, u, m) {
        const g = y.length;
        for (let c = 3; c < g; c += 4) {
          const b = y[c];
          if (b === 0)
            y[c - 3] = o, y[c - 2] = u, y[c - 1] = m;
          else if (b < 255) {
            const R = 255 - b;
            y[c - 3] = y[c - 3] * b + o * R >> 8, y[c - 2] = y[c - 2] * b + u * R >> 8, y[c - 1] = y[c - 1] * b + m * R >> 8;
          }
        }
      }
      function J(y, o, u) {
        const m = y.length, g = 1 / 255;
        for (let c = 3; c < m; c += 4) {
          const b = u ? u[y[c]] : y[c];
          o[c] = o[c] * b * g | 0;
        }
      }
      function tt(y, o, u) {
        const m = y.length;
        for (let g = 3; g < m; g += 4) {
          const c = y[g - 3] * 77 + y[g - 2] * 152 + y[g - 1] * 28;
          o[g] = u ? o[g] * u[c >> 8] >> 8 : o[g] * c >> 16;
        }
      }
      function rt(y, o, u, m, g, c, b, R, I, O, H) {
        const $ = !!c, z = $ ? c[0] : 0, N = $ ? c[1] : 0, P = $ ? c[2] : 0, X = g === "Luminosity" ? tt : J, W = Math.min(m, Math.ceil(1048576 / u));
        for (let st = 0; st < m; st += W) {
          const ct = Math.min(W, m - st), at = y.getImageData(R - O, st + (I - H), u, ct), nt = o.getImageData(R, st + I, u, ct);
          $ && Q(at.data, z, N, P), X(at.data, nt.data, b), o.putImageData(nt, R, st + I);
        }
      }
      function ut(y, o, u, m) {
        const g = m[0], c = m[1], b = m[2] - g, R = m[3] - c;
        b === 0 || R === 0 || (rt(o.context, u, b, R, o.subtype, o.backdrop, o.transferMap, g, c, o.offsetX, o.offsetY), y.save(), y.globalAlpha = 1, y.globalCompositeOperation = "source-over", y.setTransform(1, 0, 0, 1, 0, 0), y.drawImage(u.canvas, 0, 0), y.restore());
      }
      function dt(y, o) {
        if (o)
          return !0;
        const u = s.Util.singularValueDecompose2dScale(y);
        u[0] = Math.fround(u[0]), u[1] = Math.fround(u[1]);
        const m = Math.fround((globalThis.devicePixelRatio || 1) * S.PixelsPerInch.PDF_TO_CSS_UNITS);
        return u[0] <= m && u[1] <= m;
      }
      const ft = ["butt", "round", "square"], lt = ["miter", "round", "bevel"], ot = {}, et = {};
      class D {
        constructor(o, u, m, g, c, {
          optionalContentConfig: b,
          markedContentStack: R = null
        }, I, O) {
          this.ctx = o, this.current = new Z(this.ctx.canvas.width, this.ctx.canvas.height), this.stateStack = [], this.pendingClip = null, this.pendingEOFill = !1, this.res = null, this.xobjs = null, this.commonObjs = u, this.objs = m, this.canvasFactory = g, this.filterFactory = c, this.groupStack = [], this.processingType3 = null, this.baseTransform = null, this.baseTransformStack = [], this.groupLevel = 0, this.smaskStack = [], this.smaskCounter = 0, this.tempSMask = null, this.suspendedCtx = null, this.contentVisible = !0, this.markedContentStack = R || [], this.optionalContentConfig = b, this.cachedCanvases = new B(this.canvasFactory), this.cachedPatterns = /* @__PURE__ */ new Map(), this.annotationCanvasMap = I, this.viewportScale = 1, this.outputScaleX = 1, this.outputScaleY = 1, this.pageColors = O, this._cachedScaleForStroking = [-1, 0], this._cachedGetSinglePixelWidth = null, this._cachedBitmapsMap = /* @__PURE__ */ new Map();
        }
        getObject(o, u = null) {
          return typeof o == "string" ? o.startsWith("g_") ? this.commonObjs.get(o) : this.objs.get(o) : u;
        }
        beginDrawing({
          transform: o,
          viewport: u,
          transparency: m = !1,
          background: g = null
        }) {
          const c = this.ctx.canvas.width, b = this.ctx.canvas.height, R = this.ctx.fillStyle;
          if (this.ctx.fillStyle = g || "#ffffff", this.ctx.fillRect(0, 0, c, b), this.ctx.fillStyle = R, m) {
            const I = this.cachedCanvases.getCanvas("transparent", c, b);
            this.compositeCtx = this.ctx, this.transparentCanvas = I.canvas, this.ctx = I.context, this.ctx.save(), this.ctx.transform(...(0, S.getCurrentTransform)(this.compositeCtx));
          }
          this.ctx.save(), j(this.ctx), o && (this.ctx.transform(...o), this.outputScaleX = o[0], this.outputScaleY = o[0]), this.ctx.transform(...u.transform), this.viewportScale = u.scale, this.baseTransform = (0, S.getCurrentTransform)(this.ctx);
        }
        executeOperatorList(o, u, m, g) {
          const c = o.argsArray, b = o.fnArray;
          let R = u || 0;
          const I = c.length;
          if (I === R)
            return R;
          const O = I - R > E && typeof m == "function", H = O ? Date.now() + d : 0;
          let $ = 0;
          const z = this.commonObjs, N = this.objs;
          let P;
          for (; ; ) {
            if (g !== void 0 && R === g.nextBreakPoint)
              return g.breakIt(R, m), R;
            if (P = b[R], P !== s.OPS.dependency)
              this[P].apply(this, c[R]);
            else
              for (const X of c[R]) {
                const it = X.startsWith("g_") ? z : N;
                if (!it.has(X))
                  return it.get(X, m), R;
              }
            if (R++, R === I)
              return R;
            if (O && ++$ > E) {
              if (Date.now() > H)
                return m(), R;
              $ = 0;
            }
          }
        }
        #t() {
          for (; this.stateStack.length || this.inSMaskMode; )
            this.restore();
          this.ctx.restore(), this.transparentCanvas && (this.ctx = this.compositeCtx, this.ctx.save(), this.ctx.setTransform(1, 0, 0, 1, 0, 0), this.ctx.drawImage(this.transparentCanvas, 0, 0), this.ctx.restore(), this.transparentCanvas = null);
        }
        endDrawing() {
          this.#t(), this.cachedCanvases.clear(), this.cachedPatterns.clear();
          for (const o of this._cachedBitmapsMap.values()) {
            for (const u of o.values())
              typeof HTMLCanvasElement < "u" && u instanceof HTMLCanvasElement && (u.width = u.height = 0);
            o.clear();
          }
          this._cachedBitmapsMap.clear(), this.#e();
        }
        #e() {
          if (this.pageColors) {
            const o = this.filterFactory.addHCMFilter(this.pageColors.foreground, this.pageColors.background);
            if (o !== "none") {
              const u = this.ctx.filter;
              this.ctx.filter = o, this.ctx.drawImage(this.ctx.canvas, 0, 0), this.ctx.filter = u;
            }
          }
        }
        _scaleImage(o, u) {
          const m = o.width, g = o.height;
          let c = Math.max(Math.hypot(u[0], u[1]), 1), b = Math.max(Math.hypot(u[2], u[3]), 1), R = m, I = g, O = "prescale1", H, $;
          for (; c > 2 && R > 1 || b > 2 && I > 1; ) {
            let z = R, N = I;
            c > 2 && R > 1 && (z = R >= 16384 ? Math.floor(R / 2) - 1 || 1 : Math.ceil(R / 2), c /= R / z), b > 2 && I > 1 && (N = I >= 16384 ? Math.floor(I / 2) - 1 || 1 : Math.ceil(I) / 2, b /= I / N), H = this.cachedCanvases.getCanvas(O, z, N), $ = H.context, $.clearRect(0, 0, z, N), $.drawImage(o, 0, 0, R, I, 0, 0, z, N), o = H.canvas, R = z, I = N, O = O === "prescale1" ? "prescale2" : "prescale1";
          }
          return {
            img: o,
            paintWidth: R,
            paintHeight: I
          };
        }
        _createMaskCanvas(o) {
          const u = this.ctx, {
            width: m,
            height: g
          } = o, c = this.current.fillColor, b = this.current.patternFill, R = (0, S.getCurrentTransform)(u);
          let I, O, H, $;
          if ((o.bitmap || o.data) && o.count > 1) {
            const vt = o.bitmap || o.data.buffer;
            O = JSON.stringify(b ? R : [R.slice(0, 4), c]), I = this._cachedBitmapsMap.get(vt), I || (I = /* @__PURE__ */ new Map(), this._cachedBitmapsMap.set(vt, I));
            const bt = I.get(O);
            if (bt && !b) {
              const wt = Math.round(Math.min(R[0], R[2]) + R[4]), mt = Math.round(Math.min(R[1], R[3]) + R[5]);
              return {
                canvas: bt,
                offsetX: wt,
                offsetY: mt
              };
            }
            H = bt;
          }
          H || ($ = this.cachedCanvases.getCanvas("maskCanvas", m, g), Y($.context, o));
          let z = s.Util.transform(R, [1 / m, 0, 0, -1 / g, 0, 0]);
          z = s.Util.transform(z, [1, 0, 0, 1, 0, -g]);
          const [N, P, X, it] = s.Util.getAxialAlignedBoundingBox([0, 0, m, g], z), W = Math.round(X - N) || 1, st = Math.round(it - P) || 1, ct = this.cachedCanvases.getCanvas("fillCanvas", W, st), at = ct.context, nt = N, ht = P;
          at.translate(-nt, -ht), at.transform(...z), H || (H = this._scaleImage($.canvas, (0, S.getCurrentTransformInverse)(at)), H = H.img, I && b && I.set(O, H)), at.imageSmoothingEnabled = dt((0, S.getCurrentTransform)(at), o.interpolate), U(at, H, 0, 0, H.width, H.height, 0, 0, m, g), at.globalCompositeOperation = "source-in";
          const pt = s.Util.transform((0, S.getCurrentTransformInverse)(at), [1, 0, 0, 1, -nt, -ht]);
          return at.fillStyle = b ? c.getPattern(u, this, pt, v.FILL) : c, at.fillRect(0, 0, m, g), I && !b && (this.cachedCanvases.delete("fillCanvas"), I.set(O, ct.canvas)), {
            canvas: ct.canvas,
            offsetX: Math.round(nt),
            offsetY: Math.round(ht)
          };
        }
        setLineWidth(o) {
          o !== this.current.lineWidth && (this._cachedScaleForStroking[0] = -1), this.current.lineWidth = o, this.ctx.lineWidth = o;
        }
        setLineCap(o) {
          this.ctx.lineCap = ft[o];
        }
        setLineJoin(o) {
          this.ctx.lineJoin = lt[o];
        }
        setMiterLimit(o) {
          this.ctx.miterLimit = o;
        }
        setDash(o, u) {
          const m = this.ctx;
          m.setLineDash !== void 0 && (m.setLineDash(o), m.lineDashOffset = u);
        }
        setRenderingIntent(o) {
        }
        setFlatness(o) {
        }
        setGState(o) {
          for (const [u, m] of o)
            switch (u) {
              case "LW":
                this.setLineWidth(m);
                break;
              case "LC":
                this.setLineCap(m);
                break;
              case "LJ":
                this.setLineJoin(m);
                break;
              case "ML":
                this.setMiterLimit(m);
                break;
              case "D":
                this.setDash(m[0], m[1]);
                break;
              case "RI":
                this.setRenderingIntent(m);
                break;
              case "FL":
                this.setFlatness(m);
                break;
              case "Font":
                this.setFont(m[0], m[1]);
                break;
              case "CA":
                this.current.strokeAlpha = m;
                break;
              case "ca":
                this.current.fillAlpha = m, this.ctx.globalAlpha = m;
                break;
              case "BM":
                this.ctx.globalCompositeOperation = m;
                break;
              case "SMask":
                this.current.activeSMask = m ? this.tempSMask : null, this.tempSMask = null, this.checkSMaskState();
                break;
              case "TR":
                this.ctx.filter = this.current.transferMaps = this.filterFactory.addFilter(m);
                break;
            }
        }
        get inSMaskMode() {
          return !!this.suspendedCtx;
        }
        checkSMaskState() {
          const o = this.inSMaskMode;
          this.current.activeSMask && !o ? this.beginSMaskMode() : !this.current.activeSMask && o && this.endSMaskMode();
        }
        beginSMaskMode() {
          if (this.inSMaskMode)
            throw new Error("beginSMaskMode called while already in smask mode");
          const o = this.ctx.canvas.width, u = this.ctx.canvas.height, m = "smaskGroupAt" + this.groupLevel, g = this.cachedCanvases.getCanvas(m, o, u);
          this.suspendedCtx = this.ctx, this.ctx = g.context;
          const c = this.ctx;
          c.setTransform(...(0, S.getCurrentTransform)(this.suspendedCtx)), G(this.suspendedCtx, c), M(c, this.suspendedCtx), this.setGState([["BM", "source-over"], ["ca", 1], ["CA", 1]]);
        }
        endSMaskMode() {
          if (!this.inSMaskMode)
            throw new Error("endSMaskMode called while not in smask mode");
          this.ctx._removeMirroring(), G(this.ctx, this.suspendedCtx), this.ctx = this.suspendedCtx, this.suspendedCtx = null;
        }
        compose(o) {
          if (!this.current.activeSMask)
            return;
          o ? (o[0] = Math.floor(o[0]), o[1] = Math.floor(o[1]), o[2] = Math.ceil(o[2]), o[3] = Math.ceil(o[3])) : o = [0, 0, this.ctx.canvas.width, this.ctx.canvas.height];
          const u = this.current.activeSMask, m = this.suspendedCtx;
          ut(m, u, this.ctx, o), this.ctx.save(), this.ctx.setTransform(1, 0, 0, 1, 0, 0), this.ctx.clearRect(0, 0, this.ctx.canvas.width, this.ctx.canvas.height), this.ctx.restore();
        }
        save() {
          this.inSMaskMode ? (G(this.ctx, this.suspendedCtx), this.suspendedCtx.save()) : this.ctx.save();
          const o = this.current;
          this.stateStack.push(o), this.current = o.clone();
        }
        restore() {
          this.stateStack.length === 0 && this.inSMaskMode && this.endSMaskMode(), this.stateStack.length !== 0 && (this.current = this.stateStack.pop(), this.inSMaskMode ? (this.suspendedCtx.restore(), G(this.suspendedCtx, this.ctx)) : this.ctx.restore(), this.checkSMaskState(), this.pendingClip = null, this._cachedScaleForStroking[0] = -1, this._cachedGetSinglePixelWidth = null);
        }
        transform(o, u, m, g, c, b) {
          this.ctx.transform(o, u, m, g, c, b), this._cachedScaleForStroking[0] = -1, this._cachedGetSinglePixelWidth = null;
        }
        constructPath(o, u, m) {
          const g = this.ctx, c = this.current;
          let b = c.x, R = c.y, I, O;
          const H = (0, S.getCurrentTransform)(g), $ = H[0] === 0 && H[3] === 0 || H[1] === 0 && H[2] === 0, z = $ ? m.slice(0) : null;
          for (let N = 0, P = 0, X = o.length; N < X; N++)
            switch (o[N] | 0) {
              case s.OPS.rectangle:
                b = u[P++], R = u[P++];
                const it = u[P++], W = u[P++], st = b + it, ct = R + W;
                g.moveTo(b, R), it === 0 || W === 0 ? g.lineTo(st, ct) : (g.lineTo(st, R), g.lineTo(st, ct), g.lineTo(b, ct)), $ || c.updateRectMinMax(H, [b, R, st, ct]), g.closePath();
                break;
              case s.OPS.moveTo:
                b = u[P++], R = u[P++], g.moveTo(b, R), $ || c.updatePathMinMax(H, b, R);
                break;
              case s.OPS.lineTo:
                b = u[P++], R = u[P++], g.lineTo(b, R), $ || c.updatePathMinMax(H, b, R);
                break;
              case s.OPS.curveTo:
                I = b, O = R, b = u[P + 4], R = u[P + 5], g.bezierCurveTo(u[P], u[P + 1], u[P + 2], u[P + 3], b, R), c.updateCurvePathMinMax(H, I, O, u[P], u[P + 1], u[P + 2], u[P + 3], b, R, z), P += 6;
                break;
              case s.OPS.curveTo2:
                I = b, O = R, g.bezierCurveTo(b, R, u[P], u[P + 1], u[P + 2], u[P + 3]), c.updateCurvePathMinMax(H, I, O, b, R, u[P], u[P + 1], u[P + 2], u[P + 3], z), b = u[P + 2], R = u[P + 3], P += 4;
                break;
              case s.OPS.curveTo3:
                I = b, O = R, b = u[P + 2], R = u[P + 3], g.bezierCurveTo(u[P], u[P + 1], b, R, b, R), c.updateCurvePathMinMax(H, I, O, u[P], u[P + 1], b, R, b, R, z), P += 4;
                break;
              case s.OPS.closePath:
                g.closePath();
                break;
            }
          $ && c.updateScalingPathMinMax(H, z), c.setCurrentPoint(b, R);
        }
        closePath() {
          this.ctx.closePath();
        }
        stroke(o = !0) {
          const u = this.ctx, m = this.current.strokeColor;
          u.globalAlpha = this.current.strokeAlpha, this.contentVisible && (typeof m == "object" && m?.getPattern ? (u.save(), u.strokeStyle = m.getPattern(u, this, (0, S.getCurrentTransformInverse)(u), v.STROKE), this.rescaleAndStroke(!1), u.restore()) : this.rescaleAndStroke(!0)), o && this.consumePath(this.current.getClippedPathBoundingBox()), u.globalAlpha = this.current.fillAlpha;
        }
        closeStroke() {
          this.closePath(), this.stroke();
        }
        fill(o = !0) {
          const u = this.ctx, m = this.current.fillColor, g = this.current.patternFill;
          let c = !1;
          g && (u.save(), u.fillStyle = m.getPattern(u, this, (0, S.getCurrentTransformInverse)(u), v.FILL), c = !0);
          const b = this.current.getClippedPathBoundingBox();
          this.contentVisible && b !== null && (this.pendingEOFill ? (u.fill("evenodd"), this.pendingEOFill = !1) : u.fill()), c && u.restore(), o && this.consumePath(b);
        }
        eoFill() {
          this.pendingEOFill = !0, this.fill();
        }
        fillStroke() {
          this.fill(!1), this.stroke(!1), this.consumePath();
        }
        eoFillStroke() {
          this.pendingEOFill = !0, this.fillStroke();
        }
        closeFillStroke() {
          this.closePath(), this.fillStroke();
        }
        closeEOFillStroke() {
          this.pendingEOFill = !0, this.closePath(), this.fillStroke();
        }
        endPath() {
          this.consumePath();
        }
        clip() {
          this.pendingClip = ot;
        }
        eoClip() {
          this.pendingClip = et;
        }
        beginText() {
          this.current.textMatrix = s.IDENTITY_MATRIX, this.current.textMatrixScale = 1, this.current.x = this.current.lineX = 0, this.current.y = this.current.lineY = 0;
        }
        endText() {
          const o = this.pendingTextPaths, u = this.ctx;
          if (o === void 0) {
            u.beginPath();
            return;
          }
          u.save(), u.beginPath();
          for (const m of o)
            u.setTransform(...m.transform), u.translate(m.x, m.y), m.addToPath(u, m.fontSize);
          u.restore(), u.clip(), u.beginPath(), delete this.pendingTextPaths;
        }
        setCharSpacing(o) {
          this.current.charSpacing = o;
        }
        setWordSpacing(o) {
          this.current.wordSpacing = o;
        }
        setHScale(o) {
          this.current.textHScale = o / 100;
        }
        setLeading(o) {
          this.current.leading = -o;
        }
        setFont(o, u) {
          const m = this.commonObjs.get(o), g = this.current;
          if (!m)
            throw new Error(`Can't find font for ${o}`);
          if (g.fontMatrix = m.fontMatrix || s.FONT_IDENTITY_MATRIX, (g.fontMatrix[0] === 0 || g.fontMatrix[3] === 0) && (0, s.warn)("Invalid font matrix for font " + o), u < 0 ? (u = -u, g.fontDirection = -1) : g.fontDirection = 1, this.current.font = m, this.current.fontSize = u, m.isType3Font)
            return;
          const c = m.loadedName || "sans-serif", b = m.systemFontInfo?.css || `"${c}", ${m.fallbackName}`;
          let R = "normal";
          m.black ? R = "900" : m.bold && (R = "bold");
          const I = m.italic ? "italic" : "normal";
          let O = u;
          u < t ? O = t : u > i && (O = i), this.current.fontSizeScale = u / O, this.ctx.font = `${I} ${R} ${O}px ${b}`;
        }
        setTextRenderingMode(o) {
          this.current.textRenderingMode = o;
        }
        setTextRise(o) {
          this.current.textRise = o;
        }
        moveText(o, u) {
          this.current.x = this.current.lineX += o, this.current.y = this.current.lineY += u;
        }
        setLeadingMoveText(o, u) {
          this.setLeading(-u), this.moveText(o, u);
        }
        setTextMatrix(o, u, m, g, c, b) {
          this.current.textMatrix = [o, u, m, g, c, b], this.current.textMatrixScale = Math.hypot(o, u), this.current.x = this.current.lineX = 0, this.current.y = this.current.lineY = 0;
        }
        nextLine() {
          this.moveText(0, this.current.leading);
        }
        paintChar(o, u, m, g) {
          const c = this.ctx, b = this.current, R = b.font, I = b.textRenderingMode, O = b.fontSize / b.fontSizeScale, H = I & s.TextRenderingMode.FILL_STROKE_MASK, $ = !!(I & s.TextRenderingMode.ADD_TO_PATH_FLAG), z = b.patternFill && !R.missingFile;
          let N;
          (R.disableFontFace || $ || z) && (N = R.getPathGenerator(this.commonObjs, o)), R.disableFontFace || z ? (c.save(), c.translate(u, m), c.beginPath(), N(c, O), g && c.setTransform(...g), (H === s.TextRenderingMode.FILL || H === s.TextRenderingMode.FILL_STROKE) && c.fill(), (H === s.TextRenderingMode.STROKE || H === s.TextRenderingMode.FILL_STROKE) && c.stroke(), c.restore()) : ((H === s.TextRenderingMode.FILL || H === s.TextRenderingMode.FILL_STROKE) && c.fillText(o, u, m), (H === s.TextRenderingMode.STROKE || H === s.TextRenderingMode.FILL_STROKE) && c.strokeText(o, u, m)), $ && (this.pendingTextPaths ||= []).push({
            transform: (0, S.getCurrentTransform)(c),
            x: u,
            y: m,
            fontSize: O,
            addToPath: N
          });
        }
        get isFontSubpixelAAEnabled() {
          const {
            context: o
          } = this.cachedCanvases.getCanvas("isFontSubpixelAAEnabled", 10, 10);
          o.scale(1.5, 1), o.fillText("I", 0, 10);
          const u = o.getImageData(0, 0, 10, 10).data;
          let m = !1;
          for (let g = 3; g < u.length; g += 4)
            if (u[g] > 0 && u[g] < 255) {
              m = !0;
              break;
            }
          return (0, s.shadow)(this, "isFontSubpixelAAEnabled", m);
        }
        showText(o) {
          const u = this.current, m = u.font;
          if (m.isType3Font)
            return this.showType3Text(o);
          const g = u.fontSize;
          if (g === 0)
            return;
          const c = this.ctx, b = u.fontSizeScale, R = u.charSpacing, I = u.wordSpacing, O = u.fontDirection, H = u.textHScale * O, $ = o.length, z = m.vertical, N = z ? 1 : -1, P = m.defaultVMetrics, X = g * u.fontMatrix[0], it = u.textRenderingMode === s.TextRenderingMode.FILL && !m.disableFontFace && !u.patternFill;
          c.save(), c.transform(...u.textMatrix), c.translate(u.x, u.y + u.textRise), O > 0 ? c.scale(H, -1) : c.scale(H, 1);
          let W;
          if (u.patternFill) {
            c.save();
            const ht = u.fillColor.getPattern(c, this, (0, S.getCurrentTransformInverse)(c), v.FILL);
            W = (0, S.getCurrentTransform)(c), c.restore(), c.fillStyle = ht;
          }
          let st = u.lineWidth;
          const ct = u.textMatrixScale;
          if (ct === 0 || st === 0) {
            const ht = u.textRenderingMode & s.TextRenderingMode.FILL_STROKE_MASK;
            (ht === s.TextRenderingMode.STROKE || ht === s.TextRenderingMode.FILL_STROKE) && (st = this.getSinglePixelWidth());
          } else
            st /= ct;
          if (b !== 1 && (c.scale(b, b), st /= b), c.lineWidth = st, m.isInvalidPDFjsFont) {
            const ht = [];
            let pt = 0;
            for (const vt of o)
              ht.push(vt.unicode), pt += vt.width;
            c.fillText(ht.join(""), 0, 0), u.x += pt * X * H, c.restore(), this.compose();
            return;
          }
          let at = 0, nt;
          for (nt = 0; nt < $; ++nt) {
            const ht = o[nt];
            if (typeof ht == "number") {
              at += N * ht * g / 1e3;
              continue;
            }
            let pt = !1;
            const vt = (ht.isSpace ? I : 0) + R, bt = ht.fontChar, wt = ht.accent;
            let mt, St, Et = ht.width;
            if (z) {
              const xt = ht.vmetric || P, Tt = -(ht.vmetric ? xt[1] : Et * 0.5) * X, It = xt[2] * X;
              Et = xt ? -xt[0] : Et, mt = Tt / b, St = (at + It) / b;
            } else
              mt = at / b, St = 0;
            if (m.remeasure && Et > 0) {
              const xt = c.measureText(bt).width * 1e3 / g * b;
              if (Et < xt && this.isFontSubpixelAAEnabled) {
                const Tt = Et / xt;
                pt = !0, c.save(), c.scale(Tt, 1), mt /= Tt;
              } else Et !== xt && (mt += (Et - xt) / 2e3 * g / b);
            }
            if (this.contentVisible && (ht.isInFont || m.missingFile)) {
              if (it && !wt)
                c.fillText(bt, mt, St);
              else if (this.paintChar(bt, mt, St, W), wt) {
                const xt = mt + g * wt.offset.x / b, Tt = St - g * wt.offset.y / b;
                this.paintChar(wt.fontChar, xt, Tt, W);
              }
            }
            const Ft = z ? Et * X - vt * O : Et * X + vt * O;
            at += Ft, pt && c.restore();
          }
          z ? u.y -= at : u.x += at * H, c.restore(), this.compose();
        }
        showType3Text(o) {
          const u = this.ctx, m = this.current, g = m.font, c = m.fontSize, b = m.fontDirection, R = g.vertical ? 1 : -1, I = m.charSpacing, O = m.wordSpacing, H = m.textHScale * b, $ = m.fontMatrix || s.FONT_IDENTITY_MATRIX, z = o.length, N = m.textRenderingMode === s.TextRenderingMode.INVISIBLE;
          let P, X, it, W;
          if (!(N || c === 0)) {
            for (this._cachedScaleForStroking[0] = -1, this._cachedGetSinglePixelWidth = null, u.save(), u.transform(...m.textMatrix), u.translate(m.x, m.y), u.scale(H, b), P = 0; P < z; ++P) {
              if (X = o[P], typeof X == "number") {
                W = R * X * c / 1e3, this.ctx.translate(W, 0), m.x += W * H;
                continue;
              }
              const st = (X.isSpace ? O : 0) + I, ct = g.charProcOperatorList[X.operatorListId];
              if (!ct) {
                (0, s.warn)(`Type3 character "${X.operatorListId}" is not available.`);
                continue;
              }
              this.contentVisible && (this.processingType3 = X, this.save(), u.scale(c, c), u.transform(...$), this.executeOperatorList(ct), this.restore()), it = s.Util.applyTransform([X.width, 0], $)[0] * c + st, u.translate(it, 0), m.x += it * H;
            }
            u.restore(), this.processingType3 = null;
          }
        }
        setCharWidth(o, u) {
        }
        setCharWidthAndBounds(o, u, m, g, c, b) {
          this.ctx.rect(m, g, c - m, b - g), this.ctx.clip(), this.endPath();
        }
        getColorN_Pattern(o) {
          let u;
          if (o[0] === "TilingPattern") {
            const m = o[1], g = this.baseTransform || (0, S.getCurrentTransform)(this.ctx), c = {
              createCanvasGraphics: (b) => new D(b, this.commonObjs, this.objs, this.canvasFactory, this.filterFactory, {
                optionalContentConfig: this.optionalContentConfig,
                markedContentStack: this.markedContentStack
              })
            };
            u = new r(o, m, this.ctx, c, g);
          } else
            u = this._getPattern(o[1], o[2]);
          return u;
        }
        setStrokeColorN() {
          this.current.strokeColor = this.getColorN_Pattern(arguments);
        }
        setFillColorN() {
          this.current.fillColor = this.getColorN_Pattern(arguments), this.current.patternFill = !0;
        }
        setStrokeRGBColor(o, u, m) {
          const g = s.Util.makeHexColor(o, u, m);
          this.ctx.strokeStyle = g, this.current.strokeColor = g;
        }
        setFillRGBColor(o, u, m) {
          const g = s.Util.makeHexColor(o, u, m);
          this.ctx.fillStyle = g, this.current.fillColor = g, this.current.patternFill = !1;
        }
        _getPattern(o, u = null) {
          let m;
          return this.cachedPatterns.has(o) ? m = this.cachedPatterns.get(o) : (m = p(this.getObject(o)), this.cachedPatterns.set(o, m)), u && (m.matrix = u), m;
        }
        shadingFill(o) {
          if (!this.contentVisible)
            return;
          const u = this.ctx;
          this.save();
          const m = this._getPattern(o);
          u.fillStyle = m.getPattern(u, this, (0, S.getCurrentTransformInverse)(u), v.SHADING);
          const g = (0, S.getCurrentTransformInverse)(u);
          if (g) {
            const {
              width: c,
              height: b
            } = u.canvas, [R, I, O, H] = s.Util.getAxialAlignedBoundingBox([0, 0, c, b], g);
            this.ctx.fillRect(R, I, O - R, H - I);
          } else
            this.ctx.fillRect(-1e10, -1e10, 2e10, 2e10);
          this.compose(this.current.getClippedPathBoundingBox()), this.restore();
        }
        beginInlineImage() {
          (0, s.unreachable)("Should not call beginInlineImage");
        }
        beginImageData() {
          (0, s.unreachable)("Should not call beginImageData");
        }
        paintFormXObjectBegin(o, u) {
          if (this.contentVisible && (this.save(), this.baseTransformStack.push(this.baseTransform), Array.isArray(o) && o.length === 6 && this.transform(...o), this.baseTransform = (0, S.getCurrentTransform)(this.ctx), u)) {
            const m = u[2] - u[0], g = u[3] - u[1];
            this.ctx.rect(u[0], u[1], m, g), this.current.updateRectMinMax((0, S.getCurrentTransform)(this.ctx), u), this.clip(), this.endPath();
          }
        }
        paintFormXObjectEnd() {
          this.contentVisible && (this.restore(), this.baseTransform = this.baseTransformStack.pop());
        }
        beginGroup(o) {
          if (!this.contentVisible)
            return;
          this.save(), this.inSMaskMode && (this.endSMaskMode(), this.current.activeSMask = null);
          const u = this.ctx;
          o.isolated || (0, s.info)("TODO: Support non-isolated groups."), o.knockout && (0, s.warn)("Knockout groups not supported.");
          const m = (0, S.getCurrentTransform)(u);
          if (o.matrix && u.transform(...o.matrix), !o.bbox)
            throw new Error("Bounding box is required.");
          let g = s.Util.getAxialAlignedBoundingBox(o.bbox, (0, S.getCurrentTransform)(u));
          const c = [0, 0, u.canvas.width, u.canvas.height];
          g = s.Util.intersect(g, c) || [0, 0, 0, 0];
          const b = Math.floor(g[0]), R = Math.floor(g[1]);
          let I = Math.max(Math.ceil(g[2]) - b, 1), O = Math.max(Math.ceil(g[3]) - R, 1), H = 1, $ = 1;
          I > h && (H = I / h, I = h), O > h && ($ = O / h, O = h), this.current.startNewPathAndClipBox([0, 0, I, O]);
          let z = "groupAt" + this.groupLevel;
          o.smask && (z += "_smask_" + this.smaskCounter++ % 2);
          const N = this.cachedCanvases.getCanvas(z, I, O), P = N.context;
          P.scale(1 / H, 1 / $), P.translate(-b, -R), P.transform(...m), o.smask ? this.smaskStack.push({
            canvas: N.canvas,
            context: P,
            offsetX: b,
            offsetY: R,
            scaleX: H,
            scaleY: $,
            subtype: o.smask.subtype,
            backdrop: o.smask.backdrop,
            transferMap: o.smask.transferMap || null,
            startTransformInverse: null
          }) : (u.setTransform(1, 0, 0, 1, 0, 0), u.translate(b, R), u.scale(H, $), u.save()), G(u, P), this.ctx = P, this.setGState([["BM", "source-over"], ["ca", 1], ["CA", 1]]), this.groupStack.push(u), this.groupLevel++;
        }
        endGroup(o) {
          if (!this.contentVisible)
            return;
          this.groupLevel--;
          const u = this.ctx, m = this.groupStack.pop();
          if (this.ctx = m, this.ctx.imageSmoothingEnabled = !1, o.smask)
            this.tempSMask = this.smaskStack.pop(), this.restore();
          else {
            this.ctx.restore();
            const g = (0, S.getCurrentTransform)(this.ctx);
            this.restore(), this.ctx.save(), this.ctx.setTransform(...g);
            const c = s.Util.getAxialAlignedBoundingBox([0, 0, u.canvas.width, u.canvas.height], g);
            this.ctx.drawImage(u.canvas, 0, 0), this.ctx.restore(), this.compose(c);
          }
        }
        beginAnnotation(o, u, m, g, c) {
          if (this.#t(), j(this.ctx), this.ctx.save(), this.save(), this.baseTransform && this.ctx.setTransform(...this.baseTransform), Array.isArray(u) && u.length === 4) {
            const b = u[2] - u[0], R = u[3] - u[1];
            if (c && this.annotationCanvasMap) {
              m = m.slice(), m[4] -= u[0], m[5] -= u[1], u = u.slice(), u[0] = u[1] = 0, u[2] = b, u[3] = R;
              const [I, O] = s.Util.singularValueDecompose2dScale((0, S.getCurrentTransform)(this.ctx)), {
                viewportScale: H
              } = this, $ = Math.ceil(b * this.outputScaleX * H), z = Math.ceil(R * this.outputScaleY * H);
              this.annotationCanvas = this.canvasFactory.create($, z);
              const {
                canvas: N,
                context: P
              } = this.annotationCanvas;
              this.annotationCanvasMap.set(o, N), this.annotationCanvas.savedCtx = this.ctx, this.ctx = P, this.ctx.save(), this.ctx.setTransform(I, 0, 0, -O, 0, R * O), j(this.ctx);
            } else
              j(this.ctx), this.ctx.rect(u[0], u[1], b, R), this.ctx.clip(), this.endPath();
          }
          this.current = new Z(this.ctx.canvas.width, this.ctx.canvas.height), this.transform(...m), this.transform(...g);
        }
        endAnnotation() {
          this.annotationCanvas && (this.ctx.restore(), this.#e(), this.ctx = this.annotationCanvas.savedCtx, delete this.annotationCanvas.savedCtx, delete this.annotationCanvas);
        }
        paintImageMaskXObject(o) {
          if (!this.contentVisible)
            return;
          const u = o.count;
          o = this.getObject(o.data, o), o.count = u;
          const m = this.ctx, g = this.processingType3;
          if (g && (g.compiled === void 0 && (g.compiled = q(o)), g.compiled)) {
            g.compiled(m);
            return;
          }
          const c = this._createMaskCanvas(o), b = c.canvas;
          m.save(), m.setTransform(1, 0, 0, 1, 0, 0), m.drawImage(b, c.offsetX, c.offsetY), m.restore(), this.compose();
        }
        paintImageMaskXObjectRepeat(o, u, m = 0, g = 0, c, b) {
          if (!this.contentVisible)
            return;
          o = this.getObject(o.data, o);
          const R = this.ctx;
          R.save();
          const I = (0, S.getCurrentTransform)(R);
          R.transform(u, m, g, c, 0, 0);
          const O = this._createMaskCanvas(o);
          R.setTransform(1, 0, 0, 1, O.offsetX - I[4], O.offsetY - I[5]);
          for (let H = 0, $ = b.length; H < $; H += 2) {
            const z = s.Util.transform(I, [u, m, g, c, b[H], b[H + 1]]), [N, P] = s.Util.applyTransform([0, 0], z);
            R.drawImage(O.canvas, N, P);
          }
          R.restore(), this.compose();
        }
        paintImageMaskXObjectGroup(o) {
          if (!this.contentVisible)
            return;
          const u = this.ctx, m = this.current.fillColor, g = this.current.patternFill;
          for (const c of o) {
            const {
              data: b,
              width: R,
              height: I,
              transform: O
            } = c, H = this.cachedCanvases.getCanvas("maskCanvas", R, I), $ = H.context;
            $.save();
            const z = this.getObject(b, c);
            Y($, z), $.globalCompositeOperation = "source-in", $.fillStyle = g ? m.getPattern($, this, (0, S.getCurrentTransformInverse)(u), v.FILL) : m, $.fillRect(0, 0, R, I), $.restore(), u.save(), u.transform(...O), u.scale(1, -1), U(u, H.canvas, 0, 0, R, I, 0, -1, 1, 1), u.restore();
          }
          this.compose();
        }
        paintImageXObject(o) {
          if (!this.contentVisible)
            return;
          const u = this.getObject(o);
          if (!u) {
            (0, s.warn)("Dependent image isn't ready yet");
            return;
          }
          this.paintInlineImageXObject(u);
        }
        paintImageXObjectRepeat(o, u, m, g) {
          if (!this.contentVisible)
            return;
          const c = this.getObject(o);
          if (!c) {
            (0, s.warn)("Dependent image isn't ready yet");
            return;
          }
          const b = c.width, R = c.height, I = [];
          for (let O = 0, H = g.length; O < H; O += 2)
            I.push({
              transform: [u, 0, 0, m, g[O], g[O + 1]],
              x: 0,
              y: 0,
              w: b,
              h: R
            });
          this.paintInlineImageXObjectGroup(c, I);
        }
        applyTransferMapsToCanvas(o) {
          return this.current.transferMaps !== "none" && (o.filter = this.current.transferMaps, o.drawImage(o.canvas, 0, 0), o.filter = "none"), o.canvas;
        }
        applyTransferMapsToBitmap(o) {
          if (this.current.transferMaps === "none")
            return o.bitmap;
          const {
            bitmap: u,
            width: m,
            height: g
          } = o, c = this.cachedCanvases.getCanvas("inlineImage", m, g), b = c.context;
          return b.filter = this.current.transferMaps, b.drawImage(u, 0, 0), b.filter = "none", c.canvas;
        }
        paintInlineImageXObject(o) {
          if (!this.contentVisible)
            return;
          const u = o.width, m = o.height, g = this.ctx;
          if (this.save(), !s.isNodeJS) {
            const {
              filter: R
            } = g;
            R !== "none" && R !== "" && (g.filter = "none");
          }
          g.scale(1 / u, -1 / m);
          let c;
          if (o.bitmap)
            c = this.applyTransferMapsToBitmap(o);
          else if (typeof HTMLElement == "function" && o instanceof HTMLElement || !o.data)
            c = o;
          else {
            const I = this.cachedCanvases.getCanvas("inlineImage", u, m).context;
            K(I, o), c = this.applyTransferMapsToCanvas(I);
          }
          const b = this._scaleImage(c, (0, S.getCurrentTransformInverse)(g));
          g.imageSmoothingEnabled = dt((0, S.getCurrentTransform)(g), o.interpolate), U(g, b.img, 0, 0, b.paintWidth, b.paintHeight, 0, -m, u, m), this.compose(), this.restore();
        }
        paintInlineImageXObjectGroup(o, u) {
          if (!this.contentVisible)
            return;
          const m = this.ctx;
          let g;
          if (o.bitmap)
            g = o.bitmap;
          else {
            const c = o.width, b = o.height, I = this.cachedCanvases.getCanvas("inlineImage", c, b).context;
            K(I, o), g = this.applyTransferMapsToCanvas(I);
          }
          for (const c of u)
            m.save(), m.transform(...c.transform), m.scale(1, -1), U(m, g, c.x, c.y, c.w, c.h, 0, -1, 1, 1), m.restore();
          this.compose();
        }
        paintSolidColorImageMask() {
          this.contentVisible && (this.ctx.fillRect(0, 0, 1, 1), this.compose());
        }
        markPoint(o) {
        }
        markPointProps(o, u) {
        }
        beginMarkedContent(o) {
          this.markedContentStack.push({
            visible: !0
          });
        }
        beginMarkedContentProps(o, u) {
          o === "OC" ? this.markedContentStack.push({
            visible: this.optionalContentConfig.isVisible(u)
          }) : this.markedContentStack.push({
            visible: !0
          }), this.contentVisible = this.isContentVisible();
        }
        endMarkedContent() {
          this.markedContentStack.pop(), this.contentVisible = this.isContentVisible();
        }
        beginCompat() {
        }
        endCompat() {
        }
        consumePath(o) {
          const u = this.current.isEmptyClip();
          this.pendingClip && this.current.updateClipFromPath(), this.pendingClip || this.compose(o);
          const m = this.ctx;
          this.pendingClip && (u || (this.pendingClip === et ? m.clip("evenodd") : m.clip()), this.pendingClip = null), this.current.startNewPathAndClipBox(this.current.clipBox), m.beginPath();
        }
        getSinglePixelWidth() {
          if (!this._cachedGetSinglePixelWidth) {
            const o = (0, S.getCurrentTransform)(this.ctx);
            if (o[1] === 0 && o[2] === 0)
              this._cachedGetSinglePixelWidth = 1 / Math.min(Math.abs(o[0]), Math.abs(o[3]));
            else {
              const u = Math.abs(o[0] * o[3] - o[2] * o[1]), m = Math.hypot(o[0], o[2]), g = Math.hypot(o[1], o[3]);
              this._cachedGetSinglePixelWidth = Math.max(m, g) / u;
            }
          }
          return this._cachedGetSinglePixelWidth;
        }
        getScaleForStroking() {
          if (this._cachedScaleForStroking[0] === -1) {
            const {
              lineWidth: o
            } = this.current, {
              a: u,
              b: m,
              c: g,
              d: c
            } = this.ctx.getTransform();
            let b, R;
            if (m === 0 && g === 0) {
              const I = Math.abs(u), O = Math.abs(c);
              if (I === O)
                if (o === 0)
                  b = R = 1 / I;
                else {
                  const H = I * o;
                  b = R = H < 1 ? 1 / H : 1;
                }
              else if (o === 0)
                b = 1 / I, R = 1 / O;
              else {
                const H = I * o, $ = O * o;
                b = H < 1 ? 1 / H : 1, R = $ < 1 ? 1 / $ : 1;
              }
            } else {
              const I = Math.abs(u * c - m * g), O = Math.hypot(u, m), H = Math.hypot(g, c);
              if (o === 0)
                b = H / I, R = O / I;
              else {
                const $ = o * I;
                b = H > $ ? H / $ : 1, R = O > $ ? O / $ : 1;
              }
            }
            this._cachedScaleForStroking[0] = b, this._cachedScaleForStroking[1] = R;
          }
          return this._cachedScaleForStroking;
        }
        rescaleAndStroke(o) {
          const {
            ctx: u
          } = this, {
            lineWidth: m
          } = this.current, [g, c] = this.getScaleForStroking();
          if (u.lineWidth = m || 1, g === 1 && c === 1) {
            u.stroke();
            return;
          }
          const b = u.getLineDash();
          if (o && u.save(), u.scale(g, c), b.length > 0) {
            const R = Math.max(g, c);
            u.setLineDash(b.map((I) => I / R)), u.lineDashOffset /= R;
          }
          u.stroke(), o && u.restore();
        }
        isContentVisible() {
          for (let o = this.markedContentStack.length - 1; o >= 0; o--)
            if (!this.markedContentStack[o].visible)
              return !1;
          return !0;
        }
      }
      for (const y in s.OPS)
        D.prototype[y] !== void 0 && (D.prototype[s.OPS[y]] = D.prototype[y]);
    })
  ),
  /***/
  419: (
    /***/
    ((V, l, a) => {
      a.d(l, {
        /* harmony export */
        DOMCMapReaderFactory: () => (
          /* binding */
          A
        ),
        /* harmony export */
        DOMCanvasFactory: () => (
          /* binding */
          C
        ),
        /* harmony export */
        DOMFilterFactory: () => (
          /* binding */
          x
        ),
        /* harmony export */
        DOMSVGFactory: () => (
          /* binding */
          f
        ),
        /* harmony export */
        DOMStandardFontDataFactory: () => (
          /* binding */
          n
        ),
        /* harmony export */
        PDFDateString: () => (
          /* binding */
          L
        ),
        /* harmony export */
        PageViewport: () => (
          /* binding */
          p
        ),
        /* harmony export */
        PixelsPerInch: () => (
          /* binding */
          _
        ),
        /* harmony export */
        RenderingCancelledException: () => (
          /* binding */
          F
        ),
        /* harmony export */
        StatTimer: () => (
          /* binding */
          h
        ),
        /* harmony export */
        fetchData: () => (
          /* binding */
          T
        ),
        /* harmony export */
        getColorValues: () => (
          /* binding */
          U
        ),
        /* harmony export */
        getCurrentTransform: () => (
          /* binding */
          q
        ),
        /* harmony export */
        getCurrentTransformInverse: () => (
          /* binding */
          Z
        ),
        /* harmony export */
        getFilenameFromUrl: () => (
          /* binding */
          t
        ),
        /* harmony export */
        getPdfFilenameFromUrl: () => (
          /* binding */
          i
        ),
        /* harmony export */
        getRGB: () => (
          /* binding */
          B
        ),
        /* harmony export */
        getXfaPageViewport: () => (
          /* binding */
          M
        ),
        /* harmony export */
        isDataScheme: () => (
          /* binding */
          r
        ),
        /* harmony export */
        isPdfFile: () => (
          /* binding */
          w
        ),
        /* harmony export */
        isValidFetchUrl: () => (
          /* binding */
          d
        ),
        /* harmony export */
        noContextMenu: () => (
          /* binding */
          E
        ),
        /* harmony export */
        setLayerDimensions: () => (
          /* binding */
          K
        )
        /* harmony export */
      });
      var s = a(583), S = a(292);
      const v = "http://www.w3.org/2000/svg";
      class _ {
        static CSS = 96;
        static PDF = 72;
        static PDF_TO_CSS_UNITS = this.CSS / this.PDF;
      }
      class x extends s.BaseFilterFactory {
        #t;
        #e;
        #s;
        #n;
        #r;
        #i = 0;
        constructor({
          docId: G,
          ownerDocument: j = globalThis.document
        } = {}) {
          super(), this.#s = G, this.#n = j;
        }
        get #a() {
          return this.#t ||= /* @__PURE__ */ new Map();
        }
        get #h() {
          return this.#r ||= /* @__PURE__ */ new Map();
        }
        get #l() {
          if (!this.#e) {
            const G = this.#n.createElement("div"), {
              style: j
            } = G;
            j.visibility = "hidden", j.contain = "strict", j.width = j.height = 0, j.position = "absolute", j.top = j.left = 0, j.zIndex = -1;
            const Q = this.#n.createElementNS(v, "svg");
            Q.setAttribute("width", 0), Q.setAttribute("height", 0), this.#e = this.#n.createElementNS(v, "defs"), G.append(Q), Q.append(this.#e), this.#n.body.append(G);
          }
          return this.#e;
        }
        addFilter(G) {
          if (!G)
            return "none";
          let j = this.#a.get(G);
          if (j)
            return j;
          let Q, J, tt, rt;
          if (G.length === 1) {
            const lt = G[0], ot = new Array(256);
            for (let et = 0; et < 256; et++)
              ot[et] = lt[et] / 255;
            rt = Q = J = tt = ot.join(",");
          } else {
            const [lt, ot, et] = G, D = new Array(256), y = new Array(256), o = new Array(256);
            for (let u = 0; u < 256; u++)
              D[u] = lt[u] / 255, y[u] = ot[u] / 255, o[u] = et[u] / 255;
            Q = D.join(","), J = y.join(","), tt = o.join(","), rt = `${Q}${J}${tt}`;
          }
          if (j = this.#a.get(rt), j)
            return this.#a.set(G, j), j;
          const ut = `g_${this.#s}_transfer_map_${this.#i++}`, dt = `url(#${ut})`;
          this.#a.set(G, dt), this.#a.set(rt, dt);
          const ft = this.#d(ut);
          return this.#o(Q, J, tt, ft), dt;
        }
        addHCMFilter(G, j) {
          const Q = `${G}-${j}`, J = "base";
          let tt = this.#h.get(J);
          if (tt?.key === Q || (tt ? (tt.filter?.remove(), tt.key = Q, tt.url = "none", tt.filter = null) : (tt = {
            key: Q,
            url: "none",
            filter: null
          }, this.#h.set(J, tt)), !G || !j))
            return tt.url;
          const rt = this.#p(G);
          G = S.Util.makeHexColor(...rt);
          const ut = this.#p(j);
          if (j = S.Util.makeHexColor(...ut), this.#l.style.color = "", G === "#000000" && j === "#ffffff" || G === j)
            return tt.url;
          const dt = new Array(256);
          for (let D = 0; D <= 255; D++) {
            const y = D / 255;
            dt[D] = y <= 0.03928 ? y / 12.92 : ((y + 0.055) / 1.055) ** 2.4;
          }
          const ft = dt.join(","), lt = `g_${this.#s}_hcm_filter`, ot = tt.filter = this.#d(lt);
          this.#o(ft, ft, ft, ot), this.#u(ot);
          const et = (D, y) => {
            const o = rt[D] / 255, u = ut[D] / 255, m = new Array(y + 1);
            for (let g = 0; g <= y; g++)
              m[g] = o + g / y * (u - o);
            return m.join(",");
          };
          return this.#o(et(0, 5), et(1, 5), et(2, 5), ot), tt.url = `url(#${lt})`, tt.url;
        }
        addHighlightHCMFilter(G, j, Q, J, tt) {
          const rt = `${j}-${Q}-${J}-${tt}`;
          let ut = this.#h.get(G);
          if (ut?.key === rt || (ut ? (ut.filter?.remove(), ut.key = rt, ut.url = "none", ut.filter = null) : (ut = {
            key: rt,
            url: "none",
            filter: null
          }, this.#h.set(G, ut)), !j || !Q))
            return ut.url;
          const [dt, ft] = [j, Q].map(this.#p.bind(this));
          let lt = Math.round(0.2126 * dt[0] + 0.7152 * dt[1] + 0.0722 * dt[2]), ot = Math.round(0.2126 * ft[0] + 0.7152 * ft[1] + 0.0722 * ft[2]), [et, D] = [J, tt].map(this.#p.bind(this));
          ot < lt && ([lt, ot, et, D] = [ot, lt, D, et]), this.#l.style.color = "";
          const y = (m, g, c) => {
            const b = new Array(256), R = (ot - lt) / c, I = m / 255, O = (g - m) / (255 * c);
            let H = 0;
            for (let $ = 0; $ <= c; $++) {
              const z = Math.round(lt + $ * R), N = I + $ * O;
              for (let P = H; P <= z; P++)
                b[P] = N;
              H = z + 1;
            }
            for (let $ = H; $ < 256; $++)
              b[$] = b[H - 1];
            return b.join(",");
          }, o = `g_${this.#s}_hcm_${G}_filter`, u = ut.filter = this.#d(o);
          return this.#u(u), this.#o(y(et[0], D[0], 5), y(et[1], D[1], 5), y(et[2], D[2], 5), u), ut.url = `url(#${o})`, ut.url;
        }
        destroy(G = !1) {
          G && this.#h.size !== 0 || (this.#e && (this.#e.parentNode.parentNode.remove(), this.#e = null), this.#t && (this.#t.clear(), this.#t = null), this.#i = 0);
        }
        #u(G) {
          const j = this.#n.createElementNS(v, "feColorMatrix");
          j.setAttribute("type", "matrix"), j.setAttribute("values", "0.2126 0.7152 0.0722 0 0 0.2126 0.7152 0.0722 0 0 0.2126 0.7152 0.0722 0 0 0 0 0 1 0"), G.append(j);
        }
        #d(G) {
          const j = this.#n.createElementNS(v, "filter");
          return j.setAttribute("color-interpolation-filters", "sRGB"), j.setAttribute("id", G), this.#l.append(j), j;
        }
        #c(G, j, Q) {
          const J = this.#n.createElementNS(v, j);
          J.setAttribute("type", "discrete"), J.setAttribute("tableValues", Q), G.append(J);
        }
        #o(G, j, Q, J) {
          const tt = this.#n.createElementNS(v, "feComponentTransfer");
          J.append(tt), this.#c(tt, "feFuncR", G), this.#c(tt, "feFuncG", j), this.#c(tt, "feFuncB", Q);
        }
        #p(G) {
          return this.#l.style.color = G, B(getComputedStyle(this.#l).getPropertyValue("color"));
        }
      }
      class C extends s.BaseCanvasFactory {
        constructor({
          ownerDocument: G = globalThis.document
        } = {}) {
          super(), this._document = G;
        }
        _createCanvas(G, j) {
          const Q = this._document.createElement("canvas");
          return Q.width = G, Q.height = j, Q;
        }
      }
      async function T(Y, G = "text") {
        if (d(Y, document.baseURI)) {
          const j = await fetch(Y);
          if (!j.ok)
            throw new Error(j.statusText);
          switch (G) {
            case "arraybuffer":
              return j.arrayBuffer();
            case "blob":
              return j.blob();
            case "json":
              return j.json();
          }
          return j.text();
        }
        return new Promise((j, Q) => {
          const J = new XMLHttpRequest();
          J.open("GET", Y, !0), J.responseType = G, J.onreadystatechange = () => {
            if (J.readyState === XMLHttpRequest.DONE) {
              if (J.status === 200 || J.status === 0) {
                switch (G) {
                  case "arraybuffer":
                  case "blob":
                  case "json":
                    j(J.response);
                    return;
                }
                j(J.responseText);
                return;
              }
              Q(new Error(J.statusText));
            }
          }, J.send(null);
        });
      }
      class A extends s.BaseCMapReaderFactory {
        _fetchData(G, j) {
          return T(G, this.isCompressed ? "arraybuffer" : "text").then((Q) => ({
            cMapData: Q instanceof ArrayBuffer ? new Uint8Array(Q) : (0, S.stringToBytes)(Q),
            compressionType: j
          }));
        }
      }
      class n extends s.BaseStandardFontDataFactory {
        _fetchData(G) {
          return T(G, "arraybuffer").then((j) => new Uint8Array(j));
        }
      }
      class f extends s.BaseSVGFactory {
        _createSVG(G) {
          return document.createElementNS(v, G);
        }
      }
      class p {
        constructor({
          viewBox: G,
          scale: j,
          rotation: Q,
          offsetX: J = 0,
          offsetY: tt = 0,
          dontFlip: rt = !1
        }) {
          this.viewBox = G, this.scale = j, this.rotation = Q, this.offsetX = J, this.offsetY = tt;
          const ut = (G[2] + G[0]) / 2, dt = (G[3] + G[1]) / 2;
          let ft, lt, ot, et;
          switch (Q %= 360, Q < 0 && (Q += 360), Q) {
            case 180:
              ft = -1, lt = 0, ot = 0, et = 1;
              break;
            case 90:
              ft = 0, lt = 1, ot = 1, et = 0;
              break;
            case 270:
              ft = 0, lt = -1, ot = -1, et = 0;
              break;
            case 0:
              ft = 1, lt = 0, ot = 0, et = -1;
              break;
            default:
              throw new Error("PageViewport: Invalid rotation, must be a multiple of 90 degrees.");
          }
          rt && (ot = -ot, et = -et);
          let D, y, o, u;
          ft === 0 ? (D = Math.abs(dt - G[1]) * j + J, y = Math.abs(ut - G[0]) * j + tt, o = (G[3] - G[1]) * j, u = (G[2] - G[0]) * j) : (D = Math.abs(ut - G[0]) * j + J, y = Math.abs(dt - G[1]) * j + tt, o = (G[2] - G[0]) * j, u = (G[3] - G[1]) * j), this.transform = [ft * j, lt * j, ot * j, et * j, D - ft * j * ut - ot * j * dt, y - lt * j * ut - et * j * dt], this.width = o, this.height = u;
        }
        get rawDims() {
          const {
            viewBox: G
          } = this;
          return (0, S.shadow)(this, "rawDims", {
            pageWidth: G[2] - G[0],
            pageHeight: G[3] - G[1],
            pageX: G[0],
            pageY: G[1]
          });
        }
        clone({
          scale: G = this.scale,
          rotation: j = this.rotation,
          offsetX: Q = this.offsetX,
          offsetY: J = this.offsetY,
          dontFlip: tt = !1
        } = {}) {
          return new p({
            viewBox: this.viewBox.slice(),
            scale: G,
            rotation: j,
            offsetX: Q,
            offsetY: J,
            dontFlip: tt
          });
        }
        convertToViewportPoint(G, j) {
          return S.Util.applyTransform([G, j], this.transform);
        }
        convertToViewportRectangle(G) {
          const j = S.Util.applyTransform([G[0], G[1]], this.transform), Q = S.Util.applyTransform([G[2], G[3]], this.transform);
          return [j[0], j[1], Q[0], Q[1]];
        }
        convertToPdfPoint(G, j) {
          return S.Util.applyInverseTransform([G, j], this.transform);
        }
      }
      class F extends S.BaseException {
        constructor(G, j = 0) {
          super(G, "RenderingCancelledException"), this.extraDelay = j;
        }
      }
      function r(Y) {
        const G = Y.length;
        let j = 0;
        for (; j < G && Y[j].trim() === ""; )
          j++;
        return Y.substring(j, j + 5).toLowerCase() === "data:";
      }
      function w(Y) {
        return typeof Y == "string" && /\.pdf$/i.test(Y);
      }
      function t(Y, G = !1) {
        return G || ([Y] = Y.split(/[#?]/, 1)), Y.substring(Y.lastIndexOf("/") + 1);
      }
      function i(Y, G = "document.pdf") {
        if (typeof Y != "string")
          return G;
        if (r(Y))
          return (0, S.warn)('getPdfFilenameFromUrl: ignore "data:"-URL for performance reasons.'), G;
        const j = /^(?:(?:[^:]+:)?\/\/[^/]+)?([^?#]*)(\?[^#]*)?(#.*)?$/, Q = /[^/?#=]+\.pdf\b(?!.*\.pdf\b)/i, J = j.exec(Y);
        let tt = Q.exec(J[1]) || Q.exec(J[2]) || Q.exec(J[3]);
        if (tt && (tt = tt[0], tt.includes("%")))
          try {
            tt = Q.exec(decodeURIComponent(tt))[0];
          } catch {
          }
        return tt || G;
      }
      class h {
        started = /* @__PURE__ */ Object.create(null);
        times = [];
        time(G) {
          G in this.started && (0, S.warn)(`Timer is already running for ${G}`), this.started[G] = Date.now();
        }
        timeEnd(G) {
          G in this.started || (0, S.warn)(`Timer has not been started for ${G}`), this.times.push({
            name: G,
            start: this.started[G],
            end: Date.now()
          }), delete this.started[G];
        }
        toString() {
          const G = [];
          let j = 0;
          for (const {
            name: Q
          } of this.times)
            j = Math.max(Q.length, j);
          for (const {
            name: Q,
            start: J,
            end: tt
          } of this.times)
            G.push(`${Q.padEnd(j)} ${tt - J}ms
`);
          return G.join("");
        }
      }
      function d(Y, G) {
        try {
          const {
            protocol: j
          } = G ? new URL(Y, G) : new URL(Y);
          return j === "http:" || j === "https:";
        } catch {
          return !1;
        }
      }
      function E(Y) {
        Y.preventDefault();
      }
      let k;
      class L {
        static toDateObject(G) {
          if (!G || typeof G != "string")
            return null;
          k ||= new RegExp("^D:(\\d{4})(\\d{2})?(\\d{2})?(\\d{2})?(\\d{2})?(\\d{2})?([Z|+|-])?(\\d{2})?'?(\\d{2})?'?");
          const j = k.exec(G);
          if (!j)
            return null;
          const Q = parseInt(j[1], 10);
          let J = parseInt(j[2], 10);
          J = J >= 1 && J <= 12 ? J - 1 : 0;
          let tt = parseInt(j[3], 10);
          tt = tt >= 1 && tt <= 31 ? tt : 1;
          let rt = parseInt(j[4], 10);
          rt = rt >= 0 && rt <= 23 ? rt : 0;
          let ut = parseInt(j[5], 10);
          ut = ut >= 0 && ut <= 59 ? ut : 0;
          let dt = parseInt(j[6], 10);
          dt = dt >= 0 && dt <= 59 ? dt : 0;
          const ft = j[7] || "Z";
          let lt = parseInt(j[8], 10);
          lt = lt >= 0 && lt <= 23 ? lt : 0;
          let ot = parseInt(j[9], 10) || 0;
          return ot = ot >= 0 && ot <= 59 ? ot : 0, ft === "-" ? (rt += lt, ut += ot) : ft === "+" && (rt -= lt, ut -= ot), new Date(Date.UTC(Q, J, tt, rt, ut, dt));
        }
      }
      function M(Y, {
        scale: G = 1,
        rotation: j = 0
      }) {
        const {
          width: Q,
          height: J
        } = Y.attributes.style, tt = [0, 0, parseInt(Q), parseInt(J)];
        return new p({
          viewBox: tt,
          scale: G,
          rotation: j
        });
      }
      function B(Y) {
        if (Y.startsWith("#")) {
          const G = parseInt(Y.slice(1), 16);
          return [(G & 16711680) >> 16, (G & 65280) >> 8, G & 255];
        }
        return Y.startsWith("rgb(") ? Y.slice(4, -1).split(",").map((G) => parseInt(G)) : Y.startsWith("rgba(") ? Y.slice(5, -1).split(",").map((G) => parseInt(G)).slice(0, 3) : ((0, S.warn)(`Not a valid color format: "${Y}"`), [0, 0, 0]);
      }
      function U(Y) {
        const G = document.createElement("span");
        G.style.visibility = "hidden", document.body.append(G);
        for (const j of Y.keys()) {
          G.style.color = j;
          const Q = window.getComputedStyle(G).color;
          Y.set(j, B(Q));
        }
        G.remove();
      }
      function q(Y) {
        const {
          a: G,
          b: j,
          c: Q,
          d: J,
          e: tt,
          f: rt
        } = Y.getTransform();
        return [G, j, Q, J, tt, rt];
      }
      function Z(Y) {
        const {
          a: G,
          b: j,
          c: Q,
          d: J,
          e: tt,
          f: rt
        } = Y.getTransform().invertSelf();
        return [G, j, Q, J, tt, rt];
      }
      function K(Y, G, j = !1, Q = !0) {
        if (G instanceof p) {
          const {
            pageWidth: J,
            pageHeight: tt
          } = G.rawDims, {
            style: rt
          } = Y, ut = S.FeatureTest.isCSSRoundSupported, dt = `var(--scale-factor) * ${J}px`, ft = `var(--scale-factor) * ${tt}px`, lt = ut ? `round(${dt}, 1px)` : `calc(${dt})`, ot = ut ? `round(${ft}, 1px)` : `calc(${ft})`;
          !j || G.rotation % 180 === 0 ? (rt.width = lt, rt.height = ot) : (rt.width = ot, rt.height = lt);
        }
        Q && Y.setAttribute("data-main-rotation", G.rotation);
      }
    })
  ),
  /***/
  47: (
    /***/
    ((V, l, a) => {
      a.d(l, {
        /* harmony export */
        DrawLayer: () => (
          /* binding */
          v
        )
        /* harmony export */
      });
      var s = a(419), S = a(292);
      class v {
        #t = null;
        #e = 0;
        #s = /* @__PURE__ */ new Map();
        #n = /* @__PURE__ */ new Map();
        constructor({
          pageIndex: x
        }) {
          this.pageIndex = x;
        }
        setParent(x) {
          if (!this.#t) {
            this.#t = x;
            return;
          }
          if (this.#t !== x) {
            if (this.#s.size > 0)
              for (const C of this.#s.values())
                C.remove(), x.append(C);
            this.#t = x;
          }
        }
        static get _svgFactory() {
          return (0, S.shadow)(this, "_svgFactory", new s.DOMSVGFactory());
        }
        static #r(x, {
          x: C = 0,
          y: T = 0,
          width: A = 1,
          height: n = 1
        } = {}) {
          const {
            style: f
          } = x;
          f.top = `${100 * T}%`, f.left = `${100 * C}%`, f.width = `${100 * A}%`, f.height = `${100 * n}%`;
        }
        #i(x) {
          const C = v._svgFactory.create(1, 1, !0);
          return this.#t.append(C), C.setAttribute("aria-hidden", !0), v.#r(C, x), C;
        }
        #a(x, C) {
          const T = v._svgFactory.createElement("clipPath");
          x.append(T);
          const A = `clip_${C}`;
          T.setAttribute("id", A), T.setAttribute("clipPathUnits", "objectBoundingBox");
          const n = v._svgFactory.createElement("use");
          return T.append(n), n.setAttribute("href", `#${C}`), n.classList.add("clip"), A;
        }
        highlight(x, C, T, A = !1) {
          const n = this.#e++, f = this.#i(x.box);
          f.classList.add("highlight"), x.free && f.classList.add("free");
          const p = v._svgFactory.createElement("defs");
          f.append(p);
          const F = v._svgFactory.createElement("path");
          p.append(F);
          const r = `path_p${this.pageIndex}_${n}`;
          F.setAttribute("id", r), F.setAttribute("d", x.toSVGPath()), A && this.#n.set(n, F);
          const w = this.#a(p, r), t = v._svgFactory.createElement("use");
          return f.append(t), f.setAttribute("fill", C), f.setAttribute("fill-opacity", T), t.setAttribute("href", `#${r}`), this.#s.set(n, f), {
            id: n,
            clipPathId: `url(#${w})`
          };
        }
        highlightOutline(x) {
          const C = this.#e++, T = this.#i(x.box);
          T.classList.add("highlightOutline");
          const A = v._svgFactory.createElement("defs");
          T.append(A);
          const n = v._svgFactory.createElement("path");
          A.append(n);
          const f = `path_p${this.pageIndex}_${C}`;
          n.setAttribute("id", f), n.setAttribute("d", x.toSVGPath()), n.setAttribute("vector-effect", "non-scaling-stroke");
          let p;
          if (x.free) {
            T.classList.add("free");
            const w = v._svgFactory.createElement("mask");
            A.append(w), p = `mask_p${this.pageIndex}_${C}`, w.setAttribute("id", p), w.setAttribute("maskUnits", "objectBoundingBox");
            const t = v._svgFactory.createElement("rect");
            w.append(t), t.setAttribute("width", "1"), t.setAttribute("height", "1"), t.setAttribute("fill", "white");
            const i = v._svgFactory.createElement("use");
            w.append(i), i.setAttribute("href", `#${f}`), i.setAttribute("stroke", "none"), i.setAttribute("fill", "black"), i.setAttribute("fill-rule", "nonzero"), i.classList.add("mask");
          }
          const F = v._svgFactory.createElement("use");
          T.append(F), F.setAttribute("href", `#${f}`), p && F.setAttribute("mask", `url(#${p})`);
          const r = F.cloneNode();
          return T.append(r), F.classList.add("mainOutline"), r.classList.add("secondaryOutline"), this.#s.set(C, T), C;
        }
        finalizeLine(x, C) {
          const T = this.#n.get(x);
          this.#n.delete(x), this.updateBox(x, C.box), T.setAttribute("d", C.toSVGPath());
        }
        updateLine(x, C) {
          this.#s.get(x).firstChild.firstChild.setAttribute("d", C.toSVGPath());
        }
        removeFreeHighlight(x) {
          this.remove(x), this.#n.delete(x);
        }
        updatePath(x, C) {
          this.#n.get(x).setAttribute("d", C.toSVGPath());
        }
        updateBox(x, C) {
          v.#r(this.#s.get(x), C);
        }
        show(x, C) {
          this.#s.get(x).classList.toggle("hidden", !C);
        }
        rotate(x, C) {
          this.#s.get(x).setAttribute("data-main-rotation", C);
        }
        changeColor(x, C) {
          this.#s.get(x).setAttribute("fill", C);
        }
        changeOpacity(x, C) {
          this.#s.get(x).setAttribute("fill-opacity", C);
        }
        addClass(x, C) {
          this.#s.get(x).classList.add(C);
        }
        removeClass(x, C) {
          this.#s.get(x).classList.remove(C);
        }
        remove(x) {
          this.#t !== null && (this.#s.get(x).remove(), this.#s.delete(x));
        }
        destroy() {
          this.#t = null;
          for (const x of this.#s.values())
            x.remove();
          this.#s.clear();
        }
      }
    })
  ),
  /***/
  731: (
    /***/
    ((V, l, a) => {
      a.d(l, {
        AnnotationEditorLayer: () => (
          /* binding */
          r
        )
      });
      var s = a(292), S = a(310), v = a(830), _ = a(976);
      const x = /\r\n?|\n/g;
      class C extends S.AnnotationEditor {
        #t = this.editorDivBlur.bind(this);
        #e = this.editorDivFocus.bind(this);
        #s = this.editorDivInput.bind(this);
        #n = this.editorDivKeydown.bind(this);
        #r = this.editorDivPaste.bind(this);
        #i;
        #a = "";
        #h = `${this.id}-editor`;
        #l;
        #u = null;
        static _freeTextDefaultContent = "";
        static _internalPadding = 0;
        static _defaultColor = null;
        static _defaultFontSize = 10;
        static get _keyboardManager() {
          const t = C.prototype, i = (E) => E.isEmpty(), h = v.AnnotationEditorUIManager.TRANSLATE_SMALL, d = v.AnnotationEditorUIManager.TRANSLATE_BIG;
          return (0, s.shadow)(this, "_keyboardManager", new v.KeyboardManager([[["ctrl+s", "mac+meta+s", "ctrl+p", "mac+meta+p"], t.commitOrRemove, {
            bubbles: !0
          }], [["ctrl+Enter", "mac+meta+Enter", "Escape", "mac+Escape"], t.commitOrRemove], [["ArrowLeft", "mac+ArrowLeft"], t._translateEmpty, {
            args: [-h, 0],
            checker: i
          }], [["ctrl+ArrowLeft", "mac+shift+ArrowLeft"], t._translateEmpty, {
            args: [-d, 0],
            checker: i
          }], [["ArrowRight", "mac+ArrowRight"], t._translateEmpty, {
            args: [h, 0],
            checker: i
          }], [["ctrl+ArrowRight", "mac+shift+ArrowRight"], t._translateEmpty, {
            args: [d, 0],
            checker: i
          }], [["ArrowUp", "mac+ArrowUp"], t._translateEmpty, {
            args: [0, -h],
            checker: i
          }], [["ctrl+ArrowUp", "mac+shift+ArrowUp"], t._translateEmpty, {
            args: [0, -d],
            checker: i
          }], [["ArrowDown", "mac+ArrowDown"], t._translateEmpty, {
            args: [0, h],
            checker: i
          }], [["ctrl+ArrowDown", "mac+shift+ArrowDown"], t._translateEmpty, {
            args: [0, d],
            checker: i
          }]]));
        }
        static _type = "freetext";
        static _editorType = s.AnnotationEditorType.FREETEXT;
        constructor(t) {
          super({
            ...t,
            name: "freeTextEditor"
          }), this.#i = t.color || C._defaultColor || S.AnnotationEditor._defaultLineColor, this.#l = t.fontSize || C._defaultFontSize;
        }
        static initialize(t, i) {
          S.AnnotationEditor.initialize(t, i, {
            strings: ["pdfjs-free-text-default-content"]
          });
          const h = getComputedStyle(document.documentElement);
          this._internalPadding = parseFloat(h.getPropertyValue("--freetext-padding"));
        }
        static updateDefaultParams(t, i) {
          switch (t) {
            case s.AnnotationEditorParamsType.FREETEXT_SIZE:
              C._defaultFontSize = i;
              break;
            case s.AnnotationEditorParamsType.FREETEXT_COLOR:
              C._defaultColor = i;
              break;
          }
        }
        updateParams(t, i) {
          switch (t) {
            case s.AnnotationEditorParamsType.FREETEXT_SIZE:
              this.#d(i);
              break;
            case s.AnnotationEditorParamsType.FREETEXT_COLOR:
              this.#c(i);
              break;
          }
        }
        static get defaultPropertiesToUpdate() {
          return [[s.AnnotationEditorParamsType.FREETEXT_SIZE, C._defaultFontSize], [s.AnnotationEditorParamsType.FREETEXT_COLOR, C._defaultColor || S.AnnotationEditor._defaultLineColor]];
        }
        get propertiesToUpdate() {
          return [[s.AnnotationEditorParamsType.FREETEXT_SIZE, this.#l], [s.AnnotationEditorParamsType.FREETEXT_COLOR, this.#i]];
        }
        #d(t) {
          const i = (d) => {
            this.editorDiv.style.fontSize = `calc(${d}px * var(--scale-factor))`, this.translate(0, -(d - this.#l) * this.parentScale), this.#l = d, this.#p();
          }, h = this.#l;
          this.addCommands({
            cmd: i.bind(this, t),
            undo: i.bind(this, h),
            post: this._uiManager.updateUI.bind(this._uiManager, this),
            mustExec: !0,
            type: s.AnnotationEditorParamsType.FREETEXT_SIZE,
            overwriteIfSameType: !0,
            keepUndo: !0
          });
        }
        #c(t) {
          const i = (d) => {
            this.#i = this.editorDiv.style.color = d;
          }, h = this.#i;
          this.addCommands({
            cmd: i.bind(this, t),
            undo: i.bind(this, h),
            post: this._uiManager.updateUI.bind(this._uiManager, this),
            mustExec: !0,
            type: s.AnnotationEditorParamsType.FREETEXT_COLOR,
            overwriteIfSameType: !0,
            keepUndo: !0
          });
        }
        _translateEmpty(t, i) {
          this._uiManager.translateSelectedEditors(t, i, !0);
        }
        getInitialTranslation() {
          const t = this.parentScale;
          return [-C._internalPadding * t, -(C._internalPadding + this.#l) * t];
        }
        rebuild() {
          this.parent && (super.rebuild(), this.div !== null && (this.isAttachedToDOM || this.parent.add(this)));
        }
        enableEditMode() {
          this.isInEditMode() || (this.parent.setEditingState(!1), this.parent.updateToolbar(s.AnnotationEditorType.FREETEXT), super.enableEditMode(), this.overlayDiv.classList.remove("enabled"), this.editorDiv.contentEditable = !0, this._isDraggable = !1, this.div.removeAttribute("aria-activedescendant"), this.editorDiv.addEventListener("keydown", this.#n), this.editorDiv.addEventListener("focus", this.#e), this.editorDiv.addEventListener("blur", this.#t), this.editorDiv.addEventListener("input", this.#s), this.editorDiv.addEventListener("paste", this.#r));
        }
        disableEditMode() {
          this.isInEditMode() && (this.parent.setEditingState(!0), super.disableEditMode(), this.overlayDiv.classList.add("enabled"), this.editorDiv.contentEditable = !1, this.div.setAttribute("aria-activedescendant", this.#h), this._isDraggable = !0, this.editorDiv.removeEventListener("keydown", this.#n), this.editorDiv.removeEventListener("focus", this.#e), this.editorDiv.removeEventListener("blur", this.#t), this.editorDiv.removeEventListener("input", this.#s), this.editorDiv.removeEventListener("paste", this.#r), this.div.focus({
            preventScroll: !0
          }), this.isEditing = !1, this.parent.div.classList.add("freetextEditing"));
        }
        focusin(t) {
          this._focusEventsAllowed && (super.focusin(t), t.target !== this.editorDiv && this.editorDiv.focus());
        }
        onceAdded() {
          this.width || (this.enableEditMode(), this.editorDiv.focus(), this._initialOptions?.isCentered && this.center(), this._initialOptions = null);
        }
        isEmpty() {
          return !this.editorDiv || this.editorDiv.innerText.trim() === "";
        }
        remove() {
          this.isEditing = !1, this.parent && (this.parent.setEditingState(!0), this.parent.div.classList.add("freetextEditing")), super.remove();
        }
        #o() {
          const t = [];
          this.editorDiv.normalize();
          for (const i of this.editorDiv.childNodes)
            t.push(C.#g(i));
          return t.join(`
`);
        }
        #p() {
          const [t, i] = this.parentDimensions;
          let h;
          if (this.isAttachedToDOM)
            h = this.div.getBoundingClientRect();
          else {
            const {
              currentLayer: d,
              div: E
            } = this, k = E.style.display, L = E.classList.contains("hidden");
            E.classList.remove("hidden"), E.style.display = "hidden", d.div.append(this.div), h = E.getBoundingClientRect(), E.remove(), E.style.display = k, E.classList.toggle("hidden", L);
          }
          this.rotation % 180 === this.parentRotation % 180 ? (this.width = h.width / t, this.height = h.height / i) : (this.width = h.height / t, this.height = h.width / i), this.fixAndSetPosition();
        }
        commit() {
          if (!this.isInEditMode())
            return;
          super.commit(), this.disableEditMode();
          const t = this.#a, i = this.#a = this.#o().trimEnd();
          if (t === i)
            return;
          const h = (d) => {
            if (this.#a = d, !d) {
              this.remove();
              return;
            }
            this.#f(), this._uiManager.rebuild(this), this.#p();
          };
          this.addCommands({
            cmd: () => {
              h(i);
            },
            undo: () => {
              h(t);
            },
            mustExec: !1
          }), this.#p();
        }
        shouldGetKeyboardEvents() {
          return this.isInEditMode();
        }
        enterInEditMode() {
          this.enableEditMode(), this.editorDiv.focus();
        }
        dblclick(t) {
          this.enterInEditMode();
        }
        keydown(t) {
          t.target === this.div && t.key === "Enter" && (this.enterInEditMode(), t.preventDefault());
        }
        editorDivKeydown(t) {
          C._keyboardManager.exec(this, t);
        }
        editorDivFocus(t) {
          this.isEditing = !0;
        }
        editorDivBlur(t) {
          this.isEditing = !1;
        }
        editorDivInput(t) {
          this.parent.div.classList.toggle("freetextEditing", this.isEmpty());
        }
        disableEditing() {
          this.editorDiv.setAttribute("role", "comment"), this.editorDiv.removeAttribute("aria-multiline");
        }
        enableEditing() {
          this.editorDiv.setAttribute("role", "textbox"), this.editorDiv.setAttribute("aria-multiline", !0);
        }
        render() {
          if (this.div)
            return this.div;
          let t, i;
          this.width && (t = this.x, i = this.y), super.render(), this.editorDiv = document.createElement("div"), this.editorDiv.className = "internal", this.editorDiv.setAttribute("id", this.#h), this.editorDiv.setAttribute("data-l10n-id", "pdfjs-free-text"), this.enableEditing(), S.AnnotationEditor._l10nPromise.get("pdfjs-free-text-default-content").then((d) => this.editorDiv?.setAttribute("default-content", d)), this.editorDiv.contentEditable = !0;
          const {
            style: h
          } = this.editorDiv;
          if (h.fontSize = `calc(${this.#l}px * var(--scale-factor))`, h.color = this.#i, this.div.append(this.editorDiv), this.overlayDiv = document.createElement("div"), this.overlayDiv.classList.add("overlay", "enabled"), this.div.append(this.overlayDiv), (0, v.bindEvents)(this, this.div, ["dblclick", "keydown"]), this.width) {
            const [d, E] = this.parentDimensions;
            if (this.annotationElementId) {
              const {
                position: k
              } = this.#u;
              let [L, M] = this.getInitialTranslation();
              [L, M] = this.pageTranslationToScreen(L, M);
              const [B, U] = this.pageDimensions, [q, Z] = this.pageTranslation;
              let K, Y;
              switch (this.rotation) {
                case 0:
                  K = t + (k[0] - q) / B, Y = i + this.height - (k[1] - Z) / U;
                  break;
                case 90:
                  K = t + (k[0] - q) / B, Y = i - (k[1] - Z) / U, [L, M] = [M, -L];
                  break;
                case 180:
                  K = t - this.width + (k[0] - q) / B, Y = i - (k[1] - Z) / U, [L, M] = [-L, -M];
                  break;
                case 270:
                  K = t + (k[0] - q - this.height * U) / B, Y = i + (k[1] - Z - this.width * B) / U, [L, M] = [-M, L];
                  break;
              }
              this.setAt(K * d, Y * E, L, M);
            } else
              this.setAt(t * d, i * E, this.width * d, this.height * E);
            this.#f(), this._isDraggable = !0, this.editorDiv.contentEditable = !1;
          } else
            this._isDraggable = !1, this.editorDiv.contentEditable = !0;
          return this.div;
        }
        static #g(t) {
          return (t.nodeType === Node.TEXT_NODE ? t.nodeValue : t.innerText).replaceAll(x, "");
        }
        editorDivPaste(t) {
          const i = t.clipboardData || window.clipboardData, {
            types: h
          } = i;
          if (h.length === 1 && h[0] === "text/plain")
            return;
          t.preventDefault();
          const d = C.#m(i.getData("text") || "").replaceAll(x, `
`);
          if (!d)
            return;
          const E = window.getSelection();
          if (!E.rangeCount)
            return;
          this.editorDiv.normalize(), E.deleteFromDocument();
          const k = E.getRangeAt(0);
          if (!d.includes(`
`)) {
            k.insertNode(document.createTextNode(d)), this.editorDiv.normalize(), E.collapseToStart();
            return;
          }
          const {
            startContainer: L,
            startOffset: M
          } = k, B = [], U = [];
          if (L.nodeType === Node.TEXT_NODE) {
            const K = L.parentElement;
            if (U.push(L.nodeValue.slice(M).replaceAll(x, "")), K !== this.editorDiv) {
              let Y = B;
              for (const G of this.editorDiv.childNodes) {
                if (G === K) {
                  Y = U;
                  continue;
                }
                Y.push(C.#g(G));
              }
            }
            B.push(L.nodeValue.slice(0, M).replaceAll(x, ""));
          } else if (L === this.editorDiv) {
            let K = B, Y = 0;
            for (const G of this.editorDiv.childNodes)
              Y++ === M && (K = U), K.push(C.#g(G));
          }
          this.#a = `${B.join(`
`)}${d}${U.join(`
`)}`, this.#f();
          const q = new Range();
          let Z = B.reduce((K, Y) => K + Y.length, 0);
          for (const {
            firstChild: K
          } of this.editorDiv.childNodes)
            if (K.nodeType === Node.TEXT_NODE) {
              const Y = K.nodeValue.length;
              if (Z <= Y) {
                q.setStart(K, Z), q.setEnd(K, Z);
                break;
              }
              Z -= Y;
            }
          E.removeAllRanges(), E.addRange(q);
        }
        #f() {
          if (this.editorDiv.replaceChildren(), !!this.#a)
            for (const t of this.#a.split(`
`)) {
              const i = document.createElement("div");
              i.append(t ? document.createTextNode(t) : document.createElement("br")), this.editorDiv.append(i);
            }
        }
        #b() {
          return this.#a.replaceAll(" ", " ");
        }
        static #m(t) {
          return t.replaceAll(" ", " ");
        }
        get contentDiv() {
          return this.editorDiv;
        }
        static deserialize(t, i, h) {
          let d = null;
          if (t instanceof _.FreeTextAnnotationElement) {
            const {
              data: {
                defaultAppearanceData: {
                  fontSize: k,
                  fontColor: L
                },
                rect: M,
                rotation: B,
                id: U
              },
              textContent: q,
              textPosition: Z,
              parent: {
                page: {
                  pageNumber: K
                }
              }
            } = t;
            if (!q || q.length === 0)
              return null;
            d = t = {
              annotationType: s.AnnotationEditorType.FREETEXT,
              color: Array.from(L),
              fontSize: k,
              value: q.join(`
`),
              position: Z,
              pageIndex: K - 1,
              rect: M.slice(0),
              rotation: B,
              id: U,
              deleted: !1
            };
          }
          const E = super.deserialize(t, i, h);
          return E.#l = t.fontSize, E.#i = s.Util.makeHexColor(...t.color), E.#a = C.#m(t.value), E.annotationElementId = t.id || null, E.#u = d, E;
        }
        serialize(t = !1) {
          if (this.isEmpty())
            return null;
          if (this.deleted)
            return {
              pageIndex: this.pageIndex,
              id: this.annotationElementId,
              deleted: !0
            };
          const i = C._internalPadding * this.parentScale, h = this.getRect(i, i), d = S.AnnotationEditor._colorManager.convert(this.isAttachedToDOM ? getComputedStyle(this.editorDiv).color : this.#i), E = {
            annotationType: s.AnnotationEditorType.FREETEXT,
            color: d,
            fontSize: this.#l,
            value: this.#b(),
            pageIndex: this.pageIndex,
            rect: h,
            rotation: this.rotation,
            structTreeParentId: this._structTreeParentId
          };
          return t ? E : this.annotationElementId && !this.#w(E) ? null : (E.id = this.annotationElementId, E);
        }
        #w(t) {
          const {
            value: i,
            fontSize: h,
            color: d,
            pageIndex: E
          } = this.#u;
          return this._hasBeenMoved || t.value !== i || t.fontSize !== h || t.color.some((k, L) => k !== d[L]) || t.pageIndex !== E;
        }
        renderAnnotationElement(t) {
          const i = super.renderAnnotationElement(t);
          if (this.deleted)
            return i;
          const {
            style: h
          } = i;
          h.fontSize = `calc(${this.#l}px * var(--scale-factor))`, h.color = this.#i, i.replaceChildren();
          for (const E of this.#a.split(`
`)) {
            const k = document.createElement("div");
            k.append(E ? document.createTextNode(E) : document.createElement("br")), i.append(k);
          }
          const d = C._internalPadding * this.parentScale;
          return t.updateEdited({
            rect: this.getRect(d, d)
          }), i;
        }
        resetAnnotationElement(t) {
          super.resetAnnotationElement(t), t.resetEdited();
        }
      }
      var T = a(61), A = a(259), n = a(419);
      class f extends S.AnnotationEditor {
        #t = null;
        #e = 0;
        #s;
        #n = null;
        #r = null;
        #i = null;
        #a = null;
        #h = 0;
        #l = null;
        #u = null;
        #d = null;
        #c = !1;
        #o = this.#E.bind(this);
        #p = null;
        #g;
        #f = null;
        #b = "";
        #m;
        #w = "";
        static _defaultColor = null;
        static _defaultOpacity = 1;
        static _defaultThickness = 12;
        static _l10nPromise;
        static _type = "highlight";
        static _editorType = s.AnnotationEditorType.HIGHLIGHT;
        static _freeHighlightId = -1;
        static _freeHighlight = null;
        static _freeHighlightClipId = "";
        static get _keyboardManager() {
          const t = f.prototype;
          return (0, s.shadow)(this, "_keyboardManager", new v.KeyboardManager([[["ArrowLeft", "mac+ArrowLeft"], t._moveCaret, {
            args: [0]
          }], [["ArrowRight", "mac+ArrowRight"], t._moveCaret, {
            args: [1]
          }], [["ArrowUp", "mac+ArrowUp"], t._moveCaret, {
            args: [2]
          }], [["ArrowDown", "mac+ArrowDown"], t._moveCaret, {
            args: [3]
          }]]));
        }
        constructor(t) {
          super({
            ...t,
            name: "highlightEditor"
          }), this.color = t.color || f._defaultColor, this.#m = t.thickness || f._defaultThickness, this.#g = t.opacity || f._defaultOpacity, this.#s = t.boxes || null, this.#w = t.methodOfCreation || "", this.#b = t.text || "", this._isDraggable = !1, t.highlightId > -1 ? (this.#c = !0, this.#S(t), this.#v()) : (this.#t = t.anchorNode, this.#e = t.anchorOffset, this.#a = t.focusNode, this.#h = t.focusOffset, this.#y(), this.#v(), this.rotate(this.rotation));
        }
        get telemetryInitialData() {
          return {
            action: "added",
            type: this.#c ? "free_highlight" : "highlight",
            color: this._uiManager.highlightColorNames.get(this.color),
            thickness: this.#m,
            methodOfCreation: this.#w
          };
        }
        get telemetryFinalData() {
          return {
            type: "highlight",
            color: this._uiManager.highlightColorNames.get(this.color)
          };
        }
        static computeTelemetryFinalData(t) {
          return {
            numberOfColors: t.get("color").size
          };
        }
        #y() {
          const t = new T.Outliner(this.#s, 1e-3);
          this.#u = t.getOutlines(), {
            x: this.x,
            y: this.y,
            width: this.width,
            height: this.height
          } = this.#u.box;
          const i = new T.Outliner(this.#s, 25e-4, 1e-3, this._uiManager.direction === "ltr");
          this.#i = i.getOutlines();
          const {
            lastPoint: h
          } = this.#i.box;
          this.#p = [(h[0] - this.x) / this.width, (h[1] - this.y) / this.height];
        }
        #S({
          highlightOutlines: t,
          highlightId: i,
          clipPathId: h
        }) {
          this.#u = t;
          const d = 1.5;
          if (this.#i = t.getNewOutline(this.#m / 2 + d, 25e-4), i >= 0)
            this.#d = i, this.#n = h, this.parent.drawLayer.finalizeLine(i, t), this.#f = this.parent.drawLayer.highlightOutline(this.#i);
          else if (this.parent) {
            const U = this.parent.viewport.rotation;
            this.parent.drawLayer.updateLine(this.#d, t), this.parent.drawLayer.updateBox(this.#d, f.#x(this.#u.box, (U - this.rotation + 360) % 360)), this.parent.drawLayer.updateLine(this.#f, this.#i), this.parent.drawLayer.updateBox(this.#f, f.#x(this.#i.box, U));
          }
          const {
            x: E,
            y: k,
            width: L,
            height: M
          } = t.box;
          switch (this.rotation) {
            case 0:
              this.x = E, this.y = k, this.width = L, this.height = M;
              break;
            case 90: {
              const [U, q] = this.parentDimensions;
              this.x = k, this.y = 1 - E, this.width = L * q / U, this.height = M * U / q;
              break;
            }
            case 180:
              this.x = 1 - E, this.y = 1 - k, this.width = L, this.height = M;
              break;
            case 270: {
              const [U, q] = this.parentDimensions;
              this.x = 1 - k, this.y = E, this.width = L * q / U, this.height = M * U / q;
              break;
            }
          }
          const {
            lastPoint: B
          } = this.#i.box;
          this.#p = [(B[0] - E) / L, (B[1] - k) / M];
        }
        static initialize(t, i) {
          S.AnnotationEditor.initialize(t, i), f._defaultColor ||= i.highlightColors?.values().next().value || "#fff066";
        }
        static updateDefaultParams(t, i) {
          switch (t) {
            case s.AnnotationEditorParamsType.HIGHLIGHT_DEFAULT_COLOR:
              f._defaultColor = i;
              break;
            case s.AnnotationEditorParamsType.HIGHLIGHT_THICKNESS:
              f._defaultThickness = i;
              break;
          }
        }
        translateInPage(t, i) {
        }
        get toolbarPosition() {
          return this.#p;
        }
        updateParams(t, i) {
          switch (t) {
            case s.AnnotationEditorParamsType.HIGHLIGHT_COLOR:
              this.#F(i);
              break;
            case s.AnnotationEditorParamsType.HIGHLIGHT_THICKNESS:
              this.#I(i);
              break;
          }
        }
        static get defaultPropertiesToUpdate() {
          return [[s.AnnotationEditorParamsType.HIGHLIGHT_DEFAULT_COLOR, f._defaultColor], [s.AnnotationEditorParamsType.HIGHLIGHT_THICKNESS, f._defaultThickness]];
        }
        get propertiesToUpdate() {
          return [[s.AnnotationEditorParamsType.HIGHLIGHT_COLOR, this.color || f._defaultColor], [s.AnnotationEditorParamsType.HIGHLIGHT_THICKNESS, this.#m || f._defaultThickness], [s.AnnotationEditorParamsType.HIGHLIGHT_FREE, this.#c]];
        }
        #F(t) {
          const i = (d) => {
            this.color = d, this.parent?.drawLayer.changeColor(this.#d, d), this.#r?.updateColor(d);
          }, h = this.color;
          this.addCommands({
            cmd: i.bind(this, t),
            undo: i.bind(this, h),
            post: this._uiManager.updateUI.bind(this._uiManager, this),
            mustExec: !0,
            type: s.AnnotationEditorParamsType.HIGHLIGHT_COLOR,
            overwriteIfSameType: !0,
            keepUndo: !0
          }), this._reportTelemetry({
            action: "color_changed",
            color: this._uiManager.highlightColorNames.get(t)
          }, !0);
        }
        #I(t) {
          const i = this.#m, h = (d) => {
            this.#m = d, this.#R(d);
          };
          this.addCommands({
            cmd: h.bind(this, t),
            undo: h.bind(this, i),
            post: this._uiManager.updateUI.bind(this._uiManager, this),
            mustExec: !0,
            type: s.AnnotationEditorParamsType.INK_THICKNESS,
            overwriteIfSameType: !0,
            keepUndo: !0
          }), this._reportTelemetry({
            action: "thickness_changed",
            thickness: t
          }, !0);
        }
        async addEditToolbar() {
          const t = await super.addEditToolbar();
          return t ? (this._uiManager.highlightColors && (this.#r = new A.ColorPicker({
            editor: this
          }), t.addColorPicker(this.#r)), t) : null;
        }
        disableEditing() {
          super.disableEditing(), this.div.classList.toggle("disabled", !0);
        }
        enableEditing() {
          super.enableEditing(), this.div.classList.toggle("disabled", !1);
        }
        fixAndSetPosition() {
          return super.fixAndSetPosition(this.#C());
        }
        getBaseTranslation() {
          return [0, 0];
        }
        getRect(t, i) {
          return super.getRect(t, i, this.#C());
        }
        onceAdded() {
          this.parent.addUndoableEditor(this), this.div.focus();
        }
        remove() {
          this.#A(), this._reportTelemetry({
            action: "deleted"
          }), super.remove();
        }
        rebuild() {
          this.parent && (super.rebuild(), this.div !== null && (this.#v(), this.isAttachedToDOM || this.parent.add(this)));
        }
        setParent(t) {
          let i = !1;
          this.parent && !t ? this.#A() : t && (this.#v(t), i = !this.parent && this.div?.classList.contains("selectedEditor")), super.setParent(t), this.show(this._isVisible), i && this.select();
        }
        #R(t) {
          if (!this.#c)
            return;
          this.#S({
            highlightOutlines: this.#u.getNewOutline(t / 2)
          }), this.fixAndSetPosition();
          const [i, h] = this.parentDimensions;
          this.setDims(this.width * i, this.height * h);
        }
        #A() {
          this.#d === null || !this.parent || (this.parent.drawLayer.remove(this.#d), this.#d = null, this.parent.drawLayer.remove(this.#f), this.#f = null);
        }
        #v(t = this.parent) {
          this.#d === null && ({
            id: this.#d,
            clipPathId: this.#n
          } = t.drawLayer.highlight(this.#u, this.color, this.#g), this.#f = t.drawLayer.highlightOutline(this.#i), this.#l && (this.#l.style.clipPath = this.#n));
        }
        static #x({
          x: t,
          y: i,
          width: h,
          height: d
        }, E) {
          switch (E) {
            case 90:
              return {
                x: 1 - i - d,
                y: t,
                width: d,
                height: h
              };
            case 180:
              return {
                x: 1 - t - h,
                y: 1 - i - d,
                width: h,
                height: d
              };
            case 270:
              return {
                x: i,
                y: 1 - t - h,
                width: d,
                height: h
              };
          }
          return {
            x: t,
            y: i,
            width: h,
            height: d
          };
        }
        rotate(t) {
          const {
            drawLayer: i
          } = this.parent;
          let h;
          this.#c ? (t = (t - this.rotation + 360) % 360, h = f.#x(this.#u.box, t)) : h = f.#x(this, t), i.rotate(this.#d, t), i.rotate(this.#f, t), i.updateBox(this.#d, h), i.updateBox(this.#f, f.#x(this.#i.box, t));
        }
        render() {
          if (this.div)
            return this.div;
          const t = super.render();
          this.#b && (t.setAttribute("aria-label", this.#b), t.setAttribute("role", "mark")), this.#c ? t.classList.add("free") : this.div.addEventListener("keydown", this.#o);
          const i = this.#l = document.createElement("div");
          t.append(i), i.setAttribute("aria-hidden", "true"), i.className = "internal", i.style.clipPath = this.#n;
          const [h, d] = this.parentDimensions;
          return this.setDims(this.width * h, this.height * d), (0, v.bindEvents)(this, this.#l, ["pointerover", "pointerleave"]), this.enableEditing(), t;
        }
        pointerover() {
          this.parent.drawLayer.addClass(this.#f, "hovered");
        }
        pointerleave() {
          this.parent.drawLayer.removeClass(this.#f, "hovered");
        }
        #E(t) {
          f._keyboardManager.exec(this, t);
        }
        _moveCaret(t) {
          switch (this.parent.unselect(this), t) {
            case 0:
            case 2:
              this.#D(!0);
              break;
            case 1:
            case 3:
              this.#D(!1);
              break;
          }
        }
        #D(t) {
          if (!this.#t)
            return;
          const i = window.getSelection();
          t ? i.setPosition(this.#t, this.#e) : i.setPosition(this.#a, this.#h);
        }
        select() {
          super.select(), this.#f && (this.parent?.drawLayer.removeClass(this.#f, "hovered"), this.parent?.drawLayer.addClass(this.#f, "selected"));
        }
        unselect() {
          super.unselect(), this.#f && (this.parent?.drawLayer.removeClass(this.#f, "selected"), this.#c || this.#D(!1));
        }
        get _mustFixPosition() {
          return !this.#c;
        }
        show(t = this._isVisible) {
          super.show(t), this.parent && (this.parent.drawLayer.show(this.#d, t), this.parent.drawLayer.show(this.#f, t));
        }
        #C() {
          return this.#c ? this.rotation : 0;
        }
        #L() {
          if (this.#c)
            return null;
          const [t, i] = this.pageDimensions, h = this.#s, d = new Array(h.length * 8);
          let E = 0;
          for (const {
            x: k,
            y: L,
            width: M,
            height: B
          } of h) {
            const U = k * t, q = (1 - L - B) * i;
            d[E] = d[E + 4] = U, d[E + 1] = d[E + 3] = q, d[E + 2] = d[E + 6] = U + M * t, d[E + 5] = d[E + 7] = q + B * i, E += 8;
          }
          return d;
        }
        #T(t) {
          return this.#u.serialize(t, this.#C());
        }
        static startHighlighting(t, i, {
          target: h,
          x: d,
          y: E
        }) {
          const {
            x: k,
            y: L,
            width: M,
            height: B
          } = h.getBoundingClientRect(), U = (Y) => {
            this.#M(t, Y);
          }, q = {
            capture: !0,
            passive: !1
          }, Z = (Y) => {
            Y.preventDefault(), Y.stopPropagation();
          }, K = (Y) => {
            h.removeEventListener("pointermove", U), window.removeEventListener("blur", K), window.removeEventListener("pointerup", K), window.removeEventListener("pointerdown", Z, q), window.removeEventListener("contextmenu", n.noContextMenu), this.#_(t, Y);
          };
          window.addEventListener("blur", K), window.addEventListener("pointerup", K), window.addEventListener("pointerdown", Z, q), window.addEventListener("contextmenu", n.noContextMenu), h.addEventListener("pointermove", U), this._freeHighlight = new T.FreeOutliner({
            x: d,
            y: E
          }, [k, L, M, B], t.scale, this._defaultThickness / 2, i, 1e-3), {
            id: this._freeHighlightId,
            clipPathId: this._freeHighlightClipId
          } = t.drawLayer.highlight(this._freeHighlight, this._defaultColor, this._defaultOpacity, !0);
        }
        static #M(t, i) {
          this._freeHighlight.add(i) && t.drawLayer.updatePath(this._freeHighlightId, this._freeHighlight);
        }
        static #_(t, i) {
          this._freeHighlight.isEmpty() ? t.drawLayer.removeFreeHighlight(this._freeHighlightId) : t.createAndAddNewEditor(i, !1, {
            highlightId: this._freeHighlightId,
            highlightOutlines: this._freeHighlight.getOutlines(),
            clipPathId: this._freeHighlightClipId,
            methodOfCreation: "main_toolbar"
          }), this._freeHighlightId = -1, this._freeHighlight = null, this._freeHighlightClipId = "";
        }
        static deserialize(t, i, h) {
          const d = super.deserialize(t, i, h), {
            rect: [E, k, L, M],
            color: B,
            quadPoints: U
          } = t;
          d.color = s.Util.makeHexColor(...B), d.#g = t.opacity;
          const [q, Z] = d.pageDimensions;
          d.width = (L - E) / q, d.height = (M - k) / Z;
          const K = d.#s = [];
          for (let Y = 0; Y < U.length; Y += 8)
            K.push({
              x: (U[4] - L) / q,
              y: (M - (1 - U[Y + 5])) / Z,
              width: (U[Y + 2] - U[Y]) / q,
              height: (U[Y + 5] - U[Y + 1]) / Z
            });
          return d.#y(), d;
        }
        serialize(t = !1) {
          if (this.isEmpty() || t)
            return null;
          const i = this.getRect(0, 0), h = S.AnnotationEditor._colorManager.convert(this.color);
          return {
            annotationType: s.AnnotationEditorType.HIGHLIGHT,
            color: h,
            opacity: this.#g,
            thickness: this.#m,
            quadPoints: this.#L(),
            outlines: this.#T(i),
            pageIndex: this.pageIndex,
            rect: i,
            rotation: this.#C(),
            structTreeParentId: this._structTreeParentId
          };
        }
        static canCreateNewEmptyEditor() {
          return !1;
        }
      }
      class p extends S.AnnotationEditor {
        #t = 0;
        #e = 0;
        #s = this.canvasPointermove.bind(this);
        #n = this.canvasPointerleave.bind(this);
        #r = this.canvasPointerup.bind(this);
        #i = this.canvasPointerdown.bind(this);
        #a = null;
        #h = new Path2D();
        #l = !1;
        #u = !1;
        #d = !1;
        #c = null;
        #o = 0;
        #p = 0;
        #g = null;
        static _defaultColor = null;
        static _defaultOpacity = 1;
        static _defaultThickness = 1;
        static _type = "ink";
        static _editorType = s.AnnotationEditorType.INK;
        constructor(t) {
          super({
            ...t,
            name: "inkEditor"
          }), this.color = t.color || null, this.thickness = t.thickness || null, this.opacity = t.opacity || null, this.paths = [], this.bezierPath2D = [], this.allRawPaths = [], this.currentPath = [], this.scaleFactor = 1, this.translationX = this.translationY = 0, this.x = 0, this.y = 0, this._willKeepAspectRatio = !0;
        }
        static initialize(t, i) {
          S.AnnotationEditor.initialize(t, i);
        }
        static updateDefaultParams(t, i) {
          switch (t) {
            case s.AnnotationEditorParamsType.INK_THICKNESS:
              p._defaultThickness = i;
              break;
            case s.AnnotationEditorParamsType.INK_COLOR:
              p._defaultColor = i;
              break;
            case s.AnnotationEditorParamsType.INK_OPACITY:
              p._defaultOpacity = i / 100;
              break;
          }
        }
        updateParams(t, i) {
          switch (t) {
            case s.AnnotationEditorParamsType.INK_THICKNESS:
              this.#f(i);
              break;
            case s.AnnotationEditorParamsType.INK_COLOR:
              this.#b(i);
              break;
            case s.AnnotationEditorParamsType.INK_OPACITY:
              this.#m(i);
              break;
          }
        }
        static get defaultPropertiesToUpdate() {
          return [[s.AnnotationEditorParamsType.INK_THICKNESS, p._defaultThickness], [s.AnnotationEditorParamsType.INK_COLOR, p._defaultColor || S.AnnotationEditor._defaultLineColor], [s.AnnotationEditorParamsType.INK_OPACITY, Math.round(p._defaultOpacity * 100)]];
        }
        get propertiesToUpdate() {
          return [[s.AnnotationEditorParamsType.INK_THICKNESS, this.thickness || p._defaultThickness], [s.AnnotationEditorParamsType.INK_COLOR, this.color || p._defaultColor || S.AnnotationEditor._defaultLineColor], [s.AnnotationEditorParamsType.INK_OPACITY, Math.round(100 * (this.opacity ?? p._defaultOpacity))]];
        }
        #f(t) {
          const i = (d) => {
            this.thickness = d, this.#N();
          }, h = this.thickness;
          this.addCommands({
            cmd: i.bind(this, t),
            undo: i.bind(this, h),
            post: this._uiManager.updateUI.bind(this._uiManager, this),
            mustExec: !0,
            type: s.AnnotationEditorParamsType.INK_THICKNESS,
            overwriteIfSameType: !0,
            keepUndo: !0
          });
        }
        #b(t) {
          const i = (d) => {
            this.color = d, this.#E();
          }, h = this.color;
          this.addCommands({
            cmd: i.bind(this, t),
            undo: i.bind(this, h),
            post: this._uiManager.updateUI.bind(this._uiManager, this),
            mustExec: !0,
            type: s.AnnotationEditorParamsType.INK_COLOR,
            overwriteIfSameType: !0,
            keepUndo: !0
          });
        }
        #m(t) {
          const i = (d) => {
            this.opacity = d, this.#E();
          };
          t /= 100;
          const h = this.opacity;
          this.addCommands({
            cmd: i.bind(this, t),
            undo: i.bind(this, h),
            post: this._uiManager.updateUI.bind(this._uiManager, this),
            mustExec: !0,
            type: s.AnnotationEditorParamsType.INK_OPACITY,
            overwriteIfSameType: !0,
            keepUndo: !0
          });
        }
        rebuild() {
          this.parent && (super.rebuild(), this.div !== null && (this.canvas || (this.#C(), this.#L()), this.isAttachedToDOM || (this.parent.add(this), this.#T()), this.#N()));
        }
        remove() {
          this.canvas !== null && (this.isEmpty() || this.commit(), this.canvas.width = this.canvas.height = 0, this.canvas.remove(), this.canvas = null, this.#a && (clearTimeout(this.#a), this.#a = null), this.#c.disconnect(), this.#c = null, super.remove());
        }
        setParent(t) {
          !this.parent && t ? this._uiManager.removeShouldRescale(this) : this.parent && t === null && this._uiManager.addShouldRescale(this), super.setParent(t);
        }
        onScaleChanging() {
          const [t, i] = this.parentDimensions, h = this.width * t, d = this.height * i;
          this.setDimensions(h, d);
        }
        enableEditMode() {
          this.#l || this.canvas === null || (super.enableEditMode(), this._isDraggable = !1, this.canvas.addEventListener("pointerdown", this.#i));
        }
        disableEditMode() {
          !this.isInEditMode() || this.canvas === null || (super.disableEditMode(), this._isDraggable = !this.isEmpty(), this.div.classList.remove("editing"), this.canvas.removeEventListener("pointerdown", this.#i));
        }
        onceAdded() {
          this._isDraggable = !this.isEmpty();
        }
        isEmpty() {
          return this.paths.length === 0 || this.paths.length === 1 && this.paths[0].length === 0;
        }
        #w() {
          const {
            parentRotation: t,
            parentDimensions: [i, h]
          } = this;
          switch (t) {
            case 90:
              return [0, h, h, i];
            case 180:
              return [i, h, i, h];
            case 270:
              return [i, 0, h, i];
            default:
              return [0, 0, i, h];
          }
        }
        #y() {
          const {
            ctx: t,
            color: i,
            opacity: h,
            thickness: d,
            parentScale: E,
            scaleFactor: k
          } = this;
          t.lineWidth = d * E / k, t.lineCap = "round", t.lineJoin = "round", t.miterLimit = 10, t.strokeStyle = `${i}${(0, v.opacityToHex)(h)}`;
        }
        #S(t, i) {
          this.canvas.addEventListener("contextmenu", n.noContextMenu), this.canvas.addEventListener("pointerleave", this.#n), this.canvas.addEventListener("pointermove", this.#s), this.canvas.addEventListener("pointerup", this.#r), this.canvas.removeEventListener("pointerdown", this.#i), this.isEditing = !0, this.#d || (this.#d = !0, this.#T(), this.thickness ||= p._defaultThickness, this.color ||= p._defaultColor || S.AnnotationEditor._defaultLineColor, this.opacity ??= p._defaultOpacity), this.currentPath.push([t, i]), this.#u = !1, this.#y(), this.#g = () => {
            this.#A(), this.#g && window.requestAnimationFrame(this.#g);
          }, window.requestAnimationFrame(this.#g);
        }
        #F(t, i) {
          const [h, d] = this.currentPath.at(-1);
          if (this.currentPath.length > 1 && t === h && i === d)
            return;
          const E = this.currentPath;
          let k = this.#h;
          if (E.push([t, i]), this.#u = !0, E.length <= 2) {
            k.moveTo(...E[0]), k.lineTo(t, i);
            return;
          }
          E.length === 3 && (this.#h = k = new Path2D(), k.moveTo(...E[0])), this.#v(k, ...E.at(-3), ...E.at(-2), t, i);
        }
        #I() {
          if (this.currentPath.length === 0)
            return;
          const t = this.currentPath.at(-1);
          this.#h.lineTo(...t);
        }
        #R(t, i) {
          this.#g = null, t = Math.min(Math.max(t, 0), this.canvas.width), i = Math.min(Math.max(i, 0), this.canvas.height), this.#F(t, i), this.#I();
          let h;
          if (this.currentPath.length !== 1)
            h = this.#x();
          else {
            const M = [t, i];
            h = [[M, M.slice(), M.slice(), M]];
          }
          const d = this.#h, E = this.currentPath;
          this.currentPath = [], this.#h = new Path2D();
          const k = () => {
            this.allRawPaths.push(E), this.paths.push(h), this.bezierPath2D.push(d), this._uiManager.rebuild(this);
          }, L = () => {
            this.allRawPaths.pop(), this.paths.pop(), this.bezierPath2D.pop(), this.paths.length === 0 ? this.remove() : (this.canvas || (this.#C(), this.#L()), this.#N());
          };
          this.addCommands({
            cmd: k,
            undo: L,
            mustExec: !0
          });
        }
        #A() {
          if (!this.#u)
            return;
          this.#u = !1;
          const t = Math.ceil(this.thickness * this.parentScale), i = this.currentPath.slice(-3), h = i.map((k) => k[0]), d = i.map((k) => k[1]);
          Math.min(...h) - t, Math.max(...h) + t, Math.min(...d) - t, Math.max(...d) + t;
          const {
            ctx: E
          } = this;
          E.save(), E.clearRect(0, 0, this.canvas.width, this.canvas.height);
          for (const k of this.bezierPath2D)
            E.stroke(k);
          E.stroke(this.#h), E.restore();
        }
        #v(t, i, h, d, E, k, L) {
          const M = (i + d) / 2, B = (h + E) / 2, U = (d + k) / 2, q = (E + L) / 2;
          t.bezierCurveTo(M + 2 * (d - M) / 3, B + 2 * (E - B) / 3, U + 2 * (d - U) / 3, q + 2 * (E - q) / 3, U, q);
        }
        #x() {
          const t = this.currentPath;
          if (t.length <= 2)
            return [[t[0], t[0], t.at(-1), t.at(-1)]];
          const i = [];
          let h, [d, E] = t[0];
          for (h = 1; h < t.length - 2; h++) {
            const [Z, K] = t[h], [Y, G] = t[h + 1], j = (Z + Y) / 2, Q = (K + G) / 2, J = [d + 2 * (Z - d) / 3, E + 2 * (K - E) / 3], tt = [j + 2 * (Z - j) / 3, Q + 2 * (K - Q) / 3];
            i.push([[d, E], J, tt, [j, Q]]), [d, E] = [j, Q];
          }
          const [k, L] = t[h], [M, B] = t[h + 1], U = [d + 2 * (k - d) / 3, E + 2 * (L - E) / 3], q = [M + 2 * (k - M) / 3, B + 2 * (L - B) / 3];
          return i.push([[d, E], U, q, [M, B]]), i;
        }
        #E() {
          if (this.isEmpty()) {
            this.#_();
            return;
          }
          this.#y();
          const {
            canvas: t,
            ctx: i
          } = this;
          i.setTransform(1, 0, 0, 1, 0, 0), i.clearRect(0, 0, t.width, t.height), this.#_();
          for (const h of this.bezierPath2D)
            i.stroke(h);
        }
        commit() {
          this.#l || (super.commit(), this.isEditing = !1, this.disableEditMode(), this.setInForeground(), this.#l = !0, this.div.classList.add("disabled"), this.#N(!0), this.select(), this.parent.addInkEditorIfNeeded(!0), this.moveInDOM(), this.div.focus({
            preventScroll: !0
          }));
        }
        focusin(t) {
          this._focusEventsAllowed && (super.focusin(t), this.enableEditMode());
        }
        canvasPointerdown(t) {
          t.button !== 0 || !this.isInEditMode() || this.#l || (this.setInForeground(), t.preventDefault(), this.div.contains(document.activeElement) || this.div.focus({
            preventScroll: !0
          }), this.#S(t.offsetX, t.offsetY));
        }
        canvasPointermove(t) {
          t.preventDefault(), this.#F(t.offsetX, t.offsetY);
        }
        canvasPointerup(t) {
          t.preventDefault(), this.#D(t);
        }
        canvasPointerleave(t) {
          this.#D(t);
        }
        #D(t) {
          this.canvas.removeEventListener("pointerleave", this.#n), this.canvas.removeEventListener("pointermove", this.#s), this.canvas.removeEventListener("pointerup", this.#r), this.canvas.addEventListener("pointerdown", this.#i), this.#a && clearTimeout(this.#a), this.#a = setTimeout(() => {
            this.#a = null, this.canvas.removeEventListener("contextmenu", n.noContextMenu);
          }, 10), this.#R(t.offsetX, t.offsetY), this.addToAnnotationStorage(), this.setInBackground();
        }
        #C() {
          this.canvas = document.createElement("canvas"), this.canvas.width = this.canvas.height = 0, this.canvas.className = "inkEditorCanvas", this.canvas.setAttribute("data-l10n-id", "pdfjs-ink-canvas"), this.div.append(this.canvas), this.ctx = this.canvas.getContext("2d");
        }
        #L() {
          this.#c = new ResizeObserver((t) => {
            const i = t[0].contentRect;
            i.width && i.height && this.setDimensions(i.width, i.height);
          }), this.#c.observe(this.div);
        }
        get isResizable() {
          return !this.isEmpty() && this.#l;
        }
        render() {
          if (this.div)
            return this.div;
          let t, i;
          this.width && (t = this.x, i = this.y), super.render(), this.div.setAttribute("data-l10n-id", "pdfjs-ink");
          const [h, d, E, k] = this.#w();
          if (this.setAt(h, d, 0, 0), this.setDims(E, k), this.#C(), this.width) {
            const [L, M] = this.parentDimensions;
            this.setAspectRatio(this.width * L, this.height * M), this.setAt(t * L, i * M, this.width * L, this.height * M), this.#d = !0, this.#T(), this.setDims(this.width * L, this.height * M), this.#E(), this.div.classList.add("disabled");
          } else
            this.div.classList.add("editing"), this.enableEditMode();
          return this.#L(), this.div;
        }
        #T() {
          if (!this.#d)
            return;
          const [t, i] = this.parentDimensions;
          this.canvas.width = Math.ceil(this.width * t), this.canvas.height = Math.ceil(this.height * i), this.#_();
        }
        setDimensions(t, i) {
          const h = Math.round(t), d = Math.round(i);
          if (this.#o === h && this.#p === d)
            return;
          this.#o = h, this.#p = d, this.canvas.style.visibility = "hidden";
          const [E, k] = this.parentDimensions;
          this.width = t / E, this.height = i / k, this.fixAndSetPosition(), this.#l && this.#M(t, i), this.#T(), this.#E(), this.canvas.style.visibility = "visible", this.fixDims();
        }
        #M(t, i) {
          const h = this.#H(), d = (t - h) / this.#e, E = (i - h) / this.#t;
          this.scaleFactor = Math.min(d, E);
        }
        #_() {
          const t = this.#H() / 2;
          this.ctx.setTransform(this.scaleFactor, 0, 0, this.scaleFactor, this.translationX * this.scaleFactor + t, this.translationY * this.scaleFactor + t);
        }
        static #P(t) {
          const i = new Path2D();
          for (let h = 0, d = t.length; h < d; h++) {
            const [E, k, L, M] = t[h];
            h === 0 && i.moveTo(...E), i.bezierCurveTo(k[0], k[1], L[0], L[1], M[0], M[1]);
          }
          return i;
        }
        static #U(t, i, h) {
          const [d, E, k, L] = i;
          switch (h) {
            case 0:
              for (let M = 0, B = t.length; M < B; M += 2)
                t[M] += d, t[M + 1] = L - t[M + 1];
              break;
            case 90:
              for (let M = 0, B = t.length; M < B; M += 2) {
                const U = t[M];
                t[M] = t[M + 1] + d, t[M + 1] = U + E;
              }
              break;
            case 180:
              for (let M = 0, B = t.length; M < B; M += 2)
                t[M] = k - t[M], t[M + 1] += E;
              break;
            case 270:
              for (let M = 0, B = t.length; M < B; M += 2) {
                const U = t[M];
                t[M] = k - t[M + 1], t[M + 1] = L - U;
              }
              break;
            default:
              throw new Error("Invalid rotation");
          }
          return t;
        }
        static #$(t, i, h) {
          const [d, E, k, L] = i;
          switch (h) {
            case 0:
              for (let M = 0, B = t.length; M < B; M += 2)
                t[M] -= d, t[M + 1] = L - t[M + 1];
              break;
            case 90:
              for (let M = 0, B = t.length; M < B; M += 2) {
                const U = t[M];
                t[M] = t[M + 1] - E, t[M + 1] = U - d;
              }
              break;
            case 180:
              for (let M = 0, B = t.length; M < B; M += 2)
                t[M] = k - t[M], t[M + 1] -= E;
              break;
            case 270:
              for (let M = 0, B = t.length; M < B; M += 2) {
                const U = t[M];
                t[M] = L - t[M + 1], t[M + 1] = k - U;
              }
              break;
            default:
              throw new Error("Invalid rotation");
          }
          return t;
        }
        #q(t, i, h, d) {
          const E = [], k = this.thickness / 2, L = t * i + k, M = t * h + k;
          for (const B of this.paths) {
            const U = [], q = [];
            for (let Z = 0, K = B.length; Z < K; Z++) {
              const [Y, G, j, Q] = B[Z];
              if (Y[0] === Q[0] && Y[1] === Q[1] && K === 1) {
                const et = t * Y[0] + L, D = t * Y[1] + M;
                U.push(et, D), q.push(et, D);
                break;
              }
              const J = t * Y[0] + L, tt = t * Y[1] + M, rt = t * G[0] + L, ut = t * G[1] + M, dt = t * j[0] + L, ft = t * j[1] + M, lt = t * Q[0] + L, ot = t * Q[1] + M;
              Z === 0 && (U.push(J, tt), q.push(J, tt)), U.push(rt, ut, dt, ft, lt, ot), q.push(rt, ut), Z === K - 1 && q.push(lt, ot);
            }
            E.push({
              bezier: p.#U(U, d, this.rotation),
              points: p.#U(q, d, this.rotation)
            });
          }
          return E;
        }
        #V() {
          let t = 1 / 0, i = -1 / 0, h = 1 / 0, d = -1 / 0;
          for (const E of this.paths)
            for (const [k, L, M, B] of E) {
              const U = s.Util.bezierBoundingBox(...k, ...L, ...M, ...B);
              t = Math.min(t, U[0]), h = Math.min(h, U[1]), i = Math.max(i, U[2]), d = Math.max(d, U[3]);
            }
          return [t, h, i, d];
        }
        #H() {
          return this.#l ? Math.ceil(this.thickness * this.parentScale) : 0;
        }
        #N(t = !1) {
          if (this.isEmpty())
            return;
          if (!this.#l) {
            this.#E();
            return;
          }
          const i = this.#V(), h = this.#H();
          this.#e = Math.max(S.AnnotationEditor.MIN_SIZE, i[2] - i[0]), this.#t = Math.max(S.AnnotationEditor.MIN_SIZE, i[3] - i[1]);
          const d = Math.ceil(h + this.#e * this.scaleFactor), E = Math.ceil(h + this.#t * this.scaleFactor), [k, L] = this.parentDimensions;
          this.width = d / k, this.height = E / L, this.setAspectRatio(d, E);
          const M = this.translationX, B = this.translationY;
          this.translationX = -i[0], this.translationY = -i[1], this.#T(), this.#E(), this.#o = d, this.#p = E, this.setDims(d, E);
          const U = t ? h / this.scaleFactor / 2 : 0;
          this.translate(M - this.translationX - U, B - this.translationY - U);
        }
        static deserialize(t, i, h) {
          if (t instanceof _.InkAnnotationElement)
            return null;
          const d = super.deserialize(t, i, h);
          d.thickness = t.thickness, d.color = s.Util.makeHexColor(...t.color), d.opacity = t.opacity;
          const [E, k] = d.pageDimensions, L = d.width * E, M = d.height * k, B = d.parentScale, U = t.thickness / 2;
          d.#l = !0, d.#o = Math.round(L), d.#p = Math.round(M);
          const {
            paths: q,
            rect: Z,
            rotation: K
          } = t;
          for (let {
            bezier: G
          } of q) {
            G = p.#$(G, Z, K);
            const j = [];
            d.paths.push(j);
            let Q = B * (G[0] - U), J = B * (G[1] - U);
            for (let rt = 2, ut = G.length; rt < ut; rt += 6) {
              const dt = B * (G[rt] - U), ft = B * (G[rt + 1] - U), lt = B * (G[rt + 2] - U), ot = B * (G[rt + 3] - U), et = B * (G[rt + 4] - U), D = B * (G[rt + 5] - U);
              j.push([[Q, J], [dt, ft], [lt, ot], [et, D]]), Q = et, J = D;
            }
            const tt = this.#P(j);
            d.bezierPath2D.push(tt);
          }
          const Y = d.#V();
          return d.#e = Math.max(S.AnnotationEditor.MIN_SIZE, Y[2] - Y[0]), d.#t = Math.max(S.AnnotationEditor.MIN_SIZE, Y[3] - Y[1]), d.#M(L, M), d;
        }
        serialize() {
          if (this.isEmpty())
            return null;
          const t = this.getRect(0, 0), i = S.AnnotationEditor._colorManager.convert(this.ctx.strokeStyle);
          return {
            annotationType: s.AnnotationEditorType.INK,
            color: i,
            thickness: this.thickness,
            opacity: this.opacity,
            paths: this.#q(this.scaleFactor / this.parentScale, this.translationX, this.translationY, t),
            pageIndex: this.pageIndex,
            rect: t,
            rotation: this.rotation,
            structTreeParentId: this._structTreeParentId
          };
        }
      }
      class F extends S.AnnotationEditor {
        #t = null;
        #e = null;
        #s = null;
        #n = null;
        #r = null;
        #i = "";
        #a = null;
        #h = null;
        #l = null;
        #u = !1;
        #d = !1;
        static _type = "stamp";
        static _editorType = s.AnnotationEditorType.STAMP;
        constructor(t) {
          super({
            ...t,
            name: "stampEditor"
          }), this.#n = t.bitmapUrl, this.#r = t.bitmapFile;
        }
        static initialize(t, i) {
          S.AnnotationEditor.initialize(t, i);
        }
        static get supportedTypes() {
          const t = ["apng", "avif", "bmp", "gif", "jpeg", "png", "svg+xml", "webp", "x-icon"];
          return (0, s.shadow)(this, "supportedTypes", t.map((i) => `image/${i}`));
        }
        static get supportedTypesStr() {
          return (0, s.shadow)(this, "supportedTypesStr", this.supportedTypes.join(","));
        }
        static isHandlingMimeForPasting(t) {
          return this.supportedTypes.includes(t);
        }
        static paste(t, i) {
          i.pasteEditor(s.AnnotationEditorType.STAMP, {
            bitmapFile: t.getAsFile()
          });
        }
        #c(t, i = !1) {
          if (!t) {
            this.remove();
            return;
          }
          this.#t = t.bitmap, i || (this.#e = t.id, this.#u = t.isSvg), t.file && (this.#i = t.file.name), this.#g();
        }
        #o() {
          this.#s = null, this._uiManager.enableWaiting(!1), this.#a && this.div.focus();
        }
        #p() {
          if (this.#e) {
            this._uiManager.enableWaiting(!0), this._uiManager.imageManager.getFromId(this.#e).then((i) => this.#c(i, !0)).finally(() => this.#o());
            return;
          }
          if (this.#n) {
            const i = this.#n;
            this.#n = null, this._uiManager.enableWaiting(!0), this.#s = this._uiManager.imageManager.getFromUrl(i).then((h) => this.#c(h)).finally(() => this.#o());
            return;
          }
          if (this.#r) {
            const i = this.#r;
            this.#r = null, this._uiManager.enableWaiting(!0), this.#s = this._uiManager.imageManager.getFromFile(i).then((h) => this.#c(h)).finally(() => this.#o());
            return;
          }
          const t = document.createElement("input");
          t.type = "file", t.accept = F.supportedTypesStr, this.#s = new Promise((i) => {
            t.addEventListener("change", async () => {
              if (!t.files || t.files.length === 0)
                this.remove();
              else {
                this._uiManager.enableWaiting(!0);
                const h = await this._uiManager.imageManager.getFromFile(t.files[0]);
                this.#c(h);
              }
              i();
            }), t.addEventListener("cancel", () => {
              this.remove(), i();
            });
          }).finally(() => this.#o()), t.click();
        }
        remove() {
          this.#e && (this.#t = null, this._uiManager.imageManager.deleteId(this.#e), this.#a?.remove(), this.#a = null, this.#h?.disconnect(), this.#h = null, this.#l && (clearTimeout(this.#l), this.#l = null)), super.remove();
        }
        rebuild() {
          if (!this.parent) {
            this.#e && this.#p();
            return;
          }
          super.rebuild(), this.div !== null && (this.#e && this.#a === null && this.#p(), this.isAttachedToDOM || this.parent.add(this));
        }
        onceAdded() {
          this._isDraggable = !0, this.div.focus();
        }
        isEmpty() {
          return !(this.#s || this.#t || this.#n || this.#r || this.#e);
        }
        get isResizable() {
          return !0;
        }
        render() {
          if (this.div)
            return this.div;
          let t, i;
          if (this.width && (t = this.x, i = this.y), super.render(), this.div.hidden = !0, this.addAltTextButton(), this.#t ? this.#g() : this.#p(), this.width) {
            const [h, d] = this.parentDimensions;
            this.setAt(t * h, i * d, this.width * h, this.height * d);
          }
          return this.div;
        }
        #g() {
          const {
            div: t
          } = this;
          let {
            width: i,
            height: h
          } = this.#t;
          const [d, E] = this.pageDimensions, k = 0.75;
          if (this.width)
            i = this.width * d, h = this.height * E;
          else if (i > k * d || h > k * E) {
            const U = Math.min(k * d / i, k * E / h);
            i *= U, h *= U;
          }
          const [L, M] = this.parentDimensions;
          this.setDims(i * L / d, h * M / E), this._uiManager.enableWaiting(!1);
          const B = this.#a = document.createElement("canvas");
          t.append(B), t.hidden = !1, this.#m(i, h), this.#y(), this.#d || (this.parent.addUndoableEditor(this), this.#d = !0), this._reportTelemetry({
            action: "inserted_image"
          }), this.#i && B.setAttribute("aria-label", this.#i);
        }
        #f(t, i) {
          const [h, d] = this.parentDimensions;
          this.width = t / h, this.height = i / d, this.setDims(t, i), this._initialOptions?.isCentered ? this.center() : this.fixAndSetPosition(), this._initialOptions = null, this.#l !== null && clearTimeout(this.#l);
          const E = 200;
          this.#l = setTimeout(() => {
            this.#l = null, this.#m(t, i);
          }, E);
        }
        #b(t, i) {
          const {
            width: h,
            height: d
          } = this.#t;
          let E = h, k = d, L = this.#t;
          for (; E > 2 * t || k > 2 * i; ) {
            const M = E, B = k;
            E > 2 * t && (E = E >= 16384 ? Math.floor(E / 2) - 1 : Math.ceil(E / 2)), k > 2 * i && (k = k >= 16384 ? Math.floor(k / 2) - 1 : Math.ceil(k / 2));
            const U = new OffscreenCanvas(E, k);
            U.getContext("2d").drawImage(L, 0, 0, M, B, 0, 0, E, k), L = U.transferToImageBitmap();
          }
          return L;
        }
        #m(t, i) {
          t = Math.ceil(t), i = Math.ceil(i);
          const h = this.#a;
          if (!h || h.width === t && h.height === i)
            return;
          h.width = t, h.height = i;
          const d = this.#u ? this.#t : this.#b(t, i);
          if (this._uiManager.hasMLManager && !this.hasAltText()) {
            const k = new OffscreenCanvas(t, i);
            k.getContext("2d").drawImage(d, 0, 0, d.width, d.height, 0, 0, t, i), k.convertToBlob().then((M) => {
              const B = new FileReader();
              B.onload = () => {
                const U = B.result;
                this._uiManager.mlGuess({
                  service: "image-to-text",
                  request: {
                    imageData: U
                  }
                }).then((q) => {
                  const Z = q?.output || "";
                  this.parent && Z && !this.hasAltText() && (this.altTextData = {
                    altText: Z,
                    decorative: !1
                  });
                });
              }, B.readAsDataURL(M);
            });
          }
          const E = h.getContext("2d");
          E.filter = this._uiManager.hcmFilter, E.drawImage(d, 0, 0, d.width, d.height, 0, 0, t, i);
        }
        getImageForAltText() {
          return this.#a;
        }
        #w(t) {
          if (t) {
            if (this.#u) {
              const d = this._uiManager.imageManager.getSvgUrl(this.#e);
              if (d)
                return d;
            }
            const i = document.createElement("canvas");
            return {
              width: i.width,
              height: i.height
            } = this.#t, i.getContext("2d").drawImage(this.#t, 0, 0), i.toDataURL();
          }
          if (this.#u) {
            const [i, h] = this.pageDimensions, d = Math.round(this.width * i * n.PixelsPerInch.PDF_TO_CSS_UNITS), E = Math.round(this.height * h * n.PixelsPerInch.PDF_TO_CSS_UNITS), k = new OffscreenCanvas(d, E);
            return k.getContext("2d").drawImage(this.#t, 0, 0, this.#t.width, this.#t.height, 0, 0, d, E), k.transferToImageBitmap();
          }
          return structuredClone(this.#t);
        }
        #y() {
          this.#h = new ResizeObserver((t) => {
            const i = t[0].contentRect;
            i.width && i.height && this.#f(i.width, i.height);
          }), this.#h.observe(this.div);
        }
        static deserialize(t, i, h) {
          if (t instanceof _.StampAnnotationElement)
            return null;
          const d = super.deserialize(t, i, h), {
            rect: E,
            bitmapUrl: k,
            bitmapId: L,
            isSvg: M,
            accessibilityData: B
          } = t;
          L && h.imageManager.isValidId(L) ? d.#e = L : d.#n = k, d.#u = M;
          const [U, q] = d.pageDimensions;
          return d.width = (E[2] - E[0]) / U, d.height = (E[3] - E[1]) / q, B && (d.altTextData = B), d;
        }
        serialize(t = !1, i = null) {
          if (this.isEmpty())
            return null;
          const h = {
            annotationType: s.AnnotationEditorType.STAMP,
            bitmapId: this.#e,
            pageIndex: this.pageIndex,
            rect: this.getRect(0, 0),
            rotation: this.rotation,
            isSvg: this.#u,
            structTreeParentId: this._structTreeParentId
          };
          if (t)
            return h.bitmapUrl = this.#w(!0), h.accessibilityData = this.altTextData, h;
          const {
            decorative: d,
            altText: E
          } = this.altTextData;
          if (!d && E && (h.accessibilityData = {
            type: "Figure",
            alt: E
          }), i === null)
            return h;
          i.stamps ||= /* @__PURE__ */ new Map();
          const k = this.#u ? (h.rect[2] - h.rect[0]) * (h.rect[3] - h.rect[1]) : null;
          if (!i.stamps.has(this.#e))
            i.stamps.set(this.#e, {
              area: k,
              serialized: h
            }), h.bitmap = this.#w(!1);
          else if (this.#u) {
            const L = i.stamps.get(this.#e);
            k > L.area && (L.area = k, L.serialized.bitmap.close(), L.serialized.bitmap = this.#w(!1));
          }
          return h;
        }
      }
      class r {
        #t;
        #e = !1;
        #s = null;
        #n = null;
        #r = null;
        #i = null;
        #a = null;
        #h = /* @__PURE__ */ new Map();
        #l = !1;
        #u = !1;
        #d = !1;
        #c = null;
        #o;
        static _initialized = !1;
        static #p = new Map([C, p, F, f].map((t) => [t._editorType, t]));
        constructor({
          uiManager: t,
          pageIndex: i,
          div: h,
          accessibilityManager: d,
          annotationLayer: E,
          drawLayer: k,
          textLayer: L,
          viewport: M,
          l10n: B
        }) {
          const U = [...r.#p.values()];
          if (!r._initialized) {
            r._initialized = !0;
            for (const q of U)
              q.initialize(B, t);
          }
          t.registerEditorTypes(U), this.#o = t, this.pageIndex = i, this.div = h, this.#t = d, this.#s = E, this.viewport = M, this.#c = L, this.drawLayer = k, this.#o.addLayer(this);
        }
        get isEmpty() {
          return this.#h.size === 0;
        }
        get isInvisible() {
          return this.isEmpty && this.#o.getMode() === s.AnnotationEditorType.NONE;
        }
        updateToolbar(t) {
          this.#o.updateToolbar(t);
        }
        updateMode(t = this.#o.getMode()) {
          switch (this.#w(), t) {
            case s.AnnotationEditorType.NONE:
              this.disableTextSelection(), this.togglePointerEvents(!1), this.toggleAnnotationLayerPointerEvents(!0), this.disableClick();
              return;
            case s.AnnotationEditorType.INK:
              this.addInkEditorIfNeeded(!1), this.disableTextSelection(), this.togglePointerEvents(!0), this.disableClick();
              break;
            case s.AnnotationEditorType.HIGHLIGHT:
              this.enableTextSelection(), this.togglePointerEvents(!1), this.disableClick();
              break;
            default:
              this.disableTextSelection(), this.togglePointerEvents(!0), this.enableClick();
          }
          this.toggleAnnotationLayerPointerEvents(!1);
          const {
            classList: i
          } = this.div;
          for (const h of r.#p.values())
            i.toggle(`${h._type}Editing`, t === h._editorType);
          this.div.hidden = !1;
        }
        hasTextLayer(t) {
          return t === this.#c?.div;
        }
        addInkEditorIfNeeded(t) {
          if (this.#o.getMode() !== s.AnnotationEditorType.INK)
            return;
          if (!t) {
            for (const h of this.#h.values())
              if (h.isEmpty()) {
                h.setInBackground();
                return;
              }
          }
          this.createAndAddNewEditor({
            offsetX: 0,
            offsetY: 0
          }, !1).setInBackground();
        }
        setEditingState(t) {
          this.#o.setEditingState(t);
        }
        addCommands(t) {
          this.#o.addCommands(t);
        }
        togglePointerEvents(t = !1) {
          this.div.classList.toggle("disabled", !t);
        }
        toggleAnnotationLayerPointerEvents(t = !1) {
          this.#s?.div.classList.toggle("disabled", !t);
        }
        enable() {
          this.div.tabIndex = 0, this.togglePointerEvents(!0);
          const t = /* @__PURE__ */ new Set();
          for (const h of this.#h.values())
            h.enableEditing(), h.show(!0), h.annotationElementId && (this.#o.removeChangedExistingAnnotation(h), t.add(h.annotationElementId));
          if (!this.#s)
            return;
          const i = this.#s.getEditableAnnotations();
          for (const h of i) {
            if (h.hide(), this.#o.isDeletedAnnotationElement(h.data.id) || t.has(h.data.id))
              continue;
            const d = this.deserialize(h);
            d && (this.addOrRebuild(d), d.enableEditing());
          }
        }
        disable() {
          this.#d = !0, this.div.tabIndex = -1, this.togglePointerEvents(!1);
          const t = /* @__PURE__ */ new Map(), i = /* @__PURE__ */ new Map();
          for (const d of this.#h.values())
            if (d.disableEditing(), !!d.annotationElementId) {
              if (d.serialize() !== null) {
                t.set(d.annotationElementId, d);
                continue;
              } else
                i.set(d.annotationElementId, d);
              this.getEditableAnnotation(d.annotationElementId)?.show(), d.remove();
            }
          if (this.#s) {
            const d = this.#s.getEditableAnnotations();
            for (const E of d) {
              const {
                id: k
              } = E.data;
              if (this.#o.isDeletedAnnotationElement(k))
                continue;
              let L = i.get(k);
              if (L) {
                L.resetAnnotationElement(E), L.show(!1), E.show();
                continue;
              }
              L = t.get(k), L && (this.#o.addChangedExistingAnnotation(L), L.renderAnnotationElement(E), L.show(!1)), E.show();
            }
          }
          this.#w(), this.isEmpty && (this.div.hidden = !0);
          const {
            classList: h
          } = this.div;
          for (const d of r.#p.values())
            h.remove(`${d._type}Editing`);
          this.disableTextSelection(), this.toggleAnnotationLayerPointerEvents(!0), this.#d = !1;
        }
        getEditableAnnotation(t) {
          return this.#s?.getEditableAnnotation(t) || null;
        }
        setActiveEditor(t) {
          this.#o.getActive() !== t && this.#o.setActiveEditor(t);
        }
        enableTextSelection() {
          this.div.tabIndex = -1, this.#c?.div && !this.#i && (this.#i = this.#g.bind(this), this.#c.div.addEventListener("pointerdown", this.#i), this.#c.div.classList.add("highlighting"));
        }
        disableTextSelection() {
          this.div.tabIndex = 0, this.#c?.div && this.#i && (this.#c.div.removeEventListener("pointerdown", this.#i), this.#i = null, this.#c.div.classList.remove("highlighting"));
        }
        #g(t) {
          if (this.#o.unselectAll(), t.target === this.#c.div) {
            const {
              isMac: i
            } = s.FeatureTest.platform;
            if (t.button !== 0 || t.ctrlKey && i)
              return;
            this.#o.showAllEditors("highlight", !0, !0), this.#c.div.classList.add("free"), f.startHighlighting(this, this.#o.direction === "ltr", t), this.#c.div.addEventListener("pointerup", () => {
              this.#c.div.classList.remove("free");
            }, {
              once: !0
            }), t.preventDefault();
          }
        }
        enableClick() {
          this.#r || (this.#r = this.pointerdown.bind(this), this.#n = this.pointerup.bind(this), this.div.addEventListener("pointerdown", this.#r), this.div.addEventListener("pointerup", this.#n));
        }
        disableClick() {
          this.#r && (this.div.removeEventListener("pointerdown", this.#r), this.div.removeEventListener("pointerup", this.#n), this.#r = null, this.#n = null);
        }
        attach(t) {
          this.#h.set(t.id, t);
          const {
            annotationElementId: i
          } = t;
          i && this.#o.isDeletedAnnotationElement(i) && this.#o.removeDeletedAnnotationElement(t);
        }
        detach(t) {
          this.#h.delete(t.id), this.#t?.removePointerInTextLayer(t.contentDiv), !this.#d && t.annotationElementId && this.#o.addDeletedAnnotationElement(t);
        }
        remove(t) {
          this.detach(t), this.#o.removeEditor(t), t.div.remove(), t.isAttachedToDOM = !1, this.#u || this.addInkEditorIfNeeded(!1);
        }
        changeParent(t) {
          t.parent !== this && (t.parent && t.annotationElementId && (this.#o.addDeletedAnnotationElement(t.annotationElementId), S.AnnotationEditor.deleteAnnotationElement(t), t.annotationElementId = null), this.attach(t), t.parent?.detach(t), t.setParent(this), t.div && t.isAttachedToDOM && (t.div.remove(), this.div.append(t.div)));
        }
        add(t) {
          if (!(t.parent === this && t.isAttachedToDOM)) {
            if (this.changeParent(t), this.#o.addEditor(t), this.attach(t), !t.isAttachedToDOM) {
              const i = t.render();
              this.div.append(i), t.isAttachedToDOM = !0;
            }
            t.fixAndSetPosition(), t.onceAdded(), this.#o.addToAnnotationStorage(t), t._reportTelemetry(t.telemetryInitialData);
          }
        }
        moveEditorInDOM(t) {
          if (!t.isAttachedToDOM)
            return;
          const {
            activeElement: i
          } = document;
          t.div.contains(i) && !this.#a && (t._focusEventsAllowed = !1, this.#a = setTimeout(() => {
            this.#a = null, t.div.contains(document.activeElement) ? t._focusEventsAllowed = !0 : (t.div.addEventListener("focusin", () => {
              t._focusEventsAllowed = !0;
            }, {
              once: !0
            }), i.focus());
          }, 0)), t._structTreeParentId = this.#t?.moveElementInDOM(this.div, t.div, t.contentDiv, !0);
        }
        addOrRebuild(t) {
          t.needsToBeRebuilt() ? (t.parent ||= this, t.rebuild(), t.show()) : this.add(t);
        }
        addUndoableEditor(t) {
          const i = () => t._uiManager.rebuild(t), h = () => {
            t.remove();
          };
          this.addCommands({
            cmd: i,
            undo: h,
            mustExec: !1
          });
        }
        getNextId() {
          return this.#o.getId();
        }
        get #f() {
          return r.#p.get(this.#o.getMode());
        }
        #b(t) {
          const i = this.#f;
          return i ? new i.prototype.constructor(t) : null;
        }
        canCreateNewEmptyEditor() {
          return this.#f?.canCreateNewEmptyEditor();
        }
        pasteEditor(t, i) {
          this.#o.updateToolbar(t), this.#o.updateMode(t);
          const {
            offsetX: h,
            offsetY: d
          } = this.#m(), E = this.getNextId(), k = this.#b({
            parent: this,
            id: E,
            x: h,
            y: d,
            uiManager: this.#o,
            isCentered: !0,
            ...i
          });
          k && this.add(k);
        }
        deserialize(t) {
          return r.#p.get(t.annotationType ?? t.annotationEditorType)?.deserialize(t, this, this.#o) || null;
        }
        createAndAddNewEditor(t, i, h = {}) {
          const d = this.getNextId(), E = this.#b({
            parent: this,
            id: d,
            x: t.offsetX,
            y: t.offsetY,
            uiManager: this.#o,
            isCentered: i,
            ...h
          });
          return E && this.add(E), E;
        }
        #m() {
          const {
            x: t,
            y: i,
            width: h,
            height: d
          } = this.div.getBoundingClientRect(), E = Math.max(0, t), k = Math.max(0, i), L = Math.min(window.innerWidth, t + h), M = Math.min(window.innerHeight, i + d), B = (E + L) / 2 - t, U = (k + M) / 2 - i, [q, Z] = this.viewport.rotation % 180 === 0 ? [B, U] : [U, B];
          return {
            offsetX: q,
            offsetY: Z
          };
        }
        addNewEditor() {
          this.createAndAddNewEditor(this.#m(), !0);
        }
        setSelected(t) {
          this.#o.setSelected(t);
        }
        toggleSelected(t) {
          this.#o.toggleSelected(t);
        }
        isSelected(t) {
          return this.#o.isSelected(t);
        }
        unselect(t) {
          this.#o.unselect(t);
        }
        pointerup(t) {
          const {
            isMac: i
          } = s.FeatureTest.platform;
          if (!(t.button !== 0 || t.ctrlKey && i) && t.target === this.div && this.#l) {
            if (this.#l = !1, !this.#e) {
              this.#e = !0;
              return;
            }
            if (this.#o.getMode() === s.AnnotationEditorType.STAMP) {
              this.#o.unselectAll();
              return;
            }
            this.createAndAddNewEditor(t, !1);
          }
        }
        pointerdown(t) {
          if (this.#o.getMode() === s.AnnotationEditorType.HIGHLIGHT && this.enableTextSelection(), this.#l) {
            this.#l = !1;
            return;
          }
          const {
            isMac: i
          } = s.FeatureTest.platform;
          if (t.button !== 0 || t.ctrlKey && i || t.target !== this.div)
            return;
          this.#l = !0;
          const h = this.#o.getActive();
          this.#e = !h || h.isEmpty();
        }
        findNewParent(t, i, h) {
          const d = this.#o.findParent(i, h);
          return d === null || d === this ? !1 : (d.changeParent(t), !0);
        }
        destroy() {
          this.#o.getActive()?.parent === this && (this.#o.commitOrRemove(), this.#o.setActiveEditor(null)), this.#a && (clearTimeout(this.#a), this.#a = null);
          for (const t of this.#h.values())
            this.#t?.removePointerInTextLayer(t.contentDiv), t.setParent(null), t.isAttachedToDOM = !1, t.div.remove();
          this.div = null, this.#h.clear(), this.#o.removeLayer(this);
        }
        #w() {
          this.#u = !0;
          for (const t of this.#h.values())
            t.isEmpty() && t.remove();
          this.#u = !1;
        }
        render({
          viewport: t
        }) {
          this.viewport = t, (0, n.setLayerDimensions)(this.div, t);
          for (const i of this.#o.getEditors(this.pageIndex))
            this.add(i), i.rebuild();
          this.updateMode();
        }
        update({
          viewport: t
        }) {
          this.#o.commitOrRemove(), this.#w();
          const i = this.viewport.rotation, h = t.rotation;
          if (this.viewport = t, (0, n.setLayerDimensions)(this.div, {
            rotation: h
          }), i !== h)
            for (const d of this.#h.values())
              d.rotate(h);
          this.addInkEditorIfNeeded(!1);
        }
        get pageDimensions() {
          const {
            pageWidth: t,
            pageHeight: i
          } = this.viewport.rawDims;
          return [t, i];
        }
        get scale() {
          return this.#o.viewParameters.realScale;
        }
      }
    })
  ),
  /***/
  259: (
    /***/
    ((V, l, a) => {
      a.d(l, {
        /* harmony export */
        ColorPicker: () => (
          /* binding */
          _
        )
        /* harmony export */
      });
      var s = a(292), S = a(830), v = a(419);
      class _ {
        #t = this.#g.bind(this);
        #e = this.#b.bind(this);
        #s = null;
        #n = null;
        #r;
        #i = null;
        #a = !1;
        #h = !1;
        #l = null;
        #u;
        #d = null;
        #c;
        static get _keyboardManager() {
          return (0, s.shadow)(this, "_keyboardManager", new S.KeyboardManager([[["Escape", "mac+Escape"], _.prototype._hideDropdownFromKeyboard], [[" ", "mac+ "], _.prototype._colorSelectFromKeyboard], [["ArrowDown", "ArrowRight", "mac+ArrowDown", "mac+ArrowRight"], _.prototype._moveToNext], [["ArrowUp", "ArrowLeft", "mac+ArrowUp", "mac+ArrowLeft"], _.prototype._moveToPrevious], [["Home", "mac+Home"], _.prototype._moveToBeginning], [["End", "mac+End"], _.prototype._moveToEnd]]));
        }
        constructor({
          editor: C = null,
          uiManager: T = null
        }) {
          C ? (this.#h = !1, this.#c = s.AnnotationEditorParamsType.HIGHLIGHT_COLOR, this.#l = C) : (this.#h = !0, this.#c = s.AnnotationEditorParamsType.HIGHLIGHT_DEFAULT_COLOR), this.#d = C?._uiManager || T, this.#u = this.#d._eventBus, this.#r = C?.color || this.#d?.highlightColors.values().next().value || "#FFFF98";
        }
        renderButton() {
          const C = this.#s = document.createElement("button");
          C.className = "colorPicker", C.tabIndex = "0", C.setAttribute("data-l10n-id", "pdfjs-editor-colorpicker-button"), C.setAttribute("aria-haspopup", !0), C.addEventListener("click", this.#f.bind(this)), C.addEventListener("keydown", this.#t);
          const T = this.#n = document.createElement("span");
          return T.className = "swatch", T.setAttribute("aria-hidden", !0), T.style.backgroundColor = this.#r, C.append(T), C;
        }
        renderMainDropdown() {
          const C = this.#i = this.#o();
          return C.setAttribute("aria-orientation", "horizontal"), C.setAttribute("aria-labelledby", "highlightColorPickerLabel"), C;
        }
        #o() {
          const C = document.createElement("div");
          C.addEventListener("contextmenu", v.noContextMenu), C.className = "dropdown", C.role = "listbox", C.setAttribute("aria-multiselectable", !1), C.setAttribute("aria-orientation", "vertical"), C.setAttribute("data-l10n-id", "pdfjs-editor-colorpicker-dropdown");
          for (const [T, A] of this.#d.highlightColors) {
            const n = document.createElement("button");
            n.tabIndex = "0", n.role = "option", n.setAttribute("data-color", A), n.title = T, n.setAttribute("data-l10n-id", `pdfjs-editor-colorpicker-${T}`);
            const f = document.createElement("span");
            n.append(f), f.className = "swatch", f.style.backgroundColor = A, n.setAttribute("aria-selected", A === this.#r), n.addEventListener("click", this.#p.bind(this, A)), C.append(n);
          }
          return C.addEventListener("keydown", this.#t), C;
        }
        #p(C, T) {
          T.stopPropagation(), this.#u.dispatch("switchannotationeditorparams", {
            source: this,
            type: this.#c,
            value: C
          });
        }
        _colorSelectFromKeyboard(C) {
          if (C.target === this.#s) {
            this.#f(C);
            return;
          }
          const T = C.target.getAttribute("data-color");
          T && this.#p(T, C);
        }
        _moveToNext(C) {
          if (!this.#m) {
            this.#f(C);
            return;
          }
          if (C.target === this.#s) {
            this.#i.firstChild?.focus();
            return;
          }
          C.target.nextSibling?.focus();
        }
        _moveToPrevious(C) {
          if (C.target === this.#i?.firstChild || C.target === this.#s) {
            this.#m && this._hideDropdownFromKeyboard();
            return;
          }
          this.#m || this.#f(C), C.target.previousSibling?.focus();
        }
        _moveToBeginning(C) {
          if (!this.#m) {
            this.#f(C);
            return;
          }
          this.#i.firstChild?.focus();
        }
        _moveToEnd(C) {
          if (!this.#m) {
            this.#f(C);
            return;
          }
          this.#i.lastChild?.focus();
        }
        #g(C) {
          _._keyboardManager.exec(this, C);
        }
        #f(C) {
          if (this.#m) {
            this.hideDropdown();
            return;
          }
          if (this.#a = C.detail === 0, window.addEventListener("pointerdown", this.#e), this.#i) {
            this.#i.classList.remove("hidden");
            return;
          }
          const T = this.#i = this.#o();
          this.#s.append(T);
        }
        #b(C) {
          this.#i?.contains(C.target) || this.hideDropdown();
        }
        hideDropdown() {
          this.#i?.classList.add("hidden"), window.removeEventListener("pointerdown", this.#e);
        }
        get #m() {
          return this.#i && !this.#i.classList.contains("hidden");
        }
        _hideDropdownFromKeyboard() {
          if (!this.#h) {
            if (!this.#m) {
              this.#l?.unselect();
              return;
            }
            this.hideDropdown(), this.#s.focus({
              preventScroll: !0,
              focusVisible: this.#a
            });
          }
        }
        updateColor(C) {
          if (this.#n && (this.#n.style.backgroundColor = C), !this.#i)
            return;
          const T = this.#d.highlightColors.values();
          for (const A of this.#i.children)
            A.setAttribute("aria-selected", T.next().value === C);
        }
        destroy() {
          this.#s?.remove(), this.#s = null, this.#n = null, this.#i?.remove(), this.#i = null;
        }
      }
    })
  ),
  /***/
  310: (
    /***/
    ((V, l, a) => {
      a.d(l, {
        AnnotationEditor: () => (
          /* binding */
          C
        )
      });
      var s = a(830), S = a(292), v = a(419);
      class _ {
        #t = "";
        #e = !1;
        #s = null;
        #n = null;
        #r = null;
        #i = !1;
        #a = null;
        static _l10nPromise = null;
        constructor(n) {
          this.#a = n;
        }
        static initialize(n) {
          _._l10nPromise ||= n;
        }
        async render() {
          const n = this.#s = document.createElement("button");
          n.className = "altText";
          const f = await _._l10nPromise.get("pdfjs-editor-alt-text-button-label");
          n.textContent = f, n.setAttribute("aria-label", f), n.tabIndex = "0", n.addEventListener("contextmenu", v.noContextMenu), n.addEventListener("pointerdown", (F) => F.stopPropagation());
          const p = (F) => {
            F.preventDefault(), this.#a._uiManager.editAltText(this.#a);
          };
          return n.addEventListener("click", p, {
            capture: !0
          }), n.addEventListener("keydown", (F) => {
            F.target === n && F.key === "Enter" && (this.#i = !0, p(F));
          }), await this.#h(), n;
        }
        finish() {
          this.#s && (this.#s.focus({
            focusVisible: this.#i
          }), this.#i = !1);
        }
        isEmpty() {
          return !this.#t && !this.#e;
        }
        get data() {
          return {
            altText: this.#t,
            decorative: this.#e
          };
        }
        set data({
          altText: n,
          decorative: f
        }) {
          this.#t === n && this.#e === f || (this.#t = n, this.#e = f, this.#h());
        }
        toggle(n = !1) {
          this.#s && (!n && this.#r && (clearTimeout(this.#r), this.#r = null), this.#s.disabled = !n);
        }
        destroy() {
          this.#s?.remove(), this.#s = null, this.#n = null;
        }
        async #h() {
          const n = this.#s;
          if (!n)
            return;
          if (!this.#t && !this.#e) {
            n.classList.remove("done"), this.#n?.remove();
            return;
          }
          n.classList.add("done"), _._l10nPromise.get("pdfjs-editor-alt-text-edit-button-label").then((F) => {
            n.setAttribute("aria-label", F);
          });
          let f = this.#n;
          if (!f) {
            this.#n = f = document.createElement("span"), f.className = "tooltip", f.setAttribute("role", "tooltip");
            const F = f.id = `alt-text-tooltip-${this.#a.id}`;
            n.setAttribute("aria-describedby", F);
            const r = 100;
            n.addEventListener("mouseenter", () => {
              this.#r = setTimeout(() => {
                this.#r = null, this.#n.classList.add("show"), this.#a._reportTelemetry({
                  action: "alt_text_tooltip"
                });
              }, r);
            }), n.addEventListener("mouseleave", () => {
              this.#r && (clearTimeout(this.#r), this.#r = null), this.#n?.classList.remove("show");
            });
          }
          f.innerText = this.#e ? await _._l10nPromise.get("pdfjs-editor-alt-text-decorative-tooltip") : this.#t, f.parentNode || n.append(f), this.#a.getImageForAltText()?.setAttribute("aria-describedby", f.id);
        }
      }
      var x = a(362);
      class C {
        #t = null;
        #e = null;
        #s = !1;
        #n = !1;
        #r = null;
        #i = null;
        #a = this.focusin.bind(this);
        #h = this.focusout.bind(this);
        #l = null;
        #u = "";
        #d = !1;
        #c = null;
        #o = !1;
        #p = !1;
        #g = !1;
        #f = null;
        #b = 0;
        #m = 0;
        #w = null;
        _initialOptions = /* @__PURE__ */ Object.create(null);
        _isVisible = !0;
        _uiManager = null;
        _focusEventsAllowed = !0;
        _l10nPromise = null;
        #y = !1;
        #S = C._zIndex++;
        static _borderLineWidth = -1;
        static _colorManager = new s.ColorManager();
        static _zIndex = 1;
        static _telemetryTimeout = 1e3;
        static get _resizerKeyboardManager() {
          const n = C.prototype._resizeWithKeyboard, f = s.AnnotationEditorUIManager.TRANSLATE_SMALL, p = s.AnnotationEditorUIManager.TRANSLATE_BIG;
          return (0, S.shadow)(this, "_resizerKeyboardManager", new s.KeyboardManager([[["ArrowLeft", "mac+ArrowLeft"], n, {
            args: [-f, 0]
          }], [["ctrl+ArrowLeft", "mac+shift+ArrowLeft"], n, {
            args: [-p, 0]
          }], [["ArrowRight", "mac+ArrowRight"], n, {
            args: [f, 0]
          }], [["ctrl+ArrowRight", "mac+shift+ArrowRight"], n, {
            args: [p, 0]
          }], [["ArrowUp", "mac+ArrowUp"], n, {
            args: [0, -f]
          }], [["ctrl+ArrowUp", "mac+shift+ArrowUp"], n, {
            args: [0, -p]
          }], [["ArrowDown", "mac+ArrowDown"], n, {
            args: [0, f]
          }], [["ctrl+ArrowDown", "mac+shift+ArrowDown"], n, {
            args: [0, p]
          }], [["Escape", "mac+Escape"], C.prototype._stopResizingWithKeyboard]]));
        }
        constructor(n) {
          this.constructor === C && (0, S.unreachable)("Cannot initialize AnnotationEditor."), this.parent = n.parent, this.id = n.id, this.width = this.height = null, this.pageIndex = n.parent.pageIndex, this.name = n.name, this.div = null, this._uiManager = n.uiManager, this.annotationElementId = null, this._willKeepAspectRatio = !1, this._initialOptions.isCentered = n.isCentered, this._structTreeParentId = null;
          const {
            rotation: f,
            rawDims: {
              pageWidth: p,
              pageHeight: F,
              pageX: r,
              pageY: w
            }
          } = this.parent.viewport;
          this.rotation = f, this.pageRotation = (360 + f - this._uiManager.viewParameters.rotation) % 360, this.pageDimensions = [p, F], this.pageTranslation = [r, w];
          const [t, i] = this.parentDimensions;
          this.x = n.x / t, this.y = n.y / i, this.isAttachedToDOM = !1, this.deleted = !1;
        }
        get editorType() {
          return Object.getPrototypeOf(this).constructor._type;
        }
        static get _defaultLineColor() {
          return (0, S.shadow)(this, "_defaultLineColor", this._colorManager.getHexCode("CanvasText"));
        }
        static deleteAnnotationElement(n) {
          const f = new T({
            id: n.parent.getNextId(),
            parent: n.parent,
            uiManager: n._uiManager
          });
          f.annotationElementId = n.annotationElementId, f.deleted = !0, f._uiManager.addToAnnotationStorage(f);
        }
        static initialize(n, f, p) {
          if (C._l10nPromise ||= new Map(["pdfjs-editor-alt-text-button-label", "pdfjs-editor-alt-text-edit-button-label", "pdfjs-editor-alt-text-decorative-tooltip", "pdfjs-editor-resizer-label-topLeft", "pdfjs-editor-resizer-label-topMiddle", "pdfjs-editor-resizer-label-topRight", "pdfjs-editor-resizer-label-middleRight", "pdfjs-editor-resizer-label-bottomRight", "pdfjs-editor-resizer-label-bottomMiddle", "pdfjs-editor-resizer-label-bottomLeft", "pdfjs-editor-resizer-label-middleLeft"].map((r) => [r, n.get(r.replaceAll(/([A-Z])/g, (w) => `-${w.toLowerCase()}`))])), p?.strings)
            for (const r of p.strings)
              C._l10nPromise.set(r, n.get(r));
          if (C._borderLineWidth !== -1)
            return;
          const F = getComputedStyle(document.documentElement);
          C._borderLineWidth = parseFloat(F.getPropertyValue("--outline-width")) || 0;
        }
        static updateDefaultParams(n, f) {
        }
        static get defaultPropertiesToUpdate() {
          return [];
        }
        static isHandlingMimeForPasting(n) {
          return !1;
        }
        static paste(n, f) {
          (0, S.unreachable)("Not implemented");
        }
        get propertiesToUpdate() {
          return [];
        }
        get _isDraggable() {
          return this.#y;
        }
        set _isDraggable(n) {
          this.#y = n, this.div?.classList.toggle("draggable", n);
        }
        get isEnterHandled() {
          return !0;
        }
        center() {
          const [n, f] = this.pageDimensions;
          switch (this.parentRotation) {
            case 90:
              this.x -= this.height * f / (n * 2), this.y += this.width * n / (f * 2);
              break;
            case 180:
              this.x += this.width / 2, this.y += this.height / 2;
              break;
            case 270:
              this.x += this.height * f / (n * 2), this.y -= this.width * n / (f * 2);
              break;
            default:
              this.x -= this.width / 2, this.y -= this.height / 2;
              break;
          }
          this.fixAndSetPosition();
        }
        addCommands(n) {
          this._uiManager.addCommands(n);
        }
        get currentLayer() {
          return this._uiManager.currentLayer;
        }
        setInBackground() {
          this.div.style.zIndex = 0;
        }
        setInForeground() {
          this.div.style.zIndex = this.#S;
        }
        setParent(n) {
          n !== null ? (this.pageIndex = n.pageIndex, this.pageDimensions = n.pageDimensions) : this.#P(), this.parent = n;
        }
        focusin(n) {
          this._focusEventsAllowed && (this.#d ? this.#d = !1 : this.parent.setSelected(this));
        }
        focusout(n) {
          !this._focusEventsAllowed || !this.isAttachedToDOM || n.relatedTarget?.closest(`#${this.id}`) || (n.preventDefault(), this.parent?.isMultipleSelection || this.commitOrRemove());
        }
        commitOrRemove() {
          this.isEmpty() ? this.remove() : this.commit();
        }
        commit() {
          this.addToAnnotationStorage();
        }
        addToAnnotationStorage() {
          this._uiManager.addToAnnotationStorage(this);
        }
        setAt(n, f, p, F) {
          const [r, w] = this.parentDimensions;
          [p, F] = this.screenToPageTranslation(p, F), this.x = (n + p) / r, this.y = (f + F) / w, this.fixAndSetPosition();
        }
        #F([n, f], p, F) {
          [p, F] = this.screenToPageTranslation(p, F), this.x += p / n, this.y += F / f, this.fixAndSetPosition();
        }
        translate(n, f) {
          this.#F(this.parentDimensions, n, f);
        }
        translateInPage(n, f) {
          this.#c ||= [this.x, this.y], this.#F(this.pageDimensions, n, f), this.div.scrollIntoView({
            block: "nearest"
          });
        }
        drag(n, f) {
          this.#c ||= [this.x, this.y];
          const [p, F] = this.parentDimensions;
          if (this.x += n / p, this.y += f / F, this.parent && (this.x < 0 || this.x > 1 || this.y < 0 || this.y > 1)) {
            const {
              x: h,
              y: d
            } = this.div.getBoundingClientRect();
            this.parent.findNewParent(this, h, d) && (this.x -= Math.floor(this.x), this.y -= Math.floor(this.y));
          }
          let {
            x: r,
            y: w
          } = this;
          const [t, i] = this.getBaseTranslation();
          r += t, w += i, this.div.style.left = `${(100 * r).toFixed(2)}%`, this.div.style.top = `${(100 * w).toFixed(2)}%`, this.div.scrollIntoView({
            block: "nearest"
          });
        }
        get _hasBeenMoved() {
          return !!this.#c && (this.#c[0] !== this.x || this.#c[1] !== this.y);
        }
        getBaseTranslation() {
          const [n, f] = this.parentDimensions, {
            _borderLineWidth: p
          } = C, F = p / n, r = p / f;
          switch (this.rotation) {
            case 90:
              return [-F, r];
            case 180:
              return [F, r];
            case 270:
              return [F, -r];
            default:
              return [-F, -r];
          }
        }
        get _mustFixPosition() {
          return !0;
        }
        fixAndSetPosition(n = this.rotation) {
          const [f, p] = this.pageDimensions;
          let {
            x: F,
            y: r,
            width: w,
            height: t
          } = this;
          if (w *= f, t *= p, F *= f, r *= p, this._mustFixPosition)
            switch (n) {
              case 0:
                F = Math.max(0, Math.min(f - w, F)), r = Math.max(0, Math.min(p - t, r));
                break;
              case 90:
                F = Math.max(0, Math.min(f - t, F)), r = Math.min(p, Math.max(w, r));
                break;
              case 180:
                F = Math.min(f, Math.max(w, F)), r = Math.min(p, Math.max(t, r));
                break;
              case 270:
                F = Math.min(f, Math.max(t, F)), r = Math.max(0, Math.min(p - w, r));
                break;
            }
          this.x = F /= f, this.y = r /= p;
          const [i, h] = this.getBaseTranslation();
          F += i, r += h;
          const {
            style: d
          } = this.div;
          d.left = `${(100 * F).toFixed(2)}%`, d.top = `${(100 * r).toFixed(2)}%`, this.moveInDOM();
        }
        static #I(n, f, p) {
          switch (p) {
            case 90:
              return [f, -n];
            case 180:
              return [-n, -f];
            case 270:
              return [-f, n];
            default:
              return [n, f];
          }
        }
        screenToPageTranslation(n, f) {
          return C.#I(n, f, this.parentRotation);
        }
        pageTranslationToScreen(n, f) {
          return C.#I(n, f, 360 - this.parentRotation);
        }
        #R(n) {
          switch (n) {
            case 90: {
              const [f, p] = this.pageDimensions;
              return [0, -f / p, p / f, 0];
            }
            case 180:
              return [-1, 0, 0, -1];
            case 270: {
              const [f, p] = this.pageDimensions;
              return [0, f / p, -p / f, 0];
            }
            default:
              return [1, 0, 0, 1];
          }
        }
        get parentScale() {
          return this._uiManager.viewParameters.realScale;
        }
        get parentRotation() {
          return (this._uiManager.viewParameters.rotation + this.pageRotation) % 360;
        }
        get parentDimensions() {
          const {
            parentScale: n,
            pageDimensions: [f, p]
          } = this, F = f * n, r = p * n;
          return S.FeatureTest.isCSSRoundSupported ? [Math.round(F), Math.round(r)] : [F, r];
        }
        setDims(n, f) {
          const [p, F] = this.parentDimensions;
          this.div.style.width = `${(100 * n / p).toFixed(2)}%`, this.#n || (this.div.style.height = `${(100 * f / F).toFixed(2)}%`);
        }
        fixDims() {
          const {
            style: n
          } = this.div, {
            height: f,
            width: p
          } = n, F = p.endsWith("%"), r = !this.#n && f.endsWith("%");
          if (F && r)
            return;
          const [w, t] = this.parentDimensions;
          F || (n.width = `${(100 * parseFloat(p) / w).toFixed(2)}%`), !this.#n && !r && (n.height = `${(100 * parseFloat(f) / t).toFixed(2)}%`);
        }
        getInitialTranslation() {
          return [0, 0];
        }
        #A() {
          if (this.#r)
            return;
          this.#r = document.createElement("div"), this.#r.classList.add("resizers");
          const n = this._willKeepAspectRatio ? ["topLeft", "topRight", "bottomRight", "bottomLeft"] : ["topLeft", "topMiddle", "topRight", "middleRight", "bottomRight", "bottomMiddle", "bottomLeft", "middleLeft"];
          for (const f of n) {
            const p = document.createElement("div");
            this.#r.append(p), p.classList.add("resizer", f), p.setAttribute("data-resizer-name", f), p.addEventListener("pointerdown", this.#v.bind(this, f)), p.addEventListener("contextmenu", v.noContextMenu), p.tabIndex = -1;
          }
          this.div.prepend(this.#r);
        }
        #v(n, f) {
          f.preventDefault();
          const {
            isMac: p
          } = S.FeatureTest.platform;
          if (f.button !== 0 || f.ctrlKey && p)
            return;
          this.#e?.toggle(!1);
          const F = this.#E.bind(this, n), r = this._isDraggable;
          this._isDraggable = !1;
          const w = {
            passive: !0,
            capture: !0
          };
          this.parent.togglePointerEvents(!1), window.addEventListener("pointermove", F, w), window.addEventListener("contextmenu", v.noContextMenu);
          const t = this.x, i = this.y, h = this.width, d = this.height, E = this.parent.div.style.cursor, k = this.div.style.cursor;
          this.div.style.cursor = this.parent.div.style.cursor = window.getComputedStyle(f.target).cursor;
          const L = () => {
            this.parent.togglePointerEvents(!0), this.#e?.toggle(!0), this._isDraggable = r, window.removeEventListener("pointerup", L), window.removeEventListener("blur", L), window.removeEventListener("pointermove", F, w), window.removeEventListener("contextmenu", v.noContextMenu), this.parent.div.style.cursor = E, this.div.style.cursor = k, this.#x(t, i, h, d);
          };
          window.addEventListener("pointerup", L), window.addEventListener("blur", L);
        }
        #x(n, f, p, F) {
          const r = this.x, w = this.y, t = this.width, i = this.height;
          r === n && w === f && t === p && i === F || this.addCommands({
            cmd: () => {
              this.width = t, this.height = i, this.x = r, this.y = w;
              const [h, d] = this.parentDimensions;
              this.setDims(h * t, d * i), this.fixAndSetPosition();
            },
            undo: () => {
              this.width = p, this.height = F, this.x = n, this.y = f;
              const [h, d] = this.parentDimensions;
              this.setDims(h * p, d * F), this.fixAndSetPosition();
            },
            mustExec: !0
          });
        }
        #E(n, f) {
          const [p, F] = this.parentDimensions, r = this.x, w = this.y, t = this.width, i = this.height, h = C.MIN_SIZE / p, d = C.MIN_SIZE / F, E = (D) => Math.round(D * 1e4) / 1e4, k = this.#R(this.rotation), L = (D, y) => [k[0] * D + k[2] * y, k[1] * D + k[3] * y], M = this.#R(360 - this.rotation), B = (D, y) => [M[0] * D + M[2] * y, M[1] * D + M[3] * y];
          let U, q, Z = !1, K = !1;
          switch (n) {
            case "topLeft":
              Z = !0, U = (D, y) => [0, 0], q = (D, y) => [D, y];
              break;
            case "topMiddle":
              U = (D, y) => [D / 2, 0], q = (D, y) => [D / 2, y];
              break;
            case "topRight":
              Z = !0, U = (D, y) => [D, 0], q = (D, y) => [0, y];
              break;
            case "middleRight":
              K = !0, U = (D, y) => [D, y / 2], q = (D, y) => [0, y / 2];
              break;
            case "bottomRight":
              Z = !0, U = (D, y) => [D, y], q = (D, y) => [0, 0];
              break;
            case "bottomMiddle":
              U = (D, y) => [D / 2, y], q = (D, y) => [D / 2, 0];
              break;
            case "bottomLeft":
              Z = !0, U = (D, y) => [0, y], q = (D, y) => [D, 0];
              break;
            case "middleLeft":
              K = !0, U = (D, y) => [0, y / 2], q = (D, y) => [D, y / 2];
              break;
          }
          const Y = U(t, i), G = q(t, i);
          let j = L(...G);
          const Q = E(r + j[0]), J = E(w + j[1]);
          let tt = 1, rt = 1, [ut, dt] = this.screenToPageTranslation(f.movementX, f.movementY);
          if ([ut, dt] = B(ut / p, dt / F), Z) {
            const D = Math.hypot(t, i);
            tt = rt = Math.max(Math.min(Math.hypot(G[0] - Y[0] - ut, G[1] - Y[1] - dt) / D, 1 / t, 1 / i), h / t, d / i);
          } else K ? tt = Math.max(h, Math.min(1, Math.abs(G[0] - Y[0] - ut))) / t : rt = Math.max(d, Math.min(1, Math.abs(G[1] - Y[1] - dt))) / i;
          const ft = E(t * tt), lt = E(i * rt);
          j = L(...q(ft, lt));
          const ot = Q - j[0], et = J - j[1];
          this.width = ft, this.height = lt, this.x = ot, this.y = et, this.setDims(p * ft, F * lt), this.fixAndSetPosition();
        }
        altTextFinish() {
          this.#e?.finish();
        }
        async addEditToolbar() {
          return this.#l || this.#p ? this.#l : (this.#l = new x.EditorToolbar(this), this.div.append(this.#l.render()), this.#e && this.#l.addAltTextButton(await this.#e.render()), this.#l);
        }
        removeEditToolbar() {
          this.#l && (this.#l.remove(), this.#l = null, this.#e?.destroy());
        }
        getClientDimensions() {
          return this.div.getBoundingClientRect();
        }
        async addAltTextButton() {
          this.#e || (_.initialize(C._l10nPromise), this.#e = new _(this), await this.addEditToolbar());
        }
        get altTextData() {
          return this.#e?.data;
        }
        set altTextData(n) {
          this.#e && (this.#e.data = n);
        }
        hasAltText() {
          return !this.#e?.isEmpty();
        }
        render() {
          this.div = document.createElement("div"), this.div.setAttribute("data-editor-rotation", (360 - this.rotation) % 360), this.div.className = this.name, this.div.setAttribute("id", this.id), this.div.tabIndex = this.#s ? -1 : 0, this._isVisible || this.div.classList.add("hidden"), this.setInForeground(), this.div.addEventListener("focusin", this.#a), this.div.addEventListener("focusout", this.#h);
          const [n, f] = this.parentDimensions;
          this.parentRotation % 180 !== 0 && (this.div.style.maxWidth = `${(100 * f / n).toFixed(2)}%`, this.div.style.maxHeight = `${(100 * n / f).toFixed(2)}%`);
          const [p, F] = this.getInitialTranslation();
          return this.translate(p, F), (0, s.bindEvents)(this, this.div, ["pointerdown"]), this.div;
        }
        pointerdown(n) {
          const {
            isMac: f
          } = S.FeatureTest.platform;
          if (n.button !== 0 || n.ctrlKey && f) {
            n.preventDefault();
            return;
          }
          if (this.#d = !0, this._isDraggable) {
            this.#C(n);
            return;
          }
          this.#D(n);
        }
        #D(n) {
          const {
            isMac: f
          } = S.FeatureTest.platform;
          n.ctrlKey && !f || n.shiftKey || n.metaKey && f ? this.parent.toggleSelected(this) : this.parent.setSelected(this);
        }
        #C(n) {
          const f = this._uiManager.isSelected(this);
          this._uiManager.setUpDragSession();
          let p, F;
          f && (this.div.classList.add("moving"), p = {
            passive: !0,
            capture: !0
          }, this.#b = n.clientX, this.#m = n.clientY, F = (w) => {
            const {
              clientX: t,
              clientY: i
            } = w, [h, d] = this.screenToPageTranslation(t - this.#b, i - this.#m);
            this.#b = t, this.#m = i, this._uiManager.dragSelectedEditors(h, d);
          }, window.addEventListener("pointermove", F, p));
          const r = () => {
            window.removeEventListener("pointerup", r), window.removeEventListener("blur", r), f && (this.div.classList.remove("moving"), window.removeEventListener("pointermove", F, p)), this.#d = !1, this._uiManager.endDragSession() || this.#D(n);
          };
          window.addEventListener("pointerup", r), window.addEventListener("blur", r);
        }
        moveInDOM() {
          this.#f && clearTimeout(this.#f), this.#f = setTimeout(() => {
            this.#f = null, this.parent?.moveEditorInDOM(this);
          }, 0);
        }
        _setParentAndPosition(n, f, p) {
          n.changeParent(this), this.x = f, this.y = p, this.fixAndSetPosition();
        }
        getRect(n, f, p = this.rotation) {
          const F = this.parentScale, [r, w] = this.pageDimensions, [t, i] = this.pageTranslation, h = n / F, d = f / F, E = this.x * r, k = this.y * w, L = this.width * r, M = this.height * w;
          switch (p) {
            case 0:
              return [E + h + t, w - k - d - M + i, E + h + L + t, w - k - d + i];
            case 90:
              return [E + d + t, w - k + h + i, E + d + M + t, w - k + h + L + i];
            case 180:
              return [E - h - L + t, w - k + d + i, E - h + t, w - k + d + M + i];
            case 270:
              return [E - d - M + t, w - k - h - L + i, E - d + t, w - k - h + i];
            default:
              throw new Error("Invalid rotation");
          }
        }
        getRectInCurrentCoords(n, f) {
          const [p, F, r, w] = n, t = r - p, i = w - F;
          switch (this.rotation) {
            case 0:
              return [p, f - w, t, i];
            case 90:
              return [p, f - F, i, t];
            case 180:
              return [r, f - F, t, i];
            case 270:
              return [r, f - w, i, t];
            default:
              throw new Error("Invalid rotation");
          }
        }
        onceAdded() {
        }
        isEmpty() {
          return !1;
        }
        enableEditMode() {
          this.#p = !0;
        }
        disableEditMode() {
          this.#p = !1;
        }
        isInEditMode() {
          return this.#p;
        }
        shouldGetKeyboardEvents() {
          return this.#g;
        }
        needsToBeRebuilt() {
          return this.div && !this.isAttachedToDOM;
        }
        rebuild() {
          this.div?.addEventListener("focusin", this.#a), this.div?.addEventListener("focusout", this.#h);
        }
        rotate(n) {
        }
        serialize(n = !1, f = null) {
          (0, S.unreachable)("An editor must be serializable");
        }
        static deserialize(n, f, p) {
          const F = new this.prototype.constructor({
            parent: f,
            id: f.getNextId(),
            uiManager: p
          });
          F.rotation = n.rotation;
          const [r, w] = F.pageDimensions, [t, i, h, d] = F.getRectInCurrentCoords(n.rect, w);
          return F.x = t / r, F.y = i / w, F.width = h / r, F.height = d / w, F;
        }
        get hasBeenModified() {
          return !!this.annotationElementId && (this.deleted || this.serialize() !== null);
        }
        remove() {
          if (this.div.removeEventListener("focusin", this.#a), this.div.removeEventListener("focusout", this.#h), this.isEmpty() || this.commit(), this.parent ? this.parent.remove(this) : this._uiManager.removeEditor(this), this.#f && (clearTimeout(this.#f), this.#f = null), this.#P(), this.removeEditToolbar(), this.#w) {
            for (const n of this.#w.values())
              clearTimeout(n);
            this.#w = null;
          }
          this.parent = null;
        }
        get isResizable() {
          return !1;
        }
        makeResizable() {
          this.isResizable && (this.#A(), this.#r.classList.remove("hidden"), (0, s.bindEvents)(this, this.div, ["keydown"]));
        }
        get toolbarPosition() {
          return null;
        }
        keydown(n) {
          if (!this.isResizable || n.target !== this.div || n.key !== "Enter")
            return;
          this._uiManager.setSelected(this), this.#i = {
            savedX: this.x,
            savedY: this.y,
            savedWidth: this.width,
            savedHeight: this.height
          };
          const f = this.#r.children;
          if (!this.#t) {
            this.#t = Array.from(f);
            const w = this.#L.bind(this), t = this.#T.bind(this);
            for (const i of this.#t) {
              const h = i.getAttribute("data-resizer-name");
              i.setAttribute("role", "spinbutton"), i.addEventListener("keydown", w), i.addEventListener("blur", t), i.addEventListener("focus", this.#M.bind(this, h)), C._l10nPromise.get(`pdfjs-editor-resizer-label-${h}`).then((d) => i.setAttribute("aria-label", d));
            }
          }
          const p = this.#t[0];
          let F = 0;
          for (const w of f) {
            if (w === p)
              break;
            F++;
          }
          const r = (360 - this.rotation + this.parentRotation) % 360 / 90 * (this.#t.length / 4);
          if (r !== F) {
            if (r < F)
              for (let t = 0; t < F - r; t++)
                this.#r.append(this.#r.firstChild);
            else if (r > F)
              for (let t = 0; t < r - F; t++)
                this.#r.firstChild.before(this.#r.lastChild);
            let w = 0;
            for (const t of f) {
              const h = this.#t[w++].getAttribute("data-resizer-name");
              C._l10nPromise.get(`pdfjs-editor-resizer-label-${h}`).then((d) => t.setAttribute("aria-label", d));
            }
          }
          this.#_(0), this.#g = !0, this.#r.firstChild.focus({
            focusVisible: !0
          }), n.preventDefault(), n.stopImmediatePropagation();
        }
        #L(n) {
          C._resizerKeyboardManager.exec(this, n);
        }
        #T(n) {
          this.#g && n.relatedTarget?.parentNode !== this.#r && this.#P();
        }
        #M(n) {
          this.#u = this.#g ? n : "";
        }
        #_(n) {
          if (this.#t)
            for (const f of this.#t)
              f.tabIndex = n;
        }
        _resizeWithKeyboard(n, f) {
          this.#g && this.#E(this.#u, {
            movementX: n,
            movementY: f
          });
        }
        #P() {
          if (this.#g = !1, this.#_(-1), this.#i) {
            const {
              savedX: n,
              savedY: f,
              savedWidth: p,
              savedHeight: F
            } = this.#i;
            this.#x(n, f, p, F), this.#i = null;
          }
        }
        _stopResizingWithKeyboard() {
          this.#P(), this.div.focus();
        }
        select() {
          if (this.makeResizable(), this.div?.classList.add("selectedEditor"), !this.#l) {
            this.addEditToolbar().then(() => {
              this.div?.classList.contains("selectedEditor") && this.#l?.show();
            });
            return;
          }
          this.#l?.show();
        }
        unselect() {
          this.#r?.classList.add("hidden"), this.div?.classList.remove("selectedEditor"), this.div?.contains(document.activeElement) && this._uiManager.currentLayer.div.focus({
            preventScroll: !0
          }), this.#l?.hide();
        }
        updateParams(n, f) {
        }
        disableEditing() {
        }
        enableEditing() {
        }
        enterInEditMode() {
        }
        getImageForAltText() {
          return null;
        }
        get contentDiv() {
          return this.div;
        }
        get isEditing() {
          return this.#o;
        }
        set isEditing(n) {
          this.#o = n, this.parent && (n ? (this.parent.setSelected(this), this.parent.setActiveEditor(this)) : this.parent.setActiveEditor(null));
        }
        setAspectRatio(n, f) {
          this.#n = !0;
          const p = n / f, {
            style: F
          } = this.div;
          F.aspectRatio = p, F.height = "auto";
        }
        static get MIN_SIZE() {
          return 16;
        }
        static canCreateNewEmptyEditor() {
          return !0;
        }
        get telemetryInitialData() {
          return {
            action: "added"
          };
        }
        get telemetryFinalData() {
          return null;
        }
        _reportTelemetry(n, f = !1) {
          if (f) {
            this.#w ||= /* @__PURE__ */ new Map();
            const {
              action: p
            } = n;
            let F = this.#w.get(p);
            F && clearTimeout(F), F = setTimeout(() => {
              this._reportTelemetry(n), this.#w.delete(p), this.#w.size === 0 && (this.#w = null);
            }, C._telemetryTimeout), this.#w.set(p, F);
            return;
          }
          n.type ||= this.editorType, this._uiManager._eventBus.dispatch("reporttelemetry", {
            source: this,
            details: {
              type: "editing",
              data: n
            }
          });
        }
        show(n = this._isVisible) {
          this.div.classList.toggle("hidden", !n), this._isVisible = n;
        }
        enable() {
          this.div && (this.div.tabIndex = 0), this.#s = !1;
        }
        disable() {
          this.div && (this.div.tabIndex = -1), this.#s = !0;
        }
        renderAnnotationElement(n) {
          let f = n.container.querySelector(".annotationContent");
          if (!f)
            f = document.createElement("div"), f.classList.add("annotationContent", this.editorType), n.container.prepend(f);
          else if (f.nodeName === "CANVAS") {
            const p = f;
            f = document.createElement("div"), f.classList.add("annotationContent", this.editorType), p.before(f);
          }
          return f;
        }
        resetAnnotationElement(n) {
          const {
            firstChild: f
          } = n.container;
          f.nodeName === "DIV" && f.classList.contains("annotationContent") && f.remove();
        }
      }
      class T extends C {
        constructor(n) {
          super(n), this.annotationElementId = n.annotationElementId, this.deleted = !0;
        }
        serialize() {
          return {
            id: this.annotationElementId,
            deleted: !0,
            pageIndex: this.pageIndex
          };
        }
      }
    })
  ),
  /***/
  61: (
    /***/
    ((V, l, a) => {
      a.d(l, {
        /* harmony export */
        FreeOutliner: () => (
          /* binding */
          x
        ),
        /* harmony export */
        Outliner: () => (
          /* binding */
          S
        )
        /* harmony export */
      });
      var s = a(292);
      class S {
        #t;
        #e = [];
        #s = [];
        constructor(A, n = 0, f = 0, p = !0) {
          let F = 1 / 0, r = -1 / 0, w = 1 / 0, t = -1 / 0;
          const i = 10 ** -4;
          for (const {
            x: B,
            y: U,
            width: q,
            height: Z
          } of A) {
            const K = Math.floor((B - n) / i) * i, Y = Math.ceil((B + q + n) / i) * i, G = Math.floor((U - n) / i) * i, j = Math.ceil((U + Z + n) / i) * i, Q = [K, G, j, !0], J = [Y, G, j, !1];
            this.#e.push(Q, J), F = Math.min(F, K), r = Math.max(r, Y), w = Math.min(w, G), t = Math.max(t, j);
          }
          const h = r - F + 2 * f, d = t - w + 2 * f, E = F - f, k = w - f, L = this.#e.at(p ? -1 : -2), M = [L[0], L[2]];
          for (const B of this.#e) {
            const [U, q, Z] = B;
            B[0] = (U - E) / h, B[1] = (q - k) / d, B[2] = (Z - k) / d;
          }
          this.#t = {
            x: E,
            y: k,
            width: h,
            height: d,
            lastPoint: M
          };
        }
        getOutlines() {
          this.#e.sort((n, f) => n[0] - f[0] || n[1] - f[1] || n[2] - f[2]);
          const A = [];
          for (const n of this.#e)
            n[3] ? (A.push(...this.#h(n)), this.#i(n)) : (this.#a(n), A.push(...this.#h(n)));
          return this.#n(A);
        }
        #n(A) {
          const n = [], f = /* @__PURE__ */ new Set();
          for (const r of A) {
            const [w, t, i] = r;
            n.push([w, t, r], [w, i, r]);
          }
          n.sort((r, w) => r[1] - w[1] || r[0] - w[0]);
          for (let r = 0, w = n.length; r < w; r += 2) {
            const t = n[r][2], i = n[r + 1][2];
            t.push(i), i.push(t), f.add(t), f.add(i);
          }
          const p = [];
          let F;
          for (; f.size > 0; ) {
            const r = f.values().next().value;
            let [w, t, i, h, d] = r;
            f.delete(r);
            let E = w, k = t;
            for (F = [w, i], p.push(F); ; ) {
              let L;
              if (f.has(h))
                L = h;
              else if (f.has(d))
                L = d;
              else
                break;
              f.delete(L), [w, t, i, h, d] = L, E !== w && (F.push(E, k, w, k === t ? t : i), E = w), k = k === t ? i : t;
            }
            F.push(E, k);
          }
          return new _(p, this.#t);
        }
        #r(A) {
          const n = this.#s;
          let f = 0, p = n.length - 1;
          for (; f <= p; ) {
            const F = f + p >> 1, r = n[F][0];
            if (r === A)
              return F;
            r < A ? f = F + 1 : p = F - 1;
          }
          return p + 1;
        }
        #i([, A, n]) {
          const f = this.#r(A);
          this.#s.splice(f, 0, [A, n]);
        }
        #a([, A, n]) {
          const f = this.#r(A);
          for (let p = f; p < this.#s.length; p++) {
            const [F, r] = this.#s[p];
            if (F !== A)
              break;
            if (F === A && r === n) {
              this.#s.splice(p, 1);
              return;
            }
          }
          for (let p = f - 1; p >= 0; p--) {
            const [F, r] = this.#s[p];
            if (F !== A)
              break;
            if (F === A && r === n) {
              this.#s.splice(p, 1);
              return;
            }
          }
        }
        #h(A) {
          const [n, f, p] = A, F = [[n, f, p]], r = this.#r(p);
          for (let w = 0; w < r; w++) {
            const [t, i] = this.#s[w];
            for (let h = 0, d = F.length; h < d; h++) {
              const [, E, k] = F[h];
              if (!(i <= E || k <= t)) {
                if (E >= t) {
                  if (k > i)
                    F[h][1] = i;
                  else {
                    if (d === 1)
                      return [];
                    F.splice(h, 1), h--, d--;
                  }
                  continue;
                }
                F[h][2] = t, k > i && F.push([n, i, k]);
              }
            }
          }
          return F;
        }
      }
      class v {
        toSVGPath() {
          throw new Error("Abstract method `toSVGPath` must be implemented.");
        }
        get box() {
          throw new Error("Abstract getter `box` must be implemented.");
        }
        serialize(A, n) {
          throw new Error("Abstract method `serialize` must be implemented.");
        }
        get free() {
          return this instanceof C;
        }
      }
      class _ extends v {
        #t;
        #e;
        constructor(A, n) {
          super(), this.#e = A, this.#t = n;
        }
        toSVGPath() {
          const A = [];
          for (const n of this.#e) {
            let [f, p] = n;
            A.push(`M${f} ${p}`);
            for (let F = 2; F < n.length; F += 2) {
              const r = n[F], w = n[F + 1];
              r === f ? (A.push(`V${w}`), p = w) : w === p && (A.push(`H${r}`), f = r);
            }
            A.push("Z");
          }
          return A.join(" ");
        }
        serialize([A, n, f, p], F) {
          const r = [], w = f - A, t = p - n;
          for (const i of this.#e) {
            const h = new Array(i.length);
            for (let d = 0; d < i.length; d += 2)
              h[d] = A + i[d] * w, h[d + 1] = p - i[d + 1] * t;
            r.push(h);
          }
          return r;
        }
        get box() {
          return this.#t;
        }
      }
      class x {
        #t;
        #e = [];
        #s;
        #n;
        #r = [];
        #i = new Float64Array(18);
        #a;
        #h;
        #l;
        #u;
        #d;
        #c;
        #o = [];
        static #p = 8;
        static #g = 2;
        static #f = x.#p + x.#g;
        constructor({
          x: A,
          y: n
        }, f, p, F, r, w = 0) {
          this.#t = f, this.#c = F * p, this.#n = r, this.#i.set([NaN, NaN, NaN, NaN, A, n], 6), this.#s = w, this.#u = x.#p * p, this.#l = x.#f * p, this.#d = p, this.#o.push(A, n);
        }
        get free() {
          return !0;
        }
        isEmpty() {
          return isNaN(this.#i[8]);
        }
        #b() {
          const A = this.#i.subarray(4, 6), n = this.#i.subarray(16, 18), [f, p, F, r] = this.#t;
          return [(this.#a + (A[0] - n[0]) / 2 - f) / F, (this.#h + (A[1] - n[1]) / 2 - p) / r, (this.#a + (n[0] - A[0]) / 2 - f) / F, (this.#h + (n[1] - A[1]) / 2 - p) / r];
        }
        add({
          x: A,
          y: n
        }) {
          this.#a = A, this.#h = n;
          const [f, p, F, r] = this.#t;
          let [w, t, i, h] = this.#i.subarray(8, 12);
          const d = A - i, E = n - h, k = Math.hypot(d, E);
          if (k < this.#l)
            return !1;
          const L = k - this.#u, M = L / k, B = M * d, U = M * E;
          let q = w, Z = t;
          w = i, t = h, i += B, h += U, this.#o?.push(A, n);
          const K = -U / L, Y = B / L, G = K * this.#c, j = Y * this.#c;
          return this.#i.set(this.#i.subarray(2, 8), 0), this.#i.set([i + G, h + j], 4), this.#i.set(this.#i.subarray(14, 18), 12), this.#i.set([i - G, h - j], 16), isNaN(this.#i[6]) ? (this.#r.length === 0 && (this.#i.set([w + G, t + j], 2), this.#r.push(NaN, NaN, NaN, NaN, (w + G - f) / F, (t + j - p) / r), this.#i.set([w - G, t - j], 14), this.#e.push(NaN, NaN, NaN, NaN, (w - G - f) / F, (t - j - p) / r)), this.#i.set([q, Z, w, t, i, h], 6), !this.isEmpty()) : (this.#i.set([q, Z, w, t, i, h], 6), Math.abs(Math.atan2(Z - t, q - w) - Math.atan2(U, B)) < Math.PI / 2 ? ([w, t, i, h] = this.#i.subarray(2, 6), this.#r.push(NaN, NaN, NaN, NaN, ((w + i) / 2 - f) / F, ((t + h) / 2 - p) / r), [w, t, q, Z] = this.#i.subarray(14, 18), this.#e.push(NaN, NaN, NaN, NaN, ((q + w) / 2 - f) / F, ((Z + t) / 2 - p) / r), !0) : ([q, Z, w, t, i, h] = this.#i.subarray(0, 6), this.#r.push(((q + 5 * w) / 6 - f) / F, ((Z + 5 * t) / 6 - p) / r, ((5 * w + i) / 6 - f) / F, ((5 * t + h) / 6 - p) / r, ((w + i) / 2 - f) / F, ((t + h) / 2 - p) / r), [i, h, w, t, q, Z] = this.#i.subarray(12, 18), this.#e.push(((q + 5 * w) / 6 - f) / F, ((Z + 5 * t) / 6 - p) / r, ((5 * w + i) / 6 - f) / F, ((5 * t + h) / 6 - p) / r, ((w + i) / 2 - f) / F, ((t + h) / 2 - p) / r), !0));
        }
        toSVGPath() {
          if (this.isEmpty())
            return "";
          const A = this.#r, n = this.#e, f = this.#i.subarray(4, 6), p = this.#i.subarray(16, 18), [F, r, w, t] = this.#t, [i, h, d, E] = this.#b();
          if (isNaN(this.#i[6]) && !this.isEmpty())
            return `M${(this.#i[2] - F) / w} ${(this.#i[3] - r) / t} L${(this.#i[4] - F) / w} ${(this.#i[5] - r) / t} L${i} ${h} L${d} ${E} L${(this.#i[16] - F) / w} ${(this.#i[17] - r) / t} L${(this.#i[14] - F) / w} ${(this.#i[15] - r) / t} Z`;
          const k = [];
          k.push(`M${A[4]} ${A[5]}`);
          for (let L = 6; L < A.length; L += 6)
            isNaN(A[L]) ? k.push(`L${A[L + 4]} ${A[L + 5]}`) : k.push(`C${A[L]} ${A[L + 1]} ${A[L + 2]} ${A[L + 3]} ${A[L + 4]} ${A[L + 5]}`);
          k.push(`L${(f[0] - F) / w} ${(f[1] - r) / t} L${i} ${h} L${d} ${E} L${(p[0] - F) / w} ${(p[1] - r) / t}`);
          for (let L = n.length - 6; L >= 6; L -= 6)
            isNaN(n[L]) ? k.push(`L${n[L + 4]} ${n[L + 5]}`) : k.push(`C${n[L]} ${n[L + 1]} ${n[L + 2]} ${n[L + 3]} ${n[L + 4]} ${n[L + 5]}`);
          return k.push(`L${n[4]} ${n[5]} Z`), k.join(" ");
        }
        getOutlines() {
          const A = this.#r, n = this.#e, f = this.#i, p = f.subarray(4, 6), F = f.subarray(16, 18), [r, w, t, i] = this.#t, h = new Float64Array((this.#o?.length ?? 0) + 2);
          for (let U = 0, q = h.length - 2; U < q; U += 2)
            h[U] = (this.#o[U] - r) / t, h[U + 1] = (this.#o[U + 1] - w) / i;
          h[h.length - 2] = (this.#a - r) / t, h[h.length - 1] = (this.#h - w) / i;
          const [d, E, k, L] = this.#b();
          if (isNaN(f[6]) && !this.isEmpty()) {
            const U = new Float64Array(36);
            return U.set([NaN, NaN, NaN, NaN, (f[2] - r) / t, (f[3] - w) / i, NaN, NaN, NaN, NaN, (f[4] - r) / t, (f[5] - w) / i, NaN, NaN, NaN, NaN, d, E, NaN, NaN, NaN, NaN, k, L, NaN, NaN, NaN, NaN, (f[16] - r) / t, (f[17] - w) / i, NaN, NaN, NaN, NaN, (f[14] - r) / t, (f[15] - w) / i], 0), new C(U, h, this.#t, this.#d, this.#s, this.#n);
          }
          const M = new Float64Array(this.#r.length + 24 + this.#e.length);
          let B = A.length;
          for (let U = 0; U < B; U += 2) {
            if (isNaN(A[U])) {
              M[U] = M[U + 1] = NaN;
              continue;
            }
            M[U] = A[U], M[U + 1] = A[U + 1];
          }
          M.set([NaN, NaN, NaN, NaN, (p[0] - r) / t, (p[1] - w) / i, NaN, NaN, NaN, NaN, d, E, NaN, NaN, NaN, NaN, k, L, NaN, NaN, NaN, NaN, (F[0] - r) / t, (F[1] - w) / i], B), B += 24;
          for (let U = n.length - 6; U >= 6; U -= 6)
            for (let q = 0; q < 6; q += 2) {
              if (isNaN(n[U + q])) {
                M[B] = M[B + 1] = NaN, B += 2;
                continue;
              }
              M[B] = n[U + q], M[B + 1] = n[U + q + 1], B += 2;
            }
          return M.set([NaN, NaN, NaN, NaN, n[4], n[5]], B), new C(M, h, this.#t, this.#d, this.#s, this.#n);
        }
      }
      class C extends v {
        #t;
        #e = null;
        #s;
        #n;
        #r;
        #i;
        #a;
        constructor(A, n, f, p, F, r) {
          super(), this.#a = A, this.#r = n, this.#t = f, this.#i = p, this.#s = F, this.#n = r, this.#u(r);
          const {
            x: w,
            y: t,
            width: i,
            height: h
          } = this.#e;
          for (let d = 0, E = A.length; d < E; d += 2)
            A[d] = (A[d] - w) / i, A[d + 1] = (A[d + 1] - t) / h;
          for (let d = 0, E = n.length; d < E; d += 2)
            n[d] = (n[d] - w) / i, n[d + 1] = (n[d + 1] - t) / h;
        }
        toSVGPath() {
          const A = [`M${this.#a[4]} ${this.#a[5]}`];
          for (let n = 6, f = this.#a.length; n < f; n += 6) {
            if (isNaN(this.#a[n])) {
              A.push(`L${this.#a[n + 4]} ${this.#a[n + 5]}`);
              continue;
            }
            A.push(`C${this.#a[n]} ${this.#a[n + 1]} ${this.#a[n + 2]} ${this.#a[n + 3]} ${this.#a[n + 4]} ${this.#a[n + 5]}`);
          }
          return A.push("Z"), A.join(" ");
        }
        serialize([A, n, f, p], F) {
          const r = f - A, w = p - n;
          let t, i;
          switch (F) {
            case 0:
              t = this.#h(this.#a, A, p, r, -w), i = this.#h(this.#r, A, p, r, -w);
              break;
            case 90:
              t = this.#l(this.#a, A, n, r, w), i = this.#l(this.#r, A, n, r, w);
              break;
            case 180:
              t = this.#h(this.#a, f, n, -r, w), i = this.#h(this.#r, f, n, -r, w);
              break;
            case 270:
              t = this.#l(this.#a, f, p, -r, -w), i = this.#l(this.#r, f, p, -r, -w);
              break;
          }
          return {
            outline: Array.from(t),
            points: [Array.from(i)]
          };
        }
        #h(A, n, f, p, F) {
          const r = new Float64Array(A.length);
          for (let w = 0, t = A.length; w < t; w += 2)
            r[w] = n + A[w] * p, r[w + 1] = f + A[w + 1] * F;
          return r;
        }
        #l(A, n, f, p, F) {
          const r = new Float64Array(A.length);
          for (let w = 0, t = A.length; w < t; w += 2)
            r[w] = n + A[w + 1] * p, r[w + 1] = f + A[w] * F;
          return r;
        }
        #u(A) {
          const n = this.#a;
          let f = n[4], p = n[5], F = f, r = p, w = f, t = p, i = f, h = p;
          const d = A ? Math.max : Math.min;
          for (let B = 6, U = n.length; B < U; B += 6) {
            if (isNaN(n[B]))
              F = Math.min(F, n[B + 4]), r = Math.min(r, n[B + 5]), w = Math.max(w, n[B + 4]), t = Math.max(t, n[B + 5]), h < n[B + 5] ? (i = n[B + 4], h = n[B + 5]) : h === n[B + 5] && (i = d(i, n[B + 4]));
            else {
              const q = s.Util.bezierBoundingBox(f, p, ...n.slice(B, B + 6));
              F = Math.min(F, q[0]), r = Math.min(r, q[1]), w = Math.max(w, q[2]), t = Math.max(t, q[3]), h < q[3] ? (i = q[2], h = q[3]) : h === q[3] && (i = d(i, q[2]));
            }
            f = n[B + 4], p = n[B + 5];
          }
          const E = F - this.#s, k = r - this.#s, L = w - F + 2 * this.#s, M = t - r + 2 * this.#s;
          this.#e = {
            x: E,
            y: k,
            width: L,
            height: M,
            lastPoint: [i, h]
          };
        }
        get box() {
          return this.#e;
        }
        getNewOutline(A, n) {
          const {
            x: f,
            y: p,
            width: F,
            height: r
          } = this.#e, [w, t, i, h] = this.#t, d = F * i, E = r * h, k = f * i + w, L = p * h + t, M = new x({
            x: this.#r[0] * d + k,
            y: this.#r[1] * E + L
          }, this.#t, this.#i, A, this.#n, n ?? this.#s);
          for (let B = 2; B < this.#r.length; B += 2)
            M.add({
              x: this.#r[B] * d + k,
              y: this.#r[B + 1] * E + L
            });
          return M.getOutlines();
        }
      }
    })
  ),
  /***/
  362: (
    /***/
    ((V, l, a) => {
      a.d(l, {
        /* harmony export */
        EditorToolbar: () => (
          /* binding */
          S
        ),
        /* harmony export */
        HighlightToolbar: () => (
          /* binding */
          v
        )
        /* harmony export */
      });
      var s = a(419);
      class S {
        #t = null;
        #e = null;
        #s;
        #n = null;
        constructor(x) {
          this.#s = x;
        }
        render() {
          const x = this.#t = document.createElement("div");
          x.className = "editToolbar", x.setAttribute("role", "toolbar"), x.addEventListener("contextmenu", s.noContextMenu), x.addEventListener("pointerdown", S.#r);
          const C = this.#n = document.createElement("div");
          C.className = "buttons", x.append(C);
          const T = this.#s.toolbarPosition;
          if (T) {
            const {
              style: A
            } = x, n = this.#s._uiManager.direction === "ltr" ? 1 - T[0] : T[0];
            A.insetInlineEnd = `${100 * n}%`, A.top = `calc(${100 * T[1]}% + var(--editor-toolbar-vert-offset))`;
          }
          return this.#l(), x;
        }
        static #r(x) {
          x.stopPropagation();
        }
        #i(x) {
          this.#s._focusEventsAllowed = !1, x.preventDefault(), x.stopPropagation();
        }
        #a(x) {
          this.#s._focusEventsAllowed = !0, x.preventDefault(), x.stopPropagation();
        }
        #h(x) {
          x.addEventListener("focusin", this.#i.bind(this), {
            capture: !0
          }), x.addEventListener("focusout", this.#a.bind(this), {
            capture: !0
          }), x.addEventListener("contextmenu", s.noContextMenu);
        }
        hide() {
          this.#t.classList.add("hidden"), this.#e?.hideDropdown();
        }
        show() {
          this.#t.classList.remove("hidden");
        }
        #l() {
          const x = document.createElement("button");
          x.className = "delete", x.tabIndex = 0, x.setAttribute("data-l10n-id", `pdfjs-editor-remove-${this.#s.editorType}-button`), this.#h(x), x.addEventListener("click", (C) => {
            this.#s._uiManager.delete();
          }), this.#n.append(x);
        }
        get #u() {
          const x = document.createElement("div");
          return x.className = "divider", x;
        }
        addAltTextButton(x) {
          this.#h(x), this.#n.prepend(x, this.#u);
        }
        addColorPicker(x) {
          this.#e = x;
          const C = x.renderButton();
          this.#h(C), this.#n.prepend(C, this.#u);
        }
        remove() {
          this.#t.remove(), this.#e?.destroy(), this.#e = null;
        }
      }
      class v {
        #t = null;
        #e = null;
        #s;
        constructor(x) {
          this.#s = x;
        }
        #n() {
          const x = this.#e = document.createElement("div");
          x.className = "editToolbar", x.setAttribute("role", "toolbar"), x.addEventListener("contextmenu", s.noContextMenu);
          const C = this.#t = document.createElement("div");
          return C.className = "buttons", x.append(C), this.#i(), x;
        }
        #r(x, C) {
          let T = 0, A = 0;
          for (const n of x) {
            const f = n.y + n.height;
            if (f < T)
              continue;
            const p = n.x + (C ? n.width : 0);
            if (f > T) {
              A = p, T = f;
              continue;
            }
            C ? p > A && (A = p) : p < A && (A = p);
          }
          return [C ? 1 - A : A, T];
        }
        show(x, C, T) {
          const [A, n] = this.#r(C, T), {
            style: f
          } = this.#e ||= this.#n();
          x.append(this.#e), f.insetInlineEnd = `${100 * A}%`, f.top = `calc(${100 * n}% + var(--editor-toolbar-vert-offset))`;
        }
        hide() {
          this.#e.remove();
        }
        #i() {
          const x = document.createElement("button");
          x.className = "highlightButton", x.tabIndex = 0, x.setAttribute("data-l10n-id", "pdfjs-highlight-floating-button1");
          const C = document.createElement("span");
          x.append(C), C.className = "visuallyHidden", C.setAttribute("data-l10n-id", "pdfjs-highlight-floating-button-label"), x.addEventListener("contextmenu", s.noContextMenu), x.addEventListener("click", () => {
            this.#s.highlightSelection("floating_button");
          }), this.#t.append(x);
        }
      }
    })
  ),
  /***/
  830: (
    /***/
    ((V, l, a) => {
      a.d(l, {
        /* harmony export */
        AnnotationEditorUIManager: () => (
          /* binding */
          p
        ),
        /* harmony export */
        ColorManager: () => (
          /* binding */
          f
        ),
        /* harmony export */
        KeyboardManager: () => (
          /* binding */
          n
        ),
        /* harmony export */
        bindEvents: () => (
          /* binding */
          _
        ),
        /* harmony export */
        opacityToHex: () => (
          /* binding */
          x
        )
        /* harmony export */
      });
      var s = a(292), S = a(419), v = a(362);
      function _(F, r, w) {
        for (const t of w)
          r.addEventListener(t, F[t].bind(F));
      }
      function x(F) {
        return Math.round(Math.min(255, Math.max(1, 255 * F))).toString(16).padStart(2, "0");
      }
      class C {
        #t = 0;
        constructor() {
        }
        get id() {
          return `${s.AnnotationEditorPrefix}${this.#t++}`;
        }
      }
      class T {
        #t = (0, s.getUuid)();
        #e = 0;
        #s = null;
        static get _isSVGFittingCanvas() {
          const r = 'data:image/svg+xml;charset=UTF-8,<svg viewBox="0 0 1 1" width="1" height="1" xmlns="http://www.w3.org/2000/svg"><rect width="1" height="1" style="fill:red;"/></svg>', t = new OffscreenCanvas(1, 3).getContext("2d"), i = new Image();
          i.src = r;
          const h = i.decode().then(() => (t.drawImage(i, 0, 0, 1, 1, 0, 0, 1, 3), new Uint32Array(t.getImageData(0, 0, 1, 1).data.buffer)[0] === 0));
          return (0, s.shadow)(this, "_isSVGFittingCanvas", h);
        }
        async #n(r, w) {
          this.#s ||= /* @__PURE__ */ new Map();
          let t = this.#s.get(r);
          if (t === null)
            return null;
          if (t?.bitmap)
            return t.refCounter += 1, t;
          try {
            t ||= {
              bitmap: null,
              id: `image_${this.#t}_${this.#e++}`,
              refCounter: 0,
              isSvg: !1
            };
            let i;
            if (typeof w == "string" ? (t.url = w, i = await (0, S.fetchData)(w, "blob")) : i = t.file = w, i.type === "image/svg+xml") {
              const h = T._isSVGFittingCanvas, d = new FileReader(), E = new Image(), k = new Promise((L, M) => {
                E.onload = () => {
                  t.bitmap = E, t.isSvg = !0, L();
                }, d.onload = async () => {
                  const B = t.svgUrl = d.result;
                  E.src = await h ? `${B}#svgView(preserveAspectRatio(none))` : B;
                }, E.onerror = d.onerror = M;
              });
              d.readAsDataURL(i), await k;
            } else
              t.bitmap = await createImageBitmap(i);
            t.refCounter = 1;
          } catch (i) {
            console.error(i), t = null;
          }
          return this.#s.set(r, t), t && this.#s.set(t.id, t), t;
        }
        async getFromFile(r) {
          const {
            lastModified: w,
            name: t,
            size: i,
            type: h
          } = r;
          return this.#n(`${w}_${t}_${i}_${h}`, r);
        }
        async getFromUrl(r) {
          return this.#n(r, r);
        }
        async getFromId(r) {
          this.#s ||= /* @__PURE__ */ new Map();
          const w = this.#s.get(r);
          return w ? w.bitmap ? (w.refCounter += 1, w) : w.file ? this.getFromFile(w.file) : this.getFromUrl(w.url) : null;
        }
        getSvgUrl(r) {
          const w = this.#s.get(r);
          return w?.isSvg ? w.svgUrl : null;
        }
        deleteId(r) {
          this.#s ||= /* @__PURE__ */ new Map();
          const w = this.#s.get(r);
          w && (w.refCounter -= 1, w.refCounter === 0 && (w.bitmap = null));
        }
        isValidId(r) {
          return r.startsWith(`image_${this.#t}_`);
        }
      }
      class A {
        #t = [];
        #e = !1;
        #s;
        #n = -1;
        constructor(r = 128) {
          this.#s = r;
        }
        add({
          cmd: r,
          undo: w,
          post: t,
          mustExec: i,
          type: h = NaN,
          overwriteIfSameType: d = !1,
          keepUndo: E = !1
        }) {
          if (i && r(), this.#e)
            return;
          const k = {
            cmd: r,
            undo: w,
            post: t,
            type: h
          };
          if (this.#n === -1) {
            this.#t.length > 0 && (this.#t.length = 0), this.#n = 0, this.#t.push(k);
            return;
          }
          if (d && this.#t[this.#n].type === h) {
            E && (k.undo = this.#t[this.#n].undo), this.#t[this.#n] = k;
            return;
          }
          const L = this.#n + 1;
          L === this.#s ? this.#t.splice(0, 1) : (this.#n = L, L < this.#t.length && this.#t.splice(L)), this.#t.push(k);
        }
        undo() {
          if (this.#n === -1)
            return;
          this.#e = !0;
          const {
            undo: r,
            post: w
          } = this.#t[this.#n];
          r(), w?.(), this.#e = !1, this.#n -= 1;
        }
        redo() {
          if (this.#n < this.#t.length - 1) {
            this.#n += 1, this.#e = !0;
            const {
              cmd: r,
              post: w
            } = this.#t[this.#n];
            r(), w?.(), this.#e = !1;
          }
        }
        hasSomethingToUndo() {
          return this.#n !== -1;
        }
        hasSomethingToRedo() {
          return this.#n < this.#t.length - 1;
        }
        destroy() {
          this.#t = null;
        }
      }
      class n {
        constructor(r) {
          this.buffer = [], this.callbacks = /* @__PURE__ */ new Map(), this.allKeys = /* @__PURE__ */ new Set();
          const {
            isMac: w
          } = s.FeatureTest.platform;
          for (const [t, i, h = {}] of r)
            for (const d of t) {
              const E = d.startsWith("mac+");
              w && E ? (this.callbacks.set(d.slice(4), {
                callback: i,
                options: h
              }), this.allKeys.add(d.split("+").at(-1))) : !w && !E && (this.callbacks.set(d, {
                callback: i,
                options: h
              }), this.allKeys.add(d.split("+").at(-1)));
            }
        }
        #t(r) {
          r.altKey && this.buffer.push("alt"), r.ctrlKey && this.buffer.push("ctrl"), r.metaKey && this.buffer.push("meta"), r.shiftKey && this.buffer.push("shift"), this.buffer.push(r.key);
          const w = this.buffer.join("+");
          return this.buffer.length = 0, w;
        }
        exec(r, w) {
          if (!this.allKeys.has(w.key))
            return;
          const t = this.callbacks.get(this.#t(w));
          if (!t)
            return;
          const {
            callback: i,
            options: {
              bubbles: h = !1,
              args: d = [],
              checker: E = null
            }
          } = t;
          E && !E(r, w) || (i.bind(r, ...d, w)(), h || (w.stopPropagation(), w.preventDefault()));
        }
      }
      class f {
        static _colorsMapping = /* @__PURE__ */ new Map([["CanvasText", [0, 0, 0]], ["Canvas", [255, 255, 255]]]);
        get _colors() {
          const r = /* @__PURE__ */ new Map([["CanvasText", null], ["Canvas", null]]);
          return (0, S.getColorValues)(r), (0, s.shadow)(this, "_colors", r);
        }
        convert(r) {
          const w = (0, S.getRGB)(r);
          if (!window.matchMedia("(forced-colors: active)").matches)
            return w;
          for (const [t, i] of this._colors)
            if (i.every((h, d) => h === w[d]))
              return f._colorsMapping.get(t);
          return w;
        }
        getHexCode(r) {
          const w = this._colors.get(r);
          return w ? s.Util.makeHexColor(...w) : r;
        }
      }
      class p {
        #t = null;
        #e = /* @__PURE__ */ new Map();
        #s = /* @__PURE__ */ new Map();
        #n = null;
        #r = null;
        #i = null;
        #a = new A();
        #h = 0;
        #l = /* @__PURE__ */ new Set();
        #u = null;
        #d = null;
        #c = /* @__PURE__ */ new Set();
        #o = !1;
        #p = null;
        #g = null;
        #f = null;
        #b = !1;
        #m = null;
        #w = new C();
        #y = !1;
        #S = !1;
        #F = null;
        #I = null;
        #R = null;
        #A = s.AnnotationEditorType.NONE;
        #v = /* @__PURE__ */ new Set();
        #x = null;
        #E = null;
        #D = null;
        #C = this.blur.bind(this);
        #L = this.focus.bind(this);
        #T = this.copy.bind(this);
        #M = this.cut.bind(this);
        #_ = this.paste.bind(this);
        #P = this.keydown.bind(this);
        #U = this.keyup.bind(this);
        #$ = this.onEditingAction.bind(this);
        #q = this.onPageChanging.bind(this);
        #V = this.onScaleChanging.bind(this);
        #H = this.#rt.bind(this);
        #N = this.onRotationChanging.bind(this);
        #W = {
          isEditing: !1,
          isEmpty: !0,
          hasSomethingToUndo: !1,
          hasSomethingToRedo: !1,
          hasSelectedEditor: !1,
          hasSelectedText: !1
        };
        #G = [0, 0];
        #O = null;
        #z = null;
        #Z = null;
        static TRANSLATE_SMALL = 1;
        static TRANSLATE_BIG = 10;
        static get _keyboardManager() {
          const r = p.prototype, w = (d) => d.#z.contains(document.activeElement) && document.activeElement.tagName !== "BUTTON" && d.hasSomethingToControl(), t = (d, {
            target: E
          }) => {
            if (E instanceof HTMLInputElement) {
              const {
                type: k
              } = E;
              return k !== "text" && k !== "number";
            }
            return !0;
          }, i = this.TRANSLATE_SMALL, h = this.TRANSLATE_BIG;
          return (0, s.shadow)(this, "_keyboardManager", new n([[["ctrl+a", "mac+meta+a"], r.selectAll, {
            checker: t
          }], [["ctrl+z", "mac+meta+z"], r.undo, {
            checker: t
          }], [["ctrl+y", "ctrl+shift+z", "mac+meta+shift+z", "ctrl+shift+Z", "mac+meta+shift+Z"], r.redo, {
            checker: t
          }], [["Backspace", "alt+Backspace", "ctrl+Backspace", "shift+Backspace", "mac+Backspace", "mac+alt+Backspace", "mac+ctrl+Backspace", "Delete", "ctrl+Delete", "shift+Delete", "mac+Delete"], r.delete, {
            checker: t
          }], [["Enter", "mac+Enter"], r.addNewEditorFromKeyboard, {
            checker: (d, {
              target: E
            }) => !(E instanceof HTMLButtonElement) && d.#z.contains(E) && !d.isEnterHandled
          }], [[" ", "mac+ "], r.addNewEditorFromKeyboard, {
            checker: (d, {
              target: E
            }) => !(E instanceof HTMLButtonElement) && d.#z.contains(document.activeElement)
          }], [["Escape", "mac+Escape"], r.unselectAll], [["ArrowLeft", "mac+ArrowLeft"], r.translateSelectedEditors, {
            args: [-i, 0],
            checker: w
          }], [["ctrl+ArrowLeft", "mac+shift+ArrowLeft"], r.translateSelectedEditors, {
            args: [-h, 0],
            checker: w
          }], [["ArrowRight", "mac+ArrowRight"], r.translateSelectedEditors, {
            args: [i, 0],
            checker: w
          }], [["ctrl+ArrowRight", "mac+shift+ArrowRight"], r.translateSelectedEditors, {
            args: [h, 0],
            checker: w
          }], [["ArrowUp", "mac+ArrowUp"], r.translateSelectedEditors, {
            args: [0, -i],
            checker: w
          }], [["ctrl+ArrowUp", "mac+shift+ArrowUp"], r.translateSelectedEditors, {
            args: [0, -h],
            checker: w
          }], [["ArrowDown", "mac+ArrowDown"], r.translateSelectedEditors, {
            args: [0, i],
            checker: w
          }], [["ctrl+ArrowDown", "mac+shift+ArrowDown"], r.translateSelectedEditors, {
            args: [0, h],
            checker: w
          }]]));
        }
        constructor(r, w, t, i, h, d, E, k, L) {
          this.#z = r, this.#Z = w, this.#n = t, this._eventBus = i, this._eventBus._on("editingaction", this.#$), this._eventBus._on("pagechanging", this.#q), this._eventBus._on("scalechanging", this.#V), this._eventBus._on("rotationchanging", this.#N), this.#at(), this.#Q(), this.#r = h.annotationStorage, this.#p = h.filterFactory, this.#E = d, this.#f = E || null, this.#o = k, this.#R = L || null, this.viewParameters = {
            realScale: S.PixelsPerInch.PDF_TO_CSS_UNITS,
            rotation: 0
          }, this.isShiftKeyDown = !1;
        }
        destroy() {
          this.#J(), this.#K(), this._eventBus._off("editingaction", this.#$), this._eventBus._off("pagechanging", this.#q), this._eventBus._off("scalechanging", this.#V), this._eventBus._off("rotationchanging", this.#N);
          for (const r of this.#s.values())
            r.destroy();
          this.#s.clear(), this.#e.clear(), this.#c.clear(), this.#t = null, this.#v.clear(), this.#a.destroy(), this.#n?.destroy(), this.#m?.hide(), this.#m = null, this.#g && (clearTimeout(this.#g), this.#g = null), this.#O && (clearTimeout(this.#O), this.#O = null), this.#ot();
        }
        async mlGuess(r) {
          return this.#R?.guess(r) || null;
        }
        get hasMLManager() {
          return !!this.#R;
        }
        get hcmFilter() {
          return (0, s.shadow)(this, "hcmFilter", this.#E ? this.#p.addHCMFilter(this.#E.foreground, this.#E.background) : "none");
        }
        get direction() {
          return (0, s.shadow)(this, "direction", getComputedStyle(this.#z).direction);
        }
        get highlightColors() {
          return (0, s.shadow)(this, "highlightColors", this.#f ? new Map(this.#f.split(",").map((r) => r.split("=").map((w) => w.trim()))) : null);
        }
        get highlightColorNames() {
          return (0, s.shadow)(this, "highlightColorNames", this.highlightColors ? new Map(Array.from(this.highlightColors, (r) => r.reverse())) : null);
        }
        setMainHighlightColorPicker(r) {
          this.#I = r;
        }
        editAltText(r) {
          this.#n?.editAltText(this, r);
        }
        onPageChanging({
          pageNumber: r
        }) {
          this.#h = r - 1;
        }
        focusMainContainer() {
          this.#z.focus();
        }
        findParent(r, w) {
          for (const t of this.#s.values()) {
            const {
              x: i,
              y: h,
              width: d,
              height: E
            } = t.div.getBoundingClientRect();
            if (r >= i && r <= i + d && w >= h && w <= h + E)
              return t;
          }
          return null;
        }
        disableUserSelect(r = !1) {
          this.#Z.classList.toggle("noUserSelect", r);
        }
        addShouldRescale(r) {
          this.#c.add(r);
        }
        removeShouldRescale(r) {
          this.#c.delete(r);
        }
        onScaleChanging({
          scale: r
        }) {
          this.commitOrRemove(), this.viewParameters.realScale = r * S.PixelsPerInch.PDF_TO_CSS_UNITS;
          for (const w of this.#c)
            w.onScaleChanging();
        }
        onRotationChanging({
          pagesRotation: r
        }) {
          this.commitOrRemove(), this.viewParameters.rotation = r;
        }
        #X({
          anchorNode: r
        }) {
          return r.nodeType === Node.TEXT_NODE ? r.parentElement : r;
        }
        highlightSelection(r = "") {
          const w = document.getSelection();
          if (!w || w.isCollapsed)
            return;
          const {
            anchorNode: t,
            anchorOffset: i,
            focusNode: h,
            focusOffset: d
          } = w, E = w.toString(), L = this.#X(w).closest(".textLayer"), M = this.getSelectionBoxes(L);
          if (M) {
            w.empty(), this.#A === s.AnnotationEditorType.NONE && (this._eventBus.dispatch("showannotationeditorui", {
              source: this,
              mode: s.AnnotationEditorType.HIGHLIGHT
            }), this.showAllEditors("highlight", !0, !0));
            for (const B of this.#s.values())
              if (B.hasTextLayer(L)) {
                B.createAndAddNewEditor({
                  x: 0,
                  y: 0
                }, !1, {
                  methodOfCreation: r,
                  boxes: M,
                  anchorNode: t,
                  anchorOffset: i,
                  focusNode: h,
                  focusOffset: d,
                  text: E
                });
                break;
              }
          }
        }
        #nt() {
          const r = document.getSelection();
          if (!r || r.isCollapsed)
            return;
          const t = this.#X(r).closest(".textLayer"), i = this.getSelectionBoxes(t);
          i && (this.#m ||= new v.HighlightToolbar(this), this.#m.show(t, i, this.direction === "ltr"));
        }
        addToAnnotationStorage(r) {
          !r.isEmpty() && this.#r && !this.#r.has(r.id) && this.#r.setValue(r.id, r);
        }
        #rt() {
          const r = document.getSelection();
          if (!r || r.isCollapsed) {
            this.#x && (this.#m?.hide(), this.#x = null, this.#k({
              hasSelectedText: !1
            }));
            return;
          }
          const {
            anchorNode: w
          } = r;
          if (w === this.#x)
            return;
          if (!this.#X(r).closest(".textLayer")) {
            this.#x && (this.#m?.hide(), this.#x = null, this.#k({
              hasSelectedText: !1
            }));
            return;
          }
          if (this.#m?.hide(), this.#x = w, this.#k({
            hasSelectedText: !0
          }), !(this.#A !== s.AnnotationEditorType.HIGHLIGHT && this.#A !== s.AnnotationEditorType.NONE) && (this.#A === s.AnnotationEditorType.HIGHLIGHT && this.showAllEditors("highlight", !0, !0), this.#b = this.isShiftKeyDown, !this.isShiftKeyDown)) {
            const h = (d) => {
              d.type === "pointerup" && d.button !== 0 || (window.removeEventListener("pointerup", h), window.removeEventListener("blur", h), d.type === "pointerup" && this.#Y("main_toolbar"));
            };
            window.addEventListener("pointerup", h), window.addEventListener("blur", h);
          }
        }
        #Y(r = "") {
          this.#A === s.AnnotationEditorType.HIGHLIGHT ? this.highlightSelection(r) : this.#o && this.#nt();
        }
        #at() {
          document.addEventListener("selectionchange", this.#H);
        }
        #ot() {
          document.removeEventListener("selectionchange", this.#H);
        }
        #lt() {
          window.addEventListener("focus", this.#L), window.addEventListener("blur", this.#C);
        }
        #K() {
          window.removeEventListener("focus", this.#L), window.removeEventListener("blur", this.#C);
        }
        blur() {
          if (this.isShiftKeyDown = !1, this.#b && (this.#b = !1, this.#Y("main_toolbar")), !this.hasSelection)
            return;
          const {
            activeElement: r
          } = document;
          for (const w of this.#v)
            if (w.div.contains(r)) {
              this.#F = [w, r], w._focusEventsAllowed = !1;
              break;
            }
        }
        focus() {
          if (!this.#F)
            return;
          const [r, w] = this.#F;
          this.#F = null, w.addEventListener("focusin", () => {
            r._focusEventsAllowed = !0;
          }, {
            once: !0
          }), w.focus();
        }
        #Q() {
          window.addEventListener("keydown", this.#P), window.addEventListener("keyup", this.#U);
        }
        #J() {
          window.removeEventListener("keydown", this.#P), window.removeEventListener("keyup", this.#U);
        }
        #tt() {
          document.addEventListener("copy", this.#T), document.addEventListener("cut", this.#M), document.addEventListener("paste", this.#_);
        }
        #et() {
          document.removeEventListener("copy", this.#T), document.removeEventListener("cut", this.#M), document.removeEventListener("paste", this.#_);
        }
        addEditListeners() {
          this.#Q(), this.#tt();
        }
        removeEditListeners() {
          this.#J(), this.#et();
        }
        copy(r) {
          if (r.preventDefault(), this.#t?.commitOrRemove(), !this.hasSelection)
            return;
          const w = [];
          for (const t of this.#v) {
            const i = t.serialize(!0);
            i && w.push(i);
          }
          w.length !== 0 && r.clipboardData.setData("application/pdfjs", JSON.stringify(w));
        }
        cut(r) {
          this.copy(r), this.delete();
        }
        paste(r) {
          r.preventDefault();
          const {
            clipboardData: w
          } = r;
          for (const h of w.items)
            for (const d of this.#d)
              if (d.isHandlingMimeForPasting(h.type)) {
                d.paste(h, this.currentLayer);
                return;
              }
          let t = w.getData("application/pdfjs");
          if (!t)
            return;
          try {
            t = JSON.parse(t);
          } catch (h) {
            (0, s.warn)(`paste: "${h.message}".`);
            return;
          }
          if (!Array.isArray(t))
            return;
          this.unselectAll();
          const i = this.currentLayer;
          try {
            const h = [];
            for (const k of t) {
              const L = i.deserialize(k);
              if (!L)
                return;
              h.push(L);
            }
            const d = () => {
              for (const k of h)
                this.#st(k);
              this.#it(h);
            }, E = () => {
              for (const k of h)
                k.remove();
            };
            this.addCommands({
              cmd: d,
              undo: E,
              mustExec: !0
            });
          } catch (h) {
            (0, s.warn)(`paste: "${h.message}".`);
          }
        }
        keydown(r) {
          !this.isShiftKeyDown && r.key === "Shift" && (this.isShiftKeyDown = !0), this.#A !== s.AnnotationEditorType.NONE && !this.isEditorHandlingKeyboard && p._keyboardManager.exec(this, r);
        }
        keyup(r) {
          this.isShiftKeyDown && r.key === "Shift" && (this.isShiftKeyDown = !1, this.#b && (this.#b = !1, this.#Y("main_toolbar")));
        }
        onEditingAction({
          name: r
        }) {
          switch (r) {
            case "undo":
            case "redo":
            case "delete":
            case "selectAll":
              this[r]();
              break;
            case "highlightSelection":
              this.highlightSelection("context_menu");
              break;
          }
        }
        #k(r) {
          Object.entries(r).some(([t, i]) => this.#W[t] !== i) && (this._eventBus.dispatch("annotationeditorstateschanged", {
            source: this,
            details: Object.assign(this.#W, r)
          }), this.#A === s.AnnotationEditorType.HIGHLIGHT && r.hasSelectedEditor === !1 && this.#B([[s.AnnotationEditorParamsType.HIGHLIGHT_FREE, !0]]));
        }
        #B(r) {
          this._eventBus.dispatch("annotationeditorparamschanged", {
            source: this,
            details: r
          });
        }
        setEditingState(r) {
          r ? (this.#lt(), this.#tt(), this.#k({
            isEditing: this.#A !== s.AnnotationEditorType.NONE,
            isEmpty: this.#j(),
            hasSomethingToUndo: this.#a.hasSomethingToUndo(),
            hasSomethingToRedo: this.#a.hasSomethingToRedo(),
            hasSelectedEditor: !1
          })) : (this.#K(), this.#et(), this.#k({
            isEditing: !1
          }), this.disableUserSelect(!1));
        }
        registerEditorTypes(r) {
          if (!this.#d) {
            this.#d = r;
            for (const w of this.#d)
              this.#B(w.defaultPropertiesToUpdate);
          }
        }
        getId() {
          return this.#w.id;
        }
        get currentLayer() {
          return this.#s.get(this.#h);
        }
        getLayer(r) {
          return this.#s.get(r);
        }
        get currentPageIndex() {
          return this.#h;
        }
        addLayer(r) {
          this.#s.set(r.pageIndex, r), this.#y ? r.enable() : r.disable();
        }
        removeLayer(r) {
          this.#s.delete(r.pageIndex);
        }
        updateMode(r, w = null, t = !1) {
          if (this.#A !== r) {
            if (this.#A = r, r === s.AnnotationEditorType.NONE) {
              this.setEditingState(!1), this.#ct();
              return;
            }
            this.setEditingState(!0), this.#ht(), this.unselectAll();
            for (const i of this.#s.values())
              i.updateMode(r);
            if (!w && t) {
              this.addNewEditorFromKeyboard();
              return;
            }
            if (w) {
              for (const i of this.#e.values())
                if (i.annotationElementId === w) {
                  this.setSelected(i), i.enterInEditMode();
                  break;
                }
            }
          }
        }
        addNewEditorFromKeyboard() {
          this.currentLayer.canCreateNewEmptyEditor() && this.currentLayer.addNewEditor();
        }
        updateToolbar(r) {
          r !== this.#A && this._eventBus.dispatch("switchannotationeditormode", {
            source: this,
            mode: r
          });
        }
        updateParams(r, w) {
          if (this.#d) {
            switch (r) {
              case s.AnnotationEditorParamsType.CREATE:
                this.currentLayer.addNewEditor();
                return;
              case s.AnnotationEditorParamsType.HIGHLIGHT_DEFAULT_COLOR:
                this.#I?.updateColor(w);
                break;
              case s.AnnotationEditorParamsType.HIGHLIGHT_SHOW_ALL:
                this._eventBus.dispatch("reporttelemetry", {
                  source: this,
                  details: {
                    type: "editing",
                    data: {
                      type: "highlight",
                      action: "toggle_visibility"
                    }
                  }
                }), (this.#D ||= /* @__PURE__ */ new Map()).set(r, w), this.showAllEditors("highlight", w);
                break;
            }
            for (const t of this.#v)
              t.updateParams(r, w);
            for (const t of this.#d)
              t.updateDefaultParams(r, w);
          }
        }
        showAllEditors(r, w, t = !1) {
          for (const h of this.#e.values())
            h.editorType === r && h.show(w);
          (this.#D?.get(s.AnnotationEditorParamsType.HIGHLIGHT_SHOW_ALL) ?? !0) !== w && this.#B([[s.AnnotationEditorParamsType.HIGHLIGHT_SHOW_ALL, w]]);
        }
        enableWaiting(r = !1) {
          if (this.#S !== r) {
            this.#S = r;
            for (const w of this.#s.values())
              r ? w.disableClick() : w.enableClick(), w.div.classList.toggle("waiting", r);
          }
        }
        #ht() {
          if (!this.#y) {
            this.#y = !0;
            for (const r of this.#s.values())
              r.enable();
            for (const r of this.#e.values())
              r.enable();
          }
        }
        #ct() {
          if (this.unselectAll(), this.#y) {
            this.#y = !1;
            for (const r of this.#s.values())
              r.disable();
            for (const r of this.#e.values())
              r.disable();
          }
        }
        getEditors(r) {
          const w = [];
          for (const t of this.#e.values())
            t.pageIndex === r && w.push(t);
          return w;
        }
        getEditor(r) {
          return this.#e.get(r);
        }
        addEditor(r) {
          this.#e.set(r.id, r);
        }
        removeEditor(r) {
          r.div.contains(document.activeElement) && (this.#g && clearTimeout(this.#g), this.#g = setTimeout(() => {
            this.focusMainContainer(), this.#g = null;
          }, 0)), this.#e.delete(r.id), this.unselect(r), (!r.annotationElementId || !this.#l.has(r.annotationElementId)) && this.#r?.remove(r.id);
        }
        addDeletedAnnotationElement(r) {
          this.#l.add(r.annotationElementId), this.addChangedExistingAnnotation(r), r.deleted = !0;
        }
        isDeletedAnnotationElement(r) {
          return this.#l.has(r);
        }
        removeDeletedAnnotationElement(r) {
          this.#l.delete(r.annotationElementId), this.removeChangedExistingAnnotation(r), r.deleted = !1;
        }
        #st(r) {
          const w = this.#s.get(r.pageIndex);
          w ? w.addOrRebuild(r) : (this.addEditor(r), this.addToAnnotationStorage(r));
        }
        setActiveEditor(r) {
          this.#t !== r && (this.#t = r, r && this.#B(r.propertiesToUpdate));
        }
        get #ut() {
          let r = null;
          for (r of this.#v)
            ;
          return r;
        }
        updateUI(r) {
          this.#ut === r && this.#B(r.propertiesToUpdate);
        }
        toggleSelected(r) {
          if (this.#v.has(r)) {
            this.#v.delete(r), r.unselect(), this.#k({
              hasSelectedEditor: this.hasSelection
            });
            return;
          }
          this.#v.add(r), r.select(), this.#B(r.propertiesToUpdate), this.#k({
            hasSelectedEditor: !0
          });
        }
        setSelected(r) {
          for (const w of this.#v)
            w !== r && w.unselect();
          this.#v.clear(), this.#v.add(r), r.select(), this.#B(r.propertiesToUpdate), this.#k({
            hasSelectedEditor: !0
          });
        }
        isSelected(r) {
          return this.#v.has(r);
        }
        get firstSelectedEditor() {
          return this.#v.values().next().value;
        }
        unselect(r) {
          r.unselect(), this.#v.delete(r), this.#k({
            hasSelectedEditor: this.hasSelection
          });
        }
        get hasSelection() {
          return this.#v.size !== 0;
        }
        get isEnterHandled() {
          return this.#v.size === 1 && this.firstSelectedEditor.isEnterHandled;
        }
        undo() {
          this.#a.undo(), this.#k({
            hasSomethingToUndo: this.#a.hasSomethingToUndo(),
            hasSomethingToRedo: !0,
            isEmpty: this.#j()
          });
        }
        redo() {
          this.#a.redo(), this.#k({
            hasSomethingToUndo: !0,
            hasSomethingToRedo: this.#a.hasSomethingToRedo(),
            isEmpty: this.#j()
          });
        }
        addCommands(r) {
          this.#a.add(r), this.#k({
            hasSomethingToUndo: !0,
            hasSomethingToRedo: !1,
            isEmpty: this.#j()
          });
        }
        #j() {
          if (this.#e.size === 0)
            return !0;
          if (this.#e.size === 1)
            for (const r of this.#e.values())
              return r.isEmpty();
          return !1;
        }
        delete() {
          if (this.commitOrRemove(), !this.hasSelection)
            return;
          const r = [...this.#v], w = () => {
            for (const i of r)
              i.remove();
          }, t = () => {
            for (const i of r)
              this.#st(i);
          };
          this.addCommands({
            cmd: w,
            undo: t,
            mustExec: !0
          });
        }
        commitOrRemove() {
          this.#t?.commitOrRemove();
        }
        hasSomethingToControl() {
          return this.#t || this.hasSelection;
        }
        #it(r) {
          for (const w of this.#v)
            w.unselect();
          this.#v.clear();
          for (const w of r)
            w.isEmpty() || (this.#v.add(w), w.select());
          this.#k({
            hasSelectedEditor: this.hasSelection
          });
        }
        selectAll() {
          for (const r of this.#v)
            r.commit();
          this.#it(this.#e.values());
        }
        unselectAll() {
          if (!(this.#t && (this.#t.commitOrRemove(), this.#A !== s.AnnotationEditorType.NONE)) && this.hasSelection) {
            for (const r of this.#v)
              r.unselect();
            this.#v.clear(), this.#k({
              hasSelectedEditor: !1
            });
          }
        }
        translateSelectedEditors(r, w, t = !1) {
          if (t || this.commitOrRemove(), !this.hasSelection)
            return;
          this.#G[0] += r, this.#G[1] += w;
          const [i, h] = this.#G, d = [...this.#v], E = 1e3;
          this.#O && clearTimeout(this.#O), this.#O = setTimeout(() => {
            this.#O = null, this.#G[0] = this.#G[1] = 0, this.addCommands({
              cmd: () => {
                for (const k of d)
                  this.#e.has(k.id) && k.translateInPage(i, h);
              },
              undo: () => {
                for (const k of d)
                  this.#e.has(k.id) && k.translateInPage(-i, -h);
              },
              mustExec: !1
            });
          }, E);
          for (const k of d)
            k.translateInPage(r, w);
        }
        setUpDragSession() {
          if (this.hasSelection) {
            this.disableUserSelect(!0), this.#u = /* @__PURE__ */ new Map();
            for (const r of this.#v)
              this.#u.set(r, {
                savedX: r.x,
                savedY: r.y,
                savedPageIndex: r.pageIndex,
                newX: 0,
                newY: 0,
                newPageIndex: -1
              });
          }
        }
        endDragSession() {
          if (!this.#u)
            return !1;
          this.disableUserSelect(!1);
          const r = this.#u;
          this.#u = null;
          let w = !1;
          for (const [{
            x: i,
            y: h,
            pageIndex: d
          }, E] of r)
            E.newX = i, E.newY = h, E.newPageIndex = d, w ||= i !== E.savedX || h !== E.savedY || d !== E.savedPageIndex;
          if (!w)
            return !1;
          const t = (i, h, d, E) => {
            if (this.#e.has(i.id)) {
              const k = this.#s.get(E);
              k ? i._setParentAndPosition(k, h, d) : (i.pageIndex = E, i.x = h, i.y = d);
            }
          };
          return this.addCommands({
            cmd: () => {
              for (const [i, {
                newX: h,
                newY: d,
                newPageIndex: E
              }] of r)
                t(i, h, d, E);
            },
            undo: () => {
              for (const [i, {
                savedX: h,
                savedY: d,
                savedPageIndex: E
              }] of r)
                t(i, h, d, E);
            },
            mustExec: !0
          }), !0;
        }
        dragSelectedEditors(r, w) {
          if (this.#u)
            for (const t of this.#u.keys())
              t.drag(r, w);
        }
        rebuild(r) {
          if (r.parent === null) {
            const w = this.getLayer(r.pageIndex);
            w ? (w.changeParent(r), w.addOrRebuild(r)) : (this.addEditor(r), this.addToAnnotationStorage(r), r.rebuild());
          } else
            r.parent.addOrRebuild(r);
        }
        get isEditorHandlingKeyboard() {
          return this.getActive()?.shouldGetKeyboardEvents() || this.#v.size === 1 && this.firstSelectedEditor.shouldGetKeyboardEvents();
        }
        isActive(r) {
          return this.#t === r;
        }
        getActive() {
          return this.#t;
        }
        getMode() {
          return this.#A;
        }
        get imageManager() {
          return (0, s.shadow)(this, "imageManager", new T());
        }
        getSelectionBoxes(r) {
          if (!r)
            return null;
          const w = document.getSelection();
          for (let L = 0, M = w.rangeCount; L < M; L++)
            if (!r.contains(w.getRangeAt(L).commonAncestorContainer))
              return null;
          const {
            x: t,
            y: i,
            width: h,
            height: d
          } = r.getBoundingClientRect();
          let E;
          switch (r.getAttribute("data-main-rotation")) {
            case "90":
              E = (L, M, B, U) => ({
                x: (M - i) / d,
                y: 1 - (L + B - t) / h,
                width: U / d,
                height: B / h
              });
              break;
            case "180":
              E = (L, M, B, U) => ({
                x: 1 - (L + B - t) / h,
                y: 1 - (M + U - i) / d,
                width: B / h,
                height: U / d
              });
              break;
            case "270":
              E = (L, M, B, U) => ({
                x: 1 - (M + U - i) / d,
                y: (L - t) / h,
                width: U / d,
                height: B / h
              });
              break;
            default:
              E = (L, M, B, U) => ({
                x: (L - t) / h,
                y: (M - i) / d,
                width: B / h,
                height: U / d
              });
              break;
          }
          const k = [];
          for (let L = 0, M = w.rangeCount; L < M; L++) {
            const B = w.getRangeAt(L);
            if (!B.collapsed)
              for (const {
                x: U,
                y: q,
                width: Z,
                height: K
              } of B.getClientRects())
                Z === 0 || K === 0 || k.push(E(U, q, Z, K));
          }
          return k.length === 0 ? null : k;
        }
        addChangedExistingAnnotation({
          annotationElementId: r,
          id: w
        }) {
          (this.#i ||= /* @__PURE__ */ new Map()).set(r, w);
        }
        removeChangedExistingAnnotation({
          annotationElementId: r
        }) {
          this.#i?.delete(r);
        }
        renderAnnotationElement(r) {
          const w = this.#i?.get(r.data.id);
          if (!w)
            return;
          const t = this.#r.getRawValue(w);
          t && (this.#A === s.AnnotationEditorType.NONE && !t.hasBeenModified || t.renderAnnotationElement(r));
        }
      }
    })
  ),
  /***/
  94: (
    /***/
    ((V, l, a) => {
      a.d(l, {
        /* harmony export */
        PDFFetchStream: () => (
          /* binding */
          C
        )
        /* harmony export */
      });
      var s = a(292), S = a(490);
      function v(n, f, p) {
        return {
          method: "GET",
          headers: n,
          signal: p.signal,
          mode: "cors",
          credentials: f ? "include" : "same-origin",
          redirect: "follow"
        };
      }
      function _(n) {
        const f = new Headers();
        for (const p in n) {
          const F = n[p];
          F !== void 0 && f.append(p, F);
        }
        return f;
      }
      function x(n) {
        return n instanceof Uint8Array ? n.buffer : n instanceof ArrayBuffer ? n : ((0, s.warn)(`getArrayBuffer - unexpected data format: ${n}`), new Uint8Array(n).buffer);
      }
      class C {
        constructor(f) {
          this.source = f, this.isHttp = /^https?:/i.test(f.url), this.httpHeaders = this.isHttp && f.httpHeaders || {}, this._fullRequestReader = null, this._rangeRequestReaders = [];
        }
        get _progressiveDataLength() {
          return this._fullRequestReader?._loaded ?? 0;
        }
        getFullReader() {
          return (0, s.assert)(!this._fullRequestReader, "PDFFetchStream.getFullReader can only be called once."), this._fullRequestReader = new T(this), this._fullRequestReader;
        }
        getRangeReader(f, p) {
          if (p <= this._progressiveDataLength)
            return null;
          const F = new A(this, f, p);
          return this._rangeRequestReaders.push(F), F;
        }
        cancelAllRequests(f) {
          this._fullRequestReader?.cancel(f);
          for (const p of this._rangeRequestReaders.slice(0))
            p.cancel(f);
        }
      }
      class T {
        constructor(f) {
          this._stream = f, this._reader = null, this._loaded = 0, this._filename = null;
          const p = f.source;
          this._withCredentials = p.withCredentials || !1, this._contentLength = p.length, this._headersCapability = Promise.withResolvers(), this._disableRange = p.disableRange || !1, this._rangeChunkSize = p.rangeChunkSize, !this._rangeChunkSize && !this._disableRange && (this._disableRange = !0), this._abortController = new AbortController(), this._isStreamingSupported = !p.disableStream, this._isRangeSupported = !p.disableRange, this._headers = _(this._stream.httpHeaders);
          const F = p.url;
          fetch(F, v(this._headers, this._withCredentials, this._abortController)).then((r) => {
            if (!(0, S.validateResponseStatus)(r.status))
              throw (0, S.createResponseStatusError)(r.status, F);
            this._reader = r.body.getReader(), this._headersCapability.resolve();
            const w = (h) => r.headers.get(h), {
              allowRangeRequests: t,
              suggestedLength: i
            } = (0, S.validateRangeRequestCapabilities)({
              getResponseHeader: w,
              isHttp: this._stream.isHttp,
              rangeChunkSize: this._rangeChunkSize,
              disableRange: this._disableRange
            });
            this._isRangeSupported = t, this._contentLength = i || this._contentLength, this._filename = (0, S.extractFilenameFromHeader)(w), !this._isStreamingSupported && this._isRangeSupported && this.cancel(new s.AbortException("Streaming is disabled."));
          }).catch(this._headersCapability.reject), this.onProgress = null;
        }
        get headersReady() {
          return this._headersCapability.promise;
        }
        get filename() {
          return this._filename;
        }
        get contentLength() {
          return this._contentLength;
        }
        get isRangeSupported() {
          return this._isRangeSupported;
        }
        get isStreamingSupported() {
          return this._isStreamingSupported;
        }
        async read() {
          await this._headersCapability.promise;
          const {
            value: f,
            done: p
          } = await this._reader.read();
          return p ? {
            value: f,
            done: p
          } : (this._loaded += f.byteLength, this.onProgress?.({
            loaded: this._loaded,
            total: this._contentLength
          }), {
            value: x(f),
            done: !1
          });
        }
        cancel(f) {
          this._reader?.cancel(f), this._abortController.abort();
        }
      }
      class A {
        constructor(f, p, F) {
          this._stream = f, this._reader = null, this._loaded = 0;
          const r = f.source;
          this._withCredentials = r.withCredentials || !1, this._readCapability = Promise.withResolvers(), this._isStreamingSupported = !r.disableStream, this._abortController = new AbortController(), this._headers = _(this._stream.httpHeaders), this._headers.append("Range", `bytes=${p}-${F - 1}`);
          const w = r.url;
          fetch(w, v(this._headers, this._withCredentials, this._abortController)).then((t) => {
            if (!(0, S.validateResponseStatus)(t.status))
              throw (0, S.createResponseStatusError)(t.status, w);
            this._readCapability.resolve(), this._reader = t.body.getReader();
          }).catch(this._readCapability.reject), this.onProgress = null;
        }
        get isStreamingSupported() {
          return this._isStreamingSupported;
        }
        async read() {
          await this._readCapability.promise;
          const {
            value: f,
            done: p
          } = await this._reader.read();
          return p ? {
            value: f,
            done: p
          } : (this._loaded += f.byteLength, this.onProgress?.({
            loaded: this._loaded
          }), {
            value: x(f),
            done: !1
          });
        }
        cancel(f) {
          this._reader?.cancel(f), this._abortController.abort();
        }
      }
    })
  ),
  /***/
  10: (
    /***/
    ((V, l, a) => {
      a.d(l, {
        /* harmony export */
        FontFaceObject: () => (
          /* binding */
          v
        ),
        /* harmony export */
        FontLoader: () => (
          /* binding */
          S
        )
        /* harmony export */
      });
      var s = a(292);
      class S {
        #t = /* @__PURE__ */ new Set();
        constructor({
          ownerDocument: x = globalThis.document,
          styleElement: C = null
        }) {
          this._document = x, this.nativeFontFaces = /* @__PURE__ */ new Set(), this.styleElement = null, this.loadingRequests = [], this.loadTestFontId = 0;
        }
        addNativeFontFace(x) {
          this.nativeFontFaces.add(x), this._document.fonts.add(x);
        }
        removeNativeFontFace(x) {
          this.nativeFontFaces.delete(x), this._document.fonts.delete(x);
        }
        insertRule(x) {
          this.styleElement || (this.styleElement = this._document.createElement("style"), this._document.documentElement.getElementsByTagName("head")[0].append(this.styleElement));
          const C = this.styleElement.sheet;
          C.insertRule(x, C.cssRules.length);
        }
        clear() {
          for (const x of this.nativeFontFaces)
            this._document.fonts.delete(x);
          this.nativeFontFaces.clear(), this.#t.clear(), this.styleElement && (this.styleElement.remove(), this.styleElement = null);
        }
        async loadSystemFont({
          systemFontInfo: x,
          _inspectFont: C
        }) {
          if (!(!x || this.#t.has(x.loadedName))) {
            if ((0, s.assert)(!this.disableFontFace, "loadSystemFont shouldn't be called when `disableFontFace` is set."), this.isFontLoadingAPISupported) {
              const {
                loadedName: T,
                src: A,
                style: n
              } = x, f = new FontFace(T, A, n);
              this.addNativeFontFace(f);
              try {
                await f.load(), this.#t.add(T), C?.(x);
              } catch {
                (0, s.warn)(`Cannot load system font: ${x.baseFontName}, installing it could help to improve PDF rendering.`), this.removeNativeFontFace(f);
              }
              return;
            }
            (0, s.unreachable)("Not implemented: loadSystemFont without the Font Loading API.");
          }
        }
        async bind(x) {
          if (x.attached || x.missingFile && !x.systemFontInfo)
            return;
          if (x.attached = !0, x.systemFontInfo) {
            await this.loadSystemFont(x);
            return;
          }
          if (this.isFontLoadingAPISupported) {
            const T = x.createNativeFontFace();
            if (T) {
              this.addNativeFontFace(T);
              try {
                await T.loaded;
              } catch (A) {
                throw (0, s.warn)(`Failed to load font '${T.family}': '${A}'.`), x.disableFontFace = !0, A;
              }
            }
            return;
          }
          const C = x.createFontFaceRule();
          if (C) {
            if (this.insertRule(C), this.isSyncFontLoadingSupported)
              return;
            await new Promise((T) => {
              const A = this._queueLoadingCallback(T);
              this._prepareFontLoadEvent(x, A);
            });
          }
        }
        get isFontLoadingAPISupported() {
          const x = !!this._document?.fonts;
          return (0, s.shadow)(this, "isFontLoadingAPISupported", x);
        }
        get isSyncFontLoadingSupported() {
          let x = !1;
          return (s.isNodeJS || typeof navigator < "u" && typeof navigator?.userAgent == "string" && /Mozilla\/5.0.*?rv:\d+.*? Gecko/.test(navigator.userAgent)) && (x = !0), (0, s.shadow)(this, "isSyncFontLoadingSupported", x);
        }
        _queueLoadingCallback(x) {
          function C() {
            for ((0, s.assert)(!A.done, "completeRequest() cannot be called twice."), A.done = !0; T.length > 0 && T[0].done; ) {
              const n = T.shift();
              setTimeout(n.callback, 0);
            }
          }
          const {
            loadingRequests: T
          } = this, A = {
            done: !1,
            complete: C,
            callback: x
          };
          return T.push(A), A;
        }
        get _loadTestFont() {
          const x = atob("T1RUTwALAIAAAwAwQ0ZGIDHtZg4AAAOYAAAAgUZGVE1lkzZwAAAEHAAAABxHREVGABQAFQAABDgAAAAeT1MvMlYNYwkAAAEgAAAAYGNtYXABDQLUAAACNAAAAUJoZWFk/xVFDQAAALwAAAA2aGhlYQdkA+oAAAD0AAAAJGhtdHgD6AAAAAAEWAAAAAZtYXhwAAJQAAAAARgAAAAGbmFtZVjmdH4AAAGAAAAAsXBvc3T/hgAzAAADeAAAACAAAQAAAAEAALZRFsRfDzz1AAsD6AAAAADOBOTLAAAAAM4KHDwAAAAAA+gDIQAAAAgAAgAAAAAAAAABAAADIQAAAFoD6AAAAAAD6AABAAAAAAAAAAAAAAAAAAAAAQAAUAAAAgAAAAQD6AH0AAUAAAKKArwAAACMAooCvAAAAeAAMQECAAACAAYJAAAAAAAAAAAAAQAAAAAAAAAAAAAAAFBmRWQAwAAuAC4DIP84AFoDIQAAAAAAAQAAAAAAAAAAACAAIAABAAAADgCuAAEAAAAAAAAAAQAAAAEAAAAAAAEAAQAAAAEAAAAAAAIAAQAAAAEAAAAAAAMAAQAAAAEAAAAAAAQAAQAAAAEAAAAAAAUAAQAAAAEAAAAAAAYAAQAAAAMAAQQJAAAAAgABAAMAAQQJAAEAAgABAAMAAQQJAAIAAgABAAMAAQQJAAMAAgABAAMAAQQJAAQAAgABAAMAAQQJAAUAAgABAAMAAQQJAAYAAgABWABYAAAAAAAAAwAAAAMAAAAcAAEAAAAAADwAAwABAAAAHAAEACAAAAAEAAQAAQAAAC7//wAAAC7////TAAEAAAAAAAABBgAAAQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAMAAAAAAAD/gwAyAAAAAQAAAAAAAAAAAAAAAAAAAAABAAQEAAEBAQJYAAEBASH4DwD4GwHEAvgcA/gXBIwMAYuL+nz5tQXkD5j3CBLnEQACAQEBIVhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYAAABAQAADwACAQEEE/t3Dov6fAH6fAT+fPp8+nwHDosMCvm1Cvm1DAz6fBQAAAAAAAABAAAAAMmJbzEAAAAAzgTjFQAAAADOBOQpAAEAAAAAAAAADAAUAAQAAAABAAAAAgABAAAAAAAAAAAD6AAAAAAAAA==");
          return (0, s.shadow)(this, "_loadTestFont", x);
        }
        _prepareFontLoadEvent(x, C) {
          function T(U, q) {
            return U.charCodeAt(q) << 24 | U.charCodeAt(q + 1) << 16 | U.charCodeAt(q + 2) << 8 | U.charCodeAt(q + 3) & 255;
          }
          function A(U, q, Z, K) {
            const Y = U.substring(0, q), G = U.substring(q + Z);
            return Y + K + G;
          }
          let n, f;
          const p = this._document.createElement("canvas");
          p.width = 1, p.height = 1;
          const F = p.getContext("2d");
          let r = 0;
          function w(U, q) {
            if (++r > 30) {
              (0, s.warn)("Load test font never loaded."), q();
              return;
            }
            if (F.font = "30px " + U, F.fillText(".", 0, 20), F.getImageData(0, 0, 1, 1).data[3] > 0) {
              q();
              return;
            }
            setTimeout(w.bind(null, U, q));
          }
          const t = `lt${Date.now()}${this.loadTestFontId++}`;
          let i = this._loadTestFont;
          i = A(i, 976, t.length, t);
          const d = 16, E = 1482184792;
          let k = T(i, d);
          for (n = 0, f = t.length - 3; n < f; n += 4)
            k = k - E + T(t, n) | 0;
          n < t.length && (k = k - E + T(t + "XXX", n) | 0), i = A(i, d, 4, (0, s.string32)(k));
          const L = `url(data:font/opentype;base64,${btoa(i)});`, M = `@font-face {font-family:"${t}";src:${L}}`;
          this.insertRule(M);
          const B = this._document.createElement("div");
          B.style.visibility = "hidden", B.style.width = B.style.height = "10px", B.style.position = "absolute", B.style.top = B.style.left = "0px";
          for (const U of [x.loadedName, t]) {
            const q = this._document.createElement("span");
            q.textContent = "Hi", q.style.fontFamily = U, B.append(q);
          }
          this._document.body.append(B), w(t, () => {
            B.remove(), C.complete();
          });
        }
      }
      class v {
        constructor(x, {
          disableFontFace: C = !1,
          ignoreErrors: T = !1,
          inspectFont: A = null
        }) {
          this.compiledGlyphs = /* @__PURE__ */ Object.create(null);
          for (const n in x)
            this[n] = x[n];
          this.disableFontFace = C === !0, this.ignoreErrors = T === !0, this._inspectFont = A;
        }
        createNativeFontFace() {
          if (!this.data || this.disableFontFace)
            return null;
          let x;
          if (!this.cssFontInfo)
            x = new FontFace(this.loadedName, this.data, {});
          else {
            const C = {
              weight: this.cssFontInfo.fontWeight
            };
            this.cssFontInfo.italicAngle && (C.style = `oblique ${this.cssFontInfo.italicAngle}deg`), x = new FontFace(this.cssFontInfo.fontFamily, this.data, C);
          }
          return this._inspectFont?.(this), x;
        }
        createFontFaceRule() {
          if (!this.data || this.disableFontFace)
            return null;
          const x = (0, s.bytesToString)(this.data), C = `url(data:${this.mimetype};base64,${btoa(x)});`;
          let T;
          if (!this.cssFontInfo)
            T = `@font-face {font-family:"${this.loadedName}";src:${C}}`;
          else {
            let A = `font-weight: ${this.cssFontInfo.fontWeight};`;
            this.cssFontInfo.italicAngle && (A += `font-style: oblique ${this.cssFontInfo.italicAngle}deg;`), T = `@font-face {font-family:"${this.cssFontInfo.fontFamily}";${A}src:${C}}`;
          }
          return this._inspectFont?.(this, C), T;
        }
        getPathGenerator(x, C) {
          if (this.compiledGlyphs[C] !== void 0)
            return this.compiledGlyphs[C];
          let T;
          try {
            T = x.get(this.loadedName + "_path_" + C);
          } catch (n) {
            if (!this.ignoreErrors)
              throw n;
            (0, s.warn)(`getPathGenerator - ignoring character: "${n}".`);
          }
          if (!Array.isArray(T) || T.length === 0)
            return this.compiledGlyphs[C] = function(n, f) {
            };
          const A = [];
          for (let n = 0, f = T.length; n < f; )
            switch (T[n++]) {
              case s.FontRenderOps.BEZIER_CURVE_TO:
                {
                  const [p, F, r, w, t, i] = T.slice(n, n + 6);
                  A.push((h) => h.bezierCurveTo(p, F, r, w, t, i)), n += 6;
                }
                break;
              case s.FontRenderOps.MOVE_TO:
                {
                  const [p, F] = T.slice(n, n + 2);
                  A.push((r) => r.moveTo(p, F)), n += 2;
                }
                break;
              case s.FontRenderOps.LINE_TO:
                {
                  const [p, F] = T.slice(n, n + 2);
                  A.push((r) => r.lineTo(p, F)), n += 2;
                }
                break;
              case s.FontRenderOps.QUADRATIC_CURVE_TO:
                {
                  const [p, F, r, w] = T.slice(n, n + 4);
                  A.push((t) => t.quadraticCurveTo(p, F, r, w)), n += 4;
                }
                break;
              case s.FontRenderOps.RESTORE:
                A.push((p) => p.restore());
                break;
              case s.FontRenderOps.SAVE:
                A.push((p) => p.save());
                break;
              case s.FontRenderOps.SCALE:
                (0, s.assert)(A.length === 2, "Scale command is only valid at the third position.");
                break;
              case s.FontRenderOps.TRANSFORM:
                {
                  const [p, F, r, w, t, i] = T.slice(n, n + 6);
                  A.push((h) => h.transform(p, F, r, w, t, i)), n += 6;
                }
                break;
              case s.FontRenderOps.TRANSLATE:
                {
                  const [p, F] = T.slice(n, n + 2);
                  A.push((r) => r.translate(p, F)), n += 2;
                }
                break;
            }
          return this.compiledGlyphs[C] = function(f, p) {
            A[0](f), A[1](f), f.scale(p, -p);
            for (let F = 2, r = A.length; F < r; F++)
              A[F](f);
          };
        }
      }
    })
  ),
  /***/
  62: (
    /***/
    ((V, l, a) => {
      a.d(l, {
        /* harmony export */
        Metadata: () => (
          /* binding */
          S
        )
        /* harmony export */
      });
      var s = a(292);
      class S {
        #t;
        #e;
        constructor({
          parsedData: _,
          rawData: x
        }) {
          this.#t = _, this.#e = x;
        }
        getRaw() {
          return this.#e;
        }
        get(_) {
          return this.#t.get(_) ?? null;
        }
        getAll() {
          return (0, s.objectFromMap)(this.#t);
        }
        has(_) {
          return this.#t.has(_);
        }
      }
    })
  ),
  /***/
  457: (
    /***/
    ((V, l, a) => {
      a.d(l, {
        /* harmony export */
        PDFNetworkStream: () => (
          /* binding */
          T
        )
        /* harmony export */
      });
      var s = a(292), S = a(490);
      const v = 200, _ = 206;
      function x(f) {
        const p = f.response;
        return typeof p != "string" ? p : (0, s.stringToBytes)(p).buffer;
      }
      class C {
        constructor(p, F = {}) {
          this.url = p, this.isHttp = /^https?:/i.test(p), this.httpHeaders = this.isHttp && F.httpHeaders || /* @__PURE__ */ Object.create(null), this.withCredentials = F.withCredentials || !1, this.currXhrId = 0, this.pendingRequests = /* @__PURE__ */ Object.create(null);
        }
        requestRange(p, F, r) {
          const w = {
            begin: p,
            end: F
          };
          for (const t in r)
            w[t] = r[t];
          return this.request(w);
        }
        requestFull(p) {
          return this.request(p);
        }
        request(p) {
          const F = new XMLHttpRequest(), r = this.currXhrId++, w = this.pendingRequests[r] = {
            xhr: F
          };
          F.open("GET", this.url), F.withCredentials = this.withCredentials;
          for (const t in this.httpHeaders) {
            const i = this.httpHeaders[t];
            i !== void 0 && F.setRequestHeader(t, i);
          }
          return this.isHttp && "begin" in p && "end" in p ? (F.setRequestHeader("Range", `bytes=${p.begin}-${p.end - 1}`), w.expectedStatus = _) : w.expectedStatus = v, F.responseType = "arraybuffer", p.onError && (F.onerror = function(t) {
            p.onError(F.status);
          }), F.onreadystatechange = this.onStateChange.bind(this, r), F.onprogress = this.onProgress.bind(this, r), w.onHeadersReceived = p.onHeadersReceived, w.onDone = p.onDone, w.onError = p.onError, w.onProgress = p.onProgress, F.send(null), r;
        }
        onProgress(p, F) {
          const r = this.pendingRequests[p];
          r && r.onProgress?.(F);
        }
        onStateChange(p, F) {
          const r = this.pendingRequests[p];
          if (!r)
            return;
          const w = r.xhr;
          if (w.readyState >= 2 && r.onHeadersReceived && (r.onHeadersReceived(), delete r.onHeadersReceived), w.readyState !== 4 || !(p in this.pendingRequests))
            return;
          if (delete this.pendingRequests[p], w.status === 0 && this.isHttp) {
            r.onError?.(w.status);
            return;
          }
          const t = w.status || v;
          if (!(t === v && r.expectedStatus === _) && t !== r.expectedStatus) {
            r.onError?.(w.status);
            return;
          }
          const h = x(w);
          if (t === _) {
            const d = w.getResponseHeader("Content-Range"), E = /bytes (\d+)-(\d+)\/(\d+)/.exec(d);
            r.onDone({
              begin: parseInt(E[1], 10),
              chunk: h
            });
          } else h ? r.onDone({
            begin: 0,
            chunk: h
          }) : r.onError?.(w.status);
        }
        getRequestXhr(p) {
          return this.pendingRequests[p].xhr;
        }
        isPendingRequest(p) {
          return p in this.pendingRequests;
        }
        abortRequest(p) {
          const F = this.pendingRequests[p].xhr;
          delete this.pendingRequests[p], F.abort();
        }
      }
      class T {
        constructor(p) {
          this._source = p, this._manager = new C(p.url, {
            httpHeaders: p.httpHeaders,
            withCredentials: p.withCredentials
          }), this._rangeChunkSize = p.rangeChunkSize, this._fullRequestReader = null, this._rangeRequestReaders = [];
        }
        _onRangeRequestReaderClosed(p) {
          const F = this._rangeRequestReaders.indexOf(p);
          F >= 0 && this._rangeRequestReaders.splice(F, 1);
        }
        getFullReader() {
          return (0, s.assert)(!this._fullRequestReader, "PDFNetworkStream.getFullReader can only be called once."), this._fullRequestReader = new A(this._manager, this._source), this._fullRequestReader;
        }
        getRangeReader(p, F) {
          const r = new n(this._manager, p, F);
          return r.onClosed = this._onRangeRequestReaderClosed.bind(this), this._rangeRequestReaders.push(r), r;
        }
        cancelAllRequests(p) {
          this._fullRequestReader?.cancel(p);
          for (const F of this._rangeRequestReaders.slice(0))
            F.cancel(p);
        }
      }
      class A {
        constructor(p, F) {
          this._manager = p;
          const r = {
            onHeadersReceived: this._onHeadersReceived.bind(this),
            onDone: this._onDone.bind(this),
            onError: this._onError.bind(this),
            onProgress: this._onProgress.bind(this)
          };
          this._url = F.url, this._fullRequestId = p.requestFull(r), this._headersReceivedCapability = Promise.withResolvers(), this._disableRange = F.disableRange || !1, this._contentLength = F.length, this._rangeChunkSize = F.rangeChunkSize, !this._rangeChunkSize && !this._disableRange && (this._disableRange = !0), this._isStreamingSupported = !1, this._isRangeSupported = !1, this._cachedChunks = [], this._requests = [], this._done = !1, this._storedError = void 0, this._filename = null, this.onProgress = null;
        }
        _onHeadersReceived() {
          const p = this._fullRequestId, F = this._manager.getRequestXhr(p), r = (i) => F.getResponseHeader(i), {
            allowRangeRequests: w,
            suggestedLength: t
          } = (0, S.validateRangeRequestCapabilities)({
            getResponseHeader: r,
            isHttp: this._manager.isHttp,
            rangeChunkSize: this._rangeChunkSize,
            disableRange: this._disableRange
          });
          w && (this._isRangeSupported = !0), this._contentLength = t || this._contentLength, this._filename = (0, S.extractFilenameFromHeader)(r), this._isRangeSupported && this._manager.abortRequest(p), this._headersReceivedCapability.resolve();
        }
        _onDone(p) {
          if (p && (this._requests.length > 0 ? this._requests.shift().resolve({
            value: p.chunk,
            done: !1
          }) : this._cachedChunks.push(p.chunk)), this._done = !0, !(this._cachedChunks.length > 0)) {
            for (const F of this._requests)
              F.resolve({
                value: void 0,
                done: !0
              });
            this._requests.length = 0;
          }
        }
        _onError(p) {
          this._storedError = (0, S.createResponseStatusError)(p, this._url), this._headersReceivedCapability.reject(this._storedError);
          for (const F of this._requests)
            F.reject(this._storedError);
          this._requests.length = 0, this._cachedChunks.length = 0;
        }
        _onProgress(p) {
          this.onProgress?.({
            loaded: p.loaded,
            total: p.lengthComputable ? p.total : this._contentLength
          });
        }
        get filename() {
          return this._filename;
        }
        get isRangeSupported() {
          return this._isRangeSupported;
        }
        get isStreamingSupported() {
          return this._isStreamingSupported;
        }
        get contentLength() {
          return this._contentLength;
        }
        get headersReady() {
          return this._headersReceivedCapability.promise;
        }
        async read() {
          if (this._storedError)
            throw this._storedError;
          if (this._cachedChunks.length > 0)
            return {
              value: this._cachedChunks.shift(),
              done: !1
            };
          if (this._done)
            return {
              value: void 0,
              done: !0
            };
          const p = Promise.withResolvers();
          return this._requests.push(p), p.promise;
        }
        cancel(p) {
          this._done = !0, this._headersReceivedCapability.reject(p);
          for (const F of this._requests)
            F.resolve({
              value: void 0,
              done: !0
            });
          this._requests.length = 0, this._manager.isPendingRequest(this._fullRequestId) && this._manager.abortRequest(this._fullRequestId), this._fullRequestReader = null;
        }
      }
      class n {
        constructor(p, F, r) {
          this._manager = p;
          const w = {
            onDone: this._onDone.bind(this),
            onError: this._onError.bind(this),
            onProgress: this._onProgress.bind(this)
          };
          this._url = p.url, this._requestId = p.requestRange(F, r, w), this._requests = [], this._queuedChunk = null, this._done = !1, this._storedError = void 0, this.onProgress = null, this.onClosed = null;
        }
        _close() {
          this.onClosed?.(this);
        }
        _onDone(p) {
          const F = p.chunk;
          this._requests.length > 0 ? this._requests.shift().resolve({
            value: F,
            done: !1
          }) : this._queuedChunk = F, this._done = !0;
          for (const r of this._requests)
            r.resolve({
              value: void 0,
              done: !0
            });
          this._requests.length = 0, this._close();
        }
        _onError(p) {
          this._storedError = (0, S.createResponseStatusError)(p, this._url);
          for (const F of this._requests)
            F.reject(this._storedError);
          this._requests.length = 0, this._queuedChunk = null;
        }
        _onProgress(p) {
          this.isStreamingSupported || this.onProgress?.({
            loaded: p.loaded
          });
        }
        get isStreamingSupported() {
          return !1;
        }
        async read() {
          if (this._storedError)
            throw this._storedError;
          if (this._queuedChunk !== null) {
            const F = this._queuedChunk;
            return this._queuedChunk = null, {
              value: F,
              done: !1
            };
          }
          if (this._done)
            return {
              value: void 0,
              done: !0
            };
          const p = Promise.withResolvers();
          return this._requests.push(p), p.promise;
        }
        cancel(p) {
          this._done = !0;
          for (const F of this._requests)
            F.resolve({
              value: void 0,
              done: !0
            });
          this._requests.length = 0, this._manager.isPendingRequest(this._requestId) && this._manager.abortRequest(this._requestId), this._close();
        }
      }
    })
  ),
  /***/
  490: (
    /***/
    ((V, l, a) => {
      a.d(l, {
        createResponseStatusError: () => (
          /* binding */
          C
        ),
        extractFilenameFromHeader: () => (
          /* binding */
          x
        ),
        validateRangeRequestCapabilities: () => (
          /* binding */
          _
        ),
        validateResponseStatus: () => (
          /* binding */
          T
        )
      });
      var s = a(292);
      function S(A) {
        let n = !0, f = p("filename\\*", "i").exec(A);
        if (f) {
          f = f[1];
          let d = t(f);
          return d = unescape(d), d = i(d), d = h(d), r(d);
        }
        if (f = w(A), f) {
          const d = h(f);
          return r(d);
        }
        if (f = p("filename", "i").exec(A), f) {
          f = f[1];
          let d = t(f);
          return d = h(d), r(d);
        }
        function p(d, E) {
          return new RegExp("(?:^|;)\\s*" + d + '\\s*=\\s*([^";\\s][^;\\s]*|"(?:[^"\\\\]|\\\\"?)+"?)', E);
        }
        function F(d, E) {
          if (d) {
            if (!/^[\x00-\xFF]+$/.test(E))
              return E;
            try {
              const k = new TextDecoder(d, {
                fatal: !0
              }), L = (0, s.stringToBytes)(E);
              E = k.decode(L), n = !1;
            } catch {
            }
          }
          return E;
        }
        function r(d) {
          return n && /[\x80-\xff]/.test(d) && (d = F("utf-8", d), n && (d = F("iso-8859-1", d))), d;
        }
        function w(d) {
          const E = [];
          let k;
          const L = p("filename\\*((?!0\\d)\\d+)(\\*?)", "ig");
          for (; (k = L.exec(d)) !== null; ) {
            let [, B, U, q] = k;
            if (B = parseInt(B, 10), B in E) {
              if (B === 0)
                break;
              continue;
            }
            E[B] = [U, q];
          }
          const M = [];
          for (let B = 0; B < E.length && B in E; ++B) {
            let [U, q] = E[B];
            q = t(q), U && (q = unescape(q), B === 0 && (q = i(q))), M.push(q);
          }
          return M.join("");
        }
        function t(d) {
          if (d.startsWith('"')) {
            const E = d.slice(1).split('\\"');
            for (let k = 0; k < E.length; ++k) {
              const L = E[k].indexOf('"');
              L !== -1 && (E[k] = E[k].slice(0, L), E.length = k + 1), E[k] = E[k].replaceAll(/\\(.)/g, "$1");
            }
            d = E.join('"');
          }
          return d;
        }
        function i(d) {
          const E = d.indexOf("'");
          if (E === -1)
            return d;
          const k = d.slice(0, E), M = d.slice(E + 1).replace(/^[^']*'/, "");
          return F(k, M);
        }
        function h(d) {
          return !d.startsWith("=?") || /[\x00-\x19\x80-\xff]/.test(d) ? d : d.replaceAll(/=\?([\w-]*)\?([QqBb])\?((?:[^?]|\?(?!=))*)\?=/g, function(E, k, L, M) {
            if (L === "q" || L === "Q")
              return M = M.replaceAll("_", " "), M = M.replaceAll(/=([0-9a-fA-F]{2})/g, function(B, U) {
                return String.fromCharCode(parseInt(U, 16));
              }), F(k, M);
            try {
              M = atob(M);
            } catch {
            }
            return F(k, M);
          });
        }
        return "";
      }
      var v = a(419);
      function _({
        getResponseHeader: A,
        isHttp: n,
        rangeChunkSize: f,
        disableRange: p
      }) {
        const F = {
          allowRangeRequests: !1,
          suggestedLength: void 0
        }, r = parseInt(A("Content-Length"), 10);
        return !Number.isInteger(r) || (F.suggestedLength = r, r <= 2 * f) || p || !n || A("Accept-Ranges") !== "bytes" || (A("Content-Encoding") || "identity") !== "identity" || (F.allowRangeRequests = !0), F;
      }
      function x(A) {
        const n = A("Content-Disposition");
        if (n) {
          let f = S(n);
          if (f.includes("%"))
            try {
              f = decodeURIComponent(f);
            } catch {
            }
          if ((0, v.isPdfFile)(f))
            return f;
        }
        return null;
      }
      function C(A, n) {
        return A === 404 || A === 0 && n.startsWith("file:") ? new s.MissingPDFException('Missing PDF "' + n + '".') : new s.UnexpectedResponseException(`Unexpected server response (${A}) while retrieving PDF "${n}".`, A);
      }
      function T(A) {
        return A === 200 || A === 206;
      }
    })
  ),
  /***/
  786: (
    /***/
    ((V, l, a) => {
      a.a(V, async (s, S) => {
        try {
          let f = function(E) {
            const k = A.parse(E);
            return k.protocol === "file:" || k.host ? k : /^[a-z]:[/\\]/i.test(E) ? A.parse(`file:///${E}`) : (k.host || (k.protocol = "file:"), k);
          }, w = function(E, k) {
            return {
              protocol: E.protocol,
              auth: E.auth,
              host: E.hostname,
              port: E.port,
              path: E.path,
              method: "GET",
              headers: k
            };
          };
          a.d(l, {
            /* harmony export */
            PDFNodeStream: () => (
              /* binding */
              p
            )
            /* harmony export */
          });
          var v = a(292), _ = a(490);
          let x, C, T, A;
          v.isNodeJS && (x = await import(
            /*webpackIgnore: true*/
            "./__vite-browser-external-DYxpcVy9.js"
          ), C = await import(
            /*webpackIgnore: true*/
            "./__vite-browser-external-DYxpcVy9.js"
          ), T = await import(
            /*webpackIgnore: true*/
            "./__vite-browser-external-DYxpcVy9.js"
          ), A = await import(
            /*webpackIgnore: true*/
            "./__vite-browser-external-DYxpcVy9.js"
          ));
          const n = /^file:\/\/\/[a-zA-Z]:\//;
          class p {
            constructor(k) {
              this.source = k, this.url = f(k.url), this.isHttp = this.url.protocol === "http:" || this.url.protocol === "https:", this.isFsUrl = this.url.protocol === "file:", this.httpHeaders = this.isHttp && k.httpHeaders || {}, this._fullRequestReader = null, this._rangeRequestReaders = [];
            }
            get _progressiveDataLength() {
              return this._fullRequestReader?._loaded ?? 0;
            }
            getFullReader() {
              return (0, v.assert)(!this._fullRequestReader, "PDFNodeStream.getFullReader can only be called once."), this._fullRequestReader = this.isFsUrl ? new h(this) : new t(this), this._fullRequestReader;
            }
            getRangeReader(k, L) {
              if (L <= this._progressiveDataLength)
                return null;
              const M = this.isFsUrl ? new d(this, k, L) : new i(this, k, L);
              return this._rangeRequestReaders.push(M), M;
            }
            cancelAllRequests(k) {
              this._fullRequestReader?.cancel(k);
              for (const L of this._rangeRequestReaders.slice(0))
                L.cancel(k);
            }
          }
          class F {
            constructor(k) {
              this._url = k.url, this._done = !1, this._storedError = null, this.onProgress = null;
              const L = k.source;
              this._contentLength = L.length, this._loaded = 0, this._filename = null, this._disableRange = L.disableRange || !1, this._rangeChunkSize = L.rangeChunkSize, !this._rangeChunkSize && !this._disableRange && (this._disableRange = !0), this._isStreamingSupported = !L.disableStream, this._isRangeSupported = !L.disableRange, this._readableStream = null, this._readCapability = Promise.withResolvers(), this._headersCapability = Promise.withResolvers();
            }
            get headersReady() {
              return this._headersCapability.promise;
            }
            get filename() {
              return this._filename;
            }
            get contentLength() {
              return this._contentLength;
            }
            get isRangeSupported() {
              return this._isRangeSupported;
            }
            get isStreamingSupported() {
              return this._isStreamingSupported;
            }
            async read() {
              if (await this._readCapability.promise, this._done)
                return {
                  value: void 0,
                  done: !0
                };
              if (this._storedError)
                throw this._storedError;
              const k = this._readableStream.read();
              return k === null ? (this._readCapability = Promise.withResolvers(), this.read()) : (this._loaded += k.length, this.onProgress?.({
                loaded: this._loaded,
                total: this._contentLength
              }), {
                value: new Uint8Array(k).buffer,
                done: !1
              });
            }
            cancel(k) {
              if (!this._readableStream) {
                this._error(k);
                return;
              }
              this._readableStream.destroy(k);
            }
            _error(k) {
              this._storedError = k, this._readCapability.resolve();
            }
            _setReadableStream(k) {
              this._readableStream = k, k.on("readable", () => {
                this._readCapability.resolve();
              }), k.on("end", () => {
                k.destroy(), this._done = !0, this._readCapability.resolve();
              }), k.on("error", (L) => {
                this._error(L);
              }), !this._isStreamingSupported && this._isRangeSupported && this._error(new v.AbortException("streaming is disabled")), this._storedError && this._readableStream.destroy(this._storedError);
            }
          }
          class r {
            constructor(k) {
              this._url = k.url, this._done = !1, this._storedError = null, this.onProgress = null, this._loaded = 0, this._readableStream = null, this._readCapability = Promise.withResolvers();
              const L = k.source;
              this._isStreamingSupported = !L.disableStream;
            }
            get isStreamingSupported() {
              return this._isStreamingSupported;
            }
            async read() {
              if (await this._readCapability.promise, this._done)
                return {
                  value: void 0,
                  done: !0
                };
              if (this._storedError)
                throw this._storedError;
              const k = this._readableStream.read();
              return k === null ? (this._readCapability = Promise.withResolvers(), this.read()) : (this._loaded += k.length, this.onProgress?.({
                loaded: this._loaded
              }), {
                value: new Uint8Array(k).buffer,
                done: !1
              });
            }
            cancel(k) {
              if (!this._readableStream) {
                this._error(k);
                return;
              }
              this._readableStream.destroy(k);
            }
            _error(k) {
              this._storedError = k, this._readCapability.resolve();
            }
            _setReadableStream(k) {
              this._readableStream = k, k.on("readable", () => {
                this._readCapability.resolve();
              }), k.on("end", () => {
                k.destroy(), this._done = !0, this._readCapability.resolve();
              }), k.on("error", (L) => {
                this._error(L);
              }), this._storedError && this._readableStream.destroy(this._storedError);
            }
          }
          class t extends F {
            constructor(k) {
              super(k);
              const L = (M) => {
                if (M.statusCode === 404) {
                  const Z = new v.MissingPDFException(`Missing PDF "${this._url}".`);
                  this._storedError = Z, this._headersCapability.reject(Z);
                  return;
                }
                this._headersCapability.resolve(), this._setReadableStream(M);
                const B = (Z) => this._readableStream.headers[Z.toLowerCase()], {
                  allowRangeRequests: U,
                  suggestedLength: q
                } = (0, _.validateRangeRequestCapabilities)({
                  getResponseHeader: B,
                  isHttp: k.isHttp,
                  rangeChunkSize: this._rangeChunkSize,
                  disableRange: this._disableRange
                });
                this._isRangeSupported = U, this._contentLength = q || this._contentLength, this._filename = (0, _.extractFilenameFromHeader)(B);
              };
              this._request = null, this._url.protocol === "http:" ? this._request = C.request(w(this._url, k.httpHeaders), L) : this._request = T.request(w(this._url, k.httpHeaders), L), this._request.on("error", (M) => {
                this._storedError = M, this._headersCapability.reject(M);
              }), this._request.end();
            }
          }
          class i extends r {
            constructor(k, L, M) {
              super(k), this._httpHeaders = {};
              for (const U in k.httpHeaders) {
                const q = k.httpHeaders[U];
                q !== void 0 && (this._httpHeaders[U] = q);
              }
              this._httpHeaders.Range = `bytes=${L}-${M - 1}`;
              const B = (U) => {
                if (U.statusCode === 404) {
                  const q = new v.MissingPDFException(`Missing PDF "${this._url}".`);
                  this._storedError = q;
                  return;
                }
                this._setReadableStream(U);
              };
              this._request = null, this._url.protocol === "http:" ? this._request = C.request(w(this._url, this._httpHeaders), B) : this._request = T.request(w(this._url, this._httpHeaders), B), this._request.on("error", (U) => {
                this._storedError = U;
              }), this._request.end();
            }
          }
          class h extends F {
            constructor(k) {
              super(k);
              let L = decodeURIComponent(this._url.path);
              n.test(this._url.href) && (L = L.replace(/^\//, "")), x.promises.lstat(L).then((M) => {
                this._contentLength = M.size, this._setReadableStream(x.createReadStream(L)), this._headersCapability.resolve();
              }, (M) => {
                M.code === "ENOENT" && (M = new v.MissingPDFException(`Missing PDF "${L}".`)), this._storedError = M, this._headersCapability.reject(M);
              });
            }
          }
          class d extends r {
            constructor(k, L, M) {
              super(k);
              let B = decodeURIComponent(this._url.path);
              n.test(this._url.href) && (B = B.replace(/^\//, "")), this._setReadableStream(x.createReadStream(B, {
                start: L,
                end: M - 1
              }));
            }
          }
          S();
        } catch (x) {
          S(x);
        }
      }, 1);
    })
  ),
  /***/
  573: (
    /***/
    ((V, l, a) => {
      a.a(V, async (s, S) => {
        try {
          a.d(l, {
            /* harmony export */
            NodeCMapReaderFactory: () => (
              /* binding */
              p
            ),
            /* harmony export */
            NodeCanvasFactory: () => (
              /* binding */
              f
            ),
            /* harmony export */
            NodeFilterFactory: () => (
              /* binding */
              n
            ),
            /* harmony export */
            NodeStandardFontDataFactory: () => (
              /* binding */
              F
            )
            /* harmony export */
          });
          var v = a(583), _ = a(292);
          let x, C, T;
          if (_.isNodeJS) {
            x = await import(
              /*webpackIgnore: true*/
              "./__vite-browser-external-DYxpcVy9.js"
            );
            try {
              C = await import(
                /*webpackIgnore: true*/
                "./__vite-browser-external-DYxpcVy9.js"
              );
            } catch {
            }
            try {
              T = await import(
                /*webpackIgnore: true*/
                "./index-Dwr47WtL.js"
              );
            } catch {
            }
          }
          const A = function(r) {
            return x.promises.readFile(r).then((w) => new Uint8Array(w));
          };
          class n extends v.BaseFilterFactory {
          }
          class f extends v.BaseCanvasFactory {
            _createCanvas(w, t) {
              return C.createCanvas(w, t);
            }
          }
          class p extends v.BaseCMapReaderFactory {
            _fetchData(w, t) {
              return A(w).then((i) => ({
                cMapData: i,
                compressionType: t
              }));
            }
          }
          class F extends v.BaseStandardFontDataFactory {
            _fetchData(w) {
              return A(w);
            }
          }
          S();
        } catch (x) {
          S(x);
        }
      }, 1);
    })
  ),
  /***/
  626: (
    /***/
    ((V, l, a) => {
      a.d(l, {
        /* harmony export */
        OptionalContentConfig: () => (
          /* binding */
          x
        )
        /* harmony export */
      });
      var s = a(292), S = a(651);
      const v = Symbol("INTERNAL");
      class _ {
        #t = !1;
        #e = !1;
        #s = !1;
        #n = !0;
        constructor(T, {
          name: A,
          intent: n,
          usage: f
        }) {
          this.#t = !!(T & s.RenderingIntentFlag.DISPLAY), this.#e = !!(T & s.RenderingIntentFlag.PRINT), this.name = A, this.intent = n, this.usage = f;
        }
        get visible() {
          if (this.#s)
            return this.#n;
          if (!this.#n)
            return !1;
          const {
            print: T,
            view: A
          } = this.usage;
          return this.#t ? A?.viewState !== "OFF" : this.#e ? T?.printState !== "OFF" : !0;
        }
        _setVisible(T, A, n = !1) {
          T !== v && (0, s.unreachable)("Internal method `_setVisible` called."), this.#s = n, this.#n = A;
        }
      }
      class x {
        #t = null;
        #e = /* @__PURE__ */ new Map();
        #s = null;
        #n = null;
        constructor(T, A = s.RenderingIntentFlag.DISPLAY) {
          if (this.renderingIntent = A, this.name = null, this.creator = null, T !== null) {
            this.name = T.name, this.creator = T.creator, this.#n = T.order;
            for (const n of T.groups)
              this.#e.set(n.id, new _(A, n));
            if (T.baseState === "OFF")
              for (const n of this.#e.values())
                n._setVisible(v, !1);
            for (const n of T.on)
              this.#e.get(n)._setVisible(v, !0);
            for (const n of T.off)
              this.#e.get(n)._setVisible(v, !1);
            this.#s = this.getHash();
          }
        }
        #r(T) {
          const A = T.length;
          if (A < 2)
            return !0;
          const n = T[0];
          for (let f = 1; f < A; f++) {
            const p = T[f];
            let F;
            if (Array.isArray(p))
              F = this.#r(p);
            else if (this.#e.has(p))
              F = this.#e.get(p).visible;
            else
              return (0, s.warn)(`Optional content group not found: ${p}`), !0;
            switch (n) {
              case "And":
                if (!F)
                  return !1;
                break;
              case "Or":
                if (F)
                  return !0;
                break;
              case "Not":
                return !F;
              default:
                return !0;
            }
          }
          return n === "And";
        }
        isVisible(T) {
          if (this.#e.size === 0)
            return !0;
          if (!T)
            return (0, s.info)("Optional content group not defined."), !0;
          if (T.type === "OCG")
            return this.#e.has(T.id) ? this.#e.get(T.id).visible : ((0, s.warn)(`Optional content group not found: ${T.id}`), !0);
          if (T.type === "OCMD") {
            if (T.expression)
              return this.#r(T.expression);
            if (!T.policy || T.policy === "AnyOn") {
              for (const A of T.ids) {
                if (!this.#e.has(A))
                  return (0, s.warn)(`Optional content group not found: ${A}`), !0;
                if (this.#e.get(A).visible)
                  return !0;
              }
              return !1;
            } else if (T.policy === "AllOn") {
              for (const A of T.ids) {
                if (!this.#e.has(A))
                  return (0, s.warn)(`Optional content group not found: ${A}`), !0;
                if (!this.#e.get(A).visible)
                  return !1;
              }
              return !0;
            } else if (T.policy === "AnyOff") {
              for (const A of T.ids) {
                if (!this.#e.has(A))
                  return (0, s.warn)(`Optional content group not found: ${A}`), !0;
                if (!this.#e.get(A).visible)
                  return !0;
              }
              return !1;
            } else if (T.policy === "AllOff") {
              for (const A of T.ids) {
                if (!this.#e.has(A))
                  return (0, s.warn)(`Optional content group not found: ${A}`), !0;
                if (this.#e.get(A).visible)
                  return !1;
              }
              return !0;
            }
            return (0, s.warn)(`Unknown optional content policy ${T.policy}.`), !0;
          }
          return (0, s.warn)(`Unknown group type ${T.type}.`), !0;
        }
        setVisibility(T, A = !0) {
          const n = this.#e.get(T);
          if (!n) {
            (0, s.warn)(`Optional content group not found: ${T}`);
            return;
          }
          n._setVisible(v, !!A, !0), this.#t = null;
        }
        setOCGState({
          state: T,
          preserveRB: A
        }) {
          let n;
          for (const f of T) {
            switch (f) {
              case "ON":
              case "OFF":
              case "Toggle":
                n = f;
                continue;
            }
            const p = this.#e.get(f);
            if (p)
              switch (n) {
                case "ON":
                  p._setVisible(v, !0);
                  break;
                case "OFF":
                  p._setVisible(v, !1);
                  break;
                case "Toggle":
                  p._setVisible(v, !p.visible);
                  break;
              }
          }
          this.#t = null;
        }
        get hasInitialVisibility() {
          return this.#s === null || this.getHash() === this.#s;
        }
        getOrder() {
          return this.#e.size ? this.#n ? this.#n.slice() : [...this.#e.keys()] : null;
        }
        getGroups() {
          return this.#e.size > 0 ? (0, s.objectFromMap)(this.#e) : null;
        }
        getGroup(T) {
          return this.#e.get(T) || null;
        }
        getHash() {
          if (this.#t !== null)
            return this.#t;
          const T = new S.MurmurHash3_64();
          for (const [A, n] of this.#e)
            T.update(`${A}:${n.visible}`);
          return this.#t = T.hexdigest();
        }
      }
    })
  ),
  /***/
  814: (
    /***/
    ((V, l, a) => {
      a.d(l, {
        /* harmony export */
        cleanupTextLayer: () => (
          /* binding */
          n
        ),
        /* harmony export */
        renderTextLayer: () => (
          /* binding */
          t
        ),
        /* harmony export */
        updateTextLayer: () => (
          /* binding */
          i
        )
        /* harmony export */
      });
      var s = a(292), S = a(419);
      const v = 1e5, _ = 30, x = 0.8, C = /* @__PURE__ */ new Map();
      let T = null;
      function A() {
        if (!T) {
          const h = document.createElement("canvas");
          h.className = "hiddenCanvasElement", document.body.append(h), T = h.getContext("2d", {
            alpha: !1
          });
        }
        return T;
      }
      function n() {
        T?.canvas.remove(), T = null;
      }
      function f(h) {
        const d = C.get(h);
        if (d)
          return d;
        const E = A(), k = E.font;
        E.canvas.width = E.canvas.height = _, E.font = `${_}px ${h}`;
        const L = E.measureText("");
        let M = L.fontBoundingBoxAscent, B = Math.abs(L.fontBoundingBoxDescent);
        if (M) {
          const q = M / (M + B);
          return C.set(h, q), E.canvas.width = E.canvas.height = 0, E.font = k, q;
        }
        E.strokeStyle = "red", E.clearRect(0, 0, _, _), E.strokeText("g", 0, 0);
        let U = E.getImageData(0, 0, _, _).data;
        B = 0;
        for (let q = U.length - 1 - 3; q >= 0; q -= 4)
          if (U[q] > 0) {
            B = Math.ceil(q / 4 / _);
            break;
          }
        E.clearRect(0, 0, _, _), E.strokeText("A", 0, _), U = E.getImageData(0, 0, _, _).data, M = 0;
        for (let q = 0, Z = U.length; q < Z; q += 4)
          if (U[q] > 0) {
            M = _ - Math.floor(q / 4 / _);
            break;
          }
        if (E.canvas.width = E.canvas.height = 0, E.font = k, M) {
          const q = M / (M + B);
          return C.set(h, q), q;
        }
        return C.set(h, x), x;
      }
      function p(h, d, E) {
        const k = document.createElement("span"), L = {
          angle: 0,
          canvasWidth: 0,
          hasText: d.str !== "",
          hasEOL: d.hasEOL,
          fontSize: 0
        };
        h._textDivs.push(k);
        const M = s.Util.transform(h._transform, d.transform);
        let B = Math.atan2(M[1], M[0]);
        const U = E[d.fontName];
        U.vertical && (B += Math.PI / 2);
        const q = h._fontInspectorEnabled && U.fontSubstitution || U.fontFamily, Z = Math.hypot(M[2], M[3]), K = Z * f(q);
        let Y, G;
        B === 0 ? (Y = M[4], G = M[5] - K) : (Y = M[4] + K * Math.sin(B), G = M[5] - K * Math.cos(B));
        const j = "calc(var(--scale-factor)*", Q = k.style;
        h._container === h._rootContainer ? (Q.left = `${(100 * Y / h._pageWidth).toFixed(2)}%`, Q.top = `${(100 * G / h._pageHeight).toFixed(2)}%`) : (Q.left = `${j}${Y.toFixed(2)}px)`, Q.top = `${j}${G.toFixed(2)}px)`), Q.fontSize = `${j}${Z.toFixed(2)}px)`, Q.fontFamily = q, L.fontSize = Z, k.setAttribute("role", "presentation"), k.textContent = d.str, k.dir = d.dir, h._fontInspectorEnabled && (k.dataset.fontName = U.fontSubstitutionLoadedName || d.fontName), B !== 0 && (L.angle = B * (180 / Math.PI));
        let J = !1;
        if (d.str.length > 1)
          J = !0;
        else if (d.str !== " " && d.transform[0] !== d.transform[3]) {
          const tt = Math.abs(d.transform[0]), rt = Math.abs(d.transform[3]);
          tt !== rt && Math.max(tt, rt) / Math.min(tt, rt) > 1.5 && (J = !0);
        }
        J && (L.canvasWidth = U.vertical ? d.height : d.width), h._textDivProperties.set(k, L), h._isReadableStream && h._layoutText(k);
      }
      function F(h) {
        const {
          div: d,
          scale: E,
          properties: k,
          ctx: L,
          prevFontSize: M,
          prevFontFamily: B
        } = h, {
          style: U
        } = d;
        let q = "";
        if (k.canvasWidth !== 0 && k.hasText) {
          const {
            fontFamily: Z
          } = U, {
            canvasWidth: K,
            fontSize: Y
          } = k;
          (M !== Y || B !== Z) && (L.font = `${Y * E}px ${Z}`, h.prevFontSize = Y, h.prevFontFamily = Z);
          const {
            width: G
          } = L.measureText(d.textContent);
          G > 0 && (q = `scaleX(${K * E / G})`);
        }
        k.angle !== 0 && (q = `rotate(${k.angle}deg) ${q}`), q.length > 0 && (U.transform = q);
      }
      function r(h) {
        if (h._canceled)
          return;
        const d = h._textDivs, E = h._capability;
        if (d.length > v) {
          E.resolve();
          return;
        }
        if (!h._isReadableStream)
          for (const L of d)
            h._layoutText(L);
        E.resolve();
      }
      class w {
        constructor({
          textContentSource: d,
          container: E,
          viewport: k,
          textDivs: L,
          textDivProperties: M,
          textContentItemsStr: B
        }) {
          this._textContentSource = d, this._isReadableStream = d instanceof ReadableStream, this._container = this._rootContainer = E, this._textDivs = L || [], this._textContentItemsStr = B || [], this._fontInspectorEnabled = !!globalThis.FontInspector?.enabled, this._reader = null, this._textDivProperties = M || /* @__PURE__ */ new WeakMap(), this._canceled = !1, this._capability = Promise.withResolvers(), this._layoutTextParams = {
            prevFontSize: null,
            prevFontFamily: null,
            div: null,
            scale: k.scale * (globalThis.devicePixelRatio || 1),
            properties: null,
            ctx: A()
          };
          const {
            pageWidth: U,
            pageHeight: q,
            pageX: Z,
            pageY: K
          } = k.rawDims;
          this._transform = [1, 0, 0, -1, -Z, K + q], this._pageWidth = U, this._pageHeight = q, (0, S.setLayerDimensions)(E, k), this._capability.promise.finally(() => {
            this._layoutTextParams = null;
          }).catch(() => {
          });
        }
        get promise() {
          return this._capability.promise;
        }
        cancel() {
          this._canceled = !0, this._reader && (this._reader.cancel(new s.AbortException("TextLayer task cancelled.")).catch(() => {
          }), this._reader = null), this._capability.reject(new s.AbortException("TextLayer task cancelled."));
        }
        _processItems(d, E) {
          for (const k of d) {
            if (k.str === void 0) {
              if (k.type === "beginMarkedContentProps" || k.type === "beginMarkedContent") {
                const L = this._container;
                this._container = document.createElement("span"), this._container.classList.add("markedContent"), k.id !== null && this._container.setAttribute("id", `${k.id}`), L.append(this._container);
              } else k.type === "endMarkedContent" && (this._container = this._container.parentNode);
              continue;
            }
            this._textContentItemsStr.push(k.str), p(this, k, E);
          }
        }
        _layoutText(d) {
          const E = this._layoutTextParams.properties = this._textDivProperties.get(d);
          if (this._layoutTextParams.div = d, F(this._layoutTextParams), E.hasText && this._container.append(d), E.hasEOL) {
            const k = document.createElement("br");
            k.setAttribute("role", "presentation"), this._container.append(k);
          }
        }
        _render() {
          const {
            promise: d,
            resolve: E,
            reject: k
          } = Promise.withResolvers();
          let L = /* @__PURE__ */ Object.create(null);
          if (this._isReadableStream) {
            const M = () => {
              this._reader.read().then(({
                value: B,
                done: U
              }) => {
                if (U) {
                  E();
                  return;
                }
                Object.assign(L, B.styles), this._processItems(B.items, L), M();
              }, k);
            };
            this._reader = this._textContentSource.getReader(), M();
          } else if (this._textContentSource) {
            const {
              items: M,
              styles: B
            } = this._textContentSource;
            this._processItems(M, B), E();
          } else
            throw new Error('No "textContentSource" parameter specified.');
          d.then(() => {
            L = null, r(this);
          }, this._capability.reject);
        }
      }
      function t(h) {
        const d = new w(h);
        return d._render(), d;
      }
      function i({
        container: h,
        viewport: d,
        textDivs: E,
        textDivProperties: k,
        mustRotate: L = !0,
        mustRescale: M = !0
      }) {
        if (L && (0, S.setLayerDimensions)(h, {
          rotation: d.rotation
        }), M) {
          const B = A(), q = {
            prevFontSize: null,
            prevFontFamily: null,
            div: null,
            scale: d.scale * (globalThis.devicePixelRatio || 1),
            properties: null,
            ctx: B
          };
          for (const Z of E)
            q.properties = k.get(Z), q.div = Z, F(q);
        }
      }
    })
  ),
  /***/
  585: (
    /***/
    ((V, l, a) => {
      a.d(l, {
        /* harmony export */
        PDFDataTransportStream: () => (
          /* binding */
          v
        )
        /* harmony export */
      });
      var s = a(292), S = a(419);
      class v {
        constructor(T, {
          disableRange: A = !1,
          disableStream: n = !1
        }) {
          (0, s.assert)(T, 'PDFDataTransportStream - missing required "pdfDataRangeTransport" argument.');
          const {
            length: f,
            initialData: p,
            progressiveDone: F,
            contentDispositionFilename: r
          } = T;
          if (this._queuedChunks = [], this._progressiveDone = F, this._contentDispositionFilename = r, p?.length > 0) {
            const w = p instanceof Uint8Array && p.byteLength === p.buffer.byteLength ? p.buffer : new Uint8Array(p).buffer;
            this._queuedChunks.push(w);
          }
          this._pdfDataRangeTransport = T, this._isStreamingSupported = !n, this._isRangeSupported = !A, this._contentLength = f, this._fullRequestReader = null, this._rangeReaders = [], T.addRangeListener((w, t) => {
            this._onReceiveData({
              begin: w,
              chunk: t
            });
          }), T.addProgressListener((w, t) => {
            this._onProgress({
              loaded: w,
              total: t
            });
          }), T.addProgressiveReadListener((w) => {
            this._onReceiveData({
              chunk: w
            });
          }), T.addProgressiveDoneListener(() => {
            this._onProgressiveDone();
          }), T.transportReady();
        }
        _onReceiveData({
          begin: T,
          chunk: A
        }) {
          const n = A instanceof Uint8Array && A.byteLength === A.buffer.byteLength ? A.buffer : new Uint8Array(A).buffer;
          if (T === void 0)
            this._fullRequestReader ? this._fullRequestReader._enqueue(n) : this._queuedChunks.push(n);
          else {
            const f = this._rangeReaders.some(function(p) {
              return p._begin !== T ? !1 : (p._enqueue(n), !0);
            });
            (0, s.assert)(f, "_onReceiveData - no `PDFDataTransportStreamRangeReader` instance found.");
          }
        }
        get _progressiveDataLength() {
          return this._fullRequestReader?._loaded ?? 0;
        }
        _onProgress(T) {
          T.total === void 0 ? this._rangeReaders[0]?.onProgress?.({
            loaded: T.loaded
          }) : this._fullRequestReader?.onProgress?.({
            loaded: T.loaded,
            total: T.total
          });
        }
        _onProgressiveDone() {
          this._fullRequestReader?.progressiveDone(), this._progressiveDone = !0;
        }
        _removeRangeReader(T) {
          const A = this._rangeReaders.indexOf(T);
          A >= 0 && this._rangeReaders.splice(A, 1);
        }
        getFullReader() {
          (0, s.assert)(!this._fullRequestReader, "PDFDataTransportStream.getFullReader can only be called once.");
          const T = this._queuedChunks;
          return this._queuedChunks = null, new _(this, T, this._progressiveDone, this._contentDispositionFilename);
        }
        getRangeReader(T, A) {
          if (A <= this._progressiveDataLength)
            return null;
          const n = new x(this, T, A);
          return this._pdfDataRangeTransport.requestDataRange(T, A), this._rangeReaders.push(n), n;
        }
        cancelAllRequests(T) {
          this._fullRequestReader?.cancel(T);
          for (const A of this._rangeReaders.slice(0))
            A.cancel(T);
          this._pdfDataRangeTransport.abort();
        }
      }
      class _ {
        constructor(T, A, n = !1, f = null) {
          this._stream = T, this._done = n || !1, this._filename = (0, S.isPdfFile)(f) ? f : null, this._queuedChunks = A || [], this._loaded = 0;
          for (const p of this._queuedChunks)
            this._loaded += p.byteLength;
          this._requests = [], this._headersReady = Promise.resolve(), T._fullRequestReader = this, this.onProgress = null;
        }
        _enqueue(T) {
          this._done || (this._requests.length > 0 ? this._requests.shift().resolve({
            value: T,
            done: !1
          }) : this._queuedChunks.push(T), this._loaded += T.byteLength);
        }
        get headersReady() {
          return this._headersReady;
        }
        get filename() {
          return this._filename;
        }
        get isRangeSupported() {
          return this._stream._isRangeSupported;
        }
        get isStreamingSupported() {
          return this._stream._isStreamingSupported;
        }
        get contentLength() {
          return this._stream._contentLength;
        }
        async read() {
          if (this._queuedChunks.length > 0)
            return {
              value: this._queuedChunks.shift(),
              done: !1
            };
          if (this._done)
            return {
              value: void 0,
              done: !0
            };
          const T = Promise.withResolvers();
          return this._requests.push(T), T.promise;
        }
        cancel(T) {
          this._done = !0;
          for (const A of this._requests)
            A.resolve({
              value: void 0,
              done: !0
            });
          this._requests.length = 0;
        }
        progressiveDone() {
          this._done || (this._done = !0);
        }
      }
      class x {
        constructor(T, A, n) {
          this._stream = T, this._begin = A, this._end = n, this._queuedChunk = null, this._requests = [], this._done = !1, this.onProgress = null;
        }
        _enqueue(T) {
          if (!this._done) {
            if (this._requests.length === 0)
              this._queuedChunk = T;
            else {
              this._requests.shift().resolve({
                value: T,
                done: !1
              });
              for (const n of this._requests)
                n.resolve({
                  value: void 0,
                  done: !0
                });
              this._requests.length = 0;
            }
            this._done = !0, this._stream._removeRangeReader(this);
          }
        }
        get isStreamingSupported() {
          return !1;
        }
        async read() {
          if (this._queuedChunk) {
            const A = this._queuedChunk;
            return this._queuedChunk = null, {
              value: A,
              done: !1
            };
          }
          if (this._done)
            return {
              value: void 0,
              done: !0
            };
          const T = Promise.withResolvers();
          return this._requests.push(T), T.promise;
        }
        cancel(T) {
          this._done = !0;
          for (const A of this._requests)
            A.resolve({
              value: void 0,
              done: !0
            });
          this._requests.length = 0, this._stream._removeRangeReader(this);
        }
      }
    })
  ),
  /***/
  164: (
    /***/
    ((V, l, a) => {
      a.d(l, {
        /* harmony export */
        GlobalWorkerOptions: () => (
          /* binding */
          s
        )
        /* harmony export */
      });
      class s {
        static #t = null;
        static #e = "";
        static get workerPort() {
          return this.#t;
        }
        static set workerPort(v) {
          if (!(typeof Worker < "u" && v instanceof Worker) && v !== null)
            throw new Error("Invalid `workerPort` type.");
          this.#t = v;
        }
        static get workerSrc() {
          return this.#e;
        }
        static set workerSrc(v) {
          if (typeof v != "string")
            throw new Error("Invalid `workerSrc` type.");
          this.#e = v;
        }
      }
    })
  ),
  /***/
  284: (
    /***/
    ((V, l, a) => {
      a.d(l, {
        /* harmony export */
        XfaLayer: () => (
          /* binding */
          S
        )
        /* harmony export */
      });
      var s = a(50);
      class S {
        static setupStorage(_, x, C, T, A) {
          const n = T.getValue(x, {
            value: null
          });
          switch (C.name) {
            case "textarea":
              if (n.value !== null && (_.textContent = n.value), A === "print")
                break;
              _.addEventListener("input", (f) => {
                T.setValue(x, {
                  value: f.target.value
                });
              });
              break;
            case "input":
              if (C.attributes.type === "radio" || C.attributes.type === "checkbox") {
                if (n.value === C.attributes.xfaOn ? _.setAttribute("checked", !0) : n.value === C.attributes.xfaOff && _.removeAttribute("checked"), A === "print")
                  break;
                _.addEventListener("change", (f) => {
                  T.setValue(x, {
                    value: f.target.checked ? f.target.getAttribute("xfaOn") : f.target.getAttribute("xfaOff")
                  });
                });
              } else {
                if (n.value !== null && _.setAttribute("value", n.value), A === "print")
                  break;
                _.addEventListener("input", (f) => {
                  T.setValue(x, {
                    value: f.target.value
                  });
                });
              }
              break;
            case "select":
              if (n.value !== null) {
                _.setAttribute("value", n.value);
                for (const f of C.children)
                  f.attributes.value === n.value ? f.attributes.selected = !0 : f.attributes.hasOwnProperty("selected") && delete f.attributes.selected;
              }
              _.addEventListener("input", (f) => {
                const p = f.target.options, F = p.selectedIndex === -1 ? "" : p[p.selectedIndex].value;
                T.setValue(x, {
                  value: F
                });
              });
              break;
          }
        }
        static setAttributes({
          html: _,
          element: x,
          storage: C = null,
          intent: T,
          linkService: A
        }) {
          const {
            attributes: n
          } = x, f = _ instanceof HTMLAnchorElement;
          n.type === "radio" && (n.name = `${n.name}-${T}`);
          for (const [p, F] of Object.entries(n))
            if (F != null)
              switch (p) {
                case "class":
                  F.length && _.setAttribute(p, F.join(" "));
                  break;
                case "dataId":
                  break;
                case "id":
                  _.setAttribute("data-element-id", F);
                  break;
                case "style":
                  Object.assign(_.style, F);
                  break;
                case "textContent":
                  _.textContent = F;
                  break;
                default:
                  (!f || p !== "href" && p !== "newWindow") && _.setAttribute(p, F);
              }
          f && A.addLinkAttributes(_, n.href, n.newWindow), C && n.dataId && this.setupStorage(_, n.dataId, x, C);
        }
        static render(_) {
          const x = _.annotationStorage, C = _.linkService, T = _.xfaHtml, A = _.intent || "display", n = document.createElement(T.name);
          T.attributes && this.setAttributes({
            html: n,
            element: T,
            intent: A,
            linkService: C
          });
          const f = A !== "richText", p = _.div;
          if (p.append(n), _.viewport) {
            const w = `matrix(${_.viewport.transform.join(",")})`;
            p.style.transform = w;
          }
          f && p.setAttribute("class", "xfaLayer xfaFont");
          const F = [];
          if (T.children.length === 0) {
            if (T.value) {
              const w = document.createTextNode(T.value);
              n.append(w), f && s.XfaText.shouldBuildText(T.name) && F.push(w);
            }
            return {
              textDivs: F
            };
          }
          const r = [[T, -1, n]];
          for (; r.length > 0; ) {
            const [w, t, i] = r.at(-1);
            if (t + 1 === w.children.length) {
              r.pop();
              continue;
            }
            const h = w.children[++r.at(-1)[1]];
            if (h === null)
              continue;
            const {
              name: d
            } = h;
            if (d === "#text") {
              const k = document.createTextNode(h.value);
              F.push(k), i.append(k);
              continue;
            }
            const E = h?.attributes?.xmlns ? document.createElementNS(h.attributes.xmlns, d) : document.createElement(d);
            if (i.append(E), h.attributes && this.setAttributes({
              html: E,
              element: h,
              storage: x,
              intent: A,
              linkService: C
            }), h.children?.length > 0)
              r.push([h, -1, E]);
            else if (h.value) {
              const k = document.createTextNode(h.value);
              f && s.XfaText.shouldBuildText(d) && F.push(k), E.append(k);
            }
          }
          for (const w of p.querySelectorAll(".xfaNonInteractive input, .xfaNonInteractive textarea"))
            w.setAttribute("readOnly", !0);
          return {
            textDivs: F
          };
        }
        static update(_) {
          const x = `matrix(${_.viewport.transform.join(",")})`;
          _.div.style.transform = x, _.div.hidden = !1;
        }
      }
    })
  ),
  /***/
  50: (
    /***/
    ((V, l, a) => {
      a.d(l, {
        /* harmony export */
        XfaText: () => (
          /* binding */
          s
        )
        /* harmony export */
      });
      class s {
        static textContent(v) {
          const _ = [], x = {
            items: _,
            styles: /* @__PURE__ */ Object.create(null)
          };
          function C(T) {
            if (!T)
              return;
            let A = null;
            const n = T.name;
            if (n === "#text")
              A = T.value;
            else if (s.shouldBuildText(n))
              T?.attributes?.textContent ? A = T.attributes.textContent : T.value && (A = T.value);
            else return;
            if (A !== null && _.push({
              str: A
            }), !!T.children)
              for (const f of T.children)
                C(f);
          }
          return C(v), x;
        }
        static shouldBuildText(v) {
          return !(v === "textarea" || v === "input" || v === "option" || v === "select");
        }
      }
    })
  ),
  /***/
  228: (
    /***/
    ((V, l, a) => {
      a.a(V, async (s, S) => {
        try {
          a.d(l, {
            /* harmony export */
            AbortException: () => (
              /* reexport safe */
              v.AbortException
            ),
            /* harmony export */
            AnnotationEditorLayer: () => (
              /* reexport safe */
              T.AnnotationEditorLayer
            ),
            /* harmony export */
            AnnotationEditorParamsType: () => (
              /* reexport safe */
              v.AnnotationEditorParamsType
            ),
            /* harmony export */
            AnnotationEditorType: () => (
              /* reexport safe */
              v.AnnotationEditorType
            ),
            /* harmony export */
            AnnotationEditorUIManager: () => (
              /* reexport safe */
              A.AnnotationEditorUIManager
            ),
            /* harmony export */
            AnnotationLayer: () => (
              /* reexport safe */
              n.AnnotationLayer
            ),
            /* harmony export */
            AnnotationMode: () => (
              /* reexport safe */
              v.AnnotationMode
            ),
            /* harmony export */
            CMapCompressionType: () => (
              /* reexport safe */
              v.CMapCompressionType
            ),
            /* harmony export */
            ColorPicker: () => (
              /* reexport safe */
              f.ColorPicker
            ),
            /* harmony export */
            DOMSVGFactory: () => (
              /* reexport safe */
              x.DOMSVGFactory
            ),
            /* harmony export */
            DrawLayer: () => (
              /* reexport safe */
              p.DrawLayer
            ),
            /* harmony export */
            FeatureTest: () => (
              /* reexport safe */
              v.FeatureTest
            ),
            /* harmony export */
            GlobalWorkerOptions: () => (
              /* reexport safe */
              F.GlobalWorkerOptions
            ),
            /* harmony export */
            ImageKind: () => (
              /* reexport safe */
              v.ImageKind
            ),
            /* harmony export */
            InvalidPDFException: () => (
              /* reexport safe */
              v.InvalidPDFException
            ),
            /* harmony export */
            MissingPDFException: () => (
              /* reexport safe */
              v.MissingPDFException
            ),
            /* harmony export */
            OPS: () => (
              /* reexport safe */
              v.OPS
            ),
            /* harmony export */
            Outliner: () => (
              /* reexport safe */
              r.Outliner
            ),
            /* harmony export */
            PDFDataRangeTransport: () => (
              /* reexport safe */
              _.PDFDataRangeTransport
            ),
            /* harmony export */
            PDFDateString: () => (
              /* reexport safe */
              x.PDFDateString
            ),
            /* harmony export */
            PDFWorker: () => (
              /* reexport safe */
              _.PDFWorker
            ),
            /* harmony export */
            PasswordResponses: () => (
              /* reexport safe */
              v.PasswordResponses
            ),
            /* harmony export */
            PermissionFlag: () => (
              /* reexport safe */
              v.PermissionFlag
            ),
            /* harmony export */
            PixelsPerInch: () => (
              /* reexport safe */
              x.PixelsPerInch
            ),
            /* harmony export */
            RenderingCancelledException: () => (
              /* reexport safe */
              x.RenderingCancelledException
            ),
            /* harmony export */
            UnexpectedResponseException: () => (
              /* reexport safe */
              v.UnexpectedResponseException
            ),
            /* harmony export */
            Util: () => (
              /* reexport safe */
              v.Util
            ),
            /* harmony export */
            VerbosityLevel: () => (
              /* reexport safe */
              v.VerbosityLevel
            ),
            /* harmony export */
            XfaLayer: () => (
              /* reexport safe */
              w.XfaLayer
            ),
            /* harmony export */
            build: () => (
              /* reexport safe */
              _.build
            ),
            /* harmony export */
            createValidAbsoluteUrl: () => (
              /* reexport safe */
              v.createValidAbsoluteUrl
            ),
            /* harmony export */
            fetchData: () => (
              /* reexport safe */
              x.fetchData
            ),
            /* harmony export */
            getDocument: () => (
              /* reexport safe */
              _.getDocument
            ),
            /* harmony export */
            getFilenameFromUrl: () => (
              /* reexport safe */
              x.getFilenameFromUrl
            ),
            /* harmony export */
            getPdfFilenameFromUrl: () => (
              /* reexport safe */
              x.getPdfFilenameFromUrl
            ),
            /* harmony export */
            getXfaPageViewport: () => (
              /* reexport safe */
              x.getXfaPageViewport
            ),
            /* harmony export */
            isDataScheme: () => (
              /* reexport safe */
              x.isDataScheme
            ),
            /* harmony export */
            isPdfFile: () => (
              /* reexport safe */
              x.isPdfFile
            ),
            /* harmony export */
            noContextMenu: () => (
              /* reexport safe */
              x.noContextMenu
            ),
            /* harmony export */
            normalizeUnicode: () => (
              /* reexport safe */
              v.normalizeUnicode
            ),
            /* harmony export */
            renderTextLayer: () => (
              /* reexport safe */
              C.renderTextLayer
            ),
            /* harmony export */
            setLayerDimensions: () => (
              /* reexport safe */
              x.setLayerDimensions
            ),
            /* harmony export */
            shadow: () => (
              /* reexport safe */
              v.shadow
            ),
            /* harmony export */
            updateTextLayer: () => (
              /* reexport safe */
              C.updateTextLayer
            ),
            /* harmony export */
            version: () => (
              /* reexport safe */
              _.version
            )
            /* harmony export */
          });
          var v = a(292), _ = a(831), x = a(419), C = a(814), T = a(731), A = a(830), n = a(976), f = a(259), p = a(47), F = a(164), r = a(61), w = a(284), t = s([_]);
          _ = (t.then ? (await t)() : t)[0];
          const i = "4.2.67", h = "49b388101";
          S();
        } catch (i) {
          S(i);
        }
      });
    })
  ),
  /***/
  178: (
    /***/
    ((V, l, a) => {
      a.d(l, {
        /* harmony export */
        MessageHandler: () => (
          /* binding */
          x
        )
        /* harmony export */
      });
      var s = a(292);
      const S = {
        DATA: 1,
        ERROR: 2
      }, v = {
        CANCEL: 1,
        CANCEL_COMPLETE: 2,
        CLOSE: 3,
        ENQUEUE: 4,
        ERROR: 5,
        PULL: 6,
        PULL_COMPLETE: 7,
        START_COMPLETE: 8
      };
      function _(C) {
        switch (C instanceof Error || typeof C == "object" && C !== null || (0, s.unreachable)('wrapReason: Expected "reason" to be a (possibly cloned) Error.'), C.name) {
          case "AbortException":
            return new s.AbortException(C.message);
          case "MissingPDFException":
            return new s.MissingPDFException(C.message);
          case "PasswordException":
            return new s.PasswordException(C.message, C.code);
          case "UnexpectedResponseException":
            return new s.UnexpectedResponseException(C.message, C.status);
          case "UnknownErrorException":
            return new s.UnknownErrorException(C.message, C.details);
          default:
            return new s.UnknownErrorException(C.message, C.toString());
        }
      }
      class x {
        constructor(T, A, n) {
          this.sourceName = T, this.targetName = A, this.comObj = n, this.callbackId = 1, this.streamId = 1, this.streamSinks = /* @__PURE__ */ Object.create(null), this.streamControllers = /* @__PURE__ */ Object.create(null), this.callbackCapabilities = /* @__PURE__ */ Object.create(null), this.actionHandler = /* @__PURE__ */ Object.create(null), this._onComObjOnMessage = (f) => {
            const p = f.data;
            if (p.targetName !== this.sourceName)
              return;
            if (p.stream) {
              this.#e(p);
              return;
            }
            if (p.callback) {
              const r = p.callbackId, w = this.callbackCapabilities[r];
              if (!w)
                throw new Error(`Cannot resolve callback ${r}`);
              if (delete this.callbackCapabilities[r], p.callback === S.DATA)
                w.resolve(p.data);
              else if (p.callback === S.ERROR)
                w.reject(_(p.reason));
              else
                throw new Error("Unexpected callback case");
              return;
            }
            const F = this.actionHandler[p.action];
            if (!F)
              throw new Error(`Unknown action from worker: ${p.action}`);
            if (p.callbackId) {
              const r = this.sourceName, w = p.sourceName;
              new Promise(function(t) {
                t(F(p.data));
              }).then(function(t) {
                n.postMessage({
                  sourceName: r,
                  targetName: w,
                  callback: S.DATA,
                  callbackId: p.callbackId,
                  data: t
                });
              }, function(t) {
                n.postMessage({
                  sourceName: r,
                  targetName: w,
                  callback: S.ERROR,
                  callbackId: p.callbackId,
                  reason: _(t)
                });
              });
              return;
            }
            if (p.streamId) {
              this.#t(p);
              return;
            }
            F(p.data);
          }, n.addEventListener("message", this._onComObjOnMessage);
        }
        on(T, A) {
          const n = this.actionHandler;
          if (n[T])
            throw new Error(`There is already an actionName called "${T}"`);
          n[T] = A;
        }
        send(T, A, n) {
          this.comObj.postMessage({
            sourceName: this.sourceName,
            targetName: this.targetName,
            action: T,
            data: A
          }, n);
        }
        sendWithPromise(T, A, n) {
          const f = this.callbackId++, p = Promise.withResolvers();
          this.callbackCapabilities[f] = p;
          try {
            this.comObj.postMessage({
              sourceName: this.sourceName,
              targetName: this.targetName,
              action: T,
              callbackId: f,
              data: A
            }, n);
          } catch (F) {
            p.reject(F);
          }
          return p.promise;
        }
        sendWithStream(T, A, n, f) {
          const p = this.streamId++, F = this.sourceName, r = this.targetName, w = this.comObj;
          return new ReadableStream({
            start: (t) => {
              const i = Promise.withResolvers();
              return this.streamControllers[p] = {
                controller: t,
                startCall: i,
                pullCall: null,
                cancelCall: null,
                isClosed: !1
              }, w.postMessage({
                sourceName: F,
                targetName: r,
                action: T,
                streamId: p,
                data: A,
                desiredSize: t.desiredSize
              }, f), i.promise;
            },
            pull: (t) => {
              const i = Promise.withResolvers();
              return this.streamControllers[p].pullCall = i, w.postMessage({
                sourceName: F,
                targetName: r,
                stream: v.PULL,
                streamId: p,
                desiredSize: t.desiredSize
              }), i.promise;
            },
            cancel: (t) => {
              (0, s.assert)(t instanceof Error, "cancel must have a valid reason");
              const i = Promise.withResolvers();
              return this.streamControllers[p].cancelCall = i, this.streamControllers[p].isClosed = !0, w.postMessage({
                sourceName: F,
                targetName: r,
                stream: v.CANCEL,
                streamId: p,
                reason: _(t)
              }), i.promise;
            }
          }, n);
        }
        #t(T) {
          const A = T.streamId, n = this.sourceName, f = T.sourceName, p = this.comObj, F = this, r = this.actionHandler[T.action], w = {
            enqueue(t, i = 1, h) {
              if (this.isCancelled)
                return;
              const d = this.desiredSize;
              this.desiredSize -= i, d > 0 && this.desiredSize <= 0 && (this.sinkCapability = Promise.withResolvers(), this.ready = this.sinkCapability.promise), p.postMessage({
                sourceName: n,
                targetName: f,
                stream: v.ENQUEUE,
                streamId: A,
                chunk: t
              }, h);
            },
            close() {
              this.isCancelled || (this.isCancelled = !0, p.postMessage({
                sourceName: n,
                targetName: f,
                stream: v.CLOSE,
                streamId: A
              }), delete F.streamSinks[A]);
            },
            error(t) {
              (0, s.assert)(t instanceof Error, "error must have a valid reason"), !this.isCancelled && (this.isCancelled = !0, p.postMessage({
                sourceName: n,
                targetName: f,
                stream: v.ERROR,
                streamId: A,
                reason: _(t)
              }));
            },
            sinkCapability: Promise.withResolvers(),
            onPull: null,
            onCancel: null,
            isCancelled: !1,
            desiredSize: T.desiredSize,
            ready: null
          };
          w.sinkCapability.resolve(), w.ready = w.sinkCapability.promise, this.streamSinks[A] = w, new Promise(function(t) {
            t(r(T.data, w));
          }).then(function() {
            p.postMessage({
              sourceName: n,
              targetName: f,
              stream: v.START_COMPLETE,
              streamId: A,
              success: !0
            });
          }, function(t) {
            p.postMessage({
              sourceName: n,
              targetName: f,
              stream: v.START_COMPLETE,
              streamId: A,
              reason: _(t)
            });
          });
        }
        #e(T) {
          const A = T.streamId, n = this.sourceName, f = T.sourceName, p = this.comObj, F = this.streamControllers[A], r = this.streamSinks[A];
          switch (T.stream) {
            case v.START_COMPLETE:
              T.success ? F.startCall.resolve() : F.startCall.reject(_(T.reason));
              break;
            case v.PULL_COMPLETE:
              T.success ? F.pullCall.resolve() : F.pullCall.reject(_(T.reason));
              break;
            case v.PULL:
              if (!r) {
                p.postMessage({
                  sourceName: n,
                  targetName: f,
                  stream: v.PULL_COMPLETE,
                  streamId: A,
                  success: !0
                });
                break;
              }
              r.desiredSize <= 0 && T.desiredSize > 0 && r.sinkCapability.resolve(), r.desiredSize = T.desiredSize, new Promise(function(w) {
                w(r.onPull?.());
              }).then(function() {
                p.postMessage({
                  sourceName: n,
                  targetName: f,
                  stream: v.PULL_COMPLETE,
                  streamId: A,
                  success: !0
                });
              }, function(w) {
                p.postMessage({
                  sourceName: n,
                  targetName: f,
                  stream: v.PULL_COMPLETE,
                  streamId: A,
                  reason: _(w)
                });
              });
              break;
            case v.ENQUEUE:
              if ((0, s.assert)(F, "enqueue should have stream controller"), F.isClosed)
                break;
              F.controller.enqueue(T.chunk);
              break;
            case v.CLOSE:
              if ((0, s.assert)(F, "close should have stream controller"), F.isClosed)
                break;
              F.isClosed = !0, F.controller.close(), this.#s(F, A);
              break;
            case v.ERROR:
              (0, s.assert)(F, "error should have stream controller"), F.controller.error(_(T.reason)), this.#s(F, A);
              break;
            case v.CANCEL_COMPLETE:
              T.success ? F.cancelCall.resolve() : F.cancelCall.reject(_(T.reason)), this.#s(F, A);
              break;
            case v.CANCEL:
              if (!r)
                break;
              new Promise(function(w) {
                w(r.onCancel?.(_(T.reason)));
              }).then(function() {
                p.postMessage({
                  sourceName: n,
                  targetName: f,
                  stream: v.CANCEL_COMPLETE,
                  streamId: A,
                  success: !0
                });
              }, function(w) {
                p.postMessage({
                  sourceName: n,
                  targetName: f,
                  stream: v.CANCEL_COMPLETE,
                  streamId: A,
                  reason: _(w)
                });
              }), r.sinkCapability.reject(_(T.reason)), r.isCancelled = !0, delete this.streamSinks[A];
              break;
            default:
              throw new Error("Unexpected stream case");
          }
        }
        async #s(T, A) {
          await Promise.allSettled([T.startCall?.promise, T.pullCall?.promise, T.cancelCall?.promise]), delete this.streamControllers[A];
        }
        destroy() {
          this.comObj.removeEventListener("message", this._onComObjOnMessage);
        }
      }
    })
  ),
  /***/
  651: (
    /***/
    ((V, l, a) => {
      a.d(l, {
        /* harmony export */
        MurmurHash3_64: () => (
          /* binding */
          _
        )
        /* harmony export */
      });
      const s = 3285377520, S = 4294901760, v = 65535;
      class _ {
        constructor(C) {
          this.h1 = C ? C & 4294967295 : s, this.h2 = C ? C & 4294967295 : s;
        }
        update(C) {
          let T, A;
          if (typeof C == "string") {
            T = new Uint8Array(C.length * 2), A = 0;
            for (let k = 0, L = C.length; k < L; k++) {
              const M = C.charCodeAt(k);
              M <= 255 ? T[A++] = M : (T[A++] = M >>> 8, T[A++] = M & 255);
            }
          } else if (ArrayBuffer.isView(C))
            T = C.slice(), A = T.byteLength;
          else
            throw new Error("Invalid data format, must be a string or TypedArray.");
          const n = A >> 2, f = A - n * 4, p = new Uint32Array(T.buffer, 0, n);
          let F = 0, r = 0, w = this.h1, t = this.h2;
          const i = 3432918353, h = 461845907, d = i & v, E = h & v;
          for (let k = 0; k < n; k++)
            k & 1 ? (F = p[k], F = F * i & S | F * d & v, F = F << 15 | F >>> 17, F = F * h & S | F * E & v, w ^= F, w = w << 13 | w >>> 19, w = w * 5 + 3864292196) : (r = p[k], r = r * i & S | r * d & v, r = r << 15 | r >>> 17, r = r * h & S | r * E & v, t ^= r, t = t << 13 | t >>> 19, t = t * 5 + 3864292196);
          switch (F = 0, f) {
            case 3:
              F ^= T[n * 4 + 2] << 16;
            case 2:
              F ^= T[n * 4 + 1] << 8;
            case 1:
              F ^= T[n * 4], F = F * i & S | F * d & v, F = F << 15 | F >>> 17, F = F * h & S | F * E & v, n & 1 ? w ^= F : t ^= F;
          }
          this.h1 = w, this.h2 = t;
        }
        hexdigest() {
          let C = this.h1, T = this.h2;
          return C ^= T >>> 1, C = C * 3981806797 & S | C * 36045 & v, T = T * 4283543511 & S | ((T << 16 | C >>> 16) * 2950163797 & S) >>> 16, C ^= T >>> 1, C = C * 444984403 & S | C * 60499 & v, T = T * 3301882366 & S | ((T << 16 | C >>> 16) * 3120437893 & S) >>> 16, C ^= T >>> 1, (C >>> 0).toString(16).padStart(8, "0") + (T >>> 0).toString(16).padStart(8, "0");
        }
      }
    })
  ),
  /***/
  292: (
    /***/
    ((V, l, a) => {
      a.d(l, {
        /* harmony export */
        AbortException: () => (
          /* binding */
          ft
        ),
        /* harmony export */
        AnnotationBorderStyleType: () => (
          /* binding */
          t
        ),
        /* harmony export */
        AnnotationEditorParamsType: () => (
          /* binding */
          f
        ),
        /* harmony export */
        AnnotationEditorPrefix: () => (
          /* binding */
          A
        ),
        /* harmony export */
        AnnotationEditorType: () => (
          /* binding */
          n
        ),
        /* harmony export */
        AnnotationMode: () => (
          /* binding */
          T
        ),
        /* harmony export */
        AnnotationPrefix: () => (
          /* binding */
          H
        ),
        /* harmony export */
        AnnotationType: () => (
          /* binding */
          w
        ),
        /* harmony export */
        BaseException: () => (
          /* binding */
          j
        ),
        /* harmony export */
        CMapCompressionType: () => (
          /* binding */
          h
        ),
        /* harmony export */
        FONT_IDENTITY_MATRIX: () => (
          /* binding */
          v
        ),
        /* harmony export */
        FeatureTest: () => (
          /* binding */
          u
        ),
        /* harmony export */
        FontRenderOps: () => (
          /* binding */
          $
        ),
        /* harmony export */
        FormatError: () => (
          /* binding */
          dt
        ),
        /* harmony export */
        IDENTITY_MATRIX: () => (
          /* binding */
          S
        ),
        /* harmony export */
        ImageKind: () => (
          /* binding */
          r
        ),
        /* harmony export */
        InvalidPDFException: () => (
          /* binding */
          tt
        ),
        /* harmony export */
        LINE_FACTOR: () => (
          /* binding */
          x
        ),
        /* harmony export */
        MAX_IMAGE_SIZE_TO_CACHE: () => (
          /* binding */
          _
        ),
        /* harmony export */
        MissingPDFException: () => (
          /* binding */
          rt
        ),
        /* harmony export */
        OPS: () => (
          /* binding */
          d
        ),
        /* harmony export */
        PasswordException: () => (
          /* binding */
          Q
        ),
        /* harmony export */
        PasswordResponses: () => (
          /* binding */
          E
        ),
        /* harmony export */
        PermissionFlag: () => (
          /* binding */
          p
        ),
        /* harmony export */
        RenderingIntentFlag: () => (
          /* binding */
          C
        ),
        /* harmony export */
        TextRenderingMode: () => (
          /* binding */
          F
        ),
        /* harmony export */
        UnexpectedResponseException: () => (
          /* binding */
          ut
        ),
        /* harmony export */
        UnknownErrorException: () => (
          /* binding */
          J
        ),
        /* harmony export */
        Util: () => (
          /* binding */
          g
        ),
        /* harmony export */
        VerbosityLevel: () => (
          /* binding */
          i
        ),
        /* harmony export */
        assert: () => (
          /* binding */
          Z
        ),
        /* harmony export */
        bytesToString: () => (
          /* binding */
          lt
        ),
        /* harmony export */
        createValidAbsoluteUrl: () => (
          /* binding */
          Y
        ),
        /* harmony export */
        getUuid: () => (
          /* binding */
          O
        ),
        /* harmony export */
        getVerbosityLevel: () => (
          /* binding */
          M
        ),
        /* harmony export */
        info: () => (
          /* binding */
          B
        ),
        /* harmony export */
        isNodeJS: () => (
          /* binding */
          s
        ),
        /* harmony export */
        normalizeUnicode: () => (
          /* binding */
          I
        ),
        /* harmony export */
        objectFromMap: () => (
          /* binding */
          D
        ),
        /* harmony export */
        setVerbosityLevel: () => (
          /* binding */
          L
        ),
        /* harmony export */
        shadow: () => (
          /* binding */
          G
        ),
        /* harmony export */
        string32: () => (
          /* binding */
          et
        ),
        /* harmony export */
        stringToBytes: () => (
          /* binding */
          ot
        ),
        /* harmony export */
        unreachable: () => (
          /* binding */
          q
        ),
        /* harmony export */
        warn: () => (
          /* binding */
          U
        )
        /* harmony export */
      });
      const s = typeof process == "object" && process + "" == "[object process]" && !process.versions.nw && !(process.versions.electron && process.type && process.type !== "browser"), S = [1, 0, 0, 1, 0, 0], v = [1e-3, 0, 0, 1e-3, 0, 0], _ = 1e7, x = 1.35, C = {
        ANY: 1,
        DISPLAY: 2,
        PRINT: 4,
        SAVE: 8,
        ANNOTATIONS_FORMS: 16,
        ANNOTATIONS_STORAGE: 32,
        ANNOTATIONS_DISABLE: 64,
        OPLIST: 256
      }, T = {
        DISABLE: 0,
        ENABLE: 1,
        ENABLE_FORMS: 2,
        ENABLE_STORAGE: 3
      }, A = "pdfjs_internal_editor_", n = {
        DISABLE: -1,
        NONE: 0,
        FREETEXT: 3,
        HIGHLIGHT: 9,
        STAMP: 13,
        INK: 15
      }, f = {
        RESIZE: 1,
        CREATE: 2,
        FREETEXT_SIZE: 11,
        FREETEXT_COLOR: 12,
        FREETEXT_OPACITY: 13,
        INK_COLOR: 21,
        INK_THICKNESS: 22,
        INK_OPACITY: 23,
        HIGHLIGHT_COLOR: 31,
        HIGHLIGHT_DEFAULT_COLOR: 32,
        HIGHLIGHT_THICKNESS: 33,
        HIGHLIGHT_FREE: 34,
        HIGHLIGHT_SHOW_ALL: 35
      }, p = {
        PRINT: 4,
        MODIFY_CONTENTS: 8,
        COPY: 16,
        MODIFY_ANNOTATIONS: 32,
        FILL_INTERACTIVE_FORMS: 256,
        COPY_FOR_ACCESSIBILITY: 512,
        ASSEMBLE: 1024,
        PRINT_HIGH_QUALITY: 2048
      }, F = {
        FILL: 0,
        STROKE: 1,
        FILL_STROKE: 2,
        INVISIBLE: 3,
        FILL_ADD_TO_PATH: 4,
        STROKE_ADD_TO_PATH: 5,
        FILL_STROKE_ADD_TO_PATH: 6,
        ADD_TO_PATH: 7,
        FILL_STROKE_MASK: 3,
        ADD_TO_PATH_FLAG: 4
      }, r = {
        GRAYSCALE_1BPP: 1,
        RGB_24BPP: 2,
        RGBA_32BPP: 3
      }, w = {
        TEXT: 1,
        LINK: 2,
        FREETEXT: 3,
        LINE: 4,
        SQUARE: 5,
        CIRCLE: 6,
        POLYGON: 7,
        POLYLINE: 8,
        HIGHLIGHT: 9,
        UNDERLINE: 10,
        SQUIGGLY: 11,
        STRIKEOUT: 12,
        STAMP: 13,
        CARET: 14,
        INK: 15,
        POPUP: 16,
        FILEATTACHMENT: 17,
        SOUND: 18,
        MOVIE: 19,
        WIDGET: 20,
        SCREEN: 21,
        PRINTERMARK: 22,
        TRAPNET: 23,
        WATERMARK: 24,
        THREED: 25,
        REDACT: 26
      }, t = {
        SOLID: 1,
        DASHED: 2,
        BEVELED: 3,
        INSET: 4,
        UNDERLINE: 5
      }, i = {
        ERRORS: 0,
        WARNINGS: 1,
        INFOS: 5
      }, h = {
        NONE: 0,
        BINARY: 1
      }, d = {
        dependency: 1,
        setLineWidth: 2,
        setLineCap: 3,
        setLineJoin: 4,
        setMiterLimit: 5,
        setDash: 6,
        setRenderingIntent: 7,
        setFlatness: 8,
        setGState: 9,
        save: 10,
        restore: 11,
        transform: 12,
        moveTo: 13,
        lineTo: 14,
        curveTo: 15,
        curveTo2: 16,
        curveTo3: 17,
        closePath: 18,
        rectangle: 19,
        stroke: 20,
        closeStroke: 21,
        fill: 22,
        eoFill: 23,
        fillStroke: 24,
        eoFillStroke: 25,
        closeFillStroke: 26,
        closeEOFillStroke: 27,
        endPath: 28,
        clip: 29,
        eoClip: 30,
        beginText: 31,
        endText: 32,
        setCharSpacing: 33,
        setWordSpacing: 34,
        setHScale: 35,
        setLeading: 36,
        setFont: 37,
        setTextRenderingMode: 38,
        setTextRise: 39,
        moveText: 40,
        setLeadingMoveText: 41,
        setTextMatrix: 42,
        nextLine: 43,
        showText: 44,
        showSpacedText: 45,
        nextLineShowText: 46,
        nextLineSetSpacingShowText: 47,
        setCharWidth: 48,
        setCharWidthAndBounds: 49,
        setStrokeColorSpace: 50,
        setFillColorSpace: 51,
        setStrokeColor: 52,
        setStrokeColorN: 53,
        setFillColor: 54,
        setFillColorN: 55,
        setStrokeGray: 56,
        setFillGray: 57,
        setStrokeRGBColor: 58,
        setFillRGBColor: 59,
        setStrokeCMYKColor: 60,
        setFillCMYKColor: 61,
        shadingFill: 62,
        beginInlineImage: 63,
        beginImageData: 64,
        endInlineImage: 65,
        paintXObject: 66,
        markPoint: 67,
        markPointProps: 68,
        beginMarkedContent: 69,
        beginMarkedContentProps: 70,
        endMarkedContent: 71,
        beginCompat: 72,
        endCompat: 73,
        paintFormXObjectBegin: 74,
        paintFormXObjectEnd: 75,
        beginGroup: 76,
        endGroup: 77,
        beginAnnotation: 80,
        endAnnotation: 81,
        paintImageMaskXObject: 83,
        paintImageMaskXObjectGroup: 84,
        paintImageXObject: 85,
        paintInlineImageXObject: 86,
        paintInlineImageXObjectGroup: 87,
        paintImageXObjectRepeat: 88,
        paintImageMaskXObjectRepeat: 89,
        paintSolidColorImageMask: 90,
        constructPath: 91
      }, E = {
        NEED_PASSWORD: 1,
        INCORRECT_PASSWORD: 2
      };
      let k = i.WARNINGS;
      function L(z) {
        Number.isInteger(z) && (k = z);
      }
      function M() {
        return k;
      }
      function B(z) {
        k >= i.INFOS && console.log(`Info: ${z}`);
      }
      function U(z) {
        k >= i.WARNINGS && console.log(`Warning: ${z}`);
      }
      function q(z) {
        throw new Error(z);
      }
      function Z(z, N) {
        z || q(N);
      }
      function K(z) {
        switch (z?.protocol) {
          case "http:":
          case "https:":
          case "ftp:":
          case "mailto:":
          case "tel:":
            return !0;
          default:
            return !1;
        }
      }
      function Y(z, N = null, P = null) {
        if (!z)
          return null;
        try {
          if (P && typeof z == "string" && (P.addDefaultProtocol && z.startsWith("www.") && z.match(/\./g)?.length >= 2 && (z = `http://${z}`), P.tryConvertEncoding))
            try {
              z = c(z);
            } catch {
            }
          const X = N ? new URL(z, N) : new URL(z);
          if (K(X))
            return X;
        } catch {
        }
        return null;
      }
      function G(z, N, P, X = !1) {
        return Object.defineProperty(z, N, {
          value: P,
          enumerable: !X,
          configurable: !0,
          writable: !1
        }), P;
      }
      const j = (function() {
        function N(P, X) {
          this.constructor === N && q("Cannot initialize BaseException."), this.message = P, this.name = X;
        }
        return N.prototype = new Error(), N.constructor = N, N;
      })();
      class Q extends j {
        constructor(N, P) {
          super(N, "PasswordException"), this.code = P;
        }
      }
      class J extends j {
        constructor(N, P) {
          super(N, "UnknownErrorException"), this.details = P;
        }
      }
      class tt extends j {
        constructor(N) {
          super(N, "InvalidPDFException");
        }
      }
      class rt extends j {
        constructor(N) {
          super(N, "MissingPDFException");
        }
      }
      class ut extends j {
        constructor(N, P) {
          super(N, "UnexpectedResponseException"), this.status = P;
        }
      }
      class dt extends j {
        constructor(N) {
          super(N, "FormatError");
        }
      }
      class ft extends j {
        constructor(N) {
          super(N, "AbortException");
        }
      }
      function lt(z) {
        (typeof z != "object" || z?.length === void 0) && q("Invalid argument for bytesToString");
        const N = z.length, P = 8192;
        if (N < P)
          return String.fromCharCode.apply(null, z);
        const X = [];
        for (let it = 0; it < N; it += P) {
          const W = Math.min(it + P, N), st = z.subarray(it, W);
          X.push(String.fromCharCode.apply(null, st));
        }
        return X.join("");
      }
      function ot(z) {
        typeof z != "string" && q("Invalid argument for stringToBytes");
        const N = z.length, P = new Uint8Array(N);
        for (let X = 0; X < N; ++X)
          P[X] = z.charCodeAt(X) & 255;
        return P;
      }
      function et(z) {
        return String.fromCharCode(z >> 24 & 255, z >> 16 & 255, z >> 8 & 255, z & 255);
      }
      function D(z) {
        const N = /* @__PURE__ */ Object.create(null);
        for (const [P, X] of z)
          N[P] = X;
        return N;
      }
      function y() {
        const z = new Uint8Array(4);
        return z[0] = 1, new Uint32Array(z.buffer, 0, 1)[0] === 1;
      }
      function o() {
        try {
          return new Function(""), !0;
        } catch {
          return !1;
        }
      }
      class u {
        static get isLittleEndian() {
          return G(this, "isLittleEndian", y());
        }
        static get isEvalSupported() {
          return G(this, "isEvalSupported", o());
        }
        static get isOffscreenCanvasSupported() {
          return G(this, "isOffscreenCanvasSupported", typeof OffscreenCanvas < "u");
        }
        static get platform() {
          return typeof navigator < "u" && typeof navigator?.platform == "string" ? G(this, "platform", {
            isMac: navigator.platform.includes("Mac")
          }) : G(this, "platform", {
            isMac: !1
          });
        }
        static get isCSSRoundSupported() {
          return G(this, "isCSSRoundSupported", globalThis.CSS?.supports?.("width: round(1.5px, 1px)"));
        }
      }
      const m = Array.from(Array(256).keys(), (z) => z.toString(16).padStart(2, "0"));
      class g {
        static makeHexColor(N, P, X) {
          return `#${m[N]}${m[P]}${m[X]}`;
        }
        static scaleMinMax(N, P) {
          let X;
          N[0] ? (N[0] < 0 && (X = P[0], P[0] = P[2], P[2] = X), P[0] *= N[0], P[2] *= N[0], N[3] < 0 && (X = P[1], P[1] = P[3], P[3] = X), P[1] *= N[3], P[3] *= N[3]) : (X = P[0], P[0] = P[1], P[1] = X, X = P[2], P[2] = P[3], P[3] = X, N[1] < 0 && (X = P[1], P[1] = P[3], P[3] = X), P[1] *= N[1], P[3] *= N[1], N[2] < 0 && (X = P[0], P[0] = P[2], P[2] = X), P[0] *= N[2], P[2] *= N[2]), P[0] += N[4], P[1] += N[5], P[2] += N[4], P[3] += N[5];
        }
        static transform(N, P) {
          return [N[0] * P[0] + N[2] * P[1], N[1] * P[0] + N[3] * P[1], N[0] * P[2] + N[2] * P[3], N[1] * P[2] + N[3] * P[3], N[0] * P[4] + N[2] * P[5] + N[4], N[1] * P[4] + N[3] * P[5] + N[5]];
        }
        static applyTransform(N, P) {
          const X = N[0] * P[0] + N[1] * P[2] + P[4], it = N[0] * P[1] + N[1] * P[3] + P[5];
          return [X, it];
        }
        static applyInverseTransform(N, P) {
          const X = P[0] * P[3] - P[1] * P[2], it = (N[0] * P[3] - N[1] * P[2] + P[2] * P[5] - P[4] * P[3]) / X, W = (-N[0] * P[1] + N[1] * P[0] + P[4] * P[1] - P[5] * P[0]) / X;
          return [it, W];
        }
        static getAxialAlignedBoundingBox(N, P) {
          const X = this.applyTransform(N, P), it = this.applyTransform(N.slice(2, 4), P), W = this.applyTransform([N[0], N[3]], P), st = this.applyTransform([N[2], N[1]], P);
          return [Math.min(X[0], it[0], W[0], st[0]), Math.min(X[1], it[1], W[1], st[1]), Math.max(X[0], it[0], W[0], st[0]), Math.max(X[1], it[1], W[1], st[1])];
        }
        static inverseTransform(N) {
          const P = N[0] * N[3] - N[1] * N[2];
          return [N[3] / P, -N[1] / P, -N[2] / P, N[0] / P, (N[2] * N[5] - N[4] * N[3]) / P, (N[4] * N[1] - N[5] * N[0]) / P];
        }
        static singularValueDecompose2dScale(N) {
          const P = [N[0], N[2], N[1], N[3]], X = N[0] * P[0] + N[1] * P[2], it = N[0] * P[1] + N[1] * P[3], W = N[2] * P[0] + N[3] * P[2], st = N[2] * P[1] + N[3] * P[3], ct = (X + st) / 2, at = Math.sqrt((X + st) ** 2 - 4 * (X * st - W * it)) / 2, nt = ct + at || 1, ht = ct - at || 1;
          return [Math.sqrt(nt), Math.sqrt(ht)];
        }
        static normalizeRect(N) {
          const P = N.slice(0);
          return N[0] > N[2] && (P[0] = N[2], P[2] = N[0]), N[1] > N[3] && (P[1] = N[3], P[3] = N[1]), P;
        }
        static intersect(N, P) {
          const X = Math.max(Math.min(N[0], N[2]), Math.min(P[0], P[2])), it = Math.min(Math.max(N[0], N[2]), Math.max(P[0], P[2]));
          if (X > it)
            return null;
          const W = Math.max(Math.min(N[1], N[3]), Math.min(P[1], P[3])), st = Math.min(Math.max(N[1], N[3]), Math.max(P[1], P[3]));
          return W > st ? null : [X, W, it, st];
        }
        static #t(N, P, X, it, W, st, ct, at, nt, ht) {
          if (nt <= 0 || nt >= 1)
            return;
          const pt = 1 - nt, vt = nt * nt, bt = vt * nt, wt = pt * (pt * (pt * N + 3 * nt * P) + 3 * vt * X) + bt * it, mt = pt * (pt * (pt * W + 3 * nt * st) + 3 * vt * ct) + bt * at;
          ht[0] = Math.min(ht[0], wt), ht[1] = Math.min(ht[1], mt), ht[2] = Math.max(ht[2], wt), ht[3] = Math.max(ht[3], mt);
        }
        static #e(N, P, X, it, W, st, ct, at, nt, ht, pt, vt) {
          if (Math.abs(nt) < 1e-12) {
            Math.abs(ht) >= 1e-12 && this.#t(N, P, X, it, W, st, ct, at, -pt / ht, vt);
            return;
          }
          const bt = ht ** 2 - 4 * pt * nt;
          if (bt < 0)
            return;
          const wt = Math.sqrt(bt), mt = 2 * nt;
          this.#t(N, P, X, it, W, st, ct, at, (-ht + wt) / mt, vt), this.#t(N, P, X, it, W, st, ct, at, (-ht - wt) / mt, vt);
        }
        static bezierBoundingBox(N, P, X, it, W, st, ct, at, nt) {
          return nt ? (nt[0] = Math.min(nt[0], N, ct), nt[1] = Math.min(nt[1], P, at), nt[2] = Math.max(nt[2], N, ct), nt[3] = Math.max(nt[3], P, at)) : nt = [Math.min(N, ct), Math.min(P, at), Math.max(N, ct), Math.max(P, at)], this.#e(N, X, W, ct, P, it, st, at, 3 * (-N + 3 * (X - W) + ct), 6 * (N - 2 * X + W), 3 * (X - N), nt), this.#e(N, X, W, ct, P, it, st, at, 3 * (-P + 3 * (it - st) + at), 6 * (P - 2 * it + st), 3 * (it - P), nt), nt;
        }
      }
      function c(z) {
        return decodeURIComponent(escape(z));
      }
      let b = null, R = null;
      function I(z) {
        return b || (b = /([\u00a0\u00b5\u037e\u0eb3\u2000-\u200a\u202f\u2126\ufb00-\ufb04\ufb06\ufb20-\ufb36\ufb38-\ufb3c\ufb3e\ufb40-\ufb41\ufb43-\ufb44\ufb46-\ufba1\ufba4-\ufba9\ufbae-\ufbb1\ufbd3-\ufbdc\ufbde-\ufbe7\ufbea-\ufbf8\ufbfc-\ufbfd\ufc00-\ufc5d\ufc64-\ufcf1\ufcf5-\ufd3d\ufd88\ufdf4\ufdfa-\ufdfb\ufe71\ufe77\ufe79\ufe7b\ufe7d]+)|(\ufb05+)/gu, R = /* @__PURE__ */ new Map([["ﬅ", "ſt"]])), z.replaceAll(b, (N, P, X) => P ? P.normalize("NFKC") : R.get(X));
      }
      function O() {
        if (typeof crypto < "u" && typeof crypto?.randomUUID == "function")
          return crypto.randomUUID();
        const z = new Uint8Array(32);
        if (typeof crypto < "u" && typeof crypto?.getRandomValues == "function")
          crypto.getRandomValues(z);
        else
          for (let N = 0; N < 32; N++)
            z[N] = Math.floor(Math.random() * 255);
        return lt(z);
      }
      const H = "pdfjs_internal_id_", $ = {
        BEZIER_CURVE_TO: 0,
        MOVE_TO: 1,
        LINE_TO: 2,
        QUADRATIC_CURVE_TO: 3,
        RESTORE: 4,
        SAVE: 5,
        SCALE: 6,
        TRANSFORM: 7,
        TRANSLATE: 8
      };
    })
  )
  /******/
}, qe = {};
function Vt(V) {
  var l = qe[V];
  if (l !== void 0)
    return l.exports;
  var a = qe[V] = {
    /******/
    // no module.id needed
    /******/
    // no module.loaded needed
    /******/
    exports: {}
    /******/
  };
  return cn[V](a, a.exports, Vt), a.exports;
}
(() => {
  var V = typeof Symbol == "function" ? Symbol("webpack queues") : "__webpack_queues__", l = typeof Symbol == "function" ? Symbol("webpack exports") : "__webpack_exports__", a = typeof Symbol == "function" ? Symbol("webpack error") : "__webpack_error__", s = (v) => {
    v && v.d < 1 && (v.d = 1, v.forEach((_) => _.r--), v.forEach((_) => _.r-- ? _.r++ : _()));
  }, S = (v) => v.map((_) => {
    if (_ !== null && typeof _ == "object") {
      if (_[V]) return _;
      if (_.then) {
        var x = [];
        x.d = 0, _.then((A) => {
          C[l] = A, s(x);
        }, (A) => {
          C[a] = A, s(x);
        });
        var C = {};
        return C[V] = (A) => A(x), C;
      }
    }
    var T = {};
    return T[V] = (A) => {
    }, T[l] = _, T;
  });
  Vt.a = (v, _, x) => {
    var C;
    x && ((C = []).d = -1);
    var T = /* @__PURE__ */ new Set(), A = v.exports, n, f, p, F = new Promise((r, w) => {
      p = w, f = r;
    });
    F[l] = A, F[V] = (r) => (C && r(C), T.forEach(r), F.catch((w) => {
    })), v.exports = F, _((r) => {
      n = S(r);
      var w, t = () => n.map((h) => {
        if (h[a]) throw h[a];
        return h[l];
      }), i = new Promise((h) => {
        w = () => h(t), w.r = 0;
        var d = (E) => E !== C && !T.has(E) && (T.add(E), E && !E.d && (w.r++, E.push(w)));
        n.map((E) => E[V](d));
      });
      return w.r ? i : t();
    }, (r) => (r ? p(F[a] = r) : f(A), s(C))), C && C.d < 0 && (C.d = 0);
  };
})();
Vt.d = (V, l) => {
  for (var a in l)
    Vt.o(l, a) && !Vt.o(V, a) && Object.defineProperty(V, a, { enumerable: !0, get: l[a] });
};
Vt.o = (V, l) => Object.prototype.hasOwnProperty.call(V, l);
var gt = Vt(228);
gt = globalThis.pdfjsLib = await (globalThis.pdfjsLibPromise = gt);
gt.AbortException;
gt.AnnotationEditorLayer;
gt.AnnotationEditorParamsType;
gt.AnnotationEditorType;
gt.AnnotationEditorUIManager;
gt.AnnotationLayer;
gt.AnnotationMode;
gt.CMapCompressionType;
gt.ColorPicker;
gt.DOMSVGFactory;
gt.DrawLayer;
gt.FeatureTest;
var un = gt.GlobalWorkerOptions;
gt.ImageKind;
gt.InvalidPDFException;
gt.MissingPDFException;
gt.OPS;
gt.Outliner;
gt.PDFDataRangeTransport;
gt.PDFDateString;
gt.PDFWorker;
gt.PasswordResponses;
gt.PermissionFlag;
gt.PixelsPerInch;
gt.RenderingCancelledException;
gt.UnexpectedResponseException;
gt.Util;
gt.VerbosityLevel;
gt.XfaLayer;
gt.build;
gt.createValidAbsoluteUrl;
gt.fetchData;
var dn = gt.getDocument;
gt.getFilenameFromUrl;
gt.getPdfFilenameFromUrl;
gt.getXfaPageViewport;
gt.isDataScheme;
gt.isPdfFile;
gt.noContextMenu;
gt.normalizeUnicode;
gt.renderTextLayer;
gt.setLayerDimensions;
gt.shadow;
gt.updateTextLayer;
gt.version;
var fn = e.from_html('<!> <div class="pdf-canvas svelte-r41nsf"><canvas></canvas></div> <div class="button-row svelte-r41nsf"><!> <div class="page-count svelte-r41nsf"><input type="number" class="svelte-r41nsf"/> <span style="padding: var(--size-1)">/</span> <span style="padding-right: var(--size-2); width: fit-content"> </span></div> <!></div>', 1), pn = e.from_html("<!> <!> <!>", 1);
function yn(V, l) {
  e.push(l, !0);
  var a = this && this.__awaiter || function(h, d, E, k) {
    function L(M) {
      return M instanceof E ? M : new E(function(B) {
        B(M);
      });
    }
    return new (E || (E = Promise))(function(M, B) {
      function U(K) {
        try {
          Z(k.next(K));
        } catch (Y) {
          B(Y);
        }
      }
      function q(K) {
        try {
          Z(k.throw(K));
        } catch (Y) {
          B(Y);
        }
      }
      function Z(K) {
        K.done ? M(K.value) : L(K.value).then(U, q);
      }
      Z((k = k.apply(h, d || [])).next());
    });
  };
  const s = e.rest_props(l, ["$$slots", "$$events", "$$legacy"]), S = new ks(s);
  un.workerSrc = "https://cdn.jsdelivr.net/gh/freddyaboulton/gradio-pdf@main/pdf.worker.min.mjs";
  let v = e.state(e.proxy(S.props.value)), _, x = e.state(1), C, T = e.derived(() => Math.min(Math.max(S.props.starting_page, 1), e.get(x)));
  e.user_effect(() => p(e.get(T)));
  function A() {
    return a(this, void 0, void 0, function* () {
      S.props.value = null, yield se(), S.dispatch("change");
    });
  }
  function n(h) {
    return a(this, arguments, void 0, function* ({ detail: d }) {
      S.props.value = d, yield se(), S.dispatch("upload");
    });
  }
  function f(h) {
    return a(this, void 0, void 0, function* () {
      _ = yield dn({
        url: h.url,
        cMapUrl: "https://huggingface.co/datasets/freddyaboulton/bucket/resolve/main/cmaps/",
        cMapPacked: !0
      }).promise, e.set(x, _.numPages, !0), e.set(T, Math.min(Math.max(S.props.starting_page, 1), e.get(x))), p(e.get(T));
    });
  }
  function p(h) {
    _ && _.getPage(h).then((d) => {
      const E = C.getContext("2d");
      E.clearRect(0, 0, C.width, C.height);
      let k = d.getViewport({ scale: 1 });
      S.props.height && (k = d.getViewport({ scale: S.props.height / k.height }));
      const L = { canvasContext: E, viewport: k };
      C.width = k.width, C.height = k.height, d.render(L);
    });
  }
  function F() {
    e.get(T) >= e.get(x) || e.update(T);
  }
  function r() {
    e.get(T) != 1 && e.update(T, -1);
  }
  function w() {
    e.get(T) < 1 || e.get(T) > e.get(x);
  }
  function t(h) {
    return (Math.log10((h ^ h >> 31) - (h >> 31)) | 0) + 1;
  }
  let i = e.derived(() => S.props.value);
  e.user_effect(() => {
    JSON.stringify(e.get(v)) != JSON.stringify(e.get(i)) && (e.get(i) && f(e.get(i)), e.set(v, e.get(i), !0), S.dispatch("change"));
  }), Ts(V, {
    get visible() {
      return S.shared.visible;
    },
    get elem_id() {
      return S.shared.elem_id;
    },
    get elem_classes() {
      return S.shared.elem_classes;
    },
    get container() {
      return S.shared.container;
    },
    get scale() {
      return S.shared.scale;
    },
    get min_width() {
      return S.shared.min_width;
    },
    children: (h, d) => {
      var E = pn(), k = e.first_child(E);
      {
        var L = (Z) => {
          Ji(Z, e.spread_props(
            {
              get autoscroll() {
                return S.shared.autoscroll;
              },
              get i18n() {
                return S.i18n;
              }
            },
            () => S.shared.loading_status,
            {
              show_validation_error: !1,
              on_clear_status: () => S.dispatch("clear_status", S.shared.loading_status)
            }
          ));
        };
        e.if(k, (Z) => {
          S.shared.loading_status && Z(L);
        });
      }
      var M = e.sibling(k, 2);
      {
        let Z = e.derived(() => S.shared.label !== null), K = e.derived(() => S.props.value === null), Y = e.derived(() => S.shared.label || "File");
        Ci(M, {
          get show_label() {
            return e.get(Z);
          },
          get Icon() {
            return ke;
          },
          get float() {
            return e.get(K);
          },
          get label() {
            return e.get(Y);
          }
        });
      }
      var B = e.sibling(M, 2);
      {
        var U = (Z) => {
          var K = fn(), Y = e.first_child(K);
          hn(Y, {
            get i18n() {
              return S.i18n;
            },
            $$events: { clear: A }
          });
          var G = e.sibling(Y, 2), j = e.child(G);
          e.bind_this(j, (lt) => C = lt, () => C), e.reset(G);
          var Q = e.sibling(G, 2), J = e.child(Q);
          $e(J, {
            $$events: { click: r },
            children: (lt, ot) => {
              e.next();
              var et = e.text("⬅️");
              e.append(lt, et);
            },
            $$slots: { default: !0 }
          });
          var tt = e.sibling(J, 2), rt = e.child(tt);
          e.remove_input_defaults(rt), e.set_attribute(rt, "min", 1);
          var ut = e.sibling(rt, 4), dt = e.child(ut, !0);
          e.reset(ut), e.reset(tt);
          var ft = e.sibling(tt, 2);
          $e(ft, {
            $$events: { click: F },
            children: (lt, ot) => {
              e.next();
              var et = e.text("➡️");
              e.append(lt, et);
            },
            $$slots: { default: !0 }
          }), e.reset(Q), e.template_effect(
            (lt) => {
              e.set_style(rt, lt), e.set_attribute(rt, "max", e.get(x)), e.set_text(dt, e.get(x));
            },
            [() => `width: ${50 + t(e.get(x)) * 10}px`]
          ), e.bind_value(rt, () => e.get(T), (lt) => e.set(T, lt)), e.event("change", rt, w), e.append(Z, K);
        }, q = (Z) => {
          var K = e.comment(), Y = e.first_child(K);
          {
            var G = (Q) => {
              {
                let J = e.derived(() => S.shared.client?.stream);
                on(Q, {
                  filetype: ".pdf",
                  file_count: "single",
                  get max_file_size() {
                    return S.shared.max_file_size;
                  },
                  upload: (...tt) => S.shared.client.upload(...tt),
                  get stream_handler() {
                    return e.get(J);
                  },
                  get root() {
                    return S.shared.root;
                  },
                  $$events: {
                    load: n,
                    error: ({ detail: tt }) => {
                      loading_status = loading_status || {}, loading_status.status = "error", S.dispatch("error", tt);
                    }
                  },
                  children: (tt, rt) => {
                    ws(tt, {});
                  },
                  $$slots: { default: !0 }
                });
              }
            }, j = (Q) => {
              Ri(Q, {
                unpadded_box: !0,
                size: "large",
                children: (J, tt) => {
                  ke(J);
                },
                $$slots: { default: !0 }
              });
            };
            e.if(
              Y,
              (Q) => {
                S.shared.interactive ? Q(G) : Q(j, !1);
              },
              !0
            );
          }
          e.append(Z, K);
        };
        e.if(B, (Z) => {
          e.get(i) ? Z(U) : Z(q, !1);
        });
      }
      e.append(h, E);
    },
    $$slots: { default: !0 }
  }), e.pop();
}
export {
  yn as default
};
