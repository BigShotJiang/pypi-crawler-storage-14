"""
Core functionality modules for YTSage.

This package contains the core business logic and utility functions.
"""
