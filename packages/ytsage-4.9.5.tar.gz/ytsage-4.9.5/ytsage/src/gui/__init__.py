"""
GUI modules for YTSage.

This package contains all user interface components and related functionality.
"""
