def init_reader(reader):
    pass
