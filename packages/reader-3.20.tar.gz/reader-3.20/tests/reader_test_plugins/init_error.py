def init_reader(reader):
    raise ValueError('someerror')
