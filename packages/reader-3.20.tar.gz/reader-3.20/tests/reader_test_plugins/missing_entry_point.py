# no init_reader() here
