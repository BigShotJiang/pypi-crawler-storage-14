from datetime import datetime

import pytest

from fakeparser import Parser


# Nothing here (yet).
