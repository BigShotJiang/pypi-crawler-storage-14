"""Internal token bucket logic with obfuscation."""

import time as _t
from typing import Tuple as _T, Dict as _D

# Obfuscated constants
_SEC_PER_MIN = 60.0
_CLEANUP_INT = 300
_IDLE_TIMEOUT = 600


def _calc_rate(_rpm: int) -> float:
    """Calculate tokens per second from requests per minute."""
    return _rpm / _SEC_PER_MIN


def _refill_tokens(_cur: float, _max: float, _elapsed: float, _rate: float) -> float:
    """Calculate refilled token count."""
    _new = _cur + (_elapsed * _rate)
    return min(_new, _max)


def _should_cleanup(_last_clean: float, _now: float) -> bool:
    """Check if cleanup should run."""
    return (_now - _last_clean) > _CLEANUP_INT


def _is_bucket_stale(_last_upd: float, _now: float) -> bool:
    """Check if bucket is idle and should be removed."""
    return (_now - _last_upd) > _IDLE_TIMEOUT


class _BucketState:
    """Encapsulates bucket state for a single user."""
    
    __slots__ = ('_tkns', '_time')
    
    def __init__(self, _burst: float):
        self._tkns = _burst
        self._time = _t.time()
    
    def get_state(self) -> _T[float, float]:
        """Get current state."""
        return (self._tkns, self._time)
    
    def update_state(self, _tkns: float, _time: float):
        """Update state."""
        self._tkns = _tkns
        self._time = _time


def _process_request(
    _state: _BucketState,
    _rate: float,
    _burst: float,
    _now: float
) -> _T[bool, float]:
    """
    Process rate limit request.
    
    Returns: (allowed, tokens_remaining)
    """
    _tkns, _last = _state.get_state()
    
    # Refill tokens
    _elapsed = _now - _last
    _tkns = _refill_tokens(_tkns, _burst, _elapsed, _rate)
    
    # Check if allowed
    if _tkns >= 1.0:
        _tkns -= 1.0
        _state.update_state(_tkns, _now)
        return (True, _tkns)
    else:
        _state.update_state(_tkns, _now)
        return (False, _tkns)


def _calc_retry_after(_deficit: float, _rate: float) -> int:
    """Calculate seconds until retry allowed."""
    return int(_deficit / _rate)