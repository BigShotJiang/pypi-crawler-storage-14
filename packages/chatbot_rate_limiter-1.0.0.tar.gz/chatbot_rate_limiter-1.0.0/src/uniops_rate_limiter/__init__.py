"""
UniOps Rate Limiter - Token Bucket Rate Limiting

Provides per-user rate limiting with:
- Token bucket algorithm
- Configurable rate and burst
- Automatic cleanup of inactive users
- FastAPI integration

Usage:
    >>> from uniops_rate_limiter import get_rate_limiter, check_rate_limit
    >>> 
    >>> # Get limiter instance
    >>> limiter = get_rate_limiter()
    >>> 
    >>> # Check if request allowed
    >>> allowed, info = limiter.allow_request('user@example.com')
    >>> 
    >>> # In FastAPI endpoint (async)
    >>> await check_rate_limit('user@example.com')
"""

from uniops_rate_limiter.limiter import (
    TokenBucketRateLimiter,
    get_rate_limiter,
    check_rate_limit,
    get_user_rate_limit_status
)

__version__ = "1.0.0"
__all__ = [
    "TokenBucketRateLimiter",
    "get_rate_limiter",
    "check_rate_limit",
    "get_user_rate_limit_status",
]