"""Token Bucket Rate Limiter - maintains exact same interface."""

import os as _os
import time
from collections import defaultdict
from typing import Dict, Tuple, Optional
from fastapi import HTTPException
from datetime import datetime

from uniops_rate_limiter import _bucket


class TokenBucketRateLimiter:
    """
    Token bucket rate limiter with per-user tracking.
    
    Implements the token bucket algorithm for rate limiting with:
    - Configurable request rate (per minute)
    - Configurable burst capacity
    - Automatic cleanup of inactive users
    - Per-user state tracking
    
    Environment Variables:
        RATE_LIMIT_REQUESTS_PER_MINUTE: Max requests per minute (default: 20)
        RATE_LIMIT_BURST: Burst capacity (default: 5)
    """
    
    def __init__(
        self,
        requests_per_minute: Optional[int] = None,
        burst: Optional[int] = None
    ):
        # Read from environment if not provided
        if requests_per_minute is None:
            requests_per_minute = int(_os.getenv('RATE_LIMIT_REQUESTS_PER_MINUTE', '20'))
        if burst is None:
            burst = int(_os.getenv('RATE_LIMIT_BURST', '5'))
        
        self.rate = _bucket._calc_rate(requests_per_minute)
        self.burst = burst
        self.buckets: Dict[str, _bucket._BucketState] = {}
        self.cleanup_interval = _bucket._CLEANUP_INT
        self.last_cleanup = time.time()
    
    def _get_tokens(self, user: str) -> _bucket._BucketState:
        """Get or create bucket state for user."""
        if user not in self.buckets:
            self.buckets[user] = _bucket._BucketState(self.burst)
        return self.buckets[user]
    
    def allow_request(self, user: str) -> Tuple[bool, Dict]:
        """
        Check if request is allowed for user.
        
        Args:
            user: User identifier (typically email)
            
        Returns:
            Tuple of (allowed: bool, info: dict)
            - allowed: True if request permitted
            - info: Dictionary with rate limit details
        """
        now = time.time()
        
        # Periodic cleanup
        if _bucket._should_cleanup(self.last_cleanup, now):
            self._cleanup_old_buckets(now)
        
        # Get user state
        _state = self._get_tokens(user)
        
        # Process request
        allowed, tokens_left = _bucket._process_request(
            _state, self.rate, self.burst, now
        )
        
        if allowed:
            return True, {
                "allowed": True,
                "tokens_remaining": int(tokens_left),
                "rate_limit": f"{int(self.rate * 60)} requests/minute",
                "burst": self.burst
            }
        else:
            retry_after = _bucket._calc_retry_after(1.0 - tokens_left, self.rate)
            return False, {
                "allowed": False,
                "retry_after": retry_after,
                "tokens_remaining": 0,
                "rate_limit": f"{int(self.rate * 60)} requests/minute",
                "burst": self.burst
            }
    
    def _cleanup_old_buckets(self, now: float):
        """Remove stale user buckets."""
        old_users = [
            user for user, state in self.buckets.items()
            if _bucket._is_bucket_stale(state.get_state()[1], now)
        ]
        
        for user in old_users:
            del self.buckets[user]
        
        self.last_cleanup = now
    
    def get_user_status(self, user: str) -> Dict:
        """
        Get rate limit status for user.
        
        Args:
            user: User identifier
            
        Returns:
            Dictionary with current status
        """
        now = time.time()
        _state = self._get_tokens(user)
        tokens, last_update = _state.get_state()
        tokens = _bucket._refill_tokens(tokens, self.burst, now - last_update, self.rate)
        
        return {
            "user": user,
            "tokens_remaining": int(tokens),
            "burst_capacity": self.burst,
            "rate": f"{int(self.rate * 60)} requests/minute",
            "next_token_in": int(1.0 / self.rate) if tokens < self.burst else 0
        }


# Module-level singleton
_rate_limiter: Optional[TokenBucketRateLimiter] = None


def get_rate_limiter() -> TokenBucketRateLimiter:
    """
    Get global rate limiter instance.
    
    Creates singleton on first call using environment variables:
    - RATE_LIMIT_REQUESTS_PER_MINUTE
    - RATE_LIMIT_BURST
    
    Returns:
        TokenBucketRateLimiter instance
    """
    global _rate_limiter
    if _rate_limiter is None:
        _rate_limiter = TokenBucketRateLimiter()
    return _rate_limiter


async def check_rate_limit(user_email: str) -> Dict:
    """
    Check rate limit for user (FastAPI async integration).
    
    Raises HTTPException if rate limit exceeded.
    
    Args:
        user_email: User's email address
        
    Returns:
        Rate limit info dictionary
        
    Raises:
        HTTPException: 429 if rate limit exceeded
        
    Environment Variables:
        RATE_LIMIT_ENABLED: Set to 'false' to disable (default: 'true')
    """
    if _os.getenv('RATE_LIMIT_ENABLED', 'true').lower() != 'true':
        return {"rate_limit_enabled": False}
    
    limiter = get_rate_limiter()
    allowed, info = limiter.allow_request(user_email)
    
    if not allowed:
        timestamp = datetime.now().isoformat()
        
        raise HTTPException(
            status_code=429,
            detail={
                "error": "Rate limit exceeded",
                "message": f"Too many requests. Please try again in {info['retry_after']} seconds.",
                "retry_after": info['retry_after'],
                "rate_limit": info['rate_limit'],
                "user": user_email
            },
            headers={"Retry-After": str(info['retry_after'])}
        )
    
    return info


def get_user_rate_limit_status(user_email: str) -> Dict:
    """
    Get rate limit status for user.
    
    Args:
        user_email: User's email address
        
    Returns:
        Status dictionary or {"rate_limit_enabled": False}
        
    Environment Variables:
        RATE_LIMIT_ENABLED: Set to 'false' to disable
    """
    if _os.getenv('RATE_LIMIT_ENABLED', 'true').lower() != 'true':
        return {"rate_limit_enabled": False}
    
    limiter = get_rate_limiter()
    return limiter.get_user_status(user_email)