import setuptools
from pathlib import Path

setuptools.setup(
    name="jspdf",
    version=1.0,
    long_description=Path("README.md").read_text(),
    packages=setuptools.find_namespace_packages(exclude=["tests", "data"])
)

# To generate a distribution package, enter this:
# Will generate a source distribution and a build distribution.
# python3 setup.py sdist bdist_wheel
