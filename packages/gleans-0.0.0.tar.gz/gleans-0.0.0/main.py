from pathlib import Path
import sys

# Allow running the module directly from the repository without installation.
sys.path.insert(0, str(Path(__file__).parent / "src"))

def main() -> None:
    print("gleans")


if __name__ == "__main__":
    main()
