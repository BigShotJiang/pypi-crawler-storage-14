## gleans Python package

Version `0.0.0` is a placeholder release to reserve the `gleans` name on PyPI. Running the module simply prints `gleans`.

### Usage

Install locally in editable mode, then invoke the module:

```bash
python -m pip install -e .
python -m gleans
# prints: gleans
```

### Releasing 0.0.0 to PyPI

1. Make sure Python 3.12+ is active (see `.python-version`).
2. Build the wheel and source distribution:
   ```bash
   python -m pip install --upgrade build twine
   python -m build
   ```
3. Publish with your PyPI token:
   ```bash
   twine upload --non-interactive -u __token__ -p "$PYPI_TOKEN" dist/*
   ```
