"""
Placeholder package for the initial 0.0.0 release of gleans.
"""

__version__ = "0.0.0"

__all__ = ["__version__"]
