from . import __version__


def main() -> None:
    """Entry point for `python -m gleans`."""
    print("gleans")


if __name__ == "__main__":
    main()
