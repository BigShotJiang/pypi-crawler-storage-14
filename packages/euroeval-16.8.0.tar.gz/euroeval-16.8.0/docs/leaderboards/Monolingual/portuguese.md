---
hide:
    - toc
---
# 🇵🇹 Portuguese

See the [leaderboard page](/leaderboards) for more information about all the columns.

/// tab | Generative Leaderboard
<iframe title="" aria-label="Table" id="datawrapper-chart-HYjMK" src="https://datawrapper.dwcdn.net/HYjMK" scrolling="no" frameborder="0" style="width: 0; min-width: 100% !important; border: none;" height="678" data-external="1"></iframe><script type="text/javascript">!function(){"use strict";window.addEventListener("message",function(a){if(void 0!==a.data["datawrapper-height"]){var e=document.querySelectorAll("iframe");for(var t in a.data["datawrapper-height"])for(var r,i=0;r=e[i];i++)if(r.contentWindow===a.source){var d=a.data["datawrapper-height"][t]+"px";r.style.height=d}}})}();</script>
///

/// tab | NLU Leaderboard
<iframe title="" aria-label="Table" id="datawrapper-chart-IImPW" src="https://datawrapper.dwcdn.net/IImPW" scrolling="no" frameborder="0" style="width: 0; min-width: 100% !important; border: none;" height="678" data-external="1"></iframe><script type="text/javascript">!function(){"use strict";window.addEventListener("message",function(a){if(void 0!==a.data["datawrapper-height"]){var e=document.querySelectorAll("iframe");for(var t in a.data["datawrapper-height"])for(var r,i=0;r=e[i];i++)if(r.contentWindow===a.source){var d=a.data["datawrapper-height"][t]+"px";r.style.height=d}}})}();</script>
///

/// tab | Generative Scatter Plot
<iframe title="Performance of Generative Language Models on Portuguese Tasks by Model Size" aria-label="Scatter Plot" id="datawrapper-chart-mod5H" src="https://datawrapper.dwcdn.net/mod5H" scrolling="no" frameborder="0" style="width: 0; min-width: 100% !important; border: none;" height="687" data-external="1"></iframe><script type="text/javascript">!function(){"use strict";window.addEventListener("message",function(a){if(void 0!==a.data["datawrapper-height"]){var e=document.querySelectorAll("iframe");for(var t in a.data["datawrapper-height"])for(var r,i=0;r=e[i];i++)if(r.contentWindow===a.source){var d=a.data["datawrapper-height"][t]+"px";r.style.height=d}}})}();</script>
///

/// tab | NLU Scatter Plot
<iframe title="Performance of Language Models on Portuguese NLU Tasks by Model Size" aria-label="Scatter Plot" id="datawrapper-chart-i1JYz" src="https://datawrapper.dwcdn.net/i1JYz" scrolling="no" frameborder="0" style="width: 0; min-width: 100% !important; border: none;" height="687" data-external="1"></iframe><script type="text/javascript">!function(){"use strict";window.addEventListener("message",function(a){if(void 0!==a.data["datawrapper-height"]){var e=document.querySelectorAll("iframe");for(var t in a.data["datawrapper-height"])for(var r,i=0;r=e[i];i++)if(r.contentWindow===a.source){var d=a.data["datawrapper-height"][t]+"px";r.style.height=d}}})}();</script>
///

<!-- This disables the requirement that all lines must be shorter than 88 characters -->
<!-- markdownlint-configure-file { "MD013": false } -->
