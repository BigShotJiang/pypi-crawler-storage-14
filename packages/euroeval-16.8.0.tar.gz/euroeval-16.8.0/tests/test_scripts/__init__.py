"""Tests for scripts."""
