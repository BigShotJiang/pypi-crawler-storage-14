from setuptools import setup, find_packages

setup(
    name='smartinventory-lib',
    version='0.1.0',
    description='SmartInventory360 Library - AWS Integration & Utilities',
    author='Your Name',
    author_email='your.email@example.com',
    url='https://github.com/yourusername/smartinventory-lib',
    packages=find_packages(),
    install_requires=[
        'boto3>=1.26.0',
        'django>=4.2.0',
    ],
    classifiers=[
        'Programming Language :: Python :: 3',
        'Programming Language :: Python :: 3.9',
    ],
)
