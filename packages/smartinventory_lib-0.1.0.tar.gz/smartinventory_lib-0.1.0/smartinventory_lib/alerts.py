from django.db import models

class AlertManager:
    @staticmethod
    def check_and_create_alert(product):
        """Check if product needs alert"""
        from inventory.models import Alert
        
        Alert.objects.filter(product=product, is_resolved=False).delete()
        
        if product.stock_quantity <= product.low_stock_threshold:
            Alert.objects.create(
                product=product,
                alert_type='LOW_STOCK',
                message=f'{product.name} stock is low ({product.stock_quantity} units)',
                is_resolved=False
            )
        return True

__all__ = ['AlertManager']
