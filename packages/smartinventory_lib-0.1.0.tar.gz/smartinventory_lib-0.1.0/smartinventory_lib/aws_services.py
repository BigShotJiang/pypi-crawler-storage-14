import boto3
import json

class AWSServices:
    def __init__(self):
        self.dynamodb = boto3.resource('dynamodb')
        self.s3_client = boto3.client('s3')
        self.lambda_client = boto3.client('lambda')
        self.sns_client = boto3.client('sns')
    
    def sync_to_dynamodb(self, table_name, data):
        """Sync data to DynamoDB"""
        try:
            table = self.dynamodb.Table(table_name)
            table.put_item(Item=data)
            return {'success': True}
        except Exception as e:
            return {'success': False, 'error': str(e)}
    
    def upload_to_s3(self, file, key):
        """Upload file to S3"""
        try:
            bucket = 'smartinventory360'
            self.s3_client.upload_fileobj(file, bucket, key)
            url = f"https://{bucket}.s3.amazonaws.com/{key}"
            return url
        except Exception as e:
            return None
    
    def trigger_lambda_stock_monitor(self):
        """Trigger Lambda function"""
        try:
            response = self.lambda_client.invoke(
                FunctionName='StockMonitor',
                InvocationType='Event'
            )
            return {'success': True, 'message': 'Lambda triggered'}
        except Exception as e:
            return {'success': False, 'error': str(e)}

__all__ = ['AWSServices']
