def format_currency(amount, currency='€'):
    """Format amount as currency"""
    return f"{currency}{float(amount):.2f}"

def validate_product(product_id, name, price):
    """Validate product data"""
    if not product_id or len(product_id) < 3:
        return False, "Product ID must be at least 3 characters"
    if not name or len(name) < 2:
        return False, "Product name must be at least 2 characters"
    if not price or price <= 0:
        return False, "Price must be greater than 0"
    return True, "Valid"

__all__ = ['format_currency', 'validate_product']
