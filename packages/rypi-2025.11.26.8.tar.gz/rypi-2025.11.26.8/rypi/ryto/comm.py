#!/usr/bin/env python
'''
锐通的常用/共用函数(Common Function)，模块调用或命令行调用均可。
'''

VER = r'''
comm version: 2025.8.1.1.0
'''

COPR = r'''
版权所有 2025 梁业敏(字: 锐白) 保留所有权利。本软件采用 锐码署名传播许可证(RSPL) 授权。详情请见 LICENSE 或 LICENSE-EN 文件。| 网站: rymaa.cn | 邮箱: rybby@163.com
'''

INFO = r'''
锐通的常用/共用函数(Common Function)。
可通过模块调用，也可通过命令行调用。
包含一些实用函数
'''

HELP = r'''
+-------------------------------------------+
|           RyTo Common Functions           |
+-------------------------------------------+
|            HomePage: rymaa.cn             |
+-------------------------------------------+

Usage:
    rypi ryto comm [option]

Options:
    -H, --help   Show help / 显示帮助
    -I, --info   Show info / 显示信息
    -C, --copr   Show copyright / 显示版权
    -V, --version   Show version / 显示版本
    -h, --func_help   Show function help / 显示指定函数的帮助信息
    -f, --func   Show all function / 显示所有函数
    -r, --run   run function / 运行指定的函数
    -p, --para   function parameter / 运行函数的参数列表，多参数需要加引号
'''

##############################

import os
import sys
import argparse
import importlib
import importlib.util
from pathlib import Path
import inspect
import shlex
import subprocess

##############################

def load(mname):
    '''
    载入指定名称的模块。
    返回: void
    参数列表：
        mname (str): 模块名（不含后缀，可以与包名组合）
    '''

    mod = importlib.import_module(mname)
    return mod

def loadp(path):
    '''
    载入指定路径的模块。
    返回: void
    参数列表：
        path (str): 模块路径（包含后缀）
    '''

    name = path.replace('/', '_').replace('.', '_')
    spec = importlib.util.spec_from_file_location(name, path)
    mod = importlib.util.module_from_spec(spec)
    sys.modules[name] = mod
    spec.loader.exec_module(mod)
    return mod

def get_functions(mod):
    '''
    获取模块中所有函数名（排除 _ 开头的私有函数）。
    返回: 函数元组列表[(func_name, func_desc)]
    参数列表：
        mod (str): 模块（module name）
    '''

    no_func = ['main', 'load', 'loadp', 'get_modules', 'get_functions', 'parse_args', 'run_mod']
    func = [
        (name, (inspect.getdoc(obj) or '无描述').split('\n')[0].strip()) for name, obj in inspect.getmembers(mod, inspect.isfunction)
        if not name.startswith('_') or name not in no_func
    ]
    return func

def parse_args(args):
    '''
    解析如 "arg1 arg2 'with space' --flag" 的字符串
    返回: 列表[str]
    参数列表：
        args (str): 参数列表（args string）
    '''

    res = {}
    args = args.strip()
    if not args:
        return res
    
    if '=' not in args:
        return shlex.split(args)
    
    # 使用 shlex 分词，支持引号
    lexer = shlex.shlex(args, posix=True)
    lexer.whitespace_split = True
    tokens = list(lexer)
    
    for tk in tokens:
        if '=' not in tk:
            raise ValueError(f"无效的键值对: {tk}")
        key, value = tk.split('=', 1)
        res[key] = value
    
    return res

def apt(path="/etc/apt/sources.list"):
    '''
    为 apt 包管理器配置多个国内源与官方源。
    
    该函数会生成包含清华、阿里云、中科大等国内镜像源以及 Ubuntu 官方源的完整 sources.list 内容，
    并将其写入指定路径的文件中（默认为 /etc/apt/sources.list）。
    
    参数列表：
        path (str): 目标 sources.list 文件的完整路径，默认为 "/etc/apt/sources.list"
    '''

    # 确保目录存在
    path = os.path.expanduser(path)
    os.makedirs(os.path.dirname(path), exist_ok=True)

    ctt = '''
# 清华镜像 (主源)
deb https://mirrors.tuna.tsinghua.edu.cn/ubuntu/ jammy main restricted universe multiverse
deb-src https://mirrors.tuna.tsinghua.edu.cn/ubuntu/ jammy main restricted universe multiverse

# 阿里云镜像 (备用源1)
deb https://mirrors.aliyun.com/ubuntu/ jammy main restricted universe multiverse
deb-src https://mirrors.aliyun.com/ubuntu/ jammy main restricted universe multiverse

# 中科大镜像 (备用源2)
deb https://mirrors.ustc.edu.cn/ubuntu/ jammy main restricted universe multiverse
deb-src https://mirrors.ustc.edu.cn/ubuntu/ jammy main restricted universe multiverse

# 官方源 (最终备用)
deb http://archive.ubuntu.com/ubuntu/ jammy main restricted universe multiverse
deb-src http://archive.ubuntu.com/ubuntu/ jammy main restricted universe multiverse

# 安全更新
deb https://mirrors.aliyun.com/ubuntu/ jammy-security main restricted universe multiverse
deb https://mirrors.tuna.tsinghua.edu.cn/ubuntu/ jammy-security main restricted universe multiverse
deb http://security.ubuntu.com/ubuntu/ jammy-security main restricted universe multiverse

# 软件更新
deb https://mirrors.aliyun.com/ubuntu/ jammy-updates main restricted universe multiverse
deb https://mirrors.tuna.tsinghua.edu.cn/ubuntu/ jammy-updates main restricted universe multiverse
deb http://archive.ubuntu.com/ubuntu/ jammy-updates main restricted universe multiverse

# 预发布软件
deb https://mirrors.aliyun.com/ubuntu/ jammy-proposed main restricted universe multiverse
deb http://archive.ubuntu.com/ubuntu/ jammy-proposed main restricted universe multiverse

# 向后兼容
deb https://mirrors.aliyun.com/ubuntu/ jammy-backports main restricted universe multiverse
deb http://archive.ubuntu.com/ubuntu/ jammy-backports main restricted universe multiverse
'''
    with open(path, 'w', encoding='utf-8') as f:
        f.write(ctt.strip() + '\n')

def pip(path=None):
    '''
    为 pip 包管理器配置多个国内源与官方源。

    该函数生成包含清华源（主源）、腾讯云源和 PyPI 官方源的 pip 配置内容，
    并写入指定的配置文件路径。若未指定路径，则根据操作系统自动选择默认位置：
    - Linux / macOS: ~/.pip/pip.conf
    - Windows: %APPDATA%\pip\pip.ini

    参数列表：
        path (str or None): pip 配置文件的完整路径。若为 None，则使用系统默认路径。
    '''
    
    # 自动确定默认配置路径
    if path is None:
        if os.name == 'nt':  # Windows
            path = os.path.join(os.environ.get('APPDATA', ''), 'pip', 'pip.ini')
        else:  # Linux / macOS
            path = '~/.pip/pip.conf'

    # 确保目录存在
    path = os.path.expanduser(path)
    os.makedirs(os.path.dirname(path), exist_ok=True)

    ctt = '''
[global]
# 主镜像源 - 清华源
index-url = https://pypi.tuna.tsinghua.edu.cn/simple/

# 备用镜像源: 腾讯源, 官方源
extra-index-url =
    https://mirrors.cloud.tencent.com/pypi/simple/
    https://pypi.org/simple/

trusted-host =
    pypi.tuna.tsinghua.edu.cn
    mirrors.cloud.tencent.com
    pypi.org

timeout = 60
retries = 10
'''

    with open(path, 'w', encoding='utf-8') as f:
        f.write(ctt.strip() + '\n')

def conda(path=None):
    '''
    禁用 Conda 的自动激活 base 环境。

    该函数生成或更新 Conda 的配置文件（.condarc），设置 auto_activate_base 为 false，
    并保留常用的 channels 配置（conda-forge 和 defaults）。
    若未指定配置文件路径，则使用当前用户的默认 Conda 配置路径（~/.condarc）。

    参数列表：
        path (str or None): Conda 配置文件路径。若为 None，则默认为 ~/.condarc。
    '''
    
    if path is None:
        path = '~/.condarc'

    # 确保目录存在
    path = os.path.expanduser(path)
    os.makedirs(os.path.dirname(path), exist_ok=True)

    ctt = '''
channels:
  - conda-forge
  - defaults
auto_activate_base: false
'''

    with open(path, 'w', encoding='utf-8') as f:
        f.write(ctt.strip() + '\n')

def nano(path=None):
    '''
    为 nano 启用鼠标支持。

    默认情况下，nano 编辑器不支持鼠标点击定位光标。它是一个纯键盘操作的终端文本编辑器。
    不过，新版本的 nano（2.0.0+）支持有限的鼠标功能，但需要手动启用。
    写入指定内容到配置文件。若未指定路径，则根据操作系统自动选择默认位置：
    - Linux / macOS: ~/.nanorc

    参数列表：
        path (str or None): nano 配置文件的完整路径。若为 None，则使用系统默认路径。
    '''
    
    # 自动确定默认配置路径
    if path is None:
        path = '~/.nanorc'

    # 确保目录存在
    path = os.path.expanduser(path)
    os.makedirs(os.path.dirname(path), exist_ok=True)

    ctt = '''
set mouse
'''

    with open(path, 'w', encoding='utf-8') as f:
        f.write(ctt.strip() + '\n')

def pkgpip(pkgname=None):
    '''
    为 pip 源码进行打包并上传到官方源仓库与安装。

    参数列表：
        pkgname (str or None): pip 程序包名称，安装时代入。
    
    该函数自动完成以下操作流程

    1. 删除旧资源
    rm -rf dist/ build/ *.egg-info/
    或者
    rd /s /q dist
    rd /s /q build
    rd /s /q rypi.egg-info

    2. 构建
    python3 -m build

    3. 上传
    twine upload dist/*
    或者
    python3 -m twine upload dist/*

    4. 安装
    pip install --upgrade rypi -i https://pypi.org/simple

    PS: 上传过程可能需要进行双重验证，到 pypi 官网获取自己的 双重验证密钥，然后用 rypi ryto tfa 双重验证密钥 命令生成自己的 双重验证码 进行验证即可。操作时需要进入自己的项目根目录（通常是包名称）的上级目录，比如锐派的包名目录是 rypi，它的上级目录是 pjt_rypi，打包时就是在工程目录 pjt_rypi 下进行操作，rypi 目录下有各种模块和子模块。生产环境使用 pip install rypi 进行安装，开发环境使用 pip install -e . 进行安装。
    '''

    def _run_cmd(cmd):
        res = subprocess.run(cmd, shell=True, text=True, check=False, timeout=60, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        return res
    
    print('\n删除旧资源...')
    if os.name == 'nt':
        _run_cmd('rd /s /q dist')
        _run_cmd('rd /s /q build')
        _run_cmd(f'rd /s /q {pkgname}.egg-info')
    else:
        _run_cmd('rm -rf dist/ build/ *.egg-info/')
    
    print('\n构建...')
    _run_cmd('python -m build')
    
    print('\n上传...')
    _run_cmd('twine upload dist/*')
    
    print('\n安装...')
    _run_cmd('pip install --upgrade {pkgname} -i https://pypi.org/simple')
    
def main(args=None):
    '''
    入口主函数。
    返回: void
    参数列表：
        args (str): 参数列表，通过命令行传入或调用者传入。
    '''

    # 全局选项
    parser = argparse.ArgumentParser(add_help=False)
    parser.add_argument('-H', '--help', action='store_true')
    parser.add_argument('-I', '--info', action='store_true')
    parser.add_argument('-C', '--copr', action='store_true')
    parser.add_argument('-V', '--version', action='store_true')
    parser.add_argument('-f', '--func', action='store_true')
    parser.add_argument('-h', '--func_help', default='')
    parser.add_argument('-r', '--run')
    parser.add_argument('-p', '--para', default='')

    args = parser.parse_args(args)
    
    if args.version:
        print(VER)
    elif args.copr:
        print(COPR)
    elif args.info:
        print(INFO)
    elif args.help:
        print(HELP)

    # 显示所有函数
    elif args.func:
        # mod = load(f"{__package__}.{mname}")
        mod = sys.modules[__name__]
        funcs = get_functions(mod)
        print(f'\n可以在参数(-h)后加函数名称查看该函数的帮助信息，如：rypi comm -h b64。')
        print(f'\n运行函数时输入的参数值可使用列表或字典两种模式，如：')
        print(f'\n列表模式：rypi comm -r sha -p "abcdef 2"')
        print(f'\n字典模式：rypi comm -r sha -p "data=abcdef type=2"')
        print(f'\n如果参数值有空格需要加引号，如：')
        print(f'\n列表模式：rypi comm -r sha -p "\'abc def\' 3"')
        print(f'\n字典模式：rypi comm -r sha -p "data=\'abc def\' type=3"')
        print(f'\nfunction list:')
        for name, desc in funcs:
            print(f'\n    {name}: {desc}')

    # 显示指定函数的帮助信息
    elif args.func_help:
        # mod = sys.modules[__name__]
        # func = getattr(mod, args.func_help, None)
        func = globals().get(args.func_help)
        if not func or not inspect.isfunction(func):
            print(f'函数 {args.run} 不存在或不是函数')
            return
        doc = inspect.getdoc(func) or '无描述'
        print(f'\n{doc}')

    # 运行指定函数
    elif args.run:
        # mod = sys.modules[__name__]
        # func = getattr(mod, args.run, None)
        func = globals().get(args.run)
        if not func or not inspect.isfunction(func):
            print(f'函数 {args.run} 不存在或不是函数')
            return

        # 解析参数
        plist = parse_args(args.para)
        print(f'\n运行: {args.run}({plist})')
        if isinstance(plist, list):
            res = func(*plist)
        elif isinstance(plist, dict):
            res = func(**plist)
        else:
            raise TypeError(f"不支持的参数类型: {type(plist)}")
        print(f'\n运行结果: {res}')

    # 显示帮助
    else:
        print(HELP)

if __name__ == '__main__':
    main()