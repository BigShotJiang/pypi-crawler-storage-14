import jgo

if __name__ == "__main__":
    jgo.main()
