Welcome to synrfp documentation!
=================================
This is documentation for synrfp version |version| (release |release|).

.. toctree::
   :caption: Contents
   :maxdepth: 2

   Getting Started <getting_started>
   Tutorials and Examples <tutorials_and_examples>
   API Reference <api>
   References <reference>
