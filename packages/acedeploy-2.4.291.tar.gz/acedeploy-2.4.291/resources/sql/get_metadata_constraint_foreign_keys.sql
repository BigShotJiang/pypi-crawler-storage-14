SHOW IMPORTED KEYS IN SCHEMA "{database_name}"."{schema_name}"; -- this command does not work if database is not given
