SHOW STREAMS IN SCHEMA "{schema_name}";
