SHOW STAGES IN SCHEMA {schema_name};
