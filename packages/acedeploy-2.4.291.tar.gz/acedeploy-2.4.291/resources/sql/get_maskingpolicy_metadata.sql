DESCRIBE MASKING POLICY "{schema_name}"."{policy_name}";
