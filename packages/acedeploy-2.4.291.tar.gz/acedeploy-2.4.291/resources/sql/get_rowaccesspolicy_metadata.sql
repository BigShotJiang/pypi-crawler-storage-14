DESCRIBE ROW ACCESS POLICY "{schema_name}"."{policy_name}";
