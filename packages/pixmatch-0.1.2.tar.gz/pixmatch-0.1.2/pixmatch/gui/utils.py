from PySide6 import QtCore, QtWidgets

NO_MARGIN = QtCore.QMargins(0, 0, 0, 0)

MAX_SIZE_POLICY = QtWidgets.QSizePolicy(QtWidgets.QSizePolicy.Policy.Expanding,
                                        QtWidgets.QSizePolicy.Policy.Expanding)
