#!/usr/bin/env python3
from sys import stdin
import sys

# There shouldn't be any input
assert len(stdin.readline()) == 0

sys.exit(42)
