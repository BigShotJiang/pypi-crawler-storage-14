#!/usr/bin/env python3
N = int(input())
for i in range(N):
    x = input()
    if i % 2 == 0: print(x)
