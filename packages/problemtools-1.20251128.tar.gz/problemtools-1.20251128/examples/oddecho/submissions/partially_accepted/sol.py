#!/usr/bin/env python3
input()
A = input()
B = input()
C = input()
D = input()
E = input()
print(A)
print(C)
print(E)

