#!/usr/bin/env python3

print("500")
