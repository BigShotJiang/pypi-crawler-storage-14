import java.io.*;
import java.util.*;

public class GuessCrash {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("500");
		String myString = sc.next();
		System.out.println("-1");
		myString = sc.next();
	}
}
