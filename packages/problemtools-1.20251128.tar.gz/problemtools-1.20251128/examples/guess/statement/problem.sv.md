Jag tänker på ett hemligt tal mellan $1$ and $100$, kan du gissa vilket?
Givet en gissning kommer jag att berätta om din gissning 
var för stor, för liten eller rätt. Du får bara $10$ gissningar, använd 
dem klokt!


# Interaktion
Ditt program ska skriva ut gissningar om talet.
En gissning är en rad som enbart innehåller ett heltal mellan $1$ och $1000$.
Efter varje gissning måste du flusha standard out.

Efter varje gissning kan du läs svaret på standard in.
Detta svar är ett av tre ord:

- `lower` om talet jag tänker på är lägre än din gissning,
- `higher` om talet jag tänker på är högre än din gissning, eller
- `correct` om din gissning är korrekt.

Efter att ha gissat rätt ska du avsluta ditt program.
Om du gissar fel $10$ gånger får du inga fler chanser och ditt program kommer avbrytas.
