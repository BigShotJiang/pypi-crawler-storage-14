from plasTeX.Base.LaTeX.FontSelection import TextCommand


class uline(TextCommand):
    pass


class uuline(TextCommand):
    pass


class uwave(TextCommand):
    pass


class sout(TextCommand):
    pass


class xout(TextCommand):
    pass


class dashuline(TextCommand):
    pass


class dotuline(TextCommand):
    pass
