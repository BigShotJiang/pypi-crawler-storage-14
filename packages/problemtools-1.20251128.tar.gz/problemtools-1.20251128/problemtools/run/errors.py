"""
Error handling.
"""


class ProgramError(Exception):
    """Base exception class for errors within the run package."""

    pass
