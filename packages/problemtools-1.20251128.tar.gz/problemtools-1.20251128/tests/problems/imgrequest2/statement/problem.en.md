Make web request via image

<img src="https:open.kattis.com/images/site/header/logo-empty.png">
