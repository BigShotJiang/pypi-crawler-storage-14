XSS injection via problem name.
