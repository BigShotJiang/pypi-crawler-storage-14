Make web request via image

![Alt text](http:picsum.photos/400)
