All printable ASCII characters in sample
