#!/usr/bin/env bash

dir=`dirname $0`
exec java -jar $dir/viva.jar $*
