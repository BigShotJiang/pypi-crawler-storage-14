def c_to_k(celsius):
    """Convert Celsius to Kelvin."""
    return celsius + 273.15


def k_to_c(kelvin):
    """Convert Kelvin to Celsius."""
    return kelvin - 273.15
