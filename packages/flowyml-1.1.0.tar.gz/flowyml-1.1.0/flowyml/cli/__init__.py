"""CLI module for flowyml."""

from flowyml.cli.main import cli

__all__ = ["cli"]
