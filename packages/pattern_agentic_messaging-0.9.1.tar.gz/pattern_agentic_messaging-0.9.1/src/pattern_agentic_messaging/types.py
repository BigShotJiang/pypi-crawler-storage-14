from typing import Union

MessagePayload = Union[bytes, str, dict]
