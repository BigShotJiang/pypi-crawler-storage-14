from .constants import *
from .time_utils import swe_julday, swe_revjul, swe_deltat
from .planets import (
    swe_calc_ut,
    swe_calc,
    swe_get_ayanamsa_ut,
    swe_get_ayanamsa,
    swe_set_sid_mode,
)
from .houses import swe_houses, swe_houses_ex, swe_house_name
from .state import set_topo as swe_set_topo, set_ephe_path as swe_set_ephe_path
from .crossing import swe_solcross_ut, swe_mooncross_ut, swe_cross_ut
from .utils import difdeg2n
from .fixed_stars import swe_fixstar_ut

# =============================================================================
# PYSWISSEPH-COMPATIBLE FUNCTION ALIASES (without swe_ prefix)
# =============================================================================
# pyswisseph uses function names without the swe_ prefix
# These aliases provide 100% API compatibility with pyswisseph

# Time functions
julday = swe_julday
revjul = swe_revjul
deltat = swe_deltat

# Planet calculation
calc_ut = swe_calc_ut
calc = swe_calc

# Houses
houses = swe_houses
houses_ex = swe_houses_ex
house_name = swe_house_name

# Ayanamsa (sidereal)
get_ayanamsa_ut = swe_get_ayanamsa_ut
get_ayanamsa = swe_get_ayanamsa
set_sid_mode = swe_set_sid_mode

# Observer location
set_topo = swe_set_topo
set_ephe_path = swe_set_ephe_path

# Fixed Stars
fixstar_ut = swe_fixstar_ut

# Crossings
solcross_ut = swe_solcross_ut
mooncross_ut = swe_mooncross_ut


# Helper function to pre-calculate positions for Arabic parts
def swe_calc_angles(jd_ut: float, lat: float, lon: float):
    """
    Pre-calculate and cache astrological angles and planet positions
    for use with Arabic parts.

    Args:
        jd_ut: Julian Day (UT)
        lat: Latitude (degrees)
        lon: Longitude (degrees)

    Returns:
        Dictionary with calculated positions
    """
    from .state import set_angles_cache
    from .angles import calc_angles

    # Set observer location
    swe_set_topo(lon, lat, 0)

    # Calculate angles
    angles_dict = calc_angles(jd_ut, lat, lon)
    
    # Calculate and add planet positions for Arabic parts
    from .constants import SE_SUN, SE_MOON, SE_MERCURY, SE_VENUS
    
    sun_pos, _ = swe_calc_ut(jd_ut, SE_SUN, 0)
    moon_pos, _ = swe_calc_ut(jd_ut, SE_MOON, 0)
    mercury_pos, _ = swe_calc_ut(jd_ut, SE_MERCURY, 0)
    venus_pos, _ = swe_calc_ut(jd_ut, SE_VENUS, 0)
    
    angles_dict['Sun'] = sun_pos[0]
    angles_dict['Moon'] = moon_pos[0]
    angles_dict['Mercury'] = mercury_pos[0]
    angles_dict['Venus'] = venus_pos[0]
    
    # Cache for Arabic parts
    set_angles_cache(angles_dict)
    
    return angles_dict

# Helper for Arabic parts
from .arabic_parts import calc_all_arabic_parts

# Constants (planet IDs, flags, sidereal modes)
from .constants import *

__version__ = "0.1.0"
__author__ = "Giacomo Battaglia"
__license__ = "LGPL-3.0"

__all__ = [
    # Time functions (both swe_ and non-prefixed aliases)
    "swe_julday",
    "julday",
    "swe_revjul",
    "revjul",
    "swe_deltat",
    "deltat",
    # Planet calculation
    "swe_calc_ut",
    "calc_ut",
    "swe_calc",
    "calc",
    "swe_get_planet_name",
    # Houses
    "swe_houses",
    "houses",
    "swe_houses_ex",
    "houses_ex",
    "swe_house_pos",
    "swe_house_name",
    # Ayanamsa (sidereal)
    "swe_set_sid_mode",
    "set_sid_mode",
    "swe_get_ayanamsa_ut",
    "get_ayanamsa_ut",
    "swe_get_ayanamsa",
    "get_ayanamsa",
    "swe_get_ayanamsa_name",
    # Observer location
    "swe_set_topo",
    "set_topo",
    "swe_set_ephe_path",
    "set_ephe_path",
    # Crossings
    "swe_solcross_ut",
    "solcross_ut",
    "swe_mooncross_ut",
    "mooncross_ut",
    "swe_cross_ut",
    # Utilities
    "difdeg2n",
    # Helpers
    "calc_all_arabic_parts",
    # Fixed Stars
    "swe_fixstar_ut",
    "fixstar_ut",
]
