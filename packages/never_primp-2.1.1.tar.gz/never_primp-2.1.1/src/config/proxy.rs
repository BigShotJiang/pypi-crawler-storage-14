/// 代理配置
///
/// 支持 HTTP、HTTPS、SOCKS4/5 代理，以及代理认证和排除列表
///
/// # 支持的代理格式
///
/// - `http://proxy:port` - HTTP 代理
/// - `https://proxy:port` - HTTPS 代理（会自动转换为 http://）
/// - `socks5://proxy:port` - SOCKS5 代理
/// - `socks4://proxy:port` - SOCKS4 代理
/// - `http://user:pass@proxy:port` - 带认证的 HTTP 代理
/// - `http://user@proxy:port` - 带用户名的代理（密码为空）
///
/// # 示例
///
/// ```rust
/// use never_primp::config::ProxyConfig;
///
/// // 简单代理
/// let proxy = ProxyConfig {
///     url: Some("socks5://127.0.0.1:1080".to_string()),
///     ..Default::default()
/// };
///
/// // 带认证的代理
/// let proxy = ProxyConfig {
///     url: Some("http://user:pass@proxy.example.com:8080".to_string()),
///     ..Default::default()
/// };
///
/// // 排除某些域名不走代理
/// let proxy = ProxyConfig {
///     url: Some("http://proxy:8080".to_string()),
///     no_proxy: Some("localhost,127.0.0.1,.example.com".to_string()),
///     ..Default::default()
/// };
/// ```
#[derive(Clone, Default, Debug)]
pub struct ProxyConfig {
    /// 代理 URL
    ///
    /// 如果为 None，会尝试从环境变量 `PRIMP_PROXY`、`HTTP_PROXY`、`HTTPS_PROXY` 读取
    pub url: Option<String>,

    /// No Proxy 排除列表
    ///
    /// 逗号分隔的域名列表，这些域名不走代理
    /// 例如: "localhost,127.0.0.1,.example.com"
    ///
    /// 支持：
    /// - 精确匹配: "example.com"
    /// - 子域名匹配: ".example.com" 匹配 "*.example.com"
    /// - IP 地址: "192.168.1.1"
    /// - IP 子网: "192.168.1.0/24"
    /// - 通配符: "*" 匹配所有（不使用代理）
    ///
    /// 如果为 None，会尝试从环境变量 `NO_PROXY` 读取
    pub no_proxy: Option<String>,
}

impl ProxyConfig {
    /// 应用到 wreq ClientBuilder
    ///
    /// 支持的代理格式：
    /// - `http://proxy:port`
    /// - `socks5://proxy:port`
    /// - `http://user:pass@proxy:port`
    /// - `http://user@proxy:port` (支持省略密码)
    ///
    /// # 注意事项
    ///
    /// 1. 为避免 302 重定向时出现 407 错误，同时配置 HTTP 和 HTTPS 代理
    /// 2. `https://` 会自动转换为 `http://`（wreq 限制）
    /// 3. 支持从环境变量读取：`PRIMP_PROXY`, `HTTP_PROXY`, `HTTPS_PROXY`
    /// 4. 支持 No Proxy 排除列表：从 `NO_PROXY` 环境变量或配置读取
    pub fn apply(&self, builder: wreq::ClientBuilder) -> Result<wreq::ClientBuilder, String> {
        // 获取代理 URL（优先使用配置，其次环境变量）
        let proxy_url = self.url.clone().or_else(|| {
            std::env::var("PRIMP_PROXY")
                .or_else(|_| std::env::var("HTTP_PROXY"))
                .or_else(|_| std::env::var("HTTPS_PROXY"))
                .ok()
        });

        if let Some(ref proxy_url) = proxy_url {
            // 将 https:// 替换为 http://（wreq 代理限制）
            let http_proxy = if proxy_url.starts_with("https://") {
                proxy_url.replacen("https://", "http://", 1)
            } else {
                proxy_url.clone()
            };

            // 获取 no_proxy 列表（优先使用配置，其次环境变量）
            let no_proxy = self.no_proxy.clone()
                .or_else(|| std::env::var("NO_PROXY")
                    .or_else(|_| std::env::var("no_proxy"))
                    .ok());

            // 解析 no_proxy
            let no_proxy_obj = no_proxy.and_then(|s| {
                if s.trim().is_empty() {
                    None
                } else {
                    wreq::NoProxy::from_string(&s)
                }
            });

            // 分别配置 HTTP 和 HTTPS 代理，避免 302 跳转时出现 407 错误
            // 这样在协议切换（HTTP ↔ HTTPS）时代理认证信息能正确传递
            let mut http_proxy_obj = wreq::Proxy::http(&http_proxy)
                .map_err(|e| format!("HTTP代理配置无效: {} (代理URL: {})", e, http_proxy))?;
            let mut https_proxy_obj = wreq::Proxy::https(&http_proxy)
                .map_err(|e| format!("HTTPS代理配置无效: {} (代理URL: {})", e, http_proxy))?;

            // 应用 no_proxy
            if let Some(no_proxy_config) = no_proxy_obj {
                http_proxy_obj = http_proxy_obj.no_proxy(Some(no_proxy_config.clone()));
                https_proxy_obj = https_proxy_obj.no_proxy(Some(no_proxy_config));
            }

            Ok(builder.proxy(http_proxy_obj).proxy(https_proxy_obj))
        } else {
            Ok(builder)
        }
    }

    /// 设置代理 URL
    pub fn with_url(mut self, url: impl Into<String>) -> Self {
        self.url = Some(url.into());
        self
    }

    /// 设置 no_proxy 排除列表
    pub fn with_no_proxy(mut self, no_proxy: impl Into<String>) -> Self {
        self.no_proxy = Some(no_proxy.into());
        self
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_proxy_config_default() {
        let config = ProxyConfig::default();
        assert!(config.url.is_none());
        assert!(config.no_proxy.is_none());
    }

    #[test]
    fn test_proxy_config_with_url() {
        let config = ProxyConfig::default()
            .with_url("socks5://127.0.0.1:1080");

        assert_eq!(config.url, Some("socks5://127.0.0.1:1080".to_string()));
    }

    #[test]
    fn test_proxy_config_with_no_proxy() {
        let config = ProxyConfig::default()
            .with_url("http://proxy:8080")
            .with_no_proxy("localhost,127.0.0.1");

        assert_eq!(config.no_proxy, Some("localhost,127.0.0.1".to_string()));
    }
}
