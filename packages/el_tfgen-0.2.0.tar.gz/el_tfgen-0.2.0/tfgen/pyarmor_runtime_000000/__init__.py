# Pyarmor 9.2.1 (trial), 000000, 2025-12-01T18:31:24.279002
from .pyarmor_runtime import __pyarmor__
