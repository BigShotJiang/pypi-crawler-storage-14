"""
VCTK (Voice Cloning Toolkit) Corpus Recipe.

CSTR VCTK Corpus is an English multi-speaker speech dataset with 109 speakers
reading ~400 sentences each, with various English accents.

Source: https://datashare.ed.ac.uk/handle/10283/3443
License: Open Data Commons Attribution License (ODC-By) v1.0

Dataset details:
- 109 speakers (various English accents)
- ~44,000 utterances total (~400 per speaker)
- 48kHz sampling rate, 16-bit WAV
- Professional recording quality (hemi-anechoic chamber)
- Parallel text transcriptions

Subdatasets:
- main: Utterances (speaker_id, utterance_id, audio_path, text, duration_sec)
- speakers: Speaker metadata (speaker_id, age, gender, accent, region) - different schema!
"""
from pathlib import Path
from typing import Optional
import pandas as pd
import numpy as np

try:
    import soundfile as sf
    HAS_SOUNDFILE = True
except ImportError:
    HAS_SOUNDFILE = False

from ..api.recipes import RecipeContext
from ..recipes.base import RecipeOutput, SubDataset


def vctk(
    ctx: RecipeContext,
    vctk_root: Optional[str] = None,
    limit: Optional[int] = None,
    download_with_kagglehub: bool = True,
) -> RecipeOutput:
    """
    Create VCTK speech corpus dataset.

    Processes VCTK data (audio + transcriptions + speaker metadata) into structured datasets.
    Creates two datasets with different schemas (valid subdataset use case):
    1. Main: Utterances with audio paths and transcriptions
    2. Subdataset: Speaker metadata (age, gender, accent, region)

    Args:
        ctx: Recipe context
        vctk_root: Root directory containing VCTK-Corpus/ (if None, downloads via kagglehub)
        limit: Optional limit on number of utterances (for testing)
        download_with_kagglehub: Whether to download using kagglehub if vctk_root is None

    Returns:
        RecipeOutput with main utterances dataset and speakers subdataset

    Main dataset columns:
        - speaker_id: str - Speaker ID (e.g., "p326")
        - utterance_id: str - Utterance ID (e.g., "262")
        - audio_path: str - Absolute path to WAV file
        - text_path: str - Absolute path to transcription file
        - text: str - Transcription text
        - duration_sec: float - Audio duration in seconds (if soundfile available)

    Speakers subdataset columns (different schema!):
        - speaker_id: str - Speaker ID
        - age: int - Speaker age
        - gender: str - Gender (M/F)
        - accent: str - Accent (e.g., "English", "Scottish")
        - region: str - Region (e.g., "Southern England", "Belfast")

    Examples:
        >>> import warpdata as wd
        >>> from warpdata.loaders import AudioColumn
        >>>
        >>> # Download and create full dataset
        >>> result = wd.run_recipe(
        ...     "vctk",
        ...     "warpdata://audio/vctk",
        ...     with_materialize=True
        ... )
        >>>
        >>> # Load utterances
        >>> utterances = wd.load("warpdata://audio/vctk", as_format="pandas")
        >>>
        >>> # Load speaker metadata (different schema - valid subdataset!)
        >>> speakers = wd.load("warpdata://audio/vctk-speakers", as_format="pandas")
        >>>
        >>> # Lazy load audio files
        >>> audio_files = AudioColumn(utterances['audio_path'])
        >>> audio, sr = audio_files[0]  # Load first audio (np.ndarray, sample_rate)
        >>> print(f"Shape: {audio.shape}, SR: {sr} Hz")
        >>>
        >>> # Filter by speaker
        >>> p326_utterances = utterances[utterances['speaker_id'] == 'p326']
        >>>
        >>> # Join with speaker metadata
        >>> merged = utterances.merge(speakers, on='speaker_id')
        >>> scottish_audio = merged[merged['accent'] == 'Scottish']
        >>>
        >>> # Load Scottish audio files
        >>> scottish_audio_loader = AudioColumn(scottish_audio['audio_path'])
        >>> batch = scottish_audio_loader[0:5]  # Load first 5 Scottish utterances
    """
    # Determine VCTK root
    if vctk_root is None:
        if not download_with_kagglehub:
            raise ValueError("vctk_root must be provided if download_with_kagglehub=False")

        print("Downloading VCTK corpus via kagglehub...")
        print("Warning: This is a ~10.4GB download and may take a while.")

        try:
            import kagglehub
        except ImportError:
            raise ImportError(
                "kagglehub is required to download VCTK. "
                "Install with: pip install kagglehub"
            )

        # Download dataset
        path = kagglehub.dataset_download("pratt3000/vctk-corpus")
        vctk_root = Path(path) / "VCTK-Corpus" / "VCTK-Corpus"
        print(f"✓ Downloaded to: {vctk_root}")
    else:
        vctk_root = Path(vctk_root).resolve()

    # Validate paths
    wav_dir = vctk_root / "wav48"
    txt_dir = vctk_root / "txt"
    speaker_info_file = vctk_root / "speaker-info.txt"

    if not wav_dir.exists():
        raise FileNotFoundError(f"Audio directory not found: {wav_dir}")
    if not txt_dir.exists():
        raise FileNotFoundError(f"Transcription directory not found: {txt_dir}")
    if not speaker_info_file.exists():
        raise FileNotFoundError(f"Speaker info file not found: {speaker_info_file}")

    print(f"\nProcessing VCTK from {vctk_root}...")
    print(f"  Audio: {wav_dir}")
    print(f"  Transcriptions: {txt_dir}")
    print(f"  Speaker metadata: {speaker_info_file}")

    # Load speaker metadata
    print(f"\nLoading speaker metadata...")

    # Parse speaker-info.txt manually because REGION can have spaces
    speakers_data = []
    with open(speaker_info_file, 'r') as f:
        lines = f.readlines()[1:]  # Skip header
        for line in lines:
            parts = line.strip().split()
            if len(parts) < 4:
                continue

            speaker_id = 'p' + parts[0]
            age = int(parts[1])
            gender = parts[2]
            accent = parts[3]
            # Region is everything after accent (may have spaces)
            region = ' '.join(parts[4:]) if len(parts) > 4 else None

            speakers_data.append({
                'speaker_id': speaker_id,
                'age': age,
                'gender': gender,
                'accent': accent,
                'region': region,
            })

    speakers_df = pd.DataFrame(speakers_data)
    print(f"  Loaded {len(speakers_df)} speakers")

    # Build utterances dataset
    print(f"\nScanning utterances...")
    utterances = []

    speaker_dirs = sorted([d for d in wav_dir.iterdir() if d.is_dir()])

    for speaker_dir in speaker_dirs:
        speaker_id = speaker_dir.name

        # Get all audio files for this speaker
        audio_files = sorted(speaker_dir.glob("*.wav"))

        for audio_file in audio_files:
            # Parse utterance ID from filename
            # Format: p326_262.wav -> speaker=p326, utterance=262
            stem = audio_file.stem
            parts = stem.split('_')
            if len(parts) != 2:
                continue

            _, utterance_id = parts

            # Find corresponding text file
            text_file = txt_dir / speaker_id / f"{speaker_id}_{utterance_id}.txt"

            if not text_file.exists():
                print(f"  Warning: Missing transcription for {audio_file.name}")
                continue

            # Read transcription
            with open(text_file, 'r', encoding='utf-8') as f:
                text = f.read().strip()

            # Get audio duration (if soundfile available)
            duration_sec = None
            if HAS_SOUNDFILE:
                try:
                    info = sf.info(str(audio_file))
                    duration_sec = info.duration
                except Exception as e:
                    pass

            utterances.append({
                'speaker_id': speaker_id,
                'utterance_id': utterance_id,
                'audio_path': str(audio_file),
                'text_path': str(text_file),
                'text': text,
                'duration_sec': duration_sec,
            })

            # Apply limit if specified
            if limit and len(utterances) >= limit:
                break

        if limit and len(utterances) >= limit:
            break

    print(f"  Found {len(utterances):,} utterances")

    if not utterances:
        raise ValueError("No utterances found! Check VCTK directory structure.")

    # Convert to DataFrame
    utterances_df = pd.DataFrame(utterances)

    # Ensure duration_sec is standard float, not nullable Int32
    if 'duration_sec' in utterances_df.columns:
        utterances_df['duration_sec'] = utterances_df['duration_sec'].astype('float64')

    # Save main dataset (utterances)
    main_output_path = ctx.work_dir / "vctk_utterances.parquet"
    utterances_df.to_parquet(main_output_path, index=False)
    print(f"\nSaved utterances dataset: {main_output_path}")

    # Save speakers subdataset (different schema!)
    speakers_output_path = ctx.work_dir / "vctk_speakers.parquet"
    speakers_df.to_parquet(speakers_output_path, index=False)
    print(f"Saved speakers dataset: {speakers_output_path}")

    # Print statistics
    print(f"\n{'='*60}")
    print("Dataset Statistics")
    print(f"{'='*60}")
    print(f"  Total utterances: {len(utterances_df):,}")
    print(f"  Total speakers: {len(speakers_df):,}")
    print(f"  Utterances per speaker (avg): {len(utterances_df) / len(speakers_df):.1f}")

    if duration_sec is not None:
        total_duration_hours = utterances_df['duration_sec'].sum() / 3600
        print(f"  Total audio duration: {total_duration_hours:.2f} hours")

    # Speaker breakdown
    print(f"\nSpeaker metadata:")
    print(f"  Gender distribution:")
    for gender, count in speakers_df['gender'].value_counts().items():
        print(f"    {gender}: {count}")

    print(f"  Top accents:")
    for accent, count in speakers_df['accent'].value_counts().head(5).items():
        print(f"    {accent}: {count}")

    # Create subdataset for speakers (different schema - valid use case!)
    subdatasets = {
        'speakers': SubDataset(
            name='speakers',
            files=[speakers_output_path],
            description='Speaker metadata (age, gender, accent, region)',
            metadata={'count': len(speakers_df)}
        )
    }

    # Build metadata
    metadata = {
        'total_utterances': len(utterances_df),
        'total_speakers': len(speakers_df),
        'source': str(vctk_root),
        'sampling_rate_hz': 48000,
        'bit_depth': 16,
        'license': 'Open Data Commons Attribution License (ODC-By) v1.0',
        'columns': {
            'audio_path': {
                'loader': 'audio',
                'format': 'wav',
                'sample_rate': 48000,
                'bit_depth': 16,
                'description': 'Path to WAV audio file - use AudioColumn for lazy loading'
            },
            'text': {
                'type': 'text',
                'description': 'Transcription text'
            },
            'speaker_id': {
                'type': 'categorical',
                'description': 'Speaker identifier'
            },
            'utterance_id': {
                'type': 'categorical',
                'description': 'Utterance identifier'
            },
            'duration_sec': {
                'type': 'numeric',
                'unit': 'seconds',
                'description': 'Audio duration in seconds'
            }
        }
    }

    if duration_sec is not None:
        metadata['total_duration_hours'] = float(total_duration_hours)

    print(f"\n{'='*60}")
    print("Recipe complete!")
    print(f"{'='*60}")
    print(f"  Main dataset: {len(utterances_df):,} utterances")
    print(f"  Speakers subdataset: {len(speakers_df):,} speakers")

    # Track raw data for backup/provenance
    raw_data_sources = []
    if vctk_root.exists():
        raw_data_sources.append(vctk_root)  # Track the entire VCTK corpus directory

    return RecipeOutput(
        main=[main_output_path],
        subdatasets=subdatasets,
        metadata=metadata,
        raw_data=raw_data_sources,
    )
