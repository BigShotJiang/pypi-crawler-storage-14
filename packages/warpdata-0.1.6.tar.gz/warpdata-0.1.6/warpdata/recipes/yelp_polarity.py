"""
Yelp Polarity dataset recipe.

Yelp Polarity is a sentiment analysis dataset from Yelp reviews.

Source: https://huggingface.co/datasets/yelp_polarity
Paper: https://arxiv.org/abs/1509.01626

Splits:
- train: 560,000 reviews
- test: 38,000 reviews

Labels:
- 0: Negative (1-2 star reviews)
- 1: Positive (3-4 star reviews)
"""
from pathlib import Path
from typing import Tuple
import pandas as pd

from datasets import load_dataset

from ..api.recipes import RecipeContext
from .base import RecipeOutput


def yelp_polarity(
    ctx: RecipeContext,
    repo_id: str = "yelp_polarity",
    splits: Tuple[str, ...] = ("train", "test"),
) -> RecipeOutput:
    """
    Create Yelp Polarity sentiment analysis dataset.

    Downloads Yelp reviews from HuggingFace. Each review has text and
    a binary sentiment label (negative/positive).

    Args:
        ctx: Recipe context
        repo_id: HuggingFace repo ID
        splits: Which splits to include ("train", "test")

    Returns:
        RecipeOutput with single dataset

    Dataset columns:
        - text: str - Review text
        - label: int - Sentiment (0=negative, 1=positive)
        - label_name: str - Sentiment name (negative/positive)
        - split: str - train/test

    Examples:
        >>> import warpdata as wd
        >>> result = wd.run_recipe(
        ...     "yelp_polarity",
        ...     "warpdata://nlp/yelp-polarity",
        ...     with_materialize=True
        ... )
        >>> df = wd.load("warpdata://nlp/yelp-polarity", as_format="pandas")
        >>> # Filter to positive reviews
        >>> positive = df[df['label'] == 1]
    """
    from datasets import load_dataset

    print(f"Loading Yelp Polarity from {repo_id}...")

    # Label names
    label_names = ['negative', 'positive']

    # Load all requested splits
    all_records = []

    for split_name in splits:
        print(f"  Loading {split_name} split...")
        ds = load_dataset(repo_id, split=split_name)

        print(f"  Processing {len(ds):,} reviews...")

        for example in ds:
            record = {
                'text': str(example['text']),
                'label': int(example['label']),
                'label_name': label_names[example['label']],
                'split': split_name,
            }

            all_records.append(record)

    print(f"\nTotal reviews: {len(all_records):,}")

    # Create DataFrame
    df = pd.DataFrame(all_records)

    # Write to output
    output_path = ctx.work_dir / "yelp_polarity.parquet"
    df.to_parquet(output_path, index=False)

    print(f"Saved to {output_path}")
    print(f"\nSplit distribution:")
    print(df['split'].value_counts().to_string())
    print(f"\nSentiment distribution:")
    print(df['label_name'].value_counts().to_string())

    # Track raw data provenance
    raw_data_paths = []
    hf_cache = Path.home() / ".cache" / "huggingface" / "datasets" / "fancyzhx___yelp_polarity"
    if hf_cache.exists():
        raw_data_paths.append(hf_cache)

    return RecipeOutput(
        main=[output_path],
        metadata={
            'total_reviews': len(df),
            'splits': df['split'].value_counts().to_dict(),
            'sentiments': df['label_name'].value_counts().to_dict(),
            'source': repo_id,
        },
        raw_data=raw_data_paths,
    )
