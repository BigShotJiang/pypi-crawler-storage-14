"""
Polygon Ticker Events dataset recipe.

Fetches ticker event timeline from Polygon.io.
Includes: ticker changes, symbol renaming, rebranding events.

Source: Polygon.io Reference API (/vX/reference/tickers/{id}/events)
"""
from pathlib import Path
from typing import List, Optional, Dict, Any
import json
import pandas as pd
import sys
import os

from ..api.recipes import RecipeContext
from .base import RecipeOutput


def polygon_ticker_events(
    ctx: RecipeContext,
    tickers: List[str],
    *,
    types: Optional[str] = None,
    polygon_api_key: Optional[str] = None,
    raw_data_dir: str = "recipes_raw_data/polygon_ticker_events",
) -> RecipeOutput:
    """
    Create Polygon Ticker Events dataset.

    Downloads ticker event timeline including ticker changes and rebranding.

    Args:
        ctx: Recipe context
        tickers: List of ticker symbols, CUSIPs, or Composite FIGIs (e.g., ["AAPL", "META"])
        types: Comma-separated event types (currently only "ticker_change" is supported)
        polygon_api_key: Polygon API key (or set POLYGON_API_KEY env var)
        raw_data_dir: Directory to store raw JSON files

    Returns:
        RecipeOutput with ticker events data

    Examples:
        >>> import warpdata as wd
        >>> # Fetch ticker events for META (formerly FB)
        >>> result = wd.run_recipe(
        ...     "polygon_ticker_events",
        ...     "warpdata://ticker_events/meta",
        ...     tickers=["META"],
        ...     with_materialize=True
        ... )
        >>> # Fetch events for multiple tickers
        >>> result = wd.run_recipe(
        ...     "polygon_ticker_events",
        ...     "warpdata://ticker_events/tech",
        ...     tickers=["GOOGL", "META", "TWTR"],
        ...     with_materialize=True
        ... )
    """
    # Import polygon ETL
    polygon_etl_path = Path("/home/alerad/workspace/option_pricing/options_etl")
    if polygon_etl_path.exists():
        sys.path.insert(0, str(polygon_etl_path.parent))

    try:
        from options_etl.polygon_etl_module import PolygonETLAPI
    except ImportError as e:
        raise ImportError(
            f"Could not import polygon_etl_module. "
            f"Make sure /home/alerad/workspace/option_pricing is accessible"
        ) from e

    # Get API key
    api_key = polygon_api_key or os.environ.get("POLYGON_API_KEY")
    if not api_key:
        raise ValueError(
            "Polygon API key required. Set POLYGON_API_KEY env var or pass polygon_api_key parameter"
        )

    if not tickers:
        raise ValueError("Must specify at least one ticker")

    print(f"📊 Fetching Polygon Ticker Events")
    print(f"   Tickers: {', '.join(tickers)}")
    if types:
        print(f"   Types: {types}")

    # Create raw data directory
    raw_dir = Path(raw_data_dir)
    raw_dir.mkdir(parents=True, exist_ok=True)

    # Initialize Polygon ETL API
    etl = PolygonETLAPI(api_key=api_key)

    all_events = []

    # Fetch events for each ticker
    for ticker in tickers:
        print(f"\n📈 Fetching events for {ticker}...")
        json_file = raw_dir / f"{ticker.lower()}.json"

        try:
            params = {}
            if types:
                params['types'] = types

            result = etl.fetch_ticker_events(
                ticker=ticker,
                out=str(json_file),
                **params
            )
            print(f"  ✓ Fetched events for {ticker}")

        except Exception as e:
            print(f"  ⚠️  Error: {e}")
            continue

        # Load and process
        if json_file.exists():
            try:
                with open(json_file) as f:
                    data = json.load(f)

                # Extract events from response
                if isinstance(data, dict):
                    asset_name = data.get('results', {}).get('name', ticker)
                    events = data.get('results', {}).get('events', [])

                    if isinstance(events, list):
                        for event in events:
                            event_record = {
                                'query_ticker': ticker,
                                'asset_name': asset_name,
                                'event_type': event.get('type'),
                                'event_date': event.get('date'),
                            }

                            # Extract type-specific data
                            if event.get('type') == 'ticker_change':
                                ticker_change = event.get('ticker_change', {})
                                event_record['new_ticker'] = ticker_change.get('ticker')

                            all_events.append(event_record)

            except Exception as e:
                print(f"  ⚠️  Failed to parse {json_file}: {e}")

    if not all_events:
        raise ValueError("No ticker events found")

    # Convert to DataFrame
    df = pd.DataFrame(all_events)

    print(f"\n📊 Processing {len(df):,} event records...")

    # Convert event_date to datetime
    if 'event_date' in df.columns:
        df['event_date'] = pd.to_datetime(df['event_date'], errors='coerce')

    # Sort by date
    df = df.sort_values('event_date', ascending=False)

    # Merge with existing consolidated dataset if present
    try:
        from ..api import load
        existing = load(ctx.dataset_id, as_format="pandas")
        if existing is not None and len(existing) > 0:
            merged = pd.concat([existing, df], ignore_index=True)
            # Deduplicate on key fields where available
            key_cols = [c for c in ['event_date','query_ticker','event_type','new_ticker'] if c in merged.columns]
            if key_cols:
                merged = merged.drop_duplicates(subset=key_cols, keep='last')
            else:
                merged = merged.drop_duplicates(keep='last')
            df = merged
            del existing
    except Exception:
        pass

    # Save to parquet
    output_file = ctx.work_dir / "polygon_ticker_events.parquet"
    df.to_parquet(output_file, index=False)

    print(f"  ✓ Saved {len(df):,} records to {output_file.name}")

    # Show sample
    print(f"\n  📊 Columns: {list(df.columns)}")
    if len(df) > 0:
        print(f"\n  📋 Sample Events:")
        for _, row in df.head(5).iterrows():
            query = row.get('query_ticker', 'N/A')
            name = row.get('asset_name', 'N/A')
            date = row.get('event_date', 'N/A')
            event_type = row.get('event_type', 'N/A')
            new_ticker = row.get('new_ticker', 'N/A')
            if event_type == 'ticker_change':
                print(f"    {query} ({name}): Changed to {new_ticker} on {date}")
            else:
                print(f"    {query} ({name}): {event_type} on {date}")

    # Generate documentation
    readme = f"""# Polygon Ticker Events Dataset

## Overview
Ticker event timeline from Polygon.io showing ticker changes, symbol renaming, and rebranding events.

## Configuration
- **Tickers**: {', '.join(tickers)}
{f"- **Event Types**: {types}" if types else ""}

## Statistics
- **Total Events**: {len(df):,}
- **Date Range**: {df['event_date'].min()} to {df['event_date'].max()}
- **Columns**: {len(df.columns)}
- **Unique Tickers**: {df['query_ticker'].nunique() if 'query_ticker' in df.columns else 0}

## Key Fields

### Identification
- `query_ticker`: Ticker symbol used in query (current ticker)
- `asset_name`: Full name of the asset/company
- `new_ticker`: New ticker symbol (for ticker_change events)

### Event Details
- `event_type`: Type of event (currently only "ticker_change")
- `event_date`: Date when event occurred

## Event Types

### ticker_change
Indicates when a company changed its ticker symbol.

**Common Reasons:**
- **Rebranding**: Company name change (e.g., Facebook → Meta: FB → META)
- **Merger/Acquisition**: New entity formed
- **Corporate Restructuring**: Business model shift
- **Exchange Move**: Moving to different exchange

## Use Cases

### Historical Data Continuity
When analyzing historical data, ticker changes can cause issues:
- Price charts may appear to "split" at ticker change date
- Historical searches by old ticker may return no results
- Need to track both old and new symbols for complete history

### Example: Facebook → Meta
- **Old Ticker**: FB (IPO 2012-05-18)
- **New Ticker**: META (changed 2022-06-09)
- **Reason**: Company rebranding to focus on metaverse

### Data Pipeline Integration
Use this dataset to:
1. Map old tickers to new tickers
2. Maintain consistent time series across rebranding
3. Handle ticker symbol changes in backtesting
4. Update databases with current symbols

## Usage

```python
import warpdata as wd
import pandas as pd

# Load ticker events
events = wd.load("warpdata://ticker_events/all", as_format="pandas")

# Find ticker changes for a company
meta_events = events[events['query_ticker'] == 'META']

# Create ticker mapping dictionary
ticker_map = dict(zip(events['new_ticker'], events['query_ticker']))

# Find all historical tickers for an asset
def get_ticker_history(current_ticker, events):
    history = [current_ticker]
    ticker_events = events[events['query_ticker'] == current_ticker]
    for _, event in ticker_events.iterrows():
        if event['new_ticker']:
            history.append(event['new_ticker'])
    return sorted(history)

# Get all tickers META has used
meta_history = get_ticker_history('META', events)
# Result: ['FB', 'META']

# Recent ticker changes
recent = events[events['event_date'] >= pd.Timestamp.now() - pd.Timedelta(days=365)]

# Companies with multiple ticker changes
multi_changes = events.groupby('query_ticker').size()
multi_changes = multi_changes[multi_changes > 1].sort_values(ascending=False)
```

## Important Notes

### API Behavior
When you query by ticker, you get events for the **entity currently represented by that ticker**.

- Query "META" → Returns events for Meta Platforms (including "FB" → "META" change)
- Query "FB" → Would return events for whatever entity uses "FB" now (if any)

### Finding Historical Events
To find events for an entity that previously used a ticker:
1. Get the relevant identifier (CUSIP or Composite FIGI) from Ticker Details endpoint
2. Query this endpoint using that identifier instead of ticker symbol

### Data Limitations
- Currently only supports `ticker_change` events
- Historical records date back to September 10, 2003
- Not all ticker changes are captured (depends on data availability)

## Source
Polygon.io Reference API - /vX/reference/tickers/{{id}}/events
History: Records date back to September 10, 2003
Updated: Daily

## Related Endpoints
- **Ticker Details**: Get CUSIP/FIGI for an identifier
- **Ticker Types**: Reference data for ticker classifications
"""

    # Track raw data provenance
    raw_data_paths = []
    if raw_dir.exists():
        raw_data_paths.append(raw_dir.absolute())

    metadata = {
        "total_events": len(df),
        "tickers": tickers,
        "columns": list(df.columns),
        "source": "Polygon.io Reference API",
        "endpoint": "/vX/reference/tickers/{id}/events",
    }

    return RecipeOutput(
        main=[output_file],
        subdatasets={},
        docs={"README.md": readme},
        metadata=metadata,
        raw_data=raw_data_paths,
    )
