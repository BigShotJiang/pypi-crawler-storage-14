"""
OpenOrca instruction-following dataset recipe.

OpenOrca is an open-source replication of the Orca paper's dataset
constructed from FLAN, NIV2, and other sources with detailed system
prompts and assistant responses.

Source: https://huggingface.co/datasets/Open-Orca/OpenOrca

Core columns (from dataset card):
    - id: str
    - system_prompt: str
    - question: str
    - response: str

This recipe builds a single Parquet table with these core fields,
optionally limiting the number of examples, and writes in streaming
chunks to keep memory bounded.
"""
from __future__ import annotations

from pathlib import Path
from typing import Any, Dict, List, Optional

import pandas as pd
import pyarrow as pa
import pyarrow.parquet as pq
from datasets import load_dataset

try:
    from tqdm.auto import tqdm
except Exception:  # pragma: no cover
    tqdm = None

from ..api.recipes import RecipeContext
from .base import RecipeOutput


WRITE_CHUNK_SIZE = 50_000


def openorca(
    ctx: RecipeContext,
    repo_id: str = "Open-Orca/OpenOrca",
    split: str = "train",
    limit: Optional[int] = None,
) -> RecipeOutput:
    """
    Create OpenOrca instruction-following dataset.

    Args:
        ctx: Recipe context.
        repo_id: HuggingFace dataset ID (default: 'Open-Orca/OpenOrca').
        split: Dataset split to load (default: 'train').
        limit: Optional global cap on number of examples. None means
            "use full split".

    Returns:
        RecipeOutput with a single Parquet file containing:
            - id: str
            - system_prompt: str
            - question: str
            - response: str
    """
    print(f"Loading OpenOrca from {repo_id} (split={split})...")
    if limit is not None:
        print(f"  Global example limit: {limit:,}")

    # Streaming load to avoid materializing the full dataset in memory.
    ds = load_dataset(repo_id, split=split, streaming=True)

    out_path = ctx.work_dir / "openorca.parquet"
    writer: Optional[pq.ParquetWriter] = None
    buffer: List[Dict[str, Any]] = []
    total = 0

    def flush_buffer():
        nonlocal writer, buffer
        if not buffer:
            return
        df = pd.DataFrame(buffer)
        table = pa.Table.from_pandas(df, preserve_index=False)
        if writer is None:
            writer = pq.ParquetWriter(out_path, table.schema)
        writer.write_table(table)
        buffer.clear()

    # Optional progress bar (length unknown in streaming mode).
    if tqdm is not None:
        data_iter = tqdm(ds, desc="Streaming OpenOrca", unit="ex")
    else:
        data_iter = ds

    for i, example in enumerate(data_iter):
        if limit is not None and total >= limit:
            print(f"  Reached limit={limit:,}; stopping at index {i:,}")
            break

        record = {
            "id": str(example.get("id", "")),
            "system_prompt": str(example.get("system_prompt", "")),
            "question": str(example.get("question", "")),
            "response": str(example.get("response", "")),
        }
        buffer.append(record)
        total += 1

        if len(buffer) >= WRITE_CHUNK_SIZE:
            flush_buffer()

        if total % 100_000 == 0:
            print(f"  Processed {total:,} examples so far...")

    flush_buffer()
    if writer is not None:
        writer.close()

    print(f"\nTotal examples collected: {total:,}")
    print(f"Saved to {out_path}")

    # Provenance: HF cache root
    raw_data_paths: List[Path] = []
    hf_cache = Path.home() / ".cache" / "huggingface" / "datasets" / repo_id.replace("/", "___")
    if hf_cache.exists():
        raw_data_paths.append(hf_cache)

    return RecipeOutput(
        main=[out_path],
        metadata={
            "total_examples": total,
            "repo_id": repo_id,
            "split": split,
            "limit": limit,
        },
        raw_data=raw_data_paths,
    )
