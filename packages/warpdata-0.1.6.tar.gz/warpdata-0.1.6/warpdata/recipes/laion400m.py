"""
LAION-400M metadata recipe (relaion400m variant).

LAION-400M is a large-scale dataset of image-text pairs with
400M English captions and URLs.

This recipe builds a metadata-only table from the gated HuggingFace
dataset ``laion/relaion400m``. It records URL, caption and basic
image metadata, but does NOT store raw image bytes.

Source: https://huggingface.co/datasets/laion/relaion400m
Project: https://laion.ai/blog/laion-400-open-dataset/

Typical columns in ``laion/relaion400m``:
    - url: str - Image URL
    - caption: str - Text caption
    - NSFW: str - NSFW flag / classifier output
    - similarity: float - CLIP similarity score
    - LICENSE: str - License information
    - key: str - Sample key / identifier
    - original_width: int - Original image width
    - original_height: int - Original image height
"""
from pathlib import Path
from typing import Optional

import pandas as pd
from datasets import load_dataset

from ..api.recipes import RecipeContext
from .base import RecipeOutput


def laion400m(
    ctx: RecipeContext,
    repo_id: str = "laion/relaion400m",
    max_samples: Optional[int] = 1_500_000,
) -> RecipeOutput:
    """
    Create a LAION-400M metadata dataset.

    This uses the gated HuggingFace dataset ``laion/relaion400m`` and
    builds a metadata-only Parquet file with up to ``max_samples`` rows.
    By default, it caps at 1.5M samples for practicality.

    Args:
        ctx: Recipe context.
        repo_id: HuggingFace dataset ID (default: ``laion/relaion400m``).
        max_samples: Maximum number of samples to process. Defaults to
            1,500,000. Use ``None`` to process the full dataset
            (not recommended; extremely large).

    Returns:
        RecipeOutput with a single Parquet file.

    Dataset columns:
        - url: str - Image URL
        - caption: str - Text caption
        - nsfw: str - NSFW flag / classifier output
        - similarity: float - CLIP similarity score
        - license: str - License information
        - key: str - Sample key / identifier
        - original_width: int - Original image width
        - original_height: int - Original image height

    Examples:
        >>> import warpdata as wd
        >>> result = wd.run_recipe(
        ...     "laion400m",
        ...     "warpdata://vision/laion-1_5m",
        ...     max_samples=1_500_000,
        ...     with_materialize=True,
        ... )
        >>> df = wd.load("warpdata://vision/laion-1_5m", as_format="pandas")
    """
    print(f"Loading LAION-400M from {repo_id}...")

    all_records = []

    if max_samples is not None:
        print(f"Note: Limiting to {max_samples:,} samples")
        # Use streaming for sampling to avoid loading all 400M
        ds = load_dataset(repo_id, split="train", streaming=True)

        print(f"  Streaming up to {max_samples:,} samples...")
        for idx, example in enumerate(ds):
            if idx >= max_samples:
                break

            record = {
                "url": str(example.get("url", "")),
                "caption": str(example.get("caption", "")),
                "nsfw": str(example.get("NSFW", "")),
                "similarity": float(example.get("similarity", 0.0))
                if example.get("similarity") is not None
                else None,
                "license": str(example.get("LICENSE", "")),
                "key": str(example.get("key", "")),
                "original_width": int(example.get("original_width", 0))
                if example.get("original_width") is not None
                else None,
                "original_height": int(example.get("original_height", 0))
                if example.get("original_height") is not None
                else None,
            }
            all_records.append(record)

            if (idx + 1) % 100000 == 0:
                print(f"    Processed {idx + 1:,} samples...")
    else:
        print(
            "Note: max_samples is None – attempting to load full dataset "
            "(this is extremely large and not recommended)."
        )
        ds = load_dataset(repo_id, split="train")
        print(f"  Processing {len(ds):,} samples...")

        for idx, example in enumerate(ds):
            record = {
                "url": str(example.get("url", "")),
                "caption": str(example.get("caption", "")),
                "nsfw": str(example.get("NSFW", "")),
                "similarity": float(example.get("similarity", 0.0))
                if example.get("similarity") is not None
                else None,
                "license": str(example.get("LICENSE", "")),
                "key": str(example.get("key", "")),
                "original_width": int(example.get("original_width", 0))
                if example.get("original_width") is not None
                else None,
                "original_height": int(example.get("original_height", 0))
                if example.get("original_height") is not None
                else None,
            }
            all_records.append(record)

            if (idx + 1) % 1_000_000 == 0:
                print(f"    Processed {idx + 1:,} samples...")

    total = len(all_records)
    print(f"\nTotal samples: {total:,}")

    # Create DataFrame
    df = pd.DataFrame(all_records)

    # Write to output
    output_path = ctx.work_dir / "laion400m.parquet"
    df.to_parquet(output_path, index=False)

    print(f"Saved to {output_path}")

    # Track raw data provenance (HF cache directory)
    raw_data_paths = []
    hf_cache = Path.home() / ".cache" / "huggingface" / "datasets" / repo_id.replace("/", "___")
    if hf_cache.exists():
        raw_data_paths.append(hf_cache)

    return RecipeOutput(
        main=[output_path],
        metadata={
            "total_samples": total,
            "source": repo_id,
            "sampled": max_samples is not None,
            "max_samples": max_samples,
        },
        raw_data=raw_data_paths,
    )

