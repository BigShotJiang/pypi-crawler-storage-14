"""
Polygon Stocks dataset recipe.

Fetches historical stock data from Polygon.io API.
Supports grouped daily (all stocks OHLC) and individual stock bars.

Source: Polygon.io Stocks API
Data types:
- Grouped daily: OHLC for all stocks
- Individual bars: Custom timeframe bars for specific tickers
"""
from pathlib import Path
from typing import List, Optional
import json
import pandas as pd
import sys
import os
from concurrent.futures import ThreadPoolExecutor, as_completed
import datetime as dt

from ..api.recipes import RecipeContext
from .base import RecipeOutput


def polygon_stocks(
    ctx: RecipeContext,
    start_date: str,
    end_date: str,
    *,
    tickers: Optional[List[str]] = None,
    fetch_grouped_daily: bool = True,
    polygon_api_key: Optional[str] = None,
    raw_data_dir: Optional[str] = None,
    max_workers: int = 10,
    deduplicate: bool = True,
) -> RecipeOutput:
    """
    Create Polygon Stocks dataset.

    Downloads stock data from Polygon.io and converts to Parquet.

    Args:
        ctx: Recipe context
        start_date: Start date (YYYY-MM-DD)
        end_date: End date (YYYY-MM-DD)
        tickers: Optional list of specific tickers (if None, gets all via grouped daily)
        fetch_grouped_daily: Whether to fetch grouped daily (all stocks)
        polygon_api_key: Polygon API key (or set POLYGON_API_KEY env var)
        raw_data_dir: Directory to store raw JSON files
        max_workers: Max parallel downloads (default: 10, increase for faster downloads)
        deduplicate: Remove duplicates based on (date, ticker) - default True

    Returns:
        RecipeOutput with stock data

    Examples:
        >>> import warpdata as wd
        >>> # Fetch all stocks for one day
        >>> result = wd.run_recipe(
        ...     "polygon_stocks",
        ...     "warpdata://stocks/daily-2025-01-17",
        ...     start_date="2025-01-17",
        ...     end_date="2025-01-17",
        ...     with_materialize=True
        ... )
        >>> # Fast download with 20 parallel workers
        >>> result = wd.run_recipe(
        ...     "polygon_stocks",
        ...     "warpdata://stocks/year-2024",
        ...     start_date="2024-01-01",
        ...     end_date="2024-12-31",
        ...     max_workers=20,
        ...     with_materialize=True
        ... )
    """
    # Import polygon ETL
    polygon_etl_path = Path("/home/alerad/workspace/option_pricing/options_etl")
    if polygon_etl_path.exists():
        sys.path.insert(0, str(polygon_etl_path.parent))

    try:
        from options_etl.polygon_etl_module import PolygonETLAPI
    except ImportError as e:
        raise ImportError(
            f"Could not import polygon_etl_module. "
            f"Make sure /home/alerad/workspace/option_pricing is accessible"
        ) from e

    # Get API key
    api_key = polygon_api_key or os.environ.get("POLYGON_API_KEY")
    if not api_key:
        raise ValueError(
            "Polygon API key required. Set POLYGON_API_KEY env var or pass polygon_api_key parameter"
        )

    print(f"📊 Fetching Polygon Stocks data from {start_date} to {end_date}")

    # Use global raw data directory if not specified
    if raw_data_dir is None:
        raw_data_dir = str(Path.home() / ".warpdata" / "polygon_raw_data" / "polygon_stocks")

    # Create raw data directory
    raw_dir = Path(raw_data_dir)
    raw_dir.mkdir(parents=True, exist_ok=True)

    # Initialize Polygon ETL API
    etl = PolygonETLAPI(api_key=api_key)

    output_files = []
    metadata = {
        "start_date": start_date,
        "end_date": end_date,
        "source": "Polygon.io Stocks API",
        "data_type": "stocks",
    }

    if fetch_grouped_daily:
        print("\n📦 Fetching grouped daily data (all stocks)...")
        grouped_dir = raw_dir / "grouped_daily_stocks"
        grouped_dir.mkdir(parents=True, exist_ok=True)

        all_records = []

        # Build list of all dates
        current = dt.datetime.fromisoformat(start_date).date()
        end_dt = dt.datetime.fromisoformat(end_date).date()
        all_dates = []

        while current <= end_dt:
            all_dates.append(current.isoformat())
            current += dt.timedelta(days=1)

        # Separate dates into cached and uncached
        dates_to_download = []
        dates_cached = []

        for date_str in all_dates:
            json_file = grouped_dir / f"{date_str}.json"
            if json_file.exists():
                dates_cached.append(date_str)
            else:
                dates_to_download.append(date_str)

        print(f"  📊 Total dates: {len(all_dates)}")
        print(f"  ✓ Cached: {len(dates_cached)}")
        print(f"  ⬇️  To download: {len(dates_to_download)}")

        # Download uncached dates in parallel
        if dates_to_download:
            print(f"\n  🚀 Downloading {len(dates_to_download)} dates with {max_workers} parallel workers...")

            def download_date(date_str):
                json_file = grouped_dir / f"{date_str}.json"
                try:
                    sc, data = etl.client.grouped_daily_stocks(date_str)
                    if sc == 200:
                        results = data.get("results", [])
                        if results:
                            json_file.write_text(json.dumps(data))
                            return (date_str, len(results), None)
                        else:
                            # Status 200 but no results - likely weekend/holiday
                            return (date_str, 0, "No data (holiday/weekend)")
                    elif sc == 0:
                        return (date_str, 0, "API request failed (possible rate limit or data unavailable)")
                    else:
                        return (date_str, 0, f"HTTP {sc}")
                except Exception as e:
                    return (date_str, 0, str(e))

            with ThreadPoolExecutor(max_workers=max_workers) as executor:
                futures = {executor.submit(download_date, date_str): date_str
                          for date_str in dates_to_download}

                completed = 0
                failed_dates = []
                success_dates = []
                for future in as_completed(futures):
                    date_str, count, error = future.result()
                    completed += 1

                    if error:
                        print(f"  [{completed}/{len(dates_to_download)}] ⚠️  {date_str}: {error}")
                        failed_dates.append((date_str, error))
                    else:
                        print(f"  [{completed}/{len(dates_to_download)}] ✓ {date_str}: {count} stocks")
                        success_dates.append(date_str)

            # Show summary
            if failed_dates:
                print(f"\n  ⚠️  {len(failed_dates)} dates failed to download")
                if len(failed_dates) > 0:
                    # Check if failures are clustered in early dates
                    failed_dates_sorted = sorted([d for d, _ in failed_dates])
                    if failed_dates_sorted:
                        earliest_fail = failed_dates_sorted[0]
                        latest_fail = failed_dates_sorted[-1]
                        print(f"  Failed date range: {earliest_fail} to {latest_fail}")

                        # Check if we have any successful dates
                        if success_dates:
                            success_dates_sorted = sorted(success_dates)
                            earliest_success = success_dates_sorted[0]
                            print(f"  Earliest successful date: {earliest_success}")
                            print(f"  💡 Polygon grouped daily data may not be available before {earliest_success}")
                            print(f"  💡 Consider using --start {earliest_success} instead")

        # Now load all data (cached + newly downloaded) in CHUNKS
        print(f"\n  📂 Loading and processing data in chunks to avoid OOM...")

        chunk_size = 250  # Process 250 days at a time (~2M records per chunk)
        parquet_chunks = []
        total_records = 0

        for chunk_idx in range(0, len(all_dates), chunk_size):
            chunk_dates = all_dates[chunk_idx:chunk_idx + chunk_size]
            chunk_records = []

            for date_str in chunk_dates:
                json_file = grouped_dir / f"{date_str}.json"

                if json_file.exists():
                    try:
                        data = json.loads(json_file.read_text())
                        results = data.get("results", [])

                        # Delete empty cache files (weekends/holidays)
                        if not results:
                            json_file.unlink()
                            continue

                        for r in results:
                            r["date"] = date_str
                            chunk_records.append(r)

                    except Exception as e:
                        print(f"    ⚠️  Failed to parse {date_str}: {e}")

            if chunk_records:
                chunk_num = chunk_idx//chunk_size + 1
                total_chunks = (len(all_dates) + chunk_size - 1)//chunk_size
                print(f"    Chunk {chunk_num}/{total_chunks}: {len(chunk_records):,} records")

                # Convert chunk to DataFrame
                chunk_df = pd.DataFrame(chunk_records)

                # Rename columns
                column_mapping = {
                    'T': 'ticker',
                    'v': 'volume',
                    'vw': 'vwap',
                    'o': 'open',
                    'c': 'close',
                    'h': 'high',
                    'l': 'low',
                    't': 'timestamp_ms',
                    'n': 'transactions',
                }
                chunk_df = chunk_df.rename(columns=column_mapping)

                # Save chunk to temporary parquet
                chunk_file = ctx.work_dir / f"chunk_{chunk_num}.parquet"
                chunk_df.to_parquet(chunk_file, index=False)
                parquet_chunks.append(chunk_file)
                total_records += len(chunk_df)

                # Free memory
                del chunk_df
                del chunk_records

        if parquet_chunks:
            print(f"\n  ✓ Processed {total_records:,} records in {len(parquet_chunks)} chunks")
            print(f"  📦 Combining chunks into final dataset...")

            # Read all chunks and concatenate
            dfs = []
            for chunk_file in parquet_chunks:
                chunk_df = pd.read_parquet(chunk_file)
                dfs.append(chunk_df)

            df = pd.concat(dfs, ignore_index=True)
            print(f"  ✓ Combined into single DataFrame: {len(df):,} records")

            # Clean up chunk files
            for chunk_file in parquet_chunks:
                chunk_file.unlink()

        else:
            print(f"\n  ⚠️  No records found")
            raise ValueError("No trading data available")

        if len(df) > 0:
            # Columns already renamed in chunking process
            # Just ensure all expected columns exist
            expected_columns = ['ticker', 'volume', 'vwap', 'open', 'close', 'high', 'low', 'timestamp_ms', 'transactions', 'date']
            for col in expected_columns:
                if col not in df.columns:
                    df[col] = None

            # Convert timestamp to datetime
            if 'timestamp_ms' in df.columns:
                df['timestamp'] = pd.to_datetime(df['timestamp_ms'], unit='ms', errors='coerce')

            # Select and order columns
            final_columns = ['date', 'ticker', 'open', 'high', 'low', 'close',
                           'volume', 'vwap', 'transactions', 'timestamp', 'timestamp_ms']
            df = df[[col for col in final_columns if col in df.columns]]

            # Handle deduplication if existing data is present
            if deduplicate:
                # Try to load existing dataset and merge
                try:
                    from ..api import load
                    print(f"\n  🔄 Checking for existing data...")

                    dataset_uri = ctx.dataset_id  # correct dataset identifier
                    print(f"  Trying to load from: {dataset_uri}")

                    existing_df = None
                    try:
                        existing_df = load(dataset_uri, as_format="pandas")
                        print(f"  ✓ Successfully loaded existing dataset")
                    except Exception as load_err:
                        print(f"  ℹ️ No existing dataset to merge: {load_err}")

                    if existing_df is not None and not existing_df.empty:
                        print(f"  ✓ Found existing data: {len(existing_df):,} records")
                        print(f"  📦 Merging with new data...")

                        combined_df = pd.concat([existing_df, df], ignore_index=True)
                        print(f"  Combined: {len(combined_df):,} records (before dedup)")

                        # Remove duplicates based on (date, ticker)
                        print(f"  🧹 Deduplicating...")
                        initial_count = len(combined_df)
                        combined_df = combined_df.drop_duplicates(subset=['date', 'ticker'], keep='last')
                        duplicates_removed = initial_count - len(combined_df)

                        if duplicates_removed > 0:
                            print(f"  ✓ Removed {duplicates_removed:,} duplicate records")

                        df = combined_df
                        del existing_df
                        del combined_df
                    else:
                        print(f"  ℹ️  No existing data to merge (new dataset)")

                except Exception as e:
                    print(f"  ⚠️  Error checking for existing data: {e}")
                    print(f"  ℹ️  Proceeding without merge")

            # Save to parquet
            grouped_output = ctx.work_dir / "polygon_stocks_grouped_daily.parquet"
            df.to_parquet(grouped_output, index=False)
            output_files.append(grouped_output)

            metadata["grouped_daily_records"] = len(df)
            metadata["unique_tickers"] = df['ticker'].nunique() if 'ticker' in df.columns else 0
            metadata["date_range"] = f"{df['date'].min()} to {df['date'].max()}" if 'date' in df.columns else None

            print(f"  ✓ Saved {len(df):,} records to {grouped_output.name}")
            print(f"  Unique tickers: {metadata['unique_tickers']}")

            # Show sample
            print(f"\n  📊 Sample data:")
            print(df.head(3).to_string())
        else:
            print(f"\n  ⚠️  No trading data found for date range")
            print(f"  ℹ️  This usually means:")
            print(f"     - All dates were weekends/holidays")
            print(f"     - Dates are in the future")
            print(f"     - Market was closed")
            raise ValueError("No trading data available for the requested date range. This is normal for weekends/holidays.")

    # Generate documentation
    readme = f"""# Polygon Stocks Dataset

## Overview
Historical stock data from Polygon.io

## Configuration
- **Date Range**: {start_date} to {end_date}
- **Data Type**: Grouped Daily (all stocks)
- **Source**: Polygon.io Stocks API

## Schema

### Main Dataset
| Column | Type | Description |
|--------|------|-------------|
| date | string | Trading date (YYYY-MM-DD) |
| ticker | string | Stock ticker symbol |
| open | float | Opening price |
| high | float | Highest price |
| low | float | Lowest price |
| close | float | Closing price |
| volume | int | Trading volume |
| vwap | float | Volume-weighted average price |
| transactions | int | Number of transactions |
| timestamp | datetime | Trading timestamp |
| timestamp_ms | int | Unix timestamp in milliseconds |

## Usage

```python
import warpdata as wd

# Load data
df = wd.load("warpdata://stocks/...", as_format="pandas")

# Filter specific ticker
spy = df[df['ticker'] == 'SPY']

# Top movers by volume
top = df.nlargest(10, 'volume')

# Price change
df['change_pct'] = ((df['close'] - df['open']) / df['open'] * 100)
```

## Statistics
- Total records: {metadata.get('grouped_daily_records', 0):,}
- Unique tickers: {metadata.get('unique_tickers', 0):,}
- Date range: {metadata.get('date_range', 'N/A')}
"""

    # Track raw data provenance
    raw_data_paths = []
    if raw_dir.exists():
        raw_data_paths.append(raw_dir.absolute())

    return RecipeOutput(
        main=output_files,
        docs={"README.md": readme},
        metadata=metadata,
        raw_data=raw_data_paths,
    )
