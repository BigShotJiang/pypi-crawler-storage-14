"""
ArXiv API client.

Handles searching and fetching metadata from arXiv.
Uses the arXiv API (https://arxiv.org/help/api) with proper rate limiting.
Supports proxy with automatic fallback to direct connection.
"""
from __future__ import annotations

import os
import time
import re
import xml.etree.ElementTree as ET
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Iterator, Optional

import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry
from urllib.parse import urlencode

# ArXiv API base URL
ARXIV_API_URL = "http://export.arxiv.org/api/query"

# Rate limiting: arXiv asks for 3 second delay between requests
# Using 5 seconds to be safe and avoid 429 errors
RATE_LIMIT_SECONDS = 5.0
RATE_LIMIT_INITIAL_DELAY = 5.0  # Start with shorter delay on 429
RATE_LIMIT_MAX_DELAY = 60.0  # Max backoff delay

# Default proxy file location
DEFAULT_PROXY_FILE = "scripts/proxy_credentials.txt"


def load_proxy_credentials(proxy_file: Optional[str] = None) -> Optional[dict[str, str]]:
    """
    Load proxy credentials from file.

    Expected format: username:password@host:port
    or: http://username:password@host:port

    Args:
        proxy_file: Path to proxy credentials file

    Returns:
        Dict with http/https proxy URLs, or None if not found
    """
    if proxy_file is None:
        proxy_file = DEFAULT_PROXY_FILE

    if not os.path.exists(proxy_file):
        return None

    with open(proxy_file, 'r') as f:
        proxy_line = f.read().strip()

    if not proxy_line:
        return None

    if not proxy_line.startswith('http'):
        proxy_line = f"http://{proxy_line}"

    return {'http': proxy_line, 'https': proxy_line}


def create_session(
    proxies: Optional[dict[str, str]] = None,
    max_retries: int = 5,
) -> requests.Session:
    """Create a requests session with retry logic and optional proxy."""
    session = requests.Session()

    retry = Retry(
        total=max_retries,
        backoff_factor=2,
        status_forcelist=[500, 502, 503, 504],  # Don't auto-retry 429, we handle it
        allowed_methods=["GET"],
    )

    adapter = HTTPAdapter(
        max_retries=retry,
        pool_connections=10,
        pool_maxsize=10,
    )

    session.mount("http://", adapter)
    session.mount("https://", adapter)

    if proxies:
        session.proxies.update(proxies)

    session.headers.update({"User-Agent": "warpdata-arxiv-client/1.0"})

    return session


@dataclass
class ArxivPaper:
    """Represents an arXiv paper with metadata."""
    arxiv_id: str
    title: str
    abstract: str
    authors: list[str]
    categories: list[str]
    primary_category: str
    published: datetime
    updated: datetime
    pdf_url: str
    abs_url: str
    doi: Optional[str] = None
    journal_ref: Optional[str] = None
    comment: Optional[str] = None

    @property
    def year(self) -> int:
        return self.published.year

    @property
    def month(self) -> int:
        return self.published.month

    def to_dict(self) -> dict:
        """Convert to dictionary for DataFrame."""
        return {
            "arxiv_id": self.arxiv_id,
            "title": self.title,
            "abstract": self.abstract,
            "authors": self.authors,
            "categories": self.categories,
            "primary_category": self.primary_category,
            "published": self.published.isoformat(),
            "updated": self.updated.isoformat(),
            "year": self.year,
            "month": self.month,
            "pdf_url": self.pdf_url,
            "abs_url": self.abs_url,
            "doi": self.doi,
            "journal_ref": self.journal_ref,
            "comment": self.comment,
        }


class ArxivAPI:
    """
    ArXiv API client with rate limiting and proxy support.

    Example:
        api = ArxivAPI(proxy_file="scripts/proxy_credentials.txt")
        papers = api.search(
            category="cs.LG",
            year=2023,
            max_results=100,
            sort_by="submittedDate",
        )
    """

    def __init__(
        self,
        rate_limit: float = RATE_LIMIT_SECONDS,
        proxy_file: Optional[str] = None,
        use_proxy: bool = True,
    ):
        self.rate_limit = rate_limit
        self._last_request_time: Optional[float] = None
        self._proxy_file = proxy_file
        self._use_proxy = use_proxy
        self._proxy_failed = False

        # Initialize session with proxy if available
        self._proxies = None
        if use_proxy:
            self._proxies = load_proxy_credentials(proxy_file)
            if self._proxies:
                print(f"   Using proxy: {self._proxies['http'].split('@')[-1]}")

        self._session = create_session(proxies=self._proxies)

    def _wait_for_rate_limit(self) -> None:
        """Enforce rate limiting between requests."""
        if self._last_request_time is not None:
            elapsed = time.time() - self._last_request_time
            if elapsed < self.rate_limit:
                time.sleep(self.rate_limit - elapsed)
        self._last_request_time = time.time()

    def _disable_proxy(self) -> None:
        """Disable proxy and recreate session without it."""
        if self._proxies and not self._proxy_failed:
            print("   ⚠️  Proxy failed, falling back to direct connection")
            self._proxy_failed = True
            self._proxies = None
            self._session = create_session(proxies=None)

    def _build_query(
        self,
        category: Optional[str] = None,
        title: Optional[str] = None,
        abstract: Optional[str] = None,
        author: Optional[str] = None,
        all_fields: Optional[str] = None,
    ) -> str:
        """Build arXiv search query string."""
        parts = []

        if category:
            parts.append(f"cat:{category}")
        if title:
            parts.append(f"ti:{title}")
        if abstract:
            parts.append(f"abs:{abstract}")
        if author:
            parts.append(f"au:{author}")
        if all_fields:
            parts.append(f"all:{all_fields}")

        query = " AND ".join(parts) if parts else "all:*"
        return query

    def _parse_entry(self, entry: ET.Element, ns: dict) -> ArxivPaper:
        """Parse a single entry from arXiv API response."""
        def get_text(tag: str) -> str:
            elem = entry.find(f"atom:{tag}", ns)
            return elem.text.strip() if elem is not None and elem.text else ""

        def get_link(rel: str) -> str:
            for link in entry.findall("atom:link", ns):
                if link.get("rel") == rel or (rel == "pdf" and link.get("title") == "pdf"):
                    return link.get("href", "")
            return ""

        # Parse arxiv_id from the id URL
        id_url = get_text("id")
        arxiv_id = id_url.split("/abs/")[-1] if "/abs/" in id_url else id_url.split("/")[-1]
        # Remove version suffix for canonical ID
        arxiv_id_base = re.sub(r"v\d+$", "", arxiv_id)

        # Parse authors
        authors = []
        for author_elem in entry.findall("atom:author", ns):
            name_elem = author_elem.find("atom:name", ns)
            if name_elem is not None and name_elem.text:
                authors.append(name_elem.text.strip())

        # Parse categories
        categories = []
        primary_category = ""
        for cat_elem in entry.findall("arxiv:primary_category", ns):
            term = cat_elem.get("term", "")
            if term:
                primary_category = term
                categories.append(term)
        for cat_elem in entry.findall("atom:category", ns):
            term = cat_elem.get("term", "")
            if term and term not in categories:
                categories.append(term)

        # Parse dates
        published_str = get_text("published")
        updated_str = get_text("updated")
        try:
            published = datetime.fromisoformat(published_str.replace("Z", "+00:00"))
        except ValueError:
            published = datetime.now()
        try:
            updated = datetime.fromisoformat(updated_str.replace("Z", "+00:00"))
        except ValueError:
            updated = published

        # Parse optional fields
        doi_elem = entry.find("arxiv:doi", ns)
        doi = doi_elem.text.strip() if doi_elem is not None and doi_elem.text else None

        journal_elem = entry.find("arxiv:journal_ref", ns)
        journal_ref = journal_elem.text.strip() if journal_elem is not None and journal_elem.text else None

        comment_elem = entry.find("arxiv:comment", ns)
        comment = comment_elem.text.strip() if comment_elem is not None and comment_elem.text else None

        # Get PDF URL
        pdf_url = get_link("pdf")
        if not pdf_url:
            pdf_url = f"https://arxiv.org/pdf/{arxiv_id_base}.pdf"

        abs_url = f"https://arxiv.org/abs/{arxiv_id_base}"

        return ArxivPaper(
            arxiv_id=arxiv_id_base,
            title=get_text("title").replace("\n", " "),
            abstract=get_text("summary").replace("\n", " "),
            authors=authors,
            categories=categories,
            primary_category=primary_category or (categories[0] if categories else "unknown"),
            published=published,
            updated=updated,
            pdf_url=pdf_url,
            abs_url=abs_url,
            doi=doi,
            journal_ref=journal_ref,
            comment=comment,
        )

    def search(
        self,
        category: Optional[str] = None,
        year: Optional[int] = None,
        title: Optional[str] = None,
        abstract: Optional[str] = None,
        author: Optional[str] = None,
        all_fields: Optional[str] = None,
        max_results: int = 100,
        sort_by: str = "submittedDate",  # relevance, lastUpdatedDate, submittedDate
        sort_order: str = "descending",  # ascending, descending
        start: int = 0,
        max_retries: int = 6,
    ) -> list[ArxivPaper]:
        """
        Search arXiv for papers matching criteria.

        Args:
            category: arXiv category (e.g., "cs.LG", "math.CO")
            year: Filter by submission year (client-side filtering)
            title: Search in title
            abstract: Search in abstract
            author: Search by author name
            all_fields: Search across all fields
            max_results: Maximum number of results (API limit: 2000 per request)
            sort_by: Sort field (relevance, lastUpdatedDate, submittedDate)
            sort_order: Sort order (ascending, descending)
            start: Starting index for pagination
            max_retries: Maximum retry attempts on rate limit

        Returns:
            List of ArxivPaper objects
        """
        query = self._build_query(
            category=category,
            title=title,
            abstract=abstract,
            author=author,
            all_fields=all_fields,
        )

        params = {
            "search_query": query,
            "start": start,
            "max_results": min(max_results, 2000),  # API limit
            "sortBy": sort_by,
            "sortOrder": sort_order,
        }

        # Retry loop for rate limiting and proxy failures
        # Use exponential backoff: 5s, 10s, 20s, 40s, 60s (capped)
        import random
        xml_data = None
        consecutive_429s = 0

        for attempt in range(max_retries):
            self._wait_for_rate_limit()
            try:
                response = self._session.get(
                    ARXIV_API_URL,
                    params=params,
                    timeout=60,
                )

                if response.status_code == 429:
                    consecutive_429s += 1
                    # Exponential backoff with jitter: 5s, 10s, 20s, 40s... capped at 60s
                    base_delay = RATE_LIMIT_INITIAL_DELAY * (2 ** (consecutive_429s - 1))
                    wait_time = min(base_delay, RATE_LIMIT_MAX_DELAY)
                    # Add jitter (±20%)
                    jitter = wait_time * 0.2 * (random.random() * 2 - 1)
                    wait_time = wait_time + jitter
                    print(f"Rate limited (429), attempt {consecutive_429s}, waiting {wait_time:.1f}s...")
                    time.sleep(wait_time)
                    continue

                response.raise_for_status()
                xml_data = response.content
                consecutive_429s = 0  # Reset on success
                break  # Success

            except requests.exceptions.ProxyError as e:
                self._disable_proxy()
                if attempt < max_retries - 1:
                    continue
                raise

            except requests.exceptions.RequestException as e:
                if attempt == max_retries - 1:
                    raise
                # Try disabling proxy on connection errors
                if self._proxies and "proxy" in str(e).lower():
                    self._disable_proxy()
                time.sleep(self.rate_limit)

        if xml_data is None:
            return []

        # Parse XML
        root = ET.fromstring(xml_data)
        ns = {
            "atom": "http://www.w3.org/2005/Atom",
            "arxiv": "http://arxiv.org/schemas/atom",
            "opensearch": "http://a9.com/-/spec/opensearch/1.1/",
        }

        papers = []
        for entry in root.findall("atom:entry", ns):
            try:
                paper = self._parse_entry(entry, ns)
                # Client-side year filtering
                if year is not None and paper.year != year:
                    continue
                papers.append(paper)
            except Exception as e:
                print(f"Warning: Failed to parse entry: {e}")
                continue

        return papers

    def search_all(
        self,
        category: Optional[str] = None,
        year: Optional[int] = None,
        max_results: int = 1000,
        sort_by: str = "submittedDate",
        sort_order: str = "descending",
        batch_size: int = 200,
    ) -> Iterator[ArxivPaper]:
        """
        Search with automatic pagination to get all results.

        Yields papers one by one, handling pagination automatically.
        """
        fetched = 0
        start = 0

        while fetched < max_results:
            batch = min(batch_size, max_results - fetched)
            papers = self.search(
                category=category,
                year=year,
                max_results=batch,
                sort_by=sort_by,
                sort_order=sort_order,
                start=start,
            )

            if not papers:
                break

            for paper in papers:
                yield paper
                fetched += 1
                if fetched >= max_results:
                    break

            start += len(papers)

            # If we got fewer than requested, we've hit the end
            if len(papers) < batch:
                break

    def get_paper(self, arxiv_id: str) -> Optional[ArxivPaper]:
        """
        Fetch a single paper by arXiv ID.

        Args:
            arxiv_id: arXiv identifier (e.g., "2301.12345")

        Returns:
            ArxivPaper or None if not found
        """
        params = {
            "id_list": arxiv_id,
            "max_results": 1,
        }

        url = f"{ARXIV_API_URL}?{urlencode(params)}"

        self._wait_for_rate_limit()

        req = Request(url, headers={"User-Agent": "warpdata-arxiv-client/1.0"})
        with urlopen(req, timeout=60) as response:
            xml_data = response.read()

        root = ET.fromstring(xml_data)
        ns = {
            "atom": "http://www.w3.org/2005/Atom",
            "arxiv": "http://arxiv.org/schemas/atom",
        }

        entries = root.findall("atom:entry", ns)
        if not entries:
            return None

        try:
            return self._parse_entry(entries[0], ns)
        except Exception:
            return None
