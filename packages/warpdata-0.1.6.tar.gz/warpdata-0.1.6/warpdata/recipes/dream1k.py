"""
DREAM-1K Dataset Recipe.

Downloads and processes the DREAM-1K dataset from HuggingFace.
DREAM-1K is a video understanding dataset with 1000 videos containing
detailed descriptions and event annotations.

Dataset: omni-research/DREAM-1K
Paper: DREAM: Decoupling Representation and Evaluation for Video Understanding

Features:
- 1000 annotated videos
- Detailed descriptions
- Event-level annotations
- Multiple subjects and shots per video
"""
from __future__ import annotations
from pathlib import Path
from typing import List, Dict, Any
import json

from ..api.recipes import RecipeContext
from ..recipes.base import RecipeOutput, SubDataset


def dream1k(ctx: RecipeContext, **options) -> RecipeOutput:
    """
    Download and process DREAM-1K dataset.

    Options:
        limit (int): Limit number of videos to process (default: all 1000)
        download_videos (bool): Whether to download actual video files (default: True)
                                Videos are ~3.6GB total

    Returns:
        RecipeOutput with main dataset containing video metadata and annotations.
    """
    from datasets import load_dataset
    from huggingface_hub import hf_hub_download
    import pandas as pd
    import zipfile
    import shutil

    limit = options.get('limit', None)
    download_videos = options.get('download_videos', True)

    print("📥 Loading DREAM-1K dataset from HuggingFace...")
    ds = load_dataset('omni-research/DREAM-1K')
    test_split = ds['test']

    if limit:
        print(f"   Limiting to {limit} examples")
        test_split = test_split.select(range(min(limit, len(test_split))))

    print(f"   Total examples: {len(test_split)}")

    # Download and extract videos if requested
    videos_dir = None
    if download_videos:
        print("🎬 Downloading videos (3.6 GB, this may take a while)...")
        video_zip = hf_hub_download(
            repo_id='omni-research/DREAM-1K',
            filename='video/video.zip',
            repo_type='dataset'
        )

        print(f"   Downloaded to: {video_zip}")

        # Extract videos to work directory
        videos_dir = ctx.work_dir / "videos"
        videos_dir.mkdir(exist_ok=True)

        print(f"📦 Extracting videos to {videos_dir}...")
        with zipfile.ZipFile(video_zip, 'r') as zip_ref:
            zip_ref.extractall(videos_dir)

        print(f"✅ Extracted {len(list(videos_dir.rglob('*.mp4')))} video files")

    # Convert to pandas
    print("📊 Converting to DataFrame...")
    df = pd.DataFrame({
        'idx': test_split['idx'],
        'video_file': test_split['video_file'],
        'source': test_split['source'],
        'duration': test_split['duration'],
        'description': test_split['description'],
        'events': test_split['events'],
        'n_subjects': test_split['n_subjects'],
        'n_shots': test_split['n_shots'],
        'n_events': test_split['n_events'],
    })

    # Update video_file paths to point to extracted videos
    if download_videos and videos_dir:
        # Videos are extracted to DREAM-1K_videos/ and named as just the idx number
        df['video_file_absolute'] = df['idx'].apply(
            lambda idx: str(videos_dir / 'DREAM-1K_videos' / f'{idx}.mp4')
        )

    # Save main dataset
    main_path = ctx.work_dir / "dream1k.parquet"
    print(f"💾 Saving main dataset to {main_path}...")
    df.to_parquet(main_path, index=False)

    # Create events dataset (one row per event)
    print("📋 Creating events subdataset...")
    events_rows = []
    for _, row in df.iterrows():
        for event_idx, event_text in enumerate(row['events']):
            events_rows.append({
                'idx': row['idx'],
                'event_idx': event_idx,
                'event_text': event_text,
                'video_file': row['video_file'],
                'source': row['source'],
                'duration': row['duration'],
            })

    events_df = pd.DataFrame(events_rows)
    events_path = ctx.work_dir / "dream1k_events.parquet"
    events_df.to_parquet(events_path, index=False)

    print(f"   Total events: {len(events_df)}")

    # Write documentation
    doc_content = f"""# DREAM-1K Dataset

## Overview
DREAM-1K is a video understanding benchmark dataset with detailed annotations.

## Statistics
- Total videos: {len(df)}
- Total events: {len(events_df)}
- Average duration: {df['duration'].mean():.2f}s
- Average events per video: {df['n_events'].mean():.2f}
- Average subjects per video: {df['n_subjects'].mean():.2f}
- Average shots per video: {df['n_shots'].mean():.2f}

## Sources
{df['source'].value_counts().to_dict()}

## Schema

### Main Dataset (dream1k)
- `idx`: Video ID
- `video_file`: Path to video file (relative)
- `source`: Source category (e.g., DREAM/movie_animation)
- `duration`: Video duration in seconds
- `description`: Overall video description
- `events`: List of event descriptions
- `n_subjects`: Number of subjects in video
- `n_shots`: Number of camera shots
- `n_events`: Number of annotated events

### Events Subdataset (dream1k_events)
- `idx`: Video ID (links to main dataset)
- `event_idx`: Event index within video
- `event_text`: Event description
- `video_file`: Path to video file
- `source`: Source category
- `duration`: Video duration

## Usage

```python
import warpdata as wd

# Load main dataset
df = wd.load("warpdata://video/dream1k", as_format="pandas")
print(f"Videos: {{len(df)}}")

# Load events subdataset
events = wd.load("warpdata://video/dream1k-events", as_format="pandas")
print(f"Total events: {{len(events)}}")

# Filter by source
animation = df[df['source'].str.contains('animation')]

# Get videos by duration
short_videos = df[df['duration'] < 5]
long_videos = df[df['duration'] > 10]
```

## Citation

If you use DREAM-1K, please cite:
```
@article{{dream2024,
  title={{DREAM: Decoupling Representation and Evaluation for Video Understanding}},
  author={{...}},
  journal={{...}},
  year={{2024}}
}}
```

## Notes

- Video files are downloaded by default (~3.6 GB total)
- Use `download_videos=False` option to skip video download (metadata only)
- `video_file_absolute` column contains full paths to extracted videos
- Events subdataset provides per-event granularity for fine-grained analysis
"""

    ctx.write_documentation("README.md", doc_content)

    print("✅ DREAM-1K dataset processed successfully!")
    print(f"   Main dataset: {len(df)} videos")
    print(f"   Events dataset: {len(events_df)} events")

    return RecipeOutput(
        main=[main_path],
        subdatasets={
            'events': SubDataset(
                name='dream1k-events',
                files=[events_path],
                description='Per-event annotations from DREAM-1K videos'
            )
        }
    )
