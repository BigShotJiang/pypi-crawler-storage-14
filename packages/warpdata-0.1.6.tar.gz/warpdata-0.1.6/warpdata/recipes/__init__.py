"""
Built-in recipes for warpdata.

This module provides built-in recipe functions.
Registration is handled by warpdata/__init__.py after imports are complete.
"""


def register_builtin_recipes():
    """Register built-in recipes (called after api.recipes is fully initialized)."""
    from warpdata.api.recipes import register_recipe
    from .wine_quality import wine_quality
    from .sample_text import sample_text
    from .dmt_brains import dmt_brains
    from .gsm8k import gsm8k
    from .logician import logician
    from .hellaswag import hellaswag
    from .ag_news import ag_news
    from .yelp_polarity import yelp_polarity
    from .arxiv_pdf_manifest import arxiv_pdf_manifest
    from .arxiv_metadata_sqlite import arxiv_metadata_sqlite
    from .arxiv_stage_join import arxiv_stage_join
    from .arxiv_extract_text import arxiv_extract_text
    from .arxiv_legacy import arxiv
    from .arxiv.populate import arxiv_populate
    from .coco import coco
    from .celeba import celeba
    from .sam_3d_body import sam_3d_body
    from .vctk import vctk
    from .mathlib4 import mathlib4
    from .numina_math_lean import numina_math_lean
    from .dream1k import dream1k
    from .cmu_mocap import cmu_mocap
    from .gse70138_lincs import gse70138_lincs
    from .gse92742_lincs import gse92742_lincs
    from .openhermes import openhermes
    from .imdb import imdb
    from .truthfulqa import truthfulqa
    from .mathvista import mathvista
    from .english_quotes import english_quotes
    from .imagenet1k import imagenet1k
    from .mathvision import mathvision
    from .mathx5m import mathx5m
    from .arcagi import arcagi
    from .arcagi2 import arcagi2
    from .mmlu import mmlu
    from .mbpp import mbpp
    from .math_hendrycks import math_hendrycks
    from .python_alpaca import python_alpaca
    from .multi_c4 import multi_c4
    from .polygon_options import polygon_options
    from .polygon_stocks import polygon_stocks
    from .polygon_intraday import polygon_intraday
    from .polygon_stocks_intraday_ohlc import polygon_stocks_intraday_ohlc
    from .polygon_snapshots import polygon_snapshots
    from .polygon_fundamentals import polygon_fundamentals
    from .polygon_technical import polygon_technical
    from .polygon_ticks import polygon_ticks
    from .polygon_ipos import polygon_ipos
    from .polygon_splits import polygon_splits
    from .polygon_dividends import polygon_dividends
    from .polygon_ticker_events import polygon_ticker_events
    from .polygon_news import polygon_news
    from .polygon_earnings import polygon_earnings
    from .sec_earnings import sec_earnings
    from .sec_filings_text import sec_filings_text
    from .coingecko_crypto import coingecko_crypto
    from .coingecko_crypto_hourly import coingecko_crypto_hourly
    from .coingecko_global import coingecko_global
    from .coingecko_trending import coingecko_trending
    from .coingecko_ohlcv import coingecko_ohlcv
    from .coingecko_dex_pools import coingecko_dex_pools
    from .coingecko_onchain import coingecko_onchain
    from .coingecko_onchain_safe import coingecko_onchain_safe
    from .coingecko_pools_safe_full import coingecko_pools_safe_full
    from .coingecko_derivatives import coingecko_derivatives
    from .cifar100 import cifar100
    from .laion400m import laion400m
    from .laion_images import laion_images
    from .gutenberg_books import gutenberg_books
    from .gutenberg_mirror import gutenberg_mirror
    from .openorca import openorca
    from .pubmedqa import pubmedqa
    from .essential_web import essential_web
    from .the_stack import the_stack
    from .wikipedia_text import wikipedia_text
    from .fineweb import fineweb
    from .fineweb2_multilingual import fineweb2_multilingual
    from .the_stack_v2 import the_stack_v2
    from .text_chunks import text_chunks
    from .binance_symbols import binance_symbols
    from .binance_klines import binance_klines
    from .binance_symbol_map import binance_symbol_map
    from .binance_futures_funding import binance_futures_funding
    from .binance_futures_open_interest import binance_futures_open_interest
    from .sectors_from_fundamentals import sectors_from_fundamentals
    from .glove import glove

    register_recipe("wine_quality", wine_quality)
    register_recipe("sample_text", sample_text)
    register_recipe("dmt_brains", dmt_brains)
    register_recipe("gsm8k", gsm8k)
    register_recipe("logician", logician)
    register_recipe("hellaswag", hellaswag)
    register_recipe("ag_news", ag_news)
    register_recipe("yelp_polarity", yelp_polarity)
    register_recipe("arxiv_pdf_manifest", arxiv_pdf_manifest)
    register_recipe("arxiv_metadata_sqlite", arxiv_metadata_sqlite)
    register_recipe("arxiv_stage_join", arxiv_stage_join)
    register_recipe("arxiv_extract_text", arxiv_extract_text)
    register_recipe("arxiv", arxiv)
    register_recipe("arxiv_populate", arxiv_populate)
    register_recipe("coco", coco)
    register_recipe("celeba", celeba)
    register_recipe("sam_3d_body", sam_3d_body)
    register_recipe("vctk", vctk)
    register_recipe("mathlib4", mathlib4)
    register_recipe("numina_math_lean", numina_math_lean)
    register_recipe("dream1k", dream1k)
    register_recipe("cmu_mocap", cmu_mocap)
    register_recipe("gse70138_lincs", gse70138_lincs)
    register_recipe("gse92742_lincs", gse92742_lincs)
    register_recipe("openhermes", openhermes)
    register_recipe("imdb", imdb)
    register_recipe("truthfulqa", truthfulqa)
    register_recipe("mathvista", mathvista)
    register_recipe("english_quotes", english_quotes)
    register_recipe("imagenet1k", imagenet1k)
    register_recipe("mathvision", mathvision)
    register_recipe("mathx5m", mathx5m)
    register_recipe("arcagi", arcagi)
    register_recipe("arcagi2", arcagi2)
    register_recipe("mmlu", mmlu)
    register_recipe("mbpp", mbpp)
    register_recipe("math_hendrycks", math_hendrycks)
    register_recipe("python_alpaca", python_alpaca)
    register_recipe("multi_c4", multi_c4)
    register_recipe("polygon_options", polygon_options)
    register_recipe("polygon_stocks", polygon_stocks)
    register_recipe("polygon_intraday", polygon_intraday)
    register_recipe("polygon_stocks_intraday_ohlc", polygon_stocks_intraday_ohlc)
    register_recipe("polygon_snapshots", polygon_snapshots)
    register_recipe("polygon_fundamentals", polygon_fundamentals)
    register_recipe("polygon_technical", polygon_technical)
    register_recipe("polygon_ticks", polygon_ticks)
    register_recipe("polygon_ipos", polygon_ipos)
    register_recipe("polygon_splits", polygon_splits)
    register_recipe("polygon_dividends", polygon_dividends)
    register_recipe("polygon_ticker_events", polygon_ticker_events)
    register_recipe("polygon_news", polygon_news)
    register_recipe("polygon_earnings", polygon_earnings)
    register_recipe("sec_earnings", sec_earnings)
    register_recipe("sec_filings_text", sec_filings_text)
    register_recipe("coingecko_crypto", coingecko_crypto)
    register_recipe("coingecko_crypto_hourly", coingecko_crypto_hourly)
    register_recipe("coingecko_global", coingecko_global)
    register_recipe("coingecko_trending", coingecko_trending)
    register_recipe("coingecko_ohlcv", coingecko_ohlcv)
    register_recipe("coingecko_dex_pools", coingecko_dex_pools)
    register_recipe("coingecko_onchain", coingecko_onchain)
    register_recipe("coingecko_onchain_safe", coingecko_onchain_safe)
    register_recipe("coingecko_pools_safe_full", coingecko_pools_safe_full)
    register_recipe("coingecko_derivatives", coingecko_derivatives)
    register_recipe("binance_symbols", binance_symbols)
    register_recipe("binance_klines", binance_klines)
    register_recipe("binance_symbol_map", binance_symbol_map)
    register_recipe("binance_futures_funding", binance_futures_funding)
    register_recipe("binance_futures_open_interest", binance_futures_open_interest)
    register_recipe("sectors_from_fundamentals", sectors_from_fundamentals)
    register_recipe("cifar100", cifar100)
    register_recipe("laion400m", laion400m)
    register_recipe("laion_images", laion_images)
    register_recipe("gutenberg_books", gutenberg_books)
    register_recipe("gutenberg_mirror", gutenberg_mirror)
    register_recipe("openorca", openorca)
    register_recipe("pubmedqa", pubmedqa)
    register_recipe("essential_web", essential_web)
    register_recipe("the_stack", the_stack)
    register_recipe("wikipedia_text", wikipedia_text)
    register_recipe("fineweb", fineweb)
    register_recipe("fineweb2_multilingual", fineweb2_multilingual)
    register_recipe("the_stack_v2", the_stack_v2)
    register_recipe("text_chunks", text_chunks)
    register_recipe("glove", glove)


__all__ = ["register_builtin_recipes"]
