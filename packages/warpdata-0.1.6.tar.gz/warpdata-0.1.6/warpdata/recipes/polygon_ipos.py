"""
Polygon IPOs dataset recipe.

Fetches historical and upcoming IPO data from Polygon.io.
Includes: issuer name, ticker, IPO date, pricing, offering details.

Source: Polygon.io Reference API (/vX/reference/ipos)
"""
from pathlib import Path
from typing import Optional, Dict, Any
import json
import pandas as pd
import sys
import os

from ..api.recipes import RecipeContext
from .base import RecipeOutput


def polygon_ipos(
    ctx: RecipeContext,
    *,
    ticker: Optional[str] = None,
    us_code: Optional[str] = None,
    isin: Optional[str] = None,
    listing_date: Optional[str] = None,
    listing_date_gte: Optional[str] = None,
    listing_date_lte: Optional[str] = None,
    ipo_status: Optional[str] = None,
    order: str = "desc",
    limit: int = 1000,
    sort: str = "listing_date",
    polygon_api_key: Optional[str] = None,
    raw_data_dir: str = "recipes_raw_data/polygon_ipos",
) -> RecipeOutput:
    """
    Create Polygon IPOs dataset.

    Downloads IPO events including historical and upcoming offerings.

    Args:
        ctx: Recipe context
        ticker: Filter by ticker symbol (e.g., "AAPL")
        us_code: Filter by US Code (9-character alphanumeric)
        isin: Filter by ISIN (International Securities ID)
        listing_date: Filter by exact listing date (YYYY-MM-DD)
        listing_date_gte: Filter by listing date >= (YYYY-MM-DD)
        listing_date_lte: Filter by listing date <= (YYYY-MM-DD)
        ipo_status: Filter by status (pending, new, history, rumor, withdrawn, etc.)
        order: Sort order (asc or desc, default: desc)
        limit: Maximum number of results (default: 1000)
        sort: Sort field (default: listing_date)
        polygon_api_key: Polygon API key (or set POLYGON_API_KEY env var)
        raw_data_dir: Directory to store raw JSON files

    Returns:
        RecipeOutput with IPO data

    Examples:
        >>> import warpdata as wd
        >>> # Fetch recent IPOs
        >>> result = wd.run_recipe(
        ...     "polygon_ipos",
        ...     "warpdata://ipos/recent",
        ...     limit=100,
        ...     with_materialize=True
        ... )
        >>> # Fetch IPOs by status
        >>> result = wd.run_recipe(
        ...     "polygon_ipos",
        ...     "warpdata://ipos/pending",
        ...     ipo_status="pending",
        ...     with_materialize=True
        ... )
    """
    # Import polygon ETL
    polygon_etl_path = Path("/home/alerad/workspace/option_pricing/options_etl")
    if polygon_etl_path.exists():
        sys.path.insert(0, str(polygon_etl_path.parent))

    try:
        from options_etl.polygon_etl_module import PolygonETLAPI
    except ImportError as e:
        raise ImportError(
            f"Could not import polygon_etl_module. "
            f"Make sure /home/alerad/workspace/option_pricing is accessible"
        ) from e

    # Get API key
    api_key = polygon_api_key or os.environ.get("POLYGON_API_KEY")
    if not api_key:
        raise ValueError(
            "Polygon API key required. Set POLYGON_API_KEY env var or pass polygon_api_key parameter"
        )

    print(f"📊 Fetching Polygon IPOs")
    if ticker:
        print(f"   Ticker: {ticker}")
    if ipo_status:
        print(f"   Status: {ipo_status}")
    if listing_date:
        print(f"   Listing Date: {listing_date}")

    # Create raw data directory
    raw_dir = Path(raw_data_dir)
    raw_dir.mkdir(parents=True, exist_ok=True)

    # Initialize Polygon ETL API
    etl = PolygonETLAPI(api_key=api_key)

    # Prepare filters
    filters: Dict[str, Any] = {
        "order": order,
        "limit": limit,
        "sort": sort,
    }
    if ticker:
        filters["ticker"] = ticker
    if us_code:
        filters["us_code"] = us_code
    if isin:
        filters["isin"] = isin
    if listing_date:
        filters["listing_date"] = listing_date
    if listing_date_gte:
        filters["listing_date.gte"] = listing_date_gte
    if listing_date_lte:
        filters["listing_date.lte"] = listing_date_lte
    if ipo_status:
        filters["ipo_status"] = ipo_status

    # Fetch IPOs
    json_file = raw_dir / "ipos.json"
    print(f"\n📈 Fetching IPOs...")

    try:
        result = etl.fetch_ipos(out=str(json_file), **filters)
        print(f"  ✓ Fetched {result.get('count', 0):,} IPO records")
    except Exception as e:
        raise RuntimeError(f"Failed to fetch IPOs: {e}") from e

    # Load and process data
    if not json_file.exists():
        raise ValueError("No IPO data downloaded")

    with open(json_file) as f:
        data = json.load(f)

    if not isinstance(data, list) or len(data) == 0:
        raise ValueError("No IPO records found")

    # Convert to DataFrame
    df = pd.DataFrame(data)

    print(f"\n📊 Processing {len(df):,} IPO records...")

    # Convert date columns to datetime
    date_columns = ['announced_date', 'listing_date', 'last_updated', 'issue_start_date', 'issue_end_date']
    for col in date_columns:
        if col in df.columns:
            df[col] = pd.to_datetime(df[col], errors='coerce')

    # Save to parquet
    output_file = ctx.work_dir / "polygon_ipos.parquet"
    df.to_parquet(output_file, index=False)

    print(f"  ✓ Saved {len(df):,} records to {output_file.name}")

    # Show sample
    print(f"\n  📊 Columns: {list(df.columns)}")
    if len(df) > 0:
        print(f"\n  📋 Sample IPOs:")
        for _, row in df.head(3).iterrows():
            ticker_str = row.get('ticker', 'N/A')
            name = row.get('issuer_name', 'N/A')
            date = row.get('listing_date', 'N/A')
            status = row.get('ipo_status', 'N/A')
            print(f"    {ticker_str}: {name} | {date} | {status}")

    # Generate documentation
    readme = f"""# Polygon IPOs Dataset

## Overview
Historical and upcoming Initial Public Offering (IPO) data from Polygon.io

## Configuration
- **Order**: {order}
- **Sort**: {sort}
- **Limit**: {limit:,}
{f"- **Ticker**: {ticker}" if ticker else ""}
{f"- **IPO Status**: {ipo_status}" if ipo_status else ""}
{f"- **Listing Date**: {listing_date}" if listing_date else ""}

## Statistics
- **Total IPOs**: {len(df):,}
- **Date Range**: {df['listing_date'].min()} to {df['listing_date'].max()}
- **Columns**: {len(df.columns)}

## Key Fields

### Identification
- `ticker`: Stock ticker symbol
- `issuer_name`: Company name
- `us_code`: 9-character US security code
- `isin`: International Securities ID

### Dates
- `announced_date`: When IPO was announced
- `listing_date`: First trading date
- `issue_start_date`: Start of offering period
- `issue_end_date`: End of offering period
- `last_updated`: Last modification date

### Pricing
- `lowest_offer_price`: Minimum offering price
- `highest_offer_price`: Maximum offering price
- `final_issue_price`: Actual IPO price
- `currency_code`: Currency (e.g., USD)

### Offering Details
- `min_shares_offered`: Minimum shares to sell
- `max_shares_offered`: Maximum shares to sell
- `shares_outstanding`: Total shares issued
- `total_offer_size`: Total amount raised
- `lot_size`: Minimum tradeable quantity

### Status & Metadata
- `ipo_status`: Status (pending, new, history, rumor, withdrawn, etc.)
- `security_type`: Type of security (e.g., CS = Common Stock)
- `security_description`: Description of security
- `primary_exchange`: Exchange MIC code

## IPO Status Values
- **pending**: IPO announced, awaiting listing
- **new**: Recently listed (listing day)
- **history**: Past IPO event
- **rumor**: Unconfirmed IPO plans
- **withdrawn**: IPO cancelled
- **postponed**: IPO delayed
- **direct_listing_process**: Direct listing (no underwriter)

## Usage

```python
import warpdata as wd

# Load IPO data
ipos = wd.load("warpdata://ipos/recent", as_format="pandas")

# Filter by status
pending_ipos = ipos[ipos['ipo_status'] == 'pending']

# Recent IPOs (last 30 days)
import pandas as pd
recent = ipos[ipos['listing_date'] >= pd.Timestamp.now() - pd.Timedelta(days=30)]

# Sort by offering size
largest = ipos.sort_values('total_offer_size', ascending=False).head(10)

# Average IPO price range
ipos['price_range'] = ipos['highest_offer_price'] - ipos['lowest_offer_price']
avg_range = ipos['price_range'].mean()
```

## Source
Polygon.io Reference API - /vX/reference/ipos
History: Records date back to February 28, 2002
Updated: Daily
"""

    # Track raw data provenance
    raw_data_paths = []
    if raw_dir.exists():
        raw_data_paths.append(raw_dir.absolute())

    metadata = {
        "total_ipos": len(df),
        "columns": list(df.columns),
        "source": "Polygon.io Reference API",
        "endpoint": "/vX/reference/ipos",
        "filters": filters,
    }

    return RecipeOutput(
        main=[output_file],
        subdatasets={},
        docs={"README.md": readme},
        metadata=metadata,
        raw_data=raw_data_paths,
    )
