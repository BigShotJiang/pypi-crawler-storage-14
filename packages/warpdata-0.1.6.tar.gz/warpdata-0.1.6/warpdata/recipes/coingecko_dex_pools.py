"""
CoinGecko DEX Pools dataset recipe.

Downloads DEX pool data (liquidity pools, OHLCV, tokens) from CoinGecko's onchain API.

Data types:
- DEX list: Available DEXes per network
- Pool info: Token pairs, reserves, prices, volumes, transactions
- Pool OHLCV: Candlestick data for specific pools
- Top pools: Highest volume/liquidity pools by token

The recipe appends across runs and deduplicates on appropriate keys.

API key:
- Requires CoinGecko Pro API key (COINGECKO_API_KEY env var)
- Uses x-cg-pro-api-key header

Networks supported:
- eth (Ethereum)
- bsc (Binance Smart Chain)
- polygon (Polygon)
- arbitrum (Arbitrum)
- base (Base)
- avalanche (Avalanche)
- solana (Solana)
- and more...

Example:
    >>> import warpdata as wd
    >>> result = wd.run_recipe(
    ...     "coingecko_dex_pools",
    ...     "warpdata://crypto/coingecko/dex_pools",
    ...     network="eth",
    ...     data_type="top_pools",
    ...     token_addresses=["0xc02aaa39b223fe8d0a0e5c4f27ead9083c756cc2"],  # WETH
    ...     with_materialize=True
    ... )
"""
from __future__ import annotations

import os
import time
import threading
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import pandas as pd

from ..api.recipes import RecipeContext
from .base import RecipeOutput


PRO_API_BASE = "https://pro-api.coingecko.com/api/v3"

_REQ_LOCK = threading.Lock()
_LAST_REQ_TS = 0.0
_MIN_INTERVAL_ENV = float(os.environ.get('COINGECKO_MIN_INTERVAL', '0')) if os.environ.get('COINGECKO_MIN_INTERVAL') else None


def _http_get_json(url: str, params: Optional[Dict[str, Any]] = None, *, api_key: Optional[str] = None, timeout: float = 30.0) -> Dict[str, Any]:
    import urllib.request
    import urllib.parse
    import json

    qs = urllib.parse.urlencode(params or {})
    full = f"{url}?{qs}" if qs else url

    headers = {
        "Accept": "application/json",
        "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
    }
    if api_key:
        headers["x-cg-pro-api-key"] = api_key

    req = urllib.request.Request(full, headers=headers, method="GET")

    global _LAST_REQ_TS
    with _REQ_LOCK:
        default_interval = 0.15 if api_key else 1.5
        min_interval = max(_MIN_INTERVAL_ENV or 0.0, default_interval)
        now = time.time()
        wait = _LAST_REQ_TS + min_interval - now
        if wait > 0:
            time.sleep(wait)
        _LAST_REQ_TS = time.time()

    backoff = 0.5
    for attempt in range(5):
        try:
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                data = resp.read()
                return json.loads(data)
        except Exception as e:
            import urllib.error
            if isinstance(e, urllib.error.HTTPError):
                code = e.code
                body = e.read().decode("utf-8", errors="replace") if hasattr(e, "read") else ""

                if code in (429, 403) or 500 <= code < 600:
                    if attempt < 4:
                        time.sleep(backoff)
                        backoff *= 2
                        continue
                    raise RuntimeError(f"HTTP {code} for {full} :: {body}")

                raise RuntimeError(f"HTTP {code} for {full} :: {body}")

            if attempt == 4:
                raise
    raise RuntimeError(f"Failed to fetch {full}")


def coingecko_dex_pools(
    ctx: RecipeContext,
    network: str,
    *,
    data_type: str = "top_pools",
    token_addresses: Optional[List[str]] = None,
    pool_addresses: Optional[List[str]] = None,
    timeframe: str = "day",
    api_key: Optional[str] = None,
    max_workers: int = 5,
    page: int = 1,
    include_ohlcv: bool = False,
) -> RecipeOutput:
    """
    Create CoinGecko DEX pools dataset.

    Args:
        ctx: Recipe context
        network: Network ID (eth, bsc, polygon, arbitrum, base, solana, etc.)
        data_type: Type of data to fetch:
            - "dexes": List of DEXes on network
            - "top_pools": Top pools by token address(es)
            - "pool_info": Detailed info for specific pools
            - "pool_ohlcv": OHLCV data for specific pools
        token_addresses: List of token addresses (for top_pools)
        pool_addresses: List of pool addresses (for pool_info, pool_ohlcv)
        timeframe: OHLCV timeframe: day, hour (for pool_ohlcv)
        api_key: CoinGecko Pro API key (or set COINGECKO_API_KEY)
        max_workers: Max parallel workers (default: 5)
        page: Page number for paginated results (default: 1)
        include_ohlcv: Include OHLCV data for pools (default: False)

    Returns:
        RecipeOutput with pool data

    Examples:
        >>> import warpdata as wd
        >>> # Get top pools for WETH on Ethereum
        >>> result = wd.run_recipe(
        ...     "coingecko_dex_pools",
        ...     "warpdata://crypto/coingecko/dex_pools",
        ...     network="eth",
        ...     data_type="top_pools",
        ...     token_addresses=["0xc02aaa39b223fe8d0a0e5c4f27ead9083c756cc2"],
        ...     with_materialize=True
        ... )
    """
    api_key = api_key or os.environ.get("COINGECKO_API_KEY")

    if not api_key:
        raise ValueError("CoinGecko Pro API key required for onchain endpoints. Set COINGECKO_API_KEY environment variable.")

    base = PRO_API_BASE

    print(f"📊 Fetching CoinGecko DEX Pools Data")
    print(f"  Network: {network}")
    print(f"  Data type: {data_type}")
    print(f"  Max workers: {max_workers}")

    all_records = []

    # Fetch DEX list
    if data_type == "dexes":
        print(f"\n  🔄 Fetching DEX list for {network}...")
        url = f"{base}/onchain/networks/{network}/dexes"

        try:
            response = _http_get_json(url, api_key=api_key)
            dexes = response.get("data", [])

            for dex in dexes:
                record = {
                    "network": network,
                    "dex_id": dex.get("id"),
                    "type": dex.get("type"),
                    "name": dex.get("attributes", {}).get("name"),
                    "fetched_at": datetime.now(timezone.utc).isoformat(),
                }
                all_records.append(record)

            print(f"  ✓ Fetched {len(all_records)} DEXes")
        except Exception as e:
            print(f"  ❌ Failed to fetch DEXes: {e}")
            raise

    # Fetch top pools by token
    elif data_type == "top_pools":
        if not token_addresses:
            raise ValueError("token_addresses required for top_pools data type")

        print(f"\n  🔄 Fetching top pools for {len(token_addresses)} token(s)...")

        def fetch_token_pools(token_address: str) -> List[Dict]:
            try:
                url = f"{base}/onchain/networks/{network}/tokens/{token_address}/pools"
                params = {"page": page}

                response = _http_get_json(url, params, api_key=api_key)
                pools = response.get("data", [])
                included = response.get("included", [])

                # Build token lookup
                tokens = {}
                for item in included:
                    if item.get("type") == "token":
                        tokens[item["id"]] = item["attributes"]

                records = []
                for pool in pools:
                    attrs = pool.get("attributes", {})
                    rels = pool.get("relationships", {})

                    # Get base/quote token info
                    base_token_id = rels.get("base_token", {}).get("data", {}).get("id")
                    quote_token_id = rels.get("quote_token", {}).get("data", {}).get("id")
                    dex_id = rels.get("dex", {}).get("data", {}).get("id")

                    base_token = tokens.get(base_token_id, {})
                    quote_token = tokens.get(quote_token_id, {})

                    record = {
                        "network": network,
                        "pool_id": pool.get("id"),
                        "pool_address": attrs.get("address"),
                        "pool_name": attrs.get("name"),
                        "dex_id": dex_id,
                        "base_token_address": base_token.get("address"),
                        "base_token_symbol": base_token.get("symbol"),
                        "base_token_name": base_token.get("name"),
                        "quote_token_address": quote_token.get("address"),
                        "quote_token_symbol": quote_token.get("symbol"),
                        "quote_token_name": quote_token.get("name"),
                        "base_token_price_usd": attrs.get("base_token_price_usd"),
                        "quote_token_price_usd": attrs.get("quote_token_price_usd"),
                        "fdv_usd": attrs.get("fdv_usd"),
                        "market_cap_usd": attrs.get("market_cap_usd"),
                        "reserve_in_usd": attrs.get("reserve_in_usd"),
                        "volume_usd_h24": attrs.get("volume_usd", {}).get("h24"),
                        "volume_usd_h6": attrs.get("volume_usd", {}).get("h6"),
                        "volume_usd_h1": attrs.get("volume_usd", {}).get("h1"),
                        "price_change_pct_h24": attrs.get("price_change_percentage", {}).get("h24"),
                        "price_change_pct_h6": attrs.get("price_change_percentage", {}).get("h6"),
                        "price_change_pct_h1": attrs.get("price_change_percentage", {}).get("h1"),
                        "txns_h24_buys": attrs.get("transactions", {}).get("h24", {}).get("buys"),
                        "txns_h24_sells": attrs.get("transactions", {}).get("h24", {}).get("sells"),
                        "pool_created_at": attrs.get("pool_created_at"),
                        "fetched_at": datetime.now(timezone.utc).isoformat(),
                    }
                    records.append(record)

                return records
            except Exception as e:
                print(f"    ❌ {token_address}: {e}")
                return []

        with ThreadPoolExecutor(max_workers=max_workers) as executor:
            futures = {executor.submit(fetch_token_pools, addr): addr for addr in token_addresses}

            for future in as_completed(futures):
                addr = futures[future]
                records = future.result()
                all_records.extend(records)
                print(f"    [{len(all_records)} total] ✓ {addr}: {len(records)} pools")

    # Fetch pool info
    elif data_type == "pool_info":
        if not pool_addresses:
            raise ValueError("pool_addresses required for pool_info data type")

        print(f"\n  🔄 Fetching info for {len(pool_addresses)} pool(s)...")

        def fetch_pool_info(pool_address: str) -> List[Dict]:
            try:
                url = f"{base}/onchain/networks/{network}/pools/{pool_address}/info"

                response = _http_get_json(url, api_key=api_key)
                data = response.get("data", [])
                included = response.get("included", [])

                # Extract pool metadata from included
                pool_meta = {}
                for item in included:
                    if item.get("type") == "pool":
                        pool_meta = item.get("attributes", {})

                records = []
                for token in data:
                    attrs = token.get("attributes", {})

                    record = {
                        "network": network,
                        "pool_address": pool_address,
                        "token_address": attrs.get("address"),
                        "token_name": attrs.get("name"),
                        "token_symbol": attrs.get("symbol"),
                        "coingecko_coin_id": attrs.get("coingecko_coin_id"),
                        "gt_score": attrs.get("gt_score"),
                        "holders_count": attrs.get("holders", {}).get("count"),
                        "is_honeypot": attrs.get("is_honeypot"),
                        "base_token_address": pool_meta.get("base_token_address"),
                        "quote_token_address": pool_meta.get("quote_token_address"),
                        "fetched_at": datetime.now(timezone.utc).isoformat(),
                    }
                    records.append(record)

                return records
            except Exception as e:
                print(f"    ❌ {pool_address}: {e}")
                return []

        with ThreadPoolExecutor(max_workers=max_workers) as executor:
            futures = {executor.submit(fetch_pool_info, addr): addr for addr in pool_addresses}

            for future in as_completed(futures):
                addr = futures[future]
                records = future.result()
                all_records.extend(records)
                print(f"    [{len(all_records)} total] ✓ {addr}: {len(records)} tokens")

    # Fetch pool OHLCV
    elif data_type == "pool_ohlcv":
        if not pool_addresses:
            raise ValueError("pool_addresses required for pool_ohlcv data type")

        print(f"\n  🔄 Fetching OHLCV for {len(pool_addresses)} pool(s)...")
        print(f"  Timeframe: {timeframe}")

        def fetch_pool_ohlcv(pool_address: str) -> List[Dict]:
            try:
                url = f"{base}/onchain/networks/{network}/pools/{pool_address}/ohlcv/{timeframe}"

                response = _http_get_json(url, api_key=api_key)
                ohlcv_list = response.get("data", {}).get("attributes", {}).get("ohlcv_list", [])
                meta = response.get("meta", {})

                base_token = meta.get("base", {})
                quote_token = meta.get("quote", {})

                records = []
                for candle in ohlcv_list:
                    if len(candle) < 6:
                        continue

                    timestamp, open_price, high, low, close, volume = candle

                    record = {
                        "network": network,
                        "pool_address": pool_address,
                        "timestamp": datetime.fromtimestamp(timestamp, tz=timezone.utc).isoformat(),
                        "timeframe": timeframe,
                        "open": open_price,
                        "high": high,
                        "low": low,
                        "close": close,
                        "volume": volume,
                        "base_token_address": base_token.get("address"),
                        "base_token_symbol": base_token.get("symbol"),
                        "quote_token_address": quote_token.get("address"),
                        "quote_token_symbol": quote_token.get("symbol"),
                        "fetched_at": datetime.now(timezone.utc).isoformat(),
                    }
                    records.append(record)

                return records
            except Exception as e:
                print(f"    ❌ {pool_address}: {e}")
                return []

        with ThreadPoolExecutor(max_workers=max_workers) as executor:
            futures = {executor.submit(fetch_pool_ohlcv, addr): addr for addr in pool_addresses}

            for future in as_completed(futures):
                addr = futures[future]
                records = future.result()
                all_records.extend(records)
                print(f"    [{len(all_records)} total] ✓ {addr}: {len(records)} candles")

    else:
        raise ValueError(f"Invalid data_type: {data_type}. Must be one of: dexes, top_pools, pool_info, pool_ohlcv")

    if not all_records:
        raise ValueError(f"No data collected for {data_type}")

    print(f"\n  ✓ Collected {len(all_records):,} records")

    # Create DataFrame
    df = pd.DataFrame(all_records)

    # Try to load existing data and merge
    out_file = ctx.work_dir / f"coingecko_dex_{data_type}.parquet"
    if out_file.exists():
        try:
            from ..api import load
            existing_df = load(ctx.dataset_id, as_format="pandas")
            print(f"\n  📦 Found existing dataset: {len(existing_df):,} records")

            df = pd.concat([existing_df, df], ignore_index=True)

            # Deduplicate based on data type
            if data_type == "dexes":
                dedup_cols = ["network", "dex_id"]
            elif data_type == "top_pools":
                dedup_cols = ["network", "pool_address", "fetched_at"]
            elif data_type == "pool_info":
                dedup_cols = ["network", "pool_address", "token_address"]
            elif data_type == "pool_ohlcv":
                dedup_cols = ["network", "pool_address", "timestamp", "timeframe"]

            initial_count = len(df)
            df = df.drop_duplicates(subset=dedup_cols, keep="last")
            if len(df) < initial_count:
                print(f"  🧹 Removed {initial_count - len(df):,} duplicates")
        except Exception as e:
            print(f"  ℹ️  No existing dataset: {e}")

    # Sort
    if data_type == "pool_ohlcv":
        df = df.sort_values(["pool_address", "timestamp"])
    elif data_type == "top_pools":
        if "volume_usd_h24" in df.columns:
            df = df.sort_values("volume_usd_h24", ascending=False)

    df = df.reset_index(drop=True)

    # Save
    df.to_parquet(out_file, index=False)

    print(f"\n  ✅ Saved {len(df):,} records")
    print(f"  📊 Columns: {list(df.columns)}")

    readme = f"""# CoinGecko DEX Pools Data

## Overview
DEX pool data from CoinGecko onchain API

## Configuration
- **Network**: {network}
- **Data Type**: {data_type}
- **Records**: {len(df):,}

## Schema

{df.dtypes.to_string()}

## Usage

```python
import warpdata as wd

# Load data
df = wd.load("{ctx.dataset_id}", as_format="pandas")

# Example queries
top_volume = df.nlargest(10, 'volume_usd_h24')
```

## Statistics
- Total records: {len(df):,}
- Network: {network}
- Data type: {data_type}
"""

    return RecipeOutput(
        main=[out_file],
        docs={"README.md": readme},
        metadata={
            "network": network,
            "data_type": data_type,
            "records": len(df),
            "source": "CoinGecko Onchain API",
        },
    )
