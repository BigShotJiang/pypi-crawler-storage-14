"""
Polygon Options dataset recipe (FIXED VERSION).

Fetches historical options data from Polygon.io API with proper schema flattening.
Focus on chain snapshots (greeks, IV, OI) per underlying.

Source: Polygon.io Options API
"""
from pathlib import Path
from typing import List, Optional, Dict, Any
import json
import pandas as pd
import sys
import os
from concurrent.futures import ThreadPoolExecutor, as_completed
from tqdm import tqdm

from ..api.recipes import RecipeContext
from .base import RecipeOutput, SubDataset


def flatten_chain_snapshot(record: Dict[str, Any], date: str) -> Dict[str, Any]:
    """
    Flatten nested chain snapshot structure into flat dict.

    Handles:
    - Empty greeks {}
    - Missing fields
    - Nested structures (day, details, last_quote, etc.)
    """
    flat = {}

    # Add date
    flat['date'] = date

    # Top-level simple fields
    flat['break_even_price'] = record.get('break_even_price')
    flat['open_interest'] = record.get('open_interest')

    # Details (contract info)
    if 'details' in record and isinstance(record['details'], dict):
        details = record['details']
        flat['ticker'] = details.get('ticker')
        flat['contract_type'] = details.get('contract_type')
        flat['strike_price'] = details.get('strike_price')
        flat['expiration_date'] = details.get('expiration_date')
        flat['exercise_style'] = details.get('exercise_style')
        flat['shares_per_contract'] = details.get('shares_per_contract')

    # Day OHLC (option's daily trading data)
    if 'day' in record and isinstance(record['day'], dict):
        day = record['day']
        flat['day_open'] = day.get('open')
        flat['day_high'] = day.get('high')
        flat['day_low'] = day.get('low')
        flat['day_close'] = day.get('close')
        flat['day_volume'] = day.get('volume')
        flat['day_vwap'] = day.get('vwap')
        flat['day_change'] = day.get('change')
        flat['day_change_percent'] = day.get('change_percent')
        flat['day_previous_close'] = day.get('previous_close')

    # Greeks (CAN BE EMPTY!)
    greeks = record.get('greeks', {})
    if isinstance(greeks, dict):
        flat['delta'] = greeks.get('delta')
        flat['gamma'] = greeks.get('gamma')
        flat['theta'] = greeks.get('theta')
        flat['vega'] = greeks.get('vega')
    else:
        flat['delta'] = None
        flat['gamma'] = None
        flat['theta'] = None
        flat['vega'] = None

    # Last Quote (bid/ask)
    if 'last_quote' in record and isinstance(record['last_quote'], dict):
        quote = record['last_quote']
        flat['bid'] = quote.get('bid')
        flat['ask'] = quote.get('ask')
        flat['bid_size'] = quote.get('bid_size')
        flat['ask_size'] = quote.get('ask_size')
        flat['midpoint'] = quote.get('midpoint')
        flat['bid_exchange'] = quote.get('bid_exchange')
        flat['ask_exchange'] = quote.get('ask_exchange')

    # Last Trade
    if 'last_trade' in record and isinstance(record['last_trade'], dict):
        trade = record['last_trade']
        flat['last_trade_price'] = trade.get('price')
        flat['last_trade_size'] = trade.get('size')
        flat['last_trade_exchange'] = trade.get('exchange')

        # Convert conditions list to string
        conditions = trade.get('conditions', [])
        if conditions:
            flat['last_trade_conditions'] = ','.join(map(str, conditions))
        else:
            flat['last_trade_conditions'] = None

    # Underlying Asset
    if 'underlying_asset' in record and isinstance(record['underlying_asset'], dict):
        underlying = record['underlying_asset']
        flat['underlying_ticker'] = underlying.get('ticker')
        flat['underlying_price'] = underlying.get('price')
        flat['change_to_break_even'] = underlying.get('change_to_break_even')

    # Implied Volatility (if present at top level)
    flat['implied_volatility'] = record.get('implied_volatility')

    return flat


def polygon_options(
    ctx: RecipeContext,
    start_date: str,
    end_date: str,
    *,
    underlyings: List[str],
    polygon_api_key: Optional[str] = None,
    raw_data_dir: Optional[str] = None,
    max_workers: int = 10,
) -> RecipeOutput:
    """
    Create Polygon Options dataset with properly flattened chain snapshots.

    Downloads option chain data (greeks, IV, OI) for specific underlyings.

    Args:
        ctx: Recipe context
        start_date: Start date (YYYY-MM-DD)
        end_date: End date (YYYY-MM-DD)
        underlyings: List of underlying tickers (e.g., ["SPY", "QQQ", "TSLA"])
        polygon_api_key: Polygon API key (or set POLYGON_API_KEY env var)
        raw_data_dir: Directory to store raw JSON files
        max_workers: Number of parallel workers for date downloads (default: 10)

    Returns:
        RecipeOutput with chain snapshot data per underlying

    Examples:
        >>> import warpdata as wd
        >>> # Fetch SPY option chain
        >>> result = wd.run_recipe(
        ...     "polygon_options",
        ...     "warpdata://options/spy-2025-01-17",
        ...     start_date="2025-01-17",
        ...     end_date="2025-01-17",
        ...     underlyings=["SPY"],
        ...     with_materialize=True
        ... )
        >>> df = wd.load("warpdata://options/spy-2025-01-17", as_format="pandas")
    """
    # Import polygon ETL
    polygon_etl_path = Path("/home/alerad/workspace/option_pricing/options_etl")
    if polygon_etl_path.exists():
        sys.path.insert(0, str(polygon_etl_path.parent))

    try:
        from options_etl.polygon_etl_module import PolygonETLAPI
    except ImportError as e:
        raise ImportError(
            f"Could not import polygon_etl_module. "
            f"Make sure /home/alerad/workspace/option_pricing is accessible"
        ) from e

    # Get API key
    api_key = polygon_api_key or os.environ.get("POLYGON_API_KEY")
    if not api_key:
        raise ValueError(
            "Polygon API key required. Set POLYGON_API_KEY env var"
        )

    if not underlyings:
        raise ValueError("Must specify at least one underlying ticker")

    print(f"📊 Fetching Polygon Options data from {start_date} to {end_date}")
    print(f"   Underlyings: {', '.join(underlyings)}")

    # Use global raw data directory if not specified
    if raw_data_dir is None:
        raw_data_dir = str(Path.home() / ".warpdata" / "polygon_raw_data" / "polygon_options")

    # Create raw data directory
    raw_dir = Path(raw_data_dir)
    raw_dir.mkdir(parents=True, exist_ok=True)

    # Initialize Polygon ETL API
    etl = PolygonETLAPI(api_key=api_key)

    subdatasets = {}
    metadata = {
        "start_date": start_date,
        "end_date": end_date,
        "underlyings": underlyings,
        "source": "Polygon.io Options API",
        "data_type": "options_chain_snapshots",
    }

    # Process each underlying
    import datetime as dt

    # Accumulate all underlyings into a single combined dataset
    combined_frames = []

    for underlying in underlyings:
        print(f"\n📈 Processing {underlying}...")

        chain_dir = raw_dir / "snapshot_chain" / underlying
        chain_dir.mkdir(parents=True, exist_ok=True)

        all_records = []

        # Build list of all trading dates (skip weekends)
        current = dt.datetime.fromisoformat(start_date).date()
        end = dt.datetime.fromisoformat(end_date).date()
        all_dates = []

        while current <= end:
            if current.weekday() < 5:  # Weekdays only
                all_dates.append(current.isoformat())
            current += dt.timedelta(days=1)

        # Separate into cached and uncached dates
        dates_to_download = []
        dates_cached = []

        for date_str in all_dates:
            json_file = chain_dir / f"{date_str}.json"
            if json_file.exists():
                dates_cached.append(date_str)
            else:
                dates_to_download.append(date_str)

        print(f"  📊 Total dates: {len(all_dates)} ({len(dates_cached)} cached, {len(dates_to_download)} to download)")

        # Download uncached dates in parallel with progress bar
        if dates_to_download:
            def download_date(date_str):
                """Download options for a single date."""
                json_file = chain_dir / f"{date_str}.json"
                try:
                    result = etl.fetch_chain_snapshot(
                        underlying,
                        date_str,
                        out=str(json_file)
                    )
                    return (date_str, result.get('count', 0), None)
                except Exception as e:
                    return (date_str, 0, str(e))

            with ThreadPoolExecutor(max_workers=max_workers) as executor:
                futures = {executor.submit(download_date, date_str): date_str
                          for date_str in dates_to_download}

                with tqdm(total=len(dates_to_download), desc=f"  Downloading {underlying}",
                         unit="day", ncols=100) as pbar:
                    for future in as_completed(futures):
                        date_str, count, error = future.result()
                        if error:
                            pbar.write(f"    ⚠️  {date_str}: {error}")
                        pbar.update(1)

        # Now load and flatten all dates (cached + newly downloaded)
        print(f"  📂 Loading and flattening {len(all_dates)} dates...")

        for date_str in tqdm(all_dates, desc=f"  Processing {underlying}", unit="day", ncols=100):
            json_file = chain_dir / f"{date_str}.json"

            if json_file.exists():
                try:
                    with open(json_file) as f:
                        data = json.load(f)

                    # Handle both list and dict responses
                    if isinstance(data, list):
                        raw_results = data
                    elif isinstance(data, dict):
                        raw_results = data.get('results', [])
                    else:
                        raw_results = []

                    # Flatten each record
                    for raw in raw_results:
                        flat = flatten_chain_snapshot(raw, date_str)
                        all_records.append(flat)

                except Exception as e:
                    tqdm.write(f"    ⚠️  Failed to parse {json_file}: {e}")

        if all_records:
            print(f"\n  Total records for {underlying}: {len(all_records):,}")

            # Convert to DataFrame
            df = pd.DataFrame(all_records)

            # Ensure proper column order
            column_order = [
                'date', 'ticker', 'underlying_ticker', 'contract_type',
                'strike_price', 'expiration_date',
                'day_open', 'day_high', 'day_low', 'day_close', 'day_volume', 'day_vwap',
                'delta', 'gamma', 'theta', 'vega',
                'bid', 'ask', 'midpoint', 'bid_size', 'ask_size',
                'open_interest', 'implied_volatility',
                'underlying_price', 'break_even_price',
            ]

            # Reorder columns (only those that exist)
            existing_cols = [col for col in column_order if col in df.columns]
            other_cols = [col for col in df.columns if col not in column_order]
            df = df[existing_cols + other_cols]

            # Save per-underlying parquet for subdataset view
            output_file = ctx.work_dir / f"polygon_options_{underlying.lower()}.parquet"
            df.to_parquet(output_file, index=False)

            print(f"  ✓ Saved to {output_file.name}")
            print(f"\n  📊 Sample data:")
            print(df[['ticker', 'contract_type', 'strike_price', 'day_close', 'delta']].head(3))

            # Add to subdatasets
            subdatasets[underlying.lower()] = SubDataset(
                name=underlying.lower(),
                files=[output_file],
                description=f"Option chain snapshots for {underlying}",
                metadata={
                    "underlying": underlying,
                    "records": len(df),
                    "date_range": f"{df['date'].min()} to {df['date'].max()}",
                    "contract_types": df['contract_type'].value_counts().to_dict() if 'contract_type' in df.columns else {},
                }
            )

            # Stage for single combined dataset
            combined_frames.append(df)
        else:
            print(f"  ⚠️  No records found for {underlying}")

    if not subdatasets:
        raise ValueError("No options data downloaded")

    # Create/update single combined dataset that contains ALL underlyings
    combined_path = ctx.work_dir / "polygon_options.parquet"
    if combined_frames:
        combined_df = pd.concat(combined_frames, ignore_index=True)

        # Append to existing combined file if present, with dedup by (date, ticker)
        if combined_path.exists():
            try:
                existing_df = pd.read_parquet(combined_path)
                print(f"  📎 Existing combined rows: {len(existing_df):,}")
                combined_df = pd.concat([existing_df, combined_df], ignore_index=True)
            except Exception as e:
                print(f"  ⚠️  Failed to read existing combined dataset: {e}")

        # Deduplicate by snapshot date + option contract ticker
        if {'date', 'ticker'}.issubset(set(combined_df.columns)):
            before = len(combined_df)
            combined_df = combined_df.drop_duplicates(subset=["date", "ticker"], keep="last")
            after = len(combined_df)
            if after != before:
                print(f"  🧹 Deduplicated combined dataset: {before:,} -> {after:,}")

        combined_df.to_parquet(combined_path, index=False)
        print(f"  ✅ Wrote combined options dataset: {combined_path.name} ({len(combined_df):,} rows)")
        metadata["combined_records"] = len(combined_df)
        metadata["combined_file"] = combined_path.name
    else:
        # Shouldn't happen because subdatasets already checked, but be safe
        raise ValueError("No records accumulated for combined options dataset")

    # Use the single combined file as the main dataset
    main_files = [combined_path]

    # Generate documentation
    readme = f"""# Polygon Options Chain Dataset

## Overview
Option chain snapshots from Polygon.io with greeks, IV, and OI.

## Configuration
- **Date Range**: {start_date} to {end_date}
- **Underlyings**: {', '.join(underlyings)}
- **Per-underlying Views**: {len(subdatasets)}
- **Main Dataset**: Single table with all underlyings

## Schema

All nested fields have been flattened into a single table:

### Contract Details
- `ticker` - Option ticker (O:SPY251021C00500000)
- `underlying_ticker` - Underlying stock (SPY)
- `contract_type` - "call" or "put"
- `strike_price` - Strike price
- `expiration_date` - Expiration date

### Day OHLC (Option Trading)
- `day_open`, `day_high`, `day_low`, `day_close`
- `day_volume`, `day_vwap`
- `day_change_percent`

### Greeks
- `delta`, `gamma`, `theta`, `vega`
- ⚠️ Can be NULL if not calculated

### Quote Data
- `bid`, `ask`, `midpoint`
- `bid_size`, `ask_size`

### Other
- `open_interest` - Open interest
- `implied_volatility` - IV (if available)
- `underlying_price` - Current stock price
- `break_even_price` - Break-even price

## Usage

```python
import warpdata as wd

df = wd.load("{ctx.dataset_id}", as_format="pandas")

# Filter calls only
calls = df[df['contract_type'] == 'call']

# Find ATM options
atm = df[
    (df['strike_price'] >= df['underlying_price'] - 5) &
    (df['strike_price'] <= df['underlying_price'] + 5)
]

# Sort by delta
sorted_by_delta = df.sort_values('delta', ascending=False)
```

## Statistics
"""

    for name, subdataset in subdatasets.items():
        readme += f"\n### {name.upper()}\n"
        readme += f"- Records: {subdataset.metadata.get('records', 0):,}\n"
        readme += f"- Date Range: {subdataset.metadata.get('date_range', 'N/A')}\n"
        if 'contract_types' in subdataset.metadata:
            readme += f"- Contract Types: {subdataset.metadata['contract_types']}\n"

    # Track raw data provenance
    raw_data_paths = []
    if raw_dir.exists():
        raw_data_paths.append(raw_dir.absolute())

    return RecipeOutput(
        main=main_files,
        subdatasets=subdatasets,
        docs={"README.md": readme},
        metadata=metadata,
        raw_data=raw_data_paths,
    )
