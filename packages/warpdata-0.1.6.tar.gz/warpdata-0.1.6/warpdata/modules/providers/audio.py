from __future__ import annotations
from ..base import BaseWarpDatasetModule


class VCTKModule(BaseWarpDatasetModule):
    id = "warp.dataset.vctk"
    version = "1.0.0"
    dataset_uri = "warpdata://audio/vctk"


class VCTKSpeakersModule(BaseWarpDatasetModule):
    id = "warp.dataset.vctk_speakers"
    version = "1.0.0"
    dataset_uri = "warpdata://audio/vctk-speakers"

