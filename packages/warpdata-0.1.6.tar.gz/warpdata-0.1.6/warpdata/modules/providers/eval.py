from __future__ import annotations
from ..base import BaseWarpDatasetModule


class MMLUModule(BaseWarpDatasetModule):
    id = "warp.dataset.mmlu"
    version = "1.0.0"
    dataset_uri = "warpdata://eval/mmlu"

