"""
warpdata: A High-Performance Pythonic Data SDK

A developer-first toolkit for accessing, versioning, and augmenting
datasets for analytics and machine learning.
"""

__version__ = "0.1.6"

# Core data loading API
from .api.data import load, schema, head

# Streaming API for huge datasets
from .api.streaming import stream, stream_batch_dicts

# Dataset management API
from .api.management import (
    register_dataset,
    list_datasets,
    list_subdatasets,
    dataset_info,
    materialize,
    verify_dataset,
    verify_datasets,
    remove_dataset,
)

# Embeddings API
from .api.embeddings import (
    add_embeddings,
    load_embeddings,
    search_embeddings,
    join_results,
    list_embeddings,
    remove_embeddings,
    migrate_embeddings_to_latest,
)

# Recipes API
from .api.recipes import (
    register_recipe,
    list_recipes,
    run_recipe,
    reset_recipes,
    RecipeContext,
)

# Storage & Provenance API
from .api.storage import (
    get_raw_data_sources,
    backup_dataset,
    restore_dataset,
    sync_to_cloud,
    export_registry,
    import_registry,
    list_remote_datasets,
    pull_dataset,
    pull_all_datasets,
)

# Register built-in recipes after imports are complete
try:
    from .recipes import register_builtin_recipes
    register_builtin_recipes()
except Exception as e:  # optional recipes may have extra deps
    import warnings
    warnings.warn(f"Skipping recipe registration: {e}")

# Re-export for convenience
__all__ = [
    # Data loading
    "load",
    "schema",
    "head",
    "stream",
    "stream_batch_dicts",
    # Management
    "register_dataset",
    "list_datasets",
    "list_subdatasets",
    "dataset_info",
    "materialize",
    "verify_dataset",
    "verify_datasets",
    "remove_dataset",
    # Embeddings
    "add_embeddings",
    "load_embeddings",
    "search_embeddings",
    "join_results",
    "list_embeddings",
    "remove_embeddings",
    "migrate_embeddings_to_latest",
    # Modules
    "get_module",
    # Recipes
    "register_recipe",
    "list_recipes",
    "run_recipe",
    "reset_recipes",
    "RecipeContext",
    # Storage & Provenance
    "get_raw_data_sources",
    "backup_dataset",
    "restore_dataset",
    "sync_to_cloud",
    "export_registry",
    "import_registry",
    # Version
    "__version__",
]

# Modules API (import placed after __all__ declaration to avoid circulars)
from .modules import get_module  # noqa: E402
