from litestar import Litestar

from src.auth.api import auth_router
from src.auth.plugin import AuthPlugin
from src.core.database import sqlalchemy_plugin
from src.core.openapi import openapi_config


def create_app():
    app = Litestar(
        route_handlers=[auth_router],
        plugins=[sqlalchemy_plugin, AuthPlugin()],
        openapi_config=openapi_config,
        debug=True,
    )
    return app
