"""Raw resource files used by higher-level data loaders."""
