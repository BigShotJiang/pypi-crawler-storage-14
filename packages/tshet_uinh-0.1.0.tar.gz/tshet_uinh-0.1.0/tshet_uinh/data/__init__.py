"""Expose the public data helpers so callers can import them ergonomically."""

from . import 廣韻, 廣韻impl

__all__ = ["廣韻", "廣韻impl"]
