# Authors List (in alphabetical order)
Alessandro Bono <alessandro.bono369@gmail.com>
Andrea Curtoni <andrea.curtoni@nice-software.com>
Andrei Fadeev <andrei@webcontrol.ru>
Arnav Singh <arnavion@gmail.com>
Austin Garbelman <aaus@amazon.com>
Berke Viktor <bviktor@outlook.com>
BiagioFesta <15035284+BiagioFesta@users.noreply.github.com>
Bing Yu <B.yu@techsmith.com>
Catherine Holloway <milankie@gmail.com>
Christoph Reiter <reiter.christoph@gmail.com>
Chungrae Cho <hsccr@amk.ne.kr>
Clayton Walker <clayton.m.walker@gmail.com>
Cong Monkey <congzhangzh@gmail.com>
Cosimo Lupo <cosimo.lupo@daltonmaag.com>
Dan Yeaw <dan@yeaw.me>
Daniele Forghieri <daniele.forghieri@gmail.com>
Dimitrii Nikolaev <nikolaev@ift.at>
Elias Carotti <eliascrt@amazon.it>
Eustachy Kapusta <Eustachy.kapusta@gmail.com>
Fabio Lagalla <lagfabio@amazon.com>
Felipe "Zoc" Silveira <TheZoc@users.noreply.github.com>
Francesco Locunto <francesco.locunto@nice-software.com>
Henry Goffin <hgoffin@amazon.com>
Hesham Essam <hesham.essam.mail@gmail.com>
Ignacio Casal Quinteiro <icq@gnome.org>
Ignazio Pillai <ignazp@amazon.com>
Jakub Ďuračka <kubo.duracka@gmail.com>
Jeff <jeff@stargazystudios.com>
Jendrik Seipp <jendrikseipp@gmail.com>
John Stowers <john.stowers@gmail.com>
Leo Zi-You Assini <leoziyou@amazon.it>
Luke Berry <luke@braid.com>
Marco Alesiani <alesiani@amazon.com>
Marco Capypara Köpcke <hello@capypara.de>
Martin Hertz <mvhertz@gmail.com>
Matteo Biggio <biggio@amazon.com>
Mavaddat Javid <javid@mavaddat.ca>
Mehrdad Montazeri <mmontaze@amazon.com>
Mike Gran <spk121@yahoo.com>
Miroslav Rajcic <miroslav.rajcic@inet.hr>
Mitchell Hentges <mitch9654@gmail.com>
Nefo Fortressia <nefothingy@hotmail.com>
Paolo Borelli <pborelli@gnome.org>
Patrick Griffis <tingping@tingping.se>
Roberto Tronci<roberto.tronci@bittree.it>
San <sganis@gmail.com>
Silvio Lazzeretti<silviola@amazon.com>
Stefan Lau <github@stefanlau.com>
Stefano Sabatini <sabatin@amazon.com>
Steve Elgas <s.elgas@techsmith.com>
Tim Williams <tjandacw@gmail.com>
Vedavi Balaji <vedavi.balaji@gmail.com>
Vite <nuget@list.ru>
Vittorio Vaselli <vitvas@amazon.com>
Yihua Liu <yihuajack@live.cn>
