#  Copyright (C) 2016 The Gvsbuild Authors
#
#  This program is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; either version 2 of the License, or
#  (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, see <http://www.gnu.org/licenses/>.
from gvsbuild.utils.base_builders import Meson
from gvsbuild.utils.base_expanders import Tarball
from gvsbuild.utils.base_project import Project, project_add


@project_add
class Libsigcplusplus(Tarball, Meson):
    def __init__(self):
        Project.__init__(
            self,
            "libsigc++",
            prj_dir="libsigc++",
            version="3.8.0",
            lastversion_even=True,
            repository="https://github.com/libsigcplusplus/libsigcplusplus",
            archive_url="https://github.com/libsigcplusplus/libsigcplusplus/releases/download/{version}/libsigc++-{version}.tar.xz",
            hash="502a743bb07ed7627dd41bd85ec4b93b4954f06b531adc45818d24a959f54e36",
            dependencies=[
                "meson",
                "ninja",
            ],
        )

    def build(self):
        Meson.build(
            self,
            meson_params="-Dbuild-examples=false -Dbuild-documentation=false",
        )

        self.install(r".\COPYING share\doc\libsigc++")


@project_add
class Libsigcplusplus2(Tarball, Meson):
    def __init__(self):
        Project.__init__(
            self,
            "libsigc++-2.0",
            prj_dir="libsigc++-2.0",
            version="2.12.1",
            lastversion_even=True,
            lastversion_major=2,
            repository="https://github.com/libsigcplusplus/libsigcplusplus",
            archive_url="https://github.com/libsigcplusplus/libsigcplusplus/releases/download/{version}/libsigc++-{version}.tar.xz",
            hash="a9dbee323351d109b7aee074a9cb89ca3e7bcf8ad8edef1851f4cf359bd50843",
            dependencies=[
                "meson",
                "ninja",
            ],
        )

    def build(self):
        Meson.build(
            self,
            meson_params="-Dbuild-examples=false -Dbuild-documentation=false",
        )

        self.install(r".\COPYING share\doc\libsigc++-2.0")
