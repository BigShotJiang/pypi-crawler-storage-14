 * For each project, delete
	* `^\s*<Optimization.*\r\n`
	* `^\s*<PlatformToolset>.*\r\n`
