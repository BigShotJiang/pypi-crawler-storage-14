// test for libffi

// include
    #include "check_utils.h"
    // library
    #include <ffi.h>

CHECK_ONE(ffi_call)
