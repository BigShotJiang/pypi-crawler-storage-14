// test for pango

// include
    #include "check_utils.h"
    // library
    #include <pango/pango.h>

// check one function from the dll
CHECK_ONE(pango_version)
