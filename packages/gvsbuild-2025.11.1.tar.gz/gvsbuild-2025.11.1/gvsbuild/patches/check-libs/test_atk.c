// test for atk

// include
    #include "check_utils.h"
    // library
    #include <atk/atk.h>

// check one function from the dll
CHECK_ONE(atk_get_major_version)
