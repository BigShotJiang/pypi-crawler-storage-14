// test for wing

// include
    #include "check_utils.h"
    // library
    #include <wing/wing.h>

// check one function from the dll
CHECK_ONE(wing_get_version_number)
