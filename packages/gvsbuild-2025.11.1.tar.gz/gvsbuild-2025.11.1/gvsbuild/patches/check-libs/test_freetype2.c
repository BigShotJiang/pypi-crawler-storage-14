// test for freetype2

// include
    // standard
    #include "check_utils.h"
    // library
    #include <ft2build.h>
    #include FT_FREETYPE_H

// check one function from the dll
CHECK_ONE(FT_Init_FreeType)

