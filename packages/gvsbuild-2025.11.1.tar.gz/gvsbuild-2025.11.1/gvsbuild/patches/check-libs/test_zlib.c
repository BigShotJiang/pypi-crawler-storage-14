// test for zlib

// include
    #include "check_utils.h"
    // library
    #include <zlib.h>

CHECK_ONE(zlibVersion)
