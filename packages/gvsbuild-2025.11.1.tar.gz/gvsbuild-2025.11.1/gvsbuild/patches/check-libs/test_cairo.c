// test for cairo

// include
    #include "check_utils.h"
    // library
    #include <cairo.h>

// check one function from the dll
CHECK_ONE(cairo_version)
