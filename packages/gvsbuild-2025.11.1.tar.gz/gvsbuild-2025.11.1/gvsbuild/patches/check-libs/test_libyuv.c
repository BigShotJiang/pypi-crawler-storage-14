// test for libjpeg

// include
    // standard
    #include "check_utils.h"
    // library
    #include <libyuv.h>

// check one function from the dll
CHECK_ONE(ConvertToI420)
