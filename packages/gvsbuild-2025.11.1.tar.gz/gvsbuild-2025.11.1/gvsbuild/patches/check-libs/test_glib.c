// test for glib

// include
    #include "check_utils.h"
    // library
    #include <glib.h>

// check one function from the dll
CHECK_ONE(glib_check_version)
