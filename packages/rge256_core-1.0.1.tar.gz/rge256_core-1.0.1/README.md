RGE256 Core Python Package — Version 1.0.1
