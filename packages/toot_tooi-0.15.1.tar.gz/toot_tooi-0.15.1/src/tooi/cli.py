import dataclasses
import logging
import platform
import sys
from os import path
from typing import Optional

import click
from textual.logging import TextualHandler

from tooi import __version__
from tooi.app import TooiApp
from tooi.auth import NotLoggedInError
from tooi.cache import get_cache_dir
from tooi.context import create_context, set_context
from tooi.settings import Options, get_settings, get_settings_path, get_stylesheet_path
from tooi.utils.file import format_size


def get_default_map():
    return dataclasses.asdict(get_settings().options)


# Tweak the Click context
# https://click.palletsprojects.com/en/8.1.x/api/#context
CONTEXT = dict(
    # Enable using environment variables to set options
    auto_envvar_prefix="TOOI",
    # Add shorthand -h for invoking help
    help_option_names=["-h", "--help"],
    # Always show default values for options
    show_default=True,
    # Load option defaults from settings
    default_map=get_default_map(),
)


@click.command(context_settings=CONTEXT)
@click.option(
    "-S",
    "--always-show-sensitive",
    type=click.BOOL,
    default=None,
    help="Override server preference to expand toots with content warnings automatically",
)
@click.option(
    "-R",
    "--relative-timestamps",
    is_flag=True,
    help="Use relative timestamps in the timeline",
)
@click.option(
    "-r",
    "--timeline-refresh",
    type=click.INT,
    default=0,
    help="How often to automatically refresh timelines (in seconds)",
)
@click.option(
    "-s",
    "--streaming",
    is_flag=True,
    help="Use real-time streaming to fetch timeline updates",
)
@click.option("--env", is_flag=True, help="Print environment data and exit")
@click.version_option(None, "-v", "--version", package_name="toot-tooi")
def tooi(
    always_show_sensitive: Optional[bool],
    relative_timestamps: bool,
    timeline_refresh: int,
    streaming: bool,
    env: bool,
):
    options = Options(
        always_show_sensitive=always_show_sensitive,
        relative_timestamps=relative_timestamps,
        timeline_refresh=timeline_refresh,
        streaming=streaming,
    )

    # Streaming is not reliable, so if it's enabled, force timeline_refresh to be enabled as well;
    # this catches any events that streaming missed.
    if options.streaming and not options.timeline_refresh:
        options.timeline_refresh = 120

    if env:
        print_env(options)
        return

    try:
        ctx = create_context()
    except NotLoggedInError:
        click.secho("Not logged in. Please run `toot login`", fg="red")
        click.secho("Note that tooi at this point requires toot for authentication.", fg="red")
        click.secho("https://toot.bezdomni.net/installation.html", fg="red")
        sys.exit(1)

    ctx.config = get_settings()
    ctx.config.options = options

    set_context(ctx)
    app = TooiApp()
    app.run()


def main():
    logging.basicConfig(level=logging.INFO, handlers=[TextualHandler()])
    logging.getLogger("http").setLevel(logging.WARNING)
    tooi()


def print_env(options: Options):
    click.echo(f"tooi v{__version__}")
    click.echo(f"Python {platform.python_version()}")
    click.echo(f"{platform.platform()}")
    click.echo()

    cache_dir = get_cache_dir()
    cache_size = format_size(cache_dir.stat().st_size)
    click.echo(f"Cache dir: {get_cache_dir()} ({cache_size})")

    settings_path = get_settings_path()
    settings_exists = path.exists(settings_path)
    click.echo(f"Settings: {settings_path} ({'found' if settings_exists else 'not found'})")

    stylesheet_path = get_stylesheet_path()
    stylesheet_exists = path.exists(stylesheet_path)
    click.echo(f"Stylesheet: {stylesheet_path} ({'found' if stylesheet_exists else 'not found'})")
    click.echo()

    click.echo("Options:")
    for k, v in dataclasses.asdict(options).items():
        print(f"    {k} = {v}")
