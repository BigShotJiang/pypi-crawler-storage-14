from markdown_it import MarkdownIt
from textual import widgets
from tooi.widgets.link import Link


class Markdown(widgets.Markdown):
    DEFAULT_CSS = """
    Markdown {
        padding: 0;
    }
    """

    def __init__(
        self,
        markdown: str | None = None,
        *,
        name: str | None = None,
        id: str | None = None,
        classes: str | None = None,
    ):
        super().__init__(
            markdown,
            name=name,
            id=id,
            classes=classes,
            open_links=True,
            # Configure the Markdown parser not to parse inline HTML but leave it as-is
            parser_factory=lambda: MarkdownIt(options_update={"html": False}),
        )

    def _on_markdown_link_clicked(self, message: widgets.Markdown.LinkClicked):
        self.post_message(Link.Clicked(message.href))
        message.stop()
