from __future__ import annotations

from uuid import UUID, uuid4
from textual.reactive import reactive
from textual.widget import Widget


MessageId = UUID
"""Uniquely identifies a message in the status bar allowing it to be cleared."""


class StatusBar(Widget):
    # Height must be 2 because it overlaps the Footer which is 1 high
    DEFAULT_CSS = """
    StatusBar {
        dock: bottom;
        height: 2;
    }
    """

    MAX_TIMEOUT = 60

    messages: reactive[dict[MessageId, str]] = reactive({})

    def render(self):
        return " [gray]|[/gray] ".join([m for m in self.messages.values()])

    def set_message(self, text: str, timeout: float | None = None) -> MessageId:
        """
        Show a message in the status bar.

        The message will be removed after `timeout` seconds have passed (max MAX_TIMEOUT).
        """
        if not timeout or timeout > self.MAX_TIMEOUT:
            timeout = self.MAX_TIMEOUT

        message_id = uuid4()

        def _clear():
            self.clear_message(message_id)

        self.set_timer(timeout, callback=_clear)
        self.messages[message_id] = text
        self.mutate_reactive(StatusBar.messages)
        return message_id

    def clear_message(self, message_id: MessageId | None):
        """
        Clear a message with given ID before its timeout has expired.

        Does nothing if the message has already exired or message_id is None.
        """
        if message_id and message_id in self.messages:
            del self.messages[message_id]
            self.mutate_reactive(StatusBar.messages)
