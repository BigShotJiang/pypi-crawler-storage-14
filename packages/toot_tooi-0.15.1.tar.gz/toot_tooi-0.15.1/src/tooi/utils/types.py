from typing import TYPE_CHECKING


if TYPE_CHECKING:
    from tooi.app import TooiApp


class TooiWidget:
    """
    Can be inherited by a Widget to make self.app type hint to TooiApp.
    """
    @property
    def app(self) -> "TooiApp":
        return super().app  # type: ignore
