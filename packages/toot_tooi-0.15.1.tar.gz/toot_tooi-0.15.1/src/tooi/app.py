import asyncio
from contextlib import asynccontextmanager
import re
import shlex
import traceback
from pathlib import Path
from typing_extensions import override
from urllib.parse import urlparse

from textual import work
from textual.app import App
from textual.screen import ModalScreen

from tooi import __version__, messages
from tooi.api.streaming import InstanceStreamer
from tooi.api.timeline import (
    AccountTimeline,
    ContextTimeline,
    FederatedTimeline,
    HomeTimeline,
    LocalTimeline,
    NotificationTimeline,
    TagTimeline,
    Timeline,
)
from tooi.asyncio import create_async_context, set_async_context
from tooi.cache import download_images_cached
from tooi.context import get_context, is_mine
from tooi.data.instance import get_instance_info
from tooi.screens.account import AccountScreen
from tooi.screens.compose import ComposeScreen
from tooi.screens.goto import GotoHashtagScreen
from tooi.screens.help import HelpScreen
from tooi.screens.loading import LoadingScreen
from tooi.screens.main import MainScreen
from tooi.screens.messagebox import MessageBox
from tooi.screens.source import SourceScreen
from tooi.screens.status_context import StatusMenuScreen
from tooi.settings import get_stylesheet_path
from tooi.widgets.dialog import ConfirmationDialog
from tooi.widgets.gallery import GalleryScreen
from tooi.widgets.link import Link
from tooi.widgets.status_bar import MessageId, StatusBar


class TooiApp(App[None]):
    TITLE = "tooi"
    SUB_TITLE = __version__
    SCREENS = {"loading": LoadingScreen}
    CSS_PATH = "app.css"

    BINDINGS = [
        ("?", "help", "Help"),
        ("q", "pop_or_quit", "Quit"),
    ]

    def __init__(self):
        base_css = Path("./app.css")
        user_css = get_stylesheet_path()
        css_path = [base_css, user_css] if user_css.exists() else [base_css]
        super().__init__(css_path=css_path)  # type: ignore

        self.context = get_context()
        set_async_context(create_async_context(self))

    async def on_mount(self):
        self.push_screen("loading")
        self.load_initial_data()

    @work
    async def load_initial_data(self):
        self.instance = await get_instance_info()
        self.instance.streamer = InstanceStreamer(self.instance)
        self.tabs = MainScreen(self.instance)
        self.switch_screen(self.tabs)

    def on_status_edit(self, message: messages.StatusEdit):
        if is_mine(message.status):
            self.push_screen(
                ComposeScreen(self.instance, edit=message.status, edit_source=message.status_source)
            )

    async def confirm(
        self,
        title: str,
        *,
        text: str | None = None,
        confirm_label: str = "Confirm",
        cancel_label: str = "Cancel",
    ) -> bool:
        dialog = ConfirmationDialog(
            modal_title=title,
            modal_text=text,
            confirm_label=confirm_label,
            cancel_label=cancel_label,
        )
        return await self.push_screen_wait(dialog)

    def show_status(self, message: str, timeout: float | None = None) -> MessageId:
        """Show a message in the status bar"""
        return self.tabs.query_one(StatusBar).set_message(message, timeout)

    def clear_status(self, message_id: MessageId | None):
        """Clear a message from the status bar"""
        return self.tabs.query_one(StatusBar).clear_message(message_id)

    def show_error_modal(
        self, message: str | None = None, title: str = "Error", ex: Exception | None = None
    ):
        """Open a modal screen with an error."""
        message = message.strip() if message else ""
        if ex:
            if message:
                message += "\n\n"
            for line in traceback.format_exception(ex):
                message += line
        self.push_screen(MessageBox(title, message, error=True))

    @asynccontextmanager
    async def run_with_progress(
        self,
        progress: str,
        success: str | None = None,
        error: str | None = None,
    ):
        message_id = self.show_status(f"[gray]{progress}[/]")

        try:
            yield
            if success:
                self.show_status(f"[green]{success}[/]", 1)
        except Exception as ex:
            self.show_error_modal(message=error, ex=ex)
        finally:
            self.clear_status(message_id)

    @work
    async def action_pop_or_quit(self):
        if len(self.screen_stack) > 2:
            self.pop_screen()
        else:
            if await self.confirm("Quit tooi?", confirm_label="Quit"):
                self.exit()

    def action_help(self):
        self.push_screen(HelpScreen())

    def close_modals(self):
        while isinstance(self.screen, ModalScreen):
            self.pop_screen()

    @work
    async def on_show_account(self, message: messages.ShowAccount):
        self.close_modals()
        if to_post := await self.push_screen_wait(AccountScreen(message.account)):
            self.post_message(to_post)

    def on_show_source(self, message: messages.ShowSource):
        self.push_screen(SourceScreen(message.status))

    def on_show_status_menu(self, message: messages.ShowStatusMenu):
        self.push_screen(StatusMenuScreen(message.status))

    def on_status_reply(self, message: messages.StatusReply):
        self.push_screen(ComposeScreen(self.instance, message.status))

    @work
    async def on_show_hashtag_picker(self):
        if hashtag := await self.push_screen_wait(GotoHashtagScreen()):
            self.post_message(messages.GotoHashtagTimeline(hashtag))

    async def on_show_thread(self, message: messages.ShowThread):
        # TODO: composing a status: event id by hand is probably not ideal.
        await self.tabs.open_timeline_tab(
            timeline=ContextTimeline(self.instance, message.status.original),
            initial_focus=f"status-{message.status.original.id}",
        )

    async def on_goto_home_timeline(self):
        await self._open_timeline(HomeTimeline(self.instance))

    async def on_goto_personal_timeline(self):
        timeline = await AccountTimeline.from_name(self.instance, self.context.auth.acct)
        await self._open_timeline(timeline)

    async def on_goto_account_timeline(self, message: messages.GotoAccountTimeline):
        timeline = AccountTimeline(self.instance, message.account.acct, message.account.id)
        await self._open_timeline(timeline)

    async def on_goto_local_timeline(self):
        await self._open_timeline(LocalTimeline(self.instance))

    async def on_goto_federated_timeline(self):
        await self._open_timeline(FederatedTimeline(self.instance))

    async def on_goto_hashtag_timeline(self, message: messages.GotoHashtagTimeline):
        await self._open_timeline(TagTimeline(self.instance, hashtag=message.hashtag))

    async def on_show_notifications(self):
        await self.tabs.open_timeline_tab(NotificationTimeline(self.instance))

    async def _open_timeline(self, timeline: Timeline):
        await self.tabs.open_timeline_tab(timeline)

    def on_show_images(self, message: messages.ShowImages):
        if message.media_attachments:
            image_viewer = self.context.config.media.image_viewer
            if image_viewer:
                urls = [m.url for m in message.media_attachments]
                self._show_images(image_viewer, urls)
            else:
                self.push_screen(GalleryScreen(message.media_attachments))

    @override
    def open_url(self, url: str, *, new_tab: bool = True) -> None:
        parsed = urlparse(url)

        # Handle Hashtag clicks
        if m := re.match(r"/tags/(\w+)", parsed.path):
            hashtag = m.group(1)
            self.post_message(messages.GotoHashtagTimeline(hashtag))
        else:
            super().open_url(url, new_tab=new_tab)

    @work
    async def _show_images(self, image_viewer: str, urls: list[str]):
        """
        Open a local image viewer to display the given images, which should be a list of URLs.
        This returns immediately and starts the work in a background thread.
        """
        if not (viewer := self.context.config.media.image_viewer):
            self.show_error_modal("No image viewer has been configured")
            return

        paths = await download_images_cached(urls)
        args = " ".join(map(shlex.quote, [str(p) for p in paths]))
        cmd = f"{viewer} {args}"

        # Spawn the image viewer.
        process = await asyncio.create_subprocess_shell(cmd)
        # ... and wait for it to exit.
        await process.communicate()
