"""
PowerPoint MCP Server Package

A Model Context Protocol server for automating Microsoft PowerPoint using pywin32.
"""

__version__ = "0.0.1"