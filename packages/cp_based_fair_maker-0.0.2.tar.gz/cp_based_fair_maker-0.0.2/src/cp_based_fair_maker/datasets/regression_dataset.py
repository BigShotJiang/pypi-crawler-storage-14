from cp_based_fair_maker.datasets.dataset import Dataset


class RegressionDataset(Dataset):
    """Class for a dataset with regression label."""
    # To handle groups, consider using:
    #   - grouping ranges (e.g., 0-10, 10-20, inf-sup)
    #   - label encoder function
    #   - label grouping function
    raise NotImplementedError()
