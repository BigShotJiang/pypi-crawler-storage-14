#!/usr/bin/python
# -*- coding: utf-8 -*-

NAME = "migratore"
VERSION = "0.5.7"
AUTHOR = "Hive Solutions Lda."
EMAIL = "development@hive.pt"
DESCRIPTION = "Migratore Infra-structure"
LICENSE = "Apache Software License"
KEYWORDS = "migratore migration sql"
URL = "http://migratore.hive.pt"
COPYRIGHT = "2008-2023 Hive Solutions Lda."
