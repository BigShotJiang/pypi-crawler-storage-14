"""
HumanEval Rust evaluation package.

Provides evaluation harness for the HumanEval Rust problem solving dataset.

Copyright (c) 2025 Dave Tofflemire, SigilDERG Project
Version: 1.1.1
"""

__version__ = "1.1.1"

