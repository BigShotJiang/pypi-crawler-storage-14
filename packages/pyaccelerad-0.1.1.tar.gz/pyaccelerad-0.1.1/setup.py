"""
Setup script for Pyaccelerad.
"""

from setuptools import setup

# --- Run setup using configuration from pyproject.toml ---
setup()
