Pipelines
=========

.. automodule:: kedro_mlflow.pipeline.pipeline_ml
   :members:
   :undoc-members:
   :show-inheritance:

.. automodule:: kedro_mlflow.pipeline.pipeline_ml_factory
   :members:
   :undoc-members:
   :show-inheritance:
