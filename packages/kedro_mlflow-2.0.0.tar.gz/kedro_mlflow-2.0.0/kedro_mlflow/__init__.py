"""kedro-mlflow plugin constants"""

__version__ = "2.0.0"

import logging

logging.getLogger(__name__).setLevel(logging.INFO)
