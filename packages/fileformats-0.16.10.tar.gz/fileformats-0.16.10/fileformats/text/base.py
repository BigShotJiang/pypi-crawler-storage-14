from fileformats.generic import File


class Text(File):
    """Base class for text files"""
