from fileformats.text import Plain


class Foo(Plain):

    ext = ".foo"


class Bar(Plain):

    ext = ".bar"


class Baz(Plain):

    ext = ".baz"


class Qux(Plain):

    ext = ".qux"
