from fileformats.core import FileSet


class Image(FileSet):
    ...  # noqa: E701
