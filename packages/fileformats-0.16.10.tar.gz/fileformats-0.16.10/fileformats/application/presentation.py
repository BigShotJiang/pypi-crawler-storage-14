from fileformats.generic import BinaryFile


# Document formats
class Presentation(BinaryFile):
    # iana_mime = None
    pass
