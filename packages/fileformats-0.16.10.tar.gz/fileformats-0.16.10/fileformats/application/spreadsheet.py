from fileformats.generic import BinaryFile


# Document formats
class Spreadsheet(BinaryFile):
    # iana_mime = None
    pass
