"""
Local Spark Connection Strategy

Provides embedded PySpark session for local development and testing.
This is the default strategy extracted from the original SparkEngine implementation.

Includes auto-configuration of Java via bundled jdk4py - no system Java required!
"""

import os
from typing import Any, Dict, Optional

from dbt.compute.strategies.base import BaseConnectionStrategy
from dbt_common.exceptions import DbtRuntimeError

try:
    from pyspark.sql import SparkSession

    PYSPARK_AVAILABLE = True
except ImportError:
    PYSPARK_AVAILABLE = False
    SparkSession = None

# Check Java availability and provide helpful setup instructions
def _ensure_java_available():
    """
    Ensure Java is available for Spark.

    Checks if JAVA_HOME is set and provides helpful error messages with
    installation instructions if Java is not found.
    """
    import subprocess
    import shutil

    # Check if JAVA_HOME is already set and valid
    java_home = os.environ.get("JAVA_HOME")
    if java_home and os.path.exists(java_home):
        return  # System Java available

    # Check if java is in PATH
    java_bin = shutil.which("java")
    if java_bin:
        # Java found in PATH - try to infer JAVA_HOME
        try:
            # Get java version to verify it works
            result = subprocess.run(
                [java_bin, "-version"],
                capture_output=True,
                text=True,
                timeout=5
            )
            if result.returncode == 0:
                # Java works - try to set JAVA_HOME from java binary location
                # java is typically in JAVA_HOME/bin/java
                java_home = os.path.dirname(os.path.dirname(os.path.realpath(java_bin)))
                os.environ["JAVA_HOME"] = java_home
                return
        except Exception:
            pass

    # Try install-jdk as a fallback (only if user explicitly installed it)
    try:
        import jdk

        # Check if JDK is already installed
        jdk_dir = os.path.expanduser("~/.jdk")
        if os.path.exists(jdk_dir):
            # Find any installed JDK
            for jdk_version in os.listdir(jdk_dir):
                jdk_path = os.path.join(jdk_dir, jdk_version)
                if os.path.isdir(jdk_path):
                    # Check if it's a valid JDK
                    potential_homes = [
                        jdk_path,
                        os.path.join(jdk_path, "Contents", "Home"),  # macOS
                    ]
                    for home in potential_homes:
                        java_bin = os.path.join(home, "bin", "java")
                        if os.path.exists(java_bin):
                            os.environ["JAVA_HOME"] = home
                            os.environ["PATH"] = os.path.join(home, "bin") + os.pathsep + os.environ.get("PATH", "")
                            return
    except ImportError:
        pass


class LocalStrategy(BaseConnectionStrategy):
    """
    Local embedded Spark strategy.

    Creates an in-process PySpark session with local[*] master.
    Best for development, testing, and small-medium workloads.

    Configuration:
    {
        "master": "local[*]",  # optional, defaults to local[*]
        "spark.driver.memory": "4g",  # optional
        "spark.executor.memory": "4g",  # optional
        # ... any other Spark configs
    }
    """

    def validate_config(self) -> None:
        """
        Validate local strategy configuration.

        Local strategy is flexible - no required fields.
        """
        # Local strategy accepts any config - very flexible
        # Just ensure it's a dictionary
        if not isinstance(self.config, dict):
            raise DbtRuntimeError(
                f"Local Spark config must be a dictionary, got {type(self.config)}"
            )

    def get_spark_session(self) -> SparkSession:
        """
        Create local Spark session.

        Creates an embedded PySpark session with local[*] master.
        Automatically configures Java from bundled jdk4py if needed.

        :returns: Initialized SparkSession
        :raises DbtRuntimeError: If session creation fails
        """
        if not PYSPARK_AVAILABLE:
            raise DbtRuntimeError("PySpark is not available. Install it with: pip install pyspark")

        # Auto-configure Java from bundled jdk4py if system Java not available
        _ensure_java_available()

        try:
            builder = SparkSession.builder.appName(self.app_name)

            # Set local master (use config value or default to local[*])
            master = self.config.get("master", "local[*]")
            builder = builder.master(master)

            # Default local configurations
            default_configs = {
                "spark.driver.memory": "4g",
                "spark.sql.execution.arrow.pyspark.enabled": "true",
                "spark.sql.execution.arrow.pyspark.fallback.enabled": "true",
            }

            # Apply default configs (can be overridden by user config)
            for key, value in default_configs.items():
                if key not in self.config:
                    builder = builder.config(key, value)

            # Apply user-provided configs (except 'master' which is already set)
            for key, value in self.config.items():
                if key != "master":
                    builder = builder.config(key, value)

            # Enable Arrow optimization
            builder = builder.config("spark.sql.execution.arrow.enabled", "true")

            # Create session
            spark = builder.getOrCreate()

            # Set log level to WARN to reduce noise
            spark.sparkContext.setLogLevel("WARN")

            return spark

        except Exception as e:
            error_msg = str(e)

            # Check if it's a Java-related error
            if "JAVA_GATEWAY_EXITED" in error_msg or "Unable to locate a Java Runtime" in error_msg or "JAVA_HOME" in error_msg:
                raise DbtRuntimeError(
                    f"Failed to create local Spark session: Java not found.\n\n"
                    f"DVT requires Java 11 or later for Spark execution. Please install Java:\n\n"
                    f"macOS (using Homebrew):\n"
                    f"  brew install openjdk@11\n"
                    f"  export JAVA_HOME=$(/usr/libexec/java_home -v 11)\n\n"
                    f"Ubuntu/Debian:\n"
                    f"  sudo apt-get install openjdk-11-jdk\n"
                    f"  export JAVA_HOME=/usr/lib/jvm/java-11-openjdk-amd64\n\n"
                    f"Or download from: https://adoptium.net/\n\n"
                    f"Original error: {error_msg}"
                ) from e

            # Other error
            raise DbtRuntimeError(f"Failed to create local Spark session: {error_msg}") from e

    def close(self, spark: Optional[SparkSession]) -> None:
        """
        Stop local Spark session.

        For local strategy, we stop the session to free resources.

        :param spark: SparkSession to close
        """
        if spark:
            try:
                spark.stop()
            except Exception:
                pass  # Best effort cleanup

    def estimate_cost(self, duration_minutes: float) -> float:
        """
        Estimate cost for local execution.

        Local execution is free (runs on local machine).

        :param duration_minutes: Estimated query duration
        :returns: 0.0 (free)
        """
        return 0.0

    def get_platform_name(self) -> str:
        """Get platform name."""
        return "local"
