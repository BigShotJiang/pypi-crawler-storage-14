# Mark scripts as a package so `python -m scripts.mobile_browser` works cleanly.
