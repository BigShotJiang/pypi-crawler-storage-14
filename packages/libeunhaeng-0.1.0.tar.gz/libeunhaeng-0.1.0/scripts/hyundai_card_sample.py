"""
Sample script for Hyundai Card scraper (login through transaction fetch).
Run with `uv run scripts/hyundai_card_sample.py` after setting the HYUNDAI_CARD_* env vars.
"""

import asyncio
import json
import os
import sys
from pathlib import Path

# Allow running via `uv run scripts/hyundai_card_sample.py` by adding project root/src to sys.path
if __package__ in (None, ""):
    project_root = Path(__file__).resolve().parent.parent
    src_path = project_root / "src"
    if str(src_path) not in sys.path:
        sys.path.insert(0, str(src_path))

from libeunhaeng.hyundai_card_scraper import HyundaiCardScraper


def env_bool(var_name: str, default: bool = False) -> bool:
    """Parse a boolean environment variable."""
    return os.getenv(var_name, str(default)).lower() in {"1", "true", "yes", "on"}


async def main() -> None:
    base_url = os.getenv("HYUNDAI_CARD_BASE_URL")
    user_id = os.getenv("HYUNDAI_CARD_USER_ID", "your_user_id")
    password = os.getenv("HYUNDAI_CARD_PASSWORD", "your_password")
    pin = os.getenv("HYUNDAI_CARD_CREDIT_CARD_PIN", "1234")
    headless = env_bool("HYUNDAI_CARD_HEADLESS")

    async with HyundaiCardScraper(headless=headless, base_url=base_url) as scraper:
        # Login
        await scraper.login(user_id, password, pin)

        # Get transactions
        transactions = await scraper.get_transactions()

    print(json.dumps(transactions, indent=2))


if __name__ == "__main__":
    asyncio.run(main())
