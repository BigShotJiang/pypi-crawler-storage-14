"""
Launch a mobile-like Playwright browser using the shared session config.
"""

import argparse
import asyncio
import sys
from pathlib import Path

# Allow running via `uv run scripts/mobile_browser.py` by adding project root/src to sys.path
if __package__ in (None, ""):
    project_root = Path(__file__).resolve().parent.parent
    src_path = project_root / "src"
    if str(src_path) not in sys.path:
        sys.path.insert(0, str(src_path))

from libeunhaeng.playwright_mobile import mobile_playwright_session


async def main(url: str, headless: bool):
    async with mobile_playwright_session(headless=headless) as (_, _, page):
        await page.goto(url, wait_until="networkidle")
        # Keep the browser open until interrupted.
        try:
            await asyncio.Event().wait()
        except (KeyboardInterrupt, asyncio.CancelledError):
            pass


def main_cli():
    parser = argparse.ArgumentParser(description="Open a mobile Playwright browser and navigate to a URL.")
    parser.add_argument(
        "url", nargs="?", default="https://example.com", help="URL to open (default: https://example.com)"
    )
    parser.add_argument("--headless", action="store_true", help="Run browser in headless mode")
    args = parser.parse_args()

    asyncio.run(main(args.url, args.headless))


if __name__ == "__main__":
    main_cli()
