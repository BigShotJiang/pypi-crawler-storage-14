"""
Sample script for Shinhan Card scraper (login through transaction fetch).
Run with `uv run scripts/shinhan_card_sample.py` after setting the SHINHAN_CARD_* env vars.
"""

import asyncio
import json
import os
import sys
from pathlib import Path

# Allow running via `uv run scripts/shinhan_card_sample.py` by adding project root/src to sys.path
if __package__ in (None, ""):
    project_root = Path(__file__).resolve().parent.parent
    src_path = project_root / "src"
    if str(src_path) not in sys.path:
        sys.path.insert(0, str(src_path))

from libeunhaeng.shinhan_card_scraper import ShinhanCardScraper


def env_bool(var_name: str, default: bool = False) -> bool:
    """Parse a boolean environment variable."""
    return os.getenv(var_name, str(default)).lower() in {"1", "true", "yes", "on"}


async def main() -> None:
    base_url = os.getenv("SHINHAN_CARD_BASE_URL")
    user_id = os.getenv("SHINHAN_CARD_USER_ID", "your_user_id")
    password = os.getenv("SHINHAN_CARD_PASSWORD", "your_password")
    headless = env_bool("SHINHAN_CARD_HEADLESS")

    async with ShinhanCardScraper(headless=headless, base_url=base_url) as scraper:
        # Login
        await scraper.login(user_id, password)

        # Get transactions
        transactions = await scraper.get_recent_transactions()

    print(json.dumps(transactions, indent=2))


if __name__ == "__main__":
    asyncio.run(main())
