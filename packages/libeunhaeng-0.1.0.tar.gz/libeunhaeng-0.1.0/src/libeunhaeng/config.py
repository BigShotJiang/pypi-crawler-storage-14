"""Configuration dataclasses for scrapers."""

from dataclasses import dataclass


@dataclass
class ScraperConfig:
    """Base configuration for all scrapers."""

    base_url: str
    login_timeout: int = 60000
    keyboard_timeout: int = 10000
    default_wait: float = 2.0
    navigation_timeout: int = 60000


@dataclass
class ShinhanBankConfig(ScraperConfig):
    """Configuration for Shinhan Bank scraper."""

    base_url: str = "https://bank.shinhan.com/rib/easy/index.jsp#210000010000"


@dataclass
class ShinhanCardConfig(ScraperConfig):
    """Configuration for Shinhan Card scraper."""

    base_url: str = "https://www.shinhancard.com/mob/MOBFM045N/MOBFM045R01.shc?crustMenuId=ms117"


@dataclass
class HyundaiCardConfig(ScraperConfig):
    """Configuration for Hyundai Card scraper."""

    base_url: str = "https://www.hyundaicard.com/index.jsp?forceUA=PC"
    transactions_url: str = "https://www.hyundaicard.com/cpa/cb/CPACB0101_01.hc"
