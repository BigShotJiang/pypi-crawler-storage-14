# coding: utf-8

from huaweicloudsdkcore.sdk_response import SdkResponse
from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class EstimateDesktopPoolExtendVolumeResponse(SdkResponse):

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'currency': 'str',
        'extend_params': 'str',
        'official_website_rating_result': 'OfficialWebsiteRatingResult',
        'optional_discount_rating_results': 'list[OptionalDiscountRatingResult]'
    }

    attribute_map = {
        'currency': 'currency',
        'extend_params': 'extend_params',
        'official_website_rating_result': 'official_website_rating_result',
        'optional_discount_rating_results': 'optional_discount_rating_results'
    }

    def __init__(self, currency=None, extend_params=None, official_website_rating_result=None, optional_discount_rating_results=None):
        r"""EstimateDesktopPoolExtendVolumeResponse

        The model defined in huaweicloud sdk

        :param currency: 币种，比如CNY。
        :type currency: str
        :param extend_params: 扩展参数。
        :type extend_params: str
        :param official_website_rating_result: 
        :type official_website_rating_result: :class:`huaweicloudsdkworkspace.v2.OfficialWebsiteRatingResult`
        :param optional_discount_rating_results: 存在可选折扣优惠时返回折扣优惠维度询价结果，每个折扣优惠一组询价结果。
        :type optional_discount_rating_results: list[:class:`huaweicloudsdkworkspace.v2.OptionalDiscountRatingResult`]
        """
        
        super().__init__()

        self._currency = None
        self._extend_params = None
        self._official_website_rating_result = None
        self._optional_discount_rating_results = None
        self.discriminator = None

        if currency is not None:
            self.currency = currency
        if extend_params is not None:
            self.extend_params = extend_params
        if official_website_rating_result is not None:
            self.official_website_rating_result = official_website_rating_result
        if optional_discount_rating_results is not None:
            self.optional_discount_rating_results = optional_discount_rating_results

    @property
    def currency(self):
        r"""Gets the currency of this EstimateDesktopPoolExtendVolumeResponse.

        币种，比如CNY。

        :return: The currency of this EstimateDesktopPoolExtendVolumeResponse.
        :rtype: str
        """
        return self._currency

    @currency.setter
    def currency(self, currency):
        r"""Sets the currency of this EstimateDesktopPoolExtendVolumeResponse.

        币种，比如CNY。

        :param currency: The currency of this EstimateDesktopPoolExtendVolumeResponse.
        :type currency: str
        """
        self._currency = currency

    @property
    def extend_params(self):
        r"""Gets the extend_params of this EstimateDesktopPoolExtendVolumeResponse.

        扩展参数。

        :return: The extend_params of this EstimateDesktopPoolExtendVolumeResponse.
        :rtype: str
        """
        return self._extend_params

    @extend_params.setter
    def extend_params(self, extend_params):
        r"""Sets the extend_params of this EstimateDesktopPoolExtendVolumeResponse.

        扩展参数。

        :param extend_params: The extend_params of this EstimateDesktopPoolExtendVolumeResponse.
        :type extend_params: str
        """
        self._extend_params = extend_params

    @property
    def official_website_rating_result(self):
        r"""Gets the official_website_rating_result of this EstimateDesktopPoolExtendVolumeResponse.

        :return: The official_website_rating_result of this EstimateDesktopPoolExtendVolumeResponse.
        :rtype: :class:`huaweicloudsdkworkspace.v2.OfficialWebsiteRatingResult`
        """
        return self._official_website_rating_result

    @official_website_rating_result.setter
    def official_website_rating_result(self, official_website_rating_result):
        r"""Sets the official_website_rating_result of this EstimateDesktopPoolExtendVolumeResponse.

        :param official_website_rating_result: The official_website_rating_result of this EstimateDesktopPoolExtendVolumeResponse.
        :type official_website_rating_result: :class:`huaweicloudsdkworkspace.v2.OfficialWebsiteRatingResult`
        """
        self._official_website_rating_result = official_website_rating_result

    @property
    def optional_discount_rating_results(self):
        r"""Gets the optional_discount_rating_results of this EstimateDesktopPoolExtendVolumeResponse.

        存在可选折扣优惠时返回折扣优惠维度询价结果，每个折扣优惠一组询价结果。

        :return: The optional_discount_rating_results of this EstimateDesktopPoolExtendVolumeResponse.
        :rtype: list[:class:`huaweicloudsdkworkspace.v2.OptionalDiscountRatingResult`]
        """
        return self._optional_discount_rating_results

    @optional_discount_rating_results.setter
    def optional_discount_rating_results(self, optional_discount_rating_results):
        r"""Sets the optional_discount_rating_results of this EstimateDesktopPoolExtendVolumeResponse.

        存在可选折扣优惠时返回折扣优惠维度询价结果，每个折扣优惠一组询价结果。

        :param optional_discount_rating_results: The optional_discount_rating_results of this EstimateDesktopPoolExtendVolumeResponse.
        :type optional_discount_rating_results: list[:class:`huaweicloudsdkworkspace.v2.OptionalDiscountRatingResult`]
        """
        self._optional_discount_rating_results = optional_discount_rating_results

    def to_dict(self):
        import warnings
        warnings.warn("EstimateDesktopPoolExtendVolumeResponse.to_dict() is deprecated and no longer maintained, "
                      "use to_json_object() to get the response content.", DeprecationWarning)
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, EstimateDesktopPoolExtendVolumeResponse):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
