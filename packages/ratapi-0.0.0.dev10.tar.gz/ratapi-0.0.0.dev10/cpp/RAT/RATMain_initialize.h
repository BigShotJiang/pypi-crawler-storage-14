//
// Non-Degree Granting Education License -- for use at non-degree
// granting, nonprofit, education, and research organizations only. Not
// for commercial or industrial use.
//
// RATMain_initialize.h
//
// Code generation for function 'RATMain_initialize'
//
#ifndef RATMAIN_INITIALIZE_H
#define RATMAIN_INITIALIZE_H

// Include files
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
namespace RAT
{
  extern void RATMain_initialize();
}

#endif

// End of code generation (RATMain_initialize.h)
