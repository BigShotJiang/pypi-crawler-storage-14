//
// Non-Degree Granting Education License -- for use at non-degree
// granting, nonprofit, education, and research organizations only. Not
// for commercial or industrial use.
//
// hasPlotHandler.h
//
// Code generation for function 'hasPlotHandler'
//
#ifndef HASPLOTHANDLER_H
#define HASPLOTHANDLER_H

// Include files
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
namespace RAT
{
  void b_helper_not_empty_init();
  boolean_T hasPlotHandler();
}

#endif

// End of code generation (hasPlotHandler.h)
