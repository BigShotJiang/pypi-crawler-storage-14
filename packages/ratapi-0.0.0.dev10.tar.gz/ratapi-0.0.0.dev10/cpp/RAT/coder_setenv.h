/* Copyright 2020 The MathWorks, Inc. */
#ifndef CODER_SETENV_H
#define CODER_SETENV_H

#ifdef __cplusplus
extern "C" {
#endif

void portableSetEnv(const char* aName, const char* aValue);

#ifdef __cplusplus
}
#endif

#endif
