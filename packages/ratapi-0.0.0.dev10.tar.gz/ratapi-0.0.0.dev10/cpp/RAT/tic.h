//
// Non-Degree Granting Education License -- for use at non-degree
// granting, nonprofit, education, and research organizations only. Not
// for commercial or industrial use.
//
// tic.h
//
// Code generation for function 'tic'
//
#ifndef TIC_H
#define TIC_H

// Include files
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
namespace RAT
{
  namespace coder
  {
    void tic();
  }
}

#endif

// End of code generation (tic.h)
