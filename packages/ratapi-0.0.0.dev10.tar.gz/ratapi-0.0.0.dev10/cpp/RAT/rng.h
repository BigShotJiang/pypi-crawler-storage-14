//
// Non-Degree Granting Education License -- for use at non-degree
// granting, nonprofit, education, and research organizations only. Not
// for commercial or industrial use.
//
// rng.h
//
// Code generation for function 'rng'
//
#ifndef RNG_H
#define RNG_H

// Include files
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
namespace RAT
{
  namespace coder
  {
    void rng();
  }
}

#endif

// End of code generation (rng.h)
