This is the C++ source code for RAT auto-generated with MATLAB Coder.
