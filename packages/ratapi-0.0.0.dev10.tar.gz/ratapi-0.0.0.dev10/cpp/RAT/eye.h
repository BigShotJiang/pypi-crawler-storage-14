//
// Non-Degree Granting Education License -- for use at non-degree
// granting, nonprofit, education, and research organizations only. Not
// for commercial or industrial use.
//
// eye.h
//
// Code generation for function 'eye'
//
#ifndef EYE_H
#define EYE_H

// Include files
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
namespace RAT
{
  namespace coder
  {
    void eye(creal_T b_I[2][2]);
  }
}

#endif

// End of code generation (eye.h)
