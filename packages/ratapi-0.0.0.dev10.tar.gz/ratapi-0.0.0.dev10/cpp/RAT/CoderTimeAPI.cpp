//
// Non-Degree Granting Education License -- for use at non-degree
// granting, nonprofit, education, and research organizations only. Not
// for commercial or industrial use.
//
// CoderTimeAPI.cpp
//
// Code generation for function 'CoderTimeAPI'
//

// Include files
#include "CoderTimeAPI.h"
#include "RATMain_data.h"
#include "rt_nonfinite.h"

// Function Definitions
namespace RAT
{
  void freq_not_empty_init()
  {
    freq_not_empty = false;
  }
}

// End of code generation (CoderTimeAPI.cpp)
