"""Examples of normal reflectivity calculations in RAT."""
