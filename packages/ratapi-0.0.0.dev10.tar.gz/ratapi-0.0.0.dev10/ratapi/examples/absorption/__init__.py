"""An example of using absorption in a RAT project."""
