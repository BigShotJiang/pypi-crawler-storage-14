"""An example of converting between RAT and RasCAL-1."""
