import json
import argparse
import os

def create_notebook_structure():
    return {
        "cells": [],
        "metadata": {
            "kernelspec": {
                "display_name": "Python 3",
                "language": "python",
                "name": "python3"
            },
            "language_info": {
                "codemirror_mode": {
                    "name": "ipython",
                    "version": 3
                },
                "file_extension": ".py",
                "mimetype": "text/x-python",
                "name": "python",
                "nbconvert_exporter": "python",
                "pygments_lexer": "ipython3",
                "version": "3.8.5"
            }
        },
        "nbformat": 4,
        "nbformat_minor": 4
    }

def create_code_cell(source):
    return {
        "cell_type": "code",
        "execution_count": None,
        "metadata": {},
        "outputs": [],
        "source": source.splitlines(keepends=True)
    }

def create_markdown_cell(source):
    return {
        "cell_type": "markdown",
        "metadata": {},
        "source": source.splitlines(keepends=True)
    }

GDOWN_TEMPLATE = """import pandas as pd
import missingno as msno
import os, io, shutil, re
import gdown
import csv

OUTFILE = '{outfile}'
FILE_ID = '{file_id}'

def is_html_file(path, n=512):
    if not os.path.exists(path):
        return False
    with open(path, 'r', encoding='utf-8', errors='ignore') as f:
        start = f.read(n)
    return bool(re.search(r'<!DOCTYPE html|<html', start, re.IGNORECASE))

def download_from_drive_id(file_id, out=OUTFILE):
    url = f'https://drive.google.com/uc?export=download&id={file_id}'
    print('Downloading from', url)
    gdown.download(url, out, quiet=False)
    return out

# Ensure file present and valid
if os.path.exists(OUTFILE):
    if is_html_file(OUTFILE):
        print(OUTFILE, 'looks like HTML — removing and re-downloading')
        os.remove(OUTFILE)
        download_from_drive_id(FILE_ID)
    else:
        print(OUTFILE, 'exists and looks like CSV')
else:
    download_from_drive_id(FILE_ID)

# Quick peek into the downloaded file (first 1000 chars)
with open(OUTFILE, 'r', encoding='utf-8', errors='ignore') as f:
    preview = f.read(1000)
print(preview[:1000])
"""

def main():
    parser = argparse.ArgumentParser(description="Generate a Jupyter Notebook with data loading scripts.")
    parser.add_argument("filename", help="Output notebook filename (e.g., my_notebook.ipynb)")
    parser.add_argument("--drive-id", default="PLACEHOLDER_FILE_ID", help="Google Drive File ID")
    parser.add_argument("--outfile", default="data.csv", help="Output filename for the downloaded file")
    
    parser.add_argument("-k", "--kaggle", action="store_true", help="Enable Kaggle setup")
    parser.add_argument("-g", "--gdrive", action="store_true", help="Enable Google Drive setup")
    parser.add_argument("--kaggle-user", help="Kaggle Username")
    parser.add_argument("--kaggle-key", help="Kaggle API Key")
    parser.add_argument("--competition", default="catechol-benchmark-hackathon", help="Kaggle competition name")

    args = parser.parse_args()

    # Resolve Kaggle Credentials
    kaggle_user = args.kaggle_user or os.environ.get('KAGGLE_USERNAME')
    # Check for KAGGLE_KEY or KAGGLE_API_TOKEN (new style)
    kaggle_key = args.kaggle_key or os.environ.get('KAGGLE_KEY') or os.environ.get('KAGGLE_API_TOKEN')

    # Try to read from ~/.kaggle/kaggle.json if not found
    if not (kaggle_user and kaggle_key):
        kaggle_json_path = os.path.expanduser('~/.kaggle/kaggle.json')
        if os.path.exists(kaggle_json_path):
            try:
                with open(kaggle_json_path, 'r') as f:
                    data = json.load(f)
                    kaggle_user = kaggle_user or data.get('username')
                    kaggle_key = kaggle_key or data.get('key')
            except Exception as e:
                print(f"Warning: Could not read {kaggle_json_path}: {e}")

    # Check if file exists
    if not args.filename.endswith('.ipynb'):
        args.filename += '.ipynb'

    if os.path.exists(args.filename):
        print(f"Updating existing notebook: {args.filename}")
        with open(args.filename, 'r', encoding='utf-8') as f:
            nb = json.load(f)
    else:
        print(f"Creating new notebook: {args.filename}")
        nb = create_notebook_structure()

    new_cells = []

    enable_kaggle = args.kaggle
    enable_drive = args.gdrive

    # Default behavior: if neither is specified, enable Drive (legacy behavior)
    if not enable_kaggle and not enable_drive:
        enable_drive = True

    # Kaggle Section
    if enable_kaggle:
        new_cells.append(create_markdown_cell("# Kaggle Setup"))
        new_cells.append(create_code_cell("!pip install kaggle"))
        
        if kaggle_user and kaggle_key:
            # Check for new style KGAT token
            if kaggle_key.startswith('KGAT_'):
                creds_script = f"""import os
os.environ['KAGGLE_USERNAME'] = "{kaggle_user}"
os.environ['KAGGLE_API_TOKEN'] = "{kaggle_key}"
"""
            else:
                creds_script = f"""import os
os.environ['KAGGLE_USERNAME'] = "{kaggle_user}"
os.environ['KAGGLE_KEY'] = "{kaggle_key}"
"""
            new_cells.append(create_code_cell(creds_script))
        else:
             new_cells.append(create_code_cell("""import os
# TODO: Enter your Kaggle credentials here
os.environ['KAGGLE_USERNAME'] = "YOUR_USERNAME"
os.environ['KAGGLE_KEY'] = "YOUR_KEY"
"""))
        
        new_cells.append(create_code_cell(f"!kaggle competitions download -c {args.competition}"))

    # Drive Section
    if enable_drive:
        new_cells.append(create_markdown_cell("# Google Drive Download"))
        
        # Fill template
        script = GDOWN_TEMPLATE.format(outfile=args.outfile, file_id=args.drive_id)
        new_cells.append(create_code_cell(script))

    # Prepend new cells
    nb["cells"] = new_cells + nb["cells"]

    # Write file
    with open(args.filename, 'w', encoding='utf-8') as f:
        json.dump(nb, f, indent=2)
    
    print(f"Notebook saved: {args.filename}")

if __name__ == "__main__":
    main()
