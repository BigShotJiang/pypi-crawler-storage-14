"""Fetch domain implementation."""
