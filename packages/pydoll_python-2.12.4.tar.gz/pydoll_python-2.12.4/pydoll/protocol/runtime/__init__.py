"""Runtime domain implementation."""
