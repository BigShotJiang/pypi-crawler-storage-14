# Ginom v0.1

A simplified, human‑friendly, Git‑style versioning tool.

## 🚀 Overview

Ginom is a Python‑based, lightweight version-control tool inspired by
Git but designed to be extremely simple, readable, and friendly ---
especially for beginners and small projects.

## ✨ Features

-   Initialize repositories (`ginom init`)
-   Track files (`ginom track <file>`)
-   Commit changes (`ginom commit -m "message"`)
-   View logs (`ginom log`)
-   View status (`ginom status`)
-   Push/pull to GitHub via API tokens (`ginom push`, `ginom pull`)
-   Branching system (`ginom branch`, `ginom checkout`)
-   Simple conflict handling
-   Config system (`ginom config set key value`)

## 📦 Installation

``` bash
pip install ginom
```

Or install directly from source:

git clone https://github.com/yourusername/ginom
cd ginom
pip install -e .


## 🔧 Usage

Initialize a project:

``` bash
ginom init

```

Track a file:

``` bash
ginom track app.py
```

Commit changes:

``` bash
ginom commit -m "Initial commit"
```

Check status:

``` bash
ginom status
```

Push to GitHub:

``` bash
ginom push origin main
```

🧩 Why Ginom?

Ginom exists to solve real developer frustrations:

Git is powerful but overwhelming for beginners

Commands are not always intuitive

The internal object model is hard to understand

A simpler, readable, modern CLI was needed

Ginom gives devs the tools they need without the complexity they don’t.


## 🤝 Contributing

Contributions are welcome!
Fork the repo
Create a feature branch
Submit a pull request
Open issues for bugs or suggestions.


⭐ Show Support

If you like the project:

Give it a star on GitHub ⭐

Tell others about it

Contribute code or suggestions

Ginom is built for the community — and by the community.

## 📄 License

MIT License
