import os
import json
from .index import read_index
from .objects import make_blob, make_tree, make_commit
from . import refs
from .config import meta_paths
from .utils import sha256


# ---- Utilities

def ensure_dir(path: str):
    os.makedirs(path, exist_ok=True)


# ---- Init

def init_repo(root: str = "."):
    """Initialize a Ginom repository layout under .ginom/."""
    p = meta_paths(root)
    for d in [p["meta"], p["objects"], p["blobs"], p["commits"],
              p["trees"], p["refs"], p["heads"], p["tags"]]:
        ensure_dir(d)

    # HEAD points to main branch
    if not os.path.exists(p["HEAD"]):
        with open(p["HEAD"], "w") as f:
            f.write("ref: refs/heads/main\n")

    # Create empty branch ref if missing
    main_ref = os.path.join(p["heads"], "main")
    if not os.path.exists(main_ref):
        with open(main_ref, "w") as f:
            f.write("\n")  # no commit yet

    # Index (JSON staging area)
    if not os.path.exists(p["index"]):
        with open(p["index"], "w") as f:
            json.dump({"tracked": []}, f, indent=2)

    # Config
    if not os.path.exists(p["config"]):
        with open(p["config"], "w") as f:
            json.dump({}, f, indent=2)

    # IGNORE
    if not os.path.exists(p["ignore"]):
        with open(p["ignore"], "w") as f:
            f.write("# Ginom ignore patterns (glob-like)\n")

    print("Initialized Ginom repository: .ginom/")


# ---- Object writing

def _write_object(root: str, kind: str, oid: str, data: bytes):
    p = meta_paths(root)
    base = {
        "blob": p["blobs"],
        "tree": p["trees"],
        "commit": p["commits"],
    }[kind]
    os.makedirs(base, exist_ok=True)
    path = os.path.join(base, oid)
    if not os.path.exists(path):
        with open(path, "wb") as f:
            f.write(data)


# ---- Tree building

def build_tree_from_index(root: str):
    p = meta_paths(root)
    idx = read_index(p["index"])
    entries = []
    for rel in idx["tracked"]:
        full = os.path.join(root, rel)
        with open(full, "rb") as f:
            data = f.read()
        blob_oid, blob_data = make_blob(data)
        _write_object(root, "blob", blob_oid, blob_data)
        entries.append({"path": rel, "blob": blob_oid})
    tree_oid, tree_data = make_tree(entries)
    _write_object(root, "tree", tree_oid, tree_data)
    return tree_oid


# ---- Commit saving

def save(root: str, message: str, author: str = "unknown"):
    branch = refs.head_branch(root)
    parent = refs.read_ref(root, branch)
    tree_oid = build_tree_from_index(root)
    commit_oid, commit_data, _payload = make_commit(message, parent, tree_oid, author)
    _write_object(root, "commit", commit_oid, commit_data)
    refs.update_ref(root, branch, commit_oid)
    print(f"Saved commit on {branch}: {commit_oid[:8]}")
    return commit_oid


# ---- Log reading

def log(root: str, limit: int = 50):
    branch = refs.head_branch(root)
    cur = refs.read_ref(root, branch)
    out = []
    while cur and len(out) < limit:
        # read commit object
        p = meta_paths(root)
        path = os.path.join(p["commits"], cur)
        with open(path, "rb") as f:
            raw = f.read()
        # handle both prefixed and plain JSON formats
        if raw.startswith(b"commit\n"):
            payload = json.loads(raw[len(b"commit\n"):].decode())
        else:
            payload = json.loads(raw.decode())
        out.append({
            "oid": cur,
            "message": payload["message"],
            "time": payload["timestamp"]
        })
        cur = payload.get("parent")
    return out
