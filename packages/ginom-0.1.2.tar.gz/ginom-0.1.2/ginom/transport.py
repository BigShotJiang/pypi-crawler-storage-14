# ginom/transport.py
import base64, json, os, requests
from .config import get_config

def _headers(token: str):
    return {"Authorization": f"Bearer {token}", "Accept": "application/vnd.github+json"}

def push(root: str, repo):
    token = get_config(root, "github.token")
    full = get_config(root, "github.repo")  # "user/repo"
    if not token or not full:
        print("Configure with: ginom set github.token <token> and ginom set github.repo user/repo")
        return
    user, name = full.split("/")
    branch = repo["branch"]
    head = repo["commit"]
    snapshot = repo["files"]

    content = json.dumps({"commit": head, "branch": branch, "files": snapshot}, indent=2)
    path = "ginom_state.json"

    rc = requests.get(f"https://api.github.com/repos/{user}/{name}/contents/{path}",
                      headers=_headers(token), params={"ref": branch})
    sha = rc.json().get("sha") if rc.status_code == 200 else None

    data = {
        "message": f"Ginom push: {head or 'empty'}",
        "content": base64.b64encode(content.encode()).decode(),
        "branch": branch
    }
    if sha:
        data["sha"] = sha

    ru = requests.put(f"https://api.github.com/repos/{user}/{name}/contents/{path}",
                      headers=_headers(token), json=data)
    if ru.status_code < 300:
        print("Pushed ginom_state.json")
    else:
        print("Push failed:", ru.status_code, ru.text)

def pull(root: str, repo):
    token = get_config(root, "github.token")
    full = get_config(root, "github.repo")
    if not token or not full:
        print("Configure github.token and github.repo")
        return
    user, name = full.split("/")
    branch = repo["branch"]
    r = requests.get(f"https://api.github.com/repos/{user}/{name}/contents/ginom_state.json",
                     headers=_headers(token), params={"ref": branch})
    if r.status_code != 200:
        print("No remote state")
        return
    content_b64 = r.json()["content"]
    state = json.loads(base64.b64decode(content_b64).decode())
    print(f"Remote commit: {state['commit']}")
    print(f"Files: {list(state['files'].keys())}")
