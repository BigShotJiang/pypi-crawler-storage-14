import os
from .config import meta_paths

def head_branch(root: str):
    p = meta_paths(root)
    with open(p["HEAD"], "r") as f:
        line = f.read().strip()
    assert line.startswith("ref: ")
    ref = line.split("ref: ", 1)[1]
    return os.path.basename(ref)  # e.g., "main"

def set_head(root: str, branch: str):
    p = meta_paths(root)
    with open(p["HEAD"], "w") as f:
        f.write(f"ref: refs/heads/{branch}\n")

def read_ref(root: str, branch: str):
    p = meta_paths(root)
    path = os.path.join(p["heads"], branch)
    try:
        with open(path, "r") as f:
            val = f.read().strip()
            return val or None
    except FileNotFoundError:
        return None

def update_ref(root: str, branch: str, oid: str | None):
    p = meta_paths(root)
    path = os.path.join(p["heads"], branch)
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w") as f:
        f.write((oid or "") + "\n")

def create_branch(root: str, name: str):
    cur = read_ref(root, head_branch(root))
    update_ref(root, name, cur)

def switch_branch(root: str, name: str):
    # Create ref if missing
    if read_ref(root, name) is None:
        update_ref(root, name, None)
    set_head(root, name)
