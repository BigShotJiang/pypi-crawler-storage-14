import json
import time
from .utils import sha256


def make_blob(data: bytes):
    """Create a blob object from raw file data."""
    oid = sha256(b"blob\n" + data)
    return oid, data


def make_tree(entries: list[dict]):
    """Create a tree object from a list of tracked entries."""
    # entries = [{"path": str, "blob": str}]
    content = json.dumps(entries, sort_keys=True).encode()
    oid = sha256(b"tree\n" + content)
    return oid, content


def make_commit(message: str, parent_oid: str | None, tree_oid: str, author: str):
    """Create a commit object with metadata and payload."""
    payload = {
        "message": message,
        "parent": parent_oid,
        "tree": tree_oid,
        "author": author,
        "timestamp": int(time.time()),
    }
    # Store with "commit\n" header so core.log() can strip it
    data = b"commit\n" + json.dumps(payload, sort_keys=True).encode()
    oid = sha256(data)
    return oid, data, payload
