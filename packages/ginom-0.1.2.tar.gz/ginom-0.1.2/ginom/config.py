# ginom/config.py
import os
import json

def meta_paths(root: str):
    meta = os.path.join(root, ".ginom")
    objects = os.path.join(meta, "objects")
    blobs = os.path.join(objects, "blobs")
    commits = os.path.join(objects, "commits")
    trees = os.path.join(objects, "trees")
    refs = os.path.join(meta, "refs")
    heads = os.path.join(refs, "heads")
    tags = os.path.join(refs, "tags")
    head_file = os.path.join(meta, "HEAD")
    index_file = os.path.join(meta, "index")
    config_file = os.path.join(meta, "config.json")
    ignore_file = os.path.join(meta, "IGNORE")
    return {
        "meta": meta,
        "objects": objects,
        "blobs": blobs,
        "commits": commits,
        "trees": trees,
        "refs": refs,
        "heads": heads,
        "tags": tags,
        "HEAD": head_file,
        "index": index_file,
        "config": config_file,
        "ignore": ignore_file,
    }

def read_config(root: str):
    p = meta_paths(root)
    try:
        with open(p["config"], "r") as f:
            return json.load(f)
    except FileNotFoundError:
        return {}

def write_config(root: str, cfg: dict):
    p = meta_paths(root)
    with open(p["config"], "w") as f:
        json.dump(cfg, f, indent=2)

def set_config(root: str, key: str, value):
    cfg = read_config(root)
    cfg[key] = value
    write_config(root, cfg)

def get_config(root: str, key: str, default=None):
    return read_config(root).get(key, default)
