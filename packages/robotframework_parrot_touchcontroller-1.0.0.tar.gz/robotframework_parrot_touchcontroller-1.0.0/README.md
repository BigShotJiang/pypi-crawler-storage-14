# Touch Controller

## Installation

To install from package registry use the following command:

```
$ pip install robotframework-parrot-touchcontroller
```

To install from git repo use the following command:

```
$ pip install .
```

## Example

Example of using the library in Robot Framework is available `example.robot`.