from robot.api.deco import keyword
from parrot.touch.dummy import DummyTouch
from parrot.touch.axitouch import AxiDrawTouch
from parrot.touch.base import Error
from parrot.touch.adbtouch import ADBTouch
from parrot.touch.usbhidtouch import UsbHidTouch
from typing import Dict, Any

class TouchError(Exception):
    """Raised when a device-level touch error occurs."""


class TouchController:
    """
    A Robot Framework library for simulating touch input across various
    device types through a unified interface.

    == Configuration ==

    Touch devices are configured using the `Touch Setup` keyword with a dictionary 
    typically loaded from a YAML file (e.g. `config.yaml`) by importing the library 
    and variables into your test suite. Each entry in the configuration must include 
    a `type` field that specifies the device type. Supported types include:

    - `UsbHidTouch`: USB HID-based touch simulation over TCP.
    - `AxiDrawTouch`: Physical touch simulation using a pen plotter.
    - `ADBTouch`: Android device touch simulation over ADB.

    === UsbHidTouch ===
      Simulates touch over a USB HID device exposed via a TCP server.
      Supported configs:
      - `host`: IP address or hostname of the USB HID server (e.g., `127.0.0.1`)
      - `port`: TCP port number (e.g., `8000`)
      - `width`, `height`: Touch coordinate resolution (e.g., 1024x600)

    === AxiDrawTouch ===
      Controls an AxiDraw pen plotter to simulate physical touchscreen input.
      Supported configs:
      - `device`: Serial device path (e.g., `/dev/ttyUSB0`)
      - `width`, `height`: Touch surface resolution in pixels
      - `start_pos`: Physical start coordinates (e.g., `[0, 0]`)
      - `end_pos`: Physical end coordinates defining working area (e.g., `[8.66, 5.12]`)

    === ADBTouch ===
      Simulates touch events on an Android device using ADB commands.
      Supported configs:
      - `ip`: IP address of the Android device (e.g., `192.168.43.168`)

    === Configuration Sample (config.yaml) ===

    The configuration file is written in YAML format and contains a top-level key
    `TouchConfig` with device definitions:

    | TouchConfig:
    |   T1:
    |     type: UsbHidTouch
    |     host: 127.0.0.1
    |     port: 8000
    |     width: 1024
    |     height: 600
    |
    |   T2:
    |     type: AxiDrawTouch
    |     device: /dev/ttyUSB0
    |     width: 1024
    |     height: 600
    |     start_pos: [0, 0]
    |     end_pos: [8.66, 5.12]
    |
    |   T3:
    |     type: ADBTouch
    |     ip: 192.168.43.168

    = General Usage =

    Setup and initialize touch devices from a YAML configuration. Simulate touch input such as tap and swipe gestures 
    across multiple supported devices. This library supports both real physical systems and simulated touch environments, 
    making it suitable for automated device interaction and UI testing.

    = Example =

    | ***** Settings *****
    | Library    parrot.TouchController
    | Variables  config.yaml
    |
    | ***** Test Cases *****
    | Run Touch Tests
    |     Touch Setup           ${TouchConfig}                           # Initializes all touch devices from the YAML configuration.
    |     Tap                   T1    640    500    0.2                  # Simulates a tap at (640, 500) for 0.2 seconds on T1.
    |     Swipe                 T1    100    100    600    400    0.2    # Simulates swipe from (100,100) to (600,400).
    |     Touch Command         T1    move    0     1                    # Moves the touch to specified screen coordinates.
    |     Touch Command         T1    home                               # Returns the axitouch to its home position.

    """


    ROBOT_LIBRARY_SCOPE = 'GLOBAL'

    def __init__(self) -> None:
        self.devices: Dict[str, Any] = {}

    @keyword("Touch Setup")
    def setup(self, config: Dict[str, Dict[str, Any]]) -> None:
        """Initializes and configures touch controller devices.
        Loads controller instances from the given `Configuration` dictionary 
        and prepares them for input simulation.

        *Syntax*

        | `Touch Setup` | <CONFIG> |

        *Examples*

        | `Touch Setup` | ${TouchConfig} | # Loads and initializes all camera devices defined in the `${CameraConfig}` dictionary. |
        """
        if not isinstance(config, dict):
            raise Error("Expected a dictionary of controller configurations.")

        controller_classes: Dict[str, Any] = {
            "DummyTouch": DummyTouch,
            "AxiDrawTouch": AxiDrawTouch,
            "ADBTouch": ADBTouch,
            "UsbHidTouch": UsbHidTouch,
        }

        for name, dev in config.items():
            class_type = dev.get("type")

            if not class_type or not name:
                raise Error("Each TouchController entry must have 'type' and 'name' fields.")

            if class_type not in controller_classes:
                raise Error(f"Controller class '{class_type}' is not supported.")

            try:
                device = controller_classes[class_type](dev)
                device.touch_init()
            except Error as err:
                raise TouchError(f"Failed to initialize controller '{name}' of type '{class_type}': {err}") from err


            self.devices[name] = device

        print(f"[INFO] Loaded controllers: {list(self.devices.keys())}")

    @keyword("Tap")
    def send_touch(self, device: str, x: float, y: float, tap_time: float = 0.2) -> None:
        """
        Simulates a tap action on the given device at specified screen coordinates.
        Requires the device name, X and Y coordinates in pixels, and an 
        optional tap duration (default: 0.2 seconds). 

        *Syntax*

        | `Tap` | <DEVICE_NAME> | <X> | <Y> | <TAP_TIME> |

        *Examples*

        | `Tap` | T1 | 640 | 500 | 0.2 | # Simulates a tap at (640, 500) on device `T1` with a duration of 0.2 seconds. |

        """
        controller = self.devices.get(device)
        if not controller:
            raise TouchError(f"Touch controller '{device}' not found.")
        controller.touch_tap(float(x), float(y), float(tap_time))

    @keyword("Swipe")
    def send_swipe(
        self,
        device: str,
        x1: float,
        y1: float,
        x2: float,
        y2: float,
    ) -> None:
        """
        Simulates a swipe gesture on the given device from (x1, y1) to (x2, y2).
        Requires the device name, starting and ending coordinates in pixels.

        *Syntax*

        | <DEVICE_NAME> | <DEVICE_NAME> | <X1> | <Y1> | <X2> | <Y2> |

        *Examples*

        | `Swipe` | T1 | 100 | 100 | 600 | 400 | 0.3 | # Simulates a swipe on device `T1` from (100, 100) to (600, 400) |

        """

        controller = self.devices.get(device)
        if not controller:
            raise TouchError(f"Touch controller '{device}' not found.")
        controller.touch_swipe(float(x1), float(y1), float(x2), float(y2))

    @keyword("Touch Command")
    def command(self, device, command, *args):
        """
        Executes a backend-specific touch command on the given device controller.

        This keyword is used to send a command (e.g., `Move`, `Home`) to a specific device. 
        The available commands and required arguments depends on the backend implementation 
        of the touch controller. Currently only the AxiDrawTouch backend has commands.

        AxiDrawTouch backend supports the following commands. 

        - `Move` — Moves to the specified position (in inches) without touching.
          Requires two arguments: `x`, `y`.
        - `Home` — Returns the touch to its home (default) position.
          Takes no arguments.

        *Syntax*

        | Touch Command | <DEVICE_NAME> | <COMMAND> | [<ARG1>] | [<ARG2>] |

        *Examples*

        | Touch Command | T1 | move | 200 | 300 |
        | Touch Command | T1 | home |

        """
        controller = self.devices.get(device)
        if not controller:
            raise TouchError(f"Touch controller '{device}' not found.")
        controller.touch_command(command, *args)


    @keyword("Touch Set Param")
    def set_param_auto_home(self, device: str, param: str, value: str) -> None:
        """
        Sets values to configure runtime parameters for Touch control devices.
        
        Currently, this keyword supports only for `AxiDrawTouch` type devices,

        | *Parameter*       | *Description*                                                         | *Example Value* |
        | `auto_home`       | Specifies the touch action to be directed to the home position        | "True or False" |
       
        *Syntax*

        | `Touch Set Param` | <DEVICE_NAME> | auto_home | <VALUE> |

        *Examples*

        | `Touch Set Param` | T1 | auto_home | True    | # Enables auto-home on the touch controller device. |
        | `Touch Set Param` | T2 | auto_home | False   | # Disables auto-home on the touch controller device. |
        """
        controller = self.devices.get(device)
        if not controller:
            raise TouchError(f"Touch controller '{device}' not found.")
        controller.set_param(param, value)