from parrot.touch.base import BaseTouch
from typing import Any

class DummyTouch(BaseTouch):
    """A dummy touch controller for testing purposes.

    This class simulates touch interactions by printing output
    instead of interacting with physical hardware.
    """

    def __init__(self, config: Any = None) -> None:
        pass

    def touch_init(self) -> None:
        """Initialize the dummy touch system."""
        print("DummyTouch: Initialized")

    def touch_tap(self, x: float, y: float, tap_time) -> None:
        """Simulate a tap gesture at the given coordinates."""
        print(f"DummyTouch: Tap at ({x}, {y}) for {tap_time}s")

    def touch_swipe(
        self,
        startx: float,
        starty: float,
        endx: float,
        endy: float,
        tap_time
    ) -> None:
        """Simulate a swipe gesture from start to end coordinates."""
        print(f"DummyTouch: Swipe from ({startx}, {starty}) to ({endx}, {endy}) for {tap_time}s")

    def touch_command(self, cmd, *args) -> None:
        """Executes a backend-specific touch command on the given device controller."""
        print(f"DummyTouch: Touch command {cmd}, {args}")
