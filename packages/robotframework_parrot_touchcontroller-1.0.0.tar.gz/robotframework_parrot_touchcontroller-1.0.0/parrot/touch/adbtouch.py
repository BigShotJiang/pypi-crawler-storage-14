from parrot import ADBController
from parrot.touch.base import BaseTouch, Error

class ADBTouch(BaseTouch):
    """
    A touch controller implementation using ADB (Android Debug Bridge).

    This class provides methods to simulate touch gestures such as tap and swipe
    on Android devices over a network or USB using ADB shell commands.
    """

    def __init__(self, config: dict):
        """
        Initializes the ADB touch controller.

        The configuration dictionary must contain:
        - `ip`: IP address of the ADB-connected device

        Raises:
            Error: If required configuration is missing or initialization fails.
        """
        try:
            self.device_ip = config["ip"]
            self.adb = ADBController.ADBController()
        except KeyError as err:
            raise Error(f"Missing required configuration key: {err}") from err
        except Exception as err:
            raise Error(f"Initialization failed: {err}") from err

    def touch_init(self):
        """
        Initializes the ADB device connection using the provided IP.

        Raises:
            Error: If the device connection fails.
        """
        try:
            self.adb.adb_ip_connect(self.device_ip)
            print(f"ADBTouch: Connected to device {self.device_ip}")
        except Exception as err:
            raise Error("Initialization failed") from err

    def touch_tap(self, x, y, tap_time):
        """
        Simulates a tap at the given screen coordinates using ADB shell.

        Args:
            x (int | float): X-coordinate in pixels.
            y (int | float): Y-coordinate in pixels.
            tap_time: (unused) Compatibility with base method signature.

        Raises:
            Error: If the tap command fails.
        """
        try:
            cmd = ["input", "tap", str(int(x)), str(int(y))]
            self.adb.adb_shell(cmd)
            print(f"ADBTouch: Tap at ({x}, {y})")
        except Exception as err:
            raise Error(f"Touch tap failed at ({x}, {y})") from err

    def touch_swipe(self, startx, starty, endx, endy, swipe_time):
        """
        Simulates a swipe gesture from start to end coordinates using ADB shell.

        Args:
            startx (int | float): Start X-coordinate in pixels.
            starty (int | float): Start Y-coordinate in pixels.
            endx (int | float): End X-coordinate in pixels.
            endy (int | float): End Y-coordinate in pixels.
            swipe_time: (unused) Compatibility with base method signature.

        Raises:
            Error: If the swipe command fails.
        """
        try:
            cmd = ["input", "swipe", str(int(startx)), str(int(starty)), str(int(endx)), str(int(endy))]
            self.adb.adb_shell(cmd)
            print(f"ADBTouch: Swipe from ({startx}, {starty}) to ({endx}, {endy})")
        except Exception as err:
            raise Error(f"Swipe failed from ({startx}, {starty}) to ({endx}, {endy})") from err
        
    def touch_command(self, cmd, *args):
        raise Error("Commands are not supported by the ADBTouch backend")
