import xmlrpc.client
from typing import Any, Tuple
from parrot.touch.base import BaseTouch, Error


class UsbHidTouch(BaseTouch):
    """
    A touch controller implementation using USB-HID over XML-RPC.

    This class allows simulating tap and swipe gestures by sending touch commands
    over the network to a USB-HID device capable of interpreting XML-RPC messages.
    """

    def __init__(self, config: dict[str, Any]) -> None:
        """
        Initializes the USB-HID touch controller.

        The configuration dictionary must contain:
        - `host`: IP or hostname of the XML-RPC server.
        - `port`: Port number of the server.
        - `width`: Screen width in pixels.
        - `height`: Screen height in pixels.

        Raises:
            Error: If any required configuration is missing or initialization fails.
        """
        try:
            self.host: str = config["host"]
            self.port: int = config["port"]
            self.screen_width_px: int = config["width"]
            self.screen_height_px: int = config["height"]
            self.handler = None
        except KeyError as err:
            raise Error(f"Missing required configuration key: {err}") from err
        except Exception as err:
            raise Error(f"Initialization failed: {err}") from err

    def touch_init(self) -> None:
        """
        Initializes the XML-RPC connection to the USB-HID server.

        Raises:
            Error: If the connection to the HID server fails.
        """
        try:
            self.handler = xmlrpc.client.ServerProxy(f"http://{self.host}:{self.port}/")
            print(f"UsbHidTouch: Connected to {self.host}:{self.port}")
        except Exception as err:
            raise Error(f"Failed to initialize USB-HID connection: {err}") from err

    def _convert_to_hid_coordinates(self, x: float, y: float) -> Tuple[float, float]:
        """
        Converts pixel coordinates to USB-HID scaled coordinates (0 to 0.5).

        Args:
            x (float): X-coordinate in pixels.
            y (float): Y-coordinate in pixels.

        Returns:
            Tuple[float, float]: Normalized HID coordinates.

        Raises:
            Error: If the conversion fails.
        """
        try:
            x_point = (x / self.screen_width_px) * 0.5
            y_point = (y / self.screen_height_px) * 0.5
            return round(x_point, 6), round(y_point, 6)
        except Exception as err:
            raise Error(f"Failed to convert coordinates ({x}, {y})") from err

    def touch_tap(self, x: float, y: float, tap_time) -> None:
        """
        Simulates a tap gesture at the given screen coordinates.

        Args:
            x (float): X-coordinate in pixels.
            y (float): Y-coordinate in pixels.
            tap_time: Duration to hold touch (passed for consistency, but used by remote endpoint).

        Raises:
            Error: If the tap operation fails or response is invalid.
        """
        try:
            hx, hy = self._convert_to_hid_coordinates(x, y)
            command = f"T,{hx},{hy},{hx},{hy},{tap_time}"
            response = self.handler.process_data(command.encode()).data.decode().strip()
            if response != 'EXECUTED':
                raise Error(f"Unexpected response from HID device: {response}")
            print(f"UsbHidTouch: Tap at ({x}, {y}) with response '{response}'")
        except Exception as err:
            raise Error(f"Touch tap failed at ({x}, {y})") from err

    def touch_swipe(self, startx: float, starty: float, endx: float, endy: float, tap_time) -> None:
        """
        Simulates a swipe gesture from start to end coordinates.

        Args:
            startx (float): Start X-coordinate in pixels.
            starty (float): Start Y-coordinate in pixels.
            endx (float): End X-coordinate in pixels.
            endy (float): End Y-coordinate in pixels.
            tap_time: Duration of swipe (passed for consistency, but used by remote endpoint).

        Raises:
            Error: If the swipe operation fails or response is invalid.
        """
        try:
            sx, sy = self._convert_to_hid_coordinates(startx, starty)
            ex, ey = self._convert_to_hid_coordinates(endx, endy)
            command = f"T,{sx},{sy},{ex},{ey},{tap_time}"
            response = self.handler.process_data(command.encode()).data.decode().strip()
            if response != 'EXECUTED':
                raise Error(f"Unexpected response from HID device: {response}")
            print(f"UsbHidTouch: Swipe from ({startx}, {starty}) to ({endx}, {endy}) with response '{response}'")
        except Exception as err:
            raise Error(f"Swipe failed from ({startx}, {starty}) to ({endx}, {endy})") from err

    def touch_command(self, cmd, *args):
        raise Error("Commands are not supported by the UsbHidTouch backend")
