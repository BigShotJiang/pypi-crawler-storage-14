from abc import ABC, abstractmethod

class Error(Exception):
    """Base error for all TouchController implementations."""
    pass

class BaseTouch(ABC):
    @abstractmethod
    def touch_init(self) -> None:
        """Initialize the touch controller."""
        pass

    @abstractmethod
    def touch_tap(self, x: float, y: float, tap_time) -> None:
        """Simulate a tap at (x, y) in pixels for the given duration."""
        pass

    @abstractmethod
    def touch_swipe(
        self,
        startx: float,
        starty: float,
        endx: float,
        endy: float,
        tap_time
    ) -> None:
        """Simulate a swipe from (startx, starty) to (endx, endy) for the given duration."""
        pass
    @abstractmethod
    def touch_command(self, cmd, *args) -> None:
        """Executes a backend-specific touch command on the given device controller."""
        pass
