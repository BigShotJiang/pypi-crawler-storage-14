from robot.api.deco import keyword
from parrot.touch.base import BaseTouch,Error
from typing import Tuple, Any

import xmlrpc.client


class AxiTouchError(Exception):
    """Represents an error in the AxiDrawTouch controller."""


class AxiDrawTouch(BaseTouch):
    """A touch controller implementation using the AxiDraw plotting device.

    This class provides methods to simulate touch gestures such as tap and swipe
    by controlling an AxiDraw plotter based on screen coordinates.
    """

    PROPERTIES = ["auto_home"]

    def __init__(self, config: dict[str, Any]) -> None:
        """Initializes the AxiDraw touch controller.

        The configuration dictionary must contain:
        - `width`: screen width in pixels
        - `height`: screen height in pixels
        - `start_pos`: tuple (x, y) of starting cartesian coordinates (in inches)
        - `end_pos`: tuple (x, y) of ending cartesian coordinates (in inches)

        Raises:
            AxiTouchError: If initialization or connection to AxiDraw fails.
        """

        try:
            uri = f"http://{config['host']}:{config['port']}"
            self.screen_width_px: int = config["width"]
            self.screen_height_px: int = config["height"]
            self.cartesian_start: Tuple[float, float] = config["start_pos"]
            self.cartesian_end: Tuple[float, float] = config["end_pos"]

            self.auto_home = False   # Flag to track auto-home behavior

            # Optional: configure pen heights and speed
            pen_pos_up = 75
            pen_pos_down = 40
            speed_pendown = 100
            speed_penup = 100
            accel = 75

            self.axi = xmlrpc.client.ServerProxy(uri)

            self.axi.connect(accel,
                pen_pos_up, pen_pos_down,
                speed_penup, speed_pendown)

        except KeyError as err:
            raise Error(f"Missing required configuration key: {err}") from err
        except Exception as err:
            raise Error(f"Initialization failed: {err}") from err

    def convert_to_inches(self, x: float, y: float) -> Tuple[float, float]:
            x = float(x)
            y = float(y)
            sx, sy = self.cartesian_start
            ex, ey = self.cartesian_end
            x_scale = (ex - sx) / self.screen_width_px
            y_scale = (ey - sy) / self.screen_height_px
            return round(sx + x * x_scale, 3), round(sy + y * y_scale, 3)


    def touch_init(self) -> None:
        """Initialize the pen by lifting it up and moving to origin (0, 0).

        Raises:
            AxiTouchError: If initialization movement fails.
        """

        try:
            self.axi.penup()
            self.axi.home()
            print("AxiDrawTouch: Initialized and moved to origin")
        except Exception as err:
            raise Error("Initialization failed") from err

    def touch_tap(self, x: float, y: float, tap_time) -> None:
        """Simulate a tap at the given screen coordinates.

        Args:
            x (int | float): X-coordinate in pixels.
            y (int | float): Y-coordinate in pixels.
            tap_time (float, optional): Duration to hold pen down. Defaults to 0.2s.

        Raises:
            AxiTouchError: If the tap operation fails.
        """

        try:
            px, py = self.convert_to_inches(x, y)
            print(px, py)
            self.axi.tap(px, py, tap_time)
            if self.auto_home:
                self.axi.home()
            print(f"AxiDrawTouch: Tap at ({x}, {y}) for {tap_time}s")
        except Exception as err:
            raise Error(f"Touch tap failed at ({x}, {y})") from err

    def touch_swipe(
        self,
        startx: float,
        starty: float,
        endx: float,
        endy: float
    ) -> None:
        """Simulate a swipe gesture from start to end coordinates.

        Args:
            startx (int | float): Start X-coordinate in pixels.
            starty (int | float): Start Y-coordinate in pixels.
            endx (int | float): End X-coordinate in pixels.
            endy (int | float): End Y-coordinate in pixels.
            swipe_time (float, optional): Duration of the swipe. Defaults to 0.2s.

        Raises:
            AxiTouchError: If the swipe operation fails.
        """

        try:
            psx, psy = self.convert_to_inches(startx, starty)
            pex, pey = self.convert_to_inches(endx, endy)
            self.axi.swipe(psx, psy, pex, pey)
            print(f"AxiDrawTouch: Swipe from ({startx}, {starty}) to ({endx}, {endy})")
        except Exception as err:
            raise Error(f"Swipe failed from ({startx}, {starty}) to ({endx}, {endy})") from err


    def move(self, x: float, y: float):
        """
        Moving Axi arm to the absolute position in axi usable
        area. where x and y are inches.
        """
        try:
            if x == 0 and y == 0:
                self.axi.home()
                return
            self.axi.move(x, y)
        except Exception as err:
            raise Error(f"Failed to Move pointing device from ({x}, {y})") from err

    def home(self):
        """Returns the touch to its home default position."""
        try:
            self.axi.home_with_limit_switch()
        except Exception as err:
            raise Error(f"Failed to Home pointing device") from err

    def touch_command(self, cmd, *args):
        """Executes a backend-specific touch command on the given device controller."""
        cmd = cmd.lower()
        if cmd == "move":
            if len(args) != 2:
                raise Error("move command expects x and y as argument")
            x = float(args[0])
            y = float(args[1])
            self.move(x, y)
        elif cmd == "home":
            self.home()

        else:
            raise Error(f"Invalid command {cmd}")

    def set_param(self, param: str, value: bool) -> None:
        """
        Set a runtime parameter for ArucoCapture.

        | *Arguments*    | *Description* |
        | `param (str)`  | Supported: `auto_home`. |
        | `value (bool)` | True or False Value Supported. |

        *Raises:*
        | `Error` | If an unsupported parameter is provided. |
        """
        if param == 'auto_home' and param in self.PROPERTIES:
            self.auto_home = value
        else:
            raise Error(f"ArucoCapture Error: Unsupported parameter: {param}")