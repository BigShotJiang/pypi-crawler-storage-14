from __future__ import annotations

from typing import Any, Dict, Optional, List
import re
import requests
from .endpoints import ENDPOINTS


class EChallanApiClient:
    """
    Minimal Python client for eChallan.
    Replace endpoint paths with actual routes from your deployment.
    """

    def __init__(self, api_key: str, base_url: str = "https://app.echallan.app") -> None:
        self.api_key = api_key
        self.base_url = base_url.rstrip("/")
        self.endpoints = self._load_endpoints()

    def _headers(self) -> Dict[str, str]:
        return {"x-api-key": self.api_key, "Content-Type": "application/json"}

    def _load_endpoints(self) -> Dict[str, Dict[str, str]]:
        """
        Load endpoint metadata generated from the Postman collection (embedded in endpoints.py).
        """
        return {e["id"]: e for e in ENDPOINTS}

    def list_endpoints(self) -> List[Dict[str, Any]]:
        """
        Return all documented endpoints with ids, methods, and paths.
        """
        return list(self.endpoints.values())

    @staticmethod
    def _resolve_path(path_template: str, params: Optional[Dict[str, str]]) -> str:
        """
        Replace {{param}} tokens in the path with values.
        """
        params = params or {}

        def repl(match: re.Match[str]) -> str:
            key = match.group(1)
            return str(params.get(key, match.group(0)))

        return re.sub(r"{{\s*(.*?)\s*}}", repl, path_template)

    def get_health(self) -> Dict[str, Any]:
        url = f"{self.base_url}/health"
        response = requests.get(url, headers=self._headers(), timeout=10)
        response.raise_for_status()
        return response.json()

    def submit_challan(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        url = f"{self.base_url}/challans"
        response = requests.post(url, json=payload, headers=self._headers(), timeout=20)
        response.raise_for_status()
        return response.json()

    def fetch_challan(self, challan_id: str) -> Optional[Dict[str, Any]]:
        url = f"{self.base_url}/challans/{challan_id}"
        response = requests.get(url, headers=self._headers(), timeout=15)
        if response.status_code == 404:
            return None
        response.raise_for_status()
        return response.json()

    def call_endpoint(
        self,
        endpoint_id: str,
        *,
        path_params: Optional[Dict[str, Any]] = None,
        query: Optional[Dict[str, Any]] = None,
        body: Optional[Dict[str, Any]] = None,
        timeout: int = 20,
    ) -> Any:
        """
        Invoke any documented endpoint by its id from the embedded endpoints catalog.

        Args:
            endpoint_id: Identifier from the endpoints catalog (e.g., "vehicle_lookup").
            path_params: Values for templated path segments.
            query: Query parameters to append.
            body: JSON body for POST/PUT/PATCH.
            timeout: Request timeout in seconds.
        """
        endpoint = self.endpoints.get(endpoint_id)
        if not endpoint:
            raise ValueError(f"Unknown endpoint id: {endpoint_id}")

        path = self._resolve_path(endpoint["path"], path_params)
        url = f"{self.base_url}{path}"
        method = endpoint["method"].upper()

        response = requests.request(
            method,
            url,
            headers=self._headers(),
            params=query,
            json=body,
            timeout=timeout,
        )
        if response.status_code == 404:
            return None
        response.raise_for_status()
        content_type = response.headers.get("content-type", "")
        if "application/json" in content_type:
            return response.json()
        return response.text
