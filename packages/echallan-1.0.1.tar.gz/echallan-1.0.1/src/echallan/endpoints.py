"""Auto-generated endpoints catalog and helpers. Do not edit manually."""
from __future__ import annotations

from typing import Any, Dict, List, Optional, TYPE_CHECKING

if TYPE_CHECKING:
    from .client import EChallanApiClient

ENDPOINTS: List[Dict[str, str]] = [
    {
        'id': 'vehicle_lookup',
        'name': 'vehicle-lookup',
        'method': 'GET',
        'path': '/api/vehicles/{{registration_number}}',
        'description': 'vehicle-lookup',
    },
    {
        'id': 'payment_generate',
        'name': 'payment-generate',
        'method': 'POST',
        'path': '/api/payment/generate',
        'description': 'payment-generate',
    },
    {
        'id': 'payment_status',
        'name': 'payment-status',
        'method': 'GET',
        'path': '/api/payment/status',
        'description': 'payment-status',
    },
    {
        'id': 'payment_transactions_post',
        'name': 'payment-transactions-post',
        'method': 'POST',
        'path': '/api/payment/transactions',
        'description': 'payment-transactions-post',
    },
    {
        'id': 'payment_transactions_get',
        'name': 'payment-transactions-get',
        'method': 'GET',
        'path': '/api/payment/transactions',
        'description': 'payment-transactions-get',
    },
    {
        'id': 'vehicle_expired',
        'name': 'vehicle-expired',
        'method': 'GET',
        'path': '/api/vehicles/expired/{{registration_number}}',
        'description': 'vehicle-expired',
    },
    {
        'id': 'challan_status',
        'name': 'challan-status',
        'method': 'GET',
        'path': '/api/challans/{{registration_number}}',
        'description': 'challan-status',
    },
    {
        'id': 'challan_smart',
        'name': 'challan-smart',
        'method': 'GET',
        'path': '/api/challans/smart/{{registration_number}}',
        'description': 'challan-smart',
    },
    {
        'id': 'user_profile',
        'name': 'user-profile',
        'method': 'GET',
        'path': '/api/user/profile',
        'description': 'user-profile',
    },
    {
        'id': 'vehicles_list',
        'name': 'vehicles-list',
        'method': 'GET',
        'path': '/api/vehicles',
        'description': 'vehicles-list',
    },
    {
        'id': 'documents_upload',
        'name': 'documents-upload',
        'method': 'POST',
        'path': '/api/documents',
        'description': 'documents-upload',
    },
    {
        'id': 'documents_list',
        'name': 'documents-list',
        'method': 'GET',
        'path': '/api/documents',
        'description': 'documents-list',
    },
    {
        'id': 'documents_detail',
        'name': 'documents-detail',
        'method': 'GET',
        'path': '/api/documents/{{id}}',
        'description': 'documents-detail',
    },
    {
        'id': 'api_credentials',
        'name': 'api-credentials',
        'method': 'GET',
        'path': '/api/api-credentials',
        'description': 'api-credentials',
    },
    {
        'id': 'services_list',
        'name': 'services-list',
        'method': 'GET',
        'path': '/api/services',
        'description': 'services-list',
    },
    {
        'id': 'tracking_list',
        'name': 'tracking-list',
        'method': 'GET',
        'path': '/api/tracking',
        'description': 'tracking-list',
    },
    {
        'id': 'tracking_detail',
        'name': 'tracking-detail',
        'method': 'GET',
        'path': '/api/tracking/{{id}}',
        'description': 'tracking-detail',
    },
    {
        'id': 'preferences_get',
        'name': 'preferences-get',
        'method': 'GET',
        'path': '/api/preferences',
        'description': 'preferences-get',
    },
    {
        'id': 'challans_payment',
        'name': 'challans-payment',
        'method': 'GET',
        'path': '/api/challans/payment',
        'description': 'challans-payment',
    },
    {
        'id': 'payment_challans_create',
        'name': 'payment-challans-create',
        'method': 'POST',
        'path': '/api/payment/challans',
        'description': 'payment-challans-create',
    },
    {
        'id': 'vehicles_export',
        'name': 'vehicles-export',
        'method': 'GET',
        'path': '/api/vehicles/export',
        'description': 'vehicles-export',
    },
    {
        'id': 'vehicles_categories',
        'name': 'vehicles-categories',
        'method': 'GET',
        'path': '/api/vehicles/categories',
        'description': 'vehicles-categories',
    },
    {
        'id': 'vahanfin_vehicle',
        'name': 'vahanfin-vehicle',
        'method': 'GET',
        'path': '/api/vahanfin/vehicle',
        'description': 'vahanfin-vehicle',
    },
    {
        'id': 'credits_transactions',
        'name': 'credits-transactions',
        'method': 'GET',
        'path': '/api/credits/transactions',
        'description': 'credits-transactions',
    },
    {
        'id': 'credits_purchase',
        'name': 'credits-purchase',
        'method': 'GET',
        'path': '/api/credits',
        'description': 'credits-purchase',
    },
    {
        'id': 'notifications_list',
        'name': 'notifications-list',
        'method': 'GET',
        'path': '/api/notifications',
        'description': 'notifications-list',
    },
    {
        'id': 'notifications_mark_read',
        'name': 'notifications-mark-read',
        'method': 'POST',
        'path': '/api/notifications/mark-read',
        'description': 'notifications-mark-read',
    },
    {
        'id': 'vahanfin_echallan',
        'name': 'vahanfin-echallan',
        'method': 'GET',
        'path': '/api/vahanfin/echallan',
        'description': 'vahanfin-echallan',
    },
    {
        'id': 'api_history_get',
        'name': 'api-history-get',
        'method': 'GET',
        'path': '/api/api-history',
        'description': 'api-history-get',
    },
    {
        'id': 'insights_realtime',
        'name': 'insights-realtime',
        'method': 'GET',
        'path': '/api/insights/realtime',
        'description': 'insights-realtime',
    },
    {
        'id': 'vehicle_detail',
        'name': 'vehicle-detail',
        'method': 'GET',
        'path': '/api/vehicles/{{id}}',
        'description': 'vehicle-detail',
    },
    {
        'id': 'api_credentials_list',
        'name': 'api-credentials-list',
        'method': 'GET',
        'path': '/api/api-credentials',
        'description': 'api-credentials-list',
    },
    {
        'id': 'api_credentials_detail',
        'name': 'api-credentials-detail',
        'method': 'GET',
        'path': '/api/api-credentials/{{id}}',
        'description': 'api-credentials-detail',
    },
    {
        'id': 'api_history_list',
        'name': 'api-history-list',
        'method': 'GET',
        'path': '/api/api-history',
        'description': 'api-history-list',
    },
    {
        'id': 'api_history_detail',
        'name': 'api-history-detail',
        'method': 'GET',
        'path': '/api/api-history/{{id}}',
        'description': 'api-history-detail',
    },
    {
        'id': 'auth_list',
        'name': 'auth-list',
        'method': 'GET',
        'path': '/api/auth',
        'description': 'auth-list',
    },
    {
        'id': 'auth_detail',
        'name': 'auth-detail',
        'method': 'GET',
        'path': '/api/auth/{{id}}',
        'description': 'auth-detail',
    },
    {
        'id': 'challans_list',
        'name': 'challans-list',
        'method': 'GET',
        'path': '/api/challans',
        'description': 'challans-list',
    },
    {
        'id': 'challans_detail',
        'name': 'challans-detail',
        'method': 'GET',
        'path': '/api/challans/{{id}}',
        'description': 'challans-detail',
    },
    {
        'id': 'credits_list',
        'name': 'credits-list',
        'method': 'GET',
        'path': '/api/credits',
        'description': 'credits-list',
    },
    {
        'id': 'credits_detail',
        'name': 'credits-detail',
        'method': 'GET',
        'path': '/api/credits/{{id}}',
        'description': 'credits-detail',
    },
    {
        'id': 'documents_list_2',
        'name': 'documents-list',
        'method': 'GET',
        'path': '/api/documents',
        'description': 'documents-list',
    },
    {
        'id': 'documents_detail_2',
        'name': 'documents-detail',
        'method': 'GET',
        'path': '/api/documents/{{id}}',
        'description': 'documents-detail',
    },
    {
        'id': 'insights_list',
        'name': 'insights-list',
        'method': 'GET',
        'path': '/api/insights',
        'description': 'insights-list',
    },
    {
        'id': 'insights_detail',
        'name': 'insights-detail',
        'method': 'GET',
        'path': '/api/insights/{{id}}',
        'description': 'insights-detail',
    },
    {
        'id': 'notifications_list_2',
        'name': 'notifications-list',
        'method': 'GET',
        'path': '/api/notifications',
        'description': 'notifications-list',
    },
    {
        'id': 'notifications_detail',
        'name': 'notifications-detail',
        'method': 'GET',
        'path': '/api/notifications/{{id}}',
        'description': 'notifications-detail',
    },
    {
        'id': 'payment_list',
        'name': 'payment-list',
        'method': 'GET',
        'path': '/api/payment',
        'description': 'payment-list',
    },
    {
        'id': 'payment_detail',
        'name': 'payment-detail',
        'method': 'GET',
        'path': '/api/payment/{{id}}',
        'description': 'payment-detail',
    },
    {
        'id': 'preferences_list',
        'name': 'preferences-list',
        'method': 'GET',
        'path': '/api/preferences',
        'description': 'preferences-list',
    },
    {
        'id': 'preferences_detail',
        'name': 'preferences-detail',
        'method': 'GET',
        'path': '/api/preferences/{{id}}',
        'description': 'preferences-detail',
    },
    {
        'id': 'profile_list',
        'name': 'profile-list',
        'method': 'GET',
        'path': '/api/profile',
        'description': 'profile-list',
    },
    {
        'id': 'profile_detail',
        'name': 'profile-detail',
        'method': 'GET',
        'path': '/api/profile/{{id}}',
        'description': 'profile-detail',
    },
    {
        'id': 'services_list_2',
        'name': 'services-list',
        'method': 'GET',
        'path': '/api/services',
        'description': 'services-list',
    },
    {
        'id': 'services_detail',
        'name': 'services-detail',
        'method': 'GET',
        'path': '/api/services/{{id}}',
        'description': 'services-detail',
    },
    {
        'id': 'tracking_list_2',
        'name': 'tracking-list',
        'method': 'GET',
        'path': '/api/tracking',
        'description': 'tracking-list',
    },
    {
        'id': 'tracking_detail_2',
        'name': 'tracking-detail',
        'method': 'GET',
        'path': '/api/tracking/{{id}}',
        'description': 'tracking-detail',
    },
    {
        'id': 'transaction_list',
        'name': 'transaction-list',
        'method': 'GET',
        'path': '/api/transaction',
        'description': 'transaction-list',
    },
    {
        'id': 'transaction_detail',
        'name': 'transaction-detail',
        'method': 'GET',
        'path': '/api/transaction/{{id}}',
        'description': 'transaction-detail',
    },
    {
        'id': 'uploads_list',
        'name': 'uploads-list',
        'method': 'GET',
        'path': '/api/uploads',
        'description': 'uploads-list',
    },
    {
        'id': 'uploads_detail',
        'name': 'uploads-detail',
        'method': 'GET',
        'path': '/api/uploads/{{id}}',
        'description': 'uploads-detail',
    },
    {
        'id': 'user_list',
        'name': 'user-list',
        'method': 'GET',
        'path': '/api/user',
        'description': 'user-list',
    },
    {
        'id': 'user_detail',
        'name': 'user-detail',
        'method': 'GET',
        'path': '/api/user/{{id}}',
        'description': 'user-detail',
    },
    {
        'id': 'vahanfin_list',
        'name': 'vahanfin-list',
        'method': 'GET',
        'path': '/api/vahanfin',
        'description': 'vahanfin-list',
    },
    {
        'id': 'vahanfin_detail',
        'name': 'vahanfin-detail',
        'method': 'GET',
        'path': '/api/vahanfin/{{id}}',
        'description': 'vahanfin-detail',
    },
    {
        'id': 'vehicle_service_assignments_list',
        'name': 'vehicle-service-assignments-list',
        'method': 'GET',
        'path': '/api/vehicle-service-assignments',
        'description': 'vehicle-service-assignments-list',
    },
    {
        'id': 'vehicle_service_assignments_detail',
        'name': 'vehicle-service-assignments-detail',
        'method': 'GET',
        'path': '/api/vehicle-service-assignments/{{id}}',
        'description': 'vehicle-service-assignments-detail',
    },
    {
        'id': 'vehicle_services_list',
        'name': 'vehicle-services-list',
        'method': 'GET',
        'path': '/api/vehicle-services',
        'description': 'vehicle-services-list',
    },
    {
        'id': 'vehicle_services_detail',
        'name': 'vehicle-services-detail',
        'method': 'GET',
        'path': '/api/vehicle-services/{{id}}',
        'description': 'vehicle-services-detail',
    },
    {
        'id': 'vehicles_list_2',
        'name': 'vehicles-list',
        'method': 'GET',
        'path': '/api/vehicles',
        'description': 'vehicles-list',
    },
    {
        'id': 'vehicles_detail',
        'name': 'vehicles-detail',
        'method': 'GET',
        'path': '/api/vehicles/{{id}}',
        'description': 'vehicles-detail',
    },
    {
        'id': 'webhook_test_list',
        'name': 'webhook-test-list',
        'method': 'GET',
        'path': '/api/webhook-test',
        'description': 'webhook-test-list',
    },
    {
        'id': 'webhook_test_detail',
        'name': 'webhook-test-detail',
        'method': 'GET',
        'path': '/api/webhook-test/{{id}}',
        'description': 'webhook-test-detail',
    },
    {
        'id': 'challans_summary',
        'name': 'challans-summary',
        'method': 'POST',
        'path': '/api/challans/summary',
        'description': 'challans-summary',
    },
    {
        'id': 'challans_update_status',
        'name': 'challans-update-status',
        'method': 'POST',
        'path': '/api/challans/update-status',
        'description': 'challans-update-status',
    },
    {
        'id': 'challans_webhook',
        'name': 'challans-webhook',
        'method': 'POST',
        'path': '/api/challans/webhook',
        'description': 'challans-webhook',
    },
    {
        'id': 'credits',
        'name': 'credits',
        'method': 'POST',
        'path': '/api/credits',
        'description': 'credits (example purchase/credit payload)',
    },
    {
        'id': 'payment_razorpay_credits',
        'name': 'payment-razorpay-credits',
        'method': 'POST',
        'path': '/api/payment/razorpay/credits',
        'description': 'payment-razorpay-credits',
    },
    {
        'id': 'payment_razorpay_order',
        'name': 'payment-razorpay-order',
        'method': 'POST',
        'path': '/api/payment/razorpay/order',
        'description': 'payment-razorpay-order',
    },
    {
        'id': 'payment',
        'name': 'payment',
        'method': 'POST',
        'path': '/api/payment',
        'description': 'payment (example)',
    },
    {
        'id': 'profile_change_password',
        'name': 'profile-change-password',
        'method': 'POST',
        'path': '/api/profile/change-password',
        'description': 'profile-change-password',
    },
    {
        'id': 'services',
        'name': 'services',
        'method': 'POST',
        'path': '/api/services',
        'description': 'services (example payload)',
    },
    {
        'id': 'user_renewals',
        'name': 'user-renewals',
        'method': 'POST',
        'path': '/api/user-renewals',
        'description': 'user-renewals',
    },
    {
        'id': 'user_vehicle_assignments',
        'name': 'user-vehicle-assignments',
        'method': 'POST',
        'path': '/api/user-vehicle-assignments',
        'description': 'user-vehicle-assignments',
    },
    {
        'id': 'user_vehicle_renewals',
        'name': 'user-vehicle-renewals',
        'method': 'POST',
        'path': '/api/user-vehicle-renewals',
        'description': 'user-vehicle-renewals',
    },
    {
        'id': 'vehicles',
        'name': 'vehicles',
        'method': 'POST',
        'path': '/api/vehicles',
        'description': 'vehicles (example update/creation payload)',
    },
    {
        'id': 'vehicles_selected_update',
        'name': 'vehicles-selected-update',
        'method': 'POST',
        'path': '/api/vehicles/selected-update',
        'description': 'vehicles-selected-update',
    },
    {
        'id': 'webhook_test',
        'name': 'webhook-test',
        'method': 'POST',
        'path': '/api/webhook-test',
        'description': 'webhook-test (example payload)',
    },
]

def vehicle_lookup(client: "EChallanApiClient", registration_number, query: Optional[Dict[str, Any]] = None, body: Optional[Dict[str, Any]] = None, dry_run: bool = False):
    """GET /api/vehicles/{{registration_number}} (vehicle_lookup)"""
    path_params = {"registration_number": registration_number}
    if dry_run:
        resolved = client._resolve_path("/api/vehicles/{{registration_number}}", path_params)
        return {
            "endpoint_id": "vehicle_lookup",
            "method": "GET",
            "path": resolved,
            "url": f"{client.base_url}{resolved}",
            "path_params": path_params,
            "query": query or {},
            "body": body,
        }
    return client.call_endpoint(
        "vehicle_lookup",
        path_params=path_params,
        query=query,
        body=body,
    )

def payment_generate(client: "EChallanApiClient", query: Optional[Dict[str, Any]] = None, body: Optional[Dict[str, Any]] = None, dry_run: bool = False):
    """POST /api/payment/generate (payment_generate)"""
    path_params: Dict[str, Any] = {}
    if dry_run:
        resolved = client._resolve_path("/api/payment/generate", path_params)
        return {
            "endpoint_id": "payment_generate",
            "method": "POST",
            "path": resolved,
            "url": f"{client.base_url}{resolved}",
            "path_params": path_params,
            "query": query or {},
            "body": body,
        }
    return client.call_endpoint(
        "payment_generate",
        path_params=path_params,
        query=query,
        body=body,
    )

def payment_status(client: "EChallanApiClient", query: Optional[Dict[str, Any]] = None, body: Optional[Dict[str, Any]] = None, dry_run: bool = False):
    """GET /api/payment/status (payment_status)"""
    path_params: Dict[str, Any] = {}
    if dry_run:
        resolved = client._resolve_path("/api/payment/status", path_params)
        return {
            "endpoint_id": "payment_status",
            "method": "GET",
            "path": resolved,
            "url": f"{client.base_url}{resolved}",
            "path_params": path_params,
            "query": query or {},
            "body": body,
        }
    return client.call_endpoint(
        "payment_status",
        path_params=path_params,
        query=query,
        body=body,
    )

def payment_transactions_post(client: "EChallanApiClient", query: Optional[Dict[str, Any]] = None, body: Optional[Dict[str, Any]] = None, dry_run: bool = False):
    """POST /api/payment/transactions (payment_transactions_post)"""
    path_params: Dict[str, Any] = {}
    if dry_run:
        resolved = client._resolve_path("/api/payment/transactions", path_params)
        return {
            "endpoint_id": "payment_transactions_post",
            "method": "POST",
            "path": resolved,
            "url": f"{client.base_url}{resolved}",
            "path_params": path_params,
            "query": query or {},
            "body": body,
        }
    return client.call_endpoint(
        "payment_transactions_post",
        path_params=path_params,
        query=query,
        body=body,
    )

def payment_transactions_get(client: "EChallanApiClient", query: Optional[Dict[str, Any]] = None, body: Optional[Dict[str, Any]] = None, dry_run: bool = False):
    """GET /api/payment/transactions (payment_transactions_get)"""
    path_params: Dict[str, Any] = {}
    if dry_run:
        resolved = client._resolve_path("/api/payment/transactions", path_params)
        return {
            "endpoint_id": "payment_transactions_get",
            "method": "GET",
            "path": resolved,
            "url": f"{client.base_url}{resolved}",
            "path_params": path_params,
            "query": query or {},
            "body": body,
        }
    return client.call_endpoint(
        "payment_transactions_get",
        path_params=path_params,
        query=query,
        body=body,
    )

def vehicle_expired(client: "EChallanApiClient", registration_number, query: Optional[Dict[str, Any]] = None, body: Optional[Dict[str, Any]] = None, dry_run: bool = False):
    """GET /api/vehicles/expired/{{registration_number}} (vehicle_expired)"""
    path_params = {"registration_number": registration_number}
    if dry_run:
        resolved = client._resolve_path("/api/vehicles/expired/{{registration_number}}", path_params)
        return {
            "endpoint_id": "vehicle_expired",
            "method": "GET",
            "path": resolved,
            "url": f"{client.base_url}{resolved}",
            "path_params": path_params,
            "query": query or {},
            "body": body,
        }
    return client.call_endpoint(
        "vehicle_expired",
        path_params=path_params,
        query=query,
        body=body,
    )

def challan_status(client: "EChallanApiClient", registration_number, query: Optional[Dict[str, Any]] = None, body: Optional[Dict[str, Any]] = None, dry_run: bool = False):
    """GET /api/challans/{{registration_number}} (challan_status)"""
    path_params = {"registration_number": registration_number}
    if dry_run:
        resolved = client._resolve_path("/api/challans/{{registration_number}}", path_params)
        return {
            "endpoint_id": "challan_status",
            "method": "GET",
            "path": resolved,
            "url": f"{client.base_url}{resolved}",
            "path_params": path_params,
            "query": query or {},
            "body": body,
        }
    return client.call_endpoint(
        "challan_status",
        path_params=path_params,
        query=query,
        body=body,
    )

def challan_smart(client: "EChallanApiClient", registration_number, query: Optional[Dict[str, Any]] = None, body: Optional[Dict[str, Any]] = None, dry_run: bool = False):
    """GET /api/challans/smart/{{registration_number}} (challan_smart)"""
    path_params = {"registration_number": registration_number}
    if dry_run:
        resolved = client._resolve_path("/api/challans/smart/{{registration_number}}", path_params)
        return {
            "endpoint_id": "challan_smart",
            "method": "GET",
            "path": resolved,
            "url": f"{client.base_url}{resolved}",
            "path_params": path_params,
            "query": query or {},
            "body": body,
        }
    return client.call_endpoint(
        "challan_smart",
        path_params=path_params,
        query=query,
        body=body,
    )

def user_profile(client: "EChallanApiClient", query: Optional[Dict[str, Any]] = None, body: Optional[Dict[str, Any]] = None, dry_run: bool = False):
    """GET /api/user/profile (user_profile)"""
    path_params: Dict[str, Any] = {}
    if dry_run:
        resolved = client._resolve_path("/api/user/profile", path_params)
        return {
            "endpoint_id": "user_profile",
            "method": "GET",
            "path": resolved,
            "url": f"{client.base_url}{resolved}",
            "path_params": path_params,
            "query": query or {},
            "body": body,
        }
    return client.call_endpoint(
        "user_profile",
        path_params=path_params,
        query=query,
        body=body,
    )

def vehicles_list(client: "EChallanApiClient", query: Optional[Dict[str, Any]] = None, body: Optional[Dict[str, Any]] = None, dry_run: bool = False):
    """GET /api/vehicles (vehicles_list)"""
    path_params: Dict[str, Any] = {}
    if dry_run:
        resolved = client._resolve_path("/api/vehicles", path_params)
        return {
            "endpoint_id": "vehicles_list",
            "method": "GET",
            "path": resolved,
            "url": f"{client.base_url}{resolved}",
            "path_params": path_params,
            "query": query or {},
            "body": body,
        }
    return client.call_endpoint(
        "vehicles_list",
        path_params=path_params,
        query=query,
        body=body,
    )

def documents_upload(client: "EChallanApiClient", query: Optional[Dict[str, Any]] = None, body: Optional[Dict[str, Any]] = None, dry_run: bool = False):
    """POST /api/documents (documents_upload)"""
    path_params: Dict[str, Any] = {}
    if dry_run:
        resolved = client._resolve_path("/api/documents", path_params)
        return {
            "endpoint_id": "documents_upload",
            "method": "POST",
            "path": resolved,
            "url": f"{client.base_url}{resolved}",
            "path_params": path_params,
            "query": query or {},
            "body": body,
        }
    return client.call_endpoint(
        "documents_upload",
        path_params=path_params,
        query=query,
        body=body,
    )

def documents_list(client: "EChallanApiClient", query: Optional[Dict[str, Any]] = None, body: Optional[Dict[str, Any]] = None, dry_run: bool = False):
    """GET /api/documents (documents_list)"""
    path_params: Dict[str, Any] = {}
    if dry_run:
        resolved = client._resolve_path("/api/documents", path_params)
        return {
            "endpoint_id": "documents_list",
            "method": "GET",
            "path": resolved,
            "url": f"{client.base_url}{resolved}",
            "path_params": path_params,
            "query": query or {},
            "body": body,
        }
    return client.call_endpoint(
        "documents_list",
        path_params=path_params,
        query=query,
        body=body,
    )

def documents_detail(client: "EChallanApiClient", id, query: Optional[Dict[str, Any]] = None, body: Optional[Dict[str, Any]] = None, dry_run: bool = False):
    """GET /api/documents/{{id}} (documents_detail)"""
    path_params = {"id": id}
    if dry_run:
        resolved = client._resolve_path("/api/documents/{{id}}", path_params)
        return {
            "endpoint_id": "documents_detail",
            "method": "GET",
            "path": resolved,
            "url": f"{client.base_url}{resolved}",
            "path_params": path_params,
            "query": query or {},
            "body": body,
        }
    return client.call_endpoint(
        "documents_detail",
        path_params=path_params,
        query=query,
        body=body,
    )

def api_credentials(client: "EChallanApiClient", query: Optional[Dict[str, Any]] = None, body: Optional[Dict[str, Any]] = None, dry_run: bool = False):
    """GET /api/api-credentials (api_credentials)"""
    path_params: Dict[str, Any] = {}
    if dry_run:
        resolved = client._resolve_path("/api/api-credentials", path_params)
        return {
            "endpoint_id": "api_credentials",
            "method": "GET",
            "path": resolved,
            "url": f"{client.base_url}{resolved}",
            "path_params": path_params,
            "query": query or {},
            "body": body,
        }
    return client.call_endpoint(
        "api_credentials",
        path_params=path_params,
        query=query,
        body=body,
    )

def services_list(client: "EChallanApiClient", query: Optional[Dict[str, Any]] = None, body: Optional[Dict[str, Any]] = None, dry_run: bool = False):
    """GET /api/services (services_list)"""
    path_params: Dict[str, Any] = {}
    if dry_run:
        resolved = client._resolve_path("/api/services", path_params)
        return {
            "endpoint_id": "services_list",
            "method": "GET",
            "path": resolved,
            "url": f"{client.base_url}{resolved}",
            "path_params": path_params,
            "query": query or {},
            "body": body,
        }
    return client.call_endpoint(
        "services_list",
        path_params=path_params,
        query=query,
        body=body,
    )

def tracking_list(client: "EChallanApiClient", query: Optional[Dict[str, Any]] = None, body: Optional[Dict[str, Any]] = None, dry_run: bool = False):
    """GET /api/tracking (tracking_list)"""
    path_params: Dict[str, Any] = {}
    if dry_run:
        resolved = client._resolve_path("/api/tracking", path_params)
        return {
            "endpoint_id": "tracking_list",
            "method": "GET",
            "path": resolved,
            "url": f"{client.base_url}{resolved}",
            "path_params": path_params,
            "query": query or {},
            "body": body,
        }
    return client.call_endpoint(
        "tracking_list",
        path_params=path_params,
        query=query,
        body=body,
    )

def tracking_detail(client: "EChallanApiClient", id, query: Optional[Dict[str, Any]] = None, body: Optional[Dict[str, Any]] = None, dry_run: bool = False):
    """GET /api/tracking/{{id}} (tracking_detail)"""
    path_params = {"id": id}
    if dry_run:
        resolved = client._resolve_path("/api/tracking/{{id}}", path_params)
        return {
            "endpoint_id": "tracking_detail",
            "method": "GET",
            "path": resolved,
            "url": f"{client.base_url}{resolved}",
            "path_params": path_params,
            "query": query or {},
            "body": body,
        }
    return client.call_endpoint(
        "tracking_detail",
        path_params=path_params,
        query=query,
        body=body,
    )

def preferences_get(client: "EChallanApiClient", query: Optional[Dict[str, Any]] = None, body: Optional[Dict[str, Any]] = None, dry_run: bool = False):
    """GET /api/preferences (preferences_get)"""
    path_params: Dict[str, Any] = {}
    if dry_run:
        resolved = client._resolve_path("/api/preferences", path_params)
        return {
            "endpoint_id": "preferences_get",
            "method": "GET",
            "path": resolved,
            "url": f"{client.base_url}{resolved}",
            "path_params": path_params,
            "query": query or {},
            "body": body,
        }
    return client.call_endpoint(
        "preferences_get",
        path_params=path_params,
        query=query,
        body=body,
    )

def challans_payment(client: "EChallanApiClient", query: Optional[Dict[str, Any]] = None, body: Optional[Dict[str, Any]] = None, dry_run: bool = False):
    """GET /api/challans/payment (challans_payment)"""
    path_params: Dict[str, Any] = {}
    if dry_run:
        resolved = client._resolve_path("/api/challans/payment", path_params)
        return {
            "endpoint_id": "challans_payment",
            "method": "GET",
            "path": resolved,
            "url": f"{client.base_url}{resolved}",
            "path_params": path_params,
            "query": query or {},
            "body": body,
        }
    return client.call_endpoint(
        "challans_payment",
        path_params=path_params,
        query=query,
        body=body,
    )

def payment_challans_create(client: "EChallanApiClient", query: Optional[Dict[str, Any]] = None, body: Optional[Dict[str, Any]] = None, dry_run: bool = False):
    """POST /api/payment/challans (payment_challans_create)"""
    path_params: Dict[str, Any] = {}
    if dry_run:
        resolved = client._resolve_path("/api/payment/challans", path_params)
        return {
            "endpoint_id": "payment_challans_create",
            "method": "POST",
            "path": resolved,
            "url": f"{client.base_url}{resolved}",
            "path_params": path_params,
            "query": query or {},
            "body": body,
        }
    return client.call_endpoint(
        "payment_challans_create",
        path_params=path_params,
        query=query,
        body=body,
    )

def vehicles_export(client: "EChallanApiClient", query: Optional[Dict[str, Any]] = None, body: Optional[Dict[str, Any]] = None, dry_run: bool = False):
    """GET /api/vehicles/export (vehicles_export)"""
    path_params: Dict[str, Any] = {}
    if dry_run:
        resolved = client._resolve_path("/api/vehicles/export", path_params)
        return {
            "endpoint_id": "vehicles_export",
            "method": "GET",
            "path": resolved,
            "url": f"{client.base_url}{resolved}",
            "path_params": path_params,
            "query": query or {},
            "body": body,
        }
    return client.call_endpoint(
        "vehicles_export",
        path_params=path_params,
        query=query,
        body=body,
    )

def vehicles_categories(client: "EChallanApiClient", query: Optional[Dict[str, Any]] = None, body: Optional[Dict[str, Any]] = None, dry_run: bool = False):
    """GET /api/vehicles/categories (vehicles_categories)"""
    path_params: Dict[str, Any] = {}
    if dry_run:
        resolved = client._resolve_path("/api/vehicles/categories", path_params)
        return {
            "endpoint_id": "vehicles_categories",
            "method": "GET",
            "path": resolved,
            "url": f"{client.base_url}{resolved}",
            "path_params": path_params,
            "query": query or {},
            "body": body,
        }
    return client.call_endpoint(
        "vehicles_categories",
        path_params=path_params,
        query=query,
        body=body,
    )

def vahanfin_vehicle(client: "EChallanApiClient", query: Optional[Dict[str, Any]] = None, body: Optional[Dict[str, Any]] = None, dry_run: bool = False):
    """GET /api/vahanfin/vehicle (vahanfin_vehicle)"""
    path_params: Dict[str, Any] = {}
    if dry_run:
        resolved = client._resolve_path("/api/vahanfin/vehicle", path_params)
        return {
            "endpoint_id": "vahanfin_vehicle",
            "method": "GET",
            "path": resolved,
            "url": f"{client.base_url}{resolved}",
            "path_params": path_params,
            "query": query or {},
            "body": body,
        }
    return client.call_endpoint(
        "vahanfin_vehicle",
        path_params=path_params,
        query=query,
        body=body,
    )

def credits_transactions(client: "EChallanApiClient", query: Optional[Dict[str, Any]] = None, body: Optional[Dict[str, Any]] = None, dry_run: bool = False):
    """GET /api/credits/transactions (credits_transactions)"""
    path_params: Dict[str, Any] = {}
    if dry_run:
        resolved = client._resolve_path("/api/credits/transactions", path_params)
        return {
            "endpoint_id": "credits_transactions",
            "method": "GET",
            "path": resolved,
            "url": f"{client.base_url}{resolved}",
            "path_params": path_params,
            "query": query or {},
            "body": body,
        }
    return client.call_endpoint(
        "credits_transactions",
        path_params=path_params,
        query=query,
        body=body,
    )

def credits_purchase(client: "EChallanApiClient", query: Optional[Dict[str, Any]] = None, body: Optional[Dict[str, Any]] = None, dry_run: bool = False):
    """GET /api/credits (credits_purchase)"""
    path_params: Dict[str, Any] = {}
    if dry_run:
        resolved = client._resolve_path("/api/credits", path_params)
        return {
            "endpoint_id": "credits_purchase",
            "method": "GET",
            "path": resolved,
            "url": f"{client.base_url}{resolved}",
            "path_params": path_params,
            "query": query or {},
            "body": body,
        }
    return client.call_endpoint(
        "credits_purchase",
        path_params=path_params,
        query=query,
        body=body,
    )

def notifications_list(client: "EChallanApiClient", query: Optional[Dict[str, Any]] = None, body: Optional[Dict[str, Any]] = None, dry_run: bool = False):
    """GET /api/notifications (notifications_list)"""
    path_params: Dict[str, Any] = {}
    if dry_run:
        resolved = client._resolve_path("/api/notifications", path_params)
        return {
            "endpoint_id": "notifications_list",
            "method": "GET",
            "path": resolved,
            "url": f"{client.base_url}{resolved}",
            "path_params": path_params,
            "query": query or {},
            "body": body,
        }
    return client.call_endpoint(
        "notifications_list",
        path_params=path_params,
        query=query,
        body=body,
    )

def notifications_mark_read(client: "EChallanApiClient", query: Optional[Dict[str, Any]] = None, body: Optional[Dict[str, Any]] = None, dry_run: bool = False):
    """POST /api/notifications/mark-read (notifications_mark_read)"""
    path_params: Dict[str, Any] = {}
    if dry_run:
        resolved = client._resolve_path("/api/notifications/mark-read", path_params)
        return {
            "endpoint_id": "notifications_mark_read",
            "method": "POST",
            "path": resolved,
            "url": f"{client.base_url}{resolved}",
            "path_params": path_params,
            "query": query or {},
            "body": body,
        }
    return client.call_endpoint(
        "notifications_mark_read",
        path_params=path_params,
        query=query,
        body=body,
    )

def vahanfin_echallan(client: "EChallanApiClient", query: Optional[Dict[str, Any]] = None, body: Optional[Dict[str, Any]] = None, dry_run: bool = False):
    """GET /api/vahanfin/echallan (vahanfin_echallan)"""
    path_params: Dict[str, Any] = {}
    if dry_run:
        resolved = client._resolve_path("/api/vahanfin/echallan", path_params)
        return {
            "endpoint_id": "vahanfin_echallan",
            "method": "GET",
            "path": resolved,
            "url": f"{client.base_url}{resolved}",
            "path_params": path_params,
            "query": query or {},
            "body": body,
        }
    return client.call_endpoint(
        "vahanfin_echallan",
        path_params=path_params,
        query=query,
        body=body,
    )

def api_history_get(client: "EChallanApiClient", query: Optional[Dict[str, Any]] = None, body: Optional[Dict[str, Any]] = None, dry_run: bool = False):
    """GET /api/api-history (api_history_get)"""
    path_params: Dict[str, Any] = {}
    if dry_run:
        resolved = client._resolve_path("/api/api-history", path_params)
        return {
            "endpoint_id": "api_history_get",
            "method": "GET",
            "path": resolved,
            "url": f"{client.base_url}{resolved}",
            "path_params": path_params,
            "query": query or {},
            "body": body,
        }
    return client.call_endpoint(
        "api_history_get",
        path_params=path_params,
        query=query,
        body=body,
    )

def insights_realtime(client: "EChallanApiClient", query: Optional[Dict[str, Any]] = None, body: Optional[Dict[str, Any]] = None, dry_run: bool = False):
    """GET /api/insights/realtime (insights_realtime)"""
    path_params: Dict[str, Any] = {}
    if dry_run:
        resolved = client._resolve_path("/api/insights/realtime", path_params)
        return {
            "endpoint_id": "insights_realtime",
            "method": "GET",
            "path": resolved,
            "url": f"{client.base_url}{resolved}",
            "path_params": path_params,
            "query": query or {},
            "body": body,
        }
    return client.call_endpoint(
        "insights_realtime",
        path_params=path_params,
        query=query,
        body=body,
    )

def vehicle_detail(client: "EChallanApiClient", id, query: Optional[Dict[str, Any]] = None, body: Optional[Dict[str, Any]] = None, dry_run: bool = False):
    """GET /api/vehicles/{{id}} (vehicle_detail)"""
    path_params = {"id": id}
    if dry_run:
        resolved = client._resolve_path("/api/vehicles/{{id}}", path_params)
        return {
            "endpoint_id": "vehicle_detail",
            "method": "GET",
            "path": resolved,
            "url": f"{client.base_url}{resolved}",
            "path_params": path_params,
            "query": query or {},
            "body": body,
        }
    return client.call_endpoint(
        "vehicle_detail",
        path_params=path_params,
        query=query,
        body=body,
    )

def api_credentials_list(client: "EChallanApiClient", query: Optional[Dict[str, Any]] = None, body: Optional[Dict[str, Any]] = None, dry_run: bool = False):
    """GET /api/api-credentials (api_credentials_list)"""
    path_params: Dict[str, Any] = {}
    if dry_run:
        resolved = client._resolve_path("/api/api-credentials", path_params)
        return {
            "endpoint_id": "api_credentials_list",
            "method": "GET",
            "path": resolved,
            "url": f"{client.base_url}{resolved}",
            "path_params": path_params,
            "query": query or {},
            "body": body,
        }
    return client.call_endpoint(
        "api_credentials_list",
        path_params=path_params,
        query=query,
        body=body,
    )

def api_credentials_detail(client: "EChallanApiClient", id, query: Optional[Dict[str, Any]] = None, body: Optional[Dict[str, Any]] = None, dry_run: bool = False):
    """GET /api/api-credentials/{{id}} (api_credentials_detail)"""
    path_params = {"id": id}
    if dry_run:
        resolved = client._resolve_path("/api/api-credentials/{{id}}", path_params)
        return {
            "endpoint_id": "api_credentials_detail",
            "method": "GET",
            "path": resolved,
            "url": f"{client.base_url}{resolved}",
            "path_params": path_params,
            "query": query or {},
            "body": body,
        }
    return client.call_endpoint(
        "api_credentials_detail",
        path_params=path_params,
        query=query,
        body=body,
    )

def api_history_list(client: "EChallanApiClient", query: Optional[Dict[str, Any]] = None, body: Optional[Dict[str, Any]] = None, dry_run: bool = False):
    """GET /api/api-history (api_history_list)"""
    path_params: Dict[str, Any] = {}
    if dry_run:
        resolved = client._resolve_path("/api/api-history", path_params)
        return {
            "endpoint_id": "api_history_list",
            "method": "GET",
            "path": resolved,
            "url": f"{client.base_url}{resolved}",
            "path_params": path_params,
            "query": query or {},
            "body": body,
        }
    return client.call_endpoint(
        "api_history_list",
        path_params=path_params,
        query=query,
        body=body,
    )

def api_history_detail(client: "EChallanApiClient", id, query: Optional[Dict[str, Any]] = None, body: Optional[Dict[str, Any]] = None, dry_run: bool = False):
    """GET /api/api-history/{{id}} (api_history_detail)"""
    path_params = {"id": id}
    if dry_run:
        resolved = client._resolve_path("/api/api-history/{{id}}", path_params)
        return {
            "endpoint_id": "api_history_detail",
            "method": "GET",
            "path": resolved,
            "url": f"{client.base_url}{resolved}",
            "path_params": path_params,
            "query": query or {},
            "body": body,
        }
    return client.call_endpoint(
        "api_history_detail",
        path_params=path_params,
        query=query,
        body=body,
    )

def auth_list(client: "EChallanApiClient", query: Optional[Dict[str, Any]] = None, body: Optional[Dict[str, Any]] = None, dry_run: bool = False):
    """GET /api/auth (auth_list)"""
    path_params: Dict[str, Any] = {}
    if dry_run:
        resolved = client._resolve_path("/api/auth", path_params)
        return {
            "endpoint_id": "auth_list",
            "method": "GET",
            "path": resolved,
            "url": f"{client.base_url}{resolved}",
            "path_params": path_params,
            "query": query or {},
            "body": body,
        }
    return client.call_endpoint(
        "auth_list",
        path_params=path_params,
        query=query,
        body=body,
    )

def auth_detail(client: "EChallanApiClient", id, query: Optional[Dict[str, Any]] = None, body: Optional[Dict[str, Any]] = None, dry_run: bool = False):
    """GET /api/auth/{{id}} (auth_detail)"""
    path_params = {"id": id}
    if dry_run:
        resolved = client._resolve_path("/api/auth/{{id}}", path_params)
        return {
            "endpoint_id": "auth_detail",
            "method": "GET",
            "path": resolved,
            "url": f"{client.base_url}{resolved}",
            "path_params": path_params,
            "query": query or {},
            "body": body,
        }
    return client.call_endpoint(
        "auth_detail",
        path_params=path_params,
        query=query,
        body=body,
    )

def challans_list(client: "EChallanApiClient", query: Optional[Dict[str, Any]] = None, body: Optional[Dict[str, Any]] = None, dry_run: bool = False):
    """GET /api/challans (challans_list)"""
    path_params: Dict[str, Any] = {}
    if dry_run:
        resolved = client._resolve_path("/api/challans", path_params)
        return {
            "endpoint_id": "challans_list",
            "method": "GET",
            "path": resolved,
            "url": f"{client.base_url}{resolved}",
            "path_params": path_params,
            "query": query or {},
            "body": body,
        }
    return client.call_endpoint(
        "challans_list",
        path_params=path_params,
        query=query,
        body=body,
    )

def challans_detail(client: "EChallanApiClient", id, query: Optional[Dict[str, Any]] = None, body: Optional[Dict[str, Any]] = None, dry_run: bool = False):
    """GET /api/challans/{{id}} (challans_detail)"""
    path_params = {"id": id}
    if dry_run:
        resolved = client._resolve_path("/api/challans/{{id}}", path_params)
        return {
            "endpoint_id": "challans_detail",
            "method": "GET",
            "path": resolved,
            "url": f"{client.base_url}{resolved}",
            "path_params": path_params,
            "query": query or {},
            "body": body,
        }
    return client.call_endpoint(
        "challans_detail",
        path_params=path_params,
        query=query,
        body=body,
    )

def credits_list(client: "EChallanApiClient", query: Optional[Dict[str, Any]] = None, body: Optional[Dict[str, Any]] = None, dry_run: bool = False):
    """GET /api/credits (credits_list)"""
    path_params: Dict[str, Any] = {}
    if dry_run:
        resolved = client._resolve_path("/api/credits", path_params)
        return {
            "endpoint_id": "credits_list",
            "method": "GET",
            "path": resolved,
            "url": f"{client.base_url}{resolved}",
            "path_params": path_params,
            "query": query or {},
            "body": body,
        }
    return client.call_endpoint(
        "credits_list",
        path_params=path_params,
        query=query,
        body=body,
    )

def credits_detail(client: "EChallanApiClient", id, query: Optional[Dict[str, Any]] = None, body: Optional[Dict[str, Any]] = None, dry_run: bool = False):
    """GET /api/credits/{{id}} (credits_detail)"""
    path_params = {"id": id}
    if dry_run:
        resolved = client._resolve_path("/api/credits/{{id}}", path_params)
        return {
            "endpoint_id": "credits_detail",
            "method": "GET",
            "path": resolved,
            "url": f"{client.base_url}{resolved}",
            "path_params": path_params,
            "query": query or {},
            "body": body,
        }
    return client.call_endpoint(
        "credits_detail",
        path_params=path_params,
        query=query,
        body=body,
    )

def documents_list_2(client: "EChallanApiClient", query: Optional[Dict[str, Any]] = None, body: Optional[Dict[str, Any]] = None, dry_run: bool = False):
    """GET /api/documents (documents_list_2)"""
    path_params: Dict[str, Any] = {}
    if dry_run:
        resolved = client._resolve_path("/api/documents", path_params)
        return {
            "endpoint_id": "documents_list_2",
            "method": "GET",
            "path": resolved,
            "url": f"{client.base_url}{resolved}",
            "path_params": path_params,
            "query": query or {},
            "body": body,
        }
    return client.call_endpoint(
        "documents_list_2",
        path_params=path_params,
        query=query,
        body=body,
    )

def documents_detail_2(client: "EChallanApiClient", id, query: Optional[Dict[str, Any]] = None, body: Optional[Dict[str, Any]] = None, dry_run: bool = False):
    """GET /api/documents/{{id}} (documents_detail_2)"""
    path_params = {"id": id}
    if dry_run:
        resolved = client._resolve_path("/api/documents/{{id}}", path_params)
        return {
            "endpoint_id": "documents_detail_2",
            "method": "GET",
            "path": resolved,
            "url": f"{client.base_url}{resolved}",
            "path_params": path_params,
            "query": query or {},
            "body": body,
        }
    return client.call_endpoint(
        "documents_detail_2",
        path_params=path_params,
        query=query,
        body=body,
    )

def insights_list(client: "EChallanApiClient", query: Optional[Dict[str, Any]] = None, body: Optional[Dict[str, Any]] = None, dry_run: bool = False):
    """GET /api/insights (insights_list)"""
    path_params: Dict[str, Any] = {}
    if dry_run:
        resolved = client._resolve_path("/api/insights", path_params)
        return {
            "endpoint_id": "insights_list",
            "method": "GET",
            "path": resolved,
            "url": f"{client.base_url}{resolved}",
            "path_params": path_params,
            "query": query or {},
            "body": body,
        }
    return client.call_endpoint(
        "insights_list",
        path_params=path_params,
        query=query,
        body=body,
    )

def insights_detail(client: "EChallanApiClient", id, query: Optional[Dict[str, Any]] = None, body: Optional[Dict[str, Any]] = None, dry_run: bool = False):
    """GET /api/insights/{{id}} (insights_detail)"""
    path_params = {"id": id}
    if dry_run:
        resolved = client._resolve_path("/api/insights/{{id}}", path_params)
        return {
            "endpoint_id": "insights_detail",
            "method": "GET",
            "path": resolved,
            "url": f"{client.base_url}{resolved}",
            "path_params": path_params,
            "query": query or {},
            "body": body,
        }
    return client.call_endpoint(
        "insights_detail",
        path_params=path_params,
        query=query,
        body=body,
    )

def notifications_list_2(client: "EChallanApiClient", query: Optional[Dict[str, Any]] = None, body: Optional[Dict[str, Any]] = None, dry_run: bool = False):
    """GET /api/notifications (notifications_list_2)"""
    path_params: Dict[str, Any] = {}
    if dry_run:
        resolved = client._resolve_path("/api/notifications", path_params)
        return {
            "endpoint_id": "notifications_list_2",
            "method": "GET",
            "path": resolved,
            "url": f"{client.base_url}{resolved}",
            "path_params": path_params,
            "query": query or {},
            "body": body,
        }
    return client.call_endpoint(
        "notifications_list_2",
        path_params=path_params,
        query=query,
        body=body,
    )

def notifications_detail(client: "EChallanApiClient", id, query: Optional[Dict[str, Any]] = None, body: Optional[Dict[str, Any]] = None, dry_run: bool = False):
    """GET /api/notifications/{{id}} (notifications_detail)"""
    path_params = {"id": id}
    if dry_run:
        resolved = client._resolve_path("/api/notifications/{{id}}", path_params)
        return {
            "endpoint_id": "notifications_detail",
            "method": "GET",
            "path": resolved,
            "url": f"{client.base_url}{resolved}",
            "path_params": path_params,
            "query": query or {},
            "body": body,
        }
    return client.call_endpoint(
        "notifications_detail",
        path_params=path_params,
        query=query,
        body=body,
    )

def payment_list(client: "EChallanApiClient", query: Optional[Dict[str, Any]] = None, body: Optional[Dict[str, Any]] = None, dry_run: bool = False):
    """GET /api/payment (payment_list)"""
    path_params: Dict[str, Any] = {}
    if dry_run:
        resolved = client._resolve_path("/api/payment", path_params)
        return {
            "endpoint_id": "payment_list",
            "method": "GET",
            "path": resolved,
            "url": f"{client.base_url}{resolved}",
            "path_params": path_params,
            "query": query or {},
            "body": body,
        }
    return client.call_endpoint(
        "payment_list",
        path_params=path_params,
        query=query,
        body=body,
    )

def payment_detail(client: "EChallanApiClient", id, query: Optional[Dict[str, Any]] = None, body: Optional[Dict[str, Any]] = None, dry_run: bool = False):
    """GET /api/payment/{{id}} (payment_detail)"""
    path_params = {"id": id}
    if dry_run:
        resolved = client._resolve_path("/api/payment/{{id}}", path_params)
        return {
            "endpoint_id": "payment_detail",
            "method": "GET",
            "path": resolved,
            "url": f"{client.base_url}{resolved}",
            "path_params": path_params,
            "query": query or {},
            "body": body,
        }
    return client.call_endpoint(
        "payment_detail",
        path_params=path_params,
        query=query,
        body=body,
    )

def preferences_list(client: "EChallanApiClient", query: Optional[Dict[str, Any]] = None, body: Optional[Dict[str, Any]] = None, dry_run: bool = False):
    """GET /api/preferences (preferences_list)"""
    path_params: Dict[str, Any] = {}
    if dry_run:
        resolved = client._resolve_path("/api/preferences", path_params)
        return {
            "endpoint_id": "preferences_list",
            "method": "GET",
            "path": resolved,
            "url": f"{client.base_url}{resolved}",
            "path_params": path_params,
            "query": query or {},
            "body": body,
        }
    return client.call_endpoint(
        "preferences_list",
        path_params=path_params,
        query=query,
        body=body,
    )

def preferences_detail(client: "EChallanApiClient", id, query: Optional[Dict[str, Any]] = None, body: Optional[Dict[str, Any]] = None, dry_run: bool = False):
    """GET /api/preferences/{{id}} (preferences_detail)"""
    path_params = {"id": id}
    if dry_run:
        resolved = client._resolve_path("/api/preferences/{{id}}", path_params)
        return {
            "endpoint_id": "preferences_detail",
            "method": "GET",
            "path": resolved,
            "url": f"{client.base_url}{resolved}",
            "path_params": path_params,
            "query": query or {},
            "body": body,
        }
    return client.call_endpoint(
        "preferences_detail",
        path_params=path_params,
        query=query,
        body=body,
    )

def profile_list(client: "EChallanApiClient", query: Optional[Dict[str, Any]] = None, body: Optional[Dict[str, Any]] = None, dry_run: bool = False):
    """GET /api/profile (profile_list)"""
    path_params: Dict[str, Any] = {}
    if dry_run:
        resolved = client._resolve_path("/api/profile", path_params)
        return {
            "endpoint_id": "profile_list",
            "method": "GET",
            "path": resolved,
            "url": f"{client.base_url}{resolved}",
            "path_params": path_params,
            "query": query or {},
            "body": body,
        }
    return client.call_endpoint(
        "profile_list",
        path_params=path_params,
        query=query,
        body=body,
    )

def profile_detail(client: "EChallanApiClient", id, query: Optional[Dict[str, Any]] = None, body: Optional[Dict[str, Any]] = None, dry_run: bool = False):
    """GET /api/profile/{{id}} (profile_detail)"""
    path_params = {"id": id}
    if dry_run:
        resolved = client._resolve_path("/api/profile/{{id}}", path_params)
        return {
            "endpoint_id": "profile_detail",
            "method": "GET",
            "path": resolved,
            "url": f"{client.base_url}{resolved}",
            "path_params": path_params,
            "query": query or {},
            "body": body,
        }
    return client.call_endpoint(
        "profile_detail",
        path_params=path_params,
        query=query,
        body=body,
    )

def services_list_2(client: "EChallanApiClient", query: Optional[Dict[str, Any]] = None, body: Optional[Dict[str, Any]] = None, dry_run: bool = False):
    """GET /api/services (services_list_2)"""
    path_params: Dict[str, Any] = {}
    if dry_run:
        resolved = client._resolve_path("/api/services", path_params)
        return {
            "endpoint_id": "services_list_2",
            "method": "GET",
            "path": resolved,
            "url": f"{client.base_url}{resolved}",
            "path_params": path_params,
            "query": query or {},
            "body": body,
        }
    return client.call_endpoint(
        "services_list_2",
        path_params=path_params,
        query=query,
        body=body,
    )

def services_detail(client: "EChallanApiClient", id, query: Optional[Dict[str, Any]] = None, body: Optional[Dict[str, Any]] = None, dry_run: bool = False):
    """GET /api/services/{{id}} (services_detail)"""
    path_params = {"id": id}
    if dry_run:
        resolved = client._resolve_path("/api/services/{{id}}", path_params)
        return {
            "endpoint_id": "services_detail",
            "method": "GET",
            "path": resolved,
            "url": f"{client.base_url}{resolved}",
            "path_params": path_params,
            "query": query or {},
            "body": body,
        }
    return client.call_endpoint(
        "services_detail",
        path_params=path_params,
        query=query,
        body=body,
    )

def tracking_list_2(client: "EChallanApiClient", query: Optional[Dict[str, Any]] = None, body: Optional[Dict[str, Any]] = None, dry_run: bool = False):
    """GET /api/tracking (tracking_list_2)"""
    path_params: Dict[str, Any] = {}
    if dry_run:
        resolved = client._resolve_path("/api/tracking", path_params)
        return {
            "endpoint_id": "tracking_list_2",
            "method": "GET",
            "path": resolved,
            "url": f"{client.base_url}{resolved}",
            "path_params": path_params,
            "query": query or {},
            "body": body,
        }
    return client.call_endpoint(
        "tracking_list_2",
        path_params=path_params,
        query=query,
        body=body,
    )

def tracking_detail_2(client: "EChallanApiClient", id, query: Optional[Dict[str, Any]] = None, body: Optional[Dict[str, Any]] = None, dry_run: bool = False):
    """GET /api/tracking/{{id}} (tracking_detail_2)"""
    path_params = {"id": id}
    if dry_run:
        resolved = client._resolve_path("/api/tracking/{{id}}", path_params)
        return {
            "endpoint_id": "tracking_detail_2",
            "method": "GET",
            "path": resolved,
            "url": f"{client.base_url}{resolved}",
            "path_params": path_params,
            "query": query or {},
            "body": body,
        }
    return client.call_endpoint(
        "tracking_detail_2",
        path_params=path_params,
        query=query,
        body=body,
    )

def transaction_list(client: "EChallanApiClient", query: Optional[Dict[str, Any]] = None, body: Optional[Dict[str, Any]] = None, dry_run: bool = False):
    """GET /api/transaction (transaction_list)"""
    path_params: Dict[str, Any] = {}
    if dry_run:
        resolved = client._resolve_path("/api/transaction", path_params)
        return {
            "endpoint_id": "transaction_list",
            "method": "GET",
            "path": resolved,
            "url": f"{client.base_url}{resolved}",
            "path_params": path_params,
            "query": query or {},
            "body": body,
        }
    return client.call_endpoint(
        "transaction_list",
        path_params=path_params,
        query=query,
        body=body,
    )

def transaction_detail(client: "EChallanApiClient", id, query: Optional[Dict[str, Any]] = None, body: Optional[Dict[str, Any]] = None, dry_run: bool = False):
    """GET /api/transaction/{{id}} (transaction_detail)"""
    path_params = {"id": id}
    if dry_run:
        resolved = client._resolve_path("/api/transaction/{{id}}", path_params)
        return {
            "endpoint_id": "transaction_detail",
            "method": "GET",
            "path": resolved,
            "url": f"{client.base_url}{resolved}",
            "path_params": path_params,
            "query": query or {},
            "body": body,
        }
    return client.call_endpoint(
        "transaction_detail",
        path_params=path_params,
        query=query,
        body=body,
    )

def uploads_list(client: "EChallanApiClient", query: Optional[Dict[str, Any]] = None, body: Optional[Dict[str, Any]] = None, dry_run: bool = False):
    """GET /api/uploads (uploads_list)"""
    path_params: Dict[str, Any] = {}
    if dry_run:
        resolved = client._resolve_path("/api/uploads", path_params)
        return {
            "endpoint_id": "uploads_list",
            "method": "GET",
            "path": resolved,
            "url": f"{client.base_url}{resolved}",
            "path_params": path_params,
            "query": query or {},
            "body": body,
        }
    return client.call_endpoint(
        "uploads_list",
        path_params=path_params,
        query=query,
        body=body,
    )

def uploads_detail(client: "EChallanApiClient", id, query: Optional[Dict[str, Any]] = None, body: Optional[Dict[str, Any]] = None, dry_run: bool = False):
    """GET /api/uploads/{{id}} (uploads_detail)"""
    path_params = {"id": id}
    if dry_run:
        resolved = client._resolve_path("/api/uploads/{{id}}", path_params)
        return {
            "endpoint_id": "uploads_detail",
            "method": "GET",
            "path": resolved,
            "url": f"{client.base_url}{resolved}",
            "path_params": path_params,
            "query": query or {},
            "body": body,
        }
    return client.call_endpoint(
        "uploads_detail",
        path_params=path_params,
        query=query,
        body=body,
    )

def user_list(client: "EChallanApiClient", query: Optional[Dict[str, Any]] = None, body: Optional[Dict[str, Any]] = None, dry_run: bool = False):
    """GET /api/user (user_list)"""
    path_params: Dict[str, Any] = {}
    if dry_run:
        resolved = client._resolve_path("/api/user", path_params)
        return {
            "endpoint_id": "user_list",
            "method": "GET",
            "path": resolved,
            "url": f"{client.base_url}{resolved}",
            "path_params": path_params,
            "query": query or {},
            "body": body,
        }
    return client.call_endpoint(
        "user_list",
        path_params=path_params,
        query=query,
        body=body,
    )

def user_detail(client: "EChallanApiClient", id, query: Optional[Dict[str, Any]] = None, body: Optional[Dict[str, Any]] = None, dry_run: bool = False):
    """GET /api/user/{{id}} (user_detail)"""
    path_params = {"id": id}
    if dry_run:
        resolved = client._resolve_path("/api/user/{{id}}", path_params)
        return {
            "endpoint_id": "user_detail",
            "method": "GET",
            "path": resolved,
            "url": f"{client.base_url}{resolved}",
            "path_params": path_params,
            "query": query or {},
            "body": body,
        }
    return client.call_endpoint(
        "user_detail",
        path_params=path_params,
        query=query,
        body=body,
    )

def vahanfin_list(client: "EChallanApiClient", query: Optional[Dict[str, Any]] = None, body: Optional[Dict[str, Any]] = None, dry_run: bool = False):
    """GET /api/vahanfin (vahanfin_list)"""
    path_params: Dict[str, Any] = {}
    if dry_run:
        resolved = client._resolve_path("/api/vahanfin", path_params)
        return {
            "endpoint_id": "vahanfin_list",
            "method": "GET",
            "path": resolved,
            "url": f"{client.base_url}{resolved}",
            "path_params": path_params,
            "query": query or {},
            "body": body,
        }
    return client.call_endpoint(
        "vahanfin_list",
        path_params=path_params,
        query=query,
        body=body,
    )

def vahanfin_detail(client: "EChallanApiClient", id, query: Optional[Dict[str, Any]] = None, body: Optional[Dict[str, Any]] = None, dry_run: bool = False):
    """GET /api/vahanfin/{{id}} (vahanfin_detail)"""
    path_params = {"id": id}
    if dry_run:
        resolved = client._resolve_path("/api/vahanfin/{{id}}", path_params)
        return {
            "endpoint_id": "vahanfin_detail",
            "method": "GET",
            "path": resolved,
            "url": f"{client.base_url}{resolved}",
            "path_params": path_params,
            "query": query or {},
            "body": body,
        }
    return client.call_endpoint(
        "vahanfin_detail",
        path_params=path_params,
        query=query,
        body=body,
    )

def vehicle_service_assignments_list(client: "EChallanApiClient", query: Optional[Dict[str, Any]] = None, body: Optional[Dict[str, Any]] = None, dry_run: bool = False):
    """GET /api/vehicle-service-assignments (vehicle_service_assignments_list)"""
    path_params: Dict[str, Any] = {}
    if dry_run:
        resolved = client._resolve_path("/api/vehicle-service-assignments", path_params)
        return {
            "endpoint_id": "vehicle_service_assignments_list",
            "method": "GET",
            "path": resolved,
            "url": f"{client.base_url}{resolved}",
            "path_params": path_params,
            "query": query or {},
            "body": body,
        }
    return client.call_endpoint(
        "vehicle_service_assignments_list",
        path_params=path_params,
        query=query,
        body=body,
    )

def vehicle_service_assignments_detail(client: "EChallanApiClient", id, query: Optional[Dict[str, Any]] = None, body: Optional[Dict[str, Any]] = None, dry_run: bool = False):
    """GET /api/vehicle-service-assignments/{{id}} (vehicle_service_assignments_detail)"""
    path_params = {"id": id}
    if dry_run:
        resolved = client._resolve_path("/api/vehicle-service-assignments/{{id}}", path_params)
        return {
            "endpoint_id": "vehicle_service_assignments_detail",
            "method": "GET",
            "path": resolved,
            "url": f"{client.base_url}{resolved}",
            "path_params": path_params,
            "query": query or {},
            "body": body,
        }
    return client.call_endpoint(
        "vehicle_service_assignments_detail",
        path_params=path_params,
        query=query,
        body=body,
    )

def vehicle_services_list(client: "EChallanApiClient", query: Optional[Dict[str, Any]] = None, body: Optional[Dict[str, Any]] = None, dry_run: bool = False):
    """GET /api/vehicle-services (vehicle_services_list)"""
    path_params: Dict[str, Any] = {}
    if dry_run:
        resolved = client._resolve_path("/api/vehicle-services", path_params)
        return {
            "endpoint_id": "vehicle_services_list",
            "method": "GET",
            "path": resolved,
            "url": f"{client.base_url}{resolved}",
            "path_params": path_params,
            "query": query or {},
            "body": body,
        }
    return client.call_endpoint(
        "vehicle_services_list",
        path_params=path_params,
        query=query,
        body=body,
    )

def vehicle_services_detail(client: "EChallanApiClient", id, query: Optional[Dict[str, Any]] = None, body: Optional[Dict[str, Any]] = None, dry_run: bool = False):
    """GET /api/vehicle-services/{{id}} (vehicle_services_detail)"""
    path_params = {"id": id}
    if dry_run:
        resolved = client._resolve_path("/api/vehicle-services/{{id}}", path_params)
        return {
            "endpoint_id": "vehicle_services_detail",
            "method": "GET",
            "path": resolved,
            "url": f"{client.base_url}{resolved}",
            "path_params": path_params,
            "query": query or {},
            "body": body,
        }
    return client.call_endpoint(
        "vehicle_services_detail",
        path_params=path_params,
        query=query,
        body=body,
    )

def vehicles_list_2(client: "EChallanApiClient", query: Optional[Dict[str, Any]] = None, body: Optional[Dict[str, Any]] = None, dry_run: bool = False):
    """GET /api/vehicles (vehicles_list_2)"""
    path_params: Dict[str, Any] = {}
    if dry_run:
        resolved = client._resolve_path("/api/vehicles", path_params)
        return {
            "endpoint_id": "vehicles_list_2",
            "method": "GET",
            "path": resolved,
            "url": f"{client.base_url}{resolved}",
            "path_params": path_params,
            "query": query or {},
            "body": body,
        }
    return client.call_endpoint(
        "vehicles_list_2",
        path_params=path_params,
        query=query,
        body=body,
    )

def vehicles_detail(client: "EChallanApiClient", id, query: Optional[Dict[str, Any]] = None, body: Optional[Dict[str, Any]] = None, dry_run: bool = False):
    """GET /api/vehicles/{{id}} (vehicles_detail)"""
    path_params = {"id": id}
    if dry_run:
        resolved = client._resolve_path("/api/vehicles/{{id}}", path_params)
        return {
            "endpoint_id": "vehicles_detail",
            "method": "GET",
            "path": resolved,
            "url": f"{client.base_url}{resolved}",
            "path_params": path_params,
            "query": query or {},
            "body": body,
        }
    return client.call_endpoint(
        "vehicles_detail",
        path_params=path_params,
        query=query,
        body=body,
    )

def webhook_test_list(client: "EChallanApiClient", query: Optional[Dict[str, Any]] = None, body: Optional[Dict[str, Any]] = None, dry_run: bool = False):
    """GET /api/webhook-test (webhook_test_list)"""
    path_params: Dict[str, Any] = {}
    if dry_run:
        resolved = client._resolve_path("/api/webhook-test", path_params)
        return {
            "endpoint_id": "webhook_test_list",
            "method": "GET",
            "path": resolved,
            "url": f"{client.base_url}{resolved}",
            "path_params": path_params,
            "query": query or {},
            "body": body,
        }
    return client.call_endpoint(
        "webhook_test_list",
        path_params=path_params,
        query=query,
        body=body,
    )

def webhook_test_detail(client: "EChallanApiClient", id, query: Optional[Dict[str, Any]] = None, body: Optional[Dict[str, Any]] = None, dry_run: bool = False):
    """GET /api/webhook-test/{{id}} (webhook_test_detail)"""
    path_params = {"id": id}
    if dry_run:
        resolved = client._resolve_path("/api/webhook-test/{{id}}", path_params)
        return {
            "endpoint_id": "webhook_test_detail",
            "method": "GET",
            "path": resolved,
            "url": f"{client.base_url}{resolved}",
            "path_params": path_params,
            "query": query or {},
            "body": body,
        }
    return client.call_endpoint(
        "webhook_test_detail",
        path_params=path_params,
        query=query,
        body=body,
    )

def challans_summary(client: "EChallanApiClient", query: Optional[Dict[str, Any]] = None, body: Optional[Dict[str, Any]] = None, dry_run: bool = False):
    """POST /api/challans/summary (challans_summary)"""
    path_params: Dict[str, Any] = {}
    if dry_run:
        resolved = client._resolve_path("/api/challans/summary", path_params)
        return {
            "endpoint_id": "challans_summary",
            "method": "POST",
            "path": resolved,
            "url": f"{client.base_url}{resolved}",
            "path_params": path_params,
            "query": query or {},
            "body": body,
        }
    return client.call_endpoint(
        "challans_summary",
        path_params=path_params,
        query=query,
        body=body,
    )

def challans_update_status(client: "EChallanApiClient", query: Optional[Dict[str, Any]] = None, body: Optional[Dict[str, Any]] = None, dry_run: bool = False):
    """POST /api/challans/update-status (challans_update_status)"""
    path_params: Dict[str, Any] = {}
    if dry_run:
        resolved = client._resolve_path("/api/challans/update-status", path_params)
        return {
            "endpoint_id": "challans_update_status",
            "method": "POST",
            "path": resolved,
            "url": f"{client.base_url}{resolved}",
            "path_params": path_params,
            "query": query or {},
            "body": body,
        }
    return client.call_endpoint(
        "challans_update_status",
        path_params=path_params,
        query=query,
        body=body,
    )

def challans_webhook(client: "EChallanApiClient", query: Optional[Dict[str, Any]] = None, body: Optional[Dict[str, Any]] = None, dry_run: bool = False):
    """POST /api/challans/webhook (challans_webhook)"""
    path_params: Dict[str, Any] = {}
    if dry_run:
        resolved = client._resolve_path("/api/challans/webhook", path_params)
        return {
            "endpoint_id": "challans_webhook",
            "method": "POST",
            "path": resolved,
            "url": f"{client.base_url}{resolved}",
            "path_params": path_params,
            "query": query or {},
            "body": body,
        }
    return client.call_endpoint(
        "challans_webhook",
        path_params=path_params,
        query=query,
        body=body,
    )

def credits(client: "EChallanApiClient", query: Optional[Dict[str, Any]] = None, body: Optional[Dict[str, Any]] = None, dry_run: bool = False):
    """POST /api/credits (credits)"""
    path_params: Dict[str, Any] = {}
    if dry_run:
        resolved = client._resolve_path("/api/credits", path_params)
        return {
            "endpoint_id": "credits",
            "method": "POST",
            "path": resolved,
            "url": f"{client.base_url}{resolved}",
            "path_params": path_params,
            "query": query or {},
            "body": body,
        }
    return client.call_endpoint(
        "credits",
        path_params=path_params,
        query=query,
        body=body,
    )

def payment_razorpay_credits(client: "EChallanApiClient", query: Optional[Dict[str, Any]] = None, body: Optional[Dict[str, Any]] = None, dry_run: bool = False):
    """POST /api/payment/razorpay/credits (payment_razorpay_credits)"""
    path_params: Dict[str, Any] = {}
    if dry_run:
        resolved = client._resolve_path("/api/payment/razorpay/credits", path_params)
        return {
            "endpoint_id": "payment_razorpay_credits",
            "method": "POST",
            "path": resolved,
            "url": f"{client.base_url}{resolved}",
            "path_params": path_params,
            "query": query or {},
            "body": body,
        }
    return client.call_endpoint(
        "payment_razorpay_credits",
        path_params=path_params,
        query=query,
        body=body,
    )

def payment_razorpay_order(client: "EChallanApiClient", query: Optional[Dict[str, Any]] = None, body: Optional[Dict[str, Any]] = None, dry_run: bool = False):
    """POST /api/payment/razorpay/order (payment_razorpay_order)"""
    path_params: Dict[str, Any] = {}
    if dry_run:
        resolved = client._resolve_path("/api/payment/razorpay/order", path_params)
        return {
            "endpoint_id": "payment_razorpay_order",
            "method": "POST",
            "path": resolved,
            "url": f"{client.base_url}{resolved}",
            "path_params": path_params,
            "query": query or {},
            "body": body,
        }
    return client.call_endpoint(
        "payment_razorpay_order",
        path_params=path_params,
        query=query,
        body=body,
    )

def payment(client: "EChallanApiClient", query: Optional[Dict[str, Any]] = None, body: Optional[Dict[str, Any]] = None, dry_run: bool = False):
    """POST /api/payment (payment)"""
    path_params: Dict[str, Any] = {}
    if dry_run:
        resolved = client._resolve_path("/api/payment", path_params)
        return {
            "endpoint_id": "payment",
            "method": "POST",
            "path": resolved,
            "url": f"{client.base_url}{resolved}",
            "path_params": path_params,
            "query": query or {},
            "body": body,
        }
    return client.call_endpoint(
        "payment",
        path_params=path_params,
        query=query,
        body=body,
    )

def profile_change_password(client: "EChallanApiClient", query: Optional[Dict[str, Any]] = None, body: Optional[Dict[str, Any]] = None, dry_run: bool = False):
    """POST /api/profile/change-password (profile_change_password)"""
    path_params: Dict[str, Any] = {}
    if dry_run:
        resolved = client._resolve_path("/api/profile/change-password", path_params)
        return {
            "endpoint_id": "profile_change_password",
            "method": "POST",
            "path": resolved,
            "url": f"{client.base_url}{resolved}",
            "path_params": path_params,
            "query": query or {},
            "body": body,
        }
    return client.call_endpoint(
        "profile_change_password",
        path_params=path_params,
        query=query,
        body=body,
    )

def services(client: "EChallanApiClient", query: Optional[Dict[str, Any]] = None, body: Optional[Dict[str, Any]] = None, dry_run: bool = False):
    """POST /api/services (services)"""
    path_params: Dict[str, Any] = {}
    if dry_run:
        resolved = client._resolve_path("/api/services", path_params)
        return {
            "endpoint_id": "services",
            "method": "POST",
            "path": resolved,
            "url": f"{client.base_url}{resolved}",
            "path_params": path_params,
            "query": query or {},
            "body": body,
        }
    return client.call_endpoint(
        "services",
        path_params=path_params,
        query=query,
        body=body,
    )

def user_renewals(client: "EChallanApiClient", query: Optional[Dict[str, Any]] = None, body: Optional[Dict[str, Any]] = None, dry_run: bool = False):
    """POST /api/user-renewals (user_renewals)"""
    path_params: Dict[str, Any] = {}
    if dry_run:
        resolved = client._resolve_path("/api/user-renewals", path_params)
        return {
            "endpoint_id": "user_renewals",
            "method": "POST",
            "path": resolved,
            "url": f"{client.base_url}{resolved}",
            "path_params": path_params,
            "query": query or {},
            "body": body,
        }
    return client.call_endpoint(
        "user_renewals",
        path_params=path_params,
        query=query,
        body=body,
    )

def user_vehicle_assignments(client: "EChallanApiClient", query: Optional[Dict[str, Any]] = None, body: Optional[Dict[str, Any]] = None, dry_run: bool = False):
    """POST /api/user-vehicle-assignments (user_vehicle_assignments)"""
    path_params: Dict[str, Any] = {}
    if dry_run:
        resolved = client._resolve_path("/api/user-vehicle-assignments", path_params)
        return {
            "endpoint_id": "user_vehicle_assignments",
            "method": "POST",
            "path": resolved,
            "url": f"{client.base_url}{resolved}",
            "path_params": path_params,
            "query": query or {},
            "body": body,
        }
    return client.call_endpoint(
        "user_vehicle_assignments",
        path_params=path_params,
        query=query,
        body=body,
    )

def user_vehicle_renewals(client: "EChallanApiClient", query: Optional[Dict[str, Any]] = None, body: Optional[Dict[str, Any]] = None, dry_run: bool = False):
    """POST /api/user-vehicle-renewals (user_vehicle_renewals)"""
    path_params: Dict[str, Any] = {}
    if dry_run:
        resolved = client._resolve_path("/api/user-vehicle-renewals", path_params)
        return {
            "endpoint_id": "user_vehicle_renewals",
            "method": "POST",
            "path": resolved,
            "url": f"{client.base_url}{resolved}",
            "path_params": path_params,
            "query": query or {},
            "body": body,
        }
    return client.call_endpoint(
        "user_vehicle_renewals",
        path_params=path_params,
        query=query,
        body=body,
    )

def vehicles(client: "EChallanApiClient", query: Optional[Dict[str, Any]] = None, body: Optional[Dict[str, Any]] = None, dry_run: bool = False):
    """POST /api/vehicles (vehicles)"""
    path_params: Dict[str, Any] = {}
    if dry_run:
        resolved = client._resolve_path("/api/vehicles", path_params)
        return {
            "endpoint_id": "vehicles",
            "method": "POST",
            "path": resolved,
            "url": f"{client.base_url}{resolved}",
            "path_params": path_params,
            "query": query or {},
            "body": body,
        }
    return client.call_endpoint(
        "vehicles",
        path_params=path_params,
        query=query,
        body=body,
    )

def vehicles_selected_update(client: "EChallanApiClient", query: Optional[Dict[str, Any]] = None, body: Optional[Dict[str, Any]] = None, dry_run: bool = False):
    """POST /api/vehicles/selected-update (vehicles_selected_update)"""
    path_params: Dict[str, Any] = {}
    if dry_run:
        resolved = client._resolve_path("/api/vehicles/selected-update", path_params)
        return {
            "endpoint_id": "vehicles_selected_update",
            "method": "POST",
            "path": resolved,
            "url": f"{client.base_url}{resolved}",
            "path_params": path_params,
            "query": query or {},
            "body": body,
        }
    return client.call_endpoint(
        "vehicles_selected_update",
        path_params=path_params,
        query=query,
        body=body,
    )

def webhook_test(client: "EChallanApiClient", query: Optional[Dict[str, Any]] = None, body: Optional[Dict[str, Any]] = None, dry_run: bool = False):
    """POST /api/webhook-test (webhook_test)"""
    path_params: Dict[str, Any] = {}
    if dry_run:
        resolved = client._resolve_path("/api/webhook-test", path_params)
        return {
            "endpoint_id": "webhook_test",
            "method": "POST",
            "path": resolved,
            "url": f"{client.base_url}{resolved}",
            "path_params": path_params,
            "query": query or {},
            "body": body,
        }
    return client.call_endpoint(
        "webhook_test",
        path_params=path_params,
        query=query,
        body=body,
    )

__all__ = ["ENDPOINTS"] + ['vehicle_lookup', 'payment_generate', 'payment_status', 'payment_transactions_post', 'payment_transactions_get', 'vehicle_expired', 'challan_status', 'challan_smart', 'user_profile', 'vehicles_list', 'documents_upload', 'documents_list', 'documents_detail', 'api_credentials', 'services_list', 'tracking_list', 'tracking_detail', 'preferences_get', 'challans_payment', 'payment_challans_create', 'vehicles_export', 'vehicles_categories', 'vahanfin_vehicle', 'credits_transactions', 'credits_purchase', 'notifications_list', 'notifications_mark_read', 'vahanfin_echallan', 'api_history_get', 'insights_realtime', 'vehicle_detail', 'api_credentials_list', 'api_credentials_detail', 'api_history_list', 'api_history_detail', 'auth_list', 'auth_detail', 'challans_list', 'challans_detail', 'credits_list', 'credits_detail', 'documents_list_2', 'documents_detail_2', 'insights_list', 'insights_detail', 'notifications_list_2', 'notifications_detail', 'payment_list', 'payment_detail', 'preferences_list', 'preferences_detail', 'profile_list', 'profile_detail', 'services_list_2', 'services_detail', 'tracking_list_2', 'tracking_detail_2', 'transaction_list', 'transaction_detail', 'uploads_list', 'uploads_detail', 'user_list', 'user_detail', 'vahanfin_list', 'vahanfin_detail', 'vehicle_service_assignments_list', 'vehicle_service_assignments_detail', 'vehicle_services_list', 'vehicle_services_detail', 'vehicles_list_2', 'vehicles_detail', 'webhook_test_list', 'webhook_test_detail', 'challans_summary', 'challans_update_status', 'challans_webhook', 'credits', 'payment_razorpay_credits', 'payment_razorpay_order', 'payment', 'profile_change_password', 'services', 'user_renewals', 'user_vehicle_assignments', 'user_vehicle_renewals', 'vehicles', 'vehicles_selected_update', 'webhook_test']
