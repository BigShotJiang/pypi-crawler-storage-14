# eChallan Python SDK Docs

Tech-Driven Fleet Compliance & Challan Management Platform  
Experience compliance as easy as buying from Flipkart or Amazon — whether it’s settling a challan or renewing vehicle documents, it’s all just a click away.

## Overview
- Endpoints base: `https://app.echallan.app`
- Auth: `x-api-key`
- Endpoint catalog: embedded in `echallan_api/endpoints.py` (`ENDPOINTS` list + helper functions per route).

## Quick Start (code)

```python
from echallan_api.client import EChallanApiClient
from echallan_api import endpoints

client = EChallanApiClient(api_key="YOUR_KEY", base_url="https://app.echallan.app")

# Health check
print(client.get_health())

# Call a specific endpoint helper
resp = endpoints.vehicle_lookup(client, registration_number="MH01AB1234")
print(resp)

# List all documented endpoints
print([e["id"] for e in client.list_endpoints()])
```

## Notes
- Helper functions in `echallan/endpoints.py` map 1:1 to the documented routes; each supports `query`, `body`, and `dry_run` to preview the request payload/URL without sending it.
- Replace sample values with production keys and parameters from your contract.

## License & Usage
This SDK is Copyright 2025 Vahanfin Solutions Private Limited and
is licensed under the Apache License, Version 2.0. See the top-level
`LICENSE` file for full license text and the `NOTICE` file for important
usage and trademark restrictions. Using SDK code for commercial or
production services without an explicit agreement with Vahanfin may result
in suspension of service or legal action.
