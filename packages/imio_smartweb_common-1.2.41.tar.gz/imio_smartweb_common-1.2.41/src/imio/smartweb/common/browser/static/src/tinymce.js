// Traductions françaises directement dans le JS
tinymce.i18n.add("fr_FR", {
  text_expand_label: "Développer le texte",
  text_improve_label: "Améliorer le texte",
  text_shorter_label: "Raccourcir le texte",
  text_shorter_label: "Raccourcir le texte",
});

tinymce.i18n.add("nl_NL", {
  text_expand_label: "Tekst uitbreiden",
  text_improve_label: "Tekst verbeteren",
  text_shorter_label: "Tekst verkorten",
  text_shorter_label: "Tekst verkorten",
});

tinymce.i18n.add("de_DE", {
  text_expand_label: "Text erweitern",
  text_improve_label: "Text verbessern",
  text_shorter_label: "Text verkürzen",
  text_shorter_label: "Text verkürzen",
});

// --- CSRF helper -------------------------------------------------------------
function getCsrfTokenSync() {
  const meta = document.querySelector('meta[name="csrf-token"]');
  if (meta && meta.content) return meta.content;
  try {
    const xhr = new XMLHttpRequest();
    xhr.open("GET", "@@authenticator", false);
    xhr.send(null);
    const m = /value="([^"]+)"/.exec(xhr.responseText);
    return m ? m[1] : "";
  } catch (e) {
    return "";
  }
}

// --- HTTP helper -------------------------------------------------------------
async function postProcess(url, payload) {
  // const token = getCsrfTokenSync();
  const resp = await fetch(url, {
    method: "POST",
    headers: {
      Accept: "application/json",
      "Content-Type": "application/json; charset=utf-8",
      "X-CSRF-TOKEN": token,
    },
    credentials: "same-origin",
    body: JSON.stringify(payload),
  });
  if (!resp.ok) {
    const txt = await resp.text().catch(() => "");
    throw new Error("HTTP " + resp.status + " – " + txt);
  }
  const ct = resp.headers.get("Content-Type") || "";
  return ct.includes("application/json")
    ? resp.json()
    : { html: await resp.text() };
}

// --- UI helpers (spinner + disable button) -----------------------------------
function startProcessingUI(editor, btnApi) {
  if (btnApi) btnApi.setEnabled(false);
  editor.setProgressState?.(true); // spinner intégré TinyMCE
}
function stopProcessingUI(editor, btnApi) {
  editor.setProgressState?.(false);
  if (btnApi) btnApi.setEnabled(true);
}
async function withProcessingUI(editor, btnApi, fn) {
  try {
    startProcessingUI(editor, btnApi);
    await fn();
    stopProcessingUI(editor, btnApi);
    editor.notificationManager.open({
      text: "Terminé",
      type: "success",
      timeout: 1800,
    });
  } catch (e) {
    console.error("[tinymce-process] error:", e);
    stopProcessingUI(editor, btnApi);
    editor.notificationManager.open({
      text: "Échec du traitement",
      type: "error",
      timeout: 2500,
    });
  }
}

// --- Selection helper --------------------------------------------------------
function getSelectedHtml(editor) {
  // TinyMCE renvoie du HTML formaté si on demande format:"html"
  return editor.selection?.getContent({ format: "html" }) || "";
}

// --- Plugins -----------------------------------------------------------------
(function () {
  if (!window.tinymce) return;

  // ===== Plugin 1 : text_expand =====
  tinymce.PluginManager.add("text_expand", function (editor) {
    let btnApi = null;

    editor.addCommand("textExpandRun", async function () {
      const selectedHtml = getSelectedHtml(editor);
      if (!selectedHtml.trim()) {
        editor.notificationManager.open({
          text: "Sélectionnez du texte à traiter.",
          type: "warning",
          timeout: 2000,
        });
        return;
      }

      // On mémorise la sélection avant l'appel async
      const bookmark = editor.selection.getBookmark(2, true);

      await withProcessingUI(editor, btnApi, async () => {
        const data = await postProcess("@@process-textexpand", {
          html: selectedHtml,
        });
        if (!data || typeof data.html !== "string")
          throw new Error("Réponse invalide");
        editor.undoManager.transact(() => {
          editor.selection.moveToBookmark(bookmark);
          editor.selection.setContent(data.html);
        });
      });
    });

    editor.ui.registry.addButton("text_expand", {
      text: "Text expand",
      tooltip: "Process text expand",
      onAction: () => editor.execCommand("textExpandRun"),
      onSetup: (api) => {
        btnApi = api;
        return () => (btnApi = null);
      },
    });
  });

  // ===== Plugin 2 : text_improve =====
  tinymce.PluginManager.add("text_improve", function (editor) {
    let btnApi = null;

    editor.addCommand("textImproveRun", async function () {
      const selectedHtml = getSelectedHtml(editor);
      if (!selectedHtml.trim()) {
        editor.notificationManager.open({
          text: "Sélectionnez le passage pour améliorer le texte.",
          type: "warning",
          timeout: 2000,
        });
        return;
      }

      const bookmark = editor.selection.getBookmark(2, true);

      await withProcessingUI(editor, btnApi, async () => {
        const data = await postProcess("@@process-textimprove", {
          html: selectedHtml,
        });
        if (!data || typeof data.html !== "string")
          throw new Error("Réponse invalide");
        editor.undoManager.transact(() => {
          editor.selection.moveToBookmark(bookmark);
          editor.selection.setContent(data.html);
        });
      });
    });

    editor.ui.registry.addButton("text_improve", {
      text: "Text improve",
      tooltip: "Améliorer le texte",
      onAction: () => editor.execCommand("textImproveRun"),
      onSetup: (api) => {
        btnApi = api;
        return () => (btnApi = null);
      },
    });
  });

  // ===== Plugin 3 : text_shorter =====
  tinymce.PluginManager.add("text_shorter", function (editor) {
    let btnApi = null;

    editor.addCommand("textShorterRun", async function () {
      const selectedHtml = getSelectedHtml(editor);
      if (!selectedHtml.trim()) {
        editor.notificationManager.open({
          text: "Sélectionnez le passage pour raccourcir le texte.",
          type: "warning",
          timeout: 2000,
        });
        return;
      }

      const bookmark = editor.selection.getBookmark(2, true);

      await withProcessingUI(editor, btnApi, async () => {
        const data = await postProcess("@@process-textshorter", {
          html: selectedHtml,
        });
        if (!data || typeof data.html !== "string")
          throw new Error("Réponse invalide");
        editor.undoManager.transact(() => {
          editor.selection.moveToBookmark(bookmark);
          editor.selection.setContent(data.html);
        });
      });
    });

    editor.ui.registry.addButton("text_shorter", {
      text: "Text shorter",
      tooltip: "Raccourcir le texte",
      onAction: () => editor.execCommand("textShorterRun"),
      onSetup: (api) => {
        btnApi = api;
        return () => (btnApi = null);
      },
    });
  });

  tinymce.PluginManager.add("ia", function (editor) {
    // Déclare ton icône custom (injectée dans le registry de l’éditeur actif)
    editor.ui.registry.addIcon(
      "iacustom",
      `
<svg width="32" height="20" viewBox="0 0 32 20" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M25.8779 0.554711C26.0205 0.522358 26.0793 0.62971 26.1558 0.723826C26.5367 2.14881 26.9911 3.70321 28.1146 4.72231C29.0014 5.52819 30.2382 5.95024 31.3779 6.27671C31.5764 6.33406 32.1249 6.37082 31.9705 6.71641C31.897 6.87817 31.5602 6.90317 31.4102 6.94729C30.3043 7.27081 29.1029 7.67081 28.2279 8.41639C27.1323 9.34432 26.6132 10.8237 26.2396 12.1708C26.2146 12.2678 26.2029 12.4193 26.1661 12.5016C26.1588 12.5163 26.0558 12.6413 26.0455 12.6487C25.9102 12.7384 25.7632 12.6487 25.7088 12.5119C25.6793 12.4399 25.6426 12.3105 25.6205 12.2311C25.1043 10.384 24.5514 8.81197 22.7823 7.82963C21.9323 7.35758 21.047 7.17081 20.1279 6.87964C19.9485 6.82229 19.772 6.68111 19.9117 6.49435C20.025 6.33994 20.3367 6.32818 20.5044 6.27818C21.7926 5.88995 23.1161 5.44289 24.0485 4.41349C24.8352 3.54585 25.2499 2.33263 25.572 1.22529C25.6191 1.05618 25.6779 0.598828 25.8793 0.556181H25.8764L25.8779 0.554711Z" fill="#E6007E"/>
<path d="M5.88252 13.3328C5.65016 12.6681 5.49134 11.974 5.40752 11.2476C3.80164 12.0755 2.21783 13.0064 0.703125 14.0505C0.84136 13.9828 0.995771 13.9402 1.15901 13.9299C1.18695 13.9284 3.02959 13.8019 5.88399 13.3328H5.88252Z" fill="#7D1751"/>
<path d="M0.0154884 15.2306C-0.00362921 14.9438 0.0787234 14.6732 0.231664 14.4541C-0.0683348 14.86 -0.0859818 15.4261 0.231664 15.86C0.289017 15.9379 0.353722 16.0056 0.42431 16.0658C0.191958 15.8585 0.0375471 15.5644 0.0169589 15.2306H0.0154884Z" fill="#7D1751"/>
<path d="M0.494761 16.1246C0.482996 16.1158 0.471232 16.107 0.460938 16.0967C0.472702 16.1055 0.482996 16.1158 0.494761 16.1246Z" fill="#7D1751"/>
<path d="M10.3879 4.93377C11.7467 3.52937 13.4438 2.80732 15.407 2.80732C17.2555 2.80732 18.8349 3.44702 20.179 4.69407C21.1217 4.38966 22.0511 4.01172 22.7981 3.35732C22.6658 3.21026 22.5305 3.06467 22.3893 2.92203C20.4276 0.986754 18.0879 0 15.332 0C12.5761 0 10.2364 0.948519 8.27467 2.92203C6.31291 4.8573 5.33203 7.21169 5.33203 9.98077C5.33203 10.4131 5.3585 10.8352 5.40703 11.2469C6.37173 10.7499 7.34526 10.2911 8.31437 9.8646C8.34084 7.94256 9.02025 6.30875 10.3879 4.9323V4.93377Z" fill="#282828"/>
<path d="M22.4232 11.1017C22.21 12.6076 21.5512 13.9355 20.4262 15.0679C19.0306 16.4723 17.3703 17.1943 15.4071 17.1943C13.4439 17.1943 11.7836 16.4737 10.388 15.0679C10.3601 15.0385 10.3336 15.0076 10.3056 14.9782C9.13947 15.2355 8.04977 15.4473 7.05859 15.6208C7.41153 16.1282 7.81447 16.6149 8.27624 17.0781C10.238 19.0134 12.5777 20.0002 15.3336 20.0002C18.0894 20.0002 20.4291 19.0516 22.3909 17.0781C23.4262 16.037 24.185 14.8885 24.6747 13.6311C24.3571 12.5179 24.0085 11.5106 23.3659 10.6812C23.0527 10.8253 22.7394 10.965 22.4262 11.1017H22.4232Z" fill="#282828"/>
<path d="M7.05078 13.131C7.62137 13.028 8.22431 12.9119 8.85224 12.781C8.79195 12.6383 8.73607 12.4942 8.68607 12.3486C8.14048 12.5972 7.5949 12.8589 7.05078 13.131Z" fill="#282828"/>
<path d="M7.05183 13.1309C7.59595 12.8588 8.14153 12.5971 8.68712 12.3485C8.43565 11.6103 8.31065 10.8236 8.31065 9.98092C8.31065 9.94269 8.31212 9.90445 8.31359 9.86475C7.34448 10.2897 6.37242 10.75 5.40625 11.2471C5.49007 11.9735 5.6489 12.6677 5.88125 13.3324C6.25478 13.2706 6.64448 13.2044 7.05036 13.1309H7.05183Z" fill="#282828"/>
<path d="M0.509879 14.1822C0.573115 14.138 0.63782 14.0939 0.702526 14.0498C0.51135 14.1425 0.349586 14.2822 0.230469 14.4542C0.305468 14.3513 0.399586 14.2586 0.509879 14.1807V14.1822Z" fill="#E6007E"/>
<path d="M0.46011 16.0983C0.446875 16.088 0.43511 16.0777 0.421875 16.0674C0.43364 16.0777 0.446875 16.088 0.46011 16.0983Z" fill="#E6007E"/>
<path d="M1.94365 16.1454C1.49954 16.4571 0.911303 16.4322 0.492188 16.1248C0.718657 16.2983 1.00689 16.3939 1.31424 16.3748C1.43924 16.366 3.6657 16.216 7.0554 15.6204C6.62599 15.0013 6.27305 14.3528 6.00393 13.6689C4.61423 14.4101 3.24953 15.2322 1.94218 16.1454H1.94365Z" fill="#E6007E"/>
<path d="M22.4981 9.81896C22.3128 9.67926 22.1113 9.54691 21.8907 9.42485C21.6084 9.2675 21.3216 9.14397 21.0319 9.03662C17.2996 10.6278 13.6422 11.6851 10.7363 12.3675C10.0878 12.5204 9.45988 12.6572 8.85547 12.7822C9.18488 13.5689 9.6687 14.2983 10.3069 14.9777C10.6158 14.9101 10.9275 14.8395 11.2466 14.7645C13.0422 14.3454 15.1128 13.7866 17.3157 13.0557C18.9657 12.5057 20.6892 11.8586 22.426 11.1013C22.4775 10.7381 22.5039 10.3645 22.5039 9.9822C22.5039 9.92779 22.4995 9.87338 22.4995 9.81896H22.4981Z" fill="#E6007E"/>
<path d="M1.94679 16.1452C3.25267 15.232 4.61884 14.41 6.00854 13.6688C5.96442 13.557 5.92325 13.4453 5.88354 13.332C3.02914 13.8011 1.1865 13.9276 1.15856 13.9291C0.995325 13.9394 0.842385 13.982 0.702679 14.0497C0.639444 14.0938 0.574739 14.1364 0.510033 14.182C0.398269 14.26 0.305622 14.3526 0.230622 14.4555C0.0776816 14.6747 -0.00467104 14.9452 0.0144465 15.232C0.0365053 15.5673 0.189446 15.8614 0.421798 16.0673C0.433563 16.0776 0.446798 16.0879 0.460033 16.0982C0.471798 16.107 0.482092 16.1173 0.493856 16.1261C0.911502 16.4335 1.49974 16.457 1.94532 16.1467L1.94679 16.1452Z" fill="#E6007E"/>
<path d="M8.85486 12.7803C8.22692 12.9097 7.62545 13.0259 7.0534 13.1303C6.7034 13.3053 6.35487 13.4832 6.00781 13.6685C6.27693 14.3523 6.6284 15.0008 7.05928 15.6199C8.05045 15.4464 9.14015 15.2347 10.3063 14.9773C9.66662 14.2979 9.18427 13.5685 8.85486 12.7817V12.7803Z" fill="#E6007E"/>
<path d="M22.4974 9.81885C22.4974 9.87326 22.5018 9.9262 22.5018 9.98208C22.5018 10.3659 22.4753 10.738 22.4238 11.1012C22.7371 10.9644 23.0503 10.8247 23.3635 10.6806C23.1209 10.3674 22.8385 10.0777 22.4959 9.81885H22.4974Z" fill="#E6007E"/>
<path d="M6.00634 13.6691C6.3534 13.4838 6.70193 13.3059 7.05193 13.1309C6.64605 13.2044 6.25487 13.272 5.88281 13.3323C5.92252 13.4456 5.96369 13.5573 6.00781 13.6691H6.00634Z" fill="#E6007E"/>
</svg>
     `
    );

    editor.ui.registry.addIcon(
      "iashorter",
      `
      <svg width="100" height="96" viewBox="0 0 100 96" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path d="M33.4583 44.1499H4.04167C1.80952 44.1499 0 45.9673 0 48.2092V50.6782C0 52.9201 1.80952 54.7375 4.04167 54.7375H33.4583C35.6905 54.7375 37.5 52.9201 37.5 50.6782V48.2092C37.5 45.9673 35.6905 44.1499 33.4583 44.1499Z" fill="#282828"/>
      <path d="M70.9583 22.5981H4.04167C1.80952 22.5981 0 24.4155 0 26.6574V29.1265C0 31.3684 1.80952 33.1858 4.04167 33.1858H70.9583C73.1905 33.1858 75 31.3684 75 29.1265V26.6574C75 24.4155 73.1905 22.5981 70.9583 22.5981Z" fill="#282828"/>
      <path d="M95.9583 0H4.04167C1.80952 0 0 1.8174 0 4.05929V6.52833C0 8.77022 1.80952 10.5876 4.04167 10.5876H95.9583C98.1905 10.5876 100 8.77022 100 6.52833V4.05929C100 1.8174 98.1905 0 95.9583 0Z" fill="#282828"/>
      <path d="M74.7917 49.4646C75.3333 49.3391 75.5417 49.7576 75.875 50.1342C77.3333 55.6163 79.0833 61.5588 83.375 65.4925C86.75 68.5893 91.5 70.2214 95.8333 71.4768C96.5833 71.6861 98.7083 71.8535 98.0833 73.1508C97.7917 73.7785 96.5 73.8622 95.9583 74.0296C91.75 75.285 87.125 76.7916 83.7917 79.6791C79.625 83.2362 77.625 88.9276 76.2083 94.0749C76.125 94.4515 76.0833 95.0374 75.9167 95.3304C75.9167 95.3722 75.5 95.8744 75.4583 95.9162C74.9583 96.251 74.375 95.9162 74.1667 95.3722C74.0417 95.0793 73.9167 94.6189 73.8333 94.2842C71.875 87.2118 69.75 81.1438 63 77.3774C59.75 75.578 56.375 74.8665 52.875 73.7366C52.2083 73.5274 51.5 72.9834 52.0417 72.2719C52.4583 71.6861 53.6667 71.6442 54.2917 71.435C59.2083 69.9284 64.25 68.2127 67.8333 64.2789C70.8333 60.9311 72.4167 56.2859 73.6667 52.0592C73.8333 51.3896 74.0833 49.6739 74.8333 49.5065L74.7917 49.4646Z" fill="#E6007E"/>
      </svg>

      `
    );

    editor.ui.registry.addIcon(
      "iaexpand",
      `
      <svg width="100" height="96" viewBox="0 0 100 96" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path d="M33.4583 51.8501L4.04167 51.8501C1.80952 51.8501 -1.58883e-07 50.0327 -3.54874e-07 47.7908L-5.70725e-07 45.3218C-7.66716e-07 43.0799 1.80951 41.2625 4.04167 41.2625L33.4583 41.2625C35.6905 41.2625 37.5 43.0799 37.5 45.3218L37.5 47.7908C37.5 50.0327 35.6905 51.8501 33.4583 51.8501Z" fill="#282828"/>
      <path d="M70.9583 73.4019L4.04167 73.4019C1.80952 73.4019 -1.58882e-07 71.5845 -3.54874e-07 69.3426L-5.70725e-07 66.8735C-7.66717e-07 64.6316 1.80951 62.8142 4.04167 62.8142L70.9583 62.8142C73.1905 62.8142 75 64.6316 75 66.8735L75 69.3426C75 71.5845 73.1905 73.4019 70.9583 73.4019Z" fill="#282828"/>
      <path d="M95.9583 96L4.04167 96C1.80952 96 -1.58882e-07 94.1826 -3.54874e-07 91.9407L-5.70725e-07 89.4717C-7.66717e-07 87.2298 1.80951 85.4124 4.04167 85.4124L95.9583 85.4124C98.1905 85.4124 100 87.2298 100 89.4717L100 91.9407C100 94.1826 98.1905 96 95.9583 96Z" fill="#282828"/>
      <path d="M77.4056 46.5354C76.8639 46.6609 76.6556 46.2424 76.3223 45.8658C74.8639 40.3837 73.1139 34.4412 68.8223 30.5075C65.4473 27.4107 60.6973 25.7786 56.3639 24.5232C55.6139 24.3139 53.4889 24.1465 54.1139 22.8492C54.4056 22.2215 55.6973 22.1378 56.2389 21.9704C60.4473 20.715 65.0723 19.2084 68.4056 16.3209C72.5723 12.7638 74.5723 7.07244 75.9889 1.9251C76.0723 1.54846 76.1139 0.962584 76.2806 0.669646C76.2806 0.627795 76.6973 0.125621 76.7389 0.0837698C77.2389 -0.251016 77.8223 0.0837661 78.0306 0.627795C78.1556 0.920734 78.2806 1.38106 78.3639 1.71585C80.3223 8.78821 82.4473 14.8562 89.1973 18.6226C92.4473 20.422 95.8223 21.1335 99.3223 22.2634C99.9889 22.4726 100.697 23.0166 100.156 23.7281C99.7389 24.3139 98.5306 24.3558 97.9056 24.565C92.9889 26.0716 87.9473 27.7873 84.3639 31.7211C81.3639 35.069 79.7806 39.7141 78.5306 43.9408C78.3639 44.6104 78.1139 46.3261 77.3639 46.4935L77.4056 46.5354Z" fill="#E6007E"/>
      </svg>

      `
    );

    editor.ui.registry.addIcon(
      "iaimprove",
      `
        <svg width="100" height="102" viewBox="0 0 100 102" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path fill-rule="evenodd" clip-rule="evenodd" d="M67.3925 22.0785C65.1216 19.8554 61.486 19.8554 59.2179 22.0785L1.40159 80.4139C-0.467197 82.5974 -0.467197 85.8133 1.40159 87.9968L13.6648 100.246C16.0008 102.58 19.5034 102.58 21.8422 100.246L80.2418 42.4937C81.9945 40.743 81.9945 36.6616 80.2418 34.3282L67.7662 22.4575L67.3953 22.0785H67.3925ZM75.5698 38.4124L63.8899 26.7453L46.9066 43.0311L58.5186 55.3346L75.5698 38.4152V38.4124Z" fill="#282828"/>
        <path d="M87.7392 53.6969C88.0252 53.6319 88.1413 53.8468 88.297 54.0363C89.0587 56.8902 89.9704 60.0014 92.2215 62.0407C93.9968 63.6557 96.4772 64.4985 98.7594 65.1519C99.1558 65.2678 100.257 65.3386 99.9486 66.0315C99.8014 66.3568 99.1275 66.4049 98.8245 66.4925C96.6074 67.1402 94.2035 67.9407 92.448 69.4312C90.2536 71.2895 89.2116 74.2508 88.4641 76.9462C88.4131 77.1414 88.3904 77.444 88.3168 77.6081C88.3027 77.6364 88.096 77.8881 88.0761 77.9022C87.8043 78.0832 87.5098 77.9022 87.4022 77.6279C87.3428 77.4836 87.2692 77.2234 87.2267 77.065C86.1932 73.3683 85.0833 70.2203 81.5411 68.2546C79.8393 67.3099 78.064 66.9366 76.2207 66.3539C75.8611 66.238 75.51 65.958 75.7874 65.5818C76.014 65.2707 76.6397 65.2509 76.9767 65.149C79.559 64.3712 82.2093 63.4775 84.0781 61.4184C85.6552 59.6818 86.4848 57.255 87.1304 55.0347C87.2267 54.6953 87.3428 53.7818 87.7477 53.6941H87.742L87.7392 53.6969Z" fill="#E6007E"/>
        <path d="M87.7392 0.0113778C88.0252 -0.0536751 88.1413 0.161282 88.297 0.350784C89.0587 3.20462 89.9704 6.31584 92.2215 8.35511C93.9968 9.97012 96.4772 10.813 98.7594 11.4663C99.1558 11.5823 100.257 11.653 99.9486 12.346C99.8014 12.6712 99.1275 12.7193 98.8245 12.807C96.6074 13.4547 94.2035 14.2551 92.448 15.7457C90.2536 17.6039 89.2116 20.5652 88.4641 23.2607C88.4131 23.4558 88.3904 23.7585 88.3168 23.9225C88.3027 23.9508 88.096 24.2025 88.0761 24.2167C87.8043 24.3977 87.5098 24.2167 87.4022 23.9423C87.3428 23.7981 87.2692 23.5379 87.2267 23.3795C86.1932 19.6828 85.0833 16.5348 81.5411 14.5691C79.8393 13.6244 78.064 13.251 76.2207 12.6684C75.8611 12.5524 75.51 12.2724 75.7874 11.8962C76.014 11.5851 76.6397 11.5653 76.9767 11.4635C79.559 10.6857 82.2093 9.79193 84.0781 7.73286C85.6552 5.99624 86.4848 3.56948 87.1304 1.3492C87.2267 1.0098 87.3428 0.0962293 87.7477 0.00854938H87.742L87.7392 0.0113778Z" fill="#E6007E"/>
        <path d="M36.6279 0.0113778C36.9139 -0.0536751 37.0299 0.161282 37.1857 0.350784C37.9473 3.20462 38.8591 6.31584 41.1101 8.35511C42.8855 9.97012 45.3659 10.813 47.6481 11.4663C48.0445 11.5823 49.1459 11.653 48.8373 12.346C48.6901 12.6712 48.0162 12.7193 47.7132 12.807C45.4961 13.4547 43.0922 14.2551 41.3367 15.7457C39.1422 17.6039 38.1002 20.5652 37.3527 23.2607C37.3018 23.4558 37.2791 23.7585 37.2055 23.9225C37.1913 23.9508 36.9846 24.2025 36.9648 24.2167C36.693 24.3977 36.3985 24.2167 36.2909 23.9423C36.2315 23.7981 36.1578 23.5379 36.1154 23.3795C35.0819 19.6828 33.9719 16.5348 30.4297 14.5691C28.728 13.6244 26.9526 13.251 25.1093 12.6684C24.7497 12.5524 24.3986 12.2724 24.6761 11.8962C24.9026 11.5851 25.5284 11.5653 25.8653 11.4635C28.4477 10.6857 31.098 9.79193 32.9667 7.73286C34.5439 5.99624 35.3735 3.56948 36.0191 1.3492C36.1154 1.0098 36.2315 0.0962293 36.6364 0.00854938H36.6307L36.6279 0.0113778Z" fill="#E6007E"/>
        </svg>
      `
    );

    editor.ui.registry.addMenuButton("ia", {
      text: "",
      tooltip: "Outils IA",
      icon: "iacustom", // 👈 maintenant ça marche
      fetch: (callback) => {
        callback([
          {
            type: "menuitem",
            text: tinymce.i18n.translate("text_expand_label"),
            icon: "iaexpand",
            onAction: () => editor.execCommand("textExpandRun"),
          },
          {
            type: "menuitem",
            text: tinymce.i18n.translate("text_improve_label"),
            icon: "iaimprove",
            onAction: () => editor.execCommand("textImproveRun"),
          },
          {
            type: "menuitem",
            text: tinymce.i18n.translate("text_shorter_label"),
            icon: "iashorter",
            onAction: () => editor.execCommand("textShorterRun"),
          },
        ]);
      },
    });
  });
})();
