import os

# Used to limit description field on all content types
DESCRIPTION_MAX_LENGTH = 700

# Used to translated terms from brains metadatas
# Must be extended by other products
VOCABULARIES_MAPPING = {
    "iam": "imio.smartweb.vocabulary.IAm",
    "topics": "imio.smartweb.vocabulary.Topics",
}

# Used for vocabularies that allow explicitly choosen lang translations
TRANSLATED_VOCABULARIES = [
    "imio.smartweb.vocabulary.Countries",
]

IPA_URL = os.environ.get("IPA_URL", "https://ipa-staging.imio.be/imio/ai/v1/agents")

APPLICATION_ID = os.environ.get("application_id", "iA.Smartweb")

PROJECT_ID = os.environ.get("PROJECT_ID", "smartweb")
