# sage_setup: distribution = sagemath-objects

from sage.all__sagemath_objects import *
