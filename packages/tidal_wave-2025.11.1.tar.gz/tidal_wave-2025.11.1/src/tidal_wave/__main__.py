"""tidal_wave is a module that retrieves data from TIDAL API and writes it to disk."""

from .main import app

app()
