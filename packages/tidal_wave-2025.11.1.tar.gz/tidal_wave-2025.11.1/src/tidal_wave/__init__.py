"""A package to wave at the Tidal music service."""
