def test_title(document_tags) -> None:
    pass
