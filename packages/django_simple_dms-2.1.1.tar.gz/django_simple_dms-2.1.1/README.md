Django Simple DMS
=================

[![Pypi](https://badge.fury.io/py/django-simple-dms.svg)](https://badge.fury.io/py/django-simple-dms)
[![coverage](https://codecov.io/github/k-tech-italy/django-simple-dms/coverage.svg?branch=develop)](https://codecov.io/github/k-tech-italy/django-simple-dms?branch=develop)
[![Test](https://github.com/k-tech-italy/django-simple-dms/actions/workflows/tests.yaml/badge.svg)](https://github.com/k-tech-italy/django-simple-dms/actions/workflows/tests.yaml)
[![Docs](https://img.shields.io/badge/stable-blue)](https://k-tech-italy.github.io/django-simple-dms/)
[![Django](https://img.shields.io/pypi/frameworkversions/django/django-simple-dms)](https://pypi.org/project/django-simple-dms/)
[![Supported Python versions](https://img.shields.io/pypi/pyversions/django-simple-dms.svg)](https://pypi.org/project/django-simple-dms/)

Django Simple DMS is a library providing a simple document management system.

How to use
----------


Third-party libraries
---------------------
