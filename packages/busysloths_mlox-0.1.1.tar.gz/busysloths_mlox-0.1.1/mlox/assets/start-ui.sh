#!/bin/bash

pwd 

streamlit run ./app.py
