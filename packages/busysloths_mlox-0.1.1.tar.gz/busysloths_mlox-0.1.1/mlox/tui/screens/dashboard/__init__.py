"""Dashboard screen package exposing the main screen component."""

from .screen import DashboardScreen

__all__ = ["DashboardScreen"]
