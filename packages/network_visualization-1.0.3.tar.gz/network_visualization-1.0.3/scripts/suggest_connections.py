"""
Suggest Connections for Isolated Nodes

This script generates connection suggestions to integrate isolated nodes
into the main network, prioritizing by distance and demand.

Usage:
    python suggest_connections.py --model-path PATH_TO_MODEL [--output FILE]
"""

import os
import sys
import argparse
import csv

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from utils.load_data import load_all_locations, load_all_connections
from utils.graph_builder import build_network_graph, analyze_connectivity
from utils.geo_utils import suggest_connections_for_isolated


def main():
    parser = argparse.ArgumentParser(description='Suggest connections for isolated nodes')
    parser.add_argument('--model-path', type=str, required=True,
                       help='Path to Calliope model directory')
    parser.add_argument('--output', type=str, default='connection_suggestions.csv',
                       help='Output CSV filename')
    parser.add_argument('--max-per-node', type=int, default=3,
                       help='Maximum suggestions per isolated node')
    
    args = parser.parse_args()
    
    print("=" * 80)
    print("CONNECTION SUGGESTIONS FOR ISOLATED NODES")
    print("=" * 80)
    
    # Load data
    print("\n1. Loading data...")
    locations = load_all_locations(args.model_path)
    connections = load_all_connections(args.model_path)
    
    # Analyze
    print("2. Analyzing connectivity...")
    graph = build_network_graph(locations, connections)
    analysis = analyze_connectivity(graph, locations)
    
    # Get all isolated nodes (not just demand)
    all_isolated = []
    for component in analysis['components'][1:]:  # Skip main component
        all_isolated.extend(list(component))
    
    print(f"   Found {len(all_isolated)} isolated nodes")
    print(f"   Including {len(analysis['demand_isolated'])} with demand (PRIORITY)")
    
    # Generate suggestions
    print(f"\n3. Generating suggestions (max {args.max_per_node} per node)...")
    
    # Prioritize demand substations
    priority_nodes = list(analysis['demand_isolated'])
    other_nodes = [n for n in all_isolated if n not in priority_nodes]
    
    all_suggestions = []
    
    # Process priority nodes first
    if priority_nodes:
        suggestions = suggest_connections_for_isolated(
            priority_nodes,
            locations,
            analysis['main_component'],
            max_suggestions=args.max_per_node
        )
        
        for isolated_node, nearest_list in suggestions.items():
            for target, distance in nearest_list:
                all_suggestions.append({
                    'from': isolated_node,
                    'to': target,
                    'distance_km': round(distance, 2),
                    'priority': 'HIGH',
                    'reason': 'Isolated demand substation'
                })
    
    # Process other isolated nodes
    if other_nodes:
        suggestions = suggest_connections_for_isolated(
            other_nodes,
            locations,
            analysis['main_component'],
            max_suggestions=args.max_per_node
        )
        
        for isolated_node, nearest_list in suggestions.items():
            for target, distance in nearest_list:
                loc_type = locations[isolated_node]['type']
                all_suggestions.append({
                    'from': isolated_node,
                    'to': target,
                    'distance_km': round(distance, 2),
                    'priority': 'LOW',
                    'reason': f'Isolated {loc_type}'
                })
    
    # Save to CSV
    output_dir = os.path.join(os.path.dirname(__file__), '..', 'outputs', 'reports')
    os.makedirs(output_dir, exist_ok=True)
    output_path = os.path.join(output_dir, args.output)
    
    with open(output_path, 'w', newline='', encoding='utf-8') as f:
        writer = csv.DictWriter(f, fieldnames=['from', 'to', 'distance_km', 'priority', 'reason'])
        writer.writeheader()
        writer.writerows(all_suggestions)
    
    print(f"   ✓ Saved {len(all_suggestions)} suggestions to: {output_path}")
    
    # Display summary
    print("\n4. Summary:")
    print("-" * 80)
    
    high_priority = [s for s in all_suggestions if s['priority'] == 'HIGH']
    low_priority = [s for s in all_suggestions if s['priority'] == 'LOW']
    
    print(f"   High Priority (Demand): {len(high_priority)} suggestions")
    print(f"   Low Priority (Other): {len(low_priority)} suggestions")
    print(f"   Total: {len(all_suggestions)} suggestions")
    
    # Show top priority suggestions
    if high_priority:
        print("\n5. Top Priority Connections:")
        print("-" * 80)
        for suggestion in high_priority[:10]:
            print(f"   {suggestion['from']}")
            print(f"     → {suggestion['to']} ({suggestion['distance_km']} km)")
    
    print("\n" + "=" * 80)
    print(f"COMPLETE - See {output_path} for full list")
    print("=" * 80)


if __name__ == '__main__':
    main()
