"""
Geographic utilities for calculating distances and finding nearest nodes.
"""

import math
from typing import Dict, List, Tuple


def calculate_distance(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    """
    Calculate distance between two coordinates using Haversine formula.
    
    Args:
        lat1, lon1: First coordinate
        lat2, lon2: Second coordinate
        
    Returns:
        Distance in kilometers
    """
    R = 6371  # Earth radius in km
    
    # Convert to radians
    lat1, lon1, lat2, lon2 = map(math.radians, [lat1, lon1, lat2, lon2])
    
    # Haversine formula
    dlat = lat2 - lat1
    dlon = lon2 - lon1
    a = math.sin(dlat/2)**2 + math.cos(lat1) * math.cos(lat2) * math.sin(dlon/2)**2
    c = 2 * math.asin(math.sqrt(a))
    
    return R * c


def find_nearest_nodes(target_node: str, locations: Dict, 
                      candidates: List[str] = None, 
                      max_results: int = 5) -> List[Tuple[str, float]]:
    """
    Find nearest nodes to a target node based on geographic distance.
    
    Args:
        target_node: Name of the target node
        locations: Dictionary of all locations
        candidates: List of candidate node names (None = all nodes)
        max_results: Maximum number of results to return
        
    Returns:
        List of tuples (node_name, distance_km) sorted by distance
    """
    if target_node not in locations:
        return []
    
    target_loc = locations[target_node]
    target_lat = target_loc['lat']
    target_lon = target_loc['lon']
    
    # Use all locations except target if candidates not specified
    if candidates is None:
        candidates = [name for name in locations.keys() if name != target_node]
    
    # Calculate distances
    distances = []
    for candidate in candidates:
        if candidate != target_node and candidate in locations:
            cand_loc = locations[candidate]
            dist = calculate_distance(
                target_lat, target_lon,
                cand_loc['lat'], cand_loc['lon']
            )
            distances.append((candidate, dist))
    
    # Sort by distance and return top results
    distances.sort(key=lambda x: x[1])
    return distances[:max_results]


def find_nearest_by_type(target_node: str, locations: Dict, 
                        target_type: str, max_results: int = 5) -> List[Tuple[str, float]]:
    """
    Find nearest nodes of a specific type.
    
    Args:
        target_node: Name of the target node
        locations: Dictionary of all locations
        target_type: Type of nodes to search for ('power', 'substation', 'nodo')
        max_results: Maximum number of results to return
        
    Returns:
        List of tuples (node_name, distance_km) sorted by distance
    """
    candidates = [
        name for name, data in locations.items()
        if data['type'] == target_type or data['type'].startswith(target_type)
    ]
    
    return find_nearest_nodes(target_node, locations, candidates, max_results)


def suggest_connections_for_isolated(isolated_nodes: List[str], 
                                    locations: Dict,
                                    connected_nodes: set,
                                    max_suggestions: int = 3) -> Dict[str, List[Tuple[str, float]]]:
    """
    Suggest connections for isolated nodes to connect them to the main network.
    
    Args:
        isolated_nodes: List of isolated node names
        locations: Dictionary of all locations
        connected_nodes: Set of nodes in the main connected component
        max_suggestions: Number of suggestions per isolated node
        
    Returns:
        Dictionary mapping isolated nodes to suggested connections
    """
    suggestions = {}
    
    for isolated_node in isolated_nodes:
        # Find nearest connected nodes
        candidates = list(connected_nodes)
        nearest = find_nearest_nodes(isolated_node, locations, candidates, max_suggestions)
        suggestions[isolated_node] = nearest
    
    return suggestions


def calculate_total_distance(connections: List[Dict], locations: Dict) -> float:
    """
    Calculate total distance of all connections in the network.
    
    Args:
        connections: List of connections
        locations: Dictionary of locations
        
    Returns:
        Total distance in kilometers
    """
    total_distance = 0.0
    
    for conn in connections:
        if conn['from'] in locations and conn['to'] in locations:
            from_loc = locations[conn['from']]
            to_loc = locations[conn['to']]
            dist = calculate_distance(
                from_loc['lat'], from_loc['lon'],
                to_loc['lat'], to_loc['lon']
            )
            total_distance += dist
    
    return total_distance


def get_geographic_center(nodes: List[str], locations: Dict) -> Tuple[float, float]:
    """
    Calculate geographic center (mean lat/lon) of a set of nodes.
    
    Args:
        nodes: List of node names
        locations: Dictionary of locations
        
    Returns:
        Tuple of (latitude, longitude)
    """
    if not nodes:
        return (0.0, 0.0)
    
    valid_nodes = [n for n in nodes if n in locations]
    if not valid_nodes:
        return (0.0, 0.0)
    
    lat_sum = sum(locations[n]['lat'] for n in valid_nodes)
    lon_sum = sum(locations[n]['lon'] for n in valid_nodes)
    
    return (lat_sum / len(valid_nodes), lon_sum / len(valid_nodes))
