"""
Questra Automation - Python Client for Automation GraphQL API.

Provides a type-safe interface to the Questra Automation service.

Example:
    from questra_authentication import QuestraAuthentication
    from questra_automation import QuestraAutomation, ExecutionInitiator

    # Create QuestraAuthentication
    auth_client = QuestraAuthentication(
        url="https://authentik.dev.example.com",
        username="ServiceUser",
        password="secret_password",
        oidc_discovery_paths=["/application/o/automation"],
    )

    # Initialize QuestraAutomation
    client = QuestraAutomation(
        graphql_url="https://automation.dev.example.com/graphql",
        auth_client=auth_client,
    )

    # Query workspaces
    workspaces = client.queries.get_workspaces(first=10)
    for workspace in workspaces.nodes:
        print(f"Workspace: {workspace.name}")

    # Execute an automation
    result = client.mutations.execute_automation(
        workspace_name="my-workspace",
        automation_path="scripts/my_automation.py",
        initiator_type=ExecutionInitiator.MANUAL,
    )
"""

import os
import sys

from loguru import logger

logger.remove()

LOG_LEVEL = os.getenv("QUESTRA_AUTOMATION_LOG_LEVEL", "WARNING")
LOG_FORMAT = os.getenv(
    "QUESTRA_AUTOMATION_LOG_FORMAT",
    "<green>{time:YYYY-MM-DD HH:mm:ss.SSS}</green> | "
    "<level>{level: <8}</level> | "
    "<cyan>{name}</cyan>:<cyan>{function}</cyan>:<cyan>{line}</cyan> | "
    "<level>{message}</level> | "
    "{extra}{exception}",
)

logger.add(
    sys.stdout,
    format=LOG_FORMAT,
    level=LOG_LEVEL,
    colorize=True,
    backtrace=True,
    diagnose=True,
)

LOG_FILE = os.getenv("QUESTRA_AUTOMATION_LOG_FILE")
if LOG_FILE:
    logger.add(
        LOG_FILE,
        format=LOG_FORMAT,
        level="DEBUG",
        rotation="10 MB",
        retention="7 days",
        compression="zip",
        enqueue=True,
    )

logger.debug("Questra Automation logger initialized")

from .client import QuestraAutomation
from .exceptions import QuestraAutomationError, QuestraAutomationGraphQLError
from .models import (
    ApplyPolicy,
    AutomationArgumentDefinition,
    AutomationArgumentInstance,
    AutomationBuildError,
    AutomationBuildStatus,
    AutomationExecutionDomainStatus,
    AutomationExecutionStatus,
    AutomationExecutionView,
    AutomationInitiatorType,
    AutomationsConnection,
    AutomationsEdge,
    AutomationView,
    CreateRepositoryPayload,
    CreateSchedulePayload,
    CreateWorkspacePayload,
    DeleteRepositoryPayload,
    DeleteSchedulePayload,
    DeleteWorkspacePayload,
    ErrorCodesConnection,
    ErrorCodesEdge,
    ErrorCodeView,
    ExecutePayload,
    ExecutionInitiator,
    ExecutionsConnection,
    ExecutionsEdge,
    KeyValuePair,
    PageInfo,
    RenewRepositorySshKeyPayload,
    RepositoriesConnection,
    RepositoriesEdge,
    RepositoryAuthenticationMethod,
    RepositoryView,
    ScheduledExecutionsConnection,
    ScheduledExecutionsEdge,
    ScheduledExecutionView,
    SchedulesConnection,
    SchedulesEdge,
    ScheduleView,
    ServiceInfo,
    SortEnumType,
    SynchronizeWorkspacePayload,
    UpdateRepositoryPayload,
    UpdateSchedulePayload,
    UpdateWorkspacePayload,
    WorkspacesConnection,
    WorkspacesEdge,
    WorkspaceView,
)

__version__ = "0.1.0"

__all__ = [
    # Main client
    "QuestraAutomation",
    # Exceptions
    "QuestraAutomationError",
    "QuestraAutomationGraphQLError",
    # Enums
    "ApplyPolicy",
    "AutomationBuildStatus",
    "AutomationExecutionDomainStatus",
    "AutomationExecutionStatus",
    "AutomationInitiatorType",
    "ExecutionInitiator",
    "RepositoryAuthenticationMethod",
    "SortEnumType",
    # Types
    "AutomationArgumentDefinition",
    "AutomationArgumentInstance",
    "AutomationBuildError",
    "KeyValuePair",
    "PageInfo",
    "ServiceInfo",
    "WorkspaceView",
    "AutomationView",
    "AutomationExecutionView",
    "RepositoryView",
    "ScheduleView",
    "ScheduledExecutionView",
    "ErrorCodeView",
    # Connection Types
    "AutomationsConnection",
    "AutomationsEdge",
    "ExecutionsConnection",
    "ExecutionsEdge",
    "RepositoriesConnection",
    "RepositoriesEdge",
    "SchedulesConnection",
    "SchedulesEdge",
    "ScheduledExecutionsConnection",
    "ScheduledExecutionsEdge",
    "ErrorCodesConnection",
    "ErrorCodesEdge",
    "WorkspacesConnection",
    "WorkspacesEdge",
    # Payload Types
    "ExecutePayload",
    "CreateRepositoryPayload",
    "UpdateRepositoryPayload",
    "DeleteRepositoryPayload",
    "RenewRepositorySshKeyPayload",
    "CreateSchedulePayload",
    "UpdateSchedulePayload",
    "DeleteSchedulePayload",
    "CreateWorkspacePayload",
    "UpdateWorkspacePayload",
    "DeleteWorkspacePayload",
    "SynchronizeWorkspacePayload",
]
