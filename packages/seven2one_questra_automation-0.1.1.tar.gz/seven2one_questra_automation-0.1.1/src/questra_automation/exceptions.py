"""Exceptions for Questra Automation."""

from __future__ import annotations


class QuestraAutomationError(Exception):
    """Base exception for Questra Automation errors."""

    def __init__(self, message: str):
        """
        Initialize the exception.

        Args:
            message: Error message
        """
        self.message = message
        super().__init__(self.message)


class QuestraAutomationGraphQLError(QuestraAutomationError):
    """Exception for GraphQL errors from the Automation service."""

    def __init__(
        self,
        message: str,
        code: str | None = None,
        category: str | None = None,
        placeholders: dict | None = None,
        locations: list | None = None,
        path: list | None = None,
        extensions: dict | None = None,
    ):
        """
        Initialize the GraphQL error.

        Args:
            message: Error message
            code: Error code (e.g., "VALIDATION_WORKSPACE_NOT_FOUND")
            category: Error category (e.g., "Validation")
            placeholders: Placeholder values for the error message
            locations: GraphQL locations where the error occurred
            path: GraphQL path where the error occurred
            extensions: Additional error extensions
        """
        super().__init__(message)
        self.code = code
        self.category = category
        self.placeholders = placeholders or {}
        self.locations = locations or []
        self.path = path or []
        self.extensions = extensions or {}

    def __str__(self) -> str:
        """Return string representation of the error."""
        parts = [f"GraphQL Error: {self.message}"]

        if self.code:
            parts.append(f"Code: {self.code}")

        if self.category:
            parts.append(f"Category: {self.category}")

        if self.placeholders:
            parts.append(f"Placeholders: {self.placeholders}")

        if self.path:
            parts.append(f"Path: {' -> '.join(map(str, self.path))}")

        return " | ".join(parts)

    def __repr__(self) -> str:
        """Return detailed representation of the error."""
        return (
            f"QuestraAutomationGraphQLError(message={self.message!r}, "
            f"code={self.code!r}, category={self.category!r}, "
            f"placeholders={self.placeholders!r}, path={self.path!r})"
        )
