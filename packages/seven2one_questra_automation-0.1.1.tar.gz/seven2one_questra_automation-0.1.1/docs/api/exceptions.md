# Exceptions

::: questra_automation.exceptions.QuestraAutomationError
    options:
      show_source: false
      heading_level: 2

::: questra_automation.exceptions.QuestraAutomationGraphQLError
    options:
      show_source: false
      heading_level: 2
