"c", not ʒ because that is rare in English"
"tc" is often pronounced t͡s
