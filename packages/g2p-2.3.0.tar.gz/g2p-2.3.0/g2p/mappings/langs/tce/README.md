IPA mappings for Southern Tutchone with resources from the Yukon Native Language Centre
