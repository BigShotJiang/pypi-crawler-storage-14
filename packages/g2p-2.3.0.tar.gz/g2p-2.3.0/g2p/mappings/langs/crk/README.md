Language-specific files for Plains Cree (nêhiyawêwin)
