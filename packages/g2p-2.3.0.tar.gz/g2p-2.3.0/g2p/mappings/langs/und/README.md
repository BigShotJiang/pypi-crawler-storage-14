Fallback resources for an unknown language or for cases where other G2P solutions
have failed.  ("und" is a special ISO 639-3 code for an undetermined language.)
