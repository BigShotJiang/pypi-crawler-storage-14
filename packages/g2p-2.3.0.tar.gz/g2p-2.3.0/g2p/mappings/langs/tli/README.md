IPA mappings for Tlingit
with resources from the Yukon Native Language Centre
