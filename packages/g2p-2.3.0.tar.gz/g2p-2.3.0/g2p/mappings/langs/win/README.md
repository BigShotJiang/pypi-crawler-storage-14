Language-specific files for Hoocąk (Winnebago / Ho-Chunk)

Alphabet table taken from (and slightly modified): https://en.wikipedia.org/wiki/Winnebago_language#The_sounds_of_Ho-Chunk_with_example_words[6]
