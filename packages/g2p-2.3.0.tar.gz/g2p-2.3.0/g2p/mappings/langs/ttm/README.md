IPA mapping for Northern Tutchone with files from the Yukon Native Language Centre
