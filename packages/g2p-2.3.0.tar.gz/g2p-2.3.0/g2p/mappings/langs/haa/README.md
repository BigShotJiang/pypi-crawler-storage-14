IPA mappings for Hän with resources from the Yukon Native Language Centre
