"""Top-level package for pycorec."""

__author__ = """Yuto Tanaka"""
__email__ = 'tanaka.yuto.u10@gmail.com'
__version__ = '2.0.8'
