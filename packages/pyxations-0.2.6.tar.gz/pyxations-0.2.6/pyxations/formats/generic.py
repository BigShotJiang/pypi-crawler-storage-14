'''
Created on 2 dic 2024

@author: placiana
'''
from pyxations.export import get_exporter
import pandas as pd


class BidsParse(object):
    def __init__(self, session_folder_path, export_method)->None:
        self.session_folder_path = session_folder_path
        self.export_method = get_exporter(export_method)
        object.__init__(self)


    def save_dataframe(self, df, path, data_name, key):
        self.export_method.save(df, path, data_name, key)


    def store_dataframes(self, dfSamples, dfCalib=pd.DataFrame(), dfFix=pd.DataFrame(), dfSacc=pd.DataFrame(), 
                         dfHeader=pd.DataFrame(),dfBlink=pd.DataFrame(), dfMsg=pd.DataFrame()):
                # Save DataFrames to disk in one go to minimize memory usage during processing
        detection_algorithm = self.detection_algorithm

        def _ensure_trial_number(df: pd.DataFrame) -> pd.DataFrame:
            if df is None or df.empty:
                return df
            # Si ya existe trial_number no tocamos nada
            if "trial_number" in df.columns:
                return df
            # Si no existe trial_number pero sí trial_index, lo copiamos
            if "trial_index" in df.columns:
                df = df.copy()
                df["trial_number"] = df["trial_index"]
            return df

        dfSamples = _ensure_trial_number(dfSamples)
        dfFix     = _ensure_trial_number(dfFix)
        dfSacc    = _ensure_trial_number(dfSacc)
        dfBlink   = _ensure_trial_number(dfBlink)

        self.save_dataframe(dfSamples, self.session_folder_path, 'samples', key='samples')
        
        if not dfCalib.empty:
            self.save_dataframe(dfCalib, self.session_folder_path, 'calib', key='calib')
        if not dfHeader.empty:
            self.save_dataframe(dfHeader, self.session_folder_path, 'header', key='header')
        if not dfMsg.empty:
            self.save_dataframe(dfMsg, self.session_folder_path, 'msg', key='msg')

        
        (self.session_folder_path / f'{detection_algorithm}_events').mkdir(parents=True, exist_ok=True)
        #if not dfFix.empty:
        self.save_dataframe(dfFix, (self.session_folder_path / f'{detection_algorithm}_events'), 'fix', key='fix')
        #if not dfSacc.empty:
        self.save_dataframe(dfSacc, (self.session_folder_path / f'{detection_algorithm}_events'), 'sacc', key='sacc')
        #if not dfBlink.empty:
        self.save_dataframe(dfBlink, (self.session_folder_path / f'{detection_algorithm}_events'), 'blink', key='blink')        

