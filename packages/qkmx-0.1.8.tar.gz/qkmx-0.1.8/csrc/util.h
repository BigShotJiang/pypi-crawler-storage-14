#ifndef UTIL_H
#define UTIL_H

float randn_float();

#endif 