# CO Split-Up Generator

`co-splitup` is a Python package to generate **CO-wise question split-ups** and a fully formatted **Excel “CO Evaluation Sheet”** from a simple CSV of student marks.

It also includes a **Streamlit web app** so faculty can use it without touching code.

---

## ✨ Features

- 📄 **Simple input**: Paste or upload a CSV with:
  - 9 header rows (course info)
  - Student list (S.NO, REG. NO, NAME, MARKS)
- 🧮 **Automatic split-up** of total marks into:
  - Question-wise marks
  - CO-wise marks
  - Total column verified per student
- 🎯 **Supports regulations**: 2013, 2017, 2021 patterns
- 📚 **Assessment types**:
  - IA1, IA2, MOD, LAB, PRO (fixed patterns)
  - CUS (Custom) with user-defined questions & CO mapping
- 🧠 **Smart random logic**:
  - Band-based logic (weak / average / good / excellent) for regular assessments
  - Strict 0..max-per-question logic for custom assessments
- 📊 **Excel output**:
  - Question columns + CO columns + TOTAL
  - “Verified & Approved By” row
  - Borders, bold headers, background colors, frozen panes
  - Title + tagline: “KGISL INSTITUTE OF TECHNOLOGY” / “co-Kreate your Genius”

---

## 🚀 Installation

After it is uploaded to PyPI:

```bash
pip install co-splitup
