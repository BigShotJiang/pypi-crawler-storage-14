from . import test_auth_signup_partner_company
