from src.cvsx2mvsx.etl.pipelines.stories import StoriesPipeline


def main():
    cvsx_path = "data/cvsx/zipped/lattice/idr-13457537-all-data.cvsx"

    # MVSXPipeline(
    #     cvsx_path=cvsx_path,
    #     output_path="temp/test.mvsx",
    # ).run()

    StoriesPipeline(
        cvsx_path=cvsx_path,
        output_path="temp/test.mvstory",
    ).run()


if __name__ == "__main__":
    main()
