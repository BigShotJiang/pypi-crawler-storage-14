import os
import sys

from src.cvsx2mvsx.etl.pipelines.mvsx import MVSXPipeline


def main():
    if len(sys.argv) != 3:
        print("Usage: cvsx2mvsx <input.cvsx> <output.mvsx>")
        sys.exit(1)

    cvsx_path = sys.argv[1]
    mvsx_path = sys.argv[2]

    if not os.path.isfile(cvsx_path):
        print(f"❌ ERROR: File not found: {cvsx_path}")
        sys.exit(1)

    print(f"Converting {cvsx_path} -> {mvsx_path}...")
    pipeline = MVSXPipeline(cvsx_path, mvsx_path)
    pipeline.run()
    print("✅ Done!")


if __name__ == "__main__":
    main()
