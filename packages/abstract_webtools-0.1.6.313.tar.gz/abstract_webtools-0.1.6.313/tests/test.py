from imports import *
DOMAIN = 'https://abstractendeavors.com/curveIt'


parsed = urlManager(DOMAIN)

input(parsed.url)

