"""
Test script for the export_Netgen() function in cubit_mesh_export.py

Run this script:
  python test_ngsolve_export_function.py
"""

import sys
sys.path.append("C:/Program Files/Coreform Cubit 2025.3/bin")

print("=" * 60)
print("Testing export_Netgen() function")
print("=" * 60)

# Step 1: Import and initialize Cubit
print("\nStep 1: Importing Cubit...")
import cubit
cubit.init(['cubit', '-nojournal', '-batch'])
print("  [OK] Cubit initialized")

# Step 2: Create geometry and mesh
print("\nStep 2: Creating sphere geometry and mesh...")
cubit.cmd("reset")
cubit.cmd("create sphere radius 1")
cubit.cmd("volume 1 scheme tetmesh")
cubit.cmd("volume 1 size 0.3")
cubit.cmd("mesh volume 1")

# Add elements to blocks
cubit.cmd("block 1 add tet all in volume 1")
cubit.cmd("block 1 name 'sphere_volume'")
cubit.cmd("block 2 add tri all in surface all")
cubit.cmd("block 2 name 'sphere_surface'")

num_tets = len(cubit.get_block_tets(1))
num_tris = len(cubit.get_block_tris(2))
print(f"  Created: {num_tets} tets, {num_tris} boundary tris")

# Step 3: Export geometry to STEP
print("\nStep 3: Exporting geometry to STEP...")
step_file = "s:/CoreformCubit/01_GitHub/test_sphere.step"
cubit.cmd(f'export step "{step_file}" overwrite')
print(f"  [OK] Exported to {step_file}")

# Step 4: Use export_Netgen function
print("\nStep 4: Using export_Netgen() function...")
import cubit_mesh_export

ngmesh = cubit_mesh_export.export_Netgen(cubit, geometry_file=step_file)
print(f"  [OK] Created netgen.Mesh: ne={ngmesh.ne}")

# Step 5: Convert to ngsolve.Mesh
print("\nStep 5: Converting to ngsolve.Mesh...")
import ngsolve
ngs_mesh = ngsolve.Mesh(ngmesh)
print(f"  [OK] Converted: nv={ngs_mesh.nv}, ne={ngs_mesh.ne}")

# Step 6: Test Curve() with different orders
print("\nStep 6: Testing mesh.Curve() with different orders...")
for order in [2, 3, 4, 5]:
	try:
		ngs_mesh.Curve(order)
		print(f"  [OK] mesh.Curve({order}) succeeded!")
	except Exception as e:
		print(f"  [FAIL] mesh.Curve({order}) error: {e}")

# Step 7: Check materials and boundaries
print("\nStep 7: Checking materials and boundaries...")
print(f"  Materials: {ngs_mesh.GetMaterials()}")
print(f"  Boundaries: {ngs_mesh.GetBoundaries()}")

print("\n" + "=" * 60)
print("Test complete!")
print("=" * 60)
