# Premium Calculator Library

This is a simple package to calculate insurance premium. This library puporse is to use on master's project, its puporse is to demostrate that I learned how to deploy a library and use on my CA project. 

## Features

- Calculate premiums
- Calculate risk factors based on collection type

## Instalation

pip install premium-calculator-bv

## Usage

Here is an example of how to use the **PremiumCalculator** class:

```python
from premium_calculator_pkg.premium_calculator import PremiumCalculator

# Initialize the calculator with a base rate (example, 0.01 for 1%)
calculator = PremiumCalculator(base_rate=0.01)

# Calculate risk factor from percentage (example, 8 for 8%)
risk_factor_percentage = 8
risk_factor = calculator.calculate_risk_factor(risk_factor_percentage)
if risk_factor is not None:
    collection_value = 1000
    premium = calculator.calculate_premium(collection_value, risk_factor)
    print(f"The calculated premium for a collection worth ${collection_value} with {risk_factor_percentage}% risk factor is: ${premium}")
else:
    print(f"Could not calculate premium due to invalid risk factor percentage.")

```

