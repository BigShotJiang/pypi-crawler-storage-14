import unittest
from decimal import Decimal
from premium_calculator_pkg.premium_calculator import PremiumCalculator


class TestPremiumCalculator(unittest.TestCase):

    def setUp(self):
        
        self.calculator = PremiumCalculator(base_rate=0.01)

    def test_init(self):
       
        calc = PremiumCalculator(base_rate=0.02)
        self.assertEqual(calc.base_rate, Decimal('0.02'))
        
        # Test with string input
        calc2 = PremiumCalculator(base_rate='0.03')
        self.assertEqual(calc2.base_rate, Decimal('0.03'))
        
        # Test with float input
        calc3 = PremiumCalculator(base_rate=0.025)
        self.assertEqual(calc3.base_rate, Decimal('0.025'))

    def test_set_base_rate(self):
      
        self.calculator.set_base_rate(0.02)
        self.assertEqual(self.calculator.base_rate, Decimal('0.02'))
        
        # Test with string input
        self.calculator.set_base_rate('0.03')
        self.assertEqual(self.calculator.base_rate, Decimal('0.03'))
        
        # Test with float input
        self.calculator.set_base_rate(0.025)
        self.assertEqual(self.calculator.base_rate, Decimal('0.025'))

    def test_calculate_risk_factor(self):
       
        # Test with valid percentage values
        self.assertEqual(self.calculator.calculate_risk_factor(8), Decimal('0.08'))
        self.assertEqual(self.calculator.calculate_risk_factor(4), Decimal('0.04'))
        self.assertEqual(self.calculator.calculate_risk_factor(9), Decimal('0.09'))
        self.assertEqual(self.calculator.calculate_risk_factor(3), Decimal('0.03'))
        self.assertEqual(self.calculator.calculate_risk_factor(2), Decimal('0.02'))
        
        # Test with string percentage values
        self.assertEqual(self.calculator.calculate_risk_factor('8'), Decimal('0.08'))
        self.assertEqual(self.calculator.calculate_risk_factor('4.5'), Decimal('0.045'))
        
        # Test with Decimal percentage values
        self.assertEqual(self.calculator.calculate_risk_factor(Decimal('10')), Decimal('0.10'))
        
        # Test with zero
        self.assertEqual(self.calculator.calculate_risk_factor(0), Decimal('0'))
        
        # Test with invalid input types
        with self.assertRaises(Exception):  
            self.calculator.calculate_risk_factor(None)
        with self.assertRaises(Exception):  
            self.calculator.calculate_risk_factor([])
        with self.assertRaises(Exception):  
            self.calculator.calculate_risk_factor({})
        with self.assertRaises(Exception): 
            self.calculator.calculate_risk_factor('abc')

    def test_calculate_premium(self):
    
        # Test with valid inputs
        self.assertEqual(self.calculator.calculate_premium(1000, 0.08), 10.80)
        
        # Test with different base_rate
        calc2 = PremiumCalculator(base_rate=0.02)
        self.assertEqual(calc2.calculate_premium(2000, 0.04), 41.60)
        
        # Test with string inputs
        self.assertEqual(self.calculator.calculate_premium('1000', '0.08'), 10.80)
        
        # Test with Decimal risk_factor
        self.assertEqual(self.calculator.calculate_premium(500.50, Decimal('0.09')), 5.46)
        
        # Test with zero collection value
        self.assertEqual(self.calculator.calculate_premium(0, 0.08), 0.0)
        
        # Test with negative collection value
        self.assertEqual(self.calculator.calculate_premium(-1000, 0.08), 0.0)
        
        # Test with negative risk factor
        self.assertEqual(self.calculator.calculate_premium(1000, -0.08), 0.0)
        
        # Test with None risk factor
        self.assertEqual(self.calculator.calculate_premium(1000, None), 0.0)
        
        # Test with invalid input types
        self.assertEqual(self.calculator.calculate_premium('abc', 0.08), 0.0)
        self.assertEqual(self.calculator.calculate_premium(1000, 'xyz'), 0.0)
        self.assertEqual(self.calculator.calculate_premium(None, 0.08), 0.0)
        
        # Test with zero risk factor
        self.assertEqual(self.calculator.calculate_premium(1000, 0), 10.0)
        
        # Test with high risk factor
        self.assertEqual(self.calculator.calculate_premium(1000, 0.5), 15.0)

    def test_calculate_premium_with_different_base_rates(self):
        
        # Test with base_rate = 0.02
        calc = PremiumCalculator(base_rate=0.02)
        self.assertEqual(calc.calculate_premium(1000, 0.08), 21.60)
        
        # Test with base_rate = 0.005
        calc2 = PremiumCalculator(base_rate=0.005)
        self.assertEqual(calc2.calculate_premium(1000, 0.08), 5.40)
        
        # Test changing base_rate
        calc3 = PremiumCalculator(base_rate=0.01)
        self.assertEqual(calc3.calculate_premium(1000, 0.08), 10.80)
        calc3.set_base_rate(0.02)
        self.assertEqual(calc3.calculate_premium(1000, 0.08), 21.60)

    def test_edge_cases(self):
        
        # Test with very small values
        self.assertEqual(self.calculator.calculate_premium(0.01, 0.08), 0.00)
        
        # Test with very large values
        self.assertEqual(self.calculator.calculate_premium(1000000, 0.08), 10800.00)
        
        # Test with decimal collection value
        self.assertEqual(self.calculator.calculate_premium(1234.56, 0.08), 13.33)
       


if __name__ == '__main__':
    unittest.main()
