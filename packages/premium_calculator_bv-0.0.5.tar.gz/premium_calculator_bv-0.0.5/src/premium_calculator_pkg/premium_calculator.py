from decimal import Decimal


# Class to calculate insurance premium
class PremiumCalculator:

    def __init__(self, base_rate):
        """Initialize PremiumCalculator with a base rate."""
        self.base_rate = Decimal(str(base_rate))

    def set_base_rate(self, base_rate):
        self.base_rate = Decimal(str(base_rate))

    def calculate_risk_factor(self, risk_factor_percentage):
        """Return the risk factor as a Decimal fraction."""
        try:
            factor = Decimal(str(risk_factor_percentage)) / Decimal('100')
            return factor
        except (TypeError, ValueError):
            return None

    def calculate_premium(self, collection_value, risk_factor):
        """Calculate insurance premium from collection value and risk factor.

        Args:
            collection_value (float|str): The total value of the card collection.
            risk_factor (float|Decimal|str): Fractional risk factor (example: 0.08 for 8%).

        Returns:
            float: The calculated insurance premium rounded to 2 decimal places,
                   or 0.0 for invalid input.
        """
        try:
            value = float(collection_value)
            factor = float(risk_factor)

            if value <= 0 or factor < 0 or risk_factor is None:
                return 0.0

            premium = value * float(self.base_rate) * (1 + factor)
            return round(premium, 2)

        except (TypeError, ValueError):
            return 0.0
