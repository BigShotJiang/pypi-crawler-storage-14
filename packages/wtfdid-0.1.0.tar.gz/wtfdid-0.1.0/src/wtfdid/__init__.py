"""A tool to summarize your bash history using LLMs."""

__version__ = "0.1.0"
