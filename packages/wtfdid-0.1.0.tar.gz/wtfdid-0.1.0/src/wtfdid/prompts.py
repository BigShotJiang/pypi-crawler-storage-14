EXAMPLE_MARKDOWN_PROMPT = """
Here is a **concise summary of your work today** based on the terminal history you provided, with key activities categorized and clarified:

---

### 📌 **Summary of Work – [Current Date]**
*Prepared: [Current Time]*

---

### 🧬 **1. Bioinformatics & Data Processing**
- **Sequence Alignment & Variant Calling**:
  - Indexed reference genome:
    ```bash
    samtools faidx reference.fasta
    ```
  - Called variants using `bcftools`:
    ```bash
    bcftools mpileup -f reference.fasta alignment.bam | bcftools call -mv -Ob -o variants.bcf
    ```
- **Pipeline Execution**:
  - Ran a Nextflow pipeline for RNA-seq analysis:
    ```bash
    nextflow run nf-core/rnaseq -profile docker --input samplesheet.csv --outdir results/
    ```

---

### � **2. Data Analysis & Visualization**
- **Jupyter Environment**:
  - Launched Jupyter Lab for exploratory analysis:
    ```bash
    jupyter lab --no-browser --port=8888
    ```
- **Data Manipulation**:
  - Converted large CSV datasets to Parquet for performance:
    ```bash
    python -c "import pandas as pd; pd.read_csv('data.csv').to_parquet('data.parquet')"
    ```
  - Inspected data headers:
    ```bash
    head -n 5 data.csv | csvlook
    ```

---

### � **3. Version Control & Code Management**
- **Feature Development**:
  - Created and switched to a new branch `feature/user-auth`:
    ```bash
    git checkout -b feature/user-auth
    ```
  - Staged and committed changes:
    ```bash
    git add src/auth/login.py
    git commit -m "feat: implement basic login logic"
    ```
- **Repository Maintenance**:
  - Synced with upstream changes:
    ```bash
    git fetch origin && git rebase origin/main
    ```

---

### ⚙️ **4. Tool Installation & Setup (`wtfdid`)**
- **Installation**:
  - Installed `wtfdid` in editable mode using `uv`:
    ```bash
    uv pip install -e .
    ```
  - Verified installation and help command:
    ```bash
    wtfdid --help
    ```
- **Configuration**:
  - Set up the Gemini API key for the LLM backend:
    ```bash
    export GEMINI_API_KEY="your-api-key"
    ```

---

### � **5. Containerization & System Admin**
- **Docker Operations**:
  - Built the application image:
    ```bash
    docker build -t my-app:latest .
    ```
  - Started the development stack:
    ```bash
    docker-compose up -d
    ```
- **System Monitoring**:
  - Checked available disk space and process usage:
    ```bash
    df -h
    htop
    ```

---

### ✅ **Key Outcomes**
- Successfully processed RNA-seq data using the Nextflow pipeline.
- Converted raw CSV data to Parquet for faster analysis.
- Implemented basic login logic in the `feature/user-auth` branch.
- Verified `wtfdid` installation and configuration.

---

### 📝 **Next Steps (Suggested)**
1.  Analyze the RNA-seq results in Jupyter Lab.
2.  Push the `feature/user-auth` branch and open a Pull Request.
3.  Investigate disk usage warnings on the Docker volume partition.

---

> ✅ **Status:** *Productive session covering bioinformatics pipelines, data engineering, and tool development.*
"""

CATEGORIZED_PROMPT_TEMPLATE = """
You are an AI assistant specialized in summarizing developer's bash/zsh history.
Your goal is to provide a concise, categorized, and insightful summary of the user's work based on their terminal commands.

Here's the bash/zsh history for the last day:
---HISTORY_START---
{history_text}
---HISTORY_END---

Please provide a summary in Markdown format, following these guidelines:

1.  **Overall Title**: Start with "Summary of Work – [Current Date]" (e.g., "Summary of Work – 22 October 2025").
2.  **Prepared Time**: Include "Prepared: [Current Time]" (e.g., "Prepared: 20:41:41 WEST").
3.  **Categorization**: Group related commands and activities into logical categories. Use clear, descriptive headings (e.g., "Document Processing & Transcript Consolidation", "Python Script Execution & Debugging", "Development Environment Setup & Tooling", "Network & DNS Troubleshooting", "File Management & Organization", "LLM Interaction & Reflection").
4.  **Key Actions & Commands**: For each category, list the most important actions and commands. Include actual commands in code blocks where relevant.
5.  **Key Outcomes**: Provide a brief section summarizing the main achievements or results of the day.
6.  **Next Steps (Suggested)**: Suggest logical next steps based on the completed work.
7.  **Overall Status/Takeaway**: Conclude with a concise statement about the overall productivity or key takeaway from the day.

Ensure the summary is:
-   **Concise**: Avoid unnecessary verbosity.
-   **Categorized**: Group similar activities.
-   **Action-oriented**: Focus on what was done.
-   **Insightful**: Highlight important achievements or challenges.
-   **Markdown formatted**: Use headings, bullet points, and code blocks.

Example of desired output format:
{example_markdown_prompt}
"""

CHRONOLOGICAL_PROMPT_TEMPLATE = """
You are a system analyst reviewing a user’s terminal command history. Analyze the provided log of shell commands and output them in chronological order. Based on the commands executed, generate a concise, professional summary of the user's activities during their session.

Here's the bash/zsh history for the last day:
---HISTORY_START---
{history_text}
---HISTORY_END---

**Instructions:**

1. Parse the raw terminal log to identify timestamps, commands, and relevant outputs.
2. Extract key actions such as configuration checks, file inspections, or directory explorations.
3. Group related actions into logical steps and assign them to the correct time.
4. Write a clear, natural-language summary that includes:
   - A title with the date and time zone (e.g., "Summary of Work – Friday, 24 October 2025 (09:54:12 WEST)")
   - Bullet points for each significant action, including timestamp, command, and purpose
   - A brief overall summary explaining the likely intent behind the session (e.g., troubleshooting, environment setup, verification)
5. Keep tone professional and helpful — assume the user may want to use this for documentation or audit purposes.
6. If any commands are unclear or ambiguous, make a reasonable inference based on common system administration practices.

**Example Output Format:**

---

**Summary of Work – Friday, 24 October 2025 (09:54:12 WEST)**

- **09:43**: Reviewed the contents of `/etc/resolv.conf`, likely to verify or troubleshoot DNS configuration settings.
- **09:52**: Executed `ls` to list files and directories in the current working directory, possibly to assess environment state after previous checks.

---

**Overall Summary**:
The user’s session involved basic system diagnostics—checking DNS resolution configuration and inspecting directory contents. These actions suggest routine environment verification or troubleshooting related to network connectivity.
"""
