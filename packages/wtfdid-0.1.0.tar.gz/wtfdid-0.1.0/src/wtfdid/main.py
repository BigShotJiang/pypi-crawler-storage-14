import click
import datetime
import os
import llm
from wtfdid.prompts import CATEGORIZED_PROMPT_TEMPLATE, CHRONOLOGICAL_PROMPT_TEMPLATE, EXAMPLE_MARKDOWN_PROMPT

@click.group()
def cli():
    """A tool to summarize your bash history using LLMs."""

@cli.command()
@click.option("--days", default=1, help="Number of days to summarize.")
@click.option("--journal", is_flag=True, help="Write summary to a journal file.")
@click.option("--journal-file", type=click.Path(), default=os.path.expanduser("~/.wtfdid_journal.md"),
              help="Path to the journal file.")
@click.option("--model", default="qwen3", help="LLM model to use for summarization.")
@click.option("--history-file", type=click.Path(exists=True), help="Path to the history file to use.")
@click.option("--style", type=click.Choice(['categorized', 'chronological']), default='categorized', help="Style of the summary.")
def summarize(days, journal, journal_file, model, history_file, style):
    """Summarizes your bash history for the last n days."""
    history_type = None

    if history_file:
        # Infer type from filename if possible, default to bash if unknown but file provided
        if "zsh_history" in history_file:
            history_type = "zsh"
        else:
            history_type = "bash"
    else:
        zsh_history_file = os.path.expanduser("~/.zsh_history")
        bash_history_file = os.path.expanduser("~/.bash_history")

        if os.path.exists(zsh_history_file):
            history_file = zsh_history_file
            history_type = "zsh"
        elif os.path.exists(bash_history_file):
            history_file = bash_history_file
            history_type = "bash"
        else:
            click.echo("No bash or zsh history file found.")
            return

    try:
        with open(history_file, "r", encoding='utf-8', errors='ignore') as f:
            history = f.readlines()
    except PermissionError:
        click.echo(f"Error: Permission denied reading history file: {history_file}")
        return
    except Exception as e:
        click.echo(f"Error reading history file: {e}")
        return

    filtered_history = filter_history_by_days(history, days, history_type)
    
    if not filtered_history:
        click.echo(f"No history found for the last {days} day(s).")
        return

    try:
        summary = summarize_history(filtered_history, model_name=model, style=style)
    except llm.UnknownModelError:
        click.echo(f"Error: Unknown model '{model}'. Please check your installed models with 'llm models'.")
        return
    except Exception as e:
        click.echo(f"Error generating summary: {e}")
        return

    current_time_str = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')

    if journal:
        try:
            with open(journal_file, "a") as f:
                f.write(f"# wtfdid Summary - {current_time_str}\n")
                f.write(f"## History from last {days} day(s) ({history_type})\n")
                f.write(f"{summary}\n\n")
            click.echo(f"Summary written to {journal_file}")
        except PermissionError:
             click.echo(f"Error: Permission denied writing to journal file: {journal_file}")
        except Exception as e:
             click.echo(f"Error writing to journal file: {e}")
    else:
        output_message = f"Summary for the last {days} day(s) from {history_type} history:\n{summary}"
        click.echo(output_message)

def _parse_bash_history_entry(line, current_command_timestamp):
    """Parses a single bash history line."""
    if line.startswith("#") and line[1:].isdigit():
        return datetime.datetime.fromtimestamp(int(line[1:])), None
    elif current_command_timestamp:
        return current_command_timestamp, line
    return None, None

def _parse_zsh_history_entry(line):
    """Parses a single zsh history line."""
    if line.startswith(": ") and ";" in line:
        try:
            parts = line.split(";", 1)
            timestamp_str = parts[0].split(" ")[1].split(":")[0]
            timestamp = int(timestamp_str)
            command = parts[1].strip()
            return datetime.datetime.fromtimestamp(timestamp), command
        except (ValueError, IndexError):
            pass # Parsing failed, treat as untimed/unparseable
    return None, None # Not a timestamped Zsh command or parsing failed

def filter_history_by_days(history, days, history_type):
    """Filters the history by the number of days."""
    filtered_lines = []
    now = datetime.datetime.now()
    cutoff_date = (now - datetime.timedelta(days=days)).replace(hour=0, minute=0, second=0, microsecond=0)

    current_command_timestamp = None
    for line in history:
        line = line.strip()
        timestamp = None
        command = None

        if history_type == "bash":
            parsed_timestamp, parsed_command = _parse_bash_history_entry(line, current_command_timestamp)
            if parsed_timestamp and parsed_command: # If a command is associated with a timestamp
                if parsed_timestamp >= cutoff_date:
                    filtered_lines.append(parsed_command)
                current_command_timestamp = None # Reset for the next command
            elif parsed_timestamp: # If it's just a timestamp line
                current_command_timestamp = parsed_timestamp
        elif history_type == "zsh":
            parsed_timestamp, parsed_command = _parse_zsh_history_entry(line)
            if parsed_timestamp and parsed_command:
                if parsed_timestamp >= cutoff_date:
                    filtered_lines.append(parsed_command)
    return filtered_lines

def summarize_history(history, model_name, style='categorized'):
    """Summarizes the history using the llm library."""
    model = llm.get_model(model_name) # Using qwen3 as specified in previous output
    history_text = '\n'.join(history)

    if style == 'chronological':
        prompt_template = CHRONOLOGICAL_PROMPT_TEMPLATE
    else:
        prompt_template = CATEGORIZED_PROMPT_TEMPLATE

    prompt = prompt_template.format(
        history_text=history_text,
        example_markdown_prompt=EXAMPLE_MARKDOWN_PROMPT
    )
    response = model.prompt(prompt)
    return response.text()
if __name__ == "__main__":
    cli()
