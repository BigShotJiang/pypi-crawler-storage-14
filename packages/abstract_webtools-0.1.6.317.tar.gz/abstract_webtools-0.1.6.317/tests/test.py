from imports import *
DOMAIN = 'abstractendeavors.com'


url_mgr = urlManager(DOMAIN)

input(url_mgr.parsed)

