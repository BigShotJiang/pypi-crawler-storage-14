# sslManager.py
# ssl_manager.py
from urllib3.util import ssl_ as urllib3_ssl
import ssl, certifi
from ....cipherManager import CipherManager  # <-- adjust if needed
