"""Central answer store for the codeprinter package."""

from __future__ import annotations

from collections.abc import Callable
from typing import Any, Union

Answer = Union[str, int, float, dict[str, Any], list[Any], Callable[[], Any]]

ANSWERS: dict[int, Answer] = {
    1: ('''
import pandas as pd
df=pd.read_csv('lab1.csv')
df.head()

df.describe()
df.info()

missing_occupation=df['Occupation'].isnull().sum()
missing_satisfaction=df["Satisfaction_Level"].isnull().sum()
print(missing_occupation)
print(missing_satisfaction)

df['Occupation'].fillna(df['Occupation'].mode()[0],inplace=True)
df['Satisfaction_Level'].fillna(df['Satisfaction_Level'].mean(),inplace=True)
df

df["Satisfaction_Binary"]=df["Satisfaction_Level"].apply(lambda x: "High" if x>0.7 else "Low")
df


mapping_values={'Low':0,'Medium':1,'High':2}
df['Purchase_History']=df['Purchase_History'].map(mapping_values)
df

q1=df['Income'].quantile(0.25)
q3=df['Income'].quantile(0.75)
iqr=q3-q1
lower_bound=q1-1.5*iqr
upper_bound=q3+1.5*iqr
outliers= df[(df['Income']<lower_bound)| (df['Income']>upper_bound)]
print("outliers in INCOME column:")
print(f'{outliers}',end='')

df['Years_Employed'].fillna(df['Years_Employed'].median(),inplace=True)
'''),
    2: (
        "def add(a, b):\n"
        "    return a + b\n"
        "\n"
        "print(add(2, 3))"
    ),
}

