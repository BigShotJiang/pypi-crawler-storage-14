from torch.utils.data import DataLoader, DistributedSampler, IterableDataset


def create_loader(dataset, batch_size, rank, world_size, num_workers: int = 2, drop_last: bool = False, shuffle: bool = True):
    # IterableDataset doesn't support DistributedSampler
    if isinstance(dataset, IterableDataset):
        loader_kwargs = dict(
            batch_size=batch_size,
            num_workers=num_workers,
            pin_memory=True,
            drop_last=drop_last,
        )
        if num_workers > 0:
            loader_kwargs["prefetch_factor"] = 2
            loader_kwargs["persistent_workers"] = True

        return DataLoader(dataset, **loader_kwargs)

    # Regular Dataset - use DistributedSampler
    sampler = DistributedSampler(dataset, num_replicas=world_size, rank=rank, drop_last=drop_last, shuffle=shuffle)

    loader_kwargs = dict(
        batch_size=batch_size,
        sampler=sampler,
        num_workers=num_workers,
        pin_memory=True,
        persistent_workers=(num_workers > 0),
        drop_last=drop_last,
    )

    if num_workers > 0:
        loader_kwargs["prefetch_factor"] = 2

    return DataLoader(dataset, **loader_kwargs)
