#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import sys
import subprocess
import platform
import time

import re
from pathlib import Path
from shutil import which

try:
    from packaging import version

    HAS_PACKAGING = True
except ImportError:
    HAS_PACKAGING = False

try:
    import distro

    HAS_DISTRO = True
except ImportError:
    HAS_DISTRO = False

# Git commit from https://github.com/docker/docker-install when
# the script was uploaded (Should only be modified by upload job):
SCRIPT_COMMIT_SHA = "7d96bd3c5235ab2121bcb855dd7b3f3f37128ed4"

# 全局变量
VERSION = os.environ.get("VERSION", "").lstrip("v")
CHANNEL = os.environ.get("CHANNEL", "stable")
DOWNLOAD_URL = os.environ.get("DOWNLOAD_URL", "https://download.docker.com")
REPO_FILE = os.environ.get("REPO_FILE") or (
    "docker-ce-staging.repo" if "stage" in DOWNLOAD_URL else "docker-ce.repo"
)
DRY_RUN = os.environ.get("DRY_RUN", "")
REPO_ONLY = os.environ.get("REPO_ONLY", "0")

mirror = ""
sh_c = ""
lsb_dist = ""
dist_version = ""


def command_exists(command):
    """检查命令是否存在"""
    return which(command) is not None


def version_gte(v):
    """检查指定版本是否大于等于当前版本"""
    if not VERSION:
        return True
    if HAS_PACKAGING:
        try:
            return version.parse(VERSION) >= version.parse(v)
        except:
            pass
    return version_compare(VERSION, v) == 0


def version_compare(v1, v2):
    """比较两个版本字符串 - 返回 0 (成功) 如果 v1 >= v2, 否则返回 1 (失败)"""
    try:
        parts1 = [int(x.lstrip("0") or 0) for x in v1.split(".")[:2]]
        parts2 = [int(x.lstrip("0") or 0) for x in v2.split(".")[:2]]

        if parts1[0] < parts2[0]:
            return 1
        if parts1[0] > parts2[0]:
            return 0
        if len(parts1) > 1 and len(parts2) > 1 and parts1[1] < parts2[1]:
            return 1
        return 0
    except (IndexError, ValueError):
        return 1


def is_dry_run():
    """检查是否为试运行模式"""
    return bool(DRY_RUN)


def is_wsl():
    """检查是否为 WSL 环境"""
    return "microsoft" in platform.uname().release.lower()


def is_darwin():
    """检查是否为 macOS"""
    return platform.system() == "Darwin"


def deprecation_notice(distro, distro_version):
    """打印弃用警告"""
    print()
    print("\033[91;1m弃用警告\033[0m")
    print(
        f"    此 Linux 发行版 (\033[1m{distro} {distro_version}\033[0m) 已达到生命周期终点,不再受此脚本支持。"
    )
    print("    将不会为此发行版发布更新或安全修复,建议用户")
    print(f"    升级到 {distro} 的当前维护版本。")
    print()
    print("现在按 \033[1mCtrl+C\033[0m 中止此脚本,或等待安装继续。")
    print()
    time.sleep(10)


def get_distribution():
    """获取发行版信息"""
    if HAS_DISTRO:
        return distro.id()

    # 备用方法
    os_release = Path("/etc/os-release")
    if os_release.exists():
        for line in os_release.read_text().splitlines():
            if line.startswith("ID="):
                return line.split("=")[1].strip('"')
    return ""


def echo_docker_as_nonroot():
    """提示如何以非 root 用户运行 Docker"""
    if is_dry_run():
        return

    if command_exists("docker") and Path("/var/run/docker.sock").exists():
        subprocess.run(f"{sh_c} 'docker version'", shell=True, check=False)

    print()
    print("=" * 80)
    print()
    if version_gte("20.10"):
        print("要以非特权用户身份运行 Docker,请考虑设置")
        print("Docker 守护进程为您的用户使用无根模式:")
        print()
        print("    dockerd-rootless-setuptool.sh install")
        print()
        print("访问 https://docs.docker.com/go/rootless/ 了解有关无根模式的信息。")
        print()

    print()
    print("要将 Docker 守护进程作为完全特权服务运行,但授予非 root")
    print("用户访问权限,请参阅 https://docs.docker.com/go/daemon-access/")
    print()
    print("警告:访问特权 Docker 守护进程上的远程 API 等同于")
    print('         主机上的 root 访问权限。请参阅"Docker 守护进程攻击面"')
    print("         文档以获取详细信息:https://docs.docker.com/go/attack-surface/")
    print()
    print("=" * 80)
    print()


def check_forked():
    """检查是否为衍生 Linux 发行版"""
    global lsb_dist, dist_version

    if not command_exists("lsb_release"):
        # 检查 Debian 衍生版本
        debian_version = Path("/etc/debian_version")
        if debian_version.exists() and lsb_dist not in ["ubuntu", "raspbian"]:
            lsb_dist = "raspbian" if lsb_dist == "osmc" else "debian"
            content = debian_version.read_text().strip()
            dist_version = re.sub(r"[/\.].*", "", content)

            version_map = {
                "13": "trixie",
                "12": "bookworm",
                "11": "bullseye",
                "10": "buster",
                "9": "stretch",
                "8": "jessie",
            }
            dist_version = version_map.get(dist_version, dist_version)
        return

    # 检查是否支持 `-u` 选项
    result = subprocess.run("lsb_release -a -u > /dev/null 2>&1", shell=True)
    if result.returncode == 0:
        print(f"您正在使用 '{lsb_dist}' 版本 '{dist_version}'。")

        try:
            upstream_info = (
                subprocess.check_output("lsb_release -a -u 2>&1", shell=True)
                .decode()
                .lower()
            )
            for line in upstream_info.split("\n"):
                if "id:" in line:
                    lsb_dist = line.split(":")[1].strip()
                elif "codename:" in line:
                    dist_version = line.split(":")[1].strip()
        except:
            pass

        print(f"上游版本是 '{lsb_dist}' 版本 '{dist_version}'。")


def read_config_file(filepath, key_prefix):
    """从配置文件读取键值对"""
    config_path = Path(filepath)
    if not config_path.exists():
        return None

    for line in config_path.read_text().splitlines():
        if line.startswith(key_prefix):
            return line.split("=", 1)[1].strip('"')
    return None


def get_dist_version(lsb_dist):
    """获取发行版版本号"""
    version_map = {
        "13": "trixie",
        "12": "bookworm",
        "11": "bullseye",
        "10": "buster",
        "9": "stretch",
        "8": "jessie",
    }

    if HAS_DISTRO:
        return distro.codename() or distro.version()

    # Ubuntu
    if lsb_dist == "ubuntu":
        if command_exists("lsb_release"):
            return subprocess.getoutput("lsb_release --codename | cut -f2")
        return read_config_file("/etc/lsb-release", "DISTRIB_CODENAME=")

    # Debian/Raspbian
    if lsb_dist in ["debian", "raspbian"]:
        debian_ver = Path("/etc/debian_version")
        if debian_ver.exists():
            content = debian_ver.read_text().strip()
            ver = re.sub(r"[/\.].*", "", content)
            return version_map.get(ver, ver)

    # CentOS/RHEL 或其他
    if command_exists("lsb_release"):
        return subprocess.getoutput("lsb_release --release | cut -f2")

    return read_config_file("/etc/os-release", "VERSION_ID=")


def run_shell(cmd, quiet=True):
    """执行 shell 命令的辅助函数"""
    if not is_dry_run() and not quiet:
        print(f"+ {cmd}")
    subprocess.run(f"{sh_c} '{cmd}'", shell=True)


def do_install(
    channel="stable",
    dry_run=False,
    mirror="",
    version="",
    setup_repo=False,
):
    """
    执行安装
    """
    global \
        sh_c, \
        lsb_dist, \
        dist_version, \
        DOWNLOAD_URL, \
        REPO_FILE, \
        CHANNEL, \
        VERSION, \
        REPO_ONLY, \
        DRY_RUN

    # Update globals based on arguments
    CHANNEL = channel
    if dry_run:
        DRY_RUN = "1"
    if version:
        VERSION = version.lstrip("v")
    if setup_repo:
        REPO_ONLY = "1"

    # 镜像逻辑
    if mirror == "Aliyun":
        DOWNLOAD_URL = "https://mirrors.aliyun.com/docker-ce"
    elif mirror == "AzureChinaCloud":
        DOWNLOAD_URL = "https://mirror.azure.cn/docker-ce"
    elif mirror:
        print(
            f"未知镜像 '{mirror}'：请使用 'Aliyun' 或 'AzureChinaCloud'。",
            file=sys.stderr,
        )
        sys.exit(1)

    if CHANNEL not in ["stable", "test"]:
        print(f"未知通道 '{CHANNEL}'：请使用 stable 或 test。", file=sys.stderr)
        sys.exit(1)

    print(f"# 正在执行 docker 安装脚本，提交：{SCRIPT_COMMIT_SHA}")

    if command_exists("docker"):
        print(
            '警告："docker" 命令似乎已存在于此系统上。',
            file=sys.stderr,
        )
        print("", file=sys.stderr)
        print(
            "如果您已经安装了 Docker，此脚本可能会导致问题，这就是",
            file=sys.stderr,
        )
        print(
            "我们显示此警告并提供取消机会的原因",
            file=sys.stderr,
        )
        print("安装。", file=sys.stderr)
        print("", file=sys.stderr)
        print(
            "如果您使用此脚本安装了当前的 Docker 包，并且正在使用它",
            file=sys.stderr,
        )
        print(
            "再次更新 Docker，您可以忽略此消息，但请注意",
            file=sys.stderr,
        )
        print(
            "脚本会将 deb 和 rpm 仓库配置中的任何自定义更改重置",
            file=sys.stderr,
        )
        print("为与传递给脚本的参数相匹配的文件。", file=sys.stderr)
        print("", file=sys.stderr)
        print("您现在可以按 Ctrl+C 中止此脚本。", file=sys.stderr)

        time.sleep(20)

    user = subprocess.getoutput("id -un 2>/dev/null || true")

    sh_c = "sh -c"
    if user != "root":
        if command_exists("sudo"):
            sh_c = "sudo -E sh -c"
        elif command_exists("su"):
            sh_c = "su -c"
        else:
            print(
                "错误：此安装程序需要能够以 root 身份运行命令。",
                file=sys.stderr,
            )
            print(
                '我们无法找到可用的 "sudo" 或 "su" 来实现这一点。',
                file=sys.stderr,
            )
            sys.exit(1)

    if is_dry_run():
        sh_c = "echo"

    # 执行一些非常基本的平台检测
    lsb_dist = get_distribution().lower()

    if is_wsl():
        print()
        print("检测到 WSL：我们建议使用 Docker Desktop for Windows。")
        print(
            "请从 https://www.docker.com/products/docker-desktop/ 获取 Docker Desktop"
        )
        print()
        print("您现在可以按 Ctrl+C 中止此脚本。", file=sys.stderr)
        time.sleep(20)

    dist_version = get_dist_version(lsb_dist)

    # 检查是否为衍生 Linux 发行版
    check_forked()

    # 打印最近达到 EOL 的发行版版本的弃用警告
    deprecated_distros = {
        "centos.8",
        "centos.7",
        "rhel.7",
        "debian.buster",
        "debian.stretch",
        "debian.jessie",
        "raspbian.buster",
        "raspbian.stretch",
        "raspbian.jessie",
        "ubuntu.focal",
        "ubuntu.bionic",
        "ubuntu.xenial",
        "ubuntu.trusty",
        "ubuntu.oracular",
        "ubuntu.mantic",
        "ubuntu.lunar",
        "ubuntu.kinetic",
        "ubuntu.impish",
        "ubuntu.hirsute",
        "ubuntu.groovy",
        "ubuntu.eoan",
        "ubuntu.disco",
        "ubuntu.cosmic",
    }

    distro_key = f"{lsb_dist}.{dist_version}"
    if distro_key in deprecated_distros:
        deprecation_notice(lsb_dist, dist_version)
    elif lsb_dist == "fedora" and dist_version.isdigit() and int(dist_version) < 41:
        deprecation_notice(lsb_dist, dist_version)

    # 相应地为每个发行版运行设置
    if lsb_dist in ["ubuntu", "debian", "raspbian"]:
        pre_reqs = "ca-certificates curl"
        # apt_repo="deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.asc] $DOWNLOAD_URL/linux/$lsb_dist $dist_version $CHANNEL"
        arch = subprocess.getoutput("dpkg --print-architecture")
        apt_repo = f"deb [arch={arch} signed-by=/etc/apt/keyrings/docker.asc] {DOWNLOAD_URL}/linux/{lsb_dist} {dist_version} {CHANNEL}"

        run_shell("apt-get -qq update >/dev/null", quiet=False)
        run_shell(
            f"DEBIAN_FRONTEND=noninteractive apt-get -y -qq install {pre_reqs} >/dev/null",
            quiet=False,
        )
        run_shell("install -m 0755 -d /etc/apt/keyrings", quiet=False)
        run_shell(
            f'curl -fsSL "{DOWNLOAD_URL}/linux/{lsb_dist}/gpg" -o /etc/apt/keyrings/docker.asc',
            quiet=False,
        )
        run_shell("chmod a+r /etc/apt/keyrings/docker.asc", quiet=False)
        run_shell(
            f'echo "{apt_repo}" > /etc/apt/sources.list.d/docker.list', quiet=False
        )
        run_shell("apt-get -qq update >/dev/null", quiet=False)

        if REPO_ONLY == "1":
            sys.exit(0)

        pkg_version = ""
        cli_pkg_version = ""
        if VERSION:
            if is_dry_run():
                print("# 警告：DRY_RUN 中不支持版本固定")
            else:
                # 将适用于不完整的版本 IE (17.12)，但如果在测试通道中，可能实际上无法获取“最新”
                # pkg_pattern="$(echo "$VERSION" | sed 's/-ce-/~ce~.*/g' | sed 's/-/.*/g')"
                pkg_pattern = VERSION.replace("-ce-", "~ce~.*").replace("-", ".*")

                search_command = f"apt-cache madison docker-ce | grep '{pkg_pattern}' | head -1 | awk '{{$1=$1}};1' | cut -d' ' -f 3"
                pkg_version = subprocess.getoutput(f'{sh_c} "{search_command}"')
                print(f"信息：正在仓库中搜索版本 '{VERSION}'")
                print(f"信息：{search_command}")

                if not pkg_version:
                    print()
                    print(f"错误：在 apt-cache madison 结果中未找到 '{VERSION}'")
                    print()
                    sys.exit(1)

                cli_pkg_version = ""
                if version_gte("18.09"):
                    search_command = f"apt-cache madison docker-ce-cli | grep '{pkg_pattern}' | head -1 | awk '{{$1=$1}};1' | cut -d' ' -f 3"
                    print(f"信息：{search_command}")
                    cli_pkg_version = "=" + subprocess.getoutput(
                        f'{sh_c} "{search_command}"'
                    )

                pkg_version = "=" + pkg_version

        # 构建包列表
        pkgs = [f"docker-ce{pkg_version}"]

        if version_gte("18.09"):
            cli_ver = cli_pkg_version.lstrip("=") if cli_pkg_version else ""
            pkgs.extend([f"docker-ce-cli{cli_ver}", "containerd.io"])

        if version_gte("20.10"):
            pkgs.extend(
                ["docker-compose-plugin", f"docker-ce-rootless-extras{pkg_version}"]
            )

        if version_gte("23.0"):
            pkgs.append("docker-buildx-plugin")

        if version_gte("28.2"):
            pkgs.append("docker-model-plugin")

        pkgs_str = " ".join(pkgs)
        run_shell(
            f"DEBIAN_FRONTEND=noninteractive apt-get -y -qq install {pkgs_str} >/dev/null",
            quiet=False,
        )

        echo_docker_as_nonroot()
        sys.exit(0)

    elif lsb_dist in ["centos", "fedora", "rhel"]:
        if platform.machine() == "s390x":
            print("自 v27.5 起生效，请查阅 RHEL 发行版声明以获取 s390x 支持。")
            sys.exit(1)

        repo_file_url = f"{DOWNLOAD_URL}/linux/{lsb_dist}/{REPO_FILE}"

        # Determine package manager
        if command_exists("dnf5"):
            pkg_manager = "dnf5"
            config_manager = "dnf5 config-manager"
            enable_repo = f"addrepo --overwrite --save-filename=docker-ce.repo --from-repofile='{repo_file_url}'"
            disable_plugin = 'setopt "docker-ce-*.enabled=0"'
            enable_plugin = f'setopt "docker-ce-{CHANNEL}.enabled=1"'
            install_utils = (
                "dnf -y -q --setopt=install_weak_deps=False install dnf-plugins-core"
            )
            make_cache = "dnf makecache"
            pkg_manager_flags = "-y -q --best"
        elif command_exists("dnf"):
            pkg_manager = "dnf"
            config_manager = "dnf config-manager"
            enable_repo = f"--add-repo {repo_file_url}"
            disable_plugin = '--set-disabled "docker-ce-*"'
            enable_plugin = f'--set-enabled "docker-ce-{CHANNEL}"'
            install_utils = (
                "dnf -y -q --setopt=install_weak_deps=False install dnf-plugins-core"
            )
            make_cache = "dnf makecache"
            pkg_manager_flags = "-y -q --best"
        else:
            pkg_manager = "yum"
            config_manager = "yum-config-manager"
            enable_repo = f"--add-repo {repo_file_url}"
            disable_plugin = '--disable "docker-ce-*"'
            enable_plugin = f'--enable "docker-ce-{CHANNEL}"'
            install_utils = "yum -y -q install yum-utils"
            make_cache = "yum makecache"
            pkg_manager_flags = "-y -q"

        # Install utils and setup repo
        run_shell(install_utils, quiet=False)
        if pkg_manager != "dnf5":
            run_shell(
                "rm -f /etc/yum.repos.d/docker-ce.repo /etc/yum.repos.d/docker-ce-staging.repo",
                quiet=False,
            )

        run_shell(f"{config_manager} {enable_repo}", quiet=False)

        if CHANNEL != "stable":
            run_shell(f"{config_manager} {disable_plugin}", quiet=False)
            run_shell(f"{config_manager} {enable_plugin}", quiet=False)

        run_shell(make_cache, quiet=False)

        if REPO_ONLY == "1":
            sys.exit(0)

        pkg_version = ""
        cli_pkg_version = ""
        if VERSION:
            if is_dry_run():
                print("# 警告：DRY_RUN 中不支持版本固定")
            else:
                pkg_suffix = f"fc{dist_version}" if lsb_dist == "fedora" else "el"
                pkg_pattern = (
                    VERSION.replace("-ce-", r"\\.ce.*").replace("-", ".*")
                    + ".*"
                    + pkg_suffix
                )

                search_cmd = f"{pkg_manager} list --showduplicates docker-ce | grep '{pkg_pattern}' | tail -1 | awk '{{print $2}}'"
                pkg_version = subprocess.getoutput(f'{sh_c} "{search_cmd}"')
                print(f"信息：正在仓库中搜索版本 '{VERSION}'")
                print(f"信息：{search_cmd}")

                if not pkg_version:
                    print(f"\n错误：在 {pkg_manager} 列表结果中未找到 '{VERSION}'\n")
                    sys.exit(1)

                cli_pkg_version = ""
                if version_gte("18.09"):
                    search_cmd = f"{pkg_manager} list --showduplicates docker-ce-cli | grep '{pkg_pattern}' | tail -1 | awk '{{print $2}}'"
                    cli_pkg_version = subprocess.getoutput(
                        f"{sh_c} \"{search_cmd}\" | cut -d':' -f 2"
                    )

                pkg_version = (
                    pkg_version.split(":", 1)[-1] if ":" in pkg_version else pkg_version
                )
                pkg_version = f"-{pkg_version}"

        # Build package list
        pkgs = [f"docker-ce{pkg_version}"]
        if version_gte("18.09"):
            if cli_pkg_version:
                pkgs.append(f"docker-ce-cli-{cli_pkg_version}")
            else:
                pkgs.append("docker-ce-cli")
            pkgs.append("containerd.io")

        if version_gte("20.10"):
            pkgs.extend(
                ["docker-compose-plugin", f"docker-ce-rootless-extras{pkg_version}"]
            )

        if version_gte("23.0"):
            pkgs.extend(["docker-buildx-plugin", "docker-model-plugin"])

        pkgs_str = " ".join(pkgs)
        run_shell(f"{pkg_manager} {pkg_manager_flags} install {pkgs_str}", quiet=False)

        echo_docker_as_nonroot()
        sys.exit(0)

    elif lsb_dist == "sles":
        print("自 v27.5 起生效，请查阅 SLES 发行版声明以获取 s390x 支持。")
        sys.exit(1)
    else:
        if not lsb_dist:
            if is_darwin():
                print()
                print("错误：不支持的操作系统 'macOS'")
                print(
                    "请从 https://www.docker.com/products/docker-desktop 获取 Docker Desktop"
                )
                print()
                sys.exit(1)

        print()
        print(f"错误：不支持的发行版 '{lsb_dist}'")
        print()
        sys.exit(1)

    sys.exit(1)
