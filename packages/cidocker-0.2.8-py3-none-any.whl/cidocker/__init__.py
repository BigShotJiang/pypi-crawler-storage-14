import fire
from .docker.install_docker import do_install
from prompt_toolkit import prompt
from prompt_toolkit.completion import FuzzyCompleter, WordCompleter


class ENTRY(object):
    def install_docker(
        self, channel="stable", dry_run=False, mirror="", version="", setup_repo=False
    ):
        """
        Install Docker.
        """
        if not mirror:
            mirrors = ["Aliyun", "AzureChinaCloud", "Official"]
            mirror_completer = FuzzyCompleter(WordCompleter(mirrors))
            mirror = prompt(
                "请选择镜像源 (默认: Official): ",
                completer=mirror_completer,
                complete_while_typing=True,
            )
            if mirror == "Official":
                mirror = ""

        if not version:
            versions = [
                "Latest",
                "27.3.1",
                "26.1.4",
                "25.0.5",
                "24.0.9",
                "23.0.6",
                "20.10.24",
            ]
            version_completer = FuzzyCompleter(WordCompleter(versions))
            version = prompt(
                "请选择 Docker 版本 (默认: Latest): ",
                completer=version_completer,
                complete_while_typing=True,
            )
            if version == "Latest":
                version = ""

        do_install(
            channel=channel,
            dry_run=dry_run,
            mirror=mirror,
            version=version,
            setup_repo=setup_repo,
        )


def main() -> None:
    try:
        fire.Fire(ENTRY)
    except KeyboardInterrupt:
        print("\n操作已取消")
        exit(0)


if __name__ == "__main__":
    main()
