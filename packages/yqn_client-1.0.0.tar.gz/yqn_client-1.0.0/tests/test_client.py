"""
Test cases for YQN Client.
"""

import pytest
from unittest.mock import Mock, patch
from yqn_client import YQNClient, Config
from yqn_client.exceptions import APIError, AuthenticationError


class TestYQNClient:
    """Test cases for YQN Client."""
    
    def test_client_initialization(self):
        """Test client initialization."""
        config = Config(api_key="test-key", base_url="https://test.example.com")
        client = YQNClient(config=config)
        
        assert client.config.api_key == "test-key"
        assert client.config.base_url == "https://test.example.com"
        assert client.products is not None
        assert client.inventory is not None
        assert client.orders is not None
    
    def test_client_initialization_with_params(self):
        """Test client initialization with parameters."""
        client = YQNClient(
            api_key="test-key",
            base_url="https://test.example.com",
            timeout=60
        )
        
        assert client.config.api_key == "test-key"
        assert client.config.base_url == "https://test.example.com"
        assert client.config.timeout == 60
    
    def test_context_manager(self):
        """Test context manager functionality."""
        with YQNClient(api_key="test-key") as client:
            assert client.session is not None
        
        # Session should be closed after context exit
        # Note: In actual implementation, session should be closed
    
    @patch('requests.Session.request')
    def test_successful_request(self, mock_request):
        """Test successful API request."""
        mock_response = Mock()
        mock_response.status_code = 200
        mock_response.json.return_value = {"status": "success", "data": {"id": "123"}}
        mock_request.return_value = mock_response
        
        client = YQNClient(api_key="test-key")
        result = client._make_request("GET", "test-endpoint")
        
        assert result["status"] == "success"
        assert result["data"]["id"] == "123"
    
    @patch('requests.Session.request')
    def test_authentication_error(self, mock_request):
        """Test authentication error handling."""
        mock_response = Mock()
        mock_response.status_code = 401
        mock_response.text = "Unauthorized"
        mock_request.return_value = mock_response
        
        client = YQNClient(api_key="invalid-key")
        
        with pytest.raises(AuthenticationError):
            client._make_request("GET", "test-endpoint")
    
    @patch('requests.Session.request')
    def test_api_error(self, mock_request):
        """Test API error handling."""
        mock_response = Mock()
        mock_response.status_code = 400
        mock_response.text = "Bad request"
        mock_request.return_value = mock_response
        
        client = YQNClient(api_key="test-key")
        
        with pytest.raises(APIError) as exc_info:
            client._make_request("GET", "test-endpoint")
        
        assert exc_info.value.status_code == 400
        assert "API error" in str(exc_info.value)
    
    @patch('requests.Session.request')
    def test_server_error(self, mock_request):
        """Test server error handling."""
        mock_response = Mock()
        mock_response.status_code = 500
        mock_response.text = "Internal server error"
        mock_request.return_value = mock_response
        
        client = YQNClient(api_key="test-key")
        
        with pytest.raises(APIError) as exc_info:
            client._make_request("GET", "test-endpoint")
        
        assert exc_info.value.status_code == 500
    
    def test_get_method(self):
        """Test GET method."""
        client = YQNClient(api_key="test-key")
        
        with patch.object(client, '_make_request') as mock_make_request:
            client.get("test-endpoint", {"param": "value"})
            
            mock_make_request.assert_called_once_with(
                "GET", 
                "test-endpoint", 
                params={"param": "value"}
            )
    
    def test_post_method(self):
        """Test POST method."""
        client = YQNClient(api_key="test-key")
        
        with patch.object(client, '_make_request') as mock_make_request:
            client.post("test-endpoint", {"field": "value"})
            
            mock_make_request.assert_called_once_with(
                "POST", 
                "test-endpoint", 
                data={"field": "value"}
            )
    
    def test_put_method(self):
        """Test PUT method."""
        client = YQNClient(api_key="test-key")
        
        with patch.object(client, '_make_request') as mock_make_request:
            client.put("test-endpoint", {"field": "value"})
            
            mock_make_request.assert_called_once_with(
                "PUT", 
                "test-endpoint", 
                data={"field": "value"}
            )
    
    def test_delete_method(self):
        """Test DELETE method."""
        client = YQNClient(api_key="test-key")
        
        with patch.object(client, '_make_request') as mock_make_request:
            client.delete("test-endpoint", {"param": "value"})
            
            mock_make_request.assert_called_once_with(
                "DELETE", 
                "test-endpoint", 
                params={"param": "value"}
            )


class TestConfig:
    """Test cases for configuration."""
    
    def test_config_validation(self):
        """Test configuration validation."""
        config = Config(api_key="test-key")
        
        assert config.api_key == "test-key"
        assert config.base_url == "https://api.yqn.com"
        assert config.timeout == 30
        assert config.max_retries == 3
        assert config.verify_ssl is True
    
    def test_config_headers_setup(self):
        """Test configuration headers setup."""
        config = Config(api_key="test-key")
        
        assert "Authorization" in config.headers
        assert config.headers["Authorization"] == "Bearer test-key"
        assert "User-Agent" in config.headers
    
    def test_config_custom_headers(self):
        """Test configuration with custom headers."""
        custom_headers = {"X-Custom": "value"}
        config = Config(
            api_key="test-key", 
            headers=custom_headers
        )
        
        assert config.headers["X-Custom"] == "value"
        assert "Authorization" in config.headers  # Should be added automatically


if __name__ == "__main__":
    pytest.main([__file__])