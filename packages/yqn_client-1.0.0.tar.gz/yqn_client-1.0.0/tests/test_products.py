"""
Test cases for Products API.
"""

import pytest
from unittest.mock import Mock, patch
from yqn_client import YQNClient
from yqn_client.models.products import Product, ProductListResponse


class TestProductsAPI:
    """Test cases for Products API."""
    
    def setup_method(self):
        """Setup test client."""
        self.client = YQNClient(api_key="test-key")
        self.api = self.client.products
    
    @patch.object(YQNClient, '_make_request')
    def test_list_products(self, mock_request):
        """Test listing products."""
        mock_response = {
            "items": [
                {"id": "1", "name": "Product 1", "sku": "PROD-001", "price": 99.99},
                {"id": "2", "name": "Product 2", "sku": "PROD-002", "price": 199.99}
            ],
            "total": 2,
            "page": 1,
            "page_size": 10
        }
        mock_request.return_value = mock_response
        
        result = self.api.list(page=1, page_size=10)
        
        assert isinstance(result, ProductListResponse)
        assert len(result.items) == 2
        assert result.total == 2
        assert result.items[0].sku == "PROD-001"
        assert result.items[0].price == 99.99
        
        mock_request.assert_called_once_with(
            "GET", 
            "default-group/products/sku-batch-paged-query",
            params={"page": 1, "page_size": 10}
        )
    
    @patch.object(YQNClient, '_make_request')
    def test_get_product(self, mock_request):
        """Test getting product details."""
        mock_response = {
            "id": "1",
            "name": "Test Product",
            "sku": "TEST-001",
            "price": 99.99,
            "category": "Electronics"
        }
        mock_request.return_value = mock_response
        
        result = self.api.get("1")
        
        assert isinstance(result, Product)
        assert result.id == "1"
        assert result.name == "Test Product"
        assert result.sku == "TEST-001"
        assert result.price == 99.99
        
        mock_request.assert_called_once_with(
            "GET", 
            "default-group/products/1"
        )
    
    @patch.object(YQNClient, '_make_request')
    def test_query_by_sku(self, mock_request):
        """Test querying product by SKU."""
        mock_response = {
            "id": "1",
            "name": "Test Product",
            "sku": "TEST-001",
            "price": 99.99
        }
        mock_request.return_value = mock_response
        
        result = self.api.query_by_sku("TEST-001")
        
        assert isinstance(result, Product)
        assert result.sku == "TEST-001"
        
        mock_request.assert_called_once_with(
            "GET", 
            "default-group/products/query-sku",
            params={"sku": "TEST-001"}
        )
    
    @patch.object(YQNClient, '_make_request')
    def test_create_product(self, mock_request):
        """Test creating a product."""
        product_data = {
            "name": "New Product",
            "sku": "NEW-001",
            "price": 149.99,
            "category": "Electronics"
        }
        
        mock_response = {
            "id": "3",
            "name": "New Product",
            "sku": "NEW-001",
            "price": 149.99,
            "category": "Electronics"
        }
        mock_request.return_value = mock_response
        
        result = self.api.create(product_data)
        
        assert isinstance(result, Product)
        assert result.name == "New Product"
        assert result.sku == "NEW-001"
        
        mock_request.assert_called_once_with(
            "POST", 
            "default-group/products/create-edit",
            json_data=product_data
        )
    
    @patch.object(YQNClient, '_make_request')
    def test_create_product_v2(self, mock_request):
        """Test creating a product with V2 endpoint."""
        product_data = {
            "name": "New Product V2",
            "sku": "NEW-002",
            "price": 199.99,
            "category": "Electronics"
        }
        
        mock_response = {
            "id": "4",
            "name": "New Product V2",
            "sku": "NEW-002",
            "price": 199.99,
            "category": "Electronics"
        }
        mock_request.return_value = mock_response
        
        result = self.api.create_v2(product_data)
        
        assert isinstance(result, Product)
        assert result.name == "New Product V2"
        
        mock_request.assert_called_once_with(
            "POST", 
            "default-group/products/create-edit-v2",
            json_data=product_data
        )
    
    @patch.object(YQNClient, '_make_request')
    def test_create_identification_code(self, mock_request):
        """Test creating product identification code."""
        mock_response = {
            "product_id": "1",
            "code": "CODE-12345",
            "code_type": "EAN13",
            "created_at": "2024-01-01T00:00:00Z"
        }
        mock_request.return_value = mock_response
        
        result = self.api.create_identification_code("1", "CODE-12345", "EAN13")
        
        assert result.product_id == "1"
        assert result.code == "CODE-12345"
        assert result.code_type == "EAN13"
        
        expected_data = {
            "product_id": "1",
            "code": "CODE-12345",
            "code_type": "EAN13"
        }
        mock_request.assert_called_once_with(
            "POST", 
            "default-group/products/create-identification-code",
            json_data=expected_data
        )


if __name__ == "__main__":
    pytest.main([__file__])