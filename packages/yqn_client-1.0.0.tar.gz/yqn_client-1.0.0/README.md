# YQN Client Python

A comprehensive Python client for YQN logistics, built with requests and Pydantic for type safety and ease of use.

## Features

- 🚀 Full async and sync support
- 📝 Type-safe models using Pydantic
- 🔧 Easy configuration
- 📚 Comprehensive API coverage
- 🧪 Full test coverage
- 📖 Detailed documentation

## Installation

```bash
pip install yqn-client
```

## Quick Start

```python
from yqn_client import YQNClient

# Initialize client
client = YQNClient(
    api_key="your-api-key",
    base_url="https://api.yqn.com"
)

# Get product list
products = client.products.list()
print(products)

# Create a product
product = client.products.create({
    "name": "Test Product",
    "sku": "TEST-001",
    "price": 99.99
})
```

## API Modules

The client is organized into the following modules:

- **Products** - Product management, SKU operations
- **Warehouse Plans** - Inbound plan management
- **Inventory** - Stock and inventory operations
- **Orders** - Sales order management
- **Returns** - Return order operations
- **Transfers** - Stock transfers
- **Appointments** - Appointment scheduling
- **Base Data** - Basic data queries
- **Auth** - Third-party authorization
- **Shipping** - Shipping fee calculations
- **Cost** - Cost and fee operations

## Documentation

Full documentation is available at [GitHub Repository](https://github.com/cpcc/yqn-client-python#readme).

## Development

```bash
# Install development dependencies
pip install -e ".[dev]"

# Run tests
pytest

# Format code
black src tests

# Type checking
mypy src
```

## License

This project is licensed under the MIT License - see the LICENSE file for details.