"""
YQN Client - A Python client for YQN logistics and e-commerce APIs.
"""

from .client import YQNClient
from .config import Config
from .exceptions import YQNError, APIError, AuthenticationError

__version__ = "1.0.0"
__all__ = ["YQNClient", "Config", "YQNError", "APIError", "AuthenticationError"]