"""
Orders API module.
"""

from typing import Optional, Dict, Any, List
from ..base import BaseAPI
from ..models.orders import Order, OrderCreate, OrderCalculation, OrderListResponse


class OrdersAPI(BaseAPI):
    """Orders API client."""
    
    def calculate(self, calculation_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Calculate order totals and fees.
        
        Args:
            calculation_data: Order calculation data
            
        Returns:
            Calculation results
        """
        return self._post("default-group/orders/calculate", json_data=calculation_data)
    
    def create_with_attachment(
        self, 
        order_data: Dict[str, Any], 
        file_path: Optional[str] = None
    ) -> Order:
        """
        Create sales order with optional attachment.
        
        Args:
            order_data: Order data
            file_path: Optional attachment file path
            
        Returns:
            Created order
        """
        files = None
        if file_path:
            import os
            if not os.path.exists(file_path):
                raise FileNotFoundError(f"File not found: {file_path}")
            files = {"attachment": open(file_path, "rb")}
        
        try:
            response = self._post("default-group/orders/create-with-attachment", 
                                json_data=order_data, files=files)
            return Order(**response)
        finally:
            if files:
                files["attachment"].close()
    
    def get(self, order_id: str) -> Order:
        """
        Get order details by ID.
        
        Args:
            order_id: Order ID
            
        Returns:
            Order details
        """
        response = self._get(f"default-group/orders/{order_id}")
        return Order(**response)
    
    def get_store_order(self, store_order_id: str) -> Order:
        """
        Get store order details.
        
        Args:
            store_order_id: Store order ID
            
        Returns:
            Store order details
        """
        response = self._get(f"default-group/orders/store-order/{store_order_id}")
        return Order(**response)
    
    def list(
        self,
        page: Optional[int] = None,
        page_size: Optional[int] = None,
        customer_id: Optional[str] = None,
        status: Optional[str] = None,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None
    ) -> OrderListResponse:
        """
        Get paginated order list.
        
        Args:
            page: Page number
            page_size: Page size
            customer_id: Customer ID filter
            status: Status filter
            start_date: Start date filter
            end_date: End date filter
            
        Returns:
            Order list response
        """
        params = {}
        if page is not None:
            params["page"] = page
        if page_size is not None:
            params["page_size"] = page_size
        if customer_id:
            params["customer_id"] = customer_id
        if status:
            params["status"] = status
        if start_date:
            params["start_date"] = start_date
        if end_date:
            params["end_date"] = end_date
        
        response = self._get("default-group/orders/list", params)
        return OrderListResponse(**response)
    
    def upload_attachment(self, order_id: str, file_path: str) -> Dict[str, Any]:
        """
        Upload attachment to order.
        
        Args:
            order_id: Order ID
            file_path: File path to upload
            
        Returns:
            Upload result
        """
        import os
        
        if not os.path.exists(file_path):
            raise FileNotFoundError(f"File not found: {file_path}")
        
        files = {"file": open(file_path, "rb")}
        data = {"order_id": order_id}
        
        try:
            return self._post("default-group/orders/upload-attachment", data=data, files=files)
        finally:
            files["file"].close()
    
    def cancel(self, order_id: str, reason: Optional[str] = None) -> Dict[str, Any]:
        """
        Cancel order.
        
        Args:
            order_id: Order ID
            reason: Cancellation reason
            
        Returns:
            Cancellation result
        """
        data = {"order_id": order_id}
        if reason:
            data["reason"] = reason
        
        return self._post("default-group/orders/cancel", json_data=data)