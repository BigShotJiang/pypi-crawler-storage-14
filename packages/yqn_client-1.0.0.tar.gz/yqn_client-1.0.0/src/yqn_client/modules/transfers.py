"""
Transfers API module.
"""

from typing import Optional, Dict, Any, List
from ..base import BaseAPI


class TransfersAPI(BaseAPI):
    """Transfers API client."""
    
    def create(self, transfer_data: Dict[str, Any]) -> Dict[str, Any]:
        """Create transfer."""
        return self._post("default-group/transfers/create", json_data=transfer_data)
    
    def cancel_by_source_no(self, source_no: str, reason: Optional[str] = None) -> Dict[str, Any]:
        """Cancel transfer by source number."""
        data = {"source_no": source_no}
        if reason:
            data["reason"] = reason
        
        return self._post("default-group/transfers/cancel-by-source-no", json_data=data)
    
    def upload_attachment(self, transfer_id: str, file_path: str) -> Dict[str, Any]:
        """Upload transfer attachment."""
        import os
        
        if not os.path.exists(file_path):
            raise FileNotFoundError(f"File not found: {file_path}")
        
        files = {"file": open(file_path, "rb")}
        data = {"transfer_id": transfer_id}
        
        try:
            return self._post("default-group/transfers/upload-attachment", data=data, files=files)
        finally:
            files["file"].close()
    
    def get(self, transfer_id: str) -> Dict[str, Any]:
        """Get transfer details."""
        return self._get(f"default-group/transfers/{transfer_id}")