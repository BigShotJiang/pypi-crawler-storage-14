"""
Products API module.
"""

from typing import Optional, Dict, Any, List
from ..base import BaseAPI
from ..models.products import (
    Product, ProductCreate, ProductUpdate, ProductListResponse,
    ProductIdentificationCode, ChannelProductRelation, BoxProduct
)


class ProductsAPI(BaseAPI):
    """Products API client."""
    
    def list(
        self,
        page: Optional[int] = None,
        page_size: Optional[int] = None,
        search: Optional[str] = None,
        category: Optional[str] = None,
        status: Optional[str] = None
    ) -> ProductListResponse:
        """
        Get paginated product list.
        
        Args:
            page: Page number
            page_size: Page size
            search: Search keyword
            category: Product category filter
            status: Product status filter
            
        Returns:
            Product list response
        """
        params = {}
        if page is not None:
            params["page"] = page
        if page_size is not None:
            params["page_size"] = page_size
        if search:
            params["search"] = search
        if category:
            params["category"] = category
        if status:
            params["status"] = status
        
        response = self._get("default-group/products/sku-batch-paged-query", params)
        return ProductListResponse(**response)
    
    def get(self, product_id: str) -> Product:
        """
        Get product details by ID.
        
        Args:
            product_id: Product ID
            
        Returns:
            Product details
        """
        response = self._get(f"default-group/products/{product_id}")
        return Product(**response)
    
    def query_by_sku(self, sku: str) -> Product:
        """
        Query product by SKU.
        
        Args:
            sku: Product SKU
            
        Returns:
            Product details
        """
        params = {"sku": sku}
        response = self._get("default-group/products/query-sku", params)
        return Product(**response)
    
    def create_v2(self, product_data: Dict[str, Any]) -> Product:
        """
        Create/edit product V2 (with complete field coverage).
        
        Args:
            product_data: Product data
            
        Returns:
            Created product
        """
        response = self._post("default-group/products/create-edit-v2", json_data=product_data)
        return Product(**response)
    
    def create(self, product_data: Dict[str, Any]) -> Product:
        """
        Create/edit product.
        
        Args:
            product_data: Product data
            
        Returns:
            Created product
        """
        response = self._post("default-group/products/create-edit", json_data=product_data)
        return Product(**response)
    
    def create_identification_code(
        self, 
        product_id: str, 
        code: str, 
        code_type: str
    ) -> ProductIdentificationCode:
        """
        Create product identification code.
        
        Args:
            product_id: Product ID
            code: Identification code
            code_type: Code type
            
        Returns:
            Identification code details
        """
        data = {
            "product_id": product_id,
            "code": code,
            "code_type": code_type
        }
        response = self._post("default-group/products/create-identification-code", json_data=data)
        return ProductIdentificationCode(**response)
    
    def add_box_product(self, box_data: Dict[str, Any]) -> BoxProduct:
        """
        Add box product.
        
        Args:
            box_data: Box product data
            
        Returns:
            Created box product
        """
        response = self._post("default-group/products/add-box-product", json_data=box_data)
        return BoxProduct(**response)
    
    def get_channel_product_relations(
        self, 
        product_id: Optional[str] = None,
        channel_code: Optional[str] = None
    ) -> List[ChannelProductRelation]:
        """
        Query channel product relations.
        
        Args:
            product_id: Product ID filter
            channel_code: Channel code filter
            
        Returns:
            Channel product relations
        """
        params = {}
        if product_id:
            params["product_id"] = product_id
        if channel_code:
            params["channel_code"] = channel_code
        
        response = self._get("default-group/products/channel-product-relations", params)
        return [ChannelProductRelation(**item) for item in response.get("items", [])]
    
    def update(self, product_id: str, update_data: Dict[str, Any]) -> Product:
        """
        Update product.
        
        Args:
            product_id: Product ID
            update_data: Update data
            
        Returns:
            Updated product
        """
        update_data["product_id"] = product_id
        response = self._put(f"default-group/products/{product_id}", json_data=update_data)
        return Product(**response)
    
    def delete(self, product_id: str) -> Dict[str, Any]:
        """
        Delete product.
        
        Args:
            product_id: Product ID
            
        Returns:
            Deletion response
        """
        return self._delete(f"default-group/products/{product_id}")