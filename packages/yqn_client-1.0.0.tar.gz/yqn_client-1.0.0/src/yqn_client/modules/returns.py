"""
Returns API module.
"""

from typing import Optional, Dict, Any, List
from ..base import BaseAPI


class ReturnsAPI(BaseAPI):
    """Returns API client."""
    
    def track_logistics(self, return_id: str) -> Dict[str, Any]:
        """Track return logistics."""
        return self._get(f"default-group/returns/{return_id}/track-logistics")
    
    def process_item(self, return_id: str, item_data: Dict[str, Any]) -> Dict[str, Any]:
        """Process return item."""
        data = {"return_id": return_id, **item_data}
        return self._post("default-group/returns/process-item", json_data=data)
    
    def upload_attachment(self, return_id: str, file_path: str) -> Dict[str, Any]:
        """Upload return attachment."""
        import os
        
        if not os.path.exists(file_path):
            raise FileNotFoundError(f"File not found: {file_path}")
        
        files = {"file": open(file_path, "rb")}
        data = {"return_id": return_id}
        
        try:
            return self._post("default-group/returns/upload-attachment", data=data, files=files)
        finally:
            files["file"].close()
    
    def delete_attachment(self, return_id: str, attachment_id: str) -> Dict[str, Any]:
        """Delete return attachment."""
        return self._delete(f"default-group/returns/{return_id}/attachments/{attachment_id}")
    
    def confirm_plan(self, return_id: str, confirmation_data: Dict[str, Any]) -> Dict[str, Any]:
        """Confirm return plan processing."""
        data = {"return_id": return_id, **confirmation_data}
        return self._post("default-group/returns/confirm-plan", json_data=data)
    
    def create(self, return_data: Dict[str, Any]) -> Dict[str, Any]:
        """Create sales return."""
        return self._post("default-group/returns/create", json_data=return_data)
    
    def cancel(self, return_id: str, reason: Optional[str] = None) -> Dict[str, Any]:
        """Cancel sales return."""
        data = {"return_id": return_id}
        if reason:
            data["reason"] = reason
        
        return self._post("default-group/returns/cancel", json_data=data)
    
    def get_plans(
        self,
        page: Optional[int] = None,
        page_size: Optional[int] = None,
        status: Optional[str] = None
    ) -> Dict[str, Any]:
        """Query sales return plans."""
        params = {}
        if page is not None:
            params["page"] = page
        if page_size is not None:
            params["page_size"] = page_size
        if status:
            params["status"] = status
        
        return self._get("default-group/returns/plans", params)