"""
Appointments API module.
"""

from typing import Optional, Dict, Any, List
from ..base import BaseAPI


class AppointmentsAPI(BaseAPI):
    """Appointments API client."""
    
    def check_availability(self, appointment_data: Dict[str, Any]) -> Dict[str, Any]:
        """Check if appointment is available."""
        return self._post("default-group/appointments/check-availability", json_data=appointment_data)