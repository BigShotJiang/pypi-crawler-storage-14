"""
Warehouse plans API module.
"""

from typing import Optional, Dict, Any, List
from ..base import BaseAPI
from ..models.warehouse_plans import (
    WarehousePlan, WarehousePlanCreate, WarehousePlanListResponse,
    ShippingInfo, ShippingCompany, WarehousePlanItem, Attachment
)


class WarehousePlansAPI(BaseAPI):
    """Warehouse plans API client."""
    
    def list(
        self,
        page: Optional[int] = None,
        page_size: Optional[int] = None,
        warehouse_code: Optional[str] = None,
        status: Optional[str] = None,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None
    ) -> WarehousePlanListResponse:
        """
        Get paginated warehouse plan list.
        
        Args:
            page: Page number
            page_size: Page size
            warehouse_code: Warehouse code filter
            status: Status filter
            start_date: Start date filter
            end_date: End date filter
            
        Returns:
            Warehouse plan list response
        """
        params = {}
        if page is not None:
            params["page"] = page
        if page_size is not None:
            params["page_size"] = page_size
        if warehouse_code:
            params["warehouse_code"] = warehouse_code
        if status:
            params["status"] = status
        if start_date:
            params["start_date"] = start_date
        if end_date:
            params["end_date"] = end_date
        
        response = self._get("default-group/warehouse-plans/paged-query", params)
        return WarehousePlanListResponse(**response)
    
    def get(self, plan_id: str) -> WarehousePlan:
        """
        Get warehouse plan details by ID.
        
        Args:
            plan_id: Plan ID
            
        Returns:
            Warehouse plan details
        """
        response = self._get(f"default-group/warehouse-plans/{plan_id}")
        return WarehousePlan(**response)
    
    def create(self, plan_data: Dict[str, Any]) -> WarehousePlan:
        """
        Create warehouse plan.
        
        Args:
            plan_data: Plan data
            
        Returns:
            Created warehouse plan
        """
        response = self._post("default-group/warehouse-plans/create", json_data=plan_data)
        return WarehousePlan(**response)
    
    def create_or_update_draft(self, plan_data: Dict[str, Any]) -> WarehousePlan:
        """
        Create/update warehouse plan (supports default draft status for editing).
        
        Args:
            plan_data: Plan data
            
        Returns:
            Created/updated warehouse plan
        """
        response = self._post("default-group/warehouse-plans/create-update-draft", json_data=plan_data)
        return WarehousePlan(**response)
    
    def update_shipping_info(self, plan_id: str, shipping_info: Dict[str, Any]) -> ShippingInfo:
        """
        Update shipping information for warehouse plan.
        
        Args:
            plan_id: Plan ID
            shipping_info: Shipping information
            
        Returns:
            Updated shipping information
        """
        data = {"plan_id": plan_id, **shipping_info}
        response = self._put("default-group/warehouse-plans/update-shipping-info", json_data=data)
        return ShippingInfo(**response)
    
    def get_shipping_companies(self) -> List[ShippingCompany]:
        """
        Get shipping company code list.
        
        Returns:
            List of shipping companies
        """
        response = self._get("default-group/warehouse-plans/shipping-companies")
        return [ShippingCompany(**item) for item in response.get("items", [])]
    
    def execute_shipping(self, plan_id: str, shipping_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Execute shipping operation for warehouse plan.
        
        Args:
            plan_id: Plan ID
            shipping_data: Shipping operation data
            
        Returns:
            Shipping operation result
        """
        data = {"plan_id": plan_id, **shipping_data}
        return self._post("default-group/warehouse-plans/execute-shipping", json_data=data)
    
    def add_attachment(self, plan_id: str, file_path: str, description: Optional[str] = None) -> Attachment:
        """
        Add attachment to warehouse plan.
        
        Args:
            plan_id: Plan ID
            file_path: File path to upload
            description: Optional description
            
        Returns:
            Attachment details
        """
        import os
        
        if not os.path.exists(file_path):
            raise FileNotFoundError(f"File not found: {file_path}")
        
        files = {"file": open(file_path, "rb")}
        data = {"plan_id": plan_id}
        if description:
            data["description"] = description
        
        try:
            response = self._post("default-group/warehouse-plans/add-attachment", data=data, files=files)
            return Attachment(**response)
        finally:
            files["file"].close()
    
    def cancel(self, plan_id: str, reason: Optional[str] = None) -> Dict[str, Any]:
        """
        Cancel warehouse plan.
        
        Args:
            plan_id: Plan ID
            reason: Cancellation reason
            
        Returns:
            Cancellation result
        """
        data = {"plan_id": plan_id}
        if reason:
            data["reason"] = reason
        
        return self._post("default-group/warehouse-plans/cancel", json_data=data)
    
    def query_warehouse_info(self, plan_id: str) -> Dict[str, Any]:
        """
        Query warehouse information.
        
        Args:
            plan_id: Plan ID
            
        Returns:
            Warehouse information
        """
        params = {"plan_id": plan_id}
        return self._get("default-group/warehouse-plans/query-warehouse-info", params)
    
    def get_items(self, plan_id: str) -> List[WarehousePlanItem]:
        """
        Get warehouse plan items.
        
        Args:
            plan_id: Plan ID
            
        Returns:
            List of warehouse plan items
        """
        response = self._get(f"default-group/warehouse-plans/{plan_id}/items")
        return [WarehousePlanItem(**item) for item in response.get("items", [])]