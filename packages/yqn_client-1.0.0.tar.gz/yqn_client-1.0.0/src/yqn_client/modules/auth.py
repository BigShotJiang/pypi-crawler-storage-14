"""
Authentication API module.
"""

from typing import Optional, Dict, Any, List
from ..base import BaseAPI


class AuthAPI(BaseAPI):
    """Authentication API client."""
    
    def register_developer(self, developer_data: Dict[str, Any]) -> Dict[str, Any]:
        """Register developer account."""
        return self._post("default-group/auth/register-developer", json_data=developer_data)
    
    def register_app(self, app_data: Dict[str, Any]) -> Dict[str, Any]:
        """Register application."""
        return self._post("default-group/auth/register-app", json_data=app_data)
    
    def authorize_service_provider(self, auth_data: Dict[str, Any]) -> Dict[str, Any]:
        """Authorize service provider."""
        return self._post("default-group/auth/authorize-service-provider", json_data=auth_data)