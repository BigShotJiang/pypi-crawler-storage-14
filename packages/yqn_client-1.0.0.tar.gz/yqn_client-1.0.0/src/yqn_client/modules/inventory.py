"""
Inventory API module.
"""

from typing import Optional, Dict, Any, List
from ..base import BaseAPI
from ..models.inventory import (
    InventoryItem, InventoryQuery, InventoryBatchQuery, InventoryAge,
    InventoryChange, InventoryBatch, WinItSnapshot,
    InventoryListResponse, InventoryAgeListResponse
)


class InventoryAPI(BaseAPI):
    """Inventory API client."""
    
    def batch_query(self, query_data: Dict[str, Any]) -> InventoryListResponse:
        """
        Batch query inventory.
        
        Args:
            query_data: Query data containing SKUs and filters
            
        Returns:
            Inventory list response
        """
        response = self._post("default-group/inventory/batch-query", json_data=query_data)
        return InventoryListResponse(**response)
    
    def query(self, sku: str, warehouse_code: Optional[str] = None) -> InventoryItem:
        """
        Query inventory for a specific SKU.
        
        Args:
            sku: Product SKU
            warehouse_code: Optional warehouse code filter
            
        Returns:
            Inventory item
        """
        params = {"sku": sku}
        if warehouse_code:
            params["warehouse_code"] = warehouse_code
        
        response = self._get("default-group/inventory/query", params)
        return InventoryItem(**response)
    
    def batch_query_inventory(self, query_data: InventoryBatchQuery) -> InventoryListResponse:
        """
        Batch query inventory (alternative endpoint).
        
        Args:
            query_data: Batch query request
            
        Returns:
            Inventory list response
        """
        response = self._post("default-group/inventory/batch-query-inventory", json_data=query_data.dict())
        return InventoryListResponse(**response)
    
    def get_winits_snapshot(self, warehouse_code: Optional[str] = None) -> WinItSnapshot:
        """
        Get WinIt snapshot query.
        
        Args:
            warehouse_code: Optional warehouse code
            
        Returns:
            WinIt snapshot
        """
        params = {}
        if warehouse_code:
            params["warehouse_code"] = warehouse_code
        
        response = self._get("default-group/inventory/winits-snapshot", params)
        return WinItSnapshot(**response)
    
    def get_changes(
        self,
        sku: Optional[str] = None,
        warehouse_code: Optional[str] = None,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
        page: Optional[int] = None,
        page_size: Optional[int] = None
    ) -> List[InventoryChange]:
        """
        Query inventory change details.
        
        Args:
            sku: SKU filter
            warehouse_code: Warehouse code filter
            start_date: Start date filter
            end_date: End date filter
            page: Page number
            page_size: Page size
            
        Returns:
            List of inventory changes
        """
        params = {}
        if sku:
            params["sku"] = sku
        if warehouse_code:
            params["warehouse_code"] = warehouse_code
        if start_date:
            params["start_date"] = start_date
        if end_date:
            params["end_date"] = end_date
        if page is not None:
            params["page"] = page
        if page_size is not None:
            params["page_size"] = page_size
        
        response = self._get("default-group/inventory/changes", params)
        return [InventoryChange(**item) for item in response.get("items", [])]
    
    def get_batch_details(
        self,
        sku: Optional[str] = None,
        warehouse_code: Optional[str] = None,
        batch_number: Optional[str] = None,
        page: Optional[int] = None,
        page_size: Optional[int] = None
    ) -> List[InventoryBatch]:
        """
        Query inventory batch details.
        
        Args:
            sku: SKU filter
            warehouse_code: Warehouse code filter
            batch_number: Batch number filter
            page: Page number
            page_size: Page size
            
        Returns:
            List of inventory batch details
        """
        params = {}
        if sku:
            params["sku"] = sku
        if warehouse_code:
            params["warehouse_code"] = warehouse_code
        if batch_number:
            params["batch_number"] = batch_number
        if page is not None:
            params["page"] = page
        if page_size is not None:
            params["page_size"] = page_size
        
        response = self._get("default-group/inventory/batch-details", params)
        return [InventoryBatch(**item) for item in response.get("items", [])]
    
    def batch_query_age(self, query_data: Dict[str, Any]) -> InventoryAgeListResponse:
        """
        Batch query inventory age.
        
        Args:
            query_data: Query data containing SKUs and filters
            
        Returns:
            Inventory age list response
        """
        response = self._post("default-group/inventory/batch-query-age", json_data=query_data)
        return InventoryAgeListResponse(**response)
    
    def get_age_analysis(
        self,
        warehouse_code: Optional[str] = None,
        age_ranges: Optional[List[str]] = None,
        page: Optional[int] = None,
        page_size: Optional[int] = None
    ) -> List[InventoryAge]:
        """
        Get inventory age analysis.
        
        Args:
            warehouse_code: Warehouse code filter
            age_ranges: Age ranges to analyze
            page: Page number
            page_size: Page size
            
        Returns:
            List of inventory age analysis
        """
        params = {}
        if warehouse_code:
            params["warehouse_code"] = warehouse_code
        if age_ranges:
            params["age_ranges"] = ",".join(age_ranges)
        if page is not None:
            params["page"] = page
        if page_size is not None:
            params["page_size"] = page_size
        
        response = self._get("default-group/inventory/age-analysis", params)
        return [InventoryAge(**item) for item in response.get("items", [])]
    
    def adjust_inventory(
        self,
        sku: str,
        quantity_change: int,
        warehouse_code: str,
        reason: Optional[str] = None,
        reference_no: Optional[str] = None
    ) -> InventoryItem:
        """
        Adjust inventory quantity.
        
        Args:
            sku: Product SKU
            quantity_change: Quantity to adjust (positive for increase, negative for decrease)
            warehouse_code: Warehouse code
            reason: Adjustment reason
            reference_no: Reference number
            
        Returns:
            Updated inventory item
        """
        data = {
            "sku": sku,
            "quantity_change": quantity_change,
            "warehouse_code": warehouse_code
        }
        if reason:
            data["reason"] = reason
        if reference_no:
            data["reference_no"] = reference_no
        
        response = self._post("default-group/inventory/adjust", json_data=data)
        return InventoryItem(**response)
    
    def reserve_inventory(
        self,
        sku: str,
        quantity: int,
        warehouse_code: str,
        order_id: Optional[str] = None
    ) -> InventoryItem:
        """
        Reserve inventory.
        
        Args:
            sku: Product SKU
            quantity: Quantity to reserve
            warehouse_code: Warehouse code
            order_id: Optional order ID
            
        Returns:
            Updated inventory item
        """
        data = {
            "sku": sku,
            "quantity": quantity,
            "warehouse_code": warehouse_code
        }
        if order_id:
            data["order_id"] = order_id
        
        response = self._post("default-group/inventory/reserve", json_data=data)
        return InventoryItem(**response)
    
    def release_inventory(
        self,
        sku: str,
        quantity: int,
        warehouse_code: str,
        order_id: Optional[str] = None
    ) -> InventoryItem:
        """
        Release reserved inventory.
        
        Args:
            sku: Product SKU
            quantity: Quantity to release
            warehouse_code: Warehouse code
            order_id: Optional order ID
            
        Returns:
            Updated inventory item
        """
        data = {
            "sku": sku,
            "quantity": quantity,
            "warehouse_code": warehouse_code
        }
        if order_id:
            data["order_id"] = order_id
        
        response = self._post("default-group/inventory/release", json_data=data)
        return InventoryItem(**response)