"""
Shipping API module.
"""

from typing import Optional, Dict, Any, List
from ..base import BaseAPI


class ShippingAPI(BaseAPI):
    """Shipping API client."""
    
    def get_fee_settlement(
        self,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
        page: Optional[int] = None,
        page_size: Optional[int] = None
    ) -> Dict[str, Any]:
        """Query shipping fee settlement details."""
        params = {}
        if start_date:
            params["start_date"] = start_date
        if end_date:
            params["end_date"] = end_date
        if page is not None:
            params["page"] = page
        if page_size is not None:
            params["page_size"] = page_size
        
        return self._get("default-group/shipping/fee-settlement", params)