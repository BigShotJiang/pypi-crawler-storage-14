"""
Base data API module.
"""

from typing import Optional, Dict, Any, List
from ..base import BaseAPI


class BaseDataAPI(BaseAPI):
    """Base data API client."""
    
    def get_warehouses(self, active_only: bool = True) -> List[Dict[str, Any]]:
        """Query warehouses."""
        params = {"active_only": active_only}
        response = self._get("default-group/base-data/warehouses", params)
        return response.get("warehouses", [])
    
    def get_warehouse_services(self, warehouse_code: str) -> List[Dict[str, Any]]:
        """Get product service list by warehouse code."""
        return self._get(f"default-group/base-data/warehouses/{warehouse_code}/services")