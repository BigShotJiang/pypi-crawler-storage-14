"""
Cost API module.
"""

from typing import Optional, Dict, Any, List
from ..base import BaseAPI


class CostAPI(BaseAPI):
    """Cost API client."""
    
    def get_settlement_details(
        self,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
        cost_type: Optional[str] = None,
        page: Optional[int] = None,
        page_size: Optional[int] = None
    ) -> Dict[str, Any]:
        """Query cost settlement details."""
        params = {}
        if start_date:
            params["start_date"] = start_date
        if end_date:
            params["end_date"] = end_date
        if cost_type:
            params["cost_type"] = cost_type
        if page is not None:
            params["page"] = page
        if page_size is not None:
            params["page_size"] = page_size
        
        return self._get("default-group/cost/settlement-details", params)