"""
Base API module.
"""

from typing import Optional, Dict, Any
from ..client import YQNClient


class BaseAPI:
    """Base class for all API modules."""
    
    def __init__(self, client: YQNClient):
        """
        Initialize base API.
        
        Args:
            client: YQN client instance
        """
        self.client = client
    
    def _get(
        self, 
        endpoint: str, 
        params: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """Make GET request."""
        return self.client.get(endpoint, params)
    
    def _post(
        self,
        endpoint: str,
        data: Optional[Dict[str, Any]] = None,
        json_data: Optional[Dict[str, Any]] = None,
        files: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """Make POST request."""
        return self.client.post(endpoint, data=data, json_data=json_data, files=files)
    
    def _put(
        self,
        endpoint: str,
        data: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """Make PUT request."""
        return self.client.put(endpoint, data=data)
    
    def _delete(
        self,
        endpoint: str,
        params: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """Make DELETE request."""
        return self.client.delete(endpoint, params=params)