"""
Custom exceptions for YQN Client.
"""

from typing import Optional, Any, Dict


class YQNError(Exception):
    """Base exception for all YQN client errors."""
    
    def __init__(self, message: str, error_code: Optional[str] = None, details: Optional[Dict[str, Any]] = None):
        self.message = message
        self.error_code = error_code
        self.details = details or {}
        super().__init__(self.message)
    
    def __str__(self) -> str:
        if self.error_code:
            return f"[{self.error_code}] {self.message}"
        return self.message


class APIError(YQNError):
    """Raised when API returns an error response."""
    
    def __init__(
        self, 
        message: str, 
        status_code: Optional[int] = None,
        error_code: Optional[str] = None, 
        details: Optional[Dict[str, Any]] = None
    ):
        self.status_code = status_code
        super().__init__(message, error_code, details)


class AuthenticationError(YQNError):
    """Raised when authentication fails."""
    
    def __init__(self, message: str = "Authentication failed", details: Optional[Dict[str, Any]] = None):
        super().__init__(message, "AUTH_ERROR", details)


class ValidationError(YQNError):
    """Raised when request validation fails."""
    
    def __init__(self, message: str, field: Optional[str] = None, details: Optional[Dict[str, Any]] = None):
        self.field = field
        super().__init__(message, "VALIDATION_ERROR", details)


class RateLimitError(APIError):
    """Raised when API rate limit is exceeded."""
    
    def __init__(self, message: str = "Rate limit exceeded", details: Optional[Dict[str, Any]] = None):
        super().__init__(message, 429, "RATE_LIMIT", details)


class ServerError(APIError):
    """Raised when server returns 5xx error."""
    
    def __init__(self, message: str = "Server error", status_code: int = 500, details: Optional[Dict[str, Any]] = None):
        super().__init__(message, status_code, "SERVER_ERROR", details)