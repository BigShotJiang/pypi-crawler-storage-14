"""
Configuration management for YQN Client.
"""

from typing import Optional, Dict, Any
from pydantic import BaseModel, Field


class Config(BaseModel):
    """Configuration for YQN Client."""
    
    api_key: str = Field(..., description="API key for authentication")
    base_url: str = Field(default="https://api.yqn.com", description="Base URL for API")
    timeout: int = Field(default=30, description="Request timeout in seconds")
    max_retries: int = Field(default=3, description="Maximum number of retries")
    retry_delay: float = Field(default=1.0, description="Delay between retries in seconds")
    headers: Dict[str, str] = Field(default_factory=dict, description="Additional headers")
    verify_ssl: bool = Field(default=True, description="Whether to verify SSL certificates")
    
    def model_post_init(self, __context: Any) -> None:
        """Post-initialization setup."""
        # Set default headers
        if "User-Agent" not in self.headers:
            self.headers["User-Agent"] = f"yqn-client-python/1.0.0"
        
        if "Authorization" not in self.headers:
            self.headers["Authorization"] = f"Bearer {self.api_key}"
    
    class Config:
        """Pydantic configuration."""
        validate_assignment = True
        extra = "forbid"