"""
Main YQN Client implementation.
"""

import time
import logging
from typing import Optional, Dict, Any, Union
import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

from .config import Config
from .exceptions import (
    APIError, 
    AuthenticationError, 
    RateLimitError, 
    ServerError,
    ValidationError
)

# Import all API modules
from .modules.products import ProductsAPI
from .modules.warehouse_plans import WarehousePlansAPI
from .modules.inventory import InventoryAPI
from .modules.orders import OrdersAPI
from .modules.returns import ReturnsAPI
from .modules.transfers import TransfersAPI
from .modules.appointments import AppointmentsAPI
from .modules.base_data import BaseDataAPI
from .modules.auth import AuthAPI
from .modules.shipping import ShippingAPI
from .modules.cost import CostAPI


logger = logging.getLogger(__name__)


class YQNClient:
    """
    Main client for YQN API.
    
    Example:
        >>> client = YQNClient(api_key="your-api-key")
        >>> products = client.products.list()
    """
    
    def __init__(
        self,
        api_key: Optional[str] = None,
        base_url: Optional[str] = None,
        timeout: Optional[int] = None,
        max_retries: Optional[int] = None,
        retry_delay: Optional[float] = None,
        headers: Optional[Dict[str, str]] = None,
        verify_ssl: Optional[bool] = None,
        config: Optional[Config] = None
    ):
        """
        Initialize YQN Client.
        
        Args:
            api_key: API key for authentication
            base_url: Base URL for API
            timeout: Request timeout in seconds
            max_retries: Maximum number of retries
            retry_delay: Delay between retries in seconds
            headers: Additional headers
            verify_ssl: Whether to verify SSL certificates
            config: Configuration object (overrides individual parameters)
        """
        if config:
            self.config = config
        else:
            self.config = Config(
                api_key=api_key or "",
                base_url=base_url or "https://api.yqn.com",
                timeout=timeout or 30,
                max_retries=max_retries or 3,
                retry_delay=retry_delay or 1.0,
                headers=headers or {},
                verify_ssl=verify_ssl if verify_ssl is not None else True
            )
        
        self.session = self._create_session()
        
        # Initialize API modules
        self.products = ProductsAPI(self)
        self.warehouse_plans = WarehousePlansAPI(self)
        self.inventory = InventoryAPI(self)
        self.orders = OrdersAPI(self)
        self.returns = ReturnsAPI(self)
        self.transfers = TransfersAPI(self)
        self.appointments = AppointmentsAPI(self)
        self.base_data = BaseDataAPI(self)
        self.auth = AuthAPI(self)
        self.shipping = ShippingAPI(self)
        self.cost = CostAPI(self)
    
    def _create_session(self) -> requests.Session:
        """Create HTTP session with retry strategy."""
        session = requests.Session()
        
        # Configure retry strategy
        retry_strategy = Retry(
            total=self.config.max_retries,
            backoff_factor=self.config.retry_delay,
            status_forcelist=[429, 500, 502, 503, 504],
            allowed_methods=["HEAD", "GET", "POST", "PUT", "DELETE", "OPTIONS", "TRACE"]
        )
        
        adapter = HTTPAdapter(max_retries=retry_strategy)
        session.mount("http://", adapter)
        session.mount("https://", adapter)
        
        # Set default headers
        session.headers.update(self.config.headers)
        
        return session
    
    def _make_request(
        self,
        method: str,
        endpoint: str,
        params: Optional[Dict[str, Any]] = None,
        data: Optional[Dict[str, Any]] = None,
        files: Optional[Dict[str, Any]] = None,
        json_data: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """
        Make HTTP request to API.
        
        Args:
            method: HTTP method
            endpoint: API endpoint
            params: Query parameters
            data: Form data
            files: Files to upload
            json_data: JSON data
            
        Returns:
            Response data
            
        Raises:
            APIError: When API returns an error
            AuthenticationError: When authentication fails
            RateLimitError: When rate limit is exceeded
            ServerError: When server error occurs
        """
        url = f"{self.config.base_url.rstrip('/')}/{endpoint.lstrip('/')}"
        
        kwargs = {
            "params": params,
            "data": data,
            "files": files,
            "json": json_data,
            "timeout": self.config.timeout,
            "verify": self.config.verify_ssl
        }
        
        # Remove None values
        kwargs = {k: v for k, v in kwargs.items() if v is not None}
        
        try:
            logger.debug(f"Making {method} request to {url}")
            response = self.session.request(method, url, **kwargs)
            
            # Handle response based on status code
            if response.status_code == 401:
                raise AuthenticationError("Authentication failed", {"response": response.text})
            elif response.status_code == 429:
                raise RateLimitError("Rate limit exceeded", {"response": response.text})
            elif response.status_code >= 500:
                raise ServerError(
                    f"Server error: {response.status_code}",
                    response.status_code,
                    {"response": response.text}
                )
            elif response.status_code >= 400:
                raise APIError(
                    f"API error: {response.status_code}",
                    response.status_code,
                    details={"response": response.text}
                )
            
            # Try to parse JSON response
            try:
                response_data = response.json()
            except ValueError:
                if not response.text:
                    return {}
                response_data = {"data": response.text}
            
            logger.debug(f"Response: {response_data}")
            return response_data
            
        except requests.exceptions.Timeout:
            raise APIError("Request timeout")
        except requests.exceptions.ConnectionError:
            raise APIError("Connection error")
        except requests.exceptions.RequestException as e:
            raise APIError(f"Request failed: {str(e)}")
    
    def get(self, endpoint: str, params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """Make GET request."""
        return self._make_request("GET", endpoint, params=params)
    
    def post(
        self, 
        endpoint: str, 
        data: Optional[Dict[str, Any]] = None,
        json_data: Optional[Dict[str, Any]] = None,
        files: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """Make POST request."""
        return self._make_request("POST", endpoint, data=data, json_data=json_data, files=files)
    
    def put(self, endpoint: str, data: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """Make PUT request."""
        return self._make_request("PUT", endpoint, data=data)
    
    def delete(self, endpoint: str, params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """Make DELETE request."""
        return self._make_request("DELETE", endpoint, params=params)
    
    def close(self):
        """Close the session."""
        if self.session:
            self.session.close()
    
    def __enter__(self):
        """Context manager entry."""
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        """Context manager exit."""
        self.close()