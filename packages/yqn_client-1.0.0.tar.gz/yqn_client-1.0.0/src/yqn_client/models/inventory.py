"""
Inventory related Pydantic models.
"""

from typing import Optional, List, Dict, Any
from pydantic import BaseModel, Field
from datetime import datetime


class InventoryItem(BaseModel):
    """Inventory item model."""
    
    sku: Optional[str] = Field(None, description="Product SKU")
    warehouse_code: Optional[str] = Field(None, description="Warehouse code")
    quantity: Optional[int] = Field(None, description="Available quantity")
    reserved_quantity: Optional[int] = Field(None, description="Reserved quantity")
    available_quantity: Optional[int] = Field(None, description="Available quantity")
    batch_number: Optional[str] = Field(None, description="Batch number")
    production_date: Optional[str] = Field(None, description="Production date")
    expiry_date: Optional[str] = Field(None, description="Expiry date")
    
    class Config:
        """Pydantic configuration."""
        extra = "allow"


class InventoryQuery(BaseModel):
    """Inventory query request model."""
    
    sku: Optional[str] = Field(None, description="Product SKU")
    warehouse_code: Optional[str] = Field(None, description="Warehouse code")
    include_reserved: Optional[bool] = Field(True, description="Include reserved quantity")
    
    class Config:
        """Pydantic configuration."""
        extra = "allow"


class InventoryBatchQuery(BaseModel):
    """Inventory batch query request model."""
    
    skus: List[str] = Field(..., description="List of SKUs to query")
    warehouse_code: Optional[str] = Field(None, description="Warehouse code filter")
    
    class Config:
        """Pydantic configuration."""
        extra = "allow"


class InventoryAge(BaseModel):
    """Inventory age model."""
    
    sku: Optional[str] = Field(None, description="Product SKU")
    warehouse_code: Optional[str] = Field(None, description="Warehouse code")
    age_days: Optional[int] = Field(None, description="Age in days")
    quantity: Optional[int] = Field(None, description="Quantity")
    batch_number: Optional[str] = Field(None, description="Batch number")
    in_date: Optional[str] = Field(None, description="Inventory date")
    
    class Config:
        """Pydantic configuration."""
        extra = "allow"


class InventoryChange(BaseModel):
    """Inventory change detail model."""
    
    id: Optional[str] = Field(None, description="Change ID")
    sku: Optional[str] = Field(None, description="Product SKU")
    warehouse_code: Optional[str] = Field(None, description="Warehouse code")
    change_type: Optional[str] = Field(None, description="Change type")
    quantity_change: Optional[int] = Field(None, description="Quantity change")
    quantity_before: Optional[int] = Field(None, description="Quantity before change")
    quantity_after: Optional[int] = Field(None, description="Quantity after change")
    reason: Optional[str] = Field(None, description="Change reason")
    reference_no: Optional[str] = Field(None, description="Reference number")
    created_at: Optional[str] = Field(None, description="Change time")
    
    class Config:
        """Pydantic configuration."""
        extra = "allow"


class InventoryBatch(BaseModel):
    """Inventory batch detail model."""
    
    batch_number: Optional[str] = Field(None, description="Batch number")
    sku: Optional[str] = Field(None, description="Product SKU")
    warehouse_code: Optional[str] = Field(None, description="Warehouse code")
    quantity: Optional[int] = Field(None, description="Batch quantity")
    available_quantity: Optional[int] = Field(None, description="Available quantity")
    production_date: Optional[str] = Field(None, description="Production date")
    expiry_date: Optional[str] = Field(None, description="Expiry date")
    cost: Optional[float] = Field(None, description="Cost")
    
    class Config:
        """Pydantic configuration."""
        extra = "allow"


class WinItSnapshot(BaseModel):
    """WinIt snapshot model."""
    
    snapshot_id: Optional[str] = Field(None, description="Snapshot ID")
    warehouse_code: Optional[str] = Field(None, description="Warehouse code")
    total_skus: Optional[int] = Field(None, description="Total SKUs")
    total_quantity: Optional[int] = Field(None, description="Total quantity")
    created_at: Optional[str] = Field(None, description="Snapshot time")
    
    class Config:
        """Pydantic configuration."""
        extra = "allow"


class InventoryListResponse(BaseModel):
    """Inventory list response model."""
    
    items: List[InventoryItem] = Field(default_factory=list, description="Inventory items")
    total: Optional[int] = Field(None, description="Total number of items")
    page: Optional[int] = Field(None, description="Current page number")
    page_size: Optional[int] = Field(None, description="Page size")
    
    class Config:
        """Pydantic configuration."""
        extra = "allow"


class InventoryAgeListResponse(BaseModel):
    """Inventory age list response model."""
    
    items: List[InventoryAge] = Field(default_factory=list, description="Inventory age items")
    total: Optional[int] = Field(None, description="Total number of items")
    
    class Config:
        """Pydantic configuration."""
        extra = "allow"