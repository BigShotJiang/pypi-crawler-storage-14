"""
Warehouse plans related Pydantic models.
"""

from typing import Optional, List, Dict, Any
from pydantic import BaseModel, Field


class WarehousePlan(BaseModel):
    """Warehouse plan model."""
    
    id: Optional[str] = Field(None, description="Warehouse plan ID")
    plan_no: Optional[str] = Field(None, description="Plan number")
    warehouse_code: Optional[str] = Field(None, description="Warehouse code")
    status: Optional[str] = Field(None, description="Plan status")
    expected_arrival_date: Optional[str] = Field(None, description="Expected arrival date")
    actual_arrival_date: Optional[str] = Field(None, description="Actual arrival date")
    carrier_code: Optional[str] = Field(None, description="Carrier code")
    tracking_number: Optional[str] = Field(None, description="Tracking number")
    created_at: Optional[str] = Field(None, description="Creation time")
    updated_at: Optional[str] = Field(None, description="Last update time")
    
    class Config:
        """Pydantic configuration."""
        extra = "allow"


class WarehousePlanCreate(BaseModel):
    """Warehouse plan creation model."""
    
    warehouse_code: str = Field(..., description="Warehouse code")
    expected_arrival_date: str = Field(..., description="Expected arrival date")
    carrier_code: Optional[str] = Field(None, description="Carrier code")
    tracking_number: Optional[str] = Field(None, description="Tracking number")
    items: Optional[List[Dict[str, Any]]] = Field(default_factory=list, description="Plan items")
    
    class Config:
        """Pydantic configuration."""
        extra = "allow"


class ShippingInfo(BaseModel):
    """Shipping information model."""
    
    plan_id: Optional[str] = Field(None, description="Plan ID")
    carrier_code: Optional[str] = Field(None, description="Carrier code")
    tracking_number: Optional[str] = Field(None, description="Tracking number")
    vessel_name: Optional[str] = Field(None, description="Vessel name")
    voyage_number: Optional[str] = Field(None, description="Voyage number")
    departure_port: Optional[str] = Field(None, description="Departure port")
    arrival_port: Optional[str] = Field(None, description="Arrival port")
    estimated_departure_date: Optional[str] = Field(None, description="Estimated departure date")
    estimated_arrival_date: Optional[str] = Field(None, description="Estimated arrival date")
    
    class Config:
        """Pydantic configuration."""
        extra = "allow"


class ShippingCompany(BaseModel):
    """Shipping company model."""
    
    code: Optional[str] = Field(None, description="Company code")
    name: Optional[str] = Field(None, description="Company name")
    description: Optional[str] = Field(None, description="Company description")
    
    class Config:
        """Pydantic configuration."""
        extra = "allow"


class WarehousePlanListResponse(BaseModel):
    """Warehouse plan list response model."""
    
    items: List[WarehousePlan] = Field(default_factory=list, description="Warehouse plan list")
    total: Optional[int] = Field(None, description="Total number of plans")
    page: Optional[int] = Field(None, description="Current page number")
    page_size: Optional[int] = Field(None, description="Page size")
    
    class Config:
        """Pydantic configuration."""
        extra = "allow"


class WarehousePlanItem(BaseModel):
    """Warehouse plan item model."""
    
    id: Optional[str] = Field(None, description="Item ID")
    plan_id: Optional[str] = Field(None, description="Plan ID")
    sku: Optional[str] = Field(None, description="Product SKU")
    quantity: Optional[int] = Field(None, description="Quantity")
    received_quantity: Optional[int] = Field(None, description="Received quantity")
    status: Optional[str] = Field(None, description="Item status")
    
    class Config:
        """Pydantic configuration."""
        extra = "allow"


class Attachment(BaseModel):
    """Attachment model."""
    
    id: Optional[str] = Field(None, description="Attachment ID")
    filename: Optional[str] = Field(None, description="Filename")
    file_type: Optional[str] = Field(None, description="File type")
    file_size: Optional[int] = Field(None, description="File size")
    upload_time: Optional[str] = Field(None, description="Upload time")
    download_url: Optional[str] = Field(None, description="Download URL")
    
    class Config:
        """Pydantic configuration."""
        extra = "allow"