"""
Product-related Pydantic models.
"""

from typing import Optional, List, Dict, Any
from pydantic import BaseModel, Field


class Product(BaseModel):
    """Product model."""
    
    id: Optional[str] = Field(None, description="Product ID")
    name: Optional[str] = Field(None, description="Product name")
    sku: Optional[str] = Field(None, description="Product SKU")
    price: Optional[float] = Field(None, description="Product price")
    category: Optional[str] = Field(None, description="Product category")
    description: Optional[str] = Field(None, description="Product description")
    weight: Optional[float] = Field(None, description="Product weight")
    dimensions: Optional[Dict[str, float]] = Field(None, description="Product dimensions")
    status: Optional[str] = Field(None, description="Product status")
    created_at: Optional[str] = Field(None, description="Creation time")
    updated_at: Optional[str] = Field(None, description="Last update time")
    
    class Config:
        """Pydantic configuration."""
        extra = "allow"


class ProductCreate(BaseModel):
    """Product creation request model."""
    
    name: str = Field(..., description="Product name")
    sku: str = Field(..., description="Product SKU")
    price: float = Field(..., description="Product price")
    category: Optional[str] = Field(None, description="Product category")
    description: Optional[str] = Field(None, description="Product description")
    weight: Optional[float] = Field(None, description="Product weight")
    dimensions: Optional[Dict[str, float]] = Field(None, description="Product dimensions")
    
    class Config:
        """Pydantic configuration."""
        extra = "allow"


class ProductUpdate(BaseModel):
    """Product update request model."""
    
    name: Optional[str] = Field(None, description="Product name")
    price: Optional[float] = Field(None, description="Product price")
    category: Optional[str] = Field(None, description="Product category")
    description: Optional[str] = Field(None, description="Product description")
    weight: Optional[float] = Field(None, description="Product weight")
    dimensions: Optional[Dict[str, float]] = Field(None, description="Product dimensions")
    status: Optional[str] = Field(None, description="Product status")
    
    class Config:
        """Pydantic configuration."""
        extra = "allow"


class ProductListResponse(BaseModel):
    """Product list response model."""
    
    items: List[Product] = Field(default_factory=list, description="Product list")
    total: Optional[int] = Field(None, description="Total number of products")
    page: Optional[int] = Field(None, description="Current page number")
    page_size: Optional[int] = Field(None, description="Page size")
    
    class Config:
        """Pydantic configuration."""
        extra = "allow"


class ProductIdentificationCode(BaseModel):
    """Product identification code model."""
    
    product_id: Optional[str] = Field(None, description="Product ID")
    code: Optional[str] = Field(None, description="Identification code")
    code_type: Optional[str] = Field(None, description="Code type")
    created_at: Optional[str] = Field(None, description="Creation time")
    
    class Config:
        """Pydantic configuration."""
        extra = "allow"


class ChannelProductRelation(BaseModel):
    """Channel product relation model."""
    
    product_id: Optional[str] = Field(None, description="Product ID")
    channel_code: Optional[str] = Field(None, description="Channel code")
    channel_product_id: Optional[str] = Field(None, description="Channel product ID")
    relation_status: Optional[str] = Field(None, description="Relation status")
    
    class Config:
        """Pydantic configuration."""
        extra = "allow"


class BoxProduct(BaseModel):
    """Box product model."""
    
    id: Optional[str] = Field(None, description="Box product ID")
    parent_sku: Optional[str] = Field(None, description="Parent product SKU")
    child_skus: Optional[List[str]] = Field(default_factory=list, description="Child product SKUs")
    quantity: Optional[int] = Field(None, description="Quantity")
    created_at: Optional[str] = Field(None, description="Creation time")
    
    class Config:
        """Pydantic configuration."""
        extra = "allow"