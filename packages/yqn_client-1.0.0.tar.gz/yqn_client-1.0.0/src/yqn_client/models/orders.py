"""
Orders related Pydantic models.
"""

from typing import Optional, List, Dict, Any
from pydantic import BaseModel, Field


class Order(BaseModel):
    """Order model."""
    
    id: Optional[str] = Field(None, description="Order ID")
    order_no: Optional[str] = Field(None, description="Order number")
    customer_id: Optional[str] = Field(None, description="Customer ID")
    status: Optional[str] = Field(None, description="Order status")
    total_amount: Optional[float] = Field(None, description="Total amount")
    currency: Optional[str] = Field(None, description="Currency")
    created_at: Optional[str] = Field(None, description="Creation time")
    updated_at: Optional[str] = Field(None, description="Last update time")
    
    class Config:
        """Pydantic configuration."""
        extra = "allow"


class OrderItem(BaseModel):
    """Order item model."""
    
    id: Optional[str] = Field(None, description="Item ID")
    order_id: Optional[str] = Field(None, description="Order ID")
    sku: Optional[str] = Field(None, description="Product SKU")
    quantity: Optional[int] = Field(None, description="Quantity")
    price: Optional[float] = Field(None, description="Unit price")
    total_price: Optional[float] = Field(None, description="Total price")
    
    class Config:
        """Pydantic configuration."""
        extra = "allow"


class OrderCreate(BaseModel):
    """Order creation model."""
    
    customer_id: str = Field(..., description="Customer ID")
    items: List[Dict[str, Any]] = Field(..., description="Order items")
    shipping_address: Optional[Dict[str, Any]] = Field(None, description="Shipping address")
    billing_address: Optional[Dict[str, Any]] = Field(None, description="Billing address")
    
    class Config:
        """Pydantic configuration."""
        extra = "allow"


class OrderCalculation(BaseModel):
    """Order calculation model."""
    
    items: List[Dict[str, Any]] = Field(..., description="Order items")
    shipping_address: Optional[Dict[str, Any]] = Field(None, description="Shipping address")
    shipping_method: Optional[str] = Field(None, description="Shipping method")
    
    class Config:
        """Pydantic configuration."""
        extra = "allow"


class OrderListResponse(BaseModel):
    """Order list response model."""
    
    items: List[Order] = Field(default_factory=list, description="Order list")
    total: Optional[int] = Field(None, description="Total number of orders")
    page: Optional[int] = Field(None, description="Current page number")
    page_size: Optional[int] = Field(None, description="Page size")
    
    class Config:
        """Pydantic configuration."""
        extra = "allow"