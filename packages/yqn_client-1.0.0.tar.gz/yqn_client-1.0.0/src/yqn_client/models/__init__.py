"""
Pydantic models for YQN Client API responses and requests.
"""