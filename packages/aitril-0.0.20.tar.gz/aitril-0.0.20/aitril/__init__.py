"""
AiTril - Multi-LLM Orchestration CLI Tool

A neutral, open-source CLI for orchestrating multiple LLM providers
through a single unified interface.
"""

__version__ = "0.0.20"
__author__ = "AiTril Contributors"
__description__ = "Multi-LLM orchestration CLI tool"
