"""
Rohkun MCP Server Module

Model Context Protocol server for Rohkun CLI.
Allows AI assistants to interact with Rohkun automatically.

Status: Pre-implementation planning phase
"""

__version__ = "0.1.0"
