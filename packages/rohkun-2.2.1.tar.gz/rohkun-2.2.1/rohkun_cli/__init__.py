"""
Rohkun CLI v2 - Client-side code analysis tool
"""

__version__ = "2.2.1"
