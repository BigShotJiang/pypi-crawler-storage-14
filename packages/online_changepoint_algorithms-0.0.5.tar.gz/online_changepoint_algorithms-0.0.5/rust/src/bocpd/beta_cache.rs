use pyo3::{pyclass, pymethods};
use statrs::function::beta::beta;
use std::collections::HashMap;

/// Cache for beta function with a fixed value
#[pyclass]
pub struct BetaCache {
    #[pyo3(get)]
    fixed_value: f64,
    cache: HashMap<u64, f64>,
}

#[pymethods]
impl BetaCache {
    #[new]
    pub fn new_py(fixed_value: f64) -> Self {
        Self {
            fixed_value,
            cache: HashMap::new(),
        }
    }

    pub fn get_fixed_value(&self) -> f64 {
        self.fixed_value
    }

    pub fn get_value(&mut self, value: f64) -> f64 {
        let key = value.to_bits();
        // if self.cache.contains_key(&key) {
        //     let value = self
        //         .cache
        //         .get(&key)
        //         .expect("Cache should always have key here since we checked just before.");
        //     *value
        // } else {
        //     // base case
        //     let fixed = self.fixed_value;
        //     let res = match value {
        //         ..0.0 => todo!("does not expect negative numbers. What should we do in this case?"), // beta(steady_x, increase_y), // technically, should throw error
        //         0.0..=1.0 => beta(fixed, value),
        //         1.0.. => (value / (fixed + value)) * beta(fixed, value - 1.0),
        //         _ => todo!("add functionality for other float types."),
        //     };
        //     self.cache.insert(key, res.clone());
        //     res
        // }
        // New attempt
        if let std::collections::hash_map::Entry::Vacant(e) = self.cache.entry(key) {
            let fixed = self.fixed_value;
            let res = match value {
                ..0.0 => todo!("does not expect negative numbers. What should we do in this case?"), // beta(steady_x, increase_y), // technically, should throw error
                0.0.. => beta(fixed, value),
                // 0.0..=1.0 => beta(fixed, value),
                // 1.0.. => {
                //     let q = value - 1.0;
                //     (q / (fixed + q)) * beta(fixed, q) },
                _ => todo!("add functionality for other float types."),
            };
            e.insert(res);
            res
        } else {
            let &value = self.cache.get(&key).expect("Cache should always have key here since we checked just before.");
            value
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::f64::consts::PI;

    #[test]
    fn test_constructor() {
        let cache = BetaCache::new_py(0.5);
        assert_eq!(cache.fixed_value, 0.5);
    }

    fn make_cache() -> BetaCache {
        BetaCache::new_py(0.5)
    }

    #[test]
    fn test_get_value() {
        let mut cache = make_cache();
        let half_key: u64 = (0.5_f64).to_bits();
        assert!(matches!(cache.cache.get(&half_key), None));
        let value = cache.get_value(0.5);
        assert!((value - PI).abs() < 1e-8);
        assert!(matches!(cache.cache.get(&half_key), Some(&x)));
    }

    #[test]
    fn test_first_n_values() {
        let n = 1_000;
        let epsilon: f64 = 1e-8;
        let mut cache = make_cache();
        for i in 1..(2*n + 1) {
            let half = i as f64 / 2.0;
            let correct = beta(0.5, half);
            let value = cache.get_value(half);
            assert!((value - correct).abs() < epsilon, "{}th half value was incorrect. Expected {} but got {}", i, correct, value);
        }
    }
}