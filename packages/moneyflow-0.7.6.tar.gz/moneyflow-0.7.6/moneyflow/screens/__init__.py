"""TUI screens for moneyflow."""
