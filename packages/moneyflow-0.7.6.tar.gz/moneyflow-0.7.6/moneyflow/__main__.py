"""Entry point for python -m moneyflow"""

from .cli import cli

if __name__ == "__main__":
    cli()
