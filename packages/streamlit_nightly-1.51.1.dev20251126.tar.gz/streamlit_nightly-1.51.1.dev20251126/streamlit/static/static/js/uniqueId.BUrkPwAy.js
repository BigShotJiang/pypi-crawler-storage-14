import{F as i}from"./index.Da4PAoVr.js";var n=0;function u(r){var t=++n;return i(r)+t}export{u};
