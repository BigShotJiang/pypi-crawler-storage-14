def add_numbers(num1, num2):
    return num1 + num2
def sub_numbers(num1, num2):
    return num1 - num2
def mul_numbers(num1, num2):
    return num1 * num2
def div_numbers(num1, num2):
    return num1 / num2
def mod_numbers(num1, num2):
    return num1 % num2