from typing import Optional, List
from dataclasses_json import dataclass_json
from dataclasses import dataclass


@dataclass_json
@dataclass
class V4HpfsUpdateLabelRequest:
    sfsUID: str  # 并行文件唯一ID
    regionID: str  # 资源池ID
    labelList: List['V4HpfsUpdateLabelRequestLabelList']  # 标签和相应的操作类型


@dataclass_json
@dataclass
class V4HpfsUpdateLabelRequestLabelList:
    key: str  # 标签键，长度不能超过128个字符，首尾不能为空字符
    value: str  # 标签值，长度不能超过128个字符，首尾不能为空字符
    operateType: str  # 操作类型 绑定 BIND/ 解绑 UNBIND



@dataclass_json
@dataclass
class V4HpfsUpdateLabelResponse:
    statusCode: Optional[int] = None
    error: Optional[str] = None
    message: Optional[str] = None
    description: Optional[str] = None
    errorCode: Optional[str] = None
    returnObj: Optional['V4HpfsUpdateLabelReturnObj'] = None


@dataclass_json
@dataclass
class V4HpfsUpdateLabelReturnObj:
    pass


