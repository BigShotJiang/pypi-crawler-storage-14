from typing import Optional, List
from dataclasses_json import dataclass_json
from dataclasses import dataclass


@dataclass_json
@dataclass
class V4HpfsDataflowQuotaSfsRequest:
    regionID: str  # 资源池 ID
    sfsUID: str  # 并行文件唯一ID



@dataclass_json
@dataclass
class V4HpfsDataflowQuotaSfsResponse:
    statusCode: Optional[int] = None
    error: Optional[str] = None
    message: Optional[str] = None
    description: Optional[str] = None
    errorCode: Optional[str] = None
    returnObj: Optional['V4HpfsDataflowQuotaSfsReturnObj'] = None


@dataclass_json
@dataclass
class V4HpfsDataflowQuotaSfsReturnObj:
    totalDataflowQuota: Optional[int] = None  # 文件系统数据流动策略配额总数
    usedDataflowQuota: Optional[int] = None  # 文件系统已用数据流动策略配额数
    avlDataflowQuota: Optional[int] = None  # 文件系统剩余可用数据流动策略配额数



