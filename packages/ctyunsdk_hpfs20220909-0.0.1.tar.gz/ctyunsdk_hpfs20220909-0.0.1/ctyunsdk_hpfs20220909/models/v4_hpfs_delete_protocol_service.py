from typing import Optional, List
from dataclasses_json import dataclass_json
from dataclasses import dataclass


@dataclass_json
@dataclass
class V4HpfsDeleteProtocolServiceRequest:
    regionID: str  # 资源池 ID
    protocolServiceID: str  # 协议服务唯一ID



@dataclass_json
@dataclass
class V4HpfsDeleteProtocolServiceResponse:
    statusCode: Optional[int] = None
    error: Optional[str] = None
    message: Optional[str] = None
    description: Optional[str] = None
    errorCode: Optional[str] = None
    returnObj: Optional['V4HpfsDeleteProtocolServiceReturnObj'] = None


@dataclass_json
@dataclass
class V4HpfsDeleteProtocolServiceReturnObj:
    regionID: Optional[str] = None  # 资源所属资源池 ID
    resources: Optional[List['V4HpfsDeleteProtocolServiceReturnObjResources']] = None  # 资源明细


@dataclass_json
@dataclass
class V4HpfsDeleteProtocolServiceReturnObjResources:
    sfsUID: Optional[str] = None  # 并行文件唯一 ID
    protocolServiceID: Optional[str] = None  # 协议服务唯一ID



