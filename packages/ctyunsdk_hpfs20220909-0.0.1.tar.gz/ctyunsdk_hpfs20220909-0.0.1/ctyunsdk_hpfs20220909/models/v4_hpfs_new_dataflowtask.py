from typing import Optional, List
from dataclasses_json import dataclass_json
from dataclasses import dataclass


@dataclass_json
@dataclass
class V4HpfsNewDataflowtaskRequest:
    regionID: str  # 资源池 ID
    sfsUID: str  # 并行文件唯一ID
    dataflowID: str  # 数据流动策略ID
    taskType: str  # 数据流动任务类型（目前支持import_data/import_metadata/export_data）
    taskDescription: Optional[str] = None  # 数据流动任务的描述，最高支持128字符



@dataclass_json
@dataclass
class V4HpfsNewDataflowtaskResponse:
    statusCode: Optional[int] = None
    error: Optional[str] = None
    message: Optional[str] = None
    description: Optional[str] = None
    errorCode: Optional[str] = None
    returnObj: Optional['V4HpfsNewDataflowtaskReturnObj'] = None


@dataclass_json
@dataclass
class V4HpfsNewDataflowtaskReturnObj:
    regionID: Optional[str] = None  # 资源所属资源池 ID
    resources: Optional[List['V4HpfsNewDataflowtaskReturnObjResources']] = None  # 资源明细


@dataclass_json
@dataclass
class V4HpfsNewDataflowtaskReturnObjResources:
    dataflowID: Optional[str] = None  # 数据流动策略ID
    sfsUID: Optional[str] = None  # 并行文件唯一ID
    taskID: Optional[str] = None  # 数据流动任务ID



