from typing import Optional, List
from dataclasses_json import dataclass_json
from dataclasses import dataclass


@dataclass_json
@dataclass
class V4HpfsRefundSfsRequest:
    sfsUID: str  # 并行文件唯一ID
    regionID: str  # 资源池 ID
    clientToken: Optional[str] = None  # 客户端存根，用于保证订单幂等性。要求单个云平台账户内唯一



@dataclass_json
@dataclass
class V4HpfsRefundSfsResponse:
    statusCode: Optional[int] = None
    error: Optional[str] = None
    message: Optional[str] = None
    description: Optional[str] = None
    errorCode: Optional[str] = None
    returnObj: Optional['V4HpfsRefundSfsReturnObj'] = None


@dataclass_json
@dataclass
class V4HpfsRefundSfsReturnObj:
    masterOrderID: Optional[str] = None  # 退订订单号，可以使用该订单号确认资源的最终退订状态
    masterOrderNO: Optional[str] = None  # 订单号
    regionID: Optional[str] = None  # 资源所属资源池 ID



