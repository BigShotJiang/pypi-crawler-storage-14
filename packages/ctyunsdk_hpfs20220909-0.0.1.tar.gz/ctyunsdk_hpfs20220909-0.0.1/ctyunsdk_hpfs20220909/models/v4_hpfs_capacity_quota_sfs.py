from typing import Optional, List
from dataclasses_json import dataclass_json
from dataclasses import dataclass


@dataclass_json
@dataclass
class V4HpfsCapacityQuotaSfsRequest:
    regionID: str  # 资源池 ID



@dataclass_json
@dataclass
class V4HpfsCapacityQuotaSfsResponse:
    statusCode: Optional[int] = None
    error: Optional[str] = None
    message: Optional[str] = None
    description: Optional[str] = None
    errorCode: Optional[str] = None
    returnObj: Optional['V4HpfsCapacityQuotaSfsReturnObj'] = None


@dataclass_json
@dataclass
class V4HpfsCapacityQuotaSfsReturnObj:
    totalCapacityQuota: Optional[int] = None  # 总容量配额，单位GB，-1表示无限制
    usedCapacityQuota: Optional[int] = None  # 已使⽤容量配额，单位GB
    avlCapacityQuota: Optional[int] = None  # 剩余容量配额，单位GB，-1表示无限制



