from typing import Optional, List
from dataclasses_json import dataclass_json
from dataclasses import dataclass


@dataclass_json
@dataclass
class V4HpfsRenameSfsRequest:
    regionID: str  # 资源池 ID
    sfsUID: str  # 并行文件唯一ID
    sfsName: str  # 文件系统新名称



@dataclass_json
@dataclass
class V4HpfsRenameSfsResponse:
    statusCode: Optional[int] = None
    error: Optional[str] = None
    message: Optional[str] = None
    description: Optional[str] = None
    errorCode: Optional[str] = None
    returnObj: Optional['V4HpfsRenameSfsReturnObj'] = None


@dataclass_json
@dataclass
class V4HpfsRenameSfsReturnObj:
    pass


