from typing import Optional, List
from dataclasses_json import dataclass_json
from dataclasses import dataclass


@dataclass_json
@dataclass
class V4HpfsListBaselineRequest:
    regionID: str  # 资源池 ID
    sfsType: str  # 类型，hpfs_perf(HPC性能型)
    azName: Optional[str] = None  # 多可用区下的可用区名字，4.0资源池必填
    clusterName: Optional[str] = None  # 集群名称
    pageNo: Optional[int] = None  # 列表的分页页码 ，默认值为1
    pageSize: Optional[int] = None  # 每页包含的元素个数范围(1-50)，默认值为10



@dataclass_json
@dataclass
class V4HpfsListBaselineResponse:
    statusCode: Optional[int] = None
    error: Optional[str] = None
    message: Optional[str] = None
    description: Optional[str] = None
    errorCode: Optional[str] = None
    returnObj: Optional['V4HpfsListBaselineReturnObj'] = None


@dataclass_json
@dataclass
class V4HpfsListBaselineReturnObj:
    baselineList: Optional[List['V4HpfsListBaselineReturnObjBaselineList']] = None  # 返回的性能基线列表
    totalCount: Optional[int] = None  # 指定条件下性能基线总数
    currentCount: Optional[int] = None  # 当前页码下查询回来的基线数
    pageSize: Optional[int] = None  # 每页包含的元素个数范围(1-50)
    pageNo: Optional[int] = None  # 列表的分页页码


@dataclass_json
@dataclass
class V4HpfsListBaselineReturnObjBaselineList:
    baseline: Optional[str] = None  # 性能基线（MB/s/TB）
    storageType: Optional[str] = None  # 支持类型，hpfs_perf(HPC性能型)
    azName: Optional[str] = None  # 多可用区下可用区名称
    clusterNames: Optional[List[str]] = None  # 集群列表



