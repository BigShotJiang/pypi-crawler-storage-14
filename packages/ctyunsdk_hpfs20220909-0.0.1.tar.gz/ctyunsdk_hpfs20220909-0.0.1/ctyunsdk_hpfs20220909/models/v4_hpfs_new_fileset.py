from typing import Optional, List
from dataclasses_json import dataclass_json
from dataclasses import dataclass


@dataclass_json
@dataclass
class V4HpfsNewFilesetRequest:
    regionID: str  # 资源池 ID
    sfsUID: str  # 并行文件唯一ID
    filesetPath: str  # 指定FILESET在文件系统中的绝对路径，路径限制见接口约束
    capacityQuota: int  # FILESET的容量限制，单位：GiB，起步 10 GiB，步长为 1 GiB，最大不超过文件系统可用容量（文件系统可用容量 = 文件系统总容量 - 非FILESET已用容量 - FILESET分配出去的容量）
    fileCountQuota: int  # FILESET的文件数限制，单位：个，起步 1 万个，步长为 1千个，最大不超过文件系统可用文件数量 （文件系统可用文件数量 = 文件系统总文件数量 - 非FILESET已用文件数量 - FILESET分配出去的文件数量）
    filesetDescription: Optional[str] = None  # FILESET的描述，长度为0~128个字符



@dataclass_json
@dataclass
class V4HpfsNewFilesetResponse:
    statusCode: Optional[int] = None
    error: Optional[str] = None
    message: Optional[str] = None
    description: Optional[str] = None
    errorCode: Optional[str] = None
    returnObj: Optional['V4HpfsNewFilesetReturnObj'] = None


@dataclass_json
@dataclass
class V4HpfsNewFilesetReturnObj:
    regionID: Optional[str] = None  # 资源所属资源池 ID
    resources: Optional[List['V4HpfsNewFilesetReturnObjResources']] = None  # 资源明细


@dataclass_json
@dataclass
class V4HpfsNewFilesetReturnObjResources:
    sfsUID: Optional[str] = None  # 并行文件唯一 ID
    filesetID: Optional[str] = None  # FILESET唯一ID



