from typing import Optional, List
from dataclasses_json import dataclass_json
from dataclasses import dataclass


@dataclass_json
@dataclass
class V4HpfsAllocableQuotaSfsRequest:
    regionID: str  # 资源池 ID
    sfsUID: str  # 并行文件唯一ID



@dataclass_json
@dataclass
class V4HpfsAllocableQuotaSfsResponse:
    statusCode: Optional[int] = None
    error: Optional[str] = None
    message: Optional[str] = None
    description: Optional[str] = None
    errorCode: Optional[str] = None
    returnObj: Optional['V4HpfsAllocableQuotaSfsReturnObj'] = None


@dataclass_json
@dataclass
class V4HpfsAllocableQuotaSfsReturnObj:
    sfsUID: Optional[str] = None  # 并行文件唯一ID
    allocableCapacity: Optional[int] = None  # 并行文件可分配容量，单位GB
    allocableFileCount: Optional[int] = None  # 并行文件可分配文件数



