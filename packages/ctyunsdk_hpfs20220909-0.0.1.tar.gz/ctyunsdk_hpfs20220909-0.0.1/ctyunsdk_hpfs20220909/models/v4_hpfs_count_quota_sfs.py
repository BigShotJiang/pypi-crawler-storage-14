from typing import Optional, List
from dataclasses_json import dataclass_json
from dataclasses import dataclass


@dataclass_json
@dataclass
class V4HpfsCountQuotaSfsRequest:
    regionID: str  # 资源池 ID



@dataclass_json
@dataclass
class V4HpfsCountQuotaSfsResponse:
    statusCode: Optional[int] = None
    error: Optional[str] = None
    message: Optional[str] = None
    description: Optional[str] = None
    errorCode: Optional[str] = None
    returnObj: Optional['V4HpfsCountQuotaSfsReturnObj'] = None


@dataclass_json
@dataclass
class V4HpfsCountQuotaSfsReturnObj:
    avlCountQuota: Optional[int] = None  # 可用并行文件配额数量
    usedCountQuota: Optional[int] = None  # 已用并行文件配额数量
    totalCountQuota: Optional[int] = None  # 并行文件配额总数量



