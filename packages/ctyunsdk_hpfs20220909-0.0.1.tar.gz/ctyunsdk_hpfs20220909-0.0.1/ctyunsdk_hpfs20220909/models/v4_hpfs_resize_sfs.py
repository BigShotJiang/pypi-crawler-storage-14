from typing import Optional, List
from dataclasses_json import dataclass_json
from dataclasses import dataclass


@dataclass_json
@dataclass
class V4HpfsResizeSfsRequest:
    sfsSize: int  # 变配后的大小，单位 GB， 起始容量512，步长为512
    sfsUID: str  # 并行文件唯一ID
    regionID: str  # 资源池 ID
    clientToken: Optional[str] = None  # 客户端存根，用于保证订单幂等性。要求单个云平台账户内唯一



@dataclass_json
@dataclass
class V4HpfsResizeSfsResponse:
    statusCode: Optional[int] = None
    error: Optional[str] = None
    message: Optional[str] = None
    description: Optional[str] = None
    errorCode: Optional[str] = None
    returnObj: Optional['V4HpfsResizeSfsReturnObj'] = None


@dataclass_json
@dataclass
class V4HpfsResizeSfsReturnObj:
    masterOrderID: Optional[str] = None  # 订单 ID。调用方在拿到 masterOrderID 之后，在若干错误情况下，可以使用 masterOrderID 进一步确认订单状态及资源状态
    masterOrderNO: Optional[str] = None  # 订单号
    regionID: Optional[str] = None  # 资源所属资源池 ID



