from typing import Optional, List
from dataclasses_json import dataclass_json
from dataclasses import dataclass


@dataclass_json
@dataclass
class V4HpfsListRegionRequest:
    pageSize: Optional[int] = None  # 每页包含的元素个数范围(1-50)，默认值为10
    pageNo: Optional[int] = None  # 列表的分页页码，默认值为1



@dataclass_json
@dataclass
class V4HpfsListRegionResponse:
    statusCode: Optional[int] = None
    error: Optional[str] = None
    message: Optional[str] = None
    description: Optional[str] = None
    errorCode: Optional[str] = None
    returnObj: Optional['V4HpfsListRegionReturnObj'] = None


@dataclass_json
@dataclass
class V4HpfsListRegionReturnObj:
    regionList: Optional[List['V4HpfsListRegionReturnObjRegionList']] = None  # 查询的地域详情列表
    totalCount: Optional[int] = None  # 支持并行文件的地域总数
    currentCount: Optional[int] = None  # 当前页码的元素个数
    pageSize: Optional[int] = None  # 每页个数
    pageNo: Optional[int] = None  # 当前页数


@dataclass_json
@dataclass
class V4HpfsListRegionReturnObjRegionList:
    regionID: Optional[str] = None  # 资源池ID
    regionName: Optional[str] = None  # 资源池名字



