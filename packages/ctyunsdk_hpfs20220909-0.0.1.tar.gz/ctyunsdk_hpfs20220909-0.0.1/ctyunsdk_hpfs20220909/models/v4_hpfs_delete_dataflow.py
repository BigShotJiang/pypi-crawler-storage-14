from typing import Optional, List
from dataclasses_json import dataclass_json
from dataclasses import dataclass


@dataclass_json
@dataclass
class V4HpfsDeleteDataflowRequest:
    regionID: str  # 资源池 ID
    dataflowID: str  # 数据流动策略ID



@dataclass_json
@dataclass
class V4HpfsDeleteDataflowResponse:
    statusCode: Optional[int] = None
    error: Optional[str] = None
    message: Optional[str] = None
    description: Optional[str] = None
    errorCode: Optional[str] = None
    returnObj: Optional['V4HpfsDeleteDataflowReturnObj'] = None


@dataclass_json
@dataclass
class V4HpfsDeleteDataflowReturnObj:
    regionID: Optional[str] = None  # 资源所属资源池 ID



