# Semantico

Ontologia Core - Camada Semântica (Pure Layer 5)

Definição Estrita de Nouns (Objetos), Adjectives (Properties) e Relationships (Links).

## Design Pattern

- Alinhado ao Palantir Foundry Ontology
- Interfaces são Contratos de Dados (Shared Schema)
- Objetos são Active Records inteligentes
- Links são Descritores de Grafo

## Instalação

```bash
uv pip install -e .
```

## Dependências

- `registro>=0.7.0` - Sistema de registro de recursos
- `politipo>=0.5.1` - Sistema de tipos de dados
- `malha>=0.6.0` - Kernel de dados unificado
- `pydantic>=2.12` - Validação de dados

## Desenvolvimento

```bash
# Instalar dependências de desenvolvimento
uv pip install -e ".[dev]"

# Executar testes
pytest --cov=src --cov-report=term-missing

# Linting e formatação
ruff check src tests
black src tests
```

## Licença

MIT
