from .ai_brain import AIBrain
import os
import time
import uuid
import hmac
import hashlib
import requests
import logging
import json
import threading
from datetime import datetime
import numpy as np
from typing import Optional, Dict, Any
import random  # Added missing import

# Configure logging
logging.basicConfig(level=logging.INFO, format="[PnL Watchdog] %(message)s")
logger = logging.getLogger("PnLWatchdog")

# --- IMPORT ADAPTERS ---
# We use try/except here so your code doesn't crash if you haven't
# created the specific Indian/IBKR adapter files yet.
try:
    from .brokers.alpaca import AlpacaAdapter
    from .brokers.ccxt_adapter import CCXTAdapter
    from .brokers.zerodha import ZerodhaAdapter
    from .brokers.angel_one import AngelOneAdapter
    from .brokers.ibkr import IBKRAdapter
except ImportError:
    pass  # Ignore missing adapters for now


# --- RUST CORE IMPORT ---
try:
    import pnl_core
    RUST_CORE_AVAILABLE = True
except ImportError:
    # If the Rust extension isn't built/found, flag it.
    RUST_CORE_AVAILABLE = False
    logger.warning(
        "⚠️ Rust Core (pnl_core) not found. Falling back to Python math (slower, less precise).")


class PnLWatchdog:
    """
    The central Watchdog class.
    Acts as a Factory to load the correct Broker Adapter and AI Brain.
    """

    def __init__(self, broker: str = "alpaca", pro_key: str = None, opt_in: bool = False, **kwargs):
        """
        Initialize the Watchdog.
        :param broker: 'alpaca', 'ibkr', 'binance', 'zerodha', etc.
        :param pro_key: Your PnL Watchdog Pro API Key (for the private dashboard).
        :param opt_in: Set to True to share anonymous latency stats with the Global Map.
        """
        # --- 1. IDENTITY & CONFIG ---
        self.user_id = str(uuid.uuid4())
        self.pro_key = pro_key
        self.opt_in = opt_in
        self.broker_name = broker.lower()

        # Production API URL
        self.api_url = "https://pnl-cloud-backend-4esa.vercel.app/v1"

        self.brain = AIBrain()
        self.adapter = None

        # --- 2. ADAPTER FACTORY (Connects to real brokers) ---
        # Extract common arguments
        api_key = kwargs.get("api_key")
        api_secret = kwargs.get("api_secret")
        paper = kwargs.get("paper", True)

        try:
            if self.broker_name == "alpaca":
                self.adapter = AlpacaAdapter(api_key, api_secret, paper)
            elif self.broker_name == "zerodha":
                self.adapter = ZerodhaAdapter(
                    api_key, kwargs.get("access_token"))
            elif self.broker_name == "angel":
                self.adapter = AngelOneAdapter(
                    api_key,
                    kwargs.get("client_code"),
                    kwargs.get("password"),
                    kwargs.get("totp")
                )
            elif self.broker_name == "ibkr":
                self.adapter = IBKRAdapter(
                    host=kwargs.get("host", '127.0.0.1'),
                    port=kwargs.get("port", 7497)
                )
            elif self.broker_name == "test_mode":  # New mode for stress testing
                self.adapter = None
            else:
                # Default to CCXT for crypto (Binance, etc.)
                self.adapter = CCXTAdapter(
                    self.broker_name, api_key, api_secret, paper)
        except Exception as e:
            logger.warning(
                f"⚠️ Broker Adapter not initialized: {e}. (Whale View will be simulated)")

        # --- 3. WELCOME MESSAGE ---
        print("\n" + "-" * 60)
        print(f"🐶 PnL Watchdog Active.")
        print(f"🆔 YOUR USER ID: {self.user_id}")
        print(f"📋 (Copy this ID to claim your Founding Member status)")
        print("-" * 60 + "\n")

    def check_order(self, symbol, side, qty, price=None):
        """
        Main entry point. Verifies execution and reports latency.
        """
        start_time = time.time()
        logger.info(
            f"🔎 Verifying {side.upper()} {qty} {symbol} on {self.broker_name}...")

        # In a real scenario, we would use self.adapter.get_recent_orders() here
        # For now, we measure the check latency itself
        latency = int((time.time() - start_time) * 1000)

        # --- TELEMETRY (Non-blocking) ---
        if self.pro_key:
            # Pro users send full logs to their private dashboard
            threading.Thread(target=self._upload_log, args=({
                "symbol": symbol, "side": side, "qty": qty,
                "broker": self.broker_name, "latency_ms": latency,
                "slippage": 0.0, "status": "verified"
            },)).start()

        elif self.opt_in:
            # Free users send anonymous stats to the public map
            threading.Thread(target=self._upload_telemetry, args=({
                "symbol": symbol,  # Will be hashed
                "broker": self.broker_name,
                "latency_ms": latency,
                "slippage": 0.0,
                "status": "verified"
            },)).start()

        return {"status": "verified", "latency_ms": latency}

    def get_smart_route(self, symbol, size=1.0, urgency="normal"):
        """
        v0.4.0: The Oracle. Asks the cloud for the safest broker routing.
        """
        if not self.pro_key:
            logger.warning("⚠️ Oracle API requires a Pro Key.")
            return None

        try:
            headers = {"x-pro-key": self.pro_key}
            payload = {"symbol": symbol, "size": size, "urgency": urgency}

            resp = requests.post(
                f"{self.api_url}/oracle/route", json=payload, headers=headers, timeout=2)

            if resp.status_code == 200:
                data = resp.json()
                rec = data.get("recommendation")
                logger.info(
                    f"🔮 Oracle Recommendation: {rec.upper()} (Score: {data['metrics']['expected_latency']}ms)")
                return data
            else:
                logger.warning(f"Oracle Error: {resp.text}")
                return None
        except Exception as e:
            logger.error(f"Failed to reach Oracle: {e}")
            return None

    def _calculate_python_fallback(self, opens, closes, volumes):
        """Python implementation of Market Quality Metrics for Rust fallback."""
        returns_abs = []
        dollar_vols = []
        price_changes = []
        signed_vols = []
        buy_vol = 0.0
        sell_vol = 0.0

        for o, c, v in zip(opens, closes, volumes):
            if v <= 0.0:
                continue

            # Amihud
            ret = (c - o) / o
            dollar_vol = c * v
            returns_abs.append(abs(ret))
            dollar_vols.append(dollar_vol)

            # Kyle's Lambda & Imbalance
            sign = 1 if c >= o else -1
            if sign > 0:
                buy_vol += v
            else:
                sell_vol += v

            price_changes.append(c - o)
            signed_vols.append(v * sign)

        # Amihud Calculation
        amihud_score = 0.0
        if dollar_vols:
            sum_ratio = sum(r / v for r, v in zip(returns_abs, dollar_vols))
            amihud_score = (sum_ratio / len(dollar_vols)) * 1_000_000.0

        # Kyle's Lambda Calculation
        kyles_lambda = 0.0
        if len(signed_vols) > 1:
            try:
                # Use numpy for polyfit (Linear Regression slope)
                slope, _ = np.polyfit(signed_vols, price_changes, 1)
                kyles_lambda = slope * 1_000_000.0
            except np.linalg.LinAlgError:
                # Handle singular matrix error if all volumes are the same
                kyles_lambda = 0.0

        # Imbalance Calculation
        total_vol = buy_vol + sell_vol
        imbalance = (buy_vol - sell_vol) / \
            total_vol if total_vol > 0.0 else 0.0

        return amihud_score, kyles_lambda, imbalance

    def get_whale_view(self, symbol, lookback_candles=100, candles=None):
        """
        v0.5.0: The Whale Engine. Calculates Amihud & Kyle's Lambda using Rust or Python fallback.
        """
        # 1. Get Data (Prefer injected candles, then adapter, then fail)
        data = []
        if candles:
            data = candles
        elif self.adapter and hasattr(self.adapter, 'get_candles'):
            data = self.adapter.get_candles(symbol, lookback_candles)

        if not data:
            return {"error": "No candle data. Connect a broker or pass 'candles' list.", "verdict": "No Data"}

        # 2. Extract Data arrays
        opens = [c['open'] for c in data]
        closes = [c['close'] for c in data]
        volumes = [c['volume'] for c in data]

        amihud_score = 0.0
        kyles_lambda = 0.0
        imbalance = 0.0

        # 3. Process Metrics (Use Rust if available, otherwise fallback)
        if RUST_CORE_AVAILABLE:
            try:
                # Call Rust function with vectors of primitives
                amihud_score, kyles_lambda, imbalance = pnl_core.calculate_market_quality_metrics(
                    opens, closes, volumes
                )
            except Exception as e:
                logger.error(
                    f"Rust Core calculation failed: {e}. Falling back to Python.")
                amihud_score, kyles_lambda, imbalance = self._calculate_python_fallback(
                    opens, closes, volumes)
        else:
            amihud_score, kyles_lambda, imbalance = self._calculate_python_fallback(
                opens, closes, volumes)

        return {
            "symbol": symbol,
            "amihud_illiquidity": round(amihud_score, 4),
            "kyles_lambda": round(kyles_lambda, 6),
            "order_flow_imbalance": round(imbalance, 4),
            "verdict": "TOXIC ORDER FLOW" if kyles_lambda > 1.0 else "Healthy"
        }

    def generate_execution_passport(self, symbol: str, side: str, qty: float) -> Dict[str, Any]:
        """
        Pillar 2: The Execution Passport. Generates a forensic audit trail.
        """
        audit_start = time.time()
        audit_nanos = 0
        if RUST_CORE_AVAILABLE:
            try:
                # Use Rust for nanosecond-precision timestamp
                audit_nanos = pnl_core.get_audit_timestamp()
            except Exception:
                # Fallback to standard Python timestamp
                pass

        # If Rust nanosecond timestamp failed or wasn't available, use Python microsecond
        if audit_nanos == 0:
            # Fallback to python time in nanoseconds (less precise, but better than nothing)
            audit_nanos = int(audit_start * 1_000_000_000)

        # Simulate other micro-timing data points (these would come from broker adapter)
        network_latency_ns = random.randint(100_000, 500_000)  # 0.1ms to 0.5ms

        passport = {
            "audit_id": str(uuid.uuid4()),
            "symbol": symbol,
            "side": side,
            "qty": qty,
            "timestamp_ns": audit_nanos,  # Forensic timestamp
            "execution_metrics": {
                "broker_queue_latency_ns": network_latency_ns,
                "mid_price_snapshot": 100.05,
                "adverse_selection_flag": network_latency_ns > 400_000
            }
        }

        logger.info(
            f"🔎 AUDIT START: {side.upper()} {qty} {symbol} on {self.broker_name}")
        return passport

    def _sanitize_payload(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """
        PRIVACY SHIELD: Strips sensitive alpha before upload.
        """
        # Hash the symbol to protect strategy
        encrypted_symbol = "unknown"
        if 'symbol' in data:
            encrypted_symbol = hashlib.sha256(
                data['symbol'].encode()).hexdigest()

        return {
            "symbol_hash": encrypted_symbol,
            "broker": data.get('broker', 'unknown'),
            "latency_ms": data.get('latency_ms', 0),
            "slippage": data.get('slippage', 0.0),
            "status": data.get('status', 'unknown')
            # NOTE: Side, Qty, Price are deliberately excluded
        }

    def _upload_log(self, data):
        """Sends PRIVATE data to your SaaS backend (Pro Users)"""
        try:
            headers = {"x-pro-key": self.pro_key}
            requests.post(f"{self.api_url}/log_trade",
                          json=data, headers=headers, timeout=2)
        except Exception as e:
            print(f"⚠️ Cloud Sync Failed: {e}")

    def _upload_telemetry(self, data):
        """Sends ANONYMOUS health stats to the global map (Free Users)"""
        try:
            safe_data = self._sanitize_payload(data)
            # Ensure slippage is included as per the telemetry model
            requests.post(f"{self.api_url}/telemetry", json={
                "broker": safe_data.get('broker'),
                "latency_ms": safe_data.get('latency_ms'),
                "slippage": safe_data.get('slippage'),
                "status": safe_data.get('status'),
            }, timeout=2)
        except Exception:
            pass
