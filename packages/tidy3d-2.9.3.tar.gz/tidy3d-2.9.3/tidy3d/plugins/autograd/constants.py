from __future__ import annotations

BETA_DEFAULT = 1.0
ETA_DEFAULT = 0.5
