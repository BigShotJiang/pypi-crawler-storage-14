"""preserve from tidy3d.web.environment import Env backward compatibility"""

from __future__ import annotations

from .core.environment import Env

__all__ = ["Env"]
