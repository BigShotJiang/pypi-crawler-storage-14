"""Local caches."""

from __future__ import annotations

FOLDER_CACHE = {}
S3_STS_TOKENS = {}
