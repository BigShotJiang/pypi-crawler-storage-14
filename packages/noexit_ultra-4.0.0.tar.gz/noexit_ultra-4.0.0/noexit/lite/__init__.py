from .patches import apply_exit_patches

def activate_noexit_lite():
    apply_exit_patches()
    print("🛡️ NoExit Lite Activated (Exit protection only)")
