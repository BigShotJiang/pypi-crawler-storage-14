# Auto activate UltraSafe NoExit
from .core.engine import activate_noexit

activate_noexit()
