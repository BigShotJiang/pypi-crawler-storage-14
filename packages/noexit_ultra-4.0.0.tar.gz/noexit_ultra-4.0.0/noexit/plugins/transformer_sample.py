from .registry import register

def sample_transform(context):
    if "exit" in context.get("source", ""):
        context["source"] = context["source"].replace("exit(", "print(")

register(sample_transform)
