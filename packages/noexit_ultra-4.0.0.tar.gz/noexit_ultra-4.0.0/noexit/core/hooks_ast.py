import ast

class ASTExitRewriter(ast.NodeTransformer):
    def visit_Call(self, node):
        if isinstance(node.func, ast.Name) and node.func.id in ("exit", "quit"):
            node.func.id = "print"
        return self.generic_visit(node)


def patch_ast_source(source):
    try:
        tree = ast.parse(source)
        tree = ASTExitRewriter().visit(tree)
        ast.fix_missing_locations(tree)
        return compile(tree, "<noexit-ast>", "exec")
    except:
        return compile(source, "<noexit-raw>", "exec")
