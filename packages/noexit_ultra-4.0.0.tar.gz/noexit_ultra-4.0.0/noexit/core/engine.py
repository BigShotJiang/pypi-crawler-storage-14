from .config import CONFIG
from .hooks_exit_funcs import apply_exit_patches
from .hooks_exec import apply_exec_hooks
from .hooks_import import NoExitFinder
from ..plugins.registry import run_all
import sys

def activate_noexit():
    if CONFIG["patch_builtin_exit"]:
        apply_exit_patches()
    if CONFIG["patch_exec"]:
        apply_exec_hooks()
    if CONFIG["patch_imports"]:
        sys.meta_path.insert(0, NoExitFinder())
    if CONFIG["enable_plugins"]:
        run_all({"event": "startup"})
    print("🛡️ NoExit v4 Activated (Ultra Enhanced)")
