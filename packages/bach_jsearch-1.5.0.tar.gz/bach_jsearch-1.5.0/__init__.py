"""MCP Server for Jsearch"""
