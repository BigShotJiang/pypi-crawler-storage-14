"""Custom exceptions for sangreal-db library."""


class SangrealDBError(Exception):
    """Base exception class for all sangreal-db related errors."""
    pass


class TableReflectionError(SangrealDBError):
    """Raised when table reflection fails."""
    pass


class TableNotFoundError(TableReflectionError):
    """Raised when a requested table is not found in the database."""
    pass


class PrimaryKeyError(TableReflectionError):
    """Raised when a table lacks a primary key for ORM mapping."""
    pass


class DatabaseConnectionError(SangrealDBError):
    """Raised when database connection or authentication fails."""
    pass


class InsertStrategyError(SangrealDBError):
    """Raised when database-specific insert strategy fails."""
    pass


class ValidationError(SangrealDBError):
    """Raised when input validation fails."""
    pass