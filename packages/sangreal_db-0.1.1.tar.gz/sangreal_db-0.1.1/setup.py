"""Setup configuration for sangreal-db with improved dependencies and metadata."""
import os
from setuptools import setup, find_packages

setup(
    name='sangreal_db',
    version='0.1.1',  # Updated version for the refactored architecture
    description='Easy-to-use ORM for database operations with lazy table reflection',
    long_description=open('README.md', encoding='utf-8').read() if os.path.exists('README.md') else None,
    long_description_content_type='text/markdown',
    install_requires=[
        'sqlalchemy >= 2.0, < 3.0',
        'pandas >= 1.3.0, < 3.0',  # Removed restrictive upper bound, added lower bound
    ],
    extras_require={
        'dev': [
            'pytest >= 7.0',
            'pytest-cov >= 4.0',
            'black >= 22.0',
            'flake8 >= 5.0',
            'mypy >= 1.0',
        ],
    },
    python_requires='>=3.8',  # Updated minimum Python version
    author='liubola',
    author_email='lby3523@gmail.com',
    maintainer='liubola',
    maintainer_email='lby3523@gmail.com',
    license='GNU General Public License v3.0',
    packages=find_packages(),
    platforms=["all"],
    url='https://github.com/liubola/sangreal-db',
    project_urls={
        'Bug Reports': 'https://github.com/liubola/sangreal-db/issues',
        'Source': 'https://github.com/liubola/sangreal-db',
        'Documentation': 'https://github.com/liubola/sangreal-db/blob/main/README.md',
    },
    classifiers=[
        'Development Status :: 4 - Beta',
        'Operating System :: OS Independent',
        'Intended Audience :: Developers',
        'Intended Audience :: Information Technology',
        'License :: OSI Approved :: GNU General Public License v3 (GPLv3)',
        'Programming Language :: Python :: 3',
        'Programming Language :: Python :: 3.8',
        'Programming Language :: Python :: 3.9',
        'Programming Language :: Python :: 3.10',
        'Programming Language :: Python :: 3.11',
        'Programming Language :: Python :: 3.12',
        'Topic :: Database',
        'Topic :: Software Development :: Libraries :: Python Modules',
        'Topic :: Database :: Database Engines/Servers',
        'Framework :: Jupyter',
    ],
    keywords=[
        'database', 'orm', 'sqlalchemy', 'pandas', 'data-analysis',
        'interactive', 'lazy-loading', 'mysql', 'sqlite', 'postgresql',
        'oracle', 'sql-server'
    ],
    include_package_data=True,
    zip_safe=False,
)
