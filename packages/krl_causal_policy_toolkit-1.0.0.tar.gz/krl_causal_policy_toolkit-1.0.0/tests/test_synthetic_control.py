# ----------------------------------------------------------------------
# © 2025 KR-Labs. All rights reserved.
# KR-Labs™ is a trademark of Quipu Research Labs, LLC,
# a subsidiary of Sudiata Giddasira, Inc.
# ----------------------------------------------------------------------
# SPDX-License-Identifier: Apache-2.0

"""
Tests for Synthetic Control Method estimator.
"""

import numpy as np
import pandas as pd
import pytest

from krl_policy.core.base import (
    CausalEstimate,
    DataValidationError,
    EffectType,
    EstimationMethod,
)
from krl_policy.estimators.synthetic_control import (
    PlaceboResult,
    SyntheticControlMethod,
    SyntheticControlResult,
)

# =============================================================================
# Fixtures
# =============================================================================


@pytest.fixture
def scm_panel_data():
    """Create panel data for synthetic control."""
    np.random.seed(42)

    n_units = 10
    n_periods = 20
    treatment_time = 10
    true_effect = 5.0
    treated_unit = 0

    # Create panel
    units = np.repeat(np.arange(n_units), n_periods)
    times = np.tile(np.arange(n_periods), n_units)

    # Generate unit-specific trends
    unit_trends = np.random.normal(0, 0.5, n_units)
    unit_levels = np.random.normal(10, 2, n_units)

    # Generate outcomes
    outcomes = []
    for i in range(len(units)):
        u = units[i]
        t = times[i]

        # Base outcome: unit level + time trend + noise
        y = unit_levels[u] + unit_trends[u] * t + np.random.normal(0, 1)

        # Add treatment effect to treated unit post-treatment
        if u == treated_unit and t >= treatment_time:
            y += true_effect

        outcomes.append(y)

    # Create unit names
    unit_names = [f"Unit_{i}" for i in range(n_units)]

    return (
        pd.DataFrame(
            {
                "unit": [unit_names[u] for u in units],
                "time": times,
                "outcome": outcomes,
            }
        ),
        f"Unit_{treated_unit}",
        treatment_time,
        true_effect,
    )


@pytest.fixture
def scm_data_with_covariates(scm_panel_data):
    """Add covariates to SCM data."""
    data, treated_unit, treatment_time, true_effect = scm_panel_data

    np.random.seed(42)
    data["covariate1"] = np.random.normal(5, 1, len(data))
    data["covariate2"] = np.random.normal(10, 2, len(data))

    return data, treated_unit, treatment_time, true_effect


# =============================================================================
# Test SyntheticControlMethod
# =============================================================================


class TestSyntheticControlMethod:
    """Tests for SyntheticControlMethod estimator."""

    def test_init(self):
        """Test SCM initialization."""
        scm = SyntheticControlMethod(
            treated_unit="California",
            outcome_col="outcome",
            time_col="year",
            unit_col="state",
            treatment_time=1989,
        )

        assert scm.treated_unit == "California"
        assert scm.treatment_time == 1989
        assert not scm.is_fitted

    def test_fit_basic(self, scm_panel_data):
        """Test basic SCM fitting."""
        data, treated_unit, treatment_time, true_effect = scm_panel_data

        scm = SyntheticControlMethod(
            treated_unit=treated_unit,
            outcome_col="outcome",
            time_col="time",
            unit_col="unit",
            treatment_time=treatment_time,
            n_bootstrap=50,
            random_state=42,
        )

        result = scm.fit(data)

        assert scm.is_fitted
        assert result is not None
        assert isinstance(result.ate, CausalEstimate)

        # Check estimate is in reasonable range
        assert abs(result.ate.estimate - true_effect) < 3.0

        # Check method
        assert result.method == EstimationMethod.SCM

    def test_get_weights(self, scm_panel_data):
        """Test getting donor weights."""
        data, treated_unit, treatment_time, true_effect = scm_panel_data

        scm = SyntheticControlMethod(
            treated_unit=treated_unit,
            outcome_col="outcome",
            time_col="time",
            unit_col="unit",
            treatment_time=treatment_time,
            n_bootstrap=50,
            random_state=42,
        )

        scm.fit(data)
        weights = scm.get_weights()

        assert isinstance(weights, pd.Series)
        assert len(weights) > 0

        # Weights should sum to approximately 1
        assert abs(weights.sum() - 1.0) < 0.01

        # All weights should be non-negative
        assert (weights >= -0.01).all()

    def test_get_gaps(self, scm_panel_data):
        """Test getting treatment gaps."""
        data, treated_unit, treatment_time, true_effect = scm_panel_data

        scm = SyntheticControlMethod(
            treated_unit=treated_unit,
            outcome_col="outcome",
            time_col="time",
            unit_col="unit",
            treatment_time=treatment_time,
            n_bootstrap=50,
            random_state=42,
        )

        scm.fit(data)
        gaps = scm.get_gaps()

        assert isinstance(gaps, pd.Series)
        assert len(gaps) > 0

        # Post-treatment gaps should be approximately true_effect
        post_gaps = gaps[gaps.index >= treatment_time]
        assert len(post_gaps) > 0

    def test_placebo_test(self, scm_panel_data):
        """Test placebo test."""
        data, treated_unit, treatment_time, true_effect = scm_panel_data

        scm = SyntheticControlMethod(
            treated_unit=treated_unit,
            outcome_col="outcome",
            time_col="time",
            unit_col="unit",
            treatment_time=treatment_time,
            n_bootstrap=20,
            random_state=42,
        )

        scm.fit(data)
        placebo_result = scm.placebo_test(in_space=True)

        assert isinstance(placebo_result, PlaceboResult)
        assert placebo_result.n_placebos > 0
        assert 0 <= placebo_result.p_value <= 1

    def test_estimate_ate(self, scm_panel_data):
        """Test estimate_ate method."""
        data, treated_unit, treatment_time, true_effect = scm_panel_data

        scm = SyntheticControlMethod(
            treated_unit=treated_unit,
            outcome_col="outcome",
            time_col="time",
            unit_col="unit",
            treatment_time=treatment_time,
            n_bootstrap=50,
            random_state=42,
        )

        scm.fit(data)
        ate = scm.estimate_ate()

        assert isinstance(ate, CausalEstimate)
        assert ate.effect_type == EffectType.ATT

    def test_with_covariates(self, scm_data_with_covariates):
        """Test SCM with covariates."""
        data, treated_unit, treatment_time, true_effect = scm_data_with_covariates

        scm = SyntheticControlMethod(
            treated_unit=treated_unit,
            outcome_col="outcome",
            time_col="time",
            unit_col="unit",
            treatment_time=treatment_time,
            covariates=["covariate1", "covariate2"],
            n_bootstrap=50,
            random_state=42,
        )

        result = scm.fit(data)

        assert scm.is_fitted
        assert result is not None

    def test_specified_donor_pool(self, scm_panel_data):
        """Test SCM with specified donor pool."""
        data, treated_unit, treatment_time, true_effect = scm_panel_data

        # Specify only some donors
        donor_pool = ["Unit_1", "Unit_2", "Unit_3"]

        scm = SyntheticControlMethod(
            treated_unit=treated_unit,
            outcome_col="outcome",
            time_col="time",
            unit_col="unit",
            treatment_time=treatment_time,
            donor_pool=donor_pool,
            n_bootstrap=50,
            random_state=42,
        )

        scm.fit(data)
        weights = scm.get_weights()

        # Only specified donors should have weights
        assert all(d in donor_pool for d in weights[weights > 0.01].index)

    def test_missing_treated_unit(self, scm_panel_data):
        """Test error when treated unit not in data."""
        data, _, treatment_time, _ = scm_panel_data

        scm = SyntheticControlMethod(
            treated_unit="NonExistent",
            outcome_col="outcome",
            time_col="time",
            unit_col="unit",
            treatment_time=treatment_time,
        )

        with pytest.raises(DataValidationError, match="Treated unit"):
            scm.fit(data)

    def test_insufficient_donors(self, scm_panel_data):
        """Test error with insufficient donors."""
        data, treated_unit, treatment_time, _ = scm_panel_data

        # Keep only treated unit and one donor
        data_small = data[data["unit"].isin([treated_unit, "Unit_1"])]

        scm = SyntheticControlMethod(
            treated_unit=treated_unit,
            outcome_col="outcome",
            time_col="time",
            unit_col="unit",
            treatment_time=treatment_time,
        )

        with pytest.raises(DataValidationError, match="at least 2 donor"):
            scm.fit(data_small)


class TestPlaceboResult:
    """Tests for PlaceboResult dataclass."""

    def test_placebo_result_creation(self):
        """Test PlaceboResult creation."""
        result = PlaceboResult(
            placebo_effects={"Unit_1": 1.0, "Unit_2": -0.5},
            placebo_rmspe_ratios={"Unit_1": 2.0, "Unit_2": 1.5},
            p_value=0.1,
            rank=1,
            n_placebos=2,
        )

        assert result.p_value == 0.1
        assert result.n_placebos == 2
        assert len(result.placebo_effects) == 2
