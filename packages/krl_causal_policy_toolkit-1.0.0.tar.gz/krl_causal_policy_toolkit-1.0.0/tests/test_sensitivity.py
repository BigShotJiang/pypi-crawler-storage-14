# Copyright (c) 2024 Sudiata Giddasira, Inc. d/b/a Quipu Research Labs, LLC d/b/a KR-Labs™
# SPDX-License-Identifier: MIT
#
# Khipu Research Analytics Suite - KR-Labs™
# Commercial Use: Contact KR-Labs™ for licensing terms

"""
Tests for sensitivity analysis module.
"""

from unittest.mock import Mock

import numpy as np
import pandas as pd
import pytest

from krl_policy.analysis.sensitivity import (
    EValue,
    PlaceboTest,
    RosenbaumBounds,
    SensitivityAnalyzer,
    SpecificationCurve,
)
from krl_policy.core.base import CausalEstimate, EffectType


class TestRosenbaumBounds:
    """Tests for Rosenbaum bounds analysis."""

    @pytest.fixture
    def matched_effects(self):
        """Create synthetic matched pair treatment effects."""
        np.random.seed(42)
        # Positive treatment effects with some noise
        effects = np.random.normal(2.0, 1.0, 50)
        return effects

    def test_rosenbaum_init(self):
        """Test Rosenbaum bounds initialization."""
        rb = RosenbaumBounds(gamma_range=(1.0, 2.5), n_gamma=15)

        assert rb.gamma_range == (1.0, 2.5)
        assert rb.n_gamma == 15
        assert rb.significance_level == 0.05

    def test_rosenbaum_analyze(self, matched_effects):
        """Test Rosenbaum bounds analysis."""
        rb = RosenbaumBounds()
        result = rb.analyze(matched_effects)

        assert hasattr(result, "gamma_values")
        assert hasattr(result, "p_values_upper")
        assert hasattr(result, "p_values_lower")
        assert hasattr(result, "critical_gamma")

        # Check dimensions
        assert len(result.gamma_values) == 20
        assert len(result.p_values_upper) == 20
        assert len(result.p_values_lower) == 20

        # P-values should increase with Gamma
        assert np.all(np.diff(result.p_values_upper) >= -1e-10)  # Allow small numerical errors

        # Critical gamma should be in range
        assert result.gamma_values[0] <= result.critical_gamma <= result.gamma_values[-1]

    def test_rosenbaum_summary(self, matched_effects):
        """Test Rosenbaum bounds summary generation."""
        rb = RosenbaumBounds()
        result = rb.analyze(matched_effects)
        summary = result.summary()

        assert isinstance(summary, str)
        assert "Rosenbaum Bounds" in summary
        assert "Critical Gamma" in summary
        assert str(result.critical_gamma) in summary


class TestEValue:
    """Tests for E-value calculation."""

    def test_evalue_init(self):
        """Test E-value initialization."""
        ev = EValue()
        assert ev is not None

    def test_evalue_calculate(self):
        """Test E-value calculation."""
        ev = EValue()

        # Risk ratio of 2.0
        result = ev.calculate(estimate=2.0, ci_lower=1.5, ci_upper=2.8, std_error=0.3)

        assert hasattr(result, "e_value")
        assert hasattr(result, "e_value_ci")
        assert result.e_value > 1.0
        assert result.e_value_ci > 1.0
        assert result.estimate == 2.0
        assert result.ci_lower == 1.5
        assert result.ci_upper == 2.8

    def test_evalue_null_effect(self):
        """Test E-value for null effect."""
        ev = EValue()

        result = ev.calculate(estimate=1.0, ci_lower=0.8, ci_upper=1.2)

        # E-value for null should be 1
        assert result.e_value == 1.0

    def test_evalue_protective_effect(self):
        """Test E-value for protective effect (RR < 1)."""
        ev = EValue()

        result = ev.calculate(estimate=0.5, ci_lower=0.3, ci_upper=0.7)

        assert result.e_value > 1.0

    def test_evalue_summary(self):
        """Test E-value summary generation."""
        ev = EValue()
        result = ev.calculate(estimate=2.0, ci_lower=1.5, ci_upper=2.8)
        summary = result.summary()

        assert isinstance(summary, str)
        assert "E-Value" in summary
        assert str(round(result.e_value, 3)) in summary


class TestSpecificationCurve:
    """Tests for specification curve analysis."""

    @pytest.fixture
    def mock_data(self):
        """Create mock data."""
        np.random.seed(42)
        n = 200
        return pd.DataFrame(
            {
                "treatment": np.random.binomial(1, 0.5, n),
                "outcome": np.random.normal(10, 2, n),
                "x1": np.random.normal(0, 1, n),
                "x2": np.random.normal(0, 1, n),
            }
        )

    @pytest.fixture
    def mock_estimator(self):
        """Create mock estimator function."""

        def estimator_fn(data, spec):
            # Simulate estimation with variation based on spec
            base_effect = 2.0
            variation = np.random.normal(0, 0.2)

            return CausalEstimate(
                estimate=base_effect + variation,
                std_error=0.3,
                ci_lower=base_effect + variation - 0.6,
                ci_upper=base_effect + variation + 0.6,
                p_value=0.001,
                effect_type=EffectType.ATE,
            )

        return estimator_fn

    def test_spec_curve_init(self, mock_estimator):
        """Test specification curve initialization."""
        sc = SpecificationCurve(estimator_fn=mock_estimator)

        assert sc.estimator_fn == mock_estimator
        assert sc.confidence_level == 0.95

    def test_spec_curve_analyze(self, mock_data, mock_estimator):
        """Test specification curve analysis."""
        specs = [
            {"covariates": ["x1"]},
            {"covariates": ["x2"]},
            {"covariates": ["x1", "x2"]},
            {"covariates": []},
        ]

        sc = SpecificationCurve(estimator_fn=mock_estimator)
        result = sc.analyze(mock_data, specs)

        assert hasattr(result, "specifications")
        assert hasattr(result, "estimates")
        assert hasattr(result, "median_estimate")
        assert hasattr(result, "iqr_estimate")
        assert hasattr(result, "proportion_significant")

        assert len(result.estimates) == 4
        assert len(result.std_errors) == 4
        assert len(result.p_values) == 4

    def test_spec_curve_summary(self, mock_data, mock_estimator):
        """Test specification curve summary."""
        specs = [{"covariates": ["x1"]}, {"covariates": ["x2"]}]

        sc = SpecificationCurve(estimator_fn=mock_estimator)
        result = sc.analyze(mock_data, specs)
        summary = result.summary()

        assert isinstance(summary, str)
        assert "Specification Curve" in summary
        assert str(len(specs)) in summary


class TestPlaceboTest:
    """Tests for placebo tests."""

    @pytest.fixture
    def mock_data(self):
        """Create mock data with placebo outcomes."""
        np.random.seed(42)
        n = 100
        return pd.DataFrame(
            {
                "treatment": np.random.binomial(1, 0.5, n),
                "outcome": np.random.normal(10, 2, n),
                "placebo1": np.random.normal(5, 1, n),
                "placebo2": np.random.normal(8, 1.5, n),
            }
        )

    @pytest.fixture
    def mock_estimator(self):
        """Create mock estimator."""

        def estimator_fn(data):
            return CausalEstimate(
                estimate=2.0,
                std_error=0.3,
                ci_lower=1.4,
                ci_upper=2.6,
                p_value=0.001,
                effect_type=EffectType.ATE,
            )

        return estimator_fn

    def test_placebo_init(self, mock_estimator):
        """Test placebo test initialization."""
        pt = PlaceboTest(estimator_fn=mock_estimator, n_permutations=500)

        assert pt.estimator_fn == mock_estimator
        assert pt.n_permutations == 500

    def test_permutation_test(self, mock_data, mock_estimator):
        """Test permutation-based placebo test."""
        pt = PlaceboTest(estimator_fn=mock_estimator, n_permutations=50)
        result = pt.run_permutation_test(mock_data, "treatment")

        assert hasattr(result, "placebo_estimates")
        assert hasattr(result, "primary_estimate")
        assert hasattr(result, "p_value")
        assert hasattr(result, "proportion_larger")

        # Should have run permutations
        assert len(result.placebo_estimates) <= 50  # Some may fail
        assert 0 <= result.p_value <= 1
        assert 0 <= result.proportion_larger <= 1

    def test_placebo_summary(self, mock_data, mock_estimator):
        """Test placebo test summary."""
        pt = PlaceboTest(estimator_fn=mock_estimator, n_permutations=20)
        result = pt.run_permutation_test(mock_data, "treatment")
        summary = result.summary()

        assert isinstance(summary, str)
        assert "Placebo Test" in summary
        assert "P-value" in summary


class TestSensitivityAnalyzer:
    """Tests for comprehensive sensitivity analyzer."""

    @pytest.fixture
    def mock_data(self):
        """Create mock data."""
        np.random.seed(42)
        n = 100
        return pd.DataFrame(
            {
                "treatment": np.random.binomial(1, 0.5, n),
                "outcome": np.random.normal(10, 2, n),
                "x1": np.random.normal(0, 1, n),
            }
        )

    @pytest.fixture
    def mock_estimator(self):
        """Create mock estimator."""

        def estimator_fn(data, spec=None):
            return CausalEstimate(
                estimate=2.0,
                std_error=0.3,
                ci_lower=1.4,
                ci_upper=2.6,
                p_value=0.001,
                effect_type=EffectType.ATE,
            )

        return estimator_fn

    def test_analyzer_init(self, mock_estimator):
        """Test sensitivity analyzer initialization."""
        analyzer = SensitivityAnalyzer(estimator_fn=mock_estimator)

        assert analyzer.estimator_fn == mock_estimator
        assert analyzer.confidence_level == 0.95
        assert hasattr(analyzer, "rosenbaum")
        assert hasattr(analyzer, "evalue")

    def test_analyzer_rosenbaum(self):
        """Test Rosenbaum bounds via analyzer."""
        analyzer = SensitivityAnalyzer()
        effects = np.random.normal(2.0, 1.0, 50)

        result = analyzer.rosenbaum_bounds(effects)

        assert hasattr(result, "critical_gamma")

    def test_analyzer_evalue(self):
        """Test E-values via analyzer."""
        analyzer = SensitivityAnalyzer()

        result = analyzer.e_value(estimate=2.0, ci_lower=1.5, ci_upper=2.8)

        assert hasattr(result, "e_value")

    def test_analyzer_spec_curve(self, mock_data, mock_estimator):
        """Test specification curve via analyzer."""
        analyzer = SensitivityAnalyzer(estimator_fn=mock_estimator)
        specs = [{"covariates": ["x1"]}, {"covariates": []}]

        result = analyzer.specification_curve(mock_data, specs)

        assert hasattr(result, "median_estimate")

    def test_analyzer_placebo(self, mock_data, mock_estimator):
        """Test placebo test via analyzer."""
        analyzer = SensitivityAnalyzer(estimator_fn=mock_estimator)

        result = analyzer.placebo_test(mock_data, treatment_col="treatment")

        assert hasattr(result, "p_value")

    def test_analyzer_without_estimator_error(self, mock_data):
        """Test that analyzer raises error without estimator_fn."""
        analyzer = SensitivityAnalyzer()  # No estimator_fn

        with pytest.raises(ValueError, match="Must provide estimator_fn"):
            analyzer.specification_curve(mock_data, [{}])

        with pytest.raises(ValueError, match="Must provide estimator_fn"):
            analyzer.placebo_test(mock_data, treatment_col="treatment")


class TestEdgeCases:
    """Test edge cases and error handling."""

    def test_rosenbaum_with_zero_effects(self):
        """Test Rosenbaum bounds with all zero effects."""
        rb = RosenbaumBounds()
        effects = np.zeros(50)

        result = rb.analyze(effects)

        # Should complete without errors
        assert result is not None
        assert hasattr(result, "critical_gamma")

    def test_evalue_boundary_cases(self):
        """Test E-value with boundary cases."""
        ev = EValue()

        # Very small effect
        result = ev.calculate(estimate=1.01, ci_lower=1.0, ci_upper=1.02)
        assert result.e_value > 1.0

        # Very large effect
        result = ev.calculate(estimate=10.0, ci_lower=8.0, ci_upper=12.0)
        assert result.e_value > 1.0

    def test_spec_curve_with_failures(self):
        """Test specification curve when some specs fail."""
        # Create mock data
        np.random.seed(42)
        mock_data = pd.DataFrame(
            {
                "treatment": np.random.binomial(1, 0.5, 100),
                "outcome": np.random.normal(10, 2, 100),
            }
        )

        def failing_estimator(data, spec):
            if spec.get("fail", False):
                raise ValueError("Intentional failure")
            return CausalEstimate(
                estimate=2.0,
                std_error=0.3,
                ci_lower=1.4,
                ci_upper=2.6,
                p_value=0.001,
                effect_type=EffectType.ATE,
            )

        specs = [
            {"fail": False},
            {"fail": True},  # This will fail
            {"fail": False},
        ]

        sc = SpecificationCurve(estimator_fn=failing_estimator)
        result = sc.analyze(mock_data, specs)

        # Should have 2 valid specs (one failed)
        assert len(result.estimates) == 2
        assert len(result.specifications) == 2
