# ----------------------------------------------------------------------
# © 2025 KR-Labs. All rights reserved.
# KR-Labs™ is a trademark of Quipu Research Labs, LLC,
# a subsidiary of Sudiata Giddasira, Inc.
# ----------------------------------------------------------------------
# SPDX-License-Identifier: Apache-2.0

"""Tests for Regression Discontinuity Design estimator."""

import numpy as np
import pandas as pd
import pytest

from krl_policy.core.base import DataValidationError, EstimationError
from krl_policy.estimators.rdd import (
    BandwidthMethod,
    KernelType,
    RDDResult,
    RDDType,
    RegressionDiscontinuity,
)


class TestRegressionDiscontinuity:
    """Tests for RegressionDiscontinuity estimator."""

    @pytest.fixture
    def sharp_rdd_data(self):
        """Generate sharp RDD data with known treatment effect."""
        np.random.seed(42)
        n = 500
        cutoff = 50

        # Running variable
        x = np.random.uniform(0, 100, n)

        # Treatment assignment (sharp)
        treatment = (x >= cutoff).astype(int)

        # Outcome: linear + treatment effect + noise
        tau = 5.0  # True treatment effect
        y = 10 + 0.5 * (x - cutoff) + tau * treatment + np.random.normal(0, 2, n)

        return pd.DataFrame({"score": x, "outcome": y, "treated": treatment}), cutoff, tau

    @pytest.fixture
    def fuzzy_rdd_data(self):
        """Generate fuzzy RDD data."""
        np.random.seed(43)
        n = 600
        cutoff = 50

        x = np.random.uniform(0, 100, n)

        # Fuzzy treatment assignment
        prob_treated = 0.2 + 0.6 * (x >= cutoff).astype(float)
        treatment = np.random.binomial(1, prob_treated)

        tau = 10.0
        y = 15 + 0.3 * (x - cutoff) + tau * treatment + np.random.normal(0, 3, n)

        return pd.DataFrame({"score": x, "outcome": y, "treated": treatment}), cutoff, tau

    def test_sharp_rdd_init(self, sharp_rdd_data):
        """Test initialization of sharp RDD."""
        data, cutoff, _ = sharp_rdd_data

        rdd = RegressionDiscontinuity(
            running_var="score", outcome_col="outcome", cutoff=cutoff, rdd_type="sharp"
        )

        assert rdd.running_var == "score"
        assert rdd.cutoff == cutoff
        assert rdd.rdd_type == RDDType.SHARP

    def test_fuzzy_rdd_requires_treatment(self):
        """Test that fuzzy RDD requires treatment column."""
        with pytest.raises(ValueError, match="Fuzzy RDD requires treatment_col"):
            RegressionDiscontinuity(
                running_var="score",
                outcome_col="outcome",
                cutoff=50,
                rdd_type="fuzzy",
                treatment_col=None,
            )

    def test_sharp_rdd_estimation(self, sharp_rdd_data):
        """Test sharp RDD estimation."""
        data, cutoff, true_tau = sharp_rdd_data

        rdd = RegressionDiscontinuity(
            running_var="score",
            outcome_col="outcome",
            cutoff=cutoff,
            rdd_type="sharp",
            bandwidth_method="ik",
        )

        result = rdd.fit(data)

        assert isinstance(result, RDDResult)
        assert result.rdd_type == "sharp"
        assert result.n_left > 0
        assert result.n_right > 0

        # Check estimate is reasonable
        assert abs(result.ate.estimate - true_tau) < 3.0  # Within 3 units
        assert result.ate.std_error > 0
        assert len(result.ate.confidence_interval) == 2

    def test_fuzzy_rdd_estimation(self, fuzzy_rdd_data):
        """Test fuzzy RDD estimation."""
        data, cutoff, true_tau = fuzzy_rdd_data

        rdd = RegressionDiscontinuity(
            running_var="score",
            outcome_col="outcome",
            cutoff=cutoff,
            treatment_col="treated",
            rdd_type="fuzzy",
            bandwidth_method="ik",
        )

        result = rdd.fit(data)

        assert isinstance(result, RDDResult)
        assert result.rdd_type == "fuzzy"
        assert result.first_stage is not None
        assert "f_statistic" in result.first_stage
        assert result.first_stage["f_statistic"] > 0

    def test_bandwidth_selection_ik(self, sharp_rdd_data):
        """Test IK bandwidth selection."""
        data, cutoff, _ = sharp_rdd_data

        rdd = RegressionDiscontinuity(
            running_var="score", outcome_col="outcome", cutoff=cutoff, bandwidth_method="ik"
        )

        bw_result = rdd.select_bandwidth(data)

        assert bw_result.bandwidth > 0
        assert bw_result.method == "ik"

    def test_bandwidth_selection_cct(self, sharp_rdd_data):
        """Test CCT bandwidth selection."""
        data, cutoff, _ = sharp_rdd_data

        rdd = RegressionDiscontinuity(
            running_var="score", outcome_col="outcome", cutoff=cutoff, bandwidth_method="cct"
        )

        bw_result = rdd.select_bandwidth(data)

        assert bw_result.bandwidth > 0
        assert bw_result.method == "cct"

    def test_manual_bandwidth(self, sharp_rdd_data):
        """Test manual bandwidth specification."""
        data, cutoff, _ = sharp_rdd_data

        manual_bw = 15.0
        rdd = RegressionDiscontinuity(
            running_var="score",
            outcome_col="outcome",
            cutoff=cutoff,
            bandwidth=manual_bw,
            bandwidth_method="manual",
        )

        result = rdd.fit(data)

        assert result.bandwidth == manual_bw
        assert result.bandwidth_method == "manual"

    def test_different_kernels(self, sharp_rdd_data):
        """Test different kernel functions."""
        data, cutoff, _ = sharp_rdd_data

        kernels = [KernelType.TRIANGULAR, KernelType.UNIFORM, KernelType.EPANECHNIKOV]

        for kernel in kernels:
            rdd = RegressionDiscontinuity(
                running_var="score",
                outcome_col="outcome",
                cutoff=cutoff,
                kernel=kernel,
                bandwidth=15.0,
            )

            result = rdd.fit(data)
            assert result.kernel == kernel.value

    def test_polynomial_order(self, sharp_rdd_data):
        """Test different polynomial orders."""
        data, cutoff, _ = sharp_rdd_data

        for order in [1, 2]:
            rdd = RegressionDiscontinuity(
                running_var="score",
                outcome_col="outcome",
                cutoff=cutoff,
                polynomial_order=order,
                bandwidth=15.0,
            )

            result = rdd.fit(data)
            assert result.polynomial_order == order

    def test_manipulation_test(self, sharp_rdd_data):
        """Test McCrary density test for manipulation."""
        data, cutoff, _ = sharp_rdd_data

        rdd = RegressionDiscontinuity(running_var="score", outcome_col="outcome", cutoff=cutoff)

        rdd.fit(data)
        manip_result = rdd.manipulation_test()

        assert hasattr(manip_result, "statistic")
        assert hasattr(manip_result, "p_value")
        assert hasattr(manip_result, "passed")
        assert manip_result.n_left > 0
        assert manip_result.n_right > 0

    def test_placebo_test(self, sharp_rdd_data):
        """Test placebo cutoff tests."""
        data, cutoff, _ = sharp_rdd_data

        rdd = RegressionDiscontinuity(
            running_var="score", outcome_col="outcome", cutoff=cutoff, bandwidth=15.0
        )

        rdd.fit(data)
        placebo_result = rdd.placebo_test(n_placebos=3)

        assert len(placebo_result.placebo_cutoffs) > 0
        assert len(placebo_result.estimates) > 0
        assert placebo_result.significant_count >= 0

    def test_sensitivity_to_bandwidth(self, sharp_rdd_data):
        """Test sensitivity analysis varying bandwidth."""
        data, cutoff, _ = sharp_rdd_data

        rdd = RegressionDiscontinuity(running_var="score", outcome_col="outcome", cutoff=cutoff)

        rdd.fit(data)
        sens_results = rdd.sensitivity_to_bandwidth(n_bandwidths=5)

        assert len(sens_results) > 0
        for bw, estimate in sens_results.items():
            assert bw > 0
            assert hasattr(estimate, "estimate")

    def test_insufficient_data(self):
        """Test error with insufficient data."""
        data = pd.DataFrame({"score": [45, 46, 55, 56], "outcome": [10, 11, 15, 16]})

        rdd = RegressionDiscontinuity(running_var="score", outcome_col="outcome", cutoff=50)

        with pytest.raises(DataValidationError):
            rdd.fit(data)

    def test_estimate_ate(self, sharp_rdd_data):
        """Test estimate_ate method."""
        data, cutoff, _ = sharp_rdd_data

        rdd = RegressionDiscontinuity(running_var="score", outcome_col="outcome", cutoff=cutoff)

        rdd.fit(data)
        ate = rdd.estimate_ate()

        assert hasattr(ate, "estimate")
        assert hasattr(ate, "std_error")
        assert hasattr(ate, "confidence_interval")

    def test_summary(self, sharp_rdd_data):
        """Test summary output."""
        data, cutoff, _ = sharp_rdd_data

        rdd = RegressionDiscontinuity(running_var="score", outcome_col="outcome", cutoff=cutoff)

        rdd.fit(data)
        summary = rdd.summary()

        assert isinstance(summary, str)
        assert "Regression Discontinuity" in summary
        assert "Bandwidth" in summary
        assert "Treatment Effect" in summary

    def test_predict(self, sharp_rdd_data):
        """Test prediction method."""
        data, cutoff, _ = sharp_rdd_data

        rdd = RegressionDiscontinuity(running_var="score", outcome_col="outcome", cutoff=cutoff)

        rdd.fit(data)
        predictions = rdd.predict(data)

        assert len(predictions) == len(data)
        assert isinstance(predictions, np.ndarray)


class TestBandwidthMethods:
    """Tests for bandwidth selection methods."""

    @pytest.fixture
    def data(self):
        """Simple RDD dataset."""
        np.random.seed(100)
        n = 300
        x = np.random.uniform(-50, 50, n)
        y = 5 + 0.3 * x + 10 * (x >= 0) + np.random.normal(0, 2, n)

        return pd.DataFrame({"x": x, "y": y})

    def test_rot_bandwidth(self, data):
        """Test rule of thumb bandwidth."""
        rdd = RegressionDiscontinuity(
            running_var="x", outcome_col="y", cutoff=0, bandwidth_method="rot"
        )

        bw = rdd.select_bandwidth(data)
        assert bw.bandwidth > 0
        assert bw.method == "rot"

    def test_cv_bandwidth(self, data):
        """Test cross-validation bandwidth."""
        rdd = RegressionDiscontinuity(
            running_var="x", outcome_col="y", cutoff=0, bandwidth_method="cv"
        )

        bw = rdd.select_bandwidth(data)
        assert bw.bandwidth > 0
        assert bw.method == "cv"


class TestRDDEdgeCases:
    """Tests for edge cases and error handling."""

    def test_missing_columns(self):
        """Test error with missing columns."""
        data = pd.DataFrame({"x": [1, 2, 3], "y": [4, 5, 6]})

        rdd = RegressionDiscontinuity(running_var="missing", outcome_col="y", cutoff=2)

        with pytest.raises(DataValidationError):
            rdd.fit(data)

    def test_estimate_before_fit(self):
        """Test error when estimating before fitting."""
        rdd = RegressionDiscontinuity(running_var="x", outcome_col="y", cutoff=0)

        with pytest.raises(EstimationError):
            rdd.estimate_ate()
