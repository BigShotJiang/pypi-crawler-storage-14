# ----------------------------------------------------------------------
# © 2025 KR-Labs. All rights reserved.
# KR-Labs™ is a trademark of Quipu Research Labs, LLC,
# a subsidiary of Sudiata Giddasira, Inc.
# ----------------------------------------------------------------------
# SPDX-License-Identifier: Apache-2.0

"""
Unit tests for TreatmentEffectEstimator.

Tests cover:
- Basic instantiation and parameter validation
- Difference-in-means estimation
- Regression adjustment
- IPW estimation
- Doubly robust estimation
- Assumption validation
"""

import numpy as np
import pandas as pd
import pytest

from krl_policy.datasets import make_confounded_data, make_rct_data
from krl_policy.estimators import TreatmentEffectEstimator


class TestTreatmentEffectEstimatorInstantiation:
    """Test estimator instantiation and configuration."""

    def test_default_instantiation(self):
        """Test default parameters."""
        estimator = TreatmentEffectEstimator()

        assert estimator.method == "difference_in_means"
        assert estimator.confidence_level == 0.95
        assert estimator.n_bootstrap == 1000
        assert not estimator.is_fitted

    def test_custom_method(self):
        """Test custom method selection."""
        for method in ["difference_in_means", "regression_adjustment", "ipw", "doubly_robust"]:
            estimator = TreatmentEffectEstimator(method=method)
            assert estimator.method == method

    def test_invalid_method(self):
        """Test invalid method raises error."""
        with pytest.raises(ValueError, match="Unknown method"):
            TreatmentEffectEstimator(method="invalid_method")

    def test_custom_confidence_level(self):
        """Test custom confidence level."""
        estimator = TreatmentEffectEstimator(confidence_level=0.90)
        assert estimator.confidence_level == 0.90


class TestDifferenceInMeans:
    """Test difference-in-means estimator."""

    def test_basic_dim_estimation(self, rct_data_medium, true_ate_medium):
        """Test basic DiM estimation recovers true effect."""
        estimator = TreatmentEffectEstimator(method="difference_in_means")
        estimator.fit(rct_data_medium, treatment_col="T", outcome_col="Y")

        assert estimator.is_fitted
        assert estimator.effect_ is not None

        # Check estimate is close to true effect (within 2 SEs)
        error = abs(estimator.effect_ - true_ate_medium)
        assert (
            error < 2 * estimator.std_error_
        ), f"Estimate {estimator.effect_:.3f} too far from true {true_ate_medium}"

    def test_dim_confidence_interval(self, rct_data_medium, true_ate_medium):
        """Test confidence interval contains true effect."""
        estimator = TreatmentEffectEstimator(method="difference_in_means")
        estimator.fit(rct_data_medium, treatment_col="T", outcome_col="Y")

        ci_lower, ci_upper = estimator.ci_
        assert ci_lower < ci_upper

        # 95% CI should contain true effect most of the time
        # Can't guarantee this for a single test, but check interval is reasonable
        assert ci_lower < estimator.effect_ < ci_upper

    def test_dim_p_value(self, rct_data_medium):
        """Test p-value calculation."""
        estimator = TreatmentEffectEstimator(method="difference_in_means")
        estimator.fit(rct_data_medium, treatment_col="T", outcome_col="Y")

        assert 0 <= estimator.p_value_ <= 1

        # With true ATE of 2.0 and reasonable sample size,
        # p-value should be small
        assert estimator.p_value_ < 0.05

    def test_dim_with_known_effect(self, known_effect_df):
        """Test DiM recovers known effect with high precision."""
        data, true_effect = known_effect_df

        estimator = TreatmentEffectEstimator(method="difference_in_means")
        estimator.fit(data, treatment_col="T", outcome_col="Y")

        # With low noise, should be very close
        assert abs(estimator.effect_ - true_effect) < 0.5


class TestRegressionAdjustment:
    """Test regression adjustment estimator."""

    def test_basic_regression(self, rct_data_medium, true_ate_medium):
        """Test regression adjustment estimation."""
        estimator = TreatmentEffectEstimator(method="regression_adjustment")
        estimator.fit(
            rct_data_medium,
            treatment_col="T",
            outcome_col="Y",
            covariate_cols=["X0", "X1", "X2", "X3", "X4"],
        )

        assert estimator.is_fitted

        # Should be close to true effect
        error = abs(estimator.effect_ - true_ate_medium)
        assert error < 2 * estimator.std_error_

    def test_regression_reduces_variance(self, rct_data_large):
        """Test that regression reduces variance vs DiM."""
        dim_estimator = TreatmentEffectEstimator(method="difference_in_means")
        reg_estimator = TreatmentEffectEstimator(method="regression_adjustment")

        dim_estimator.fit(rct_data_large, treatment_col="T", outcome_col="Y")
        reg_estimator.fit(
            rct_data_large,
            treatment_col="T",
            outcome_col="Y",
            covariate_cols=["X0", "X1", "X2", "X3", "X4"],
        )

        # Regression should reduce SE by using covariate information
        # Not guaranteed but usually true
        # Allow for some variation
        assert reg_estimator.std_error_ <= dim_estimator.std_error_ * 1.5


class TestIPWEstimator:
    """Test inverse probability weighting estimator."""

    def test_ipw_rct_data(self, rct_data_medium, true_ate_medium):
        """Test IPW on RCT data."""
        estimator = TreatmentEffectEstimator(
            method="ipw", n_bootstrap=200, random_state=42  # Reduce for speed
        )
        estimator.fit(
            rct_data_medium,
            treatment_col="T",
            outcome_col="Y",
            covariate_cols=["X0", "X1", "X2", "X3", "X4"],
        )

        assert estimator.is_fitted
        assert estimator._propensity_scores is not None

        # Should recover effect
        error = abs(estimator.effect_ - true_ate_medium)
        assert error < 3 * estimator.std_error_

    @pytest.mark.slow
    def test_ipw_confounded_data(self, confounded_data_weak):
        """Test IPW on confounded data."""
        estimator = TreatmentEffectEstimator(method="ipw", n_bootstrap=200, random_state=42)

        covariate_cols = [c for c in confounded_data_weak.columns if c.startswith("X")]

        estimator.fit(
            confounded_data_weak, treatment_col="T", outcome_col="Y", covariate_cols=covariate_cols
        )

        # IPW should correct for confounding
        # True ATE is 2.0
        error = abs(estimator.effect_ - 2.0)
        assert error < 1.0  # Allow larger tolerance for confounded data


class TestDoublyRobustEstimator:
    """Test doubly robust (AIPW) estimator."""

    def test_dr_rct_data(self, rct_data_medium, true_ate_medium):
        """Test DR on RCT data."""
        estimator = TreatmentEffectEstimator(method="doubly_robust", random_state=42)
        estimator.fit(
            rct_data_medium,
            treatment_col="T",
            outcome_col="Y",
            covariate_cols=["X0", "X1", "X2", "X3", "X4"],
        )

        assert estimator.is_fitted
        assert estimator._propensity_scores is not None
        assert estimator._outcome_predictions is not None

        # Should recover effect
        error = abs(estimator.effect_ - true_ate_medium)
        assert error < 2 * estimator.std_error_

    def test_dr_efficiency(self, rct_data_large):
        """Test DR has reasonable efficiency."""
        dr_estimator = TreatmentEffectEstimator(method="doubly_robust")
        dim_estimator = TreatmentEffectEstimator(method="difference_in_means")

        covariate_cols = [c for c in rct_data_large.columns if c.startswith("X")]

        dr_estimator.fit(rct_data_large, "T", "Y", covariate_cols)
        dim_estimator.fit(rct_data_large, "T", "Y")

        # DR should not be much worse than DiM
        assert dr_estimator.std_error_ <= dim_estimator.std_error_ * 2


class TestAssumptionValidation:
    """Test assumption validation methods."""

    def test_validate_rct_data(self, rct_data_medium):
        """Test validation on clean RCT data."""
        estimator = TreatmentEffectEstimator(method="ipw")

        covariate_cols = [c for c in rct_data_medium.columns if c.startswith("X")]
        estimator.fit(rct_data_medium, "T", "Y", covariate_cols)

        validation = estimator.validate_assumptions(rct_data_medium)

        assert hasattr(validation, "is_valid")
        assert hasattr(validation, "checks")
        assert hasattr(validation, "warnings")

        # RCT data should generally pass
        assert "positivity" in validation.checks

    def test_validation_not_fitted_raises(self, rct_data_medium):
        """Test validation raises if not fitted."""
        estimator = TreatmentEffectEstimator()

        with pytest.raises(RuntimeError, match="not been fitted"):
            estimator.validate_assumptions(rct_data_medium)


class TestTreatmentEffectResult:
    """Test treatment effect result generation."""

    def test_get_treatment_effect(self, rct_data_medium):
        """Test get_treatment_effect returns correct structure."""
        estimator = TreatmentEffectEstimator()
        estimator.fit(rct_data_medium, "T", "Y")

        result = estimator.get_treatment_effect()

        # Result has an ate attribute which is a CausalEstimate
        assert result.ate.estimate == estimator.effect_
        assert result.ate.std_error == estimator.std_error_
        assert result.ate.ci_lower == estimator.ci_[0]
        assert result.ate.ci_upper == estimator.ci_[1]
        assert result.ate.p_value == estimator.p_value_

    def test_summary_output(self, rct_data_medium):
        """Test summary string generation."""
        estimator = TreatmentEffectEstimator()
        estimator.fit(rct_data_medium, "T", "Y")

        summary = estimator.summary()

        assert isinstance(summary, str)
        assert "Treatment Effect" in summary
        assert "Estimate" in summary
        assert "Std. Error" in summary


class TestPredict:
    """Test prediction functionality."""

    def test_predict_returns_constant(self, rct_data_medium):
        """Test predict returns constant effect for homogeneous estimator."""
        estimator = TreatmentEffectEstimator()
        estimator.fit(rct_data_medium, "T", "Y")

        predictions = estimator.predict(rct_data_medium)

        assert len(predictions) == len(rct_data_medium)
        assert np.allclose(predictions, estimator.effect_)

    def test_predict_not_fitted_raises(self, rct_data_medium):
        """Test predict raises if not fitted."""
        estimator = TreatmentEffectEstimator()

        with pytest.raises(RuntimeError, match="not been fitted"):
            estimator.predict(rct_data_medium)


class TestEdgeCases:
    """Test edge cases and error handling."""

    def test_small_sample(self):
        """Test with very small sample."""
        np.random.seed(42)
        data = pd.DataFrame({"T": [0, 0, 1, 1], "Y": [1, 2, 4, 5]})

        estimator = TreatmentEffectEstimator()
        estimator.fit(data, "T", "Y")

        # Should not crash, effect should be 3.0
        assert abs(estimator.effect_ - 3.0) < 0.01

    def test_no_covariates(self):
        """Test estimation with no covariates."""
        data, _ = make_rct_data(n_samples=100, n_features=0, random_state=42)

        estimator = TreatmentEffectEstimator(method="regression_adjustment")
        estimator.fit(data, "T", "Y", covariate_cols=[])

        # Should fall back to DiM
        assert estimator.is_fitted

    def test_missing_treatment_col(self, rct_data_medium):
        """Test error on missing treatment column."""
        estimator = TreatmentEffectEstimator()

        with pytest.raises((ValueError, KeyError)):
            estimator.fit(rct_data_medium, treatment_col="nonexistent", outcome_col="Y")

    def test_missing_outcome_col(self, rct_data_medium):
        """Test error on missing outcome column."""
        estimator = TreatmentEffectEstimator()

        with pytest.raises((ValueError, KeyError)):
            estimator.fit(rct_data_medium, treatment_col="T", outcome_col="nonexistent")
