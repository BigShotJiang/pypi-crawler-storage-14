# ----------------------------------------------------------------------
# © 2025 KR-Labs. All rights reserved.
# KR-Labs™ is a trademark of Quipu Research Labs, LLC,
# a subsidiary of Sudiata Giddasira, Inc.
# ----------------------------------------------------------------------
# SPDX-License-Identifier: Apache-2.0

"""
Unit tests for core utility functions.

Tests cover:
- Bootstrap confidence intervals
- Clustered standard errors
- Covariate balance checks
- Parallel trends testing
- Statistical utilities
"""

import numpy as np
import pandas as pd
import pytest

from krl_policy.core.utils import (
    balance_check,
    balance_summary,
    bootstrap_ci,
    bootstrap_std_error,
    clustered_se,
    compute_ci,
    compute_p_value,
    parallel_trends_test,
    standardized_mean_difference,
)


class TestBootstrapInference:
    """Test bootstrap inference functions."""

    def test_bootstrap_ci_basic(self):
        """Test basic bootstrap CI computation."""
        np.random.seed(42)
        data = pd.DataFrame({"x": np.random.randn(100)})

        def mean_fn(df):
            return df["x"].mean()

        estimate, ci_lower, ci_upper = bootstrap_ci(data, mean_fn, n_bootstrap=500, random_state=42)

        assert ci_lower < estimate < ci_upper
        assert ci_lower < 0.5  # True mean is 0
        assert ci_upper > -0.5

    def test_bootstrap_ci_percentile_method(self):
        """Test percentile method."""
        np.random.seed(42)
        data = pd.DataFrame({"x": np.random.randn(100)})

        estimate, ci_lower, ci_upper = bootstrap_ci(
            data, lambda df: df["x"].mean(), method="percentile", n_bootstrap=500, random_state=42
        )

        assert ci_lower < ci_upper

    def test_bootstrap_ci_basic_method(self):
        """Test basic method."""
        np.random.seed(42)
        data = pd.DataFrame({"x": np.random.randn(100)})

        estimate, ci_lower, ci_upper = bootstrap_ci(
            data, lambda df: df["x"].mean(), method="basic", n_bootstrap=500, random_state=42
        )

        assert ci_lower < ci_upper

    def test_bootstrap_ci_bca_method(self):
        """Test BCa method."""
        np.random.seed(42)
        data = pd.DataFrame({"x": np.random.randn(100)})

        estimate, ci_lower, ci_upper = bootstrap_ci(
            data, lambda df: df["x"].mean(), method="bca", n_bootstrap=500, random_state=42
        )

        assert ci_lower < ci_upper

    def test_bootstrap_ci_confidence_level(self):
        """Test different confidence levels."""
        np.random.seed(42)
        data = pd.DataFrame({"x": np.random.randn(200)})

        _, ci_lower_90, ci_upper_90 = bootstrap_ci(
            data, lambda df: df["x"].mean(), confidence_level=0.90, n_bootstrap=500
        )

        _, ci_lower_95, ci_upper_95 = bootstrap_ci(
            data, lambda df: df["x"].mean(), confidence_level=0.95, n_bootstrap=500
        )

        # 95% CI should be wider
        width_90 = ci_upper_90 - ci_lower_90
        width_95 = ci_upper_95 - ci_lower_95

        assert width_95 >= width_90 * 0.9  # Allow some sampling variation

    def test_bootstrap_std_error(self):
        """Test bootstrap standard error."""
        np.random.seed(42)
        data = pd.DataFrame({"x": np.random.randn(100)})

        se = bootstrap_std_error(data, lambda df: df["x"].mean(), n_bootstrap=500, random_state=42)

        assert se > 0
        assert se < 0.5  # Should be around 0.1 for n=100


class TestClusteredStandardErrors:
    """Test clustered standard error computation."""

    def test_clustered_se_basic(self):
        """Test basic clustered SE computation."""
        np.random.seed(42)
        n = 100
        n_clusters = 10

        # Generate clustered data
        cluster_ids = np.repeat(np.arange(n_clusters), n // n_clusters)
        X = np.column_stack([np.ones(n), np.random.randn(n)])
        beta_true = np.array([1.0, 2.0])

        # Clustered errors
        cluster_effects = np.random.randn(n_clusters)
        errors = cluster_effects[cluster_ids] + np.random.randn(n) * 0.5

        Y = X @ beta_true + errors

        # Fit OLS
        beta_hat = np.linalg.lstsq(X, Y, rcond=None)[0]
        residuals = Y - X @ beta_hat

        # Compute clustered SE
        se_clustered = clustered_se(residuals, X, cluster_ids)

        assert len(se_clustered) == 2
        assert all(se > 0 for se in se_clustered)


class TestCovariateBalance:
    """Test covariate balance functions."""

    @pytest.fixture
    def balance_data(self):
        """Create data for balance tests."""
        np.random.seed(42)
        n = 200

        return pd.DataFrame(
            {
                "T": np.random.binomial(1, 0.5, n),
                "age": np.random.normal(40, 10, n),
                "income": np.random.normal(50000, 15000, n),
                "education": np.random.normal(14, 2, n),
            }
        )

    def test_standardized_mean_difference(self, balance_data):
        """Test SMD computation."""
        smd = standardized_mean_difference(balance_data, treatment_col="T", covariate="age")

        # SMD should be between -3 and 3 for reasonable data
        assert -3 < smd < 3

    def test_smd_balanced_data(self):
        """Test SMD is small for balanced data."""
        np.random.seed(42)
        n = 1000

        # Create balanced data (randomized treatment)
        data = pd.DataFrame({"T": np.random.binomial(1, 0.5, n), "X": np.random.randn(n)})

        smd = standardized_mean_difference(data, "T", "X")

        # Should be close to 0 for randomized data
        assert abs(smd) < 0.2

    def test_smd_imbalanced_data(self):
        """Test SMD is large for imbalanced data."""
        np.random.seed(42)
        n = 200

        # Create imbalanced data
        X = np.random.randn(n)
        T = (X > 0).astype(int)  # Treatment depends on X

        data = pd.DataFrame({"T": T, "X": X})
        smd = standardized_mean_difference(data, "T", "X")

        # Should be large due to confounding
        assert abs(smd) > 1.0

    def test_balance_check(self, balance_data):
        """Test balance check function."""
        results = balance_check(
            balance_data, treatment_col="T", covariates=["age", "income", "education"]
        )

        assert len(results) == 3

        for cov, stats in results.items():
            assert "smd" in stats
            assert "mean_treated" in stats
            assert "mean_control" in stats
            assert "balanced" in stats

    def test_balance_summary(self, balance_data):
        """Test balance summary generation."""
        results = balance_check(
            balance_data, treatment_col="T", covariates=["age", "income", "education"]
        )

        summary = balance_summary(results)

        assert isinstance(summary, str)
        assert "Covariate Balance Summary" in summary
        assert "age" in summary


class TestParallelTrendsTest:
    """Test parallel trends testing."""

    @pytest.fixture
    def panel_data(self):
        """Create panel data for parallel trends test."""
        np.random.seed(42)

        records = []
        for unit in range(20):
            is_treated = unit < 10
            for time in range(10):
                T = 1 if is_treated and time >= 5 else 0
                # Parallel pre-trends
                Y = 2 * time + (3 if is_treated else 0) + T * 2.0 + np.random.randn()
                records.append(
                    {"unit": unit, "time": time, "T": T, "Y": Y, "treated_unit": int(is_treated)}
                )

        return pd.DataFrame(records)

    def test_parallel_trends_test(self, panel_data):
        """Test parallel trends test function."""
        result = parallel_trends_test(
            panel_data,
            outcome_col="Y",
            treatment_col="treated_unit",
            time_col="time",
            unit_col="unit",
            treatment_time=5,
        )

        assert "f_statistic" in result
        assert "p_value" in result
        assert "parallel_trends" in result
        assert "pre_trends" in result

    def test_parallel_trends_pass(self, panel_data):
        """Test parallel trends pass for parallel data."""
        # With truly parallel pre-trends, should pass
        result = parallel_trends_test(
            panel_data,
            outcome_col="Y",
            treatment_col="treated_unit",
            time_col="time",
            unit_col="unit",
            treatment_time=5,
        )

        # Should typically pass (p > 0.05)
        # Can't guarantee due to randomness, so just check structure


class TestStatisticalUtilities:
    """Test statistical utility functions."""

    def test_compute_p_value_two_sided(self):
        """Test two-sided p-value computation."""
        # Large z-score should give small p-value
        p = compute_p_value(estimate=3.0, std_error=1.0)
        assert p < 0.01

        # z-score of 0 should give p-value of 1
        p = compute_p_value(estimate=0.0, std_error=1.0)
        assert p > 0.99

    def test_compute_p_value_one_sided(self):
        """Test one-sided p-value computation."""
        # Positive estimate, greater alternative
        p = compute_p_value(estimate=2.0, std_error=1.0, alternative="greater")
        assert p < 0.05

        # Positive estimate, less alternative
        p = compute_p_value(estimate=2.0, std_error=1.0, alternative="less")
        assert p > 0.95

    def test_compute_ci(self):
        """Test confidence interval computation."""
        ci_lower, ci_upper = compute_ci(estimate=0.0, std_error=1.0)

        # 95% CI for standard normal
        assert ci_lower < 0
        assert ci_upper > 0
        assert abs(ci_lower + 1.96) < 0.01
        assert abs(ci_upper - 1.96) < 0.01

    def test_compute_ci_confidence_level(self):
        """Test CI with different confidence levels."""
        ci_90 = compute_ci(estimate=0.0, std_error=1.0, confidence_level=0.90)
        ci_95 = compute_ci(estimate=0.0, std_error=1.0, confidence_level=0.95)

        # 95% CI should be wider
        width_90 = ci_90[1] - ci_90[0]
        width_95 = ci_95[1] - ci_95[0]

        assert width_95 > width_90
