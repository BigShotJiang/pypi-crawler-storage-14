# Copyright (c) 2024 Sudiata Giddasira, Inc. d/b/a Quipu Research Labs, LLC d/b/a KR-Labs™
# SPDX-License-Identifier: MIT

"""Tests for reporting module."""

import tempfile
from pathlib import Path

import pandas as pd
import pytest

from krl_policy.core.base import CausalEstimate, DiagnosticResult, EffectType
from krl_policy.reporting import (
    HTMLReport,
    LaTeXReport,
    MarkdownReport,
    ReportConfig,
    ReportGenerator,
)


class TestReportConfig:
    """Tests for ReportConfig."""

    def test_default_config(self):
        """Test default configuration."""
        config = ReportConfig()
        assert config.title == "Causal Inference Report"
        assert config.author is None
        assert config.date is not None  # Auto-set to today
        assert config.include_diagnostics is True
        assert config.include_code is False
        assert config.significance_level == 0.05

    def test_custom_config(self):
        """Test custom configuration."""
        config = ReportConfig(
            title="My Report",
            author="John Doe",
            date="January 1, 2024",
            include_diagnostics=False,
            significance_level=0.01,
        )
        assert config.title == "My Report"
        assert config.author == "John Doe"
        assert config.date == "January 1, 2024"
        assert config.include_diagnostics is False
        assert config.significance_level == 0.01


class TestHTMLReport:
    """Tests for HTMLReport."""

    @pytest.fixture
    def report(self):
        """Create HTML report instance."""
        config = ReportConfig(title="Test Report", author="Test Author", date="Test Date")
        return HTMLReport(config)

    @pytest.fixture
    def estimate(self):
        """Create sample estimate."""
        return CausalEstimate(
            estimate=5.0,
            std_error=1.0,
            ci_lower=3.0,
            ci_upper=7.0,
            p_value=0.001,
            effect_type=EffectType.ATE,
        )

    def test_initialization(self, report):
        """Test report initialization."""
        rendered = report.render()
        assert "<!DOCTYPE html>" in rendered
        assert "Test Report" in rendered
        assert "Test Author" in rendered
        assert "Test Date" in rendered

    def test_add_title(self, report):
        """Test adding titles."""
        report.add_title("Section 1", level=2)
        rendered = report.render()
        assert "<h2>Section 1</h2>" in rendered

    def test_add_text(self, report):
        """Test adding text."""
        report.add_text("This is a test paragraph.")
        rendered = report.render()
        assert "<p>This is a test paragraph.</p>" in rendered

    def test_add_table(self, report):
        """Test adding tables."""
        df = pd.DataFrame({"Method": ["OLS", "IV"], "Estimate": [5.0, 4.5]})
        report.add_table(df, caption="Results")
        rendered = report.render()
        assert "Results" in rendered
        assert "OLS" in rendered
        assert "5.0" in rendered

    def test_add_estimate(self, report, estimate):
        """Test adding estimates."""
        report.add_estimate(estimate, label="ATE")
        rendered = report.render()
        assert "ATE" in rendered
        assert "5.0000" in rendered
        assert "1.0000" in rendered
        assert "0.0010" in rendered

    def test_add_significant_estimate(self, report, estimate):
        """Test significant estimate formatting."""
        report.add_estimate(estimate)
        rendered = report.render()
        assert "significant" in rendered
        assert "***" in rendered

    def test_add_nonsignificant_estimate(self, report):
        """Test non-significant estimate formatting."""
        estimate = CausalEstimate(
            estimate=1.0,
            std_error=2.0,
            ci_lower=-3.0,
            ci_upper=5.0,
            p_value=0.6,
            effect_type=EffectType.ATE,
        )
        report.add_estimate(estimate)
        rendered = report.render()
        assert "not-significant" in rendered

    def test_add_diagnostics(self, report):
        """Test adding diagnostics."""
        diagnostics = DiagnosticResult(
            balance_statistics={"age": {"smd": 0.05}}, warnings=["Warning 1", "Warning 2"]
        )
        report.add_diagnostics(diagnostics)
        rendered = report.render()
        assert "Diagnostic Information" in rendered
        assert "Warning 1" in rendered
        assert "Warning 2" in rendered

    def test_add_comparison_table(self, report):
        """Test adding comparison table."""
        report.add_comparison_table(
            methods=["OLS", "IV", "DID"],
            estimates=[5.0, 4.5, 5.2],
            std_errors=[1.0, 1.2, 0.9],
            p_values=[0.001, 0.01, 0.001],
        )
        rendered = report.render()
        assert "Method Comparison" in rendered
        assert "OLS" in rendered
        assert "5.0000" in rendered

    def test_save_report(self, report):
        """Test saving report to file."""
        with tempfile.TemporaryDirectory() as tmpdir:
            path = Path(tmpdir) / "test_report.html"
            report.save(path)
            assert path.exists()
            content = path.read_text()
            assert "<!DOCTYPE html>" in content


class TestLaTeXReport:
    """Tests for LaTeXReport."""

    @pytest.fixture
    def report(self):
        """Create LaTeX report instance."""
        config = ReportConfig(title="Test Report", author="Test Author")
        return LaTeXReport(config)

    @pytest.fixture
    def estimate(self):
        """Create sample estimate."""
        return CausalEstimate(
            estimate=5.0,
            std_error=1.0,
            ci_lower=3.0,
            ci_upper=7.0,
            p_value=0.001,
            effect_type=EffectType.ATE,
        )

    def test_initialization(self, report):
        """Test report initialization."""
        rendered = report.render()
        assert r"\documentclass" in rendered
        assert r"\title{Test Report}" in rendered
        assert r"\author{Test Author}" in rendered

    def test_add_title(self, report):
        """Test adding titles."""
        report.add_title("Results", level=1)
        rendered = report.render()
        assert r"\section{Results}" in rendered

    def test_add_text(self, report):
        """Test adding text with special characters."""
        report.add_text("Test with 50% improvement & cost_reduction")
        rendered = report.render()
        assert r"50\%" in rendered
        assert r"\&" in rendered
        assert r"cost\_reduction" in rendered

    def test_add_table(self, report):
        """Test adding tables."""
        df = pd.DataFrame({"A": [1, 2], "B": [3, 4]})
        report.add_table(df, caption="Test Table")
        rendered = report.render()
        assert r"\begin{table}" in rendered
        assert r"\caption{Test Table}" in rendered
        assert r"\toprule" in rendered

    def test_add_estimate(self, report, estimate):
        """Test adding estimates."""
        report.add_estimate(estimate, label="ATE")
        rendered = report.render()
        assert "ATE" in rendered
        assert "5.0000" in rendered
        assert "***" in rendered

    def test_save_report(self, report):
        """Test saving report to file."""
        with tempfile.TemporaryDirectory() as tmpdir:
            path = Path(tmpdir) / "test_report.tex"
            report.save(path)
            assert path.exists()
            content = path.read_text()
            assert r"\documentclass" in content


class TestMarkdownReport:
    """Tests for MarkdownReport."""

    @pytest.fixture
    def report(self):
        """Create Markdown report instance."""
        config = ReportConfig(title="Test Report", author="Test Author")
        return MarkdownReport(config)

    @pytest.fixture
    def estimate(self):
        """Create sample estimate."""
        return CausalEstimate(
            estimate=5.0,
            std_error=1.0,
            ci_lower=3.0,
            ci_upper=7.0,
            p_value=0.001,
            effect_type=EffectType.ATE,
        )

    def test_initialization(self, report):
        """Test report initialization."""
        rendered = report.render()
        assert "# Test Report" in rendered
        assert "**Author:** Test Author" in rendered

    def test_add_title(self, report):
        """Test adding titles."""
        report.add_title("Results", level=2)
        rendered = report.render()
        assert "## Results" in rendered

    def test_add_text(self, report):
        """Test adding text."""
        report.add_text("This is a test.")
        rendered = report.render()
        assert "This is a test." in rendered

    def test_add_table(self, report):
        """Test adding tables."""
        df = pd.DataFrame({"Method": ["OLS"], "Estimate": [5.0]})
        report.add_table(df, caption="Results")
        rendered = report.render()
        assert "**Results**" in rendered
        assert "OLS" in rendered

    def test_add_estimate(self, report, estimate):
        """Test adding estimates."""
        report.add_estimate(estimate, label="ATE")
        rendered = report.render()
        assert "### ATE" in rendered
        assert "5.0000 ***" in rendered
        assert "**P-value:**" in rendered

    def test_add_diagnostics(self, report):
        """Test adding diagnostics."""
        diagnostics = DiagnosticResult(
            balance_statistics={"age": {"smd": 0.05}}, warnings=["Warning 1"]
        )
        report.add_diagnostics(diagnostics)
        rendered = report.render()
        assert "Diagnostic Information" in rendered
        assert "⚠️ Warning 1" in rendered

    def test_save_report(self, report):
        """Test saving report to file."""
        with tempfile.TemporaryDirectory() as tmpdir:
            path = Path(tmpdir) / "test_report.md"
            report.save(path)
            assert path.exists()
            content = path.read_text()
            assert "# Test Report" in content


class TestReportGenerator:
    """Tests for ReportGenerator."""

    @pytest.fixture
    def generator(self):
        """Create report generator instance."""
        return ReportGenerator(title="Test Report", author="Test Author")

    @pytest.fixture
    def estimate(self):
        """Create sample estimate."""
        return CausalEstimate(
            estimate=5.0,
            std_error=1.0,
            ci_lower=3.0,
            ci_upper=7.0,
            p_value=0.001,
            effect_type=EffectType.ATE,
        )

    def test_initialization(self, generator):
        """Test generator initialization."""
        assert generator.html is not None
        assert generator.latex is not None
        assert generator.markdown is not None
        assert generator.config.title == "Test Report"

    def test_add_title(self, generator):
        """Test adding title to all formats."""
        generator.add_title("Results")

        html = generator.html.render()
        latex = generator.latex.render()
        markdown = generator.markdown.render()

        assert "Results" in html
        assert "Results" in latex
        assert "Results" in markdown

    def test_add_text(self, generator):
        """Test adding text to all formats."""
        generator.add_text("Test paragraph")

        html = generator.html.render()
        latex = generator.latex.render()
        markdown = generator.markdown.render()

        assert "Test paragraph" in html
        assert "Test paragraph" in latex
        assert "Test paragraph" in markdown

    def test_add_table(self, generator):
        """Test adding table to all formats."""
        df = pd.DataFrame({"A": [1], "B": [2]})
        generator.add_table(df, caption="Test")

        html = generator.html.render()
        latex = generator.latex.render()
        markdown = generator.markdown.render()

        assert "Test" in html
        assert "Test" in latex
        assert "Test" in markdown

    def test_add_estimate(self, generator, estimate):
        """Test adding estimate to all formats."""
        generator.add_estimate(estimate, label="ATE")

        html = generator.html.render()
        latex = generator.latex.render()
        markdown = generator.markdown.render()

        assert "ATE" in html and "5.0000" in html
        assert "ATE" in latex and "5.0000" in latex
        assert "ATE" in markdown and "5.0000" in markdown

    def test_add_comparison_table(self, generator):
        """Test adding comparison table."""
        generator.add_comparison_table(
            methods=["OLS", "IV"],
            estimates=[5.0, 4.5],
            std_errors=[1.0, 1.2],
            p_values=[0.001, 0.01],
        )

        html = generator.html.render()
        latex = generator.latex.render()
        markdown = generator.markdown.render()

        assert "Method Comparison" in html
        assert "Method Comparison" in latex
        assert "Method Comparison" in markdown

    def test_save_all_formats(self, generator, estimate):
        """Test saving all report formats."""
        generator.add_title("Results")
        generator.add_estimate(estimate)

        with tempfile.TemporaryDirectory() as tmpdir:
            base_path = Path(tmpdir) / "report"
            generator.save_all(base_path)

            # Check all files created
            assert Path(tmpdir, "report.html").exists()
            assert Path(tmpdir, "report.tex").exists()
            assert Path(tmpdir, "report.md").exists()

            # Verify content
            html_content = Path(tmpdir, "report.html").read_text()
            assert "<!DOCTYPE html>" in html_content

            latex_content = Path(tmpdir, "report.tex").read_text()
            assert r"\documentclass" in latex_content

            md_content = Path(tmpdir, "report.md").read_text()
            assert "# Test Report" in md_content


class TestEdgeCases:
    """Test edge cases and error handling."""

    def test_empty_report(self):
        """Test rendering empty report."""
        report = HTMLReport()
        rendered = report.render()
        assert "<!DOCTYPE html>" in rendered

    def test_missing_diagnostics(self):
        """Test diagnostics with no data."""
        report = HTMLReport()
        diagnostics = DiagnosticResult()
        report.add_diagnostics(diagnostics)
        # Should not raise error
        rendered = report.render()
        assert rendered is not None

    def test_exclude_diagnostics(self):
        """Test excluding diagnostics from report."""
        config = ReportConfig(include_diagnostics=False)
        report = HTMLReport(config)
        diagnostics = DiagnosticResult(warnings=["Test warning"])
        report.add_diagnostics(diagnostics)
        rendered = report.render()
        assert "Test warning" not in rendered

    def test_nested_directories(self):
        """Test saving to nested directory structure."""
        report = HTMLReport()
        with tempfile.TemporaryDirectory() as tmpdir:
            path = Path(tmpdir) / "nested" / "dir" / "report.html"
            report.save(path)
            assert path.exists()
