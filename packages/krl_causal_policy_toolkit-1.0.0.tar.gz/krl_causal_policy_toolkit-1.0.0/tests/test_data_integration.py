# Copyright (c) 2024 Sudiata Giddasira, Inc. d/b/a Quipu Research Labs, LLC d/b/a KR-Labs™
# SPDX-License-Identifier: MIT

"""Tests for data integration module."""

import numpy as np
import pandas as pd
import pytest

from krl_policy.data import (
    DatasetMetadata,
    DatasetRegistry,
    DatasetSource,
    PolicyDataLoader,
    PolicyDataset,
    list_available_datasets,
    load_policy_dataset,
)


class TestDatasetMetadata:
    """Tests for DatasetMetadata."""

    def test_basic_metadata(self):
        """Test basic metadata creation."""
        metadata = DatasetMetadata(
            name="test",
            description="Test dataset",
            source=DatasetSource.BUILTIN,
            treatment_col="treat",
            outcome_col="outcome",
            covariates=["x1", "x2"],
        )
        assert metadata.name == "test"
        assert metadata.treatment_col == "treat"
        assert len(metadata.covariates) == 2

    def test_panel_metadata(self):
        """Test metadata with panel data fields."""
        metadata = DatasetMetadata(
            name="panel",
            description="Panel dataset",
            source=DatasetSource.BUILTIN,
            treatment_col="treat",
            outcome_col="outcome",
            time_col="year",
            unit_col="state",
        )
        assert metadata.time_col == "year"
        assert metadata.unit_col == "state"

    def test_rdd_metadata(self):
        """Test metadata with RDD fields."""
        metadata = DatasetMetadata(
            name="rdd",
            description="RDD dataset",
            source=DatasetSource.BUILTIN,
            treatment_col="treat",
            outcome_col="outcome",
            running_var="score",
            cutoff=50.0,
        )
        assert metadata.running_var == "score"
        assert metadata.cutoff == 50.0


class TestPolicyDataset:
    """Tests for PolicyDataset."""

    @pytest.fixture
    def sample_data(self):
        """Create sample dataset."""
        return pd.DataFrame(
            {
                "treat": [1, 0, 1, 0, 1],
                "outcome": [10, 5, 12, 6, 11],
                "x1": [1, 2, 3, 4, 5],
                "x2": [5, 4, 3, 2, 1],
            }
        )

    @pytest.fixture
    def sample_metadata(self):
        """Create sample metadata."""
        return DatasetMetadata(
            name="test",
            description="Test dataset",
            source=DatasetSource.BUILTIN,
            treatment_col="treat",
            outcome_col="outcome",
            covariates=["x1", "x2"],
        )

    def test_dataset_creation(self, sample_data, sample_metadata):
        """Test dataset creation."""
        dataset = PolicyDataset(data=sample_data, metadata=sample_metadata)
        assert len(dataset.data) == 5
        assert dataset.metadata.name == "test"

    def test_missing_treatment_column(self, sample_data, sample_metadata):
        """Test error when treatment column is missing."""
        sample_metadata.treatment_col = "nonexistent"
        with pytest.raises(ValueError, match="Treatment column"):
            PolicyDataset(data=sample_data, metadata=sample_metadata)

    def test_missing_outcome_column(self, sample_data, sample_metadata):
        """Test error when outcome column is missing."""
        sample_metadata.outcome_col = "nonexistent"
        with pytest.raises(ValueError, match="Outcome column"):
            PolicyDataset(data=sample_data, metadata=sample_metadata)

    def test_treatment_property(self, sample_data, sample_metadata):
        """Test treatment property."""
        dataset = PolicyDataset(data=sample_data, metadata=sample_metadata)
        treatment = dataset.treatment
        assert len(treatment) == 5
        assert treatment.sum() == 3  # 3 treated units

    def test_outcome_property(self, sample_data, sample_metadata):
        """Test outcome property."""
        dataset = PolicyDataset(data=sample_data, metadata=sample_metadata)
        outcome = dataset.outcome
        assert len(outcome) == 5
        assert outcome.mean() == 8.8

    def test_covariates_data(self, sample_data, sample_metadata):
        """Test covariates data property."""
        dataset = PolicyDataset(data=sample_data, metadata=sample_metadata)
        covariates = dataset.covariates_data
        assert covariates.shape == (5, 2)
        assert list(covariates.columns) == ["x1", "x2"]

    def test_split_by_treatment(self, sample_data, sample_metadata):
        """Test splitting by treatment."""
        dataset = PolicyDataset(data=sample_data, metadata=sample_metadata)
        treated, control = dataset.split_by_treatment()
        assert len(treated) == 3
        assert len(control) == 2

    def test_summary(self, sample_data, sample_metadata):
        """Test summary statistics."""
        dataset = PolicyDataset(data=sample_data, metadata=sample_metadata)
        summary = dataset.summary()

        assert summary["n_obs"] == 5
        assert summary["n_treated"] == 3
        assert summary["n_control"] == 2
        assert summary["treatment_rate"] == 0.6
        assert summary["outcome_mean_treated"] == 11.0
        assert summary["outcome_mean_control"] == 5.5
        assert summary["outcome_diff"] == 5.5

    def test_describe(self, sample_data, sample_metadata):
        """Test describe method."""
        dataset = PolicyDataset(data=sample_data, metadata=sample_metadata)
        description = dataset.describe()

        assert "TEST Dataset" in description
        assert "Test dataset" in description
        assert "Total: 5" in description
        assert "Treated: 3" in description


class TestDatasetRegistry:
    """Tests for DatasetRegistry."""

    def test_list_datasets(self):
        """Test listing available datasets."""
        datasets = DatasetRegistry.list_datasets()
        assert isinstance(datasets, list)
        assert len(datasets) > 0
        assert "nsw" in datasets

    def test_get_metadata(self):
        """Test getting dataset metadata."""
        metadata = DatasetRegistry.get_metadata("nsw")
        assert metadata.name == "nsw"
        assert metadata.treatment_col == "treat"
        assert metadata.outcome_col == "re78"
        assert "age" in metadata.covariates

    def test_get_metadata_invalid(self):
        """Test error for invalid dataset."""
        with pytest.raises(ValueError, match="not found"):
            DatasetRegistry.get_metadata("nonexistent")

    def test_load_nsw_dataset(self):
        """Test loading NSW dataset."""
        dataset = DatasetRegistry.load_dataset("nsw")
        assert isinstance(dataset, PolicyDataset)
        assert len(dataset.data) > 0
        assert "treat" in dataset.data.columns
        assert "re78" in dataset.data.columns

    def test_load_medicaid_dataset(self):
        """Test loading Medicaid dataset."""
        dataset = DatasetRegistry.load_dataset("medicaid")
        assert isinstance(dataset, PolicyDataset)
        assert dataset.metadata.time_col == "year"
        assert dataset.metadata.unit_col == "state"
        assert "medicaid_expansion" in dataset.data.columns

    def test_load_minimum_wage_dataset(self):
        """Test loading minimum wage dataset."""
        dataset = DatasetRegistry.load_dataset("minimum_wage")
        assert isinstance(dataset, PolicyDataset)
        assert "min_wage_increase" in dataset.data.columns
        assert "employment_rate" in dataset.data.columns

    def test_load_education_voucher_dataset(self):
        """Test loading education voucher dataset."""
        dataset = DatasetRegistry.load_dataset("education_voucher")
        assert isinstance(dataset, PolicyDataset)
        assert dataset.metadata.instrument == "lottery_win"
        assert "voucher" in dataset.data.columns
        assert "lottery_win" in dataset.data.columns

    def test_load_snap_dataset(self):
        """Test loading SNAP dataset."""
        dataset = DatasetRegistry.load_dataset("snap_eligibility")
        assert isinstance(dataset, PolicyDataset)
        assert dataset.metadata.running_var == "income_pct_fpl"
        assert dataset.metadata.cutoff == 130.0
        assert "snap_eligible" in dataset.data.columns


class TestPolicyDataLoader:
    """Tests for PolicyDataLoader."""

    def test_initialization(self):
        """Test loader initialization."""
        loader = PolicyDataLoader()
        assert loader.registry is not None

    def test_list_available(self):
        """Test listing available datasets."""
        loader = PolicyDataLoader()
        datasets = loader.list_available()
        assert isinstance(datasets, list)
        assert len(datasets) > 0

    def test_get_info(self):
        """Test getting dataset info."""
        loader = PolicyDataLoader()
        info = loader.get_info("nsw")
        assert info.name == "nsw"
        assert "training" in info.description.lower()

    def test_load_dataset(self):
        """Test loading dataset."""
        loader = PolicyDataLoader()
        dataset = loader.load("nsw")
        assert isinstance(dataset, PolicyDataset)
        assert len(dataset.data) > 0


class TestHighLevelAPI:
    """Tests for high-level API functions."""

    def test_list_available_datasets(self):
        """Test list_available_datasets function."""
        datasets = list_available_datasets()
        assert isinstance(datasets, list)
        assert "nsw" in datasets
        assert "medicaid" in datasets

    def test_load_policy_dataset(self):
        """Test load_policy_dataset function."""
        dataset = load_policy_dataset("nsw")
        assert isinstance(dataset, PolicyDataset)
        assert len(dataset.data) > 0
        assert dataset.metadata.n_obs == len(dataset.data)

    def test_load_and_use_nsw(self):
        """Test loading and using NSW dataset."""
        dataset = load_policy_dataset("nsw")

        # Check structure
        assert "treat" in dataset.data.columns
        assert "re78" in dataset.data.columns

        # Check summary
        summary = dataset.summary()
        assert summary["n_obs"] > 0
        assert summary["n_treated"] > 0
        assert summary["n_control"] > 0

        # Check split
        treated, control = dataset.split_by_treatment()
        assert len(treated) + len(control) == len(dataset.data)

    def test_load_and_use_panel_data(self):
        """Test loading and using panel dataset."""
        dataset = load_policy_dataset("medicaid")

        # Check panel structure
        assert dataset.metadata.time_col is not None
        assert dataset.metadata.unit_col is not None
        assert dataset.metadata.time_col in dataset.data.columns
        assert dataset.metadata.unit_col in dataset.data.columns

        # Check multiple time periods
        n_years = dataset.data[dataset.metadata.time_col].nunique()
        assert n_years > 1

    def test_load_and_use_rdd_data(self):
        """Test loading and using RDD dataset."""
        dataset = load_policy_dataset("snap_eligibility")

        # Check RDD structure
        assert dataset.metadata.running_var is not None
        assert dataset.metadata.cutoff is not None
        assert dataset.metadata.running_var in dataset.data.columns

        # Check cutoff creates treatment
        running_var = dataset.data[dataset.metadata.running_var]
        treatment = dataset.data[dataset.metadata.treatment_col]

        # Below cutoff should be mostly treated
        below_cutoff = running_var <= dataset.metadata.cutoff
        assert treatment[below_cutoff].mean() > 0.9


class TestDatasetConsistency:
    """Test dataset consistency and quality."""

    @pytest.mark.parametrize(
        "dataset_name", ["nsw", "medicaid", "minimum_wage", "education_voucher", "snap_eligibility"]
    )
    def test_all_datasets_load(self, dataset_name):
        """Test that all datasets load successfully."""
        dataset = load_policy_dataset(dataset_name)
        assert isinstance(dataset, PolicyDataset)
        assert len(dataset.data) > 0

    @pytest.mark.parametrize(
        "dataset_name", ["nsw", "medicaid", "minimum_wage", "education_voucher", "snap_eligibility"]
    )
    def test_all_datasets_have_required_columns(self, dataset_name):
        """Test that all datasets have required columns."""
        dataset = load_policy_dataset(dataset_name)

        # Check treatment and outcome columns exist
        assert dataset.metadata.treatment_col in dataset.data.columns
        assert dataset.metadata.outcome_col in dataset.data.columns

        # Check covariates exist
        for cov in dataset.metadata.covariates:
            assert cov in dataset.data.columns

    @pytest.mark.parametrize(
        "dataset_name", ["nsw", "medicaid", "minimum_wage", "education_voucher", "snap_eligibility"]
    )
    def test_all_datasets_summary_works(self, dataset_name):
        """Test that summary works for all datasets."""
        dataset = load_policy_dataset(dataset_name)
        summary = dataset.summary()

        assert summary["n_obs"] > 0
        assert summary["n_treated"] > 0
        assert summary["n_control"] > 0
        assert 0 < summary["treatment_rate"] < 1

    @pytest.mark.parametrize(
        "dataset_name", ["nsw", "medicaid", "minimum_wage", "education_voucher", "snap_eligibility"]
    )
    def test_all_datasets_describe_works(self, dataset_name):
        """Test that describe works for all datasets."""
        dataset = load_policy_dataset(dataset_name)
        description = dataset.describe()

        assert isinstance(description, str)
        assert len(description) > 0
        assert dataset.metadata.name.upper() in description
