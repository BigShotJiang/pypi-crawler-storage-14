# ----------------------------------------------------------------------
# © 2025 KR-Labs. All rights reserved.
# KR-Labs™ is a trademark of Quipu Research Labs, LLC,
# a subsidiary of Sudiata Giddasira, Inc.
# ----------------------------------------------------------------------
# SPDX-License-Identifier: Apache-2.0

"""Tests for PolicyEvaluator."""

import numpy as np
import pandas as pd
import pytest

from krl_policy.core.base import EstimationError
from krl_policy.evaluators.policy_evaluator import (
    PolicyEvaluationResult,
    PolicyEvaluator,
    PolicyMethod,
)


class TestPolicyEvaluator:
    """Tests for PolicyEvaluator."""

    @pytest.fixture
    def simple_rct_data(self):
        """Generate simple RCT data."""
        np.random.seed(42)
        n = 200

        treatment = np.random.binomial(1, 0.5, n)
        x1 = np.random.normal(0, 1, n)
        x2 = np.random.normal(0, 1, n)

        tau = 2.0
        y = 10 + 1.5 * x1 + 0.8 * x2 + tau * treatment + np.random.normal(0, 1, n)

        return pd.DataFrame({"treatment": treatment, "outcome": y, "x1": x1, "x2": x2}), tau

    def test_init_with_string_method(self):
        """Test initialization with string method."""
        evaluator = PolicyEvaluator(
            method="regression_adjustment", treatment_col="treatment", outcome_col="outcome"
        )

        assert evaluator.method_name == "regression_adjustment"
        assert evaluator.treatment_col == "treatment"
        assert evaluator.outcome_col == "outcome"

    def test_init_with_enum_method(self):
        """Test initialization with enum method."""
        evaluator = PolicyEvaluator(
            method=PolicyMethod.IPW, treatment_col="treatment", outcome_col="outcome"
        )

        assert evaluator.method_name == "ipw"

    def test_basic_evaluation(self, simple_rct_data):
        """Test basic policy evaluation."""
        data, true_tau = simple_rct_data

        evaluator = PolicyEvaluator(
            method="regression_adjustment",
            treatment_col="treatment",
            outcome_col="outcome",
            covariates=["x1", "x2"],
        )

        result = evaluator.evaluate(data)

        assert isinstance(result, PolicyEvaluationResult)
        assert hasattr(result.primary_estimate, "estimate")
        assert abs(result.primary_estimate.estimate - true_tau) < 1.0

    def test_method_comparison(self, simple_rct_data):
        """Test multi-method comparison."""
        data, _ = simple_rct_data

        evaluator = PolicyEvaluator(
            method="regression_adjustment",
            treatment_col="treatment",
            outcome_col="outcome",
            covariates=["x1", "x2"],
            compare_methods=["ipw", "doubly_robust"],
        )

        result = evaluator.evaluate(data)

        assert result.comparison is not None
        assert len(result.comparison.methods) >= 2
        assert "regression_adjustment" in result.comparison.methods
        assert result.comparison.mean_estimate is not None
        assert result.comparison.std_estimate >= 0

    def test_assumption_validation(self, simple_rct_data):
        """Test assumption validation."""
        data, _ = simple_rct_data

        evaluator = PolicyEvaluator(
            method="regression_adjustment",
            treatment_col="treatment",
            outcome_col="outcome",
            covariates=["x1", "x2"],
            validate_assumptions=True,
        )

        result = evaluator.evaluate(data)

        assert result.assumption_report is not None
        assert hasattr(result.assumption_report, "all_passed")
        assert isinstance(result.assumption_report.warnings, list)

    def test_no_assumption_validation(self, simple_rct_data):
        """Test with assumption validation disabled."""
        data, _ = simple_rct_data

        evaluator = PolicyEvaluator(
            method="regression_adjustment",
            treatment_col="treatment",
            outcome_col="outcome",
            validate_assumptions=False,
        )

        result = evaluator.evaluate(data)

        assert result.assumption_report is None

    def test_sensitivity_to_confounding(self, simple_rct_data):
        """Test sensitivity analysis for unobserved confounding."""
        data, _ = simple_rct_data

        evaluator = PolicyEvaluator(
            method="regression_adjustment",
            treatment_col="treatment",
            outcome_col="outcome",
            covariates=["x1", "x2"],
        )

        evaluator.evaluate(data)
        sens_results = evaluator.sensitivity_to_unobserved_confounding(
            r2_range=(0.0, 0.3), n_points=5
        )

        assert len(sens_results) == 5
        for r2, estimate in sens_results.items():
            assert 0 <= r2 <= 0.3
            assert hasattr(estimate, "estimate")

    def test_get_result(self, simple_rct_data):
        """Test get_result method."""
        data, _ = simple_rct_data

        evaluator = PolicyEvaluator(
            method="regression_adjustment", treatment_col="treatment", outcome_col="outcome"
        )

        evaluator.evaluate(data)
        result = evaluator.get_result()

        assert isinstance(result, PolicyEvaluationResult)

    def test_get_result_before_evaluate(self):
        """Test error when getting result before evaluation."""
        evaluator = PolicyEvaluator(
            method="regression_adjustment", treatment_col="treatment", outcome_col="outcome"
        )

        with pytest.raises(EstimationError):
            evaluator.get_result()

    def test_summary(self, simple_rct_data):
        """Test summary generation."""
        data, _ = simple_rct_data

        evaluator = PolicyEvaluator(
            method="regression_adjustment",
            treatment_col="treatment",
            outcome_col="outcome",
            covariates=["x1", "x2"],
        )

        evaluator.evaluate(data)
        summary = evaluator.summary()

        assert isinstance(summary, str)
        assert "Policy Evaluation" in summary
        assert "Treatment Effect" in summary

    def test_to_dict(self, simple_rct_data):
        """Test export to dictionary."""
        data, _ = simple_rct_data

        evaluator = PolicyEvaluator(
            method="regression_adjustment",
            treatment_col="treatment",
            outcome_col="outcome",
            covariates=["x1", "x2"],
            compare_methods=["ipw"],
        )

        evaluator.evaluate(data)
        output = evaluator.to_dict()

        assert isinstance(output, dict)
        assert "method" in output
        assert "estimate" in output
        assert "std_error" in output
        assert "comparison" in output

    def test_different_methods(self, simple_rct_data):
        """Test evaluation with different methods."""
        data, _ = simple_rct_data

        methods = ["difference_in_means", "regression_adjustment", "ipw", "doubly_robust"]

        for method in methods:
            evaluator = PolicyEvaluator(
                method=method,
                treatment_col="treatment",
                outcome_col="outcome",
                covariates=["x1", "x2"],
            )

            result = evaluator.evaluate(data)
            assert result.primary_estimate is not None
            assert result.method == method


class TestPolicyEvaluatorWithDiD:
    """Tests for PolicyEvaluator with DiD."""

    @pytest.fixture
    def panel_data(self):
        """Generate panel data."""
        np.random.seed(43)
        n_units = 50
        n_periods = 6

        data = []
        for unit in range(n_units):
            treated = unit >= n_units // 2
            for period in range(n_periods):
                post = period >= 3

                y = (
                    10
                    + unit * 0.1
                    + period * 0.5
                    + (5.0 if (treated and post) else 0)
                    + np.random.normal(0, 1)
                )

                data.append(
                    {"unit": unit, "time": period, "treated": int(treated and post), "outcome": y}
                )

        return pd.DataFrame(data)

    def test_did_evaluation(self, panel_data):
        """Test evaluation with DiD method."""
        evaluator = PolicyEvaluator(
            method="did",
            treatment_col="treated",
            outcome_col="outcome",
            time_col="time",
            unit_col="unit",
        )

        result = evaluator.evaluate(panel_data)

        assert result.method == "did"
        assert result.primary_estimate is not None


class TestEdgeCases:
    """Tests for edge cases."""

    def test_summary_before_evaluate(self):
        """Test summary before evaluation."""
        evaluator = PolicyEvaluator(
            method="regression_adjustment", treatment_col="treatment", outcome_col="outcome"
        )

        summary = evaluator.summary()

        assert "No evaluation" in summary

    def test_to_dict_before_evaluate(self):
        """Test to_dict before evaluation."""
        evaluator = PolicyEvaluator(
            method="regression_adjustment", treatment_col="treatment", outcome_col="outcome"
        )

        with pytest.raises(EstimationError):
            evaluator.to_dict()
