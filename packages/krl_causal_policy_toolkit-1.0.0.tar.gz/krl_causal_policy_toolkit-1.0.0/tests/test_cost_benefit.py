# ----------------------------------------------------------------------
# © 2025 KR-Labs. All rights reserved.
# KR-Labs™ is a trademark of Quipu Research Labs, LLC,
# a subsidiary of Sudiata Giddasira, Inc.
# ----------------------------------------------------------------------
# SPDX-License-Identifier: Apache-2.0

"""Tests for Cost-Benefit Analyzer."""

import numpy as np
import pandas as pd
import pytest

from krl_policy.evaluators.cost_benefit import (
    CashFlow,
    CostBenefitAnalyzer,
    CostBenefitResult,
    DiscountRate,
    DistributionType,
)


class TestCostBenefitAnalyzer:
    """Tests for CostBenefitAnalyzer."""

    def test_init(self):
        """Test initialization."""
        cba = CostBenefitAnalyzer(discount_rate=0.05, time_horizon=10)

        assert cba.discount_rate == 0.05
        assert cba.time_horizon == 10

    def test_invalid_discount_rate(self):
        """Test error with invalid discount rate."""
        with pytest.raises(ValueError):
            CostBenefitAnalyzer(discount_rate=-0.1)

        with pytest.raises(ValueError):
            CostBenefitAnalyzer(discount_rate=1.5)

    def test_add_cost(self):
        """Test adding a cost."""
        cba = CostBenefitAnalyzer()
        cba.add_cost("Initial investment", 1000000, year=0)

        assert len(cba._cash_flows) == 1
        assert cba._cash_flows[0].amount == 1000000
        assert not cba._cash_flows[0].is_benefit

    def test_add_benefit(self):
        """Test adding a benefit."""
        cba = CostBenefitAnalyzer()
        cba.add_benefit("Annual revenue", 200000, year=1)

        assert len(cba._cash_flows) == 1
        assert cba._cash_flows[0].amount == 200000
        assert cba._cash_flows[0].is_benefit

    def test_recurring_cost(self):
        """Test recurring cost."""
        cba = CostBenefitAnalyzer(time_horizon=5)
        cba.add_cost("Operating cost", 50000, year=1, recurring=True)

        # Should create 5 cash flows (years 1-5)
        assert len(cba._cash_flows) == 5

    def test_recurring_with_growth(self):
        """Test recurring cash flow with growth."""
        cba = CostBenefitAnalyzer(time_horizon=3)
        cba.add_benefit("Revenue", 100000, year=1, recurring=True, growth_rate=0.1)

        # Check growth
        assert cba._cash_flows[0].amount == 100000
        assert cba._cash_flows[1].amount == pytest.approx(110000, rel=0.01)
        assert cba._cash_flows[2].amount == pytest.approx(121000, rel=0.01)

    def test_simple_npv_calculation(self):
        """Test basic NPV calculation."""
        cba = CostBenefitAnalyzer(discount_rate=0.05, time_horizon=3)

        # Initial cost
        cba.add_cost("Investment", 1000, year=0)

        # Benefits
        cba.add_benefit("Year 1", 400, year=1)
        cba.add_benefit("Year 2", 400, year=2)
        cba.add_benefit("Year 3", 400, year=3)

        result = cba.analyze()

        assert isinstance(result, CostBenefitResult)
        assert result.npv > 0  # Should be profitable
        assert result.bcr > 1  # Benefits > costs
        assert result.total_costs == 1000  # No discounting on year 0
        assert result.total_benefits > 1000

    def test_negative_npv(self):
        """Test with negative NPV."""
        cba = CostBenefitAnalyzer(discount_rate=0.1)

        cba.add_cost("High cost", 10000, year=0)
        cba.add_benefit("Low benefit", 500, year=1, recurring=True)

        result = cba.analyze()

        assert result.npv < 0
        assert result.bcr < 1
        assert not result.is_cost_effective

    def test_irr_calculation(self):
        """Test IRR calculation."""
        cba = CostBenefitAnalyzer(discount_rate=0.05, time_horizon=5)

        # Classic investment pattern
        cba.add_cost("Investment", 1000, year=0)
        cba.add_benefit("Returns", 300, year=1, recurring=True)

        result = cba.analyze()

        # IRR should exist for this pattern
        assert result.irr is not None
        assert result.irr > 0

    def test_sensitivity_analysis(self):
        """Test one-way sensitivity analysis."""
        cba = CostBenefitAnalyzer(discount_rate=0.05, time_horizon=3)

        cba.add_cost("Investment", 1000, year=0)
        cba.add_benefit("Revenue", 500, year=1, recurring=True)

        # Run sensitivity on discount rate
        sens = cba.sensitivity_analysis("discount_rate", n_values=5)

        assert sens.parameter == "discount_rate"
        assert len(sens.values) == 5
        assert len(sens.npv_values) == 5
        assert len(sens.bcr_values) == 5

    def test_tornado_analysis(self):
        """Test tornado analysis."""
        cba = CostBenefitAnalyzer(discount_rate=0.05, time_horizon=3)

        cba.add_cost("Investment", 1000, year=0)
        cba.add_benefit("Revenue", 500, year=1, recurring=True)
        cba.add_cost("Operating", 100, year=1, recurring=True)

        results = cba.tornado_analysis(percentage_range=0.2)

        assert len(results) > 0
        # Results should be sorted by impact
        if len(results) > 1:
            impact_0 = max(results[0].npv_values) - min(results[0].npv_values)
            impact_1 = max(results[1].npv_values) - min(results[1].npv_values)
            assert impact_0 >= impact_1

    def test_monte_carlo_simulation(self):
        """Test Monte Carlo simulation."""
        cba = CostBenefitAnalyzer(discount_rate=0.05, time_horizon=3)

        # Add cash flows with uncertainty
        cba.add_cost(
            "Investment", 1000, year=0, distribution="normal", distribution_params={"std": 100}
        )
        cba.add_benefit(
            "Revenue",
            600,
            year=1,
            recurring=True,
            distribution="normal",
            distribution_params={"std": 50},
        )

        mc_result = cba.monte_carlo_simulation(n_simulations=1000, random_seed=42)

        assert len(mc_result.npv_distribution) == 1000
        assert len(mc_result.bcr_distribution) == 1000
        assert mc_result.mean_npv > 0
        assert mc_result.std_npv > 0
        assert 0 <= mc_result.prob_positive_npv <= 1
        assert len(mc_result.confidence_interval) == 2

    def test_distributional_analysis(self):
        """Test distributional analysis by group."""
        cba = CostBenefitAnalyzer(discount_rate=0.05, time_horizon=3)

        cba.add_cost("Investment", 1000, year=0, group="Government")
        cba.add_benefit("Revenue", 800, year=1, recurring=True, group="Consumers")
        cba.add_benefit("Tax revenue", 200, year=1, recurring=True, group="Government")

        dist_result = cba.distributional_analysis()

        assert "Government" in dist_result.group_impacts
        assert "Consumers" in dist_result.group_impacts
        assert len(dist_result.winners) > 0

    def test_break_even_analysis(self):
        """Test break-even analysis."""
        cba = CostBenefitAnalyzer(discount_rate=0.05, time_horizon=3)

        cba.add_cost("Investment", 1000, year=0)
        cba.add_benefit("Revenue", 400, year=1, recurring=True)

        threshold = cba.break_even_analysis("Revenue")

        # Should find a threshold
        assert threshold is not None or threshold is None  # May or may not find one

    def test_summary(self):
        """Test summary generation."""
        cba = CostBenefitAnalyzer(discount_rate=0.05, time_horizon=3)

        cba.add_cost("Investment", 1000, year=0)
        cba.add_benefit("Revenue", 500, year=1, recurring=True)

        summary = cba.summary()

        assert isinstance(summary, str)
        assert "Net Present Value" in summary
        assert "Benefit-Cost Ratio" in summary

    def test_to_dataframe(self):
        """Test export to DataFrame."""
        cba = CostBenefitAnalyzer(discount_rate=0.05, time_horizon=3)

        cba.add_cost("Investment", 1000, year=0)
        cba.add_benefit("Revenue", 500, year=1, recurring=True)

        cba.analyze()
        df = cba.to_dataframe()

        assert isinstance(df, pd.DataFrame)
        assert len(df) > 0
        assert "name" in df.columns
        assert "amount" in df.columns
        assert "pv" in df.columns


class TestCashFlow:
    """Tests for CashFlow class."""

    def test_cash_flow_init(self):
        """Test CashFlow initialization."""
        cf = CashFlow(name="Test", amount=1000, year=1, is_benefit=True)

        assert cf.name == "Test"
        assert cf.amount == 1000
        assert cf.year == 1
        assert cf.is_benefit

    def test_point_distribution_sample(self):
        """Test sampling from point distribution."""
        cf = CashFlow(name="Test", amount=1000, year=1, distribution=DistributionType.POINT)

        samples = cf.sample(100)

        assert len(samples) == 100
        assert np.all(samples == 1000)

    def test_normal_distribution_sample(self):
        """Test sampling from normal distribution."""
        cf = CashFlow(
            name="Test",
            amount=1000,
            year=1,
            distribution=DistributionType.NORMAL,
            distribution_params={"std": 100},
        )

        np.random.seed(42)
        samples = cf.sample(1000)

        assert len(samples) == 1000
        assert np.abs(np.mean(samples) - 1000) < 50  # Close to mean
        assert 50 < np.std(samples) < 150  # Reasonable std

    def test_uniform_distribution_sample(self):
        """Test sampling from uniform distribution."""
        cf = CashFlow(
            name="Test",
            amount=1000,
            year=1,
            distribution=DistributionType.UNIFORM,
            distribution_params={"low": 800, "high": 1200},
        )

        np.random.seed(42)
        samples = cf.sample(1000)

        assert np.all(samples >= 800)
        assert np.all(samples <= 1200)

    def test_triangular_distribution_sample(self):
        """Test sampling from triangular distribution."""
        cf = CashFlow(
            name="Test",
            amount=1000,
            year=1,
            distribution=DistributionType.TRIANGULAR,
            distribution_params={"low": 700, "mode": 1000, "high": 1300},
        )

        np.random.seed(42)
        samples = cf.sample(1000)

        assert np.all(samples >= 700)
        assert np.all(samples <= 1300)


class TestEdgeCases:
    """Tests for edge cases."""

    def test_no_cash_flows(self):
        """Test error when analyzing with no cash flows."""
        cba = CostBenefitAnalyzer()

        with pytest.raises(ValueError, match="No cash flows"):
            cba.analyze()

    def test_zero_costs(self):
        """Test with zero costs."""
        cba = CostBenefitAnalyzer()
        cba.add_benefit("Revenue", 1000, year=1)

        result = cba.analyze()

        assert result.bcr == float("inf")
        assert result.npv > 0

    def test_payback_period(self):
        """Test payback period calculation."""
        cba = CostBenefitAnalyzer(discount_rate=0.05, time_horizon=5)

        cba.add_cost("Investment", 1000, year=0)
        cba.add_benefit("Revenue", 300, year=1, recurring=True)

        result = cba.analyze()

        # Should have a payback period
        assert result.payback_period is not None
        assert result.payback_period > 0
