# ----------------------------------------------------------------------
# © 2025 KR-Labs. All rights reserved.
# KR-Labs™ is a trademark of Quipu Research Labs, LLC,
# a subsidiary of Sudiata Giddasira, Inc.
# ----------------------------------------------------------------------
# SPDX-License-Identifier: Apache-2.0

"""
Tests for Instrumental Variables estimator.
"""

import numpy as np
import pandas as pd
import pytest

from krl_policy.core.base import (
    CausalEstimate,
    DataValidationError,
    EffectType,
    EstimationMethod,
)
from krl_policy.estimators.iv import (
    InstrumentalVariables,
    IVDiagnostics,
    IVMethod,
    IVResult,
)

# =============================================================================
# Fixtures
# =============================================================================


@pytest.fixture
def iv_data():
    """Create data for IV estimation."""
    np.random.seed(42)
    n = 1000

    # Instrument (exogenous)
    z = np.random.normal(0, 1, n)

    # Unobserved confounder
    u = np.random.normal(0, 1, n)

    # Endogenous treatment (affected by instrument and confounder)
    d = 0.5 * z + 0.5 * u + np.random.normal(0, 0.5, n)

    # True treatment effect
    true_effect = 2.0

    # Outcome (affected by treatment, confounder, and noise)
    y = true_effect * d + 1.0 * u + np.random.normal(0, 1, n)

    data = pd.DataFrame(
        {
            "instrument": z,
            "treatment": d,
            "outcome": y,
        }
    )

    return data, true_effect


@pytest.fixture
def iv_data_with_covariates():
    """Create IV data with covariates."""
    np.random.seed(42)
    n = 1000

    # Covariates
    x1 = np.random.normal(0, 1, n)
    x2 = np.random.binomial(1, 0.5, n)

    # Instrument
    z = np.random.normal(0, 1, n)

    # Unobserved confounder
    u = np.random.normal(0, 1, n)

    # Treatment
    d = 0.5 * z + 0.3 * x1 + 0.5 * u + np.random.normal(0, 0.5, n)

    # True effect
    true_effect = 2.5

    # Outcome
    y = true_effect * d + x1 + 2 * x2 + u + np.random.normal(0, 1, n)

    data = pd.DataFrame(
        {
            "x1": x1,
            "x2": x2,
            "instrument": z,
            "treatment": d,
            "outcome": y,
        }
    )

    return data, true_effect


@pytest.fixture
def iv_data_multiple_instruments():
    """Create IV data with multiple instruments."""
    np.random.seed(42)
    n = 1000

    # Multiple instruments
    z1 = np.random.normal(0, 1, n)
    z2 = np.random.normal(0, 1, n)
    z3 = np.random.normal(0, 1, n)

    # Unobserved confounder
    u = np.random.normal(0, 1, n)

    # Treatment
    d = 0.3 * z1 + 0.3 * z2 + 0.2 * z3 + 0.5 * u + np.random.normal(0, 0.5, n)

    # True effect
    true_effect = 1.5

    # Outcome
    y = true_effect * d + u + np.random.normal(0, 1, n)

    data = pd.DataFrame(
        {
            "z1": z1,
            "z2": z2,
            "z3": z3,
            "treatment": d,
            "outcome": y,
        }
    )

    return data, true_effect


@pytest.fixture
def weak_instrument_data():
    """Create data with weak instrument."""
    np.random.seed(42)
    n = 500

    # Weak instrument (low correlation with treatment)
    z = np.random.normal(0, 1, n)

    # Unobserved confounder
    u = np.random.normal(0, 1, n)

    # Treatment (weakly affected by instrument)
    d = 0.05 * z + 0.9 * u + np.random.normal(0, 1, n)  # Very weak first stage

    # Outcome
    y = 2.0 * d + u + np.random.normal(0, 1, n)

    data = pd.DataFrame(
        {
            "instrument": z,
            "treatment": d,
            "outcome": y,
        }
    )

    return data


# =============================================================================
# Test InstrumentalVariables
# =============================================================================


class TestInstrumentalVariables:
    """Tests for InstrumentalVariables estimator."""

    def test_init(self):
        """Test IV initialization."""
        iv = InstrumentalVariables(
            treatment_col="treatment",
            outcome_col="outcome",
            instruments=["z1", "z2"],
            method="2sls",
        )

        assert iv.config.treatment_col == "treatment"
        assert iv.instruments == ["z1", "z2"]
        assert iv.method == "2sls"
        assert not iv.is_fitted

    def test_init_requires_instruments(self):
        """Test that instruments are required."""
        with pytest.raises(ValueError, match="At least one instrument"):
            InstrumentalVariables(
                treatment_col="treatment",
                outcome_col="outcome",
                instruments=None,
            )

    def test_invalid_method(self):
        """Test error on invalid method."""
        with pytest.raises(ValueError, match="Method must be one of"):
            InstrumentalVariables(
                treatment_col="treatment",
                outcome_col="outcome",
                instruments=["z"],
                method="invalid",
            )

    def test_fit_2sls(self, iv_data):
        """Test 2SLS estimation."""
        data, true_effect = iv_data

        iv = InstrumentalVariables(
            treatment_col="treatment",
            outcome_col="outcome",
            instruments=["instrument"],
            method="2sls",
            n_bootstrap=100,
            random_state=42,
        )

        result = iv.fit(data)

        assert iv.is_fitted
        assert result is not None
        assert isinstance(result.ate, CausalEstimate)

        # IV estimate should be closer to true effect than OLS would be
        # (OLS would be biased due to endogeneity)
        assert abs(result.ate.estimate - true_effect) < 1.0

    def test_fit_liml(self, iv_data):
        """Test LIML estimation."""
        data, true_effect = iv_data

        iv = InstrumentalVariables(
            treatment_col="treatment",
            outcome_col="outcome",
            instruments=["instrument"],
            method="liml",
            n_bootstrap=100,
            random_state=42,
        )

        result = iv.fit(data)

        assert iv.is_fitted
        assert result is not None

        # LIML should be similar to 2SLS with strong instruments
        assert abs(result.ate.estimate - true_effect) < 1.5

    def test_fit_gmm(self, iv_data):
        """Test GMM estimation."""
        data, true_effect = iv_data

        iv = InstrumentalVariables(
            treatment_col="treatment",
            outcome_col="outcome",
            instruments=["instrument"],
            method="gmm",
            n_bootstrap=100,
            random_state=42,
        )

        result = iv.fit(data)

        assert iv.is_fitted
        assert result is not None

    def test_with_covariates(self, iv_data_with_covariates):
        """Test IV with covariates."""
        data, true_effect = iv_data_with_covariates

        iv = InstrumentalVariables(
            treatment_col="treatment",
            outcome_col="outcome",
            instruments=["instrument"],
            covariates=["x1", "x2"],
            method="2sls",
            n_bootstrap=100,
            random_state=42,
        )

        result = iv.fit(data)

        assert iv.is_fitted
        assert abs(result.ate.estimate - true_effect) < 1.5

    def test_multiple_instruments(self, iv_data_multiple_instruments):
        """Test IV with multiple instruments."""
        data, true_effect = iv_data_multiple_instruments

        iv = InstrumentalVariables(
            treatment_col="treatment",
            outcome_col="outcome",
            instruments=["z1", "z2", "z3"],
            method="2sls",
            n_bootstrap=100,
            random_state=42,
        )

        result = iv.fit(data)

        assert iv.is_fitted
        assert abs(result.ate.estimate - true_effect) < 1.0

    def test_get_first_stage(self, iv_data):
        """Test getting first stage results."""
        data, _ = iv_data

        iv = InstrumentalVariables(
            treatment_col="treatment",
            outcome_col="outcome",
            instruments=["instrument"],
            method="2sls",
            n_bootstrap=50,
            random_state=42,
        )

        iv.fit(data)
        first_stage = iv.get_first_stage()

        assert "coefficients" in first_stage
        assert "fitted_values" in first_stage
        assert "f_statistic" in first_stage

        # First stage F should be strong
        assert first_stage["f_statistic"] > 10

    def test_get_diagnostics(self, iv_data):
        """Test getting IV diagnostics."""
        data, _ = iv_data

        iv = InstrumentalVariables(
            treatment_col="treatment",
            outcome_col="outcome",
            instruments=["instrument"],
            method="2sls",
            n_bootstrap=50,
            random_state=42,
        )

        iv.fit(data)
        diagnostics = iv.get_diagnostics()

        assert isinstance(diagnostics, IVDiagnostics)
        assert diagnostics.first_stage_f > 0
        assert not diagnostics.weak_instrument  # Should be strong instrument

    def test_weak_instrument_detection(self, weak_instrument_data):
        """Test weak instrument detection."""
        data = weak_instrument_data

        iv = InstrumentalVariables(
            treatment_col="treatment",
            outcome_col="outcome",
            instruments=["instrument"],
            method="2sls",
            n_bootstrap=50,
            random_state=42,
        )

        result = iv.fit(data)
        diagnostics = iv.get_diagnostics()

        # Should detect weak instrument
        assert diagnostics.weak_instrument
        assert diagnostics.first_stage_f < 10

        # Should have warning
        assert any("Weak instrument" in w for w in result.diagnostics.warnings)

    def test_estimate_ate(self, iv_data):
        """Test estimate_ate method."""
        data, _ = iv_data

        iv = InstrumentalVariables(
            treatment_col="treatment",
            outcome_col="outcome",
            instruments=["instrument"],
            method="2sls",
            n_bootstrap=50,
            random_state=42,
        )

        iv.fit(data)
        ate = iv.estimate_ate()

        assert isinstance(ate, CausalEstimate)
        assert ate.effect_type == EffectType.LATE  # IV estimates LATE

    def test_overidentification_test(self, iv_data_multiple_instruments):
        """Test overidentification (Sargan) test with valid instruments."""
        data, _ = iv_data_multiple_instruments

        iv = InstrumentalVariables(
            treatment_col="treatment",
            outcome_col="outcome",
            instruments=["z1", "z2", "z3"],
            method="2sls",
            n_bootstrap=50,
            random_state=42,
        )

        iv.fit(data)
        diagnostics = iv.get_diagnostics()

        # Sargan test should be available (overidentified)
        assert not np.isnan(diagnostics.sargan_statistic)
        assert not np.isnan(diagnostics.sargan_pvalue)

        # Sargan test produces a statistic - p-value depends on data
        # Just verify the test runs and returns values
        assert 0 <= diagnostics.sargan_pvalue <= 1

    def test_missing_instrument_column(self, iv_data):
        """Test error when instrument column missing."""
        data, _ = iv_data
        data_missing = data.drop(columns=["instrument"])

        iv = InstrumentalVariables(
            treatment_col="treatment",
            outcome_col="outcome",
            instruments=["instrument"],
        )

        with pytest.raises(DataValidationError, match="Missing required columns"):
            iv.fit(data_missing)


# =============================================================================
# Test Diagnostics
# =============================================================================


class TestIVDiagnostics:
    """Tests for IVDiagnostics dataclass."""

    def test_diagnostics_creation(self):
        """Test IVDiagnostics creation."""
        diag = IVDiagnostics(
            first_stage_f=25.0,
            weak_instrument=False,
            sargan_statistic=1.5,
            sargan_pvalue=0.47,
            durbin_wu_hausman=8.2,
            dwh_pvalue=0.004,
            partial_r2=0.15,
        )

        assert diag.first_stage_f == 25.0
        assert not diag.weak_instrument
        assert diag.partial_r2 == 0.15


# =============================================================================
# Test Enums
# =============================================================================


class TestIVEnums:
    """Tests for IV enums."""

    def test_iv_method_enum(self):
        """Test IVMethod enum."""
        assert IVMethod.TSLS.value == "2sls"
        assert IVMethod.LIML.value == "liml"
        assert IVMethod.GMM.value == "gmm"
