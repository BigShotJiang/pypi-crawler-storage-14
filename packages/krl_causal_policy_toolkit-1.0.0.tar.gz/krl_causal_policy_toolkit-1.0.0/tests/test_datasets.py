# ----------------------------------------------------------------------
# © 2025 KR-Labs. All rights reserved.
# KR-Labs™ is a trademark of Quipu Research Labs, LLC,
# a subsidiary of Sudiata Giddasira, Inc.
# ----------------------------------------------------------------------
# SPDX-License-Identifier: Apache-2.0

"""
Unit tests for synthetic data generators.

Tests cover:
- Data generator configurations
- Perfect RCT data generation
- Confounded observational data
- Heterogeneous treatment effect data
- Panel data generation
- Regression discontinuity data
"""

import numpy as np
import pandas as pd
import pytest

from krl_policy.datasets import (
    ConfoundedObservationalGenerator,
    DataGeneratorConfig,
    HeterogeneousTreatmentEffectGenerator,
    PanelDataGenerator,
    PerfectRCTGenerator,
    RegressionDiscontinuityGenerator,
    SyntheticDataGenerator,
    make_confounded_data,
    make_panel_data,
    make_rct_data,
)


class TestDataGeneratorConfig:
    """Test configuration class."""

    def test_default_config(self):
        """Test default configuration values."""
        config = DataGeneratorConfig()

        assert config.n_samples == 1000
        assert config.n_features == 5
        assert config.true_ate == 2.0
        assert config.noise_std == 1.0
        assert config.treatment_probability == 0.5
        assert config.random_state is None

    def test_custom_config(self):
        """Test custom configuration."""
        config = DataGeneratorConfig(
            n_samples=500, n_features=10, true_ate=3.0, noise_std=0.5, random_state=42
        )

        assert config.n_samples == 500
        assert config.n_features == 10
        assert config.true_ate == 3.0
        assert config.noise_std == 0.5
        assert config.random_state == 42


class TestPerfectRCTGenerator:
    """Test perfect RCT data generator."""

    def test_generate_creates_dataframe(self, small_config):
        """Test generate returns DataFrame."""
        gen = PerfectRCTGenerator(small_config)
        data = gen.generate()

        assert isinstance(data, pd.DataFrame)
        assert len(data) == small_config.n_samples

    def test_has_required_columns(self, small_config):
        """Test generated data has required columns."""
        gen = PerfectRCTGenerator(small_config)
        data = gen.generate()

        # Check for covariates
        for i in range(small_config.n_features):
            assert f"X{i}" in data.columns

        # Check for treatment and outcome
        assert "T" in data.columns
        assert "Y" in data.columns

    def test_treatment_is_binary(self, small_config):
        """Test treatment is binary."""
        gen = PerfectRCTGenerator(small_config)
        data = gen.generate()

        assert data["T"].isin([0, 1]).all()

    def test_treatment_probability(self, medium_config):
        """Test treatment probability is roughly correct."""
        gen = PerfectRCTGenerator(medium_config)
        data = gen.generate()

        actual_prob = data["T"].mean()
        expected_prob = medium_config.treatment_probability

        # Should be within reasonable range
        assert abs(actual_prob - expected_prob) < 0.1

    def test_true_ate_property(self, small_config):
        """Test true_ate property."""
        gen = PerfectRCTGenerator(small_config)
        gen.generate()

        assert gen.true_ate == small_config.true_ate

    def test_true_effects_property(self, small_config):
        """Test true_effects property."""
        gen = PerfectRCTGenerator(small_config)
        gen.generate()

        effects = gen.true_effects
        assert len(effects) == small_config.n_samples
        # For perfect RCT, all effects should be constant
        assert np.allclose(effects, small_config.true_ate)

    def test_reproducibility(self, random_state):
        """Test reproducibility with random state."""
        config = DataGeneratorConfig(n_samples=100, random_state=random_state)

        gen1 = PerfectRCTGenerator(config)
        gen2 = PerfectRCTGenerator(config)

        data1 = gen1.generate()
        data2 = gen2.generate()

        pd.testing.assert_frame_equal(data1, data2)


class TestConfoundedObservationalGenerator:
    """Test confounded observational data generator."""

    def test_generate_creates_dataframe(self, small_config):
        """Test generate returns DataFrame."""
        gen = ConfoundedObservationalGenerator(small_config)
        data = gen.generate()

        assert isinstance(data, pd.DataFrame)
        assert len(data) == small_config.n_samples

    def test_propensity_scores_included(self, small_config):
        """Test propensity scores are included."""
        gen = ConfoundedObservationalGenerator(small_config)
        data = gen.generate()

        assert "propensity_score_true" in data.columns

        # Propensity scores should be between 0 and 1
        assert (data["propensity_score_true"] >= 0).all()
        assert (data["propensity_score_true"] <= 1).all()

    def test_confounding_strength_effect(self, medium_config):
        """Test confounding strength affects treatment assignment."""
        gen_weak = ConfoundedObservationalGenerator(medium_config, confounding_strength=0.1)
        gen_strong = ConfoundedObservationalGenerator(medium_config, confounding_strength=0.9)

        data_weak = gen_weak.generate()
        data_strong = gen_strong.generate()

        # Stronger confounding should have more variation in propensity scores
        ps_weak_std = data_weak["propensity_score_true"].std()
        ps_strong_std = data_strong["propensity_score_true"].std()

        assert ps_strong_std > ps_weak_std

    def test_naive_estimator_biased(self, medium_config):
        """Test that naive DiM is biased on confounded data."""
        gen = ConfoundedObservationalGenerator(medium_config, confounding_strength=0.8)
        data = gen.generate()

        # Naive difference in means
        naive_ate = data[data["T"] == 1]["Y"].mean() - data[data["T"] == 0]["Y"].mean()

        # With confounding, naive estimate should differ from true ATE
        true_ate = gen.true_ate

        # Can't guarantee which direction, but should often differ
        # This is a weak test - just checking the setup works


class TestHeterogeneousTreatmentEffectGenerator:
    """Test heterogeneous treatment effect generator."""

    def test_generate_creates_dataframe(self, small_config):
        """Test generate returns DataFrame."""
        gen = HeterogeneousTreatmentEffectGenerator(small_config)
        data = gen.generate()

        assert isinstance(data, pd.DataFrame)
        assert len(data) == small_config.n_samples

    def test_true_effects_vary(self, medium_config):
        """Test true effects vary across individuals."""
        gen = HeterogeneousTreatmentEffectGenerator(medium_config, effect_heterogeneity=1.0)
        data = gen.generate()

        effects = gen.true_effects

        # Effects should vary
        assert effects.std() > 0

    def test_true_tau_in_data(self, small_config):
        """Test true tau is in data."""
        gen = HeterogeneousTreatmentEffectGenerator(small_config)
        data = gen.generate()

        assert "tau_true" in data.columns

    def test_average_effect_near_ate(self, large_config):
        """Test average of heterogeneous effects near ATE."""
        gen = HeterogeneousTreatmentEffectGenerator(large_config, effect_heterogeneity=0.5)
        gen.generate()

        mean_effect = gen.true_effects.mean()

        # Should be close to configured ATE
        assert abs(mean_effect - large_config.true_ate) < 0.5


class TestPanelDataGenerator:
    """Test panel data generator."""

    def test_generate_creates_panel(self):
        """Test generate creates panel data."""
        gen = PanelDataGenerator(n_units=10, n_periods=5)
        data = gen.generate()

        assert isinstance(data, pd.DataFrame)
        assert len(data) == 10 * 5  # n_units * n_periods

    def test_has_panel_columns(self):
        """Test has unit and time columns."""
        gen = PanelDataGenerator(n_units=10, n_periods=5)
        data = gen.generate()

        assert "unit" in data.columns
        assert "time" in data.columns
        assert "T" in data.columns
        assert "Y" in data.columns

    def test_mid_treatment_timing(self):
        """Test mid-point treatment timing."""
        gen = PanelDataGenerator(
            n_units=10, n_periods=10, treatment_timing="mid", treatment_fraction=0.5
        )
        data = gen.generate()

        # Treatment should only appear in second half
        early_treatment = data[data["time"] < 5]["T"].sum()
        late_treatment = data[data["time"] >= 5]["T"].sum()

        assert early_treatment == 0
        assert late_treatment > 0

    def test_staggered_treatment_timing(self):
        """Test staggered treatment adoption."""
        gen = PanelDataGenerator(
            n_units=20, n_periods=10, treatment_timing="staggered", treatment_fraction=0.5
        )
        data = gen.generate()

        # Find first treatment time for each unit
        treated_units = data[data["T"] == 1].groupby("unit")["time"].min()

        if len(treated_units) > 1:
            # Should have variation in treatment timing
            # Not guaranteed but likely with staggered design
            pass


class TestRegressionDiscontinuityGenerator:
    """Test RD data generator."""

    def test_generate_creates_dataframe(self):
        """Test generate returns DataFrame."""
        gen = RegressionDiscontinuityGenerator()
        data = gen.generate()

        assert isinstance(data, pd.DataFrame)

    def test_has_running_variable(self):
        """Test has running variable."""
        gen = RegressionDiscontinuityGenerator(threshold=0.5)
        data = gen.generate()

        assert "R" in data.columns
        assert "T" in data.columns
        assert "distance_to_threshold" in data.columns

    def test_sharp_cutoff(self):
        """Test sharp RD design."""
        gen = RegressionDiscontinuityGenerator(threshold=0.5)
        data = gen.generate()

        # Treatment should be 1 iff R >= threshold
        below_threshold = data[data["R"] < 0.5]["T"]
        above_threshold = data[data["R"] >= 0.5]["T"]

        assert (below_threshold == 0).all()
        assert (above_threshold == 1).all()


class TestFactoryFunctions:
    """Test convenience factory functions."""

    def test_make_rct_data(self):
        """Test make_rct_data function."""
        data, true_ate = make_rct_data(n_samples=100, n_features=3, true_ate=2.5, random_state=42)

        assert isinstance(data, pd.DataFrame)
        assert len(data) == 100
        assert true_ate == 2.5

    def test_make_confounded_data(self):
        """Test make_confounded_data function."""
        data, true_ate = make_confounded_data(
            n_samples=100, confounding_strength=0.5, random_state=42
        )

        assert isinstance(data, pd.DataFrame)
        assert "propensity_score_true" in data.columns

    def test_make_panel_data(self):
        """Test make_panel_data function."""
        data, true_ate = make_panel_data(n_units=10, n_periods=5, true_ate=2.0, random_state=42)

        assert isinstance(data, pd.DataFrame)
        assert len(data) == 50  # 10 * 5
        assert true_ate == 2.0
