# ----------------------------------------------------------------------
# © 2025 KR-Labs. All rights reserved.
# KR-Labs™ is a trademark of Quipu Research Labs, LLC,
# a subsidiary of Sudiata Giddasira, Inc.
# ----------------------------------------------------------------------
# SPDX-License-Identifier: Apache-2.0

"""
Tests for Matching estimators (PSM and Covariate Matching).
"""

import numpy as np
import pandas as pd
import pytest

from krl_policy.core.base import (
    CausalEstimate,
    DataValidationError,
    EffectType,
    EstimationMethod,
)
from krl_policy.estimators.matching import (
    CovariateMatching,
    MatchingMethod,
    MatchingResult,
    PropensityScoreMatching,
    ReplacementMode,
)

# =============================================================================
# Fixtures
# =============================================================================


@pytest.fixture
def matching_data():
    """Create data for matching estimation."""
    np.random.seed(42)
    n = 500

    # Covariates
    age = np.random.normal(40, 10, n)
    income = np.random.normal(50000, 15000, n)
    education = np.random.choice([1, 2, 3, 4], n, p=[0.2, 0.3, 0.3, 0.2])

    # Treatment probability depends on covariates (confounding)
    propensity = 1 / (
        1 + np.exp(-(-2 + 0.05 * (age - 40) + 0.00002 * (income - 50000) + 0.3 * education))
    )
    treatment = np.random.binomial(1, propensity)

    # True treatment effect
    true_effect = 3.0

    # Outcome depends on covariates and treatment
    outcome = (
        10
        + 0.1 * age
        + 0.0001 * income
        + 1.5 * education
        + true_effect * treatment
        + np.random.normal(0, 2, n)
    )

    data = pd.DataFrame(
        {
            "age": age,
            "income": income,
            "education": education,
            "treatment": treatment,
            "outcome": outcome,
        }
    )

    return data, true_effect


@pytest.fixture
def matching_data_large():
    """Create larger dataset for matching."""
    np.random.seed(42)
    n = 2000

    # More covariates
    x1 = np.random.normal(0, 1, n)
    x2 = np.random.normal(0, 1, n)
    x3 = np.random.normal(0, 1, n)
    x4 = np.random.binomial(1, 0.5, n)

    # Treatment
    propensity = 1 / (1 + np.exp(-(-1 + x1 + 0.5 * x2 - 0.3 * x3 + x4)))
    treatment = np.random.binomial(1, propensity)

    # Outcome
    true_effect = 2.5
    outcome = 5 + x1 + x2 - x3 + 2 * x4 + true_effect * treatment + np.random.normal(0, 1, n)

    data = pd.DataFrame(
        {
            "x1": x1,
            "x2": x2,
            "x3": x3,
            "x4": x4,
            "treatment": treatment,
            "outcome": outcome,
        }
    )

    return data, true_effect


# =============================================================================
# Test PropensityScoreMatching
# =============================================================================


class TestPropensityScoreMatching:
    """Tests for PropensityScoreMatching estimator."""

    def test_init(self):
        """Test PSM initialization."""
        psm = PropensityScoreMatching(
            treatment_col="treatment",
            outcome_col="outcome",
            covariates=["x1", "x2"],
            n_matches=1,
        )

        assert psm.config.treatment_col == "treatment"
        assert psm.n_matches == 1
        assert not psm.is_fitted

    def test_init_requires_covariates(self):
        """Test that covariates are required."""
        with pytest.raises(ValueError, match="covariates must be specified"):
            PropensityScoreMatching(
                treatment_col="treatment",
                outcome_col="outcome",
                covariates=None,
            )

    def test_fit_basic(self, matching_data):
        """Test basic PSM fitting."""
        data, true_effect = matching_data

        psm = PropensityScoreMatching(
            treatment_col="treatment",
            outcome_col="outcome",
            covariates=["age", "income", "education"],
            n_matches=1,
            n_bootstrap=100,
            random_state=42,
        )

        result = psm.fit(data)

        assert psm.is_fitted
        assert result is not None
        assert isinstance(result.ate, CausalEstimate)

        # Estimate should be in reasonable range of true effect
        assert abs(result.ate.estimate - true_effect) < 2.0

    def test_fit_with_caliper(self, matching_data):
        """Test PSM with caliper."""
        data, true_effect = matching_data

        psm = PropensityScoreMatching(
            treatment_col="treatment",
            outcome_col="outcome",
            covariates=["age", "income", "education"],
            n_matches=1,
            caliper=0.1,
            n_bootstrap=100,
            random_state=42,
        )

        result = psm.fit(data)

        assert psm.is_fitted
        # With caliper, some units might be dropped
        diagnostics = result.diagnostics
        assert diagnostics.model_fit is not None

    def test_matching_without_replacement(self, matching_data):
        """Test PSM without replacement."""
        data, true_effect = matching_data

        psm = PropensityScoreMatching(
            treatment_col="treatment",
            outcome_col="outcome",
            covariates=["age", "income", "education"],
            n_matches=1,
            replacement="without",
            n_bootstrap=100,
            random_state=42,
        )

        result = psm.fit(data)

        assert psm.is_fitted

        # Check no control used more than once
        pairs = psm.get_matched_pairs()
        assert pairs["control_idx"].nunique() == len(pairs)

    def test_multiple_matches(self, matching_data_large):
        """Test PSM with multiple matches."""
        data, true_effect = matching_data_large

        psm = PropensityScoreMatching(
            treatment_col="treatment",
            outcome_col="outcome",
            covariates=["x1", "x2", "x3", "x4"],
            n_matches=3,
            n_bootstrap=100,
            random_state=42,
        )

        result = psm.fit(data)

        assert psm.is_fitted
        pairs = psm.get_matched_pairs()

        # Each treated unit should have up to n_matches controls
        matches_per_treated = pairs.groupby("treated_idx").size()
        assert (matches_per_treated <= 3).all()

    def test_get_propensity_scores(self, matching_data):
        """Test getting propensity scores."""
        data, _ = matching_data

        psm = PropensityScoreMatching(
            treatment_col="treatment",
            outcome_col="outcome",
            covariates=["age", "income", "education"],
            n_bootstrap=50,
            random_state=42,
        )

        psm.fit(data)
        ps = psm.get_propensity_scores()

        assert isinstance(ps, pd.Series)
        assert len(ps) == len(data)
        assert (ps >= 0).all() and (ps <= 1).all()

    def test_get_matched_pairs(self, matching_data):
        """Test getting matched pairs."""
        data, _ = matching_data

        psm = PropensityScoreMatching(
            treatment_col="treatment",
            outcome_col="outcome",
            covariates=["age", "income", "education"],
            n_bootstrap=50,
            random_state=42,
        )

        psm.fit(data)
        pairs = psm.get_matched_pairs()

        assert isinstance(pairs, pd.DataFrame)
        assert "treated_idx" in pairs.columns
        assert "control_idx" in pairs.columns
        assert "distance" in pairs.columns

    def test_get_balance_table(self, matching_data):
        """Test getting balance table."""
        data, _ = matching_data

        psm = PropensityScoreMatching(
            treatment_col="treatment",
            outcome_col="outcome",
            covariates=["age", "income", "education"],
            n_bootstrap=50,
            random_state=42,
        )

        psm.fit(data)
        balance = psm.get_balance_table()

        assert isinstance(balance, pd.DataFrame)
        assert "covariate" in balance.columns
        assert "smd_before" in balance.columns
        assert "smd_after" in balance.columns

        # Balance should improve after matching
        assert (balance["smd_after"].abs() <= balance["smd_before"].abs()).mean() > 0.5

    def test_estimate_ate(self, matching_data):
        """Test estimate_ate method."""
        data, _ = matching_data

        psm = PropensityScoreMatching(
            treatment_col="treatment",
            outcome_col="outcome",
            covariates=["age", "income", "education"],
            n_bootstrap=50,
            random_state=42,
        )

        psm.fit(data)
        ate = psm.estimate_ate()

        assert isinstance(ate, CausalEstimate)
        assert ate.effect_type == EffectType.ATE


# =============================================================================
# Test CovariateMatching
# =============================================================================


class TestCovariateMatching:
    """Tests for CovariateMatching estimator."""

    def test_init(self):
        """Test covariate matching initialization."""
        cm = CovariateMatching(
            treatment_col="treatment",
            outcome_col="outcome",
            covariates=["x1", "x2"],
            distance="mahalanobis",
        )

        assert cm.distance == "mahalanobis"
        assert not cm.is_fitted

    def test_init_requires_covariates(self):
        """Test that covariates are required."""
        with pytest.raises(ValueError, match="covariates must be specified"):
            CovariateMatching(
                treatment_col="treatment",
                outcome_col="outcome",
                covariates=None,
            )

    def test_invalid_distance(self):
        """Test error on invalid distance metric."""
        with pytest.raises(ValueError, match="distance must be"):
            CovariateMatching(
                treatment_col="treatment",
                outcome_col="outcome",
                covariates=["x1"],
                distance="invalid",
            )

    def test_fit_mahalanobis(self, matching_data_large):
        """Test Mahalanobis matching."""
        data, true_effect = matching_data_large

        cm = CovariateMatching(
            treatment_col="treatment",
            outcome_col="outcome",
            covariates=["x1", "x2", "x3", "x4"],
            distance="mahalanobis",
            n_bootstrap=100,
            random_state=42,
        )

        result = cm.fit(data)

        assert cm.is_fitted
        assert result is not None
        assert isinstance(result.ate, CausalEstimate)

        # Estimate should be in reasonable range
        assert abs(result.ate.estimate - true_effect) < 2.0

    def test_fit_euclidean(self, matching_data_large):
        """Test Euclidean matching."""
        data, true_effect = matching_data_large

        cm = CovariateMatching(
            treatment_col="treatment",
            outcome_col="outcome",
            covariates=["x1", "x2", "x3", "x4"],
            distance="euclidean",
            n_bootstrap=100,
            random_state=42,
        )

        result = cm.fit(data)

        assert cm.is_fitted
        assert result is not None

    def test_with_caliper(self, matching_data_large):
        """Test matching with caliper."""
        data, _ = matching_data_large

        cm = CovariateMatching(
            treatment_col="treatment",
            outcome_col="outcome",
            covariates=["x1", "x2", "x3", "x4"],
            distance="euclidean",
            caliper=1.0,
            n_bootstrap=50,
            random_state=42,
        )

        result = cm.fit(data)

        assert cm.is_fitted

        # Check distances are within caliper
        pairs = cm._matched_pairs
        assert (pairs["distance"] <= 1.0).all()

    def test_without_replacement(self, matching_data_large):
        """Test matching without replacement."""
        data, _ = matching_data_large

        cm = CovariateMatching(
            treatment_col="treatment",
            outcome_col="outcome",
            covariates=["x1", "x2", "x3", "x4"],
            distance="euclidean",
            replacement="without",
            n_bootstrap=50,
            random_state=42,
        )

        result = cm.fit(data)

        assert cm.is_fitted

        # Check no control used more than once
        pairs = cm._matched_pairs
        assert pairs["control_idx"].nunique() == len(pairs)

    def test_estimate_ate(self, matching_data_large):
        """Test estimate_ate method."""
        data, _ = matching_data_large

        cm = CovariateMatching(
            treatment_col="treatment",
            outcome_col="outcome",
            covariates=["x1", "x2", "x3", "x4"],
            distance="mahalanobis",
            n_bootstrap=50,
            random_state=42,
        )

        cm.fit(data)
        ate = cm.estimate_ate()

        assert isinstance(ate, CausalEstimate)
        assert ate.effect_type == EffectType.ATE


# =============================================================================
# Test Enums
# =============================================================================


class TestEnums:
    """Tests for matching enums."""

    def test_matching_method_enum(self):
        """Test MatchingMethod enum."""
        assert MatchingMethod.PROPENSITY.value == "propensity"
        assert MatchingMethod.MAHALANOBIS.value == "mahalanobis"
        assert MatchingMethod.EUCLIDEAN.value == "euclidean"
        assert MatchingMethod.EXACT.value == "exact"

    def test_replacement_mode_enum(self):
        """Test ReplacementMode enum."""
        assert ReplacementMode.WITH_REPLACEMENT.value == "with"
        assert ReplacementMode.WITHOUT_REPLACEMENT.value == "without"
