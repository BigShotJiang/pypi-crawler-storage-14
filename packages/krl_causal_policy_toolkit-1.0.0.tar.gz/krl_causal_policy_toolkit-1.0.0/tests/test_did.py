# ----------------------------------------------------------------------
# © 2025 KR-Labs. All rights reserved.
# KR-Labs™ is a trademark of Quipu Research Labs, LLC,
# a subsidiary of Sudiata Giddasira, Inc.
# ----------------------------------------------------------------------
# SPDX-License-Identifier: Apache-2.0

"""
Tests for Difference-in-Differences estimator.
"""

import numpy as np
import pandas as pd
import pytest

from krl_policy.core.base import (
    CausalEstimate,
    DataValidationError,
    EffectType,
    EstimationMethod,
)
from krl_policy.estimators.did import (
    DiDResult,
    DifferenceInDifferences,
    EventStudyResult,
)

# =============================================================================
# Fixtures
# =============================================================================


@pytest.fixture
def simple_did_data():
    """Create simple 2x2 DiD data."""
    np.random.seed(42)
    n_units = 50
    n_periods = 10
    treatment_time = 5
    true_effect = 3.0

    # Create panel
    units = np.repeat(np.arange(n_units), n_periods)
    times = np.tile(np.arange(n_periods), n_units)

    # Treatment group (first half of units)
    treatment_group = (units < n_units // 2).astype(int)

    # Post-treatment indicator
    post = (times >= treatment_time).astype(int)

    # Generate outcome
    # Y = unit_fe + time_fe + true_effect * (treated * post) + noise
    unit_fe = np.random.normal(0, 1, n_units)[units]
    time_fe = 0.5 * times

    outcome = (
        unit_fe
        + time_fe
        + true_effect * treatment_group * post
        + np.random.normal(0, 0.5, len(units))
    )

    return (
        pd.DataFrame(
            {
                "unit": units,
                "time": times,
                "treatment": treatment_group,
                "outcome": outcome,
            }
        ),
        true_effect,
        treatment_time,
    )


@pytest.fixture
def staggered_did_data():
    """Create staggered adoption DiD data."""
    np.random.seed(42)
    n_units = 30
    n_periods = 15
    true_effect = 2.5

    # Different treatment timing for different units
    # Units 0-9: never treated
    # Units 10-19: treated at t=5
    # Units 20-29: treated at t=10

    units = np.repeat(np.arange(n_units), n_periods)
    times = np.tile(np.arange(n_periods), n_units)

    treatment_group = np.zeros(len(units), dtype=int)
    treatment_time_unit = np.full(n_units, np.inf)

    # Set treatment timing
    treatment_time_unit[10:20] = 5
    treatment_time_unit[20:30] = 10

    # Create treatment indicator
    for i in range(len(units)):
        u = units[i]
        t = times[i]
        if t >= treatment_time_unit[u]:
            treatment_group[i] = 1

    # Generate outcome
    unit_fe = np.random.normal(0, 1, n_units)[units]
    time_fe = 0.3 * times

    outcome = (
        unit_fe + time_fe + true_effect * treatment_group + np.random.normal(0, 0.5, len(units))
    )

    return (
        pd.DataFrame(
            {
                "unit": units,
                "time": times,
                "treatment": (units >= 10).astype(int),  # Treatment group indicator
                "treated": treatment_group,  # Actual treatment status
                "outcome": outcome,
            }
        ),
        true_effect,
    )


# =============================================================================
# Test DifferenceInDifferences
# =============================================================================


class TestDifferenceInDifferences:
    """Tests for DifferenceInDifferences estimator."""

    def test_init(self):
        """Test DiD initialization."""
        did = DifferenceInDifferences(
            treatment_col="treatment",
            outcome_col="outcome",
            time_col="time",
            unit_col="unit",
            method="twfe",
        )

        assert did.config.treatment_col == "treatment"
        assert did.config.outcome_col == "outcome"
        assert did.method == "twfe"
        assert not did.is_fitted

    def test_invalid_method(self):
        """Test that invalid method raises error."""
        with pytest.raises(ValueError, match="Method must be one of"):
            DifferenceInDifferences(method="invalid")

    def test_classic_did(self, simple_did_data):
        """Test classic 2x2 DiD estimation."""
        data, true_effect, treatment_time = simple_did_data

        did = DifferenceInDifferences(
            treatment_col="treatment",
            outcome_col="outcome",
            time_col="time",
            unit_col="unit",
            treatment_time=treatment_time,
            method="classic",
            n_bootstrap=100,
            random_state=42,
        )

        result = did.fit(data)

        assert did.is_fitted
        assert result is not None
        assert isinstance(result.ate, CausalEstimate)

        # Check estimate is close to true effect
        assert abs(result.ate.estimate - true_effect) < 1.0

        # Check method
        assert result.method == EstimationMethod.DID

    def test_twfe_did(self, simple_did_data):
        """Test two-way fixed effects DiD."""
        data, true_effect, treatment_time = simple_did_data

        did = DifferenceInDifferences(
            treatment_col="treatment",
            outcome_col="outcome",
            time_col="time",
            unit_col="unit",
            treatment_time=treatment_time,
            method="twfe",
            n_bootstrap=100,
            random_state=42,
        )

        result = did.fit(data)

        assert did.is_fitted
        assert abs(result.ate.estimate - true_effect) < 1.0

    def test_event_study(self, simple_did_data):
        """Test event study estimation."""
        data, true_effect, treatment_time = simple_did_data

        did = DifferenceInDifferences(
            treatment_col="treatment",
            outcome_col="outcome",
            time_col="time",
            unit_col="unit",
            treatment_time=treatment_time,
            method="event_study",
            n_bootstrap=100,
            random_state=42,
        )

        result = did.fit(data)

        assert did.is_fitted

        # Get event study results
        es_result = did.event_study(pre_periods=3, post_periods=3)

        assert isinstance(es_result, EventStudyResult)
        assert len(es_result.coefficients) > 0

        # Pre-period coefficients should be close to zero
        for p in es_result.pre_periods:
            if p in es_result.coefficients and p != es_result.reference_period:
                assert abs(es_result.coefficients[p].estimate) < 2.0

        # Post-period coefficients should be close to true effect
        for p in es_result.post_periods:
            if p in es_result.coefficients:
                # Allow some variation
                pass

    def test_parallel_trends_test(self, simple_did_data):
        """Test parallel trends assumption test."""
        data, true_effect, treatment_time = simple_did_data

        did = DifferenceInDifferences(
            treatment_col="treatment",
            outcome_col="outcome",
            time_col="time",
            unit_col="unit",
            treatment_time=treatment_time,
            method="twfe",
            n_bootstrap=50,
            random_state=42,
        )

        did.fit(data)
        pt_result = did.test_parallel_trends()

        assert "parallel_trends" in pt_result
        assert "p_value" in pt_result
        assert "f_statistic" in pt_result

    def test_estimate_ate(self, simple_did_data):
        """Test estimate_ate method."""
        data, true_effect, treatment_time = simple_did_data

        did = DifferenceInDifferences(
            treatment_col="treatment",
            outcome_col="outcome",
            time_col="time",
            unit_col="unit",
            treatment_time=treatment_time,
            method="twfe",
            n_bootstrap=50,
            random_state=42,
        )

        did.fit(data)
        ate = did.estimate_ate()

        assert isinstance(ate, CausalEstimate)
        assert ate.effect_type == EffectType.ATT

    def test_missing_columns(self):
        """Test error on missing columns."""
        data = pd.DataFrame(
            {
                "unit": [1, 2],
                "time": [1, 2],
            }
        )

        did = DifferenceInDifferences(
            treatment_col="treatment",
            outcome_col="outcome",
            time_col="time",
            unit_col="unit",
        )

        with pytest.raises(DataValidationError, match="Missing required columns"):
            did.fit(data)

    def test_infer_treatment_time(self, simple_did_data):
        """Test automatic treatment time inference."""
        data, true_effect, treatment_time = simple_did_data

        did = DifferenceInDifferences(
            treatment_col="treatment",
            outcome_col="outcome",
            time_col="time",
            unit_col="unit",
            treatment_time=None,  # Should infer
            method="twfe",
            n_bootstrap=50,
            random_state=42,
        )

        # Should not raise
        result = did.fit(data)
        assert result is not None


class TestEventStudyResult:
    """Tests for EventStudyResult dataclass."""

    def test_to_dataframe(self):
        """Test conversion to DataFrame."""
        coefficients = {
            -2: CausalEstimate(0.1, 0.2, -0.3, 0.5, 0.7),
            -1: CausalEstimate(0.0, 0.0, 0.0, 0.0, 1.0),
            0: CausalEstimate(2.0, 0.3, 1.4, 2.6, 0.001),
            1: CausalEstimate(2.5, 0.4, 1.7, 3.3, 0.001),
        }

        result = EventStudyResult(
            coefficients=coefficients,
            pre_periods=[-2, -1],
            post_periods=[0, 1],
            reference_period=-1,
        )

        df = result.to_dataframe()

        assert isinstance(df, pd.DataFrame)
        assert len(df) == 4
        assert "relative_time" in df.columns
        assert "estimate" in df.columns
        assert "is_pre_period" in df.columns
