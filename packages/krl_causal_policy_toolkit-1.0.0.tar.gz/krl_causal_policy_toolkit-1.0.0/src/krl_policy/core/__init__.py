# ----------------------------------------------------------------------
# © 2025 KR-Labs. All rights reserved.
# KR-Labs™ is a trademark of Quipu Research Labs, LLC,
# a subsidiary of Sudiata Giddasira, Inc.
# ----------------------------------------------------------------------
# SPDX-License-Identifier: Apache-2.0

"""
Core module for KRL Causal Policy Toolkit.

This module provides the foundation classes for policy evaluation:
- Base estimator abstract class
- Result dataclasses
- Configuration classes
- Enums for methods and effect types
- Exception classes
- Utility functions for inference
"""

from krl_policy.core.base import (  # Base classes; Result classes; Configuration; Enums; Exceptions
    BasePolicyEstimator,
    CausalEstimate,
    ConvergenceError,
    DataValidationError,
    DiagnosticResult,
    EffectType,
    EstimationError,
    EstimationMethod,
    IdentificationError,
    InferenceMethod,
    PolicyConfig,
    PolicyException,
    PolicyValidationResult,
    SensitivityResult,
    TreatmentEffectResult,
)
from krl_policy.core.utils import (  # Bootstrap inference; Clustered standard errors; Covariate balance; Parallel trends; Statistical utilities
    balance_check,
    balance_summary,
    bootstrap_ci,
    bootstrap_std_error,
    clustered_se,
    compute_ci,
    compute_p_value,
    parallel_trends_test,
    standardized_mean_difference,
)

__all__ = [
    # Base classes
    "BasePolicyEstimator",
    # Result classes
    "TreatmentEffectResult",
    "PolicyValidationResult",
    "CausalEstimate",
    "DiagnosticResult",
    "SensitivityResult",
    # Configuration
    "PolicyConfig",
    # Enums
    "EstimationMethod",
    "EffectType",
    "InferenceMethod",
    # Exceptions
    "PolicyException",
    "EstimationError",
    "IdentificationError",
    "DataValidationError",
    "ConvergenceError",
    # Bootstrap
    "bootstrap_ci",
    "bootstrap_std_error",
    # Clustered SE
    "clustered_se",
    # Balance
    "standardized_mean_difference",
    "balance_check",
    "balance_summary",
    # Parallel trends
    "parallel_trends_test",
    # Statistics
    "compute_p_value",
    "compute_ci",
]
