# ----------------------------------------------------------------------
# © 2025 KR-Labs. All rights reserved.
# KR-Labs™ is a trademark of Quipu Research Labs, LLC,
# a subsidiary of Sudiata Giddasira, Inc.
# ----------------------------------------------------------------------
# SPDX-License-Identifier: Apache-2.0

"""
Core base classes and interfaces for the KRL Causal Policy Toolkit.

This module provides the foundational abstractions for policy evaluation,
treatment effect estimation, and causal inference.
"""

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional, Tuple, Union

import numpy as np
import pandas as pd

# Import from krl-open-core if available
try:
    from krl_core import ConfigManager, get_logger

    HAS_KRL_CORE = True
except ImportError:
    import logging

    HAS_KRL_CORE = False

    def get_logger(name: str):
        return logging.getLogger(name)

    class ConfigManager:
        """Fallback config manager."""

        def __init__(self):
            self._config = {}

        def get(self, key: str, default: Any = None) -> Any:
            return self._config.get(key, default)

        def set(self, key: str, value: Any) -> None:
            self._config[key] = value


logger = get_logger(__name__)


# =============================================================================
# Enums and Constants
# =============================================================================


class EstimationMethod(Enum):
    """Available estimation methods for treatment effects."""

    REGRESSION = "regression"
    IPW = "ipw"  # Inverse Probability Weighting
    AIPW = "aipw"  # Augmented IPW (Doubly Robust)
    STRATIFICATION = "stratification"
    MATCHING = "matching"
    DID = "did"  # Difference-in-Differences
    SCM = "scm"  # Synthetic Control Method
    RDD = "rdd"  # Regression Discontinuity Design
    IV = "iv"  # Instrumental Variables


class EffectType(Enum):
    """Types of treatment effects."""

    ATE = "ate"  # Average Treatment Effect
    ATT = "att"  # Average Treatment on Treated
    ATU = "atu"  # Average Treatment on Untreated
    CATE = "cate"  # Conditional Average Treatment Effect
    LATE = "late"  # Local Average Treatment Effect


class InferenceMethod(Enum):
    """Methods for statistical inference."""

    ANALYTIC = "analytic"  # Closed-form standard errors
    BOOTSTRAP = "bootstrap"  # Bootstrap confidence intervals
    CLUSTERED = "clustered"  # Clustered standard errors
    RANDOMIZATION = "randomization"  # Randomization inference


# =============================================================================
# Exception Classes
# =============================================================================


class PolicyException(Exception):
    """Base exception for policy toolkit errors."""

    pass


class EstimationError(PolicyException):
    """Error during estimation."""

    pass


class IdentificationError(PolicyException):
    """Causal identification assumption violated."""

    pass


class DataValidationError(PolicyException):
    """Input data validation failed."""

    pass


class ConvergenceError(PolicyException):
    """Optimization did not converge."""

    pass


# =============================================================================
# Configuration
# =============================================================================


@dataclass
class PolicyConfig:
    """
    Configuration for policy evaluation.

    Attributes
    ----------
    treatment_col : str
        Name of treatment indicator column
    outcome_col : str
        Name of outcome variable column
    covariates : List[str], optional
        Names of covariate columns
    cluster_col : str, optional
        Name of cluster column for clustered SEs
    time_col : str, optional
        Name of time column for panel data
    unit_col : str, optional
        Name of unit identifier column
    n_bootstrap : int
        Number of bootstrap iterations (default: 1000)
    confidence_level : float
        Confidence level for intervals (default: 0.95)
    random_state : int, optional
        Random seed for reproducibility
    """

    treatment_col: str = "treatment"
    outcome_col: str = "outcome"
    covariates: Optional[List[str]] = None
    cluster_col: Optional[str] = None
    time_col: Optional[str] = None
    unit_col: Optional[str] = None
    n_bootstrap: int = 1000
    confidence_level: float = 0.95
    random_state: Optional[int] = None

    def __post_init__(self):
        """Validate configuration after initialization."""
        if not 0 < self.confidence_level < 1:
            raise ValueError("confidence_level must be between 0 and 1")
        if self.n_bootstrap < 100:
            logger.warning("n_bootstrap < 100 may produce unreliable intervals")

    def to_dict(self) -> Dict[str, Any]:
        """Convert config to dictionary."""
        return {
            "treatment_col": self.treatment_col,
            "outcome_col": self.outcome_col,
            "covariates": self.covariates,
            "cluster_col": self.cluster_col,
            "time_col": self.time_col,
            "unit_col": self.unit_col,
            "n_bootstrap": self.n_bootstrap,
            "confidence_level": self.confidence_level,
            "random_state": self.random_state,
        }

    @classmethod
    def from_dict(cls, config_dict: Dict[str, Any]) -> "PolicyConfig":
        """Create config from dictionary."""
        return cls(**config_dict)


# =============================================================================
# Result Classes
# =============================================================================


@dataclass
class CausalEstimate:
    """
    A single causal effect estimate with uncertainty quantification.

    Attributes
    ----------
    estimate : float
        Point estimate of the causal effect
    std_error : float
        Standard error of the estimate
    ci_lower : float
        Lower bound of confidence interval
    ci_upper : float
        Upper bound of confidence interval
    p_value : float
        P-value for null hypothesis of zero effect
    effect_type : EffectType
        Type of effect (ATE, ATT, etc.)
    method : EstimationMethod
        Method used for estimation
    n_treated : int
        Number of treated units
    n_control : int
        Number of control units
    confidence_level : float
        Confidence level for interval
    """

    estimate: float
    std_error: float
    ci_lower: float
    ci_upper: float
    p_value: float
    effect_type: EffectType = EffectType.ATE
    method: EstimationMethod = EstimationMethod.REGRESSION
    n_treated: int = 0
    n_control: int = 0
    confidence_level: float = 0.95

    @property
    def is_significant(self) -> bool:
        """Check if effect is statistically significant at alpha = 1 - confidence_level."""
        return self.p_value < (1 - self.confidence_level)

    @property
    def confidence_interval(self) -> Tuple[float, float]:
        """Return confidence interval as a tuple."""
        return (self.ci_lower, self.ci_upper)

    @property
    def t_statistic(self) -> float:
        """Compute t-statistic."""
        if self.std_error == 0:
            return np.inf if self.estimate != 0 else 0.0
        return self.estimate / self.std_error

    def __repr__(self) -> str:
        sig = "*" if self.is_significant else ""
        return (
            f"CausalEstimate({self.effect_type.value.upper()}: "
            f"{self.estimate:.4f}{sig} [{self.ci_lower:.4f}, {self.ci_upper:.4f}], "
            f"p={self.p_value:.4f})"
        )


@dataclass
class DiagnosticResult:
    """
    Diagnostic information about estimation quality.

    Attributes
    ----------
    balance_statistics : Dict[str, float]
        Covariate balance metrics (standardized mean differences)
    assumption_tests : Dict[str, Dict]
        Results of assumption tests (parallel trends, etc.)
    model_fit : Dict[str, float]
        Model fit statistics (R², RMSE, etc.)
    warnings : List[str]
        Any warnings about potential issues
    """

    balance_statistics: Dict[str, float] = field(default_factory=dict)
    assumption_tests: Dict[str, Dict] = field(default_factory=dict)
    model_fit: Dict[str, float] = field(default_factory=dict)
    warnings: List[str] = field(default_factory=list)

    @property
    def has_warnings(self) -> bool:
        """Check if any warnings were raised."""
        return len(self.warnings) > 0

    @property
    def max_smd(self) -> float:
        """Maximum standardized mean difference (balance metric)."""
        if not self.balance_statistics:
            return np.nan
        return max(abs(v) for v in self.balance_statistics.values())

    @property
    def is_balanced(self) -> bool:
        """Check if covariates are balanced (max SMD < 0.1)."""
        return self.max_smd < 0.1


@dataclass
class TreatmentEffectResult:
    """
    Complete result from treatment effect estimation.

    Attributes
    ----------
    ate : CausalEstimate
        Average Treatment Effect estimate
    att : CausalEstimate, optional
        Average Treatment on Treated estimate
    cate : Dict[str, CausalEstimate], optional
        Conditional Average Treatment Effects by subgroup
    diagnostics : DiagnosticResult
        Diagnostic information
    method : EstimationMethod
        Estimation method used
    config : PolicyConfig
        Configuration used
    fitted_values : np.ndarray, optional
        Fitted/predicted values
    residuals : np.ndarray, optional
        Model residuals
    weights : np.ndarray, optional
        Estimation weights (for IPW)
    """

    ate: CausalEstimate
    att: Optional[CausalEstimate] = None
    cate: Optional[Dict[str, CausalEstimate]] = None
    diagnostics: DiagnosticResult = field(default_factory=DiagnosticResult)
    method: EstimationMethod = EstimationMethod.REGRESSION
    config: Optional[PolicyConfig] = None
    fitted_values: Optional[np.ndarray] = None
    residuals: Optional[np.ndarray] = None
    weights: Optional[np.ndarray] = None

    def summary(self) -> str:
        """Generate text summary of results."""
        lines = [
            "=" * 60,
            "Treatment Effect Estimation Results",
            "=" * 60,
            f"Method: {self.method.value.upper()}",
            "",
            "Average Treatment Effect (ATE):",
            f"  Estimate: {self.ate.estimate:.4f}",
            f"  Std. Error: {self.ate.std_error:.4f}",
            f"  {self.ate.confidence_level*100:.0f}% CI: [{self.ate.ci_lower:.4f}, {self.ate.ci_upper:.4f}]",
            f"  P-value: {self.ate.p_value:.4f}",
            f"  Significant: {'Yes' if self.ate.is_significant else 'No'}",
            "",
            f"Sample Size: {self.ate.n_treated + self.ate.n_control}",
            f"  Treated: {self.ate.n_treated}",
            f"  Control: {self.ate.n_control}",
        ]

        if self.att is not None:
            lines.extend(
                [
                    "",
                    "Average Treatment on Treated (ATT):",
                    f"  Estimate: {self.att.estimate:.4f}",
                    f"  Std. Error: {self.att.std_error:.4f}",
                    f"  P-value: {self.att.p_value:.4f}",
                ]
            )

        if self.diagnostics.has_warnings:
            lines.extend(
                [
                    "",
                    "⚠️ Warnings:",
                ]
            )
            for warning in self.diagnostics.warnings:
                lines.append(f"  - {warning}")

        lines.append("=" * 60)
        return "\n".join(lines)

    def to_dict(self) -> Dict[str, Any]:
        """Convert result to dictionary."""
        result = {
            "ate": {
                "estimate": self.ate.estimate,
                "std_error": self.ate.std_error,
                "ci_lower": self.ate.ci_lower,
                "ci_upper": self.ate.ci_upper,
                "p_value": self.ate.p_value,
            },
            "method": self.method.value,
            "n_treated": self.ate.n_treated,
            "n_control": self.ate.n_control,
        }

        if self.att is not None:
            result["att"] = {
                "estimate": self.att.estimate,
                "std_error": self.att.std_error,
                "ci_lower": self.att.ci_lower,
                "ci_upper": self.att.ci_upper,
                "p_value": self.att.p_value,
            }

        return result


@dataclass
class SensitivityResult:
    """
    Result from sensitivity analysis.

    Attributes
    ----------
    robustness_value : float
        Measure of robustness to unmeasured confounding
    e_value : float
        E-value for unmeasured confounding
    specification_curve : pd.DataFrame
        Results from specification curve analysis
    placebo_tests : Dict[str, CausalEstimate]
        Results from placebo tests
    """

    robustness_value: float = np.nan
    e_value: float = np.nan
    specification_curve: Optional[pd.DataFrame] = None
    placebo_tests: Dict[str, CausalEstimate] = field(default_factory=dict)


@dataclass
class PolicyValidationResult:
    """
    Result from policy assumption validation.

    Attributes
    ----------
    is_valid : bool
        Whether all assumption checks passed
    checks : Dict[str, bool]
        Individual check results
    warnings : List[str]
        Warning messages from validation
    recommendations : List[str]
        Recommendations for addressing issues
    details : Dict[str, Any]
        Additional validation details
    """

    is_valid: bool = True
    checks: Dict[str, bool] = field(default_factory=dict)
    warnings: List[str] = field(default_factory=list)
    recommendations: List[str] = field(default_factory=list)
    details: Dict[str, Any] = field(default_factory=dict)


# =============================================================================
# Base Estimator Class
# =============================================================================


class BasePolicyEstimator(ABC):
    """
    Abstract base class for all policy estimators.

    All causal inference estimators in the toolkit should inherit from this
    class and implement the abstract methods.

    Parameters
    ----------
    config : PolicyConfig, optional
        Configuration object. If None, default config is used.
    **kwargs
        Additional keyword arguments passed to config.

    Attributes
    ----------
    config : PolicyConfig
        Configuration for the estimator
    is_fitted : bool
        Whether the estimator has been fitted
    result_ : TreatmentEffectResult
        Results from fitting (available after fit())

    Examples
    --------
    >>> from krl_policy.estimators import TreatmentEffectEstimator
    >>> estimator = TreatmentEffectEstimator(
    ...     treatment_col="treated",
    ...     outcome_col="earnings"
    ... )
    >>> result = estimator.fit(data)
    >>> print(result.ate)
    """

    def __init__(self, config: Optional[PolicyConfig] = None, **kwargs):
        if config is not None:
            self.config = config
        else:
            self.config = PolicyConfig(**kwargs)

        self.is_fitted = False
        self.result_: Optional[TreatmentEffectResult] = None
        self._data: Optional[pd.DataFrame] = None

        logger.debug(f"Initialized {self.__class__.__name__} with config: {self.config}")

    @abstractmethod
    def fit(self, data: pd.DataFrame) -> TreatmentEffectResult:
        """
        Fit the estimator and compute treatment effects.

        Parameters
        ----------
        data : pd.DataFrame
            Input data with treatment, outcome, and covariate columns

        Returns
        -------
        TreatmentEffectResult
            Complete result object with estimates and diagnostics

        Raises
        ------
        DataValidationError
            If data validation fails
        EstimationError
            If estimation fails
        """
        pass

    @abstractmethod
    def estimate_ate(self) -> CausalEstimate:
        """
        Estimate Average Treatment Effect.

        Must be called after fit().

        Returns
        -------
        CausalEstimate
            ATE estimate with uncertainty quantification

        Raises
        ------
        RuntimeError
            If called before fit()
        """
        pass

    def estimate_att(self) -> CausalEstimate:
        """
        Estimate Average Treatment on Treated.

        Default implementation returns None. Override in subclasses.

        Returns
        -------
        CausalEstimate or None
            ATT estimate if available
        """
        return None

    def estimate_cate(self, subgroup_col: str) -> Dict[str, CausalEstimate]:
        """
        Estimate Conditional Average Treatment Effect by subgroup.

        Default implementation raises NotImplementedError.
        Override in subclasses that support heterogeneous effects.

        Parameters
        ----------
        subgroup_col : str
            Column name defining subgroups

        Returns
        -------
        Dict[str, CausalEstimate]
            Dictionary mapping subgroup values to CATE estimates
        """
        raise NotImplementedError(f"{self.__class__.__name__} does not support CATE estimation")

    def get_diagnostics(self) -> DiagnosticResult:
        """
        Get diagnostic information about the estimation.

        Returns
        -------
        DiagnosticResult
            Diagnostic information

        Raises
        ------
        RuntimeError
            If called before fit()
        """
        self._check_is_fitted()
        return self.result_.diagnostics

    def validate_data(self, data: pd.DataFrame) -> None:
        """
        Validate input data.

        Parameters
        ----------
        data : pd.DataFrame
            Input data to validate

        Raises
        ------
        DataValidationError
            If validation fails
        """
        # Check required columns
        required = [self.config.treatment_col, self.config.outcome_col]
        missing = [col for col in required if col not in data.columns]
        if missing:
            raise DataValidationError(f"Missing required columns: {missing}")

        # Check treatment is binary
        treatment = data[self.config.treatment_col]
        unique_values = treatment.unique()
        if not set(unique_values).issubset({0, 1, 0.0, 1.0, True, False}):
            raise DataValidationError(
                f"Treatment column must be binary (0/1), got unique values: {unique_values}"
            )

        # Check for variation in treatment
        if treatment.nunique() < 2:
            raise DataValidationError("Treatment column must have variation (both 0 and 1)")

        # Check outcome is numeric
        if not np.issubdtype(data[self.config.outcome_col].dtype, np.number):
            raise DataValidationError("Outcome column must be numeric")

        # Check covariates if specified
        if self.config.covariates:
            missing_cov = [col for col in self.config.covariates if col not in data.columns]
            if missing_cov:
                raise DataValidationError(f"Missing covariate columns: {missing_cov}")

        # Check for missing values
        cols_to_check = [self.config.treatment_col, self.config.outcome_col]
        if self.config.covariates:
            cols_to_check.extend(self.config.covariates)

        n_missing = data[cols_to_check].isna().sum().sum()
        if n_missing > 0:
            raise DataValidationError(
                f"Data contains {n_missing} missing values. "
                "Please handle missing data before estimation."
            )

        logger.debug("Data validation passed")

    def _check_is_fitted(self) -> None:
        """Check if estimator has been fitted."""
        if not self.is_fitted:
            raise RuntimeError(
                f"{self.__class__.__name__} has not been fitted. " "Call fit() first."
            )

    def __repr__(self) -> str:
        fitted_str = "fitted" if self.is_fitted else "not fitted"
        return f"{self.__class__.__name__}({fitted_str})"


# =============================================================================
# Exports
# =============================================================================

__all__ = [
    # Enums
    "EstimationMethod",
    "EffectType",
    "InferenceMethod",
    # Exceptions
    "PolicyException",
    "EstimationError",
    "IdentificationError",
    "DataValidationError",
    "ConvergenceError",
    # Config
    "PolicyConfig",
    # Results
    "CausalEstimate",
    "DiagnosticResult",
    "TreatmentEffectResult",
    "SensitivityResult",
    "PolicyValidationResult",
    # Base class
    "BasePolicyEstimator",
    # Utilities
    "get_logger",
]
