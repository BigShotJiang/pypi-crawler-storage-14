# ----------------------------------------------------------------------
# © 2025 KR-Labs. All rights reserved.
# KR-Labs™ is a trademark of Quipu Research Labs, LLC,
# a subsidiary of Sudiata Giddasira, Inc.
# ----------------------------------------------------------------------
# SPDX-License-Identifier: Apache-2.0

"""
Utility functions for causal inference and policy evaluation.

This module provides helper functions for:
- Bootstrap confidence intervals
- Clustered standard errors
- Covariate balance assessment
- Parallel trends testing
"""

from typing import Callable, Dict, List, Optional, Tuple, Union

import numpy as np
import pandas as pd
from scipy import stats

# Import logger
try:
    from krl_core import get_logger
except ImportError:
    import logging

    def get_logger(name: str):
        return logging.getLogger(name)


logger = get_logger(__name__)


# =============================================================================
# Bootstrap Inference
# =============================================================================


def bootstrap_ci(
    data: Union[pd.DataFrame, np.ndarray],
    statistic_fn: Callable,
    n_bootstrap: int = 1000,
    confidence_level: float = 0.95,
    method: str = "percentile",
    random_state: Optional[int] = None,
    **kwargs,
) -> Tuple[float, float, float]:
    """
    Compute bootstrap confidence intervals.

    Parameters
    ----------
    data : pd.DataFrame or np.ndarray
        Data to bootstrap
    statistic_fn : Callable
        Function that computes the statistic of interest.
        Should take data as first argument and return a scalar.
    n_bootstrap : int, default=1000
        Number of bootstrap iterations
    confidence_level : float, default=0.95
        Confidence level (e.g., 0.95 for 95% CI)
    method : str, default="percentile"
        Method for computing CI: "percentile", "basic", or "bca"
    random_state : int, optional
        Random seed for reproducibility
    **kwargs
        Additional arguments passed to statistic_fn

    Returns
    -------
    Tuple[float, float, float]
        (point_estimate, ci_lower, ci_upper)

    Examples
    --------
    >>> def mean_diff(data):
    ...     return data[data['T']==1]['Y'].mean() - data[data['T']==0]['Y'].mean()
    >>> estimate, ci_low, ci_high = bootstrap_ci(df, mean_diff)
    """
    from tqdm import tqdm
    
    rng = np.random.default_rng(random_state)

    # Convert to DataFrame if numpy array
    if isinstance(data, np.ndarray):
        data = pd.DataFrame(data)

    n = len(data)

    # Point estimate
    point_estimate = statistic_fn(data, **kwargs)

    # Bootstrap samples
    bootstrap_stats = []
    for _ in tqdm(range(n_bootstrap), desc="Bootstrap CI", leave=False):
        # Sample with replacement
        indices = rng.choice(n, size=n, replace=True)
        sample = data.iloc[indices]

        try:
            stat = statistic_fn(sample, **kwargs)
            bootstrap_stats.append(stat)
        except Exception:
            # Skip failed bootstrap iterations
            continue

    bootstrap_stats = np.array(bootstrap_stats)

    # Remove NaN values
    bootstrap_stats = bootstrap_stats[~np.isnan(bootstrap_stats)]

    if len(bootstrap_stats) < n_bootstrap * 0.5:
        logger.warning(f"Only {len(bootstrap_stats)}/{n_bootstrap} bootstrap iterations succeeded")

    # Compute confidence interval
    alpha = 1 - confidence_level

    if method == "percentile":
        ci_lower = np.percentile(bootstrap_stats, 100 * alpha / 2)
        ci_upper = np.percentile(bootstrap_stats, 100 * (1 - alpha / 2))

    elif method == "basic":
        ci_lower = 2 * point_estimate - np.percentile(bootstrap_stats, 100 * (1 - alpha / 2))
        ci_upper = 2 * point_estimate - np.percentile(bootstrap_stats, 100 * alpha / 2)

    elif method == "bca":
        # Bias-corrected and accelerated (BCa) bootstrap
        # Compute bias correction
        z0 = stats.norm.ppf(np.mean(bootstrap_stats < point_estimate))

        # Compute acceleration using jackknife
        jackknife_stats = []
        for i in range(n):
            jack_sample = data.drop(data.index[i])
            try:
                jack_stat = statistic_fn(jack_sample, **kwargs)
                jackknife_stats.append(jack_stat)
            except Exception:
                continue

        jackknife_stats = np.array(jackknife_stats)
        jack_mean = np.mean(jackknife_stats)

        num = np.sum((jack_mean - jackknife_stats) ** 3)
        denom = 6 * (np.sum((jack_mean - jackknife_stats) ** 2) ** 1.5)
        a = num / denom if denom != 0 else 0

        # Adjusted percentiles
        z_alpha_lower = stats.norm.ppf(alpha / 2)
        z_alpha_upper = stats.norm.ppf(1 - alpha / 2)

        alpha_lower_adj = stats.norm.cdf(z0 + (z0 + z_alpha_lower) / (1 - a * (z0 + z_alpha_lower)))
        alpha_upper_adj = stats.norm.cdf(z0 + (z0 + z_alpha_upper) / (1 - a * (z0 + z_alpha_upper)))

        ci_lower = np.percentile(bootstrap_stats, 100 * alpha_lower_adj)
        ci_upper = np.percentile(bootstrap_stats, 100 * alpha_upper_adj)

    else:
        raise ValueError(f"Unknown bootstrap method: {method}")

    return point_estimate, ci_lower, ci_upper


def bootstrap_std_error(
    data: Union[pd.DataFrame, np.ndarray],
    statistic_fn: Callable,
    n_bootstrap: int = 1000,
    random_state: Optional[int] = None,
    n_jobs: int = 1,
    **kwargs,
) -> float:
    """
    Compute bootstrap standard error with optional parallelization.

    Parameters
    ----------
    data : pd.DataFrame or np.ndarray
        Data to bootstrap
    statistic_fn : Callable
        Function that computes the statistic of interest
    n_bootstrap : int, default=1000
        Number of bootstrap iterations
    random_state : int, optional
        Random seed for reproducibility
    n_jobs : int, default=1
        Number of parallel jobs. -1 uses all CPU cores.
        If 1, runs sequentially with progress bar.
    **kwargs
        Additional arguments passed to statistic_fn

    Returns
    -------
    float
        Bootstrap standard error
    """
    from tqdm import tqdm

    rng = np.random.default_rng(random_state)

    if isinstance(data, np.ndarray):
        data = pd.DataFrame(data)

    n = len(data)

    # Parallel execution
    if n_jobs != 1:
        try:
            from joblib import Parallel, delayed

            def bootstrap_iteration(seed):
                local_rng = np.random.default_rng(seed)
                indices = local_rng.choice(n, size=n, replace=True)
                sample = data.iloc[indices]
                try:
                    return statistic_fn(sample, **kwargs)
                except Exception:
                    return np.nan

            # Generate seeds for reproducibility
            seeds = rng.integers(0, 2**31, size=n_bootstrap)

            bootstrap_stats = Parallel(n_jobs=n_jobs, verbose=10)(
                delayed(bootstrap_iteration)(seed) for seed in seeds
            )

            bootstrap_stats = np.array([s for s in bootstrap_stats if not np.isnan(s)])
            return np.std(bootstrap_stats, ddof=1)

        except ImportError:
            logger.warning("joblib not installed, falling back to sequential execution")

    # Sequential execution with progress bar
    bootstrap_stats = []
    for _ in tqdm(range(n_bootstrap), desc="Bootstrap iterations", leave=False):
        indices = rng.choice(n, size=n, replace=True)
        sample = data.iloc[indices]

        try:
            stat = statistic_fn(sample, **kwargs)
            bootstrap_stats.append(stat)
        except Exception:
            continue

    return np.std(bootstrap_stats, ddof=1)


# =============================================================================
# Clustered Standard Errors
# =============================================================================


def clustered_se(
    residuals: np.ndarray, X: np.ndarray, cluster_ids: np.ndarray, dof_adjustment: bool = True
) -> np.ndarray:
    """
    Compute clustered standard errors (Liang-Zeger).

    Parameters
    ----------
    residuals : np.ndarray
        Model residuals (n,)
    X : np.ndarray
        Design matrix (n, k) including intercept
    cluster_ids : np.ndarray
        Cluster identifiers (n,)
    dof_adjustment : bool, default=True
        Apply finite sample degrees of freedom adjustment

    Returns
    -------
    np.ndarray
        Clustered standard errors for each coefficient (k,)

    Notes
    -----
    Implements the Liang-Zeger (1986) cluster-robust variance estimator.
    """
    n, k = X.shape
    clusters = np.unique(cluster_ids)
    G = len(clusters)

    # Compute (X'X)^{-1}
    XtX_inv = np.linalg.inv(X.T @ X)

    # Compute meat of the sandwich
    meat = np.zeros((k, k))

    for g in clusters:
        # Select observations in cluster g
        mask = cluster_ids == g
        X_g = X[mask]
        e_g = residuals[mask]

        # Cluster contribution to meat
        score_g = X_g.T @ e_g  # k x 1
        meat += np.outer(score_g, score_g)

    # Sandwich estimator
    V = XtX_inv @ meat @ XtX_inv

    # Degrees of freedom adjustment
    if dof_adjustment:
        adjustment = (G / (G - 1)) * ((n - 1) / (n - k))
        V = V * adjustment

    return np.sqrt(np.diag(V))


# =============================================================================
# Covariate Balance
# =============================================================================


def standardized_mean_difference(
    data: pd.DataFrame, treatment_col: str, covariate: str, weights: Optional[np.ndarray] = None
) -> float:
    """
    Compute standardized mean difference for a single covariate.

    Parameters
    ----------
    data : pd.DataFrame
        Input data
    treatment_col : str
        Name of treatment column
    covariate : str
        Name of covariate column
    weights : np.ndarray, optional
        Sample weights (e.g., IPW weights)

    Returns
    -------
    float
        Standardized mean difference (SMD)

    Notes
    -----
    SMD = (mean_treated - mean_control) / pooled_std

    Pooled std computed as sqrt((var_treated + var_control) / 2)
    """
    treated = data[data[treatment_col] == 1][covariate]
    control = data[data[treatment_col] == 0][covariate]

    if weights is not None:
        treated_weights = weights[data[treatment_col] == 1]
        control_weights = weights[data[treatment_col] == 0]

        # Weighted means
        mean_treated = np.average(treated, weights=treated_weights)
        mean_control = np.average(control, weights=control_weights)

        # Weighted variances
        var_treated = np.average((treated - mean_treated) ** 2, weights=treated_weights)
        var_control = np.average((control - mean_control) ** 2, weights=control_weights)
    else:
        mean_treated = treated.mean()
        mean_control = control.mean()
        var_treated = treated.var()
        var_control = control.var()

    pooled_std = np.sqrt((var_treated + var_control) / 2)

    if pooled_std == 0:
        return 0.0

    return (mean_treated - mean_control) / pooled_std


def balance_check(
    data: pd.DataFrame,
    treatment_col: str,
    covariates: List[str],
    weights: Optional[np.ndarray] = None,
    threshold: float = 0.1,
) -> Dict[str, Dict[str, Union[float, bool]]]:
    """
    Compute covariate balance statistics.

    Parameters
    ----------
    data : pd.DataFrame
        Input data
    treatment_col : str
        Name of treatment column
    covariates : List[str]
        List of covariate column names
    weights : np.ndarray, optional
        Sample weights (e.g., IPW weights)
    threshold : float, default=0.1
        SMD threshold for balance (typically 0.1 or 0.25)

    Returns
    -------
    Dict[str, Dict]
        Dictionary with balance statistics for each covariate:
        - smd: standardized mean difference
        - mean_treated: mean in treated group
        - mean_control: mean in control group
        - balanced: whether |SMD| < threshold

    Examples
    --------
    >>> balance = balance_check(df, 'treatment', ['age', 'income', 'education'])
    >>> for cov, stats in balance.items():
    ...     print(f"{cov}: SMD={stats['smd']:.3f}, balanced={stats['balanced']}")
    """
    results = {}

    for cov in covariates:
        if cov not in data.columns:
            logger.warning(f"Covariate '{cov}' not found in data, skipping")
            continue

        smd = standardized_mean_difference(data, treatment_col, cov, weights)

        treated = data[data[treatment_col] == 1][cov]
        control = data[data[treatment_col] == 0][cov]

        results[cov] = {
            "smd": smd,
            "mean_treated": treated.mean(),
            "mean_control": control.mean(),
            "std_treated": treated.std(),
            "std_control": control.std(),
            "balanced": abs(smd) < threshold,
        }

    return results


def balance_summary(balance_results: Dict[str, Dict], threshold: float = 0.1) -> str:
    """
    Generate text summary of balance check results.

    Parameters
    ----------
    balance_results : Dict
        Output from balance_check()
    threshold : float, default=0.1
        SMD threshold for balance

    Returns
    -------
    str
        Formatted summary string
    """
    lines = [
        "Covariate Balance Summary",
        "=" * 60,
        f"{'Covariate':<20} {'SMD':>10} {'Treated':>12} {'Control':>12} {'Balanced':>10}",
        "-" * 60,
    ]

    n_balanced = 0
    for cov, stats in balance_results.items():
        balanced_str = "✓" if stats["balanced"] else "✗"
        if stats["balanced"]:
            n_balanced += 1

        lines.append(
            f"{cov:<20} {stats['smd']:>10.3f} "
            f"{stats['mean_treated']:>12.3f} {stats['mean_control']:>12.3f} "
            f"{balanced_str:>10}"
        )

    lines.extend(
        [
            "-" * 60,
            f"Balanced covariates: {n_balanced}/{len(balance_results)} "
            f"(threshold: |SMD| < {threshold})",
        ]
    )

    return "\n".join(lines)


# =============================================================================
# Parallel Trends Testing
# =============================================================================


def parallel_trends_test(
    data: pd.DataFrame,
    outcome_col: str,
    treatment_col: str,
    time_col: str,
    unit_col: str,
    pre_periods: Optional[int] = None,
    treatment_time: Optional[Union[str, int]] = None,
) -> Dict[str, Union[float, bool, np.ndarray]]:
    """
    Test for parallel pre-treatment trends.

    Parameters
    ----------
    data : pd.DataFrame
        Panel data with unit and time columns
    outcome_col : str
        Name of outcome column
    treatment_col : str
        Name of treatment group indicator (not treatment timing)
    time_col : str
        Name of time period column
    unit_col : str
        Name of unit identifier column
    pre_periods : int, optional
        Number of pre-treatment periods to test
    treatment_time : str or int, optional
        Time period when treatment starts

    Returns
    -------
    Dict
        - f_statistic: F-statistic for joint test
        - p_value: P-value for joint test
        - parallel_trends: Boolean indicating if test passes (p > 0.05)
        - pre_trends: Array of pre-period differential trends

    Notes
    -----
    Tests H0: Pre-treatment trends are parallel between treated and control.
    Uses an F-test on differential pre-trends.
    """
    # Get unique time periods
    times = sorted(data[time_col].unique())

    # Determine treatment time if not specified
    if treatment_time is None:
        # Assume treatment starts when treatment indicator turns on
        treated_data = data[data[treatment_col] == 1]
        treatment_time = treated_data[time_col].min()

    # Get pre-treatment periods
    pre_times = [t for t in times if t < treatment_time]

    if pre_periods is not None:
        pre_times = pre_times[-pre_periods:]

    if len(pre_times) < 2:
        logger.warning("Not enough pre-treatment periods for parallel trends test")
        return {
            "f_statistic": np.nan,
            "p_value": np.nan,
            "parallel_trends": True,  # Assume true if can't test
            "pre_trends": np.array([]),
        }

    # Compute period-by-period differences
    pre_trends = []

    for t in pre_times:
        period_data = data[data[time_col] == t]

        treated_mean = period_data[period_data[treatment_col] == 1][outcome_col].mean()
        control_mean = period_data[period_data[treatment_col] == 0][outcome_col].mean()

        pre_trends.append(treated_mean - control_mean)

    pre_trends = np.array(pre_trends)

    # Test for trend in pre-period differences
    # Using linear regression of differences on time
    x = np.arange(len(pre_trends))

    # Simple F-test for slope = 0
    n = len(pre_trends)
    x_mean = x.mean()
    y_mean = pre_trends.mean()

    slope = np.sum((x - x_mean) * (pre_trends - y_mean)) / np.sum((x - x_mean) ** 2)

    # Residuals
    y_pred = y_mean + slope * (x - x_mean)
    ss_res = np.sum((pre_trends - y_pred) ** 2)
    ss_tot = np.sum((pre_trends - y_mean) ** 2)

    if ss_tot == 0:
        f_stat = 0.0
        p_value = 1.0
    else:
        r_squared = 1 - ss_res / ss_tot
        # F-statistic for slope = 0
        df1 = 1
        df2 = n - 2

        if df2 > 0 and r_squared < 1:
            f_stat = (r_squared / df1) / ((1 - r_squared) / df2)
            p_value = 1 - stats.f.cdf(f_stat, df1, df2)
        else:
            f_stat = np.nan
            p_value = np.nan

    return {
        "f_statistic": f_stat,
        "p_value": p_value,
        "parallel_trends": p_value > 0.05 if not np.isnan(p_value) else True,
        "pre_trends": pre_trends,
        "slope": slope,
        "n_pre_periods": len(pre_times),
    }


# =============================================================================
# Statistical Utilities
# =============================================================================


def compute_p_value(
    estimate: float, std_error: float, null_value: float = 0.0, alternative: str = "two-sided"
) -> float:
    """
    Compute p-value for hypothesis test.

    Parameters
    ----------
    estimate : float
        Point estimate
    std_error : float
        Standard error of estimate
    null_value : float, default=0.0
        Null hypothesis value
    alternative : str, default="two-sided"
        Alternative hypothesis: "two-sided", "greater", or "less"

    Returns
    -------
    float
        P-value
    """
    if std_error == 0:
        return 0.0 if estimate != null_value else 1.0

    z = (estimate - null_value) / std_error

    if alternative == "two-sided":
        return 2 * (1 - stats.norm.cdf(abs(z)))
    elif alternative == "greater":
        return 1 - stats.norm.cdf(z)
    elif alternative == "less":
        return stats.norm.cdf(z)
    else:
        raise ValueError(f"Unknown alternative: {alternative}")


def compute_ci(
    estimate: float, std_error: float, confidence_level: float = 0.95, method: str = "normal"
) -> Tuple[float, float]:
    """
    Compute confidence interval.

    Parameters
    ----------
    estimate : float
        Point estimate
    std_error : float
        Standard error
    confidence_level : float, default=0.95
        Confidence level
    method : str, default="normal"
        Method: "normal" or "t" (with dof parameter)

    Returns
    -------
    Tuple[float, float]
        (ci_lower, ci_upper)
    """
    alpha = 1 - confidence_level
    z = stats.norm.ppf(1 - alpha / 2)

    ci_lower = estimate - z * std_error
    ci_upper = estimate + z * std_error

    return ci_lower, ci_upper


# =============================================================================
# Exports
# =============================================================================

__all__ = [
    # Bootstrap
    "bootstrap_ci",
    "bootstrap_std_error",
    # Clustered SE
    "clustered_se",
    # Balance
    "standardized_mean_difference",
    "balance_check",
    "balance_summary",
    # Parallel trends
    "parallel_trends_test",
    # Statistics
    "compute_p_value",
    "compute_ci",
]
