# Copyright (c) 2024 Sudiata Giddasira, Inc. d/b/a Quipu Research Labs, LLC d/b/a KR-Labs™
# SPDX-License-Identifier: MIT
#
# Khipu Research Analytics Suite - KR-Labs™
# Commercial Use: Contact KR-Labs™ for licensing terms

"""
Automated report generation for causal inference results.

This module provides tools for generating publication-ready reports
in multiple formats (HTML, LaTeX, Markdown) from causal inference results.
"""

from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional, Union

import pandas as pd
from krl_core.logging import get_logger

from krl_policy.core.base import CausalEstimate, DiagnosticResult

logger = get_logger(__name__)


# =============================================================================
# Report Configuration
# =============================================================================


@dataclass
class ReportConfig:
    """
    Configuration for report generation.

    Attributes
    ----------
    title : str
        Report title
    author : str, optional
        Author name
    date : str, optional
        Report date (defaults to today)
    include_diagnostics : bool
        Whether to include diagnostic information
    include_code : bool
        Whether to include code snippets
    significance_level : float
        Significance level for hypothesis tests
    """

    title: str = "Causal Inference Report"
    author: Optional[str] = None
    date: Optional[str] = None
    include_diagnostics: bool = True
    include_code: bool = False
    significance_level: float = 0.05

    def __post_init__(self):
        if self.date is None:
            self.date = datetime.now().strftime("%B %d, %Y")


# =============================================================================
# Report Generators
# =============================================================================


class BaseReport:
    """
    Base class for report generators.

    Parameters
    ----------
    config : ReportConfig, optional
        Report configuration
    """

    def __init__(self, config: Optional[ReportConfig] = None):
        self.config = config or ReportConfig()
        self._sections: List[str] = []

    def add_title(self, title: str, level: int = 1) -> None:
        """Add a title/heading."""
        raise NotImplementedError

    def add_text(self, text: str) -> None:
        """Add plain text paragraph."""
        raise NotImplementedError

    def add_table(self, df: pd.DataFrame, caption: Optional[str] = None) -> None:
        """Add a table."""
        raise NotImplementedError

    def add_estimate(self, estimate: CausalEstimate, label: str = "Effect Estimate") -> None:
        """Add a formatted causal estimate."""
        raise NotImplementedError

    def add_diagnostics(self, diagnostics: DiagnosticResult) -> None:
        """Add diagnostic information."""
        raise NotImplementedError

    def render(self) -> str:
        """Render the complete report."""
        raise NotImplementedError

    def save(self, path: Union[str, Path]) -> None:
        """Save report to file."""
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        with open(path, "w") as f:
            f.write(self.render())
        logger.info(f"Report saved to {path}")


class HTMLReport(BaseReport):
    """
    HTML report generator.

    Generates publication-ready HTML reports with Bootstrap styling.

    Examples
    --------
    >>> from krl_policy.reporting import HTMLReport
    >>> report = HTMLReport()
    >>> report.add_title("Treatment Effect Analysis")
    >>> report.add_estimate(estimate)
    >>> report.save("output.html")
    """

    def __init__(self, config: Optional[ReportConfig] = None):
        super().__init__(config)
        self._add_header()

    def _add_header(self) -> None:
        """Add HTML header with Bootstrap CSS."""
        header = f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{self.config.title}</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {{ 
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            line-height: 1.6;
            padding: 2rem;
            max-width: 1200px;
            margin: 0 auto;
        }}
        .estimate {{ 
            background: #f8f9fa;
            border-left: 4px solid #007bff;
            padding: 1rem;
            margin: 1rem 0;
        }}
        .significant {{ 
            color: #28a745;
            font-weight: bold;
        }}
        .not-significant {{ 
            color: #6c757d;
        }}
        table {{ 
            margin: 1rem 0;
        }}
        .diagnostic {{ 
            background: #fff3cd;
            border-left: 4px solid #ffc107;
            padding: 1rem;
            margin: 1rem 0;
        }}
    </style>
</head>
<body>
    <div class="container">
        <h1 class="mb-4">{self.config.title}</h1>
"""
        if self.config.author:
            header += f"        <p class='text-muted'>Author: {self.config.author}</p>\n"
        header += f"        <p class='text-muted'>Date: {self.config.date}</p>\n"
        header += "        <hr>\n"
        self._sections.append(header)

    def add_title(self, title: str, level: int = 2) -> None:
        """Add a title/heading."""
        self._sections.append(f"        <h{level}>{title}</h{level}>\n")

    def add_text(self, text: str) -> None:
        """Add plain text paragraph."""
        self._sections.append(f"        <p>{text}</p>\n")

    def add_table(self, df: pd.DataFrame, caption: Optional[str] = None) -> None:
        """Add a table."""
        html = "        <div class='table-responsive'>\n"
        if caption:
            html += f"            <p class='fw-bold'>{caption}</p>\n"
        html += df.to_html(classes="table table-striped table-hover", index=False)
        html += "        </div>\n"
        self._sections.append(html)

    def add_estimate(self, estimate: CausalEstimate, label: str = "Effect Estimate") -> None:
        """Add a formatted causal estimate."""
        sig_class = "significant" if estimate.is_significant else "not-significant"
        sig_text = "***" if estimate.is_significant else ""

        html = f"""        <div class='estimate'>
            <h4>{label}</h4>
            <p><strong>Point Estimate:</strong> <span class='{sig_class}'>{estimate.estimate:.4f}{sig_text}</span></p>
            <p><strong>Standard Error:</strong> {estimate.std_error:.4f}</p>
            <p><strong>95% Confidence Interval:</strong> [{estimate.ci_lower:.4f}, {estimate.ci_upper:.4f}]</p>
            <p><strong>P-value:</strong> {estimate.p_value:.4f}</p>
            <p><strong>Effect Type:</strong> {estimate.effect_type.value.upper()}</p>
        </div>
"""
        self._sections.append(html)

    def add_diagnostics(self, diagnostics: DiagnosticResult) -> None:
        """Add diagnostic information."""
        if not self.config.include_diagnostics:
            return

        html = "        <div class='diagnostic'>\n"
        html += "            <h4>Diagnostic Information</h4>\n"

        if diagnostics.balance_statistics:
            html += "            <h5>Balance Statistics</h5>\n"
            df = pd.DataFrame(diagnostics.balance_statistics).T
            html += df.to_html(classes="table table-sm")

        if diagnostics.warnings:
            html += "            <h5>Warnings</h5>\n"
            html += "            <ul>\n"
            for warning in diagnostics.warnings:
                html += f"                <li class='text-warning'>{warning}</li>\n"
            html += "            </ul>\n"

        html += "        </div>\n"
        self._sections.append(html)

    def add_comparison_table(
        self,
        methods: List[str],
        estimates: List[float],
        std_errors: List[float],
        p_values: List[float],
    ) -> None:
        """Add a method comparison table."""
        df = pd.DataFrame(
            {
                "Method": methods,
                "Estimate": [f"{e:.4f}" for e in estimates],
                "Std Error": [f"{se:.4f}" for se in std_errors],
                "P-value": [f"{p:.4f}" for p in p_values],
                "Significant": [
                    "✓" if p < self.config.significance_level else "✗" for p in p_values
                ],
            }
        )
        self.add_table(df, caption="Method Comparison")

    def render(self) -> str:
        """Render the complete report."""
        footer = """    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>"""
        return "".join(self._sections) + footer


class LaTeXReport(BaseReport):
    """
    LaTeX report generator.

    Generates publication-ready LaTeX documents for academic papers.

    Examples
    --------
    >>> from krl_policy.reporting import LaTeXReport
    >>> report = LaTeXReport()
    >>> report.add_title("Results")
    >>> report.add_estimate(estimate)
    >>> report.save("output.tex")
    """

    def __init__(self, config: Optional[ReportConfig] = None):
        super().__init__(config)
        self._add_preamble()

    def _add_preamble(self) -> None:
        """Add LaTeX preamble."""
        preamble = (
            r"""\documentclass[11pt]{article}
\usepackage[utf8]{inputenc}
\usepackage{booktabs}
\usepackage{geometry}
\usepackage{amsmath}
\usepackage{hyperref}
\geometry{margin=1in}

\title{"""
            + self.config.title
            + r"""}
"""
        )
        if self.config.author:
            preamble += r"\author{" + self.config.author + r"}" + "\n"
        preamble += r"\date{" + self.config.date + r"}" + "\n"
        preamble += r"""
\begin{document}
\maketitle

"""
        self._sections.append(preamble)

    def add_title(self, title: str, level: int = 2) -> None:
        """Add a title/heading."""
        if level == 1:
            self._sections.append(f"\\section{{{title}}}\n\n")
        elif level == 2:
            self._sections.append(f"\\subsection{{{title}}}\n\n")
        else:
            self._sections.append(f"\\subsubsection{{{title}}}\n\n")

    def add_text(self, text: str) -> None:
        """Add plain text paragraph."""
        # Escape special LaTeX characters
        text = text.replace("_", r"\_").replace("%", r"\%").replace("&", r"\&")
        self._sections.append(f"{text}\n\n")

    def add_table(self, df: pd.DataFrame, caption: Optional[str] = None) -> None:
        """Add a table."""
        latex = "\\begin{table}[htbp]\n"
        latex += "\\centering\n"
        if caption:
            latex += f"\\caption{{{caption}}}\n"

        # Generate table
        latex += "\\begin{tabular}{" + "l" * len(df.columns) + "}\n"
        latex += "\\toprule\n"
        latex += " & ".join(df.columns) + " \\\\\n"
        latex += "\\midrule\n"

        for _, row in df.iterrows():
            latex += " & ".join(str(v) for v in row.values) + " \\\\\n"

        latex += "\\bottomrule\n"
        latex += "\\end{tabular}\n"
        latex += "\\end{table}\n\n"
        self._sections.append(latex)

    def add_estimate(self, estimate: CausalEstimate, label: str = "Effect Estimate") -> None:
        """Add a formatted causal estimate."""
        sig = "***" if estimate.is_significant else ""

        latex = f"""\\textbf{{{label}:}}

\\begin{{itemize}}
    \\item Point Estimate: ${estimate.estimate:.4f}^{{{sig}}}$
    \\item Standard Error: ${estimate.std_error:.4f}$
    \\item 95\\% CI: $[{estimate.ci_lower:.4f}, {estimate.ci_upper:.4f}]$
    \\item P-value: ${estimate.p_value:.4f}$
    \\item Effect Type: {estimate.effect_type.value.upper()}
\\end{{itemize}}

"""
        self._sections.append(latex)

    def add_diagnostics(self, diagnostics: DiagnosticResult) -> None:
        """Add diagnostic information."""
        if not self.config.include_diagnostics:
            return

        self.add_title("Diagnostic Information", level=3)

        if diagnostics.warnings:
            latex = "\\textbf{Warnings:}\n\\begin{itemize}\n"
            for warning in diagnostics.warnings:
                latex += f"    \\item {warning}\n"
            latex += "\\end{itemize}\n\n"
            self._sections.append(latex)

    def render(self) -> str:
        """Render the complete report."""
        footer = "\\end{document}\n"
        return "".join(self._sections) + footer


class MarkdownReport(BaseReport):
    """
    Markdown report generator.

    Generates GitHub-flavored markdown reports.

    Examples
    --------
    >>> from krl_policy.reporting import MarkdownReport
    >>> report = MarkdownReport()
    >>> report.add_title("Analysis Results")
    >>> report.add_estimate(estimate)
    >>> report.save("output.md")
    """

    def __init__(self, config: Optional[ReportConfig] = None):
        super().__init__(config)
        self._add_header()

    def _add_header(self) -> None:
        """Add markdown header."""
        header = f"# {self.config.title}\n\n"
        if self.config.author:
            header += f"**Author:** {self.config.author}  \n"
        header += f"**Date:** {self.config.date}\n\n"
        header += "---\n\n"
        self._sections.append(header)

    def add_title(self, title: str, level: int = 2) -> None:
        """Add a title/heading."""
        self._sections.append(f"{'#' * level} {title}\n\n")

    def add_text(self, text: str) -> None:
        """Add plain text paragraph."""
        self._sections.append(f"{text}\n\n")

    def add_table(self, df: pd.DataFrame, caption: Optional[str] = None) -> None:
        """Add a table."""
        if caption:
            self._sections.append(f"**{caption}**\n\n")
        self._sections.append(df.to_markdown(index=False) + "\n\n")

    def add_estimate(self, estimate: CausalEstimate, label: str = "Effect Estimate") -> None:
        """Add a formatted causal estimate."""
        sig = " ***" if estimate.is_significant else ""

        md = f"""### {label}

- **Point Estimate:** {estimate.estimate:.4f}{sig}
- **Standard Error:** {estimate.std_error:.4f}
- **95% Confidence Interval:** [{estimate.ci_lower:.4f}, {estimate.ci_upper:.4f}]
- **P-value:** {estimate.p_value:.4f}
- **Effect Type:** {estimate.effect_type.value.upper()}

"""
        self._sections.append(md)

    def add_diagnostics(self, diagnostics: DiagnosticResult) -> None:
        """Add diagnostic information."""
        if not self.config.include_diagnostics:
            return

        self.add_title("Diagnostic Information", level=3)

        if diagnostics.balance_statistics:
            df = pd.DataFrame(diagnostics.balance_statistics).T
            self.add_table(df, caption="Balance Statistics")

        if diagnostics.warnings:
            md = "**Warnings:**\n\n"
            for warning in diagnostics.warnings:
                md += f"- ⚠️ {warning}\n"
            md += "\n"
            self._sections.append(md)

    def render(self) -> str:
        """Render the complete report."""
        return "".join(self._sections)


class ReportGenerator:
    """
    High-level interface for generating reports.

    Provides a convenient API for creating reports in multiple formats
    from causal inference results.

    Parameters
    ----------
    config : ReportConfig, optional
        Report configuration

    Examples
    --------
    >>> from krl_policy.reporting import ReportGenerator
    >>>
    >>> generator = ReportGenerator(title="Policy Evaluation Results")
    >>> generator.add_estimate(ate_estimate, label="Average Treatment Effect")
    >>> generator.add_table(balance_table, caption="Covariate Balance")
    >>>
    >>> # Save in multiple formats
    >>> generator.save_html("report.html")
    >>> generator.save_latex("report.tex")
    >>> generator.save_markdown("report.md")
    """

    def __init__(self, config: Optional[ReportConfig] = None, **kwargs):
        if config is None:
            config = ReportConfig(**kwargs)
        self.config = config

        # Initialize report generators
        self.html = HTMLReport(config)
        self.latex = LaTeXReport(config)
        self.markdown = MarkdownReport(config)

    def add_title(self, title: str, level: int = 2) -> None:
        """Add a title to all reports."""
        self.html.add_title(title, level)
        self.latex.add_title(title, level)
        self.markdown.add_title(title, level)

    def add_text(self, text: str) -> None:
        """Add text to all reports."""
        self.html.add_text(text)
        self.latex.add_text(text)
        self.markdown.add_text(text)

    def add_table(self, df: pd.DataFrame, caption: Optional[str] = None) -> None:
        """Add table to all reports."""
        self.html.add_table(df, caption)
        self.latex.add_table(df, caption)
        self.markdown.add_table(df, caption)

    def add_estimate(self, estimate: CausalEstimate, label: str = "Effect Estimate") -> None:
        """Add estimate to all reports."""
        self.html.add_estimate(estimate, label)
        self.latex.add_estimate(estimate, label)
        self.markdown.add_estimate(estimate, label)

    def add_diagnostics(self, diagnostics: DiagnosticResult) -> None:
        """Add diagnostics to all reports."""
        self.html.add_diagnostics(diagnostics)
        self.latex.add_diagnostics(diagnostics)
        self.markdown.add_diagnostics(diagnostics)

    def add_comparison_table(
        self,
        methods: List[str],
        estimates: List[float],
        std_errors: List[float],
        p_values: List[float],
    ) -> None:
        """Add method comparison table."""
        self.html.add_comparison_table(methods, estimates, std_errors, p_values)

        # For LaTeX and Markdown, create DataFrame and use add_table
        df = pd.DataFrame(
            {
                "Method": methods,
                "Estimate": [f"{e:.4f}" for e in estimates],
                "Std Error": [f"{se:.4f}" for se in std_errors],
                "P-value": [f"{p:.4f}" for p in p_values],
            }
        )
        self.latex.add_table(df, caption="Method Comparison")
        self.markdown.add_table(df, caption="Method Comparison")

    def save_html(self, path: Union[str, Path]) -> None:
        """Save HTML report."""
        self.html.save(path)

    def save_latex(self, path: Union[str, Path]) -> None:
        """Save LaTeX report."""
        self.latex.save(path)

    def save_markdown(self, path: Union[str, Path]) -> None:
        """Save Markdown report."""
        self.markdown.save(path)

    def save_all(self, base_path: Union[str, Path]) -> None:
        """
        Save reports in all formats.

        Parameters
        ----------
        base_path : str or Path
            Base filename (without extension)
        """
        base = Path(base_path)
        self.save_html(base.with_suffix(".html"))
        self.save_latex(base.with_suffix(".tex"))
        self.save_markdown(base.with_suffix(".md"))
        logger.info(f"All reports saved with base path: {base}")


__all__ = [
    "ReportConfig",
    "BaseReport",
    "HTMLReport",
    "LaTeXReport",
    "MarkdownReport",
    "ReportGenerator",
]
