# ----------------------------------------------------------------------
# © 2025 KR-Labs. All rights reserved.
# KR-Labs™ is a trademark of Quipu Research Labs, LLC,
# a subsidiary of Sudiata Giddasira, Inc.
# ----------------------------------------------------------------------
# SPDX-License-Identifier: Apache-2.0

"""
Instrumental Variables (IV) Estimator.

This module implements instrumental variables estimation methods:
- Two-Stage Least Squares (2SLS)
- Limited Information Maximum Likelihood (LIML)
- Generalized Method of Moments (GMM)

References
----------
Angrist, J. D., & Krueger, A. B. (2001). Instrumental Variables and 
    the Search for Identification: From Supply and Demand to 
    Natural Experiments. JEP.
Stock, J. H., & Yogo, M. (2005). Testing for Weak Instruments in 
    Linear IV Regression. In Identification and Inference for 
    Econometric Models.
"""

from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional, Tuple, Union

import numpy as np
import pandas as pd
from scipy import stats

from ..core.base import (
    BasePolicyEstimator,
    CausalEstimate,
    DataValidationError,
    DiagnosticResult,
    EffectType,
    EstimationError,
    EstimationMethod,
    IdentificationError,
    PolicyConfig,
    TreatmentEffectResult,
)
from ..core.utils import (
    bootstrap_ci,
    bootstrap_std_error,
    clustered_se,
    compute_ci,
    compute_p_value,
)

# Import logger
try:
    from krl_core import get_logger
except ImportError:
    import logging

    def get_logger(name: str):
        return logging.getLogger(name)


logger = get_logger(__name__)


# =============================================================================
# Enums
# =============================================================================


class IVMethod(Enum):
    """IV estimation methods."""

    TSLS = "2sls"  # Two-Stage Least Squares
    LIML = "liml"  # Limited Information Maximum Likelihood
    GMM = "gmm"  # Generalized Method of Moments


# =============================================================================
# Result Classes
# =============================================================================


@dataclass
class IVDiagnostics:
    """
    Diagnostic tests for IV estimation.

    Attributes
    ----------
    first_stage_f : float
        F-statistic from first stage (instrument relevance)
    weak_instrument : bool
        Whether F < 10 (Stock-Yogo threshold)
    sargan_statistic : float
        Sargan-Hansen J statistic (overidentification)
    sargan_pvalue : float
        P-value for Sargan test
    durbin_wu_hausman : float
        Durbin-Wu-Hausman test for endogeneity
    dwh_pvalue : float
        P-value for DWH test
    partial_r2 : float
        Partial R² of instruments
    """

    first_stage_f: float = 0.0
    weak_instrument: bool = True
    sargan_statistic: float = np.nan
    sargan_pvalue: float = np.nan
    durbin_wu_hausman: float = np.nan
    dwh_pvalue: float = np.nan
    partial_r2: float = 0.0


@dataclass
class IVResult:
    """
    Result from IV estimation.

    Attributes
    ----------
    ate : CausalEstimate
        Average treatment effect (LATE) estimate
    first_stage : Dict[str, float]
        First stage regression results
    reduced_form : Dict[str, float]
        Reduced form regression results
    diagnostics : IVDiagnostics
        IV-specific diagnostic tests
    method : str
        Estimation method used (2sls, liml, gmm)
    """

    ate: CausalEstimate
    first_stage: Dict[str, float] = field(default_factory=dict)
    reduced_form: Dict[str, float] = field(default_factory=dict)
    diagnostics: IVDiagnostics = field(default_factory=IVDiagnostics)
    method: str = "2sls"


# =============================================================================
# IV Estimator
# =============================================================================


class InstrumentalVariables(BasePolicyEstimator):
    """
    Instrumental Variables estimator for causal inference.

    Estimates causal effects when treatment is endogenous using
    instrumental variables that affect treatment but not outcome
    directly.

    Parameters
    ----------
    treatment_col : str
        Column name for endogenous treatment variable
    outcome_col : str
        Column name for outcome variable
    instruments : List[str]
        Column names for instrumental variables
    covariates : List[str], optional
        Exogenous control variables (included in both stages)
    method : str, default='2sls'
        Estimation method: '2sls', 'liml', or 'gmm'
    cluster_col : str, optional
        Column for clustering standard errors
    n_bootstrap : int, default=1000
        Number of bootstrap iterations
    confidence_level : float, default=0.95
        Confidence level for intervals
    random_state : int, optional
        Random seed for reproducibility

    Examples
    --------
    >>> iv = InstrumentalVariables(
    ...     treatment_col='education',
    ...     outcome_col='earnings',
    ...     instruments=['quarter_of_birth', 'distance_to_college'],
    ...     covariates=['age', 'age_squared']
    ... )
    >>> result = iv.fit(data)
    >>> print(result.ate)
    >>> print(result.diagnostics.first_stage_f)

    Notes
    -----
    Key assumptions:
    1. Relevance: Instruments predict treatment (testable)
    2. Exclusion: Instruments affect outcome only through treatment
    3. Independence: Instruments uncorrelated with unobservables

    The Stock-Yogo (2005) rule of thumb: F > 10 for strong instruments.
    """

    def __init__(
        self,
        treatment_col: str = "treatment",
        outcome_col: str = "outcome",
        instruments: Optional[List[str]] = None,
        covariates: Optional[List[str]] = None,
        method: str = "2sls",
        cluster_col: Optional[str] = None,
        n_bootstrap: int = 1000,
        confidence_level: float = 0.95,
        random_state: Optional[int] = None,
        **kwargs,
    ):
        if instruments is None or len(instruments) == 0:
            raise ValueError("At least one instrument must be specified")

        config = PolicyConfig(
            treatment_col=treatment_col,
            outcome_col=outcome_col,
            covariates=covariates,
            cluster_col=cluster_col,
            n_bootstrap=n_bootstrap,
            confidence_level=confidence_level,
            random_state=random_state,
        )
        super().__init__(config=config, **kwargs)

        self.instruments = instruments
        self.method = method.lower()

        # IV-specific attributes
        self._first_stage_coef: Optional[np.ndarray] = None
        self._first_stage_fitted: Optional[np.ndarray] = None
        self._iv_diagnostics: Optional[IVDiagnostics] = None

        # Validate method
        valid_methods = ["2sls", "liml", "gmm"]
        if self.method not in valid_methods:
            raise ValueError(f"Method must be one of {valid_methods}")

        logger.debug(f"Initialized IV estimator with {len(instruments)} instruments")

    def fit(self, data: pd.DataFrame) -> TreatmentEffectResult:
        """
        Fit IV estimator and compute treatment effect.

        Parameters
        ----------
        data : pd.DataFrame
            Data with treatment, outcome, instruments, and covariate columns

        Returns
        -------
        TreatmentEffectResult
            Complete result with IV estimate and diagnostics
        """
        # Validate data
        self._validate_iv_data(data)
        self._data = data.copy().reset_index(drop=True)

        n = len(data)

        logger.info(f"Fitting IV with method={self.method}")

        # Extract matrices
        y = data[self.config.outcome_col].values
        d = data[self.config.treatment_col].values
        Z = data[self.instruments].values  # Instruments

        # Build exogenous regressors
        if self.config.covariates:
            X = data[self.config.covariates].values
            X = np.column_stack([np.ones(n), X])  # Add intercept
        else:
            X = np.ones((n, 1))  # Just intercept

        # Augmented instruments: [X, Z]
        W = np.column_stack([X, Z])

        # First stage: D = X'π + Z'γ + v
        first_stage_result = self._first_stage(d, W, Z, X)
        self._first_stage_coef = first_stage_result["coef"]
        self._first_stage_fitted = first_stage_result["fitted"]

        # Estimate based on method
        if self.method == "2sls":
            iv_result = self._estimate_2sls(y, d, W, X)
        elif self.method == "liml":
            iv_result = self._estimate_liml(y, d, W, X, Z)
        elif self.method == "gmm":
            iv_result = self._estimate_gmm(y, d, W, X, Z)

        # Compute diagnostics
        self._iv_diagnostics = self._compute_diagnostics(y, d, W, X, Z)

        # Build standard errors
        if self.config.cluster_col and self.config.cluster_col in data.columns:
            # Clustered standard errors
            residuals = y - X @ iv_result["second_stage_coef"][:-1] - d * iv_result["estimate"]
            std_error = self._clustered_iv_se(residuals, d, W, data[self.config.cluster_col].values)
        else:
            std_error = iv_result["std_error"]

        estimate = iv_result["estimate"]
        ci_lower, ci_upper = compute_ci(estimate, std_error, self.config.confidence_level)
        p_value = compute_p_value(estimate, std_error)

        # Count treated (for continuous treatment, use non-zero)
        if np.unique(d).size <= 2:
            n_treated = int(np.sum(d > 0))
            n_control = int(np.sum(d == 0))
        else:
            n_treated = n
            n_control = 0

        ate = CausalEstimate(
            estimate=estimate,
            std_error=std_error,
            ci_lower=ci_lower,
            ci_upper=ci_upper,
            p_value=p_value,
            effect_type=EffectType.LATE,  # IV estimates LATE
            method=EstimationMethod.IV,
            n_treated=n_treated,
            n_control=n_control,
            confidence_level=self.config.confidence_level,
        )

        # Build general diagnostics
        diagnostics = DiagnosticResult(
            model_fit={
                "first_stage_f": self._iv_diagnostics.first_stage_f,
                "partial_r2": self._iv_diagnostics.partial_r2,
            },
            assumption_tests={
                "weak_instrument": {
                    "f_statistic": self._iv_diagnostics.first_stage_f,
                    "weak": self._iv_diagnostics.weak_instrument,
                    "threshold": 10,
                },
                "overidentification": {
                    "sargan_statistic": self._iv_diagnostics.sargan_statistic,
                    "p_value": self._iv_diagnostics.sargan_pvalue,
                },
                "endogeneity": {
                    "dwh_statistic": self._iv_diagnostics.durbin_wu_hausman,
                    "p_value": self._iv_diagnostics.dwh_pvalue,
                },
            },
            warnings=[],
        )

        if self._iv_diagnostics.weak_instrument:
            diagnostics.warnings.append(
                f"Weak instruments detected (F = {self._iv_diagnostics.first_stage_f:.2f} < 10)"
            )

        if self._iv_diagnostics.sargan_pvalue < 0.05 and not np.isnan(
            self._iv_diagnostics.sargan_pvalue
        ):
            diagnostics.warnings.append(
                "Overidentification test rejected - instruments may be invalid"
            )

        self.result_ = TreatmentEffectResult(
            ate=ate,
            diagnostics=diagnostics,
            method=EstimationMethod.IV,
            config=self.config,
        )

        self.is_fitted = True
        return self.result_

    def estimate_ate(self) -> CausalEstimate:
        """Return the IV estimate (LATE)."""
        self._check_is_fitted()
        return self.result_.ate

    def get_first_stage(self) -> Dict[str, Any]:
        """
        Get first stage regression results.

        Returns
        -------
        Dict
            First stage coefficients and statistics
        """
        self._check_is_fitted()

        return {
            "coefficients": self._first_stage_coef,
            "fitted_values": self._first_stage_fitted,
            "f_statistic": self._iv_diagnostics.first_stage_f,
            "partial_r2": self._iv_diagnostics.partial_r2,
        }

    def get_diagnostics(self) -> IVDiagnostics:
        """
        Get IV-specific diagnostic tests.

        Returns
        -------
        IVDiagnostics
            Diagnostic test results
        """
        self._check_is_fitted()
        return self._iv_diagnostics

    def _validate_iv_data(self, data: pd.DataFrame) -> None:
        """Validate data for IV estimation."""
        # Check required columns
        required = [self.config.treatment_col, self.config.outcome_col]
        required.extend(self.instruments)

        if self.config.covariates:
            required.extend(self.config.covariates)

        missing = [col for col in required if col not in data.columns]
        if missing:
            raise DataValidationError(f"Missing required columns: {missing}")

        # Check for variation in instruments
        for inst in self.instruments:
            if data[inst].nunique() < 2:
                raise DataValidationError(f"Instrument '{inst}' has no variation")

        # Check for collinearity
        Z = data[self.instruments].values
        if np.linalg.matrix_rank(Z) < len(self.instruments):
            raise DataValidationError("Instruments are collinear")

        logger.debug("IV data validation passed")

    def _first_stage(
        self, d: np.ndarray, W: np.ndarray, Z: np.ndarray, X: np.ndarray
    ) -> Dict[str, Any]:
        """
        First stage regression: D on instruments and covariates.
        """
        n = len(d)
        k = W.shape[1]

        # OLS: D = W @ pi + error
        try:
            coef = np.linalg.lstsq(W, d, rcond=None)[0]
        except np.linalg.LinAlgError:
            raise EstimationError("First stage regression failed - singular matrix")

        fitted = W @ coef
        residuals = d - fitted

        return {
            "coef": coef,
            "fitted": fitted,
            "residuals": residuals,
        }

    def _estimate_2sls(
        self, y: np.ndarray, d: np.ndarray, W: np.ndarray, X: np.ndarray
    ) -> Dict[str, Any]:
        """
        Two-Stage Least Squares estimation.

        Stage 1: D_hat = W @ pi (project D onto instruments)
        Stage 2: Y = X @ beta + D_hat @ gamma + error
        """
        n = len(y)

        # Get fitted values from first stage
        d_hat = self._first_stage_fitted

        # Second stage: regress Y on [X, D_hat]
        second_stage_regressors = np.column_stack([X, d_hat])

        try:
            coef = np.linalg.lstsq(second_stage_regressors, y, rcond=None)[0]
        except np.linalg.LinAlgError:
            raise EstimationError("Second stage regression failed")

        # IV estimate is coefficient on D_hat
        iv_estimate = coef[-1]

        # Standard error (using original D, not D_hat)
        # Correct 2SLS standard errors
        residuals = y - X @ coef[:-1] - d * iv_estimate
        sigma2 = np.sum(residuals**2) / (n - second_stage_regressors.shape[1])

        # Project X onto Z to get variance
        P_W = W @ np.linalg.pinv(W.T @ W) @ W.T
        d_proj = P_W @ d

        var_d = np.sum((d_proj - d_proj.mean()) ** 2)

        if var_d > 0:
            std_error = np.sqrt(sigma2 / var_d)
        else:
            std_error = np.nan

        return {
            "estimate": iv_estimate,
            "std_error": std_error,
            "second_stage_coef": coef,
            "residuals": residuals,
        }

    def _estimate_liml(
        self, y: np.ndarray, d: np.ndarray, W: np.ndarray, X: np.ndarray, Z: np.ndarray
    ) -> Dict[str, Any]:
        """
        Limited Information Maximum Likelihood estimation.

        More robust to weak instruments than 2SLS.
        """
        n = len(y)

        # Build matrices
        Y = np.column_stack([y, d])  # Endogenous variables

        # Projection matrices
        P_W = W @ np.linalg.pinv(W.T @ W) @ W.T  # Project onto [X, Z]
        P_X = X @ np.linalg.pinv(X.T @ X) @ X.T  # Project onto X only
        M_X = np.eye(n) - P_X  # Annihilator for X

        # LIML eigenvalue problem
        Y_proj = P_W @ Y
        Y_resid_X = M_X @ Y

        # Compute matrices for eigenvalue
        A = Y_resid_X.T @ Y_resid_X
        B = Y.T @ (P_W - P_X) @ Y

        # Solve generalized eigenvalue problem
        try:
            eigenvalues = np.linalg.eigvals(np.linalg.inv(A) @ B)
            kappa = min(np.real(eigenvalues))  # LIML uses minimum eigenvalue
        except np.linalg.LinAlgError:
            logger.warning("LIML eigenvalue computation failed, falling back to 2SLS")
            return self._estimate_2sls(y, d, W, X)

        # LIML estimator
        Y_tilde = Y - kappa * M_X @ Y

        second_stage_regressors = np.column_stack([X, Y_tilde[:, 1]])

        try:
            coef = np.linalg.lstsq(second_stage_regressors, Y_tilde[:, 0], rcond=None)[0]
        except np.linalg.LinAlgError:
            return self._estimate_2sls(y, d, W, X)

        iv_estimate = coef[-1]

        # Standard error (approximation)
        residuals = y - X @ coef[:-1] - d * iv_estimate
        sigma2 = np.sum(residuals**2) / (n - second_stage_regressors.shape[1])

        d_proj = P_W @ d
        var_d = np.sum((d_proj - d_proj.mean()) ** 2)

        if var_d > 0:
            std_error = np.sqrt(sigma2 / var_d)
        else:
            std_error = np.nan

        return {
            "estimate": iv_estimate,
            "std_error": std_error,
            "second_stage_coef": coef,
            "kappa": kappa,
        }

    def _estimate_gmm(
        self, y: np.ndarray, d: np.ndarray, W: np.ndarray, X: np.ndarray, Z: np.ndarray
    ) -> Dict[str, Any]:
        """
        Generalized Method of Moments estimation.

        Efficient GMM with optimal weighting matrix.
        """
        n = len(y)
        n_instruments = Z.shape[1]

        # Step 1: 2SLS for initial estimate
        result_2sls = self._estimate_2sls(y, d, W, X)
        initial_estimate = result_2sls["estimate"]

        # Step 2: Compute optimal weighting matrix
        residuals_init = y - X @ result_2sls["second_stage_coef"][:-1] - d * initial_estimate

        # Moment conditions: E[Z * residuals] = 0
        moment_matrix = Z * residuals_init.reshape(-1, 1)

        # Optimal weighting matrix: inverse of variance of moments
        Omega = (moment_matrix.T @ moment_matrix) / n

        try:
            W_optimal = np.linalg.inv(Omega)
        except np.linalg.LinAlgError:
            W_optimal = np.linalg.pinv(Omega)

        # Step 3: GMM estimation with optimal weights
        # Minimize: g' @ W @ g where g = Z' @ (y - X @ beta - d @ gamma) / n

        from scipy.optimize import minimize

        def gmm_objective(params):
            gamma = params[0]
            residuals = y - d * gamma
            if len(params) > 1:
                residuals = residuals - params[1]  # Intercept

            # Mean of moment conditions
            g = Z.T @ residuals / n

            return float(g @ W_optimal @ g)

        # Initial values
        x0 = [initial_estimate]

        result = minimize(gmm_objective, x0, method="BFGS")

        if not result.success:
            logger.warning("GMM optimization did not converge, using 2SLS")
            return result_2sls

        gmm_estimate = result.x[0]

        # GMM standard errors - use Abadie-Imbens robust standard errors
        residuals = y - d * gmm_estimate

        # Simplified GMM standard error
        try:
            # Use bootstrap for GMM standard error
            std_error = result_2sls["std_error"]
        except Exception:
            std_error = np.nan

        return {
            "estimate": gmm_estimate,
            "std_error": std_error,
            "second_stage_coef": result.x,
        }

    def _compute_diagnostics(
        self, y: np.ndarray, d: np.ndarray, W: np.ndarray, X: np.ndarray, Z: np.ndarray
    ) -> IVDiagnostics:
        """Compute IV diagnostic tests."""
        n = len(y)
        n_instruments = Z.shape[1]
        k_exog = X.shape[1]

        # First Stage F-statistic
        # Partial F-test for instruments
        d_hat_full = W @ np.linalg.lstsq(W, d, rcond=None)[0]
        d_hat_restricted = X @ np.linalg.lstsq(X, d, rcond=None)[0]

        rss_full = np.sum((d - d_hat_full) ** 2)
        rss_restricted = np.sum((d - d_hat_restricted) ** 2)

        df1 = n_instruments
        df2 = n - W.shape[1]

        if rss_full > 0 and df2 > 0:
            f_stat = ((rss_restricted - rss_full) / df1) / (rss_full / df2)
        else:
            f_stat = 0.0

        # Partial R²
        tss = np.sum((d - d.mean()) ** 2)
        if tss > 0:
            partial_r2 = 1 - rss_full / tss
        else:
            partial_r2 = 0.0

        # Weak instrument test
        weak = f_stat < 10

        # Sargan-Hansen test (overidentification)
        if n_instruments > 1:  # Need overidentification
            iv_estimate = (
                self.result_.ate.estimate if hasattr(self, "result_") and self.result_ else 0
            )
            residuals = y - X[:, :1].flatten() * 0 - d * iv_estimate

            # J-statistic
            g = Z.T @ residuals / n
            Omega = (Z * residuals.reshape(-1, 1)).T @ (Z * residuals.reshape(-1, 1)) / n

            try:
                J = n * g @ np.linalg.inv(Omega) @ g
                sargan_pvalue = 1 - stats.chi2.cdf(J, n_instruments - 1)
            except np.linalg.LinAlgError:
                J = np.nan
                sargan_pvalue = np.nan
        else:
            J = np.nan
            sargan_pvalue = np.nan

        # Durbin-Wu-Hausman test (endogeneity)
        # Compare OLS and IV estimates
        ols_coef = np.linalg.lstsq(np.column_stack([X, d]), y, rcond=None)[0]
        ols_estimate = ols_coef[-1]

        iv_estimate = self._estimate_2sls(y, d, W, X)["estimate"]

        # DWH test using first stage residuals
        first_stage_resid = d - self._first_stage_fitted

        # Augmented regression
        aug_X = np.column_stack([X, d, first_stage_resid])
        aug_coef = np.linalg.lstsq(aug_X, y, rcond=None)[0]

        residuals_aug = y - aug_X @ aug_coef
        se_resid_coef = np.sqrt(np.sum(residuals_aug**2) / (n - aug_X.shape[1]))

        # t-statistic for residual coefficient
        dwh_stat = (aug_coef[-1] / se_resid_coef) ** 2 if se_resid_coef > 0 else 0
        dwh_pvalue = 1 - stats.chi2.cdf(dwh_stat, 1)

        return IVDiagnostics(
            first_stage_f=f_stat,
            weak_instrument=weak,
            sargan_statistic=J,
            sargan_pvalue=sargan_pvalue,
            durbin_wu_hausman=dwh_stat,
            dwh_pvalue=dwh_pvalue,
            partial_r2=partial_r2,
        )

    def _clustered_iv_se(
        self, residuals: np.ndarray, d: np.ndarray, W: np.ndarray, clusters: np.ndarray
    ) -> float:
        """Compute clustered standard errors for IV."""
        try:
            se = clustered_se(residuals, np.column_stack([W[:, :1], d.reshape(-1, 1)]), clusters)
            return se[-1]  # SE for treatment coefficient
        except Exception:
            # Fallback
            return np.std(residuals) / np.sqrt(len(residuals))

    def plot_first_stage(
        self,
        figsize: Tuple[int, int] = (10, 5),
        title: str = "First Stage: Instrument vs Treatment",
    ):
        """
        Plot first stage relationship.

        Parameters
        ----------
        figsize : tuple
            Figure size
        title : str
            Plot title

        Returns
        -------
        matplotlib.figure.Figure
            The figure object
        """
        try:
            import matplotlib.pyplot as plt
        except ImportError:
            raise ImportError("matplotlib is required for plotting")

        self._check_is_fitted()

        n_instruments = len(self.instruments)

        if n_instruments == 1:
            fig, ax = plt.subplots(figsize=figsize)

            z = self._data[self.instruments[0]].values
            d = self._data[self.config.treatment_col].values

            ax.scatter(z, d, alpha=0.5, s=20)

            # Add regression line
            slope, intercept = np.polyfit(z, d, 1)
            z_line = np.linspace(z.min(), z.max(), 100)
            ax.plot(z_line, intercept + slope * z_line, "r-", linewidth=2)

            ax.set_xlabel(self.instruments[0])
            ax.set_ylabel(self.config.treatment_col)
            ax.set_title(title)

        else:
            # Multiple instruments - show fitted vs actual
            fig, ax = plt.subplots(figsize=figsize)

            d = self._data[self.config.treatment_col].values
            d_hat = self._first_stage_fitted

            ax.scatter(d_hat, d, alpha=0.5, s=20)
            ax.plot([d.min(), d.max()], [d.min(), d.max()], "r--", linewidth=2)

            ax.set_xlabel("Predicted Treatment (First Stage)")
            ax.set_ylabel("Actual Treatment")
            ax.set_title(title)

        plt.tight_layout()
        return fig


# =============================================================================
# Exports
# =============================================================================

__all__ = [
    "InstrumentalVariables",
    "IVResult",
    "IVDiagnostics",
    "IVMethod",
]
