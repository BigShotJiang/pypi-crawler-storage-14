# ----------------------------------------------------------------------
# © 2025 KR-Labs. All rights reserved.
# KR-Labs™ is a trademark of Quipu Research Labs, LLC,
# a subsidiary of Sudiata Giddasira, Inc.
# ----------------------------------------------------------------------
# SPDX-License-Identifier: Apache-2.0

"""
Matching Estimators for Causal Inference.

This module implements various matching methods:
- Propensity Score Matching (PSM)
- Covariate Matching (Exact, Mahalanobis)
- Nearest Neighbor Matching
- Caliper Matching

References
----------
Rosenbaum, P. R., & Rubin, D. B. (1983). The Central Role of the 
    Propensity Score in Observational Studies for Causal Effects. 
    Biometrika.
Abadie, A., & Imbens, G. W. (2006). Large Sample Properties of 
    Matching Estimators for Average Treatment Effects. Econometrica.
"""

from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional, Tuple, Union

import numpy as np
import pandas as pd
from scipy import spatial, stats

from ..core.base import (
    BasePolicyEstimator,
    CausalEstimate,
    DataValidationError,
    DiagnosticResult,
    EffectType,
    EstimationError,
    EstimationMethod,
    PolicyConfig,
    TreatmentEffectResult,
)
from ..core.utils import (
    balance_check,
    bootstrap_ci,
    bootstrap_std_error,
    compute_ci,
    compute_p_value,
    standardized_mean_difference,
)

# Import logger
try:
    from krl_core import get_logger
except ImportError:
    import logging

    def get_logger(name: str):
        return logging.getLogger(name)


logger = get_logger(__name__)


# =============================================================================
# Enums
# =============================================================================


class MatchingMethod(Enum):
    """Matching method types."""

    PROPENSITY = "propensity"
    MAHALANOBIS = "mahalanobis"
    EUCLIDEAN = "euclidean"
    EXACT = "exact"


class ReplacementMode(Enum):
    """Matching with/without replacement."""

    WITH_REPLACEMENT = "with"
    WITHOUT_REPLACEMENT = "without"


# =============================================================================
# Result Classes
# =============================================================================


@dataclass
class MatchingResult:
    """
    Result from matching estimation.

    Attributes
    ----------
    ate : CausalEstimate
        Average Treatment Effect estimate
    att : CausalEstimate
        Average Treatment on Treated estimate
    matched_pairs : pd.DataFrame
        DataFrame of matched treated-control pairs
    propensity_scores : pd.Series, optional
        Propensity scores (for PSM)
    balance_before : Dict[str, Dict]
        Covariate balance before matching
    balance_after : Dict[str, Dict]
        Covariate balance after matching
    n_matched : int
        Number of successfully matched pairs
    n_dropped : int
        Number of units dropped (no match)
    """

    ate: CausalEstimate
    att: CausalEstimate = None
    matched_pairs: pd.DataFrame = None
    propensity_scores: pd.Series = None
    balance_before: Dict[str, Dict] = field(default_factory=dict)
    balance_after: Dict[str, Dict] = field(default_factory=dict)
    n_matched: int = 0
    n_dropped: int = 0
    diagnostics: DiagnosticResult = field(default_factory=DiagnosticResult)


# =============================================================================
# Propensity Score Matching Estimator
# =============================================================================


class PropensityScoreMatching(BasePolicyEstimator):
    """
    Propensity Score Matching estimator.

    Estimates treatment effects by matching treated units to control
    units with similar propensity scores (probability of treatment).

    Parameters
    ----------
    treatment_col : str
        Column name for treatment indicator
    outcome_col : str
        Column name for outcome variable
    covariates : List[str]
        Covariate columns for propensity score model
    n_matches : int, default=1
        Number of matches per treated unit
    caliper : float, optional
        Maximum propensity score distance for matching.
        If None, no caliper is applied.
    replacement : str, default='with'
        'with' for matching with replacement, 'without' for without
    estimand : str, default='att'
        Target estimand: 'att' or 'ate'
    propensity_model : str, default='logistic'
        Model for propensity scores: 'logistic', 'probit'
    n_bootstrap : int, default=1000
        Number of bootstrap iterations
    confidence_level : float, default=0.95
        Confidence level for intervals
    random_state : int, optional
        Random seed for reproducibility

    Examples
    --------
    >>> psm = PropensityScoreMatching(
    ...     treatment_col='treatment',
    ...     outcome_col='outcome',
    ...     covariates=['age', 'income', 'education'],
    ...     n_matches=1,
    ...     caliper=0.2
    ... )
    >>> result = psm.fit(data)
    >>> print(result.ate)
    >>> print(result.balance_after)

    Notes
    -----
    Key assumptions:
    1. Unconfoundedness (selection on observables)
    2. Common support (overlap in propensity scores)
    3. Correct specification of propensity score model
    """

    def __init__(
        self,
        treatment_col: str = "treatment",
        outcome_col: str = "outcome",
        covariates: Optional[List[str]] = None,
        n_matches: int = 1,
        caliper: Optional[float] = None,
        replacement: str = "with",
        estimand: str = "att",
        propensity_model: str = "logistic",
        n_bootstrap: int = 1000,
        confidence_level: float = 0.95,
        random_state: Optional[int] = None,
        **kwargs,
    ):
        if covariates is None:
            raise ValueError("covariates must be specified for propensity score matching")

        config = PolicyConfig(
            treatment_col=treatment_col,
            outcome_col=outcome_col,
            covariates=covariates,
            n_bootstrap=n_bootstrap,
            confidence_level=confidence_level,
            random_state=random_state,
        )
        super().__init__(config=config, **kwargs)

        self.n_matches = n_matches
        self.caliper = caliper
        self.replacement = replacement.lower()
        self.estimand = estimand.lower()
        self.propensity_model = propensity_model.lower()

        # PSM-specific attributes
        self._propensity_scores: Optional[pd.Series] = None
        self._matched_pairs: Optional[pd.DataFrame] = None
        self._balance_before: Dict[str, Dict] = {}
        self._balance_after: Dict[str, Dict] = {}

        # Validate parameters
        if self.replacement not in ["with", "without"]:
            raise ValueError("replacement must be 'with' or 'without'")
        if self.estimand not in ["att", "ate"]:
            raise ValueError("estimand must be 'att' or 'ate'")

        logger.debug(f"Initialized PSM with {len(covariates)} covariates")

    def fit(self, data: pd.DataFrame) -> TreatmentEffectResult:
        """
        Fit propensity score matching and estimate treatment effect.

        Parameters
        ----------
        data : pd.DataFrame
            Data with treatment, outcome, and covariate columns

        Returns
        -------
        TreatmentEffectResult
            Complete result with PSM estimate and diagnostics
        """
        # Validate data
        self.validate_data(data)
        self._data = data.copy().reset_index(drop=True)

        # Compute balance before matching
        self._balance_before = balance_check(
            self._data,
            self.config.treatment_col,
            self.config.covariates,
        )

        logger.info("Estimating propensity scores...")

        # Estimate propensity scores
        self._propensity_scores = self._estimate_propensity_scores()

        # Check common support
        self._check_common_support()

        logger.info("Performing matching...")

        # Perform matching
        self._matched_pairs = self._perform_matching()

        n_matched = len(self._matched_pairs)
        n_treated = self._data[self.config.treatment_col].sum()
        n_dropped = n_treated - self._matched_pairs["treated_idx"].nunique()

        logger.info(f"Matched {n_matched} pairs, dropped {n_dropped} treated units")

        # Compute balance after matching
        matched_data = self._create_matched_dataset()
        self._balance_after = balance_check(
            matched_data,
            self.config.treatment_col,
            self.config.covariates,
        )

        # Estimate treatment effect
        ate_estimate, att_estimate = self._estimate_effect()

        # Bootstrap for inference
        std_error = self._bootstrap_std_error()

        ci_lower, ci_upper = compute_ci(att_estimate, std_error, self.config.confidence_level)
        p_value = compute_p_value(att_estimate, std_error)

        n_control = len(self._data) - n_treated

        att = CausalEstimate(
            estimate=att_estimate,
            std_error=std_error,
            ci_lower=ci_lower,
            ci_upper=ci_upper,
            p_value=p_value,
            effect_type=EffectType.ATT,
            method=EstimationMethod.MATCHING,
            n_treated=int(n_treated),
            n_control=n_control,
            confidence_level=self.config.confidence_level,
        )

        ate = CausalEstimate(
            estimate=ate_estimate,
            std_error=std_error,
            ci_lower=ci_lower,
            ci_upper=ci_upper,
            p_value=p_value,
            effect_type=EffectType.ATE,
            method=EstimationMethod.MATCHING,
            n_treated=int(n_treated),
            n_control=n_control,
            confidence_level=self.config.confidence_level,
        )

        # Build diagnostics
        max_smd_before = max(abs(v["smd"]) for v in self._balance_before.values())
        max_smd_after = max(abs(v["smd"]) for v in self._balance_after.values())

        diagnostics = DiagnosticResult(
            balance_statistics={
                cov: self._balance_after[cov]["smd"] for cov in self._balance_after
            },
            model_fit={
                "n_matched": n_matched,
                "n_dropped": n_dropped,
                "max_smd_before": max_smd_before,
                "max_smd_after": max_smd_after,
            },
            warnings=[],
        )

        if max_smd_after > 0.1:
            diagnostics.warnings.append(
                f"Covariate imbalance after matching (max SMD = {max_smd_after:.3f})"
            )

        if n_dropped > 0.1 * n_treated:
            diagnostics.warnings.append(
                f"{n_dropped} treated units ({100*n_dropped/n_treated:.1f}%) dropped"
            )

        self.result_ = TreatmentEffectResult(
            ate=ate,
            att=att,
            diagnostics=diagnostics,
            method=EstimationMethod.MATCHING,
            config=self.config,
        )

        self.is_fitted = True
        return self.result_

    def estimate_ate(self) -> CausalEstimate:
        """Return the ATE estimate."""
        self._check_is_fitted()
        return self.result_.ate

    def get_propensity_scores(self) -> pd.Series:
        """
        Get estimated propensity scores.

        Returns
        -------
        pd.Series
            Propensity scores
        """
        self._check_is_fitted()
        return self._propensity_scores

    def get_matched_pairs(self) -> pd.DataFrame:
        """
        Get matched pairs.

        Returns
        -------
        pd.DataFrame
            DataFrame with treated_idx, control_idx, and distance columns
        """
        self._check_is_fitted()
        return self._matched_pairs

    def get_balance_table(self) -> pd.DataFrame:
        """
        Get covariate balance comparison table.

        Returns
        -------
        pd.DataFrame
            Balance statistics before and after matching
        """
        self._check_is_fitted()

        rows = []
        for cov in self.config.covariates:
            before = self._balance_before.get(cov, {})
            after = self._balance_after.get(cov, {})

            rows.append(
                {
                    "covariate": cov,
                    "smd_before": before.get("smd", np.nan),
                    "smd_after": after.get("smd", np.nan),
                    "mean_treated_before": before.get("mean_treated", np.nan),
                    "mean_control_before": before.get("mean_control", np.nan),
                    "mean_treated_after": after.get("mean_treated", np.nan),
                    "mean_control_after": after.get("mean_control", np.nan),
                }
            )

        df = pd.DataFrame(rows)
        df["smd_reduction"] = abs(df["smd_before"]) - abs(df["smd_after"])

        return df

    def _estimate_propensity_scores(self) -> pd.Series:
        """Estimate propensity scores using logistic regression."""
        from sklearn.linear_model import LogisticRegression

        X = self._data[self.config.covariates].values
        y = self._data[self.config.treatment_col].values

        if self.propensity_model == "logistic":
            model = LogisticRegression(max_iter=1000, random_state=self.config.random_state)
        else:
            # Probit would require statsmodels, fallback to logistic
            logger.warning("Probit not available, using logistic regression")
            model = LogisticRegression(max_iter=1000, random_state=self.config.random_state)

        model.fit(X, y)
        propensity_scores = model.predict_proba(X)[:, 1]

        return pd.Series(propensity_scores, index=self._data.index, name="propensity_score")

    def _check_common_support(self) -> None:
        """Check for common support in propensity scores."""
        ps = self._propensity_scores
        treatment = self._data[self.config.treatment_col]

        ps_treated = ps[treatment == 1]
        ps_control = ps[treatment == 0]

        # Check overlap
        overlap_min = max(ps_treated.min(), ps_control.min())
        overlap_max = min(ps_treated.max(), ps_control.max())

        if overlap_max <= overlap_min:
            raise EstimationError(
                "No common support - propensity score distributions don't overlap"
            )

        # Warn if overlap is small
        n_treated_in_support = ((ps_treated >= overlap_min) & (ps_treated <= overlap_max)).sum()
        n_control_in_support = ((ps_control >= overlap_min) & (ps_control <= overlap_max)).sum()

        if n_treated_in_support < 0.8 * len(ps_treated):
            logger.warning(
                f"Only {100*n_treated_in_support/len(ps_treated):.1f}% of treated "
                "in common support region"
            )

    def _perform_matching(self) -> pd.DataFrame:
        """Perform nearest neighbor matching on propensity scores."""
        ps = self._propensity_scores
        treatment = self._data[self.config.treatment_col]

        treated_idx = self._data[treatment == 1].index.tolist()
        control_idx = self._data[treatment == 0].index.tolist()

        ps_treated = ps[treated_idx].values
        ps_control = ps[control_idx].values

        matched_pairs = []
        used_controls = set()

        # Build KD-tree for control propensity scores
        control_tree = spatial.KDTree(ps_control.reshape(-1, 1))

        for i, t_idx in enumerate(treated_idx):
            ps_t = ps_treated[i]

            # Find nearest neighbors
            distances, indices = control_tree.query(
                [[ps_t]],
                k=min(self.n_matches * 10, len(control_idx)),  # Get extras in case of caliper
            )

            distances = distances.flatten()
            indices = indices.flatten()

            matches_found = 0
            for dist, c_local_idx in zip(distances, indices):
                c_idx = control_idx[c_local_idx]

                # Apply caliper
                if self.caliper is not None and dist > self.caliper:
                    continue

                # Check replacement
                if self.replacement == "without" and c_idx in used_controls:
                    continue

                matched_pairs.append(
                    {
                        "treated_idx": t_idx,
                        "control_idx": c_idx,
                        "distance": dist,
                        "ps_treated": ps_t,
                        "ps_control": ps_control[c_local_idx],
                    }
                )

                if self.replacement == "without":
                    used_controls.add(c_idx)

                matches_found += 1
                if matches_found >= self.n_matches:
                    break

        return pd.DataFrame(matched_pairs)

    def _create_matched_dataset(self) -> pd.DataFrame:
        """Create dataset with matched observations."""
        # Get unique matched indices
        treated_idx = self._matched_pairs["treated_idx"].unique()
        control_idx = self._matched_pairs["control_idx"].unique()

        all_idx = list(set(treated_idx) | set(control_idx))

        return self._data.loc[all_idx]

    def _estimate_effect(self) -> Tuple[float, float]:
        """Estimate ATE and ATT from matched pairs."""
        y_col = self.config.outcome_col

        # Get outcomes for matched pairs
        treated_outcomes = []
        control_outcomes = []

        for _, row in self._matched_pairs.iterrows():
            t_idx = row["treated_idx"]
            c_idx = row["control_idx"]

            treated_outcomes.append(self._data.loc[t_idx, y_col])
            control_outcomes.append(self._data.loc[c_idx, y_col])

        treated_outcomes = np.array(treated_outcomes)
        control_outcomes = np.array(control_outcomes)

        # ATT: Simple difference for matched pairs
        att = np.mean(treated_outcomes - control_outcomes)

        # ATE: Need to account for matching weights
        if self.estimand == "ate":
            # Weight by inverse of number of times each control is used
            control_counts = self._matched_pairs["control_idx"].value_counts()
            weights = 1.0 / self._matched_pairs["control_idx"].map(control_counts)
            ate = np.average(treated_outcomes - control_outcomes, weights=weights)
        else:
            ate = att

        return ate, att

    def _bootstrap_std_error(self) -> float:
        """Bootstrap standard error for the treatment effect."""
        rng = np.random.default_rng(self.config.random_state)

        y_col = self.config.outcome_col
        matched_pairs = self._matched_pairs

        bootstrap_effects = []

        for _ in range(self.config.n_bootstrap):
            # Resample matched pairs
            sample_idx = rng.choice(len(matched_pairs), size=len(matched_pairs), replace=True)
            sample_pairs = matched_pairs.iloc[sample_idx]

            treated_outcomes = []
            control_outcomes = []

            for _, row in sample_pairs.iterrows():
                t_idx = row["treated_idx"]
                c_idx = row["control_idx"]

                treated_outcomes.append(self._data.loc[t_idx, y_col])
                control_outcomes.append(self._data.loc[c_idx, y_col])

            effect = np.mean(np.array(treated_outcomes) - np.array(control_outcomes))
            bootstrap_effects.append(effect)

        return np.std(bootstrap_effects, ddof=1)

    def plot_balance(
        self,
        figsize: Tuple[int, int] = (10, 8),
        title: str = "Covariate Balance: Before vs After Matching",
    ):
        """
        Plot covariate balance comparison.

        Parameters
        ----------
        figsize : tuple
            Figure size
        title : str
            Plot title

        Returns
        -------
        matplotlib.figure.Figure
            The figure object
        """
        try:
            import matplotlib.pyplot as plt
        except ImportError:
            raise ImportError("matplotlib is required for plotting")

        self._check_is_fitted()

        balance_df = self.get_balance_table()

        fig, ax = plt.subplots(figsize=figsize)

        y_positions = np.arange(len(balance_df))

        # Plot before matching (red squares)
        ax.scatter(
            balance_df["smd_before"],
            y_positions,
            marker="s",
            s=100,
            color="red",
            label="Before Matching",
            alpha=0.7,
        )

        # Plot after matching (blue circles)
        ax.scatter(
            balance_df["smd_after"],
            y_positions,
            marker="o",
            s=100,
            color="blue",
            label="After Matching",
            alpha=0.7,
        )

        # Connect before and after
        for i, (before, after) in enumerate(zip(balance_df["smd_before"], balance_df["smd_after"])):
            ax.plot([before, after], [i, i], "gray", alpha=0.5, linewidth=1)

        # Reference lines
        ax.axvline(x=0, color="black", linestyle="-", linewidth=1)
        ax.axvline(x=0.1, color="gray", linestyle="--", alpha=0.5)
        ax.axvline(x=-0.1, color="gray", linestyle="--", alpha=0.5)
        ax.axvspan(-0.1, 0.1, alpha=0.1, color="green")

        ax.set_yticks(y_positions)
        ax.set_yticklabels(balance_df["covariate"])
        ax.set_xlabel("Standardized Mean Difference")
        ax.set_title(title)
        ax.legend(loc="best")

        plt.tight_layout()
        return fig

    def plot_propensity_distribution(
        self,
        figsize: Tuple[int, int] = (10, 5),
        bins: int = 30,
        title: str = "Propensity Score Distribution",
    ):
        """
        Plot propensity score distributions.

        Parameters
        ----------
        figsize : tuple
            Figure size
        bins : int
            Number of histogram bins
        title : str
            Plot title

        Returns
        -------
        matplotlib.figure.Figure
            The figure object
        """
        try:
            import matplotlib.pyplot as plt
        except ImportError:
            raise ImportError("matplotlib is required for plotting")

        self._check_is_fitted()

        treatment = self._data[self.config.treatment_col]
        ps = self._propensity_scores

        fig, ax = plt.subplots(figsize=figsize)

        # Treated distribution
        ax.hist(
            ps[treatment == 1], bins=bins, alpha=0.5, color="blue", label="Treated", density=True
        )

        # Control distribution
        ax.hist(
            ps[treatment == 0], bins=bins, alpha=0.5, color="red", label="Control", density=True
        )

        ax.set_xlabel("Propensity Score")
        ax.set_ylabel("Density")
        ax.set_title(title)
        ax.legend()

        plt.tight_layout()
        return fig


# =============================================================================
# Covariate Matching Estimator
# =============================================================================


class CovariateMatching(BasePolicyEstimator):
    """
    Covariate (Mahalanobis) Matching estimator.

    Matches units directly on covariates using distance metrics
    rather than propensity scores.

    Parameters
    ----------
    treatment_col : str
        Column name for treatment indicator
    outcome_col : str
        Column name for outcome variable
    covariates : List[str]
        Covariate columns for matching
    distance : str, default='mahalanobis'
        Distance metric: 'mahalanobis', 'euclidean'
    n_matches : int, default=1
        Number of matches per treated unit
    caliper : float, optional
        Maximum distance for matching
    replacement : str, default='with'
        'with' for matching with replacement, 'without' for without
    n_bootstrap : int, default=1000
        Number of bootstrap iterations
    confidence_level : float, default=0.95
        Confidence level for intervals
    random_state : int, optional
        Random seed for reproducibility
    """

    def __init__(
        self,
        treatment_col: str = "treatment",
        outcome_col: str = "outcome",
        covariates: Optional[List[str]] = None,
        distance: str = "mahalanobis",
        n_matches: int = 1,
        caliper: Optional[float] = None,
        replacement: str = "with",
        n_bootstrap: int = 1000,
        confidence_level: float = 0.95,
        random_state: Optional[int] = None,
        **kwargs,
    ):
        if covariates is None:
            raise ValueError("covariates must be specified for covariate matching")

        config = PolicyConfig(
            treatment_col=treatment_col,
            outcome_col=outcome_col,
            covariates=covariates,
            n_bootstrap=n_bootstrap,
            confidence_level=confidence_level,
            random_state=random_state,
        )
        super().__init__(config=config, **kwargs)

        self.distance = distance.lower()
        self.n_matches = n_matches
        self.caliper = caliper
        self.replacement = replacement.lower()

        # Matching-specific attributes
        self._matched_pairs: Optional[pd.DataFrame] = None
        self._cov_matrix_inv: Optional[np.ndarray] = None

        if self.distance not in ["mahalanobis", "euclidean"]:
            raise ValueError("distance must be 'mahalanobis' or 'euclidean'")

        logger.debug(f"Initialized CovariateMatching with distance={distance}")

    def fit(self, data: pd.DataFrame) -> TreatmentEffectResult:
        """
        Fit covariate matching and estimate treatment effect.

        Parameters
        ----------
        data : pd.DataFrame
            Data with treatment, outcome, and covariate columns

        Returns
        -------
        TreatmentEffectResult
            Complete result with matching estimate and diagnostics
        """
        # Validate data
        self.validate_data(data)
        self._data = data.copy().reset_index(drop=True)

        logger.info(f"Performing {self.distance} matching...")

        # Compute covariance matrix inverse for Mahalanobis
        if self.distance == "mahalanobis":
            X = self._data[self.config.covariates].values
            cov_matrix = np.cov(X.T)
            self._cov_matrix_inv = np.linalg.pinv(cov_matrix)

        # Perform matching
        self._matched_pairs = self._perform_matching()

        n_matched = len(self._matched_pairs)
        n_treated = self._data[self.config.treatment_col].sum()
        n_dropped = n_treated - self._matched_pairs["treated_idx"].nunique()

        logger.info(f"Matched {n_matched} pairs")

        # Estimate treatment effect
        ate_estimate, att_estimate = self._estimate_effect()

        # Bootstrap standard error
        std_error = self._bootstrap_std_error()

        ci_lower, ci_upper = compute_ci(att_estimate, std_error, self.config.confidence_level)
        p_value = compute_p_value(att_estimate, std_error)

        n_control = len(self._data) - n_treated

        att = CausalEstimate(
            estimate=att_estimate,
            std_error=std_error,
            ci_lower=ci_lower,
            ci_upper=ci_upper,
            p_value=p_value,
            effect_type=EffectType.ATT,
            method=EstimationMethod.MATCHING,
            n_treated=int(n_treated),
            n_control=n_control,
            confidence_level=self.config.confidence_level,
        )

        ate = CausalEstimate(
            estimate=ate_estimate,
            std_error=std_error,
            ci_lower=ci_lower,
            ci_upper=ci_upper,
            p_value=p_value,
            effect_type=EffectType.ATE,
            method=EstimationMethod.MATCHING,
            n_treated=int(n_treated),
            n_control=n_control,
            confidence_level=self.config.confidence_level,
        )

        diagnostics = DiagnosticResult(
            model_fit={
                "n_matched": n_matched,
                "n_dropped": n_dropped,
                "distance_metric": self.distance,
            },
            warnings=[],
        )

        if n_dropped > 0.1 * n_treated:
            diagnostics.warnings.append(f"{n_dropped} treated units dropped")

        self.result_ = TreatmentEffectResult(
            ate=ate,
            att=att,
            diagnostics=diagnostics,
            method=EstimationMethod.MATCHING,
            config=self.config,
        )

        self.is_fitted = True
        return self.result_

    def estimate_ate(self) -> CausalEstimate:
        """Return the ATE estimate."""
        self._check_is_fitted()
        return self.result_.ate

    def _mahalanobis_distance(self, x1: np.ndarray, x2: np.ndarray) -> float:
        """Compute Mahalanobis distance."""
        diff = x1 - x2
        return np.sqrt(diff @ self._cov_matrix_inv @ diff)

    def _perform_matching(self) -> pd.DataFrame:
        """Perform nearest neighbor matching on covariates."""
        X = self._data[self.config.covariates].values
        treatment = self._data[self.config.treatment_col]

        treated_idx = self._data[treatment == 1].index.tolist()
        control_idx = self._data[treatment == 0].index.tolist()

        X_treated = X[treatment == 1]
        X_control = X[treatment == 0]

        matched_pairs = []
        used_controls = set()

        # Build distance matrix / tree
        if self.distance == "euclidean":
            control_tree = spatial.KDTree(X_control)

        for i, t_idx in enumerate(treated_idx):
            x_t = X_treated[i]

            if self.distance == "euclidean":
                distances, indices = control_tree.query(
                    [x_t], k=min(self.n_matches * 10, len(control_idx))
                )
                distances = distances.flatten()
                indices = indices.flatten()
            else:
                # Mahalanobis: compute all distances
                distances = []
                indices = list(range(len(control_idx)))
                for j, x_c in enumerate(X_control):
                    d = self._mahalanobis_distance(x_t, x_c)
                    distances.append(d)
                distances = np.array(distances)
                sorted_idx = np.argsort(distances)
                distances = distances[sorted_idx]
                indices = [indices[j] for j in sorted_idx]

            matches_found = 0
            for dist, c_local_idx in zip(distances, indices):
                c_idx = control_idx[c_local_idx]

                if self.caliper is not None and dist > self.caliper:
                    continue

                if self.replacement == "without" and c_idx in used_controls:
                    continue

                matched_pairs.append(
                    {
                        "treated_idx": t_idx,
                        "control_idx": c_idx,
                        "distance": dist,
                    }
                )

                if self.replacement == "without":
                    used_controls.add(c_idx)

                matches_found += 1
                if matches_found >= self.n_matches:
                    break

        return pd.DataFrame(matched_pairs)

    def _estimate_effect(self) -> Tuple[float, float]:
        """Estimate ATE and ATT from matched pairs."""
        y_col = self.config.outcome_col

        treated_outcomes = []
        control_outcomes = []

        for _, row in self._matched_pairs.iterrows():
            t_idx = row["treated_idx"]
            c_idx = row["control_idx"]

            treated_outcomes.append(self._data.loc[t_idx, y_col])
            control_outcomes.append(self._data.loc[c_idx, y_col])

        treated_outcomes = np.array(treated_outcomes)
        control_outcomes = np.array(control_outcomes)

        att = np.mean(treated_outcomes - control_outcomes)
        ate = att

        return ate, att

    def _bootstrap_std_error(self) -> float:
        """Bootstrap standard error."""
        rng = np.random.default_rng(self.config.random_state)

        y_col = self.config.outcome_col
        matched_pairs = self._matched_pairs

        bootstrap_effects = []

        for _ in range(self.config.n_bootstrap):
            sample_idx = rng.choice(len(matched_pairs), size=len(matched_pairs), replace=True)
            sample_pairs = matched_pairs.iloc[sample_idx]

            treated_outcomes = []
            control_outcomes = []

            for _, row in sample_pairs.iterrows():
                t_idx = row["treated_idx"]
                c_idx = row["control_idx"]

                treated_outcomes.append(self._data.loc[t_idx, y_col])
                control_outcomes.append(self._data.loc[c_idx, y_col])

            effect = np.mean(np.array(treated_outcomes) - np.array(control_outcomes))
            bootstrap_effects.append(effect)

        return np.std(bootstrap_effects, ddof=1)


# =============================================================================
# Exports
# =============================================================================

__all__ = [
    "PropensityScoreMatching",
    "CovariateMatching",
    "MatchingResult",
    "MatchingMethod",
    "ReplacementMode",
]
