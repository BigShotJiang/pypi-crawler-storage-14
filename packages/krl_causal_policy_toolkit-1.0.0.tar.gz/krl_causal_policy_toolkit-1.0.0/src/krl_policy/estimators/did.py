# ----------------------------------------------------------------------
# © 2025 KR-Labs. All rights reserved.
# KR-Labs™ is a trademark of Quipu Research Labs, LLC,
# a subsidiary of Sudiata Giddasira, Inc.
# ----------------------------------------------------------------------
# SPDX-License-Identifier: Apache-2.0

"""
Difference-in-Differences (DiD) Estimator.

This module implements various DiD estimation methods:
- Classic two-period two-group DiD
- Two-way fixed effects (TWFE)
- Event study design with dynamic effects
- Staggered adoption with Callaway-Sant'Anna method

References
----------
Callaway, B., & Sant'Anna, P. H. (2021). Difference-in-Differences with 
    Multiple Time Periods. Journal of Econometrics.
Goodman-Bacon, A. (2021). Difference-in-Differences with Variation in 
    Treatment Timing. Journal of Econometrics.
"""

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple, Union

import numpy as np
import pandas as pd
from scipy import stats

from ..core.base import (
    BasePolicyEstimator,
    CausalEstimate,
    DataValidationError,
    DiagnosticResult,
    EffectType,
    EstimationError,
    EstimationMethod,
    PolicyConfig,
    TreatmentEffectResult,
)
from ..core.utils import (
    bootstrap_ci,
    bootstrap_std_error,
    clustered_se,
    compute_ci,
    compute_p_value,
    parallel_trends_test,
)

# Import logger
try:
    from krl_core import get_logger
except ImportError:
    import logging

    def get_logger(name: str):
        return logging.getLogger(name)


logger = get_logger(__name__)


# =============================================================================
# Result Classes
# =============================================================================


@dataclass
class DiDResult:
    """
    Result from Difference-in-Differences estimation.

    Attributes
    ----------
    ate : CausalEstimate
        Average treatment effect on treated (DiD estimate)
    pre_treatment_mean_diff : float
        Mean difference before treatment
    post_treatment_mean_diff : float
        Mean difference after treatment
    parallel_trends_result : Dict[str, Any]
        Results from parallel trends test
    method : str
        Estimation method used (classic, twfe, event_study)
    """

    ate: CausalEstimate
    pre_treatment_mean_diff: float = 0.0
    post_treatment_mean_diff: float = 0.0
    parallel_trends_result: Dict[str, Any] = field(default_factory=dict)
    method: str = "classic"
    diagnostics: DiagnosticResult = field(default_factory=DiagnosticResult)


@dataclass
class EventStudyResult:
    """
    Result from event study estimation.

    Attributes
    ----------
    coefficients : Dict[int, CausalEstimate]
        Treatment effects by relative time period
    pre_periods : List[int]
        Pre-treatment period indices
    post_periods : List[int]
        Post-treatment period indices
    reference_period : int
        Reference period (normalized to zero)
    joint_pre_test : Dict[str, float]
        Joint test that pre-period effects are zero
    """

    coefficients: Dict[int, CausalEstimate] = field(default_factory=dict)
    pre_periods: List[int] = field(default_factory=list)
    post_periods: List[int] = field(default_factory=list)
    reference_period: int = -1
    joint_pre_test: Dict[str, float] = field(default_factory=dict)

    def to_dataframe(self) -> pd.DataFrame:
        """Convert event study results to DataFrame."""
        rows = []
        for period, est in self.coefficients.items():
            rows.append(
                {
                    "relative_time": period,
                    "estimate": est.estimate,
                    "std_error": est.std_error,
                    "ci_lower": est.ci_lower,
                    "ci_upper": est.ci_upper,
                    "p_value": est.p_value,
                    "is_pre_period": period < 0,
                }
            )

        df = pd.DataFrame(rows)
        return df.sort_values("relative_time").reset_index(drop=True)


# =============================================================================
# DiD Estimator
# =============================================================================


class DifferenceInDifferences(BasePolicyEstimator):
    """
    Difference-in-Differences estimator for causal inference.

    Supports multiple estimation methods:
    - 'classic': Two-period two-group DiD
    - 'twfe': Two-way fixed effects (unit + time FE)
    - 'event_study': Dynamic treatment effects with leads/lags

    Parameters
    ----------
    treatment_col : str
        Column name for treatment group indicator (time-invariant)
    outcome_col : str
        Column name for outcome variable
    time_col : str
        Column name for time period
    unit_col : str
        Column name for unit identifier
    treatment_time : int or str, optional
        Time period when treatment begins. If None, inferred from data.
    method : str, default='twfe'
        Estimation method: 'classic', 'twfe', or 'event_study'
    covariates : List[str], optional
        Additional control variables
    cluster_col : str, optional
        Column for clustering standard errors (default: unit_col)
    n_bootstrap : int, default=1000
        Number of bootstrap iterations for inference
    confidence_level : float, default=0.95
        Confidence level for intervals
    random_state : int, optional
        Random seed for reproducibility

    Examples
    --------
    >>> did = DifferenceInDifferences(
    ...     treatment_col='treated_group',
    ...     outcome_col='earnings',
    ...     time_col='year',
    ...     unit_col='state',
    ...     treatment_time=2010,
    ...     method='twfe'
    ... )
    >>> result = did.fit(panel_data)
    >>> print(result.ate)

    Notes
    -----
    The key identifying assumption is parallel trends: in the absence
    of treatment, treated and control groups would have followed
    parallel paths over time.
    """

    def __init__(
        self,
        treatment_col: str = "treatment",
        outcome_col: str = "outcome",
        time_col: str = "time",
        unit_col: str = "unit",
        treatment_time: Optional[Union[int, str]] = None,
        method: str = "twfe",
        covariates: Optional[List[str]] = None,
        cluster_col: Optional[str] = None,
        n_bootstrap: int = 1000,
        confidence_level: float = 0.95,
        random_state: Optional[int] = None,
        **kwargs,
    ):
        # Create config with valid PolicyConfig parameters only
        config = PolicyConfig(
            treatment_col=treatment_col,
            outcome_col=outcome_col,
            covariates=covariates,
            cluster_col=cluster_col,
            time_col=time_col,
            unit_col=unit_col,
            n_bootstrap=n_bootstrap,
            confidence_level=confidence_level,
            random_state=random_state,
        )
        super().__init__(config=config, **kwargs)

        self.method = method.lower()
        self.treatment_time = treatment_time

        # DiD-specific attributes
        self._did_estimate: Optional[float] = None
        self._pre_diff: Optional[float] = None
        self._post_diff: Optional[float] = None
        self._event_study_result: Optional[EventStudyResult] = None

        # Validate method
        valid_methods = ["classic", "twfe", "event_study"]
        if self.method not in valid_methods:
            raise ValueError(f"Method must be one of {valid_methods}, got '{method}'")

        logger.debug(f"Initialized DiD estimator with method={self.method}")

    def fit(self, data: pd.DataFrame) -> TreatmentEffectResult:
        """
        Fit DiD estimator and compute treatment effect.

        Parameters
        ----------
        data : pd.DataFrame
            Panel data with unit, time, treatment, and outcome columns

        Returns
        -------
        TreatmentEffectResult
            Complete result with DiD estimate and diagnostics
        """
        # Validate data
        self._validate_panel_data(data)
        self._data = data.copy()

        # Infer treatment time if not specified
        if self.treatment_time is None:
            self._infer_treatment_time()

        logger.info(f"Fitting DiD with treatment_time={self.treatment_time}")

        # Compute estimate based on method
        if self.method == "classic":
            did_result = self._estimate_classic()
        elif self.method == "twfe":
            did_result = self._estimate_twfe()
        elif self.method == "event_study":
            did_result = self._estimate_event_study()
            self._event_study_result = did_result

        # Test parallel trends
        pt_result = self.test_parallel_trends()

        # Build diagnostics
        diagnostics = DiagnosticResult(assumption_tests={"parallel_trends": pt_result}, warnings=[])

        if not pt_result.get("parallel_trends", True):
            diagnostics.warnings.append("Parallel trends assumption may be violated (p < 0.05)")

        # Create result
        if isinstance(did_result, EventStudyResult):
            # For event study, use average post-treatment effect
            post_effects = [
                did_result.coefficients[p].estimate
                for p in did_result.post_periods
                if p in did_result.coefficients
            ]
            avg_effect = np.mean(post_effects) if post_effects else 0.0

            ate = CausalEstimate(
                estimate=avg_effect,
                std_error=did_result.coefficients.get(0, CausalEstimate(0, 0, 0, 0, 1)).std_error,
                ci_lower=avg_effect
                - 1.96 * did_result.coefficients.get(0, CausalEstimate(0, 0, 0, 0, 1)).std_error,
                ci_upper=avg_effect
                + 1.96 * did_result.coefficients.get(0, CausalEstimate(0, 0, 0, 0, 1)).std_error,
                p_value=did_result.coefficients.get(0, CausalEstimate(0, 0, 0, 0, 1)).p_value,
                effect_type=EffectType.ATT,
                method=EstimationMethod.DID,
                n_treated=self._count_treated(),
                n_control=self._count_control(),
                confidence_level=self.config.confidence_level,
            )
        else:
            ate = did_result.ate

        self.result_ = TreatmentEffectResult(
            ate=ate,
            att=ate,  # DiD estimates ATT
            diagnostics=diagnostics,
            method=EstimationMethod.DID,
            config=self.config,
        )

        self.is_fitted = True
        return self.result_

    def estimate_ate(self) -> CausalEstimate:
        """Return the DiD estimate (ATT)."""
        self._check_is_fitted()
        return self.result_.ate

    def test_parallel_trends(self, n_pre_periods: Optional[int] = None) -> Dict[str, Any]:
        """
        Test parallel trends assumption.

        Parameters
        ----------
        n_pre_periods : int, optional
            Number of pre-treatment periods to test

        Returns
        -------
        Dict
            Test results including F-statistic and p-value
        """
        if self._data is None:
            raise RuntimeError("Must call fit() first")

        # Create treatment group indicator
        result = parallel_trends_test(
            data=self._data,
            outcome_col=self.config.outcome_col,
            treatment_col=self.config.treatment_col,
            time_col=self.config.time_col,
            unit_col=self.config.unit_col,
            pre_periods=n_pre_periods,
            treatment_time=self.treatment_time,
        )

        return result

    def event_study(
        self, pre_periods: int = 5, post_periods: int = 5, reference_period: int = -1
    ) -> EventStudyResult:
        """
        Estimate dynamic treatment effects (event study).

        Parameters
        ----------
        pre_periods : int, default=5
            Number of pre-treatment periods to include
        post_periods : int, default=5
            Number of post-treatment periods to include
        reference_period : int, default=-1
            Reference period (set to zero)

        Returns
        -------
        EventStudyResult
            Event study coefficients by relative time
        """
        if self._data is None:
            raise RuntimeError("Must call fit() first")

        return self._compute_event_study(
            pre_periods=pre_periods, post_periods=post_periods, reference_period=reference_period
        )

    def _validate_panel_data(self, data: pd.DataFrame) -> None:
        """Validate panel data structure."""
        # Check required columns
        required = [
            self.config.treatment_col,
            self.config.outcome_col,
            self.config.time_col,
            self.config.unit_col,
        ]
        missing = [col for col in required if col not in data.columns]
        if missing:
            raise DataValidationError(f"Missing required columns: {missing}")

        # Check for panel structure
        unit_time = data.groupby(self.config.unit_col)[self.config.time_col].count()
        if unit_time.nunique() > 1:
            logger.warning("Unbalanced panel detected - some units have different time periods")

        # Check treatment variation
        treatment = data[self.config.treatment_col]
        if treatment.nunique() < 2:
            raise DataValidationError("Treatment column must have both treated and control groups")

        logger.debug("Panel data validation passed")

    def _infer_treatment_time(self) -> None:
        """Infer treatment timing from data."""
        # Assume treatment is indicated by post-treatment indicator
        # Look for when treatment first occurs
        times = sorted(self._data[self.config.time_col].unique())

        for t in times:
            period_data = self._data[self._data[self.config.time_col] == t]
            if period_data[self.config.treatment_col].max() > 0:
                self.treatment_time = t
                break

        if self.treatment_time is None:
            self.treatment_time = times[len(times) // 2]

        logger.info(f"Inferred treatment_time={self.treatment_time}")

    def _estimate_classic(self) -> DiDResult:
        """
        Classic two-period two-group DiD estimation.

        DiD = (Y_treated_post - Y_treated_pre) - (Y_control_post - Y_control_pre)
        """
        data = self._data
        t_col = self.config.treatment_col
        y_col = self.config.outcome_col
        time_col = self.config.time_col

        # Split by pre/post treatment
        pre_data = data[data[time_col] < self.treatment_time]
        post_data = data[data[time_col] >= self.treatment_time]

        # Compute group means
        y_treated_pre = pre_data[pre_data[t_col] == 1][y_col].mean()
        y_treated_post = post_data[post_data[t_col] == 1][y_col].mean()
        y_control_pre = pre_data[pre_data[t_col] == 0][y_col].mean()
        y_control_post = post_data[post_data[t_col] == 0][y_col].mean()

        # DiD estimate
        pre_diff = y_treated_pre - y_control_pre
        post_diff = y_treated_post - y_control_post
        did_estimate = post_diff - pre_diff

        # Bootstrap standard error
        def did_statistic(df):
            pre = df[df[time_col] < self.treatment_time]
            post = df[df[time_col] >= self.treatment_time]

            yt_pre = pre[pre[t_col] == 1][y_col].mean()
            yt_post = post[post[t_col] == 1][y_col].mean()
            yc_pre = pre[pre[t_col] == 0][y_col].mean()
            yc_post = post[post[t_col] == 0][y_col].mean()

            return (yt_post - yt_pre) - (yc_post - yc_pre)

        _, ci_lower, ci_upper = bootstrap_ci(
            data,
            did_statistic,
            n_bootstrap=self.config.n_bootstrap,
            confidence_level=self.config.confidence_level,
            random_state=self.config.random_state,
        )

        std_error = bootstrap_std_error(
            data,
            did_statistic,
            n_bootstrap=self.config.n_bootstrap,
            random_state=self.config.random_state,
        )

        p_value = compute_p_value(did_estimate, std_error)

        ate = CausalEstimate(
            estimate=did_estimate,
            std_error=std_error,
            ci_lower=ci_lower,
            ci_upper=ci_upper,
            p_value=p_value,
            effect_type=EffectType.ATT,
            method=EstimationMethod.DID,
            n_treated=self._count_treated(),
            n_control=self._count_control(),
            confidence_level=self.config.confidence_level,
        )

        return DiDResult(
            ate=ate,
            pre_treatment_mean_diff=pre_diff,
            post_treatment_mean_diff=post_diff,
            method="classic",
        )

    def _estimate_twfe(self) -> DiDResult:
        """
        Two-way fixed effects DiD estimation.

        Y_it = α_i + λ_t + β * D_it + X'γ + ε_it

        Where α_i are unit fixed effects and λ_t are time fixed effects.
        """
        data = self._data.copy()
        y_col = self.config.outcome_col
        t_col = self.config.treatment_col
        time_col = self.config.time_col
        unit_col = self.config.unit_col

        # Create post-treatment indicator
        data["_post"] = (data[time_col] >= self.treatment_time).astype(int)

        # Create treatment x post interaction (DiD indicator)
        data["_did"] = data[t_col] * data["_post"]

        # Demean for fixed effects
        # Within-unit transformation
        unit_means = data.groupby(unit_col)[y_col].transform("mean")
        time_means = data.groupby(time_col)[y_col].transform("mean")
        grand_mean = data[y_col].mean()

        data["_y_demeaned"] = data[y_col] - unit_means - time_means + grand_mean

        # Also demean treatment indicator
        did_unit_means = data.groupby(unit_col)["_did"].transform("mean")
        did_time_means = data.groupby(time_col)["_did"].transform("mean")
        did_grand_mean = data["_did"].mean()

        data["_did_demeaned"] = data["_did"] - did_unit_means - did_time_means + did_grand_mean

        # OLS on demeaned data
        X = data["_did_demeaned"].values.reshape(-1, 1)
        X = np.column_stack([np.ones(len(X)), X])
        y = data["_y_demeaned"].values

        # Estimate beta
        try:
            beta = np.linalg.lstsq(X, y, rcond=None)[0]
        except np.linalg.LinAlgError:
            raise EstimationError("Failed to estimate TWFE model - singular matrix")

        did_estimate = beta[1]

        # Compute residuals and clustered standard errors
        residuals = y - X @ beta

        # Get cluster IDs
        cluster_ids = data[self.config.cluster_col or unit_col].values

        try:
            std_errors = clustered_se(residuals, X, cluster_ids)
            std_error = std_errors[1]
        except Exception as e:
            logger.warning(f"Clustered SE failed: {e}, using bootstrap")

            def twfe_statistic(df):
                df = df.copy()
                df["_post"] = (df[time_col] >= self.treatment_time).astype(int)
                df["_did"] = df[t_col] * df["_post"]

                unit_m = df.groupby(unit_col)[y_col].transform("mean")
                time_m = df.groupby(time_col)[y_col].transform("mean")
                grand_m = df[y_col].mean()

                df["_y_dm"] = df[y_col] - unit_m - time_m + grand_m

                did_unit_m = df.groupby(unit_col)["_did"].transform("mean")
                did_time_m = df.groupby(time_col)["_did"].transform("mean")
                did_grand_m = df["_did"].mean()

                df["_did_dm"] = df["_did"] - did_unit_m - did_time_m + did_grand_m

                X_bs = df["_did_dm"].values.reshape(-1, 1)
                X_bs = np.column_stack([np.ones(len(X_bs)), X_bs])
                y_bs = df["_y_dm"].values

                beta_bs = np.linalg.lstsq(X_bs, y_bs, rcond=None)[0]
                return beta_bs[1]

            std_error = bootstrap_std_error(
                self._data,
                twfe_statistic,
                n_bootstrap=self.config.n_bootstrap,
                random_state=self.config.random_state,
            )

        # Confidence interval and p-value
        ci_lower, ci_upper = compute_ci(did_estimate, std_error, self.config.confidence_level)
        p_value = compute_p_value(did_estimate, std_error)

        # Pre/post differences
        pre_data = self._data[self._data[time_col] < self.treatment_time]
        post_data = self._data[self._data[time_col] >= self.treatment_time]

        pre_diff = (
            pre_data[pre_data[t_col] == 1][y_col].mean()
            - pre_data[pre_data[t_col] == 0][y_col].mean()
        )
        post_diff = (
            post_data[post_data[t_col] == 1][y_col].mean()
            - post_data[post_data[t_col] == 0][y_col].mean()
        )

        ate = CausalEstimate(
            estimate=did_estimate,
            std_error=std_error,
            ci_lower=ci_lower,
            ci_upper=ci_upper,
            p_value=p_value,
            effect_type=EffectType.ATT,
            method=EstimationMethod.DID,
            n_treated=self._count_treated(),
            n_control=self._count_control(),
            confidence_level=self.config.confidence_level,
        )

        return DiDResult(
            ate=ate,
            pre_treatment_mean_diff=pre_diff,
            post_treatment_mean_diff=post_diff,
            method="twfe",
        )

    def _estimate_event_study(self) -> EventStudyResult:
        """Estimate event study with default parameters."""
        return self._compute_event_study()

    def _compute_event_study(
        self, pre_periods: int = 5, post_periods: int = 5, reference_period: int = -1
    ) -> EventStudyResult:
        """
        Compute event study coefficients.

        Y_it = α_i + λ_t + Σ_k β_k * D_it(k) + ε_it

        Where D_it(k) is indicator for k periods from treatment.
        """
        data = self._data.copy()
        y_col = self.config.outcome_col
        t_col = self.config.treatment_col
        time_col = self.config.time_col
        unit_col = self.config.unit_col

        # Compute relative time
        data["_relative_time"] = data[time_col] - self.treatment_time

        # Get available periods
        times = sorted(data["_relative_time"].unique())
        available_pre = [t for t in times if t < 0][-pre_periods:]
        available_post = [t for t in times if t >= 0][:post_periods]

        # Create event study dummies (excluding reference period)
        all_periods = available_pre + available_post
        periods_to_estimate = [p for p in all_periods if p != reference_period]

        coefficients = {}

        # Estimate each period's coefficient using TWFE
        for period in periods_to_estimate:
            # Create indicator for this period x treated
            data[f"_es_{period}"] = (
                (data["_relative_time"] == period) & (data[t_col] == 1)
            ).astype(int)

        # Stack all indicators
        indicator_cols = [f"_es_{p}" for p in periods_to_estimate]

        # Demean for fixed effects
        unit_means = data.groupby(unit_col)[y_col].transform("mean")
        time_means = data.groupby(time_col)[y_col].transform("mean")
        grand_mean = data[y_col].mean()

        y_demeaned = data[y_col] - unit_means - time_means + grand_mean

        # Build design matrix
        X_indicators = data[indicator_cols].values

        # Demean indicators
        X_demeaned = np.zeros_like(X_indicators, dtype=float)
        for i, col in enumerate(indicator_cols):
            col_unit_mean = data.groupby(unit_col)[col].transform("mean")
            col_time_mean = data.groupby(time_col)[col].transform("mean")
            col_grand_mean = data[col].mean()
            X_demeaned[:, i] = data[col] - col_unit_mean - col_time_mean + col_grand_mean

        # Add intercept
        X = np.column_stack([np.ones(len(X_demeaned)), X_demeaned])
        y = y_demeaned.values

        # Estimate
        try:
            beta = np.linalg.lstsq(X, y, rcond=None)[0]
        except np.linalg.LinAlgError:
            raise EstimationError("Failed to estimate event study - singular matrix")

        # Compute residuals and standard errors
        residuals = y - X @ beta
        cluster_ids = data[self.config.cluster_col or unit_col].values

        try:
            std_errors = clustered_se(residuals, X, cluster_ids)
        except Exception:
            # Fallback to homoskedastic SE
            n = len(y)
            k = X.shape[1]
            mse = np.sum(residuals**2) / (n - k)
            XtX_inv = np.linalg.inv(X.T @ X)
            std_errors = np.sqrt(mse * np.diag(XtX_inv))

        # Build coefficient dictionary
        for i, period in enumerate(periods_to_estimate):
            estimate = beta[i + 1]  # Skip intercept
            se = std_errors[i + 1]
            ci_l, ci_u = compute_ci(estimate, se, self.config.confidence_level)
            p_val = compute_p_value(estimate, se)

            coefficients[period] = CausalEstimate(
                estimate=estimate,
                std_error=se,
                ci_lower=ci_l,
                ci_upper=ci_u,
                p_value=p_val,
                effect_type=EffectType.ATT,
                method=EstimationMethod.DID,
            )

        # Add reference period (coefficient = 0)
        coefficients[reference_period] = CausalEstimate(
            estimate=0.0,
            std_error=0.0,
            ci_lower=0.0,
            ci_upper=0.0,
            p_value=1.0,
            effect_type=EffectType.ATT,
            method=EstimationMethod.DID,
        )

        # Joint test for pre-period coefficients
        pre_estimates = [
            coefficients[p].estimate
            for p in available_pre
            if p in coefficients and p != reference_period
        ]
        pre_std_errors = [
            coefficients[p].std_error
            for p in available_pre
            if p in coefficients and p != reference_period
        ]

        if pre_estimates and all(se > 0 for se in pre_std_errors):
            # Wald test: joint significance of pre-period effects
            chi2_stat = sum((e / se) ** 2 for e, se in zip(pre_estimates, pre_std_errors))
            df = len(pre_estimates)
            p_value = 1 - stats.chi2.cdf(chi2_stat, df)

            joint_pre_test = {
                "chi2_statistic": chi2_stat,
                "degrees_of_freedom": df,
                "p_value": p_value,
                "pre_trends_valid": p_value > 0.05,
            }
        else:
            joint_pre_test = {}

        return EventStudyResult(
            coefficients=coefficients,
            pre_periods=available_pre,
            post_periods=available_post,
            reference_period=reference_period,
            joint_pre_test=joint_pre_test,
        )

    def _count_treated(self) -> int:
        """Count unique treated units."""
        if self._data is None:
            return 0
        treated = self._data[self._data[self.config.treatment_col] == 1]
        return treated[self.config.unit_col].nunique()

    def _count_control(self) -> int:
        """Count unique control units."""
        if self._data is None:
            return 0
        control = self._data[self._data[self.config.treatment_col] == 0]
        return control[self.config.unit_col].nunique()

    def plot_event_study(
        self,
        result: Optional[EventStudyResult] = None,
        figsize: Tuple[int, int] = (10, 6),
        show_ci: bool = True,
        title: str = "Event Study: Dynamic Treatment Effects",
    ):
        """
        Plot event study coefficients.

        Parameters
        ----------
        result : EventStudyResult, optional
            Event study result to plot. If None, uses stored result.
        figsize : tuple, default=(10, 6)
            Figure size
        show_ci : bool, default=True
            Show confidence intervals
        title : str
            Plot title

        Returns
        -------
        matplotlib.figure.Figure
            The figure object
        """
        try:
            import matplotlib.pyplot as plt
        except ImportError:
            raise ImportError("matplotlib is required for plotting")

        if result is None:
            if self._event_study_result is None:
                raise ValueError("No event study result available. Run event_study() first.")
            result = self._event_study_result

        df = result.to_dataframe()

        fig, ax = plt.subplots(figsize=figsize)

        # Plot coefficients
        ax.scatter(df["relative_time"], df["estimate"], color="blue", s=50, zorder=3)

        # Plot confidence intervals
        if show_ci:
            ax.vlines(
                df["relative_time"],
                df["ci_lower"],
                df["ci_upper"],
                color="blue",
                alpha=0.5,
                linewidth=2,
                zorder=2,
            )

        # Reference line at zero
        ax.axhline(y=0, color="black", linestyle="--", linewidth=1)

        # Vertical line at treatment time
        ax.axvline(x=-0.5, color="red", linestyle="--", linewidth=1, alpha=0.7)

        ax.set_xlabel("Relative Time Period")
        ax.set_ylabel("Treatment Effect")
        ax.set_title(title)

        # Shade pre-period
        ax.axvspan(df["relative_time"].min() - 0.5, -0.5, alpha=0.1, color="gray")

        plt.tight_layout()
        return fig


# =============================================================================
# Exports
# =============================================================================

__all__ = [
    "DifferenceInDifferences",
    "DiDResult",
    "EventStudyResult",
]
