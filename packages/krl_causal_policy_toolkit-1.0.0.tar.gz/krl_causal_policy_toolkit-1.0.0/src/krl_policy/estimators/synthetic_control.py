# ----------------------------------------------------------------------
# © 2025 KR-Labs. All rights reserved.
# KR-Labs™ is a trademark of Quipu Research Labs, LLC,
# a subsidiary of Sudiata Giddasira, Inc.
# ----------------------------------------------------------------------
# SPDX-License-Identifier: Apache-2.0

"""
Synthetic Control Method Estimator.

This module implements the Abadie-Gardeazabal-Diamond-Hainmueller
Synthetic Control Method for estimating causal effects of aggregate
interventions.

References
----------
Abadie, A., Diamond, A., & Hainmueller, J. (2010). Synthetic Control 
    Methods for Comparative Case Studies: Estimating the Effect of 
    California's Tobacco Control Program. JASA.
Abadie, A., & Gardeazabal, J. (2003). The Economic Costs of Conflict: 
    A Case Study of the Basque Country. AER.
"""

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple, Union

import numpy as np
import pandas as pd
from scipy import optimize, stats

from ..core.base import (
    BasePolicyEstimator,
    CausalEstimate,
    ConvergenceError,
    DataValidationError,
    DiagnosticResult,
    EffectType,
    EstimationError,
    EstimationMethod,
    PolicyConfig,
    TreatmentEffectResult,
)
from ..core.utils import (
    bootstrap_ci,
    bootstrap_std_error,
    compute_ci,
    compute_p_value,
)

# Import logger
try:
    from krl_core import get_logger
except ImportError:
    import logging

    def get_logger(name: str):
        return logging.getLogger(name)


logger = get_logger(__name__)


# =============================================================================
# Result Classes
# =============================================================================


@dataclass
class SyntheticControlResult:
    """
    Result from Synthetic Control Method estimation.

    Attributes
    ----------
    ate : CausalEstimate
        Average treatment effect estimate
    weights : pd.Series
        Donor unit weights (indexed by unit name)
    pre_rmspe : float
        Pre-treatment root mean squared prediction error
    post_rmspe : float
        Post-treatment root mean squared prediction error
    gaps : pd.Series
        Treatment effect by time period (treated - synthetic)
    treated_values : pd.Series
        Observed values for treated unit
    synthetic_values : pd.Series
        Synthetic control values
    predictor_balance : Dict[str, Dict]
        Balance of predictors between treated and synthetic
    """

    ate: CausalEstimate
    weights: pd.Series = None
    pre_rmspe: float = 0.0
    post_rmspe: float = 0.0
    gaps: pd.Series = None
    treated_values: pd.Series = None
    synthetic_values: pd.Series = None
    predictor_balance: Dict[str, Dict] = field(default_factory=dict)
    diagnostics: DiagnosticResult = field(default_factory=DiagnosticResult)


@dataclass
class PlaceboResult:
    """
    Result from placebo tests.

    Attributes
    ----------
    placebo_effects : Dict[str, float]
        Treatment effects when each donor is placebo treated
    placebo_rmspe_ratios : Dict[str, float]
        Post/pre RMSPE ratios for each placebo
    p_value : float
        P-value from placebo distribution
    rank : int
        Rank of true effect among placebos
    """

    placebo_effects: Dict[str, float] = field(default_factory=dict)
    placebo_rmspe_ratios: Dict[str, float] = field(default_factory=dict)
    p_value: float = 1.0
    rank: int = 0
    n_placebos: int = 0


# =============================================================================
# Synthetic Control Estimator
# =============================================================================


class SyntheticControlMethod(BasePolicyEstimator):
    """
    Synthetic Control Method for aggregate intervention analysis.

    Constructs a weighted combination of control (donor) units that
    approximates the pre-treatment characteristics of the treated unit,
    then uses this synthetic control as a counterfactual.

    Parameters
    ----------
    treated_unit : str or int
        Identifier for the treated unit
    outcome_col : str
        Column name for outcome variable
    time_col : str
        Column name for time period
    unit_col : str
        Column name for unit identifier
    treatment_time : int or str
        Time period when treatment begins
    donor_pool : List[str], optional
        Specific donor units to use. If None, uses all non-treated units.
    covariates : List[str], optional
        Predictor variables for matching
    custom_v : np.ndarray, optional
        Custom V matrix for predictor weighting. If None, optimized.
    n_bootstrap : int, default=1000
        Number of bootstrap iterations
    confidence_level : float, default=0.95
        Confidence level for intervals
    random_state : int, optional
        Random seed for reproducibility

    Examples
    --------
    >>> scm = SyntheticControlMethod(
    ...     treated_unit='California',
    ...     outcome_col='cigarette_sales',
    ...     time_col='year',
    ...     unit_col='state',
    ...     treatment_time=1989,
    ...     covariates=['income', 'beer_sales']
    ... )
    >>> result = scm.fit(panel_data)
    >>> print(result.weights)
    >>> print(result.gaps)

    Notes
    -----
    Key assumptions:
    1. Donor pool contains units unaffected by intervention
    2. Pre-treatment fit is good (low RMSPE)
    3. No anticipation effects
    """

    def __init__(
        self,
        treated_unit: Union[str, int],
        outcome_col: str = "outcome",
        time_col: str = "time",
        unit_col: str = "unit",
        treatment_time: Optional[Union[int, str]] = None,
        donor_pool: Optional[List[Union[str, int]]] = None,
        covariates: Optional[List[str]] = None,
        custom_v: Optional[np.ndarray] = None,
        n_bootstrap: int = 1000,
        confidence_level: float = 0.95,
        random_state: Optional[int] = None,
        **kwargs,
    ):
        config = PolicyConfig(
            outcome_col=outcome_col,
            covariates=covariates,
            time_col=time_col,
            unit_col=unit_col,
            n_bootstrap=n_bootstrap,
            confidence_level=confidence_level,
            random_state=random_state,
        )
        super().__init__(config=config, **kwargs)

        self.treated_unit = treated_unit
        self.treatment_time = treatment_time
        self.donor_pool = donor_pool
        self.custom_v = custom_v

        # SCM-specific attributes
        self._weights: Optional[pd.Series] = None
        self._v_matrix: Optional[np.ndarray] = None
        self._gaps: Optional[pd.Series] = None
        self._treated_series: Optional[pd.Series] = None
        self._synthetic_series: Optional[pd.Series] = None
        self._pre_rmspe: float = 0.0
        self._post_rmspe: float = 0.0

        logger.debug(f"Initialized SCM for treated_unit={treated_unit}")

    def fit(self, data: pd.DataFrame) -> TreatmentEffectResult:
        """
        Fit synthetic control and estimate treatment effect.

        Parameters
        ----------
        data : pd.DataFrame
            Panel data with unit, time, outcome, and covariate columns

        Returns
        -------
        TreatmentEffectResult
            Complete result with SCM estimate and diagnostics
        """
        # Validate data
        self._validate_scm_data(data)
        self._data = data.copy()

        # Set up donor pool
        all_units = data[self.config.unit_col].unique()
        if self.donor_pool is None:
            self.donor_pool = [u for u in all_units if u != self.treated_unit]

        if len(self.donor_pool) < 2:
            raise DataValidationError("Need at least 2 donor units")

        logger.info(f"Fitting SCM with {len(self.donor_pool)} donor units")

        # Reshape data to wide format
        outcome_wide = self._reshape_to_wide(data, self.config.outcome_col)

        # Get pre-treatment and post-treatment periods
        times = sorted(data[self.config.time_col].unique())
        pre_times = [t for t in times if t < self.treatment_time]
        post_times = [t for t in times if t >= self.treatment_time]

        if len(pre_times) < 2:
            raise DataValidationError("Need at least 2 pre-treatment periods")

        # Build predictor matrices
        X0, X1 = self._build_predictor_matrices(data, outcome_wide, pre_times)

        # Optimize weights
        self._weights, self._v_matrix = self._optimize_weights(X0, X1)

        # Compute synthetic control series
        self._treated_series = outcome_wide[self.treated_unit]
        self._synthetic_series = self._compute_synthetic(outcome_wide)

        # Compute gaps (treatment effects)
        self._gaps = self._treated_series - self._synthetic_series

        # Compute RMSPE
        pre_gaps = self._gaps[self._gaps.index.isin(pre_times)]
        post_gaps = self._gaps[self._gaps.index.isin(post_times)]

        self._pre_rmspe = np.sqrt(np.mean(pre_gaps**2))
        self._post_rmspe = np.sqrt(np.mean(post_gaps**2))

        # Average treatment effect (post-treatment)
        ate_estimate = post_gaps.mean()

        # Bootstrap for inference
        def scm_statistic(df):
            # Re-run SCM on bootstrap sample
            try:
                ow = self._reshape_to_wide(df, self.config.outcome_col)
                X0_bs, X1_bs = self._build_predictor_matrices(df, ow, pre_times)
                w_bs, _ = self._optimize_weights(X0_bs, X1_bs)

                treated = ow[self.treated_unit]
                synth = sum(
                    w_bs.get(u, 0) * ow.get(u, pd.Series(0, index=ow.index))
                    for u in self.donor_pool
                )
                gaps = treated - synth
                return gaps[gaps.index.isin(post_times)].mean()
            except Exception:
                return np.nan

        std_error = bootstrap_std_error(
            data,
            scm_statistic,
            n_bootstrap=min(self.config.n_bootstrap, 200),  # Reduce for speed
            random_state=self.config.random_state,
        )

        ci_lower, ci_upper = compute_ci(ate_estimate, std_error, self.config.confidence_level)
        p_value = compute_p_value(ate_estimate, std_error)

        ate = CausalEstimate(
            estimate=ate_estimate,
            std_error=std_error,
            ci_lower=ci_lower,
            ci_upper=ci_upper,
            p_value=p_value,
            effect_type=EffectType.ATT,
            method=EstimationMethod.SCM,
            n_treated=1,
            n_control=len(self.donor_pool),
            confidence_level=self.config.confidence_level,
        )

        # Build diagnostics
        diagnostics = DiagnosticResult(
            model_fit={
                "pre_rmspe": self._pre_rmspe,
                "post_rmspe": self._post_rmspe,
                "rmspe_ratio": (
                    self._post_rmspe / self._pre_rmspe if self._pre_rmspe > 0 else np.inf
                ),
            },
            warnings=[],
        )

        if self._pre_rmspe > 0.1 * self._treated_series[pre_times].std():
            diagnostics.warnings.append(
                f"Pre-treatment RMSPE ({self._pre_rmspe:.4f}) is relatively large"
            )

        self.result_ = TreatmentEffectResult(
            ate=ate,
            att=ate,
            diagnostics=diagnostics,
            method=EstimationMethod.SCM,
            config=self.config,
        )

        self.is_fitted = True
        return self.result_

    def estimate_ate(self) -> CausalEstimate:
        """Return the SCM estimate (ATT)."""
        self._check_is_fitted()
        return self.result_.ate

    def get_weights(self) -> pd.Series:
        """
        Get donor unit weights.

        Returns
        -------
        pd.Series
            Weights indexed by donor unit name
        """
        self._check_is_fitted()
        return pd.Series(self._weights, name="weights").sort_values(ascending=False)

    def get_gaps(self) -> pd.Series:
        """
        Get treatment effect by time period.

        Returns
        -------
        pd.Series
            Gaps (treated - synthetic) indexed by time period
        """
        self._check_is_fitted()
        return self._gaps

    def placebo_test(
        self,
        in_space: bool = True,
        in_time: bool = False,
        placebo_time: Optional[Union[int, str]] = None,
    ) -> PlaceboResult:
        """
        Run placebo tests for inference.

        Parameters
        ----------
        in_space : bool, default=True
            Run in-space placebos (each donor as placebo treated)
        in_time : bool, default=False
            Run in-time placebo (pre-treatment placebo intervention)
        placebo_time : int or str, optional
            Time for in-time placebo (must be pre-treatment)

        Returns
        -------
        PlaceboResult
            Placebo test results with p-value
        """
        self._check_is_fitted()

        if not in_space and not in_time:
            raise ValueError("Must specify at least one placebo type")

        placebo_effects = {}
        placebo_rmspe_ratios = {}

        if in_space:
            # For each donor, run SCM as if it were treated
            for donor in self.donor_pool:
                try:
                    placebo_scm = SyntheticControlMethod(
                        treated_unit=donor,
                        outcome_col=self.config.outcome_col,
                        time_col=self.config.time_col,
                        unit_col=self.config.unit_col,
                        treatment_time=self.treatment_time,
                        donor_pool=[u for u in self.donor_pool if u != donor] + [self.treated_unit],
                        covariates=self.config.covariates,
                        n_bootstrap=100,  # Reduce for speed
                        random_state=self.config.random_state,
                    )

                    placebo_result = placebo_scm.fit(self._data)
                    placebo_effects[donor] = placebo_result.ate.estimate

                    if placebo_scm._pre_rmspe > 0:
                        placebo_rmspe_ratios[donor] = (
                            placebo_scm._post_rmspe / placebo_scm._pre_rmspe
                        )

                except Exception as e:
                    logger.warning(f"Placebo for {donor} failed: {e}")
                    continue

        # Compute p-value
        true_effect = abs(self.result_.ate.estimate)
        true_rmspe_ratio = self._post_rmspe / self._pre_rmspe if self._pre_rmspe > 0 else np.inf

        # Use RMSPE ratio for inference (more robust)
        all_ratios = list(placebo_rmspe_ratios.values()) + [true_rmspe_ratio]
        rank = sum(1 for r in all_ratios if r >= true_rmspe_ratio)
        n_total = len(all_ratios)
        p_value = rank / n_total

        return PlaceboResult(
            placebo_effects=placebo_effects,
            placebo_rmspe_ratios=placebo_rmspe_ratios,
            p_value=p_value,
            rank=rank,
            n_placebos=len(placebo_effects),
        )

    def _validate_scm_data(self, data: pd.DataFrame) -> None:
        """Validate data for SCM estimation."""
        # Check required columns
        required = [
            self.config.outcome_col,
            self.config.time_col,
            self.config.unit_col,
        ]
        missing = [col for col in required if col not in data.columns]
        if missing:
            raise DataValidationError(f"Missing required columns: {missing}")

        # Check treated unit exists
        units = data[self.config.unit_col].unique()
        if self.treated_unit not in units:
            raise DataValidationError(f"Treated unit '{self.treated_unit}' not found in data")

        # Check treatment time
        times = data[self.config.time_col].unique()
        if self.treatment_time is not None and self.treatment_time not in times:
            raise DataValidationError(f"Treatment time '{self.treatment_time}' not in data")

        logger.debug("SCM data validation passed")

    def _reshape_to_wide(self, data: pd.DataFrame, value_col: str) -> pd.DataFrame:
        """Reshape panel data to wide format (time x unit)."""
        return data.pivot(
            index=self.config.time_col, columns=self.config.unit_col, values=value_col
        )

    def _build_predictor_matrices(
        self, data: pd.DataFrame, outcome_wide: pd.DataFrame, pre_times: List
    ) -> Tuple[np.ndarray, np.ndarray]:
        """
        Build predictor matrices for optimization.

        X0: Predictors for donor units (k x J)
        X1: Predictors for treated unit (k x 1)
        """
        donors = self.donor_pool

        # Use pre-treatment outcome averages as predictors
        predictors = []

        # Pre-treatment outcome means
        for donor in donors:
            predictor_vals = outcome_wide.loc[pre_times, donor].values
            predictors.append(predictor_vals)

        X0 = np.column_stack(predictors)  # T_pre x J
        X1 = outcome_wide.loc[pre_times, self.treated_unit].values.reshape(-1, 1)  # T_pre x 1

        # Add covariates if specified
        if self.config.covariates:
            for cov in self.config.covariates:
                if cov in data.columns:
                    cov_wide = self._reshape_to_wide(data, cov)
                    cov_pre_means = cov_wide.loc[pre_times].mean()

                    X0 = np.vstack([X0, cov_pre_means[donors].values.reshape(1, -1)])
                    X1 = np.vstack([X1, [[cov_pre_means[self.treated_unit]]]])

        return X0, X1

    def _optimize_weights(
        self, X0: np.ndarray, X1: np.ndarray
    ) -> Tuple[Dict[str, float], np.ndarray]:
        """
        Optimize donor weights to minimize pre-treatment distance.

        Solves: min_W ||X1 - X0 @ W||^2
        subject to: W >= 0, sum(W) = 1
        """
        J = X0.shape[1]  # Number of donors

        if self.custom_v is not None:
            V = np.diag(self.custom_v)
        else:
            # Use uniform weighting of predictors
            V = np.eye(X0.shape[0])

        # Objective: ||X1 - X0 @ W||_V^2 = (X1 - X0@W)' V (X1 - X0@W)
        def objective(w):
            diff = X1.flatten() - X0 @ w
            return diff @ V @ diff

        # Constraints
        constraints = [{"type": "eq", "fun": lambda w: np.sum(w) - 1}]  # Sum to 1

        # Bounds: 0 <= w <= 1
        bounds = [(0, 1) for _ in range(J)]

        # Initial guess: uniform weights
        w0 = np.ones(J) / J

        # Optimize
        result = optimize.minimize(
            objective,
            w0,
            method="SLSQP",
            bounds=bounds,
            constraints=constraints,
            options={"maxiter": 1000, "ftol": 1e-10},
        )

        if not result.success:
            logger.warning(f"Optimization warning: {result.message}")

        # Build weights dictionary
        weights = {donor: result.x[i] for i, donor in enumerate(self.donor_pool)}

        return weights, V

    def _compute_synthetic(self, outcome_wide: pd.DataFrame) -> pd.Series:
        """Compute synthetic control as weighted average of donors."""
        synthetic = pd.Series(0.0, index=outcome_wide.index)

        for donor, weight in self._weights.items():
            if weight > 1e-6 and donor in outcome_wide.columns:
                synthetic += weight * outcome_wide[donor]

        return synthetic

    def plot_gaps(
        self,
        figsize: Tuple[int, int] = (12, 5),
        show_zero_line: bool = True,
        show_treatment_line: bool = True,
        title: str = None,
    ):
        """
        Plot treatment effects (gaps) over time.

        Parameters
        ----------
        figsize : tuple, default=(12, 5)
            Figure size
        show_zero_line : bool, default=True
            Show horizontal line at zero
        show_treatment_line : bool, default=True
            Show vertical line at treatment time
        title : str, optional
            Plot title

        Returns
        -------
        matplotlib.figure.Figure
            The figure object
        """
        try:
            import matplotlib.pyplot as plt
        except ImportError:
            raise ImportError("matplotlib is required for plotting")

        self._check_is_fitted()

        fig, axes = plt.subplots(1, 2, figsize=figsize)

        # Left panel: Treated vs Synthetic
        ax1 = axes[0]
        ax1.plot(
            self._treated_series.index,
            self._treated_series.values,
            "b-",
            label=f"Treated ({self.treated_unit})",
            linewidth=2,
        )
        ax1.plot(
            self._synthetic_series.index,
            self._synthetic_series.values,
            "r--",
            label="Synthetic Control",
            linewidth=2,
        )

        if show_treatment_line:
            ax1.axvline(x=self.treatment_time, color="gray", linestyle=":", alpha=0.7)

        ax1.set_xlabel("Time")
        ax1.set_ylabel(self.config.outcome_col)
        ax1.set_title("Treated vs Synthetic Control")
        ax1.legend()

        # Right panel: Gaps
        ax2 = axes[1]
        ax2.plot(self._gaps.index, self._gaps.values, "g-", linewidth=2)
        ax2.fill_between(self._gaps.index, self._gaps.values, 0, alpha=0.3, color="green")

        if show_zero_line:
            ax2.axhline(y=0, color="black", linestyle="--", alpha=0.5)

        if show_treatment_line:
            ax2.axvline(x=self.treatment_time, color="gray", linestyle=":", alpha=0.7)

        ax2.set_xlabel("Time")
        ax2.set_ylabel("Treatment Effect (Gap)")
        ax2.set_title("Treatment Effect over Time")

        if title:
            fig.suptitle(title, fontsize=14, y=1.02)

        plt.tight_layout()
        return fig

    def plot_weights(
        self,
        top_n: int = 10,
        figsize: Tuple[int, int] = (10, 6),
        title: str = "Synthetic Control Donor Weights",
    ):
        """
        Plot donor unit weights.

        Parameters
        ----------
        top_n : int, default=10
            Number of top donors to show
        figsize : tuple
            Figure size
        title : str
            Plot title

        Returns
        -------
        matplotlib.figure.Figure
            The figure object
        """
        try:
            import matplotlib.pyplot as plt
        except ImportError:
            raise ImportError("matplotlib is required for plotting")

        self._check_is_fitted()

        weights = self.get_weights()

        # Get top donors
        top_weights = weights.head(top_n)

        fig, ax = plt.subplots(figsize=figsize)

        bars = ax.barh(range(len(top_weights)), top_weights.values, color="steelblue")
        ax.set_yticks(range(len(top_weights)))
        ax.set_yticklabels(top_weights.index)
        ax.set_xlabel("Weight")
        ax.set_title(title)

        # Add weight labels
        for bar, weight in zip(bars, top_weights.values):
            if weight > 0.01:
                ax.text(
                    bar.get_width() + 0.01,
                    bar.get_y() + bar.get_height() / 2,
                    f"{weight:.3f}",
                    va="center",
                    fontsize=9,
                )

        ax.invert_yaxis()
        plt.tight_layout()
        return fig


# =============================================================================
# Exports
# =============================================================================

__all__ = [
    "SyntheticControlMethod",
    "SyntheticControlResult",
    "PlaceboResult",
]
