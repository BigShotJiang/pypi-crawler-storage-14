# ----------------------------------------------------------------------
# © 2025 KR-Labs. All rights reserved.
# KR-Labs™ is a trademark of Quipu Research Labs, LLC,
# a subsidiary of Sudiata Giddasira, Inc.
# ----------------------------------------------------------------------
# SPDX-License-Identifier: Apache-2.0

"""
Regression Discontinuity Design (RDD) Estimator.

This module implements Sharp and Fuzzy RDD estimation methods:
- Sharp RD: Treatment deterministically assigned at cutoff
- Fuzzy RD: Treatment probability jumps at cutoff (uses IV)
- Multiple bandwidth selection methods (IK, CCT, ROT)
- Local polynomial regression with various kernels

References
----------
Imbens, G., & Kalyanaraman, K. (2012). Optimal Bandwidth Choice for the 
    Regression Discontinuity Estimator. Review of Economic Studies.
Calonico, S., Cattaneo, M. D., & Titiunik, R. (2014). Robust Nonparametric 
    Confidence Intervals for Regression-Discontinuity Designs. Econometrica.
Lee, D. S., & Lemieux, T. (2010). Regression Discontinuity Designs in 
    Economics. Journal of Economic Literature.
"""

from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Callable, Dict, List, Optional, Tuple, Union

import numpy as np
import pandas as pd
from scipy import stats
from scipy.optimize import minimize_scalar

from ..core.base import (
    BasePolicyEstimator,
    CausalEstimate,
    DataValidationError,
    DiagnosticResult,
    EffectType,
    EstimationError,
    EstimationMethod,
    PolicyConfig,
    TreatmentEffectResult,
)
from ..core.utils import (
    bootstrap_ci,
    bootstrap_std_error,
    compute_ci,
    compute_p_value,
)

# Import logger
try:
    from krl_core import get_logger
except ImportError:
    import logging

    def get_logger(name: str):
        return logging.getLogger(name)


logger = get_logger(__name__)


# =============================================================================
# Enums and Types
# =============================================================================


class RDDType(Enum):
    """Type of regression discontinuity design."""

    SHARP = "sharp"
    FUZZY = "fuzzy"


class BandwidthMethod(Enum):
    """Bandwidth selection method."""

    IK = "ik"  # Imbens-Kalyanaraman optimal bandwidth
    CCT = "cct"  # Calonico-Cattaneo-Titiunik robust bandwidth
    ROT = "rot"  # Rule of thumb
    CV = "cv"  # Cross-validation
    MANUAL = "manual"  # User-specified


class KernelType(Enum):
    """Kernel function for local polynomial regression."""

    TRIANGULAR = "triangular"
    EPANECHNIKOV = "epanechnikov"
    UNIFORM = "uniform"
    GAUSSIAN = "gaussian"


# =============================================================================
# Result Classes
# =============================================================================


@dataclass
class RDDResult:
    """
    Result from Regression Discontinuity estimation.

    Attributes
    ----------
    ate : CausalEstimate
        Local Average Treatment Effect at cutoff
    bandwidth : float
        Bandwidth used for estimation
    bandwidth_method : str
        Method used for bandwidth selection
    n_left : int
        Number of observations left of cutoff (in bandwidth)
    n_right : int
        Number of observations right of cutoff (in bandwidth)
    polynomial_order : int
        Order of local polynomial used
    kernel : str
        Kernel function used
    rdd_type : str
        Type of RDD (sharp or fuzzy)
    first_stage : Optional[Dict]
        First stage results for fuzzy RDD
    diagnostics : DiagnosticResult
        Diagnostic information
    """

    ate: CausalEstimate
    bandwidth: float
    bandwidth_method: str
    n_left: int
    n_right: int
    polynomial_order: int = 1
    kernel: str = "triangular"
    rdd_type: str = "sharp"
    first_stage: Optional[Dict[str, Any]] = None
    diagnostics: DiagnosticResult = field(default_factory=DiagnosticResult)


@dataclass
class BandwidthResult:
    """
    Result from bandwidth selection.

    Attributes
    ----------
    bandwidth : float
        Selected optimal bandwidth
    method : str
        Method used for selection
    left_bandwidth : Optional[float]
        Left bandwidth (if asymmetric)
    right_bandwidth : Optional[float]
        Right bandwidth (if asymmetric)
    """

    bandwidth: float
    method: str
    left_bandwidth: Optional[float] = None
    right_bandwidth: Optional[float] = None


@dataclass
class ManipulationTestResult:
    """
    Result from manipulation/density test at cutoff.

    Attributes
    ----------
    statistic : float
        Test statistic
    p_value : float
        P-value for null of no manipulation
    n_left : int
        Observations just left of cutoff
    n_right : int
        Observations just right of cutoff
    passed : bool
        Whether test passed (no evidence of manipulation)
    """

    statistic: float
    p_value: float
    n_left: int
    n_right: int
    passed: bool


@dataclass
class PlaceboTestResult:
    """
    Result from placebo cutoff test.

    Attributes
    ----------
    placebo_cutoffs : List[float]
        Cutoff values tested
    estimates : List[CausalEstimate]
        Estimates at each placebo cutoff
    significant_count : int
        Number of significant placebo effects
    """

    placebo_cutoffs: List[float]
    estimates: List[CausalEstimate]
    significant_count: int


# =============================================================================
# Kernel Functions
# =============================================================================


def _triangular_kernel(u: np.ndarray) -> np.ndarray:
    """Triangular kernel: K(u) = (1 - |u|) for |u| <= 1."""
    return np.maximum(1.0 - np.abs(u), 0.0)


def _epanechnikov_kernel(u: np.ndarray) -> np.ndarray:
    """Epanechnikov kernel: K(u) = 0.75 * (1 - u^2) for |u| <= 1."""
    result = 0.75 * (1.0 - u**2)
    result[np.abs(u) > 1] = 0.0
    return result


def _uniform_kernel(u: np.ndarray) -> np.ndarray:
    """Uniform kernel: K(u) = 0.5 for |u| <= 1."""
    return np.where(np.abs(u) <= 1, 0.5, 0.0)


def _gaussian_kernel(u: np.ndarray) -> np.ndarray:
    """Gaussian kernel: K(u) = exp(-u^2/2) / sqrt(2*pi)."""
    return np.exp(-0.5 * u**2) / np.sqrt(2 * np.pi)


KERNEL_FUNCTIONS = {
    KernelType.TRIANGULAR: _triangular_kernel,
    KernelType.EPANECHNIKOV: _epanechnikov_kernel,
    KernelType.UNIFORM: _uniform_kernel,
    KernelType.GAUSSIAN: _gaussian_kernel,
}


# =============================================================================
# RegressionDiscontinuity Estimator
# =============================================================================


class RegressionDiscontinuity(BasePolicyEstimator):
    """
    Regression Discontinuity Design (RDD) estimator.

    Estimates local average treatment effects at a cutoff where treatment
    assignment changes discontinuously based on a running variable.

    Parameters
    ----------
    running_var : str
        Name of the running variable column
    outcome_col : str
        Name of the outcome column
    cutoff : float
        Cutoff value where treatment changes
    treatment_col : Optional[str]
        Treatment column (required for fuzzy RDD)
    rdd_type : Union[str, RDDType]
        Type of RDD: 'sharp' or 'fuzzy'
    bandwidth : Optional[float]
        Manual bandwidth (if None, computed automatically)
    bandwidth_method : Union[str, BandwidthMethod]
        Method for bandwidth selection
    kernel : Union[str, KernelType]
        Kernel function for weighting
    polynomial_order : int
        Order of local polynomial (1=linear, 2=quadratic)
    confidence_level : float
        Confidence level for intervals
    covariates : Optional[List[str]]
        Additional covariates to include
    cluster_col : Optional[str]
        Column for clustered standard errors

    Examples
    --------
    >>> # Sharp RDD example
    >>> rdd = RegressionDiscontinuity(
    ...     running_var='score',
    ...     outcome_col='outcome',
    ...     cutoff=50.0,
    ...     rdd_type='sharp'
    ... )
    >>> result = rdd.fit(data)
    >>> print(f"LATE: {result.ate.estimate:.3f}")

    >>> # Fuzzy RDD with automatic bandwidth
    >>> rdd = RegressionDiscontinuity(
    ...     running_var='score',
    ...     outcome_col='outcome',
    ...     cutoff=50.0,
    ...     treatment_col='treated',
    ...     rdd_type='fuzzy',
    ...     bandwidth_method='cct'
    ... )
    >>> result = rdd.fit(data)
    """

    def __init__(
        self,
        running_var: str,
        outcome_col: str,
        cutoff: float,
        treatment_col: Optional[str] = None,
        rdd_type: Union[str, RDDType] = RDDType.SHARP,
        bandwidth: Optional[float] = None,
        bandwidth_method: Union[str, BandwidthMethod] = BandwidthMethod.IK,
        kernel: Union[str, KernelType] = KernelType.TRIANGULAR,
        polynomial_order: int = 1,
        confidence_level: float = 0.95,
        covariates: Optional[List[str]] = None,
        cluster_col: Optional[str] = None,
        config: Optional[PolicyConfig] = None,
        **kwargs,
    ):
        super().__init__(
            treatment_col=treatment_col or "_treatment",
            outcome_col=outcome_col,
            covariates=covariates,
            config=config or PolicyConfig(),
        )

        self.running_var = running_var
        self.outcome_col = outcome_col  # Store explicitly for RDD logic
        self.cutoff = cutoff
        self.treatment_col = treatment_col  # Store treatment col explicitly
        self.covariates = covariates  # Store covariates explicitly
        self.manual_bandwidth = bandwidth
        self.cluster_col = cluster_col

        # Convert string to enum
        if isinstance(rdd_type, str):
            rdd_type = RDDType(rdd_type.lower())
        self.rdd_type = rdd_type

        if isinstance(bandwidth_method, str):
            bandwidth_method = BandwidthMethod(bandwidth_method.lower())
        self.bandwidth_method = bandwidth_method

        if isinstance(kernel, str):
            kernel = KernelType(kernel.lower())
        self.kernel = kernel

        self.polynomial_order = polynomial_order
        self.confidence_level = confidence_level

        # Validate fuzzy RDD requires treatment column
        if self.rdd_type == RDDType.FUZZY and treatment_col is None:
            raise ValueError("Fuzzy RDD requires treatment_col to be specified")

        # State
        self._fitted = False
        self._result: Optional[RDDResult] = None
        self._data: Optional[pd.DataFrame] = None
        self._bandwidth: Optional[float] = None

    def _validate_data(self, data: pd.DataFrame) -> None:
        """Validate input data for RDD."""
        # Check required columns
        required_cols = [self.running_var, self.outcome_col]
        if self.rdd_type == RDDType.FUZZY:
            required_cols.append(self.treatment_col)
        if self.covariates:
            required_cols.extend(self.covariates)
        if self.cluster_col:
            required_cols.append(self.cluster_col)

        missing = set(required_cols) - set(data.columns)
        if missing:
            raise DataValidationError(f"Missing columns: {missing}")

        # Check for sufficient observations on each side
        n_left = (data[self.running_var] < self.cutoff).sum()
        n_right = (data[self.running_var] >= self.cutoff).sum()

        if n_left < 10:
            raise DataValidationError(f"Insufficient observations left of cutoff: {n_left}")
        if n_right < 10:
            raise DataValidationError(f"Insufficient observations right of cutoff: {n_right}")

    def _get_kernel_weights(self, x: np.ndarray, bandwidth: float) -> np.ndarray:
        """Compute kernel weights for observations."""
        u = x / bandwidth
        kernel_func = KERNEL_FUNCTIONS[self.kernel]
        return kernel_func(u)

    def _select_bandwidth_ik(self, x: np.ndarray, y: np.ndarray) -> float:
        """
        Imbens-Kalyanaraman optimal bandwidth selection.

        Implements the optimal bandwidth from Imbens & Kalyanaraman (2012).
        """
        n = len(x)

        # Preliminary bandwidth (rule of thumb)
        h_rot = self._select_bandwidth_rot(x, y)

        # Step 1: Estimate second derivative at cutoff
        # Use pilot bandwidth
        h_pilot = 1.84 * np.std(x) * n ** (-1 / 5)

        # Fit cubic on each side
        left_mask = (x >= -h_pilot) & (x < 0)
        right_mask = (x >= 0) & (x <= h_pilot)

        if left_mask.sum() < 5 or right_mask.sum() < 5:
            return h_rot

        # Estimate second derivatives
        try:
            # Left side
            x_left = x[left_mask]
            y_left = y[left_mask]
            coeffs_left = np.polyfit(x_left, y_left, 3)
            m2_left = 2 * coeffs_left[1]  # Second derivative at 0

            # Right side
            x_right = x[right_mask]
            y_right = y[right_mask]
            coeffs_right = np.polyfit(x_right, y_right, 3)
            m2_right = 2 * coeffs_right[1]

            # Curvature at cutoff
            curvature = (m2_right - m2_left) / 2

            if np.abs(curvature) < 1e-10:
                return h_rot

        except (np.linalg.LinAlgError, ValueError):
            return h_rot

        # Step 2: Estimate variance
        # Use residuals from linear fit
        mask = np.abs(x) <= h_rot
        if mask.sum() < 10:
            return h_rot

        x_bw = x[mask]
        y_bw = y[mask]

        # Separate left/right variance
        left_bw = x_bw < 0
        right_bw = x_bw >= 0

        if left_bw.sum() < 3 or right_bw.sum() < 3:
            sigma2 = np.var(y_bw)
        else:
            # Fit linear on each side
            try:
                resid_left = y_bw[left_bw] - np.polyval(
                    np.polyfit(x_bw[left_bw], y_bw[left_bw], 1), x_bw[left_bw]
                )
                resid_right = y_bw[right_bw] - np.polyval(
                    np.polyfit(x_bw[right_bw], y_bw[right_bw], 1), x_bw[right_bw]
                )
                sigma2 = (np.var(resid_left) + np.var(resid_right)) / 2
            except (np.linalg.LinAlgError, ValueError):
                sigma2 = np.var(y_bw)

        # Step 3: Compute optimal bandwidth
        # h_opt = C_k * (sigma^2 / (curvature^2 * n))^(1/5)
        # C_k depends on kernel (for triangular: C_k ≈ 3.4)
        C_k = 3.4  # Triangular kernel constant

        if np.abs(curvature) > 1e-10:
            h_opt = C_k * (sigma2 / (curvature**2 * n)) ** (1 / 5)
        else:
            h_opt = h_rot

        # Bound the bandwidth
        x_range = np.max(x) - np.min(x)
        h_opt = np.clip(h_opt, x_range * 0.05, x_range * 0.5)

        return h_opt

    def _select_bandwidth_cct(self, x: np.ndarray, y: np.ndarray) -> float:
        """
        Calonico-Cattaneo-Titiunik robust bandwidth selection.

        Implements the MSE-optimal bandwidth from CCT (2014).
        """
        n = len(x)

        # Start with IK bandwidth
        h_ik = self._select_bandwidth_ik(x, y)

        # CCT adjustment: use regularization
        # Estimate variance and bias terms

        # Pilot bandwidth for bias estimation
        h_pilot = h_ik * n ** (-2 / 25)

        left_mask = (x >= -h_pilot) & (x < 0)
        right_mask = (x >= 0) & (x <= h_pilot)

        if left_mask.sum() < 5 or right_mask.sum() < 5:
            return h_ik

        try:
            # Estimate bias term using quadratic fit
            x_left = x[left_mask]
            y_left = y[left_mask]
            x_right = x[right_mask]
            y_right = y[right_mask]

            # Quadratic coefficients
            coeffs_left = np.polyfit(x_left, y_left, 2)
            coeffs_right = np.polyfit(x_right, y_right, 2)

            # Second derivatives at cutoff
            b_left = 2 * coeffs_left[0]
            b_right = 2 * coeffs_right[0]

            # Regularization term
            reg = (b_right + b_left) / 2

            # Adjust bandwidth
            if np.abs(reg) > 1e-10:
                h_cct = h_ik * (1 + 0.5 / np.abs(reg)) ** (1 / 5)
            else:
                h_cct = h_ik

            # Bound
            x_range = np.max(x) - np.min(x)
            h_cct = np.clip(h_cct, x_range * 0.05, x_range * 0.5)

            return h_cct

        except (np.linalg.LinAlgError, ValueError):
            return h_ik

    def _select_bandwidth_rot(self, x: np.ndarray, y: np.ndarray) -> float:
        """Rule of thumb bandwidth: Silverman's rule adapted for RDD."""
        n = len(x)
        sigma_x = np.std(x)

        # Silverman's rule of thumb
        h_rot = 1.06 * sigma_x * n ** (-1 / 5)

        # Bound by data range
        x_range = np.max(x) - np.min(x)
        h_rot = np.clip(h_rot, x_range * 0.05, x_range * 0.5)

        return h_rot

    def _select_bandwidth_cv(self, x: np.ndarray, y: np.ndarray, n_folds: int = 5) -> float:
        """Cross-validation bandwidth selection."""
        # Grid of candidate bandwidths
        h_rot = self._select_bandwidth_rot(x, y)
        h_candidates = np.linspace(h_rot * 0.5, h_rot * 2.0, 20)

        best_h = h_rot
        best_cv = np.inf

        n = len(x)
        fold_size = n // n_folds

        for h in h_candidates:
            cv_error = 0.0

            for fold in range(n_folds):
                # Leave-out indices
                start_idx = fold * fold_size
                end_idx = start_idx + fold_size if fold < n_folds - 1 else n

                test_mask = np.zeros(n, dtype=bool)
                test_mask[start_idx:end_idx] = True
                train_mask = ~test_mask

                # Fit on training data
                x_train = x[train_mask]
                y_train = y[train_mask]
                x_test = x[test_mask]
                y_test = y[test_mask]

                # Only use test points near cutoff
                test_near = np.abs(x_test) <= h
                if test_near.sum() == 0:
                    continue

                # Predict
                y_pred = np.zeros(test_near.sum())
                for i, xi in enumerate(x_test[test_near]):
                    weights = self._get_kernel_weights(x_train - xi, h)
                    if weights.sum() < 1e-10:
                        y_pred[i] = np.mean(y_train)
                    else:
                        y_pred[i] = np.average(y_train, weights=weights)

                cv_error += np.mean((y_test[test_near] - y_pred) ** 2)

            if cv_error < best_cv:
                best_cv = cv_error
                best_h = h

        return best_h

    def select_bandwidth(
        self, data: pd.DataFrame, method: Optional[Union[str, BandwidthMethod]] = None
    ) -> BandwidthResult:
        """
        Select optimal bandwidth for RDD.

        Parameters
        ----------
        data : pd.DataFrame
            Input data
        method : Optional[Union[str, BandwidthMethod]]
            Override bandwidth selection method

        Returns
        -------
        BandwidthResult
            Selected bandwidth and metadata
        """
        if method is None:
            method = self.bandwidth_method
        elif isinstance(method, str):
            method = BandwidthMethod(method.lower())

        # Center running variable at cutoff
        x = data[self.running_var].values - self.cutoff
        y = data[self.outcome_col].values

        if method == BandwidthMethod.MANUAL:
            if self.manual_bandwidth is None:
                raise ValueError("Manual bandwidth not specified")
            bandwidth = self.manual_bandwidth
        elif method == BandwidthMethod.IK:
            bandwidth = self._select_bandwidth_ik(x, y)
        elif method == BandwidthMethod.CCT:
            bandwidth = self._select_bandwidth_cct(x, y)
        elif method == BandwidthMethod.ROT:
            bandwidth = self._select_bandwidth_rot(x, y)
        elif method == BandwidthMethod.CV:
            bandwidth = self._select_bandwidth_cv(x, y)
        else:
            raise ValueError(f"Unknown bandwidth method: {method}")

        return BandwidthResult(bandwidth=bandwidth, method=method.value)

    def _local_polynomial_fit(
        self,
        x: np.ndarray,
        y: np.ndarray,
        bandwidth: float,
        weights: Optional[np.ndarray] = None,
        order: int = 1,
    ) -> Tuple[np.ndarray, np.ndarray]:
        """
        Fit local polynomial regression.

        Returns coefficients and standard errors.
        """
        # Kernel weights
        k_weights = self._get_kernel_weights(x, bandwidth)

        if weights is not None:
            k_weights = k_weights * weights

        # Only use observations with positive weight
        mask = k_weights > 0
        if mask.sum() < order + 2:
            raise EstimationError(f"Insufficient observations for polynomial order {order}")

        x_w = x[mask]
        y_w = y[mask]
        w = k_weights[mask]

        # Build design matrix
        X = np.column_stack([x_w**p for p in range(order + 1)])

        # Weighted least squares
        W = np.diag(w)
        XtWX = X.T @ W @ X
        XtWy = X.T @ W @ y_w

        try:
            coeffs = np.linalg.solve(XtWX, XtWy)
        except np.linalg.LinAlgError:
            # Use pseudoinverse
            coeffs = np.linalg.lstsq(XtWX, XtWy, rcond=None)[0]

        # Standard errors (heteroskedasticity-robust)
        residuals = y_w - X @ coeffs

        # Meat of sandwich: sum of w_i^2 * x_i * x_i' * e_i^2
        meat = np.zeros((order + 1, order + 1))
        for i in range(len(x_w)):
            xi = X[i : i + 1, :]  # Row vector
            meat += (w[i] ** 2) * (residuals[i] ** 2) * (xi.T @ xi)

        # Bread: inv(X'WX)
        try:
            bread = np.linalg.inv(XtWX)
        except np.linalg.LinAlgError:
            bread = np.linalg.pinv(XtWX)

        # Sandwich variance
        var_coeffs = bread @ meat @ bread
        se_coeffs = np.sqrt(np.diag(var_coeffs))

        return coeffs, se_coeffs

    def _estimate_sharp_rdd(self, data: pd.DataFrame, bandwidth: float) -> RDDResult:
        """Estimate sharp RDD."""
        # Center running variable
        x = data[self.running_var].values - self.cutoff
        y = data[self.outcome_col].values

        # Split left and right
        left_mask = (x >= -bandwidth) & (x < 0)
        right_mask = (x >= 0) & (x <= bandwidth)

        n_left = left_mask.sum()
        n_right = right_mask.sum()

        if n_left < self.polynomial_order + 2:
            raise EstimationError(f"Insufficient observations left of cutoff: {n_left}")
        if n_right < self.polynomial_order + 2:
            raise EstimationError(f"Insufficient observations right of cutoff: {n_right}")

        # Fit local polynomial on each side
        x_left = x[left_mask]
        y_left = y[left_mask]
        x_right = x[right_mask]
        y_right = y[right_mask]

        coeffs_left, se_left = self._local_polynomial_fit(
            x_left, y_left, bandwidth, order=self.polynomial_order
        )
        coeffs_right, se_right = self._local_polynomial_fit(
            x_right, y_right, bandwidth, order=self.polynomial_order
        )

        # Treatment effect: intercept difference
        tau = coeffs_right[0] - coeffs_left[0]
        se_tau = np.sqrt(se_left[0] ** 2 + se_right[0] ** 2)

        # Confidence interval and p-value
        z = stats.norm.ppf(1 - (1 - self.confidence_level) / 2)
        ci = (tau - z * se_tau, tau + z * se_tau)

        t_stat = tau / se_tau if se_tau > 0 else 0.0
        p_value = 2 * (1 - stats.norm.cdf(np.abs(t_stat)))

        ate = CausalEstimate(
            estimate=tau,
            std_error=se_tau,
            ci_lower=ci[0],
            ci_upper=ci[1],
            p_value=p_value,
            effect_type=EffectType.LATE,
        )

        return RDDResult(
            ate=ate,
            bandwidth=bandwidth,
            bandwidth_method=self.bandwidth_method.value,
            n_left=n_left,
            n_right=n_right,
            polynomial_order=self.polynomial_order,
            kernel=self.kernel.value,
            rdd_type="sharp",
            diagnostics=DiagnosticResult(
                assumption_tests={"continuity": {"tested": True}}, warnings=[]
            ),
        )

    def _estimate_fuzzy_rdd(self, data: pd.DataFrame, bandwidth: float) -> RDDResult:
        """Estimate fuzzy RDD using local 2SLS."""
        # Center running variable
        x = data[self.running_var].values - self.cutoff
        y = data[self.outcome_col].values
        d = data[self.treatment_col].values  # Treatment indicator

        # Create instrument: above cutoff indicator
        z = (x >= 0).astype(float)

        # Within bandwidth
        bw_mask = np.abs(x) <= bandwidth

        n_left = (bw_mask & (x < 0)).sum()
        n_right = (bw_mask & (x >= 0)).sum()

        if n_left < self.polynomial_order + 2 or n_right < self.polynomial_order + 2:
            raise EstimationError("Insufficient observations for fuzzy RDD")

        # Kernel weights
        weights = self._get_kernel_weights(x, bandwidth)

        # First stage: regress D on Z (and polynomial in X)
        # D = gamma_0 + gamma_1 * Z + f(X) + epsilon
        x_bw = x[bw_mask]
        d_bw = d[bw_mask]
        y_bw = y[bw_mask]
        z_bw = z[bw_mask]
        w_bw = weights[bw_mask]

        # Build design matrix with polynomial terms
        X_first = np.column_stack(
            [
                np.ones(len(x_bw)),
                z_bw,
                *[x_bw**p for p in range(1, self.polynomial_order + 1)],
                *[z_bw * x_bw**p for p in range(1, self.polynomial_order + 1)],
            ]
        )

        W = np.diag(w_bw)

        # First stage
        try:
            XtWX_first = X_first.T @ W @ X_first
            XtWd = X_first.T @ W @ d_bw
            gamma = np.linalg.solve(XtWX_first, XtWd)
        except np.linalg.LinAlgError:
            gamma = np.linalg.lstsq(X_first.T @ W @ X_first, X_first.T @ W @ d_bw, rcond=None)[0]

        # First stage coefficient on Z (jump in treatment probability)
        first_stage_jump = gamma[1]

        # Predicted treatment
        d_hat = X_first @ gamma

        # Second stage: regress Y on D_hat
        X_second = np.column_stack(
            [np.ones(len(x_bw)), d_hat, *[x_bw**p for p in range(1, self.polynomial_order + 1)]]
        )

        try:
            XtWX_second = X_second.T @ W @ X_second
            XtWy = X_second.T @ W @ y_bw
            beta = np.linalg.solve(XtWX_second, XtWy)
        except np.linalg.LinAlgError:
            beta = np.linalg.lstsq(X_second.T @ W @ X_second, X_second.T @ W @ y_bw, rcond=None)[0]

        # Treatment effect (coefficient on D_hat)
        tau = beta[1]

        # Standard error (2SLS variance)
        residuals = y_bw - X_second @ beta
        sigma2 = np.sum(w_bw * residuals**2) / (len(x_bw) - len(beta))

        try:
            var_beta = sigma2 * np.linalg.inv(XtWX_second)
        except np.linalg.LinAlgError:
            var_beta = sigma2 * np.linalg.pinv(XtWX_second)

        se_tau = np.sqrt(var_beta[1, 1])

        # Confidence interval and p-value
        z_crit = stats.norm.ppf(1 - (1 - self.confidence_level) / 2)
        ci = (tau - z_crit * se_tau, tau + z_crit * se_tau)

        t_stat = tau / se_tau if se_tau > 0 else 0.0
        p_value = 2 * (1 - stats.norm.cdf(np.abs(t_stat)))

        ate = CausalEstimate(
            estimate=tau,
            std_error=se_tau,
            ci_lower=ci[0],
            ci_upper=ci[1],
            p_value=p_value,
            effect_type=EffectType.LATE,
        )

        # First stage diagnostics
        first_stage_resid = d_bw - d_hat
        first_stage_sigma2 = np.sum(w_bw * first_stage_resid**2) / len(x_bw)
        first_stage_se = np.sqrt(first_stage_sigma2 / (np.sum(w_bw * z_bw**2)))
        first_stage_f = (first_stage_jump / first_stage_se) ** 2 if first_stage_se > 0 else 0

        first_stage_result = {
            "coefficient": first_stage_jump,
            "std_error": first_stage_se,
            "f_statistic": first_stage_f,
            "weak_instrument": first_stage_f < 10,
        }

        return RDDResult(
            ate=ate,
            bandwidth=bandwidth,
            bandwidth_method=self.bandwidth_method.value,
            n_left=n_left,
            n_right=n_right,
            polynomial_order=self.polynomial_order,
            kernel=self.kernel.value,
            rdd_type="fuzzy",
            first_stage=first_stage_result,
            diagnostics=DiagnosticResult(
                assumption_tests={
                    "continuity": {"tested": True},
                    "first_stage_relevance": {"tested": True, "f_statistic": first_stage_f},
                },
                warnings=["Weak instrument detected"] if first_stage_f < 10 else [],
            ),
        )

    def fit(self, data: pd.DataFrame, **kwargs) -> RDDResult:
        """
        Fit the RDD estimator.

        Parameters
        ----------
        data : pd.DataFrame
            Input data with running variable, outcome, and treatment

        Returns
        -------
        RDDResult
            Estimation results with LATE at cutoff
        """
        self._validate_data(data)
        self._data = data.copy()

        # Select bandwidth
        if self.manual_bandwidth is not None:
            bandwidth = self.manual_bandwidth
        else:
            bw_result = self.select_bandwidth(data)
            bandwidth = bw_result.bandwidth

        self._bandwidth = bandwidth

        logger.info(f"Using bandwidth: {bandwidth:.4f}")
        logger.info(f"RDD type: {self.rdd_type.value}")

        # Estimate based on RDD type
        if self.rdd_type == RDDType.SHARP:
            result = self._estimate_sharp_rdd(data, bandwidth)
        else:
            result = self._estimate_fuzzy_rdd(data, bandwidth)

        self._result = result
        self._fitted = True

        return result

    def manipulation_test(
        self, data: Optional[pd.DataFrame] = None, bandwidth: Optional[float] = None
    ) -> ManipulationTestResult:
        """
        McCrary density test for manipulation at cutoff.

        Tests whether there is bunching in the running variable at the cutoff,
        which would indicate manipulation of the assignment variable.

        Parameters
        ----------
        data : Optional[pd.DataFrame]
            Data to test (uses fitted data if None)
        bandwidth : Optional[float]
            Bandwidth for density estimation

        Returns
        -------
        ManipulationTestResult
            Test results
        """
        if data is None:
            if self._data is None:
                raise ValueError("No data available. Fit the model first.")
            data = self._data

        x = data[self.running_var].values - self.cutoff

        if bandwidth is None:
            bandwidth = self._bandwidth or self._select_bandwidth_rot(x, np.zeros_like(x))

        # Count observations in bins around cutoff
        bin_width = bandwidth / 5

        # Left of cutoff
        left_mask = (x >= -bandwidth) & (x < 0)
        right_mask = (x >= 0) & (x <= bandwidth)

        n_left = left_mask.sum()
        n_right = right_mask.sum()

        # Under null of no manipulation, counts should be similar
        # Use a chi-squared-like test
        n_total = n_left + n_right
        expected = n_total / 2

        if expected > 0:
            chi2_stat = ((n_left - expected) ** 2 + (n_right - expected) ** 2) / expected
            p_value = 1 - stats.chi2.cdf(chi2_stat, 1)
        else:
            chi2_stat = 0.0
            p_value = 1.0

        return ManipulationTestResult(
            statistic=chi2_stat,
            p_value=p_value,
            n_left=n_left,
            n_right=n_right,
            passed=p_value > 0.05,
        )

    def placebo_test(
        self,
        data: Optional[pd.DataFrame] = None,
        placebo_cutoffs: Optional[List[float]] = None,
        n_placebos: int = 5,
    ) -> PlaceboTestResult:
        """
        Placebo test at alternative cutoffs.

        Estimates RDD at cutoffs where there should be no discontinuity.

        Parameters
        ----------
        data : Optional[pd.DataFrame]
            Data to test
        placebo_cutoffs : Optional[List[float]]
            Specific cutoffs to test
        n_placebos : int
            Number of placebo cutoffs if not specified

        Returns
        -------
        PlaceboTestResult
            Results at placebo cutoffs
        """
        if data is None:
            if self._data is None:
                raise ValueError("No data available. Fit the model first.")
            data = self._data

        x = data[self.running_var].values

        # Generate placebo cutoffs
        if placebo_cutoffs is None:
            # Use percentiles, excluding area near true cutoff
            percentiles = np.linspace(20, 80, n_placebos + 2)[1:-1]
            placebo_cutoffs = np.percentile(x, percentiles)

            # Remove any too close to actual cutoff
            min_distance = (np.max(x) - np.min(x)) * 0.1
            placebo_cutoffs = [c for c in placebo_cutoffs if np.abs(c - self.cutoff) > min_distance]

        estimates = []
        significant_count = 0

        for pc in placebo_cutoffs:
            # Create new RDD estimator at placebo cutoff
            placebo_rdd = RegressionDiscontinuity(
                running_var=self.running_var,
                outcome_col=self.outcome_col,
                cutoff=pc,
                treatment_col=self.treatment_col,
                rdd_type=self.rdd_type,
                bandwidth_method=self.bandwidth_method,
                kernel=self.kernel,
                polynomial_order=self.polynomial_order,
                confidence_level=self.confidence_level,
            )

            try:
                result = placebo_rdd.fit(data)
                estimates.append(result.ate)

                if result.ate.p_value < (1 - self.confidence_level):
                    significant_count += 1
            except (EstimationError, DataValidationError):
                # Skip if can't estimate at this cutoff
                continue

        return PlaceboTestResult(
            placebo_cutoffs=placebo_cutoffs,
            estimates=estimates,
            significant_count=significant_count,
        )

    def covariate_balance_test(
        self, data: Optional[pd.DataFrame] = None, covariates: Optional[List[str]] = None
    ) -> Dict[str, Dict[str, float]]:
        """
        Test covariate balance at cutoff.

        For each covariate, estimates a "placebo RDD" using that covariate
        as the outcome. Significant discontinuities suggest imbalance.

        Parameters
        ----------
        data : Optional[pd.DataFrame]
            Data to test
        covariates : Optional[List[str]]
            Covariates to test

        Returns
        -------
        Dict[str, Dict[str, float]]
            Balance test results for each covariate
        """
        if data is None:
            if self._data is None:
                raise ValueError("No data available. Fit the model first.")
            data = self._data

        if covariates is None:
            covariates = self.covariates or []

        if not covariates:
            logger.warning("No covariates specified for balance test")
            return {}

        results = {}
        bandwidth = self._bandwidth or self.select_bandwidth(data).bandwidth

        for cov in covariates:
            if cov not in data.columns:
                continue

            # Run RDD with covariate as outcome
            cov_rdd = RegressionDiscontinuity(
                running_var=self.running_var,
                outcome_col=cov,
                cutoff=self.cutoff,
                rdd_type=RDDType.SHARP,
                bandwidth=bandwidth,
                bandwidth_method=BandwidthMethod.MANUAL,
                kernel=self.kernel,
                polynomial_order=self.polynomial_order,
            )

            try:
                result = cov_rdd.fit(data)
                results[cov] = {
                    "discontinuity": result.ate.estimate,
                    "std_error": result.ate.std_error,
                    "p_value": result.ate.p_value,
                    "balanced": result.ate.p_value > 0.05,
                }
            except (EstimationError, DataValidationError):
                results[cov] = {
                    "discontinuity": np.nan,
                    "std_error": np.nan,
                    "p_value": np.nan,
                    "balanced": None,
                }

        return results

    def sensitivity_to_bandwidth(
        self,
        data: Optional[pd.DataFrame] = None,
        bandwidth_range: Optional[Tuple[float, float]] = None,
        n_bandwidths: int = 10,
    ) -> Dict[float, CausalEstimate]:
        """
        Sensitivity analysis varying bandwidth.

        Parameters
        ----------
        data : Optional[pd.DataFrame]
            Data to analyze
        bandwidth_range : Optional[Tuple[float, float]]
            Range of bandwidths to test
        n_bandwidths : int
            Number of bandwidths to test

        Returns
        -------
        Dict[float, CausalEstimate]
            Estimates at each bandwidth
        """
        if data is None:
            if self._data is None:
                raise ValueError("No data available. Fit the model first.")
            data = self._data

        base_bw = self._bandwidth or self.select_bandwidth(data).bandwidth

        if bandwidth_range is None:
            bandwidth_range = (base_bw * 0.5, base_bw * 2.0)

        bandwidths = np.linspace(bandwidth_range[0], bandwidth_range[1], n_bandwidths)

        results = {}

        for bw in bandwidths:
            sens_rdd = RegressionDiscontinuity(
                running_var=self.running_var,
                outcome_col=self.outcome_col,
                cutoff=self.cutoff,
                treatment_col=self.treatment_col,
                rdd_type=self.rdd_type,
                bandwidth=bw,
                bandwidth_method=BandwidthMethod.MANUAL,
                kernel=self.kernel,
                polynomial_order=self.polynomial_order,
                confidence_level=self.confidence_level,
            )

            try:
                result = sens_rdd.fit(data)
                results[bw] = result.ate
            except (EstimationError, DataValidationError):
                continue

        return results

    def estimate_ate(self) -> CausalEstimate:
        """Return the estimated LATE at cutoff."""
        if not self._fitted or self._result is None:
            raise EstimationError("Model not fitted. Call fit() first.")
        return self._result.ate

    def get_result(self) -> TreatmentEffectResult:
        """Get result in standard TreatmentEffectResult format."""
        if not self._fitted or self._result is None:
            raise EstimationError("Model not fitted. Call fit() first.")

        return TreatmentEffectResult(
            ate=self._result.ate,
            method=EstimationMethod.REGRESSION_ADJUSTMENT,
            n_treated=self._result.n_right,
            n_control=self._result.n_left,
            diagnostics=self._result.diagnostics,
        )

    def predict(self, data: pd.DataFrame) -> np.ndarray:
        """
        Predict outcomes based on fitted model.

        For RDD, predicts based on which side of cutoff observation falls.
        """
        if not self._fitted or self._result is None:
            raise EstimationError("Model not fitted. Call fit() first.")

        x = data[self.running_var].values - self.cutoff

        # Predict counterfactual outcome without treatment
        # Treatment effect applies only above cutoff
        baseline = np.zeros(len(x))
        effect = np.where(x >= 0, self._result.ate.estimate, 0.0)

        return baseline + effect

    def summary(self) -> str:
        """Generate text summary of RDD results."""
        if not self._fitted or self._result is None:
            return "Model not fitted."

        result = self._result
        lines = [
            "=" * 60,
            "Regression Discontinuity Design Results",
            "=" * 60,
            f"RDD Type: {result.rdd_type.upper()}",
            f"Cutoff: {self.cutoff}",
            f"Bandwidth: {result.bandwidth:.4f} ({result.bandwidth_method})",
            f"Kernel: {result.kernel}",
            f"Polynomial Order: {result.polynomial_order}",
            "",
            "Sample Size:",
            f"  Left of cutoff: {result.n_left}",
            f"  Right of cutoff: {result.n_right}",
            "",
            "Treatment Effect (LATE):",
            f"  Estimate: {result.ate.estimate:.4f}",
            f"  Std. Error: {result.ate.std_error:.4f}",
            f"  {self.confidence_level*100:.0f}% CI: [{result.ate.confidence_interval[0]:.4f}, {result.ate.confidence_interval[1]:.4f}]",
            f"  P-value: {result.ate.p_value:.4f}",
        ]

        if result.first_stage:
            lines.extend(
                [
                    "",
                    "First Stage (Fuzzy RDD):",
                    f"  Jump in treatment prob: {result.first_stage['coefficient']:.4f}",
                    f"  F-statistic: {result.first_stage['f_statistic']:.2f}",
                    f"  Weak instrument: {'Yes' if result.first_stage['weak_instrument'] else 'No'}",
                ]
            )

        lines.append("=" * 60)

        return "\n".join(lines)
