# ----------------------------------------------------------------------
# © 2025 KR-Labs. All rights reserved.
# KR-Labs™ is a trademark of Quipu Research Labs, LLC,
# a subsidiary of Sudiata Giddasira, Inc.
# ----------------------------------------------------------------------
# SPDX-License-Identifier: Apache-2.0

"""
Treatment Effect Estimators for causal inference.

This module provides fundamental treatment effect estimation methods:
- Difference-in-Means (simple comparison)
- Regression Adjustment (OLS with covariates)
- Inverse Probability Weighting (IPW)
- Doubly Robust Estimation (AIPW)
"""

from typing import Any, Dict, List, Optional, Tuple, Union

import numpy as np
import pandas as pd
from scipy import stats

from krl_policy.core.base import (
    BasePolicyEstimator,
    CausalEstimate,
    PolicyValidationResult,
    TreatmentEffectResult,
)
from krl_policy.core.utils import (
    balance_check,
    bootstrap_ci,
    bootstrap_std_error,
    compute_ci,
    compute_p_value,
)

# Import logger
try:
    from krl_core import get_logger
except ImportError:
    import logging

    def get_logger(name: str):
        return logging.getLogger(name)


logger = get_logger(__name__)


class TreatmentEffectEstimator(BasePolicyEstimator):
    """
    Primary estimator for average treatment effects (ATE).

    Supports multiple estimation methods:
    - difference_in_means: Simple comparison of treated vs control means
    - regression_adjustment: OLS regression with covariate adjustment
    - ipw: Inverse probability weighting
    - doubly_robust: Augmented IPW (AIPW)

    Parameters
    ----------
    method : str, default="difference_in_means"
        Estimation method to use
    confidence_level : float, default=0.95
        Confidence level for intervals
    n_bootstrap : int, default=1000
        Number of bootstrap iterations for inference
    propensity_model : object, optional
        Model for propensity score estimation (required for IPW/DR)
    outcome_model : object, optional
        Model for outcome regression (required for regression/DR)
    random_state : int, optional
        Random seed for reproducibility

    Attributes
    ----------
    effect_ : float
        Estimated average treatment effect
    std_error_ : float
        Standard error of the estimate
    p_value_ : float
        P-value for null hypothesis of no effect
    ci_ : Tuple[float, float]
        Confidence interval

    Examples
    --------
    >>> from krl_policy.estimators import TreatmentEffectEstimator
    >>> from krl_policy.datasets import make_rct_data
    >>>
    >>> # Generate data
    >>> data, true_ate = make_rct_data(n_samples=1000, true_ate=2.0)
    >>>
    >>> # Simple estimation
    >>> estimator = TreatmentEffectEstimator(method="difference_in_means")
    >>> estimator.fit(data, treatment_col='T', outcome_col='Y')
    >>> print(f"ATE: {estimator.effect_:.3f} ({estimator.ci_[0]:.3f}, {estimator.ci_[1]:.3f})")
    """

    SUPPORTED_METHODS = ["difference_in_means", "regression_adjustment", "ipw", "doubly_robust"]

    def __init__(
        self,
        method: str = "difference_in_means",
        treatment_col: str = "T",
        outcome_col: str = "Y",
        covariates: Optional[List[str]] = None,
        confidence_level: float = 0.95,
        n_bootstrap: int = 1000,
        propensity_model: Optional[Any] = None,
        outcome_model: Optional[Any] = None,
        random_state: Optional[int] = None,
        n_jobs: int = 1,
        adaptive_bootstrap: bool = True,
        **kwargs,
    ):
        """
        Initialize TreatmentEffectEstimator.

        Parameters
        ----------
        n_jobs : int, default=1
            Number of parallel jobs for bootstrap. -1 uses all CPU cores.
        adaptive_bootstrap : bool, default=True
            If True, automatically reduces bootstrap iterations for small samples.
        """
        # Filter kwargs to only include PolicyConfig-compatible params
        super().__init__(
            confidence_level=confidence_level,
            random_state=random_state,
            n_bootstrap=n_bootstrap,
        )

        if method not in self.SUPPORTED_METHODS:
            raise ValueError(f"Unknown method '{method}'. " f"Supported: {self.SUPPORTED_METHODS}")

        self.method = method
        self.treatment_col = treatment_col
        self.outcome_col = outcome_col
        self.covariates = covariates
        self.n_bootstrap = n_bootstrap
        self.propensity_model = propensity_model
        self.outcome_model = outcome_model
        self.random_state = random_state
        self.confidence_level = confidence_level
        self.n_jobs = n_jobs
        self.adaptive_bootstrap = adaptive_bootstrap

        # Results
        self.effect_: Optional[float] = None
        self.std_error_: Optional[float] = None
        self.p_value_: Optional[float] = None
        self.ci_: Optional[Tuple[float, float]] = None

        # Internal state
        self._propensity_scores: Optional[np.ndarray] = None
        self._outcome_predictions: Optional[Dict[str, np.ndarray]] = None
        self._balance_stats: Optional[Dict] = None

    def _validate_input_data(
        self, data: pd.DataFrame, treatment_col: str, outcome_col: str
    ) -> None:
        """Validate input data for treatment effect estimation."""
        # Check required columns exist
        if treatment_col not in data.columns:
            raise ValueError(f"Treatment column '{treatment_col}' not found in data")
        if outcome_col not in data.columns:
            raise ValueError(f"Outcome column '{outcome_col}' not found in data")

        # Check treatment is binary
        treatment = data[treatment_col]
        unique_values = set(treatment.unique())
        if not unique_values.issubset({0, 1, 0.0, 1.0, True, False}):
            raise ValueError(f"Treatment column must be binary (0/1), got: {unique_values}")

        # Check for variation
        if treatment.nunique() < 2:
            raise ValueError("Treatment must have both treated and control units")

    def _get_adaptive_bootstrap_size(self, n: int) -> int:
        """
        Determine optimal bootstrap size based on sample size.

        For small samples (n < 100), use fewer bootstrap iterations
        to speed up computation while maintaining reasonable accuracy.
        """
        if not self.adaptive_bootstrap:
            return self.n_bootstrap

        if n < 30:
            return min(200, self.n_bootstrap)
        elif n < 50:
            return min(500, self.n_bootstrap)
        elif n < 100:
            return min(1000, self.n_bootstrap)
        else:
            return self.n_bootstrap

    def fit(
        self,
        data: pd.DataFrame,
        treatment_col: Optional[str] = None,
        outcome_col: Optional[str] = None,
        covariate_cols: Optional[List[str]] = None,
        **kwargs,
    ) -> "TreatmentEffectEstimator":
        """
        Fit the treatment effect estimator.

        Parameters
        ----------
        data : pd.DataFrame
            Input data
        treatment_col : str, optional
            Name of treatment indicator column. Uses self.treatment_col if not provided.
        outcome_col : str, optional
            Name of outcome column. Uses self.outcome_col if not provided.
        covariate_cols : List[str], optional
            Names of covariate columns. If None, auto-detect.
        **kwargs
            Additional arguments

        Returns
        -------
        self
            Fitted estimator
        """
        # Use stored column names if not provided
        if treatment_col is None:
            treatment_col = self.treatment_col
        if outcome_col is None:
            outcome_col = self.outcome_col

        self._validate_input_data(data, treatment_col, outcome_col)

        # Store column names
        self._treatment_col = treatment_col
        self._outcome_col = outcome_col

        # Auto-detect covariates if not provided
        if covariate_cols is None:
            covariate_cols = [
                col
                for col in data.columns
                if col not in [treatment_col, outcome_col]
                and not col.endswith("_true")  # Exclude true values from synthetic data
            ]

        self._covariate_cols = covariate_cols

        # Extract data
        T = data[treatment_col].values
        Y = data[outcome_col].values
        X = data[covariate_cols].values if covariate_cols else None

        # Adaptive bootstrap sizing
        n = len(data)
        effective_bootstrap = self._get_adaptive_bootstrap_size(n)
        if effective_bootstrap < self.n_bootstrap:
            logger.info(
                f"Using adaptive bootstrap: {effective_bootstrap} iterations "
                f"(reduced from {self.n_bootstrap} due to small sample size n={n})"
            )
            self._effective_n_bootstrap = effective_bootstrap
        else:
            self._effective_n_bootstrap = self.n_bootstrap

        # Fit based on method
        if self.method == "difference_in_means":
            self._fit_dim(T, Y)
        elif self.method == "regression_adjustment":
            self._fit_regression(T, Y, X)
        elif self.method == "ipw":
            self._fit_ipw(data, T, Y, X)
        elif self.method == "doubly_robust":
            self._fit_doubly_robust(data, T, Y, X)

        # Compute balance statistics
        if covariate_cols:
            self._balance_stats = balance_check(data, treatment_col, covariate_cols)

        self.is_fitted = True
        logger.info(
            f"Fitted {self.method}: ATE={self.effect_:.4f} "
            f"(SE={self.std_error_:.4f}, p={self.p_value_:.4f})"
        )

        return self

    def _fit_dim(self, T: np.ndarray, Y: np.ndarray) -> None:
        """Difference-in-means estimator."""
        # Simple mean comparison
        Y1 = Y[T == 1]
        Y0 = Y[T == 0]

        n1 = len(Y1)
        n0 = len(Y0)

        mean1 = Y1.mean()
        mean0 = Y0.mean()

        self.effect_ = mean1 - mean0

        # Standard error (assuming unequal variances)
        var1 = Y1.var(ddof=1)
        var0 = Y0.var(ddof=1)
        self.std_error_ = np.sqrt(var1 / n1 + var0 / n0)

        # Inference
        self.p_value_ = compute_p_value(self.effect_, self.std_error_)
        self.ci_ = compute_ci(self.effect_, self.std_error_, self.confidence_level)

    def _fit_regression(self, T: np.ndarray, Y: np.ndarray, X: Optional[np.ndarray]) -> None:
        """Regression adjustment estimator (OLS)."""
        if X is None:
            # Fall back to difference-in-means
            self._fit_dim(T, Y)
            return

        # Design matrix: [1, X, T]
        n = len(Y)
        X_design = np.column_stack([np.ones(n), X, T])

        # OLS estimation
        try:
            beta, residuals, rank, s = np.linalg.lstsq(X_design, Y, rcond=None)
        except np.linalg.LinAlgError:
            logger.warning("OLS failed, falling back to difference-in-means")
            self._fit_dim(T, Y)
            return

        # Treatment effect is last coefficient
        self.effect_ = beta[-1]

        # Standard error from OLS
        Y_pred = X_design @ beta
        resid = Y - Y_pred
        mse = np.sum(resid**2) / (n - X_design.shape[1])

        try:
            XtX_inv = np.linalg.inv(X_design.T @ X_design)
            var_beta = mse * np.diag(XtX_inv)
            self.std_error_ = np.sqrt(var_beta[-1])
        except np.linalg.LinAlgError:
            # Use bootstrap if matrix is singular
            self.std_error_ = self._bootstrap_se(T, Y, X)

        # Inference
        self.p_value_ = compute_p_value(self.effect_, self.std_error_)
        self.ci_ = compute_ci(self.effect_, self.std_error_, self.confidence_level)

        # Store predictions
        self._outcome_predictions = {"predicted": Y_pred, "residuals": resid}

    def _fit_ipw(
        self, data: pd.DataFrame, T: np.ndarray, Y: np.ndarray, X: Optional[np.ndarray]
    ) -> None:
        """Inverse probability weighting estimator."""
        # Estimate propensity scores
        e = self._estimate_propensity(data, T, X)
        self._propensity_scores = e

        # Clip propensity scores to avoid extreme weights
        e = np.clip(e, 0.01, 0.99)

        # IPW estimator
        # ATE = E[Y*T/e(X)] - E[Y*(1-T)/(1-e(X))]
        w1 = T / e
        w0 = (1 - T) / (1 - e)

        # Normalize weights (Hajek estimator)
        w1 = w1 / w1.sum()
        w0 = w0 / w0.sum()

        self.effect_ = np.sum(w1 * Y) - np.sum(w0 * Y)

        # Bootstrap standard error
        def ipw_stat(df):
            T_b = df[self._treatment_col].values
            Y_b = df[self._outcome_col].values
            e_b = self._estimate_propensity(df, T_b, df[self._covariate_cols].values)
            e_b = np.clip(e_b, 0.01, 0.99)
            w1_b = T_b / e_b
            w0_b = (1 - T_b) / (1 - e_b)
            w1_b = w1_b / w1_b.sum()
            w0_b = w0_b / w0_b.sum()
            return np.sum(w1_b * Y_b) - np.sum(w0_b * Y_b)

        self.std_error_ = bootstrap_std_error(
            data, ipw_stat, self._effective_n_bootstrap, self.random_state, n_jobs=self.n_jobs
        )

        # Inference
        self.p_value_ = compute_p_value(self.effect_, self.std_error_)
        self.ci_ = compute_ci(self.effect_, self.std_error_, self.confidence_level)

    def _fit_doubly_robust(
        self, data: pd.DataFrame, T: np.ndarray, Y: np.ndarray, X: Optional[np.ndarray]
    ) -> None:
        """Doubly robust (AIPW) estimator."""
        # Estimate propensity scores
        e = self._estimate_propensity(data, T, X)
        self._propensity_scores = e
        e = np.clip(e, 0.01, 0.99)

        # Estimate outcome models
        mu1, mu0 = self._estimate_outcome_models(T, Y, X)
        self._outcome_predictions = {"mu1": mu1, "mu0": mu0}

        # AIPW estimator
        # psi = mu1 - mu0 + T*(Y-mu1)/e - (1-T)*(Y-mu0)/(1-e)
        psi = mu1 - mu0 + T * (Y - mu1) / e - (1 - T) * (Y - mu0) / (1 - e)

        self.effect_ = np.mean(psi)

        # Standard error from influence function
        self.std_error_ = np.std(psi, ddof=1) / np.sqrt(len(psi))

        # Inference
        self.p_value_ = compute_p_value(self.effect_, self.std_error_)
        self.ci_ = compute_ci(self.effect_, self.std_error_, self.confidence_level)

    def _estimate_propensity(
        self, data: pd.DataFrame, T: np.ndarray, X: Optional[np.ndarray]
    ) -> np.ndarray:
        """Estimate propensity scores."""
        if self.propensity_model is not None:
            # Use provided model
            self.propensity_model.fit(X, T)
            return self.propensity_model.predict_proba(X)[:, 1]

        if X is None:
            # No covariates, use marginal probability
            return np.full(len(T), T.mean())

        # Default: logistic regression
        try:
            from sklearn.linear_model import LogisticRegression

            model = LogisticRegression(max_iter=1000, random_state=self.random_state)
            model.fit(X, T)
            return model.predict_proba(X)[:, 1]
        except ImportError:
            # Manual logistic regression using Newton-Raphson
            return self._manual_logistic_propensity(X, T)

    def _manual_logistic_propensity(
        self, X: np.ndarray, T: np.ndarray, max_iter: int = 100
    ) -> np.ndarray:
        """Manual logistic regression for propensity estimation."""
        n, k = X.shape
        X_aug = np.column_stack([np.ones(n), X])
        beta = np.zeros(k + 1)

        for _ in range(max_iter):
            p = 1 / (1 + np.exp(-X_aug @ beta))
            p = np.clip(p, 1e-10, 1 - 1e-10)

            # Gradient
            grad = X_aug.T @ (T - p)

            # Hessian
            W = np.diag(p * (1 - p))
            H = -X_aug.T @ W @ X_aug

            try:
                delta = np.linalg.solve(H, grad)
                beta = beta - delta
            except np.linalg.LinAlgError:
                break

            if np.max(np.abs(delta)) < 1e-6:
                break

        return 1 / (1 + np.exp(-X_aug @ beta))

    def _estimate_outcome_models(
        self, T: np.ndarray, Y: np.ndarray, X: Optional[np.ndarray]
    ) -> Tuple[np.ndarray, np.ndarray]:
        """Estimate outcome models E[Y|X,T=1] and E[Y|X,T=0]."""
        if self.outcome_model is not None:
            # Use provided model
            model1 = self.outcome_model.__class__()
            model0 = self.outcome_model.__class__()

            model1.fit(X[T == 1], Y[T == 1])
            model0.fit(X[T == 0], Y[T == 0])

            mu1 = model1.predict(X)
            mu0 = model0.predict(X)
            return mu1, mu0

        if X is None:
            # No covariates
            mu1 = np.full(len(Y), Y[T == 1].mean())
            mu0 = np.full(len(Y), Y[T == 0].mean())
            return mu1, mu0

        # Default: OLS
        n, k = X.shape
        X_aug = np.column_stack([np.ones(n), X])

        # Fit separate regressions
        X1 = X_aug[T == 1]
        Y1 = Y[T == 1]
        X0 = X_aug[T == 0]
        Y0 = Y[T == 0]

        try:
            beta1, _, _, _ = np.linalg.lstsq(X1, Y1, rcond=None)
            beta0, _, _, _ = np.linalg.lstsq(X0, Y0, rcond=None)

            mu1 = X_aug @ beta1
            mu0 = X_aug @ beta0
        except np.linalg.LinAlgError:
            # Fall back to means
            mu1 = np.full(len(Y), Y[T == 1].mean())
            mu0 = np.full(len(Y), Y[T == 0].mean())

        return mu1, mu0

    def _bootstrap_se(self, T: np.ndarray, Y: np.ndarray, X: Optional[np.ndarray]) -> float:
        """Compute bootstrap standard error."""
        rng = np.random.default_rng(self.random_state)
        n = len(Y)
        estimates = []

        for _ in range(self.n_bootstrap):
            idx = rng.choice(n, size=n, replace=True)
            T_b = T[idx]
            Y_b = Y[idx]
            X_b = X[idx] if X is not None else None

            # Compute estimate on bootstrap sample
            if self.method == "difference_in_means" or X_b is None:
                est = Y_b[T_b == 1].mean() - Y_b[T_b == 0].mean()
            else:
                X_design = np.column_stack([np.ones(n), X_b, T_b])
                try:
                    beta, _, _, _ = np.linalg.lstsq(X_design, Y_b, rcond=None)
                    est = beta[-1]
                except:
                    est = Y_b[T_b == 1].mean() - Y_b[T_b == 0].mean()

            estimates.append(est)

        return np.std(estimates, ddof=1)

    def predict(self, data: pd.DataFrame, **kwargs) -> np.ndarray:
        """
        Predict treatment effects for new data.

        For homogeneous treatment effect models, returns the estimated ATE
        for each observation.

        Parameters
        ----------
        data : pd.DataFrame
            New data for prediction

        Returns
        -------
        np.ndarray
            Predicted treatment effects
        """
        self._check_is_fitted()

        # For these simple estimators, return constant effect
        return np.full(len(data), self.effect_)

    def get_treatment_effect(self, **kwargs) -> TreatmentEffectResult:
        """
        Get the treatment effect result.

        Returns
        -------
        TreatmentEffectResult
            Full treatment effect result with inference
        """
        self._check_is_fitted()

        # Create ATE estimate
        ate = CausalEstimate(
            estimate=self.effect_,
            std_error=self.std_error_,
            ci_lower=self.ci_[0],
            ci_upper=self.ci_[1],
            p_value=self.p_value_,
        )

        return TreatmentEffectResult(ate=ate)

    def estimate_ate(self) -> CausalEstimate:
        """
        Estimate average treatment effect (required by base class).

        Returns
        -------
        CausalEstimate
            Estimated ATE with inference
        """
        self._check_is_fitted()

        return CausalEstimate(
            estimate=self.effect_,
            std_error=self.std_error_,
            ci_lower=self.ci_[0],
            ci_upper=self.ci_[1],
            p_value=self.p_value_,
        )

    def validate_assumptions(self, data: pd.DataFrame) -> PolicyValidationResult:
        """
        Validate causal assumptions.

        Checks:
        - Overlap (propensity score overlap)
        - Covariate balance
        - Positivity

        Parameters
        ----------
        data : pd.DataFrame
            Data to validate

        Returns
        -------
        PolicyValidationResult
            Validation results
        """
        self._check_is_fitted()

        checks = {}
        warnings = []

        # 1. Overlap check
        if self._propensity_scores is not None:
            e = self._propensity_scores
            min_e = e.min()
            max_e = e.max()

            overlap_ok = min_e > 0.01 and max_e < 0.99
            checks["overlap"] = overlap_ok

            if not overlap_ok:
                warnings.append(
                    f"Overlap violation: propensity scores range from "
                    f"{min_e:.3f} to {max_e:.3f}"
                )

        # 2. Covariate balance check
        if self._balance_stats is not None:
            n_unbalanced = sum(1 for v in self._balance_stats.values() if not v["balanced"])
            balance_ok = n_unbalanced == 0
            checks["covariate_balance"] = balance_ok

            if not balance_ok:
                warnings.append(f"{n_unbalanced} covariates are imbalanced (|SMD| > 0.1)")

        # 3. Positivity check
        T = data[self._treatment_col].values
        n_treated = T.sum()
        n_control = len(T) - n_treated

        positivity_ok = n_treated >= 10 and n_control >= 10
        checks["positivity"] = positivity_ok

        if not positivity_ok:
            warnings.append(f"Positivity concern: {n_treated} treated, {n_control} control")

        # Overall validity
        is_valid = all(checks.values()) if checks else True

        return PolicyValidationResult(
            is_valid=is_valid,
            checks=checks,
            warnings=warnings,
            recommendations=(
                [
                    "Consider matching or IPW if balance is poor",
                    "Use robust standard errors with clustered data",
                ]
                if not is_valid
                else []
            ),
        )

    def summary(self) -> str:
        """
        Generate text summary of estimation results.

        Returns
        -------
        str
            Formatted summary string
        """
        self._check_is_fitted()

        lines = [
            "=" * 60,
            f"Treatment Effect Estimation Results",
            "=" * 60,
            f"Method: {self.method}",
            f"",
            f"Average Treatment Effect (ATE)",
            f"-" * 40,
            f"  Estimate:      {self.effect_:>12.4f}",
            f"  Std. Error:    {self.std_error_:>12.4f}",
            f"  95% CI:        [{self.ci_[0]:>8.4f}, {self.ci_[1]:>8.4f}]",
            f"  P-value:       {self.p_value_:>12.4f}",
            f"",
        ]

        # Statistical significance
        if self.p_value_ < 0.001:
            sig = "***"
        elif self.p_value_ < 0.01:
            sig = "**"
        elif self.p_value_ < 0.05:
            sig = "*"
        else:
            sig = ""

        lines.append(f"  Significance:  {sig}")
        lines.append(f"")
        lines.append("=" * 60)

        return "\n".join(lines)

    def get_diagnostics(self) -> "DiagnosticResult":
        """
        Get diagnostic information about the estimation.

        Returns
        -------
        DiagnosticResult
            Diagnostic information with balance statistics if available
        """
        from krl_policy.core.base import DiagnosticResult

        self._check_is_fitted()

        diagnostics = DiagnosticResult()
        if self._balance_stats:
            diagnostics.balance_statistics = self._balance_stats
        return diagnostics

    def _get_params(self) -> Dict[str, Any]:
        """Get estimator parameters."""
        return {
            "method": self.method,
            "confidence_level": self.confidence_level,
            "n_bootstrap": self.n_bootstrap,
            "random_state": self.random_state,
        }


# =============================================================================
# Exports
# =============================================================================

__all__ = [
    "TreatmentEffectEstimator",
]
