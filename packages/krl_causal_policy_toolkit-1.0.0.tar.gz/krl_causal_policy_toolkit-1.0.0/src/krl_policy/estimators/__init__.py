# ----------------------------------------------------------------------
# © 2025 KR-Labs. All rights reserved.
# KR-Labs™ is a trademark of Quipu Research Labs, LLC,
# a subsidiary of Sudiata Giddasira, Inc.
# ----------------------------------------------------------------------
# SPDX-License-Identifier: Apache-2.0

"""
Estimators module for KRL Causal Policy Toolkit.

Provides a comprehensive suite of causal inference estimators:

Phase 1 - Foundation:
- TreatmentEffectEstimator: Basic treatment effect methods (DiM, regression, IPW, DR)

Phase 2 - Advanced Methods:
- DifferenceInDifferences: DiD with TWFE and event studies
- SyntheticControlMethod: Abadie-Gardeazabal-Diamond-Hainmueller SCM
- PropensityScoreMatching: PSM with various matching algorithms
- CovariateMatching: Mahalanobis and Euclidean distance matching
- InstrumentalVariables: 2SLS, LIML, and GMM estimators

Phase 3 - Advanced Methods:
- RegressionDiscontinuity: Sharp and Fuzzy RDD with bandwidth selection
"""

# Phase 2: Advanced estimators
from krl_policy.estimators.did import (
    DiDResult,
    DifferenceInDifferences,
    EventStudyResult,
)
from krl_policy.estimators.iv import (
    InstrumentalVariables,
    IVDiagnostics,
    IVMethod,
    IVResult,
)
from krl_policy.estimators.matching import (
    CovariateMatching,
    MatchingMethod,
    MatchingResult,
    PropensityScoreMatching,
    ReplacementMode,
)

# Phase 3: Advanced estimators
from krl_policy.estimators.rdd import (
    BandwidthMethod,
    KernelType,
    RDDResult,
    RDDType,
    RegressionDiscontinuity,
)
from krl_policy.estimators.synthetic_control import (
    PlaceboResult,
    SyntheticControlMethod,
    SyntheticControlResult,
)

# Phase 1: Foundation estimators
from krl_policy.estimators.treatment_effect import TreatmentEffectEstimator

__all__ = [
    # Phase 1
    "TreatmentEffectEstimator",
    # Phase 2 - DiD
    "DifferenceInDifferences",
    "DiDResult",
    "EventStudyResult",
    # Phase 2 - Synthetic Control
    "SyntheticControlMethod",
    "SyntheticControlResult",
    "PlaceboResult",
    # Phase 2 - Matching
    "PropensityScoreMatching",
    "CovariateMatching",
    "MatchingResult",
    "MatchingMethod",
    "ReplacementMode",
    # Phase 2 - IV
    "InstrumentalVariables",
    "IVResult",
    "IVDiagnostics",
    "IVMethod",
    # Phase 3 - RDD
    "RegressionDiscontinuity",
    "RDDResult",
    "RDDType",
    "BandwidthMethod",
    "KernelType",
]
