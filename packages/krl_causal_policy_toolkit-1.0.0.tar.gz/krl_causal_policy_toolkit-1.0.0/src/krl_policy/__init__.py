# ----------------------------------------------------------------------
# © 2025 KR-Labs. All rights reserved.
# KR-Labs™ is a trademark of Quipu Research Labs, LLC,
# a subsidiary of Sudiata Giddasira, Inc.
# ----------------------------------------------------------------------
# SPDX-License-Identifier: Apache-2.0

"""
KRL Causal Policy Toolkit - Policy evaluation and causal inference tools.

This package provides comprehensive causal inference and policy evaluation
capabilities including:

Phase 1 - Foundation:
- Treatment effect estimation (DiM, Regression, IPW, Doubly Robust)
- Synthetic data generators for testing
- Statistical utilities for inference

Phase 2 - Advanced Methods:
- Difference-in-Differences (DiD) with TWFE and event studies
- Synthetic Control Method (SCM) for aggregate interventions
- Propensity Score and Covariate Matching
- Instrumental Variables (2SLS, LIML, GMM)

Phase 3 - Advanced Methods & Evaluators:
- Regression Discontinuity Design (Sharp and Fuzzy RDD)
- Cost-Benefit Analysis with Monte Carlo simulation
- PolicyEvaluator: Unified evaluation interface
"""

from krl_policy.__version__ import __author__, __license__, __version__

# Phase 4 - Analysis Tools
from krl_policy.analysis import (
    EValue,
    PlaceboTest,
    RosenbaumBounds,
    SensitivityAnalyzer,
    SpecificationCurve,
)

# Core classes
from krl_policy.core import (  # Exceptions; Utilities
    BasePolicyEstimator,
    CausalEstimate,
    ConvergenceError,
    DataValidationError,
    DiagnosticResult,
    EffectType,
    EstimationError,
    EstimationMethod,
    IdentificationError,
    InferenceMethod,
    PolicyConfig,
    PolicyException,
    PolicyValidationResult,
    TreatmentEffectResult,
    balance_check,
    balance_summary,
    bootstrap_ci,
    bootstrap_std_error,
    clustered_se,
    compute_ci,
    compute_p_value,
    parallel_trends_test,
    standardized_mean_difference,
)

# Phase 4 - Data Integration
from krl_policy.data import (
    PolicyDataLoader,
    PolicyDataset,
    list_available_datasets,
    load_policy_dataset,
)

# Datasets
from krl_policy.datasets import (
    ConfoundedObservationalGenerator,
    DataGeneratorConfig,
    HeterogeneousTreatmentEffectGenerator,
    PanelDataGenerator,
    PerfectRCTGenerator,
    RegressionDiscontinuityGenerator,
    SyntheticDataGenerator,
    make_confounded_data,
    make_panel_data,
    make_rct_data,
)

# Phase 3 Estimators
# Phase 2 Estimators
# Phase 1 Estimators
from krl_policy.estimators import (  # Difference-in-Differences; Synthetic Control; Matching; Instrumental Variables; Regression Discontinuity
    BandwidthMethod,
    CovariateMatching,
    DiDResult,
    DifferenceInDifferences,
    EventStudyResult,
    InstrumentalVariables,
    IVDiagnostics,
    IVMethod,
    IVResult,
    KernelType,
    MatchingMethod,
    MatchingResult,
    PlaceboResult,
    PropensityScoreMatching,
    RDDResult,
    RDDType,
    RegressionDiscontinuity,
    ReplacementMode,
    SyntheticControlMethod,
    SyntheticControlResult,
    TreatmentEffectEstimator,
)

# Phase 3 Evaluators
from krl_policy.evaluators import (  # Cost-Benefit Analysis; Policy Evaluator
    AssumptionReport,
    CashFlow,
    CostBenefitAnalyzer,
    CostBenefitResult,
    DiscountRate,
    DistributionalResult,
    MethodComparison,
    MonteCarloResult,
    PolicyEvaluationResult,
    PolicyEvaluator,
    SensitivityResult,
)

# Phase 4 - Reporting Tools
from krl_policy.reporting import (
    HTMLReport,
    LaTeXReport,
    MarkdownReport,
    ReportConfig,
    ReportGenerator,
)

__all__ = [
    # Version info
    "__version__",
    "__author__",
    "__license__",
    # Core classes
    "BasePolicyEstimator",
    "TreatmentEffectResult",
    "PolicyValidationResult",
    "CausalEstimate",
    "DiagnosticResult",
    "PolicyConfig",
    "EstimationMethod",
    "EffectType",
    "InferenceMethod",
    # Exceptions
    "PolicyException",
    "EstimationError",
    "IdentificationError",
    "DataValidationError",
    "ConvergenceError",
    # Utilities
    "bootstrap_ci",
    "bootstrap_std_error",
    "clustered_se",
    "standardized_mean_difference",
    "balance_check",
    "balance_summary",
    "parallel_trends_test",
    "compute_p_value",
    "compute_ci",
    # Phase 1 Estimators
    "TreatmentEffectEstimator",
    # Phase 2 - DiD
    "DifferenceInDifferences",
    "DiDResult",
    "EventStudyResult",
    # Phase 2 - Synthetic Control
    "SyntheticControlMethod",
    "SyntheticControlResult",
    "PlaceboResult",
    # Phase 2 - Matching
    "PropensityScoreMatching",
    "CovariateMatching",
    "MatchingResult",
    "MatchingMethod",
    "ReplacementMode",
    # Phase 2 - IV
    "InstrumentalVariables",
    "IVResult",
    "IVDiagnostics",
    "IVMethod",
    # Phase 3 - RDD
    "RegressionDiscontinuity",
    "RDDResult",
    "RDDType",
    "BandwidthMethod",
    "KernelType",
    # Phase 3 - Cost-Benefit Analysis
    "CostBenefitAnalyzer",
    "CostBenefitResult",
    "SensitivityResult",
    "MonteCarloResult",
    "DistributionalResult",
    "CashFlow",
    "DiscountRate",
    # Phase 3 - Policy Evaluator
    "PolicyEvaluator",
    "PolicyEvaluationResult",
    "MethodComparison",
    "AssumptionReport",
    # Phase 4 - Sensitivity Analysis
    "SensitivityAnalyzer",
    "RosenbaumBounds",
    "EValue",
    "SpecificationCurve",
    "PlaceboTest",
    # Phase 4 - Reporting
    "ReportGenerator",
    "HTMLReport",
    "LaTeXReport",
    "MarkdownReport",
    "ReportConfig",
    # Phase 4 - Data Integration
    "PolicyDataset",
    "PolicyDataLoader",
    "list_available_datasets",
    "load_policy_dataset",
    # Datasets
    "DataGeneratorConfig",
    "SyntheticDataGenerator",
    "PerfectRCTGenerator",
    "ConfoundedObservationalGenerator",
    "HeterogeneousTreatmentEffectGenerator",
    "PanelDataGenerator",
    "RegressionDiscontinuityGenerator",
    "make_rct_data",
    "make_confounded_data",
    "make_panel_data",
]
