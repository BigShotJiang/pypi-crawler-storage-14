# Copyright (c) 2024 Sudiata Giddasira, Inc. d/b/a Quipu Research Labs, LLC d/b/a KR-Labs™
# SPDX-License-Identifier: MIT
#
# Khipu Research Analytics Suite - KR-Labs™
# Commercial Use: Contact KR-Labs™ for licensing terms

"""
Policy dataset loaders and data integration utilities.

This module provides tools for loading and working with policy-relevant datasets,
including integration with krl-data-connectors for external data sources.
"""

from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import numpy as np
import pandas as pd
from krl_core.logging import get_logger

logger = get_logger(__name__)


# =============================================================================
# Dataset Metadata
# =============================================================================


class DatasetSource(Enum):
    """Source types for policy datasets."""

    BUILTIN = "builtin"
    CONNECTOR = "connector"
    FILE = "file"
    URL = "url"


@dataclass
class DatasetMetadata:
    """
    Metadata for policy datasets.

    Attributes
    ----------
    name : str
        Dataset name
    description : str
        Dataset description
    source : DatasetSource
        Source type
    treatment_col : str
        Name of treatment variable
    outcome_col : str
        Name of outcome variable
    covariates : List[str]
        List of covariate columns
    time_col : Optional[str]
        Time variable for panel data
    unit_col : Optional[str]
        Unit identifier for panel data
    running_var : Optional[str]
        Running variable for RDD
    cutoff : Optional[float]
        Cutoff value for RDD
    instrument : Optional[str]
        Instrumental variable
    n_obs : Optional[int]
        Number of observations
    n_treated : Optional[int]
        Number of treated units
    tags : List[str]
        Dataset tags for categorization
    """

    name: str
    description: str
    source: DatasetSource
    treatment_col: str
    outcome_col: str
    covariates: List[str] = field(default_factory=list)
    time_col: Optional[str] = None
    unit_col: Optional[str] = None
    running_var: Optional[str] = None
    cutoff: Optional[float] = None
    instrument: Optional[str] = None
    n_obs: Optional[int] = None
    n_treated: Optional[int] = None
    tags: List[str] = field(default_factory=list)


# =============================================================================
# Dataset Container
# =============================================================================


@dataclass
class PolicyDataset:
    """
    Container for policy evaluation datasets.

    Parameters
    ----------
    data : pd.DataFrame
        The dataset
    metadata : DatasetMetadata
        Dataset metadata

    Attributes
    ----------
    data : pd.DataFrame
        The dataset
    metadata : DatasetMetadata
        Dataset metadata

    Examples
    --------
    >>> from krl_policy.data import load_policy_dataset
    >>> dataset = load_policy_dataset("nsw")
    >>> df = dataset.data
    >>> print(dataset.metadata.description)
    """

    data: pd.DataFrame
    metadata: DatasetMetadata

    def __post_init__(self):
        """Validate dataset."""
        if self.metadata.treatment_col not in self.data.columns:
            raise ValueError(f"Treatment column '{self.metadata.treatment_col}' not found in data")
        if self.metadata.outcome_col not in self.data.columns:
            raise ValueError(f"Outcome column '{self.metadata.outcome_col}' not found in data")

    @property
    def treatment(self) -> pd.Series:
        """Get treatment variable."""
        return self.data[self.metadata.treatment_col]

    @property
    def outcome(self) -> pd.Series:
        """Get outcome variable."""
        return self.data[self.metadata.outcome_col]

    @property
    def covariates_data(self) -> pd.DataFrame:
        """Get covariate data."""
        if not self.metadata.covariates:
            return pd.DataFrame(index=self.data.index)
        return self.data[self.metadata.covariates]

    def split_by_treatment(self) -> Tuple[pd.DataFrame, pd.DataFrame]:
        """
        Split data into treated and control groups.

        Returns
        -------
        treated : pd.DataFrame
            Treated group data
        control : pd.DataFrame
            Control group data
        """
        treated = self.data[self.treatment == 1]
        control = self.data[self.treatment == 0]
        return treated, control

    def summary(self) -> Dict[str, Any]:
        """
        Get dataset summary statistics.

        Returns
        -------
        summary : dict
            Summary statistics
        """
        treated, control = self.split_by_treatment()

        return {
            "n_obs": len(self.data),
            "n_treated": len(treated),
            "n_control": len(control),
            "treatment_rate": len(treated) / len(self.data),
            "outcome_mean_treated": treated[self.metadata.outcome_col].mean(),
            "outcome_mean_control": control[self.metadata.outcome_col].mean(),
            "outcome_diff": treated[self.metadata.outcome_col].mean()
            - control[self.metadata.outcome_col].mean(),
        }

    def describe(self) -> str:
        """
        Get human-readable dataset description.

        Returns
        -------
        description : str
            Formatted description
        """
        summary = self.summary()

        desc = f"""
{self.metadata.name.upper()} Dataset
{'-' * (len(self.metadata.name) + 8)}

Description: {self.metadata.description}

Sample Size:
  Total: {summary['n_obs']:,}
  Treated: {summary['n_treated']:,} ({summary['treatment_rate']:.1%})
  Control: {summary['n_control']:,}

Outcome Variable: {self.metadata.outcome_col}
  Mean (Treated): {summary['outcome_mean_treated']:.3f}
  Mean (Control): {summary['outcome_mean_control']:.3f}
  Raw Difference: {summary['outcome_diff']:.3f}

Covariates: {', '.join(self.metadata.covariates) if self.metadata.covariates else 'None'}
"""
        if self.metadata.time_col:
            desc += f"Time Variable: {self.metadata.time_col}\n"
        if self.metadata.unit_col:
            desc += f"Unit Variable: {self.metadata.unit_col}\n"
        if self.metadata.running_var:
            desc += (
                f"Running Variable: {self.metadata.running_var} (cutoff={self.metadata.cutoff})\n"
            )
        if self.metadata.instrument:
            desc += f"Instrument: {self.metadata.instrument}\n"

        return desc.strip()


# =============================================================================
# Built-in Datasets
# =============================================================================


class DatasetRegistry:
    """Registry of built-in policy datasets."""

    _datasets: Dict[str, Dict[str, Any]] = {
        "nsw": {
            "description": "National Supported Work (NSW) Demonstration - Job training program evaluation",
            "treatment_col": "treat",
            "outcome_col": "re78",
            "covariates": [
                "age",
                "education",
                "black",
                "hispanic",
                "married",
                "nodegree",
                "re74",
                "re75",
            ],
            "tags": ["employment", "training", "rct"],
            "generator": lambda: _generate_nsw_data(),
        },
        "medicaid": {
            "description": "Medicaid expansion impact on health outcomes",
            "treatment_col": "medicaid_expansion",
            "outcome_col": "insurance_rate",
            "covariates": ["poverty_rate", "unemployment", "median_income", "urban"],
            "time_col": "year",
            "unit_col": "state",
            "tags": ["health", "medicaid", "did", "panel"],
            "generator": lambda: _generate_medicaid_data(),
        },
        "minimum_wage": {
            "description": "Minimum wage increase effects on employment",
            "treatment_col": "min_wage_increase",
            "outcome_col": "employment_rate",
            "covariates": ["gdp_growth", "population", "industry_mix"],
            "time_col": "quarter",
            "unit_col": "state",
            "tags": ["labor", "minimum-wage", "did", "panel"],
            "generator": lambda: _generate_minimum_wage_data(),
        },
        "education_voucher": {
            "description": "Education voucher program effects on test scores",
            "treatment_col": "voucher",
            "outcome_col": "test_score",
            "covariates": ["parental_education", "household_income", "prior_score"],
            "instrument": "lottery_win",
            "tags": ["education", "voucher", "iv"],
            "generator": lambda: _generate_education_voucher_data(),
        },
        "snap_eligibility": {
            "description": "SNAP eligibility threshold effects on food security",
            "treatment_col": "snap_eligible",
            "outcome_col": "food_security_score",
            "covariates": ["household_size", "employment_status", "age"],
            "running_var": "income_pct_fpl",
            "cutoff": 130.0,
            "tags": ["nutrition", "snap", "rdd"],
            "generator": lambda: _generate_snap_data(),
        },
    }

    @classmethod
    def list_datasets(cls) -> List[str]:
        """List available dataset names."""
        return list(cls._datasets.keys())

    @classmethod
    def get_metadata(cls, name: str) -> DatasetMetadata:
        """Get dataset metadata."""
        if name not in cls._datasets:
            raise ValueError(f"Dataset '{name}' not found. Available: {cls.list_datasets()}")

        config = cls._datasets[name]
        return DatasetMetadata(
            name=name,
            description=config["description"],
            source=DatasetSource.BUILTIN,
            treatment_col=config["treatment_col"],
            outcome_col=config["outcome_col"],
            covariates=config.get("covariates", []),
            time_col=config.get("time_col"),
            unit_col=config.get("unit_col"),
            running_var=config.get("running_var"),
            cutoff=config.get("cutoff"),
            instrument=config.get("instrument"),
            tags=config.get("tags", []),
        )

    @classmethod
    def load_dataset(cls, name: str) -> PolicyDataset:
        """Load a built-in dataset."""
        if name not in cls._datasets:
            raise ValueError(f"Dataset '{name}' not found. Available: {cls.list_datasets()}")

        config = cls._datasets[name]
        data = config["generator"]()
        metadata = cls.get_metadata(name)

        # Update metadata with actual counts
        metadata.n_obs = len(data)
        metadata.n_treated = (data[metadata.treatment_col] == 1).sum()

        return PolicyDataset(data=data, metadata=metadata)


# =============================================================================
# Data Generators for Built-in Datasets
# =============================================================================


def _generate_nsw_data() -> pd.DataFrame:
    """Generate NSW-like dataset."""
    np.random.seed(42)
    n = 614

    # Demographics
    age = np.random.normal(25, 7, n)
    education = np.random.normal(10, 2, n)
    black = np.random.binomial(1, 0.8, n)
    hispanic = np.random.binomial(1, 0.1, n)
    married = np.random.binomial(1, 0.2, n)
    nodegree = (education < 12).astype(int)

    # Pre-treatment earnings
    re74 = np.maximum(0, np.random.normal(2000, 5000, n))
    re75 = np.maximum(0, np.random.normal(1500, 4500, n))

    # Treatment assignment
    treatment_score = (
        -2 + 0.05 * age - 0.2 * education + 0.5 * black - 0.3 * married + 0.0005 * (re74 + re75)
    )
    treat_prob = 1 / (1 + np.exp(-treatment_score))
    treat = np.random.binomial(1, treat_prob, n)

    # Outcome (1978 earnings)
    re78 = (
        1500
        + 1500 * treat  # treatment effect
        + 100 * age
        - 5 * age**2  # age effects
        + 500 * education
        + -1000 * black
        + 1000 * married
        + 0.3 * re74
        + 0.3 * re75
        + np.random.normal(0, 3000, n)
    )
    re78 = np.maximum(0, re78)

    return pd.DataFrame(
        {
            "treat": treat,
            "re78": re78,
            "age": age,
            "education": education,
            "black": black,
            "hispanic": hispanic,
            "married": married,
            "nodegree": nodegree,
            "re74": re74,
            "re75": re75,
        }
    )


def _generate_medicaid_data() -> pd.DataFrame:
    """Generate Medicaid expansion panel dataset."""
    np.random.seed(43)

    states = [f"State_{i}" for i in range(50)]
    years = list(range(2010, 2020))

    data = []
    for state_id, state in enumerate(states):
        # Some states expand in 2014, others later or not at all
        expansion_year = 2014 if state_id < 30 else (2016 if state_id < 40 else None)

        for year in years:
            medicaid_expansion = 1 if (expansion_year and year >= expansion_year) else 0

            # State characteristics
            poverty_rate = 12 + np.random.normal(0, 3)
            unemployment = 6 + np.random.normal(0, 2)
            median_income = 50000 + state_id * 1000 + np.random.normal(0, 5000)
            urban = np.random.binomial(1, 0.7)

            # Outcome: insurance rate
            insurance_rate = (
                75  # baseline
                + 8 * medicaid_expansion  # treatment effect
                + -0.5 * poverty_rate
                + -0.3 * unemployment
                + 0.0003 * median_income
                + 5 * urban
                + 2 * (year - 2010)  # time trend
                + np.random.normal(0, 3)
            )
            insurance_rate = np.clip(insurance_rate, 0, 100)

            data.append(
                {
                    "state": state,
                    "year": year,
                    "medicaid_expansion": medicaid_expansion,
                    "insurance_rate": insurance_rate,
                    "poverty_rate": poverty_rate,
                    "unemployment": unemployment,
                    "median_income": median_income,
                    "urban": urban,
                }
            )

    return pd.DataFrame(data)


def _generate_minimum_wage_data() -> pd.DataFrame:
    """Generate minimum wage panel dataset."""
    np.random.seed(44)

    states = [f"State_{i}" for i in range(40)]
    quarters = list(range(1, 21))  # 5 years of quarterly data

    data = []
    for state_id, state in enumerate(states):
        # Some states increase minimum wage at quarter 11
        treatment_quarter = 11 if state_id < 20 else None

        for quarter in quarters:
            min_wage_increase = 1 if (treatment_quarter and quarter >= treatment_quarter) else 0

            # State characteristics
            gdp_growth = 2 + np.random.normal(0, 1)
            population = 5000000 + state_id * 100000
            industry_mix = np.random.normal(0, 1)

            # Outcome: employment rate
            employment_rate = (
                95  # baseline
                + -0.5 * min_wage_increase  # small negative effect
                + 0.3 * gdp_growth
                + 5e-7 * population
                + 0.2 * industry_mix
                + 0.1 * quarter  # time trend
                + np.random.normal(0, 1)
            )
            employment_rate = np.clip(employment_rate, 85, 100)

            data.append(
                {
                    "state": state,
                    "quarter": quarter,
                    "min_wage_increase": min_wage_increase,
                    "employment_rate": employment_rate,
                    "gdp_growth": gdp_growth,
                    "population": population,
                    "industry_mix": industry_mix,
                }
            )

    return pd.DataFrame(data)


def _generate_education_voucher_data() -> pd.DataFrame:
    """Generate education voucher dataset with instrumental variable."""
    np.random.seed(45)
    n = 1000

    # Characteristics
    parental_education = np.random.normal(12, 3, n)
    household_income = np.maximum(0, np.random.normal(50000, 20000, n))
    prior_score = np.random.normal(500, 100, n)

    # Instrument: lottery win (random)
    lottery_win = np.random.binomial(1, 0.5, n)

    # Treatment: voucher use (affected by lottery and preferences)
    voucher_score = (
        -1
        + 2 * lottery_win
        + 0.1 * parental_education
        + 0.00003 * household_income
        + 0.005 * prior_score
    )
    voucher_prob = 1 / (1 + np.exp(-voucher_score))
    voucher = np.random.binomial(1, voucher_prob, n)

    # Outcome: test score
    test_score = (
        400
        + 50 * voucher  # treatment effect
        + 10 * parental_education
        + 0.001 * household_income
        + 0.3 * prior_score
        + np.random.normal(0, 50, n)
    )

    return pd.DataFrame(
        {
            "voucher": voucher,
            "test_score": test_score,
            "parental_education": parental_education,
            "household_income": household_income,
            "prior_score": prior_score,
            "lottery_win": lottery_win,
        }
    )


def _generate_snap_data() -> pd.DataFrame:
    """Generate SNAP eligibility RDD dataset."""
    np.random.seed(46)
    n = 2000

    # Running variable: income as % of federal poverty level
    income_pct_fpl = np.random.uniform(80, 180, n)

    # Treatment: SNAP eligibility (cutoff at 130%)
    snap_eligible = (income_pct_fpl <= 130).astype(int)

    # Characteristics
    household_size = np.random.choice([1, 2, 3, 4, 5, 6], n)
    employment_status = np.random.binomial(1, 0.6, n)
    age = np.random.normal(40, 15, n)

    # Outcome: food security score (higher is better)
    food_security_score = (
        50
        + 10 * snap_eligible  # treatment effect at cutoff
        + -0.2 * income_pct_fpl  # smooth function of running variable
        + 2 * household_size
        + 5 * employment_status
        + 0.1 * age
        + np.random.normal(0, 5, n)
    )
    food_security_score = np.clip(food_security_score, 0, 100)

    return pd.DataFrame(
        {
            "snap_eligible": snap_eligible,
            "food_security_score": food_security_score,
            "income_pct_fpl": income_pct_fpl,
            "household_size": household_size,
            "employment_status": employment_status,
            "age": age,
        }
    )


# =============================================================================
# High-level API
# =============================================================================


class PolicyDataLoader:
    """
    High-level interface for loading policy datasets.

    Examples
    --------
    >>> from krl_policy.data import PolicyDataLoader
    >>>
    >>> loader = PolicyDataLoader()
    >>> print(loader.list_available())
    >>>
    >>> # Load dataset
    >>> dataset = loader.load("nsw")
    >>> print(dataset.describe())
    >>>
    >>> # Access data
    >>> df = dataset.data
    >>> treatment = dataset.treatment
    >>> outcome = dataset.outcome
    """

    def __init__(self):
        self.registry = DatasetRegistry()

    def list_available(self) -> List[str]:
        """List available datasets."""
        return self.registry.list_datasets()

    def get_info(self, name: str) -> DatasetMetadata:
        """Get dataset information."""
        return self.registry.get_metadata(name)

    def load(self, name: str) -> PolicyDataset:
        """
        Load a policy dataset.

        Parameters
        ----------
        name : str
            Dataset name

        Returns
        -------
        dataset : PolicyDataset
            Loaded dataset
        """
        logger.info(f"Loading dataset: {name}")
        dataset = self.registry.load_dataset(name)
        logger.info(f"Loaded {dataset.metadata.n_obs} observations")
        return dataset


def list_available_datasets() -> List[str]:
    """
    List all available policy datasets.

    Returns
    -------
    datasets : List[str]
        List of dataset names

    Examples
    --------
    >>> from krl_policy.data import list_available_datasets
    >>> datasets = list_available_datasets()
    >>> print(datasets)
    ['nsw', 'medicaid', 'minimum_wage', 'education_voucher', 'snap_eligibility']
    """
    return DatasetRegistry.list_datasets()


def load_policy_dataset(name: str) -> PolicyDataset:
    """
    Load a policy dataset by name.

    Parameters
    ----------
    name : str
        Dataset name

    Returns
    -------
    dataset : PolicyDataset
        Loaded dataset

    Examples
    --------
    >>> from krl_policy.data import load_policy_dataset
    >>>
    >>> # Load NSW dataset
    >>> dataset = load_policy_dataset("nsw")
    >>> print(dataset.describe())
    >>>
    >>> # Access data
    >>> df = dataset.data
    >>> summary = dataset.summary()
    """
    loader = PolicyDataLoader()
    return loader.load(name)


__all__ = [
    "DatasetSource",
    "DatasetMetadata",
    "PolicyDataset",
    "DatasetRegistry",
    "PolicyDataLoader",
    "list_available_datasets",
    "load_policy_dataset",
]
