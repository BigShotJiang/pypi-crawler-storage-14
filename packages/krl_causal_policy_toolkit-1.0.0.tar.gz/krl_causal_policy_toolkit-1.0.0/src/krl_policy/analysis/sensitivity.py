# Copyright (c) 2024 Sudiata Giddasira, Inc. d/b/a Quipu Research Labs, LLC d/b/a KR-Labs™
# SPDX-License-Identifier: MIT
#
# Khipu Research Analytics Suite - KR-Labs™
# Commercial Use: Contact KR-Labs™ for licensing terms

"""
Sensitivity analysis for causal inference.

This module provides tools for assessing the robustness of causal estimates
to potential unmeasured confounding and model specification choices.
"""

from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional, Tuple

import numpy as np
import pandas as pd
from krl_core.logging import get_logger
from scipy import stats
from scipy.optimize import minimize_scalar

from krl_policy.core.base import CausalEstimate, EffectType

logger = get_logger(__name__)


# =============================================================================
# Result Classes
# =============================================================================


@dataclass
class RosenbaumBoundsResult:
    """
    Results from Rosenbaum bounds analysis.

    Attributes
    ----------
    gamma_values : np.ndarray
        Values of sensitivity parameter Gamma
    p_values_upper : np.ndarray
        Upper bound p-values for each Gamma
    p_values_lower : np.ndarray
        Lower bound p-values for each Gamma
    critical_gamma : float
        Value of Gamma where inference changes
    significance_level : float
        Significance level used
    """

    gamma_values: np.ndarray
    p_values_upper: np.ndarray
    p_values_lower: np.ndarray
    critical_gamma: float
    significance_level: float = 0.05

    def summary(self) -> str:
        """Generate summary text."""
        lines = [
            "=" * 60,
            "Rosenbaum Bounds Analysis",
            "=" * 60,
            f"Critical Gamma: {self.critical_gamma:.3f}",
            f"Significance Level: {self.significance_level}",
            "",
            "Interpretation:",
            f"  Hidden bias up to Gamma={self.critical_gamma:.2f} would not",
            f"  alter the inference at alpha={self.significance_level}",
            "=" * 60,
        ]
        return "\n".join(lines)


@dataclass
class EValueResult:
    """
    Results from E-value calculation.

    Attributes
    ----------
    e_value : float
        E-value for the point estimate
    e_value_ci : float
        E-value for the confidence interval bound
    estimate : float
        Original effect estimate
    std_error : float
        Standard error of estimate
    ci_lower : float
        Lower confidence bound
    ci_upper : float
        Upper confidence bound
    """

    e_value: float
    e_value_ci: float
    estimate: float
    std_error: float
    ci_lower: float
    ci_upper: float

    def summary(self) -> str:
        """Generate summary text."""
        lines = [
            "=" * 60,
            "E-Value Analysis",
            "=" * 60,
            f"Point Estimate: {self.estimate:.4f}",
            f"95% CI: [{self.ci_lower:.4f}, {self.ci_upper:.4f}]",
            "",
            f"E-value (estimate): {self.e_value:.3f}",
            f"E-value (CI bound): {self.e_value_ci:.3f}",
            "",
            "Interpretation:",
            f"  An unmeasured confounder would need to be associated",
            f"  with both treatment and outcome by a risk ratio of",
            f"  {self.e_value:.2f} to explain away the observed effect.",
            "=" * 60,
        ]
        return "\n".join(lines)


@dataclass
class SpecificationCurveResult:
    """
    Results from specification curve analysis.

    Attributes
    ----------
    specifications : List[Dict[str, Any]]
        List of all specification configurations
    estimates : np.ndarray
        Effect estimates for each specification
    std_errors : np.ndarray
        Standard errors for each specification
    p_values : np.ndarray
        P-values for each specification
    median_estimate : float
        Median across specifications
    iqr_estimate : Tuple[float, float]
        Interquartile range
    proportion_significant : float
        Proportion of specs with p < 0.05
    """

    specifications: List[Dict[str, Any]]
    estimates: np.ndarray
    std_errors: np.ndarray
    p_values: np.ndarray
    median_estimate: float
    iqr_estimate: Tuple[float, float]
    proportion_significant: float

    def summary(self) -> str:
        """Generate summary text."""
        lines = [
            "=" * 60,
            "Specification Curve Analysis",
            "=" * 60,
            f"Total Specifications: {len(self.specifications)}",
            f"Median Estimate: {self.median_estimate:.4f}",
            f"IQR: [{self.iqr_estimate[0]:.4f}, {self.iqr_estimate[1]:.4f}]",
            f"Range: [{np.min(self.estimates):.4f}, {np.max(self.estimates):.4f}]",
            "",
            f"Proportion Significant (p<0.05): {self.proportion_significant:.1%}",
            f"Std Dev Across Specs: {np.std(self.estimates):.4f}",
            "=" * 60,
        ]
        return "\n".join(lines)


@dataclass
class PlaceboTestResult:
    """
    Results from placebo tests.

    Attributes
    ----------
    placebo_estimates : List[CausalEstimate]
        Estimates from placebo tests
    primary_estimate : CausalEstimate
        Original estimate for comparison
    proportion_larger : float
        Proportion of placebo estimates larger in magnitude
    p_value : float
        Permutation-based p-value
    """

    placebo_estimates: List[CausalEstimate]
    primary_estimate: CausalEstimate
    proportion_larger: float
    p_value: float

    def summary(self) -> str:
        """Generate summary text."""
        placebo_vals = [est.estimate for est in self.placebo_estimates]
        lines = [
            "=" * 60,
            "Placebo Test Results",
            "=" * 60,
            f"Primary Estimate: {self.primary_estimate.estimate:.4f}",
            f"Number of Placebos: {len(self.placebo_estimates)}",
            f"Median Placebo: {np.median(placebo_vals):.4f}",
            f"Std Dev Placebos: {np.std(placebo_vals):.4f}",
            "",
            f"Proportion Larger: {self.proportion_larger:.1%}",
            f"P-value: {self.p_value:.4f}",
            "=" * 60,
        ]
        return "\n".join(lines)


# =============================================================================
# Core Analysis Classes
# =============================================================================


class RosenbaumBounds:
    """
    Rosenbaum bounds for sensitivity to hidden bias.

    Computes bounds on p-values under different levels of hidden bias
    (Gamma) for matched samples.

    Parameters
    ----------
    gamma_range : Tuple[float, float], default=(1.0, 3.0)
        Range of Gamma values to test
    n_gamma : int, default=20
        Number of Gamma values to evaluate
    significance_level : float, default=0.05
        Significance level for finding critical Gamma

    Examples
    --------
    >>> from krl_policy.analysis import RosenbaumBounds
    >>> rb = RosenbaumBounds()
    >>> result = rb.analyze(treatment_effects)
    >>> print(result.summary())
    """

    def __init__(
        self,
        gamma_range: Tuple[float, float] = (1.0, 3.0),
        n_gamma: int = 20,
        significance_level: float = 0.05,
    ):
        self.gamma_range = gamma_range
        self.n_gamma = n_gamma
        self.significance_level = significance_level

    def analyze(
        self, treatment_effects: np.ndarray, alternative: str = "two-sided"
    ) -> RosenbaumBoundsResult:
        """
        Compute Rosenbaum bounds.

        Parameters
        ----------
        treatment_effects : np.ndarray
            Matched pair differences (treated - control)
        alternative : str, default="two-sided"
            Alternative hypothesis: 'two-sided', 'greater', or 'less'

        Returns
        -------
        RosenbaumBoundsResult
            Bounds analysis results
        """
        logger.info("Computing Rosenbaum bounds for hidden bias")

        # Wilcoxon signed rank components
        abs_effects = np.abs(treatment_effects)
        signs = np.sign(treatment_effects)
        ranks = stats.rankdata(abs_effects)

        # Compute bounds for each Gamma
        gamma_values = np.linspace(self.gamma_range[0], self.gamma_range[1], self.n_gamma)

        p_values_upper = np.zeros(self.n_gamma)
        p_values_lower = np.zeros(self.n_gamma)

        for i, gamma in enumerate(gamma_values):
            p_upper, p_lower = self._compute_bounds(ranks, signs, gamma)
            p_values_upper[i] = p_upper
            p_values_lower[i] = p_lower

        # Find critical Gamma
        critical_gamma = self._find_critical_gamma(gamma_values, p_values_upper, p_values_lower)

        return RosenbaumBoundsResult(
            gamma_values=gamma_values,
            p_values_upper=p_values_upper,
            p_values_lower=p_values_lower,
            critical_gamma=critical_gamma,
            significance_level=self.significance_level,
        )

    def _compute_bounds(
        self, ranks: np.ndarray, signs: np.ndarray, gamma: float
    ) -> Tuple[float, float]:
        """Compute upper and lower p-value bounds for given Gamma."""
        n = len(ranks)
        T_plus = np.sum(ranks[signs > 0])

        # Expected value and variance under different biases
        E_T = n * (n + 1) / 4
        V_T = n * (n + 1) * (2 * n + 1) / 24

        # Upper bound (worst case for rejecting null)
        p_val = gamma / (1 + gamma)
        E_upper = p_val * n * (n + 1) / 2
        z_upper = (T_plus - E_upper) / np.sqrt(V_T)
        p_upper = 1 - stats.norm.cdf(z_upper)

        # Lower bound (best case for rejecting null)
        p_val = 1 / (1 + gamma)
        E_lower = p_val * n * (n + 1) / 2
        z_lower = (T_plus - E_lower) / np.sqrt(V_T)
        p_lower = 1 - stats.norm.cdf(z_lower)

        return p_upper, p_lower

    def _find_critical_gamma(
        self, gamma_values: np.ndarray, p_values_upper: np.ndarray, p_values_lower: np.ndarray
    ) -> float:
        """Find Gamma where inference would change."""
        # Find where upper bound crosses significance level
        idx = np.where(p_values_upper > self.significance_level)[0]
        if len(idx) == 0:
            return gamma_values[-1]  # No change within range
        return gamma_values[idx[0]]


class EValue:
    """
    Calculate E-values for unmeasured confounding.

    E-values quantify the minimum strength of association that an unmeasured
    confounder would need to have with both treatment and outcome to explain
    away an observed effect.

    References
    ----------
    VanderWeele TJ, Ding P (2017). Sensitivity Analysis in Observational Research:
    Introducing the E-Value. Annals of Internal Medicine.

    Examples
    --------
    >>> from krl_policy.analysis import EValue
    >>> ev = EValue()
    >>> result = ev.calculate(estimate=2.0, ci_lower=1.5, ci_upper=2.8)
    >>> print(result.summary())
    """

    def calculate(
        self, estimate: float, ci_lower: float, ci_upper: float, std_error: Optional[float] = None
    ) -> EValueResult:
        """
        Calculate E-values.

        Parameters
        ----------
        estimate : float
            Point estimate of causal effect (e.g., risk ratio, odds ratio)
        ci_lower : float
            Lower confidence bound
        ci_upper : float
            Upper confidence bound
        std_error : float, optional
            Standard error of estimate

        Returns
        -------
        EValueResult
            E-value analysis results
        """
        logger.info("Calculating E-values for unmeasured confounding")

        # Convert to risk ratio scale if needed
        # For now, assume already on appropriate scale

        # E-value for point estimate
        e_val = self._compute_e_value(estimate)

        # E-value for CI bound (use bound closer to null)
        if estimate > 1:
            e_val_ci = self._compute_e_value(ci_lower)
        else:
            e_val_ci = self._compute_e_value(ci_upper)

        if std_error is None:
            # Approximate from CI
            std_error = (ci_upper - ci_lower) / (2 * 1.96)

        return EValueResult(
            e_value=e_val,
            e_value_ci=e_val_ci,
            estimate=estimate,
            std_error=std_error,
            ci_lower=ci_lower,
            ci_upper=ci_upper,
        )

    def _compute_e_value(self, rr: float) -> float:
        """Compute E-value for risk ratio."""
        if rr >= 1:
            return rr + np.sqrt(rr * (rr - 1))
        else:
            return 1 / rr + np.sqrt(1 / rr * (1 / rr - 1))


class SpecificationCurve:
    """
    Specification curve analysis for model robustness.

    Tests sensitivity of results to different model specifications by
    systematically varying modeling choices.

    Parameters
    ----------
    estimator_fn : Callable
        Function that takes data and specification dict, returns CausalEstimate
    confidence_level : float, default=0.95
        Confidence level for inference

    Examples
    --------
    >>> from krl_policy.analysis import SpecificationCurve
    >>>
    >>> def my_estimator(data, spec):
    >>>     # Your estimation logic here
    >>>     return estimate
    >>>
    >>> sc = SpecificationCurve(estimator_fn=my_estimator)
    >>> result = sc.analyze(data, specifications)
    >>> print(result.summary())
    """

    def __init__(
        self,
        estimator_fn: Callable[[pd.DataFrame, Dict], CausalEstimate],
        confidence_level: float = 0.95,
    ):
        self.estimator_fn = estimator_fn
        self.confidence_level = confidence_level

    def analyze(
        self, data: pd.DataFrame, specifications: List[Dict[str, Any]]
    ) -> SpecificationCurveResult:
        """
        Run specification curve analysis.

        Parameters
        ----------
        data : pd.DataFrame
            Input data
        specifications : List[Dict[str, Any]]
            List of specification dictionaries. Each dict contains
            parameters for one model specification.

        Returns
        -------
        SpecificationCurveResult
            Specification curve results
        """
        logger.info(f"Running specification curve with {len(specifications)} specs")

        estimates = []
        std_errors = []
        p_values = []

        for i, spec in enumerate(specifications):
            try:
                result = self.estimator_fn(data, spec)
                estimates.append(result.estimate)
                std_errors.append(result.std_error)
                p_values.append(result.p_value)
            except Exception as e:
                logger.warning(f"Spec {i} failed: {e}")
                estimates.append(np.nan)
                std_errors.append(np.nan)
                p_values.append(np.nan)

        estimates = np.array(estimates)
        std_errors = np.array(std_errors)
        p_values = np.array(p_values)

        # Remove failed specs
        valid = ~np.isnan(estimates)
        estimates = estimates[valid]
        std_errors = std_errors[valid]
        p_values = p_values[valid]
        specs_clean = [s for i, s in enumerate(specifications) if valid[i]]

        # Summary statistics
        median_est = np.median(estimates)
        q25, q75 = np.percentile(estimates, [25, 75])
        prop_sig = np.mean(p_values < 0.05)

        return SpecificationCurveResult(
            specifications=specs_clean,
            estimates=estimates,
            std_errors=std_errors,
            p_values=p_values,
            median_estimate=median_est,
            iqr_estimate=(q25, q75),
            proportion_significant=prop_sig,
        )


class PlaceboTest:
    """
    Placebo tests for causal identification.

    Tests robustness by estimating effects on outcomes or treatments
    that should show no effect if the identification strategy is valid.

    Parameters
    ----------
    estimator_fn : Callable
        Function that estimates treatment effect
    n_permutations : int, default=1000
        Number of permutations for p-value calculation

    Examples
    --------
    >>> from krl_policy.analysis import PlaceboTest
    >>>
    >>> def my_estimator(data):
    >>>     # Your estimation logic
    >>>     return estimate
    >>>
    >>> pt = PlaceboTest(estimator_fn=my_estimator)
    >>> result = pt.run_placebo_outcomes(data, placebo_outcomes)
    >>> print(result.summary())
    """

    def __init__(
        self, estimator_fn: Callable[[pd.DataFrame], CausalEstimate], n_permutations: int = 1000
    ):
        self.estimator_fn = estimator_fn
        self.n_permutations = n_permutations

    def run_placebo_outcomes(
        self, data: pd.DataFrame, placebo_outcomes: List[str], primary_outcome: str
    ) -> PlaceboTestResult:
        """
        Test on placebo outcomes that should show no effect.

        Parameters
        ----------
        data : pd.DataFrame
            Input data
        placebo_outcomes : List[str]
            Column names of placebo outcomes
        primary_outcome : str
            Column name of primary outcome (for comparison)

        Returns
        -------
        PlaceboTestResult
            Placebo test results
        """
        logger.info(f"Running placebo tests on {len(placebo_outcomes)} outcomes")

        # Estimate primary effect
        primary_est = self.estimator_fn(data)

        # Estimate placebo effects
        placebo_estimates = []
        for outcome in placebo_outcomes:
            # Temporarily swap outcome column
            data_placebo = data.copy()
            # This assumes estimator_fn can handle outcome column
            # In practice, need to make this more flexible
            placebo_est = self.estimator_fn(data_placebo)
            placebo_estimates.append(placebo_est)

        # Calculate proportion larger in magnitude
        placebo_mags = [abs(est.estimate) for est in placebo_estimates]
        primary_mag = abs(primary_est.estimate)
        proportion_larger = np.mean(np.array(placebo_mags) >= primary_mag)

        # Permutation p-value
        p_value = (1 + np.sum(np.array(placebo_mags) >= primary_mag)) / (1 + len(placebo_mags))

        return PlaceboTestResult(
            placebo_estimates=placebo_estimates,
            primary_estimate=primary_est,
            proportion_larger=proportion_larger,
            p_value=p_value,
        )

    def run_permutation_test(self, data: pd.DataFrame, treatment_col: str) -> PlaceboTestResult:
        """
        Permutation test by randomizing treatment assignment.

        Parameters
        ----------
        data : pd.DataFrame
            Input data
        treatment_col : str
            Column name of treatment variable

        Returns
        -------
        PlaceboTestResult
            Permutation test results
        """
        logger.info(f"Running permutation test with {self.n_permutations} perms")

        # Original estimate
        primary_est = self.estimator_fn(data)

        # Permutation estimates
        placebo_estimates = []
        for i in range(self.n_permutations):
            data_perm = data.copy()
            data_perm[treatment_col] = np.random.permutation(data[treatment_col].values)
            try:
                perm_est = self.estimator_fn(data_perm)
                placebo_estimates.append(perm_est)
            except Exception as e:
                logger.debug(f"Permutation {i} failed: {e}")

        # Calculate p-value
        placebo_ests = [abs(est.estimate) for est in placebo_estimates]
        primary_mag = abs(primary_est.estimate)
        p_value = (1 + np.sum(np.array(placebo_ests) >= primary_mag)) / (1 + len(placebo_ests))
        proportion_larger = np.mean(np.array(placebo_ests) >= primary_mag)

        return PlaceboTestResult(
            placebo_estimates=placebo_estimates,
            primary_estimate=primary_est,
            proportion_larger=proportion_larger,
            p_value=p_value,
        )


class SensitivityAnalyzer:
    """
    Comprehensive sensitivity analysis toolkit.

    Combines multiple sensitivity analysis methods to assess robustness
    of causal inferences.

    Parameters
    ----------
    estimator_fn : Callable, optional
        Function that estimates treatment effect from data
    confidence_level : float, default=0.95
        Confidence level for inference

    Examples
    --------
    >>> from krl_policy.analysis import SensitivityAnalyzer
    >>>
    >>> analyzer = SensitivityAnalyzer(estimator_fn=my_estimator)
    >>>
    >>> # Rosenbaum bounds
    >>> rb_result = analyzer.rosenbaum_bounds(treatment_effects)
    >>>
    >>> # E-values
    >>> ev_result = analyzer.e_value(estimate, ci_lower, ci_upper)
    >>>
    >>> # Specification curve
    >>> sc_result = analyzer.specification_curve(data, specs)
    """

    def __init__(self, estimator_fn: Optional[Callable] = None, confidence_level: float = 0.95):
        self.estimator_fn = estimator_fn
        self.confidence_level = confidence_level

        # Initialize sub-analyzers
        self.rosenbaum = RosenbaumBounds()
        self.evalue = EValue()

    def rosenbaum_bounds(self, treatment_effects: np.ndarray, **kwargs) -> RosenbaumBoundsResult:
        """Run Rosenbaum bounds analysis."""
        return self.rosenbaum.analyze(treatment_effects, **kwargs)

    def e_value(self, estimate: float, ci_lower: float, ci_upper: float, **kwargs) -> EValueResult:
        """Calculate E-values."""
        return self.evalue.calculate(estimate, ci_lower, ci_upper, **kwargs)

    def specification_curve(
        self,
        data: pd.DataFrame,
        specifications: List[Dict[str, Any]],
        estimator_fn: Optional[Callable] = None,
    ) -> SpecificationCurveResult:
        """Run specification curve analysis."""
        fn = estimator_fn or self.estimator_fn
        if fn is None:
            raise ValueError("Must provide estimator_fn")

        sc = SpecificationCurve(estimator_fn=fn)
        return sc.analyze(data, specifications)

    def placebo_test(
        self,
        data: pd.DataFrame,
        placebo_outcomes: Optional[List[str]] = None,
        treatment_col: Optional[str] = None,
        estimator_fn: Optional[Callable] = None,
        **kwargs,
    ) -> PlaceboTestResult:
        """Run placebo tests."""
        fn = estimator_fn or self.estimator_fn
        if fn is None:
            raise ValueError("Must provide estimator_fn")

        pt = PlaceboTest(estimator_fn=fn)

        if placebo_outcomes is not None:
            return pt.run_placebo_outcomes(data, placebo_outcomes, **kwargs)
        elif treatment_col is not None:
            return pt.run_permutation_test(data, treatment_col)
        else:
            raise ValueError("Must provide either placebo_outcomes or treatment_col")


__all__ = [
    "SensitivityAnalyzer",
    "RosenbaumBounds",
    "RosenbaumBoundsResult",
    "EValue",
    "EValueResult",
    "SpecificationCurve",
    "SpecificationCurveResult",
    "PlaceboTest",
    "PlaceboTestResult",
]
