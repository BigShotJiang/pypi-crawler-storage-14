# ----------------------------------------------------------------------
# © 2025 KR-Labs. All rights reserved.
# KR-Labs™ is a trademark of Quipu Research Labs, LLC,
# a subsidiary of Sudiata Giddasira, Inc.
# ----------------------------------------------------------------------
# SPDX-License-Identifier: Apache-2.0

"""
Unified Policy Evaluator Interface.

High-level interface for comprehensive policy evaluation workflows.
Orchestrates method selection, estimation, diagnostics, and reporting.
"""

from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional, Tuple, Type, Union

import numpy as np
import pandas as pd
from scipy import stats

from ..core.base import (
    BasePolicyEstimator,
    CausalEstimate,
    DiagnosticResult,
    EffectType,
    EstimationError,
    EstimationMethod,
    PolicyConfig,
    TreatmentEffectResult,
)
from ..estimators import (
    CovariateMatching,
    DifferenceInDifferences,
    InstrumentalVariables,
    PropensityScoreMatching,
    SyntheticControlMethod,
    TreatmentEffectEstimator,
)
from ..estimators.rdd import RegressionDiscontinuity

# Import logger
try:
    from krl_core import get_logger
except ImportError:
    import logging

    def get_logger(name: str):
        return logging.getLogger(name)


logger = get_logger(__name__)


# =============================================================================
# Enums
# =============================================================================


class PolicyMethod(Enum):
    """Available policy evaluation methods."""

    DIFFERENCE_IN_MEANS = "difference_in_means"
    REGRESSION_ADJUSTMENT = "regression_adjustment"
    IPW = "ipw"
    DOUBLY_ROBUST = "doubly_robust"
    DIFFERENCE_IN_DIFFERENCES = "did"
    SYNTHETIC_CONTROL = "synthetic_control"
    PROPENSITY_MATCHING = "psm"
    COVARIATE_MATCHING = "covariate_matching"
    INSTRUMENTAL_VARIABLES = "iv"
    REGRESSION_DISCONTINUITY = "rdd"


# =============================================================================
# Result Classes
# =============================================================================


@dataclass
class MethodComparison:
    """
    Comparison of multiple estimation methods.

    Attributes
    ----------
    methods : List[str]
        Methods compared
    estimates : Dict[str, CausalEstimate]
        Estimates from each method
    mean_estimate : float
        Mean across methods
    std_estimate : float
        Standard deviation across methods
    min_estimate : float
        Minimum estimate
    max_estimate : float
        Maximum estimate
    """

    methods: List[str]
    estimates: Dict[str, CausalEstimate]
    mean_estimate: float
    std_estimate: float
    min_estimate: float
    max_estimate: float


@dataclass
class AssumptionReport:
    """
    Report on causal identification assumptions.

    Attributes
    ----------
    method : str
        Estimation method
    assumptions : Dict[str, Dict[str, Any]]
        Assumption tests and results
    all_passed : bool
        Whether all testable assumptions passed
    warnings : List[str]
        Warnings about untestable assumptions
    """

    method: str
    assumptions: Dict[str, Dict[str, Any]] = field(default_factory=dict)
    all_passed: bool = True
    warnings: List[str] = field(default_factory=list)


@dataclass
class PolicyEvaluationResult:
    """
    Complete policy evaluation result.

    Attributes
    ----------
    primary_estimate : CausalEstimate
        Main treatment effect estimate
    method : str
        Primary method used
    comparison : Optional[MethodComparison]
        Multi-method comparison
    assumption_report : AssumptionReport
        Assumption validation results
    diagnostics : DiagnosticResult
        Detailed diagnostics
    """

    primary_estimate: CausalEstimate
    method: str
    comparison: Optional[MethodComparison] = None
    assumption_report: Optional[AssumptionReport] = None
    diagnostics: DiagnosticResult = field(default_factory=DiagnosticResult)


# =============================================================================
# PolicyEvaluator
# =============================================================================


class PolicyEvaluator:
    """
    Unified interface for policy evaluation.

    Orchestrates data preparation, method selection, estimation,
    diagnostics, and reporting for causal policy analysis.

    Parameters
    ----------
    method : Union[str, PolicyMethod, BasePolicyEstimator]
        Primary estimation method or custom estimator
    treatment_col : str
        Treatment/intervention column name
    outcome_col : str
        Outcome variable column name
    covariates : Optional[List[str]]
        Covariate columns
    confidence_level : float
        Confidence level for intervals
    config : Optional[PolicyConfig]
        Configuration object
    compare_methods : Optional[List[str]]
        Additional methods to run for comparison
    validate_assumptions : bool
        Whether to run assumption tests
    **method_kwargs
        Additional arguments passed to estimator

    Examples
    --------
    >>> # Basic evaluation with single method
    >>> evaluator = PolicyEvaluator(
    ...     method='regression',
    ...     treatment_col='treated',
    ...     outcome_col='outcome',
    ...     covariates=['age', 'income']
    ... )
    >>> result = evaluator.evaluate(data)
    >>> print(f"ATE: {result.primary_estimate.estimate:.3f}")

    >>> # Multi-method comparison
    >>> evaluator = PolicyEvaluator(
    ...     method='did',
    ...     treatment_col='treated',
    ...     outcome_col='outcome',
    ...     time_col='year',
    ...     unit_col='state',
    ...     compare_methods=['synthetic_control'],
    ...     validate_assumptions=True
    ... )
    >>> result = evaluator.evaluate(data)
    >>> print(result.comparison.mean_estimate)
    """

    def __init__(
        self,
        method: Union[str, PolicyMethod, BasePolicyEstimator],
        treatment_col: str,
        outcome_col: str,
        covariates: Optional[List[str]] = None,
        confidence_level: float = 0.95,
        config: Optional[PolicyConfig] = None,
        compare_methods: Optional[List[Union[str, PolicyMethod]]] = None,
        validate_assumptions: bool = True,
        **method_kwargs,
    ):
        self.treatment_col = treatment_col
        self.outcome_col = outcome_col
        self.covariates = covariates or []
        self.confidence_level = confidence_level
        self.config = config or PolicyConfig()
        self.compare_methods = compare_methods or []
        self.validate_assumptions = validate_assumptions
        self.method_kwargs = method_kwargs

        # Initialize primary estimator
        if isinstance(method, BasePolicyEstimator):
            self.primary_estimator = method
            self.method_name = type(method).__name__
        else:
            if isinstance(method, str):
                method = PolicyMethod(method.lower())
            self.method_name = method.value
            self.primary_estimator = self._create_estimator(method, **method_kwargs)

        # Results
        self._result: Optional[PolicyEvaluationResult] = None
        self._data: Optional[pd.DataFrame] = None

    def _create_estimator(self, method: Union[str, PolicyMethod], **kwargs) -> BasePolicyEstimator:
        """Create estimator instance from method name."""
        if isinstance(method, str):
            method = PolicyMethod(method.lower())

        # Merge default config with kwargs
        estimator_kwargs = {
            "treatment_col": self.treatment_col,
            "outcome_col": self.outcome_col,
            "covariates": self.covariates,
            "confidence_level": self.confidence_level,
            "config": self.config,
            **kwargs,
        }

        if method == PolicyMethod.DIFFERENCE_IN_MEANS:
            return TreatmentEffectEstimator(method="difference_in_means", **estimator_kwargs)
        elif method == PolicyMethod.REGRESSION_ADJUSTMENT:
            return TreatmentEffectEstimator(method="regression_adjustment", **estimator_kwargs)
        elif method == PolicyMethod.IPW:
            return TreatmentEffectEstimator(method="ipw", **estimator_kwargs)
        elif method == PolicyMethod.DOUBLY_ROBUST:
            return TreatmentEffectEstimator(method="doubly_robust", **estimator_kwargs)
        elif method == PolicyMethod.DIFFERENCE_IN_DIFFERENCES:
            # Remove kwargs not needed for DiD
            did_kwargs = {
                k: v for k, v in estimator_kwargs.items() if k not in ["method", "config"]
            }
            return DifferenceInDifferences(**did_kwargs)
        elif method == PolicyMethod.SYNTHETIC_CONTROL:
            sc_kwargs = {k: v for k, v in estimator_kwargs.items() if k not in ["method"]}
            return SyntheticControlMethod(**sc_kwargs)
        elif method == PolicyMethod.PROPENSITY_MATCHING:
            psm_kwargs = {k: v for k, v in estimator_kwargs.items() if k not in ["method"]}
            return PropensityScoreMatching(**psm_kwargs)
        elif method == PolicyMethod.COVARIATE_MATCHING:
            cm_kwargs = {k: v for k, v in estimator_kwargs.items() if k not in ["method"]}
            return CovariateMatching(**cm_kwargs)
        elif method == PolicyMethod.INSTRUMENTAL_VARIABLES:
            iv_kwargs = {k: v for k, v in estimator_kwargs.items() if k not in ["method"]}
            return InstrumentalVariables(**iv_kwargs)
        elif method == PolicyMethod.REGRESSION_DISCONTINUITY:
            rdd_kwargs = {k: v for k, v in estimator_kwargs.items() if k not in ["method"]}
            return RegressionDiscontinuity(**rdd_kwargs)
        else:
            raise ValueError(f"Unknown method: {method}")

    def _validate_assumptions_for_method(
        self, method_name: str, estimator: BasePolicyEstimator, data: pd.DataFrame
    ) -> AssumptionReport:
        """Run assumption validation tests for a method."""
        assumptions = {}
        warnings = []
        all_passed = True

        # Common assumptions
        if method_name in ["regression", "ipw", "doubly_robust"]:
            # Overlap assumption (common support)
            if hasattr(estimator, "get_propensity_scores"):
                try:
                    ps = estimator.get_propensity_scores()
                    treated_ps = ps[data[self.treatment_col] == 1]
                    control_ps = ps[data[self.treatment_col] == 0]

                    # Check for extreme propensity scores
                    extreme_low = (ps < 0.1).sum()
                    extreme_high = (ps > 0.9).sum()

                    assumptions["overlap"] = {
                        "tested": True,
                        "passed": extreme_low < len(ps) * 0.05 and extreme_high < len(ps) * 0.05,
                        "treated_range": (treated_ps.min(), treated_ps.max()),
                        "control_range": (control_ps.min(), control_ps.max()),
                        "extreme_low": extreme_low,
                        "extreme_high": extreme_high,
                    }

                    if not assumptions["overlap"]["passed"]:
                        all_passed = False
                        warnings.append("Weak overlap: many extreme propensity scores")
                except:
                    assumptions["overlap"] = {"tested": False}
                    warnings.append("Could not test overlap assumption")

        # DiD-specific assumptions
        if method_name == "did" or isinstance(estimator, DifferenceInDifferences):
            # Parallel trends test
            if hasattr(estimator, "test_parallel_trends"):
                try:
                    pt_result = estimator.test_parallel_trends()
                    assumptions["parallel_trends"] = {
                        "tested": True,
                        "passed": (
                            pt_result.passed
                            if hasattr(pt_result, "passed")
                            else pt_result.get("passed", True)
                        ),
                        "p_value": (
                            pt_result.p_value
                            if hasattr(pt_result, "p_value")
                            else pt_result.get("p_value")
                        ),
                    }
                    if not assumptions["parallel_trends"]["passed"]:
                        all_passed = False
                        warnings.append("Parallel trends assumption may be violated")
                except:
                    assumptions["parallel_trends"] = {"tested": False}
                    warnings.append("Could not test parallel trends")
            else:
                warnings.append("Parallel trends assumption not testable (untestable)")

        # IV-specific assumptions
        if method_name == "iv" or isinstance(estimator, InstrumentalVariables):
            # Instrument relevance
            if hasattr(estimator, "_result") and estimator._result:
                result = estimator._result
                if hasattr(result, "diagnostics") and result.diagnostics:
                    diag = result.diagnostics
                    if hasattr(diag, "first_stage_f"):
                        assumptions["instrument_relevance"] = {
                            "tested": True,
                            "passed": diag.first_stage_f > 10,
                            "f_statistic": diag.first_stage_f,
                        }
                        if not assumptions["instrument_relevance"]["passed"]:
                            all_passed = False
                            warnings.append("Weak instruments detected (F < 10)")

            # Overidentification
            if hasattr(estimator, "_result") and estimator._result:
                result = estimator._result
                if hasattr(result, "diagnostics") and result.diagnostics:
                    diag = result.diagnostics
                    if hasattr(diag, "sargan_p_value"):
                        assumptions["overidentification"] = {
                            "tested": True,
                            "passed": diag.sargan_p_value > 0.05,
                            "p_value": diag.sargan_p_value,
                        }
                        if not assumptions["overidentification"]["passed"]:
                            all_passed = False
                            warnings.append("Overidentification test failed")

        # RDD-specific assumptions
        if method_name == "rdd" or isinstance(estimator, RegressionDiscontinuity):
            # Manipulation test
            if hasattr(estimator, "manipulation_test"):
                try:
                    manip = estimator.manipulation_test()
                    assumptions["no_manipulation"] = {
                        "tested": True,
                        "passed": manip.passed,
                        "p_value": manip.p_value,
                    }
                    if not assumptions["no_manipulation"]["passed"]:
                        all_passed = False
                        warnings.append("Evidence of manipulation at cutoff")
                except:
                    assumptions["no_manipulation"] = {"tested": False}
                    warnings.append("Could not test for manipulation")

            warnings.append("Continuity assumption not directly testable")

        return AssumptionReport(
            method=method_name,
            assumptions=assumptions,
            all_passed=all_passed,
            warnings=warnings,
        )

    def _compare_methods(
        self, data: pd.DataFrame, primary_estimate: CausalEstimate
    ) -> Optional[MethodComparison]:
        """Run and compare multiple estimation methods."""
        if not self.compare_methods:
            return None

        estimates = {self.method_name: primary_estimate}

        for method in self.compare_methods:
            try:
                estimator = self._create_estimator(method, **self.method_kwargs)
                result = estimator.fit(data)

                # Extract ATE
                if hasattr(result, "ate"):
                    ate = result.ate
                elif isinstance(result, TreatmentEffectResult):
                    ate = result.ate
                else:
                    ate = estimator.estimate_ate()

                estimates[method if isinstance(method, str) else method.value] = ate

            except Exception as e:
                logger.warning(f"Failed to run comparison method {method}: {e}")
                continue

        if len(estimates) < 2:
            return None

        # Calculate summary statistics
        estimate_values = [e.estimate for e in estimates.values()]

        return MethodComparison(
            methods=list(estimates.keys()),
            estimates=estimates,
            mean_estimate=float(np.mean(estimate_values)),
            std_estimate=float(np.std(estimate_values)),
            min_estimate=float(np.min(estimate_values)),
            max_estimate=float(np.max(estimate_values)),
        )

    def evaluate(self, data: pd.DataFrame) -> PolicyEvaluationResult:
        """
        Run complete policy evaluation.

        Parameters
        ----------
        data : pd.DataFrame
            Input data

        Returns
        -------
        PolicyEvaluationResult
            Comprehensive evaluation results
        """
        self._data = data.copy()

        logger.info(f"Running policy evaluation with method: {self.method_name}")

        # Fit primary estimator
        result = self.primary_estimator.fit(data)

        # Extract primary estimate
        if hasattr(result, "ate"):
            primary_estimate = result.ate
        elif isinstance(result, TreatmentEffectResult):
            primary_estimate = result.ate
        else:
            primary_estimate = self.primary_estimator.estimate_ate()

        # Get diagnostics
        if hasattr(result, "diagnostics"):
            diagnostics = result.diagnostics
        elif hasattr(self.primary_estimator, "get_diagnostics"):
            diagnostics = self.primary_estimator.get_diagnostics()
        else:
            diagnostics = DiagnosticResult()

        # Assumption validation
        assumption_report = None
        if self.validate_assumptions:
            assumption_report = self._validate_assumptions_for_method(
                self.method_name, self.primary_estimator, data
            )

        # Method comparison
        comparison = None
        if self.compare_methods:
            comparison = self._compare_methods(data, primary_estimate)

        self._result = PolicyEvaluationResult(
            primary_estimate=primary_estimate,
            method=self.method_name,
            comparison=comparison,
            assumption_report=assumption_report,
            diagnostics=diagnostics,
        )

        return self._result

    def sensitivity_to_unobserved_confounding(
        self, r2_range: Tuple[float, float] = (0.0, 0.5), n_points: int = 11
    ) -> Dict[float, CausalEstimate]:
        """
        Sensitivity analysis for unobserved confounding.

        Varies the assumed strength of confounding (R²) and shows
        impact on estimates.

        Parameters
        ----------
        r2_range : Tuple[float, float]
            Range of R² values to consider
        n_points : int
            Number of points to evaluate

        Returns
        -------
        Dict[float, CausalEstimate]
            Estimates at each R² level
        """
        # This is a simplified placeholder
        # Full implementation would use methods like Rosenbaum bounds
        logger.warning("Sensitivity analysis is a simplified implementation")

        if self._result is None:
            raise EstimationError("Must run evaluate() first")

        base_estimate = self._result.primary_estimate.estimate
        base_se = self._result.primary_estimate.std_error

        r2_values = np.linspace(r2_range[0], r2_range[1], n_points)
        results = {}

        for r2 in r2_values:
            # Adjust estimate based on confounding strength
            # This is a rough approximation
            adjustment = base_estimate * r2 * 1.5
            adjusted_estimate = base_estimate - adjustment
            adjusted_se = base_se * (1 + r2)

            z = 1.96  # 95% CI
            ci = (adjusted_estimate - z * adjusted_se, adjusted_estimate + z * adjusted_se)

            results[r2] = CausalEstimate(
                estimate=adjusted_estimate,
                std_error=adjusted_se,
                ci_lower=ci[0],
                ci_upper=ci[1],
                p_value=2 * (1 - stats.norm.cdf(abs(adjusted_estimate / adjusted_se))),
                effect_type=EffectType.ATE,
            )

        return results

    def get_result(self) -> PolicyEvaluationResult:
        """Get evaluation result."""
        if self._result is None:
            raise EstimationError("Must run evaluate() first")
        return self._result

    def summary(self) -> str:
        """Generate text summary of evaluation."""
        if self._result is None:
            return "No evaluation run yet."

        result = self._result
        lines = [
            "=" * 70,
            "Policy Evaluation Summary",
            "=" * 70,
            f"Primary Method: {result.method.upper()}",
            "",
            "Treatment Effect:",
            f"  Estimate: {result.primary_estimate.estimate:.4f}",
            f"  Std. Error: {result.primary_estimate.std_error:.4f}",
            f"  95% CI: [{result.primary_estimate.confidence_interval[0]:.4f}, {result.primary_estimate.confidence_interval[1]:.4f}]",
            f"  P-value: {result.primary_estimate.p_value:.4f}",
            f"  Significant: {'Yes' if result.primary_estimate.p_value < 0.05 else 'No'}",
        ]

        if result.comparison:
            lines.extend(
                [
                    "",
                    "Method Comparison:",
                    f"  Methods: {', '.join(result.comparison.methods)}",
                    f"  Mean Estimate: {result.comparison.mean_estimate:.4f}",
                    f"  Std. Deviation: {result.comparison.std_estimate:.4f}",
                    f"  Range: [{result.comparison.min_estimate:.4f}, {result.comparison.max_estimate:.4f}]",
                ]
            )

        if result.assumption_report:
            lines.extend(
                [
                    "",
                    "Assumption Validation:",
                    f"  All Passed: {'Yes' if result.assumption_report.all_passed else 'No'}",
                    f"  Tests Run: {len(result.assumption_report.assumptions)}",
                ]
            )
            if result.assumption_report.warnings:
                lines.append("  Warnings:")
                for w in result.assumption_report.warnings:
                    lines.append(f"    - {w}")

        lines.append("=" * 70)

        return "\n".join(lines)

    def to_dict(self) -> Dict[str, Any]:
        """Export results to dictionary."""
        if self._result is None:
            raise EstimationError("Must run evaluate() first")

        result = self._result

        output = {
            "method": result.method,
            "estimate": result.primary_estimate.estimate,
            "std_error": result.primary_estimate.std_error,
            "confidence_interval": result.primary_estimate.confidence_interval,
            "p_value": result.primary_estimate.p_value,
        }

        if result.comparison:
            output["comparison"] = {
                "methods": result.comparison.methods,
                "mean_estimate": result.comparison.mean_estimate,
                "std_estimate": result.comparison.std_estimate,
            }

        if result.assumption_report:
            output["assumptions"] = {
                "all_passed": result.assumption_report.all_passed,
                "warnings": result.assumption_report.warnings,
            }

        return output
