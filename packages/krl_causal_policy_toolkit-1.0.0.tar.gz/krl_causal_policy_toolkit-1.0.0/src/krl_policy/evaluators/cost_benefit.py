# ----------------------------------------------------------------------
# © 2025 KR-Labs. All rights reserved.
# KR-Labs™ is a trademark of Quipu Research Labs, LLC,
# a subsidiary of Sudiata Giddasira, Inc.
# ----------------------------------------------------------------------
# SPDX-License-Identifier: Apache-2.0

"""
Cost-Benefit Analyzer for Policy Evaluation.

This module provides tools for comprehensive cost-benefit analysis:
- Net Present Value (NPV) calculation
- Benefit-Cost Ratio (BCR)
- Internal Rate of Return (IRR)
- Monte Carlo sensitivity analysis
- Distributional impact analysis

References
----------
Boardman, A. E., et al. (2018). Cost-Benefit Analysis: Concepts and Practice.
    Cambridge University Press.
Weimer, D. L., & Vining, A. R. (2017). Policy Analysis: Concepts and Practice.
    Routledge.
"""

from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Callable, Dict, List, Optional, Tuple, Union

import numpy as np
import pandas as pd
from scipy import stats
from scipy.optimize import brentq

# Import logger
try:
    from krl_core import get_logger
except ImportError:
    import logging

    def get_logger(name: str):
        return logging.getLogger(name)


logger = get_logger(__name__)


# =============================================================================
# Enums and Types
# =============================================================================


class DiscountRate(Enum):
    """Standard discount rate approaches."""

    SOCIAL = "social"  # Social discount rate (typically 3-7%)
    MARKET = "market"  # Market rate of return
    SHADOW = "shadow"  # Shadow price of capital
    CUSTOM = "custom"  # User-specified


class DistributionType(Enum):
    """Distribution types for uncertainty modeling."""

    NORMAL = "normal"
    LOGNORMAL = "lognormal"
    UNIFORM = "uniform"
    TRIANGULAR = "triangular"
    BETA = "beta"
    POINT = "point"  # No uncertainty (deterministic)


# =============================================================================
# Data Classes
# =============================================================================


@dataclass
class CashFlow:
    """
    Represents a cash flow (cost or benefit) in the analysis.

    Attributes
    ----------
    name : str
        Name/label for this cash flow
    amount : float
        Expected value of the cash flow
    year : int
        Year when cash flow occurs (0 = present)
    is_benefit : bool
        True if benefit, False if cost
    distribution : DistributionType
        Distribution for uncertainty analysis
    distribution_params : Dict[str, float]
        Parameters for the distribution
    group : Optional[str]
        Group/stakeholder affected by this cash flow
    """

    name: str
    amount: float
    year: int
    is_benefit: bool = True
    distribution: DistributionType = DistributionType.POINT
    distribution_params: Dict[str, float] = field(default_factory=dict)
    group: Optional[str] = None

    def sample(self, n_samples: int = 1) -> np.ndarray:
        """Draw random samples from the distribution."""
        if self.distribution == DistributionType.POINT:
            return np.full(n_samples, self.amount)

        elif self.distribution == DistributionType.NORMAL:
            std = self.distribution_params.get("std", abs(self.amount) * 0.1)
            return np.random.normal(self.amount, std, n_samples)

        elif self.distribution == DistributionType.LOGNORMAL:
            # Parameterize so mean = amount
            cv = self.distribution_params.get("cv", 0.2)  # Coefficient of variation
            sigma = np.sqrt(np.log(1 + cv**2))
            mu = np.log(abs(self.amount)) - sigma**2 / 2
            sign = np.sign(self.amount) if self.amount != 0 else 1
            return sign * np.random.lognormal(mu, sigma, n_samples)

        elif self.distribution == DistributionType.UNIFORM:
            low = self.distribution_params.get("low", self.amount * 0.8)
            high = self.distribution_params.get("high", self.amount * 1.2)
            return np.random.uniform(low, high, n_samples)

        elif self.distribution == DistributionType.TRIANGULAR:
            low = self.distribution_params.get("low", self.amount * 0.7)
            mode = self.distribution_params.get("mode", self.amount)
            high = self.distribution_params.get("high", self.amount * 1.3)
            return np.random.triangular(low, mode, high, n_samples)

        elif self.distribution == DistributionType.BETA:
            a = self.distribution_params.get("a", 2)
            b = self.distribution_params.get("b", 2)
            low = self.distribution_params.get("low", self.amount * 0.5)
            high = self.distribution_params.get("high", self.amount * 1.5)
            samples = np.random.beta(a, b, n_samples)
            return low + samples * (high - low)

        else:
            return np.full(n_samples, self.amount)


@dataclass
class CostBenefitResult:
    """
    Result from cost-benefit analysis.

    Attributes
    ----------
    npv : float
        Net Present Value
    bcr : float
        Benefit-Cost Ratio
    irr : Optional[float]
        Internal Rate of Return (if calculable)
    total_benefits : float
        Present value of all benefits
    total_costs : float
        Present value of all costs
    discount_rate : float
        Discount rate used
    time_horizon : int
        Time horizon in years
    cash_flows : List[Dict]
        Detailed cash flow breakdown
    """

    npv: float
    bcr: float
    irr: Optional[float]
    total_benefits: float
    total_costs: float
    discount_rate: float
    time_horizon: int
    cash_flows: List[Dict[str, Any]] = field(default_factory=list)

    @property
    def is_cost_effective(self) -> bool:
        """Whether policy passes cost-effectiveness threshold (NPV > 0)."""
        return self.npv > 0

    @property
    def payback_period(self) -> Optional[int]:
        """Simple payback period (years until cumulative NPV > 0)."""
        cumulative = 0.0
        for cf in self.cash_flows:
            cumulative += cf.get("pv", 0)
            if cumulative > 0:
                return cf.get("year", 0)
        return None


@dataclass
class SensitivityResult:
    """
    Result from sensitivity analysis.

    Attributes
    ----------
    parameter : str
        Parameter being varied
    base_value : float
        Base case value
    values : List[float]
        Parameter values tested
    npv_values : List[float]
        NPV at each parameter value
    bcr_values : List[float]
        BCR at each parameter value
    threshold : Optional[float]
        Threshold value where NPV = 0
    elasticity : float
        Elasticity of NPV to parameter
    """

    parameter: str
    base_value: float
    values: List[float]
    npv_values: List[float]
    bcr_values: List[float]
    threshold: Optional[float] = None
    elasticity: float = 0.0


@dataclass
class MonteCarloResult:
    """
    Result from Monte Carlo simulation.

    Attributes
    ----------
    npv_distribution : np.ndarray
        Distribution of NPV values
    bcr_distribution : np.ndarray
        Distribution of BCR values
    mean_npv : float
        Mean NPV
    std_npv : float
        Standard deviation of NPV
    prob_positive_npv : float
        Probability that NPV > 0
    confidence_interval : Tuple[float, float]
        Confidence interval for NPV
    var_5 : float
        5% Value at Risk (5th percentile of NPV)
    n_simulations : int
        Number of simulations run
    """

    npv_distribution: np.ndarray
    bcr_distribution: np.ndarray
    mean_npv: float
    std_npv: float
    prob_positive_npv: float
    confidence_interval: Tuple[float, float]
    var_5: float
    n_simulations: int


@dataclass
class DistributionalResult:
    """
    Result from distributional analysis.

    Attributes
    ----------
    group_impacts : Dict[str, float]
        Net impact by stakeholder group
    gini_before : Optional[float]
        Gini coefficient before policy
    gini_after : Optional[float]
        Gini coefficient after policy
    winners : List[str]
        Groups that benefit
    losers : List[str]
        Groups that lose
    """

    group_impacts: Dict[str, float]
    gini_before: Optional[float] = None
    gini_after: Optional[float] = None
    winners: List[str] = field(default_factory=list)
    losers: List[str] = field(default_factory=list)


# =============================================================================
# CostBenefitAnalyzer
# =============================================================================


class CostBenefitAnalyzer:
    """
    Comprehensive cost-benefit analysis for policy evaluation.

    Supports NPV, BCR, IRR calculations with uncertainty analysis
    through Monte Carlo simulation and sensitivity analysis.

    Parameters
    ----------
    discount_rate : float
        Annual discount rate (e.g., 0.03 for 3%)
    time_horizon : int
        Analysis time horizon in years
    discount_type : Union[str, DiscountRate]
        Type of discount rate used
    confidence_level : float
        Confidence level for intervals

    Examples
    --------
    >>> # Basic cost-benefit analysis
    >>> cba = CostBenefitAnalyzer(discount_rate=0.03, time_horizon=10)
    >>>
    >>> # Add costs and benefits
    >>> cba.add_cost("Implementation", 1000000, year=0)
    >>> cba.add_cost("Operating", 50000, year=1, recurring=True)
    >>> cba.add_benefit("Revenue", 200000, year=1, recurring=True)
    >>>
    >>> # Run analysis
    >>> result = cba.analyze()
    >>> print(f"NPV: ${result.npv:,.2f}")
    >>> print(f"BCR: {result.bcr:.2f}")

    >>> # Monte Carlo simulation
    >>> mc_result = cba.monte_carlo_simulation(n_simulations=10000)
    >>> print(f"Probability of positive NPV: {mc_result.prob_positive_npv:.1%}")
    """

    def __init__(
        self,
        discount_rate: float = 0.03,
        time_horizon: int = 10,
        discount_type: Union[str, DiscountRate] = DiscountRate.SOCIAL,
        confidence_level: float = 0.95,
    ):
        if discount_rate < 0 or discount_rate > 1:
            raise ValueError("Discount rate must be between 0 and 1")
        if time_horizon < 1:
            raise ValueError("Time horizon must be at least 1 year")

        self.discount_rate = discount_rate
        self.time_horizon = time_horizon
        self.confidence_level = confidence_level

        if isinstance(discount_type, str):
            discount_type = DiscountRate(discount_type.lower())
        self.discount_type = discount_type

        # Cash flows
        self._cash_flows: List[CashFlow] = []
        self._result: Optional[CostBenefitResult] = None

    def add_cash_flow(self, cash_flow: CashFlow) -> None:
        """Add a cash flow to the analysis."""
        if cash_flow.year < 0:
            raise ValueError("Year cannot be negative")
        if cash_flow.year > self.time_horizon:
            logger.warning(
                f"Cash flow '{cash_flow.name}' occurs after time horizon "
                f"(year {cash_flow.year} > {self.time_horizon})"
            )
        self._cash_flows.append(cash_flow)

    def add_cost(
        self,
        name: str,
        amount: float,
        year: int = 0,
        recurring: bool = False,
        growth_rate: float = 0.0,
        distribution: Union[str, DistributionType] = DistributionType.POINT,
        distribution_params: Optional[Dict[str, float]] = None,
        group: Optional[str] = None,
    ) -> None:
        """
        Add a cost to the analysis.

        Parameters
        ----------
        name : str
            Name/label for this cost
        amount : float
            Cost amount (positive number)
        year : int
            Year when cost occurs
        recurring : bool
            If True, cost recurs annually from year to time_horizon
        growth_rate : float
            Annual growth rate for recurring costs
        distribution : Union[str, DistributionType]
            Distribution for uncertainty analysis
        distribution_params : Optional[Dict[str, float]]
            Distribution parameters
        group : Optional[str]
            Stakeholder group bearing this cost
        """
        amount = abs(amount)  # Costs stored as positive

        if isinstance(distribution, str):
            distribution = DistributionType(distribution.lower())

        if recurring:
            # Add cash flow for each year
            for y in range(year, self.time_horizon + 1):
                years_from_start = y - year
                adjusted_amount = amount * (1 + growth_rate) ** years_from_start

                cf = CashFlow(
                    name=f"{name} (Year {y})",
                    amount=adjusted_amount,
                    year=y,
                    is_benefit=False,
                    distribution=distribution,
                    distribution_params=distribution_params or {},
                    group=group,
                )
                self._cash_flows.append(cf)
        else:
            cf = CashFlow(
                name=name,
                amount=amount,
                year=year,
                is_benefit=False,
                distribution=distribution,
                distribution_params=distribution_params or {},
                group=group,
            )
            self._cash_flows.append(cf)

    def add_benefit(
        self,
        name: str,
        amount: float,
        year: int = 0,
        recurring: bool = False,
        growth_rate: float = 0.0,
        distribution: Union[str, DistributionType] = DistributionType.POINT,
        distribution_params: Optional[Dict[str, float]] = None,
        group: Optional[str] = None,
    ) -> None:
        """
        Add a benefit to the analysis.

        Parameters
        ----------
        name : str
            Name/label for this benefit
        amount : float
            Benefit amount (positive number)
        year : int
            Year when benefit occurs
        recurring : bool
            If True, benefit recurs annually from year to time_horizon
        growth_rate : float
            Annual growth rate for recurring benefits
        distribution : Union[str, DistributionType]
            Distribution for uncertainty analysis
        distribution_params : Optional[Dict[str, float]]
            Distribution parameters
        group : Optional[str]
            Stakeholder group receiving this benefit
        """
        amount = abs(amount)  # Benefits stored as positive

        if isinstance(distribution, str):
            distribution = DistributionType(distribution.lower())

        if recurring:
            for y in range(year, self.time_horizon + 1):
                years_from_start = y - year
                adjusted_amount = amount * (1 + growth_rate) ** years_from_start

                cf = CashFlow(
                    name=f"{name} (Year {y})",
                    amount=adjusted_amount,
                    year=y,
                    is_benefit=True,
                    distribution=distribution,
                    distribution_params=distribution_params or {},
                    group=group,
                )
                self._cash_flows.append(cf)
        else:
            cf = CashFlow(
                name=name,
                amount=amount,
                year=year,
                is_benefit=True,
                distribution=distribution,
                distribution_params=distribution_params or {},
                group=group,
            )
            self._cash_flows.append(cf)

    def _present_value(self, amount: float, year: int) -> float:
        """Calculate present value of a future amount."""
        return amount / (1 + self.discount_rate) ** year

    def _calculate_npv(
        self, cash_flows: Optional[List[CashFlow]] = None
    ) -> Tuple[float, float, float]:
        """
        Calculate NPV, total benefits, and total costs.

        Returns
        -------
        Tuple[float, float, float]
            (NPV, total_benefits_pv, total_costs_pv)
        """
        if cash_flows is None:
            cash_flows = self._cash_flows

        total_benefits = 0.0
        total_costs = 0.0

        for cf in cash_flows:
            pv = self._present_value(cf.amount, cf.year)

            if cf.is_benefit:
                total_benefits += pv
            else:
                total_costs += pv

        npv = total_benefits - total_costs

        return npv, total_benefits, total_costs

    def _calculate_irr(self) -> Optional[float]:
        """
        Calculate Internal Rate of Return.

        IRR is the discount rate at which NPV = 0.
        """
        # Build net cash flows by year
        net_by_year = {}
        for cf in self._cash_flows:
            year = cf.year
            amount = cf.amount if cf.is_benefit else -cf.amount
            net_by_year[year] = net_by_year.get(year, 0) + amount

        if not net_by_year:
            return None

        max_year = max(net_by_year.keys())
        cash_flow_series = [net_by_year.get(y, 0) for y in range(max_year + 1)]

        # Check if IRR is calculable (sign change required)
        signs = [np.sign(cf) for cf in cash_flow_series if cf != 0]
        if len(set(signs)) < 2:
            return None

        def npv_func(r):
            return sum(cf / (1 + r) ** t for t, cf in enumerate(cash_flow_series))

        try:
            # Find IRR using Brent's method
            irr = brentq(npv_func, -0.99, 10.0)
            return irr
        except (ValueError, RuntimeError):
            return None

    def analyze(self) -> CostBenefitResult:
        """
        Run the cost-benefit analysis.

        Returns
        -------
        CostBenefitResult
            Analysis results
        """
        if not self._cash_flows:
            raise ValueError("No cash flows added. Use add_cost() and add_benefit().")

        npv, total_benefits, total_costs = self._calculate_npv()

        # Benefit-cost ratio
        bcr = total_benefits / total_costs if total_costs > 0 else float("inf")

        # Internal rate of return
        irr = self._calculate_irr()

        # Detailed cash flows
        detailed_cf = []
        for cf in self._cash_flows:
            pv = self._present_value(cf.amount, cf.year)
            detailed_cf.append(
                {
                    "name": cf.name,
                    "year": cf.year,
                    "amount": cf.amount,
                    "pv": pv if cf.is_benefit else -pv,
                    "is_benefit": cf.is_benefit,
                    "group": cf.group,
                }
            )

        self._result = CostBenefitResult(
            npv=npv,
            bcr=bcr,
            irr=irr,
            total_benefits=total_benefits,
            total_costs=total_costs,
            discount_rate=self.discount_rate,
            time_horizon=self.time_horizon,
            cash_flows=detailed_cf,
        )

        return self._result

    def sensitivity_analysis(
        self,
        parameter: str,
        values: Optional[List[float]] = None,
        percentage_range: float = 0.5,
        n_values: int = 11,
    ) -> SensitivityResult:
        """
        One-way sensitivity analysis.

        Parameters
        ----------
        parameter : str
            Parameter to vary: 'discount_rate', 'benefit_<name>', 'cost_<name>'
        values : Optional[List[float]]
            Specific values to test
        percentage_range : float
            Range as percentage of base value (e.g., 0.5 = ±50%)
        n_values : int
            Number of values to test

        Returns
        -------
        SensitivityResult
            Sensitivity analysis results
        """
        # Get base value
        if parameter == "discount_rate":
            base_value = self.discount_rate
            if values is None:
                low = max(0.001, base_value * (1 - percentage_range))
                high = min(0.99, base_value * (1 + percentage_range))
                values = np.linspace(low, high, n_values).tolist()
        else:
            # Find matching cash flow
            cf_match = None
            for cf in self._cash_flows:
                if parameter.lower() in cf.name.lower():
                    cf_match = cf
                    break
            if cf_match is None:
                raise ValueError(f"Parameter not found: {parameter}")
            base_value = cf_match.amount
            if values is None:
                low = base_value * (1 - percentage_range)
                high = base_value * (1 + percentage_range)
                values = np.linspace(low, high, n_values).tolist()

        npv_values = []
        bcr_values = []

        for v in values:
            if parameter == "discount_rate":
                # Temporarily change discount rate
                original = self.discount_rate
                self.discount_rate = v
                npv, benefits, costs = self._calculate_npv()
                self.discount_rate = original
            else:
                # Create modified cash flows
                modified_cfs = []
                for cf in self._cash_flows:
                    if parameter.lower() in cf.name.lower():
                        new_cf = CashFlow(
                            name=cf.name,
                            amount=v,
                            year=cf.year,
                            is_benefit=cf.is_benefit,
                            distribution=cf.distribution,
                            distribution_params=cf.distribution_params,
                            group=cf.group,
                        )
                        modified_cfs.append(new_cf)
                    else:
                        modified_cfs.append(cf)
                npv, benefits, costs = self._calculate_npv(modified_cfs)

            npv_values.append(npv)
            bcr = benefits / costs if costs > 0 else float("inf")
            bcr_values.append(bcr)

        # Find threshold where NPV = 0
        threshold = None
        for i in range(len(values) - 1):
            if npv_values[i] * npv_values[i + 1] < 0:  # Sign change
                # Linear interpolation
                threshold = values[i] + (values[i + 1] - values[i]) * (
                    -npv_values[i] / (npv_values[i + 1] - npv_values[i])
                )
                break

        # Calculate elasticity (% change in NPV / % change in parameter)
        base_npv = npv_values[n_values // 2] if n_values % 2 == 1 else npv_values[0]
        if base_npv != 0 and base_value != 0:
            delta_npv = (npv_values[-1] - npv_values[0]) / abs(base_npv)
            delta_param = (values[-1] - values[0]) / abs(base_value)
            elasticity = delta_npv / delta_param if delta_param != 0 else 0.0
        else:
            elasticity = 0.0

        return SensitivityResult(
            parameter=parameter,
            base_value=base_value,
            values=values,
            npv_values=npv_values,
            bcr_values=bcr_values,
            threshold=threshold,
            elasticity=elasticity,
        )

    def tornado_analysis(
        self, parameters: Optional[List[str]] = None, percentage_range: float = 0.2
    ) -> List[SensitivityResult]:
        """
        Tornado diagram analysis.

        Varies each parameter by ±percentage_range and ranks by impact on NPV.

        Parameters
        ----------
        parameters : Optional[List[str]]
            Parameters to include (default: all cash flows)
        percentage_range : float
            Range to vary each parameter

        Returns
        -------
        List[SensitivityResult]
            Results sorted by impact magnitude
        """
        if parameters is None:
            parameters = ["discount_rate"] + [cf.name for cf in self._cash_flows]

        results = []

        for param in parameters:
            try:
                sens = self.sensitivity_analysis(
                    param, n_values=3, percentage_range=percentage_range  # Just low, base, high
                )
                results.append(sens)
            except ValueError:
                continue

        # Sort by impact (range of NPV values)
        results.sort(key=lambda r: max(r.npv_values) - min(r.npv_values), reverse=True)

        return results

    def monte_carlo_simulation(
        self, n_simulations: int = 10000, random_seed: Optional[int] = None
    ) -> MonteCarloResult:
        """
        Monte Carlo simulation for uncertainty analysis.

        Parameters
        ----------
        n_simulations : int
            Number of simulation iterations
        random_seed : Optional[int]
            Random seed for reproducibility

        Returns
        -------
        MonteCarloResult
            Simulation results
        """
        if random_seed is not None:
            np.random.seed(random_seed)

        npv_samples = np.zeros(n_simulations)
        bcr_samples = np.zeros(n_simulations)

        for i in range(n_simulations):
            # Sample each cash flow
            total_benefits = 0.0
            total_costs = 0.0

            for cf in self._cash_flows:
                sample = cf.sample(1)[0]
                pv = self._present_value(sample, cf.year)

                if cf.is_benefit:
                    total_benefits += pv
                else:
                    total_costs += pv

            npv_samples[i] = total_benefits - total_costs
            bcr_samples[i] = total_benefits / total_costs if total_costs > 0 else float("inf")

        # Calculate statistics
        mean_npv = np.mean(npv_samples)
        std_npv = np.std(npv_samples)
        prob_positive = np.mean(npv_samples > 0)

        alpha = 1 - self.confidence_level
        ci = (
            np.percentile(npv_samples, alpha / 2 * 100),
            np.percentile(npv_samples, (1 - alpha / 2) * 100),
        )

        var_5 = np.percentile(npv_samples, 5)

        return MonteCarloResult(
            npv_distribution=npv_samples,
            bcr_distribution=bcr_samples,
            mean_npv=mean_npv,
            std_npv=std_npv,
            prob_positive_npv=prob_positive,
            confidence_interval=ci,
            var_5=var_5,
            n_simulations=n_simulations,
        )

    def distributional_analysis(
        self, baseline_distribution: Optional[Dict[str, float]] = None
    ) -> DistributionalResult:
        """
        Analyze distributional impacts by stakeholder group.

        Parameters
        ----------
        baseline_distribution : Optional[Dict[str, float]]
            Baseline welfare distribution by group (for Gini calculation)

        Returns
        -------
        DistributionalResult
            Distributional analysis results
        """
        # Calculate net impact by group
        group_impacts: Dict[str, float] = {}

        for cf in self._cash_flows:
            group = cf.group or "Unspecified"
            pv = self._present_value(cf.amount, cf.year)

            if cf.is_benefit:
                group_impacts[group] = group_impacts.get(group, 0) + pv
            else:
                group_impacts[group] = group_impacts.get(group, 0) - pv

        # Identify winners and losers
        winners = [g for g, v in group_impacts.items() if v > 0]
        losers = [g for g, v in group_impacts.items() if v < 0]

        # Calculate Gini coefficients if baseline provided
        gini_before = None
        gini_after = None

        if baseline_distribution:
            gini_before = self._calculate_gini(list(baseline_distribution.values()))

            # After policy
            after_distribution = {
                g: baseline_distribution.get(g, 0) + group_impacts.get(g, 0)
                for g in set(baseline_distribution.keys()) | set(group_impacts.keys())
            }
            gini_after = self._calculate_gini(list(after_distribution.values()))

        return DistributionalResult(
            group_impacts=group_impacts,
            gini_before=gini_before,
            gini_after=gini_after,
            winners=winners,
            losers=losers,
        )

    def _calculate_gini(self, values: List[float]) -> float:
        """Calculate Gini coefficient."""
        values = np.array(values)
        values = values[values >= 0]  # Remove negative values

        if len(values) == 0:
            return 0.0

        sorted_values = np.sort(values)
        n = len(sorted_values)
        cumulative = np.cumsum(sorted_values)

        gini = (2 * np.sum((np.arange(1, n + 1) * sorted_values))) / (n * np.sum(sorted_values)) - (
            n + 1
        ) / n

        return max(0, min(1, gini))

    def break_even_analysis(self, parameter: str, direction: str = "find") -> Optional[float]:
        """
        Find break-even value for a parameter.

        Parameters
        ----------
        parameter : str
            Parameter to find break-even for
        direction : str
            'find' to find threshold, 'increase' or 'decrease' for direction

        Returns
        -------
        Optional[float]
            Break-even value or None if not found
        """
        sens = self.sensitivity_analysis(
            parameter, percentage_range=0.99, n_values=101  # Wide range
        )

        return sens.threshold

    def summary(self) -> str:
        """Generate text summary of cost-benefit analysis."""
        if self._result is None:
            self.analyze()

        result = self._result

        lines = [
            "=" * 60,
            "Cost-Benefit Analysis Results",
            "=" * 60,
            "",
            f"Time Horizon: {result.time_horizon} years",
            f"Discount Rate: {result.discount_rate:.1%}",
            "",
            "Key Metrics:",
            f"  Net Present Value (NPV): ${result.npv:,.2f}",
            f"  Benefit-Cost Ratio (BCR): {result.bcr:.2f}",
            (
                f"  Internal Rate of Return (IRR): {result.irr:.1%}"
                if result.irr
                else "  Internal Rate of Return (IRR): N/A"
            ),
            "",
            f"  Total Benefits (PV): ${result.total_benefits:,.2f}",
            f"  Total Costs (PV): ${result.total_costs:,.2f}",
            "",
            f"Cost-Effective: {'Yes' if result.is_cost_effective else 'No'}",
        ]

        if result.payback_period:
            lines.append(f"Payback Period: {result.payback_period} years")

        lines.append("=" * 60)

        return "\n".join(lines)

    def to_dataframe(self) -> pd.DataFrame:
        """Export cash flows to DataFrame."""
        if self._result is None:
            self.analyze()

        return pd.DataFrame(self._result.cash_flows)
