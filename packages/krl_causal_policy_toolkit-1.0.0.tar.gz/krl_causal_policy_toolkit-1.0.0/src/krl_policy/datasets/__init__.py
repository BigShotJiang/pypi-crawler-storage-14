# ----------------------------------------------------------------------
# © 2025 KR-Labs. All rights reserved.
# KR-Labs™ is a trademark of Quipu Research Labs, LLC,
# a subsidiary of Sudiata Giddasira, Inc.
# ----------------------------------------------------------------------
# SPDX-License-Identifier: Apache-2.0

"""
Datasets module for KRL Causal Policy Toolkit.

Provides synthetic data generators for testing and validating
causal inference methods.
"""

from krl_policy.datasets.synthetic import (  # Config; Base class; Generators; Factory functions
    ConfoundedObservationalGenerator,
    DataGeneratorConfig,
    HeterogeneousTreatmentEffectGenerator,
    PanelDataGenerator,
    PerfectRCTGenerator,
    RegressionDiscontinuityGenerator,
    SyntheticDataGenerator,
    make_confounded_data,
    make_panel_data,
    make_rct_data,
)

__all__ = [
    # Config
    "DataGeneratorConfig",
    # Base class
    "SyntheticDataGenerator",
    # Generators
    "PerfectRCTGenerator",
    "ConfoundedObservationalGenerator",
    "HeterogeneousTreatmentEffectGenerator",
    "PanelDataGenerator",
    "RegressionDiscontinuityGenerator",
    # Factory functions
    "make_rct_data",
    "make_confounded_data",
    "make_panel_data",
]
