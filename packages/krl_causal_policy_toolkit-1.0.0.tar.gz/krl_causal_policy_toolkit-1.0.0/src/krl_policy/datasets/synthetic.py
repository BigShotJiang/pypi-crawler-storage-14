# ----------------------------------------------------------------------
# © 2025 KR-Labs. All rights reserved.
# KR-Labs™ is a trademark of Quipu Research Labs, LLC,
# a subsidiary of Sudiata Giddasira, Inc.
# ----------------------------------------------------------------------
# SPDX-License-Identifier: Apache-2.0

"""
Synthetic datasets for testing causal inference methods.

This module provides dataset generators for validating treatment effect
estimators under various scenarios:
- Perfect RCT data
- Confounded observational data
- Panel/time-series data with staggered treatment
"""

from dataclasses import dataclass
from typing import Dict, List, Optional, Tuple, Union

import numpy as np
import pandas as pd


@dataclass
class DataGeneratorConfig:
    """Configuration for synthetic data generation."""

    n_samples: int = 1000
    n_features: int = 5
    true_ate: float = 2.0
    noise_std: float = 1.0
    treatment_probability: float = 0.5
    random_state: Optional[int] = None


class SyntheticDataGenerator:
    """
    Base class for synthetic causal data generation.

    Provides common functionality for generating treatment assignments,
    covariates, and outcomes.
    """

    def __init__(self, config: Optional[DataGeneratorConfig] = None):
        """
        Initialize generator.

        Parameters
        ----------
        config : DataGeneratorConfig, optional
            Configuration for data generation
        """
        self.config = config or DataGeneratorConfig()
        self.rng = np.random.default_rng(self.config.random_state)
        self._data: Optional[pd.DataFrame] = None
        self._true_effects: Optional[np.ndarray] = None

    def generate(self) -> pd.DataFrame:
        """Generate synthetic dataset. Must be implemented by subclasses."""
        raise NotImplementedError("Subclasses must implement generate()")

    @property
    def data(self) -> pd.DataFrame:
        """Get generated data."""
        if self._data is None:
            self._data = self.generate()
        return self._data

    @property
    def true_effects(self) -> np.ndarray:
        """Get true individual treatment effects."""
        if self._true_effects is None:
            raise ValueError("True effects not available for this generator")
        return self._true_effects

    @property
    def true_ate(self) -> float:
        """Get true average treatment effect."""
        return self.config.true_ate

    def _generate_covariates(self, n: int, k: int) -> np.ndarray:
        """Generate random covariates."""
        return self.rng.standard_normal((n, k))

    def _generate_noise(self, n: int) -> np.ndarray:
        """Generate outcome noise."""
        return self.rng.normal(0, self.config.noise_std, n)


class PerfectRCTGenerator(SyntheticDataGenerator):
    """
    Generate perfect randomized controlled trial data.

    Treatment is randomly assigned independent of covariates.
    True ATE is exactly as specified in config.

    Examples
    --------
    >>> gen = PerfectRCTGenerator(DataGeneratorConfig(n_samples=1000, true_ate=2.5))
    >>> data = gen.generate()
    >>> print(f"True ATE: {gen.true_ate}")
    """

    def generate(self) -> pd.DataFrame:
        """
        Generate perfect RCT dataset.

        Returns
        -------
        pd.DataFrame
            Dataset with columns:
            - X0, X1, ...: Covariates
            - T: Treatment indicator (0/1)
            - Y: Outcome
        """
        n = self.config.n_samples
        k = self.config.n_features

        # Generate covariates
        X = self._generate_covariates(n, k)

        # Random treatment assignment (perfect randomization)
        T = self.rng.binomial(1, self.config.treatment_probability, n)

        # Generate baseline outcome (function of covariates)
        # Y0 = X @ beta + epsilon
        beta = self.rng.standard_normal(k)
        Y0 = X @ beta + self._generate_noise(n)

        # Treatment effect is constant
        tau = self.config.true_ate
        self._true_effects = np.full(n, tau)

        # Observed outcome
        Y = Y0 + T * tau

        # Create DataFrame
        data = pd.DataFrame(X, columns=[f"X{i}" for i in range(k)])
        data["T"] = T
        data["Y"] = Y

        self._data = data
        return data


class ConfoundedObservationalGenerator(SyntheticDataGenerator):
    """
    Generate confounded observational data.

    Treatment assignment depends on covariates, creating selection bias.
    Naive comparisons will be biased; methods like IPW or matching needed.

    Parameters
    ----------
    confounding_strength : float
        Strength of confounding (0 = none, 1 = strong)

    Examples
    --------
    >>> gen = ConfoundedObservationalGenerator(
    ...     config=DataGeneratorConfig(n_samples=1000),
    ...     confounding_strength=0.5
    ... )
    >>> data = gen.generate()
    """

    def __init__(
        self, config: Optional[DataGeneratorConfig] = None, confounding_strength: float = 0.5
    ):
        super().__init__(config)
        self.confounding_strength = confounding_strength

    def generate(self) -> pd.DataFrame:
        """
        Generate confounded observational dataset.

        Returns
        -------
        pd.DataFrame
            Dataset with confounded treatment assignment
        """
        n = self.config.n_samples
        k = self.config.n_features

        # Generate covariates
        X = self._generate_covariates(n, k)

        # Confounded treatment assignment
        # P(T=1|X) = sigmoid(gamma * X @ alpha)
        alpha = self.rng.standard_normal(k)
        propensity_score = self._sigmoid(self.confounding_strength * X @ alpha)
        T = self.rng.binomial(1, propensity_score)

        # Baseline outcome depends on confounders
        beta = self.rng.standard_normal(k)
        Y0 = X @ beta + self._generate_noise(n)

        # Treatment effect (can be heterogeneous)
        tau = self.config.true_ate
        self._true_effects = np.full(n, tau)

        # Observed outcome
        Y = Y0 + T * tau

        # Create DataFrame
        data = pd.DataFrame(X, columns=[f"X{i}" for i in range(k)])
        data["T"] = T
        data["Y"] = Y
        data["propensity_score_true"] = propensity_score

        self._data = data
        return data

    def _sigmoid(self, x: np.ndarray) -> np.ndarray:
        """Sigmoid function."""
        return 1 / (1 + np.exp(-x))


class HeterogeneousTreatmentEffectGenerator(SyntheticDataGenerator):
    """
    Generate data with heterogeneous treatment effects.

    Treatment effects vary by individual characteristics.
    Useful for testing CATE (conditional average treatment effect) estimators.

    Parameters
    ----------
    effect_heterogeneity : float
        Standard deviation of individual treatment effects around ATE

    Examples
    --------
    >>> gen = HeterogeneousTreatmentEffectGenerator(
    ...     config=DataGeneratorConfig(true_ate=2.0),
    ...     effect_heterogeneity=1.0
    ... )
    >>> data = gen.generate()
    >>> print(f"Effect std: {gen.true_effects.std():.2f}")
    """

    def __init__(
        self,
        config: Optional[DataGeneratorConfig] = None,
        effect_heterogeneity: float = 1.0,
        confounding_strength: float = 0.0,
    ):
        super().__init__(config)
        self.effect_heterogeneity = effect_heterogeneity
        self.confounding_strength = confounding_strength

    def generate(self) -> pd.DataFrame:
        """
        Generate dataset with heterogeneous treatment effects.

        Returns
        -------
        pd.DataFrame
            Dataset with varying individual treatment effects
        """
        n = self.config.n_samples
        k = self.config.n_features

        # Generate covariates
        X = self._generate_covariates(n, k)

        # Treatment assignment (possibly confounded)
        if self.confounding_strength > 0:
            alpha = self.rng.standard_normal(k)
            propensity = self._sigmoid(self.confounding_strength * X @ alpha)
            T = self.rng.binomial(1, propensity)
        else:
            T = self.rng.binomial(1, self.config.treatment_probability, n)
            propensity = np.full(n, self.config.treatment_probability)

        # Heterogeneous treatment effects
        # tau_i = ATE + X @ gamma + epsilon_tau
        gamma = self.rng.standard_normal(k) * 0.5
        tau = self.config.true_ate + X @ gamma * self.effect_heterogeneity
        self._true_effects = tau

        # Baseline outcome
        beta = self.rng.standard_normal(k)
        Y0 = X @ beta + self._generate_noise(n)

        # Observed outcome
        Y = Y0 + T * tau

        # Create DataFrame
        data = pd.DataFrame(X, columns=[f"X{i}" for i in range(k)])
        data["T"] = T
        data["Y"] = Y
        data["propensity_score_true"] = propensity
        data["tau_true"] = tau

        self._data = data
        return data

    def _sigmoid(self, x: np.ndarray) -> np.ndarray:
        """Sigmoid function."""
        return 1 / (1 + np.exp(-x))


class PanelDataGenerator(SyntheticDataGenerator):
    """
    Generate panel data for difference-in-differences analysis.

    Creates data with unit and time dimensions, with staggered
    treatment adoption.

    Parameters
    ----------
    n_units : int
        Number of units (e.g., states, firms)
    n_periods : int
        Number of time periods
    treatment_timing : str
        When treatment starts: "mid" (middle of panel) or "staggered"
    treatment_fraction : float
        Fraction of units that receive treatment

    Examples
    --------
    >>> gen = PanelDataGenerator(n_units=50, n_periods=10)
    >>> data = gen.generate()
    >>> print(data.columns)  # ['unit', 'time', 'T', 'Y', ...]
    """

    def __init__(
        self,
        n_units: int = 50,
        n_periods: int = 10,
        treatment_timing: str = "mid",
        treatment_fraction: float = 0.5,
        config: Optional[DataGeneratorConfig] = None,
    ):
        super().__init__(config)
        self.n_units = n_units
        self.n_periods = n_periods
        self.treatment_timing = treatment_timing
        self.treatment_fraction = treatment_fraction

    def generate(self) -> pd.DataFrame:
        """
        Generate panel dataset.

        Returns
        -------
        pd.DataFrame
            Panel data with unit, time, treatment, and outcome columns
        """
        # Determine which units are treated
        n_treated = int(self.n_units * self.treatment_fraction)
        treated_units = self.rng.choice(self.n_units, size=n_treated, replace=False)

        # Generate treatment timing
        if self.treatment_timing == "mid":
            # All treated units receive treatment at same time
            treatment_start = {u: self.n_periods // 2 for u in treated_units}
        elif self.treatment_timing == "staggered":
            # Staggered treatment adoption
            treatment_start = {
                u: self.rng.integers(self.n_periods // 4, 3 * self.n_periods // 4)
                for u in treated_units
            }
        else:
            raise ValueError(f"Unknown treatment_timing: {self.treatment_timing}")

        # Generate panel data
        records = []

        # Unit fixed effects
        unit_effects = self.rng.standard_normal(self.n_units) * 2

        # Time fixed effects (common trends)
        time_effects = np.cumsum(self.rng.standard_normal(self.n_periods) * 0.5)

        # True treatment effects for each unit
        true_effects = {}

        for unit in range(self.n_units):
            is_treated_unit = unit in treated_units
            start_time = treatment_start.get(unit, self.n_periods + 1)

            for time in range(self.n_periods):
                # Treatment indicator
                T = 1 if is_treated_unit and time >= start_time else 0

                # Outcome with unit and time fixed effects
                Y = (
                    unit_effects[unit]
                    + time_effects[time]
                    + T * self.config.true_ate
                    + self.rng.normal(0, self.config.noise_std)
                )

                records.append(
                    {
                        "unit": unit,
                        "time": time,
                        "T": T,
                        "Y": Y,
                        "treated_unit": int(is_treated_unit),
                        "post": int(time >= self.n_periods // 2),
                    }
                )

                if is_treated_unit and T == 1:
                    true_effects.setdefault(unit, []).append(self.config.true_ate)

        self._data = pd.DataFrame(records)
        self._true_effects = np.array(
            [np.mean(true_effects.get(u, [0])) for u in range(self.n_units)]
        )

        return self._data


class RegressionDiscontinuityGenerator(SyntheticDataGenerator):
    """
    Generate data for regression discontinuity design.

    Treatment is assigned based on a running variable crossing a threshold.

    Parameters
    ----------
    threshold : float
        Cutoff value for treatment assignment
    bandwidth : float
        Width of analysis window around threshold

    Examples
    --------
    >>> gen = RegressionDiscontinuityGenerator(threshold=0.5)
    >>> data = gen.generate()
    """

    def __init__(
        self,
        threshold: float = 0.5,
        bandwidth: float = 0.2,
        config: Optional[DataGeneratorConfig] = None,
    ):
        super().__init__(config)
        self.threshold = threshold
        self.bandwidth = bandwidth

    def generate(self) -> pd.DataFrame:
        """
        Generate RDD dataset.

        Returns
        -------
        pd.DataFrame
            Data with running variable, treatment, and outcome
        """
        n = self.config.n_samples

        # Running variable (e.g., test score, income)
        R = self.rng.uniform(0, 1, n)

        # Sharp treatment assignment
        T = (R >= self.threshold).astype(int)

        # Outcome as function of running variable + treatment effect
        # Y = f(R) + tau * T + epsilon
        # Using polynomial form
        Y0 = 2 * R + 0.5 * R**2 + self._generate_noise(n)
        Y = Y0 + T * self.config.true_ate

        # True effects
        self._true_effects = np.full(n, self.config.true_ate) * T

        # Create DataFrame
        data = pd.DataFrame({"R": R, "T": T, "Y": Y, "distance_to_threshold": R - self.threshold})

        self._data = data
        return data


# =============================================================================
# Factory Functions
# =============================================================================


def make_rct_data(
    n_samples: int = 1000,
    n_features: int = 5,
    true_ate: float = 2.0,
    noise_std: float = 1.0,
    random_state: Optional[int] = None,
) -> Tuple[pd.DataFrame, float]:
    """
    Convenience function to generate perfect RCT data.

    Returns
    -------
    Tuple[pd.DataFrame, float]
        (data, true_ate)
    """
    config = DataGeneratorConfig(
        n_samples=n_samples,
        n_features=n_features,
        true_ate=true_ate,
        noise_std=noise_std,
        random_state=random_state,
    )
    gen = PerfectRCTGenerator(config)
    return gen.generate(), gen.true_ate


def make_confounded_data(
    n_samples: int = 1000,
    n_features: int = 5,
    true_ate: float = 2.0,
    confounding_strength: float = 0.5,
    random_state: Optional[int] = None,
) -> Tuple[pd.DataFrame, float]:
    """
    Convenience function to generate confounded observational data.

    Returns
    -------
    Tuple[pd.DataFrame, float]
        (data, true_ate)
    """
    config = DataGeneratorConfig(
        n_samples=n_samples, n_features=n_features, true_ate=true_ate, random_state=random_state
    )
    gen = ConfoundedObservationalGenerator(config, confounding_strength)
    return gen.generate(), gen.true_ate


def make_panel_data(
    n_units: int = 50,
    n_periods: int = 10,
    true_ate: float = 2.0,
    treatment_timing: str = "mid",
    random_state: Optional[int] = None,
) -> Tuple[pd.DataFrame, float]:
    """
    Convenience function to generate panel data for DiD.

    Returns
    -------
    Tuple[pd.DataFrame, float]
        (data, true_ate)
    """
    config = DataGeneratorConfig(true_ate=true_ate, random_state=random_state)
    gen = PanelDataGenerator(
        n_units=n_units, n_periods=n_periods, treatment_timing=treatment_timing, config=config
    )
    return gen.generate(), gen.true_ate


# =============================================================================
# Exports
# =============================================================================

__all__ = [
    # Config
    "DataGeneratorConfig",
    # Base class
    "SyntheticDataGenerator",
    # Generators
    "PerfectRCTGenerator",
    "ConfoundedObservationalGenerator",
    "HeterogeneousTreatmentEffectGenerator",
    "PanelDataGenerator",
    "RegressionDiscontinuityGenerator",
    # Factory functions
    "make_rct_data",
    "make_confounded_data",
    "make_panel_data",
]
